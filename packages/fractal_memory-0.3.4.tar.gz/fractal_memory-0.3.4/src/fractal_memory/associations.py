"""Association network — B-8 (cellular automata + refractory) and B-15 (stigmergic trails)."""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Callable
from uuid import UUID

import numpy as np

from fractal_memory.config import FractalConfig
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)


class AssociationNetwork:
    """Association network over stored memories.

    Implements:
    - B-8: Cellular automata rules with per-node edge caps and refractory periods.
    - B-15: Stigmergic trail weights on association edges.

    Session state (in-memory, resets between sessions):
      _refractory: memory_id -> turns remaining before activation is allowed.
      _turn_counter: incremented once per retrieval call.
    """

    def __init__(
        self,
        storage: Storage,
        embeddings: EmbeddingProvider,
        config: FractalConfig,
    ) -> None:
        self._storage = storage
        self._embeddings = embeddings
        self._config = config
        # Session-scoped refractory state
        self._refractory: dict[UUID, int] = {}
        self._turn_counter: int = 0

    # ------------------------------------------------------------------
    # Co-retrieval — edge formation and strengthening
    # ------------------------------------------------------------------

    async def on_co_retrieval(
        self, memory_ids: list[UUID], zoom_level: int
    ) -> None:
        """Strengthen or create edges for co-retrieved memories.

        Only memories injected at L2 (zoom_level=2) or higher form edges.
        L3 memories (zoom_level=3) get a doubled weight increment.

        Args:
            memory_ids: IDs of memories retrieved together.
            zoom_level: The zoom level at which they were injected (2 or 3).
        """
        if len(memory_ids) < 2 or zoom_level < 2:
            return

        # Determine weight increment (L3 gets higher increment than L2)
        base_increment = (
            self._config.co_retrieval_weight_l3
            if zoom_level >= 3
            else self._config.co_retrieval_weight_l2
        )

        for i in range(len(memory_ids)):
            for j in range(i + 1, len(memory_ids)):
                a = memory_ids[i]
                b = memory_ids[j]
                await self._strengthen_or_create_edge(a, b, base_increment)

    async def _strengthen_or_create_edge(
        self, a: UUID, b: UUID, base_increment: float
    ) -> None:
        """Strengthen existing edge or create new one, enforcing edge cap."""
        edges_a = await self._storage.get_associations(a)
        # Check if edge already exists
        existing = next(
            (e for e in edges_a if e[0] == b), None
        )

        if existing is not None:
            current_weight = existing[1]
            new_weight = min(
                self._config.edge_weight_max,
                current_weight + base_increment * (1.0 - current_weight),
            )
            await self._storage.update_association_weight(a, b, new_weight)
        else:
            # New edge — check edge cap on both nodes
            count_a = await self._storage.count_associations(a)
            count_b = await self._storage.count_associations(b)
            cap = self._config.edge_cap_per_node

            if count_a >= cap:
                weakest = await self._storage.get_weakest_association(a)
                if weakest:
                    src, tgt, _ = weakest
                    await self._storage.delete_association(src, tgt)

            if count_b >= cap:
                weakest = await self._storage.get_weakest_association(b)
                if weakest:
                    src, tgt, _ = weakest
                    await self._storage.delete_association(src, tgt)

            await self._storage.store_association(
                source_id=a,
                target_id=b,
                weight=base_increment,
            )

    # ------------------------------------------------------------------
    # Spreading activation — 1-hop traversal
    # ------------------------------------------------------------------

    async def spreading_activation(
        self, seed_ids: list[UUID], domain: str | None = None
    ) -> dict[UUID, float]:
        """Spread activation 1 hop from seed memories.

        Skips neighbors in refractory. Returns boost values keyed by memory ID.
        Target latency: <10ms for 10K memories (1-hop only).

        Args:
            seed_ids: Directly retrieved memory IDs (seeds for activation).
            domain: Optional domain filter (future use; not filtered here).

        Returns:
            dict mapping neighbor memory IDs to their activation boost.
        """
        boosts: dict[UUID, float] = defaultdict(float)
        seed_set = set(seed_ids)

        for seed_id in seed_ids:
            edges = await self._storage.get_associations(seed_id)
            for neighbor_id, weight, _trail_w, _centroid in edges:
                if neighbor_id in seed_set:
                    continue
                if self._refractory.get(neighbor_id, 0) > 0:
                    continue
                boost = weight * self._config.activation_decay
                boosts[neighbor_id] = max(boosts[neighbor_id], boost)

        return dict(boosts)

    # ------------------------------------------------------------------
    # Refractory period management (B-8)
    # ------------------------------------------------------------------

    async def enter_refractory(self, memory_ids: list[UUID]) -> None:
        """Put memories into refractory for config.refractory_turns turns.

        Args:
            memory_ids: IDs of memories to make refractory (typically L3-injected).
        """
        turns = self._config.refractory_turns
        for mid in memory_ids:
            self._refractory[mid] = turns

    def advance_turn(self) -> None:
        """Decrement all refractory counters. Remove entries that reach 0."""
        self._turn_counter += 1
        expired = [mid for mid, turns in self._refractory.items() if turns <= 1]
        for mid in expired:
            del self._refractory[mid]
        for mid in list(self._refractory.keys()):
            if mid not in expired:
                self._refractory[mid] -= 1

    # ------------------------------------------------------------------
    # Edge access (P2→P3 contracts)
    # ------------------------------------------------------------------

    async def get_edges(
        self, memory_id: UUID
    ) -> list[tuple[UUID, float]]:
        """Return all edges for a memory as (target_id, weight) pairs.

        P2→P3 contract for niche construction.
        """
        edges = await self._storage.get_associations(memory_id)
        return [(neighbor_id, weight) for neighbor_id, weight, _, _ in edges]

    async def update_edge(
        self, source_id: UUID, target_id: UUID, weight: float
    ) -> None:
        """Set edge weight directly. Clamps to [edge_weight_min, edge_weight_max].

        P2→P3 contract for niche construction.
        """
        clamped = max(self._config.edge_weight_min, min(self._config.edge_weight_max, weight))
        await self._storage.update_association_weight(source_id, target_id, clamped)

    # ------------------------------------------------------------------
    # Slow-wave homeostasis (B-13 partial)
    # ------------------------------------------------------------------

    async def decay_all_weights(self, factor: float | None = None) -> int:
        """Multiply all edge weights by factor; delete edges below min_viable_edge_weight.

        Called during sleep consolidation at session_end.
        Uses batch SQL for O(1) DB operations instead of per-edge updates (Issue #38).

        Args:
            factor: Multiplicative decay factor (0 < factor < 1). Defaults to config.slow_wave_decay_factor.

        Returns:
            Count of edges pruned.
        """
        if factor is None:
            factor = self._config.slow_wave_decay_factor
        min_weight = self._config.min_viable_edge_weight
        pruned = await self._storage.batch_decay_and_prune(factor, min_weight)
        logger.debug(
            "Slow-wave decay: factor=%.2f, pruned=%d edges", factor, pruned
        )
        return pruned

    # ------------------------------------------------------------------
    # Stigmergic trail (B-15)
    # ------------------------------------------------------------------

    async def strengthen_trail(
        self, memory_ids: list[UUID], query_embedding: list[float]
    ) -> None:
        """Strengthen trail weight on edges along the retrieved path.

        Called when a retrieval is confirmed as successful (safety signal or
        judge rating 2). Updates trail_weight as asymptotic approach and
        trail_context_centroid as exponential moving average (EMA).

        Args:
            memory_ids: IDs of memories on the confirmed-useful retrieval path.
            query_embedding: The query vector that produced the good outcome.
        """
        query_vec = np.array(query_embedding, dtype=np.float32)

        for i in range(len(memory_ids)):
            for j in range(i + 1, len(memory_ids)):
                a = memory_ids[i]
                b = memory_ids[j]
                edges_a = await self._storage.get_associations(a)
                existing = next((e for e in edges_a if e[0] == b), None)
                if existing is None:
                    continue

                _neighbor_id, _weight, trail_weight, centroid = existing

                # Asymptotic trail weight increase
                new_trail_weight = min(
                    self._config.edge_weight_max,
                    trail_weight + self._config.trail_increment_rate * (1.0 - trail_weight),
                )

                # EMA centroid update
                alpha = self._config.trail_ema_alpha
                if centroid is None:
                    new_centroid = query_embedding
                else:
                    c_vec = np.array(centroid, dtype=np.float32)
                    new_c_vec = alpha * c_vec + (1.0 - alpha) * query_vec
                    new_centroid = new_c_vec.tolist()

                await self._storage.update_association_trail(
                    a, b, new_trail_weight, new_centroid
                )

    async def get_trail_boost(
        self, query_embedding: list[float], candidate_ids: list[UUID]
    ) -> dict[UUID, float]:
        """Cold start boost using stigmergic trail weights (B-15).

        Called during the first 3 retrievals of a session. For each candidate,
        checks edges for trail_weight > 0. Boost = trail_weight * cosine_sim
        between query and trail_context_centroid.

        Args:
            query_embedding: Current query vector.
            candidate_ids: Memory IDs to check for trail boosts.

        Returns:
            dict mapping memory ID to boost value.
        """
        query_vec = np.array(query_embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_vec)
        if query_norm == 0:
            return {}

        boosts: dict[UUID, float] = {}
        for mid in candidate_ids:
            edges = await self._storage.get_associations(mid)
            best_boost = 0.0
            for _neighbor_id, _weight, trail_weight, centroid in edges:
                if trail_weight <= 0 or centroid is None:
                    continue
                c_vec = np.array(centroid, dtype=np.float32)
                c_norm = np.linalg.norm(c_vec)
                if c_norm == 0:
                    continue
                cos_sim = float(np.dot(query_vec, c_vec) / (query_norm * c_norm))
                boost = trail_weight * max(0.0, cos_sim)
                best_boost = max(best_boost, boost)
            if best_boost > 0:
                boosts[mid] = best_boost

        return boosts

    # ------------------------------------------------------------------
    # Stats (P2→P3 contract)
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Phase 3 additions
    # ------------------------------------------------------------------

    async def get_all_edges(self) -> list[dict]:
        """Return all association edges as dicts with source, target, weight."""
        all_edges = await self._storage.get_all_associations()
        return [
            {"source": src, "target": tgt, "weight": w}
            for src, tgt, w in all_edges
        ]

    async def get_neighbors(self, memory_id: UUID) -> list[UUID]:
        """Return IDs of all memories directly connected to memory_id."""
        edges = await self.get_edges(memory_id)
        return [nid for nid, _ in edges]

    async def adjust_edge_weight(
        self,
        source_id: UUID,
        target_id: UUID,
        delta_fn: "Callable[[float], float]",
    ) -> None:
        """Apply delta_fn to the edge weight between source_id and target_id.

        Creates the edge if it does not exist.  Clamps result to [0.01, 0.99].
        """
        edges = await self._storage.get_associations(source_id)
        current_weight = 0.0
        for mid, w, *_ in edges:
            if mid == target_id:
                current_weight = w
                break
        new_weight = max(0.01, min(0.99, delta_fn(current_weight)))
        await self._storage.update_association_weight(source_id, target_id, new_weight)

    async def prune_below(self, threshold: float) -> int:
        """Delete all association edges with weight below threshold.

        Delegates to ``Storage.delete_weak_associations()`` — no private API access.

        Args:
            threshold: Edges with weight strictly below this are deleted.

        Returns:
            Count of deleted edges.

        Added in Phase 3 for dreaming slow-wave cleanup.
        See also: ``decay_all_weights``.
        """
        return await self._storage.delete_weak_associations(threshold)

    async def get_stats(self) -> dict:
        """Return association network statistics.

        Returns:
            dict with edge_count, avg_weight, max_weight, nodes_with_edges.
        """
        all_edges = await self._storage.get_all_associations()
        if not all_edges:
            return {
                "edge_count": 0,
                "avg_weight": 0.0,
                "max_weight": 0.0,
                "nodes_with_edges": 0,
            }
        weights = [w for _, _, w in all_edges]
        nodes: set[UUID] = set()
        for src, tgt, _ in all_edges:
            nodes.add(src)
            nodes.add(tgt)
        return {
            "edge_count": len(all_edges),
            "avg_weight": float(np.mean(weights)),
            "max_weight": float(np.max(weights)),
            "nodes_with_edges": len(nodes),
        }
