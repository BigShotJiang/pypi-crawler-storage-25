"""Contextual bandits with Thompson Sampling for retrieval strategy selection (B-4, Phase 3)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from fractal_memory.config import FractalConfig
from fractal_memory.morphogens import MorphogenState

if TYPE_CHECKING:
    pass


# ---------------------------------------------------------------------------
# Arm definitions
# ---------------------------------------------------------------------------

ARMS_CONFIG: dict[str, dict[str, float]] = {
    "conservative": {"gate_strictness": 0.8, "activation_decay": 0.3, "retrieval_breadth": 0.3},
    "aggressive": {"gate_strictness": 0.2, "activation_decay": 0.7, "retrieval_breadth": 0.9},
    "precision": {"gate_strictness": 0.6, "activation_decay": 0.3, "retrieval_breadth": 0.4},
    "exploratory": {"gate_strictness": 0.3, "activation_decay": 0.7, "retrieval_breadth": 0.8},
    "balanced": {},  # use morphogen-derived defaults
}


@dataclass
class RetrievalArm:
    """A named retrieval strategy with Beta posterior parameters."""

    name: str
    parameters: dict[str, float]
    alpha: float = 1.0       # Beta success count + prior
    beta_param: float = 1.0  # Beta failure count + prior


# ---------------------------------------------------------------------------
# Context binning
# ---------------------------------------------------------------------------

def _bin_morphogen(value: float) -> int:
    """Discretise a morphogen value into 3 levels: 0 (low), 1 (medium), 2 (high)."""
    if value < 0.33:
        return 0
    if value < 0.67:
        return 1
    return 2


def _context_key(morphogens: MorphogenState) -> str:
    """Produce a string key for a context bin (27 possible values, 3^3)."""
    ir = _bin_morphogen(morphogens.information_richness)
    rp = _bin_morphogen(morphogens.retrieval_pressure)
    dd = _bin_morphogen(morphogens.domain_density)
    return f"{ir}_{rp}_{dd}"


# ---------------------------------------------------------------------------
# ContextualBandit
# ---------------------------------------------------------------------------

class ContextualBandit:
    """Thompson Sampling bandit over 5 arms × 27 context bins.

    The "balanced" arm defers to morphogen-derived defaults.  The other four
    arms override specific parameters.

    Hierarchy:
      B-4 selects the arm family → B-1 provides baseline values → B-11 fine-tunes.
    """

    def __init__(self, config: FractalConfig) -> None:
        self._config = config
        # context_bin → arm_name → RetrievalArm
        self._arms: dict[str, dict[str, RetrievalArm]] = {}
        self._current_arm: str | None = None
        self._current_context_key: str | None = None
        self._rng = np.random.default_rng()

    def _ensure_context(self, ctx_key: str) -> None:
        """Lazily initialise arm posteriors for a context bin."""
        if ctx_key not in self._arms:
            self._arms[ctx_key] = {
                name: RetrievalArm(name=name, parameters=dict(params))
                for name, params in ARMS_CONFIG.items()
            }

    # ------------------------------------------------------------------
    # Selection
    # ------------------------------------------------------------------

    def select_arm(self, morphogens: MorphogenState) -> RetrievalArm:
        """Sample from each arm's Beta posterior and return the winner.

        Stores the selection as ``_current_arm`` for ``record_outcome``.
        """
        ctx_key = _context_key(morphogens)
        self._ensure_context(ctx_key)
        self._current_context_key = ctx_key

        best_arm_name: str = "balanced"
        best_sample: float = -1.0
        for name, arm in self._arms[ctx_key].items():
            sample = float(self._rng.beta(arm.alpha, arm.beta_param))
            if sample > best_sample:
                best_sample = sample
                best_arm_name = name

        self._current_arm = best_arm_name
        return self._arms[ctx_key][best_arm_name]

    # ------------------------------------------------------------------
    # Feedback
    # ------------------------------------------------------------------

    def record_outcome(self, success: bool) -> None:
        """Update the selected arm's Beta posterior.

        Only called when a clear signal is available.  Ambiguous outcomes
        are ignored (danger theory principle).
        """
        if self._current_arm is None or self._current_context_key is None:
            return
        ctx = self._current_context_key
        if ctx not in self._arms:
            return
        arm = self._arms[ctx].get(self._current_arm)
        if arm is None:
            return
        if success:
            arm.alpha += 1.0
        else:
            arm.beta_param += 1.0

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def get_arm_stats(self) -> dict[str, dict[str, float]]:
        """Return per-arm statistics aggregated across all context bins.

        Returns:
            ``{arm_name: {"alpha": float, "beta": float, "mean_success": float, "pulls": int}}``
        """
        totals: dict[str, dict[str, float]] = {
            name: {"alpha": 0.0, "beta": 0.0, "pulls": 0.0}
            for name in ARMS_CONFIG
        }
        for ctx_arms in self._arms.values():
            for name, arm in ctx_arms.items():
                totals[name]["alpha"] += arm.alpha
                totals[name]["beta"] += arm.beta_param
                totals[name]["pulls"] += arm.alpha + arm.beta_param - 2.0  # subtract priors

        result: dict[str, dict[str, float]] = {}
        for name, agg in totals.items():
            total = agg["alpha"] + agg["beta"]
            result[name] = {
                "alpha": agg["alpha"],
                "beta": agg["beta"],
                "mean_success": agg["alpha"] / max(1.0, total),
                "pulls": max(0.0, agg["pulls"]),
            }
        return result

    # ------------------------------------------------------------------
    # Dreaming: posterior downscaling
    # ------------------------------------------------------------------

    def downscale_posteriors(self, factor: float | None = None) -> None:
        """Proportionally reduce all arm posteriors to force re-exploration.

        Called during B-13 slow-wave dreaming.  Values are floored at 1.0
        (uniform prior) to prevent collapse.
        """
        effective_factor = factor if factor is not None else self._config.bandit_downscale_factor
        for ctx_arms in self._arms.values():
            for arm in ctx_arms.values():
                arm.alpha = max(1.0, arm.alpha * effective_factor)
                arm.beta_param = max(1.0, arm.beta_param * effective_factor)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def serialize(self) -> dict:
        """Serialise bandit state to a plain dict."""
        arms_data: dict[str, dict[str, dict[str, float]]] = {}
        for ctx_key, ctx_arms in self._arms.items():
            arms_data[ctx_key] = {}
            for name, arm in ctx_arms.items():
                arms_data[ctx_key][name] = {
                    "alpha": arm.alpha,
                    "beta_param": arm.beta_param,
                }
        return {
            "current_arm": self._current_arm,
            "current_context_key": self._current_context_key,
            "arms": arms_data,
        }

    @classmethod
    def deserialize(cls, data: dict, config: FractalConfig) -> "ContextualBandit":
        """Reconstruct from a serialised dict."""
        instance = cls(config=config)
        instance._current_arm = data.get("current_arm")
        instance._current_context_key = data.get("current_context_key")
        for ctx_key, ctx_arms_data in data.get("arms", {}).items():
            instance._arms[ctx_key] = {}
            for arm_name, arm_vals in ctx_arms_data.items():
                arm = RetrievalArm(
                    name=arm_name,
                    parameters=dict(ARMS_CONFIG.get(arm_name, {})),
                    alpha=float(arm_vals.get("alpha", 1.0)),
                    beta_param=float(arm_vals.get("beta_param", 1.0)),
                )
                instance._arms[ctx_key][arm_name] = arm
        return instance

    @property
    def current_arm(self) -> str | None:
        """Name of the arm selected in the most recent call to select_arm."""
        return self._current_arm
