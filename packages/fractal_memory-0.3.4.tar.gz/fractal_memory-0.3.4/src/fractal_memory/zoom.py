"""Zoom level generation — compress raw text into L0–L3 levels."""

from __future__ import annotations

import json
import logging
import re
from typing import NamedTuple

from fractal_memory.llm import LLMProvider, LLMUnavailableError
from fractal_memory.models import ContextTags

logger = logging.getLogger(__name__)


class ZoomLevels(NamedTuple):
    l0_tag: str
    l1_label: str
    l2_summary: str
    l3_full: str


_SYSTEM_PROMPT = (
    "You are a memory compression engine. You compress raw text into multiple "
    "zoom levels for a memory system. Each zoom level represents the same "
    "information at a different resolution. You MUST respond with valid JSON "
    "only — no explanation, no markdown."
)

_USER_PROMPT_TEMPLATE = """Compress the following memory into 4 zoom levels. The memory was created in domain "{domain}".

Memory text:
---
{raw_text}
---

Respond with this exact JSON structure:
{{
  "l0_tag": "<2 tokens max. A category tag like 'db:config' or 'pref:lang'. Use format category:subtag>",
  "l1_label": "<10 tokens max. A descriptive label like 'user-prefers-TypeScript-backend'. Use kebab-case, no spaces>",
  "l2_summary": "<30 tokens max. One compressed sentence capturing the gist with key details>",
  "l3_full": "<100 tokens max. Full context with nuances, exceptions, and conditions. Structured prose, not verbatim copy>"
}}

Rules:
- l0 MUST be ≤2 tokens. Use category:subtag format.
- l1 MUST be ≤10 tokens. Kebab-case label.
- l2 MUST be ≤30 tokens. Single compressed sentence.
- l3 MUST be ≤100 tokens. Full context with all nuance.
- Preserve ALL critical information — especially negations ("NOT", "NEVER"), exceptions, and conditions.
- If the memory contains a contrast (what something is NOT), include it in l2 and l3."""


class ZoomGenerator:
    def __init__(self, llm: LLMProvider) -> None:
        self._llm = llm

    async def generate(
        self,
        raw_text: str,
        domain: str | None = None,
        context: ContextTags | None = None,
    ) -> ZoomLevels:
        try:
            prompt = _USER_PROMPT_TEMPLATE.format(
                domain=domain or "general",
                raw_text=raw_text,
            )
            response = await self._llm.complete(
                prompt=prompt, system=_SYSTEM_PROMPT, max_tokens=500
            )
            return self._parse_zoom_response(response, raw_text)
        except LLMUnavailableError:
            logger.warning("LLM unavailable — using fallback zoom generation")
            return self._generate_fallback(raw_text)

    def _generate_fallback(self, raw_text: str) -> ZoomLevels:
        words = raw_text.split()
        # L0: first 2 words
        l0 = ":".join(words[:2]).lower()[:20] if len(words) >= 2 else "mem:note"
        # L1: first ~10 words, kebab-case
        l1_words = words[:10]
        l1 = "-".join(w.lower().strip(".,!?;:") for w in l1_words)[:60]
        # L2: first ~2 sentences, truncated to ~30 tokens
        sentences = re.split(r"(?<=[.!?])\s+", raw_text)
        l2 = " ".join(sentences[:2])[:150]
        # L3: full text truncated to ~100 tokens
        l3 = raw_text[:500]
        return ZoomLevels(l0_tag=l0, l1_label=l1, l2_summary=l2, l3_full=l3)

    def _parse_zoom_response(self, response: str, raw_text: str) -> ZoomLevels:
        # Strip markdown fences
        cleaned = response.strip()
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("Failed to parse LLM zoom response — using fallback")
            return self._generate_fallback(raw_text)

        if not isinstance(data, dict):
            return self._generate_fallback(raw_text)

        # Fill missing fields with fallback values
        fallback = self._generate_fallback(raw_text)
        l0 = data.get("l0_tag") or fallback.l0_tag
        l1 = data.get("l1_label") or fallback.l1_label
        l2 = data.get("l2_summary") or fallback.l2_summary
        l3 = data.get("l3_full") or fallback.l3_full

        return ZoomLevels(l0_tag=l0, l1_label=l1, l2_summary=l2, l3_full=l3)
