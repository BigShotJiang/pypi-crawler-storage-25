"""LLM provider abstraction for zoom generation and session summaries."""

from __future__ import annotations

import asyncio
import logging
from typing import Protocol, runtime_checkable

logger = logging.getLogger(__name__)


class LLMUnavailableError(Exception):
    """Raised when the LLM API is unreachable after retries."""


class LLMRateLimitError(Exception):
    """Raised when the session LLM call limit is exceeded."""


@runtime_checkable
class LLMProvider(Protocol):
    async def complete(
        self,
        prompt: str,
        system: str | None = None,
        max_tokens: int = 500,
    ) -> str: ...


class LLMCallTracker:
    """Wraps an LLMProvider with concurrency control, rate limiting, and usage logging.

    Args:
        provider: The underlying LLM provider to wrap.
        max_concurrent: Max simultaneous LLM calls (semaphore limit).
        max_calls_per_session: Safety limit on total calls per session.
    """

    def __init__(
        self,
        provider: LLMProvider,
        max_concurrent: int = 3,
        max_calls_per_session: int = 200,
    ) -> None:
        self._provider = provider
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._max_calls = max_calls_per_session
        self._call_count = 0
        self._total_prompt_chars = 0
        self._total_response_chars = 0

    async def complete(
        self,
        prompt: str,
        system: str | None = None,
        max_tokens: int = 500,
    ) -> str:
        if self._call_count >= self._max_calls:
            raise LLMRateLimitError(
                f"Session LLM call limit reached ({self._max_calls}). "
                "This prevents runaway costs from bugs or loops."
            )
        async with self._semaphore:
            self._call_count += 1
            self._total_prompt_chars += len(prompt) + len(system or "")
            try:
                response = await self._provider.complete(prompt, system, max_tokens)
                self._total_response_chars += len(response)
                logger.debug(
                    "LLM call #%d: ~%d prompt tokens, ~%d response tokens",
                    self._call_count,
                    (len(prompt) + len(system or "")) // 4,
                    len(response) // 4,
                )
                return response
            except Exception:
                logger.debug("LLM call #%d failed", self._call_count)
                raise

    def reset_session(self) -> None:
        """Reset call count for a new session."""
        if self._call_count > 0:
            logger.info(
                "LLM session usage: %d calls, ~%d prompt tokens, ~%d response tokens",
                self._call_count,
                self._total_prompt_chars // 4,
                self._total_response_chars // 4,
            )
        self._call_count = 0
        self._total_prompt_chars = 0
        self._total_response_chars = 0

    @property
    def call_count(self) -> int:
        return self._call_count


class ClaudeCodeProvider:
    """LLM provider using Claude Code bridge (Pro subscription, no API key)."""

    def __init__(self, model: str = "sonnet", timeout: float = 30.0) -> None:
        self._model = model
        self._timeout = timeout
        self._client = None

    def _get_client(self) -> object:
        if self._client is None:
            from fractal_memory.bridge import AsyncClaudeCode

            self._client = AsyncClaudeCode()
        return self._client

    async def complete(
        self,
        prompt: str,
        system: str | None = None,
        max_tokens: int = 500,
    ) -> str:
        try:
            client = self._get_client()
            response = await asyncio.wait_for(
                client.messages.create(
                    model=self._model,
                    max_tokens=max_tokens,
                    system=system or "",
                    messages=[{"role": "user", "content": prompt}],
                ),
                timeout=self._timeout,
            )
            return response.content[0].text
        except asyncio.TimeoutError as e:
            raise LLMUnavailableError(
                f"Claude Code bridge timed out after {self._timeout}s"
            ) from e
        except FileNotFoundError as e:
            raise LLMUnavailableError(
                f"Claude Code bridge not available: {e}. "
                "Set ANTHROPIC_API_KEY or FRACTAL_LLM_PROVIDER=ollama for LLM features, "
                "or use fractal-memory without LLM (all core features work)."
            ) from e
        except Exception as e:
            raise LLMUnavailableError(f"Claude Code bridge error: {e}") from e


class AnthropicProvider:
    """LLM provider using the Anthropic API directly."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-haiku-4-5-20251001",
        timeout: float = 30.0,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._timeout = timeout
        self._client = None

    def _get_client(self) -> object:
        if self._client is None:
            import anthropic

            self._client = anthropic.AsyncAnthropic(api_key=self._api_key)
        return self._client

    async def complete(
        self,
        prompt: str,
        system: str | None = None,
        max_tokens: int = 500,
    ) -> str:
        import anthropic

        client = self._get_client()
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                kwargs: dict = {
                    "model": self._model,
                    "max_tokens": max_tokens,
                    "messages": [{"role": "user", "content": prompt}],
                }
                if system:
                    kwargs["system"] = system
                response = await asyncio.wait_for(
                    client.messages.create(**kwargs),
                    timeout=self._timeout,
                )
                return response.content[0].text
            except (asyncio.TimeoutError, anthropic.APIError):
                if attempt < max_attempts - 1:
                    # Exponential backoff with jitter (Issue #44)
                    delay = (2 ** attempt) + (attempt * 0.5)
                    await asyncio.sleep(delay)
                    continue
                raise LLMUnavailableError(
                    f"Anthropic API unavailable after {max_attempts} attempts"
                )
        raise LLMUnavailableError("Anthropic API unavailable")  # pragma: no cover


class OllamaProvider:
    """LLM provider using Ollama local server."""

    def __init__(
        self,
        model: str = "llama3.2",
        base_url: str = "http://localhost:11434",
        timeout: float = 60.0,
    ) -> None:
        self._model = model
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client: object | None = None  # httpx.AsyncClient (lazy)

    def _get_client(self) -> object:
        """Lazily create and reuse a persistent HTTP client (Issue #36)."""
        if self._client is None:
            import httpx

            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client

    async def complete(
        self,
        prompt: str,
        system: str | None = None,
        max_tokens: int = 500,
    ) -> str:
        try:
            client = self._get_client()
            payload: dict = {
                "model": self._model,
                "prompt": prompt,
                "stream": False,
                "options": {"num_predict": max_tokens},
            }
            if system:
                payload["system"] = system
            response = await client.post(
                f"{self._base_url}/api/generate", json=payload
            )
            response.raise_for_status()
            return response.json()["response"]
        except Exception as e:
            raise LLMUnavailableError(f"Ollama error: {e}") from e
