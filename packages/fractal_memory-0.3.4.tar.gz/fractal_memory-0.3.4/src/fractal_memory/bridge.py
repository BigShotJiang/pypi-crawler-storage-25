"""
Claude Code Client via Node.js Bridge

Uses the official Claude Agent SDK via a Node.js bridge to leverage
your Claude Code Pro subscription instead of paying API credits.

The bridge calls @anthropic-ai/claude-agent-sdk which properly
authenticates via your Claude Code login (claude login).

Why Node.js bridge instead of direct Python SDK?
- The official Claude Agent SDK is only available for Node.js
- This bridge approach avoids maintaining a separate Python SDK
- Subprocess communication is async-friendly and reliable

Streaming Events:
- When stream_events=True, the bridge emits real-time events via stderr
- Events include: tool_start, tool_end, text_delta, query_start, query_complete
- Python can read these asynchronously to show live progress
"""

import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# Default timeout for SDK calls (in seconds)
DEFAULT_SDK_TIMEOUT_SECONDS = 1200  # 20 minutes - for large generation tasks
DEFAULT_STALE_TIMEOUT_SECONDS = 120  # 2 minutes - detect potential hangs early

# Type alias for event callbacks
EventCallback = Callable[[Dict[str, Any]], None]


@dataclass
class SDKEvent:
    """Event emitted by the Claude Agent SDK during execution."""
    type: str
    timestamp: int = 0
    tool: Optional[str] = None
    tool_id: Optional[str] = None
    input: Optional[Dict[str, Any]] = None
    duration_ms: Optional[int] = None
    text: Optional[str] = None
    is_error: bool = False
    usage: Optional[Dict[str, int]] = None
    model: Optional[str] = None


@dataclass
class ClaudeCodeUsage:
    """Usage statistics from Claude Agent SDK."""
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0


@dataclass
class ClaudeCodeResponse:
    """Response from Claude Code, mimicking Anthropic SDK response structure."""
    content: List[Any]
    stop_reason: str
    usage: ClaudeCodeUsage
    model: str


@dataclass
class TextBlock:
    """Text content block."""
    type: str = "text"
    text: str = ""


class ClaudeCodeClient:
    """
    Async client that uses Claude Agent SDK via Node.js bridge.

    This allows using your Claude Code Pro subscription instead of
    paying per-token with the Anthropic API.

    Prerequisites:
        1. Install Claude Code: npm install -g @anthropic-ai/claude-code
        2. Login: claude login
        3. Run npm install in experiments/bridge directory
    """

    DEFAULT_MODEL_MAP: Dict[str, str] = {
        "claude-opus-4-6": "opus",
        "claude-sonnet-4-5-20250929": "sonnet",
        "claude-sonnet-4-5": "sonnet",
        "claude-haiku-4-5-20251001": "haiku",
        "claude-haiku-4-5": "haiku",
        "claude-opus-4-20250514": "opus",
        "claude-sonnet-4-20250514": "sonnet",
        "claude-3-5-sonnet-latest": "sonnet",
        "claude-3-5-haiku-latest": "haiku",
        "claude-3-opus-20240229": "opus",
        "claude-3-sonnet-20240229": "sonnet",
        "claude-3-haiku-20240307": "haiku",
    }

    def __init__(
        self,
        bridge_path: Optional[str] = None,
        model_map: Optional[Dict[str, str]] = None,
        timeout_seconds: Optional[int] = None,
        stale_timeout_seconds: Optional[int] = None
    ):
        self._timeout_seconds = timeout_seconds if timeout_seconds else DEFAULT_SDK_TIMEOUT_SECONDS
        self._stale_timeout_seconds = stale_timeout_seconds if stale_timeout_seconds else DEFAULT_STALE_TIMEOUT_SECONDS

        if bridge_path:
            self._bridge_path = Path(bridge_path)
        else:
            # Dev repo layout: internal/experiments/bridge/claude_bridge.mjs
            # This bridge requires Node.js + npm install in the bridge directory.
            # For pip-installed users, use AnthropicProvider or OllamaProvider instead.
            self._bridge_path = (
                Path(__file__).parent.parent.parent
                / "internal" / "experiments" / "bridge" / "claude_bridge.mjs"
            )

        if not self._bridge_path.exists():
            raise FileNotFoundError(
                f"Claude Code bridge not found at {self._bridge_path}. "
                "The bridge requires a development checkout of fractal-memory with "
                "Node.js dependencies installed (cd internal/experiments/bridge && npm install). "
                "For production use, configure an LLM provider instead:\n"
                "  - ANTHROPIC_API_KEY env var → uses Anthropic API directly\n"
                "  - FRACTAL_LLM_PROVIDER=ollama → uses local Ollama\n"
                "  - Or pass llm=YourProvider() to FractalMemory()\n"
                "The system works without an LLM (zoom uses fallback, no dreaming/judge)."
            )

        self._model_map = {**self.DEFAULT_MODEL_MAP, **(model_map or {})}
        logger.debug("ClaudeCodeClient initialized with bridge at %s", self._bridge_path)

    def _build_prompt(
        self,
        system: str,
        messages: List[Dict[str, Any]],
    ) -> str:
        """Build a single prompt string from system prompt and messages.

        For single-turn requests (one user message, no assistant messages),
        returns the user content directly without role prefixes. This avoids
        the Agent SDK misinterpreting structured prompts as conversational.
        """
        # Extract message contents
        user_parts = []
        has_assistant = False
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        text_parts.append(block)
                content = "\n".join(text_parts)

            if role == "assistant":
                has_assistant = True
            user_parts.append((role, content))

        # Single-turn: pass content directly (no "User:" prefix)
        if not has_assistant and len(user_parts) == 1:
            return user_parts[0][1]

        # Multi-turn: use role prefixes
        parts = []
        for role, content in user_parts:
            if role == "user":
                parts.append(f"User: {content}")
            elif role == "assistant":
                parts.append(f"Assistant: {content}")
        return "\n\n".join(parts)

    def _map_model(self, model: str) -> str:
        """Map model names to SDK format."""
        return self._model_map.get(model, model)

    async def create_message(
        self,
        model: str,
        max_tokens: int,
        messages: List[Dict[str, Any]],
        system: str = "",
        temperature: Optional[float] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        working_directory: Optional[str] = None,
        **kwargs
    ) -> ClaudeCodeResponse:
        """Create a message using Claude Agent SDK via Node.js bridge."""
        mapped_model = self._map_model(model)
        logger.info("Creating message with model=%s (original=%s)", mapped_model, model)

        prompt = self._build_prompt(system, messages)

        bridge_input = {
            "prompt": prompt,
            "system_prompt": system,
            "model": mapped_model,
            "timeout_seconds": self._timeout_seconds,
            "stale_timeout_seconds": self._stale_timeout_seconds
        }

        if working_directory:
            bridge_input["cwd"] = working_directory

        env = os.environ.copy()
        env.pop("ANTHROPIC_API_KEY", None)
        env.pop("CLAUDECODE", None)

        process = None
        try:
            process = await asyncio.create_subprocess_exec(
                "node",
                str(self._bridge_path),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(input=json.dumps(bridge_input).encode("utf-8")),
                    timeout=self._timeout_seconds
                )
            except asyncio.TimeoutError:
                if process:
                    try:
                        process.kill()
                        await process.wait()
                    except ProcessLookupError:
                        pass
                raise RuntimeError(
                    f"Claude SDK call timed out after {self._timeout_seconds}s. "
                    "Consider simplifying the query or increasing timeout."
                )

            if process.returncode != 0:
                error_msg = stderr.decode("utf-8", errors="replace").strip()
                stdout_msg = stdout.decode("utf-8", errors="replace").strip()
                full_error = error_msg or stdout_msg or "Unknown error"
                raise RuntimeError(f"Claude bridge failed (exit {process.returncode}): {full_error}")

            output = stdout.decode("utf-8", errors="replace").strip()
            result = json.loads(output)

            if not result.get("success"):
                error = result.get("error", "Unknown error")
                raise RuntimeError(f"Claude SDK error: {error}")

            usage_data = result.get("usage", {})
            usage = ClaudeCodeUsage(
                input_tokens=usage_data.get("input_tokens", 0),
                output_tokens=usage_data.get("output_tokens", 0),
                cache_creation_input_tokens=usage_data.get("cache_creation_input_tokens", 0),
                cache_read_input_tokens=usage_data.get("cache_read_input_tokens", 0)
            )

            return ClaudeCodeResponse(
                content=[TextBlock(type="text", text=result.get("response", ""))],
                stop_reason="end_turn",
                usage=usage,
                model=result.get("model", model)
            )

        except FileNotFoundError:
            raise RuntimeError(
                "Node.js not found. Please ensure Node.js is installed and in PATH."
            )
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Failed to parse bridge response: {e}")
        except RuntimeError:
            raise
        except Exception as e:
            raise RuntimeError(f"Claude bridge error: {type(e).__name__}: {str(e)}")


class ClaudeCodeMessages:
    """Wrapper to match Anthropic SDK's client.messages interface."""

    def __init__(
        self,
        client: ClaudeCodeClient,
        working_directory: Optional[str] = None,
    ):
        self._client = client
        self._working_directory = working_directory

    async def create(self, **kwargs) -> ClaudeCodeResponse:
        """Create a message (matches Anthropic SDK interface)."""
        if self._working_directory and "working_directory" not in kwargs:
            kwargs["working_directory"] = self._working_directory
        return await self._client.create_message(**kwargs)


class AsyncClaudeCode:
    """
    Async Claude Code client matching Anthropic SDK interface.

    Drop-in replacement for anthropic.AsyncAnthropic when using Claude Pro.

    Usage:
        # Instead of:
        # client = anthropic.AsyncAnthropic(api_key="...")

        # Use:
        client = AsyncClaudeCode()

        response = await client.messages.create(
            model="sonnet",
            max_tokens=4096,
            system="You are helpful.",
            messages=[{"role": "user", "content": "Hello"}]
        )
    """

    def __init__(
        self,
        bridge_path: Optional[str] = None,
        working_directory: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
        stale_timeout_seconds: Optional[int] = None,
        **kwargs
    ):
        self._client = ClaudeCodeClient(
            bridge_path=bridge_path,
            timeout_seconds=timeout_seconds,
            stale_timeout_seconds=stale_timeout_seconds
        )
        self._working_directory = working_directory
        self.messages = ClaudeCodeMessages(self._client, working_directory=working_directory)
