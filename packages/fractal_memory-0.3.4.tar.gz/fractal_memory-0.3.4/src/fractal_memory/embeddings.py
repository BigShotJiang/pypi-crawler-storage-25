"""Embedding provider abstraction + local sentence-transformers implementation."""

from __future__ import annotations

import asyncio
import threading
from typing import Protocol, runtime_checkable


@runtime_checkable
class EmbeddingProvider(Protocol):
    async def embed(self, text: str) -> list[float]: ...
    async def embed_batch(self, texts: list[str]) -> list[list[float]]: ...

    @property
    def model_name(self) -> str: ...

    @property
    def dimension(self) -> int: ...


class LocalEmbeddingProvider:
    """sentence-transformers embedding provider with lazy model loading."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2") -> None:
        self._model_name = model_name
        self._model = None
        self._dimension: int | None = None
        self._load_lock = threading.Lock()  # Thread-safe model loading (Issue #41)

    def _load_model(self) -> None:
        if self._model is None:
            with self._load_lock:
                # Double-check after acquiring the lock
                if self._model is None:
                    from sentence_transformers import SentenceTransformer

                    self._model = SentenceTransformer(self._model_name)
                    self._dimension = getattr(
                        self._model,
                        "get_embedding_dimension",
                        self._model.get_sentence_embedding_dimension,
                    )()

    def _embed_sync(self, text: str) -> list[float]:
        self._load_model()
        vec = self._model.encode(text, normalize_embeddings=True)
        return vec.tolist()

    def _embed_batch_sync(self, texts: list[str]) -> list[list[float]]:
        self._load_model()
        vecs = self._model.encode(texts, normalize_embeddings=True)
        return [v.tolist() for v in vecs]

    async def embed(self, text: str) -> list[float]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._embed_sync, text)

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._embed_batch_sync, texts)

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def dimension(self) -> int:
        if self._dimension is None:
            self._load_model()
        if self._dimension is None:
            raise RuntimeError(
                "Embedding model failed to load — dimension is unavailable"
            )
        return self._dimension
