"""Sleep consolidation engine — runs at session_end as a registered hook."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from uuid import UUID, uuid4

import numpy as np

from fractal_memory._compat import utcnow
from fractal_memory.associations import AssociationNetwork
from fractal_memory.config import FractalConfig
from fractal_memory.domains import DomainManager
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.feedback import JudgeRating
from fractal_memory.lifecycle import LifecycleManager
from fractal_memory.llm import LLMProvider, LLMUnavailableError
from fractal_memory.models import Memory
from fractal_memory.scar import ScarTissueManager
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)

_MERGE_SYSTEM = (
    "You are a memory consolidation engine. You merge multiple related memories "
    "about the same topic into one unified memory. Preserve ALL nuance, exceptions, "
    "and conditions from every source memory. You MUST respond with valid JSON only "
    "— no explanation, no markdown."
)

_MERGE_USER_TEMPLATE = """\
Merge the following {n} memories about the same topic into ONE unified memory.

Source memories:
{memories_json}

Rules:
- Preserve ALL details from every source memory — nuance, exceptions, conditions.
- If sources disagree, note the disagreement explicitly.
- If sources have different contexts, preserve all contexts.
- The unified memory should be richer than any individual source.

Respond with this exact JSON structure:
{{
  "l0_tag": "<2 tokens max, category:subtag format>",
  "l1_label": "<10 tokens max, kebab-case>",
  "l2_summary": "<30 tokens max, one sentence>",
  "l3_full": "<150 tokens max, full unified context>",
  "contrast": "<what this memory is NOT, or null>"
}}\
"""


@dataclass
class MergeEvent:
    """Record of a memory merge operation."""

    merged_memory_id: UUID
    source_memory_ids: list[UUID]
    domain: str


@dataclass
class ConsolidationReport:
    """Summary of a consolidation run."""

    edges_strengthened: int = 0
    merges: list[MergeEvent] = field(default_factory=list)
    edges_decayed: int = 0
    scars_expired: int = 0
    freeloaders_found: int = 0
    domain_drift_suggestions: list[tuple[UUID, str, str]] = field(default_factory=list)


class ConsolidationEngine:
    """Sleep consolidation: merge, prune, downscale, expire scars, detect drift.

    Registered as a session_end hook via SessionManager.register_on_end_hook().
    Implements B-13 partial (merge + prune + proportional weight downscaling).
    """

    def __init__(
        self,
        storage: Storage,
        embeddings: EmbeddingProvider,
        llm: LLMProvider,
        associations: AssociationNetwork,
        scars: ScarTissueManager,
        lifecycle: LifecycleManager,
        domains: DomainManager,
        config: FractalConfig,
    ) -> None:
        self._storage = storage
        self._embeddings = embeddings
        self._llm = llm
        self._associations = associations
        self._scars = scars
        self._lifecycle = lifecycle
        self._domains = domains
        self._config = config
        # Set at session_end time by the hook
        self._session_memories: list[UUID] = []
        self._session_retrievals: list[dict] = []
        self._judge_ratings: list[JudgeRating] = []
        # Idempotency: track last session that ran consolidation
        self._current_session_id: UUID | None = None
        self._last_run_session_id: UUID | None = None
        self._last_run_report: ConsolidationReport | None = None

    def set_session_data(
        self,
        session_memories: list[UUID],
        session_retrievals: list[dict],
        judge_ratings: list[JudgeRating],
        session_id: UUID | None = None,
    ) -> None:
        """Called by the session_end hook to inject session data before run()."""
        self._session_memories = session_memories
        self._session_retrievals = session_retrievals
        self._judge_ratings = judge_ratings
        self._current_session_id = session_id

    async def run(self) -> ConsolidationReport:
        """Run the full consolidation pipeline.

        Order matters:
        1. Strengthen associations from co-retrieval patterns.
        2. Merge similar memories (LLM call per merge group).
        3. Slow-wave downscale (B-13 partial).
        4. Expire scars.
        5. Mark freeloaders.
        6. Suggest domain drift.

        Idempotent within a session — second call returns cached report.

        Returns:
            ConsolidationReport with counts of actions taken.
        """
        # Idempotency guard: skip if already ran for this session
        sid = getattr(self, "_current_session_id", None)
        if sid is not None and sid == self._last_run_session_id and self._last_run_report is not None:
            logger.debug("Consolidation: skipping duplicate run for session %s", sid)
            return self._last_run_report

        report = ConsolidationReport()
        logger.info("Consolidation: starting")

        report.edges_strengthened = await self._strengthen_associations()
        merges = await self._merge_similar()
        report.merges = merges
        report.edges_decayed = await self._slow_wave_downscale()
        report.scars_expired = await self._expire_scars()
        report.freeloaders_found = await self._prune_freeloaders()
        report.domain_drift_suggestions = await self._suggest_domain_drift()

        logger.info(
            "Consolidation complete: edges_strengthened=%d, merges=%d, "
            "edges_decayed=%d, scars_expired=%d, freeloaders=%d, drift_suggestions=%d",
            report.edges_strengthened,
            len(report.merges),
            report.edges_decayed,
            report.scars_expired,
            report.freeloaders_found,
            len(report.domain_drift_suggestions),
        )
        # Cache for idempotency
        if sid is not None:
            self._last_run_session_id = sid
            self._last_run_report = report
        return report

    # ------------------------------------------------------------------
    # Public delegates for maintenance (Phase 3)
    # ------------------------------------------------------------------

    async def prune_expired(self) -> int:
        """Prune memories consistently unused across sessions.

        Delegates to ``_prune_freeloaders()`` which increments miss counts
        for zero-rated memories based on LLM judge ratings.

        Returns:
            Count of memories pruned (miss_count incremented).

        Added in Phase 3 for maintenance scheduling.
        See also: ``_prune_freeloaders``.
        """
        return await self._prune_freeloaders()

    async def merge_duplicates(self, similarity_threshold: float) -> int:
        """Merge highly similar memories across all domains.

        Delegates to ``_merge_similar()`` with a threshold override.

        Args:
            similarity_threshold: Cosine similarity above which memories
                are considered duplicates. Temporarily overrides
                ``config.merge_similarity_threshold``.

        Returns:
            Count of merge events performed.

        Added in Phase 3 for maintenance scheduling.
        See also: ``_merge_similar``.
        """
        import dataclasses
        original_config = self._config
        self._config = dataclasses.replace(
            self._config, merge_similarity_threshold=similarity_threshold
        )
        try:
            events = await self._merge_similar()
        finally:
            self._config = original_config
        return len(events)

    # ------------------------------------------------------------------
    # Step 1: Strengthen associations
    # ------------------------------------------------------------------

    async def _strengthen_associations(self) -> int:
        """Bake session co-retrieval patterns into the association network."""
        count = 0
        for retrieval in self._session_retrievals:
            l2_ids = retrieval.get("l2_ids", [])
            l3_ids = retrieval.get("l3_ids", [])
            if l2_ids and len(l2_ids) >= 2:
                await self._associations.on_co_retrieval(l2_ids, zoom_level=2)
                count += len(l2_ids)
            if l3_ids and len(l3_ids) >= 2:
                await self._associations.on_co_retrieval(l3_ids, zoom_level=3)
                count += len(l3_ids)
        return count

    # ------------------------------------------------------------------
    # Step 2: Merge similar memories
    # ------------------------------------------------------------------

    async def _merge_similar(self) -> list[MergeEvent]:
        """Find and merge highly similar memories within each domain."""
        all_domains_raw = await self._storage.list_domains()
        events: list[MergeEvent] = []

        for domain_name, _count, _last_updated in all_domains_raw:
            domain_memories = await self._storage.get_memories_by_domain(domain_name)
            if len(domain_memories) < 2:
                continue

            # Find merge candidates: cosine similarity > merge_similarity_threshold
            merge_groups = self._find_merge_groups(domain_memories)

            for group in merge_groups:
                if len(group) < 2:
                    continue
                event = await self._merge_group(group, domain_name)
                if event:
                    events.append(event)

        return events

    def _find_merge_groups(
        self, memories: list[Memory]
    ) -> list[list[Memory]]:
        """Find groups of memories with cosine similarity > threshold.

        Uses transitive grouping: if A~B and B~C, all three are in one group.
        Cross-domain merging is prohibited (caller ensures same domain).
        """
        threshold = self._config.merge_similarity_threshold
        n = len(memories)
        if n < 2:
            return []

        vecs = np.array([m.embedding for m in memories], dtype=np.float32)
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1.0, norms)
        normed = vecs / norms
        sim_matrix = normed @ normed.T

        # Union-find for transitive grouping
        parent = list(range(n))

        def find(x: int) -> int:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x: int, y: int) -> None:
            parent[find(x)] = find(y)

        for i in range(n):
            for j in range(i + 1, n):
                if sim_matrix[i, j] >= threshold:
                    union(i, j)

        # Build groups by root
        groups_by_root: dict[int, list[Memory]] = {}
        for i, mem in enumerate(memories):
            root = find(i)
            groups_by_root.setdefault(root, []).append(mem)

        # Only return groups with 2+ members
        return [g for g in groups_by_root.values() if len(g) >= 2]

    async def _merge_group(
        self, group: list[Memory], domain: str
    ) -> MergeEvent | None:
        """Merge a group of similar memories into one unified memory using LLM."""
        memories_json = json.dumps(
            [
                {
                    "l2_summary": m.l2_summary,
                    "l3_full": m.l3_full,
                    "domain": m.domain,
                    "created_at": m.created_at.isoformat(),
                }
                for m in group
            ],
            indent=2,
        )
        prompt = _MERGE_USER_TEMPLATE.format(
            n=len(group), memories_json=memories_json
        )

        try:
            response = await self._llm.complete(
                prompt=prompt, system=_MERGE_SYSTEM, max_tokens=500
            )
        except LLMUnavailableError:
            logger.warning("LLM unavailable — skipping merge of %d memories", len(group))
            return None

        zoom = self._parse_merge_response(response, group)
        if zoom is None:
            logger.warning("Failed to parse merge response — keeping source memories")
            return None

        # Validate: merged content should not be shorter than any individual source
        if len(zoom.get("l3_full", "")) < min(len(m.l3_full) for m in group):
            logger.warning("Merged content shorter than sources — skipping merge")
            return None

        # Compute merged embedding
        merged_text = zoom["l3_full"]
        merged_embedding = await self._embeddings.embed(merged_text)

        # Consolidated metadata
        now = utcnow()
        merged_id = uuid4()
        merged_memory = Memory(
            id=merged_id,
            domain=domain,
            created_at=min(m.created_at for m in group),
            updated_at=now,
            context={},
            l0_tag=zoom.get("l0_tag", group[0].l0_tag),
            l1_label=zoom.get("l1_label", group[0].l1_label),
            l2_summary=zoom.get("l2_summary", group[0].l2_summary),
            l3_full=zoom.get("l3_full", group[0].l3_full),
            l4_raw="\n---\n".join(m.l4_raw for m in group),
            embedding=merged_embedding,
            embedding_model=getattr(self._embeddings, "model_name", "unknown"),
            intensity=max(m.intensity for m in group),
            retrieval_count=sum(m.retrieval_count for m in group),
            miss_count=sum(m.miss_count for m in group),
            lifecycle=max(
                (m.lifecycle for m in group),
                key=lambda lc: ["probation", "confirmed", "permanent", "safety_critical"].index(str(lc)),
            ),
            contrast=zoom.get("contrast"),
            vitality=max(m.vitality for m in group),
        )

        # Collect edges to transfer before committing anything
        edges_to_transfer: list[tuple[UUID, float, float, list[float] | None]] = []
        group_ids = {m.id for m in group}
        for source_mem in group:
            source_edges = await self._storage.get_associations(source_mem.id)
            for neighbor_id, weight, trail_weight, centroid in source_edges:
                if neighbor_id in group_ids:
                    continue  # skip intra-group edges
                edges_to_transfer.append((neighbor_id, weight, trail_weight, centroid))

        # Execute atomically: store merged, transfer edges, delete sources
        try:
            # Store merged memory
            await self._storage.store_memory(merged_memory)

            # Transfer edges (keep stronger weight for shared targets)
            best_edges: dict[UUID, tuple[float, float, list[float] | None]] = {}
            for neighbor_id, weight, trail_weight, centroid in edges_to_transfer:
                prev = best_edges.get(neighbor_id)
                if prev is None or prev[0] < weight:
                    best_edges[neighbor_id] = (weight, trail_weight, centroid)

            for neighbor_id, (weight, trail_weight, centroid) in best_edges.items():
                await self._storage.store_association(
                    source_id=merged_id,
                    target_id=neighbor_id,
                    weight=weight,
                    trail_weight=trail_weight,
                    trail_context_centroid=centroid,
                )

            # Delete source memories (also cleans their association edges via delete_memory)
            source_ids = [m.id for m in group]
            for mid in source_ids:
                await self._storage.delete_memory(mid)

        except Exception:
            # On failure, roll back the merged memory via public API (Issue #45)
            try:
                await self._storage.rollback_merge(merged_id)
            except Exception:
                pass
            logger.exception("Merge rollback executed for group in domain=%s", domain)
            return None

        logger.info(
            "Merged %d memories into %s (domain=%s)", len(group), merged_id, domain
        )
        return MergeEvent(
            merged_memory_id=merged_id,
            source_memory_ids=source_ids,
            domain=domain,
        )

    def _parse_merge_response(
        self, response: str, group: list[Memory]
    ) -> dict | None:
        """Parse merge LLM response. Returns zoom dict or None on failure."""
        import re

        cleaned = response.strip()
        # Strip markdown fences
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", cleaned)
            cleaned = re.sub(r"\n?```$", "", cleaned)
            cleaned = cleaned.strip()

        try:
            data = json.loads(cleaned)
            if isinstance(data, dict) and "l3_full" in data:
                return data
        except (json.JSONDecodeError, ValueError):
            pass

        return None

    # ------------------------------------------------------------------
    # Step 3: Slow-wave homeostasis (B-13 partial)
    # ------------------------------------------------------------------

    async def _slow_wave_downscale(self) -> int:
        """Proportional weight reduction on all edges. Weak edges die."""
        return await self._associations.decay_all_weights()

    # ------------------------------------------------------------------
    # Step 4: Expire scars
    # ------------------------------------------------------------------

    async def _expire_scars(self) -> int:
        """Age and expire scar tissue."""
        return await self._scars.expire_scars()

    # ------------------------------------------------------------------
    # Step 5: Mark freeloaders
    # ------------------------------------------------------------------

    async def _prune_freeloaders(self) -> int:
        """Increment miss_count for memories consistently unused this session.

        Uses LLM judge ratings: rating 0 = clearly unused.
        Does NOT delete memories — lifecycle management handles that.
        """
        zero_rated = {r.memory_id for r in self._judge_ratings if r.rating == 0}
        count = 0
        for mid in zero_rated:
            mem = await self._storage.get_memory(mid)
            if mem is None:
                continue
            await self._lifecycle.on_memory_missed(mem)
            count += 1
        return count

    # ------------------------------------------------------------------
    # Step 6: Suggest domain drift
    # ------------------------------------------------------------------

    async def _suggest_domain_drift(
        self,
    ) -> list[tuple[UUID, str, str]]:
        """Check for memories that should change domain based on association topology.

        Suggestions are logged but NOT automatically applied in Phase 2.

        Returns:
            list of (memory_id, current_domain, suggested_domain) tuples.
        """
        suggestions: list[tuple[UUID, str, str]] = []

        # Build domain lookup with a single query instead of O(N) per domain (Issue #47)
        domain_lookup: dict[UUID, str] = {}
        all_pairs = await self._storage.get_all_memory_domains()
        for mid_str, domain_name in all_pairs:
            domain_lookup[UUID(mid_str)] = domain_name

        for memory_id, current_domain in list(domain_lookup.items()):
            edges = await self._associations.get_edges(memory_id)
            if not edges:
                continue

            suggested = await self._domains.suggest_domain_from_associations(
                memory_id=memory_id,
                association_edges=edges,
                current_domain=current_domain,
                domain_lookup=domain_lookup,
            )
            if suggested and suggested != current_domain:
                suggestions.append((memory_id, current_domain, suggested))
                logger.info(
                    "Domain drift suggestion: %s %s -> %s",
                    memory_id, current_domain, suggested,
                )

        return suggestions
