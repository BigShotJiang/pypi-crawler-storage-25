"""Dashboard FastAPI application — localhost-only diagnostic interface."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from uuid import UUID

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

logger = logging.getLogger(__name__)

_STATIC_DIR = Path(__file__).parent / "static"
_TEMPLATES_DIR = Path(__file__).parent / "templates"
_DOMAIN_PATTERN = re.compile(r"^[a-zA-Z0-9_\-\.]{1,100}$")


class DashboardApp:
    """Diagnostic dashboard backed by a FractalMemory instance.

    Localhost only (127.0.0.1). No authentication. All data sourced from
    the FractalMemory public API — dashboard never touches storage directly.
    """

    def __init__(self, fractal_memory: object) -> None:
        self._fm = fractal_memory

    def create_app(self) -> FastAPI:
        """Create and configure the FastAPI application."""
        app = FastAPI(
            title="Fractal Memory Dashboard",
            description="Diagnostic dashboard for the Fractal Memory organism",
            docs_url=None,  # Disable swagger UI (localhost tool only)
        )

        # Static files
        if _STATIC_DIR.exists():
            app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")

        # Jinja2 templates
        templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))

        # ----------------------------------------------------------------
        # HTML page routes
        # ----------------------------------------------------------------

        @app.get("/", response_class=HTMLResponse)
        async def page_home(request: Request) -> HTMLResponse:
            """Home — Domain Organs view."""
            return templates.TemplateResponse(
                request, "index.html", {"active": "home"}
            )

        @app.get("/brain", response_class=HTMLResponse)
        async def page_brain(request: Request) -> HTMLResponse:
            """Neural Network — association force graph."""
            return templates.TemplateResponse(
                request, "brain.html", {"active": "brain"}
            )

        @app.get("/lifecycle", response_class=HTMLResponse)
        async def page_lifecycle(request: Request) -> HTMLResponse:
            """Lifecycle Chrysalis — maturation rings."""
            return templates.TemplateResponse(
                request, "lifecycle.html", {"active": "lifecycle"}
            )

        @app.get("/pipeline", response_class=HTMLResponse)
        async def page_pipeline(request: Request) -> HTMLResponse:
            """Processing Pipeline — from raw input to stored memory."""
            return templates.TemplateResponse(
                request, "pipeline.html", {"active": "pipeline"}
            )

        @app.get("/morphogens", response_class=HTMLResponse)
        async def page_morphogens(request: Request) -> HTMLResponse:
            """Morphogen Landscape — adaptive response curves and signal trajectories."""
            return templates.TemplateResponse(
                request, "morphogens.html", {"active": "morphogens"}
            )

        @app.get("/organism", response_class=HTMLResponse)
        async def page_organism(request: Request) -> HTMLResponse:
            """Organism Health — self-model, domain maturity, parameter drift."""
            return templates.TemplateResponse(
                request, "organism.html", {"active": "organism"}
            )

        @app.get("/dreaming", response_class=HTMLResponse)
        async def page_dreaming(request: Request) -> HTMLResponse:
            """Dream Cycles — slow-wave consolidation and REM recombination."""
            return templates.TemplateResponse(
                request, "dreaming.html", {"active": "dreaming"}
            )

        @app.get("/apoptosis", response_class=HTMLResponse)
        async def page_apoptosis(request: Request) -> HTMLResponse:
            """Apoptosis — pruned memories, triggers, and fragments."""
            return templates.TemplateResponse(
                request, "apoptosis.html", {"active": "apoptosis"}
            )

        @app.get("/folding", response_class=HTMLResponse)
        async def page_folding(request: Request) -> HTMLResponse:
            """Dimensional Folding — operational regime and anomaly unfolds."""
            return templates.TemplateResponse(
                request, "folding.html", {"active": "folding"}
            )

        @app.get("/niche", response_class=HTMLResponse)
        async def page_niche(request: Request) -> HTMLResponse:
            """Niche Construction — domain clusters, cohesion, and Louvain proposals."""
            return templates.TemplateResponse(
                request, "niche.html", {"active": "niche"}
            )

        @app.get("/cascade", response_class=HTMLResponse)
        async def page_cascade(request: Request) -> HTMLResponse:
            """Cascade Detector — EKF state, circuit breaker, cascade warnings."""
            return templates.TemplateResponse(
                request, "cascade.html", {"active": "cascade"}
            )

        @app.get("/api/morphogen-trajectory")
        async def api_morphogen_trajectory() -> JSONResponse:
            """Time series of morphogen signals from session history."""
            data = await self._get_morphogen_trajectory()
            return JSONResponse(data)

        @app.get("/api/response-curves")
        async def api_response_curves() -> JSONResponse:
            """Current sigmoid parameters for all response curves."""
            data = await self._get_response_curves()
            return JSONResponse(data)

        @app.get("/api/system-state")
        async def api_system_state() -> JSONResponse:
            """Current system state, morphogen values, and bandit arm stats."""
            data = await self._get_system_state()
            return JSONResponse(data)

        @app.get("/api/scars")
        async def api_scars() -> JSONResponse:
            """Scar tissue + golden seam data for Kintsugi view."""
            data = await self._get_scars_data()
            return JSONResponse(data)

        @app.get("/api/correction-timeline")
        async def api_correction_timeline() -> JSONResponse:
            """Per-correction event log for timeline."""
            data = await self._get_correction_timeline()
            return JSONResponse(data)

        @app.get("/api/health-snapshot")
        async def api_health_snapshot() -> JSONResponse:
            """Full organism health snapshot from self-model."""
            data = await self._get_health_snapshot()
            return JSONResponse(data)

        @app.get("/api/domain-maturity")
        async def api_domain_maturity() -> JSONResponse:
            """Maturity classification per domain."""
            data = await self._get_domain_maturity()
            return JSONResponse(data)

        @app.get("/api/explain-last")
        async def api_explain_last() -> JSONResponse:
            """Explanation of the last retrieval."""
            data = await self._get_explain_last()
            return JSONResponse(data)

        @app.get("/api/dream-stats")
        async def api_dream_stats() -> JSONResponse:
            """Last dream cycle stats + session totals."""
            data = await self._get_dream_stats()
            return JSONResponse(data)

        @app.get("/api/dream-history")
        async def api_dream_history() -> JSONResponse:
            """Per-session dream cycle history (last 20)."""
            data = await self._get_dream_history()
            return JSONResponse(data)

        @app.get("/api/apoptosis-stats")
        async def api_apoptosis_stats() -> JSONResponse:
            """Pruning events, trigger distribution, and vitality data."""
            data = await self._get_apoptosis_stats()
            return JSONResponse(data)

        @app.get("/api/folding-state")
        async def api_folding_state() -> JSONResponse:
            """Current regime, active subsystems, folded stats, anomaly history."""
            data = await self._get_folding_state()
            return JSONResponse(data)

        @app.get("/api/niche-health")
        async def api_niche_health() -> JSONResponse:
            """Per-domain niche health: cohesion, separation, stability."""
            data = await self._get_niche_health()
            return JSONResponse(data)

        @app.get("/api/niche-proposals")
        async def api_niche_proposals() -> JSONResponse:
            """Pending Louvain cluster proposals."""
            data = await self._get_niche_proposals()
            return JSONResponse(data)

        @app.get("/api/cascade-state")
        async def api_cascade_state() -> JSONResponse:
            """EKF hidden state, covariance, warnings, circuit breaker status."""
            data = await self._get_cascade_state()
            return JSONResponse(data)

        @app.get("/api/cascade-history")
        async def api_cascade_history() -> JSONResponse:
            """Historical cascade warnings."""
            data = await self._get_cascade_history()
            return JSONResponse(data)

        @app.get("/feedback", response_class=HTMLResponse)
        async def page_feedback(request: Request) -> HTMLResponse:
            return templates.TemplateResponse(request, "feedback.html", {"active": "feedback"})

        @app.get("/buffer", response_class=HTMLResponse)
        async def page_buffer(request: Request) -> HTMLResponse:
            return templates.TemplateResponse(request, "buffer.html", {"active": "buffer"})

        @app.get("/maintenance", response_class=HTMLResponse)
        async def page_maintenance(request: Request) -> HTMLResponse:
            return templates.TemplateResponse(request, "maintenance.html", {"active": "maintenance"})

        @app.get("/config", response_class=HTMLResponse)
        async def page_config(request: Request) -> HTMLResponse:
            return templates.TemplateResponse(request, "config.html", {"active": "config"})

        @app.get("/bandits", response_class=HTMLResponse)
        async def page_bandits(request: Request) -> HTMLResponse:
            return templates.TemplateResponse(request, "bandits.html", {"active": "bandits"})

        @app.get("/states", response_class=HTMLResponse)
        async def page_states(request: Request) -> HTMLResponse:
            return templates.TemplateResponse(request, "states.html", {"active": "states"})

        @app.get("/consolidation", response_class=HTMLResponse)
        async def page_consolidation(request: Request) -> HTMLResponse:
            return templates.TemplateResponse(request, "consolidation.html", {"active": "consolidation"})

        @app.get("/guide", response_class=HTMLResponse)
        async def page_guide(request: Request) -> HTMLResponse:
            """Comprehensive guide to every dashboard page."""
            return templates.TemplateResponse(request, "guide.html", {"active": "guide"})

        @app.get("/api/feedback-state")
        async def api_feedback_state() -> JSONResponse:
            return JSONResponse(await self._get_feedback_state())

        @app.get("/api/feedback-history")
        async def api_feedback_history() -> JSONResponse:
            return JSONResponse(await self._get_feedback_history())

        @app.get("/api/buffer-state")
        async def api_buffer_state() -> JSONResponse:
            return JSONResponse(await self._get_buffer_state())

        @app.get("/api/maintenance-state")
        async def api_maintenance_state() -> JSONResponse:
            return JSONResponse(await self._get_maintenance_state())

        @app.get("/api/maintenance-history")
        async def api_maintenance_history() -> JSONResponse:
            return JSONResponse(await self._get_maintenance_history())

        @app.get("/api/config-state")
        async def api_config_state() -> JSONResponse:
            return JSONResponse(await self._get_config_state())

        @app.get("/api/bandits-state")
        async def api_bandits_state() -> JSONResponse:
            return JSONResponse(await self._get_bandits_state())

        @app.get("/api/bandits-history")
        async def api_bandits_history() -> JSONResponse:
            return JSONResponse(await self._get_bandits_history())

        @app.get("/api/states-data")
        async def api_states_data() -> JSONResponse:
            return JSONResponse(await self._get_states_data())

        @app.get("/api/states-history")
        async def api_states_history() -> JSONResponse:
            return JSONResponse(await self._get_states_history())

        @app.get("/api/consolidation-state")
        async def api_consolidation_state() -> JSONResponse:
            return JSONResponse(await self._get_consolidation_state())

        @app.get("/api/consolidation-history")
        async def api_consolidation_history() -> JSONResponse:
            return JSONResponse(await self._get_consolidation_history())

        @app.get("/domain/{domain}", response_class=HTMLResponse)
        async def page_domain_detail(request: Request, domain: str) -> HTMLResponse:
            """Domain detail — memory list with stats."""
            if not _DOMAIN_PATTERN.match(domain):
                raise HTTPException(status_code=400, detail="Invalid domain name")
            memories = await self._fm._storage.get_memories_by_domain(domain)  # type: ignore[union-attr]
            return templates.TemplateResponse(
                request, "domain_detail.html", {"active": "", "domain": domain, "memories": memories}
            )

        @app.get("/memory/{memory_id}", response_class=HTMLResponse)
        async def page_memory_detail(request: Request, memory_id: str) -> HTMLResponse:
            """Memory detail — zoom levels, metadata, associations."""
            try:
                mid = UUID(memory_id)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid memory ID format")
            mem = await self._fm.get(mid)  # type: ignore[union-attr]
            if mem is None:
                raise HTTPException(status_code=404, detail="Memory not found")
            edges = await self._fm._associations.get_edges(mem.id)  # type: ignore[union-attr]
            edge_list = [{"source": str(mem.id), "target": str(tid), "weight": w} for tid, w in edges]
            return templates.TemplateResponse(
                request, "memory_detail.html", {"active": "", "memory": mem, "edges": edge_list}
            )

        # ----------------------------------------------------------------
        # JSON API endpoints
        # ----------------------------------------------------------------

        @app.get("/api/stats")
        async def api_stats() -> JSONResponse:
            """Full system stats."""
            data = await self._fm.get_stats()  # type: ignore[union-attr]
            return JSONResponse(data)

        @app.get("/api/vitals")
        async def api_vitals() -> JSONResponse:
            """Real-time vital signs for HTMX polling."""
            data = await self._get_vital_signs()
            return JSONResponse(data)

        @app.get("/api/associations/{domain}")
        async def api_associations(domain: str) -> JSONResponse:
            """Association graph data (nodes + edges) for D3.js."""
            if not _DOMAIN_PATTERN.match(domain):
                raise HTTPException(status_code=400, detail="Invalid domain name")
            data = await self._get_association_graph(domain)
            return JSONResponse(data)

        @app.get("/api/lifecycle-distribution")
        async def api_lifecycle() -> JSONResponse:
            """Lifecycle counts per status."""
            data = await self._get_lifecycle_distribution()
            return JSONResponse(data)

        @app.get("/api/pipeline-stats")
        async def api_pipeline() -> JSONResponse:
            """Gate throughput, latency, waiting room size."""
            data = await self._get_pipeline_stats()
            return JSONResponse(data)

        @app.get("/api/domain-health")
        async def api_domain_health() -> JSONResponse:
            """Per-domain health metrics."""
            data = await self._get_domain_health()
            return JSONResponse(data)

        @app.get("/api/domain/{domain}")
        async def api_domain_detail(domain: str) -> JSONResponse:
            """Domain detail — memory list and stats."""
            if not _DOMAIN_PATTERN.match(domain):
                raise HTTPException(status_code=400, detail="Invalid domain name")
            memories = await self._fm._storage.get_memories_by_domain(domain)  # type: ignore[union-attr]
            return JSONResponse({
                "domain": domain,
                "memories": [
                    {
                        "id": str(m.id),
                        "l0_tag": m.l0_tag,
                        "l1_label": m.l1_label,
                        "l2_summary": m.l2_summary,
                        "lifecycle": str(m.lifecycle),
                        "intensity": m.intensity,
                        "retrieval_count": m.retrieval_count,
                        "created_at": m.created_at.isoformat(),
                    }
                    for m in memories
                ],
            })

        @app.get("/api/memory/{memory_id}")
        async def api_memory_detail(memory_id: str) -> JSONResponse:
            """Memory detail — zoom levels, metadata, edges."""
            try:
                mid = UUID(memory_id)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid memory ID format")
            mem = await self._fm.get(mid)  # type: ignore[union-attr]
            if mem is None:
                raise HTTPException(status_code=404, detail="Memory not found")
            edges = await self._fm._associations.get_edges(mem.id)  # type: ignore[union-attr]
            return JSONResponse({
                "id": str(mem.id),
                "domain": mem.domain,
                "l0_tag": mem.l0_tag,
                "l1_label": mem.l1_label,
                "l2_summary": mem.l2_summary,
                "l3_full": mem.l3_full,
                "lifecycle": str(mem.lifecycle),
                "intensity": mem.intensity,
                "retrieval_count": mem.retrieval_count,
                "created_at": mem.created_at.isoformat(),
                "updated_at": mem.updated_at.isoformat(),
                "edges": [
                    {"target_id": str(tid), "weight": round(w, 4)}
                    for tid, w in edges
                ],
            })

        return app

    # ------------------------------------------------------------------
    # Data methods
    # ------------------------------------------------------------------

    async def _get_vital_signs(self) -> dict:
        """Compute real-time vital signs.

        Heart rate is sourced from the session_activity SQLite table so the
        dashboard works even when running in a different OS process than the
        MCP server. Falls back to the last completed session if no live row
        exists or if the live row is stale (>60s since last update).
        """
        from datetime import datetime, timezone

        stats = await self._fm.get_stats()  # type: ignore[union-attr]
        overall = stats.get("overall", {})
        assoc = stats.get("associations", {})
        lifecycle = stats.get("lifecycle", {})

        total = overall.get("total_memories", 0)
        budget = self._fm._config.memory_token_budget  # type: ignore[union-attr]

        # -- Heartbeat: read from session_activity (cross-process safe) --
        # Aggregate across all active sessions so the dashboard reflects
        # every running MCP server process, not just the most recent one.
        heart_rate = 0
        session_live = False
        active_domain = None
        active_sessions_count = 0

        all_activity = await self._fm._storage.get_all_active_session_activity()  # type: ignore[union-attr]
        if all_activity:
            session_live = True
            active_sessions_count = len(all_activity)
            active_domain = all_activity[0].get("domain")  # most recent
            for activity in all_activity:
                heart_rate += activity.get("stores", 0) + activity.get("retrievals", 0)

        if not session_live:
            # Fallback: show ops from the most recent completed session
            summaries = await self._fm._storage.get_session_summaries(limit=1)  # type: ignore[union-attr]
            if summaries:
                s = summaries[0]
                heart_rate = s.get("store_count", 0) + s.get("retrieve_count", 0)

        return {
            "heart_rate": heart_rate,
            "session_live": session_live,
            "active_domain": active_domain,
            "active_sessions": active_sessions_count,
            "pressure": round(total / max(budget, 1) * 100, 1),
            "temperature": assoc.get("avg_weight", 0.0),
            "total_memories": total,
            "total_sessions": overall.get("total_sessions", 0),
            "active_scars": stats.get("scars", {}).get("active_count", 0),
            "association_edges": assoc.get("edge_count", 0),
            "lifecycle": lifecycle,
            "domains": [d["name"] for d in stats.get("domains", [])],
        }

    async def _get_association_graph(self, domain: str) -> dict:
        """Return D3.js-ready graph data for a domain."""
        import math

        memories = await self._fm._storage.get_memories_by_domain(domain)  # type: ignore[union-attr]
        memory_ids = {m.id for m in memories}

        nodes = []
        for i, m in enumerate(memories):
            angle = 2 * math.pi * i / max(len(memories), 1)
            r = 300
            nodes.append({
                "id": str(m.id),
                "label": m.l1_label,
                "lifecycle": str(m.lifecycle),
                "intensity": m.intensity,
                "retrieval_count": m.retrieval_count,
                "x": r * math.cos(angle) + 400,
                "y": r * math.sin(angle) + 300,
            })

        edges = []
        all_edges = await self._fm._storage.get_all_associations()  # type: ignore[union-attr]
        for src, tgt, weight in all_edges:
            if src in memory_ids and tgt in memory_ids:
                edges.append({
                    "source": str(src),
                    "target": str(tgt),
                    "weight": round(weight, 3),
                })

        return {"nodes": nodes, "edges": edges}

    async def _get_lifecycle_distribution(self) -> dict:
        """Return lifecycle counts and rates."""
        counts = await self._fm._storage.get_lifecycle_counts()  # type: ignore[union-attr]
        total = sum(counts.values()) or 1
        probation = counts.get("probation", 0)
        confirmed = counts.get("confirmed", 0)
        permanent = counts.get("permanent", 0)
        safety_critical = counts.get("safety_critical", 0)

        return {
            "probation": probation,
            "confirmed": confirmed,
            "permanent": permanent,
            "safety_critical": safety_critical,
            "total": total,
            "promotion_rate": round((confirmed + permanent) / total * 100, 1),
            "pruning_rate": round(probation / total * 100, 1),
        }

    async def _get_pipeline_stats(self) -> dict:
        """Return gate and processing statistics via public storage API."""
        # Reuse get_stats() which is already proven to work for vitals.
        stats = await self._fm.get_stats()  # type: ignore[union-attr]
        overall = stats.get("overall", {})
        total_memories = overall.get("total_memories", 0)
        total_sessions = overall.get("total_sessions", 0)

        # Recent memories from already-working stats path.
        recent_raw = stats.get("recent_stores", [])
        recent = [
            {
                "id": r.get("id", ""),
                "domain": r.get("domain", ""),
                "l1_label": r.get("l1_label", ""),
                "l2_summary": "",  # not in recent_stores; fetched below
                "lifecycle": r.get("lifecycle", "probation"),
                "intensity": 0.0,
                "created_at": (r.get("created_at") or "")[:19].replace("T", " "),
            }
            for r in recent_raw
        ]

        # Waiting room via direct SQL (only safe path — no public API method).
        waiting_room_count = 0
        waiting_room_entries: list[dict] = []
        conn = getattr(getattr(self._fm, "_storage", None), "_conn", None)
        if conn:
            try:
                async with conn.execute("SELECT COUNT(*) FROM waiting_room") as cur:
                    row = await cur.fetchone()
                    waiting_room_count = row[0] if row else 0
                async with conn.execute(
                    "SELECT id, content, domain, created_at, sessions_elapsed "
                    "FROM waiting_room ORDER BY created_at DESC LIMIT 20"
                ) as cur:
                    async for row in cur:
                        waiting_room_entries.append({
                            "id": row[0],
                            "preview": (row[1] or "")[:120],
                            "domain": row[2] or "—",
                            "created_at": (row[3] or "")[:19].replace("T", " "),
                            "sessions_elapsed": row[4],
                        })
            except Exception:
                logger.debug("Waiting room query failed", exc_info=True)

        cfg = self._fm._config  # type: ignore[union-attr]
        gate_signal_count = cfg.gate_signal_count
        pioneer_mode = gate_signal_count == 1

        return {
            "waiting_room_size": waiting_room_count,
            "waiting_room_entries": waiting_room_entries,
            "gate_signal_count": gate_signal_count,
            "pioneer_mode": pioneer_mode,
            "top_l1": cfg.top_l1,
            "top_l2": cfg.top_l2,
            "top_l3": cfg.top_l3,
            "total_memories": total_memories,
            "total_sessions": total_sessions,
            "recent_memories": recent,
        }

    async def _get_domain_health(self) -> dict:
        """Return per-domain health metrics."""
        domains_stats = await self._fm._domain_manager.list_domains_with_stats()  # type: ignore[union-attr]
        return {
            "domains": [
                {
                    "name": ds.name,
                    "memory_count": ds.memory_count,
                    "session_count": ds.session_count,
                    "avg_internal_edge_weight": round(ds.avg_internal_edge_weight, 3),
                    "edge_count": ds.edge_count,
                }
                for ds in domains_stats
            ]
        }

    async def _get_morphogen_trajectory(self) -> dict:
        """Time series of morphogen signals from session history."""
        points = []
        try:
            rows = await self._fm._storage.get_morphogen_history()  # type: ignore[union-attr]
            for i, row in enumerate(rows):
                if row:
                    points.append({
                        "session": i + 1,
                        "information_richness": float(row.get("information_richness", 0.5)),
                        "retrieval_pressure": float(row.get("retrieval_pressure", 0.5)),
                        "domain_density": float(row.get("domain_density", 0.5)),
                    })
        except Exception:
            logger.debug("get_morphogen_history failed", exc_info=True)
        return {"trajectory": points}

    async def _get_response_curves(self) -> dict:
        """Current sigmoid parameters for all 8 response curves."""
        import numpy as np

        curves = []
        try:
            morphogen_field = getattr(self._fm, "_morphogens", None)
            if morphogen_field is not None:
                for curve in morphogen_field.curves:
                    history = list(morphogen_field._curve_history.get(curve.name, []))
                    midpoints = [h[0] for h in history[-10:]]
                    steepnesses = [h[1] for h in history[-10:]]
                    midpoint_var = float(np.var(midpoints)) if len(midpoints) >= 2 else 1.0
                    steepness_var = float(np.var(steepnesses)) if len(steepnesses) >= 2 else 1.0
                    curves.append({
                        "name": curve.name,
                        "midpoint": round(curve.midpoint, 4),
                        "steepness": round(curve.steepness, 4),
                        "base_value": round(curve.base_value, 4),
                        "min_value": curve.min_value,
                        "max_value": curve.max_value,
                        "morphogen_weights": curve.morphogen_weights,
                        "midpoint_variance": round(midpoint_var, 6),
                        "steepness_variance": round(steepness_var, 4),
                        "converged": midpoint_var < 0.01 and steepness_var < 0.5,
                    })
        except Exception:
            logger.debug("_get_response_curves failed", exc_info=True)
        converged_count = sum(1 for c in curves if c["converged"])
        return {
            "curves": curves,
            "total": len(curves),
            "converged_count": converged_count,
            "all_converged": converged_count == len(curves) and len(curves) > 0,
        }

    async def _get_system_state(self) -> dict:
        """Current system state, morphogen values, and bandit arm stats."""
        state_str = "flow"
        morphogens: dict = {}
        bandit_stats: dict = {}

        try:
            states_mgr = getattr(self._fm, "_states", None)
            if states_mgr is not None:
                state_str = states_mgr.current_state_str
        except Exception:
            logger.debug("_get_system_state: states failed", exc_info=True)

        try:
            morph_field = getattr(self._fm, "_morphogens", None)
            if morph_field is not None and morph_field.last_morphogens is not None:
                ms = morph_field.last_morphogens
                morphogens = {
                    "information_richness": round(ms.information_richness, 4),
                    "retrieval_pressure": round(ms.retrieval_pressure, 4),
                    "domain_density": round(ms.domain_density, 4),
                }
        except Exception:
            logger.debug("_get_system_state: morphogens failed", exc_info=True)

        try:
            bandits = getattr(self._fm, "_bandits", None)
            if bandits is not None:
                bandit_stats = bandits.get_arm_stats()
        except Exception:
            logger.debug("_get_system_state: bandits failed", exc_info=True)

        return {
            "state": state_str,
            "morphogens": morphogens,
            "bandit_stats": bandit_stats,
        }

    async def _get_scars_data(self) -> dict:
        """Scar tissue + golden seam data for Kintsugi view."""
        scars: list[dict] = []
        try:
            scar_rows = await self._fm._storage.get_active_scars()  # type: ignore[union-attr]
            for row in scar_rows:
                # get_active_scars() returns tuples: (id, pattern_embedding, memory_id, reason, ttl, elapsed)
                if isinstance(row, (list, tuple)) and len(row) >= 6:
                    scar_id, _emb, _mem_id, reason, ttl_sessions, sessions_elapsed = row[:6]
                    scars.append({
                        "id": str(scar_id),
                        "created_at": "",
                        "reason": reason,
                        "ttl_sessions": ttl_sessions,
                        "sessions_elapsed": sessions_elapsed,
                        "suppressed_count": 0,
                    })
                elif isinstance(row, dict):
                    scars.append({
                        "id": str(row.get("id", "")),
                        "created_at": row.get("created_at", ""),
                        "reason": row.get("reason", ""),
                        "ttl_sessions": row.get("ttl_sessions", 0),
                        "sessions_elapsed": row.get("sessions_elapsed", 0),
                        "suppressed_count": row.get("suppressed_count", 0),
                    })
        except Exception:
            logger.debug("get_active_scars failed", exc_info=True)

        return {
            "scars": scars,
            "total_scars": len(scars),
        }

    async def _get_correction_timeline(self) -> dict:
        """Per-correction event log for timeline."""
        events: list[dict] = []
        try:
            rows = await self._fm._storage.get_correction_events(limit=50)  # type: ignore[union-attr]
            for r in rows:
                events.append({
                    "id": str(r.get("id", "")),
                    "occurred_at": r.get("occurred_at", ""),
                    "original_pattern": r.get("original_pattern", ""),
                    "correction_text": r.get("correction_text", ""),
                    "scar_id": str(r.get("scar_id", "")) if r.get("scar_id") else None,
                    "session_id": str(r.get("session_id", "")) if r.get("session_id") else None,
                })
        except Exception:
            logger.debug("get_correction_events failed", exc_info=True)
        return {"events": events, "total": len(events)}

    # ------------------------------------------------------------------
    # Phase 3 extended data methods
    # ------------------------------------------------------------------

    async def _get_health_snapshot(self) -> dict:
        """Full organism health from self-model."""
        try:
            report = await self._fm.health()  # type: ignore[union-attr]
            flagged = getattr(self._fm._self_model, "_flagged_params", [])  # type: ignore[union-attr]
            warnings = []
            for w in getattr(self._fm._self_model, "_cascade_warnings", []):  # type: ignore[union-attr]
                warnings.append({
                    "affected_system": getattr(w, "affected_system", str(w)),
                    "severity": round(float(getattr(w, "severity", 0)), 3),
                    "recommended_action": getattr(w, "recommended_action", ""),
                    "predicted_sessions_to_impact": getattr(w, "predicted_sessions_to_impact", 0),
                })
            # Fallback: if total_memories from health report is empty,
            # populate from get_stats which always works
            total_memories = report.total_memories
            if not total_memories:
                try:
                    stats = await self._fm.get_stats()  # type: ignore[union-attr]
                    total_memories = {
                        d["name"]: d.get("memory_count", 0)
                        for d in stats.get("domains", [])
                    }
                except Exception:
                    pass
            return {
                "retrieval_hit_rate": round(report.retrieval_hit_rate, 4),
                "total_memories": total_memories,
                "morphogen_convergence": report.morphogen_convergence,
                "chronic_memories_count": report.chronic_memories_count,
                "system_state": report.system_state,
                "association_density": round(report.association_density, 4),
                "scar_count": report.scar_count,
                "bandit_arm_distribution": report.bandit_arm_distribution,
                "flagged_parameters": flagged,
                "cascade_warnings": warnings,
            }
        except Exception:
            logger.debug("_get_health_snapshot failed", exc_info=True)
            return {}

    async def _get_domain_maturity(self) -> dict:
        """Maturity classification per domain."""
        domains: list[dict] = []
        try:
            stats = await self._fm.get_stats()  # type: ignore[union-attr]
            domain_names = [d["name"] for d in stats.get("domains", [])]
            domain_memory_counts = {d["name"]: d.get("memory_count", 0) for d in stats.get("domains", [])}
            for name in domain_names:
                maturity = await self._fm._self_model.domain_maturity(name)  # type: ignore[union-attr]
                domains.append({
                    "name": name,
                    "maturity": maturity,
                    "memory_count": domain_memory_counts.get(name, 0),
                })
        except Exception:
            logger.debug("_get_domain_maturity failed", exc_info=True)
        return {"domains": domains}

    async def _get_explain_last(self) -> dict:
        """Last retrieval explanation from self-model."""
        try:
            report = await self._fm.explain_last()  # type: ignore[union-attr]
            return {
                "query": report.query,
                "retrieved_memories": report.retrieved_memories,
                "suppressed_memories": report.suppressed_memories,
                "system_state": report.system_state,
                "morphogens": report.morphogens,
                "bandit_arm_selected": report.bandit_arm_selected,
            }
        except Exception:
            logger.debug("_get_explain_last failed", exc_info=True)
            return {"query": "", "retrieved_memories": [], "suppressed_memories": [],
                    "system_state": "", "morphogens": {}, "bandit_arm_selected": ""}

    async def _get_dream_stats(self) -> dict:
        """Last dream cycle stats cached on the dreaming engine."""
        try:
            dreaming = getattr(self._fm, "_dreaming", None)
            last = getattr(dreaming, "_last_report", None) if dreaming else None
            if last is None:
                return {"last_cycle": None, "totals": {}}
            sw = last.slow_wave
            rem = last.rem
            attempted = rem.syntheses_attempted or 0
            stored = rem.syntheses_stored or 0
            success_rate = round(stored / attempted, 3) if attempted else 0.0
            return {
                "last_cycle": {
                    "slow_wave": {
                        "edges_decayed": sw.edges_decayed,
                        "edges_pruned": sw.edges_pruned,
                        "edges_remaining": sw.edges_remaining,
                        "bandits_downscaled": sw.bandits_downscaled,
                    },
                    "rem": {
                        "pairs_evaluated": rem.pairs_evaluated,
                        "syntheses_attempted": attempted,
                        "syntheses_stored": stored,
                        "syntheses_discarded": rem.syntheses_discarded,
                        "success_rate": success_rate,
                    },
                    "duration_seconds": round(last.duration_seconds, 2),
                },
                "totals": getattr(dreaming, "_session_totals", {}),
            }
        except Exception:
            logger.debug("_get_dream_stats failed", exc_info=True)
            return {"last_cycle": None, "totals": {}}

    async def _get_dream_history(self) -> dict:
        """Per-session dream history stored on the dreaming engine."""
        try:
            dreaming = getattr(self._fm, "_dreaming", None)
            history = list(getattr(dreaming, "_report_history", []) if dreaming else [])
            sessions = []
            for i, r in enumerate(history[-20:]):
                sessions.append({
                    "session": i + 1,
                    "edges_decayed": r.slow_wave.edges_decayed,
                    "syntheses_stored": r.rem.syntheses_stored,
                    "duration_seconds": round(r.duration_seconds, 2),
                })
            return {"history": sessions}
        except Exception:
            logger.debug("_get_dream_history failed", exc_info=True)
            return {"history": []}

    async def _get_apoptosis_stats(self) -> dict:
        """Pruning events and trigger distribution."""
        try:
            apoptosis = getattr(self._fm, "_apoptosis", None)
            events = list(getattr(apoptosis, "_pruning_log", []) if apoptosis else [])
            trigger_counts: dict[str, int] = {}
            vitalities: list[float] = []
            serialised: list[dict] = []
            for e in events[-50:]:
                reason = getattr(e, "reason", str(e))
                trigger_counts[reason] = trigger_counts.get(reason, 0) + 1
                vitalities.append(float(getattr(e, "vitality", 0.0)))
                serialised.append({
                    "memory_id": str(getattr(e, "memory_id", "")),
                    "reason": reason,
                    "vitality": round(float(getattr(e, "vitality", 0.0)), 4),
                    "fragments_created": getattr(e, "fragments_created", 0),
                    "scar_created": getattr(e, "scar_created", False),
                    "neighbors_flagged": getattr(e, "neighbors_flagged", 0),
                })
            return {
                "total_pruned": len(events),
                "total_fragments": sum(getattr(e, "fragments_created", 0) for e in events),
                "total_neighbors_flagged": sum(getattr(e, "neighbors_flagged", 0) for e in events),
                "trigger_counts": trigger_counts,
                "vitalities": vitalities[-100:],
                "recent_events": serialised,
            }
        except Exception:
            logger.debug("_get_apoptosis_stats failed", exc_info=True)
            return {"total_pruned": 0, "total_fragments": 0, "total_neighbors_flagged": 0,
                    "trigger_counts": {}, "vitalities": [], "recent_events": []}

    async def _get_folding_state(self) -> dict:
        """Regime, active subsystems, folded stats, anomaly history."""
        try:
            folding = getattr(self._fm, "_folding", None)
            if folding is None:
                return {}
            regime = folding.current_regime
            active = list(folding.active_subsystems)
            folded_stats = dict(getattr(folding, "_folded_stats", {}))
            anomaly_raw = getattr(folding, "_anomaly_history", {})
            anomaly_history = {k: list(v) for k, v in anomaly_raw.items()}
            unfold_log = list(getattr(folding, "_unfold_log", []))
            # Include session/memory counts and morphogen convergence for the regime display
            stats = await self._fm.get_stats()  # type: ignore[union-attr]
            overall = stats.get("overall", {})
            morphogens = getattr(self._fm, "_morphogens", None)
            converged = morphogens.has_converged() if morphogens else False
            folded_subs = [s for s in getattr(folding, "_all_subsystems", [])
                           if s not in active] if hasattr(folding, "_all_subsystems") else []
            return {
                "regime": regime,
                "active_subsystems": active,
                "folded_subsystems": folded_subs,
                "session_count": overall.get("total_sessions", 0),
                "memory_count": overall.get("total_memories", 0),
                "morphogens_converged": converged,
                "folded_stats": {k: (round(v, 4) if v is not None else None)
                                 for k, v in folded_stats.items()},
                "anomaly_history": anomaly_history,
                "unfold_events": unfold_log[-20:],
            }
        except Exception:
            logger.debug("_get_folding_state failed", exc_info=True)
            return {}

    async def _get_niche_health(self) -> dict:
        """Per-domain niche health metrics."""
        domains: list[dict] = []
        try:
            niche = getattr(self._fm, "_niche", None)
            stats = await self._fm.get_stats()  # type: ignore[union-attr]
            domain_names = [d["name"] for d in stats.get("domains", [])]
            session_count = getattr(niche, "_session_count", 0) if niche else 0
            total_reassignments = getattr(niche, "_total_reassignments", 0) if niche else 0
            for name in domain_names:
                if niche:
                    health = await niche.get_niche_health(name)
                    domains.append({
                        "name": name,
                        "internal_cohesion": round(health.internal_cohesion, 4),
                        "external_separation": round(health.external_separation, 4),
                        "stability_sessions": health.stability_sessions,
                        "memory_count": health.memory_count,
                    })
        except Exception:
            logger.debug("_get_niche_health failed", exc_info=True)
        return {
            "domains": domains,
            "session_count": getattr(getattr(self._fm, "_niche", None), "_session_count", 0),
            "total_reassignments": getattr(getattr(self._fm, "_niche", None), "_total_reassignments", 0),
        }

    async def _get_niche_proposals(self) -> dict:
        """Run Louvain cluster detection and return proposals."""
        proposals: list[dict] = []
        try:
            niche = getattr(self._fm, "_niche", None)
            if niche:
                raw = await niche.detect_domain_clusters()
                for p in raw:
                    proposals.append({
                        "proposed_domain": p.proposed_domain,
                        "member_count": len(p.memory_ids),
                        "current_domains": p.current_domains,
                        "modularity_delta": round(p.modularity_delta, 4),
                        "confidence": round(p.confidence, 4),
                    })
        except Exception:
            logger.debug("_get_niche_proposals failed", exc_info=True)
        return {"proposals": proposals}

    async def _get_cascade_state(self) -> dict:
        """EKF hidden state, covariance, warnings, circuit breaker counters."""
        try:
            import numpy as np
            cascade = getattr(self._fm, "_cascade", None)
            if cascade is None:
                return {}
            subsystems = ["gate", "retrieval", "storage", "associations", "domains"]
            state_vec: list[float] = []
            covariance_trace = 0.0
            state_history: list[list[float]] = []
            detector_type = type(cascade).__name__

            x = getattr(cascade, "_x", None)
            P = getattr(cascade, "_P", None)
            if x is not None:
                state_vec = [round(float(v), 4) for v in x]
            if P is not None:
                covariance_trace = round(float(np.trace(P)), 4)
            hist = getattr(cascade, "_state_history", [])
            state_history = [[round(float(v), 4) for v in h] for h in hist]

            # circuit breaker counters (CircuitBreaker attrs)
            low_hit_sessions = getattr(cascade, "_low_hit_sessions", 0)
            high_corr_sessions = getattr(cascade, "_high_correction_sessions", 0)

            # current warnings stored on self-model
            warnings = []
            for w in getattr(getattr(self._fm, "_self_model", None), "_cascade_warnings", []):
                warnings.append({
                    "affected_system": getattr(w, "affected_system", ""),
                    "severity": round(float(getattr(w, "severity", 0)), 3),
                    "recommended_action": getattr(w, "recommended_action", ""),
                    "predicted_sessions_to_impact": getattr(w, "predicted_sessions_to_impact", 0),
                })
            return {
                "subsystems": subsystems,
                "state": dict(zip(subsystems, state_vec)) if state_vec else {},
                "covariance_trace": covariance_trace,
                "state_history": state_history,
                "detector_type": detector_type,
                "low_hit_sessions": low_hit_sessions,
                "high_correction_sessions": high_corr_sessions,
                "cascade_warnings": warnings,
            }
        except Exception:
            logger.debug("_get_cascade_state failed", exc_info=True)
            return {}

    async def _get_cascade_history(self) -> dict:
        """Historical cascade warnings from self-model log."""
        try:
            sm = getattr(self._fm, "_self_model", None)
            history = list(getattr(sm, "_cascade_warning_log", []) if sm else [])
            events = []
            for i, w in enumerate(history[-50:]):
                events.append({
                    "session": i + 1,
                    "affected_system": getattr(w, "affected_system", ""),
                    "severity": round(float(getattr(w, "severity", 0)), 3),
                    "recommended_action": getattr(w, "recommended_action", ""),
                    "predicted_sessions_to_impact": getattr(w, "predicted_sessions_to_impact", 0),
                })
            return {"events": events}
        except Exception:
            logger.debug("_get_cascade_history failed", exc_info=True)
            return {"events": []}

    # ------------------------------------------------------------------
    # Feedback / Danger Theory
    # ------------------------------------------------------------------

    async def _get_feedback_state(self) -> dict:
        try:
            dt = getattr(self._fm, "_danger_theory", None)
            ssd = getattr(self._fm, "_store_signal_detector", None)
            judge = getattr(self._fm, "_judge", None)
            states = getattr(self._fm, "_states", None)

            signals = []
            subtype_counts: dict[str, int] = {}
            store_subtype_counts: dict[str, int] = {}
            if dt:
                for sig in getattr(dt, "_session_signals", [])[-50:]:
                    st = str(getattr(sig, "subtype", ""))
                    subtype_counts[st] = subtype_counts.get(st, 0) + 1
                    signals.append({
                        "type": str(getattr(sig, "type", "")),
                        "subtype": st,
                        "confidence": round(float(getattr(sig, "confidence", 0)), 3),
                        "message": str(getattr(sig, "message", ""))[:150],
                        "timestamp": getattr(sig, "timestamp", "").isoformat()
                            if hasattr(getattr(sig, "timestamp", ""), "isoformat") else str(getattr(sig, "timestamp", "")),
                    })

            info_richness = 0.0
            session_score = 0.0
            if ssd:
                info_richness = round(float(ssd.get_information_richness_signal()), 4)
                session_score = round(float(getattr(ssd, "_session_score", 0)), 4)
                for exc in list(getattr(ssd, "_recent_exchanges", []))[-20:]:
                    pass  # just for future use

            triples = []
            cost_estimate = 0.0
            if judge:
                cost_estimate = round(float(judge.get_cost_estimate()), 6)
                for t in getattr(judge, "_triples", [])[-30:]:
                    triples.append({
                        "memory_id": str(getattr(t, "memory_id", ""))[:8],
                        "query": str(getattr(t, "query", ""))[:80],
                        "has_clear_signal": bool(getattr(t, "has_clear_signal", False)),
                    })
            judge_ratings = []
            for r in getattr(self._fm, "_judge_ratings", [])[-30:]:
                judge_ratings.append({
                    "memory_id": str(getattr(r, "memory_id", ""))[:8],
                    "rating": int(getattr(r, "rating", 0)),
                    "confidence": round(float(getattr(r, "confidence", 0)), 3),
                })

            consecutive_misses = getattr(states, "_consecutive_misses", 0) if states else 0
            consecutive_corrections = getattr(states, "_consecutive_corrections", 0) if states else 0
            consecutive_successes = getattr(states, "_consecutive_successes", 0) if states else 0

            return {
                "signals": list(reversed(signals)),
                "subtype_counts": subtype_counts,
                "store_subtype_counts": store_subtype_counts,
                "message_count": getattr(dt, "_message_count", 0) if dt else 0,
                "avg_message_length": round(float(getattr(dt, "_avg_message_length", 0)), 1) if dt else 0,
                "session_signal_count": len(signals),
                "info_richness": info_richness,
                "session_score": session_score,
                "triples_count": len(triples),
                "triples": triples,
                "judge_ratings": judge_ratings,
                "cost_estimate": cost_estimate,
                "consecutive_misses": consecutive_misses,
                "consecutive_corrections": consecutive_corrections,
                "consecutive_successes": consecutive_successes,
            }
        except Exception:
            logger.debug("_get_feedback_state failed", exc_info=True)
            return {"signals": [], "subtype_counts": {}, "store_subtype_counts": {},
                    "message_count": 0, "avg_message_length": 0, "session_signal_count": 0,
                    "info_richness": 0, "triples": [], "judge_ratings": [], "cost_estimate": 0,
                    "session_score": 0, "consecutive_misses": 0,
                    "consecutive_corrections": 0, "consecutive_successes": 0}

    async def _get_feedback_history(self) -> dict:
        try:
            ssd = getattr(self._fm, "_store_signal_detector", None)
            history = list(getattr(ssd, "_score_history", []) if ssd else [])
            return {"sessions": [{"session": i + 1, "score": round(float(v), 4)}
                                  for i, v in enumerate(history[-20:])]}
        except Exception:
            logger.debug("_get_feedback_history failed", exc_info=True)
            return {"sessions": []}

    # ------------------------------------------------------------------
    # Buffer
    # ------------------------------------------------------------------

    async def _get_buffer_state(self) -> dict:
        try:
            buf = getattr(self._fm, "_buffer", None)
            if buf is None:
                return {}
            pinned = [str(uid)[:8] for uid in getattr(buf, "_pinned", set())]
            auto_promoted = [str(uid)[:8] for uid in getattr(buf, "_auto_promoted", set())]
            just_written = [str(uid)[:8] for uid in list(getattr(buf, "_just_written", []))]
            recent_ids = list(getattr(buf, "_recent", {}).keys())
            recent = [str(uid)[:8] for uid in recent_ids[:20]]
            access_counts = getattr(buf, "_access_counts", {})
            top_access = sorted(
                [{"id": str(k)[:8], "count": v} for k, v in access_counts.items()],
                key=lambda x: x["count"], reverse=True
            )[:20]
            hab_counter = getattr(buf, "_habituation_counter", {})
            hab_threshold = getattr(self._fm._config, "habituation_window", 5)
            habituation = sorted(
                [{"id": str(k)[:8], "count": v,
                  "habituated": v >= hab_threshold} for k, v in hab_counter.items()],
                key=lambda x: x["count"], reverse=True
            )[:20]
            habituated_count = sum(1 for h in habituation if h["habituated"])
            return {
                "pinned": pinned,
                "auto_promoted": auto_promoted,
                "just_written": just_written,
                "recent": recent,
                "turn": getattr(buf, "_turn", 0),
                "soft_cap": getattr(self._fm._config, "buffer_soft_cap", 20),
                "just_written_max": getattr(self._fm._config, "buffer_just_written_max", 3),
                "top_access": top_access,
                "habituation": habituation,
                "habituated_count": habituated_count,
                "total_buffer_size": len(pinned) + len(auto_promoted) + len(just_written) + len(recent),
            }
        except Exception:
            logger.debug("_get_buffer_state failed", exc_info=True)
            return {}

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    async def _get_maintenance_state(self) -> dict:
        try:
            maint = getattr(self._fm, "_maintenance", None)
            if maint is None:
                return {"tiers": [], "last_report": None}
            last_run = getattr(maint, "_last_intra_session_run", None)
            turn_count = getattr(maint, "_intra_session_turn_count", 0)
            last_report = getattr(maint, "_last_report", None)
            report_dict = None
            if last_report:
                report_dict = {
                    "tier": getattr(last_report, "tier", ""),
                    "duration_seconds": round(float(getattr(last_report, "duration_seconds", 0)), 2),
                    "actions_taken": dict(getattr(last_report, "actions_taken", {})),
                }
            tier_history = list(getattr(maint, "_tier_run_log", []))
            tiers = {}
            for entry in tier_history:
                tier = entry.get("tier", "")
                if tier not in tiers or entry.get("timestamp", "") > tiers[tier].get("timestamp", ""):
                    tiers[tier] = entry
            return {
                "last_intra_session_run": last_run.isoformat() if hasattr(last_run, "isoformat") else None,
                "intra_session_turn_count": turn_count,
                "intra_session_interval_minutes": getattr(self._fm._config, "intra_session_interval_minutes", 15),
                "long_session_threshold_minutes": getattr(self._fm._config, "long_session_threshold_minutes", 45),
                "last_report": report_dict,
                "tier_last_run": tiers,
            }
        except Exception:
            logger.debug("_get_maintenance_state failed", exc_info=True)
            return {"tiers": [], "last_report": None}

    async def _get_maintenance_history(self) -> dict:
        try:
            maint = getattr(self._fm, "_maintenance", None)
            history = list(getattr(maint, "_report_history", []) if maint else [])
            runs = []
            for r in history[-20:]:
                runs.append({
                    "tier": getattr(r, "tier", ""),
                    "duration_seconds": round(float(getattr(r, "duration_seconds", 0)), 2),
                    "actions_taken": dict(getattr(r, "actions_taken", {})),
                    "total_actions": sum(getattr(r, "actions_taken", {}).values()),
                })
            return {"runs": runs}
        except Exception:
            logger.debug("_get_maintenance_history failed", exc_info=True)
            return {"runs": []}

    # ------------------------------------------------------------------
    # Config
    # ------------------------------------------------------------------

    async def _get_config_state(self) -> dict:
        import dataclasses
        try:
            cfg = self._fm._config  # type: ignore[union-attr]
            # Morphogen sensitivity annotations (H=high, M=medium, L=low)
            sensitivity_map = {
                "top_l1": "H", "top_l2": "H", "top_l3": "H",
                "scoring_cosine_weight": "H", "scoring_intensity_weight": "M",
                "gate_signal_count": "H", "gate_base_intensity": "H",
                "activation_decay": "H", "co_retrieval_weight_l2": "M", "co_retrieval_weight_l3": "M",
                "slow_wave_decay_factor": "H", "merge_similarity_threshold": "H",
                "conflict_detection_threshold": "H", "scar_match_threshold": "H",
                "apoptosis_context_drift_threshold": "H", "apoptosis_min_vitality": "H",
                "rem_resonance_min": "M", "rem_resonance_max": "M", "rem_emergence_threshold": "H",
                "niche_attract_rate": "M", "niche_repel_rate": "M",
                "morphogen_alpha": "H",
                "domain_drift_threshold": "H",
            }
            category_map = {
                "db_path": "Storage",
                "embedding_model": "Embedding", "embedding_dim": "Embedding",
                "llm_provider": "LLM", "llm_model": "LLM", "llm_api_key": "LLM",
                "llm_timeout_seconds": "LLM", "llm_max_concurrent": "LLM", "llm_max_calls_per_session": "LLM",
                "memory_token_budget_pct": "Retrieval", "context_window_tokens": "Retrieval",
                "top_l1": "Retrieval", "top_l2": "Retrieval", "top_l3": "Retrieval",
                "scoring_cosine_weight": "Retrieval", "scoring_intensity_weight": "Retrieval",
                "hint_window_size": "Retrieval", "hint_min_score": "Retrieval",
                "gate_signal_count": "Gate", "waiting_room_max": "Gate",
                "waiting_room_expiry_sessions": "Gate", "waiting_room_similarity_threshold": "Gate",
                "gate_base_intensity": "Gate", "gate_signal_weight_emphasis": "Gate",
                "gate_signal_weight_explicit_store": "Gate", "gate_signal_weight_repetition": "Gate",
                "gate_signal_weight_novelty": "Gate", "gate_signal_weight_topic_relevance": "Gate",
                "pruning_ttl_sessions": "Lifecycle", "confirmation_threshold": "Lifecycle",
                "permanence_threshold": "Lifecycle",
                "buffer_soft_cap": "Buffer", "buffer_just_written_max": "Buffer",
                "buffer_auto_promote_threshold": "Buffer", "habituation_window": "Buffer",
                "topic_shift_threshold": "Buffer",
                "activation_decay": "Association", "edge_cap_per_node": "Association",
                "refractory_turns": "Association", "co_retrieval_weight_l2": "Association",
                "co_retrieval_weight_l3": "Association", "trail_ema_alpha": "Association",
                "trail_increment_rate": "Association", "association_boost_weight": "Association",
                "min_viable_edge_weight": "Association", "edge_weight_min": "Association",
                "edge_weight_max": "Association",
                "conflict_detection_threshold": "Consolidation", "merge_similarity_threshold": "Consolidation",
                "scar_ttl_sessions": "Consolidation", "slow_wave_decay_factor": "Consolidation",
                "scar_match_threshold": "Scar", "scar_direct_penalty": "Scar",
                "scar_indirect_penalty": "Scar",
                "reask_similarity_threshold": "Feedback", "engagement_length_ratio": "Feedback",
                "engagement_topic_similarity": "Feedback",
                "domain_drift_threshold": "Domain",
                "enable_spreading_activation": "Feature Flags", "enable_scar_penalty": "Feature Flags",
                "enable_llm_judge": "Feature Flags",
                "chronic_decay_factor": "Phase3-Morphogen", "chronic_retrieval_weight": "Phase3-Morphogen",
                "chronic_promotion_threshold": "Phase3-Morphogen",
                "intra_session_interval_minutes": "Phase3-Maintenance",
                "long_session_threshold_minutes": "Phase3-Maintenance",
                "morphogen_alpha": "Phase3-Morphogen", "morphogen_ema_window": "Phase3-Morphogen",
                "morphogen_density_saturation": "Phase3-Morphogen",
                "apoptosis_context_drift_threshold": "Phase3-Apoptosis",
                "apoptosis_contradiction_limit": "Phase3-Apoptosis",
                "apoptosis_min_vitality": "Phase3-Apoptosis",
                "apoptosis_fragment_strength": "Phase3-Apoptosis",
                "apoptosis_scar_duration": "Phase3-Apoptosis",
                "niche_attract_rate": "Phase3-Niche", "niche_repel_rate": "Phase3-Niche",
                "niche_modularity_threshold": "Phase3-Niche", "niche_min_cluster_size": "Phase3-Niche",
                "rem_resonance_min": "Phase3-Dreaming", "rem_resonance_max": "Phase3-Dreaming",
                "rem_emergence_threshold": "Phase3-Dreaming", "rem_max_pairs": "Phase3-Dreaming",
                "rem_top_memories": "Phase3-Dreaming", "bandit_downscale_factor": "Phase3-Dreaming",
                "stress_miss_threshold": "Phase3-States", "stress_correction_threshold": "Phase3-States",
                "stress_recovery_successes": "Phase3-States",
                "domain_sparse_memory_threshold": "Phase3-States",
                "domain_sparse_session_threshold": "Phase3-States",
                "bootstrap_budget_pct": "Bootstrap",
                "dashboard_host": "Dashboard", "dashboard_port": "Dashboard",
                "auto_session": "MCP", "default_domain": "MCP",
                "activity_flush_interval": "MCP", "mcp_port": "MCP",
                "summary_max_memories": "Session", "summary_max_queries": "Session",
                "max_text_length": "Validation", "max_query_length": "Validation",
                "max_domain_length": "Validation", "domain_pattern": "Validation",
            }
            params = []
            for f in dataclasses.fields(cfg):
                if f.name == "llm_api_key":
                    continue  # skip secrets
                val = getattr(cfg, f.name)
                params.append({
                    "name": f.name,
                    "value": str(val),
                    "type": type(val).__name__,
                    "is_bool": isinstance(val, bool),
                    "bool_value": bool(val) if isinstance(val, bool) else None,
                    "category": category_map.get(f.name, "Other"),
                    "sensitivity": sensitivity_map.get(f.name, ""),
                })
            threshold_params = ["scar_match_threshold", "apoptosis_context_drift_threshold",
                                 "rem_resonance_min", "rem_resonance_max", "merge_similarity_threshold",
                                 "domain_drift_threshold",
                                 "rem_emergence_threshold"]
            thresholds = [{"name": n, "value": round(float(getattr(cfg, n, 0)), 4)}
                          for n in threshold_params if hasattr(cfg, n)]
            bool_flags = [p for p in params if p["is_bool"]]
            return {"params": params, "thresholds": thresholds, "bool_flags": bool_flags}
        except Exception:
            logger.debug("_get_config_state failed", exc_info=True)
            return {"params": [], "thresholds": [], "bool_flags": []}

    # ------------------------------------------------------------------
    # Bandits
    # ------------------------------------------------------------------

    async def _get_bandits_state(self) -> dict:
        try:
            bandits = getattr(self._fm, "_bandits", None)
            if bandits is None:
                return {}
            arm_stats = bandits.get_arm_stats()
            current_arm = getattr(bandits, "_current_arm", None)
            current_context_key = getattr(bandits, "_current_context_key", None)
            # Get parameters for current arm
            current_arm_params: dict = {}
            arms_raw = getattr(bandits, "_arms", {})
            if current_context_key and current_arm and current_context_key in arms_raw:
                arm_obj = arms_raw[current_context_key].get(current_arm)
                if arm_obj:
                    current_arm_params = dict(getattr(arm_obj, "parameters", {}))
            # Aggregate across all context bins
            aggregated: dict[str, dict] = {}
            for ctx_bin, arms in arms_raw.items():
                for arm_name, arm_obj in arms.items():
                    if arm_name not in aggregated:
                        aggregated[arm_name] = {"alpha": 0.0, "beta": 0.0, "pulls": 0, "bins": 0}
                    aggregated[arm_name]["alpha"] += float(getattr(arm_obj, "alpha", 1.0))
                    aggregated[arm_name]["beta"] += float(getattr(arm_obj, "beta_param", 1.0))
                    aggregated[arm_name]["bins"] += 1
            arm_list = []
            for name, agg in aggregated.items():
                bins = max(agg["bins"], 1)
                a = agg["alpha"] / bins
                b = agg["beta"] / bins
                mean_success = round(a / (a + b), 4) if (a + b) > 0 else 0.5
                arm_list.append({
                    "name": name,
                    "alpha": round(a, 3),
                    "beta": round(b, 3),
                    "mean_success": mean_success,
                    "pulls": agg["bins"],
                })
            context_bins: dict[str, int] = {}
            selection_log = list(getattr(bandits, "_selection_log", []))
            for entry in selection_log:
                key = str(entry.get("context_key", "unknown"))
                context_bins[key] = context_bins.get(key, 0) + 1
            return {
                "current_arm": current_arm,
                "current_context_key": current_context_key,
                "current_arm_params": current_arm_params,
                "arm_stats": arm_stats,
                "arm_list": arm_list,
                "context_bins": context_bins,
            }
        except Exception:
            logger.debug("_get_bandits_state failed", exc_info=True)
            return {}

    async def _get_bandits_history(self) -> dict:
        try:
            bandits = getattr(self._fm, "_bandits", None)
            history = list(getattr(bandits, "_session_history", []) if bandits else [])
            return {"sessions": history[-20:]}
        except Exception:
            logger.debug("_get_bandits_history failed", exc_info=True)
            return {"sessions": []}

    # ------------------------------------------------------------------
    # System States
    # ------------------------------------------------------------------

    async def _get_states_data(self) -> dict:
        try:
            states = getattr(self._fm, "_states", None)
            if states is None:
                return {}
            multipliers = states.get_parameter_multipliers()
            cfg = self._fm._config  # type: ignore[union-attr]
            session_count = getattr(states, "_session_count", 0)
            state_entry = getattr(states, "_state_entry_session", 0)
            sessions_in_state = max(session_count - state_entry, 0) if session_count else 0
            return {
                "current_state": states.current_state_str,
                "consecutive_misses": getattr(states, "_consecutive_misses", 0),
                "consecutive_corrections": getattr(states, "_consecutive_corrections", 0),
                "consecutive_successes": getattr(states, "_consecutive_successes", 0),
                "session_count": session_count,
                "state_entry_session": state_entry,
                "sessions_in_state": sessions_in_state,
                "parameter_multipliers": multipliers,
                "thresholds": {
                    "stress_miss_threshold": cfg.stress_miss_threshold,
                    "stress_correction_threshold": cfg.stress_correction_threshold,
                    "stress_recovery_successes": cfg.stress_recovery_successes,
                    "domain_sparse_memory_threshold": cfg.domain_sparse_memory_threshold,
                    "domain_sparse_session_threshold": cfg.domain_sparse_session_threshold,
                },
            }
        except Exception:
            logger.debug("_get_states_data failed", exc_info=True)
            return {}

    async def _get_states_history(self) -> dict:
        try:
            states = getattr(self._fm, "_states", None)
            history = list(getattr(states, "_state_history", []) if states else [])
            return {"sessions": [{"session": i + 1, "state": str(s)}
                                  for i, s in enumerate(history[-50:])]}
        except Exception:
            logger.debug("_get_states_history failed", exc_info=True)
            return {"sessions": []}

    # ------------------------------------------------------------------
    # Consolidation
    # ------------------------------------------------------------------

    async def _get_consolidation_state(self) -> dict:
        try:
            cons = getattr(self._fm, "_consolidation", None)
            if cons is None:
                return {"last_report": None}
            last = getattr(cons, "_last_report", None)
            report = None
            if last:
                merges = getattr(last, "merges", [])
                domain_drifts = getattr(last, "domain_drift_suggestions", [])
                report = {
                    "edges_strengthened": getattr(last, "edges_strengthened", 0),
                    "merges_count": len(merges),
                    "edges_decayed": getattr(last, "edges_decayed", 0),
                    "scars_expired": getattr(last, "scars_expired", 0),
                    "freeloaders_found": getattr(last, "freeloaders_found", 0),
                    "merge_events": [
                        {
                            "merged_id": str(getattr(m, "merged_memory_id", ""))[:8],
                            "source_count": len(getattr(m, "source_memory_ids", [])),
                            "domain": str(getattr(m, "domain", "")),
                        }
                        for m in merges[:20]
                    ],
                    "domain_drift_suggestions": [
                        {
                            "memory_id": str(d[0])[:8] if isinstance(d, (list, tuple)) else "",
                            "current_domain": str(d[1]) if isinstance(d, (list, tuple)) and len(d) > 1 else "",
                            "suggested_domain": str(d[2]) if isinstance(d, (list, tuple)) and len(d) > 2 else "",
                        }
                        for d in domain_drifts[:20]
                    ],
                }
            cfg = self._fm._config  # type: ignore[union-attr]
            return {
                "last_report": report,
                "session_memories_count": len(getattr(cons, "_session_memories", [])),
                "session_retrievals_count": len(getattr(cons, "_session_retrievals", [])),
                "judge_ratings_count": len(getattr(cons, "_judge_ratings", [])),
                "config": {
                    "conflict_detection_threshold": cfg.conflict_detection_threshold,
                    "merge_similarity_threshold": cfg.merge_similarity_threshold,
                    "slow_wave_decay_factor": cfg.slow_wave_decay_factor,
                },
            }
        except Exception:
            logger.debug("_get_consolidation_state failed", exc_info=True)
            return {"last_report": None}

    async def _get_consolidation_history(self) -> dict:
        try:
            cons = getattr(self._fm, "_consolidation", None)
            history = list(getattr(cons, "_report_history", []) if cons else [])
            runs = []
            for r in history[-20:]:
                runs.append({
                    "edges_strengthened": getattr(r, "edges_strengthened", 0),
                    "merges": len(getattr(r, "merges", [])),
                    "edges_decayed": getattr(r, "edges_decayed", 0),
                    "scars_expired": getattr(r, "scars_expired", 0),
                    "freeloaders_found": getattr(r, "freeloaders_found", 0),
                })
            return {"runs": runs}
        except Exception:
            logger.debug("_get_consolidation_history failed", exc_info=True)
            return {"runs": []}


def create_dashboard(fractal_memory: object) -> FastAPI:
    """Factory: create the dashboard FastAPI app for a given FractalMemory instance."""
    return DashboardApp(fractal_memory).create_app()


def run_dashboard(fractal_memory: object, port: int = 8765, host: str = "127.0.0.1") -> None:
    """Run the dashboard server.

    Security: defaults to 127.0.0.1 (localhost only) — no authentication.

    Args:
        fractal_memory: Initialized FractalMemory instance.
        port: Port to listen on. Default 8765.
        host: Host to bind to. Default 127.0.0.1.
    """
    try:
        import uvicorn
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "Dashboard requires uvicorn. Install with: pip install fractal-memory[dashboard]"
        ) from exc

    app = create_dashboard(fractal_memory)
    uvicorn.run(app, host=host, port=port)
