"""Fractal Memory diagnostic dashboard — FastAPI + HTMX + D3.js + Chart.js."""
