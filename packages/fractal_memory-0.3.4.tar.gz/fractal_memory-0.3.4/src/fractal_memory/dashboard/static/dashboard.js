/**
 * Fractal Memory Dashboard — shared utilities
 * D3.js, Chart.js, HTMX helpers loaded by base.html
 */

// ---- Utility: HTML escape ----
window.escHtml = function (s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
};

// ---- Vitals bar (nav) ----
function updateNavVitals(data) {
  const bar = document.getElementById("nav-vitals-bar");
  if (!bar) return;

  const live = data.session_live;
  const heartRate = data.heart_rate || 0;
  let heartHtml;
  if (!live && heartRate === 0) {
    heartHtml = '<span class="vital vital-heart vital-dim" title="No active session">&#x2665; &mdash;</span>';
  } else if (live) {
    heartHtml = '<span class="vital vital-heart vital-pulse" title="Live session (' + heartRate + ' ops)">&#x2665; ' + heartRate + ' ops</span>';
  } else {
    heartHtml = '<span class="vital vital-heart vital-dim" title="Last session">&#x2665; ' + heartRate + ' ops (last)</span>';
  }

  bar.innerHTML =
    heartHtml +
    '<span class="vital">&#x1F9E0; ' + (data.total_memories || 0) + '</span>' +
    '<span class="vital">&#x26A1; ' + (data.pressure || 0) + '%</span>';
}

// Poll nav vitals on every page
document.addEventListener("DOMContentLoaded", function () {
  function pollNavVitals() {
    fetch("/api/vitals")
      .then(function(r) { return r.json(); })
      .then(updateNavVitals)
      .catch(function() {});
  }
  pollNavVitals();
  setInterval(pollNavVitals, 5000);
});
