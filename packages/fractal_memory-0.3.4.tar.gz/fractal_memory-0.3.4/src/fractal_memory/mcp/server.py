"""MCP server for Fractal Memory — exposes store/retrieve/stats as tools."""

from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime
from enum import StrEnum
from uuid import UUID

import uvicorn
from mcp.server.fastmcp import Context, FastMCP

from fractal_memory import FractalMemory
from fractal_memory.config import load_config
from fractal_memory.models import TaskStatus
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _serialize(obj: object) -> object:
    """Recursively serialize an object to JSON-safe types."""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, StrEnum):
        return str(obj)
    if isinstance(obj, dict):
        return {str(k): _serialize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_serialize(v) for v in obj]
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        d = {}
        for f in dataclasses.fields(obj):
            if f.name == "embedding":
                continue  # exclude 384-float vectors from responses
            d[f.name] = _serialize(getattr(obj, f.name))
        return d
    return str(obj)


def _resolve_domain(ctx: Context, domain: str) -> str:
    """Return domain, falling back to active_domain from lifespan context."""
    if domain and domain != "default":
        return domain
    # Fall back to the active domain set during lifespan, which is sourced from config
    return ctx.request_context.lifespan_context.get(
        "active_domain",
        ctx.request_context.lifespan_context["fm"]._config.default_domain,
    )


async def _ensure_session(ctx: Context, domain: str) -> None:
    """Auto-start a session if none is active."""
    fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
    if fm._session.current_session is None:
        await fm.session_start(domain)
        logger.info("Auto-started session for domain '%s'", domain)


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------


async def _run_dashboard(fm: FractalMemory) -> None:
    """Launch the diagnostic dashboard in the background.

    Shares the live FractalMemory instance with the MCP server so that
    /api/vitals reflects real session counters instead of stale SQLite data.
    Dashboard runs on localhost only (127.0.0.1).
    """
    try:
        # Import here so dashboard extras are optional at module level.
        # Catches ImportError and ModuleNotFoundError (subclass of ImportError,
        # but explicit for clarity with older tool-chains).
        from fractal_memory.dashboard.app import create_dashboard  # noqa: PLC0415
    except ImportError as exc:
        logger.warning(
            "Dashboard extras not installed or failed to import (%s) — "
            "skipping dashboard launch. "
            "Install with: pip install fractal-memory[dashboard]",
            exc,
        )
        return

    host = fm._config.dashboard_host
    port = fm._config.dashboard_port
    try:
        app = create_dashboard(fm)
        config = uvicorn.Config(app, host=host, port=port, log_level="warning")
        server = uvicorn.Server(config)
        logger.info("Dashboard starting at http://%s:%d", host, port)
        await server.serve()
    except SystemExit:
        # uvicorn calls sys.exit(1) when the port is already in use.
        # SystemExit is BaseException, not Exception, so it must be caught
        # explicitly — otherwise it propagates through the task group and
        # crashes the entire MCP server process.
        logger.info(
            "Dashboard already running at http://%s:%d — reusing existing instance.",
            host,
            port,
        )
    except Exception:
        # Catches uvicorn.Config/Server instantiation failures and other
        # runtime errors from serve(). MCP server continues either way.
        logger.exception(
            "Dashboard server failed to start or exited unexpectedly "
            "(host=%s port=%d)",
            host,
            port,
        )


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """Initialize FractalMemory + Storage at startup, clean up on shutdown.

    Co-launches the diagnostic dashboard as a background asyncio task so that
    both MCP tools and the dashboard share the same live FractalMemory instance.
    This gives the dashboard accurate heart rate and session counters without
    any inter-process communication or SQLite polling.
    """
    config = load_config()
    # Override instructions based on config (Issue #40 — deferred from import time)
    if not config.auto_session:
        server.instructions = _MANUAL_INSTRUCTIONS
    fm = FractalMemory(config)
    await fm.initialize()
    logger.info("Fractal Memory initialized")

    # Auto-start a session at server boot so the dashboard heartbeat is live
    # immediately and Claude can begin storing/retrieving without an explicit
    # session_start call. Controlled by auto_session config flag.
    if config.auto_session:
        session_ctx = await fm.session_start(config.default_domain)
        # Flush a zero-op activity row immediately so the dashboard sees a live
        # session from the moment the server starts — before any store/retrieve.
        await fm._storage.upsert_session_activity(
            session_id=session_ctx.session.id,
            domain=config.default_domain,
            started_at=session_ctx.session.started_at,
            stores=0,
            retrievals=0,
        )
        logger.info("Auto-started session for domain '%s'", config.default_domain)

    # Co-launch dashboard — same process, same fm, zero migration cost.
    dashboard_task = asyncio.create_task(_run_dashboard(fm))

    # Keepalive: refresh session_activity every 60s so the dashboard always
    # sees a live heartbeat even when the server is idle (no stores/retrieves).
    async def _keepalive() -> None:
        while True:
            await asyncio.sleep(60)
            try:
                session = fm._session.current_session
                if session is not None:
                    await fm._storage.upsert_session_activity(
                        session_id=session.id,
                        domain=session.domain,
                        started_at=session.started_at,
                        stores=fm._activity_stores,
                        retrievals=fm._activity_retrievals,
                    )
            except Exception:
                logger.debug("Keepalive heartbeat failed", exc_info=True)

    keepalive_task = asyncio.create_task(_keepalive())

    try:
        yield {"fm": fm, "active_domain": config.default_domain}
    finally:
        # Cancel background tasks, then end session and close fm.
        keepalive_task.cancel()
        dashboard_task.cancel()
        try:
            await dashboard_task
        except asyncio.CancelledError:
            pass  # Expected — task was cancelled normally
        except Exception:
            logger.warning("Dashboard task exited with an unexpected error during shutdown")

        if fm._session.current_session is not None:
            try:
                await fm.session_end()
            except Exception:
                logger.exception("Error ending session during shutdown")
        await fm.close()
        logger.info("Fractal Memory shut down")


# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------

_AUTO_INSTRUCTIONS = """\
You have access to fractal-memory, a persistent long-term memory system that \
learns and improves across sessions.

Do this automatically — no need to wait for the user to ask:
- Call memory_session_start at the beginning of each conversation (use the \
project name or topic as the domain, e.g. "fractal-memory-dev", "client-api").
- Call memory_retrieve at the start of any task or question to load relevant \
context from previous sessions.
- Call memory_store whenever the user shares a preference, decision, fact, \
bug fix, architectural choice, or any context worth remembering in future sessions.
- Call memory_session_end when the conversation ends.

Use memory_correct if the user says something you stored was wrong. \
Use memory_confirm if the user confirms a memory is accurate.

Domain management:
- Use memory_set_domain(domain) to switch the active domain mid-conversation \
(e.g. when the user says "now let's work on project B").
- Use memory_get_domain() to check what domain is currently active.\
"""

_MANUAL_INSTRUCTIONS = """\
You have access to fractal-memory tools (memory_store, memory_retrieve, \
memory_session_start, memory_session_end, memory_correct, memory_confirm). \
Use them only when the user explicitly asks.\
"""

# Create FastMCP without loading config at import time (Issue #40).
# Default to auto instructions; lifespan will override if auto_session=False.
mcp = FastMCP("fractal-memory", lifespan=lifespan, instructions=_AUTO_INSTRUCTIONS)


# -- Store & Retrieve (auto-session) ----------------------------------------


@mcp.tool()
async def memory_store(
    ctx: Context,
    text: str,
    domain: str = "default",
    intensity: float = 0.5,
) -> str:
    """Store a memory. Auto-starts a session if needed.

    Args:
        text: The text content to remember.
        domain: Memory domain (e.g. project name). Defaults to active domain.
        intensity: Importance hint (0.0-1.0).
    """
    try:
        domain = _resolve_domain(ctx, domain)
        await _ensure_session(ctx, domain)
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        mem = await fm.store(text, domain=domain, intensity=intensity)
        if mem is None:
            return json.dumps({"status": "gated_out", "message": "Memory sent to waiting room"})
        return json.dumps(_serialize(mem))
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_retrieve(
    ctx: Context,
    query: str,
    domain: str = "default",
    token_budget: int = 0,
    user_message: str = "",
) -> str:
    """Retrieve memories matching a query. Auto-starts a session if needed.

    Args:
        query: Search query text.
        domain: Memory domain to search in. Defaults to active domain.
        token_budget: Override token budget (0 = use default).
        user_message: Optional user message for real-time feedback detection.
    """
    try:
        domain = _resolve_domain(ctx, domain)
        await _ensure_session(ctx, domain)
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        budget = token_budget if token_budget > 0 else None
        msg = user_message if user_message else None
        result = await fm.retrieve(query, domain=domain, token_budget=budget, user_message=msg)
        return json.dumps(_serialize(result))
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Session management (explicit) ------------------------------------------


@mcp.tool()
async def memory_session_start(ctx: Context, domain: str = "default") -> str:
    """Explicitly start a new memory session for a domain.

    Args:
        domain: Memory domain to start the session in. Defaults to active domain.
    """
    try:
        domain = _resolve_domain(ctx, domain)
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        session_ctx = await fm.session_start(domain)
        return json.dumps(_serialize(session_ctx))
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_session_end(ctx: Context) -> str:
    """End the current memory session and generate a summary."""
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        summary = await fm.session_end()
        return json.dumps(_serialize(summary))
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Direct memory ops -------------------------------------------------------


@mcp.tool()
async def memory_get(ctx: Context, memory_id: str) -> str:
    """Fetch a single memory by its UUID.

    Args:
        memory_id: The UUID of the memory to fetch.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        mem = await fm.get(UUID(memory_id))
        if mem is None:
            return json.dumps({"error": "Memory not found"})
        return json.dumps(_serialize(mem))
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_delete(ctx: Context, memory_id: str) -> str:
    """Delete a memory by its UUID.

    Args:
        memory_id: The UUID of the memory to delete.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        deleted = await fm.delete(UUID(memory_id))
        return json.dumps({"deleted": deleted})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_pin(ctx: Context, memory_id: str) -> str:
    """Pin a memory (promote to PERMANENT lifecycle, always in working buffer).

    Args:
        memory_id: The UUID of the memory to pin.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        await fm.pin(UUID(memory_id))
        return json.dumps({"pinned": True, "memory_id": memory_id})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_unpin(ctx: Context, memory_id: str) -> str:
    """Unpin a memory (revert from PERMANENT to CONFIRMED lifecycle).

    Args:
        memory_id: The UUID of the memory to unpin.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        await fm.unpin(UUID(memory_id))
        return json.dumps({"unpinned": True, "memory_id": memory_id})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_mark_critical(ctx: Context, memory_id: str) -> str:
    """Mark a memory as safety-critical (highest lifecycle, never pruned, always injected).

    Args:
        memory_id: The UUID of the memory to mark as safety-critical.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        await fm.mark_critical(UUID(memory_id))
        return json.dumps({"safety_critical": True, "memory_id": memory_id})
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Phase 2: Explicit feedback API -----------------------------------------


@mcp.tool()
async def memory_correct(ctx: Context, memory_id: str, correction: str) -> str:
    """Correct a memory. Creates scar tissue and regenerates zoom levels.

    Args:
        memory_id: The UUID of the memory to correct.
        correction: The correction text.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        mem = await fm.correct(UUID(memory_id), correction)
        if mem is None:
            return json.dumps({"error": "Memory not found"})
        return json.dumps(_serialize(mem))
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_confirm(ctx: Context, memory_id: str) -> str:
    """Confirm a memory is correct. Strengthens trails and increments retrieval count.

    Args:
        memory_id: The UUID of the memory to confirm.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        await fm.confirm(UUID(memory_id))
        return json.dumps({"status": "confirmed", "memory_id": memory_id})
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Domain selection --------------------------------------------------------


@mcp.tool()
async def memory_set_domain(ctx: Context, domain: str) -> str:
    """Set the active domain for this session. All subsequent store/retrieve calls
    will use this domain unless an explicit domain is provided.

    Args:
        domain: Domain name to set as active (alphanumeric, hyphens, underscores, dots).
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        fm._validate_domain(domain)
        ctx.request_context.lifespan_context["active_domain"] = domain
        return json.dumps({"active_domain": domain, "status": "ok"})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def memory_get_domain(ctx: Context) -> str:
    """Get the currently active domain for this session."""
    try:
        domain = ctx.request_context.lifespan_context.get("active_domain", "general")
        return json.dumps({"active_domain": domain})
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Domain listing ----------------------------------------------------------


@mcp.tool()
async def memory_list_domains(ctx: Context) -> str:
    """List all memory domains with counts and last activity."""
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        domains = await fm.list_domains()
        return json.dumps([_serialize(d) for d in domains])
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Task management ---------------------------------------------------------


@mcp.tool()
async def task_add(ctx: Context, description: str, priority: int = 0) -> str:
    """Add a new task.

    Args:
        description: What needs to be done.
        priority: Priority level (higher = more important).
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        task = await fm.add_task(description, priority=priority)
        return json.dumps(_serialize(task))
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def task_complete(ctx: Context, task_id: str) -> str:
    """Mark a task as completed.

    Args:
        task_id: The UUID of the task to complete.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        await fm.complete_task(UUID(task_id))
        return json.dumps({"completed": True, "task_id": task_id})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def task_list(ctx: Context, status: str = "") -> str:
    """List tasks, optionally filtered by status.

    Args:
        status: Filter by status ('active', 'completed', 'deferred'). Empty = all.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        task_status = TaskStatus(status) if status else None
        tasks = await fm.list_tasks(status=task_status)
        return json.dumps([_serialize(t) for t in tasks])
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Stats -------------------------------------------------------------------


@mcp.tool()
async def memory_stats(ctx: Context) -> str:
    """Get comprehensive memory system statistics.

    Returns JSON with: overall counts, per-domain breakdown, current session info,
    recent stores/retrievals, lifecycle distribution, and working buffer state.
    """
    try:
        fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
        stats = await fm.get_stats()
        return json.dumps(stats)
    except Exception as e:
        return json.dumps({"error": str(e)})


# -- Dashboard ---------------------------------------------------------------


@mcp.tool()
async def open_dashboard(ctx: Context) -> str:
    """Open the Fractal Memory dashboard in the default browser.

    The dashboard runs co-located with the MCP server (same process).
    Opens http://127.0.0.1:8765 (default) in the system default browser.
    Returns the URL that was opened (includes the actual port).
    """
    import webbrowser

    fm: FractalMemory = ctx.request_context.lifespan_context["fm"]
    cfg = fm._config
    port: int = cfg.dashboard_port
    host: str = cfg.dashboard_host
    url = f"http://{host}:{port}"

    webbrowser.open(url)
    return json.dumps({"opened": True, "url": url})


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the Fractal Memory MCP server over stdio."""
    import os
    from logging.handlers import RotatingFileHandler
    from pathlib import Path

    # Prevent sentence-transformers / HuggingFace from making network requests
    # on every startup to check for model updates. The model is already cached
    # at ~/.cache/huggingface/. Without this, startup takes 5-30s and Claude
    # Code's MCP handshake times out, causing the "failed" status.
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("HF_DATASETS_OFFLINE", "1")

    # Log to file — stdout is the MCP wire protocol and must stay clean.
    # Log sits next to the database (respects FRACTAL_DB_PATH override).
    # Defaults to ~/.fractal_memory/fractal_memory.log.
    _cfg = load_config()
    log_dir = Path(_cfg.db_path).expanduser().parent
    log_dir.mkdir(parents=True, exist_ok=True)
    log_level_name = os.environ.get("FRACTAL_LOG_LEVEL", "INFO").upper()
    log_level = getattr(logging, log_level_name, logging.INFO)
    handler = RotatingFileHandler(
        log_dir / "fractal_memory.log",
        maxBytes=5 * 1024 * 1024,  # 5 MB
        backupCount=3,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logging.root.setLevel(log_level)
    logging.root.addHandler(handler)
    # Keep noisy third-party loggers quiet regardless of FRACTAL_LOG_LEVEL.
    for noisy in ("httpx", "httpcore", "uvicorn.access", "sentence_transformers", "transformers"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
