"""Compatibility helpers for fractal-memory."""

from datetime import UTC, datetime


def utcnow() -> datetime:
    """Return current UTC time as a naive datetime.

    Naive UTC — preserves backward compatibility with existing stored
    timestamps. Migrate to timezone-aware in Phase 5 if needed.
    """
    return datetime.now(UTC).replace(tzinfo=None)
