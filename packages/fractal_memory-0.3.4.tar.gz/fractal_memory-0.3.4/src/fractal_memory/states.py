"""System states — STRESS / FLOW / CURIOSITY parameter modulation (Phase 3)."""

from __future__ import annotations

from enum import StrEnum

from fractal_memory.config import FractalConfig


class SystemState(StrEnum):
    FLOW = "flow"
    STRESS = "stress"
    CURIOSITY = "curiosity"


class SystemStateManager:
    """Manages system state transitions and parameter multipliers.

    Three mutually exclusive states (FLOW, STRESS, CURIOSITY). FLOW is the
    default. Multipliers applied on top of morphogen-derived parameter values.
    """

    def __init__(self, config: FractalConfig) -> None:
        self._config = config
        self._current_state: SystemState = SystemState.FLOW
        self._consecutive_misses: int = 0
        self._consecutive_corrections: int = 0
        self._consecutive_successes: int = 0
        self._session_count: int = 0

    def evaluate(
        self,
        session_metrics: dict,
        domain_memory_count: int,
        domain_session_count: int,
    ) -> SystemState:
        """Evaluate triggers and return the current system state.

        STRESS takes priority in mature domains. CURIOSITY takes priority in
        sparse domains. FLOW is the default when no trigger is active.

        Args:
            session_metrics: Dict of session-level metrics. May include
                ``query_variance`` (float) for embedding variance detection.
            domain_memory_count: Number of memories in the current domain.
            domain_session_count: Number of sessions in the current domain.

        Returns:
            The newly evaluated (and stored) system state.
        """
        stress_triggered = (
            self._consecutive_misses >= self._config.stress_miss_threshold
            or self._consecutive_corrections >= self._config.stress_correction_threshold
        )

        sparse_memories = domain_memory_count < self._config.domain_sparse_memory_threshold
        sparse_sessions = domain_session_count < self._config.domain_sparse_session_threshold
        high_query_variance = session_metrics.get("query_variance", 0.0) > 0.5
        curiosity_triggered = (sparse_memories and sparse_sessions) or high_query_variance

        if stress_triggered and curiosity_triggered:
            # Precedence: sparse domain → CURIOSITY wins; mature domain → STRESS wins
            if sparse_memories and sparse_sessions:
                self._current_state = SystemState.CURIOSITY
            else:
                self._current_state = SystemState.STRESS
        elif stress_triggered:
            self._current_state = SystemState.STRESS
        elif curiosity_triggered:
            self._current_state = SystemState.CURIOSITY
        else:
            self._current_state = SystemState.FLOW

        return self._current_state

    def get_parameter_multipliers(self) -> dict[str, float]:
        """Return parameter multipliers for the current state.

        Multipliers are applied on top of morphogen-derived values:
        ``final_param = morphogen_value * multiplier``.
        """
        multipliers: dict[str, dict[str, float]] = {
            SystemState.FLOW: {
                "gate_strictness": 1.3,
                "activation_decay": 1.0,
                "buffer_soft_cap": 1.0,
                "pruning_ttl": 1.0,
                "retrieval_breadth": 0.8,
                "consolidation_aggression": 1.3,
            },
            SystemState.STRESS: {
                "gate_strictness": 0.7,
                "activation_decay": 0.6,
                "buffer_soft_cap": 1.5,
                "pruning_ttl": 1.0,
                "retrieval_breadth": 1.3,
                "consolidation_aggression": 1.0,
            },
            SystemState.CURIOSITY: {
                "gate_strictness": 0.5,
                "activation_decay": 0.8,
                "buffer_soft_cap": 1.0,
                "pruning_ttl": 2.0,
                "retrieval_breadth": 1.5,
                "consolidation_aggression": 0.7,
            },
        }
        return multipliers[self._current_state]

    def on_successful_retrieval(self) -> None:
        """Record a successful retrieval and possibly recover from STRESS."""
        self._consecutive_misses = 0
        self._consecutive_successes += 1
        if (
            self._current_state == SystemState.STRESS
            and self._consecutive_successes >= self._config.stress_recovery_successes
        ):
            self._current_state = SystemState.FLOW
            self._consecutive_successes = 0

    def on_failed_retrieval(self) -> None:
        """Record a failed retrieval (miss)."""
        self._consecutive_misses += 1
        # Cap at 2x threshold to prevent unbounded growth (Issue #16)
        cap = self._config.stress_miss_threshold * 2
        self._consecutive_misses = min(self._consecutive_misses, cap)
        self._consecutive_successes = 0

    def on_correction(self) -> None:
        """Record an explicit user correction."""
        self._consecutive_corrections += 1
        # Cap at 2x threshold to prevent unbounded growth (Issue #16)
        cap = self._config.stress_correction_threshold * 2
        self._consecutive_corrections = min(self._consecutive_corrections, cap)
        self._consecutive_successes = 0

    def reset_session(self) -> None:
        """Reset per-session counters including miss counter (Issue #16)."""
        self._consecutive_corrections = 0
        self._consecutive_misses = 0
        self._session_count += 1

    @property
    def current_state(self) -> SystemState:
        """The current system state."""
        return self._current_state

    @property
    def current_state_str(self) -> str:
        """The current system state as a plain string."""
        return str(self._current_state)
