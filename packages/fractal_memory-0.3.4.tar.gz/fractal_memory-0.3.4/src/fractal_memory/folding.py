"""Dimensional folding — operational complexity management via regime detection (B-12, Phase 3)."""

from __future__ import annotations

from collections import deque

from fractal_memory.config import FractalConfig


# ---------------------------------------------------------------------------
# Regime → active subsystem mapping
# ---------------------------------------------------------------------------

_REGIME_ACTIVE: dict[str, set[str]] = {
    "BOOTSTRAP": {"succession_logic", "bootstrap", "states"},
    "LEARNING": {"bandits", "danger_theory", "morphogens", "states"},
    "MATURE": {"niche", "kalman", "automata", "states"},
}

_ALL_SUBSYSTEMS: set[str] = {
    "succession_logic", "bootstrap",
    "bandits", "danger_theory", "morphogens",
    "niche", "kalman", "automata", "states",
}

# Anomaly detection: sessions above 2σ triggers forced unfold
_ANOMALY_WINDOW = 10
_FORCED_UNFOLD_SIGMA = 2.0
_RETURN_TO_STRUCTURAL_SIGMA = 1.0
_RETURN_STREAK_REQUIRED = 3


# ---------------------------------------------------------------------------
# DimensionalFolder
# ---------------------------------------------------------------------------


class DimensionalFolder:
    """Reduces operational complexity by keeping only 2–3 subsystems active.

    Inactive subsystems are "folded" to a single summary statistic.  Circuit
    breaker logic can force-unfold a structural subsystem when its metric
    exceeds 2σ from its rolling average.
    """

    # Minimum consecutive converged sessions required before MATURE transition
    _CONVERGENCE_DURATION_THRESHOLD: int = 10

    def __init__(self, config: FractalConfig) -> None:
        self._config = config
        self._current_regime: str = "BOOTSTRAP"
        self._active_subsystems: set[str] = set(_REGIME_ACTIVE["BOOTSTRAP"])
        self._folded_stats: dict[str, float] = {}
        # subsystem → rolling window of summary stats
        self._anomaly_history: dict[str, deque[float]] = {
            name: deque(maxlen=_ANOMALY_WINDOW) for name in _ALL_SUBSYSTEMS
        }
        # Forced-unfold state: subsystem → consecutive within-σ sessions
        self._return_streak: dict[str, int] = {}
        # Track consecutive sessions where morphogens have converged
        self._convergence_streak: int = 0

    # ------------------------------------------------------------------
    # Regime determination
    # ------------------------------------------------------------------

    def determine_regime(
        self,
        session_count: int,
        memory_count: int,
        morphogens_converged: bool,
    ) -> str:
        """Determine and return the current operational regime.

        Transitions trigger a regime change which resets the active set.
        """
        # Track convergence duration
        if morphogens_converged:
            self._convergence_streak += 1
        else:
            self._convergence_streak = 0

        if session_count <= 5 or memory_count < 30:
            new_regime = "BOOTSTRAP"
        elif not morphogens_converged or self._convergence_streak < self._CONVERGENCE_DURATION_THRESHOLD:
            new_regime = "LEARNING"
        else:
            new_regime = "MATURE"

        if new_regime != self._current_regime:
            self._transition(new_regime)

        return self._current_regime

    def _transition(self, new_regime: str) -> None:
        self._current_regime = new_regime
        self._active_subsystems = set(_REGIME_ACTIVE.get(new_regime, set()))

    # ------------------------------------------------------------------
    # Active / folded checks
    # ------------------------------------------------------------------

    def is_active(self, subsystem: str) -> bool:
        """Return whether a subsystem is in active (full computation) mode."""
        return subsystem in self._active_subsystems

    def get_folded_stat(self, subsystem: str) -> float | None:
        """Return the cached summary statistic for a folded subsystem.

        Returns None for active subsystems (use full computation instead).
        """
        if self.is_active(subsystem):
            return None
        return self._folded_stats.get(subsystem)

    # ------------------------------------------------------------------
    # Stats updates
    # ------------------------------------------------------------------

    def update_folded_stats(self, stats: dict[str, float]) -> None:
        """Update summary statistics for all subsystems.

        Called at session_end.  Each subsystem provides a single scalar.
        """
        for name, value in stats.items():
            self._folded_stats[name] = value
            if name not in self._anomaly_history:
                self._anomaly_history[name] = deque(maxlen=_ANOMALY_WINDOW)
            self._anomaly_history[name].append(value)

    # ------------------------------------------------------------------
    # Circuit-breaker forced unfold / return
    # ------------------------------------------------------------------

    def check_forced_unfold(self, subsystem: str, current_metric: float) -> bool:
        """Force a structural subsystem active if its metric exceeds 2σ.

        Returns True if the subsystem should be forced active this session.
        """
        if self.is_active(subsystem):
            return False  # already active

        history = list(self._anomaly_history.get(subsystem, deque()))
        if len(history) < 3:
            return False

        import statistics
        mean = statistics.mean(history)
        try:
            stdev = statistics.stdev(history)
        except statistics.StatisticsError:
            return False

        if stdev == 0.0:
            return False

        z_score = abs(current_metric - mean) / stdev
        if z_score >= _FORCED_UNFOLD_SIGMA:
            self._active_subsystems.add(subsystem)
            self._return_streak[subsystem] = 0
            return True
        return False

    def check_return_to_structural(self, subsystem: str, current_metric: float) -> bool:
        """Return a forced-unfold subsystem to structural mode after 3 calm sessions.

        Returns True if the subsystem was returned to structural mode.
        """
        if not self.is_active(subsystem):
            return False
        # Only applies to subsystems that were forced unfold (not regime-default-active)
        if subsystem in _REGIME_ACTIVE.get(self._current_regime, set()):
            return False

        history = list(self._anomaly_history.get(subsystem, deque()))
        if len(history) < 3:
            return False

        import statistics
        mean = statistics.mean(history)
        try:
            stdev = statistics.stdev(history)
        except statistics.StatisticsError:
            return False

        if stdev == 0.0:
            return False

        z_score = abs(current_metric - mean) / stdev
        if z_score < _RETURN_TO_STRUCTURAL_SIGMA:
            streak = self._return_streak.get(subsystem, 0) + 1
            self._return_streak[subsystem] = streak
            if streak >= _RETURN_STREAK_REQUIRED:
                self._active_subsystems.discard(subsystem)
                self._return_streak[subsystem] = 0
                return True
        else:
            self._return_streak[subsystem] = 0
        return False

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def current_regime(self) -> str:
        """The current operational regime."""
        return self._current_regime

    @property
    def active_subsystems(self) -> set[str]:
        """Set of currently active subsystem names."""
        return set(self._active_subsystems)
