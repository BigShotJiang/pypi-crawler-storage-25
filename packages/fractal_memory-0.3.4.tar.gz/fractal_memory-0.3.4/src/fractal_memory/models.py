"""Data classes, enums, and type definitions for fractal-memory."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import TypedDict
from uuid import UUID


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class LifecycleStatus(StrEnum):
    PROBATION = "probation"
    CONFIRMED = "confirmed"
    PERMANENT = "permanent"
    SAFETY_CRITICAL = "safety_critical"


class TaskStatus(StrEnum):
    ACTIVE = "active"
    COMPLETED = "completed"
    DEFERRED = "deferred"


# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

class ContextTags(TypedDict, total=False):
    project: str
    task: str
    tools: list[str]
    domain: str


# ---------------------------------------------------------------------------
# Core data classes
# ---------------------------------------------------------------------------

@dataclass
class Memory:
    id: UUID
    domain: str
    created_at: datetime
    updated_at: datetime
    context: ContextTags
    l0_tag: str
    l1_label: str
    l2_summary: str
    l3_full: str
    l4_raw: str
    embedding: list[float]
    embedding_model: str
    intensity: float = 0.5
    retrieval_count: int = 0
    miss_count: int = 0
    last_accessed: datetime | None = None
    lifecycle: LifecycleStatus = LifecycleStatus.PROBATION
    chronic_score: float = 0.0
    contrast: str | None = None
    chain_next: UUID | None = None
    chain_prev: UUID | None = None
    # Phase 3+ fields — stored now to avoid future migrations
    vitality: float = 1.0
    reconsolidation_count: int = 0
    origin: str = "organic"
    # Phase 4+ fields
    trust_score: float = 1.0
    pinned: bool = False


@dataclass
class Task:
    id: UUID
    description: str
    created_at: datetime
    status: TaskStatus = TaskStatus.ACTIVE
    related_memory_ids: list[UUID] = field(default_factory=list)
    priority: int = 0


@dataclass
class WaitingRoomEntry:
    id: UUID
    content: str
    first_signal: dict
    domain: str | None
    created_at: datetime
    sessions_elapsed: int = 0
    embedding: list[float] = field(default_factory=list)


@dataclass
class Session:
    id: UUID
    domain: str
    started_at: datetime
    ended_at: datetime | None = None
    summary: str | None = None


# ---------------------------------------------------------------------------
# Result / context data classes
# ---------------------------------------------------------------------------

@dataclass
class RetrievalResult:
    l3_memories: list[Memory] = field(default_factory=list)
    l2_memories: list[Memory] = field(default_factory=list)
    l1_memories: list[Memory] = field(default_factory=list)
    hints: list[Memory] = field(default_factory=list)
    token_budget_used: int = 0
    token_budget_total: int = 0
    store_suggestions: list[dict] = field(default_factory=list)  # Phase 2: StoreSignal dicts


@dataclass
class SessionContext:
    session: Session
    bootstrap_memories: list[Memory] = field(default_factory=list)
    last_summary: str | None = None
    active_tasks: list[Task] = field(default_factory=list)


@dataclass
class SessionSummary:
    session_id: UUID
    summary: str
    memories_stored: int = 0
    memories_retrieved: int = 0
    duration_seconds: float = 0.0


@dataclass
class DomainInfo:
    name: str
    memory_count: int
    last_active: datetime
