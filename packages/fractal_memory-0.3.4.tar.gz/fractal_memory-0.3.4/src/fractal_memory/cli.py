"""Fractal Memory CLI — Click-based command interface (Phase 3)."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any
from uuid import UUID

import click

from fractal_memory.config import FractalConfig, load_config

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run(coro: Any) -> Any:
    """Run an async coroutine synchronously, catching and displaying errors."""
    try:
        return asyncio.run(coro)
    except click.exceptions.Exit:
        raise  # Allow Click's own exit signals through (e.g. ctx.exit())
    except click.ClickException:
        raise  # Already a user-facing Click error, re-raise as-is
    except Exception as exc:
        logger.debug("CLI command failed", exc_info=True)
        raise click.ClickException(str(exc)) from exc


def _validate_uuid(value: str) -> UUID:
    """Parse a UUID string, raising click.BadParameter on invalid input."""
    try:
        return UUID(value)
    except (ValueError, AttributeError):
        raise click.BadParameter(
            f"Invalid UUID: '{value}'. Expected format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        )


class _IntensityRange(click.ParamType):
    """Click parameter type that validates intensity is in [0.0, 1.0]."""

    name = "float[0-1]"

    def convert(self, value: Any, param: click.Parameter | None, ctx: click.Context | None) -> float:
        try:
            fval = float(value)
        except (ValueError, TypeError):
            self.fail(f"'{value}' is not a valid float.", param, ctx)
        if not (0.0 <= fval <= 1.0):
            self.fail(f"Intensity {fval} is out of range. Must be between 0.0 and 1.0.", param, ctx)
        return fval


INTENSITY_TYPE = _IntensityRange()


def _domain_from_cwd() -> str:
    """Derive domain name from the current working directory."""
    return Path.cwd().name


async def _make_fm(db: str | None, domain: str | None) -> tuple[Any, str]:
    """Create and initialise a FractalMemory instance.

    Ensures fm.close() is called if initialization fails after the
    FractalMemory object is constructed (preventing resource leaks).
    """
    from fractal_memory import FractalMemory

    overrides: dict[str, Any] = {}
    if db:
        overrides["db_path"] = Path(db).expanduser()

    config = FractalConfig(**{k: v for k, v in overrides.items()}) if overrides else load_config()
    fm = FractalMemory(config=config)
    try:
        await fm.initialize()
    except Exception:
        await fm.close()
        raise
    active_domain = domain or _domain_from_cwd()
    return fm, active_domain


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


@click.group()
@click.option("--db", default=None, help="Database path (overrides config)")
@click.option("--domain", default=None, help="Active domain")
@click.pass_context
def cli(ctx: click.Context, db: str | None, domain: str | None) -> None:
    """Fractal Memory — organism control interface."""
    ctx.ensure_object(dict)
    ctx.obj["db"] = db
    ctx.obj["domain"] = domain


# ---------------------------------------------------------------------------
# store
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("text")
@click.option("--domain", default=None, help="Target domain")
@click.option("--intensity", default=0.5, show_default=True, type=INTENSITY_TYPE, help="Memory intensity 0–1")
@click.pass_context
def store(ctx: click.Context, text: str, domain: str | None, intensity: float) -> None:
    """Store TEXT as a memory."""

    async def _store() -> None:
        db = ctx.obj.get("db")
        active_domain = domain or ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, active_domain)
        try:
            await fm.session_start(active_domain)
            mem = await fm.store(text, domain=active_domain, intensity=intensity)
            if mem is None:
                click.echo("Memory queued in waiting room (gate deferred).")
            else:
                click.echo(f"Stored: {mem.id}")
                click.echo(f"  L0: {mem.l0_tag}")
                click.echo(f"  L1: {mem.l1_label}")
                click.echo(f"  Lifecycle: {mem.lifecycle}")
            await fm.session_end()
        finally:
            await fm.close()

    _run(_store())


# ---------------------------------------------------------------------------
# retrieve
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("query")
@click.option("--domain", default=None)
@click.option("--budget", default=0, help="Token budget (0 = default)")
@click.pass_context
def retrieve(ctx: click.Context, query: str, domain: str | None, budget: int) -> None:
    """Retrieve memories for QUERY."""

    async def _retrieve() -> None:
        db = ctx.obj.get("db")
        active_domain = domain or ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, active_domain)
        try:
            result = await fm.retrieve(
                query,
                domain=active_domain,
                token_budget=budget if budget > 0 else None,
            )
            click.echo(f"L3 ({len(result.l3_memories)}):")
            for m in result.l3_memories:
                click.echo(f"  [{m.id}] {m.l1_label}")
            click.echo(f"L2 ({len(result.l2_memories)}):")
            for m in result.l2_memories:
                click.echo(f"  [{m.id}] {m.l2_summary[:80]}")
            click.echo(f"Tokens used: {result.token_budget_used}/{result.token_budget_total}")
        finally:
            await fm.close()

    _run(_retrieve())


# ---------------------------------------------------------------------------
# session
# ---------------------------------------------------------------------------


@cli.group()
def session() -> None:
    """Session management commands."""


@session.command("start")
@click.option("--domain", default=None)
@click.pass_context
def session_start(ctx: click.Context, domain: str | None) -> None:
    """Start a new session."""

    async def _start() -> None:
        db = ctx.obj.get("db")
        active_domain = domain or ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, active_domain)
        try:
            ctx_obj = await fm.session_start(active_domain)
            click.echo(f"Session started in domain: {active_domain}")
            click.echo(f"Session ID: {ctx_obj.session.id}")
            click.echo(f"Bootstrap memories: {len(ctx_obj.bootstrap_memories)}")
        finally:
            await fm.close()

    _run(_start())


@session.command("end")
@click.pass_context
def session_end(ctx: click.Context) -> None:
    """End the current session (not supported in CLI)."""
    click.echo(
        "CLI session end is not supported. "
        "Use the MCP server for session lifecycle management. "
        "See: fractal-memory docs."
    )
    ctx.exit(1)


# ---------------------------------------------------------------------------
# health
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def health(ctx: click.Context) -> None:
    """Show the full health report."""

    async def _health() -> None:
        db = ctx.obj.get("db")
        domain = ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, domain)
        try:
            if hasattr(fm, "health"):
                report = await fm.health()
                click.echo(f"System state: {report.system_state}")
                click.echo(f"Retrieval hit rate: {report.retrieval_hit_rate:.2%}")
                click.echo(f"Association density: {report.association_density:.2f}")
                click.echo(f"Scars: {report.scar_count}")
                click.echo(f"Morphogen converged: {report.morphogen_convergence.get('converged', False)}")
                click.echo(f"Total memories: {sum(report.total_memories.values())}")
                if report.cascade_warnings:
                    click.echo(f"CASCADE WARNINGS: {len(report.cascade_warnings)}")
                    for w in report.cascade_warnings:
                        click.echo(f"  {w.affected_system}: {w.recommended_action}")
                if report.flagged_parameters:
                    click.echo(f"Flagged parameters: {', '.join(report.flagged_parameters)}")
            else:
                click.echo("health() not available in this version")
        finally:
            await fm.close()

    _run(_health())


# ---------------------------------------------------------------------------
# explain
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def explain(ctx: click.Context) -> None:
    """Explain the last retrieval decision."""

    async def _explain() -> None:
        db = ctx.obj.get("db")
        domain = ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, domain)
        try:
            if hasattr(fm, "explain_last"):
                report = await fm.explain_last()
                click.echo(f"Query: {report.query}")
                click.echo(f"State: {report.system_state}  Arm: {report.bandit_arm_selected}")
                click.echo(f"Retrieved: {len(report.retrieved_memories)}")
                for m in report.retrieved_memories[:5]:
                    click.echo(f"  {m}")
                click.echo(f"Suppressed: {len(report.suppressed_memories)}")
            else:
                click.echo("explain_last() not available in this version")
        finally:
            await fm.close()

    _run(_explain())


# ---------------------------------------------------------------------------
# domains
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def domains(ctx: click.Context) -> None:
    """List all domains with statistics."""

    async def _domains() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        try:
            domain_list = await fm.list_domains()
            click.echo(f"{'Domain':<30} {'Memories':>8} {'Last Active'}")
            click.echo("-" * 60)
            for d in domain_list:
                click.echo(f"{d.name:<30} {d.memory_count:>8}  {str(d.last_active)[:19]}")
        finally:
            await fm.close()

    _run(_domains())


# ---------------------------------------------------------------------------
# memories
# ---------------------------------------------------------------------------


@cli.command()
@click.option("--domain", default=None)
@click.option("--lifecycle", default=None, help="probation|confirmed|permanent")
@click.option("--limit", default=20, show_default=True)
@click.pass_context
def memories(ctx: click.Context, domain: str | None, lifecycle: str | None, limit: int) -> None:
    """List memories with optional filters."""

    async def _memories() -> None:
        db = ctx.obj.get("db")
        active_domain = domain or ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, active_domain)
        try:
            mems = await fm._storage.list_memories(  # type: ignore[attr-defined]
                domain=active_domain if domain else None,
                lifecycle=lifecycle,
                limit=limit,
            )
            click.echo(f"{'ID':<36} {'L1 Label':<40} {'Lifecycle':<12} {'Vitality':>8}")
            click.echo("-" * 100)
            for m in mems:
                vitality = f"{m.vitality:.3f}" if hasattr(m, "vitality") else "N/A"
                click.echo(f"{str(m.id):<36} {m.l1_label[:40]:<40} {str(m.lifecycle):<12} {vitality:>8}")
        finally:
            await fm.close()

    _run(_memories())


# ---------------------------------------------------------------------------
# inspect
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("memory_id")
@click.pass_context
def inspect(ctx: click.Context, memory_id: str) -> None:
    """Show full detail for a memory."""
    mid = _validate_uuid(memory_id)

    async def _inspect() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        try:
            mem = await fm._storage.get_memory(mid)  # type: ignore[attr-defined]
            if mem is None:
                click.echo(f"Memory {memory_id} not found.")
                return
            click.echo(f"ID: {mem.id}")
            click.echo(f"Domain: {mem.domain}")
            click.echo(f"Lifecycle: {mem.lifecycle}")
            click.echo(f"Intensity: {mem.intensity}")
            click.echo(f"Vitality: {getattr(mem, 'vitality', 'N/A')}")
            click.echo(f"Chronic score: {getattr(mem, 'chronic_score', 'N/A')}")
            click.echo(f"Retrieval count: {mem.retrieval_count}")
            click.echo(f"Miss count: {mem.miss_count}")
            click.echo(f"L0: {mem.l0_tag}")
            click.echo(f"L1: {mem.l1_label}")
            click.echo(f"L2: {mem.l2_summary}")
            click.echo(f"L3: {mem.l3_full}")
        finally:
            await fm.close()

    _run(_inspect())


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("memory_id")
@click.confirmation_option(prompt="Delete this memory?")
@click.pass_context
def delete(ctx: click.Context, memory_id: str) -> None:
    """Delete a memory (with confirmation)."""
    mid = _validate_uuid(memory_id)

    async def _delete() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        try:
            await fm._storage.delete_memory(mid)  # type: ignore[attr-defined]
            click.echo(f"Deleted: {memory_id}")
        finally:
            await fm.close()

    _run(_delete())


# ---------------------------------------------------------------------------
# pin / unpin
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("memory_id")
@click.pass_context
def pin(ctx: click.Context, memory_id: str) -> None:
    """Pin a memory (promote to PERMANENT lifecycle)."""
    mid = _validate_uuid(memory_id)

    async def _pin() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        try:
            await fm.pin(mid)
            click.echo(f"Pinned: {memory_id}")
        finally:
            await fm.close()

    _run(_pin())


@cli.command()
@click.argument("memory_id")
@click.pass_context
def unpin(ctx: click.Context, memory_id: str) -> None:
    """Unpin a memory (revert to CONFIRMED lifecycle)."""
    mid = _validate_uuid(memory_id)

    async def _unpin() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        try:
            await fm.unpin(mid)
            click.echo(f"Unpinned: {memory_id}")
        finally:
            await fm.close()

    _run(_unpin())


# ---------------------------------------------------------------------------
# morphogens
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def morphogens(ctx: click.Context) -> None:
    """Show current morphogen values, response curves, and convergence status."""

    async def _morphogens() -> None:
        db = ctx.obj.get("db")
        domain = ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, domain)
        try:
            if hasattr(fm, "_morphogens") and fm._morphogens is not None:  # type: ignore[attr-defined]
                m = fm._morphogens  # type: ignore[attr-defined]
                ms = m.last_morphogens
                if ms:
                    click.echo(f"information_richness: {ms.information_richness:.3f}")
                    click.echo(f"retrieval_pressure:   {ms.retrieval_pressure:.3f}")
                    click.echo(f"domain_density:       {ms.domain_density:.3f}")
                click.echo(f"Converged: {m.has_converged()}")
                click.echo("")
                click.echo(f"{'Curve':<22} {'Midpoint':>8} {'Steepness':>10} {'Value':>8}")
                click.echo("-" * 52)
                if ms:
                    for curve in m.curves:
                        val = curve.compute(ms)
                        click.echo(
                            f"{curve.name:<22} {curve.midpoint:>8.3f} {curve.steepness:>10.3f} {val:>8.3f}"
                        )
            else:
                click.echo("Morphogenetic field not active in this instance.")
        finally:
            await fm.close()

    _run(_morphogens())


# ---------------------------------------------------------------------------
# bandits
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def bandits(ctx: click.Context) -> None:
    """Show bandit arm statistics."""

    async def _bandits() -> None:
        db = ctx.obj.get("db")
        domain = ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, domain)
        try:
            if hasattr(fm, "_bandits") and fm._bandits is not None:  # type: ignore[attr-defined]
                stats = fm._bandits.get_arm_stats()  # type: ignore[attr-defined]
                click.echo(f"{'Arm':<14} {'Alpha':>7} {'Beta':>7} {'Mean':>7} {'Pulls':>7}")
                click.echo("-" * 46)
                for arm_name, s in stats.items():
                    click.echo(
                        f"{arm_name:<14} {s['alpha']:>7.1f} {s['beta']:>7.1f} "
                        f"{s['mean_success']:>7.3f} {s['pulls']:>7.0f}"
                    )
                click.echo(f"\nCurrent arm: {fm._bandits.current_arm}")  # type: ignore[attr-defined]
            else:
                click.echo("Bandit not active in this instance.")
        finally:
            await fm.close()

    _run(_bandits())


# ---------------------------------------------------------------------------
# maintenance
# ---------------------------------------------------------------------------


@cli.command()
@click.option(
    "--tier",
    type=click.Choice(["daily", "weekly", "monthly"]),
    required=True,
    help="Maintenance tier to run",
)
@click.pass_context
def maintenance(ctx: click.Context, tier: str) -> None:
    """Manually trigger a maintenance cycle."""

    async def _maintenance() -> None:
        db = ctx.obj.get("db")
        domain = ctx.obj.get("domain") or _domain_from_cwd()
        fm, _ = await _make_fm(db, domain)
        try:
            if hasattr(fm, "_maintenance") and fm._maintenance is not None:  # type: ignore[attr-defined]
                scheduler = fm._maintenance  # type: ignore[attr-defined]
                if tier == "daily":
                    report = await scheduler.daily_maintenance()
                elif tier == "weekly":
                    report = await scheduler.weekly_maintenance()
                else:
                    report = await scheduler.monthly_maintenance()
                click.echo(f"Maintenance tier: {report.tier}")
                click.echo(f"Duration: {report.duration_seconds:.2f}s")
                for action, count in report.actions_taken.items():
                    click.echo(f"  {action}: {count}")
            else:
                click.echo("Maintenance scheduler not active in this instance.")
        finally:
            await fm.close()

    _run(_maintenance())


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def stats(ctx: click.Context) -> None:
    """Quick summary: memories, domains, edges, scars, seams, sessions."""

    async def _stats() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        try:
            summary = await fm._storage.get_summary_stats()  # type: ignore[attr-defined]
            click.echo("=== Fractal Memory Stats ===")
            for key, val in summary.items():
                click.echo(f"  {key}: {val}")
        finally:
            await fm.close()

    _run(_stats())


# ---------------------------------------------------------------------------
# lint
# ---------------------------------------------------------------------------


async def _lint_checks(
    conn: Any,
    storage: Any,
    issues: list[str],
    fixes: list[str],
    fix: bool,
) -> None:
    """Run all lint SQL checks against the database.

    Separated from the lint command so callers can wrap this in a
    try/except and surface a user-friendly error when the schema is
    missing expected tables or columns.
    """
    # 1. Orphaned edges — associations pointing to deleted memory IDs
    orphaned_edges = 0
    async with conn.execute(
        """SELECT a.source_id, a.target_id FROM associations a
           LEFT JOIN memories m1 ON a.source_id = m1.id
           LEFT JOIN memories m2 ON a.target_id = m2.id
           WHERE m1.id IS NULL OR m2.id IS NULL"""
    ) as cur:
        orphaned = await cur.fetchall()
        orphaned_edges = len(orphaned)

    if orphaned_edges > 0:
        issues.append(f"Orphaned edges: {orphaned_edges} association(s) pointing to deleted memories")
        if fix:
            await conn.execute(
                """DELETE FROM associations WHERE source_id NOT IN (SELECT id FROM memories)
                   OR target_id NOT IN (SELECT id FROM memories)"""
            )
            await conn.commit()
            fixes.append(f"Deleted {orphaned_edges} orphaned edge(s)")

    # 2. Broken chains — chain_next/chain_prev pointing to non-existent memories
    broken_chains = 0
    async with conn.execute(
        """SELECT m.id, m.chain_next FROM memories m
           WHERE m.chain_next IS NOT NULL
           AND m.chain_next NOT IN (SELECT id FROM memories)"""
    ) as cur:
        broken_next = await cur.fetchall()
    async with conn.execute(
        """SELECT m.id, m.chain_prev FROM memories m
           WHERE m.chain_prev IS NOT NULL
           AND m.chain_prev NOT IN (SELECT id FROM memories)"""
    ) as cur:
        broken_prev = await cur.fetchall()
    broken_chains = len(broken_next) + len(broken_prev)

    if broken_chains > 0:
        issues.append(f"Broken chains: {broken_chains} chain pointer(s) to non-existent memories")
        if fix:
            for row in broken_next:
                await conn.execute(
                    "UPDATE memories SET chain_next = NULL WHERE id = ?", (row["id"],)
                )
            for row in broken_prev:
                await conn.execute(
                    "UPDATE memories SET chain_prev = NULL WHERE id = ?", (row["id"],)
                )
            await conn.commit()
            fixes.append(f"Cleared {broken_chains} broken chain pointer(s)")

    # 3. Missing embeddings — memories without embedding vectors
    async with conn.execute(
        "SELECT COUNT(*) FROM memories WHERE embedding IS NULL OR LENGTH(embedding) = 0"
    ) as cur:
        row = await cur.fetchone()
        missing_embeddings = row[0] if row else 0

    if missing_embeddings > 0:
        issues.append(f"Missing embeddings: {missing_embeddings} memory(ies) without embedding vectors")

    # 4. Stale memories — not accessed in 30+ sessions
    total_sessions = await storage.get_session_count()
    if total_sessions >= 30:
        async with conn.execute(
            """SELECT COUNT(*) FROM memories
               WHERE (last_accessed IS NULL AND retrieval_count = 0)
               AND lifecycle != 'permanent'"""
        ) as cur:
            row = await cur.fetchone()
            stale_count = row[0] if row else 0
        if stale_count > 0:
            issues.append(f"Stale memories: {stale_count} never-accessed memory(ies) across {total_sessions} sessions")

    # 5. Lifecycle anomalies — PERMANENT memories with zero retrievals
    async with conn.execute(
        "SELECT COUNT(*) FROM memories WHERE lifecycle = 'permanent' AND retrieval_count = 0"
    ) as cur:
        row = await cur.fetchone()
        perm_zero = row[0] if row else 0

    if perm_zero > 0:
        issues.append(f"Lifecycle anomalies: {perm_zero} PERMANENT memory(ies) with zero retrievals")


@cli.command()
@click.option("--fix", is_flag=True, help="Auto-repair safe issues")
@click.pass_context
def lint(ctx: click.Context, fix: bool) -> None:
    """Check database health and report issues."""

    async def _lint() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        storage = fm._storage  # type: ignore[attr-defined]
        issues: list[str] = []
        fixes: list[str] = []

        try:
            try:
                conn = storage._ensure_conn()
            except Exception as exc:
                raise click.ClickException(
                    f"Cannot connect to database for lint: {exc}"
                ) from exc

            try:
                await _lint_checks(conn, storage, issues, fixes, fix)
            except click.ClickException:
                raise
            except Exception as exc:
                raise click.ClickException(
                    f"Lint failed — database may use an older schema: {exc}"
                ) from exc

            # Report
            if not issues:
                click.echo("No issues found. Database is healthy.")
            else:
                click.echo(f"Found {len(issues)} issue(s):")
                for issue in issues:
                    click.echo(f"  - {issue}")
                if fix and fixes:
                    click.echo(f"\nFixed {len(fixes)} issue(s):")
                    for f in fixes:
                        click.echo(f"  - {f}")
                elif not fix and any("Orphaned" in i or "Broken" in i for i in issues):
                    click.echo("\nRun with --fix to auto-repair safe issues.")
        finally:
            await fm.close()

    _run(_lint())


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------


@cli.group()
def export() -> None:
    """Export memories and stats."""


@export.command("memories")
@click.option("--domain", required=True, help="Domain to export")
@click.option("--format", "fmt", type=click.Choice(["json", "markdown"]), default="json", show_default=True)
@click.option("--output", "-o", default=None, help="Output file (default: stdout)")
@click.pass_context
def export_memories(ctx: click.Context, domain: str, fmt: str, output: str | None) -> None:
    """Export memories for a domain."""

    async def _export() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, domain)
        storage = fm._storage  # type: ignore[attr-defined]

        try:
            memories = await storage.get_memories_by_domain(domain)

            if fmt == "json":
                data = []
                for m in memories:
                    data.append({
                        "id": str(m.id),
                        "domain": m.domain,
                        "l0_tag": m.l0_tag,
                        "l1_label": m.l1_label,
                        "l2_summary": m.l2_summary,
                        "l3_full": m.l3_full,
                        "lifecycle": m.lifecycle.value,
                        "intensity": m.intensity,
                        "retrieval_count": m.retrieval_count,
                        "vitality": m.vitality,
                        "created_at": m.created_at.isoformat(),
                        "updated_at": m.updated_at.isoformat(),
                    })
                text = json.dumps(data, indent=2)
            else:  # markdown
                lines: list[str] = []
                lines.append(f"# Fractal Memory Export — {domain}\n")
                lines.append(f"Total memories: {len(memories)}\n")
                for m in memories:
                    lines.append(f"---\n")
                    lines.append(f"## {m.l1_label}\n")
                    lines.append(f"- **ID:** `{m.id}`")
                    lines.append(f"- **Lifecycle:** {m.lifecycle.value}")
                    lines.append(f"- **Intensity:** {m.intensity}")
                    lines.append(f"- **Vitality:** {m.vitality:.3f}")
                    lines.append(f"- **Retrievals:** {m.retrieval_count}")
                    lines.append(f"- **Created:** {m.created_at.isoformat()}")
                    lines.append(f"- **Tag:** `{m.l0_tag}`\n")
                    lines.append(f"### Summary\n")
                    lines.append(f"{m.l2_summary}\n")
                    lines.append(f"### Full\n")
                    lines.append(f"{m.l3_full}\n")

                    # Include associations
                    assocs = await storage.get_associations(m.id)
                    if assocs:
                        lines.append(f"### Associations\n")
                        for target_id, weight, trail_weight, _ in assocs:
                            lines.append(f"- `{target_id}` (weight: {weight:.3f}, trail: {trail_weight:.3f})")
                        lines.append("")

                text = "\n".join(lines)

            if output:
                Path(output).write_text(text)
                click.echo(f"Exported {len(memories)} memories to {output}")
            else:
                click.echo(text)
        finally:
            await fm.close()

    _run(_export())


@export.command("stats")
@click.option("--format", "fmt", type=click.Choice(["json"]), default="json", show_default=True)
@click.pass_context
def export_stats(ctx: click.Context, fmt: str) -> None:
    """Export full system stats as JSON."""

    async def _export_stats() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        storage = fm._storage  # type: ignore[attr-defined]

        try:
            summary = await storage.get_summary_stats()
            lifecycle = await storage.get_lifecycle_counts()
            domains = await storage.list_domains_with_counts()
            edge_stats = await storage.get_edge_stats()

            data = {
                "summary": summary,
                "lifecycle_distribution": lifecycle,
                "domains": domains,
                "associations": edge_stats,
            }
            click.echo(json.dumps(data, indent=2))
        finally:
            await fm.close()

    _run(_export_stats())


# ---------------------------------------------------------------------------
# audit
# ---------------------------------------------------------------------------


@cli.group()
def audit() -> None:
    """Audit trail — inspect session history, corrections, and consolidation."""


@audit.command("sessions")
@click.option("--limit", default=20, show_default=True, help="Number of sessions to show")
@click.pass_context
def audit_sessions(ctx: click.Context, limit: int) -> None:
    """Show recent session summaries."""

    async def _audit_sessions() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        storage = fm._storage  # type: ignore[attr-defined]

        try:
            summaries = await storage.get_session_summaries(limit=limit)
            if not summaries:
                click.echo("No session summaries found.")
                return

            click.echo(f"{'Session ID':<38} {'Ended':<20} {'Stores':>6} {'Retrieves':>9} {'Scars':>6} {'Merges':>7} {'Edges':>6}")
            click.echo("-" * 96)
            for s in summaries:
                ended = s.get("ended_at", "")[:19]
                click.echo(
                    f"{s.get('session_id', ''):<38} {ended:<20} "
                    f"{s.get('store_count', 0):>6} {s.get('retrieve_count', 0):>9} "
                    f"{s.get('scar_count', 0):>6} {s.get('merge_count', 0):>7} "
                    f"{s.get('edge_count', 0):>6}"
                )
        finally:
            await fm.close()

    _run(_audit_sessions())


@audit.command("corrections")
@click.option("--limit", default=20, show_default=True, help="Number of corrections to show")
@click.pass_context
def audit_corrections(ctx: click.Context, limit: int) -> None:
    """Show recent correction events."""

    async def _audit_corrections() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        storage = fm._storage  # type: ignore[attr-defined]

        try:
            events = await storage.get_correction_events(limit=limit)
            if not events:
                click.echo("No correction events found.")
                return

            click.echo(f"{'When':<20} {'Memory ID':<38} {'Correction'}")
            click.echo("-" * 100)
            for e in events:
                when = e.get("occurred_at", "")[:19]
                mem_id = e.get("memory_id", "N/A") or "N/A"
                correction = (e.get("correction_text", "") or "")[:60]
                click.echo(f"{when:<20} {mem_id:<38} {correction}")
        finally:
            await fm.close()

    _run(_audit_corrections())


@audit.command("consolidation")
@click.pass_context
def audit_consolidation(ctx: click.Context) -> None:
    """Show last consolidation report from session summaries."""

    async def _audit_consolidation() -> None:
        db = ctx.obj.get("db")
        fm, _ = await _make_fm(db, None)
        storage = fm._storage  # type: ignore[attr-defined]

        try:
            summaries = await storage.get_session_summaries(limit=5)
            if not summaries:
                click.echo("No session summaries found.")
                return

            click.echo("Last 5 sessions consolidation activity:\n")
            for s in summaries:
                ended = s.get("ended_at", "")[:19]
                click.echo(f"Session: {s.get('session_id', '')}")
                click.echo(f"  Ended: {ended}")
                click.echo(f"  Merges: {s.get('merge_count', 0)}")
                click.echo(f"  Scars created: {s.get('scar_count', 0)}")
                click.echo(f"  Edges at end: {s.get('edge_count', 0)}")
                click.echo("")
        finally:
            await fm.close()

    _run(_audit_consolidation())
