"""Session management — start, end, summary generation, bootstrap."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from datetime import datetime
from uuid import UUID, uuid4

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.gate import CoincidenceGate
from fractal_memory.lifecycle import LifecycleManager
from fractal_memory.llm import LLMProvider, LLMUnavailableError
from fractal_memory.models import (
    LifecycleStatus,
    Memory,
    RetrievalResult,
    Session,
    SessionContext,
    SessionSummary,
    TaskStatus,
)
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)

_SUMMARY_SYSTEM = (
    "You are a session summarizer. You compress a conversation session into a "
    "brief narrative summary. The summary will be used to bootstrap the next "
    "session in this domain. Focus on what was accomplished, what decisions "
    "were made, and what's pending. Respond with plain text only — no markdown, "
    "no JSON."
)

_SUMMARY_TEMPLATE = """Summarize this session in domain "{domain}".

Memories stored this session ({n_stored}):
{stored_memory_summaries}

Queries made this session ({n_queries}):
{query_list}

Session duration: {duration:.0f} minutes.

Write a 2-3 sentence summary capturing:
1. What was the main focus/topic?
2. What was accomplished or decided?
3. What's left pending or unresolved (if anything)?

Keep it under 50 tokens."""


class SessionManager:
    def __init__(
        self,
        storage: Storage,
        llm: LLMProvider,
        lifecycle: LifecycleManager,
        gate: CoincidenceGate,
        config: FractalConfig,
    ) -> None:
        self._storage = storage
        self._llm = llm
        self._lifecycle = lifecycle
        self._gate = gate
        self._config = config

        self._current_session: Session | None = None
        self._session_memories: list[UUID] = []
        self._session_retrievals: list[dict] = []
        self._on_session_end_hooks: list[Callable[[], Awaitable[None]]] = []
        self._session_accessed: set = set()
        # Phase 2 session state
        self._exchange_count: int = 0
        # Protect session mutations from concurrent access (Issue #11)
        self._lock = asyncio.Lock()

    @property
    def current_session(self) -> Session | None:
        return self._current_session

    @property
    def session_memory_ids(self) -> list[UUID]:
        """Public accessor for session memory IDs (Issue #50)."""
        return list(self._session_memories)

    @property
    def session_retrievals(self) -> list[dict]:
        """Public accessor for session retrieval records (Issue #50)."""
        return list(self._session_retrievals)

    @property
    def accessed_memory_ids(self) -> set[UUID]:
        """Public accessor for accessed memory IDs (Issue #50)."""
        return set(self._session_accessed)

    @property
    def exchange_count(self) -> int:
        """Public accessor for exchange count (Issue #50)."""
        return self._exchange_count

    async def start(self, domain: str | None = None) -> SessionContext:
        """Start a new session, loading bootstrap context for the given domain.

        Args:
            domain: Domain to start the session in. Defaults to config.default_domain.

        Returns:
            SessionContext with bootstrap memories, last summary, and active tasks.

        Raises:
            RuntimeError: If a session is already active. Call end() first.
        """
        async with self._lock:
            return await self._start_locked(domain)

    async def _start_locked(self, domain: str | None = None) -> SessionContext:
        """Internal start implementation — must be called under self._lock."""
        domain = domain or self._config.default_domain

        if self._current_session is not None:
            # Auto-end the orphaned session instead of silently overwriting (Issue #12)
            logger.warning(
                "Auto-ending active session %s (domain=%s) before starting new session.",
                self._current_session.id,
                self._current_session.domain,
            )
            await self._end_locked()

        session = Session(
            id=uuid4(),
            domain=domain,
            started_at=utcnow(),
        )
        await self._storage.store_session(session)
        self._current_session = session
        self._session_memories: list = []
        self._session_retrievals: list = []
        self._session_accessed: set = set()  # Union of stored + retrieved IDs
        self._exchange_count = 0

        # Bootstrap: safety-critical memories
        safety_memories = await self._storage.get_memories_by_lifecycle(
            LifecycleStatus.SAFETY_CRITICAL
        )

        # Bootstrap: chronic/permanent memories
        permanent = await self._storage.get_memories_by_lifecycle(
            LifecycleStatus.PERMANENT
        )
        chronic = [
            m for m in permanent
            if m.chronic_score >= self._config.chronic_promotion_threshold
        ]

        bootstrap = safety_memories + chronic

        # Cap bootstrap payload at configured percentage of memory budget
        bootstrap_budget = int(
            self._config.memory_token_budget * self._config.bootstrap_budget_pct
        )
        bootstrap = self._cap_bootstrap(bootstrap, bootstrap_budget)

        # Bootstrap: last session summary
        last_session = await self._storage.get_last_session(domain)
        last_summary = last_session.summary if last_session else None

        # Bootstrap: active tasks
        active_tasks = await self._storage.list_tasks(TaskStatus.ACTIVE)

        return SessionContext(
            session=session,
            bootstrap_memories=bootstrap,
            last_summary=last_summary,
            active_tasks=active_tasks,
        )

    async def end(self) -> SessionSummary:
        """End the current session: generate summary, run pruning, expire waiting room.

        Returns:
            SessionSummary with LLM-generated summary and session statistics.

        Raises:
            RuntimeError: If no active session exists.
        """
        async with self._lock:
            return await self._end_locked()

    async def _end_locked(self) -> SessionSummary:
        """Internal end implementation — must be called under self._lock."""
        if self._current_session is None:
            raise RuntimeError("No active session to end")

        session = self._current_session
        now = utcnow()
        duration = (now - session.started_at).total_seconds()

        # Generate summary
        summary_text = await self._generate_summary(session.domain, duration)

        # Update session record
        session.ended_at = now
        session.summary = summary_text
        await self._storage.update_session(session)

        # Run lifecycle pruning
        pruned = await self._lifecycle.prune_expired()
        if pruned:
            logger.info("Pruned %d expired probation memories", len(pruned))

        # Expire waiting room entries
        expired = await self._gate.expire_waiting_room()
        if expired:
            logger.info("Expired %d waiting room entries", expired)

        # Increment waiting room session counters
        await self._storage.increment_waiting_room_sessions()

        # Run on-end hooks (P1→P2 extension point)
        for hook in self._on_session_end_hooks:
            try:
                await hook()
            except Exception:
                logger.exception("Session end hook failed")

        # Record session summary row (Option 12 — Phase 4 timeline foundation).
        # One write per session, zero per-op overhead.
        try:
            # Count retrieval hits: retrievals that returned at least one L3 result
            retrieval_hits = sum(
                1 for r in self._session_retrievals if r.get("l3_count", 0) > 0
            )
            # Use session.ended_at (the canonical record) not the local `now` variable.
            await self._storage.record_session_summary(
                session_id=session.id,
                started_at=session.started_at,
                ended_at=session.ended_at,  # type: ignore[arg-type]  # set above
                store_count=len(self._session_memories),
                retrieve_count=len(self._session_retrievals),
                retrieval_hits=retrieval_hits,
            )
        except Exception:
            logger.exception("Failed to record session summary — non-fatal")

        summary = SessionSummary(
            session_id=session.id,
            summary=summary_text,
            memories_stored=len(self._session_memories),
            memories_retrieved=len(self._session_retrievals),
            duration_seconds=duration,
        )

        self._current_session = None
        return summary

    def register_on_end_hook(
        self, hook: Callable[[], Awaitable[None]]
    ) -> None:
        """Register an async callback to run when the session ends.

        Args:
            hook: Zero-argument async callable invoked during ``end()``.
        """
        self._on_session_end_hooks.append(hook)

    async def record_store(self, memory_id: UUID) -> None:
        """Record that a memory was stored during this session.

        Args:
            memory_id: UUID of the stored memory.
        """
        self._session_memories.append(memory_id)
        self._session_accessed.add(memory_id)

    async def record_retrieval(
        self, query: str, result: RetrievalResult
    ) -> None:
        """Record a retrieval operation for session statistics and accessed-ID tracking.

        Args:
            query: The search query text.
            result: The retrieval result containing L1/L2/L3 memories.
        """
        retrieved_ids = [m.id for m in result.l3_memories]
        l2_ids = [m.id for m in result.l2_memories]
        self._session_retrievals.append({
            "query": query,
            "l3_count": len(result.l3_memories),
            "l2_count": len(result.l2_memories),
            "l1_count": len(result.l1_memories),
            "l3_ids": retrieved_ids,
            "l2_ids": l2_ids,
        })
        # Track all accessed IDs for chronic/vitality updates
        self._session_accessed.update(retrieved_ids)
        self._session_accessed.update(l2_ids)

    def record_exchange(self) -> None:
        """Increment exchange count. Called on each user message (Phase 2)."""
        self._exchange_count += 1

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        return len(text) // 4

    def _cap_bootstrap(
        self, memories: list[Memory], budget_tokens: int
    ) -> list[Memory]:
        """Keep only as many bootstrap memories as fit within the token budget.

        Safety-critical memories are always included first.
        """
        safety = [m for m in memories if m.lifecycle == LifecycleStatus.SAFETY_CRITICAL]
        others = [m for m in memories if m.lifecycle != LifecycleStatus.SAFETY_CRITICAL]
        # Sort non-safety by retrieval count descending for relevance (Issue #46)
        others.sort(key=lambda m: (m.retrieval_count, m.intensity), reverse=True)

        result = list(safety)
        used = sum(self._estimate_tokens(m.l2_summary) for m in result)

        for m in others:
            cost = self._estimate_tokens(m.l2_summary)
            if used + cost > budget_tokens:
                break
            result.append(m)
            used += cost

        return result

    async def _generate_summary(
        self, domain: str, duration_seconds: float
    ) -> str:
        n_stored = len(self._session_memories)
        n_queries = len(self._session_retrievals)

        # Build stored memory summaries
        stored_summaries = []
        if self._session_memories:
            for mid in self._session_memories[:self._config.summary_max_memories]:
                mem = await self._storage.get_memory(mid)
                if mem:
                    stored_summaries.append(f"- {mem.l2_summary}")
        stored_text = "\n".join(stored_summaries) if stored_summaries else "(none)"

        # Build query list
        query_list = []
        for r in self._session_retrievals[:self._config.summary_max_queries]:
            query_list.append(f"- \"{r['query']}\" → {r['l3_count']} L3 results")
        query_text = "\n".join(query_list) if query_list else "(none)"

        prompt = _SUMMARY_TEMPLATE.format(
            domain=domain,
            n_stored=n_stored,
            stored_memory_summaries=stored_text,
            n_queries=n_queries,
            query_list=query_text,
            duration=duration_seconds / 60.0,
        )

        try:
            return await self._llm.complete(
                prompt=prompt, system=_SUMMARY_SYSTEM, max_tokens=200
            )
        except Exception:
            logger.debug("LLM summary generation failed — using fallback", exc_info=True)
            return (
                f'Session in domain "{domain}": stored {n_stored} memories, '
                f"performed {n_queries} retrievals over "
                f"{duration_seconds / 60.0:.0f} minutes."
            )
