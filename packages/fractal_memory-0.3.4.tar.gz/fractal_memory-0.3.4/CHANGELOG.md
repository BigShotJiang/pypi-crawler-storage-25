# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.4] - 2026-04-13

### Release Notes

**Title:** v0.3.4 — Fix all 49 validated bugs from deep audit, add persistent pin flag, embedding cache, schema v8

**GitHub Release Body:**

> ## What's new
>
> ### Bug fixes (49)
>
> **P0 — Crash fixes:**
> - Fixed gate crash on string signals — string-to-Signal enum coercion in `gate.py`
> - Fixed store/retrieve working without active session — session guard with RuntimeError
> - Fixed CLI `store` crash on gated-out memory (None return)
> - Fixed association weight updates only applying to one direction (~50% of edges)
>
> **P1 — Broken subsystem wiring:**
> - Wired `apoptosis.execute_apoptosis()` into monthly maintenance results
> - Wired `SelfModel.record_retrieval()` into retrieve pipeline — `explain_last()` now returns real data
> - Wired bandit state persistence (serialize/deserialize) with new `bandit_state` table (schema v7)
>
> **P2 — Correctness fixes (24):**
> - Fixed store/retrieve ignoring session domain — now inherits from `session_start(domain)`
> - Fixed L3 co-retrieval edges double-recorded — L3 excluded from L2 association call
> - Fixed danger theory regex false positives (`not \w+` matched everything) — tightened patterns, added mutual exclusion
> - Fixed system state counters growing unbounded — added caps and session reset
> - Fixed zero-vector embeddings appearing in retrieval results
> - Fixed CJK token estimation undercount (4x) — CJK-aware heuristic
> - Fixed vitality formula using quadratic penalty — now linear
> - Fixed apoptosis context drift using zero-vector — uses domain centroid
> - Fixed competitive_inhibition weight decay without floor — `max(0.1, ...)` floor
> - Fixed _parse_ratings regex matching stray digits in LLM text
> - Fixed _slow_wave and _dawn_reset silently swallowing all exceptions — logging added
> - Fixed OllamaProvider creating new HTTP client per call — persistent client
> - Fixed N+1 queries in scar penalty — batch pre-load
> - Fixed N+1 queries in decay_all_weights — bulk SQL
> - Fixed _maybe_flush_activity firing at total_ops=0
> - Fixed MCP server load_config() at import time — deferred to lifespan
> - Fixed LocalEmbeddingProvider thread-unsafe model loading — threading.Lock
> - Fixed _config propagation missing 4 subsystems after regime transition
> - Fixed O(N*M) queries in _suggest_domain_drift — single SQL query
> - Fixed session concurrency with asyncio.Lock, auto-end on double start
> - Fixed correction chain dangling references on delete
> - Fixed pinned memories being demoted by zombie demotion — persistent `pinned` flag
>
> **P3 — Code quality (14):**
> - Added async context manager (`async with FractalMemory(...) as fm:`)
> - Added config validation for embedding_dim, max_text_length, max_query_length
> - Added embedding dimension validation on store
> - Removed dead `_state_entry_session` field
> - Removed misleading `type: ignore` on dreaming prune_below call
> - Added exponential backoff to AnthropicProvider retries (3 attempts)
> - Added bootstrap relevance sorting by retrieval_count
> - Added public session state accessors (replaced private attribute access)
> - Added comprehensive env var type coercion for all numeric config fields
> - Fixed consolidation accessing private `_ensure_conn()` — new public `rollback_merge()` method
> - Fixed keepalive and dreaming bare `except: pass` anti-pattern — logging added
> - Added retrieval embedding cache with invalidation — avoids repeated numpy allocation
>
> ### Schema
> - **v7:** `bandit_state` table for Thompson Sampling posterior persistence
> - **v8:** `pinned` column on memories table for persistent pin flag
>
> ### Testing
> - 970 tests, 0 failures
> - Updated session state machine tests for new session guard behavior
> - Updated throughput test threshold (5/s → 2/s) for CI stability
> - Updated miss counter test for new reset-on-session behavior
>
> ### Install
>
> ```bash
> pip install fractal-memory==0.3.4
>
> # With dashboard:
> pip install "fractal-memory[dashboard]==0.3.4"
> ```
>
> Full changelog: https://github.com/entropyvector/fractal-memory/blob/main/CHANGELOG.md

### Fixed
- Fix gate crash on string signals — string-to-Signal coercion in `evaluate()` and `_add_to_waiting_room()`
- Fix store/retrieve working without session — `RuntimeError` guard after input validation
- Fix CLI `store` crash on `None` return when gate defers memory
- Fix association weight update only applying to `(source, target)` direction — now bidirectional
- Wire `apoptosis.execute_apoptosis()` into monthly maintenance for each `batch_check()` candidate
- Wire `SelfModel.record_retrieval()` in `retrieve()` — `explain_last()` returns real data
- Wire bandit state `serialize()`/`deserialize()` — persist to `bandit_state` table on session end/start
- Fix store/retrieve ignoring session domain — inherit from `current_session.domain`
- Fix L3 co-retrieval double-recording — exclude L3 IDs from L2 `on_co_retrieval()` call
- Fix danger theory regex false positives — remove `not \w+`, tighten to specific correction phrases, add CORRECTION > CONFIRMATION precedence
- Fix system state counters unbounded — cap at `2 * threshold`, reset misses on `reset_session()`
- Fix zero-vector embeddings appearing in results — `zero_mask` with forced similarity = 0.0
- Fix CJK token estimation undercount — `sum(2 if ord(c) > 0x2E80 else 1 for c in text) // 4`
- Fix vitality quadratic penalty — linear formula `rc / max(1, total)`
- Fix apoptosis context drift using zero-vector — compute domain centroid from `get_all_embeddings()`
- Fix `competitive_inhibition` weight decay without floor — `max(0.1, weight * 0.8)`
- Fix `_parse_ratings` regex matching stray digits — anchor to line start or `rating:`/`score:` delimiters
- Fix `_slow_wave` silently swallowing all exceptions — `logger.warning()`/`logger.debug()`
- Fix `_dawn_reset` failures silently swallowed — logging for inner and outer exceptions
- Fix `OllamaProvider` creating new HTTP client per call — lazy persistent `httpx.AsyncClient`
- Fix N+1 queries in scar penalty — batch pre-load edges into `neighbor_map`
- Fix N+1 queries in `decay_all_weights` — bulk `UPDATE`/`DELETE` via `batch_decay_and_prune()`
- Fix `_maybe_flush_activity` firing when `total_ops == 0`
- Fix MCP server `load_config()` at import time — deferred to lifespan, `FastMCP` created without config
- Fix `LocalEmbeddingProvider._load_model` thread-unsafe — `threading.Lock` with double-checked locking
- Fix `_config` propagation missing `_niche`, `_buffer`, `_folding`, `_states` after regime transition
- Fix O(N*M) queries in `_suggest_domain_drift` — new `get_all_memory_domains()` single SQL query
- Fix session concurrency — `asyncio.Lock` protecting `start()`/`end()`, auto-end on double start
- Fix correction chain dangling references — null out `chain_next`/`chain_prev` on `delete_memory()`
- Fix pinned memories demoted by `_demote_zombie_permanent` — check `mem.pinned` flag
- Fix consolidation accessing private `_ensure_conn()` — new `Storage.rollback_merge()` public method
- Fix keepalive and dreaming bare `except: pass` — replaced with logging
- Remove dead `_state_entry_session` field from `states.py`
- Remove misleading `type: ignore[attr-defined]` on `prune_below()` call in `dreaming.py`

### Added
- `Memory.pinned` boolean field — persistent pin flag surviving session restarts
- Schema migration v7: `bandit_state` table for Thompson Sampling posteriors
- Schema migration v8: `pinned` column on `memories` table
- `FractalMemory.__aenter__`/`__aexit__` — async context manager support
- `Storage.rollback_merge()` — public API for merge rollback (replaces private conn access)
- `Storage.get_all_memory_domains()` — single-query domain lookup for all memories
- `Storage.batch_decay_and_prune()` — bulk SQL edge decay and cleanup
- `RetrievalEngine.invalidate_cache()` — per-domain embedding cache invalidation
- Embedding cache in `RetrievalEngine` — avoids repeated numpy array allocation per retrieval
- `SessionManager` public accessors: `session_memory_ids`, `session_retrievals`, `accessed_memory_ids`, `exchange_count`
- Config validation for `embedding_dim` (1-4096), `max_text_length` (100-1M), `max_query_length` (100-1M)
- Embedding dimension validation on `store()` — rejects mismatched dimensions
- Comprehensive env var type coercion for all numeric `FractalConfig` fields
- `AnthropicProvider` exponential backoff: 3 attempts with `(2^attempt + attempt*0.5)` delay
- Bootstrap memory sorting by `(retrieval_count, intensity)` descending

### Changed
- Session state machine tests updated to expect `RuntimeError` for store/retrieve without session
- Throughput test threshold lowered from 5/s to 2/s for CI stability
- Miss counter test updated for new reset-on-session behavior
- `lifecycle.pin()` now sets `mem.pinned = True` in addition to lifecycle promotion
- `lifecycle.unpin()` now clears `mem.pinned = False`
- `_demote_zombie_permanent()` skips memories with `pinned=True`
- `_cosine_similarity_batch()` delegates to `_cosine_similarity_batch_np()` for cached arrays

## [0.3.3] - 2026-04-12

### Release Notes

**Title:** v0.3.3 — 15 bug fixes, CLI hardening, real self-model metrics

**GitHub Release Body:**

> ## What's new
>
> ### Bug fixes (15)
> - Fixed `_propagate_config()` missing 8 subsystems — stale config on niche, buffer, folding, cascade, danger_theory, store_signal_detector, judge, states
> - Fixed `store()` intensity silently overwritten by gate — user value now acts as floor
> - Fixed `confirm()` not promoting PROBATION to CONFIRMED lifecycle status
> - Fixed `BatchedLLMJudge` crash on non-string `model_name`
> - Fixed `store(signals=[])` treated differently from `signals=None`
> - Fixed `delete()` leaving dangling `chain_next`/`chain_prev` references
> - Fixed `update_association_weight` only updating one direction
> - Fixed `compute_vitality` being unnecessarily async
> - Fixed `DimensionalFolder.update_folded_stats` dropping unknown subsystem metrics
> - Fixed empty-string domain silently defaulting to "default"
> - Fixed `WaitingRoomEntry` not exported from package
> - Fixed vitality calculation using quadratic penalty (hit_rate^2)
> - Fixed `gate_signal_count` default of 2 breaking single-signal store
> - Fixed morphogen `ResponseCurve.compute` crash on NaN/Inf
> - Fixed `competitive_inhibition` using wrong rolling-mean key
>
> ### Enhancements
> - CLI: comprehensive error handling, UUID validation, intensity range type, init cleanup
> - Self-model: real metrics for freshness, compression_ratio, growth_rate, domain_health
> - Config: validation for ~60 additional parameters across all phases
> - Dreaming: proper logging instead of bare `except: pass`
>
> ### Testing
> - Added `test_bugfix_v4.py` — 11 test classes covering all 15 bug fixes
> - Added `test_cli_stress.py` — stress tests for all 21 CLI commands
> - Updated existing tests for config/API changes
>
> ### Install
>
> ```bash
> pip install fractal-memory==0.3.3
>
> # With dashboard:
> pip install "fractal-memory[dashboard]==0.3.3"
> ```
>
> Full changelog: https://github.com/entropyvector/fractal-memory/blob/main/CHANGELOG.md

### Fixed
- Fix `_propagate_config()` missing 8 subsystems (`_niche`, `_buffer`, `_folding`, `_cascade`, `_danger_theory`, `_store_signal_detector`, `_judge`, `_states`) — stale config after propagation
- Fix `store()` intensity silently overwritten by gate — now uses `max(intensity, decision.intensity)` as floor
- Fix `confirm()` not promoting PROBATION to CONFIRMED lifecycle status
- Fix `BatchedLLMJudge` crash on non-string `model_name` — added `isinstance(model, str)` guard
- Fix `store(signals=[])` treated differently from `signals=None` — empty list now falls through to default
- Fix `delete()` leaving dangling `chain_next`/`chain_prev` references on adjacent memories
- Fix `update_association_weight` only updating one direction (A→B but not B→A)
- Fix `compute_vitality` being unnecessarily async — changed to sync, all callers updated
- Fix `DimensionalFolder.update_folded_stats` silently dropping unknown subsystem metrics
- Fix empty-string domain silently defaulting to "default" — now raises `ValueError`
- Fix `WaitingRoomEntry` not exported from package `__all__`
- Fix vitality calculation using quadratic penalty (`hit_rate^2` → linear `rc / max(1, total)`)
- Fix `gate_signal_count` default of 2 breaking single-signal store — changed default to 1
- Fix morphogen `ResponseCurve.compute` crash on NaN/Inf values
- Fix `competitive_inhibition` using wrong rolling-mean key — now per-morphogen composite keys

### Changed
- CLI `_run()` now catches all exceptions with user-friendly error messages
- CLI lint SQL checks extracted into `_lint_checks()` with connection/schema error handling
- Self-model health report computes real metrics (freshness, compression_ratio, growth_rate, domain_health) instead of stubs
- Config `__post_init__` validates ~60 additional parameters across all phases
- Dreaming engine: 6 bare `except: pass` blocks replaced with `logger.warning()`/`logger.debug()`
- Replaced deprecated `datetime.utcnow()` with `datetime.now(UTC)` in tests

### Added
- CLI `_validate_uuid()` helper — converts invalid UUIDs to `click.BadParameter`
- CLI `_IntensityRange` Click parameter type — validates intensity in [0.0, 1.0]
- `tests/test_bugfix_v4.py` — 11 test classes covering all 15 bug fixes
- `tests/test_cli_stress.py` — stress tests for all 21 CLI commands (12 groups)

## [0.3.2] - 2026-04-11

### Release Notes

**Title:** v0.3.2 — Deep adversarial testing + bug fixes

**GitHub Release Body:**

> ## What's new
>
> ### Bug fixes
> - Fixed self-loop edges allowed in association storage layer (`store_association`)
> - Fixed unclamped intensity parameter in `store()` API (now clamped to [0.0, 1.0])
>
> ### Testing
> - Added 10 adversarial/boundary/integration test suites (125 new tests)
> - Total test suite: 852 tests, 0 failures
> - Suites cover: adversarial data, session state machine, concurrent torture, numerical boundaries, lifecycle simulation, LLM failure injection, config boundaries, schema migration, association graph integrity, health report accuracy
>
> ### Install
>
> ```bash
> pip install fractal-memory==0.3.2
>
> # With dashboard:
> pip install "fractal-memory[dashboard]==0.3.2"
> ```
>
> Full changelog: https://github.com/entropyvector/fractal-memory/blob/main/CHANGELOG.md

### Fixed
- Prevent self-loop edges in `store_association()` — guard rejects `source_id == target_id`
- Clamp `intensity` parameter to [0.0, 1.0] in `store()` — explicit contract instead of relying on gate override

### Added
- `tests/test_chaos_memory_factory.py` (16 tests) — NaN/Inf embedding rejection, Unicode/emoji, null bytes, zero vectors, extreme intensity, 1D embeddings
- `tests/test_session_state_machine.py` (14 tests) — end-before-start, double-end, double-start, store/retrieve without session, invalid domains, empty text
- `tests/test_concurrent_torture.py` (10 tests) — 75 concurrent stores, interleaved store+retrieve, double-delete, concurrent delete, store-after-close, double-close, rapid session cycles
- `tests/test_numerical_boundaries.py` (18 tests) — ResponseCurve with extreme morphogens/steepness, AllostericUpdater stability, cosine similarity edge cases, vitality with 0/0 counts
- `tests/test_lifecycle_simulation.py` (7 tests) — 10-session lifecycle promotion, pruning TTL, pin prevents pruning, association graph growth, health report validation
- `tests/test_llm_failure_injection.py` (9 tests) — TimeoutError, ConnectionError, malformed JSON, empty response, partial JSON, broken LLM retrieve, intermittent failures
- `tests/test_config_boundary_blaster.py` (18 tests) — invalid config rejection (gate, budget, weights, zoom, flush), extreme-valid pipelines, frozen config
- `tests/test_schema_migration_gauntlet.py` (8 tests) — v1→v6 and v3→v6 migration with data preservation, fresh DB schema, double-initialize idempotency
- `tests/test_association_graph_integrity.py` (13 tests) — self-loop prevention, edge deduplication, weight bounds, orphan cleanup, edge cap, weak edge pruning, decay, stats
- `tests/test_health_report_truth.py` (11 tests) — empty system defaults, total_memories accuracy, system_state validity, field type bounds, morphogen convergence keys
- `issues_all.md` — deep bug-hunting report documenting all findings

## [0.3.1] - 2026-04-10

### Release Notes

**Title:** v0.3.1 — Bug fixes + PyPI packaging

**GitHub Release Body:**

> ## What's new
>
> ### Bug fixes
> - Fixed 31 validated issues across all phases (storage, associations, consolidation, dreaming, self-model, apoptosis)
> - Fixed scoring weight validation (cosine + intensity must sum to 1.0)
> - Fixed chronic memory query compatibility
> - Fixed edge weight clamping in associations
> - Fixed scar tissue TTL tracking
>
> ### Packaging
> - Added PyPI-optimized README with absolute image URLs
> - Added CHANGELOG.md, SECURITY.md, CONTRIBUTING.md
> - Added `py.typed` marker for type checker support
>
> ### Install
>
> ```bash
> pip install fractal-memory==0.3.1
>
> # With dashboard:
> pip install "fractal-memory[dashboard]==0.3.1"
> ```
>
> Full changelog: https://github.com/entropyvector/fractal-memory/blob/main/CHANGELOG.md

### Fixed

**Batch 1 — Critical**
- Fix `get_summary_stats()` key mismatch (`memories`→`total_memories`, `sessions`→`total_sessions`) in folding regime consumer
- Fix `self._row_to_memory()` → module-level `_row_to_memory()` in storage (2 call sites)
- Fix `apoptosis.py` TYPE_CHECKING import `scars` → `scar`
- Fix `execute_apoptosis()` 4 silent failures: LLM `generate()`→`complete()`, remove `.tolist()` on list, `weaken_edge()`→`adjust_edge_weight()`, fix `create_scar()` signature
- Add `prune_expired()` and `merge_duplicates()` public methods to `ConsolidationEngine`

**Batch 2 — High severity**
- Fix dreaming REM `generate()`→`complete()` with XML security delimiters
- Add `prune_below()` SQL DELETE to `AssociationNetwork` (replaces missing method)
- Fix `SelfModel.health()` calling non-existent `list_domains()` → `list_domains_with_stats()`
- Fix `SelfModel.health()` reading wrong keys from `get_stats()` (`nodes`→`nodes_with_edges`, `edges`→`edge_count`)
- Initialize `_current_session_id` in `ConsolidationEngine.__init__`
- Add `WHERE sessions_elapsed < ttl_sessions` filter to `count_active_scars()`
- Create `morphogen_history` table (schema version 5) with `save_morphogen_state()` / `get_morphogen_history()`
- Implement Pioneer→Shrub config transition with `_propagate_config()` applying to all 15 subsystems

**Batch 3 — Medium severity**
- Add `token_budget` validation: `is None` check respects `0`, negative raises `ValueError`
- Add `FractalConfig.__post_init__` range validation for 9 fields with weight-sum check
- Add NaN/Inf embedding validation in `_pack_embedding()`
- Add `acreate_memory()` async factory function
- Replace hardcoded `get_session_stats()` with real SQL query on `session_summaries` (bounded by 90 days)
- Replace `datetime.utcnow()` with `_compat.utcnow()` across all 13 source files
- CLI `session end` → print "not supported" message (exit code 1)
- CLI `store` → wrap in micro-session (`session_start` / `session_end`)

**Batch 4 — Low severity**
- Store warmup task reference to prevent garbage collection
- Fix `DreamReport.dawn` type annotation: `DawnReport | None = None`
- Use `getattr` fallback for deprecated `get_sentence_embedding_dimension()`
- Add `__version__` attribute via `importlib.metadata`
- Remove early activity flush clause (`total_ops <= interval`)
- Add `GateDecision.embedding` field, reuse in `store()` to avoid redundant embed call
- Add tier overlap docstring to `retrieve()`

### Added
- `fractal_memory._compat` module with `utcnow()` helper for naive UTC timestamps
- `acreate_memory()` async factory exported in `__all__`
- `__version__` package attribute sourced from `pyproject.toml`
- `AssociationNetwork.prune_below()` for SQL-level edge cleanup
- `ConsolidationEngine.prune_expired()` and `merge_duplicates()` public delegates
- `GateDecision.embedding` optional field for gate-to-store embedding reuse
- `morphogen_history` table (schema version 5)

### Security
- XML delimiters around memory content in LLM prompts (apoptosis, dreaming) to prevent prompt injection
- NaN/Inf validation on all embedding storage paths
- Config validation prevents out-of-range parameter values

### Changed
- CLI `session end` now returns exit code 1 with explanation (not supported without persistent process)
- CLI `store` creates a micro-session for proper lifecycle hook activation
- README install instructions: `pip install -e` → `pip install`, added `pipx` option

### Removed
- Internal tooling scripts from `docs/` directory (`seed_demo_data.py`, `take_screenshots.py`)

## [0.3.0] - 2026-04-07

### Added

**Phase 1 — Pioneer**
- `FractalMemory` core class with async `store()`, `retrieve()`, `session_start()`, `session_end()`
- 5-level zoom system (L0 tag → L1 label → L2 summary → L3 full → L4 raw)
- Token-budgeted retrieval: top 200 as labels, top 50 as summaries, top 10 as full context
- Memory lifecycle: probation → confirmed → permanent → safety-critical
- Intensity-weighted storage with automatic gating
- Session bootstrap with prior context injection
- Sentence-transformer embeddings with cosine similarity scoring

**Phase 2 — Shrub**
- Association graph: edges form between co-retrieved memories, weights decay over time
- Scar tissue: corrections leave permanent repair markers, penalize future retrieval
- Kintsugi: golden seams on corrected memories (visible in dashboard)
- Consolidation engine: merge similar memories, strengthen edges, expire scars
- Danger theory: feedback signals from user messages (surprise, contradiction, resolution)
- LLM judge: rates memory usefulness at session end
- Multi-domain support with domain isolation
- 19-page real-time dashboard (FastAPI + Chart.js + D3.js)

**Phase 3 — Forest**
- Morphogenetic self-calibration: adaptive sigmoid response curves per parameter
- System states: FLOW / STRESS / CURIOSITY state machine with parameter multipliers
- Contextual bandits: Thompson sampling for retrieval strategy selection
- Dreaming: slow-wave consolidation + REM recombination at session end
- Apoptosis: controlled pruning of low-vitality memories with fragment salvage
- Niche construction: Louvain clustering for domain reorganization proposals
- Cascade detector: Extended Kalman Filter for system health prediction
- Dimensional folding: operational regime detection (BOOTSTRAP → LEARNING → MATURE)
- Maintenance scheduler: tiered (intra-session, daily, weekly, monthly) background maintenance
- Self-model: organism health metrics, parameter drift detection
- MCP server with auto-session management and dashboard co-launch
- CLI (`fractal`) with store, retrieve, inspect, export, health, maintenance commands

### Security
- SQL injection protection via parameterized queries throughout
- Input validation on all public API boundaries
- Domain name sanitization (alphanumeric + hyphens/underscores/dots only)
