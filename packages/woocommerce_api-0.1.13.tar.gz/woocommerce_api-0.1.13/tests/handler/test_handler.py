import pytest
import requests_mock.adapter
from woocommerce.handler_base import HandlerBase
from dataclasses import dataclass
import requests
import requests_mock

@pytest.fixture
def adapter():
    adapter = requests_mock.Adapter()
    yield adapter

@pytest.fixture
def mock_session(adapter):
    print("Setting up mock session")
    session = requests.Session()
    session.mount("https://", adapter)
    yield session


class TestHandler(HandlerBase):
    handler_type = "mock"

@pytest.fixture
def handler(mock_session):
    print("Creating base class...")
    handler = TestHandler(
        "https://test.com/",
        ("user","psw"),
        session=mock_session
    )
    yield handler
    print("Tearing down....")

def test_retrieve(handler: TestHandler, adapter):
    mock_data = [{"id":1,"name":"Mock","slug":"mock"}]
    adapter.register_uri('GET', 'https://test.com/wp-json/wc/v3/products/mock', json=mock_data)

    result = handler.retrieve()
    assert result == mock_data

def test_retrieve_single(handler: TestHandler, adapter):
    mock_data = {"id":1,"name":"Mock","slug":"mock"}
    adapter.register_uri('GET', 'https://test.com/wp-json/wc/v3/products/mock/1', json=mock_data)

    result = handler.retrieve_single(1)
    assert result == mock_data

def test_create(handler: TestHandler, adapter):
    mock_data = {"id":1,"name":"Mock","slug":"mock"}
    adapter.register_uri('POST', 'https://test.com/wp-json/wc/v3/products/mock', json=mock_data)

    result = handler.create(mock_data)
    assert result == mock_data

def test_delete(handler: TestHandler, adapter):
    mock_data = {"id":1,"name":"Mock","slug":"mock"}
    adapter.register_uri('DELETE', 'https://test.com/wp-json/wc/v3/products/mock/1', json=mock_data)

    result = handler.delete(1)
    assert result == mock_data

def test_batch_update(handler: TestHandler, adapter):
    mock_data = {
        "create": [
            {"id":1,"name":"Mock","slug":"mock"}
        ],
        "update":[
            {"id":2,"name":"Mock2","slug":"mock"}
        ],
        "delete":[
            {"id":3,"name":"Mock3","slug":"mock"}
        ]
    }
    adapter.register_uri("POST",'https://test.com/wp-json/wc/v3/products/mock/batch', json=mock_data)

    res = handler.batch_update(mock_data["create"],mock_data["update"], [3])
    assert res == mock_data

