from dataclasses import dataclass

@dataclass
class ImageProperties:

    id: int
    src: str
    name: str
    alt: str