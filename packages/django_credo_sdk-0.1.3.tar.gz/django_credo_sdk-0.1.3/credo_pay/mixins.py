"""
Django model mixin for Credo payments.
"""

from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional

from django.db import models, transaction

from .client import CredoClient
from .models import PaymentResponse, VerifyResponse


class CredoBaseMixin:
    """Shared lazy Credo client."""

    _credo_client: Optional[CredoClient] = None

    @property
    def credo_client(self) -> CredoClient:
        if self._credo_client is None:
            self._credo_client = CredoClient()
        return self._credo_client


class CredoPaymentMixin(CredoBaseMixin):
    """
    Mixin that adds Credo payment support to any Django model.

    Override the two required methods, then override whichever lifecycle
    hooks you need. Everything else has sensible defaults and can be
    ignored until you need it.

    Minimal example::

        class Order(CredoPaymentMixin, models.Model):
            amount     = models.DecimalField(max_digits=12, decimal_places=2)
            email      = models.EmailField()
            credo_ref  = models.CharField(max_length=64, blank=True)
            status     = models.CharField(max_length=20, default='pending')

            # --- required ---

            def get_payment_amount(self):
                return self.amount

            def get_payment_email(self):
                return self.email

            # --- required for sync_payment_status() ---

            def get_credo_trans_ref(self):
                return self.credo_ref or None

            # --- hooks: override only what you need ---

            def on_payment_initiated(self, response):
                self.credo_ref = response.trans_ref or ''
                self.status = 'awaiting_payment'
                self.save(update_fields=['credo_ref', 'status'])

            def on_payment_confirmed(self, verification):
                self.status = 'paid'
                self.save(update_fields=['status'])

            def on_payment_failed(self, verification):
                self.status = 'failed'
                self.save(update_fields=['status'])

    Starting a payment in a view::

        order = get_object_or_404(Order, pk=pk)
        response = order.create_payment()
        return redirect(response.authorization_url)

    Handling a callback or webhook::

        order = Order.objects.get(credo_ref=event.trans_ref)
        order.sync_payment_status()

    Preventing duplicate processing when a callback and a webhook race::

        def on_payment_confirmed(self, verification):
            with self.payment_lock() as locked:
                if locked.status == 'paid':
                    return
                locked.status = 'paid'
                locked.save(update_fields=['status'])

    The mixin delegates to the same CredoClient as the service layer, so
    it is equally powerful. The difference is that service-layer code lives
    in views; mixin-layer code lives in the model, which is often cleaner.
    """

    # ------------------------------------------------------------------
    # Required — implement these two
    # ------------------------------------------------------------------

    def get_payment_amount(self) -> Any:
        """Amount to charge in the currency's main unit (e.g. Naira for NGN)."""
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_payment_amount()"
        )

    def get_payment_email(self) -> str:
        """Customer's email address."""
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_payment_email()"
        )

    # ------------------------------------------------------------------
    # Optional — override to supply stored references or customise init
    # ------------------------------------------------------------------

    def get_credo_trans_ref(self) -> Optional[str]:
        """
        Return the Credo trans_ref stored on this object, or None.

        Required only if you call sync_payment_status() without passing
        trans_ref explicitly.
        """
        return None

    def get_payment_callback_url(self) -> Optional[str]:
        return self.credo_client.config.default_callback_url or None

    def get_payment_reference(self) -> Optional[str]:
        """Pre-built business reference, or None to let the SDK generate one."""
        return None

    def get_payment_currency(self) -> Optional[str]:
        return None

    def get_payment_channels(self) -> Optional[List[str]]:
        return None

    def get_payment_bearer(self) -> Optional[int]:
        return None

    def get_payment_first_name(self) -> Optional[str]:
        return None

    def get_payment_last_name(self) -> Optional[str]:
        return None

    def get_payment_phone_number(self) -> Optional[str]:
        return None

    def get_payment_service_code(self) -> Optional[str]:
        return None

    def get_payment_bank_account(self) -> Optional[str]:
        return None

    def get_payment_metadata(self) -> Optional[Dict[str, Any]]:
        return None

    def get_payment_custom_fields(self) -> Optional[List[Dict[str, str]]]:
        return None

    # ------------------------------------------------------------------
    # Lifecycle hooks — override to persist state after each event
    # ------------------------------------------------------------------

    def on_payment_initiated(self, response: PaymentResponse) -> None:
        """
        Called after Credo returns an authorization URL.

        Store response.trans_ref and response.reference here so you can
        look up the order later from a webhook or callback.
        """

    def on_payment_confirmed(self, verification: VerifyResponse) -> None:
        """Called when the payment verifies as successful."""

    def on_payment_failed(self, verification: VerifyResponse) -> None:
        """Called when the payment verifies as failed or declined."""

    def on_payment_pending(self, verification: VerifyResponse) -> None:
        """Called when the payment status is still pending (optional)."""

    # ------------------------------------------------------------------
    # Concurrency helper
    # ------------------------------------------------------------------

    @contextmanager
    def payment_lock(self) -> Iterator["CredoPaymentMixin"]:
        """
        Lock this model row for the duration of a payment state update.

        Use inside your hooks to prevent duplicate processing when a
        callback and a webhook arrive at the same time::

            def on_payment_confirmed(self, verification):
                with self.payment_lock() as locked:
                    if locked.status == 'paid':
                        return          # already processed
                    locked.status = 'paid'
                    locked.save(update_fields=['status'])
        """
        if isinstance(self, models.Model) and self.pk is not None:
            with transaction.atomic():
                locked = self.__class__._default_manager.select_for_update().get(pk=self.pk)
                yield locked
        else:
            yield self

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def create_payment(
        self,
        *,
        callback_url: Optional[str] = None,
        amount: Optional[Any] = None,
        email: Optional[str] = None,
        currency: Optional[str] = None,
        reference: Optional[str] = None,
        channels: Optional[List[str]] = None,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        phone_number: Optional[str] = None,
        service_code: Optional[str] = None,
        bank_account: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        custom_fields: Optional[List[Dict[str, str]]] = None,
        bearer: Optional[int] = None,
    ) -> PaymentResponse:
        """
        Initialize a Credo payment and call on_payment_initiated().

        Keyword arguments override the values returned by get_* methods,
        so you can pass one-off overrides without subclassing::

            response = order.create_payment(callback_url='https://...')
            return redirect(response.authorization_url)

        on_payment_initiated() is called with the Credo response. Store
        response.trans_ref in your model there so sync_payment_status()
        can find the right transaction later.
        """
        response = self.credo_client.initialize_payment(
            amount=amount if amount is not None else self.get_payment_amount(),
            email=email or self.get_payment_email(),
            callback_url=callback_url or self.get_payment_callback_url(),
            currency=currency or self.get_payment_currency(),
            reference=reference or self.get_payment_reference(),
            channels=channels or self.get_payment_channels(),
            first_name=first_name or self.get_payment_first_name(),
            last_name=last_name or self.get_payment_last_name(),
            phone_number=phone_number or self.get_payment_phone_number(),
            service_code=service_code or self.get_payment_service_code(),
            bank_account=bank_account or self.get_payment_bank_account(),
            metadata=metadata if metadata is not None else self.get_payment_metadata(),
            custom_fields=(
                custom_fields if custom_fields is not None
                else self.get_payment_custom_fields()
            ),
            bearer=bearer if bearer is not None else self.get_payment_bearer(),
        )
        self.on_payment_initiated(response)
        return response

    def verify_payment(self, trans_ref: Optional[str] = None) -> VerifyResponse:
        """
        Verify a payment with Credo.

        If trans_ref is omitted, get_credo_trans_ref() is used. Raises
        ValueError when no reference is available from either source.
        """
        ref = trans_ref or self.get_credo_trans_ref()
        if not ref:
            raise ValueError(
                f"{self.__class__.__name__}.get_credo_trans_ref() returned None "
                "and no trans_ref was passed to verify_payment(). "
                "Override get_credo_trans_ref() to return the stored trans_ref."
            )
        return self.credo_client.verify_payment(ref)

    def sync_payment_status(self, trans_ref: Optional[str] = None) -> VerifyResponse:
        """
        Verify the payment with Credo and call the appropriate hook.

        Calls on_payment_confirmed(), on_payment_failed(), or
        on_payment_pending() based on what Credo returns.

        Use this in your callback and webhook handlers::

            order = Order.objects.get(credo_ref=trans_ref)
            order.sync_payment_status()

        Or pass the reference explicitly::

            order.sync_payment_status(trans_ref=event.trans_ref)
        """
        verification = self.verify_payment(trans_ref)

        if verification.is_successful:
            self.on_payment_confirmed(verification)
        elif verification.is_failed:
            self.on_payment_failed(verification)
        else:
            self.on_payment_pending(verification)

        return verification
