"""
Short-lived debug event storage for the SDK sandbox UI.

The debug page should show real callbacks and webhooks that reached this Django
process. This module intentionally uses Django's cache instead of database
models so the SDK does not impose migrations on integrators.
"""

from typing import Any, Dict, List, Optional
from uuid import uuid4

from django.core.cache import cache
from django.conf import settings
from django.utils import timezone


DEBUG_EVENTS_CACHE_KEY = "credo_pay:debug_events"
DEBUG_EVENTS_TTL_SECONDS = 60 * 60 * 6
DEBUG_EVENTS_MAX_ITEMS = 25


def debug_events_enabled() -> bool:
    """Return True when the sandbox inbox should collect incoming events."""
    return bool(getattr(settings, "CREDO_ENABLE_DEBUG_EVENTS", getattr(settings, "DEBUG", False)))


def record_debug_event(
    *,
    kind: str,
    outcome: str,
    title: str,
    details: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Record one callback/webhook event for the debug inbox."""
    if not debug_events_enabled():
        return {}

    event = {
        "id": uuid4().hex,
        "kind": kind,
        "outcome": outcome,
        "title": title,
        "details": details or {},
        "received_at": timezone.now(),
    }

    events = cache.get(DEBUG_EVENTS_CACHE_KEY, [])
    events.insert(0, event)
    events = events[:DEBUG_EVENTS_MAX_ITEMS]
    cache.set(DEBUG_EVENTS_CACHE_KEY, events, DEBUG_EVENTS_TTL_SECONDS)
    return event


def get_debug_events(limit: int = DEBUG_EVENTS_MAX_ITEMS) -> List[Dict[str, Any]]:
    """Return newest debug events first."""
    if not debug_events_enabled():
        return []

    events = cache.get(DEBUG_EVENTS_CACHE_KEY, [])
    return events[:limit]
