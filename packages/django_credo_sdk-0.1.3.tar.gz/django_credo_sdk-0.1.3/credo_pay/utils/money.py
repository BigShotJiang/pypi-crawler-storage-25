"""
Money conversion helpers.

The public SDK accepts amounts in the currency's main unit, for example Nigerian
Naira. Credo's initialize endpoint expects the lowest denomination, for example
kobo for NGN.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any

from ..exceptions import CredoValidationError


MINOR_UNIT_MULTIPLIERS = {
    "NGN": Decimal("100"),
    "USD": Decimal("100"),
    "GHS": Decimal("100"),
}


def _decimal(value: Any, field: str = "amount") -> Decimal:
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise CredoValidationError(f"Invalid {field}: {value}", field=field) from exc


def minor_unit_multiplier(currency: str) -> Decimal:
    """Return the minor-unit multiplier for a currency."""
    return MINOR_UNIT_MULTIPLIERS.get((currency or "").upper(), Decimal("100"))


def amount_to_minor_units(amount: Any, currency: str = "NGN") -> int:
    """
    Convert a public SDK amount to Credo's lowest-denomination amount.

    Example:
        amount_to_minor_units(1500, "NGN") == 150000
    """
    major_amount = _decimal(amount)
    if major_amount <= 0:
        raise CredoValidationError("Amount must be greater than 0", field="amount")

    minor_amount = (major_amount * minor_unit_multiplier(currency)).quantize(
        Decimal("1"),
        rounding=ROUND_HALF_UP,
    )
    if minor_amount <= 0:
        raise CredoValidationError("Amount is too small for the selected currency", field="amount")
    return int(minor_amount)


def amount_from_minor_units(amount: Any, currency: str = "NGN") -> Decimal:
    """
    Convert Credo's lowest-denomination amount to the currency's main unit.

    Example:
        amount_from_minor_units(150000, "NGN") == Decimal("1500.00")
    """
    minor_amount = _decimal(amount)
    return (minor_amount / minor_unit_multiplier(currency)).quantize(Decimal("0.01"))
