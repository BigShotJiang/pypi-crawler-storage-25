"""
Reference generation helpers for Credo payments.

Credo transaction references must be unique and alphanumeric. These helpers make
it easy to include a readable product/order prefix while keeping the final value
safe for Credo's API.
"""

import secrets
import string
import time
from typing import Optional

from ..exceptions import CredoValidationError
from .validators import validate_reference


DEFAULT_REFERENCE_PREFIX = "PAY"
DEFAULT_REFERENCE_MAX_LENGTH = 50
DEFAULT_REFERENCE_SUFFIX_LENGTH = 12
REFERENCE_ALPHABET = string.ascii_letters + string.digits


def sanitize_reference_part(value: object, *, uppercase: bool = False) -> str:
    """Return only alphanumeric characters from a user-provided reference part."""
    sanitized = "".join(char for char in str(value or "") if char.isalnum())
    return sanitized.upper() if uppercase else sanitized


def _base36(value: int) -> str:
    digits = string.digits + string.ascii_uppercase
    if value == 0:
        return "0"

    result = ""
    while value:
        value, remainder = divmod(value, 36)
        result = digits[remainder] + result
    return result


def _random_suffix(length: int) -> str:
    return "".join(secrets.choice(REFERENCE_ALPHABET) for _ in range(length))


def generate_payment_reference(
    prefix: Optional[object] = None,
    *,
    suffix_length: int = DEFAULT_REFERENCE_SUFFIX_LENGTH,
    max_length: int = DEFAULT_REFERENCE_MAX_LENGTH,
    uppercase: bool = False,
) -> str:
    """
    Generate a unique, Credo-safe payment reference.

    Args:
        prefix: Readable product/order prefix, e.g. "codex".
        suffix_length: Number of generated characters appended to the prefix.
        max_length: Maximum total reference length.
        uppercase: Convert the prefix and generated suffix to uppercase.

    Returns:
        Alphanumeric reference such as "codexM0L7KQ4P8B2A".
    """
    if suffix_length < 6:
        raise CredoValidationError("suffix_length must be at least 6", field="suffix_length")
    if max_length <= suffix_length:
        raise CredoValidationError("max_length must be greater than suffix_length", field="max_length")

    cleaned_prefix = sanitize_reference_part(prefix or DEFAULT_REFERENCE_PREFIX, uppercase=uppercase)
    if not cleaned_prefix:
        raise CredoValidationError(
            "Reference prefix must contain at least one alphanumeric character",
            field="prefix",
        )

    timestamp = _base36(int(time.time() * 1000))
    random_length = max(suffix_length - len(timestamp), 0)
    suffix = f"{timestamp}{_random_suffix(random_length)}"[-suffix_length:]
    if uppercase:
        suffix = suffix.upper()

    prefix_length = max_length - suffix_length
    reference = f"{cleaned_prefix[:prefix_length]}{suffix}"
    validate_reference(reference)
    return reference
