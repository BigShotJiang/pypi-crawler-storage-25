"""
Callback URL utilities for handling Credo payment redirects.

When Credo completes a payment (success or failure), it redirects
the customer back to your callback URL with query parameters containing
the transaction result.
"""

from urllib.parse import urlencode, urlparse, parse_qs
from typing import Iterable, Optional, Dict, Any
from dataclasses import dataclass

from ..exceptions import CredoValidationError
from .signature import sign_callback_params, verify_callback_signature


@dataclass
class CallbackData:
    """
    Parsed callback data from Credo redirect.
    
    When Credo redirects to your callback URL, it includes these query params:
    - status: Transaction status code (0 = success)
    - errorMessage: Description (e.g., "Approved")
    - transRef: Credo's transaction reference
    - transAmount: Transaction amount
    - currency: Currency code
    - reference: Your business reference
    """
    status: int
    error_message: str
    trans_ref: str
    trans_amount: float
    currency: str
    reference: str
    raw_params: Dict[str, Any]
    
    @property
    def is_successful(self) -> bool:
        """Check if transaction was successful."""
        return self.status == 0
    
    @property
    def is_approved(self) -> bool:
        """Check if transaction was approved."""
        return self.error_message.lower() == "approved"
    
    @classmethod
    def from_url(
        cls,
        url: str,
        *,
        signing_secret: Optional[str] = None,
        require_signature: bool = False,
        signed_fields: Optional[Iterable[str]] = None,
    ) -> "CallbackData":
        """
        Parse callback data from a full URL.

        Args:
            url: Full callback URL with query parameters
            
        Returns:
            CallbackData instance
            
        Example:
            data = CallbackData.from_url(
                "https://example.com/callback?status=0&errorMessage=Approved&transRef=abc123"
            )
        """
        parsed = urlparse(url)
        return cls.from_query_string(
            parsed.query,
            signing_secret=signing_secret,
            require_signature=require_signature,
            signed_fields=signed_fields,
        )

    @classmethod
    def from_query_string(
        cls,
        query_string: str,
        *,
        signing_secret: Optional[str] = None,
        require_signature: bool = False,
        signed_fields: Optional[Iterable[str]] = None,
    ) -> "CallbackData":
        """
        Parse callback data from query string.
        
        Args:
            query_string: Query string without the leading '?'
            
        Returns:
            CallbackData instance
        """
        params = parse_qs(query_string)

        if require_signature or signing_secret:
            if not verify_callback_signature(params, signing_secret or "", signed_fields):
                raise CredoValidationError("Invalid callback signature", field="credo_signature")
        
        # Helper to get first value from list or default
        def get_param(key: str, default: str = "") -> str:
            values = params.get(key, [default])
            return values[0] if values else default

        return cls._from_values(
            status=get_param("status", ""),
            error_message=get_param("errorMessage", ""),
            trans_ref=get_param("transRef", ""),
            trans_amount=get_param("transAmount", "0"),
            currency=get_param("currency", "NGN"),
            reference=get_param("reference", ""),
            raw_params={k: v[0] if len(v) == 1 else v for k, v in params.items()},
        )
    
    @classmethod
    def _from_values(
        cls,
        *,
        status: Any,
        error_message: str,
        trans_ref: str,
        trans_amount: Any,
        currency: str,
        reference: str,
        raw_params: Dict[str, Any],
    ) -> "CallbackData":
        if status in (None, ""):
            raise CredoValidationError("Callback status is required", field="status")
        if not trans_ref:
            raise CredoValidationError("Callback transRef is required", field="transRef")

        try:
            status_value = int(status)
        except (TypeError, ValueError) as exc:
            raise CredoValidationError("Callback status must be an integer", field="status") from exc

        try:
            amount_value = float(trans_amount or 0)
        except (TypeError, ValueError) as exc:
            raise CredoValidationError("Callback transAmount must be numeric", field="transAmount") from exc

        return cls(
            status=status_value,
            error_message=error_message,
            trans_ref=trans_ref,
            trans_amount=amount_value,
            currency=currency or "NGN",
            reference=reference,
            raw_params=raw_params,
        )

    @classmethod
    def from_request(
        cls,
        request,
        *,
        signing_secret: Optional[str] = None,
        require_signature: bool = False,
        signed_fields: Optional[Iterable[str]] = None,
    ) -> "CallbackData":
        """
        Parse callback data from Django request.
        
        Args:
            request: Django HttpRequest or DRF Request
            
        Returns:
            CallbackData instance
            
        Example:
            def callback_view(request):
                data = CallbackData.from_request(request)
                if data.is_successful:
                    # Handle success
                    pass
        """
        # Support both Django and DRF requests
        params = getattr(request, 'query_params', None) or request.GET

        raw_params = dict(params)
        if require_signature or signing_secret:
            if not verify_callback_signature(raw_params, signing_secret or "", signed_fields):
                raise CredoValidationError("Invalid callback signature", field="credo_signature")
        
        return cls._from_values(
            status=params.get("status", ""),
            error_message=params.get("errorMessage", ""),
            trans_ref=params.get("transRef", ""),
            trans_amount=params.get("transAmount", 0),
            currency=params.get("currency", "NGN"),
            reference=params.get("reference", ""),
            raw_params=raw_params,
        )


def build_callback_url(
    base_url: str,
    success_path: Optional[str] = None,
    failure_path: Optional[str] = None,
    extra_params: Optional[Dict[str, str]] = None,
    signing_secret: Optional[str] = None,
    signed_fields: Optional[Iterable[str]] = None,
) -> str:
    """
    Build a callback URL with optional path and parameters.
    
    Note: Credo will append its own query parameters to this URL
    when redirecting the customer back.
    
    Args:
        base_url: Base URL of your site
        success_path: Path for the callback endpoint
        failure_path: Not used (Credo uses same URL for success/failure)
        extra_params: Additional merchant query parameters to include
        signing_secret: Optional HMAC secret for merchant-controlled query params
        signed_fields: Optional explicit merchant fields to sign
        
    Returns:
        Complete callback URL
        
    Example:
        url = build_callback_url(
            "https://example.com",
            success_path="/payment/complete/",
            extra_params={"order_id": "12345"}
        )
        # Returns: https://example.com/payment/complete/?order_id=12345
    """
    # Remove trailing slash from base
    base_url = base_url.rstrip("/")
    
    # Add path
    if success_path:
        path = success_path.strip("/")
        url = f"{base_url}/{path}/"
    else:
        url = f"{base_url}/"
    
    # Add extra params
    if extra_params:
        if signing_secret:
            extra_params = sign_callback_params(extra_params, signing_secret, signed_fields)
        url = f"{url}?{urlencode(extra_params)}"
    
    return url
