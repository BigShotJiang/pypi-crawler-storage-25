"""
Signature utilities for webhook verification.

Implements SHA512 signature verification as specified by Credo.
"""

import hashlib
import hmac
from typing import Any, Dict, Iterable, List, Optional


CALLBACK_SIGNATURE_PARAM = "credo_signature"
CALLBACK_SIGNED_FIELDS_PARAM = "credo_signed_fields"
CALLBACK_UNSIGNED_FIELDS = {
    "status",
    "errorMessage",
    "transRef",
    "transAmount",
    "currency",
    "reference",
    CALLBACK_SIGNATURE_PARAM,
    CALLBACK_SIGNED_FIELDS_PARAM,
}


def generate_webhook_signature(token: str, business_code: str) -> str:
    """
    Generate webhook signature for verification.
    
    The signature is SHA512(token + business_code) as per Credo documentation.
    
    Args:
        token: Webhook token configured on the Credo dashboard
        business_code: businessCode from the Credo webhook payload
        
    Returns:
        SHA512 hash string
    """
    content = f"{token}{business_code}"
    return hashlib.sha512(content.encode()).hexdigest()


def verify_webhook_signature(
    received_signature: str,
    token: str,
    business_code: str
) -> bool:
    """
    Verify that a webhook signature is valid.
    
    Args:
        received_signature: The X-Credo-Signature header value
        token: Webhook token configured on the Credo dashboard
        business_code: businessCode from the Credo webhook payload
        
    Returns:
        True if signature is valid, False otherwise
    """
    if not received_signature or not token or not business_code:
        return False
    
    expected_signature = generate_webhook_signature(token, business_code)
    
    # Use constant-time comparison to prevent timing attacks
    return hmac.compare_digest(
        received_signature.lower(),
        expected_signature.lower()
    )


def _first_value(value: Any) -> str:
    if isinstance(value, (list, tuple)):
        return "" if not value else str(value[0])
    return "" if value is None else str(value)


def _canonical_callback_payload(
    params: Dict[str, Any],
    signed_fields: Iterable[str],
) -> str:
    parts: List[str] = []
    for field in sorted(set(signed_fields)):
        parts.append(f"{field}={_first_value(params.get(field, ''))}")
    return "&".join(parts)


def default_callback_signed_fields(params: Dict[str, Any]) -> List[str]:
    """
    Return merchant-controlled callback fields that can be signed before redirect.

    Credo appends its own redirect fields after payment, so those fields cannot be
    authenticated by a merchant-generated HMAC. They still must be verified with
    verify_payment().
    """
    return sorted(k for k in params if k not in CALLBACK_UNSIGNED_FIELDS)


def generate_callback_signature(
    params: Dict[str, Any],
    secret: str,
    signed_fields: Optional[Iterable[str]] = None,
) -> str:
    """Generate an HMAC-SHA256 signature for merchant callback parameters."""
    if not secret:
        raise ValueError("Callback signing secret is required")

    fields = list(signed_fields) if signed_fields is not None else default_callback_signed_fields(params)
    payload = _canonical_callback_payload(params, fields)
    return hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()


def sign_callback_params(
    params: Dict[str, Any],
    secret: str,
    signed_fields: Optional[Iterable[str]] = None,
) -> Dict[str, Any]:
    """Return callback params with credo_signature and credo_signed_fields added."""
    signed = dict(params)
    fields = list(signed_fields) if signed_fields is not None else default_callback_signed_fields(signed)
    signed[CALLBACK_SIGNED_FIELDS_PARAM] = ",".join(sorted(set(fields)))
    signed[CALLBACK_SIGNATURE_PARAM] = generate_callback_signature(signed, secret, fields)
    return signed


def verify_callback_signature(
    params: Dict[str, Any],
    secret: str,
    signed_fields: Optional[Iterable[str]] = None,
) -> bool:
    """Verify a merchant-generated callback parameter signature."""
    if not params or not secret:
        return False

    received_signature = _first_value(params.get(CALLBACK_SIGNATURE_PARAM))
    if not received_signature:
        return False

    if signed_fields is None:
        encoded_fields = _first_value(params.get(CALLBACK_SIGNED_FIELDS_PARAM))
        signed_fields = [field for field in encoded_fields.split(",") if field] if encoded_fields else None

    expected_signature = generate_callback_signature(params, secret, signed_fields)
    return hmac.compare_digest(received_signature.lower(), expected_signature.lower())
