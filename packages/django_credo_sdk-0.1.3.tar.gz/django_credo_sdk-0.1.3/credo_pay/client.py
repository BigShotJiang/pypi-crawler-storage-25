"""
Main Credo client class.

Provides a unified interface for all Credo SDK operations.
"""

from typing import Optional, List, Dict, Any, Callable, Union

from .config import CredoConfig
from .services.payment import PaymentService
from .services.webhook import WebhookService
from .idempotency import PaymentEventResult, PaymentHandler, PaymentLock, process_payment_event
from .utils.reference import generate_payment_reference
from .models import (
    PaymentResponse,
    VerifyResponse,
    WebhookEvent,
)


class CredoClient:
    """
    Main client for interacting with Credo Payment Gateway.
    
    Provides a simple, unified interface for:
    - Initializing payments
    - Verifying transactions
    - Handling webhooks
    - Payment routing with service codes
    
    Usage:
        # Initialize with Django settings
        client = CredoClient()
        
        # Or with custom config
        config = CredoConfig(
            public_key="your-public-key",
            secret_key="your-secret-key",
            environment="sandbox"
        )
        client = CredoClient(config)
        
        # Initialize a payment
        response = client.initialize_payment(
            amount=15000,
            email="customer@example.com",
            callback_url="https://yoursite.com/api/credo/callback-webhook/"
        )
        
        # Redirect customer to payment page
        redirect_url = response.authorization_url
        
        # Later, verify the payment
        result = client.verify_payment(response.trans_ref)
        if result.is_successful:
            print("Payment confirmed!")
    """
    
    def __init__(self, config: Optional[CredoConfig] = None):
        """
        Initialize Credo client.
        
        Args:
            config: Optional CredoConfig instance. If not provided,
                   configuration is loaded from Django settings.
        """
        if config is None:
            config = CredoConfig.from_django_settings()
        
        config.validate()
        
        self.config = config
        self._payment_service = PaymentService(config)
        self._webhook_service = WebhookService(config)
    
    # ==================== Payment Methods ====================
    
    def initialize_payment(
        self,
        amount: float,
        email: str,
        callback_url: Optional[str] = None,
        currency: Optional[str] = None,
        reference: Optional[str] = None,
        reference_prefix: Optional[object] = None,
        channels: Optional[List[str]] = None,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        phone_number: Optional[str] = None,
        service_code: Optional[str] = None,
        bank_account: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        custom_fields: Optional[List[Dict[str, str]]] = None,
        bearer: Optional[int] = None,
    ) -> PaymentResponse:
        """
        Initialize a payment transaction.
        
        Creates a payment session and returns a URL to redirect
        the customer to complete payment.
        
        Args:
            amount: Amount to charge in the currency's main unit, e.g., 15000 for ₦15,000.
                    The SDK sends NGN to Credo as kobo.
            email: Customer's email address
            callback_url: URL to redirect after payment
            currency: Currency code (uses CREDO_DEFAULT_CURRENCY when omitted)
            reference: Your unique reference (auto-generated if not provided)
            reference_prefix: Optional readable prefix for generated reference
            channels: Payment channels ['card', 'bank'] or subset
            first_name: Customer's first name
            last_name: Customer's last name
            phone_number: Customer's phone number
            service_code: Service code for payment routing
            bank_account: Bank account for payment routing
            metadata: Additional data to store with transaction
            custom_fields: Custom field list for metadata
            bearer: Who pays fees (0 = customer, 1 = merchant)
            
        Returns:
            PaymentResponse with authorization_url to redirect customer
            
        Example:
            response = client.initialize_payment(
                amount=15000,
                email="john@example.com",
                callback_url="https://yoursite.com/api/credo/callback-webhook/"
            )
            
            # Redirect to response.authorization_url
        """
        return self._payment_service.initialize(
            amount=amount,
            email=email,
            callback_url=callback_url,
            currency=currency,
            reference=reference,
            reference_prefix=reference_prefix,
            channels=channels,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            service_code=service_code,
            bank_account=bank_account,
            metadata=metadata,
            custom_fields=custom_fields,
            bearer=bearer,
        )
    
    def verify_payment(self, reference: str) -> VerifyResponse:
        """
        Verify a payment transaction status.
        
        Use this to confirm payment status after callback or webhook.
        
        Args:
            reference: Transaction reference (transRef from Credo)
            
        Returns:
            VerifyResponse with transaction details and status
            
        Example:
            result = client.verify_payment("JunW00GkHm01vo0N96pk")
            
            if result.is_successful:
                print(f"Paid: {result.trans_amount} {result.currency_code}")
            elif result.is_failed:
                print(f"Failed: {result.status_description}")
        """
        return self._payment_service.verify(reference)
    
    def initialize_routed_payment(
        self,
        amount: float,
        email: str,
        service_code: str,
        bank_account: str,
        callback_url: Optional[str] = None,
        **kwargs
    ) -> PaymentResponse:
        """
        Initialize a payment routed to a specific destination.
        
        Use this for multi-destination payment scenarios like:
        - Property management (tenants paying to different property accounts)
        - Marketplace payouts
        - Split payments
        
        Args:
            amount: Amount to charge
            email: Customer's email
            service_code: Service code for routing (from Credo dashboard)
            bank_account: Destination bank account number
            callback_url: Redirect URL after payment
            **kwargs: Additional arguments (first_name, last_name, etc.)
            
        Returns:
            PaymentResponse with authorization_url
            
        Example:
            # Tenant paying rent for Property A
            response = client.initialize_routed_payment(
                amount=150000,  # ₦150,000; SDK sends 15,000,000 kobo to Credo
                email="tenant@example.com",
                service_code="PROPERTY_A_SERVICE_CODE",
                bank_account="0123456789",
                callback_url="https://yoursite.com/api/credo/callback-webhook/",
                first_name="John",
                last_name="Tenant"
            )
        """
        return self._payment_service.initialize_routed_payment(
            amount=amount,
            email=email,
            service_code=service_code,
            bank_account=bank_account,
            callback_url=callback_url,
            **kwargs
        )
    
    # ==================== Webhook Methods ====================
    
    def verify_webhook_signature(self, signature: str, business_code: str) -> bool:
        """
        Verify a webhook signature.
        
        Args:
            signature: X-Credo-Signature header value
            business_code: data.businessCode from Credo's webhook payload
            
        Returns:
            True if signature is valid
        """
        return self._webhook_service.verify_signature(signature, business_code)
    
    def parse_webhook(
        self,
        payload: Union[bytes, str, Dict[str, Any]]
    ) -> WebhookEvent:
        """
        Parse a webhook payload into WebhookEvent object.
        
        Args:
            payload: Raw webhook payload
            
        Returns:
            Parsed WebhookEvent
        """
        return self._webhook_service.parse_event(payload)
    
    def process_webhook(
        self,
        payload: Union[bytes, str, Dict[str, Any]],
        signature: str,
        verify: bool = True,
        use_payload_business_code: bool = False
    ) -> WebhookEvent:
        """
        Process a complete webhook request.
        
        Verifies signature, parses payload, and runs registered handlers.
        
        Args:
            payload: Raw webhook payload
            signature: X-Credo-Signature header value
            verify: Whether to verify signature (default: True)
            use_payload_business_code: Kept for API clarity. The SDK always
                                       extracts businessCode from Credo's payload
                                       when verification is enabled.
            
        Returns:
            Parsed WebhookEvent
            
        Example:
            event = client.process_webhook(
                payload=request.body,
                signature=request.headers.get("X-Credo-Signature"),
            )
            
            if event.is_successful:
                order = Order.objects.get(reference=event.business_ref)
                order.mark_paid()
        """
        return self._webhook_service.process_webhook(
            payload, signature, verify, use_payload_business_code
        )
    
    def register_webhook_handler(
        self,
        event_type: str,
        handler: Callable[[WebhookEvent], None]
    ) -> None:
        """
        Register a handler for webhook events.
        
        Args:
            event_type: Event type to handle:
                - 'transaction.successful'
                - 'transaction.failed'
                - 'transaction.settlement.success'
            handler: Function that receives WebhookEvent
            
        Example:
            def on_payment_success(event):
                order = Order.objects.get(reference=event.business_ref)
                order.status = "paid"
                order.save()
            
            client.register_webhook_handler(
                "transaction.successful",
                on_payment_success
            )
        """
        self._webhook_service.register_handler(event_type, handler)

    def process_payment_event(
        self,
        *,
        reference: str,
        event: Union[VerifyResponse, WebhookEvent],
        on_success: PaymentHandler,
        on_failure: PaymentHandler,
        on_pending: Optional[PaymentHandler] = None,
        lock: Optional[PaymentLock] = None,
        terminal_field: Optional[str] = None,
        terminal_values: Optional[List[Any]] = None,
        on_commit: Optional[Callable[..., Any]] = None,
    ) -> PaymentEventResult:
        """
        Run payment handlers in an idempotency-safe database transaction.

        Pass lock=model_payment_lock(YourModel, lookup_field="credo_trans_ref") to
        lock the row before the handler updates it.

        terminal_field / terminal_values — skip the handler if the locked object
        is already in a terminal state (e.g. status already "paid").

        on_commit — called after the transaction commits, for side effects like
        confirmation emails that must not run if the transaction rolls back.
        """
        return process_payment_event(
            reference=reference,
            event=event,
            on_success=on_success,
            on_failure=on_failure,
            on_pending=on_pending,
            lock=lock,
            terminal_field=terminal_field,
            terminal_values=terminal_values,
            on_commit=on_commit,
        )
    
    # ==================== Utility Methods ====================
    
    def generate_reference(self) -> str:
        """Generate a unique transaction reference."""
        return self._payment_service.generate_reference()

    def generate_payment_reference(
        self,
        prefix: Optional[object] = None,
        *,
        suffix_length: int = 12,
        max_length: int = 50,
        uppercase: bool = False,
    ) -> str:
        """
        Generate a Credo-safe reference with an optional readable prefix.

        Example:
            client.generate_payment_reference("codex")
            # "codexM0L7KQ4P8B2A"
        """
        return generate_payment_reference(
            prefix=prefix,
            suffix_length=suffix_length,
            max_length=max_length,
            uppercase=uppercase,
        )
    
    @property
    def is_production(self) -> bool:
        """Check if client is configured for production."""
        return self.config.is_production
    
    @property
    def inline_script_url(self) -> str:
        """Get the Credo inline payment script URL."""
        return self.config.inline_script_url
