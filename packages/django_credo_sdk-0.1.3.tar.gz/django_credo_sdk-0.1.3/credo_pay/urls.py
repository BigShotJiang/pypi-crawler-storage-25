"""
URL patterns for the Credo SDK.

Include in your project:

    from django.urls import include, path

    urlpatterns = [
        path("api/credo/", include("credo_pay.urls")),
    ]

The callback-webhook endpoint is always registered and requires no DRF.
Payment API endpoints (initialize, verify) and debug views are registered
only when djangorestframework is installed.
"""

from django.urls import path

from .views.debug import (
    DebugConfigCheckView,
    DebugInitializePaymentView,
    DebugInterfaceView,
    DebugVerifyPaymentView,
    DebugWebhookEventsView,
)
from .views.django import DjangoCredoWebhookView

app_name = "credo_pay"

# Always available — pure Django, no DRF dependency.
urlpatterns = [
    path(
        "callback-webhook/",
        DjangoCredoWebhookView.as_view(),
        name="callback-webhook",
    ),
    # Debug interface — gated by DEBUG=True or CREDO_ENABLE_DEBUG_INTERFACE=True.
    path("debug/", DebugInterfaceView.as_view(), name="debug-interface"),
    path("debug/config-check/", DebugConfigCheckView.as_view(), name="debug-config-check"),
    path("debug/initialize/", DebugInitializePaymentView.as_view(), name="debug-initialize"),
    path("debug/verify/", DebugVerifyPaymentView.as_view(), name="debug-verify"),
    path("debug/webhook/", DebugWebhookEventsView.as_view(), name="debug-webhook"),
]

# DRF endpoints — only registered when djangorestframework is installed.
try:
    from .views.drf import (
        CredoWebhookView,
        PaymentInitializeView,
        PaymentVerifyView,
        RoutedPaymentInitializeView,
    )

    urlpatterns += [
        path("initialize/", PaymentInitializeView.as_view(), name="payment-initialize"),
        path(
            "routed/initialize/",
            RoutedPaymentInitializeView.as_view(),
            name="routed-payment-initialize",
        ),
        path(
            "verify/<str:reference>/",
            PaymentVerifyView.as_view(),
            name="payment-verify",
        ),
    ]
except ImportError:
    pass
