"""
Webhook service for handling Credo webhook events.

Provides signature verification and event parsing.

Webhook Events (per Credo docs):
- transaction.successful: Payment was successful (status=0)
- transaction.failed: Payment declined (status=7)
- transaction.settlement.success: Settlement completed (status=5)

Signature Verification:
X-Credo-Signature = SHA512(WEBHOOK_TOKEN + BUSINESS_CODE)
"""

import json
from typing import Callable, Dict, Any, Optional, Union

from ..config import CredoConfig
from ..models import WebhookEvent
from ..exceptions import CredoWebhookError
from ..utils.signature import verify_webhook_signature


class WebhookService:
    """
    Service for handling Credo webhooks.
    
    Provides methods for verifying webhook signatures and
    parsing webhook payloads into typed objects.
    
    Webhook Structure (per Credo docs):
    {
        "event": "transaction.successful",
        "data": {
            "businessCode": "700607002190001",
            "transRef": "cI9H00N2AB02Qb0s69Mj",
            "businessRef": "PL1683423455304ATm",
            "debitedAmount": 1000.0,
            "transAmount": 1000.0,
            "transFeeAmount": 15.0,
            "settlementAmount": 985.0,
            "customerId": "email@example.com",
            "transactionDate": "May 7, 2023, 1:37:53 AM",
            "channelId": 1,
            "currencyCode": "NGN",
            "status": 0,
            "paymentMethodType": "MasterCard",
            "paymentMethod": "Card",
            "customer": {
                "customerEmail": "john.wick@yahoo.com",
                "firstName": "John",
                "lastName": "Wick",
                "phoneNo": "23470122199999"
            }
        }
    }
    
    Usage:
        config = CredoConfig.from_django_settings()
        webhook_service = WebhookService(config)
        
        # In your webhook view
        def webhook_view(request):
            signature = request.headers.get("X-Credo-Signature")
            
            event = webhook_service.process_webhook(
                request.body,
                signature=signature,
            )
            
            if event.is_successful:
                # Handle successful payment
                pass
    """
    
    def __init__(self, config: CredoConfig):
        """
        Initialize webhook service.
        
        Args:
            config: CredoConfig instance with webhook credentials
        """
        self.config = config
        self._handlers: Dict[str, Callable[[WebhookEvent], None]] = {}
    
    def verify_signature(self, received_signature: str, business_code: Optional[str] = None) -> bool:
        """
        Verify webhook signature.
        
        Per Credo docs: X-Credo-Signature = SHA512(Token + Business_code)
        
        Args:
            received_signature: The X-Credo-Signature header value
            business_code: Credo business code from the webhook payload
            
        Returns:
            True if signature is valid
            
        Raises:
            CredoWebhookError: If verification credentials are missing
        """
        if not self.config.webhook_token:
            raise CredoWebhookError(
                "Webhook token not configured. "
                "Set CREDO_WEBHOOK_SECRET_TOKEN in settings. "
                "This is a token you create and register in Credo Dashboard > Settings > Webhooks."
            )
        
        if not business_code:
            return False
        
        return verify_webhook_signature(
            received_signature=received_signature,
            token=self.config.webhook_token,
            business_code=business_code,
        )
    
    def verify_signature_from_payload(self, received_signature: str, payload: Dict[str, Any]) -> bool:
        """
        Verify webhook signature using business code from the payload.
        
        Credo includes businessCode in every webhook payload, so SDK views use
        this method instead of asking integrators to configure it.
        
        Args:
            received_signature: The X-Credo-Signature header value
            payload: The parsed webhook payload (must contain data.businessCode)
            
        Returns:
            True if signature is valid
        """
        if not self.config.webhook_token:
            raise CredoWebhookError(
                "Webhook token not configured. Set CREDO_WEBHOOK_SECRET_TOKEN in settings."
            )
        
        # Extract business code from payload
        data = payload.get("data", {})
        business_code = data.get("businessCode", "")
        
        if not business_code:
            raise CredoWebhookError(
                "Business code not found in webhook payload. Cannot verify signature."
            )
        
        return verify_webhook_signature(
            received_signature=received_signature,
            token=self.config.webhook_token,
            business_code=business_code,
        )
    
    def parse_event(self, payload: Union[bytes, str, Dict[str, Any]]) -> WebhookEvent:
        """
        Parse webhook payload into WebhookEvent object.
        
        Args:
            payload: Raw webhook payload (bytes, string, or dict)
            
        Returns:
            Parsed WebhookEvent object
            
        Raises:
            CredoWebhookError: If payload is invalid
        """
        try:
            if isinstance(payload, bytes):
                data = json.loads(payload.decode("utf-8"))
            elif isinstance(payload, str):
                data = json.loads(payload)
            else:
                data = payload
            
            return WebhookEvent.from_payload(data)
            
        except json.JSONDecodeError as e:
            raise CredoWebhookError(f"Invalid JSON payload: {str(e)}")
        except Exception as e:
            raise CredoWebhookError(f"Failed to parse webhook: {str(e)}")
    
    def register_handler(
        self,
        event_type: str,
        handler: Callable[[WebhookEvent], None]
    ) -> None:
        """
        Register a handler for a specific event type.
        
        Available event types (per Credo docs):
        - transaction.successful: Payment was successful
        - transaction.failed: Payment was declined
        - transaction.settlement.success: Settlement completed
        
        Args:
            event_type: Event type to handle
            handler: Callable that takes a WebhookEvent
            
        Example:
            def handle_success(event):
                print(f"Payment successful: {event.trans_ref}")
                # Update order status, send confirmation email, etc.
            
            webhook_service.register_handler(
                "transaction.successful",
                handle_success
            )
        """
        self._handlers[event_type] = handler
    
    def handle_event(self, event: WebhookEvent) -> bool:
        """
        Handle a webhook event using registered handlers.
        
        Args:
            event: Parsed WebhookEvent object
            
        Returns:
            True if handler was found and executed
        """
        handler = self._handlers.get(event.event)
        
        if handler:
            handler(event)
            return True
        
        return False
    
    def process_webhook(
        self,
        payload: Union[bytes, str, Dict[str, Any]],
        signature: str,
        verify: bool = True,
        use_payload_business_code: bool = False
    ) -> WebhookEvent:
        """
        Process a complete webhook request.
        
        Combines signature verification, parsing, and handler execution.
        
        Per Credo docs, businessCode is included in every webhook payload, so
        this method extracts it from the payload for signature verification.
        
        Args:
            payload: Raw webhook payload
            signature: X-Credo-Signature header value
            verify: Whether to verify signature (default: True)
            use_payload_business_code: Kept for API clarity. Signature
                                       verification always uses payload
                                       businessCode in this SDK.
            
        Returns:
            Parsed WebhookEvent object
            
        Raises:
            CredoWebhookError: If signature is invalid or parsing fails
        """
        # Parse payload first - we need it for business code extraction
        try:
            if isinstance(payload, bytes):
                parsed_payload = json.loads(payload.decode("utf-8"))
            elif isinstance(payload, str):
                parsed_payload = json.loads(payload)
            else:
                parsed_payload = payload
        except json.JSONDecodeError as e:
            raise CredoWebhookError(f"Invalid JSON payload: {str(e)}")
        
        if verify:
            if not self.verify_signature_from_payload(signature, parsed_payload):
                raise CredoWebhookError("Invalid webhook signature")
        
        event = self.parse_event(parsed_payload)
        self.handle_event(event)
        
        return event
