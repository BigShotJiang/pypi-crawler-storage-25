"""
Data models for Credo SDK.

Uses dataclasses for clean, type-safe data structures.
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any, Union
from enum import IntEnum
from datetime import datetime
from decimal import Decimal, InvalidOperation

from .exceptions import CredoValidationError
from .utils.money import amount_from_minor_units, amount_to_minor_units


def _to_float(value: Any, default: float = 0.0) -> float:
    """Convert optional API numeric values to float without crashing on blanks."""
    if value in (None, ""):
        return default
    return float(value)


def _to_int(value: Any, default: int = 0) -> int:
    """Convert optional API integer values to int without crashing on blanks."""
    if value in (None, ""):
        return default
    return int(value)


def _to_decimal(value: Any) -> Decimal:
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise CredoValidationError(f"Invalid amount value: {value}", field="amount") from exc


class TransactionStatus(IntEnum):
    """
    Credo transaction status codes.
    
    Reference from Credo documentation:
    - 0: Successful transaction
    - 1: Refunded transaction
    - 2: Refund queued
    - 3: Failed transaction
    - 4: Settlement queued
    - 5: Settled transaction
    - 6: Review (flagged for human review)
    - 7: Declined (failed fraud check)
    - 8: Failed (aged - over 24 hours)
    - 9: Abandoned (15/14 status over 24 hours)
    - 13: Attempted (customer attempted payment)
    - 14: Initialised (payment URL loaded on browser)
    - 15: Initialising (payment request sent, URL returned)
    
    Note: Records with status 14 & 15 are not considered transactions
    yet and might not show in transaction history.
    """
    SUCCESSFUL = 0
    REFUNDED = 1
    REFUND_QUEUED = 2
    FAILED = 3
    SETTLE_QUEUED = 4
    SETTLED = 5
    REVIEW = 6
    DECLINED = 7
    FAILED_AGED = 8
    ABANDONED = 9
    ATTEMPTED = 13
    INITIALISED = 14
    INITIALISING = 15
    
    @classmethod
    def is_successful(cls, status: int) -> bool:
        """Check if status indicates a successful payment."""
        return status in [cls.SUCCESSFUL, cls.SETTLED, cls.SETTLE_QUEUED]
    
    @classmethod
    def is_failed(cls, status: int) -> bool:
        """Check if status indicates a failed payment."""
        return status in [cls.FAILED, cls.DECLINED, cls.FAILED_AGED, cls.ABANDONED]
    
    @classmethod
    def is_pending(cls, status: int) -> bool:
        """Check if status indicates a pending payment."""
        return status in [cls.INITIALISING, cls.INITIALISED, cls.ATTEMPTED, cls.REVIEW]
    
    @classmethod
    def is_refund(cls, status: int) -> bool:
        """Check if status indicates a refund state."""
        return status in [cls.REFUNDED, cls.REFUND_QUEUED]
    
    @classmethod
    def requires_action(cls, status: int) -> bool:
        """Check if status requires manual action/review."""
        return status == cls.REVIEW
    
    @classmethod
    def get_description(cls, status: int) -> str:
        """Get human-readable description for status code."""
        descriptions = {
            0: "Successful transaction",
            1: "Transaction refunded",
            2: "Refund queued",
            3: "Failed transaction",
            4: "Settlement queued",
            5: "Transaction settled",
            6: "Flagged for review",
            7: "Transaction declined (fraud check failed)",
            8: "Failed (aged - over 24 hours)",
            9: "Transaction abandoned",
            13: "Payment attempted",
            14: "Payment initialized",
            15: "Initializing payment",
        }
        return descriptions.get(status, f"Unknown status: {status}")


class FeeBearer(IntEnum):
    """
    Who bears the transaction fee.
    
    Per Credo documentation:
    - 0: Customer bears the fee
    - 1: Merchant bears the fee
    """
    CUSTOMER = 0  # Customer pays the transaction fee
    MERCHANT = 1  # Merchant pays the transaction fee


@dataclass
class Customer:
    """Customer information for payment."""
    email: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API request."""
        data = {"email": self.email}
        if self.first_name:
            data["customerFirstName"] = self.first_name
        if self.last_name:
            data["customerLastName"] = self.last_name
        if self.phone_number:
            data["customerPhoneNumber"] = self.phone_number
        return data


@dataclass
class CustomField:
    """Custom metadata field."""
    variable_name: str
    value: str
    display_name: Optional[str] = None
    
    def to_dict(self) -> Dict[str, str]:
        """Convert to dictionary for API request."""
        data = {
            "variable_name": self.variable_name,
            "value": self.value
        }
        if self.display_name:
            data["display_name"] = self.display_name
        return data


@dataclass
class PaymentMetadata:
    """
    Metadata for payment transactions.
    
    Useful for routing payments to specific bank accounts
    and storing custom data.
    """
    bank_account: Optional[str] = None
    custom_fields: List[CustomField] = field(default_factory=list)
    logo_url: Optional[str] = None
    extra_data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API request."""
        data = {}
        if self.bank_account:
            data["bankAccount"] = self.bank_account
        if self.custom_fields:
            data["customFields"] = [cf.to_dict() for cf in self.custom_fields]
        if self.logo_url:
            data["logoUrl"] = self.logo_url
        data.update(self.extra_data)
        return data


@dataclass
class PaymentRequest:
    """
    Payment initialization request data.
    
    Attributes:
        amount: Amount to send to Credo in the currency's lowest denomination, e.g., kobo
        email: Customer's email address
        callback_url: URL to redirect after payment
        currency: Currency code (default: NGN)
        reference: Unique transaction reference (auto-generated if not provided)
        channels: Payment channels to enable (card, bank, or both)
        customer: Customer details
        metadata: Additional metadata for the transaction
        service_code: Service code for dynamic settlement routing
        bearer: Who bears the transaction fee (0 = customer, 1 = merchant)
    """
    amount: int
    email: str
    callback_url: str
    currency: str = "NGN"
    reference: Optional[str] = None
    channels: List[str] = field(default_factory=lambda: ["card", "bank"])
    customer: Optional[Customer] = None
    metadata: Optional[PaymentMetadata] = None
    service_code: Optional[str] = None
    bearer: int = 0  # Fixed: 0 = customer bears fee (default), 1 = merchant bears fee
    
    def __post_init__(self):
        """Validate payment request data."""
        if self.amount <= 0:
            raise ValueError("Amount must be greater than 0")
        if not self.email:
            raise ValueError("Email is required")
        if not self.callback_url:
            raise ValueError("Callback URL is required")
        
        # Validate channels
        valid_channels = {"card", "bank"}
        for channel in self.channels:
            if channel not in valid_channels:
                raise ValueError(f"Invalid channel: {channel}. Must be 'card' or 'bank'")
        
        # Validate bearer
        if self.bearer not in [0, 1]:
            raise ValueError("Bearer must be 0 (customer) or 1 (merchant)")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API request."""
        data = {
            "amount": self.amount,
            "email": self.email,
            "callbackUrl": self.callback_url,
            "currency": self.currency,
            "channels": self.channels,
            "bearer": self.bearer,
        }
        
        if self.reference:
            data["reference"] = self.reference
        
        if self.service_code:
            data["serviceCode"] = self.service_code
        
        if self.customer:
            data.update(self.customer.to_dict())
        
        if self.metadata:
            data["metadata"] = self.metadata.to_dict()
        
        return data


@dataclass
class PaymentResponse:
    """
    Response from payment initialization.
    
    Attributes:
        status: HTTP status code
        message: Response message
        authorization_url: URL to redirect customer for payment
        trans_ref: Credo transaction reference
        reference: Your transaction reference
    """
    status: int
    message: str
    authorization_url: Optional[str] = None
    trans_ref: Optional[str] = None
    reference: Optional[str] = None
    raw_response: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_api_response(cls, response_data: Dict[str, Any]) -> "PaymentResponse":
        """Create from API response dictionary."""
        data = response_data.get("data") or {}
        return cls(
            status=response_data.get("status", 0),
            message=response_data.get("message", ""),
            authorization_url=data.get("authorizationUrl") or data.get("credoReference"),
            trans_ref=data.get("transRef") or data.get("credoReference"),
            reference=data.get("reference") or data.get("businessRef"),
            raw_response=response_data,
        )
    
    @property
    def is_successful(self) -> bool:
        """Check if initialization was successful."""
        return self.status == 200 and self.authorization_url is not None


@dataclass
class VerifyResponse:
    """
    Response from transaction verification.
    
    Contains full transaction details including amounts,
    status, and customer information.
    """
    status: int
    message: str
    business_code: Optional[str] = None
    trans_ref: Optional[str] = None
    business_ref: Optional[str] = None
    debited_amount: float = 0.0
    trans_amount: float = 0.0
    trans_fee_amount: float = 0.0
    settlement_amount: float = 0.0
    customer_id: Optional[str] = None
    transaction_date: Optional[str] = None
    channel_id: int = 0
    currency_code: str = "NGN"
    transaction_status: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    raw_response: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_api_response(cls, response_data: Dict[str, Any]) -> "VerifyResponse":
        """Create from API response dictionary."""
        data = response_data.get("data") or {}
        return cls(
            status=response_data.get("status", 0),
            message=response_data.get("message", ""),
            business_code=data.get("businessCode"),
            trans_ref=data.get("transRef"),
            business_ref=data.get("businessRef"),
            debited_amount=_to_float(data.get("debitedAmount")),
            trans_amount=_to_float(data.get("transAmount")),
            trans_fee_amount=_to_float(data.get("transFeeAmount")),
            settlement_amount=_to_float(data.get("settlementAmount")),
            customer_id=data.get("customerId"),
            transaction_date=data.get("transactionDate"),
            channel_id=_to_int(data.get("channelId")),
            currency_code=data.get("currencyCode", "NGN"),
            transaction_status=_to_int(data.get("status")),
            metadata=data.get("metadata") or {},
            raw_response=response_data,
        )
    
    @property
    def is_successful(self) -> bool:
        """Check if transaction was successful."""
        return TransactionStatus.is_successful(self.transaction_status)
    
    @property
    def is_failed(self) -> bool:
        """Check if transaction failed."""
        return TransactionStatus.is_failed(self.transaction_status)
    
    @property
    def is_pending(self) -> bool:
        """Check if transaction is pending."""
        return TransactionStatus.is_pending(self.transaction_status)

    @property
    def is_review(self) -> bool:
        """Check if transaction is flagged for manual review (status 6)."""
        return self.transaction_status == TransactionStatus.REVIEW

    @property
    def status_description(self) -> str:
        """Get human-readable status description."""
        return TransactionStatus.get_description(self.transaction_status)

    @property
    def fee_amount(self) -> float:
        """Alias for trans_fee_amount used by templates and UI code."""
        return self.trans_fee_amount

    def amount_matches(
        self,
        expected_amount: Union[float, Decimal],
        *,
        field: str = "trans_amount",
        currency: Optional[str] = None,
        tolerance: Union[float, Decimal] = 0,
    ) -> bool:
        """
        Return True when a verified Credo amount matches the expected main-unit amount.

        Args:
            expected_amount: Main-unit amount your application expected, e.g., Naira.
                             Accepts float or Decimal — pass Decimal for lossless comparison.
            field: One of trans_amount, debited_amount, settlement_amount.
            currency: Optional expected currency code.
            tolerance: Optional tolerance for rounding differences.
        """
        allowed_fields = {"trans_amount", "debited_amount", "settlement_amount"}
        if field not in allowed_fields:
            raise CredoValidationError(
                f"Invalid amount field '{field}'. Use one of: {', '.join(sorted(allowed_fields))}",
                field="field",
            )

        if currency and self.currency_code.upper() != currency.upper():
            return False

        actual = _to_decimal(getattr(self, field))
        expected = _to_decimal(amount_to_minor_units(expected_amount, currency or self.currency_code))
        allowed_delta = _to_decimal(amount_to_minor_units(tolerance, currency or self.currency_code)) if tolerance else Decimal("0")
        return abs(actual - expected) <= allowed_delta

    def assert_amount(
        self,
        expected_amount: Union[float, Decimal],
        *,
        field: str = "trans_amount",
        currency: Optional[str] = None,
        tolerance: Union[float, Decimal] = 0,
    ) -> "VerifyResponse":
        """
        Raise CredoValidationError unless the verified amount matches expectation.

        expected_amount and tolerance are in the currency's main unit. Returns
        self so callers can chain after verify_payment().
        """
        if self.amount_matches(
            expected_amount,
            field=field,
            currency=currency,
            tolerance=tolerance,
        ):
            return self

        expected_currency = currency or self.currency_code
        raise CredoValidationError(
            (
                f"Verified {field} mismatch: expected {expected_amount} "
                f"{expected_currency}, got {amount_from_minor_units(getattr(self, field), self.currency_code)} "
                f"{self.currency_code}"
            ),
            field=field,
        )

    @property
    def trans_amount_major(self) -> Decimal:
        """Transaction amount in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.trans_amount, self.currency_code)

    @property
    def debited_amount_major(self) -> Decimal:
        """Debited amount in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.debited_amount, self.currency_code)

    @property
    def trans_fee_amount_major(self) -> Decimal:
        """Transaction fee in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.trans_fee_amount, self.currency_code)

    @property
    def settlement_amount_major(self) -> Decimal:
        """Settlement amount in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.settlement_amount, self.currency_code)


@dataclass
class WebhookCustomer:
    """Customer data from webhook payload."""
    email: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WebhookCustomer":
        """Create from webhook data dictionary."""
        return cls(
            email=data.get("customerEmail"),
            first_name=data.get("firstName"),
            last_name=data.get("lastName"),
            phone_number=data.get("phoneNo"),
        )


@dataclass
class WebhookEvent:
    """
    Parsed webhook event from Credo.
    
    Attributes:
        event: Event type (e.g., 'transaction.successful')
        trans_ref: Credo transaction reference
        business_ref: Your transaction reference
        amount: Transaction amount
        status: Transaction status code
        customer: Customer information
    """
    event: str
    trans_ref: Optional[str] = None
    business_ref: Optional[str] = None
    business_code: Optional[str] = None
    debited_amount: float = 0.0
    trans_amount: float = 0.0
    trans_fee_amount: float = 0.0
    settlement_amount: float = 0.0
    customer_id: Optional[str] = None
    transaction_date: Optional[str] = None
    channel_id: int = 0
    currency_code: str = "NGN"
    status: int = 0
    payment_method_type: Optional[str] = None
    payment_method: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    customer: Optional[WebhookCustomer] = None
    raw_data: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_payload(cls, payload: Dict[str, Any]) -> "WebhookEvent":
        """Create from webhook payload dictionary."""
        data = payload.get("data") or {}
        customer_data = data.get("customer") or {}
        
        return cls(
            event=payload.get("event", ""),
            trans_ref=data.get("transRef"),
            business_ref=data.get("businessRef"),
            business_code=data.get("businessCode"),
            debited_amount=_to_float(data.get("debitedAmount")),
            trans_amount=_to_float(data.get("transAmount")),
            trans_fee_amount=_to_float(data.get("transFeeAmount")),
            settlement_amount=_to_float(data.get("settlementAmount")),
            customer_id=data.get("customerId"),
            transaction_date=data.get("transactionDate"),
            channel_id=_to_int(data.get("channelId")),
            currency_code=data.get("currencyCode", "NGN"),
            status=_to_int(data.get("status")),
            payment_method_type=data.get("paymentMethodType"),
            payment_method=data.get("paymentMethod"),
            metadata=data.get("metadata") or {},
            customer=WebhookCustomer.from_dict(customer_data) if customer_data else None,
            raw_data=payload,
        )
    
    @property
    def transaction_status(self) -> int:
        """Credo transaction status code. Mirrors VerifyResponse.transaction_status for uniform handling."""
        return self.status

    @property
    def payment_channel(self) -> Optional[str]:
        """Normalised payment channel — whichever of payment_method_type or payment_method is populated."""
        return self.payment_method_type or self.payment_method or None

    @property
    def is_successful(self) -> bool:
        """Check if event indicates successful transaction."""
        return self.event == "transaction.successful" and TransactionStatus.is_successful(self.status)

    @property
    def is_failed(self) -> bool:
        """Check if event indicates failed transaction."""
        return self.event == "transaction.failed" and TransactionStatus.is_failed(self.status)

    @property
    def is_pending(self) -> bool:
        """Check if event indicates a pending or under-review transaction."""
        return TransactionStatus.is_pending(self.status)

    @property
    def is_review(self) -> bool:
        """Check if transaction is flagged for manual review (status 6)."""
        return self.status == TransactionStatus.REVIEW

    @property
    def is_settlement(self) -> bool:
        """Check if event is a settlement notification."""
        return self.event == "transaction.settlement.success"

    @property
    def trans_amount_major(self) -> Decimal:
        """Transaction amount in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.trans_amount, self.currency_code)

    @property
    def debited_amount_major(self) -> Decimal:
        """Debited amount in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.debited_amount, self.currency_code)

    @property
    def trans_fee_amount_major(self) -> Decimal:
        """Transaction fee in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.trans_fee_amount, self.currency_code)

    @property
    def settlement_amount_major(self) -> Decimal:
        """Settlement amount in the currency's main unit, e.g., Naira."""
        return amount_from_minor_units(self.settlement_amount, self.currency_code)

    def amount_matches(
        self,
        expected_amount: Union[float, Decimal],
        *,
        field: str = "trans_amount",
        currency: Optional[str] = None,
        tolerance: Union[float, Decimal] = 0,
    ) -> bool:
        """
        Return True when a webhook amount matches the expected main-unit amount.
        Accepts float or Decimal — pass Decimal for lossless comparison.
        """
        allowed_fields = {"trans_amount", "debited_amount", "settlement_amount"}
        if field not in allowed_fields:
            raise CredoValidationError(
                f"Invalid amount field '{field}'. Use one of: {', '.join(sorted(allowed_fields))}",
                field="field",
            )

        if currency and self.currency_code.upper() != currency.upper():
            return False

        actual = _to_decimal(getattr(self, field))
        expected = _to_decimal(amount_to_minor_units(expected_amount, currency or self.currency_code))
        allowed_delta = _to_decimal(amount_to_minor_units(tolerance, currency or self.currency_code)) if tolerance else Decimal("0")
        return abs(actual - expected) <= allowed_delta

    def assert_amount(
        self,
        expected_amount: Union[float, Decimal],
        *,
        field: str = "trans_amount",
        currency: Optional[str] = None,
        tolerance: Union[float, Decimal] = 0,
    ) -> "WebhookEvent":
        """
        Raise CredoValidationError unless the webhook amount matches expectation.
        Accepts float or Decimal — pass Decimal for lossless comparison.
        """
        if self.amount_matches(
            expected_amount,
            field=field,
            currency=currency,
            tolerance=tolerance,
        ):
            return self

        expected_currency = currency or self.currency_code
        raise CredoValidationError(
            (
                f"Webhook {field} mismatch: expected {expected_amount} "
                f"{expected_currency}, got {amount_from_minor_units(getattr(self, field), self.currency_code)} "
                f"{self.currency_code}"
            ),
            field=field,
        )
