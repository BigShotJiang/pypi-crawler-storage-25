"""
Debug interface views — development only, no DRF required.

Accessible only when DEBUG=True or CREDO_ENABLE_DEBUG_INTERFACE=True.
Never enable in production.
"""

import logging
from decimal import Decimal
from typing import Any

from django.conf import settings
from django.http import Http404
from django.shortcuts import render
from django.views import View

from ..client import CredoClient
from ..config import CredoConfig
from ..exceptions import CredoError
from ..utils.debug_events import debug_events_enabled, get_debug_events

logger = logging.getLogger(__name__)


def _debug_interface_enabled() -> bool:
    return bool(
        getattr(settings, "DEBUG", False)
        or getattr(settings, "CREDO_ENABLE_DEBUG_INTERFACE", False)
    )


class _DebugBase(View):
    """Base debug view — blocks access when the debug interface is disabled."""

    def dispatch(self, request, *args: Any, **kwargs: Any):
        if not _debug_interface_enabled():
            raise Http404("Credo debug interface is disabled")
        return super().dispatch(request, *args, **kwargs)

    @property
    def credo_client(self) -> CredoClient:
        return CredoClient()


class DebugInterfaceView(_DebugBase):
    """
    Main debug page.

    GET /api/credo/debug/
    """

    def get(self, request):
        config = CredoConfig.from_django_settings()
        context = {
            "environment": config.environment,
            "is_sandbox": config.environment == "sandbox",
            "base_url": config.base_url,
            "public_key_set": bool(config.public_key),
            "secret_key_set": bool(config.secret_key),
            "default_currency": config.default_currency,
            "default_channels": config.default_channels,
            "callback_url": config.default_callback_url,
            "public_key_preview": (
                f"{config.public_key[:12]}..." if config.public_key else "Not set"
            ),
        }
        return render(request, "credo_pay/debug.html", context)


class DebugConfigCheckView(_DebugBase):
    """
    Configuration check partial.

    GET /api/credo/debug/config-check/
    """

    def get(self, request):
        config = CredoConfig.from_django_settings()
        checks = []
        all_passed = True

        checks.append({
            "name": "Environment",
            "value": config.environment,
            "passed": config.environment in ["sandbox", "production"],
            "message": f"Using {config.environment} environment",
        })

        public_key_valid = bool(config.public_key)
        checks.append({
            "name": "Public Key",
            "value": f"{config.public_key[:16]}..." if config.public_key else "Not set",
            "passed": public_key_valid,
            "message": "Public key configured" if public_key_valid else "Missing public key",
        })
        if not public_key_valid:
            all_passed = False

        secret_key_valid = bool(config.secret_key)
        checks.append({
            "name": "Secret Key",
            "value": "***SET***" if config.secret_key else "Not set",
            "passed": secret_key_valid,
            "message": "Secret key configured" if secret_key_valid else "Missing secret key",
        })
        if not secret_key_valid:
            all_passed = False

        callback_valid = bool(config.default_callback_url)
        callback_https = not config.is_production or (
            callback_valid
            and config.default_callback_url.lower().startswith("https://")
        )
        callback_passed = callback_valid and callback_https
        checks.append({
            "name": "Callback URL",
            "value": config.default_callback_url or "Not set",
            "passed": callback_passed,
            "message": (
                "Callback URL configured"
                if callback_passed
                else "Production callback URL must use HTTPS"
                if callback_valid
                else "Missing CREDO_DEFAULT_CALLBACK_URL"
            ),
        })
        if not callback_passed:
            all_passed = False

        webhook_valid = bool(config.webhook_token)
        checks.append({
            "name": "Webhook Token",
            "value": "***SET***" if config.webhook_token else "Not set",
            "passed": webhook_valid,
            "message": (
                "Webhook token configured"
                if webhook_valid
                else "Missing CREDO_WEBHOOK_SECRET_TOKEN"
            ),
        })
        if not webhook_valid:
            all_passed = False

        checks.append({
            "name": "API Base URL",
            "value": config.base_url,
            "passed": True,
            "message": f"API calls will use {config.environment} environment",
        })
        checks.append({
            "name": "Request Timeout",
            "value": f"{config.request_timeout:g}s",
            "passed": config.request_timeout > 0,
            "message": (
                "Credo API timeout configured"
                if config.request_timeout > 0
                else "CREDO_REQUEST_TIMEOUT must be greater than 0"
            ),
        })
        if config.request_timeout <= 0:
            all_passed = False

        return render(request, "credo_pay/partials/config_check.html", {
            "checks": checks,
            "all_passed": all_passed,
            "environment": config.environment,
        })


class DebugInitializePaymentView(_DebugBase):
    """
    Debug payment initialization partial (HTMX target).

    POST /api/credo/debug/initialize/
    """

    def post(self, request):
        try:
            config = CredoConfig.from_django_settings()
            config.request_timeout = float(
                getattr(settings, "CREDO_DEBUG_REQUEST_TIMEOUT", config.request_timeout)
            )
            client = CredoClient(config)

            amount = Decimal(str(request.POST.get("amount", 1000)))
            email = request.POST.get("email", "test@example.com")
            first_name = request.POST.get("first_name", "") or None
            last_name = request.POST.get("last_name", "") or None
            phone_number = request.POST.get("phone_number", "") or None
            callback_url = request.POST.get("callback_url", "") or None
            currency = request.POST.get("currency", "NGN")
            channels = request.POST.getlist("channels") or ["card", "bank"]
            reference_prefix = request.POST.get("reference_prefix", "").strip() or None
            service_code = request.POST.get("service_code", "").strip() or None
            bank_account = request.POST.get("bank_account", "").strip() or None

            response = client.initialize_payment(
                amount=amount,
                email=email,
                callback_url=callback_url,
                currency=currency,
                channels=channels,
                first_name=first_name,
                last_name=last_name,
                phone_number=phone_number,
                reference_prefix=reference_prefix,
                service_code=service_code,
                bank_account=bank_account,
            )
            context = {
                "success": True,
                "authorization_url": response.authorization_url,
                "trans_ref": response.trans_ref,
                "reference": response.reference,
                "reference_prefix": reference_prefix,
                "message": response.message,
                "service_code": service_code,
                "bank_account": bank_account,
                "request_timeout": config.request_timeout,
            }
        except CredoError as exc:
            context = {"success": False, "error": str(exc), "details": exc.details}
        except Exception as exc:
            context = {"success": False, "error": str(exc)}

        return render(request, "credo_pay/partials/payment_result.html", context)


class DebugVerifyPaymentView(_DebugBase):
    """
    Debug payment verification partial (HTMX target).

    POST /api/credo/debug/verify/
    """

    def post(self, request):
        reference = request.POST.get("reference", "").strip()
        if not reference:
            return render(request, "credo_pay/partials/verify_result.html", {
                "success": False,
                "error": "Reference is required",
            })
        try:
            response = self.credo_client.verify_payment(reference)
            context = {
                "success": True,
                "trans_ref": response.trans_ref,
                "business_ref": response.business_ref,
                "debited_amount": response.debited_amount_major,
                "trans_amount": response.trans_amount_major,
                "fee_amount": response.trans_fee_amount_major,
                "settlement_amount": response.settlement_amount_major,
                "customer_id": response.customer_id,
                "transaction_date": response.transaction_date,
                "currency": response.currency_code,
                "status_code": response.transaction_status,
                "status_description": response.status_description,
                "is_successful": response.is_successful,
                "is_pending": response.is_pending,
                "is_failed": response.is_failed,
            }
        except CredoError as exc:
            context = {"success": False, "error": str(exc), "details": exc.details}
        except Exception as exc:
            context = {"success": False, "error": str(exc)}

        return render(request, "credo_pay/partials/verify_result.html", context)


class DebugWebhookEventsView(_DebugBase):
    """
    Debug webhook/callback event inbox partial (HTMX polling target).

    GET /api/credo/debug/webhook/
    """

    def get(self, request):
        return render(request, "credo_pay/partials/webhook_events.html", {
            "events": get_debug_events(),
            "debug_events_enabled": debug_events_enabled(),
        })
