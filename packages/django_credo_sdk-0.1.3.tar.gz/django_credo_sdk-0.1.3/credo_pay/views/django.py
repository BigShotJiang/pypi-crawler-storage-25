"""
Pure Django views — no djangorestframework required.

Use DjangoCredoWebhookView in projects that do not use DRF.
"""

import logging
from typing import Optional

from django.http import HttpResponse, JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt

from ..client import CredoClient
from ..exceptions import CredoError, CredoValidationError, CredoWebhookError
from ..models import VerifyResponse, WebhookEvent
from ..utils.callback import CallbackData
from ..utils.debug_events import record_debug_event
from ._core import handle_callback_request, handle_webhook_request

logger = logging.getLogger(__name__)


class _DjangoCredoBase(View):
    """Base view providing a lazy Credo client."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._client: Optional[CredoClient] = None

    @property
    def credo_client(self) -> CredoClient:
        if self._client is None:
            self._client = CredoClient()
        return self._client


@method_decorator(csrf_exempt, name="dispatch")
class DjangoCredoWebhookView(_DjangoCredoBase):
    """
    Unified callback/webhook endpoint — pure Django, no DRF required.

    Handles both Credo payment flows on one URL:

    - **GET**  Customer browser redirect after a payment attempt
    - **POST** Credo server-to-server webhook notification

    Subclass and override the two hook methods:

        class MyView(DjangoCredoWebhookView):

            def handle_callback(self, callback_data, verify_response):
                if verify_response and verify_response.is_successful:
                    Order.objects.filter(
                        reference=callback_data.reference
                    ).update(status="paid")
                    return redirect("/payment/success/")
                return redirect("/payment/failed/")

            def handle_webhook(self, event):
                if event.is_successful:
                    Order.objects.filter(
                        credo_trans_ref=event.trans_ref
                    ).update(status="paid")
                elif event.is_failed:
                    Order.objects.filter(
                        credo_trans_ref=event.trans_ref
                    ).update(status="failed")

    Wire it up in urls.py:

        path("api/credo/callback-webhook/", MyView.as_view(), name="credo-callback-webhook")
    """

    verify_callback_transaction: bool = True
    verify_webhook_signature: bool = True
    callback_signing_secret: Optional[str] = None
    require_signed_callback: bool = False

    # ------------------------------------------------------------------
    # HTTP handlers
    # ------------------------------------------------------------------

    def get(self, request, *args, **kwargs) -> HttpResponse:
        """Handle Credo customer redirect callbacks."""
        try:
            callback_data = CallbackData.from_request(
                request,
                signing_secret=self.callback_signing_secret,
                require_signature=self.require_signed_callback,
            )
            logger.info(
                "Payment callback received: status=%s trans_ref=%s reference=%s",
                callback_data.status,
                callback_data.trans_ref,
                callback_data.reference,
            )
            verify_response = handle_callback_request(
                self.credo_client,
                callback_data,
                self.verify_callback_transaction,
            )
            result = self.handle_callback(callback_data, verify_response)
            if result is not None:
                return result
            return self._default_callback_response(callback_data, verify_response)

        except CredoValidationError as exc:
            logger.warning("Invalid callback data: %s", exc)
            record_debug_event(
                kind="Callback",
                outcome="failed",
                title="Invalid Credo redirect callback",
                details={"error": str(exc), "params": dict(request.GET)},
            )
            return JsonResponse(
                {"error": "Invalid callback data", "details": exc.details}, status=400
            )
        except CredoError as exc:
            logger.warning("Callback verification failed: %s", exc)
            record_debug_event(
                kind="Callback",
                outcome="failed",
                title="Credo callback verification failed",
                details={"error": str(exc)},
            )
            return JsonResponse(
                {"error": "Unable to verify callback transaction", "details": exc.details},
                status=400,
            )
        except Exception as exc:
            logger.error("Callback processing error: %s", exc)
            return JsonResponse({"error": "Failed to process callback"}, status=500)

    def post(self, request, *args, **kwargs) -> HttpResponse:
        """Handle Credo server-to-server webhook notifications."""
        signature = (
            request.headers.get("X-Credo-Signature", "")
            or request.headers.get("X-Signature", "")
        )
        try:
            event = handle_webhook_request(
                self.credo_client,
                request.body,
                signature,
                self.verify_webhook_signature,
            )
            self.handle_webhook(event)
            return JsonResponse({"status": "success", "event": event.event})

        except CredoWebhookError as exc:
            logger.warning("Webhook signature invalid: %s", exc)
            record_debug_event(
                kind="Webhook",
                outcome="failed",
                title="Credo webhook signature invalid",
                details={"error": str(exc), "signature_present": bool(signature)},
            )
            return JsonResponse({"error": "Invalid webhook signature"}, status=401)
        except CredoError as exc:
            logger.error("Webhook processing failed: %s", exc)
            return JsonResponse({"error": str(exc)}, status=400)
        except Exception as exc:
            logger.error("Webhook processing error: %s", exc)
            return JsonResponse({"error": "Failed to process webhook"}, status=500)

    # ------------------------------------------------------------------
    # Hook methods — override in your subclass
    # ------------------------------------------------------------------

    def handle_callback(
        self,
        callback_data: CallbackData,
        verify_response: Optional[VerifyResponse],
    ) -> Optional[HttpResponse]:
        """
        Called after the callback is parsed and optionally verified.

        Return an HttpResponse (or redirect) to short-circuit the default
        response, or return None to fall through to the default.

        verify_response is None when:
        - verify_callback_transaction=False, or
        - trans_ref was absent from Credo's redirect (abandoned payment).
        Always check before using it.
        """
        return None

    def handle_webhook(self, event: WebhookEvent) -> None:
        """
        Called for each verified server-to-server webhook notification.

        event.is_successful, event.is_failed, event.is_settlement, and
        event.is_pending let you branch on the outcome without reading
        raw status codes.
        """
        logger.info(
            "Webhook processed: %s ref=%s amount=%s",
            event.event,
            event.trans_ref,
            event.trans_amount,
        )

    # ------------------------------------------------------------------
    # Default response (used when handle_callback returns None)
    # ------------------------------------------------------------------

    def _default_callback_response(
        self,
        callback_data: CallbackData,
        verify_response: Optional[VerifyResponse],
    ) -> JsonResponse:
        if verify_response:
            is_successful = verify_response.is_successful
            status_desc = verify_response.status_description
        else:
            is_successful = callback_data.is_successful
            status_desc = callback_data.error_message

        if is_successful:
            return JsonResponse({
                "status": "success",
                "message": "Payment completed successfully",
                "trans_ref": callback_data.trans_ref,
                "reference": callback_data.reference,
                "amount": str(callback_data.trans_amount),
                "currency": callback_data.currency,
                "verified": verify_response is not None,
            })
        return JsonResponse({
            "status": "failed",
            "message": status_desc or "Payment failed",
            "trans_ref": callback_data.trans_ref,
            "reference": callback_data.reference,
            "verified": verify_response is not None,
        }, status=400)
