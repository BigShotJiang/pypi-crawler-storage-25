"""
Shared callback and webhook handler logic.

Framework-agnostic functions used by both DjangoCredoWebhookView and
CredoWebhookView to avoid duplicating the same parsing, verification,
and debug-event recording logic in each view layer.
"""

import logging
from typing import Optional

from ..client import CredoClient
from ..models import VerifyResponse, WebhookEvent
from ..utils.callback import CallbackData
from ..utils.debug_events import record_debug_event

logger = logging.getLogger(__name__)


def handle_callback_request(
    client: CredoClient,
    callback_data: CallbackData,
    verify: bool,
) -> Optional[VerifyResponse]:
    """
    Optionally verify a callback transaction and record a debug event.

    Returns a VerifyResponse when verify=True and trans_ref is present,
    otherwise None. Does not raise — callers handle exceptions.
    """
    verify_response: Optional[VerifyResponse] = None

    if verify and callback_data.trans_ref:
        verify_response = client.verify_payment(callback_data.trans_ref)
        logger.info(
            "Transaction verified: status=%s is_successful=%s",
            verify_response.transaction_status,
            verify_response.is_successful,
        )

    outcome = (
        "success"
        if (verify_response.is_successful if verify_response else callback_data.is_successful)
        else "failed"
    )
    record_debug_event(
        kind="Callback",
        outcome=outcome,
        title="Credo redirect callback received",
        details={
            "trans_ref": callback_data.trans_ref,
            "reference": callback_data.reference,
            "callback_status": callback_data.status,
            "verified": bool(verify_response),
            "verified_status": verify_response.transaction_status if verify_response else None,
            "amount": callback_data.trans_amount,
            "currency": callback_data.currency,
        },
    )
    return verify_response


def handle_webhook_request(
    client: CredoClient,
    body: bytes,
    signature: str,
    verify_signature: bool,
) -> WebhookEvent:
    """
    Parse and optionally verify a Credo webhook payload.

    Records a debug event on success. Raises CredoWebhookError on bad
    signature, CredoError on parse failure.
    """
    event = client.process_webhook(
        payload=body,
        signature=signature,
        verify=verify_signature,
        use_payload_business_code=True,
    )
    logger.info(
        "Webhook received: event=%s trans_ref=%s amount=%s",
        event.event,
        event.trans_ref,
        event.trans_amount,
    )
    record_debug_event(
        kind="Webhook",
        outcome="success",
        title=event.event or "Credo webhook received",
        details={
            "trans_ref": event.trans_ref,
            "business_ref": event.business_ref,
            "status": event.status,
            "amount": str(event.trans_amount_major),
            "currency": event.currency_code,
            "signature_present": bool(signature),
        },
    )
    return event
