"""
Django REST Framework views — requires djangorestframework.

Install: pip install django-credo-sdk[drf]

These views provide DRF-native request validation via serializers and
DRF-native Response objects. For projects without DRF, use the views
in credo_pay.views.django instead.
"""

import logging
from typing import Optional

from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

from ..client import CredoClient
from ..exceptions import CredoError, CredoValidationError, CredoWebhookError
from ..models import VerifyResponse, WebhookEvent
from ..utils.callback import CallbackData
from ..utils.debug_events import record_debug_event
from ._core import handle_callback_request, handle_webhook_request
from .serializers import (
    PaymentInitializeSerializer,
    PaymentResponseSerializer,
    RoutedPaymentSerializer,
    VerifyResponseSerializer,
)

logger = logging.getLogger(__name__)


class _DRFCredoBase(APIView):
    """Base DRF view providing a lazy Credo client."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._client: Optional[CredoClient] = None

    @property
    def credo_client(self) -> CredoClient:
        if self._client is None:
            self._client = CredoClient()
        return self._client


class PaymentInitializeView(_DRFCredoBase):
    """
    Initialize a Credo payment.

    POST /api/credo/initialize/

    Defaults to AllowAny for guest/anonymous checkout. Override
    permission_classes in a subclass to restrict to authenticated users
    when your flow requires a logged-in customer:

        class AuthPaymentView(PaymentInitializeView):
            permission_classes = [IsAuthenticated]
    """

    permission_classes = [AllowAny]

    def post(self, request: Request) -> Response:
        serializer = PaymentInitializeSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {"error": "Validation failed", "details": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
        data = serializer.validated_data
        try:
            result = self.credo_client.initialize_payment(
                amount=data["amount"],
                email=data["email"],
                callback_url=data.get("callback_url") or None,
                currency=data.get("currency", "NGN"),
                reference=data.get("reference") or None,
                reference_prefix=data.get("reference_prefix") or None,
                channels=data.get("channels"),
                first_name=data.get("first_name") or None,
                last_name=data.get("last_name") or None,
                phone_number=data.get("phone_number") or None,
                service_code=data.get("service_code") or None,
                bank_account=data.get("bank_account") or None,
                metadata=data.get("metadata") or None,
                custom_fields=data.get("custom_fields") or None,
                bearer=data.get("bearer"),
            )
            return Response(PaymentResponseSerializer(result).data)
        except CredoError as exc:
            logger.error("Payment initialization failed: %s", exc)
            return Response(
                {"error": str(exc), "details": exc.details},
                status=status.HTTP_400_BAD_REQUEST,
            )


class RoutedPaymentInitializeView(_DRFCredoBase):
    """
    Initialize a routed Credo payment.

    POST /api/credo/routed/initialize/

    Defaults to AllowAny. Override permission_classes as needed.
    """

    permission_classes = [AllowAny]

    def post(self, request: Request) -> Response:
        serializer = RoutedPaymentSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {"error": "Validation failed", "details": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
        data = serializer.validated_data
        try:
            result = self.credo_client.initialize_routed_payment(
                amount=data["amount"],
                email=data["email"],
                service_code=data["service_code"],
                bank_account=data["bank_account"],
                callback_url=data.get("callback_url") or None,
                currency=data.get("currency", "NGN"),
                reference=data.get("reference") or None,
                reference_prefix=data.get("reference_prefix") or None,
                channels=data.get("channels"),
                first_name=data.get("first_name") or None,
                last_name=data.get("last_name") or None,
                phone_number=data.get("phone_number") or None,
                metadata=data.get("metadata") or None,
                custom_fields=data.get("custom_fields") or None,
                bearer=data.get("bearer"),
            )
            return Response(PaymentResponseSerializer(result).data)
        except CredoError as exc:
            logger.error("Routed payment initialization failed: %s", exc)
            return Response(
                {"error": str(exc), "details": exc.details},
                status=status.HTTP_400_BAD_REQUEST,
            )


class PaymentVerifyView(_DRFCredoBase):
    """
    Verify a Credo payment by trans_ref.

    GET /api/credo/verify/<reference>/

    Defaults to AllowAny. Override permission_classes as needed.
    """

    permission_classes = [AllowAny]

    def get(self, request: Request, reference: str) -> Response:
        try:
            result = self.credo_client.verify_payment(reference)
            return Response(VerifyResponseSerializer(result).data)
        except CredoError as exc:
            logger.error("Payment verification failed: %s", exc)
            return Response(
                {"error": str(exc), "details": exc.details},
                status=status.HTTP_400_BAD_REQUEST,
            )


class CredoWebhookView(_DRFCredoBase):
    """
    Unified DRF callback/webhook endpoint.

    Handles both Credo payment flows on one URL:

    - **GET**  Customer browser redirect after a payment attempt
    - **POST** Credo server-to-server webhook notification

    Subclass and override handle_callback() / handle_webhook():

        class MyView(CredoWebhookView):

            def handle_callback(self, callback_data, verify_response):
                if verify_response and verify_response.is_successful:
                    Order.objects.filter(
                        reference=callback_data.reference
                    ).update(status="paid")
                    return redirect("/payment/success/")
                return redirect("/payment/failed/")

            def handle_webhook(self, event):
                if event.is_successful:
                    Order.objects.filter(
                        credo_trans_ref=event.trans_ref
                    ).update(status="paid")
                elif event.is_failed:
                    Order.objects.filter(
                        credo_trans_ref=event.trans_ref
                    ).update(status="failed")
                elif event.is_settlement:
                    Transaction.objects.filter(
                        trans_ref=event.trans_ref
                    ).update(settled=True)
    """

    permission_classes = [AllowAny]

    verify_callback_transaction: bool = True
    verify_webhook_signature: bool = True
    callback_signing_secret: Optional[str] = None
    require_signed_callback: bool = False

    # ------------------------------------------------------------------
    # HTTP handlers
    # ------------------------------------------------------------------

    def get(self, request: Request) -> Response:
        """Handle Credo customer redirect callbacks."""
        try:
            callback_data = CallbackData.from_request(
                request,
                signing_secret=self.callback_signing_secret,
                require_signature=self.require_signed_callback,
            )
            logger.info(
                "Payment callback received: status=%s trans_ref=%s reference=%s",
                callback_data.status,
                callback_data.trans_ref,
                callback_data.reference,
            )
            verify_response = handle_callback_request(
                self.credo_client,
                callback_data,
                self.verify_callback_transaction,
            )
            result = self.handle_callback(callback_data, verify_response)
            if result is not None:
                return result
            return self._default_callback_response(callback_data, verify_response)

        except CredoValidationError as exc:
            logger.warning("Invalid callback data: %s", exc)
            record_debug_event(
                kind="Callback",
                outcome="failed",
                title="Invalid Credo redirect callback",
                details={"error": str(exc), "params": dict(request.query_params)},
            )
            return Response(
                {"error": "Invalid callback data", "details": exc.details},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except CredoError as exc:
            logger.warning("Callback verification failed: %s", exc)
            record_debug_event(
                kind="Callback",
                outcome="failed",
                title="Credo callback verification failed",
                details={"error": str(exc)},
            )
            return Response(
                {"error": "Unable to verify callback transaction", "details": exc.details},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as exc:
            logger.error("Callback processing error: %s", exc)
            return Response(
                {"error": "Failed to process callback"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def post(self, request: Request) -> Response:
        """Handle Credo server-to-server webhook notifications."""
        signature = (
            request.headers.get("X-Credo-Signature", "")
            or request.headers.get("X-Signature", "")
        )
        try:
            event = handle_webhook_request(
                self.credo_client,
                request.body,
                signature,
                self.verify_webhook_signature,
            )
            self.handle_webhook(event)
            return Response({"status": "success", "event": event.event})

        except CredoWebhookError as exc:
            logger.warning("Webhook signature invalid: %s", exc)
            record_debug_event(
                kind="Webhook",
                outcome="failed",
                title="Credo webhook signature invalid",
                details={"error": str(exc), "signature_present": bool(signature)},
            )
            return Response(
                {"error": "Invalid webhook signature"},
                status=status.HTTP_401_UNAUTHORIZED,
            )
        except CredoError as exc:
            logger.error("Webhook processing failed: %s", exc)
            return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)

    # ------------------------------------------------------------------
    # Hook methods — override in your subclass
    # ------------------------------------------------------------------

    def handle_callback(
        self,
        callback_data: CallbackData,
        verify_response: Optional[VerifyResponse],
    ) -> Optional[Response]:
        """
        Called after the callback is parsed and optionally verified.

        Return a Response (or redirect) to short-circuit the default, or
        None to fall through to the default. verify_response is None when
        verify_callback_transaction=False or trans_ref was absent.
        """
        return None

    def handle_webhook(self, event: WebhookEvent) -> None:
        """
        Called for each verified server-to-server webhook notification.

        event.is_successful, event.is_failed, event.is_settlement, and
        event.is_pending let you branch on the outcome.
        """
        logger.info(
            "Webhook processed: %s ref=%s amount=%s",
            event.event,
            event.trans_ref,
            event.trans_amount,
        )

    # ------------------------------------------------------------------
    # Default response (used when handle_callback returns None)
    # ------------------------------------------------------------------

    def _default_callback_response(
        self,
        callback_data: CallbackData,
        verify_response: Optional[VerifyResponse],
    ) -> Response:
        if verify_response:
            is_successful = verify_response.is_successful
            status_desc = verify_response.status_description
        else:
            is_successful = callback_data.is_successful
            status_desc = callback_data.error_message

        if is_successful:
            return Response({
                "status": "success",
                "message": "Payment completed successfully",
                "trans_ref": callback_data.trans_ref,
                "reference": callback_data.reference,
                "amount": str(callback_data.trans_amount),
                "currency": callback_data.currency,
                "verified": verify_response is not None,
            })
        return Response({
            "status": "failed",
            "message": status_desc or "Payment failed",
            "trans_ref": callback_data.trans_ref,
            "reference": callback_data.reference,
            "verified": verify_response is not None,
        }, status=status.HTTP_400_BAD_REQUEST)
