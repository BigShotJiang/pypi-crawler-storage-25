"""
Credo SDK views.

Always available (no DRF required):
    DjangoCredoWebhookView       Pure Django callback/webhook handler
    Debug*View                   Development debug interface views

Requires djangorestframework (pip install django-credo-sdk[drf]):
    CredoWebhookView             DRF callback/webhook handler
    PaymentInitializeView        DRF payment initialization endpoint
    RoutedPaymentInitializeView  DRF routed payment endpoint
    PaymentVerifyView            DRF payment verification endpoint

Import DRF views directly when you need them:

    from credo_pay.views.drf import CredoWebhookView, PaymentInitializeView
    from credo_pay.views.django import DjangoCredoWebhookView
"""

from .debug import (
    DebugConfigCheckView,
    DebugInitializePaymentView,
    DebugInterfaceView,
    DebugVerifyPaymentView,
    DebugWebhookEventsView,
)
from .django import DjangoCredoWebhookView

# DRF views — only importable when djangorestframework is installed.
# Attempting to use these without DRF raises ImportError with a clear message.
try:
    from .drf import (
        CredoWebhookView,
        PaymentInitializeView,
        RoutedPaymentInitializeView,
        PaymentVerifyView,
    )
    _DRF_VIEWS_AVAILABLE = True
except ImportError:
    _DRF_VIEWS_AVAILABLE = False

    class CredoWebhookView:  # type: ignore[no-redef]
        """Stub — djangorestframework is not installed."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "CredoWebhookView requires djangorestframework. "
                "Install it with: pip install django-credo-sdk[drf]"
            )

    class PaymentInitializeView:  # type: ignore[no-redef]
        """Stub — djangorestframework is not installed."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "PaymentInitializeView requires djangorestframework. "
                "Install it with: pip install django-credo-sdk[drf]"
            )

    class RoutedPaymentInitializeView:  # type: ignore[no-redef]
        """Stub — djangorestframework is not installed."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "RoutedPaymentInitializeView requires djangorestframework. "
                "Install it with: pip install django-credo-sdk[drf]"
            )

    class PaymentVerifyView:  # type: ignore[no-redef]
        """Stub — djangorestframework is not installed."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "PaymentVerifyView requires djangorestframework. "
                "Install it with: pip install django-credo-sdk[drf]"
            )


__all__ = [
    # Pure Django (always available)
    "DjangoCredoWebhookView",
    # Debug (always available, gated by DEBUG setting)
    "DebugInterfaceView",
    "DebugConfigCheckView",
    "DebugInitializePaymentView",
    "DebugVerifyPaymentView",
    "DebugWebhookEventsView",
    # DRF (requires djangorestframework)
    "CredoWebhookView",
    "PaymentInitializeView",
    "RoutedPaymentInitializeView",
    "PaymentVerifyView",
]
