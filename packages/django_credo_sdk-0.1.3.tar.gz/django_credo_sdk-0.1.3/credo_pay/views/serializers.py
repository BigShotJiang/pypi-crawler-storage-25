"""
Django REST Framework serializers for Credo SDK.

Only imported when djangorestframework is installed. All classes here
are DRF-specific and have no Django-only equivalents.
"""

from decimal import Decimal

from rest_framework import serializers


class PaymentInitializeSerializer(serializers.Serializer):
    """Validate a payment initialization request."""

    amount = serializers.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=Decimal("0.01"),
        help_text="Amount in the currency's main unit (e.g. Naira). The SDK converts to kobo.",
    )
    email = serializers.EmailField()
    callback_url = serializers.URLField(required=False, allow_blank=True)
    currency = serializers.CharField(max_length=3, default="NGN")
    reference = serializers.CharField(max_length=50, required=False, allow_blank=True)
    reference_prefix = serializers.CharField(max_length=50, required=False, allow_blank=True)
    channels = serializers.ListField(
        child=serializers.ChoiceField(choices=["card", "bank"]),
        default=["card", "bank"],
        required=False,
    )
    first_name = serializers.CharField(max_length=100, required=False, allow_blank=True)
    last_name = serializers.CharField(max_length=100, required=False, allow_blank=True)
    phone_number = serializers.CharField(max_length=20, required=False, allow_blank=True)
    service_code = serializers.CharField(max_length=50, required=False, allow_blank=True)
    bank_account = serializers.CharField(max_length=20, required=False, allow_blank=True)
    metadata = serializers.DictField(required=False, default=dict)
    custom_fields = serializers.ListField(
        child=serializers.DictField(child=serializers.CharField()),
        required=False,
        default=list,
    )
    bearer = serializers.ChoiceField(
        choices=[0, 1],
        required=False,
        allow_null=True,
        default=None,
        help_text="Who bears the transaction fee: 0 = Customer (default), 1 = Merchant",
    )


class RoutedPaymentSerializer(PaymentInitializeSerializer):
    """Validate a routed payment request — service_code and bank_account are required."""

    service_code = serializers.CharField(max_length=50)
    bank_account = serializers.CharField(max_length=20)


class PaymentResponseSerializer(serializers.Serializer):
    """Serialize a PaymentResponse for API responses."""

    status = serializers.IntegerField()
    message = serializers.CharField()
    authorization_url = serializers.URLField(allow_null=True, allow_blank=True)
    trans_ref = serializers.CharField(allow_null=True, allow_blank=True)
    reference = serializers.CharField(allow_null=True, allow_blank=True)


class VerifyResponseSerializer(serializers.Serializer):
    """Serialize a VerifyResponse for API responses."""

    status = serializers.IntegerField()
    message = serializers.CharField()
    business_code = serializers.CharField(allow_null=True, allow_blank=True)
    trans_ref = serializers.CharField(allow_null=True, allow_blank=True)
    business_ref = serializers.CharField(allow_null=True, allow_blank=True)
    debited_amount = serializers.FloatField()
    trans_amount = serializers.FloatField()
    trans_fee_amount = serializers.FloatField()
    settlement_amount = serializers.FloatField()
    debited_amount_major = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)
    trans_amount_major = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)
    trans_fee_amount_major = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)
    settlement_amount_major = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)
    customer_id = serializers.CharField(allow_null=True, allow_blank=True)
    transaction_date = serializers.CharField(allow_null=True, allow_blank=True)
    channel_id = serializers.IntegerField()
    currency_code = serializers.CharField()
    transaction_status = serializers.IntegerField()
    is_successful = serializers.BooleanField()
    is_failed = serializers.BooleanField()
    is_pending = serializers.BooleanField()
    status_description = serializers.CharField()
