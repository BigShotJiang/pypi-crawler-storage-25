"""
Django Credo SDK

A Django/DRF SDK for integrating the Credo payment gateway.

    from credo_pay import CredoClient

    client = CredoClient()
    response = client.initialize_payment(
        amount=15000,
        email="customer@example.com",
        callback_url="https://yoursite.com/api/credo/callback-webhook/",
    )

Traditional Django projects (no DRF):

    from credo_pay import DjangoCredoWebhookView

Django REST Framework projects:

    from credo_pay import CredoWebhookView               # requires DRF
    from credo_pay.views.drf import PaymentInitializeView # requires DRF
"""

from .client import CredoClient
from .config import CredoConfig
from .exceptions import (
    CredoAPIError,
    CredoConfigError,
    CredoError,
    CredoPaymentError,
    CredoValidationError,
    CredoWebhookError,
)
from .idempotency import PaymentEventResult, model_payment_lock, process_payment_event
from .models import (
    Customer,
    FeeBearer,
    PaymentRequest,
    PaymentResponse,
    TransactionStatus,
    VerifyResponse,
    WebhookEvent,
)
from .utils.callback import CallbackData, build_callback_url
from .utils.reference import generate_payment_reference, sanitize_reference_part
from .utils.signature import sign_callback_params, verify_callback_signature

# Always available — pure Django, no DRF required.
from .views.django import DjangoCredoWebhookView

# DRF views — always importable; raises ImportError on instantiation if DRF absent.
from .views import CredoWebhookView

__version__ = "0.1.3"

__all__ = [
    # Client
    "CredoClient",
    "CredoConfig",
    # Exceptions
    "CredoError",
    "CredoAPIError",
    "CredoValidationError",
    "CredoWebhookError",
    "CredoConfigError",
    "CredoPaymentError",
    # Models
    "PaymentRequest",
    "PaymentResponse",
    "TransactionStatus",
    "FeeBearer",
    "VerifyResponse",
    "WebhookEvent",
    "Customer",
    # Utilities
    "CallbackData",
    "build_callback_url",
    "generate_payment_reference",
    "sanitize_reference_part",
    "sign_callback_params",
    "verify_callback_signature",
    # Idempotency
    "PaymentEventResult",
    "model_payment_lock",
    "process_payment_event",
    # Views (pure Django)
    "DjangoCredoWebhookView",
    # Views (DRF — requires djangorestframework)
    "CredoWebhookView",
]
