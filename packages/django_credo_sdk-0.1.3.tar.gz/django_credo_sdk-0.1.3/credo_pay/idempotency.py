"""
Idempotent payment event helpers.

Use these helpers when a callback and webhook can arrive at the same time for
the same transaction. They wrap handler execution in transaction.atomic() and
lock the affected Django row with select_for_update().
"""

from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Type, Union

from django.db import models, transaction

from .models import VerifyResponse, WebhookEvent


PaymentEvent = Union[VerifyResponse, WebhookEvent]
PaymentLock = Callable[[str], Any]
PaymentHandler = Callable[[PaymentEvent, Any], Any]


@dataclass
class PaymentEventResult:
    """Result from process_payment_event()."""

    reference: str
    outcome: str  # "success", "failed", "pending", "skipped"
    event: PaymentEvent
    locked_object: Any = None
    handler_result: Any = None

    @property
    def is_successful(self) -> bool:
        return self.outcome == "success"

    @property
    def is_failed(self) -> bool:
        return self.outcome == "failed"

    @property
    def is_pending(self) -> bool:
        return self.outcome == "pending"

    @property
    def is_skipped(self) -> bool:
        """True when the payment was already in a terminal state (idempotency guard)."""
        return self.outcome == "skipped"


def model_payment_lock(
    model: Type[models.Model],
    *,
    lookup_field: Union[str, Callable] = "credo_trans_ref",
) -> PaymentLock:
    """
    Build a lock callback for process_payment_event().

    lookup_field accepts:

    - A string field name for a single-field exact match (default)::

        lock = model_payment_lock(Order, lookup_field="credo_trans_ref")

    - A callable ``(model, reference) -> QuerySet`` for custom lookups,
      including OR queries when a webhook and a callback carry different
      reference fields::

          from django.db.models import Q

          lock = model_payment_lock(
              Payment,
              lookup_field=lambda m, ref: m.objects.filter(
                  Q(credo_trans_ref=ref) | Q(business_reference=ref)
              ),
          )
    """

    def lock(reference: str) -> models.Model:
        if callable(lookup_field):
            return lookup_field(model, reference).select_for_update().get()
        return model._default_manager.select_for_update().get(**{lookup_field: reference})

    return lock


def process_payment_event(
    *,
    reference: str,
    event: PaymentEvent,
    on_success: PaymentHandler,
    on_failure: PaymentHandler,
    on_pending: Optional[PaymentHandler] = None,
    lock: Optional[PaymentLock] = None,
    terminal_field: Optional[str] = None,
    terminal_values: Optional[List[Any]] = None,
    on_commit: Optional[Callable] = None,
) -> PaymentEventResult:
    """
    Process a verified payment event under a database transaction.

    Handlers receive ``(event, locked_object)``. Provide
    ``lock=model_payment_lock(...)`` or your own lock callback to make status
    updates safe under concurrent callback/webhook delivery.

    **Idempotency guard** — ``terminal_field`` / ``terminal_values``: if the
    locked object is already in a terminal state, the handler is skipped and
    ``outcome`` is ``"skipped"``::

        process_payment_event(
            reference=event.trans_ref,
            event=event,
            lock=model_payment_lock(Payment, lookup_field="credo_trans_ref"),
            terminal_field="status",
            terminal_values=["paid", "failed"],
            on_success=mark_paid,
            on_failure=mark_failed,
        )

    **Post-commit hook** — ``on_commit``: called with
    ``(event, locked_object, handler_result)`` after the transaction commits.
    Use for side effects that must not run if the transaction rolls back
    (confirmation emails, push notifications, WebSocket broadcasts)::

        process_payment_event(
            ...
            on_success=mark_paid,
            on_commit=lambda event, obj, result: send_confirmation_email(obj),
        )
    """
    outcome = "pending"
    handler_result = None
    locked_object = None

    with transaction.atomic():
        if lock is not None:
            locked_object = lock(reference)

        # Idempotency: skip if the object is already in a terminal state.
        if (
            terminal_field is not None
            and terminal_values is not None
            and locked_object is not None
            and getattr(locked_object, terminal_field, None) in terminal_values
        ):
            return PaymentEventResult(reference, "skipped", event, locked_object, None)

        if event.is_successful:
            handler_result = on_success(event, locked_object)
            outcome = "success"
        elif event.is_failed:
            handler_result = on_failure(event, locked_object)
            outcome = "failed"
        else:
            handler_result = on_pending(event, locked_object) if on_pending else None
            outcome = "pending"

        # Register the post-commit hook inside the atomic block so it is
        # deferred until the transaction actually commits and discarded if
        # the transaction rolls back.
        if outcome == "success" and on_commit is not None:
            _obj = locked_object
            _res = handler_result
            transaction.on_commit(lambda: on_commit(event, _obj, _res))

    return PaymentEventResult(reference, outcome, event, locked_object, handler_result)
