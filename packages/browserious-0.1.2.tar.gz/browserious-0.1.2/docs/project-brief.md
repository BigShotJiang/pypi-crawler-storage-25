# Browser API Wrapper - Project Brief

## Goal

Build a self-hosted, horizontally scalable browser-as-a-service with:

- REST/WebSocket API for browser control
- Persistent browser profiles
- Extension support
- Proxy configuration per session
- Remote screen access (VNC/noVNC)
- Permissive licensing (MIT/Apache 2.0 only)

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  Docker Container                                   │
│  ┌───────────────────────────────────────────────┐  │
│  │  Xvfb (:99)          - Virtual framebuffer    │  │
│  │  x11vnc              - VNC server             │  │
│  │  noVNC/websockify    - Web VNC client         │  │
│  │  Chromium            - Full browser           │  │
│  │  API Server (FastAPI)- Control interface      │  │
│  └───────────────────────────────────────────────┘  │
│                                                     │
│  Ports:                                             │
│    5900  - VNC (native clients)                     │
│    6080  - noVNC (web browser access)               │
│    9222  - Chrome DevTools Protocol                 │
│    8000  - REST API                                 │
└─────────────────────────────────────────────────────┘
```

## Tech Stack

|Component            |Choice                                      |License                       |
|---------------------|--------------------------------------------|------------------------------|
|Base image           |`mcr.microsoft.com/playwright:v1.49.0-noble`|Apache 2.0                    |
|Browser control      |Playwright (Python)                         |Apache 2.0                    |
|Virtual display      |Xvfb                                        |MIT                           |
|VNC server           |x11vnc                                      |GPL-2.0 (server-side only, OK)|
|Web VNC              |noVNC + websockify                          |MPL-2.0                       |
|Process manager      |Supervisor                                  |BSD                           |
|API framework        |FastAPI                                     |MIT                           |
|Task queue (optional)|Celery + Redis                              |BSD                           |

## File Structure

```
browser-api/
├── Dockerfile
├── docker-compose.yml
├── supervisord.conf
├── requirements.txt
├── src/
│   ├── __init__.py
│   ├── main.py              # FastAPI app
│   ├── browser_manager.py   # Playwright wrapper
│   ├── models.py            # Pydantic models
│   └── config.py            # Settings
├── extensions/              # Chrome extensions (unpacked)
├── profiles/                # Persistent browser profiles
└── README.md
```

## API Design

### Sessions

```
POST   /sessions                 - Create new browser session
GET    /sessions                 - List active sessions
GET    /sessions/{id}            - Get session info (CDP URL, VNC URL)
DELETE /sessions/{id}            - Close session
```

### Session Options (POST /sessions body)

```json
{
  "profile_id": "user-123",        // Reuse existing profile or create new
  "proxy": {
    "server": "http://proxy:8080",
    "username": "user",
    "password": "pass"
  },
  "extensions": ["ublock", "custom-ext"],
  "viewport": {"width": 1920, "height": 1080},
  "user_agent": "...",
  "timeout": 3600                  // Session TTL in seconds
}
```

### Response

```json
{
  "session_id": "abc-123",
  "cdp_url": "ws://host:9222/devtools/browser/...",
  "vnc_url": "http://host:6080/vnc.html?path=...",
  "live_view": "http://host:6080/vnc.html?autoconnect=true",
  "expires_at": "2024-01-01T12:00:00Z"
}
```

### Pages (within session)

```
POST   /sessions/{id}/pages              - New page/tab
GET    /sessions/{id}/pages              - List pages
POST   /sessions/{id}/pages/{pid}/goto   - Navigate
POST   /sessions/{id}/pages/{pid}/click  - Click element
POST   /sessions/{id}/pages/{pid}/type   - Type text
POST   /sessions/{id}/pages/{pid}/eval   - Run JavaScript
GET    /sessions/{id}/pages/{pid}/screenshot - Get screenshot
GET    /sessions/{id}/pages/{pid}/content    - Get HTML
```

### Storage State

```
GET    /profiles/{profile_id}/state      - Export cookies/localStorage
PUT    /profiles/{profile_id}/state      - Import state
DELETE /profiles/{profile_id}            - Delete profile
```

## Dockerfile

```dockerfile
FROM mcr.microsoft.com/playwright:v1.49.0-noble

# Install display and VNC stack
RUN apt-get update && apt-get install -y --no-install-recommends \
    xvfb \
    x11vnc \
    novnc \
    websockify \
    supervisor \
    python3-pip \
    && rm -rf /var/lib/apt/lists/*

# Python deps
COPY requirements.txt /app/
RUN pip install --no-cache-dir -r /app/requirements.txt

# App code
COPY src/ /app/src/
COPY supervisord.conf /etc/supervisor/conf.d/supervisord.conf

# Directories
RUN mkdir -p /data/profiles /data/extensions

ENV DISPLAY=:99
ENV RESOLUTION=1920x1080x24
ENV PYTHONPATH=/app

WORKDIR /app

EXPOSE 5900 6080 8000 9222

CMD ["/usr/bin/supervisord", "-c", "/etc/supervisor/conf.d/supervisord.conf"]
```

## supervisord.conf

```ini
[supervisord]
nodaemon=true
user=root
logfile=/var/log/supervisor/supervisord.log
childlogdir=/var/log/supervisor

[program:xvfb]
command=Xvfb :99 -screen 0 %(ENV_RESOLUTION)s -ac
autorestart=true
priority=100
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0

[program:x11vnc]
command=x11vnc -display :99 -forever -shared -nopw -rfbport 5900 -xkb
autorestart=true
priority=200
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0

[program:novnc]
command=websockify --web=/usr/share/novnc/ 6080 localhost:5900
autorestart=true
priority=300
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0

[program:api]
command=python -m uvicorn src.main:app --host 0.0.0.0 --port 8000
environment=DISPLAY=":99"
autorestart=true
priority=400
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
```

## requirements.txt

```
fastapi>=0.109.0
uvicorn[standard]>=0.27.0
playwright>=1.49.0
pydantic>=2.0.0
pydantic-settings>=2.0.0
python-multipart>=0.0.6
```

## Core Implementation Sketch

### src/config.py

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    profiles_dir: str = "/data/profiles"
    extensions_dir: str = "/data/extensions"
    default_timeout: int = 3600
    max_sessions: int = 10

settings = Settings()
```

### src/models.py

```python
from pydantic import BaseModel
from typing import Optional

class ProxyConfig(BaseModel):
    server: str
    username: Optional[str] = None
    password: Optional[str] = None

class SessionCreate(BaseModel):
    profile_id: Optional[str] = None
    proxy: Optional[ProxyConfig] = None
    extensions: list[str] = []
    viewport: dict = {"width": 1920, "height": 1080}
    user_agent: Optional[str] = None
    timeout: int = 3600

class SessionResponse(BaseModel):
    session_id: str
    cdp_url: str
    vnc_url: str
    live_view: str
    expires_at: str
```

### src/browser_manager.py

```python
import asyncio
import uuid
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext
from .config import settings

class BrowserSession:
    def __init__(self, session_id: str, context: BrowserContext, profile_path: Path):
        self.session_id = session_id
        self.context = context
        self.profile_path = profile_path
        self.pages = {}

class BrowserManager:
    def __init__(self):
        self.sessions: dict[str, BrowserSession] = {}
        self.playwright = None

    async def start(self):
        self.playwright = await async_playwright().start()

    async def create_session(
        self,
        profile_id: str | None = None,
        proxy: dict | None = None,
        extensions: list[str] = [],
        viewport: dict = {"width": 1920, "height": 1080},
        user_agent: str | None = None,
    ) -> BrowserSession:
        session_id = str(uuid.uuid4())

        # Profile path
        profile_id = profile_id or session_id
        profile_path = Path(settings.profiles_dir) / profile_id

        # Build extension args
        ext_args = []
        if extensions:
            ext_paths = [str(Path(settings.extensions_dir) / e) for e in extensions]
            ext_args = [
                f"--disable-extensions-except={','.join(ext_paths)}",
                *[f"--load-extension={p}" for p in ext_paths],
            ]

        # Launch persistent context
        context = await self.playwright.chromium.launch_persistent_context(
            user_data_dir=str(profile_path),
            headless=False,  # Need headed for extensions + VNC
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                *ext_args,
            ],
            ignore_default_args=["--disable-extensions"] if extensions else [],
            proxy=proxy,
            viewport=viewport,
            user_agent=user_agent,
        )

        session = BrowserSession(session_id, context, profile_path)
        self.sessions[session_id] = session
        return session

    async def close_session(self, session_id: str):
        if session_id in self.sessions:
            session = self.sessions.pop(session_id)
            await session.context.close()

    async def get_session(self, session_id: str) -> BrowserSession | None:
        return self.sessions.get(session_id)

manager = BrowserManager()
```

### src/main.py

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from datetime import datetime, timedelta

from .browser_manager import manager
from .models import SessionCreate, SessionResponse

@asynccontextmanager
async def lifespan(app: FastAPI):
    await manager.start()
    yield
    # Cleanup sessions on shutdown
    for session_id in list(manager.sessions.keys()):
        await manager.close_session(session_id)

app = FastAPI(title="Browser API", lifespan=lifespan)

@app.post("/sessions", response_model=SessionResponse)
async def create_session(req: SessionCreate):
    session = await manager.create_session(
        profile_id=req.profile_id,
        proxy=req.proxy.model_dump() if req.proxy else None,
        extensions=req.extensions,
        viewport=req.viewport,
        user_agent=req.user_agent,
    )

    # TODO: Get actual CDP endpoint from browser
    return SessionResponse(
        session_id=session.session_id,
        cdp_url=f"ws://localhost:9222/devtools/browser/{session.session_id}",
        vnc_url="vnc://localhost:5900",
        live_view="http://localhost:6080/vnc.html?autoconnect=true",
        expires_at=(datetime.utcnow() + timedelta(seconds=req.timeout)).isoformat(),
    )

@app.get("/sessions")
async def list_sessions():
    return {"sessions": list(manager.sessions.keys())}

@app.get("/sessions/{session_id}")
async def get_session(session_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, "Session not found")
    return {"session_id": session_id, "pages": len(session.context.pages)}

@app.delete("/sessions/{session_id}")
async def delete_session(session_id: str):
    await manager.close_session(session_id)
    return {"status": "closed"}

@app.post("/sessions/{session_id}/pages/{page_idx}/goto")
async def page_goto(session_id: str, page_idx: int, url: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, "Session not found")
    pages = session.context.pages
    if page_idx >= len(pages):
        raise HTTPException(404, "Page not found")
    await pages[page_idx].goto(url)
    return {"status": "ok", "url": url}

@app.get("/sessions/{session_id}/pages/{page_idx}/screenshot")
async def page_screenshot(session_id: str, page_idx: int):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, "Session not found")
    pages = session.context.pages
    if page_idx >= len(pages):
        raise HTTPException(404, "Page not found")
    screenshot = await pages[page_idx].screenshot()
    from fastapi.responses import Response
    return Response(content=screenshot, media_type="image/png")
```

## docker-compose.yml

```yaml
services:
  browser-api:
    build: .
    shm_size: 2g
    ports:
      - "5900:5900"   # VNC
      - "6080:6080"   # noVNC web
      - "8000:8000"   # API
      - "9222:9222"   # CDP (optional direct access)
    volumes:
      - ./profiles:/data/profiles
      - ./extensions:/data/extensions
    environment:
      - RESOLUTION=1920x1080x24
    restart: unless-stopped

  # Optional: Redis for session state / task queue
  # redis:
  #   image: redis:alpine
  #   ports:
  #     - "6379:6379"
```

## TODO / Future Enhancements

1. **Horizontal scaling**: Run multiple containers, use Redis for session registry
1. **Session isolation**: One browser per container vs multiple contexts
1. **Proxy rotation**: Pool of proxies, rotate per request
1. **Recording**: Save session recordings (playwright trace)
1. **Webhooks**: Notify on session events
1. **Auth**: API key authentication
1. **Resource limits**: CPU/memory per session
1. **Health checks**: Auto-restart dead browsers

## Usage Example

```bash
# Start
docker-compose up -d

# Create session with proxy
curl -X POST http://localhost:8000/sessions \
  -H "Content-Type: application/json" \
  -d '{
    "profile_id": "my-profile",
    "proxy": {"server": "http://proxy:8080"},
    "extensions": ["ublock"]
  }'

# Open VNC in browser
open http://localhost:6080/vnc.html?autoconnect=true

# Navigate
curl -X POST "http://localhost:8000/sessions/{id}/pages/0/goto?url=https://example.com"

# Screenshot
curl http://localhost:8000/sessions/{id}/pages/0/screenshot > screenshot.png
```

## References

- Playwright persistent context: https://playwright.dev/python/docs/api/class-browsertype#browser-type-launch-persistent-context
- Playwright extensions: https://playwright.dev/python/docs/chrome-extensions
- noVNC: https://github.com/novnc/noVNC
- x11vnc: https://github.com/LibVNC/x11vnc
