# Task 032: Node API with Hardware Input Simulation

## Overview

Create a lightweight Go-based API that runs inside each browser node container, providing low-level control capabilities including human-like mouse/keyboard simulation with precise timing.

## Motivation

Current architecture requires `docker exec` for container-level operations, which is:
- Slow (process spawn overhead)
- Requires Docker socket access in API container (security concern)
- No persistent state or connection pooling
- Hard to achieve precise timing for input simulation

A dedicated node API enables:
- Fast HTTP-based communication over Docker network
- Precise timing control for human-like input simulation
- Local profile operations (no network transfer)
- Optional/lazy VNC startup
- Clean separation of concerns

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  API Container (browserious-api)                             │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  FastAPI :8100                                         │ │
│  │  - Proxies /sessions/{id}/input/* to node API          │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
           │
           │ HTTP over Docker network
           ▼
┌─────────────────────────────────────────────────────────────┐
│  Browser Node Container                                      │
│  ┌──────────────────┐  ┌──────────────────────────────────┐ │
│  │  Node API :8080  │  │  Xvfb :99                        │ │
│  │  (Go binary)     │  │    ▲                             │ │
│  │                  │──┼────┤ X11 input events            │ │
│  │  POST /play      │  │    │                             │ │
│  │  GET /health     │  │  Chromium (CDP :9222)            │ │
│  │                  │  │  x11vnc :5900                    │ │
│  └──────────────────┘  └──────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Core Feature: Playlist Executor

### Concept

Instead of individual API calls per input action, users submit a "playlist" of actions with timing parameters. The node API executes them with precise timing, enabling human-like input patterns.

### Request Format

```
POST /play
Content-Type: application/json

{
  "actions": [
    {"type": "move", "x": 500, "y": 300, "duration_ms": 250, "easing": {"x": "ease_out", "y": "linear"}},
    {"type": "sleep", "duration_ms": 50},
    {"type": "mouse_down", "button": 1},
    {"type": "sleep", "duration_ms": 30},
    {"type": "mouse_up", "button": 1},
    {"type": "sleep", "duration_ms": 200},
    {"type": "type_text", "text": "hello world", "interval": {"min_ms": 40, "max_ms": 120}}
  ]
}
```

### Action Types

| Action | Parameters | Description |
|--------|------------|-------------|
| `move` | x, y, duration_ms, easing | Animated mouse movement with easing |
| `sleep` | duration_ms | Pause execution |
| `mouse_down` | button (1=left, 2=middle, 3=right) | Press mouse button |
| `mouse_up` | button | Release mouse button |
| `click` | button, x?, y?, count? | Move + down + sleep + up |
| `key_down` | key | Press key (X11 keysym or name) |
| `key_up` | key | Release key |
| `key` | key | Down + short sleep + up |
| `type_text` | text, interval{min_ms, max_ms} | Human-like typing with random delays |
| `scroll` | delta_x, delta_y, duration_ms? | Mouse wheel scroll |

### Easing Functions

For `move` action, X and Y can have independent easing. Full Robert Penner easing set (30 functions):

| Category | easeIn | easeOut | easeInOut |
|----------|--------|---------|-----------|
| **Linear** | `linear` | - | - |
| **Sine** | `ease_in_sine` | `ease_out_sine` | `ease_in_out_sine` |
| **Quad** | `ease_in_quad` | `ease_out_quad` | `ease_in_out_quad` |
| **Cubic** | `ease_in_cubic` | `ease_out_cubic` | `ease_in_out_cubic` |
| **Quart** | `ease_in_quart` | `ease_out_quart` | `ease_in_out_quart` |
| **Quint** | `ease_in_quint` | `ease_out_quint` | `ease_in_out_quint` |
| **Expo** | `ease_in_expo` | `ease_out_expo` | `ease_in_out_expo` |
| **Circ** | `ease_in_circ` | `ease_out_circ` | `ease_in_out_circ` |
| **Back** | `ease_in_back` | `ease_out_back` | `ease_in_out_back` |
| **Elastic** | `ease_in_elastic` | `ease_out_elastic` | `ease_in_out_elastic` |
| **Bounce** | `ease_in_bounce` | `ease_out_bounce` | `ease_in_out_bounce` |

**Formulas (t = 0..1):**

```go
// Power functions (quad, cubic, quart, quint)
func easeInQuad(t float64) float64  { return t * t }
func easeOutQuad(t float64) float64 { return 1 - (1-t)*(1-t) }
func easeInOutQuad(t float64) float64 {
    if t < 0.5 { return 2 * t * t }
    return 1 - math.Pow(-2*t+2, 2)/2
}
// Cubic: t³, Quart: t⁴, Quint: t⁵ (same pattern)

// Sine
func easeInSine(t float64) float64    { return 1 - math.Cos(t*math.Pi/2) }
func easeOutSine(t float64) float64   { return math.Sin(t * math.Pi / 2) }
func easeInOutSine(t float64) float64 { return -(math.Cos(math.Pi*t) - 1) / 2 }

// Exponential
func easeInExpo(t float64) float64 {
    if t == 0 { return 0 }
    return math.Pow(2, 10*t-10)
}
func easeOutExpo(t float64) float64 {
    if t == 1 { return 1 }
    return 1 - math.Pow(2, -10*t)
}

// Circular
func easeInCirc(t float64) float64  { return 1 - math.Sqrt(1-t*t) }
func easeOutCirc(t float64) float64 { return math.Sqrt(1 - math.Pow(t-1, 2)) }

// Back (overshoot)
func easeInBack(t float64) float64 {
    c1, c3 := 1.70158, 2.70158
    return c3*t*t*t - c1*t*t
}
func easeOutBack(t float64) float64 {
    c1, c3 := 1.70158, 2.70158
    return 1 + c3*math.Pow(t-1, 3) + c1*math.Pow(t-1, 2)
}

// Elastic (spring)
func easeOutElastic(t float64) float64 {
    if t == 0 || t == 1 { return t }
    c4 := (2 * math.Pi) / 3
    return math.Pow(2, -10*t) * math.Sin((t*10-0.75)*c4) + 1
}

// Bounce (piecewise parabolas)
func easeOutBounce(t float64) float64 {
    n1, d1 := 7.5625, 2.75
    if t < 1/d1 {
        return n1 * t * t
    } else if t < 2/d1 {
        t -= 1.5 / d1
        return n1*t*t + 0.75
    } else if t < 2.5/d1 {
        t -= 2.25 / d1
        return n1*t*t + 0.9375
    }
    t -= 2.625 / d1
    return n1*t*t + 0.984375
}
func easeInBounce(t float64) float64 { return 1 - easeOutBounce(1-t) }
```

**Example with independent X/Y easing:**

```json
{
  "type": "move",
  "x": 800,
  "y": 400,
  "duration_ms": 300,
  "easing": {
    "x": "ease_out_cubic",
    "y": "ease_in_out_sine"
  }
}
```

### Response Format

```json
{
  "status": "ok",
  "executed": 7,
  "duration_ms": 1250
}
```

On error:
```json
{
  "status": "error",
  "error": "invalid key: NonExistentKey",
  "executed": 3,
  "failed_at": 4
}
```

## Implementation Details

### Why Go?

- `time.Sleep` has nanosecond precision
- No GIL - true parallelism for X/Y interpolation
- Tiny static binary (~5-10MB)
- Fast startup (<10ms)
- Can use CGO for direct X11 calls if needed

### X11 Integration Options

| Method | Latency | Complexity | Dependencies |
|--------|---------|------------|--------------|
| exec xdotool per action | ~5ms | Simple | xdotool binary |
| xdotool stdin pipe | ~0.5ms | Simple | xdotool binary |
| libxdo (CGO) | ~0.1ms | Medium | libxdo-dev |
| pure X11 (CGO) | ~0.01ms | Complex | libx11-dev |

**Recommendation:** Start with xdotool stdin pipe for simplicity. Upgrade to CGO if latency becomes an issue.

```go
// Persistent xdotool process
cmd := exec.Command("xdotool", "-")
stdin, _ := cmd.StdinPipe()
cmd.Start()

// Write commands with minimal latency
stdin.Write([]byte("mousemove 100 200\n"))
```

### Mouse Movement Interpolation

```go
func animateMouseMove(targetX, targetY, durationMs int, easing EasingConfig) {
    startX, startY := getCurrentMousePos()

    frameInterval := 10 * time.Millisecond  // 100fps
    frames := durationMs / 10

    for i := 0; i <= frames; i++ {
        t := float64(i) / float64(frames)  // 0.0 to 1.0

        easedX := applyEasing(t, easing.X)
        easedY := applyEasing(t, easing.Y)

        x := startX + int(float64(targetX-startX)*easedX)
        y := startY + int(float64(targetY-startY)*easedY)

        xdoMouseMove(x, y)
        time.Sleep(frameInterval)
    }
}
```

### Typing Simulation

```go
func typeTextWithVariance(text string, interval IntervalConfig) {
    for _, char := range text {
        key := charToKeysym(char)

        xdoKeyDown(key)
        time.Sleep(randomDuration(10, 30))  // realistic key hold
        xdoKeyUp(key)

        // Random delay between keystrokes
        delay := randomDuration(interval.MinMs, interval.MaxMs)
        time.Sleep(delay)
    }
}
```

## File Structure

```
node/
├── api/
│   ├── main.go           # HTTP server, /play endpoint
│   ├── playlist.go       # Playlist executor
│   ├── actions.go        # Action type definitions
│   ├── easing.go         # Easing functions
│   ├── xdo.go            # xdotool interface
│   └── go.mod
├── Dockerfile            # Multi-stage: build Go + runtime
└── entrypoint.sh         # Start node API + Chrome + Xvfb
```

## Dockerfile Changes

```dockerfile
# Build stage for Go API
FROM golang:1.21-alpine AS builder
WORKDIR /build
COPY api/ .
RUN go build -o node-api .

# Runtime stage
FROM mcr.microsoft.com/playwright:v1.49.1-noble

RUN apt-get update && apt-get install -y --no-install-recommends \
    xvfb \
    x11vnc \
    socat \
    xdotool \
    && rm -rf /var/lib/apt/lists/*

COPY --from=builder /build/node-api /usr/local/bin/
COPY entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh

EXPOSE 5900 8080 9222

ENTRYPOINT ["/entrypoint.sh"]
```

## Main API Integration

New endpoints in browserious-api:

```python
@app.post("/sessions/{session_id}/input/play")
async def play_input(session_id: str, playlist: Playlist):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, "Session not found")

    # Forward to node API
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"http://{session.container_ip}:8080/play",
            json=playlist.dict(),
            timeout=playlist.estimated_duration_ms / 1000 + 5
        )
    return response.json()
```

## Future Extensions (Out of Scope)

These could be added to the node API later:

| Endpoint | Purpose |
|----------|---------|
| `POST /vnc/start` | Start x11vnc on demand |
| `POST /vnc/stop` | Stop x11vnc |
| `GET /screenshot` | Fast X11 screenshot |
| `GET /profile/cookies` | Export cookies |
| `PUT /profile/cookies` | Import cookies |
| `GET /mouse/position` | Current mouse coordinates |

## Acceptance Criteria

1. [ ] Go-based node API runs inside browser containers on port 8080
2. [ ] `POST /play` executes action playlists with precise timing
3. [ ] Mouse movement supports easing functions (linear, ease_in, ease_out, ease_in_out)
4. [ ] X and Y axes can have independent easing
5. [ ] `type_text` action simulates human-like typing with random intervals
6. [ ] All mouse actions work: move, mouse_down, mouse_up, click, scroll
7. [ ] All keyboard actions work: key_down, key_up, key, type_text
8. [ ] Main API proxies requests to node API via container IP
9. [ ] Node API starts automatically with container
10. [ ] `GET /health` endpoint for container health checks
11. [ ] Error handling returns meaningful messages with execution state

## Testing

```python
# Test human-like click
requests.post(f"{API_URL}/sessions/{sid}/input/play", json={
    "actions": [
        {"type": "move", "x": 500, "y": 300, "duration_ms": 200, "easing": {"x": "ease_out", "y": "ease_in_out"}},
        {"type": "sleep", "duration_ms": 50},
        {"type": "mouse_down", "button": 1},
        {"type": "sleep", "duration_ms": 25},
        {"type": "mouse_up", "button": 1}
    ]
})

# Test typing
requests.post(f"{API_URL}/sessions/{sid}/input/play", json={
    "actions": [
        {"type": "click", "x": 400, "y": 200, "button": 1},
        {"type": "sleep", "duration_ms": 100},
        {"type": "type_text", "text": "Hello, World!", "interval": {"min_ms": 50, "max_ms": 150}}
    ]
})
```

## References

- xdotool man page: https://www.semicomplete.com/projects/xdotool/
- X11 keysyms: /usr/include/X11/keysymdef.h
- Easing functions: https://easings.net/
