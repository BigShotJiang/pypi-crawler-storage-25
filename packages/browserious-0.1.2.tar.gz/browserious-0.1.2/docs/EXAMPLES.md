# Browserious API Examples & Cheatsheet

Quick reference for common operations. For full API documentation, see [API.md](API.md).

## Setup

```bash
export API_URL="http://localhost:8100"
export API_KEY="your-api-key"
```

```python
import requests

API_URL = "http://localhost:8100"
API_KEY = "your-api-key"
headers = {"X-API-Key": API_KEY}
```

---

## Sessions

### Create Session (Basic)

```bash
curl -X POST $API_URL/sessions \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"timeout": 3600}'
```

```python
session = requests.post(f"{API_URL}/sessions", headers=headers, json={"timeout": 3600}).json()
session_id = session["session_id"]
print(f"VNC: {session['web_vnc_url']}")
```

### Create Session (With Options)

```python
session = requests.post(f"{API_URL}/sessions", headers=headers, json={
    "profile_id": "my-profile",
    "proxy": {"server": "http://proxy.example.com:8080"},
    "viewport": {"width": 1280, "height": 720},
    "user_agent": "Mozilla/5.0 (Custom Agent)",
    "timeout": 7200
}).json()
```

### List Sessions

```bash
curl -H "X-API-Key: $API_KEY" $API_URL/sessions
```

```python
sessions = requests.get(f"{API_URL}/sessions", headers=headers).json()
print(f"Active sessions: {sessions['total']}")
```

### Delete Session

```bash
curl -X DELETE -H "X-API-Key: $API_KEY" $API_URL/sessions/$SESSION_ID
```

```python
requests.delete(f"{API_URL}/sessions/{session_id}", headers=headers)
```

---

## Pages

### Create New Page

```python
page = requests.post(f"{API_URL}/sessions/{session_id}/pages", headers=headers).json()
page_id = page["page_id"]
```

### Navigate

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/goto",
    headers=headers,
    json={"url": "https://example.com", "wait_until": "networkidle"}
).json()
print(f"Loaded: {result['url']} in {result['load_time_ms']}ms")
```

### Click Element

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/click",
    headers=headers,
    json={"selector": {"strategy": "css", "value": "#submit-button"}}
)
```

### Type Text (With Keyboard Events)

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/type",
    headers=headers,
    json={
        "selector": {"strategy": "css", "value": "input[name='search']"},
        "text": "hello world",
        "delay": 50
    }
)
```

### Fill Input (Fast, No Events)

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/fill",
    headers=headers,
    json={
        "selector": {"strategy": "css", "value": "#email"},
        "value": "user@example.com"
    }
)
```

### Wait for Element

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/waitForSelector",
    headers=headers,
    json={
        "selector": {"strategy": "css", "value": ".loading"},
        "state": "hidden",
        "timeout": 10000
    }
)
```

### Execute JavaScript

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": "return document.title"}
).json()
print(f"Title: {result['result']}")
```

### Screenshot

```python
screenshot = requests.get(
    f"{API_URL}/sessions/{session_id}/screenshot",
    headers=headers,
    params={"full_page": True, "type": "png"}
)
with open("screenshot.png", "wb") as f:
    f.write(screenshot.content)
```

### Get Page HTML

```python
content = requests.get(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/content",
    headers=headers
).json()
print(f"HTML length: {content['length']}")
```

---

## Selector Strategies

All selection operations support these strategies:

| Strategy | Example | Use Case |
|----------|---------|----------|
| `css` | `#submit-button` | Most common, simple elements |
| `xpath` | `//button[text()='Submit']` | Complex DOM traversal |
| `text` | `text=Submit` | Find by visible text |
| `role` | `role=button[name='Submit']` | Accessibility-based (modern) |
| `js` | `() => document.querySelector('.item')` | Custom logic |

```python
selectors = [
    {"strategy": "css", "value": "#login-btn"},
    {"strategy": "xpath", "value": "//input[@type='email']"},
    {"strategy": "text", "value": "text=Sign In"},
    {"strategy": "role", "value": "role=button[name='Login']"},
    {"strategy": "js", "value": "() => document.forms[0].querySelector('button')"},
]
```

---

## Request Interception

### Block Images (Speed Up Scraping)

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/routes",
    headers=headers,
    json={
        "pattern": "**/*.{png,jpg,jpeg,gif,svg,webp}",
        "action": {"type": "block"}
    }
)
```

### Block Ads/Trackers

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/routes",
    headers=headers,
    json={
        "pattern": "**/*{analytics,tracking,ads}*",
        "action": {"type": "block"}
    }
)
```

### Mock API Response

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/routes",
    headers=headers,
    json={
        "pattern": "**/api/user",
        "action": {
            "type": "override",
            "status": 200,
            "headers": {"Content-Type": "application/json"},
            "body": '{"id": 123, "name": "Test User", "email": "test@example.com"}'
        }
    }
)
```

### Redirect URL

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/routes",
    headers=headers,
    json={
        "pattern": "**/api/v1/**",
        "action": {"type": "redirect", "url": "https://api.example.com/v2/"}
    }
)
```

### Capture/Inspect Requests

```python
route = requests.post(
    f"{API_URL}/sessions/{session_id}/routes",
    headers=headers,
    json={
        "pattern": "**/api/**",
        "action": {"type": "inspect", "capture_body": True}
    }
).json()
route_id = route["route_id"]

requests.post(f"{API_URL}/sessions/{session_id}/pages/page-0/goto", headers=headers,
    json={"url": "https://example.com"})

captured = requests.get(
    f"{API_URL}/sessions/{session_id}/routes/{route_id}/inspect",
    headers=headers
).json()
for req in captured["requests"]:
    print(f"{req['method']} {req['url']} -> {req['response']['status']}")
```

---

## VNC Remote Viewing

### Web VNC (In Browser)

Open in your browser:
```
http://localhost:8100/vnc.html?session={session_id}
```

### Programmatic VNC URL

```python
session = requests.post(f"{API_URL}/sessions", headers=headers, json={"timeout": 3600}).json()
print(f"Open in browser: {session['web_vnc_url']}")
```

---

## Input Simulation

Hardware-level input using X11 events. **Important:** Coordinates are in screen space, not browser viewport. See coordinate conversion below.

### Complete Example: Click and Type in Google Search

This example demonstrates the full workflow: coordinate conversion, mouse movement with easing, clicking, and typing.

```python
import requests

API_URL = "http://localhost:8100"
headers = {"X-API-Key": "your-api-key"}

session = requests.post(f"{API_URL}/sessions", headers=headers, json={"timeout": 3600}).json()
session_id = session["session_id"]
page_id = "page-0"

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/goto", headers=headers,
    json={"url": "https://google.com", "wait_until": "networkidle"})

window_info = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """(() => ({
        screenX: window.screenX,
        screenY: window.screenY,
        chromeHeight: window.outerHeight - window.innerHeight,
        chromeWidth: window.outerWidth - window.innerWidth
    }))()"""}
).json()["result"]

offset_x = window_info['screenX']
offset_y = window_info['screenY'] + window_info['chromeHeight']

bbox = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """(() => {
        const el = document.querySelector("textarea[name='q']");
        if (!el) return null;
        const rect = el.getBoundingClientRect();
        return {x: rect.x + rect.width/2, y: rect.y + rect.height/2};
    })()"""}
).json()["result"]

screen_x = int(bbox["x"]) + offset_x
screen_y = int(bbox["y"]) + offset_y

result = requests.post(
    f"{API_URL}/sessions/{session_id}/input/play",
    headers=headers,
    json={"actions": [
        {"type": "move", "x": screen_x, "y": screen_y, "duration_ms": 400,
         "easing": {"x": "ease_out_cubic", "y": "ease_in_out_sine"}},
        {"type": "sleep", "duration_ms": 50},
        {"type": "click", "button": 1},
        {"type": "sleep", "duration_ms": 100},
        {"type": "type_text", "text": "browserious automation",
         "interval": {"min_ms": 40, "max_ms": 120}},
        {"type": "sleep", "duration_ms": 200},
        {"type": "key", "key": "Return"}
    ]}
).json()

print(f"Executed {result['executed']} actions in {result['duration_ms']}ms")

requests.delete(f"{API_URL}/sessions/{session_id}", headers=headers)
```

### Coordinate Conversion Helper

```python
def get_screen_offset(session_id, page_id, headers):
    """Get offset to convert viewport coords to screen coords."""
    info = requests.post(
        f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
        headers=headers,
        json={"script": """(() => ({
            screenX: window.screenX, screenY: window.screenY,
            chromeHeight: window.outerHeight - window.innerHeight,
            chromeWidth: window.outerWidth - window.innerWidth
        }))()"""}
    ).json()["result"]
    return (
        info['screenX'],
        info['screenY'] + info['chromeHeight']
    )

def get_element_center(session_id, page_id, selector, headers):
    """Get viewport center coordinates of an element."""
    bbox = requests.post(
        f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
        headers=headers,
        json={"script": f"""(() => {{
            const el = document.querySelector("{selector}");
            if (!el) return null;
            const rect = el.getBoundingClientRect();
            return {{x: rect.x + rect.width/2, y: rect.y + rect.height/2}};
        }})()"""}
    ).json()["result"]
    return bbox

offset_x, offset_y = get_screen_offset(session_id, page_id, headers)
bbox = get_element_center(session_id, page_id, "button#submit", headers)
screen_x = int(bbox["x"]) + offset_x
screen_y = int(bbox["y"]) + offset_y
```

### Human-like Click (Screen Coords)

```bash
curl -X POST "$API_URL/sessions/$SID/input/play" \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "actions": [
      {"type": "move", "x": 500, "y": 300, "duration_ms": 200, "easing": {"x": "ease_out_cubic", "y": "ease_in_out_sine"}},
      {"type": "sleep", "duration_ms": 50},
      {"type": "mouse_down", "button": 1},
      {"type": "sleep", "duration_ms": 25},
      {"type": "mouse_up", "button": 1}
    ]
  }'
```

### Type Text with Variable Timing

```bash
curl -X POST "$API_URL/sessions/$SID/input/play" \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "actions": [
      {"type": "click", "x": 400, "y": 200},
      {"type": "sleep", "duration_ms": 100},
      {"type": "type_text", "text": "hello world!", "interval": {"min_ms": 50, "max_ms": 150}}
    ]
  }'
```

### Drag and Drop

```bash
curl -X POST "$API_URL/sessions/$SID/input/play" \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "actions": [
      {"type": "move", "x": 100, "y": 100, "duration_ms": 150},
      {"type": "mouse_down", "button": 1},
      {"type": "move", "x": 400, "y": 300, "duration_ms": 500, "easing": {"x": "ease_in_out_quad", "y": "ease_in_out_quad"}},
      {"type": "mouse_up", "button": 1}
    ]
  }'
```

### Keyboard Shortcuts

```bash
curl -X POST "$API_URL/sessions/$SID/input/play" \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "actions": [
      {"type": "key_down", "key": "Control_L"},
      {"type": "key", "key": "a"},
      {"type": "key_up", "key": "Control_L"}
    ]
  }'
```

### Scroll Page

```bash
curl -X POST "$API_URL/sessions/$SID/input/play" \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "actions": [
      {"type": "scroll", "delta_x": 0, "delta_y": 5}
    ]
  }'
```

### Get Mouse Position

```python
pos = requests.get(f"{API_URL}/sessions/{session_id}/input/position", headers=headers).json()
print(f"Cursor at ({pos['x']}, {pos['y']})")
```

### Display Screenshot (with Cursor)

Captures the full X11 display (includes browser chrome):

```python
screenshot = requests.get(
    f"{API_URL}/sessions/{session_id}/screenshot",
    headers=headers,
    params={"fullscreen": True}
)
with open("display.png", "wb") as f:
    f.write(screenshot.content)
```

Page viewport only (default, supports full-page scroll):
```python
page_screenshot = requests.get(
    f"{API_URL}/sessions/{session_id}/screenshot",
    headers=headers,
    params={"full_page": True}
)
```

### Screenshot with Cursor Overlay

Use `cursor=true` to draw cursor position on screenshots:

```python
screenshot = requests.get(
    f"{API_URL}/sessions/{session_id}/screenshot",
    headers=headers,
    params={"cursor": True, "full_page": True}
)
with open("with_cursor.png", "wb") as f:
    f.write(screenshot.content)
```

### Debug Cursor Overlay (JavaScript Injection)

Inject a visual cursor that follows the mouse and appears in page screenshots. Useful for debugging coordinate mismatches.

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """
        (() => {
            if (document.getElementById('debug-cursor')) return 'already exists';

            const cursor = document.createElement('div');
            cursor.id = 'debug-cursor';
            cursor.style.cssText = `
                position: fixed;
                width: 20px;
                height: 20px;
                border: 3px solid red;
                border-radius: 50%;
                pointer-events: none;
                z-index: 999999;
                transform: translate(-50%, -50%);
                box-shadow: 0 0 10px rgba(255,0,0,0.5);
            `;

            const label = document.createElement('div');
            label.id = 'debug-cursor-label';
            label.style.cssText = `
                position: fixed;
                background: rgba(0,0,0,0.8);
                color: lime;
                font: 12px monospace;
                padding: 2px 6px;
                pointer-events: none;
                z-index: 999999;
                white-space: nowrap;
            `;

            document.body.appendChild(cursor);
            document.body.appendChild(label);

            document.addEventListener('mousemove', e => {
                cursor.style.left = e.clientX + 'px';
                cursor.style.top = e.clientY + 'px';
                label.style.left = (e.clientX + 15) + 'px';
                label.style.top = (e.clientY + 15) + 'px';
                label.textContent = `viewport: (${e.clientX}, ${e.clientY})`;
            });

            return 'cursor overlay injected';
        })()
    """}
)
```

Now when you move the mouse and take a screenshot, you'll see:
- A red circle at the cursor position
- A label showing viewport coordinates

To remove the overlay:

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """
        document.getElementById('debug-cursor')?.remove();
        document.getElementById('debug-cursor-label')?.remove();
        'removed';
    """}
)
```

**Coordinate Debugging Workflow:**

1. Inject the cursor overlay
2. Move mouse to target screen coordinates via `play_input`
3. Take a page screenshot
4. Check if the red circle is on the intended element
5. If misaligned, adjust your offset calculation

---

## Complete Workflows

### Web Scraping

```python
import requests

API_URL = "http://localhost:8100"
headers = {"X-API-Key": "your-api-key"}

session = requests.post(f"{API_URL}/sessions", headers=headers, json={"timeout": 1800}).json()
session_id = session["session_id"]
page_id = "page-0"

requests.post(f"{API_URL}/sessions/{session_id}/routes", headers=headers,
    json={"pattern": "**/*.{png,jpg,gif}", "action": {"type": "block"}})

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/goto", headers=headers,
    json={"url": "https://quotes.toscrape.com", "wait_until": "networkidle"})

data = requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval", headers=headers,
    json={"script": """
        return Array.from(document.querySelectorAll('.quote')).map(q => ({
            text: q.querySelector('.text').innerText,
            author: q.querySelector('.author').innerText
        }))
    """}).json()

for quote in data["result"]:
    print(f'"{quote["text"]}" - {quote["author"]}')

requests.delete(f"{API_URL}/sessions/{session_id}", headers=headers)
```

### Form Submission

```python
session = requests.post(f"{API_URL}/sessions", headers=headers, json={"timeout": 600}).json()
session_id = session["session_id"]
page_id = "page-0"

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/goto", headers=headers,
    json={"url": "https://httpbin.org/forms/post"})

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/fill", headers=headers,
    json={"selector": {"strategy": "css", "value": "input[name='custname']"}, "value": "John Doe"})

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/fill", headers=headers,
    json={"selector": {"strategy": "css", "value": "input[name='custemail']"}, "value": "john@example.com"})

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/click", headers=headers,
    json={"selector": {"strategy": "css", "value": "button[type='submit']"}})

import time
time.sleep(2)

screenshot = requests.get(f"{API_URL}/sessions/{session_id}/screenshot", headers=headers)
with open("form-result.png", "wb") as f:
    f.write(screenshot.content)

requests.delete(f"{API_URL}/sessions/{session_id}", headers=headers)
```

### E2E Testing with Mocked API

```python
session = requests.post(f"{API_URL}/sessions", headers=headers, json={"timeout": 300}).json()
session_id = session["session_id"]
page_id = "page-0"

requests.post(f"{API_URL}/sessions/{session_id}/routes", headers=headers,
    json={
        "pattern": "**/api/auth/login",
        "action": {
            "type": "override",
            "status": 200,
            "headers": {"Content-Type": "application/json"},
            "body": '{"token": "mock-jwt-token", "user": {"id": 1, "name": "Test User"}}'
        }
    })

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/goto", headers=headers,
    json={"url": "https://your-app.example.com/login"})

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/fill", headers=headers,
    json={"selector": {"strategy": "css", "value": "#email"}, "value": "test@example.com"})

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/fill", headers=headers,
    json={"selector": {"strategy": "css", "value": "#password"}, "value": "password123"})

requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/click", headers=headers,
    json={"selector": {"strategy": "css", "value": "#login-button"}})

result = requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/waitForSelector", headers=headers,
    json={"selector": {"strategy": "css", "value": ".dashboard"}, "state": "visible", "timeout": 5000})

assert result.json()["found"] == True

requests.delete(f"{API_URL}/sessions/{session_id}", headers=headers)
```

### Profile Persistence

```python
session = requests.post(f"{API_URL}/sessions", headers=headers,
    json={"profile_id": "persistent-user", "timeout": 600}).json()
session_id = session["session_id"]

requests.post(f"{API_URL}/sessions/{session_id}/pages/page-0/goto", headers=headers,
    json={"url": "https://example.com/login"})

requests.delete(f"{API_URL}/sessions/{session_id}", headers=headers)

session2 = requests.post(f"{API_URL}/sessions", headers=headers,
    json={"profile_id": "persistent-user", "timeout": 600}).json()

result = requests.post(f"{API_URL}/sessions/{session2['session_id']}/pages/page-0/eval", headers=headers,
    json={"script": "return document.cookie"}).json()
print(f"Cookies preserved: {result['result']}")

requests.delete(f"{API_URL}/sessions/{session2['session_id']}", headers=headers)
```

---

## Error Handling

```python
response = requests.post(f"{API_URL}/sessions/{session_id}/pages/{page_id}/click",
    headers=headers,
    json={"selector": {"strategy": "css", "value": "#nonexistent"}})

if response.status_code != 200:
    error = response.json()
    print(f"Error: {error.get('detail', 'Unknown error')}")
```

Common status codes:
- `200` - Success
- `400` - Bad request (invalid parameters)
- `401` - Unauthorized (invalid API key)
- `404` - Session or page not found
- `422` - Validation error
- `500` - Internal server error
- `504` - Browser operation timeout

---

## Content Extraction (Large/Minified HTML)

When `page/content` returns huge minified HTML (100k+ chars), use JavaScript evaluation to extract structured data directly.

### Extract Headlines/Links

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """
        Array.from(document.querySelectorAll('h1, h2, h3, a[href]'))
            .slice(0, 30)
            .map(el => el.textContent.trim())
            .filter(t => t.length > 10)
    """}
).json()
headlines = result["result"]
```

### Extract with XPath References

Get both content and XPath for each element (useful for later interaction):

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """
        function getXPath(el) {
            if (el.id) return `//*[@id="${el.id}"]`;
            if (el === document.body) return '/html/body';
            let ix = 0;
            const siblings = el.parentNode ? el.parentNode.childNodes : [];
            for (let i = 0; i < siblings.length; i++) {
                const sibling = siblings[i];
                if (sibling === el) return getXPath(el.parentNode) + '/' + el.tagName.toLowerCase() + '[' + (ix + 1) + ']';
                if (sibling.nodeType === 1 && sibling.tagName === el.tagName) ix++;
            }
        }

        Array.from(document.querySelectorAll('h1, h2, h3, article, [class*="title"], [class*="headline"]'))
            .slice(0, 20)
            .map(el => ({
                text: el.textContent.trim().slice(0, 200),
                xpath: getXPath(el),
                tag: el.tagName.toLowerCase(),
                classes: el.className
            }))
            .filter(item => item.text.length > 10)
    """}
).json()

for item in result["result"]:
    print(f"[{item['tag']}] {item['text'][:60]}...")
    print(f"  XPath: {item['xpath']}")
```

### Extract Links with Metadata

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """
        function getXPath(el) {
            if (el.id) return `//*[@id="${el.id}"]`;
            if (el === document.body) return '/html/body';
            let ix = 0;
            const siblings = el.parentNode ? el.parentNode.childNodes : [];
            for (let i = 0; i < siblings.length; i++) {
                const sibling = siblings[i];
                if (sibling === el) return getXPath(el.parentNode) + '/' + el.tagName.toLowerCase() + '[' + (ix + 1) + ']';
                if (sibling.nodeType === 1 && sibling.tagName === el.tagName) ix++;
            }
        }

        Array.from(document.querySelectorAll('a[href]'))
            .filter(a => a.href && !a.href.startsWith('javascript:'))
            .slice(0, 50)
            .map(a => ({
                text: a.textContent.trim().slice(0, 100),
                href: a.href,
                xpath: getXPath(a)
            }))
            .filter(item => item.text.length > 3)
    """}
).json()
```

### Extract Structured Page Summary

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """({
        title: document.title,
        url: window.location.href,
        meta: {
            description: document.querySelector('meta[name="description"]')?.content,
            keywords: document.querySelector('meta[name="keywords"]')?.content,
            ogTitle: document.querySelector('meta[property="og:title"]')?.content,
            ogImage: document.querySelector('meta[property="og:image"]')?.content
        },
        headings: {
            h1: Array.from(document.querySelectorAll('h1')).map(h => h.textContent.trim()),
            h2: Array.from(document.querySelectorAll('h2')).slice(0, 10).map(h => h.textContent.trim())
        },
        links: document.querySelectorAll('a[href]').length,
        images: document.querySelectorAll('img').length,
        forms: document.querySelectorAll('form').length
    })"""}
).json()
```

### Click Element by XPath (After Extraction)

Once you have an XPath from extraction, use it to interact:

```python
xpath = "/html/body/div[2]/main/article[1]/h2/a"

requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/click",
    headers=headers,
    json={"selector": {"strategy": "xpath", "value": xpath}}
)
```

### Why Use This Pattern?

| Approach | Pros | Cons |
|----------|------|------|
| `page/content` | Full HTML | Huge (100k-1M chars), minified, hard to parse |
| `page/eval` + JS | Structured data, fast, XPath refs | Requires knowing what to extract |

**Use `page/eval`** when you know what elements you need (headlines, links, forms).
**Use `page/content`** only when you need raw HTML for external processing.

---

## Tips

1. **Use longer timeouts** for interactive debugging: `{"timeout": 3600}`
2. **Block images** when scraping to speed up page loads
3. **Use `networkidle`** wait for SPAs: `{"wait_until": "networkidle"}`
4. **Profile IDs** are reused - use unique IDs for parallel sessions
5. **VNC viewer** is great for debugging - watch what the browser sees
6. **Input coords are screen coords** - use the coordinate conversion helper to click on elements
7. **VNC cursor visibility** - the built-in VNC viewer shows the cursor; custom clients may need "show dot cursor" enabled
8. **Use Tab for form navigation** - clicking between fields can be blocked by overlays; Tab key is more reliable
9. **Click labels not checkboxes** - label text is a bigger target than tiny checkbox elements
10. **Use easing for human-like movement** - `{"easing": {"x": "ease_out_cubic", "y": "ease_in_out_sine"}}`

---

## Form Interaction Best Practices

### Navigate with Tab Key

Clicking between form fields can fail if overlays or tooltips intercept the click. Use Tab:

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/input/play",
    headers=headers,
    json={"actions": [
        {"type": "move", "x": 500, "y": 400, "duration_ms": 200},
        {"type": "click", "button": 1},
        {"type": "type_text", "text": "user@example.com", "interval": {"min_ms": 30, "max_ms": 80}},
        {"type": "key", "key": "Tab"},
        {"type": "type_text", "text": "password123", "interval": {"min_ms": 30, "max_ms": 80}},
        {"type": "key", "key": "Tab"},
        {"type": "key", "key": "space"},  # Toggle checkbox
        {"type": "key", "key": "Tab"},
        {"type": "key", "key": "Return"}  # Submit
    ]}
)
```

### Click Labels for Checkboxes

Instead of targeting the tiny checkbox element, click its label text:

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """
        (() => {
            const label = Array.from(document.querySelectorAll('label'))
                .find(l => l.textContent.includes('Remember me'));
            if (!label) return null;
            const r = label.getBoundingClientRect();
            return {
                x: Math.round(r.x + r.width/2 + screenX),
                y: Math.round(r.y + r.height/2 + screenY + chromeHeight)
            };
        })()
    """}
).json()
```

### Human-Like Mouse Movement

Use easing functions for natural cursor movement:

```python
requests.post(
    f"{API_URL}/sessions/{session_id}/input/play",
    headers=headers,
    json={"actions": [
        {
            "type": "move",
            "x": 800,
            "y": 500,
            "duration_ms": 350,
            "easing": {
                "x": "ease_out_cubic",
                "y": "ease_in_out_sine"
            }
        },
        {"type": "click", "button": 1}
    ]}
)
```

Available easing functions: `linear`, `ease_in_quad`, `ease_out_quad`, `ease_in_out_quad`, `ease_in_cubic`, `ease_out_cubic`, `ease_in_out_cubic`, `ease_in_sine`, `ease_out_sine`, `ease_in_out_sine`

---

## Iframe Limitations

### Debug Cursor Overlay Doesn't Work in Iframes

The debug cursor overlay only tracks mouse movement on the main page. When the cursor enters an iframe (like reCAPTCHA), mousemove events go to the iframe and the overlay stops updating.

**Workaround:** Use the coordinate formula directly instead of relying on visual feedback inside iframes.

### Iframes Have Separate Coordinate Systems

Elements inside iframes report coordinates relative to the iframe, not the page. To click inside an iframe:

1. Get the iframe's position on the page
2. Get the element's position inside the iframe
3. Add them together

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """
        (() => {
            const iframe = document.querySelector('iframe[title*="reCAPTCHA"]');
            if (!iframe) return null;
            const iframeRect = iframe.getBoundingClientRect();

            // Note: Can't access iframe internals due to cross-origin
            // Return iframe position for manual offset calculation
            return {
                iframeX: iframeRect.x,
                iframeY: iframeRect.y,
                iframeWidth: iframeRect.width,
                iframeHeight: iframeRect.height
            };
        })()
    """}
).json()
```

For cross-origin iframes (like reCAPTCHA), you cannot query elements inside. Use visual estimation or known grid layouts.

---

## CAPTCHA Detection & Solving

### Detect CAPTCHAs on Page

```python
captchas = requests.get(
    f"{API_URL}/sessions/{session_id}/pages/page-0/captchas",
    headers=headers
).json()

if captchas["found"]:
    print(f"Found {captchas['count']} CAPTCHA(s)")
    for c in captchas["captchas"]:
        print(f"  - {c['provider']} at ({c['viewport_coords']['x']}, {c['viewport_coords']['y']})")
```

### Get Grid Cell Coordinates

```python
segmentation = requests.get(
    f"{API_URL}/sessions/{session_id}/pages/page-0/captcha/segment",
    headers=headers
).json()

print(f"Grid: {segmentation['grid_rows']}x{segmentation['grid_cols']}")
for cell in segmentation["cells"]:
    print(f"  Cell {cell['index']}: center at ({cell['center_x']}, {cell['center_y']})")
```

### Solve CAPTCHA (Click Cells)

```python
result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/page-0/captcha/solve",
    headers=headers,
    json={
        "cells": [1, 4, 7],
        "click_delay_min_ms": 200,
        "click_delay_max_ms": 400,
        "then_verify": True
    }
).json()

print(f"Clicked {len(result['clicked'])} cells, verify: {result['verify_clicked']}")
```

### Full CAPTCHA Workflow

```python
session_id = "..."

captchas = requests.get(f"{API_URL}/sessions/{session_id}/pages/page-0/captchas", headers=headers).json()
if not captchas["found"]:
    print("No CAPTCHA detected")
    exit()

captcha = captchas["captchas"][0]
print(f"Detected {captcha['provider']} CAPTCHA")

segmentation = requests.get(
    f"{API_URL}/sessions/{session_id}/pages/page-0/captcha/segment",
    headers=headers
).json()

screenshot = requests.get(
    f"{API_URL}/sessions/{session_id}/screenshot",
    headers=headers,
    params={
        "crop_x": segmentation["frame_coords"]["x"],
        "crop_y": segmentation["frame_coords"]["y"],
        "crop_width": segmentation["frame_coords"]["width"],
        "crop_height": segmentation["frame_coords"]["height"]
    }
).content

# TODO: Send screenshot to vision AI to determine which cells to click
cells_to_click = [1, 4, 7]  # Example: cells identified by AI

result = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/page-0/captcha/solve",
    headers=headers,
    json={"cells": cells_to_click, "then_verify": True}
).json()

print(f"Status: {result['status']}, Verify clicked: {result['verify_clicked']}")
```

### Tips for CAPTCHA Automation

- **Use the API** - The `/captcha/segment` endpoint handles coordinate calculation
- **Crop screenshots** - Send only the CAPTCHA region to vision AI to reduce tokens
- **Human-like delays** - The solve endpoint adds random delays between clicks
- **Cursor overlay** - Use `?cursor=true` on screenshots to debug click positions
