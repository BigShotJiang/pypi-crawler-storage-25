# Browserious Stealth Test Results — Fingerprint Pro

**Date:** 2025-02-17
**Target:** https://demo.fingerprint.com/playground
**Server IP:** DigitalOcean datacenter (North Bergen, NJ)

## Results Summary

| Test | Config | Score | VM | DevTools | VPN | High-Activity | Tampering |
|------|--------|------:|:--:|:--------:|:---:|:-------------:|:---------:|
| 1. Baseline | none | **22** | ✗ Yes | ✗ Yes | ✓ | ✓ | ✓ |
| 2. Timezone | `TZ=America/New_York` | **22** | ✗ Yes | ✗ Yes | ✓ | ✓ | ✓ |
| 3. TZ + WebGL (generic) | `+ GTX 1660 SUPER, OpenGL 4.5` | **18** | ✓ | ✗ Yes | ✗ OS mismatch | ✗ Yes | ✓ |
| 4. TZ + WebGL (Linux-correct) | `+ .../PCIe/SSE2, OpenGL 4.5 (Core Profile)` | **14** | ✓ | ✗ Yes | ✓ | ✗ Yes | ✓ |
| 5. Test 4 + chrome_args | `+ --disable-blink-features=AutomationControlled` | **14** | ✓ | ✗ Yes | ✓ | ✗ Yes | ✓ |
| 6. Test 4 + CDP init script | `+ cdc_* cleanup, chrome.runtime stub` | **14** | ✓ | ✗ Yes | ✓ | ✗ Yes | ✓ |

**Best score: 14** (down from 22 baseline, -36% reduction)

## What Works

### ✅ Timezone (`TZ` env var + Playwright `timezone_id`)
- `Intl.DateTimeFormat().resolvedOptions().timeZone` → `America/New_York` from first load
- `originTimezone` in Fingerprint's server response matches correctly
- **Prevents VPN "OS mismatch" flag** that would otherwise trigger when timezone doesn't match IP geolocation
- Didn't lower score by itself (VPN wasn't flagged in baseline), but is **essential defense** against timezone-based VPN detection

### ✅ WebGL Spoofing (init script via `context.add_init_script()`)
- **Eliminated Virtual Machine detection entirely** — the biggest win
- SwiftShader string replaced before Fingerprint's JS agent runs
- Browser Tampering stays "Not detected" — override is invisible to their anomaly detection
- **Critical detail:** GPU string format must match the OS in the User-Agent:
  - ✗ `ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER, OpenGL 4.5)` → triggers VPN "OS mismatch"
  - ✓ `ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER/PCIe/SSE2, OpenGL 4.5 (Core Profile))` → clean

### ✅ Pre-navigation Init Scripts (new API)
- Scripts execute before any page JS — confirmed working
- WebGL override, language override both apply before Fingerprint's agent snapshots the environment
- This was the key missing feature that made previous post-load patching attempts fail

## What Doesn't Work

### ✗ `--disable-blink-features=AutomationControlled`
- No effect on score or any detection signal
- Fingerprint Pro doesn't rely on the automation flag (navigator.webdriver was already false)

### ✗ CDP artifact cleanup via init script
- Removing `window.chrome.cdc_*`, adding `chrome.runtime` stub, cleaning `Error.stack` traces — zero effect
- **Developer Tools detection is protocol-level** — Fingerprint detects the active CDP WebSocket connection itself, not JS-visible artifacts
- Cannot be fixed with JavaScript

### ✗ High-Activity Device
- Appeared after ~3 tests from same IP, persisted through all subsequent tests
- This is **IP reputation / behavioral** — the datacenter IP is getting flagged for volume
- Can only be fixed with residential proxy or IP rotation

## Remaining Detection Signals (score 14)

| Signal | Detection Method | Can Fix? |
|--------|-----------------|----------|
| **Developer Tools** | CDP WebSocket protocol detection | No — requires patched Chromium or non-CDP control method |
| **High-Activity Device** | IP reputation / request volume | Yes — residential proxy or IP rotation |

## Recommended Session Config for Best Stealth

```python
session = create_session(
    timezone="America/New_York",              # Match IP geolocation
    stealth_webgl_vendor="Google Inc. (NVIDIA Corporation)",
    stealth_webgl_renderer="ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER/PCIe/SSE2, OpenGL 4.5 (Core Profile))",
)
```

## Future Improvements (beyond current API)

1. **Residential proxy support** → eliminates High-Activity Device + further reduces datacenter fingerprint
2. **Patched Chromium** (e.g., ungoogled-chromium without CDP indicators) → eliminates Developer Tools detection
3. **Canvas/Audio fingerprint noise** → adds uniqueness, prevents cross-session correlation
4. **Connection via native browser API** instead of CDP → eliminates protocol-level detection entirely
