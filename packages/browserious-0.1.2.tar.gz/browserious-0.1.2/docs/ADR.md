# Architecture Decision Records

This document captures key architectural decisions made during the design of the Browser API Wrapper project.

## Format

Each ADR follows this structure:
- **Status:** Accepted | Rejected | Superseded | Deprecated
- **Context:** What is the issue we're facing?
- **Decision:** What have we decided?
- **Consequences:** What are the trade-offs?
- **Alternatives Considered:** What else did we consider?

---

## ADR-001: One Browser Per Container vs Multi-Context

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
We need to decide between two isolation models:
1. Run multiple browser contexts within a single container
2. Run one browser instance per container

Multi-context approach is more resource-efficient (one Chromium process serves multiple sessions), but has shared fate (one crash affects all sessions) and makes resource limits harder to enforce.

One-container-per-browser provides stronger isolation and clearer resource boundaries but uses more memory and requires container orchestration.

**Decision:**
Use one browser per container architecture.

**Rationale:**
1. **Resource Isolation:** Docker CPU/memory limits apply cleanly to each session
2. **Fault Isolation:** Crash in one browser doesn't affect others
3. **Security:** Stronger process and filesystem isolation
4. **Cleanup:** Kill container = guaranteed cleanup of all browser state
5. **Debugging:** Easier to inspect/debug single-purpose containers
6. **Extensibility:** Easier to add per-session networking (different subnets, VPNs)

**Consequences:**
- ✅ Better isolation and reliability
- ✅ Simpler resource management
- ✅ Easier to debug
- ❌ Higher memory overhead (~150MB per session vs ~50MB for contexts)
- ❌ Slower session creation (~3-5s vs ~1s)
- ❌ More containers to orchestrate

**Alternatives Considered:**
- **Multi-context:** Rejected due to shared fate and resource management complexity
- **Hybrid:** One container with multiple browsers (not just contexts) - too complex

---

## ADR-002: Manual Orchestration vs Built-in Scaling

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
For horizontal scaling, we could:
1. Build orchestration into the application (Redis registry, session routing)
2. Use Kubernetes/Docker Swarm primitives
3. Leave orchestration to external tools (user responsibility)

Built-in orchestration makes the service "production-ready" out of the box but adds significant complexity (distributed state, leader election, health checking).

**Decision:**
Manual/external orchestration for MVP. Run multiple independent instances, use external load balancer.

**Rationale:**
1. **Simplicity:** Each instance is stateless and independent
2. **Flexibility:** Users choose their orchestration (k8s, docker-compose, systemd)
3. **Faster MVP:** No distributed systems complexity
4. **Common Pattern:** Many services follow this model (Redis, PostgreSQL)

**Consequences:**
- ✅ Simpler implementation and testing
- ✅ No distributed state to manage
- ✅ Users can use existing orchestration knowledge
- ❌ Cannot route requests to existing sessions across instances
- ❌ Users must manage load balancing
- ❌ No built-in HA failover

**Future Enhancement:**
Phase 2 can add Redis-based session registry for transparent multi-instance support.

**Alternatives Considered:**
- **Redis session registry:** Deferred to post-MVP
- **Built-in leader election:** Too complex for MVP
- **Kubernetes-native design:** Too opinionated, limits deployment options

---

## ADR-003: Shared Profile Concurrent Access

**Status:** Accepted (with warnings)

**Date:** 2025-12-09

**Context:**
When multiple sessions request the same `profile_id`, we could:
1. Allow concurrent access (multiple browsers read/write same profile)
2. Lock profile to first session (error on concurrent access)
3. Copy-on-write (second session gets profile fork)

Concurrent access has data corruption risks (SQLite databases, LevelDB) but enables use cases like "logged in user" shared across parallel scrapers.

**Decision:**
Allow shared profile concurrent access with clear documentation of risks.

**Rationale:**
1. **Use Case Support:** Parallel scrapers sharing auth state is common pattern
2. **User Control:** Users can manage profile IDs to avoid conflicts
3. **Simplicity:** No locking or copy-on-write complexity
4. **Performance:** No serialization bottleneck

**Consequences:**
- ✅ Enables parallel scraping with shared auth
- ✅ Simple implementation
- ❌ Risk of profile corruption (SQLite, LevelDB)
- ❌ Undefined behavior on concurrent writes
- 📋 Must document risk prominently

**Documentation Requirements:**
- Warning in API docs about corruption risk
- Recommendation: use unique profile_id per session for production
- Example: `profile_id = f"{user_id}-{session_num}"` for safe parallelism

**Alternatives Considered:**
- **Profile locking:** Rejected - too restrictive for scraping use case
- **Copy-on-write:** Too complex for MVP
- **Read-only profiles:** Doesn't solve the use case

---

## ADR-004: Full CDP Passthrough

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Chrome DevTools Protocol (CDP) provides complete browser control. We could:
1. Abstract CDP behind REST API (wrap every CDP command)
2. Expose CDP directly via WebSocket proxy
3. Hybrid: REST for common operations, CDP for advanced

Wrapping CDP in REST provides cleaner abstraction but limits functionality. Direct CDP access is more flexible but requires users to learn CDP.

**Decision:**
Provide both: REST API for common operations + WebSocket proxy for direct CDP access.

**Rationale:**
1. **Flexibility:** Advanced users can use CDP directly (puppeteer, playwright)
2. **Completeness:** Don't need to wrap every CDP command
3. **Future-proof:** New CDP features available immediately
4. **Ecosystem:** Users can use existing CDP tools and libraries

**Implementation:**
- REST API for 80% use cases (goto, click, type, screenshot)
- WebSocket at `/sessions/{id}/cdp` for CDP passthrough
- CDP connection uses existing Playwright browser

**Consequences:**
- ✅ Maximum flexibility
- ✅ Don't need to wrap every CDP feature
- ✅ Compatible with puppeteer/playwright
- ⚠️ Two ways to do things (REST vs CDP) - document when to use each
- 📋 Need to document CDP security implications

**Alternatives Considered:**
- **REST only:** Too limiting, would need to wrap every CDP command
- **CDP only:** Poor UX for simple operations, need low-level knowledge

---

## ADR-005: All Selector Strategies

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
For element selection (click, type, etc.), we could support:
- CSS selectors (standard, simple)
- XPath (powerful, verbose)
- Playwright locators (text=, role=, modern UX)
- Custom JS functions (ultimate flexibility)

Each has different trade-offs in complexity, power, and maintainability.

**Decision:**
Support all four selector strategies with explicit strategy parameter.

**Rationale:**
1. **CSS:** Most familiar, handles 70% of cases
2. **XPath:** Needed for complex DOM navigation (e.g., ancestor axes)
3. **Playwright locators:** Best practice for modern tests (accessibility-based)
4. **JS functions:** Escape hatch for edge cases

**API Design:**
```json
{
  "selector": {
    "strategy": "css|xpath|text|role|js",
    "value": "selector string or JS code"
  }
}
```

**Examples:**
- CSS: `{"strategy": "css", "value": "#submit-button"}`
- XPath: `{"strategy": "xpath", "value": "//button[text()='Submit']"}`
- Text: `{"strategy": "text", "value": "text=Submit"}`
- Role: `{"strategy": "role", "value": "role=button[name='Submit']"}`
- JS: `{"strategy": "js", "value": "() => document.querySelectorAll('.item')"}`

**Consequences:**
- ✅ Flexibility for all use cases
- ✅ Users can choose familiar syntax
- ⚠️ More API surface to document and test
- 📋 Need clear documentation on when to use each

**Alternatives Considered:**
- **CSS only:** Too limiting for complex DOMs
- **CSS + XPath:** Common but misses modern Playwright locators
- **Playwright only:** Unfamiliar to many users

---

## ADR-006: Request Interception as Core Feature

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Request interception (mock/block/redirect requests) could be:
1. Core MVP feature (routes API)
2. Post-MVP enhancement
3. External proxy (user handles separately)

This feature is complex but critical for testing (mocking APIs) and scraping (blocking ads/trackers).

**Decision:**
Include request interception in MVP as first-class feature.

**Rationale:**
1. **Testing Use Case:** Mocking API responses is essential for E2E tests
2. **Scraping Use Case:** Blocking images/ads saves bandwidth and speeds up scraping
3. **Differentiator:** Not all browser-as-a-service offerings have this
4. **Playwright Support:** Built-in route handling makes implementation straightforward

**Features:**
- Pattern matching (glob patterns like `**/*.{png,jpg}`)
- Actions: block, redirect, override, inspect
- Override response body, headers, status
- Capture requests for later inspection

**Consequences:**
- ✅ Critical feature for both testing and scraping use cases
- ✅ Differentiates from simpler alternatives
- ❌ More API complexity (routes CRUD)
- ⚠️ Performance impact (route checking on every request)

**Alternatives Considered:**
- **External proxy:** Too clunky, requires separate infrastructure
- **Post-MVP:** Too important for primary use cases
- **CDP-only:** Poor UX, requires CDP knowledge

---

## ADR-007: API Key Authentication for MVP

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Authentication options:
1. No auth (trusted network only)
2. API key (simple token)
3. OAuth2/JWT (full auth system)
4. mTLS (certificate-based)

**Decision:**
API key authentication with `X-API-Key` header.

**Rationale:**
1. **Simplicity:** Easy to implement and use
2. **Standard Pattern:** Industry-standard approach (AWS, Stripe, etc.)
3. **Stateless:** No session management needed
4. **Good Enough:** Adequate security for self-hosted service

**Implementation:**
- Environment variable: `API_KEYS=key1,key2,key3`
- Middleware validates `X-API-Key` header
- 401 response if missing/invalid
- No rate limiting in MVP (can add later)

**Consequences:**
- ✅ Simple and standard
- ✅ Stateless
- ❌ Keys can be leaked (need to rotate)
- ❌ No fine-grained permissions
- 📋 Document key rotation practices

**Alternatives Considered:**
- **No auth:** Too risky for any network exposure
- **OAuth2:** Overkill for MVP, requires user management
- **mTLS:** Too complex for HTTP API

---

## ADR-008: VNC Password Per Session

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
VNC security options:
1. No password (trust network)
2. Shared password (all sessions)
3. Unique password per session

**Decision:**
Generate unique VNC password per session, return in session creation response.

**Rationale:**
1. **Security:** Prevents unauthorized access to other sessions
2. **Simplicity:** No external auth system needed
3. **Standard:** VNC password is standard feature

**Implementation:**
- Generate 8-character random password (alphanumeric)
- Pass to x11vnc via `-passwd` flag
- Return password in session creation response
- User provides password when connecting via VNC client

**Consequences:**
- ✅ Better security than shared password
- ✅ Simple implementation
- ⚠️ Password visible in API response (use HTTPS)
- ❌ VNC passwords limited to 8 chars (protocol limitation)

**Alternatives Considered:**
- **No password:** Too insecure
- **Shared password:** Session isolation violated
- **VNC over SSH tunnel:** Too complex for MVP

---

## ADR-009: Extension Upload via API

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Extension management options:
1. Pre-installed only (admin manually places in directory)
2. Upload via API (multipart/form-data)
3. Download from URL (Chrome Web Store)

**Decision:**
Upload via API (POST /extensions with .zip/.crx file).

**Rationale:**
1. **Flexibility:** Users can upload custom extensions
2. **Automation:** Can be scripted/automated
3. **Control:** No external dependencies on Chrome Web Store

**Implementation:**
- Accept .zip or .crx file
- Unpack to `/data/extensions/{extension_id}`
- Parse manifest.json for metadata
- Return extension_id for use in session creation

**Consequences:**
- ✅ Flexible and automatable
- ✅ No Chrome Web Store dependency
- ⚠️ Security risk (malicious extensions) - user responsibility
- 📋 Need to document extension format

**Alternatives Considered:**
- **Pre-installed only:** Too manual, not automatable
- **URL download:** Requires Chrome Web Store API, rate limits

---

## ADR-010: Python + FastAPI Stack

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Language and framework options:
- Python + FastAPI
- Node.js + Express
- Go + Chi/Fiber
- Rust + Actix

**Decision:**
Python with FastAPI framework.

**Rationale:**
1. **Playwright:** Official Python bindings, excellent async support
2. **FastAPI:** Modern, async, automatic OpenAPI docs
3. **Ecosystem:** Rich ecosystem for web scraping (requests, beautifulsoup)
4. **Developer Experience:** Type hints, Pydantic validation
5. **Familiarity:** User's primary language (per CLAUDE.md)

**Consequences:**
- ✅ Great Playwright integration
- ✅ Excellent async support
- ✅ Automatic API documentation
- ❌ Slower than Go/Rust (acceptable for I/O-bound workload)
- ❌ Larger Docker image than Go/Rust

**Alternatives Considered:**
- **Node.js:** Good Playwright support but user prefers Python
- **Go:** Better performance but weaker Playwright bindings
- **Rust:** Best performance but steeper learning curve

---

## ADR-011: Playwright Over Puppeteer

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Browser automation library options:
- Playwright (Microsoft)
- Puppeteer (Google)
- Selenium WebDriver

**Decision:**
Use Playwright for browser control.

**Rationale:**
1. **Features:** Richer API (auto-wait, route interception, multiple browsers)
2. **Python Support:** First-class Python async API
3. **Persistent Context:** Built-in profile management
4. **Extensions:** Better extension support than Puppeteer
5. **Modern:** Newer, more actively developed

**Consequences:**
- ✅ Rich feature set
- ✅ Excellent async Python API
- ✅ Built-in features (auto-wait, interception)
- ⚠️ Users familiar with Puppeteer need to learn differences
- 📋 Can still use Puppeteer via CDP passthrough if needed

**Alternatives Considered:**
- **Puppeteer:** More popular but Python support is community-maintained
- **Selenium:** Legacy, WebDriver protocol has more overhead

---

## ADR-012: Docker + Supervisor Process Management

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Need to run multiple processes in container:
- Xvfb (virtual display)
- x11vnc (VNC server)
- noVNC (web VNC)
- FastAPI app

Process manager options:
- Supervisor
- systemd
- Custom shell script
- Multiple containers (one process per container)

**Decision:**
Single container with Supervisor process manager.

**Rationale:**
1. **Simplicity:** One container = one session, easier to manage
2. **Supervisor:** Mature, well-documented, standard for multi-process containers
3. **Startup Order:** Supervisor handles dependency order (Xvfb before x11vnc)
4. **Logging:** Centralized log management
5. **Restart:** Auto-restart crashed processes

**Consequences:**
- ✅ Simple deployment (one container)
- ✅ Process dependency management
- ✅ Auto-restart on crashes
- ⚠️ Anti-pattern (containers should run one process) but pragmatic
- 📋 Document supervisor configuration

**Alternatives Considered:**
- **systemd:** Too heavy for containers, designed for full OS
- **Shell script:** No automatic restart, poor error handling
- **Multiple containers:** Too complex, requires container networking

---

## ADR-013: Filesystem-Based Profile Storage

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Profile storage options:
- Filesystem (local directory)
- S3/object storage
- Database (PostgreSQL)
- Distributed filesystem (Ceph, GlusterFS)

**Decision:**
Filesystem-based storage at `/data/profiles/{profile_id}`.

**Rationale:**
1. **Chromium Native:** Chromium expects filesystem profile directory
2. **Performance:** Local filesystem is fastest
3. **Simplicity:** No additional infrastructure
4. **Volumes:** Docker volumes for persistence

**Consequences:**
- ✅ Simple and fast
- ✅ Native Chromium support
- ❌ Not suitable for distributed/multi-host deployments
- ❌ No built-in backup/replication
- 📋 Users must handle backup via volume snapshots

**Future Enhancement:**
For distributed deployments, add S3 backend with local caching.

**Alternatives Considered:**
- **S3:** Too slow for browser profile access, adds latency
- **Database:** Inefficient for binary blob storage
- **Network filesystem:** Adds complexity and latency

---

## ADR-014: Hard Timeout with Immediate Termination

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
Session timeout behavior options:
1. Hard close immediately at expiry
2. Grace period with warning
3. Auto-extend on activity

**Decision:**
Hard close immediately when session reaches timeout.

**Rationale:**
1. **Simplicity:** No grace period logic or warning system
2. **Resource Management:** Predictable resource cleanup
3. **User Control:** User sets timeout at creation, knows when it ends
4. **Implementation:** Simple background task checking expiry

**Implementation:**
- Background task runs every 60s
- Checks all sessions for expiry
- Calls `browser_manager.close_session()` for expired

**Consequences:**
- ✅ Simple implementation
- ✅ Predictable behavior
- ❌ Abrupt termination (no warning)
- 📋 Document that users should set adequate timeout

**Alternatives Considered:**
- **Grace period:** Added complexity, unclear UX (how long?)
- **Auto-extend:** Requires activity detection, zombies live forever

---

## ADR-015: OpenAPI/Swagger Documentation

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
API documentation options:
- OpenAPI/Swagger (standard)
- Custom markdown
- README only
- Postman collection

**Decision:**
Use FastAPI's automatic OpenAPI generation + custom markdown docs.

**Rationale:**
1. **Automatic:** FastAPI generates OpenAPI from Pydantic models
2. **Interactive:** Swagger UI for testing
3. **Standard:** OpenAPI is industry standard
4. **Dual Format:** Machine-readable (JSON) + human-readable (UI)

**Implementation:**
- FastAPI automatically generates `/docs` (Swagger UI)
- Also generate `/redoc` (ReDoc UI)
- Supplement with `docs/API.md` for narrative documentation

**Consequences:**
- ✅ Free documentation from type hints
- ✅ Interactive testing UI
- ✅ Always up-to-date with code
- 📋 Still need narrative docs for concepts

**Alternatives Considered:**
- **Markdown only:** Not interactive, harder to keep in sync
- **Postman:** Proprietary format, not standard

---

## Summary of Key Trade-offs

| Decision | Benefit | Cost | Rationale |
|----------|---------|------|-----------|
| One container per browser | Isolation, reliability | Memory overhead | Worth it for production use |
| Manual orchestration | Simplicity | No built-in HA | Good for MVP, can add later |
| Shared profiles | Parallel scraping | Corruption risk | User choice, document risk |
| All selector strategies | Flexibility | More API surface | Needed for diverse use cases |
| Request interception in MVP | Core differentiator | Complexity | Too important to defer |
| Python + FastAPI | Great DX, Playwright | Slower than Go | Good enough for I/O bound |
| Filesystem profiles | Simple, fast | Not distributed | Fine for single-host MVP |

---

## ADR-016: Separated API Orchestrator and Browser Nodes

**Status:** Accepted (supersedes ADR-012 partially)

**Date:** 2025-12-09

**Context:**
The initial implementation (ADR-012) bundled everything into a single container:
- FastAPI application
- Xvfb virtual display
- x11vnc VNC server
- noVNC web client
- Chromium browser (via Playwright)
- Supervisor process manager

This architecture has scaling problems:
1. Cannot run multiple browser sessions with isolated containers
2. API server is coupled to browser lifecycle
3. Port conflicts when trying to scale (VNC 5900, CDP 9222 clash)
4. No true container isolation between sessions

**Decision:**
Separate the architecture into two components:

1. **API Orchestrator** (runs on host under supervisor)
   - FastAPI application
   - Manages Docker containers via Docker API
   - Proxies VNC WebSocket connections
   - Connects to browser nodes via CDP for Playwright operations

2. **Browser Node** (minimal Docker container per session)
   - Xvfb (virtual display)
   - Chromium (browser)
   - x11vnc (VNC server, no password - network isolated)
   - No internal API, no noVNC, no supervisor

**Architecture:**
```
┌─────────────────────────────────────────────────────┐
│  Host Machine                                        │
│                                                      │
│  Supervisor:                                         │
│  └─ FastAPI :8000                                   │
│       │                                              │
│       ├─ REST API (sessions, pages, routes, etc.)   │
│       ├─ VNC WebSocket proxy /sessions/{id}/vnc     │
│       └─ Docker API (create/kill containers)        │
│                                                      │
│  ┌─────────────────────────────────────────────┐    │
│  │ Docker Network: browserious                  │    │
│  │                                              │    │
│  │  ┌──────────────┐  ┌──────────────┐         │    │
│  │  │ session-abc  │  │ session-xyz  │         │    │
│  │  │              │  │              │         │    │
│  │  │ Xvfb :99     │  │ Xvfb :99     │         │    │
│  │  │ x11vnc :5900 │  │ x11vnc :5900 │         │    │
│  │  │ Chromium     │  │ Chromium     │         │    │
│  │  │ CDP :9222    │  │ CDP :9222    │         │    │
│  │  └──────────────┘  └──────────────┘         │    │
│  │                                              │    │
│  │  (same ports OK - addressed by hostname)    │    │
│  └─────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────┘
```

**Network Strategy:**
- Create dedicated Docker network `browserious`
- Each container hostname = session ID (e.g., `session-abc123`)
- API connects via hostname: `session-abc123:9222` for CDP, `session-abc123:5900` for VNC
- No port conflicts - all nodes use same internal ports
- Nodes not exposed to host network (security)

**VNC Access Strategy (Option C from analysis):**
- FastAPI proxies VNC WebSocket at `/sessions/{id}/vnc`
- Single entry point with API key authentication
- No need to expose node ports to host
- Acceptable latency for debugging use case

**Playwright Connection:**
- Playwright connects to remote browser via CDP WebSocket
- `playwright.chromium.connect_over_cdp(f"ws://session-{id}:9222")`
- All browser operations happen over CDP, no local browser process

**Rationale:**
1. **True Isolation:** Each session in separate container with own resources
2. **Scalability:** Can run many sessions limited only by host resources
3. **No Port Conflicts:** Docker network + hostnames solve port mapping
4. **Security:** Nodes isolated in private network, only API exposed
5. **Minimal Nodes:** Less attack surface, faster startup, smaller images
6. **Host API:** Can run under existing supervisor, no Docker-in-Docker needed

**Consequences:**
- ✅ True container isolation per session
- ✅ No port conflict issues
- ✅ API can scale independently of nodes
- ✅ Smaller, faster node containers
- ✅ Better security (nodes not exposed)
- ❌ Requires Docker socket access from API
- ❌ More complex than single-container approach
- ❌ API must handle container lifecycle
- 📋 Need to document Docker network setup

**Migration from ADR-012:**
- Keep supervisor concept for host-level API process
- Remove supervisor from node containers
- Split Dockerfile into node-only image
- Add Docker SDK to API for container management

**Implementation Requirements:**
1. New minimal Dockerfile for browser nodes
2. Docker SDK integration in FastAPI
3. VNC WebSocket proxy endpoint
4. CDP-based remote Playwright connection
5. Container lifecycle management (create, health check, cleanup)
6. Docker network creation on startup

**Alternatives Considered:**
- **Keep single container:** Doesn't scale, port conflicts
- **Docker-in-Docker:** Security concerns, complexity
- **Kubernetes-only:** Too opinionated, limits deployment options
- **Expose all node ports:** Port management nightmare

---

## ADR-017: VNC Access via API WebSocket Proxy

**Status:** Accepted

**Date:** 2025-12-09

**Context:**
With browser nodes in isolated Docker network, need to provide VNC access for debugging. Options analyzed:

| Option | Description | Pros | Cons |
|--------|-------------|------|------|
| A | API proxies WebSocket | Single endpoint | Bottleneck, more code |
| B | Expose ports on demand | Best performance | Port chaos, firewall issues |
| C | Single noVNC gateway | Clean architecture | Extra hop |

**Decision:**
Option C variant - FastAPI directly proxies VNC WebSocket (no separate noVNC process).

**Implementation:**
- Endpoint: `WS /sessions/{session_id}/vnc`
- API authenticates request (API key)
- Looks up container hostname for session
- Opens WebSocket to `session-{id}:5900`
- Bidirectionally proxies VNC protocol

**Client Usage:**
```javascript
// User connects noVNC client to:
ws://api-host:8000/sessions/abc123/vnc?api_key=xxx
```

Or embed in web UI with noVNC JavaScript client.

**Rationale:**
1. **Single entry point:** All access through API
2. **Authentication:** Reuse existing API key auth
3. **No extra processes:** FastAPI handles proxy
4. **Network isolation:** Nodes stay private
5. **Simple client:** Standard VNC WebSocket

**Consequences:**
- ✅ Secure (authenticated)
- ✅ Simple architecture
- ✅ No port management
- ⚠️ API handles VNC traffic (acceptable load)
- 📋 Need noVNC client instructions in docs

---

## ADR-018: IP-Based CDP Connection Instead of Hostname

**Status:** Accepted

**Date:** 2025-12-16

**Context:**
When connecting to browser nodes via CDP, we initially used container hostnames (e.g., `session-abc123:9222`). However, Chrome/Chromium validates the `Host` header in CDP connections and rejects connections where the host is not `localhost` or an IP address.

Error observed:
```
socket hang up
```

This occurred because Chrome's CDP implementation checks the Host header and rejects non-IP/non-localhost values for security reasons.

**Decision:**
Connect to browser nodes using their Docker network IP address instead of hostname.

**Implementation:**
```python
container.reload()
container_ip = container.attrs['NetworkSettings']['Networks'][settings.docker_network]['IPAddress']
cdp_url = f"http://{container_ip}:9222"
browser = await self.playwright.chromium.connect_over_cdp(cdp_url)
```

**Consequences:**
- ✅ CDP connections work reliably
- ✅ No Chrome validation errors
- ⚠️ IP addresses can change on container restart (mitigated by connecting immediately after creation)
- 📋 Session response includes `cdp_url` with IP for debugging

---

## ADR-019: CDP Connection Retry Logic

**Status:** Accepted

**Date:** 2025-12-16

**Context:**
Even after the container reports as running and CDP port check succeeds, the browser may not be fully ready to accept CDP connections. Initial connection attempts can fail with "socket hang up" errors.

**Decision:**
Implement retry logic with 5 attempts and 1-second delays between attempts.

**Implementation:**
```python
browser = None
cdp_url = f"http://{container_ip}:9222"
for attempt in range(5):
    try:
        browser = await self.playwright.chromium.connect_over_cdp(cdp_url)
        break
    except Exception as e:
        logger.warning(f"CDP connection attempt {attempt + 1}/5 failed: {e}")
        if attempt < 4:
            await asyncio.sleep(1)
        else:
            raise
```

**Rationale:**
1. **Browser startup variance:** Chromium takes variable time to initialize
2. **Simple solution:** Retry is simpler than complex readiness checks
3. **Reasonable timeout:** 5 attempts × 1 second = ~5 seconds max additional delay
4. **Clear logging:** Each failed attempt is logged for debugging

**Consequences:**
- ✅ Reliable session creation even under load
- ✅ Clear error messages on persistent failures
- ⚠️ Session creation takes slightly longer (retries add latency)
- 📋 Logs show retry attempts for debugging

---

## ADR-020: Go Node API for Input Simulation

**Status:** Accepted

**Date:** 2025-12-16

**Context:**
We needed to implement hardware-level input simulation (mouse/keyboard via X11) inside browser containers. Options considered:
1. Docker exec to run xdotool commands (high latency, requires Docker socket)
2. Python process inside container (complex dependencies, GIL issues for timing)
3. Go binary inside container (minimal footprint, precise timing)

**Decision:**
Implement a lightweight Go HTTP server running inside each browser node container that:
- Runs xdotool via persistent stdin pipe for minimal latency
- Provides `/play` endpoint accepting action playlists
- Supports 30 easing functions for human-like mouse movement
- Executes actions with nanosecond-precision timing

**Rationale:**
1. **Performance:** Go provides excellent concurrency and precise timing control
2. **Minimal Footprint:** Single binary adds ~8MB to container image
3. **Low Latency:** Persistent xdotool pipe eliminates process spawn overhead
4. **Clean Architecture:** Separates orchestration (Python FastAPI) from node control (Go)
5. **Future Extensibility:** Can add more node-level features (local screenshots, resource monitoring)

**Implementation:**
- Go binary built during Docker image creation
- Listens on port 8080 inside each browser node container
- FastAPI proxies requests to node's IP:8080
- Supports complex playlists with easing, timing, and variable delays

**Consequences:**
- ✅ Sub-millisecond latency for input commands
- ✅ 30 easing functions enable human-like mouse movement
- ✅ Clean separation between API and node concerns
- ❌ Adds Go build stage to Dockerfile (increases build time ~15s)
- ❌ Binary adds ~8MB to container image
- 📋 Node API provides foundation for future node-level features

**Alternatives Considered:**
- **Docker exec + xdotool:** High latency (~50-100ms per command), requires Docker socket access
- **Python in container:** Complex dependencies, GIL issues, slower than Go
- **Direct X11 library calls:** More complex, less maintainable than xdotool wrapper

---

## Future ADRs (Not Yet Decided)

### ADR-TBD: Multi-Instance Session Registry
When we add Redis-based session registry for true horizontal scaling.

### ADR-TBD: Monitoring and Metrics
When we add Prometheus metrics and health checks.

### ADR-TBD: Profile Storage Backend
When we add S3/object storage for distributed profiles.

### ADR-TBD: Browser Version Management
When we add support for multiple Chromium versions or Firefox.

### ADR-TBD: Container Orchestration Integration
When we add Kubernetes-native features (CRDs, operators).
