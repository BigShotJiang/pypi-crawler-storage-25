# Development Notes

This document captures obstacles encountered during development and their solutions.

## Test Suite Issues (December 2024)

### Issue 1: Read-only Filesystem Error at Import Time

**Problem:** `ExtensionManager` created directories in `__init__`, causing `OSError: [Errno 30] Read-only file system: '/data'` when tests ran on macOS.

**Root Cause:** The module-level singleton `extension_manager = ExtensionManager(settings.extensions_dir)` tried to create `/data/extensions` at import time, before tests could set up temp directories.

**Solution:** Made directory creation lazy by adding `_ensure_dir()` method called in `upload_extension()` instead of `__init__()`.

```python
# Before (failed at import)
def __init__(self, extensions_dir: str):
    self.extensions_dir = Path(extensions_dir)
    self.extensions_dir.mkdir(parents=True, exist_ok=True)

# After (lazy creation)
def __init__(self, extensions_dir: str):
    self.extensions_dir = Path(extensions_dir)

def _ensure_dir(self):
    self.extensions_dir.mkdir(parents=True, exist_ok=True)

async def upload_extension(self, ...):
    self._ensure_dir()
    ...
```

### Issue 2: Environment Variable Conflicts Between Tests

**Problem:** `test_auth.py` set its own `API_KEYS` env var that conflicted with `conftest.py`, causing 401 errors for valid keys.

**Root Cause:** `conftest.py` sets `API_KEYS=test-api-key` before any imports. `test_auth.py` then tried to set `API_KEYS=test-key-1,test-key-2,test-key-3` but settings were already loaded.

**Solution:** Updated `test_auth.py` to use the same key set by `conftest.py` (`test-api-key`), and removed the redundant environment variable setting.

### Issue 3: Deprecated asyncio.get_event_loop()

**Problem:** Some tests used `asyncio.get_event_loop().run_until_complete()` which raised `RuntimeError: There is no current event loop in thread 'MainThread'` in Python 3.11+.

**Root Cause:** Python 3.10+ deprecated implicit event loop creation. `asyncio.get_event_loop()` no longer creates a loop automatically.

**Solution:** Converted synchronous tests to async using `@pytest.mark.anyio`:

```python
# Before (deprecated)
def test_delete_extension(extension_manager, valid_extension_zip):
    import asyncio
    result = asyncio.get_event_loop().run_until_complete(
        extension_manager.upload_extension(valid_extension_zip, "test.zip")
    )

# After (modern async)
@pytest.mark.anyio
async def test_delete_extension(extension_manager, valid_extension_zip):
    result = await extension_manager.upload_extension(valid_extension_zip, "test.zip")
```

### Issue 4: FastAPI Exception Handler Not Catching RuntimeError

**Problem:** Test `test_global_exception_handler` raised `RuntimeError` expecting it to be caught by `@app.exception_handler(Exception)`, but the exception bubbled up uncaught.

**Root Cause:** FastAPI/Starlette's generic `Exception` handler behavior is inconsistent in test environments with `ASGITransport`. Route-level exceptions may bypass the handler in certain configurations.

**Solution:** Changed test to verify exception handler is registered rather than testing runtime behavior:

```python
# Before (flaky)
@pytest.mark.anyio
async def test_global_exception_handler():
    response = await ac.get("/test-error")
    assert response.status_code == 500

# After (reliable)
@pytest.mark.anyio
async def test_global_exception_handler_defined():
    from src.main import app
    exception_handlers = app.exception_handlers
    assert Exception in exception_handlers
```

### Issue 5: Config Test Expected Defaults Overridden by conftest.py

**Problem:** `test_config_with_valid_env` expected `settings.profiles_dir == "/data/profiles"` but got temp path set by `conftest.py`.

**Root Cause:** `conftest.py` sets `PROFILES_DIR` and `EXTENSIONS_DIR` to temp directories before tests run, overriding defaults.

**Solution:** Explicitly set the expected values in the test's monkeypatch:

```python
def test_config_with_valid_env(monkeypatch):
    monkeypatch.setenv("API_KEYS", "key1,key2,key3")
    monkeypatch.setenv("MAX_SESSIONS", "20")
    monkeypatch.setenv("PROFILES_DIR", "/data/profiles")  # Added
    monkeypatch.setenv("EXTENSIONS_DIR", "/data/extensions")  # Added
```

## Dependencies

### pytest-anyio vs pytest-asyncio

We use `pytest-anyio` instead of `pytest-asyncio` because:
- Simpler configuration (no `asyncio_mode` setting needed)
- Works with both asyncio and trio backends
- Consistent with FastAPI's testing recommendations

### requirements-dev.txt

Development dependencies are separated from production:
```
-r requirements.txt
pytest>=8.0.0
pytest-anyio>=0.0.0
httpx>=0.27.0
```

## Test Configuration

The test setup in `conftest.py`:

```python
import os
import tempfile

_temp_dir = tempfile.mkdtemp()
os.environ.setdefault("API_KEYS", "test-api-key")
os.environ.setdefault("PROFILES_DIR", os.path.join(_temp_dir, "profiles"))
os.environ.setdefault("EXTENSIONS_DIR", os.path.join(_temp_dir, "extensions"))
```

This ensures:
1. Environment variables are set before any `src.*` imports
2. Temporary directories prevent filesystem permission issues
3. Consistent API key across all tests

## Known Warnings

The test suite produces these warnings (safe to ignore):

1. **PydanticDeprecatedSince20** - `class Config` vs `ConfigDict`. Low priority migration.
2. **PytestConfigWarning: Unknown config option: asyncio_mode** - Leftover from pytest-asyncio, ignored by pytest-anyio.
3. **DeprecationWarning: 'HTTP_422_UNPROCESSABLE_ENTITY'** - Starlette deprecation, will be fixed in future FastAPI version.

---

## Docker Architecture Issues (December 2025)

### Issue 6: CDP "socket hang up" Error

**Problem:** Session creation failed with `socket hang up` error when connecting to browser node via CDP.

**Root Cause:** Chrome/Chromium validates the `Host` header in CDP connections. When connecting via hostname (e.g., `session-abc123:9222`), Chrome rejects the connection because it only accepts `localhost` or IP addresses.

**Solution:** Use container IP address instead of hostname for CDP connections:

```python
container.reload()
container_ip = container.attrs['NetworkSettings']['Networks'][settings.docker_network]['IPAddress']
cdp_url = f"http://{container_ip}:9222"
```

See ADR-018 for full rationale.

### Issue 7: Intermittent CDP Connection Failures

**Problem:** Even with IP-based connection, CDP sometimes failed on first attempt with "socket hang up" because browser wasn't fully ready.

**Root Cause:** The port check (`socket.connect_ex()`) can succeed before Chrome is actually ready to accept CDP connections. There's a race condition between the port being open and Chrome fully initializing.

**Solution:** Added retry logic with 5 attempts and 1-second delays:

```python
for attempt in range(5):
    try:
        browser = await self.playwright.chromium.connect_over_cdp(cdp_url)
        break
    except Exception as e:
        logger.warning(f"CDP connection attempt {attempt + 1}/5 failed: {e}")
        if attempt < 4:
            await asyncio.sleep(1)
        else:
            raise
```

See ADR-019 for full rationale.

### Issue 8: VNC Empty Screen Despite WebSocket Connection

**Problem:** VNC web viewer connected successfully (WebSocket streaming messages) but showed empty black screen.

**Root Cause:** The noVNC client initialization was incomplete. The inline script needed proper module import and event handlers.

**Solution:** Updated `/vnc.html` endpoint in `src/main.py` with complete noVNC initialization:

```javascript
import RFB from 'https://cdn.jsdelivr.net/npm/@novnc/novnc@1.4.0/core/rfb.js';

rfb.addEventListener('connect', ...);
rfb.addEventListener('disconnect', ...);
rfb.addEventListener('credentialsrequired', ...);

const rfb = new RFB(document.getElementById('screen'), wsUrl);
rfb.scaleViewport = true;
rfb.resizeSession = true;
rfb.clipViewport = false;
```

Key settings:
- `scaleViewport = true` - Scales to fit container
- `resizeSession = true` - Allows session resize
- `clipViewport = false` - Don't clip the viewport (was causing blank screen)

### Issue 9: Session Timeout Confusion

**Problem:** Sessions were expiring after ~5 minutes when users expected them to last longer.

**Root Cause:** Default timeout was 300 seconds (5 minutes). Users didn't realize they needed to specify longer timeout.

**Solution:** Updated example notebook to use `timeout=3600` (1 hour) and documented the timeout parameter more prominently.
