# Patterns from Scraper Project

Legacy scraper project (`~/projects/scraper`) contains valuable patterns developed 2019-2021 that can enhance browserious. This document extracts the best ideas.

## 1. Declarative XPath Extraction System

### Original Implementation

Scraper uses JSON configs to define extraction schemas:

```json
{
  "numberOfItems": "//div[@data-widget='catalogResultsHeader']/div",
  "items": {
    "_root": "//div[@data-widget='searchResultsV2']/div/div",
    "href": "./descendant::img[1]/ancestor::a[1]/@href",
    "img": ".//img[starts-with(@src, 'https://cdn1')]/@src",
    "name": ".//a[starts-with(@href, '/product/')]/text()",
    "price": ".//span[contains(text(),'₽')][1]",
    "labels": {
      "delivery": ".//span[contains(text(), 'Доставит')]/text()",
      "bestseller": ".//div[contains(text(),'Бестселлер')]/text()"
    }
  }
}
```

The `_root` key creates repeating elements - each match becomes a parent for nested selectors.

### Parser (Python - lxml)

```python
class LXMLRecursiveXpathParser:
    @classmethod
    def recursive_xpath(cls, struct, root_element):
        res = {}
        _root = struct.pop('_root', None)

        if _root:
            return [cls.recursive_xpath(struct.copy(), el)
                    for el in root_element.xpath(_root)]

        for field, v in struct.items():
            if isinstance(v, str):
                xpath_res = root_element.xpath(v)
                # Auto-convert elements to text, clean whitespace
                res[field] = clean_results(xpath_res)
            elif isinstance(v, dict):
                res[field] = cls.recursive_xpath(v, root_element)
        return res
```

### Parser (JavaScript - in-browser)

```javascript
function parseXpath(struct) {
  function recursiveXpath(struct, rootElement) {
    let res = {};
    let _root = struct['_root'];

    if (_root) {
      delete struct['_root'];
      let elements = document.evaluate(_root, rootElement, null,
        XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      return Array.from({length: elements.snapshotLength},
        (_, i) => recursiveXpath({...struct}, elements.snapshotItem(i)));
    }

    for (const [field, v] of Object.entries(struct)) {
      if (typeof v === 'string') {
        res[field] = evaluateXpath(v, rootElement);
      } else {
        res[field] = recursiveXpath(v, rootElement);
      }
    }
    return res;
  }
  return recursiveXpath(struct, document.documentElement);
}
```

### Browserious Integration Ideas

Add endpoint to `page_operations.py`:

```
POST /sessions/{session_id}/pages/{page_id}/extract
{
  "schema": { ... },        // XPath/CSS extraction schema
  "format": "xpath|css",    // Selector format
  "wait_for": "selector"    // Optional wait before extraction
}
```

Benefits:
- No client-side code needed for common extractions
- Schema can be stored/versioned
- Same schema works across sessions

---

## 2. Request Interception Presets

### Original Implementation

```javascript
const defaultOptions = {
  blacklist: [
    /\.(jpe?g|png|svg)$/,
    /\.(woff2)$/,
    /(googleadservices|googletagmanager|google-analytics)/,
    /(doubleclick|creativecdn)/,
    /(criteo|facebook|mail\.ru)/,
  ]
}

page.on('request', (request) => {
  let url = request.url();
  if (matchesBlacklist(url)) {
    if (isImage(url)) {
      request.respond(getMockImage(getSize(url)));
    } else {
      request.abort();
    }
  } else {
    request.continue();
  }
});
```

Mock images are pre-loaded at various sizes (75, 125, 200, 450, 550, 650, 1000, 1250, 1450) to return appropriate placeholders.

### Browserious Integration Ideas

Pre-defined route presets in `route_manager.py`:

```python
PRESETS = {
    "block_analytics": {
        "patterns": [
            r"google-analytics\.com",
            r"googletagmanager\.com",
            r"facebook\.net",
            r"doubleclick\.net"
        ],
        "action": "abort"
    },
    "block_images": {
        "patterns": [r"\.(jpe?g|png|gif|svg|webp)(\?|$)"],
        "action": "respond",
        "response": {"body": MOCK_1PX_GIF, "contentType": "image/gif"}
    },
    "block_fonts": {
        "patterns": [r"\.(woff2?|ttf|eot)(\?|$)"],
        "action": "abort"
    }
}
```

API:

```
POST /sessions/{session_id}/routes/presets
{
  "presets": ["block_analytics", "block_images"],
  "custom_patterns": [...]
}
```

---

## 3. Smart Scroll with Lazy-Load Detection

### Original Implementation

```javascript
export const scrollToBottom = async ({
  page,
  maxScrolls = 100,
  delayBetweenScrolls = 200,
  confirmationDelay = 1000,
  maxScrollHeight = 10000
}) => {
  let scroll;
  for (let i = 0; i < maxScrolls; i++) {
    scroll = await scrollState(page);

    if (scroll.touchedBottom) {
      // Double-check after delay (content might load)
      await page.waitForTimeout(confirmationDelay);
      scroll = await scrollState(page);
      if (scroll.touchedBottom) break;
    }

    let scrollBy = Math.min(scroll.bottom, scroll.clientHeight, maxScrollHeight);
    await page.evaluate((y) => window.scrollBy(0, y), scrollBy);
    await page.waitForTimeout(delayBetweenScrolls);
  }
  return scroll;
}

export const scrollState = async (page) => {
  return await page.evaluate(() => ({
    top: document.documentElement.scrollTop,
    height: document.documentElement.scrollHeight,
    clientHeight: document.documentElement.clientHeight,
    bottom: document.documentElement.scrollHeight -
      (document.documentElement.scrollTop + document.documentElement.clientHeight),
    touchedBottom: document.documentElement.scrollTop +
      document.documentElement.clientHeight >= document.documentElement.scrollHeight,
  }));
}
```

### Browserious Integration Ideas

Add to `page_operations.py`:

```
POST /sessions/{session_id}/pages/{page_id}/scroll
{
  "direction": "bottom|top|element",
  "target": "selector",              // For element scroll
  "max_scrolls": 100,
  "scroll_delay_ms": 200,
  "confirmation_delay_ms": 1000,
  "wait_for_network_idle": true
}
```

Returns:
```json
{
  "scrolls_performed": 47,
  "final_height": 12500,
  "timed_out": false
}
```

---

## 4. Human-like Mouse Movement (Anti-detection)

### Original Implementation

```python
class VNC:
    def mouse_move(self, pos):
        absolute_start = self.last_mouse_pos
        absolute_end = pos
        dist = np.linalg.norm(absolute_end - absolute_start)

        mouse_speed = random.randint(600, 800)  # px/sec
        time_for_movement = dist / mouse_speed
        num_steps = int(time_for_movement * 1000 / 13.38)  # ~75fps

        tweening = pytweening.easeInOutQuad
        noise_radius = np.random.randint(-30, 30, (2,))

        for i in range(num_steps):
            progress = tweening(i / num_steps)
            new_pos = get_point_on_line(start, end, progress)

            # Add sine-wave noise for natural wobble
            phase = np.pi * 2 * i / num_steps
            noise = noise_radius * np.sin(phase)
            new_pos += noise

            self.client.mouseMove(*new_pos)
            time.sleep(random.gauss(0.01338, 0.00281))
```

Key features:
- Easing curves (not linear)
- Random noise on path
- Variable delays between steps
- Speed variance

### Browserious Integration Ideas

Add stealth mode to mouse operations:

```
POST /sessions/{session_id}/pages/{page_id}/click
{
  "selector": "#submit",
  "stealth": {
    "enabled": true,
    "move_curve": "ease_in_out_quad",
    "speed_range": [400, 800],
    "path_noise": 30,
    "hover_before_click_ms": [100, 300]
  }
}
```

This would use Playwright's mouse.move with calculated intermediate points.

---

## 5. Streaming Results Pattern

### Original Implementation

```javascript
export function asyncIterableCrawler(options) {
  return {
    state: {status: 'init'},

    async * generator() {
      yield { type: 'browser', value: await this.openBrowser() };
      this.state = {status: 'open-page'};

      yield { type: 'page', value: await this.openPage(url) };
      this.state = {status: 'get-content'};

      yield { type: 'raw-content', value: await page.content() };
      this.state = {status: 'parse'};

      yield { type: 'parsed-content', value: await this.parseContent() };
      this.state = {status: 'done'};
    },

    [Symbol.asyncIterator]() {
      return this.generator();
    }
  }
}

// Express endpoint with streaming
app.get('/parse', async (req, res) => {
  res.set('Content-Type', 'text/plain');

  for await (let content of asyncIterableCrawler(options)) {
    res.write(JSON.stringify(content) + '\n\n');
  }
  res.end();
});
```

### Browserious Integration Ideas

Server-Sent Events for long operations:

```
GET /sessions/{session_id}/pages/{page_id}/crawl?sse=true
```

Response (SSE stream):
```
event: status
data: {"state": "navigating", "url": "..."}

event: status
data: {"state": "scrolling", "progress": 0.45}

event: content
data: {"type": "raw_html", "size": 125000}

event: content
data: {"type": "extracted", "items": 47}

event: done
data: {"took_ms": 4532}
```

---

## 6. Container Pool with LRU Selection

### Original Implementation

```python
def get_container(container_name=None):
    if not container_name:
        # Get least recently used container
        container_name = kv.zrange('containers', 0, 0)[0]

    container = client.containers.get(container_name)

    # Update last-used timestamp
    kv.zadd('containers', time.time(), container_name)

    return container

def launch_container(screen_dimensions, proxy, timezone):
    container_name = f"chrome-{w}x{h}-{port}-{proxy or 'noproxy'}"

    container = client.containers.run(
        image='selenium/standalone-chrome-debug',
        environment={
            'SCREEN_WIDTH': w,
            'SCREEN_HEIGHT': h,
            'TZ': timezone,
            'http_proxy': proxy,
        },
        ports={5900: vnc_port, 4444: selenium_port},
        volumes={'/dev/shm': {'bind': '/dev/shm', 'mode': 'rw'}},
        detach=True,
    )

    # Track in Redis sorted set (score = creation time)
    kv.zadd('containers', time.time(), container_name)
    kv.set(container_name, json.dumps(container_config))

    return container
```

### Browserious Integration Ideas

Already using similar patterns, but could add:
- LRU session eviction when at capacity
- Container warm-up pool (pre-created but unassigned)
- Session affinity for profile persistence

---

## Summary of Portable Features

| Feature | Effort | Value | Priority |
|---------|--------|-------|----------|
| Declarative extraction schemas | Medium | High | P1 |
| Request interception presets | Low | High | P1 |
| Smart scroll to bottom | Low | Medium | P2 |
| Human-like mouse (stealth) | High | Medium | P3 |
| Streaming/SSE for long ops | Medium | Medium | P2 |
| Container pool management | Low | Already have | - |

## Files to Reference

| Pattern | Scraper Location |
|---------|-----------------|
| XPath parser (Python) | `scrapyapp/xpath/parser.py` |
| XPath parser (JS) | `puppet-master/xpath/inBrowserParser.js` |
| XPath configs | `scrapyapp/xpath/ozon/*.json` |
| Request interception | `puppet-master/generic-crawler.js:46-125` |
| Smart scroll | `puppet-master/puppeteer-utils.js:3-45` |
| Mouse movement | `vnc.py:27-100` |
| Streaming crawler | `puppet-master/generic-crawler.js:147-206` |
| Container management | `dockercontrol.py` |
