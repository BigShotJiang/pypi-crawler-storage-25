# Security Analysis and Best Practices

**Document Version:** 1.0
**Last Updated:** 2025-12-09

## Table of Contents

- [Overview](#overview)
- [Threat Model](#threat-model)
- [Security Architecture](#security-architecture)
- [Attack Vectors & Mitigations](#attack-vectors--mitigations)
- [Data Protection](#data-protection)
- [Network Security](#network-security)
- [Container Security](#container-security)
- [API Security](#api-security)
- [Browser Security](#browser-security)
- [Production Hardening](#production-hardening)
- [Compliance Considerations](#compliance-considerations)
- [Security Checklist](#security-checklist)

---

## Overview

Browser API Wrapper exposes significant attack surface:
- Remote code execution via browser
- Persistent storage (profiles) with sensitive data
- Network access to arbitrary URLs
- Extension execution
- Container orchestration

This document provides comprehensive security analysis and hardening guidance.

---

## Threat Model

### Assets

1. **Browser Sessions** - Running browser instances with user context
2. **Profile Data** - Cookies, localStorage, credentials, session tokens
3. **API Service** - Control plane for browser operations
4. **Host System** - Server running Docker containers
5. **Network** - Outbound connections from browsers
6. **Extensions** - Third-party code execution in browser

### Threat Actors

| Actor | Motivation | Capability | Likelihood |
|-------|------------|------------|------------|
| **External Attacker** | Data theft, resource abuse | Remote access | High |
| **Malicious User** | Container escape, lateral movement | API access | Medium |
| **Insider Threat** | Data exfiltration | Full access | Low |
| **Automated Bots** | Crypto mining, spam | Internet-wide scanning | High |

### Trust Boundaries

```
┌─────────────────────────────────────────────────┐
│  Trusted Network (VPN/Firewall)                 │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  API Layer (FastAPI)                       │ │
│  │  - API Key Authentication                  │ │
│  │  - Request Validation                      │ │
│  └────────────────────────────────────────────┘ │
│                ▼                                 │
│  ┌────────────────────────────────────────────┐ │
│  │  Container Isolation (Docker)              │ │
│  │  - One browser per container               │ │
│  │  - Resource limits                         │ │
│  │  - Network isolation                       │ │
│  └────────────────────────────────────────────┘ │
│                ▼                                 │
│  ┌────────────────────────────────────────────┐ │
│  │  Browser Sandbox (Chromium)                │ │
│  │  - Multi-process architecture              │ │
│  │  - Site isolation                          │ │
│  └────────────────────────────────────────────┘ │
│                ▼                                 │
└────────────────┼────────────────────────────────┘
                 ▼
        Internet (Untrusted)
```

---

## Security Architecture

### Defense in Depth Layers

1. **Network Layer**
   - Firewall rules (restrict API to trusted IPs)
   - TLS/HTTPS for API
   - VPN for administrative access

2. **API Layer**
   - Authentication (API keys)
   - Input validation (Pydantic)
   - Rate limiting
   - CORS policies

3. **Container Layer**
   - Docker isolation
   - Resource limits (CPU, memory)
   - Read-only filesystem (where possible)
   - Minimal capabilities

4. **Browser Layer**
   - Chromium sandbox
   - Site isolation
   - No privileged extensions
   - CSP headers

5. **Data Layer**
   - Encrypted storage
   - Secure credential management
   - Audit logging

---

## Attack Vectors & Mitigations

### AV-1: Unauthorized API Access

**Attack:** Attacker gains API access without valid credentials.

**Impact:** Critical - Full control over browser sessions, data theft

**Mitigations:**
- ✅ API key authentication required
- ✅ Keys stored as environment variables (not in code)
- 🔲 TLS/HTTPS enforcement (should add)
- 🔲 IP allowlisting (optional)
- 🔲 Rate limiting (should add)
- 🔲 API key rotation policy

**Recommendations:**
```bash
# Strong API key generation
openssl rand -base64 32

# Environment variable (never commit)
export API_KEYS=your-secure-key-here

# HTTPS via reverse proxy
# nginx config:
server {
    listen 443 ssl;
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

---

### AV-2: Container Escape

**Attack:** Malicious code in browser exploits Docker to escape to host.

**Impact:** Critical - Host compromise, lateral movement

**Mitigations:**
- ✅ Unprivileged containers (non-root user)
- ✅ Docker isolation
- 🔲 AppArmor/SELinux profiles
- 🔲 Seccomp filtering
- 🔲 Read-only root filesystem
- 🔲 Drop unnecessary capabilities

**Recommendations:**

Dockerfile hardening:
```dockerfile
# Run as non-root user
RUN groupadd -r browseruser && useradd -r -g browseruser browseruser
USER browseruser

# Read-only root filesystem (where possible)
# Note: Browser needs write access to profile dir
VOLUME /data/profiles
```

Docker run with security options:
```bash
docker run \
  --security-opt=no-new-privileges \
  --security-opt=apparmor=docker-default \
  --cap-drop=ALL \
  --cap-add=SYS_CHROOT \
  --read-only \
  --tmpfs /tmp \
  -v profiles:/data/profiles \
  browserapi
```

---

### AV-3: Resource Exhaustion (DoS)

**Attack:** Attacker creates unlimited sessions or resource-intensive operations.

**Impact:** High - Service unavailable, cost increase

**Mitigations:**
- ✅ Session timeout (hard close)
- ✅ Docker resource limits (CPU, memory)
- 🔲 Rate limiting (per API key)
- 🔲 Max sessions per user
- 🔲 Request size limits
- 🔲 Monitoring/alerting

**Recommendations:**

docker-compose.yml:
```yaml
services:
  browser-api:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 512M
```

Application config:
```python
class Settings(BaseSettings):
    max_sessions_per_user: int = 10
    max_session_duration: int = 3600
    max_request_size: int = 10_485_760  # 10MB
```

---

### AV-4: Profile Data Theft

**Attack:** Attacker accesses other users' profiles (cookies, credentials).

**Impact:** Critical - Credential theft, account takeover

**Mitigations:**
- ✅ API key authentication prevents cross-user access
- 🔲 Encrypt profiles at rest
- 🔲 Profile access audit logging
- 🔲 Per-user encryption keys

**Recommendations:**

Filesystem encryption (LUKS):
```bash
# Encrypt volume for profiles
cryptsetup luksFormat /dev/sdb
cryptsetup open /dev/sdb profiles_encrypted
mkfs.ext4 /dev/mapper/profiles_encrypted
mount /dev/mapper/profiles_encrypted /data/profiles
```

Application-level encryption:
```python
from cryptography.fernet import Fernet

# Generate key per profile_id (derived from API key + profile_id)
key = derive_key(api_key, profile_id)
cipher = Fernet(key)

# Encrypt sensitive files before storage
encrypted_data = cipher.encrypt(profile_data)
```

---

### AV-5: Malicious Extension

**Attack:** User uploads malicious extension that steals data or mines crypto.

**Impact:** High - Data exfiltration, resource abuse

**Mitigations:**
- ⚠️ User responsibility (no automated vetting)
- 🔲 Extension manifest validation
- 🔲 Restrict dangerous permissions
- 🔲 Network egress filtering
- 🔲 Extension sandboxing

**Recommendations:**

Extension validation:
```python
DANGEROUS_PERMISSIONS = [
    "debugger",  # Can inject code
    "management",  # Can disable extensions
    "privacy",  # Can modify privacy settings
]

def validate_extension_manifest(manifest):
    permissions = manifest.get("permissions", [])
    for perm in permissions:
        if perm in DANGEROUS_PERMISSIONS:
            raise ValidationError(f"Dangerous permission: {perm}")
```

Network egress filtering:
```bash
# Restrict outbound connections (iptables)
iptables -A OUTPUT -p tcp --dport 80 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 443 -j ACCEPT
iptables -A OUTPUT -j DROP  # Block all other outbound
```

---

### AV-6: VNC Session Hijacking

**Attack:** Attacker brute-forces VNC password or intercepts connection.

**Impact:** High - Session takeover, visual surveillance

**Mitigations:**
- ✅ Unique password per session
- 🔲 Strong password generation (12+ chars)
- 🔲 TLS for VNC (VNC over SSH or stunnel)
- 🔲 VNC access logging
- 🔲 Rate limiting on VNC port

**Recommendations:**

Strong password generation:
```python
import secrets
import string

def generate_vnc_password():
    # 12 characters (VNC protocol limit is 8, but we can hash)
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(12))
```

VNC over SSH tunnel:
```bash
# Client-side
ssh -L 5900:localhost:5900 user@api-server
vncviewer localhost:5900
```

---

### AV-7: Cross-Site Request Forgery (CSRF)

**Attack:** Malicious site tricks user into making API requests.

**Impact:** Medium - Unauthorized session creation/manipulation

**Mitigations:**
- ✅ API key in header (not cookie) prevents CSRF
- 🔲 CORS policy (restrict origins)
- 🔲 Referer validation
- 🔲 CSRF tokens (if adding web UI)

**Recommendations:**

FastAPI CORS middleware:
```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://trusted-client.com"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["X-API-Key"],
)
```

---

### AV-8: JavaScript Injection via Eval

**Attack:** Attacker injects malicious JS via `/eval` endpoint.

**Impact:** High - XSS, data theft within page context

**Mitigations:**
- ⚠️ Documented risk (user controls eval input)
- 🔲 Input sanitization (limited effectiveness)
- 🔲 CSP headers in target pages
- 🔲 Eval audit logging

**Recommendations:**

Document in API:
```markdown
### Security Warning: JavaScript Eval

The `/eval` endpoint executes arbitrary JavaScript in the page context.
- Only eval trusted code
- Sanitize user input before eval
- Consider using safer alternatives (click, type, fill)
```

Audit logging:
```python
@app.post("/sessions/{session_id}/pages/{page_id}/eval")
async def eval_js(session_id: str, page_id: str, request: EvalRequest):
    logger.warning(
        f"eval called: session={session_id}, script={request.script[:100]}"
    )
    # ... execute eval
```

---

### AV-9: Profile Corruption (Shared Access)

**Attack:** Concurrent writes to shared profile cause data corruption.

**Impact:** Medium - Data loss, undefined behavior

**Mitigations:**
- ⚠️ Documented risk (ADR-003)
- 🔲 File locking (limited effectiveness for LevelDB)
- 🔲 Profile versioning
- 🔲 Backup before sharing

**Recommendations:**

Document safe usage:
```markdown
### Profile Sharing Warning

Concurrent access to the same profile_id can cause corruption.

Safe pattern:
- Use unique profile_id per session: `user-{user_id}-{session_num}`
- Share profiles sequentially (not concurrently)
- Export/import state for sharing

Risky pattern:
- Multiple sessions with `profile_id: "shared"` (may corrupt)
```

---

### AV-10: Supply Chain Attack

**Attack:** Compromised dependency or Docker base image.

**Impact:** Critical - Backdoor, data exfiltration

**Mitigations:**
- 🔲 Pin dependency versions
- 🔲 Verify checksums/signatures
- 🔲 Scan for vulnerabilities (Snyk, Trivy)
- 🔲 Use official base images
- 🔲 Minimal dependencies

**Recommendations:**

requirements.txt with hashes:
```
fastapi==0.109.0 --hash=sha256:...
uvicorn==0.27.0 --hash=sha256:...
playwright==1.49.0 --hash=sha256:...
```

Dockerfile with specific versions:
```dockerfile
FROM mcr.microsoft.com/playwright:v1.49.0-noble@sha256:abc123...
```

Vulnerability scanning:
```bash
# Scan Docker image
trivy image browserapi:latest

# Scan Python dependencies
safety check
```

---

## Data Protection

### Sensitive Data Classification

| Data Type | Sensitivity | Storage | Retention |
|-----------|-------------|---------|-----------|
| API Keys | Critical | Environment vars | Permanent |
| VNC Passwords | High | Memory only | Session lifetime |
| Profile Cookies | High | Encrypted disk | User-defined |
| Session Tokens | High | Encrypted disk | User-defined |
| Screenshots | Medium | Ephemeral | On-demand |
| Request Logs | Medium | Disk/SIEM | 30 days |
| HTML Content | Low | Ephemeral | On-demand |

### Encryption

**At Rest:**
- Profile storage: LUKS disk encryption or application-level encryption
- API keys: Environment variables (never in code/logs)
- Backups: Encrypted archives (GPG, age)

**In Transit:**
- API: HTTPS/TLS 1.3
- VNC: SSH tunnel or stunnel
- CDP: WebSocket over TLS

**In Use:**
- Memory: No special handling (rely on OS isolation)
- Swap: Disable swap or encrypt swap partition

### Data Retention

```python
class RetentionPolicy:
    session_logs: timedelta = timedelta(days=30)
    audit_logs: timedelta = timedelta(days=90)
    profiles: str = "user-managed"  # No automatic deletion
    screenshots: str = "ephemeral"  # Not stored by default
```

---

## Network Security

### Firewall Rules

Recommended iptables configuration:

```bash
# Allow SSH (admin access)
iptables -A INPUT -p tcp --dport 22 -s ADMIN_IP -j ACCEPT

# Allow API (from trusted network)
iptables -A INPUT -p tcp --dport 8000 -s TRUSTED_CIDR -j ACCEPT

# Allow VNC (from trusted network)
iptables -A INPUT -p tcp --dport 5900 -s TRUSTED_CIDR -j ACCEPT
iptables -A INPUT -p tcp --dport 6080 -s TRUSTED_CIDR -j ACCEPT

# Block all other inbound
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -j DROP

# Outbound: Allow DNS, HTTP, HTTPS (for browser)
iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 80 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 443 -j ACCEPT
iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
```

### Network Segmentation

```
┌──────────────────┐
│  Management Net  │  (SSH, monitoring)
│  10.0.1.0/24     │
└────────┬─────────┘
         │
┌────────▼─────────┐
│  API Net         │  (API server)
│  10.0.2.0/24     │
└────────┬─────────┘
         │
┌────────▼─────────┐
│  Container Net   │  (Browser containers)
│  10.0.3.0/24     │
└────────┬─────────┘
         │
┌────────▼─────────┐
│  Internet        │
└──────────────────┘
```

---

## Container Security

### Docker Security Best Practices

1. **Run as non-root**
```dockerfile
RUN useradd -m -u 1000 browseruser
USER browseruser
```

2. **Drop capabilities**
```bash
docker run --cap-drop=ALL --cap-add=SYS_CHROOT browserapi
```

3. **Read-only root filesystem**
```bash
docker run --read-only --tmpfs /tmp browserapi
```

4. **Resource limits**
```yaml
deploy:
  resources:
    limits:
      cpus: '2'
      memory: 2G
      pids: 1000
```

5. **Seccomp profile**
```json
{
  "defaultAction": "SCMP_ACT_ERRNO",
  "architectures": ["SCMP_ARCH_X86_64"],
  "syscalls": [
    {"names": ["read", "write", "open", "close"], "action": "SCMP_ACT_ALLOW"}
  ]
}
```

6. **Network isolation**
```bash
docker network create --internal containers_net
docker run --network containers_net browserapi
```

---

## API Security

### Authentication & Authorization

**Current (MVP):**
- API key in `X-API-Key` header
- No fine-grained permissions
- All-or-nothing access

**Future Enhancements:**
- OAuth2 / JWT
- Role-based access control (RBAC)
- Per-session permissions
- Audit logging

### Input Validation

Pydantic models enforce validation:

```python
class SessionCreate(BaseModel):
    profile_id: str | None = Field(None, max_length=255, pattern=r'^[a-zA-Z0-9_-]+$')
    timeout: int = Field(3600, ge=60, le=86400)  # 1 min to 24 hours

    @field_validator('profile_id')
    def validate_profile_id(cls, v):
        if v and '..' in v:
            raise ValueError('Invalid profile_id: path traversal detected')
        return v
```

### Rate Limiting

Add middleware for rate limiting:

```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@app.post("/sessions")
@limiter.limit("10/minute")
async def create_session(...):
    ...
```

---

## Browser Security

### Chromium Sandbox

Chromium's multi-process architecture provides defense in depth:
- Renderer process: Sandboxed, minimal privileges
- GPU process: Sandboxed
- Network process: Isolated

Keep Playwright/Chromium up to date for security patches.

### Site Isolation

Enable Site Isolation (on by default):
```python
context = await playwright.chromium.launch_persistent_context(
    args=["--site-per-process"]
)
```

### Content Security Policy

For pages under your control, set CSP headers:
```python
await page.set_extra_http_headers({
    "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'"
})
```

---

## Production Hardening

### Pre-Deployment Checklist

- [ ] TLS/HTTPS enabled (nginx/Caddy reverse proxy)
- [ ] API keys generated with `openssl rand -base64 32`
- [ ] Firewall rules configured (restrict API/VNC to trusted IPs)
- [ ] Docker security options enabled (non-root, cap-drop, seccomp)
- [ ] Profile storage encrypted (LUKS or equivalent)
- [ ] Monitoring and alerting configured
- [ ] Audit logging enabled
- [ ] Dependency versions pinned and scanned
- [ ] Backups automated and tested
- [ ] Incident response plan documented

### Monitoring & Alerting

**Metrics to monitor:**
- API request rate (detect DoS)
- Session creation rate
- Failed authentication attempts
- Resource usage (CPU, memory, disk)
- Container count
- Error rates

**Alerts:**
- Failed auth > 10/minute
- Sessions > max_sessions
- Disk usage > 80%
- High CPU usage (sustained)

**Tools:**
- Prometheus + Grafana
- ELK stack (Elasticsearch, Logstash, Kibana)
- Sentry (error tracking)

### Audit Logging

Log security-relevant events:

```python
import logging
import structlog

audit_logger = structlog.get_logger("audit")

@app.post("/sessions")
async def create_session(request: Request, ...):
    audit_logger.info(
        "session_created",
        api_key=hash_api_key(request.headers.get("X-API-Key")),
        profile_id=req.profile_id,
        proxy=bool(req.proxy),
        extensions=req.extensions,
        timestamp=datetime.utcnow().isoformat(),
    )
```

### Backup Strategy

**What to backup:**
- Profile data (`/data/profiles`)
- Extension data (`/data/extensions`)
- Configuration (docker-compose.yml, .env)

**Backup script:**
```bash
#!/bin/bash
BACKUP_DIR=/backups
DATE=$(date +%Y%m%d-%H%M%S)

# Encrypt and backup profiles
tar czf - /data/profiles | gpg -e -r backup@example.com > $BACKUP_DIR/profiles-$DATE.tar.gz.gpg

# Retention: keep 7 days
find $BACKUP_DIR -mtime +7 -delete
```

### Incident Response

1. **Detect:** Monitoring alerts trigger
2. **Contain:** Isolate affected containers (`docker stop`)
3. **Investigate:** Review audit logs, container logs
4. **Remediate:** Patch vulnerability, rotate API keys
5. **Recover:** Restore from backup if needed
6. **Post-mortem:** Document incident, improve defenses

---

## Compliance Considerations

### GDPR (EU)

**Implications:**
- Profile data may contain PII (cookies, personal info)
- Users have right to data export, deletion
- Data breach notification (72 hours)

**Compliance:**
- Implement `GET /profiles/{id}/state` (data export)
- Implement `DELETE /profiles/{id}` (right to be forgotten)
- Encrypt profile data at rest
- Audit logging for data access
- Data retention policy

### SOC 2 / ISO 27001

**Controls needed:**
- Access control (API key authentication)
- Encryption (TLS, disk encryption)
- Monitoring and logging
- Incident response plan
- Vendor risk management (Playwright, Docker)
- Backup and recovery

### PCI-DSS (if handling payment data)

**Requirements:**
- Do NOT store payment card data in profiles
- If unavoidable: PCI-DSS Level 1 compliance required
- Use tokenization instead

---

## Security Checklist

### Development
- [ ] Input validation on all endpoints (Pydantic)
- [ ] API key authentication enforced
- [ ] No secrets in code (use environment variables)
- [ ] Dependencies pinned with hashes
- [ ] Vulnerability scanning (Snyk, Trivy)

### Deployment
- [ ] TLS/HTTPS enabled
- [ ] Strong API keys generated
- [ ] Firewall configured
- [ ] Docker security options enabled
- [ ] Profile encryption enabled
- [ ] Non-root user in containers

### Operations
- [ ] Monitoring and alerting active
- [ ] Audit logging enabled
- [ ] Backups automated and tested
- [ ] Incident response plan documented
- [ ] Security updates applied monthly

### Compliance
- [ ] Data retention policy defined
- [ ] Privacy policy published
- [ ] Data export/deletion implemented
- [ ] Audit trail maintained

---

## References

- OWASP Top 10: https://owasp.org/www-project-top-ten/
- Docker Security: https://docs.docker.com/engine/security/
- Chromium Security: https://www.chromium.org/Home/chromium-security/
- CIS Docker Benchmark: https://www.cisecurity.org/benchmark/docker

---

## Conclusion

Security is a continuous process. This document provides baseline hardening guidance, but threats evolve. Regular security reviews, penetration testing, and updates are essential for production deployments.

**Next Steps:**
1. Implement TLS/HTTPS
2. Add rate limiting
3. Enable audit logging
4. Set up monitoring/alerting
5. Conduct security audit before production launch
