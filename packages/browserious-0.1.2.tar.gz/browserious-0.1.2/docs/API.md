# Browser API - Complete API Reference

**Version:** 1.0.0
**Base URL:** `http://localhost:8100`
**Authentication:** API Key (X-API-Key header)

## Table of Contents

- [Authentication](#authentication)
- [Error Responses](#error-responses)
- [Sessions](#sessions)
- [Pages](#pages)
- [Request Interception](#request-interception)
- [Input Simulation](#input-simulation)
- [CAPTCHA Detection & Solving](#captcha-detection--solving)
- [Profiles](#profiles)
- [Extensions](#extensions)
- [VNC Remote Viewing](#vnc-remote-viewing)
- [CDP WebSocket](#cdp-websocket)
- [Complete Examples](#complete-examples)

---

## Authentication

All API requests require an API key in the `X-API-Key` header.

```bash
curl -H "X-API-Key: your-api-key" http://localhost:8100/sessions
```

### Configuration

Set API keys via environment variable:
```bash
export API_KEYS=key1,key2,key3
```

### Error Response

```json
{
  "detail": "Invalid or missing API key"
}
```

Status: `401 Unauthorized`

---

## Error Responses

All errors follow a consistent format:

```json
{
  "detail": "Human-readable error message",
  "error_code": "ERROR_CODE",
  "context": {
    "additional": "context"
  }
}
```

### Common Error Codes

| Status | Error Code | Description |
|--------|-----------|-------------|
| 400 | `INVALID_REQUEST` | Malformed request body or parameters |
| 401 | `UNAUTHORIZED` | Invalid or missing API key |
| 404 | `SESSION_NOT_FOUND` | Session ID does not exist |
| 404 | `PAGE_NOT_FOUND` | Page ID does not exist |
| 409 | `SESSION_LIMIT_REACHED` | Maximum concurrent sessions exceeded |
| 422 | `VALIDATION_ERROR` | Request validation failed (Pydantic) |
| 500 | `INTERNAL_ERROR` | Unexpected server error |
| 504 | `BROWSER_TIMEOUT` | Browser operation timed out |

---

## Sessions

### Create Session

`POST /sessions`

Creates a new browser session with specified configuration.

#### Request Body

```json
{
  "profile_id": "user-123",
  "proxy": {
    "server": "http://proxy.example.com:8080",
    "username": "proxyuser",
    "password": "proxypass"
  },
  "extensions": ["ext-abc123", "ext-def456"],
  "viewport": {
    "width": 1920,
    "height": 1080
  },
  "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
  "timeout": 3600
}
```

#### Parameters

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `profile_id` | string | No | `<uuid>` | Profile identifier for persistent storage |
| `proxy.server` | string | No | None | Proxy URL (http/https/socks5) |
| `proxy.username` | string | No | None | Proxy authentication username |
| `proxy.password` | string | No | None | Proxy authentication password |
| `extensions` | string[] | No | `[]` | List of extension IDs to load |
| `viewport.width` | integer | No | 1920 | Browser viewport width |
| `viewport.height` | integer | No | 1080 | Browser viewport height |
| `user_agent` | string | No | Default | Custom user agent string |
| `timeout` | integer | No | 3600 | Session lifetime in seconds |

#### Response

```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "profile_id": "user-123",
  "cdp_url": "ws://192.168.x.x:9222",
  "vnc_url": "ws://localhost:8100/sessions/550e8400-e29b-41d4-a716-446655440000/vnc",
  "vnc_password": "",
  "web_vnc_url": "http://localhost:8100/vnc.html?session=550e8400-e29b-41d4-a716-446655440000",
  "container_id": "docker-abc123",
  "created_at": "2025-12-09T10:30:00Z",
  "expires_at": "2025-12-09T11:30:00Z"
}
```

#### Example

```bash
curl -X POST http://localhost:8100/sessions \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "profile_id": "scraper-001",
    "proxy": {
      "server": "http://proxy.example.com:8080"
    },
    "viewport": {"width": 1280, "height": 720},
    "timeout": 7200
  }'
```

---

### List Sessions

`GET /sessions`

Returns all active sessions.

#### Response

```json
{
  "sessions": [
    {
      "session_id": "550e8400-e29b-41d4-a716-446655440000",
      "profile_id": "scraper-001",
      "created_at": "2025-12-09T10:30:00Z",
      "expires_at": "2025-12-09T11:30:00Z",
      "page_count": 3,
      "route_count": 1
    }
  ],
  "total": 1
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" http://localhost:8100/sessions
```

---

### Get Session Details

`GET /sessions/{session_id}`

Returns detailed information about a specific session.

#### Response

```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "profile_id": "scraper-001",
  "container_id": "docker-abc123",
  "created_at": "2025-12-09T10:30:00Z",
  "expires_at": "2025-12-09T11:30:00Z",
  "pages": [
    {
      "page_id": "page-0",
      "url": "https://example.com",
      "title": "Example Domain"
    },
    {
      "page_id": "page-1",
      "url": "https://httpbin.org",
      "title": "httpbin"
    }
  ],
  "routes": [
    {
      "route_id": "route-123",
      "pattern": "**/*.{png,jpg}"
    }
  ],
  "extensions": ["ext-abc123"],
  "proxy": {
    "server": "http://proxy.example.com:8080"
  },
  "viewport": {"width": 1280, "height": 720}
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  http://localhost:8100/sessions/550e8400-e29b-41d4-a716-446655440000
```

---

### Delete Session

`DELETE /sessions/{session_id}`

Immediately closes the session and terminates the browser.

#### Response

```json
{
  "status": "closed",
  "session_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

#### Example

```bash
curl -X DELETE \
  -H "X-API-Key: your-api-key" \
  http://localhost:8100/sessions/550e8400-e29b-41d4-a716-446655440000
```

---

### Screenshot

`GET /sessions/{session_id}/screenshot`

Capture a screenshot of the browser page or full display.

#### Query Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `page_id` | string | `page-0` | Page ID (ignored when fullscreen=true) |
| `full_page` | boolean | false | Capture full scrollable page |
| `fullscreen` | boolean | false | Capture full X11 display (includes browser chrome) |
| `type` | string | `png` | Image format: `png`, `jpeg` |
| `quality` | integer | 80 | JPEG quality (0-100) |
| `cursor` | boolean | false | Draw cursor overlay on screenshot |
| `crop_x` | integer | null | Crop region X coordinate |
| `crop_y` | integer | null | Crop region Y coordinate |
| `crop_width` | integer | null | Crop region width |
| `crop_height` | integer | null | Crop region height |

#### Response

Binary image data with `Content-Type: image/png` or `image/jpeg`.

#### Examples

```bash
# Page viewport (default)
curl -H "X-API-Key: your-api-key" \
  "http://localhost:8100/sessions/{session_id}/screenshot" > page.png

# Full scrollable page
curl -H "X-API-Key: your-api-key" \
  "http://localhost:8100/sessions/{session_id}/screenshot?full_page=true" > full.png

# Full display with browser chrome
curl -H "X-API-Key: your-api-key" \
  "http://localhost:8100/sessions/{session_id}/screenshot?fullscreen=true" > display.png

# With cursor overlay and crop
curl -H "X-API-Key: your-api-key" \
  "http://localhost:8100/sessions/{session_id}/screenshot?cursor=true&crop_x=100&crop_y=100&crop_width=400&crop_height=300" > cropped.png
```

---

## Pages

### Create Page

`POST /sessions/{session_id}/pages`

Creates a new tab/page in the session.

#### Request Body (Optional)

```json
{
  "url": "https://example.com"
}
```

#### Response

```json
{
  "page_id": "page-1",
  "url": "https://example.com",
  "title": "Example Domain"
}
```

#### Example

```bash
curl -X POST \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com"}' \
  http://localhost:8100/sessions/{session_id}/pages
```

---

### List Pages

`GET /sessions/{session_id}/pages`

Returns all pages/tabs in the session.

#### Response

```json
{
  "pages": [
    {
      "page_id": "page-0",
      "url": "https://example.com",
      "title": "Example Domain"
    }
  ]
}
```

---

### Navigate

`POST /sessions/{session_id}/pages/{page_id}/goto`

Navigates the page to a URL.

#### Request Body

```json
{
  "url": "https://example.com",
  "wait_until": "networkidle",
  "timeout": 30000
}
```

#### Parameters

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `url` | string | Yes | - | Target URL |
| `wait_until` | string | No | `load` | When to consider navigation complete: `load`, `domcontentloaded`, `networkidle` |
| `timeout` | integer | No | 30000 | Navigation timeout in milliseconds |

#### Response

```json
{
  "status": "ok",
  "url": "https://example.com",
  "title": "Example Domain",
  "load_time_ms": 1234
}
```

#### Example

```bash
curl -X POST \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com", "wait_until": "networkidle"}' \
  http://localhost:8100/sessions/{session_id}/pages/{page_id}/goto
```

---

### Click Element

`POST /sessions/{session_id}/pages/{page_id}/click`

Clicks an element on the page.

#### Request Body

```json
{
  "selector": {
    "strategy": "css",
    "value": "#submit-button"
  },
  "timeout": 5000,
  "force": false
}
```

#### Selector Strategies

##### CSS Selector
```json
{"strategy": "css", "value": "#submit-button"}
```

##### XPath
```json
{"strategy": "xpath", "value": "//button[contains(text(), 'Submit')]"}
```

##### Playwright Text
```json
{"strategy": "text", "value": "text=Submit"}
```

##### Playwright Role
```json
{"strategy": "role", "value": "role=button[name='Submit']"}
```

##### JavaScript Function
```json
{
  "strategy": "js",
  "value": "() => document.querySelectorAll('.item')[0]"
}
```

#### Parameters

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `selector` | object | Yes | - | Element selector |
| `selector.strategy` | string | Yes | - | `css`, `xpath`, `text`, `role`, `js` |
| `selector.value` | string | Yes | - | Selector expression |
| `timeout` | integer | No | 5000 | Wait timeout in milliseconds |
| `force` | boolean | No | false | Force click even if element not interactive |

#### Response

```json
{
  "status": "ok",
  "selector": {"strategy": "css", "value": "#submit-button"}
}
```

#### Example

```bash
curl -X POST \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "selector": {"strategy": "css", "value": "#login-button"},
    "timeout": 10000
  }' \
  http://localhost:8100/sessions/{session_id}/pages/{page_id}/click
```

---

### Type Text

`POST /sessions/{session_id}/pages/{page_id}/type`

Types text into an element (simulates keyboard input with events).

#### Request Body

```json
{
  "selector": {"strategy": "css", "value": "#username"},
  "text": "myusername",
  "delay": 50,
  "clear": true
}
```

#### Parameters

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `selector` | object | Yes | - | Element selector |
| `text` | string | Yes | - | Text to type |
| `delay` | integer | No | 0 | Delay between keystrokes (ms) |
| `clear` | boolean | No | false | Clear existing text first |

#### Response

```json
{
  "status": "ok",
  "text": "myusername"
}
```

---

### Fill Input

`POST /sessions/{session_id}/pages/{page_id}/fill`

Fills an input field (fast, no keyboard events).

#### Request Body

```json
{
  "selector": {"strategy": "css", "value": "#email"},
  "value": "user@example.com"
}
```

#### Response

```json
{
  "status": "ok",
  "value": "user@example.com"
}
```

---

### Wait for Selector

`POST /sessions/{session_id}/pages/{page_id}/waitForSelector`

Waits for an element to appear/disappear.

#### Request Body

```json
{
  "selector": {"strategy": "css", "value": ".loaded"},
  "state": "visible",
  "timeout": 30000
}
```

#### Parameters

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `selector` | object | Yes | - | Element selector |
| `state` | string | No | `visible` | `visible`, `hidden`, `attached`, `detached` |
| `timeout` | integer | No | 30000 | Wait timeout in milliseconds |

#### Response

```json
{
  "status": "ok",
  "found": true,
  "wait_time_ms": 1234
}
```

---

### Execute JavaScript

`POST /sessions/{session_id}/pages/{page_id}/eval`

Executes JavaScript in the page context.

#### Request Body

```json
{
  "script": "return document.title",
  "args": []
}
```

For more complex scripts:
```json
{
  "script": "({ title, url }) => ({ title, url, length: document.body.innerText.length })",
  "args": [{"title": "Example", "url": "https://example.com"}]
}
```

#### Response

```json
{
  "result": "Example Domain"
}
```

For complex return values:
```json
{
  "result": {
    "title": "Example",
    "url": "https://example.com",
    "length": 1234
  }
}
```

#### Example

```bash
curl -X POST \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"script": "return document.querySelectorAll(\".item\").length"}' \
  http://localhost:8100/sessions/{session_id}/pages/{page_id}/eval
```

---

### Get Element at Point

`GET /sessions/{session_id}/pages/{page_id}/elementAtPoint`

Gets the DOM element at specified viewport coordinates.

#### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `x` | integer | yes | X coordinate in viewport |
| `y` | integer | yes | Y coordinate in viewport |

#### Response

```json
{
  "found": true,
  "tag_name": "button",
  "id": "submit-btn",
  "class_name": "btn btn-primary",
  "text_content": "Submit",
  "bounding_box": {
    "x": 100,
    "y": 200,
    "width": 120,
    "height": 40
  },
  "attributes": {
    "type": "submit",
    "data-testid": "submit"
  },
  "xpath": "//*[@id=\"submit-btn\"]",
  "css_selector": "#submit-btn"
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  "http://localhost:8100/sessions/{session_id}/pages/{page_id}/elementAtPoint?x=150&y=300"
```

---

### Get Page HTML

`GET /sessions/{session_id}/pages/{page_id}/content`

Returns the page HTML content.

#### Response

```json
{
  "html": "<!DOCTYPE html><html><head>...</head><body>...</body></html>",
  "length": 12345
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  http://localhost:8100/sessions/{session_id}/pages/{page_id}/content
```

---

## Request Interception

### Create Route

`POST /sessions/{session_id}/routes`

Registers a request interception route.

#### Request Body - Block

```json
{
  "pattern": "**/*.{png,jpg,jpeg,gif,svg}",
  "action": {
    "type": "block"
  }
}
```

#### Request Body - Redirect

```json
{
  "pattern": "**/api/old-endpoint",
  "action": {
    "type": "redirect",
    "url": "https://api.example.com/new-endpoint"
  }
}
```

#### Request Body - Override

```json
{
  "pattern": "**/api/user",
  "action": {
    "type": "override",
    "status": 200,
    "headers": {
      "Content-Type": "application/json"
    },
    "body": "{\"id\": 123, \"name\": \"Test User\"}"
  }
}
```

#### Request Body - Inspect

```json
{
  "pattern": "**/api/**",
  "action": {
    "type": "inspect",
    "capture_body": true
  }
}
```

#### Response

```json
{
  "route_id": "route-abc123",
  "pattern": "**/*.{png,jpg,jpeg,gif,svg}",
  "action": {"type": "block"}
}
```

#### Example

```bash
curl -X POST \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "pattern": "**/*.{png,jpg}",
    "action": {"type": "block"}
  }' \
  http://localhost:8100/sessions/{session_id}/routes
```

---

### List Routes

`GET /sessions/{session_id}/routes`

Returns all active routes for the session.

#### Response

```json
{
  "routes": [
    {
      "route_id": "route-abc123",
      "pattern": "**/*.{png,jpg}",
      "action": {"type": "block"}
    },
    {
      "route_id": "route-def456",
      "pattern": "**/api/**",
      "action": {"type": "inspect"}
    }
  ]
}
```

---

### Delete Route

`DELETE /sessions/{session_id}/routes/{route_id}`

Removes a route (stops intercepting).

#### Response

```json
{
  "status": "deleted",
  "route_id": "route-abc123"
}
```

---

### Get Captured Requests

`GET /sessions/{session_id}/routes/{route_id}/inspect`

Returns captured requests for inspect-type routes.

#### Response

```json
{
  "route_id": "route-abc123",
  "pattern": "**/api/**",
  "requests": [
    {
      "timestamp": "2025-12-09T10:35:00Z",
      "method": "GET",
      "url": "https://api.example.com/data",
      "headers": {
        "Authorization": "Bearer token123",
        "User-Agent": "..."
      },
      "body": null,
      "response": {
        "status": 200,
        "headers": {
          "Content-Type": "application/json"
        },
        "body": "{\"data\": [...]}"
      },
      "timing": {
        "start_time": "2025-12-09T10:35:00.100Z",
        "end_time": "2025-12-09T10:35:00.250Z",
        "duration_ms": 150
      }
    }
  ],
  "total": 1
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  http://localhost:8100/sessions/{session_id}/routes/{route_id}/inspect
```

---

## Input Simulation

Hardware-level input simulation using X11 events through the node API. This provides true OS-level mouse and keyboard events that are indistinguishable from real user input.

### Play Input Playlist

Execute a sequence of mouse/keyboard actions with precise timing.

`POST /sessions/{session_id}/input/play`

#### Request Body

```json
{
  "actions": [
    {"type": "move", "x": 500, "y": 300, "duration_ms": 200, "easing": {"x": "ease_out_cubic", "y": "linear"}},
    {"type": "sleep", "duration_ms": 50},
    {"type": "mouse_down", "button": 1},
    {"type": "sleep", "duration_ms": 30},
    {"type": "mouse_up", "button": 1}
  ]
}
```

#### Response

```json
{
  "status": "ok",
  "executed": 5,
  "duration_ms": 280,
  "error": null,
  "failed_at": null
}
```

On error:
```json
{
  "status": "error",
  "executed": 2,
  "duration_ms": 150,
  "error": "unknown action type: invalid",
  "failed_at": 2
}
```

---

### Coordinate System

**Important:** Input simulation uses **screen coordinates** (X11 display), not browser viewport coordinates. To click on a specific element in the browser, you must convert viewport coordinates to screen coordinates.

#### Viewport to Screen Coordinate Conversion

The browser window has chrome UI (title bar, toolbar, etc.) that offsets the content area. Use JavaScript to calculate the offset:

```python
window_info = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """(() => ({
        screenX: window.screenX,
        screenY: window.screenY,
        chromeHeight: window.outerHeight - window.innerHeight,
        chromeWidth: window.outerWidth - window.innerWidth
    }))()"""}
).json()["result"]

offset_x = window_info['screenX'] + window_info['chromeWidth'] // 2
offset_y = window_info['screenY'] + window_info['chromeHeight']
```

Then convert any viewport coordinate to screen coordinate:
```python
screen_x = viewport_x + offset_x
screen_y = viewport_y + offset_y
```

#### Example: Click on Element by Bounding Box

```python
bbox = requests.post(
    f"{API_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={"script": """(() => {
        const el = document.querySelector("textarea[name='q']");
        if (!el) return null;
        const rect = el.getBoundingClientRect();
        return {x: rect.x + rect.width/2, y: rect.y + rect.height/2};
    })()"""}
).json()["result"]

screen_x = int(bbox["x"]) + offset_x
screen_y = int(bbox["y"]) + offset_y

requests.post(
    f"{API_URL}/sessions/{session_id}/input/play",
    headers=headers,
    json={"actions": [
        {"type": "move", "x": screen_x, "y": screen_y, "duration_ms": 300,
         "easing": {"x": "ease_out_cubic", "y": "ease_in_out_sine"}},
        {"type": "sleep", "duration_ms": 50},
        {"type": "click", "button": 1}
    ]}
)
```

---

### Action Types

| Type | Description |
|------|-------------|
| `move` | Move mouse with optional animation and easing |
| `sleep` | Pause execution for specified duration |
| `mouse_down` | Press mouse button |
| `mouse_up` | Release mouse button |
| `click` | Move to position (optional) and click |
| `key_down` | Press and hold a key |
| `key_up` | Release a key |
| `key` | Press and release a key |
| `type_text` | Type text with human-like variable timing |
| `scroll` | Scroll wheel in X/Y direction |

### Action Parameters

#### move

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `x` | int | Yes | - | Target X screen coordinate |
| `y` | int | Yes | - | Target Y screen coordinate |
| `duration_ms` | int | No | 0 | Animation duration (0 = instant) |
| `easing.x` | string | No | `linear` | Easing function for X axis |
| `easing.y` | string | No | `linear` | Easing function for Y axis |

#### sleep

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `duration_ms` | int | Yes | Pause duration in milliseconds |

#### mouse_down / mouse_up

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `button` | int | Yes | - | 1=left, 2=middle, 3=right |

#### click

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `x` | int | No | current | Target X (0 = use current position) |
| `y` | int | No | current | Target Y (0 = use current position) |
| `button` | int | No | 1 | Mouse button (1=left, 2=middle, 3=right) |
| `count` | int | No | 1 | Number of clicks (2 = double-click) |

#### key_down / key_up / key

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `key` | string | Yes | Key name (see Key Names below) |

#### type_text

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Text to type |
| `interval.min_ms` | int | No | 40 | Minimum delay between keystrokes |
| `interval.max_ms` | int | No | 120 | Maximum delay between keystrokes |

#### scroll

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `delta_x` | int | Yes | Horizontal scroll (+ = right) |
| `delta_y` | int | Yes | Vertical scroll (+ = down) |

---

### Key Names

For `key`, `key_down`, and `key_up` actions, use X11 keysym names:

**Special Keys:**
- `Return` (Enter)
- `Tab`
- `space`
- `BackSpace`
- `Escape`
- `Delete`
- `Insert`
- `Home`, `End`
- `Page_Up`, `Page_Down`
- `Up`, `Down`, `Left`, `Right`

**Modifier Keys:**
- `Shift_L`, `Shift_R`
- `Control_L`, `Control_R`
- `Alt_L`, `Alt_R`
- `Super_L` (Windows/Command key)

**Function Keys:**
- `F1` through `F12`

**Punctuation (for type_text, automatically mapped):**
- `exclam` (!)
- `at` (@)
- `numbersign` (#)
- `dollar` ($)
- `percent` (%)
- `ampersand` (&)
- `asterisk` (*)
- `parenleft` ((, `parenright` ())
- `minus` (-), `underscore` (_)
- `equal` (=), `plus` (+)
- `bracketleft` ([), `bracketright` (])
- `braceleft` ({), `braceright` (})
- `semicolon` (;), `colon` (:)
- `apostrophe` ('), `quotedbl` (")
- `comma` (,), `period` (.)
- `slash` (/), `backslash` (\)
- `question` (?), `bar` (|)
- `grave` (`), `asciitilde` (~)
- `less` (<), `greater` (>)
- `asciicircum` (^)

---

### Easing Functions

Available easing functions for `move` action. Use different functions for X and Y axes to create natural curved mouse paths:

**Basic:** `linear`

**Sine:** `ease_in_sine`, `ease_out_sine`, `ease_in_out_sine`

**Power:**
- Quadratic: `ease_in_quad`, `ease_out_quad`, `ease_in_out_quad`
- Cubic: `ease_in_cubic`, `ease_out_cubic`, `ease_in_out_cubic`
- Quartic: `ease_in_quart`, `ease_out_quart`, `ease_in_out_quart`
- Quintic: `ease_in_quint`, `ease_out_quint`, `ease_in_out_quint`

**Exponential:** `ease_in_expo`, `ease_out_expo`, `ease_in_out_expo`

**Circular:** `ease_in_circ`, `ease_out_circ`, `ease_in_out_circ`

**Back (overshoot):** `ease_in_back`, `ease_out_back`, `ease_in_out_back`

**Elastic (spring):** `ease_in_elastic`, `ease_out_elastic`, `ease_in_out_elastic`

**Bounce:** `ease_in_bounce`, `ease_out_bounce`, `ease_in_out_bounce`

#### Human-like Mouse Movement

Combine different easing functions on X and Y to create arc-like paths:
```json
{
  "type": "move",
  "x": 500,
  "y": 300,
  "duration_ms": 400,
  "easing": {
    "x": "ease_out_cubic",
    "y": "ease_in_out_sine"
  }
}
```

---

### Get Mouse Position

`GET /sessions/{session_id}/input/position`

Returns the current mouse cursor position in screen coordinates.

#### Response

```json
{
  "x": 500,
  "y": 300
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  http://localhost:8100/sessions/{session_id}/input/position
```

---

## CAPTCHA Detection & Solving

### Detect CAPTCHAs

`GET /sessions/{session_id}/pages/{page_id}/captchas`

Detects CAPTCHA elements on the page. Identifies reCAPTCHA, hCaptcha, Cloudflare Turnstile, and other common providers.

#### Response

```json
{
  "found": true,
  "count": 1,
  "captchas": [
    {
      "type": "iframe",
      "provider": "recaptcha",
      "bounding_box": {
        "x": 250,
        "y": 150,
        "width": 400,
        "height": 580
      },
      "viewport_coords": {
        "x": 250,
        "y": 150,
        "center_x": 450,
        "center_y": 440
      },
      "iframe_src": "https://www.google.com/recaptcha/api2/anchor...",
      "element_selector": "iframe[src*=\"recaptcha\"]"
    }
  ]
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  http://localhost:8100/sessions/{session_id}/pages/page-0/captchas
```

---

### Segment CAPTCHA

`GET /sessions/{session_id}/pages/{page_id}/captcha/segment`

Segments a detected CAPTCHA into interactive grid cells and buttons. Returns precise bounding boxes for each cell in screen coordinates.

#### Query Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `captcha_index` | integer | 0 | Index of captcha to segment (from /captchas) |

#### Response

```json
{
  "type": "image_grid",
  "provider": "recaptcha",
  "prompt": null,
  "grid_rows": 3,
  "grid_cols": 3,
  "cells": [
    {
      "index": 0,
      "x": 270,
      "y": 200,
      "width": 120,
      "height": 120,
      "center_x": 330,
      "center_y": 260,
      "selected": false
    },
    ...
  ],
  "buttons": [
    {
      "name": "verify",
      "x": 500,
      "y": 530,
      "width": 120,
      "height": 30,
      "center_x": 560,
      "center_y": 545
    },
    {
      "name": "skip",
      "x": 270,
      "y": 530,
      "width": 120,
      "height": 30,
      "center_x": 330,
      "center_y": 545
    }
  ],
  "frame_coords": {
    "x": 250,
    "y": 150,
    "width": 400,
    "height": 580
  }
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  "http://localhost:8100/sessions/{session_id}/pages/page-0/captcha/segment?captcha_index=0"
```

---

### Solve CAPTCHA

`POST /sessions/{session_id}/pages/{page_id}/captcha/solve`

Clicks specified grid cells on a CAPTCHA with human-like timing and optionally clicks verify.

#### Query Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `captcha_index` | integer | 0 | Index of captcha to solve |

#### Request Body

```json
{
  "cells": [0, 3, 6, 8],
  "click_delay_min_ms": 200,
  "click_delay_max_ms": 400,
  "then_verify": true
}
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `cells` | array[int] | required | Grid cell indices to click |
| `click_delay_min_ms` | integer | 200 | Min ms between clicks |
| `click_delay_max_ms` | integer | 400 | Max ms between clicks |
| `then_verify` | boolean | true | Click verify button after cells |

#### Response

```json
{
  "status": "ok",
  "clicked": [
    {"cell": 0, "x": 330, "y": 260, "success": true},
    {"cell": 3, "x": 330, "y": 380, "success": true},
    {"cell": 6, "x": 330, "y": 500, "success": true},
    {"cell": 8, "x": 570, "y": 500, "success": true}
  ],
  "verify_clicked": true
}
```

#### Example

```bash
curl -X POST -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"cells": [1, 4, 7], "then_verify": true}' \
  "http://localhost:8100/sessions/{session_id}/pages/page-0/captcha/solve"
```

---

### VNC Cursor Visibility

When viewing the session via VNC, the cursor is visible by default. The built-in web VNC viewer (`/vnc.html?session=...`) automatically enables cursor display.

If using a custom VNC client and the cursor is not visible, ensure your client has "show dot cursor" or "local cursor" enabled. The x11vnc server embeds the cursor image in the video stream.

---

## Profiles

### Export Profile State

`GET /profiles/{profile_id}/state`

Exports cookies, localStorage, and sessionStorage.

#### Response

```json
{
  "profile_id": "user-123",
  "cookies": [
    {
      "name": "session_id",
      "value": "abc123xyz",
      "domain": ".example.com",
      "path": "/",
      "expires": 1704067200,
      "httpOnly": true,
      "secure": true,
      "sameSite": "Lax"
    }
  ],
  "localStorage": [
    {
      "origin": "https://example.com",
      "items": [
        {"key": "theme", "value": "dark"},
        {"key": "language", "value": "en"}
      ]
    }
  ],
  "sessionStorage": [
    {
      "origin": "https://example.com",
      "items": [
        {"key": "temp_data", "value": "..."}
      ]
    }
  ]
}
```

#### Example

```bash
curl -H "X-API-Key: your-api-key" \
  http://localhost:8100/profiles/user-123/state > profile-state.json
```

---

### Import Profile State

`PUT /profiles/{profile_id}/state`

Imports cookies, localStorage, and sessionStorage.

#### Request Body

Same format as export response.

#### Response

```json
{
  "status": "imported",
  "profile_id": "user-123",
  "imported": {
    "cookies": 5,
    "localStorage_origins": 2,
    "sessionStorage_origins": 1
  }
}
```

#### Example

```bash
curl -X PUT \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d @profile-state.json \
  http://localhost:8100/profiles/user-123/state
```

---

### Delete Profile

`DELETE /profiles/{profile_id}`

Deletes profile directory and all data.

#### Response

```json
{
  "status": "deleted",
  "profile_id": "user-123"
}
```

---

## Extensions

### Upload Extension

`POST /extensions`

Uploads a Chrome extension (.zip or .crx file).

#### Request

Multipart form data with `file` field.

#### Response

```json
{
  "extension_id": "ext-abc123",
  "name": "uBlock Origin",
  "version": "1.54.0",
  "description": "An efficient blocker...",
  "manifest_version": 3,
  "permissions": ["storage", "webRequest"],
  "file_size": 12345678
}
```

#### Example

```bash
curl -X POST \
  -H "X-API-Key: your-api-key" \
  -F "file=@ublock-origin.zip" \
  http://localhost:8100/extensions
```

---

### List Extensions

`GET /extensions`

Returns all available extensions.

#### Response

```json
{
  "extensions": [
    {
      "extension_id": "ext-abc123",
      "name": "uBlock Origin",
      "version": "1.54.0",
      "manifest_version": 3
    }
  ],
  "total": 1
}
```

---

### Delete Extension

`DELETE /extensions/{extension_id}`

Deletes extension (removes from storage).

#### Response

```json
{
  "status": "deleted",
  "extension_id": "ext-abc123"
}
```

---

## VNC Remote Viewing

### Web VNC Viewer

`GET /vnc.html?session={session_id}`

Opens a web-based VNC viewer for the session using noVNC.

#### Example

Open in browser:
```
http://localhost:8100/vnc.html?session=550e8400-e29b-41d4-a716-446655440000
```

---

### VNC WebSocket

`WS /sessions/{session_id}/vnc`

WebSocket endpoint for VNC protocol. Connect using any noVNC-compatible client.

#### Connection

```javascript
import RFB from '@novnc/novnc/core/rfb.js';

const rfb = new RFB(
  document.getElementById('screen'),
  'ws://localhost:8100/sessions/550e8400-e29b-41d4-a716-446655440000/vnc'
);

rfb.scaleViewport = true;
rfb.resizeSession = true;
```

**Note:** VNC sessions have no password by default. The browser nodes are isolated in a private Docker network and accessed only through the API proxy.

---

## CDP WebSocket

### Connect to CDP

`WS /sessions/{session_id}/cdp`

WebSocket proxy to Chrome DevTools Protocol.

**Note:** The Browserious API internally manages CDP connections to browser nodes. The CDP URL returned in session responses (`cdp_url`) is for internal use. For external CDP access, use the `/sessions/{id}/cdp` WebSocket endpoint.

#### Connection

```javascript
const ws = new WebSocket('ws://localhost:8100/sessions/{session_id}/cdp');

ws.on('open', () => {
  ws.send(JSON.stringify({
    id: 1,
    method: 'Page.navigate',
    params: {url: 'https://example.com'}
  }));
});

ws.on('message', (data) => {
  const response = JSON.parse(data);
  console.log(response);
});
```

#### Using Puppeteer

```javascript
const puppeteer = require('puppeteer-core');

const browser = await puppeteer.connect({
  browserWSEndpoint: 'ws://localhost:8100/sessions/{session_id}/cdp'
});

const page = await browser.newPage();
await page.goto('https://example.com');
```

#### Using Playwright

```javascript
const { chromium } = require('playwright');

const browser = await chromium.connectOverCDP(
  'ws://localhost:8100/sessions/{session_id}/cdp'
);

const page = await browser.newPage();
await page.goto('https://example.com');
```

---

## Complete Examples

### Example 1: Web Scraping with Proxy

```bash
# 1. Create session with proxy
SESSION=$(curl -X POST http://localhost:8100/sessions \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "profile_id": "scraper-001",
    "proxy": {"server": "http://proxy.example.com:8080"},
    "extensions": ["ublock-ext-id"]
  }' | jq -r '.session_id')

# 2. Block images to speed up scraping
curl -X POST http://localhost:8100/sessions/$SESSION/routes \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"pattern": "**/*.{png,jpg,jpeg,gif}", "action": {"type": "block"}}'

# 3. Navigate to target
curl -X POST http://localhost:8100/sessions/$SESSION/pages/page-0/goto \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com", "wait_until": "networkidle"}'

# 4. Extract data
curl -X POST http://localhost:8100/sessions/$SESSION/pages/page-0/eval \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"script": "return Array.from(document.querySelectorAll(\".item\")).map(el => el.innerText)"}' \
  | jq '.result'

# 5. Cleanup
curl -X DELETE http://localhost:8100/sessions/$SESSION \
  -H "X-API-Key: your-api-key"
```

---

### Example 2: E2E Testing with Mocked API

```python
import requests
import time

API_KEY = "your-api-key"
BASE_URL = "http://localhost:8100"
headers = {"X-API-Key": API_KEY}

session_resp = requests.post(
    f"{BASE_URL}/sessions",
    headers=headers,
    json={"profile_id": "test-user", "timeout": 600}
).json()
session_id = session_resp["session_id"]
page_id = "page-0"

requests.post(
    f"{BASE_URL}/sessions/{session_id}/routes",
    headers=headers,
    json={
        "pattern": "**/api/user",
        "action": {
            "type": "override",
            "status": 200,
            "headers": {"Content-Type": "application/json"},
            "body": '{"id": 123, "name": "Test User", "email": "test@example.com"}'
        }
    }
)

requests.post(
    f"{BASE_URL}/sessions/{session_id}/pages/{page_id}/goto",
    headers=headers,
    json={"url": "https://app.example.com"}
)

requests.post(
    f"{BASE_URL}/sessions/{session_id}/pages/{page_id}/fill",
    headers=headers,
    json={
        "selector": {"strategy": "css", "value": "#username"},
        "value": "testuser"
    }
)

requests.post(
    f"{BASE_URL}/sessions/{session_id}/pages/{page_id}/fill",
    headers=headers,
    json={
        "selector": {"strategy": "css", "value": "#password"},
        "value": "testpass"
    }
)

requests.post(
    f"{BASE_URL}/sessions/{session_id}/pages/{page_id}/click",
    headers=headers,
    json={"selector": {"strategy": "css", "value": "#login-button"}}
)

time.sleep(2)

with open("screenshot.png", "wb") as f:
    resp = requests.get(
        f"{BASE_URL}/sessions/{session_id}/pages/{page_id}/screenshot",
        headers=headers,
        params={"full_page": True}
    )
    f.write(resp.content)

requests.delete(f"{BASE_URL}/sessions/{session_id}", headers=headers)
```

---

### Example 3: Profile Management

```python
import requests
import json

API_KEY = "your-api-key"
BASE_URL = "http://localhost:8100"
headers = {"X-API-Key": API_KEY}

session_resp = requests.post(
    f"{BASE_URL}/sessions",
    headers=headers,
    json={"profile_id": "persistent-user", "timeout": 600}
).json()
session_id = session_resp["session_id"]
page_id = "page-0"

requests.post(
    f"{BASE_URL}/sessions/{session_id}/pages/{page_id}/goto",
    headers=headers,
    json={"url": "https://example.com/login"}
)

requests.post(
    f"{BASE_URL}/sessions/{session_id}/pages/{page_id}/eval",
    headers=headers,
    json={
        "script": """
            localStorage.setItem('auth_token', 'token123');
            document.cookie = 'session=abc123; path=/';
        """
    }
)

requests.delete(f"{BASE_URL}/sessions/{session_id}", headers=headers)

state = requests.get(
    f"{BASE_URL}/profiles/persistent-user/state",
    headers=headers
).json()

with open("profile-backup.json", "w") as f:
    json.dump(state, f, indent=2)

new_session_resp = requests.post(
    f"{BASE_URL}/sessions",
    headers=headers,
    json={"profile_id": "persistent-user", "timeout": 600}
).json()
new_session_id = new_session_resp["session_id"]

result = requests.post(
    f"{BASE_URL}/sessions/{new_session_id}/pages/page-0/eval",
    headers=headers,
    json={"script": "return localStorage.getItem('auth_token')"}
).json()

print(f"Auth token restored: {result['result']}")

requests.delete(f"{BASE_URL}/sessions/{new_session_id}", headers=headers)
```

---

### Example 4: Request Interception and Inspection

```bash
SESSION_ID="your-session-id"
API_KEY="your-api-key"

ROUTE_ID=$(curl -X POST http://localhost:8100/sessions/$SESSION_ID/routes \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "pattern": "**/api/**",
    "action": {"type": "inspect", "capture_body": true}
  }' | jq -r '.route_id')

curl -X POST http://localhost:8100/sessions/$SESSION_ID/pages/page-0/goto \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com"}'

sleep 5

curl -H "X-API-Key: $API_KEY" \
  http://localhost:8100/sessions/$SESSION_ID/routes/$ROUTE_ID/inspect \
  | jq '.requests[] | {method: .method, url: .url, status: .response.status}'
```

---

## Rate Limits

No rate limiting in MVP. For production use, implement at reverse proxy level (nginx, Caddy) or application level.

## Versioning

API versioning via Accept header (future):
```
Accept: application/vnd.browserapi.v1+json
```

Currently: No versioning, breaking changes will bump major version.

## Support

- GitHub Issues: https://github.com/muzhig/browserious/issues
- Documentation: https://github.com/muzhig/browserious/docs
