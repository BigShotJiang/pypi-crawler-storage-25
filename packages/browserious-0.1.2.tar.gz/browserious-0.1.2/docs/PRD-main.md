# Browser API Wrapper - Product Requirements Document

**Version:** 1.0
**Date:** 2025-12-09
**Status:** Draft for Review

## Executive Summary

Building a self-hosted, API-controlled browser-as-a-service (BrowserAPI) that enables programmatic browser automation, web scraping, and testing workflows. The service provides REST API + WebSocket control over Chromium instances with persistent profiles, proxy support, extension loading, request interception, and remote viewing via VNC.

**Primary Use Cases:**
1. Browser automation and E2E testing (primary)
2. Web scraping and data extraction (primary)
3. Remote browser service (secondary)

**MVP Architecture:** One browser per Docker container, manual horizontal scaling, API key authentication.

## Problem Statement

Developers need reliable, scalable browser automation that:
- Works consistently across environments (no "works on my machine")
- Supports advanced features (extensions, proxies, profiles, request interception)
- Provides both programmatic control and visual debugging (API + VNC)
- Scales horizontally for parallel execution
- Offers production-grade reliability

Existing solutions are either:
- Too heavyweight (Selenium Grid)
- Limited functionality (headless-only services)
- Vendor-locked (commercial services)
- Missing critical features (request interception, profile persistence)

## Target Users & Avatars

### Avatar 1: QA Engineer (Emily)
- **Role:** Senior QA Engineer at SaaS company
- **Needs:** Reliable E2E testing infrastructure, parallel test execution, screenshot/trace capture
- **Pain Points:** Flaky tests in CI/CD, slow test execution, debugging failures is hard
- **Usage:** Runs 500+ tests daily, needs 10-20 parallel browsers, uses custom auth profiles

### Avatar 2: Data Engineer (Alex)
- **Role:** Data engineer at market research firm
- **Needs:** Scrape dynamic websites at scale, bypass bot detection, rotate proxies
- **Pain Points:** Sites block headless browsers, need to maintain sessions/cookies, proxy management
- **Usage:** 24/7 scraping jobs, 100+ concurrent sessions, needs profile persistence

### Avatar 3: DevOps/Platform Engineer (Jordan)
- **Role:** Platform engineer building internal tools
- **Needs:** Self-hosted solution, horizontal scaling, production-grade reliability
- **Pain Points:** Vendor lock-in, cost of commercial services, need full control
- **Usage:** Internal platform service for multiple teams, needs monitoring/metrics

## Use Cases & User Stories

### UC-1: Parallel Test Execution
**As** Emily (QA Engineer)
**I want** to run 20 browser sessions in parallel
**So that** my test suite completes in 10 minutes instead of 3 hours

**Acceptance Criteria:**
- Can create 20+ concurrent sessions
- Each session isolated (different profile, no interference)
- Sessions auto-cleanup after test completes
- Can capture screenshots/traces for failed tests

### UC-2: Web Scraping with Proxy Rotation
**As** Alex (Data Engineer)
**I want** to scrape sites using different proxies per session
**So that** I can avoid rate limits and IP bans

**Acceptance Criteria:**
- Configure proxy per session (HTTP/HTTPS/SOCKS5)
- Proxy with authentication supported
- Session maintains same proxy throughout lifecycle
- Can reuse profiles with cookies/localStorage

### UC-3: Request Interception for Testing
**As** Emily (QA Engineer)
**I want** to intercept and mock API responses
**So that** I can test edge cases without backend changes

**Acceptance Criteria:**
- Intercept XHR/Fetch requests by pattern
- Override response body, status, headers
- Block/redirect specific resources (ads, analytics)
- Override media URLs (images, videos)

### UC-4: Visual Debugging
**As** Alex (Data Engineer)
**I want** to watch my scraper running in real-time
**So that** I can debug issues quickly

**Acceptance Criteria:**
- Open browser session in web browser via VNC
- Real-time view with mouse/keyboard control
- VNC session secured with password
- Can disconnect/reconnect without killing session

### UC-5: Profile Management
**As** Alex (Data Engineer)
**I want** to persist browser profiles across sessions
**So that** I can maintain login state and cookies

**Acceptance Criteria:**
- Create session with profile_id
- Profile persists after session closes
- Can export/import profile state (cookies, localStorage)
- Multiple sessions can share same profile (concurrent access)

### UC-6: Extension Support
**As** Emily (QA Engineer)
**I want** to load custom Chrome extensions
**So that** I can test with ad blockers, VPN extensions, etc.

**Acceptance Criteria:**
- Upload extension .zip/.crx via API
- Launch session with specific extensions enabled
- Extensions work in non-headless mode
- Can update/delete extensions

## Key Decisions & Rationale

### Decision 1: One Browser Per Container
**Choice:** Each browser session runs in dedicated Docker container
**Rationale:**
- Better resource isolation (CPU, memory limits)
- Crash in one browser doesn't affect others
- Easier cleanup (kill container = clean state)
- Simpler security model (container isolation)
**Trade-off:** Higher resource usage vs multi-context approach

### Decision 2: Manual Horizontal Scaling
**Choice:** No built-in orchestration; user runs multiple instances manually
**Rationale:**
- Simplest MVP implementation
- Users can choose their orchestration (k8s, docker-compose, systemd)
- Avoids complexity of distributed state management
**Future:** Can add Redis-based session registry later

### Decision 3: Shared Profile Concurrent Access
**Choice:** Allow multiple sessions to use same profile_id simultaneously
**Rationale:**
- Use case: same "logged in" state for parallel scrapers
- Risk of data corruption is acceptable (user can manage profile IDs)
- Simpler than copy-on-write implementation
**Warning:** Document this risk clearly in API docs

### Decision 4: Full CDP Passthrough
**Choice:** Expose Chrome DevTools Protocol directly via WebSocket
**Rationale:**
- Maximum flexibility for advanced users
- Don't need to wrap every CDP command in REST API
- Users can use existing CDP clients (puppeteer, playwright, etc.)
**Implementation:** WebSocket proxy at /sessions/{id}/cdp

### Decision 5: All Selector Strategies
**Choice:** Support CSS, XPath, Playwright locators, and custom JS functions
**Rationale:**
- Different use cases need different strategies
- CSS: simplest, most common
- XPath: powerful for complex DOM navigation
- Playwright locators: best UX (text=, role=, etc.)
- JS functions: ultimate flexibility
**Implementation:** Selector parameter includes strategy type

### Decision 6: Request Interception Required
**Choice:** Build request interception/override into MVP
**Rationale:**
- Critical for both testing (mocking) and scraping (blocking resources)
- Differentiator vs basic browser automation
- Playwright has built-in support (route API)
**Scope:** Intercept, block, redirect, override response

### Decision 7: API Key Authentication
**Choice:** Simple token-based auth with API keys
**Rationale:**
- Good balance of security and simplicity
- Standard pattern (X-API-Key header)
- Easy to implement and test
**Future:** Can add OAuth2/JWT later if needed

### Decision 8: VNC Password Per Session
**Choice:** Each session gets unique VNC password
**Rationale:**
- Better security than shared password
- Still simple enough for MVP
- Return password in session creation response
**Implementation:** Generate random password, pass to x11vnc

## MVP Scope & Features

### Core Features (Must Have)

#### 1. Session Management
- `POST /sessions` - Create browser session with options
- `GET /sessions` - List active sessions
- `GET /sessions/{id}` - Get session details
- `DELETE /sessions/{id}` - Close session (hard close on timeout)
- Session options: profile_id, proxy, extensions, viewport, user_agent, timeout

#### 2. Page Operations
- `POST /sessions/{id}/pages` - Create new tab/page
- `GET /sessions/{id}/pages` - List pages in session
- `POST /sessions/{id}/pages/{pid}/goto` - Navigate to URL
- `POST /sessions/{id}/pages/{pid}/click` - Click element (all selector strategies)
- `POST /sessions/{id}/pages/{pid}/type` - Type text into element
- `POST /sessions/{id}/pages/{pid}/fill` - Fill input field
- `POST /sessions/{id}/pages/{pid}/waitForSelector` - Wait for element
- `POST /sessions/{id}/pages/{pid}/eval` - Execute JavaScript
- `GET /sessions/{id}/pages/{pid}/screenshot` - Capture screenshot
- `GET /sessions/{id}/pages/{pid}/content` - Get HTML content

#### 3. Request Interception
- `POST /sessions/{id}/routes` - Register route intercept pattern
- `GET /sessions/{id}/routes` - List active routes
- `DELETE /sessions/{id}/routes/{rid}` - Remove route
- Route actions: block, redirect, override (response body/headers/status)
- Media override: replace image/video URLs
- XHR inspection: capture and modify fetch/XHR

#### 4. Profile Management
- `GET /profiles/{profile_id}/state` - Export cookies/localStorage
- `PUT /profiles/{profile_id}/state` - Import state
- `DELETE /profiles/{profile_id}` - Delete profile
- Concurrent access supported (shared profile)

#### 5. Extension Management
- `POST /extensions` - Upload extension (.zip/.crx)
- `GET /extensions` - List available extensions
- `DELETE /extensions/{ext_id}` - Delete extension
- Extension specified in session creation by ID

#### 6. CDP WebSocket
- `WS /sessions/{id}/cdp` - WebSocket proxy to CDP endpoint
- Full CDP protocol passthrough
- Allows direct use of puppeteer/playwright

#### 7. VNC Access
- VNC server on port 5900 (per-container)
- noVNC web interface on port 6080
- Unique VNC password per session (returned in session response)
- Share screen with multiple viewers

#### 8. Configuration & Security
- API key authentication (X-API-Key header)
- Environment-based config (profiles dir, extensions dir, max sessions)
- Session timeout with hard close
- Resource limits via Docker (CPU, memory)

### Nice to Have (Post-MVP)

#### 1. Monitoring & Observability
- `/health` endpoint for liveness/readiness
- `/metrics` Prometheus endpoint (session count, resource usage)
- Session event webhooks (created, closed, error)

#### 2. Advanced Features
- Session recording (Playwright trace)
- Network HAR export
- Performance metrics (page load times)
- Screenshot comparison/diffing

#### 3. Scaling & HA
- Redis-based session registry for multi-instance
- Automatic session migration on instance failure
- Load balancing / session affinity

## Out of Scope (for MVP)

### Explicitly Not Included
1. Built-in orchestration (k8s, docker swarm)
2. Multi-tenancy isolation beyond API keys
3. Usage billing/metering
4. Session queuing when max_sessions reached
5. Automatic proxy rotation/pool management
6. Browser version management (use Playwright's)
7. Mobile device emulation (future)
8. Screenshot comparison tools
9. Metrics/monitoring beyond logs
10. Admin UI (CLI/curl only)

## Technical Architecture

### Component Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│  Host Machine                                                     │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  Supervisor (host process manager)                           │ │
│  │  └─ FastAPI Application :8000                               │ │
│  │       ├─ REST API (sessions, pages, routes, extensions)     │ │
│  │       ├─ WebSocket: /sessions/{id}/cdp (CDP proxy)          │ │
│  │       ├─ WebSocket: /sessions/{id}/vnc (VNC proxy)          │ │
│  │       └─ Docker API (container lifecycle)                   │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                          │                                        │
│                          │ Docker API + Network                   │
│                          ▼                                        │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  Docker Network: browserious                                 │ │
│  │                                                              │ │
│  │  ┌─────────────────────┐    ┌─────────────────────┐         │ │
│  │  │  session-abc123     │    │  session-xyz789     │         │ │
│  │  │  (Browser Node)     │    │  (Browser Node)     │         │ │
│  │  │                     │    │                     │         │ │
│  │  │  Xvfb :99           │    │  Xvfb :99           │         │ │
│  │  │  x11vnc :5900       │    │  x11vnc :5900       │         │ │
│  │  │  Chromium           │    │  Chromium           │         │ │
│  │  │  └─ CDP :9222       │    │  └─ CDP :9222       │         │ │
│  │  │                     │    │                     │         │ │
│  │  │  Profile: mounted   │    │  Profile: mounted   │         │ │
│  │  │  Extensions: mounted│    │  Extensions: mounted│         │ │
│  │  └─────────────────────┘    └─────────────────────┘         │ │
│  │                                                              │ │
│  │  (Same ports - addressed by container hostname)              │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  /data/profiles/    ← Shared volume for browser profiles         │
│  /data/extensions/  ← Shared volume for extensions               │
└──────────────────────────────────────────────────────────────────┘
         ▲
         │ API Calls (REST/WebSocket)
         │
    ┌────┴─────┐
    │  Client  │
    └──────────┘
```

### Architecture Notes

**Separation of Concerns (ADR-016):**
- **API Orchestrator:** Runs on host under supervisor, manages Docker containers
- **Browser Nodes:** Minimal containers with Xvfb + Chromium + x11vnc only
- **Network Isolation:** Nodes in private Docker network, only API exposed

**Communication Flow:**
1. Client → API: REST/WebSocket over HTTP(S)
2. API → Node: CDP (browser control) + VNC (visual access)
3. API → Docker: Container lifecycle management

**Key Design Decisions:**
- No port conflicts: Docker network + hostnames (e.g., `session-abc:9222`)
- VNC proxied through API: Single entry point, authenticated
- Profiles/extensions mounted: Shared storage across nodes

### Technology Stack

| Component | Technology | Version | License |
|-----------|-----------|---------|---------|
| Base Image | playwright:v1.49.0-noble | latest | Apache 2.0 |
| Browser | Chromium (via Playwright) | latest | BSD |
| Language | Python | 3.11+ | PSF |
| API Framework | FastAPI | 0.109+ | MIT |
| ASGI Server | Uvicorn | 0.27+ | BSD |
| Browser Control | Playwright | 1.49+ | Apache 2.0 |
| Virtual Display | Xvfb | - | MIT |
| VNC Server | x11vnc | - | GPL-2.0 (server-side) |
| Web VNC | noVNC + websockify | - | MPL-2.0 |
| Process Manager | Supervisor | - | BSD |
| Validation | Pydantic | 2.0+ | MIT |

### File Structure

```
browserious/
├── docs/
│   ├── project-brief.md
│   ├── PRD.md
│   └── API.md                    # API documentation
├── src/
│   ├── __init__.py
│   ├── main.py                   # FastAPI app + lifespan
│   ├── config.py                 # Settings (pydantic-settings)
│   ├── models.py                 # Request/response models
│   ├── auth.py                   # API key authentication
│   ├── browser_manager.py        # Session lifecycle
│   ├── page_operations.py        # Page control endpoints
│   ├── route_manager.py          # Request interception
│   ├── extension_manager.py      # Extension upload/management
│   ├── profile_manager.py        # Profile state import/export
│   ├── cdp_proxy.py              # WebSocket CDP forwarding
│   └── selectors.py              # Selector strategy handling
├── tests/
│   ├── test_sessions.py
│   ├── test_pages.py
│   ├── test_routes.py
│   ├── test_extensions.py
│   └── test_profiles.py
├── Dockerfile
├── docker-compose.yml
├── supervisord.conf
├── requirements.txt
├── requirements-dev.txt          # pytest, black, mypy
├── .gitignore
├── .dockerignore
└── README.md
```

## API Specification

### Authentication

All endpoints require API key authentication:
```
X-API-Key: your-api-key-here
```

Configuration:
```python
API_KEYS = ["key1", "key2"]  # Environment variable: API_KEYS=key1,key2
```

### Session Endpoints

#### POST /sessions
Create new browser session.

**Request:**
```json
{
  "profile_id": "user-123",
  "proxy": {
    "server": "http://proxy.example.com:8080",
    "username": "user",
    "password": "pass"
  },
  "extensions": ["ext-id-1", "ext-id-2"],
  "viewport": {"width": 1920, "height": 1080},
  "user_agent": "Mozilla/5.0...",
  "timeout": 3600
}
```

**Response:**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "cdp_url": "ws://localhost:9222/devtools/browser/abc123",
  "vnc_url": "vnc://localhost:5900",
  "vnc_password": "rX9mK2pL",
  "web_vnc_url": "http://localhost:6080/vnc.html?path=?token=abc123",
  "created_at": "2025-12-09T10:30:00Z",
  "expires_at": "2025-12-09T11:30:00Z"
}
```

#### GET /sessions
List all active sessions.

**Response:**
```json
{
  "sessions": [
    {
      "session_id": "550e8400-e29b-41d4-a716-446655440000",
      "profile_id": "user-123",
      "created_at": "2025-12-09T10:30:00Z",
      "expires_at": "2025-12-09T11:30:00Z",
      "page_count": 3
    }
  ],
  "total": 1
}
```

#### GET /sessions/{session_id}
Get session details.

**Response:**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "profile_id": "user-123",
  "created_at": "2025-12-09T10:30:00Z",
  "expires_at": "2025-12-09T11:30:00Z",
  "pages": [
    {"page_id": "page-0", "url": "https://example.com", "title": "Example"},
    {"page_id": "page-1", "url": "about:blank", "title": ""}
  ],
  "extensions": ["ext-id-1"],
  "proxy": {"server": "http://proxy.example.com:8080"}
}
```

#### DELETE /sessions/{session_id}
Close session (terminates browser immediately).

**Response:**
```json
{"status": "closed", "session_id": "550e8400-e29b-41d4-a716-446655440000"}
```

### Page Endpoints

#### POST /sessions/{session_id}/pages
Create new page/tab.

**Response:**
```json
{"page_id": "page-1", "url": "about:blank"}
```

#### GET /sessions/{session_id}/pages
List pages in session.

**Response:**
```json
{
  "pages": [
    {"page_id": "page-0", "url": "https://example.com", "title": "Example"}
  ]
}
```

#### POST /sessions/{session_id}/pages/{page_id}/goto
Navigate to URL.

**Request:**
```json
{"url": "https://example.com", "wait_until": "networkidle"}
```

**Response:**
```json
{"status": "ok", "url": "https://example.com", "title": "Example Domain"}
```

#### POST /sessions/{session_id}/pages/{page_id}/click
Click element.

**Request:**
```json
{
  "selector": {
    "strategy": "css",
    "value": "#submit-button"
  },
  "timeout": 5000
}
```

Selector strategies:
- `css`: CSS selector
- `xpath`: XPath expression
- `text`: Playwright text selector (e.g., "text=Submit")
- `role`: Playwright role selector (e.g., "role=button[name='Submit']")
- `js`: JavaScript function returning element array

**Response:**
```json
{"status": "ok", "selector": {"strategy": "css", "value": "#submit-button"}}
```

#### POST /sessions/{session_id}/pages/{page_id}/type
Type text into element.

**Request:**
```json
{
  "selector": {"strategy": "css", "value": "#username"},
  "text": "myusername",
  "delay": 50
}
```

#### POST /sessions/{session_id}/pages/{page_id}/fill
Fill input field (faster than type, no events).

**Request:**
```json
{
  "selector": {"strategy": "css", "value": "#email"},
  "value": "user@example.com"
}
```

#### POST /sessions/{session_id}/pages/{page_id}/waitForSelector
Wait for element to appear.

**Request:**
```json
{
  "selector": {"strategy": "css", "value": ".loaded"},
  "state": "visible",
  "timeout": 30000
}
```

#### POST /sessions/{session_id}/pages/{page_id}/eval
Execute JavaScript in page context.

**Request:**
```json
{
  "script": "return document.title",
  "args": []
}
```

**Response:**
```json
{"result": "Example Domain"}
```

#### GET /sessions/{session_id}/pages/{page_id}/screenshot
Capture screenshot (PNG).

**Query params:**
- `full_page=true` - Full page screenshot
- `type=png|jpeg` - Image format

**Response:** Binary image data (Content-Type: image/png)

#### GET /sessions/{session_id}/pages/{page_id}/content
Get page HTML.

**Response:**
```json
{"html": "<!DOCTYPE html><html>..."}
```

### Request Interception Endpoints

#### POST /sessions/{session_id}/routes
Register route intercept pattern.

**Request:**
```json
{
  "pattern": "**/*.{png,jpg,jpeg,gif}",
  "action": {
    "type": "redirect",
    "url": "http://placekitten.com/200/300"
  }
}
```

Action types:
- `block` - Block request (return 404)
- `redirect` - Redirect to different URL
- `override` - Override response body/headers/status
- `inspect` - Log request/response, allow to continue

**Override example:**
```json
{
  "pattern": "**/api/user",
  "action": {
    "type": "override",
    "status": 200,
    "headers": {"Content-Type": "application/json"},
    "body": "{\"name\": \"Test User\"}"
  }
}
```

**Response:**
```json
{"route_id": "route-123", "pattern": "**/*.{png,jpg,jpeg,gif}"}
```

#### GET /sessions/{session_id}/routes
List active routes.

**Response:**
```json
{
  "routes": [
    {
      "route_id": "route-123",
      "pattern": "**/*.{png,jpg,jpeg,gif}",
      "action": {"type": "redirect", "url": "..."}
    }
  ]
}
```

#### DELETE /sessions/{session_id}/routes/{route_id}
Remove route.

#### POST /sessions/{session_id}/routes/{route_id}/inspect
Get captured requests for inspect-type routes.

**Response:**
```json
{
  "requests": [
    {
      "url": "https://api.example.com/data",
      "method": "GET",
      "headers": {...},
      "response": {
        "status": 200,
        "headers": {...},
        "body": "..."
      }
    }
  ]
}
```

### Profile Endpoints

#### GET /profiles/{profile_id}/state
Export profile state (cookies, localStorage, sessionStorage).

**Response:**
```json
{
  "cookies": [
    {
      "name": "session",
      "value": "abc123",
      "domain": ".example.com",
      "path": "/",
      "expires": 1234567890
    }
  ],
  "localStorage": [
    {"origin": "https://example.com", "key": "theme", "value": "dark"}
  ],
  "sessionStorage": [...]
}
```

#### PUT /profiles/{profile_id}/state
Import profile state.

**Request:** Same format as GET response

#### DELETE /profiles/{profile_id}
Delete profile (removes directory).

### Extension Endpoints

#### POST /extensions
Upload extension.

**Request:** multipart/form-data with file field

**Response:**
```json
{
  "extension_id": "ext-abc123",
  "name": "uBlock Origin",
  "version": "1.2.3",
  "manifest": {...}
}
```

#### GET /extensions
List available extensions.

**Response:**
```json
{
  "extensions": [
    {
      "extension_id": "ext-abc123",
      "name": "uBlock Origin",
      "version": "1.2.3"
    }
  ]
}
```

#### DELETE /extensions/{extension_id}
Delete extension.

### CDP WebSocket

#### WS /sessions/{session_id}/cdp
WebSocket proxy to Chrome DevTools Protocol.

Forward all CDP messages bidirectionally. Compatible with puppeteer/playwright.

**Example (using puppeteer):**
```javascript
const browser = await puppeteer.connect({
  browserWSEndpoint: 'ws://localhost:8000/sessions/abc-123/cdp'
});
```

## Data Models

### Session
```python
class Session:
    session_id: str
    profile_id: str | None
    container_id: str
    created_at: datetime
    expires_at: datetime
    proxy: ProxyConfig | None
    extensions: list[str]
    viewport: dict
    user_agent: str | None
    vnc_password: str
```

### Page
```python
class Page:
    page_id: str
    session_id: str
    url: str
    title: str
    playwright_page: playwright.Page
```

### Route
```python
class Route:
    route_id: str
    session_id: str
    pattern: str
    action: RouteAction
```

### RouteAction
```python
class RouteAction:
    type: Literal["block", "redirect", "override", "inspect"]
    url: str | None  # for redirect
    status: int | None  # for override
    headers: dict | None  # for override
    body: str | None  # for override
```

## Security & Privacy

### Threat Model

**Threats:**
1. Unauthorized API access
2. Session hijacking (VNC)
3. Container escape
4. Resource exhaustion (DoS)
5. Malicious extensions
6. Data leakage between sessions

**Mitigations:**

1. **API Authentication:** API key required for all endpoints
2. **VNC Security:** Unique password per session, password in response only
3. **Container Isolation:** Docker provides baseline isolation, can add seccomp/AppArmor
4. **Resource Limits:** Docker CPU/memory limits per container
5. **Extension Vetting:** User responsibility (no automatic vetting in MVP)
6. **Profile Isolation:** Filesystem permissions (uid/gid), profiles in separate dirs

### Privacy Considerations

- **Profile Data:** Contains cookies, localStorage, cache - sensitive user data
- **VNC Recordings:** If VNC session is recorded, contains visual PII
- **Request Logs:** May contain auth tokens, API keys in headers

**Best Practices:**
- Encrypt profile storage at rest (disk encryption)
- Rotate API keys regularly
- Log sanitization (redact auth headers)
- Secure VNC with strong passwords
- Network isolation (private network for containers)

## Open Questions & Risks

### Open Questions

1. **Q:** How to handle container lifecycle in production?
   **A:** TBD - depends on deployment (docker-compose, k8s, systemd)

2. **Q:** Should profiles be backed up automatically?
   **A:** Out of scope for MVP, user responsibility

3. **Q:** How to handle browser crashes?
   **A:** Session marked as failed, container cleaned up, client retries

4. **Q:** Maximum concurrent sessions per host?
   **A:** Depends on hardware; recommend 10-20 per 8-core/16GB host

5. **Q:** Should we support Firefox in addition to Chromium?
   **A:** Not in MVP, Playwright supports it but adds complexity

### Risks & Mitigation

| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
| Shared profile corruption | Medium | Medium | Document risk, recommend profile-per-session for critical use |
| VNC password brute force | High | Low | Rate limiting, strong password generation |
| Resource exhaustion (memory leak) | High | Medium | Docker memory limits, session timeouts, monitoring |
| CDP security (RCE via eval) | High | Low | Document risk, recommend input validation |
| Extension malware | High | Low | User responsibility, no auto-install from store |
| Container escape | Critical | Very Low | Keep Docker updated, use seccomp profiles |

## Success Metrics

### MVP Launch Criteria
- [ ] All core endpoints functional (sessions, pages, routes, profiles, extensions)
- [ ] API key authentication working
- [ ] VNC access with per-session passwords
- [ ] CDP WebSocket proxy functional
- [ ] Request interception working (block, redirect, override, inspect)
- [ ] Extension upload and loading working
- [ ] All selector strategies implemented (CSS, XPath, Playwright, JS)
- [ ] Docker image builds successfully
- [ ] docker-compose.yml starts service
- [ ] Basic test coverage (>70% critical paths)
- [ ] API documentation complete
- [ ] README with quick start guide

### Success Metrics (Post-Launch)
- **Adoption:** 5+ active users within first month
- **Reliability:** <1% session creation failure rate
- **Performance:** Session creation <5 seconds
- **Stability:** Service uptime >99%
- **Usage:** Average 50+ sessions/day per deployment

## Implementation Plan / Task List

### Phase 1: Foundation (Core Infrastructure)
- [ ] Project setup (Poetry/pip, mypy, black, pytest)
- [ ] Docker base image with Xvfb, x11vnc, noVNC, supervisor
- [ ] supervisord.conf with all services
- [ ] FastAPI skeleton with lifespan
- [ ] Config management (pydantic-settings)
- [ ] API key authentication middleware
- [ ] Dockerfile and docker-compose.yml

### Phase 2: Session Management
- [ ] BrowserManager class (create, close, get session)
- [ ] Playwright integration (launch persistent context)
- [ ] Session model (Pydantic models)
- [ ] POST /sessions endpoint (basic, no extensions yet)
- [ ] GET /sessions endpoint
- [ ] GET /sessions/{id} endpoint
- [ ] DELETE /sessions/{id} endpoint
- [ ] Session timeout handling (background task)
- [ ] Proxy configuration support
- [ ] Viewport and user agent configuration

### Phase 3: Page Operations
- [ ] Page model and manager
- [ ] POST /sessions/{id}/pages (new tab)
- [ ] GET /sessions/{id}/pages (list)
- [ ] POST /pages/{id}/goto
- [ ] Selector strategy abstraction (CSS, XPath, Playwright, JS)
- [ ] POST /pages/{id}/click
- [ ] POST /pages/{id}/type
- [ ] POST /pages/{id}/fill
- [ ] POST /pages/{id}/waitForSelector
- [ ] POST /pages/{id}/eval (JavaScript execution)
- [ ] GET /pages/{id}/screenshot
- [ ] GET /pages/{id}/content (HTML)

### Phase 4: Request Interception
- [ ] RouteManager class
- [ ] Playwright route handler integration
- [ ] POST /sessions/{id}/routes (register route)
- [ ] GET /sessions/{id}/routes (list)
- [ ] DELETE /sessions/{id}/routes/{rid}
- [ ] Block action
- [ ] Redirect action
- [ ] Override action (status, headers, body)
- [ ] Inspect action (capture requests)
- [ ] POST /routes/{id}/inspect (get captured)

### Phase 5: Extensions
- [ ] Extension upload endpoint (POST /extensions)
- [ ] Extension storage (unpack .zip/.crx)
- [ ] Extension metadata parsing (manifest.json)
- [ ] GET /extensions (list)
- [ ] DELETE /extensions/{id}
- [ ] Session creation with extensions
- [ ] Extension loading in Playwright

### Phase 6: Profiles
- [ ] Profile manager class
- [ ] GET /profiles/{id}/state (export)
- [ ] PUT /profiles/{id}/state (import)
- [ ] DELETE /profiles/{id}
- [ ] Concurrent profile access support
- [ ] Profile directory management

### Phase 7: VNC & Remote Access
- [ ] VNC password generation
- [ ] x11vnc with password parameter
- [ ] noVNC token generation
- [ ] VNC URL in session response
- [ ] Test VNC access via web browser

### Phase 8: CDP WebSocket
- [ ] WebSocket endpoint at /sessions/{id}/cdp
- [ ] Get CDP endpoint from Playwright browser
- [ ] Bidirectional WebSocket proxy
- [ ] Test with puppeteer/playwright client

### Phase 9: Testing & Documentation
- [ ] Unit tests (models, selectors, route manager)
- [ ] Integration tests (API endpoints)
- [ ] E2E tests (full workflow)
- [ ] API documentation (OpenAPI/Swagger)
- [ ] README.md (quick start, examples)
- [ ] docs/API.md (detailed API reference)
- [ ] Example code (Python, JavaScript)

### Phase 10: Refinement & Deployment
- [ ] Error handling (consistent error responses)
- [ ] Input validation (all endpoints)
- [ ] Logging (structured logs)
- [ ] Docker image optimization (layer caching)
- [ ] Security audit (dependency scan, dockerfile lint)
- [ ] Performance testing (load test 20 concurrent sessions)
- [ ] Deployment guide (docker-compose, systemd)
- [ ] Production checklist (security, backups, monitoring)

## Appendix

### Glossary
- **CDP:** Chrome DevTools Protocol - remote debugging protocol for Chromium
- **VNC:** Virtual Network Computing - remote desktop protocol
- **noVNC:** HTML5 VNC client (runs in browser)
- **Persistent Context:** Playwright feature to save browser profile between launches
- **Route:** Request interception pattern in Playwright
- **Extension:** Chrome/Chromium browser extension (.crx file)

### References
- Playwright API: https://playwright.dev/python/docs/api/class-playwright
- Chrome DevTools Protocol: https://chromedevtools.github.io/devtools-protocol/
- noVNC Documentation: https://github.com/novnc/noVNC
- FastAPI Documentation: https://fastapi.tiangolo.com/
- x11vnc Documentation: https://github.com/LibVNC/x11vnc

### Version History
- **v1.0** (2025-12-09) - Initial PRD based on project brief and stakeholder interviews
