# Task 028: Consistent Error Handling

## Description
Implement consistent error handling across all endpoints with proper error codes and messages.

## Acceptance Criteria
- [ ] All errors follow consistent format
- [ ] HTTP status codes used correctly
- [ ] Error codes defined for common errors
- [ ] Validation errors properly formatted
- [ ] Errors don't leak sensitive information
- [ ] Error responses match API specification

## Implementation

### Global Exception Handler
File: `src/main.py` (add exception handlers)

```python
from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "detail": exc.detail,
            "error_code": getattr(exc, "error_code", "HTTP_ERROR"),
        }
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "detail": "Validation error",
            "error_code": "VALIDATION_ERROR",
            "errors": exc.errors(),
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "error_code": "INTERNAL_ERROR",
        }
    )
```

### Custom Exception Classes
File: `src/exceptions.py` (create)

```python
class BrowserAPIException(HTTPException):
    def __init__(self, status_code: int, detail: str, error_code: str):
        super().__init__(status_code=status_code, detail=detail)
        self.error_code = error_code

class SessionNotFoundError(BrowserAPIException):
    def __init__(self, session_id: str):
        super().__init__(
            status_code=404,
            detail=f"Session not found: {session_id}",
            error_code="SESSION_NOT_FOUND"
        )

class SessionLimitReachedError(BrowserAPIException):
    def __init__(self):
        super().__init__(
            status_code=409,
            detail="Maximum concurrent sessions reached",
            error_code="SESSION_LIMIT_REACHED"
        )

class PageNotFoundError(BrowserAPIException):
    def __init__(self, page_id: str):
        super().__init__(
            status_code=404,
            detail=f"Page not found: {page_id}",
            error_code="PAGE_NOT_FOUND"
        )

class BrowserTimeoutError(BrowserAPIException):
    def __init__(self, operation: str):
        super().__init__(
            status_code=504,
            detail=f"Browser operation timed out: {operation}",
            error_code="BROWSER_TIMEOUT"
        )
```

### Error Codes Enum
File: `src/models.py` (add)

```python
from enum import Enum

class ErrorCode(str, Enum):
    INVALID_REQUEST = "INVALID_REQUEST"
    UNAUTHORIZED = "UNAUTHORIZED"
    SESSION_NOT_FOUND = "SESSION_NOT_FOUND"
    PAGE_NOT_FOUND = "PAGE_NOT_FOUND"
    SESSION_LIMIT_REACHED = "SESSION_LIMIT_REACHED"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    BROWSER_TIMEOUT = "BROWSER_TIMEOUT"
```

### Update Endpoints
Replace all `HTTPException` with custom exceptions:

```python
# Before
if not session:
    raise HTTPException(404, detail="Session not found")

# After
if not session:
    raise SessionNotFoundError(session_id)
```

### Wrap Browser Operations
Add timeout handling for browser operations:

```python
import asyncio

async def safe_browser_operation(operation, timeout_ms: int = 30000):
    try:
        return await asyncio.wait_for(operation, timeout=timeout_ms / 1000)
    except asyncio.TimeoutError:
        raise BrowserTimeoutError(operation.__name__)
    except Exception as e:
        logger.error(f"Browser operation failed: {e}")
        raise
```

## References
- [API: Error Responses](../docs/API.md#error-responses)
- [PRD: Phase 10 - Error Handling](../docs/PRD.md#phase-10-refinement--deployment)
- [SECURITY: Data Protection](../docs/SECURITY.md#data-protection)

## Testing
- [ ] Test each error type
- [ ] Test error response format
- [ ] Test validation errors
- [ ] Test unhandled exceptions (don't leak stack traces)
- [ ] Test browser timeout

File: `tests/test_error_handling.py`

## Security Note
- Never expose internal paths or stack traces
- Sanitize error messages (no sensitive data)
- Log full details internally, return generic message
