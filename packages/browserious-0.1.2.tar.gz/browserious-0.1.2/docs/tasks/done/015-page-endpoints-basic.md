# Task 015: Page Endpoints - Create and List

## Description
Implement page creation and listing endpoints.

## Acceptance Criteria
- [ ] POST `/sessions/{id}/pages` creates new page/tab
- [ ] GET `/sessions/{id}/pages` lists all pages
- [ ] Both require API key authentication
- [ ] Returns 404 if session not found
- [ ] Page IDs are consistent (page-0, page-1, etc.)

## Implementation
File: `src/main.py` (add endpoints)

### POST /sessions/{id}/pages
```python
@app.post("/sessions/{session_id}/pages", dependencies=[Depends(verify_api_key)])
async def create_page(session_id: str, req: PageCreate | None = None):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await session.context.new_page()

    if req and req.url:
        await page.goto(req.url)

    page_id = f"page-{len(session.context.pages) - 1}"

    return {
        "page_id": page_id,
        "url": page.url,
        "title": await page.title() if req and req.url else "",
    }
```

### GET /sessions/{id}/pages
```python
@app.get("/sessions/{session_id}/pages", dependencies=[Depends(verify_api_key)])
async def list_pages(session_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    pages = [
        {
            "page_id": f"page-{i}",
            "url": page.url,
            "title": await page.title(),
        }
        for i, page in enumerate(session.context.pages)
    ]

    return {"pages": pages}
```

## Helper Function
Add helper to get page by ID:
```python
async def get_page_by_id(session: BrowserSession, page_id: str) -> Page:
    try:
        idx = int(page_id.split("-")[1])
        return session.context.pages[idx]
    except (IndexError, ValueError):
        raise HTTPException(404, detail="Page not found")
```

## Models
File: `src/models.py` (add)

```python
class PageCreate(BaseModel):
    url: str | None = None

class PageInfo(BaseModel):
    page_id: str
    url: str
    title: str
```

## References
- [API: POST /sessions/{id}/pages](../docs/API.md#create-page)
- [API: GET /sessions/{id}/pages](../docs/API.md#list-pages)

## Testing
- [ ] Test create page without URL (about:blank)
- [ ] Test create page with URL
- [ ] Test list pages (empty session)
- [ ] Test list pages (multiple pages)
- [ ] Test session not found (404)

File: `tests/test_pages.py`
