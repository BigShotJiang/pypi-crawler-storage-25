# Task 004: API Key Authentication Middleware

## Description
Implement API key authentication middleware for FastAPI.

## Acceptance Criteria
- [ ] `src/auth.py` implements authentication
- [ ] Validates `X-API-Key` header
- [ ] Returns 401 if missing or invalid
- [ ] Works as FastAPI dependency
- [ ] Supports multiple API keys (from config)
- [ ] No secrets logged

## Implementation
File: `src/auth.py`

Create:
1. `verify_api_key()` dependency function
2. Returns 401 with `{"detail": "Invalid or missing API key"}`
3. Checks against `settings.api_keys`
4. Constant-time comparison to prevent timing attacks

## Usage Pattern
```python
from src.auth import verify_api_key

@app.get("/sessions", dependencies=[Depends(verify_api_key)])
async def list_sessions():
    ...
```

## References
- [ADR-007: API Key Authentication](../docs/ADR.md#adr-007-api-key-authentication-for-mvp)
- [API: Authentication](../docs/API.md#authentication)
- [SECURITY: API Security](../docs/SECURITY.md#api-security)

## Security Requirements
- Use `secrets.compare_digest()` for comparison (timing-attack safe)
- Never log API key values
- Return generic error (don't leak which keys exist)

## Testing
- [ ] Test with valid API key
- [ ] Test with invalid API key (401)
- [ ] Test with missing header (401)
- [ ] Test with multiple valid keys
- [ ] Test timing attack resistance (same time for valid/invalid)

File: `tests/test_auth.py`
