# Task 007: Supervisor Configuration

## Description
Create supervisord.conf to manage Xvfb, x11vnc, noVNC, and FastAPI processes.

## Acceptance Criteria
- [ ] `supervisord.conf` created
- [ ] Configures 4 programs: xvfb, x11vnc, novnc, api
- [ ] Correct startup order (priority)
- [ ] Auto-restart enabled
- [ ] Logs to stdout (for Docker)
- [ ] Environment variables passed

## Implementation
File: `supervisord.conf`

Programs in priority order:
1. **xvfb** (priority 100) - Virtual display
2. **x11vnc** (priority 200) - VNC server (depends on xvfb)
3. **novnc** (priority 300) - Web VNC client
4. **api** (priority 400) - FastAPI application

## Configuration
```ini
[supervisord]
nodaemon=true
user=root
logfile=/var/log/supervisor/supervisord.log
pidfile=/var/run/supervisord.pid
childlogdir=/var/log/supervisor

[program:xvfb]
command=Xvfb :99 -screen 0 %(ENV_RESOLUTION)s -ac
autorestart=true
priority=100
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
stderr_logfile=/dev/stderr
stderr_logfile_maxbytes=0

[program:x11vnc]
command=x11vnc -display :99 -forever -shared -rfbport 5900 -xkb
autorestart=true
priority=200
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
stderr_logfile=/dev/stderr
stderr_logfile_maxbytes=0

[program:novnc]
command=websockify --web=/usr/share/novnc/ 6080 localhost:5900
autorestart=true
priority=300
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
stderr_logfile=/dev/stderr
stderr_logfile_maxbytes=0

[program:api]
command=python -m uvicorn src.main:app --host 0.0.0.0 --port 8000
directory=/app
environment=DISPLAY=":99"
autorestart=true
priority=400
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
stderr_logfile=/dev/stderr
stderr_logfile_maxbytes=0
```

## Update Dockerfile
Add to Dockerfile:
```dockerfile
COPY supervisord.conf /etc/supervisor/conf.d/supervisord.conf
CMD ["/usr/bin/supervisord", "-c", "/etc/supervisor/conf.d/supervisord.conf"]
```

## References
- [Project Brief: supervisord.conf](../docs/project-brief.md#supervisordconf)
- [ADR-012: Supervisor Process Management](../docs/ADR.md#adr-012-docker--supervisor-process-management)

## Testing
- [ ] Build Docker image
- [ ] Run container: `docker run -p 8000:8000 browserious`
- [ ] Verify all 4 processes start
- [ ] Check logs show all services running
- [ ] Access health endpoint: `curl localhost:8000/health`

## Notes
- VNC password will be added in later task
- Initially x11vnc runs without password (will add `-passwd` flag later)
