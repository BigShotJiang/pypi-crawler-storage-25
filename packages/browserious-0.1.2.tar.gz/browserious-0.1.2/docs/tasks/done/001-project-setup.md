# Task 001: Project Setup and Dependencies

## Description
Set up the Python project structure with all required dependencies and development tools.

## Acceptance Criteria
- [ ] `requirements.txt` created with production dependencies
- [ ] `requirements-dev.txt` created with development dependencies
- [ ] `src/` directory structure created
- [ ] `tests/` directory structure created
- [ ] `src/__init__.py` exists
- [ ] All dependencies installable without errors
- [ ] Playwright browsers installable

## Dependencies
```
requirements.txt:
- fastapi>=0.109.0
- uvicorn[standard]>=0.27.0
- playwright>=1.49.0
- pydantic>=2.0.0
- pydantic-settings>=2.0.0
- python-multipart>=0.0.6

requirements-dev.txt:
- pytest>=7.4.0
- pytest-asyncio>=0.21.0
- black>=23.0.0
- mypy>=1.5.0
- httpx>=0.24.0  # for testing FastAPI
```

## File Structure to Create
```
src/
├── __init__.py
├── main.py (stub)
├── config.py (stub)
├── models.py (stub)
└── auth.py (stub)

tests/
├── __init__.py
├── conftest.py
└── test_basic.py (sanity test)
```

## References
- [PRD: Phase 1 - Foundation](../docs/PRD.md#phase-1-foundation-core-infrastructure)
- [CLAUDE.md: Development Requirements](../CLAUDE.md#-development-requirements)

## Implementation Notes
- Pin exact versions for reproducibility
- Use Python 3.11+ features (type hints with `|` syntax)
- Add `.python-version` file with `3.11`

## Testing
- Run `pip install -r requirements.txt`
- Run `pip install -r requirements-dev.txt`
- Run `playwright install chromium`
- Run `pytest` (should have 1 passing sanity test)
