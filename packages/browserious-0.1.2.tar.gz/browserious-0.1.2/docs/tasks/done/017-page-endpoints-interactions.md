# Task 017: Page Endpoints - Click, Type, Fill

## Description
Implement page interaction endpoints: click, type, and fill.

## Acceptance Criteria
- [ ] POST `/sessions/{id}/pages/{pid}/click` implemented
- [ ] POST `/sessions/{id}/pages/{pid}/type` implemented
- [ ] POST `/sessions/{id}/pages/{pid}/fill` implemented
- [ ] All use selector strategy abstraction
- [ ] Support timeout and optional parameters
- [ ] Return consistent response format

## Implementation
File: `src/main.py` (add endpoints)

### Click
```python
@app.post("/sessions/{session_id}/pages/{page_id}/click", dependencies=[Depends(verify_api_key)])
async def page_click(session_id: str, page_id: str, req: ClickRequest):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)
    locator = await SelectorStrategy.locate(page, req.selector)

    await locator.click(
        timeout=req.timeout,
        force=req.force,
    )

    return {"status": "ok", "selector": req.selector.model_dump()}
```

### Type
```python
@app.post("/sessions/{session_id}/pages/{page_id}/type", dependencies=[Depends(verify_api_key)])
async def page_type(session_id: str, page_id: str, req: TypeRequest):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)
    locator = await SelectorStrategy.locate(page, req.selector)

    if req.clear:
        await locator.clear()

    await locator.press_sequentially(req.text, delay=req.delay)

    return {"status": "ok", "text": req.text}
```

### Fill
```python
@app.post("/sessions/{session_id}/pages/{page_id}/fill", dependencies=[Depends(verify_api_key)])
async def page_fill(session_id: str, page_id: str, req: FillRequest):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)
    locator = await SelectorStrategy.locate(page, req.selector)

    await locator.fill(req.value, timeout=req.timeout)

    return {"status": "ok", "value": req.value}
```

## Models
File: `src/models.py` (add)

```python
class ClickRequest(BaseModel):
    selector: Selector
    timeout: int = 5000
    force: bool = False

class TypeRequest(BaseModel):
    selector: Selector
    text: str
    delay: int = 0  # milliseconds between keystrokes
    clear: bool = False

class FillRequest(BaseModel):
    selector: Selector
    value: str
    timeout: int = 5000
```

## References
- [API: Click Element](../docs/API.md#click-element)
- [API: Type Text](../docs/API.md#type-text)
- [API: Fill Input](../docs/API.md#fill-input)

## Testing
- [ ] Test click with CSS selector
- [ ] Test click with XPath selector
- [ ] Test type with delay
- [ ] Test type with clear=true
- [ ] Test fill input
- [ ] Test timeout on non-existent element
- [ ] Test all selector strategies

File: `tests/test_page_interactions.py`
