# Task 014: Selector Strategy Abstraction

## Description
Implement selector strategy handler supporting CSS, XPath, Playwright locators, and JS functions.

## Acceptance Criteria
- [ ] `src/selectors.py` created
- [ ] Supports 5 selector strategies: css, xpath, text, role, js
- [ ] Returns Playwright Locator for all strategies
- [ ] Validates selector format
- [ ] Raises clear errors for invalid selectors

## Implementation
File: `src/selectors.py`

```python
from playwright.async_api import Page, Locator

class SelectorStrategy:
    @staticmethod
    async def locate(page: Page, selector: Selector) -> Locator:
        match selector.strategy:
            case "css":
                return page.locator(selector.value)
            case "xpath":
                return page.locator(f"xpath={selector.value}")
            case "text":
                return page.locator(selector.value)  # e.g., "text=Submit"
            case "role":
                return page.locator(selector.value)  # e.g., "role=button[name='Submit']"
            case "js":
                # Execute JS function, return first element
                # For multiple elements, use page.locator with custom selector
                raise NotImplementedError("JS selector strategy")
            case _:
                raise ValueError(f"Unknown selector strategy: {selector.strategy}")
```

## Selector Model
File: `src/models.py` (add)

```python
class Selector(BaseModel):
    strategy: Literal["css", "xpath", "text", "role", "js"]
    value: str

    @field_validator('value')
    def validate_value(cls, v, info):
        if not v or not v.strip():
            raise ValueError("Selector value cannot be empty")
        return v
```

## References
- [ADR-005: All Selector Strategies](../docs/ADR.md#adr-005-all-selector-strategies)
- [API: Selector Strategies](../docs/API.md#selector-strategies)
- [PRD: Selector Strategy Abstraction](../docs/PRD.md#phase-3-page-operations)

## Testing
- [ ] Test CSS selector
- [ ] Test XPath selector
- [ ] Test Playwright text selector
- [ ] Test Playwright role selector
- [ ] Test JS selector (if implemented)
- [ ] Test invalid strategy (error)
- [ ] Test empty value (validation error)

File: `tests/test_selectors.py`

## Notes
- JS selector strategy is complex, may defer to post-MVP
- For MVP, focus on css, xpath, text, role
