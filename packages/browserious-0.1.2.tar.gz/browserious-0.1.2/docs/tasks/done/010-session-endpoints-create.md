# Task 010: Session Endpoints - POST /sessions

## Description
Implement session creation endpoint with full configuration support.

## Acceptance Criteria
- [ ] POST `/sessions` endpoint implemented
- [ ] Accepts SessionCreate request body
- [ ] Returns SessionResponse
- [ ] Integrates with BrowserManager
- [ ] Validates max_sessions limit
- [ ] Calculates expires_at timestamp
- [ ] Requires API key authentication
- [ ] Returns 409 if max sessions reached

## Implementation
File: `src/main.py` (add endpoint)

```python
@app.post("/sessions", response_model=SessionResponse, dependencies=[Depends(verify_api_key)])
async def create_session(req: SessionCreate):
    # Check max sessions
    if len(manager.sessions) >= settings.max_sessions:
        raise HTTPException(409, detail="Maximum concurrent sessions reached")

    # Create session via manager
    session = await manager.create_session(
        profile_id=req.profile_id,
        proxy=req.proxy.model_dump() if req.proxy else None,
        viewport=req.viewport,
        user_agent=req.user_agent,
        timeout=req.timeout,
    )

    # Return response
    return SessionResponse(
        session_id=session.session_id,
        profile_id=session.profile_id,
        cdp_url=f"ws://localhost:9222/devtools/browser/{session.session_id}",
        vnc_url="vnc://localhost:5900",
        vnc_password=session.vnc_password or "",
        web_vnc_url=f"http://localhost:6080/vnc.html?autoconnect=true",
        created_at=session.created_at.isoformat(),
        expires_at=session.expires_at.isoformat(),
    )
```

## Update Lifespan
Initialize manager in lifespan:
```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    await manager.start()
    yield
    # Cleanup all sessions
    for session_id in list(manager.sessions.keys()):
        await manager.close_session(session_id)
```

## References
- [API: POST /sessions](../docs/API.md#create-session)
- [PRD: Session Management](../docs/PRD.md#1-session-management)

## Testing
- [ ] Test session creation with minimal config
- [ ] Test session creation with full config (proxy, viewport, etc.)
- [ ] Test max_sessions limit (409 error)
- [ ] Test authentication required
- [ ] Test response format matches spec
- [ ] Test session_id is UUID
- [ ] Test expires_at = created_at + timeout

File: `tests/test_sessions.py`
