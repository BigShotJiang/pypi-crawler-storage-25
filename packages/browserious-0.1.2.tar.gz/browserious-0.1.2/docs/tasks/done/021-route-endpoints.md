# Task 021: Route Endpoints - CRUD Operations

## Description
Implement route endpoints for creating, listing, and deleting request interception rules.

## Acceptance Criteria
- [ ] POST `/sessions/{id}/routes` creates route
- [ ] GET `/sessions/{id}/routes` lists routes
- [ ] DELETE `/sessions/{id}/routes/{rid}` deletes route
- [ ] GET `/sessions/{id}/routes/{rid}/inspect` returns captured requests
- [ ] All actions supported: block, redirect, override, inspect

## Implementation
File: `src/main.py` (add endpoints)

### POST /sessions/{id}/routes
```python
@app.post("/sessions/{session_id}/routes", dependencies=[Depends(verify_api_key)])
async def create_route(session_id: str, req: RouteCreate):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    route_id = await session.route_manager.register_route(
        session.context,
        req.pattern,
        req.action,
    )

    return {
        "route_id": route_id,
        "pattern": req.pattern,
        "action": req.action.model_dump(),
    }
```

### GET /sessions/{id}/routes
```python
@app.get("/sessions/{session_id}/routes", dependencies=[Depends(verify_api_key)])
async def list_routes(session_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    routes = [
        {
            "route_id": r.route_id,
            "pattern": r.pattern,
            "action": r.action,
        }
        for r in session.route_manager.list_routes()
    ]

    return {"routes": routes}
```

### DELETE /sessions/{id}/routes/{rid}
```python
@app.delete("/sessions/{session_id}/routes/{route_id}", dependencies=[Depends(verify_api_key)])
async def delete_route(session_id: str, route_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    await session.route_manager.unregister_route(session.context, route_id)

    return {"status": "deleted", "route_id": route_id}
```

### GET /sessions/{id}/routes/{rid}/inspect
```python
@app.get("/sessions/{session_id}/routes/{route_id}/inspect", dependencies=[Depends(verify_api_key)])
async def get_captured_requests(session_id: str, route_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    route_info = session.route_manager.get_route(route_id)
    if not route_info:
        raise HTTPException(404, detail="Route not found")

    return {
        "route_id": route_id,
        "pattern": route_info.pattern,
        "requests": route_info.captured_requests,
        "total": len(route_info.captured_requests),
    }
```

## Models
File: `src/models.py` (add)

```python
class RouteAction(BaseModel):
    type: Literal["block", "redirect", "override", "inspect"]
    url: str | None = None  # for redirect
    status: int | None = None  # for override
    headers: dict | None = None  # for override
    body: str | None = None  # for override
    capture_body: bool = False  # for inspect

class RouteCreate(BaseModel):
    pattern: str
    action: RouteAction

    @field_validator('pattern')
    def validate_pattern(cls, v):
        if not v or not v.strip():
            raise ValueError("Pattern cannot be empty")
        return v
```

## References
- [API: Request Interception](../docs/API.md#request-interception)
- [PRD: Route Endpoints](../docs/PRD.md#3-request-interception)

## Testing
- [ ] Test create block route
- [ ] Test create redirect route
- [ ] Test create override route
- [ ] Test create inspect route
- [ ] Test list routes
- [ ] Test delete route
- [ ] Test get captured requests
- [ ] Test route not found (404)

File: `tests/test_routes.py`
