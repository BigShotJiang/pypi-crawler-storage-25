# Task 031: Final Documentation Updates

## Description
Update all documentation to reflect implemented features and current state.

## Acceptance Criteria
- [ ] README updated with installation instructions
- [ ] API.md reflects actual endpoints
- [ ] Contributing guidelines added
- [ ] Deployment guide created
- [ ] All code examples tested and working
- [ ] OpenAPI docs accurate

## Files to Update

### README.md
- [ ] Update quick start with actual commands
- [ ] Update configuration section
- [ ] Add troubleshooting section (common issues found during testing)
- [ ] Update roadmap (mark MVP items as done)
- [ ] Add real examples (tested)

### docs/API.md
- [ ] Verify all endpoints documented
- [ ] Update error codes (actual implementation)
- [ ] Add rate limiting info (if implemented)
- [ ] Update examples with tested code

### CONTRIBUTING.md (create)
```markdown
# Contributing to Browserious

## Development Setup

1. Clone repository
2. Install dependencies: `pip install -r requirements-dev.txt`
3. Install Playwright browsers: `playwright install chromium`
4. Run tests: `pytest`

## Code Style

- Follow PEP 8
- Use type hints
- No comments (code should be self-explanatory)
- No inline imports

## Testing

- Write tests for new features
- Maintain >70% coverage
- Run `pytest` before committing

## Pull Requests

1. Create feature branch
2. Make changes with tests
3. Update documentation
4. Open PR with description
```

### docs/DEPLOYMENT.md (create)
```markdown
# Deployment Guide

## Production Checklist

- [ ] Generate strong API keys
- [ ] Enable HTTPS (nginx/Caddy)
- [ ] Configure firewall
- [ ] Set resource limits
- [ ] Enable logging
- [ ] Set up monitoring
- [ ] Configure backups

## Docker Deployment

### Single Server

\`\`\`bash
# Clone repository
git clone https://github.com/muzhig/browserious.git
cd browserious

# Configure
cp .env.example .env
# Edit .env (set API_KEYS)

# Start
docker-compose up -d

# Verify
curl -H "X-API-Key: $API_KEYS" http://localhost:8000/health
\`\`\`

### Multiple Instances

Use docker-compose with different ports and nginx load balancer.

## Monitoring

Set up external monitoring:
- Uptime: UptimeRobot, Pingdom
- Logs: ELK stack, Loki
- Metrics: Prometheus + Grafana

## Backup Strategy

Backup `/data/profiles` and `/data/extensions` regularly.

## Troubleshooting

See README.md troubleshooting section.
```

### Update OpenAPI
Ensure FastAPI generates accurate OpenAPI:

File: `src/main.py`
```python
app = FastAPI(
    title="Browserious API",
    description="Self-hosted browser-as-a-service for automation, testing, and scraping",
    version="1.0.0",
    contact={
        "name": "Browserious",
        "url": "https://github.com/muzhig/browserious",
    },
    license_info={
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT",
    },
)
```

## Verification

- [ ] All links work (no 404s)
- [ ] Code examples copy-paste and run
- [ ] Screenshots up-to-date (if any)
- [ ] Version numbers consistent

## Testing
- [ ] Follow README quick start from scratch
- [ ] Run all code examples
- [ ] Verify OpenAPI docs at `/docs`
- [ ] Check all internal links

## References
- [PRD: Phase 9 - Documentation](../docs/PRD.md#phase-9-testing--documentation)
