# Task 019: Page Endpoints - Screenshot and Content

## Description
Implement screenshot capture and HTML content extraction endpoints.

## Acceptance Criteria
- [ ] GET `/sessions/{id}/pages/{pid}/screenshot` returns PNG/JPEG
- [ ] GET `/sessions/{id}/pages/{pid}/content` returns HTML
- [ ] Screenshot supports full_page, type, quality parameters
- [ ] Returns binary image data with correct Content-Type
- [ ] HTML content includes length metadata

## Implementation
File: `src/main.py` (add endpoints)

### Screenshot
```python
from fastapi.responses import Response

@app.get("/sessions/{session_id}/pages/{page_id}/screenshot", dependencies=[Depends(verify_api_key)])
async def page_screenshot(
    session_id: str,
    page_id: str,
    full_page: bool = False,
    type: Literal["png", "jpeg"] = "png",
    quality: int = 80,
):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)

    screenshot_bytes = await page.screenshot(
        full_page=full_page,
        type=type,
        quality=quality if type == "jpeg" else None,
    )

    media_type = f"image/{type}"
    return Response(content=screenshot_bytes, media_type=media_type)
```

### Content (HTML)
```python
@app.get("/sessions/{session_id}/pages/{page_id}/content", dependencies=[Depends(verify_api_key)])
async def page_content(session_id: str, page_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)

    html = await page.content()

    return {
        "html": html,
        "length": len(html),
    }
```

## References
- [API: Capture Screenshot](../docs/API.md#capture-screenshot)
- [API: Get Page HTML](../docs/API.md#get-page-html)

## Testing
- [ ] Test screenshot PNG format
- [ ] Test screenshot JPEG format with quality
- [ ] Test full_page screenshot
- [ ] Test screenshot Content-Type header
- [ ] Test HTML content extraction
- [ ] Test content length matches actual length
- [ ] Test page not found (404)

File: `tests/test_page_screenshot_content.py`

## Notes
- Screenshot may be large (several MB for full page)
- Consider adding size limits or warning in docs
- JPEG quality only applies to JPEG format
