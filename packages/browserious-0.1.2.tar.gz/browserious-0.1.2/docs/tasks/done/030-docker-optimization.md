# Task 030: Docker Image Optimization

## Description
Optimize Docker image for size, security, and build speed.

## Acceptance Criteria
- [ ] Multi-stage build for smaller image
- [ ] Layer caching optimized
- [ ] .dockerignore configured
- [ ] Security best practices applied
- [ ] Build time < 5 minutes
- [ ] Image size reasonable (< 2GB)

## Implementation

### .dockerignore
File: `.dockerignore`

```
# Git
.git/
.gitignore

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
*.egg-info/
.pytest_cache/
.coverage

# Project
profiles/
extensions/
.env
*.md
docs/
tasks/
tests/

# IDE
.vscode/
.idea/
*.swp
```

### Optimize Dockerfile
File: `Dockerfile` (optimize)

```dockerfile
FROM mcr.microsoft.com/playwright:v1.49.0-noble

# Install system dependencies in one layer
RUN apt-get update && apt-get install -y --no-install-recommends \
    xvfb \
    x11vnc \
    novnc \
    websockify \
    supervisor \
    && rm -rf /var/lib/apt/lists/*

# Create non-root user
RUN groupadd -r browseruser && \
    useradd -r -g browseruser browseruser

# Copy requirements first (for layer caching)
WORKDIR /app
COPY requirements.txt .

# Install Python dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Copy supervisord config
COPY supervisord.conf /etc/supervisor/conf.d/supervisord.conf

# Copy application code
COPY src/ /app/src/

# Create directories with correct permissions
RUN mkdir -p /data/profiles /data/extensions /var/log/supervisor && \
    chown -R browseruser:browseruser /data /app /var/log/supervisor

# Environment
ENV DISPLAY=:99
ENV RESOLUTION=1920x1080x24
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1

USER browseruser

EXPOSE 5900 6080 8000 9222

HEALTHCHECK --interval=30s --timeout=10s --start-period=10s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

CMD ["/usr/bin/supervisord", "-c", "/etc/supervisor/conf.d/supervisord.conf"]
```

### Build Script
File: `scripts/build.sh` (create)

```bash
#!/bin/bash
set -e

echo "Building Docker image..."

# Build with build args
docker build \
  --build-arg BUILDKIT_INLINE_CACHE=1 \
  --tag browserious:latest \
  --tag browserious:$(git rev-parse --short HEAD) \
  .

echo "Image built successfully"
docker images browserious:latest
```

### Build Optimization
Use BuildKit for faster builds:

```bash
export DOCKER_BUILDKIT=1
docker build --progress=plain -t browserious .
```

## Security Hardening

### Add to Dockerfile
```dockerfile
# Security: read-only root filesystem where possible
# (Note: browser needs write access to profile dir)

# Security: drop all capabilities, add only necessary ones
# (Applied via docker-compose.yml)

# Security: non-root user
USER browseruser
```

### Update docker-compose.yml
```yaml
security_opt:
  - no-new-privileges:true
cap_drop:
  - ALL
cap_add:
  - SYS_CHROOT
read_only: false  # Browser needs write access
tmpfs:
  - /tmp
```

## References
- [SECURITY: Container Security](../docs/SECURITY.md#container-security)
- [PRD: Phase 10 - Docker Optimization](../docs/PRD.md#phase-10-refinement--deployment)

## Testing
- [ ] Build image
- [ ] Check image size
- [ ] Test build cache (modify code, rebuild)
- [ ] Run security scan (trivy)
- [ ] Test healthcheck
- [ ] Verify non-root user

## Commands
```bash
# Build
./scripts/build.sh

# Size check
docker images browserious:latest

# Security scan
trivy image browserious:latest

# Run with security options
docker-compose up -d
docker-compose ps
```

## Target Metrics
- Build time: < 5 minutes (with cache < 1 minute)
- Image size: < 2GB
- Security scan: No HIGH or CRITICAL vulnerabilities
