# Task 022: Extension Manager - Upload and Storage

## Description
Implement extension upload, storage, and metadata parsing.

## Acceptance Criteria
- [ ] `src/extension_manager.py` created
- [ ] POST `/extensions` accepts .zip/.crx upload
- [ ] Extracts and stores extension
- [ ] Parses manifest.json for metadata
- [ ] GET `/extensions` lists available extensions
- [ ] DELETE `/extensions/{id}` removes extension

## Implementation
File: `src/extension_manager.py`

```python
import zipfile
import json
from pathlib import Path

class ExtensionManager:
    def __init__(self, extensions_dir: str):
        self.extensions_dir = Path(extensions_dir)
        self.extensions_dir.mkdir(parents=True, exist_ok=True)

    async def upload_extension(self, file_data: bytes, filename: str) -> dict:
        extension_id = f"ext-{uuid.uuid4()}"
        extension_path = self.extensions_dir / extension_id

        # Extract zip/crx
        with zipfile.ZipFile(io.BytesIO(file_data)) as zf:
            zf.extractall(extension_path)

        # Parse manifest.json
        manifest_path = extension_path / "manifest.json"
        if not manifest_path.exists():
            shutil.rmtree(extension_path)
            raise ValueError("Invalid extension: manifest.json not found")

        with open(manifest_path) as f:
            manifest = json.load(f)

        return {
            "extension_id": extension_id,
            "name": manifest.get("name", "Unknown"),
            "version": manifest.get("version", "0.0.0"),
            "description": manifest.get("description", ""),
            "manifest_version": manifest.get("manifest_version", 2),
            "permissions": manifest.get("permissions", []),
            "file_size": sum(f.stat().st_size for f in extension_path.rglob("*") if f.is_file()),
        }

    def list_extensions(self) -> list[dict]:
        extensions = []
        for ext_dir in self.extensions_dir.iterdir():
            if ext_dir.is_dir():
                manifest_path = ext_dir / "manifest.json"
                if manifest_path.exists():
                    with open(manifest_path) as f:
                        manifest = json.load(f)
                    extensions.append({
                        "extension_id": ext_dir.name,
                        "name": manifest.get("name", "Unknown"),
                        "version": manifest.get("version", "0.0.0"),
                        "manifest_version": manifest.get("manifest_version", 2),
                    })
        return extensions

    def delete_extension(self, extension_id: str):
        extension_path = self.extensions_dir / extension_id
        if extension_path.exists():
            shutil.rmtree(extension_path)

    def get_extension_path(self, extension_id: str) -> Path:
        return self.extensions_dir / extension_id

extension_manager = ExtensionManager(settings.extensions_dir)
```

## Endpoints
File: `src/main.py` (add endpoints)

```python
from fastapi import UploadFile, File

@app.post("/extensions", dependencies=[Depends(verify_api_key)])
async def upload_extension(file: UploadFile = File(...)):
    if not file.filename.endswith(('.zip', '.crx')):
        raise HTTPException(400, detail="File must be .zip or .crx")

    file_data = await file.read()

    extension_info = await extension_manager.upload_extension(file_data, file.filename)

    return extension_info

@app.get("/extensions", dependencies=[Depends(verify_api_key)])
async def list_extensions():
    extensions = extension_manager.list_extensions()
    return {"extensions": extensions, "total": len(extensions)}

@app.delete("/extensions/{extension_id}", dependencies=[Depends(verify_api_key)])
async def delete_extension(extension_id: str):
    extension_manager.delete_extension(extension_id)
    return {"status": "deleted", "extension_id": extension_id}
```

## References
- [ADR-009: Extension Upload via API](../docs/ADR.md#adr-009-extension-upload-via-api)
- [API: Extensions](../docs/API.md#extensions)
- [PRD: Phase 5 - Extensions](../docs/PRD.md#phase-5-extensions)

## Security
- Validate manifest.json structure
- Check for dangerous permissions (warn user)
- Limit file size (e.g., 50MB)

## Testing
- [ ] Test upload valid extension
- [ ] Test upload invalid file (not zip)
- [ ] Test upload without manifest.json
- [ ] Test list extensions
- [ ] Test delete extension
- [ ] Test extension path traversal prevention

File: `tests/test_extensions.py`
