# Task: Unified Screenshot API with Fullscreen Mode

## Description

Combine page and display screenshot endpoints into a single unified API. The page screenshot endpoint gains a `fullscreen` parameter that composites the browser chrome (from display screenshot) with the page content.

## Motivation

- Two separate screenshot endpoints is confusing for API users
- Often need both page content AND browser chrome (address bar, tabs, etc.) for debugging
- Unifying reduces API surface and cognitive load
- Better matches how humans think about screenshots: "give me what I see"

## API Design

### Current (Two Endpoints)

```python
# Page screenshot (viewport/page content only)
GET /sessions/{session_id}/pages/{page_id}/screenshot

# Display screenshot (X11 framebuffer, includes browser chrome)
GET /sessions/{session_id}/display/screenshot
```

### Proposed (Unified)

```python
# Page screenshot (default, same as before)
GET /sessions/{session_id}/pages/{page_id}/screenshot

# With fullscreen - composites display + page
GET /sessions/{session_id}/pages/{page_id}/screenshot?fullscreen=true
```

The `/display/screenshot` endpoint remains available but is now secondary - the primary API is through page screenshot.

## Implementation

### 1. Fullscreen Screenshot Composition

When `fullscreen=true`:
1. Take display screenshot (X11 framebuffer)
2. Take page screenshot (Playwright)
3. Composite them: paste page content over the viewport area of the display shot

```python
from PIL import Image
from io import BytesIO

def composite_fullscreen_screenshot(
    display_bytes: bytes,
    page_bytes: bytes,
    viewport_offset_x: int,
    viewport_offset_y: int,
    viewport_width: int,
    viewport_height: int,
) -> bytes:
    display_img = Image.open(BytesIO(display_bytes)).convert("RGBA")
    page_img = Image.open(BytesIO(page_bytes)).convert("RGBA")

    # Resize page screenshot to viewport dimensions if needed
    if page_img.size != (viewport_width, viewport_height):
        page_img = page_img.resize((viewport_width, viewport_height))

    # Paste page content over the viewport area
    # This effectively replaces the browser's rendered page with Playwright's version
    display_img.paste(page_img, (viewport_offset_x, viewport_offset_y))

    output = BytesIO()
    display_img.save(output, format="PNG")
    return output.getvalue()
```

### 2. Viewport Offset Detection

Need to know where the browser viewport starts within the display:

```python
# Could be hardcoded for known chromium kiosk mode
# Or detected once at session start by comparing display vs page screenshots

async def detect_viewport_offset(session) -> tuple[int, int, int, int]:
    # Take both screenshots
    display = await get_display_screenshot(session)
    page = await get_page_screenshot(session, page_id)

    # Find where page content appears in display
    # (Image matching or known offsets for kiosk mode)

    # For kiosk mode, typically:
    # - offset_x = 0 (no sidebar)
    # - offset_y = 0 (no title bar, address bar hidden)
    # - width = display_width
    # - height = display_height

    return offset_x, offset_y, width, height
```

### 3. Full-Page Fullscreen

When `fullscreen=true` AND `full_page=true`:
- Display shot stays the same size
- Page shot extends beyond viewport (scrolled content)
- Result: browser chrome at top, full page content below

```python
def composite_fullpage_fullscreen(
    display_bytes: bytes,
    full_page_bytes: bytes,
    viewport_offset_y: int,
    viewport_height: int,
) -> bytes:
    display_img = Image.open(BytesIO(display_bytes))
    page_img = Image.open(BytesIO(full_page_bytes))

    display_width, display_height = display_img.size
    page_width, page_height = page_img.size

    # Chrome height (the part above viewport)
    chrome_height = viewport_offset_y

    # Result size: chrome + full page height
    result_height = chrome_height + page_height
    result = Image.new("RGBA", (display_width, result_height))

    # Paste browser chrome (top portion of display)
    chrome = display_img.crop((0, 0, display_width, chrome_height))
    result.paste(chrome, (0, 0))

    # Paste full page content below chrome
    result.paste(page_img, (0, chrome_height))

    output = BytesIO()
    result.save(output, format="PNG")
    return output.getvalue()
```

### 4. Empty Areas / Transparency

Handle scrollbars, borders, or gaps:

```python
# Areas outside the viewport (scrollbars, borders) remain from display shot
# OR can be made transparent if requested

def composite_with_transparency(
    display_bytes: bytes,
    page_bytes: bytes,
    viewport_x: int, viewport_y: int,
    viewport_width: int, viewport_height: int,
    transparent_chrome: bool = False,  # Make non-viewport areas transparent
) -> bytes:
    display_img = Image.open(BytesIO(display_bytes)).convert("RGBA")
    page_img = Image.open(BytesIO(page_bytes)).convert("RGBA")

    if transparent_chrome:
        # Create transparent base
        result = Image.new("RGBA", display_img.size, (0, 0, 0, 0))
        # Paste only the page content
        result.paste(page_img, (viewport_x, viewport_y))
    else:
        # Paste page over display
        display_img.paste(page_img, (viewport_x, viewport_y))
        result = display_img

    output = BytesIO()
    result.save(output, format="PNG")
    return output.getvalue()
```

## Frame of Reference

**Critical documentation point:**

| Mode | Coordinate Origin (0,0) | Use Case |
|------|------------------------|----------|
| `fullscreen=false` (default) | Top-left of **page content** | DOM interactions, element positions |
| `fullscreen=true` | Top-left of **display** | Full context, debugging, CAPTCHA detection |

### Why This Matters

When using `cursor=true`:
- **Without fullscreen**: cursor coords are in page/viewport space
- **With fullscreen**: cursor coords are in display/screen space

When using `crop=...`:
- **Without fullscreen**: crop coords are relative to page content
- **With fullscreen**: crop coords are relative to display

## Updated Endpoint Signature

```python
@app.get("/sessions/{session_id}/pages/{page_id}/screenshot")
async def page_screenshot(
    session_id: str,
    page_id: str,
    full_page: bool = Query(default=False, description="Capture full scrollable page"),
    fullscreen: bool = Query(default=False, description="Include browser chrome (display composite)"),
    cursor: bool = Query(default=False, description="Draw cursor overlay"),
    crop_x: int = Query(default=None, description="Crop region X"),
    crop_y: int = Query(default=None, description="Crop region Y"),
    crop_width: int = Query(default=None, description="Crop region width"),
    crop_height: int = Query(default=None, description="Crop region height"),
    type: Literal["png", "jpeg"] = Query(default="png"),
    quality: int = Query(default=80, ge=0, le=100),
):
    ...
```

## Acceptance Criteria

- [ ] `fullscreen=true` composites display + page screenshots
- [ ] Viewport offset is correctly calculated/configured
- [ ] Browser chrome (tabs, address bar) visible when fullscreen
- [ ] `full_page=true` + `fullscreen=true` works correctly
- [ ] Empty areas (scrollbars, borders) handled gracefully
- [ ] Coordinate frame of reference is documented
- [ ] `cursor=true` works correctly in both modes
- [ ] `crop=...` works correctly in both modes
- [ ] Performance acceptable (compositing adds latency)
- [ ] `/display/screenshot` endpoint still works (backwards compat)

## Example Use Cases

1. **Debug browser state**: See address bar URL + page content in one shot
2. **CAPTCHA context**: See the whole screen including browser chrome, which may hint at being detected
3. **Comprehensive logging**: Full visual record of what the session looks like
4. **Before/after comparisons**: Consistent full-screen captures for visual regression

## Dependencies

- Task 033: Cursor overlay (must handle both coordinate systems)
- Task 034: Crop region (must handle both coordinate systems)
- Pillow for image composition

## Testing

```python
def test_fullscreen_screenshot():
    # Navigate to a page
    goto("https://example.com")

    # Take regular page screenshot
    page_only = screenshot()

    # Take fullscreen composite
    fullscreen = screenshot(fullscreen=True)

    # Fullscreen should be larger (includes chrome)
    # Or same size but with browser UI visible
    assert fullscreen != page_only

def test_fullscreen_with_cursor():
    # Move cursor to known screen position
    move(500, 300)

    # Take fullscreen screenshot with cursor
    img = screenshot(fullscreen=True, cursor=True)

    # Cursor should appear at (500, 300) in screen coords
    # (verify visually or with pixel analysis)
```
