# Task 023: Session Creation with Extensions

## Description
Update session creation to load Chrome extensions.

## Acceptance Criteria
- [ ] SessionCreate accepts extensions parameter
- [ ] BrowserManager loads extensions on session creation
- [ ] Extensions specified by extension_id
- [ ] Invalid extension_id returns 400 error
- [ ] Extensions work in non-headless mode

## Implementation
File: `src/browser_manager.py` (update create_session)

```python
async def create_session(
    self,
    profile_id: str | None = None,
    proxy: dict | None = None,
    extensions: list[str] = [],
    viewport: dict = {"width": 1920, "height": 1080},
    user_agent: str | None = None,
    timeout: int = 3600,
) -> BrowserSession:
    session_id = str(uuid.uuid4())

    profile_id = profile_id or session_id
    profile_path = Path(settings.profiles_dir) / profile_id

    # Build extension args
    ext_args = []
    if extensions:
        ext_paths = []
        for ext_id in extensions:
            ext_path = extension_manager.get_extension_path(ext_id)
            if not ext_path.exists():
                raise ValueError(f"Extension not found: {ext_id}")
            ext_paths.append(str(ext_path))

        ext_args = [
            f"--disable-extensions-except={','.join(ext_paths)}",
            f"--load-extension={','.join(ext_paths)}",
        ]

    # Launch persistent context
    context = await self.playwright.chromium.launch_persistent_context(
        user_data_dir=str(profile_path),
        headless=False,  # Required for extensions
        args=[
            "--no-sandbox",
            "--disable-dev-shm-usage",
            *ext_args,
        ],
        ignore_default_args=["--disable-extensions"] if extensions else [],
        proxy=proxy,
        viewport=viewport,
        user_agent=user_agent,
    )

    created_at = datetime.utcnow()
    expires_at = created_at + timedelta(seconds=timeout)

    session = BrowserSession(
        session_id=session_id,
        profile_id=profile_id,
        context=context,
        profile_path=profile_path,
        created_at=created_at,
        expires_at=expires_at,
    )

    self.sessions[session_id] = session
    return session
```

## Update Endpoint
File: `src/main.py` (update create_session endpoint)

Pass extensions parameter to manager.create_session():
```python
session = await manager.create_session(
    profile_id=req.profile_id,
    proxy=req.proxy.model_dump() if req.proxy else None,
    extensions=req.extensions,  # Add this
    viewport=req.viewport,
    user_agent=req.user_agent,
    timeout=req.timeout,
)
```

## References
- [Project Brief: Extensions](../docs/project-brief.md#extensions)
- [Playwright: Chrome Extensions](https://playwright.dev/python/docs/chrome-extensions)

## Testing
- [ ] Test session creation with valid extension
- [ ] Test session creation with multiple extensions
- [ ] Test session creation with invalid extension_id (400)
- [ ] Test extension loads in browser (verify in page context)
- [ ] Test session without extensions

File: `tests/test_session_extensions.py`
