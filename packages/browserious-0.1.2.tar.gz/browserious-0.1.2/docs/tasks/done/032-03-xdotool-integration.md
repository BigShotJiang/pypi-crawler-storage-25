---
id: TASK-032-03
title: Implement xdotool integration
type: backend
status: new
priority: high
depends: [TASK-032-01]
blocks: [TASK-032-04]
prd: PRD-node-api-input.md
estimated_files:
  - node/api/xdo.go
  - node/api/xdo_test.go
---

# Implement xdotool integration

## Context

xdotool sends X11 input events to the virtual display. We need a Go interface to call xdotool commands with minimal latency.

## Requirements

- Mouse move, click, button down/up
- Keyboard key down/up, type text
- Mouse scroll
- Get current mouse position

## Implementation Notes

- Use persistent xdotool process with stdin pipe for low latency
- Set `DISPLAY` environment variable from config
- Commands are newline-delimited to stdin
- Consider using xdotool's `--delay 0` for immediate execution

## Sub-tasks

- [ ] Create `XdoController` struct with stdin pipe
- [ ] Implement `Start()` to launch xdotool process
- [ ] Implement `Close()` for cleanup
- [ ] Implement `MouseMove(x, y int)`
- [ ] Implement `MouseDown(button int)` and `MouseUp(button int)`
- [ ] Implement `Click(button int)`
- [ ] Implement `KeyDown(key string)` and `KeyUp(key string)`
- [ ] Implement `Type(text string)`
- [ ] Implement `Scroll(dx, dy int)`
- [ ] Implement `GetMousePosition() (x, y int)`
- [ ] Handle xdotool process crashes (restart)

## Acceptance Criteria

- [ ] Mouse movements appear in Xvfb display
- [ ] Key events are received by applications
- [ ] Scroll events work
- [ ] No process leak on repeated Start/Close
- [ ] Latency < 5ms per command

## On Completion

- [ ] Test manually with Xvfb running
- [ ] Commit: `git commit -m "Add xdotool integration layer"`
- [ ] Move this file to `done/`
