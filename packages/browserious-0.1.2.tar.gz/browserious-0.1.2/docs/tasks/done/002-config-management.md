# Task 002: Configuration Management

## Description
Implement configuration management using pydantic-settings for environment-based configuration.

## Acceptance Criteria
- [ ] `src/config.py` implements Settings class
- [ ] All configuration from environment variables
- [ ] Type hints on all settings
- [ ] Default values for optional settings
- [ ] Settings singleton instance exported
- [ ] Configuration validated on startup

## Required Settings
```python
API_KEYS: str  # Comma-separated, required
PROFILES_DIR: str = "/data/profiles"
EXTENSIONS_DIR: str = "/data/extensions"
MAX_SESSIONS: int = 10
DEFAULT_TIMEOUT: int = 3600
RESOLUTION: str = "1920x1080x24"
```

## Implementation
File: `src/config.py`

Use `pydantic-settings` BaseSettings with:
- Environment variable prefix (if needed)
- Validation for required fields
- Type coercion (e.g., comma-separated string to list)
- Singleton pattern for settings instance

## References
- [PRD: Phase 1 - Config Management](../docs/PRD.md#phase-1-foundation-core-infrastructure)
- [API: Configuration](../docs/API.md#configuration)

## Example Usage
```python
from src.config import settings

api_keys = settings.api_keys  # List[str]
max_sessions = settings.max_sessions  # int
```

## Testing
- [ ] Test with valid environment variables
- [ ] Test with missing required variables (should raise error)
- [ ] Test type coercion (string to int, comma-separated to list)
- [ ] Test default values

File: `tests/test_config.py`
