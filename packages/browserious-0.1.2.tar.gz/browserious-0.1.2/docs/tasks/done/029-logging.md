# Task 029: Structured Logging

## Description
Implement structured logging for operations, errors, and auditing.

## Acceptance Criteria
- [ ] Structured logging configured (JSON format)
- [ ] Log levels used correctly (DEBUG, INFO, WARNING, ERROR)
- [ ] Sensitive data not logged (API keys, VNC passwords)
- [ ] Request IDs for tracing
- [ ] Logs to stdout (Docker-friendly)

## Implementation

### Configure Logging
File: `src/logging_config.py` (create)

```python
import logging
import sys
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_obj = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        if hasattr(record, "session_id"):
            log_obj["session_id"] = record.session_id

        if hasattr(record, "request_id"):
            log_obj["request_id"] = record.request_id

        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_obj)

def setup_logging(level: str = "INFO"):
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())

    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    root_logger.setLevel(getattr(logging, level.upper()))

    # Silence noisy loggers
    logging.getLogger("playwright").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
```

### Add Request ID Middleware
File: `src/main.py` (add middleware)

```python
import uuid
from starlette.middleware.base import BaseHTTPMiddleware

class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id

        response = await call_next(request)

        response.headers["X-Request-ID"] = request_id
        return response

app.add_middleware(RequestIDMiddleware)
```

### Initialize Logging
File: `src/main.py` (add at startup)

```python
from src.logging_config import setup_logging

setup_logging(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)
```

### Logging Best Practices
```python
# Session operations
logger.info(
    "Session created",
    extra={
        "session_id": session.session_id,
        "profile_id": session.profile_id,
    }
)

# Errors
logger.error(
    "Browser operation failed",
    exc_info=True,
    extra={"session_id": session_id}
)

# Audit events (eval, routes)
logger.warning(
    "JavaScript eval executed",
    extra={
        "session_id": session_id,
        "script": script[:100],  # Truncate
    }
)
```

### Sensitive Data Sanitization
File: `src/utils.py` (create)

```python
def sanitize_headers(headers: dict) -> dict:
    sensitive_keys = {"authorization", "x-api-key", "cookie"}
    return {
        k: "***REDACTED***" if k.lower() in sensitive_keys else v
        for k, v in headers.items()
    }
```

## References
- [PRD: Phase 10 - Logging](../docs/PRD.md#phase-10-refinement--deployment)
- [SECURITY: Data Protection](../docs/SECURITY.md#data-protection)

## Configuration
Add to environment variables:
```
LOG_LEVEL=INFO  # DEBUG, INFO, WARNING, ERROR
```

## Testing
- [ ] Test log output format (JSON)
- [ ] Test log levels
- [ ] Test sensitive data not logged
- [ ] Test request ID in logs
- [ ] Test exception logging

File: `tests/test_logging.py`

## Notes
- Logs to stdout for Docker (supervisor captures)
- Use external log aggregation (ELK, Loki) in production
- Rotate logs if storing to files
