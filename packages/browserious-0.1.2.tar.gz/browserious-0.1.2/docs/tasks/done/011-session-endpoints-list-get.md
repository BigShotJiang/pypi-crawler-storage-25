# Task 011: Session Endpoints - GET /sessions and GET /sessions/{id}

## Description
Implement session listing and detail retrieval endpoints.

## Acceptance Criteria
- [ ] GET `/sessions` endpoint lists all active sessions
- [ ] GET `/sessions/{id}` endpoint returns session details
- [ ] Returns 404 if session not found
- [ ] Both require API key authentication
- [ ] Response matches API specification

## Implementation
File: `src/main.py` (add endpoints)

### GET /sessions
```python
@app.get("/sessions", response_model=SessionListResponse, dependencies=[Depends(verify_api_key)])
async def list_sessions():
    sessions = [
        SessionInfo(
            session_id=s.session_id,
            profile_id=s.profile_id,
            created_at=s.created_at.isoformat(),
            expires_at=s.expires_at.isoformat(),
            page_count=len(s.context.pages),
            route_count=0,  # TODO: will add routes later
        )
        for s in manager.sessions.values()
    ]
    return SessionListResponse(sessions=sessions, total=len(sessions))
```

### GET /sessions/{id}
```python
@app.get("/sessions/{session_id}", response_model=SessionDetail, dependencies=[Depends(verify_api_key)])
async def get_session(session_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    pages = [
        PageInfo(
            page_id=f"page-{i}",
            url=page.url,
            title=await page.title(),
        )
        for i, page in enumerate(session.context.pages)
    ]

    return SessionDetail(
        session_id=session.session_id,
        profile_id=session.profile_id,
        created_at=session.created_at.isoformat(),
        expires_at=session.expires_at.isoformat(),
        pages=pages,
        routes=[],  # TODO: will add routes later
        extensions=[],  # TODO: will add extensions later
        proxy=None,  # TODO: store proxy config in session
    )
```

## Add Models
File: `src/models.py`

```python
class SessionInfo(BaseModel):
    session_id: str
    profile_id: str
    created_at: str
    expires_at: str
    page_count: int
    route_count: int

class SessionListResponse(BaseModel):
    sessions: list[SessionInfo]
    total: int

class SessionDetail(BaseModel):
    session_id: str
    profile_id: str
    created_at: str
    expires_at: str
    pages: list[PageInfo]
    routes: list
    extensions: list[str]
    proxy: dict | None
```

## References
- [API: GET /sessions](../docs/API.md#list-sessions)
- [API: GET /sessions/{id}](../docs/API.md#get-session-details)

## Testing
- [ ] Test list sessions (empty)
- [ ] Test list sessions (with 1 session)
- [ ] Test list sessions (with multiple sessions)
- [ ] Test get session details (exists)
- [ ] Test get session details (not found - 404)
- [ ] Test authentication required

File: `tests/test_sessions.py` (extend)
