# Task 027: Integration Tests - Complete Workflows

## Description
Create integration tests for complete end-to-end workflows.

## Acceptance Criteria
- [ ] Test complete session lifecycle
- [ ] Test web scraping workflow
- [ ] Test E2E testing workflow with mocks
- [ ] Test profile persistence across sessions
- [ ] Test extension loading and functionality
- [ ] All tests pass

## Implementation
File: `tests/integration/test_workflows.py`

### Test Session Lifecycle
```python
async def test_complete_session_lifecycle(client):
    # Create session
    response = await client.post("/sessions", json={
        "profile_id": "test-profile",
        "timeout": 600
    })
    assert response.status_code == 200
    session_id = response.json()["session_id"]

    # List sessions
    response = await client.get("/sessions")
    assert len(response.json()["sessions"]) == 1

    # Get session details
    response = await client.get(f"/sessions/{session_id}")
    assert response.status_code == 200

    # Delete session
    response = await client.delete(f"/sessions/{session_id}")
    assert response.status_code == 200

    # Verify deleted
    response = await client.get(f"/sessions/{session_id}")
    assert response.status_code == 404
```

### Test Web Scraping Workflow
```python
async def test_web_scraping_workflow(client):
    # Create session with proxy
    response = await client.post("/sessions", json={
        "profile_id": "scraper",
        "timeout": 600
    })
    session_id = response.json()["session_id"]

    # Block images
    await client.post(f"/sessions/{session_id}/routes", json={
        "pattern": "**/*.{png,jpg}",
        "action": {"type": "block"}
    })

    # Navigate to page
    await client.post(
        f"/sessions/{session_id}/pages/page-0/goto",
        json={"url": "https://example.com"}
    )

    # Extract data via eval
    response = await client.post(
        f"/sessions/{session_id}/pages/page-0/eval",
        json={"script": "return document.title"}
    )
    assert "Example" in response.json()["result"]

    # Take screenshot
    response = await client.get(f"/sessions/{session_id}/pages/page-0/screenshot")
    assert response.status_code == 200
    assert response.headers["content-type"] == "image/png"

    # Cleanup
    await client.delete(f"/sessions/{session_id}")
```

### Test E2E with Mocks
```python
async def test_e2e_with_mocked_api(client):
    # Create session
    response = await client.post("/sessions", json={})
    session_id = response.json()["session_id"]

    # Mock API response
    await client.post(f"/sessions/{session_id}/routes", json={
        "pattern": "**/api/user",
        "action": {
            "type": "override",
            "status": 200,
            "headers": {"Content-Type": "application/json"},
            "body": '{"name": "Test User"}'
        }
    })

    # Navigate to app (that calls /api/user)
    await client.post(
        f"/sessions/{session_id}/pages/page-0/goto",
        json={"url": "https://httpbin.org/html"}
    )

    # Verify mock was used (would need inspect route for full verification)

    await client.delete(f"/sessions/{session_id}")
```

### Test Profile Persistence
```python
async def test_profile_persistence(client):
    profile_id = "persistent-profile"

    # Session 1: Set some state
    response = await client.post("/sessions", json={"profile_id": profile_id})
    session1_id = response.json()["session_id"]

    await client.post(f"/sessions/{session1_id}/pages/page-0/goto",
        json={"url": "https://example.com"})

    await client.post(f"/sessions/{session1_id}/pages/page-0/eval", json={
        "script": "localStorage.setItem('test_key', 'test_value'); return true;"
    })

    # Export state
    state_response = await client.get(f"/profiles/{profile_id}/state")
    state = state_response.json()

    await client.delete(f"/sessions/{session1_id}")

    # Session 2: Verify state persists
    response = await client.post("/sessions", json={"profile_id": profile_id})
    session2_id = response.json()["session_id"]

    await client.post(f"/sessions/{session2_id}/pages/page-0/goto",
        json={"url": "https://example.com"})

    result = await client.post(f"/sessions/{session2_id}/pages/page-0/eval", json={
        "script": "return localStorage.getItem('test_key');"
    })

    assert result.json()["result"] == "test_value"

    await client.delete(f"/sessions/{session2_id}")
```

## References
- [PRD: Phase 9 - Integration Tests](../docs/PRD.md#phase-9-testing--documentation)
- [README: API Examples](../README.md#api-examples)

## Testing
Run with:
```bash
pytest tests/integration/ -v
```

## Notes
- These tests require actual browser (slower)
- May need to increase test timeouts
- Use pytest markers for integration tests
