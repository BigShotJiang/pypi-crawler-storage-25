# Task: Element Hit Testing at Coordinates

## Description

Add an endpoint or provide a documented JS snippet to identify what element exists at specific viewport coordinates. Useful for visual navigation and debugging coordinate calculations.

## Motivation

- When navigating visually (screenshot-based), need to verify what's at a position before clicking
- Helps debug coordinate offset calculations
- Can identify if click target is obscured by another element
- Useful for building element maps from visual positions

## Options

### Option A: API Endpoint

```python
GET /sessions/{session_id}/pages/{page_id}/elementAt?x=500&y=300

Response:
{
    "found": true,
    "element": {
        "tag": "BUTTON",
        "id": "submit-btn",
        "classes": "btn btn-primary",
        "text": "Sign In",
        "href": null,
        "type": "submit",
        "name": "submit",
        "value": "",
        "disabled": false,
        "visible": true,
        "clickable": true,
        "bounds": {"x": 480, "y": 285, "width": 100, "height": 40}
    },
    "stack": [
        {"tag": "BUTTON", "id": "submit-btn"},
        {"tag": "FORM", "id": "login-form"},
        {"tag": "DIV", "classes": "container"},
        {"tag": "BODY"},
        {"tag": "HTML"}
    ]
}
```

### Option B: Documented JS Snippet (for page_eval)

```javascript
((x, y) => {
    const el = document.elementFromPoint(x, y);
    if (!el) return {found: false};

    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);

    // Get element stack (what's above this point)
    const stack = [];
    let current = el;
    while (current && current !== document.body) {
        stack.push({
            tag: current.tagName,
            id: current.id || null,
            classes: current.className || null
        });
        current = current.parentElement;
    }

    return {
        found: true,
        element: {
            tag: el.tagName,
            id: el.id || null,
            classes: el.className || null,
            text: el.textContent?.trim().slice(0, 100) || null,
            href: el.href || null,
            type: el.type || null,
            name: el.name || null,
            placeholder: el.placeholder || null,
            disabled: el.disabled || false,
            visible: style.display !== 'none' && style.visibility !== 'hidden',
            clickable: (
                el.onclick !== null ||
                el.tagName === 'A' ||
                el.tagName === 'BUTTON' ||
                el.tagName === 'INPUT' ||
                el.getAttribute('role') === 'button' ||
                style.cursor === 'pointer'
            ),
            bounds: {
                x: Math.round(rect.x),
                y: Math.round(rect.y),
                width: Math.round(rect.width),
                height: Math.round(rect.height)
            }
        },
        stack: stack
    };
})(VIEWPORT_X, VIEWPORT_Y)
```

## Recommendation

Implement as both:
1. **API endpoint** for convenience and discoverability
2. **Documented JS snippet** in EXAMPLES.md for flexibility

The API endpoint would internally use the JS snippet via page_eval.

## Implementation (if API endpoint)

1. Add new endpoint:
   ```python
   @router.get("/sessions/{session_id}/pages/{page_id}/elementAt")
   async def get_element_at_coordinates(
       session_id: str,
       page_id: str,
       x: int = Query(..., description="Viewport X coordinate"),
       y: int = Query(..., description="Viewport Y coordinate"),
       include_stack: bool = Query(False, description="Include parent element stack")
   ):
   ```

2. Execute JS snippet via existing page_eval infrastructure

3. Return structured response

## Acceptance Criteria

- [ ] Returns element info at given viewport coordinates
- [ ] Includes bounds for verification
- [ ] Indicates if element is clickable/interactive
- [ ] Optional: return element stack (parent hierarchy)
- [ ] Returns `{found: false}` if no element at coordinates
- [ ] JS snippet documented in EXAMPLES.md

## Use Cases

1. **Pre-click verification**: Check what's at calculated coordinates before clicking
2. **Debug offset issues**: Verify cursor is over intended element
3. **Element discovery**: Find clickable elements by scanning positions
4. **Obstruction detection**: Check if target is covered by overlay/modal
