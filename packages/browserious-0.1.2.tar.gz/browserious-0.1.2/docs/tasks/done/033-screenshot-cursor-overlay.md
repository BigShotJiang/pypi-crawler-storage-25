# Task: Server-Side Cursor Overlay on Screenshots

## Description

Add a `cursor` boolean parameter to BOTH screenshot endpoints (`/pages/{page_id}/screenshot` and `/display/screenshot`) that stamps the cursor position directly on the PNG image server-side.

## Problem Solved

- JS-injected cursor overlay doesn't work inside iframes (mousemove events go to iframe, not page)
- This is critical for captcha solving where the captcha is in an iframe
- Server-side overlay is always accurate regardless of page structure
- No DOM pollution or potential interference with page behavior

## API Design

```python
# Page screenshot - gets cursor position from /input/position API
GET /sessions/{session_id}/pages/{page_id}/screenshot?cursor=true

# Display screenshot - same approach
GET /sessions/{session_id}/display/screenshot?cursor=true
```

Both endpoints use the same shared function for drawing the overlay.

## Implementation

### 1. Create shared overlay function

```python
# src/image_utils.py
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont

def stamp_cursor_overlay(
    image_bytes: bytes,
    x: int,
    y: int,
    color: str = "red",
    radius: int = 15,
    show_coords: bool = True
) -> bytes:
    img = Image.open(BytesIO(image_bytes))
    draw = ImageDraw.Draw(img)

    # Draw circle around cursor position
    draw.ellipse(
        [x - radius, y - radius, x + radius, y + radius],
        outline=color,
        width=3
    )

    # Draw crosshair
    line_ext = 8
    draw.line([x - radius - line_ext, y, x + radius + line_ext, y], fill=color, width=2)
    draw.line([x, y - radius - line_ext, x, y + radius + line_ext], fill=color, width=2)

    # Draw coordinate label
    if show_coords:
        label = f"({x}, {y})"
        draw.text((x + radius + 5, y - radius - 5), label, fill=color)

    output = BytesIO()
    img.save(output, format="PNG")
    return output.getvalue()
```

### 2. Update page_screenshot endpoint

```python
@app.get("/sessions/{session_id}/pages/{page_id}/screenshot")
async def page_screenshot(
    session_id: str,
    page_id: str,
    full_page: bool = Query(default=False),
    type: Literal["png", "jpeg"] = Query(default="png"),
    quality: int = Query(default=80, ge=0, le=100),
    cursor: bool = Query(default=False, description="Draw cursor overlay on screenshot"),
):
    # ... existing code to get screenshot_bytes ...

    if cursor:
        # Get cursor position from existing API
        x, y = await get_mouse_position(session)

        # Convert screen coords to viewport coords
        # Screen coords include browser chrome, viewport starts at (0,0) inside page
        # Need to account for browser window position and chrome height
        viewport_x = x - session.viewport_offset_x
        viewport_y = y - session.viewport_offset_y

        screenshot_bytes = stamp_cursor_overlay(screenshot_bytes, viewport_x, viewport_y)

    return Response(content=screenshot_bytes, media_type=media_type)
```

### 3. Update display_screenshot endpoint

```python
@app.get("/sessions/{session_id}/display/screenshot")
async def get_display_screenshot_endpoint(
    session_id: str,
    cursor: bool = Query(default=False, description="Draw cursor overlay on screenshot"),
):
    # ... existing code ...
    screenshot_data = await get_display_screenshot(session)

    if cursor:
        # For display screenshots, use screen coords directly (no conversion needed)
        x, y = await get_mouse_position(session)
        screenshot_data = stamp_cursor_overlay(screenshot_data, x, y)

    return Response(content=screenshot_data, media_type="image/png")
```

### 4. Coordinate calculation considerations

**Page screenshot:**
- Mouse position is in screen coordinates (X11)
- Page screenshot is in viewport coordinates (0,0 = top-left of page content)
- Need to subtract browser chrome offset (title bar, toolbar, tabs)
- Chromium in kiosk mode should have minimal chrome

**Display screenshot:**
- Both mouse and screenshot are in screen coordinates
- No conversion needed

## Acceptance Criteria

- [ ] Both screenshot endpoints accept `cursor: bool` parameter
- [ ] Cursor overlay is a red circle with crosshair
- [ ] Coordinates are displayed next to cursor (x, y)
- [ ] Page screenshot correctly converts screen→viewport coords
- [ ] Display screenshot uses screen coords directly
- [ ] Shared function used by both endpoints (DRY)
- [ ] Works correctly with full_page screenshots (need scroll position consideration)
- [ ] Works when cursor is over iframes (the whole point!)
- [ ] No performance regression when cursor=false

## Testing

```python
def test_page_screenshot_with_cursor():
    # Move cursor to known position
    response = client.post(f"/sessions/{sid}/input/playlist", json={"playlist": [
        {"type": "move", "x": 400, "y": 300, "duration": 0}
    ]})

    # Take screenshot with cursor
    response = client.get(f"/sessions/{sid}/pages/page-0/screenshot?cursor=true")

    # Verify cursor overlay is present at expected position
    # (visual inspection or pixel analysis)
```

## Dependencies

- Pillow (PIL) - already likely in deps for image processing

## Related

- Task 034: Screenshot crop region (combines with this - crop first, then draw cursor if in region)
- docs/EXAMPLES.md - JS cursor overlay docs (will add note about this being better for iframes)
