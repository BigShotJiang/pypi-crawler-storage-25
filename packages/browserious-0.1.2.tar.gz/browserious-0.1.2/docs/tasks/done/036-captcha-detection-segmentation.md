# Task: CAPTCHA Detection, Segmentation, and Solving Infrastructure

## Description

Build infrastructure to detect CAPTCHA challenges on pages, precisely segment their interactive elements (grid cells, checkboxes, buttons), and calculate accurate click coordinates for solving.

## Problem Statement

In our previous captcha solving attempts:
- ✅ We could **recognize the captcha** was present on screen
- ✅ We could **generate correct solution plans** (e.g., "click tiles 1, 4, 7, 9")
- ❌ We **failed to navigate it** - click coordinates were consistently off
- ❌ We clicked wrong grid cells despite knowing the right answer

The issue: we need precise bounding boxes of EACH interactive element within the captcha frame.

## Architecture

### Phase 1: CAPTCHA Frame Detection

Detect the captcha iframe/container on the page:

```python
# New endpoint or documented JS snippet
GET /sessions/{session_id}/pages/{page_id}/detectCaptcha

Response:
{
    "detected": true,
    "type": "recaptcha_v2",  # or "hcaptcha", "turnstile", "custom"
    "frame": {
        "x": 250,
        "y": 150,
        "width": 400,
        "height": 580,
        "is_iframe": true,
        "iframe_src": "https://www.google.com/recaptcha/api2/anchor..."
    }
}
```

Detection methods:
1. Look for known iframe srcs (recaptcha, hcaptcha, cloudflare)
2. Look for known container class names
3. Visual detection via screenshot analysis (fallback)

### Phase 2: Grid Cell Segmentation

Once captcha is detected, segment the interactive grid:

```python
GET /sessions/{session_id}/pages/{page_id}/captcha/segment

Response:
{
    "type": "image_grid",
    "prompt": "Select all images with traffic lights",
    "grid": {
        "rows": 3,
        "cols": 3,
        "cells": [
            {"index": 0, "x": 270, "y": 200, "width": 120, "height": 120, "center_x": 330, "center_y": 260},
            {"index": 1, "x": 390, "y": 200, "width": 120, "height": 120, "center_x": 450, "center_y": 260},
            ...
        ]
    },
    "buttons": {
        "verify": {"x": 500, "y": 550, "width": 80, "height": 30, "center_x": 540, "center_y": 565},
        "skip": {"x": 270, "y": 550, "width": 80, "height": 30, "center_x": 310, "center_y": 565}
    }
}
```

### Phase 3: Coordinate-Accurate Clicking

With precise bboxes, implement click helper:

```python
POST /sessions/{session_id}/pages/{page_id}/captcha/click
{
    "cells": [0, 3, 6, 8],  # Grid cell indices to click
    "click_delay": 300,     # ms between clicks (human-like)
    "then_verify": true     # Click verify button after
}

Response:
{
    "clicked": [
        {"cell": 0, "x": 330, "y": 260, "success": true},
        {"cell": 3, "x": 330, "y": 380, "success": true},
        ...
    ],
    "verify_clicked": true
}
```

## Implementation Details

### 1. Detection via JavaScript (works for most cases)

```javascript
(() => {
    // Check for reCAPTCHA
    const recaptcha = document.querySelector('iframe[src*="recaptcha"]');
    if (recaptcha) {
        const rect = recaptcha.getBoundingClientRect();
        return {
            detected: true,
            type: 'recaptcha_v2',
            frame: {
                x: Math.round(rect.x),
                y: Math.round(rect.y),
                width: Math.round(rect.width),
                height: Math.round(rect.height),
                is_iframe: true
            }
        };
    }

    // Check for hCaptcha
    const hcaptcha = document.querySelector('iframe[src*="hcaptcha"]');
    if (hcaptcha) {
        const rect = hcaptcha.getBoundingClientRect();
        return {
            detected: true,
            type: 'hcaptcha',
            frame: { x: rect.x, y: rect.y, width: rect.width, height: rect.height, is_iframe: true }
        };
    }

    // Check for Cloudflare Turnstile
    const turnstile = document.querySelector('iframe[src*="challenges.cloudflare"]');
    if (turnstile) { ... }

    return { detected: false };
})()
```

### 2. Grid Segmentation via Screenshot Analysis

When captcha is inside cross-origin iframe (can't access DOM):

```python
from PIL import Image
import numpy as np

def segment_captcha_grid(screenshot_bytes: bytes, captcha_bbox: dict) -> dict:
    img = Image.open(BytesIO(screenshot_bytes))

    # Crop to captcha region
    captcha_img = img.crop((
        captcha_bbox['x'],
        captcha_bbox['y'],
        captcha_bbox['x'] + captcha_bbox['width'],
        captcha_bbox['y'] + captcha_bbox['height']
    ))

    # Detect grid lines using edge detection
    # Most captcha grids have visible borders between cells

    # For 3x3 grid:
    # - Find horizontal lines at ~33% and ~66% height
    # - Find vertical lines at ~33% and ~66% width
    # - Calculate cell bounds

    # Return cell coordinates in SCREEN space (not captcha-relative)
```

### 3. Visual AI Segmentation (fallback/enhancement)

Send cropped captcha screenshot to vision model for segmentation:

```python
async def segment_with_vision_ai(captcha_screenshot: bytes) -> dict:
    # Send to Claude/GPT-4V with structured output request
    # Ask: "Identify the grid cells in this captcha. Return bounding boxes for each cell."

    # This handles non-standard captchas and varying layouts
```

### 4. Coordinate Mapping

Critical: map captcha-relative coords to screen coords for clicking:

```python
def to_screen_coords(captcha_frame: dict, local_x: int, local_y: int) -> tuple[int, int]:
    # Captcha frame position (from detection)
    frame_x = captcha_frame['x']
    frame_y = captcha_frame['y']

    # Screen coordinates = frame position + local position
    screen_x = frame_x + local_x
    screen_y = frame_y + local_y

    return screen_x, screen_y
```

## API Endpoints

### GET /sessions/{session_id}/pages/{page_id}/captcha/detect

Detect captcha presence and type.

### GET /sessions/{session_id}/pages/{page_id}/captcha/segment

Get precise bboxes of all interactive elements.

### POST /sessions/{session_id}/pages/{page_id}/captcha/solve

Convenience endpoint that:
1. Takes solution plan (which cells to click)
2. Clicks each cell with human-like timing
3. Clicks verify button
4. Returns success/failure status

## Acceptance Criteria

- [ ] Detect reCAPTCHA v2 presence and bounding box
- [ ] Detect hCaptcha presence and bounding box
- [ ] Segment 3x3 and 4x4 image grids accurately
- [ ] Return cell bboxes in SCREEN coordinates (ready for clicking)
- [ ] Calculate center point of each cell for clicking
- [ ] Detect verify/skip buttons and their coordinates
- [ ] Coordinate accuracy: clicks land within 5px of intended center
- [ ] Human-like delays between grid cell clicks (200-400ms)
- [ ] Works with Task 034 (crop screenshot to captcha region)
- [ ] Works with Task 033 (cursor overlay to debug clicks)

## Testing Strategy

1. **Unit test grid segmentation** with sample captcha screenshots
2. **Integration test** clicking accuracy on test captcha pages
3. **Visual debugging** using cursor overlay (Task 033) to verify click positions

## Example Workflow

```python
# 1. Navigate to page with captcha
await goto("https://example.com/signup")

# 2. Detect captcha
captcha = await detect_captcha()
# {"detected": true, "type": "recaptcha_v2", "frame": {"x": 250, "y": 150, ...}}

# 3. Take cropped screenshot of captcha (Task 034)
screenshot = await page_screenshot(crop_x=250, crop_y=150, crop_width=400, crop_height=580)

# 4. Send to vision AI for solving
solution = await vision_ai.solve_captcha(screenshot)
# {"cells_to_click": [1, 4, 7], "confidence": 0.92}

# 5. Get precise cell coordinates
segmentation = await segment_captcha()
# {"cells": [{"index": 0, "center_x": 330, "center_y": 260}, ...]}

# 6. Click each cell
for cell_idx in solution['cells_to_click']:
    cell = segmentation['cells'][cell_idx]
    await click(cell['center_x'], cell['center_y'])
    await sleep(random.uniform(0.2, 0.4))

# 7. Click verify
await click(segmentation['buttons']['verify']['center_x'],
            segmentation['buttons']['verify']['center_y'])

# 8. Take screenshot to verify success (with cursor overlay for debugging)
await page_screenshot(cursor=true)
```

## Dependencies

- Pillow for image processing/grid detection
- NumPy for edge detection (optional)
- Integration with existing input proxy for clicking

## Related Tasks

- Task 033: Cursor overlay (critical for debugging click positions)
- Task 034: Screenshot crop (reduce context when analyzing captcha)
- Task 035: Element at coordinates (verify what's under click position)

## Notes

- reCAPTCHA challenges are served from cross-origin iframe, so DOM access is impossible
- Must rely on visual analysis of screenshots for segmentation
- Cell borders are usually clearly visible, making grid detection feasible
- Button positions can often be inferred from layout (bottom of captcha frame)
- Consider caching segmentation results while captcha is on screen
