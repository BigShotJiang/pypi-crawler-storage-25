---
id: TASK-032-06
title: Add input proxy endpoint to main API
type: backend
status: new
priority: medium
depends: [TASK-032-04, TASK-032-05]
blocks: [TASK-032-07]
prd: PRD-node-api-input.md
estimated_files:
  - src/main.py
  - src/models.py
  - src/input_proxy.py
---

# Add input proxy endpoint to main API

## Context

The main FastAPI application needs to proxy input requests to the Go node API running inside browser containers.

## Requirements

- POST /sessions/{session_id}/input/play endpoint
- Forward request body to node API
- Return node API response
- Handle timeout and connection errors

## Implementation Notes

- Use httpx for async HTTP requests to node API
- Node API runs on container_ip:8080
- Timeout should accommodate playlist duration
- Validate session exists before proxying

## Sub-tasks

- [ ] Add Playlist and Action Pydantic models
- [ ] Create input_proxy.py with proxy logic
- [ ] Add POST /sessions/{id}/input/play endpoint
- [ ] Calculate timeout from playlist (sum of durations + buffer)
- [ ] Handle node API errors gracefully
- [ ] Add request/response logging

## Acceptance Criteria

- [ ] Endpoint accepts valid playlist JSON
- [ ] Request is forwarded to correct container
- [ ] Node API response is returned to client
- [ ] 404 if session doesn't exist
- [ ] 504 if node API times out
- [ ] Invalid playlist returns 422

## On Completion

- [ ] Test with running session
- [ ] Update docs/API.md with new endpoint
- [ ] Commit: `git commit -m "Add input playlist proxy endpoint"`
- [ ] Move this file to `done/`
