# Task 005: FastAPI Application Skeleton

## Description
Create the main FastAPI application with lifespan management and basic structure.

## Acceptance Criteria
- [ ] `src/main.py` implements FastAPI app
- [ ] Lifespan context manager for startup/shutdown
- [ ] CORS middleware configured
- [ ] Exception handlers configured
- [ ] Health check endpoint (no auth required)
- [ ] OpenAPI docs available at `/docs`
- [ ] App runs with `uvicorn src.main:app`

## Implementation
File: `src/main.py`

Create:
1. FastAPI app with title, version, lifespan
2. Lifespan async context manager
3. Global exception handler for consistent error format
4. CORS middleware (restrictive by default)
5. GET `/health` endpoint (returns `{"status": "ok"}`)

## Lifespan Events
```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: initialize browser manager (later task)
    yield
    # Shutdown: cleanup sessions (later task)
```

## Error Response Format
```json
{
  "detail": "Error message",
  "error_code": "ERROR_CODE",
  "context": {}
}
```

## References
- [PRD: Phase 1 - FastAPI Skeleton](../docs/PRD.md#phase-1-foundation-core-infrastructure)
- [API: Error Responses](../docs/API.md#error-responses)

## Testing
- [ ] Test app starts without errors
- [ ] Test `/health` endpoint returns 200
- [ ] Test `/docs` serves OpenAPI UI
- [ ] Test CORS headers
- [ ] Test exception handler (trigger error, check format)

File: `tests/test_main.py`
