# Task 009: Browser Manager - Core Classes

## Description
Implement BrowserManager and BrowserSession core classes for managing Playwright browser contexts.

## Acceptance Criteria
- [ ] `src/browser_manager.py` created
- [ ] `BrowserSession` dataclass with session info
- [ ] `BrowserManager` class with session registry
- [ ] `start()` method initializes Playwright
- [ ] `create_session()` method (basic, no extensions yet)
- [ ] `close_session()` method
- [ ] `get_session()` method
- [ ] Singleton manager instance

## Implementation
File: `src/browser_manager.py`

Classes:
```python
@dataclass
class BrowserSession:
    session_id: str
    profile_id: str
    context: BrowserContext
    profile_path: Path
    created_at: datetime
    expires_at: datetime
    vnc_password: str | None = None

class BrowserManager:
    def __init__(self):
        self.sessions: dict[str, BrowserSession] = {}
        self.playwright: Playwright | None = None

    async def start(self):
        # Initialize Playwright

    async def create_session(
        self,
        profile_id: str | None = None,
        proxy: dict | None = None,
        viewport: dict = {"width": 1920, "height": 1080},
        user_agent: str | None = None,
        timeout: int = 3600,
    ) -> BrowserSession:
        # Create persistent context
        # Return BrowserSession

    async def close_session(self, session_id: str):
        # Close context and cleanup

    async def get_session(self, session_id: str) -> BrowserSession | None:
        # Return session or None

manager = BrowserManager()
```

## References
- [Project Brief: Browser Manager](../docs/project-brief.md#srcbrowser_managerpy)
- [PRD: Phase 2 - Browser Manager](../docs/PRD.md#phase-2-session-management)
- [ADR-001: One Browser Per Container](../docs/ADR.md#adr-001-one-browser-per-container-vs-multi-context)

## Key Points
- Use `launch_persistent_context()` for profile support
- Generate UUID for session_id
- Default profile_id to session_id if not provided
- Set `headless=False` (needed for VNC and extensions)
- Args: `--no-sandbox`, `--disable-dev-shm-usage`

## Testing
- [ ] Test Playwright initialization
- [ ] Test session creation with default options
- [ ] Test session creation with custom profile_id
- [ ] Test session creation with proxy
- [ ] Test session retrieval
- [ ] Test session closure
- [ ] Test multiple concurrent sessions

File: `tests/test_browser_manager.py`
