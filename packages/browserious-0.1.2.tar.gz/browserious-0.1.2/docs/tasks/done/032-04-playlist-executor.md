---
id: TASK-032-04
title: Implement playlist executor
type: backend
status: new
priority: high
depends: [TASK-032-02, TASK-032-03]
blocks: [TASK-032-06]
prd: PRD-node-api-input.md
estimated_files:
  - node/api/actions.go
  - node/api/playlist.go
  - node/api/playlist_test.go
---

# Implement playlist executor

## Context

Users submit action playlists to simulate human-like input. The executor processes actions sequentially with precise timing, supporting animated mouse movements with independent X/Y easing.

## Requirements

- Parse JSON action arrays
- Execute actions sequentially with timing
- Animated mouse movement with configurable easing per axis
- type_text macro with random keystroke intervals
- Return execution stats (count, duration, errors)

## Implementation Notes

- Action types: move, sleep, mouse_down, mouse_up, click, key_down, key_up, key, type_text, scroll
- Mouse move: interpolate at ~100fps (10ms intervals)
- type_text: expand to key_down/sleep/key_up sequences with random delays
- Use `time.Sleep` for precise timing (Go has nanosecond precision)

## Sub-tasks

- [ ] Define Action struct with all action types
- [ ] Define Playlist struct with Actions array
- [ ] Implement `ExecutePlaylist(p Playlist) (Result, error)`
- [ ] Implement `executeMove()` with easing interpolation
- [ ] Implement `executeSleep()`
- [ ] Implement mouse button actions
- [ ] Implement keyboard actions
- [ ] Implement `executeTypeText()` macro expansion
- [ ] Implement `executeScroll()`
- [ ] Wire up `POST /play` endpoint
- [ ] Add request validation

## Acceptance Criteria

- [ ] POST /play accepts JSON playlist
- [ ] Mouse moves smoothly with visible easing
- [ ] Independent X/Y easing produces curved paths
- [ ] type_text produces variable timing between keys
- [ ] Response includes executed count and total duration
- [ ] Invalid actions return 400 with error details

## On Completion

- [ ] Test with sample playlists
- [ ] Commit: `git commit -m "Implement playlist executor with easing"`
- [ ] Move this file to `done/`
