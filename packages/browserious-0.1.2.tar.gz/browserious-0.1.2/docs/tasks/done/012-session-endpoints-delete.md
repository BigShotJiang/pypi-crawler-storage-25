# Task 012: Session Endpoints - DELETE /sessions/{id}

## Description
Implement session deletion endpoint with immediate cleanup.

## Acceptance Criteria
- [ ] DELETE `/sessions/{id}` endpoint implemented
- [ ] Closes browser context
- [ ] Removes session from manager
- [ ] Returns success response
- [ ] Returns 404 if session not found
- [ ] Requires API key authentication

## Implementation
File: `src/main.py` (add endpoint)

```python
@app.delete("/sessions/{session_id}", dependencies=[Depends(verify_api_key)])
async def delete_session(session_id: str):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    await manager.close_session(session_id)

    return {"status": "closed", "session_id": session_id}
```

## Update BrowserManager
Ensure `close_session()` method:
1. Closes browser context (`await context.close()`)
2. Removes from sessions dict
3. Handles case where session doesn't exist (no error)

## References
- [API: DELETE /sessions/{id}](../docs/API.md#delete-session)
- [ADR-014: Hard Timeout](../docs/ADR.md#adr-014-hard-timeout-with-immediate-termination)

## Testing
- [ ] Test delete existing session
- [ ] Test delete non-existent session (404)
- [ ] Test session actually closed (not in manager.sessions)
- [ ] Test browser context closed
- [ ] Test can create new session after deleting
- [ ] Test authentication required

File: `tests/test_sessions.py` (extend)
