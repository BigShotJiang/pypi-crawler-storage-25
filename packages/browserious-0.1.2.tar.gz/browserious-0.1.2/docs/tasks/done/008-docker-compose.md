# Task 008: Docker Compose Configuration

## Description
Create docker-compose.yml for local development and testing.

## Acceptance Criteria
- [ ] `docker-compose.yml` created
- [ ] Service definition with all ports
- [ ] Volume mounts for profiles and extensions
- [ ] Environment variables
- [ ] Resource limits configured
- [ ] shm_size set (required for Chromium)
- [ ] Service starts with `docker-compose up`

## Implementation
File: `docker-compose.yml`

```yaml
version: '3.8'

services:
  browser-api:
    build: .
    container_name: browserious
    shm_size: 2g  # Required for Chromium
    ports:
      - "5900:5900"   # VNC
      - "6080:6080"   # noVNC web
      - "8000:8000"   # API
      - "9222:9222"   # CDP (optional)
    volumes:
      - ./profiles:/data/profiles
      - ./extensions:/data/extensions
    environment:
      - API_KEYS=${API_KEYS}
      - RESOLUTION=1920x1080x24
      - MAX_SESSIONS=10
      - DEFAULT_TIMEOUT=3600
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 512M
    restart: unless-stopped
```

## Also Create
File: `.env.example`
```
API_KEYS=your-api-key-here
RESOLUTION=1920x1080x24
MAX_SESSIONS=10
DEFAULT_TIMEOUT=3600
```

## Update .gitignore
Add:
```
.env
profiles/
extensions/
```

## References
- [Project Brief: docker-compose.yml](../docs/project-brief.md#docker-composeyml)
- [README: Quick Start](../README.md#quick-start)
- [SECURITY: Resource Limits](../docs/SECURITY.md#av-3-resource-exhaustion-dos)

## Testing
- [ ] Create `.env` from `.env.example`
- [ ] Set API_KEYS in `.env`
- [ ] Run `docker-compose up -d`
- [ ] Verify service starts
- [ ] Check all ports accessible
- [ ] Verify volumes created
- [ ] Test health endpoint
- [ ] Check resource limits applied

File: `tests/test_docker_compose.sh` (shell script)
