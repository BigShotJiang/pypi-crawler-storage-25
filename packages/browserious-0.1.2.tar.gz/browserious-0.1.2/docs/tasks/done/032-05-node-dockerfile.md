---
id: TASK-032-05
title: Update node Dockerfile for Go API
type: devops
status: new
priority: high
depends: [TASK-032-01]
blocks: [TASK-032-06]
prd: PRD-node-api-input.md
estimated_files:
  - node/Dockerfile
  - node/entrypoint.sh
---

# Update node Dockerfile for Go API

## Context

The browser node container needs to include the Go API binary and start it alongside Chrome and Xvfb.

## Requirements

- Multi-stage build: compile Go, copy to runtime image
- Install xdotool in runtime image
- Start Go API in entrypoint
- Expose port 8080 for node API

## Implementation Notes

- Use `golang:1.21-alpine` for build stage
- Static binary: `CGO_ENABLED=0 go build`
- Add `xdotool` to apt-get install list
- Start node-api before Chrome (it needs DISPLAY set)

## Sub-tasks

- [ ] Add Go build stage to Dockerfile
- [ ] Copy binary to runtime image
- [ ] Add xdotool to apt-get install
- [ ] Update entrypoint.sh to start node-api
- [ ] Expose port 8080
- [ ] Test container builds successfully

## Acceptance Criteria

- [ ] `docker build -t browserious-node:latest ./node` succeeds
- [ ] Container starts with node-api on 8080
- [ ] `curl container:8080/health` returns 200
- [ ] xdotool commands work inside container
- [ ] Chrome still starts and accepts CDP connections

## On Completion

- [ ] Rebuild: `docker build -t browserious-node:latest ./node`
- [ ] Test manually: `docker run --rm browserious-node:latest`
- [ ] Commit: `git commit -m "Add Go API to node container"`
- [ ] Move this file to `done/`
