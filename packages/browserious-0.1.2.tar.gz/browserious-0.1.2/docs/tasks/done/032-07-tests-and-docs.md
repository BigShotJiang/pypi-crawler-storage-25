---
id: TASK-032-07
title: Add tests and documentation for input API
type: docs
status: new
priority: medium
depends: [TASK-032-06]
blocks: []
prd: PRD-node-api-input.md
estimated_files:
  - tests/test_input_proxy.py
  - docs/API.md
  - docs/EXAMPLES.md
---

# Add tests and documentation for input API

## Context

The input simulation feature needs integration tests and user-facing documentation.

## Requirements

- Integration tests for input proxy endpoint
- API documentation for POST /sessions/{id}/input/play
- Examples showing common use cases

## Implementation Notes

- Mock node API responses in tests
- Document all action types with examples
- Document all easing functions
- Add examples to docs/EXAMPLES.md

## Sub-tasks

- [ ] Add test_input_proxy.py with endpoint tests
- [ ] Test valid playlist execution
- [ ] Test error cases (invalid session, bad JSON)
- [ ] Add Input Simulation section to docs/API.md
- [ ] Document action types and parameters
- [ ] Document easing functions with use cases
- [ ] Add input examples to docs/EXAMPLES.md
- [ ] Update ADR.md with Node API decision

## Acceptance Criteria

- [ ] All tests pass: `pytest tests/test_input_proxy.py`
- [ ] API.md documents all action types
- [ ] EXAMPLES.md shows click, type, drag patterns
- [ ] ADR.md has ADR-020 for Node API architecture

## On Completion

- [ ] Run full test suite: `pytest`
- [ ] Review documentation for accuracy
- [ ] Commit: `git commit -m "Add input API tests and documentation"`
- [ ] Move this file to `done/`
