# Task: Screenshot Crop Region Parameter

## Description

Add a crop parameter to screenshot endpoints to capture only a specific region of the page/display. This reduces image size and saves context when working with AI assistants.

## Motivation

- Full page screenshots can be 100KB-500KB, consuming significant AI context
- Often only a small region is relevant (a form, a button, an error message)
- Cropping server-side is more efficient than sending full image and describing the region
- Enables targeted visual debugging without context bloat

## API Design

```python
# Crop by coordinates
GET /sessions/{session_id}/pages/{page_id}/screenshot?crop_x=600&crop_y=400&crop_width=300&crop_height=200

# Or as JSON object
GET /sessions/{session_id}/pages/{page_id}/screenshot?crop={"x":600,"y":400,"width":300,"height":200}

# Crop around element (by selector)
GET /sessions/{session_id}/pages/{page_id}/screenshot?crop_selector={"strategy":"css","value":"#login-form"}&crop_padding=20
```

## Implementation

1. Add optional query parameters:
   - `crop_x: int` - left edge (viewport coords)
   - `crop_y: int` - top edge (viewport coords)
   - `crop_width: int` - width in pixels
   - `crop_height: int` - height in pixels
   - `crop_padding: int = 0` - extra padding around crop region

2. Alternative: crop around element
   - `crop_selector: SelectorModel` - element to crop around
   - `crop_padding: int = 20` - padding around element bounds

3. Use Pillow to crop:
   ```python
   from PIL import Image

   img = Image.open(screenshot_bytes)
   cropped = img.crop((x, y, x + width, y + height))
   ```

4. For element-based cropping:
   ```python
   # Get element bounds via page_eval
   bounds = await page.evaluate('''
       (selector) => {
           const el = document.querySelector(selector);
           if (!el) return null;
           const rect = el.getBoundingClientRect();
           return {x: rect.x, y: rect.y, width: rect.width, height: rect.height};
       }
   ''', selector)

   # Add padding and crop
   x = max(0, bounds['x'] - padding)
   y = max(0, bounds['y'] - padding)
   width = bounds['width'] + padding * 2
   height = bounds['height'] + padding * 2
   ```

## Acceptance Criteria

- [ ] Coordinate-based cropping works
- [ ] Element-based cropping works with all selector strategies
- [ ] Padding parameter respected
- [ ] Bounds checking (crop region doesn't exceed image dimensions)
- [ ] Works with both page and display screenshots
- [ ] Combines with cursor overlay (crop first, then draw cursor if in region)

## Example Use Cases

1. **Form debugging**: Crop just the login form to check field states
2. **Error messages**: Crop the notification area to capture error text
3. **Element verification**: Crop around a button to verify its state
4. **CAPTCHA region**: Crop just the CAPTCHA grid for analysis

## Size Impact Example

| Screenshot Type | Full Page | Cropped (300x200) |
|-----------------|-----------|-------------------|
| News homepage   | 450KB     | 15KB              |
| Login form      | 75KB      | 8KB               |
| CAPTCHA grid    | 180KB     | 25KB              |

## Critical for CAPTCHA Solving

When solving interactive captchas (like image grids), multiple screenshots are taken frequently to verify progress. Cropping to just the captcha region:
- Reduces context window consumption dramatically
- Provides more precise coordinates for clicking
- Faster iteration when debugging click accuracy

## Order of Operations

When both crop AND cursor overlay are requested:
1. Take full screenshot
2. Crop to specified region
3. **Adjust cursor coordinates** (subtract crop origin)
4. Draw cursor overlay on cropped image

```python
if cursor and (crop_x or crop_y):
    # Adjust cursor position relative to crop region
    cursor_x_in_crop = cursor_x - crop_x
    cursor_y_in_crop = cursor_y - crop_y

    # Only draw if cursor is within crop region
    if 0 <= cursor_x_in_crop < crop_width and 0 <= cursor_y_in_crop < crop_height:
        screenshot = stamp_cursor_overlay(screenshot, cursor_x_in_crop, cursor_y_in_crop)
```

## Related

- Task 033: Cursor overlay (must coordinate with cropping)
- Task 036: CAPTCHA detection/segmentation (primary use case)
