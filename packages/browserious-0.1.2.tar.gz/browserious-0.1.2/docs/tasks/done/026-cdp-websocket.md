# Task 026: CDP WebSocket Proxy

## Description
Implement WebSocket proxy for Chrome DevTools Protocol passthrough.

## Acceptance Criteria
- [ ] `src/cdp_proxy.py` created
- [ ] WS `/sessions/{id}/cdp` endpoint implemented
- [ ] Bidirectional message forwarding
- [ ] Get CDP endpoint URL from Playwright
- [ ] Compatible with puppeteer/playwright clients
- [ ] Handles connection lifecycle

## Implementation
File: `src/cdp_proxy.py`

```python
from fastapi import WebSocket
import websockets
import asyncio

async def forward_cdp_messages(
    client_ws: WebSocket,
    cdp_url: str,
):
    async with websockets.connect(cdp_url) as cdp_ws:
        async def client_to_cdp():
            try:
                while True:
                    message = await client_ws.receive_text()
                    await cdp_ws.send(message)
            except Exception as e:
                logger.error(f"Client to CDP error: {e}")

        async def cdp_to_client():
            try:
                async for message in cdp_ws:
                    await client_ws.send_text(message)
            except Exception as e:
                logger.error(f"CDP to client error: {e}")

        await asyncio.gather(
            client_to_cdp(),
            cdp_to_client(),
            return_exceptions=True,
        )
```

## Endpoint
File: `src/main.py` (add endpoint)

```python
from fastapi import WebSocket, WebSocketDisconnect

@app.websocket("/sessions/{session_id}/cdp")
async def cdp_websocket(websocket: WebSocket, session_id: str):
    # Note: WebSocket doesn't support Depends() for auth
    # Need to check API key from query param or header

    await websocket.accept()

    session = await manager.get_session(session_id)
    if not session:
        await websocket.close(code=1008, reason="Session not found")
        return

    # Get CDP endpoint from browser
    cdp_url = session.context.browser.ws_endpoint

    try:
        await forward_cdp_messages(websocket, cdp_url)
    except WebSocketDisconnect:
        logger.info(f"CDP WebSocket disconnected for session {session_id}")
    except Exception as e:
        logger.error(f"CDP WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal error")
```

## Get CDP Endpoint
File: `src/browser_manager.py` (update)

Store browser reference in BrowserSession:
```python
@dataclass
class BrowserSession:
    ...
    browser: Browser  # Add this field
```

When creating session:
```python
context = await self.playwright.chromium.launch_persistent_context(...)
browser = context.browser  # Get browser reference

session = BrowserSession(
    ...
    browser=browser,
)
```

Then in session response:
```python
return SessionResponse(
    ...
    cdp_url=f"{session.browser.ws_endpoint}",
)
```

## References
- [ADR-004: Full CDP Passthrough](../docs/ADR.md#adr-004-full-cdp-passthrough)
- [API: CDP WebSocket](../docs/API.md#cdp-websocket)
- [PRD: Phase 8 - CDP WebSocket](../docs/PRD.md#phase-8-cdp-websocket)

## WebSocket Authentication
For MVP, skip auth on WebSocket (rely on network security).
Post-MVP: Add token-based auth via query parameter.

## Testing
- [ ] Test WebSocket connection
- [ ] Test message forwarding (client → CDP)
- [ ] Test message forwarding (CDP → client)
- [ ] Test with puppeteer client
- [ ] Test connection close
- [ ] Test session not found

File: `tests/test_cdp_websocket.py`

## Dependencies
Add to requirements.txt:
```
websockets>=12.0
```
