---
id: TASK-032-01
title: Create Go Node API skeleton
type: backend
status: new
priority: high
depends: []
blocks: [TASK-032-02, TASK-032-03, TASK-032-04]
prd: PRD-node-api-input.md
estimated_files:
  - node/api/main.go
  - node/api/go.mod
  - node/api/go.sum
---

# Create Go Node API skeleton

## Context

Browser node containers need a lightweight API for low-level operations like hardware input simulation. Go provides precise timing and small binary size ideal for this use case.

## Requirements

- HTTP server on port 8080
- Health check endpoint
- JSON request/response handling
- Graceful shutdown support

## Implementation Notes

- Use standard library `net/http` (no frameworks needed)
- Single binary, statically compiled
- Environment variable for DISPLAY (default `:99`)
- Log to stdout for Docker log collection

## Sub-tasks

- [ ] Create `node/api/` directory structure
- [ ] Initialize Go module: `go mod init browserious-node`
- [ ] Create `main.go` with HTTP server
- [ ] Add `GET /health` endpoint returning `{"status": "ok"}`
- [ ] Add `POST /play` endpoint stub (returns 501 for now)
- [ ] Add graceful shutdown on SIGTERM

## Acceptance Criteria

- [ ] `go build` produces static binary
- [ ] Server starts and responds on port 8080
- [ ] `GET /health` returns 200 with JSON
- [ ] Binary size < 15MB

## On Completion

- [ ] Test: `go build && ./node-api &; curl localhost:8080/health`
- [ ] Commit: `git commit -m "Add Go node API skeleton"`
- [ ] Move this file to `done/`
