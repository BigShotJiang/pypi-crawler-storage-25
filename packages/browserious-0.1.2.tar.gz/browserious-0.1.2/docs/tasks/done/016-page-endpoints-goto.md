# Task 016: Page Endpoint - Navigate (goto)

## Description
Implement page navigation endpoint with wait strategies.

## Acceptance Criteria
- [ ] POST `/sessions/{id}/pages/{pid}/goto` implemented
- [ ] Supports URL parameter
- [ ] Supports wait_until parameter (load, domcontentloaded, networkidle)
- [ ] Supports timeout parameter
- [ ] Returns navigation result with timing
- [ ] Returns 404 if session or page not found

## Implementation
File: `src/main.py` (add endpoint)

```python
@app.post("/sessions/{session_id}/pages/{page_id}/goto", dependencies=[Depends(verify_api_key)])
async def page_goto(session_id: str, page_id: str, req: GotoRequest):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)

    start_time = time.time()

    await page.goto(
        req.url,
        wait_until=req.wait_until,
        timeout=req.timeout,
    )

    load_time_ms = int((time.time() - start_time) * 1000)

    return {
        "status": "ok",
        "url": page.url,
        "title": await page.title(),
        "load_time_ms": load_time_ms,
    }
```

## Model
File: `src/models.py` (add)

```python
class GotoRequest(BaseModel):
    url: str
    wait_until: Literal["load", "domcontentloaded", "networkidle"] = "load"
    timeout: int = 30000  # milliseconds

    @field_validator('url')
    def validate_url(cls, v):
        if not v.startswith(('http://', 'https://', 'about:', 'data:')):
            raise ValueError("Invalid URL scheme")
        return v

    @field_validator('timeout')
    def validate_timeout(cls, v):
        if v < 0 or v > 120000:  # max 2 minutes
            raise ValueError("Timeout must be between 0 and 120000ms")
        return v
```

## References
- [API: POST /pages/{id}/goto](../docs/API.md#navigate)
- [Playwright: page.goto()](https://playwright.dev/python/docs/api/class-page#page-goto)

## Error Handling
- Navigation timeout: Return 504 with detail
- Invalid URL: Return 400 with validation error
- Network error: Return 500 with error detail

## Testing
- [ ] Test navigate to valid URL
- [ ] Test different wait_until strategies
- [ ] Test custom timeout
- [ ] Test navigation timeout (504)
- [ ] Test invalid URL (400)
- [ ] Test page not found (404)
- [ ] Test load_time_ms is reasonable

File: `tests/test_pages.py` (extend)
