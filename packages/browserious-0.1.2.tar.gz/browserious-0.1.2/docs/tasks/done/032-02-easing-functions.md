---
id: TASK-032-02
title: Implement easing functions library
type: backend
status: new
priority: medium
depends: [TASK-032-01]
blocks: [TASK-032-04]
prd: PRD-node-api-input.md
estimated_files:
  - node/api/easing.go
  - node/api/easing_test.go
---

# Implement easing functions library

## Context

Mouse movements need easing functions for human-like motion. X and Y axes should support independent easing for natural cursor paths.

## Requirements

- Full Robert Penner easing set (30 functions)
- Input: t (0.0 to 1.0), Output: eased value (0.0 to 1.0)
- Function lookup by string name

## Implementation Notes

- All functions take `t float64` and return `float64`
- Use `math` package for Sin, Cos, Pow, Sqrt
- Create map for string-to-function lookup
- Back/Elastic/Bounce can return values outside 0-1 range (overshoot)

## Sub-tasks

- [ ] Implement linear (passthrough)
- [ ] Implement Sine family (easeInSine, easeOutSine, easeInOutSine)
- [ ] Implement power functions (Quad, Cubic, Quart, Quint)
- [ ] Implement Expo and Circ families
- [ ] Implement Back family (overshoot)
- [ ] Implement Elastic family (spring)
- [ ] Implement Bounce family (piecewise parabolas)
- [ ] Create `GetEasing(name string)` lookup function
- [ ] Write unit tests for all functions

## Acceptance Criteria

- [ ] All 30 easing functions implemented
- [ ] `GetEasing("ease_out_cubic")` returns correct function
- [ ] `GetEasing("invalid")` returns linear as fallback
- [ ] Tests verify key values: t=0→0, t=1→1, t=0.5→expected
- [ ] `go test ./...` passes

## On Completion

- [ ] Run tests: `go test -v ./...`
- [ ] Commit: `git commit -m "Add easing functions library"`
- [ ] Move this file to `done/`
