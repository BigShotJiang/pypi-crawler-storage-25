# Task 025: VNC Password Generation

## Description
Implement VNC password generation per session and update supervisord to use it.

## Acceptance Criteria
- [ ] Generate unique VNC password per session
- [ ] Store password in BrowserSession
- [ ] Return password in session creation response
- [ ] Update x11vnc to use password
- [ ] Password is 8-12 characters alphanumeric

## Implementation

### Generate Password
File: `src/browser_manager.py` (add helper)

```python
import secrets
import string

def generate_vnc_password() -> str:
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(12))
```

### Update BrowserSession Creation
File: `src/browser_manager.py` (update create_session)

```python
async def create_session(...) -> BrowserSession:
    ...
    vnc_password = generate_vnc_password()

    session = BrowserSession(
        session_id=session_id,
        profile_id=profile_id,
        context=context,
        profile_path=profile_path,
        created_at=created_at,
        expires_at=expires_at,
        vnc_password=vnc_password,
    )
    ...
```

### Update Supervisord (Dynamic Password)
This is complex because supervisord starts before session creation.

**Option 1: No password for MVP** (simplest)
- Document that VNC should be behind firewall
- Add password in post-MVP

**Option 2: Container-level password** (recommended)
- Generate password when container starts
- Pass as environment variable to supervisor
- Same password for all sessions in container (since 1 browser per container)

For one-browser-per-container architecture, use Option 2:

File: `docker-compose.yml` (add)
```yaml
environment:
  - VNC_PASSWORD=${VNC_PASSWORD:-changeme}
```

File: `supervisord.conf` (update)
```ini
[program:x11vnc]
command=x11vnc -display :99 -forever -shared -passwd %(ENV_VNC_PASSWORD)s -rfbport 5900 -xkb
```

## Update Session Response
File: `src/main.py` (update create_session)

Return VNC password in response (or container-level password from env).

## References
- [ADR-008: VNC Password Per Session](../docs/ADR.md#adr-008-vnc-password-per-session)
- [SECURITY: VNC Session Hijacking](../docs/SECURITY.md#av-6-vnc-session-hijacking)

## Decision Needed
Since architecture is one-browser-per-container, VNC password should be per-container (generated at container start), not per-session. Update ADR if needed.

## Testing
- [ ] Test password generation (alphanumeric, correct length)
- [ ] Test VNC connection with password
- [ ] Test VNC connection fails without password
- [ ] Test password returned in session response

File: `tests/test_vnc_password.py`

## Notes
- VNC password protocol limits to 8 characters (DES encryption)
- Modern VNC supports longer passwords with different auth methods
- Document password security limitations
