# Task 003: Pydantic Request/Response Models

## Description
Create all Pydantic models for API request/response validation.

## Acceptance Criteria
- [ ] All models defined in `src/models.py`
- [ ] Type hints on all fields
- [ ] Field validation (min/max, patterns, etc.)
- [ ] Optional fields with defaults
- [ ] Models match API specification exactly

## Models to Create

### Session Models
```python
ProxyConfig
SessionCreate
SessionResponse
SessionInfo
SessionListResponse
```

### Page Models
```python
PageCreate
PageInfo
PageListResponse
GotoRequest
ClickRequest
TypeRequest
FillRequest
WaitForSelectorRequest
EvalRequest
Selector  # Union of selector strategies
```

### Route Models
```python
RouteAction
RouteCreate
RouteInfo
RouteListResponse
InspectedRequest
```

### Profile Models
```python
Cookie
LocalStorageItem
SessionStorageItem
ProfileState
```

### Extension Models
```python
ExtensionInfo
ExtensionListResponse
```

## References
- [API: Complete Reference](../docs/API.md)
- [PRD: Data Models](../docs/PRD.md#data-models)

## Validation Rules
- `profile_id`: max 255 chars, pattern `^[a-zA-Z0-9_-]+$`, no `..`
- `timeout`: 60 <= timeout <= 86400
- `viewport.width`: 320 <= width <= 3840
- `viewport.height`: 240 <= height <= 2160
- `selector.strategy`: enum ["css", "xpath", "text", "role", "js"]

## Testing
- [ ] Test valid models
- [ ] Test validation errors (invalid values)
- [ ] Test optional fields
- [ ] Test model serialization (to dict, to JSON)

File: `tests/test_models.py`
