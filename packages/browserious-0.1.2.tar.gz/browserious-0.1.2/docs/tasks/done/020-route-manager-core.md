# Task 020: Route Manager - Core Implementation

## Description
Implement RouteManager class for request interception with Playwright route handlers.

## Acceptance Criteria
- [ ] `src/route_manager.py` created
- [ ] RouteManager class manages routes per session
- [ ] Supports register, unregister, list routes
- [ ] Integrates with Playwright context.route()
- [ ] Stores route metadata for inspection

## Implementation
File: `src/route_manager.py`

```python
from dataclasses import dataclass
from playwright.async_api import BrowserContext, Route

@dataclass
class RouteInfo:
    route_id: str
    pattern: str
    action: RouteAction
    captured_requests: list = field(default_factory=list)

class RouteManager:
    def __init__(self):
        self.routes: dict[str, RouteInfo] = {}  # route_id -> RouteInfo

    async def register_route(
        self,
        context: BrowserContext,
        pattern: str,
        action: RouteAction,
    ) -> str:
        route_id = str(uuid.uuid4())

        route_info = RouteInfo(
            route_id=route_id,
            pattern=pattern,
            action=action,
        )

        # Create handler based on action type
        async def route_handler(route: Route):
            if action.type == "block":
                await route.abort()
            elif action.type == "redirect":
                await route.fulfill(status=302, headers={"Location": action.url})
            elif action.type == "override":
                await route.fulfill(
                    status=action.status,
                    headers=action.headers or {},
                    body=action.body,
                )
            elif action.type == "inspect":
                # Capture request
                request_info = {
                    "url": route.request.url,
                    "method": route.request.method,
                    "headers": route.request.headers,
                }
                route_info.captured_requests.append(request_info)
                await route.continue_()

        await context.route(pattern, route_handler)

        self.routes[route_id] = route_info
        return route_id

    async def unregister_route(self, context: BrowserContext, route_id: str):
        if route_id in self.routes:
            route_info = self.routes.pop(route_id)
            await context.unroute(route_info.pattern)

    def list_routes(self) -> list[RouteInfo]:
        return list(self.routes.values())

    def get_route(self, route_id: str) -> RouteInfo | None:
        return self.routes.get(route_id)
```

## Update BrowserSession
Add route_manager to BrowserSession:
```python
@dataclass
class BrowserSession:
    ...
    route_manager: RouteManager = field(default_factory=RouteManager)
```

## References
- [ADR-006: Request Interception](../docs/ADR.md#adr-006-request-interception-as-core-feature)
- [PRD: Phase 4 - Request Interception](../docs/PRD.md#phase-4-request-interception)
- [Playwright: Route](https://playwright.dev/python/docs/api/class-route)

## Testing
- [ ] Test register route
- [ ] Test unregister route
- [ ] Test list routes
- [ ] Test route handler for each action type
- [ ] Test pattern matching

File: `tests/test_route_manager.py`
