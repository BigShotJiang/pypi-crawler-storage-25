# Task 018: Page Endpoints - Wait and Eval

## Description
Implement waitForSelector and JavaScript eval endpoints.

## Acceptance Criteria
- [ ] POST `/sessions/{id}/pages/{pid}/waitForSelector` implemented
- [ ] POST `/sessions/{id}/pages/{pid}/eval` implemented
- [ ] waitForSelector supports state parameter
- [ ] eval executes arbitrary JavaScript safely
- [ ] Both support timeout

## Implementation
File: `src/main.py` (add endpoints)

### waitForSelector
```python
@app.post("/sessions/{session_id}/pages/{page_id}/waitForSelector", dependencies=[Depends(verify_api_key)])
async def page_wait_for_selector(session_id: str, page_id: str, req: WaitForSelectorRequest):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)
    locator = await SelectorStrategy.locate(page, req.selector)

    start_time = time.time()

    await locator.wait_for(state=req.state, timeout=req.timeout)

    wait_time_ms = int((time.time() - start_time) * 1000)

    return {
        "status": "ok",
        "found": True,
        "wait_time_ms": wait_time_ms,
    }
```

### eval (JavaScript execution)
```python
@app.post("/sessions/{session_id}/pages/{page_id}/eval", dependencies=[Depends(verify_api_key)])
async def page_eval(session_id: str, page_id: str, req: EvalRequest):
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(404, detail="Session not found")

    page = await get_page_by_id(session, page_id)

    # Execute JS in page context
    result = await page.evaluate(req.script, req.args)

    return {"result": result}
```

## Models
File: `src/models.py` (add)

```python
class WaitForSelectorRequest(BaseModel):
    selector: Selector
    state: Literal["visible", "hidden", "attached", "detached"] = "visible"
    timeout: int = 30000

class EvalRequest(BaseModel):
    script: str
    args: list = []

    @field_validator('script')
    def validate_script(cls, v):
        if not v or not v.strip():
            raise ValueError("Script cannot be empty")
        return v
```

## References
- [API: Wait for Selector](../docs/API.md#wait-for-selector)
- [API: Execute JavaScript](../docs/API.md#execute-javascript)
- [SECURITY: JavaScript Injection](../docs/SECURITY.md#av-8-javascript-injection-via-eval)

## Security Note
- Document eval security risk in API docs
- Log eval calls for audit
- Consider rate limiting eval endpoint

## Testing
- [ ] Test wait for visible element
- [ ] Test wait for hidden element
- [ ] Test timeout when element not found
- [ ] Test eval with simple return value
- [ ] Test eval with complex object return
- [ ] Test eval with arguments
- [ ] Test eval with syntax error

File: `tests/test_page_wait_eval.py`
