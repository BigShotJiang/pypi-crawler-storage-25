# Task 006: Dockerfile - Base Image and System Dependencies

## Description
Create Dockerfile based on Playwright image with Xvfb, x11vnc, noVNC, and Supervisor.

## Acceptance Criteria
- [ ] `Dockerfile` created
- [ ] Uses `mcr.microsoft.com/playwright:v1.49.0-noble` as base
- [ ] Installs system dependencies (xvfb, x11vnc, novnc, websockify, supervisor)
- [ ] Creates non-root user for security
- [ ] Exposes ports 5900, 6080, 8000, 9222
- [ ] Sets environment variables
- [ ] Image builds successfully

## Dockerfile Structure
```dockerfile
FROM mcr.microsoft.com/playwright:v1.49.0-noble

# Install system dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    xvfb \
    x11vnc \
    novnc \
    websockify \
    supervisor \
    && rm -rf /var/lib/apt/lists/*

# Create non-root user
RUN groupadd -r browseruser && useradd -r -g browseruser browseruser

# Copy requirements and install Python deps
COPY requirements.txt /app/
RUN pip install --no-cache-dir -r /app/requirements.txt

# Create directories
RUN mkdir -p /data/profiles /data/extensions /var/log/supervisor
RUN chown -R browseruser:browseruser /data /app /var/log/supervisor

# Environment
ENV DISPLAY=:99
ENV RESOLUTION=1920x1080x24
ENV PYTHONPATH=/app

WORKDIR /app
USER browseruser

EXPOSE 5900 6080 8000 9222

# CMD will be added in later task (supervisor)
```

## References
- [Project Brief: Dockerfile](../docs/project-brief.md#dockerfile)
- [ADR-012: Docker + Supervisor](../docs/ADR.md#adr-012-docker--supervisor-process-management)
- [SECURITY: Container Security](../docs/SECURITY.md#container-security)

## Testing
- [ ] Build image: `docker build -t browserious .`
- [ ] Image builds without errors
- [ ] Verify installed packages
- [ ] Check user is non-root
- [ ] Check directories exist

## Notes
- Don't add CMD yet (will be supervisor in next task)
- Don't copy application code yet (comes later)
