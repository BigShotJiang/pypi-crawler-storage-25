# Task 024: Profile Manager - State Import/Export

## Description
Implement profile state management: export and import cookies, localStorage, sessionStorage.

## Acceptance Criteria
- [ ] `src/profile_manager.py` created
- [ ] GET `/profiles/{id}/state` exports profile state
- [ ] PUT `/profiles/{id}/state` imports profile state
- [ ] DELETE `/profiles/{id}` deletes profile directory
- [ ] Handles concurrent access gracefully

## Implementation
File: `src/profile_manager.py`

```python
class ProfileManager:
    def __init__(self, profiles_dir: str):
        self.profiles_dir = Path(profiles_dir)

    async def export_state(self, profile_id: str, context: BrowserContext | None = None) -> dict:
        if context:
            # Export from active context
            storage_state = await context.storage_state()
        else:
            # Export from saved state file
            state_file = self.profiles_dir / profile_id / "state.json"
            if state_file.exists():
                with open(state_file) as f:
                    storage_state = json.load(f)
            else:
                storage_state = {"cookies": [], "origins": []}

        return {
            "profile_id": profile_id,
            "cookies": storage_state.get("cookies", []),
            "localStorage": [
                {
                    "origin": origin["origin"],
                    "items": [
                        {"key": item["name"], "value": item["value"]}
                        for item in origin.get("localStorage", [])
                    ]
                }
                for origin in storage_state.get("origins", [])
            ],
            "sessionStorage": [
                {
                    "origin": origin["origin"],
                    "items": [
                        {"key": item["name"], "value": item["value"]}
                        for item in origin.get("sessionStorage", [])
                    ]
                }
                for origin in storage_state.get("origins", [])
            ],
        }

    async def import_state(self, profile_id: str, state: dict):
        # Convert to Playwright storage_state format
        storage_state = {
            "cookies": state.get("cookies", []),
            "origins": [],
        }

        # Add localStorage
        for ls_item in state.get("localStorage", []):
            origin_data = {
                "origin": ls_item["origin"],
                "localStorage": [
                    {"name": item["key"], "value": item["value"]}
                    for item in ls_item.get("items", [])
                ]
            }
            storage_state["origins"].append(origin_data)

        # Save to state file
        profile_path = self.profiles_dir / profile_id
        profile_path.mkdir(parents=True, exist_ok=True)

        state_file = profile_path / "state.json"
        with open(state_file, "w") as f:
            json.dump(storage_state, f, indent=2)

    def delete_profile(self, profile_id: str):
        profile_path = self.profiles_dir / profile_id
        if profile_path.exists():
            shutil.rmtree(profile_path)

profile_manager = ProfileManager(settings.profiles_dir)
```

## Endpoints
File: `src/main.py` (add endpoints)

```python
@app.get("/profiles/{profile_id}/state", dependencies=[Depends(verify_api_key)])
async def export_profile_state(profile_id: str):
    # Check if profile has active session
    active_session = None
    for session in manager.sessions.values():
        if session.profile_id == profile_id:
            active_session = session
            break

    state = await profile_manager.export_state(
        profile_id,
        active_session.context if active_session else None
    )

    return state

@app.put("/profiles/{profile_id}/state", dependencies=[Depends(verify_api_key)])
async def import_profile_state(profile_id: str, state: ProfileState):
    await profile_manager.import_state(profile_id, state.model_dump())

    return {
        "status": "imported",
        "profile_id": profile_id,
        "imported": {
            "cookies": len(state.cookies),
            "localStorage_origins": len(state.localStorage),
            "sessionStorage_origins": len(state.sessionStorage),
        }
    }

@app.delete("/profiles/{profile_id}", dependencies=[Depends(verify_api_key)])
async def delete_profile(profile_id: str):
    # Check if profile in use
    for session in manager.sessions.values():
        if session.profile_id == profile_id:
            raise HTTPException(409, detail="Profile is in use by active session")

    profile_manager.delete_profile(profile_id)

    return {"status": "deleted", "profile_id": profile_id}
```

## Models
File: `src/models.py` (add)

```python
class Cookie(BaseModel):
    name: str
    value: str
    domain: str
    path: str
    expires: int = -1
    httpOnly: bool = False
    secure: bool = False
    sameSite: str = "Lax"

class StorageItem(BaseModel):
    key: str
    value: str

class OriginStorage(BaseModel):
    origin: str
    items: list[StorageItem]

class ProfileState(BaseModel):
    cookies: list[Cookie] = []
    localStorage: list[OriginStorage] = []
    sessionStorage: list[OriginStorage] = []
```

## References
- [API: Profiles](../docs/API.md#profiles)
- [PRD: Phase 6 - Profiles](../docs/PRD.md#phase-6-profiles)
- [ADR-003: Shared Profile Access](../docs/ADR.md#adr-003-shared-profile-concurrent-access)

## Testing
- [ ] Test export state from active session
- [ ] Test export state from saved file
- [ ] Test import state
- [ ] Test delete profile
- [ ] Test delete profile in use (409)
- [ ] Test round-trip (export -> import -> export)

File: `tests/test_profiles.py`
