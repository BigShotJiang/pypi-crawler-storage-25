# Task 013: Session Timeout Background Task

## Description
Implement background task to automatically close expired sessions.

## Acceptance Criteria
- [ ] Background task runs periodically (every 60 seconds)
- [ ] Checks all sessions for expiration
- [ ] Closes expired sessions automatically
- [ ] Logs session closures
- [ ] Starts in lifespan, stops on shutdown

## Implementation
File: `src/browser_manager.py` (add method)

```python
class BrowserManager:
    async def cleanup_expired_sessions(self):
        while True:
            await asyncio.sleep(60)
            now = datetime.utcnow()
            expired = [
                sid for sid, session in self.sessions.items()
                if session.expires_at <= now
            ]
            for session_id in expired:
                logger.info(f"Session {session_id} expired, closing")
                await self.close_session(session_id)
```

File: `src/main.py` (update lifespan)

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    await manager.start()

    # Start background cleanup task
    cleanup_task = asyncio.create_task(manager.cleanup_expired_sessions())

    yield

    # Cancel cleanup task
    cleanup_task.cancel()
    try:
        await cleanup_task
    except asyncio.CancelledError:
        pass

    # Cleanup all remaining sessions
    for session_id in list(manager.sessions.keys()):
        await manager.close_session(session_id)
```

## References
- [ADR-014: Hard Timeout](../docs/ADR.md#adr-014-hard-timeout-with-immediate-termination)
- [PRD: Session Timeout Handling](../docs/PRD.md#phase-2-session-management)

## Testing
- [ ] Test session expires after timeout
- [ ] Test background task runs periodically
- [ ] Test task stops on shutdown
- [ ] Test multiple sessions, only expired ones closed
- [ ] Test short timeout (e.g., 5 seconds) for testing

File: `tests/test_session_timeout.py`
