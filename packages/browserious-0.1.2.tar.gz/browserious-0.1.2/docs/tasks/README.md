# Browserious Implementation Tasks

This directory contains all implementation tasks for the Browserious project, organized by status.

## Directory Structure

```
tasks/
├── new/          # Tasks ready to be picked up (31 tasks)
├── in-progress/  # Tasks currently being worked on
├── done/         # Completed tasks
└── README.md     # This file
```

## Task Workflow

1. **Pick a Task:** Move a task file from `new/` to `in-progress/`
2. **Work on Task:** Implement according to specifications
3. **Complete Task:** When done, move to `done/`

## Task Numbering

Tasks are numbered for logical dependency order:

- **001-008:** Foundation & Infrastructure (Docker, FastAPI, Config)
- **009-013:** Session Management (Core browser control)
- **014-019:** Page Operations (Navigate, interact, extract)
- **020-021:** Request Interception (Routes)
- **022-024:** Extensions & Profiles
- **025-026:** VNC & CDP WebSocket
- **027-031:** Testing, Error Handling, Optimization, Documentation

## Dependency Order

Some tasks depend on others. Recommended implementation order:

### Phase 1: Foundation (Must do first)
- 001: Project setup
- 002: Config management
- 003: Pydantic models
- 004: API key authentication
- 005: FastAPI skeleton

### Phase 2: Docker Infrastructure (Can do in parallel with Phase 1)
- 006: Dockerfile base
- 007: Supervisord config
- 008: Docker Compose

### Phase 3: Core Session Management (Requires Phase 1)
- 009: Browser manager core
- 010: POST /sessions
- 011: GET /sessions (list & get)
- 012: DELETE /sessions
- 013: Session timeout

### Phase 4: Page Operations (Requires Phase 3)
- 014: Selector strategies
- 015: Page endpoints (create/list)
- 016: Page goto
- 017: Page interactions (click/type/fill)
- 018: Page wait/eval
- 019: Page screenshot/content

### Phase 5: Request Interception (Requires Phase 3)
- 020: Route manager core
- 021: Route endpoints

### Phase 6: Extensions (Requires Phase 3)
- 022: Extension manager
- 023: Session with extensions

### Phase 7: Profiles (Requires Phase 3)
- 024: Profile manager

### Phase 8: VNC & CDP (Requires Phase 3)
- 025: VNC password
- 026: CDP WebSocket

### Phase 9: Quality & Deployment (Requires most features)
- 027: Integration tests
- 028: Error handling
- 029: Logging
- 030: Docker optimization
- 031: Documentation updates

## Task File Format

Each task file contains:

- **Description:** What needs to be done
- **Acceptance Criteria:** Definition of done (checkboxes)
- **Implementation:** Code snippets and guidance
- **References:** Links to relevant documentation
- **Testing:** What tests to write
- **Notes:** Additional considerations

## Working on Tasks

### Before Starting
1. Read the task file completely
2. Review referenced documentation (PRD, ADR, API docs)
3. Understand acceptance criteria
4. Check task dependencies

### While Working
1. Follow CLAUDE.md guidelines strictly
2. No comments in code
3. No inline imports
4. Minimal try-except
5. Use type hints everywhere

### After Completing
1. ✅ All acceptance criteria met
2. ✅ Tests written and passing
3. ✅ Documentation updated (if needed)
4. ✅ Changes committed with clear message
5. ✅ Move task file to `done/`

## Progress Tracking

Track overall progress:
```bash
# Count tasks by status
ls -1 tasks/new/ | wc -l      # New tasks
ls -1 tasks/in-progress/ | wc -l  # In progress
ls -1 tasks/done/ | wc -l     # Completed

# Calculate percentage
# Completed / Total * 100
```

## Quick Start for AI Agents

1. Read [CLAUDE.md](../CLAUDE.md) completely
2. Pick task 001 (if starting fresh)
3. Move `001-project-setup.md` to `in-progress/`
4. Implement according to task file
5. Run tests
6. Commit changes
7. Move task to `done/`
8. Pick next task (002)

## Parallel Work

Some tasks can be done in parallel:
- Phase 1 and Phase 2 (Foundation + Docker) can overlap
- Within Phase 4 (Page Operations), individual endpoints can be done in any order
- Testing tasks can be done alongside implementation

## Important Notes

- **Documentation is Critical:** Update docs after every task
- **Commit Frequently:** Commit after each completed task
- **Test Everything:** Write tests for all new code
- **Follow Dependencies:** Don't skip to advanced tasks without foundation
- **Ask Questions:** If unclear, check docs or ask user

## Resources

- [CLAUDE.md](../CLAUDE.md) - AI agent instructions
- [docs/PRD.md](../docs/PRD.md) - Product requirements
- [docs/ADR.md](../docs/ADR.md) - Architecture decisions
- [docs/API.md](../docs/API.md) - API specification
- [docs/SECURITY.md](../docs/SECURITY.md) - Security guidelines

## Estimated Timeline

- Foundation (001-008): ~2-3 hours
- Session Management (009-013): ~2-3 hours
- Page Operations (014-019): ~3-4 hours
- Request Interception (020-021): ~1-2 hours
- Extensions & Profiles (022-024): ~2-3 hours
- VNC & CDP (025-026): ~1-2 hours
- Testing & Polish (027-031): ~3-4 hours

**Total: ~15-20 hours** for complete MVP implementation

---

**Ready to build!** Start with task 001 and work through systematically.
