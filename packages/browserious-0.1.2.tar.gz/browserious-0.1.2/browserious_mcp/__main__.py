from browserious_mcp.server import mcp

mcp.run()
