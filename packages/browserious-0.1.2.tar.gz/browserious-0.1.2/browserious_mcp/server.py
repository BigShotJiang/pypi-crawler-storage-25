import os
import tempfile
from dataclasses import dataclass, field
from datetime import datetime

import httpx
from fastmcp import FastMCP
from fastmcp.utilities.types import Image
from playwright.async_api import Browser, BrowserContext, Page, Playwright, async_playwright

API_BASE_URL = os.getenv("BROWSERIOUS_API_URL", "http://localhost:8100")
API_KEY = os.getenv("BROWSERIOUS_API_KEY", "")
SCREENSHOT_DIR = os.getenv("BROWSERIOUS_SCREENSHOT_DIR", tempfile.gettempdir())


def _api_headers() -> dict[str, str]:
    if API_KEY.startswith("br_live_"):
        return {"Authorization": f"Bearer {API_KEY}"}
    if API_KEY:
        return {"X-API-Key": API_KEY}
    return {}


_api = httpx.AsyncClient(base_url=API_BASE_URL, headers=_api_headers(), timeout=120.0)


@dataclass
class SessionState:
    session_id: str
    cdp_url: str
    input_url: str
    session_token: str
    vnc_password: str
    routing_headers: dict[str, str] = field(default_factory=dict)
    browser: Browser | None = None
    context: BrowserContext | None = None
    pages: dict[str, Page] = field(default_factory=dict)


_sessions: dict[str, SessionState] = {}
_playwright: Playwright | None = None


async def _get_playwright() -> Playwright:
    global _playwright
    if _playwright is None:
        _playwright = await async_playwright().start()
    return _playwright


def _get_session(session_id: str) -> SessionState:
    state = _sessions.get(session_id)
    if not state:
        raise ValueError(f"Session {session_id} not connected. Call create_session first.")
    return state


def _get_page(state: SessionState, page_id: str) -> Page:
    page = state.pages.get(page_id)
    if not page:
        if state.context and state.context.pages:
            for p in state.context.pages:
                pid = f"page-{state.context.pages.index(p)}"
                state.pages[pid] = p
            page = state.pages.get(page_id)
    if not page:
        raise ValueError(f"Page {page_id} not found in session {state.session_id}")
    return page


def _locate(page: Page, selector: str, strategy: str = "css"):
    match strategy:
        case "css":
            return page.locator(selector)
        case "xpath":
            return page.locator(f"xpath={selector}")
        case "text":
            return page.locator(f"text={selector}")
        case "role":
            return page.locator(selector)
        case "js":
            return page.locator(f"js={selector}")
        case _:
            raise ValueError(f"Unknown strategy: {strategy}")


def _input_headers(state: SessionState) -> dict[str, str]:
    headers = {}
    if state.session_token:
        headers["Authorization"] = f"Bearer {state.session_token}"
    headers.update(state.routing_headers)
    return headers


mcp = FastMCP("Browserious")


@mcp.tool()
async def create_session(
    timeout: int = 3600,
    profile_id: str | None = None,
    user_agent: str | None = None,
    timezone: str | None = None,
    locale: str | None = None,
    languages: list[str] | None = None,
    proxy_server: str | None = None,
    viewport_width: int = 1920,
    viewport_height: int = 1080,
    chrome_args: list[str] | None = None,
    stealth_webgl_vendor: str | None = None,
    stealth_webgl_renderer: str | None = None,
) -> dict:
    """Create a new browser session. Returns session_id and connection URLs."""
    payload: dict = {
        "timeout": timeout,
        "viewport": {"width": viewport_width, "height": viewport_height},
    }
    if profile_id:
        payload["profile_id"] = profile_id
    if user_agent:
        payload["user_agent"] = user_agent
    if timezone:
        payload["timezone"] = timezone
    if locale:
        payload["locale"] = locale
    if languages:
        payload["languages"] = languages
    if proxy_server:
        payload["proxy"] = {"server": proxy_server}
    if chrome_args:
        payload["chrome_args"] = chrome_args
    if stealth_webgl_vendor or stealth_webgl_renderer:
        stealth = {}
        if stealth_webgl_vendor:
            stealth["webgl_vendor"] = stealth_webgl_vendor
        if stealth_webgl_renderer:
            stealth["webgl_renderer"] = stealth_webgl_renderer
        payload["stealth"] = stealth

    response = await _api.post("/sessions", json=payload)
    if not response.is_success:
        return {"error": response.status_code, "detail": response.text}
    data = response.json()

    pw = await _get_playwright()
    cdp_url = data["cdp_url"].replace("wss://", "https://", 1).replace("ws://", "http://", 1)
    routing_headers = data.get("routing_headers", {})
    cdp_headers = dict(routing_headers)
    cdp_headers["Authorization"] = f"Bearer {data['session_token']}"
    browser = await pw.chromium.connect_over_cdp(cdp_url, headers=cdp_headers)
    context = browser.contexts[0] if browser.contexts else await browser.new_context()

    state = SessionState(
        session_id=data["session_id"],
        cdp_url=data["cdp_url"],
        input_url=data["input_url"],
        session_token=data["session_token"],
        vnc_password=data["vnc_password"],
        routing_headers=routing_headers,
        browser=browser,
        context=context,
    )
    for i, page in enumerate(context.pages):
        state.pages[f"page-{i}"] = page
    _sessions[data["session_id"]] = state

    return data


@mcp.tool()
async def delete_session(session_id: str) -> dict:
    """Close and terminate a browser session."""
    state = _sessions.pop(session_id, None)
    if state and state.browser:
        await state.browser.close()

    response = await _api.delete(f"/sessions/{session_id}")
    response.raise_for_status()
    return response.json()


@mcp.tool()
async def list_sessions() -> dict:
    """List all active browser sessions."""
    response = await _api.get("/sessions")
    response.raise_for_status()
    return response.json()


@mcp.tool()
async def create_page(session_id: str, url: str | None = None) -> dict:
    """Create a new browser tab. Optionally navigate to URL immediately."""
    state = _get_session(session_id)
    page = await state.context.new_page()
    page_id = f"page-{len(state.pages)}"
    state.pages[page_id] = page
    if url:
        await page.goto(url)
    return {"page_id": page_id, "url": page.url, "title": await page.title()}


@mcp.tool()
async def page_goto(
    session_id: str,
    page_id: str,
    url: str,
    wait_until: str = "load",
    timeout: int = 30000,
) -> dict:
    """Navigate page to URL. wait_until: 'load', 'domcontentloaded', or 'networkidle'."""
    page = _get_page(_get_session(session_id), page_id)
    await page.goto(url, wait_until=wait_until, timeout=timeout)
    return {"url": page.url, "title": await page.title()}


@mcp.tool()
async def page_click(
    session_id: str,
    page_id: str,
    selector: str,
    strategy: str = "css",
    timeout: int = 5000,
) -> dict:
    """Click an element. strategy: 'css', 'xpath', 'text', 'role', or 'js'."""
    page = _get_page(_get_session(session_id), page_id)
    locator = _locate(page, selector, strategy)
    await locator.click(timeout=timeout)
    return {"clicked": selector}


@mcp.tool()
async def page_type(
    session_id: str,
    page_id: str,
    selector: str,
    text: str,
    strategy: str = "css",
    delay: int = 0,
    clear: bool = False,
) -> dict:
    """Type text into element with keyboard events. delay=ms between keystrokes."""
    page = _get_page(_get_session(session_id), page_id)
    locator = _locate(page, selector, strategy)
    if clear:
        await locator.fill("")
    await locator.press_sequentially(text, delay=delay)
    return {"typed": text}


@mcp.tool()
async def page_fill(
    session_id: str,
    page_id: str,
    selector: str,
    value: str,
    strategy: str = "css",
) -> dict:
    """Fill input field instantly (no keyboard events). Clears existing content."""
    page = _get_page(_get_session(session_id), page_id)
    locator = _locate(page, selector, strategy)
    await locator.fill(value)
    return {"filled": value}


@mcp.tool()
async def page_eval(session_id: str, page_id: str, script: str) -> dict:
    """Execute JavaScript in page context. Returns evaluated result."""
    page = _get_page(_get_session(session_id), page_id)
    result = await page.evaluate(script)
    return {"result": result}


@mcp.tool()
async def page_wait_for_selector(
    session_id: str,
    page_id: str,
    selector: str,
    strategy: str = "css",
    state: str = "visible",
    timeout: int = 30000,
) -> dict:
    """Wait for element state: 'visible', 'hidden', 'attached', 'detached'."""
    page = _get_page(_get_session(session_id), page_id)
    locator = _locate(page, selector, strategy)
    await locator.wait_for(state=state, timeout=timeout)
    return {"found": selector, "state": state}


@mcp.tool()
async def page_content(session_id: str, page_id: str) -> dict:
    """Get full HTML content of the page. For large pages, use page_eval to extract specific data."""
    page = _get_page(_get_session(session_id), page_id)
    content = await page.content()
    return {"content": content}


@mcp.tool()
async def add_init_script(
    session_id: str,
    script: str,
    page_id: str | None = None,
) -> dict:
    """Add a pre-navigation initialization script. Runs before any page JS on every navigation.
    If page_id is provided, applies to that page only. Otherwise applies to all pages in the session (context-level)."""
    state = _get_session(session_id)
    if page_id:
        page = _get_page(state, page_id)
        await page.add_init_script(script)
    else:
        await state.context.add_init_script(script)
    return {"added": True, "scope": page_id or "context"}


@mcp.tool()
async def page_screenshot(
    session_id: str,
    page_id: str = "page-0",
    full_page: bool = False,
    fullscreen: bool = False,
    cursor: bool = False,
    crop_x: int | None = None,
    crop_y: int | None = None,
    crop_width: int | None = None,
    crop_height: int | None = None,
) -> Image:
    """Capture page screenshot. Returns inline image and file path."""
    state = _get_session(session_id)

    if fullscreen:
        async with httpx.AsyncClient() as client:
            params = {"cursor": cursor, "type": "png"}
            response = await client.get(
                f"{state.input_url}/screenshot",
                params=params,
                headers=_input_headers(state),
                timeout=30.0,
            )
            response.raise_for_status()
            png_bytes = response.content
    else:
        page = _get_page(state, page_id)
        clip = None
        if crop_x is not None and crop_y is not None and crop_width is not None and crop_height is not None:
            clip = {"x": crop_x, "y": crop_y, "width": crop_width, "height": crop_height}
        png_bytes = await page.screenshot(full_page=full_page, clip=clip, type="png")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    mode = "display" if fullscreen else "page"
    filename = f"screenshot_{session_id[:8]}_{mode}_{timestamp}.png"
    filepath = os.path.join(SCREENSHOT_DIR, filename)

    with open(filepath, "wb") as f:
        f.write(png_bytes)

    return Image(data=png_bytes, format="png")


@mcp.tool()
async def display_screenshot(session_id: str) -> Image:
    """Capture X11 display with mouse cursor. Returns inline image and file path."""
    state = _get_session(session_id)
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{state.input_url}/screenshot",
            headers=_input_headers(state),
            timeout=30.0,
        )
        response.raise_for_status()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"display_{session_id[:8]}_{timestamp}.png"
    filepath = os.path.join(SCREENSHOT_DIR, filename)

    with open(filepath, "wb") as f:
        f.write(response.content)

    return Image(data=response.content, format="png")


@mcp.tool()
async def play_input(session_id: str, actions: list[dict]) -> dict:
    """Execute hardware-level mouse/keyboard actions via X11.

    Action types:
    - move: {type, x, y, duration_ms?, easing?}
    - click: {type, button?, x?, y?}
    - mouse_down/mouse_up: {type, button}
    - type_text: {type, text, interval?}  interval={min_ms, max_ms}
    - key: {type, key}
    - key_down/key_up: {type, key}
    - scroll: {type, delta_x?, delta_y?}
    - sleep: {type, duration_ms}

    Coordinates are screen space. Use page_eval to get element positions and convert.
    """
    state = _get_session(session_id)
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{state.input_url}/play",
            json={"actions": actions},
            headers=_input_headers(state),
            timeout=120.0,
        )
        response.raise_for_status()
    return response.json()


@mcp.tool()
async def get_cursor_position(session_id: str) -> dict:
    """Get current mouse cursor position in screen coordinates."""
    state = _get_session(session_id)
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{state.input_url}/position",
            headers=_input_headers(state),
            timeout=10.0,
        )
        response.raise_for_status()
    return response.json()


@mcp.tool()
async def element_at_point(
    session_id: str,
    page_id: str,
    x: int,
    y: int,
) -> dict:
    """Get element information at screen coordinates."""
    page = _get_page(_get_session(session_id), page_id)
    result = await page.evaluate(
        """({x, y}) => {
            const el = document.elementFromPoint(x, y);
            if (!el) return null;
            return {
                tagName: el.tagName,
                id: el.id,
                className: el.className,
                textContent: el.textContent?.slice(0, 100),
                href: el.href || null,
                rect: el.getBoundingClientRect().toJSON()
            };
        }""",
        {"x": x, "y": y},
    )
    return {"element": result}


@mcp.tool()
async def captcha_detect(session_id: str, page_id: str) -> dict:
    """Detect CAPTCHA widgets on the page (reCAPTCHA, hCaptcha, Turnstile)."""
    page = _get_page(_get_session(session_id), page_id)
    result = await page.evaluate("""() => {
        const captchas = [];
        document.querySelectorAll('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="turnstile"]').forEach(el => {
            const rect = el.getBoundingClientRect();
            captchas.push({
                type: el.src.includes('recaptcha') ? 'recaptcha' : el.src.includes('hcaptcha') ? 'hcaptcha' : 'turnstile',
                x: rect.x, y: rect.y, width: rect.width, height: rect.height
            });
        });
        return captchas;
    }""")
    return {"captchas": result}


@mcp.tool()
async def captcha_segment(
    session_id: str,
    page_id: str,
    x: int,
    y: int,
    width: int,
    height: int,
    grid_rows: int = 3,
    grid_cols: int = 3,
) -> dict:
    """Segment a CAPTCHA image grid into clickable cells with coordinates."""
    cell_width = width / grid_cols
    cell_height = height / grid_rows
    cells = []
    for row in range(grid_rows):
        for col in range(grid_cols):
            cells.append({
                "index": row * grid_cols + col,
                "row": row,
                "col": col,
                "center_x": int(x + col * cell_width + cell_width / 2),
                "center_y": int(y + row * cell_height + cell_height / 2),
            })
    return {"cells": cells, "grid_rows": grid_rows, "grid_cols": grid_cols}


@mcp.tool()
async def captcha_solve(
    session_id: str,
    page_id: str,
    cells: list[int],
    cell_coordinates: list[dict],
    verify_button: dict | None = None,
) -> dict:
    """Click specified CAPTCHA cells and optionally the verify button."""
    state = _get_session(session_id)
    actions = []
    for cell_idx in cells:
        coord = cell_coordinates[cell_idx]
        actions.append({"type": "click", "x": coord["center_x"], "y": coord["center_y"]})
        actions.append({"type": "sleep", "duration_ms": 200})

    if verify_button:
        actions.append({"type": "click", "x": verify_button["x"], "y": verify_button["y"]})

    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{state.input_url}/play",
            json={"actions": actions},
            headers=_input_headers(state),
            timeout=60.0,
        )
        response.raise_for_status()
    return {"clicked_cells": cells, "verified": verify_button is not None}
