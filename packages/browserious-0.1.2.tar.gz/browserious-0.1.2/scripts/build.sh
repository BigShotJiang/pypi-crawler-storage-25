#!/bin/bash
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "=== Go node API ==="
cd "$ROOT/node/api"
go build -o node-api .
echo "ok"

echo "=== Frontend ==="
cd "$ROOT/frontend"
npm run build
echo "ok"

echo "=== Docker image (node) ==="
docker build -t browserious-node:latest "$ROOT/node/"
echo "ok"

echo "=== All builds passed ==="
