#!/bin/bash
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FLY_TOKEN=$(grep FLY_API_TOKEN "$ROOT/.env.prod" | cut -d= -f2-)
FLY_APP="browserious-nodes"
API_BASE="https://api.machines.dev/v1/apps/$FLY_APP"

fly_api() {
    curl -s -H "Authorization: Bearer $FLY_TOKEN" "$@"
}

case "$1" in
    list)
        fly_api "$API_BASE/machines" | python3 -m json.tool
        ;;
    cleanup)
        ids=$(fly_api "$API_BASE/machines" | python3 -c "import sys,json; [print(m['id']) for m in json.load(sys.stdin)]" 2>/dev/null)
        if [ -z "$ids" ]; then
            echo "No machines to clean up"
            exit 0
        fi
        for id in $ids; do
            echo "Destroying $id..."
            fly_api -X DELETE "$API_BASE/machines/$id?force=true"
        done
        echo "Done"
        ;;
    destroy)
        [ -z "$2" ] && echo "Usage: $0 destroy <machine_id>" && exit 1
        fly_api -X DELETE "$API_BASE/machines/$2?force=true"
        ;;
    logs)
        ~/.fly/bin/flyctl logs -a $FLY_APP --no-tail 2>&1 | tail -${2:-50}
        ;;
    push)
        echo "=== Building and pushing node image to Fly registry ==="
        ~/.fly/bin/flyctl auth docker
        docker buildx build --platform linux/amd64 -t registry.fly.io/$FLY_APP:latest "$ROOT/node/" --push
        echo "ok"
        ;;
    *)
        echo "Usage: $0 {list|cleanup|destroy <id>|logs [n]|push}"
        ;;
esac
