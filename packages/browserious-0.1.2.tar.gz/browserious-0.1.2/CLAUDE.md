# Browserious - Development Guide

API-controlled browser-as-a-service for automation, testing, and web scraping.

**Stack**: Python, FastAPI, Playwright, Docker, Go (node API), PostgreSQL (asyncpg + SQLAlchemy + Alembic), React/Vite (frontend), FastMCP (MCP server)

**Versions**: Python `.python-version`, Node `.node-version`, Go `node/api/go.mod`

## Takt Integration

Tasks and wiki managed via [Takt](https://takt.potapov.dev).

**Project slug:** `browserious` | **Wiki slug:** `browserious`

Use `/takt-worker browserious` for autonomous task execution, `/takt-gardener browserious` for wiki maintenance.

Key rules:
- Claim before coding, DONE after verification
- Search wiki before starting any task (`wiki_search` + `wiki_grep` + `wiki_semantic_search` in parallel)
- Update wiki after completing work that changes documented knowledge
- Use `[[browserious-123]]` for tasks, `[[browserious/path]]` for wiki pages

## Worktrees

All code changes happen in isolated git worktrees. Never commit directly to `main`.

```bash
wt create <name>                        # creates ../browserious@<name>
cd ../browserious@<name>                # isolated branch, DB, ports
# ... work, test, commit, push, PR ...
wt remove <name>                        # drops DB, removes worktree
```

What `wt create` does: checks out `wt/<name>` branch, symlinks `.venv` and `extensions`, copies `.env.dev` and `.env.testing` with isolated DB name (`browserious_<suffix>`), clones the database via `pg_dump`.

Do NOT use `git worktree add/remove` directly.

## Development Commands

```bash
.venv/bin/python -m uvicorn src.main:app --port 8100     # API server
.venv/bin/pytest tests/ -v --tb=short                     # tests (163 tests)
ruff check src/ tests/                                     # lint
```

## CI Pipeline

Single workflow `.github/workflows/tests.yml`:

| Job | Trigger | Gate |
|-----|---------|------|
| `test`, `lint` | push/PR/release | always |
| `docker-build`, `docker-build-node` | push/PR/release | node image only if `node/` changed |
| `deploy-frontend` | push main | test+lint, `frontend/` changed |
| `push-node-image` | push main | test+lint, `node/` changed |
| `publish-pypi` | GitHub Release | test+lint |

## Project Structure

```
src/
├── main.py              # FastAPI app, lifespan, routing
├── config.py            # Settings (pydantic-settings, .env.{STAGE})
├── models.py            # Pydantic request/response models
├── auth.py              # Multi-mode auth (API key, JWT, br_live_* tokens)
├── oauth.py             # Google/GitHub OAuth code exchange
├── token_routes.py      # API token CRUD
├── tenant_routes.py     # Per-tenant config/limits
├── usage_routes.py      # Usage summary + billing webhook
├── audit.py / audit_routes.py  # Audit event logging
├── browser_manager.py   # Session lifecycle, CDP connection
├── backend_provider.py  # Abstract backend interface
├── backends/
│   ├── byom.py          # Local Docker backend
│   └── fly.py           # Fly.io Machines backend
├── page_operations.py   # Page control endpoints
├── route_manager.py     # Request interception
├── selectors.py         # CSS/XPath/text/role/JS selector strategies
├── profile_manager.py   # Profile state import/export
├── extension_manager.py # Extension upload/management
├── cdp_proxy.py         # WebSocket CDP forwarding
├── vnc_proxy.py         # WebSocket VNC forwarding
├── input_proxy.py       # HTTP input action proxy
├── image_utils.py       # Screenshot/image helpers
├── database.py          # SQLAlchemy async engine, session factory
└── db_models.py         # User, APIToken, TenantConfig, UsageEvent

browserious_mcp/
└── server.py            # FastMCP stdio server (PyPI: browserious)

node/
├── Dockerfile           # Go builder + Playwright base
├── entrypoint.sh        # Xvfb, x11vnc, Go API, Chrome
└── api/                 # Go input simulation service (xdotool, easing)

frontend/                # React SPA (Vite, Cloudflare Pages)
tests/                   # pytest + pytest-asyncio
```

## Code Guidelines

- No comments in code
- No inline imports — all imports at module level
- No try-except imports — missing imports must crash early
- Minimal try-except — rely on FastAPI global exception handlers
- Type hints everywhere
- Pydantic models for all request/response validation
- Use `settings.profiles_dir` / `settings.extensions_dir` — never hardcode `/data/` paths

## Testing

```bash
.venv/bin/pytest tests/ -v --tb=short
```

- pytest + pytest-asyncio, fixtures in `tests/conftest.py`
- PostgreSQL service required (CI uses postgres:16 container)
- `STAGE=testing` loads `.env.testing` config
- Test success/error/edge cases and auth requirements

## Key Architecture

- **One browser per container** — Docker isolation per session
- **Pluggable backends** — BYOM (local Docker) and Fly.io, extensible via `BackendProvider`
- **Opaque routing headers** — backends return `routing_headers: dict[str, str]`, callers forward without knowing what's inside
- **Multi-mode auth** — legacy API keys (`X-API-Key`), JWT (OAuth), managed tokens (`br_live_*`)
- **Multi-tenant** — user isolation on sessions, profiles, and resource limits
- **Per-session container auth** — `SESSION_TOKEN` env var guards CDP/VNC/input endpoints in Go node API

## Wiki Reference

Full documentation lives in the Takt wiki (`browserious`):
- `architecture/*` — auth, backend providers, container security, database, frontend, node API, ADRs
- `api/*` — REST reference, MCP tools, examples
- `security/*` — threat model, 13 attack vectors, stealth test results
- `infrastructure/*` — deployment, environment separation
- `research/*` — CDP detection, Fly networking, cloud hosting, MCP OAuth
