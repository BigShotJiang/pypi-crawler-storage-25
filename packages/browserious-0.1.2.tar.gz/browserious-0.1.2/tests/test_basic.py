import pytest
from httpx import AsyncClient


@pytest.mark.anyio
async def test_health_endpoint(client):
    response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


@pytest.mark.anyio
async def test_health_endpoint_no_auth_required(client):
    response = await client.get("/health")
    assert response.status_code == 200


@pytest.mark.anyio
async def test_openapi_docs_available(client):
    response = await client.get("/docs")
    assert response.status_code == 200


@pytest.mark.anyio
async def test_openapi_json_available(client):
    response = await client.get("/openapi.json")
    assert response.status_code == 200
    data = response.json()
    assert data["info"]["title"] == "Browserious API"
    assert data["info"]["version"] == "1.0.0"


@pytest.mark.anyio
async def test_cors_headers():
    from src.main import app
    from httpx import ASGITransport

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.options(
            "/health",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "GET",
            },
        )
        assert "access-control-allow-origin" in response.headers


@pytest.mark.anyio
async def test_global_exception_handler_defined():
    from src.main import app

    exception_handlers = app.exception_handlers
    assert Exception in exception_handlers


@pytest.mark.anyio
async def test_validation_error_handler():
    from src.main import app
    from fastapi import APIRouter
    from pydantic import BaseModel
    from httpx import ASGITransport

    router = APIRouter()

    class TestModel(BaseModel):
        required_field: str
        number_field: int

    @router.post("/test-validation")
    async def test_validation(data: TestModel):
        return {"ok": True}

    app.include_router(router)

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/test-validation", json={})
        assert response.status_code == 422
        data = response.json()
        assert data["detail"] == "Request validation failed"
        assert data["error_code"] == "VALIDATION_ERROR"
        assert "context" in data
        assert "errors" in data["context"]
