import pytest
from pydantic import ValidationError


def test_config_with_valid_env(monkeypatch):
    monkeypatch.setenv("API_KEYS", "key1,key2,key3")
    monkeypatch.setenv("MAX_SESSIONS", "20")
    monkeypatch.setenv("PROFILES_DIR", "/data/profiles")
    monkeypatch.setenv("EXTENSIONS_DIR", "/data/extensions")

    from src.config import Settings

    settings = Settings(_env_file=None)

    assert settings.api_keys == "key1,key2,key3"
    assert settings.api_keys_list == ["key1", "key2", "key3"]
    assert settings.max_sessions == 20
    assert settings.profiles_dir == "/data/profiles"
    assert settings.extensions_dir == "/data/extensions"
    assert settings.default_timeout == 3600
    assert settings.resolution == "1920x1080x24"


def test_config_missing_api_keys(monkeypatch):
    monkeypatch.delenv("API_KEYS", raising=False)

    from src.config import Settings

    with pytest.raises(ValidationError):
        Settings(_env_file=None)


def test_config_empty_api_keys(monkeypatch):
    monkeypatch.setenv("API_KEYS", "")

    from src.config import Settings

    with pytest.raises(ValidationError):
        Settings(_env_file=None)


def test_config_type_coercion(monkeypatch):
    monkeypatch.setenv("API_KEYS", "testkey")
    monkeypatch.setenv("MAX_SESSIONS", "50")
    monkeypatch.setenv("DEFAULT_TIMEOUT", "7200")

    from src.config import Settings

    settings = Settings(_env_file=None)

    assert isinstance(settings.max_sessions, int)
    assert settings.max_sessions == 50
    assert isinstance(settings.default_timeout, int)
    assert settings.default_timeout == 7200


def test_api_keys_list_parsing(monkeypatch):
    monkeypatch.setenv("API_KEYS", "key1, key2 , key3")

    from src.config import Settings

    settings = Settings(_env_file=None)

    assert settings.api_keys_list == ["key1", "key2", "key3"]
