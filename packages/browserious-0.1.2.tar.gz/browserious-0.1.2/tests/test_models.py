import pytest
from pydantic import ValidationError
from datetime import datetime, timezone
from src.models import (
    ProxyConfig,
    ViewportConfig,
    SessionCreate,
    SessionResponse,
    SessionCloseResponse,
    PageCreate,
    PageInfo,
    GotoRequest,
    GotoResponse,
    Selector,
    ClickRequest,
    ClickResponse,
    TypeRequest,
    FillRequest,
    WaitForSelectorRequest,
    EvalRequest,
    RouteActionBlock,
    RouteActionRedirect,
    RouteActionOverride,
    RouteActionInspect,
    RouteCreate,
    InspectedRequest,
    InspectedResponse,
    RequestTiming,
    Cookie,
    StorageItem,
    LocalStorageOrigin,
    ProfileState,
    ProfileImportResponse,
    ExtensionInfo,
    ExtensionDeleteResponse,
)


class TestProxyConfig:
    def test_valid_proxy_minimal(self):
        proxy = ProxyConfig(server="http://proxy.example.com:8080")
        assert proxy.server == "http://proxy.example.com:8080"
        assert proxy.username is None
        assert proxy.password is None

    def test_valid_proxy_with_auth(self):
        proxy = ProxyConfig(
            server="http://proxy.example.com:8080",
            username="user",
            password="pass"
        )
        assert proxy.username == "user"
        assert proxy.password == "pass"


class TestViewportConfig:
    def test_default_viewport(self):
        viewport = ViewportConfig()
        assert viewport.width == 1920
        assert viewport.height == 1080

    def test_custom_viewport(self):
        viewport = ViewportConfig(width=1280, height=720)
        assert viewport.width == 1280
        assert viewport.height == 720

    def test_min_width(self):
        viewport = ViewportConfig(width=320, height=240)
        assert viewport.width == 320
        assert viewport.height == 240

    def test_max_width(self):
        viewport = ViewportConfig(width=3840, height=2160)
        assert viewport.width == 3840
        assert viewport.height == 2160

    def test_width_too_small(self):
        with pytest.raises(ValidationError) as exc_info:
            ViewportConfig(width=200)
        assert 'greater than or equal to 320' in str(exc_info.value)

    def test_width_too_large(self):
        with pytest.raises(ValidationError) as exc_info:
            ViewportConfig(width=4000)
        assert 'less than or equal to 3840' in str(exc_info.value)

    def test_height_too_small(self):
        with pytest.raises(ValidationError) as exc_info:
            ViewportConfig(height=100)
        assert 'greater than or equal to 240' in str(exc_info.value)

    def test_height_too_large(self):
        with pytest.raises(ValidationError) as exc_info:
            ViewportConfig(height=3000)
        assert 'less than or equal to 2160' in str(exc_info.value)


class TestSessionCreate:
    def test_minimal_session_create(self):
        session = SessionCreate()
        assert session.profile_id is None
        assert session.proxy is None
        assert session.extensions == []
        assert session.viewport.width == 1920
        assert session.viewport.height == 1080
        assert session.user_agent is None
        assert session.timeout == 3600

    def test_full_session_create(self):
        session = SessionCreate(
            profile_id="user-123",
            proxy=ProxyConfig(server="http://proxy.example.com:8080"),
            extensions=["ext-1", "ext-2"],
            viewport=ViewportConfig(width=1280, height=720),
            user_agent="Custom Agent",
            timeout=7200
        )
        assert session.profile_id == "user-123"
        assert session.proxy.server == "http://proxy.example.com:8080"
        assert session.extensions == ["ext-1", "ext-2"]
        assert session.viewport.width == 1280
        assert session.timeout == 7200

    def test_profile_id_validation_valid(self):
        session = SessionCreate(profile_id="user-123_test-profile")
        assert session.profile_id == "user-123_test-profile"

    def test_profile_id_validation_dotdot(self):
        with pytest.raises(ValidationError) as exc_info:
            SessionCreate(profile_id="user/../admin")
        assert 'cannot contain ".."' in str(exc_info.value)

    def test_profile_id_validation_invalid_chars(self):
        with pytest.raises(ValidationError) as exc_info:
            SessionCreate(profile_id="user@domain")
        assert 'must match pattern' in str(exc_info.value)

    def test_profile_id_validation_slash(self):
        with pytest.raises(ValidationError) as exc_info:
            SessionCreate(profile_id="user/profile")
        assert 'must match pattern' in str(exc_info.value)

    def test_profile_id_max_length(self):
        long_id = "a" * 255
        session = SessionCreate(profile_id=long_id)
        assert session.profile_id == long_id

    def test_profile_id_too_long(self):
        long_id = "a" * 256
        with pytest.raises(ValidationError) as exc_info:
            SessionCreate(profile_id=long_id)
        assert 'at most 255 characters' in str(exc_info.value)

    def test_timeout_min(self):
        session = SessionCreate(timeout=60)
        assert session.timeout == 60

    def test_timeout_max(self):
        session = SessionCreate(timeout=86400)
        assert session.timeout == 86400

    def test_timeout_too_small(self):
        with pytest.raises(ValidationError) as exc_info:
            SessionCreate(timeout=30)
        assert 'greater than or equal to 60' in str(exc_info.value)

    def test_timeout_too_large(self):
        with pytest.raises(ValidationError) as exc_info:
            SessionCreate(timeout=100000)
        assert 'less than or equal to 86400' in str(exc_info.value)


class TestSessionResponse:
    def test_session_response(self):
        now = datetime.now(timezone.utc)
        response = SessionResponse(
            session_id="550e8400-e29b-41d4-a716-446655440000",
            profile_id="user-123",
            cdp_url="ws://localhost:9222/devtools/browser/abc",
            vnc_url="vnc://localhost:5900",
            input_url="http://localhost:8080",
            vnc_password="secret123",
            session_token="tok_abc123",
            web_vnc_url="http://localhost:6080/vnc.html",
            container_id="docker-abc123",
            created_at=now,
            expires_at=now
        )
        assert response.session_id == "550e8400-e29b-41d4-a716-446655440000"
        assert response.vnc_password == "secret123"
        assert response.session_token == "tok_abc123"


class TestPageModels:
    def test_page_create_empty(self):
        page = PageCreate()
        assert page.url is None

    def test_page_create_with_url(self):
        page = PageCreate(url="https://example.com")
        assert page.url == "https://example.com"

    def test_page_info(self):
        page = PageInfo(
            page_id="page-0",
            url="https://example.com",
            title="Example Domain"
        )
        assert page.page_id == "page-0"
        assert page.url == "https://example.com"
        assert page.title == "Example Domain"


class TestGotoRequest:
    def test_goto_minimal(self):
        req = GotoRequest(url="https://example.com")
        assert req.url == "https://example.com"
        assert req.wait_until == "load"
        assert req.timeout == 30000

    def test_goto_with_options(self):
        req = GotoRequest(
            url="https://example.com",
            wait_until="networkidle",
            timeout=60000
        )
        assert req.wait_until == "networkidle"
        assert req.timeout == 60000

    def test_goto_invalid_wait_until(self):
        with pytest.raises(ValidationError):
            GotoRequest(url="https://example.com", wait_until="invalid")


class TestSelector:
    def test_css_selector(self):
        sel = Selector(strategy="css", value="#submit-button")
        assert sel.strategy == "css"
        assert sel.value == "#submit-button"

    def test_xpath_selector(self):
        sel = Selector(strategy="xpath", value="//button[@id='submit']")
        assert sel.strategy == "xpath"

    def test_text_selector(self):
        sel = Selector(strategy="text", value="text=Submit")
        assert sel.strategy == "text"

    def test_role_selector(self):
        sel = Selector(strategy="role", value="role=button[name='Submit']")
        assert sel.strategy == "role"

    def test_js_selector(self):
        sel = Selector(strategy="js", value="() => document.querySelector('#btn')")
        assert sel.strategy == "js"

    def test_invalid_strategy(self):
        with pytest.raises(ValidationError):
            Selector(strategy="invalid", value="test")


class TestClickRequest:
    def test_click_minimal(self):
        req = ClickRequest(selector=Selector(strategy="css", value="#btn"))
        assert req.selector.strategy == "css"
        assert req.timeout == 5000
        assert req.force is False

    def test_click_with_options(self):
        req = ClickRequest(
            selector=Selector(strategy="xpath", value="//button"),
            timeout=10000,
            force=True
        )
        assert req.timeout == 10000
        assert req.force is True


class TestTypeRequest:
    def test_type_minimal(self):
        req = TypeRequest(
            selector=Selector(strategy="css", value="#input"),
            text="hello"
        )
        assert req.text == "hello"
        assert req.delay == 0
        assert req.clear is False

    def test_type_with_options(self):
        req = TypeRequest(
            selector=Selector(strategy="css", value="#input"),
            text="hello",
            delay=50,
            clear=True
        )
        assert req.delay == 50
        assert req.clear is True


class TestFillRequest:
    def test_fill_request(self):
        req = FillRequest(
            selector=Selector(strategy="css", value="#email"),
            value="user@example.com"
        )
        assert req.value == "user@example.com"


class TestWaitForSelectorRequest:
    def test_wait_minimal(self):
        req = WaitForSelectorRequest(
            selector=Selector(strategy="css", value=".loaded")
        )
        assert req.state == "visible"
        assert req.timeout == 30000

    def test_wait_with_state(self):
        req = WaitForSelectorRequest(
            selector=Selector(strategy="css", value=".hidden"),
            state="hidden",
            timeout=5000
        )
        assert req.state == "hidden"
        assert req.timeout == 5000

    def test_wait_invalid_state(self):
        with pytest.raises(ValidationError):
            WaitForSelectorRequest(
                selector=Selector(strategy="css", value=".test"),
                state="invalid"
            )


class TestEvalRequest:
    def test_eval_no_args(self):
        req = EvalRequest(script="return document.title")
        assert req.script == "return document.title"
        assert req.args == []

    def test_eval_with_args(self):
        req = EvalRequest(
            script="(a, b) => a + b",
            args=[1, 2]
        )
        assert req.args == [1, 2]


class TestRouteActions:
    def test_route_action_block(self):
        action = RouteActionBlock(type="block")
        assert action.type == "block"

    def test_route_action_redirect(self):
        action = RouteActionRedirect(
            type="redirect",
            url="https://example.com"
        )
        assert action.type == "redirect"
        assert action.url == "https://example.com"

    def test_route_action_override(self):
        action = RouteActionOverride(
            type="override",
            status=200,
            headers={"Content-Type": "application/json"},
            body='{"result": "ok"}'
        )
        assert action.status == 200
        assert action.headers["Content-Type"] == "application/json"
        assert action.body == '{"result": "ok"}'

    def test_route_action_override_invalid_status(self):
        with pytest.raises(ValidationError):
            RouteActionOverride(type="override", status=99)

        with pytest.raises(ValidationError):
            RouteActionOverride(type="override", status=600)

    def test_route_action_inspect(self):
        action = RouteActionInspect(type="inspect", capture_body=True)
        assert action.type == "inspect"
        assert action.capture_body is True

    def test_route_action_inspect_default(self):
        action = RouteActionInspect(type="inspect")
        assert action.capture_body is False


class TestRouteCreate:
    def test_route_create_block(self):
        route = RouteCreate(
            pattern="**/*.{png,jpg}",
            action=RouteActionBlock(type="block")
        )
        assert route.pattern == "**/*.{png,jpg}"
        assert route.action.type == "block"

    def test_route_create_redirect(self):
        route = RouteCreate(
            pattern="**/api/old",
            action=RouteActionRedirect(type="redirect", url="https://new.api")
        )
        assert route.action.url == "https://new.api"


class TestCookie:
    def test_cookie_minimal(self):
        cookie = Cookie(
            name="session",
            value="abc123",
            domain=".example.com",
            path="/"
        )
        assert cookie.name == "session"
        assert cookie.httpOnly is False
        assert cookie.secure is False
        assert cookie.sameSite is None

    def test_cookie_full(self):
        cookie = Cookie(
            name="session",
            value="abc123",
            domain=".example.com",
            path="/",
            expires=1234567890,
            httpOnly=True,
            secure=True,
            sameSite="Lax"
        )
        assert cookie.httpOnly is True
        assert cookie.secure is True
        assert cookie.sameSite == "Lax"


class TestProfileState:
    def test_profile_state_empty(self):
        state = ProfileState(profile_id="user-123")
        assert state.profile_id == "user-123"
        assert state.cookies == []
        assert state.localStorage == []
        assert state.sessionStorage == []

    def test_profile_state_with_data(self):
        state = ProfileState(
            profile_id="user-123",
            cookies=[
                Cookie(
                    name="session",
                    value="abc",
                    domain=".example.com",
                    path="/"
                )
            ],
            localStorage=[
                LocalStorageOrigin(
                    origin="https://example.com",
                    items=[StorageItem(key="theme", value="dark")]
                )
            ]
        )
        assert len(state.cookies) == 1
        assert len(state.localStorage) == 1
        assert state.localStorage[0].items[0].key == "theme"


class TestExtensionInfo:
    def test_extension_info_minimal(self):
        ext = ExtensionInfo(
            extension_id="ext-123",
            name="Test Extension",
            version="1.0.0",
            manifest_version=3,
            file_size=12345
        )
        assert ext.extension_id == "ext-123"
        assert ext.description is None
        assert ext.permissions == []

    def test_extension_info_full(self):
        ext = ExtensionInfo(
            extension_id="ext-123",
            name="uBlock Origin",
            version="1.54.0",
            description="An efficient blocker",
            manifest_version=3,
            permissions=["storage", "webRequest"],
            file_size=12345678
        )
        assert ext.description == "An efficient blocker"
        assert len(ext.permissions) == 2


class TestModelSerialization:
    def test_session_create_to_dict(self):
        session = SessionCreate(
            profile_id="user-123",
            timeout=7200
        )
        data = session.model_dump()
        assert data['profile_id'] == "user-123"
        assert data['timeout'] == 7200

    def test_session_create_to_json(self):
        session = SessionCreate(profile_id="user-123")
        json_str = session.model_dump_json()
        assert '"profile_id":"user-123"' in json_str

    def test_route_action_discriminated_union(self):
        block_route = RouteCreate(
            pattern="**/*.png",
            action=RouteActionBlock(type="block")
        )
        data = block_route.model_dump()
        assert data['action']['type'] == "block"

        redirect_route = RouteCreate(
            pattern="**/*.png",
            action=RouteActionRedirect(type="redirect", url="https://example.com")
        )
        data = redirect_route.model_dump()
        assert data['action']['type'] == "redirect"
        assert data['action']['url'] == "https://example.com"


class TestResponseModels:
    def test_goto_response(self):
        resp = GotoResponse(
            status="ok",
            url="https://example.com",
            title="Example",
            load_time_ms=1234
        )
        assert resp.status == "ok"
        assert resp.load_time_ms == 1234

    def test_click_response(self):
        resp = ClickResponse(
            status="ok",
            selector=Selector(strategy="css", value="#btn")
        )
        assert resp.status == "ok"

    def test_session_close_response(self):
        resp = SessionCloseResponse(
            status="closed",
            session_id="abc-123"
        )
        assert resp.status == "closed"

    def test_profile_import_response(self):
        resp = ProfileImportResponse(
            status="imported",
            profile_id="user-123",
            imported={"cookies": 5, "localStorage_origins": 2}
        )
        assert resp.imported["cookies"] == 5

    def test_extension_delete_response(self):
        resp = ExtensionDeleteResponse(
            status="deleted",
            extension_id="ext-123"
        )
        assert resp.status == "deleted"


class TestInspectedRequest:
    def test_inspected_request_full(self):
        now = datetime.now(timezone.utc)
        req = InspectedRequest(
            timestamp=now,
            method="GET",
            url="https://api.example.com/data",
            headers={"Authorization": "Bearer token"},
            body=None,
            response=InspectedResponse(
                status=200,
                headers={"Content-Type": "application/json"},
                body='{"result": "ok"}'
            ),
            timing=RequestTiming(
                start_time=now,
                end_time=now,
                duration_ms=150
            )
        )
        assert req.method == "GET"
        assert req.response.status == 200
        assert req.timing.duration_ms == 150
