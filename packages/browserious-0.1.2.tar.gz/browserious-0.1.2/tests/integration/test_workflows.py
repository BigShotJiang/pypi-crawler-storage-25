import pytest


@pytest.mark.anyio
async def test_session_lifecycle_requires_auth(client):
    response = await client.post("/sessions")
    assert response.status_code == 401


@pytest.mark.anyio
async def test_profile_export_requires_auth(client):
    response = await client.get("/profiles/test/state")
    assert response.status_code == 401


@pytest.mark.anyio
async def test_extension_list_requires_auth(client):
    response = await client.get("/extensions")
    assert response.status_code == 401


@pytest.mark.anyio
async def test_route_creation_requires_auth(client):
    response = await client.post("/sessions/test/routes", json={
        "pattern": "**/*",
        "action": {"type": "block"}
    })
    assert response.status_code == 401
