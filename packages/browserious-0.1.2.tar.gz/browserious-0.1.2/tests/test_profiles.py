import json
import pytest
from unittest.mock import AsyncMock

from src.profile_manager import ProfileManager


@pytest.fixture
def profile_manager(tmp_path):
    return ProfileManager(str(tmp_path / "profiles"))


@pytest.mark.anyio
async def test_export_state_from_context(profile_manager):
    mock_context = AsyncMock()
    mock_context.storage_state = AsyncMock(return_value={
        "cookies": [{"name": "test", "value": "value", "domain": "example.com"}],
        "origins": [
            {
                "origin": "https://example.com",
                "localStorage": [{"name": "key1", "value": "val1"}]
            }
        ]
    })

    state = await profile_manager.export_state("test-profile", mock_context)

    assert state["profile_id"] == "test-profile"
    assert len(state["cookies"]) == 1
    assert len(state["localStorage"]) == 1
    assert state["localStorage"][0]["origin"] == "https://example.com"


@pytest.mark.anyio
async def test_export_state_from_file(profile_manager, tmp_path):
    profiles_dir = tmp_path / "profiles"
    profile_dir = profiles_dir / "saved-profile"
    profile_dir.mkdir(parents=True)

    state_data = {
        "cookies": [{"name": "saved", "value": "cookie"}],
        "origins": []
    }
    with open(profile_dir / "state.json", "w") as f:
        json.dump(state_data, f)

    state = await profile_manager.export_state("saved-profile")

    assert state["profile_id"] == "saved-profile"
    assert len(state["cookies"]) == 1


@pytest.mark.anyio
async def test_export_state_no_file(profile_manager):
    state = await profile_manager.export_state("new-profile")

    assert state["profile_id"] == "new-profile"
    assert state["cookies"] == []
    assert state["localStorage"] == []


@pytest.mark.anyio
async def test_import_state(profile_manager, tmp_path):
    state = {
        "cookies": [{"name": "test", "value": "cookie"}],
        "localStorage": [
            {
                "origin": "https://example.com",
                "items": [{"key": "k1", "value": "v1"}]
            }
        ]
    }

    await profile_manager.import_state("import-test", state)

    state_file = tmp_path / "profiles" / "import-test" / "state.json"
    assert state_file.exists()

    with open(state_file) as f:
        saved = json.load(f)

    assert len(saved["cookies"]) == 1
    assert len(saved["origins"]) == 1


def test_delete_profile(profile_manager, tmp_path):
    profiles_dir = tmp_path / "profiles"
    profile_dir = profiles_dir / "to-delete"
    profile_dir.mkdir(parents=True)
    (profile_dir / "state.json").write_text("{}")

    assert profile_manager.profile_exists("to-delete")

    profile_manager.delete_profile("to-delete")

    assert not profile_manager.profile_exists("to-delete")


def test_delete_nonexistent_profile(profile_manager):
    result = profile_manager.delete_profile("nonexistent")
    assert result is False


@pytest.mark.anyio
async def test_profile_endpoints_require_auth(client):
    response = await client.get("/profiles/test/state")
    assert response.status_code == 401

    response = await client.put("/profiles/test/state", json={})
    assert response.status_code == 401

    response = await client.delete("/profiles/test")
    assert response.status_code == 401


@pytest.mark.anyio
async def test_delete_nonexistent_profile_endpoint(client):
    response = await client.delete(
        "/profiles/nonexistent",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404
