import pytest
from unittest.mock import MagicMock

from src.models import Selector
from src.selectors import SelectorStrategy


@pytest.fixture
def mock_page():
    page = MagicMock()
    page.locator = MagicMock(return_value=MagicMock())
    return page


def test_css_selector(mock_page):
    selector = Selector(strategy="css", value="button.submit")
    SelectorStrategy.locate(mock_page, selector)
    mock_page.locator.assert_called_once_with("button.submit")


def test_xpath_selector(mock_page):
    selector = Selector(strategy="xpath", value="//button[@class='submit']")
    SelectorStrategy.locate(mock_page, selector)
    mock_page.locator.assert_called_once_with("xpath=//button[@class='submit']")


def test_text_selector(mock_page):
    selector = Selector(strategy="text", value="Submit")
    SelectorStrategy.locate(mock_page, selector)
    mock_page.locator.assert_called_once_with("text=Submit")


def test_role_selector(mock_page):
    selector = Selector(strategy="role", value="role=button[name='Submit']")
    SelectorStrategy.locate(mock_page, selector)
    mock_page.locator.assert_called_once_with("role=button[name='Submit']")


def test_js_selector(mock_page):
    selector = Selector(strategy="js", value="() => document.querySelector('button')")
    SelectorStrategy.locate(mock_page, selector)
    mock_page.locator.assert_called_once_with("js=() => document.querySelector('button')")


def test_invalid_strategy(mock_page):
    with pytest.raises(ValueError, match="Unknown selector strategy"):
        selector = MagicMock()
        selector.strategy = "invalid"
        selector.value = "test"
        SelectorStrategy.locate(mock_page, selector)


def test_selector_model_validation():
    selector = Selector(strategy="css", value="button")
    assert selector.strategy == "css"
    assert selector.value == "button"


def test_selector_model_invalid_strategy():
    with pytest.raises(ValueError):
        Selector(strategy="invalid", value="button")
