import pytest
from unittest.mock import AsyncMock

from src.route_manager import RouteManager
from src.models import RouteActionBlock, RouteActionRedirect, RouteActionOverride, RouteActionInspect


@pytest.fixture
def route_manager():
    return RouteManager()


@pytest.fixture
def mock_context():
    context = AsyncMock()
    context.route = AsyncMock()
    context.unroute = AsyncMock()
    return context


@pytest.mark.anyio
async def test_register_block_route(route_manager, mock_context):
    action = RouteActionBlock(type="block")
    route_id = await route_manager.register_route(mock_context, "**/*.png", action)

    assert route_id is not None
    assert route_id in route_manager.routes
    assert route_manager.routes[route_id].pattern == "**/*.png"
    mock_context.route.assert_called_once()


@pytest.mark.anyio
async def test_register_redirect_route(route_manager, mock_context):
    action = RouteActionRedirect(type="redirect", url="https://example.com/redirect")
    route_id = await route_manager.register_route(mock_context, "**/*.js", action)

    assert route_id is not None
    assert route_manager.routes[route_id].action.type == "redirect"
    assert route_manager.routes[route_id].action.url == "https://example.com/redirect"


@pytest.mark.anyio
async def test_register_override_route(route_manager, mock_context):
    action = RouteActionOverride(type="override", status=200, body="mocked response")
    route_id = await route_manager.register_route(mock_context, "**/api/*", action)

    assert route_id is not None
    assert route_manager.routes[route_id].action.type == "override"
    assert route_manager.routes[route_id].action.status == 200


@pytest.mark.anyio
async def test_register_inspect_route(route_manager, mock_context):
    action = RouteActionInspect(type="inspect", capture_body=True)
    route_id = await route_manager.register_route(mock_context, "**/*", action)

    assert route_id is not None
    assert route_manager.routes[route_id].action.type == "inspect"
    assert route_manager.routes[route_id].action.capture_body is True


@pytest.mark.anyio
async def test_unregister_route(route_manager, mock_context):
    action = RouteActionBlock(type="block")
    route_id = await route_manager.register_route(mock_context, "**/*.png", action)

    assert route_id in route_manager.routes

    await route_manager.unregister_route(mock_context, route_id)

    assert route_id not in route_manager.routes
    mock_context.unroute.assert_called_once()


@pytest.mark.anyio
async def test_list_routes(route_manager, mock_context):
    action1 = RouteActionBlock(type="block")
    action2 = RouteActionRedirect(type="redirect", url="https://example.com")

    await route_manager.register_route(mock_context, "**/*.png", action1)
    await route_manager.register_route(mock_context, "**/*.js", action2)

    routes = route_manager.list_routes()

    assert len(routes) == 2


@pytest.mark.anyio
async def test_get_route(route_manager, mock_context):
    action = RouteActionBlock(type="block")
    route_id = await route_manager.register_route(mock_context, "**/*.png", action)

    route_info = route_manager.get_route(route_id)

    assert route_info is not None
    assert route_info.pattern == "**/*.png"


@pytest.mark.anyio
async def test_get_nonexistent_route(route_manager):
    route_info = route_manager.get_route("nonexistent")
    assert route_info is None


@pytest.mark.anyio
async def test_route_endpoints_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/routes",
        headers={"X-API-Key": "test-api-key"},
        json={"pattern": "**/*", "action": {"type": "block"}},
    )
    assert response.status_code == 404


@pytest.mark.anyio
async def test_list_routes_session_not_found(client):
    response = await client.get(
        "/sessions/nonexistent/routes",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404


@pytest.mark.anyio
async def test_delete_route_session_not_found(client):
    response = await client.delete(
        "/sessions/nonexistent/routes/some-route-id",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404


@pytest.mark.anyio
async def test_inspect_route_session_not_found(client):
    response = await client.get(
        "/sessions/nonexistent/routes/some-route-id/inspect",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404


@pytest.mark.anyio
async def test_route_endpoints_require_auth(client):
    endpoints = [
        ("POST", "/sessions/test/routes"),
        ("GET", "/sessions/test/routes"),
        ("DELETE", "/sessions/test/routes/route-id"),
        ("GET", "/sessions/test/routes/route-id/inspect"),
    ]

    for method, path in endpoints:
        if method == "POST":
            response = await client.post(path, json={"pattern": "**/*", "action": {"type": "block"}})
        elif method == "DELETE":
            response = await client.delete(path)
        else:
            response = await client.get(path)
        assert response.status_code == 401, f"Expected 401 for {method} {path}"
