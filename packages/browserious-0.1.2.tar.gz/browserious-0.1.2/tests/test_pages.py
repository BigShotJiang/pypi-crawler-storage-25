import pytest


@pytest.mark.anyio
async def test_create_page_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/pages",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_list_pages_session_not_found(client):
    response = await client.get(
        "/sessions/nonexistent/pages",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_goto_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/pages/page-0/goto",
        headers={"X-API-Key": "test-api-key"},
        json={"url": "https://example.com"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_click_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/pages/page-0/click",
        headers={"X-API-Key": "test-api-key"},
        json={"selector": {"strategy": "css", "value": "button"}},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_type_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/pages/page-0/type",
        headers={"X-API-Key": "test-api-key"},
        json={"selector": {"strategy": "css", "value": "input"}, "text": "hello"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_fill_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/pages/page-0/fill",
        headers={"X-API-Key": "test-api-key"},
        json={"selector": {"strategy": "css", "value": "input"}, "value": "hello"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_wait_for_selector_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/pages/page-0/waitForSelector",
        headers={"X-API-Key": "test-api-key"},
        json={"selector": {"strategy": "css", "value": "button"}},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_eval_session_not_found(client):
    response = await client.post(
        "/sessions/nonexistent/pages/page-0/eval",
        headers={"X-API-Key": "test-api-key"},
        json={"script": "return 1"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_screenshot_session_not_found(client):
    response = await client.get(
        "/sessions/nonexistent/screenshot",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_content_session_not_found(client):
    response = await client.get(
        "/sessions/nonexistent/pages/page-0/content",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "Session not found"


@pytest.mark.anyio
async def test_page_requires_auth(client):
    endpoints = [
        ("POST", "/sessions/test/pages"),
        ("GET", "/sessions/test/pages"),
        ("POST", "/sessions/test/pages/page-0/goto"),
        ("POST", "/sessions/test/pages/page-0/click"),
        ("POST", "/sessions/test/pages/page-0/type"),
        ("POST", "/sessions/test/pages/page-0/fill"),
        ("POST", "/sessions/test/pages/page-0/waitForSelector"),
        ("POST", "/sessions/test/pages/page-0/eval"),
        ("GET", "/sessions/test/screenshot"),
        ("GET", "/sessions/test/pages/page-0/content"),
    ]

    for method, path in endpoints:
        if method == "POST":
            response = await client.post(path, json={})
        else:
            response = await client.get(path)
        assert response.status_code == 401, f"Expected 401 for {method} {path}"


@pytest.mark.anyio
async def test_goto_request_validation(client):
    response = await client.post(
        "/sessions/test/pages/page-0/goto",
        headers={"X-API-Key": "test-api-key"},
        json={},
    )
    assert response.status_code == 422


@pytest.mark.anyio
async def test_click_request_validation(client):
    response = await client.post(
        "/sessions/test/pages/page-0/click",
        headers={"X-API-Key": "test-api-key"},
        json={},
    )
    assert response.status_code == 422


@pytest.mark.anyio
async def test_eval_request_validation(client):
    response = await client.post(
        "/sessions/test/pages/page-0/eval",
        headers={"X-API-Key": "test-api-key"},
        json={},
    )
    assert response.status_code == 422
