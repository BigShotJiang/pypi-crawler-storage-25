import asyncio
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, patch

import pytest

from src.backend_provider import BackendRegistry, BackendSession
from src.browser_manager import BrowserManager


def _mock_backend():
    backend = AsyncMock()
    backend.create_session = AsyncMock(
        side_effect=lambda session_id, container_name, environment, volumes, **kw: BackendSession(
            session_id=session_id,
            host="172.17.0.2",
            backend_id=f"container-{session_id[:8]}",
        )
    )
    backend.terminate_session = AsyncMock()
    backend.health_check = AsyncMock(return_value={"status": "ok"})
    return backend


def _make_manager():
    backend = _mock_backend()
    registry = BackendRegistry()
    registry.register("byom", backend)
    manager = BrowserManager(registry=registry)
    manager.playwright = AsyncMock()
    context = AsyncMock()
    context.pages = []
    browser = AsyncMock()
    browser.contexts = [context]
    manager.playwright.chromium.connect_over_cdp = AsyncMock(return_value=browser)
    return manager


@pytest.mark.anyio
async def test_cleanup_closes_expired_sessions():
    manager = _make_manager()
    with patch.object(manager, '_wait_for_cdp', new_callable=AsyncMock):
        session1 = await manager.create_session(timeout=1)
        session2 = await manager.create_session(timeout=3600)

        await asyncio.sleep(1.5)

        now = datetime.utcnow()
        expired = [
            sid for sid, s in manager.sessions.items()
            if s.expires_at <= now
        ]
        for sid in expired:
            await manager.close_session(sid)

        assert session1.session_id not in manager.sessions
        assert session2.session_id in manager.sessions


@pytest.mark.anyio
async def test_cleanup_task_runs_periodically():
    manager = _make_manager()
    with patch.object(manager, '_wait_for_cdp', new_callable=AsyncMock):
        with patch.object(manager, 'close_session', new_callable=AsyncMock) as mock_close:
            session = await manager.create_session(timeout=60)
            session.expires_at = datetime.utcnow() - timedelta(seconds=1)

            with patch('src.browser_manager.asyncio.sleep', new_callable=AsyncMock) as mock_sleep:
                mock_sleep.side_effect = [None, asyncio.CancelledError()]

                with pytest.raises(asyncio.CancelledError):
                    await manager.cleanup_expired_sessions()

                mock_close.assert_called_once_with(session.session_id)


@pytest.mark.anyio
async def test_cleanup_only_closes_expired_not_active():
    manager = _make_manager()
    with patch.object(manager, '_wait_for_cdp', new_callable=AsyncMock):
        session1 = await manager.create_session(timeout=3600)
        session2 = await manager.create_session(timeout=3600)
        session3 = await manager.create_session(timeout=3600)

        session1.expires_at = datetime.utcnow() - timedelta(seconds=10)
        session3.expires_at = datetime.utcnow() - timedelta(seconds=5)

        now = datetime.utcnow()
        expired = [
            sid for sid, s in manager.sessions.items()
            if s.expires_at <= now
        ]
        for sid in expired:
            await manager.close_session(sid)

        assert session1.session_id not in manager.sessions
        assert session2.session_id in manager.sessions
        assert session3.session_id not in manager.sessions
        assert len(manager.sessions) == 1
