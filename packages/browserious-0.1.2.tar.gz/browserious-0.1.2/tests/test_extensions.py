import io
import json
import zipfile
import pytest

from src.extension_manager import ExtensionManager


@pytest.fixture
def extension_manager(tmp_path):
    return ExtensionManager(str(tmp_path / "extensions"))


@pytest.fixture
def valid_extension_zip():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as zf:
        manifest = {
            "name": "Test Extension",
            "version": "1.0.0",
            "description": "A test extension",
            "manifest_version": 3,
            "permissions": ["storage"],
        }
        zf.writestr("manifest.json", json.dumps(manifest))
        zf.writestr("background.js", "console.log('test');")
    return buffer.getvalue()


@pytest.fixture
def invalid_extension_zip():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as zf:
        zf.writestr("readme.txt", "This is not an extension")
    return buffer.getvalue()


@pytest.mark.anyio
async def test_upload_valid_extension(extension_manager, valid_extension_zip):
    result = await extension_manager.upload_extension(valid_extension_zip, "test.zip")

    assert result["name"] == "Test Extension"
    assert result["version"] == "1.0.0"
    assert result["manifest_version"] == 3
    assert "extension_id" in result
    assert result["extension_id"].startswith("ext-")


@pytest.mark.anyio
async def test_upload_extension_without_manifest(extension_manager, invalid_extension_zip):
    with pytest.raises(ValueError, match="manifest.json not found"):
        await extension_manager.upload_extension(invalid_extension_zip, "invalid.zip")


@pytest.mark.anyio
async def test_list_extensions(extension_manager, valid_extension_zip):
    await extension_manager.upload_extension(valid_extension_zip, "test1.zip")
    await extension_manager.upload_extension(valid_extension_zip, "test2.zip")

    extensions = extension_manager.list_extensions()

    assert len(extensions) == 2


@pytest.mark.anyio
async def test_delete_extension(extension_manager, valid_extension_zip):
    result = await extension_manager.upload_extension(valid_extension_zip, "test.zip")

    extension_id = result["extension_id"]
    assert extension_manager.extension_exists(extension_id)

    extension_manager.delete_extension(extension_id)
    assert not extension_manager.extension_exists(extension_id)


@pytest.mark.anyio
async def test_get_extension_path(extension_manager, valid_extension_zip):
    result = await extension_manager.upload_extension(valid_extension_zip, "test.zip")

    extension_id = result["extension_id"]
    path = extension_manager.get_extension_path(extension_id)

    assert path is not None
    assert path.exists()


def test_get_nonexistent_extension_path(extension_manager):
    path = extension_manager.get_extension_path("nonexistent")
    assert path is None


@pytest.mark.anyio
async def test_extension_endpoint_requires_auth(client):
    response = await client.get("/extensions")
    assert response.status_code == 401

    response = await client.delete("/extensions/test-id")
    assert response.status_code == 401


@pytest.mark.anyio
async def test_delete_nonexistent_extension(client):
    response = await client.delete(
        "/extensions/nonexistent",
        headers={"X-API-Key": "test-api-key"},
    )
    assert response.status_code == 404
