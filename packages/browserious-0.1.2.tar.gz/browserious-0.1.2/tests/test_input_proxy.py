import pytest
from datetime import datetime, timedelta
from unittest.mock import patch, AsyncMock, MagicMock

from src.browser_manager import manager, BrowserSession


@pytest.fixture
def mock_session():
    now = datetime.utcnow()
    session = BrowserSession(
        session_id="test-session-123",
        profile_id="test-profile",
        container_id="container-123",
        container_name="session-test-session",
        container_ip="172.17.0.2",
        created_at=now,
        expires_at=now + timedelta(seconds=3600),
        context=AsyncMock(),
        browser=AsyncMock(),
        viewport={"width": 1920, "height": 1080},
        proxy=None,
        extensions=[],
    )
    return session


@pytest.mark.anyio
async def test_play_success(client, mock_session):
    with patch.object(manager, "get_session", return_value=mock_session):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "ok", "executed": 3, "duration_ms": 500}

        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(return_value=mock_response)

        with patch("src.input_proxy.httpx.AsyncClient", return_value=mock_http_client):
            response = await client.post(
                "/sessions/test-session-123/input/play",
                json={
                    "actions": [
                        {"type": "move", "x": 100, "y": 200, "duration_ms": 200},
                        {"type": "sleep", "duration_ms": 50},
                        {"type": "click", "button": 1}
                    ]
                },
                headers={"X-API-Key": "test-api-key"}
            )

            assert response.status_code == 200
            data = response.json()
            assert data["status"] == "ok"
            assert data["executed"] == 3
            assert data["duration_ms"] == 500


@pytest.mark.anyio
async def test_play_session_not_found(client):
    with patch.object(manager, "get_session", return_value=None):
        response = await client.post(
            "/sessions/nonexistent/input/play",
            json={"actions": [{"type": "click", "button": 1}]},
            headers={"X-API-Key": "test-api-key"}
        )
        assert response.status_code == 404


@pytest.mark.anyio
async def test_play_invalid_empty_actions(client):
    response = await client.post(
        "/sessions/test-session/input/play",
        json={"actions": []},
        headers={"X-API-Key": "test-api-key"}
    )
    assert response.status_code == 422


@pytest.mark.anyio
async def test_play_invalid_action_type(client):
    response = await client.post(
        "/sessions/test-session-123/input/play",
        json={"actions": [{"type": "invalid_action"}]},
        headers={"X-API-Key": "test-api-key"}
    )
    assert response.status_code == 422


@pytest.mark.anyio
async def test_play_with_easing(client, mock_session):
    with patch.object(manager, "get_session", return_value=mock_session):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "ok", "executed": 1, "duration_ms": 200}

        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(return_value=mock_response)

        with patch("src.input_proxy.httpx.AsyncClient", return_value=mock_http_client):
            response = await client.post(
                "/sessions/test-session-123/input/play",
                json={
                    "actions": [
                        {
                            "type": "move",
                            "x": 500,
                            "y": 300,
                            "duration_ms": 200,
                            "easing": {"x": "ease_out_cubic", "y": "linear"}
                        }
                    ]
                },
                headers={"X-API-Key": "test-api-key"}
            )

            assert response.status_code == 200
            data = response.json()
            assert data["status"] == "ok"


@pytest.mark.anyio
async def test_play_type_text_action(client, mock_session):
    with patch.object(manager, "get_session", return_value=mock_session):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "ok", "executed": 1, "duration_ms": 1000}

        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(return_value=mock_response)

        with patch("src.input_proxy.httpx.AsyncClient", return_value=mock_http_client):
            response = await client.post(
                "/sessions/test-session-123/input/play",
                json={
                    "actions": [
                        {
                            "type": "type_text",
                            "text": "hello world",
                            "interval": {"min_ms": 50, "max_ms": 150}
                        }
                    ]
                },
                headers={"X-API-Key": "test-api-key"}
            )

            assert response.status_code == 200
            data = response.json()
            assert data["status"] == "ok"


@pytest.mark.anyio
async def test_play_scroll_action(client, mock_session):
    with patch.object(manager, "get_session", return_value=mock_session):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "ok", "executed": 1, "duration_ms": 10}

        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(return_value=mock_response)

        with patch("src.input_proxy.httpx.AsyncClient", return_value=mock_http_client):
            response = await client.post(
                "/sessions/test-session-123/input/play",
                json={
                    "actions": [
                        {"type": "scroll", "delta_x": 0, "delta_y": 5}
                    ]
                },
                headers={"X-API-Key": "test-api-key"}
            )

            assert response.status_code == 200
            data = response.json()
            assert data["status"] == "ok"


@pytest.mark.anyio
async def test_play_node_api_error(client, mock_session):
    with patch.object(manager, "get_session", return_value=mock_session):
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"error": "xdotool command failed"}

        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(return_value=mock_response)

        with patch("src.input_proxy.httpx.AsyncClient", return_value=mock_http_client):
            response = await client.post(
                "/sessions/test-session-123/input/play",
                json={
                    "actions": [{"type": "click", "button": 1}]
                },
                headers={"X-API-Key": "test-api-key"}
            )

            assert response.status_code == 502


@pytest.mark.anyio
async def test_play_requires_auth(client):
    response = await client.post(
        "/sessions/test-session-123/input/play",
        json={"actions": [{"type": "click", "button": 1}]}
    )
    assert response.status_code == 401


@pytest.mark.anyio
async def test_play_node_api_timeout(client, mock_session):
    import httpx as httpx_module

    with patch.object(manager, "get_session", return_value=mock_session):
        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(side_effect=httpx_module.TimeoutException("timeout"))

        with patch("src.input_proxy.httpx.AsyncClient", return_value=mock_http_client):
            response = await client.post(
                "/sessions/test-session-123/input/play",
                json={
                    "actions": [{"type": "click", "button": 1}]
                },
                headers={"X-API-Key": "test-api-key"}
            )

            assert response.status_code == 504
