import pytest
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

from src.browser_manager import BrowserManager, manager


@pytest.fixture
def mock_docker_client():
    client = MagicMock()
    client.networks.get = MagicMock()
    container = MagicMock()
    container.id = "test-container-id-12345"
    container.attrs = {
        'NetworkSettings': {
            'Networks': {
                'browserious': {'IPAddress': '172.17.0.2'}
            },
            'Ports': {
                '9222/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '49222'}],
                '5900/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '45900'}],
                '8080/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '48080'}],
            }
        }
    }
    container.reload = MagicMock()
    client.containers.run = MagicMock(return_value=container)
    client.containers.get = MagicMock(return_value=container)
    return client


@pytest.fixture
def mock_playwright():
    pw = AsyncMock()
    browser = AsyncMock()
    context = AsyncMock()
    context.pages = []
    browser.contexts = [context]
    pw.chromium.connect_over_cdp = AsyncMock(return_value=browser)
    return pw


@pytest.fixture
def browser_manager():
    return BrowserManager()


@pytest.mark.anyio
async def test_playwright_initialization(browser_manager):
    assert browser_manager.playwright is None
    assert browser_manager.provider is not None


@pytest.mark.anyio
async def test_session_creation_with_defaults(browser_manager, mock_docker_client, mock_playwright):
    with patch('src.backends.byom.docker') as mock_docker_module, \
         patch('src.browser_manager.async_playwright') as mock_async_playwright, \
         patch.object(browser_manager, '_wait_for_cdp', new_callable=AsyncMock):

        mock_docker_module.from_env.return_value = mock_docker_client
        mock_async_playwright.return_value.start = AsyncMock(return_value=mock_playwright)
        browser_manager.provider.docker_client = mock_docker_client
        browser_manager.playwright = mock_playwright

        session = await browser_manager.create_session()

        assert session.session_id is not None
        assert session.profile_id == session.session_id
        assert session.container_id == "test-container-id-12345"
        assert session.container_name.startswith("session-")
        assert isinstance(session.created_at, datetime)
        assert isinstance(session.expires_at, datetime)
        assert session.expires_at > session.created_at


@pytest.mark.anyio
async def test_session_creation_with_custom_profile_id(browser_manager, mock_docker_client, mock_playwright):
    with patch('src.backends.byom.docker') as mock_docker_module, \
         patch('src.browser_manager.async_playwright') as mock_async_playwright, \
         patch.object(browser_manager, '_wait_for_cdp', new_callable=AsyncMock):

        mock_docker_module.from_env.return_value = mock_docker_client
        mock_async_playwright.return_value.start = AsyncMock(return_value=mock_playwright)
        browser_manager.provider.docker_client = mock_docker_client
        browser_manager.playwright = mock_playwright

        profile_id = "test-profile-123"
        session = await browser_manager.create_session(profile_id=profile_id)

        assert session.profile_id == profile_id
        assert session.session_id != profile_id


@pytest.mark.anyio
async def test_session_creation_with_proxy(browser_manager, mock_docker_client, mock_playwright):
    with patch('src.backends.byom.docker') as mock_docker_module, \
         patch('src.browser_manager.async_playwright') as mock_async_playwright, \
         patch.object(browser_manager, '_wait_for_cdp', new_callable=AsyncMock):

        mock_docker_module.from_env.return_value = mock_docker_client
        mock_async_playwright.return_value.start = AsyncMock(return_value=mock_playwright)
        browser_manager.provider.docker_client = mock_docker_client
        browser_manager.playwright = mock_playwright

        proxy = {"server": "http://proxy.example.com:8080"}

        await browser_manager.create_session(proxy=proxy)

        call_args = mock_docker_client.containers.run.call_args
        env = call_args.kwargs.get('environment', {})
        assert env.get('PROXY_SERVER') == "http://proxy.example.com:8080"


@pytest.mark.anyio
async def test_session_retrieval(browser_manager, mock_docker_client, mock_playwright):
    with patch('src.backends.byom.docker') as mock_docker_module, \
         patch('src.browser_manager.async_playwright') as mock_async_playwright, \
         patch.object(browser_manager, '_wait_for_cdp', new_callable=AsyncMock):

        mock_docker_module.from_env.return_value = mock_docker_client
        mock_async_playwright.return_value.start = AsyncMock(return_value=mock_playwright)
        browser_manager.provider.docker_client = mock_docker_client
        browser_manager.playwright = mock_playwright

        session = await browser_manager.create_session()

        retrieved = await browser_manager.get_session(session.session_id)
        assert retrieved == session

        not_found = await browser_manager.get_session("nonexistent")
        assert not_found is None


@pytest.mark.anyio
async def test_session_closure(browser_manager, mock_docker_client, mock_playwright):
    with patch('src.backends.byom.docker') as mock_docker_module, \
         patch('src.browser_manager.async_playwright') as mock_async_playwright, \
         patch.object(browser_manager, '_wait_for_cdp', new_callable=AsyncMock):

        mock_docker_module.from_env.return_value = mock_docker_client
        mock_async_playwright.return_value.start = AsyncMock(return_value=mock_playwright)
        browser_manager.provider.docker_client = mock_docker_client
        browser_manager.playwright = mock_playwright

        session = await browser_manager.create_session()
        session_id = session.session_id

        assert session_id in browser_manager.sessions

        await browser_manager.close_session(session_id)

        assert session_id not in browser_manager.sessions


@pytest.mark.anyio
async def test_multiple_concurrent_sessions(browser_manager, mock_docker_client, mock_playwright):
    with patch('src.backends.byom.docker') as mock_docker_module, \
         patch('src.browser_manager.async_playwright') as mock_async_playwright, \
         patch.object(browser_manager, '_wait_for_cdp', new_callable=AsyncMock):

        port_bindings = {
            '9222/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '49222'}],
            '5900/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '45900'}],
            '8080/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '48080'}],
        }
        container1 = MagicMock()
        container1.id = "container-1"
        container1.attrs = {'NetworkSettings': {'Networks': {'browserious': {'IPAddress': '172.17.0.2'}}, 'Ports': port_bindings}}
        container1.reload = MagicMock()
        container2 = MagicMock()
        container2.id = "container-2"
        container2.attrs = {'NetworkSettings': {'Networks': {'browserious': {'IPAddress': '172.17.0.3'}}, 'Ports': port_bindings}}
        container2.reload = MagicMock()
        container3 = MagicMock()
        container3.id = "container-3"
        container3.attrs = {'NetworkSettings': {'Networks': {'browserious': {'IPAddress': '172.17.0.4'}}, 'Ports': port_bindings}}
        container3.reload = MagicMock()
        mock_docker_client.containers.run = MagicMock(side_effect=[container1, container2, container3])

        mock_docker_module.from_env.return_value = mock_docker_client
        mock_async_playwright.return_value.start = AsyncMock(return_value=mock_playwright)
        browser_manager.provider.docker_client = mock_docker_client
        browser_manager.playwright = mock_playwright

        session1 = await browser_manager.create_session(profile_id="profile-1")
        session2 = await browser_manager.create_session(profile_id="profile-2")
        session3 = await browser_manager.create_session(profile_id="profile-3")

        assert len(browser_manager.sessions) == 3
        assert session1.session_id in browser_manager.sessions
        assert session2.session_id in browser_manager.sessions
        assert session3.session_id in browser_manager.sessions

        assert session1.profile_id == "profile-1"
        assert session2.profile_id == "profile-2"
        assert session3.profile_id == "profile-3"


def test_singleton_instance():
    assert manager is not None
    assert isinstance(manager, BrowserManager)
