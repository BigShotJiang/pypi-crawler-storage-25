import asyncio

import asyncpg
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.config import settings
from src.database import Base
from src.db_models import *  # noqa: F401,F403

TEST_DB_NAME = "browserious_test"


def _base_url():
    return settings.database_url.rsplit("/", 1)[0]


@pytest.fixture(scope="session")
def test_db_url():
    return f"{_base_url()}/{TEST_DB_NAME}"


@pytest.fixture(scope="session", autouse=True)
def _create_test_db(test_db_url):
    async def _setup():
        base = _base_url().replace("+asyncpg", "")
        conn = await asyncpg.connect(f"{base}/postgres")
        await conn.execute(f"DROP DATABASE IF EXISTS {TEST_DB_NAME}")
        await conn.execute(f"CREATE DATABASE {TEST_DB_NAME}")
        await conn.close()

    async def _teardown():
        base = _base_url().replace("+asyncpg", "")
        conn = await asyncpg.connect(f"{base}/postgres")
        await conn.execute(
            f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            f"WHERE datname = '{TEST_DB_NAME}' AND pid <> pg_backend_pid()"
        )
        await conn.execute(f"DROP DATABASE IF EXISTS {TEST_DB_NAME}")
        await conn.close()

    asyncio.run(_setup())
    yield
    asyncio.run(_teardown())


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def engine(_create_test_db, test_db_url):
    eng = create_async_engine(test_db_url, echo=False)
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    from src import database
    database.engine = eng
    database.async_session = async_sessionmaker(eng, class_=AsyncSession, expire_on_commit=False)

    yield eng

    await eng.dispose()


@pytest_asyncio.fixture(loop_scope="session")
async def db(engine):
    factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with factory() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture(loop_scope="session")
async def client(engine):
    from src.main import app

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
