import time
import pytest
from httpx import AsyncClient, ASGITransport
from fastapi import FastAPI, Depends
from src.auth import verify_api_key


app = FastAPI()


@app.get("/protected", dependencies=[Depends(verify_api_key)])
async def protected_endpoint():
    return {"message": "success"}


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest.mark.anyio
async def test_valid_api_key(client):
    response = await client.get("/protected", headers={"X-API-Key": "test-api-key"})
    assert response.status_code == 200
    assert response.json() == {"message": "success"}


@pytest.mark.anyio
async def test_invalid_api_key(client):
    response = await client.get("/protected", headers={"X-API-Key": "invalid-key"})
    assert response.status_code == 401
    assert response.json() == {"detail": "Invalid or missing API key"}


@pytest.mark.anyio
async def test_missing_api_key_header(client):
    response = await client.get("/protected")
    assert response.status_code == 401
    assert response.json() == {"detail": "Invalid or missing API key"}


@pytest.mark.anyio
async def test_empty_api_key(client):
    response = await client.get("/protected", headers={"X-API-Key": ""})
    assert response.status_code == 401
    assert response.json() == {"detail": "Invalid or missing API key"}


@pytest.mark.anyio
async def test_case_sensitive_api_key(client):
    response = await client.get("/protected", headers={"X-API-Key": "TEST-API-KEY"})
    assert response.status_code == 401
    assert response.json() == {"detail": "Invalid or missing API key"}


@pytest.mark.anyio
async def test_api_key_with_whitespace(client):
    response = await client.get("/protected", headers={"X-API-Key": " test-api-key "})
    assert response.status_code == 401
    assert response.json() == {"detail": "Invalid or missing API key"}


@pytest.mark.anyio
async def test_timing_attack_resistance(client):
    valid_key = "test-api-key"
    invalid_key = "wrong-api-key"

    times_valid = []
    times_invalid = []

    for _ in range(100):
        start = time.perf_counter()
        await client.get("/protected", headers={"X-API-Key": valid_key})
        times_valid.append(time.perf_counter() - start)

        start = time.perf_counter()
        await client.get("/protected", headers={"X-API-Key": invalid_key})
        times_invalid.append(time.perf_counter() - start)

    avg_valid = sum(times_valid) / len(times_valid)
    avg_invalid = sum(times_invalid) / len(times_invalid)

    ratio = max(avg_valid, avg_invalid) / min(avg_valid, avg_invalid)

    assert ratio < 2.0
