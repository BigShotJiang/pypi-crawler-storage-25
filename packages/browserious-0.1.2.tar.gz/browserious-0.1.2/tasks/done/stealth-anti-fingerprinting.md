# Browserious: Anti-Fingerprinting & Stealth Improvements

## Background

Tested browserious against [Fingerprint Pro Playground](https://demo.fingerprint.com/playground) to assess detection surface. Results below, followed by actionable tasks.

### What Passes (Not Detected)
- `navigator.webdriver` = `false`
- No `__playwright` or `__pw_*` globals
- User-Agent clean: `Chrome/131.0.0.0` (no `HeadlessChrome`)
- `navigator.plugins.length` = 5 (headless usually 0)
- `outerWidth/outerHeight` non-zero (1919×1079)
- Bot detection: not detected
- Incognito: not detected
- Browser tampering: not detected (anomalyScore 0.0045)

### What Gets Caught
| Signal | Value | Why It's Detected |
|--------|-------|-------------------|
| **Virtual Machine** | `true` | WebGL renderer = `SwiftShader`, datacenter IP |
| **Developer Tools** | `true` | CDP connection detected |
| **VPN** | `true` (after patching) | Timezone/OS mismatch when patched incorrectly |
| **WebGL renderer** | `SwiftShader Device (LLVM 10.0.0)` | No real GPU in container |
| **Suspect Score** | 22 (baseline), 26 (after naive patching) | Composite of above signals |

### Key Finding: Timing Problem
Post-load JS patching (`page_eval`) is **too late** — Fingerprint's JS agent snapshots timezone, WebGL, etc. on initial page load and phones home before any patches can run. We confirmed this when timezone patches applied via `page_eval` had zero effect on the server-side `originTimezone: "UTC"` value.

---

## Task 1: Container Timezone Support (`TZ` env var)

**Priority: High** — Simplest fix with biggest impact on VPN/timezone mismatch detection.

### Problem
Container runs with `TZ=UTC` by default. Fingerprint cross-references IP geolocation (New Jersey) against browser timezone (UTC) and flags the mismatch as VPN usage.

### Implementation

**`node/entrypoint.sh`** — Already inherits env vars. Just ensure `TZ` is set before Chrome launches (it already would be via Docker env).

**`src/models.py`** — Add `timezone` field to `SessionCreate`:
```python
class SessionCreate(BaseModel):
    # ... existing fields ...
    timezone: Optional[str] = None  # e.g. "America/New_York"
```

**`src/browser_manager.py`** — Pass `TZ` in container environment:
```python
# In create_session(), add to environment dict:
if timezone:
    environment["TZ"] = timezone
```

Also call Playwright's timezone override on the context for consistency:
```python
context_options = {"viewport": viewport}
if timezone:
    context_options["timezone_id"] = timezone
session.context = await browser.new_context(**context_options)
```

**`mcp_server.py`** — Add `timezone` param to `create_session` tool.

### Acceptance Criteria
- `new Date().getTimezoneOffset()` returns correct offset for the specified timezone
- `Intl.DateTimeFormat().resolvedOptions().timeZone` returns specified timezone
- Both values are correct from first page load (not patched after)

---

## Task 2: Pre-Navigation Script Injection (`add_init_script`)

**Priority: High** — Required for any JS-level stealth that must run before page scripts execute.

### Problem
`page_eval` runs JS after page load. Detection scripts (Fingerprint, DataDome, etc.) execute during page construction and capture the real browser state before any patches apply.

### Implementation

**New API endpoint:**
```
POST /sessions/{session_id}/pages/{page_id}/initScript
Body: { "script": "..." }
```

**`src/models.py`** — Add models:
```python
class InitScriptRequest(BaseModel):
    script: str

class InitScriptResponse(BaseModel):
    status: Literal['ok']
    script_id: str  # for potential removal later
```

**`src/main.py`** — New endpoint that calls Playwright's `page.add_init_script()`:
```python
@app.post("/sessions/{session_id}/pages/{page_id}/initScript")
async def add_init_script(session_id: str, page_id: str, req: InitScriptRequest):
    page = await get_page_by_id(session, page_id)
    await page.add_init_script(req.script)
    return InitScriptResponse(status="ok", script_id=...)
```

Consider also a **context-level** variant that applies to all pages:
```
POST /sessions/{session_id}/initScript
```
This calls `context.add_init_script()` instead, affecting all new pages in the session.

**`mcp_server.py`** — Add `add_init_script` tool.

### Acceptance Criteria
- Script executes before any page JS on `page_goto`
- Script persists across navigations on the same page
- Context-level variant applies to all new pages
- Works with WebGL, timezone, and other override scripts

---

## Task 3: Custom Chrome Launch Arguments

**Priority: Medium** — Enables flags like `--disable-blink-features=AutomationControlled`.

### Problem
`entrypoint.sh` builds `CHROME_ARGS` from specific env vars. No way to pass arbitrary Chrome flags from the API.

### Implementation

**`src/models.py`** — Add `chrome_args` to `SessionCreate`:
```python
class SessionCreate(BaseModel):
    # ... existing fields ...
    chrome_args: list[str] = Field(default_factory=list)
```

Validate against a denylist of dangerous flags (e.g. `--remote-debugging-address`, `--user-data-dir` which are already managed).

**`src/browser_manager.py`** — Pass as env var:
```python
if chrome_args:
    environment["EXTRA_CHROME_ARGS"] = " ".join(chrome_args)
```

**`node/entrypoint.sh`** — Append:
```bash
if [ -n "$EXTRA_CHROME_ARGS" ]; then
    CHROME_ARGS="$CHROME_ARGS $EXTRA_CHROME_ARGS"
fi
```

**`mcp_server.py`** — Add `chrome_args` param to `create_session`.

### Useful Default Args for Stealth
Consider making these defaults (or a `stealth: bool` toggle):
```
--disable-blink-features=AutomationControlled
--disable-features=AutomationControlled
```

### Acceptance Criteria
- Custom args passed through to Chrome in the container
- Dangerous flags (that conflict with managed settings) are rejected
- MCP tool exposes the parameter

---

## Task 4: WebGL Renderer Override

**Priority: Medium** — SwiftShader is the #1 VM detection signal.

### Problem
Container has no GPU → Chrome uses SwiftShader software renderer → WebGL renderer string reveals VM.

### Implementation

Best approach: provide this as a **built-in init script** that can be enabled via session config, since it requires `add_init_script` (Task 2) to work properly.

**`src/models.py`** — Add stealth config:
```python
class StealthConfig(BaseModel):
    webgl_vendor: Optional[str] = None   # e.g. "Google Inc. (NVIDIA Corporation)"
    webgl_renderer: Optional[str] = None # e.g. "ANGLE (NVIDIA, GeForce RTX 3060...)"

class SessionCreate(BaseModel):
    # ... existing fields ...
    stealth: Optional[StealthConfig] = None
```

**`src/browser_manager.py`** — After creating context, if stealth config has WebGL overrides, call `context.add_init_script()` with the WebGL spoofing + `toString()` protection script.

### Acceptance Criteria
- WebGL renderer/vendor return spoofed values
- `getParameter.toString()` returns `"function getParameter() { [native code] }"`
- Values are present from first page load (init script, not eval)

---

## Task 5: Locale & Language Configuration

**Priority: Low** — Supports consistent fingerprint alongside timezone.

### Problem
Container defaults to `en-US` with single language. A machine in New Jersey with only `["en-US"]` is fine, but if targeting other geolocations, language/locale must match.

### Implementation

**`src/models.py`** — Add to `SessionCreate`:
```python
class SessionCreate(BaseModel):
    # ... existing fields ...
    locale: Optional[str] = None   # e.g. "en-US"
    languages: Optional[list[str]] = None  # e.g. ["en-US", "en"]
```

**`src/browser_manager.py`** — Pass to Playwright context:
```python
context_options = {"viewport": viewport}
if locale:
    context_options["locale"] = locale
if timezone:
    context_options["timezone_id"] = timezone
```

And set `LANG` env var in the container for system-level locale.

**`node/entrypoint.sh`**:
```bash
if [ -n "$LANG_OVERRIDE" ]; then
    export LANG="$LANG_OVERRIDE"
fi
```

### Acceptance Criteria
- `navigator.languages` returns configured values
- `Intl.DateTimeFormat().resolvedOptions().locale` matches
- Consistent with timezone and geolocation

---

## Task 6: MCP Tool Parameter Parity

**Priority: Medium** — MCP `create_session` currently only exposes `timeout` and `profile_id`, missing many API features.

### Problem
The API's `SessionCreate` model supports `proxy`, `user_agent`, `viewport`, `extensions`, but the MCP tool doesn't pass them through.

### Implementation

Update `mcp_server.py` `create_session` to accept and forward all params:
```python
@mcp.tool()
async def create_session(
    timeout: int = 3600,
    profile_id: str | None = None,
    user_agent: str | None = None,
    timezone: str | None = None,        # Task 1
    locale: str | None = None,          # Task 5
    proxy_server: str | None = None,
    viewport_width: int = 1920,
    viewport_height: int = 1080,
    chrome_args: list[str] | None = None,  # Task 3
    stealth_webgl_renderer: str | None = None,  # Task 4
) -> dict:
```

### Acceptance Criteria
- All `SessionCreate` parameters accessible via MCP
- Existing MCP callers unaffected (all new params optional)

---

## Summary & Dependency Order

```
Task 1 (TZ env var)          — standalone, do first
Task 2 (init_script API)     — standalone, do first  
Task 3 (Chrome args)         — standalone
Task 4 (WebGL override)      — depends on Task 2
Task 5 (Locale/languages)    — standalone
Task 6 (MCP parity)          — do last, wraps all new features
```

Tasks 1 and 2 are the critical path — together they would eliminate the timezone mismatch detection and enable pre-load JS patching that actually works against Fingerprint Pro.
