# Contributing to Browserious

Thank you for your interest in contributing to Browserious!

## Getting Started

### Prerequisites

- Python 3.11+
- Docker and Docker Compose
- Git

### Development Setup

```bash
# Clone repository
git clone https://github.com/muzhig/browserious.git
cd browserious

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Install Playwright browsers
playwright install chromium

# Run tests
pytest tests/ -v
```

### Running Locally (Without Docker)

```bash
export API_KEYS=test-key
export DISPLAY=:99
Xvfb :99 -screen 0 1920x1080x24 &
python -m uvicorn src.main:app --reload
```

## Development Workflow

### 1. Create a Branch

```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/your-bug-fix
```

### 2. Make Changes

- Follow the code style guidelines below
- Write tests for new functionality
- Update documentation if needed

### 3. Run Tests

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_sessions.py -v

# Run with coverage
pytest tests/ -v --cov=src --cov-report=term-missing
```

### 4. Submit Pull Request

- Push your branch to GitHub
- Open a Pull Request against `main`
- Fill in the PR template
- Wait for CI checks to pass
- Request review

## Code Style Guidelines

### Python Code

- **No comments** - Code should be self-explanatory
- **No inline imports** - All imports at module level
- **No try-except wrapping** - Let errors bubble up to global handlers
- **Type hints** - Use Python type hints for function parameters and return types
- **Pydantic models** - Use Pydantic for all request/response validation

### Example

```python
# Good
from typing import Optional
from pydantic import BaseModel

class SessionCreate(BaseModel):
    profile_id: Optional[str] = None
    timeout: int = 3600

async def create_session(req: SessionCreate) -> dict:
    session = await manager.create_session(req.profile_id, req.timeout)
    return {"session_id": session.id}

# Bad - has comments, inline imports, try-except
async def create_session(req):
    try:
        from src.manager import manager  # inline import
        # Create a new session
        session = await manager.create_session(req.profile_id)
        return {"session_id": session.id}
    except Exception as e:
        return {"error": str(e)}
```

### Commit Messages

- Keep messages short and concise (1 sentence)
- Use imperative mood ("Add feature" not "Added feature")
- No emoji or special characters

```bash
# Good
git commit -m "Add session timeout configuration"
git commit -m "Fix profile corruption on concurrent access"

# Bad
git commit -m "WIP"
git commit -m "Added feature :rocket:"
git commit -m "This commit adds a new feature for managing sessions with timeout"
```

## Project Structure

```
browserious/
├── src/                    # Source code
│   ├── main.py            # FastAPI app, routes
│   ├── models.py          # Pydantic models
│   ├── config.py          # Settings
│   ├── auth.py            # API key authentication
│   ├── browser_manager.py # Session lifecycle
│   ├── route_manager.py   # Request interception
│   ├── extension_manager.py
│   ├── profile_manager.py
│   ├── selectors.py       # Selector strategies
│   └── cdp_proxy.py       # CDP WebSocket proxy
├── tests/                  # Test suite
│   ├── conftest.py        # Pytest fixtures
│   ├── test_*.py          # Test files
│   └── integration/       # Integration tests
├── docs/                   # Documentation
│   ├── PRD.md             # Product requirements
│   ├── ADR.md             # Architecture decisions
│   ├── API.md             # API reference
│   └── SECURITY.md        # Security guidelines
├── tasks/                  # Task tracking
│   ├── new/               # Unassigned tasks
│   ├── in-progress/       # Active tasks
│   └── done/              # Completed tasks
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── requirements-dev.txt
```

## Testing Guidelines

### What to Test

- Happy path (success cases)
- Error cases (validation, not found, timeout)
- Edge cases (empty input, max limits)
- Security (auth required, path traversal prevention)

### What NOT to Test

- Playwright internals (trust the library)
- External services
- Implementation details that may change

### Test Structure

```python
@pytest.mark.anyio
async def test_create_session_with_profile(client):
    response = await client.post(
        "/sessions",
        headers={"X-API-Key": "test-api-key"},
        json={"profile_id": "test-profile"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "session_id" in data
```

## Documentation

### When to Update Docs

- API changes → update `docs/API.md`
- Architecture decisions → add to `docs/ADR.md`
- Security changes → update `docs/SECURITY.md`
- New features → update `README.md`

### ADR Format

When making significant technical decisions, document them:

```markdown
## ADR-XXX: Decision Title

**Date:** YYYY-MM-DD
**Status:** Accepted

### Context
Why this decision needed to be made.

### Decision
What we decided to do.

### Consequences
Trade-offs and implications.
```

## Security

- Never commit secrets or API keys
- Validate all user input with Pydantic
- Prevent path traversal in file operations
- Follow guidelines in `docs/SECURITY.md`

## Getting Help

- Check existing [documentation](docs/)
- Search [GitHub Issues](https://github.com/muzhig/browserious/issues)
- Open a new issue for questions

