import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from playwright.async_api import BrowserContext, Route

from src.models import RouteAction


@dataclass
class CapturedRequest:
    timestamp: datetime
    method: str
    url: str
    headers: dict[str, str]
    body: Optional[str] = None


@dataclass
class RouteInfo:
    route_id: str
    pattern: str
    action: RouteAction
    captured_requests: list[CapturedRequest] = field(default_factory=list)


class RouteManager:
    def __init__(self):
        self.routes: dict[str, RouteInfo] = {}
        self._handlers: dict[str, callable] = {}

    async def register_route(
        self,
        context: BrowserContext,
        pattern: str,
        action: RouteAction,
    ) -> str:
        route_id = str(uuid.uuid4())

        route_info = RouteInfo(
            route_id=route_id,
            pattern=pattern,
            action=action,
        )

        async def route_handler(route: Route):
            if action.type == "block":
                await route.abort()
            elif action.type == "redirect":
                await route.fulfill(status=302, headers={"Location": action.url})
            elif action.type == "override":
                await route.fulfill(
                    status=action.status,
                    headers=action.headers or {},
                    body=action.body,
                )
            elif action.type == "inspect":
                request_info = CapturedRequest(
                    timestamp=datetime.utcnow(),
                    method=route.request.method,
                    url=route.request.url,
                    headers=dict(route.request.headers),
                )
                if action.capture_body:
                    request_info.body = route.request.post_data
                route_info.captured_requests.append(request_info)
                await route.continue_()

        await context.route(pattern, route_handler)

        self.routes[route_id] = route_info
        self._handlers[route_id] = route_handler
        return route_id

    async def unregister_route(self, context: BrowserContext, route_id: str):
        if route_id in self.routes:
            route_info = self.routes.pop(route_id)
            handler = self._handlers.pop(route_id, None)
            if handler:
                await context.unroute(route_info.pattern, handler)

    def list_routes(self) -> list[RouteInfo]:
        return list(self.routes.values())

    def get_route(self, route_id: str) -> Optional[RouteInfo]:
        return self.routes.get(route_id)
