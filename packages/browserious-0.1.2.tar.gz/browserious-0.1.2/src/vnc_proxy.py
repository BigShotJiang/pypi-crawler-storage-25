import asyncio
import logging
import socket
from typing import Optional

from fastapi import WebSocket

logger = logging.getLogger(__name__)

BUFFER_SIZE = 65536


async def forward_vnc_connection(websocket: WebSocket, vnc_host: str, vnc_port: int = 5900):
    reader: Optional[asyncio.StreamReader] = None
    writer: Optional[asyncio.StreamWriter] = None

    logger.info(f"Attempting VNC connection to {vnc_host}:{vnc_port}")

    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(vnc_host, vnc_port),
            timeout=10.0
        )
        logger.info(f"Connected to VNC server at {vnc_host}:{vnc_port}")
    except asyncio.TimeoutError:
        logger.error(f"Timeout connecting to VNC server at {vnc_host}:{vnc_port}")
        await websocket.close(code=1011, reason="VNC server connection timeout")
        return
    except (OSError, socket.error) as e:
        logger.error(f"Failed to connect to VNC server: {e}")
        await websocket.close(code=1011, reason="VNC server connection failed")
        return

    async def ws_to_vnc():
        try:
            while True:
                data = await websocket.receive_bytes()
                logger.debug(f"WS->VNC: {len(data)} bytes")
                writer.write(data)
                await writer.drain()
        except Exception as e:
            logger.info(f"ws_to_vnc ended: {e}")
            raise

    async def vnc_to_ws():
        try:
            while True:
                data = await reader.read(BUFFER_SIZE)
                if not data:
                    logger.info("VNC server closed connection")
                    break
                logger.debug(f"VNC->WS: {len(data)} bytes")
                await websocket.send_bytes(data)
        except Exception as e:
            logger.info(f"vnc_to_ws ended: {e}")
            raise

    try:
        await asyncio.gather(ws_to_vnc(), vnc_to_ws())
    except Exception as e:
        logger.info(f"VNC proxy connection ended: {e}")
    finally:
        if writer:
            writer.close()
            await writer.wait_closed()
