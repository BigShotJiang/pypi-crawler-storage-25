from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select

from src.auth import AuthContext, get_auth_context
from src.database import async_session
from src.db_models import TenantConfig

router = APIRouter(prefix="/tenant", tags=["Tenant"])


class TenantConfigResponse(BaseModel):
    backend_provider: str
    max_sessions: int
    max_session_duration: int
    max_profiles: int
    config: dict | None = None


class TenantConfigUpdate(BaseModel):
    backend_provider: str | None = None
    max_sessions: int | None = Field(default=None, ge=1, le=100)
    max_session_duration: int | None = Field(default=None, ge=60, le=86400)
    max_profiles: int | None = Field(default=None, ge=1, le=1000)
    config: dict | None = None


DEFAULT_CONFIG = TenantConfigResponse(
    backend_provider="byom",
    max_sessions=5,
    max_session_duration=3600,
    max_profiles=50,
    config=None,
)


def _require_user(auth: AuthContext) -> None:
    if auth.is_legacy or not auth.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Tenant config requires user authentication")


@router.get("/config", response_model=TenantConfigResponse)
async def get_tenant_config(auth: AuthContext = Depends(get_auth_context)):
    _require_user(auth)
    async with async_session() as session:
        result = await session.execute(
            select(TenantConfig).where(TenantConfig.user_id == auth.user_id)
        )
        tc = result.scalar_one_or_none()

    if not tc:
        return DEFAULT_CONFIG

    return TenantConfigResponse(
        backend_provider=tc.backend_provider,
        max_sessions=tc.max_sessions,
        max_session_duration=tc.max_session_duration,
        max_profiles=tc.max_profiles,
        config=tc.config,
    )


@router.put("/config", response_model=TenantConfigResponse)
async def update_tenant_config(body: TenantConfigUpdate, auth: AuthContext = Depends(get_auth_context)):
    _require_user(auth)
    async with async_session() as session:
        result = await session.execute(
            select(TenantConfig).where(TenantConfig.user_id == auth.user_id)
        )
        tc = result.scalar_one_or_none()

        if not tc:
            tc = TenantConfig(user_id=auth.user_id)
            session.add(tc)

        if body.backend_provider is not None:
            tc.backend_provider = body.backend_provider
        if body.max_sessions is not None:
            tc.max_sessions = body.max_sessions
        if body.max_session_duration is not None:
            tc.max_session_duration = body.max_session_duration
        if body.max_profiles is not None:
            tc.max_profiles = body.max_profiles
        if body.config is not None:
            tc.config = body.config

        await session.commit()
        await session.refresh(tc)

    return TenantConfigResponse(
        backend_provider=tc.backend_provider,
        max_sessions=tc.max_sessions,
        max_session_duration=tc.max_session_duration,
        max_profiles=tc.max_profiles,
        config=tc.config,
    )
