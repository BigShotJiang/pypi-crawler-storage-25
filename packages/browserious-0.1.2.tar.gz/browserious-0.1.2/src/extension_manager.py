import io
import json
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import Optional

from src.config import settings


class ExtensionManager:
    def __init__(self, extensions_dir: str):
        self.extensions_dir = Path(extensions_dir)

    def _ensure_dir(self):
        self.extensions_dir.mkdir(parents=True, exist_ok=True)

    async def upload_extension(self, file_data: bytes, filename: str) -> dict:
        self._ensure_dir()
        extension_id = f"ext-{uuid.uuid4()}"
        extension_path = self.extensions_dir / extension_id

        with zipfile.ZipFile(io.BytesIO(file_data)) as zf:
            zf.extractall(extension_path)

        manifest_path = extension_path / "manifest.json"
        if not manifest_path.exists():
            shutil.rmtree(extension_path)
            raise ValueError("Invalid extension: manifest.json not found")

        with open(manifest_path) as f:
            manifest = json.load(f)

        return {
            "extension_id": extension_id,
            "name": manifest.get("name", "Unknown"),
            "version": manifest.get("version", "0.0.0"),
            "description": manifest.get("description"),
            "manifest_version": manifest.get("manifest_version", 2),
            "permissions": manifest.get("permissions", []),
            "file_size": sum(f.stat().st_size for f in extension_path.rglob("*") if f.is_file()),
        }

    def list_extensions(self) -> list[dict]:
        extensions = []
        for ext_dir in self.extensions_dir.iterdir():
            if ext_dir.is_dir():
                manifest_path = ext_dir / "manifest.json"
                if manifest_path.exists():
                    with open(manifest_path) as f:
                        manifest = json.load(f)
                    extensions.append({
                        "extension_id": ext_dir.name,
                        "name": manifest.get("name", "Unknown"),
                        "version": manifest.get("version", "0.0.0"),
                        "description": manifest.get("description"),
                        "manifest_version": manifest.get("manifest_version", 2),
                        "permissions": manifest.get("permissions", []),
                        "file_size": sum(f.stat().st_size for f in ext_dir.rglob("*") if f.is_file()),
                    })
        return extensions

    def delete_extension(self, extension_id: str) -> bool:
        extension_path = self.extensions_dir / extension_id
        if extension_path.exists():
            shutil.rmtree(extension_path)
            return True
        return False

    def get_extension_path(self, extension_id: str) -> Optional[Path]:
        extension_path = self.extensions_dir / extension_id
        if extension_path.exists():
            return extension_path
        return None

    def extension_exists(self, extension_id: str) -> bool:
        return (self.extensions_dir / extension_id).exists()


extension_manager = ExtensionManager(settings.extensions_dir)
