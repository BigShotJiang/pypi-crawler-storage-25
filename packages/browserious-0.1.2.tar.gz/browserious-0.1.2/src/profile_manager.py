import json
import shutil
from pathlib import Path
from typing import Optional

from playwright.async_api import BrowserContext

from src.config import settings


class ProfileManager:
    def __init__(self, profiles_dir: str):
        self.profiles_dir = Path(profiles_dir)

    def _profile_path(self, profile_id: str, tenant_id: Optional[str] = None) -> Path:
        if tenant_id:
            return self.profiles_dir / tenant_id / profile_id
        return self.profiles_dir / profile_id

    async def export_state(self, profile_id: str, context: Optional[BrowserContext] = None, tenant_id: Optional[str] = None) -> dict:
        if context:
            storage_state = await context.storage_state()
        else:
            state_file = self._profile_path(profile_id, tenant_id) / "state.json"
            if state_file.exists():
                with open(state_file) as f:
                    storage_state = json.load(f)
            else:
                storage_state = {"cookies": [], "origins": []}

        return {
            "profile_id": profile_id,
            "cookies": storage_state.get("cookies", []),
            "localStorage": [
                {
                    "origin": origin["origin"],
                    "items": [
                        {"key": item["name"], "value": item["value"]}
                        for item in origin.get("localStorage", [])
                    ]
                }
                for origin in storage_state.get("origins", [])
            ],
            "sessionStorage": [
                {
                    "origin": origin["origin"],
                    "items": [
                        {"key": item["name"], "value": item["value"]}
                        for item in origin.get("sessionStorage", [])
                    ]
                }
                for origin in storage_state.get("origins", [])
            ],
        }

    async def import_state(self, profile_id: str, state: dict, tenant_id: Optional[str] = None):
        storage_state = {
            "cookies": state.get("cookies", []),
            "origins": [],
        }

        for ls_item in state.get("localStorage", []):
            origin_data = {
                "origin": ls_item["origin"],
                "localStorage": [
                    {"name": item["key"], "value": item["value"]}
                    for item in ls_item.get("items", [])
                ]
            }
            storage_state["origins"].append(origin_data)

        profile_path = self._profile_path(profile_id, tenant_id)
        profile_path.mkdir(parents=True, exist_ok=True)

        state_file = profile_path / "state.json"
        with open(state_file, "w") as f:
            json.dump(storage_state, f, indent=2)

    def delete_profile(self, profile_id: str, tenant_id: Optional[str] = None) -> bool:
        profile_path = self._profile_path(profile_id, tenant_id)
        if profile_path.exists():
            shutil.rmtree(profile_path)
            return True
        return False

    def profile_exists(self, profile_id: str, tenant_id: Optional[str] = None) -> bool:
        return self._profile_path(profile_id, tenant_id).exists()


profile_manager = ProfileManager(settings.profiles_dir)
