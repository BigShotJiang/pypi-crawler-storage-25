import os
from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

STAGE = os.getenv("STAGE", "dev")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=f".env.{STAGE}", env_file_encoding="utf-8", extra="ignore")

    api_keys: str
    profiles_dir: str = "/data/profiles"
    extensions_dir: str = "/data/extensions"
    host_profiles_dir: str = ""
    host_extensions_dir: str = ""
    max_sessions: int = 10
    default_timeout: int = 3600
    resolution: str = "1920x1080x24"

    api_host: str = "localhost"
    api_port: int = 8100

    docker_network: str = "browserious"
    docker_image: str = "browserious-node:latest"
    node_shm_size: str = "2g"
    node_memory_limit: str = "2g"
    node_cpu_limit: float = 2.0

    database_url: str = "postgresql+asyncpg://localhost/browserious"
    db_pool_size: int = 5
    db_max_overflow: int = 10

    jwt_secret: str = ""
    google_client_id: str = ""
    google_client_secret: str = ""
    github_client_id: str = ""
    github_client_secret: str = ""
    oauth_redirect_base: str = "https://browserious.com"

    default_backend: str = "byom"
    fly_api_token: str = ""
    fly_app_name: str = "browserious-nodes"
    fly_region: str = "ewr"
    fly_image: str = "registry.fly.io/browserious-nodes:latest"
    fly_vm_size: str = "shared-cpu-2x"
    fly_vm_memory: int = 2048

    @field_validator("api_keys")
    @classmethod
    def validate_api_keys(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("API_KEYS cannot be empty")
        return v

    @property
    def api_keys_list(self) -> list[str]:
        return [k.strip() for k in self.api_keys.split(",") if k.strip()]

    @property
    def profiles_path(self) -> Path:
        return Path(self.profiles_dir)

    @property
    def extensions_path(self) -> Path:
        return Path(self.extensions_dir)


settings = Settings()
