from io import BytesIO
from typing import Optional

from PIL import Image, ImageDraw


def stamp_cursor_overlay(
    image_bytes: bytes,
    x: int,
    y: int,
    color: str = "red",
    radius: int = 15,
    show_coords: bool = True
) -> bytes:
    img = Image.open(BytesIO(image_bytes))
    draw = ImageDraw.Draw(img)

    draw.ellipse(
        [x - radius, y - radius, x + radius, y + radius],
        outline=color,
        width=3
    )

    line_ext = 8
    draw.line([x - radius - line_ext, y, x + radius + line_ext, y], fill=color, width=2)
    draw.line([x, y - radius - line_ext, x, y + radius + line_ext], fill=color, width=2)

    if show_coords:
        label = f"({x}, {y})"
        draw.text((x + radius + 5, y - radius - 5), label, fill=color)

    output = BytesIO()
    img.save(output, format="PNG")
    return output.getvalue()


def crop_image(
    image_bytes: bytes,
    x: int,
    y: int,
    width: int,
    height: int,
    output_format: str = "PNG",
    quality: int = 80,
) -> bytes:
    img = Image.open(BytesIO(image_bytes))
    img_width, img_height = img.size

    x = max(0, min(x, img_width - 1))
    y = max(0, min(y, img_height - 1))
    x2 = max(x + 1, min(x + width, img_width))
    y2 = max(y + 1, min(y + height, img_height))

    cropped = img.crop((x, y, x2, y2))

    output = BytesIO()
    save_kwargs = {"format": output_format.upper()}
    if output_format.upper() == "JPEG":
        save_kwargs["quality"] = quality
    cropped.save(output, **save_kwargs)
    return output.getvalue()


def composite_fullscreen_screenshot(
    display_bytes: bytes,
    page_bytes: bytes,
    viewport_offset_x: int,
    viewport_offset_y: int,
) -> bytes:
    display_img = Image.open(BytesIO(display_bytes)).convert("RGBA")
    page_img = Image.open(BytesIO(page_bytes)).convert("RGBA")

    display_img.paste(page_img, (viewport_offset_x, viewport_offset_y))

    output = BytesIO()
    display_img.save(output, format="PNG")
    return output.getvalue()


def composite_fullpage_fullscreen_screenshot(
    display_bytes: bytes,
    page_bytes: bytes,
    viewport_offset_y: int,
) -> bytes:
    display_img = Image.open(BytesIO(display_bytes))
    page_img = Image.open(BytesIO(page_bytes))

    display_width, display_height = display_img.size
    page_width, page_height = page_img.size

    chrome_height = viewport_offset_y

    result_height = chrome_height + page_height
    result = Image.new("RGBA", (display_width, result_height))

    chrome = display_img.crop((0, 0, display_width, chrome_height))
    result.paste(chrome, (0, 0))

    result.paste(page_img, (0, chrome_height))

    output = BytesIO()
    result.save(output, format="PNG")
    return output.getvalue()


def process_screenshot(
    image_bytes: bytes,
    cursor_x: Optional[int] = None,
    cursor_y: Optional[int] = None,
    cursor_color: str = "red",
    crop_x: Optional[int] = None,
    crop_y: Optional[int] = None,
    crop_width: Optional[int] = None,
    crop_height: Optional[int] = None,
    output_format: str = "PNG",
    quality: int = 80,
) -> bytes:
    result = image_bytes

    if cursor_x is not None and cursor_y is not None:
        result = stamp_cursor_overlay(result, cursor_x, cursor_y, color=cursor_color)

    if crop_x is not None and crop_y is not None and crop_width is not None and crop_height is not None:
        result = crop_image(result, crop_x, crop_y, crop_width, crop_height, output_format, quality)
    elif output_format.upper() == "JPEG":
        img = Image.open(BytesIO(result))
        output = BytesIO()
        img.save(output, format="JPEG", quality=quality)
        result = output.getvalue()

    return result
