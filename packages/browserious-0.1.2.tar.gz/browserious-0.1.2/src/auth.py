import hashlib
import secrets
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

import jwt
from fastapi import Header, HTTPException, Request, status
from sqlalchemy import select, update

from src.config import settings
from src.database import async_session
from src.db_models import APIToken, User


TOKEN_PREFIX = "br_live_"
JWT_ALGORITHM = "HS256"


@dataclass
class AuthContext:
    user_id: uuid.UUID | None = None
    email: str | None = None
    is_legacy: bool = False


def hash_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode()).hexdigest()


def generate_api_token() -> str:
    return TOKEN_PREFIX + secrets.token_urlsafe(32)


def create_jwt(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user.id),
        "email": user.email,
        "iss": "browserious",
        "aud": "browserious",
        "iat": now,
        "exp": now.replace(year=now.year + 1),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=JWT_ALGORITHM)


def decode_jwt(token: str) -> dict:
    return jwt.decode(
        token,
        settings.jwt_secret,
        algorithms=[JWT_ALGORITHM],
        audience="browserious",
        issuer="browserious",
    )


async def _resolve_bearer_token(token: str) -> AuthContext:
    if token.startswith(TOKEN_PREFIX):
        token_hash = hash_token(token)
        async with async_session() as session:
            result = await session.execute(
                select(APIToken, User)
                .join(User, APIToken.user_id == User.id)
                .where(APIToken.token_hash == token_hash)
                .where(
                    (APIToken.expires_at.is_(None))
                    | (APIToken.expires_at > datetime.now(timezone.utc))
                )
            )
            row = result.first()
            if not row:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")
            api_token, user = row
            await session.execute(
                update(APIToken)
                .where(APIToken.id == api_token.id)
                .values(last_used_at=datetime.now(timezone.utc))
            )
            await session.commit()
            return AuthContext(user_id=user.id, email=user.email)

    claims = decode_jwt(token)
    return AuthContext(user_id=uuid.UUID(claims["sub"]), email=claims.get("email"))


async def _resolve_api_key(key: str) -> AuthContext:
    if key.startswith(TOKEN_PREFIX):
        return await _resolve_bearer_token(key)

    valid_keys = settings.api_keys_list
    is_valid = any(secrets.compare_digest(key, valid_key) for valid_key in valid_keys)
    if not is_valid:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing API key")
    return AuthContext(is_legacy=True)


async def get_auth_context(
    request: Request,
    authorization: str | None = Header(None),
    x_api_key: str | None = Header(None),
) -> AuthContext:
    if authorization and authorization.startswith("Bearer "):
        token = authorization[7:]
        return await _resolve_bearer_token(token)

    if x_api_key:
        return await _resolve_api_key(x_api_key)

    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing API key")


async def verify_api_key(
    request: Request,
    authorization: str | None = Header(None),
    x_api_key: str | None = Header(None),
) -> None:
    await get_auth_context(request, authorization, x_api_key)
