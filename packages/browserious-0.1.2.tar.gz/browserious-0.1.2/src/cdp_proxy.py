import asyncio
import logging

from fastapi import WebSocket
import websockets

logger = logging.getLogger(__name__)


async def forward_cdp_messages(client_ws: WebSocket, cdp_url: str):
    async with websockets.connect(cdp_url) as cdp_ws:
        async def client_to_cdp():
            while True:
                message = await client_ws.receive_text()
                await cdp_ws.send(message)

        async def cdp_to_client():
            async for message in cdp_ws:
                await client_ws.send_text(message)

        await asyncio.gather(
            client_to_cdp(),
            cdp_to_client(),
            return_exceptions=True,
        )
