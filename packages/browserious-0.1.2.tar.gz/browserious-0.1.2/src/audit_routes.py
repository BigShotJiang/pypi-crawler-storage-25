from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy import select

from src.auth import AuthContext, get_auth_context
from src.database import async_session
from src.db_models import UsageEvent

router = APIRouter(prefix="/audit", tags=["Audit"])


class AuditEvent(BaseModel):
    id: str
    event_type: str
    session_id: Optional[str] = None
    duration_seconds: Optional[int] = None
    metadata: Optional[dict] = None
    created_at: datetime


class AuditListResponse(BaseModel):
    events: list[AuditEvent]
    total: int


@router.get("/events", response_model=AuditListResponse)
async def list_audit_events(
    event_type: Optional[str] = Query(default=None, description="Filter by event type (e.g. session.create, auth.login)"),
    since: Optional[datetime] = Query(default=None, description="Events after this timestamp"),
    until: Optional[datetime] = Query(default=None, description="Events before this timestamp"),
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
    auth: AuthContext = Depends(get_auth_context),
):
    if auth.is_legacy or not auth.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Audit log requires user authentication")

    async with async_session() as session:
        query = select(UsageEvent).where(UsageEvent.user_id == auth.user_id)

        if event_type:
            query = query.where(UsageEvent.event_type == event_type)
        if since:
            query = query.where(UsageEvent.created_at >= since)
        if until:
            query = query.where(UsageEvent.created_at <= until)

        query = query.order_by(UsageEvent.created_at.desc()).offset(offset).limit(limit)

        result = await session.execute(query)
        events = result.scalars().all()

    return AuditListResponse(
        events=[
            AuditEvent(
                id=str(e.id),
                event_type=e.event_type,
                session_id=e.session_id,
                duration_seconds=e.duration_seconds,
                metadata=e.metadata_,
                created_at=e.created_at,
            )
            for e in events
        ],
        total=len(events),
    )
