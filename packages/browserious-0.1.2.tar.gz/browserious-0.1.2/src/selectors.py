from playwright.async_api import Page, Locator

from src.models import Selector


class SelectorStrategy:
    @staticmethod
    def locate(page: Page, selector: Selector) -> Locator:
        match selector.strategy:
            case "css":
                return page.locator(selector.value)
            case "xpath":
                return page.locator(f"xpath={selector.value}")
            case "text":
                return page.locator(f"text={selector.value}")
            case "role":
                return page.locator(selector.value)
            case "js":
                return page.locator(f"js={selector.value}")
            case _:
                raise ValueError(f"Unknown selector strategy: {selector.strategy}")
