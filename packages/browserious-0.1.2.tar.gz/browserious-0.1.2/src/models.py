from pydantic import BaseModel, Field, field_validator
from typing import Literal, Optional, Any
from datetime import datetime
import re


class ErrorResponse(BaseModel):
    detail: str
    error_code: str
    context: Optional[dict[str, Any]] = None


DETAIL_TO_ERROR_CODE: dict[str, str] = {
    "Session not found": "SESSION_NOT_FOUND",
    "Page not found": "PAGE_NOT_FOUND",
    "Route not found": "ROUTE_NOT_FOUND",
    "Extension not found": "EXTENSION_NOT_FOUND",
    "Profile not found": "PROFILE_NOT_FOUND",
    "Captcha not found at specified index": "CAPTCHA_NOT_FOUND",
    "Maximum concurrent sessions reached": "MAX_SESSIONS",
    "Profile is in use by active session": "PROFILE_IN_USE",
    "Failed to save profile": "PROFILE_SAVE_FAILED",
    "File must be .zip or .crx": "INVALID_FILE_TYPE",
    "Invalid or missing API key": "UNAUTHORIZED",
    "Tenant session limit reached": "TENANT_SESSION_LIMIT",
    "Profile limit reached": "TENANT_PROFILE_LIMIT",
}


class ProxyConfig(BaseModel):
    server: str
    username: Optional[str] = None
    password: Optional[str] = None


class ViewportConfig(BaseModel):
    width: int = Field(default=1920, ge=320, le=3840)
    height: int = Field(default=1080, ge=240, le=2160)


CHROME_ARGS_DENYLIST = {
    "--remote-debugging-port",
    "--remote-debugging-address",
    "--remote-allow-origins",
    "--user-data-dir",
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--proxy-server",
    "--load-extension",
    "--user-agent",
    "--window-size",
}


class StealthConfig(BaseModel):
    webgl_vendor: Optional[str] = None
    webgl_renderer: Optional[str] = None


class SessionCreate(BaseModel):
    profile_id: Optional[str] = Field(default=None, max_length=255)
    proxy: Optional[ProxyConfig] = None
    extensions: list[str] = Field(default_factory=list)
    viewport: ViewportConfig = Field(default_factory=ViewportConfig)
    user_agent: Optional[str] = None
    timeout: int = Field(default=3600, ge=60, le=86400)
    timezone: Optional[str] = None
    locale: Optional[str] = None
    languages: Optional[list[str]] = None
    chrome_args: list[str] = Field(default_factory=list)
    stealth: Optional[StealthConfig] = None

    @field_validator('profile_id')
    @classmethod
    def validate_profile_id(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if '..' in v:
            raise ValueError('profile_id cannot contain ".."')
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('profile_id must match pattern ^[a-zA-Z0-9_-]+$')
        return v

    @field_validator('chrome_args')
    @classmethod
    def validate_chrome_args(cls, v: list[str]) -> list[str]:
        for arg in v:
            flag = arg.split("=")[0]
            if flag in CHROME_ARGS_DENYLIST:
                raise ValueError(f'Chrome arg "{flag}" is managed internally and cannot be overridden')
        return v


class SessionResponse(BaseModel):
    session_id: str
    profile_id: str
    cdp_url: str
    vnc_url: str
    input_url: str
    vnc_password: str
    session_token: str
    web_vnc_url: str
    container_id: str
    created_at: datetime
    expires_at: datetime
    user_agent: Optional[str] = None
    window_info: Optional['WindowInfo'] = None
    routing_headers: dict[str, str] = Field(default_factory=dict)


class PageInfo(BaseModel):
    page_id: str
    url: str
    title: str


class SessionInfo(BaseModel):
    session_id: str
    profile_id: str
    created_at: datetime
    expires_at: datetime
    page_count: int
    route_count: int


class WindowInfo(BaseModel):
    screen_x: int
    screen_y: int
    chrome_width: int
    chrome_height: int


class SessionDetails(BaseModel):
    session_id: str
    profile_id: str
    container_id: str
    created_at: datetime
    expires_at: datetime
    pages: list[PageInfo]
    routes: list['RouteInfo']
    extensions: list[str]
    proxy: Optional[ProxyConfig] = None
    viewport: ViewportConfig
    user_agent: Optional[str] = None
    window_info: Optional[WindowInfo] = None


class SessionListResponse(BaseModel):
    sessions: list[SessionInfo]
    total: int


class SessionCloseResponse(BaseModel):
    status: Literal['closed']
    session_id: str


class PageCreate(BaseModel):
    url: Optional[str] = None


class PageListResponse(BaseModel):
    pages: list[PageInfo]


class GotoRequest(BaseModel):
    url: str
    wait_until: Literal['load', 'domcontentloaded', 'networkidle'] = 'load'
    timeout: int = Field(default=30000, ge=0)


class GotoResponse(BaseModel):
    status: Literal['ok']
    url: str
    title: str
    load_time_ms: int


class Selector(BaseModel):
    strategy: Literal['css', 'xpath', 'text', 'role', 'js']
    value: str


class ClickRequest(BaseModel):
    selector: Selector
    timeout: int = Field(default=5000, ge=0)
    force: bool = False


class ClickResponse(BaseModel):
    status: Literal['ok']
    selector: Selector


class TypeRequest(BaseModel):
    selector: Selector
    text: str
    delay: int = Field(default=0, ge=0)
    clear: bool = False


class TypeResponse(BaseModel):
    status: Literal['ok']
    text: str


class FillRequest(BaseModel):
    selector: Selector
    value: str


class FillResponse(BaseModel):
    status: Literal['ok']
    value: str


class WaitForSelectorRequest(BaseModel):
    selector: Selector
    state: Literal['visible', 'hidden', 'attached', 'detached'] = 'visible'
    timeout: int = Field(default=30000, ge=0)


class WaitForSelectorResponse(BaseModel):
    status: Literal['ok']
    found: bool
    wait_time_ms: int


class EvalRequest(BaseModel):
    script: str
    args: list[Any] = Field(default_factory=list)


class EvalResponse(BaseModel):
    result: Any


class ContentResponse(BaseModel):
    html: str
    length: int


class InitScriptRequest(BaseModel):
    script: str


class InitScriptResponse(BaseModel):
    status: Literal['ok']
    scope: Literal['page', 'context']


class RouteActionBlock(BaseModel):
    type: Literal['block']


class RouteActionRedirect(BaseModel):
    type: Literal['redirect']
    url: str


class RouteActionOverride(BaseModel):
    type: Literal['override']
    status: int = Field(ge=100, le=599)
    headers: Optional[dict[str, str]] = None
    body: Optional[str] = None


class RouteActionInspect(BaseModel):
    type: Literal['inspect']
    capture_body: bool = False


RouteAction = RouteActionBlock | RouteActionRedirect | RouteActionOverride | RouteActionInspect


class RouteCreate(BaseModel):
    pattern: str
    action: RouteAction


class RouteInfo(BaseModel):
    route_id: str
    pattern: str
    action: RouteAction


class RouteListResponse(BaseModel):
    routes: list[RouteInfo]


class RouteDeleteResponse(BaseModel):
    status: Literal['deleted']
    route_id: str


class RequestTiming(BaseModel):
    start_time: datetime
    end_time: datetime
    duration_ms: int


class InspectedResponse(BaseModel):
    status: int
    headers: dict[str, str]
    body: Optional[str] = None


class InspectedRequest(BaseModel):
    timestamp: datetime
    method: str
    url: str
    headers: dict[str, str]
    body: Optional[str] = None
    response: Optional[InspectedResponse] = None
    timing: RequestTiming


class InspectResponse(BaseModel):
    route_id: str
    pattern: str
    requests: list[InspectedRequest]
    total: int


class Cookie(BaseModel):
    name: str
    value: str
    domain: str
    path: str
    expires: Optional[int] = None
    httpOnly: bool = False
    secure: bool = False
    sameSite: Optional[Literal['Strict', 'Lax', 'None']] = None


class StorageItem(BaseModel):
    key: str
    value: str


class LocalStorageOrigin(BaseModel):
    origin: str
    items: list[StorageItem]


class SessionStorageOrigin(BaseModel):
    origin: str
    items: list[StorageItem]


class ProfileState(BaseModel):
    profile_id: str
    cookies: list[Cookie] = Field(default_factory=list)
    localStorage: list[LocalStorageOrigin] = Field(default_factory=list)
    sessionStorage: list[SessionStorageOrigin] = Field(default_factory=list)


class ProfileImportResponse(BaseModel):
    status: Literal['imported']
    profile_id: str
    imported: dict[str, int]


class ProfileDeleteResponse(BaseModel):
    status: Literal['deleted']
    profile_id: str


class ProfileSaveResponse(BaseModel):
    status: Literal['saved']
    profile_id: str


class ExtensionInfo(BaseModel):
    extension_id: str
    name: str
    version: str
    description: Optional[str] = None
    manifest_version: int
    permissions: list[str] = Field(default_factory=list)
    file_size: int


class ExtensionListResponse(BaseModel):
    extensions: list[ExtensionInfo]
    total: int


class ExtensionDeleteResponse(BaseModel):
    status: Literal['deleted']
    extension_id: str


class InputEasingConfig(BaseModel):
    x: str = "linear"
    y: str = "linear"


class InputInterval(BaseModel):
    min_ms: int = Field(default=40, ge=1)
    max_ms: int = Field(default=120, ge=1)


class InputAction(BaseModel):
    type: Literal['move', 'sleep', 'mouse_down', 'mouse_up', 'click', 'key_down', 'key_up', 'key', 'type_text', 'scroll']
    x: Optional[int] = None
    y: Optional[int] = None
    duration_ms: Optional[int] = Field(default=None, ge=0)
    easing: Optional[InputEasingConfig] = None
    button: Optional[int] = Field(default=None, ge=1, le=3)
    key: Optional[str] = None
    text: Optional[str] = None
    interval: Optional[InputInterval] = None
    delta_x: Optional[int] = None
    delta_y: Optional[int] = None
    count: Optional[int] = Field(default=None, ge=1)


class InputPlaylist(BaseModel):
    actions: list[InputAction] = Field(..., min_length=1)


class InputPlayResult(BaseModel):
    status: Literal['ok', 'error']
    executed: int
    duration_ms: int
    error: Optional[str] = None
    failed_at: Optional[int] = None


class MousePositionResponse(BaseModel):
    x: int
    y: int


class ElementAtPointResponse(BaseModel):
    found: bool
    tag_name: Optional[str] = None
    id: Optional[str] = None
    class_name: Optional[str] = None
    text_content: Optional[str] = None
    bounding_box: Optional[dict[str, float]] = None
    attributes: dict[str, str] = Field(default_factory=dict)
    xpath: Optional[str] = None
    css_selector: Optional[str] = None


class CaptchaRegion(BaseModel):
    type: str
    provider: Optional[str] = None
    bounding_box: dict[str, float]
    viewport_coords: dict[str, int]
    iframe_src: Optional[str] = None
    element_selector: Optional[str] = None


class CaptchaDetectionResponse(BaseModel):
    found: bool
    count: int
    captchas: list[CaptchaRegion] = Field(default_factory=list)


class CaptchaGridCell(BaseModel):
    index: int
    x: int
    y: int
    width: int
    height: int
    center_x: int
    center_y: int
    selected: bool = False


class CaptchaButton(BaseModel):
    name: str
    x: int
    y: int
    width: int
    height: int
    center_x: int
    center_y: int


class CaptchaSegmentationResponse(BaseModel):
    type: Literal['image_grid', 'checkbox', 'slider', 'unknown']
    provider: Optional[str] = None
    prompt: Optional[str] = None
    grid_rows: Optional[int] = None
    grid_cols: Optional[int] = None
    cells: list[CaptchaGridCell] = Field(default_factory=list)
    buttons: list[CaptchaButton] = Field(default_factory=list)
    frame_coords: dict[str, int] = Field(default_factory=dict)


class CaptchaSolveRequest(BaseModel):
    cells: list[int] = Field(..., description="Grid cell indices to click")
    click_delay_min_ms: int = Field(default=200, ge=50, description="Min ms between clicks")
    click_delay_max_ms: int = Field(default=400, ge=50, description="Max ms between clicks")
    then_verify: bool = Field(default=True, description="Click verify button after cells")


class CaptchaClickResult(BaseModel):
    cell: int
    x: int
    y: int
    success: bool


class CaptchaSolveResponse(BaseModel):
    status: Literal['ok', 'error']
    clicked: list[CaptchaClickResult]
    verify_clicked: bool = False
    error: Optional[str] = None
