import logging
from typing import Tuple

import httpx
from fastapi import HTTPException, status

from src.browser_manager import BrowserSession
from src.models import InputPlaylist, InputPlayResult

logger = logging.getLogger(__name__)

NODE_API_TIMEOUT = 30.0


def _auth_headers(session: BrowserSession) -> dict:
    if session.session_token:
        return {"Authorization": f"Bearer {session.session_token}"}
    return {}


def calculate_playlist_timeout(playlist: InputPlaylist) -> float:
    total_duration = sum(
        (a.duration_ms or 0) +
        (len(a.text or '') * (a.interval.max_ms if a.interval else 120) if a.type == 'type_text' else 0)
        for a in playlist.actions
    )
    return (total_duration / 1000) + 30


async def proxy_input_playlist(session: BrowserSession, playlist: InputPlaylist) -> InputPlayResult:
    timeout_seconds = calculate_playlist_timeout(playlist)
    node_api_url = f"{session.input_url}/play"

    logger.info(f"Proxying input playlist to {node_api_url} ({len(playlist.actions)} actions, timeout={timeout_seconds:.1f}s)")

    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                node_api_url,
                json=playlist.model_dump(),
                headers=_auth_headers(session),
                timeout=timeout_seconds,
            )
        except httpx.TimeoutException:
            logger.error(f"Node API timeout after {timeout_seconds}s for session {session.session_id}")
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail=f"Node API timeout after {timeout_seconds:.1f}s"
            )
        except httpx.ConnectError as e:
            logger.error(f"Node API connection error for session {session.session_id}: {e}")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Failed to connect to node API"
            )

    result = response.json()
    logger.info(f"Input playlist completed: {result.get('executed')} actions in {result.get('duration_ms')}ms")

    if response.status_code != 200:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Node API error: {result.get('error', 'Unknown error')}"
        )

    return InputPlayResult(**result)


async def get_mouse_position(session: BrowserSession) -> Tuple[int, int]:
    node_api_url = f"{session.input_url}/position"

    logger.info(f"Getting mouse position from {node_api_url}")

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(node_api_url, headers=_auth_headers(session), timeout=NODE_API_TIMEOUT)
        except httpx.TimeoutException:
            logger.error(f"Node API timeout for session {session.session_id}")
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="Node API timeout"
            )
        except httpx.ConnectError as e:
            logger.error(f"Node API connection error for session {session.session_id}: {e}")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Failed to connect to node API"
            )

    if response.status_code != 200:
        result = response.json()
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Node API error: {result.get('error', 'Unknown error')}"
        )

    result = response.json()
    return result["x"], result["y"]


async def get_display_screenshot(session: BrowserSession) -> bytes:
    node_api_url = f"{session.input_url}/screenshot"

    logger.info(f"Getting display screenshot from {node_api_url}")

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(node_api_url, headers=_auth_headers(session), timeout=NODE_API_TIMEOUT)
        except httpx.TimeoutException:
            logger.error(f"Node API timeout for session {session.session_id}")
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="Node API timeout"
            )
        except httpx.ConnectError as e:
            logger.error(f"Node API connection error for session {session.session_id}: {e}")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Failed to connect to node API"
            )

    if response.status_code != 200:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Failed to capture display screenshot"
        )

    return response.content
