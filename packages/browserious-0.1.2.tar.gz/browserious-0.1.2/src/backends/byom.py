import logging

import docker
from docker.errors import APIError, NotFound

from src.backend_provider import BackendProvider, BackendSession
from src.config import settings

logger = logging.getLogger(__name__)


class BYOMBackend(BackendProvider):
    def __init__(self):
        self.docker_client: docker.DockerClient | None = None

    async def start(self) -> None:
        self.docker_client = docker.from_env()
        self._ensure_network()

    def _ensure_network(self):
        try:
            self.docker_client.networks.get(settings.docker_network)
            logger.info(f"Docker network '{settings.docker_network}' exists")
        except NotFound:
            self.docker_client.networks.create(settings.docker_network, driver="bridge")
            logger.info(f"Created Docker network '{settings.docker_network}'")

    async def create_session(
        self,
        session_id: str,
        container_name: str,
        environment: dict[str, str],
        volumes: dict[str, dict],
    ) -> BackendSession:
        container = self.docker_client.containers.run(
            settings.docker_image,
            detach=True,
            name=container_name,
            hostname=container_name,
            network=settings.docker_network,
            environment=environment,
            volumes=volumes,
            shm_size=settings.node_shm_size,
            mem_limit=settings.node_memory_limit,
            nano_cpus=int(settings.node_cpu_limit * 1e9),
            extra_hosts={"host.docker.internal": "host-gateway"},
            ports={"9222/tcp": None, "5900/tcp": None, "8080/tcp": None},
            remove=True,
        )

        logger.info(f"Started container {container_name} ({container.id[:12]})")

        container.reload()
        port_bindings = container.attrs["NetworkSettings"]["Ports"]
        cdp_port = int(port_bindings["9222/tcp"][0]["HostPort"])
        vnc_port = int(port_bindings["5900/tcp"][0]["HostPort"])
        input_port = int(port_bindings["8080/tcp"][0]["HostPort"])
        logger.info(f"Container {container_name} ports: CDP={cdp_port} VNC={vnc_port} input={input_port}")

        return BackendSession(
            session_id=session_id,
            host="localhost",
            backend_id=container.id,
            cdp_port=cdp_port,
            vnc_port=vnc_port,
            input_port=input_port,
        )

    async def terminate_session(self, backend_id: str) -> None:
        try:
            container = self.docker_client.containers.get(backend_id)
            container.stop(timeout=5)
            logger.info(f"Stopped container {backend_id[:12]}")
        except NotFound:
            logger.warning(f"Container {backend_id[:12]} already removed")
        except APIError as e:
            logger.error(f"Error stopping container {backend_id[:12]}: {e}")

    def _extract_ports(self, container) -> tuple[int, int, int]:
        port_bindings = container.attrs["NetworkSettings"]["Ports"] or {}
        cdp_port = int(port_bindings["9222/tcp"][0]["HostPort"]) if port_bindings.get("9222/tcp") else 9222
        vnc_port = int(port_bindings["5900/tcp"][0]["HostPort"]) if port_bindings.get("5900/tcp") else 5900
        input_port = int(port_bindings["8080/tcp"][0]["HostPort"]) if port_bindings.get("8080/tcp") else 8080
        return cdp_port, vnc_port, input_port

    async def get_session(self, backend_id: str) -> BackendSession | None:
        try:
            container = self.docker_client.containers.get(backend_id)
            container.reload()
            cdp_port, vnc_port, input_port = self._extract_ports(container)
            return BackendSession(
                session_id="",
                host="localhost",
                backend_id=container.id,
                cdp_port=cdp_port,
                vnc_port=vnc_port,
                input_port=input_port,
            )
        except NotFound:
            return None

    async def list_sessions(self) -> list[BackendSession]:
        containers = self.docker_client.containers.list(
            filters={"network": settings.docker_network, "ancestor": settings.docker_image}
        )
        results = []
        for c in containers:
            c.reload()
            cdp_port, vnc_port, input_port = self._extract_ports(c)
            results.append(BackendSession(
                session_id="", host="localhost", backend_id=c.id,
                cdp_port=cdp_port, vnc_port=vnc_port, input_port=input_port,
            ))
        return results

    async def health_check(self) -> dict:
        try:
            self.docker_client.ping()
            return {"status": "healthy", "backend": "byom", "docker": True}
        except Exception as e:
            return {"status": "unhealthy", "backend": "byom", "error": str(e)}

    async def shutdown(self) -> None:
        pass
