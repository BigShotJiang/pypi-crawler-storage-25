import logging

import httpx

from src.backend_provider import BackendProvider, BackendSession
from src.config import settings

logger = logging.getLogger(__name__)

FLY_API_BASE = "https://api.machines.dev/v1"


class FlyBackend(BackendProvider):
    def __init__(self):
        self._client: httpx.AsyncClient | None = None

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {settings.fly_api_token}"}

    async def start(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=f"{FLY_API_BASE}/apps/{settings.fly_app_name}",
            headers=self._headers(),
            timeout=60,
        )
        logger.info(f"Fly backend started for app '{settings.fly_app_name}' in region '{settings.fly_region}'")

    async def create_session(
        self,
        session_id: str,
        container_name: str,
        environment: dict[str, str],
        volumes: dict[str, dict],
    ) -> BackendSession:
        machine_config = {
            "name": container_name,
            "region": settings.fly_region,
            "config": {
                "image": settings.fly_image,
                "env": environment,
                "guest": {
                    "cpu_kind": "shared",
                    "cpus": 2,
                    "memory_mb": settings.fly_vm_memory,
                },
                "services": [
                    {
                        "protocol": "tcp",
                        "internal_port": 8080,
                        "ports": [{"port": 443, "handlers": ["tls", "http"]}],
                    },
                ],
                "auto_destroy": True,
            },
        }

        resp = await self._client.post("/machines", json=machine_config)
        resp.raise_for_status()
        machine = resp.json()

        machine_id = machine["id"]
        logger.info(f"Created Fly machine {machine_id} for session {session_id}")

        await self._wait_for_state(machine_id, "started")

        host = f"{settings.fly_app_name}.fly.dev"
        logger.info(f"Fly machine {machine_id} started, host={host}")

        return BackendSession(
            session_id=session_id,
            host=host,
            backend_id=machine_id,
            cdp_port=443,
            vnc_port=443,
            input_port=443,
            tls=True,
            routing_headers={"fly-force-instance-id": machine_id},
        )

    async def _wait_for_state(self, machine_id: str, target_state: str, timeout: int = 60):
        resp = await self._client.get(
            f"/machines/{machine_id}/wait",
            params={"state": target_state, "timeout": timeout},
        )
        if resp.status_code == 408:
            machine_resp = await self._client.get(f"/machines/{machine_id}")
            machine_resp.raise_for_status()
            state = machine_resp.json().get("state", "unknown")
            logger.warning(f"Fly wait timed out for {machine_id}, current state: {state}")
            if state == "started":
                return
        resp.raise_for_status()

    async def terminate_session(self, backend_id: str) -> None:
        resp = await self._client.post(f"/machines/{backend_id}/stop")
        if resp.status_code == 200:
            logger.info(f"Stopped Fly machine {backend_id}")
            resp = await self._client.delete(f"/machines/{backend_id}", params={"force": "true"})
            if resp.status_code == 200:
                logger.info(f"Destroyed Fly machine {backend_id}")
        else:
            logger.warning(f"Failed to stop Fly machine {backend_id}: {resp.status_code}")

    async def get_session(self, backend_id: str) -> BackendSession | None:
        resp = await self._client.get(f"/machines/{backend_id}")
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        machine = resp.json()
        return BackendSession(
            session_id="",
            host=f"{settings.fly_app_name}.fly.dev",
            backend_id=machine["id"],
            tls=True,
            routing_headers={"fly-force-instance-id": machine["id"]},
        )

    async def list_sessions(self) -> list[BackendSession]:
        resp = await self._client.get("/machines")
        resp.raise_for_status()
        machines = resp.json()
        return [
            BackendSession(
                session_id="",
                host=f"{settings.fly_app_name}.fly.dev",
                backend_id=m["id"],
                tls=True,
                routing_headers={"fly-force-instance-id": m["id"]},
            )
            for m in machines
            if m.get("state") == "started"
        ]

    async def health_check(self) -> dict:
        if not settings.fly_api_token:
            return {"status": "unhealthy", "backend": "fly", "error": "no API token"}
        resp = await self._client.get("/machines")
        if resp.status_code == 200:
            return {"status": "healthy", "backend": "fly", "region": settings.fly_region}
        return {"status": "unhealthy", "backend": "fly", "error": f"HTTP {resp.status_code}"}

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()
