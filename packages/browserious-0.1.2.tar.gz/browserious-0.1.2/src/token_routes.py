from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import delete, select

from src.audit import record_event
from src.auth import AuthContext, generate_api_token, get_auth_context, hash_token
from src.database import async_session
from src.db_models import APIToken

router = APIRouter(prefix="/tokens", tags=["Tokens"])


class TokenCreateRequest(BaseModel):
    name: str | None = None


class TokenCreateResponse(BaseModel):
    id: str
    name: str | None
    token: str
    created_at: datetime


class TokenInfo(BaseModel):
    id: str
    name: str | None
    token_prefix: str
    last_used_at: datetime | None
    expires_at: datetime | None
    created_at: datetime


class TokenListResponse(BaseModel):
    tokens: list[TokenInfo]


class TokenDeleteResponse(BaseModel):
    deleted: bool


def _require_user(auth: AuthContext) -> None:
    if auth.is_legacy or not auth.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Token management requires user authentication")


@router.post("", response_model=TokenCreateResponse)
async def create_token(body: TokenCreateRequest, auth: AuthContext = Depends(get_auth_context)):
    raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Token creation is temporarily disabled")
    _require_user(auth)
    raw_token = generate_api_token()
    token_hash = hash_token(raw_token)

    async with async_session() as session:
        api_token = APIToken(user_id=auth.user_id, token_hash=token_hash, name=body.name)
        session.add(api_token)
        await session.commit()
        await session.refresh(api_token)

    await record_event(auth.user_id, "token.create", metadata={"token_id": str(api_token.id), "name": api_token.name})
    return TokenCreateResponse(
        id=str(api_token.id),
        name=api_token.name,
        token=raw_token,
        created_at=api_token.created_at,
    )


@router.get("", response_model=TokenListResponse)
async def list_tokens(auth: AuthContext = Depends(get_auth_context)):
    _require_user(auth)
    async with async_session() as session:
        result = await session.execute(
            select(APIToken).where(APIToken.user_id == auth.user_id).order_by(APIToken.created_at.desc())
        )
        tokens = result.scalars().all()

    return TokenListResponse(
        tokens=[
            TokenInfo(
                id=str(t.id),
                name=t.name,
                token_prefix=f"br_live_...{t.token_hash[-6:]}",
                last_used_at=t.last_used_at,
                expires_at=t.expires_at,
                created_at=t.created_at,
            )
            for t in tokens
        ]
    )


@router.delete("/{token_id}", response_model=TokenDeleteResponse)
async def delete_token(token_id: str, auth: AuthContext = Depends(get_auth_context)):
    _require_user(auth)
    async with async_session() as session:
        result = await session.execute(
            delete(APIToken).where(APIToken.id == token_id, APIToken.user_id == auth.user_id)
        )
        await session.commit()

    if result.rowcount == 0:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Token not found")

    await record_event(auth.user_id, "token.revoke", metadata={"token_id": token_id})
    return TokenDeleteResponse(deleted=True)
