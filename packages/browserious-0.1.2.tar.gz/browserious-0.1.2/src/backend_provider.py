import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class BackendSession:
    session_id: str
    host: str
    backend_id: str = ""
    cdp_port: int = 9222
    vnc_port: int = 5900
    input_port: int = 8080
    tls: bool = False
    routing_headers: dict[str, str] = field(default_factory=dict)


class BackendProvider(ABC):
    @abstractmethod
    async def start(self) -> None:
        ...

    @abstractmethod
    async def create_session(
        self,
        session_id: str,
        container_name: str,
        environment: dict[str, str],
        volumes: dict[str, dict],
    ) -> BackendSession:
        ...

    @abstractmethod
    async def terminate_session(self, backend_id: str) -> None:
        ...

    @abstractmethod
    async def get_session(self, backend_id: str) -> BackendSession | None:
        ...

    @abstractmethod
    async def list_sessions(self) -> list[BackendSession]:
        ...

    @abstractmethod
    async def health_check(self) -> dict:
        ...

    @abstractmethod
    async def shutdown(self) -> None:
        ...



class BackendRegistry:
    def __init__(self):
        self._providers: dict[str, BackendProvider] = {}

    def register(self, name: str, provider: BackendProvider):
        self._providers[name] = provider

    def get(self, name: str) -> BackendProvider | None:
        return self._providers.get(name)

    async def start_all(self):
        for name, provider in self._providers.items():
            logger.info(f"Starting backend provider: {name}")
            await provider.start()

    async def shutdown_all(self):
        for name, provider in self._providers.items():
            logger.info(f"Shutting down backend provider: {name}")
            await provider.shutdown()

    async def resolve_chain(self, names: list[str]) -> BackendProvider:
        for name in names:
            provider = self._providers.get(name)
            if not provider:
                logger.warning(f"Backend provider '{name}' not registered, skipping")
                continue
            health = await provider.health_check()
            if health.get("status") == "healthy":
                return provider
            logger.warning(f"Backend provider '{name}' unhealthy: {health}")
        raise RuntimeError(f"No healthy backend in chain: {names}")
