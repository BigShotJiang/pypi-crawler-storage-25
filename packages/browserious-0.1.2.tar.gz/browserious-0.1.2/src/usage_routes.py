import logging
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from src.auth import AuthContext, get_auth_context
from src.config import settings
from src.database import async_session
from src.db_models import UsageEvent

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Usage & Billing"])


class UsageSummary(BaseModel):
    period_start: datetime
    period_end: datetime
    session_count: int
    total_session_seconds: int
    profile_count: int
    profile_storage_bytes: int


class PaddleWebhookPayload(BaseModel):
    event_type: str
    data: dict = Field(default_factory=dict)


class PaddleWebhookResponse(BaseModel):
    received: bool


def _require_user(auth: AuthContext) -> None:
    if auth.is_legacy or not auth.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Usage API requires user authentication")


def _count_profiles(user_id) -> tuple[int, int]:
    tenant_dir = settings.profiles_path / str(user_id)
    if not tenant_dir.exists():
        return 0, 0
    count = 0
    total_bytes = 0
    for profile_dir in tenant_dir.iterdir():
        if profile_dir.is_dir():
            count += 1
            for f in profile_dir.rglob("*"):
                if f.is_file():
                    total_bytes += f.stat().st_size
    return count, total_bytes


@router.get("/usage/summary", response_model=UsageSummary)
async def get_usage_summary(
    since: Optional[datetime] = Query(default=None, description="Period start (defaults to current month)"),
    until: Optional[datetime] = Query(default=None, description="Period end (defaults to now)"),
    auth: AuthContext = Depends(get_auth_context),
):
    _require_user(auth)

    now = datetime.now(timezone.utc)
    if since is None:
        since = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if until is None:
        until = now

    async with async_session() as session:
        result = await session.execute(
            select(
                func.count().label("session_count"),
                func.coalesce(func.sum(UsageEvent.duration_seconds), 0).label("total_seconds"),
            )
            .where(UsageEvent.user_id == auth.user_id)
            .where(UsageEvent.event_type == "session.close")
            .where(UsageEvent.created_at >= since)
            .where(UsageEvent.created_at <= until)
        )
        row = result.one()
        session_count = row.session_count
        total_seconds = row.total_seconds

    profile_count, storage_bytes = _count_profiles(auth.user_id)

    return UsageSummary(
        period_start=since,
        period_end=until,
        session_count=session_count,
        total_session_seconds=total_seconds,
        profile_count=profile_count,
        profile_storage_bytes=storage_bytes,
    )


@router.post("/billing/paddle/webhook", response_model=PaddleWebhookResponse)
async def paddle_webhook(request: Request):
    body = await request.json()
    event_type = body.get("event_type", "unknown")
    logger.info(f"Paddle webhook received: {event_type}")

    return PaddleWebhookResponse(received=True)
