import asyncio
import random
import re
import time
from contextlib import asynccontextmanager
from typing import Literal, Optional

from fastapi import Depends, FastAPI, HTTPException, Query, Request, UploadFile, File, WebSocket, WebSocketDisconnect, status
from fastapi.exceptions import RequestValidationError
from starlette.middleware.sessions import SessionMiddleware
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response, HTMLResponse
from playwright.async_api import Page
from playwright._impl._errors import TimeoutError as PlaywrightTimeoutError, Error as PlaywrightError
from pydantic import ValidationError

from sqlalchemy import select

from src.audit import record_event
from src.audit_routes import router as audit_router
from src.auth import AuthContext, get_auth_context, verify_api_key
from src.browser_manager import BrowserSession, manager
from src.db_models import TenantConfig
from src.database import async_session as db_session
from src.config import settings
from src.database import close_db, init_db
from src.oauth import router as oauth_router
from src.tenant_routes import router as tenant_router
from src.token_routes import router as token_router
from src.usage_routes import router as usage_router
from src.extension_manager import extension_manager
from src.image_utils import process_screenshot
from src.input_proxy import get_display_screenshot, get_mouse_position, proxy_input_playlist
from src.models import (
    DETAIL_TO_ERROR_CODE,
    CaptchaButton,
    CaptchaClickResult,
    CaptchaDetectionResponse,
    CaptchaGridCell,
    CaptchaRegion,
    CaptchaSegmentationResponse,
    CaptchaSolveRequest,
    CaptchaSolveResponse,
    ClickRequest,
    ClickResponse,
    ContentResponse,
    ElementAtPointResponse,
    ErrorResponse,
    EvalRequest,
    EvalResponse,
    ExtensionDeleteResponse,
    ExtensionInfo,
    ExtensionListResponse,
    FillRequest,
    FillResponse,
    GotoRequest,
    GotoResponse,
    InitScriptRequest,
    InitScriptResponse,
    InputPlaylist,
    InputPlayResult,
    InspectResponse,
    MousePositionResponse,
    InspectedRequest,
    PageCreate,
    PageInfo,
    PageListResponse,
    ProfileDeleteResponse,
    ProfileImportResponse,
    ProfileSaveResponse,
    ProfileState,
    RequestTiming,
    RouteCreate,
    RouteDeleteResponse,
    RouteInfo,
    RouteListResponse,
    SessionCloseResponse,
    SessionCreate,
    SessionDetails,
    SessionInfo,
    SessionListResponse,
    SessionResponse,
    WindowInfo,
    TypeRequest,
    TypeResponse,
    ViewportConfig,
    WaitForSelectorRequest,
    WaitForSelectorResponse,
)
from src.cdp_proxy import forward_cdp_messages
from src.profile_manager import profile_manager
from src.selectors import SelectorStrategy
from src.vnc_proxy import forward_vnc_connection

import logging

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    await manager.start()
    cleanup_task = asyncio.create_task(manager.cleanup_expired_sessions())
    yield
    cleanup_task.cancel()
    await manager.shutdown()
    await close_db()


tags_metadata = [
    {"name": "Health", "description": "API health check"},
    {"name": "Sessions", "description": "Browser session lifecycle management"},
    {"name": "Pages", "description": "Page/tab operations within a session"},
    {"name": "Routes", "description": "Request interception (block, redirect, override, inspect)"},
    {"name": "Input", "description": "Hardware-level mouse/keyboard simulation"},
    {"name": "Extensions", "description": "Chrome extension management"},
    {"name": "Profiles", "description": "Browser profile state import/export"},
    {"name": "VNC", "description": "Remote viewing via VNC"},
    {"name": "CDP", "description": "Chrome DevTools Protocol access"},
]

app = FastAPI(
    title="Browserious API",
    version="1.0.0",
    description="Self-hosted browser-as-a-service for automation, testing, and web scraping. Provides API-controlled browser instances with VNC viewing, CDP access, request interception, and hardware-level input simulation.",
    lifespan=lifespan,
    openapi_tags=tags_metadata,
)

app.add_middleware(SessionMiddleware, secret_key=settings.jwt_secret or "dev-session-secret")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://browserious.com"],
    allow_origin_regex=r"^(https://.*\.browserious\.pages\.dev|http://localhost:\d+)$",
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)

app.include_router(oauth_router)
app.include_router(token_router)
app.include_router(tenant_router)
app.include_router(audit_router)
app.include_router(usage_router)


def _error_json(status_code: int, detail: str, error_code: str, context: dict | None = None) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content=ErrorResponse(detail=detail, error_code=error_code, context=context).model_dump(exclude_none=True),
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return _error_json(422, "Request validation failed", "VALIDATION_ERROR", {"errors": exc.errors()})


@app.exception_handler(ValidationError)
async def pydantic_validation_exception_handler(request: Request, exc: ValidationError) -> JSONResponse:
    return _error_json(422, "Validation failed", "VALIDATION_ERROR", {"errors": exc.errors()})


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    detail = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
    error_code = DETAIL_TO_ERROR_CODE.get(detail)
    if not error_code:
        for prefix, code in DETAIL_TO_ERROR_CODE.items():
            if detail.startswith(prefix):
                error_code = code
                break
        else:
            error_code = "HTTP_ERROR"
    return _error_json(exc.status_code, detail, error_code)


@app.exception_handler(PlaywrightTimeoutError)
async def playwright_timeout_handler(request: Request, exc: PlaywrightTimeoutError) -> JSONResponse:
    return _error_json(408, "Playwright operation timed out", "TIMEOUT", {"message": str(exc)})


STRICT_MODE_RE = re.compile(r"strict mode violation.*resolved to (\d+) elements")


@app.exception_handler(PlaywrightError)
async def playwright_error_handler(request: Request, exc: PlaywrightError) -> JSONResponse:
    message = str(exc)
    if STRICT_MODE_RE.search(message):
        return _error_json(400, "Selector matched multiple elements (strict mode). Use a more specific selector.", "STRICT_MODE_VIOLATION", {"message": message})
    if "SyntaxError" in message or "is not valid JavaScript" in message:
        return _error_json(400, "Invalid JavaScript", "INVALID_SCRIPT", {"message": message})
    if "waiting for" in message.lower() and ("visible" in message.lower() or "hidden" in message.lower() or "attached" in message.lower() or "detached" in message.lower()):
        return _error_json(408, "Element wait condition not met within timeout", "WAIT_TIMEOUT", {"message": message})
    return _error_json(422, "Playwright operation failed", "PLAYWRIGHT_ERROR", {"message": message})


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    return _error_json(500, "Internal server error", "INTERNAL_ERROR", {"type": type(exc).__name__})


async def get_verified_session(session_id: str, auth: AuthContext) -> BrowserSession:
    session = await manager.get_session(session_id)
    if not session:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    if not auth.is_legacy and auth.user_id and session.user_id and auth.user_id != session.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Session not found")
    return session


@app.get("/health", tags=["Health"])
async def health() -> dict[str, str]:
    """Health check endpoint. Returns {"status": "ok"} if the API is running."""
    return {"status": "ok"}


@app.get("/vnc.html", response_class=HTMLResponse, tags=["VNC"])
async def vnc_viewer(session: str):
    """Returns an HTML page with embedded noVNC viewer for the specified session."""
    return f"""<!DOCTYPE html>
<html>
<head>
    <title>Browserious VNC - {session[:8]}</title>
    <style>
        html, body {{ margin: 0; padding: 0; height: 100%; overflow: hidden; }}
        #screen {{ width: 100%; height: 100%; background: #000; }}
        #status {{ position: fixed; top: 10px; left: 10px; color: #0f0; font-family: monospace; z-index: 1000; }}
    </style>
</head>
<body>
    <div id="status">Connecting...</div>
    <div id="screen"></div>
    <script src="https://cdn.jsdelivr.net/npm/@novnc/novnc@1.4.0/lib/rfb.js"></script>
    <script>
        (function() {{
            const status = document.getElementById('status');
            const wsUrl = 'ws://' + window.location.host + '/sessions/{session}/vnc';
            status.textContent = 'Connecting to ' + wsUrl;

            // Load noVNC dynamically
            const script = document.createElement('script');
            script.type = 'module';
            script.textContent = `
                import RFB from 'https://cdn.jsdelivr.net/npm/@novnc/novnc@1.4.0/core/rfb.js';

                const status = document.getElementById('status');
                const wsUrl = 'ws://' + window.location.host + '/sessions/{session}/vnc';

                try {{
                    const rfb = new RFB(document.getElementById('screen'), wsUrl);
                    rfb.scaleViewport = true;
                    rfb.resizeSession = true;
                    rfb.clipViewport = false;
                    rfb.showDotCursor = true;

                    rfb.addEventListener('connect', () => {{
                        status.textContent = 'Connected';
                        setTimeout(() => status.style.display = 'none', 2000);
                    }});
                    rfb.addEventListener('disconnect', (e) => {{
                        status.style.display = 'block';
                        status.textContent = 'Disconnected: ' + (e.detail.clean ? 'clean' : 'error');
                    }});
                    rfb.addEventListener('credentialsrequired', () => {{
                        status.textContent = 'Credentials required (none set)';
                    }});
                }} catch (err) {{
                    status.textContent = 'Error: ' + err.message;
                    console.error(err);
                }}
            `;
            document.body.appendChild(script);
        }})();
    </script>
</body>
</html>"""


async def _get_tenant_limits(user_id) -> TenantConfig | None:
    if not user_id:
        return None
    async with db_session() as session:
        result = await session.execute(
            select(TenantConfig).where(TenantConfig.user_id == user_id)
        )
        return result.scalar_one_or_none()


@app.post("/sessions", response_model=SessionResponse, tags=["Sessions"])
async def create_session(req: SessionCreate, auth: AuthContext = Depends(get_auth_context)):
    """Create a new browser session. Returns session_id, CDP/VNC URLs, and expiration time. Optionally specify profile_id for persistent storage, proxy config, extensions, viewport size, and timeout."""
    if len(manager.sessions) >= settings.max_sessions:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Maximum concurrent sessions reached"
        )

    timeout = req.timeout
    if not auth.is_legacy and auth.user_id:
        tenant_config = await _get_tenant_limits(auth.user_id)
        max_sessions = tenant_config.max_sessions if tenant_config else 5
        max_duration = tenant_config.max_session_duration if tenant_config else 3600
        user_sessions = sum(1 for s in manager.sessions.values() if s.user_id == auth.user_id)
        if user_sessions >= max_sessions:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Tenant session limit reached ({max_sessions})"
            )
        timeout = min(timeout, max_duration)

    session = await manager.create_session(
        profile_id=req.profile_id,
        proxy=req.proxy.model_dump() if req.proxy else None,
        extensions=req.extensions if req.extensions else None,
        viewport=req.viewport.model_dump(),
        user_agent=req.user_agent,
        timeout=timeout,
        timezone=req.timezone,
        locale=req.locale,
        languages=req.languages,
        chrome_args=req.chrome_args if req.chrome_args else None,
        stealth=req.stealth.model_dump() if req.stealth else None,
        user_id=auth.user_id,
    )

    user_agent = session.user_agent
    window_info = None

    page = session.context.pages[0] if session.context.pages else await session.context.new_page()
    await page.wait_for_load_state("domcontentloaded")
    browser_info = await page.evaluate("""(() => ({
        userAgent: navigator.userAgent,
        screenX: window.screenX,
        screenY: window.screenY,
        chromeWidth: window.outerWidth - window.innerWidth,
        chromeHeight: window.outerHeight - window.innerHeight
    }))()""")
    if not user_agent:
        user_agent = browser_info.get("userAgent")
    window_info = WindowInfo(
        screen_x=browser_info["screenX"],
        screen_y=browser_info["screenY"],
        chrome_width=browser_info["chromeWidth"],
        chrome_height=browser_info["chromeHeight"],
    )

    await record_event(auth.user_id, "session.create", session_id=session.session_id, metadata={"profile_id": session.profile_id, "backend": session.backend_name})

    base_url = f"{settings.api_host}:{settings.api_port}"
    if session.tls:
        vnc_url = session.vnc_url
        web_vnc_url = ""
    else:
        vnc_url = f"ws://{base_url}/sessions/{session.session_id}/vnc"
        web_vnc_url = f"http://{base_url}/vnc.html?session={session.session_id}"
    return SessionResponse(
        session_id=session.session_id,
        profile_id=session.profile_id,
        cdp_url=session.cdp_url,
        vnc_url=vnc_url,
        input_url=session.input_url,
        vnc_password=session.vnc_password,
        session_token=session.session_token,
        web_vnc_url=web_vnc_url,
        container_id=session.container_id,
        created_at=session.created_at,
        expires_at=session.expires_at,
        user_agent=user_agent,
        window_info=window_info,
        routing_headers=session.routing_headers,
    )


@app.get("/sessions", response_model=SessionListResponse, tags=["Sessions"])
async def list_sessions(auth: AuthContext = Depends(get_auth_context)):
    """List all active browser sessions with their IDs, profile IDs, creation/expiration times, and page counts."""
    visible = manager.sessions.values()
    if not auth.is_legacy and auth.user_id:
        visible = [s for s in visible if s.user_id == auth.user_id]
    sessions = [
        SessionInfo(
            session_id=s.session_id,
            profile_id=s.profile_id,
            created_at=s.created_at,
            expires_at=s.expires_at,
            page_count=len(s.context.pages),
            route_count=0,
        )
        for s in visible
    ]
    return SessionListResponse(sessions=sessions, total=len(sessions))


@app.get("/sessions/{session_id}", response_model=SessionDetails, tags=["Sessions"])
async def get_session(session_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Get detailed information about a session including all pages, routes, extensions, proxy config, and viewport."""
    session = await get_verified_session(session_id, auth)

    pages = [
        PageInfo(
            page_id=f"page-{i}",
            url=page.url,
            title=await page.title(),
        )
        for i, page in enumerate(session.context.pages)
    ]

    user_agent = session.user_agent
    window_info = None

    page = session.context.pages[0] if session.context.pages else await session.context.new_page()
    await page.wait_for_load_state("domcontentloaded")
    browser_info = await page.evaluate("""(() => ({
        userAgent: navigator.userAgent,
        screenX: window.screenX,
        screenY: window.screenY,
        chromeWidth: window.outerWidth - window.innerWidth,
        chromeHeight: window.outerHeight - window.innerHeight
    }))()""")
    if not user_agent:
        user_agent = browser_info.get("userAgent")
    window_info = WindowInfo(
        screen_x=browser_info["screenX"],
        screen_y=browser_info["screenY"],
        chrome_width=browser_info["chromeWidth"],
        chrome_height=browser_info["chromeHeight"],
    )

    return SessionDetails(
        session_id=session.session_id,
        profile_id=session.profile_id,
        container_id=session.container_id,
        created_at=session.created_at,
        expires_at=session.expires_at,
        pages=pages,
        routes=[],
        extensions=session.extensions,
        proxy=session.proxy,
        viewport=ViewportConfig(**session.viewport),
        user_agent=user_agent,
        window_info=window_info,
    )


@app.delete("/sessions/{session_id}", response_model=SessionCloseResponse, tags=["Sessions"])
async def delete_session(session_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Close and terminate a browser session immediately. Stops the browser container and releases resources."""
    await get_verified_session(session_id, auth)
    await manager.close_session(session_id)

    return SessionCloseResponse(status="closed", session_id=session_id)


@app.post("/sessions/{session_id}/profile/save", response_model=ProfileSaveResponse, tags=["Sessions"])
async def save_session_profile(session_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Save the session's browser profile to persistent storage. By default, session changes are ephemeral and discarded on close. Call this to persist cookies, localStorage, etc. to the profile_id."""
    session = await get_verified_session(session_id, auth)

    success = await manager.save_session_profile(session_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to save profile"
        )

    await record_event(auth.user_id, "profile.save", session_id=session_id, metadata={"profile_id": session.profile_id})
    return ProfileSaveResponse(status="saved", profile_id=session.profile_id)


async def get_page_by_id(session: BrowserSession, page_id: str) -> Page:
    try:
        idx = int(page_id.split("-")[1])
        pages = session.context.pages
        if idx < 0 or idx >= len(pages):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Page not found"
            )
        return pages[idx]
    except (IndexError, ValueError):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Page not found"
        )


@app.post("/sessions/{session_id}/pages", response_model=PageInfo, tags=["Pages"])
async def create_page(session_id: str, auth: AuthContext = Depends(get_auth_context), req: PageCreate = None):
    """Create a new browser tab/page in the session. Optionally navigate to a URL immediately."""
    session = await get_verified_session(session_id, auth)

    page = await session.context.new_page()

    if req and req.url:
        await page.goto(req.url)

    page_id = f"page-{len(session.context.pages) - 1}"

    return PageInfo(
        page_id=page_id,
        url=page.url,
        title=await page.title() if req and req.url else "",
    )


@app.get("/sessions/{session_id}/pages", response_model=PageListResponse, tags=["Pages"])
async def list_pages(session_id: str, auth: AuthContext = Depends(get_auth_context)):
    """List all pages/tabs in the session with their IDs, URLs, and titles."""
    session = await get_verified_session(session_id, auth)

    pages = [
        PageInfo(
            page_id=f"page-{i}",
            url=page.url,
            title=await page.title(),
        )
        for i, page in enumerate(session.context.pages)
    ]

    return PageListResponse(pages=pages)


@app.post("/sessions/{session_id}/pages/{page_id}/goto", response_model=GotoResponse, tags=["Pages"])
async def page_goto(session_id: str, page_id: str, req: GotoRequest, auth: AuthContext = Depends(get_auth_context)):
    """Navigate the page to a URL. Specify wait_until ('load', 'domcontentloaded', 'networkidle') and timeout in ms."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)

    start_time = time.time()

    await page.goto(
        req.url,
        wait_until=req.wait_until,
        timeout=req.timeout,
    )

    load_time_ms = int((time.time() - start_time) * 1000)

    return GotoResponse(
        status="ok",
        url=page.url,
        title=await page.title(),
        load_time_ms=load_time_ms,
    )


@app.post("/sessions/{session_id}/pages/{page_id}/click", response_model=ClickResponse, tags=["Pages"])
async def page_click(session_id: str, page_id: str, req: ClickRequest, auth: AuthContext = Depends(get_auth_context)):
    """Click an element using selector (css, xpath, text, role, or js strategy). Set force=true to click non-interactive elements."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)
    locator = SelectorStrategy.locate(page, req.selector)

    await locator.click(
        timeout=req.timeout,
        force=req.force,
    )

    return ClickResponse(status="ok", selector=req.selector)


@app.post("/sessions/{session_id}/pages/{page_id}/type", response_model=TypeResponse, tags=["Pages"])
async def page_type(session_id: str, page_id: str, req: TypeRequest, auth: AuthContext = Depends(get_auth_context)):
    """Type text into an element with keyboard events. Set delay (ms) between keystrokes and clear=true to clear existing text first."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)
    locator = SelectorStrategy.locate(page, req.selector)

    if req.clear:
        await locator.clear()

    await locator.press_sequentially(req.text, delay=req.delay)

    return TypeResponse(status="ok", text=req.text)


@app.post("/sessions/{session_id}/pages/{page_id}/fill", response_model=FillResponse, tags=["Pages"])
async def page_fill(session_id: str, page_id: str, req: FillRequest, auth: AuthContext = Depends(get_auth_context)):
    """Fill an input field with a value (fast, no keyboard events). Clears existing content before filling."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)
    locator = SelectorStrategy.locate(page, req.selector)

    await locator.fill(req.value)

    return FillResponse(status="ok", value=req.value)


@app.post("/sessions/{session_id}/pages/{page_id}/waitForSelector", response_model=WaitForSelectorResponse, tags=["Pages"])
async def page_wait_for_selector(session_id: str, page_id: str, req: WaitForSelectorRequest, auth: AuthContext = Depends(get_auth_context)):
    """Wait for an element to reach a state ('visible', 'hidden', 'attached', 'detached'). Returns wait time in ms."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)
    locator = SelectorStrategy.locate(page, req.selector)

    start_time = time.time()

    await locator.wait_for(state=req.state, timeout=req.timeout)

    wait_time_ms = int((time.time() - start_time) * 1000)

    return WaitForSelectorResponse(
        status="ok",
        found=True,
        wait_time_ms=wait_time_ms,
    )


@app.post("/sessions/{session_id}/pages/{page_id}/eval", response_model=EvalResponse, tags=["Pages"])
async def page_eval(session_id: str, page_id: str, req: EvalRequest, auth: AuthContext = Depends(get_auth_context)):
    """Execute JavaScript in the page context. Pass args array for parameters. Returns the evaluated result."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)

    result = await page.evaluate(req.script, req.args)

    return EvalResponse(result=result)


@app.get("/sessions/{session_id}/pages/{page_id}/content", response_model=ContentResponse, tags=["Pages"])
async def page_content(session_id: str, page_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Get the full HTML content of the page including doctype and all elements."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)

    html = await page.content()

    return ContentResponse(html=html, length=len(html))


@app.post("/sessions/{session_id}/pages/{page_id}/initScript", response_model=InitScriptResponse, tags=["Pages"])
async def add_page_init_script(session_id: str, page_id: str, req: InitScriptRequest, auth: AuthContext = Depends(get_auth_context)):
    """Add an initialization script to a page. The script runs before any page JS on every navigation, including the current page on next navigation. Use for pre-load overrides (timezone, WebGL, etc.)."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)
    await page.add_init_script(req.script)

    return InitScriptResponse(status="ok", scope="page")


@app.post("/sessions/{session_id}/initScript", response_model=InitScriptResponse, tags=["Sessions"])
async def add_context_init_script(session_id: str, req: InitScriptRequest, auth: AuthContext = Depends(get_auth_context)):
    """Add an initialization script to the browser context. The script runs before any page JS on every navigation for all pages in the session, including new pages."""
    session = await get_verified_session(session_id, auth)

    await session.context.add_init_script(req.script)

    return InitScriptResponse(status="ok", scope="context")


@app.post("/sessions/{session_id}/routes", response_model=RouteInfo, tags=["Routes"])
async def create_route(session_id: str, req: RouteCreate, auth: AuthContext = Depends(get_auth_context)):
    """Create a request interception route. Actions: 'block', 'redirect' (with url), 'override' (with status/headers/body), or 'inspect' (capture requests)."""
    session = await get_verified_session(session_id, auth)

    route_id = await session.route_manager.register_route(
        session.context,
        req.pattern,
        req.action,
    )

    return RouteInfo(
        route_id=route_id,
        pattern=req.pattern,
        action=req.action,
    )


@app.get("/sessions/{session_id}/routes", response_model=RouteListResponse, tags=["Routes"])
async def list_routes(session_id: str, auth: AuthContext = Depends(get_auth_context)):
    """List all active request interception routes for the session."""
    session = await get_verified_session(session_id, auth)

    routes = [
        RouteInfo(
            route_id=r.route_id,
            pattern=r.pattern,
            action=r.action,
        )
        for r in session.route_manager.list_routes()
    ]

    return RouteListResponse(routes=routes)


@app.delete("/sessions/{session_id}/routes/{route_id}", response_model=RouteDeleteResponse, tags=["Routes"])
async def delete_route(session_id: str, route_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Remove an interception route, stopping the pattern from being matched."""
    session = await get_verified_session(session_id, auth)

    route_info = session.route_manager.get_route(route_id)
    if not route_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Route not found"
        )

    await session.route_manager.unregister_route(session.context, route_id)

    return RouteDeleteResponse(status="deleted", route_id=route_id)


@app.get("/sessions/{session_id}/routes/{route_id}/inspect", response_model=InspectResponse, tags=["Routes"])
async def get_captured_requests(session_id: str, route_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Get all requests captured by an 'inspect' type route, including method, URL, headers, and body."""
    session = await get_verified_session(session_id, auth)

    route_info = session.route_manager.get_route(route_id)
    if not route_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Route not found"
        )

    requests = [
        InspectedRequest(
            timestamp=r.timestamp,
            method=r.method,
            url=r.url,
            headers=r.headers,
            body=r.body,
            response=None,
            timing=RequestTiming(
                start_time=r.timestamp,
                end_time=r.timestamp,
                duration_ms=0,
            ),
        )
        for r in route_info.captured_requests
    ]

    return InspectResponse(
        route_id=route_id,
        pattern=route_info.pattern,
        requests=requests,
        total=len(requests),
    )


@app.post("/extensions", response_model=ExtensionInfo, dependencies=[Depends(verify_api_key)], tags=["Extensions"])
async def upload_extension(file: UploadFile = File(..., description="Chrome extension file (.zip or .crx)")):
    """Upload a Chrome extension. Returns extension_id to use when creating sessions. Accepts .zip or .crx files."""
    if not file.filename or not file.filename.endswith(('.zip', '.crx')):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File must be .zip or .crx"
        )

    file_data = await file.read()

    info = await extension_manager.upload_extension(file_data, file.filename)

    return ExtensionInfo(
        extension_id=info["extension_id"],
        name=info["name"],
        version=info["version"],
        description=info.get("description"),
        manifest_version=info["manifest_version"],
        permissions=info.get("permissions", []),
        file_size=info["file_size"],
    )


@app.get("/extensions", response_model=ExtensionListResponse, dependencies=[Depends(verify_api_key)], tags=["Extensions"])
async def list_extensions():
    """List all uploaded extensions with their IDs, names, versions, and permissions."""
    extensions_list = extension_manager.list_extensions()
    extensions = [
        ExtensionInfo(
            extension_id=ext["extension_id"],
            name=ext["name"],
            version=ext["version"],
            description=ext.get("description"),
            manifest_version=ext["manifest_version"],
            permissions=ext.get("permissions", []),
            file_size=ext["file_size"],
        )
        for ext in extensions_list
    ]
    return ExtensionListResponse(extensions=extensions, total=len(extensions))


@app.delete("/extensions/{extension_id}", response_model=ExtensionDeleteResponse, dependencies=[Depends(verify_api_key)], tags=["Extensions"])
async def delete_extension(extension_id: str):
    """Delete an uploaded extension. Cannot delete extensions currently in use by active sessions."""
    if not extension_manager.extension_exists(extension_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Extension not found"
        )

    extension_manager.delete_extension(extension_id)

    return ExtensionDeleteResponse(status="deleted", extension_id=extension_id)


def _tenant_id(auth: AuthContext) -> str | None:
    if auth.is_legacy or not auth.user_id:
        return None
    return str(auth.user_id)


@app.get("/profiles/{profile_id}/state", response_model=ProfileState, tags=["Profiles"])
async def export_profile_state(profile_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Export profile state (cookies, localStorage, sessionStorage) for backup or transfer. Works with active or inactive profiles."""
    tenant_id = _tenant_id(auth)
    active_session = None
    for session in manager.sessions.values():
        if session.profile_id == profile_id and (not tenant_id or str(session.user_id) == tenant_id):
            active_session = session
            break

    if not active_session and not profile_manager.profile_exists(profile_id, tenant_id=tenant_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profile not found")

    state = await profile_manager.export_state(
        profile_id,
        active_session.context if active_session else None,
        tenant_id=tenant_id,
    )

    return ProfileState(
        profile_id=state["profile_id"],
        cookies=state.get("cookies", []),
        localStorage=state.get("localStorage", []),
        sessionStorage=state.get("sessionStorage", []),
    )


@app.put("/profiles/{profile_id}/state", response_model=ProfileImportResponse, tags=["Profiles"])
async def import_profile_state(profile_id: str, state: ProfileState, auth: AuthContext = Depends(get_auth_context)):
    """Import profile state (cookies, localStorage, sessionStorage). Creates profile if it doesn't exist."""
    tenant_id = _tenant_id(auth)

    if tenant_id and not profile_manager.profile_exists(profile_id, tenant_id=tenant_id):
        tenant_config = await _get_tenant_limits(auth.user_id)
        max_profiles = tenant_config.max_profiles if tenant_config else 50
        tenant_dir = settings.profiles_path / tenant_id
        existing_count = sum(1 for p in tenant_dir.iterdir() if p.is_dir()) if tenant_dir.exists() else 0
        if existing_count >= max_profiles:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Profile limit reached ({max_profiles})"
            )

    await profile_manager.import_state(profile_id, state.model_dump(), tenant_id=tenant_id)
    await record_event(auth.user_id, "profile.import", metadata={"profile_id": profile_id})

    return ProfileImportResponse(
        status="imported",
        profile_id=profile_id,
        imported={
            "cookies": len(state.cookies),
            "localStorage_origins": len(state.localStorage),
            "sessionStorage_origins": len(state.sessionStorage),
        }
    )


@app.delete("/profiles/{profile_id}", response_model=ProfileDeleteResponse, tags=["Profiles"])
async def delete_profile(profile_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Delete a profile and all its stored data. Fails if profile is in use by an active session."""
    tenant_id = _tenant_id(auth)
    for session in manager.sessions.values():
        if session.profile_id == profile_id and (not tenant_id or str(session.user_id) == tenant_id):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Profile is in use by active session"
            )

    if not profile_manager.profile_exists(profile_id, tenant_id=tenant_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Profile not found"
        )

    profile_manager.delete_profile(profile_id, tenant_id=tenant_id)
    await record_event(auth.user_id, "profile.delete", metadata={"profile_id": profile_id})

    return ProfileDeleteResponse(status="deleted", profile_id=profile_id)


@app.websocket("/sessions/{session_id}/cdp")
async def cdp_websocket(websocket: WebSocket, session_id: str):
    """WebSocket proxy to Chrome DevTools Protocol. Use with Puppeteer or Playwright connectOverCDP()."""
    await websocket.accept()

    session = await manager.get_session(session_id)
    if not session:
        await websocket.close(code=1008, reason="Session not found")
        return

    if not session.cdp_url:
        await websocket.close(code=1011, reason="CDP endpoint not available")
        return

    try:
        await forward_cdp_messages(websocket, session.cdp_url)
    except WebSocketDisconnect:
        logger.info(f"CDP WebSocket disconnected for session {session_id}")
    except Exception as e:
        logger.error(f"CDP WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal error")


@app.websocket("/sessions/{session_id}/vnc")
async def vnc_websocket(websocket: WebSocket, session_id: str):
    """WebSocket proxy to VNC server for remote viewing. Use with noVNC client or /vnc.html page."""
    await websocket.accept()

    session = await manager.get_session(session_id)
    if not session:
        await websocket.close(code=1008, reason="Session not found")
        return

    try:
        await forward_vnc_connection(
            websocket,
            session.vnc_host,
            session.vnc_port,
        )
    except WebSocketDisconnect:
        logger.info(f"VNC WebSocket disconnected for session {session_id}")
    except Exception as e:
        logger.error(f"VNC WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal error")


@app.post("/sessions/{session_id}/input/play", response_model=InputPlayResult, tags=["Input"])
async def play_input(session_id: str, playlist: InputPlaylist, auth: AuthContext = Depends(get_auth_context)):
    """Execute a sequence of hardware-level mouse/keyboard actions. Supports move, click, type_text, key, scroll with easing and timing. Coordinates are in screen space (not viewport)."""
    session = await get_verified_session(session_id, auth)

    return await proxy_input_playlist(session, playlist)


@app.get("/sessions/{session_id}/input/position", response_model=MousePositionResponse, tags=["Input"])
async def get_input_position(session_id: str, auth: AuthContext = Depends(get_auth_context)):
    """Get current mouse cursor position in screen coordinates. Use with /display/screenshot or to calculate viewport offsets."""
    session = await get_verified_session(session_id, auth)

    x, y = await get_mouse_position(session)
    return MousePositionResponse(x=x, y=y)


@app.get("/sessions/{session_id}/pages/{page_id}/elementAtPoint", response_model=ElementAtPointResponse, tags=["Pages"])
async def element_at_point(
    session_id: str,
    page_id: str,
    x: int = Query(..., description="X coordinate in viewport"),
    y: int = Query(..., description="Y coordinate in viewport"),
    auth: AuthContext = Depends(get_auth_context),
):
    """Get the DOM element at the specified viewport coordinates. Returns element info including tag, id, classes, text, bounding box, and generated selectors."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)

    result = await page.evaluate("""([x, y]) => {
        const el = document.elementFromPoint(x, y);
        if (!el) return { found: false };

        const rect = el.getBoundingClientRect();
        const attrs = {};
        for (const attr of el.attributes) {
            attrs[attr.name] = attr.value;
        }

        function getXPath(element) {
            if (element.id) return `//*[@id="${element.id}"]`;
            if (element === document.body) return '/html/body';
            let ix = 0;
            const siblings = element.parentNode ? element.parentNode.childNodes : [];
            for (const sibling of siblings) {
                if (sibling === element) {
                    const parentPath = element.parentNode ? getXPath(element.parentNode) : '';
                    return `${parentPath}/${element.tagName.toLowerCase()}[${ix + 1}]`;
                }
                if (sibling.nodeType === 1 && sibling.tagName === element.tagName) ix++;
            }
            return '';
        }

        function getCssSelector(element) {
            if (element.id) return `#${element.id}`;
            let selector = element.tagName.toLowerCase();
            if (element.className && typeof element.className === 'string') {
                const classes = element.className.trim().split(/\\s+/).filter(c => c);
                if (classes.length) selector += '.' + classes.join('.');
            }
            return selector;
        }

        return {
            found: true,
            tag_name: el.tagName.toLowerCase(),
            id: el.id || null,
            class_name: el.className || null,
            text_content: el.textContent ? el.textContent.slice(0, 200).trim() : null,
            bounding_box: {
                x: rect.x,
                y: rect.y,
                width: rect.width,
                height: rect.height
            },
            attributes: attrs,
            xpath: getXPath(el),
            css_selector: getCssSelector(el)
        };
    }""", [x, y])

    return ElementAtPointResponse(**result)


@app.get("/sessions/{session_id}/screenshot", tags=["Sessions"])
async def screenshot(
    session_id: str,
    page_id: str = Query(default="page-0", description="Page ID (ignored when fullscreen=true)"),
    full_page: bool = Query(default=False, description="Capture full scrollable page (ignored when fullscreen=true)"),
    fullscreen: bool = Query(default=False, description="Capture full X11 display instead of page viewport"),
    type: Literal["png", "jpeg"] = Query(default="png", description="Image format"),
    quality: int = Query(default=80, ge=0, le=100, description="JPEG quality (0-100)"),
    cursor: bool = Query(default=False, description="Draw cursor overlay on screenshot"),
    crop_x: Optional[int] = Query(default=None, description="Crop region X coordinate"),
    crop_y: Optional[int] = Query(default=None, description="Crop region Y coordinate"),
    crop_width: Optional[int] = Query(default=None, ge=1, description="Crop region width"),
    crop_height: Optional[int] = Query(default=None, ge=1, description="Crop region height"),
    auth: AuthContext = Depends(get_auth_context),
):
    """Capture a screenshot. By default captures the page viewport. Set fullscreen=true to capture the full X11 display (includes browser chrome). Supports cursor overlay and cropping."""
    session = await get_verified_session(session_id, auth)

    cursor_x, cursor_y = None, None

    if fullscreen:
        screenshot_bytes = await get_display_screenshot(session)
        if cursor:
            cursor_x, cursor_y = await get_mouse_position(session)
    else:
        page = await get_page_by_id(session, page_id)
        screenshot_args = {"full_page": full_page, "type": type}
        if type == "jpeg":
            screenshot_args["quality"] = quality
        screenshot_bytes = await page.screenshot(**screenshot_args)

        if cursor:
            screen_x, screen_y = await get_mouse_position(session)
            browser_info = await page.evaluate("""(() => ({
                screenX: window.screenX,
                screenY: window.screenY,
                chromeHeight: window.outerHeight - window.innerHeight,
                scrollX: window.scrollX,
                scrollY: window.scrollY
            }))()""")
            cursor_x = screen_x - browser_info["screenX"]
            cursor_y = screen_y - browser_info["screenY"] - browser_info["chromeHeight"]
            if full_page:
                cursor_x += browser_info["scrollX"]
                cursor_y += browser_info["scrollY"]

    screenshot_bytes = process_screenshot(
        screenshot_bytes,
        cursor_x=cursor_x,
        cursor_y=cursor_y,
        crop_x=crop_x,
        crop_y=crop_y,
        crop_width=crop_width,
        crop_height=crop_height,
        output_format=type,
        quality=quality,
    )

    media_type = f"image/{type}"
    return Response(content=screenshot_bytes, media_type=media_type)


@app.get("/sessions/{session_id}/pages/{page_id}/captchas", response_model=CaptchaDetectionResponse, tags=["Pages"])
async def detect_captchas(
    session_id: str,
    page_id: str,
    auth: AuthContext = Depends(get_auth_context),
):
    """Detect CAPTCHA elements on the page. Identifies reCAPTCHA, hCaptcha, Cloudflare Turnstile, and other common CAPTCHA providers. Returns bounding boxes and viewport coordinates for each detected CAPTCHA."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)

    captchas = await page.evaluate("""() => {
        const results = [];

        const captchaPatterns = [
            { selector: 'iframe[src*="recaptcha"]', type: 'iframe', provider: 'recaptcha' },
            { selector: 'iframe[src*="hcaptcha"]', type: 'iframe', provider: 'hcaptcha' },
            { selector: 'iframe[src*="challenges.cloudflare.com"]', type: 'iframe', provider: 'turnstile' },
            { selector: 'iframe[src*="arkoselabs"]', type: 'iframe', provider: 'funcaptcha' },
            { selector: 'iframe[src*="geetest"]', type: 'iframe', provider: 'geetest' },
            { selector: '.g-recaptcha', type: 'widget', provider: 'recaptcha' },
            { selector: '.h-captcha', type: 'widget', provider: 'hcaptcha' },
            { selector: '[data-sitekey]', type: 'widget', provider: 'generic' },
            { selector: '.cf-turnstile', type: 'widget', provider: 'turnstile' },
            { selector: '#captcha', type: 'element', provider: 'generic' },
            { selector: '[class*="captcha"]', type: 'element', provider: 'generic' },
            { selector: '[id*="captcha"]', type: 'element', provider: 'generic' },
        ];

        const seen = new Set();

        for (const pattern of captchaPatterns) {
            const elements = document.querySelectorAll(pattern.selector);
            for (const el of elements) {
                const rect = el.getBoundingClientRect();
                if (rect.width < 10 || rect.height < 10) continue;

                const key = `${Math.round(rect.x)}-${Math.round(rect.y)}-${Math.round(rect.width)}-${Math.round(rect.height)}`;
                if (seen.has(key)) continue;
                seen.add(key);

                let selector = pattern.selector;
                if (el.id) selector = `#${el.id}`;
                else if (el.className && typeof el.className === 'string') {
                    const classes = el.className.trim().split(/\\s+/).filter(c => c);
                    if (classes.length) selector = el.tagName.toLowerCase() + '.' + classes.join('.');
                }

                results.push({
                    type: pattern.type,
                    provider: pattern.provider,
                    bounding_box: {
                        x: rect.x,
                        y: rect.y,
                        width: rect.width,
                        height: rect.height
                    },
                    viewport_coords: {
                        x: Math.round(rect.x),
                        y: Math.round(rect.y),
                        center_x: Math.round(rect.x + rect.width / 2),
                        center_y: Math.round(rect.y + rect.height / 2)
                    },
                    iframe_src: el.tagName === 'IFRAME' ? el.src : null,
                    element_selector: selector
                });
            }
        }

        return results;
    }""")

    return CaptchaDetectionResponse(
        found=len(captchas) > 0,
        count=len(captchas),
        captchas=[CaptchaRegion(**c) for c in captchas],
    )


@app.get("/sessions/{session_id}/pages/{page_id}/captcha/segment", response_model=CaptchaSegmentationResponse, tags=["Pages"])
async def segment_captcha(
    session_id: str,
    page_id: str,
    captcha_index: int = Query(default=0, ge=0, description="Index of captcha to segment (from /captchas endpoint)"),
    auth: AuthContext = Depends(get_auth_context),
):
    """Segment a detected CAPTCHA into interactive grid cells and buttons. Returns precise bounding boxes for each cell in screen coordinates, ready for clicking. Works with reCAPTCHA image grids, hCaptcha, and similar providers."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)

    segmentation = await page.evaluate("""(captchaIndex) => {
        const captchaPatterns = [
            { selector: 'iframe[src*="recaptcha"]', type: 'iframe', provider: 'recaptcha' },
            { selector: 'iframe[src*="hcaptcha"]', type: 'iframe', provider: 'hcaptcha' },
            { selector: 'iframe[src*="challenges.cloudflare.com"]', type: 'iframe', provider: 'turnstile' },
            { selector: '.g-recaptcha', type: 'widget', provider: 'recaptcha' },
            { selector: '.h-captcha', type: 'widget', provider: 'hcaptcha' },
        ];

        let captchaEl = null;
        let provider = 'unknown';
        let captchaCount = 0;

        for (const pattern of captchaPatterns) {
            const elements = document.querySelectorAll(pattern.selector);
            for (const el of elements) {
                const rect = el.getBoundingClientRect();
                if (rect.width < 10 || rect.height < 10) continue;
                if (captchaCount === captchaIndex) {
                    captchaEl = el;
                    provider = pattern.provider;
                    break;
                }
                captchaCount++;
            }
            if (captchaEl) break;
        }

        if (!captchaEl) {
            return {
                type: 'unknown',
                provider: null,
                prompt: null,
                grid_rows: null,
                grid_cols: null,
                cells: [],
                buttons: [],
                frame_coords: {}
            };
        }

        const frameRect = captchaEl.getBoundingClientRect();
        const frameCoords = {
            x: Math.round(frameRect.x),
            y: Math.round(frameRect.y),
            width: Math.round(frameRect.width),
            height: Math.round(frameRect.height)
        };

        let gridRows = 3;
        let gridCols = 3;

        if (provider === 'recaptcha') {
            if (frameRect.width > 450) {
                gridRows = 4;
                gridCols = 4;
            }
        } else if (provider === 'hcaptcha') {
            gridRows = 3;
            gridCols = 3;
        }

        const headerHeight = Math.round(frameRect.height * 0.22);
        const footerHeight = Math.round(frameRect.height * 0.12);
        const gridStartY = frameRect.y + headerHeight;
        const gridHeight = frameRect.height - headerHeight - footerHeight;
        const gridWidth = frameRect.width;

        const cellWidth = gridWidth / gridCols;
        const cellHeight = gridHeight / gridRows;

        const cells = [];
        for (let row = 0; row < gridRows; row++) {
            for (let col = 0; col < gridCols; col++) {
                const cellX = Math.round(frameRect.x + col * cellWidth);
                const cellY = Math.round(gridStartY + row * cellHeight);
                const cellW = Math.round(cellWidth);
                const cellH = Math.round(cellHeight);
                cells.push({
                    index: row * gridCols + col,
                    x: cellX,
                    y: cellY,
                    width: cellW,
                    height: cellH,
                    center_x: Math.round(cellX + cellW / 2),
                    center_y: Math.round(cellY + cellH / 2),
                    selected: false
                });
            }
        }

        const buttons = [];
        const verifyButtonY = frameRect.y + frameRect.height - footerHeight / 2;
        buttons.push({
            name: 'verify',
            x: Math.round(frameRect.x + frameRect.width * 0.65),
            y: Math.round(verifyButtonY - 15),
            width: Math.round(frameRect.width * 0.3),
            height: 30,
            center_x: Math.round(frameRect.x + frameRect.width * 0.8),
            center_y: Math.round(verifyButtonY)
        });
        buttons.push({
            name: 'skip',
            x: Math.round(frameRect.x + frameRect.width * 0.05),
            y: Math.round(verifyButtonY - 15),
            width: Math.round(frameRect.width * 0.3),
            height: 30,
            center_x: Math.round(frameRect.x + frameRect.width * 0.2),
            center_y: Math.round(verifyButtonY)
        });

        return {
            type: 'image_grid',
            provider: provider,
            prompt: null,
            grid_rows: gridRows,
            grid_cols: gridCols,
            cells: cells,
            buttons: buttons,
            frame_coords: frameCoords
        };
    }""", captcha_index)

    return CaptchaSegmentationResponse(
        type=segmentation["type"],
        provider=segmentation.get("provider"),
        prompt=segmentation.get("prompt"),
        grid_rows=segmentation.get("grid_rows"),
        grid_cols=segmentation.get("grid_cols"),
        cells=[CaptchaGridCell(**c) for c in segmentation.get("cells", [])],
        buttons=[CaptchaButton(**b) for b in segmentation.get("buttons", [])],
        frame_coords=segmentation.get("frame_coords", {}),
    )


@app.post("/sessions/{session_id}/pages/{page_id}/captcha/solve", response_model=CaptchaSolveResponse, tags=["Pages"])
async def solve_captcha(
    session_id: str,
    page_id: str,
    req: CaptchaSolveRequest,
    captcha_index: int = Query(default=0, ge=0, description="Index of captcha to solve"),
    auth: AuthContext = Depends(get_auth_context),
):
    """Click specified grid cells on a CAPTCHA with human-like timing and optionally click verify. Uses grid cell indices from /captcha/segment endpoint. Coordinates are automatically calculated in screen space for accurate clicking."""
    session = await get_verified_session(session_id, auth)

    page = await get_page_by_id(session, page_id)

    segmentation = await page.evaluate("""(captchaIndex) => {
        const captchaPatterns = [
            { selector: 'iframe[src*="recaptcha"]', type: 'iframe', provider: 'recaptcha' },
            { selector: 'iframe[src*="hcaptcha"]', type: 'iframe', provider: 'hcaptcha' },
            { selector: 'iframe[src*="challenges.cloudflare.com"]', type: 'iframe', provider: 'turnstile' },
            { selector: '.g-recaptcha', type: 'widget', provider: 'recaptcha' },
            { selector: '.h-captcha', type: 'widget', provider: 'hcaptcha' },
        ];

        let captchaEl = null;
        let provider = 'unknown';
        let captchaCount = 0;

        for (const pattern of captchaPatterns) {
            const elements = document.querySelectorAll(pattern.selector);
            for (const el of elements) {
                const rect = el.getBoundingClientRect();
                if (rect.width < 10 || rect.height < 10) continue;
                if (captchaCount === captchaIndex) {
                    captchaEl = el;
                    provider = pattern.provider;
                    break;
                }
                captchaCount++;
            }
            if (captchaEl) break;
        }

        if (!captchaEl) {
            return null;
        }

        const frameRect = captchaEl.getBoundingClientRect();
        let gridRows = 3;
        let gridCols = 3;

        if (provider === 'recaptcha' && frameRect.width > 450) {
            gridRows = 4;
            gridCols = 4;
        }

        const headerHeight = Math.round(frameRect.height * 0.22);
        const footerHeight = Math.round(frameRect.height * 0.12);
        const gridStartY = frameRect.y + headerHeight;
        const gridHeight = frameRect.height - headerHeight - footerHeight;
        const gridWidth = frameRect.width;

        const cellWidth = gridWidth / gridCols;
        const cellHeight = gridHeight / gridRows;

        const cells = [];
        for (let row = 0; row < gridRows; row++) {
            for (let col = 0; col < gridCols; col++) {
                const cellX = Math.round(frameRect.x + col * cellWidth);
                const cellY = Math.round(gridStartY + row * cellHeight);
                const cellW = Math.round(cellWidth);
                const cellH = Math.round(cellHeight);
                cells.push({
                    index: row * gridCols + col,
                    center_x: Math.round(cellX + cellW / 2),
                    center_y: Math.round(cellY + cellH / 2),
                });
            }
        }

        const verifyButtonY = frameRect.y + frameRect.height - footerHeight / 2;
        const verifyButton = {
            center_x: Math.round(frameRect.x + frameRect.width * 0.8),
            center_y: Math.round(verifyButtonY)
        };

        return { cells, verifyButton };
    }""", captcha_index)

    if not segmentation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Captcha not found at specified index"
        )

    browser_info = await page.evaluate("""(() => ({
        screenX: window.screenX,
        screenY: window.screenY,
        chromeHeight: window.outerHeight - window.innerHeight
    }))()""")

    screen_offset_x = browser_info["screenX"]
    screen_offset_y = browser_info["screenY"] + browser_info["chromeHeight"]

    clicked = []
    for cell_index in req.cells:
        if cell_index < 0 or cell_index >= len(segmentation["cells"]):
            clicked.append(CaptchaClickResult(
                cell=cell_index,
                x=0,
                y=0,
                success=False
            ))
            continue

        cell = segmentation["cells"][cell_index]
        screen_x = cell["center_x"] + screen_offset_x
        screen_y = cell["center_y"] + screen_offset_y

        await proxy_input_playlist(session, InputPlaylist(actions=[
            {"type": "move", "x": screen_x, "y": screen_y, "duration_ms": random.randint(100, 200)},
            {"type": "click"}
        ]))

        clicked.append(CaptchaClickResult(
            cell=cell_index,
            x=screen_x,
            y=screen_y,
            success=True
        ))

        delay = random.randint(req.click_delay_min_ms, req.click_delay_max_ms)
        await asyncio.sleep(delay / 1000.0)

    verify_clicked = False
    if req.then_verify and segmentation.get("verifyButton"):
        verify_btn = segmentation["verifyButton"]
        screen_x = verify_btn["center_x"] + screen_offset_x
        screen_y = verify_btn["center_y"] + screen_offset_y

        await asyncio.sleep(random.uniform(0.3, 0.5))

        await proxy_input_playlist(session, InputPlaylist(actions=[
            {"type": "move", "x": screen_x, "y": screen_y, "duration_ms": random.randint(100, 200)},
            {"type": "click"}
        ]))
        verify_clicked = True

    return CaptchaSolveResponse(
        status="ok",
        clicked=clicked,
        verify_clicked=verify_clicked
    )
