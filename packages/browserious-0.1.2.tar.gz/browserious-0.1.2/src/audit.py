import uuid
from typing import Optional

from src.database import async_session
from src.db_models import UsageEvent


async def record_event(
    user_id: Optional[uuid.UUID],
    event_type: str,
    session_id: Optional[str] = None,
    duration_seconds: Optional[int] = None,
    metadata: Optional[dict] = None,
):
    if not user_id:
        return
    async with async_session() as db:
        event = UsageEvent(
            user_id=user_id,
            event_type=event_type,
            session_id=session_id,
            duration_seconds=duration_seconds,
            metadata_=metadata,
        )
        db.add(event)
        await db.commit()
