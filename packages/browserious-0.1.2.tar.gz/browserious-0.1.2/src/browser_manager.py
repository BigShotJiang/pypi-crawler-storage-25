import asyncio
import logging
import secrets
import shutil
import socket
import uuid as uuid_mod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

import httpx
from playwright.async_api import async_playwright, Browser, BrowserContext

from sqlalchemy import select

from src.audit import record_event
from src.backend_provider import BackendProvider, BackendRegistry
from src.backends.byom import BYOMBackend
from src.backends.fly import FlyBackend
from src.config import settings
from src.database import async_session
from src.db_models import TenantConfig
from src.extension_manager import extension_manager
from src.route_manager import RouteManager

logger = logging.getLogger(__name__)


@dataclass
class BrowserSession:
    session_id: str
    profile_id: str
    container_id: str
    container_name: str
    container_ip: str
    created_at: datetime
    expires_at: datetime
    proxy: Optional[dict] = None
    extensions: list[str] = field(default_factory=list)
    viewport: dict = field(default_factory=lambda: {"width": 1920, "height": 1080})
    user_agent: Optional[str] = None
    user_id: Optional[uuid_mod.UUID] = None
    backend_name: str = "byom"
    session_token: str = ""
    vnc_password: str = ""
    cdp_port: int = 9222
    vnc_port: int = 5900
    input_port: int = 8080
    tls: bool = False
    routing_headers: dict[str, str] = field(default_factory=dict)
    browser: Optional[Browser] = None
    context: Optional[BrowserContext] = None
    route_manager: RouteManager = field(default_factory=RouteManager)

    @property
    def cdp_url(self) -> str:
        scheme = "wss" if self.tls else "ws"
        port = f":{self.cdp_port}" if self.cdp_port not in (443, 80) else ""
        return f"{scheme}://{self.container_ip}{port}"

    @property
    def vnc_host(self) -> str:
        return self.container_ip

    @property
    def vnc_url(self) -> str:
        scheme = "wss" if self.tls else "ws"
        port = f":{self.vnc_port}" if self.vnc_port not in (443, 80) else ""
        return f"{scheme}://{self.container_ip}{port}/vnc"

    @property
    def input_url(self) -> str:
        scheme = "https" if self.tls else "http"
        port = f":{self.input_port}" if self.input_port not in (443, 80) else ""
        return f"{scheme}://{self.container_ip}{port}"


class BrowserManager:
    def __init__(self, registry: BackendRegistry | None = None):
        self.sessions: dict[str, BrowserSession] = {}
        if registry is None:
            registry = BackendRegistry()
            registry.register("byom", BYOMBackend())
            if settings.fly_api_token:
                registry.register("fly", FlyBackend())
        self.registry: BackendRegistry = registry
        self.playwright = None

    @property
    def provider(self) -> BackendProvider:
        return self.registry.get(settings.default_backend)

    async def start(self):
        await self.registry.start_all()
        self.playwright = await async_playwright().start()

    async def create_session(
        self,
        profile_id: Optional[str] = None,
        proxy: Optional[dict] = None,
        extensions: Optional[list[str]] = None,
        viewport: dict = None,
        user_agent: Optional[str] = None,
        timeout: int = 3600,
        timezone: Optional[str] = None,
        locale: Optional[str] = None,
        languages: Optional[list[str]] = None,
        chrome_args: Optional[list[str]] = None,
        stealth: Optional[dict] = None,
        user_id: Optional[uuid_mod.UUID] = None,
    ) -> BrowserSession:
        if self.playwright is None:
            await self.start()

        session_id = str(uuid_mod.uuid4())
        container_name = f"session-{session_id[:12]}"

        if profile_id is None:
            profile_id = session_id

        if viewport is None:
            viewport = {"width": 1920, "height": 1080}

        tenant_id = str(user_id) if user_id else None
        if tenant_id:
            canonical_profile_path = settings.profiles_path / tenant_id / profile_id
        else:
            canonical_profile_path = settings.profiles_path / profile_id
        working_dir = settings.profiles_path / ".working" / session_id
        working_dir.mkdir(parents=True, exist_ok=True)

        if canonical_profile_path.exists():
            shutil.copytree(canonical_profile_path, working_dir, dirs_exist_ok=True)
            logger.info(f"Copied profile {profile_id} to working dir for session {session_id}")

        session_token = secrets.token_urlsafe(32)
        vnc_password = secrets.token_urlsafe(8)[:8]

        environment = {
            "DISPLAY": ":99",
            "RESOLUTION": settings.resolution,
            "WINDOW_SIZE": f"{viewport['width']},{viewport['height']}",
            "PROFILE_DIR": f"{settings.profiles_dir}/.working/{session_id}",
            "SESSION_TOKEN": session_token,
            "VNC_PASSWORD": vnc_password,
        }

        if proxy and proxy.get("server"):
            environment["PROXY_SERVER"] = proxy["server"]

        if user_agent:
            environment["USER_AGENT"] = user_agent

        if timezone:
            environment["TZ"] = timezone

        if locale:
            environment["LANG_OVERRIDE"] = locale

        if chrome_args:
            environment["EXTRA_CHROME_ARGS"] = " ".join(chrome_args)

        ext_paths = []
        if extensions:
            for ext_id in extensions:
                ext_path = extension_manager.get_extension_path(ext_id)
                if ext_path is None:
                    raise ValueError(f"Extension not found: {ext_id}")
                ext_paths.append(f"/data/extensions/{ext_id}")
            environment["EXTENSION_PATHS"] = ",".join(ext_paths)

        host_profiles = settings.host_profiles_dir or str(settings.profiles_path.absolute())
        host_extensions = settings.host_extensions_dir or str(settings.extensions_path.absolute())

        volumes = {
            host_profiles: {"bind": settings.profiles_dir, "mode": "rw"},
            host_extensions: {"bind": settings.extensions_dir, "mode": "ro"},
        }

        backend_name, provider = await self._resolve_provider(user_id)

        backend_session = await provider.create_session(
            session_id=session_id,
            container_name=container_name,
            environment=environment,
            volumes=volumes,
        )

        await self._wait_for_cdp(
            backend_session.host, backend_session.cdp_port,
            tls=backend_session.tls, routing_headers=backend_session.routing_headers,
            session_token=session_token,
        )

        created_at = datetime.utcnow()
        expires_at = created_at + timedelta(seconds=timeout)

        session = BrowserSession(
            session_id=session_id,
            profile_id=profile_id,
            container_id=backend_session.backend_id,
            container_name=container_name,
            container_ip=backend_session.host,
            created_at=created_at,
            expires_at=expires_at,
            proxy=proxy,
            extensions=extensions or [],
            viewport=viewport,
            user_agent=user_agent,
            user_id=user_id,
            backend_name=backend_name,
            session_token=session_token,
            vnc_password=vnc_password,
            cdp_port=backend_session.cdp_port,
            vnc_port=backend_session.vnc_port,
            input_port=backend_session.input_port,
            tls=backend_session.tls,
            routing_headers=backend_session.routing_headers,
        )

        scheme = "https" if backend_session.tls else "http"
        port = f":{backend_session.cdp_port}" if backend_session.cdp_port not in (443, 80) else ""
        cdp_url = f"{scheme}://{backend_session.host}{port}"
        cdp_headers = {"Authorization": f"Bearer {session_token}"}
        cdp_headers.update(backend_session.routing_headers)
        max_cdp_attempts = 15 if backend_session.tls else 5
        browser = None
        for attempt in range(max_cdp_attempts):
            try:
                browser = await self.playwright.chromium.connect_over_cdp(cdp_url, headers=cdp_headers)
                break
            except Exception as e:
                logger.warning(f"CDP connection attempt {attempt + 1}/{max_cdp_attempts} failed: {e}")
                if attempt < max_cdp_attempts - 1:
                    await asyncio.sleep(2)
                else:
                    raise

        session.browser = browser

        context_options = {"viewport": viewport}
        if timezone:
            context_options["timezone_id"] = timezone
        if locale:
            context_options["locale"] = locale
        if user_agent:
            context_options["user_agent"] = user_agent

        contexts = browser.contexts
        if contexts:
            session.context = contexts[0]
        else:
            session.context = await browser.new_context(**context_options)

        if languages:
            languages_json = repr(languages)
            languages_script = f"""(() => {{
    Object.defineProperty(navigator, 'languages', {{
        get: () => {languages_json},
        configurable: true,
    }});
    Object.defineProperty(navigator, 'language', {{
        get: () => {languages_json}[0],
        configurable: true,
    }});
}})();"""
            await session.context.add_init_script(languages_script)

        if stealth and (stealth.get("webgl_vendor") or stealth.get("webgl_renderer")):
            webgl_vendor = stealth.get("webgl_vendor", "Google Inc. (NVIDIA Corporation)")
            webgl_renderer = stealth.get("webgl_renderer", "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060, OpenGL 4.5)")
            webgl_script = f"""(() => {{
    const VENDOR = {repr(webgl_vendor)};
    const RENDERER = {repr(webgl_renderer)};
    const getParameter = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(parameter) {{
        if (parameter === 37445) return VENDOR;
        if (parameter === 37446) return RENDERER;
        return getParameter.call(this, parameter);
    }};
    const getParameter2 = WebGL2RenderingContext.prototype.getParameter;
    WebGL2RenderingContext.prototype.getParameter = function(parameter) {{
        if (parameter === 37445) return VENDOR;
        if (parameter === 37446) return RENDERER;
        return getParameter2.call(this, parameter);
    }};
    const debugInfo = WebGLRenderingContext.prototype.getExtension;
    WebGLRenderingContext.prototype.getExtension = function(name) {{
        const ext = debugInfo.call(this, name);
        if (name === 'WEBGL_debug_renderer_info' && ext) {{
            return {{UNMASKED_VENDOR_WEBGL: 37445, UNMASKED_RENDERER_WEBGL: 37446}};
        }}
        return ext;
    }};
    const debugInfo2 = WebGL2RenderingContext.prototype.getExtension;
    WebGL2RenderingContext.prototype.getExtension = function(name) {{
        const ext = debugInfo2.call(this, name);
        if (name === 'WEBGL_debug_renderer_info' && ext) {{
            return {{UNMASKED_VENDOR_WEBGL: 37445, UNMASKED_RENDERER_WEBGL: 37446}};
        }}
        return ext;
    }};
}})();"""
            await session.context.add_init_script(webgl_script)

        self.sessions[session_id] = session
        logger.info(f"Session {session_id} created with container {container_name}")
        return session

    async def _resolve_provider(self, user_id: Optional[uuid_mod.UUID] = None) -> tuple[str, BackendProvider]:
        if user_id:
            async with async_session() as db:
                result = await db.execute(
                    select(TenantConfig).where(TenantConfig.user_id == user_id)
                )
                tenant_config = result.scalar_one_or_none()

            if tenant_config:
                backend_name = tenant_config.backend_provider
                fallback_names = (tenant_config.config or {}).get("fallback_chain", [])
                chain = [backend_name] + fallback_names

                provider = await self.registry.resolve_chain(chain)
                return backend_name, provider

        provider = self.registry.get(settings.default_backend)
        if not provider:
            raise RuntimeError(f"Default backend '{settings.default_backend}' not registered")
        return settings.default_backend, provider

    async def _wait_for_cdp(self, host: str, port: int = 9222, max_attempts: int = 30, tls: bool = False, routing_headers: dict[str, str] | None = None, session_token: str = ""):
        if tls:
            await self._wait_for_cdp_http(host, port, max_attempts, routing_headers=routing_headers or {}, session_token=session_token)
        else:
            await self._wait_for_cdp_tcp(host, port, max_attempts)

    async def _wait_for_cdp_tcp(self, host: str, port: int, max_attempts: int):
        for attempt in range(max_attempts):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((host, port))
                sock.close()
                if result == 0:
                    logger.info(f"CDP ready on {host}:{port}")
                    return
            except socket.error:
                pass
            await asyncio.sleep(0.5)
        raise TimeoutError(f"CDP not available on {host}:{port} after {max_attempts * 0.5}s")

    async def _wait_for_cdp_http(self, host: str, port: int, max_attempts: int, routing_headers: dict[str, str] | None = None, session_token: str = ""):
        scheme = "https" if port == 443 else "http"
        port_str = f":{port}" if port not in (443, 80) else ""
        url = f"{scheme}://{host}{port_str}/health"
        headers = {}
        headers.update(routing_headers or {})
        if session_token:
            headers["Authorization"] = f"Bearer {session_token}"
        async with httpx.AsyncClient(timeout=2) as client:
            for attempt in range(max_attempts):
                try:
                    resp = await client.get(url, headers=headers)
                    if resp.status_code == 200:
                        logger.info(f"CDP ready on {url}")
                        return
                except httpx.HTTPError:
                    pass
                await asyncio.sleep(0.5)
        raise TimeoutError(f"CDP not available at {url} after {max_attempts * 0.5}s")

    async def close_session(self, session_id: str):
        session = self.sessions.get(session_id)
        if not session:
            return

        if session.browser:
            await session.browser.close()

        provider = self.registry.get(session.backend_name) or self.provider
        await provider.terminate_session(session.container_id)

        await self.save_session_profile(session_id)

        working_dir = settings.profiles_path / ".working" / session_id
        if working_dir.exists():
            shutil.rmtree(working_dir)
            logger.info(f"Cleaned up working directory for session {session_id}")

        duration = int((datetime.utcnow() - session.created_at).total_seconds())
        await record_event(session.user_id, "session.close", session_id=session_id, duration_seconds=duration)

        del self.sessions[session_id]
        logger.info(f"Session {session_id} closed")

    async def get_session(self, session_id: str) -> Optional[BrowserSession]:
        return self.sessions.get(session_id)

    async def save_session_profile(self, session_id: str) -> bool:
        session = self.sessions.get(session_id)
        if not session:
            return False

        working_dir = settings.profiles_path / ".working" / session_id
        tenant_id = str(session.user_id) if session.user_id else None
        if tenant_id:
            canonical_path = settings.profiles_path / tenant_id / session.profile_id
        else:
            canonical_path = settings.profiles_path / session.profile_id

        if not working_dir.exists():
            return False

        canonical_path.parent.mkdir(parents=True, exist_ok=True)
        if canonical_path.exists():
            shutil.rmtree(canonical_path)

        shutil.copytree(working_dir, canonical_path, ignore=shutil.ignore_patterns('Singleton*'))
        logger.info(f"Saved session {session_id} profile to {session.profile_id}")
        return True

    async def cleanup_expired_sessions(self):
        while True:
            await asyncio.sleep(60)
            now = datetime.utcnow()
            expired = [
                sid for sid, session in self.sessions.items()
                if session.expires_at <= now
            ]
            for session_id in expired:
                logger.info(f"Session {session_id} expired, closing")
                await self.close_session(session_id)

    async def shutdown(self):
        for session_id in list(self.sessions.keys()):
            await self.close_session(session_id)
        await self.registry.shutdown_all()
        if self.playwright:
            await self.playwright.stop()


manager = BrowserManager()
