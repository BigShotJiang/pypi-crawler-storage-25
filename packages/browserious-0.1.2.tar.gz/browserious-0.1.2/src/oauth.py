import httpx
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from sqlalchemy import select

from src.audit import record_event
from src.auth import create_jwt
from src.config import settings
from src.database import async_session
from src.db_models import User

router = APIRouter(prefix="/auth", tags=["Auth"])


class CodeExchangeRequest(BaseModel):
    code: str


async def _get_or_create_user(email: str, name: str | None, provider: str, provider_id: str) -> User:
    async with async_session() as session:
        result = await session.execute(
            select(User).where(User.oauth_provider == provider, User.oauth_id == provider_id)
        )
        user = result.scalar_one_or_none()
        if user:
            return user

        result = await session.execute(select(User).where(User.email == email))
        user = result.scalar_one_or_none()
        if user:
            user.oauth_provider = provider
            user.oauth_id = provider_id
            if name and not user.name:
                user.name = name
            await session.commit()
            await session.refresh(user)
            return user

        user = User(email=email, name=name, oauth_provider=provider, oauth_id=provider_id)
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user


def _user_response(user: User, jwt_token: str) -> JSONResponse:
    return JSONResponse({"token": jwt_token, "user": {"id": str(user.id), "email": user.email, "name": user.name}})


@router.get("/config")
async def auth_config():
    return {
        "google_client_id": settings.google_client_id,
        "github_client_id": settings.github_client_id,
        "redirect_base": settings.oauth_redirect_base,
    }


@router.post("/google/exchange")
async def google_exchange(body: CodeExchangeRequest):
    redirect_uri = f"{settings.oauth_redirect_base}/auth/google/callback"
    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            "https://oauth2.googleapis.com/token",
            data={
                "grant_type": "authorization_code",
                "code": body.code,
                "client_id": settings.google_client_id,
                "client_secret": settings.google_client_secret,
                "redirect_uri": redirect_uri,
            },
        )
        token_data = token_resp.json()
        if "error" in token_data:
            return JSONResponse({"detail": token_data.get("error_description", token_data["error"])}, status_code=400)

        userinfo_resp = await client.get(
            "https://www.googleapis.com/oauth2/v3/userinfo",
            headers={"Authorization": f"Bearer {token_data['access_token']}"},
        )
        userinfo = userinfo_resp.json()

    user = await _get_or_create_user(
        email=userinfo["email"],
        name=userinfo.get("name"),
        provider="google",
        provider_id=userinfo["sub"],
    )
    jwt_token = create_jwt(user)
    await record_event(user.id, "auth.login", metadata={"provider": "google"})
    return _user_response(user, jwt_token)


@router.post("/github/exchange")
async def github_exchange(body: CodeExchangeRequest):
    redirect_uri = f"{settings.oauth_redirect_base}/auth/github/callback"
    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            "https://github.com/login/oauth/access_token",
            data={
                "client_id": settings.github_client_id,
                "client_secret": settings.github_client_secret,
                "code": body.code,
                "redirect_uri": redirect_uri,
            },
            headers={"Accept": "application/json"},
        )
        token_data = token_resp.json()
        if "error" in token_data:
            return JSONResponse({"detail": token_data.get("error_description", token_data["error"])}, status_code=400)

        access_token = token_data["access_token"]
        headers = {"Authorization": f"Bearer {access_token}", "Accept": "application/json"}

        profile_resp = await client.get("https://api.github.com/user", headers=headers)
        profile = profile_resp.json()

        github_id = str(profile["id"])
        name = profile.get("name")
        email = profile.get("email")

        if not email:
            emails_resp = await client.get("https://api.github.com/user/emails", headers=headers)
            emails = emails_resp.json()
            primary = next((e for e in emails if e.get("primary")), None)
            if primary:
                email = primary["email"]

    user = await _get_or_create_user(email=email, name=name, provider="github", provider_id=github_id)
    jwt_token = create_jwt(user)
    await record_event(user.id, "auth.login", metadata={"provider": "github"})
    return _user_response(user, jwt_token)
