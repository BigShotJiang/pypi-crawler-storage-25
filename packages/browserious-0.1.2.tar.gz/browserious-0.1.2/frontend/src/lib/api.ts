const API_BASE = import.meta.env.VITE_API_URL || "https://api.browserious.com";

function getToken(): string | null {
  return localStorage.getItem("token");
}

export function setToken(token: string) {
  localStorage.setItem("token", token);
}

export function clearToken() {
  localStorage.removeItem("token");
}

export function isAuthenticated(): boolean {
  return !!getToken();
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (!res.ok) {
    const body = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(body.detail || `HTTP ${res.status}`);
  }

  return res.json();
}

export interface TokenInfo {
  id: string;
  name: string | null;
  token_prefix: string;
  last_used_at: string | null;
  expires_at: string | null;
  created_at: string;
}

export interface TokenCreateResponse {
  id: string;
  name: string | null;
  token: string;
  created_at: string;
}

export interface UsageSummary {
  period_start: string;
  period_end: string;
  session_count: number;
  total_session_seconds: number;
  profile_count: number;
  profile_storage_bytes: number;
}

export interface TenantConfig {
  backend_provider: string;
  max_sessions: number;
  max_session_duration: number;
  max_profiles: number;
  config: Record<string, unknown> | null;
}

export interface AuthResponse {
  token: string;
  user: { id: string; email: string; name?: string };
}

export interface AuthConfig {
  google_client_id: string;
  github_client_id: string;
  redirect_base: string;
}

export function buildGoogleAuthUrl(config: AuthConfig): string {
  const params = new URLSearchParams({
    client_id: config.google_client_id,
    redirect_uri: `${config.redirect_base}/auth/google/callback`,
    response_type: "code",
    scope: "openid email profile",
    access_type: "offline",
    prompt: "consent",
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params}`;
}

export function buildGithubAuthUrl(config: AuthConfig): string {
  const params = new URLSearchParams({
    client_id: config.github_client_id,
    redirect_uri: `${config.redirect_base}/auth/github/callback`,
    scope: "user:email",
  });
  return `https://github.com/login/oauth/authorize?${params}`;
}

export const api = {
  auth: {
    config: () => request<AuthConfig>("/auth/config"),
    exchangeGoogle: (code: string) =>
      request<AuthResponse>("/auth/google/exchange", {
        method: "POST",
        body: JSON.stringify({ code }),
      }),
    exchangeGithub: (code: string) =>
      request<AuthResponse>("/auth/github/exchange", {
        method: "POST",
        body: JSON.stringify({ code }),
      }),
  },
  tokens: {
    list: () => request<{ tokens: TokenInfo[] }>("/tokens"),
    create: (name?: string) =>
      request<TokenCreateResponse>("/tokens", {
        method: "POST",
        body: JSON.stringify({ name }),
      }),
    revoke: (id: string) =>
      request<{ deleted: boolean }>(`/tokens/${id}`, { method: "DELETE" }),
  },
  usage: {
    summary: (since?: string, until?: string) => {
      const params = new URLSearchParams();
      if (since) params.set("since", since);
      if (until) params.set("until", until);
      const qs = params.toString();
      return request<UsageSummary>(`/usage/summary${qs ? `?${qs}` : ""}`);
    },
  },
  tenant: {
    config: () => request<TenantConfig>("/tenant/config"),
  },
};
