import { useEffect, useState } from "react";
import { api } from "../lib/api";
import type { UsageSummary } from "../lib/api";

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function UsageOverview() {
  const [usage, setUsage] = useState<UsageSummary | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.usage
      .summary()
      .then(setUsage)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-gray-500 text-sm">Loading usage...</p>;
  if (!usage) return null;

  const stats = [
    { label: "Sessions this month", value: usage.session_count.toString() },
    { label: "Total runtime", value: formatDuration(usage.total_session_seconds) },
    { label: "Stored profiles", value: usage.profile_count.toString() },
    { label: "Profile storage", value: formatBytes(usage.profile_storage_bytes) },
  ];

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Usage</h2>
      <div className="grid grid-cols-2 gap-4">
        {stats.map((s) => (
          <div
            key={s.label}
            className="bg-gray-50 dark:bg-gray-800 rounded p-4 border dark:border-gray-700"
          >
            <p className="text-2xl font-bold">{s.value}</p>
            <p className="text-sm text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
