import type { AuthConfig } from "../lib/api";
import { buildGoogleAuthUrl, buildGithubAuthUrl } from "../lib/api";

const API_URL = import.meta.env.VITE_API_URL || "https://api.browserious.com";

interface Props {
  authConfig: AuthConfig | null;
}

const features = [
  {
    title: "API-Controlled Browsers",
    description:
      "Spin up isolated Chromium sessions on demand. Navigate, click, fill forms, take screenshots — all via REST API or MCP.",
  },
  {
    title: "MCP Native",
    description:
      "First-class Model Context Protocol support. Connect Claude, Cursor, or any MCP client and let your AI agent browse the web.",
  },
  {
    title: "Persistent Profiles",
    description:
      "Save and restore browser state — cookies, localStorage, sessions. Pick up exactly where you left off.",
  },
  {
    title: "Live View via VNC",
    description:
      "Watch your browser sessions in real time through noVNC. Debug automation visually, no guesswork.",
  },
  {
    title: "Request Interception",
    description:
      "Block, redirect, or modify network requests. Filter ads, mock APIs, or capture traffic programmatically.",
  },
  {
    title: "Self-Hosted",
    description:
      "Run on your own infrastructure. Your data stays on your machines. No third-party browser clouds.",
  },
];

const steps = [
  {
    step: "1",
    title: "Sign in",
    description: "Authenticate with Google or GitHub. Get your API token.",
  },
  {
    step: "2",
    title: "Connect",
    description: "Add the MCP server URL to Claude Desktop, Cursor, or call the REST API directly.",
  },
  {
    step: "3",
    title: "Browse",
    description: "Create sessions, navigate pages, extract data, automate workflows.",
  },
];

export default function LandingPage({ authConfig }: Props) {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100">
      <nav className="max-w-5xl mx-auto px-4 py-6 flex items-center justify-between">
        <span className="text-xl font-bold">Browserious</span>
        <div className="flex items-center gap-4">
          <a
            href={`${API_URL}/docs`}
            className="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
          >
            API Docs
          </a>
          <a
            href="/dashboard"
            className="text-sm px-4 py-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-100"
          >
            Sign in
          </a>
        </div>
      </nav>

      <section className="max-w-5xl mx-auto px-4 pt-20 pb-24 text-center">
        <h1 className="text-5xl sm:text-6xl font-bold tracking-tight leading-tight">
          Browser-as-a-Service
          <br />
          <span className="text-gray-400">for AI Agents</span>
        </h1>
        <p className="mt-6 text-lg text-gray-500 max-w-2xl mx-auto">
          API-controlled browser sessions with MCP support.
          Let your AI navigate the web, extract data, and automate workflows
          in isolated, sandboxed environments.
        </p>
        <div className="mt-10 flex items-center justify-center gap-4">
          <a
            href="/dashboard"
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 text-sm"
          >
            Get Started
          </a>
          <a
            href={`${API_URL}/docs`}
            className="px-6 py-3 border border-gray-300 dark:border-gray-700 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-900 text-sm"
          >
            View API Docs
          </a>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 py-16 border-t dark:border-gray-800">
        <h2 className="text-2xl font-bold text-center mb-12">How it works</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((s) => (
            <div key={s.step} className="text-center">
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 font-bold text-sm mb-4">
                {s.step}
              </div>
              <h3 className="font-semibold mb-2">{s.title}</h3>
              <p className="text-sm text-gray-500">{s.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 py-16 border-t dark:border-gray-800">
        <h2 className="text-2xl font-bold text-center mb-12">Features</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div
              key={f.title}
              className="p-5 border dark:border-gray-800 rounded-lg"
            >
              <h3 className="font-semibold mb-2">{f.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                {f.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 py-16 border-t dark:border-gray-800">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">MCP Configuration</h2>
          <p className="text-gray-500 mb-8">
            Add this to your Claude Desktop or Cursor config:
          </p>
          <pre className="inline-block text-left text-sm bg-gray-50 dark:bg-gray-900 p-6 rounded-lg border dark:border-gray-700 font-mono">
{`{
  "mcpServers": {
    "browserious": {
      "type": "stdio",
      "command": "uvx",
      "args": ["browserious"],
      "env": {
        "BROWSERIOUS_API_URL": "${API_URL}",
        "BROWSERIOUS_API_KEY": "<your-api-token>"
      }
    }
  }
}`}
          </pre>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 py-20 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
        <p className="text-gray-500 mb-8">Free to use. Sign in with Google or GitHub.</p>
        <div className="flex items-center justify-center gap-4">
          <a
            href={authConfig ? buildGoogleAuthUrl(authConfig) : "#"}
            className="px-6 py-3 bg-white dark:bg-gray-800 border dark:border-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            Continue with Google
          </a>
          <a
            href={authConfig ? buildGithubAuthUrl(authConfig) : "#"}
            className="px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg text-sm font-medium hover:bg-gray-800 dark:hover:bg-gray-100"
          >
            Continue with GitHub
          </a>
        </div>
      </section>

      <footer className="border-t dark:border-gray-800 py-8 text-center text-sm text-gray-400">
        Browserious
      </footer>
    </div>
  );
}
