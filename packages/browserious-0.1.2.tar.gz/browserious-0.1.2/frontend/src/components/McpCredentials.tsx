import { useState } from "react";
import type { TokenCreateResponse } from "../lib/api";

const API_URL = import.meta.env.VITE_API_URL || "https://api.browserious.com";

type ClientType = "claude-code" | "claude-desktop" | "cursor" | "windsurf";
type InstallMethod = "uvx" | "pip";

interface ClientConfig {
  label: string;
  filePath: string;
  includeType: boolean;
}

interface Props {
  newToken?: TokenCreateResponse | null;
}

function buildSnippet(
  token: string,
  includeType: boolean,
  method: InstallMethod
): string {
  const entry: Record<string, unknown> = {
    env: {
      BROWSERIOUS_API_URL: API_URL,
      BROWSERIOUS_API_KEY: token,
    },
  };
  if (method === "uvx") {
    entry.command = "uvx";
    entry.args = ["browserious"];
  } else {
    entry.command = "browserious";
  }
  if (includeType) {
    return JSON.stringify(
      { mcpServers: { browserious: { type: "stdio", ...entry } } },
      null,
      2
    );
  }
  return JSON.stringify(
    { mcpServers: { browserious: entry } },
    null,
    2
  );
}

const clients: Record<ClientType, ClientConfig> = {
  "claude-code": {
    label: "Claude Code",
    filePath: "~/.claude.json",
    includeType: true,
  },
  "claude-desktop": {
    label: "Claude Desktop",
    filePath: "~/Library/Application Support/Claude/claude_desktop_config.json",
    includeType: false,
  },
  cursor: {
    label: "Cursor",
    filePath: ".cursor/mcp.json",
    includeType: false,
  },
  windsurf: {
    label: "Windsurf",
    filePath: "~/.codeium/windsurf/mcp_config.json",
    includeType: false,
  },
};

const clientOrder: ClientType[] = [
  "claude-code",
  "claude-desktop",
  "cursor",
  "windsurf",
];

export default function McpCredentials({ newToken }: Props) {
  const [selected, setSelected] = useState<ClientType>("claude-code");
  const [method, setMethod] = useState<InstallMethod>("uvx");
  const [copied, setCopied] = useState(false);

  const tokenValue = newToken?.token || "<your-api-token>";
  const config = clients[selected];
  const snippet = buildSnippet(tokenValue, config.includeType, method);

  function copy() {
    navigator.clipboard.writeText(snippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">
        MCP Connection
        {newToken && (
          <span className="ml-2 text-sm text-green-600 dark:text-green-400 font-normal">
            (includes your new token)
          </span>
        )}
      </h2>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mb-3">
        <div className="flex flex-wrap gap-1">
          {clientOrder.map((type) => (
            <button
              key={type}
              onClick={() => {
                setSelected(type);
                setCopied(false);
              }}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                selected === type
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
              }`}
            >
              {clients[type].label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
          <span>via</span>
          {(["uvx", "pip"] as const).map((m) => (
            <button
              key={m}
              onClick={() => {
                setMethod(m);
                setCopied(false);
              }}
              className={`px-2 py-1 rounded font-mono transition-colors ${
                method === m
                  ? "bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  : "text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      <p className="text-xs text-gray-500 dark:text-gray-400 mb-2 font-mono">
        {config.filePath}
      </p>

      <div className="relative">
        <pre className="text-xs bg-gray-50 dark:bg-gray-900 p-3 rounded border dark:border-gray-700 font-mono overflow-x-auto">
          {snippet}
        </pre>
        <button
          onClick={copy}
          className="absolute top-2 right-2 px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded text-xs hover:bg-gray-300 dark:hover:bg-gray-600"
        >
          {copied ? "Copied!" : "Copy"}
        </button>
      </div>

      {method === "pip" && (
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 font-mono">
          pip install browserious
        </p>
      )}

      {!newToken && (
        <p className="text-xs text-gray-500 mt-2">
          Create an API token above to auto-fill the config.
        </p>
      )}
    </div>
  );
}
