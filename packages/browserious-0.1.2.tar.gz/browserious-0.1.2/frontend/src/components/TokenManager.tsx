import { useEffect, useState } from "react";
import { api } from "../lib/api";
import type { TokenInfo, TokenCreateResponse } from "../lib/api";

interface Props {
  onTokenCreate?: (token: TokenCreateResponse | null) => void;
}

export default function TokenManager({ onTokenCreate }: Props) {
  const [tokens, setTokens] = useState<TokenInfo[]>([]);
  const [newToken, setNewToken] = useState<TokenCreateResponse | null>(null);
  const [tokenName, setTokenName] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadTokens() {
    setLoading(true);
    const res = await api.tokens.list();
    setTokens(res.tokens);
    setLoading(false);
  }

  useEffect(() => {
    loadTokens().catch((e) => {
      setError(e.message);
      setLoading(false);
    });
  }, []);

  async function handleCreate() {
    setError("");
    const res = await api.tokens.create(tokenName || undefined);
    setNewToken(res);
    onTokenCreate?.(res);
    setTokenName("");
    await loadTokens();
  }

  async function handleRevoke(id: string) {
    setError("");
    await api.tokens.revoke(id);
    await loadTokens();
  }

  function copyToClipboard(text: string) {
    navigator.clipboard.writeText(text);
  }

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">API Tokens</h2>

      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 p-3 rounded mb-4 text-sm">
          {error}
        </div>
      )}

      {newToken && (
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 p-4 rounded mb-4">
          <p className="text-sm font-medium text-green-800 dark:text-green-300 mb-2">
            Token created. Copy it now — it won't be shown again.
          </p>
          <div className="flex items-center gap-2">
            <code className="flex-1 text-sm bg-white dark:bg-gray-900 p-2 rounded border font-mono break-all">
              {newToken.token}
            </code>
            <button
              onClick={() => copyToClipboard(newToken.token)}
              className="px-3 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700 shrink-0"
            >
              Copy
            </button>
          </div>
          <button
            onClick={() => setNewToken(null)}
            className="mt-2 text-sm text-gray-500 hover:text-gray-700"
          >
            Dismiss
          </button>
        </div>
      )}

      <p className="text-sm text-amber-600 dark:text-amber-400 mb-4">
        Token creation is temporarily disabled.
      </p>

      <div className="flex gap-2 mb-4 opacity-50 pointer-events-none">
        <input
          type="text"
          placeholder="Token name (optional)"
          value={tokenName}
          onChange={(e) => setTokenName(e.target.value)}
          className="flex-1 px-3 py-2 border rounded bg-white dark:bg-gray-900 dark:border-gray-700 text-sm"
          disabled
        />
        <button
          disabled
          onClick={handleCreate}
          className="px-4 py-2 bg-indigo-600 text-white rounded text-sm hover:bg-indigo-700"
        >
          Create Token
        </button>
      </div>

      {loading ? (
        <p className="text-gray-500 text-sm">Loading...</p>
      ) : tokens.length === 0 ? (
        <p className="text-gray-500 text-sm">No tokens yet.</p>
      ) : (
        <div className="border dark:border-gray-700 rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800">
              <tr>
                <th className="px-4 py-2 text-left font-medium">Name</th>
                <th className="px-4 py-2 text-left font-medium">Token</th>
                <th className="px-4 py-2 text-left font-medium">Last Used</th>
                <th className="px-4 py-2 text-left font-medium">Created</th>
                <th className="px-4 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y dark:divide-gray-700">
              {tokens.map((t) => (
                <tr key={t.id}>
                  <td className="px-4 py-2">{t.name || "—"}</td>
                  <td className="px-4 py-2 font-mono text-xs">{t.token_prefix}</td>
                  <td className="px-4 py-2 text-gray-500">
                    {t.last_used_at
                      ? new Date(t.last_used_at).toLocaleDateString()
                      : "Never"}
                  </td>
                  <td className="px-4 py-2 text-gray-500">
                    {new Date(t.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-2 text-right">
                    <button
                      onClick={() => handleRevoke(t.id)}
                      className="text-red-600 hover:text-red-800 text-xs"
                    >
                      Revoke
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
