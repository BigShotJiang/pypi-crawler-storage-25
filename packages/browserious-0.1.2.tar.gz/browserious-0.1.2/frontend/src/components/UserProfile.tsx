interface Props {
  user: { id: string; email: string; name?: string } | null;
  onLogout: () => void;
}

export default function UserProfile({ user, onLogout }: Props) {
  if (!user) return null;

  return (
    <div className="flex items-center justify-between">
      <div>
        <p className="font-medium">{user.name || user.email}</p>
        {user.name && (
          <p className="text-sm text-gray-500">{user.email}</p>
        )}
      </div>
      <button
        onClick={onLogout}
        className="px-3 py-1.5 text-sm border rounded hover:bg-gray-50 dark:hover:bg-gray-800 dark:border-gray-700"
      >
        Sign out
      </button>
    </div>
  );
}
