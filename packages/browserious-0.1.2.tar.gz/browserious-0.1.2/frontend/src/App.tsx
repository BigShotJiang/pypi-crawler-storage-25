import { useEffect, useState } from "react";
import { isAuthenticated, setToken, clearToken, api, buildGoogleAuthUrl, buildGithubAuthUrl } from "./lib/api";
import type { AuthConfig, TokenCreateResponse } from "./lib/api";
import TokenManager from "./components/TokenManager";
import McpCredentials from "./components/McpCredentials";
import UsageOverview from "./components/UsageOverview";
import UserProfile from "./components/UserProfile";
import LandingPage from "./components/LandingPage";

interface User {
  id: string;
  email: string;
  name?: string;
}

function decodeJwtPayload(token: string): Record<string, unknown> | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  return JSON.parse(atob(parts[1]));
}

function getOAuthCode(): { provider: "google" | "github"; code: string } | null {
  const path = window.location.pathname;
  const params = new URLSearchParams(window.location.search);
  const code = params.get("code");
  if (!code) return null;
  if (path === "/auth/google/callback") return { provider: "google", code };
  if (path === "/auth/github/callback") return { provider: "github", code };
  return null;
}

function useRoute() {
  const [path, setPath] = useState(window.location.pathname);

  useEffect(() => {
    function onPopState() {
      setPath(window.location.pathname);
    }
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  function navigate(to: string) {
    window.history.pushState(null, "", to);
    setPath(to);
  }

  return { path, navigate };
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authed, setAuthed] = useState(isAuthenticated());
  const [authError, setAuthError] = useState("");
  const [authConfig, setAuthConfig] = useState<AuthConfig | null>(null);
  const [lastCreatedToken, setLastCreatedToken] = useState<TokenCreateResponse | null>(null);
  const { path, navigate } = useRoute();

  useEffect(() => {
    api.auth.config().then(setAuthConfig);
  }, []);

  useEffect(() => {
    const oauthCode = getOAuthCode();
    if (oauthCode) {
      const exchange = oauthCode.provider === "google" ? api.auth.exchangeGoogle : api.auth.exchangeGithub;
      exchange(oauthCode.code)
        .then((res) => {
          setToken(res.token);
          setUser(res.user);
          setAuthed(true);
          window.history.replaceState(null, "", "/dashboard");
          navigate("/dashboard");
        })
        .catch((err) => {
          setAuthError(err.message);
          window.history.replaceState(null, "", "/dashboard");
          navigate("/dashboard");
        });
      return;
    }

    if (authed) {
      const token = localStorage.getItem("token");
      if (token) {
        const payload = decodeJwtPayload(token);
        if (payload) {
          setUser({
            id: payload.sub as string,
            email: payload.email as string,
          });
        }
      }
    }
  }, [authed]);

  function handleLogout() {
    clearToken();
    setUser(null);
    setAuthed(false);
    navigate("/");
  }

  if (path.startsWith("/auth/") && path.endsWith("/callback")) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 flex items-center justify-center">
        <p className="text-gray-500">Signing in...</p>
      </div>
    );
  }

  if (path === "/dashboard") {
    if (!authed) {
      return (
        <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 flex items-center justify-center">
          <div className="text-center space-y-6 max-w-sm">
            <h1 className="text-3xl font-bold">Browserious</h1>
            <p className="text-gray-500">Sign in to manage your account</p>
            {authError && (
              <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 p-3 rounded text-sm">
                {authError}
              </div>
            )}
            <div className="space-y-3">
              <a
                href={authConfig ? buildGoogleAuthUrl(authConfig) : "#"}
                className="block w-full px-4 py-2.5 bg-white dark:bg-gray-800 border dark:border-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                Continue with Google
              </a>
              <a
                href={authConfig ? buildGithubAuthUrl(authConfig) : "#"}
                className="block w-full px-4 py-2.5 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg text-sm font-medium hover:bg-gray-800 dark:hover:bg-gray-100"
              >
                Continue with GitHub
              </a>
            </div>
            <a
              href="/"
              onClick={(e) => { e.preventDefault(); navigate("/"); }}
              className="inline-block text-sm text-gray-400 hover:text-gray-600"
            >
              Back to home
            </a>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100">
        <div className="max-w-3xl mx-auto px-4 py-8 space-y-8">
          <div className="flex items-center justify-between border-b dark:border-gray-800 pb-4">
            <a
              href="/"
              onClick={(e) => { e.preventDefault(); navigate("/"); }}
              className="text-2xl font-bold hover:text-gray-600 dark:hover:text-gray-300"
            >
              Browserious
            </a>
            <UserProfile user={user} onLogout={handleLogout} />
          </div>

          <UsageOverview />
          <TokenManager onTokenCreate={setLastCreatedToken} />
          <McpCredentials newToken={lastCreatedToken} />
        </div>
      </div>
    );
  }

  return <LandingPage authConfig={authConfig} />;
}
