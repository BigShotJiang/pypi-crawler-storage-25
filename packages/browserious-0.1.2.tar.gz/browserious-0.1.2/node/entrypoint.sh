#!/bin/bash
set -e

export XCURSOR_THEME=Adwaita
export XCURSOR_SIZE=24

Xvfb :99 -screen 0 ${RESOLUTION} &
sleep 1

xsetroot -display :99 -cursor_name left_ptr &

/usr/local/bin/node-api &

if [ -n "$VNC_PASSWORD" ]; then
    mkdir -p /tmp/vnc
    x11vnc -storepasswd "$VNC_PASSWORD" /tmp/vnc/passwd
    x11vnc -display :99 -forever -shared -rfbport 5900 -rfbauth /tmp/vnc/passwd -nocursorshape -cursor arrow &
else
    x11vnc -display :99 -forever -shared -rfbport 5900 -nopw -nocursorshape -cursor arrow &
fi

CHROMIUM_PATH=$(find /ms-playwright -name "chrome" -type f 2>/dev/null | head -1)

if [ -z "$CHROMIUM_PATH" ]; then
    echo "ERROR: Chromium not found in /ms-playwright"
    exit 1
fi

socat TCP-LISTEN:9222,fork,bind=0.0.0.0,reuseaddr TCP:127.0.0.1:9223 &

CHROME_ARGS="--no-sandbox --disable-setuid-sandbox --remote-debugging-port=9223 --remote-allow-origins=* --no-first-run --no-default-browser-check --disable-background-networking --disable-sync --disable-translate --disable-dev-shm-usage --disable-infobars --hide-crash-restore-bubble --test-type --disable-features=Translate,TranslateUI,MediaRouter"

if [ -n "$PROFILE_DIR" ]; then
    mkdir -p "$PROFILE_DIR"
    CHROME_ARGS="$CHROME_ARGS --user-data-dir=$PROFILE_DIR"
fi

if [ -n "$PROXY_SERVER" ]; then
    CHROME_ARGS="$CHROME_ARGS --proxy-server=$PROXY_SERVER"
fi

if [ -n "$EXTENSION_PATHS" ]; then
    CHROME_ARGS="$CHROME_ARGS --load-extension=$EXTENSION_PATHS"
fi

if [ -n "$USER_AGENT" ]; then
    CHROME_ARGS="$CHROME_ARGS --user-agent=\"$USER_AGENT\""
fi

if [ -n "$WINDOW_SIZE" ]; then
    CHROME_ARGS="$CHROME_ARGS --window-size=$WINDOW_SIZE"
else
    CHROME_ARGS="$CHROME_ARGS --window-size=1920,1080"
fi

if [ -n "$EXTRA_CHROME_ARGS" ]; then
    CHROME_ARGS="$CHROME_ARGS $EXTRA_CHROME_ARGS"
fi

if [ -n "$LANG_OVERRIDE" ]; then
    export LANG="$LANG_OVERRIDE"
fi

CHROME_ARGS="$CHROME_ARGS --start-maximized"

eval exec $CHROMIUM_PATH $CHROME_ARGS "$@"
