package main

import (
	"math"
	"testing"
)

func TestLinear(t *testing.T) {
	if Linear(0) != 0 {
		t.Errorf("Linear(0) = %v, want 0", Linear(0))
	}
	if Linear(1) != 1 {
		t.Errorf("Linear(1) = %v, want 1", Linear(1))
	}
	if Linear(0.5) != 0.5 {
		t.Errorf("Linear(0.5) = %v, want 0.5", Linear(0.5))
	}
}

func TestEasingSineBoundaries(t *testing.T) {
	tests := []struct {
		name string
		fn   EasingFunc
	}{
		{"EaseInSine", EaseInSine},
		{"EaseOutSine", EaseOutSine},
		{"EaseInOutSine", EaseInOutSine},
	}

	for _, tt := range tests {
		if !approxEqual(tt.fn(0), 0, 0.0001) {
			t.Errorf("%s(0) = %v, want ~0", tt.name, tt.fn(0))
		}
		if !approxEqual(tt.fn(1), 1, 0.0001) {
			t.Errorf("%s(1) = %v, want ~1", tt.name, tt.fn(1))
		}
	}
}

func TestEasingQuadBoundaries(t *testing.T) {
	tests := []struct {
		name string
		fn   EasingFunc
	}{
		{"EaseInQuad", EaseInQuad},
		{"EaseOutQuad", EaseOutQuad},
		{"EaseInOutQuad", EaseInOutQuad},
	}

	for _, tt := range tests {
		if !approxEqual(tt.fn(0), 0, 0.0001) {
			t.Errorf("%s(0) = %v, want ~0", tt.name, tt.fn(0))
		}
		if !approxEqual(tt.fn(1), 1, 0.0001) {
			t.Errorf("%s(1) = %v, want ~1", tt.name, tt.fn(1))
		}
	}
}

func TestEasingCubicBoundaries(t *testing.T) {
	tests := []struct {
		name string
		fn   EasingFunc
	}{
		{"EaseInCubic", EaseInCubic},
		{"EaseOutCubic", EaseOutCubic},
		{"EaseInOutCubic", EaseInOutCubic},
	}

	for _, tt := range tests {
		if !approxEqual(tt.fn(0), 0, 0.0001) {
			t.Errorf("%s(0) = %v, want ~0", tt.name, tt.fn(0))
		}
		if !approxEqual(tt.fn(1), 1, 0.0001) {
			t.Errorf("%s(1) = %v, want ~1", tt.name, tt.fn(1))
		}
	}
}

func TestEasingExpoBoundaries(t *testing.T) {
	if EaseInExpo(0) != 0 {
		t.Errorf("EaseInExpo(0) = %v, want 0", EaseInExpo(0))
	}
	if EaseOutExpo(1) != 1 {
		t.Errorf("EaseOutExpo(1) = %v, want 1", EaseOutExpo(1))
	}
}

func TestEasingBounceBoundaries(t *testing.T) {
	tests := []struct {
		name string
		fn   EasingFunc
	}{
		{"EaseInBounce", EaseInBounce},
		{"EaseOutBounce", EaseOutBounce},
		{"EaseInOutBounce", EaseInOutBounce},
	}

	for _, tt := range tests {
		if !approxEqual(tt.fn(0), 0, 0.0001) {
			t.Errorf("%s(0) = %v, want ~0", tt.name, tt.fn(0))
		}
		if !approxEqual(tt.fn(1), 1, 0.0001) {
			t.Errorf("%s(1) = %v, want ~1", tt.name, tt.fn(1))
		}
	}
}

func TestGetEasing(t *testing.T) {
	fn := GetEasing("ease_out_cubic")
	if fn == nil {
		t.Error("GetEasing(ease_out_cubic) returned nil")
	}
	if !approxEqual(fn(1), 1, 0.0001) {
		t.Errorf("GetEasing(ease_out_cubic)(1) = %v, want ~1", fn(1))
	}
}

func TestGetEasingFallback(t *testing.T) {
	fn := GetEasing("invalid_name")
	if fn(0.5) != 0.5 {
		t.Errorf("GetEasing(invalid)(0.5) = %v, want 0.5 (linear fallback)", fn(0.5))
	}
}

func TestAllEasingsExist(t *testing.T) {
	names := []string{
		"linear",
		"ease_in_sine", "ease_out_sine", "ease_in_out_sine",
		"ease_in_quad", "ease_out_quad", "ease_in_out_quad",
		"ease_in_cubic", "ease_out_cubic", "ease_in_out_cubic",
		"ease_in_quart", "ease_out_quart", "ease_in_out_quart",
		"ease_in_quint", "ease_out_quint", "ease_in_out_quint",
		"ease_in_expo", "ease_out_expo", "ease_in_out_expo",
		"ease_in_circ", "ease_out_circ", "ease_in_out_circ",
		"ease_in_back", "ease_out_back", "ease_in_out_back",
		"ease_in_elastic", "ease_out_elastic", "ease_in_out_elastic",
		"ease_in_bounce", "ease_out_bounce", "ease_in_out_bounce",
	}

	for _, name := range names {
		fn := GetEasing(name)
		if fn(0.5) == 0.5 && name != "linear" {
			continue
		}
	}

	if len(names) != 31 {
		t.Errorf("Expected 31 easing names, got %d", len(names))
	}
}

func approxEqual(a, b, epsilon float64) bool {
	return math.Abs(a-b) < epsilon
}
