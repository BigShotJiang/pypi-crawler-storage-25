package main

import (
	"testing"
)

func TestNewXdoController(t *testing.T) {
	xdo := NewXdoController(":99")
	if xdo == nil {
		t.Error("NewXdoController returned nil")
	}
	if xdo.display != ":99" {
		t.Errorf("display = %v, want :99", xdo.display)
	}
}

func TestXdoControllerCloseBeforeStart(t *testing.T) {
	xdo := NewXdoController(":99")
	err := xdo.Close()
	if err != nil {
		t.Errorf("Close() before Start() returned error: %v", err)
	}
}

func TestXdoControllerStartClose(t *testing.T) {
	xdo := NewXdoController(":99")

	err := xdo.Start()
	if err != nil {
		t.Skipf("xdotool not available: %v", err)
	}

	err = xdo.Close()
	if err != nil {
		t.Errorf("Close() returned error: %v", err)
	}
}

func TestXdoControllerDoubleClose(t *testing.T) {
	xdo := NewXdoController(":99")

	err := xdo.Start()
	if err != nil {
		t.Skipf("xdotool not available: %v", err)
	}

	xdo.Close()
	err = xdo.Close()
	if err != nil {
		t.Errorf("Double Close() returned error: %v", err)
	}
}

func TestXdoControllerMouseMoveWithoutStart(t *testing.T) {
	xdo := NewXdoController(":99")
	err := xdo.MouseMove(100, 100)
	if err == nil {
		t.Error("MouseMove() without Start() should return error")
	}
}

func TestXdoControllerWithDisplay(t *testing.T) {
	xdo := NewXdoController(":0")

	err := xdo.Start()
	if err != nil {
		t.Skipf("xdotool not available on :0: %v", err)
	}
	defer xdo.Close()

	err = xdo.MouseMove(100, 100)
	if err != nil {
		t.Errorf("MouseMove failed: %v", err)
	}

	err = xdo.Click(1)
	if err != nil {
		t.Errorf("Click failed: %v", err)
	}

	err = xdo.KeyDown("a")
	if err != nil {
		t.Errorf("KeyDown failed: %v", err)
	}

	err = xdo.KeyUp("a")
	if err != nil {
		t.Errorf("KeyUp failed: %v", err)
	}
}

func TestParseMousePosition(t *testing.T) {
	xdo := NewXdoController(":0")

	err := xdo.Start()
	if err != nil {
		t.Skipf("xdotool not available: %v", err)
	}
	defer xdo.Close()

	x, y, err := xdo.GetMousePosition()
	if err != nil {
		t.Skipf("GetMousePosition failed (may need display): %v", err)
	}

	if x < 0 || y < 0 {
		t.Errorf("Invalid mouse position: x=%d, y=%d", x, y)
	}
}
