package main

import (
	"math/rand"
	"time"
)

type PlaylistExecutor struct {
	xdo *XdoController
}

func NewPlaylistExecutor(xdo *XdoController) *PlaylistExecutor {
	return &PlaylistExecutor{xdo: xdo}
}

func (p *PlaylistExecutor) Execute(playlist Playlist) PlayResult {
	start := time.Now()

	for i, action := range playlist.Actions {
		var err error
		switch action.Type {
		case "move":
			err = p.executeMove(action)
		case "sleep":
			p.executeSleep(action)
		case "mouse_down":
			err = p.xdo.MouseDown(action.Button)
		case "mouse_up":
			err = p.xdo.MouseUp(action.Button)
		case "click":
			err = p.executeClick(action)
		case "key_down":
			err = p.xdo.KeyDown(action.Key)
		case "key_up":
			err = p.xdo.KeyUp(action.Key)
		case "key":
			err = p.xdo.Key(action.Key)
		case "type_text":
			err = p.executeTypeText(action)
		case "scroll":
			err = p.xdo.Scroll(action.DeltaX, action.DeltaY)
		default:
			return PlayResult{
				Status:     "error",
				Error:      "unknown action type: " + action.Type,
				Executed:   i,
				FailedAt:   i,
				DurationMs: time.Since(start).Milliseconds(),
			}
		}

		if err != nil {
			return PlayResult{
				Status:     "error",
				Error:      err.Error(),
				Executed:   i,
				FailedAt:   i,
				DurationMs: time.Since(start).Milliseconds(),
			}
		}
	}

	return PlayResult{
		Status:     "ok",
		Executed:   len(playlist.Actions),
		DurationMs: time.Since(start).Milliseconds(),
	}
}

func (p *PlaylistExecutor) executeMove(action Action) error {
	startX, startY, err := p.xdo.GetMousePosition()
	if err != nil {
		startX, startY = 0, 0
	}

	duration := time.Duration(action.DurationMs) * time.Millisecond
	if duration == 0 {
		return p.xdo.MouseMove(action.X, action.Y)
	}

	easingX := Linear
	easingY := Linear
	if action.Easing != nil {
		if action.Easing.X != "" {
			easingX = GetEasing(action.Easing.X)
		}
		if action.Easing.Y != "" {
			easingY = GetEasing(action.Easing.Y)
		}
	}

	frameInterval := 10 * time.Millisecond
	frames := int(duration / frameInterval)
	if frames < 1 {
		frames = 1
	}

	for i := 0; i <= frames; i++ {
		t := float64(i) / float64(frames)

		tx := easingX(t)
		ty := easingY(t)

		x := startX + int(float64(action.X-startX)*tx)
		y := startY + int(float64(action.Y-startY)*ty)

		if err := p.xdo.MouseMove(x, y); err != nil {
			return err
		}

		if i < frames {
			time.Sleep(frameInterval)
		}
	}

	return nil
}

func (p *PlaylistExecutor) executeSleep(action Action) {
	time.Sleep(time.Duration(action.DurationMs) * time.Millisecond)
}

func (p *PlaylistExecutor) executeClick(action Action) error {
	if action.X != 0 || action.Y != 0 {
		if err := p.xdo.MouseMove(action.X, action.Y); err != nil {
			return err
		}
	}

	count := action.Count
	if count < 1 {
		count = 1
	}

	button := action.Button
	if button == 0 {
		button = 1
	}

	for i := 0; i < count; i++ {
		if err := p.xdo.Click(button); err != nil {
			return err
		}
		if i < count-1 {
			time.Sleep(50 * time.Millisecond)
		}
	}

	return nil
}

func charToKeysym(char rune) string {
	special := map[rune]string{
		' ':  "space",
		'\t': "Tab",
		'\n': "Return",
		'!':  "exclam",
		'"':  "quotedbl",
		'#':  "numbersign",
		'$':  "dollar",
		'%':  "percent",
		'&':  "ampersand",
		'\'': "apostrophe",
		'(':  "parenleft",
		')':  "parenright",
		'*':  "asterisk",
		'+':  "plus",
		',':  "comma",
		'-':  "minus",
		'.':  "period",
		'/':  "slash",
		':':  "colon",
		';':  "semicolon",
		'<':  "less",
		'=':  "equal",
		'>':  "greater",
		'?':  "question",
		'@':  "at",
		'[':  "bracketleft",
		'\\': "backslash",
		']':  "bracketright",
		'^':  "asciicircum",
		'_':  "underscore",
		'`':  "grave",
		'{':  "braceleft",
		'|':  "bar",
		'}':  "braceright",
		'~':  "asciitilde",
	}
	if keysym, ok := special[char]; ok {
		return keysym
	}
	return string(char)
}

func (p *PlaylistExecutor) executeTypeText(action Action) error {
	minMs := 40
	maxMs := 120
	if action.Interval != nil {
		minMs = action.Interval.MinMs
		maxMs = action.Interval.MaxMs
	}

	for _, char := range action.Text {
		key := charToKeysym(char)

		if err := p.xdo.KeyDown(key); err != nil {
			return err
		}
		time.Sleep(time.Duration(10+rand.Intn(20)) * time.Millisecond)
		if err := p.xdo.KeyUp(key); err != nil {
			return err
		}

		delay := minMs + rand.Intn(maxMs-minMs+1)
		time.Sleep(time.Duration(delay) * time.Millisecond)
	}

	return nil
}

func init() {
	rand.Seed(time.Now().UnixNano())
}
