package main

type EasingConfig struct {
	X string `json:"x"`
	Y string `json:"y"`
}

type Interval struct {
	MinMs int `json:"min_ms"`
	MaxMs int `json:"max_ms"`
}

type Action struct {
	Type       string        `json:"type"`
	X          int           `json:"x,omitempty"`
	Y          int           `json:"y,omitempty"`
	DurationMs int           `json:"duration_ms,omitempty"`
	Easing     *EasingConfig `json:"easing,omitempty"`
	Button     int           `json:"button,omitempty"`
	Key        string        `json:"key,omitempty"`
	Text       string        `json:"text,omitempty"`
	Interval   *Interval     `json:"interval,omitempty"`
	DeltaX     int           `json:"delta_x,omitempty"`
	DeltaY     int           `json:"delta_y,omitempty"`
	Count      int           `json:"count,omitempty"`
}

type Playlist struct {
	Actions []Action `json:"actions"`
}

type PlayResult struct {
	Status     string `json:"status"`
	Executed   int    `json:"executed"`
	DurationMs int64  `json:"duration_ms"`
	Error      string `json:"error,omitempty"`
	FailedAt   int    `json:"failed_at,omitempty"`
}
