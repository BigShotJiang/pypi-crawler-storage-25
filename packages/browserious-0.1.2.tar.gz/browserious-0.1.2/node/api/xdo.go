package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
)

var ErrNotStarted = errors.New("xdotool not started")
var ErrRestartFailed = errors.New("xdotool restart failed")

type XdoController struct {
	cmd     *exec.Cmd
	stdin   io.WriteCloser
	display string
	mu      sync.Mutex
}

func NewXdoController(display string) *XdoController {
	return &XdoController{
		display: display,
	}
}

func (x *XdoController) Start() error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.startLocked()
}

func (x *XdoController) startLocked() error {
	x.cmd = exec.Command("xdotool", "-")
	x.cmd.Env = append(os.Environ(), fmt.Sprintf("DISPLAY=%s", x.display))

	stdin, err := x.cmd.StdinPipe()
	if err != nil {
		return err
	}
	x.stdin = stdin

	return x.cmd.Start()
}

func (x *XdoController) closeLocked() {
	if x.stdin != nil {
		x.stdin.Close()
		x.stdin = nil
	}

	if x.cmd != nil && x.cmd.Process != nil {
		x.cmd.Process.Kill()
		x.cmd.Wait()
	}
	x.cmd = nil
}

func (x *XdoController) Close() error {
	x.mu.Lock()
	defer x.mu.Unlock()
	x.closeLocked()
	return nil
}

func (x *XdoController) writeCommand(format string, args ...interface{}) error {
	if x.stdin == nil {
		return ErrNotStarted
	}

	_, err := fmt.Fprintf(x.stdin, format, args...)
	if err != nil {
		log.Printf("xdotool write failed: %v, attempting restart", err)
		x.closeLocked()
		if restartErr := x.startLocked(); restartErr != nil {
			log.Printf("xdotool restart failed: %v", restartErr)
			return ErrRestartFailed
		}
		log.Printf("xdotool restarted successfully, retrying command")
		_, err = fmt.Fprintf(x.stdin, format, args...)
	}
	return err
}

func (x *XdoController) MouseMove(px, py int) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("mousemove %d %d\n", px, py)
}

func (x *XdoController) MouseDown(button int) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("mousedown %d\n", button)
}

func (x *XdoController) MouseUp(button int) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("mouseup %d\n", button)
}

func (x *XdoController) Click(button int) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("click %d\n", button)
}

func (x *XdoController) Scroll(dx, dy int) error {
	x.mu.Lock()
	err := x.writeCommand("mousemove_relative --sync 0 0\n")
	x.mu.Unlock()
	if err != nil {
		return err
	}

	if dy > 0 {
		for i := 0; i < dy; i++ {
			if err := x.Click(4); err != nil {
				return err
			}
		}
	} else if dy < 0 {
		for i := 0; i < -dy; i++ {
			if err := x.Click(5); err != nil {
				return err
			}
		}
	}

	return nil
}

func (x *XdoController) KeyDown(key string) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("keydown %s\n", key)
}

func (x *XdoController) KeyUp(key string) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("keyup %s\n", key)
}

func (x *XdoController) Key(key string) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("key %s\n", key)
}

func (x *XdoController) Type(text string) error {
	x.mu.Lock()
	defer x.mu.Unlock()
	return x.writeCommand("type -- %q\n", text)
}

func (x *XdoController) GetMousePosition() (int, int, error) {
	cmd := exec.Command("xdotool", "getmouselocation")
	cmd.Env = append(os.Environ(), fmt.Sprintf("DISPLAY=%s", x.display))

	output, err := cmd.Output()
	if err != nil {
		return 0, 0, err
	}

	scanner := bufio.NewScanner(strings.NewReader(string(output)))
	if !scanner.Scan() {
		return 0, 0, fmt.Errorf("no output from xdotool getmouselocation")
	}

	line := scanner.Text()
	parts := strings.Fields(line)

	var px, py int
	for _, part := range parts {
		if strings.HasPrefix(part, "x:") {
			px, err = strconv.Atoi(strings.TrimPrefix(part, "x:"))
			if err != nil {
				return 0, 0, fmt.Errorf("failed to parse x coordinate: %w", err)
			}
		} else if strings.HasPrefix(part, "y:") {
			py, err = strconv.Atoi(strings.TrimPrefix(part, "y:"))
			if err != nil {
				return 0, 0, fmt.Errorf("failed to parse y coordinate: %w", err)
			}
		}
	}

	return px, py, nil
}
