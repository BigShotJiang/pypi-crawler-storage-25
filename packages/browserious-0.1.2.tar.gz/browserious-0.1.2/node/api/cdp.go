package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"strings"
	"time"
)

const chromeAddr = "127.0.0.1:9223"

func newCDPProxy() *httputil.ReverseProxy {
	target, _ := url.Parse("http://" + chromeAddr)
	proxy := httputil.NewSingleHostReverseProxy(target)
	original := proxy.Director
	proxy.Director = func(req *http.Request) {
		req.Header.Set("X-Original-Host", req.Host)
		original(req)
		req.Host = chromeAddr
	}
	proxy.FlushInterval = -1
	proxy.Transport = &http.Transport{
		DialContext: (&net.Dialer{
			Timeout: 5 * time.Second,
		}).DialContext,
		DisableKeepAlives: true,
	}
	proxy.ErrorHandler = func(w http.ResponseWriter, r *http.Request, err error) {
		log.Printf("CDP proxy error: %v (url=%s)", err, r.URL.String())
		w.WriteHeader(http.StatusBadGateway)
	}
	proxy.ModifyResponse = rewriteCDPResponse
	return proxy
}

func rewriteCDPResponse(resp *http.Response) error {
	ct := resp.Header.Get("Content-Type")
	if !strings.Contains(ct, "json") {
		return nil
	}
	origHost := resp.Request.Header.Get("X-Original-Host")
	if origHost == "" {
		return nil
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	resp.Body.Close()
	scheme := "wss"
	if strings.HasPrefix(origHost, "localhost") || strings.HasPrefix(origHost, "127.") {
		scheme = "ws"
	}
	body = bytes.ReplaceAll(body, []byte("ws://"+chromeAddr), []byte(scheme+"://"+origHost))
	resp.Body = io.NopCloser(bytes.NewReader(body))
	resp.ContentLength = int64(len(body))
	resp.Header.Set("Content-Length", fmt.Sprintf("%d", len(body)))
	resp.Header.Del("Transfer-Encoding")
	return nil
}

var cdpProxy = newCDPProxy()

func cdpJSONHandler(w http.ResponseWriter, r *http.Request) {
	cdpProxy.ServeHTTP(w, r)
}

func cdpWebSocketHandler(w http.ResponseWriter, r *http.Request) {
	hj, ok := w.(http.Hijacker)
	if !ok {
		http.Error(w, "hijacking not supported", http.StatusInternalServerError)
		return
	}

	chrome, err := net.DialTimeout("tcp", chromeAddr, 5*time.Second)
	if err != nil {
		log.Printf("CDP WebSocket dial failed: %v", err)
		http.Error(w, "chrome unavailable", http.StatusBadGateway)
		return
	}

	clientConn, clientBuf, err := hj.Hijack()
	if err != nil {
		chrome.Close()
		log.Printf("CDP WebSocket hijack failed: %v", err)
		return
	}

	r.Host = chromeAddr
	r.Header.Set("Host", chromeAddr)
	r.Write(chrome)

	go func() {
		io.Copy(chrome, clientBuf)
		chrome.Close()
	}()
	io.Copy(clientConn, chrome)
	clientConn.Close()
}
