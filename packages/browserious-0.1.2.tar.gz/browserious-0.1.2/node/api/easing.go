package main

import "math"

type EasingFunc func(float64) float64

func Linear(t float64) float64 {
	return t
}

func EaseInSine(t float64) float64 {
	return 1 - math.Cos(t*math.Pi/2)
}

func EaseOutSine(t float64) float64 {
	return math.Sin(t * math.Pi / 2)
}

func EaseInOutSine(t float64) float64 {
	return -(math.Cos(math.Pi*t) - 1) / 2
}

func EaseInQuad(t float64) float64 {
	return t * t
}

func EaseOutQuad(t float64) float64 {
	return 1 - (1-t)*(1-t)
}

func EaseInOutQuad(t float64) float64 {
	if t < 0.5 {
		return 2 * t * t
	}
	return 1 - math.Pow(-2*t+2, 2)/2
}

func EaseInCubic(t float64) float64 {
	return t * t * t
}

func EaseOutCubic(t float64) float64 {
	return 1 - math.Pow(1-t, 3)
}

func EaseInOutCubic(t float64) float64 {
	if t < 0.5 {
		return 4 * t * t * t
	}
	return 1 - math.Pow(-2*t+2, 3)/2
}

func EaseInQuart(t float64) float64 {
	return t * t * t * t
}

func EaseOutQuart(t float64) float64 {
	return 1 - math.Pow(1-t, 4)
}

func EaseInOutQuart(t float64) float64 {
	if t < 0.5 {
		return 8 * t * t * t * t
	}
	return 1 - math.Pow(-2*t+2, 4)/2
}

func EaseInQuint(t float64) float64 {
	return t * t * t * t * t
}

func EaseOutQuint(t float64) float64 {
	return 1 - math.Pow(1-t, 5)
}

func EaseInOutQuint(t float64) float64 {
	if t < 0.5 {
		return 16 * t * t * t * t * t
	}
	return 1 - math.Pow(-2*t+2, 5)/2
}

func EaseInExpo(t float64) float64 {
	if t == 0 {
		return 0
	}
	return math.Pow(2, 10*t-10)
}

func EaseOutExpo(t float64) float64 {
	if t == 1 {
		return 1
	}
	return 1 - math.Pow(2, -10*t)
}

func EaseInOutExpo(t float64) float64 {
	if t == 0 {
		return 0
	}
	if t == 1 {
		return 1
	}
	if t < 0.5 {
		return math.Pow(2, 20*t-10) / 2
	}
	return (2 - math.Pow(2, -20*t+10)) / 2
}

func EaseInCirc(t float64) float64 {
	return 1 - math.Sqrt(1-t*t)
}

func EaseOutCirc(t float64) float64 {
	return math.Sqrt(1 - math.Pow(t-1, 2))
}

func EaseInOutCirc(t float64) float64 {
	if t < 0.5 {
		return (1 - math.Sqrt(1-math.Pow(2*t, 2))) / 2
	}
	return (math.Sqrt(1-math.Pow(-2*t+2, 2)) + 1) / 2
}

func EaseInBack(t float64) float64 {
	c1 := 1.70158
	c3 := c1 + 1
	return c3*t*t*t - c1*t*t
}

func EaseOutBack(t float64) float64 {
	c1 := 1.70158
	c3 := c1 + 1
	return 1 + c3*math.Pow(t-1, 3) + c1*math.Pow(t-1, 2)
}

func EaseInOutBack(t float64) float64 {
	c1 := 1.70158
	c2 := c1 * 1.525
	if t < 0.5 {
		return (math.Pow(2*t, 2) * ((c2+1)*2*t - c2)) / 2
	}
	return (math.Pow(2*t-2, 2)*((c2+1)*(t*2-2)+c2) + 2) / 2
}

func EaseInElastic(t float64) float64 {
	if t == 0 {
		return 0
	}
	if t == 1 {
		return 1
	}
	c4 := (2 * math.Pi) / 3
	return -math.Pow(2, 10*t-10) * math.Sin((t*10-10.75)*c4)
}

func EaseOutElastic(t float64) float64 {
	if t == 0 {
		return 0
	}
	if t == 1 {
		return 1
	}
	c4 := (2 * math.Pi) / 3
	return math.Pow(2, -10*t)*math.Sin((t*10-0.75)*c4) + 1
}

func EaseInOutElastic(t float64) float64 {
	if t == 0 {
		return 0
	}
	if t == 1 {
		return 1
	}
	c5 := (2 * math.Pi) / 4.5
	if t < 0.5 {
		return -(math.Pow(2, 20*t-10) * math.Sin((20*t-11.125)*c5)) / 2
	}
	return (math.Pow(2, -20*t+10)*math.Sin((20*t-11.125)*c5))/2 + 1
}

func EaseOutBounce(t float64) float64 {
	n1 := 7.5625
	d1 := 2.75
	if t < 1/d1 {
		return n1 * t * t
	} else if t < 2/d1 {
		t -= 1.5 / d1
		return n1*t*t + 0.75
	} else if t < 2.5/d1 {
		t -= 2.25 / d1
		return n1*t*t + 0.9375
	}
	t -= 2.625 / d1
	return n1*t*t + 0.984375
}

func EaseInBounce(t float64) float64 {
	return 1 - EaseOutBounce(1-t)
}

func EaseInOutBounce(t float64) float64 {
	if t < 0.5 {
		return (1 - EaseOutBounce(1-2*t)) / 2
	}
	return (1 + EaseOutBounce(2*t-1)) / 2
}

func GetEasing(name string) EasingFunc {
	easings := map[string]EasingFunc{
		"linear":             Linear,
		"ease_in_sine":       EaseInSine,
		"ease_out_sine":      EaseOutSine,
		"ease_in_out_sine":   EaseInOutSine,
		"ease_in_quad":       EaseInQuad,
		"ease_out_quad":      EaseOutQuad,
		"ease_in_out_quad":   EaseInOutQuad,
		"ease_in_cubic":      EaseInCubic,
		"ease_out_cubic":     EaseOutCubic,
		"ease_in_out_cubic":  EaseInOutCubic,
		"ease_in_quart":      EaseInQuart,
		"ease_out_quart":     EaseOutQuart,
		"ease_in_out_quart":  EaseInOutQuart,
		"ease_in_quint":      EaseInQuint,
		"ease_out_quint":     EaseOutQuint,
		"ease_in_out_quint":  EaseInOutQuint,
		"ease_in_expo":       EaseInExpo,
		"ease_out_expo":      EaseOutExpo,
		"ease_in_out_expo":   EaseInOutExpo,
		"ease_in_circ":       EaseInCirc,
		"ease_out_circ":      EaseOutCirc,
		"ease_in_out_circ":   EaseInOutCirc,
		"ease_in_back":       EaseInBack,
		"ease_out_back":      EaseOutBack,
		"ease_in_out_back":   EaseInOutBack,
		"ease_in_elastic":    EaseInElastic,
		"ease_out_elastic":   EaseOutElastic,
		"ease_in_out_elastic": EaseInOutElastic,
		"ease_in_bounce":     EaseInBounce,
		"ease_out_bounce":    EaseOutBounce,
		"ease_in_out_bounce": EaseInOutBounce,
	}

	if fn, ok := easings[name]; ok {
		return fn
	}
	return Linear
}
