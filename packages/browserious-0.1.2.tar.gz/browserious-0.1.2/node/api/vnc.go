package main

import (
	"io"
	"log"
	"net"
	"net/http"

	"golang.org/x/net/websocket"
)

func vncHandler(w http.ResponseWriter, r *http.Request) {
	websocket.Handler(handleVNC).ServeHTTP(w, r)
}

func handleVNC(ws *websocket.Conn) {
	ws.PayloadType = websocket.BinaryFrame

	vnc, err := net.Dial("tcp", "localhost:5900")
	if err != nil {
		log.Printf("VNC connection failed: %v", err)
		return
	}

	go func() {
		io.Copy(vnc, ws)
		vnc.Close()
	}()
	io.Copy(ws, vnc)
}
