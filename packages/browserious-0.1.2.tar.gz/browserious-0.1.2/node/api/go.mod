module browserious-node

go 1.25.0

require golang.org/x/net v0.52.0
