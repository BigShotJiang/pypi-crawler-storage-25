package main

import (
	"testing"
)

type mockXdoController struct {
	moves      []struct{ x, y int }
	clicks     []int
	keys       []string
	scrolls    []struct{ dx, dy int }
	shouldFail bool
}

func (m *mockXdoController) Start() error                     { return nil }
func (m *mockXdoController) Close() error                     { return nil }
func (m *mockXdoController) GetMousePosition() (int, int, error) { return 0, 0, nil }

func (m *mockXdoController) MouseMove(x, y int) error {
	m.moves = append(m.moves, struct{ x, y int }{x, y})
	return nil
}

func (m *mockXdoController) MouseDown(button int) error {
	return nil
}

func (m *mockXdoController) MouseUp(button int) error {
	return nil
}

func (m *mockXdoController) Click(button int) error {
	m.clicks = append(m.clicks, button)
	return nil
}

func (m *mockXdoController) KeyDown(key string) error {
	m.keys = append(m.keys, "down:"+key)
	return nil
}

func (m *mockXdoController) KeyUp(key string) error {
	m.keys = append(m.keys, "up:"+key)
	return nil
}

func (m *mockXdoController) Key(key string) error {
	m.keys = append(m.keys, key)
	return nil
}

func (m *mockXdoController) Type(text string) error {
	return nil
}

func (m *mockXdoController) Scroll(dx, dy int) error {
	m.scrolls = append(m.scrolls, struct{ dx, dy int }{dx, dy})
	return nil
}

func TestPlaylistExecutorEmptyPlaylist(t *testing.T) {
	mock := &mockXdoController{}
	xdo := NewXdoController(":99")
	xdo.cmd = nil

	executor := NewPlaylistExecutor(xdo)
	result := executor.Execute(Playlist{Actions: []Action{}})

	if result.Status != "ok" {
		t.Errorf("Status = %v, want ok", result.Status)
	}
	if result.Executed != 0 {
		t.Errorf("Executed = %v, want 0", result.Executed)
	}
	_ = mock
}

func TestPlaylistExecutorUnknownAction(t *testing.T) {
	xdo := NewXdoController(":99")
	executor := NewPlaylistExecutor(xdo)

	result := executor.Execute(Playlist{
		Actions: []Action{
			{Type: "unknown_action"},
		},
	})

	if result.Status != "error" {
		t.Errorf("Status = %v, want error", result.Status)
	}
	if result.Error == "" {
		t.Error("Error message should not be empty")
	}
}

func TestPlaylistExecutorSleep(t *testing.T) {
	xdo := NewXdoController(":99")
	executor := NewPlaylistExecutor(xdo)

	result := executor.Execute(Playlist{
		Actions: []Action{
			{Type: "sleep", DurationMs: 10},
		},
	})

	if result.Status != "ok" {
		t.Errorf("Status = %v, want ok", result.Status)
	}
	if result.Executed != 1 {
		t.Errorf("Executed = %v, want 1", result.Executed)
	}
	if result.DurationMs < 10 {
		t.Errorf("DurationMs = %v, want >= 10", result.DurationMs)
	}
}

func TestPlayResultFields(t *testing.T) {
	result := PlayResult{
		Status:     "ok",
		Executed:   5,
		DurationMs: 100,
	}

	if result.Error != "" {
		t.Error("Error should be empty for ok status")
	}
	if result.FailedAt != 0 {
		t.Error("FailedAt should be 0 for ok status")
	}
}

func TestPlayResultErrorFields(t *testing.T) {
	result := PlayResult{
		Status:     "error",
		Executed:   3,
		DurationMs: 50,
		Error:      "test error",
		FailedAt:   3,
	}

	if result.Error == "" {
		t.Error("Error should not be empty for error status")
	}
}

func TestActionStructFields(t *testing.T) {
	action := Action{
		Type:       "move",
		X:          100,
		Y:          200,
		DurationMs: 500,
		Easing:     &EasingConfig{X: "ease_out", Y: "linear"},
		Button:     1,
		Key:        "a",
		Text:       "hello",
		Interval:   &Interval{MinMs: 40, MaxMs: 120},
		DeltaX:     0,
		DeltaY:     5,
		Count:      2,
	}

	if action.Type != "move" {
		t.Errorf("Type = %v, want move", action.Type)
	}
	if action.Easing.X != "ease_out" {
		t.Errorf("Easing.X = %v, want ease_out", action.Easing.X)
	}
}

func TestEasingConfigDefaults(t *testing.T) {
	config := EasingConfig{}
	if config.X != "" {
		t.Errorf("Default X = %v, want empty", config.X)
	}
	if config.Y != "" {
		t.Errorf("Default Y = %v, want empty", config.Y)
	}
}

func TestIntervalConfig(t *testing.T) {
	interval := Interval{MinMs: 50, MaxMs: 150}
	if interval.MinMs != 50 {
		t.Errorf("MinMs = %v, want 50", interval.MinMs)
	}
	if interval.MaxMs != 150 {
		t.Errorf("MaxMs = %v, want 150", interval.MaxMs)
	}
}
