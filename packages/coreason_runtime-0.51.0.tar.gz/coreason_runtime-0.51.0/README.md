# 🧠 coreason-runtime

[![PyPI - Version](https://img.shields.io/pypi/v/coreason_runtime.svg)](https://pypi.org/project/coreason_runtime)
[![CI](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/ci.yml)
[![Documentation](https://img.shields.io/badge/docs-GitHub_Pages-blue.svg)](https://coreason-ai.github.io/coreason-runtime/)
[![Deploy Docs](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/docs.yml/badge.svg)](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/docs.yml)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/coreason_runtime.svg)](https://pypi.org/project/coreason_runtime)
[![Downloads](https://img.shields.io/pypi/dm/coreason_runtime.svg)](https://pypi.org/project/coreason_runtime/)
[![License: Prosperity 3.0](https://img.shields.io/badge/License-Prosperity_3.0-blue.svg)](https://prosperitylicense.com/versions/3.0.0)
[![SOTA: 2026](https://img.shields.io/badge/Architecture-Kinetic_Engine-purple.svg)](https://coreason.ai)
<br>
[![OpenSSF Scorecard](https://img.shields.io/ossf-scorecard/github.com/CoReason-AI/=OpenSSF)](https://scorecard.dev/viewer/?uri=github.com/CoReason-AI/coreason-runtime)
[![Code Coverage](https://img.shields.io/codecov/c/github/CoReason-AI/coreason-runtime/main.svg)](https://codecov.io/gh/CoReason-AI/coreason-runtime)
[![Checked with mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)
[![Code style: ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)
[![Security: Bandit](https://img.shields.io/badge/security-bandit-yellow.svg)](https://github.com/PyCQA/bandit)
<br>
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![Forks](https://img.shields.io/github/forks/CoReason-AI/coreason-runtime.svg)](https://github.com/CoReason-AI/coreason-runtime/network/members)
[![Powered By: AI](https://img.shields.io/badge/Powered%20By-CoReason%20AI-FF4500.svg)](https://coreason.ai)
[![OSV-Scanner](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-runtime/osv-scanner.yml?branch=main&label=OSV-Scanner)](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/osv-scanner.yml)
[![Trivy](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-runtime/trivy.yml?branch=main&label=Trivy)](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/trivy.yml)
[![TruffleHog](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-runtime/trufflehog.yml?branch=main&label=TruffleHog)](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/trufflehog.yml)
[![OWASP ZAP](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-runtime/dast.yml?branch=main&label=OWASP%20ZAP)](https://github.com/CoReason-AI/coreason-runtime/actions/workflows/dast.yml)

**The official zero-trust, high-throughput kinetic execution engine for the `coreason-manifest` ontology.**

`coreason-runtime` is a State-of-the-Art (SOTA) 2026 cybernetic execution engine. It abandons legacy, fragile "chain-of-thought" LLM scripting in favor of deterministic **Active Inference**, Topological Data Analysis (TDA), and strictly bounded Markov Decision Processes. It is the definitive implementation of the CoReason Tripartite Doctrine for Tier-1 Kinetic Execution.

If `coreason-manifest` is the DNA of your multi-agent topologies, `coreason-runtime` is the biological cell that safely executes them.

---

## 🚀 The Paradigm Shift

Modern enterprise AI cannot rely on unbounded `while True` loops and raw Python `exec()`. The `coreason-runtime` enforces mathematical rigor at every boundary:

* **Deterministic Orchestration:** Built on **Temporal**, Cognitive Topology executions are durably serialized. If a GPU dies or a network request fails, the topology pauses, rehydrates, and resumes exactly where it left off. No amnesia. No ghost processes.
* **Zero-Trust WASM Sandboxing:** Kinetic actions (Tools) are executed inside isolated WebAssembly environments via **Extism**. Agents can execute complex IO without ever touching your host's root kernel or filesystem.
* **Epistemic Vector Ledger:** Native, zero-copy integration with **LanceDB**. The runtime automatically projects the agent's latent state into an embedded vector memory layer.
* **Embedded Medallion Analytics:** No need for heavy Spark clusters. Raw telemetry (SSE) is ingested via **dlt** and transformed into Silver/Gold analytical intelligence matrices using Rust-backed **Polars** directly inside the daemon.
* **Human-in-the-Loop (HITL) Webhooks:** When an agent calculates high Variational Free Energy (epistemic uncertainty), it durably suspends its thread and emits an Oracle Request, waiting safely for a human expert to inject resolving priors via API.
* **Bipartite Proposer-Verifier Protocol:** The runtime is physically isolated from local OS capability generation. To fabricate assets, the runtime strictly proposes topological models over air-gapped MCP boundaries to the remote Universal Asset Forge (`coreason-meta-engineering`).

---

## ⚡ Installation

We utilize `uv` for ultra-fast, deterministic resolution. Ensure you are running Python 3.14+.

```bash
uv add coreason-runtime
```

*Note: For bare-metal enterprise deployment with SGLang GPU passthrough, refer to our [Docker Deployment Guide](docs/DEPLOYMENT.md).*

------

## 🛠️ Quickstart

The runtime is designed to be operated via its CLI or mounted as an API edge.

### 1\. Run a Local Cognitive Topology

To execute a mathematically verified agentic topology, simply pass the JSON/YAML manifest to the runtime:

```bash
coreason run ./my_topology_manifest.json
```

### 2\. Boot the API Edge & Telemetry Broker

To boot the runtime as a continuous daemon (exposing the CRDT State Sync, Schema Projection, and Server-Sent Events telemetry):

```bash
coreason serve --port 8000
```

Your frontend IDE can now connect to `http://localhost:8000/api/v1/telemetry/stream` to visualize the active inference loops in real-time.

-----

## 🏗️ Architecture

The runtime operates across five isolated computational boundaries under the CoReason Tripartite Doctrine:

1.  **The Orchestrator:** Temporal Python SDK running deterministic AST-scanned workflows.
2.  **The Cognitive Engine:** SGLang routing for sub-millisecond constrained tensor inference.
3.  **The Kinetic Sandbox:** Extism executing `.wasm` tools with zero-trust lattices.
4.  **The Epistemic Store:** LanceDB & Polars managing long-term vectors and ETL metrics.
5.  **The Universal Asset Forge:** A decoupled MCP channel connecting strictly to the `coreason-meta-engineering` Fabrication Lines to physically synthesize assets via the Bipartite generation pipeline.

For a deep dive into the cybernetic loop, read the [Architecture Documentation](docs/architecture.md).

-----

## 📜 License

This software is proprietary and dual-licensed under the **Prosperity Public License 3.0**.
Commercial use beyond a 30-day trial requires a separate commercial license. See the `LICENSE` file for details.

Copyright (c) 2026 CoReason, Inc.
