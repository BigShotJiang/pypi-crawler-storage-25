# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical tests for SpeculativeExecutionWorkflow.

Tests the speculative branch-forking, barge-in interrupt, and rollback
signal pathways using Temporal time-skipping environments.

All tests use physically instantiated manifest ontology models — zero unittest.mock.

NOTE: The SpeculativeExecutionWorkflow uses `asyncio.wait` with `asyncio.create_task`
which exercises the Temporal task selector. On Windows, the `asyncio.wait` selector
may flake due to proactor event loop differences. Tests that exercise the `asyncio.wait`
path are gated with `@pytest.mark.skipif(sys.platform == "win32", ...)`.
"""

import asyncio
import concurrent.futures
import sys
from datetime import timedelta
from typing import Any

import httpx
import pytest
from fastapi import FastAPI
from temporalio import workflow
from temporalio.testing import WorkflowEnvironment

pytestmark = pytest.mark.filterwarnings("ignore:Module loguru.* was imported after initial workflow load:UserWarning")
from temporalio.worker import Worker

with workflow.unsafe.imports_passed_through():
    # Defeat Temporal sandbox UserWarning by statically mapping loguru internals natively
    from coreason_manifest import (
        DAGTopologyManifest,
        ExecutionEnvelopeState,
        StateVectorProfile,
        TraceContextState,
    )

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.orchestration.workflows.speculative_execution_workflow import SpeculativeExecutionWorkflow

# ── Physical Substrate Setup ─────────────────────────────────────────

app = FastAPI()


@app.post("/mcp/{server_cid}/tools/call")
async def mock_gateway_call(server_cid: str, payload: dict[str, Any]) -> "Any":
    """Physical FastAPI endpoint for MasterGateway bridge testing."""
    return {"success": True, "outputs": {"result": "shadow_result"}, "intent_hash": "stub-hash", "usage": {}}


@app.get("/profiles")
async def mock_gateway_profiles() -> dict[str, list[str]]:
    return {"profiles": ["system_node", "urn:coreason:oracle:gateway"]}


# ── Stub DAG Child Workflow ──────────────────────────────────────────


@workflow.defn(name="CognitiveTopologyExecutionWorkflow", sandboxed=False)
class StubDAGWorkflow:
    """Stub DAG workflow that returns immediately with success."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        return {"status": "success", "results": [{"outputs": {"stub": True}}]}


@workflow.defn(name="CognitiveTopologyExecutionWorkflow", sandboxed=False)
class StubDAGWorkflowSlow:
    """Stub DAG workflow that waits 60 seconds (to be interrupted)."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        # Sleep long enough to be interrupted by barge-in or rollback signals
        await workflow.sleep(timedelta(seconds=60))
        return {"status": "success", "results": []}


# ── Envelope Factory ─────────────────────────────────────────────────


def _build_speculative_envelope(
    commit_probability: float = 0.9,
    speculative_cid: str = "branch-alpha",
    rollback_pointers: list[str] | None = None,
    threshold_target: float | None = None,
) -> dict[str, Any]:
    """Build a minimal ExecutionEnvelopeState for the speculative workflow."""
    dag_manifest = DAGTopologyManifest(
        topology_class="dag",
        max_depth=10,
        max_fan_out=5,
        nodes={
            "did:coreason:node01": {  # type: ignore[dict-item]
                "topology_class": "agent",
                "description": "test description",
            },
        },
        edges=[],
    )

    envelope = ExecutionEnvelopeState(
        payload=dag_manifest.model_dump(mode="json"),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        trace_context=TraceContextState(
            trace_cid="01ARZ3NDEKTSV4RRFFQ69G5FAV",
            span_cid="01ARZ3NDEKTSV4RRFFQ69G5FAX",
            causal_clock=0,
        ),
    )

    # The speculative workflow reads from payload.payload for its policy
    dump = envelope.model_dump(mode="json")
    policy = {
        "speculative_cid": speculative_cid,
        "commit_probability": commit_probability,
        "rollback_pointers": rollback_pointers or [],
    }
    if threshold_target is not None:
        policy["threshold_target"] = threshold_target
    dump["payload"]["payload"] = policy

    return dump


# ── Tests ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_speculative_high_commit_merges(neo4j_container: "Any") -> None:
    """High commit_probability (>= 0.8) merges the shadow branch, committed=True."""
    payload = _build_speculative_envelope(commit_probability=0.9)

    # Physical Activities with injected ASGITransport
    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-merge-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-merge-test",
                task_queue="spec-merge-queue",
            )

    assert result["status"] == "success"
    assert result["committed"] is True
    assert result["result"]["status"] == "success"


@pytest.mark.asyncio
async def test_speculative_low_commit_stays_isolated(neo4j_container: "Any") -> None:
    """Low commit_probability (< 0.8) keeps the branch in shadow isolation."""
    payload = _build_speculative_envelope(commit_probability=0.2)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-isolate-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-isolate-test",
                task_queue="spec-isolate-queue",
            )

    assert result["status"] == "success"
    assert result["committed"] is False


@pytest.mark.asyncio
async def test_speculative_custom_threshold_merges(neo4j_container: "Any") -> None:
    """A speculative branch merges when commit_probability >= custom threshold_target, using neo4j."""
    payload = _build_speculative_envelope(commit_probability=0.5, threshold_target=0.4)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-custom-merge-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-custom-merge-test",
                task_queue="spec-custom-merge-queue",
            )

    assert result["status"] == "success"
    assert result["committed"] is True
    assert result["result"]["status"] == "success"


@pytest.mark.asyncio
async def test_speculative_custom_threshold_stays_isolated(neo4j_container: "Any") -> None:
    """A speculative branch remains isolated when commit_probability < custom threshold_target, using neo4j."""
    payload = _build_speculative_envelope(commit_probability=0.5, threshold_target=0.6)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-custom-isolate-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-custom-isolate-test",
                task_queue="spec-custom-isolate-queue",
            )

    assert result["status"] == "success"
    assert result["committed"] is False


@pytest.mark.asyncio
async def test_speculative_barge_in_halts_execution(neo4j_container: "Any") -> None:
    """Barge-in signal halts the speculative branch mid-execution."""
    payload = _build_speculative_envelope(commit_probability=0.9)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-barge-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflowSlow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            handle = await env.client.start_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-barge-test",
                task_queue="spec-barge-queue",
            )

            # Give the workflow time to start the child
            await asyncio.sleep(0.5)

            # Send barge-in signal
            await handle.signal(
                SpeculativeExecutionWorkflow.receive_barge_in,
                {"target_event_cid": "evt-123", "reason": "user_abort"},
            )

            result = await handle.result()
            await asyncio.sleep(0.5)

    assert result["status"] == "barge_in_halted"
    assert result["event"]["reason"] == "user_abort"


@pytest.mark.asyncio
async def test_speculative_rollback_falsifies_branch(neo4j_container: "Any") -> None:
    """Rollback intent signal falsifies the speculative branch and restores rewind anchors."""
    payload = _build_speculative_envelope(
        commit_probability=0.9,
        speculative_cid="branch-beta",
        rollback_pointers=["checkpoint-1", "checkpoint-2"],
    )

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-rollback-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflowSlow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            handle = await env.client.start_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-rollback-test",
                task_queue="spec-rollback-queue",
            )

            await asyncio.sleep(0.5)

            # Send rollback intent
            await handle.signal(
                SpeculativeExecutionWorkflow.receive_rollback_intent,
                {"cascade_cid": "cascade-1", "reason": "formal_verification_failed"},
            )

            result = await handle.result()
            await asyncio.sleep(0.5)

    assert result["status"] == "rolled_back"
    assert result["falsified_subgraph"] == "branch-beta"
    assert result["rewind_anchors"] == ["checkpoint-1", "checkpoint-2"]
    assert result["rollback_intent"]["reason"] == "formal_verification_failed"


@pytest.mark.asyncio
async def test_speculative_child_workflow_id_format(neo4j_container: "Any") -> None:
    """Child workflow ID follows the shadow naming convention."""
    payload = _build_speculative_envelope(speculative_cid="test-cid-123")

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-id-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-id-test",
                task_queue="spec-id-queue",
            )

    # The workflow completes successfully — child ID format is
    # f"{workflow_id}-shadow-{speculative_cid}" validated by Temporal
    assert result["status"] == "success"


@pytest.mark.asyncio
async def test_speculative_workflow_cancellation(neo4j_container: "Any") -> None:
    """Test standard asyncio.CancelledError paths."""
    payload = _build_speculative_envelope(speculative_cid="test-cancel-cid")

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-can-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflowSlow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            handle = await env.client.start_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-can-test",
                task_queue="spec-can-queue",
            )
            await asyncio.sleep(0.5)
            await handle.cancel()
            from temporalio.client import WorkflowFailureError

            with pytest.raises(WorkflowFailureError) as exc_info:
                await handle.result()
            assert hasattr(exc_info.value, "cause")
            assert "CancelledError" in str(type(exc_info.value.cause))
            await asyncio.sleep(0.5)


@pytest.mark.asyncio
async def test_speculative_multiple_concurrent_forks(neo4j_container: "Any") -> None:
    """Execute multiple speculative parallel forks concurrently across identical branch configurations and verify success."""
    payload1 = _build_speculative_envelope(speculative_cid="shared-branch-cid")
    payload2 = _build_speculative_envelope(speculative_cid="shared-branch-cid")

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-multi-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.execute_gateway_cognitive_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            # Run concurrently
            result1, result2 = await asyncio.gather(
                env.client.execute_workflow(
                    SpeculativeExecutionWorkflow.run,
                    payload1,
                    id="spec-multi-test-1",
                    task_queue="spec-multi-queue",
                ),
                env.client.execute_workflow(
                    SpeculativeExecutionWorkflow.run,
                    payload2,
                    id="spec-multi-test-2",
                    task_queue="spec-multi-queue",
                ),
            )

    assert result1["status"] == "success"
    assert result2["status"] == "success"
