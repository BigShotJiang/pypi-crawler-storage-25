# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for Hollow Plane Bridging workflow."""

from typing import Any

import coreason_manifest.spec.ontology as o
import pytest
from pydantic import BaseModel, ConfigDict
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker


class MockHollowPlaneBridge(BaseModel):
    target_plane: str
    model_config = ConfigDict(extra="ignore")


class MockObserverPhysics(BaseModel):
    spatial_offset: float
    model_config = ConfigDict(extra="ignore")


class MockNDimensionalTensorManifest(BaseModel):
    merkle_root: str
    shape: list[int]
    structural_format: str
    model_config = ConfigDict(extra="ignore")


# Backwards mock injecting to prevent import failures directly
o.HollowPlaneBridge = MockHollowPlaneBridge  # type: ignore
o.ObserverPhysics = MockObserverPhysics  # type: ignore
o.NDimensionalTensorManifest = MockNDimensionalTensorManifest  # type: ignore

from temporalio import activity

from coreason_runtime.orchestration.workflows.hollow_plane_bridge_workflow import (
    HollowPlaneBridgeWorkflow,
    cross_dimensional_state_projector_activity,
    verify_tensor_boundary_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@pytest.mark.asyncio
@pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
async def test_hollow_plane_bridge_workflow_success() -> None:
    """Test mathematically constrained bridging projection."""
    payload: dict[str, Any] = {
        "bridge_request": {"target_plane": "ros2_bridge"},
        "observer": {"spatial_offset": 5.0},
        "tensor": {
            "shape": (256, 256, 3),
            "structural_format": "float32",
            "merkle_root": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            "storage_uri": "mock://data",
            "vram_footprint_bytes": 1024,
        },
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="hollow-plane-queue",
            workflows=[HollowPlaneBridgeWorkflow],
            activities=[stub_emit_span, verify_tensor_boundary_activity, cross_dimensional_state_projector_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(  # type: ignore
                HollowPlaneBridgeWorkflow.run,
                payload,
                id="test-hpb-1",
                task_queue="hollow-plane-queue",
            )
            assert result["transported"] is True


@pytest.mark.asyncio
async def test_hollow_plane_bridge_failures() -> None:
    """Test rigorous schema conformance enforcement."""
    payload_bad: dict[str, Any] = {
        "bridge_request": {},  # Missing required target_plane string and fails on strict model_validate
        "observer": {"spatial_offset": 5.0},
        "tensor": {},
    }
    with pytest.raises(ManifestConformanceError) as exc_info:
        await verify_tensor_boundary_activity(payload_bad)  # type: ignore
    assert "Hollow Plane Boundary Violation" in str(exc_info.value)

    # Test strictness on next level execution without true bool verification
    with pytest.raises(ManifestConformanceError):
        await cross_dimensional_state_projector_activity({})
