# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import concurrent.futures

import pyarrow as pa

from coreason_runtime.execution_plane.actuators.active_inference_tool import (
    run_active_inference_tool as run_active_inference,
)


def test_identity_manager_arrow_multi_threaded_gil_bypass() -> None:
    """Execute a multi-threaded benchmark loop passing massive Arrow data blocks across execution boundaries.

    Asserts that the thread processing pools achieve zero execution friction, confirming the runtime
    completely bypasses the Python GIL limits.
    """
    generative_model = {
        "name": "gil_bypass_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }

    # Generate a massive Arrow table to simulate heavy payload data stream
    rows = 100
    data = [pa.array([i % 2 for i in range(rows)])]
    table = pa.Table.from_arrays(data, names=["modality_0"])

    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    ipc_bytes = sink.getvalue().to_pybytes()

    # Define job runner
    def worker_job():
        result = run_active_inference(generative_model, observation_history=ipc_bytes)
        return result["status"] == "success"

    # Multi-threaded thread pool execution simulating high concurrent throughput
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(worker_job) for _ in range(10)]
        results = [fut.result() for fut in futures]

    assert all(results) is True
