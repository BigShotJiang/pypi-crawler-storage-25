# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from pathlib import Path

import polars as pl
import pytest

from coreason_runtime.execution_plane.actuators.active_inference_tool import (
    run_active_inference_tool as run_active_inference,
)


def test_active_inference_default() -> None:
    result = run_active_inference({"test": "data"})
    assert result["status"] == "success"
    assert result["generative_model_referenced"] == "unnamed_generative_model"
    assert "expected_information_gain" in result
    assert "precision" in result


def test_active_inference_list_single_modality() -> None:
    # 1 modality, 2 states, 2 observations
    generative_model = {
        "name": "single_modality_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }
    history = [0, 1, 0]
    result = run_active_inference(generative_model, observation_history=history)
    assert result["status"] == "success"
    assert result["generative_model_referenced"] == "single_modality_model"


def test_active_inference_list_multi_modality() -> None:
    # 2 modalities, 1 hidden state factor
    generative_model = {
        "name": "multi_modality_model",
        "A": [
            [[0.9, 0.1], [0.1, 0.9]],  # modality 0
            [[0.8, 0.2], [0.2, 0.8]],  # modality 1
        ],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0], [1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }
    history = [[0, 1], [1, 0], [0, 0]]
    result = run_active_inference(generative_model, observation_history=history)
    assert result["status"] == "success"
    assert result["generative_model_referenced"] == "multi_modality_model"


def test_active_inference_dict_input() -> None:
    generative_model = {
        "name": "dict_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }
    history_dict = {"modality_0": [0, 1, 0]}
    result = run_active_inference(generative_model, observation_history=history_dict)
    assert result["status"] == "success"


def test_active_inference_parquet_input(tmp_path: Path) -> None:
    generative_model = {
        "name": "parquet_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }
    df = pl.DataFrame({"modality_0": [0, 1, 0]})
    file_path = tmp_path / "test_obs.parquet"
    df.write_parquet(file_path)

    result = run_active_inference(generative_model, observation_history=str(file_path))
    assert result["status"] == "success"


def test_active_inference_validation_errors() -> None:
    generative_model = {
        "name": "validation_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }

    # Invalid type
    with pytest.raises(TypeError, match="Unsupported type for observation_history"):
        run_active_inference(generative_model, observation_history=123)

    # Modality count mismatch
    with pytest.raises(ValueError, match="has length 2, but model has 1 modalities"):
        run_active_inference(generative_model, observation_history=[[0, 1]])

    # Invalid element type
    with pytest.raises(ValueError, match="must be a list of modality values"):
        run_active_inference(generative_model, observation_history=[{"invalid": "type"}])


def test_active_inference_path_traversal_protection(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    generative_model = {
        "name": "path_traversal_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }

    # 1. Enforced via environment variable
    scratch_dir = tmp_path / "scratch_zone"
    scratch_dir.mkdir()
    monkeypatch.setenv("COREASON_TELEMETRY_SCRATCH_DIR", str(scratch_dir))

    safe_file = scratch_dir / "safe.parquet"
    df = pl.DataFrame({"modality_0": [0]})
    df.write_parquet(safe_file)

    # Safe path runs fine
    result = run_active_inference(generative_model, observation_history=str(safe_file))
    assert result["status"] == "success"

    # Out of bounds path raises ValueError
    unsafe_file = tmp_path / "unsafe.parquet"
    df.write_parquet(unsafe_file)
    with pytest.raises(ValueError, match="Path traversal security violation"):
        run_active_inference(generative_model, observation_history=str(unsafe_file))

    # 2. Enforced with unset environment variable (should fail on general path outside temp/cwd scratch)
    monkeypatch.delenv("COREASON_TELEMETRY_SCRATCH_DIR", raising=False)
    # A path completely outside CWD and temp dir should fail
    # We can mock/check a path like "C:/Windows/System32/drivers/etc/hosts" or similar root path
    # Actually, using a path under a custom root directory is clean and works across platforms
    with pytest.raises(ValueError, match="Path traversal security violation"):
        run_active_inference(
            generative_model,
            observation_history="C:/unauthorized_directory/file.parquet"
            if Path("C:/").exists()
            else "/unauthorized_directory/file.parquet",
        )


def test_active_inference_tool_path_traversal_enforcement(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Explicitly verify that the active inference tool enforces path traversal containment checks."""
    test_active_inference_path_traversal_protection(tmp_path, monkeypatch)


def test_active_inference_bytes_input() -> None:
    generative_model = {
        "name": "bytes_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }
    df = pl.DataFrame({"modality_0": [0, 1, 0]})
    import pyarrow as pa

    table = df.to_arrow()
    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    ipc_bytes = sink.getvalue().to_pybytes()

    result = run_active_inference(generative_model, observation_history=ipc_bytes)
    assert result["status"] == "success"


def test_active_inference_directory_traversal_breakout() -> None:
    """Inject a relative directory traversal string (../../etc/passwd) as observation_history."""
    generative_model = {
        "name": "traversal_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }
    with pytest.raises(ValueError, match="Path traversal security violation"):
        run_active_inference(generative_model, observation_history="../../etc/passwd")


def test_active_inference_arrow_ipc_stream() -> None:
    """Stream an in-memory serialized pyarrow.RecordBatch using an authorized IPC byte layout."""
    import pyarrow as pa

    generative_model = {
        "name": "arrow_ipc_model",
        "A": [[[0.9, 0.1], [0.1, 0.9]]],
        "B": [[[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]]],
        "C": [[1.0, -1.0]],
        "D": [[0.5, 0.5]],
    }
    data = [pa.array([0, 1, 0])]
    table = pa.Table.from_arrays(data, names=["modality_0"])

    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    ipc_bytes = sink.getvalue().to_pybytes()

    result = run_active_inference(generative_model, observation_history=ipc_bytes)
    assert result["status"] == "success"
