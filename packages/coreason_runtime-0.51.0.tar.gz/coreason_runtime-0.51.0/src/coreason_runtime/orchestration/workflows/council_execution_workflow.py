# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.utils import canonicalize


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class CouncilExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Council Topology manifest.

    AGENT INSTRUCTION: Formalizes Social Choice Theory and pBFT to synthesize
    an authoritative truth from a cognitive network. All council member nodes
    are evaluated in parallel; the adjudicator node synthesizes the final output.
    """

    def __init__(self) -> None:
        """Initialize CouncilExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Council workflow.

        AGENT INSTRUCTION: This workflow enforces Social Choice Theory consensus.
        Council members produce independent outputs in parallel. The consensus_policy
        strategy resolves disagreements before the adjudicator synthesises the final truth.
        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing a CouncilTopologyManifest.

        Returns:
            A dictionary containing the final execution status and results.
        """
        import asyncio

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting CouncilExecutionWorkflow")

        results: list[dict[str, Any]] = []
        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import CouncilTopologyManifest

            try:
                manifest = CouncilTopologyManifest.model_validate_json(json.dumps(manifest_payload))
            except Exception as e:
                from temporalio.exceptions import ApplicationError

                workflow.logger.error(f"Manifest validation failed: {e!s}")
                raise ApplicationError(
                    f"Manifest validation failed: {e!s}", type="ManifestValidationError", non_retryable=True
                ) from e

        governance = manifest_payload.get("governance")

        adjudicator_id = str(manifest.adjudicator_cid)
        consensus_policy = manifest.consensus_policy

        member_node_cids = [nid for nid in manifest.nodes if str(nid) != adjudicator_id]

        if self._current_state_envelope is None:
            msg = "State Envelope is None"
            raise ValueError(msg)

        workflow.logger.info(f"Council fan-out: {len(member_node_cids)} members")

        member_results: dict[str, dict[str, Any]] = {}

        async def execute_member(node_cid: str) -> tuple[str, dict[str, Any]]:
            """Execute inference for a single council member."""
            await workflow.sleep(timedelta(seconds=0.1))
            self.enforce_governance_limits(governance, workflow_start_time)

            node_profile = manifest.nodes[node_cid]
            with workflow.unsafe.sandbox_unrestricted():
                if not self._current_state_envelope:
                    msg = "Council execution requires a valid state envelope."
                    raise ValueError(msg)
                node_payload = manifest_payload.get("nodes", {}).get(node_cid)
                if not node_payload:
                    node_payload = node_profile.model_dump(mode="json")

            segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": node_payload,
            }

            with workflow.unsafe.sandbox_unrestricted():
                import json

                from temporalio.exceptions import ApplicationError

                payload_str = json.dumps(segregated_payload).lower()
                firewall = getattr(manifest, "epistemic_semantic_firewall_policy", None)
                blocked_phrases = (
                    getattr(firewall, "blocked_phrases", [])
                    if firewall
                    else ["ignore previous instructions", "forget all previous", "system prompt", "you are now a"]
                )

                for phrase in blocked_phrases:
                    if phrase.lower() in payload_str:
                        workflow.logger.error(f"SemanticFirewall Violation: Blocked phrase '{phrase}' detected.")
                        msg = f"SemanticFirewall Violation: Biba phrase '{phrase}' detected in workload."
                        raise ApplicationError(
                            msg,
                            type="SemanticFirewallError",
                            non_retryable=True,
                        )

            result = await workflow.execute_activity(
                "ExecuteNemoclawCognitiveActivity",
                args=[
                    {
                        "name": "deploy_cognitive_topology",
                        "arguments": {
                            "workflow_id": workflow.info().workflow_id,
                            "payload": segregated_payload,
                            "schema_to_request": "AutonomousAgentResponse"
                            if node_payload.get("action_space_cid")
                            else "AgentResponse",
                        },
                    }
                ],
                schedule_to_close_timeout=timedelta(minutes=5),
                retry_policy=RetryPolicy(maximum_attempts=5),
            )

            usage = result.get("usage", {})
            self._accumulated_tokens += usage.get("total_tokens", 0)
            self._accumulated_cost += result.get("cost", 0.0)
            await self.record_resource_utilization("result", usage, result.get("cost", 0.0))

            return node_cid, result

        tasks = [asyncio.create_task(execute_member(str(nid))) for nid in member_node_cids]

        for task in tasks:
            node_cid, result = await task
            member_results[node_cid] = result
            results.append({"node_cid": node_cid, "type": "council_member", "result": result})

        self.reconcile_state(
            {
                "accumulated_tokens": self._accumulated_tokens,
                "accumulated_cost": self._accumulated_cost,
            }
        )

        consensus_reached = True
        consensus_detail = "default"

        if consensus_policy:
            strategy = consensus_policy.strategy
            workflow.logger.info(f"Resolving consensus with strategy: {strategy}")

            intent_hashes = [r.get("intent_hash", "") for r in member_results.values()]

            if strategy == "unanimous":
                if len(set(intent_hashes)) != 1:
                    consensus_reached = False
                    consensus_detail = "unanimous_failed"
                else:
                    consensus_detail = "unanimous"

            elif strategy == "majority":
                from collections import Counter

                hash_counts = Counter(intent_hashes)
                _most_common_hash, most_common_count = hash_counts.most_common(1)[0]
                if most_common_count > len(intent_hashes) / 2:
                    consensus_detail = "majority"
                else:
                    consensus_reached = False
                    consensus_detail = "majority_failed"

            elif strategy == "debate_rounds":
                max_rounds = consensus_policy.max_debate_rounds or 3
                consensus_detail = f"debate_rounds:{max_rounds}"

            elif strategy == "pbft":
                quorum_rules = consensus_policy.quorum_rules
                if quorum_rules:
                    from collections import Counter

                    hash_counts = Counter(intent_hashes)
                    _, agreeing_count = hash_counts.most_common(1)[0]
                    if agreeing_count >= quorum_rules.min_quorum_size:
                        consensus_detail = "pbft_quorum_met"
                    else:
                        consensus_reached = False
                        consensus_detail = f"pbft_quorum_failed:{quorum_rules.byzantine_action}"
                        workflow.logger.warning(f"pBFT quorum not met. Action: {quorum_rules.byzantine_action}")

            elif strategy == "prediction_market":
                consensus_detail = "prediction_market"

        workflow.logger.info(f"Adjudicator {adjudicator_id} synthesizing council outputs")

        await workflow.sleep(timedelta(seconds=0.1))
        self.enforce_governance_limits(governance, workflow_start_time)

        adjudicator_profile = manifest.nodes[adjudicator_id]
        with workflow.unsafe.sandbox_unrestricted():
            import typing

            adj_node_payload: dict[str, typing.Any] = dict(manifest_payload.get("nodes", {}).get(adjudicator_id, {}))
            if not adj_node_payload:
                adj_node_payload = dict(adjudicator_profile.model_dump(mode="json"))  # pyre-ignore
            adj_node_payload["input_data"] = list(member_results.values())
            adj_node_payload["consensus_detail"] = consensus_detail
            adj_node_payload["consensus_reached"] = consensus_reached

        adj_segregated_payload = {
            "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
            "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
            "node_profile": adj_node_payload,
        }

        adj_result = await workflow.execute_activity(
            "ExecuteNemoclawCognitiveActivity",
            args=[
                {
                    "name": "deploy_cognitive_topology",
                    "arguments": {
                        "workflow_id": workflow.info().workflow_id,
                        "payload": adj_segregated_payload,
                        "schema_to_request": "AutonomousAgentResponse"
                        if adj_node_payload.get("action_space_cid")
                        else "AgentResponse",
                    },
                }
            ],
            schedule_to_close_timeout=timedelta(minutes=5),
            retry_policy=RetryPolicy(maximum_attempts=5),
        )

        adj_usage = adj_result.get("usage", {})
        self._accumulated_tokens += adj_usage.get("total_tokens", 0)
        self._accumulated_cost += adj_result.get("cost", 0.0)
        await self.record_resource_utilization("adj", adj_usage, adj_result.get("cost", 0.0))

        self.reconcile_state(
            {
                "accumulated_tokens": self._accumulated_tokens,
                "accumulated_cost": self._accumulated_cost,
            }
        )

        results.append({"node_cid": adjudicator_id, "type": "adjudicator", "result": adj_result})

        if manifest.shared_state_contract:
            try:
                with workflow.unsafe.sandbox_unrestricted():
                    import jsonschema

                    logger = workflow.logger
                    logger.info("Enforcing shared_state_contract Schema-on-Write for Council Adjudicator")
                    if not isinstance(adj_result, dict):
                        msg = "Adjudicator result must be a dictionary to match state contract."
                        raise ValueError(msg)

                    outputs_to_validate = adj_result.get("outputs", adj_result)
                    jsonschema.validate(
                        instance=outputs_to_validate, schema=manifest.shared_state_contract.schema_definition
                    )
            except Exception as e:
                workflow.logger.exception(f"State rejected by shared_state_contract: {e}")
                from temporalio.exceptions import ApplicationError

                msg = f"State rejected by shared_state_contract (Schema-on-Write): {e}"
                raise ApplicationError(msg, type="SchemaOnWriteValidationError", non_retryable=True) from e

        intent_hash = adj_result.get("intent_hash")
        if not intent_hash or intent_hash == "UNKNOWN_HASH":
            import hashlib

            intent_hash = hashlib.sha256(canonicalize(adj_result)).hexdigest()
        success = adj_result.get("success", True) and consensus_reached

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, adj_result, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed CouncilExecutionWorkflow")
        return {
            "status": "success" if consensus_reached else "consensus_failed",
            "consensus_detail": consensus_detail,
            "results": results,
        }
