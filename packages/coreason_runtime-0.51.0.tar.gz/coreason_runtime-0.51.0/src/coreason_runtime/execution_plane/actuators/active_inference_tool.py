# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import typing

from mcp.server.fastmcp import FastMCP

app = FastMCP("active-inference-tool")


@app.tool()
def run_active_inference_tool(
    generative_model: dict[str, typing.Any],
    observation_history: list[typing.Any] | dict[str, typing.Any] | str | None = None,
) -> dict[str, typing.Any]:
    """Execute active inference to minimize variational free energy.

    Args:
        generative_model: The Pydantic-mapped generative model dictionary.
        observation_history: Optional history of observations sourced straight from telemetry.
                             Can be a list, dictionary (Polars-compatible), or a Parquet/IPC file path.

    Returns:
        A dictionary containing the expected information gain and precision-weighted policy.
    """
    try:
        import numpy as np
        from pymdp.agent import Agent
    except ImportError as err:
        msg = "pymdp and numpy are required for active inference operations but are not installed."
        raise ImportError(msg) from err

    model_name = generative_model.get("name", "unnamed_generative_model")

    # Extract or create default matrices
    a_matrix = generative_model.get("A")
    b_matrix = generative_model.get("B")
    c_matrix = generative_model.get("C")
    d_matrix = generative_model.get("D")

    # Standardize input into lists of numpy arrays (pymdp obj_array format)
    if a_matrix is None:
        a_matrix = [np.array([[0.9, 0.1], [0.1, 0.9]])]
    else:
        a_matrix = (
            [np.array(a) for a in a_matrix]
            if isinstance(a_matrix, list) and isinstance(a_matrix[0], list) and isinstance(a_matrix[0][0], list)
            else [np.array(a_matrix)]
        )

    if b_matrix is None:
        b_matrix = [np.array([[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]])]
    else:
        b_matrix = (
            [np.array(b) for b in b_matrix]
            if isinstance(b_matrix, list)
            and isinstance(b_matrix[0], list)
            and isinstance(b_matrix[0][0], list)
            and isinstance(b_matrix[0][0][0], list)
            else [np.array(b_matrix)]
        )

    if c_matrix is None:
        c_matrix = [np.array([1.0, -1.0])]
    else:
        c_matrix = (
            [np.array(c) for c in c_matrix]
            if isinstance(c_matrix, list) and isinstance(c_matrix[0], list)
            else [np.array(c_matrix)]
        )

    if d_matrix is None:
        d_matrix = [np.array([0.5, 0.5])]
    else:
        d_matrix = (
            [np.array(d) for d in d_matrix]
            if isinstance(d_matrix, list) and isinstance(d_matrix[0], list)
            else [np.array(d_matrix)]
        )

    # Initialize pymdp Agent
    agent = Agent(A=a_matrix, B=b_matrix, C=c_matrix, D=d_matrix)

    # Normalize observation history to list of lists (modalities per timestep)
    obs_list = []
    if observation_history is not None:
        if isinstance(observation_history, bytes):
            try:
                import polars as pl
                import pyarrow as pa

                with pa.BufferReader(observation_history) as reader, pa.ipc.open_stream(reader) as stream:
                    arrow_table = stream.read_all()

                df = pl.from_arrow(arrow_table)
                if len(df.columns) > 1:
                    raw_steps = [list(row) for row in df.iter_rows()]
                else:
                    col_name = df.columns[0]
                    raw_steps = [[val] for val in df[col_name].to_list()]
            except Exception as e:
                msg = f"Zero-GIL In-Memory Ingestion Fault: Failed to unpack Arrow IPC byte stream: {e!s}"
                raise ValueError(msg) from e
        elif isinstance(observation_history, str):
            import os
            import tempfile

            import polars as pl

            def get_canonical_path(path: str) -> str:
                return os.path.normcase(os.path.realpath(os.path.abspath(path)))

            # Enforce strict path containment rules before letting Polars parse strings
            scratch_env = os.environ.get("COREASON_TELEMETRY_SCRATCH_DIR")
            allowed_bases = [scratch_env] if scratch_env else ["./scratch", tempfile.gettempdir()]

            if os.path.isabs(observation_history):
                target_path = os.path.abspath(observation_history)
            else:
                target_path = os.path.abspath(os.path.join(allowed_bases[0], observation_history))

            canonical_target = get_canonical_path(target_path)

            is_contained = False
            for base in allowed_bases:
                canonical_base = get_canonical_path(base)
                base_prefix = canonical_base if canonical_base.endswith(os.path.sep) else canonical_base + os.path.sep
                if canonical_target.startswith(base_prefix) or canonical_target == canonical_base:
                    is_contained = True
                    break

            if not is_contained:
                raise ValueError(
                    f"Epistemic Quarantine Violation: Path traversal security violation: Path breakout detected for path {observation_history}"
                )

            try:
                if observation_history.endswith(".parquet"):
                    df = pl.read_parquet(target_path)
                elif observation_history.endswith((".ipc", ".arrow", ".feather")):
                    df = pl.read_ipc(target_path)
                elif observation_history.endswith(".csv"):
                    df = pl.read_csv(target_path)
                else:
                    msg = f"Unsupported file format for observation history: {observation_history}"
                    raise ValueError(msg)

                if len(df.columns) > 1:
                    raw_steps = [list(row) for row in df.iter_rows()]
                else:
                    col_name = df.columns[0]
                    raw_steps = [[val] for val in df[col_name].to_list()]
            except Exception as e:
                msg = f"Failed to load observation history from file: {e!s}"
                raise ValueError(msg) from e
        elif isinstance(observation_history, dict):
            try:
                import polars as pl

                df = pl.DataFrame(observation_history)
                if len(df.columns) > 1:
                    raw_steps = [list(row) for row in df.iter_rows()]
                else:
                    col_name = df.columns[0]
                    raw_steps = [[val] for val in df[col_name].to_list()]
            except Exception as e:
                msg = f"Failed to load observation history from dictionary: {e!s}"
                raise ValueError(msg) from e
        elif isinstance(observation_history, list):
            if not observation_history:
                raw_steps = []
            elif isinstance(observation_history[0], list):
                raw_steps = observation_history
            else:
                for item in observation_history:
                    if isinstance(item, (dict, set, tuple)) and not isinstance(item, list):
                        msg = f"Observation must be a list of modality values, got {type(item)}"
                        raise ValueError(msg)
                raw_steps = [[val] for val in observation_history]
        else:
            msg = f"Unsupported type for observation_history: {type(observation_history)}"
            raise TypeError(msg)

        # Batch raw_steps (list of modalities for each timestep) to PyMDP format (batch_size = 1)
        for idx, step in enumerate(raw_steps):
            if not isinstance(step, list):
                msg = f"Observation at index {idx} must be a list of modality values, got {type(step)}"
                raise ValueError(msg)
            if len(step) != len(a_matrix):
                msg = f"Observation at index {idx} has length {len(step)}, but model has {len(a_matrix)} modalities"
                raise ValueError(msg)

            formatted_step = []
            for val in step:
                if isinstance(val, list):
                    formatted_step.append(val)
                else:
                    formatted_step.append([val])
            obs_list.append(formatted_step)

    # Fallback to dummy observation if history is empty or not provided
    if not obs_list:
        dummy_obs = [[0] for _ in range(len(a_matrix))]
        obs_list = [dummy_obs]

    # Run sequential active inference
    empirical_prior = agent.D
    all_efe = []
    qs = None
    for obs in obs_list:
        qs = agent.infer_states(obs, empirical_prior=empirical_prior)
        q_pi, efe = agent.infer_policies(qs)
        all_efe.append(efe)
        action = agent.sample_action(q_pi)
        empirical_prior = agent.update_empirical_prior(action, qs)

    # Calculate expected information gain using the optimal policy metric (lowest EFE, i.e. highest q_pi)
    if all_efe:
        q_pi_flat = np.asarray(q_pi).flatten()
        efe_flat = np.asarray(all_efe[-1]).flatten()
        best_policy_idx = np.argmax(q_pi_flat)
        expected_information_gain = float(-efe_flat[best_policy_idx])
    else:
        expected_information_gain = 0.0
    precision = float(np.mean(agent.alpha)) if hasattr(agent, "alpha") else 1.0

    return {
        "status": "success",
        "action": "minimize_variational_free_energy",
        "generative_model_referenced": model_name,
        "expected_information_gain": expected_information_gain,
        "precision": precision,
    }


if __name__ == "__main__":
    app.run()
