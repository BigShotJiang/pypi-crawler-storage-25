"""Tests for MinIO CLI authorization adapter."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from phlo.cli.authorization import CliPrincipalResolver
from phlo_minio.authorization import (
    COMMAND_ACTION_MAP,
    COMMAND_RESOURCE_MAP,
    MUTATION_COMMANDS,
    READ_COMMANDS,
    SURFACE_NAME,
    FRAMEWORK_TYPE,
    MinioCliSurfaceAdapter,
)


class TestMinioCliPrincipalResolver:
    """Tests for the shared CLI principal resolver."""

    def test_resolve_service_account(self) -> None:
        """Should resolve PHLO_SERVICE_ACCOUNT as service principal."""
        with patch.dict("os.environ", {"PHLO_SERVICE_ACCOUNT": "ci-pipeline"}):
            principal = CliPrincipalResolver.resolve()
            assert principal.subject == "ci-pipeline"
            assert principal.principal_type == "service"
            assert "operators" in principal.groups

    def test_resolve_human_principal(self) -> None:
        """Should resolve PHLO_AUTH_SUBJECT as human principal."""
        with patch.dict(
            "os.environ",
            {
                "PHLO_AUTH_SUBJECT": "alice",
                "PHLO_AUTH_TYPE": "user",
                "PHLO_AUTH_GROUPS": "operators,admins",
            },
        ):
            principal = CliPrincipalResolver.resolve()
            assert principal.subject == "alice"
            assert principal.principal_type == "user"
            assert principal.groups == ("operators", "admins")

    def test_resolve_dev_fallback(self) -> None:
        """Should use dev fallback when PHLO_DEV_MODE set."""
        with patch.dict("os.environ", {"PHLO_DEV_MODE": "true"}):
            principal = CliPrincipalResolver.resolve()
            assert principal.subject == "local:root"
            assert principal.groups == ("admin",)

    def test_resolve_anonymous_default(self) -> None:
        """Should return anonymous principal when no auth env vars."""
        principal = CliPrincipalResolver.resolve()
        assert principal.subject == "anonymous"
        assert principal.principal_type == "user"
        assert principal.groups == ()


class TestMinioCliSurfaceAdapter:
    """Tests for MinIO CLI surface adapter."""

    def test_singleton_instance(self) -> None:
        """Should return singleton instance."""
        adapter1 = MinioCliSurfaceAdapter.get_instance()
        adapter2 = MinioCliSurfaceAdapter.get_instance()
        assert adapter1 is adapter2

    def test_surface_name(self) -> None:
        """Should return correct surface name."""
        adapter = MinioCliSurfaceAdapter()
        assert adapter.surface_name == SURFACE_NAME

    def test_framework_type(self) -> None:
        """Should return correct framework type."""
        adapter = MinioCliSurfaceAdapter()
        assert adapter.framework_type == FRAMEWORK_TYPE

    def test_list_operations(self) -> None:
        """Should declare mutation operations."""
        adapter = MinioCliSurfaceAdapter()
        operations = adapter.list_operations()
        assert len(operations) == len(MUTATION_COMMANDS)
        for op in operations:
            assert op["action"] in COMMAND_ACTION_MAP.values()
            assert op["resource_type"] in COMMAND_RESOURCE_MAP.values()

    def test_is_active(self) -> None:
        """Should always return True."""
        adapter = MinioCliSurfaceAdapter()
        assert adapter.is_active(None) is True

    def test_read_commands_return_allow(self) -> None:
        """Read commands should return allow without enforcement."""
        adapter = MinioCliSurfaceAdapter()
        for cmd in READ_COMMANDS:
            result = adapter.check_command_authorization(cmd)
            assert result.allowed is True

    def test_unknown_commands_return_deny(self) -> None:
        """Unknown commands should return deny."""
        adapter = MinioCliSurfaceAdapter()
        result = adapter.check_command_authorization("minio.unknown")
        assert result.allowed is False
        assert result.reason_code == "unknown_command"

    def test_mutation_commands_call_enforce(self) -> None:
        """Mutation commands should call enforce."""
        adapter = MinioCliSurfaceAdapter()

        mock_result = MagicMock()
        mock_result.variant = "allow"

        with patch("phlo_minio.authorization.enforce", return_value=mock_result):
            with patch.object(adapter, "_resolver"):
                from phlo.capabilities.interfaces import AuthPrincipal

                adapter._resolver.resolve = MagicMock(
                    return_value=AuthPrincipal(
                        subject="test",
                        principal_type="user",
                        issuer="test",
                        groups=(),
                        attributes={},
                    )
                )

                result = adapter.check_command_authorization("minio")

                if result.variant == "deny":
                    pass


class TestCommandClassification:
    """Tests for command classification."""

    def test_minio_shell_is_mutation(self) -> None:
        """minio (raw mc passthrough) should be classified as mutation."""
        assert "minio" in MUTATION_COMMANDS

    def test_minio_ls_is_read(self) -> None:
        """minio ls should be classified as read."""
        assert "minio.ls" in READ_COMMANDS

    def test_minio_admin_info_is_read(self) -> None:
        """minio admin info should be classified as read."""
        assert "minio.admin.info" in READ_COMMANDS

    def test_resource_mapping(self) -> None:
        """Commands should map to correct resources."""
        assert COMMAND_RESOURCE_MAP["minio"] == "storage"
        assert COMMAND_RESOURCE_MAP["minio.ls"] == "storage"
        assert COMMAND_RESOURCE_MAP["minio.admin.info"] == "storage"

    def test_action_mapping(self) -> None:
        """Commands should map to correct actions."""
        assert COMMAND_ACTION_MAP["minio"] == "storage.manage"
        assert COMMAND_ACTION_MAP["minio.ls"] == "storage.read"
        assert COMMAND_ACTION_MAP["minio.admin.info"] == "storage.read"
