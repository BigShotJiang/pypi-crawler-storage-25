---
name: glab-mr-refresh
description: >
  Rebase open merge requests on their target branch and restart pipelines.
  Use when the user says /glab-mr-refresh, /mr-refresh, 'rebase mes MR',
  'refresh mes MR', 'mets mes MR a jour', 'rebase toutes les MR',
  or needs to update stale MRs.
argument-hint: "[--author USERNAME] [--all] [--iid IID] to filter MRs"
allowed-tools:
  - Read
  - Edit
  - Glob
  - Grep
  - Bash
  - Skill
  - AskUserQuestion
---

Rebase open merge requests on their target branch and restart their pipelines.

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Mode detection

Detect the execution context using `detect_context`:
```bash
CTX=$(pysae-ai-tools internal detect-context)
IS_CI=$(echo "$CTX" | jq -r '.is_ci')
MR_IID=$(echo "$CTX" | jq -r '.mr_iid // empty')
PROJECT_PATH=$(echo "$CTX" | jq -r '.project_path // empty')
```

In CI mode (`IS_CI` is `true`):
- **Never use `AskUserQuestion`** — resolve conflicts automatically without asking
- Use `MR_IID` to target the current MR if no `--iid` flag is given

## Step 1 : List open MRs

Use the bundled script to list MRs:
```bash
RESULT=$(pysae-ai-tools glab mr-refresh [--author USERNAME | --all])
```

### Filtering
- **Default** (`--me`): only MRs authored by the current user
- `--author <username>`: MRs by a specific author
- `--all`: all open MRs on the project
- `--iid <IID>`: single MR by IID (skip listing, go directly to Step 2)

Parse `$ARGUMENTS` to determine which flag to pass. If `$ARGUMENTS` contains `--all`, pass `--all`. If it contains `--author <name>`, pass `--author <name>`. Otherwise, use the default (current user).

Display the list to the user:
```
MRs ouvertes (auteur: <username>) :
- !42 feat/add-export (→ main) — "Add CSV export"
- !38 fix/login-bug (→ main) — "Fix login redirect" ⚠️ conflits
```

If there are no MRs, inform the user and stop.

## Step 2 : Rebase each MR

For each MR, in order:

### 2.1 — Checkout and fetch
```bash
git fetch origin
git checkout <source_branch>
git pull origin <source_branch>
```

### 2.2 — Rebase on target branch
```bash
git rebase origin/<target_branch>
```

### 2.3 — Handle conflicts

**If rebase succeeds** → go to Step 2.5

**If rebase has conflicts**, resolve them and track how many commits produce conflicts:
1. Read each conflicting file
2. Resolve the conflict (keep the intent of both sides)
3. `git add <file>`
4. `git rebase --continue`
5. If the next commit also has conflicts, increment the conflict commit counter
6. **If 3 or more commits have produced conflicts** → the branch has diverged too much for a clean rebase. Abort and fallback to merge:
   ```bash
   git rebase --abort
   git merge origin/<target_branch> --no-edit
   ```
   If the merge also has conflicts, resolve them. If there are more than 10 conflicting files, abort and report:
   ```bash
   git merge --abort
   ```
   > ⚠️ MR !<IID> : trop de conflits pour un rebase ou merge automatique. Intervention manuelle requise.
7. Otherwise, continue resolving until the rebase completes

### 2.4 — Verify after rebase/merge
Run a quick sanity check if a test command is available (from CLAUDE.md):
- Python: `pytest --co -q` (collect only, no execution — verifies imports)
- Node: `npx tsc --noEmit` (type check only)

If the check fails, the rebase introduced a regression. Report it to the user and do not push.

### 2.5 — Push
```bash
git push --force-with-lease origin <source_branch>
```

`--force-with-lease` is required after rebase (history was rewritten). It is safe because it refuses to push if the remote has commits we don't know about.

### 2.6 — Restart pipeline
Invoke the `/ci-run` skill with the `start` job (or the first manual job) on the MR pipeline. If no pipeline exists after push, GitLab will create one automatically — wait a few seconds then check.

If the first job in the pipeline is manual, play it.

### 2.7 — Report progress
After each MR, print:
```
✓ !42 feat/add-export — rebase OK, pipeline relancee
✓ !38 fix/login-bug — merge (conflits resolus), pipeline relancee
✗ !35 refactor/auth — trop de conflits, intervention manuelle requise
```

## Step 3 : Summary

Print a final summary:
```
Refresh termine :
- 2/3 MRs rebasees et pipelines relancees
- 1 MR avec conflits non resolus (!35)
```

## Gotchas

- **`--force-with-lease`** — toujours utiliser `--force-with-lease` et jamais `--force` apres un rebase. C'est une protection contre l'ecrasement de commits pushes par d'autres entre-temps.
- **MR en draft** — les traiter comme les autres, elles ont aussi besoin d'etre a jour.
- **Branches protegees** — si le push est refuse (branche protegee), reporter l'erreur sans retry.
- **Pipeline deja en cours** — si une pipeline tourne deja apres le push, ne pas en relancer une nouvelle.
- **Stacked MRs** — si une MR cible une branche qui est elle-meme une source d'une autre MR (stacking), traiter d'abord la MR la plus proche de main, puis remonter la chaine.

## Rules

- **Language**: messages en francais, commandes git/glab en anglais
- **Never force push without `--force-with-lease`**
- **Ask before resolving conflicts** in local mode — in CI mode, resolve automatically
- **Delegate pipeline restart to `/ci-run`** — do not duplicate pipeline triggering logic

$ARGUMENTS
