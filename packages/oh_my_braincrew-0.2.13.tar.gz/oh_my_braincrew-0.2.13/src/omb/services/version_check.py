# OMB-PLAN-000071: Version update checker
"""Version update checker — queries GitHub releases API and caches result."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

CACHE_DIR = Path.home() / ".omb" / "cache"
CACHE_FILE = Path(os.environ.get("OMB_VERSION_CACHE", str(CACHE_DIR / "latest-version.json")))
CACHE_TTL_SECONDS = 86400  # 24 hours


def fetch_latest_version() -> str | None:
    """Fetch latest version tag from GitHub API. Returns version string or None."""
    import urllib.request

    from omb.commands.update import GITHUB_API

    try:
        req = urllib.request.Request(
            GITHUB_API,
            headers={"Accept": "application/vnd.github+json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            tag = str(data.get("tag_name", ""))
            return tag.lstrip("v") if tag else None
    except Exception:
        return None


def write_cache(latest_version: str) -> None:
    """Write latest version to cache file with 0o600 permissions."""
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(json.dumps({
            "latest_version": latest_version,
            "checked_at": time.time(),
        }))
        CACHE_FILE.chmod(0o600)
    except OSError:
        pass


def read_cache() -> str | None:
    """Read cached latest version. Returns None if cache missing or expired."""
    try:
        if not CACHE_FILE.exists():
            return None
        data = json.loads(CACHE_FILE.read_text())
        checked_at = float(data.get("checked_at", 0))
        if time.time() - checked_at > CACHE_TTL_SECONDS:
            return None
        return str(data.get("latest_version", "")) or None
    except (json.JSONDecodeError, OSError, KeyError):
        return None


def check_and_cache() -> str | None:
    """Check for updates, cache result. Called by SessionStart hook (in background thread)."""
    cached = read_cache()
    if cached is not None:
        return cached
    latest = fetch_latest_version()
    if latest:
        write_cache(latest)
    return latest


def get_latest_cached() -> str | None:
    """Read cached latest version (non-blocking). Called by statusline render."""
    return read_cache()
