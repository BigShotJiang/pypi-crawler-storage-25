"""omb update — upgrade oh-my-braincrew CLI and plugin from the public release repo."""

from __future__ import annotations

import contextlib
import json
import platform
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

import click

PKG_NAME = "oh-my-braincrew"
RELEASE_REPO = "teddynote-lab/oh-my-braincrew-release"
RELEASE_REPO_URL = f"https://github.com/{RELEASE_REPO}.git"
GITHUB_API = f"https://api.github.com/repos/{RELEASE_REPO}/releases/latest"


def _run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    """Run a subprocess, raising on failure when *check* is True."""
    result = subprocess.run(cmd, capture_output=True, text=True)
    if check and result.returncode != 0:
        stderr = result.stderr.strip() or result.stdout.strip()
        raise click.ClickException(f"`{' '.join(cmd)}` failed:\n{stderr}")
    return result


def _is_frozen() -> bool:
    """Return True when running as a PyInstaller-bundled binary."""
    return getattr(sys, "frozen", False)


def _current_platform() -> str:
    """Return platform string matching release asset names."""
    s = platform.system().lower()
    if s in ("windows", "win32"):
        return "windows"
    return s  # darwin, linux


def _current_arch() -> str:
    """Return architecture string matching release asset names."""
    m = platform.machine().lower()
    if m in ("x86_64", "amd64"):
        return "amd64"
    if m in ("arm64", "aarch64"):
        return "arm64"
    return m


def _fetch_json(url: str) -> dict[str, object]:
    """Fetch JSON from a URL."""
    import urllib.request

    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        result: dict[str, object] = json.loads(resp.read())
        return result


def _latest_release() -> tuple[str, str] | None:
    """Fetch latest release info. Returns (version, asset_download_url) or None."""
    try:
        data = _fetch_json(GITHUB_API)
    except Exception:
        return None

    tag = str(data.get("tag_name", ""))
    version = tag.lstrip("v")
    plat = _current_platform()
    arch = _current_arch()

    suffix = ".exe" if plat == "windows" else ""
    target_name = f"omb-v{version}-{plat}-{arch}{suffix}"

    assets: list[dict[str, object]] = data.get("assets", [])  # type: ignore[assignment]
    for asset in assets:
        if str(asset.get("name", "")) == target_name:
            return version, str(asset.get("browser_download_url", ""))

    return None


def _download_file(url: str, dest: Path) -> None:
    """Download a file from URL to dest path."""
    import urllib.request

    click.echo(f"Downloading from {RELEASE_REPO}...")
    urllib.request.urlretrieve(url, str(dest))


def _self_replace(new_binary: Path) -> None:
    """Replace the currently running binary with *new_binary*."""
    current = Path(sys.executable).resolve()
    backup = current.with_suffix(".bak")

    new_binary.chmod(new_binary.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    if backup.exists():
        backup.unlink()
    current.rename(backup)
    try:
        shutil.copy2(str(new_binary), str(current))
        current.chmod(current.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    except Exception:
        if backup.exists():
            backup.rename(current)
        raise
    finally:
        if backup.exists():
            with contextlib.suppress(OSError):
                backup.unlink()


# ---------------------------------------------------------------------------
# Plugin update — always from the public release repo
# ---------------------------------------------------------------------------

def _plugin_dir() -> Path:
    """Return the canonical plugin directory: ~/.omb/plugin/."""
    return Path.home() / ".omb" / "plugin"


def _update_plugin() -> None:
    """Update plugin from the public release repo via git clone or pull."""
    plugin = _plugin_dir()

    if plugin.is_dir() and (plugin / ".git").is_dir():
        click.echo(f"Updating plugin at {plugin}...")
        result = _run(["git", "-C", str(plugin), "pull", "--ff-only"], check=False)
        if result.returncode == 0:
            out = result.stdout.strip()
            click.echo(f"  {out if out else 'Already up to date.'}")
        else:
            click.echo("  git pull failed — re-cloning...")
            shutil.rmtree(plugin)
            _clone_plugin(plugin)
    elif plugin.is_dir():
        # Exists but not a git repo — replace it
        click.echo(f"  Plugin at {plugin} is not a git repo — re-cloning...")
        shutil.rmtree(plugin)
        _clone_plugin(plugin)
    else:
        click.echo("Downloading plugin...")
        _clone_plugin(plugin)

    # Ensure ~/.omb/home points to the plugin dir
    home_file = Path.home() / ".omb" / "home"
    home_file.parent.mkdir(mode=0o700, exist_ok=True)
    home_file.write_text(str(plugin.resolve()))
    home_file.chmod(0o600)


def _clone_plugin(dest: Path) -> None:
    """Clone the public release repo as the plugin directory."""
    result = _run(
        ["git", "clone", "--depth", "1", RELEASE_REPO_URL, str(dest)],
        check=False,
    )
    if result.returncode == 0:
        click.echo(f"  Plugin installed to {dest}")
    else:
        click.echo(f"  Failed to clone plugin: {result.stderr.strip()}")


# ---------------------------------------------------------------------------
# CLI update
# ---------------------------------------------------------------------------

def _update_cli_binary() -> bool:
    """Self-update the frozen binary. Returns True if updated."""
    from omb.services.version import get_version

    current = get_version()
    click.echo(f"Current version: {current}")
    click.echo("Checking for updates...")

    release = _latest_release()
    if release is None:
        click.echo("  No release found for this platform. Skipping CLI update.")
        return False

    latest_version, download_url = release
    if latest_version == current:
        click.echo(f"  CLI already up to date (v{current}).")
        return False

    click.echo(f"  New version: v{current} -> v{latest_version}")
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp) / "omb_new"
        _download_file(download_url, tmp_path)
        _self_replace(tmp_path)

    click.echo(f"  CLI updated to v{latest_version}.")
    return True


def _update_cli_pip() -> None:
    """Update the pip/uv/pipx installation."""
    cmd: list[str]
    if shutil.which("uv"):
        cmd = [str(shutil.which("uv")), "pip", "install", "--upgrade", PKG_NAME]
    elif shutil.which("pipx"):
        result = _run([str(shutil.which("pipx")), "list"], check=False)
        if PKG_NAME in (result.stdout or ""):
            cmd = [str(shutil.which("pipx")), "upgrade", PKG_NAME]
        else:
            cmd = [sys.executable, "-m", "pip", "install", "--upgrade", PKG_NAME]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", PKG_NAME]

    click.echo(f"Updating CLI: {' '.join(cmd)}")
    _run(cmd, check=False)


@click.command("update")
def update_cmd() -> None:
    """Update omb CLI and plugin to the latest version."""
    from omb.commands.sync import sync_plugin_to_project

    # Step 1: Update CLI
    if _is_frozen():
        _update_cli_binary()
    else:
        _update_cli_pip()

    # Step 2: Always update plugin from release repo
    _update_plugin()

    # Step 3: Sync plugin files to current project if in an omb project
    cwd = Path.cwd()
    if (cwd / ".omb").is_dir():
        click.echo()
        click.echo(f"Syncing plugin files to {cwd}...")
        sync_plugin_to_project(cwd, _plugin_dir())
    else:
        click.echo("  (Not in an omb project — skipping project sync)")

    click.echo("Update complete.")
