"""omb sync — sync plugin operational files to the current project."""

from __future__ import annotations

import shutil
from pathlib import Path

import click

PLUGIN_DIR = Path.home() / ".omb" / "plugin"


def _is_omb_project(project_dir: Path) -> bool:
    """Return True if the directory is an omb-initialized project."""
    return (project_dir / ".omb").is_dir()


def sync_plugin_to_project(project_dir: Path, plugin_dir: Path | None = None) -> bool:
    """Sync plugin operational files from plugin dir to the project.

    Copies skills, commands, agents, hooks, rules, and settings from the
    plugin directory to the project's .claude/ directory.  Existing
    project-specific files that don't collide with plugin files are preserved.

    Returns True if sync succeeded, False if plugin dir is missing.
    """
    plugin = plugin_dir or PLUGIN_DIR
    src_claude = plugin / ".claude"

    if not src_claude.is_dir():
        click.echo("  Plugin .claude/ directory not found — skipping sync.")
        return False

    dst_claude = project_dir / ".claude"
    dst_claude.mkdir(parents=True, exist_ok=True)

    synced: list[str] = []

    # 1. Skills: copy each skill dir individually (add/update, never delete project-only skills)
    src_skills = src_claude / "skills"
    dst_skills = dst_claude / "skills"
    if src_skills.is_dir():
        dst_skills.mkdir(parents=True, exist_ok=True)
        count = 0
        for skill_dir in sorted(src_skills.iterdir()):
            if skill_dir.is_dir() and not skill_dir.name.startswith("."):
                dst = dst_skills / skill_dir.name
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(skill_dir, dst)
                count += 1
        synced.append(f"skills ({count})")

    # 2. Commands: sync omb/ subdirectory only
    src_cmds = src_claude / "commands" / "omb"
    dst_cmds = dst_claude / "commands" / "omb"
    if src_cmds.is_dir():
        dst_cmds.parent.mkdir(parents=True, exist_ok=True)
        if dst_cmds.exists():
            shutil.rmtree(dst_cmds)
        shutil.copytree(src_cmds, dst_cmds)
        synced.append("commands/omb")

    # 3. Agents: sync omb/ subdirectory only
    src_agents = src_claude / "agents" / "omb"
    dst_agents = dst_claude / "agents" / "omb"
    if src_agents.is_dir():
        dst_agents.parent.mkdir(parents=True, exist_ok=True)
        if dst_agents.exists():
            shutil.rmtree(dst_agents)
        shutil.copytree(src_agents, dst_agents)
        synced.append("agents/omb")

    # 4. Hooks: sync omb/ subdirectory only
    src_hooks = src_claude / "hooks" / "omb"
    dst_hooks = dst_claude / "hooks" / "omb"
    if src_hooks.is_dir():
        dst_hooks.parent.mkdir(parents=True, exist_ok=True)
        if dst_hooks.exists():
            shutil.rmtree(dst_hooks)
        shutil.copytree(src_hooks, dst_hooks)
        synced.append("hooks/omb")

    # 5. Rules: full replace
    src_rules = src_claude / "rules"
    dst_rules = dst_claude / "rules"
    if src_rules.is_dir():
        if dst_rules.exists():
            shutil.rmtree(dst_rules)
        shutil.copytree(src_rules, dst_rules)
        synced.append("rules")

    # 6. Settings: full replace
    src_settings = src_claude / "settings.json"
    dst_settings = dst_claude / "settings.json"
    if src_settings.is_file():
        shutil.copy2(src_settings, dst_settings)
        synced.append("settings.json")

    if synced:
        click.echo(f"  Synced: {', '.join(synced)}")
    else:
        click.echo("  Nothing to sync.")

    return True


@click.command("sync")
@click.argument("path", default=".", type=click.Path(exists=True))
def sync_cmd(path: str) -> None:
    """Sync plugin files to a project directory."""
    project_dir = Path(path).resolve()

    if not _is_omb_project(project_dir):
        raise click.ClickException(
            f"Not an omb project (no .omb/ directory): {project_dir}\n"
            "Run 'omb init' first."
        )

    plugin = PLUGIN_DIR
    if not plugin.is_dir():
        raise click.ClickException(
            f"Plugin not installed at {plugin}.\n"
            "Run 'omb update' first."
        )

    click.echo(f"Syncing plugin files to {project_dir}...")
    sync_plugin_to_project(project_dir, plugin)
    click.echo("Sync complete.")
