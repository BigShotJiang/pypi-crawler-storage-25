"""CLI commands for deterministic pipeline initialization.

Provides `omb task init` and `omb task checkpoint` subcommands.
These replace the non-deterministic inline JSON generation that Claude
previously performed via Write tool calls.
"""

from __future__ import annotations

import json
import sys
from typing import TYPE_CHECKING

import click

if TYPE_CHECKING:
    from pathlib import Path

from omb.pipeline.definitions import get_pipeline_templates
from omb.pipeline.factory import PipelineFactoryError, apply_checkpoints, clear_checkpoints, init_from_tasks_json, init_from_template
from omb.pipeline.storage import PipelineStorage
from omb.services.paths import resolve_project_root

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TEMPLATE_ALIASES: dict[str, str] = {
    "full": "Interview - Plan - Review - Execute - Verify - Document - Create PR",
    "fix": "ASK_USER - Plan - Review - Execute - Verify - Document - Create PR",
    "plan": "ASK_USER - Plan - Review",
    "exec": "ASK_USER - Execute - Verify - Document - Create PR",
    "review-pr": "ASK_USER - Review PR - Judge - Plan - Review - Execute - Verify - Document - Create PR",
}


def _project_root() -> Path:
    """Resolve project root."""
    return resolve_project_root()


def _list_templates() -> str:
    """Format available templates for display."""
    lines = ["Available templates:"]
    templates = get_pipeline_templates()
    for i, name in enumerate(templates, start=1):
        lines.append(f"  {i}. {name}")
    lines.append("")
    lines.append("Aliases:")
    for alias, target in _TEMPLATE_ALIASES.items():
        lines.append(f"  {alias} -> {target}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Click group
# ---------------------------------------------------------------------------

task_group = click.Group("task", help="Pipeline task management commands.")


@task_group.command("init")
@click.argument("template", required=False, default="")
@click.option("--name", "pipeline_name", default=None, help="Pipeline name override")
@click.option("--description", default="", help="Pipeline description")
@click.option("--checkpoints", default="", help="Comma-separated task_names to checkpoint")
@click.option("--manual", is_flag=True, default=False, help="Read tasks JSON from stdin")
@click.option("--tasks-json", "tasks_json", default="", help="Tasks JSON string (alternative to stdin)")
@click.option("--json", "as_json", is_flag=True, default=False, help="Output structured JSON")
def task_init(
    template: str,
    pipeline_name: str | None,
    description: str,
    checkpoints: str,
    manual: bool,
    tasks_json: str,
    as_json: bool,
) -> None:
    """Initialize a new pipeline session from a template or manual task list.

    TEMPLATE is a template name or alias (e.g. "fix", "plan", "full").
    Omit to list available templates.

    Use --manual with --tasks-json or stdin to create a custom pipeline.
    """
    root = _project_root()
    storage = PipelineStorage(root)

    try:
        if manual:
            # Manual mode: read tasks from --tasks-json or stdin.
            raw = tasks_json or sys.stdin.read()
            if not raw.strip():
                click.echo("Error: no tasks JSON provided (use --tasks-json or pipe to stdin)", err=True)
                sys.exit(1)
            pipeline, waves = init_from_tasks_json(
                raw,
                name=pipeline_name or "Manual Pipeline",
                description=description,
            )
        else:
            # Template mode.
            if not template:
                click.echo(_list_templates())
                sys.exit(0)

            pipeline, waves = init_from_template(
                template,
                name=pipeline_name,
                description=description,
            )

        # Apply checkpoints if requested.
        if checkpoints:
            cp_names = [n.strip() for n in checkpoints.split(",") if n.strip()]
            for task in pipeline.tasks:
                if task.task_name in cp_names:
                    task.checkpoint = True

        # Save to disk.
        storage.save(pipeline)

        # Output.
        if as_json:
            result = {
                "session_id": pipeline.session_id,
                "name": pipeline.name,
                "description": pipeline.description,
                "waves": waves,
                "checkpoints": [t.task_name for t in pipeline.tasks if t.checkpoint],
                "tasks": [
                    {
                        "task_id": t.task_id,
                        "task_name": t.task_name,
                        "task_type": str(t.task_type),
                        "checkpoint": t.checkpoint,
                    }
                    for t in pipeline.tasks
                ],
            }
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(f"session_id: {pipeline.session_id}")
            click.echo(f"name: {pipeline.name}")
            if pipeline.description:
                click.echo(f"description: {pipeline.description}")
            click.echo("")
            for i, wave in enumerate(waves):
                click.echo(f"Wave {i}: [{', '.join(wave)}]")
            cp_tasks = [t.task_name for t in pipeline.tasks if t.checkpoint]
            if cp_tasks:
                click.echo(f"\nCheckpoints: {', '.join(cp_tasks)}")
            click.echo(f"\nSaved: .omb/sessions/{pipeline.session_id}.json")

    except PipelineFactoryError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)


@task_group.command("checkpoint")
@click.argument("session_id")
@click.option("--tasks", "task_names", default=None, help="Comma-separated task_names to checkpoint")
@click.option("--clear", "clear_all", is_flag=True, default=False, help="Clear all checkpoints from the session")
def task_checkpoint(session_id: str, task_names: str | None, clear_all: bool) -> None:
    """Enable or clear checkpoints on tasks in an existing session."""
    if clear_all and task_names:
        click.echo("Error: --clear and --tasks are mutually exclusive", err=True)
        sys.exit(1)
    if not clear_all and not task_names:
        click.echo("Error: provide --tasks or --clear", err=True)
        sys.exit(1)

    root = _project_root()
    storage = PipelineStorage(root)

    try:
        if clear_all:
            state = clear_checkpoints(storage, session_id)
            click.echo("All checkpoints cleared.")
            auto = [t.task_name for t in state.tasks if t.task_type.value == "SKILL"]
            if auto:
                click.echo(f"Auto-advance: {', '.join(auto)}")
        else:
            assert task_names is not None
            names = [n.strip() for n in task_names.split(",") if n.strip()]
            if not names:
                click.echo("Error: --tasks requires at least one task name", err=True)
                sys.exit(1)
            state = apply_checkpoints(storage, session_id, names)
            click.echo(f"Checkpoints enabled: {', '.join(names)}")
            auto = [t.task_name for t in state.tasks if not t.checkpoint and t.task_type.value == "SKILL"]
            if auto:
                click.echo(f"Auto-advance: {', '.join(auto)}")
    except PipelineFactoryError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)


@task_group.command("list")
def task_list() -> None:
    """List available pipeline templates."""
    click.echo(_list_templates())
