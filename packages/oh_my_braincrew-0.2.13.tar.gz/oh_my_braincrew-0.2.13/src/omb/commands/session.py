"""CLI command group for inspecting and mutating session state.

`omb session set <session_id> --field <field> --value <value>` allows
pipeline automation scripts to patch individual fields on a live session
without rewriting the entire JSON.
"""
# OMB-PLAN-000077: session command group

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

import click

from omb.pipeline.storage import PipelineStorage
from omb.services.paths import resolve_project_root

if TYPE_CHECKING:
    from pathlib import Path

# OMB-PLAN-000077: allowlist of fields that callers are permitted to mutate
_ALLOWED_FIELDS: frozenset[str] = frozenset(["worktree_path", "description", "name"])


def _project_root() -> Path:
    """Resolve project root."""
    return resolve_project_root()


@click.group("session")
def session_group() -> None:
    """Commands for inspecting and mutating pipeline session state."""


@session_group.command("set")
@click.argument("session_id")
@click.option("--field", required=True, help="Field name to update.")
@click.option("--value", required=True, help='New value. Pass "null" to clear the field.')
def session_set_cmd(session_id: str, field: str, value: str) -> None:
    """Set a single field on a pipeline session.

    SESSION_ID is the pipeline session identifier.
    Use --field and --value to specify the mutation.
    Pass "null" as the value to set the field to None.
    """
    # OMB-PLAN-000077: reject disallowed fields early
    if field not in _ALLOWED_FIELDS:
        click.echo(
            f"[session set] field {field!r} is not allowed; "
            f"permitted fields: {sorted(_ALLOWED_FIELDS)}",
            err=True,
        )
        sys.exit(1)

    root = _project_root()
    storage = PipelineStorage(root)

    if not storage.exists(session_id):
        click.echo(f"[session set] session {session_id!r} not found", err=True)
        sys.exit(1)

    try:
        state = storage.load(session_id)
    except Exception as exc:  # noqa: BLE001
        click.echo(f"[session set] session {session_id!r} state is corrupted: {exc}", err=True)
        sys.exit(1)

    if state is None:
        click.echo(f"[session set] failed to load session {session_id!r}", err=True)
        sys.exit(1)

    # OMB-PLAN-000077: "null" string maps to Python None
    coerced_value: str | None = None if value == "null" else value
    setattr(state, field, coerced_value)

    try:
        storage.save(state)
    except Exception as exc:  # noqa: BLE001
        click.echo(f"[session set] failed to save session {session_id!r}: {exc}", err=True)
        sys.exit(1)

    click.echo(f"[session set] {session_id!r}.{field} = {coerced_value!r}")
