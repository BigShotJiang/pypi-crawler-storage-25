"""CLI command for rendering pipeline progress as an ANSI box-drawing table."""

from __future__ import annotations

import os
import sys

import click

from omb.pipeline.storage import PipelineStorage
from omb.pipeline.types import PipelineState, TaskStatus
from omb.services.paths import resolve_project_root

# ANSI color codes
_GREEN = "\033[32m"
_BOLD_YELLOW = "\033[1;33m"
_RED = "\033[31m"
_DIM = "\033[2m"
_RESET = "\033[0m"

_STATUS_DISPLAY: dict[TaskStatus, tuple[str, str]] = {
    TaskStatus.DONE: (_GREEN, "✓ done"),
    TaskStatus.ACTIVE: (_BOLD_YELLOW, "▶ active"),
    TaskStatus.FAILED: (_RED, "✗ failed"),
    TaskStatus.SKIPPED: (_DIM, "- skipped"),
    TaskStatus.PENDING: ("", "  --"),
}

_STATUS_COL_WIDTH = 9  # width of "▶ active" (longest status string)


def _render_progress(state: PipelineState, use_color: bool) -> str:
    """Render the pipeline progress table as a string."""
    tasks = state.tasks
    if not tasks:
        return f" Pipeline: {state.session_id}  (no tasks)"

    done_count = sum(1 for t in tasks if t.status == TaskStatus.DONE)
    total = len(tasks)
    task_col_width = max(max(len(t.task_name) for t in tasks), 12)

    lines: list[str] = []

    # Header line
    header = f" Pipeline: {state.session_id}"
    counter = f"{done_count}/{total} done"
    pad = max(50 - len(header) - len(counter), 2)
    lines.append(f"{header}{' ' * pad}{counter}")

    # Column widths: # = 3, Task = task_col_width, Status = _STATUS_COL_WIDTH
    num_w = 3
    stat_w = _STATUS_COL_WIDTH

    def hline(left: str, mid1: str, mid2: str, right: str) -> str:
        return f" {left}{'─' * (num_w + 2)}{mid1}{'─' * (task_col_width + 2)}{mid2}{'─' * (stat_w + 2)}{right}"

    top = hline("┌", "┬", "┬", "┐")
    div = hline("├", "┼", "┼", "┤")
    bot = hline("└", "┴", "┴", "┘")

    def row(num: str, task: str, status: str, color: str = "") -> str:
        content = f" │ {num:>{num_w}} │ {task:<{task_col_width}} │ {status:<{stat_w}} │"
        if color and use_color:
            return f" {color}{content[1:]}{_RESET}"
        return content

    lines.append(top)
    lines.append(row("#", "Task", "Status"))
    lines.append(div)

    for i, t in enumerate(tasks, start=1):
        color, status_text = _STATUS_DISPLAY.get(t.status, ("", "  --"))
        lines.append(row(str(i), t.task_name, status_text, color))

    lines.append(bot)
    return "\n".join(lines)


@click.command("progress")
@click.argument("session_id")
def progress_cmd(session_id: str) -> None:
    """Render an ANSI progress table for a pipeline session."""
    root = resolve_project_root()
    storage = PipelineStorage(root)
    state = storage.load(session_id)

    if state is None:
        click.echo(f"Error: session '{session_id}' not found", err=True)
        sys.exit(1)

    use_color = "NO_COLOR" not in os.environ
    click.echo(_render_progress(state, use_color))
