"""Pipeline instantiation factory.

Deterministic pipeline creation from templates or manual task lists.
All ID generation, dependency wiring, validation, and persistence
happen here — keeping the CLI layer thin and the skill layer scriptable.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from omb.pipeline.definitions import get_pipeline_templates, resolve_template_name
from omb.pipeline.types import (
    NotificationConfig,
    PipelineState,
    PipelineStatus,
    TaskState,
    TaskType,
    generate_session_id,
    generate_task_id,
)
from omb.pipeline.validation import validate_pipeline_schema
from omb.pipeline.waves import compute_waves

if TYPE_CHECKING:
    from omb.pipeline.storage import PipelineStorage


class PipelineFactoryError(Exception):
    """Raised when pipeline creation or validation fails."""


def init_from_template(
    template_name: str,
    *,
    name: str | None = None,
    description: str | None = None,
) -> tuple[PipelineState, list[list[str]]]:
    """Create a pipeline from a pre-made template.

    Args:
        template_name: Template display name or alias (e.g. "fix", "plan").
        name: Override pipeline name (defaults to template display name).
        description: Override pipeline description.

    Returns:
        (PipelineState, waves) where waves is the Kahn topological sort result.

    Raises:
        PipelineFactoryError: If template not found or validation fails.
    """
    canonical = resolve_template_name(template_name)
    if canonical is None:
        available = list(get_pipeline_templates().keys())
        raise PipelineFactoryError(
            f"Unknown template {template_name!r}. Available: {available}"
        )

    templates = get_pipeline_templates()
    tasks = templates[canonical]

    pipeline = _build_pipeline(
        tasks=tasks,
        name=name or canonical,
        description=description or "",
    )

    waves = _validate_and_compute_waves(pipeline)
    return pipeline, waves


def init_from_tasks_json(
    tasks_json: str,
    *,
    name: str,
    description: str = "",
) -> tuple[PipelineState, list[list[str]]]:
    """Create a pipeline from a manual task list (JSON string).

    The input JSON is a list of task dicts with at least:
      - task_name (str)
      - task_type (str: SKILL, SUB-AGENT, ASK_USER, SYSTEM_DECISION)
      - depends_on_index (list[int]): positional references to other tasks

    IDs, status, and other fields are generated/defaulted here.

    Returns:
        (PipelineState, waves)

    Raises:
        PipelineFactoryError: If JSON parsing or validation fails.
    """
    try:
        raw_tasks: list[dict[str, Any]] = json.loads(tasks_json)
    except json.JSONDecodeError as exc:
        raise PipelineFactoryError(f"Invalid tasks JSON: {exc}") from exc

    if not raw_tasks:
        raise PipelineFactoryError("tasks_json must be a non-empty JSON array")

    # Generate task_ids and build TaskState objects.
    task_states: list[TaskState] = []
    for raw in raw_tasks:
        task_states.append(TaskState(
            task_id=generate_task_id(),
            task_name=raw.get("task_name", "unknown"),
            task_type=TaskType(raw.get("task_type", "SKILL")),
            task_payload=raw.get("task_payload"),
            checkpoint=raw.get("checkpoint", False),
            max_retries=raw.get("max_retries", 0),
        ))

    # Wire depends_on using positional index references.
    for i, raw in enumerate(raw_tasks):
        dep_indices: list[int] = raw.get("depends_on_index", [])
        task_states[i].depends_on = [
            task_states[idx].task_id for idx in dep_indices if 0 <= idx < len(task_states)
        ]

    pipeline = _build_pipeline(
        tasks=task_states,
        name=name,
        description=description,
    )

    waves = _validate_and_compute_waves(pipeline)
    return pipeline, waves


def apply_checkpoints(
    storage: PipelineStorage,
    session_id: str,
    task_names: list[str],
) -> PipelineState:
    """Enable checkpoints on tasks matching the given task_names.

    Args:
        storage: PipelineStorage instance.
        session_id: Existing session to modify.
        task_names: List of task_name values to set checkpoint=True.

    Returns:
        Updated PipelineState.

    Raises:
        PipelineFactoryError: If session not found or task_name not matched.
    """
    state = storage.load(session_id)
    if state is None:
        raise PipelineFactoryError(f"Session {session_id!r} not found")

    known_names = {t.task_name for t in state.tasks}
    for tn in task_names:
        if tn not in known_names:
            raise PipelineFactoryError(
                f"Task name {tn!r} not found in session. Available: {sorted(known_names)}"
            )

    for task in state.tasks:
        if task.task_name in task_names:
            task.checkpoint = True

    storage.save(state)
    return state


def clear_checkpoints(
    storage: PipelineStorage,
    session_id: str,
) -> PipelineState:
    """Clear all checkpoints from a session.

    Args:
        storage: PipelineStorage instance.
        session_id: Existing session to modify.

    Returns:
        Updated PipelineState.

    Raises:
        PipelineFactoryError: If session not found.
    """
    state = storage.load(session_id)
    if state is None:
        raise PipelineFactoryError(f"Session {session_id!r} not found")

    for task in state.tasks:
        task.checkpoint = False

    storage.save(state)
    return state


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_pipeline(
    *,
    tasks: list[TaskState],
    name: str,
    description: str,
) -> PipelineState:
    """Construct a PipelineState with a fresh session_id."""
    from datetime import UTC, datetime

    return PipelineState(
        session_id=generate_session_id(),
        name=name,
        description=description,
        status=PipelineStatus.ACTIVE,
        created_at=datetime.now(tz=UTC),
        notification=NotificationConfig(),
        tasks=tasks,
    )


def _validate_and_compute_waves(pipeline: PipelineState) -> list[list[str]]:
    """Validate the pipeline and compute wave structure.

    Raises PipelineFactoryError on validation failure.
    """
    data = json.loads(pipeline.model_dump_json())
    ok, errors = validate_pipeline_schema(data)
    if not ok:
        raise PipelineFactoryError(
            "Validation failed:\n" + "\n".join(f"  - {e}" for e in errors)
        )

    waves = compute_waves(pipeline.tasks)

    # Convert wave task_ids to task_names for display.
    id_to_name = {t.task_id: t.task_name for t in pipeline.tasks}
    named_waves = [[id_to_name[tid] for tid in wave] for wave in waves]
    return named_waves
