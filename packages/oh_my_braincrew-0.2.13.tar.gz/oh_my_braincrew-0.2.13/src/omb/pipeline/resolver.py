"""Pipeline state resolver — filters to ACTIVE pipelines only.

# BCRW-PLAN-000080: Pipeline resolver
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from omb.pipeline.types import PipelineState, PipelineStatus

if TYPE_CHECKING:
    from omb.pipeline.storage import PipelineStorage


class PipelineResolver:
    """Resolves a session ID to its active PipelineState.

    Returns None for missing, completed, stalled, or cancelled pipelines so
    callers only ever receive a state that is ready for further processing.
    """

    def __init__(self, storage: PipelineStorage) -> None:
        self._storage = storage

    def resolve(self, session_id: str) -> PipelineState | None:
        """Load state for session_id and return it only if status is ACTIVE.

        Returns:
            PipelineState when the pipeline exists and is ACTIVE.
            None when the file is missing or status is not ACTIVE.
        """
        state = self._storage.load(session_id)
        if state is None or state.status != PipelineStatus.ACTIVE:
            return None
        return state

    def resolve_by_claude_session(self, claude_session_id: str) -> PipelineState | None:
        """Scan active pipelines for one whose claude_session_id matches.

        Linear scan over list_sessions(). Only loads each file once and stops
        at the first ACTIVE match. Expected session count is small (< 20).
        Corrupt or incompatible session files are skipped to prevent one bad
        file from breaking the entire scan.
        """
        for sid in self._storage.list_sessions():
            try:
                state = self._storage.load(sid)
            except Exception:  # noqa: BLE001
                continue
            if (
                state is not None
                and state.status == PipelineStatus.ACTIVE
                and state.claude_session_id == claude_session_id
            ):
                return state
        return None

    def resolve_single_active(self) -> PipelineState | None:
        """Return the sole active pipeline, or None if zero or 2+ are active.

        Last-resort fallback for Stop events where claude_session_id has not
        yet been bound.  Only safe when exactly one pipeline is active —
        ambiguity means we cannot know which pipeline the event belongs to.
        """
        active: list[PipelineState] = []
        for sid in self._storage.list_sessions():
            try:
                state = self._storage.load(sid)
            except Exception:  # noqa: BLE001
                continue
            if state is not None and state.status == PipelineStatus.ACTIVE:
                active.append(state)
                if len(active) > 1:
                    return None  # ambiguous — abort
        return active[0] if len(active) == 1 else None
