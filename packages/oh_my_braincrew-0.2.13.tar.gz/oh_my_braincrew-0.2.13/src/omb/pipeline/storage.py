"""Pipeline state persistence with lock-file pattern.

# BCRW-PLAN-000080: Pipeline storage with lock-file pattern

Uses LOCK_EX file locks to prevent concurrent read/write races (RPR-018).
Session IDs are sanitized to prevent path traversal attacks (RPR-019).
Writes use a temp-file + atomic rename pattern for crash safety.
"""

from __future__ import annotations

import contextlib
import fcntl
import os
import tempfile
from pathlib import Path  # noqa: TC003

from omb.pipeline.types import PipelineState

# Characters that make a session_id unsafe for use as a filename component.
_FORBIDDEN_CHARS = frozenset(["/", "\\", "\x00"])
_FORBIDDEN_SEQUENCES = frozenset([".."])


class PipelineStorage:
    """Persistent storage for PipelineState using JSON files with lock-file concurrency.

    Layout under project_root:
        .omb/sessions/{session_id}.json   — state data
        .omb/sessions/{session_id}.lock   — exclusive lock file (never removed)
        .omb/reports/                     — reserved for future report artefacts
    """

    def __init__(self, project_root: Path | str) -> None:
        self._root = Path(project_root)
        self._sessions_dir = self._root / ".omb" / "sessions"
        self._reports_dir = self._root / ".omb" / "reports"
        self._sessions_dir.mkdir(parents=True, exist_ok=True)
        self._reports_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _path(self, session_id: str) -> Path:
        """Return the JSON path for session_id after sanitization.

        Raises ValueError if session_id contains path-unsafe characters.
        """
        self._validate_session_id(session_id)
        return self._sessions_dir / f"{session_id}.json"

    def _lock_path(self, session_id: str) -> Path:
        """Return the lock-file path for session_id."""
        self._validate_session_id(session_id)
        return self._sessions_dir / f"{session_id}.lock"

    @staticmethod
    def _validate_session_id(session_id: str) -> None:
        """Reject session IDs that could enable path traversal (RPR-019)."""
        for ch in _FORBIDDEN_CHARS:
            if ch in session_id:
                raise ValueError(
                    f"Invalid session_id {session_id!r}: contains forbidden character {ch!r}"
                )
        for seq in _FORBIDDEN_SEQUENCES:
            if seq in session_id:
                raise ValueError(
                    f"Invalid session_id {session_id!r}: contains forbidden sequence {seq!r}"
                )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self, session_id: str) -> PipelineState | None:
        """Load and return PipelineState for session_id, or None if not found.

        Acquires LOCK_EX on the lock file before reading to prevent races.
        """
        target = self._path(session_id)
        lock_file = self._lock_path(session_id)

        with open(lock_file, "a+") as lf:
            fcntl.flock(lf, fcntl.LOCK_EX)
            try:
                if not target.exists():
                    return None
                return PipelineState.model_validate_json(target.read_text(encoding="utf-8"))
            finally:
                fcntl.flock(lf, fcntl.LOCK_UN)

    def save(self, state: PipelineState) -> None:
        """Persist state atomically using temp-file + fsync + rename.

        Acquires LOCK_EX on the lock file before writing to prevent races.
        """
        target = self._path(state.session_id)
        lock_file = self._lock_path(state.session_id)

        with open(lock_file, "a+") as lf:
            fcntl.flock(lf, fcntl.LOCK_EX)
            try:
                payload = state.model_dump_json()
                # Write to a temp file in the same directory so rename is atomic.
                fd, tmp_path = tempfile.mkstemp(
                    suffix=".tmp",
                    prefix=f"{state.session_id}_",
                    dir=self._sessions_dir,
                )
                try:
                    with os.fdopen(fd, "w", encoding="utf-8") as f:
                        f.write(payload)
                        f.flush()
                        os.fsync(f.fileno())
                    os.rename(tmp_path, target)
                except Exception:
                    # Clean up temp file on failure before re-raising.
                    with contextlib.suppress(OSError):
                        os.unlink(tmp_path)
                    raise
            finally:
                fcntl.flock(lf, fcntl.LOCK_UN)

    def exists(self, session_id: str) -> bool:
        """Return True if the session file exists."""
        return self._path(session_id).exists()

    def delete(self, session_id: str) -> None:
        """Delete the session JSON file if it exists. Noop if missing.

        Acquires LOCK_EX to prevent race with concurrent save().
        """
        target = self._path(session_id)
        lock_file = self._lock_path(session_id)

        with open(lock_file, "a+") as lf:
            fcntl.flock(lf, fcntl.LOCK_EX)
            try:
                target.unlink(missing_ok=True)
            finally:
                fcntl.flock(lf, fcntl.LOCK_UN)

    def archive(self, session_id: str) -> None:
        """Move session JSON to finished/ and remove the lock file.

        Called when a pipeline reaches a terminal state (completed, stalled, cancelled).
        """
        source = self._path(session_id)
        lock_file = self._lock_path(session_id)
        finished_dir = self._sessions_dir / "finished"
        finished_dir.mkdir(parents=True, exist_ok=True)

        if source.exists():
            dest = finished_dir / source.name
            source.rename(dest)

        lock_file.unlink(missing_ok=True)

    def list_sessions(self) -> list[str]:
        """Return session IDs for all persisted sessions.

        Excludes .tmp files (partial writes) and .lock files (lock artefacts).
        """
        return [
            p.stem
            for p in self._sessions_dir.glob("*.json")
            if not p.name.endswith(".tmp")
        ]
