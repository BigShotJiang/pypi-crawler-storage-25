# BCRW-PLAN-000080: Dependency wiring and CLI registration
"""Shared dependency factories consumed by CLI command groups.

Centralises construction of stateful singletons (HookHandler, session manager)
so that command modules can import them lazily without circular dependencies.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from omb.services.paths import resolve_project_root

if TYPE_CHECKING:
    from omb.hook.handler import HookHandler


def _project_root() -> str:
    """Return the project root directory as a string.

    Delegates to resolve_project_root() for centralized resolution (RPR-044).
    No caching — re-resolves on every call so tests can monkeypatch freely.
    """
    return str(resolve_project_root())


def get_handler() -> HookHandler:
    """Return a fully-wired HookHandler instance.

    When pipeline.enabled is True in .omb/config.json, constructs the full
    session manager chain:
        PipelineStorage → PipelineResolver → SessionHandler → SessionManager

    The concrete SessionManager.handle(event, input, status) is adapted to the
    handle_event(hook_input) protocol expected by HookHandler via a thin lambda
    adapter.  If pipeline is disabled or config cannot be loaded, returns a bare
    HookHandler with no session manager.

    All heavy imports are inside this function body (lazy imports, RPR-021).
    """
    # Lazy imports for startup performance (RPR-021).
    import re

    from omb.hook.handler import HookHandler
    from omb.hook.types import Decision, EventType, HookInput, HookOutput
    from omb.hook.utils import parse_result_status_with_session
    from omb.services.config import load_config

    pipeline_session_re = re.compile(r"\d{12}-[a-z0-9]{6}")

    root = Path(_project_root())
    cfg = load_config(root)

    if not cfg.pipeline.enabled:
        return HookHandler()

    from omb.pipeline.resolver import PipelineResolver
    from omb.pipeline.storage import PipelineStorage
    from omb.pipeline.types import PipelineState, ResultStatus
    from omb.services.notification import load_config as load_slack_config  # noqa: PLC0415
    from omb.session.handler import SessionHandler
    from omb.session.manager import SessionManager as ConcreteSessionManager

    storage = PipelineStorage(root)
    resolver = PipelineResolver(storage)
    slack_config = load_slack_config()
    session_handler = SessionHandler(storage, notification_config=slack_config)
    concrete_manager = ConcreteSessionManager(resolver=resolver, handler=session_handler)

    # Map skill completion signals to pipeline result statuses.
    skill_status_map: dict[str, ResultStatus] = {
        "DONE": ResultStatus.APPROVED,
        "DONE_WITH_CONCERNS": ResultStatus.APPROVED,
        "APPROVED": ResultStatus.APPROVED,
        "NEEDS_REVISION": ResultStatus.REJECT,
        "REJECT": ResultStatus.REJECT,
        "FAILED": ResultStatus.FAILED,
        "NEEDS_CONTEXT": ResultStatus.NONE,
        "BLOCKED": ResultStatus.NONE,
    }

    # Driver heartbeat staleness threshold in seconds.
    # If omb-run hasn't called `omb advance` within this window, the Stop hook
    # assumes the driver is dead and takes over advancement.
    _DRIVER_STALE_THRESHOLD_SECONDS = 120.0

    def _log_guard(
        event_input: HookInput,
        reason: str,
        state: PipelineState | None = None,
    ) -> None:
        """Log a guard skip to both Claude UUID and pipeline session logs."""
        from omb.hook.event_logger import log_pipeline_event  # noqa: PLC0415

        log_pipeline_event(
            event_input,
            pipeline_session_id=state.session_id if state else None,
            event_name="guard_skip",
            details={
                "reason": reason,
                "driver": state.driver if state else None,
                "active_task": (
                    active.task_name
                    if (active := state.active_task() if state else None)
                    else None
                ),
            },
        )

    def _check_driver_guard(
        event_input: HookInput,
        xml_pipeline_id: str | None,
    ) -> tuple[bool, str, PipelineState | None]:
        """Consolidated driver guard for Stop events.

        Returns (should_skip, reason, resolved_state).

        Checks whether a pipeline driver (e.g. omb-run) is actively controlling
        the pipeline.  If the driver is set but its heartbeat is stale (no
        `omb advance` call within _DRIVER_STALE_THRESHOLD_SECONDS), clears the
        driver and allows the Stop hook to take over — preventing permanent stall
        when the driver dies.
        """
        from datetime import UTC, datetime  # noqa: PLC0415

        # Resolution chain: try Claude UUID, then claude_session_id binding,
        # then single-active fallback.
        sid = event_input.session_id or ""
        state = (
            resolver.resolve(sid)
            or resolver.resolve_by_claude_session(sid)
            or resolver.resolve_single_active()
        )

        # Secondary resolution: if primary failed but <omb> markers carry a
        # pipeline session_id, resolve directly.
        if state is None and xml_pipeline_id:
            state = resolver.resolve(xml_pipeline_id)
        elif xml_pipeline_id:
            # If primary resolved a different pipeline than the XML marker
            # references, prefer the XML-referenced pipeline for the driver check.
            xml_state = resolver.resolve(xml_pipeline_id)
            if xml_state and xml_state.driver:
                state = xml_state

        if state is None or not state.driver:
            return (False, "no_driver", state)

        # Driver is set — check heartbeat staleness.
        if state.driver_heartbeat is not None:
            age = (datetime.now(tz=UTC) - state.driver_heartbeat).total_seconds()
            if age > _DRIVER_STALE_THRESHOLD_SECONDS:
                # Driver is dead — clear it and allow Stop hook takeover.
                old_driver = state.driver
                state.driver = None
                state.driver_heartbeat = None
                storage.save(state)
                return (
                    False,
                    f"driver_stale(driver={old_driver}, age={age:.0f}s > {_DRIVER_STALE_THRESHOLD_SECONDS:.0f}s)",
                    state,
                )
            return (
                True,
                f"driver={state.driver}, heartbeat={age:.0f}s ago",
                state,
            )

        # Legacy session without heartbeat — preserve old blocking behavior.
        return (True, f"driver={state.driver}, no_heartbeat (legacy)", state)

    def _maybe_downgrade_for_stop_hook(
        output: HookOutput, stop_hook_active: bool
    ) -> HookOutput:
        """Downgrade BLOCK to ALLOW when stop_hook_active is True.

        When the Stop hook is already active, Claude Code ignores BLOCK
        decisions.  Downgrade to ALLOW so the state update is persisted
        and the next UserPromptSubmit can inject the active task context.

        NOTE: For STOP events, the adapter returns early before reaching
        this function.  This downgrade now only applies to non-STOP events
        where stop_hook_active might be True (e.g., nested hook calls).
        """
        if stop_hook_active and output.decision == Decision.BLOCK:
            output.decision = Decision.ALLOW
            if output.message:
                output.message = f"[Pipeline advanced] Next: {output.message}"
        return output

    class _SessionManagerAdapter:
        """Adapter from handle_event(hook_input) → concrete handle(event, input, status)."""

        def handle_event(self, event_input: HookInput) -> HookOutput:
            try:
                event = EventType(event_input.hook_event_name)
            except ValueError:
                return HookOutput()

            # Guard 1: re-entrant Stop hook — defer to avoid double-advance.
            if event == EventType.STOP and event_input.stop_hook_active:
                _log_guard(event_input, "stop_hook_active=True")
                return HookOutput()

            xml_pipeline_id, xml_task_name, raw_status = parse_result_status_with_session(
                event_input.last_assistant_message,
            )

            # Capture original Claude UUID before XML override
            original_claude_uuid = event_input.session_id or ""

            # Validate XML session_id format before trusting it
            if xml_pipeline_id and not pipeline_session_re.fullmatch(xml_pipeline_id):
                xml_pipeline_id = None  # reject malformed session_id

            # Consolidated driver guard: checks all driver conditions in one
            # place with heartbeat staleness detection.
            if event == EventType.STOP:
                should_skip, reason, guard_state = _check_driver_guard(
                    event_input, xml_pipeline_id,
                )
                if should_skip:
                    _log_guard(event_input, reason, guard_state)
                    return HookOutput()

            # Auto-approve: if parsing failed on a Stop event and an active
            # pipeline has a running task, treat the missing <omb> marker as
            # implicit DONE.  Previously this path delegated to omb-fallback-
            # decide via a two-BLOCK chain, but Claude Code ignores the second
            # BLOCK when stop_hook_active=True, causing the pipeline to freeze.
            # Inline auto-approve eliminates the two-BLOCK dependency.
            if raw_status is None and event == EventType.STOP:
                infer_id = event_input.session_id or ""
                if infer_id:
                    pipeline_state = (
                        resolver.resolve(infer_id)
                        or resolver.resolve_by_claude_session(infer_id)
                        or resolver.resolve_single_active()
                    )
                    if pipeline_state is not None:
                        # Driver check already passed above (not stale),
                        # but if a driver is still present here it means
                        # the guard returned should_skip=False (stale takeover).
                        # In that case, auto-approve is fine.
                        active = pipeline_state.active_task()
                        if active and active.status.value == "active":
                            inferred_status = ResultStatus.APPROVED
                            inferred_input = event_input.model_copy(
                                update={"session_id": pipeline_state.session_id},
                            )
                            inferred_uuid = original_claude_uuid or infer_id
                            output = concrete_manager.handle(
                                event=event,
                                input=inferred_input,
                                status=inferred_status,
                                original_claude_uuid=(
                                    inferred_uuid
                                    if pipeline_state.session_id != infer_id
                                    else None
                                ),
                            )
                            return _maybe_downgrade_for_stop_hook(
                                output, event_input.stop_hook_active
                            )

            # Normal path: map to ResultStatus
            if raw_status in skill_status_map:
                status = skill_status_map[raw_status]
            elif raw_status:
                try:
                    status = ResultStatus(raw_status)
                except ValueError:
                    status = ResultStatus.NONE
            else:
                status = ResultStatus.NONE

            # Guard: if the <omb> marker names a task that differs from the
            # currently active task, the omb advance CLI already advanced past
            # it — skip to prevent double advance.
            # Strip parenthetical description from xml_task_name before comparing:
            # skills emit "<task>create-plan(summary)</task>" but pipeline stores
            # bare "create-plan" — without normalization the guard always fires.
            if xml_task_name:
                bare_xml_task = xml_task_name.split("(")[0].strip()
                guard_id = xml_pipeline_id or event_input.session_id or ""
                if guard_id:
                    guard_state = (
                        resolver.resolve(guard_id)
                        or resolver.resolve_by_claude_session(guard_id)
                    )
                    if guard_state:
                        guard_active = guard_state.active_task()
                        if guard_active and guard_active.task_name != bare_xml_task:
                            _log_guard(
                                event_input,
                                f"task_mismatch(xml={bare_xml_task}, active={guard_active.task_name})",
                                guard_state,
                            )
                            return HookOutput()

            # When skill output includes a pipeline session_id in the XML marker,
            # use it to override the session_id so direct resolve hits in SessionManager.
            if xml_pipeline_id:
                event_input = event_input.model_copy(
                    update={"session_id": xml_pipeline_id},
                )

            output = concrete_manager.handle(
                event=event,
                input=event_input,
                status=status,
                original_claude_uuid=original_claude_uuid if xml_pipeline_id else None,
            )
            return _maybe_downgrade_for_stop_hook(
                output, event_input.stop_hook_active
            )

    return HookHandler(session_manager=_SessionManagerAdapter())
