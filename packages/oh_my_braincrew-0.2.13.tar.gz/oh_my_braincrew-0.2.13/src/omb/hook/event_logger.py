"""Comprehensive hook event logger — logs ALL hook events to .omb/logs/.

Every hook event produces two JSON-line entries: incoming (full payload) and
outgoing (hook response).  When handler.handle() raises, a third entry
(direction: "error") captures the exception.

Log files are named by Claude session UUID so all events for a session land
in one file regardless of pipeline state.  This is orthogonal to the
pipeline-specific step logging in session/handler.py.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from omb.hook.types import HookInput, HookOutput

logger = logging.getLogger(__name__)

_SUMMARY_MAX_LEN = 200


def _resolve_log_dir(hook_input: HookInput) -> str:
    root = (
        hook_input.omb_project_dir
        or os.environ.get("OMB_PROJECT_ROOT")
        or os.environ.get("CLAUDE_PROJECT_DIR")
        or "."
    )
    return os.path.join(root, ".omb", "logs")


def _write_entry(log_dir: str, session_id: str, entry: dict[str, Any]) -> None:
    os.makedirs(log_dir, exist_ok=True)
    filename = session_id if session_id else "unknown"
    log_path = os.path.join(log_dir, f"{filename}.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")


def _truncate(value: str, max_len: int = _SUMMARY_MAX_LEN) -> str:
    if len(value) <= max_len:
        return value
    return value[:max_len] + "..."


def _incoming_summary(hook_input: HookInput) -> dict[str, str]:
    return {
        "tool_name": hook_input.tool_name or "",
        "user_prompt": _truncate(hook_input.user_prompt or ""),
        "last_assistant_message": _truncate(hook_input.last_assistant_message),
    }


def _outgoing_summary(hook_output: HookOutput) -> dict[str, str]:
    return {
        "decision": hook_output.decision.value,
        "message": _truncate(hook_output.message),
    }


def log_incoming(hook_input: HookInput) -> None:
    """Log the full incoming hook payload. Fail-safe — never raises."""
    try:
        log_dir = _resolve_log_dir(hook_input)
        entry: dict[str, Any] = {
            "ts": datetime.now(tz=UTC).isoformat(),
            "direction": "incoming",
            "event": hook_input.hook_event_name,
            "session_id": hook_input.session_id,
            "payload": hook_input.raw,
            "summary": _incoming_summary(hook_input),
        }
        _write_entry(log_dir, hook_input.session_id, entry)
    except Exception:  # noqa: BLE001
        logger.debug("[event_logger] failed to write incoming log (suppressed)")


def log_outgoing(hook_input: HookInput, hook_output: HookOutput) -> None:
    """Log the hook response. Fail-safe — never raises."""
    try:
        log_dir = _resolve_log_dir(hook_input)
        response_str = hook_output.to_stdout()
        try:
            response = json.loads(response_str)
        except (json.JSONDecodeError, TypeError):
            response = {"_raw": response_str}

        entry: dict[str, Any] = {
            "ts": datetime.now(tz=UTC).isoformat(),
            "direction": "outgoing",
            "event": hook_input.hook_event_name,
            "session_id": hook_input.session_id,
            "response": response,
            "summary": _outgoing_summary(hook_output),
        }
        _write_entry(log_dir, hook_input.session_id, entry)
    except Exception:  # noqa: BLE001
        logger.debug("[event_logger] failed to write outgoing log (suppressed)")


def log_pipeline_event(
    hook_input: HookInput,
    pipeline_session_id: str | None,
    event_name: str,
    details: dict[str, Any],
) -> None:
    """Log a pipeline-relevant event to both Claude UUID and pipeline session logs.

    Writes to the Claude UUID log (existing convention) and also to the pipeline
    session log so that pipeline-centric debugging has a single source of truth.
    """
    try:
        log_dir = _resolve_log_dir(hook_input)
        entry: dict[str, Any] = {
            "ts": datetime.now(tz=UTC).isoformat(),
            "direction": "pipeline",
            "event": event_name,
            "claude_session_id": hook_input.session_id,
            "pipeline_session_id": pipeline_session_id,
            **details,
        }
        # Write to Claude UUID log
        _write_entry(log_dir, hook_input.session_id, entry)
        # Write to pipeline session log (if known and different)
        if pipeline_session_id and pipeline_session_id != hook_input.session_id:
            _write_entry(log_dir, pipeline_session_id, entry)
    except Exception:  # noqa: BLE001
        logger.debug("[event_logger] failed to write pipeline event log (suppressed)")


def log_error(hook_input: HookInput, exc: BaseException) -> None:
    """Log a handler error. Fail-safe — never raises."""
    try:
        log_dir = _resolve_log_dir(hook_input)
        entry: dict[str, Any] = {
            "ts": datetime.now(tz=UTC).isoformat(),
            "direction": "error",
            "event": hook_input.hook_event_name,
            "session_id": hook_input.session_id,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
        }
        _write_entry(log_dir, hook_input.session_id, entry)
    except Exception:  # noqa: BLE001
        logger.debug("[event_logger] failed to write error log (suppressed)")
