# BCRW-PLAN-000080: Hook handler — thin routing dispatcher
"""Central hook event dispatcher.

Routes events to the appropriate handler: session events to the session
manager, PreToolUse to per-tool check functions, and all others to
passthrough or stub handlers.

Security check logic lives in ``checks.py``; utility functions in ``utils.py``;
constants in ``constants.py``; regex patterns in ``patterns.py``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Protocol

from omb.hook.checks import check_bash, check_edit, check_write
from omb.hook.types import SESSION_EVENTS, EventType, HookInput, HookOutput

# Re-export for backward compatibility — external consumers import from here.
from omb.hook.utils import parse_result_status as parse_result_status  # noqa: F401

# ---------------------------------------------------------------------------
# Session manager protocol
# ---------------------------------------------------------------------------


class SessionManager(Protocol):
    """Minimal interface for session-level event handling (Hotl pipeline integration)."""

    def handle_event(self, event_input: HookInput) -> HookOutput: ...


# ---------------------------------------------------------------------------
# HookHandler
# ---------------------------------------------------------------------------


class HookHandler:
    """Central hook event dispatcher.

    Routes session events (STOP, UPS, SESSION_START) to an optional session
    manager for Hotl pipeline integration.  All other events are handled
    directly via match/case dispatch.
    """

    def __init__(self, session_manager: SessionManager | None = None) -> None:
        self._session_manager = session_manager

    def handle(self, hook_input: HookInput) -> HookOutput:
        """Dispatch *hook_input* by event type and return the hook output."""
        try:
            event = EventType(hook_input.hook_event_name)
        except ValueError:
            # Unknown event type — passthrough.
            return HookOutput()

        # Parse-only mode for stop-hook-triggered turns: still route to session
        # manager so it can parse <omb> markers from fallback skill output and
        # advance the pipeline. The adapter in deps.py guards against returning
        # BLOCK when stop_hook_active=True, preventing infinite loops.
        if event == EventType.STOP and hook_input.stop_hook_active:
            if self._session_manager is not None:
                return self._session_manager.handle_event(hook_input)
            return HookOutput()

        # Persist Claude session UUID to file on SessionStart (best-effort).
        if event == EventType.SESSION_START and hook_input.session_id:
            try:
                uuid_dir = Path(hook_input.cwd or ".") / ".omb" / "sessions"
                uuid_dir.mkdir(parents=True, exist_ok=True)
                (uuid_dir / ".claude-uuid").write_text(hook_input.session_id)
            except Exception:  # noqa: BLE001
                pass  # best-effort, do not block session start

            # OMB-PLAN-000071: Check for version updates in background thread (non-blocking).
            import threading

            def _bg_version_check() -> None:
                try:
                    from omb.services.version_check import check_and_cache
                    check_and_cache()
                except (OSError, TimeoutError):
                    pass  # version check is best-effort

            threading.Thread(target=_bg_version_check, daemon=True).start()

        # Session events → session manager (if available).
        if event in SESSION_EVENTS:
            if self._session_manager is not None:
                return self._session_manager.handle_event(hook_input)
            # No session manager — passthrough.
            return HookOutput()

        # Non-session event dispatch.
        match event:
            case EventType.PRE_TOOL_USE:
                return self._route_pre_tool_use(hook_input)
            case EventType.POST_TOOL_USE:
                # Stub: plan file naming validation (future implementation).
                return HookOutput()
            case EventType.PRE_COMPACT:
                return HookOutput(
                    message="[BCRW] Context compaction in progress. "
                    "Preserve pipeline state and active task context.",
                    event_type=EventType.PRE_COMPACT,
                )
            case _:
                return HookOutput()

    def _route_pre_tool_use(self, hook_input: HookInput) -> HookOutput:
        """Route PreToolUse to the appropriate per-tool check function."""
        tool_name = hook_input.tool_name or ""
        tool_input = hook_input.tool_input or {}

        match tool_name:
            case "Bash":
                result = check_bash(tool_input)
            case "Write":
                result = check_write(tool_input, hook_input.cwd)
            case "Edit":
                result = check_edit(tool_input, hook_input.cwd)
            case _:
                result = HookOutput()

        # Tag with event type so to_stdout() produces the correct wire format.
        result.event_type = EventType.PRE_TOOL_USE
        return result
