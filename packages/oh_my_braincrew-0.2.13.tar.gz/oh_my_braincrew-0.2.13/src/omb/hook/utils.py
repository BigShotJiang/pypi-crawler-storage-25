# BCRW-PLAN-000080: Hook utility functions
"""Pure utility functions for hook enforcement.

All functions return primitive types (str, bool, None) — never HookOutput.
Check functions in ``checks.py`` compose these utilities to produce decisions.
"""

from __future__ import annotations

import os

from omb.hook.constants import (
    ALLOWLIST_PREFIXES,
    ALLOWLIST_RELATIVE_DIRS,
    DENY_PATH_EXTENSIONS,
    DENY_PATH_PATTERNS,
)
from omb.hook.patterns import (
    COMPLETION_SIGNAL_RE,
    LONG_RUNNING_PATTERNS,
    OMB_MARKER_RE,
    OMB_XML_RE,
    SENSITIVE_CONTENT_PATTERNS,
    VERDICT_HEADER_RE,
)

# ---------------------------------------------------------------------------
# Result status parsing (RPR-042: only match structured markers, not prose)
# ---------------------------------------------------------------------------


def parse_result_status(text: str) -> str | None:
    """Extract a result status from skill output text.

    Matches (in priority order):
    1. XML schema: ``<omb><task>name</task><decision>STATUS</decision></omb>``
    2. Legacy structured markers: ``<omb>STEP:task-name:STATUS</omb>``
    3. Verdict headers: ``### Status: APPROVED``
    4. Completion signals: ``DONE — summary`` at line start (RPR-042 safe)

    Returns the status string (e.g. ``"DONE"``, ``"APPROVED"``) or ``None``.
    """
    # Priority 1: New XML schema
    m = OMB_XML_RE.search(text)
    if m:
        return m.group(3)

    # Priority 2: Legacy structured markers (backward compat)
    m = OMB_MARKER_RE.search(text)
    if m:
        return m.group(1)

    # Priority 3: Verdict headers
    m = VERDICT_HEADER_RE.search(text)
    if m:
        return m.group(1).replace(" ", "_")

    # Priority 4: Completion signals (expanded)
    m = COMPLETION_SIGNAL_RE.search(text)
    if m:
        return m.group(1)

    return None


def parse_result_status_with_session(text: str) -> tuple[str | None, str | None, str | None]:
    """Extract pipeline session_id, task name, and result status from skill output.

    Returns (pipeline_session_id, task_name, status). pipeline_session_id comes
    from the ``<session_id>`` tag in the OMB XML marker (group 1); task_name from
    the ``<task>`` tag (group 2); status from ``<decision>`` (group 3).
    Non-XML parsers never carry a session_id or task_name.
    """
    m = OMB_XML_RE.search(text)
    if m:
        return m.group(1) or None, m.group(2) or None, m.group(3)
    return None, None, parse_result_status(text)


# ---------------------------------------------------------------------------
# Long-running command advisory
# ---------------------------------------------------------------------------


def check_long_running(command: str) -> str | None:
    """Return an advisory message if command matches a known long-running pattern."""
    for pattern in LONG_RUNNING_PATTERNS:
        match = pattern.search(command)
        if match:
            return (
                f"Advisory: `{match.group()}` may take a while. "
                "Consider using `run_in_background: true`."
            )
    return None


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def is_in_allowlist(path: str, cwd: str | None = None) -> bool:
    """Return True if *path* starts with any allowlisted prefix or relative dir."""
    abs_path = os.path.abspath(path)
    if any(
        abs_path.startswith(prefix) or abs_path == prefix.rstrip(os.sep)
        for prefix in ALLOWLIST_PREFIXES
    ):
        return True
    # Check project-relative allowlisted directories.
    if cwd:
        for rel_dir in ALLOWLIST_RELATIVE_DIRS:
            allowed = os.path.realpath(os.path.join(cwd, rel_dir))
            if abs_path.startswith(allowed + os.sep) or abs_path == allowed:
                return True
    return False


def matches_deny_pattern(file_path: str, base: str, pattern: str) -> bool:
    """Return True if *file_path* or *base* matches the deny *pattern*.

    Ported from Go ``matchesDenyPattern`` — exact same logic:
    - Exact basename match (e.g. ``.env``)
    - Prefix match on basename for patterns ending in ``.`` (e.g. ``.env.`` matches ``.env.production``)
    - Substring match against the slash-normalised full path for directory patterns
    """
    pattern_slash = pattern.replace(os.sep, "/")

    # Exact base name match.
    if not pattern.endswith("/"):
        if base == pattern:
            return True
        # Prefix match on base name (e.g. ".env.production" matches ".env.").
        if pattern_slash.endswith(".") and base.startswith(pattern_slash.rstrip(".")):
            return True

    # Directory segment or path substring match.
    file_slash = file_path.replace(os.sep, "/")
    return pattern_slash in file_slash


def check_path_deny(file_path: str, base: str) -> str:
    """Return a non-empty deny reason if the path matches any deny rule."""
    # Blocked extensions.
    ext = os.path.splitext(base)[1].lower()
    for deny_ext in DENY_PATH_EXTENSIONS:
        if ext == deny_ext:
            return f"blocked file extension: {ext}"

    # Blocked path patterns (substring match against slash-normalised path).
    normalized = file_path.replace(os.sep, "/")
    for pattern in DENY_PATH_PATTERNS:
        if matches_deny_pattern(normalized, base, pattern):
            return f"blocked path pattern: {pattern}"

    return ""


def check_path_traversal(file_path: str, boundary: str) -> str:
    """Return a non-empty deny reason if *file_path* escapes *boundary*.

    Uses ``os.path.realpath`` to resolve symlinks (unlike Go which uses Clean+Rel,
    Python realpath also resolves symlinks for stronger defense).
    """
    abs_path = (
        file_path if os.path.isabs(file_path) else os.path.join(boundary, file_path)
    )

    resolved = os.path.realpath(abs_path)
    resolved_boundary = os.path.realpath(boundary)

    # Ensure resolved path is within the boundary.
    try:
        os.path.relpath(resolved, resolved_boundary)
    except ValueError:
        return "path traversal: unable to resolve relative path"

    # Check that the resolved path doesn't escape the boundary.
    if (
        not resolved.startswith(resolved_boundary + os.sep)
        and resolved != resolved_boundary
    ):
        return "path traversal: target is outside project boundary"

    return ""


# ---------------------------------------------------------------------------
# Content scanning
# ---------------------------------------------------------------------------


def scan_content(content: str) -> str:
    """Return a non-empty deny reason if *content* contains sensitive patterns."""
    for pattern in SENSITIVE_CONTENT_PATTERNS:
        if pattern.search(content):
            return f"sensitive content detected: {pattern.pattern}"
    return ""
