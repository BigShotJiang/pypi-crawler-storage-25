# BCRW-PLAN-000080: Composable per-tool check functions
"""One check function per tool type — each returns a HookOutput decision.

Functions are standalone and composable. Import individually to build
custom hook pipelines or combine in handler routing.
"""

from __future__ import annotations

import os
import unicodedata

from omb.hook.constants import DANGEROUS_BASH_SUBSTRINGS
from omb.hook.patterns import DANGEROUS_BASH_CMD_PATTERNS
from omb.hook.types import Decision, HookOutput
from omb.hook.utils import (
    check_long_running,
    check_path_deny,
    check_path_traversal,
    is_in_allowlist,
    scan_content,
)


def check_bash(tool_input: dict[str, object]) -> HookOutput:
    """Check bash command against dangerous patterns.

    Uses two matching strategies:
    - Regex with command-position anchors for commands like ``rm -rf /``
      (avoids false positives from echo/string contexts).
    - Substring match for always-dangerous strings like ``DROP DATABASE``
      and fork bombs (dangerous regardless of context).
    """
    command = str(tool_input.get("command", ""))

    # Position-aware regex patterns (command boundary matching).
    for pattern in DANGEROUS_BASH_CMD_PATTERNS:
        if pattern.search(command):
            return HookOutput(
                decision=Decision.DENY,
                exit_code=2,
                message=f"dangerous bash command blocked: {pattern.pattern}",
            )

    # Always-dangerous substrings (no context sensitivity needed).
    for substring in DANGEROUS_BASH_SUBSTRINGS:
        if substring in command:
            return HookOutput(
                decision=Decision.DENY,
                exit_code=2,
                message=f"dangerous bash command blocked: {substring}",
            )

    # Command is allowed — attach advisory if it matches a long-running pattern.
    advisory = check_long_running(command)
    if advisory:
        return HookOutput(message=advisory)
    return HookOutput()


def _check_file_path(
    tool_name: str, tool_input: dict[str, object], cwd: str
) -> HookOutput:
    """Shared file path and content validation for Write and Edit tools.

    Applies NFC normalisation, allowlist bypass, path deny, path traversal,
    and content scanning (Write only).
    """
    file_path = str(tool_input.get("file_path", ""))
    if not file_path:
        return HookOutput()

    # NFC-normalise the path (macOS Unicode normalisation defence).
    file_path = unicodedata.normalize("NFC", file_path)

    # Check allowlist first — these paths bypass path deny.
    if is_in_allowlist(file_path, cwd):
        # Content scan still applies even for allowlisted paths.
        if tool_name == "Write":
            content = str(tool_input.get("content", ""))
            reason = scan_content(content)
            if reason:
                return HookOutput(
                    decision=Decision.DENY, exit_code=2, message=reason
                )
        if tool_name == "Edit":
            new_string = str(tool_input.get("new_string", ""))
            reason = scan_content(new_string)
            if reason:
                return HookOutput(
                    decision=Decision.DENY, exit_code=2, message=reason
                )
        return HookOutput()

    # Check path-based deny patterns.
    base = os.path.basename(file_path)
    reason = check_path_deny(file_path, base)
    if reason:
        return HookOutput(
            decision=Decision.DENY, exit_code=2, message=reason
        )

    # Check path traversal — resolve symlinks and compare against project boundary.
    if cwd:
        reason = check_path_traversal(file_path, cwd)
        if reason:
            return HookOutput(
                decision=Decision.DENY, exit_code=2, message=reason
            )

    # Scan content for sensitive patterns (secrets, private keys, API tokens).
    if tool_name == "Write":
        content = str(tool_input.get("content", ""))
        reason = scan_content(content)
        if reason:
            return HookOutput(
                decision=Decision.DENY, exit_code=2, message=reason
            )
    if tool_name == "Edit":
        new_string = str(tool_input.get("new_string", ""))
        reason = scan_content(new_string)
        if reason:
            return HookOutput(
                decision=Decision.DENY, exit_code=2, message=reason
            )

    return HookOutput()


def check_write(tool_input: dict[str, object], cwd: str) -> HookOutput:
    """Check Write tool invocation against path deny and content scan rules."""
    return _check_file_path("Write", tool_input, cwd)


def check_edit(tool_input: dict[str, object], cwd: str) -> HookOutput:
    """Check Edit tool invocation against path deny and content scan rules."""
    return _check_file_path("Edit", tool_input, cwd)
