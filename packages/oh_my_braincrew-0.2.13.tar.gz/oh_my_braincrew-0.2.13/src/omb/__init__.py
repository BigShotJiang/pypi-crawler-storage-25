"""oh-my-braincrew: Multi-agent orchestration harness for Claude Code."""

from omb.services.version import VERSION as __version__  # noqa: N811

__all__ = ["__version__"]
