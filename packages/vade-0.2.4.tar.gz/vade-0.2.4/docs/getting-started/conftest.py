"""Shared fixtures for getting-started page testing.

pytest-markdown-docs runs each code block independently. This conftest
injects common imports into every block's namespace via the
pytest_markdown_docs_globals hook.
"""

import datetime

from vade import (
    Dual,
    Dual2,
    DiscountCurve,
    LineCurve,
    Solver,
    IRS,
    FRA,
    Deposit,
)


def pytest_markdown_docs_globals():
    """Inject common imports into getting-started code blocks."""
    return {
        "datetime": datetime,
        "Dual": Dual,
        "Dual2": Dual2,
        "DiscountCurve": DiscountCurve,
        "LineCurve": LineCurve,
        "Solver": Solver,
        "IRS": IRS,
        "FRA": FRA,
        "Deposit": Deposit,
    }
