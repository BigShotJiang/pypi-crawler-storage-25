# Vade — Product Roadmap

Features and development pipeline, organized by asset class and infrastructure layer. For technical documentation on shipped features, see the [main index](index.md).

**Status:** Available = production-ready | Planned = scoped for near-term delivery | Future = strategic roadmap

---

## Rates

| Status | Feature | Description | Key Capabilities |
|--------|---------|-------------|-----------------|
| Available | **Interest Rate Swaps** | Vanilla and structured IRS: fixed-float, basis, zero-coupon, OIS | IRS, FRA, ZCS, SBS, OIS with spec-driven construction, NPV, par rate, cashflow projection, spread analytics, delta/gamma via AD |
| Available | **Deposits & Futures** | Money market deposits and short-rate futures | Deposit rate/NPV, IR futures with convexity adjustment, pack/bundle aggregation |
| Available | **Caps & Floors** | Caplet/floorlet pricing under Black-76 and Bachelier (normal) models | NPV, implied vol inversion, vol surface construction, normal and lognormal pricing |
| Available | **Discount Curves** | Discount factor term structures with 10+ interpolation schemes | Log-linear, linear, flat forward/backward, monotone cubic, log-cubic, natural cubic, Hermite, convex monotone, cubic spline, linear zero; LineCurve for generic value curves |
| Available | **Forward Curves** | Native forward-rate representation with Gauss-Legendre quadrature | Forward rate node specification, automatic discount factor recovery via numerical integration |
| Available | **Parametric Curves** | Nelson-Siegel, Svensson, and Smith-Wilson term structure models | Analytical zero and instantaneous forward rates, closed-form calibration targets |
| Available | **Composite & Spread Curves** | Multi-curve layering and additive/multiplicative spread overlays | CompositeCurve (stacked), SpreadCurve (base + deterministic spread), TurnOfYearCurve (date-specific jump adjustments) |
| Available | **Curve Transforms** | Non-destructive curve manipulation operators | Parallel shift (bp), time translation, roll-down (theta decay) — applicable across all curve types |
| Available | **Multi-Curve & CSA Discounting** | Simultaneous OIS discounting and forecast curve construction | Iterative node-by-node bootstrap, multi-curve Jacobian calibration, pre-solver dependency chains |
| Available | **Solver & Calibration** | Jacobian-based multi-instrument curve fitting | Levenberg-Marquardt, Gauss-Newton, gradient descent; convergence tolerances, condition number monitoring |
| Available | **Risk Analytics** | Bucket-level sensitivities via automatic differentiation | IRImpliedCurve with user-defined tenor buckets, bucket delta, full AD propagation through the pricing stack |
| Available | **FX Implied Curves** | Cross-currency discount curves from FX forward markets | Interest rate parity-derived discount factors for cross-currency valuation |
| Planned | **Swaptions** | European and Bermudan swaption pricing | Payer/receiver NPV, delta/gamma via AD, expiry × tenor vol surface interpolation, cash and physical settlement |
| Future | **Structured Rate Notes** | Exotic coupon structures: range accruals, inverse floaters, snowballs | Path-dependent coupon evaluation, scenario analysis, rate curve and vol surface sensitivities |
| Future | **Bond Futures** | Exchange-traded bond delivery contracts | Forward pricing with carry and financing, CTD identification, gross/net basis, delivery option analytics |

## Credit

| Status | Feature | Description | Key Capabilities |
|--------|---------|-------------|-----------------|
| Available | **Fixed Rate Bonds** | Settlement-aware bond pricing with full analytics | NPV, dirty/clean price, YTM, Macaulay/modified duration, convexity, Z-spread, I-spread |
| Available | **Bills** | Discount instruments: T-bills, CP, CD | Discount yield, money market yield, settlement-adjusted pricing |
| Available | **Floating Rate Notes** | FRN with sub-period compounding and embedded optionality | FloatRateNote, SubPeriodFRN, CappedFloatRateNote with Black-76/Bachelier cap/floor valuation |
| Available | **Structured Bonds** | Non-vanilla fixed income: zero-coupon, step-up, amortizing, PIK | OID accrual (zeros), varying coupon schedules (step-up), declining notional (amortizing), in-kind compounding (PIK) |
| Available | **Callable Bonds** | Callable bond valuation via Hull-White trinomial lattice | OAS, effective duration/convexity, vega, arbitrary call schedule support |
| Available | **Asset Swaps** | Par and market-value asset swap spread analytics | Bond + swap decomposition, asset swap spread extraction |
| Available | **Credit Default Swaps** | Single-name CDS pricing with hazard rate bootstrapping | CDS NPV, par spread, survival probabilities, CreditImpliedCurve construction |
| Available | **Fitted Bond Curves** | Parametric curve fitting to observed bond prices via NLS | NS/NSS/Smith-Wilson models, Levenberg-Marquardt optimization, residual diagnostics |
| Future | **Credit Linked Notes** | Funded credit exposure via note wrapper | CLN pricing (credit + funding + recovery), recovery sensitivity, break-even spread vs unfunded CDS |
| Future | **Credit Index Options** | Options on CDX/iTraxx index spreads | Payer/receiver pricing, index spread vol, exercise into tranche, delta/gamma to index spread |
| Future | **Fixed Income ETFs** | Bond ETF analytics and creation/redemption mechanics | NAV premium/discount, effective duration/convexity, YTW, tracking error, creation basket composition |
| Future | **CLOs/ABS** | Structured credit with prepayment and default modeling | Pool-level cashflow projection, tranche yield/WAL/duration, CPR/CDR/severity scenario analysis |

## FX & FX Options

| Status | Feature | Description | Key Capabilities |
|--------|---------|-------------|-----------------|
| Available | **FX Rates & Forwards** | Spot rate graph with BFS triangulation and covered interest rate parity forwards | Cross-rate discovery, forward point calculation, outright forward rates |
| Available | **Cross-Currency Swaps** | MTM and non-MTM cross-currency basis swaps | MTM resets, notional exchange, multi-curve CSA-aware pricing |
| Available | **FX Forwards** | Outright FX forward contracts | NPV, forward points, settlement and value date handling |
| Available | **Non-Deliverable Instruments** | NDF, NDIRS, NDXCS for restricted EM currencies | Per-period FX conversion, 3-curve pricing framework, 5 EM calendars, 15 market convention specs |
| Available | **FX Implied Curves** | Discount curves bootstrapped from FX forward points | Cross-currency discounting via interest rate parity |
| Planned | **Full EMTA NDF Templates** | Complete EMTA-standard NDF templates across EM currency pairs | Construction from CCY pair alone, fixing source registry, settlement calendar integration |
| Future | **Vanilla FX Options & Vol Surface** | European FX option pricing and smile construction | Greeks, delta/premium-adjusted conventions, RR/BF quotes, ATM definitions, smile interpolation, vol cones |
| Future | **Vanilla Option Strategies** | Multi-leg vanilla structures | Spreads, risk reversals, straddles, strangles, butterflies, seagulls |
| Future | **First-Generation Exotics** | Single-asset path-dependent options | Barriers (KI/KO), digitals, touches, compounds, Asians, lookbacks, forward starts, cliquets, quantos |
| Future | **Second-Generation Exotics** | Advanced exotics and multi-asset structures | Corridors, faders, exotic barriers, pay-later, spread/exchange, basket, best/worst-of, var/vol swaps |
| Future | **Structured FX Forwards** | Forwards with embedded optionality | Participating, shark, accumulator, range accrual, knock-out, butterfly, boomerang, forward series |
| Future | **FX Structured Products** | Deposits, loans, swaps, and notes with FX-linked payoffs | Dual currency deposits, performance-linked structures, participation notes, hybrid FX products |

## Infrastructure, Portfolio & Risk

| Status | Feature | Description | Key Capabilities |
|--------|---------|-------------|-----------------|
| Available | **Automatic Differentiation** | Forward-mode AD via Dual and Dual2 number types | First-order (delta) and second-order (gamma) sensitivities; exact analytic gradients through the full pricing stack |
| Available | **Calendars & Scheduling** | Business day calendars, schedule generation, day count conventions | 15+ named calendars (NYC, LDN, TGT, TYO, etc.), 10 DCF conventions, stub handling, IMM date generation |
| Available | **Cashflow Engine** | Fixed and floating leg generation with period-level granularity | FixedLeg, FloatLeg, structured cashflow output via Polars DataFrames |
| Available | **Market Context** | Centralized market state container | Curves, FX rates, fixings; immutable functional API (.with_*()), solver integration, full JSON round-trip |
| Available | **JSON Serialization** | Complete round-trip serialization across the object model | Polymorphic curve envelope (11 types), instrument serialization, MarketContext persistence |
| Available | **Numerical Methods** | Root-finding and optimization primitives | Brent, Newton-Raphson; Black-76 and Bachelier closed-form models |
| Planned | **MCP Server** | Model Context Protocol server exposing Vade's pricing and analytics as tool endpoints for LLM agents | Curve construction, instrument pricing, risk analytics, and market data operations accessible via MCP; structured JSON request/response; composable tool definitions for multi-step workflows |
| Planned | **Agentic Workflow Integration** | LLM-orchestrated multi-step quantitative workflows via tool-use chains | Natural language-driven curve building, trade pricing, scenario analysis, and risk reporting; agent-composed pipelines across rates, credit, and FX; iterative calibration and what-if analysis through conversational interfaces |
| Planned | **Portfolio Valuation Engine** | Trade store, book hierarchy, and position management | Trade capture with audit trail, book/portfolio NPV aggregation, position lifecycle, bulk repricing |
| Planned | **Risk & PnL Engine** | Portfolio-level risk measures and PnL computation | Parametric and historical VaR, user-defined stress scenarios, daily/intraday PnL, risk limit monitoring |
| Planned | **PnL Explain** | Attribution of PnL into fundamental market and trade drivers | Carry/roll-down, curve decomposition (parallel/slope/curvature), trade activity effects, unexplained residual |

## Financing & Rates-Credit Hybrids

| Status | Feature | Description | Key Capabilities |
|--------|---------|-------------|-----------------|
| Future | **Repo** | Repurchase agreement pricing and collateral management | NPV, implied repo rate, margin call triggers, term and open repo support |
| Future | **Reverse Repo** | Cash-lending perspective, mirroring repo mechanics | Reverse repo yield, collateral eligibility, net position analysis |
| Future | **Securities Lending** | Fee accrual, collateral management, utilization tracking | Lending fee schedules, utilization rates, collateral coverage monitoring |
| Future | **Syndicated Loans** | Multi-lender term loans and revolvers | Cashflow projection, all-in yield with upfront/commitment/utilization fees, prepayment with make-whole |
| Future | **Bilateral Loans** | Single-lender facilities with flexible amortization profiles | NPV/YTM, duration/convexity, schedule generation (equal principal, annuity, bullet) |
| Future | **Total Return Swaps** | Synthetic total return exposure vs floating funding rate | TRS NPV (receiver/payer legs), return projection, funding accrual, basis risk decomposition |
| Future | **Bond Forwards** | Derivative based financing with funding curve adjustments | Forward clean price with carry/financing risk |

## XVA & Valuation Adjustments

| Status | Feature | Description | Key Capabilities |
|--------|---------|-------------|-----------------|
| Future | **Exposure Simulation Engine** | Monte Carlo portfolio revaluation for counterparty exposure profiling | EPE/ENE time profiles, netting set aggregation, path-dependent collateral simulation, multi-factor scenario generation |
| Future | **CSA & Collateral Modeling** | Credit Support Annex representation and collateral mechanics | Threshold/MTA/rounding, eligible collateral and haircut schedules, collateral interest accrual, rehypothecation |
| Future | **CVA/DVA** | Bilateral counterparty credit valuation adjustments | EPE/ENE × survival probability × LGD framework, CDS-implied hazard rates, wrong-way risk |
| Future | **FVA** | Funding valuation adjustment for uncollateralized exposures | Funding spread curves (repo, CP), secured vs unsecured exposure gap, bilateral FVA |
| Future | **MVA** | Margin valuation adjustment for IM/VM funding cost | SIMM-based IM calculation, IM path evolution, margin funding cost attribution, clearing vs bilateral |
| Future | **KVA** | Capital valuation adjustment for regulatory capital consumption | SA-CCR/IMM RWA, cost of equity hurdle rate, capital relief from collateral and central clearing |
| Future | **ColVA** | Collateral valuation adjustment for haircut and reinvestment drag | Haircut opportunity cost, reinvestment gap, collateral optionality, currency and asset-type effects |
| Future | **XVA Integration & Attribution** | Unified XVA framework with P&L explain | Total XVA = CVA + DVA + FVA + MVA + KVA + ColVA, XVA Greeks (spread delta, funding delta), bid-offer adjustment, XVA P&L attribution |
