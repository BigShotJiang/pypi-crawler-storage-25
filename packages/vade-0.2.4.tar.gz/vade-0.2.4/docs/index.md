# Vade

**Production-grade Fixed Income Quant Library with rates, credit and FX analytics for Python, powered by Rust.**

Vade brings institutional-quality fixed income analytics to Python. Built from the ground up in Rust and exposed through seamless PyO3 bindings, it delivers the performance of a compiled trading system with the ergonomics of a Python library.

______________________________________________________________________

### Why Vade?

- **Rust-powered performance** -- Native speed for curve building, calibration, and risk computation. No compromises.
- **Automatic differentiation** -- First- and second-order sensitivities (delta, gamma) computed exactly via dual numbers -- no finite differences, no numerical noise.
- **Full fixed income coverage** -- Interest rate swaps, bonds, CDS, FX forwards, caps & floors, callable bonds, and more.
- **Multi-curve calibration** -- Simultaneous bootstrap and fitting across discount, forecast, and credit curves.
- **Market context management** -- Bundle curves, FX rates, and fixings into a single serializable environment.
- **Zero Python overhead** -- All analytics execute in Rust. Python is the interface, not the bottleneck.

______________________________________________________________________

## Getting Started

Get vade installed and running in under 5 minutes.

- [Installation](getting-started/installation.md) -- Install vade and verify your setup

## Understanding Vade

Learn how vade works under the hood -- the Rust/Python architecture and the automatic differentiation type system that powers risk analytics.

- [Architecture](getting-started/architecture.md) -- Rust core, PyO3 bindings, max-Rust philosophy, and performance
- [Type System](getting-started/type-system.md) -- Dual/Dual2 automatic differentiation and Union return types

## API Reference

Complete parameter signatures, types, and working examples for every vade class and function.

- [API Reference](api/) -- Full API index with product sections and shared infrastructure

### By Product

- [Rates](api/rates/) -- Interest rate curves, instruments, and calibration
- [FX](api/fx/) -- FX rates, forwards, cross-currency, and non-deliverable instruments
- [Credit](api/credit/) -- Bonds, CDS, callable bonds, and spread analytics

### Shared Infrastructure

- [Calendar](api/calendar.md) -- Schedule generation, business day calendars, day count fractions, tenor arithmetic
- [Autodiff](api/autodiff.md) -- Dual and Dual2 automatic differentiation types
- [Numerical](api/numerical.md) -- Root-finding solvers (Brent, Newton-Raphson)
- [Context](api/context.md) -- MarketContext, FixingStore, and evaluation date management
- [Cashflows](api/cashflows.md) -- Fixed and floating leg cashflow generation

## Fundamentals

Core concepts that apply across all product areas.

- [Quick Start](guides/quick-start.md) -- Build a curve, price an instrument, and calibrate in one workflow
- [Market Context](guides/market-context.md) -- Build, query, and serialize a complete market environment
- [Serialization](guides/serialization.md) -- JSON round-trips for curves and instruments
- [Calibration](guides/calibration.md) -- Multi-curve calibration with Solver

## Rates

Interest rate curve construction, instrument pricing, risk analytics, and volatility products.

- [Overview](guides/rates/) -- Product introduction and key concepts
- [Curve Building](guides/rates/curve-building.md) -- Interpolation methods, curve types, and forward rate analysis
- [Bootstrap & Parametric Curves](guides/rates/bootstrap-parametric.md) -- Iterative bootstrap, Nelson-Siegel, NSS, Smith-Wilson
- [Pricing](guides/rates/pricing.md) -- Price IR instruments against calibrated curves
- [Risk](guides/rates/risk.md) -- Delta, gamma, and bucket-level sensitivities
- [Caps & Floors](guides/rates/capfloor.md) -- Black-76 and Bachelier pricing

## Credit

Bond analytics, credit default swaps, credit curve construction, and spread analysis.

- [Overview](guides/credit/) -- Product introduction and key concepts
- [Bonds](guides/credit/bonds.md) -- Bond analytics, duration, convexity, Z-spread
- [Callable Bonds](guides/credit/callable-bonds.md) -- Callable bond pricing with OAS
- [Credit Curves & CDS](guides/credit/credit-curves-cds.md) -- Credit curve construction and CDS pricing
- [Fitted Curves](guides/credit/fitted-curves.md) -- Parametric curve fitting to bond portfolios
- [Spread Analytics](guides/credit/spread-analytics.md) -- I-spread and asset swap analysis

## FX

FX spot rate triangulation, forward construction, cross-currency swaps, and non-deliverable instruments.

- [Overview](guides/fx/) -- Product introduction and key concepts
- [FX Rates & Forwards](guides/fx/fx-rates-forwards.md) -- FX rate triangulation and forward construction
- [Cross-Currency Swaps](guides/fx/cross-currency.md) -- Cross-currency swap pricing and risk
- [Non-Deliverable Instruments](guides/fx/non-deliverable.md) -- NDF and non-deliverable swap pricing

## Learning Paths

**New to Vade?** Start here:
[Installation](getting-started/installation.md) ->
[Architecture](getting-started/architecture.md) ->
[Type System](getting-started/type-system.md) ->
[Quick Start](guides/quick-start.md)

**Rates:**
[Curve Building](guides/rates/curve-building.md) ->
[Bootstrap & Parametric](guides/rates/bootstrap-parametric.md) ->
[Calibration](guides/calibration.md) ->
[Pricing](guides/rates/pricing.md) ->
[Risk](guides/rates/risk.md) ->
[Caps & Floors](guides/rates/capfloor.md)

**Credit:**
[Bonds](guides/credit/bonds.md) ->
[Credit Curves & CDS](guides/credit/credit-curves-cds.md) ->
[Spread Analytics](guides/credit/spread-analytics.md) ->
[Callable Bonds](guides/credit/callable-bonds.md) ->
[Fitted Curves](guides/credit/fitted-curves.md)

**FX:**
[FX Rates & Forwards](guides/fx/fx-rates-forwards.md) ->
[Cross-Currency Swaps](guides/fx/cross-currency.md) ->
[Non-Deliverable Instruments](guides/fx/non-deliverable.md)

**Market data management:**
[Market Context](guides/market-context.md) ->
[Serialization](guides/serialization.md)

## Roadmap

See [Roadmap](./roadmap.md) for planned features and milestones.

## Reference

Lookup tables for string enum values and parameter conventions used across the API.

- [Conventions](./conventions.md) -- String enum values for day counts, frequencies, interpolation methods, and more
