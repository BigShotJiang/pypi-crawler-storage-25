# Risk

Compute delta, gamma, and bucket-level risk sensitivities from calibrated curves using [automatic differentiation](../../getting-started/type-system.md). The [Solver](../../api/rates/solver.md#solver) provides AD-based delta and gamma, while [IRImpliedCurve](../../api/rates/curves.md#irimpliedcurve) offers tenor-bucketed risk reporting.

## Setup -- Calibrate with Labeled Instruments

Calibrate a [DiscountCurve](../../api/rates/curves.md#discountcurve) using the 5-tuple [instrument format](../../api/rates/solver.md#instruments-format). Labels are required for delta and gamma output to identify which calibrating instrument drives each sensitivity.

```python
import datetime
from vade import DiscountCurve, IRS, Solver

effective = datetime.date(2025, 6, 16)

nodes = {
    effective: 1.0,
    datetime.date(2026, 6, 16): 1.0,
    datetime.date(2027, 6, 16): 1.0,
    datetime.date(2028, 6, 16): 1.0,
    datetime.date(2030, 6, 16): 1.0,
    datetime.date(2035, 6, 16): 1.0,
}
curve = DiscountCurve(
    nodes, interpolation="log_linear", convention="act360", id="sofr"
)

irs_1y = IRS(effective=effective, termination="1Y", frequency="a", fixed_rate=4.00, convention="act360", float_convention="act360")
irs_2y = IRS(effective=effective, termination="2Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")
irs_3y = IRS(effective=effective, termination="3Y", frequency="a", fixed_rate=3.75, convention="act360", float_convention="act360")
irs_5y = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.70, convention="act360", float_convention="act360")
irs_10y = IRS(effective=effective, termination="10Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")

instruments = [
    (irs_1y, 4.00, 0, "1Y_IRS", "USD"),
    (irs_2y, 3.85, 0, "2Y_IRS", "USD"),
    (irs_3y, 3.75, 0, "3Y_IRS", "USD"),
    (irs_5y, 3.70, 0, "5Y_IRS", "USD"),
    (irs_10y, 3.85, 0, "10Y_IRS", "USD"),
]

solver = Solver(curves=[curve], instruments=instruments)
result = solver.iterate()
result.converged  # True
```

## Delta -- First-Order Sensitivities

Delta measures how an instrument's NPV changes per unit move in each calibration instrument rate. The solver uses first-order AD (Dual numbers) to compute exact analytic sensitivities without finite differences.

```python
import datetime
from vade import DiscountCurve, IRS, Solver

effective = datetime.date(2025, 6, 16)
nodes = {
    effective: 1.0,
    datetime.date(2026, 6, 16): 1.0,
    datetime.date(2027, 6, 16): 1.0,
    datetime.date(2028, 6, 16): 1.0,
    datetime.date(2030, 6, 16): 1.0,
    datetime.date(2035, 6, 16): 1.0,
}
curve = DiscountCurve(nodes, interpolation="log_linear", convention="act360", id="sofr")

irs_1y = IRS(effective=effective, termination="1Y", frequency="a", fixed_rate=4.00, convention="act360", float_convention="act360")
irs_2y = IRS(effective=effective, termination="2Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")
irs_3y = IRS(effective=effective, termination="3Y", frequency="a", fixed_rate=3.75, convention="act360", float_convention="act360")
irs_5y = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.70, convention="act360", float_convention="act360")
irs_10y = IRS(effective=effective, termination="10Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")

instruments = [
    (irs_1y, 4.00, 0, "1Y_IRS", "USD"),
    (irs_2y, 3.85, 0, "2Y_IRS", "USD"),
    (irs_3y, 3.75, 0, "3Y_IRS", "USD"),
    (irs_5y, 3.70, 0, "5Y_IRS", "USD"),
    (irs_10y, 3.85, 0, "10Y_IRS", "USD"),
]

solver = Solver(curves=[curve], instruments=instruments)
result = solver.iterate()

# Price a 5Y IRS slightly off-market
test_irs = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.80, convention="act360", float_convention="act360")

delta_df = solver.delta(test_irs, result)
delta_df.columns  # ['instrument_label', 'tenor', 'sensitivity', 'currency']
len(delta_df)  # 5
any(abs(s) > 1e-10 for s in delta_df["sensitivity"].to_list())  # True
```

## Portfolio Delta

Pass a list of instruments to compute aggregated portfolio-level delta. The solver sums sensitivities across all instruments in the list.

```python
import datetime
from vade import DiscountCurve, IRS, Solver

effective = datetime.date(2025, 6, 16)
nodes = {
    effective: 1.0,
    datetime.date(2026, 6, 16): 1.0,
    datetime.date(2027, 6, 16): 1.0,
    datetime.date(2028, 6, 16): 1.0,
    datetime.date(2030, 6, 16): 1.0,
    datetime.date(2035, 6, 16): 1.0,
}
curve = DiscountCurve(nodes, interpolation="log_linear", convention="act360", id="sofr")

irs_1y = IRS(effective=effective, termination="1Y", frequency="a", fixed_rate=4.00, convention="act360", float_convention="act360")
irs_2y = IRS(effective=effective, termination="2Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")
irs_3y = IRS(effective=effective, termination="3Y", frequency="a", fixed_rate=3.75, convention="act360", float_convention="act360")
irs_5y = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.70, convention="act360", float_convention="act360")
irs_10y = IRS(effective=effective, termination="10Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")

instruments = [
    (irs_1y, 4.00, 0, "1Y_IRS", "USD"),
    (irs_2y, 3.85, 0, "2Y_IRS", "USD"),
    (irs_3y, 3.75, 0, "3Y_IRS", "USD"),
    (irs_5y, 3.70, 0, "5Y_IRS", "USD"),
    (irs_10y, 3.85, 0, "10Y_IRS", "USD"),
]

solver = Solver(curves=[curve], instruments=instruments)
result = solver.iterate()

# Portfolio of two off-market swaps
port_irs1 = IRS(effective=effective, termination="3Y", frequency="a", fixed_rate=3.80, convention="act360", float_convention="act360")
port_irs2 = IRS(effective=effective, termination="7Y", frequency="a", fixed_rate=3.80, convention="act360", float_convention="act360")

portfolio_delta = solver.delta([port_irs1, port_irs2], result)
len(portfolio_delta)  # 5
portfolio_delta.columns  # ['instrument_label', 'tenor', 'sensitivity', 'currency']
```

## Gamma -- Second-Order Sensitivities

Gamma measures second-order (convexity) risk using Dual2 automatic differentiation. The result is a cross-gamma matrix showing how delta changes with respect to each calibrating instrument rate.

```python
import datetime
from vade import DiscountCurve, IRS, Solver

effective = datetime.date(2025, 6, 16)
nodes = {
    effective: 1.0,
    datetime.date(2026, 6, 16): 1.0,
    datetime.date(2027, 6, 16): 1.0,
    datetime.date(2028, 6, 16): 1.0,
    datetime.date(2030, 6, 16): 1.0,
    datetime.date(2035, 6, 16): 1.0,
}
curve = DiscountCurve(nodes, interpolation="log_linear", convention="act360", id="sofr")

irs_1y = IRS(effective=effective, termination="1Y", frequency="a", fixed_rate=4.00, convention="act360", float_convention="act360")
irs_2y = IRS(effective=effective, termination="2Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")
irs_3y = IRS(effective=effective, termination="3Y", frequency="a", fixed_rate=3.75, convention="act360", float_convention="act360")
irs_5y = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.70, convention="act360", float_convention="act360")
irs_10y = IRS(effective=effective, termination="10Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")

instruments = [
    (irs_1y, 4.00, 0, "1Y_IRS", "USD"),
    (irs_2y, 3.85, 0, "2Y_IRS", "USD"),
    (irs_3y, 3.75, 0, "3Y_IRS", "USD"),
    (irs_5y, 3.70, 0, "5Y_IRS", "USD"),
    (irs_10y, 3.85, 0, "10Y_IRS", "USD"),
]

solver = Solver(curves=[curve], instruments=instruments)
result = solver.iterate()

test_irs = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.80, convention="act360", float_convention="act360")

gamma_df = solver.gamma(test_irs, result)
"label" in gamma_df.columns  # True
len(gamma_df)  # 5
```

## Bucket-Level Risk

[IRImpliedCurve](../../api/rates/curves.md#irimpliedcurve) provides tenor-bucketed DV01 sensitivities by re-parameterizing a calibrated curve into standard tenor buckets. This gives a risk report aligned with market-standard tenor points.

```python
import datetime
import math
from vade import DiscountCurve, IRImpliedCurve, BusinessCalendar, FixedRateBond

effective = datetime.date(2024, 1, 1)

# Build a curve with known DFs for bucket risk
nodes = {effective: 1.0}
for y in range(1, 11):
    nodes[datetime.date(2024 + y, 1, 1)] = math.exp(-0.03 * y)

source = DiscountCurve(
    nodes, interpolation="log_linear", convention="act365f", id="test_curve"
)

cal = BusinessCalendar("NYC")
tenors = ["1Y", "2Y", "5Y", "10Y"]
implied = IRImpliedCurve(source, effective, tenors, cal)
implied.tenor_labels()  # ['0D', '1Y', '2Y', '5Y', '10Y']

float(implied.discount_factor(datetime.date(2025, 1, 1))) > 0.95  # True

bond = FixedRateBond(effective=effective, termination="5Y", coupon=0.04, frequency="s")
bucket_df = implied.bucket_delta(bond)
"tenor" in bucket_df.columns  # True
"delta" in bucket_df.columns  # True
any(abs(float(d)) > 1e-12 for d in bucket_df["delta"].to_list())  # True
```

## AAD Delta vs Analytical DV01

The [Solver](../../api/rates/solver.md#solver) and [FixedRateBond](../../api/credit/instruments.md#fixedratebond) offer two different sensitivity measures that answer different questions:

- **`Solver.delta(instrument, result)`** computes dNPV/dr_i via automatic differentiation, where r_i is each calibrating instrument rate. It answers: *"how does this instrument's NPV change per unit move in each curve-calibrating rate?"* The output is a per-instrument breakdown of curve risk.

- **`bond.dv01(curves)`** computes -dP/dy * 0.0001 via analytical formula. It answers: *"how does the bond's price change per 1 basis point parallel shift in yield?"* This is a single scalar measuring price-level yield sensitivity.

**The ~100x scaling difference with QuantLib:** `Solver.delta()` returns sensitivity per 1.0 rate move (units: NPV change per 100% rate shift). QuantLib's `BondFunctions::basisPointValue` reports at the price level per 100 face. On a bond with 100 face value, Vade's `Solver.delta()` on the dominant bucket gives roughly -4.5, while QuantLib reports roughly -445 -- the factor is notional/price scaling and the per-unit vs per-100bp convention. To compare directly, use `bond.dv01()` which matches QuantLib's `BondFunctions::basisPointValue` in magnitude.

| Method | What it computes | When to use | QuantLib equivalent |
|--------|-----------------|-------------|---------------------|
| `Solver.delta()` | AAD dNPV/dr per calibrating instrument | Curve risk, hedging ratios | BondFunctions::basisPointValue (but AD, not finite-diff) |
| `bond.dv01()` | Analytical -dP/dy per bp | Quick bond risk, P&L explain | BondFunctions::basisPointValue |
| `bond.duration()` | Curve-based modified/macaulay duration | Duration matching | BondFunctions::duration |
| `bond.convexity()` | Curve-based bond convexity | Convexity adjustment | BondFunctions::convexity |

The following example builds a 5-year bond on the same curve used above and compares both measures:

```python
import datetime
from vade import DiscountCurve, IRS, Solver, FixedRateBond

effective = datetime.date(2025, 6, 16)
nodes = {
    effective: 1.0,
    datetime.date(2026, 6, 16): 1.0,
    datetime.date(2027, 6, 16): 1.0,
    datetime.date(2028, 6, 16): 1.0,
    datetime.date(2030, 6, 16): 1.0,
    datetime.date(2035, 6, 16): 1.0,
}
curve = DiscountCurve(nodes, interpolation="log_linear", convention="act360", id="sofr")

irs_1y = IRS(effective=effective, termination="1Y", frequency="a", fixed_rate=4.00, convention="act360", float_convention="act360")
irs_2y = IRS(effective=effective, termination="2Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")
irs_3y = IRS(effective=effective, termination="3Y", frequency="a", fixed_rate=3.75, convention="act360", float_convention="act360")
irs_5y = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.70, convention="act360", float_convention="act360")
irs_10y = IRS(effective=effective, termination="10Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")

instruments = [
    (irs_1y, 4.00, 0, "1Y_IRS", "USD"),
    (irs_2y, 3.85, 0, "2Y_IRS", "USD"),
    (irs_3y, 3.75, 0, "3Y_IRS", "USD"),
    (irs_5y, 3.70, 0, "5Y_IRS", "USD"),
    (irs_10y, 3.85, 0, "10Y_IRS", "USD"),
]

solver = Solver(curves=[curve], instruments=instruments)
result = solver.iterate()
assert result.converged

calibrated = solver.get_curve(0)

bond = FixedRateBond(
    effective=effective, termination="5Y", coupon=0.04,
    frequency="s", convention="act360", face_value=100.0,
)

# AAD delta: per-instrument curve sensitivity (dNPV/dr_i)
delta_df = solver.delta(bond, result)
assert delta_df.columns == ["instrument_label", "tenor", "sensitivity", "currency"]
dominant = max(abs(s) for s in delta_df["sensitivity"].to_list())
assert dominant > 1.0  # largest bucket sensitivity is ~4.5

# Analytical DV01: price change per 1bp yield shift
dv01 = bond.dv01(calibrated)
assert 0.01 < dv01 < 1.0  # ~0.046 for a 5Y bond with 100 face

# Modified duration: percentage price change per 1% yield shift
duration = bond.duration(calibrated)
assert 3.0 < duration < 6.0  # ~4.5 for a 5Y semi-annual bond
```

## Gamma vs Convexity

`Solver.gamma()` and `bond.convexity()` measure different second-order effects:

- **`Solver.gamma(instrument, result)`** computes the cross-instrument gamma matrix d2NPV/(dr_i * dr_j) -- how delta with respect to one calibrating instrument changes as another calibrating rate moves. This is a matrix of curve-level second derivatives, useful for understanding non-linear curve risk and gamma hedging across tenors.

- **`bond.convexity(curves)`** computes d2P/dy2, the bond's price-yield convexity -- how the bond's duration itself changes as yields move. This is the standard bond convexity used in duration-convexity approximations.

These are entirely different quantities. QuantLib's `BondFunctions::convexity` returns bond convexity (e.g., ~23.6 for a 5Y bond), while Vade's `Solver.gamma()` returns cross-instrument second derivatives (values near zero like -0.003). Comparing them directly is meaningless.

**Use `Solver.gamma()` for:** cross-tenor gamma risk, gamma hedging portfolios, understanding non-linear curve exposure.

**Use `bond.convexity()` for:** duration-convexity price approximation, bond relative value, convexity-adjusted hedging.

```python
import datetime
from vade import DiscountCurve, IRS, Solver, FixedRateBond

effective = datetime.date(2025, 6, 16)
nodes = {
    effective: 1.0,
    datetime.date(2026, 6, 16): 1.0,
    datetime.date(2027, 6, 16): 1.0,
    datetime.date(2028, 6, 16): 1.0,
    datetime.date(2030, 6, 16): 1.0,
    datetime.date(2035, 6, 16): 1.0,
}
curve = DiscountCurve(nodes, interpolation="log_linear", convention="act360", id="sofr")

irs_1y = IRS(effective=effective, termination="1Y", frequency="a", fixed_rate=4.00, convention="act360", float_convention="act360")
irs_2y = IRS(effective=effective, termination="2Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")
irs_3y = IRS(effective=effective, termination="3Y", frequency="a", fixed_rate=3.75, convention="act360", float_convention="act360")
irs_5y = IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.70, convention="act360", float_convention="act360")
irs_10y = IRS(effective=effective, termination="10Y", frequency="a", fixed_rate=3.85, convention="act360", float_convention="act360")

instruments = [
    (irs_1y, 4.00, 0, "1Y_IRS", "USD"),
    (irs_2y, 3.85, 0, "2Y_IRS", "USD"),
    (irs_3y, 3.75, 0, "3Y_IRS", "USD"),
    (irs_5y, 3.70, 0, "5Y_IRS", "USD"),
    (irs_10y, 3.85, 0, "10Y_IRS", "USD"),
]

solver = Solver(curves=[curve], instruments=instruments)
result = solver.iterate()
assert result.converged

calibrated = solver.get_curve(0)

bond = FixedRateBond(
    effective=effective, termination="5Y", coupon=0.04,
    frequency="s", convention="act360", face_value=100.0,
)

# Cross-instrument gamma: d2NPV/(dr_i * dr_j) matrix
gamma_df = solver.gamma(bond, result)
assert "label" in gamma_df.columns
assert len(gamma_df) == 5  # one row per calibrating instrument

# Bond convexity: d2P/dy2 (standard bond convexity)
convexity = bond.convexity(calibrated)
assert convexity > 10.0  # ~23.6 for a 5Y semi-annual bond

# These are fundamentally different: gamma values are near zero (cross-derivatives),
# while convexity is a much larger number (price-yield curvature).
gamma_values = [gamma_df["5Y_IRS"][i] for i in range(len(gamma_df))]
assert max(abs(v) for v in gamma_values) < 1.0  # cross-gamma values are small
assert convexity > 10 * max(abs(v) for v in gamma_values)  # convexity >> gamma
```

## Next Steps

- [Calibration](../calibration.md) -- multi-curve frameworks and solver algorithm comparison
- [Curve Building](curve-building.md) -- interpolation methods and curve types
