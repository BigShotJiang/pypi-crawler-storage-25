"""Shared fixtures and globals for guide code block testing.

pytest-markdown-docs runs each code block independently. This conftest
injects common imports and a calibrated curve into every block's namespace
via the pytest_markdown_docs_globals hook.
"""

import datetime

import math

from vade import (
    DiscountCurve,
    ForwardCurve,
    IRS,
    FRA,
    ZCS,
    OIS,
    Deposit,
    LineCurve,
    Solver,
    FXRates,
    FXForwards,
    FXForward,
    XCS,
    CDS,
    CreditImpliedCurve,
    FixedRateBond,
    CapFloor,
    NelsonSiegel,
    NelsonSiegelSvensson,
    SmithWilson,
    bootstrap,
    Bill,
    FloatRateNote,
    SpreadCurve,
    CompositeCurve,
    ZeroCouponBond,
    StepUpBond,
    AmortizingBond,
    PIKBond,
    CappedFloatRateNote,
    AssetSwap,
    CallableBond,
    FittedBondCurve,
    NDF,
    NDIRS,
)

from vade import MarketContext, FixingStore
from vade import eval_date as vade_eval_date

try:
    from vade import NDXCS
except ImportError:
    NDXCS = None


def _build_calibrated():
    """Build the shared USD SOFR calibrated curve used across all guides."""
    effective = datetime.date(2025, 6, 16)

    nodes = {
        effective: 1.0,
        datetime.date(2025, 7, 16): 1.0,
        datetime.date(2025, 9, 16): 1.0,
        datetime.date(2025, 12, 16): 1.0,
        datetime.date(2026, 6, 16): 1.0,
        datetime.date(2027, 6, 16): 1.0,
        datetime.date(2028, 6, 16): 1.0,
        datetime.date(2030, 6, 16): 1.0,
        datetime.date(2032, 6, 16): 1.0,
        datetime.date(2035, 6, 16): 1.0,
    }

    curve = DiscountCurve(
        nodes, interpolation="log_linear", convention="act360", id="sofr"
    )

    dep_1m = Deposit(effective=effective, termination="1m", rate=0.0, convention="act360")
    fra_3m = FRA(effective=effective, termination="3m", fixed_rate=0.0, convention="act360")
    fra_6m = FRA(effective=effective, termination="6m", fixed_rate=0.0, convention="act360")
    irs_1y = IRS(effective=effective, termination="1y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_2y = IRS(effective=effective, termination="2y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_3y = IRS(effective=effective, termination="3y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_5y = IRS(effective=effective, termination="5y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_7y = IRS(effective=effective, termination="7y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_10y = IRS(effective=effective, termination="10y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")

    instruments = [
        (dep_1m, 0.0430),
        (fra_3m, 0.0425),
        (fra_6m, 0.0415),
        (irs_1y, 4.00),
        (irs_2y, 3.85),
        (irs_3y, 3.75),
        (irs_5y, 3.70),
        (irs_7y, 3.75),
        (irs_10y, 3.85),
    ]

    solver = Solver(curves=[curve], instruments=instruments)
    result = solver.iterate()
    calibrated = solver.get_curve(0)
    return solver, result, calibrated


_solver, _result, _calibrated = _build_calibrated()


def _build_fx_curves():
    """Build USD and EUR calibrated curves for FX guides."""
    effective = datetime.date(2025, 6, 16)

    usd_curve = DiscountCurve(
        {
            effective: 1.0,
            datetime.date(2025, 9, 16): 1.0,
            datetime.date(2026, 6, 16): 1.0,
            datetime.date(2027, 6, 16): 1.0,
            datetime.date(2028, 6, 16): 1.0,
            datetime.date(2030, 6, 16): 1.0,
        },
        interpolation="log_linear",
        convention="act360",
        id="usd",
    )

    dep_usd = Deposit(effective=effective, termination="3m", rate=0.0, convention="act360")
    irs_usd_1y = IRS(effective=effective, termination="1y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_usd_2y = IRS(effective=effective, termination="2y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_usd_3y = IRS(effective=effective, termination="3y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_usd_5y = IRS(effective=effective, termination="5y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")

    solver_usd = Solver(
        curves=[usd_curve],
        instruments=[
            (dep_usd, 0.0430),
            (irs_usd_1y, 4.10),
            (irs_usd_2y, 3.95),
            (irs_usd_3y, 3.85),
            (irs_usd_5y, 3.80),
        ],
    )
    result_usd = solver_usd.iterate()
    assert result_usd.converged
    usd_curve = solver_usd.get_curve(0)

    eur_curve = DiscountCurve(
        {
            effective: 1.0,
            datetime.date(2025, 9, 16): 1.0,
            datetime.date(2026, 6, 16): 1.0,
            datetime.date(2027, 6, 16): 1.0,
            datetime.date(2028, 6, 16): 1.0,
            datetime.date(2030, 6, 16): 1.0,
        },
        interpolation="log_linear",
        convention="act360",
        id="eur",
    )

    dep_eur = Deposit(effective=effective, termination="3m", rate=0.0, convention="act360")
    irs_eur_1y = IRS(effective=effective, termination="1y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_eur_2y = IRS(effective=effective, termination="2y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_eur_3y = IRS(effective=effective, termination="3y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_eur_5y = IRS(effective=effective, termination="5y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")

    solver_eur = Solver(
        curves=[eur_curve],
        instruments=[
            (dep_eur, 0.0350),
            (irs_eur_1y, 3.20),
            (irs_eur_2y, 3.10),
            (irs_eur_3y, 3.05),
            (irs_eur_5y, 3.00),
        ],
    )
    result_eur = solver_eur.iterate()
    assert result_eur.converged
    eur_curve = solver_eur.get_curve(0)

    fxr = FXRates(fx_rates={"eurusd": 1.08, "gbpusd": 1.27, "usdjpy": 149.50}, settlement=effective)
    fxf = FXForwards(fx_rates=fxr, settlements={"usd": effective, "eur": effective})

    return usd_curve, eur_curve, fxr, fxf


def _build_credit_curves():
    """Build credit and discount curves for credit guides."""
    effective = datetime.date(2025, 6, 16)

    credit_curve = CreditImpliedCurve(
        {
            effective: 0.01,
            datetime.date(2026, 6, 16): 0.012,
            datetime.date(2028, 6, 16): 0.015,
            datetime.date(2030, 6, 16): 0.018,
        },
        convention="act360",
        recovery_rate=0.4,
    )

    disc_curve = DiscountCurve(
        {
            effective: 1.0,
            datetime.date(2026, 6, 16): 1.0,
            datetime.date(2028, 6, 16): 1.0,
            datetime.date(2030, 6, 16): 1.0,
            datetime.date(2035, 6, 16): 1.0,
        },
        interpolation="log_linear",
        convention="act360",
        id="disc",
    )

    dep = Deposit(effective=effective, termination="1y", rate=0.0, convention="act360")
    irs_3y = IRS(effective=effective, termination="3y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_5y = IRS(effective=effective, termination="5y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")
    irs_10y = IRS(effective=effective, termination="10y", frequency="a", fixed_rate=0.0, convention="act360", float_convention="act360")

    solver_disc = Solver(
        curves=[disc_curve],
        instruments=[
            (dep, 0.0400),
            (irs_3y, 3.80),
            (irs_5y, 3.75),
            (irs_10y, 3.85),
        ],
    )
    result_disc = solver_disc.iterate()
    assert result_disc.converged
    disc_curve = solver_disc.get_curve(0)

    return credit_curve, disc_curve


_usd_curve, _eur_curve, _fxr, _fxf = _build_fx_curves()
_credit_curve, _disc_curve = _build_credit_curves()


def pytest_markdown_docs_globals():
    """Inject shared state into every markdown code block."""
    return {
        "datetime": datetime,
        "DiscountCurve": DiscountCurve,
        "ForwardCurve": ForwardCurve,
        "LineCurve": LineCurve,
        "IRS": IRS,
        "FRA": FRA,
        "ZCS": ZCS,
        "OIS": OIS,
        "Deposit": Deposit,
        "Solver": Solver,
        # Phase 17 imports
        "FXRates": FXRates,
        "FXForwards": FXForwards,
        "FXForward": FXForward,
        "XCS": XCS,
        "CDS": CDS,
        "CreditImpliedCurve": CreditImpliedCurve,
        "FixedRateBond": FixedRateBond,
        "CapFloor": CapFloor,
        "NelsonSiegel": NelsonSiegel,
        "NelsonSiegelSvensson": NelsonSiegelSvensson,
        "SmithWilson": SmithWilson,
        "bootstrap": bootstrap,
        "Bill": Bill,
        "FloatRateNote": FloatRateNote,
        "SpreadCurve": SpreadCurve,
        "CompositeCurve": CompositeCurve,
        # Phase 26 imports
        "ZeroCouponBond": ZeroCouponBond,
        "StepUpBond": StepUpBond,
        "AmortizingBond": AmortizingBond,
        "PIKBond": PIKBond,
        "CappedFloatRateNote": CappedFloatRateNote,
        "AssetSwap": AssetSwap,
        "CallableBond": CallableBond,
        "FittedBondCurve": FittedBondCurve,
        # Phase 30 imports
        "NDF": NDF,
        "NDIRS": NDIRS,
        "NDXCS": NDXCS,
        "math": math,
        # Phase 35 imports
        "MarketContext": MarketContext,
        "FixingStore": FixingStore,
        "vade_eval_date": vade_eval_date,
        # Pre-built shared state
        "effective": datetime.date(2025, 6, 16),
        "calibrated": _calibrated,
        "_solver": _solver,
        "_result": _result,
        # Pre-built FX state
        "usd_curve": _usd_curve,
        "eur_curve": _eur_curve,
        "fxr": _fxr,
        "fxf": _fxf,
        # Pre-built credit state
        "credit_curve": _credit_curve,
        "disc_curve": _disc_curve,
    }
