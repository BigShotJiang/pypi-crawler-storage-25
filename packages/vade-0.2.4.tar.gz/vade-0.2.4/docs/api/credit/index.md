# Credit API Reference

Complete API reference for credit analytics: bonds, credit derivatives, and spread analysis.

---

## Pages

- [Instruments](./instruments.md) -- FixedRateBond, Bill, FloatRateNote, SubPeriodFRN, ZeroCouponBond, StepUpBond, AmortizingBond, PIKBond, CappedFloatRateNote, AssetSwap, CallableBond, CDS
- [Curves](../rates/curves.md) -- CreditImpliedCurve, FittedBondCurve, SpreadCurve

## See Also

- [Credit Guides](../../guides/credit/) -- Bond analytics, CDS pricing, fitted curves, and spread analysis guides
