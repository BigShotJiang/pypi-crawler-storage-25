# FX API Reference

Complete API reference for FX analytics: spot/forward rates, cross-currency instruments, and non-deliverable products.

---

## Pages

- [Instruments](./instruments.md) -- XCS, FXForward, NDF, NDIRS, NDXCS
- [FX Rates & Forwards](./fx-rates.md) -- FXRates, FXForwards, FXPair
- [Curves](../rates/curves.md) -- FXImpliedCurve

## See Also

- [FX Rates & Forwards Guide](../../guides/fx/fx-rates-forwards.md) -- FX rate triangulation and forward construction
- [Cross-Currency Swaps Guide](../../guides/fx/cross-currency.md) -- Cross-currency swap pricing and risk
- [Non-Deliverable Instruments Guide](../../guides/fx/non-deliverable.md) -- NDF and non-deliverable swap pricing for restricted currencies
- [Context](../context.md) -- MarketContext with fx_rates for cross-currency pricing
- [Solver](../rates/solver.md) -- Multi-curve calibration with FX rate support
