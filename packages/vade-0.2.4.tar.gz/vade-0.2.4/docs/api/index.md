# API Reference

Complete parameter signatures, types, and working examples for every vade class and function.

---

## Product Sections

- [Rates](./rates/) -- Interest rate curves, instruments, and calibration
- [FX](./fx/) -- FX rates, forwards, cross-currency, and non-deliverable instruments
- [Credit](./credit/) -- Bonds, CDS, callable bonds, and spread analytics

## Shared Infrastructure

- [Calendar](./calendar.md) -- Schedule generation, business day calendars, day count fractions, tenor arithmetic
- [Autodiff](./autodiff.md) -- Dual and Dual2 automatic differentiation types
- [Numerical](./numerical.md) -- Root-finding solvers (Brent, Newton-Raphson)
- [Context](./context.md) -- MarketContext, FixingStore, and evaluation date management
- [Cashflows](./cashflows.md) -- Fixed and floating leg cashflow generation
