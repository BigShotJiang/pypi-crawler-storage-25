# Rates API Reference

Complete API reference for interest rate analytics: curve construction, instrument pricing, and multi-curve calibration.

---

## Pages

- [Instruments](./instruments.md) -- IRS, FRA, ZCS, SBS, OIS, Deposit, IRFuture, CapFloor
- [Curves](./curves.md) -- DiscountCurve, LineCurve, ForwardCurve, CompositeCurve, SpreadCurve, TurnOfYearCurve, IRImpliedCurve, FXImpliedCurve, CreditImpliedCurve, FittedBondCurve, NelsonSiegel, NelsonSiegelSvensson, SmithWilson
- [Solver](./solver.md) -- Multi-curve calibration, bootstrap, Levenberg-Marquardt solver

## See Also

- [Rates Guides](../../guides/rates/) -- Curve building, pricing, risk, and cap/floor guides
