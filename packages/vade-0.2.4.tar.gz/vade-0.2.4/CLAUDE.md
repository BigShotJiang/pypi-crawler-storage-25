<!-- GSD:project-start source:PROJECT.md -->
## Project

**Vade**

A production-grade fixed income quantitative library with a Rust core and Python API. Vade provides curve construction, instrument pricing (IRS, OIS, bonds, CDS, FX), risk analytics (DV01, duration, Greeks via AAD), and cashflow generation for quant desks and systematic trading. Built with PyO3/maturin for C-level performance with Python ergonomics.

**Core Value:** Correct, production-grade pricing and risk numbers that match industry-standard QuantLib — users must be able to trust the numbers for live trading.

### Constraints

- **Tech stack**: Rust core + Python bindings via PyO3/maturin — no pure-Python computation
- **Compatibility**: Python 3.11+ (ABI3 stable API)
- **Performance**: Numerical changes must not regress performance on existing benchmarks
- **Backward compat**: Existing API signatures preserved — new parameters must be optional with defaults matching current behavior
<!-- GSD:project-end -->

<!-- GSD:stack-start source:codebase/STACK.md -->
## Technology Stack

## Languages
- Rust 2021 edition - Core quantitative finance engine and algorithms
- Python 3.11+ - User-facing API and orchestration layer
- YAML - GitHub Actions CI/CD configuration
## Runtime
- CPython 3.11, 3.12, 3.13 - Supported Python versions (requires >= 3.11)
- uv - Fast Python package and project manager
- Cargo - Rust package manager
- Lockfile: `uv.lock` (Python), `Cargo.lock` (Rust) - both present
## Frameworks
- PyO3 0.28.3 - Python bindings for Rust code via Cython-like FFI
- Maturin 1.0-<2.0 - Build tool and Python packaging system for PyO3 projects
- NumPy 2.0+ - Python array operations; Rust numpy 0.28 bindings
- Polars 1.39+ - DataFrame library for risk output and cashflow analysis
- pandas 2.2+ - DataFrame support for integration and data export
- ndarray 0.17 - Dense n-dimensional array computing in Rust
- statrs 0.18 - Statistical distribution functions (Normal CDF used in option pricing)
- itertools 0.14 - Iterator utilities for Rust sequences
- serde 1.0 - Serialization framework for Rust structures
- serde_json 1.0 - JSON encoding/decoding for curves, solver state, market contexts
- chrono 0.4.44 - Date arithmetic, scheduling, day count conventions (Rust)
- iana-time-zone - Timezone support via IANA database
- pytest-markdown-docs 0.9.2+ - Run Python examples from docstrings as tests
- pytest - Python test runner (configuration in `pyproject.toml`)
- auto_ops 0.3 - Operator overloading macros for Dual types (automatic differentiation)
- num-traits 0.2 - Numeric trait implementations for generic math operations
## Key Dependencies
- PyO3 0.28.3 - Enables Python/Rust interop; ABI3 mode for stable API across Python versions (abi3-py311 feature)
- Maturin - Build system; compiles Rust to binary wheels for distribution on PyPI
- NumPy 2.0+ - Required by user code; bindings integrated via `numpy` crate 0.28
- ndarray 0.17 with serde - Core numerical arrays; serialization support for JSON roundtripping
- chrono 0.4 with serde - Date handling and calendar logic; serializable for market context persistence
- serde_json 1.0 - Enables JSON import/export of curves and solver configuration
- statrs 0.18 - Provides Normal distribution CDF for cap/floor and option valuation
- Polars 1.39+ - User-facing API returns risk Greeks as Polars DataFrames (preferred over pandas)
- pandas 2.2+ - Fallback DataFrame export for compatibility
## Configuration
- No external env variables required for core functionality
- Build config: Maturin handles Python version detection and wheel compilation
- Runtime config: MarketContext object bundles curves, fixings, FX rates, and calendars
- `pyproject.toml` - Python package metadata, dependencies, test config
- `Cargo.toml` - Rust dependencies, lib target configuration (`crate-type = ["cdylib"]`)
- `Cargo.lock` - Locked Rust dependency versions
- `uv.lock` - Locked Python dependency versions
- `.mdformat.toml` - Markdown formatting (no-wrap, LF line endings)
- `.github/workflows/publish.yml` - PyPI distribution pipeline
## Platform Requirements
- Rust toolchain 1.70+ (MSRV not explicitly set but implied by PyO3 0.28)
- Python 3.11-3.13
- C compiler (cc crate dependency for build scripts)
- macOS, Linux (x86_64, aarch64), Windows (x64) supported
- Pre-built wheels distributed via PyPI for Python 3.11-3.13
- Targets: Linux x86_64/aarch64, macOS x86_64/ARM64 (Apple Silicon), Windows x64
- Source distribution (sdist) available for custom compilation
- ABI3 stable interface (abi3-py311) allows wheels to work across Python 3.11+
## Build Artifacts
- `_vade_rs.abi3.so` (Linux/macOS) or `.pyd` (Windows) - Main Rust extension module
- Compiled with `-r` (release optimizations) for production wheels
- `vade._vade_rs.autodiff` - Dual number automatic differentiation
- `vade._vade_rs.calendar` - Business calendars and schedules
- `vade._vade_rs.curves` - Discount curves and interpolation
- `vade._vade_rs.cashflows` - Fixed and floating leg generation
- `vade._vade_rs.instruments` - Rates, bonds, credit, FX pricing
- `vade._vade_rs.solver` - Curve calibration and risk computation
- `vade._vade_rs.fx` - FX rates and triangulation
- `vade._vade_rs.numerical` - Root finders (Brent, Newton-Raphson)
## External Build Dependencies
- `pyo3` ecosystem (pyo3-ffi, pyo3-macros, pyo3-build-config)
- `chrono` ecosystem (iana-time-zone for platform-specific timezone data)
- Standard utilities: `indexmap` (ordered dict), `approx` (float comparisons), `getrandom` (entropy)
<!-- GSD:stack-end -->

<!-- GSD:conventions-start source:CONVENTIONS.md -->
## Conventions

## Naming Patterns
- Python: lowercase with underscores (`context.py`, `fixings.py`, `_helpers.py`)
- Rust: lowercase with underscores (`convention.rs`, `curve.rs`, `mod.rs`)
- Test files: `test_*.py` pattern (e.g., `test_bonds.py`, `test_dual.py`)
- Private/internal modules: prefix with underscore (`_helpers.py`, `_vade_rs` package)
- Python: snake_case for all functions
- Rust: snake_case for all functions and methods
- Python: snake_case for all variables and parameters
- Rust: snake_case for all variables
- Python: PascalCase for all classes and types
- Rust: PascalCase for structs, enums, traits
- Python/Rust: UPPER_SNAKE_CASE for module-level constants (not observed extensively, but standard)
## Code Style
- Python: PEP 8 style is followed
- Markdown: `.mdformat.toml` specifies `wrap = "no"` and `end_of_line = "lf"`
- No `.rustfmt.toml` or `.eslintrc` observed; standard Rust edition 2021 conventions apply
- No ESLint, Prettier, or Clippy configs detected in root
- Python code uses standard PEP 8 patterns observed in source
- Rust code compiles with standard `cargo build` (no special linting setup visible)
- Python: Groups observed in source files:
- Rust: Groups observed:
- Python: Flat namespace imports encouraged
- Rust: Module paths used directly via `use crate::...`
## Error Handling
- Rust: Returns `Result<T, String>` for fallible operations
- Python: Explicit exception raising observed
## Logging
- Python: Could use `print()` or explicit logging if added
- Rust: No slog/tracing observed; error handling through `Result` types
- Errors are explicit and returned/raised, not logged
- Test validation via assertions, not logs
## Comments
- Module-level: Always include docstring (observed in all test files)
- Function-level: Doc comments for public APIs
- Python uses NumPy/SciPy docstring style (observed in `context.py`)
- Rust uses standard doc comments with examples in some cases
## Function Design
- Python test functions: 1-15 lines typically
- Rust computation functions: 10-50 lines
- No god functions observed
- Python: Keyword arguments with type hints throughout
- Rust: Explicit struct members, no keyword args (not applicable in Rust)
- Python: Single return value or tuple, never implicit None
- Rust: Uses `Option<T>` and `Result<T, E>` for error handling
## Module Design
- Python: All public types/functions listed in `__all__` at module level
- Rust: `pub` keyword for public items, module re-exports via `pub use`
- Python: Yes, `__init__.py` files act as barrels
- Rust: Yes, `mod.rs` files aggregate submodules
## Type Hints
- Full type hints on all functions and methods observed
- Uses modern Python 3.11+ syntax:
- Type hints required and explicit on all public functions
- Generic parameters used where appropriate (e.g., `Interpolator`, `Number` for autodiff types)
## Code Organization Principles
- Pure calculation logic in Rust (no I/O, no Python dependencies)
- Python bindings isolated in `py.rs` modules
- Python-specific features (fixtures, context managers) in Python files only
<!-- GSD:conventions-end -->

<!-- GSD:architecture-start source:ARCHITECTURE.md -->
## Architecture

## Pattern Overview
- **Dual-language design**: Rust core (`rust/`) compiles to a single extension module (`_vade_rs`), exposed through Python wrappers
- **Domain-driven modules**: Separated by financial domain (curves, instruments, solver, cashflows)
- **Lazy binding**: Rust submodules registered via PyO3 and re-exported in Python for transparent access
- **Spec-driven construction**: Instruments built via spec templates (market convention bundles) merged with user overrides
- **AD-based solver**: Automatic differentiation drives Jacobian extraction for curve calibration
- **Multi-currency support**: XCS (cross-currency swaps) and FX instruments use 4-curve models when needed
## Layers
- Location: `rust/`
- Purpose: High-performance fixed-income calculations, curve interpolation, autodiff, solver
- Contains: Instrument pricing, curve node management, cashflow generation, root finding
- Depends on: ndarray, chrono, num-traits, pyo3
- Used by: Python API layer via PyO3 bindings
- Location: `rust/*/py.rs` files in each Rust module
- Purpose: PyO3 class definitions (`Py*` classes) that wrap Rust structs
- Contains: `PyInterestRateSwap`, `PyDiscountCurve`, `PySolver`, etc.
- Depends on: Rust core module, pyo3
- Used by: Python wrapper layer
- Location: `python/vade/`
- Purpose: User-facing API with spec support, curve resolution, convenience methods
- Contains: `InterestRateSwap`, `DiscountCurve`, `Solver` (wrapper classes)
- Depends on: Rust bindings (`vade._vade_rs`), numpy, pandas, polars
- Exposed via: Top-level `vade` package
- Location: `rust/marketcurves/`, `python/vade/marketcurves/`
- Purpose: Discount curves, parametric curves (Nelson-Siegel, Smith-Wilson), fitted curves
- Supports: Linear interpolation, log-linear, parametric fits, spread curves, FX-implied curves
- Depends on: Curve nodes, interpolation methods, bond instruments (for fitted curves)
- Location: `rust/instruments/{rates,fx,credit}/`, `python/vade/instruments/`
- Purpose: Compute par rates, NPV, risk (DV01), and cashflows for derivatives and bonds
- Contains: IRS, FRA, ZCS, SBS, OIS, Deposit, Bonds, CDS, XCS, NDF, etc.
- Depends on: Cashflows module, curves, solver (for bond pricing)
- Location: `rust/cashflows/`, `python/vade/cashflows/`
- Purpose: Generate period-by-period cashflows with accrual, fixing, and discounting
- Contains: Fixed and floating legs, period generation, compounding methods
- Supports: RFR payment delay, In-Arrears, BBA LIBOR, multiple calendars
- Exposes: Polars/Pandas DataFrames for analysis
- Location: `rust/solver/`, `python/vade/solver/`
- Purpose: Calibrate curve nodes to match instrument target rates
- Algorithms: Levenberg-Marquardt (default), Gauss-Newton, Gradient Descent
- Uses: Automatic differentiation for Jacobian extraction
- Outputs: SolverResult with convergence diagnostics, Jacobian, residuals, condition number
- Location: `rust/autodiff/`, `python/vade/autodiff/`
- Purpose: First- and second-order automatic differentiation
- Types: `Dual` (forward-mode AD), `Dual2` (second derivative)
- Used by: Solver for sensitivity computation, risk calculations
- **Calendar & Scheduling** (`rust/calendar/`, `python/vade/calendar/`): Business day conventions, schedules, day-count fractions
- **Numerical Methods** (`rust/numerical/`, `python/vade/numerical/`): Brent root finding, Newton-Raphson
- **Context & Fixings** (`python/vade/context.py`, `python/vade/fixings.py`): Thread-local market context, historical fixing store
- **Market Data Registries** (`python/vade/instruments/specs/`): Instrument spec templates (usd_irs, euribor_6m_irs, etc.)
## Data Flow
- **Curve state**: Immutable Rust curve objects with node values as floats (or Duals during AD)
- **Instrument state**: Spec merged with user overrides, stored in Python wrappers
- **Market context**: Thread-local context variable holds current MarketContext (curves, fixings, eval_date)
- **Fixing store**: In-memory dict mapping (index, date) → rate for historical rates
## Key Abstractions
- Purpose: Abstract discount factor lookup by tenor or date
- Implementations: DiscountCurve (raw nodes), LineCurve (bootstrapped), CreditImpliedCurve, ForwardCurve, SmithWilson, NelsonSiegel, SmithWilson, SpreadCurve, ComputedCurve, CompositeCurve
- Used by: Instruments for discounting, forward rate lookup, spread adjustments
- Purpose: Unified dispatch for pricing across all product types
- Variants: IRS, FRA, ZCS, SBS, OIS, Deposit, IRFuture, Bond, CDS, XCS, FXForward, AssetSwap, CallableBond, NDF, NDIRS, NDXCS
- Methods: `rate()`, `npv()`, `cashflows()`, `delta()`
- Files: `rust/instruments/mod.rs` line 46-65
- Purpose: Type-erased reference to solver-owned curves during calibration
- Variants: Discount, Line, CreditImplied, Forward
- Used by: Solver to manage heterogeneous curve types
- Files: `rust/solver/mod.rs` line 23-112
- Purpose: Binding of instrument + target rate + curve indices for solver
- Fields: instrument, target, disc_curve_idx, forecast_curve_idx, label, currency, leg2 indices
- Files: `rust/solver/mod.rs` line 114-129
- Each Rust-exported class has a Python wrapper (e.g., `InterestRateSwap` wraps `PyInterestRateSwap`)
- Wrapper adds spec merging, curve resolution from context, convenience methods
- Example: `python/vade/instruments/rates.py` line 26-150
## Entry Points
- Location: `rust/lib.rs`
- Triggers: Build via maturin (Python package build time)
- Responsibilities: Registers all PyO3 submodules (autodiff, calendar, curves, cashflows, instruments, solver, fx, numerical) into `_vade_rs` extension module
- Location: `python/vade/__init__.py`
- Triggers: Import `vade` or submodules
- Responsibilities:
- Location: `python/tests/`
- Runs via: `pytest` with `pyproject.toml` configuration
- Includes: Integration tests for curves, instruments, solver, autodiff, cashflows, risk
- Fixtures: `conftest.py` defines Dual/Dual2 fixtures and markdown doc globals
## Error Handling
- Python validators check dates, rates, curve consistency before passing to Rust
- Rust functions use `Result<T, PyErr>` for error propagation through PyO3
- Solver checks for singular Jacobian, NaN objectives, detects non-convergence
- Curve queries raise ValueError if extrapolating beyond grid
- `python/vade/instruments/_helpers.py`: `_parse_termination()` validates tenor format
- `rust/solver/mod.rs`: Convergence checks, damping strategy selection
- `rust/marketcurves/curve.rs`: Bounds checking on interpolation requests
## Cross-Cutting Concerns
- Python layer: Date range, currency codes, notional > 0, rate bounds
- Rust layer: Curve interpolation bounds, instrument construction preconditions
<!-- GSD:architecture-end -->

<!-- GSD:workflow-start source:GSD defaults -->
## GSD Workflow Enforcement

Before using Edit, Write, or other file-changing tools, start work through a GSD command so planning artifacts and execution context stay in sync.

Use these entry points:
- `/gsd:quick` for small fixes, doc updates, and ad-hoc tasks
- `/gsd:debug` for investigation and bug fixing
- `/gsd:execute-phase` for planned phase work

Do not make direct repo edits outside a GSD workflow unless the user explicitly asks to bypass it.
<!-- GSD:workflow-end -->



<!-- GSD:profile-start -->
## Developer Profile

> Profile not yet configured. Run `/gsd:profile-user` to generate your developer profile.
> This section is managed by `generate-claude-profile` -- do not edit manually.
<!-- GSD:profile-end -->
