"""
Fixing index definitions for interest rate indices.

Provides a registry of RFR (risk-free rate) and IBOR (interbank offered rate)
indices with their market conventions (tenor, day count, calendar, currency).

Index names are used as keys throughout vade -- in instrument specs, fixings
registry, and curve construction.
"""

from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# Index Registry
# ---------------------------------------------------------------------------

INDEX_REGISTRY: dict[str, dict[str, Any]] = {
    # -----------------------------------------------------------------------
    # RFR (Risk-Free Rate) indices
    # -----------------------------------------------------------------------
    "SOFR": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act360",
        "calendar": "nyc",
        "currency": "usd",
        "description": "Secured Overnight Financing Rate",
    },
    "SONIA": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act365f",
        "calendar": "ldn",
        "currency": "gbp",
        "description": "Sterling Overnight Index Average",
    },
    "ESTR": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act360",
        "calendar": "tgt",
        "currency": "eur",
        "description": "Euro Short-Term Rate",
    },
    "TONAR": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act365f",
        "calendar": "tyo",
        "currency": "jpy",
        "description": "Tokyo Overnight Average Rate",
    },
    "SARON": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act360",
        "calendar": "zur",
        "currency": "chf",
        "description": "Swiss Average Rate Overnight",
    },
    "AONIA": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act365f",
        "calendar": "syd",
        "currency": "aud",
        "description": "AUD Overnight Index Average",
    },
    "CORRA": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act365f",
        "calendar": "tro",
        "currency": "cad",
        "description": "Canadian Overnight Repo Rate Average",
    },
    "SWESTR": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act360",
        "calendar": "stk",
        "currency": "sek",
        "description": "Swedish krona Short-Term Rate",
    },
    "NOWA": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act365f",
        "calendar": "osl",
        "currency": "nok",
        "description": "Norwegian Overnight Weighted Average",
    },
    "NZONIA": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act365f",
        "calendar": "wlg",
        "currency": "nzd",
        "description": "NZD Official Cash Rate",
    },
    "DESTR": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act360",
        "calendar": "cph",
        "currency": "dkk",
        "description": "Denmark Short-Term Rate",
    },

    # -----------------------------------------------------------------------
    # FX indices (D-09)
    # -----------------------------------------------------------------------
    "EURUSD": {
        "type": "fx",
        "base": "eur",
        "quote": "usd",
        "settlement_lag": 2,
        "calendar": "nyc,tgt",
        "description": "EUR/USD spot FX rate",
    },
    "USDJPY": {
        "type": "fx",
        "base": "usd",
        "quote": "jpy",
        "settlement_lag": 2,
        "calendar": "nyc,tyo",
        "description": "USD/JPY spot FX rate",
    },
    "GBPUSD": {
        "type": "fx",
        "base": "gbp",
        "quote": "usd",
        "settlement_lag": 2,
        "calendar": "nyc,ldn",
        "description": "GBP/USD spot FX rate",
    },
    "USDCAD": {
        "type": "fx",
        "base": "usd",
        "quote": "cad",
        "settlement_lag": 1,
        "calendar": "nyc",
        "description": "USD/CAD spot FX rate",
    },
    "AUDUSD": {
        "type": "fx",
        "base": "aud",
        "quote": "usd",
        "settlement_lag": 2,
        "calendar": "nyc,syd",
        "description": "AUD/USD spot FX rate",
    },
    "USDCHF": {
        "type": "fx",
        "base": "usd",
        "quote": "chf",
        "settlement_lag": 2,
        "calendar": "nyc,zur",
        "description": "USD/CHF spot FX rate",
    },
    "USDNOK": {
        "type": "fx",
        "base": "usd",
        "quote": "nok",
        "settlement_lag": 2,
        "calendar": "nyc,osl",
        "description": "USD/NOK spot FX rate",
    },
    "USDSEK": {
        "type": "fx",
        "base": "usd",
        "quote": "sek",
        "settlement_lag": 2,
        "calendar": "nyc,stk",
        "description": "USD/SEK spot FX rate",
    },

    # -----------------------------------------------------------------------
    # IBOR (Interbank Offered Rate) indices
    # -----------------------------------------------------------------------
    "EURIBOR_1M": {
        "type": "ibor",
        "tenor": "1m",
        "day_count": "act360",
        "calendar": "tgt",
        "currency": "eur",
        "publication_lag": 2,
        "description": "Euro Interbank Offered Rate 1M",
    },
    "EURIBOR_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act360",
        "calendar": "tgt",
        "currency": "eur",
        "publication_lag": 2,
        "description": "Euro Interbank Offered Rate 3M",
    },
    "EURIBOR_6M": {
        "type": "ibor",
        "tenor": "6m",
        "day_count": "act360",
        "calendar": "tgt",
        "currency": "eur",
        "publication_lag": 2,
        "description": "Euro Interbank Offered Rate 6M",
    },
    "TIBOR_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act365f",
        "calendar": "tyo",
        "currency": "jpy",
        "publication_lag": 2,
        "description": "Tokyo Interbank Offered Rate 3M",
    },
    "TIBOR_6M": {
        "type": "ibor",
        "tenor": "6m",
        "day_count": "act365f",
        "calendar": "tyo",
        "currency": "jpy",
        "publication_lag": 2,
        "description": "Tokyo Interbank Offered Rate 6M",
    },
    "BBSW_1M": {
        "type": "ibor",
        "tenor": "1m",
        "day_count": "act365f",
        "calendar": "syd",
        "currency": "aud",
        "publication_lag": 0,
        "description": "Bank Bill Swap Rate 1M",
    },
    "BBSW_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act365f",
        "calendar": "syd",
        "currency": "aud",
        "publication_lag": 0,
        "description": "Bank Bill Swap Rate 3M",
    },
    "BBSW_6M": {
        "type": "ibor",
        "tenor": "6m",
        "day_count": "act365f",
        "calendar": "syd",
        "currency": "aud",
        "publication_lag": 0,
        "description": "Bank Bill Swap Rate 6M",
    },
    "CDOR_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act365f",
        "calendar": "tro",
        "currency": "cad",
        "publication_lag": 0,
        "description": "Canadian Dollar Offered Rate 3M",
    },
    "STIBOR_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act360",
        "calendar": "stk",
        "currency": "sek",
        "publication_lag": 2,
        "description": "Stockholm Interbank Offered Rate 3M",
    },
    "NIBOR_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act360",
        "calendar": "osl",
        "currency": "nok",
        "publication_lag": 2,
        "description": "Norwegian Interbank Offered Rate 3M",
    },
    "NIBOR_6M": {
        "type": "ibor",
        "tenor": "6m",
        "day_count": "act360",
        "calendar": "osl",
        "currency": "nok",
        "publication_lag": 2,
        "description": "Norwegian Interbank Offered Rate 6M",
    },
    "NZDBILL_1M": {
        "type": "ibor",
        "tenor": "1m",
        "day_count": "act365f",
        "calendar": "wlg",
        "currency": "nzd",
        "publication_lag": 0,
        "description": "NZD Bank Bill Rate 1M",
    },
    "NZDBILL_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act365f",
        "calendar": "wlg",
        "currency": "nzd",
        "publication_lag": 0,
        "description": "NZD Bank Bill Rate 3M",
    },
    "NZDBILL_6M": {
        "type": "ibor",
        "tenor": "6m",
        "day_count": "act365f",
        "calendar": "wlg",
        "currency": "nzd",
        "publication_lag": 0,
        "description": "NZD Bank Bill Rate 6M",
    },

    # -------------------------------------------------------------------
    # NDF FX indices
    # -------------------------------------------------------------------
    "USDBRL": {
        "type": "ndf_fx",
        "base": "usd",
        "quote": "brl",
        "fixing_lag": 2,
        "settlement_lag": 2,
        "settlement_currency": "usd",
        "calendar": "sao,nyc",
        "fixing_source": "PTAX",
        "description": "USD/BRL NDF fixing rate (PTAX)",
    },
    "USDCNY": {
        "type": "ndf_fx",
        "base": "usd",
        "quote": "cny",
        "fixing_lag": 2,
        "settlement_lag": 2,
        "settlement_currency": "usd",
        "calendar": "bjs,nyc",
        "fixing_source": "CFETS",
        "description": "USD/CNY NDF fixing rate (CFETS)",
    },
    "USDINR": {
        "type": "ndf_fx",
        "base": "usd",
        "quote": "inr",
        "fixing_lag": 2,
        "settlement_lag": 2,
        "settlement_currency": "usd",
        "calendar": "mum,nyc",
        "fixing_source": "RBI",
        "description": "USD/INR NDF fixing rate (RBI reference rate)",
    },
    "USDKRW": {
        "type": "ndf_fx",
        "base": "usd",
        "quote": "krw",
        "fixing_lag": 1,
        "settlement_lag": 2,
        "settlement_currency": "usd",
        "calendar": "sel,nyc",
        "fixing_source": "KFTC",
        "description": "USD/KRW NDF fixing rate (KFTC18)",
    },
    "USDTWD": {
        "type": "ndf_fx",
        "base": "usd",
        "quote": "twd",
        "fixing_lag": 2,
        "settlement_lag": 2,
        "settlement_currency": "usd",
        "calendar": "tai,nyc",
        "fixing_source": "CBC",
        "description": "USD/TWD NDF fixing rate (CBC)",
    },

    # -------------------------------------------------------------------
    # EM Rate indices
    # -------------------------------------------------------------------
    "CDI": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "bus252",
        "calendar": "sao",
        "currency": "brl",
        "compounding": "daily",
        "description": "Brazil Certificado de Deposito Interbancario",
    },
    "MIBOR": {
        "type": "rfr",
        "tenor": "1d",
        "day_count": "act365f",
        "calendar": "mum",
        "currency": "inr",
        "description": "Mumbai Interbank Offered Rate (overnight)",
    },
    "CD91": {
        "type": "ibor",
        "tenor": "91d",
        "day_count": "act365f",
        "calendar": "sel",
        "currency": "krw",
        "publication_lag": 0,
        "description": "Korea 91-day Certificate of Deposit rate",
    },
    "SHIBOR_3M": {
        "type": "ibor",
        "tenor": "3m",
        "day_count": "act360",
        "calendar": "bjs",
        "currency": "cny",
        "publication_lag": 0,
        "description": "Shanghai Interbank Offered Rate 3-month",
    },
}


# ---------------------------------------------------------------------------
# Registry API
# ---------------------------------------------------------------------------

def get_index(name: str) -> dict[str, Any]:
    """
    Return the index convention dict for the given name.

    Parameters
    ----------
    name : str
        Index name (e.g. "SOFR", "EURIBOR_3M").

    Returns
    -------
    dict
        A *copy* of the index dict so callers can modify without side effects.

    Raises
    ------
    KeyError
        If the index name is not found in the registry.
    """
    try:
        return dict(INDEX_REGISTRY[name])
    except KeyError:
        available = ", ".join(sorted(INDEX_REGISTRY.keys())[:10])
        raise KeyError(
            f"Unknown index '{name}'. "
            f"Available indices include: {available}, ... "
            f"({len(INDEX_REGISTRY)} total). Use list_indices() for full list."
        )


def list_indices() -> list[str]:
    """Return a sorted list of all available index names."""
    return sorted(INDEX_REGISTRY.keys())
