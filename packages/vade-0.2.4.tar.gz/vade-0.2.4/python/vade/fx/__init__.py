"""FX framework: rates, forwards, and pairs.

Re-exports from vade.marketcurves for backward compatibility.
"""

from vade.marketcurves import FXPair, FXRates, FXForwards

__all__ = ["FXPair", "FXRates", "FXForwards"]
