"""Market data context: FixingStore and MarketContext."""

from __future__ import annotations

import contextvars
import json as _json
import re as _re
from contextlib import contextmanager
from datetime import date
from typing import Any


class FixingStore:
    """In-memory store for historical fixing rates, keyed by index name and date."""

    def __init__(self) -> None:
        self._data: dict[str, dict[date, float]] = {}

    def set(self, index: str, fixings: dict[Any, float]) -> None:
        """Store fixings for an index, merging with any existing data.

        Parameters
        ----------
        index : str
            Index name (e.g. "SOFR", "EURIBOR_3M").
        fixings : dict
            Mapping of date (or ISO date string) to rate (float).
            String keys are parsed via ``date.fromisoformat()``.
        """
        parsed: dict[date, float] = {}
        for k, v in fixings.items():
            if isinstance(k, str):
                k = date.fromisoformat(k)
            parsed[k] = float(v)

        if index in self._data:
            self._data[index].update(parsed)
        else:
            self._data[index] = parsed

    def get(self, index: str) -> dict[date, float] | None:
        """Retrieve all fixings for an index.

        Returns a copy of the internal dict, or None if no fixings stored.
        """
        data = self._data.get(index)
        if data is None:
            return None
        return dict(data)

    def get_rate(self, index: str, dt: date | str) -> float | None:
        """Retrieve a single fixing rate for an index on a given date.

        Parameters
        ----------
        index : str
            Index name.
        dt : date or str
            The fixing date. Strings are parsed via ``date.fromisoformat()``.

        Returns
        -------
        float or None
            The fixing rate, or None if not found.
        """
        data = self._data.get(index)
        if data is None:
            return None
        if isinstance(dt, str):
            dt = date.fromisoformat(dt)
        return data.get(dt)

    def clear(self, index: str | None = None) -> None:
        """Clear fixings.

        If index is provided, clear that index only. If None, clear all.
        """
        if index is None:
            self._data.clear()
        else:
            self._data.pop(index, None)

    def list_indices(self) -> list[str]:
        """Return a sorted list of indices that have stored fixings."""
        return sorted(self._data.keys())

    def from_polars(self, df: Any, index: str | None = None) -> None:
        """Bulk-load fixings from a Polars DataFrame.

        Parameters
        ----------
        df : polars.DataFrame
            Either narrow format (2 columns: date, value) or wide format
            (3+ columns: date column + one column per index).
        index : str or None
            Required for narrow (2-column) format. Ignored for wide format.
        """
        import polars as pl  # noqa: F811

        cols = df.columns
        if len(cols) == 2:
            # Narrow format
            if index is None:
                raise ValueError(
                    "index name required for narrow (2-column) DataFrame"
                )
            fixings = {row[0]: row[1] for row in df.iter_rows()}
            self.set(index, fixings)
        else:
            # Wide format: first column is dates, rest are index columns
            date_col = cols[0]
            for idx_col in cols[1:]:
                fixings = {
                    row[0]: row[1]
                    for row in df.select([date_col, idx_col]).iter_rows()
                    if row[1] is not None
                }
                self.set(idx_col, fixings)

    def from_csv(self, path: str, index: str | None = None) -> None:
        """Bulk-load fixings from a CSV file.

        Parameters
        ----------
        path : str
            Path to the CSV file.
        index : str or None
            Required for narrow (2-column) CSV. Ignored for wide format.
        """
        import polars as pl  # noqa: F811

        df = pl.read_csv(path, try_parse_dates=True)
        self.from_polars(df, index=index)

    def __repr__(self) -> str:
        n_indices = len(self._data)
        n_fixings = sum(len(v) for v in self._data.values())
        return f"FixingStore({n_indices} indices, {n_fixings} fixings)"

    def __len__(self) -> int:
        return sum(len(v) for v in self._data.values())


# ---------------------------------------------------------------------------
# Module-level eval_date context variable
# ---------------------------------------------------------------------------

_eval_date_var: contextvars.ContextVar[date | None] = contextvars.ContextVar(
    "vade_eval_date", default=None
)


@contextmanager
def eval_date(d: date):
    """Temporarily set the module-level default eval date.

    Usage::

        with eval_date(date(2024, 1, 15)):
            ctx = MarketContext()  # ctx.eval_date == date(2024, 1, 15)
    """
    token = _eval_date_var.set(d)
    try:
        yield d
    finally:
        _eval_date_var.reset(token)


def get_eval_date() -> date:
    """Get the current module-level eval date, or date.today()."""
    return _eval_date_var.get() or date.today()


# ---------------------------------------------------------------------------
# Curve type registry for polymorphic serialization
# ---------------------------------------------------------------------------


def _build_curve_registry() -> dict[str, type]:
    import vade.curves as _c

    return {
        "DiscountCurve": _c.DiscountCurve,
        "LineCurve": _c.LineCurve,
        "ForwardCurve": _c.ForwardCurve,
        "SpreadCurve": _c.SpreadCurve,
        "CompositeCurve": _c.CompositeCurve,
        "FXImpliedCurve": _c.FXImpliedCurve,
        "CreditImpliedCurve": _c.CreditImpliedCurve,
        "NelsonSiegel": _c.NelsonSiegel,
        "NelsonSiegelSvensson": _c.NelsonSiegelSvensson,
        "SmithWilson": _c.SmithWilson,
        "TurnOfYearCurve": _c.TurnOfYearCurve,
    }


_CURVE_REGISTRY: dict[str, type] | None = None


def _get_curve_registry() -> dict[str, type]:
    global _CURVE_REGISTRY
    if _CURVE_REGISTRY is None:
        _CURVE_REGISTRY = _build_curve_registry()
    return _CURVE_REGISTRY


_CALENDAR_NAME_RE = _re.compile(r"^BusinessCalendar\('(.+)'\)$")


def _extract_calendar_name(cal: object) -> str:
    m = _CALENDAR_NAME_RE.match(repr(cal))
    if m is None:
        raise ValueError(
            "Calendar cannot be serialized: custom calendars created via "
            "BusinessCalendar.new_custom() are not serializable. "
            "Only named calendars (e.g. BusinessCalendar('NYC')) are supported."
        )
    return m.group(1)


# ---------------------------------------------------------------------------
# MarketContext
# ---------------------------------------------------------------------------


class MarketContext:
    """Immutable market data container bundling all pricing inputs.

    Parameters
    ----------
    eval_date : date, optional
        Evaluation date. Falls back to module-level ``eval_date`` context
        manager value, then ``date.today()``.
    curves : dict[str, Any], optional
        Named curves keyed by string ID (e.g. ``{"USD_SOFR": curve}``).
    fixings : FixingStore, optional
        Historical fixings store. Defaults to a fresh empty store.
    fx_rates : optional
        FX rate triangulation object.
    calendars : dict[str, Any], optional
        Named business calendars.
    """

    def __init__(
        self,
        *,
        eval_date: date | None = None,
        curves: dict[str, Any] | None = None,
        fixings: FixingStore | None = None,
        fx_rates: Any = None,
        fx_pairs: dict[str, float] | None = None,
        calendars: dict[str, Any] | None = None,
    ) -> None:
        if eval_date is None:
            eval_date = _eval_date_var.get() or date.today()
        self._eval_date = eval_date
        self._curves = dict(curves) if curves else {}
        self._fixings = fixings if fixings is not None else FixingStore()
        self._fx_rates = fx_rates
        self._fx_pairs = fx_pairs
        self._calendars = dict(calendars) if calendars else {}

    # --- Read-only properties ---

    @property
    def eval_date(self) -> date:
        """Evaluation date."""
        return self._eval_date

    @property
    def curves(self) -> dict[str, Any]:
        """Named curves (defensive copy)."""
        return dict(self._curves)

    @property
    def fixings(self) -> FixingStore:
        """Historical fixings store."""
        return self._fixings

    @property
    def fx_rates(self) -> Any:
        """FX rate triangulation object, or None."""
        return self._fx_rates

    @property
    def calendars(self) -> dict[str, Any]:
        """Named business calendars (defensive copy)."""
        return dict(self._calendars)

    # --- Curve lookup ---

    def curve(self, curve_id: str) -> Any:
        """Retrieve a curve by its string ID.

        Raises
        ------
        KeyError
            If the curve is not found, with a descriptive message listing
            available curve IDs.
        """
        try:
            return self._curves[curve_id]
        except KeyError:
            raise KeyError(
                f"Curve '{curve_id}' not found in context. "
                f"Available: {sorted(self._curves.keys())}"
            ) from None

    # --- Factory methods ---

    @classmethod
    def from_solver(
        cls,
        solver: Any,
        *,
        eval_date: date | None = None,
        fixings: FixingStore | None = None,
        fx_rates: Any = None,
        fx_pairs: dict[str, float] | None = None,
        calendars: dict[str, Any] | None = None,
    ) -> MarketContext:
        """Create MarketContext from a calibrated Solver.

        Extracts all curves by their string IDs from the solver.

        Parameters
        ----------
        solver : Solver
            A calibrated Solver instance.
        eval_date : date, optional
            Evaluation date. Falls back to module-level default, then today.
        fixings : FixingStore, optional
            Historical fixings store.
        fx_rates : optional
            FX rate triangulation object.
        fx_pairs : dict, optional
            FX pair rates for serialization (e.g. ``{"eurusd": 1.08}``).
        calendars : dict, optional
            Named business calendars.
        """
        curves = {}
        for curve_id in solver.curve_ids:
            curves[curve_id] = solver.get_curve_by_id(curve_id)
        return cls(
            eval_date=eval_date,
            curves=curves,
            fixings=fixings,
            fx_rates=fx_rates,
            fx_pairs=fx_pairs,
            calendars=calendars,
        )

    # --- Immutable derivation (.with_*()) ---

    def with_eval_date(self, eval_date: date) -> MarketContext:
        """Return a new context with a different eval_date."""
        return MarketContext(
            eval_date=eval_date,
            curves=dict(self._curves),
            fixings=self._fixings,
            fx_rates=self._fx_rates,
            fx_pairs=self._fx_pairs,
            calendars=dict(self._calendars),
        )

    def with_curve(self, curve_id: str, curve: Any) -> MarketContext:
        """Return a new context with an added/replaced curve."""
        new_curves = dict(self._curves)
        new_curves[curve_id] = curve
        return MarketContext(
            eval_date=self._eval_date,
            curves=new_curves,
            fixings=self._fixings,
            fx_rates=self._fx_rates,
            fx_pairs=self._fx_pairs,
            calendars=dict(self._calendars),
        )

    def with_fixings(self, fixings: FixingStore) -> MarketContext:
        """Return a new context with a different fixings store."""
        return MarketContext(
            eval_date=self._eval_date,
            curves=dict(self._curves),
            fixings=fixings,
            fx_rates=self._fx_rates,
            fx_pairs=self._fx_pairs,
            calendars=dict(self._calendars),
        )

    def with_fx_rates(
        self, fx_rates: Any, *, fx_pairs: dict[str, float] | None = None
    ) -> MarketContext:
        """Return a new context with different FX rates."""
        return MarketContext(
            eval_date=self._eval_date,
            curves=dict(self._curves),
            fixings=self._fixings,
            fx_rates=fx_rates,
            fx_pairs=fx_pairs if fx_pairs is not None else self._fx_pairs,
            calendars=dict(self._calendars),
        )

    def with_calendar(self, name: str, calendar: Any) -> MarketContext:
        """Return a new context with an added/replaced calendar."""
        new_cals = dict(self._calendars)
        new_cals[name] = calendar
        return MarketContext(
            eval_date=self._eval_date,
            curves=dict(self._curves),
            fixings=self._fixings,
            fx_rates=self._fx_rates,
            fx_pairs=self._fx_pairs,
            calendars=new_cals,
        )

    # --- Serialization ---

    def to_json(self) -> str:
        """Serialize this MarketContext to a compact JSON string.

        Raises
        ------
        ValueError
            If FXRates is present but ``fx_pairs`` was not provided,
            if a custom calendar is present, or if a curve type is
            not serializable.
        """
        registry = _get_curve_registry()

        curves_out: dict[str, Any] = {}
        for name, curve in self._curves.items():
            cls_name = type(curve).__name__
            if cls_name not in registry:
                raise ValueError(
                    f"Curve '{name}' of type '{cls_name}' is not serializable. "
                    f"Supported types: {sorted(registry)}"
                )
            curves_out[name] = {
                "type": cls_name,
                "data": _json.loads(curve.to_json()),
            }

        fixings_out: dict[str, dict[str, float]] = {
            idx: {d.isoformat(): v for d, v in dates.items()}
            for idx, dates in self._fixings._data.items()
        }

        fx_out: dict[str, Any] | None = None
        if self._fx_rates is not None:
            if self._fx_pairs is None:
                raise ValueError(
                    "FXRates cannot be serialized without fx_pairs \u2014 "
                    "provide fx_pairs= when constructing MarketContext."
                )
            fx_out = {
                "pairs": self._fx_pairs,
                "settlement": self._fx_rates.settlement.isoformat(),
            }

        cals_out: dict[str, str] = {
            name: _extract_calendar_name(cal)
            for name, cal in self._calendars.items()
        }

        payload = {
            "eval_date": self._eval_date.isoformat(),
            "curves": curves_out,
            "fixings": fixings_out,
            "fx_rates": fx_out,
            "calendars": cals_out,
        }
        return _json.dumps(payload, separators=(",", ":"))

    @classmethod
    def from_json(cls, json_str: str) -> MarketContext:
        """Deserialize a MarketContext from a JSON string.

        Parameters
        ----------
        json_str : str
            JSON string previously produced by :meth:`to_json`.
        """
        from vade.calendar import BusinessCalendar as _BusinessCalendar
        from vade.fx import FXRates as _FXRates

        registry = _get_curve_registry()
        data = _json.loads(json_str)

        eval_date_val = date.fromisoformat(data["eval_date"])

        curves: dict[str, Any] = {}
        for name, env in data.get("curves", {}).items():
            curve_cls = registry.get(env["type"])
            if curve_cls is None:
                raise ValueError(f"Unknown curve type '{env['type']}' in JSON.")
            curves[name] = curve_cls.from_json(_json.dumps(env["data"]))

        fixings = FixingStore()
        for idx, dates in data.get("fixings", {}).items():
            fixings.set(idx, dates)

        fx_rates = None
        fx_pairs = None
        fx_data = data.get("fx_rates")
        if fx_data is not None:
            fx_pairs = fx_data["pairs"]
            settlement = date.fromisoformat(fx_data["settlement"])
            fx_rates = _FXRates(fx_pairs, settlement)

        calendars: dict[str, Any] = {}
        for name, cal_name in data.get("calendars", {}).items():
            calendars[name] = _BusinessCalendar(cal_name)

        return cls(
            eval_date=eval_date_val,
            curves=curves,
            fixings=fixings,
            fx_rates=fx_rates,
            fx_pairs=fx_pairs,
            calendars=calendars,
        )

    def __repr__(self) -> str:
        return (
            f"MarketContext(eval_date={self._eval_date}, "
            f"curves={len(self._curves)}, "
            f"fixings={len(self._fixings._data)} indices)"
        )

    # --- Analytics ---

    def discount_factor(self, curve_id: str, dt: date) -> Any:
        """Query discount factor from a named curve."""
        return self.curve(curve_id).discount_factor(dt)

    def forward_rate(self, curve_id: str, start: date, end: date) -> Any:
        """Query forward rate from a named curve."""
        return self.curve(curve_id).forward_rate(start, end)

    def zero_rate(self, curve_id: str, start: date, end: date) -> Any:
        """Query zero rate from a named curve."""
        return self.curve(curve_id).zero_rate(start, end)

    def fx_rate(self, base: str, quote: str) -> float:
        """Query FX rate from context's FX rates."""
        if self._fx_rates is None:
            raise ValueError("No FX rates in context")
        pair = f"{base}{quote}".lower()
        return self._fx_rates.rate(pair)

    # --- Diff ---

    @staticmethod
    def _diff_keys(self_keys: set[str], other_keys: set[str]) -> dict:
        """Compute set-difference summary for two key sets."""
        return {
            "added": sorted(other_keys - self_keys),
            "removed": sorted(self_keys - other_keys),
            "common": sorted(self_keys & other_keys),
        }

    def diff(self, other: "MarketContext", *, as_dataframe: bool = False) -> Any:
        """Compare this context with another, reporting differences.

        Parameters
        ----------
        other : MarketContext
            The context to compare against.
        as_dataframe : bool
            If True, return a Polars DataFrame instead of a dict.

        Returns
        -------
        dict or polars.DataFrame
            Summary of differences across all 5 fields.
        """
        result: dict[str, Any] = {}

        # eval_date
        result["eval_date"] = {
            "changed": self._eval_date != other._eval_date,
            "self": self._eval_date,
            "other": other._eval_date,
        }

        # curves
        result["curves"] = self._diff_keys(
            set(self._curves.keys()), set(other._curves.keys())
        )

        # fixings
        self_fix = set(self._fixings.list_indices())
        other_fix = set(other._fixings.list_indices())
        result["fixings"] = self._diff_keys(self_fix, other_fix)

        # fx_rates
        both_none = self._fx_rates is None and other._fx_rates is None
        result["fx_rates"] = {
            "changed": not both_none and (self._fx_rates is not other._fx_rates),
        }

        # calendars
        result["calendars"] = self._diff_keys(
            set(self._calendars.keys()), set(other._calendars.keys())
        )

        if not as_dataframe:
            return result

        # DataFrame output
        try:
            import polars as pl
        except ImportError:
            raise ImportError(
                "polars is required for as_dataframe=True. "
                "Install with: pip install polars"
            )

        rows: dict[str, list] = {
            "section": [],
            "key": [],
            "change": [],
            "self_value": [],
            "other_value": [],
        }

        # eval_date row
        if result["eval_date"]["changed"]:
            rows["section"].append("eval_date")
            rows["key"].append("eval_date")
            rows["change"].append("changed")
            rows["self_value"].append(str(self._eval_date))
            rows["other_value"].append(str(other._eval_date))

        # curves, fixings, calendars rows
        for section in ("curves", "fixings", "calendars"):
            d = result[section]
            for key in d["added"]:
                rows["section"].append(section)
                rows["key"].append(key)
                rows["change"].append("added")
                rows["self_value"].append("")
                rows["other_value"].append(key)
            for key in d["removed"]:
                rows["section"].append(section)
                rows["key"].append(key)
                rows["change"].append("removed")
                rows["self_value"].append(key)
                rows["other_value"].append("")
            for key in d["common"]:
                rows["section"].append(section)
                rows["key"].append(key)
                rows["change"].append("unchanged")
                rows["self_value"].append(key)
                rows["other_value"].append(key)

        # fx_rates row
        fx_change = "changed" if result["fx_rates"]["changed"] else "unchanged"
        rows["section"].append("fx_rates")
        rows["key"].append("fx_rates")
        rows["change"].append(fx_change)
        rows["self_value"].append(str(self._fx_rates is not None))
        rows["other_value"].append(str(other._fx_rates is not None))

        if not rows["section"]:
            return pl.DataFrame(
                schema={
                    "section": pl.Utf8,
                    "key": pl.Utf8,
                    "change": pl.Utf8,
                    "self_value": pl.Utf8,
                    "other_value": pl.Utf8,
                }
            )

        return pl.DataFrame(rows)
