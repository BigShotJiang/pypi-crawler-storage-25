"""
Historical fixings registry for interest rate indices.

Provides an in-memory store for historical fixing rates indexed by name
and date. Instruments query this registry automatically during pricing
when past fixings are needed for accrued interest or RFR compounding.

Fixings are not persisted -- users load them each session.

Usage::

    import vade.fixings as fixings
    from datetime import date

    fixings.set("SOFR", {
        date(2024, 1, 2): 0.053,
        date(2024, 1, 3): 0.0531,
        "2024-01-04": 0.0529,   # string dates are parsed
    })

    rate = fixings.get_rate("SOFR", date(2024, 1, 2))  # 0.053
    all_sofr = fixings.get("SOFR")  # {date: rate, ...}
"""

from __future__ import annotations

from datetime import date
from typing import Any

from vade.context import FixingStore


# ---------------------------------------------------------------------------
# Default store instance (module-level singleton)
# ---------------------------------------------------------------------------

_DEFAULT_STORE = FixingStore()


# ---------------------------------------------------------------------------
# Public API (delegates to _DEFAULT_STORE)
# ---------------------------------------------------------------------------

def set(index: str, fixings: dict[Any, float]) -> None:
    """
    Store fixings for an index, merging with any existing data.

    Parameters
    ----------
    index : str
        Index name (e.g. "SOFR", "EURIBOR_3M").
    fixings : dict
        Mapping of date (or ISO date string) to rate (float).
        String keys are parsed via ``date.fromisoformat()``.
    """
    _DEFAULT_STORE.set(index, fixings)


def get(index: str) -> dict[date, float] | None:
    """
    Retrieve all fixings for an index.

    Parameters
    ----------
    index : str
        Index name.

    Returns
    -------
    dict or None
        Mapping of date to rate, or None if no fixings stored for this index.
    """
    return _DEFAULT_STORE.get(index)


def get_rate(index: str, dt: date | str) -> float | None:
    """
    Retrieve a single fixing rate for an index on a given date.

    Parameters
    ----------
    index : str
        Index name.
    dt : date or str
        The fixing date. Strings are parsed via ``date.fromisoformat()``.

    Returns
    -------
    float or None
        The fixing rate, or None if not found.
    """
    return _DEFAULT_STORE.get_rate(index, dt)


def clear(index: str | None = None) -> None:
    """
    Clear fixings.

    Parameters
    ----------
    index : str or None
        If provided, clear fixings for that index only.
        If None, clear all fixings.
    """
    _DEFAULT_STORE.clear(index)


def list_indices() -> list[str]:
    """Return a sorted list of indices that have stored fixings."""
    return _DEFAULT_STORE.list_indices()
