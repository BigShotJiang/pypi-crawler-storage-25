"""Market curves: discount/rate curves, FX rates, and FX forwards."""

# --- Curves ---
from vade._vade_rs.curves import (
    DiscountCurve,
    LineCurve,
    CreditImpliedCurve,
    CompositeCurve,
    FXImpliedCurve,
    NelsonSiegel,
    NelsonSiegelSvensson,
    SmithWilson,
    IRImpliedCurve,
    ForwardCurve,
    SpreadCurve,
    TurnOfYearCurve,
    FittedBondCurve,
)

# --- FX ---
from vade._vade_rs.fx import FXPair, FXRates, FXForwards

__all__ = [
    # Curves
    "DiscountCurve", "LineCurve", "CreditImpliedCurve", "CompositeCurve",
    "FXImpliedCurve", "NelsonSiegel", "NelsonSiegelSvensson", "SmithWilson",
    "IRImpliedCurve", "ForwardCurve", "SpreadCurve", "TurnOfYearCurve",
    "FittedBondCurve",
    # FX
    "FXPair", "FXRates", "FXForwards",
]
