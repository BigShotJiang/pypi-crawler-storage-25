"""Automatic differentiation types and functions."""

from vade._vade_rs.autodiff import Dual, Dual2

__all__ = ["Dual", "Dual2"]
