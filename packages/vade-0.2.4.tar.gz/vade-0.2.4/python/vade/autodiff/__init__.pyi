"""Type stubs for vade.autodiff module."""

from typing import List, Optional
import numpy as np
import numpy.typing as npt

class Dual:
    """First-order dual number for forward-mode automatic differentiation."""

    def __init__(self, var: str, real: float) -> None:
        """Create a Dual number with a single variable.

        Args:
            var: Variable name.
            real: Real value.
        """
        ...

    @staticmethod
    def new_multi(
        real: float,
        vars: List[str],
        dual: Optional[List[float]] = None,
    ) -> "Dual":
        """Create a Dual number with multiple variables.

        Args:
            real: Real value.
            vars: Variable names.
            dual: Optional derivative values (defaults to identity).
        """
        ...

    @property
    def real(self) -> float:
        """Real value of the dual number."""
        ...

    @property
    def vars(self) -> List[str]:
        """Variable names."""
        ...

    def gradient(self) -> npt.NDArray[np.float64]:
        """First-order derivatives as a numpy array."""
        ...

    def exp(self) -> "Dual":
        """Exponential function with AD."""
        ...

    def log(self) -> "Dual":
        """Natural logarithm with AD."""
        ...

    def __add__(self, other: "Dual | float") -> "Dual": ...
    def __radd__(self, other: "Dual | float") -> "Dual": ...
    def __sub__(self, other: "Dual | float") -> "Dual": ...
    def __rsub__(self, other: "Dual | float") -> "Dual": ...
    def __mul__(self, other: "Dual | float") -> "Dual": ...
    def __rmul__(self, other: "Dual | float") -> "Dual": ...
    def __truediv__(self, other: "Dual | float") -> "Dual": ...
    def __rtruediv__(self, other: "Dual | float") -> "Dual": ...
    def __neg__(self) -> "Dual": ...
    def __pow__(self, exp: float) -> "Dual": ...
    def __float__(self) -> float: ...
    def __repr__(self) -> str: ...

class Dual2:
    """Second-order dual number for forward-mode automatic differentiation."""

    def __init__(self, var: str, real: float) -> None:
        """Create a Dual2 number with a single variable.

        Args:
            var: Variable name.
            real: Real value.
        """
        ...

    @staticmethod
    def new_multi(
        real: float,
        vars: List[str],
        dual: Optional[List[float]] = None,
        dual2: Optional[List[float]] = None,
    ) -> "Dual2":
        """Create a Dual2 number with multiple variables.

        Args:
            real: Real value.
            vars: Variable names.
            dual: Optional first-order derivative values.
            dual2: Optional second-order derivative values (half-Hessian, flattened).
        """
        ...

    @property
    def real(self) -> float:
        """Real value of the dual number."""
        ...

    @property
    def vars(self) -> List[str]:
        """Variable names."""
        ...

    def gradient(self) -> npt.NDArray[np.float64]:
        """First-order derivatives as a numpy array."""
        ...

    def gradient2(self) -> npt.NDArray[np.float64]:
        """Full Hessian matrix as a 2D numpy array.

        Note: Returns the full Hessian (2x the stored half-Hessian).
        """
        ...

    def exp(self) -> "Dual2":
        """Exponential function with AD."""
        ...

    def log(self) -> "Dual2":
        """Natural logarithm with AD."""
        ...

    def __add__(self, other: "Dual2 | float") -> "Dual2": ...
    def __radd__(self, other: "Dual2 | float") -> "Dual2": ...
    def __sub__(self, other: "Dual2 | float") -> "Dual2": ...
    def __rsub__(self, other: "Dual2 | float") -> "Dual2": ...
    def __mul__(self, other: "Dual2 | float") -> "Dual2": ...
    def __rmul__(self, other: "Dual2 | float") -> "Dual2": ...
    def __truediv__(self, other: "Dual2 | float") -> "Dual2": ...
    def __rtruediv__(self, other: "Dual2 | float") -> "Dual2": ...
    def __neg__(self) -> "Dual2": ...
    def __pow__(self, exp: float) -> "Dual2": ...
    def __float__(self) -> float: ...
    def __repr__(self) -> str: ...
