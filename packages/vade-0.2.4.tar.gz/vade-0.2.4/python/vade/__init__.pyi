"""Type stubs for vade top-level module.

All public types are re-exported here for flat import access:
    from vade import Curve, IRS, Solver, Dual, ...
"""

# --- Curves ---
from vade.curves import (
    DiscountCurve as DiscountCurve,
    LineCurve as LineCurve,
    CompositeCurve as CompositeCurve,
    FXImpliedCurve as FXImpliedCurve,
    CreditImpliedCurve as CreditImpliedCurve,
    NelsonSiegel as NelsonSiegel,
    NelsonSiegelSvensson as NelsonSiegelSvensson,
    SmithWilson as SmithWilson,
    IRImpliedCurve as IRImpliedCurve,
    ForwardCurve as ForwardCurve,
    SpreadCurve as SpreadCurve,
    TurnOfYearCurve as TurnOfYearCurve,
)

# --- FX ---
from vade.fx import (
    FXRates as FXRates,
    FXForwards as FXForwards,
    FXPair as FXPair,
)

# --- Cashflows ---
from vade.cashflows import (
    FixedLeg as FixedLeg,
    FloatLeg as FloatLeg,
)

# --- Instruments ---
from vade.instruments import (
    InterestRateSwap as InterestRateSwap,
    IRS as IRS,
    ForwardRateAgreement as ForwardRateAgreement,
    FRA as FRA,
    ZeroCouponSwap as ZeroCouponSwap,
    ZCS as ZCS,
    SingleBasisSwap as SingleBasisSwap,
    SBS as SBS,
    OvernightIndexedSwap as OvernightIndexedSwap,
    OIS as OIS,
    Deposit as Deposit,
    IRFuture as IRFuture,
    CapFloor as CapFloor,
    FixedRateBond as FixedRateBond,
    Bill as Bill,
    FloatRateNote as FloatRateNote,
    ZeroCouponBond as ZeroCouponBond,
    StepUpBond as StepUpBond,
    AmortizingBond as AmortizingBond,
    PIKBond as PIKBond,
    SubPeriodFRN as SubPeriodFRN,
    CappedFloatRateNote as CappedFloatRateNote,
    AssetSwap as AssetSwap,
    CallableBond as CallableBond,
    CreditDefaultSwap as CreditDefaultSwap,
    CDS as CDS,
    CrossCurrencySwap as CrossCurrencySwap,
    XCS as XCS,
    FXForward as FXForward,
)

# --- Solver ---
from vade.solver import (
    Solver as Solver,
    SolverResult as SolverResult,
    bootstrap as bootstrap,
)

# --- Autodiff ---
from vade.autodiff import (
    Dual as Dual,
    Dual2 as Dual2,
)

# --- Calendar ---
from vade.calendar import (
    Schedule as Schedule,
    BusinessCalendar as BusinessCalendar,
    dcf as dcf,
    add_tenor as add_tenor,
    add_business_days as add_business_days,
    parse_date as parse_date,
)

# --- Numerical ---
from vade.numerical import (
    brent_solve as brent_solve,
    newton_raphson_solve as newton_raphson_solve,
)

# --- Context ---
import datetime
from contextlib import contextmanager
from typing import Any, Generator

from vade.context import FixingStore as FixingStore

class MarketContext:
    _eval_date: datetime.date
    _curves: dict[str, Any]
    _fixings: FixingStore
    _fx_rates: Any
    _fx_pairs: dict[str, float] | None
    _calendars: dict[str, Any]

    def __init__(
        self,
        *,
        eval_date: datetime.date | None = None,
        curves: dict[str, Any] | None = None,
        fixings: FixingStore | None = None,
        fx_rates: Any = None,
        fx_pairs: dict[str, float] | None = None,
        calendars: dict[str, Any] | None = None,
    ) -> None: ...

    @property
    def eval_date(self) -> datetime.date: ...
    @property
    def curves(self) -> dict[str, Any]: ...
    @property
    def fixings(self) -> FixingStore: ...
    @property
    def fx_rates(self) -> Any: ...
    @property
    def calendars(self) -> dict[str, Any]: ...

    def curve(self, curve_id: str) -> Any: ...
    def discount_factor(self, curve_id: str, dt: datetime.date) -> Any: ...
    def forward_rate(self, curve_id: str, start: datetime.date | str, end: datetime.date | str) -> Any: ...
    def zero_rate(self, curve_id: str, start: datetime.date | str, end: datetime.date | str) -> Any: ...
    def fx_rate(self, base: str, quote: str) -> float: ...
    def diff(self, other: "MarketContext", *, as_dataframe: bool = False) -> Any: ...

    @classmethod
    def from_solver(
        cls,
        solver: Any,
        *,
        eval_date: datetime.date | None = None,
        fixings: FixingStore | None = None,
        fx_rates: Any = None,
        fx_pairs: dict[str, float] | None = None,
        calendars: dict[str, Any] | None = None,
    ) -> MarketContext: ...

    def with_eval_date(self, eval_date: datetime.date) -> MarketContext: ...
    def with_curve(self, curve_id: str, curve: Any) -> MarketContext: ...
    def with_fixings(self, fixings: FixingStore) -> MarketContext: ...
    def with_fx_rates(self, fx_rates: Any, *, fx_pairs: dict[str, float] | None = None) -> MarketContext: ...
    def with_calendar(self, name: str, calendar: Any) -> MarketContext: ...

    def to_json(self) -> str: ...
    @classmethod
    def from_json(cls, json_str: str) -> MarketContext: ...

    def __repr__(self) -> str: ...

def eval_date(d: datetime.date) -> contextmanager: ...

__version__: str

__all__: list[str]
