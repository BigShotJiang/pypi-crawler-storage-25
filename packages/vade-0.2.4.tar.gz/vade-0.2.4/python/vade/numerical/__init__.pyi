"""Type stubs for vade.numerical module."""

from typing import Callable, Tuple


def brent_solve(
    f: Callable[[float], float],
    a: float,
    b: float,
    tol: float = 1e-12,
    max_iter: int = 200,
) -> float:
    """Brent's method root finder.

    Finds x in [a, b] such that f(x) = 0.

    Args:
        f: Callable taking float, returning float.
        a: Lower bracket.
        b: Upper bracket.
        tol: Convergence tolerance.
        max_iter: Maximum iterations.

    Returns:
        Root x where f(x) ~ 0.

    Raises:
        ValueError: If root is not bracketed or max_iter exceeded.
    """
    ...


def newton_raphson_solve(
    f: Callable[[float], Tuple[float, float]],
    x0: float,
    tol: float = 1e-12,
    max_iter: int = 200,
) -> float:
    """Newton-Raphson root finder.

    Finds x such that f(x) = 0, where f returns (value, derivative).

    Args:
        f: Callable taking float, returning (value, derivative) tuple.
        x0: Initial guess.
        tol: Convergence tolerance.
        max_iter: Maximum iterations.

    Returns:
        Root x where f(x) ~ 0.

    Raises:
        ValueError: If derivative is zero or max_iter exceeded.
    """
    ...


def discount_factor(rate: float, time: float, compounding: str) -> float:
    """Compute discount factor from rate, time, and compounding convention.

    Args:
        rate: Interest rate (e.g. 0.05 for 5%).
        time: Time in years.
        compounding: One of "continuous", "annual", "semi_annual",
            "quarterly", "daily", "simple".

    Returns:
        Discount factor as float.

    Raises:
        ValueError: If compounding convention is unknown.
    """
    ...


def rate_from_df(df: float, time: float, compounding: str) -> float:
    """Compute interest rate from discount factor.

    Args:
        df: Discount factor.
        time: Time in years.
        compounding: One of "continuous", "annual", "semi_annual",
            "quarterly", "daily", "simple".

    Returns:
        Interest rate as float.

    Raises:
        ValueError: If compounding convention is unknown.
    """
    ...


def convert_rate(
    rate: float, time: float, from_compounding: str, to_compounding: str
) -> float:
    """Convert rate between compounding conventions.

    Args:
        rate: Interest rate in the source convention.
        time: Time in years.
        from_compounding: Source compounding convention.
        to_compounding: Target compounding convention.

    Returns:
        Equivalent rate in the target convention.

    Raises:
        ValueError: If any compounding convention is unknown.
    """
    ...
