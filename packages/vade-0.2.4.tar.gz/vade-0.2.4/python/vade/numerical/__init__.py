"""Numerical algorithms: root-finding and compounding conversions."""

from vade._vade_rs.numerical import (
    brent_solve,
    newton_raphson_solve,
    discount_factor,
    rate_from_df,
    convert_rate,
)

__all__ = [
    "brent_solve", "newton_raphson_solve",
    "discount_factor", "rate_from_df", "convert_rate",
]
