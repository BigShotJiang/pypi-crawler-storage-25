"""Rate instrument classes: IRS, FRA, ZCS, SBS, OIS, Deposit, IRFuture, CapFloor."""
from __future__ import annotations

import datetime
from typing import Any, Optional, Union

from vade._vade_rs.instruments import (
    PyInterestRateSwap,
    PyForwardRateAgreement,
    PyZeroCouponSwap,
    PySingleBasisSwap,
    PyOvernightIndexedSwap,
    PyDeposit,
    PyIRFuture,
    PyCapFloor,
)
from vade.instruments._helpers import (
    _parse_frequency,
    _parse_modifier,
    _parse_termination,
    _merge_spec_params,
    _resolve_curves_from_context,
)
from vade.cashflows.dataframe import cashflows_to_polars

class InterestRateSwap:
    """Interest Rate Swap: fixed vs floating leg.

    Construct with explicit parameters or a spec template::

        irs = InterestRateSwap(
            spec="usd_irs",
            effective=date(2024, 1, 1),
            termination="5Y",
            fixed_rate=3.0,
        )
    """

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        frequency: str = "a",
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: str = "USD",
        amortization: Any = None,
        fixed_amortization: Any = None,
        float_amortization: Any = None,
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "frequency": frequency,
            "fixed_rate": fixed_rate,
            "notional": notional,
            "convention": convention,
            "fixing_method": fixing_method,
            "spread": spread,
            "calendar": calendar,
            "payment_lag": payment_lag,
            "currency": currency,
            "modifier": modifier,
            "stub": stub,
        })
        # Apply explicit overrides
        if float_convention is not None:
            params["float_convention"] = float_convention
        if amortization is not None:
            params["amortization"] = amortization
        if fixed_amortization is not None:
            params["fixed_amortization"] = fixed_amortization
        if float_amortization is not None:
            params["float_amortization"] = float_amortization
        # Apply any extra kwargs from user
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        # Extract leg2_ prefixed params from spec for float leg
        fconv = params.get("float_convention", params.get("leg2_convention", params.get("convention", "act360")))
        fm = params.get("leg2_fixing_method", params.get("fixing_method", "rfr_payment_delay"))

        self._inner = PyInterestRateSwap(
            effective=effective,
            termination=term_date,
            frequency=_parse_frequency(params.get("frequency", "a")),
            fixed_rate=params.get("fixed_rate", 0.0),
            notional=params.get("notional", 1_000_000.0),
            convention=params.get("convention", "act360"),
            float_convention=fconv,
            fixing_method=fm,
            spread=params.get("spread", 0.0),
            calendar=params.get("calendar"),
            payment_lag=params.get("payment_lag"),
            currency=params.get("currency", "USD"),
            amortization=params.get("amortization"),
            modifier=_parse_modifier(params.get("modifier", "mf")),
            stub=params.get("stub", "shortfront"),
            fixed_amortization=params.get("fixed_amortization"),
            float_amortization=params.get("float_amortization"),
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = params.get("index")
        if index is not None:
            self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Compute par rate."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        """Compute net present value."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        """Return cashflows as a Polars DataFrame."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        """Compute spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.spread(curves)

    def _resolve_curves_from_solver(self, solver):
        """Auto-resolve curves from a calibrated Solver instance."""
        if self._disc_curve_id:
            disc = solver.get_curve_by_id(self._disc_curve_id)
            if self._forecast_curve_id and self._forecast_curve_id != self._disc_curve_id:
                forecast = solver.get_curve_by_id(self._forecast_curve_id)
                return [forecast, disc]
            return disc
        # Default: use first curve from solver
        return solver.get_curve(0)

    def __repr__(self):
        return "InterestRateSwap(...)"


# Alias
IRS = InterestRateSwap


class ForwardRateAgreement:
    """Forward Rate Agreement: single-period forward rate instrument."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        notional: float = 1_000_000.0,
        fixed_rate: float = 0.0,
        convention: str = "act360",
        fixing_method: str = "rfr_payment_delay",
        calendar: Optional[str] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "notional": notional,
            "fixed_rate": fixed_rate,
            "convention": convention,
            "fixing_method": fixing_method,
            "calendar": calendar,
        })
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyForwardRateAgreement(
            effective=effective,
            termination=term_date,
            notional=params.get("notional", 1_000_000.0),
            fixed_rate=params.get("fixed_rate", 0.0),
            convention=params.get("convention", "act360"),
            fixing_method=params.get("leg2_fixing_method", params.get("fixing_method", "rfr_payment_delay")),
            calendar=params.get("calendar"),
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = params.get("index")
        if index is not None:
            self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.spread(curves)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            disc = solver.get_curve_by_id(self._disc_curve_id)
            if self._forecast_curve_id and self._forecast_curve_id != self._disc_curve_id:
                forecast = solver.get_curve_by_id(self._forecast_curve_id)
                return [forecast, disc]
            return disc
        return solver.get_curve(0)

    def __repr__(self):
        return "ForwardRateAgreement(...)"


# Alias
FRA = ForwardRateAgreement


class ZeroCouponSwap:
    """Zero Coupon Swap: zero-coupon fixed vs floating leg."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "fixed_rate": fixed_rate,
            "notional": notional,
            "convention": convention,
            "fixing_method": fixing_method,
            "spread": spread,
            "calendar": calendar,
            "currency": currency,
        })
        if float_convention is not None:
            params["float_convention"] = float_convention
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)
        fconv = params.get("float_convention", params.get("leg2_convention", params.get("convention", "act360")))

        self._inner = PyZeroCouponSwap(
            effective=effective,
            termination=term_date,
            fixed_rate=params.get("fixed_rate", 0.0),
            notional=params.get("notional", 1_000_000.0),
            convention=params.get("convention", "act360"),
            float_convention=fconv,
            fixing_method=params.get("leg2_fixing_method", params.get("fixing_method", "rfr_payment_delay")),
            spread=params.get("spread", 0.0),
            calendar=params.get("calendar"),
            currency=params.get("currency", "USD"),
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = params.get("index")
        if index is not None:
            self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.spread(curves)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            disc = solver.get_curve_by_id(self._disc_curve_id)
            if self._forecast_curve_id and self._forecast_curve_id != self._disc_curve_id:
                forecast = solver.get_curve_by_id(self._forecast_curve_id)
                return [forecast, disc]
            return disc
        return solver.get_curve(0)

    def __repr__(self):
        return "ZeroCouponSwap(...)"


# Alias
ZCS = ZeroCouponSwap


class SingleBasisSwap:
    """Single Basis Swap: two floating legs with different indices."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        frequency: str = "q",
        leg2_frequency: str = "s",
        notional: float = 1_000_000.0,
        spread: float = 0.0,
        convention: str = "act360",
        leg2_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        leg2_fixing_method: Optional[str] = None,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: str = "USD",
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "frequency": frequency,
            "leg2_frequency": leg2_frequency,
            "notional": notional,
            "spread": spread,
            "convention": convention,
            "fixing_method": fixing_method,
            "calendar": calendar,
            "payment_lag": payment_lag,
            "currency": currency,
            "modifier": modifier,
            "stub": stub,
        })
        if leg2_convention is not None:
            params["leg2_convention"] = leg2_convention
        if leg2_fixing_method is not None:
            params["leg2_fixing_method"] = leg2_fixing_method
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PySingleBasisSwap(
            effective=effective,
            termination=term_date,
            frequency=_parse_frequency(params.get("frequency", "q")),
            leg2_frequency=_parse_frequency(params.get("leg2_frequency", "s")),
            notional=params.get("notional", 1_000_000.0),
            spread=params.get("spread", 0.0),
            convention=params.get("convention", "act360"),
            leg2_convention=params.get("leg2_convention", params.get("convention", "act360")),
            fixing_method=params.get("fixing_method", "rfr_payment_delay"),
            leg2_fixing_method=params.get("leg2_fixing_method", params.get("fixing_method", "rfr_payment_delay")),
            calendar=params.get("calendar"),
            payment_lag=params.get("payment_lag"),
            currency=params.get("currency", "USD"),
            modifier=_parse_modifier(params.get("modifier", "mf")),
            stub=params.get("stub", "shortfront"),
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = params.get("index")
        if index is not None:
            self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.spread(curves)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            disc = solver.get_curve_by_id(self._disc_curve_id)
            if self._forecast_curve_id and self._forecast_curve_id != self._disc_curve_id:
                forecast = solver.get_curve_by_id(self._forecast_curve_id)
                return [forecast, disc]
            return disc
        return solver.get_curve(0)

    def __repr__(self):
        return "SingleBasisSwap(...)"


# Alias
SBS = SingleBasisSwap


class OvernightIndexedSwap:
    """Overnight Indexed Swap: fixed vs RFR-compounded floating leg."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        frequency: str = "a",
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: str = "USD",
        amortization: Any = None,
        fixed_amortization: Any = None,
        float_amortization: Any = None,
        compounding_method: Optional[str] = None,
        lockout: Optional[int] = None,
        lookback: Optional[int] = None,
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "frequency": frequency,
            "fixed_rate": fixed_rate,
            "notional": notional,
            "convention": convention,
            "fixing_method": fixing_method,
            "spread": spread,
            "calendar": calendar,
            "payment_lag": payment_lag,
            "currency": currency,
            "modifier": modifier,
            "stub": stub,
        })
        if float_convention is not None:
            params["float_convention"] = float_convention
        if amortization is not None:
            params["amortization"] = amortization
        if fixed_amortization is not None:
            params["fixed_amortization"] = fixed_amortization
        if float_amortization is not None:
            params["float_amortization"] = float_amortization
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)
        fconv = params.get("float_convention", params.get("leg2_convention", params.get("convention", "act360")))
        fm = params.get("leg2_fixing_method", params.get("fixing_method", "rfr_payment_delay"))

        self._inner = PyOvernightIndexedSwap(
            effective=effective,
            termination=term_date,
            frequency=_parse_frequency(params.get("frequency", "a")),
            fixed_rate=params.get("fixed_rate", 0.0),
            notional=params.get("notional", 1_000_000.0),
            convention=params.get("convention", "act360"),
            float_convention=fconv,
            fixing_method=fm,
            spread=params.get("spread", 0.0),
            calendar=params.get("calendar"),
            payment_lag=params.get("payment_lag"),
            currency=params.get("currency", "USD"),
            amortization=params.get("amortization"),
            modifier=_parse_modifier(params.get("modifier", "mf")),
            stub=params.get("stub", "shortfront"),
            compounding_method=compounding_method,
            lockout=lockout,
            lookback=lookback,
            fixed_amortization=params.get("fixed_amortization"),
            float_amortization=params.get("float_amortization"),
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = params.get("index")
        if index is not None:
            self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id, self._forecast_curve_id)
        return self._inner.spread(curves)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            disc = solver.get_curve_by_id(self._disc_curve_id)
            if self._forecast_curve_id and self._forecast_curve_id != self._disc_curve_id:
                forecast = solver.get_curve_by_id(self._forecast_curve_id)
                return [forecast, disc]
            return disc
        return solver.get_curve(0)

    def __repr__(self):
        return "OvernightIndexedSwap(...)"


# Alias
OIS = OvernightIndexedSwap


class Deposit:
    """Deposit instrument for short-end calibration."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyDeposit(
            effective=effective,
            termination=term_date,
            rate=rate,
            notional=notional,
            convention=convention,
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "Deposit(...)"


class IRFuture:
    """STIR Futures instrument with convexity adjustment."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        price: float = 100.0,
        notional: float = 1_000_000.0,
        convexity_adjustment: float = 0.0,
        convention: str = "act360",
        quote_convention: str = "price",
        sigma: Optional[float] = None,
        tick_size: Optional[float] = None,
        notional_multiplier: Optional[float] = None,
        contract_size: Optional[float] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyIRFuture(
            effective=effective,
            termination=term_date,
            price=price,
            notional=notional,
            convexity_adjustment=convexity_adjustment,
            convention=convention,
            quote_convention=quote_convention,
            sigma=sigma,
            tick_size=tick_size,
            notional_multiplier=notional_multiplier,
            contract_size=contract_size,
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def _resolve_curves_from_solver(self, solver):
        if self._forecast_curve_id:
            return solver.get_curve_by_id(self._forecast_curve_id)
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "IRFuture(...)"


class CapFloor:
    """Cap/Floor instrument with Black-76 or Bachelier pricing.

    Pricing-only instrument (not available in Solver calibration).
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        strike: float = 0.0,
        vol: float = 0.0,
        notional: float = 1_000_000.0,
        frequency: str = "q",
        cap_floor_type: str = "cap",
        model: str = "black76",
        convention: str = "act360",
        currency: str = "USD",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyCapFloor(
            effective=effective,
            termination=term_date,
            strike=strike,
            vol=vol,
            notional=notional,
            frequency=_parse_frequency(frequency),
            cap_floor_type=cap_floor_type,
            model=model,
            convention=convention,
            currency=currency,
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = index

    def npv(self, disc_curve=None, forecast_curve=None, *, ctx=None):
        """Compute NPV of the cap/floor."""
        if ctx is not None and disc_curve is None:
            disc_curve = ctx.curve(self._disc_curve_id)
            forecast_curve = ctx.curve(self._forecast_curve_id)
        return self._inner.npv(disc_curve, forecast_curve)

    def cashflows(self, disc_curve=None, forecast_curve=None, *, ctx=None):
        """Per-caplet/floorlet cashflow decomposition."""
        if ctx is not None and disc_curve is None:
            disc_curve = ctx.curve(self._disc_curve_id)
            forecast_curve = ctx.curve(self._forecast_curve_id)
        rows = self._inner.cashflows(disc_curve, forecast_curve)
        return cashflows_to_polars(rows)

    def __repr__(self):
        return "CapFloor(...)"



__all__ = [
    "InterestRateSwap", "IRS",
    "ForwardRateAgreement", "FRA",
    "ZeroCouponSwap", "ZCS",
    "SingleBasisSwap", "SBS",
    "OvernightIndexedSwap", "OIS",
    "Deposit",
    "IRFuture",
    "CapFloor",
]
