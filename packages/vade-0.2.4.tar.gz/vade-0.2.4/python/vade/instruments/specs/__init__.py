"""
Instrument specification templates for market conventions.

Each spec is a dict of convention parameters that can be used to construct
instruments with standard market conventions. Users can register custom specs
at runtime via register_spec().

Spec keys follow the leg1/leg2 convention:
  - Top-level keys apply to leg1 (fixed leg for IRS, pay leg for SBS)
  - leg2_* keys apply to leg2 (float leg for IRS, receive leg for SBS)
  - Keys without leg2_ prefix are shared if leg2_ variant is absent

Common keys:
  frequency:     Payment frequency ("a", "s", "q", "m")
  stub:          Stub type ("shortfront", "longfront", "shortback", "longback")
  eom:           End-of-month rule (bool)
  modifier:      Business day modifier ("mf", "f", "p", "none")
  calendar:      Business calendar code ("nyc", "ldn", "tgt", ...)
  payment_lag:   Days between accrual end and payment (int)
  currency:      ISO currency code
  convention:    Day count convention ("act360", "act365f", "30e360", ...)
  index:         Fixing index name ("SOFR", "SONIA", "EURIBOR_6M", ...)
  notional_exchange: Whether notional is exchanged (bool)

  leg2_frequency, leg2_convention, leg2_fixing_method, leg2_spread_compound_method, etc.
"""

from __future__ import annotations

from typing import Any

from vade.instruments.specs.rates import RATES_SPECS
from vade.instruments.specs.fx import FX_SPECS
from vade.instruments.specs.credit import CREDIT_SPECS

# ---------------------------------------------------------------------------
# Instrument Specification Registry
# ---------------------------------------------------------------------------

INSTRUMENT_SPECS: dict[str, dict[str, Any]] = {
    **RATES_SPECS,
    **FX_SPECS,
    **CREDIT_SPECS,
}


# ---------------------------------------------------------------------------
# Registry API
# ---------------------------------------------------------------------------

def get_spec(name: str) -> dict[str, Any]:
    """
    Return the instrument spec dict for the given name.

    Parameters
    ----------
    name : str
        Spec name (e.g. "usd_irs", "eur_irs6").

    Returns
    -------
    dict
        A *copy* of the spec dict so callers can modify without side effects.

    Raises
    ------
    KeyError
        If the spec name is not found in the registry.
    """
    try:
        return dict(INSTRUMENT_SPECS[name])
    except KeyError:
        available = ", ".join(sorted(INSTRUMENT_SPECS.keys())[:10])
        raise KeyError(
            f"Unknown instrument spec '{name}'. "
            f"Available specs include: {available}, ... "
            f"({len(INSTRUMENT_SPECS)} total). Use list_specs() for full list."
        )


def register_spec(name: str, spec: dict[str, Any]) -> None:
    """
    Register a custom instrument spec at runtime.

    Parameters
    ----------
    name : str
        Spec name to register.
    spec : dict
        Convention dict with keys like frequency, convention, calendar, etc.
    """
    INSTRUMENT_SPECS[name] = dict(spec)


def list_specs() -> list[str]:
    """Return a sorted list of all available spec names."""
    return sorted(INSTRUMENT_SPECS.keys())


__all__ = ["INSTRUMENT_SPECS", "get_spec", "register_spec", "list_specs"]
