"""Instrument types for interest rate derivatives.

Supports spec-based construction with market convention templates,
flexible curve input, and solver= kwarg for auto-resolving calibrated curves.
"""
from vade.instruments.rates import (
    InterestRateSwap, IRS, ForwardRateAgreement, FRA,
    ZeroCouponSwap, ZCS, SingleBasisSwap, SBS,
    OvernightIndexedSwap, OIS, Deposit, IRFuture, CapFloor,
)
from vade.instruments.fx import (
    CrossCurrencySwap, XCS, FXForward, NDF, NDIRS, NDXCS,
)
from vade.instruments.credit import (
    FixedRateBond, Bill, FloatRateNote, ZeroCouponBond,
    StepUpBond, AmortizingBond, PIKBond, SubPeriodFRN,
    CappedFloatRateNote, CreditDefaultSwap, CDS,
    AssetSwap, CallableBond,
)

__all__ = [
    # rates
    "InterestRateSwap", "IRS",
    "ForwardRateAgreement", "FRA",
    "ZeroCouponSwap", "ZCS",
    "SingleBasisSwap", "SBS",
    "OvernightIndexedSwap", "OIS",
    "Deposit",
    "IRFuture",
    "CapFloor",
    # fx
    "CrossCurrencySwap", "XCS",
    "FXForward",
    "NDF",
    "NDIRS",
    "NDXCS",
    # credit
    "FixedRateBond",
    "Bill",
    "FloatRateNote",
    "ZeroCouponBond",
    "StepUpBond",
    "AmortizingBond",
    "PIKBond",
    "SubPeriodFRN",
    "CappedFloatRateNote",
    "CreditDefaultSwap", "CDS",
    "AssetSwap",
    "CallableBond",
]
