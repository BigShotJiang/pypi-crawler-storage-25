"""FX instrument classes: CrossCurrencySwap, FXForward, NDF, NDIRS, NDXCS."""
from __future__ import annotations

import datetime
from typing import Any, Optional, Union

from vade._vade_rs.instruments import (
    CrossCurrencySwap as _PyXCS,
    FXForward as _PyFXForward,
    NDF as _PyNDF,
    NDIRS as _PyNDIRS,
    NDXCS as _PyNDXCS,
)
from vade.instruments._helpers import (
    _parse_frequency,
    _parse_modifier,
    _parse_termination,
    _merge_spec_params,
    _resolve_xccy_from_context,
)
from vade.instruments.rates import InterestRateSwap  # D-07: NDIRS extends IRS
from vade.cashflows.dataframe import cashflows_to_polars

class CrossCurrencySwap:
    """Cross Currency Swap with 4-curve pricing model.

    Supports FixedFloat, FloatFloat, FixedFixed variants with
    notional exchange and MTM resets.
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        frequency: str = "q",
        leg1_currency: str = "EUR",
        leg2_currency: str = "USD",
        leg1_notional: float = 1_000_000.0,
        leg2_notional: float = 1_100_000.0,
        initial_fx_rate: float = 1.1,
        fixed_rate: Optional[float] = None,
        notional_exchange: bool = True,
        convention: str = "act360",
        leg2_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        modifier: str = "mf",
        stub: str = "shortfront",
        mtm_leg: Optional[int] = None,
        leg1_disc_curve_id: Optional[str] = None,
        leg1_forecast_curve_id: Optional[str] = None,
        leg2_disc_curve_id: Optional[str] = None,
        leg2_forecast_curve_id: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = _PyXCS(
            effective=effective,
            termination=term_date,
            frequency=_parse_frequency(frequency),
            leg1_currency=leg1_currency,
            leg2_currency=leg2_currency,
            leg1_notional=leg1_notional,
            leg2_notional=leg2_notional,
            initial_fx_rate=initial_fx_rate,
            fixed_rate=fixed_rate,
            notional_exchange=notional_exchange,
            convention=convention,
            leg2_convention=leg2_convention,
            fixing_method=fixing_method,
            spread=spread,
            modifier=_parse_modifier(modifier),
            stub=stub,
            mtm_leg=mtm_leg,
        )
        self._leg1_disc_curve_id = leg1_disc_curve_id
        self._leg1_forecast_curve_id = leg1_forecast_curve_id
        self._leg2_disc_curve_id = leg2_disc_curve_id
        self._leg2_forecast_curve_id = leg2_forecast_curve_id

    def rate(self, leg1_disc=None, leg1_forecast=None, leg2_disc=None, leg2_forecast=None, fx_rates=None, metric="leg2", *, ctx=None):
        """Compute par basis spread on specified leg (in basis points)."""
        if ctx is not None and leg1_disc is None:
            leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates = \
                _resolve_xccy_from_context(ctx, self._leg1_disc_curve_id, self._leg1_forecast_curve_id,
                                           self._leg2_disc_curve_id, self._leg2_forecast_curve_id)
        return self._inner.rate(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates, metric)

    def npv(self, leg1_disc=None, leg1_forecast=None, leg2_disc=None, leg2_forecast=None, fx_rates=None, *, ctx=None):
        """Compute NPV in leg1 currency."""
        if ctx is not None and leg1_disc is None:
            leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates = \
                _resolve_xccy_from_context(ctx, self._leg1_disc_curve_id, self._leg1_forecast_curve_id,
                                           self._leg2_disc_curve_id, self._leg2_forecast_curve_id)
        return self._inner.npv(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates)

    def cashflows(self, leg1_disc=None, leg1_forecast=None, leg2_disc=None, leg2_forecast=None, *, ctx=None):
        """Return cashflows as a Polars DataFrame."""
        if ctx is not None and leg1_disc is None:
            leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, _ = \
                _resolve_xccy_from_context(ctx, self._leg1_disc_curve_id, self._leg1_forecast_curve_id,
                                           self._leg2_disc_curve_id, self._leg2_forecast_curve_id)
        rows = self._inner.cashflows(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast)
        return cashflows_to_polars(rows)

    def __repr__(self):
        return "CrossCurrencySwap(...)"


# Alias
XCS = CrossCurrencySwap


class FXForward:
    """FX Forward instrument: single FX exchange at future delivery."""

    def __init__(
        self,
        *,
        pair: str = "eurusd",
        notional: float = 1_000_000.0,
        delivery: Optional[datetime.date] = None,
        currency: str = "USD",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        if delivery is None:
            raise ValueError("delivery date is required")

        self._inner = _PyFXForward(
            pair=pair,
            notional=notional,
            delivery=delivery,
            currency=currency,
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id

    def rate(self, disc_curve=None, forecast_curve=None, fx_rates=None, *, ctx=None):
        """Compute implied forward rate via IRP."""
        if ctx is not None and disc_curve is None:
            disc_curve = ctx.curve(self._disc_curve_id)
            forecast_curve = ctx.curve(self._forecast_curve_id)
            fx_rates = ctx.fx_rates
            if fx_rates is None:
                raise ValueError("ctx.fx_rates is required for FXForward pricing")
        return self._inner.rate(disc_curve, forecast_curve, fx_rates)

    def npv(self, disc_curve=None, forecast_curve=None, fx_rates=None, *, ctx=None):
        """Compute NPV from domestic perspective."""
        if ctx is not None and disc_curve is None:
            disc_curve = ctx.curve(self._disc_curve_id)
            forecast_curve = ctx.curve(self._forecast_curve_id)
            fx_rates = ctx.fx_rates
            if fx_rates is None:
                raise ValueError("ctx.fx_rates is required for FXForward pricing")
        return self._inner.npv(disc_curve, forecast_curve, fx_rates)

    def cashflows(self, disc_curve=None, forecast_curve=None, fx_rates=None, *, ctx=None):
        """Return cashflows as a Polars DataFrame."""
        if ctx is not None and disc_curve is None:
            disc_curve = ctx.curve(self._disc_curve_id)
            forecast_curve = ctx.curve(self._forecast_curve_id)
            fx_rates = ctx.fx_rates
            if fx_rates is None:
                raise ValueError("ctx.fx_rates is required for FXForward pricing")
        rows = self._inner.cashflows(disc_curve, forecast_curve, fx_rates)
        return cashflows_to_polars(rows)

    def __repr__(self):
        return "FXForward(...)"


class NDF(FXForward):
    """Non-Deliverable FX Forward: single-currency net settlement.

    An NDF is an FX forward where delivery is restricted -- instead of
    physical exchange, a net settlement amount is paid in a convertible
    settlement currency based on the difference between the contracted
    rate and the FX fixing rate at maturity.

    Direct construction::

        ndf = NDF(
            pair="usdbrl",
            notional=1_000_000.0,
            delivery=date(2026, 6, 15),
            settlement_currency="usd",
            contracted_rate=5.50,
        )

    Spec-based construction::

        ndf = NDF(spec="usdbrl_ndf", delivery=date(2026, 6, 15), contracted_rate=5.50)
    """

    def __init__(
        self,
        *,
        pair: str = "usdbrl",
        notional: float = 1_000_000.0,
        delivery: Optional[datetime.date] = None,
        settlement_currency: str = "usd",
        contracted_rate: Optional[float] = None,
        fx_fixing: Optional[float] = None,
        leg2_fx_fixing: Optional[float] = None,
        currency: Optional[str] = None,
        spec: Optional[str] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        if delivery is None:
            raise ValueError("delivery date is required")
        if contracted_rate is None:
            raise ValueError("contracted_rate is required for NDF")

        # Merge spec defaults if provided
        if spec is not None:
            from vade.instruments.specs import get_spec
            spec_defaults = get_spec(spec)
            pair = spec_defaults.get("pair", pair)
            settlement_currency = spec_defaults.get("settlement_currency", settlement_currency)
            if currency is None:
                currency = settlement_currency.upper()

        if currency is None:
            currency = settlement_currency.upper()

        # Bypass FXForward.__init__ -- construct _inner directly as PyNDFInstrument
        self._inner = _PyNDF(
            pair=pair,
            notional=notional,
            delivery=delivery,
            settlement_currency=settlement_currency,
            contracted_rate=contracted_rate,
            currency=currency,
            fx_fixing=fx_fixing,
            leg2_fx_fixing=leg2_fx_fixing,
        )
        self._pair = pair
        self._notional = notional
        self._settlement_currency = settlement_currency
        self._contracted_rate = contracted_rate
        self._fx_fixing = fx_fixing
        self._leg2_fx_fixing = leg2_fx_fixing
        self._delivery = delivery
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._index = index
        # FX fixing index: convention "{PAIR}_FIX" per D-11
        self._fx_fixing_index = self._pair.upper() + "_FIX"

    def spread(self, disc_curve=None, forecast_curve=None, fx_rates=None, *, ctx=None):
        """Return forward points: contracted_rate - implied_forward."""
        if ctx is not None and disc_curve is None:
            disc_curve = ctx.curve(self._disc_curve_id)
            forecast_curve = ctx.curve(self._forecast_curve_id)
            fx_rates = ctx.fx_rates
            if fx_rates is None:
                raise ValueError("ctx.fx_rates is required for NDF pricing")
        return self._inner.spread(disc_curve, forecast_curve, fx_rates)

    def pillar_date(self):
        """Return settlement date for solver calibration."""
        return self._inner.pillar_date()

    def to_json(self) -> str:
        """Serialize NDF to JSON with date-keyed fx_fixing.

        Format: {"fx_fixing": {"2026-06-15": 5.42}} when fx_fixing is set,
        or {"fx_fixing": null} when not set.
        """
        import json
        data = {
            "pair": self._pair,
            "notional": self._notional,
            "delivery": str(self._delivery),
            "settlement_currency": self._settlement_currency,
            "contracted_rate": self._contracted_rate,
        }
        # Date-keyed fx_fixing
        if self._fx_fixing is not None:
            data["fx_fixing"] = {str(self._delivery): self._fx_fixing}
        else:
            data["fx_fixing"] = None
        if self._leg2_fx_fixing is not None:
            data["leg2_fx_fixing"] = {str(self._delivery): self._leg2_fx_fixing}
        return json.dumps(data)

    @classmethod
    def from_json(cls, json_str: str) -> "NDF":
        """Deserialize NDF from JSON with date-keyed fx_fixing."""
        import json
        data = json.loads(json_str)
        fx_fixing = None
        if data.get("fx_fixing") is not None:
            fx_fixing = list(data["fx_fixing"].values())[0]
        leg2_fx_fixing = None
        if data.get("leg2_fx_fixing") is not None:
            leg2_fx_fixing = list(data["leg2_fx_fixing"].values())[0]
        delivery = datetime.date.fromisoformat(data["delivery"])
        return cls(
            pair=data.get("pair", "usdbrl"),
            notional=data.get("notional", 1_000_000.0),
            delivery=delivery,
            settlement_currency=data["settlement_currency"],
            contracted_rate=data["contracted_rate"],
            fx_fixing=fx_fixing,
            leg2_fx_fixing=leg2_fx_fixing,
        )

    def __repr__(self):
        return f"NDF(pair=..., delivery={self._delivery}, settlement_currency='{self._settlement_currency}')"


class NDIRS(InterestRateSwap):
    """Non-Deliverable Interest Rate Swap.

    An IRS where cashflows accrue in a restricted currency but settle
    in a convertible currency via per-period FX conversion.

    Direct construction::

        ndirs = NDIRS(
            effective=date(2024, 1, 1),
            termination="5Y",
            fixed_rate=10.0,
            settlement_currency="usd",
            pair="usdbrl",
            notional=1_000_000.0,
        )

    Spec-based construction::

        ndirs = NDIRS(spec="usdbrl_ndirs", effective=date(2024, 1, 1),
                       termination="5Y", fixed_rate=10.0)
    """

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        frequency: str = "s",
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: Optional[str] = None,
        settlement_currency: str = "usd",
        pair: str = "usdbrl",
        fx_fixings: Optional[dict] = None,
        amortization: Any = None,
        fixed_amortization: Any = None,
        float_amortization: Any = None,
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        leg2_disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        # Merge spec defaults
        params = _merge_spec_params(spec, {
            "frequency": frequency,
            "fixed_rate": fixed_rate,
            "notional": notional,
            "convention": convention,
            "fixing_method": fixing_method,
            "spread": spread,
            "calendar": calendar,
            "payment_lag": payment_lag,
            "currency": currency,
            "modifier": modifier,
            "stub": stub,
            "settlement_currency": settlement_currency,
            "pair": pair,
        })
        if float_convention is not None:
            params["float_convention"] = float_convention
        if amortization is not None:
            params["amortization"] = amortization
        if fixed_amortization is not None:
            params["fixed_amortization"] = fixed_amortization
        if float_amortization is not None:
            params["float_amortization"] = float_amortization
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)
        settle_ccy = params.get("settlement_currency", "usd")
        nd_pair = params.get("pair", "usdbrl")

        # If currency not specified, derive restricted currency from pair RHS
        if params.get("currency") is None:
            params["currency"] = nd_pair[3:6].upper()

        fconv = params.get("float_convention", params.get("leg2_convention", params.get("convention", "act360")))
        fm = params.get("leg2_fixing_method", params.get("fixing_method", "rfr_payment_delay"))

        # Convert fx_fixings dict keys to proper format if needed
        fx_fix = None
        if fx_fixings is not None:
            fx_fix = {k: float(v) for k, v in fx_fixings.items()}

        # Bypass IRS.__init__ -- construct _inner directly as PyNDIRSInstrument
        self._inner = _PyNDIRS(
            effective=effective,
            termination=term_date,
            frequency=_parse_frequency(params.get("frequency", "s")),
            fixed_rate=params.get("fixed_rate", 0.0),
            notional=params.get("notional", 1_000_000.0),
            convention=params.get("convention", "act360"),
            float_convention=fconv,
            fixing_method=fm,
            spread=params.get("spread", 0.0),
            settlement_currency=settle_ccy,
            pair=nd_pair,
            currency=params.get("currency", "BRL"),
            modifier=_parse_modifier(params.get("modifier", "mf")),
            stub=params.get("stub", "shortfront"),
            calendar=params.get("calendar"),
            payment_lag=params.get("payment_lag"),
            fx_fixings=fx_fix,
            amortization=params.get("amortization"),
            fixed_amortization=params.get("fixed_amortization"),
            float_amortization=params.get("float_amortization"),
        )
        self._disc_curve_id = disc_curve_id
        self._forecast_curve_id = forecast_curve_id
        self._leg2_disc_curve_id = leg2_disc_curve_id
        self._index = params.get("index")
        if index is not None:
            self._index = index
        # FX fixing index per D-11
        self._fx_fixing_index = nd_pair.upper() + "_FIX"
        # Store for JSON serialization
        self._settlement_currency = settle_ccy
        self._pair = nd_pair
        self._fx_fixings = fx_fixings
        self._effective = effective
        self._termination = termination
        self._fixed_rate = params.get("fixed_rate", 0.0)
        self._notional = params.get("notional", 1_000_000.0)
        self._spec = spec

    def rate(self, curves=None, *, solver=None, fx_rates=None, ctx=None):
        """Par fixed rate making settlement-currency NPV = 0."""
        disc, forecast, leg2_disc = self._resolve_3curves(curves, solver, ctx=ctx)
        if fx_rates is None and ctx is not None:
            fx_rates = ctx.fx_rates
        if fx_rates is None:
            raise ValueError("fx_rates is required for NDIRS")
        return self._inner.rate(disc, forecast, leg2_disc, fx_rates)

    def npv(self, curves=None, *, solver=None, fx_rates=None, ctx=None):
        """Settlement-currency NPV with per-period FX conversion."""
        disc, forecast, leg2_disc = self._resolve_3curves(curves, solver, ctx=ctx)
        if fx_rates is None and ctx is not None:
            fx_rates = ctx.fx_rates
        if fx_rates is None:
            raise ValueError("fx_rates is required for NDIRS")
        return self._inner.npv(disc, forecast, leg2_disc, fx_rates)

    def cashflows(self, curves=None, *, solver=None, fx_rates=None, ctx=None):
        """Cashflows with both restricted and settlement currency amounts."""
        disc, forecast, leg2_disc = self._resolve_3curves(curves, solver, ctx=ctx)
        if fx_rates is None and ctx is not None:
            fx_rates = ctx.fx_rates
        if fx_rates is None:
            raise ValueError("fx_rates is required for NDIRS")
        rows = self._inner.cashflows(disc, forecast, leg2_disc, fx_rates)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, fx_rates=None, ctx=None):
        """Spread on float leg making settlement-currency NPV = 0."""
        disc, forecast, leg2_disc = self._resolve_3curves(curves, solver, ctx=ctx)
        if fx_rates is None and ctx is not None:
            fx_rates = ctx.fx_rates
        if fx_rates is None:
            raise ValueError("fx_rates is required for NDIRS")
        return self._inner.spread(disc, forecast, leg2_disc, fx_rates)

    def pillar_date(self):
        """Maturity date for solver calibration."""
        return self._inner.pillar_date()

    def _resolve_3curves(self, curves, solver, ctx=None):
        """Resolve 3 curves: disc (settlement), forecast (restricted), leg2_disc (restricted disc)."""
        if solver is not None:
            disc = solver.curves.get(self._disc_curve_id) if self._disc_curve_id else None
            forecast = solver.curves.get(self._forecast_curve_id) if self._forecast_curve_id else None
            leg2_disc = solver.curves.get(self._leg2_disc_curve_id) if self._leg2_disc_curve_id else None
            if disc is None or forecast is None or leg2_disc is None:
                raise ValueError("NDIRS requires disc_curve_id, forecast_curve_id, and leg2_disc_curve_id for solver resolution")
            return disc, forecast, leg2_disc
        if ctx is not None and curves is None:
            disc = ctx.curve(self._disc_curve_id)
            forecast = ctx.curve(self._forecast_curve_id)
            leg2_disc = ctx.curve(self._leg2_disc_curve_id)
            return disc, forecast, leg2_disc
        if curves is None or len(curves) < 3:
            raise ValueError("NDIRS requires 3 curves: [settlement_disc, restricted_forecast, restricted_disc]")
        return curves[0], curves[1], curves[2]

    def to_json(self) -> str:
        """Serialize NDIRS to JSON with date-keyed fx_fixings."""
        import json
        data = {
            "type": "NDIRS",
            "effective": self._effective.isoformat() if self._effective else None,
            "termination": str(self._termination),
            "fixed_rate": self._fixed_rate,
            "notional": self._notional,
            "settlement_currency": self._settlement_currency,
            "pair": self._pair,
            "spec": self._spec,
        }
        if self._fx_fixings:
            data["fx_fixings"] = {k.isoformat(): v for k, v in self._fx_fixings.items()}
        return json.dumps(data)

    @classmethod
    def from_json(cls, json_str: str) -> "NDIRS":
        """Deserialize NDIRS from JSON."""
        import json
        data = json.loads(json_str)
        fx_fixings = None
        if "fx_fixings" in data and data["fx_fixings"]:
            fx_fixings = {datetime.date.fromisoformat(k): v for k, v in data["fx_fixings"].items()}
        effective = datetime.date.fromisoformat(data["effective"]) if data.get("effective") else None
        return cls(
            spec=data.get("spec"),
            effective=effective,
            termination=data.get("termination"),
            fixed_rate=data.get("fixed_rate", 0.0),
            notional=data.get("notional", 1_000_000.0),
            settlement_currency=data.get("settlement_currency", "usd"),
            pair=data.get("pair", "usdbrl"),
            fx_fixings=fx_fixings,
        )

    def __repr__(self):
        return f"NDIRS(settlement_currency='{self._settlement_currency}', pair='{self._pair}')"


class NDXCS(CrossCurrencySwap):
    """Non-Deliverable Cross-Currency Swap.

    A cross-currency swap where one leg is non-deliverable -- cashflows
    accrue in a restricted currency but settle in a convertible currency
    via per-period FX conversion. Supports notional exchanges and MTM
    resets on the ND leg with FX fixing conversion.

    Direct construction::

        ndxcs = NDXCS(
            effective=date(2024, 1, 1),
            termination="5Y",
            leg1_currency="USD",
            leg2_currency="BRL",
            settlement_currency="usd",
            nd_leg=2,
            pair="usdbrl",
            leg1_notional=1_000_000.0,
            leg2_notional=5_000_000.0,
            initial_fx_rate=5.0,
        )

    Spec-based construction::

        ndxcs = NDXCS(spec="usdbrl_ndxcs", effective=date(2024, 1, 1),
                       termination="5Y")
    """

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        frequency: str = "q",
        leg1_currency: str = "USD",
        leg2_currency: str = "BRL",
        leg1_notional: float = 1_000_000.0,
        leg2_notional: float = 5_000_000.0,
        initial_fx_rate: float = 5.0,
        fixed_rate: Optional[float] = None,
        notional_exchange: bool = True,
        convention: str = "act360",
        leg2_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        modifier: str = "mf",
        stub: str = "shortfront",
        mtm_leg: Optional[int] = None,
        settlement_currency: str = "usd",
        nd_leg: int = 2,
        pair: Optional[str] = None,
        fx_fixings: Optional[dict] = None,
        calendar: Optional[str] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        leg2_disc_curve_id: Optional[str] = None,
        leg2_forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        # Merge spec defaults
        params = _merge_spec_params(spec, {
            "frequency": frequency,
            "leg1_currency": leg1_currency,
            "leg2_currency": leg2_currency,
            "leg1_notional": leg1_notional,
            "leg2_notional": leg2_notional,
            "initial_fx_rate": initial_fx_rate,
            "notional_exchange": notional_exchange,
            "convention": convention,
            "fixing_method": fixing_method,
            "spread": spread,
            "modifier": modifier,
            "stub": stub,
            "settlement_currency": settlement_currency,
            "nd_leg": nd_leg,
            "calendar": calendar,
        })
        if fixed_rate is not None:
            params["fixed_rate"] = fixed_rate
        if leg2_convention is not None:
            params["leg2_convention"] = leg2_convention
        if mtm_leg is not None:
            params["mtm_leg"] = mtm_leg
        if pair is not None:
            params["pair"] = pair
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        # Derive pair from currencies if not specified
        nd_pair = params.get("pair")
        if nd_pair is None:
            nd_pair = (params["leg1_currency"] + params["leg2_currency"]).lower()

        conv2 = params.get("leg2_convention", params.get("convention", "act360"))

        # Convert fx_fixings dict keys to proper format if needed
        nd_fx_fix = None
        if fx_fixings is not None:
            nd_fx_fix = {k: float(v) for k, v in fx_fixings.items()}

        # Bypass CrossCurrencySwap.__init__ -- construct _inner directly as PyNDXCSInstrument
        self._inner = _PyNDXCS(
            effective=effective,
            termination=term_date,
            frequency=_parse_frequency(params.get("frequency", "q")),
            leg1_currency=params.get("leg1_currency", "USD"),
            leg2_currency=params.get("leg2_currency", "BRL"),
            leg1_notional=params.get("leg1_notional", 1_000_000.0),
            leg2_notional=params.get("leg2_notional", 5_000_000.0),
            initial_fx_rate=params.get("initial_fx_rate", 5.0),
            fixed_rate=params.get("fixed_rate"),
            notional_exchange=params.get("notional_exchange", True),
            convention=params.get("convention", "act360"),
            leg2_convention=conv2 if conv2 != params.get("convention", "act360") else None,
            fixing_method=params.get("fixing_method", "rfr_payment_delay"),
            spread=params.get("spread", 0.0),
            modifier=_parse_modifier(params.get("modifier", "mf")),
            stub=params.get("stub", "shortfront"),
            mtm_leg=params.get("mtm_leg"),
            settlement_currency=params.get("settlement_currency", "usd"),
            nd_leg=params.get("nd_leg", 2),
            calendar=params.get("calendar"),
            nd_fx_fixings=nd_fx_fix,
        )

        # Store construction params for JSON serialization
        self._effective = effective
        self._termination = termination
        self._spec = spec
        self._fx_fixings = fx_fixings
        self._params = params
        self._leg1_disc_curve_id = disc_curve_id
        self._leg1_forecast_curve_id = forecast_curve_id
        self._leg2_disc_curve_id = leg2_disc_curve_id
        self._leg2_forecast_curve_id = leg2_forecast_curve_id
        self._index = params.get("index")
        if index is not None:
            self._index = index
        self._fx_fixing_index = nd_pair.upper() + "_FIX"

    def rate(self, leg1_disc=None, leg1_forecast=None, leg2_disc=None, leg2_forecast=None, fx_rates=None, *, ctx=None):
        """Compute par basis spread on the ND leg (basis points)."""
        if ctx is not None and leg1_disc is None:
            leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates = \
                _resolve_xccy_from_context(ctx, self._leg1_disc_curve_id, self._leg1_forecast_curve_id,
                                           self._leg2_disc_curve_id, self._leg2_forecast_curve_id)
        return self._inner.rate(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates)

    def npv(self, leg1_disc=None, leg1_forecast=None, leg2_disc=None, leg2_forecast=None, fx_rates=None, *, ctx=None):
        """Compute NPV in settlement currency."""
        if ctx is not None and leg1_disc is None:
            leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates = \
                _resolve_xccy_from_context(ctx, self._leg1_disc_curve_id, self._leg1_forecast_curve_id,
                                           self._leg2_disc_curve_id, self._leg2_forecast_curve_id)
        return self._inner.npv(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates)

    def cashflows(self, leg1_disc=None, leg1_forecast=None, leg2_disc=None, leg2_forecast=None, fx_rates=None, *, ctx=None):
        """Return cashflows as a Polars DataFrame with settlement columns for ND leg."""
        if ctx is not None and leg1_disc is None:
            leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates = \
                _resolve_xccy_from_context(ctx, self._leg1_disc_curve_id, self._leg1_forecast_curve_id,
                                           self._leg2_disc_curve_id, self._leg2_forecast_curve_id)
        rows = self._inner.cashflows(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates)
        return cashflows_to_polars(rows)

    def spread(self, leg1_disc=None, leg1_forecast=None, leg2_disc=None, leg2_forecast=None, fx_rates=None, *, ctx=None):
        """Compute par floating spread on the ND leg."""
        if ctx is not None and leg1_disc is None:
            leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates = \
                _resolve_xccy_from_context(ctx, self._leg1_disc_curve_id, self._leg1_forecast_curve_id,
                                           self._leg2_disc_curve_id, self._leg2_forecast_curve_id)
        return self._inner.spread(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates)

    def pillar_date(self):
        """Return the pillar date for solver calibration."""
        return self._inner.pillar_date()

    def to_json(self):
        """Serialize to JSON dict with date-keyed fx_fixings (per D-10)."""
        data = {
            "type": "NDXCS",
            "effective": self._effective.isoformat() if self._effective else None,
            "termination": str(self._termination),
            "spec": self._spec,
        }
        # Include construction params
        for k, v in self._params.items():
            if k not in data:
                data[k] = v
        # Serialize fx_fixings as date-keyed dict
        if self._fx_fixings is not None:
            data["fx_fixings"] = {
                k.isoformat() if hasattr(k, "isoformat") else str(k): v
                for k, v in self._fx_fixings.items()
            }
        return data

    @classmethod
    def from_json(cls, data):
        """Deserialize from JSON dict."""
        d = dict(data)
        d.pop("type", None)
        eff = d.pop("effective", None)
        if isinstance(eff, str):
            eff = datetime.date.fromisoformat(eff)
        term = d.pop("termination", None)
        fx_fix = d.pop("fx_fixings", None)
        if fx_fix is not None:
            fx_fix = {
                datetime.date.fromisoformat(k) if isinstance(k, str) else k: float(v)
                for k, v in fx_fix.items()
            }
        return cls(effective=eff, termination=term, fx_fixings=fx_fix, **d)

    def __repr__(self):
        return f"NDXCS(settlement_currency='{self._params.get('settlement_currency', '?')}', nd_leg={self._params.get('nd_leg', '?')})"




__all__ = [
    "CrossCurrencySwap", "XCS",
    "FXForward",
    "NDF",
    "NDIRS",
    "NDXCS",
]
