"""Type stubs for vade.solver module."""

from typing import List, Optional, Tuple, Union

import numpy as np
import polars as pl

from vade.curves import DiscountCurve, LineCurve

Curve = Union[DiscountCurve, LineCurve]


class SolverResult:
    """Result of solver calibration."""

    @property
    def converged(self) -> bool: ...
    @property
    def iterations(self) -> int: ...
    @property
    def objective(self) -> float: ...
    @property
    def residuals(self) -> list[float]: ...
    @property
    def jacobian(self) -> np.ndarray:
        """2D numpy array with shape (n_instruments, n_vars)."""
        ...
    @property
    def condition_number(self) -> float: ...
    @property
    def status(self) -> str: ...
    @property
    def time_seconds(self) -> float: ...
    @property
    def algorithm(self) -> str:
        """Name of the optimization algorithm used."""
        ...
    def __repr__(self) -> str: ...


class Solver:
    """Solver for curve calibration with selectable optimization algorithm."""

    def __init__(
        self,
        *,
        curves: list[Curve],
        instruments: list[tuple],
        weights: Optional[list[float]] = None,
        func_tol: float = 1e-14,
        grad_tol: float = 1e-14,
        max_iter: int = 100,
        ini_lambda: Optional[Tuple[float, float, float]] = None,
        pre_solvers: Optional[list["Solver"]] = None,
        fx_rates: ... = None,
        algorithm: str = "levenberg_marquardt",
        learning_rate: Optional[float] = None,
    ) -> None: ...
    def iterate(self) -> SolverResult: ...
    def get_curve(self, index: int = 0) -> Curve: ...
    def get_curve_by_id(self, curve_id: str) -> Curve: ...
    def delta(self, instrument: Union[object, list], result: SolverResult) -> pl.DataFrame:
        """Compute delta risk. Returns DataFrame with columns: instrument_label, tenor, sensitivity, currency."""
        ...
    def gamma(self, instrument: Union[object, list], result: SolverResult) -> pl.DataFrame:
        """Compute cross-gamma matrix. Returns labeled DataFrame."""
        ...
    def to_json(self) -> str: ...
    @staticmethod
    def from_json(s: str) -> "Solver": ...
    def __repr__(self) -> str: ...


def bootstrap(
    curves: list,
    instruments: list,
    target_curve_idx: int,
    tol: Optional[float] = None,
    max_outer: Optional[int] = None,
    max_brent: Optional[int] = None,
    bracket_low: Optional[float] = None,
    bracket_high: Optional[float] = None,
) -> object:
    """Iterative bootstrap calibration (node-by-node Brent root-finding).

    Args:
        curves: List of curve objects to calibrate.
        instruments: List of dicts with keys: 'instrument' (Rust binding),
            'target' (float), 'disc_curve_idx' (int), optional 'forecast_curve_idx',
            optional 'label'.
        target_curve_idx: Index of the curve to calibrate in the curves list.
        tol: Root-finding tolerance (default: 1e-12).
        max_outer: Maximum outer iterations for global interpolators.
        max_brent: Maximum Brent iterations per node.
        bracket_low: Lower bracket for Brent search.
        bracket_high: Upper bracket for Brent search.

    Returns:
        The calibrated curve (same type as curves[target_curve_idx]).
    """
    ...
