"""Solver for curve calibration using Levenberg-Marquardt, Gauss-Newton, or Gradient Descent.

The Solver calibrates curve nodes to match a set of instrument target rates
using AD-driven Jacobian extraction and iterative optimization.

Usage::

    from vade import Solver, IRS, DiscountCurve

    # Default: Levenberg-Marquardt
    solver = Solver(curves=[curve], instruments=[(irs1, 3.0)])
    result = solver.iterate()

    # Gauss-Newton
    solver = Solver(curves=[curve], instruments=[(irs1, 3.0)], algorithm='gauss_newton')

    # Gradient Descent
    solver = Solver(curves=[curve], instruments=[(irs1, 3.0)], algorithm='gradient_descent')
"""

from __future__ import annotations

from typing import Any, List, Optional, Tuple

import numpy as np

from vade._vade_rs.solver import PySolver, PySolverResult, bootstrap


class SolverResult:
    """Result of solver calibration with convergence diagnostics."""

    def __init__(self, inner: PySolverResult):
        self._inner = inner

    @property
    def converged(self) -> bool:
        """Whether the solver converged."""
        return self._inner.converged

    @property
    def iterations(self) -> int:
        """Number of iterations performed."""
        return self._inner.iterations

    @property
    def objective(self) -> float:
        """Final objective value (sum of weighted squared residuals)."""
        return self._inner.objective

    @property
    def residuals(self) -> list[float]:
        """Final residuals (rate - target for each instrument)."""
        return self._inner.residuals

    @property
    def jacobian(self) -> np.ndarray:
        """Jacobian matrix as numpy 2D array (n_instruments x n_vars)."""
        return np.asarray(self._inner.jacobian)

    @property
    def condition_number(self) -> float:
        """Condition number estimate of the Jacobian."""
        return self._inner.condition_number

    @property
    def status(self) -> str:
        """Status message describing termination reason."""
        return self._inner.status

    @property
    def time_seconds(self) -> float:
        """Wall-clock time in seconds."""
        return self._inner.time_seconds

    @property
    def algorithm(self) -> str:
        """Name of the optimization algorithm used."""
        return self._inner.algorithm

    def __repr__(self) -> str:
        return f"SolverResult(converged={self.converged}, iterations={self.iterations}, objective={self.objective:.2e}, algorithm='{self.algorithm}')"


class Solver:
    """Solver for curve calibration with selectable optimization algorithm.

    Parameters
    ----------
    curves : list
        List of DiscountCurve/LineCurve to calibrate.
    instruments : list of (instrument, target_rate) tuples
        Instruments with their target rates.
    weights : list of float, optional
        Weights for each instrument (default: all 1.0).
    func_tol : float
        Objective function convergence tolerance.
    grad_tol : float
        Gradient convergence tolerance.
    max_iter : int
        Maximum number of iterations.
    ini_lambda : tuple of (float, float, float), optional
        (initial_lambda, success_scale, failure_scale) for LM damping.
        Only valid with algorithm='levenberg_marquardt'.
    pre_solvers : list of Solver, optional
        Pre-solver chain for multi-curve calibration.
    algorithm : str
        Optimization algorithm: 'levenberg_marquardt' (default), 'gauss_newton',
        or 'gradient_descent'.
    learning_rate : float, optional
        Learning rate for gradient descent. Only valid with algorithm='gradient_descent'.
        Default is 1.0 (full step with Armijo backtracking).
    """

    def __init__(
        self,
        *,
        curves: list,
        instruments: list,
        weights: Optional[list[float]] = None,
        func_tol: float = 1e-14,
        grad_tol: float = 1e-14,
        max_iter: int = 100,
        ini_lambda: Optional[Tuple[float, float, float]] = None,
        pre_solvers: Optional[list] = None,
        fx_rates=None,
        algorithm: str = "levenberg_marquardt",
        learning_rate: Optional[float] = None,
    ):
        # Extract inner Rust objects from Python wrapper instruments
        # Supports two formats:
        #   Tuple: (instrument, target[, curve_idx[, label[, currency]]])
        #   Dict:  {"instrument": inst, "target": float, "disc_curve_idx": int, ...}
        rust_instruments = []
        for i, item in enumerate(instruments):
            if isinstance(item, dict):
                # Dict format: supports leg2 indices for XCS 4-curve model
                d = {
                    "instrument": item["instrument"]._inner,
                    "target": float(item["target"]),
                    "disc_curve_idx": int(item.get("disc_curve_idx", 0)),
                }
                if "forecast_curve_idx" in item:
                    d["forecast_curve_idx"] = int(item["forecast_curve_idx"])
                if "leg2_disc_curve_idx" in item:
                    d["leg2_disc_curve_idx"] = int(item["leg2_disc_curve_idx"])
                if "leg2_forecast_curve_idx" in item:
                    d["leg2_forecast_curve_idx"] = int(item["leg2_forecast_curve_idx"])
                d["label"] = str(item.get("label", f"inst_{i}"))
                d["currency"] = str(item.get("currency", "USD"))
                rust_instruments.append(d)
            elif len(item) == 2:
                inst, target = item
                label = getattr(inst, '_label', f"inst_{i}")
                currency = getattr(inst, '_currency', "USD")
                rust_instruments.append((inst._inner, float(target), 0, label, currency))
            elif len(item) == 3:
                inst, target, curve_idx = item
                label = getattr(inst, '_label', f"inst_{i}")
                currency = getattr(inst, '_currency', "USD")
                rust_instruments.append((inst._inner, float(target), int(curve_idx), label, currency))
            elif len(item) == 4:
                inst, target, curve_idx, label = item
                currency = getattr(inst, '_currency', "USD")
                rust_instruments.append((inst._inner, float(target), int(curve_idx), str(label), currency))
            elif len(item) == 5:
                inst, target, curve_idx, label, currency = item
                rust_instruments.append((inst._inner, float(target), int(curve_idx), str(label), str(currency)))
            else:
                raise ValueError("Each instrument must be a tuple (instrument, target_rate[, ...]) or a dict")

        # Extract inner Rust pre-solvers
        rust_pre_solvers = None
        if pre_solvers:
            rust_pre_solvers = [ps._inner for ps in pre_solvers]

        # FXRates is directly a Rust PyFXRates (no Python wrapper)
        rust_fx_rates = fx_rates

        self._inner = PySolver(
            curves=curves,
            instruments=rust_instruments,
            weights=weights,
            func_tol=func_tol,
            grad_tol=grad_tol,
            max_iter=max_iter,
            ini_lambda=ini_lambda,
            pre_solvers=rust_pre_solvers,
            fx_rates=rust_fx_rates,
            algorithm=algorithm,
            learning_rate=learning_rate,
        )

    def iterate(self) -> SolverResult:
        """Run optimization iteration to calibrate curves."""
        raw_result = self._inner.iterate()
        return SolverResult(raw_result)

    def get_curve(self, index: int = 0):
        """Get calibrated curve by index."""
        return self._inner.get_curve(index)

    def get_curve_by_id(self, curve_id: str):
        """Get calibrated curve by its string ID."""
        return self._inner.get_curve_by_id(curve_id)

    @property
    def curve_ids(self) -> list[str]:
        """Return list of string IDs for all curves in the solver."""
        return self._inner.curve_ids()

    def delta(
        self,
        instrument,
        result: SolverResult,
    ):
        """Compute delta risk sensitivities.

        Returns Polars DataFrame with columns:
            instrument_label, tenor, sensitivity, currency

        Parameters
        ----------
        instrument : Instrument or list[Instrument]
            Single instrument or list for portfolio-level aggregation.
        result : SolverResult
            Result from solver.iterate() (provides Jacobian).
        """
        import polars as pl

        jacobian = result.jacobian.tolist()
        labels = self._inner.instrument_labels()
        tenors = self._inner.instrument_tenors()
        currencies = self._inner.instrument_currencies()

        if isinstance(instrument, list):
            sensitivities = np.zeros(len(labels))
            for inst in instrument:
                raw = self._inner.delta(inst._inner, jacobian)
                sensitivities += np.array(raw)
            sensitivities = sensitivities.tolist()
        else:
            sensitivities = self._inner.delta(instrument._inner, jacobian)

        return pl.DataFrame({
            "instrument_label": labels,
            "tenor": tenors,
            "sensitivity": sensitivities,
            "currency": currencies,
        })

    def gamma(
        self,
        instrument,
        result: SolverResult,
    ):
        """Compute cross-gamma matrix.

        Returns Polars DataFrame with labeled cross-gamma matrix.
        Rows and columns indexed by calibrating instrument labels.

        Parameters
        ----------
        instrument : Instrument or list[Instrument]
            Single instrument or list for portfolio-level aggregation.
        result : SolverResult
            Result from solver.iterate() (provides Jacobian).
        """
        import polars as pl

        jacobian = result.jacobian.tolist()
        labels = self._inner.instrument_labels()

        if isinstance(instrument, list):
            gamma_matrix = None
            for inst in instrument:
                raw = self._inner.gamma(inst._inner, jacobian)
                mat = np.array(raw)
                gamma_matrix = mat if gamma_matrix is None else gamma_matrix + mat
            gamma_matrix = gamma_matrix.tolist()
        else:
            gamma_matrix = self._inner.gamma(instrument._inner, jacobian)

        data = {"label": labels}
        for i, lbl in enumerate(labels):
            data[lbl] = [row[i] for row in gamma_matrix]

        return pl.DataFrame(data)

    def to_json(self) -> str:
        """Serialize solver state (curves and instruments) to JSON string."""
        return self._inner.to_json()

    @classmethod
    def from_json(cls, s: str) -> "Solver":
        """Deserialize solver from JSON string."""
        obj = cls.__new__(cls)
        obj._inner = PySolver.from_json(s)
        return obj

    def __repr__(self) -> str:
        return repr(self._inner)


__all__ = ["Solver", "SolverResult", "bootstrap"]
