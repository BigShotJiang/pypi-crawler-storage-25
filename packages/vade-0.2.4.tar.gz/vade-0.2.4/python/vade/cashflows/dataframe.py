"""DataFrame construction from CashflowRow list."""

from __future__ import annotations

from typing import TYPE_CHECKING

import polars as pl

if TYPE_CHECKING:
    import pandas as pd


def cashflows_to_polars(rows: list) -> pl.DataFrame:
    """Convert a list of CashflowRow objects to a Polars DataFrame.

    Columns: Type, start, end, payment, Ccy, Notional, fixing_rate,
             Rate, Spread, DCF, Cashflow, DF, NPV.

    DF and NPV columns are only present when the rows were generated
    with a curve (i.e., row.df is not None).

    When AD types (Dual/Dual2) are present in Cashflow/DF/NPV columns,
    those columns use pl.Object dtype to preserve the AD values.
    """
    if not rows:
        return pl.DataFrame()

    # Detect whether curve was provided (DF/NPV columns present)
    has_curve = rows[0].df is not None

    # Detect AD types by checking if cashflow is a plain float
    has_ad = False
    if has_curve:
        for row in rows:
            if row.npv is not None and not isinstance(row.npv, (int, float)):
                has_ad = True
                break

    # Build column data
    data: dict[str, list] = {
        "Type": [r.period_type for r in rows],
        "start": [r.start for r in rows],
        "end": [r.end for r in rows],
        "payment": [r.payment for r in rows],
        "Ccy": [r.currency for r in rows],
        "Notional": [r.notional for r in rows],
        "fixing_rate": [
            _number_value(r.fixing_rate) for r in rows
        ],
        "Rate": [r.rate for r in rows],
        "Spread": [r.spread for r in rows],
        "DCF": [r.dcf for r in rows],
        "Cashflow": [r.cashflow for r in rows] if has_ad else [
            _number_value(r.cashflow) for r in rows
        ],
    }

    if has_curve:
        data["DF"] = [r.df for r in rows] if has_ad else [
            _number_value(r.df) for r in rows
        ]
        data["NPV"] = [r.npv for r in rows] if has_ad else [
            _number_value(r.npv) for r in rows
        ]

    # NDIRS settlement columns (only present when any row has settlement data)
    has_settlement = any(
        getattr(r, "settlement_currency_label", None) is not None for r in rows
    )
    if has_settlement:
        data["FX_Rate"] = [getattr(r, "fx_rate", None) for r in rows]
        data["Settlement_Amount"] = [
            _number_value(getattr(r, "settlement_amount", None)) for r in rows
        ]
        data["Settlement_Ccy"] = [
            getattr(r, "settlement_currency_label", None) for r in rows
        ]

    # Determine schema
    schema: dict[str, pl.DataType] = {}
    schema["Type"] = pl.Utf8
    schema["start"] = pl.Date
    schema["end"] = pl.Date
    schema["payment"] = pl.Date
    schema["Ccy"] = pl.Utf8
    schema["Notional"] = pl.Float64
    schema["fixing_rate"] = pl.Float64
    schema["Rate"] = pl.Float64
    schema["Spread"] = pl.Float64
    schema["DCF"] = pl.Float64

    if has_ad:
        schema["Cashflow"] = pl.Object
        if has_curve:
            schema["DF"] = pl.Object
            schema["NPV"] = pl.Object
    else:
        schema["Cashflow"] = pl.Float64
        if has_curve:
            schema["DF"] = pl.Float64
            schema["NPV"] = pl.Float64

    if has_settlement:
        schema["FX_Rate"] = pl.Float64
        schema["Settlement_Amount"] = pl.Float64
        schema["Settlement_Ccy"] = pl.Utf8

    return pl.DataFrame(data, schema=schema)


def cashflows_to_pandas(rows: list) -> "pd.DataFrame":
    """Convert a list of CashflowRow objects to a pandas DataFrame.

    Convenience wrapper around cashflows_to_polars().to_pandas().
    """
    return cashflows_to_polars(rows).to_pandas()


def _number_value(val):
    """Extract float value from a Number (float, Dual, or Dual2), or return None."""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    # Dual/Dual2 have a .real property
    if hasattr(val, "real"):
        return float(val.real)
    return float(val)
