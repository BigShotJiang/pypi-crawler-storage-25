"""Type stubs for vade.cashflows module."""

import datetime
from typing import Dict, List, Optional, Union

import polars as pl

from vade.autodiff import Dual, Dual2
from vade.calendar import BusinessCalendar, Schedule
from vade.curves import DiscountCurve, LineCurve

Curve = Union[DiscountCurve, LineCurve]
NumberLike = Union[float, Dual, Dual2]
Fixings = Dict[datetime.date, float]

class CashflowRow:
    """A single row of cashflow data for DataFrame construction."""

    @property
    def period_type(self) -> str: ...
    @property
    def start(self) -> datetime.date: ...
    @property
    def end(self) -> datetime.date: ...
    @property
    def payment(self) -> datetime.date: ...
    @property
    def currency(self) -> str: ...
    @property
    def notional(self) -> float: ...
    @property
    def fixing_rate(self) -> Optional[NumberLike]: ...
    @property
    def rate(self) -> float: ...
    @property
    def spread(self) -> float: ...
    @property
    def dcf(self) -> float: ...
    @property
    def cashflow(self) -> NumberLike: ...
    @property
    def df(self) -> Optional[NumberLike]: ...
    @property
    def npv(self) -> Optional[NumberLike]: ...
    def __repr__(self) -> str: ...

class FixedPeriod:
    """Fixed-rate accrual period.

    NPV = -notional * dcf * (fixed_rate/100) * DF(payment).
    """

    def __init__(
        self,
        start: datetime.date,
        end: datetime.date,
        payment: datetime.date,
        notional: float,
        fixed_rate: float,
        convention: str = "act360",
    ) -> None: ...
    def npv(self, curve: Curve) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def cashflow(self) -> float: ...
    def __repr__(self) -> str: ...

class FloatPeriod:
    """Floating-rate accrual period with RFR compounding.

    Fixing methods (string): 'rfr_payment_delay', 'rfr_observation_shift',
    'rfr_lockout', 'rfr_lookback'. Append '_N' for custom shift days
    (e.g. 'rfr_observation_shift_5'). Append '_average' for averaging
    variants (e.g. 'rfr_payment_delay_average').

    Spread methods: 'none_simple' (default), 'isda_compounding'.
    """

    def __init__(
        self,
        start: datetime.date,
        end: datetime.date,
        payment: datetime.date,
        notional: float,
        calendar: BusinessCalendar,
        spread: float = 0.0,
        convention: str = "act360",
        fixing_method: str = "rfr_payment_delay",
        spread_method: str = "none_simple",
    ) -> None: ...
    def npv(
        self,
        curve: Curve,
        fixings: Optional[Fixings] = None,
    ) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def rate(
        self,
        curve: Curve,
        fixings: Optional[Fixings] = None,
    ) -> NumberLike: ...
    def __repr__(self) -> str: ...

class IborPeriod:
    """IBOR fixing period with publication lag.

    The fixing date is start minus fixing_lag business days.
    """

    def __init__(
        self,
        start: datetime.date,
        end: datetime.date,
        payment: datetime.date,
        notional: float,
        calendar: BusinessCalendar,
        spread: float = 0.0,
        convention: str = "act360",
        fixing_lag: int = 2,
    ) -> None: ...
    def npv(
        self,
        curve: Curve,
        fixings: Optional[Fixings] = None,
    ) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def fixing_date(self) -> datetime.date: ...
    def __repr__(self) -> str: ...

class ZeroFixedPeriod:
    """Zero-coupon fixed-rate period.

    Cashflow = -notional * ((1 + rate/100)^dcf - 1).
    """

    def __init__(
        self,
        start: datetime.date,
        end: datetime.date,
        payment: datetime.date,
        notional: float,
        fixed_rate: float,
        convention: str = "act360",
    ) -> None: ...
    def npv(self, curve: Curve) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def cashflow(self) -> float: ...
    def __repr__(self) -> str: ...

class ZeroFloatPeriod:
    """Zero-coupon floating-rate period with RFR compounding."""

    def __init__(
        self,
        start: datetime.date,
        end: datetime.date,
        payment: datetime.date,
        notional: float,
        calendar: BusinessCalendar,
        spread: float = 0.0,
        convention: str = "act360",
        fixing_method: str = "rfr_payment_delay",
        spread_method: str = "none_simple",
    ) -> None: ...
    def npv(
        self,
        curve: Curve,
        fixings: Optional[Fixings] = None,
    ) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def __repr__(self) -> str: ...

class CashflowPeriod:
    """Simple notional exchange or fee cashflow.

    NPV = -notional * DF(payment).
    """

    def __init__(
        self,
        payment: datetime.date,
        notional: float,
        currency: str = "USD",
    ) -> None: ...
    def npv(self, curve: Curve) -> NumberLike: ...
    def cashflow(self) -> float: ...
    def __repr__(self) -> str: ...

class FixedLeg:
    """Fixed-rate leg constructed from a Schedule.

    Amortization: None, 'constant_AMOUNT', 'percentage_PCT',
    or a list of notionals.
    """

    def __init__(
        self,
        schedule: Schedule,
        fixed_rate: float,
        notional: float,
        convention: str = "act360",
        currency: str = "USD",
        payment_lag: Optional[int] = None,
        amortization: Optional[Union[str, List[float]]] = None,
    ) -> None: ...
    def npv(self, curve: Curve) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def cashflows(
        self,
        curve: Optional[Curve] = None,
    ) -> List[CashflowRow]: ...
    @property
    def n_periods(self) -> int: ...
    def __repr__(self) -> str: ...

class FloatLeg:
    """Floating-rate leg constructed from a Schedule with RFR compounding."""

    def __init__(
        self,
        schedule: Schedule,
        notional: float,
        calendar: BusinessCalendar,
        spread: float = 0.0,
        convention: str = "act360",
        fixing_method: str = "rfr_payment_delay",
        spread_method: str = "none_simple",
        currency: str = "USD",
        payment_lag: Optional[int] = None,
        amortization: Optional[Union[str, List[float]]] = None,
    ) -> None: ...
    def npv(
        self,
        curve: Curve,
        fixings: Optional[Fixings] = None,
    ) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def cashflows(
        self,
        curve: Optional[Curve] = None,
        fixings: Optional[Fixings] = None,
    ) -> List[CashflowRow]: ...
    @property
    def n_periods(self) -> int: ...
    def __repr__(self) -> str: ...

class ZeroFixedLeg:
    """Zero-coupon fixed-rate leg."""

    def __init__(
        self,
        start: datetime.date,
        end: datetime.date,
        payment: datetime.date,
        fixed_rate: float,
        notional: float,
        convention: str = "act360",
        currency: str = "USD",
    ) -> None: ...
    def npv(self, curve: Curve) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def cashflows(
        self,
        curve: Optional[Curve] = None,
    ) -> List[CashflowRow]: ...
    def __repr__(self) -> str: ...

class ZeroFloatLeg:
    """Zero-coupon floating-rate leg."""

    def __init__(
        self,
        start: datetime.date,
        end: datetime.date,
        payment: datetime.date,
        notional: float,
        calendar: BusinessCalendar,
        spread: float = 0.0,
        convention: str = "act360",
        fixing_method: str = "rfr_payment_delay",
        spread_method: str = "none_simple",
        currency: str = "USD",
    ) -> None: ...
    def npv(
        self,
        curve: Curve,
        fixings: Optional[Fixings] = None,
    ) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def cashflows(
        self,
        curve: Optional[Curve] = None,
        fixings: Optional[Fixings] = None,
    ) -> List[CashflowRow]: ...
    def __repr__(self) -> str: ...

class CustomLeg:
    """Leg with arbitrary heterogeneous period types."""

    def __init__(
        self,
        periods: List[
            Union[
                FixedPeriod,
                FloatPeriod,
                IborPeriod,
                ZeroFixedPeriod,
                ZeroFloatPeriod,
                CashflowPeriod,
            ]
        ],
        currency: str = "USD",
    ) -> None: ...
    def npv(
        self,
        curve: Curve,
        fixings: Optional[Fixings] = None,
    ) -> NumberLike: ...
    def analytic_delta(self, curve: Curve) -> NumberLike: ...
    def cashflows(
        self,
        curve: Optional[Curve] = None,
        fixings: Optional[Fixings] = None,
    ) -> List[CashflowRow]: ...
    @property
    def n_periods(self) -> int: ...
    def __repr__(self) -> str: ...

def cashflows_to_polars(rows: List[CashflowRow]) -> pl.DataFrame:
    """Convert a list of CashflowRow to a Polars DataFrame.

    Columns: Type, start, end, payment, Ccy, Notional, fixing_rate,
    Rate, Spread, DCF, Cashflow. If curve was provided: also DF, NPV.
    """
    ...

def cashflows_to_pandas(
    rows: List[CashflowRow],
) -> "pandas.DataFrame":
    """Convert a list of CashflowRow to a pandas DataFrame."""
    ...
