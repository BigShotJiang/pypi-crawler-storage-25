"""
Regression tests for OIS lookback/lockout/observation-shift (Phase 03).

These tests ensure:
- lookback=2 produces different NPV than plain OIS on a steep curve
- lockout=2 produces different NPV than plain OIS on a steep curve
- obs_shift=2 produces different NPV than plain OIS on a steep curve
- All NPVs are finite and reasonable for 10M notional
- No regressions in existing OIS behavior

Key insight: log-linear interpolation produces piecewise constant forward rates
between nodes. Tests must place curve node boundaries within the adjustment
window so lookback/lockout/obs_shift actually sees different rates.

Run:
    uv run pytest python/tests/test_ois_diagnosis.py -v
"""

import datetime
import pytest
import vade
from vade import DiscountCurve, OIS


def _steep_curve_for_lockout():
    """Build a steep discount curve with a node boundary within the lockout window.

    Default OIS calendar has no holidays (weekends only). For a 1Y OIS ending
    Jan 2 2025, the last business days are:
        ..., Dec 27(Fri), Dec 30(Mon), Dec 31(Tue), Jan 1(Wed), Jan 2(Thu=end)

    With lockout=2, the last 2 business days (Dec 31, Jan 1) use the frozen
    fixing date (Dec 30). The frozen rate = overnight_rate(Dec 30, Dec 31).

    Placing a node at Dec 31 creates segments:
        [Dec 30, Dec 31] with one forward rate (steep)
        [Dec 31, Jan 2]  with a different forward rate (flatter)

    This ensures the frozen rate (from Dec 30-Dec 31 segment) differs from
    the normal rate that would be used for Dec 31 and Jan 1 (from Dec 31-Jan 2).
    """
    d = datetime.date
    nodes = {
        d(2024, 1, 2): 1.0,
        d(2024, 7, 1): 0.9850,
        d(2024, 12, 30): 0.9660,
        d(2024, 12, 31): 0.9620,   # Node at lockout boundary -- steep drop
        d(2025, 1, 2): 0.9615,     # Flatter slope in lockout window
        d(2025, 7, 1): 0.9400,
        d(2026, 1, 2): 0.9100,
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f", id="sofr")


def _steep_curve_for_lookback():
    """Build a steep discount curve with node boundaries within the lookback window.

    For a 1Y OIS (Jan 2 2024 - Jan 2 2025), lookback=2 shifts observation
    dates back by 2 business days. Placing a node at Jan 2 2025 with another
    at Dec 30 2024 ensures the first few observation dates cross a boundary.
    """
    d = datetime.date
    nodes = {
        d(2024, 1, 2): 1.0,
        d(2024, 7, 1): 0.9850,
        d(2024, 12, 30): 0.9660,   # Node boundary within lookback window
        d(2025, 1, 2): 0.9650,
        d(2025, 7, 1): 0.9400,
        d(2026, 1, 2): 0.9100,
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f", id="sofr")


def _steep_curve_for_obs_shift():
    """Build a steep discount curve with node boundary for obs_shift testing.

    obs_shift=2 shifts the entire observation window back by 2 business days.
    Nodes placed at the start of the accrual period ensure the shifted window
    sees different forward rates.
    """
    d = datetime.date
    nodes = {
        d(2023, 12, 29): 1.001,    # Node just before accrual start
        d(2024, 1, 2): 1.0,
        d(2024, 7, 1): 0.9850,
        d(2025, 1, 2): 0.9650,
        d(2025, 7, 1): 0.9400,
        d(2026, 1, 2): 0.9100,
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f", id="sofr")


def _make_ois(curve_fn, **extra):
    """Build an OIS with given extra params, using specified curve."""
    d = datetime.date
    common = dict(
        effective=d(2024, 1, 2),
        termination=d(2025, 1, 2),
        frequency="a",
        fixed_rate=4.0,
        notional=10_000_000,
        convention="act365f",
        float_convention="act360",
        compounding_method="spread_exclusive",
    )
    common.update(extra)
    return OIS(**common), curve_fn()


class TestLookbackRegression:
    """Lookback=2 shifts observation dates back, producing different rates on steep curve."""

    def test_lookback_differs_from_plain(self):
        curve = _steep_curve_for_lookback()
        d = datetime.date
        common = dict(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            compounding_method="spread_exclusive",
        )
        ois_plain = OIS(**common)
        ois_lb = OIS(**common, lookback=2)

        npv_plain = ois_plain.npv(curve)
        npv_lb = ois_lb.npv(curve)

        assert abs(npv_lb - npv_plain) > 0.01, (
            f"lookback=2 should change NPV on steep curve, "
            f"got plain={npv_plain:.6f} vs lookback={npv_lb:.6f}"
        )

    def test_lookback_rate_differs_from_plain(self):
        curve = _steep_curve_for_lookback()
        d = datetime.date
        common = dict(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            compounding_method="spread_exclusive",
        )
        ois_plain = OIS(**common)
        ois_lb = OIS(**common, lookback=2)

        rate_plain = ois_plain.rate(curve)
        rate_lb = ois_lb.rate(curve)

        assert abs(rate_lb - rate_plain) > 1e-6, (
            f"lookback=2 should change fair rate on steep curve, "
            f"got plain={rate_plain:.8f} vs lookback={rate_lb:.8f}"
        )


class TestLockoutRegression:
    """Lockout=2 freezes last N fixings, producing different rates on steep curve."""

    def test_lockout_differs_from_plain(self):
        curve = _steep_curve_for_lockout()
        d = datetime.date
        common = dict(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            compounding_method="spread_exclusive",
        )
        ois_plain = OIS(**common)
        ois_lo = OIS(**common, lockout=2)

        npv_plain = ois_plain.npv(curve)
        npv_lo = ois_lo.npv(curve)

        assert abs(npv_lo - npv_plain) > 0.01, (
            f"lockout=2 should change NPV on steep curve with node boundary, "
            f"got plain={npv_plain:.6f} vs lockout={npv_lo:.6f}"
        )

    def test_lockout_rate_differs_from_plain(self):
        curve = _steep_curve_for_lockout()
        d = datetime.date
        common = dict(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            compounding_method="spread_exclusive",
        )
        ois_plain = OIS(**common)
        ois_lo = OIS(**common, lockout=2)

        rate_plain = ois_plain.rate(curve)
        rate_lo = ois_lo.rate(curve)

        assert abs(rate_lo - rate_plain) > 1e-6, (
            f"lockout=2 should change fair rate on steep curve, "
            f"got plain={rate_plain:.8f} vs lockout={rate_lo:.8f}"
        )


class TestObsShiftRegression:
    """Observation shift=2 shifts the entire observation window, producing different rates."""

    def test_obs_shift_differs_from_plain(self):
        curve = _steep_curve_for_obs_shift()
        d = datetime.date

        ois_plain = OIS(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            compounding_method="spread_exclusive",
        )
        ois_os = OIS(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            fixing_method="rfr_observation_shift_2",
        )

        npv_plain = ois_plain.npv(curve)
        npv_os = ois_os.npv(curve)
        rate_plain = ois_plain.rate(curve)
        rate_os = ois_os.rate(curve)

        # obs_shift should produce at least a small difference
        diff_npv = abs(npv_os - npv_plain)
        diff_rate = abs(rate_os - rate_plain)
        assert diff_npv > 0.01 or diff_rate > 1e-6, (
            f"observation shift should affect rate on steep curve, "
            f"NPV diff={diff_npv:.6f}, rate diff={diff_rate:.10f}"
        )

    def test_obs_shift_runs_without_error(self):
        """Observation shift OIS constructs and runs without error."""
        curve = _steep_curve_for_obs_shift()
        d = datetime.date
        ois_os = OIS(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            fixing_method="rfr_observation_shift_2",
        )
        npv = ois_os.npv(curve)
        rate = ois_os.rate(curve)
        assert isinstance(npv, float)
        assert isinstance(rate, float)


class TestAllVariantsSanity:
    """All OIS variants should produce finite, reasonable NPVs."""

    def test_all_variants_reasonable(self):
        curve = _steep_curve_for_lockout()
        d = datetime.date
        common = dict(
            effective=d(2024, 1, 2),
            termination=d(2025, 1, 2),
            frequency="a",
            fixed_rate=4.0,
            notional=10_000_000,
            convention="act365f",
            float_convention="act360",
            compounding_method="spread_exclusive",
        )

        variants = [
            ("plain", OIS(**common)),
            ("lookback=2", OIS(**common, lookback=2)),
            ("lockout=2", OIS(**common, lockout=2)),
            ("obs_shift=2", OIS(
                effective=d(2024, 1, 2),
                termination=d(2025, 1, 2),
                frequency="a",
                fixed_rate=4.0,
                notional=10_000_000,
                convention="act365f",
                float_convention="act360",
                fixing_method="rfr_observation_shift_2",
            )),
        ]

        for name, ois in variants:
            npv = ois.npv(curve)
            assert abs(npv) < 5_000_000, f"{name} NPV unreasonable: {npv}"
            # NPV can be zero if fixed_rate matches fair rate exactly, but very unlikely
            assert isinstance(npv, float), f"{name} NPV should be float"
            assert npv == npv, f"{name} NPV is NaN"  # NaN check
