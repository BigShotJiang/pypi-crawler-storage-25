"""Integration tests for curve transformation Python bindings.

Covers shift, translate, roll operations on all curve types.
"""

import math
from datetime import date

import pytest

from vade import DiscountCurve, LineCurve, NelsonSiegel, SmithWilson


# ============================================================
# Shift tests
# ============================================================


class TestShift:
    """Shift (parallel bump by basis points) on all curve types."""

    def test_shift_discount_curve(self):
        """Shift DiscountCurve by 10bp increases zero rate by ~10bp."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            convention="act365f",
        )
        shifted = c.shift(10.0)
        orig_rate = c.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        shifted_rate = shifted.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        diff = shifted_rate - orig_rate
        assert diff == pytest.approx(0.001, abs=1e-6), f"Expected ~10bp shift, got {diff}"

    def test_shift_line_curve(self):
        """Shift LineCurve by 10bp increases node values by 0.001."""
        c = LineCurve(
            {date(2024, 1, 1): 0.03, date(2025, 1, 1): 0.035, date(2026, 1, 1): 0.04},
            convention="act365f",
        )
        shifted = c.shift(10.0)
        # Check that a rate query reflects the shift
        orig_rate = c.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        shifted_rate = shifted.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        diff = shifted_rate - orig_rate
        assert diff == pytest.approx(0.001, abs=1e-6)

    def test_shift_immutable(self):
        """Original curve unchanged after shift."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97},
            convention="act365f",
        )
        orig_df = c.discount_factor(date(2025, 1, 1))
        _ = c.shift(50.0)
        after_df = c.discount_factor(date(2025, 1, 1))
        assert orig_df == after_df, "Original curve must not be modified"

    def test_shift_nelson_siegel(self):
        """Shift NelsonSiegel by 10bp adjusts beta0."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        shifted = ns.shift(10.0)
        # Long rate should increase by ~10bp (beta0 goes from 0.05 to 0.051)
        orig_rate = ns.zero_rate(date(2024, 1, 1), date(2044, 1, 1))
        shifted_rate = shifted.zero_rate(date(2024, 1, 1), date(2044, 1, 1))
        diff = shifted_rate - orig_rate
        assert diff == pytest.approx(0.001, abs=0.0005)

    def test_shift_smith_wilson(self):
        """Shift SmithWilson by 10bp."""
        sw = SmithWilson(
            [date(2025, 1, 1), date(2026, 1, 1), date(2029, 1, 1)],
            [0.03, 0.032, 0.036],
            0.033, 0.128, date(2024, 1, 1),
        )
        shifted = sw.shift(10.0)
        # Zero rate should increase
        orig_rate = sw.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        shifted_rate = shifted.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        assert shifted_rate > orig_rate

    def test_shift_negative_bp(self):
        """Shift by negative bp decreases rates."""
        c = LineCurve(
            {date(2024, 1, 1): 0.03, date(2025, 1, 1): 0.035},
            convention="act365f",
        )
        shifted = c.shift(-10.0)
        orig_rate = c.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        shifted_rate = shifted.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        assert shifted_rate < orig_rate


# ============================================================
# Translate tests
# ============================================================


class TestTranslate:
    """Translate (shift valuation date) on curve types."""

    def test_translate_discount_curve(self):
        """Translate DiscountCurve by 365 days shifts all dates forward."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            convention="act365f",
        )
        translated = c.translate(365)
        # The new base date is 2024-01-01 + 365 = 2024-12-31
        # DF at new base date should be 1.0 (was the original first node DF)
        df = translated.discount_factor(date(2024, 12, 31))
        assert df == pytest.approx(1.0, abs=1e-6)
        # DF at shifted 1Y node (2025-01-01 + 365 = 2025-12-31) should be ~0.97
        df2 = translated.discount_factor(date(2025, 12, 31))
        assert df2 == pytest.approx(0.97, abs=1e-3)

    def test_translate_nelson_siegel(self):
        """Translate NelsonSiegel shifts base_date."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        translated = ns.translate(365)
        # New base_date = 2024-01-01 + 365 days = 2024-12-31
        # DF at new base_date should be 1.0
        df = translated.discount_factor(date(2024, 12, 31))
        assert df == pytest.approx(1.0, abs=1e-10)


# ============================================================
# Roll tests
# ============================================================


class TestRoll:
    """Roll (forward to future date using today's forward rates)."""

    def test_roll_discount_curve(self):
        """Roll DiscountCurve forward 90 days."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            convention="act365f",
        )
        rolled = c.roll(90)
        # First DF of rolled curve should be 1.0
        df = rolled.discount_factor(date(2024, 3, 31))
        assert df == pytest.approx(1.0, abs=1e-6)

    def test_roll_nelson_siegel(self):
        """Roll NelsonSiegel shifts base_date (same as translate)."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        rolled = ns.roll(365)
        # New base_date = 2024-01-01 + 365 = 2024-12-31
        df = rolled.discount_factor(date(2024, 12, 31))
        assert df == pytest.approx(1.0, abs=1e-10)
