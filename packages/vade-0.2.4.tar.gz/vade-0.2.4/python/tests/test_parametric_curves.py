"""Integration tests for parametric curve Python bindings.

Covers CURV-09 (NelsonSiegel), CURV-10 (NSS), CURV-11 (SmithWilson),
and D-04 (drop-in curve compatibility with instruments).
"""

import math
from datetime import date

import pytest

from vade import NelsonSiegel, NelsonSiegelSvensson, SmithWilson, IRS
from vade.autodiff import Dual


# ============================================================
# Nelson-Siegel tests
# ============================================================


class TestNelsonSiegel:
    """CURV-09: NelsonSiegel parametric curve from Python."""

    def test_construction(self):
        """Construct NelsonSiegel and query discount factor."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        df = ns.discount_factor(date(2025, 1, 1))
        assert 0.0 < df < 1.0, f"DF should be between 0 and 1, got {df}"

    def test_zero_rate_at_zero_region(self):
        """Zero rate near base_date approaches beta0 + beta1."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        # Query a short maturity to approximate the t->0 limit
        rate = ns.zero_rate(date(2024, 1, 1), date(2024, 1, 2))
        # At t->0: r(0) = beta0 + beta1 = 0.03
        assert rate == pytest.approx(0.03, abs=0.005)

    def test_long_rate_converges_to_beta0(self):
        """Zero rate at long maturity converges toward beta0."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        rate = ns.zero_rate(date(2024, 1, 1), date(2044, 1, 1))
        assert rate == pytest.approx(0.05, abs=0.005)

    def test_discount_factor_at_base_date(self):
        """DF at base_date = 1.0."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        df = ns.discount_factor(date(2024, 1, 1))
        assert df == pytest.approx(1.0, abs=1e-12)

    def test_forward_rate_positive(self):
        """Forward rate is positive for a normal curve shape."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        fwd = ns.forward_rate(date(2025, 1, 1), date(2026, 1, 1))
        assert fwd > 0.0

    def test_custom_convention(self):
        """NelsonSiegel works with act360 convention."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1), convention="act360")
        df = ns.discount_factor(date(2025, 1, 1))
        assert 0.0 < df < 1.0

    def test_repr(self):
        """repr includes class name."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1), id="test_ns")
        assert "NelsonSiegel" in repr(ns)


class TestNelsonSiegelSvensson:
    """CURV-10: NelsonSiegelSvensson parametric curve from Python."""

    def test_construction(self):
        """Construct NSS with 6 parameters and query DF."""
        nss = NelsonSiegelSvensson(
            0.05, -0.02, 0.01, 0.005, 1.5, 2.0, date(2024, 1, 1)
        )
        df = nss.discount_factor(date(2025, 1, 1))
        assert 0.0 < df < 1.0

    def test_reduces_to_ns(self):
        """NSS with beta3=0 matches NS result."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        nss = NelsonSiegelSvensson(
            0.05, -0.02, 0.01, 0.0, 1.5, 2.0, date(2024, 1, 1)
        )
        # Check at multiple maturities
        for year in [2025, 2026, 2028, 2034]:
            d = date(year, 1, 1)
            df_ns = ns.discount_factor(d)
            df_nss = nss.discount_factor(d)
            assert df_ns == pytest.approx(df_nss, abs=1e-10), (
                f"NS/NSS mismatch at {d}: NS={df_ns}, NSS={df_nss}"
            )

    def test_zero_rate_at_zero(self):
        """NSS at t=0 returns beta0 + beta1."""
        nss = NelsonSiegelSvensson(
            0.05, -0.02, 0.01, 0.005, 1.5, 2.0, date(2024, 1, 1)
        )
        rate = nss.zero_rate(date(2024, 1, 1), date(2024, 1, 2))
        assert rate == pytest.approx(0.03, abs=0.005)

    def test_repr(self):
        """repr includes class name."""
        nss = NelsonSiegelSvensson(
            0.05, -0.02, 0.01, 0.005, 1.5, 2.0, date(2024, 1, 1), id="test_nss"
        )
        assert "NelsonSiegelSvensson" in repr(nss)


class TestSmithWilson:
    """CURV-11: SmithWilson parametric curve from Python."""

    @staticmethod
    def _sw_fixture():
        dates = [
            date(2025, 1, 1),
            date(2026, 1, 1),
            date(2027, 1, 1),
            date(2029, 1, 1),
            date(2034, 1, 1),
            date(2044, 1, 1),
        ]
        rates = [0.03, 0.032, 0.034, 0.036, 0.038, 0.037]
        return SmithWilson(dates, rates, 0.033, 0.128, date(2024, 1, 1))

    def test_construction(self):
        """Construct SmithWilson and query DF."""
        sw = self._sw_fixture()
        df = sw.discount_factor(date(2025, 1, 1))
        assert 0.0 < df < 1.0

    def test_market_reproduction(self):
        """SW reproduces market DFs at input maturities."""
        sw_dates = [
            date(2025, 1, 1),
            date(2026, 1, 1),
            date(2027, 1, 1),
            date(2029, 1, 1),
            date(2034, 1, 1),
            date(2044, 1, 1),
        ]
        rates = [0.03, 0.032, 0.034, 0.036, 0.038, 0.037]
        sw = SmithWilson(sw_dates, rates, 0.033, 0.128, date(2024, 1, 1))

        base = date(2024, 1, 1)
        for d, r in zip(sw_dates, rates):
            dcf = (d - base).days / 365.25
            expected_df = math.exp(-r * dcf)
            actual_df = sw.discount_factor(d)
            assert actual_df == pytest.approx(expected_df, abs=2e-3), (
                f"DF mismatch at {d}: got {actual_df}, expected {expected_df}"
            )

    def test_ufr_convergence(self):
        """Forward rate at 100Y converges toward UFR."""
        sw = self._sw_fixture()
        # Approximate forward rate at very long maturity
        rate_90y = sw.zero_rate(date(2024, 1, 1), date(2114, 1, 1))
        rate_100y = sw.zero_rate(date(2024, 1, 1), date(2124, 1, 1))
        # Both should be close to UFR = 0.033
        assert abs(rate_100y - 0.033) < 0.01, f"100Y rate {rate_100y} far from UFR 0.033"

    def test_base_date_df(self):
        """DF at base_date = 1.0."""
        sw = self._sw_fixture()
        df = sw.discount_factor(date(2024, 1, 1))
        assert df == pytest.approx(1.0, abs=1e-10)

    def test_repr(self):
        """repr includes class name."""
        sw = self._sw_fixture()
        assert "SmithWilson" in repr(sw)


class TestParametricInInstrument:
    """D-04: Parametric curves as drop-in replacements in instruments."""

    def test_ns_in_irs(self):
        """NelsonSiegel can be used as discount/forecast curve for IRS.npv()."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        irs = IRS(
            effective=date(2024, 3, 1),
            termination="1Y",
            frequency="S",
            fixed_rate=3.5,
            notional=1_000_000,
        )
        npv = irs.npv(ns)
        # Just verify it returns a number without error
        assert isinstance(npv, float)


class TestParametricAD:
    """AD propagation through parametric curves."""

    def test_ns_dual_params(self):
        """NelsonSiegel with Dual params returns Dual from discount_factor."""
        beta0 = Dual("beta0", 0.05)
        ns = NelsonSiegel(beta0, -0.02, 0.01, 1.5, date(2024, 1, 1))
        df = ns.discount_factor(date(2025, 1, 1))
        assert isinstance(df, Dual), f"Expected Dual, got {type(df)}"
        assert 0.0 < df.real < 1.0
