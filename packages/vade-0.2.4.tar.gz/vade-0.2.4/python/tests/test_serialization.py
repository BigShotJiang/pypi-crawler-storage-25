"""Integration tests for JSON serialization Python bindings.

Covers D-12 (to_json/from_json on all curves and solver)
and D-09 (AD stripped to f64 on serialization).
"""

import json
import math
from datetime import date

import pytest

from vade import (
    DiscountCurve,
    LineCurve,
    NelsonSiegel,
    NelsonSiegelSvensson,
    SmithWilson,
)
from vade.solver import Solver
from vade.instruments import IRS


# ============================================================
# DiscountCurve serialization
# ============================================================


class TestDiscountCurveSerialization:
    """to_json / from_json roundtrip for DiscountCurve."""

    def test_roundtrip(self):
        """DiscountCurve survives JSON roundtrip with matching DF."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            convention="act365f",
        )
        s = c.to_json()
        c2 = DiscountCurve.from_json(s)
        assert c.discount_factor(date(2025, 1, 1)) == pytest.approx(
            c2.discount_factor(date(2025, 1, 1)), abs=1e-10
        )

    def test_json_is_valid(self):
        """to_json produces valid JSON."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97},
            convention="act365f",
        )
        s = c.to_json()
        parsed = json.loads(s)
        assert isinstance(parsed, dict)
        assert "nodes" in parsed


# ============================================================
# LineCurve serialization
# ============================================================


class TestLineCurveSerialization:
    """to_json / from_json roundtrip for LineCurve."""

    def test_roundtrip(self):
        """LineCurve survives JSON roundtrip with matching rate."""
        c = LineCurve(
            {date(2024, 1, 1): 0.03, date(2025, 1, 1): 0.035},
            convention="act365f",
        )
        s = c.to_json()
        c2 = LineCurve.from_json(s)
        assert c.zero_rate(date(2024, 1, 1), date(2025, 1, 1)) == pytest.approx(
            c2.zero_rate(date(2024, 1, 1), date(2025, 1, 1)), abs=1e-10
        )


# ============================================================
# NelsonSiegel serialization
# ============================================================


class TestNelsonSiegelSerialization:
    """to_json / from_json roundtrip for NelsonSiegel."""

    def test_roundtrip(self):
        """NS survives JSON roundtrip with matching DF."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        s = ns.to_json()
        ns2 = NelsonSiegel.from_json(s)
        assert ns.discount_factor(date(2025, 1, 1)) == pytest.approx(
            ns2.discount_factor(date(2025, 1, 1)), abs=1e-10
        )

    def test_json_has_expected_keys(self):
        """JSON has expected structure."""
        ns = NelsonSiegel(0.05, -0.02, 0.01, 1.5, date(2024, 1, 1))
        parsed = json.loads(ns.to_json())
        assert "beta0" in parsed
        assert "beta1" in parsed
        assert "tau" in parsed
        assert "base_date" in parsed


# ============================================================
# NelsonSiegelSvensson serialization
# ============================================================


class TestNSSSerialization:
    """to_json / from_json roundtrip for NelsonSiegelSvensson."""

    def test_roundtrip(self):
        """NSS survives JSON roundtrip with matching DF."""
        nss = NelsonSiegelSvensson(
            0.05, -0.02, 0.01, 0.005, 1.5, 2.0, date(2024, 1, 1)
        )
        s = nss.to_json()
        nss2 = NelsonSiegelSvensson.from_json(s)
        assert nss.discount_factor(date(2025, 1, 1)) == pytest.approx(
            nss2.discount_factor(date(2025, 1, 1)), abs=1e-10
        )


# ============================================================
# SmithWilson serialization
# ============================================================


class TestSmithWilsonSerialization:
    """to_json / from_json roundtrip for SmithWilson."""

    def test_roundtrip(self):
        """SW survives JSON roundtrip with matching DF."""
        sw = SmithWilson(
            [date(2025, 1, 1), date(2026, 1, 1), date(2029, 1, 1)],
            [0.03, 0.032, 0.036],
            0.033, 0.128, date(2024, 1, 1),
        )
        s = sw.to_json()
        sw2 = SmithWilson.from_json(s)
        assert sw.discount_factor(date(2026, 1, 1)) == pytest.approx(
            sw2.discount_factor(date(2026, 1, 1)), abs=1e-10
        )


# ============================================================
# Solver serialization
# ============================================================


class TestSolverSerialization:
    """to_json / from_json roundtrip for Solver."""

    def test_solver_roundtrip(self):
        """Calibrated solver survives JSON roundtrip."""
        dc = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97},
            convention="act365f",
            id="usd_ois",
        )
        irs = IRS(
            effective=date(2024, 1, 1),
            termination="1Y",
            frequency="A",
            fixed_rate=3.0,
            notional=1_000_000,
        )
        solver = Solver(
            curves=[dc],
            instruments=[(irs, 0.0)],
        )
        result = solver.iterate()

        s = solver.to_json()
        solver2 = Solver.from_json(s)
        # Get curve from restored solver and verify DF
        curve1 = solver.get_curve(0)
        curve2 = solver2.get_curve(0)
        assert curve1.discount_factor(date(2025, 1, 1)) == pytest.approx(
            curve2.discount_factor(date(2025, 1, 1)), abs=1e-8
        )


# ============================================================
# AD stripping on serialization
# ============================================================


class TestADStripping:
    """D-09: AD stripped to f64 on serialization."""

    def test_ad_stripped_on_serialize(self):
        """Curve with Dual nodes serializes as f64 (AD stripped)."""
        from vade.autodiff import Dual

        d1 = Dual("v0", 1.0)
        d2 = Dual("v1", 0.97)
        dc = DiscountCurve(
            {date(2024, 1, 1): d1, date(2025, 1, 1): d2},
            convention="act365f",
        )
        s = dc.to_json()
        parsed = json.loads(s)
        # After deserialization, values should be plain floats (not Dual objects)
        dc2 = DiscountCurve.from_json(s)
        df = dc2.discount_factor(date(2025, 1, 1))
        assert isinstance(df, float), f"Expected float after deserialization, got {type(df)}"
        assert df == pytest.approx(0.97, abs=1e-10)

    def test_ns_ad_stripped_on_serialize(self):
        """NelsonSiegel with Dual params serializes as f64."""
        from vade.autodiff import Dual

        beta0 = Dual("beta0", 0.05)
        ns = NelsonSiegel(beta0, -0.02, 0.01, 1.5, date(2024, 1, 1))
        s = ns.to_json()
        ns2 = NelsonSiegel.from_json(s)
        df = ns2.discount_factor(date(2025, 1, 1))
        assert isinstance(df, float), f"Expected float after deserialization, got {type(df)}"
