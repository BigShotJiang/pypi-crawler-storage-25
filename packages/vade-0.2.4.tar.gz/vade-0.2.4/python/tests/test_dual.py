"""Integration tests for vade autodiff module: Dual and Dual2 Python bindings."""

import math

import numpy as np
import pytest

from vade.autodiff import Dual, Dual2


class TestDualCreation:
    def test_dual_creation(self):
        d = Dual("x", 2.0)
        assert d.real == 2.0

    def test_dual_vars(self):
        d = Dual("x", 2.0)
        assert d.vars == ["x"]

    def test_dual_gradient_numpy(self):
        d = Dual("x", 2.0)
        grad = d.gradient()
        assert isinstance(grad, np.ndarray)
        assert grad.shape == (1,)
        np.testing.assert_array_almost_equal(grad, [1.0])

    def test_dual_repr(self):
        d = Dual("x", 2.0)
        r = repr(d)
        assert "Dual" in r
        assert "2" in r

    def test_dual_float(self):
        d = Dual("x", 2.5)
        assert float(d) == 2.5


class TestDualArithmetic:
    def test_add_dual_dual(self, dual_x, dual_y):
        result = dual_x + dual_y
        assert result.real == 5.0
        assert result.vars == ["x", "y"]
        grad = result.gradient()
        np.testing.assert_array_almost_equal(grad, [1.0, 1.0])

    def test_sub_dual_dual(self, dual_x, dual_y):
        result = dual_x - dual_y
        assert result.real == -1.0

    def test_mul_dual_dual(self):
        d = Dual("x", 3.0)
        result = d * d
        assert result.real == 9.0
        np.testing.assert_array_almost_equal(result.gradient(), [6.0])

    def test_div_dual_dual(self):
        d1 = Dual("x", 6.0)
        d2 = Dual("x", 3.0)
        result = d1 / d2
        assert abs(result.real - 2.0) < 1e-12

    def test_neg_dual(self, dual_x):
        result = -dual_x
        assert result.real == -2.0
        np.testing.assert_array_almost_equal(result.gradient(), [-1.0])

    def test_pow_dual(self):
        d = Dual("x", 3.0)
        result = d**2.0
        assert result.real == 9.0
        np.testing.assert_array_almost_equal(result.gradient(), [6.0])


class TestMixedArithmetic:
    def test_dual_add_float(self, dual_x):
        result = dual_x + 3.0
        assert result.real == 5.0
        np.testing.assert_array_almost_equal(result.gradient(), [1.0])

    def test_float_add_dual(self, dual_x):
        result = 3.0 + dual_x
        assert result.real == 5.0
        np.testing.assert_array_almost_equal(result.gradient(), [1.0])

    def test_dual_mul_float(self, dual_x):
        result = dual_x * 3.0
        assert result.real == 6.0
        np.testing.assert_array_almost_equal(result.gradient(), [3.0])

    def test_float_mul_dual(self, dual_x):
        result = 3.0 * dual_x
        assert result.real == 6.0
        np.testing.assert_array_almost_equal(result.gradient(), [3.0])

    def test_float_sub_dual(self, dual_x):
        result = 10.0 - dual_x
        assert result.real == 8.0
        np.testing.assert_array_almost_equal(result.gradient(), [-1.0])

    def test_float_div_dual(self):
        d = Dual("x", 2.0)
        result = 6.0 / d
        assert abs(result.real - 3.0) < 1e-12
        np.testing.assert_array_almost_equal(result.gradient(), [-1.5])


class TestVariableAlignment:
    def test_dual_variable_alignment(self):
        d1 = Dual("x", 1.0)
        d2 = Dual("y", 2.0)
        result = d1 + d2
        assert result.real == 3.0
        assert set(result.vars) == {"x", "y"}
        grad = result.gradient()
        assert len(grad) == 2
        np.testing.assert_array_almost_equal(grad, [1.0, 1.0])


class TestDualMathFunctions:
    def test_dual_exp(self):
        d = Dual("x", 2.0)
        result = d.exp()
        assert abs(result.real - math.exp(2.0)) < 1e-12
        np.testing.assert_array_almost_equal(result.gradient(), [math.exp(2.0)])

    def test_dual_log(self):
        d = Dual("x", 2.0)
        result = d.log()
        assert abs(result.real - math.log(2.0)) < 1e-12
        np.testing.assert_array_almost_equal(result.gradient(), [0.5])


class TestDual2Creation:
    def test_dual2_creation(self):
        d = Dual2("x", 3.0)
        assert d.real == 3.0

    def test_dual2_vars(self):
        d = Dual2("x", 3.0)
        assert d.vars == ["x"]

    def test_dual2_gradient(self):
        d = Dual2("x", 3.0)
        grad = d.gradient()
        assert isinstance(grad, np.ndarray)
        np.testing.assert_array_almost_equal(grad, [1.0])


class TestDual2SecondDerivative:
    def test_dual2_mul_hessian(self):
        d = Dual2("x", 2.0)
        result = d * d
        assert result.real == 4.0
        grad = result.gradient()
        np.testing.assert_array_almost_equal(grad, [4.0])
        hess = result.gradient2()
        assert isinstance(hess, np.ndarray)
        assert hess.shape == (1, 1)
        np.testing.assert_array_almost_equal(hess, [[2.0]])

    def test_dual2_exp_hessian(self):
        d = Dual2("x", 1.0)
        result = d.exp()
        e = math.exp(1.0)
        assert abs(result.real - e) < 1e-12
        hess = result.gradient2()
        np.testing.assert_array_almost_equal(hess, [[e]], decimal=10)

    def test_dual2_pow_hessian(self):
        d = Dual2("x", 2.0)
        result = d**3.0
        assert abs(result.real - 8.0) < 1e-12
        hess = result.gradient2()
        np.testing.assert_array_almost_equal(hess, [[12.0]], decimal=10)


class TestDual2Arithmetic:
    def test_dual2_add_float(self):
        d = Dual2("x", 2.0)
        result = d + 3.0
        assert result.real == 5.0

    def test_float_mul_dual2(self):
        d = Dual2("x", 2.0)
        result = 3.0 * d
        assert result.real == 6.0


class TestCrossTypeRejection:
    def test_dual_plus_dual2_raises(self):
        d1 = Dual("x", 1.0)
        d2 = Dual2("x", 2.0)
        with pytest.raises(TypeError):
            _ = d1 + d2

    def test_dual2_plus_dual_raises(self):
        d1 = Dual2("x", 1.0)
        d2 = Dual("x", 2.0)
        with pytest.raises(TypeError):
            _ = d1 + d2
