"""Tests for vade.parse_date() — Rust-backed date string parsing."""

import datetime

import pytest

import vade


class TestParseDateValid:
    """Valid date parsing with various format strings."""

    def test_iso_format(self):
        result = vade.parse_date("2024-03-15", "%Y-%m-%d")
        assert result == datetime.date(2024, 3, 15)

    def test_slash_format(self):
        result = vade.parse_date("15/03/2024", "%d/%m/%Y")
        assert result == datetime.date(2024, 3, 15)

    def test_month_name_format(self):
        result = vade.parse_date("Mar 15, 2024", "%b %d, %Y")
        assert result == datetime.date(2024, 3, 15)

    def test_leap_year(self):
        result = vade.parse_date("2024-02-29", "%Y-%m-%d")
        assert result == datetime.date(2024, 2, 29)

    def test_default_format(self):
        """Default format is ISO 8601 (%Y-%m-%d)."""
        result = vade.parse_date("2024-03-15")
        assert result == datetime.date(2024, 3, 15)


class TestParseDateInvalid:
    """Invalid input raises ValueError with descriptive message."""

    def test_not_a_date(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            vade.parse_date("not-a-date", "%Y-%m-%d")

    def test_invalid_month(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            vade.parse_date("2024-13-01", "%Y-%m-%d")

    def test_non_leap_year_feb29(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            vade.parse_date("2023-02-29", "%Y-%m-%d")


class TestParseDateSubmodule:
    """parse_date is accessible from vade.calendar submodule too."""

    def test_calendar_submodule_access(self):
        from vade.calendar import parse_date
        result = parse_date("2024-03-15", "%Y-%m-%d")
        assert result == datetime.date(2024, 3, 15)
