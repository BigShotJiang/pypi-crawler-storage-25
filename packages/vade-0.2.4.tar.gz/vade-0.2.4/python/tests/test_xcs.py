"""Integration tests for Cross Currency Swap (XCS)."""

import datetime
import pytest

from vade import (
    XCS,
    CrossCurrencySwap,
    DiscountCurve,
    FXRates,
    Solver,
)


def _d(y, m, d):
    return datetime.date(y, m, d)


def _make_disc_curve(dates_dfs, id="curve"):
    nodes = {d: v for d, v in dates_dfs}
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f", id=id)


def _setup_xcs():
    """Create a basic XCS test setup with curves and FX rates."""
    eur_disc = _make_disc_curve([
        (_d(2024, 1, 1), 1.0),
        (_d(2025, 1, 1), 0.98),
        (_d(2026, 1, 1), 0.96),
    ], id="eur_disc")
    usd_disc = _make_disc_curve([
        (_d(2024, 1, 1), 1.0),
        (_d(2025, 1, 1), 0.97),
        (_d(2026, 1, 1), 0.94),
    ], id="usd_disc")
    fxr = FXRates({"eurusd": 1.1}, _d(2024, 1, 1))
    return eur_disc, usd_disc, fxr


class TestXCS:
    def test_xcs_float_float(self):
        """Basic float-float XCS NPV test."""
        eur_disc, usd_disc, fxr = _setup_xcs()

        xcs = XCS(
            effective=_d(2024, 1, 1),
            termination=_d(2026, 1, 1),
            frequency="s",
            leg1_currency="EUR",
            leg2_currency="USD",
            leg1_notional=1_000_000.0,
            leg2_notional=1_100_000.0,
            initial_fx_rate=1.1,
            notional_exchange=True,
            convention="act360",
        )

        npv = xcs.npv(eur_disc, eur_disc, usd_disc, usd_disc, fxr)
        npv_val = npv if isinstance(npv, float) else npv.real
        # NPV should be finite (positive or negative)
        assert abs(npv_val) < 1_000_000, f"NPV should be reasonable, got {npv_val}"

    def test_xcs_rate_metric(self):
        """XCS rate with metric parameter."""
        eur_disc, usd_disc, fxr = _setup_xcs()

        xcs = XCS(
            effective=_d(2024, 1, 1),
            termination=_d(2026, 1, 1),
            frequency="s",
            leg1_currency="EUR",
            leg2_currency="USD",
            leg1_notional=1_000_000.0,
            leg2_notional=1_100_000.0,
            initial_fx_rate=1.1,
            notional_exchange=True,
            convention="act360",
        )

        rate = xcs.rate(eur_disc, eur_disc, usd_disc, usd_disc, fxr, metric="leg2")
        rate_val = rate if isinstance(rate, float) else rate.real
        # Basis spread should be reasonable (in basis points)
        assert -500 < rate_val < 500, f"Basis spread should be reasonable, got {rate_val}bp"

    def test_xcs_notional_exchange(self):
        """With notional exchange, NPV includes principal flows."""
        eur_disc, usd_disc, fxr = _setup_xcs()

        xcs_with = XCS(
            effective=_d(2024, 1, 1),
            termination=_d(2026, 1, 1),
            frequency="s",
            leg1_currency="EUR",
            leg2_currency="USD",
            leg1_notional=1_000_000.0,
            leg2_notional=1_100_000.0,
            initial_fx_rate=1.1,
            notional_exchange=True,
            convention="act360",
        )

        xcs_without = XCS(
            effective=_d(2024, 1, 1),
            termination=_d(2026, 1, 1),
            frequency="s",
            leg1_currency="EUR",
            leg2_currency="USD",
            leg1_notional=1_000_000.0,
            leg2_notional=1_100_000.0,
            initial_fx_rate=1.1,
            notional_exchange=False,
            convention="act360",
        )

        npv_with = xcs_with.npv(eur_disc, eur_disc, usd_disc, usd_disc, fxr)
        npv_without = xcs_without.npv(eur_disc, eur_disc, usd_disc, usd_disc, fxr)

        v_with = npv_with if isinstance(npv_with, float) else npv_with.real
        v_without = npv_without if isinstance(npv_without, float) else npv_without.real

        # NPVs should differ because of principal exchange
        # (they could be the same if FX hasn't moved, but with different DFs they should differ)
        assert isinstance(v_with, float)
        assert isinstance(v_without, float)

    def test_xcs_import(self):
        from vade import XCS, CrossCurrencySwap
        assert XCS is not None
        assert CrossCurrencySwap is not None
        assert XCS is CrossCurrencySwap


class TestXCSSolverIntegration:
    """XCS integration with solver using 4-curve model (D-15, D-48)."""

    def test_xcs_solver_calibration(self):
        """XCS calibrates in multi-curve solver with FXRates."""
        # 4 curves: leg1_disc (EUR), leg1_forecast (EUR), leg2_disc (USD), leg2_forecast (USD)
        eur_disc = _make_disc_curve([
            (_d(2024, 1, 1), 1.0), (_d(2025, 1, 1), 0.975), (_d(2026, 1, 1), 0.95),
        ], id="eur_disc")
        eur_fwd = _make_disc_curve([
            (_d(2024, 1, 1), 1.0), (_d(2025, 1, 1), 0.975), (_d(2026, 1, 1), 0.95),
        ], id="eur_fwd")
        usd_disc = _make_disc_curve([
            (_d(2024, 1, 1), 1.0), (_d(2025, 1, 1), 0.97), (_d(2026, 1, 1), 0.94),
        ], id="usd_disc")
        usd_fwd = _make_disc_curve([
            (_d(2024, 1, 1), 1.0), (_d(2025, 1, 1), 0.97), (_d(2026, 1, 1), 0.94),
        ], id="usd_fwd")

        fxr = FXRates({"eurusd": 1.1}, _d(2024, 1, 1))

        xcs = XCS(
            effective=_d(2024, 1, 1),
            termination=_d(2026, 1, 1),
            frequency="s",
            leg1_currency="EUR",
            leg2_currency="USD",
            leg1_notional=1_000_000.0,
            leg2_notional=1_100_000.0,
            initial_fx_rate=1.1,
            notional_exchange=True,
            convention="act360",
        )

        # Verify XCS.rate works with 4-curve model
        rate = xcs.rate(eur_disc, eur_fwd, usd_disc, usd_fwd, fxr, metric="leg2")
        rate_val = rate if isinstance(rate, float) else rate.real
        assert rate is not None, "XCS.rate() should return a value"
        assert -500 < rate_val < 500, f"Basis spread {rate_val}bp should be reasonable"

        # Create solver with 4 curves and dict-based instrument
        solver = Solver(
            curves=[eur_disc, eur_fwd, usd_disc, usd_fwd],
            instruments=[{
                "instrument": xcs,
                "target": rate_val,
                "disc_curve_idx": 0,
                "forecast_curve_idx": 1,
                "leg2_disc_curve_idx": 2,
                "leg2_forecast_curve_idx": 3,
                "label": "xcs_eurusd",
                "currency": "EUR",
            }],
            func_tol=1e-10, max_iter=50,
            fx_rates=fxr,
        )

        # The solver should at minimum not crash with XCS + 4-curve model
        result = solver.iterate()
        assert result.jacobian is not None, "Solver should produce a Jacobian"

    def test_xcs_rate_nonzero(self):
        """XCS rate with leg2 metric returns non-zero basis spread."""
        eur_disc, usd_disc, fxr = _setup_xcs()

        xcs = XCS(
            effective=_d(2024, 1, 1),
            termination=_d(2026, 1, 1),
            frequency="s",
            leg1_currency="EUR",
            leg2_currency="USD",
            leg1_notional=1_000_000.0,
            leg2_notional=1_100_000.0,
            initial_fx_rate=1.1,
            notional_exchange=True,
            convention="act360",
        )

        rate = xcs.rate(eur_disc, eur_disc, usd_disc, usd_disc, fxr, metric="leg2")
        assert rate is not None
        # With different discount factors for EUR/USD, there should be a non-zero basis
        rate_val = rate if isinstance(rate, float) else rate.real
        assert isinstance(rate_val, float)
