"""Integration tests for DiscountCurve and LineCurve Python bindings.

Covers all CURV-01 through CURV-07 requirements.
"""

import math
from datetime import date

import pytest

from vade.autodiff import Dual, Dual2
from vade.curves import DiscountCurve, LineCurve
from vade import CompositeCurve, FXImpliedCurve, FXRates, IRS


# ============================================================
# CURV-01: DiscountCurve construction
# ============================================================


class TestDiscountCurveConstruction:
    """CURV-01: DiscountCurve from dict and parallel lists."""

    def test_from_dict(self):
        """Construct DiscountCurve from {date: float} dict."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94}
        )
        assert c.discount_factor(date(2025, 1, 1)) == pytest.approx(0.97, abs=1e-10)

    def test_from_lists(self):
        """Construct DiscountCurve from ([dates], [values]) tuple."""
        dates = [date(2024, 1, 1), date(2025, 1, 1), date(2026, 1, 1)]
        values = [1.0, 0.97, 0.94]
        c = DiscountCurve((dates, values))
        assert c.discount_factor(date(2025, 1, 1)) == pytest.approx(0.97, abs=1e-10)

    def test_auto_insert_df1(self):
        """DF=1.0 auto-inserted at first node if not present."""
        c = DiscountCurve(
            {date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94}
        )
        # First node should be 1.0
        assert c.discount_factor(date(2025, 1, 1)) == pytest.approx(1.0, abs=1e-10)

    def test_dual_nodes(self):
        """Construct with Dual-valued nodes."""
        d1 = Dual("v0", 1.0)
        d2 = Dual("v1", 0.97)
        d3 = Dual("v2", 0.94)
        c = DiscountCurve(
            {date(2024, 1, 1): d1, date(2025, 1, 1): d2, date(2026, 1, 1): d3}
        )
        df = c.discount_factor(date(2025, 1, 1))
        assert isinstance(df, Dual)
        assert df.real == pytest.approx(0.97, abs=1e-10)

    def test_dual2_nodes(self):
        """Construct with Dual2-valued nodes."""
        d1 = Dual2("v0", 1.0)
        d2 = Dual2("v1", 0.97)
        d3 = Dual2("v2", 0.94)
        c = DiscountCurve(
            {date(2024, 1, 1): d1, date(2025, 1, 1): d2, date(2026, 1, 1): d3}
        )
        df = c.discount_factor(date(2025, 1, 1))
        assert isinstance(df, Dual2)
        assert df.real == pytest.approx(0.97, abs=1e-10)


# ============================================================
# CURV-02: Log-linear interpolation
# ============================================================


class TestLogLinearInterpolation:
    """CURV-02: Log-linear interpolation for DiscountCurve."""

    @pytest.fixture
    def curve(self):
        return DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            interpolation="log_linear",
            convention="act365f",
        )

    def test_at_node(self, curve):
        """Exact node value returned at node date."""
        assert curve.discount_factor(date(2025, 1, 1)) == pytest.approx(0.97, abs=1e-10)

    def test_midpoint(self, curve):
        """Mid-interval DF matches exp(lerp(log))."""
        df_mid = curve.discount_factor(date(2024, 7, 1))
        # Log-linear: exp(lerp(log(1.0), log(0.97)))
        # t = days(2024-01-01 to 2024-07-01) / days(2024-01-01 to 2025-01-01)
        d0 = date(2024, 1, 1)
        d1 = date(2024, 7, 1)
        d2 = date(2025, 1, 1)
        t = (d1 - d0).days / (d2 - d0).days
        expected = math.exp((1 - t) * math.log(1.0) + t * math.log(0.97))
        assert df_mid == pytest.approx(expected, abs=1e-10)

    def test_extrapolation(self, curve):
        """Flat forward extrapolation beyond last node."""
        df_far = curve.discount_factor(date(2030, 1, 1))
        assert df_far == pytest.approx(0.94, abs=1e-10)


# ============================================================
# CURV-03: Linear zero rate interpolation
# ============================================================


class TestLinearZeroRate:
    """CURV-03: Linear zero rate interpolation."""

    def test_linear_zero_rate(self):
        """Linear zero rate interpolation produces expected path."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            interpolation="linear_zero_rate",
            convention="act365f",
        )
        # At nodes, should reproduce node values
        assert c.discount_factor(date(2025, 1, 1)) == pytest.approx(0.97, abs=1e-10)
        # At midpoint, should interpolate linearly in zero rate space
        df_mid = c.discount_factor(date(2024, 7, 1))
        assert isinstance(df_mid, float)
        assert 0.97 < df_mid < 1.0


# ============================================================
# CURV-04: Flat forward/backward
# ============================================================


class TestFlatForwardBackward:
    """CURV-04: Flat forward and flat backward step functions."""

    def test_flat_forward(self):
        """Flat forward: right-continuous step function."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            interpolation="flat_forward",
        )
        # Between nodes: takes left node value
        df = c.discount_factor(date(2024, 7, 1))
        assert df == pytest.approx(1.0, abs=1e-10)

    def test_flat_backward(self):
        """Flat backward: left-continuous step function."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            interpolation="flat_backward",
        )
        # Between nodes: takes right node value
        df = c.discount_factor(date(2024, 7, 1))
        assert df == pytest.approx(0.97, abs=1e-10)


# ============================================================
# CURV-05: B-spline interpolation
# ============================================================


class TestSplineInterpolation:
    """CURV-05: B-spline (sugar) interpolation."""

    @pytest.fixture
    def nodes(self):
        return {
            date(2024, 1, 1): 1.0,
            date(2025, 1, 1): 0.97,
            date(2026, 1, 1): 0.94,
            date(2027, 1, 1): 0.90,
            date(2028, 1, 1): 0.85,
        }

    def test_spline_sugar(self, nodes):
        """interpolation='spline' builds log-cubic spline."""
        c = DiscountCurve(nodes, interpolation="spline")
        # Should reproduce nodes at node dates
        assert c.discount_factor(date(2025, 1, 1)) == pytest.approx(0.97, abs=1e-8)
        assert c.discount_factor(date(2026, 1, 1)) == pytest.approx(0.94, abs=1e-8)
        # Mid-point should be smooth and between adjacent values
        df_mid = c.discount_factor(date(2025, 7, 1))
        assert 0.93 < df_mid < 0.97

    def test_spline_with_knots(self, nodes):
        """Explicit t parameter for custom knot dates."""
        knot_dates = [
            date(2024, 1, 1),
            date(2025, 1, 1),
            date(2026, 1, 1),
            date(2027, 1, 1),
            date(2028, 1, 1),
        ]
        c = DiscountCurve(nodes, interpolation="spline", t=knot_dates)
        # Should still reproduce nodes
        assert c.discount_factor(date(2025, 1, 1)) == pytest.approx(0.97, abs=1e-8)

    def test_spline_endpoints(self, nodes):
        """not_a_knot vs natural produce different results."""
        c_nak = DiscountCurve(nodes, interpolation="spline", endpoints="not_a_knot")
        c_nat = DiscountCurve(nodes, interpolation="spline", endpoints="natural")
        # At a mid-point, they should differ (unless by coincidence)
        df_nak = c_nak.discount_factor(date(2025, 7, 1))
        df_nat = c_nat.discount_factor(date(2025, 7, 1))
        assert isinstance(df_nak, float)
        assert isinstance(df_nat, float)
        # Both should be reasonable
        assert 0.9 < df_nak < 1.0
        assert 0.9 < df_nat < 1.0


# ============================================================
# CURV-06: LineCurve
# ============================================================


class TestLineCurve:
    """CURV-06: LineCurve for rate/spread curves."""

    def test_construction(self):
        """Construct LineCurve with rate values."""
        c = LineCurve(
            {date(2024, 1, 1): 0.03, date(2025, 1, 1): 0.035, date(2026, 1, 1): 0.04},
            convention="act365f",
        )
        repr_str = repr(c)
        assert "LineCurve" in repr_str

    def test_discount_factor(self):
        """DF derived from interpolated rate: DF = exp(-rate * dcf)."""
        c = LineCurve(
            {date(2024, 1, 1): 0.03, date(2025, 1, 1): 0.035},
            convention="act365f",
        )
        # At first node: dcf = 0, DF = exp(0) = 1.0
        df_start = c.discount_factor(date(2024, 1, 1))
        assert df_start == pytest.approx(1.0, abs=1e-10)

        # At end: dcf = 366/365 (2024 leap year), rate = 0.035
        df_end = c.discount_factor(date(2025, 1, 1))
        dcf = 366.0 / 365.0
        expected = math.exp(-0.035 * dcf)
        assert df_end == pytest.approx(expected, abs=1e-10)

    def test_zero_rate(self):
        """Zero rate query on LineCurve."""
        c = LineCurve(
            {date(2024, 1, 1): 0.03, date(2026, 1, 1): 0.04},
            convention="act365f",
        )
        rate = c.zero_rate(date(2024, 1, 1), date(2026, 1, 1))
        assert isinstance(rate, float)
        assert rate > 0.0


# ============================================================
# CURV-07: Rate queries
# ============================================================


class TestRateQueries:
    """CURV-07: Rate query methods on DiscountCurve."""

    @pytest.fixture
    def curve(self):
        return DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94},
            convention="act365f",
        )

    def test_zero_rate_formula(self, curve):
        """zero_rate = -ln(DF2/DF1) / dcf."""
        rate = curve.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        # DF(start) = 1.0, DF(end) = 0.97
        # dcf = 366/365 (2024 leap year, Act365F)
        dcf = 366.0 / 365.0
        expected = -math.log(0.97 / 1.0) / dcf
        assert rate == pytest.approx(expected, abs=1e-10)

    def test_forward_rate(self, curve):
        """Forward rate between two dates."""
        fwd = curve.forward_rate(date(2025, 1, 1), date(2026, 1, 1))
        # DF(2025) = 0.97, DF(2026) = 0.94
        # dcf = 365/365 = 1.0 (2025 non-leap, Act365F)
        dcf = 365.0 / 365.0
        expected = -math.log(0.94 / 0.97) / dcf
        assert fwd == pytest.approx(expected, abs=1e-10)

    def test_tenor_string(self, curve):
        """zero_rate accepts tenor string for end date."""
        # date(2024, 1, 1) + "1Y" = date(2025, 1, 1)
        rate_tenor = curve.zero_rate(date(2024, 1, 1), "1Y")
        rate_date = curve.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        assert rate_tenor == pytest.approx(rate_date, abs=1e-10)

    def test_ad_propagation(self, curve):
        """Dual nodes -> Dual rate output with nonzero gradient."""
        d1 = Dual("v0", 1.0)
        d2 = Dual("v1", 0.97)
        d3 = Dual("v2", 0.94)
        c = DiscountCurve(
            {date(2024, 1, 1): d1, date(2025, 1, 1): d2, date(2026, 1, 1): d3},
            convention="act365f",
        )
        rate = c.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        assert isinstance(rate, Dual)
        assert rate.real > 0.0
        # Gradient should be nonzero (rate depends on v1)
        import numpy as np
        grad = rate.gradient()
        assert np.any(np.abs(grad) > 1e-10), "AD gradient should be nonzero"


# ============================================================
# Import tests
# ============================================================


class TestImports:
    """Verify import paths work correctly."""

    def test_import_from_curves(self):
        """from vade.curves import DiscountCurve, LineCurve"""
        from vade.curves import DiscountCurve, LineCurve
        assert DiscountCurve is not None
        assert LineCurve is not None

    def test_import_from_vade(self):
        """from vade import DiscountCurve, LineCurve"""
        from vade import DiscountCurve, LineCurve
        assert DiscountCurve is not None
        assert LineCurve is not None


# ============================================================
# Edge cases and string parameter tests
# ============================================================


class TestEdgeCases:
    """Edge cases and parameter validation."""

    def test_custom_id(self):
        """Custom id parameter."""
        c = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97},
            id="my_curve",
        )
        assert "my_curve" in repr(c)

    def test_interpolation_methods(self):
        """All interpolation methods are selectable via string."""
        nodes = {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94}
        for method in ["log_linear", "linear", "linear_zero_rate", "flat_forward", "flat_backward"]:
            c = DiscountCurve(nodes, interpolation=method)
            df = c.discount_factor(date(2024, 7, 1))
            assert isinstance(df, float), f"Failed for {method}"

    def test_invalid_interpolation(self):
        """Invalid interpolation string raises ValueError."""
        with pytest.raises(ValueError, match="Unknown interpolation"):
            DiscountCurve(
                {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97},
                interpolation="invalid",
            )

    def test_convention_variants(self):
        """Various convention strings work."""
        nodes = {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97}
        for conv in ["act360", "act365f"]:
            c = DiscountCurve(nodes, convention=conv)
            assert isinstance(c.discount_factor(date(2024, 7, 1)), float)


# ============================================================
# CompositeCurve integration tests (D-42, CURV-08)
# ============================================================


class TestCompositeCurveIntegration:
    """CompositeCurve used as drop-in curve for instrument pricing."""

    def test_composite_curve_with_instrument(self):
        """CompositeCurve (OIS + spread) used as discount curve for IRS pricing."""
        # OIS base curve
        ois_nodes = {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94}
        ois_curve = DiscountCurve(ois_nodes, interpolation="log_linear",
                                   convention="act365f", id="ois")
        # Spread curve (small spread as DiscountCurve)
        spread_nodes = {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.998, date(2026, 1, 1): 0.996}
        spread_curve = DiscountCurve(spread_nodes, interpolation="log_linear",
                                      convention="act365f", id="spread")
        # Composite = OIS * spread (per D-42)
        composite = CompositeCurve([ois_curve, spread_curve], id="funding")

        # Composite DF < OIS DF (spread adds cost)
        ois_df = float(ois_curve.discount_factor(date(2025, 1, 1)))
        comp_df = float(composite.discount_factor(date(2025, 1, 1)))
        assert comp_df < ois_df, "Composite DF should be less than OIS DF (spread adds cost)"
        # Verify multiplicative: comp_df ~ ois_df * spread_df
        spread_df = float(spread_curve.discount_factor(date(2025, 1, 1)))
        assert abs(comp_df - ois_df * spread_df) < 1e-10

        # Use CompositeCurve as disc curve for IRS pricing
        irs = IRS(effective=date(2024, 1, 1), termination=date(2026, 1, 1),
                  frequency="s", convention="act360", fixed_rate=3.0,
                  notional=1_000_000, currency="usd")
        # Should not raise -- CompositeCurve is a valid curve input
        npv_composite = irs.npv(composite)
        npv_ois = irs.npv(ois_curve)
        # Different discount curves produce different NPVs
        v_comp = float(npv_composite) if not isinstance(npv_composite, float) else npv_composite
        v_ois = float(npv_ois) if not isinstance(npv_ois, float) else npv_ois
        assert abs(v_comp - v_ois) > 1e-6, "Different discount curves should produce different NPVs"

    def test_composite_curve_line_addition(self):
        """Two LineCurves composed: rates add."""
        base_nodes = {date(2024, 1, 1): 3.0, date(2025, 1, 1): 3.2, date(2026, 1, 1): 3.4}
        spread_nodes = {date(2024, 1, 1): 0.2, date(2025, 1, 1): 0.2, date(2026, 1, 1): 0.2}
        base = LineCurve(base_nodes, id="base")
        spread = LineCurve(spread_nodes, id="spread")
        composite = CompositeCurve([base, spread], id="total")

        # For LineCurves, composition adds rates (per D-37)
        base_zr = base.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        comp_zr = composite.zero_rate(date(2024, 1, 1), date(2025, 1, 1))
        base_val = float(base_zr) if not isinstance(base_zr, float) else base_zr
        comp_val = float(comp_zr) if not isinstance(comp_zr, float) else comp_zr
        assert comp_val > base_val, "Composite rate should be higher than base"


# ============================================================
# FXImpliedCurve integration tests (D-38)
# ============================================================


class TestFXImpliedCurveIntegration:
    """FXImpliedCurve (FX-adjusted discounting per D-38) used as discount curve."""

    def test_proxy_curve_with_instrument(self):
        """FXImpliedCurve used as discount curve for IRS pricing."""
        usd_nodes = {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.97, date(2026, 1, 1): 0.94}
        eur_nodes = {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.975, date(2026, 1, 1): 0.95}
        usd_curve = DiscountCurve(usd_nodes, interpolation="log_linear",
                                   convention="act365f", id="usd_ois")
        eur_curve = DiscountCurve(eur_nodes, interpolation="log_linear",
                                   convention="act365f", id="eur_ois")

        fx_rates = FXRates({"eurusd": 1.1}, date(2024, 1, 1))

        # FXImpliedCurve: EUR cashflows with USD collateral
        proxy = FXImpliedCurve("eur", "usd", fx_rates, {"eurusd": date(2024, 1, 3)},
                           usd_curve, eur_curve, id="eur_usd_proxy")

        proxy_df = float(proxy.discount_factor(date(2025, 1, 1)))
        assert 0.5 < proxy_df < 1.5, f"FXImpliedCurve DF {proxy_df} out of range"

        # Should be usable as a discount curve for an IRS
        irs = IRS(effective=date(2024, 1, 1), termination=date(2026, 1, 1),
                  frequency="s", convention="act360", fixed_rate=3.0,
                  notional=1_000_000, currency="eur")
        npv = irs.npv(proxy)
        assert npv is not None, "FXImpliedCurve should work as curve input to IRS"
