"""Integration tests for risk sensitivities (delta, gamma) with DataFrame output."""

import datetime
import math

import polars as pl
import pytest

from vade import InterestRateSwap, DiscountCurve, Solver


def make_5irs_solver():
    """Build and calibrate a 5-IRS solver for risk testing."""
    base = datetime.date(2024, 1, 1)
    dates = [base]
    dfs = [1.0]
    tenors = [1, 2, 3, 4, 5]
    for y in tenors:
        d = datetime.date(2024 + y, 1, 1)
        dates.append(d)
        dfs.append(1.0)  # default -- solver will calibrate

    curve = DiscountCurve(
        dict(zip(dates, dfs)),
        interpolation="log_linear",
        convention="act365f",
        id="disc",
    )

    targets = [3.0, 3.2, 3.4, 3.5, 3.6]
    instruments = []
    irs_list = []
    for i, (y, target) in enumerate(zip(tenors, targets)):
        irs = InterestRateSwap(
            effective=base,
            termination=f"{y}Y",
            frequency="a",
            fixed_rate=target,
            convention="act365f",
            modifier="mf",
        )
        irs_list.append(irs)
        instruments.append((irs, target, 0, f"{y}Y_IRS", "USD"))

    solver = Solver(
        curves=[curve],
        instruments=instruments,
    )
    result = solver.iterate()
    assert result.converged, f"Solver failed: {result.status}"
    return solver, result, irs_list


def test_solver_delta_returns_dataframe():
    """solver.delta(instrument, result) returns Polars DataFrame
    with columns: instrument_label, tenor, sensitivity, currency."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.delta(irs_list[2], result)
    assert isinstance(df, pl.DataFrame)
    assert set(df.columns) == {"instrument_label", "tenor", "sensitivity", "currency"}
    assert len(df) == 5  # 5 calibrating instruments


def test_solver_gamma_returns_dataframe():
    """solver.gamma(instrument, result) returns labeled Polars DataFrame."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.gamma(irs_list[2], result)
    assert isinstance(df, pl.DataFrame)
    assert "label" in df.columns
    assert len(df) == 5  # 5x5 matrix


def test_delta_columns_schema():
    """Delta DataFrame has exact column schema per D-01."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.delta(irs_list[0], result)
    assert df.columns == ["instrument_label", "tenor", "sensitivity", "currency"]
    assert df["instrument_label"].dtype == pl.Utf8
    assert df["tenor"].dtype == pl.Utf8
    assert df["sensitivity"].dtype == pl.Float64
    assert df["currency"].dtype == pl.Utf8


def test_gamma_columns_schema():
    """Gamma DataFrame has label column + one column per instrument per D-02."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.gamma(irs_list[0], result)
    labels = df["label"].to_list()
    # First column is 'label', rest are instrument labels
    expected_cols = ["label"] + labels
    assert df.columns == expected_cols


def test_delta_portfolio_list():
    """solver.delta([inst1, inst2], result) returns aggregated DataFrame."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.delta([irs_list[0], irs_list[1]], result)
    assert isinstance(df, pl.DataFrame)
    assert set(df.columns) == {"instrument_label", "tenor", "sensitivity", "currency"}
    assert len(df) == 5


def test_gamma_portfolio_list():
    """solver.gamma([inst1, inst2], result) returns aggregated DataFrame."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.gamma([irs_list[0], irs_list[1]], result)
    assert isinstance(df, pl.DataFrame)
    assert "label" in df.columns
    assert len(df) == 5


def test_delta_self_sensitivity():
    """Delta of calibrating instrument has dominant self-sensitivity."""
    solver, result, irs_list = make_5irs_solver()
    # The 3Y IRS (index 2) should have strong sensitivity at its own tenor
    df = solver.delta(irs_list[2], result)
    sensitivities = df["sensitivity"].to_list()
    # At least some entries should be nonzero
    has_nonzero = any(abs(s) > 1e-10 for s in sensitivities)
    assert has_nonzero, "Delta should have nonzero entries"


def test_delta_values_finite():
    """All delta values should be finite."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.delta(irs_list[0], result)
    for s in df["sensitivity"].to_list():
        assert math.isfinite(s), f"Delta sensitivity {s} is not finite"


def test_gamma_symmetric():
    """Gamma matrix should be approximately symmetric."""
    solver, result, irs_list = make_5irs_solver()
    df = solver.gamma(irs_list[2], result)
    labels = df["label"].to_list()
    for i, li in enumerate(labels):
        for j, lj in enumerate(labels):
            g_ij = df[lj][i]
            g_ji = df[li][j]
            assert abs(g_ij - g_ji) < 1e-6, f"Gamma[{i},{j}]={g_ij} != Gamma[{j},{i}]={g_ji}"
