"""Integration tests for FittedBondCurve (FITC-01)."""

import pytest
from datetime import date
import vade


class TestFittedBondCurve:
    """Integration tests for FittedBondCurve (FITC-01)."""

    @pytest.fixture
    def bond_portfolio(self):
        """Create a portfolio of fixed-rate bonds with known market prices."""
        settlement = date(2024, 1, 15)
        bonds = []
        # Create 5 fixed-rate bonds with different maturities (2Y, 3Y, 5Y, 7Y, 10Y)
        for maturity_year, coupon, price in [
            (2026, 0.03, 99.5),
            (2027, 0.035, 99.0),
            (2029, 0.04, 98.5),
            (2031, 0.042, 97.0),
            (2034, 0.045, 95.0),
        ]:
            bond = vade.FixedRateBond(
                effective=settlement,
                termination=date(maturity_year, 1, 15),
                frequency="s",
                convention="act365f",
                coupon=coupon,
                face_value=100.0,
            )
            bonds.append(bond)
        prices = [99.5, 99.0, 98.5, 97.0, 95.0]
        return bonds, prices, settlement

    def test_ns_fit(self, bond_portfolio):
        """FITC-01a: Fit NS to bond portfolio, curve queryable."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS")
        assert fc.converged
        assert fc.rmse < 1.0  # reasonable fit
        # CurveQuery works
        df = fc.discount_factor(date(2025, 1, 15))
        assert 0.9 < df < 1.0
        zr = fc.zero_rate(settlement, date(2029, 1, 15))
        assert 0.0 < zr < 0.10

    def test_nss_fit(self, bond_portfolio):
        """FITC-01b: Fit NSS to bond portfolio."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NSS")
        assert fc.converged
        assert fc.rmse < 1.0

    def test_sw_fit(self, bond_portfolio):
        """FITC-01c: Fit SW to bond portfolio."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="SW", ufr=0.033, alpha=0.1)
        assert fc.converged
        assert fc.rmse < 1.0

    def test_custom_weights(self, bond_portfolio):
        """FITC-01e: Custom weights override."""
        bonds, prices, settlement = bond_portfolio
        weights = [1.0, 1.0, 2.0, 2.0, 3.0]  # emphasize long end
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS", weights=weights)
        assert fc.converged

    def test_fit_quality(self, bond_portfolio):
        """FITC-01f: RMSE and per-bond pricing errors available."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS")
        assert isinstance(fc.rmse, float)
        assert fc.rmse >= 0.0
        errors = fc.pricing_errors()
        assert len(errors) == len(bonds)
        assert all(isinstance(e, float) for e in errors)

    def test_convergence_info(self, bond_portfolio):
        """FITC-01g: Converged/iterations/objective available."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS")
        assert isinstance(fc.converged, bool)
        assert isinstance(fc.iterations, int)
        assert fc.iterations > 0
        assert isinstance(fc.objective, float)

    def test_curve_interop(self, bond_portfolio):
        """FITC-01h: Fitted curve works as input to bond analytics."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS")
        # Use fitted curve to price a bond
        test_bond = bonds[0]
        model_price = test_bond.price(fc, settlement=settlement)
        assert isinstance(model_price, float)
        assert 90.0 < model_price < 110.0

    def test_curve_attribute(self, bond_portfolio):
        """D-12: Inner curve accessible via .curve() method."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS")
        inner = fc.curve()
        assert isinstance(inner, vade.NelsonSiegel)

    def test_repr(self, bond_portfolio):
        """FittedBondCurve has informative repr."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS")
        r = repr(fc)
        assert "FittedBondCurve" in r
        assert "NS" in r

    def test_initial_params_override(self, bond_portfolio):
        """D-08: User can override initial parameters."""
        bonds, prices, settlement = bond_portfolio
        fc = vade.FittedBondCurve(
            bonds, prices, settlement, model="NS",
            initial_params=[0.04, -0.01, 0.0, 1.5],  # 4 NS params
        )
        assert fc.converged

    def test_import_from_vade(self):
        """FittedBondCurve importable from top-level vade namespace."""
        from vade import FittedBondCurve
        assert FittedBondCurve is not None

    def test_zero_coupon_bonds(self):
        """Fit works with ZeroCouponBond instruments too."""
        settlement = date(2024, 1, 15)
        bonds = [
            vade.ZeroCouponBond(
                effective=settlement,
                termination=date(2024 + i, 7, 15),
                convention="act365f",
                face_value=100.0,
                issue_price=100.0 - i * 3.0,
            )
            for i in range(1, 6)
        ]
        prices = [97.0, 94.0, 91.0, 87.5, 84.0]
        fc = vade.FittedBondCurve(bonds, prices, settlement, model="NS")
        assert fc.converged
