"""Tests for FixingStore class (FIX-01 through FIX-04) and MarketContext (CTX-01 through CTX-06)."""

from __future__ import annotations

import tempfile
from datetime import date
from pathlib import Path

import polars as pl
import pytest

from vade.context import FixingStore


class TestFixingStoreSetGet:
    """Basic CRUD operations on FixingStore."""

    def test_fixingstore_set_get(self):
        store = FixingStore()
        store.set("SOFR", {date(2024, 1, 2): 0.053})
        assert store.get_rate("SOFR", date(2024, 1, 2)) == 0.053
        result = store.get("SOFR")
        assert result is not None
        assert result[date(2024, 1, 2)] == 0.053
        assert store.get("MISSING") is None
        assert store.get_rate("SOFR", date(2099, 1, 1)) is None

    def test_fixingstore_set_merges(self):
        store = FixingStore()
        d1 = date(2024, 1, 2)
        d2 = date(2024, 1, 3)
        store.set("SOFR", {d1: 0.05})
        store.set("SOFR", {d2: 0.06})
        assert store.get_rate("SOFR", d1) == 0.05
        assert store.get_rate("SOFR", d2) == 0.06

    def test_fixingstore_string_date_parsing(self):
        store = FixingStore()
        store.set("SOFR", {"2024-01-02": 0.053})
        assert store.get_rate("SOFR", date(2024, 1, 2)) == 0.053
        assert store.get_rate("SOFR", "2024-01-02") == 0.053

    def test_fixingstore_clear_all(self):
        store = FixingStore()
        store.set("SOFR", {date(2024, 1, 2): 0.05})
        store.set("EURIBOR", {date(2024, 1, 2): 0.03})
        store.clear()
        assert store.list_indices() == []

    def test_fixingstore_clear_single(self):
        store = FixingStore()
        store.set("SOFR", {date(2024, 1, 2): 0.05})
        store.set("EURIBOR", {date(2024, 1, 2): 0.03})
        store.clear("SOFR")
        assert store.list_indices() == ["EURIBOR"]

    def test_fixingstore_list_indices(self):
        store = FixingStore()
        store.set("EURIBOR_3M", {date(2024, 1, 2): 0.03})
        store.set("SOFR", {date(2024, 1, 2): 0.05})
        assert store.list_indices() == ["EURIBOR_3M", "SOFR"]

    def test_fixingstore_independent_instances(self):
        store1 = FixingStore()
        store2 = FixingStore()
        store1.set("SOFR", {date(2024, 1, 2): 0.05})
        assert store2.get("SOFR") is None


class TestFixingStorePolars:
    """Bulk loading from Polars DataFrames (FIX-03)."""

    def test_fixingstore_from_polars_narrow(self):
        store = FixingStore()
        df = pl.DataFrame({
            "date": [date(2024, 1, 2), date(2024, 1, 3)],
            "value": [0.053, 0.054],
        })
        store.from_polars(df, index="SOFR")
        assert store.get_rate("SOFR", date(2024, 1, 2)) == 0.053
        assert store.get_rate("SOFR", date(2024, 1, 3)) == 0.054

    def test_fixingstore_from_polars_narrow_requires_index(self):
        store = FixingStore()
        df = pl.DataFrame({
            "date": [date(2024, 1, 2)],
            "value": [0.053],
        })
        with pytest.raises(ValueError, match="index name required"):
            store.from_polars(df)

    def test_fixingstore_from_polars_wide(self):
        store = FixingStore()
        df = pl.DataFrame({
            "date": [date(2024, 1, 2), date(2024, 1, 3)],
            "SOFR": [0.053, 0.054],
            "EURIBOR": [0.031, 0.032],
        })
        store.from_polars(df)
        assert store.get_rate("SOFR", date(2024, 1, 2)) == 0.053
        assert store.get_rate("EURIBOR", date(2024, 1, 3)) == 0.032

    def test_fixingstore_from_polars_merges(self):
        store = FixingStore()
        store.set("SOFR", {date(2024, 1, 1): 0.050})
        df = pl.DataFrame({
            "date": [date(2024, 1, 2)],
            "value": [0.053],
        })
        store.from_polars(df, index="SOFR")
        # Both old and new data present
        assert store.get_rate("SOFR", date(2024, 1, 1)) == 0.050
        assert store.get_rate("SOFR", date(2024, 1, 2)) == 0.053


class TestFixingStoreCSV:
    """Bulk loading from CSV files (FIX-04)."""

    def test_fixingstore_from_csv(self):
        store = FixingStore()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
            f.write("date,value\n")
            f.write("2024-01-02,0.053\n")
            f.write("2024-01-03,0.054\n")
            path = f.name
        try:
            store.from_csv(path, index="SOFR")
            assert store.get_rate("SOFR", date(2024, 1, 2)) == 0.053
            assert store.get_rate("SOFR", date(2024, 1, 3)) == 0.054
        finally:
            Path(path).unlink(missing_ok=True)

    def test_fixingstore_from_csv_wide(self):
        store = FixingStore()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
            f.write("date,SOFR,EURIBOR\n")
            f.write("2024-01-02,0.053,0.031\n")
            f.write("2024-01-03,0.054,0.032\n")
            path = f.name
        try:
            store.from_csv(path)
            assert store.get_rate("SOFR", date(2024, 1, 2)) == 0.053
            assert store.get_rate("EURIBOR", date(2024, 1, 3)) == 0.032
        finally:
            Path(path).unlink(missing_ok=True)


# ============================================================================
# MarketContext Tests (CTX-01 through CTX-06)
# ============================================================================

from vade.context import MarketContext, eval_date as vade_eval_date, get_eval_date


class TestMarketContextCreation:
    """CTX-01: MarketContext creation and defaults."""

    def test_marketcontext_creation(self):
        mock_curve = object()
        ctx = MarketContext(eval_date=date(2024, 6, 15), curves={"USD_SOFR": mock_curve})
        assert ctx.eval_date == date(2024, 6, 15)
        assert ctx.curves == {"USD_SOFR": mock_curve}

    def test_marketcontext_defaults(self):
        ctx = MarketContext()
        assert ctx.eval_date == date.today()
        assert ctx.curves == {}
        assert isinstance(ctx.fixings, FixingStore)
        assert ctx.fx_rates is None
        assert ctx.calendars == {}

    def test_marketcontext_curve_access_dict(self):
        mock_curve = object()
        ctx = MarketContext(curves={"USD_SOFR": mock_curve})
        assert ctx.curves["USD_SOFR"] is mock_curve
        with pytest.raises(KeyError):
            ctx.curves["MISSING"]

    def test_marketcontext_curve_method(self):
        mock_curve = object()
        ctx = MarketContext(curves={"USD_SOFR": mock_curve})
        assert ctx.curve("USD_SOFR") is mock_curve
        with pytest.raises(KeyError, match="not found in context"):
            ctx.curve("MISSING")

    def test_marketcontext_fixings(self):
        store = FixingStore()
        ctx = MarketContext(fixings=store)
        assert ctx.fixings is store

    def test_marketcontext_fx_rates(self):
        mock_fx = object()
        ctx = MarketContext(fx_rates=mock_fx)
        assert ctx.fx_rates is mock_fx

    def test_marketcontext_calendars(self):
        mock_cal = object()
        ctx = MarketContext(calendars={"NYC": mock_cal})
        assert ctx.calendars["NYC"] is mock_cal


class TestMarketContextImmutableDerivation:
    """CTX-02: .with_*() immutable derivation methods."""

    def test_marketcontext_with_eval_date(self):
        mock_curve = object()
        ctx = MarketContext(eval_date=date(2024, 1, 1), curves={"K": mock_curve})
        ctx2 = ctx.with_eval_date(date(2024, 6, 15))
        assert ctx2.eval_date == date(2024, 6, 15)
        assert ctx.eval_date == date(2024, 1, 1)  # original unchanged
        assert ctx2.curves is not ctx.curves  # different dict (defensive copy)
        assert ctx2.curves["K"] is ctx.curves["K"]  # same object ref (shallow copy)

    def test_marketcontext_with_curve(self):
        ctx = MarketContext(curves={"A": object()})
        new_curve = object()
        ctx2 = ctx.with_curve("NEW", new_curve)
        assert "NEW" in ctx2.curves
        assert "NEW" not in ctx.curves

    def test_marketcontext_with_fixings(self):
        old_store = FixingStore()
        new_store = FixingStore()
        ctx = MarketContext(fixings=old_store)
        ctx2 = ctx.with_fixings(new_store)
        assert ctx2.fixings is new_store
        assert ctx.fixings is old_store

    def test_marketcontext_with_fx_rates(self):
        old_fx = object()
        new_fx = object()
        ctx = MarketContext(fx_rates=old_fx)
        ctx2 = ctx.with_fx_rates(new_fx)
        assert ctx2.fx_rates is new_fx
        assert ctx.fx_rates is old_fx

    def test_marketcontext_with_calendar(self):
        ctx = MarketContext(calendars={"NYC": object()})
        new_cal = object()
        ctx2 = ctx.with_calendar("LDN", new_cal)
        assert "LDN" in ctx2.calendars
        assert "LDN" not in ctx.calendars


class TestEvalDateContextManager:
    """CTX-03: eval_date context manager."""

    def test_eval_date_context_manager(self):
        with vade_eval_date(date(2024, 1, 1)) as d:
            assert d == date(2024, 1, 1)
            assert get_eval_date() == date(2024, 1, 1)
        assert get_eval_date() == date.today()

    def test_eval_date_context_manager_nested(self):
        d1 = date(2024, 1, 1)
        d2 = date(2024, 6, 15)
        with vade_eval_date(d1):
            assert get_eval_date() == d1
            with vade_eval_date(d2):
                assert get_eval_date() == d2
            assert get_eval_date() == d1
        assert get_eval_date() == date.today()

    def test_eval_date_context_manager_resets_on_exception(self):
        try:
            with vade_eval_date(date(2024, 1, 1)):
                raise RuntimeError("boom")
        except RuntimeError:
            pass
        assert get_eval_date() == date.today()

    def test_marketcontext_eval_date_fallback(self):
        with vade_eval_date(date(2024, 3, 15)):
            ctx = MarketContext()
            assert ctx.eval_date == date(2024, 3, 15)

    def test_marketcontext_repr(self):
        ctx = MarketContext(eval_date=date(2024, 6, 15), curves={"A": 1, "B": 2})
        r = repr(ctx)
        assert "MarketContext" in r
        assert "2024-06-15" in r
        assert "2" in r  # curve count


# ============================================================================
# Solver integration tests (from_solver, curve_ids)
# ============================================================================


class TestMarketContextFromSolver:
    """CTX-05: MarketContext.from_solver() integration."""

    def _build_solver(self):
        """Build a minimal calibrated Solver for testing."""
        from vade import Solver, DiscountCurve, Deposit

        curve = DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.95},
            id="USD_SOFR",
            interpolation="log_linear",
        )
        dep = Deposit(
            effective=date(2024, 1, 1),
            termination="1y",
            calendar="NYC",
            convention="act360",
            fixed_rate=5.0,
        )
        solver = Solver(curves=[curve], instruments=[(dep, 5.0)])
        solver.iterate()
        return solver

    def test_solver_curve_ids(self):
        solver = self._build_solver()
        ids = solver.curve_ids
        assert isinstance(ids, list)
        assert "USD_SOFR" in ids

    def test_marketcontext_from_solver(self):
        solver = self._build_solver()
        ctx = MarketContext.from_solver(solver, eval_date=date(2024, 6, 15))
        assert ctx.eval_date == date(2024, 6, 15)
        assert "USD_SOFR" in ctx.curves
        # Should not raise
        curve = ctx.curve("USD_SOFR")
        assert curve is not None


# ============================================================================
# Namespace and backward compatibility tests
# ============================================================================


class TestVadeNamespace:
    """Verify top-level vade namespace exports."""

    def test_vade_namespace_marketcontext(self):
        import vade
        assert hasattr(vade, "MarketContext")

    def test_vade_namespace_fixingstore(self):
        import vade
        assert hasattr(vade, "FixingStore")

    def test_vade_namespace_eval_date(self):
        import vade
        assert hasattr(vade, "eval_date")

    def test_fixings_module_backward_compat(self):
        import vade.fixings as f
        f.set("TEST_COMPAT", {"2024-01-01": 1.0})
        assert f.get_rate("TEST_COMPAT", "2024-01-01") == 1.0
        f.clear()

    def test_fixingstore_and_module_share_nothing(self):
        """FixingStore instances are independent of vade.fixings module singleton."""
        import vade.fixings as f
        store = FixingStore()
        store.set("PRIVATE", {date(2024, 1, 1): 99.0})
        assert f.get("PRIVATE") is None
        store.clear()


# ---------------------------------------------------------------------------
# Phase 32 Plan 02: Integration tests for instrument context resolution
# ---------------------------------------------------------------------------

from vade.instruments import (
    InterestRateSwap as IRS,
    Deposit,
    FixedRateBond,
    CrossCurrencySwap,
    FXForward,
    NDF,
    NDIRS,
    NDXCS,
)
from vade.curves import DiscountCurve


class TestInstrumentContextResolution:
    """INST-01, INST-02: instruments resolve curves from ctx=."""

    @pytest.fixture
    def curve(self):
        """A simple discount curve for testing."""
        return DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.96, date(2029, 1, 1): 0.82, date(2034, 1, 1): 0.65},
            "log_linear",
        )

    @pytest.fixture
    def ctx(self, curve):
        return MarketContext(
            eval_date=date(2024, 1, 1),
            curves={"USD_SOFR": curve},
        )

    def test_irs_ctx_equals_explicit(self, curve, ctx):
        irs = IRS(
            effective=date(2024, 1, 1), termination="5Y", fixed_rate=3.0,
            disc_curve_id="USD_SOFR", forecast_curve_id="USD_SOFR",
        )
        assert irs.npv(ctx=ctx) == irs.npv(curve)
        assert irs.rate(ctx=ctx) == irs.rate(curve)

    def test_deposit_ctx_equals_explicit(self, curve, ctx):
        dep = Deposit(
            effective=date(2024, 1, 1), termination="3M", rate=5.0,
            disc_curve_id="USD_SOFR",
        )
        assert dep.npv(ctx=ctx) == dep.npv(curve)

    def test_bond_ctx_equals_explicit(self, curve, ctx):
        bond = FixedRateBond(
            effective=date(2024, 1, 1), termination="10Y", coupon=0.04,
            disc_curve_id="USD_SOFR",
        )
        assert bond.npv(ctx=ctx) == bond.npv(curve)

    def test_priority_explicit_over_ctx(self, curve, ctx):
        """D-01: explicit curves= wins over ctx=."""
        irs = IRS(
            effective=date(2024, 1, 1), termination="5Y", fixed_rate=3.0,
            disc_curve_id="USD_SOFR", forecast_curve_id="USD_SOFR",
        )
        # Passing both curves= and ctx= should use curves=
        result_explicit = irs.npv(curve)
        result_both = irs.npv(curve, ctx=ctx)
        assert result_explicit == result_both


class TestFixingResolution:
    """FIX-05: instruments auto-resolve fixings from context."""

    def test_resolve_fixings_from_context(self):
        """_resolve_fixings returns ctx fixings over module-level."""
        from vade.instruments._helpers import _resolve_fixings
        store = FixingStore()
        store.set("SOFR", {date(2024, 1, 2): 0.053})
        ctx = MarketContext(fixings=store)
        result = _resolve_fixings("SOFR", ctx=ctx)
        assert result is not None
        assert result[date(2024, 1, 2)] == 0.053

    def test_explicit_fixings_win(self):
        """Explicit fixings= param beats ctx fixings."""
        from vade.instruments._helpers import _resolve_fixings
        store = FixingStore()
        store.set("SOFR", {date(2024, 1, 2): 0.053})
        ctx = MarketContext(fixings=store)
        explicit = {date(2024, 1, 2): 0.999}
        result = _resolve_fixings("SOFR", explicit_fixings=explicit, ctx=ctx)
        assert result[date(2024, 1, 2)] == 0.999

    def test_index_storage_from_spec(self):
        """Instruments store _index from spec or explicit param."""
        irs = IRS(effective=date(2024, 1, 1), termination="5Y", fixed_rate=3.0, index="SOFR")
        assert irs._index == "SOFR"

    def test_index_storage_none_default(self):
        """Without index param, _index defaults from spec or None."""
        irs = IRS(effective=date(2024, 1, 1), termination="5Y", fixed_rate=3.0)
        # No spec, no explicit -- should be None
        assert irs._index is None


class TestCrossCurrencyContext:
    """INST-03: cross-currency instruments resolve FX from context."""

    def test_xcs_stores_curve_ids(self):
        xcs = CrossCurrencySwap(
            effective=date(2024, 1, 1), termination="3Y",
            leg1_disc_curve_id="EUR_ESTR",
            leg1_forecast_curve_id="EUR_ESTR",
            leg2_disc_curve_id="USD_SOFR",
            leg2_forecast_curve_id="USD_SOFR",
        )
        assert xcs._leg1_disc_curve_id == "EUR_ESTR"
        assert xcs._leg2_disc_curve_id == "USD_SOFR"

    def test_fxforward_stores_curve_ids(self):
        fxf = FXForward(
            pair="eurusd", delivery=date(2025, 1, 1),
            disc_curve_id="EUR_ESTR", forecast_curve_id="USD_SOFR",
        )
        assert fxf._disc_curve_id == "EUR_ESTR"
        assert fxf._forecast_curve_id == "USD_SOFR"

    def test_ndf_fx_fixing_index(self):
        """D-11: NDF stores _fx_fixing_index as PAIR_FIX."""
        ndf = NDF(
            pair="usdbrl", delivery=date(2025, 1, 1),
            contracted_rate=5.5, settlement_currency="usd",
            disc_curve_id="USD_SOFR", forecast_curve_id="BRL_CDI",
        )
        assert ndf._fx_fixing_index == "USDBRL_FIX"

    def test_ndirs_stores_fx_fixing_index(self):
        """NDIRS stores _fx_fixing_index based on pair."""
        ndirs = NDIRS(
            effective=date(2024, 1, 1), termination="5Y",
            fixed_rate=10.0, settlement_currency="usd", pair="usdbrl",
            disc_curve_id="USD_SOFR", forecast_curve_id="BRL_CDI",
            leg2_disc_curve_id="BRL_CDI",
        )
        assert ndirs._fx_fixing_index == "USDBRL_FIX"

    def test_ndxcs_stores_curve_ids_and_fx_fixing(self):
        """NDXCS stores curve IDs as direct attributes."""
        ndxcs = NDXCS(
            effective=date(2024, 1, 1), termination="5Y",
            disc_curve_id="USD_SOFR", forecast_curve_id="USD_SOFR",
            leg2_disc_curve_id="BRL_CDI", leg2_forecast_curve_id="BRL_CDI",
        )
        assert ndxcs._leg1_disc_curve_id == "USD_SOFR"
        assert ndxcs._leg2_disc_curve_id == "BRL_CDI"
        assert ndxcs._fx_fixing_index == "USDBRL_FIX"

    def test_xcs_ctx_signature(self):
        """XCS methods accept ctx= keyword arg."""
        import inspect
        for method_name in ["rate", "npv", "cashflows"]:
            sig = inspect.signature(getattr(CrossCurrencySwap, method_name))
            assert "ctx" in sig.parameters, f"CrossCurrencySwap.{method_name} missing ctx="

    def test_ndirs_ctx_signature(self):
        """NDIRS methods accept ctx= keyword arg."""
        import inspect
        for method_name in ["rate", "npv", "cashflows", "spread"]:
            sig = inspect.signature(getattr(NDIRS, method_name))
            assert "ctx" in sig.parameters, f"NDIRS.{method_name} missing ctx="

    def test_ndxcs_ctx_signature(self):
        """NDXCS methods accept ctx= keyword arg."""
        import inspect
        for method_name in ["rate", "npv", "cashflows", "spread"]:
            sig = inspect.signature(getattr(NDXCS, method_name))
            assert "ctx" in sig.parameters, f"NDXCS.{method_name} missing ctx="


# ============================================================================
# Phase 33 Plan 01: MarketContext serialization tests
# ============================================================================

import json

from vade.curves import DiscountCurve as DC, LineCurve
from vade.fx import FXRates
from vade.calendar import BusinessCalendar


class TestMarketContextSerialization:
    """SER-01, SER-02, SER-03: MarketContext to_json/from_json round-trip."""

    # --- fx_pairs plumbing ---

    def test_fx_pairs_kwarg_stored(self):
        """MarketContext accepts fx_pairs and stores as _fx_pairs."""
        ctx = MarketContext(eval_date=date(2024, 1, 1), fx_pairs={"EURUSD": 1.08})
        assert ctx._fx_pairs == {"EURUSD": 1.08}

    def test_with_eval_date_preserves_fx_pairs(self):
        ctx = MarketContext(eval_date=date(2024, 1, 1), fx_pairs={"EURUSD": 1.08})
        ctx2 = ctx.with_eval_date(date(2024, 6, 1))
        assert ctx2._fx_pairs == {"EURUSD": 1.08}

    def test_with_curve_preserves_fx_pairs(self):
        ctx = MarketContext(eval_date=date(2024, 1, 1), fx_pairs={"EURUSD": 1.08})
        ctx2 = ctx.with_curve("K", object())
        assert ctx2._fx_pairs == {"EURUSD": 1.08}

    def test_with_fixings_preserves_fx_pairs(self):
        ctx = MarketContext(eval_date=date(2024, 1, 1), fx_pairs={"EURUSD": 1.08})
        ctx2 = ctx.with_fixings(FixingStore())
        assert ctx2._fx_pairs == {"EURUSD": 1.08}

    def test_with_calendar_preserves_fx_pairs(self):
        ctx = MarketContext(eval_date=date(2024, 1, 1), fx_pairs={"EURUSD": 1.08})
        ctx2 = ctx.with_calendar("NYC", object())
        assert ctx2._fx_pairs == {"EURUSD": 1.08}

    def test_with_fx_rates_updates_fx_pairs(self):
        ctx = MarketContext(
            eval_date=date(2024, 1, 1),
            fx_rates=FXRates({"eurusd": 1.08}, date(2024, 1, 3)),
            fx_pairs={"eurusd": 1.08},
        )
        new_fx = FXRates({"gbpusd": 1.27}, date(2024, 1, 3))
        ctx2 = ctx.with_fx_rates(new_fx, fx_pairs={"gbpusd": 1.27})
        assert ctx2._fx_pairs == {"gbpusd": 1.27}

    def test_with_fx_rates_carries_over_fx_pairs(self):
        ctx = MarketContext(
            eval_date=date(2024, 1, 1),
            fx_rates=FXRates({"eurusd": 1.08}, date(2024, 1, 3)),
            fx_pairs={"eurusd": 1.08},
        )
        new_fx = FXRates({"eurusd": 1.10}, date(2024, 1, 3))
        ctx2 = ctx.with_fx_rates(new_fx)
        assert ctx2._fx_pairs == {"eurusd": 1.08}

    def test_from_solver_passes_fx_pairs(self):
        """from_solver() accepts and passes through fx_pairs."""
        from vade import Solver

        curve = DC(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.95},
            id="USD_SOFR",
        )
        dep = Deposit(
            effective=date(2024, 1, 1), termination="1y",
            calendar="NYC", convention="act360", fixed_rate=5.0,
        )
        solver = Solver(curves=[curve], instruments=[(dep, 5.0)])
        solver.iterate()
        ctx = MarketContext.from_solver(solver, fx_pairs={"eurusd": 1.08})
        assert ctx._fx_pairs == {"eurusd": 1.08}

    # --- to_json basic ---

    def test_to_json_returns_valid_json(self):
        ctx = MarketContext(eval_date=date(2024, 1, 1))
        result = ctx.to_json()
        data = json.loads(result)
        assert "eval_date" in data
        assert "curves" in data
        assert "fixings" in data
        assert "fx_rates" in data
        assert "calendars" in data

    def test_to_json_compact_format(self):
        """to_json uses compact separators (no spaces)."""
        ctx = MarketContext(eval_date=date(2024, 1, 1))
        result = ctx.to_json()
        # compact JSON has no spaces after colons or commas
        assert ": " not in result or result.count(": ") == 0

    def test_to_json_curve_envelope(self):
        """Curves are wrapped in envelope: {type, data}."""
        curve = DC(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.95},
            id="USD_SOFR",
        )
        ctx = MarketContext(eval_date=date(2024, 1, 1), curves={"USD_SOFR": curve})
        data = json.loads(ctx.to_json())
        env = data["curves"]["USD_SOFR"]
        assert env["type"] == "DiscountCurve"
        assert "data" in env

    # --- from_json basic ---

    def test_from_json_restores_eval_date(self):
        ctx = MarketContext(eval_date=date(2024, 6, 15))
        restored = MarketContext.from_json(ctx.to_json())
        assert restored.eval_date == date(2024, 6, 15)

    def test_from_json_restores_polymorphic_curves(self):
        """Different curve types are correctly disambiguated."""
        dc = DC(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.95},
            id="DISC",
        )
        lc = LineCurve(
            {date(2024, 1, 1): 0.05, date(2025, 1, 1): 0.06},
            id="LINE",
        )
        ctx = MarketContext(eval_date=date(2024, 1, 1), curves={"DISC": dc, "LINE": lc})
        restored = MarketContext.from_json(ctx.to_json())
        assert type(restored.curve("DISC")).__name__ == "DiscountCurve"
        assert type(restored.curve("LINE")).__name__ == "LineCurve"

    def test_roundtrip_discount_factor_preserved(self):
        """SER-03: discount_factor values match after round-trip."""
        dc = DC(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.95},
            id="USD_SOFR",
        )
        ctx = MarketContext(eval_date=date(2024, 1, 1), curves={"USD_SOFR": dc})
        restored = MarketContext.from_json(ctx.to_json())
        original_df = dc.discount_factor(date(2024, 7, 1))
        restored_df = restored.curve("USD_SOFR").discount_factor(date(2024, 7, 1))
        assert original_df == restored_df

    def test_roundtrip_fixings_preserved(self):
        """SER-03: FixingStore data survives round-trip."""
        store = FixingStore()
        store.set("SOFR", {date(2024, 1, 2): 0.053, date(2024, 1, 3): 0.054})
        store.set("EURIBOR", {date(2024, 1, 2): 0.031})
        ctx = MarketContext(eval_date=date(2024, 1, 1), fixings=store)
        restored = MarketContext.from_json(ctx.to_json())
        assert restored.fixings.get_rate("SOFR", date(2024, 1, 2)) == 0.053
        assert restored.fixings.get_rate("SOFR", date(2024, 1, 3)) == 0.054
        assert restored.fixings.get_rate("EURIBOR", date(2024, 1, 2)) == 0.031

    def test_roundtrip_fx_rates_preserved(self):
        """SER-03: FXRates accessible after round-trip."""
        fx = FXRates({"eurusd": 1.08}, date(2024, 1, 3))
        ctx = MarketContext(
            eval_date=date(2024, 1, 1),
            fx_rates=fx,
            fx_pairs={"eurusd": 1.08},
        )
        restored = MarketContext.from_json(ctx.to_json())
        assert restored.fx_rates is not None
        assert float(restored.fx_rates.rate("eurusd")) == pytest.approx(1.08)
        assert restored.fx_rates.settlement == date(2024, 1, 3)

    def test_roundtrip_named_calendars_preserved(self):
        """SER-03: Named calendars survive round-trip."""
        cal = BusinessCalendar("NYC")
        ctx = MarketContext(eval_date=date(2024, 1, 1), calendars={"NYC": cal})
        restored = MarketContext.from_json(ctx.to_json())
        assert "NYC" in restored.calendars
        assert "BusinessCalendar" in repr(restored.calendars["NYC"])

    # --- Error cases ---

    def test_to_json_raises_without_fx_pairs(self):
        """to_json raises ValueError when fx_rates set but fx_pairs missing."""
        fx = FXRates({"eurusd": 1.08}, date(2024, 1, 3))
        ctx = MarketContext(eval_date=date(2024, 1, 1), fx_rates=fx)
        with pytest.raises(ValueError, match="cannot be serialized without fx_pairs"):
            ctx.to_json()

    def test_to_json_raises_custom_calendar(self):
        """to_json raises ValueError for custom (non-named) calendars."""
        cal = BusinessCalendar.new_custom([], [])
        ctx = MarketContext(eval_date=date(2024, 1, 1), calendars={"CUSTOM": cal})
        with pytest.raises(ValueError, match="custom calendars"):
            ctx.to_json()

    def test_to_json_raises_non_serializable_curve(self):
        """to_json raises ValueError for curve types not in registry."""

        class FakeCurve:
            pass

        ctx = MarketContext(eval_date=date(2024, 1, 1), curves={"BAD": FakeCurve()})
        with pytest.raises(ValueError, match="not serializable"):
            ctx.to_json()

    # --- Graceful handling of optional fields ---

    def test_from_json_handles_null_fx_rates(self):
        """from_json with fx_rates=null produces ctx.fx_rates is None."""
        ctx = MarketContext(eval_date=date(2024, 1, 1))
        restored = MarketContext.from_json(ctx.to_json())
        assert restored.fx_rates is None

    def test_from_json_handles_empty_calendars(self):
        """from_json with empty calendars dict works."""
        ctx = MarketContext(eval_date=date(2024, 1, 1))
        restored = MarketContext.from_json(ctx.to_json())
        assert restored.calendars == {}


# ============================================================================
# Phase 34 Plan 01: MarketContext analytics convenience methods
# ============================================================================


class TestMarketContextAnalytics:
    """STAT-01: Convenience query methods on MarketContext."""

    @pytest.fixture
    def curve(self):
        return DiscountCurve(
            {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.95, date(2026, 1, 1): 0.90},
            id="USD_SOFR",
            interpolation="log_linear",
        )

    @pytest.fixture
    def ctx(self, curve):
        return MarketContext(
            eval_date=date(2024, 1, 1),
            curves={"USD_SOFR": curve},
        )

    def test_discount_factor(self, curve, ctx):
        dt = date(2024, 7, 1)
        expected = curve.discount_factor(dt)
        assert ctx.discount_factor("USD_SOFR", dt) == expected

    def test_forward_rate(self, curve, ctx):
        start = date(2024, 7, 1)
        end = date(2025, 1, 1)
        expected = curve.forward_rate(start, end)
        assert ctx.forward_rate("USD_SOFR", start, end) == expected

    def test_zero_rate(self, curve, ctx):
        start = date(2024, 1, 1)
        end = date(2025, 1, 1)
        expected = curve.zero_rate(start, end)
        assert ctx.zero_rate("USD_SOFR", start, end) == expected

    def test_fx_rate(self):
        fx = FXRates({"eurusd": 1.08}, date(2024, 1, 3))
        ctx = MarketContext(
            eval_date=date(2024, 1, 1),
            fx_rates=fx,
        )
        result = ctx.fx_rate("EUR", "USD")
        assert float(result) == pytest.approx(1.08)

    def test_convenience_missing_curve(self, ctx):
        with pytest.raises(KeyError, match="not found in context"):
            ctx.discount_factor("NONEXISTENT", date(2024, 7, 1))

    def test_fx_rate_no_fx_rates(self):
        ctx = MarketContext(eval_date=date(2024, 1, 1))
        with pytest.raises(ValueError, match="No FX rates in context"):
            ctx.fx_rate("USD", "EUR")


class TestMarketContextDiff:
    """STAT-02: MarketContext diff method."""

    def test_diff_eval_date(self):
        ctx1 = MarketContext(eval_date=date(2024, 1, 1))
        ctx2 = MarketContext(eval_date=date(2024, 6, 15))
        result = ctx1.diff(ctx2)
        assert result["eval_date"]["changed"] is True
        assert result["eval_date"]["self"] == date(2024, 1, 1)
        assert result["eval_date"]["other"] == date(2024, 6, 15)

        # Same eval_date
        ctx3 = MarketContext(eval_date=date(2024, 1, 1))
        result2 = ctx1.diff(ctx3)
        assert result2["eval_date"]["changed"] is False

    def test_diff_curves(self):
        curve_a = object()
        curve_b = object()
        ctx1 = MarketContext(eval_date=date(2024, 1, 1), curves={"A": curve_a})
        ctx2 = MarketContext(eval_date=date(2024, 1, 1), curves={"A": curve_a, "B": curve_b})
        result = ctx1.diff(ctx2)
        assert result["curves"]["added"] == ["B"]
        assert result["curves"]["removed"] == []
        assert result["curves"]["common"] == ["A"]

    def test_diff_fixings(self):
        store1 = FixingStore()
        store1.set("SOFR", {date(2024, 1, 2): 0.05})
        store2 = FixingStore()
        store2.set("SOFR", {date(2024, 1, 2): 0.05})
        store2.set("EURIBOR", {date(2024, 1, 2): 0.03})
        ctx1 = MarketContext(eval_date=date(2024, 1, 1), fixings=store1)
        ctx2 = MarketContext(eval_date=date(2024, 1, 1), fixings=store2)
        result = ctx1.diff(ctx2)
        assert result["fixings"]["added"] == ["EURIBOR"]
        assert result["fixings"]["removed"] == []
        assert result["fixings"]["common"] == ["SOFR"]

    def test_diff_fx_rates(self):
        fx = FXRates({"eurusd": 1.08}, date(2024, 1, 3))
        ctx1 = MarketContext(eval_date=date(2024, 1, 1), fx_rates=fx)
        ctx2 = MarketContext(eval_date=date(2024, 1, 1))
        result = ctx1.diff(ctx2)
        assert result["fx_rates"]["changed"] is True

        # Both None
        ctx3 = MarketContext(eval_date=date(2024, 1, 1))
        ctx4 = MarketContext(eval_date=date(2024, 1, 1))
        result2 = ctx3.diff(ctx4)
        assert result2["fx_rates"]["changed"] is False

    def test_diff_calendars(self):
        cal_a = object()
        cal_b = object()
        ctx1 = MarketContext(eval_date=date(2024, 1, 1), calendars={"NYC": cal_a, "LDN": cal_b})
        ctx2 = MarketContext(eval_date=date(2024, 1, 1), calendars={"NYC": cal_a})
        result = ctx1.diff(ctx2)
        assert result["calendars"]["added"] == []
        assert result["calendars"]["removed"] == ["LDN"]
        assert result["calendars"]["common"] == ["NYC"]

    def test_diff_identical(self):
        ctx = MarketContext(eval_date=date(2024, 1, 1))
        result = ctx.diff(ctx)
        assert result["eval_date"]["changed"] is False
        assert result["curves"]["added"] == []
        assert result["curves"]["removed"] == []
        assert result["fixings"]["added"] == []
        assert result["fixings"]["removed"] == []
        assert result["fx_rates"]["changed"] is False
        assert result["calendars"]["added"] == []
        assert result["calendars"]["removed"] == []

    def test_diff_dataframe(self):
        ctx1 = MarketContext(eval_date=date(2024, 1, 1), curves={"A": object()})
        ctx2 = MarketContext(eval_date=date(2024, 6, 15), curves={"A": object(), "B": object()})
        result = ctx1.diff(ctx2, as_dataframe=True)
        assert isinstance(result, pl.DataFrame)
        assert result.columns == ["section", "key", "change", "self_value", "other_value"]
        assert len(result) > 0
