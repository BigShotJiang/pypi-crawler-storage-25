"""Comprehensive tests for NDF (Non-Deliverable Forward) instrument.

Covers NDF-01 through NDF-07, spread calculation, and JSON serialization.
"""

import datetime
import json

import pytest

from vade import NDF, FXForward, FXRates, Solver, Dual
from vade.curves import DiscountCurve
from vade.instruments.specs import INSTRUMENT_SPECS


def _d(y, m, d):
    return datetime.date(y, m, d)


def _make_disc_curve(nodes, id="curve"):
    return DiscountCurve(
        nodes,
        interpolation="log_linear",
        convention="act365f",
        id=id,
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def eval_date():
    return _d(2024, 1, 15)


@pytest.fixture
def usd_curve():
    """USD discount curve."""
    return _make_disc_curve(
        {
            _d(2024, 1, 1): 1.0,
            _d(2024, 7, 1): 0.985,
            _d(2025, 1, 1): 0.97,
            _d(2026, 1, 1): 0.94,
        },
        id="usd",
    )


@pytest.fixture
def brl_curve():
    """BRL offshore discount curve."""
    return _make_disc_curve(
        {
            _d(2024, 1, 1): 1.0,
            _d(2024, 7, 1): 0.945,
            _d(2025, 1, 1): 0.89,
            _d(2026, 1, 1): 0.80,
        },
        id="brl",
    )


@pytest.fixture
def fxr(eval_date):
    """FXRates with USDBRL spot."""
    return FXRates({"usdbrl": 5.0}, eval_date)


# ---------------------------------------------------------------------------
# NDF-01: Construction
# ---------------------------------------------------------------------------


class TestNDFConstruction:
    def test_basic_2ccy_construction(self):
        ndf = NDF(
            pair="usdbrl",
            notional=1_000_000.0,
            delivery=_d(2025, 7, 1),
            settlement_currency="usd",
            contracted_rate=5.50,
        )
        assert ndf is not None

    def test_requires_delivery(self):
        with pytest.raises(ValueError, match="delivery"):
            NDF(
                pair="usdbrl",
                notional=1e6,
                settlement_currency="usd",
                contracted_rate=5.5,
            )

    def test_requires_contracted_rate(self):
        with pytest.raises(ValueError, match="contracted_rate"):
            NDF(
                pair="usdbrl",
                notional=1e6,
                delivery=_d(2025, 7, 1),
                settlement_currency="usd",
            )

    def test_ndf_is_fxforward_subclass(self):
        ndf = NDF(
            pair="usdbrl",
            notional=1e6,
            delivery=_d(2025, 7, 1),
            settlement_currency="usd",
            contracted_rate=5.5,
        )
        assert isinstance(ndf, FXForward)

    def test_import_from_vade(self):
        from vade import NDF as _NDF
        assert _NDF is not None


# ---------------------------------------------------------------------------
# NDF-02: Rate (implied forward)
# ---------------------------------------------------------------------------


class TestNDFRate:
    def test_rate_returns_implied_forward(self, usd_curve, brl_curve, fxr):
        ndf = NDF(
            pair="usdbrl",
            notional=1e6,
            delivery=_d(2025, 1, 1),
            settlement_currency="usd",
            contracted_rate=5.5,
        )
        rate = ndf.rate(usd_curve, brl_curve, fxr)
        val = float(rate) if not isinstance(rate, float) else rate
        # Implied forward = spot * DF_usd(delivery) / DF_brl(delivery)
        # = 5.0 * 0.97 / 0.89 ~ 5.449
        expected = 5.0 * 0.97 / 0.89
        assert abs(val - expected) < 0.05, f"NDF rate {val} not close to expected {expected}"

    def test_rate_returns_dual(self, usd_curve, brl_curve, fxr):
        ndf = NDF(
            pair="usdbrl",
            notional=1e6,
            delivery=_d(2025, 1, 1),
            settlement_currency="usd",
            contracted_rate=5.5,
        )
        rate = ndf.rate(usd_curve, brl_curve, fxr)
        # Rate should be numeric (float or Dual)
        val = float(rate) if not isinstance(rate, float) else rate
        assert isinstance(val, float)


# ---------------------------------------------------------------------------
# NDF-03: NPV
# ---------------------------------------------------------------------------


class TestNDFNPV:
    def test_npv_at_market_near_zero(self, usd_curve, brl_curve, fxr):
        """NPV near zero when contracted_rate equals implied forward."""
        # First get implied forward
        ndf_probe = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.0,
        )
        implied_fwd = float(ndf_probe.rate(usd_curve, brl_curve, fxr))

        # Create NDF at implied forward
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=implied_fwd,
        )
        npv = float(ndf.npv(usd_curve, brl_curve, fxr))
        assert abs(npv) < 100, f"NPV at market should be near zero, got {npv}"

    def test_npv_in_the_money(self, usd_curve, brl_curve, fxr):
        """Contracted rate below market for USDBRL => bought BRL cheap => positive NPV."""
        ndf_probe = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.0,
        )
        implied_fwd = float(ndf_probe.rate(usd_curve, brl_curve, fxr))

        # Buy BRL at below-market rate (cheaper)
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=implied_fwd - 0.5,
        )
        npv = float(ndf.npv(usd_curve, brl_curve, fxr))
        # The sign convention depends on Rust implementation; just check it is non-trivial
        assert abs(npv) > 100, f"In-the-money NDF should have significant NPV, got {npv}"

    def test_npv_out_of_the_money(self, usd_curve, brl_curve, fxr):
        """Contracted rate above market for USDBRL => bought BRL expensive."""
        ndf_probe = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.0,
        )
        implied_fwd = float(ndf_probe.rate(usd_curve, brl_curve, fxr))

        ndf_itm = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=implied_fwd - 0.5,
        )
        ndf_otm = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=implied_fwd + 0.5,
        )
        npv_itm = float(ndf_itm.npv(usd_curve, brl_curve, fxr))
        npv_otm = float(ndf_otm.npv(usd_curve, brl_curve, fxr))
        # ITM and OTM NPVs should have opposite signs
        assert npv_itm * npv_otm < 0, f"ITM ({npv_itm}) and OTM ({npv_otm}) should have opposite signs"

    def test_npv_with_fixing(self, usd_curve, brl_curve, fxr):
        """NPV uses fixing when fx_fixing is set."""
        ndf_no_fix = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        ndf_with_fix = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5, fx_fixing=5.42,
        )
        npv1 = float(ndf_no_fix.npv(usd_curve, brl_curve, fxr))
        npv2 = float(ndf_with_fix.npv(usd_curve, brl_curve, fxr))
        # NPVs should differ when fixing is provided vs implied
        assert abs(npv1 - npv2) > 0.01 or abs(npv1) < 1, \
            "NPV with fixing should differ from NPV without (unless fixing equals implied)"

    def test_npv_returns_number(self, usd_curve, brl_curve, fxr):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        npv = ndf.npv(usd_curve, brl_curve, fxr)
        val = float(npv) if not isinstance(npv, float) else npv
        assert isinstance(val, float)


# ---------------------------------------------------------------------------
# NDF-04: Cashflows
# ---------------------------------------------------------------------------


class TestNDFCashflows:
    def test_cashflows_returns_dataframe(self, usd_curve, brl_curve, fxr):
        import polars as pl
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        df = ndf.cashflows(usd_curve, brl_curve, fxr)
        assert isinstance(df, pl.DataFrame)

    def test_cashflows_has_2_rows(self, usd_curve, brl_curve, fxr):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        df = ndf.cashflows(usd_curve, brl_curve, fxr)
        assert len(df) == 2, f"Expected 2 cashflow rows, got {len(df)}"

    def test_cashflows_period_types(self, usd_curve, brl_curve, fxr):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        df = ndf.cashflows(usd_curve, brl_curve, fxr)
        types = df["Type"].to_list()
        assert "NDF_Domestic" in types, f"Missing NDF_Domestic in {types}"
        assert "NDF_Foreign" in types, f"Missing NDF_Foreign in {types}"

    def test_cashflows_currencies(self, usd_curve, brl_curve, fxr):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        df = ndf.cashflows(usd_curve, brl_curve, fxr)
        currencies = df["Ccy"].to_list()
        # For USDBRL: domestic=USD, foreign=BRL
        assert "usd" in [c.lower() for c in currencies] or "USD" in currencies
        assert "brl" in [c.lower() for c in currencies] or "BRL" in currencies


# ---------------------------------------------------------------------------
# NDF-05: 3-currency NDF
# ---------------------------------------------------------------------------


class TestNDF3Currency:
    def test_3ccy_construction(self):
        """3-currency NDF where settlement differs from both pair currencies."""
        ndf = NDF(
            pair="eurbrl",
            notional=1e6,
            delivery=_d(2025, 7, 1),
            settlement_currency="usd",
            contracted_rate=5.5,
        )
        assert ndf is not None

    def test_3ccy_needs_fx_rates_with_paths(self):
        """Rate/NPV work when FXRates has triangulation paths."""
        usd_curve = _make_disc_curve(
            {_d(2024, 1, 1): 1.0, _d(2025, 7, 1): 0.94},
            id="usd",
        )
        brl_curve = _make_disc_curve(
            {_d(2024, 1, 1): 1.0, _d(2025, 7, 1): 0.80},
            id="brl",
        )
        # FXRates needs paths EUR->USD and BRL->USD
        fxr = FXRates({"eurusd": 1.1, "usdbrl": 5.0}, _d(2024, 1, 15))

        ndf = NDF(
            pair="eurbrl",
            notional=1e6,
            delivery=_d(2025, 7, 1),
            settlement_currency="usd",
            contracted_rate=5.5,
        )
        # Just verify it doesn't crash
        rate = ndf.rate(usd_curve, brl_curve, fxr)
        val = float(rate) if not isinstance(rate, float) else rate
        assert isinstance(val, float), f"3-currency NDF rate should return float, got {type(rate)}"


# ---------------------------------------------------------------------------
# NDF-06: Specs
# ---------------------------------------------------------------------------


class TestNDFSpecs:
    def test_usdbrl_ndf_spec(self):
        ndf = NDF(spec="usdbrl_ndf", delivery=_d(2025, 7, 1), contracted_rate=5.5)
        assert ndf is not None

    def test_usdcny_ndf_spec(self):
        ndf = NDF(spec="usdcny_ndf", delivery=_d(2025, 7, 1), contracted_rate=7.2)
        assert ndf is not None

    def test_usdinr_ndf_spec(self):
        ndf = NDF(spec="usdinr_ndf", delivery=_d(2025, 7, 1), contracted_rate=83.0)
        assert ndf is not None

    def test_usdkrw_ndf_spec(self):
        ndf = NDF(spec="usdkrw_ndf", delivery=_d(2025, 7, 1), contracted_rate=1300.0)
        assert ndf is not None

    def test_usdtwd_ndf_spec(self):
        ndf = NDF(spec="usdtwd_ndf", delivery=_d(2025, 7, 1), contracted_rate=31.0)
        assert ndf is not None

    def test_all_5_specs_in_registry(self):
        expected = ["usdbrl_ndf", "usdcny_ndf", "usdinr_ndf", "usdkrw_ndf", "usdtwd_ndf"]
        for name in expected:
            assert name in INSTRUMENT_SPECS, f"Missing NDF spec: {name}"


# ---------------------------------------------------------------------------
# NDF-07: Solver integration
# ---------------------------------------------------------------------------


class TestNDFSolver:
    def test_pillar_date_returns_delivery(self):
        delivery = _d(2025, 7, 1)
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=delivery,
            settlement_currency="usd", contracted_rate=5.5,
        )
        assert ndf.pillar_date() == delivery

    def test_ndf_in_solver(self):
        """NDF instruments can be used in solver for curve calibration."""
        usd_curve = _make_disc_curve(
            {_d(2024, 1, 1): 1.0, _d(2025, 1, 1): 0.97},
            id="usd",
        )
        brl_curve = _make_disc_curve(
            {_d(2024, 1, 1): 1.0, _d(2025, 1, 1): 0.89},
            id="brl",
        )
        fxr = FXRates({"usdbrl": 5.0}, _d(2024, 1, 15))

        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        # Get the implied rate to use as target
        target_rate = float(ndf.rate(usd_curve, brl_curve, fxr))

        solver = Solver(
            curves=[usd_curve, brl_curve],
            instruments=[(ndf, target_rate, 0, "ndf", "usd")],
            func_tol=1e-10, max_iter=50,
            fx_rates=fxr,
        )
        result = solver.iterate()
        assert result.jacobian is not None


# ---------------------------------------------------------------------------
# Spread
# ---------------------------------------------------------------------------


class TestNDFSpread:
    def test_spread_forward_points(self, usd_curve, brl_curve, fxr):
        """spread = contracted_rate - implied_forward."""
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        spread = float(ndf.spread(usd_curve, brl_curve, fxr))
        implied_fwd = float(ndf.rate(usd_curve, brl_curve, fxr))
        expected = 5.5 - implied_fwd
        assert abs(spread - expected) < 0.01, \
            f"Spread {spread} != contracted_rate - implied_fwd ({expected})"

    def test_spread_at_market_near_zero(self, usd_curve, brl_curve, fxr):
        """When contracted_rate == implied_forward, spread ~= 0."""
        ndf_probe = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=5.0,
        )
        implied_fwd = float(ndf_probe.rate(usd_curve, brl_curve, fxr))

        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 1, 1),
            settlement_currency="usd", contracted_rate=implied_fwd,
        )
        spread = float(ndf.spread(usd_curve, brl_curve, fxr))
        assert abs(spread) < 0.001, f"Spread at market should be ~0, got {spread}"


# ---------------------------------------------------------------------------
# JSON Serialization
# ---------------------------------------------------------------------------


class TestNDFSerialization:
    def test_to_json_without_fixing(self):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 7, 1),
            settlement_currency="usd", contracted_rate=5.5,
        )
        j = json.loads(ndf.to_json())
        assert j["fx_fixing"] is None
        assert j["contracted_rate"] == 5.5
        assert j["settlement_currency"] == "usd"

    def test_to_json_with_fixing(self):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 7, 1),
            settlement_currency="usd", contracted_rate=5.5, fx_fixing=5.42,
        )
        j = json.loads(ndf.to_json())
        assert isinstance(j["fx_fixing"], dict)
        assert "2025-07-01" in j["fx_fixing"]
        assert j["fx_fixing"]["2025-07-01"] == 5.42

    def test_roundtrip_json(self):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 7, 1),
            settlement_currency="usd", contracted_rate=5.5, fx_fixing=5.42,
        )
        json_str = ndf.to_json()
        ndf2 = NDF.from_json(json_str)
        assert ndf2._contracted_rate == 5.5
        assert ndf2._fx_fixing == 5.42
        assert ndf2._delivery == _d(2025, 7, 1)
        assert ndf2._settlement_currency == "usd"

    def test_json_date_keyed_format(self):
        ndf = NDF(
            pair="usdbrl", notional=1e6, delivery=_d(2025, 7, 1),
            settlement_currency="usd", contracted_rate=5.5, fx_fixing=5.42,
        )
        raw = ndf.to_json()
        data = json.loads(raw)
        fixing = data["fx_fixing"]
        assert isinstance(fixing, dict)
        keys = list(fixing.keys())
        assert len(keys) == 1
        # Key should be a date string
        assert keys[0] == "2025-07-01"
        # Value should be a float
        assert isinstance(fixing[keys[0]], float)
