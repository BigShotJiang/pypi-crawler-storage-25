"""Integration tests for FX framework: FXPair, FXRates, FXForwards, FXForward instrument."""

import datetime
import pytest

from vade import (
    FXPair,
    FXRates,
    FXForwards,
    FXForward,
    DiscountCurve,
    Solver,
)


def _d(y, m, d):
    return datetime.date(y, m, d)


def _make_disc_curve(dates_dfs, id="curve"):
    """Build a simple discount curve from (date, df) pairs."""
    nodes = {d: v for d, v in dates_dfs}
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f", id=id)


class TestFXPair:
    def test_fxpair_creation(self):
        pair = FXPair("eurusd")
        assert pair.lhs == "eur"
        assert pair.rhs == "usd"

    def test_fxpair_invert(self):
        pair = FXPair("eurusd")
        inv = pair.invert()
        assert inv.lhs == "usd"
        assert inv.rhs == "eur"

    def test_fxpair_str(self):
        pair = FXPair("eurusd")
        assert str(pair) == "eurusd"

    def test_fxpair_repr(self):
        pair = FXPair("gbpusd")
        assert "gbpusd" in repr(pair)

    def test_fxpair_invalid(self):
        with pytest.raises(ValueError):
            FXPair("eu")
        with pytest.raises(ValueError):
            FXPair("usdusd")


class TestFXRates:
    def _sample_rates(self):
        return FXRates(
            {"eurusd": 1.1, "usdjpy": 110.0},
            _d(2024, 1, 15),
        )

    def test_fxrates_direct_rate(self):
        fxr = self._sample_rates()
        rate = fxr.rate("eurusd")
        val = rate if isinstance(rate, float) else rate.real
        assert abs(val - 1.1) < 1e-10

    def test_fxrates_cross_rate(self):
        fxr = self._sample_rates()
        rate = fxr.rate("eurjpy")
        # EURJPY = EURUSD * USDJPY = 1.1 * 110 = 121.0
        val = rate if isinstance(rate, float) else rate.real
        assert abs(val - 121.0) < 1e-8, f"Cross rate should be ~121.0, got {val}"

    def test_fxrates_inverse_rate(self):
        fxr = self._sample_rates()
        rate = fxr.rate("usdeur")
        val = rate if isinstance(rate, float) else rate.real
        assert abs(val - 1.0 / 1.1) < 1e-8, f"Inverse rate should be ~0.909, got {val}"

    def test_fxrates_convert(self):
        fxr = self._sample_rates()
        result = fxr.convert(100.0, "eur", "usd")
        val = result if isinstance(result, float) else result.real
        assert abs(val - 110.0) < 1e-6, f"Convert 100 EUR to USD should be ~110, got {val}"

    def test_fxrates_restate(self):
        fxr = self._sample_rates()
        restated = fxr.restate(["eurjpy", "usdjpy"])
        # Should produce consistent rates
        rate_eurjpy = restated.rate("eurjpy")
        val = rate_eurjpy if isinstance(rate_eurjpy, float) else rate_eurjpy.real
        assert abs(val - 121.0) < 1e-6

    def test_fxrates_currencies(self):
        fxr = self._sample_rates()
        ccys = sorted(fxr.currencies)
        assert ccys == ["eur", "jpy", "usd"]

    def test_fxrates_settlement(self):
        fxr = self._sample_rates()
        assert fxr.settlement == _d(2024, 1, 15)


class TestFXForwards:
    def _setup(self):
        fxr = FXRates({"eurusd": 1.1}, _d(2024, 1, 15))
        settlements = {"eurusd": _d(2024, 1, 17)}
        fxf = FXForwards(fxr, settlements)

        eur_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0),
            (_d(2025, 1, 15), 0.97),
        ], id="eur_disc")
        usd_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0),
            (_d(2025, 1, 15), 0.95),
        ], id="usd_disc")

        curves = {"eur": eur_curve, "usd": usd_curve}
        return fxf, curves

    def test_fxforwards_rate(self):
        fxf, curves = self._setup()
        rate = fxf.rate("eurusd", _d(2025, 1, 15), curves)
        val = rate if isinstance(rate, float) else rate.real
        # Forward = spot * DF_eur / DF_usd = 1.1 * 0.97 / 0.95
        expected = 1.1 * 0.97 / 0.95
        assert abs(val - expected) < 1e-8, f"Forward should be ~{expected}, got {val}"

    def test_fxforwards_points(self):
        fxf, curves = self._setup()
        pts = fxf.points("eurusd", _d(2025, 1, 15), curves)
        val = pts if isinstance(pts, float) else pts.real
        expected = 1.1 * 0.97 / 0.95 - 1.1
        assert abs(val - expected) < 1e-8


class TestFXForwardInstrument:
    def test_fxforward_instrument(self):
        fxr = FXRates({"eurusd": 1.1}, _d(2024, 1, 15))
        eur_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0),
            (_d(2025, 1, 15), 0.97),
        ], id="eur_disc")
        usd_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0),
            (_d(2025, 1, 15), 0.95),
        ], id="usd_disc")

        fxf = FXForward(pair="eurusd", notional=1_000_000.0, delivery=_d(2025, 1, 15))
        rate = fxf.rate(eur_curve, usd_curve, fxr)
        val = rate if isinstance(rate, float) else rate.real
        expected = 1.1 * 0.97 / 0.95
        assert abs(val - expected) < 1e-6


class TestFXForwardSolverIntegration:
    """FXForward instrument works with solver (D-21)."""

    def test_fxforward_in_solver(self):
        """FXForward instrument calibrates in solver context."""
        usd_nodes = {_d(2024, 1, 15): 1.0, _d(2025, 1, 15): 0.97}
        eur_nodes = {_d(2024, 1, 15): 1.0, _d(2025, 1, 15): 0.975}
        usd_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0), (_d(2025, 1, 15), 0.97),
        ], id="usd")
        eur_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0), (_d(2025, 1, 15), 0.975),
        ], id="eur")
        fx_rates = FXRates({"eurusd": 1.1}, _d(2024, 1, 15))

        fxf = FXForward(pair="eurusd", notional=1_000_000,
                        delivery=_d(2025, 1, 15), currency="usd")

        # FXForward.rate() should return the implied forward FX rate
        rate = fxf.rate(eur_curve, usd_curve, fx_rates)
        rate_val = float(rate) if not isinstance(rate, float) else rate
        # Forward = spot * DF_eur / DF_usd = 1.1 * 0.975 / 0.97 ~ 1.1057
        expected = 1.1 * 0.975 / 0.97
        assert abs(rate_val - expected) < 0.01, \
            f"FXForward rate {rate_val} != expected {expected}"

        # FXForward works in solver with fx_rates
        solver = Solver(
            curves=[eur_curve, usd_curve],
            instruments=[(fxf, rate_val, 0, "fxf", "usd")],
            func_tol=1e-10, max_iter=50,
            fx_rates=fx_rates,
        )
        result = solver.iterate()
        assert result.jacobian is not None

    def test_fxforward_npv(self):
        """FXForward NPV is reasonable."""
        eur_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0), (_d(2025, 1, 15), 0.975),
        ], id="eur")
        usd_curve = _make_disc_curve([
            (_d(2024, 1, 15), 1.0), (_d(2025, 1, 15), 0.97),
        ], id="usd")
        fx_rates = FXRates({"eurusd": 1.1}, _d(2024, 1, 15))

        fxf = FXForward(pair="eurusd", notional=1_000_000,
                        delivery=_d(2025, 1, 15), currency="usd")
        npv = fxf.npv(eur_curve, usd_curve, fx_rates)
        npv_val = float(npv) if not isinstance(npv, float) else npv
        assert abs(npv_val) < 1_000_000, f"FXForward NPV should be reasonable: {npv_val}"


class TestFXImport:
    def test_fx_import(self):
        from vade import FXRates, FXForwards, FXPair
        assert FXRates is not None
        assert FXForwards is not None
        assert FXPair is not None
