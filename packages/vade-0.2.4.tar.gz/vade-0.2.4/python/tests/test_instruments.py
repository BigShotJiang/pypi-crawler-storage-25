"""Integration tests for Python instrument API."""

import datetime
import pytest
import polars as pl

from vade import (
    DiscountCurve,
    LineCurve,
    IRS,
    InterestRateSwap,
    FRA,
    ForwardRateAgreement,
    ZCS,
    ZeroCouponSwap,
    SBS,
    SingleBasisSwap,
    OIS,
    OvernightIndexedSwap,
    Deposit,
    IRFuture,
    CapFloor,
    Solver,
)


def _make_curve():
    """Build a test discount curve."""
    d = datetime.date
    nodes = {
        d(2024, 1, 1): 1.0,
        d(2025, 1, 1): 0.97,
        d(2026, 1, 1): 0.94,
        d(2027, 1, 1): 0.91,
        d(2028, 1, 1): 0.88,
        d(2029, 1, 1): 0.85,
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f", id="disc")


class TestIRSConstruction:
    """IRS construction and pricing tests."""

    def test_irs_construction(self):
        """Create IRS with explicit params, verify rate() returns float."""
        d = datetime.date
        curve = _make_curve()
        irs = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="s",
            fixed_rate=3.0,
            notional=1_000_000.0,
            convention="act365f",
            float_convention="act365f",
            modifier="mf",
        )
        rate = irs.rate(curve)
        assert isinstance(rate, float)
        assert 0 < rate < 20, f"Rate should be reasonable: {rate}"

    def test_irs_from_spec(self):
        """Create IRS with spec='usd_irs'."""
        d = datetime.date
        curve = _make_curve()
        irs = IRS(
            spec="usd_irs",
            effective=d(2024, 1, 1),
            termination="5Y",
            fixed_rate=3.0,
        )
        rate = irs.rate(curve)
        assert isinstance(rate, float)
        assert rate > 0

    def test_irs_npv(self):
        """Verify NPV close to 0 when fixed_rate = par rate."""
        d = datetime.date
        curve = _make_curve()
        irs_for_rate = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="s",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
        )
        par_rate = irs_for_rate.rate(curve)

        irs_at_par = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="s",
            fixed_rate=par_rate,
            convention="act365f",
            float_convention="act365f",
        )
        npv = irs_at_par.npv(curve)
        assert abs(npv) < 1e-4, f"NPV at par rate should be ~0, got {npv}"

    def test_irs_cashflows(self):
        """Verify returns Polars DataFrame with expected columns."""
        d = datetime.date
        curve = _make_curve()
        irs = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="s",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
        )
        df = irs.cashflows(curve)
        assert isinstance(df, pl.DataFrame)
        assert len(df) > 0
        assert "Type" in df.columns
        assert "Cashflow" in df.columns

    def test_spec_override(self):
        """Spec + user kwargs override specific fields."""
        d = datetime.date
        curve = _make_curve()
        # usd_irs uses act360; we override convention to act365f
        irs = IRS(
            spec="usd_irs",
            effective=d(2024, 1, 1),
            termination="2Y",
            fixed_rate=3.0,
            convention="act365f",
        )
        rate = irs.rate(curve)
        assert isinstance(rate, float)


class TestFRA:
    """FRA tests."""

    def test_fra_rate(self):
        """FRA rate matches forward rate from curve."""
        d = datetime.date
        curve = _make_curve()
        fra = FRA(
            effective=d(2025, 1, 1),
            termination=d(2025, 7, 1),
            notional=1_000_000.0,
            fixed_rate=3.0,
            convention="act365f",
        )
        rate = fra.rate(curve)
        assert isinstance(rate, float)
        assert rate > 0, f"FRA rate should be positive: {rate}"


class TestZCS:
    """ZCS tests."""

    def test_zcs_npv(self):
        """ZCS NPV computation."""
        d = datetime.date
        curve = _make_curve()
        zcs = ZCS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
        )
        npv = zcs.npv(curve)
        assert isinstance(npv, float)
        assert abs(npv) < 1e8


class TestSBS:
    """SBS tests."""

    def test_sbs_npv(self):
        """SBS NPV with two float legs."""
        d = datetime.date
        curve = _make_curve()
        sbs = SBS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="q",
            leg2_frequency="s",
            convention="act365f",
        )
        npv = sbs.npv(curve)
        assert isinstance(npv, float)


class TestOIS:
    """OIS tests."""

    def test_ois_construction(self):
        """OIS with RFR fixing constructs and prices."""
        d = datetime.date
        curve = _make_curve()
        ois = OIS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="a",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
        )
        rate = ois.rate(curve)
        assert isinstance(rate, float)
        assert rate > 0


class TestDeposit:
    """Deposit tests."""

    def test_deposit_rate(self):
        """Deposit rate matches expected from DF."""
        d = datetime.date
        curve = _make_curve()
        dep = Deposit(
            effective=d(2024, 1, 1),
            termination=d(2024, 7, 1),
            rate=3.0,
            convention="act365f",
        )
        rate = dep.rate(curve)
        assert isinstance(rate, float)
        assert rate > 0


class TestIRFuture:
    """IR future tests."""

    def test_irfuture_rate(self):
        """IR future rate with convexity adjustment."""
        d = datetime.date
        curve = _make_curve()
        fut = IRFuture(
            effective=d(2024, 4, 1),
            termination=d(2024, 7, 1),
            price=97.0,
            convexity_adjustment=0.001,
            convention="act365f",
        )
        rate = fut.rate(curve)
        assert isinstance(rate, float)
        assert rate > 0


class TestDualCurveInput:
    """Tests for different curve input formats."""

    def test_dual_curve_list(self):
        """List [forecast, disc] curve input."""
        d = datetime.date
        curve = _make_curve()
        irs = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="s",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
        )
        # Same curve for both: rate should match single-curve
        rate_single = irs.rate(curve)
        rate_list = irs.rate([curve, curve])
        assert abs(rate_single - rate_list) < 1e-10

    def test_dual_curve_dict(self):
        """Dict {"disc": ..., "forecast": ...} curve input."""
        d = datetime.date
        curve = _make_curve()
        irs = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="s",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
        )
        rate_single = irs.rate(curve)
        rate_dict = irs.rate({"disc": curve, "forecast": curve})
        assert abs(rate_single - rate_dict) < 1e-10


class TestCapFloor:
    """Cap/Floor instrument tests (INST-01)."""

    def test_cap_floor_black76_cap_positive_npv(self):
        """Cap with ATM strike should have positive NPV."""
        d = datetime.date
        curve = _make_curve()
        cap = CapFloor(
            effective=d(2024, 1, 1),
            termination=d(2025, 1, 1),
            strike=3.0,
            vol=0.20,
            model="black76",
            frequency="q",
            convention="act365f",
        )
        npv = cap.npv(curve, curve)
        assert isinstance(npv, float)
        assert npv > 0, f"Cap NPV should be positive, got {npv}"
        assert npv < 1e8, f"Cap NPV should be reasonable, got {npv}"

    def test_cap_floor_bachelier_floor_positive_npv(self):
        """Floor with ITM strike should have positive NPV."""
        d = datetime.date
        curve = _make_curve()
        floor = CapFloor(
            effective=d(2024, 1, 1),
            termination=d(2025, 1, 1),
            strike=5.0,
            vol=0.005,
            model="bachelier",
            cap_floor_type="floor",
            frequency="q",
            convention="act365f",
        )
        npv = floor.npv(curve, curve)
        assert isinstance(npv, float)
        assert npv > 0, f"ITM floor NPV should be positive, got {npv}"

    def test_cap_floor_cashflows_per_period(self):
        """CapFloor.cashflows() returns per-caplet rows."""
        d = datetime.date
        curve = _make_curve()
        cap = CapFloor(
            effective=d(2024, 1, 1),
            termination=d(2025, 1, 1),
            strike=3.0,
            vol=0.20,
            model="black76",
            frequency="q",
            convention="act365f",
        )
        df = cap.cashflows(curve, curve)
        assert isinstance(df, pl.DataFrame)
        # 1Y quarterly = 4 periods
        assert len(df) == 4, f"Expected 4 caplet rows, got {len(df)}"

    def test_cap_floor_type_parameter(self):
        """cap_floor_type='cap' and 'floor' produce different NPVs."""
        d = datetime.date
        curve = _make_curve()
        cap = CapFloor(
            effective=d(2024, 1, 1),
            termination=d(2025, 1, 1),
            strike=3.0,
            vol=0.20,
            model="black76",
            frequency="q",
            convention="act365f",
            cap_floor_type="cap",
        )
        floor = CapFloor(
            effective=d(2024, 1, 1),
            termination=d(2025, 1, 1),
            strike=3.0,
            vol=0.20,
            model="black76",
            frequency="q",
            convention="act365f",
            cap_floor_type="floor",
        )
        cap_npv = cap.npv(curve, curve)
        floor_npv = floor.npv(curve, curve)
        assert cap_npv != floor_npv, f"Cap and floor NPVs should differ: {cap_npv} vs {floor_npv}"


class TestAmortizingIRS:
    """Per-leg amortization tests (INST-02)."""

    def test_amortizing_irs_per_leg(self):
        """Per-leg amortization produces different result than mirrored."""
        d = datetime.date
        curve = _make_curve()
        # IRS with per-leg amortization: only fixed leg amortizes
        irs_per_leg = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="a",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
            fixed_amortization="constant_100000",
        )
        # IRS with shared amortization: both legs amortize
        irs_shared = IRS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="a",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
            amortization="constant_100000",
        )
        npv_per_leg = irs_per_leg.npv(curve)
        npv_shared = irs_shared.npv(curve)
        assert isinstance(npv_per_leg, float)
        assert isinstance(npv_shared, float)
        # Per-leg (only fixed amortizes) should differ from shared (both amortize)
        assert abs(npv_per_leg - npv_shared) > 1e-4, (
            f"Per-leg and shared amortization should produce different NPVs: {npv_per_leg} vs {npv_shared}"
        )

    def test_amortizing_irs_mutual_exclusion(self):
        """Cannot specify both amortization and per-leg amortization."""
        d = datetime.date
        with pytest.raises(Exception):
            IRS(
                effective=d(2024, 1, 1),
                termination=d(2026, 1, 1),
                frequency="a",
                fixed_rate=3.0,
                convention="act365f",
                float_convention="act365f",
                amortization="constant_100000",
                fixed_amortization="constant_50000",
            )


class TestOISCompounding:
    """OIS compounding method tests (INST-03)."""

    def test_ois_compounding_method_spread_exclusive(self):
        """spread_exclusive vs standard differ when spread != 0."""
        d = datetime.date
        curve = _make_curve()
        ois_standard = OIS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="a",
            fixed_rate=3.0,
            spread=0.5,
            convention="act365f",
            float_convention="act365f",
            compounding_method="standard",
        )
        ois_spread_exclusive = OIS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="a",
            fixed_rate=3.0,
            spread=0.5,
            convention="act365f",
            float_convention="act365f",
            compounding_method="spread_exclusive",
        )
        npv_standard = ois_standard.npv(curve)
        npv_spread_exclusive = ois_spread_exclusive.npv(curve)
        assert isinstance(npv_standard, float)
        assert isinstance(npv_spread_exclusive, float)
        assert abs(npv_standard - npv_spread_exclusive) > 1e-6, (
            f"Standard and spread_exclusive should produce different NPVs: {npv_standard} vs {npv_spread_exclusive}"
        )

    def test_ois_compounding_method_simple_average(self):
        """simple_average uses arithmetic averaging."""
        d = datetime.date
        curve = _make_curve()
        ois = OIS(
            effective=d(2024, 1, 1),
            termination=d(2026, 1, 1),
            frequency="a",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
            compounding_method="simple_average",
        )
        npv = ois.npv(curve)
        assert isinstance(npv, float)
        assert abs(npv) < 1e8, f"NPV should be finite, got {npv}"


class TestIRFutureRefinements:
    """IR future refinements tests (INST-04)."""

    def test_ir_future_rate_quoting(self):
        """quote_convention='rate' passes rate directly."""
        d = datetime.date
        curve = _make_curve()
        fut_price = IRFuture(
            effective=d(2024, 4, 1),
            termination=d(2024, 7, 1),
            price=97.0,
            convention="act365f",
            quote_convention="price",
        )
        fut_rate = IRFuture(
            effective=d(2024, 4, 1),
            termination=d(2024, 7, 1),
            price=0.03,
            convention="act365f",
            quote_convention="rate",
        )
        rate_price = fut_price.rate(curve)
        rate_rate = fut_rate.rate(curve)
        assert isinstance(rate_price, float)
        assert isinstance(rate_rate, float)
        assert rate_price > 0
        assert rate_rate > 0

    def test_ir_future_sigma_hull_white(self):
        """sigma parameter enables Hull-White CA."""
        d = datetime.date
        curve = _make_curve()
        fut = IRFuture(
            effective=d(2024, 4, 1),
            termination=d(2024, 7, 1),
            price=97.0,
            convention="act365f",
            sigma=0.01,
        )
        rate = fut.rate(curve)
        assert isinstance(rate, float)
        assert rate > 0

    def test_ir_future_contract_specs(self):
        """Contract specs are accepted and stored."""
        d = datetime.date
        curve = _make_curve()
        fut = IRFuture(
            effective=d(2024, 4, 1),
            termination=d(2024, 7, 1),
            price=97.0,
            convention="act365f",
            tick_size=0.005,
            notional_multiplier=2500.0,
            contract_size=1000000.0,
        )
        npv = fut.npv(curve)
        assert isinstance(npv, float)
        assert abs(npv) < 1e12  # finite


class TestSolverCurveResolution:
    """Test solver= kwarg for curve resolution."""

    def test_solver_curve_resolution(self):
        """Construct Solver, calibrate, then call instrument.npv(solver=solver)."""
        d = datetime.date
        from vade._vade_rs.instruments import PyInterestRateSwap

        # Build curve with default (uninitialized) DFs for solver to calibrate
        tenors = [d(2025, 1, 1), d(2026, 1, 1), d(2027, 1, 1)]
        nodes = {d(2024, 1, 1): 1.0}
        for t in tenors:
            nodes[t] = 1.0

        curve = DiscountCurve(
            nodes, interpolation="log_linear", convention="act365f", id="disc"
        )

        # Build IRS instruments with target rates
        targets = [3.0, 3.2, 3.4]
        instruments_for_solver = []
        irs_instruments = []
        for i, (target, tenor) in enumerate(zip(targets, tenors)):
            irs = IRS(
                effective=d(2024, 1, 1),
                termination=tenor,
                frequency="a",
                fixed_rate=target,
                convention="act365f",
                float_convention="act365f",
                disc_curve_id="disc",
            )
            instruments_for_solver.append((irs, target))
            irs_instruments.append(irs)

        solver = Solver(curves=[curve], instruments=instruments_for_solver)
        result = solver.iterate()
        assert result.converged

        # Use solver= kwarg to auto-resolve curves
        npv_via_solver = irs_instruments[0].npv(solver=solver)
        assert isinstance(npv_via_solver, float)
        assert abs(npv_via_solver) < 1e8  # should be finite

        # Compare with explicit curve from solver
        calibrated_curve = solver.get_curve(0)
        npv_explicit = irs_instruments[0].npv(calibrated_curve)
        assert abs(npv_via_solver - npv_explicit) < 1e-8
