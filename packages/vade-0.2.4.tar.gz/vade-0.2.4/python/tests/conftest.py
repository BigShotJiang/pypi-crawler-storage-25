"""Shared test fixtures for vade Python tests."""

import pytest
from vade.autodiff import Dual, Dual2


@pytest.fixture
def dual_x():
    """A simple Dual('x', 2.0)."""
    return Dual("x", 2.0)


@pytest.fixture
def dual_y():
    """A simple Dual('y', 3.0)."""
    return Dual("y", 3.0)


@pytest.fixture
def dual2_x():
    """A simple Dual2('x', 2.0)."""
    return Dual2("x", 2.0)


def pytest_markdown_docs_globals():
    """Inject common imports for markdown doc code blocks."""
    import datetime
    import vade
    return {
        "vade": vade,
        "datetime": datetime,
        "date": datetime.date,
    }
