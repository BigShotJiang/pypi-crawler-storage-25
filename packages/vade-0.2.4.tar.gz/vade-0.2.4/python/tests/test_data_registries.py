"""Tests for Python-side data registries: specs, fixings, indices."""

from __future__ import annotations

from datetime import date

import pytest

from vade.fixings import clear as fixings_clear
from vade.fixings import get as fixings_get
from vade.fixings import get_rate, list_indices as fixings_list_indices
from vade.fixings import set as fixings_set
from vade.indices import get_index, list_indices
from vade.instruments.specs import get_spec, list_specs, register_spec


# ---------------------------------------------------------------------------
# Instrument specs
# ---------------------------------------------------------------------------

class TestSpecsRegistry:
    def test_get_spec_usd_irs(self):
        s = get_spec("usd_irs")
        assert s["frequency"] == "a"
        assert s["currency"] == "usd"
        assert s["convention"] == "act360"
        assert s["calendar"] == "nyc"
        assert s["payment_lag"] == 2

    def test_get_spec_eur_irs(self):
        s = get_spec("eur_irs")
        assert s["frequency"] == "a"
        assert s["currency"] == "eur"
        assert s["convention"] == "act360"
        assert s["calendar"] == "tgt"

    def test_get_spec_gbp_irs(self):
        s = get_spec("gbp_irs")
        assert s["frequency"] == "a"
        assert s["currency"] == "gbp"
        assert s["convention"] == "act365f"
        assert s["calendar"] == "ldn"
        assert s["payment_lag"] == 0

    def test_get_spec_returns_copy(self):
        """Modifying returned spec should not affect registry."""
        s = get_spec("usd_irs")
        s["frequency"] = "MODIFIED"
        s2 = get_spec("usd_irs")
        assert s2["frequency"] == "a"

    def test_specs_unknown_raises(self):
        with pytest.raises(KeyError, match="Unknown instrument spec"):
            get_spec("nonexistent")

    def test_specs_register_custom(self):
        register_spec("test_custom_swap", {
            "frequency": "q",
            "currency": "usd",
            "convention": "act360",
        })
        s = get_spec("test_custom_swap")
        assert s["frequency"] == "q"
        assert s["currency"] == "usd"

    def test_list_specs_count(self):
        specs = list_specs()
        assert len(specs) >= 20
        assert specs == sorted(specs)
        assert "usd_irs" in specs
        assert "eur_irs" in specs
        assert "gbp_irs" in specs


# ---------------------------------------------------------------------------
# Historical fixings
# ---------------------------------------------------------------------------

class TestFixingsRegistry:
    def setup_method(self):
        fixings_clear()

    def test_fixings_set_get(self):
        fixings_set("SOFR", {
            date(2024, 1, 2): 0.053,
            date(2024, 1, 3): 0.0531,
        })
        data = fixings_get("SOFR")
        assert data is not None
        assert len(data) == 2
        assert data[date(2024, 1, 2)] == 0.053
        assert data[date(2024, 1, 3)] == 0.0531

    def test_fixings_set_string_dates(self):
        fixings_set("SONIA", {"2024-03-01": 0.05, "2024-03-04": 0.051})
        data = fixings_get("SONIA")
        assert data is not None
        assert data[date(2024, 3, 1)] == 0.05

    def test_fixings_get_none_for_unknown(self):
        assert fixings_get("UNKNOWN") is None

    def test_fixings_clear_individual(self):
        fixings_set("SOFR", {date(2024, 1, 2): 0.053})
        fixings_set("SONIA", {date(2024, 1, 2): 0.05})
        fixings_clear("SOFR")
        assert fixings_get("SOFR") is None
        assert fixings_get("SONIA") is not None

    def test_fixings_clear_all(self):
        fixings_set("SOFR", {date(2024, 1, 2): 0.053})
        fixings_set("SONIA", {date(2024, 1, 2): 0.05})
        fixings_clear()
        assert fixings_get("SOFR") is None
        assert fixings_get("SONIA") is None

    def test_fixings_get_rate(self):
        fixings_set("SOFR", {
            date(2024, 1, 2): 0.053,
            date(2024, 1, 3): 0.0531,
        })
        assert get_rate("SOFR", date(2024, 1, 2)) == 0.053
        assert get_rate("SOFR", date(2024, 1, 3)) == 0.0531
        assert get_rate("SOFR", date(2024, 1, 4)) is None
        assert get_rate("UNKNOWN", date(2024, 1, 2)) is None

    def test_fixings_get_rate_string_date(self):
        fixings_set("SOFR", {date(2024, 1, 2): 0.053})
        assert get_rate("SOFR", "2024-01-02") == 0.053

    def test_fixings_merge(self):
        """Setting fixings twice should merge, not replace."""
        fixings_set("SOFR", {date(2024, 1, 2): 0.053})
        fixings_set("SOFR", {date(2024, 1, 3): 0.0531})
        data = fixings_get("SOFR")
        assert len(data) == 2

    def test_fixings_list_indices(self):
        fixings_set("SOFR", {date(2024, 1, 2): 0.053})
        fixings_set("SONIA", {date(2024, 1, 2): 0.05})
        indices = fixings_list_indices()
        assert indices == ["SOFR", "SONIA"]


# ---------------------------------------------------------------------------
# Index definitions
# ---------------------------------------------------------------------------

class TestIndicesRegistry:
    def test_sofr(self):
        i = get_index("SOFR")
        assert i["type"] == "rfr"
        assert i["tenor"] == "1d"
        assert i["day_count"] == "act360"
        assert i["currency"] == "usd"

    def test_sonia(self):
        i = get_index("SONIA")
        assert i["type"] == "rfr"
        assert i["day_count"] == "act365f"
        assert i["currency"] == "gbp"

    def test_euribor_3m(self):
        i = get_index("EURIBOR_3M")
        assert i["type"] == "ibor"
        assert i["tenor"] == "3m"
        assert i["day_count"] == "act360"
        assert i["currency"] == "eur"
        assert i["publication_lag"] == 2

    def test_indices_unknown_raises(self):
        with pytest.raises(KeyError, match="Unknown index"):
            get_index("nonexistent")

    def test_list_indices_count(self):
        idx = list_indices()
        assert len(idx) >= 21  # 11 RFR + 8 FX + 15 IBOR + 5 NDF FX + 4 EM rate
        assert idx == sorted(idx)
        assert "SOFR" in idx
        assert "EURIBOR_3M" in idx
        assert "USDBRL" in idx
        assert "CDI" in idx

    def test_index_returns_copy(self):
        i = get_index("SOFR")
        i["type"] = "MODIFIED"
        i2 = get_index("SOFR")
        assert i2["type"] == "rfr"


class TestNdfFxIndices:
    """Tests for NDF FX index definitions (FNDX-02)."""

    def test_usdbrl(self):
        i = get_index("USDBRL")
        assert i["type"] == "ndf_fx"
        assert i["base"] == "usd"
        assert i["quote"] == "brl"
        assert i["fixing_lag"] == 2
        assert i["settlement_lag"] == 2
        assert i["settlement_currency"] == "usd"
        assert i["calendar"] == "sao,nyc"
        assert i["fixing_source"] == "PTAX"

    def test_usdcny(self):
        i = get_index("USDCNY")
        assert i["type"] == "ndf_fx"
        assert i["base"] == "usd"
        assert i["quote"] == "cny"
        assert i["fixing_lag"] == 2
        assert i["settlement_lag"] == 2
        assert i["settlement_currency"] == "usd"
        assert i["calendar"] == "bjs,nyc"
        assert i["fixing_source"] == "CFETS"

    def test_usdinr(self):
        i = get_index("USDINR")
        assert i["type"] == "ndf_fx"
        assert i["base"] == "usd"
        assert i["quote"] == "inr"
        assert i["fixing_lag"] == 2
        assert i["settlement_lag"] == 2
        assert i["settlement_currency"] == "usd"
        assert i["calendar"] == "mum,nyc"
        assert i["fixing_source"] == "RBI"

    def test_usdkrw(self):
        i = get_index("USDKRW")
        assert i["type"] == "ndf_fx"
        assert i["base"] == "usd"
        assert i["quote"] == "krw"
        assert i["fixing_lag"] == 1  # KRW is T-1, not T-2
        assert i["settlement_lag"] == 2
        assert i["settlement_currency"] == "usd"
        assert i["calendar"] == "sel,nyc"
        assert i["fixing_source"] == "KFTC"

    def test_usdtwd(self):
        i = get_index("USDTWD")
        assert i["type"] == "ndf_fx"
        assert i["base"] == "usd"
        assert i["quote"] == "twd"
        assert i["fixing_lag"] == 2
        assert i["settlement_lag"] == 2
        assert i["settlement_currency"] == "usd"
        assert i["calendar"] == "tai,nyc"
        assert i["fixing_source"] == "CBC"

    def test_all_ndf_fx_have_required_fields(self):
        """Every ndf_fx index must have all required fields per D-06."""
        required = {"type", "base", "quote", "fixing_lag", "settlement_lag",
                    "settlement_currency", "calendar", "fixing_source", "description"}
        for name in ["USDBRL", "USDCNY", "USDINR", "USDKRW", "USDTWD"]:
            i = get_index(name)
            missing = required - set(i.keys())
            assert not missing, f"{name} missing fields: {missing}"


class TestEmRateIndices:
    """Tests for EM rate index definitions (FNDX-03)."""

    def test_cdi(self):
        i = get_index("CDI")
        assert i["type"] == "rfr"
        assert i["tenor"] == "1d"
        assert i["day_count"] == "bus252"
        assert i["calendar"] == "sao"
        assert i["currency"] == "brl"
        assert i["compounding"] == "daily"  # per D-10

    def test_mibor(self):
        i = get_index("MIBOR")
        assert i["type"] == "rfr"
        assert i["tenor"] == "1d"
        assert i["day_count"] == "act365f"
        assert i["calendar"] == "mum"
        assert i["currency"] == "inr"

    def test_cd91(self):
        i = get_index("CD91")
        assert i["type"] == "ibor"
        assert i["tenor"] == "91d"
        assert i["day_count"] == "act365f"
        assert i["calendar"] == "sel"
        assert i["currency"] == "krw"
        assert i["publication_lag"] == 0

    def test_shibor_3m(self):
        i = get_index("SHIBOR_3M")
        assert i["type"] == "ibor"
        assert i["tenor"] == "3m"
        assert i["day_count"] == "act360"
        assert i["calendar"] == "bjs"
        assert i["currency"] == "cny"
        assert i["publication_lag"] == 0
