"""Integration tests for the calendar module from Python."""

import datetime
import pytest

from vade.calendar import (
    BusinessCalendar,
    Schedule,
    dcf,
    add_tenor,
    add_business_days,
)


def d(y, m, day):
    """Shorthand for datetime.date."""
    return datetime.date(y, m, day)


class TestBusinessCalendar:
    """Tests for BusinessCalendar from Python."""

    def test_named_calendar_nyc(self):
        cal = BusinessCalendar("NYC")
        assert cal.is_holiday(d(2024, 12, 25))  # Christmas
        assert not cal.is_holiday(d(2024, 12, 24))  # Christmas Eve
        assert cal.is_business_day(d(2024, 12, 24))
        assert not cal.is_business_day(d(2024, 12, 25))

    def test_named_calendar_ldn(self):
        cal = BusinessCalendar("LDN")
        assert cal.is_holiday(d(2024, 8, 26))  # August Bank Holiday

    def test_custom_calendar(self):
        cal = BusinessCalendar.new_custom(["2024-01-01", "2024-12-25"], [5, 6])
        assert cal.is_holiday(d(2024, 1, 1))
        assert not cal.is_holiday(d(2024, 1, 2))
        assert cal.is_business_day(d(2024, 1, 2))

    def test_calendar_union(self):
        nyc = BusinessCalendar("NYC")
        ldn = BusinessCalendar("LDN")
        combined = nyc.union_cal(ldn)
        # NYC holiday
        assert combined.is_holiday(d(2024, 11, 11))  # Veterans Day
        # LDN holiday
        assert combined.is_holiday(d(2024, 8, 26))  # August Bank Holiday

    def test_bus_day_count(self):
        cal = BusinessCalendar.new_custom([], [5, 6])
        assert cal.bus_day_count(d(2024, 1, 1), d(2024, 1, 8)) == 5

    def test_unknown_calendar_raises(self):
        with pytest.raises(ValueError, match="Unknown calendar"):
            BusinessCalendar("INVALID")


class TestAdjuster:
    """Tests for date adjustment from Python via Schedule."""

    def test_adjuster_following(self):
        """Following rolls forward to next business day."""
        # Create schedule where a date falls on weekend
        s = Schedule(
            effective=d(2024, 1, 15),
            termination=d(2024, 7, 15),
            frequency="S",
            adjuster="following",
        )
        # Both dates are weekdays, so no adjustment
        assert s.adjusted_dates[0] == d(2024, 1, 15)

    def test_adjuster_modified_following(self):
        """ModifiedFollowing stays in month."""
        # 2024-03-31 is Sunday: Following -> April 1, ModFollowing -> March 29
        s = Schedule(
            effective=d(2024, 1, 31),
            termination=d(2024, 3, 31),
            frequency="M",
            adjuster="modified_following",
            roll_day="eom",
        )
        # March 31 (Sun) -> March 29 (Fri)
        assert s.adjusted_dates[-1] == d(2024, 3, 29)


class TestDcf:
    """Tests for day count fraction calculations from Python."""

    def test_act360(self):
        result = dcf("act360", d(2024, 1, 15), d(2024, 7, 15))
        assert abs(result - 182.0 / 360.0) < 1e-10

    def test_act365f(self):
        result = dcf("act365f", d(2024, 1, 15), d(2024, 7, 15))
        assert abs(result - 182.0 / 365.0) < 1e-10

    def test_actactisda(self):
        result = dcf("actactisda", d(2024, 1, 1), d(2024, 7, 1))
        expected = 182.0 / 366.0  # 2024 is leap year
        assert abs(result - expected) < 1e-10

    def test_thirty360(self):
        result = dcf("30/360", d(2024, 1, 15), d(2024, 7, 15))
        expected = 0.5  # 6 months / 12
        assert abs(result - expected) < 1e-10

    def test_bus252(self):
        cal = BusinessCalendar.new_custom([], [5, 6])
        result = dcf("bus252", d(2024, 1, 1), d(2024, 1, 8), calendar=cal)
        expected = 5.0 / 252.0
        assert abs(result - expected) < 1e-10

    def test_bus252_requires_calendar(self):
        with pytest.raises(ValueError):
            dcf("bus252", d(2024, 1, 1), d(2024, 1, 8))

    def test_unknown_convention_raises(self):
        with pytest.raises(ValueError, match="Unknown day count"):
            dcf("invalid", d(2024, 1, 1), d(2024, 7, 1))


class TestSchedule:
    """Tests for schedule generation from Python."""

    def test_regular_schedule(self):
        s = Schedule(
            effective=d(2024, 1, 15),
            termination=d(2025, 1, 15),
            frequency="S",
        )
        assert s.n_periods == 2
        assert len(s) == 2
        assert s.unadjusted_dates == [d(2024, 1, 15), d(2024, 7, 15), d(2025, 1, 15)]
        assert not s.has_front_stub()
        assert not s.has_back_stub()

    def test_front_stub(self):
        s = Schedule(
            effective=d(2024, 3, 1),
            termination=d(2025, 1, 15),
            frequency="S",
            adjuster="actual",
            roll_day="15",
            stub_inference="short_front",
        )
        assert s.has_front_stub()
        assert s.unadjusted_dates[0] == d(2024, 3, 1)
        assert s.unadjusted_dates[-1] == d(2025, 1, 15)

    def test_back_stub(self):
        s = Schedule(
            effective=d(2024, 1, 15),
            termination=d(2025, 3, 1),
            frequency="S",
            adjuster="actual",
            roll_day="15",
            stub_inference="short_back",
        )
        assert s.has_back_stub()
        assert s.unadjusted_dates[-1] == d(2025, 3, 1)

    def test_quarterly(self):
        s = Schedule(
            effective=d(2024, 1, 15),
            termination=d(2025, 1, 15),
            frequency="Q",
        )
        assert s.n_periods == 4

    def test_monthly(self):
        s = Schedule(
            effective=d(2024, 1, 15),
            termination=d(2024, 6, 15),
            frequency="M",
        )
        assert s.n_periods == 5

    def test_zero_coupon(self):
        s = Schedule(
            effective=d(2024, 1, 15),
            termination=d(2029, 1, 15),
            frequency="Z",
        )
        assert s.n_periods == 1

    def test_with_named_calendar(self):
        cal = BusinessCalendar("NYC")
        s = Schedule(
            effective=d(2024, 1, 15),  # MLK day
            termination=d(2024, 7, 15),
            frequency="S",
            calendar=cal,
            adjuster="following",
        )
        # Jan 15 2024 is MLK day -> adjusted to Jan 16
        assert s.adjusted_dates[0] == d(2024, 1, 16)
        assert s.adjusted_dates[1] == d(2024, 7, 15)

    def test_repr(self):
        s = Schedule(
            effective=d(2024, 1, 15),
            termination=d(2025, 1, 15),
            frequency="S",
        )
        r = repr(s)
        assert "Schedule" in r
        assert "periods=2" in r

    def test_invalid_dates_raises(self):
        with pytest.raises(ValueError):
            Schedule(
                effective=d(2025, 1, 15),
                termination=d(2024, 1, 15),
                frequency="S",
            )

    def test_string_to_enum_frequency(self):
        """String-to-enum conversion works for frequency."""
        for freq, expected_periods in [("M", 12), ("Q", 4), ("S", 2), ("A", 1)]:
            s = Schedule(
                effective=d(2024, 1, 15),
                termination=d(2025, 1, 15),
                frequency=freq,
            )
            assert s.n_periods == expected_periods, f"Failed for freq={freq}"

    def test_string_to_enum_adjuster(self):
        """String-to-enum conversion works for adjuster."""
        for adj in ["actual", "following", "modified_following", "preceding", "modified_preceding"]:
            s = Schedule(
                effective=d(2024, 1, 15),
                termination=d(2024, 7, 15),
                frequency="S",
                adjuster=adj,
            )
            assert s.n_periods == 1


class TestTenor:
    """Tests for tenor parsing and date arithmetic from Python."""

    def test_add_tenor_years(self):
        result = add_tenor(d(2024, 1, 15), "2Y")
        assert result == d(2026, 1, 15)

    def test_add_tenor_months(self):
        result = add_tenor(d(2024, 1, 15), "6M")
        assert result == d(2024, 7, 15)

    def test_add_tenor_weeks(self):
        result = add_tenor(d(2024, 1, 15), "1W")
        assert result == d(2024, 1, 22)

    def test_add_tenor_days(self):
        result = add_tenor(d(2024, 3, 1), "30D")
        assert result == d(2024, 3, 31)

    def test_add_tenor_business_days(self):
        cal = BusinessCalendar.new_custom([], [5, 6])
        result = add_tenor(d(2024, 1, 3), "3B", calendar=cal)
        assert result == d(2024, 1, 8)  # Wed + 3BD = Mon

    def test_add_tenor_requires_calendar_for_business_days(self):
        with pytest.raises(ValueError):
            add_tenor(d(2024, 1, 1), "3B")


class TestPaymentLag:
    """Tests for add_business_days from Python."""

    def test_forward(self):
        cal = BusinessCalendar.new_custom([], [5, 6])
        result = add_business_days(d(2024, 1, 1), 2, cal)
        assert result == d(2024, 1, 3)

    def test_over_weekend(self):
        cal = BusinessCalendar.new_custom([], [5, 6])
        result = add_business_days(d(2024, 1, 5), 1, cal)  # Friday
        assert result == d(2024, 1, 8)  # Monday

    def test_backward(self):
        cal = BusinessCalendar.new_custom([], [5, 6])
        result = add_business_days(d(2024, 1, 3), -2, cal)
        assert result == d(2024, 1, 1)

    def test_with_holiday(self):
        cal = BusinessCalendar("NYC")
        # Skip Christmas
        result = add_business_days(d(2024, 12, 24), 1, cal)
        assert result == d(2024, 12, 26)
