"""Integration tests for CDS, CreditImpliedCurve, CompositeCurve, FXImpliedCurve."""

import datetime
import math
import pytest

from vade import (
    CDS,
    CreditDefaultSwap,
    CreditImpliedCurve,
    CompositeCurve,
    FXImpliedCurve,
    DiscountCurve,
    LineCurve,
    FXRates,
    Solver,
)


def _d(y, m, d):
    return datetime.date(y, m, d)


def _make_disc_curve(dates_dfs, id="disc"):
    nodes = {d: v for d, v in dates_dfs}
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f", id=id)


def _make_line_curve(dates_vals, id="line"):
    nodes = {d: v for d, v in dates_vals}
    return LineCurve(nodes, interpolation="linear", convention="act365f", id=id)


def _make_credit_curve():
    """Simple credit curve with flat hazard rate 0.01 (~ 100bp per year)."""
    nodes = {
        _d(2024, 1, 1): 0.01,
        _d(2029, 1, 1): 0.01,
    }
    return CreditImpliedCurve(nodes, convention="act365f", recovery_rate=0.4, id="credit")


def _make_disc():
    return _make_disc_curve([
        (_d(2024, 1, 1), 1.0),
        (_d(2025, 1, 1), 0.97),
        (_d(2026, 1, 1), 0.94),
        (_d(2027, 1, 1), 0.91),
        (_d(2028, 1, 1), 0.88),
        (_d(2029, 1, 1), 0.85),
    ], id="disc")


class TestCreditImpliedCurve:
    def test_credit_implied_curve(self):
        cc = _make_credit_curve()
        # Q(1Y) = exp(-0.01 * 1) ~ 0.99
        sp = cc.survival_probability(_d(2025, 1, 1))
        val = sp if isinstance(sp, float) else sp.real
        expected = math.exp(-0.01 * (366 / 365))  # 2024 is leap year
        assert abs(val - expected) < 1e-4, f"Survival prob should be ~{expected}, got {val}"

    def test_credit_curve_discount_factor(self):
        cc = _make_credit_curve()
        # discount_factor == survival_probability for credit curves
        df = cc.discount_factor(_d(2025, 1, 1))
        sp = cc.survival_probability(_d(2025, 1, 1))
        df_val = df if isinstance(df, float) else df.real
        sp_val = sp if isinstance(sp, float) else sp.real
        assert abs(df_val - sp_val) < 1e-12

    def test_credit_curve_properties(self):
        cc = _make_credit_curve()
        assert cc.id == "credit"
        assert cc.recovery_rate == 0.4


class TestCDS:
    def test_cds_par_spread(self):
        disc = _make_disc()
        cc = _make_credit_curve()
        cds = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
            convention="act360",
        )
        par = cds.rate(disc, cc)
        val = par if isinstance(par, float) else par.real
        # Par spread should be reasonable (positive, typically 10-500bp)
        assert 1 < val < 500, f"Par spread should be reasonable, got {val}bp"

    def test_cds_npv_at_par(self):
        disc = _make_disc()
        cc = _make_credit_curve()
        cds = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
            convention="act360",
        )
        # Get par spread and create a CDS at par
        par = cds.rate(disc, cc)
        par_val = par if isinstance(par, float) else par.real
        cds_at_par = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=par_val,
            convention="act360",
        )
        npv = cds_at_par.npv(disc, cc)
        npv_val = npv if isinstance(npv, float) else npv.real
        assert abs(npv_val) < 1000, f"NPV at par should be ~0, got {npv_val}"

    def test_cds_cashflows(self):
        disc = _make_disc()
        cc = _make_credit_curve()
        cds = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
            convention="act360",
        )
        df = cds.cashflows(disc, cc)
        assert len(df) > 0, "Cashflows should have rows"
        # Should have both CreditPremium and CreditProtection rows
        types = df["Type"].to_list()
        assert any("CreditPremium" in t for t in types)
        assert any("CreditProtection" in t for t in types)

    def test_cds_accrued(self):
        cds = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
            convention="act360",
        )
        # Accrued mid-period
        acc = cds.accrued(_d(2024, 2, 15))
        assert acc >= 0, f"Accrued should be non-negative, got {acc}"

    def test_cds_jtd_ead(self):
        cds = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
            convention="act360",
        )
        # EAD = (1-R)*N = 0.6 * 10M = 6M
        ead = cds.ead()
        assert abs(ead - 6_000_000.0) < 1.0, f"EAD should be 6M, got {ead}"

        # JTD = (1-R)*N - accrued
        jtd = cds.jtd(_d(2024, 1, 1))
        assert jtd > 0, "JTD should be positive at effective date"

    def test_cds_upfront(self):
        disc = _make_disc()
        cc = _make_credit_curve()
        cds = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
            convention="act360",
        )
        upfront = cds.upfront(disc, cc)
        upfront_val = upfront if isinstance(upfront, float) else upfront.real
        # Upfront is a percentage, should be reasonable
        assert -50 < upfront_val < 50, f"Upfront should be reasonable, got {upfront_val}%"

    def test_cds_import(self):
        from vade import CDS, CreditImpliedCurve
        assert CDS is not None
        assert CreditImpliedCurve is not None


class TestCDSSolverRoundTrip:
    """Calibrate credit curve, then verify CDS.rate() returns target spreads."""

    def test_cds_solver_round_trip(self):
        """Calibrate credit curve from 2 CDS, verify rates match targets."""
        disc = _make_disc()
        credit_nodes = {
            _d(2024, 1, 1): 0.01,
            _d(2026, 1, 1): 0.01,
            _d(2028, 1, 1): 0.01,
        }
        credit_curve = CreditImpliedCurve(
            credit_nodes, convention="act365f", recovery_rate=0.4, id="credit"
        )

        targets = [60.0, 90.0]
        tenors = [_d(2026, 1, 1), _d(2028, 1, 1)]
        instruments = []
        for tenor, target in zip(tenors, targets):
            cds = CDS(
                effective=_d(2024, 1, 1), termination=tenor,
                frequency="q", notional=10_000_000.0,
                recovery_rate=0.4, fixed_rate=100.0,
                convention="act360", currency="usd",
            )
            instruments.append({
                "instrument": cds, "target": target,
                "disc_curve_idx": 0, "forecast_curve_idx": 1,
                "label": "cds", "currency": "usd",
            })

        solver = Solver(
            curves=[disc, credit_curve],
            instruments=instruments,
            func_tol=1e-10, max_iter=50,
        )
        result = solver.iterate()
        assert result.converged, f"Solver did not converge: {result.status}"

        calibrated = solver.get_curve(1)
        for i, (tenor, target) in enumerate(zip(tenors, targets)):
            cds = CDS(
                effective=_d(2024, 1, 1), termination=tenor,
                frequency="q", notional=10_000_000.0,
                recovery_rate=0.4, fixed_rate=100.0,
                convention="act360", currency="usd",
            )
            rate = cds.rate(disc, calibrated)
            val = float(rate) if not isinstance(rate, float) else rate
            assert abs(val - target) < 1.0, \
                f"CDS[{i}] rate {val} != target {target}"


def _make_disc_2016():
    """Discount curve spanning 2015-2022 for CDS IMM schedule tests."""
    return _make_disc_curve([
        (_d(2015, 12, 20), 1.0),
        (_d(2016, 12, 20), 0.98),
        (_d(2017, 12, 20), 0.96),
        (_d(2018, 12, 20), 0.94),
        (_d(2019, 12, 20), 0.92),
        (_d(2020, 12, 20), 0.90),
        (_d(2021, 12, 20), 0.88),
        (_d(2022, 12, 20), 0.86),
    ], id="disc2016")


def _make_credit_2016():
    """Credit curve spanning 2015-2022 for CDS IMM schedule tests."""
    nodes = {
        _d(2015, 12, 20): 0.01,
        _d(2022, 12, 20): 0.01,
    }
    return CreditImpliedCurve(nodes, convention="act365f", recovery_rate=0.4, id="credit2016")


class TestCDSIMMSchedule:
    """Integration tests for CDS IMM schedule generation via trade_date + tenor."""

    def test_cds_trade_date_5y(self):
        """CDS constructed with trade_date+tenor produces a valid instrument."""
        disc = _make_disc_2016()
        cc = _make_credit_2016()
        cds = CDS(
            trade_date=_d(2016, 3, 20),
            tenor="5Y",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
        )
        par = cds.rate(disc, cc)
        val = par if isinstance(par, float) else par.real
        assert 0 < val < 500, f"Par spread should be reasonable, got {val}bp"

    def test_cds_trade_date_maturity_vectors(self):
        """QuantLib CDS2015 cdsMaturity test vectors for 5Y tenor."""
        disc = _make_disc_2016()
        cc = _make_credit_2016()

        vectors = [
            # (trade_date, tenor, expected_last_payment_date)
            (_d(2016, 3, 19), "5Y", _d(2020, 12, 20)),
            (_d(2016, 3, 20), "5Y", _d(2021, 6, 20)),
            (_d(2016, 6, 20), "5Y", _d(2021, 6, 20)),
            (_d(2016, 9, 20), "5Y", _d(2021, 12, 20)),
            (_d(2016, 12, 12), "5Y", _d(2021, 12, 20)),
            (_d(2016, 12, 20), "5Y", _d(2021, 12, 20)),
        ]

        for trade_date, tenor, expected_maturity in vectors:
            cds = CDS(
                trade_date=trade_date,
                tenor=tenor,
                notional=10_000_000.0,
                recovery_rate=0.4,
                fixed_rate=100.0,
            )
            cf = cds.cashflows(disc, cc)
            # Get last premium cashflow payment date
            premium_rows = cf.filter(cf["Type"].str.contains("CreditPremium"))
            last_payment = premium_rows["payment"].to_list()[-1]
            # The unadjusted maturity date -- adjusted may shift by 1-2 days for weekends
            # Check the last payment is within 2 business days of expected maturity
            delta = abs((last_payment - expected_maturity).days)
            assert delta <= 2, (
                f"trade={trade_date}, tenor={tenor}: last payment {last_payment} "
                f"should be near {expected_maturity} (delta={delta}d)"
            )

    def test_cds_schedule_rule(self):
        """Schedule(rule='cds') generates quarterly IMM 20th dates."""
        from vade import Schedule
        s = Schedule(
            effective=_d(2024, 3, 20),
            termination=_d(2029, 6, 20),
            frequency="q",
            rule="cds",
        )
        for d in s.unadjusted_dates:
            assert d.day == 20, f"Date {d} not on 20th"
            assert d.month in (3, 6, 9, 12), f"Date {d} not in IMM quarter month"

    def test_cds_imm_date_helpers(self):
        """previous_imm_cds_date and next_imm_cds_date callable from Python."""
        import vade
        prev = vade.previous_imm_cds_date(_d(2024, 4, 5))
        assert prev == _d(2024, 3, 20), f"Expected 2024-03-20, got {prev}"

        nxt = vade.next_imm_cds_date(_d(2024, 4, 5))
        assert nxt == _d(2024, 6, 20), f"Expected 2024-06-20, got {nxt}"

    def test_cds_backward_compat(self):
        """Existing CDS construction with effective+termination still works."""
        disc = _make_disc()
        cc = _make_credit_curve()
        cds = CDS(
            effective=_d(2024, 1, 1),
            termination=_d(2029, 1, 1),
            frequency="q",
            notional=10_000_000.0,
            recovery_rate=0.4,
            fixed_rate=100.0,
            convention="act360",
        )
        par = cds.rate(disc, cc)
        val = par if isinstance(par, float) else par.real
        assert 1 < val < 500, f"Par spread should be reasonable, got {val}bp"


class TestCompositeCurve:
    def test_composite_curve_discount(self):
        c1 = _make_disc_curve([
            (_d(2024, 1, 1), 1.0),
            (_d(2025, 1, 1), 0.97),
        ], id="c1")
        c2 = _make_disc_curve([
            (_d(2024, 1, 1), 1.0),
            (_d(2025, 1, 1), 0.99),
        ], id="c2")

        comp = CompositeCurve([c1, c2], id="composite")
        df = comp.discount_factor(_d(2025, 1, 1))
        val = df if isinstance(df, float) else df.real
        expected = 0.97 * 0.99
        assert abs(val - expected) < 1e-8, f"Composite DF should be {expected}, got {val}"

    def test_composite_curve_line(self):
        c1 = _make_line_curve([
            (_d(2024, 1, 1), 0.02),
            (_d(2025, 1, 1), 0.02),
        ], id="l1")
        c2 = _make_line_curve([
            (_d(2024, 1, 1), 0.01),
            (_d(2025, 1, 1), 0.01),
        ], id="l2")

        comp = CompositeCurve([c1, c2], id="composite")
        zr = comp.zero_rate(_d(2024, 1, 1), _d(2025, 1, 1))
        val = zr if isinstance(zr, float) else zr.real
        # Sum of zero rates: 0.02 + 0.01 = 0.03
        assert abs(val - 0.03) < 1e-4, f"Composite zero rate should be ~0.03, got {val}"


class TestFXImpliedCurve:
    def test_proxy_curve(self):
        fxr = FXRates({"eurusd": 1.1}, _d(2024, 1, 1))
        settlements = {"eurusd": _d(2024, 1, 3)}

        usd_curve = _make_disc_curve([
            (_d(2024, 1, 1), 1.0),
            (_d(2025, 1, 1), 0.95),
        ], id="usd")
        eur_curve = _make_disc_curve([
            (_d(2024, 1, 1), 1.0),
            (_d(2025, 1, 1), 0.97),
        ], id="eur")

        proxy = FXImpliedCurve("eur", "usd", fxr, settlements, usd_curve, eur_curve)
        df = proxy.discount_factor(_d(2025, 1, 1))
        val = df if isinstance(df, float) else df.real
        # In simple case without basis, proxy DF ~ cashflow DF = 0.97
        assert abs(val - 0.97) < 0.02, f"Proxy DF should be ~0.97, got {val}"

    def test_proxy_curve_as_curve(self):
        """FXImpliedCurve should be usable wherever a curve is expected (D-38)."""
        fxr = FXRates({"eurusd": 1.1}, _d(2024, 1, 1))
        settlements = {"eurusd": _d(2024, 1, 3)}

        usd_curve = _make_disc_curve([
            (_d(2024, 1, 1), 1.0),
            (_d(2025, 1, 1), 0.95),
        ], id="usd")
        eur_curve = _make_disc_curve([
            (_d(2024, 1, 1), 1.0),
            (_d(2025, 1, 1), 0.97),
        ], id="eur")

        proxy = FXImpliedCurve("eur", "usd", fxr, settlements, usd_curve, eur_curve)
        # Test zero_rate works
        zr = proxy.zero_rate(_d(2024, 1, 1), _d(2025, 1, 1))
        val = zr if isinstance(zr, float) else zr.real
        assert val > 0, f"Zero rate should be positive, got {val}"
