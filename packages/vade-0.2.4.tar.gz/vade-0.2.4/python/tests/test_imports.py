"""Smoke tests verifying the clean import API and conventions (API-01, API-03, API-04)."""

import datetime
import inspect


class TestAutodiffImports:
    """Verify autodiff module imports work cleanly."""

    def test_import_dual(self):
        from vade.autodiff import Dual

        d = Dual("x", 2.0)
        assert d.real == 2.0

    def test_import_dual2(self):
        from vade.autodiff import Dual2

        d = Dual2("x", 3.0)
        assert d.real == 3.0

    def test_all_exports(self):
        from vade.autodiff import __all__

        assert "Dual" in __all__
        assert "Dual2" in __all__


class TestCalendarImports:
    """Verify calendar module imports work cleanly."""

    def test_import_business_calendar(self):
        from vade.calendar import BusinessCalendar

        cal = BusinessCalendar("NYC")
        assert repr(cal) == "BusinessCalendar('NYC')"

    def test_import_schedule(self):
        from vade.calendar import Schedule

        s = Schedule(
            effective=datetime.date(2024, 1, 15),
            termination=datetime.date(2025, 1, 15),
            frequency="S",
        )
        assert s.n_periods == 2

    def test_import_dcf(self):
        from vade.calendar import dcf

        result = dcf("act360", datetime.date(2024, 1, 15), datetime.date(2024, 7, 15))
        assert abs(result - 182.0 / 360.0) < 1e-10

    def test_import_add_tenor(self):
        from vade.calendar import add_tenor

        result = add_tenor(datetime.date(2024, 1, 15), "2Y")
        assert result == datetime.date(2026, 1, 15)

    def test_import_add_business_days(self):
        from vade.calendar import add_business_days, BusinessCalendar

        cal = BusinessCalendar.new_custom([], [5, 6])
        result = add_business_days(datetime.date(2024, 1, 5), 1, cal)
        assert result == datetime.date(2024, 1, 8)  # Friday + 1 = Monday

    def test_all_exports(self):
        from vade.calendar import __all__

        assert "BusinessCalendar" in __all__
        assert "Schedule" in __all__
        assert "dcf" in __all__
        assert "add_tenor" in __all__
        assert "add_business_days" in __all__


class TestNoGlobalState:
    """Verify no global mutable state exists (API-03)."""

    def test_calendar_requires_explicit_parameter(self):
        """BusinessCalendar must be explicitly passed to functions that need it."""
        from vade.calendar import dcf

        # bus252 requires explicit calendar parameter
        try:
            dcf("bus252", datetime.date(2024, 1, 1), datetime.date(2024, 1, 8))
            assert False, "Should have raised an error requiring calendar"
        except (ValueError, TypeError):
            pass

    def test_schedule_uses_explicit_params(self):
        """Schedule uses explicit parameters with sensible defaults (API-04)."""
        from vade.calendar import Schedule

        # All parameters are keyword arguments with defaults
        s = Schedule(
            effective=datetime.date(2024, 1, 15),
            termination=datetime.date(2025, 1, 15),
            frequency="S",
        )
        assert s.n_periods == 2

    def test_two_calendars_are_independent(self):
        """Two calendar instances do not share mutable state."""
        from vade.calendar import BusinessCalendar

        cal1 = BusinessCalendar("NYC")
        cal2 = BusinessCalendar("LDN")
        # Modifying one should not affect the other
        assert cal1.is_holiday(datetime.date(2024, 11, 11))  # Veterans Day (NYC)
        assert not cal2.is_holiday(datetime.date(2024, 11, 11))  # Not a LDN holiday


class TestFlatImports:
    """Verify all public types are importable from top-level vade (API-01)."""

    def test_flat_import_all_names(self):
        """Every name in __all__ is importable from vade."""
        import vade
        for name in vade.__all__:
            assert hasattr(vade, name), f"vade.__all__ lists '{name}' but it is not importable"

    def test_all_completeness(self):
        """__all__ has at least 50 names per D-01."""
        import vade
        assert len(vade.__all__) >= 50, f"Expected 50+ names, got {len(vade.__all__)}"

    def test_sys_not_exported(self):
        """sys module does not leak into public namespace."""
        import vade
        assert "sys" not in vade.__all__

    def test_flat_import_curves(self):
        from vade import (
            DiscountCurve, LineCurve, ForwardCurve, SpreadCurve,
            TurnOfYearCurve, CompositeCurve, FXImpliedCurve,
            CreditImpliedCurve, IRImpliedCurve,
            NelsonSiegel, NelsonSiegelSvensson, SmithWilson,
        )

    def test_flat_import_instruments(self):
        from vade import (
            IRS, FRA, ZCS, SBS, OIS, Deposit, IRFuture, CapFloor,
            FixedRateBond, Bill, FloatRateNote, CDS, XCS, FXForward,
            InterestRateSwap, ForwardRateAgreement, ZeroCouponSwap,
            SingleBasisSwap, OvernightIndexedSwap,
            CreditDefaultSwap, CrossCurrencySwap,
        )

    def test_flat_import_solver(self):
        from vade import Solver, SolverResult, bootstrap

    def test_flat_import_fx(self):
        from vade import FXRates, FXForwards, FXPair

    def test_flat_import_cashflows(self):
        from vade import FixedLeg, FloatLeg

    def test_flat_import_autodiff(self):
        from vade import Dual, Dual2

    def test_flat_import_calendar(self):
        from vade import Schedule, BusinessCalendar, dcf, add_tenor, add_business_days

    def test_flat_import_numerical(self):
        from vade import brent_solve, newton_raphson_solve


class TestSubmoduleAll:
    """Verify __all__ lists in all submodules."""

    def test_curves_all(self):
        from vade import curves
        assert len(curves.__all__) == 13

    def test_solver_all(self):
        from vade import solver
        assert "bootstrap" in solver.__all__

    def test_numerical_all(self):
        from vade import numerical
        assert "brent_solve" in numerical.__all__
        assert "newton_raphson_solve" in numerical.__all__

    def test_autodiff_all(self):
        from vade import autodiff
        assert "Dual" in autodiff.__all__
        assert "Dual2" in autodiff.__all__

    def test_calendar_all(self):
        from vade import calendar
        assert "BusinessCalendar" in calendar.__all__
        assert "Schedule" in calendar.__all__
