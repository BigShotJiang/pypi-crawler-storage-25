"""Tests for Non-Deliverable Interest Rate Swap (NDIRS).

Covers NDIRS-01 (construction, cashflows, specs), NDIRS-02 (partial FX fixings),
NDIRS-03 (3-curve model), and COMN-01/02/03 (AD, JSON, spread consistency).
"""

import datetime
import json
import math

import polars as pl
import pytest

from vade import NDIRS, DiscountCurve, FXRates, Dual
from vade.instruments import InterestRateSwap
from vade.instruments.specs import INSTRUMENT_SPECS


def _d(y, m, d):
    return datetime.date(y, m, d)


def _make_disc_curve(nodes, id="curve"):
    return DiscountCurve(
        nodes,
        interpolation="log_linear",
        convention="act365f",
        id=id,
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def usd_curve():
    """Settlement discount curve (USD) -- flat ~3% rates."""
    return _make_disc_curve(
        {
            _d(2024, 1, 1): 1.0,
            _d(2025, 1, 1): 0.9709,
            _d(2026, 1, 1): 0.9426,
            _d(2027, 1, 1): 0.9151,
            _d(2028, 1, 1): 0.8885,
            _d(2029, 1, 1): 0.8626,
        },
        id="usd",
    )


@pytest.fixture
def brl_curve():
    """Restricted forecast AND discount curve (BRL) -- flat ~12% rates."""
    return _make_disc_curve(
        {
            _d(2024, 1, 1): 1.0,
            _d(2025, 1, 1): 0.8929,
            _d(2026, 1, 1): 0.7972,
            _d(2027, 1, 1): 0.7118,
            _d(2028, 1, 1): 0.6355,
            _d(2029, 1, 1): 0.5674,
        },
        id="brl",
    )


@pytest.fixture
def fxr():
    """USDBRL spot = 5.0 (5 BRL per 1 USD)."""
    return FXRates({"usdbrl": 5.0}, _d(2024, 1, 15))


def _make_test_ndirs(**overrides):
    """Create standard test NDIRS."""
    defaults = dict(
        effective=_d(2024, 1, 1),
        termination="2Y",
        fixed_rate=10.0,
        notional=1_000_000.0,
        settlement_currency="usd",
        pair="usdbrl",
        convention="act365f",
        frequency="s",
    )
    defaults.update(overrides)
    return NDIRS(**defaults)


# ---------------------------------------------------------------------------
# NDIRS-01: Construction
# ---------------------------------------------------------------------------


class TestNDIRSConstruction:
    def test_ndirs_construction(self):
        ndirs = _make_test_ndirs()
        assert ndirs is not None
        assert isinstance(ndirs, NDIRS)
        # pillar_date should be after effective
        assert ndirs.pillar_date() > _d(2024, 1, 1)

    def test_ndirs_is_irs_subclass(self):
        ndirs = _make_test_ndirs()
        assert isinstance(ndirs, InterestRateSwap)

    def test_ndirs_construction_with_spec(self):
        ndirs = NDIRS(
            spec="usdbrl_ndirs",
            effective=_d(2024, 1, 1),
            termination="2Y",
            fixed_rate=10.0,
        )
        assert ndirs is not None

    def test_ndirs_requires_effective(self):
        with pytest.raises(ValueError, match="effective"):
            NDIRS(termination="2Y", fixed_rate=10.0, pair="usdbrl")

    def test_ndirs_requires_termination(self):
        with pytest.raises(ValueError, match="termination"):
            NDIRS(effective=_d(2024, 1, 1), fixed_rate=10.0, pair="usdbrl")


# ---------------------------------------------------------------------------
# NDIRS-01: Cashflows
# ---------------------------------------------------------------------------


class TestNDIRSCashflows:
    def test_ndirs_cashflows_have_settlement_fields(self, usd_curve, brl_curve, fxr):
        ndirs = _make_test_ndirs()
        df = ndirs.cashflows(curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr)
        assert isinstance(df, pl.DataFrame)
        assert "FX_Rate" in df.columns
        assert "Settlement_Amount" in df.columns
        assert "Settlement_Ccy" in df.columns

    def test_ndirs_cashflows_settlement_amounts_nonzero(self, usd_curve, brl_curve, fxr):
        ndirs = _make_test_ndirs()
        df = ndirs.cashflows(curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr)
        # Filter to interest periods (Fixed/Float) -- skip notional exchange
        interest = df.filter(pl.col("Type").is_in(["Fixed", "Float"]))
        # All interest rows should have non-null FX rates and settlement amounts
        fx_rates = interest["FX_Rate"].to_list()
        settle_amts = interest["Settlement_Amount"].to_list()
        assert all(r is not None and r > 0 for r in fx_rates), f"Some FX_Rate values are None or zero: {fx_rates}"
        assert all(a is not None and a != 0 for a in settle_amts), f"Some Settlement_Amount values are zero: {settle_amts}"

    def test_ndirs_cashflows_settlement_ccy_is_usd(self, usd_curve, brl_curve, fxr):
        ndirs = _make_test_ndirs()
        df = ndirs.cashflows(curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr)
        settle_ccys = df["Settlement_Ccy"].to_list()
        assert all(c.lower() == "usd" for c in settle_ccys if c is not None)


# ---------------------------------------------------------------------------
# NDIRS-02: Partial FX fixings
# ---------------------------------------------------------------------------


class TestNDIRSPartialFixings:
    def test_partial_fx_fixings(self, usd_curve, brl_curve, fxr):
        """Partial fixings produce different NPV than no fixings."""
        ndirs_no_fix = _make_test_ndirs()
        npv_no = float(ndirs_no_fix.npv(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))

        # Provide fixing for first coupon date only (significantly different from implied)
        ndirs_partial = _make_test_ndirs(
            fx_fixings={_d(2024, 7, 1): 6.0}  # 6.0 vs implied ~5.2
        )
        npv_partial = float(ndirs_partial.npv(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))

        assert math.isfinite(npv_no)
        assert math.isfinite(npv_partial)
        # With a fixing of 6.0 (materially different from implied ~5.2),
        # NPVs should differ
        assert abs(npv_no - npv_partial) > 1.0, \
            f"Partial fixings should change NPV: no_fix={npv_no}, partial={npv_partial}"

    def test_full_fx_fixings(self, usd_curve, brl_curve, fxr):
        """Full fixings produce finite NPV different from no-fixings case."""
        ndirs_no_fix = _make_test_ndirs()
        npv_no = float(ndirs_no_fix.npv(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))

        # All coupon dates get fixings at 6.0 (materially different from implied)
        all_fixings = {
            _d(2024, 7, 1): 6.0,
            _d(2025, 1, 1): 6.2,
            _d(2025, 7, 1): 6.4,
            _d(2026, 1, 1): 6.6,
        }
        ndirs_full = _make_test_ndirs(fx_fixings=all_fixings)
        npv_full = float(ndirs_full.npv(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))

        assert math.isfinite(npv_full)
        assert abs(npv_no - npv_full) > 1.0

    def test_no_fx_fixings(self, usd_curve, brl_curve, fxr):
        """No fixings: all FX rates are IRP-implied."""
        ndirs = _make_test_ndirs(fx_fixings=None)
        npv = float(ndirs.npv(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        assert math.isfinite(npv)


# ---------------------------------------------------------------------------
# NDIRS-03: 3-Curve Model
# ---------------------------------------------------------------------------


class TestNDIRS3CurveModel:
    def test_three_curve_model(self, usd_curve, brl_curve, fxr):
        """Swapping the forecast curve (restricted forward) materially changes the rate.

        The 3-curve model separates: (1) settlement discounting (USD),
        (2) restricted forward projection (BRL forecast), (3) restricted
        discounting for FX forwards (BRL disc). Changing the forecast curve
        should change the floating leg projection and therefore the par rate.
        """
        ndirs = _make_test_ndirs()

        # Correct: usd_disc, brl_forecast, brl_disc
        rate_correct = float(ndirs.rate(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        # Swap forecast to USD (wrong: ~3% forward rates instead of ~12%)
        rate_swapped = float(ndirs.rate(
            curves=[usd_curve, usd_curve, brl_curve], fx_rates=fxr
        ))

        assert math.isfinite(rate_correct)
        assert math.isfinite(rate_swapped)
        # BRL (~12%) vs USD (~3%) forecast should produce materially different par rate
        assert abs(rate_correct - rate_swapped) > 1.0, \
            f"3-curve model should matter: correct={rate_correct}, swapped_forecast={rate_swapped}"

    def test_wrong_curve_produces_different_rate(self, usd_curve, brl_curve, fxr):
        """Swapping disc and forecast curves produces different rate."""
        ndirs = _make_test_ndirs()

        rate_correct = float(ndirs.rate(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        rate_swapped = float(ndirs.rate(
            curves=[brl_curve, usd_curve, brl_curve], fx_rates=fxr
        ))

        assert math.isfinite(rate_correct)
        assert math.isfinite(rate_swapped)
        assert abs(rate_correct - rate_swapped) > 0.1, \
            f"Swapped curves should give different rate: {rate_correct} vs {rate_swapped}"

    def test_ndirs_rate(self, usd_curve, brl_curve, fxr):
        """Par rate is positive, finite, and reasonable."""
        ndirs = _make_test_ndirs()
        rate = float(ndirs.rate(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        assert math.isfinite(rate)
        assert 0 < rate < 50, f"NDIRS rate {rate} out of reasonable range"

    def test_ndirs_npv_at_par_rate(self, usd_curve, brl_curve, fxr):
        """NPV at par rate should be approximately zero."""
        ndirs_probe = _make_test_ndirs()
        par_rate = float(ndirs_probe.rate(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))

        ndirs_par = _make_test_ndirs(fixed_rate=par_rate)
        npv = float(ndirs_par.npv(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        assert abs(npv) < 1000, \
            f"NPV at par rate should be ~0, got {npv} (par_rate={par_rate})"

    def test_ndirs_spread(self, usd_curve, brl_curve, fxr):
        """Spread is finite."""
        ndirs = _make_test_ndirs()
        spread = float(ndirs.spread(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        assert math.isfinite(spread)

    def test_ndirs_requires_fx_rates(self, usd_curve, brl_curve):
        """Methods raise if fx_rates not provided."""
        ndirs = _make_test_ndirs()
        with pytest.raises(ValueError, match="fx_rates"):
            ndirs.rate(curves=[usd_curve, brl_curve, brl_curve])
        with pytest.raises(ValueError, match="fx_rates"):
            ndirs.npv(curves=[usd_curve, brl_curve, brl_curve])

    def test_ndirs_requires_3_curves(self, fxr):
        """Methods raise if fewer than 3 curves provided."""
        ndirs = _make_test_ndirs()
        usd = _make_disc_curve({_d(2024,1,1): 1.0, _d(2026,1,1): 0.94}, id="usd")
        with pytest.raises(ValueError, match="3 curves"):
            ndirs.rate(curves=[usd], fx_rates=fxr)


# ---------------------------------------------------------------------------
# NDIRS-01: Specs
# ---------------------------------------------------------------------------


class TestNDIRSSpecs:
    def test_ndirs_spec_usdbrl(self):
        ndirs = NDIRS(spec="usdbrl_ndirs", effective=_d(2024, 1, 1), termination="5Y", fixed_rate=10.0)
        assert ndirs is not None

    def test_ndirs_spec_usdinr(self):
        ndirs = NDIRS(spec="usdinr_ndirs", effective=_d(2024, 1, 1), termination="5Y", fixed_rate=7.0)
        assert ndirs is not None

    def test_ndirs_spec_usdkrw(self):
        ndirs = NDIRS(spec="usdkrw_ndirs", effective=_d(2024, 1, 1), termination="5Y", fixed_rate=3.0)
        assert ndirs is not None

    def test_ndirs_spec_usdcny(self):
        ndirs = NDIRS(spec="usdcny_ndirs", effective=_d(2024, 1, 1), termination="5Y", fixed_rate=3.0)
        assert ndirs is not None

    def test_ndirs_spec_usdtwd(self):
        ndirs = NDIRS(spec="usdtwd_ndirs", effective=_d(2024, 1, 1), termination="5Y", fixed_rate=2.0)
        assert ndirs is not None

    def test_all_5_ndirs_specs_in_registry(self):
        expected = ["usdbrl_ndirs", "usdinr_ndirs", "usdkrw_ndirs", "usdcny_ndirs", "usdtwd_ndirs"]
        for name in expected:
            assert name in INSTRUMENT_SPECS, f"Missing NDIRS spec: {name}"


# ---------------------------------------------------------------------------
# COMN-01, COMN-02, COMN-03: AD, JSON, Spread
# ---------------------------------------------------------------------------


class TestNDIRSCommon:
    def test_ndirs_ad_support(self, usd_curve, brl_curve, fxr):
        """Rate and NPV work with AD-enabled curves (result may be Dual)."""
        ndirs = _make_test_ndirs()
        rate = ndirs.rate(curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr)
        npv = ndirs.npv(curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr)
        # FXRates creates Dual variables, so results should be Dual
        rate_val = float(rate) if not isinstance(rate, float) else rate
        npv_val = float(npv) if not isinstance(npv, float) else npv
        assert math.isfinite(rate_val)
        assert math.isfinite(npv_val)

    def test_ndirs_json_roundtrip(self):
        """JSON roundtrip preserves key fields."""
        ndirs = _make_test_ndirs(
            fx_fixings={_d(2024, 7, 1): 5.3, _d(2025, 1, 1): 5.5}
        )
        json_str = ndirs.to_json()
        data = json.loads(json_str)
        assert data["type"] == "NDIRS"
        assert data["settlement_currency"] == "usd"
        assert data["pair"] == "usdbrl"
        assert "2024-07-01" in data["fx_fixings"]
        assert data["fx_fixings"]["2024-07-01"] == 5.3

        # Roundtrip
        ndirs2 = NDIRS.from_json(json_str)
        assert ndirs2._settlement_currency == "usd"
        assert ndirs2._pair == "usdbrl"
        assert ndirs2._fx_fixings[_d(2024, 7, 1)] == 5.3
        assert ndirs2._fx_fixings[_d(2025, 1, 1)] == 5.5

    def test_ndirs_json_without_fixings(self):
        """JSON works without fx_fixings."""
        ndirs = _make_test_ndirs()
        json_str = ndirs.to_json()
        data = json.loads(json_str)
        assert "fx_fixings" not in data or data.get("fx_fixings") is None

    def test_ndirs_spread_consistent(self, usd_curve, brl_curve, fxr):
        """At par rate, spread should be approximately zero."""
        ndirs_probe = _make_test_ndirs()
        par_rate = float(ndirs_probe.rate(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        ndirs_par = _make_test_ndirs(fixed_rate=par_rate)
        spread = float(ndirs_par.spread(
            curves=[usd_curve, brl_curve, brl_curve], fx_rates=fxr
        ))
        # At par, spread should be near zero
        assert abs(spread) < 1.0, f"Spread at par rate should be ~0, got {spread}"

    def test_ndirs_import_from_vade(self):
        """NDIRS is importable via from vade import NDIRS."""
        from vade import NDIRS as _NDIRS
        assert _NDIRS is not None

    def test_ndirs_pillar_date(self):
        """pillar_date returns termination date."""
        ndirs = _make_test_ndirs(termination="3Y")
        pd = ndirs.pillar_date()
        assert pd == _d(2027, 1, 1)
