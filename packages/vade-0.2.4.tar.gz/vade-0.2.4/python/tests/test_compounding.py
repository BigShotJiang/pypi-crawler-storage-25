"""Tests for compounding conversion functions (discount_factor, rate_from_df, convert_rate)."""

import math
from itertools import combinations

import pytest

import vade


def test_discount_factor_continuous():
    result = vade.discount_factor(0.05, 1.0, "continuous")
    assert result == pytest.approx(math.exp(-0.05))


def test_discount_factor_annual():
    result = vade.discount_factor(0.05, 1.0, "annual")
    assert result == pytest.approx(1.0 / 1.05)


def test_discount_factor_semi_annual():
    result = vade.discount_factor(0.05, 1.0, "semi_annual")
    assert result == pytest.approx((1.025) ** (-2))


def test_discount_factor_quarterly():
    result = vade.discount_factor(0.05, 1.0, "quarterly")
    assert result == pytest.approx((1.0125) ** (-4))


def test_discount_factor_daily():
    result = vade.discount_factor(0.05, 1.0, "daily")
    assert result == pytest.approx((1 + 0.05 / 365) ** (-365))


def test_discount_factor_simple():
    result = vade.discount_factor(0.05, 2.0, "simple")
    assert result == pytest.approx(1.0 / (1.0 + 0.05 * 2.0))


def test_rate_from_df_roundtrip():
    """For each convention, compute df then recover rate."""
    rate = 0.05
    time = 1.0
    for conv in ["continuous", "annual", "semi_annual", "quarterly", "daily", "simple"]:
        df = vade.discount_factor(rate, time, conv)
        recovered = vade.rate_from_df(df, time, conv)
        assert recovered == pytest.approx(rate, abs=1e-12), f"roundtrip failed for {conv}"


def test_convert_rate_roundtrip():
    """Convert continuous -> semi_annual -> continuous should return original rate."""
    original = 0.05
    converted = vade.convert_rate(original, 1.0, "continuous", "semi_annual")
    back = vade.convert_rate(converted, 1.0, "semi_annual", "continuous")
    assert back == pytest.approx(original, abs=1e-15)


def test_convert_rate_all_pairs():
    """All pairwise conversions (excluding simple) should round-trip."""
    rate = 0.05
    time = 1.0
    conventions = ["continuous", "annual", "semi_annual", "quarterly"]
    for from_conv, to_conv in combinations(conventions, 2):
        converted = vade.convert_rate(rate, time, from_conv, to_conv)
        back = vade.convert_rate(converted, time, to_conv, from_conv)
        assert back == pytest.approx(rate, abs=1e-14), f"roundtrip {from_conv}->{to_conv} failed"


def test_invalid_convention_raises():
    with pytest.raises(ValueError, match="Unknown compounding convention"):
        vade.discount_factor(0.05, 1.0, "bad")


def test_invalid_convention_rate_from_df_raises():
    with pytest.raises(ValueError, match="Unknown compounding convention"):
        vade.rate_from_df(0.95, 1.0, "bad")


def test_invalid_convention_convert_rate_raises():
    with pytest.raises(ValueError):
        vade.convert_rate(0.05, 1.0, "continuous", "bad")
    with pytest.raises(ValueError):
        vade.convert_rate(0.05, 1.0, "bad", "continuous")


def test_price_from_ytm_unchanged():
    """Regression: price_from_ytm produces identical results after refactor."""
    import datetime

    bond = vade.FixedRateBond(
        effective=datetime.date(2024, 1, 15),
        termination=datetime.date(2029, 1, 15),
        frequency="S",
        coupon=0.05,
        calendar="nyc",
        convention="act360",
    )
    settlement = datetime.date(2024, 1, 15)

    # Baseline values computed from the original implementation
    # "periodic" (default): standard frequency-based discounting
    price_periodic = bond.price_from_ytm(0.05, settlement, "periodic")
    assert price_periodic == pytest.approx(100.0, abs=0.5), f"periodic price: {price_periodic}"

    # "continuous": exp(-ytm * t)
    price_continuous = bond.price_from_ytm(0.05, settlement, "continuous")
    assert price_continuous > 99.0, f"continuous price: {price_continuous}"

    # "annual": (1 + ytm)^(-t)
    price_annual = bond.price_from_ytm(0.05, settlement, "annual")
    assert price_annual > 99.0, f"annual price: {price_annual}"

    # "semi_annual": (1 + ytm/2)^(-2t)
    price_semi = bond.price_from_ytm(0.05, settlement, "semi_annual")
    assert price_semi > 99.0, f"semi_annual price: {price_semi}"

    # All prices should be close to par for a 5% coupon bond at 5% yield
    for conv, price in [("periodic", price_periodic), ("continuous", price_continuous),
                        ("annual", price_annual), ("semi_annual", price_semi)]:
        assert 98.0 < price < 102.0, f"{conv} price out of range: {price}"
