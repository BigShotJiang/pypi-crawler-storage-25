"""Integration tests for AssetSwap instrument."""

import math
import datetime
from datetime import date

import pytest

from vade import (
    AssetSwap, FixedRateBond, FloatRateNote, ZeroCouponBond,
    StepUpBond, DiscountCurve,
)


def make_flat_curve(rate: float = 0.03) -> DiscountCurve:
    """Create a flat discount curve for testing."""
    base = date(2024, 1, 1)
    dates = [base]
    dfs = [1.0]
    for y in range(1, 11):
        d = date(2024 + y, 1, 1)
        dates.append(d)
        dfs.append(math.exp(-rate * y))

    return DiscountCurve(
        dict(zip(dates, dfs)),
        interpolation="log_linear",
        convention="act365f",
        id="test_curve",
    )


@pytest.fixture
def curve():
    return make_flat_curve(0.03)


@pytest.fixture
def bond():
    return FixedRateBond(
        effective=date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
        face_value=100,
    )


def test_par_asset_swap(bond, curve):
    """Par asset swap computes a finite spread."""
    asw = AssetSwap(bond=bond, asw_type="par")
    spread = asw.rate(curves=curve)
    assert isinstance(spread, float)
    assert math.isfinite(spread)
    assert -0.5 < spread < 0.5


def test_non_par_asset_swap(bond, curve):
    """Non-par asset swap with dirty_price computes finite spread."""
    asw = AssetSwap(bond=bond, asw_type="non_par", dirty_price=102.5)
    spread = asw.rate(curves=curve)
    assert isinstance(spread, float)
    assert math.isfinite(spread)

    # Different dirty_price gives different spread
    asw2 = AssetSwap(bond=bond, asw_type="non_par", dirty_price=97.0)
    spread2 = asw2.rate(curves=curve)
    assert abs(spread - spread2) > 1e-6


def test_non_par_dirty_price_sensitivity(bond, curve):
    """Different dirty_prices produce different non-par spreads."""
    asw1 = AssetSwap(bond=bond, asw_type="non_par", dirty_price=101.0)
    asw2 = AssetSwap(bond=bond, asw_type="non_par", dirty_price=103.0)
    s1 = asw1.rate(curves=curve)
    s2 = asw2.rate(curves=curve)
    assert abs(s1 - s2) > 1e-6


def test_par_consistency(bond, curve):
    """Par AssetSwap.rate() matches bond.asw_spread('par_par')."""
    # Bond method
    bond_spread = bond.asw_spread(curves=curve, price=100.0, method="par_par")

    # AssetSwap method
    asw = AssetSwap(bond=bond, asw_type="par")
    asw_spread = asw.rate(curves=curve)

    # Both compute par spread; should be close
    assert math.isfinite(bond_spread)
    assert math.isfinite(asw_spread)
    assert abs(bond_spread - asw_spread) < 1e-6


def test_non_par_requires_dirty_price(bond):
    """Non-par asset swap without dirty_price raises ValueError."""
    with pytest.raises(ValueError, match="dirty_price"):
        AssetSwap(bond=bond, asw_type="non_par")


def test_all_variants(curve):
    """Asset swap works with multiple bond variants."""
    bonds = [
        FixedRateBond(
            effective=date(2024, 1, 1), termination="5Y",
            coupon=0.04, frequency="s",
        ),
        FloatRateNote(
            effective=date(2024, 1, 1), termination="5Y",
            spread=0.005, frequency="q",
        ),
        StepUpBond(
            effective=date(2024, 1, 1), termination="5Y",
            coupon_rates=[(date(2024, 1, 1), 0.03), (date(2026, 1, 1), 0.04)],
            frequency="s",
        ),
    ]
    for b in bonds:
        asw = AssetSwap(bond=b, asw_type="par")
        spread = asw.rate(curves=curve)
        assert math.isfinite(spread), f"Spread not finite for {type(b).__name__}"


def test_npv_at_fair_spread(bond, curve):
    """NPV is 0 when no fixed spread is set."""
    asw = AssetSwap(bond=bond, asw_type="par")
    npv = asw.npv(curves=curve)
    assert abs(npv) < 1e-10


def test_npv_with_fixed_spread(bond, curve):
    """NPV is non-zero when a fixed spread is set."""
    asw = AssetSwap(bond=bond, asw_type="par", spread=0.01)
    npv = asw.npv(curves=curve)
    assert isinstance(npv, float)
    assert math.isfinite(npv)
    assert abs(npv) > 1e-6  # non-zero


def test_cashflows(bond, curve):
    """Cashflows returns a non-empty Polars DataFrame."""
    asw = AssetSwap(bond=bond, asw_type="par")
    cfs = asw.cashflows(curves=curve)
    assert len(cfs) > 0


def test_solver_integration(curve):
    """AssetSwap can be used as a Solver instrument."""
    from vade import Solver

    bond = FixedRateBond(
        effective=date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    asw = AssetSwap(bond=bond, asw_type="par")

    # AssetSwap should be accepted by Solver — format: (instrument, target_rate)
    solver = Solver(
        curves=[curve],
        instruments=[(asw, 0.005)],
    )
    # Solver construction should not error
    assert solver is not None


def test_invalid_bond_raises():
    """Non-bond object raises ValueError."""
    with pytest.raises(ValueError, match="bond must be"):
        AssetSwap(bond="not_a_bond", asw_type="par")


def test_repr(bond):
    """repr returns a string."""
    asw = AssetSwap(bond=bond, asw_type="par")
    assert repr(asw) == "AssetSwap(...)"
