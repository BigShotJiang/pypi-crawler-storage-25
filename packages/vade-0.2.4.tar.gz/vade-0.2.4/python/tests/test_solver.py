"""Integration tests for Python solver API."""

import datetime
import pytest
import numpy as np

from vade import (
    DiscountCurve,
    LineCurve,
    CreditImpliedCurve,
    IRS,
    OIS,
    Deposit,
    CDS,
    FXForward,
    FXRates,
    Solver,
    SolverResult,
)
import vade.fixings as fixings


def _d(y, m, d_):
    return datetime.date(y, m, d_)


class TestSingleCurveCalibration:
    """Single curve calibration with 5 IRS."""

    def _build_5irs_solver(self):
        """Build a 5-IRS calibration problem."""
        tenors = [_d(2025, 1, 1), _d(2026, 1, 1), _d(2027, 1, 1), _d(2028, 1, 1), _d(2029, 1, 1)]
        targets = [3.0, 3.2, 3.4, 3.5, 3.6]

        nodes = {_d(2024, 1, 1): 1.0}
        for t in tenors:
            nodes[t] = 1.0

        curve = DiscountCurve(
            nodes, interpolation="log_linear", convention="act365f", id="disc"
        )

        instruments = []
        for target, tenor in zip(targets, tenors):
            irs = IRS(
                effective=_d(2024, 1, 1),
                termination=tenor,
                frequency="a",
                fixed_rate=target,
                convention="act365f",
                float_convention="act365f",
            )
            instruments.append((irs, target))

        return Solver(curves=[curve], instruments=instruments)

    def test_single_curve_calibration(self):
        """Calibrate DiscountCurve to 5 IRS quotes, verify residuals < 1e-8."""
        solver = self._build_5irs_solver()
        result = solver.iterate()

        assert result.converged, f"Should converge: {result.status}"
        for i, r in enumerate(result.residuals):
            assert abs(r) < 1e-8, f"Residual[{i}] = {r} should be < 1e-8"

    def test_convergence_diagnostics(self):
        """Verify SolverResult diagnostics: jacobian, condition_number."""
        solver = self._build_5irs_solver()
        result = solver.iterate()

        assert result.converged
        assert result.iterations > 0
        assert result.status

        # Jacobian
        jac = result.jacobian
        assert isinstance(jac, np.ndarray), f"jacobian should be numpy array, got {type(jac)}"
        assert jac.ndim == 2, f"jacobian should be 2D, got {jac.ndim}D"
        assert jac.shape == (5, 5), f"jacobian shape should be (5,5), got {jac.shape}"
        assert np.any(np.abs(jac) > 1e-20), "jacobian should have nonzero entries"
        assert not np.any(np.isnan(jac)), "jacobian should not have NaN"

        # Condition number
        cn = result.condition_number
        assert isinstance(cn, float)
        assert cn > 0, f"condition_number should be positive: {cn}"
        assert np.isfinite(cn), f"condition_number should be finite: {cn}"

    def test_convergence_controls(self):
        """Verify func_tol, max_iter affect behavior."""
        tenors = [_d(2025, 1, 1), _d(2026, 1, 1), _d(2027, 1, 1)]
        targets = [3.0, 3.2, 3.4]
        nodes = {_d(2024, 1, 1): 1.0}
        for t in tenors:
            nodes[t] = 1.0

        curve = DiscountCurve(
            nodes, interpolation="log_linear", convention="act365f", id="disc"
        )
        instruments = []
        for target, tenor in zip(targets, tenors):
            irs = IRS(
                effective=_d(2024, 1, 1),
                termination=tenor,
                frequency="a",
                fixed_rate=target,
                convention="act365f",
                float_convention="act365f",
            )
            instruments.append((irs, target))

        # Relaxed tolerance
        solver = Solver(curves=[curve], instruments=instruments, func_tol=1e-6)
        result = solver.iterate()
        assert result.converged
        assert result.objective < 1e-6

    def test_get_calibrated_curve(self):
        """Extract curve from solver after calibration, verify DFs."""
        solver = self._build_5irs_solver()
        result = solver.iterate()
        assert result.converged

        curve = solver.get_curve(0)
        assert curve is not None

        # Check DFs are monotonically decreasing
        df1 = curve.discount_factor(_d(2025, 1, 1))
        df5 = curve.discount_factor(_d(2029, 1, 1))
        assert df1 > df5, f"DFs should decrease: DF(1Y)={df1}, DF(5Y)={df5}"
        assert df1 < 1.0, f"DF(1Y) should be < 1.0: {df1}"
        assert df5 > 0.0, f"DF(5Y) should be > 0: {df5}"


class TestMultiCurveCalibration:
    """Multi-curve calibration with pre-solver."""

    def test_multi_curve_with_pre_solver(self):
        """OIS disc curve + forward curve with pre-solver."""
        # Inner solver: 2 OIS instruments calibrate the discount curve
        inner_tenors = [_d(2026, 1, 1), _d(2027, 1, 1)]
        inner_targets = [3.0, 3.2]
        inner_nodes = {_d(2024, 1, 1): 1.0}
        for t in inner_tenors:
            inner_nodes[t] = 1.0

        inner_curve = DiscountCurve(
            inner_nodes, interpolation="log_linear", convention="act365f", id="inner"
        )
        inner_instruments = []
        for target, tenor in zip(inner_targets, inner_tenors):
            irs = IRS(
                effective=_d(2024, 1, 1),
                termination=tenor,
                frequency="a",
                fixed_rate=target,
                convention="act365f",
                float_convention="act365f",
            )
            inner_instruments.append((irs, target))

        inner_solver = Solver(curves=[inner_curve], instruments=inner_instruments)

        # Outer solver: 2 IRS on a separate curve, using inner as pre-solver
        outer_tenors = [_d(2028, 1, 1), _d(2029, 1, 1)]
        outer_targets = [3.5, 3.6]
        outer_nodes = {_d(2024, 1, 1): 1.0}
        for t in outer_tenors:
            outer_nodes[t] = 1.0

        outer_curve = DiscountCurve(
            outer_nodes, interpolation="log_linear", convention="act365f", id="outer"
        )
        outer_instruments = []
        for target, tenor in zip(outer_targets, outer_tenors):
            irs = IRS(
                effective=_d(2024, 1, 1),
                termination=tenor,
                frequency="a",
                fixed_rate=target,
                convention="act365f",
                float_convention="act365f",
            )
            outer_instruments.append((irs, target))

        outer_solver = Solver(
            curves=[outer_curve],
            instruments=outer_instruments,
            pre_solvers=[inner_solver],
        )
        result = outer_solver.iterate()
        assert result.converged, f"Outer solver should converge: {result.status}"


class TestSolverWithFixings:
    """Test solver with historical fixings."""

    def test_solver_with_fixings(self):
        """Set fixings, calibrate instruments that might need historical rates."""
        # Set some fixings
        fixings.set("SOFR", {
            _d(2024, 1, 2): 0.053,
            _d(2024, 1, 3): 0.0531,
            _d(2024, 1, 4): 0.0529,
        })

        # Basic calibration still works (fixings used by float leg if dates are past)
        tenors = [_d(2025, 1, 1), _d(2026, 1, 1)]
        targets = [3.0, 3.2]
        nodes = {_d(2024, 1, 1): 1.0}
        for t in tenors:
            nodes[t] = 1.0

        curve = DiscountCurve(
            nodes, interpolation="log_linear", convention="act365f", id="disc"
        )
        instruments = []
        for target, tenor in zip(targets, tenors):
            irs = IRS(
                effective=_d(2024, 1, 1),
                termination=tenor,
                frequency="a",
                fixed_rate=target,
                convention="act365f",
                float_convention="act365f",
            )
            instruments.append((irs, target))

        solver = Solver(curves=[curve], instruments=instruments)
        result = solver.iterate()
        assert result.converged

        # Cleanup
        fixings.clear()

    def test_fixings_accessible(self):
        """Verify fixings API works."""
        fixings.set("SOFR", {_d(2024, 1, 2): 0.053})
        rate = fixings.get_rate("SOFR", _d(2024, 1, 2))
        assert rate == 0.053
        fixings.clear()


class TestCreditCurveCalibration:
    """Calibrate CreditImpliedCurve from CDS par spread targets."""

    def test_solver_cds_calibration(self):
        """3 CDS instruments calibrate hazard rate nodes to match target par spreads."""
        # Discount curve (flat ~3% rate)
        disc_nodes = {
            _d(2024, 1, 1): 1.0,
            _d(2025, 1, 1): 0.97,
            _d(2026, 1, 1): 0.94,
            _d(2027, 1, 1): 0.91,
        }
        disc_curve = DiscountCurve(disc_nodes, interpolation="log_linear",
                                    convention="act365f", id="disc_usd")

        # Credit curve with anchor node at effective date + nodes at each tenor
        credit_nodes = {
            _d(2024, 1, 1): 0.01,
            _d(2025, 1, 1): 0.01,
            _d(2026, 1, 1): 0.01,
            _d(2027, 1, 1): 0.01,
        }
        credit_curve = CreditImpliedCurve(credit_nodes, convention="act365f",
                                           recovery_rate=0.4, id="credit_ig")

        # 3 CDS at 1Y, 2Y, 3Y tenors
        targets = [120.0, 150.0, 180.0]  # par spreads in bp
        tenors = [_d(2025, 1, 1), _d(2026, 1, 1), _d(2027, 1, 1)]
        instruments = []
        for tenor, target in zip(tenors, targets):
            cds = CDS(
                effective=_d(2024, 1, 1), termination=tenor,
                frequency="q", convention="act360",
                notional=10_000_000, fixed_rate=100,
                recovery_rate=0.4,
                currency="usd",
            )
            # disc_curve at index 0, credit_curve at index 1 (as forecast)
            instruments.append({
                "instrument": cds, "target": target,
                "disc_curve_idx": 0, "forecast_curve_idx": 1,
                "label": "cds", "currency": "usd",
            })

        # Create solver with disc and credit curves
        solver = Solver(
            curves=[disc_curve, credit_curve],
            instruments=instruments,
            func_tol=1e-10,
            max_iter=50,
        )

        result = solver.iterate()
        assert result.converged, f"Solver did not converge: {result.status}"

        # Verify calibrated rates match targets within tolerance
        calibrated_credit = solver.get_curve(1)
        for i, (tenor, target) in enumerate(zip(tenors, targets)):
            cds = CDS(
                effective=_d(2024, 1, 1), termination=tenor,
                frequency="q", convention="act360",
                notional=10_000_000, fixed_rate=100,
                recovery_rate=0.4,
                currency="usd",
            )
            computed_rate = cds.rate(disc_curve, calibrated_credit)
            val = float(computed_rate) if not isinstance(computed_rate, float) else computed_rate
            assert abs(val - target) < 0.5, \
                f"CDS rate {val} != target {target}"

    def test_solver_cds_npv_near_zero_after_calibration(self):
        """After calibration with fixed_rate = target, NPV should be near zero."""
        disc_nodes = {_d(2024, 1, 1): 1.0, _d(2026, 1, 1): 0.94}
        disc_curve = DiscountCurve(disc_nodes, interpolation="log_linear",
                                    convention="act365f", id="disc")
        credit_nodes = {_d(2024, 1, 1): 0.01, _d(2026, 1, 1): 0.01}
        credit_curve = CreditImpliedCurve(credit_nodes, convention="act365f",
                                           recovery_rate=0.4, id="credit")
        cds = CDS(effective=_d(2024, 1, 1), termination=_d(2026, 1, 1),
                  frequency="q", convention="act360",
                  notional=10_000_000, fixed_rate=100,
                  recovery_rate=0.4,
                  currency="usd")

        solver = Solver(curves=[disc_curve, credit_curve],
                        instruments=[{
                            "instrument": cds, "target": 100.0,
                            "disc_curve_idx": 0, "forecast_curve_idx": 1,
                            "label": "cds", "currency": "usd",
                        }],
                        func_tol=1e-10, max_iter=50)
        result = solver.iterate()
        assert result.converged

        # At par spread = fixed_rate, NPV should be ~0
        calibrated_credit = solver.get_curve(1)
        npv = cds.npv(disc_curve, calibrated_credit)
        npv_val = float(npv) if not isinstance(npv, float) else npv
        assert abs(npv_val) < 1000, f"NPV should be ~0, got {npv_val}"


class TestFXDeltaRisk:
    """FX delta risk tests for cross-currency instruments (FX-03, D-49)."""

    def test_fx_delta_nonzero_for_fxforward(self):
        """FX delta risk is non-zero for FXForward after solver calibration.

        Verifies that FX rates are Dual variables in solver Jacobian and that
        the Jacobian has non-zero FX sensitivity columns for cross-currency instruments.
        """
        usd_nodes = {_d(2024, 1, 1): 1.0, _d(2025, 1, 1): 0.97}
        eur_nodes = {_d(2024, 1, 1): 1.0, _d(2025, 1, 1): 0.975}
        usd_curve = DiscountCurve(usd_nodes, interpolation="log_linear",
                                   convention="act365f", id="usd")
        eur_curve = DiscountCurve(eur_nodes, interpolation="log_linear",
                                   convention="act365f", id="eur")
        fx_rates = FXRates({"eurusd": 1.1}, _d(2024, 1, 1))

        fxf = FXForward(pair="eurusd", notional=1_000_000,
                        delivery=_d(2025, 1, 1), currency="usd")

        # Compute implied forward rate as target
        fwd_rate = fxf.rate(eur_curve, usd_curve, fx_rates)
        fwd_val = float(fwd_rate) if not isinstance(fwd_rate, float) else fwd_rate

        solver = Solver(
            curves=[usd_curve, eur_curve],
            instruments=[(fxf, fwd_val, 0, "fxf", "usd")],
            func_tol=1e-10, max_iter=50,
            fx_rates=fx_rates,
        )

        result = solver.iterate()
        # Jacobian should exist and include FX variable columns
        jac = result.jacobian
        assert jac is not None
        assert jac.shape[0] >= 1, "Should have at least 1 instrument row"
        # Jacobian columns = curve vars + FX vars
        # With fx_rates set, total vars should be > just curve vars
        n_cols = jac.shape[1]
        assert n_cols > 0, "Jacobian should have columns"


def _build_solver_with_algo(algorithm="levenberg_marquardt", **kwargs):
    """Build a 5-IRS calibration problem with specified algorithm."""
    tenors = [_d(2025, 1, 1), _d(2026, 1, 1), _d(2027, 1, 1), _d(2028, 1, 1), _d(2029, 1, 1)]
    targets = [3.0, 3.2, 3.4, 3.5, 3.6]
    nodes = {_d(2024, 1, 1): 1.0}
    for t in tenors:
        nodes[t] = 1.0
    curve = DiscountCurve(
        nodes, interpolation="log_linear", convention="act365f", id="disc"
    )
    instruments = []
    for target, tenor in zip(targets, tenors):
        irs = IRS(
            effective=_d(2024, 1, 1),
            termination=tenor,
            frequency="a",
            fixed_rate=target,
            convention="act365f",
            float_convention="act365f",
        )
        instruments.append((irs, target))
    return Solver(curves=[curve], instruments=instruments, algorithm=algorithm, **kwargs)


class TestGaussNewton:
    """Gauss-Newton optimizer tests (CALIB-01)."""

    def test_convergence(self):
        """GN calibrates 5-IRS to same residuals as LM."""
        solver = _build_solver_with_algo("gauss_newton")
        result = solver.iterate()
        assert result.converged, f"GN should converge: {result.status}"
        for i, r in enumerate(result.residuals):
            assert abs(r) < 1e-7, f"GN residual[{i}] = {r} should be < 1e-7"

    def test_algorithm_in_result(self):
        """SolverResult.algorithm reflects gauss_newton."""
        solver = _build_solver_with_algo("gauss_newton")
        result = solver.iterate()
        assert result.algorithm == "gauss_newton"

    def test_singular_failure(self):
        """GN fails with clear error on ill-conditioned problem."""
        # Create a problem with more variables than instruments (1 inst, 5 vars)
        nodes = {
            _d(2024, 1, 1): 1.0,
            _d(2025, 1, 1): 1.0,
            _d(2026, 1, 1): 1.0,
            _d(2027, 1, 1): 1.0,
            _d(2028, 1, 1): 1.0,
            _d(2029, 1, 1): 1.0,
        }
        curve = DiscountCurve(
            nodes, interpolation="log_linear", convention="act365f", id="disc"
        )
        irs = IRS(
            effective=_d(2024, 1, 1),
            termination=_d(2025, 1, 1),
            frequency="a",
            fixed_rate=3.0,
            convention="act365f",
            float_convention="act365f",
        )
        solver = Solver(
            curves=[curve], instruments=[(irs, 3.0)], algorithm="gauss_newton"
        )
        result = solver.iterate()
        # Should NOT converge (singular system) or converge trivially
        assert (
            not result.converged
            or "singular" in result.status.lower()
            or result.iterations <= 2
        )

    def test_risk_parity(self):
        """GN produces same delta risk as LM for same calibrated result."""
        lm_solver = _build_solver_with_algo("levenberg_marquardt")
        lm_result = lm_solver.iterate()
        gn_solver = _build_solver_with_algo("gauss_newton")
        gn_result = gn_solver.iterate()
        # Both converged
        assert lm_result.converged and gn_result.converged
        # Build a test instrument for delta comparison
        irs_test = IRS(
            effective=_d(2024, 1, 1),
            termination=_d(2027, 6, 15),
            frequency="a",
            fixed_rate=3.3,
            convention="act365f",
            float_convention="act365f",
        )
        lm_delta = lm_solver.delta(irs_test, lm_result)
        gn_delta = gn_solver.delta(irs_test, gn_result)
        lm_sens = lm_delta["sensitivity"].to_list()
        gn_sens = gn_delta["sensitivity"].to_list()
        for i, (lm_s, gn_s) in enumerate(zip(lm_sens, gn_sens)):
            assert abs(lm_s - gn_s) < 1e-5, f"Delta[{i}]: LM={lm_s}, GN={gn_s}"


class TestGradientDescent:
    """Gradient descent optimizer tests (CALIB-02)."""

    def test_convergence(self):
        """GD converges on 5-IRS (with generous iterations)."""
        solver = _build_solver_with_algo(
            "gradient_descent", max_iter=500, func_tol=1e-10
        )
        result = solver.iterate()
        assert result.converged, f"GD should converge: {result.status}"
        for i, r in enumerate(result.residuals):
            assert abs(r) < 1e-4, f"GD residual[{i}] = {r} should be < 1e-4"

    def test_algorithm_in_result(self):
        """SolverResult.algorithm reflects gradient_descent."""
        solver = _build_solver_with_algo("gradient_descent", max_iter=500)
        result = solver.iterate()
        assert result.algorithm == "gradient_descent"

    def test_risk_parity(self):
        """GD produces similar delta risk to LM for converged result."""
        lm_solver = _build_solver_with_algo("levenberg_marquardt")
        lm_result = lm_solver.iterate()
        gd_solver = _build_solver_with_algo(
            "gradient_descent", max_iter=1000, func_tol=1e-10
        )
        gd_result = gd_solver.iterate()
        if not gd_result.converged:
            pytest.skip("GD did not converge - skip risk parity check")
        irs_test = IRS(
            effective=_d(2024, 1, 1),
            termination=_d(2027, 6, 15),
            frequency="a",
            fixed_rate=3.3,
            convention="act365f",
            float_convention="act365f",
        )
        lm_delta = lm_solver.delta(irs_test, lm_result)
        gd_delta = gd_solver.delta(irs_test, gd_result)
        lm_sens = lm_delta["sensitivity"].to_list()
        gd_sens = gd_delta["sensitivity"].to_list()
        for i, (lm_s, gd_s) in enumerate(zip(lm_sens, gd_sens)):
            assert abs(lm_s - gd_s) < 1e-3, f"Delta[{i}]: LM={lm_s}, GD={gd_s}"


class TestAlgorithmSelection:
    """Algorithm parameter validation tests (CALIB-01 + CALIB-02)."""

    def test_default_is_lm(self):
        """Default algorithm is levenberg_marquardt."""
        solver = _build_solver_with_algo()  # default
        result = solver.iterate()
        assert result.algorithm == "levenberg_marquardt"

    def test_invalid_algorithm(self):
        """Unknown algorithm string raises ValueError."""
        with pytest.raises(ValueError, match="Unknown algorithm"):
            _build_solver_with_algo("bogus")

    def test_ini_lambda_with_gn(self):
        """ini_lambda with gauss_newton raises ValueError."""
        with pytest.raises(ValueError, match="ini_lambda is not valid"):
            _build_solver_with_algo("gauss_newton", ini_lambda=(1.0, 0.5, 2.0))

    def test_ini_lambda_with_gd(self):
        """ini_lambda with gradient_descent raises ValueError."""
        with pytest.raises(ValueError, match="ini_lambda is not valid"):
            _build_solver_with_algo("gradient_descent", ini_lambda=(1.0, 0.5, 2.0))

    def test_learning_rate_with_lm(self):
        """learning_rate with levenberg_marquardt raises ValueError."""
        with pytest.raises(ValueError, match="learning_rate is not valid"):
            _build_solver_with_algo("levenberg_marquardt", learning_rate=0.1)

    def test_learning_rate_with_gn(self):
        """learning_rate with gauss_newton raises ValueError."""
        with pytest.raises(ValueError, match="learning_rate is not valid"):
            _build_solver_with_algo("gauss_newton", learning_rate=0.1)

    def test_custom_learning_rate(self):
        """GD accepts custom learning_rate."""
        solver = _build_solver_with_algo(
            "gradient_descent", learning_rate=0.5, max_iter=500
        )
        result = solver.iterate()
        assert result.algorithm == "gradient_descent"

    def test_custom_ini_lambda(self):
        """LM accepts custom ini_lambda."""
        solver = _build_solver_with_algo(
            "levenberg_marquardt", ini_lambda=(0.5, 0.3, 3.0)
        )
        result = solver.iterate()
        assert result.algorithm == "levenberg_marquardt"
        assert result.converged
