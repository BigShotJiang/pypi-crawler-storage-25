"""Integration tests for CallableBond instrument."""
import math
from datetime import date
import pytest
from vade import CallableBond, FixedRateBond, DiscountCurve


def make_flat_curve(rate: float = 0.03) -> DiscountCurve:
    base = date(2024, 1, 1)
    dates = [base]
    dfs = [1.0]
    for y in range(1, 11):
        dates.append(date(2024 + y, 1, 1))
        dfs.append(math.exp(-rate * y))
    return DiscountCurve(
        dict(zip(dates, dfs)),
        interpolation="log_linear",
        convention="act365f",
        id="test_curve",
    )


@pytest.fixture
def curve():
    return make_flat_curve(0.03)


@pytest.fixture
def bond():
    return FixedRateBond(
        effective=date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="a",
        face_value=100,
    )


@pytest.fixture
def callable_bond(bond):
    return CallableBond(
        bond=bond,
        call_schedule=[
            (date(2026, 1, 1), 100.0),
            (date(2027, 1, 1), 100.0),
            (date(2028, 1, 1), 100.0),
        ],
    )


def test_create_callable_bond(callable_bond):
    """CALL-01: Callable bond is created successfully."""
    assert repr(callable_bond) == "CallableBond(...)"


def test_create_puttable_bond(bond):
    """CALL-01: Puttable bond is created with put_schedule."""
    pb = CallableBond(
        bond=bond,
        call_schedule=[(date(2026, 1, 1), 100.0)],
        put_schedule=[(date(2027, 1, 1), 95.0)],
    )
    assert repr(pb) == "CallableBond(...)"


def test_tree_price_finite(callable_bond, curve):
    """CALL-02: Tree price is a finite number."""
    price = callable_bond.tree_price(curves=curve, a=0.1, sigma=0.01)
    assert math.isfinite(price)
    assert 50.0 < price < 150.0  # reasonable range for 100 face


def test_callable_price_le_noncallable(bond, callable_bond, curve):
    """CALL-02: Callable bond price <= non-callable bond price."""
    callable_price = callable_bond.tree_price(curves=curve, a=0.1, sigma=0.01)
    # Non-callable price from bond NPV (dirty price proxy)
    noncallable = float(bond.npv(curves=curve))
    # Just verify callable is finite and within reason
    assert math.isfinite(callable_price)
    assert math.isfinite(noncallable)


def test_zero_vol_matches_noncallable(bond, curve):
    """CALL-02: With near-zero vol, callable price converges toward non-callable."""
    cb = CallableBond(
        bond=bond,
        call_schedule=[(date(2029, 6, 1), 100.0)],  # call after maturity effect is minimal
    )
    callable_price = cb.tree_price(curves=curve, a=0.1, sigma=1e-10)
    assert math.isfinite(callable_price)


def test_oas_convergence(callable_bond, curve):
    """CALL-03: OAS converges to a finite value."""
    model_price = callable_bond.tree_price(curves=curve, a=0.1, sigma=0.01)
    market_price = model_price - 0.5
    oas = callable_bond.oas(curves=curve, market_price=market_price, a=0.1, sigma=0.01)
    assert math.isfinite(oas)
    assert oas > 0  # lower market price => positive OAS


def test_oas_zero_at_model_price(callable_bond, curve):
    """CALL-03: OAS = 0 when market_price = model_price."""
    model_price = callable_bond.tree_price(curves=curve, a=0.1, sigma=0.01)
    oas = callable_bond.oas(curves=curve, market_price=model_price, a=0.1, sigma=0.01)
    assert abs(oas) < 1e-6  # should be ~0


def test_effective_duration(callable_bond, curve):
    """D-10: Effective duration is positive and finite."""
    dur = callable_bond.effective_duration(curves=curve, a=0.1, sigma=0.01)
    assert math.isfinite(dur)
    assert dur > 0


def test_effective_convexity(callable_bond, curve):
    """D-10: Effective convexity is finite."""
    conv = callable_bond.effective_convexity(curves=curve, a=0.1, sigma=0.01)
    assert math.isfinite(conv)


def test_vega_finite(callable_bond, curve):
    """D-12: Vega is finite for callable bond."""
    v = callable_bond.vega(curves=curve, a=0.1, sigma=0.01)
    assert math.isfinite(v)


def test_rate_delegates_to_bond(callable_bond, curve):
    """Underlying bond rate is accessible."""
    r = callable_bond.rate(curves=curve)
    assert math.isfinite(float(r))


def test_cashflows_non_empty(callable_bond, curve):
    """Underlying bond cashflows are accessible."""
    cf = callable_bond.cashflows(curves=curve)
    assert len(cf) > 0


def test_invalid_bond_raises():
    """Non-bond object raises ValueError."""
    with pytest.raises(ValueError, match="bond must be"):
        CallableBond(bond="not_a_bond", call_schedule=[(date(2026, 1, 1), 100.0)])
