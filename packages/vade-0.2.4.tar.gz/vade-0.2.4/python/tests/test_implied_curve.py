"""Integration tests for IRImpliedCurve and bucket_delta."""

import datetime
import math

import pytest

from vade import DiscountCurve, IRImpliedCurve, FixedRateBond
from vade.calendar import BusinessCalendar


def make_flat_curve(rate: float = 0.03) -> DiscountCurve:
    """Create a flat discount curve for testing."""
    base = datetime.date(2024, 1, 1)
    dates = [base]
    dfs = [1.0]
    for y in range(1, 11):
        d = datetime.date(2024 + y, 1, 1)
        dates.append(d)
        dfs.append(math.exp(-rate * y))

    return DiscountCurve(
        dict(zip(dates, dfs)),
        interpolation="log_linear",
        convention="act365f",
        id="test_curve",
    )


def make_calendar() -> BusinessCalendar:
    """Create a simple business calendar."""
    return BusinessCalendar("NYC")


def test_ir_implied_curve_construction():
    """IRImpliedCurve can be constructed from a DiscountCurve with tenor list."""
    curve = make_flat_curve()
    cal = make_calendar()
    tenors = ["1Y", "2Y", "5Y", "10Y"]
    implied = IRImpliedCurve(curve, datetime.date(2024, 1, 1), tenors, cal)
    labels = implied.tenor_labels()
    assert labels == ["0D", "1Y", "2Y", "5Y", "10Y"]


def test_ir_implied_curve_discount_factor():
    """DF at tenor dates matches source curve."""
    curve = make_flat_curve(0.03)
    cal = make_calendar()
    tenors = ["1Y", "2Y", "5Y", "10Y"]
    implied = IRImpliedCurve(curve, datetime.date(2024, 1, 1), tenors, cal)

    # DF at 1Y should be close to exp(-0.03)
    df_1y = implied.discount_factor(datetime.date(2025, 1, 1))
    assert isinstance(df_1y, float)
    assert abs(df_1y - math.exp(-0.03)) < 0.01


def test_ir_implied_curve_interpolation():
    """DF at intermediate date is reasonable (between adjacent tenors)."""
    curve = make_flat_curve(0.03)
    cal = make_calendar()
    tenors = ["1Y", "2Y", "5Y", "10Y"]
    implied = IRImpliedCurve(curve, datetime.date(2024, 1, 1), tenors, cal)

    df_2y = implied.discount_factor(datetime.date(2026, 1, 1))
    df_3y = implied.discount_factor(datetime.date(2027, 1, 1))
    df_5y = implied.discount_factor(datetime.date(2029, 1, 1))

    # 3Y DF should be between 2Y and 5Y
    assert df_2y > df_3y > df_5y


def test_bucket_delta_returns_dataframe():
    """bucket_delta returns Polars DataFrame with correct columns."""
    import polars as pl

    curve = make_flat_curve(0.03)
    cal = make_calendar()
    tenors = ["1Y", "2Y", "5Y", "10Y"]
    implied = IRImpliedCurve(curve, datetime.date(2024, 1, 1), tenors, cal)

    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )

    df = implied.bucket_delta(bond)
    assert isinstance(df, pl.DataFrame)
    assert "tenor" in df.columns
    assert "date" in df.columns
    assert "delta" in df.columns


def test_bucket_delta_column_types():
    """tenor is str, date is date, delta is float."""
    import polars as pl

    curve = make_flat_curve(0.03)
    cal = make_calendar()
    tenors = ["1Y", "2Y", "5Y"]
    implied = IRImpliedCurve(curve, datetime.date(2024, 1, 1), tenors, cal)

    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="3Y",
        coupon=0.04,
        frequency="s",
    )

    df = implied.bucket_delta(bond)
    assert df["tenor"].dtype == pl.Utf8
    assert df["date"].dtype == pl.Date
    assert df["delta"].dtype == pl.Float64


def test_bucket_delta_nonzero():
    """Deltas are non-zero for non-trivial instruments."""
    curve = make_flat_curve(0.03)
    cal = make_calendar()
    tenors = ["1Y", "2Y", "5Y", "10Y"]
    implied = IRImpliedCurve(curve, datetime.date(2024, 1, 1), tenors, cal)

    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )

    df = implied.bucket_delta(bond)
    # At least some deltas should be non-zero
    deltas = df["delta"].to_list()
    assert any(abs(d) > 1e-12 for d in deltas), f"All deltas are zero: {deltas}"
