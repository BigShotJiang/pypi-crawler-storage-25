"""
Cashflow engine integration tests.

Validates all period and leg types through PyO3 bindings, including
NPV, analytic delta, cashflow DataFrame output, and AD propagation.
"""

import math
from datetime import date

import polars as pl
import pytest

from vade.autodiff import Dual
from vade.calendar import BusinessCalendar, Schedule
from vade.cashflows import (
    CashflowPeriod,
    CashflowRow,
    CustomLeg,
    FixedLeg,
    FixedPeriod,
    FloatLeg,
    FloatPeriod,
    IborPeriod,
    ZeroFixedLeg,
    ZeroFixedPeriod,
    ZeroFloatLeg,
    ZeroFloatPeriod,
    cashflows_to_pandas,
    cashflows_to_polars,
)
from vade.curves import DiscountCurve


# ---- Fixtures ----

@pytest.fixture
def cal():
    """Weekends-only business calendar."""
    return BusinessCalendar.new_custom([], [5, 6])


@pytest.fixture
def flat_curve():
    """Flat discount curve: DF ~ exp(-0.05 * t) via Act365F."""
    # Build nodes at 2024-01-01, 2025-01-01, 2026-01-01
    nodes = {
        date(2024, 1, 1): 1.0,
        date(2025, 1, 1): 0.95122942,  # exp(-0.05*1)
        date(2026, 1, 1): 0.90483742,  # exp(-0.05*2)
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f")


@pytest.fixture
def schedule_2y_semi(cal):
    """2Y semi-annual schedule from 2024-01-01 to 2026-01-01."""
    return Schedule(
        date(2024, 1, 1),
        date(2026, 1, 1),
        "S",
        cal,
    )


@pytest.fixture
def dual_curve():
    """DiscountCurve with Dual nodes for AD testing."""
    nodes = {
        date(2024, 1, 1): Dual("v0", 1.0),
        date(2025, 1, 1): Dual("v1", 0.95),
        date(2026, 1, 1): Dual("v2", 0.90),
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act365f")


# ---- TestFixedPeriod (PER-01) ----

class TestFixedPeriod:
    """PER-01: FixedPeriod NPV, analytic_delta, cashflow."""

    def test_npv(self, flat_curve):
        p = FixedPeriod(
            date(2024, 1, 1), date(2025, 1, 1), date(2025, 1, 1),
            1_000_000.0, 5.0, "act365f",
        )
        npv = p.npv(flat_curve)
        # NPV = -1M * (366/365) * 0.05 * DF(2025-01-01)
        dcf = 366.0 / 365.0  # 2024 is a leap year
        df = math.exp(-0.05 * 1.0)
        expected = -1_000_000.0 * dcf * 0.05 * df
        assert abs(npv - expected) < 1.0, f"NPV={npv}, expected={expected}"

    def test_analytic_delta(self, flat_curve):
        p = FixedPeriod(
            date(2024, 1, 1), date(2025, 1, 1), date(2025, 1, 1),
            1_000_000.0, 5.0, "act365f",
        )
        delta = p.analytic_delta(flat_curve)
        dcf = 366.0 / 365.0
        df = math.exp(-0.05 * 1.0)
        expected = -1_000_000.0 * dcf / 10000.0 * df
        assert abs(delta - expected) < 0.01, f"delta={delta}, expected={expected}"

    def test_cashflow(self):
        p = FixedPeriod(
            date(2024, 1, 1), date(2025, 1, 1), date(2025, 1, 1),
            1_000_000.0, 5.0, "act365f",
        )
        cf = p.cashflow()
        dcf = 366.0 / 365.0
        expected = -1_000_000.0 * dcf * 0.05
        assert abs(cf - expected) < 0.01

    def test_npv_with_dual_curve(self, dual_curve):
        p = FixedPeriod(
            date(2024, 1, 1), date(2025, 1, 1), date(2025, 1, 1),
            1_000_000.0, 5.0, "act365f",
        )
        npv = p.npv(dual_curve)
        # Should return a Dual with non-zero gradient
        assert isinstance(npv, Dual), f"Expected Dual, got {type(npv)}"
        assert npv.real != 0.0


# ---- TestFloatPeriod (PER-02) ----

class TestFloatPeriod:
    """PER-02: FloatPeriod NPV with RFR fixing methods."""

    def test_npv_payment_delay(self, flat_curve, cal):
        p = FloatPeriod(
            date(2024, 6, 3), date(2024, 9, 3), date(2024, 9, 3),
            1_000_000.0, cal, 0.0, "act360", "rfr_payment_delay",
        )
        npv = p.npv(flat_curve)
        assert isinstance(npv, float)
        assert npv < 0.0  # pay leg with positive rate

    def test_npv_with_fixings(self, flat_curve, cal):
        p = FloatPeriod(
            date(2024, 6, 3), date(2024, 6, 10), date(2024, 6, 10),
            1_000_000.0, cal, 0.0, "act360", "rfr_payment_delay",
        )
        # With fixings: override curve rates
        fixings = {
            date(2024, 6, 3): 5.0,  # percentage
            date(2024, 6, 4): 5.0,
            date(2024, 6, 5): 5.0,
            date(2024, 6, 6): 5.0,
            date(2024, 6, 7): 5.0,
        }
        npv = p.npv(flat_curve, fixings)
        assert isinstance(npv, float)
        assert npv != 0.0

    def test_npv_observation_shift(self, flat_curve, cal):
        p = FloatPeriod(
            date(2024, 6, 3), date(2024, 9, 3), date(2024, 9, 3),
            1_000_000.0, cal, 0.0, "act360", "rfr_observation_shift_5",
        )
        npv = p.npv(flat_curve)
        assert isinstance(npv, float)
        assert npv != 0.0


# ---- TestRFRFixingMethods (PER-06) ----

class TestRFRFixingMethods:
    """PER-06: All 8 FixingMethod variants produce sensible rates."""

    @pytest.mark.parametrize("method", [
        "rfr_payment_delay",
        "rfr_observation_shift",
        "rfr_lockout",
        "rfr_lookback",
        "rfr_payment_delay_average",
        "rfr_observation_shift_average",
        "rfr_lockout_average",
        "rfr_lookback_average",
    ])
    def test_all_methods_produce_rate(self, flat_curve, cal, method):
        p = FloatPeriod(
            date(2024, 6, 3), date(2024, 9, 3), date(2024, 9, 3),
            1_000_000.0, cal, 0.0, "act360", method,
        )
        rate = p.rate(flat_curve)
        assert isinstance(rate, float)
        assert rate > 0.0, f"Rate should be positive, got {rate}"

    def test_compound_vs_average(self, flat_curve, cal):
        p_comp = FloatPeriod(
            date(2024, 6, 3), date(2024, 9, 3), date(2024, 9, 3),
            1_000_000.0, cal, 0.0, "act360", "rfr_payment_delay",
        )
        p_avg = FloatPeriod(
            date(2024, 6, 3), date(2024, 9, 3), date(2024, 9, 3),
            1_000_000.0, cal, 0.0, "act360", "rfr_payment_delay_average",
        )
        r_comp = p_comp.rate(flat_curve)
        r_avg = p_avg.rate(flat_curve)
        # Compound rate >= average rate for positive rates
        assert r_comp >= r_avg - 1e-10, f"compound={r_comp} < average={r_avg}"


# ---- TestIborPeriod (PER-07) ----

class TestIborPeriod:
    """PER-07: IborPeriod fixing date resolution and NPV."""

    def test_fixing_date(self, cal):
        p = IborPeriod(
            date(2024, 1, 3), date(2024, 4, 3), date(2024, 4, 3),
            1_000_000.0, cal, 0.0, "act360", 2,
        )
        fix_date = p.fixing_date()
        # 2 business days before Wed Jan 3 = Mon Jan 1
        assert fix_date == date(2024, 1, 1)

    def test_npv_with_fixings(self, flat_curve, cal):
        p = IborPeriod(
            date(2024, 1, 3), date(2024, 4, 3), date(2024, 4, 3),
            1_000_000.0, cal, 0.0, "act360", 2,
        )
        fixings = {date(2024, 1, 1): 5.0}  # fixing at the fixing_date
        npv = p.npv(flat_curve, fixings)
        assert isinstance(npv, float)
        assert npv != 0.0

    def test_npv_from_curve(self, flat_curve, cal):
        p = IborPeriod(
            date(2024, 1, 3), date(2024, 4, 3), date(2024, 4, 3),
            1_000_000.0, cal, 0.0, "act360", 2,
        )
        npv = p.npv(flat_curve)
        assert isinstance(npv, float)
        assert npv < 0.0


# ---- TestZeroPeriods (PER-03) ----

class TestZeroPeriods:
    """PER-03: ZeroFixedPeriod and ZeroFloatPeriod NPV."""

    def test_zero_fixed_npv(self, flat_curve):
        p = ZeroFixedPeriod(
            date(2024, 1, 1), date(2025, 1, 1), date(2025, 1, 1),
            1_000_000.0, 5.0, "act365f",
        )
        npv = p.npv(flat_curve)
        assert isinstance(npv, float)
        # Cashflow = -1M * (1.05^dcf - 1)
        dcf = 366.0 / 365.0
        cf = -1_000_000.0 * (1.05 ** dcf - 1.0)
        df_val = math.exp(-0.05 * 1.0)
        expected = cf * df_val
        assert abs(npv - expected) < 1.0

    def test_zero_float_npv(self, flat_curve, cal):
        p = ZeroFloatPeriod(
            date(2024, 6, 3), date(2024, 9, 3), date(2024, 9, 3),
            1_000_000.0, cal, 0.0, "act360", "rfr_payment_delay",
        )
        npv = p.npv(flat_curve)
        assert isinstance(npv, float)
        assert npv != 0.0


# ---- TestCashflowPeriod (PER-04) ----

class TestCashflowPeriod:
    """PER-04: CashflowPeriod NPV = -notional * DF(payment)."""

    def test_npv(self, flat_curve):
        p = CashflowPeriod(date(2025, 1, 1), 1_000_000.0, "USD")
        npv = p.npv(flat_curve)
        df_val = math.exp(-0.05 * 1.0)
        expected = -1_000_000.0 * df_val
        assert abs(npv - expected) < 1.0

    def test_cashflow(self):
        p = CashflowPeriod(date(2025, 1, 1), 1_000_000.0, "USD")
        assert p.cashflow() == -1_000_000.0


# ---- TestFixedLeg (LEG-01) ----

class TestFixedLeg:
    """LEG-01: FixedLeg from Schedule with aggregate NPV and delta."""

    def test_from_schedule(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        assert leg.n_periods == 4  # 2Y semi = 4 periods

    def test_npv(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        npv = leg.npv(flat_curve)
        assert isinstance(npv, float)
        # NPV should be non-zero
        assert npv != 0.0

    def test_analytic_delta(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        delta = leg.analytic_delta(flat_curve)
        assert isinstance(delta, float)
        assert delta < 0.0  # pay leg, negative delta

    def test_cashflows_list(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        rows = leg.cashflows(flat_curve)
        assert len(rows) > 0
        assert all(isinstance(r, CashflowRow) for r in rows)


# ---- TestFloatLeg (LEG-02) ----

class TestFloatLeg:
    """LEG-02: FloatLeg from Schedule with RFR fixing method."""

    def test_from_schedule(self, flat_curve, schedule_2y_semi, cal):
        leg = FloatLeg(schedule_2y_semi, 1_000_000.0, cal, 0.0, "act360")
        assert leg.n_periods == 4

    def test_npv_with_fixings(self, flat_curve, schedule_2y_semi, cal):
        leg = FloatLeg(schedule_2y_semi, 1_000_000.0, cal, 0.0, "act360")
        # Pass a few fixings (won't cover everything but tests the path)
        fixings = {date(2024, 1, 2): 5.0, date(2024, 1, 3): 5.0}
        npv = leg.npv(flat_curve, fixings)
        assert isinstance(npv, float)
        assert npv != 0.0


# ---- TestZeroLegs (LEG-03) ----

class TestZeroLegs:
    """LEG-03: ZeroFixedLeg and ZeroFloatLeg single-period legs."""

    def test_zero_fixed_leg(self, flat_curve):
        leg = ZeroFixedLeg(
            date(2024, 1, 1), date(2025, 1, 1), date(2025, 1, 1),
            5.0, 1_000_000.0, "act365f",
        )
        npv = leg.npv(flat_curve)
        assert isinstance(npv, float)
        assert npv != 0.0

    def test_zero_float_leg(self, flat_curve, cal):
        leg = ZeroFloatLeg(
            date(2024, 6, 3), date(2024, 9, 3), date(2024, 9, 3),
            1_000_000.0, cal, 0.0, "act360",
        )
        npv = leg.npv(flat_curve)
        assert isinstance(npv, float)
        assert npv != 0.0


# ---- TestCustomLeg (LEG-05) ----

class TestCustomLeg:
    """LEG-05: CustomLeg with mixed period types."""

    def test_mixed_periods(self, flat_curve):
        periods = [
            FixedPeriod(
                date(2024, 1, 1), date(2024, 7, 1), date(2024, 7, 1),
                1_000_000.0, 5.0, "act365f",
            ),
            CashflowPeriod(date(2025, 1, 1), 500_000.0, "USD"),
        ]
        leg = CustomLeg(periods)
        npv = leg.npv(flat_curve)
        assert isinstance(npv, float)
        assert npv != 0.0
        rows = leg.cashflows(flat_curve)
        assert len(rows) == 2


# ---- TestAmortization (LEG-06) ----

class TestAmortization:
    """LEG-06: Amortization notional schedules and exchange periods."""

    def test_constant_amortization(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(
            schedule_2y_semi, 5.0, 1_000_000.0, "act365f",
            amortization="constant_250000",
        )
        rows = leg.cashflows(flat_curve)
        # Should have Fixed periods + Cashflow exchange periods
        fixed_rows = [r for r in rows if r.period_type == "Fixed"]
        assert len(fixed_rows) == 4
        # Notionals should decrease
        notionals = [r.notional for r in fixed_rows]
        for i in range(len(notionals) - 1):
            assert notionals[i] > notionals[i + 1] or abs(notionals[i] - notionals[i + 1]) < 1.0

    def test_percentage_amortization(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(
            schedule_2y_semi, 5.0, 1_000_000.0, "act365f",
            amortization="percentage_10.0",
        )
        rows = leg.cashflows(flat_curve)
        fixed_rows = [r for r in rows if r.period_type == "Fixed"]
        notionals = [r.notional for r in fixed_rows]
        # First notional is 1M, each subsequent is 90% of prior
        assert abs(notionals[0] - 1_000_000.0) < 1.0
        assert abs(notionals[1] - 900_000.0) < 1.0

    def test_custom_amortization(self, flat_curve, schedule_2y_semi):
        custom = [1_000_000.0, 800_000.0, 600_000.0, 400_000.0]
        leg = FixedLeg(
            schedule_2y_semi, 5.0, 1_000_000.0, "act365f",
            amortization=custom,
        )
        rows = leg.cashflows(flat_curve)
        fixed_rows = [r for r in rows if r.period_type == "Fixed"]
        notionals = [r.notional for r in fixed_rows]
        assert notionals == custom

    def test_notional_exchanges(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(
            schedule_2y_semi, 5.0, 1_000_000.0, "act365f",
            amortization="constant_250000",
        )
        rows = leg.cashflows(flat_curve)
        cf_rows = [r for r in rows if r.period_type == "Cashflow"]
        # Should have initial + intermediate exchanges + final
        assert len(cf_rows) >= 2  # at minimum initial + final


# ---- TestCashflowDataFrame (LEG-07) ----

class TestCashflowDataFrame:
    """LEG-07: Polars/pandas DataFrame output from leg.cashflows()."""

    def test_polars_output(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        rows = leg.cashflows(flat_curve)
        df = cashflows_to_polars(rows)
        assert isinstance(df, pl.DataFrame)
        # Check expected columns
        for col in ["Type", "start", "end", "payment", "Ccy", "Notional",
                     "fixing_rate", "Rate", "Spread", "DCF", "Cashflow",
                     "DF", "NPV"]:
            assert col in df.columns, f"Missing column: {col}"

    def test_without_curve(self, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        rows = leg.cashflows()  # no curve
        df = cashflows_to_polars(rows)
        assert isinstance(df, pl.DataFrame)
        # Without curve: no DF/NPV columns
        assert "DF" not in df.columns
        assert "NPV" not in df.columns

    def test_with_curve(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        rows = leg.cashflows(flat_curve)
        df = cashflows_to_polars(rows)
        assert "DF" in df.columns
        assert "NPV" in df.columns

    def test_to_pandas(self, flat_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        rows = leg.cashflows(flat_curve)
        pdf = cashflows_to_pandas(rows)
        assert len(pdf) > 0
        assert "NPV" in pdf.columns

    def test_ad_columns(self, dual_curve, schedule_2y_semi):
        leg = FixedLeg(schedule_2y_semi, 5.0, 1_000_000.0, "act365f")
        rows = leg.cashflows(dual_curve)
        df = cashflows_to_polars(rows)
        # AD values should produce Object columns for NPV
        assert df["NPV"].dtype == pl.Object
