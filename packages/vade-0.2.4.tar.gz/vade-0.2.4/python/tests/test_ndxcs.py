"""Test suite for NDXCS (Non-Deliverable Cross-Currency Swap).

Covers NDXCS-01 (construction, ND leg conversion), NDXCS-02 (notional exchanges),
NDXCS-03 (MTM resets), COMN-01 (AD), COMN-02 (JSON), COMN-03 (spread).
"""
import datetime
import math
import pytest

from vade import (
    NDXCS, DiscountCurve, FXRates, Dual,
)
from vade.instruments.specs import INSTRUMENT_SPECS


# ---- Fixtures ----

def _usd_curve():
    """USD discount curve (~4% flat)."""
    eff = datetime.date(2024, 6, 1)
    nodes = {
        eff: 1.0,
        datetime.date(2025, 6, 1): 0.9615,
        datetime.date(2026, 6, 1): 0.9246,
        datetime.date(2027, 6, 1): 0.8890,
        datetime.date(2029, 6, 1): 0.8219,
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act360", id="usd")


def _brl_curve():
    """BRL discount curve (~12% flat -- materially different from USD)."""
    eff = datetime.date(2024, 6, 1)
    nodes = {
        eff: 1.0,
        datetime.date(2025, 6, 1): 0.8929,
        datetime.date(2026, 6, 1): 0.7972,
        datetime.date(2027, 6, 1): 0.7118,
        datetime.date(2029, 6, 1): 0.5674,
    }
    return DiscountCurve(nodes, interpolation="log_linear", convention="act360", id="brl")


def _fx_rates():
    """FXRates with USDBRL = 5.0."""
    return FXRates({"usdbrl": 5.0}, settlement=datetime.date(2024, 6, 1))


def _make_ndxcs(**kwargs):
    """Create a standard NDXCS for testing."""
    defaults = dict(
        effective=datetime.date(2024, 6, 1),
        termination="2Y",
        leg1_currency="USD",
        leg2_currency="BRL",
        settlement_currency="usd",
        nd_leg=2,
        pair="usdbrl",
        leg1_notional=1_000_000.0,
        leg2_notional=5_000_000.0,
        initial_fx_rate=5.0,
        notional_exchange=True,
        convention="act360",
        frequency="q",
    )
    defaults.update(kwargs)
    return NDXCS(**defaults)


# ---- NDXCS-01: Basic construction and ND leg conversion ----

class TestNDXCSConstruction:
    def test_ndxcs_direct_construction(self):
        ndxcs = _make_ndxcs()
        assert ndxcs is not None

    def test_ndxcs_from_spec(self):
        ndxcs = NDXCS(
            spec="usdbrl_ndxcs",
            effective=datetime.date(2024, 6, 1),
            termination="2Y",
            leg1_notional=1_000_000.0,
            leg2_notional=5_000_000.0,
            initial_fx_rate=5.0,
        )
        assert ndxcs is not None

    def test_ndxcs_all_5_specs(self):
        for spec_name in ["usdbrl_ndxcs", "usdinr_ndxcs", "usdkrw_ndxcs", "usdcny_ndxcs", "usdtwd_ndxcs"]:
            ndxcs = NDXCS(
                spec=spec_name,
                effective=datetime.date(2024, 6, 1),
                termination="1Y",
                leg1_notional=1_000_000.0,
                leg2_notional=5_000_000.0,
                initial_fx_rate=5.0,
            )
            assert ndxcs is not None

    def test_ndxcs_repr(self):
        ndxcs = _make_ndxcs()
        r = repr(ndxcs)
        assert "NDXCS" in r

    def test_ndxcs_import(self):
        from vade import NDXCS as NDXCS_import
        assert NDXCS_import is NDXCS

    def test_ndxcs_specs_in_registry(self):
        for spec_name in ["usdbrl_ndxcs", "usdinr_ndxcs", "usdkrw_ndxcs", "usdcny_ndxcs", "usdtwd_ndxcs"]:
            assert spec_name in INSTRUMENT_SPECS


class TestNDXCSPricing:
    def test_ndxcs_rate_returns_finite(self):
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        rate = ndxcs.rate(usd, usd, brl, brl, fxr)
        val = float(rate)
        assert math.isfinite(val)

    def test_ndxcs_npv_returns_finite(self):
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv = ndxcs.npv(usd, usd, brl, brl, fxr)
        val = float(npv)
        assert math.isfinite(val)

    def test_ndxcs_spread_returns_finite(self):
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        spd = ndxcs.spread(usd, usd, brl, brl, fxr)
        val = float(spd)
        assert math.isfinite(val)

    def test_ndxcs_different_curves_different_result(self):
        """3-curve model produces materially different rate from 1-curve model."""
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        rate_3curve = float(ndxcs.rate(usd, usd, brl, brl, fxr))
        rate_1curve = float(ndxcs.rate(usd, usd, usd, usd, fxr))
        assert abs(rate_3curve - rate_1curve) > 1.0  # Materially different (>1bp)


# ---- NDXCS-02: Notional exchanges via FX fixings ----

class TestNDXCSNotionalExchange:
    def test_ndxcs_with_notional_exchange(self):
        ndxcs = _make_ndxcs(notional_exchange=True)
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv_with = float(ndxcs.npv(usd, usd, brl, brl, fxr))
        assert math.isfinite(npv_with)

    def test_ndxcs_without_notional_exchange(self):
        ndxcs = _make_ndxcs(notional_exchange=False)
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv_without = float(ndxcs.npv(usd, usd, brl, brl, fxr))
        assert math.isfinite(npv_without)

    def test_ndxcs_notional_exchange_affects_npv(self):
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv_with = float(_make_ndxcs(notional_exchange=True).npv(usd, usd, brl, brl, fxr))
        npv_without = float(_make_ndxcs(notional_exchange=False).npv(usd, usd, brl, brl, fxr))
        assert abs(npv_with - npv_without) > 100  # Notional exchanges have material impact


# ---- NDXCS-03: MTM resets on ND leg ----

class TestNDXCSMTMReset:
    def test_ndxcs_with_mtm_leg(self):
        ndxcs = _make_ndxcs(mtm_leg=2)
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv = float(ndxcs.npv(usd, usd, brl, brl, fxr))
        assert math.isfinite(npv)

    def test_ndxcs_mtm_with_fx_fixings(self):
        """MTM reset dates looked up in fx_fixings (per D-06)."""
        fx_fix = {datetime.date(2024, 9, 1): 5.2, datetime.date(2024, 12, 1): 5.4}
        ndxcs = _make_ndxcs(mtm_leg=2, fx_fixings=fx_fix)
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv = float(ndxcs.npv(usd, usd, brl, brl, fxr))
        assert math.isfinite(npv)


# ---- COMN-01: AD-enabled Number types ----

class TestNDXCSAD:
    def test_ndxcs_rate_ad_enabled(self):
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        rate = ndxcs.rate(usd, usd, brl, brl, fxr)
        # AD-enabled means it returns Dual (not just float)
        # FXRates creates Dual variables, so result should be Dual
        assert isinstance(rate, (float, Dual))

    def test_ndxcs_npv_ad_enabled(self):
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv = ndxcs.npv(usd, usd, brl, brl, fxr)
        assert isinstance(npv, (float, Dual))


# ---- COMN-02: JSON serialization ----

class TestNDXCSJSON:
    def test_ndxcs_to_json(self):
        ndxcs = _make_ndxcs()
        data = ndxcs.to_json()
        assert data["type"] == "NDXCS"
        assert data["settlement_currency"] == "usd"
        assert data["nd_leg"] == 2

    def test_ndxcs_json_roundtrip(self):
        fx_fix = {datetime.date(2024, 9, 1): 5.2}
        ndxcs = _make_ndxcs(fx_fixings=fx_fix)
        data = ndxcs.to_json()
        ndxcs2 = NDXCS.from_json(data)
        assert ndxcs2 is not None
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        npv1 = float(ndxcs.npv(usd, usd, brl, brl, fxr))
        npv2 = float(ndxcs2.npv(usd, usd, brl, brl, fxr))
        assert abs(npv1 - npv2) < 1e-6

    def test_ndxcs_json_fx_fixings_date_keyed(self):
        """fx_fixings serialized as date-keyed dict (per D-10)."""
        fx_fix = {datetime.date(2024, 9, 1): 5.2, datetime.date(2024, 12, 1): 5.4}
        ndxcs = _make_ndxcs(fx_fixings=fx_fix)
        data = ndxcs.to_json()
        assert "fx_fixings" in data
        assert "2024-09-01" in data["fx_fixings"]
        assert data["fx_fixings"]["2024-09-01"] == 5.2


# ---- COMN-03: spread() method ----

class TestNDXCSSpread:
    def test_ndxcs_spread_consistent_with_rate(self):
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        rate = float(ndxcs.rate(usd, usd, brl, brl, fxr))
        spd = float(ndxcs.spread(usd, usd, brl, brl, fxr))
        # For NDXCS, spread() and rate() should return the same value
        assert abs(rate - spd) < 1e-10


# ---- Cashflows ----

class TestNDXCSCashflows:
    def test_ndxcs_cashflows_returns_dataframe(self):
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        cf = ndxcs.cashflows(usd, usd, brl, brl, fxr)
        assert len(cf) > 0

    def test_ndxcs_cashflows_have_settlement_fields(self):
        """ND leg rows have settlement columns populated."""
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        cf = ndxcs.cashflows(usd, usd, brl, brl, fxr)
        # Check that Settlement_Ccy column exists for ND instrument
        cols = cf.columns
        assert "Settlement_Ccy" in cols

    def test_ndxcs_cashflows_nd_leg_has_fx_rate(self):
        """ND leg (BRL) rows should have FX rate info."""
        ndxcs = _make_ndxcs()
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()
        cf = ndxcs.cashflows(usd, usd, brl, brl, fxr)
        # Filter BRL rows -- they should have FX rate info
        if "FX_Rate" in cf.columns:
            import polars as pl
            ccy_col = "Ccy" if "Ccy" in cf.columns else "Currency"
            brl_rows = cf.filter(pl.col(ccy_col) == "BRL")
            if len(brl_rows) > 0:
                assert brl_rows["FX_Rate"].null_count() < len(brl_rows)


# ---- Known fixings ----

class TestNDXCSFixings:
    def test_ndxcs_known_fixing_affects_result(self):
        """Providing known FX fixings should produce different result than implied."""
        usd = _usd_curve()
        brl = _brl_curve()
        fxr = _fx_rates()

        ndxcs_no_fix = _make_ndxcs()
        ndxcs_with_fix = _make_ndxcs(fx_fixings={datetime.date(2024, 9, 1): 6.0})

        npv1 = float(ndxcs_no_fix.npv(usd, usd, brl, brl, fxr))
        npv2 = float(ndxcs_with_fix.npv(usd, usd, brl, brl, fxr))
        # They should differ since 6.0 is different from implied forward
        assert math.isfinite(npv1)
        assert math.isfinite(npv2)

    def test_ndxcs_pillar_date(self):
        ndxcs = _make_ndxcs()
        pd = ndxcs.pillar_date()
        assert pd > datetime.date(2024, 6, 1)
