"""Integration tests for root finders via internal import path."""

import pytest

from vade._vade_rs.numerical import brent_solve, newton_raphson_solve


def test_brent_solve_basic():
    """brent_solve finds root of x^2 - 4 = 0."""
    result = brent_solve(lambda x: x**2 - 4, 0, 5)
    assert abs(result - 2.0) < 1e-10


def test_newton_raphson_solve_basic():
    """newton_raphson_solve finds root of x^2 - 4 = 0."""
    result = newton_raphson_solve(lambda x: (x**2 - 4, 2 * x), 3.0)
    assert abs(result - 2.0) < 1e-10


def test_brent_solve_convergence_error():
    """Bad bracket (same sign at both ends) raises ValueError."""
    with pytest.raises(ValueError):
        brent_solve(lambda x: x**2 + 1, 0, 5)


def test_brent_solve_negative_root():
    """brent_solve can find negative roots."""
    result = brent_solve(lambda x: x**2 - 4, -5, 0)
    assert abs(result - (-2.0)) < 1e-10


def test_newton_raphson_solve_cos():
    """newton_raphson_solve finds root of cos(x) near pi/2."""
    import math
    result = newton_raphson_solve(lambda x: (math.cos(x), -math.sin(x)), 1.0)
    assert abs(result - math.pi / 2) < 1e-10
