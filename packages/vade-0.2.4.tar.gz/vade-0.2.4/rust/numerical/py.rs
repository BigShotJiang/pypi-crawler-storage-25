use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use super::{brent, newton_raphson};
use super::compounding;

/// Brent's method root finder for Python callables.
///
/// Finds x such that f(x) = 0, where f is a Python callable.
#[pyfunction]
#[pyo3(signature = (f, a, b, tol = 1e-12, max_iter = 200))]
fn brent_solve(py: Python<'_>, f: Py<PyAny>, a: f64, b: f64, tol: f64, max_iter: usize) -> PyResult<f64> {
    let result = brent(
        |x| {
            f.call1(py, (x,))
                .and_then(|r| r.extract::<f64>(py))
                .unwrap_or(f64::NAN)
        },
        a, b, tol, max_iter,
    );
    result.map_err(|e| PyValueError::new_err(e))
}

/// Newton-Raphson root finder for Python callables.
///
/// Finds x such that f(x) = 0, where f is a Python callable that returns (value, derivative).
#[pyfunction]
#[pyo3(signature = (f, x0, tol = 1e-12, max_iter = 200))]
fn newton_raphson_solve(py: Python<'_>, f: Py<PyAny>, x0: f64, tol: f64, max_iter: usize) -> PyResult<f64> {
    let result = newton_raphson(
        |x| {
            let result = f.call1(py, (x,)).unwrap();
            let tuple: (f64, f64) = result.extract(py).unwrap();
            tuple
        },
        x0, tol, max_iter,
    );
    result.map_err(|e| PyValueError::new_err(e))
}

/// Compute discount factor from rate, time, and compounding convention.
///
/// Args:
///     rate: Interest rate (e.g. 0.05 for 5%)
///     time: Time in years
///     compounding: One of "continuous", "annual", "semi_annual", "quarterly", "daily", "simple"
///
/// Returns:
///     Discount factor as float
#[pyfunction]
fn discount_factor(rate: f64, time: f64, compounding: &str) -> PyResult<f64> {
    compounding::discount_factor(rate, time, compounding)
        .map_err(|e| PyValueError::new_err(e))
}

/// Compute interest rate from discount factor, time, and compounding convention.
///
/// Args:
///     df: Discount factor
///     time: Time in years
///     compounding: One of "continuous", "annual", "semi_annual", "quarterly", "daily", "simple"
///
/// Returns:
///     Interest rate as float
#[pyfunction]
fn rate_from_df(df: f64, time: f64, compounding: &str) -> PyResult<f64> {
    compounding::rate_from_df(df, time, compounding)
        .map_err(|e| PyValueError::new_err(e))
}

/// Convert rate between compounding conventions.
///
/// Args:
///     rate: Interest rate in the source convention
///     time: Time in years
///     from_compounding: Source compounding convention
///     to_compounding: Target compounding convention
///
/// Returns:
///     Equivalent rate in the target convention
#[pyfunction]
fn convert_rate(rate: f64, time: f64, from_compounding: &str, to_compounding: &str) -> PyResult<f64> {
    compounding::convert_rate(rate, time, from_compounding, to_compounding)
        .map_err(|e| PyValueError::new_err(e))
}

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(brent_solve, m)?)?;
    m.add_function(wrap_pyfunction!(newton_raphson_solve, m)?)?;
    m.add_function(wrap_pyfunction!(discount_factor, m)?)?;
    m.add_function(wrap_pyfunction!(rate_from_df, m)?)?;
    m.add_function(wrap_pyfunction!(convert_rate, m)?)?;
    Ok(())
}
