/// Brent's method for 1D root finding.
///
/// Combines bisection, secant, and inverse quadratic interpolation
/// for robust and efficient root finding of continuous functions.
///
/// # Arguments
/// * `f` - Function whose root is sought
/// * `a` - Lower bracket bound
/// * `b` - Upper bracket bound
/// * `tol` - Convergence tolerance
/// * `max_iter` - Maximum number of iterations
///
/// # Returns
/// The root x such that |f(x)| < tol, or an error if no sign change or max_iter exceeded.
pub fn brent<F>(mut f: F, a: f64, b: f64, tol: f64, max_iter: usize) -> Result<f64, String>
where
    F: FnMut(f64) -> f64,
{
    let mut a = a;
    let mut b = b;
    let mut fa = f(a);
    let mut fb = f(b);

    if fa * fb > 0.0 {
        return Err("No sign change in bracket: f(a) and f(b) have the same sign".to_string());
    }

    if fa.abs() < fb.abs() {
        std::mem::swap(&mut a, &mut b);
        std::mem::swap(&mut fa, &mut fb);
    }

    let mut c = a;
    let mut fc = fa;
    let mut mflag = true;
    let mut d = b - a; // previous step size

    for _ in 0..max_iter {
        if fb.abs() < tol {
            return Ok(b);
        }
        if fa.abs() < tol {
            return Ok(a);
        }

        let s;
        if (fa - fc).abs() > 1e-30 && (fb - fc).abs() > 1e-30 {
            // Inverse quadratic interpolation
            s = a * fb * fc / ((fa - fb) * (fa - fc))
                + b * fa * fc / ((fb - fa) * (fb - fc))
                + c * fa * fb / ((fc - fa) * (fc - fb));
        } else {
            // Secant method
            s = b - fb * (b - a) / (fb - fa);
        }

        // Conditions to reject interpolation and use bisection instead
        let mid = (a + b) / 2.0;
        let cond1 = if a < b {
            s < (3.0 * a + b) / 4.0 || s > b
        } else {
            s > (3.0 * a + b) / 4.0 || s < b
        };
        let cond2 = mflag && (s - b).abs() >= (b - c).abs() / 2.0;
        let cond3 = !mflag && (s - b).abs() >= (c - d).abs() / 2.0;
        let cond4 = mflag && (b - c).abs() < tol;
        let cond5 = !mflag && (c - d).abs() < tol;

        let s = if cond1 || cond2 || cond3 || cond4 || cond5 {
            mflag = true;
            mid
        } else {
            mflag = false;
            s
        };

        let fs = f(s);
        d = c;
        c = b;
        fc = fb;

        if fa * fs < 0.0 {
            b = s;
            fb = fs;
        } else {
            a = s;
            fa = fs;
        }

        if fa.abs() < fb.abs() {
            std::mem::swap(&mut a, &mut b);
            std::mem::swap(&mut fa, &mut fb);
        }
    }

    if fb.abs() < tol {
        Ok(b)
    } else {
        Err(format!(
            "Brent's method did not converge after {} iterations (|f(b)|={:.2e})",
            max_iter,
            fb.abs()
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::PI;

    #[test]
    fn test_brent_sqrt2() {
        let result = brent(|x| x * x - 2.0, 1.0, 2.0, 1e-12, 100).unwrap();
        assert!(
            (result - std::f64::consts::SQRT_2).abs() < 1e-10,
            "Expected sqrt(2), got {}",
            result
        );
    }

    #[test]
    fn test_brent_sin() {
        let result = brent(|x| x.sin(), 3.0, 4.0, 1e-12, 100).unwrap();
        assert!(
            (result - PI).abs() < 1e-10,
            "Expected pi, got {}",
            result
        );
    }

    #[test]
    fn test_brent_no_sign_change() {
        let result = brent(|x| x * x + 1.0, 0.0, 1.0, 1e-12, 100);
        assert!(result.is_err(), "Should fail with no sign change");
    }

    #[test]
    fn test_brent_linear() {
        let result = brent(|x| 2.0 * x - 6.0, 0.0, 10.0, 1e-12, 100).unwrap();
        assert!(
            (result - 3.0).abs() < 1e-10,
            "Expected 3.0, got {}",
            result
        );
    }
}
