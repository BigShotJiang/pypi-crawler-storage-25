/// Shared interest-rate compounding conversion utilities.
///
/// Provides discount factor calculation, rate extraction from discount factors,
/// and rate conversion between compounding conventions.

/// Compute the discount factor for a given rate, time period, and compounding convention.
///
/// # Arguments
/// * `rate` - Interest rate (e.g. 0.05 for 5%)
/// * `time` - Time in years
/// * `compounding` - One of "continuous", "annual", "semi_annual", "quarterly", "daily", "simple"
///
/// # Returns
/// Discount factor as f64, or error for unknown convention.
pub fn discount_factor(rate: f64, time: f64, compounding: &str) -> Result<f64, String> {
    match compounding {
        "continuous" => Ok((-rate * time).exp()),
        "annual" => Ok((1.0 + rate).powf(-time)),
        "semi_annual" => Ok((1.0 + rate / 2.0).powf(-2.0 * time)),
        "quarterly" => Ok((1.0 + rate / 4.0).powf(-4.0 * time)),
        "daily" => Ok((1.0 + rate / 365.0).powf(-365.0 * time)),
        "simple" => Ok(1.0 / (1.0 + rate * time)),
        _ => Err(format!("Unknown compounding convention: '{}'", compounding)),
    }
}

/// Compute the interest rate from a discount factor, time period, and compounding convention.
///
/// Inverse of `discount_factor`.
///
/// # Arguments
/// * `df` - Discount factor
/// * `time` - Time in years
/// * `compounding` - One of "continuous", "annual", "semi_annual", "quarterly", "daily", "simple"
///
/// # Returns
/// Interest rate as f64, or error for unknown convention.
pub fn rate_from_df(df: f64, time: f64, compounding: &str) -> Result<f64, String> {
    match compounding {
        "continuous" => Ok(-df.ln() / time),
        "annual" => Ok(df.powf(-1.0 / time) - 1.0),
        "semi_annual" => Ok(2.0 * (df.powf(-1.0 / (2.0 * time)) - 1.0)),
        "quarterly" => Ok(4.0 * (df.powf(-1.0 / (4.0 * time)) - 1.0)),
        "daily" => Ok(365.0 * (df.powf(-1.0 / (365.0 * time)) - 1.0)),
        "simple" => Ok((1.0 / df - 1.0) / time),
        _ => Err(format!("Unknown compounding convention: '{}'", compounding)),
    }
}

/// Convert an interest rate from one compounding convention to another.
///
/// Two-step process: compute discount factor with the source convention,
/// then extract the rate using the target convention.
///
/// # Arguments
/// * `rate` - Interest rate in the source convention
/// * `time` - Time in years
/// * `from` - Source compounding convention
/// * `to` - Target compounding convention
///
/// # Returns
/// Equivalent rate in the target convention, or error for unknown convention.
pub fn convert_rate(rate: f64, time: f64, from: &str, to: &str) -> Result<f64, String> {
    let df = discount_factor(rate, time, from)?;
    rate_from_df(df, time, to)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_discount_factor_continuous() {
        let result = discount_factor(0.05, 1.0, "continuous").unwrap();
        let expected = (-0.05_f64).exp();
        assert!((result - expected).abs() < 1e-14, "continuous: got {}, expected {}", result, expected);
    }

    #[test]
    fn test_discount_factor_annual() {
        let result = discount_factor(0.05, 1.0, "annual").unwrap();
        let expected = 1.0 / 1.05;
        assert!((result - expected).abs() < 1e-14, "annual: got {}, expected {}", result, expected);
    }

    #[test]
    fn test_discount_factor_semi_annual() {
        let result = discount_factor(0.05, 1.0, "semi_annual").unwrap();
        let expected = (1.025_f64).powf(-2.0);
        assert!((result - expected).abs() < 1e-14, "semi_annual: got {}, expected {}", result, expected);
    }

    #[test]
    fn test_discount_factor_quarterly() {
        let result = discount_factor(0.05, 1.0, "quarterly").unwrap();
        let expected = (1.0125_f64).powf(-4.0);
        assert!((result - expected).abs() < 1e-14, "quarterly: got {}, expected {}", result, expected);
    }

    #[test]
    fn test_discount_factor_daily() {
        let result = discount_factor(0.05, 1.0, "daily").unwrap();
        let expected = (1.0 + 0.05 / 365.0_f64).powf(-365.0);
        assert!((result - expected).abs() < 1e-14, "daily: got {}, expected {}", result, expected);
    }

    #[test]
    fn test_discount_factor_simple() {
        let result = discount_factor(0.05, 2.0, "simple").unwrap();
        let expected = 1.0 / (1.0 + 0.05 * 2.0);
        assert!((result - expected).abs() < 1e-14, "simple: got {}, expected {}", result, expected);
    }

    #[test]
    fn test_discount_factor_multi_year() {
        let result = discount_factor(0.05, 2.5, "semi_annual").unwrap();
        let expected = (1.025_f64).powf(-5.0);
        assert!((result - expected).abs() < 1e-14, "semi_annual 2.5y: got {}, expected {}", result, expected);
    }

    #[test]
    fn test_discount_factor_unknown_convention() {
        let result = discount_factor(0.05, 1.0, "bad_string");
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("Unknown compounding convention"));
    }

    #[test]
    fn test_rate_from_df_continuous() {
        let df = (-0.05_f64).exp();
        let result = rate_from_df(df, 1.0, "continuous").unwrap();
        assert!((result - 0.05).abs() < 1e-14, "continuous rate_from_df: got {}", result);
    }

    #[test]
    fn test_rate_from_df_annual() {
        let df = 1.0 / 1.05;
        let result = rate_from_df(df, 1.0, "annual").unwrap();
        assert!((result - 0.05).abs() < 1e-14, "annual rate_from_df: got {}", result);
    }

    #[test]
    fn test_rate_from_df_roundtrip_all_conventions() {
        let rate = 0.05;
        let time = 1.0;
        for conv in &["continuous", "annual", "semi_annual", "quarterly", "daily", "simple"] {
            let df = discount_factor(rate, time, conv).unwrap();
            let recovered = rate_from_df(df, time, conv).unwrap();
            // "daily" has slightly lower precision due to 365 frequency
            let tol = if *conv == "daily" { 1e-12 } else { 1e-14 };
            assert!(
                (recovered - rate).abs() < tol,
                "roundtrip {} failed: got {}, expected {}",
                conv, recovered, rate
            );
        }
    }

    #[test]
    fn test_convert_rate_roundtrip_continuous_semi_annual() {
        let original = 0.05;
        let converted = convert_rate(original, 1.0, "continuous", "semi_annual").unwrap();
        let back = convert_rate(converted, 1.0, "semi_annual", "continuous").unwrap();
        assert!(
            (back - original).abs() < 1e-15,
            "roundtrip continuous<->semi_annual: got {}, expected {}",
            back, original
        );
    }

    #[test]
    fn test_convert_rate_roundtrip_semi_annual_annual() {
        let original = 0.05;
        let converted = convert_rate(original, 1.0, "semi_annual", "annual").unwrap();
        let back = convert_rate(converted, 1.0, "annual", "semi_annual").unwrap();
        assert!(
            (back - original).abs() < 1e-15,
            "roundtrip semi_annual<->annual: got {}, expected {}",
            back, original
        );
    }

    #[test]
    fn test_convert_rate_all_pairs() {
        let rate = 0.05;
        let time = 1.0;
        // Exclude "simple" since its conversion is time-dependent in a different way
        let conventions = ["continuous", "annual", "semi_annual", "quarterly", "daily"];
        for from in &conventions {
            for to in &conventions {
                let converted = convert_rate(rate, time, from, to).unwrap();
                let back = convert_rate(converted, time, to, from).unwrap();
                // "daily" conversions have slightly lower precision
                let tol = if *from == "daily" || *to == "daily" { 1e-12 } else { 1e-14 };
                assert!(
                    (back - rate).abs() < tol,
                    "roundtrip {}->{} failed: got {}, expected {}",
                    from, to, back, rate
                );
            }
        }
    }

    #[test]
    fn test_rate_from_df_unknown_convention() {
        let result = rate_from_df(0.95, 1.0, "bad");
        assert!(result.is_err());
    }

    #[test]
    fn test_convert_rate_unknown_convention() {
        let result = convert_rate(0.05, 1.0, "continuous", "bad");
        assert!(result.is_err());
        let result = convert_rate(0.05, 1.0, "bad", "continuous");
        assert!(result.is_err());
    }
}
