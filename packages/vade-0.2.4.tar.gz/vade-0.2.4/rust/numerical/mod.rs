pub mod brent;
pub mod compounding;
pub mod newton;
pub mod py;

pub use brent::brent;
pub use newton::newton_raphson;
