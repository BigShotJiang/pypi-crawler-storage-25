/// Newton-Raphson method for 1D root finding.
///
/// Uses the iteration x_{n+1} = x_n - f(x_n) / f'(x_n).
///
/// # Arguments
/// * `f` - Function returning (value, derivative) at a point
/// * `x0` - Initial guess
/// * `tol` - Convergence tolerance
/// * `max_iter` - Maximum number of iterations
///
/// # Returns
/// The root x such that |f(x)| < tol, or an error.
pub fn newton_raphson<F>(f: F, x0: f64, tol: f64, max_iter: usize) -> Result<f64, String>
where
    F: Fn(f64) -> (f64, f64),
{
    let mut x = x0;

    for _ in 0..max_iter {
        let (fx, dfx) = f(x);

        if fx.abs() < tol {
            return Ok(x);
        }

        if dfx.abs() < 1e-30 {
            return Err(format!(
                "Newton-Raphson: zero derivative at x={:.6e} (f={:.6e}, f'={:.6e})",
                x, fx, dfx
            ));
        }

        let x_new = x - fx / dfx;

        if x_new.abs() > 1e15 {
            return Err(format!(
                "Newton-Raphson: diverged at x={:.6e} (x_new={:.6e})",
                x, x_new
            ));
        }

        x = x_new;
    }

    let (fx, _) = f(x);
    if fx.abs() < tol {
        Ok(x)
    } else {
        Err(format!(
            "Newton-Raphson did not converge after {} iterations (|f(x)|={:.2e})",
            max_iter,
            fx.abs()
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_newton_sqrt2() {
        let result = newton_raphson(|x| (x * x - 2.0, 2.0 * x), 1.5, 1e-12, 100).unwrap();
        assert!(
            (result - std::f64::consts::SQRT_2).abs() < 1e-10,
            "Expected sqrt(2), got {}",
            result
        );
    }

    #[test]
    fn test_newton_cubic() {
        let result =
            newton_raphson(|x| (x * x * x - 1.0, 3.0 * x * x), 0.5, 1e-12, 100).unwrap();
        assert!(
            (result - 1.0).abs() < 1e-10,
            "Expected 1.0, got {}",
            result
        );
    }

    #[test]
    fn test_newton_converges_fast() {
        // Newton should converge in well under 10 iterations for well-conditioned problems.
        // We verify by setting max_iter=10 and confirming convergence.
        let result = newton_raphson(
            |x| (x * x - 2.0, 2.0 * x),
            1.5,
            1e-12,
            10,
        )
        .unwrap();
        assert!(
            (result - std::f64::consts::SQRT_2).abs() < 1e-10,
            "Should converge to sqrt(2) in < 10 iterations"
        );
    }
}
