// Curve transformation functions: shift, translate, roll.
//
// All transformations return new curve objects without modifying the original
// (immutable/functional style per D-05).
//
// Supported curve types (D-06):
// - DiscountCurve
// - LineCurve
// - CompositeCurve
// - FXImpliedCurve
// - CreditImpliedCurve

use chrono::Duration;
use indexmap::IndexMap;

use crate::autodiff::enums::Number;
use crate::calendar::convention::DcfOptions;
use crate::marketcurves::composite::{CompositeCurve, CompositeCurveType};
use crate::marketcurves::credit::CreditImpliedCurve;
use crate::marketcurves::curve::{CurveQuery, DiscountCurve, LineCurve};
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::fx_implied::FXImpliedCurve;

// =============================================================================
// Shift: parallel bump by basis points (D-07: input is basis points)
// =============================================================================

/// Shift a DiscountCurve by `bp` basis points.
///
/// The zero rate at every tenor increases by `bp/10000`. This translates to
/// multiplying each discount factor by `exp(-shift_decimal * dcf)`.
pub fn shift_discount_curve(curve: &DiscountCurve, bp: f64) -> DiscountCurve {
    let shift_decimal = bp / 10_000.0;
    let base_date = curve.nodes.first_key();
    let keys = curve.nodes.keys();
    let values = curve.nodes.get_values_f64();

    let mut new_map = IndexMap::new();
    for (date, df_value) in keys.iter().zip(values.iter()) {
        let dcf = curve
            .convention
            .dcf(base_date, *date, &DcfOptions::default())
            .unwrap_or(0.0);
        let new_df = if dcf.abs() < 1e-14 {
            *df_value // base date node: keep DF = 1.0
        } else {
            df_value * (-shift_decimal * dcf).exp()
        };
        new_map.insert(*date, new_df);
    }

    DiscountCurve::new(
        Nodes::from_f64_map(new_map),
        curve.interpolator.clone(),
        curve.convention,
        curve.id.clone(),
    )
}

/// Shift a LineCurve by `bp` basis points.
///
/// Each node value (rate) increases by `bp/10000`.
pub fn shift_line_curve(curve: &LineCurve, bp: f64) -> LineCurve {
    let shift_decimal = bp / 10_000.0;
    let keys = curve.nodes.keys();
    let values = curve.nodes.get_values_f64();

    let mut new_map = IndexMap::new();
    for (date, val) in keys.iter().zip(values.iter()) {
        new_map.insert(*date, val + shift_decimal);
    }

    LineCurve::new(
        Nodes::from_f64_map(new_map),
        curve.interpolator.clone(),
        curve.convention,
        curve.id.clone(),
    )
}

/// Shift a CompositeCurve by `bp` basis points.
///
/// Applies shift to each component curve.
pub fn shift_composite_curve(curve: &CompositeCurve, bp: f64) -> CompositeCurve {
    match &curve.curves {
        CompositeCurveType::Discount(curves) => {
            let shifted: Vec<DiscountCurve> =
                curves.iter().map(|c| shift_discount_curve(c, bp)).collect();
            CompositeCurve::new_discount(shifted, curve.id.clone())
        }
        CompositeCurveType::Line(curves) => {
            let shifted: Vec<LineCurve> =
                curves.iter().map(|c| shift_line_curve(c, bp)).collect();
            CompositeCurve::new_line(shifted, curve.id.clone())
        }
    }
}

/// Shift an FXImpliedCurve by `bp` basis points.
///
/// Applies shift to the cashflow_curve component.
pub fn shift_fx_implied_curve(curve: &FXImpliedCurve, bp: f64) -> FXImpliedCurve {
    let shifted_cashflow = shift_discount_curve(&curve.cashflow_curve, bp);
    FXImpliedCurve::new(
        curve.cashflow_ccy.clone(),
        curve.collateral_ccy.clone(),
        curve.fx_rates.clone(),
        curve.fx_settlements.clone(),
        curve.collateral_curve.clone(),
        shifted_cashflow,
        curve.id.clone(),
    )
}

/// Shift a CreditImpliedCurve by `bp` basis points.
///
/// Each hazard rate node increases by `bp/10000`.
pub fn shift_credit_curve(curve: &CreditImpliedCurve, bp: f64) -> CreditImpliedCurve {
    let shift_decimal = bp / 10_000.0;
    let keys = curve.nodes.keys();
    let values = curve.nodes.get_values_f64();

    let mut new_map = IndexMap::new();
    for (date, val) in keys.iter().zip(values.iter()) {
        new_map.insert(*date, val + shift_decimal);
    }

    CreditImpliedCurve::new(
        Nodes::from_f64_map(new_map),
        curve.convention,
        curve.recovery_rate,
        curve.id.clone(),
    )
}

// =============================================================================
// Translate: shift valuation date forward by N days
// =============================================================================

/// Translate a DiscountCurve: shift all node dates forward by `days`.
///
/// Values stay the same; only dates move.
pub fn translate_discount_curve(curve: &DiscountCurve, days: i64) -> DiscountCurve {
    let keys = curve.nodes.keys();
    let values = curve.nodes.get_values_f64();
    let delta = Duration::days(days);

    let mut new_map = IndexMap::new();
    for (date, val) in keys.iter().zip(values.iter()) {
        new_map.insert(*date + delta, *val);
    }

    DiscountCurve::new(
        Nodes::from_f64_map(new_map),
        curve.interpolator.clone(),
        curve.convention,
        curve.id.clone(),
    )
}

/// Translate a LineCurve: shift all node dates forward by `days`.
pub fn translate_line_curve(curve: &LineCurve, days: i64) -> LineCurve {
    let keys = curve.nodes.keys();
    let values = curve.nodes.get_values_f64();
    let delta = Duration::days(days);

    let mut new_map = IndexMap::new();
    for (date, val) in keys.iter().zip(values.iter()) {
        new_map.insert(*date + delta, *val);
    }

    LineCurve::new(
        Nodes::from_f64_map(new_map),
        curve.interpolator.clone(),
        curve.convention,
        curve.id.clone(),
    )
}

/// Translate a CreditImpliedCurve: shift all node dates forward by `days`.
pub fn translate_credit_curve(curve: &CreditImpliedCurve, days: i64) -> CreditImpliedCurve {
    let keys = curve.nodes.keys();
    let values = curve.nodes.get_values_f64();
    let delta = Duration::days(days);

    let mut new_map = IndexMap::new();
    for (date, val) in keys.iter().zip(values.iter()) {
        new_map.insert(*date + delta, *val);
    }

    CreditImpliedCurve::new(
        Nodes::from_f64_map(new_map),
        curve.convention,
        curve.recovery_rate,
        curve.id.clone(),
    )
}

/// Translate a CompositeCurve: translate each component curve.
pub fn translate_composite_curve(curve: &CompositeCurve, days: i64) -> CompositeCurve {
    match &curve.curves {
        CompositeCurveType::Discount(curves) => {
            let translated: Vec<DiscountCurve> =
                curves.iter().map(|c| translate_discount_curve(c, days)).collect();
            CompositeCurve::new_discount(translated, curve.id.clone())
        }
        CompositeCurveType::Line(curves) => {
            let translated: Vec<LineCurve> =
                curves.iter().map(|c| translate_line_curve(c, days)).collect();
            CompositeCurve::new_line(translated, curve.id.clone())
        }
    }
}

/// Translate an FXImpliedCurve: translate each component curve.
pub fn translate_fx_implied_curve(curve: &FXImpliedCurve, days: i64) -> FXImpliedCurve {
    let translated_cashflow = translate_discount_curve(&curve.cashflow_curve, days);
    let translated_collateral = translate_discount_curve(&curve.collateral_curve, days);
    FXImpliedCurve::new(
        curve.cashflow_ccy.clone(),
        curve.collateral_ccy.clone(),
        curve.fx_rates.clone(),
        curve.fx_settlements.clone(),
        translated_collateral,
        translated_cashflow,
        curve.id.clone(),
    )
}

// =============================================================================
// Roll: produce curve as if valued at a future date using today's forward rates
// =============================================================================

/// Roll a DiscountCurve forward by `days`.
///
/// The rolled curve has `roll_date = base + days` as its new base date.
/// For each original node date after roll_date, the new DF is the forward DF:
///   new_df(date) = original_df(date) / original_df(roll_date)
///
/// Uses the curve's interpolation to get DF at roll_date.
pub fn roll_discount_curve(curve: &DiscountCurve, days: i64) -> DiscountCurve {
    let base_date = curve.nodes.first_key();
    let roll_date = base_date + Duration::days(days);

    // Get DF at roll_date via interpolation
    let df_roll = match curve.discount_factor(roll_date) {
        Number::F64(v) => v,
        Number::Dual(d) => d.real(),
        Number::Dual2(d) => d.real(),
    };

    let keys = curve.nodes.keys();
    let values = curve.nodes.get_values_f64();

    let mut new_map = IndexMap::new();
    // Insert roll_date as the new base with DF = 1.0
    new_map.insert(roll_date, 1.0);

    // Add forward DFs for all original nodes after roll_date
    for (date, df_value) in keys.iter().zip(values.iter()) {
        if *date > roll_date {
            let fwd_df = df_value / df_roll;
            new_map.insert(*date, fwd_df);
        }
    }

    DiscountCurve::new(
        Nodes::from_f64_map(new_map),
        curve.interpolator.clone(),
        curve.convention,
        curve.id.clone(),
    )
}

/// Roll a LineCurve forward by `days`.
///
/// Computes forward rates at shifted maturities from the original curve.
/// The rolled curve base becomes `base + days`, and rates are recomputed
/// as forward rates from the original curve.
pub fn roll_line_curve(curve: &LineCurve, days: i64) -> LineCurve {
    let base_date = curve.nodes.first_key();
    let roll_date = base_date + Duration::days(days);

    let keys = curve.nodes.keys();

    let mut new_map = IndexMap::new();

    // For the roll_date itself, use the forward rate starting at roll_date
    // For each original node after roll_date, compute forward rate from roll_date to that node
    for date in &keys {
        if *date > roll_date {
            // Forward rate from roll_date to this date
            let fwd = curve.forward_rate(roll_date, *date);
            let fwd_f64 = match fwd {
                Number::F64(v) => v,
                Number::Dual(d) => d.real(),
                Number::Dual2(d) => d.real(),
            };
            new_map.insert(*date, fwd_f64);
        }
    }

    // Insert rate at roll_date (the interpolated value at roll_date from original)
    if new_map.is_empty() || !new_map.contains_key(&roll_date) {
        // Use the forward rate from the original curve's base to roll_date as the starting rate
        let rate_at_roll = match curve.zero_rate(base_date, roll_date) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real(),
            Number::Dual2(d) => d.real(),
        };
        new_map.insert(roll_date, rate_at_roll);
    }

    // Sort by date
    new_map.sort_keys();

    LineCurve::new(
        Nodes::from_f64_map(new_map),
        curve.interpolator.clone(),
        curve.convention,
        curve.id.clone(),
    )
}

#[cfg(test)]
mod tests {
    use chrono::NaiveDate;
    use indexmap::IndexMap;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::curve::{CurveQuery, DiscountCurve, LineCurve};
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::composite::{CompositeCurve, CompositeCurveType};
    use crate::marketcurves::credit::CreditImpliedCurve;
    use crate::calendar::convention::DayCountConvention;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn discount_curve_fixture() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test_dc".to_string(),
        )
    }

    fn line_curve_fixture() -> LineCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.035),
            (ymd(2026, 1, 1), 0.04),
        ]));
        LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "test_lc".to_string(),
        )
    }

    fn credit_curve_fixture() -> CreditImpliedCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.02),
        ]));
        CreditImpliedCurve::new(
            nodes,
            DayCountConvention::Act365F,
            0.40,
            "test_credit".to_string(),
        )
    }

    // ---- Shift tests ----

    #[test]
    fn test_shift_discount_curve_10bp() {
        let curve = discount_curve_fixture();
        let shifted = super::shift_discount_curve(&curve, 10.0);

        // The zero rate at every tenor should increase by 10bp = 0.001
        let base = ymd(2024, 1, 1);
        let end = ymd(2025, 1, 1);

        let orig_rate = curve.zero_rate(base, end);
        let shifted_rate = shifted.zero_rate(base, end);

        if let (crate::autodiff::enums::Number::F64(o), crate::autodiff::enums::Number::F64(s)) = (orig_rate, shifted_rate) {
            let diff = s - o;
            assert!(
                (diff - 0.001).abs() < 1e-8,
                "Zero rate should increase by 0.001 (10bp), got diff={diff}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_shift_discount_curve_0bp() {
        let curve = discount_curve_fixture();
        let shifted = super::shift_discount_curve(&curve, 0.0);

        // Should return identical curve
        let orig_vals = curve.nodes.get_values_f64();
        let shifted_vals = shifted.nodes.get_values_f64();

        for (o, s) in orig_vals.iter().zip(shifted_vals.iter()) {
            assert!((o - s).abs() < 1e-12, "0bp shift should give identical DF: orig={o}, shifted={s}");
        }
    }

    #[test]
    fn test_shift_line_curve_10bp() {
        let curve = line_curve_fixture();
        let shifted = super::shift_line_curve(&curve, 10.0);

        let orig_vals = curve.nodes.get_values_f64();
        let shifted_vals = shifted.nodes.get_values_f64();

        for (o, s) in orig_vals.iter().zip(shifted_vals.iter()) {
            let diff = s - o;
            assert!(
                (diff - 0.001).abs() < 1e-12,
                "Each node should increase by 0.001 (10bp): orig={o}, shifted={s}"
            );
        }
    }

    #[test]
    fn test_shift_immutable_semantics() {
        let curve = discount_curve_fixture();
        let orig_vals = curve.nodes.get_values_f64().clone();

        let _shifted = super::shift_discount_curve(&curve, 50.0);

        // Original should be unchanged
        let after_vals = curve.nodes.get_values_f64();
        assert_eq!(orig_vals, after_vals, "Original curve must not be modified");
    }

    #[test]
    fn test_shift_basis_points_input() {
        // shift(10) should mean +10bp = +0.001 decimal
        let curve = line_curve_fixture();
        let shifted = super::shift_line_curve(&curve, 10.0);

        let orig_first = curve.nodes.get_values_f64()[0];
        let shifted_first = shifted.nodes.get_values_f64()[0];

        assert!(
            (shifted_first - orig_first - 0.001).abs() < 1e-12,
            "shift(10) should add 0.001 (10bp in decimal)"
        );
    }

    #[test]
    fn test_shift_composite_curve() {
        let c1 = discount_curve_fixture();
        let c2 = {
            let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
                (ymd(2024, 1, 1), 1.0),
                (ymd(2025, 1, 1), 0.99),
                (ymd(2026, 1, 1), 0.98),
            ]));
            DiscountCurve::new(nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "c2".to_string())
        };

        let composite = CompositeCurve::new_discount(vec![c1, c2], "comp".to_string());
        let shifted = super::shift_composite_curve(&composite, 10.0);

        // The shifted composite should have its component DFs adjusted
        match &shifted.curves {
            CompositeCurveType::Discount(curves) => {
                assert_eq!(curves.len(), 2, "Should still have 2 component curves");
            }
            _ => panic!("Expected Discount variant"),
        }
    }

    #[test]
    fn test_shift_credit_curve() {
        let curve = credit_curve_fixture();
        let shifted = super::shift_credit_curve(&curve, 10.0);

        let orig_vals = curve.nodes.get_values_f64();
        let shifted_vals = shifted.nodes.get_values_f64();

        for (o, s) in orig_vals.iter().zip(shifted_vals.iter()) {
            let diff = s - o;
            assert!(
                (diff - 0.001).abs() < 1e-12,
                "Credit hazard rate should increase by 0.001 (10bp): orig={o}, shifted={s}"
            );
        }
    }

    // ---- Translate tests ----

    #[test]
    fn test_translate_discount_curve() {
        let curve = discount_curve_fixture();
        let translated = super::translate_discount_curve(&curve, 30);

        let orig_dates = curve.nodes.keys();
        let trans_dates = translated.nodes.keys();

        for (o, t) in orig_dates.iter().zip(trans_dates.iter()) {
            let diff = (*t - *o).num_days();
            assert_eq!(diff, 30, "Each date should shift forward by 30 days");
        }

        // Values should remain the same
        let orig_vals = curve.nodes.get_values_f64();
        let trans_vals = translated.nodes.get_values_f64();
        assert_eq!(orig_vals, trans_vals);
    }

    #[test]
    fn test_translate_line_curve() {
        let curve = line_curve_fixture();
        let translated = super::translate_line_curve(&curve, 30);

        let orig_dates = curve.nodes.keys();
        let trans_dates = translated.nodes.keys();

        for (o, t) in orig_dates.iter().zip(trans_dates.iter()) {
            let diff = (*t - *o).num_days();
            assert_eq!(diff, 30, "Each date should shift forward by 30 days");
        }
    }

    // ---- Roll tests ----

    #[test]
    fn test_roll_discount_curve() {
        let curve = discount_curve_fixture();
        // Roll forward 90 days
        let rolled = super::roll_discount_curve(&curve, 90);

        // The rolled curve's base date should be 90 days forward
        let base = curve.nodes.first_key();
        let expected_base = base + chrono::Duration::days(90);
        let rolled_base = rolled.nodes.first_key();
        assert_eq!(rolled_base, expected_base, "Rolled curve base should be original + 90 days");

        // The first DF of the rolled curve should be 1.0
        let first_df = rolled.nodes.get_values_f64()[0];
        assert!((first_df - 1.0).abs() < 1e-12, "First DF should be 1.0");
    }

    #[test]
    fn test_roll_discount_curve_forward_df() {
        // Build a simple 2-node discount curve
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.96),
            (ymd(2026, 1, 1), 0.92),
        ]));
        let curve = DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "roll_test".to_string(),
        );

        // Roll forward 366 days (to 2025-01-01)
        let rolled = super::roll_discount_curve(&curve, 366);

        // After rolling to 2025-01-01, the only remaining node should be 2026-01-01
        // The rolled DF at 2026-01-01 should be DF(2026)/DF(2025) = 0.92/0.96
        let rolled_vals = rolled.nodes.get_values_f64();
        // Should have base (1.0) + remaining nodes after roll_date
        assert!(rolled_vals.len() >= 2, "Rolled curve should have at least 2 nodes");
        let fwd_df = rolled_vals[rolled_vals.len() - 1];
        let expected_fwd_df = 0.92 / 0.96;
        assert!(
            (fwd_df - expected_fwd_df).abs() < 1e-8,
            "Rolled DF should be forward DF: got={fwd_df}, expected={expected_fwd_df}"
        );
    }
}
