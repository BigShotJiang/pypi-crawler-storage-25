use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::autodiff::linalg::dsolve_f64;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::marketcurves::curve::CurveQuery;

/// Smith-Wilson parametric curve for regulatory yield curve extrapolation.
///
/// Used by EIOPA/Solvency II for risk-free rate term structure extrapolation.
/// The curve reproduces market discount factors exactly at input maturities
/// and converges to the ultimate forward rate (UFR) at long maturities.
///
/// Discount factor formula:
///   P(t) = exp(-UFR * t) + sum_j(zeta_j * W(t, u_j))
///
/// where W(t, u) is the Wilson kernel function and zeta coefficients are
/// calibrated to reproduce market discount factors.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SmithWilson {
    pub ufr: f64,
    pub alpha: f64,
    pub maturities: Vec<f64>,
    pub zeta: Vec<f64>,
    pub convention: DayCountConvention,
    pub base_date: NaiveDate,
    pub id: String,
}

/// Wilson kernel function.
///
/// W(t, u) = exp(-UFR * (t + u)) * (alpha * min(t,u) - exp(-alpha * max(t,u)) * sinh(alpha * min(t,u)))
pub fn wilson_kernel(t: f64, u: f64, ufr: f64, alpha: f64) -> f64 {
    let min_tu = t.min(u);
    let max_tu = t.max(u);
    let exp_ufr = (-ufr * (t + u)).exp();
    let sinh_term = (alpha * min_tu).sinh();
    let exp_alpha = (-alpha * max_tu).exp();
    exp_ufr * (alpha * min_tu - exp_alpha * sinh_term)
}

impl SmithWilson {
    /// Construct a SmithWilson curve from market data.
    ///
    /// # Arguments
    /// * `dates` - Market maturity dates
    /// * `rates` - Market zero rates (continuous compounding) at those dates
    /// * `ufr` - Ultimate forward rate (e.g., 0.033 for 3.3%)
    /// * `alpha` - Convergence speed parameter
    /// * `convention` - Day count convention for year fraction calculation
    /// * `base_date` - Curve base date
    /// * `id` - Curve identifier
    pub fn new(
        dates: Vec<NaiveDate>,
        rates: Vec<f64>,
        ufr: f64,
        alpha: f64,
        convention: DayCountConvention,
        base_date: NaiveDate,
        id: String,
    ) -> Self {
        assert_eq!(dates.len(), rates.len(), "dates and rates must have same length");
        assert!(!dates.is_empty(), "Must provide at least one market point");
        assert!(alpha > 0.0, "alpha must be positive");

        let n = dates.len();

        // Convert dates to maturities (year fractions)
        let maturities: Vec<f64> = dates.iter()
            .map(|d| convention.dcf(base_date, *d, &DcfOptions::default()).unwrap())
            .collect();

        // Compute market discount factors: P_market_j = exp(-rate_j * u_j)
        let p_market: Vec<f64> = rates.iter()
            .zip(maturities.iter())
            .map(|(r, u)| (-r * u).exp())
            .collect();

        // Build Wilson matrix W[i][j] = wilson_kernel(u_i, u_j, ufr, alpha)
        let w_matrix: Vec<Vec<f64>> = (0..n)
            .map(|i| {
                (0..n)
                    .map(|j| wilson_kernel(maturities[i], maturities[j], ufr, alpha))
                    .collect()
            })
            .collect();

        // RHS: m_j = P_market_j - exp(-ufr * u_j)
        let rhs: Vec<f64> = (0..n)
            .map(|j| p_market[j] - (-ufr * maturities[j]).exp())
            .collect();

        // Solve W * zeta = m
        let zeta = dsolve_f64(&w_matrix, &rhs);

        Self {
            ufr,
            alpha,
            maturities,
            zeta,
            convention,
            base_date,
            id,
        }
    }

    /// Compute the discount factor at a given year fraction t.
    fn discount_factor_at_t(&self, t: f64) -> f64 {
        if t <= 0.0 {
            return 1.0;
        }
        let base = (-self.ufr * t).exp();
        let correction: f64 = self.zeta.iter()
            .zip(self.maturities.iter())
            .map(|(z, u)| z * wilson_kernel(t, *u, self.ufr, self.alpha))
            .sum();
        base + correction
    }
}

impl CurveQuery for SmithWilson {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        let t = self.convention.dcf(self.base_date, date, &DcfOptions::default()).unwrap();
        Number::F64(self.discount_factor_at_t(t))
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        if dcf.abs() < 1e-14 {
            return Number::F64(0.0);
        }
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn sw_fixture() -> SmithWilson {
        let base = ymd(2024, 1, 1);
        let dates = vec![
            ymd(2025, 1, 1),  // 1Y
            ymd(2026, 1, 1),  // 2Y
            ymd(2027, 1, 1),  // 3Y
            ymd(2029, 1, 1),  // 5Y
            ymd(2034, 1, 1),  // 10Y
            ymd(2044, 1, 1),  // 20Y
        ];
        let rates = vec![0.03, 0.032, 0.034, 0.036, 0.038, 0.037];
        SmithWilson::new(
            dates,
            rates,
            0.033,   // UFR
            0.128,   // alpha
            DayCountConvention::Act365F,
            base,
            "sw_test".to_string(),
        )
    }

    // Test 1: SW reproduces market discount factors at input maturities
    #[test]
    fn test_sw_reproduces_market_dfs() {
        let base = ymd(2024, 1, 1);
        let dates = vec![
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
            ymd(2029, 1, 1),
            ymd(2034, 1, 1),
            ymd(2044, 1, 1),
        ];
        let rates = vec![0.03, 0.032, 0.034, 0.036, 0.038, 0.037];
        let sw = SmithWilson::new(
            dates.clone(),
            rates.clone(),
            0.033,
            0.128,
            DayCountConvention::Act365F,
            base,
            "sw_test".to_string(),
        );

        for (date, rate) in dates.iter().zip(rates.iter()) {
            let dcf = DayCountConvention::Act365F.dcf(base, *date, &DcfOptions::default()).unwrap();
            let expected_df = (-rate * dcf).exp();
            if let Number::F64(df) = sw.discount_factor(*date) {
                assert!(
                    (df - expected_df).abs() < 1e-6,
                    "DF mismatch at {:?}: got {}, expected {}", date, df, expected_df
                );
            } else {
                panic!("Expected F64");
            }
        }
    }

    // Test 2: SW discount_factor at t=0 returns 1.0
    #[test]
    fn test_sw_discount_factor_at_base_date() {
        let sw = sw_fixture();
        if let Number::F64(df) = sw.discount_factor(ymd(2024, 1, 1)) {
            assert!((df - 1.0).abs() < 1e-12, "Expected 1.0, got {}", df);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 3: SW at very long maturity converges toward exp(-UFR * t)
    #[test]
    fn test_sw_ufr_convergence() {
        let sw = sw_fixture();
        // At 100Y, the Wilson correction should be small relative to exp(-UFR * t)
        let date_100y = ymd(2124, 1, 1);
        let dcf = DayCountConvention::Act365F.dcf(ymd(2024, 1, 1), date_100y, &DcfOptions::default()).unwrap();
        let ufr_df = (-sw.ufr * dcf).exp();
        if let Number::F64(df) = sw.discount_factor(date_100y) {
            let relative_diff = ((df - ufr_df) / ufr_df).abs();
            assert!(
                relative_diff < 0.10,
                "At 100Y, SW DF={} should be close to UFR DF={}, relative diff={}",
                df, ufr_df, relative_diff
            );
        } else {
            panic!("Expected F64");
        }
    }

    // Test 4: SW zero_rate and forward_rate return positive values for positive UFR
    #[test]
    fn test_sw_positive_rates() {
        let sw = sw_fixture();
        let zr = sw.zero_rate(ymd(2024, 1, 1), ymd(2025, 1, 1));
        if let Number::F64(r) = zr {
            assert!(r > 0.0, "Zero rate should be positive, got {}", r);
        } else {
            panic!("Expected F64");
        }

        let fwd = sw.forward_rate(ymd(2025, 1, 1), ymd(2026, 1, 1));
        if let Number::F64(r) = fwd {
            assert!(r > 0.0, "Forward rate should be positive, got {}", r);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 5: Wilson kernel is symmetric: W(t, u) == W(u, t)
    #[test]
    fn test_wilson_kernel_symmetry() {
        let ufr = 0.033;
        let alpha = 0.128;
        let pairs = [(1.0, 3.0), (0.5, 10.0), (5.0, 5.0), (2.0, 7.0)];
        for (t, u) in pairs {
            let w_tu = wilson_kernel(t, u, ufr, alpha);
            let w_ut = wilson_kernel(u, t, ufr, alpha);
            assert!(
                (w_tu - w_ut).abs() < 1e-14,
                "Kernel not symmetric: W({},{})={} != W({},{})={}",
                t, u, w_tu, u, t, w_ut
            );
        }
    }

    // Test 6: Serde roundtrip for SmithWilson
    #[test]
    fn test_serde_sw_roundtrip() {
        let sw = sw_fixture();
        let json = serde_json::to_string(&sw).unwrap();
        let restored: SmithWilson = serde_json::from_str(&json).unwrap();
        // Verify DF at 2Y matches
        let df_orig = sw.discount_factor(ymd(2026, 1, 1));
        let df_restored = restored.discount_factor(ymd(2026, 1, 1));
        if let (Number::F64(a), Number::F64(b)) = (&df_orig, &df_restored) {
            assert!((a - b).abs() < 1e-12, "SW DF mismatch: {} vs {}", a, b);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 7: Zeta coefficients solve the interpolation condition
    #[test]
    fn test_sw_zeta_interpolation_condition() {
        let sw = sw_fixture();
        // For each market maturity, P(u_j) should equal the stored market DF
        // We verify this indirectly by checking the DF at each maturity
        let rates = vec![0.03, 0.032, 0.034, 0.036, 0.038, 0.037];
        for (i, u) in sw.maturities.iter().enumerate() {
            let expected_df = (-rates[i] * u).exp();
            let computed_df = sw.discount_factor_at_t(*u);
            assert!(
                (computed_df - expected_df).abs() < 1e-10,
                "Interpolation condition failed at maturity {}: computed={}, expected={}",
                u, computed_df, expected_df
            );
        }
    }
}
