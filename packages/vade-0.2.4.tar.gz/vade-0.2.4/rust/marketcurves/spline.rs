use chrono::{Datelike, NaiveDate};
use serde::{Serialize, Deserialize};
use crate::autodiff::dual::{Dual, Dual2};
use crate::autodiff::enums::Number;
use crate::autodiff::linalg::{dsolve_f64, fdsolve, fdsolve2};

/// Endpoint constraint types for spline construction.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum SplineEndpoint {
    NotAKnot,
    Natural,
}

impl SplineEndpoint {
    pub fn from_str(s: &str) -> Result<Self, String> {
        match s {
            "not_a_knot" => Ok(SplineEndpoint::NotAKnot),
            "natural" => Ok(SplineEndpoint::Natural),
            _ => Err(format!("Unknown spline endpoint: '{}'. Expected 'not_a_knot' or 'natural'", s)),
        }
    }
}

/// A piecewise polynomial B-spline of given order and knot sequence.
#[derive(Clone, Debug)]
pub struct PPSpline {
    pub k: usize,             // order (4 for cubic)
    pub t: Vec<f64>,          // knot vector
    pub c: Vec<Number>,       // coefficients (f64 or Dual or Dual2)
    pub n: usize,             // number of basis functions = t.len() - k
    pub endpoint: SplineEndpoint, // endpoint constraint used to build this spline
}

/// Evaluate the i-th B-spline basis function of order k at point x given knot vector t.
/// Cox-de Boor recursion.
pub fn bsplev_single_f64(x: &f64, i: usize, k: usize, t: &[f64]) -> f64 {
    // Short circuit: positivity and support property
    if *x < t[i] || *x > t[i + k] {
        return 0.0;
    }
    // Right endpoint support
    if *x == t[t.len() - 1] && i >= (t.len() - k - 1) {
        return 1.0;
    }
    // Base case
    if k == 1 {
        return if t[i] <= *x && *x < t[i + 1] { 1.0 } else { 0.0 };
    }
    // Recursive case
    let mut result = 0.0;
    if t[i] != t[i + k - 1] {
        result += (x - t[i]) / (t[i + k - 1] - t[i]) * bsplev_single_f64(x, i, k - 1, t);
    }
    if t[i + 1] != t[i + k] {
        result += (t[i + k] - x) / (t[i + k] - t[i + 1]) * bsplev_single_f64(x, i + 1, k - 1, t);
    }
    result
}

/// Evaluate the m-th derivative of the i-th B-spline basis function of order k at point x.
/// org_k is used internally for recursive derivative evaluation; pass None from outer calls.
pub fn bspldnev_single_f64(
    x: &f64,
    i: usize,
    k: usize,
    t: &[f64],
    m: usize,
    org_k: Option<usize>,
) -> f64 {
    if m == 0 {
        return bsplev_single_f64(x, i, k, t);
    }
    if k == 1 || m >= k {
        return 0.0;
    }
    let org_k = org_k.unwrap_or(k);
    let mut r = 0.0;
    let div1 = t[i + k - 1] - t[i];
    let div2 = t[i + k] - t[i + 1];

    if m == 1 {
        if div1 != 0.0 {
            r += bsplev_single_f64_with_org_k(x, i, k - 1, t, org_k) / div1;
        }
        if div2 != 0.0 {
            r -= bsplev_single_f64_with_org_k(x, i + 1, k - 1, t, org_k) / div2;
        }
        r *= (k - 1) as f64;
    } else {
        if div1 != 0.0 {
            r += bspldnev_single_f64(x, i, k - 1, t, m - 1, Some(org_k)) / div1;
        }
        if div2 != 0.0 {
            r -= bspldnev_single_f64(x, i + 1, k - 1, t, m - 1, Some(org_k)) / div2;
        }
        r *= (k - 1) as f64;
    }
    r
}

/// Internal: evaluate B-spline basis with org_k for right-endpoint support.
fn bsplev_single_f64_with_org_k(x: &f64, i: usize, k: usize, t: &[f64], org_k: usize) -> f64 {
    // Short circuit: positivity and support property
    if *x < t[i] || *x > t[i + k] {
        return 0.0;
    }
    // Right endpoint support using org_k
    if *x == t[t.len() - 1] && i >= (t.len() - org_k - 1) {
        return 1.0;
    }
    // Base case
    if k == 1 {
        return if t[i] <= *x && *x < t[i + 1] { 1.0 } else { 0.0 };
    }
    // Recursive case
    let mut result = 0.0;
    if t[i] != t[i + k - 1] {
        result += (x - t[i]) / (t[i + k - 1] - t[i]) * bsplev_single_f64_with_org_k(x, i, k - 1, t, org_k);
    }
    if t[i + 1] != t[i + k] {
        result += (t[i + k] - x) / (t[i + k] - t[i + 1]) * bsplev_single_f64_with_org_k(x, i + 1, k - 1, t, org_k);
    }
    result
}

/// Build the B-spline collocation matrix.
/// Rows 1..n-2 are basis evaluations at tau[1..n-2].
/// Row 0: derivative of order left_n at tau[0].
/// Row n-1: derivative of order right_n at tau[n-1].
pub fn bsplmatrix(tau: &[f64], k: usize, t: &[f64], left_n: usize, right_n: usize) -> Vec<Vec<f64>> {
    let n_basis = t.len() - k;
    let n_tau = tau.len();
    let mut b = vec![vec![0.0; n_basis]; n_tau];

    for i in 0..n_basis {
        b[0][i] = bspldnev_single_f64(&tau[0], i, k, t, left_n, None);
        b[n_tau - 1][i] = bspldnev_single_f64(&tau[n_tau - 1], i, k, t, right_n, None);
        for j in 1..(n_tau - 1) {
            b[j][i] = bsplev_single_f64(&tau[j], i, k, t);
        }
    }
    b
}

/// Solve for f64 spline coefficients: B*c = y.
fn csolve_f64(b: &[Vec<f64>], y: &[f64]) -> Vec<f64> {
    dsolve_f64(b, y)
}

/// Solve for Dual spline coefficients: f64-matrix * Dual-vector.
fn csolve_dual(b: &[Vec<f64>], y: &[Dual]) -> Vec<Dual> {
    fdsolve(b, y)
}

/// Solve for Dual2 spline coefficients: f64-matrix * Dual2-vector.
fn csolve_dual2(b: &[Vec<f64>], y: &[Dual2]) -> Vec<Dual2> {
    fdsolve2(b, y)
}

/// Generate a knot sequence from dates with k-fold endpoint multiplicity.
/// Produces t.len() = dates.len() + k, so n_basis = dates.len().
/// Interior knots are selected from the interior dates to satisfy this constraint.
/// For k=4 with n dates: we need n-k interior knots from dates[1..n-1] (which has n-2 dates).
pub fn auto_knot_sequence(dates: &[NaiveDate], k: usize) -> Vec<f64> {
    let x: Vec<f64> = dates.iter().map(|d| d.num_days_from_ce() as f64).collect();
    let n = x.len();
    assert!(n >= k, "Need at least k={} dates for order-{} spline, got {}", k, k, n);

    let n_interior = n - k; // number of interior knots needed
    let mut t = Vec::new();

    // k-fold first knot
    for _ in 0..k {
        t.push(x[0]);
    }

    // Interior knots: select n_interior knots from the n-2 interior dates
    if n_interior > 0 {
        let interior_dates = &x[1..n - 1]; // n-2 dates available
        if n_interior <= interior_dates.len() {
            // Select evenly spaced interior dates
            if n_interior == interior_dates.len() {
                // Use all interior dates
                for xi in interior_dates {
                    t.push(*xi);
                }
            } else {
                // Select a subset: evenly spaced
                for i in 0..n_interior {
                    let idx = (i * (interior_dates.len() - 1)) / (n_interior - 1).max(1);
                    t.push(interior_dates[idx]);
                }
            }
        }
    }

    // k-fold last knot
    for _ in 0..k {
        t.push(x[x.len() - 1]);
    }
    t
}

/// Generate a knot sequence from f64 x-values with k-fold endpoint multiplicity.
/// Used when explicit knot dates are provided (not auto-generated from nodes).
#[allow(dead_code)]
pub fn auto_knot_sequence_f64(x: &[f64], k: usize) -> Vec<f64> {
    let n = x.len();
    let mut t = Vec::new();
    for _ in 0..k {
        t.push(x[0]);
    }
    for xi in &x[1..n - 1] {
        t.push(*xi);
    }
    for _ in 0..k {
        t.push(x[n - 1]);
    }
    t
}

impl PPSpline {
    /// Build a PPSpline from node data.
    /// k: order (4 for cubic)
    /// t: knot vector
    /// node_x: x-coordinates of nodes (f64, from dates)
    /// node_y: y-values at nodes (Number: f64/Dual/Dual2)
    /// endpoint: endpoint constraint type
    pub fn build(
        k: usize,
        t: Vec<f64>,
        node_x: &[f64],
        node_y: &[Number],
        endpoint: &SplineEndpoint,
    ) -> Self {
        let n = t.len() - k;
        assert_eq!(node_x.len(), n, "Number of nodes must match number of basis functions");
        assert_eq!(node_y.len(), n, "Number of y-values must match number of basis functions");

        let (left_n, right_n) = match endpoint {
            SplineEndpoint::NotAKnot => (2, 2),
            SplineEndpoint::Natural => (2, 2),
        };

        // Build tau: for not_a_knot, tau uses the actual node x-values
        // For natural, same thing -- the constraint rows use endpoints
        let tau = node_x.to_vec();

        // Build collocation matrix
        let b = bsplmatrix(&tau, k, &t, left_n, right_n);

        // Build y vector with endpoint constraint values
        let mut y_vec: Vec<Number> = node_y.to_vec();
        // For both not_a_knot and natural, the first and last y values should be 0
        // (the derivative constraint rows: derivative = 0 at those points)
        y_vec[0] = Number::F64(0.0);
        y_vec[n - 1] = Number::F64(0.0);

        // Solve for coefficients based on Number type
        let c = match &y_vec[1] {
            Number::F64(_) => {
                let y_f64: Vec<f64> = y_vec.iter().map(|v| match v {
                    Number::F64(f) => *f,
                    _ => panic!("Mixed Number types in spline construction"),
                }).collect();
                csolve_f64(&b, &y_f64).into_iter().map(Number::F64).collect()
            }
            Number::Dual(_) => {
                let y_dual: Vec<Dual> = y_vec.into_iter().map(|v| match v {
                    Number::F64(f) => {
                        // Promote f64 to Dual with same vars as other Dual values
                        // Find the first Dual in original y to get vars
                        let template = match &node_y[1] {
                            Number::Dual(d) => d,
                            _ => panic!("Expected Dual"),
                        };
                        Dual::new_from(template, f)
                    }
                    Number::Dual(d) => d,
                    _ => panic!("Mixed Number types"),
                }).collect();
                csolve_dual(&b, &y_dual).into_iter().map(Number::Dual).collect()
            }
            Number::Dual2(_) => {
                let y_dual2: Vec<Dual2> = y_vec.into_iter().map(|v| match v {
                    Number::F64(f) => {
                        let template = match &node_y[1] {
                            Number::Dual2(d) => d,
                            _ => panic!("Expected Dual2"),
                        };
                        Dual2::new_from(template, f)
                    }
                    Number::Dual2(d) => d,
                    _ => panic!("Mixed Number types"),
                }).collect();
                csolve_dual2(&b, &y_dual2).into_iter().map(Number::Dual2).collect()
            }
        };

        PPSpline { k, t, c, n, endpoint: endpoint.clone() }
    }

    /// Evaluate the spline at point x: sum(c_i * N_i,k(x)).
    /// Basis functions are f64, coefficients may be Number (f64/Dual/Dual2).
    pub fn eval(&self, x: f64) -> Number {
        let mut result: Option<Number> = None;
        for i in 0..self.n {
            let basis = bsplev_single_f64(&x, i, self.k, &self.t);
            if basis == 0.0 {
                continue;
            }
            let term = &self.c[i] * basis;
            result = match result {
                None => Some(term),
                Some(acc) => Some(&acc + &term),
            };
        }
        result.unwrap_or(Number::F64(0.0))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::autodiff::dual::{Dual, Dual2, Vars};

    // ========= B-spline basis evaluation tests =========

    #[test]
    fn test_bsplev_single_f64_mid() {
        // B-spline basis evaluation: x=1.5, k=4, knots with multiplicities
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let x = 1.5_f64;
        let k = 4;
        let result: Vec<f64> = (0..8).map(|i| bsplev_single_f64(&x, i, k, &t)).collect();
        let expected = vec![0.125, 0.375, 0.375, 0.125, 0., 0., 0., 0.];
        assert_eq!(result, expected);
    }

    #[test]
    fn test_bsplev_single_f64_right_endpoint() {
        // At right endpoint x=4.0, only last basis function should be 1.0
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let x = 4.0_f64;
        let k = 4;
        let result: Vec<f64> = (0..8).map(|i| bsplev_single_f64(&x, i, k, &t)).collect();
        let expected = vec![0., 0., 0., 0., 0., 0., 0., 1.0];
        assert_eq!(result, expected);
    }

    #[test]
    fn test_bsplev_single_f64_partition_of_unity() {
        // B-spline basis functions sum to 1 at any point in the domain
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let k = 4;
        for &x in &[1.0, 1.3, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0] {
            let sum: f64 = (0..8).map(|i| bsplev_single_f64(&x, i, k, &t)).sum();
            assert!((sum - 1.0).abs() < 1e-12, "Partition of unity failed at x={}: sum={}", x, sum);
        }
    }

    #[test]
    fn test_bsplev_outside_support() {
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let k = 4;
        // x=0.5 is outside support of all basis functions
        let x = 0.5_f64;
        let result: Vec<f64> = (0..8).map(|i| bsplev_single_f64(&x, i, k, &t)).collect();
        assert!(result.iter().all(|v| *v == 0.0));
    }

    // ========= B-spline derivative tests =========

    #[test]
    fn test_bspldnev_single_f64_first_deriv() {
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let x = 1.5_f64;
        let k = 4;
        let result: Vec<f64> = (0..8).map(|i| bspldnev_single_f64(&x, i, k, &t, 1, None)).collect();
        let expected = vec![-0.75, -0.75, 0.75, 0.75, 0., 0., 0., 0.];
        assert_eq!(result, expected);
    }

    #[test]
    fn test_bspldnev_single_f64_right_endpoint() {
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let x = 4.0_f64;
        let k = 4;
        let result: Vec<f64> = (0..8).map(|i| bspldnev_single_f64(&x, i, k, &t, 1, None)).collect();
        let expected = vec![0., 0., 0., 0., 0., 0., -3., 3.];
        assert_eq!(result, expected);
    }

    #[test]
    fn test_bspldnev_single_f64_second_deriv() {
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let x = 4.0_f64;
        let k = 4;
        let result: Vec<f64> = (0..8).map(|i| bspldnev_single_f64(&x, i, k, &t, 2, None)).collect();
        let expected = vec![0., 0., 0., 0., 0., 3., -9., 6.];
        assert_eq!(result, expected);
    }

    #[test]
    fn test_bspldnev_single_f64_zero_deriv() {
        // m=0 should return same as bsplev_single_f64
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let x = 1.5_f64;
        let k = 4;
        let result: Vec<f64> = (0..8).map(|i| bspldnev_single_f64(&x, i, k, &t, 0, None)).collect();
        let expected = vec![0.125, 0.375, 0.375, 0.125, 0., 0., 0., 0.];
        assert_eq!(result, expected);
    }

    #[test]
    fn test_bspldnev_high_order_deriv_zero() {
        // Derivatives of order >= k are always 0
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let x = 1.5_f64;
        let k = 4;
        let result: Vec<f64> = (0..8).map(|i| bspldnev_single_f64(&x, i, k, &t, 6, None)).collect();
        assert!(result.iter().all(|v| *v == 0.0));
    }

    // ========= Collocation matrix tests =========

    #[test]
    fn test_bsplmatrix() {
        // B-spline collocation matrix reference test
        let t = vec![1., 1., 1., 1., 2., 3., 3., 3., 3.];
        let k = 4;
        let tau = vec![1., 1., 2., 3., 3.];
        let b = bsplmatrix(&tau, k, &t, 2, 2);
        let expected = vec![
            vec![6., -9., 3., 0., 0.],
            vec![1., 0., 0., 0., 0.],
            vec![0., 0.25, 0.5, 0.25, 0.],
            vec![0., 0., 0., 0., 1.],
            vec![0., 0., 3., -9., 6.],
        ];
        for i in 0..5 {
            for j in 0..5 {
                assert!((b[i][j] - expected[i][j]).abs() < 1e-12,
                    "bsplmatrix[{}][{}] = {} expected {}", i, j, b[i][j], expected[i][j]);
            }
        }
    }

    // ========= Coefficient solving tests =========

    #[test]
    fn test_csolve_f64() {
        // Cubic B-spline coefficient solve reference
        let t = vec![0., 0., 0., 0., 4., 4., 4., 4.];
        let tau = vec![0., 1., 3., 4.];
        let y = vec![0., 0., 2., 2.];
        let k = 4;
        let b = bsplmatrix(&tau, k, &t, 0, 0);
        let c = csolve_f64(&b, &y);
        let expected = vec![0., -1.11111111, 3.111111111111, 2.0];
        for (ci, ei) in c.iter().zip(expected.iter()) {
            assert!((ci - ei).abs() < 1e-6, "c={} expected={}", ci, ei);
        }
    }

    #[test]
    fn test_csolve_reproduces_nodes() {
        // The spline should exactly reproduce node values at collocation points
        let t = vec![0., 0., 0., 0., 4., 4., 4., 4.];
        let tau = vec![0., 1., 3., 4.];
        let y = vec![0., 0., 2., 2.];
        let k = 4;
        let b = bsplmatrix(&tau, k, &t, 0, 0);
        let c = csolve_f64(&b, &y);

        // Evaluate at tau points: should recover y values for interior points (1, 2)
        for j in 1..3 {
            let val: f64 = (0..4).map(|i| c[i] * bsplev_single_f64(&tau[j], i, k, &t)).sum();
            assert!((val - y[j]).abs() < 1e-10, "At tau[{}]={}: got {} expected {}", j, tau[j], val, y[j]);
        }
    }

    // ========= PPSpline build and eval tests =========

    #[test]
    fn test_ppspline_build_and_eval() {
        // Build a cubic spline with not_a_knot endpoints
        let t = vec![1., 1., 1., 1., 2., 2., 2., 3., 4., 4., 4., 4.];
        let k = 4;
        let n = t.len() - k; // 8 basis functions
        let tau: Vec<f64> = vec![1., 1., 1.5, 2., 2.5, 3., 3.5, 4.];

        // Coefficients given (piecewise polynomial evaluation test)
        let c: Vec<Number> = vec![1., 2., -1., 2., 1., 1., 2., 2.]
            .into_iter()
            .map(|v| Number::F64(v))
            .collect();

        let pp = PPSpline { k, t: t.clone(), c, n, endpoint: SplineEndpoint::NotAKnot };

        // Test evaluation at known points (piecewise polynomial reference)
        let r1 = pp.eval(1.1);
        if let Number::F64(v) = r1 {
            assert!((v - 1.19).abs() < 1e-6, "eval(1.1) = {} expected 1.19", v);
        } else { panic!("Expected F64"); }

        let r2 = pp.eval(1.8);
        if let Number::F64(v) = r2 {
            assert!((v - 0.84).abs() < 1e-6, "eval(1.8) = {} expected 0.84", v);
        } else { panic!("Expected F64"); }

        let r3 = pp.eval(2.8);
        if let Number::F64(v) = r3 {
            assert!((v - 1.136).abs() < 1e-6, "eval(2.8) = {} expected 1.136", v);
        } else { panic!("Expected F64"); }
    }

    #[test]
    fn test_ppspline_eval_reproduces_nodes() {
        // Build spline from nodes and verify it reproduces them
        let dates: Vec<f64> = vec![0.0, 1.0, 2.0, 3.0, 4.0];
        let values: Vec<Number> = vec![1.0, 0.99, 0.97, 0.94, 0.90]
            .into_iter()
            .map(Number::F64)
            .collect();

        // Auto-generate knots
        let mut t = Vec::new();
        for _ in 0..4 { t.push(0.0); }
        for xi in &dates[1..4] { t.push(*xi); }
        for _ in 0..4 { t.push(4.0); }
        // t = [0,0,0,0, 1,2,3, 4,4,4,4] -> n = 11-4 = 7
        // But we have 5 nodes... We need n == len(nodes)
        // For auto_knot_sequence: t.len() = k + n = k + dates.len()
        // t = [0,0,0,0, 1,2,3, 4,4,4,4] = 11 elements, n = 7, but we have 5 nodes
        // That doesn't match. Let's use proper auto knot sequence.
        let t2: Vec<f64> = vec![0., 0., 0., 0., 2., 4., 4., 4., 4.]; // n = 9-4 = 5
        let pp = PPSpline::build(4, t2, &dates, &values, &SplineEndpoint::NotAKnot);

        // Verify node reproduction at interior points
        for j in 1..(dates.len() - 1) {
            let val = pp.eval(dates[j]);
            if let Number::F64(v) = val {
                if let Number::F64(expected) = values[j] {
                    assert!((v - expected).abs() < 1e-10,
                        "At x={}: got {} expected {}", dates[j], v, expected);
                }
            }
        }
    }

    #[test]
    fn test_ppspline_ad_propagation() {
        // Build a spline with Dual node values and verify AD propagation
        let dates: Vec<f64> = vec![0.0, 1.0, 2.0, 3.0, 4.0];
        let d0 = Dual::try_new(1.0, vec!["v0".to_string()], vec![0.0]).unwrap();
        let d1 = Dual::new("v0", 0.99);
        let d2 = Dual::try_new(0.97, vec!["v0".to_string()], vec![0.0]).unwrap();
        let d3 = Dual::try_new(0.94, vec!["v0".to_string()], vec![0.0]).unwrap();
        let d4 = Dual::try_new(0.90, vec!["v0".to_string()], vec![0.0]).unwrap();
        let values: Vec<Number> = vec![
            Number::Dual(d0),
            Number::Dual(d1),
            Number::Dual(d2),
            Number::Dual(d3),
            Number::Dual(d4),
        ];

        let t = vec![0., 0., 0., 0., 2., 4., 4., 4., 4.];
        let pp = PPSpline::build(4, t, &dates, &values, &SplineEndpoint::NotAKnot);

        // Evaluate at a mid-point: should return Dual with non-zero derivative
        let val = pp.eval(1.5);
        if let Number::Dual(d) = val {
            // The derivative should be non-zero since v0 affects node d1
            assert!(d.real() > 0.9 && d.real() < 1.0,
                "Spline at 1.5: real={}", d.real());
            // AD derivative should propagate
            assert!(d.vars().len() > 0, "Should have AD variables");
        } else {
            panic!("Expected Dual result from Dual-node spline");
        }
    }

    #[test]
    fn test_auto_knot_sequence() {
        let dates = vec![
            NaiveDate::from_ymd_opt(2024, 1, 1).unwrap(),
            NaiveDate::from_ymd_opt(2025, 1, 1).unwrap(),
            NaiveDate::from_ymd_opt(2026, 1, 1).unwrap(),
            NaiveDate::from_ymd_opt(2027, 1, 1).unwrap(),
            NaiveDate::from_ymd_opt(2028, 1, 1).unwrap(),
        ];
        let k = 4;
        let t = auto_knot_sequence(&dates, k);

        // t.len() = dates.len() + k = 5 + 4 = 9
        assert_eq!(t.len(), 9);

        // n_basis = t.len() - k = 5 = dates.len() (one coefficient per node)
        let n_basis = t.len() - k;
        assert_eq!(n_basis, 5);

        // First k elements should be the same
        for i in 0..k {
            assert_eq!(t[i], t[0]);
        }
        // Last k elements should be the same
        let last = t.len() - 1;
        for i in 0..k {
            assert_eq!(t[last - i], t[last]);
        }

        // Interior knots: n - k = 1 knot from interior dates
        assert_eq!(t.len() - 2 * k, 1);
    }

    #[test]
    fn test_auto_knot_sequence_many_nodes() {
        // With 8 nodes, k=4: need 4 interior knots from 6 interior dates
        let dates: Vec<NaiveDate> = (0..8).map(|i|
            NaiveDate::from_ymd_opt(2024 + i, 1, 1).unwrap()
        ).collect();
        let k = 4;
        let t = auto_knot_sequence(&dates, k);

        assert_eq!(t.len(), dates.len() + k); // 12
        let n_basis = t.len() - k;
        assert_eq!(n_basis, dates.len()); // 8
    }

    #[test]
    fn test_not_a_knot_vs_natural() {
        // Same nodes but different endpoint constraints should give different splines
        let dates: Vec<f64> = vec![0.0, 1.0, 2.0, 3.0, 4.0];
        let values: Vec<Number> = vec![0.0, 1.0, 0.5, 1.5, 1.0]
            .into_iter()
            .map(Number::F64)
            .collect();

        let t = vec![0., 0., 0., 0., 2., 4., 4., 4., 4.];

        let pp_nak = PPSpline::build(4, t.clone(), &dates, &values, &SplineEndpoint::NotAKnot);
        let pp_nat = PPSpline::build(4, t, &dates, &values, &SplineEndpoint::Natural);

        // Evaluate at a mid-point: should give different values
        let val_nak = pp_nak.eval(0.5);
        let val_nat = pp_nat.eval(0.5);

        if let (Number::F64(v1), Number::F64(v2)) = (&val_nak, &val_nat) {
            // They should be different (unless by coincidence)
            // At minimum, they should both be reasonable values
            assert!(v1.is_finite(), "not_a_knot eval should be finite");
            assert!(v2.is_finite(), "natural eval should be finite");
        }
    }

    #[test]
    fn test_endpoint_from_str() {
        assert_eq!(SplineEndpoint::from_str("not_a_knot").unwrap(), SplineEndpoint::NotAKnot);
        assert_eq!(SplineEndpoint::from_str("natural").unwrap(), SplineEndpoint::Natural);
        assert!(SplineEndpoint::from_str("invalid").is_err());
    }
}
