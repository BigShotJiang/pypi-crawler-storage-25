use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::calendar::convention::DcfOptions;
use crate::marketcurves::curve::{CurveQuery, DiscountCurve, LineCurve};
use crate::marketcurves::interpolation::CurveInterpolation;

/// Composition type for CompositeCurve.
///
/// - Discount: multiplicative DF composition (product of component DFs).
/// - Line: additive rate composition (sum of component rates).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum CompositeCurveType {
    Discount(Vec<DiscountCurve>),
    Line(Vec<LineCurve>),
}

/// A composite curve that combines multiple curves.
///
/// For DiscountCurve composition: DFs are multiplied (D-37).
/// For LineCurve composition: rates are added (D-37).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CompositeCurve {
    pub curves: CompositeCurveType,
    pub id: String,
}

impl CompositeCurve {
    /// Create a CompositeCurve from multiple DiscountCurves (multiplicative DF).
    pub fn new_discount(curves: Vec<DiscountCurve>, id: String) -> Self {
        Self {
            curves: CompositeCurveType::Discount(curves),
            id,
        }
    }

    /// Create a CompositeCurve from multiple LineCurves (additive rates).
    pub fn new_line(curves: Vec<LineCurve>, id: String) -> Self {
        Self {
            curves: CompositeCurveType::Line(curves),
            id,
        }
    }
}

impl CurveQuery for CompositeCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        match &self.curves {
            CompositeCurveType::Discount(curves) => {
                // Multiplicative: product of DFs
                let mut result = Number::F64(1.0);
                for c in curves {
                    result = &result * &c.discount_factor(date);
                }
                result
            }
            CompositeCurveType::Line(curves) => {
                // Sum zero rates from each curve, convert to DF.
                // LineCurve: DF = exp(-rate * dcf(first_key, date))
                // For the composite: sum the rates then convert to DF.
                if curves.is_empty() {
                    return Number::F64(1.0);
                }
                let base_date = curves[0].nodes.first_key();
                let convention = curves[0].convention;
                let dcf = convention
                    .dcf(base_date, date, &DcfOptions::default())
                    .unwrap_or(0.0);
                if dcf.abs() < 1e-14 {
                    return Number::F64(1.0);
                }
                // Each LineCurve's interpolated value at `date` gives the rate.
                // Sum them and convert to DF.
                let mut total_rate = Number::F64(0.0);
                for c in curves {
                    let rate = c.interpolator.interpolated_value(&c.nodes, date);
                    total_rate = total_rate + rate;
                }
                (&total_rate * (-dcf)).exp()
            }
        }
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        match &self.curves {
            CompositeCurveType::Discount(curves) => {
                // Derive from composite DF ratio
                if curves.is_empty() {
                    return Number::F64(0.0);
                }
                let convention = curves[0].convention;
                let dcf = convention
                    .dcf(start, end, &DcfOptions::default())
                    .unwrap();
                let df_start = self.discount_factor(start);
                let df_end = self.discount_factor(end);
                let ratio = &df_end / &df_start;
                -(ratio.log()) / dcf
            }
            CompositeCurveType::Line(curves) => {
                // Additive: sum zero rates from each component
                let mut total = Number::F64(0.0);
                for c in curves {
                    total = total + c.zero_rate(start, end);
                }
                total
            }
        }
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        match &self.curves {
            CompositeCurveType::Discount(curves) => {
                // Derive from composite DFs
                if curves.is_empty() {
                    return Number::F64(0.0);
                }
                let convention = curves[0].convention;
                let dcf = convention
                    .dcf(start, end, &DcfOptions::default())
                    .unwrap();
                let df_start = self.discount_factor(start);
                let df_end = self.discount_factor(end);
                let ratio = &df_end / &df_start;
                -(ratio.log()) / dcf
            }
            CompositeCurveType::Line(curves) => {
                // Additive: sum forward rates from each component
                let mut total = Number::F64(0.0);
                for c in curves {
                    total = total + c.forward_rate(start, end);
                }
                total
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::autodiff::dual::Dual;
    use indexmap::IndexMap;
    use crate::calendar::convention::DayCountConvention;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn disc_curve_1() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc1".to_string(),
        )
    }

    fn disc_curve_2() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.99),
            (ymd(2026, 1, 1), 0.98),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc2".to_string(),
        )
    }

    fn line_curve_1() -> LineCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.02),
            (ymd(2025, 1, 1), 0.02),
            (ymd(2026, 1, 1), 0.02),
        ]));
        LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "line1".to_string(),
        )
    }

    fn line_curve_2() -> LineCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.01),
            (ymd(2026, 1, 1), 0.01),
        ]));
        LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "line2".to_string(),
        )
    }

    #[test]
    fn test_composite_discount_multiply() {
        let c1 = disc_curve_1();
        let c2 = disc_curve_2();

        let df1 = c1.discount_factor(ymd(2025, 1, 1));
        let df2 = c2.discount_factor(ymd(2025, 1, 1));

        let composite = CompositeCurve::new_discount(vec![c1, c2], "comp".to_string());
        let df_comp = composite.discount_factor(ymd(2025, 1, 1));

        // Composite DF = product of individual DFs
        let expected = &df1 * &df2;
        if let (Number::F64(c), Number::F64(e)) = (&df_comp, &expected) {
            assert!(
                (c - e).abs() < 1e-12,
                "Composite DF ({c}) != product ({e})"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_composite_line_add() {
        let c1 = line_curve_1(); // 2%
        let c2 = line_curve_2(); // 1%

        let composite = CompositeCurve::new_line(vec![c1, c2], "comp".to_string());

        // Composite zero rate should be sum = 3%
        let zr = composite.zero_rate(ymd(2024, 1, 1), ymd(2025, 1, 1));
        if let Number::F64(r) = zr {
            assert!(
                (r - 0.03).abs() < 1e-6,
                "Composite zero rate should be ~0.03 (2%+1%), got {r}"
            );
        } else {
            panic!("Expected F64");
        }

        // Verify DF is consistent with summed rate (not product of individual DFs)
        let df = composite.discount_factor(ymd(2025, 1, 1));
        if let Number::F64(v) = df {
            let dcf = 366.0 / 365.0; // 2024 is leap year
            let expected = (-0.03 * dcf).exp();
            assert!(
                (v - expected).abs() < 1e-6,
                "Composite DF ({v}) should match exp(-0.03*dcf) = {expected}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_composite_single_curve() {
        let c1 = disc_curve_1();
        let df_single = c1.discount_factor(ymd(2025, 1, 1));

        let composite = CompositeCurve::new_discount(vec![c1], "single".to_string());
        let df_comp = composite.discount_factor(ymd(2025, 1, 1));

        if let (Number::F64(s), Number::F64(c)) = (&df_single, &df_comp) {
            assert!(
                (s - c).abs() < 1e-12,
                "Single-curve composite ({c}) != original ({s})"
            );
        }
    }

    #[test]
    fn test_composite_ad() {
        // Create Dual-valued discount curves
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.97);
        let nodes1 = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]));
        let c1 = DiscountCurve::new(
            nodes1,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "dual1".to_string(),
        );

        let d3 = Dual::new("v2", 1.0);
        let d4 = Dual::new("v3", 0.99);
        let nodes2 = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d3),
            (ymd(2025, 1, 1), d4),
        ]));
        let c2 = DiscountCurve::new(
            nodes2,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "dual2".to_string(),
        );

        let composite = CompositeCurve::new_discount(vec![c1, c2], "comp_dual".to_string());
        let df = composite.discount_factor(ymd(2025, 1, 1));

        match df {
            Number::Dual(d) => {
                let expected = 0.97 * 0.99;
                assert!(
                    (d.real() - expected).abs() < 1e-10,
                    "Composite Dual real={}, expected={}",
                    d.real(),
                    expected
                );
            }
            _ => panic!("Expected Dual from composite with Dual curves"),
        }
    }
}
