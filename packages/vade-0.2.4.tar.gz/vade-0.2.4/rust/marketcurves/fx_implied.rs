use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use std::collections::HashMap;

use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::calendar::convention::DcfOptions;
use crate::marketcurves::curve::{CurveQuery, DiscountCurve};
use crate::marketcurves::fx::pair::FXPair;
use crate::marketcurves::fx::rates::FXRates;

/// An FX-implied curve that derives discount factors via FX parity (D-38, D-41).
///
/// FXImpliedCurve implements CurveQuery by computing:
///   proxy_df(t) = collateral_df(t) * fx_forward(t) / fx_spot
///
/// where fx_forward(t) = spot * df_cashflow(t) / df_collateral(t).
///
/// Stores all required data internally (owned copies) so it can be passed
/// as `&dyn CurveQuery` anywhere without lifetime complications.
///
/// This is a read-only derived curve. When the Solver mutates underlying
/// component curves, a new FXImpliedCurve should be constructed with updated data.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FXImpliedCurve {
    /// Currency of the cashflows being discounted.
    pub cashflow_ccy: String,
    /// Currency of the collateral/CSA.
    pub collateral_ccy: String,
    /// Owned copy of FX rates (for spot rate lookup).
    pub fx_rates: FXRates,
    /// Per-pair settlement dates for FX forwards.
    pub fx_settlements: HashMap<String, NaiveDate>,
    /// Owned collateral currency discount curve.
    pub collateral_curve: DiscountCurve,
    /// Owned cashflow currency discount curve.
    pub cashflow_curve: DiscountCurve,
    /// Curve identifier.
    pub id: String,
}

impl FXImpliedCurve {
    /// Create a new FXImpliedCurve.
    pub fn new(
        cashflow_ccy: String,
        collateral_ccy: String,
        fx_rates: FXRates,
        fx_settlements: HashMap<String, NaiveDate>,
        collateral_curve: DiscountCurve,
        cashflow_curve: DiscountCurve,
        id: String,
    ) -> Self {
        Self {
            cashflow_ccy,
            collateral_ccy,
            fx_rates,
            fx_settlements,
            collateral_curve,
            cashflow_curve,
            id,
        }
    }
}

impl CurveQuery for FXImpliedCurve {
    /// Proxy discount factor via FX parity.
    ///
    /// proxy_df(t) = collateral_df(t) * fx_forward(t) / fx_spot
    ///             = collateral_df(t) * (spot * df_cash(t) / df_col(t)) / spot
    ///             = df_cash(t)
    ///
    /// When there is a basis or funding spread between the curves, the result
    /// differs from a simple cashflow curve DF. The value of FXImpliedCurve is in
    /// the general case where the collateral curve includes additional basis/spread.
    fn discount_factor(&self, date: NaiveDate) -> Number {
        // Same currency short-circuit: proxy DF = cashflow DF
        if self.cashflow_ccy == self.collateral_ccy {
            return self.cashflow_curve.discount_factor(date);
        }

        let pair = FXPair::new(&self.cashflow_ccy, &self.collateral_ccy);
        let spot = self.fx_rates.rate(&pair);

        let df_cash = self.cashflow_curve.discount_factor(date);
        let df_col = self.collateral_curve.discount_factor(date);

        // Forward = spot * df_cash / df_col
        let fwd = &(&spot * &df_cash) / &df_col;

        // Proxy DF = df_col * fwd / spot
        &df_col * &(&fwd / &spot)
    }

    /// Zero rate derived from proxy discount factors.
    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let convention = self.collateral_curve.convention;
        let dcf = convention
            .dcf(start, end, &DcfOptions::default())
            .unwrap();
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let ratio = &df_end / &df_start;
        -(ratio.log()) / dcf
    }

    /// Forward rate derived from proxy discount factors.
    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::autodiff::dual::Dual;
    use indexmap::IndexMap;
    use crate::calendar::convention::DayCountConvention;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn make_proxy() -> FXImpliedCurve {
        let fx_rates = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 1),
        );
        let settlements = HashMap::from([("eurusd".to_string(), ymd(2024, 1, 3))]);

        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.95),
        ]));
        let usd_curve = DiscountCurve::new(
            usd_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "usd".to_string(),
        );

        let eur_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
        ]));
        let eur_curve = DiscountCurve::new(
            eur_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "eur".to_string(),
        );

        // FXImpliedCurve: cashflow in EUR, collateral in USD
        FXImpliedCurve::new(
            "eur".to_string(),
            "usd".to_string(),
            fx_rates,
            settlements,
            usd_curve,  // collateral curve (USD)
            eur_curve,   // cashflow curve (EUR)
            "proxy_eurusd".to_string(),
        )
    }

    #[test]
    fn test_proxy_curve_basic() {
        let proxy = make_proxy();
        let df = proxy.discount_factor(ymd(2025, 1, 1));

        // proxy_df = col_df * (spot * cash_df / col_df) / spot = cash_df
        // In the simple case with no basis, proxy DF = cashflow DF = 0.97
        match &df {
            Number::Dual(d) => {
                assert!(
                    (d.real() - 0.97).abs() < 1e-8,
                    "Proxy DF should be ~0.97 (cashflow DF), got {}",
                    d.real()
                );
            }
            Number::F64(v) => {
                assert!(
                    (v - 0.97).abs() < 1e-8,
                    "Proxy DF should be ~0.97 (cashflow DF), got {v}"
                );
            }
            _ => panic!("Unexpected type"),
        }
    }

    #[test]
    fn test_proxy_curve_same_ccy() {
        // When cashflow = collateral currency, proxy DF should equal cashflow DF
        let fx_rates = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 1),
        );
        let settlements = HashMap::from([("eurusd".to_string(), ymd(2024, 1, 3))]);

        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.95),
        ]));
        let usd_curve = DiscountCurve::new(
            usd_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "usd".to_string(),
        );

        let usd_nodes2 = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.95),
        ]));
        let usd_curve2 = DiscountCurve::new(
            usd_nodes2,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "usd2".to_string(),
        );

        // Same currency for both
        let proxy = FXImpliedCurve::new(
            "usd".to_string(),
            "usd".to_string(),
            fx_rates,
            settlements,
            usd_curve,   // collateral
            usd_curve2,  // cashflow
            "proxy_same".to_string(),
        );

        let df = proxy.discount_factor(ymd(2025, 1, 1));
        match &df {
            Number::Dual(d) => {
                assert!(
                    (d.real() - 0.95).abs() < 1e-8,
                    "Same-ccy proxy DF should be ~0.95, got {}",
                    d.real()
                );
            }
            Number::F64(v) => {
                assert!(
                    (v - 0.95).abs() < 1e-8,
                    "Same-ccy proxy DF should be ~0.95, got {v}"
                );
            }
            _ => panic!("Unexpected type"),
        }
    }

    #[test]
    fn test_proxy_curve_implements_curve_query() {
        let proxy = make_proxy();

        // Pass as &dyn CurveQuery
        fn use_curve(curve: &dyn CurveQuery, date: NaiveDate) -> Number {
            curve.discount_factor(date)
        }

        let df = use_curve(&proxy, ymd(2025, 1, 1));
        match &df {
            Number::Dual(d) => assert!(d.real() > 0.0 && d.real() < 1.0),
            Number::F64(v) => assert!(*v > 0.0 && *v < 1.0),
            _ => panic!("Unexpected type"),
        }

        // Also test zero_rate
        let zr = proxy.zero_rate(ymd(2024, 1, 1), ymd(2025, 1, 1));
        match &zr {
            Number::Dual(d) => assert!(d.real() > 0.0, "Zero rate should be positive"),
            Number::F64(v) => assert!(*v > 0.0, "Zero rate should be positive"),
            _ => panic!("Unexpected type"),
        }
    }

    #[test]
    fn test_proxy_curve_ad() {
        // Use Dual-valued curves to verify AD propagation
        let fx_rates = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 1),
        );
        let settlements = HashMap::from([("eurusd".to_string(), ymd(2024, 1, 3))]);

        let d1 = Dual::new("usd_df1", 1.0);
        let d2 = Dual::new("usd_df2", 0.95);
        let usd_nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]));
        let usd_curve = DiscountCurve::new(
            usd_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "usd_dual".to_string(),
        );

        let d3 = Dual::new("eur_df1", 1.0);
        let d4 = Dual::new("eur_df2", 0.97);
        let eur_nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d3),
            (ymd(2025, 1, 1), d4),
        ]));
        let eur_curve = DiscountCurve::new(
            eur_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "eur_dual".to_string(),
        );

        let proxy = FXImpliedCurve::new(
            "eur".to_string(),
            "usd".to_string(),
            fx_rates,
            settlements,
            usd_curve,
            eur_curve,
            "proxy_ad".to_string(),
        );

        let df = proxy.discount_factor(ymd(2025, 1, 1));
        match df {
            Number::Dual(d) => {
                // Should have sensitivities to both FX and curve DFs
                assert!(d.real() > 0.0 && d.real() < 1.0);
                // The Dual should carry derivatives
                assert!(
                    d.vars.len() > 0,
                    "Dual should have variables for AD"
                );
            }
            _ => panic!("Expected Dual from proxy with Dual curves, got {:?}", df),
        }
    }
}
