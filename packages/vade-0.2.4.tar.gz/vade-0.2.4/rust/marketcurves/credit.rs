use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::nodes::Nodes;

/// A credit implied curve storing piecewise flat hazard rates.
///
/// Computes survival probability Q(t) = exp(-integral lambda(s) ds)
/// where lambda(s) is the piecewise flat hazard rate function.
///
/// Implements CurveQuery: discount_factor returns Q(t) (survival probability).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CreditImpliedCurve {
    pub nodes: Nodes,                  // date -> hazard rate (lambda)
    pub convention: DayCountConvention,
    pub recovery_rate: f64,            // constant flat recovery rate
    pub id: String,
}

impl CreditImpliedCurve {
    pub fn new(
        nodes: Nodes,
        convention: DayCountConvention,
        recovery_rate: f64,
        id: String,
    ) -> Self {
        Self {
            nodes,
            convention,
            recovery_rate,
            id,
        }
    }

    /// Compute survival probability Q(t) = exp(-cumulative_hazard(t)).
    ///
    /// Uses piecewise flat hazard rates: for each segment [t_i, t_{i+1}],
    /// hazard accumulates as lambda_i * dcf(t_i, min(t_{i+1}, date)).
    pub fn survival_probability(&self, date: NaiveDate) -> Number {
        let keys = self.nodes.keys();
        if keys.is_empty() {
            return Number::F64(1.0);
        }

        // Before or at first node: Q = 1.0
        if date <= keys[0] {
            return Number::F64(1.0);
        }

        let n = keys.len();
        let mut cumulative_hazard = Number::F64(0.0);

        for i in 0..n {
            let t_start = keys[i];
            let lambda_i = self.nodes.get_value_at_index(i);

            let t_end = if i + 1 < n { keys[i + 1] } else { date };

            if date <= t_start {
                break;
            }

            let segment_end = if date < t_end { date } else { t_end };
            let dcf = self.convention
                .dcf(t_start, segment_end, &DcfOptions::default())
                .unwrap();

            cumulative_hazard = cumulative_hazard + &lambda_i * dcf;

            // If date is within this segment, we're done
            if date <= t_end {
                break;
            }
        }

        // Extrapolation beyond last node is already handled in the loop:
        // when i = n-1, t_end = date (the else branch), so the loop
        // accumulates lambda_{n-1} * dcf(keys[n-1], date) automatically.

        (-cumulative_hazard).exp()
    }

    /// Return the piecewise flat hazard rate at a given date (step function).
    pub fn hazard_rate(&self, date: NaiveDate) -> Number {
        let keys = self.nodes.keys();
        if keys.is_empty() {
            return Number::F64(0.0);
        }

        // Before first node: use first rate
        if date <= keys[0] {
            return self.nodes.get_value_at_index(0);
        }

        let n = keys.len();
        // Find the segment: last key <= date
        for i in (0..n).rev() {
            if keys[i] <= date {
                return self.nodes.get_value_at_index(i);
            }
        }

        self.nodes.get_value_at_index(0)
    }

    // -- Solver support methods --

    pub fn set_nodes(&mut self, nodes: Nodes) {
        self.nodes = nodes;
    }

    pub fn get_node_values(&self) -> Vec<f64> {
        self.nodes.get_values_f64()
    }

    pub fn set_node_values(&mut self, values: &[f64]) {
        self.nodes.set_values_as_f64(values);
    }

    /// Number of solver variables. All nodes are solvable (ini_solve=0).
    pub fn n_vars(&self) -> usize {
        self.nodes.len()
    }

    /// Index at which solver variables start. For CreditImpliedCurve, 0.
    pub fn ini_solve(&self) -> usize {
        0
    }
}

impl CurveQuery for CreditImpliedCurve {
    /// discount_factor returns survival probability Q(t).
    fn discount_factor(&self, date: NaiveDate) -> Number {
        self.survival_probability(date)
    }

    /// zero_rate derived from survival probabilities.
    /// r = -ln(Q(end)/Q(start)) / dcf(start, end)
    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention
            .dcf(start, end, &DcfOptions::default())
            .unwrap();
        let q_start = self.survival_probability(start);
        let q_end = self.survival_probability(end);
        let ratio = &q_end / &q_start;
        -(ratio.log()) / dcf
    }

    /// forward_rate: same as zero_rate for piecewise flat hazard rates.
    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn credit_curve_fixture() -> CreditImpliedCurve {
        // 2 nodes: 1Y=0.01, 2Y=0.02 hazard rates
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.02),
        ]));
        CreditImpliedCurve::new(
            nodes,
            DayCountConvention::Act365F,
            0.40,
            "credit_test".to_string(),
        )
    }

    #[test]
    fn test_credit_curve_survival_prob() {
        let curve = credit_curve_fixture();
        // Q(1.5Y) = exp(-0.01 * dcf(2024-01-01, 2025-01-01) - 0.02 * dcf(2025-01-01, 2025-07-01))
        let date_1_5y = ymd(2025, 7, 1);
        let q = curve.survival_probability(date_1_5y);

        let dcf_1y = 366.0 / 365.0; // 2024 is leap year
        let dcf_half = 181.0 / 365.0; // Jan 1 to Jul 1 2025
        let expected = (-0.01 * dcf_1y - 0.02 * dcf_half).exp();

        if let Number::F64(v) = q {
            assert!(
                (v - expected).abs() < 1e-10,
                "Q={v}, expected={expected}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_curve_query() {
        let curve = credit_curve_fixture();
        let date = ymd(2024, 7, 1);
        let df = curve.discount_factor(date);
        let q = curve.survival_probability(date);
        assert_eq!(df, q, "discount_factor should equal survival_probability");
    }

    #[test]
    fn test_credit_curve_before_first_node() {
        let curve = credit_curve_fixture();
        let q = curve.survival_probability(ymd(2023, 6, 1));
        assert_eq!(q, Number::F64(1.0));
    }

    #[test]
    fn test_credit_curve_at_first_node() {
        let curve = credit_curve_fixture();
        let q = curve.survival_probability(ymd(2024, 1, 1));
        assert_eq!(q, Number::F64(1.0));
    }

    #[test]
    fn test_credit_curve_extrapolation() {
        let curve = credit_curve_fixture();
        // Beyond last node (2025-01-01): uses last hazard rate (0.02) for extrapolation
        let date_3y = ymd(2027, 1, 1);
        let q = curve.survival_probability(date_3y);

        let dcf_1y = 366.0 / 365.0; // 2024 is leap year
        let dcf_ext = 730.0 / 365.0; // 2025-01-01 to 2027-01-01 = 730 days
        let expected = (-0.01 * dcf_1y - 0.02 * dcf_ext).exp();

        if let Number::F64(v) = q {
            assert!(
                (v - expected).abs() < 1e-10,
                "Q={v}, expected={expected}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_curve_hazard_rate() {
        let curve = credit_curve_fixture();
        // Before first node
        assert_eq!(curve.hazard_rate(ymd(2023, 6, 1)), Number::F64(0.01));
        // At first node
        assert_eq!(curve.hazard_rate(ymd(2024, 1, 1)), Number::F64(0.01));
        // Between nodes
        assert_eq!(curve.hazard_rate(ymd(2024, 7, 1)), Number::F64(0.01));
        // At second node
        assert_eq!(curve.hazard_rate(ymd(2025, 1, 1)), Number::F64(0.02));
        // After last node
        assert_eq!(curve.hazard_rate(ymd(2026, 1, 1)), Number::F64(0.02));
    }

    #[test]
    fn test_credit_curve_zero_rate() {
        let curve = credit_curve_fixture();
        let zr = curve.zero_rate(ymd(2024, 1, 1), ymd(2025, 1, 1));
        // Q(start) = 1.0 (at first node), Q(end) uses first hazard rate
        // zero_rate = -ln(Q(end)/Q(start)) / dcf
        // = -ln(Q(end)) / dcf = hazard_rate (for single flat segment) = 0.01
        if let Number::F64(r) = zr {
            assert!(
                (r - 0.01).abs() < 1e-10,
                "zero rate={r}, expected=0.01"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_curve_solver_support() {
        let mut curve = credit_curve_fixture();
        assert_eq!(curve.ini_solve(), 0);
        assert_eq!(curve.n_vars(), 2);

        let vals = curve.get_node_values();
        assert_eq!(vals, vec![0.01, 0.02]);

        curve.set_node_values(&[0.015, 0.025]);
        assert_eq!(curve.get_node_values(), vec![0.015, 0.025]);
    }

    #[test]
    fn test_credit_curve_ad_propagation() {
        use crate::autodiff::dual::Dual;

        let d1 = Dual::new("h0", 0.01);
        let d2 = Dual::new("h1", 0.02);
        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]));
        let curve = CreditImpliedCurve::new(
            nodes,
            DayCountConvention::Act365F,
            0.40,
            "credit_dual".to_string(),
        );

        let q = curve.survival_probability(ymd(2025, 7, 1));
        if let Number::Dual(d) = q {
            assert!(d.real() > 0.0 && d.real() < 1.0);
        } else {
            panic!("Expected Dual from survival probability");
        }
    }
}
