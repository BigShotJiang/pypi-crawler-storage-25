use chrono::{Datelike, Days, NaiveDate};
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::spread_curve::CurveContainer;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::cal::BusinessCalendar;

/// Turn-of-year adjusted curve that applies forward rate bumps at year-end dates.
///
/// This is a query-only wrapper (not calibratable). Implements CurveQuery but
/// is NOT added to CurveRef per D-17.
///
/// Positive bp bumps increase forward rates at year-end, resulting in lower
/// discount factors for dates past the year-end window.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TurnOfYearCurve {
    /// Owned wrapped curve.
    pub inner: CurveContainer,
    /// Year-end bumps: (year_end_date, bp_bump).
    /// Positive bp = higher forward rate = lower DF.
    pub bumps: Vec<(NaiveDate, f64)>,
    /// Day count convention for dcf computation.
    pub convention: DayCountConvention,
    /// Optional business calendar for determining next business day after year-end.
    pub calendar: Option<BusinessCalendar>,
    /// Curve identifier.
    pub id: String,
}

impl TurnOfYearCurve {
    pub fn new(
        inner: CurveContainer,
        bumps: Vec<(NaiveDate, f64)>,
        convention: DayCountConvention,
        calendar: Option<BusinessCalendar>,
        id: String,
    ) -> Self {
        Self {
            inner,
            bumps,
            convention,
            calendar,
            id,
        }
    }

    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap()
    }

    pub fn from_json(s: &str) -> Result<Self, serde_json::Error> {
        let mut curve: Self = serde_json::from_str(s)?;
        // Rebuild interpolator on the inner curve container
        match &mut curve.inner {
            CurveContainer::Discount(c) => c.rebuild_spline(),
            CurveContainer::Line(c) => c.rebuild_spline(),
            CurveContainer::Forward(c) => c.rebuild_spline(),
        }
        Ok(curve)
    }

    /// Find the next business day after the given date.
    /// If a calendar is provided, use it. Otherwise, use simple weekend skipping.
    fn next_business_day(&self, date: NaiveDate) -> NaiveDate {
        let next = date + Days::new(1);
        match &self.calendar {
            Some(cal) => {
                // Roll forward from the day after year-end to next business day
                let mut d = next;
                while !cal.is_business_day(d) {
                    d = d + Days::new(1);
                }
                d
            }
            None => {
                // Simple weekend skip: 5=Sat, 6=Sun (chrono num_days_from_monday)
                let mut d = next;
                loop {
                    let dow = d.weekday().num_days_from_monday();
                    if dow < 5 {
                        // weekday
                        return d;
                    }
                    d = d + Days::new(1);
                }
            }
        }
    }
}

impl CurveQuery for TurnOfYearCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        let df_base = self.inner.discount_factor(date);

        // Compute cumulative TOY adjustment
        let mut adjustment = 0.0_f64;
        for &(year_end, bp) in &self.bumps {
            let next_bd = self.next_business_day(year_end);
            if date > next_bd {
                // Full bump applies -- query is past this year-end window
                let dcf = self.convention.dcf(
                    year_end, next_bd, &DcfOptions::default()
                ).unwrap();
                adjustment += bp / 10000.0 * dcf;
            } else if date > year_end && date <= next_bd {
                // Partial bump -- query is within the year-end window
                let dcf = self.convention.dcf(
                    year_end, date, &DcfOptions::default()
                ).unwrap();
                adjustment += bp / 10000.0 * dcf;
            }
            // else: date <= year_end, no bump from this year-end
        }

        // TOY bumps are f64 only (not Number) since they are fixed parameters,
        // not AD variables (per D-20)
        df_base * Number::F64((-adjustment).exp())
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn base_discount_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2025, 1, 1), 1.0),
            (ymd(2026, 1, 1), 0.95),
            (ymd(2027, 1, 1), 0.90),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "base".to_string(),
        )
    }

    #[test]
    fn test_toy_serde_roundtrip() {
        let base = base_discount_curve();
        let curve = TurnOfYearCurve::new(
            CurveContainer::Discount(base),
            vec![(ymd(2025, 12, 31), 5.0)],
            DayCountConvention::Act365F,
            None,
            "toy_serde".to_string(),
        );

        let json = curve.to_json();
        let restored = TurnOfYearCurve::from_json(&json).expect("from_json should succeed");

        let date = ymd(2026, 1, 15);
        let df_orig = curve.discount_factor(date);
        let df_restored = restored.discount_factor(date);

        if let (Number::F64(a), Number::F64(b)) = (&df_orig, &df_restored) {
            assert!(
                (a - b).abs() < 1e-12,
                "Serde roundtrip: orig DF={}, restored DF={}",
                a,
                b
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_toy_bump_positive() {
        // +5bp bump on 2025-12-31 should make DF on 2026-01-15 lower than base
        let base = base_discount_curve();
        let curve = TurnOfYearCurve::new(
            CurveContainer::Discount(base.clone()),
            vec![(ymd(2025, 12, 31), 5.0)], // +5bp
            DayCountConvention::Act365F,
            None,
            "toy".to_string(),
        );

        let date = ymd(2026, 1, 15);
        let df_base = base.discount_factor(date);
        let df_toy = curve.discount_factor(date);

        if let (Number::F64(b), Number::F64(t)) = (&df_base, &df_toy) {
            assert!(
                t < b,
                "TOY adjusted DF ({}) should be lower than base DF ({})",
                t,
                b
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_toy_before_yearend() {
        // Dates before 2025-12-31 should have identical DF to base
        let base = base_discount_curve();
        let curve = TurnOfYearCurve::new(
            CurveContainer::Discount(base.clone()),
            vec![(ymd(2025, 12, 31), 5.0)],
            DayCountConvention::Act365F,
            None,
            "toy".to_string(),
        );

        let date = ymd(2025, 6, 15);
        let df_base = base.discount_factor(date);
        let df_toy = curve.discount_factor(date);

        if let (Number::F64(b), Number::F64(t)) = (&df_base, &df_toy) {
            assert!(
                (t - b).abs() < 1e-15,
                "Before year-end, TOY DF ({}) should equal base DF ({})",
                t,
                b
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_toy_multiple_bumps() {
        // Two year-end bumps should accumulate
        let base = base_discount_curve();
        let single_bump = TurnOfYearCurve::new(
            CurveContainer::Discount(base.clone()),
            vec![(ymd(2025, 12, 31), 5.0)],
            DayCountConvention::Act365F,
            None,
            "toy_single".to_string(),
        );

        let double_bump = TurnOfYearCurve::new(
            CurveContainer::Discount(base.clone()),
            vec![
                (ymd(2025, 12, 31), 5.0),
                (ymd(2026, 12, 31), 5.0),
            ],
            DayCountConvention::Act365F,
            None,
            "toy_double".to_string(),
        );

        // Query a date past both year-ends
        // Base curve only goes to 2027-01-01 so query within range
        let date = ymd(2027, 1, 1);
        let df_single = single_bump.discount_factor(date);
        let df_double = double_bump.discount_factor(date);

        if let (Number::F64(s), Number::F64(d)) = (&df_single, &df_double) {
            assert!(
                d < s,
                "Double bump DF ({}) should be lower than single bump DF ({})",
                d,
                s
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_toy_sign_convention() {
        // Positive bp = higher forward rate = LOWER DF
        let base = base_discount_curve();
        let positive_bump = TurnOfYearCurve::new(
            CurveContainer::Discount(base.clone()),
            vec![(ymd(2025, 12, 31), 10.0)], // +10bp
            DayCountConvention::Act365F,
            None,
            "toy_pos".to_string(),
        );

        let negative_bump = TurnOfYearCurve::new(
            CurveContainer::Discount(base.clone()),
            vec![(ymd(2025, 12, 31), -10.0)], // -10bp
            DayCountConvention::Act365F,
            None,
            "toy_neg".to_string(),
        );

        let date = ymd(2026, 1, 15);
        let df_base = base.discount_factor(date);
        let df_pos = positive_bump.discount_factor(date);
        let df_neg = negative_bump.discount_factor(date);

        if let (Number::F64(b), Number::F64(p), Number::F64(n)) =
            (&df_base, &df_pos, &df_neg)
        {
            assert!(p < b, "Positive bump DF ({}) should be < base DF ({})", p, b);
            assert!(n > b, "Negative bump DF ({}) should be > base DF ({})", n, b);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_toy_at_yearend_date() {
        // At exactly the year-end date, no bump should apply
        let base = base_discount_curve();
        let curve = TurnOfYearCurve::new(
            CurveContainer::Discount(base.clone()),
            vec![(ymd(2025, 12, 31), 50.0)], // large bump
            DayCountConvention::Act365F,
            None,
            "toy".to_string(),
        );

        let date = ymd(2025, 12, 31);
        let df_base = base.discount_factor(date);
        let df_toy = curve.discount_factor(date);

        if let (Number::F64(b), Number::F64(t)) = (&df_base, &df_toy) {
            assert!(
                (t - b).abs() < 1e-15,
                "At year-end date itself, TOY DF ({}) should equal base DF ({})",
                t,
                b
            );
        } else {
            panic!("Expected F64");
        }
    }
}
