use serde::{Serialize, Deserialize};

/// FXPair represents a currency pair such as "eurusd" (EUR/USD).
/// lhs is the base (numerator) currency, rhs is the quote (denominator) currency.
/// Both are stored as lowercase 3-character ISO codes.
#[derive(Clone, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct FXPair {
    pub lhs: String,
    pub rhs: String,
}

impl FXPair {
    /// Create a new FXPair from two currency codes.
    /// Lowercases and validates 3-character length.
    pub fn new(lhs: &str, rhs: &str) -> Self {
        let lhs_lower = lhs.to_lowercase();
        let rhs_lower = rhs.to_lowercase();
        assert!(
            lhs_lower.len() == 3,
            "Currency code must be 3 characters, got '{}'",
            lhs
        );
        assert!(
            rhs_lower.len() == 3,
            "Currency code must be 3 characters, got '{}'",
            rhs
        );
        assert!(
            lhs_lower != rhs_lower,
            "FXPair must have two distinct currencies, got '{}'",
            lhs_lower
        );
        Self {
            lhs: lhs_lower,
            rhs: rhs_lower,
        }
    }

    /// Parse a 6-character string like "eurusd" into FXPair { lhs: "eur", rhs: "usd" }.
    pub fn from_str(s: &str) -> Result<Self, String> {
        let lower = s.to_lowercase();
        if lower.len() != 6 {
            return Err(format!(
                "FXPair string must be 6 characters, got '{}' ({})",
                s,
                s.len()
            ));
        }
        let lhs = &lower[..3];
        let rhs = &lower[3..];
        if lhs == rhs {
            return Err(format!(
                "FXPair must have two distinct currencies, got '{}'",
                s
            ));
        }
        Ok(Self {
            lhs: lhs.to_string(),
            rhs: rhs.to_string(),
        })
    }

    /// Return the inverted pair (swap lhs and rhs).
    pub fn invert(&self) -> FXPair {
        FXPair {
            lhs: self.rhs.clone(),
            rhs: self.lhs.clone(),
        }
    }
}

impl std::fmt::Display for FXPair {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "{}{}", self.lhs, self.rhs)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fxpair_parse() {
        let pair = FXPair::from_str("eurusd").unwrap();
        assert_eq!(pair.lhs, "eur");
        assert_eq!(pair.rhs, "usd");
    }

    #[test]
    fn test_fxpair_parse_uppercase() {
        let pair = FXPair::from_str("EURUSD").unwrap();
        assert_eq!(pair.lhs, "eur");
        assert_eq!(pair.rhs, "usd");
    }

    #[test]
    fn test_fxpair_invert() {
        let pair = FXPair::new("eur", "usd");
        let inv = pair.invert();
        assert_eq!(inv.lhs, "usd");
        assert_eq!(inv.rhs, "eur");
    }

    #[test]
    fn test_fxpair_to_string() {
        let pair = FXPair::new("eur", "usd");
        assert_eq!(pair.to_string(), "eurusd");
    }

    #[test]
    fn test_fxpair_equality() {
        let a = FXPair::new("eur", "usd");
        let b = FXPair::from_str("eurusd").unwrap();
        assert_eq!(a, b);
    }

    #[test]
    fn test_fxpair_invalid_length() {
        assert!(FXPair::from_str("eu").is_err());
        assert!(FXPair::from_str("eurusdd").is_err());
    }

    #[test]
    fn test_fxpair_same_currency() {
        assert!(FXPair::from_str("usdusd").is_err());
    }

    #[test]
    #[should_panic(expected = "distinct currencies")]
    fn test_fxpair_new_same_currency() {
        FXPair::new("usd", "usd");
    }
}
