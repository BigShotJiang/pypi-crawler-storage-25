use std::collections::{HashMap, VecDeque};

use chrono::NaiveDate;
use indexmap::IndexSet;
use serde::{Serialize, Deserialize};
use std::sync::Arc;

use crate::autodiff::dual::Dual;
use crate::autodiff::enums::Number;
use crate::marketcurves::fx::pair::FXPair;

/// FXRates stores a set of quoted FX pairs and computes cross rates via
/// graph-based BFS triangulation. All rates are stored as Number (Dual when
/// AD is active) with auto-created variable names "fx_{lhs}{rhs}".
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FXRates {
    /// The quoted FX pairs.
    pub pairs: Vec<FXPair>,
    /// The rates for each quoted pair (Dual variables for AD).
    pub rates: Vec<Number>,
    /// Settlement date for all FX rates.
    pub settlement: NaiveDate,
    /// Adjacency list: currency -> Vec<(neighbor_ccy, rate_index, is_inverted)>.
    #[serde(skip)]
    adjacency: HashMap<String, Vec<(String, usize, bool)>>,
    /// All currencies extracted from pairs, sorted.
    pub currencies: Vec<String>,
}

impl FXRates {
    /// Create FXRates from quoted pairs and their rates.
    ///
    /// Validates that exactly N-1 pairs are provided for N currencies (spanning tree)
    /// and that the graph is connected.
    ///
    /// Auto-creates Dual variables with names "fx_{lhs}{rhs}" for each quoted rate.
    pub fn new(fx_rates: Vec<(FXPair, f64)>, settlement: NaiveDate) -> Self {
        // Extract unique currencies
        let mut ccy_set: IndexSet<String> = IndexSet::new();
        for (pair, _) in &fx_rates {
            ccy_set.insert(pair.lhs.clone());
            ccy_set.insert(pair.rhs.clone());
        }
        ccy_set.sort();
        let currencies: Vec<String> = ccy_set.into_iter().collect();
        let n_ccy = currencies.len();
        let n_pairs = fx_rates.len();

        // Validate spanning tree: need exactly N-1 pairs for N currencies
        assert!(
            n_pairs == n_ccy - 1,
            "Expected {} pairs for {} currencies (spanning tree), got {}",
            n_ccy - 1,
            n_ccy,
            n_pairs
        );

        let pairs: Vec<FXPair> = fx_rates.iter().map(|(p, _)| p.clone()).collect();

        // Create Dual variables with shared vars set
        let var_names: Vec<String> = pairs
            .iter()
            .map(|p| format!("fx_{}", p))
            .collect();
        let arc_vars = Arc::new(IndexSet::from_iter(var_names.clone()));

        let rates: Vec<Number> = fx_rates
            .iter()
            .enumerate()
            .map(|(idx, (_, rate))| {
                let mut dual_vec = vec![0.0; n_pairs];
                dual_vec[idx] = 1.0;
                let d = Dual::try_new(*rate, var_names.clone(), dual_vec).unwrap();
                // Ensure shared Arc by re-creating with the shared arc
                let d_shared = Dual {
                    real: d.real,
                    vars: Arc::clone(&arc_vars),
                    dual: d.dual,
                };
                Number::Dual(d_shared)
            })
            .collect();

        // Build adjacency
        let adjacency = Self::build_adjacency(&pairs);

        // Validate connectivity
        assert!(
            Self::is_connected(&adjacency, &currencies),
            "FX rate graph is not connected -- currencies are not all reachable"
        );

        Self {
            pairs,
            rates,
            settlement,
            adjacency,
            currencies,
        }
    }

    /// Create FXRates from pre-computed Number rates (used by restate).
    /// Does NOT auto-create Dual variables -- preserves existing AD structure.
    pub fn from_number_rates(
        pairs: Vec<FXPair>,
        rates: Vec<Number>,
        settlement: NaiveDate,
    ) -> Self {
        let mut ccy_set: IndexSet<String> = IndexSet::new();
        for pair in &pairs {
            ccy_set.insert(pair.lhs.clone());
            ccy_set.insert(pair.rhs.clone());
        }
        ccy_set.sort();
        let currencies: Vec<String> = ccy_set.into_iter().collect();

        let adjacency = Self::build_adjacency(&pairs);

        Self {
            pairs,
            rates,
            settlement,
            adjacency,
            currencies,
        }
    }

    /// Build adjacency list from pairs.
    fn build_adjacency(pairs: &[FXPair]) -> HashMap<String, Vec<(String, usize, bool)>> {
        let mut adjacency: HashMap<String, Vec<(String, usize, bool)>> = HashMap::new();
        for (idx, pair) in pairs.iter().enumerate() {
            adjacency
                .entry(pair.lhs.clone())
                .or_default()
                .push((pair.rhs.clone(), idx, false));
            adjacency
                .entry(pair.rhs.clone())
                .or_default()
                .push((pair.lhs.clone(), idx, true));
        }
        adjacency
    }

    /// Check that all currencies are reachable (graph is connected).
    fn is_connected(
        adjacency: &HashMap<String, Vec<(String, usize, bool)>>,
        currencies: &[String],
    ) -> bool {
        if currencies.is_empty() {
            return true;
        }
        let mut visited: HashMap<String, bool> = HashMap::new();
        let mut queue: VecDeque<String> = VecDeque::new();
        queue.push_back(currencies[0].clone());
        visited.insert(currencies[0].clone(), true);

        while let Some(ccy) = queue.pop_front() {
            if let Some(neighbors) = adjacency.get(&ccy) {
                for (neighbor, _, _) in neighbors {
                    if !visited.contains_key(neighbor) {
                        visited.insert(neighbor.clone(), true);
                        queue.push_back(neighbor.clone());
                    }
                }
            }
        }
        visited.len() == currencies.len()
    }

    /// BFS shortest path from one currency to another.
    /// Returns a list of (rate_index, is_inverted) edges along the path.
    fn bfs_path(&self, from: &str, to: &str) -> Option<Vec<(usize, bool)>> {
        if from == to {
            return Some(vec![]);
        }

        let mut visited: HashMap<String, bool> = HashMap::new();
        // parent[ccy] = (prev_ccy, rate_idx, inverted)
        let mut parent: HashMap<String, (String, usize, bool)> = HashMap::new();
        let mut queue: VecDeque<String> = VecDeque::new();

        visited.insert(from.to_string(), true);
        queue.push_back(from.to_string());

        while let Some(ccy) = queue.pop_front() {
            if let Some(neighbors) = self.adjacency.get(&ccy) {
                for (neighbor, rate_idx, inverted) in neighbors {
                    if !visited.contains_key(neighbor) {
                        visited.insert(neighbor.clone(), true);
                        parent.insert(neighbor.clone(), (ccy.clone(), *rate_idx, *inverted));
                        if neighbor == to {
                            // Reconstruct path
                            let mut path = Vec::new();
                            let mut current = to.to_string();
                            while let Some((prev, idx, inv)) = parent.get(&current) {
                                path.push((*idx, *inv));
                                current = prev.clone();
                            }
                            path.reverse();
                            return Some(path);
                        }
                        queue.push_back(neighbor.clone());
                    }
                }
            }
        }
        None
    }

    /// Get the FX rate for a given pair, computed via BFS triangulation.
    /// For forward edges, multiplies by the rate; for inverted edges, divides.
    pub fn rate(&self, pair: &FXPair) -> Number {
        let path = self
            .bfs_path(&pair.lhs, &pair.rhs)
            .unwrap_or_else(|| panic!("No path found from {} to {}", pair.lhs, pair.rhs));

        if path.is_empty() {
            // Same currency
            return Number::F64(1.0);
        }

        let mut result: Number = Number::F64(1.0);
        for (rate_idx, inverted) in &path {
            if *inverted {
                result = &result / &self.rates[*rate_idx];
            } else {
                result = &result * &self.rates[*rate_idx];
            }
        }
        result
    }

    /// Get the FX rate between two currency codes.
    /// Returns 1.0 for same currency. Convenience wrapper around rate().
    pub fn rate_for_ccy(&self, domestic: &str, foreign: &str) -> Number {
        if domestic == foreign {
            return Number::F64(1.0);
        }
        let pair = FXPair::new(domestic, foreign);
        self.rate(&pair)
    }

    /// Convert a value from one currency to another.
    /// value is in `domestic` currency, result is in `foreign` currency.
    pub fn convert(&self, value: &Number, domestic: &str, foreign: &str) -> Number {
        let pair = FXPair::new(domestic, foreign);
        let fx = self.rate(&pair);
        value * &fx
    }

    /// Convert a set of currency positions to a single base currency.
    pub fn convert_positions(
        &self,
        positions: &HashMap<String, Number>,
        base: &str,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for (ccy, value) in positions {
            if ccy == base {
                total = &total + value;
            } else {
                total = &total + &self.convert(value, ccy, base);
            }
        }
        total
    }

    /// Set FX rates as Dual variables within the solver's unified variable namespace.
    ///
    /// This integrates FX rates into the solver's AD system so the Jacobian includes
    /// FX rate sensitivities (D-49). Each rate gets a Dual with derivative 1.0 at
    /// position (offset + i) in the shared variable set.
    pub fn set_rates_as_dual(
        &mut self,
        var_names: Arc<IndexSet<String>>,
        offset: usize,
    ) {
        use ndarray::Array1;

        let n_vars_total = var_names.len();
        self.rates = self.rates.iter().enumerate().map(|(i, rate)| {
            let real = match rate {
                Number::F64(v) => *v,
                Number::Dual(d) => d.real,
                Number::Dual2(d) => d.real,
            };
            let var_idx = offset + i;
            let mut dual_vec = Array1::zeros(n_vars_total);
            if var_idx < n_vars_total {
                dual_vec[var_idx] = 1.0;
            }
            Number::Dual(Dual {
                real,
                vars: Arc::clone(&var_names),
                dual: dual_vec,
            })
        }).collect();
    }

    /// Get the f64 values of all FX rates (extracting reals from Dual if needed).
    pub fn get_rate_values_f64(&self) -> Vec<f64> {
        self.rates.iter().map(|r| match r {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        }).collect()
    }

    /// Variable names for FX rates in the solver namespace: "fx_{pair}".
    pub fn var_names(&self) -> Vec<String> {
        self.pairs.iter().map(|p| format!("fx_{}", p)).collect()
    }

    /// Number of FX rate variables.
    pub fn n_fx_vars(&self) -> usize {
        self.pairs.len()
    }

    /// Rebuild adjacency after deserialization.
    pub fn rebuild_adjacency(&mut self) {
        self.adjacency = Self::build_adjacency(&self.pairs);
    }

    /// Serialize to JSON string.
    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap()
    }

    /// Deserialize from JSON string, rebuilding adjacency.
    pub fn from_json(s: &str) -> Result<Self, serde_json::Error> {
        let mut fx: Self = serde_json::from_str(s)?;
        fx.rebuild_adjacency();
        Ok(fx)
    }

    /// Re-express the FX rates with different base pairs while preserving AD sensitivities.
    /// Each new pair's rate is computed from the current graph, keeping full AD chain.
    pub fn restate(&self, new_pairs: &[FXPair]) -> FXRates {
        let new_rates: Vec<Number> = new_pairs
            .iter()
            .map(|p| self.rate(p))
            .collect();
        FXRates::from_number_rates(new_pairs.to_vec(), new_rates, self.settlement)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn sample_rates() -> FXRates {
        FXRates::new(
            vec![
                (FXPair::new("eur", "usd"), 1.1),
                (FXPair::new("usd", "jpy"), 110.0),
            ],
            ymd(2024, 1, 15),
        )
    }

    #[test]
    fn test_fxrates_direct_rate() {
        let fxr = sample_rates();
        let rate = fxr.rate(&FXPair::new("eur", "usd"));
        if let Number::Dual(d) = &rate {
            assert!((d.real - 1.1).abs() < 1e-12);
        } else {
            panic!("Expected Dual, got {:?}", rate);
        }
    }

    #[test]
    fn test_fxrates_cross_rate() {
        let fxr = sample_rates();
        let rate = fxr.rate(&FXPair::new("eur", "jpy"));
        if let Number::Dual(d) = &rate {
            // 1.1 * 110.0 = 121.0
            assert!(
                (d.real - 121.0).abs() < 1e-10,
                "Cross rate should be ~121.0, got {}",
                d.real
            );
        } else {
            panic!("Expected Dual, got {:?}", rate);
        }
    }

    #[test]
    fn test_fxrates_inverse_rate() {
        let fxr = sample_rates();
        let rate = fxr.rate(&FXPair::new("usd", "eur"));
        if let Number::Dual(d) = &rate {
            let expected = 1.0 / 1.1;
            assert!(
                (d.real - expected).abs() < 1e-10,
                "Inverse rate should be ~{}, got {}",
                expected,
                d.real
            );
        } else {
            panic!("Expected Dual, got {:?}", rate);
        }
    }

    #[test]
    fn test_fxrates_ad_propagation() {
        let fxr = sample_rates();
        // Cross rate eurjpy = eurusd * usdjpy
        let rate = fxr.rate(&FXPair::new("eur", "jpy"));
        if let Number::Dual(d) = &rate {
            // d(eurjpy)/d(eurusd) = usdjpy = 110.0
            // d(eurjpy)/d(usdjpy) = eurusd = 1.1
            let idx_eurusd = d.vars.get_index_of("fx_eurusd").unwrap();
            let idx_usdjpy = d.vars.get_index_of("fx_usdjpy").unwrap();
            assert!(
                (d.dual[idx_eurusd] - 110.0).abs() < 1e-10,
                "Gradient wrt eurusd should be 110.0, got {}",
                d.dual[idx_eurusd]
            );
            assert!(
                (d.dual[idx_usdjpy] - 1.1).abs() < 1e-10,
                "Gradient wrt usdjpy should be 1.1, got {}",
                d.dual[idx_usdjpy]
            );
        } else {
            panic!("Expected Dual, got {:?}", rate);
        }
    }

    #[test]
    fn test_fxrates_convert() {
        let fxr = sample_rates();
        let value = Number::F64(100.0);
        let converted = fxr.convert(&value, "eur", "usd");
        if let Number::Dual(d) = &converted {
            assert!(
                (d.real - 110.0).abs() < 1e-10,
                "100 EUR -> USD should be ~110.0, got {}",
                d.real
            );
        } else {
            panic!("Expected Dual, got {:?}", converted);
        }
    }

    #[test]
    fn test_fxrates_convert_positions() {
        let fxr = sample_rates();
        let mut positions = HashMap::new();
        positions.insert("eur".to_string(), Number::F64(100.0));
        positions.insert("usd".to_string(), Number::F64(50.0));
        let total = fxr.convert_positions(&positions, "usd");
        if let Number::Dual(d) = &total {
            // 100 EUR * 1.1 + 50 USD = 160.0
            assert!(
                (d.real - 160.0).abs() < 1e-10,
                "Total in USD should be ~160.0, got {}",
                d.real
            );
        } else {
            panic!("Expected Dual, got {:?}", total);
        }
    }

    #[test]
    fn test_fxrates_restate() {
        let fxr = sample_rates();
        // Restate with different pairs
        let new_pairs = vec![
            FXPair::new("usd", "eur"),
            FXPair::new("eur", "jpy"),
        ];
        let restated = fxr.restate(&new_pairs);

        // Check usdeur rate
        let usdeur = restated.rate(&FXPair::new("usd", "eur"));
        if let Number::Dual(d) = &usdeur {
            let expected = 1.0 / 1.1;
            assert!(
                (d.real - expected).abs() < 1e-10,
                "Restated usdeur should be ~{}, got {}",
                expected,
                d.real
            );
        } else {
            panic!("Expected Dual, got {:?}", usdeur);
        }

        // Check eurjpy rate
        let eurjpy = restated.rate(&FXPair::new("eur", "jpy"));
        if let Number::Dual(d) = &eurjpy {
            assert!(
                (d.real - 121.0).abs() < 1e-10,
                "Restated eurjpy should be ~121.0, got {}",
                d.real
            );
        } else {
            panic!("Expected Dual, got {:?}", eurjpy);
        }
    }

    #[test]
    #[should_panic(expected = "Expected 1 pairs for 2 currencies")]
    fn test_fxrates_validation_cycle() {
        // 2 pairs for 2 currencies is a cycle (overspecified)
        FXRates::new(
            vec![
                (FXPair::new("eur", "usd"), 1.1),
                (FXPair::new("usd", "eur"), 0.909),
            ],
            ymd(2024, 1, 15),
        );
    }

    #[test]
    fn test_fxrates_same_currency_rate() {
        let fxr = sample_rates();
        // Use from_str to test; rate() handles lhs==rhs internally
        let rate = fxr.rate_for_ccy("usd", "usd");
        if let Number::F64(v) = rate {
            assert!((v - 1.0).abs() < 1e-12);
        } else {
            panic!("Expected F64(1.0) for same currency");
        }
    }
}
