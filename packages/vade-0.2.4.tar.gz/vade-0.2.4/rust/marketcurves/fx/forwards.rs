use std::collections::HashMap;

use chrono::NaiveDate;

use crate::autodiff::enums::Number;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::fx::pair::FXPair;
use crate::marketcurves::fx::rates::FXRates;

/// FXForwards computes forward FX rates via interest rate parity (IRP).
///
/// Forward = Spot * DF_domestic / DF_foreign
///
/// where domestic is the lhs (numerator) currency and foreign is the rhs
/// (denominator) currency of the FXPair.
#[derive(Clone, Debug)]
pub struct FXForwards {
    /// The spot FX rates.
    pub fx_rates: FXRates,
    /// Per-pair settlement dates, keyed by pair string (e.g. "eurusd").
    pub settlements: HashMap<String, NaiveDate>,
}

impl FXForwards {
    /// Create a new FXForwards from spot rates and settlement dates.
    pub fn new(fx_rates: FXRates, settlements: HashMap<String, NaiveDate>) -> Self {
        Self {
            fx_rates,
            settlements,
        }
    }

    /// Forward FX rate via IRP: F(t) = S * DF_dom(t) / DF_for(t)
    pub fn rate(
        &self,
        pair: &FXPair,
        delivery: NaiveDate,
        curves: &HashMap<String, &dyn CurveQuery>,
    ) -> Number {
        let spot = self.fx_rates.rate(pair);
        let dom_curve = curves
            .get(&pair.lhs)
            .unwrap_or_else(|| panic!("Missing discount curve for domestic currency '{}'", pair.lhs));
        let for_curve = curves
            .get(&pair.rhs)
            .unwrap_or_else(|| panic!("Missing discount curve for foreign currency '{}'", pair.rhs));
        let df_dom = dom_curve.discount_factor(delivery);
        let df_for = for_curve.discount_factor(delivery);
        // Forward = Spot * DF_dom / DF_for
        &(&spot * &df_dom) / &df_for
    }

    /// Forward FX points (forward - spot).
    pub fn points(
        &self,
        pair: &FXPair,
        delivery: NaiveDate,
        curves: &HashMap<String, &dyn CurveQuery>,
    ) -> Number {
        let forward = self.rate(pair, delivery, curves);
        let spot = self.fx_rates.rate(pair);
        &forward - &spot
    }

    /// Swap points (same as points for standard convention).
    pub fn swap_points(
        &self,
        pair: &FXPair,
        delivery: NaiveDate,
        curves: &HashMap<String, &dyn CurveQuery>,
    ) -> Number {
        self.points(pair, delivery, curves)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::autodiff::dual::Dual;
    use crate::calendar::convention::DayCountConvention;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    /// Create a simple DiscountCurve from f64 nodes.
    fn make_discount_curve(
        nodes: Vec<(NaiveDate, f64)>,
        id: &str,
    ) -> DiscountCurve {
        let map: IndexMap<NaiveDate, f64> = nodes.into_iter().collect();
        let nodes = Nodes::from_f64_map(map);
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            id.to_string(),
        )
    }

    fn sample_fxforwards() -> (FXForwards, DiscountCurve, DiscountCurve) {
        let fx_rates = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        );
        let settlements = HashMap::from([("eurusd".to_string(), ymd(2024, 1, 17))]);
        let fxf = FXForwards::new(fx_rates, settlements);

        // EUR discount curve: DF=1.0 at spot, ~0.98 at 1y
        let eur_curve = make_discount_curve(
            vec![
                (ymd(2024, 1, 15), 1.0),
                (ymd(2025, 1, 15), 0.97),
            ],
            "eur_disc",
        );

        // USD discount curve: DF=1.0 at spot, ~0.95 at 1y
        let usd_curve = make_discount_curve(
            vec![
                (ymd(2024, 1, 15), 1.0),
                (ymd(2025, 1, 15), 0.95),
            ],
            "usd_disc",
        );

        (fxf, eur_curve, usd_curve)
    }

    #[test]
    fn test_fx_forward_rate() {
        let (fxf, eur_curve, usd_curve) = sample_fxforwards();
        let curves: HashMap<String, &dyn CurveQuery> = HashMap::from([
            ("eur".to_string(), &eur_curve as &dyn CurveQuery),
            ("usd".to_string(), &usd_curve as &dyn CurveQuery),
        ]);

        let pair = FXPair::new("eur", "usd");
        let delivery = ymd(2025, 1, 15);
        let forward = fxf.rate(&pair, delivery, &curves);

        // Forward = Spot * DF_eur / DF_usd = 1.1 * 0.97 / 0.95
        let expected = 1.1 * 0.97 / 0.95;
        match &forward {
            Number::Dual(d) => {
                assert!(
                    (d.real - expected).abs() < 1e-10,
                    "Forward should be ~{}, got {}",
                    expected,
                    d.real
                );
            }
            Number::F64(v) => {
                assert!(
                    (v - expected).abs() < 1e-10,
                    "Forward should be ~{}, got {}",
                    expected,
                    v
                );
            }
            _ => panic!("Unexpected type {:?}", forward),
        }
    }

    #[test]
    fn test_fx_forward_points() {
        let (fxf, eur_curve, usd_curve) = sample_fxforwards();
        let curves: HashMap<String, &dyn CurveQuery> = HashMap::from([
            ("eur".to_string(), &eur_curve as &dyn CurveQuery),
            ("usd".to_string(), &usd_curve as &dyn CurveQuery),
        ]);

        let pair = FXPair::new("eur", "usd");
        let delivery = ymd(2025, 1, 15);
        let pts = fxf.points(&pair, delivery, &curves);

        // points = forward - spot = 1.1 * 0.97/0.95 - 1.1
        let expected = 1.1 * 0.97 / 0.95 - 1.1;
        match &pts {
            Number::Dual(d) => {
                assert!(
                    (d.real - expected).abs() < 1e-10,
                    "Points should be ~{}, got {}",
                    expected,
                    d.real
                );
            }
            Number::F64(v) => {
                assert!(
                    (v - expected).abs() < 1e-10,
                    "Points should be ~{}, got {}",
                    expected,
                    v
                );
            }
            _ => panic!("Unexpected type"),
        }
    }

    #[test]
    fn test_fx_forward_at_spot_date() {
        let (fxf, eur_curve, usd_curve) = sample_fxforwards();
        let curves: HashMap<String, &dyn CurveQuery> = HashMap::from([
            ("eur".to_string(), &eur_curve as &dyn CurveQuery),
            ("usd".to_string(), &usd_curve as &dyn CurveQuery),
        ]);

        let pair = FXPair::new("eur", "usd");
        // Delivery at settlement -> DFs are both 1.0 -> forward ~ spot
        let delivery = ymd(2024, 1, 15);
        let forward = fxf.rate(&pair, delivery, &curves);

        match &forward {
            Number::Dual(d) => {
                assert!(
                    (d.real - 1.1).abs() < 1e-10,
                    "Forward at spot date should be ~spot (1.1), got {}",
                    d.real
                );
            }
            Number::F64(v) => {
                assert!(
                    (v - 1.1).abs() < 1e-10,
                    "Forward at spot date should be ~spot (1.1), got {}",
                    v
                );
            }
            _ => panic!("Unexpected type"),
        }
    }

    #[test]
    fn test_fx_forward_inverse() {
        let (fxf, eur_curve, usd_curve) = sample_fxforwards();
        let curves: HashMap<String, &dyn CurveQuery> = HashMap::from([
            ("eur".to_string(), &eur_curve as &dyn CurveQuery),
            ("usd".to_string(), &usd_curve as &dyn CurveQuery),
        ]);

        let delivery = ymd(2025, 1, 15);
        let fwd_eurusd = fxf.rate(&FXPair::new("eur", "usd"), delivery, &curves);
        let fwd_usdeur = fxf.rate(&FXPair::new("usd", "eur"), delivery, &curves);

        // forward(eurusd) * forward(usdeur) ~ 1.0
        let product = &fwd_eurusd * &fwd_usdeur;
        match &product {
            Number::Dual(d) => {
                assert!(
                    (d.real - 1.0).abs() < 1e-8,
                    "Forward * inverse forward should be ~1.0, got {}",
                    d.real
                );
            }
            Number::F64(v) => {
                assert!(
                    (v - 1.0).abs() < 1e-8,
                    "Forward * inverse forward should be ~1.0, got {}",
                    v
                );
            }
            _ => panic!("Unexpected type"),
        }
    }

    #[test]
    fn test_fx_forward_ad() {
        // Use Dual curves to verify AD propagation through forwards
        let fx_rates = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        );
        let settlements = HashMap::from([("eurusd".to_string(), ymd(2024, 1, 17))]);
        let fxf = FXForwards::new(fx_rates, settlements);

        // Create Dual-aware discount curves
        let d_eur_1 = Dual::new("eur_df1", 1.0);
        let d_eur_2 = Dual::new("eur_df2", 0.97);
        let eur_nodes = Nodes::from_dual_map(IndexMap::from([
            (ymd(2024, 1, 15), d_eur_1),
            (ymd(2025, 1, 15), d_eur_2),
        ]));
        let eur_curve = DiscountCurve::new(
            eur_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "eur_disc".to_string(),
        );

        let d_usd_1 = Dual::new("usd_df1", 1.0);
        let d_usd_2 = Dual::new("usd_df2", 0.95);
        let usd_nodes = Nodes::from_dual_map(IndexMap::from([
            (ymd(2024, 1, 15), d_usd_1),
            (ymd(2025, 1, 15), d_usd_2),
        ]));
        let usd_curve = DiscountCurve::new(
            usd_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "usd_disc".to_string(),
        );

        let curves: HashMap<String, &dyn CurveQuery> = HashMap::from([
            ("eur".to_string(), &eur_curve as &dyn CurveQuery),
            ("usd".to_string(), &usd_curve as &dyn CurveQuery),
        ]);

        let pair = FXPair::new("eur", "usd");
        let forward = fxf.rate(&pair, ymd(2025, 1, 15), &curves);

        // Forward should be Dual with sensitivities to fx_eurusd, eur_df2, usd_df2
        match &forward {
            Number::Dual(d) => {
                let expected = 1.1 * 0.97 / 0.95;
                assert!(
                    (d.real - expected).abs() < 1e-10,
                    "Forward real should be ~{}, got {}",
                    expected,
                    d.real
                );
                // Should have sensitivities to the FX rate
                assert!(
                    d.vars.contains("fx_eurusd"),
                    "Forward Dual should contain fx_eurusd variable"
                );
            }
            _ => panic!("Expected Dual from forward with AD curves, got {:?}", forward),
        }
    }
}
