use std::collections::HashMap;

use chrono::NaiveDate;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::autodiff::enums::Number;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::py::{PyDiscountCurve, PyLineCurve, PyNelsonSiegel, PyNelsonSiegelSvensson, PySmithWilson};
use crate::marketcurves::fx::pair::FXPair;
use crate::marketcurves::fx::rates::FXRates;
use crate::marketcurves::fx::forwards::FXForwards;

// ---- Helper: Number -> Py<PyAny> ----

fn number_to_py(py: Python<'_>, n: Number) -> PyResult<Py<PyAny>> {
    match n {
        Number::F64(f) => Ok(f.into_pyobject(py).expect("f64 to py").into_any().unbind()),
        Number::Dual(d) => Ok(Py::new(py, d)?.into_any()),
        Number::Dual2(d) => Ok(Py::new(py, d)?.into_any()),
    }
}

fn extract_curve_ref<'py>(obj: &Bound<'py, PyAny>) -> PyResult<Box<dyn CurveQuery + 'py>> {
    if let Ok(dc) = obj.extract::<PyRef<'py, PyDiscountCurve>>() {
        Ok(Box::new(dc.inner.clone()))
    } else if let Ok(lc) = obj.extract::<PyRef<'py, PyLineCurve>>() {
        Ok(Box::new(lc.inner.clone()))
    } else if let Ok(ns) = obj.extract::<PyRef<'py, PyNelsonSiegel>>() {
        Ok(Box::new(ns.inner.clone()))
    } else if let Ok(nss) = obj.extract::<PyRef<'py, PyNelsonSiegelSvensson>>() {
        Ok(Box::new(nss.inner.clone()))
    } else if let Ok(sw) = obj.extract::<PyRef<'py, PySmithWilson>>() {
        Ok(Box::new(sw.inner.clone()))
    } else {
        Err(PyValueError::new_err(
            "curve must be a DiscountCurve, LineCurve, NelsonSiegel, NelsonSiegelSvensson, or SmithWilson",
        ))
    }
}

// ---- PyFXPair ----

#[pyclass(name = "FXPair", module = "vade._vade_rs.fx", from_py_object)]
#[derive(Clone)]
pub struct PyFXPair {
    pub inner: FXPair,
}

#[pymethods]
impl PyFXPair {
    #[new]
    fn new(pair_str: &str) -> PyResult<Self> {
        FXPair::from_str(pair_str)
            .map(|inner| PyFXPair { inner })
            .map_err(|e| PyValueError::new_err(e))
    }

    #[getter]
    fn lhs(&self) -> String {
        self.inner.lhs.clone()
    }

    #[getter]
    fn rhs(&self) -> String {
        self.inner.rhs.clone()
    }

    fn invert(&self) -> PyFXPair {
        PyFXPair {
            inner: self.inner.invert(),
        }
    }

    fn __repr__(&self) -> String {
        format!("FXPair('{}')", self.inner)
    }

    fn __str__(&self) -> String {
        self.inner.to_string()
    }
}

// ---- PyFXRates ----

#[pyclass(name = "FXRates", module = "vade._vade_rs.fx", from_py_object)]
#[derive(Clone)]
pub struct PyFXRates {
    pub inner: FXRates,
}

#[pymethods]
impl PyFXRates {
    #[new]
    fn new(fx_rates: HashMap<String, f64>, settlement: NaiveDate) -> PyResult<Self> {
        let mut pairs_rates = Vec::new();
        for (key, rate) in fx_rates {
            let pair = FXPair::from_str(&key)
                .map_err(|e| PyValueError::new_err(e))?;
            pairs_rates.push((pair, rate));
        }
        if pairs_rates.is_empty() {
            return Err(PyValueError::new_err("fx_rates dict must not be empty"));
        }
        Ok(PyFXRates {
            inner: FXRates::new(pairs_rates, settlement),
        })
    }

    fn rate(&self, py: Python<'_>, pair: &str) -> PyResult<Py<PyAny>> {
        let fx_pair = FXPair::from_str(pair)
            .map_err(|e| PyValueError::new_err(e))?;
        let result = self.inner.rate(&fx_pair);
        number_to_py(py, result)
    }

    fn convert(&self, py: Python<'_>, value: f64, domestic: &str, foreign: &str) -> PyResult<Py<PyAny>> {
        let val = Number::F64(value);
        let result = self.inner.convert(&val, domestic, foreign);
        number_to_py(py, result)
    }

    fn convert_positions(&self, py: Python<'_>, positions: HashMap<String, f64>, base: &str) -> PyResult<Py<PyAny>> {
        let pos: HashMap<String, Number> = positions
            .into_iter()
            .map(|(k, v)| (k, Number::F64(v)))
            .collect();
        let result = self.inner.convert_positions(&pos, base);
        number_to_py(py, result)
    }

    fn restate(&self, new_pairs: Vec<String>) -> PyResult<PyFXRates> {
        let fx_pairs: Result<Vec<FXPair>, _> = new_pairs
            .iter()
            .map(|s| FXPair::from_str(s))
            .collect();
        let fx_pairs = fx_pairs.map_err(|e| PyValueError::new_err(e))?;
        let restated = self.inner.restate(&fx_pairs);
        Ok(PyFXRates { inner: restated })
    }

    #[getter]
    fn currencies(&self) -> Vec<String> {
        self.inner.currencies.clone()
    }

    #[getter]
    fn settlement(&self) -> NaiveDate {
        self.inner.settlement
    }

    fn __repr__(&self) -> String {
        format!(
            "FXRates(currencies={:?}, settlement={})",
            self.inner.currencies, self.inner.settlement
        )
    }
}

// ---- PyFXForwards ----

#[pyclass(name = "FXForwards", module = "vade._vade_rs.fx", from_py_object)]
#[derive(Clone)]
pub struct PyFXForwards {
    pub inner: FXForwards,
}

#[pymethods]
impl PyFXForwards {
    #[new]
    fn new(fx_rates: &PyFXRates, settlements: HashMap<String, NaiveDate>) -> PyResult<Self> {
        Ok(PyFXForwards {
            inner: FXForwards::new(fx_rates.inner.clone(), settlements),
        })
    }

    fn rate<'py>(
        &self,
        py: Python<'py>,
        pair: &str,
        delivery: NaiveDate,
        curves: &Bound<'py, pyo3::types::PyDict>,
    ) -> PyResult<Py<PyAny>> {
        let fx_pair = FXPair::from_str(pair)
            .map_err(|e| PyValueError::new_err(e))?;

        // Extract curves from dict
        let mut curve_map: HashMap<String, Box<dyn CurveQuery>> = HashMap::new();
        for (k, v) in curves.iter() {
            let key: String = k.extract()?;
            let curve = extract_curve_ref(&v)?;
            curve_map.insert(key, curve);
        }

        // Build reference map
        let ref_map: HashMap<String, &dyn CurveQuery> = curve_map
            .iter()
            .map(|(k, v)| (k.clone(), v.as_ref() as &dyn CurveQuery))
            .collect();

        let result = self.inner.rate(&fx_pair, delivery, &ref_map);
        number_to_py(py, result)
    }

    fn points<'py>(
        &self,
        py: Python<'py>,
        pair: &str,
        delivery: NaiveDate,
        curves: &Bound<'py, pyo3::types::PyDict>,
    ) -> PyResult<Py<PyAny>> {
        let fx_pair = FXPair::from_str(pair)
            .map_err(|e| PyValueError::new_err(e))?;

        let mut curve_map: HashMap<String, Box<dyn CurveQuery>> = HashMap::new();
        for (k, v) in curves.iter() {
            let key: String = k.extract()?;
            let curve = extract_curve_ref(&v)?;
            curve_map.insert(key, curve);
        }

        let ref_map: HashMap<String, &dyn CurveQuery> = curve_map
            .iter()
            .map(|(k, v)| (k.clone(), v.as_ref() as &dyn CurveQuery))
            .collect();

        let result = self.inner.points(&fx_pair, delivery, &ref_map);
        number_to_py(py, result)
    }

    fn __repr__(&self) -> String {
        format!(
            "FXForwards(currencies={:?})",
            self.inner.fx_rates.currencies
        )
    }
}

// ---- Module registration ----

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyFXPair>()?;
    m.add_class::<PyFXRates>()?;
    m.add_class::<PyFXForwards>()?;
    Ok(())
}
