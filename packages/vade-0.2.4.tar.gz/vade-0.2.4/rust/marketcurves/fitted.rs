use chrono::NaiveDate;
use crate::autodiff::enums::Number;
use crate::autodiff::linalg::dsolve_f64;
use crate::calendar::convention::DayCountConvention;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::nelson_siegel::{NelsonSiegel, NelsonSiegelSvensson};
use crate::marketcurves::smith_wilson::SmithWilson;
use crate::instruments::bond::{BondInstrument, BondVariant};

/// Which parametric model to fit.
#[derive(Clone)]
pub enum FittingModel {
    NelsonSiegel,
    NelsonSiegelSvensson,
    SmithWilson { ufr: f64, alpha: f64 },
}

/// Inner curve after fitting -- delegates CurveQuery.
#[derive(Clone)]
pub enum FittedCurveInner {
    NS(NelsonSiegel),
    NSS(NelsonSiegelSvensson),
    SW(SmithWilson),
}

/// Result of the fitting procedure.
#[derive(Clone)]
pub struct FitResult {
    pub converged: bool,
    pub iterations: usize,
    pub objective: f64,
    pub rmse: f64,
    pub pricing_errors: Vec<f64>,
}

/// A parametric curve fitted to bond market prices via Levenberg-Marquardt.
#[derive(Clone)]
pub struct FittedBondCurve {
    pub curve: FittedCurveInner,
    pub fit_result: FitResult,
    pub base: NaiveDate,
    pub curve_id: String,
}

/// Extract f64 from a Number enum (strips AD wrappers).
fn extract_f64(n: Number) -> f64 {
    match n {
        Number::F64(v) => v,
        Number::Dual(d) => d.real(),
        Number::Dual2(d) => d.real(),
    }
}

/// Extract coupon rate from a bond variant, returning 0.0 for zero-coupon types.
fn bond_coupon_rate(bond: &BondInstrument) -> f64 {
    match &bond.variant {
        BondVariant::FixedRate(data) => data.coupon,
        BondVariant::StepUp(data) => {
            // Use first period's coupon rate as approximation
            if let Some(first) = data.periods.first() {
                first.coupon_rate
            } else {
                0.0
            }
        }
        _ => 0.0,
    }
}

/// Approximate YTM for initial parameter heuristics.
fn approx_ytm(bond: &BondInstrument, price: f64, settlement: NaiveDate) -> f64 {
    let years = (bond.termination - settlement).num_days() as f64 / 365.25;
    if years <= 0.0 {
        return 0.03; // fallback
    }
    let coupon_rate = bond_coupon_rate(bond);
    let face = bond.face_value;
    let coupon_income = coupon_rate * face;
    let capital_gain = (face - price) / years;
    let avg_price = (face + price) / 2.0;
    if avg_price <= 0.0 {
        return 0.03;
    }
    (coupon_income + capital_gain) / avg_price
}

/// Build a candidate curve from parameter vector.
fn build_candidate(
    params: &[f64],
    model: &FittingModel,
    convention: DayCountConvention,
    base_date: NaiveDate,
    bond_maturity_dates: &[NaiveDate],
) -> FittedCurveInner {
    match model {
        FittingModel::NelsonSiegel => {
            let ns = NelsonSiegel::new(
                Number::F64(params[0]),
                Number::F64(params[1]),
                Number::F64(params[2]),
                Number::F64(params[3].exp()), // log-tau transform for positivity
                convention,
                base_date,
                "fitted".to_string(),
            );
            FittedCurveInner::NS(ns)
        }
        FittingModel::NelsonSiegelSvensson => {
            let nss = NelsonSiegelSvensson::new(
                Number::F64(params[0]),
                Number::F64(params[1]),
                Number::F64(params[2]),
                Number::F64(params[3]),
                Number::F64(params[4].exp()), // log-tau1
                Number::F64(params[5].exp()), // log-tau2
                convention,
                base_date,
                "fitted".to_string(),
            );
            FittedCurveInner::NSS(nss)
        }
        FittingModel::SmithWilson { ufr, alpha } => {
            // params are zero rates at each bond maturity
            let sw = SmithWilson::new(
                bond_maturity_dates.to_vec(),
                params.to_vec(),
                *ufr,
                *alpha,
                convention,
                base_date,
                "fitted".to_string(),
            );
            FittedCurveInner::SW(sw)
        }
    }
}

/// Compute model clean prices for all bonds using a candidate curve.
fn model_prices(
    inner: &FittedCurveInner,
    bonds: &[BondInstrument],
    settlement: NaiveDate,
) -> Vec<f64> {
    let curve: &dyn CurveQuery = match inner {
        FittedCurveInner::NS(c) => c,
        FittedCurveInner::NSS(c) => c,
        FittedCurveInner::SW(c) => c,
    };
    bonds
        .iter()
        .map(|bond| extract_f64(bond.price(curve, Some(settlement))))
        .collect()
}

/// Levenberg-Marquardt step: solve (J^T*W*J + lambda*I) delta = -J^T*W*r.
fn lm_step(
    j_matrix: &[Vec<f64>],
    residuals: &[f64],
    weights: &[f64],
    n_params: usize,
    lambda: f64,
) -> Vec<f64> {
    let n_instruments = residuals.len();
    let mut a_mat = vec![vec![0.0; n_params]; n_params];
    let mut b_vec = vec![0.0; n_params];
    for j_idx in 0..n_params {
        for k_idx in 0..n_params {
            let mut sum = 0.0;
            for i in 0..n_instruments {
                sum += j_matrix[i][j_idx] * weights[i] * j_matrix[i][k_idx];
            }
            a_mat[j_idx][k_idx] = sum;
        }
        a_mat[j_idx][j_idx] += lambda;
        let mut b_sum = 0.0;
        for i in 0..n_instruments {
            b_sum += j_matrix[i][j_idx] * weights[i] * residuals[i];
        }
        b_vec[j_idx] = -b_sum;
    }
    dsolve_f64(&a_mat, &b_vec)
}

impl CurveQuery for FittedCurveInner {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        match self {
            FittedCurveInner::NS(c) => c.discount_factor(date),
            FittedCurveInner::NSS(c) => c.discount_factor(date),
            FittedCurveInner::SW(c) => c.discount_factor(date),
        }
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        match self {
            FittedCurveInner::NS(c) => c.zero_rate(start, end),
            FittedCurveInner::NSS(c) => c.zero_rate(start, end),
            FittedCurveInner::SW(c) => c.zero_rate(start, end),
        }
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        match self {
            FittedCurveInner::NS(c) => c.forward_rate(start, end),
            FittedCurveInner::NSS(c) => c.forward_rate(start, end),
            FittedCurveInner::SW(c) => c.forward_rate(start, end),
        }
    }
}

impl CurveQuery for FittedBondCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        self.curve.discount_factor(date)
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.curve.zero_rate(start, end)
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.curve.forward_rate(start, end)
    }
}

impl FittedBondCurve {
    /// Fit a parametric curve to bond market prices using Levenberg-Marquardt.
    ///
    /// # Arguments
    /// * `bonds` - Slice of bond instruments to fit
    /// * `market_prices` - Clean prices for each bond
    /// * `settlement` - Settlement date for pricing
    /// * `model` - Which parametric model to fit (NS, NSS, or SmithWilson)
    /// * `convention` - Day count convention
    /// * `base_date` - Curve base date
    /// * `weights` - Optional custom weights; None = inverse time-to-maturity
    /// * `initial_params` - Optional starting parameters; None = heuristic defaults
    /// * `max_iter` - Maximum LM iterations; None = 200
    /// * `func_tol` - Convergence tolerance; None = 1e-10
    /// * `id` - Curve identifier
    #[allow(clippy::too_many_arguments)]
    pub fn fit(
        bonds: &[BondInstrument],
        market_prices: &[f64],
        settlement: NaiveDate,
        model: FittingModel,
        convention: DayCountConvention,
        base_date: NaiveDate,
        weights: Option<&[f64]>,
        initial_params: Option<&[f64]>,
        max_iter: Option<usize>,
        func_tol: Option<f64>,
        id: String,
    ) -> Self {
        let n_bonds = bonds.len();
        assert_eq!(n_bonds, market_prices.len(), "bonds and market_prices must have same length");
        assert!(n_bonds > 0, "Must provide at least one bond");

        let max_iterations = max_iter.unwrap_or(200);
        let tolerance = func_tol.unwrap_or(1e-10);

        // -- Weights (D-05, D-06) --
        let w: Vec<f64> = if let Some(user_w) = weights {
            assert_eq!(user_w.len(), n_bonds, "weights must match number of bonds");
            user_w.to_vec()
        } else {
            // Inverse time-to-maturity weighting
            let raw: Vec<f64> = bonds
                .iter()
                .map(|bond| {
                    let days = (bond.termination - settlement).num_days() as f64;
                    let years = days / 365.25;
                    if years > 0.0 { 1.0 / years } else { 1.0 }
                })
                .collect();
            // Normalize so weights sum to n_bonds (preserves objective scale)
            let sum: f64 = raw.iter().sum();
            if sum > 0.0 {
                raw.iter().map(|r| r * n_bonds as f64 / sum).collect()
            } else {
                vec![1.0; n_bonds]
            }
        };

        // -- Bond maturity dates for SW model --
        let bond_maturity_dates: Vec<NaiveDate> = bonds.iter().map(|b| b.termination).collect();

        // -- Initial parameters (D-08) --
        let mut params: Vec<f64> = if let Some(user_p) = initial_params {
            user_p.to_vec()
        } else {
            match &model {
                FittingModel::NelsonSiegel => {
                    // Approximate YTMs for heuristics
                    let ytms: Vec<f64> = bonds
                        .iter()
                        .zip(market_prices.iter())
                        .map(|(b, p)| approx_ytm(b, *p, settlement))
                        .collect();
                    // Sort by maturity to find shortest/longest
                    let mut by_mat: Vec<(f64, f64)> = bonds
                        .iter()
                        .zip(ytms.iter())
                        .map(|(b, y)| {
                            let years = (b.termination - settlement).num_days() as f64 / 365.25;
                            (years, *y)
                        })
                        .collect();
                    by_mat.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
                    let ytm_longest = by_mat.last().map(|x| x.1).unwrap_or(0.03);
                    let ytm_shortest = by_mat.first().map(|x| x.1).unwrap_or(0.03);
                    let beta0 = ytm_longest;
                    let beta1 = ytm_shortest - beta0;
                    let beta2 = 0.0;
                    let log_tau = 1.5_f64.ln();
                    vec![beta0, beta1, beta2, log_tau]
                }
                FittingModel::NelsonSiegelSvensson => {
                    let ytms: Vec<f64> = bonds
                        .iter()
                        .zip(market_prices.iter())
                        .map(|(b, p)| approx_ytm(b, *p, settlement))
                        .collect();
                    let mut by_mat: Vec<(f64, f64)> = bonds
                        .iter()
                        .zip(ytms.iter())
                        .map(|(b, y)| {
                            let years = (b.termination - settlement).num_days() as f64 / 365.25;
                            (years, *y)
                        })
                        .collect();
                    by_mat.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
                    let ytm_longest = by_mat.last().map(|x| x.1).unwrap_or(0.03);
                    let ytm_shortest = by_mat.first().map(|x| x.1).unwrap_or(0.03);
                    let beta0 = ytm_longest;
                    let beta1 = ytm_shortest - beta0;
                    let beta2 = 0.0;
                    let beta3 = 0.0;
                    let log_tau1 = 1.5_f64.ln();
                    let log_tau2 = 5.0_f64.ln();
                    vec![beta0, beta1, beta2, beta3, log_tau1, log_tau2]
                }
                FittingModel::SmithWilson { .. } => {
                    // Initial rates = 0.03 for each bond maturity
                    vec![0.03; n_bonds]
                }
            }
        };

        let n_params = params.len();

        // -- LM iteration (D-07) --
        let mut lambda = 1.0_f64;
        let success_scale = 0.5;
        let failure_scale = 2.0;
        let eps = 1e-6; // finite difference step

        let mut g_prev = f64::MAX;
        let mut converged = false;
        let mut iterations = 0_usize;
        let mut best_params = params.clone();

        for iter in 0..max_iterations {
            iterations = iter + 1;

            // Build candidate curve and compute residuals
            let candidate = build_candidate(&params, &model, convention, base_date, &bond_maturity_dates);
            let prices = model_prices(&candidate, bonds, settlement);
            let residuals: Vec<f64> = prices
                .iter()
                .zip(market_prices.iter())
                .map(|(mp, mkt)| mp - mkt)
                .collect();

            // Weighted objective
            let g: f64 = residuals
                .iter()
                .zip(w.iter())
                .map(|(r, wi)| wi * r * r)
                .sum();

            // Check for objective increase
            if g >= g_prev && iter > 0 {
                lambda *= failure_scale;
                params = best_params.clone();
                // Recompute with restored params
                let candidate2 = build_candidate(&params, &model, convention, base_date, &bond_maturity_dates);
                let prices2 = model_prices(&candidate2, bonds, settlement);
                let residuals2: Vec<f64> = prices2
                    .iter()
                    .zip(market_prices.iter())
                    .map(|(mp, mkt)| mp - mkt)
                    .collect();
                let g2: f64 = residuals2
                    .iter()
                    .zip(w.iter())
                    .map(|(r, wi)| wi * r * r)
                    .sum();
                g_prev = g2;

                // Compute Jacobian on restored params
                let jacobian = Self::compute_jacobian(
                    &params, &model, convention, base_date, &bond_maturity_dates,
                    bonds, settlement, n_bonds, n_params, eps,
                );
                let delta = lm_step(&jacobian, &residuals2, &w, n_params, lambda);
                for j in 0..n_params {
                    params[j] += delta[j];
                }
                continue;
            }

            if iter > 0 {
                lambda *= success_scale;
            }
            best_params = params.clone();

            // Convergence check
            if (g_prev - g).abs() < tolerance || g < tolerance {
                converged = true;
                g_prev = g;
                break;
            }

            g_prev = g;

            // Compute Jacobian via central finite differences
            let jacobian = Self::compute_jacobian(
                &params, &model, convention, base_date, &bond_maturity_dates,
                bonds, settlement, n_bonds, n_params, eps,
            );

            // LM step
            let delta = lm_step(&jacobian, &residuals, &w, n_params, lambda);
            for j in 0..n_params {
                params[j] += delta[j];
            }
        }

        // Build final curve from best params
        let final_curve = build_candidate(&best_params, &model, convention, base_date, &bond_maturity_dates);
        let final_prices = model_prices(&final_curve, bonds, settlement);
        let pricing_errors: Vec<f64> = final_prices
            .iter()
            .zip(market_prices.iter())
            .map(|(mp, mkt)| mp - mkt)
            .collect();
        let rmse = {
            let sum_sq: f64 = pricing_errors.iter().map(|e| e * e).sum();
            (sum_sq / n_bonds as f64).sqrt()
        };

        let fit_result = FitResult {
            converged,
            iterations,
            objective: g_prev,
            rmse,
            pricing_errors,
        };

        FittedBondCurve {
            curve: final_curve,
            fit_result,
            base: base_date,
            curve_id: id,
        }
    }

    /// Compute Jacobian via central finite differences.
    fn compute_jacobian(
        params: &[f64],
        model: &FittingModel,
        convention: DayCountConvention,
        base_date: NaiveDate,
        bond_maturity_dates: &[NaiveDate],
        bonds: &[BondInstrument],
        settlement: NaiveDate,
        n_bonds: usize,
        n_params: usize,
        eps: f64,
    ) -> Vec<Vec<f64>> {
        let mut jacobian = vec![vec![0.0; n_params]; n_bonds];
        for j in 0..n_params {
            let mut p_plus = params.to_vec();
            let mut p_minus = params.to_vec();
            p_plus[j] += eps;
            p_minus[j] -= eps;

            let c_plus = build_candidate(&p_plus, model, convention, base_date, bond_maturity_dates);
            let c_minus = build_candidate(&p_minus, model, convention, base_date, bond_maturity_dates);
            let prices_plus = model_prices(&c_plus, bonds, settlement);
            let prices_minus = model_prices(&c_minus, bonds, settlement);

            for i in 0..n_bonds {
                jacobian[i][j] = (prices_plus[i] - prices_minus[i]) / (2.0 * eps);
            }
        }
        jacobian
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::calendar::frequency::Frequency;
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    /// Helper: create a fixed-rate bond.
    fn make_bond(effective: NaiveDate, termination: NaiveDate, coupon: f64, face: f64) -> BondInstrument {
        BondInstrument::new_fixed_rate(
            effective,
            termination,
            coupon,
            Frequency::Annual,
            0, // settlement_days
            0, // ex_div_days
            BusinessCalendar::new_custom(vec![], vec![5, 6]),
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            face,
            Adjuster::ModifiedFollowing,
        )
    }

    /// Generate synthetic bond prices from a known NS curve.
    fn ns_target_prices() -> (Vec<BondInstrument>, Vec<f64>, NaiveDate) {
        let base = ymd(2024, 1, 1);
        let ns = NelsonSiegel::new(
            Number::F64(0.04),
            Number::F64(-0.01),
            Number::F64(0.008),
            Number::F64(1.5),
            DayCountConvention::Act365F,
            base,
            "target".to_string(),
        );

        let maturities = vec![
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2028, 1, 1),
            ymd(2031, 1, 1),
            ymd(2034, 1, 1),
        ];
        let coupons = vec![0.03, 0.035, 0.04, 0.042, 0.045];

        let mut bonds = Vec::new();
        let mut prices = Vec::new();
        for (i, &mat) in maturities.iter().enumerate() {
            let bond = make_bond(base, mat, coupons[i], 100.0);
            let price = extract_f64(bond.price(&ns as &dyn CurveQuery, Some(base)));
            bonds.push(bond);
            prices.push(price);
        }
        (bonds, prices, base)
    }

    #[test]
    fn test_ns_fit() {
        let (bonds, prices, base) = ns_target_prices();
        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::NelsonSiegel,
            DayCountConvention::Act365F,
            base, None, None, None, None,
            "ns_fit".to_string(),
        );
        assert!(fitted.fit_result.converged, "NS fit should converge");
        assert!(
            fitted.fit_result.rmse < 0.01,
            "RMSE={} should be < 0.01", fitted.fit_result.rmse
        );
    }

    #[test]
    fn test_nss_fit() {
        let base = ymd(2024, 1, 1);
        let nss = NelsonSiegelSvensson::new(
            Number::F64(0.04),
            Number::F64(-0.01),
            Number::F64(0.008),
            Number::F64(0.003),
            Number::F64(1.5),
            Number::F64(5.0),
            DayCountConvention::Act365F,
            base,
            "target".to_string(),
        );

        let maturities = vec![
            ymd(2025, 1, 1), ymd(2026, 1, 1), ymd(2027, 1, 1),
            ymd(2029, 1, 1), ymd(2031, 1, 1), ymd(2034, 1, 1),
            ymd(2039, 1, 1),
        ];
        let coupons = vec![0.03, 0.032, 0.035, 0.038, 0.04, 0.042, 0.045];

        let mut bonds = Vec::new();
        let mut prices = Vec::new();
        for (i, &mat) in maturities.iter().enumerate() {
            let bond = make_bond(base, mat, coupons[i], 100.0);
            let price = extract_f64(bond.price(&nss as &dyn CurveQuery, Some(base)));
            bonds.push(bond);
            prices.push(price);
        }

        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::NelsonSiegelSvensson,
            DayCountConvention::Act365F,
            base, None, None, None, None,
            "nss_fit".to_string(),
        );
        assert!(fitted.fit_result.converged, "NSS fit should converge");
        assert!(
            fitted.fit_result.rmse < 0.01,
            "RMSE={} should be < 0.01", fitted.fit_result.rmse
        );
    }

    #[test]
    fn test_sw_fit() {
        let base = ymd(2024, 1, 1);
        // Create SW target curve
        let target_dates = vec![
            ymd(2025, 1, 1), ymd(2027, 1, 1), ymd(2029, 1, 1),
            ymd(2034, 1, 1), ymd(2044, 1, 1),
        ];
        let target_rates = vec![0.03, 0.034, 0.036, 0.038, 0.037];
        let sw = SmithWilson::new(
            target_dates.clone(),
            target_rates.clone(),
            0.033,
            0.128,
            DayCountConvention::Act365F,
            base,
            "target".to_string(),
        );

        let maturities = vec![
            ymd(2025, 1, 1), ymd(2027, 1, 1), ymd(2029, 1, 1),
            ymd(2034, 1, 1), ymd(2044, 1, 1),
        ];
        let coupons = vec![0.03, 0.035, 0.04, 0.042, 0.045];

        let mut bonds = Vec::new();
        let mut prices = Vec::new();
        for (i, &mat) in maturities.iter().enumerate() {
            let bond = make_bond(base, mat, coupons[i], 100.0);
            let price = extract_f64(bond.price(&sw as &dyn CurveQuery, Some(base)));
            bonds.push(bond);
            prices.push(price);
        }

        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::SmithWilson { ufr: 0.033, alpha: 0.128 },
            DayCountConvention::Act365F,
            base, None, None, None, None,
            "sw_fit".to_string(),
        );
        assert!(fitted.fit_result.converged, "SW fit should converge");
        assert!(
            fitted.fit_result.rmse < 0.05,
            "RMSE={} should be < 0.05", fitted.fit_result.rmse
        );
    }

    #[test]
    fn test_inverse_duration_weights() {
        let base = ymd(2024, 1, 1);
        let bonds = vec![
            make_bond(base, ymd(2025, 1, 1), 0.03, 100.0), // ~1Y
            make_bond(base, ymd(2034, 1, 1), 0.04, 100.0), // ~10Y
        ];
        // With inverse time-to-maturity: w1 ~ 1/1 = 1.0, w2 ~ 1/10 = 0.1
        // Normalized to sum=2: w1 ~ 1.818, w2 ~ 0.182
        let ttm1 = (ymd(2025, 1, 1) - base).num_days() as f64 / 365.25;
        let ttm2 = (ymd(2034, 1, 1) - base).num_days() as f64 / 365.25;
        let raw1 = 1.0 / ttm1;
        let raw2 = 1.0 / ttm2;
        let sum = raw1 + raw2;
        let expected_w1 = raw1 * 2.0 / sum;
        let expected_w2 = raw2 * 2.0 / sum;

        // Verify the weight computation logic matches
        assert!(expected_w1 > expected_w2, "Short-maturity bond should have higher weight");
        assert!((expected_w1 + expected_w2 - 2.0).abs() < 1e-10, "Weights should sum to n_bonds=2");
    }

    #[test]
    fn test_custom_weights() {
        let (bonds, prices, base) = ns_target_prices();
        let custom_w = vec![1.0, 1.0, 1.0, 1.0, 1.0];
        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::NelsonSiegel,
            DayCountConvention::Act365F,
            base, Some(&custom_w), None, None, None,
            "custom_w".to_string(),
        );
        assert!(fitted.fit_result.converged, "NS fit with custom weights should converge");
    }

    #[test]
    fn test_convergence_info() {
        let (bonds, prices, base) = ns_target_prices();
        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::NelsonSiegel,
            DayCountConvention::Act365F,
            base, None, None, None, None,
            "info".to_string(),
        );
        assert!(fitted.fit_result.iterations > 0, "Should have at least 1 iteration");
        assert!(fitted.fit_result.objective >= 0.0, "Objective should be non-negative");
        assert_eq!(
            fitted.fit_result.pricing_errors.len(), bonds.len(),
            "pricing_errors.len() should equal n_bonds"
        );
    }

    #[test]
    fn test_log_tau_positivity() {
        let (bonds, prices, base) = ns_target_prices();
        // Use pathological initial params with negative log-tau
        let init = vec![0.05, -0.02, 0.01, -5.0]; // log_tau = -5 => tau = exp(-5) ~ 0.007 (very small but positive)
        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::NelsonSiegel,
            DayCountConvention::Act365F,
            base, None, Some(&init), None, None,
            "tau_test".to_string(),
        );
        // The curve should still produce valid results (tau is always positive via exp())
        if let FittedCurveInner::NS(ns) = &fitted.curve {
            let tau_val = extract_f64(ns.tau.clone());
            assert!(tau_val > 0.0, "tau must be positive, got {}", tau_val);
        } else {
            panic!("Expected NS inner curve");
        }
    }

    #[test]
    fn test_initial_params_override() {
        let (bonds, prices, base) = ns_target_prices();
        // Provide initial params close to the answer
        let init = vec![0.04, -0.01, 0.008, 1.5_f64.ln()];
        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::NelsonSiegel,
            DayCountConvention::Act365F,
            base, None, Some(&init), None, None,
            "init_override".to_string(),
        );
        assert!(fitted.fit_result.converged, "Should converge with good initial params");
        assert!(
            fitted.fit_result.rmse < 1e-6,
            "RMSE={} should be very small with near-perfect initial params",
            fitted.fit_result.rmse
        );
    }

    #[test]
    fn test_curve_query_delegation() {
        let (bonds, prices, base) = ns_target_prices();
        let fitted = FittedBondCurve::fit(
            &bonds, &prices, base,
            FittingModel::NelsonSiegel,
            DayCountConvention::Act365F,
            base, None, None, None, None,
            "query_test".to_string(),
        );
        // Test CurveQuery delegation
        let df = fitted.discount_factor(ymd(2025, 1, 1));
        if let Number::F64(v) = df {
            assert!(v > 0.0 && v < 1.0, "DF should be between 0 and 1, got {}", v);
        } else {
            panic!("Expected F64");
        }

        let zr = fitted.zero_rate(base, ymd(2026, 1, 1));
        if let Number::F64(v) = zr {
            assert!(v > 0.0, "Zero rate should be positive, got {}", v);
        } else {
            panic!("Expected F64");
        }

        let fwd = fitted.forward_rate(ymd(2025, 1, 1), ymd(2026, 1, 1));
        if let Number::F64(v) = fwd {
            assert!(v > 0.0, "Forward rate should be positive, got {}", v);
        } else {
            panic!("Expected F64");
        }
    }
}
