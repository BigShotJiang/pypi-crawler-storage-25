use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::{CurveInterpolation, Interpolator};
use crate::marketcurves::interpolation::natural_cubic::NaturalCubicInterpolator;
use crate::marketcurves::interpolation::log_cubic::LogCubicInterpolator;
use crate::marketcurves::interpolation::hermite::HermiteInterpolator;
use crate::marketcurves::interpolation::monotone_cubic::MonotoneCubicInterpolator;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::adjuster::Adjuster;
use crate::calendar::cal::BusinessCalendar;
use crate::autodiff::ops::math_funcs::MathFuncs;

/// Trait for querying curves: discount factors, zero rates, forward rates.
pub trait CurveQuery {
    fn discount_factor(&self, date: NaiveDate) -> Number;
    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number;
    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number;
}

/// A discount factor curve with interpolated DF values.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DiscountCurve {
    pub nodes: Nodes,
    pub interpolator: Interpolator,
    pub convention: DayCountConvention,
    pub modifier: Adjuster,
    pub calendar: Option<BusinessCalendar>,
    pub id: String,
}

/// A value-based curve (zero rates, spreads).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LineCurve {
    pub nodes: Nodes,
    pub interpolator: Interpolator,
    pub convention: DayCountConvention,
    pub modifier: Adjuster,
    pub calendar: Option<BusinessCalendar>,
    pub id: String,
}

impl DiscountCurve {
    pub fn new(
        mut nodes: Nodes,
        interpolator: Interpolator,
        convention: DayCountConvention,
        id: String,
    ) -> Self {
        nodes.ensure_first_df_one();
        Self {
            nodes,
            interpolator,
            convention,
            modifier: Adjuster::ModifiedFollowing,
            calendar: None,
            id,
        }
    }

    pub fn set_nodes(&mut self, nodes: Nodes) {
        self.nodes = nodes;
    }

    /// Get f64 values from all nodes (delegates to nodes.get_values_f64).
    pub fn get_node_values(&self) -> Vec<f64> {
        self.nodes.get_values_f64()
    }

    /// Set node values as f64, then trigger recomputation.
    pub fn set_node_values(&mut self, values: &[f64]) {
        self.nodes.set_values_as_f64(values);
    }

    /// Number of solver variables (total nodes minus ini_solve).
    /// For DiscountCurve, ini_solve=1 (first DF is always 1.0).
    pub fn n_vars(&self) -> usize {
        self.nodes.len().saturating_sub(self.ini_solve())
    }

    /// Index at which solver variables start.
    /// For DiscountCurve this is 1 (first DF fixed at 1.0).
    pub fn ini_solve(&self) -> usize {
        1
    }

    /// Rebuild stateful interpolator from current nodes after deserialization.
    /// Call this after deserializing a curve that had a Spline or stateful interpolator.
    pub fn rebuild_spline(&mut self) {
        match &self.interpolator {
            Interpolator::Spline { pp, local_interp, log_transform } => {
                let endpoint = pp.endpoint.clone();
                let local = *local_interp.clone();
                let lt = *log_transform;
                self.interpolator = Interpolator::build_spline(
                    &self.nodes, None, &endpoint, local, lt,
                );
            }
            Interpolator::NaturalCubic(_) => {
                self.interpolator = Interpolator::NaturalCubic(NaturalCubicInterpolator::build(&self.nodes));
            }
            Interpolator::LogCubic(_) => {
                self.interpolator = Interpolator::LogCubic(LogCubicInterpolator::build(&self.nodes));
            }
            Interpolator::Hermite(_) => {
                self.interpolator = Interpolator::Hermite(HermiteInterpolator::build(&self.nodes));
            }
            Interpolator::MonotoneCubic(_) => {
                self.interpolator = Interpolator::MonotoneCubic(MonotoneCubicInterpolator::build(&self.nodes));
            }
            Interpolator::ConvexMonotone(_) => {
                // ConvexMonotone is stateless -- no rebuild needed
            }
            _ => {} // stateless variants don't need rebuild
        }
    }

    /// Serialize to JSON string.
    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap()
    }

    /// Deserialize from JSON string, rebuilding interpolator if needed.
    pub fn from_json(s: &str) -> Result<Self, serde_json::Error> {
        let mut curve: Self = serde_json::from_str(s)?;
        curve.rebuild_spline();
        Ok(curve)
    }
}

impl LineCurve {
    pub fn new(
        nodes: Nodes,
        interpolator: Interpolator,
        convention: DayCountConvention,
        id: String,
    ) -> Self {
        Self {
            nodes,
            interpolator,
            convention,
            modifier: Adjuster::ModifiedFollowing,
            calendar: None,
            id,
        }
    }

    pub fn set_nodes(&mut self, nodes: Nodes) {
        self.nodes = nodes;
    }

    /// Get f64 values from all nodes.
    pub fn get_node_values(&self) -> Vec<f64> {
        self.nodes.get_values_f64()
    }

    /// Set node values as f64, then trigger recomputation.
    pub fn set_node_values(&mut self, values: &[f64]) {
        self.nodes.set_values_as_f64(values);
    }

    /// Number of solver variables.
    /// For LineCurve, ini_solve=0 (all nodes are solvable).
    pub fn n_vars(&self) -> usize {
        self.nodes.len().saturating_sub(self.ini_solve())
    }

    /// Index at which solver variables start.
    /// For LineCurve this is 0 (all nodes participate in the solve).
    pub fn ini_solve(&self) -> usize {
        0
    }

    /// Rebuild stateful interpolator from current nodes after deserialization.
    pub fn rebuild_spline(&mut self) {
        match &self.interpolator {
            Interpolator::Spline { pp, local_interp, log_transform } => {
                let endpoint = pp.endpoint.clone();
                let local = *local_interp.clone();
                let lt = *log_transform;
                self.interpolator = Interpolator::build_spline(
                    &self.nodes, None, &endpoint, local, lt,
                );
            }
            Interpolator::NaturalCubic(_) => {
                self.interpolator = Interpolator::NaturalCubic(NaturalCubicInterpolator::build(&self.nodes));
            }
            Interpolator::LogCubic(_) => {
                self.interpolator = Interpolator::LogCubic(LogCubicInterpolator::build(&self.nodes));
            }
            Interpolator::Hermite(_) => {
                self.interpolator = Interpolator::Hermite(HermiteInterpolator::build(&self.nodes));
            }
            Interpolator::MonotoneCubic(_) => {
                self.interpolator = Interpolator::MonotoneCubic(MonotoneCubicInterpolator::build(&self.nodes));
            }
            Interpolator::ConvexMonotone(_) => {
                // ConvexMonotone is stateless -- no rebuild needed
            }
            _ => {} // stateless variants don't need rebuild
        }
    }

    /// Serialize to JSON string.
    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap()
    }

    /// Deserialize from JSON string, rebuilding interpolator if needed.
    pub fn from_json(s: &str) -> Result<Self, serde_json::Error> {
        let mut curve: Self = serde_json::from_str(s)?;
        curve.rebuild_spline();
        Ok(curve)
    }
}

impl CurveQuery for DiscountCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        self.interpolator.interpolated_value(&self.nodes, date)
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        // Forward rate between two dates is the same formula as zero_rate
        self.zero_rate(start, end)
    }
}

impl CurveQuery for LineCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        // LineCurve stores rates; DF = exp(-rate * dcf(first_date, date))
        let rate = self.interpolator.interpolated_value(&self.nodes, date);
        let first_date = self.nodes.first_key();
        let dcf = self.convention.dcf(first_date, date, &DcfOptions::default()).unwrap();
        (&rate * (-dcf)).exp()
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::autodiff::dual::Dual;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn discount_curve_fixture() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test_curve".to_string(),
        )
    }

    #[test]
    fn test_discount_curve_construction() {
        let curve = discount_curve_fixture();
        assert_eq!(curve.id, "test_curve");
        assert_eq!(curve.nodes.len(), 3);
    }

    #[test]
    fn test_discount_curve_auto_insert_df_one() {
        // Create without DF=1.0 at first node
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        let curve = DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        );
        // First value should be 1.0 (auto-inserted)
        assert_eq!(curve.nodes.get_value_at_index(0), Number::F64(1.0));
    }

    #[test]
    fn test_discount_factor_at_node() {
        let curve = discount_curve_fixture();
        let df = curve.discount_factor(ymd(2025, 1, 1));
        assert_eq!(df, Number::F64(0.97));
    }

    #[test]
    fn test_discount_factor_mid_interval() {
        let curve = discount_curve_fixture();
        let df = curve.discount_factor(ymd(2024, 7, 1));
        if let Number::F64(v) = df {
            // Log-linear: should be between 0.97 and 1.0
            assert!(v > 0.97 && v < 1.0, "DF={v} should be between 0.97 and 1.0");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_discount_factor_extrapolation() {
        let curve = discount_curve_fixture();
        let df = curve.discount_factor(ymd(2030, 1, 1));
        // Flat forward extrapolation: returns last node value
        assert_eq!(df, Number::F64(0.94));
    }

    #[test]
    fn test_zero_rate() {
        let curve = discount_curve_fixture();
        let rate = curve.zero_rate(ymd(2024, 1, 1), ymd(2025, 1, 1));
        // r = -ln(DF(end)/DF(start)) / dcf
        // DF(start) = 1.0, DF(end) = 0.97
        // dcf = 366/365 (2024 is leap year)
        // r = -ln(0.97) / (366/365)
        if let Number::F64(r) = rate {
            let dcf = 366.0 / 365.0;
            let expected = -0.97_f64.ln() / dcf;
            assert!((r - expected).abs() < 1e-10, "rate={r}, expected={expected}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_forward_rate() {
        let curve = discount_curve_fixture();
        let fwd = curve.forward_rate(ymd(2025, 1, 1), ymd(2026, 1, 1));
        // Forward rate between two dates
        if let Number::F64(r) = fwd {
            // DF(2025) = 0.97, DF(2026) = 0.94
            let dcf = 365.0 / 365.0; // 2025 is not leap, Act365F
            let expected = -(0.94_f64 / 0.97).ln() / dcf;
            assert!((r - expected).abs() < 1e-10, "fwd={r}, expected={expected}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_discount_curve_ad_propagation() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.97);
        let d3 = Dual::new("v2", 0.94);
        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
            (ymd(2026, 1, 1), d3),
        ]));
        let curve = DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "dual_curve".to_string(),
        );

        // DF query should return Dual
        let df = curve.discount_factor(ymd(2024, 7, 1));
        if let Number::Dual(d) = df {
            assert!(d.real() > 0.97 && d.real() < 1.0);
        } else {
            panic!("Expected Dual from DF query");
        }

        // Zero rate query should return Dual
        let rate = curve.zero_rate(ymd(2024, 1, 1), ymd(2025, 1, 1));
        if let Number::Dual(d) = rate {
            assert!(d.real() > 0.0, "Zero rate should be positive");
        } else {
            panic!("Expected Dual from zero rate query");
        }
    }

    #[test]
    fn test_line_curve_construction() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.035),
            (ymd(2026, 1, 1), 0.04),
        ]));
        let curve = LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "rate_curve".to_string(),
        );
        assert_eq!(curve.id, "rate_curve");
        assert_eq!(curve.nodes.len(), 3);
    }

    #[test]
    fn test_line_curve_discount_factor() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.035),
        ]));
        let curve = LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "rate_curve".to_string(),
        );

        // DF at first node: dcf = 0, so DF = exp(-rate * 0) = 1.0
        let df_start = curve.discount_factor(ymd(2024, 1, 1));
        if let Number::F64(v) = df_start {
            assert!((v - 1.0).abs() < 1e-12, "DF at start should be 1.0, got {v}");
        } else {
            panic!("Expected F64");
        }

        // DF at end: dcf = 366/365, rate = 0.035
        let df_end = curve.discount_factor(ymd(2025, 1, 1));
        if let Number::F64(v) = df_end {
            let dcf = 366.0 / 365.0;
            let expected = (-0.035 * dcf).exp();
            assert!((v - expected).abs() < 1e-10, "DF={v}, expected={expected}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_line_curve_zero_rate() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2026, 1, 1), 0.04),
        ]));
        let curve = LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "rate_curve".to_string(),
        );

        // Zero rate from start to end should be derivable from DFs
        let rate = curve.zero_rate(ymd(2024, 1, 1), ymd(2026, 1, 1));
        if let Number::F64(r) = rate {
            assert!(r > 0.0, "Zero rate should be positive, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_discount_curve_get_node_values() {
        let curve = discount_curve_fixture();
        let vals = curve.get_node_values();
        assert_eq!(vals, vec![1.0, 0.97, 0.94]);
    }

    #[test]
    fn test_discount_curve_set_node_values() {
        let mut curve = discount_curve_fixture();
        curve.set_node_values(&[1.0, 0.95, 0.90]);
        assert_eq!(curve.get_node_values(), vec![1.0, 0.95, 0.90]);
        let df = curve.discount_factor(ymd(2025, 1, 1));
        assert_eq!(df, Number::F64(0.95));
    }

    #[test]
    fn test_discount_curve_n_vars() {
        let curve = discount_curve_fixture();
        assert_eq!(curve.ini_solve(), 1);
        assert_eq!(curve.n_vars(), 2); // 3 nodes - 1 ini_solve
    }

    #[test]
    fn test_line_curve_n_vars() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.035),
            (ymd(2026, 1, 1), 0.04),
        ]));
        let curve = LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "test".to_string(),
        );
        assert_eq!(curve.ini_solve(), 0);
        assert_eq!(curve.n_vars(), 3); // all nodes solvable
    }

    #[test]
    fn test_serde_discount_curve_roundtrip() {
        let curve = discount_curve_fixture();
        let json = curve.to_json();
        let restored = DiscountCurve::from_json(&json).unwrap();
        // Verify DF queries match
        let df_orig = curve.discount_factor(ymd(2025, 1, 1));
        let df_restored = restored.discount_factor(ymd(2025, 1, 1));
        if let (Number::F64(a), Number::F64(b)) = (&df_orig, &df_restored) {
            assert!((a - b).abs() < 1e-12, "DF mismatch: {} vs {}", a, b);
        } else {
            panic!("Expected F64");
        }
        assert_eq!(restored.id, "test_curve");
    }

    #[test]
    fn test_serde_line_curve_roundtrip() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.035),
            (ymd(2026, 1, 1), 0.04),
        ]));
        let curve = LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "rate_curve".to_string(),
        );
        let json = curve.to_json();
        let restored = LineCurve::from_json(&json).unwrap();
        let df_orig = curve.discount_factor(ymd(2024, 7, 1));
        let df_restored = restored.discount_factor(ymd(2024, 7, 1));
        if let (Number::F64(a), Number::F64(b)) = (&df_orig, &df_restored) {
            assert!((a - b).abs() < 1e-12, "DF mismatch: {} vs {}", a, b);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_serde_discount_curve_with_dual_strips_ad() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.97);
        let d3 = Dual::new("v2", 0.94);
        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
            (ymd(2026, 1, 1), d3),
        ]));
        let curve = DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "dual_curve".to_string(),
        );
        let json = curve.to_json();
        let restored = DiscountCurve::from_json(&json).unwrap();
        // After deserialization, should be F64 (AD stripped)
        let df = restored.discount_factor(ymd(2025, 1, 1));
        if let Number::F64(v) = df {
            assert!((v - 0.97).abs() < 1e-12, "Expected 0.97, got {}", v);
        } else {
            panic!("Expected F64 after deserialization (AD stripped)");
        }
    }

    #[test]
    fn test_set_nodes() {
        let mut curve = discount_curve_fixture();
        let new_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.95),
        ]));
        curve.set_nodes(new_nodes);
        assert_eq!(curve.nodes.len(), 2);
        let df = curve.discount_factor(ymd(2025, 1, 1));
        assert_eq!(df, Number::F64(0.95));
    }
}
