use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::marketcurves::curve::CurveQuery;

/// Nelson-Siegel parametric yield curve model.
///
/// Zero rate formula:
///   r(t) = beta0 + beta1 * ((1 - exp(-t/tau)) / (t/tau))
///                 + beta2 * ((1 - exp(-t/tau)) / (t/tau) - exp(-t/tau))
///
/// At t=0 (L'Hopital limit): r(0) = beta0 + beta1
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct NelsonSiegel {
    pub beta0: Number,
    pub beta1: Number,
    pub beta2: Number,
    pub tau: Number,
    pub convention: DayCountConvention,
    pub base_date: NaiveDate,
    pub id: String,
}

/// Nelson-Siegel-Svensson parametric yield curve model.
///
/// Extends Nelson-Siegel with a second hump component:
///   r(t) = NS(t; beta0, beta1, beta2, tau1)
///        + beta3 * ((1 - exp(-t/tau2)) / (t/tau2) - exp(-t/tau2))
///
/// At t=0: r(0) = beta0 + beta1 (beta3 term vanishes)
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct NelsonSiegelSvensson {
    pub beta0: Number,
    pub beta1: Number,
    pub beta2: Number,
    pub beta3: Number,
    pub tau1: Number,
    pub tau2: Number,
    pub convention: DayCountConvention,
    pub base_date: NaiveDate,
    pub id: String,
}

impl NelsonSiegel {
    pub fn new(
        beta0: Number,
        beta1: Number,
        beta2: Number,
        tau: Number,
        convention: DayCountConvention,
        base_date: NaiveDate,
        id: String,
    ) -> Self {
        // Validate tau > 0
        match &tau {
            Number::F64(v) => assert!(*v > 0.0, "tau must be positive, got {}", v),
            Number::Dual(d) => assert!(d.real() > 0.0, "tau must be positive"),
            Number::Dual2(d) => assert!(d.real() > 0.0, "tau must be positive"),
        }
        Self { beta0, beta1, beta2, tau, convention, base_date, id }
    }

    /// Compute zero rate at maturity t (year fraction from base_date).
    fn zero_rate_at_maturity(&self, t: f64) -> Number {
        if t.abs() < 1e-14 {
            // L'Hopital limit: r(0) = beta0 + beta1
            return &self.beta0 + &self.beta1;
        }
        let t_num = Number::F64(t);
        let t_over_tau = &t_num / &self.tau;
        let exp_neg = (-&t_over_tau).exp();
        let one = Number::F64(1.0);
        let factor1 = &(&one - &exp_neg) / &t_over_tau;
        let factor2 = &factor1 - &exp_neg;
        let term1 = &self.beta1 * &factor1;
        let term2 = &self.beta2 * &factor2;
        let sum = &self.beta0 + &term1;
        &sum + &term2
    }
}

impl NelsonSiegelSvensson {
    pub fn new(
        beta0: Number,
        beta1: Number,
        beta2: Number,
        beta3: Number,
        tau1: Number,
        tau2: Number,
        convention: DayCountConvention,
        base_date: NaiveDate,
        id: String,
    ) -> Self {
        match &tau1 {
            Number::F64(v) => assert!(*v > 0.0, "tau1 must be positive"),
            Number::Dual(d) => assert!(d.real() > 0.0, "tau1 must be positive"),
            Number::Dual2(d) => assert!(d.real() > 0.0, "tau1 must be positive"),
        }
        match &tau2 {
            Number::F64(v) => assert!(*v > 0.0, "tau2 must be positive"),
            Number::Dual(d) => assert!(d.real() > 0.0, "tau2 must be positive"),
            Number::Dual2(d) => assert!(d.real() > 0.0, "tau2 must be positive"),
        }
        Self { beta0, beta1, beta2, beta3, tau1, tau2, convention, base_date, id }
    }

    /// Compute zero rate at maturity t (year fraction from base_date).
    fn zero_rate_at_maturity(&self, t: f64) -> Number {
        if t.abs() < 1e-14 {
            // L'Hopital limit: r(0) = beta0 + beta1
            return &self.beta0 + &self.beta1;
        }

        let t_num = Number::F64(t);
        let one = Number::F64(1.0);

        // NS component with tau1
        let t_over_tau1 = &t_num / &self.tau1;
        let exp_neg1 = (-&t_over_tau1).exp();
        let factor1_1 = &(&one - &exp_neg1) / &t_over_tau1;
        let factor2_1 = &factor1_1 - &exp_neg1;

        // Second hump component with tau2
        let t_over_tau2 = &t_num / &self.tau2;
        let exp_neg2 = (-&t_over_tau2).exp();
        let factor1_2 = &(&one - &exp_neg2) / &t_over_tau2;
        let factor2_2 = &factor1_2 - &exp_neg2;

        let term1 = &self.beta1 * &factor1_1;
        let term2 = &self.beta2 * &factor2_1;
        let term3 = &self.beta3 * &factor2_2;
        let sum = &self.beta0 + &term1;
        let sum = &sum + &term2;
        &sum + &term3
    }
}

impl CurveQuery for NelsonSiegel {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        let dcf = self.convention.dcf(self.base_date, date, &DcfOptions::default()).unwrap();
        if dcf.abs() < 1e-14 {
            return Number::F64(1.0);
        }
        let rate = self.zero_rate_at_maturity(dcf);
        (&rate * (-dcf)).exp()
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        if dcf.abs() < 1e-14 {
            return Number::F64(0.0);
        }
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

impl CurveQuery for NelsonSiegelSvensson {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        let dcf = self.convention.dcf(self.base_date, date, &DcfOptions::default()).unwrap();
        if dcf.abs() < 1e-14 {
            return Number::F64(1.0);
        }
        let rate = self.zero_rate_at_maturity(dcf);
        (&rate * (-dcf)).exp()
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        if dcf.abs() < 1e-14 {
            return Number::F64(0.0);
        }
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::autodiff::dual::Dual;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn ns_fixture() -> NelsonSiegel {
        NelsonSiegel::new(
            Number::F64(0.05),   // beta0 - long-term level
            Number::F64(-0.02),  // beta1 - short-term component
            Number::F64(0.01),   // beta2 - medium-term hump
            Number::F64(1.5),    // tau - decay factor
            DayCountConvention::Act365F,
            ymd(2024, 1, 1),
            "ns_test".to_string(),
        )
    }

    // Test 1: NS at t=0 returns beta0 + beta1 = 0.03 (L'Hopital limit)
    #[test]
    fn test_ns_zero_rate_at_t_zero() {
        let ns = ns_fixture();
        let rate = ns.zero_rate_at_maturity(0.0);
        if let Number::F64(r) = rate {
            assert!((r - 0.03).abs() < 1e-10, "Expected 0.03, got {}", r);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 2: NS at t=10 converges toward beta0 = 0.05
    #[test]
    fn test_ns_zero_rate_converges_to_beta0() {
        let ns = ns_fixture();
        let rate = ns.zero_rate_at_maturity(10.0);
        if let Number::F64(r) = rate {
            // At t=10, the factor1 and factor2 terms decay, rate approaches beta0
            assert!((r - 0.05).abs() < 0.005, "Expected close to 0.05, got {}", r);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 3: NS discount_factor at base_date equals 1.0
    #[test]
    fn test_ns_discount_factor_at_base_date() {
        let ns = ns_fixture();
        let df = ns.discount_factor(ymd(2024, 1, 1));
        if let Number::F64(v) = df {
            assert!((v - 1.0).abs() < 1e-12, "Expected 1.0, got {}", v);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 4: NS discount_factor at 1Y matches exp(-rate * dcf)
    #[test]
    fn test_ns_discount_factor_at_1y() {
        let ns = ns_fixture();
        let date_1y = ymd(2025, 1, 1);
        let df = ns.discount_factor(date_1y);
        let dcf = DayCountConvention::Act365F.dcf(ymd(2024, 1, 1), date_1y, &DcfOptions::default()).unwrap();
        let rate = ns.zero_rate_at_maturity(dcf);
        if let (Number::F64(df_val), Number::F64(rate_val)) = (&df, &rate) {
            let expected_df = (-rate_val * dcf).exp();
            assert!(
                (df_val - expected_df).abs() < 1e-12,
                "DF={}, expected={}", df_val, expected_df
            );
        } else {
            panic!("Expected F64");
        }
    }

    // Test 5: NSS at t=0 returns beta0 + beta1
    #[test]
    fn test_nss_zero_rate_at_t_zero() {
        let nss = NelsonSiegelSvensson::new(
            Number::F64(0.05),
            Number::F64(-0.02),
            Number::F64(0.01),
            Number::F64(0.005),  // beta3
            Number::F64(1.5),    // tau1
            Number::F64(2.0),    // tau2
            DayCountConvention::Act365F,
            ymd(2024, 1, 1),
            "nss_test".to_string(),
        );
        let rate = nss.zero_rate_at_maturity(0.0);
        if let Number::F64(r) = rate {
            assert!((r - 0.03).abs() < 1e-10, "Expected 0.03, got {}", r);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 6: NSS with beta3=0 reduces to NS result
    #[test]
    fn test_nss_with_beta3_zero_equals_ns() {
        let ns = ns_fixture();
        let nss = NelsonSiegelSvensson::new(
            Number::F64(0.05),
            Number::F64(-0.02),
            Number::F64(0.01),
            Number::F64(0.0),   // beta3 = 0 -> reduces to NS
            Number::F64(1.5),   // tau1 = same as NS tau
            Number::F64(2.0),   // tau2 = irrelevant when beta3=0
            DayCountConvention::Act365F,
            ymd(2024, 1, 1),
            "nss_test".to_string(),
        );

        for t in [0.5, 1.0, 2.0, 5.0, 10.0] {
            let ns_rate = ns.zero_rate_at_maturity(t);
            let nss_rate = nss.zero_rate_at_maturity(t);
            if let (Number::F64(a), Number::F64(b)) = (&ns_rate, &nss_rate) {
                assert!(
                    (a - b).abs() < 1e-12,
                    "NS/NSS mismatch at t={}: NS={}, NSS={}", t, a, b
                );
            } else {
                panic!("Expected F64");
            }
        }
    }

    // Test 7: AD propagation -- NS with Dual parameters returns Dual from discount_factor
    #[test]
    fn test_ns_ad_propagation() {
        let beta0 = Dual::new("beta0", 0.05);
        let beta1 = Dual::new_from(&beta0, -0.02);
        let beta2 = Dual::new_from(&beta0, 0.01);
        let tau = Dual::new_from(&beta0, 1.5);
        let ns = NelsonSiegel::new(
            Number::Dual(beta0),
            Number::Dual(beta1),
            Number::Dual(beta2),
            Number::Dual(tau),
            DayCountConvention::Act365F,
            ymd(2024, 1, 1),
            "ns_ad".to_string(),
        );
        let df = ns.discount_factor(ymd(2025, 1, 1));
        if let Number::Dual(d) = df {
            assert!(d.real() > 0.0 && d.real() < 1.0, "DF should be between 0 and 1, got {}", d.real());
            // Derivative with respect to beta0 should be negative (higher rate -> lower DF)
            assert!(d.dual[0] < 0.0, "dDF/dbeta0 should be negative");
        } else {
            panic!("Expected Dual from NS discount_factor with Dual params");
        }
    }

    // Test 8: Serde roundtrip for NelsonSiegel
    #[test]
    fn test_serde_ns_roundtrip() {
        let ns = ns_fixture();
        let json = serde_json::to_string(&ns).unwrap();
        let restored: NelsonSiegel = serde_json::from_str(&json).unwrap();
        // Verify DF at 1Y matches
        let df_orig = ns.discount_factor(ymd(2025, 1, 1));
        let df_restored = restored.discount_factor(ymd(2025, 1, 1));
        if let (Number::F64(a), Number::F64(b)) = (&df_orig, &df_restored) {
            assert!((a - b).abs() < 1e-12, "NS DF mismatch: {} vs {}", a, b);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 9: forward_rate between two dates returns positive rate for normal curve shape
    #[test]
    fn test_ns_forward_rate_positive() {
        let ns = ns_fixture();
        let fwd = ns.forward_rate(ymd(2025, 1, 1), ymd(2026, 1, 1));
        if let Number::F64(r) = fwd {
            assert!(r > 0.0, "Forward rate should be positive, got {}", r);
        } else {
            panic!("Expected F64");
        }
    }
}
