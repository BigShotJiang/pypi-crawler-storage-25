use chrono::{Datelike, NaiveDate};
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::{CurveInterpolation, Interpolator};
use crate::marketcurves::interpolation::natural_cubic::NaturalCubicInterpolator;
use crate::marketcurves::interpolation::log_cubic::LogCubicInterpolator;
use crate::marketcurves::interpolation::hermite::HermiteInterpolator;
use crate::marketcurves::interpolation::monotone_cubic::MonotoneCubicInterpolator;
use crate::marketcurves::interpolation::utils::index_left;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::adjuster::Adjuster;
use crate::calendar::cal::BusinessCalendar;
use crate::marketcurves::curve::CurveQuery;

/// 5-point Gauss-Legendre quadrature nodes on [-1, 1].
const GL_NODES: [f64; 5] = [
    -0.9061798459386640,
    -0.5384693101056831,
     0.0,
     0.5384693101056831,
     0.9061798459386640,
];

/// 5-point Gauss-Legendre quadrature weights.
const GL_WEIGHTS: [f64; 5] = [
    0.2369268850561891,
    0.4786286704993665,
    0.5688888888888889,
    0.4786286704993665,
    0.2369268850561891,
];

/// A forward rate curve that stores instantaneous forward rates f(t) and derives
/// discount factors via piecewise analytic integration: DF(t) = exp(-integral(f(s)ds)).
///
/// Key differences from DiscountCurve:
/// - Node values are forward rates, not discount factors
/// - DF at first node = 1.0 by construction (zero integral)
/// - ini_solve = 0: all nodes are calibratable (no fixed first node)
/// - Integration engine converts forward rates to discount factors
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ForwardCurve {
    pub nodes: Nodes,
    pub interpolator: Interpolator,
    pub convention: DayCountConvention,
    pub modifier: Adjuster,
    pub calendar: Option<BusinessCalendar>,
    pub id: String,
    /// Precomputed cumulative integrals of forward rates at each node (f64 fast path).
    /// cum_integrals[0] = 0.0 (integral from first node to first node).
    /// cum_integrals[i] = integral of f(s) from x_0 to x_i.
    #[serde(skip)]
    cum_integrals: Vec<f64>,
}

impl ForwardCurve {
    /// Create a new ForwardCurve. No ensure_first_df_one -- DF=1.0 at first node
    /// by construction (zero integral). Calls rebuild_integrals().
    pub fn new(
        nodes: Nodes,
        interpolator: Interpolator,
        convention: DayCountConvention,
        id: String,
    ) -> Self {
        let mut curve = Self {
            nodes,
            interpolator,
            convention,
            modifier: Adjuster::ModifiedFollowing,
            calendar: None,
            id,
            cum_integrals: Vec::new(),
        };
        curve.rebuild_integrals();
        curve
    }

    pub fn set_nodes(&mut self, nodes: Nodes) {
        self.nodes = nodes;
        self.rebuild_integrals();
    }

    /// Get f64 values from all nodes (delegates to nodes.get_values_f64).
    pub fn get_node_values(&self) -> Vec<f64> {
        self.nodes.get_values_f64()
    }

    /// Set node values as f64, then rebuild integrals.
    pub fn set_node_values(&mut self, values: &[f64]) {
        self.nodes.set_values_as_f64(values);
        self.rebuild_integrals();
    }

    /// Number of solver variables. For ForwardCurve, all nodes are calibratable.
    pub fn n_vars(&self) -> usize {
        self.nodes.len().saturating_sub(self.ini_solve())
    }

    /// Index at which solver variables start.
    /// For ForwardCurve this is 0 (all nodes participate in the solve).
    pub fn ini_solve(&self) -> usize {
        0
    }

    /// Rebuild the precomputed cumulative integrals (f64 fast path).
    /// Uses 5-point Gauss-Legendre quadrature per interval for all interpolator types.
    fn rebuild_integrals(&mut self) {
        let n = self.nodes.len();
        if n < 2 {
            self.cum_integrals = vec![0.0; n];
            return;
        }

        let xs = self.nodes.keys_as_f64();
        let vals = self.nodes.get_values_f64();

        let mut cum = vec![0.0; n];
        for i in 0..(n - 1) {
            let x_lo = xs[i];
            let x_hi = xs[i + 1];
            let interval_integral = self.integrate_interval_f64(x_lo, x_hi, &xs, &vals);
            cum[i + 1] = cum[i] + interval_integral;
        }
        self.cum_integrals = cum;
    }

    /// Integrate the interpolated forward rate over [x_lo, x_hi] using f64 values.
    /// Uses analytic formula for FlatForward; 5-point GL quadrature otherwise.
    ///
    /// Note: When x_lo is exactly a node point, index_left returns the index of the
    /// previous interval (closed right boundary). We use a tiny epsilon offset to
    /// ensure correct interval identification for the current interval.
    fn integrate_interval_f64(&self, x_lo: f64, x_hi: f64, xs: &[f64], vals: &[f64]) -> f64 {
        let dt = x_hi - x_lo;
        if dt.abs() < 1e-15 {
            return 0.0;
        }

        // Use midpoint for index lookup to avoid boundary ambiguity
        let x_mid = (x_lo + x_hi) / 2.0;

        match &self.interpolator {
            Interpolator::FlatForward => {
                // Flat forward returns left node value throughout interval
                let idx = index_left(x_mid, xs);
                vals[idx] * dt
            }
            Interpolator::FlatBackward => {
                // Flat backward returns right node value throughout interval
                let idx = index_left(x_mid, xs);
                let right_idx = (idx + 1).min(vals.len() - 1);
                vals[right_idx] * dt
            }
            Interpolator::Linear => {
                // Linear: integral = (f_lo + f_hi) / 2 * dt (trapezoidal)
                let idx = index_left(x_mid, xs);
                let f_lo = vals[idx];
                let f_hi = vals[idx + 1];
                (f_lo + f_hi) / 2.0 * dt
            }
            _ => {
                // General case: 5-point Gauss-Legendre quadrature
                self.gl_quadrature_f64(x_lo, x_hi, xs, vals)
            }
        }
    }

    /// 5-point Gauss-Legendre quadrature over [a, b] using f64 interpolation.
    fn gl_quadrature_f64(&self, a: f64, b: f64, xs: &[f64], vals: &[f64]) -> f64 {
        let half_width = (b - a) / 2.0;
        let mid = (a + b) / 2.0;
        let mut sum = 0.0;
        for k in 0..5 {
            let x = mid + half_width * GL_NODES[k];
            // Evaluate interpolated forward rate at x using f64 arithmetic
            let f_val = self.eval_interp_f64(x, xs, vals);
            sum += GL_WEIGHTS[k] * f_val;
        }
        half_width * sum
    }

    /// Evaluate interpolated forward rate at point x using f64 values directly.
    /// This avoids going through the Number type for the precomputation path.
    fn eval_interp_f64(&self, x: f64, xs: &[f64], vals: &[f64]) -> f64 {
        // For the f64 fast path, we use a simple interpolation
        // that matches what the interpolator would produce
        let n = xs.len();
        if n == 0 { return 0.0; }
        if x <= xs[0] { return vals[0]; }
        if x >= xs[n - 1] { return vals[n - 1]; }

        let idx = index_left(x, xs);

        match &self.interpolator {
            Interpolator::FlatForward => vals[idx],
            Interpolator::FlatBackward => vals[idx + 1],
            Interpolator::Linear | Interpolator::LinearZeroRate => {
                // Linear interpolation
                let t = (x - xs[idx]) / (xs[idx + 1] - xs[idx]);
                vals[idx] * (1.0 - t) + vals[idx + 1] * t
            }
            Interpolator::LogLinear => {
                // Log-linear interpolation
                let t = (x - xs[idx]) / (xs[idx + 1] - xs[idx]);
                (vals[idx].ln() * (1.0 - t) + vals[idx + 1].ln() * t).exp()
            }
            _ => {
                // For complex interpolators (cubic, etc.), use the full interpolator
                // through the Number path -- extract f64
                let date = NaiveDate::from_num_days_from_ce_opt(x as i32).unwrap();
                match self.interpolator.interpolated_value(&self.nodes, date) {
                    Number::F64(v) => v,
                    Number::Dual(d) => d.real(),
                    Number::Dual2(d) => d.real(),
                }
            }
        }
    }

    /// Compute the integral of the forward rate from the first node to a given x
    /// using Number arithmetic (supports AD: Dual/Dual2).
    /// This is the on-the-fly path used when nodes carry AD state.
    fn integral_to_x_number(&self, x: f64) -> Number {
        let xs = self.nodes.keys_as_f64();
        let n = xs.len();
        if n == 0 { return Number::F64(0.0); }
        if x <= xs[0] { return Number::F64(0.0); }

        let mut total = Number::F64(0.0);

        // Sum full interval integrals
        for i in 0..(n - 1) {
            if x <= xs[i] { break; }
            let x_hi = if x < xs[i + 1] { x } else { xs[i + 1] };
            let interval_integral = self.gl_quadrature_number(xs[i], x_hi);
            total = &total + &interval_integral;
            if x <= xs[i + 1] { break; }
        }

        // If x > last node, extrapolate with flat forward (last node value)
        if x > xs[n - 1] {
            let last_fwd = self.nodes.get_value_at_index(n - 1);
            let extra_dt = x - xs[n - 1];
            total = &total + &(&last_fwd * extra_dt);
        }

        total
    }

    /// 5-point Gauss-Legendre quadrature over [a, b] using Number (AD-aware) interpolation.
    fn gl_quadrature_number(&self, a: f64, b: f64) -> Number {
        let half_width = (b - a) / 2.0;
        let mid = (a + b) / 2.0;
        let mut sum = Number::F64(0.0);
        for k in 0..5 {
            let x = mid + half_width * GL_NODES[k];
            let date = NaiveDate::from_num_days_from_ce_opt(x as i32)
                .unwrap_or_else(|| {
                    // Fallback for fractional days: round to nearest day
                    NaiveDate::from_num_days_from_ce_opt(x.round() as i32).unwrap()
                });
            let f_val = self.interpolator.interpolated_value(&self.nodes, date);
            sum = &sum + &(&f_val * GL_WEIGHTS[k]);
        }
        &sum * half_width
    }

    /// Rebuild stateful interpolator from current nodes after deserialization.
    /// Then rebuild integrals.
    pub fn rebuild_spline(&mut self) {
        match &self.interpolator {
            Interpolator::Spline { pp, local_interp, log_transform } => {
                let endpoint = pp.endpoint.clone();
                let local = *local_interp.clone();
                let lt = *log_transform;
                self.interpolator = Interpolator::build_spline(
                    &self.nodes, None, &endpoint, local, lt,
                );
            }
            Interpolator::NaturalCubic(_) => {
                self.interpolator = Interpolator::NaturalCubic(NaturalCubicInterpolator::build(&self.nodes));
            }
            Interpolator::LogCubic(_) => {
                self.interpolator = Interpolator::LogCubic(LogCubicInterpolator::build(&self.nodes));
            }
            Interpolator::Hermite(_) => {
                self.interpolator = Interpolator::Hermite(HermiteInterpolator::build(&self.nodes));
            }
            Interpolator::MonotoneCubic(_) => {
                self.interpolator = Interpolator::MonotoneCubic(MonotoneCubicInterpolator::build(&self.nodes));
            }
            Interpolator::ConvexMonotone(_) => {
                // ConvexMonotone is stateless -- no rebuild needed
            }
            _ => {} // stateless variants don't need rebuild
        }
        self.rebuild_integrals();
    }

    /// Serialize to JSON string.
    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap()
    }

    /// Deserialize from JSON string, rebuilding interpolator and integrals.
    pub fn from_json(s: &str) -> Result<Self, serde_json::Error> {
        let mut curve: Self = serde_json::from_str(s)?;
        curve.rebuild_spline();
        Ok(curve)
    }

    /// Check if nodes are in f64 mode (no AD state).
    fn is_f64_mode(&self) -> bool {
        matches!(&self.nodes, Nodes::F64(_))
    }
}

impl CurveQuery for ForwardCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let xs = self.nodes.keys_as_f64();

        if xs.is_empty() {
            return Number::F64(1.0);
        }

        // At or before first node: DF = 1.0
        if x <= xs[0] {
            return Number::F64(1.0);
        }

        if self.is_f64_mode() && !self.cum_integrals.is_empty() {
            // Fast path: use precomputed cumulative integrals
            let n = xs.len();
            if x >= xs[n - 1] {
                // Extrapolation: flat forward from last node
                let vals = self.nodes.get_values_f64();
                let last_fwd = vals[n - 1];
                let extra_integral = last_fwd * (x - xs[n - 1]);
                let total = self.cum_integrals[n - 1] + extra_integral;
                return Number::F64((-total).exp());
            }

            let idx = index_left(x, &xs);
            // Partial integral within the interval [xs[idx], x]
            let vals = self.nodes.get_values_f64();
            let partial = self.integrate_interval_f64(xs[idx], x, &xs, &vals);
            let total = self.cum_integrals[idx] + partial;
            Number::F64((-total).exp())
        } else {
            // AD path: compute integral on the fly using Number arithmetic
            let integral = self.integral_to_x_number(x);
            (&integral * (-1.0)).exp()
        }
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        if dcf.abs() < 1e-15 {
            return Number::F64(0.0);
        }
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        // Average forward rate over [start, end], derived from discount factors
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    #[test]
    fn test_forward_df_anchor() {
        // DF at first node should be exactly 1.0
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.05),
            (ymd(2025, 1, 1), 0.05),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd".to_string(),
        );
        let df = curve.discount_factor(ymd(2024, 1, 1));
        if let Number::F64(v) = df {
            assert!((v - 1.0).abs() < 1e-15, "DF at first node should be 1.0, got {}", v);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_forward_flat_forward_exact() {
        // Flat forward at 5% = 0.05 per day (in num_days_from_ce units)
        // But we need to think in terms of the x-axis: num_days_from_ce
        // DF(t) = exp(-f * (x - x0)) where f is forward rate and x is in days
        let rate = 0.05; // forward rate per day

        let d0 = ymd(2024, 1, 1);
        let d1 = ymd(2025, 1, 1); // 366 days (2024 is leap year)
        let d2 = ymd(2026, 1, 1); // 365 more days

        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (d0, rate),
            (d1, rate),
            (d2, rate),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd_flat".to_string(),
        );

        // DF at 1Y: exp(-0.05 * 366) -- but 0.05 per day is huge!
        // More realistic: treat node values as forward rate per day.
        // Actually, in the interpolation framework, the x-axis is num_days_from_ce.
        // So the integral is in "days" and the forward rate is "per day".
        //
        // For a sensible test, let's use annual rates.
        // With flat forward at annual rate r, and integral over [x0, x1] days:
        // integral = r * (x1 - x0) days * (1/365.25) years? No -- the integral is directly r * dt_days.
        //
        // The ForwardCurve stores rates that, when integrated over the x-axis (days),
        // give the log of the discount factor. So if we want DF(1Y) = exp(-0.05),
        // we need the forward rate per day = 0.05 / 366.
        let rate_per_day = 0.05 / 366.0;
        let nodes2 = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (d0, rate_per_day),
            (d1, rate_per_day),
            (d2, rate_per_day),
        ]));
        let curve2 = ForwardCurve::new(
            nodes2,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd_flat2".to_string(),
        );

        let df_1y = curve2.discount_factor(d1);
        let expected_1y = (-0.05_f64).exp(); // exp(-rate_per_day * 366) = exp(-0.05)
        if let Number::F64(v) = df_1y {
            assert!(
                (v - expected_1y).abs() < 1e-12,
                "DF at 1Y: got {}, expected {} (diff={})", v, expected_1y, (v - expected_1y).abs()
            );
        } else {
            panic!("Expected F64");
        }

        let df_2y = curve2.discount_factor(d2);
        // integral from d0 to d2 = rate_per_day * (366 + 365) = 0.05/366 * 731
        let expected_2y = (-(rate_per_day * 731.0)).exp();
        if let Number::F64(v) = df_2y {
            assert!(
                (v - expected_2y).abs() < 1e-12,
                "DF at 2Y: got {}, expected {} (diff={})", v, expected_2y, (v - expected_2y).abs()
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_forward_linear_integration() {
        // Linear interpolation between two forward rates
        let d0 = ymd(2024, 1, 1);
        let d1 = ymd(2025, 1, 1);
        let r0 = 0.03 / 366.0; // per day
        let r1 = 0.05 / 366.0; // per day
        let dt = 366.0; // days

        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (d0, r0),
            (d1, r1),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "fwd_linear".to_string(),
        );

        // With linear interpolation, integral = (r0 + r1)/2 * dt (trapezoidal)
        let expected_integral = (r0 + r1) / 2.0 * dt;
        let expected_df = (-expected_integral).exp();

        let df = curve.discount_factor(d1);
        if let Number::F64(v) = df {
            assert!(
                (v - expected_df).abs() < 1e-12,
                "DF with linear fwd: got {}, expected {} (diff={})", v, expected_df, (v - expected_df).abs()
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_forward_df_consistency() {
        // Test: df -> zero_rate -> forward_rate roundtrip consistency
        let d0 = ymd(2024, 1, 1);
        let d1 = ymd(2025, 1, 1);
        let d2 = ymd(2026, 1, 1);
        let rate_per_day = 0.04 / 366.0;

        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (d0, rate_per_day),
            (d1, rate_per_day * 1.1),
            (d2, rate_per_day * 1.2),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "fwd_consist".to_string(),
        );

        let df_0 = curve.discount_factor(d0);
        let df_1 = curve.discount_factor(d1);
        let df_2 = curve.discount_factor(d2);

        // Zero rate from d0 to d1 should be consistent with DF
        let zr_01 = curve.zero_rate(d0, d1);
        let dcf_01 = DayCountConvention::Act365F.dcf(d0, d1, &DcfOptions::default()).unwrap();

        if let (Number::F64(df0), Number::F64(df1), Number::F64(zr)) = (&df_0, &df_1, &zr_01) {
            let expected_zr = -(df1 / df0).ln() / dcf_01;
            assert!(
                (zr - expected_zr).abs() < 1e-10,
                "Zero rate mismatch: got {}, expected {}", zr, expected_zr
            );
        } else {
            panic!("Expected F64 values");
        }

        // Forward rate from d1 to d2 should be consistent with DFs
        let fwd_12 = curve.forward_rate(d1, d2);
        let dcf_12 = DayCountConvention::Act365F.dcf(d1, d2, &DcfOptions::default()).unwrap();

        if let (Number::F64(df1), Number::F64(df2), Number::F64(fwd)) = (&df_1, &df_2, &fwd_12) {
            let expected_fwd = -(df2 / df1).ln() / dcf_12;
            assert!(
                (fwd - expected_fwd).abs() < 1e-10,
                "Forward rate mismatch: got {}, expected {}", fwd, expected_fwd
            );
        } else {
            panic!("Expected F64 values");
        }
    }

    #[test]
    fn test_forward_serde_roundtrip() {
        let d0 = ymd(2024, 1, 1);
        let d1 = ymd(2025, 1, 1);
        let d2 = ymd(2026, 1, 1);
        let rate_per_day = 0.04 / 366.0;

        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (d0, rate_per_day),
            (d1, rate_per_day * 1.1),
            (d2, rate_per_day * 1.2),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd_serde".to_string(),
        );

        let json = curve.to_json();
        let restored = ForwardCurve::from_json(&json).unwrap();

        // DF values should match after roundtrip
        for date in &[d0, d1, d2] {
            let df_orig = curve.discount_factor(*date);
            let df_restored = restored.discount_factor(*date);
            if let (Number::F64(a), Number::F64(b)) = (&df_orig, &df_restored) {
                assert!(
                    (a - b).abs() < 1e-12,
                    "DF mismatch at {:?}: {} vs {}", date, a, b
                );
            } else {
                panic!("Expected F64");
            }
        }

        assert_eq!(restored.id, "fwd_serde");
    }

    #[test]
    fn test_forward_ini_solve() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.05),
            (ymd(2025, 1, 1), 0.05),
            (ymd(2026, 1, 1), 0.05),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd".to_string(),
        );
        assert_eq!(curve.ini_solve(), 0, "ForwardCurve ini_solve should be 0");
        assert_eq!(curve.n_vars(), 3, "n_vars should equal nodes.len()");
    }

    #[test]
    fn test_forward_extrapolation() {
        // Beyond last node: flat forward extrapolation using last forward rate
        let d0 = ymd(2024, 1, 1);
        let d1 = ymd(2025, 1, 1);
        let rate_per_day = 0.05 / 366.0;

        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (d0, rate_per_day),
            (d1, rate_per_day),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd_extrap".to_string(),
        );

        // DF at 2Y should use constant forward rate beyond last node
        let d2 = ymd(2026, 1, 1);
        let days_total = (d2 - d0).num_days() as f64;
        let expected_df = (-rate_per_day * days_total).exp();
        let df = curve.discount_factor(d2);
        if let Number::F64(v) = df {
            assert!(
                (v - expected_df).abs() < 1e-12,
                "Extrapolated DF: got {}, expected {}", v, expected_df
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_forward_natural_cubic() {
        // Test with natural cubic interpolation -- verify it doesn't crash and gives reasonable DFs
        let d0 = ymd(2024, 1, 1);
        let d1 = ymd(2025, 1, 1);
        let d2 = ymd(2026, 1, 1);
        let d3 = ymd(2027, 1, 1);
        let d4 = ymd(2028, 1, 1);
        let rate_per_day = 0.04 / 366.0;

        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (d0, rate_per_day),
            (d1, rate_per_day * 1.05),
            (d2, rate_per_day * 1.10),
            (d3, rate_per_day * 1.12),
            (d4, rate_per_day * 1.15),
        ]));

        let interp = Interpolator::NaturalCubic(NaturalCubicInterpolator::build(&nodes));
        let curve = ForwardCurve::new(
            nodes,
            interp,
            DayCountConvention::Act365F,
            "fwd_cubic".to_string(),
        );

        // DF at first node = 1.0
        let df0 = curve.discount_factor(d0);
        if let Number::F64(v) = df0 {
            assert!((v - 1.0).abs() < 1e-15, "DF at first node: {}", v);
        }

        // DF should be positive and < 1.0 at subsequent dates
        for date in &[d1, d2, d3, d4] {
            let df = curve.discount_factor(*date);
            if let Number::F64(v) = df {
                assert!(v > 0.0 && v < 1.0, "DF at {:?} = {} should be in (0, 1)", date, v);
            } else {
                panic!("Expected F64");
            }
        }

        // DFs should be monotonically decreasing
        let dfs: Vec<f64> = [d0, d1, d2, d3, d4].iter().map(|d| {
            match curve.discount_factor(*d) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            }
        }).collect();
        for i in 1..dfs.len() {
            assert!(dfs[i] < dfs[i - 1], "DFs not monotone: DF[{}]={} >= DF[{}]={}", i, dfs[i], i - 1, dfs[i - 1]);
        }
    }
}
