use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::marketcurves::curve::{CurveQuery, DiscountCurve, LineCurve};
use crate::marketcurves::forward_curve::ForwardCurve;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::calendar::convention::{DayCountConvention, DcfOptions};

/// Polymorphic container for inner curves used by SpreadCurve and TurnOfYearCurve.
/// Enables owned storage of a DiscountCurve, LineCurve, or ForwardCurve.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum CurveContainer {
    Discount(DiscountCurve),
    Line(LineCurve),
    Forward(ForwardCurve),
}

impl CurveQuery for CurveContainer {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        match self {
            CurveContainer::Discount(c) => c.discount_factor(date),
            CurveContainer::Line(c) => c.discount_factor(date),
            CurveContainer::Forward(c) => c.discount_factor(date),
        }
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        match self {
            CurveContainer::Discount(c) => c.zero_rate(start, end),
            CurveContainer::Line(c) => c.zero_rate(start, end),
            CurveContainer::Forward(c) => c.zero_rate(start, end),
        }
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        match self {
            CurveContainer::Discount(c) => c.forward_rate(start, end),
            CurveContainer::Line(c) => c.forward_rate(start, end),
            CurveContainer::Forward(c) => c.forward_rate(start, end),
        }
    }
}

/// Spread application mode.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum SpreadMode {
    /// DF = DF_base * exp(-spread * dcf)
    Additive,
    /// DF = DF_base * DF_spread
    Multiplicative,
}

/// A spread curve that applies a spread over a base curve.
///
/// Not calibratable (query-only wrapper). Implements CurveQuery but is NOT
/// added to CurveRef per D-17.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SpreadCurve {
    /// Owned clone of the base curve.
    pub base: CurveContainer,
    /// Spread values as a LineCurve.
    pub spread: LineCurve,
    /// How the spread is applied.
    pub mode: SpreadMode,
    /// Day count convention for dcf computation (used in additive mode).
    pub convention: DayCountConvention,
    /// Curve identifier.
    pub id: String,
}

impl SpreadCurve {
    pub fn new(
        base: CurveContainer,
        spread: LineCurve,
        mode: SpreadMode,
        convention: DayCountConvention,
        id: String,
    ) -> Self {
        Self {
            base,
            spread,
            mode,
            convention,
            id,
        }
    }

    /// First node date of the spread curve, used as the base date for dcf calculation.
    fn base_date(&self) -> NaiveDate {
        self.spread.nodes.first_key()
    }

    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap()
    }

    pub fn from_json(s: &str) -> Result<Self, serde_json::Error> {
        let mut curve: Self = serde_json::from_str(s)?;
        // Rebuild interpolator on the spread LineCurve
        curve.spread.rebuild_spline();
        // Rebuild interpolator on the base curve container
        match &mut curve.base {
            CurveContainer::Discount(c) => c.rebuild_spline(),
            CurveContainer::Line(c) => c.rebuild_spline(),
            CurveContainer::Forward(c) => c.rebuild_spline(),
        }
        Ok(curve)
    }
}

impl CurveQuery for SpreadCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        let df_base = self.base.discount_factor(date);

        match self.mode {
            SpreadMode::Additive => {
                // Get interpolated spread value from LineCurve
                let spread_val = self.spread.interpolator.interpolated_value(
                    &self.spread.nodes,
                    date,
                );
                // Compute dcf from base_date to query date
                let dcf = self.convention.dcf(
                    self.base_date(),
                    date,
                    &DcfOptions::default(),
                ).unwrap();
                // DF = DF_base * exp(-spread * dcf)
                let adjustment = (&spread_val * (-dcf)).exp();
                &df_base * &adjustment
            }
            SpreadMode::Multiplicative => {
                // Get spread DF from the LineCurve (treated as a curve)
                let df_spread = self.spread.discount_factor(date);
                &df_base * &df_spread
            }
        }
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn base_discount_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.95),
            (ymd(2026, 1, 1), 0.90),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "base".to_string(),
        )
    }

    fn spread_line_curve(rate: f64) -> LineCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), rate),
            (ymd(2025, 1, 1), rate),
            (ymd(2026, 1, 1), rate),
        ]));
        LineCurve::new(
            nodes,
            Interpolator::Linear,
            DayCountConvention::Act365F,
            "spread".to_string(),
        )
    }

    #[test]
    fn test_spread_additive() {
        // Base DF at 1Y = 0.95, spread = 0.01 (100bp)
        let base = base_discount_curve();
        let spread = spread_line_curve(0.01);
        let curve = SpreadCurve::new(
            CurveContainer::Discount(base.clone()),
            spread,
            SpreadMode::Additive,
            DayCountConvention::Act365F,
            "spread_add".to_string(),
        );

        let date = ymd(2025, 1, 1);
        let df = curve.discount_factor(date);
        let base_df = base.discount_factor(date);

        // Expected: base_df * exp(-0.01 * dcf(2024-01-01, 2025-01-01))
        // dcf = 366/365 (2024 is leap year)
        let dcf = 366.0 / 365.0;
        let expected = if let Number::F64(b) = base_df {
            b * (-0.01 * dcf).exp()
        } else {
            panic!("Expected F64");
        };

        if let Number::F64(v) = df {
            assert!(
                (v - expected).abs() < 1e-12,
                "Additive spread DF: got {}, expected {}",
                v,
                expected
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_spread_multiplicative() {
        // Base DF at 1Y = 0.95, spread LineCurve with rate 0.01
        let base = base_discount_curve();
        let spread = spread_line_curve(0.01);
        let curve = SpreadCurve::new(
            CurveContainer::Discount(base.clone()),
            spread.clone(),
            SpreadMode::Multiplicative,
            DayCountConvention::Act365F,
            "spread_mult".to_string(),
        );

        let date = ymd(2025, 1, 1);
        let df = curve.discount_factor(date);
        let base_df = base.discount_factor(date);
        let spread_df = spread.discount_factor(date);

        // Expected: base_df * spread_df
        let expected = if let (Number::F64(b), Number::F64(s)) = (&base_df, &spread_df) {
            b * s
        } else {
            panic!("Expected F64");
        };

        if let Number::F64(v) = df {
            assert!(
                (v - expected).abs() < 1e-12,
                "Multiplicative spread DF: got {}, expected {}",
                v,
                expected
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_curve_container_dispatch() {
        // CurveContainer::Discount delegates correctly
        let base = base_discount_curve();
        let container = CurveContainer::Discount(base.clone());

        let date = ymd(2025, 1, 1);
        let df_container = container.discount_factor(date);
        let df_direct = base.discount_factor(date);

        assert_eq!(df_container, df_direct);

        // CurveContainer::Line delegates correctly
        let line = spread_line_curve(0.03);
        let container_line = CurveContainer::Line(line.clone());

        let df_container_line = container_line.discount_factor(date);
        let df_direct_line = line.discount_factor(date);

        assert_eq!(df_container_line, df_direct_line);
    }

    #[test]
    fn test_spread_serde_roundtrip() {
        let base = base_discount_curve();
        let spread = spread_line_curve(0.01);
        let curve = SpreadCurve::new(
            CurveContainer::Discount(base),
            spread,
            SpreadMode::Additive,
            DayCountConvention::Act365F,
            "spread_serde".to_string(),
        );

        let json = curve.to_json();
        let restored = SpreadCurve::from_json(&json).expect("from_json should succeed");

        let date = ymd(2025, 1, 1);
        let df_orig = curve.discount_factor(date);
        let df_restored = restored.discount_factor(date);

        if let (Number::F64(a), Number::F64(b)) = (&df_orig, &df_restored) {
            assert!(
                (a - b).abs() < 1e-12,
                "Serde roundtrip: orig DF={}, restored DF={}",
                a,
                b
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_spread_zero_rate() {
        // Verify zero_rate is computed from DF ratio
        let base = base_discount_curve();
        let spread = spread_line_curve(0.005);
        let curve = SpreadCurve::new(
            CurveContainer::Discount(base),
            spread,
            SpreadMode::Additive,
            DayCountConvention::Act365F,
            "spread_zr".to_string(),
        );

        let rate = curve.zero_rate(ymd(2024, 1, 1), ymd(2025, 1, 1));
        if let Number::F64(r) = rate {
            assert!(r > 0.0, "Zero rate should be positive, got {}", r);
        } else {
            panic!("Expected F64");
        }
    }
}
