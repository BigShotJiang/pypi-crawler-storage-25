use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::cubic_spline::CubicSplineCoeffs;

/// Natural cubic spline interpolator.
///
/// Fits a C2-continuous cubic spline through node values with natural boundary
/// conditions (S''=0 at endpoints). Uses the shared CubicSplineCoeffs solver
/// without log-transform (operates directly on y-values).
#[derive(Clone, Debug)]
pub struct NaturalCubicInterpolator {
    pub coeffs: CubicSplineCoeffs,
}

impl NaturalCubicInterpolator {
    /// Create a placeholder instance (used during deserialization before rebuild).
    pub fn placeholder() -> Self {
        Self { coeffs: CubicSplineCoeffs::empty() }
    }

    /// Build a natural cubic spline from the given nodes.
    pub fn build(nodes: &Nodes) -> Self {
        Self {
            coeffs: CubicSplineCoeffs::build(nodes, false), // no log transform
        }
    }
}

impl CurveInterpolation for NaturalCubicInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let last_x = *self.coeffs.x.last().unwrap();

        // Flat forward extrapolation beyond last node
        if x >= last_x {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        self.coeffs.eval(x)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;
    use indexmap::IndexMap;
    use crate::autodiff::dual::{Dual, Vars};
    use crate::autodiff::enums::Number;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn make_f64_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.90),
            (ymd(2028, 1, 1), 0.85),
        ]))
    }

    #[test]
    fn test_natural_cubic_reproduces_nodes() {
        // Test 1: Interpolate at each node date -- reproduces exact value within 1e-12
        let nodes = make_f64_nodes();
        let interp = NaturalCubicInterpolator::build(&nodes);
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
        ];
        let expected = vec![1.0, 0.97, 0.94, 0.90];

        for (date, exp) in dates.iter().zip(expected.iter()) {
            let val = interp.interpolated_value(&nodes, *date);
            match val {
                Number::F64(v) => assert!(
                    (v - exp).abs() < 1e-12,
                    "At {:?}: got {} expected {}",
                    date, v, exp
                ),
                _ => panic!("Expected F64"),
            }
        }
    }

    #[test]
    fn test_natural_cubic_midpoint_between_nodes() {
        // Test 2: Interpolate at mid-interval -- value between adjacent nodes for monotone input
        let nodes = make_f64_nodes();
        let interp = NaturalCubicInterpolator::build(&nodes);
        let mid_date = ymd(2025, 7, 1);
        let val = interp.interpolated_value(&nodes, mid_date);
        match val {
            Number::F64(v) => assert!(
                v > 0.93 && v < 0.98,
                "Mid-point value {} should be between adjacent nodes",
                v
            ),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_natural_cubic_extrapolation_flat() {
        // Test 3: Extrapolation beyond last node returns last node value
        let nodes = make_f64_nodes();
        let interp = NaturalCubicInterpolator::build(&nodes);
        let far_date = ymd(2030, 1, 1);
        let val = interp.interpolated_value(&nodes, far_date);
        match val {
            Number::F64(v) => assert!(
                (v - 0.85).abs() < 1e-12,
                "Extrapolation should return last node value, got {}",
                v
            ),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_natural_cubic_ad_dual() {
        // Test 4: Build with Dual nodes, query mid-interval, result is Number::Dual with derivatives
        let vars = vec![
            "v0".to_string(),
            "v1".to_string(),
            "v2".to_string(),
            "v3".to_string(),
        ];
        let d0 = Dual::try_new(1.0, vars.clone(), vec![0.0, 0.0, 0.0, 0.0]).unwrap();
        let d1 = Dual::try_new(0.97, vars.clone(), vec![1.0, 0.0, 0.0, 0.0]).unwrap();
        let d2 = Dual::try_new(0.94, vars.clone(), vec![0.0, 1.0, 0.0, 0.0]).unwrap();
        let d3 = Dual::try_new(0.90, vars.clone(), vec![0.0, 0.0, 1.0, 0.0]).unwrap();
        let d4 = Dual::try_new(0.85, vars.clone(), vec![0.0, 0.0, 0.0, 1.0]).unwrap();

        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d0),
            (ymd(2025, 1, 1), d1),
            (ymd(2026, 1, 1), d2),
            (ymd(2027, 1, 1), d3),
            (ymd(2028, 1, 1), d4),
        ]));

        let interp = NaturalCubicInterpolator::build(&nodes);
        let val = interp.interpolated_value(&nodes, ymd(2025, 7, 1));
        match val {
            Number::Dual(d) => {
                assert!(d.real() > 0.93 && d.real() < 0.97, "Real: {}", d.real());
                let has_deriv = d.dual.iter().any(|&v| v.abs() > 1e-15);
                assert!(has_deriv, "Should have non-zero derivatives");
            }
            _ => panic!("Expected Dual"),
        }
    }

    #[test]
    fn test_natural_cubic_ad_vs_fd_jacobian() {
        // Test 5: Full Jacobian FD vs AD test (D-05/D-06)
        let base_values = vec![1.0, 0.97, 0.94, 0.90, 0.85];
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
            ymd(2028, 1, 1),
        ];
        let query_date = ymd(2025, 7, 1);
        let bump = 1e-6;

        // For each node j (skip j=0 which is DF=1.0 constant)
        for j in 1..base_values.len() {
            // AD: build with Dual where node j has derivative = 1
            let vars: Vec<String> = (0..base_values.len())
                .map(|k| format!("v{}", k))
                .collect();
            let dual_nodes: Vec<Dual> = base_values
                .iter()
                .enumerate()
                .map(|(i, &v)| {
                    let mut derivs = vec![0.0; base_values.len()];
                    derivs[i] = 1.0;
                    Dual::try_new(v, vars.clone(), derivs).unwrap()
                })
                .collect();

            let nodes_dual = Nodes::from_dual_map(IndexMap::from_iter(
                dates.iter().cloned().zip(dual_nodes).collect::<Vec<_>>(),
            ));
            let interp = NaturalCubicInterpolator::build(&nodes_dual);
            let val = interp.interpolated_value(&nodes_dual, query_date);
            let ad_delta = match &val {
                Number::Dual(d) => d.dual[j],
                _ => panic!("Expected Dual"),
            };

            // FD: bump node j up and down
            let mut vals_up = base_values.clone();
            vals_up[j] += bump;
            let nodes_up = Nodes::from_f64_map(IndexMap::from_iter(
                dates.iter().cloned().zip(vals_up).collect::<Vec<_>>(),
            ));
            let interp_up = NaturalCubicInterpolator::build(&nodes_up);
            let v_up = match interp_up.interpolated_value(&nodes_up, query_date) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };

            let mut vals_dn = base_values.clone();
            vals_dn[j] -= bump;
            let nodes_dn = Nodes::from_f64_map(IndexMap::from_iter(
                dates.iter().cloned().zip(vals_dn).collect::<Vec<_>>(),
            ));
            let interp_dn = NaturalCubicInterpolator::build(&nodes_dn);
            let v_dn = match interp_dn.interpolated_value(&nodes_dn, query_date) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };

            let fd_delta = (v_up - v_dn) / (2.0 * bump);
            let rel_err = (ad_delta - fd_delta).abs() / fd_delta.abs().max(1e-10);
            assert!(
                rel_err < 1e-6,
                "Node {}: AD={:.10} FD={:.10} rel_err={:.2e}",
                j, ad_delta, fd_delta, rel_err
            );
        }
    }
}
