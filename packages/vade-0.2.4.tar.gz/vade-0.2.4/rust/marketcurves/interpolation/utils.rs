use crate::autodiff::ops::math_funcs::MathFuncs;
use std::ops::{Add, Mul, Sub};

/// Calculate the left sided index for a given value in a sorted list.
/// Clamped to [0, n-2] for extrapolation safety.
///
/// Examples:
/// If xs is [1.2, 1.7, 1.9, 2.8]:
/// - 0.5: returns 0 (extrapolated left)
/// - 1.5: returns 0 (within first interval)
/// - 1.7: returns 0 (closed right side of first interval)
/// - 1.71: returns 1 (within second interval)
/// - 2.8: returns 2 (closed right side of last interval)
/// - 3.5: returns 2 (extrapolated right)
pub fn index_left(x: f64, xs: &[f64]) -> usize {
    let n = xs.len();
    assert!(n >= 2, "index_left requires at least 2 elements");

    if x <= xs[0] {
        return 0;
    }
    if x >= xs[n - 1] {
        return n - 2;
    }

    // Binary search for the interval
    let mut lo = 0;
    let mut hi = n - 1;
    while hi - lo > 1 {
        let mid = (lo + hi) / 2;
        if x <= xs[mid] {
            hi = mid;
        } else {
            lo = mid;
        }
    }
    lo
}

/// Linear interpolation between two points.
/// Works with f64, Dual, and Dual2.
pub fn linear_interp<T>(x1: f64, y1: &T, x2: f64, y2: &T, x: f64) -> T
where
    for<'a> &'a T: Sub<&'a T, Output = T> + Add<&'a T, Output = T>,
    T: Mul<f64, Output = T>,
{
    y1 + &((y2 - y1) * ((x - x1) / (x2 - x1)))
}

/// Log-linear interpolation: exp(linear_interp(log(y1), log(y2), x)).
/// Works with f64, Dual, and Dual2.
pub fn log_linear_interp<T>(x1: f64, y1: &T, x2: f64, y2: &T, x: f64) -> T
where
    for<'a> &'a T: Sub<&'a T, Output = T> + Add<&'a T, Output = T>,
    T: Mul<f64, Output = T> + MathFuncs,
{
    let (ly1, ly2) = (y1.log(), y2.log());
    linear_interp(x1, &ly1, x2, &ly2, x).exp()
}

/// Linear zero rate interpolation.
/// Converts node values (DFs) to zero rates, linearly interpolates rates,
/// then converts back to DF.
/// Handles t1==0 case with flat forward (use r2).
pub fn linear_zero_interp<T>(x0: f64, x1: f64, y1: &T, x2: f64, y2: &T, x: f64) -> T
where
    for<'a> &'a T: Sub<&'a T, Output = T> + Add<&'a T, Output = T>,
    T: Mul<f64, Output = T> + MathFuncs + Clone,
{
    let t1: f64 = x1 - x0;
    let t2: f64 = x2 - x0;
    let t: f64 = x - x0;
    let r2: T = y2.log() * (-1.0 / t2);
    let r: T = if t1 == 0.0 {
        r2.clone() // Flat forward zero rate in first interval
    } else {
        let r1: T = y1.log() * (-1.0 / t1);
        &r1 + &((&r2 - &r1) * ((t - t1) / (t2 - t1)))
    };
    (r * (-t)).exp()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::autodiff::dual::Dual;
    use crate::autodiff::ops::math_funcs::MathFuncs;

    #[test]
    fn test_index_left_basic() {
        let xs = vec![1.2, 1.7, 1.9, 2.8];
        assert_eq!(index_left(0.5, &xs), 0);
        assert_eq!(index_left(1.5, &xs), 0);
        assert_eq!(index_left(1.7, &xs), 0); // closed right side
        assert_eq!(index_left(1.71, &xs), 1);
        assert_eq!(index_left(2.8, &xs), 2);
        assert_eq!(index_left(3.5, &xs), 2); // extrapolated right
    }

    #[test]
    fn test_index_left_two_elements() {
        let xs = vec![1.0, 2.0];
        assert_eq!(index_left(0.5, &xs), 0);
        assert_eq!(index_left(1.5, &xs), 0);
        assert_eq!(index_left(2.5, &xs), 0);
    }

    #[test]
    fn test_linear_interp_f64() {
        let result = linear_interp(1.0, &10.0, 2.0, &30.0, 1.5);
        assert_eq!(result, 20.0);
    }

    #[test]
    fn test_linear_interp_dual() {
        let y1 = Dual::new("x", 10.0);
        let y2 = Dual::new("y", 30.0);
        let result = linear_interp(1.0, &y1, 2.0, &y2, 1.5);
        assert_eq!(result.real(), 20.0);
    }

    #[test]
    fn test_log_linear_interp_f64() {
        let result = log_linear_interp(1.0, &10.0, 2.0, &30.0, 1.5);
        let expected = (0.5 * 10.0_f64.ln() + 0.5 * 30.0_f64.ln()).exp();
        assert!((result - expected).abs() < 1e-12);
    }

    #[test]
    fn test_log_linear_interp_dual() {
        let y1 = Dual::new("x", 10.0);
        let y2 = Dual::new("y", 30.0);
        let result = log_linear_interp(1.0, &y1, 2.0, &y2, 1.5);
        let expected = (0.5_f64 * y1.log() + 0.5_f64 * y2.log()).exp();
        assert!((result.real() - expected.real()).abs() < 1e-12);
    }

    #[test]
    fn test_linear_zero_interp_f64() {
        // nodes: x0=0, x1=366, y1=0.99, x2=731, y2=0.98
        // r2 = -ln(0.98) / 731
        // r1 = -ln(0.99) / 366
        // interpolation at x=547 (half-way between x1 and x2)
        let x0 = 0.0;
        let x1 = 366.0;
        let x2 = 731.0;
        let y1 = 0.99_f64;
        let y2 = 0.98_f64;
        let x = 547.0;
        let result = linear_zero_interp(x0, x1, &y1, x2, &y2, x);
        // r1 = -ln(0.99)/366, r2 = -ln(0.98)/731
        // r = r1 + ((547-366)/(731-366)) * (r2-r1)
        // expected = exp(-r*547)
        let r1 = -0.99_f64.ln() / 366.0;
        let r2 = -0.98_f64.ln() / 731.0;
        let t = 547.0;
        let r = r1 + ((t - 366.0) / (731.0 - 366.0)) * (r2 - r1);
        let expected = (-r * t).exp();
        assert!((result - expected).abs() < 1e-12);
    }

    #[test]
    fn test_linear_zero_interp_first_interval() {
        // When t1==0, use flat forward (r = r2)
        let x0 = 0.0;
        let x1 = 0.0; // first node at x0
        let x2 = 366.0;
        let y1 = 1.0_f64;
        let y2 = 0.99_f64;
        let x = 182.0;
        let result = linear_zero_interp(x0, x1, &y1, x2, &y2, x);
        // r2 = -ln(0.99)/366
        // r = r2 (flat forward since t1=0)
        // expected = exp(-r2 * 182)
        let r2 = -0.99_f64.ln() / 366.0;
        let expected = (-r2 * 182.0).exp();
        assert!((result - expected).abs() < 1e-12);
    }
}
