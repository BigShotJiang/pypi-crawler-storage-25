use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::cubic_spline::CubicSplineCoeffs;

/// Log-cubic spline interpolator.
///
/// Applies log-transform to DF values before fitting the cubic spline,
/// then exp() on evaluation. This ensures interpolated discount factors
/// remain positive. Uses the shared CubicSplineCoeffs solver with
/// log_transform=true.
#[derive(Clone, Debug)]
pub struct LogCubicInterpolator {
    pub coeffs: CubicSplineCoeffs,
}

impl LogCubicInterpolator {
    /// Create a placeholder instance (used during deserialization before rebuild).
    pub fn placeholder() -> Self {
        Self { coeffs: CubicSplineCoeffs::empty() }
    }

    /// Build a log-cubic spline from the given nodes.
    pub fn build(nodes: &Nodes) -> Self {
        Self {
            coeffs: CubicSplineCoeffs::build(nodes, true), // log transform
        }
    }
}

impl CurveInterpolation for LogCubicInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let last_x = *self.coeffs.x.last().unwrap();

        // Flat forward extrapolation beyond last node: return last node value directly
        if x >= last_x {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        // Evaluate in log-space and convert back via exp()
        self.coeffs.eval(x).exp()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;
    use indexmap::IndexMap;
    use crate::autodiff::dual::{Dual, Vars};
    use crate::autodiff::enums::Number;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn make_f64_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.90),
            (ymd(2028, 1, 1), 0.85),
        ]))
    }

    #[test]
    fn test_log_cubic_reproduces_nodes() {
        // Test 6: Build with 5 DF nodes, interpolate at each node -- reproduces exact value
        let nodes = make_f64_nodes();
        let interp = LogCubicInterpolator::build(&nodes);
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
        ];
        let expected = vec![1.0, 0.97, 0.94, 0.90];

        for (date, exp) in dates.iter().zip(expected.iter()) {
            let val = interp.interpolated_value(&nodes, *date);
            match val {
                Number::F64(v) => assert!(
                    (v - exp).abs() < 1e-12,
                    "At {:?}: got {} expected {}",
                    date, v, exp
                ),
                _ => panic!("Expected F64"),
            }
        }
    }

    #[test]
    fn test_log_cubic_positive_dfs() {
        // Test 7: Interpolated DFs remain positive (log-space guarantees this)
        let nodes = make_f64_nodes();
        let interp = LogCubicInterpolator::build(&nodes);

        // Test at many intermediate dates
        for month in 1..=48 {
            let year = 2024 + (month - 1) / 12;
            let m = ((month - 1) % 12) + 1;
            if let Some(date) = NaiveDate::from_ymd_opt(year, m as u32, 15) {
                let x = date.num_days_from_ce() as f64;
                let last_x = *interp.coeffs.x.last().unwrap();
                if x < last_x {
                    let val = interp.interpolated_value(&nodes, date);
                    match val {
                        Number::F64(v) => assert!(
                            v > 0.0,
                            "DF at {:?} = {} should be positive",
                            date, v
                        ),
                        _ => panic!("Expected F64"),
                    }
                }
            }
        }
    }

    #[test]
    fn test_log_cubic_ad_vs_fd_jacobian() {
        // Test 8: Full Jacobian FD vs AD test (D-05/D-06)
        let base_values = vec![1.0, 0.97, 0.94, 0.90, 0.85];
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
            ymd(2028, 1, 1),
        ];
        let query_date = ymd(2026, 7, 1);
        let bump = 1e-6;

        for j in 1..base_values.len() {
            // AD path
            let vars: Vec<String> = (0..base_values.len())
                .map(|k| format!("v{}", k))
                .collect();
            let dual_nodes: Vec<Dual> = base_values
                .iter()
                .enumerate()
                .map(|(i, &v)| {
                    let mut derivs = vec![0.0; base_values.len()];
                    derivs[i] = 1.0;
                    Dual::try_new(v, vars.clone(), derivs).unwrap()
                })
                .collect();

            let nodes_dual = Nodes::from_dual_map(IndexMap::from_iter(
                dates.iter().cloned().zip(dual_nodes).collect::<Vec<_>>(),
            ));
            let interp = LogCubicInterpolator::build(&nodes_dual);
            let val = interp.interpolated_value(&nodes_dual, query_date);
            let ad_delta = match &val {
                Number::Dual(d) => d.dual[j],
                _ => panic!("Expected Dual"),
            };

            // FD path: bump up
            let mut vals_up = base_values.clone();
            vals_up[j] += bump;
            let nodes_up = Nodes::from_f64_map(IndexMap::from_iter(
                dates.iter().cloned().zip(vals_up).collect::<Vec<_>>(),
            ));
            let interp_up = LogCubicInterpolator::build(&nodes_up);
            let v_up = match interp_up.interpolated_value(&nodes_up, query_date) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };

            // FD path: bump down
            let mut vals_dn = base_values.clone();
            vals_dn[j] -= bump;
            let nodes_dn = Nodes::from_f64_map(IndexMap::from_iter(
                dates.iter().cloned().zip(vals_dn).collect::<Vec<_>>(),
            ));
            let interp_dn = LogCubicInterpolator::build(&nodes_dn);
            let v_dn = match interp_dn.interpolated_value(&nodes_dn, query_date) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };

            let fd_delta = (v_up - v_dn) / (2.0 * bump);
            let rel_err = (ad_delta - fd_delta).abs() / fd_delta.abs().max(1e-10);
            assert!(
                rel_err < 1e-6,
                "Node {}: AD={:.10} FD={:.10} rel_err={:.2e}",
                j, ad_delta, fd_delta, rel_err
            );
        }
    }
}
