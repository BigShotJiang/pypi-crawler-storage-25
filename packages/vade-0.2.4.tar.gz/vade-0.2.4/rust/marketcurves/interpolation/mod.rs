pub mod utils;
pub mod log_linear;
pub mod linear;
pub mod linear_zero_rate;
pub mod flat_forward;
pub mod flat_backward;
pub mod cubic_spline;
pub mod natural_cubic;
pub mod log_cubic;
pub mod hermite;
pub mod monotone_cubic;
pub mod convex_monotone;

use chrono::{Datelike, NaiveDate};
use serde::{Serialize, Deserialize, Serializer, Deserializer};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::spline::{PPSpline, SplineEndpoint, auto_knot_sequence};
use crate::marketcurves::interpolation::natural_cubic::NaturalCubicInterpolator;
use crate::marketcurves::interpolation::log_cubic::LogCubicInterpolator;
use crate::marketcurves::interpolation::hermite::HermiteInterpolator;
use crate::marketcurves::interpolation::monotone_cubic::MonotoneCubicInterpolator;
use crate::marketcurves::interpolation::convex_monotone::ConvexMonotoneInterpolator;

/// Trait for curve interpolation methods.
/// Each interpolator returns a Number at the given date by interpolating the nodes.
pub trait CurveInterpolation {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number;
}

/// Enum wrapping all interpolation methods for dynamic dispatch.
#[derive(Clone, Debug)]
pub enum Interpolator {
    LogLinear,
    Linear,
    LinearZeroRate,
    FlatForward,
    FlatBackward,
    /// Spline interpolation with optional local method for dates before first knot.
    Spline {
        pp: PPSpline,
        local_interp: Box<Interpolator>,
        log_transform: bool, // true for DiscountCurve (log-cubic), false for LineCurve
    },
    /// Natural cubic spline (C2-continuous, natural BCs).
    NaturalCubic(NaturalCubicInterpolator),
    /// Log-cubic spline (natural cubic in log-space, positive DFs guaranteed).
    LogCubic(LogCubicInterpolator),
    /// Hermite cubic with finite-difference tangents.
    Hermite(HermiteInterpolator),
    /// Monotone cubic (Fritsch-Carlson) preserving monotonicity.
    MonotoneCubic(MonotoneCubicInterpolator),
    /// Convex monotone (Hagan-West) with positive forward rates.
    ConvexMonotone(ConvexMonotoneInterpolator),
}

impl CurveInterpolation for Interpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        match self {
            Interpolator::LogLinear => {
                log_linear::LogLinearInterpolator.interpolated_value(nodes, date)
            }
            Interpolator::Linear => {
                linear::LinearInterpolator.interpolated_value(nodes, date)
            }
            Interpolator::LinearZeroRate => {
                linear_zero_rate::LinearZeroRateInterpolator.interpolated_value(nodes, date)
            }
            Interpolator::FlatForward => {
                flat_forward::FlatForwardInterpolator.interpolated_value(nodes, date)
            }
            Interpolator::FlatBackward => {
                flat_backward::FlatBackwardInterpolator.interpolated_value(nodes, date)
            }
            Interpolator::Spline { pp, local_interp, log_transform } => {
                let x = date.num_days_from_ce() as f64;
                // First effective knot is t[k-1] (accounting for k-fold multiplicity)
                let first_knot = pp.t[pp.k - 1];

                if x < first_knot {
                    // Delegate to local interpolation method
                    local_interp.interpolated_value(nodes, date)
                } else {
                    // Check for extrapolation beyond last node
                    let last_knot = pp.t[pp.t.len() - pp.k];
                    if x > last_knot {
                        // Flat forward extrapolation: return last node value
                        return nodes.get_value_at_index(nodes.len() - 1);
                    }
                    let val = pp.eval(x);
                    if *log_transform {
                        val.exp()
                    } else {
                        val
                    }
                }
            }
            Interpolator::NaturalCubic(inner) => inner.interpolated_value(nodes, date),
            Interpolator::LogCubic(inner) => inner.interpolated_value(nodes, date),
            Interpolator::Hermite(inner) => inner.interpolated_value(nodes, date),
            Interpolator::MonotoneCubic(inner) => inner.interpolated_value(nodes, date),
            Interpolator::ConvexMonotone(inner) => inner.interpolated_value(nodes, date),
        }
    }
}

impl Interpolator {
    /// Parse an interpolation method from a string.
    pub fn from_str(s: &str) -> Result<Self, String> {
        match s {
            "log_linear" => Ok(Interpolator::LogLinear),
            "linear" => Ok(Interpolator::Linear),
            "linear_zero_rate" => Ok(Interpolator::LinearZeroRate),
            "flat_forward" => Ok(Interpolator::FlatForward),
            "flat_backward" => Ok(Interpolator::FlatBackward),
            "spline" => Ok(Interpolator::LogLinear), // placeholder; needs build_spline
            "natural_cubic" => Ok(Interpolator::NaturalCubic(NaturalCubicInterpolator::placeholder())),
            "log_cubic" => Ok(Interpolator::LogCubic(LogCubicInterpolator::placeholder())),
            "hermite" => Ok(Interpolator::Hermite(HermiteInterpolator::placeholder())),
            "monotone_cubic" => Ok(Interpolator::MonotoneCubic(MonotoneCubicInterpolator::placeholder())),
            "convex_monotone" => Ok(Interpolator::ConvexMonotone(ConvexMonotoneInterpolator)),
            _ => Err(format!("Unknown interpolation method: '{}'. Expected one of: log_linear, linear, linear_zero_rate, flat_forward, flat_backward, spline, natural_cubic, log_cubic, hermite, monotone_cubic, convex_monotone", s)),
        }
    }

    /// Build a Spline interpolator from nodes.
    ///
    /// - nodes: the curve nodes
    /// - t_dates: optional knot dates. If None, auto-generate from all node dates.
    /// - endpoint: endpoint constraint (NotAKnot or Natural)
    /// - local_method: fallback interpolator for dates before first knot
    /// - log_transform: if true, spline is built on log(values) and exp() on eval (for DiscountCurve)
    pub fn build_spline(
        nodes: &Nodes,
        t_dates: Option<&[NaiveDate]>,
        endpoint: &SplineEndpoint,
        local_method: Interpolator,
        log_transform: bool,
    ) -> Self {
        let node_dates: Vec<NaiveDate> = match nodes {
            Nodes::F64(m) => m.keys().cloned().collect(),
            Nodes::Dual(m) => m.keys().cloned().collect(),
            Nodes::Dual2(m) => m.keys().cloned().collect(),
        };

        let k = 4; // cubic B-spline

        // Generate or use provided knot vector
        let t = match t_dates {
            Some(dates) => {
                // Use provided knot dates with k-fold endpoint multiplicity
                auto_knot_sequence(dates, k)
            }
            None => {
                // Auto-generate from all node dates
                auto_knot_sequence(&node_dates, k)
            }
        };

        let n_basis = t.len() - k;
        let node_x = nodes.keys_as_f64();

        // Get y-values: if log_transform, take log of values
        let node_y: Vec<Number> = (0..nodes.len()).map(|i| {
            let val = nodes.get_value_at_index(i);
            if log_transform {
                val.log()
            } else {
                val
            }
        }).collect();

        // For auto-knot mode (t_dates=None), n_basis should equal node count.
        // For explicit knots, n_basis may differ from node count.
        // The PPSpline::build will handle collocation.
        assert_eq!(n_basis, node_y.len(),
            "Number of basis functions ({}) must match number of nodes ({}). \
             Adjust knot vector to satisfy: t.len() - k == nodes.len()", n_basis, node_y.len());

        let pp = PPSpline::build(k, t, &node_x, &node_y, endpoint);

        Interpolator::Spline {
            pp,
            local_interp: Box::new(local_method),
            log_transform,
        }
    }
}

/// Helper struct for serializing Interpolator::Spline configuration.
#[allow(dead_code)]
#[derive(Serialize, Deserialize)]
struct SplineConfig {
    endpoint: SplineEndpoint,
    local_interp: String,
    log_transform: bool,
}

/// Helper enum for Interpolator serialization.
#[derive(Serialize, Deserialize)]
#[serde(untagged)]
enum InterpolatorRepr {
    Simple(String),
    Spline { r#type: String, endpoint: SplineEndpoint, local_interp: String, log_transform: bool },
}

impl Serialize for Interpolator {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        match self {
            Interpolator::LogLinear => InterpolatorRepr::Simple("log_linear".to_string()).serialize(serializer),
            Interpolator::Linear => InterpolatorRepr::Simple("linear".to_string()).serialize(serializer),
            Interpolator::LinearZeroRate => InterpolatorRepr::Simple("linear_zero_rate".to_string()).serialize(serializer),
            Interpolator::FlatForward => InterpolatorRepr::Simple("flat_forward".to_string()).serialize(serializer),
            Interpolator::FlatBackward => InterpolatorRepr::Simple("flat_backward".to_string()).serialize(serializer),
            Interpolator::NaturalCubic(_) => InterpolatorRepr::Simple("natural_cubic".to_string()).serialize(serializer),
            Interpolator::LogCubic(_) => InterpolatorRepr::Simple("log_cubic".to_string()).serialize(serializer),
            Interpolator::Hermite(_) => InterpolatorRepr::Simple("hermite".to_string()).serialize(serializer),
            Interpolator::MonotoneCubic(_) => InterpolatorRepr::Simple("monotone_cubic".to_string()).serialize(serializer),
            Interpolator::ConvexMonotone(_) => InterpolatorRepr::Simple("convex_monotone".to_string()).serialize(serializer),
            Interpolator::Spline { pp, local_interp, log_transform } => {
                let local_name = match local_interp.as_ref() {
                    Interpolator::LogLinear => "log_linear",
                    Interpolator::Linear => "linear",
                    Interpolator::LinearZeroRate => "linear_zero_rate",
                    Interpolator::FlatForward => "flat_forward",
                    Interpolator::FlatBackward => "flat_backward",
                    _ => "log_linear", // fallback for nested spline/new variants
                };
                InterpolatorRepr::Spline {
                    r#type: "spline".to_string(),
                    endpoint: pp.endpoint.clone(),
                    local_interp: local_name.to_string(),
                    log_transform: *log_transform,
                }.serialize(serializer)
            }
        }
    }
}

impl<'de> Deserialize<'de> for Interpolator {
    fn deserialize<D: Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        let repr = InterpolatorRepr::deserialize(deserializer)?;
        match repr {
            InterpolatorRepr::Simple(s) => match s.as_str() {
                "log_linear" => Ok(Interpolator::LogLinear),
                "linear" => Ok(Interpolator::Linear),
                "linear_zero_rate" => Ok(Interpolator::LinearZeroRate),
                "flat_forward" => Ok(Interpolator::FlatForward),
                "flat_backward" => Ok(Interpolator::FlatBackward),
                "natural_cubic" => Ok(Interpolator::NaturalCubic(NaturalCubicInterpolator::placeholder())),
                "log_cubic" => Ok(Interpolator::LogCubic(LogCubicInterpolator::placeholder())),
                "hermite" => Ok(Interpolator::Hermite(HermiteInterpolator::placeholder())),
                "monotone_cubic" => Ok(Interpolator::MonotoneCubic(MonotoneCubicInterpolator::placeholder())),
                "convex_monotone" => Ok(Interpolator::ConvexMonotone(ConvexMonotoneInterpolator)),
                _ => Err(serde::de::Error::custom(format!("Unknown interpolator: {}", s))),
            },
            InterpolatorRepr::Spline { endpoint, local_interp, log_transform, .. } => {
                let local = match local_interp.as_str() {
                    "log_linear" => Interpolator::LogLinear,
                    "linear" => Interpolator::Linear,
                    "linear_zero_rate" => Interpolator::LinearZeroRate,
                    "flat_forward" => Interpolator::FlatForward,
                    "flat_backward" => Interpolator::FlatBackward,
                    _ => Interpolator::LogLinear,
                };
                // Create a placeholder PPSpline; rebuild_spline must be called after deserialization
                let placeholder_pp = PPSpline {
                    k: 4,
                    t: vec![],
                    c: vec![],
                    n: 0,
                    endpoint,
                };
                Ok(Interpolator::Spline {
                    pp: placeholder_pp,
                    local_interp: Box::new(local),
                    log_transform,
                })
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use chrono::NaiveDate;
    use crate::autodiff::dual::{Dual, Vars};
    use crate::marketcurves::spline::SplineEndpoint;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn f64_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2000, 1, 1), 1.0),
            (ymd(2001, 1, 1), 0.99),
            (ymd(2002, 1, 1), 0.98),
        ]))
    }

    #[test]
    fn test_interpolator_from_str() {
        assert!(matches!(Interpolator::from_str("log_linear"), Ok(Interpolator::LogLinear)));
        assert!(matches!(Interpolator::from_str("linear"), Ok(Interpolator::Linear)));
        assert!(matches!(Interpolator::from_str("linear_zero_rate"), Ok(Interpolator::LinearZeroRate)));
        assert!(matches!(Interpolator::from_str("flat_forward"), Ok(Interpolator::FlatForward)));
        assert!(matches!(Interpolator::from_str("flat_backward"), Ok(Interpolator::FlatBackward)));
        assert!(matches!(Interpolator::from_str("natural_cubic"), Ok(Interpolator::NaturalCubic(_))));
        assert!(matches!(Interpolator::from_str("log_cubic"), Ok(Interpolator::LogCubic(_))));
        assert!(matches!(Interpolator::from_str("hermite"), Ok(Interpolator::Hermite(_))));
        assert!(matches!(Interpolator::from_str("monotone_cubic"), Ok(Interpolator::MonotoneCubic(_))));
        assert!(matches!(Interpolator::from_str("convex_monotone"), Ok(Interpolator::ConvexMonotone(_))));
        assert!(Interpolator::from_str("invalid").is_err());
    }

    #[test]
    fn test_interpolator_enum_dispatches() {
        let nodes = f64_nodes();
        // Test that each variant dispatches correctly
        let ll = Interpolator::LogLinear;
        let result = ll.interpolated_value(&nodes, ymd(2000, 7, 1));
        if let Number::F64(v) = result {
            assert!(v > 0.99 && v < 1.0);
        } else {
            panic!("Expected F64");
        }

        let lin = Interpolator::Linear;
        let result = lin.interpolated_value(&nodes, ymd(2000, 7, 1));
        if let Number::F64(v) = result {
            assert!(v > 0.99 && v < 1.0);
        } else {
            panic!("Expected F64");
        }

        let ff = Interpolator::FlatForward;
        let result = ff.interpolated_value(&nodes, ymd(2000, 7, 1));
        assert_eq!(result, Number::F64(1.0));

        let fb = Interpolator::FlatBackward;
        let result = fb.interpolated_value(&nodes, ymd(2000, 7, 1));
        assert_eq!(result, Number::F64(0.99));
    }

    // ========= Spline interpolation tests =========

    fn discount_nodes_5y() -> Nodes {
        // 5 nodes spanning 5 years, typical discount factors
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.90),
            (ymd(2028, 1, 1), 0.85),
        ]))
    }

    #[test]
    fn test_spline_log_cubic_reproduces_nodes() {
        // Build a log-cubic spline and verify it reproduces node values exactly
        let nodes = discount_nodes_5y();
        let interp = Interpolator::build_spline(
            &nodes,
            None,
            &SplineEndpoint::NotAKnot,
            Interpolator::LogLinear,
            true, // log_transform for DiscountCurve
        );

        // At each node date, the interpolated value should equal the node value
        let dates = vec![ymd(2025, 1, 1), ymd(2026, 1, 1), ymd(2027, 1, 1)];
        let expected = vec![0.97, 0.94, 0.90];
        for (date, exp) in dates.iter().zip(expected.iter()) {
            let val = interp.interpolated_value(&nodes, *date);
            if let Number::F64(v) = val {
                assert!((v - exp).abs() < 1e-10,
                    "At {:?}: got {} expected {}", date, v, exp);
            } else {
                panic!("Expected F64");
            }
        }
    }

    #[test]
    fn test_spline_smooth_interpolation() {
        // Interpolated values at mid-points should be between adjacent node values
        let nodes = discount_nodes_5y();
        let interp = Interpolator::build_spline(
            &nodes,
            None,
            &SplineEndpoint::NotAKnot,
            Interpolator::LogLinear,
            true,
        );

        let mid_date = ymd(2025, 7, 1); // between 2025 and 2026 nodes
        let val = interp.interpolated_value(&nodes, mid_date);
        if let Number::F64(v) = val {
            assert!(v > 0.93 && v < 0.97,
                "Mid-point value {} should be between adjacent node values", v);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_spline_extrapolation_flat_forward() {
        // Beyond last node, should return last node value (flat forward)
        let nodes = discount_nodes_5y();
        let interp = Interpolator::build_spline(
            &nodes,
            None,
            &SplineEndpoint::NotAKnot,
            Interpolator::LogLinear,
            true,
        );

        let far_date = ymd(2030, 1, 1);
        let val = interp.interpolated_value(&nodes, far_date);
        if let Number::F64(v) = val {
            assert!((v - 0.85).abs() < 1e-10, "Extrapolation should return last node value");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_spline_no_log_transform() {
        // LineCurve mode: no log transform
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.035),
            (ymd(2026, 1, 1), 0.04),
            (ymd(2027, 1, 1), 0.038),
            (ymd(2028, 1, 1), 0.036),
        ]));
        let interp = Interpolator::build_spline(
            &nodes,
            None,
            &SplineEndpoint::NotAKnot,
            Interpolator::Linear,
            false, // no log_transform for LineCurve
        );

        // Should reproduce node values at interior points
        let val = interp.interpolated_value(&nodes, ymd(2025, 1, 1));
        if let Number::F64(v) = val {
            assert!((v - 0.035).abs() < 1e-10, "Should reproduce node value, got {}", v);
        }
    }

    #[test]
    fn test_spline_ad_propagation_through_interpolation() {
        // Dual nodes through spline interpolation should produce Dual output
        let d1 = Dual::try_new(1.0, vec!["v0".to_string()], vec![0.0]).unwrap();
        let d2 = Dual::new("v0", 0.97);
        let d3 = Dual::try_new(0.94, vec!["v0".to_string()], vec![0.0]).unwrap();
        let d4 = Dual::try_new(0.90, vec!["v0".to_string()], vec![0.0]).unwrap();
        let d5 = Dual::try_new(0.85, vec!["v0".to_string()], vec![0.0]).unwrap();

        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
            (ymd(2026, 1, 1), d3),
            (ymd(2027, 1, 1), d4),
            (ymd(2028, 1, 1), d5),
        ]));

        let interp = Interpolator::build_spline(
            &nodes,
            None,
            &SplineEndpoint::NotAKnot,
            Interpolator::LogLinear,
            true,
        );

        let val = interp.interpolated_value(&nodes, ymd(2025, 7, 1));
        if let Number::Dual(d) = val {
            assert!(d.real() > 0.93 && d.real() < 0.97,
                "Dual spline real value at mid-point: {}", d.real());
            // Should have AD variables
            assert!(d.vars().len() > 0, "Should propagate AD variables");
        } else {
            panic!("Expected Dual result from Dual-node spline");
        }
    }

    #[test]
    fn test_spline_from_str_placeholder() {
        // "spline" from_str returns a placeholder (LogLinear) since build_spline is needed
        let result = Interpolator::from_str("spline");
        assert!(result.is_ok());
    }

    #[test]
    fn test_serde_interpolator_simple_roundtrip() {
        // Test stateless interpolators with full functional equivalence
        for (interp, name) in &[
            (Interpolator::LogLinear, "log_linear"),
            (Interpolator::Linear, "linear"),
            (Interpolator::FlatForward, "flat_forward"),
        ] {
            let json = serde_json::to_string(interp).unwrap();
            assert!(json.contains(name), "JSON should contain '{}', got: {}", name, json);
            let restored: Interpolator = serde_json::from_str(&json).unwrap();
            // Verify functional equivalence
            let nodes = f64_nodes();
            let val_orig = interp.interpolated_value(&nodes, ymd(2000, 7, 1));
            let val_restored = restored.interpolated_value(&nodes, ymd(2000, 7, 1));
            assert_eq!(val_orig, val_restored, "Roundtrip mismatch for {}", name);
        }
    }

    #[test]
    fn test_serde_new_interpolators_name_roundtrip() {
        // For stateful interpolators, verify serde name roundtrip (placeholders deserialize correctly)
        use crate::marketcurves::interpolation::natural_cubic::NaturalCubicInterpolator;
        use crate::marketcurves::interpolation::log_cubic::LogCubicInterpolator;
        use crate::marketcurves::interpolation::hermite::HermiteInterpolator;
        use crate::marketcurves::interpolation::monotone_cubic::MonotoneCubicInterpolator;
        use crate::marketcurves::interpolation::convex_monotone::ConvexMonotoneInterpolator;

        let variants: Vec<(Interpolator, &str)> = vec![
            (Interpolator::NaturalCubic(NaturalCubicInterpolator::placeholder()), "natural_cubic"),
            (Interpolator::LogCubic(LogCubicInterpolator::placeholder()), "log_cubic"),
            (Interpolator::Hermite(HermiteInterpolator::placeholder()), "hermite"),
            (Interpolator::MonotoneCubic(MonotoneCubicInterpolator::placeholder()), "monotone_cubic"),
            (Interpolator::ConvexMonotone(ConvexMonotoneInterpolator), "convex_monotone"),
        ];

        for (interp, name) in &variants {
            let json = serde_json::to_string(interp).unwrap();
            assert!(json.contains(name), "JSON should contain '{}', got: {}", name, json);
            let restored: Interpolator = serde_json::from_str(&json).unwrap();
            // Verify the variant type is preserved
            let restored_json = serde_json::to_string(&restored).unwrap();
            assert_eq!(json, restored_json, "Serde roundtrip mismatch for {}", name);
        }
    }

    #[test]
    fn test_serde_interpolator_spline_config() {
        let nodes = discount_nodes_5y();
        let interp = Interpolator::build_spline(
            &nodes,
            None,
            &SplineEndpoint::NotAKnot,
            Interpolator::LogLinear,
            true,
        );
        let json = serde_json::to_string(&interp).unwrap();
        // Should contain "spline" type and endpoint config, not the full PPSpline data
        assert!(json.contains("spline"), "JSON should contain 'spline': {}", json);
        assert!(json.contains("NotAKnot"), "JSON should contain endpoint: {}", json);
    }

    #[test]
    fn test_new_interpolators_dispatch() {
        use crate::marketcurves::interpolation::natural_cubic::NaturalCubicInterpolator;
        use crate::marketcurves::interpolation::log_cubic::LogCubicInterpolator;
        use crate::marketcurves::interpolation::hermite::HermiteInterpolator;
        use crate::marketcurves::interpolation::monotone_cubic::MonotoneCubicInterpolator;
        use crate::marketcurves::interpolation::convex_monotone::ConvexMonotoneInterpolator;

        let nodes = discount_nodes_5y();
        let mid_date = ymd(2025, 7, 1);

        // Build each new interpolator, wrap in enum, call interpolated_value
        let interps: Vec<(Interpolator, &str)> = vec![
            (Interpolator::NaturalCubic(NaturalCubicInterpolator::build(&nodes)), "natural_cubic"),
            (Interpolator::LogCubic(LogCubicInterpolator::build(&nodes)), "log_cubic"),
            (Interpolator::Hermite(HermiteInterpolator::build(&nodes)), "hermite"),
            (Interpolator::MonotoneCubic(MonotoneCubicInterpolator::build(&nodes)), "monotone_cubic"),
            (Interpolator::ConvexMonotone(ConvexMonotoneInterpolator), "convex_monotone"),
        ];

        for (interp, name) in &interps {
            let val = interp.interpolated_value(&nodes, mid_date);
            if let Number::F64(v) = val {
                assert!(v > 0.0 && v < 2.0,
                    "Interpolator {} returned unreasonable value: {}", name, v);
                assert!(v > 0.90 && v < 1.0,
                    "Interpolator {} mid-point value {} should be between 0.90 and 1.0", name, v);
            } else {
                panic!("Expected F64 from {}", name);
            }
        }
    }

    #[test]
    fn test_existing_interpolators_still_work() {
        // Regression: all existing interpolators should still work
        let nodes = f64_nodes();
        for interp in &[
            Interpolator::LogLinear,
            Interpolator::Linear,
            Interpolator::LinearZeroRate,
            Interpolator::FlatForward,
            Interpolator::FlatBackward,
        ] {
            let val = interp.interpolated_value(&nodes, ymd(2000, 7, 1));
            if let Number::F64(v) = val {
                assert!(v.is_finite(), "Interpolator {:?} returned non-finite value", interp);
            }
        }
    }
}
