use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::utils::index_left;
use crate::marketcurves::interpolation::hermite::hermite_eval;

/// Extract the real (f64) value from a Number.
fn number_real(n: &Number) -> f64 {
    match n {
        Number::F64(f) => *f,
        Number::Dual(d) => d.real(),
        Number::Dual2(d) => d.real(),
    }
}

/// Create a zero Number matching the type of the given Number.
fn zero_like(n: &Number) -> Number {
    match n {
        Number::F64(_) => Number::F64(0.0),
        Number::Dual(d) => {
            let z = crate::autodiff::dual::Dual::new_from(d, 0.0);
            Number::Dual(z)
        }
        Number::Dual2(d) => {
            let z = crate::autodiff::dual::Dual2::new_from(d, 0.0);
            Number::Dual2(z)
        }
    }
}

/// Compute monotone tangents using Fritsch-Carlson algorithm with circle constraint.
///
/// Steps:
/// 1. Compute secant slopes delta[k] = (y[k+1] - y[k]) / (x[k+1] - x[k])
/// 2. Initialize tangents: endpoints get one-sided secant, interior gets average of adjacent secants
/// 3. Flat section check: if delta[k].real() ~ 0, set adjacent tangents to zero
/// 4. Circle constraint: if alpha^2 + beta^2 > 9, rescale with tau = 3/sqrt(alpha^2+beta^2)
fn compute_monotone_tangents(xs: &[f64], ys: &[Number]) -> Vec<Number> {
    let n = ys.len();
    assert!(n >= 2, "Need at least 2 nodes for monotone cubic");

    // Step 1: Compute secant slopes
    let mut delta: Vec<Number> = Vec::with_capacity(n - 1);
    for k in 0..n - 1 {
        let h = xs[k + 1] - xs[k];
        delta.push(&(&ys[k + 1] - &ys[k]) * (1.0 / h));
    }

    // Step 2: Initialize tangents
    let mut m: Vec<Number> = Vec::with_capacity(n);
    // First endpoint: one-sided
    m.push(delta[0].clone());
    // Interior: average of adjacent secants
    for k in 1..n - 1 {
        m.push(&(&delta[k - 1] + &delta[k]) * 0.5);
    }
    // Last endpoint: one-sided
    m.push(delta[n - 2].clone());

    // Step 3: Flat section check
    for k in 0..n - 1 {
        let dk_real = number_real(&delta[k]);
        if dk_real.abs() < 1e-30 {
            m[k] = zero_like(&ys[k]);
            m[k + 1] = zero_like(&ys[k + 1]);
        }
    }

    // Step 4: Circle constraint (Fritsch-Carlson)
    // For each interval where delta[k] is not flat
    for k in 0..n - 1 {
        let dk_real = number_real(&delta[k]);
        if dk_real.abs() < 1e-30 {
            continue;
        }

        let mk_real = number_real(&m[k]);
        let mk1_real = number_real(&m[k + 1]);
        let alpha_real = mk_real / dk_real;
        let beta_real = mk1_real / dk_real;

        let circle = alpha_real * alpha_real + beta_real * beta_real;
        if circle > 9.0 {
            // Rescale: tau = 3 / sqrt(alpha^2 + beta^2)
            let tau = 3.0 / circle.sqrt();
            // m[k] = delta[k] * (tau * alpha_real)
            // m[k+1] = delta[k] * (tau * beta_real)
            m[k] = &delta[k] * (tau * alpha_real);
            m[k + 1] = &delta[k] * (tau * beta_real);
        }
    }

    m
}

/// Monotone cubic interpolator using Fritsch-Carlson algorithm.
///
/// Preserves monotonicity of the data (no spurious oscillations).
/// Uses the circle constraint (alpha^2 + beta^2 <= 9) with smooth
/// rescaling for AD safety rather than hard clamping.
#[derive(Clone, Debug)]
pub struct MonotoneCubicInterpolator {
    pub xs: Vec<f64>,
    pub ys: Vec<Number>,
    pub tangents: Vec<Number>,
}

impl MonotoneCubicInterpolator {
    /// Create a placeholder instance (used during deserialization before rebuild).
    pub fn placeholder() -> Self {
        Self { xs: vec![], ys: vec![], tangents: vec![] }
    }

    /// Build from curve nodes, extracting xs/ys and computing monotone tangents.
    pub fn build(nodes: &Nodes) -> Self {
        let xs = nodes.keys_as_f64();
        let ys: Vec<Number> = (0..nodes.len()).map(|i| nodes.get_value_at_index(i)).collect();
        let tangents = compute_monotone_tangents(&xs, &ys);
        MonotoneCubicInterpolator { xs, ys, tangents }
    }
}

impl CurveInterpolation for MonotoneCubicInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        // Rebuild from nodes to capture AD state
        let xs = nodes.keys_as_f64();
        let ys: Vec<Number> = (0..nodes.len()).map(|i| nodes.get_value_at_index(i)).collect();
        let tangents = compute_monotone_tangents(&xs, &ys);

        let x = date.num_days_from_ce() as f64;

        // Flat forward extrapolation beyond last node
        if x >= *xs.last().unwrap() {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        let i = index_left(x, &xs);
        hermite_eval(x, xs[i], &ys[i], &tangents[i], xs[i + 1], &ys[i + 1], &tangents[i + 1])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use chrono::NaiveDate;
    use crate::autodiff::dual::{Dual, Vars};
    use crate::autodiff::enums::Number;
    use crate::marketcurves::nodes::Nodes;
    use std::sync::Arc;
    use indexmap::IndexSet;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn five_node_monotone_decreasing() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
            (ymd(2026, 1, 1), 0.95),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.86),
        ]))
    }

    // Test 1: Reproduces node values exactly
    #[test]
    fn test_monotone_cubic_reproduces_nodes() {
        let nodes = five_node_monotone_decreasing();
        let interp = MonotoneCubicInterpolator::build(&nodes);
        let dates = vec![
            ymd(2024, 1, 1), ymd(2025, 1, 1), ymd(2026, 1, 1),
            ymd(2027, 1, 1), ymd(2028, 1, 1),
        ];
        let expected = vec![1.0, 0.98, 0.95, 0.91, 0.86];
        for (date, exp) in dates.iter().zip(expected.iter()) {
            let val = interp.interpolated_value(&nodes, *date);
            if let Number::F64(v) = val {
                assert!(
                    (v - exp).abs() < 1e-12,
                    "At {:?}: got {}, expected {}", date, v, exp
                );
            } else {
                panic!("Expected F64");
            }
        }
    }

    // Test 2: Monotonicity preservation -- 20 equally-spaced points, all decreasing
    #[test]
    fn test_monotone_cubic_monotonicity() {
        let nodes = five_node_monotone_decreasing();
        let interp = MonotoneCubicInterpolator::build(&nodes);

        // 20 equally-spaced dates between first and last node
        let start = ymd(2024, 1, 1).num_days_from_ce();
        let end = ymd(2028, 1, 1).num_days_from_ce();
        let step = (end - start) as f64 / 20.0;

        let mut prev_val = f64::MAX;
        for i in 0..=20 {
            let day = start + (step * i as f64) as i32;
            let date = NaiveDate::from_num_days_from_ce_opt(day).unwrap();
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(v) = val {
                assert!(
                    v <= prev_val + 1e-12,
                    "Monotonicity violated at step {}: prev={}, curr={}", i, prev_val, v
                );
                prev_val = v;
            }
        }
    }

    // Test 3: Non-monotone input (hump shape) -- no overshoot beyond input range
    #[test]
    fn test_monotone_cubic_no_overshoot() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.04),
            (ymd(2026, 1, 1), 0.05),
            (ymd(2027, 1, 1), 0.04),
            (ymd(2028, 1, 1), 0.035),
        ]));
        let interp = MonotoneCubicInterpolator::build(&nodes);

        let min_val = 0.03_f64;
        let max_val = 0.05_f64;

        let start = ymd(2024, 1, 1).num_days_from_ce();
        let end = ymd(2028, 1, 1).num_days_from_ce();
        let step = (end - start) as f64 / 40.0;

        for i in 0..=40 {
            let day = start + (step * i as f64) as i32;
            let date = NaiveDate::from_num_days_from_ce_opt(day).unwrap();
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(v) = val {
                assert!(
                    v >= min_val - 1e-6 && v <= max_val + 1e-6,
                    "Overshoot at step {}: value {} outside [{}, {}]", i, v, min_val, max_val
                );
            }
        }
    }

    // Test 4: Flat section handling -- tangents set to zero for equal adjacent nodes
    #[test]
    fn test_monotone_cubic_flat_section() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.95),
            (ymd(2026, 1, 1), 0.95),  // flat section
            (ymd(2027, 1, 1), 0.95),  // flat section
            (ymd(2028, 1, 1), 0.90),
        ]));
        let xs = nodes.keys_as_f64();
        let ys: Vec<Number> = (0..nodes.len()).map(|i| nodes.get_value_at_index(i)).collect();
        let tangents = compute_monotone_tangents(&xs, &ys);

        // Tangents at the flat section boundaries should be zero
        // Nodes 1,2,3 are involved in the flat sections (delta[1]=0, delta[2]=0)
        // delta[1] = (ys[2]-ys[1])/(xs[2]-xs[1]) = 0 => m[1]=0, m[2]=0
        // delta[2] = (ys[3]-ys[2])/(xs[3]-xs[2]) = 0 => m[2]=0, m[3]=0
        assert!(number_real(&tangents[1]).abs() < 1e-12, "Tangent at flat boundary should be zero");
        assert!(number_real(&tangents[2]).abs() < 1e-12, "Tangent in flat section should be zero");
        assert!(number_real(&tangents[3]).abs() < 1e-12, "Tangent at flat boundary should be zero");

        // Interpolated values in flat section should all be 0.95
        let interp = MonotoneCubicInterpolator::build(&nodes);
        let val = interp.interpolated_value(&nodes, ymd(2025, 7, 1));
        if let Number::F64(v) = val {
            assert!((v - 0.95).abs() < 1e-10, "Flat section interpolation should be 0.95, got {}", v);
        }
        let val = interp.interpolated_value(&nodes, ymd(2026, 7, 1));
        if let Number::F64(v) = val {
            assert!((v - 0.95).abs() < 1e-10, "Flat section interpolation should be 0.95, got {}", v);
        }
    }

    // Test 5: Full Jacobian FD vs AD test
    #[test]
    fn test_monotone_cubic_ad_vs_fd() {
        let values = vec![1.0, 0.98, 0.95, 0.91, 0.86];
        let dates = vec![
            ymd(2024, 1, 1), ymd(2025, 1, 1), ymd(2026, 1, 1),
            ymd(2027, 1, 1), ymd(2028, 1, 1),
        ];
        let query_date = ymd(2025, 7, 1);
        let bump = 1e-6;
        let n = values.len();

        // AD: build Dual nodes and evaluate
        let var_names = Arc::new(IndexSet::from_iter(
            (0..n).map(|i| format!("v{}", i)).collect::<Vec<_>>()
        ));
        let mut dual_map = IndexMap::new();
        for (i, (&date, &val)) in dates.iter().zip(values.iter()).enumerate() {
            let mut dual_vec = ndarray::Array1::zeros(n);
            dual_vec[i] = 1.0;
            let dual = Dual {
                real: val,
                vars: Arc::clone(&var_names),
                dual: dual_vec,
            };
            dual_map.insert(date, dual);
        }
        let dual_nodes = Nodes::from_dual_map(dual_map);
        let interp = MonotoneCubicInterpolator::build(&dual_nodes);
        let ad_result = interp.interpolated_value(&dual_nodes, query_date);
        let (ad_real, ad_derivs): (f64, Vec<f64>) = if let Number::Dual(d) = &ad_result {
            (d.real(), d.dual.to_vec())
        } else {
            panic!("Expected Dual");
        };

        // FD: bump each node
        let base_nodes = Nodes::from_f64_map(IndexMap::from_iter(
            dates.iter().zip(values.iter()).map(|(&d, &v)| (d, v))
        ));
        let base_interp = MonotoneCubicInterpolator::build(&base_nodes);
        let base_val = if let Number::F64(v) = base_interp.interpolated_value(&base_nodes, query_date) {
            v
        } else {
            panic!("Expected F64");
        };

        for i in 0..n {
            let mut bumped_values = values.clone();
            bumped_values[i] += bump;
            let bumped_nodes = Nodes::from_f64_map(IndexMap::from_iter(
                dates.iter().zip(bumped_values.iter()).map(|(&d, &v)| (d, v))
            ));
            let bumped_interp = MonotoneCubicInterpolator::build(&bumped_nodes);
            let bumped_val = if let Number::F64(v) = bumped_interp.interpolated_value(&bumped_nodes, query_date) {
                v
            } else {
                panic!("Expected F64");
            };
            let fd_deriv = (bumped_val - base_val) / bump;
            let ad_deriv = ad_derivs[i];
            let denom = if ad_deriv.abs() > 1e-10 { ad_deriv.abs() } else { 1.0 };
            let rel_err = (ad_deriv - fd_deriv).abs() / denom;
            assert!(
                rel_err < 1e-6,
                "Node {}: AD={:.10}, FD={:.10}, rel_err={:.2e}",
                i, ad_deriv, fd_deriv, rel_err
            );
        }

        // Also verify AD real value is monotone-consistent
        assert!(ad_real > 0.93 && ad_real < 0.98, "AD real value: {}", ad_real);
    }

    // Test 6: Circle constraint triggers -- extreme slopes where alpha^2+beta^2 > 9
    #[test]
    fn test_monotone_cubic_circle_constraint() {
        // Create data where tangent/secant ratio would violate circle constraint
        // Steep then flat: large tangent relative to small secant
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.5),    // steep drop
            (ymd(2026, 1, 1), 0.49),   // nearly flat
            (ymd(2027, 1, 1), 0.48),   // nearly flat
            (ymd(2028, 1, 1), 0.01),   // steep drop again
        ]));
        let interp = MonotoneCubicInterpolator::build(&nodes);

        // Verify output is still monotone despite extreme slopes
        let start = ymd(2024, 1, 1).num_days_from_ce();
        let end = ymd(2028, 1, 1).num_days_from_ce();
        let step = (end - start) as f64 / 40.0;

        let mut prev_val = f64::MAX;
        for i in 0..=40 {
            let day = start + (step * i as f64) as i32;
            let date = NaiveDate::from_num_days_from_ce_opt(day).unwrap();
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(v) = val {
                assert!(
                    v <= prev_val + 1e-10,
                    "Monotonicity violated at step {}: prev={:.6}, curr={:.6}", i, prev_val, v
                );
                prev_val = v;
            }
        }
    }
}
