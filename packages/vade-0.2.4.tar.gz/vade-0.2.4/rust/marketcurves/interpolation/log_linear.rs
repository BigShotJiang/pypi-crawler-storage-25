use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::utils::{index_left, log_linear_interp};

/// Log-linear interpolation: exp(lerp(log(y1), log(y2))).
#[derive(Clone, Debug)]
pub struct LogLinearInterpolator;

impl CurveInterpolation for LogLinearInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let xs = nodes.keys_as_f64();
        let index = index_left(x, &xs);

        // Extrapolation beyond last node: flat forward (return last value)
        if x >= *xs.last().unwrap() {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        macro_rules! interp {
            ($Variant:ident, $map:expr) => {{
                let (_, y1) = $map.get_index(index).unwrap();
                let (_, y2) = $map.get_index(index + 1).unwrap();
                Number::$Variant(log_linear_interp(xs[index], y1, xs[index + 1], y2, x))
            }};
        }
        match nodes {
            Nodes::F64(m) => interp!(F64, m),
            Nodes::Dual(m) => interp!(Dual, m),
            Nodes::Dual2(m) => interp!(Dual2, m),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::autodiff::dual::Dual;
    use crate::autodiff::ops::math_funcs::MathFuncs;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn f64_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2000, 1, 1), 1.0),
            (ymd(2001, 1, 1), 0.99),
            (ymd(2002, 1, 1), 0.98),
        ]))
    }

    #[test]
    fn test_log_linear_mid_interval() {
        let nodes = f64_nodes();
        let interp = LogLinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2000, 7, 1));
        // exp(lerp(ln(1.0), ln(0.99)))
        let x1 = ymd(2000, 1, 1).num_days_from_ce() as f64;
        let x2 = ymd(2001, 1, 1).num_days_from_ce() as f64;
        let x = ymd(2000, 7, 1).num_days_from_ce() as f64;
        let frac = (x - x1) / (x2 - x1);
        let expected = (frac * 0.99_f64.ln()).exp();
        if let Number::F64(v) = result {
            assert!((v - expected).abs() < 1e-12, "got {v}, expected {expected}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_log_linear_at_node() {
        let nodes = f64_nodes();
        let interp = LogLinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2001, 1, 1));
        assert_eq!(result, Number::F64(0.99));
    }

    #[test]
    fn test_log_linear_extrapolation() {
        let nodes = f64_nodes();
        let interp = LogLinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2005, 1, 1));
        assert_eq!(result, Number::F64(0.98)); // flat forward
    }

    #[test]
    fn test_log_linear_ad_propagation() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.98);
        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]));
        let interp = LogLinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2024, 7, 1));
        if let Number::Dual(d) = result {
            assert!(d.real() > 0.98 && d.real() < 1.0);
        } else {
            panic!("Expected Dual");
        }
    }
}
