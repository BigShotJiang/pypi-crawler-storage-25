use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::utils::{index_left, linear_zero_interp};

/// Linear zero rate interpolation.
/// Converts DFs to zero rates, linearly interpolates rates, converts back.
#[derive(Clone, Debug)]
pub struct LinearZeroRateInterpolator;

impl CurveInterpolation for LinearZeroRateInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let xs = nodes.keys_as_f64();
        let index = index_left(x, &xs);

        // Extrapolation beyond last node: flat forward (return last value)
        if x >= *xs.last().unwrap() {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        let x0 = xs[0]; // first node date for zero rate base

        macro_rules! interp {
            ($Variant:ident, $map:expr) => {{
                let (_, y1) = $map.get_index(index).unwrap();
                let (_, y2) = $map.get_index(index + 1).unwrap();
                Number::$Variant(linear_zero_interp(x0, xs[index], y1, xs[index + 1], y2, x))
            }};
        }
        match nodes {
            Nodes::F64(m) => interp!(F64, m),
            Nodes::Dual(m) => interp!(Dual, m),
            Nodes::Dual2(m) => interp!(Dual2, m),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::autodiff::dual::Dual;
    use crate::autodiff::ops::math_funcs::MathFuncs;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn f64_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2000, 1, 1), 1.0),
            (ymd(2001, 1, 1), 0.99),
            (ymd(2002, 1, 1), 0.98),
        ]))
    }

    #[test]
    fn test_linear_zero_rate_second_interval() {
        let nodes = f64_nodes();
        let interp = LinearZeroRateInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2001, 7, 1));
        // x0, x1, x2 in days from CE
        let x0 = ymd(2000, 1, 1).num_days_from_ce() as f64;
        let x1 = ymd(2001, 1, 1).num_days_from_ce() as f64;
        let x2 = ymd(2002, 1, 1).num_days_from_ce() as f64;
        let x = ymd(2001, 7, 1).num_days_from_ce() as f64;
        let t1 = x1 - x0;
        let t2 = x2 - x0;
        let t = x - x0;
        let r1 = -0.99_f64.ln() / t1;
        let r2 = -0.98_f64.ln() / t2;
        let r = r1 + ((t - t1) / (t2 - t1)) * (r2 - r1);
        let expected = (-r * t).exp();
        if let Number::F64(v) = result {
            assert!((v - expected).abs() < 1e-12, "got {v}, expected {expected}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_linear_zero_rate_first_interval() {
        let nodes = f64_nodes();
        let interp = LinearZeroRateInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2000, 7, 1));
        // First interval: t1=0, so flat forward r = r2
        let x0 = ymd(2000, 1, 1).num_days_from_ce() as f64;
        let x2 = ymd(2001, 1, 1).num_days_from_ce() as f64;
        let x = ymd(2000, 7, 1).num_days_from_ce() as f64;
        let t2 = x2 - x0;
        let t = x - x0;
        let r2 = -0.99_f64.ln() / t2;
        let expected = (-r2 * t).exp();
        if let Number::F64(v) = result {
            assert!((v - expected).abs() < 1e-12, "got {v}, expected {expected}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_linear_zero_rate_extrapolation() {
        let nodes = f64_nodes();
        let interp = LinearZeroRateInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2005, 1, 1));
        assert_eq!(result, Number::F64(0.98)); // flat forward
    }

    #[test]
    fn test_linear_zero_rate_ad_propagation() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.98);
        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]));
        let interp = LinearZeroRateInterpolator;
        // Query in first interval (t1=0 case)
        let result = interp.interpolated_value(&nodes, ymd(2024, 7, 1));
        if let Number::Dual(d) = result {
            assert!(d.real() > 0.98 && d.real() < 1.0);
        } else {
            panic!("Expected Dual");
        }
    }
}
