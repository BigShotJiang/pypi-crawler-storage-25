use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::utils::index_left;

/// Extract the real (f64) value from a Number.
#[allow(dead_code)]
fn number_real(n: &Number) -> f64 {
    match n {
        Number::F64(f) => *f,
        Number::Dual(d) => d.real(),
        Number::Dual2(d) => d.real(),
    }
}

/// Evaluate cubic Hermite polynomial on interval [x0, x1].
/// y0, y1, m0, m1 are Number (AD-aware). Basis functions are f64 scalars.
pub fn hermite_eval(
    x: f64,
    x0: f64, y0: &Number, m0: &Number,
    x1: f64, y1: &Number, m1: &Number,
) -> Number {
    let h = x1 - x0;
    let t = (x - x0) / h;
    let t2 = t * t;
    let t3 = t2 * t;
    let h00 = 2.0 * t3 - 3.0 * t2 + 1.0;
    let h10 = t3 - 2.0 * t2 + t;
    let h01 = -2.0 * t3 + 3.0 * t2;
    let h11 = t3 - t2;
    // p(t) = y0*h00 + h*m0*h10 + y1*h01 + h*m1*h11
    &(&(y0 * h00) + &(m0 * (h * h10))) + &(&(y1 * h01) + &(m1 * (h * h11)))
}

/// Compute finite-difference tangents (Catmull-Rom for non-uniform spacing).
fn compute_tangents(xs: &[f64], ys: &[Number]) -> Vec<Number> {
    let n = ys.len();
    let mut m = Vec::with_capacity(n);
    // First endpoint: one-sided difference
    m.push(&(&ys[1] - &ys[0]) * (1.0 / (xs[1] - xs[0])));
    // Interior: average of adjacent secants
    for k in 1..n - 1 {
        let d_left = &(&ys[k] - &ys[k - 1]) * (1.0 / (xs[k] - xs[k - 1]));
        let d_right = &(&ys[k + 1] - &ys[k]) * (1.0 / (xs[k + 1] - xs[k]));
        m.push(&(&d_left + &d_right) * 0.5);
    }
    // Last endpoint: one-sided difference
    m.push(&(&ys[n - 1] - &ys[n - 2]) * (1.0 / (xs[n - 1] - xs[n - 2])));
    m
}

/// Hermite interpolator using cubic Hermite polynomials with finite-difference tangents.
#[derive(Clone, Debug)]
pub struct HermiteInterpolator {
    pub xs: Vec<f64>,
    pub ys: Vec<Number>,
    pub tangents: Vec<Number>,
}

impl HermiteInterpolator {
    /// Create a placeholder instance (used during deserialization before rebuild).
    pub fn placeholder() -> Self {
        Self { xs: vec![], ys: vec![], tangents: vec![] }
    }

    /// Build from curve nodes, extracting xs/ys and computing tangents.
    pub fn build(nodes: &Nodes) -> Self {
        let xs = nodes.keys_as_f64();
        let ys: Vec<Number> = (0..nodes.len()).map(|i| nodes.get_value_at_index(i)).collect();
        let tangents = compute_tangents(&xs, &ys);
        HermiteInterpolator { xs, ys, tangents }
    }
}

impl CurveInterpolation for HermiteInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        // Rebuild from nodes to capture AD state
        let xs = nodes.keys_as_f64();
        let ys: Vec<Number> = (0..nodes.len()).map(|i| nodes.get_value_at_index(i)).collect();
        let tangents = compute_tangents(&xs, &ys);

        let x = date.num_days_from_ce() as f64;

        // Flat forward extrapolation beyond last node
        if x >= *xs.last().unwrap() {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        let i = index_left(x, &xs);
        hermite_eval(x, xs[i], &ys[i], &tangents[i], xs[i + 1], &ys[i + 1], &tangents[i + 1])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use chrono::NaiveDate;
    use crate::autodiff::dual::{Dual, Dual2, Vars};
    use crate::autodiff::enums::Number;
    use crate::marketcurves::nodes::Nodes;
    use std::sync::Arc;
    use indexmap::IndexSet;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn five_node_f64() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
            (ymd(2026, 1, 1), 0.95),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.86),
        ]))
    }

    // Test 1: Reproduces node values exactly
    #[test]
    fn test_hermite_reproduces_nodes() {
        let nodes = five_node_f64();
        let interp = HermiteInterpolator::build(&nodes);
        let dates = vec![
            ymd(2024, 1, 1), ymd(2025, 1, 1), ymd(2026, 1, 1),
            ymd(2027, 1, 1), ymd(2028, 1, 1),
        ];
        let expected = vec![1.0, 0.98, 0.95, 0.91, 0.86];
        for (date, exp) in dates.iter().zip(expected.iter()) {
            let val = interp.interpolated_value(&nodes, *date);
            if let Number::F64(v) = val {
                assert!(
                    (v - exp).abs() < 1e-12,
                    "At {:?}: got {}, expected {}", date, v, exp
                );
            } else {
                panic!("Expected F64");
            }
        }
    }

    // Test 2: Mid-interval returns value between adjacent nodes for monotone input
    #[test]
    fn test_hermite_mid_interval() {
        let nodes = five_node_f64();
        let interp = HermiteInterpolator::build(&nodes);
        let val = interp.interpolated_value(&nodes, ymd(2025, 7, 1));
        if let Number::F64(v) = val {
            assert!(v > 0.95 && v < 0.98, "Mid-point value {} should be between 0.95 and 0.98", v);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 3: Extrapolation beyond last node returns last node value
    #[test]
    fn test_hermite_extrapolation() {
        let nodes = five_node_f64();
        let interp = HermiteInterpolator::build(&nodes);
        let val = interp.interpolated_value(&nodes, ymd(2030, 1, 1));
        if let Number::F64(v) = val {
            assert!((v - 0.86).abs() < 1e-12, "Extrapolation should return last node value, got {}", v);
        } else {
            panic!("Expected F64");
        }
    }

    // Test 4: AD -- Dual nodes produce Dual output with non-zero derivatives
    #[test]
    fn test_hermite_ad_dual() {
        let var_names = Arc::new(IndexSet::from_iter(vec![
            "v0".to_string(), "v1".to_string(), "v2".to_string(),
            "v3".to_string(), "v4".to_string(),
        ]));
        let n_vars = 5;
        let values = vec![1.0, 0.98, 0.95, 0.91, 0.86];
        let dates = vec![
            ymd(2024, 1, 1), ymd(2025, 1, 1), ymd(2026, 1, 1),
            ymd(2027, 1, 1), ymd(2028, 1, 1),
        ];
        let mut map = IndexMap::new();
        for (i, (&date, &val)) in dates.iter().zip(values.iter()).enumerate() {
            let mut dual_vec = ndarray::Array1::zeros(n_vars);
            dual_vec[i] = 1.0;
            let dual = Dual {
                real: val,
                vars: Arc::clone(&var_names),
                dual: dual_vec,
            };
            map.insert(date, dual);
        }
        let nodes = Nodes::from_dual_map(map);
        let interp = HermiteInterpolator::build(&nodes);
        let val = interp.interpolated_value(&nodes, ymd(2025, 7, 1));
        if let Number::Dual(d) = val {
            assert!(d.real() > 0.93 && d.real() < 0.98, "Real value: {}", d.real());
            // At least some derivatives should be non-zero
            let has_nonzero = d.dual.iter().any(|&x| x.abs() > 1e-15);
            assert!(has_nonzero, "Dual should have non-zero derivatives");
        } else {
            panic!("Expected Dual");
        }
    }

    // Test 5: Full Jacobian FD vs AD test
    #[test]
    fn test_hermite_ad_vs_fd() {
        let values = vec![1.0, 0.98, 0.95, 0.91, 0.86];
        let dates = vec![
            ymd(2024, 1, 1), ymd(2025, 1, 1), ymd(2026, 1, 1),
            ymd(2027, 1, 1), ymd(2028, 1, 1),
        ];
        let query_date = ymd(2025, 7, 1);
        let bump = 1e-6;
        let n = values.len();

        // AD: build Dual nodes and evaluate
        let var_names = Arc::new(IndexSet::from_iter(
            (0..n).map(|i| format!("v{}", i)).collect::<Vec<_>>()
        ));
        let mut dual_map = IndexMap::new();
        for (i, (&date, &val)) in dates.iter().zip(values.iter()).enumerate() {
            let mut dual_vec = ndarray::Array1::zeros(n);
            dual_vec[i] = 1.0;
            let dual = Dual {
                real: val,
                vars: Arc::clone(&var_names),
                dual: dual_vec,
            };
            dual_map.insert(date, dual);
        }
        let dual_nodes = Nodes::from_dual_map(dual_map);
        let interp = HermiteInterpolator::build(&dual_nodes);
        let ad_result = interp.interpolated_value(&dual_nodes, query_date);
        let ad_derivs: Vec<f64> = if let Number::Dual(d) = &ad_result {
            d.dual.to_vec()
        } else {
            panic!("Expected Dual");
        };

        // FD: bump each node and compute finite difference
        let base_nodes = Nodes::from_f64_map(IndexMap::from_iter(
            dates.iter().zip(values.iter()).map(|(&d, &v)| (d, v))
        ));
        let base_interp = HermiteInterpolator::build(&base_nodes);
        let base_val = if let Number::F64(v) = base_interp.interpolated_value(&base_nodes, query_date) {
            v
        } else {
            panic!("Expected F64");
        };

        for i in 0..n {
            let mut bumped_values = values.clone();
            bumped_values[i] += bump;
            let bumped_nodes = Nodes::from_f64_map(IndexMap::from_iter(
                dates.iter().zip(bumped_values.iter()).map(|(&d, &v)| (d, v))
            ));
            let bumped_interp = HermiteInterpolator::build(&bumped_nodes);
            let bumped_val = if let Number::F64(v) = bumped_interp.interpolated_value(&bumped_nodes, query_date) {
                v
            } else {
                panic!("Expected F64");
            };
            let fd_deriv = (bumped_val - base_val) / bump;
            let ad_deriv = ad_derivs[i];
            let denom = if ad_deriv.abs() > 1e-10 { ad_deriv.abs() } else { 1.0 };
            let rel_err = (ad_deriv - fd_deriv).abs() / denom;
            assert!(
                rel_err < 1e-6,
                "Node {}: AD={:.10}, FD={:.10}, rel_err={:.2e}",
                i, ad_deriv, fd_deriv, rel_err
            );
        }
    }

    // Test 6: Minimum case with 3 nodes
    #[test]
    fn test_hermite_three_nodes() {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.93),
        ]));
        let interp = HermiteInterpolator::build(&nodes);

        // At nodes
        for (date, exp) in [(ymd(2024, 1, 1), 1.0), (ymd(2025, 1, 1), 0.97), (ymd(2026, 1, 1), 0.93)] {
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(v) = val {
                assert!((v - exp).abs() < 1e-12, "At {:?}: got {}, expected {}", date, v, exp);
            }
        }

        // Mid-point
        let val = interp.interpolated_value(&nodes, ymd(2024, 7, 1));
        if let Number::F64(v) = val {
            assert!(v > 0.93 && v < 1.0, "Mid-point value {} should be between 0.93 and 1.0", v);
        }
    }
}
