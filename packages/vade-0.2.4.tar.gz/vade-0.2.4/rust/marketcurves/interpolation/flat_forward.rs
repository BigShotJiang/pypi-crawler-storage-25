use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::utils::index_left;

/// Flat forward interpolation: returns the left-side node value for any point in interval.
/// For extrapolation beyond last node, returns last node value.
#[derive(Clone, Debug)]
pub struct FlatForwardInterpolator;

impl CurveInterpolation for FlatForwardInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let xs = nodes.keys_as_f64();
        let index = index_left(x, &xs);

        // At or beyond last node: return last node value
        if x >= *xs.last().unwrap() {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        // At the exact right boundary of interval: return right node
        if x >= xs[index + 1] {
            nodes.get_value_at_index(index + 1)
        } else {
            nodes.get_value_at_index(index)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::autodiff::dual::Dual;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn f64_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2000, 1, 1), 1.0),
            (ymd(2001, 1, 1), 0.99),
            (ymd(2002, 1, 1), 0.98),
        ]))
    }

    #[test]
    fn test_flat_forward_mid_interval() {
        let nodes = f64_nodes();
        let interp = FlatForwardInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2000, 7, 1));
        // Flat forward returns left-side value
        assert_eq!(result, Number::F64(1.0));
    }

    #[test]
    fn test_flat_forward_at_node() {
        let nodes = f64_nodes();
        let interp = FlatForwardInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2001, 1, 1));
        // At exact node boundary, return that node value
        assert_eq!(result, Number::F64(0.99));
    }

    #[test]
    fn test_flat_forward_left_out_of_bounds() {
        let nodes = f64_nodes();
        let interp = FlatForwardInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(1999, 7, 1));
        assert_eq!(result, Number::F64(1.0));
    }

    #[test]
    fn test_flat_forward_right_out_of_bounds() {
        let nodes = f64_nodes();
        let interp = FlatForwardInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2005, 7, 1));
        assert_eq!(result, Number::F64(0.98));
    }

    #[test]
    fn test_flat_forward_ad_propagation() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.98);
        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]));
        let interp = FlatForwardInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2024, 7, 1));
        if let Number::Dual(d) = result {
            assert_eq!(d.real(), 1.0); // left-side value
        } else {
            panic!("Expected Dual");
        }
    }
}
