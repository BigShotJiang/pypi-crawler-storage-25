use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::utils::{index_left, linear_interp};

/// Linear interpolation between adjacent nodes.
#[derive(Clone, Debug)]
pub struct LinearInterpolator;

impl CurveInterpolation for LinearInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let xs = nodes.keys_as_f64();
        let index = index_left(x, &xs);

        // Extrapolation beyond last node: flat (return last value)
        if x >= *xs.last().unwrap() {
            return nodes.get_value_at_index(nodes.len() - 1);
        }

        macro_rules! interp {
            ($Variant:ident, $map:expr) => {{
                let (_, y1) = $map.get_index(index).unwrap();
                let (_, y2) = $map.get_index(index + 1).unwrap();
                Number::$Variant(linear_interp(xs[index], y1, xs[index + 1], y2, x))
            }};
        }
        match nodes {
            Nodes::F64(m) => interp!(F64, m),
            Nodes::Dual(m) => interp!(Dual, m),
            Nodes::Dual2(m) => interp!(Dual2, m),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::autodiff::dual::Dual;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn f64_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2000, 1, 1), 1.0),
            (ymd(2001, 1, 1), 0.99),
            (ymd(2002, 1, 1), 0.98),
        ]))
    }

    #[test]
    fn test_linear_mid_interval() {
        let nodes = f64_nodes();
        let interp = LinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2000, 7, 1));
        let x1 = ymd(2000, 1, 1).num_days_from_ce() as f64;
        let x2 = ymd(2001, 1, 1).num_days_from_ce() as f64;
        let x = ymd(2000, 7, 1).num_days_from_ce() as f64;
        let frac = (x - x1) / (x2 - x1);
        let expected = 1.0 + frac * (0.99 - 1.0);
        if let Number::F64(v) = result {
            assert!((v - expected).abs() < 1e-12);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_linear_at_node() {
        let nodes = f64_nodes();
        let interp = LinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2001, 1, 1));
        assert_eq!(result, Number::F64(0.99));
    }

    #[test]
    fn test_linear_extrapolation() {
        let nodes = f64_nodes();
        let interp = LinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2005, 1, 1));
        assert_eq!(result, Number::F64(0.98)); // flat
    }

    #[test]
    fn test_linear_ad_propagation() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.98);
        let nodes = Nodes::from_dual_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]));
        let interp = LinearInterpolator;
        let result = interp.interpolated_value(&nodes, ymd(2024, 7, 1));
        if let Number::Dual(d) = result {
            assert!(d.real() > 0.98 && d.real() < 1.0);
        } else {
            panic!("Expected Dual");
        }
    }
}
