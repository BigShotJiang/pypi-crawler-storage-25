use chrono::{Datelike, NaiveDate};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::CurveInterpolation;
use crate::marketcurves::interpolation::utils::index_left;

/// Extract the f64 real value from a Number (for branching, per Pitfall 4).
fn number_real(n: &Number) -> f64 {
    match n {
        Number::F64(f) => *f,
        Number::Dual(d) => d.real(),
        Number::Dual2(d) => d.real(),
    }
}

/// Convex Monotone (Hagan-West) interpolation.
///
/// Operates in forward-rate space, deriving forward rates internally from
/// discount factor nodes. Ensures positive forward rates everywhere through
/// piecewise quadratic evaluation with monotonicity enforcement.
///
/// Algorithm:
/// 1. Compute discrete forward rates from DF nodes: f_i = -log(DF_{i+1}/DF_i) / dt_i
/// 2. Compute f_bar at nodes (weighted average of adjacent forwards)
/// 3. For each interval, define quadratic forward function preserving area
/// 4. Enforce positivity of forwards via g-value scaling
/// 5. Integrate forward rate to recover DF at query date
#[derive(Clone, Debug)]
pub struct ConvexMonotoneInterpolator;

/// Compute discrete forward rates from DF nodes.
/// f_i = -log(DF_{i+1} / DF_i) / (t_{i+1} - t_i) for i=0..n-2
/// All arithmetic via Number ops to preserve AD.
fn compute_forward_rates(xs: &[f64], dfs: &[Number]) -> Vec<Number> {
    (0..dfs.len() - 1)
        .map(|i| {
            let dt = xs[i + 1] - xs[i];
            let ratio = &dfs[i + 1] / &dfs[i]; // Number division
            ratio.log() * (-1.0 / dt) // Number log * f64 scalar
        })
        .collect()
}

/// Compute f_bar (discrete forward rates at nodes).
/// Interior: f_bar_i = (dt_{i-1} * f_i + dt_i * f_{i-1}) / (dt_{i-1} + dt_i)
/// Endpoints: f_bar_0 = f_0, f_bar_{n-1} = f_{n-2}
fn compute_f_bar(xs: &[f64], fwd_rates: &[Number]) -> Vec<Number> {
    let n = xs.len(); // number of nodes
    let mut f_bar = Vec::with_capacity(n);

    // f_bar_0 = f_0
    f_bar.push(fwd_rates[0].clone());

    // Interior nodes
    for i in 1..n - 1 {
        let dt_prev = xs[i] - xs[i - 1]; // dt_{i-1}
        let dt_curr = xs[i + 1] - xs[i]; // dt_i
        let total = dt_prev + dt_curr;
        // f_bar_i = (dt_prev * f_i + dt_curr * f_{i-1}) / total
        let val = &(&fwd_rates[i] * dt_prev + &fwd_rates[i - 1] * dt_curr) / &Number::F64(total);
        f_bar.push(val);
    }

    // f_bar_{n-1} = f_{n-2}
    f_bar.push(fwd_rates[fwd_rates.len() - 1].clone());

    f_bar
}

/// Evaluate the integrated forward rate from 0 to x for the quadratic:
/// f(x) = f_i + g_0*(1 - 4x + 3x^2) + g_1*(-2x + 3x^2)
/// Integral F(x) = f_i*x + g_0*(x - 2x^2 + x^3) + g_1*(-x^2 + x^3)
fn integrated_forward(f_i: &Number, g_0: &Number, g_1: &Number, x: f64) -> Number {
    let x2 = x * x;
    let x3 = x2 * x;
    let term_fi = f_i * x;
    let term_g0 = g_0 * (x - 2.0 * x2 + x3);
    let term_g1 = g_1 * (-x2 + x3);
    &(&term_fi + &term_g0) + &term_g1
}

/// Check the minimum of the forward rate quadratic f(x) = f_i + g_0*(1-4x+3x^2) + g_1*(-2x+3x^2)
/// on [0,1]. If minimum < 0, scale g_0 and g_1 toward zero to enforce positivity.
/// Returns (adjusted_g0, adjusted_g1).
fn enforce_positivity(
    f_i: &Number,
    g_0: &Number,
    g_1: &Number,
) -> (Number, Number) {
    let f_i_real = number_real(f_i);
    let g_0_real = number_real(g_0);
    let g_1_real = number_real(g_1);

    // f'(x) = g_0*(-4 + 6x) + g_1*(-2 + 6x)
    // Set to 0: x_min = (4*g_0 + 2*g_1) / (6*(g_0 + g_1))
    let denom = 6.0 * (g_0_real + g_1_real);
    if denom.abs() < 1e-15 {
        // g_0 + g_1 ~ 0: forward is essentially constant at f_i
        return (g_0.clone(), g_1.clone());
    }

    let x_min = (4.0 * g_0_real + 2.0 * g_1_real) / denom;

    // Check at x_min if it's in [0, 1], plus endpoints
    let mut min_val = f_i_real; // forward at x=0 is f_i + g_0
    for &x in &[0.0_f64, 1.0, x_min] {
        if x >= 0.0 && x <= 1.0 {
            let x2 = x * x;
            let _x3 = x2 * x;
            let fwd = f_i_real + g_0_real * (1.0 - 4.0 * x + 3.0 * x2)
                + g_1_real * (-2.0 * x + 3.0 * x2);
            if fwd < min_val {
                min_val = fwd;
            }
        }
    }

    if min_val >= 0.0 {
        return (g_0.clone(), g_1.clone());
    }

    // Scale g_0, g_1 toward zero. We need f_i + alpha*g >= 0 everywhere.
    // Binary search for the largest alpha in [0, 1] that keeps min >= 0.
    let mut alpha_lo = 0.0_f64;
    let mut alpha_hi = 1.0_f64;
    for _ in 0..50 {
        let alpha = 0.5 * (alpha_lo + alpha_hi);
        let ag0 = alpha * g_0_real;
        let ag1 = alpha * g_1_real;

        let denom_a = 6.0 * (ag0 + ag1);
        let x_m = if denom_a.abs() < 1e-15 {
            0.5
        } else {
            ((4.0 * ag0 + 2.0 * ag1) / denom_a).clamp(0.0, 1.0)
        };

        let mut min_v = f64::MAX;
        for &x in &[0.0_f64, 1.0, x_m] {
            if x >= 0.0 && x <= 1.0 {
                let x2 = x * x;
                let fwd = f_i_real + ag0 * (1.0 - 4.0 * x + 3.0 * x2)
                    + ag1 * (-2.0 * x + 3.0 * x2);
                if fwd < min_v {
                    min_v = fwd;
                }
            }
        }

        if min_v >= 0.0 {
            alpha_lo = alpha;
        } else {
            alpha_hi = alpha;
        }
    }

    let alpha = alpha_lo;
    (g_0 * alpha, g_1 * alpha)
}

impl CurveInterpolation for ConvexMonotoneInterpolator {
    fn interpolated_value(&self, nodes: &Nodes, date: NaiveDate) -> Number {
        let x = date.num_days_from_ce() as f64;
        let xs = nodes.keys_as_f64();
        let n = nodes.len();
        assert!(n >= 3, "ConvexMonotoneInterpolator requires at least 3 nodes");

        // Extrapolation: flat forward
        if x >= *xs.last().unwrap() {
            return nodes.get_value_at_index(n - 1);
        }
        if x <= xs[0] {
            return nodes.get_value_at_index(0);
        }

        // Collect DF values
        let dfs: Vec<Number> = (0..n).map(|i| nodes.get_value_at_index(i)).collect();

        // Step 1: Compute forward rates from DFs
        let fwd_rates = compute_forward_rates(&xs, &dfs);

        // Step 2: Compute f_bar at each node
        let f_bar = compute_f_bar(&xs, &fwd_rates);

        // Find interval
        let idx = index_left(x, &xs);

        // dt for this interval
        let dt_i = xs[idx + 1] - xs[idx];
        // Normalized parameter within interval
        let t_norm = (x - xs[idx]) / dt_i;

        // Step 3: g-values for this interval
        let f_i = &fwd_rates[idx];
        let g_0 = &f_bar[idx] - f_i;
        let g_1 = &f_bar[idx + 1] - f_i;

        // Step 4: Enforce positive forwards
        let (g_0_adj, g_1_adj) = enforce_positivity(f_i, &g_0, &g_1);

        // Step 5: Integrate forward rate from 0 to t_norm and compute DF
        let f_integral = integrated_forward(f_i, &g_0_adj, &g_1_adj, t_norm);

        // DF(t) = DF(t_i) * exp(-F(t_norm) * dt_i)
        let neg_integral = &f_integral * (-dt_i);
        &dfs[idx] * &neg_integral.exp()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use indexmap::IndexMap;
    use crate::autodiff::dual::{Dual, Dual2};
    use crate::autodiff::enums::Number;
    use crate::marketcurves::nodes::Nodes;
    use std::sync::Arc;
    use indexmap::IndexSet;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    /// 5 monotone-decreasing DF nodes
    fn monotone_df_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.90),
            (ymd(2028, 1, 1), 0.85),
        ]))
    }

    /// Steep curve with high rates
    fn steep_df_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.90),
            (ymd(2026, 1, 1), 0.75),
            (ymd(2027, 1, 1), 0.55),
            (ymd(2028, 1, 1), 0.35),
        ]))
    }

    /// Flat forward rates (exponential decay DFs)
    fn flat_forward_df_nodes() -> Nodes {
        let r = 0.03; // 3% flat rate
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), (-r * 1.0_f64).exp()),
            (ymd(2026, 1, 1), (-r * 2.0_f64).exp()),
            (ymd(2027, 1, 1), (-r * 3.0_f64).exp()),
            (ymd(2028, 1, 1), (-r * 4.0_f64).exp()),
        ]))
    }

    /// Minimum 3 nodes
    fn min_df_nodes() -> Nodes {
        Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.96),
            (ymd(2026, 1, 1), 0.91),
        ]))
    }

    // Test 1: Reproduces exact DF at node dates
    #[test]
    fn test_convex_monotone_reproduces_nodes() {
        let nodes = monotone_df_nodes();
        let interp = ConvexMonotoneInterpolator;
        let expected_dfs = vec![1.0, 0.97, 0.94, 0.90, 0.85];
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
            ymd(2028, 1, 1),
        ];
        for (date, exp) in dates.iter().zip(expected_dfs.iter()) {
            let val = interp.interpolated_value(&nodes, *date);
            if let Number::F64(v) = val {
                assert!(
                    (v - exp).abs() < 1e-10,
                    "At {:?}: got {}, expected {}",
                    date,
                    v,
                    exp
                );
            } else {
                panic!("Expected F64");
            }
        }
    }

    // Test 2: Forward rates are positive
    #[test]
    fn test_convex_monotone_positive_forwards() {
        let nodes = monotone_df_nodes();
        let interp = ConvexMonotoneInterpolator;

        // Evaluate at 50 equally-spaced points
        let start = ymd(2024, 1, 1).num_days_from_ce();
        let end = ymd(2028, 1, 1).num_days_from_ce();
        let step = ((end - start) as f64 / 50.0) as i32;

        let mut prev_df = 1.0_f64;
        let mut prev_x = start as f64;
        for i in 1..=50 {
            let day = start + i * step;
            let date = NaiveDate::from_num_days_from_ce_opt(day).unwrap();
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(df) = val {
                let x = day as f64;
                let dt = x - prev_x;
                if dt > 0.0 {
                    // implied forward = -log(df/prev_df) / dt
                    let implied_fwd = -(df / prev_df).ln() / dt;
                    assert!(
                        implied_fwd >= -1e-10,
                        "Negative forward rate {} at day {}",
                        implied_fwd,
                        day
                    );
                }
                prev_df = df;
                prev_x = x;
            } else {
                panic!("Expected F64");
            }
        }
    }

    // Test 3: Interpolated DFs are monotone decreasing
    #[test]
    fn test_convex_monotone_monotone_decreasing() {
        let nodes = monotone_df_nodes();
        let interp = ConvexMonotoneInterpolator;

        let start = ymd(2024, 1, 1).num_days_from_ce();
        let end = ymd(2028, 1, 1).num_days_from_ce();
        let step = ((end - start) as f64 / 100.0) as i32;

        let mut prev_df = f64::MAX;
        for i in 0..=100 {
            let day = start + i * step;
            let date = NaiveDate::from_num_days_from_ce_opt(day).unwrap();
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(df) = val {
                assert!(
                    df <= prev_df + 1e-12,
                    "DF not monotone decreasing: prev={}, curr={} at day {}",
                    prev_df,
                    df,
                    day
                );
                prev_df = df;
            }
        }
    }

    // Test 4: Flat forward rates reproduce exactly
    #[test]
    fn test_convex_monotone_flat_forward_exact() {
        let nodes = flat_forward_df_nodes();
        let interp = ConvexMonotoneInterpolator;
        let r = 0.03;

        // Check mid-points between nodes
        let xs = nodes.keys_as_f64();
        let x0 = xs[0];
        for i in 0..4 {
            let x_mid = 0.5 * (xs[i] + xs[i + 1]);
            let date = NaiveDate::from_num_days_from_ce_opt(x_mid as i32).unwrap();
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(df) = val {
                let t = (x_mid - x0) / 365.25; // approximate year fraction
                // For exactly spaced nodes with constant forward, the convex monotone
                // should reproduce closely (not exactly due to day count vs year fraction)
                // Just check it's reasonable
                let expected_approx = (-r * t).exp();
                assert!(
                    (df - expected_approx).abs() < 0.01,
                    "Flat forward midpoint: got {}, expected ~{}",
                    df,
                    expected_approx
                );
            }
        }
    }

    // Test 5: Full Jacobian FD vs AD test
    #[test]
    fn test_convex_monotone_ad_vs_fd() {
        let interp = ConvexMonotoneInterpolator;
        let base_dfs = vec![1.0, 0.97, 0.94, 0.90, 0.85];
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
            ymd(2028, 1, 1),
        ];
        let query_date = ymd(2025, 7, 1);
        let bump = 1e-6;

        // Create Dual nodes (ini_solve=1: first node fixed)
        let n_vars = base_dfs.len() - 1; // 4 AD variables
        let var_names: Arc<IndexSet<String>> = Arc::new(
            (0..n_vars)
                .map(|i| format!("v{}", i))
                .collect(),
        );

        let mut dual_nodes_map = IndexMap::new();
        for (i, (&date, &df)) in dates.iter().zip(base_dfs.iter()).enumerate() {
            if i == 0 {
                // Constant dual
                let d = Dual {
                    real: df,
                    vars: Arc::clone(&var_names),
                    dual: ndarray::Array1::zeros(n_vars),
                };
                dual_nodes_map.insert(date, d);
            } else {
                let mut dual_vec = ndarray::Array1::zeros(n_vars);
                dual_vec[i - 1] = 1.0;
                let d = Dual {
                    real: df,
                    vars: Arc::clone(&var_names),
                    dual: dual_vec,
                };
                dual_nodes_map.insert(date, d);
            }
        }
        let dual_nodes = Nodes::from_dual_map(dual_nodes_map);
        let ad_result = interp.interpolated_value(&dual_nodes, query_date);
        let ad_derivs = match &ad_result {
            Number::Dual(d) => d.dual.to_vec(),
            _ => panic!("Expected Dual"),
        };

        // Finite difference for each variable
        for var_idx in 0..n_vars {
            let node_idx = var_idx + 1; // skip first fixed node
            let mut dfs_up = base_dfs.clone();
            let mut dfs_dn = base_dfs.clone();
            dfs_up[node_idx] += bump;
            dfs_dn[node_idx] -= bump;

            let nodes_up = Nodes::from_f64_map(
                dates
                    .iter()
                    .zip(dfs_up.iter())
                    .map(|(&d, &v)| (d, v))
                    .collect(),
            );
            let nodes_dn = Nodes::from_f64_map(
                dates
                    .iter()
                    .zip(dfs_dn.iter())
                    .map(|(&d, &v)| (d, v))
                    .collect(),
            );

            let val_up = match interp.interpolated_value(&nodes_up, query_date) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };
            let val_dn = match interp.interpolated_value(&nodes_dn, query_date) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };

            let fd_deriv = (val_up - val_dn) / (2.0 * bump);
            let ad_deriv = ad_derivs[var_idx];

            let denom = if fd_deriv.abs() > 1e-10 {
                fd_deriv.abs()
            } else {
                1.0
            };
            let rel_err = (ad_deriv - fd_deriv).abs() / denom;
            assert!(
                rel_err < 1e-6,
                "AD vs FD mismatch for var {}: AD={}, FD={}, rel_err={}",
                var_idx,
                ad_deriv,
                fd_deriv,
                rel_err
            );
        }
    }

    // Test 6: Minimum 3 nodes
    #[test]
    fn test_convex_monotone_three_nodes() {
        let nodes = min_df_nodes();
        let interp = ConvexMonotoneInterpolator;

        // Should reproduce node values
        let val = interp.interpolated_value(&nodes, ymd(2025, 1, 1));
        if let Number::F64(v) = val {
            assert!((v - 0.96).abs() < 1e-10, "Got {} expected 0.96", v);
        }

        // Should interpolate between nodes
        let mid = interp.interpolated_value(&nodes, ymd(2024, 7, 1));
        if let Number::F64(v) = mid {
            assert!(v > 0.96 && v < 1.0, "Mid-point {} should be between 0.96 and 1.0", v);
        }
    }

    // Test 7: Steep curve (high rates), still positive forwards
    #[test]
    fn test_convex_monotone_steep_positive_forwards() {
        let nodes = steep_df_nodes();
        let interp = ConvexMonotoneInterpolator;

        let start = ymd(2024, 1, 1).num_days_from_ce();
        let end = ymd(2028, 1, 1).num_days_from_ce();
        let step = ((end - start) as f64 / 50.0) as i32;

        let mut prev_df = 1.0_f64;
        let mut prev_x = start as f64;
        for i in 1..=50 {
            let day = start + i * step;
            let date = NaiveDate::from_num_days_from_ce_opt(day).unwrap();
            let val = interp.interpolated_value(&nodes, date);
            if let Number::F64(df) = val {
                let x = day as f64;
                let dt = x - prev_x;
                if dt > 0.0 {
                    let implied_fwd = -(df / prev_df).ln() / dt;
                    assert!(
                        implied_fwd >= -1e-10,
                        "Negative forward rate {} at day {} (steep curve)",
                        implied_fwd,
                        day
                    );
                }
                prev_df = df;
                prev_x = x;
            }
        }
    }

    // Additional: Dual2 AD propagation test
    #[test]
    fn test_convex_monotone_dual2_propagation() {
        let interp = ConvexMonotoneInterpolator;
        let base_dfs = vec![1.0, 0.97, 0.94, 0.90, 0.85];
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2026, 1, 1),
            ymd(2027, 1, 1),
            ymd(2028, 1, 1),
        ];

        let n_vars = base_dfs.len() - 1;
        let var_names: Arc<IndexSet<String>> = Arc::new(
            (0..n_vars).map(|i| format!("v{}", i)).collect(),
        );

        let mut map = IndexMap::new();
        for (i, (&date, &df)) in dates.iter().zip(base_dfs.iter()).enumerate() {
            if i == 0 {
                let d = Dual2 {
                    real: df,
                    vars: Arc::clone(&var_names),
                    dual: ndarray::Array1::zeros(n_vars),
                    dual2: ndarray::Array2::zeros((n_vars, n_vars)),
                };
                map.insert(date, d);
            } else {
                let mut dual_vec = ndarray::Array1::zeros(n_vars);
                dual_vec[i - 1] = 1.0;
                let d = Dual2 {
                    real: df,
                    vars: Arc::clone(&var_names),
                    dual: dual_vec,
                    dual2: ndarray::Array2::zeros((n_vars, n_vars)),
                };
                map.insert(date, d);
            }
        }

        let dual2_nodes = Nodes::from_dual2_map(map);
        let result = interp.interpolated_value(&dual2_nodes, ymd(2025, 7, 1));
        if let Number::Dual2(d) = result {
            assert!(
                d.real() > 0.93 && d.real() < 0.97,
                "Dual2 real value: {}",
                d.real()
            );
            // Should have non-zero first derivatives
            let has_nonzero = d.dual.iter().any(|&v| v.abs() > 1e-15);
            assert!(has_nonzero, "Dual2 should have non-zero first derivatives");
        } else {
            panic!("Expected Dual2");
        }
    }

    // Test: extrapolation behavior
    #[test]
    fn test_convex_monotone_extrapolation() {
        let nodes = monotone_df_nodes();
        let interp = ConvexMonotoneInterpolator;

        // Beyond last node: flat forward
        let far = interp.interpolated_value(&nodes, ymd(2030, 1, 1));
        assert_eq!(far, Number::F64(0.85));

        // Before first node
        let early = interp.interpolated_value(&nodes, ymd(2023, 1, 1));
        assert_eq!(early, Number::F64(1.0));
    }
}
