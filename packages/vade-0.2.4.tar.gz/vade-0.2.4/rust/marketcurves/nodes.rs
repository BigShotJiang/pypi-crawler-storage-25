use chrono::{Datelike, NaiveDate};
use indexmap::{IndexMap, IndexSet};
use ndarray::Array1;
use serde::{Serialize, Deserialize, Serializer, Deserializer};
use std::sync::Arc;
use crate::autodiff::dual::{Dual, Dual2};
use crate::autodiff::enums::Number;

/// Date-indexed values for curve nodes.
/// Each variant stores an IndexMap<NaiveDate, T> with ordered date keys.
#[derive(Clone, Debug)]
pub enum Nodes {
    F64(IndexMap<NaiveDate, f64>),
    Dual(IndexMap<NaiveDate, Dual>),
    Dual2(IndexMap<NaiveDate, Dual2>),
}

impl Nodes {
    /// Create Nodes::F64 from an IndexMap<NaiveDate, f64>.
    pub fn from_f64_map(map: IndexMap<NaiveDate, f64>) -> Self {
        Nodes::F64(map)
    }

    /// Create Nodes::Dual from an IndexMap<NaiveDate, Dual>.
    pub fn from_dual_map(map: IndexMap<NaiveDate, Dual>) -> Self {
        Nodes::Dual(map)
    }

    /// Create Nodes::Dual2 from an IndexMap<NaiveDate, Dual2>.
    pub fn from_dual2_map(map: IndexMap<NaiveDate, Dual2>) -> Self {
        Nodes::Dual2(map)
    }

    /// Convert date keys to f64 using num_days_from_ce() for interpolation math.
    pub fn keys_as_f64(&self) -> Vec<f64> {
        match self {
            Nodes::F64(m) => m.keys().map(|d| d.num_days_from_ce() as f64).collect(),
            Nodes::Dual(m) => m.keys().map(|d| d.num_days_from_ce() as f64).collect(),
            Nodes::Dual2(m) => m.keys().map(|d| d.num_days_from_ce() as f64).collect(),
        }
    }

    /// Return the number of nodes.
    pub fn len(&self) -> usize {
        match self {
            Nodes::F64(m) => m.len(),
            Nodes::Dual(m) => m.len(),
            Nodes::Dual2(m) => m.len(),
        }
    }

    /// Check if nodes collection is empty.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Get the value at a given index as a Number.
    pub fn get_value_at_index(&self, i: usize) -> Number {
        match self {
            Nodes::F64(m) => {
                let (_, v) = m.get_index(i).unwrap();
                Number::F64(*v)
            }
            Nodes::Dual(m) => {
                let (_, v) = m.get_index(i).unwrap();
                Number::Dual(v.clone())
            }
            Nodes::Dual2(m) => {
                let (_, v) = m.get_index(i).unwrap();
                Number::Dual2(v.clone())
            }
        }
    }

    /// Get the first key (date).
    pub fn first_key(&self) -> NaiveDate {
        match self {
            Nodes::F64(m) => *m.first().unwrap().0,
            Nodes::Dual(m) => *m.first().unwrap().0,
            Nodes::Dual2(m) => *m.first().unwrap().0,
        }
    }

    /// Get the last key (date).
    pub fn last_key(&self) -> NaiveDate {
        match self {
            Nodes::F64(m) => *m.last().unwrap().0,
            Nodes::Dual(m) => *m.last().unwrap().0,
            Nodes::Dual2(m) => *m.last().unwrap().0,
        }
    }

    /// Auto-insert DF=1.0 at the first node date if first value != 1.0.
    /// Returns true if insertion occurred.
    /// For DiscountCurve usage: ensures the first node has DF=1.0.
    pub fn ensure_first_df_one(&mut self) -> bool {
        match self {
            Nodes::F64(m) => {
                if let Some((date, val)) = m.first() {
                    if (*val - 1.0).abs() > f64::EPSILON {
                        let date = *date;
                        m.insert(date, 1.0);
                        m.sort_keys();
                        return true;
                    }
                }
                false
            }
            Nodes::Dual(m) => {
                if let Some((date, val)) = m.first() {
                    if (val.real() - 1.0).abs() > f64::EPSILON {
                        let date = *date;
                        let one = Dual::new_from(val, 1.0);
                        m.insert(date, one);
                        m.sort_keys();
                        return true;
                    }
                }
                false
            }
            Nodes::Dual2(m) => {
                if let Some((date, val)) = m.first() {
                    if (val.real() - 1.0).abs() > f64::EPSILON {
                        let date = *date;
                        let one = Dual2::new_from(val, 1.0);
                        m.insert(date, one);
                        m.sort_keys();
                        return true;
                    }
                }
                false
            }
        }
    }

    /// Extract f64 values from any variant (real part for Dual/Dual2).
    pub fn get_values_f64(&self) -> Vec<f64> {
        match self {
            Nodes::F64(m) => m.values().copied().collect(),
            Nodes::Dual(m) => m.values().map(|d| d.real()).collect(),
            Nodes::Dual2(m) => m.values().map(|d| d.real()).collect(),
        }
    }

    /// Extract all date keys.
    pub fn keys(&self) -> Vec<NaiveDate> {
        match self {
            Nodes::F64(m) => m.keys().copied().collect(),
            Nodes::Dual(m) => m.keys().copied().collect(),
            Nodes::Dual2(m) => m.keys().copied().collect(),
        }
    }

    /// Convert to Dual nodes for AD-based solver iteration.
    ///
    /// Indices 0..ini_solve become constant Duals (zero derivatives).
    /// Indices ini_solve.. get AD variables corresponding to their position in var_names.
    /// For DiscountCurve ini_solve=1 (first DF fixed at 1.0), for LineCurve ini_solve=0.
    pub fn set_values_as_dual(
        &mut self,
        values: &[f64],
        var_names: Arc<IndexSet<String>>,
        ini_solve: usize,
    ) {
        let dates = self.keys();
        assert_eq!(values.len(), dates.len(), "values length must match nodes length");
        let n_vars = var_names.len();
        let mut map = IndexMap::new();
        for (i, (&date, &val)) in dates.iter().zip(values.iter()).enumerate() {
            if i < ini_solve {
                // Constant dual: zero derivatives, shares the var_names Arc
                let dual = Dual {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: Array1::zeros(n_vars),
                };
                map.insert(date, dual);
            } else {
                // AD variable: derivative is 1.0 at position (i - ini_solve), 0 elsewhere
                let var_idx = i - ini_solve;
                let mut dual_vec = Array1::zeros(n_vars);
                if var_idx < n_vars {
                    dual_vec[var_idx] = 1.0;
                }
                let dual = Dual {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: dual_vec,
                };
                map.insert(date, dual);
            }
        }
        *self = Nodes::Dual(map);
    }

    /// Convert to Dual2 nodes for AD-based gamma computation.
    ///
    /// Indices 0..ini_solve become constant Dual2s (zero first and second derivatives).
    /// Indices ini_solve.. get AD variables with identity first derivative at their position.
    /// All second derivatives start as zero -- AD arithmetic fills them during evaluation.
    pub fn set_values_as_dual2(
        &mut self,
        values: &[f64],
        var_names: Arc<IndexSet<String>>,
        ini_solve: usize,
    ) {
        let dates = self.keys();
        assert_eq!(values.len(), dates.len(), "values length must match nodes length");
        let n_vars = var_names.len();
        let mut map = IndexMap::new();
        for (i, (&date, &val)) in dates.iter().zip(values.iter()).enumerate() {
            if i < ini_solve {
                // Constant Dual2: zero first and second derivatives
                let d2 = Dual2 {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: Array1::zeros(n_vars),
                    dual2: ndarray::Array2::zeros((n_vars, n_vars)),
                };
                map.insert(date, d2);
            } else {
                // AD variable: first derivative is 1.0 at position (i - ini_solve)
                let var_idx = i - ini_solve;
                let mut dual_vec = Array1::zeros(n_vars);
                if var_idx < n_vars {
                    dual_vec[var_idx] = 1.0;
                }
                let d2 = Dual2 {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: dual_vec,
                    dual2: ndarray::Array2::zeros((n_vars, n_vars)),
                };
                map.insert(date, d2);
            }
        }
        *self = Nodes::Dual2(map);
    }

    /// Convert back to F64 nodes (for resetting after solve).
    pub fn set_values_as_f64(&mut self, values: &[f64]) {
        let dates = self.keys();
        assert_eq!(values.len(), dates.len(), "values length must match nodes length");
        let mut map = IndexMap::new();
        for (&date, &val) in dates.iter().zip(values.iter()) {
            map.insert(date, val);
        }
        *self = Nodes::F64(map);
    }

    /// Sort keys by date order.
    pub fn sort_keys(&mut self) {
        match self {
            Nodes::F64(m) => m.sort_keys(),
            Nodes::Dual(m) => m.sort_keys(),
            Nodes::Dual2(m) => m.sort_keys(),
        }
    }
}

/// Custom Serialize for Nodes: always serializes as IndexMap<NaiveDate, f64> (strips AD state).
impl Serialize for Nodes {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let map: IndexMap<NaiveDate, f64> = self.keys()
            .into_iter()
            .zip(self.get_values_f64())
            .collect();
        map.serialize(serializer)
    }
}

/// Custom Deserialize for Nodes: always deserializes as Nodes::F64.
impl<'de> Deserialize<'de> for Nodes {
    fn deserialize<D: Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        let map: IndexMap<NaiveDate, f64> = IndexMap::deserialize(deserializer)?;
        Ok(Nodes::F64(map))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    #[test]
    fn test_from_f64_map() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
        ]);
        let nodes = Nodes::from_f64_map(map);
        assert_eq!(nodes.len(), 2);
    }

    #[test]
    fn test_keys_as_f64() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
        ]);
        let nodes = Nodes::from_f64_map(map);
        let keys = nodes.keys_as_f64();
        assert_eq!(keys.len(), 2);
        assert_eq!(keys[0], ymd(2024, 1, 1).num_days_from_ce() as f64);
        assert_eq!(keys[1], ymd(2025, 1, 1).num_days_from_ce() as f64);
    }

    #[test]
    fn test_get_value_at_index() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
        ]);
        let nodes = Nodes::from_f64_map(map);
        assert_eq!(nodes.get_value_at_index(0), Number::F64(1.0));
        assert_eq!(nodes.get_value_at_index(1), Number::F64(0.98));
    }

    #[test]
    fn test_first_last_key() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
        ]);
        let nodes = Nodes::from_f64_map(map);
        assert_eq!(nodes.first_key(), ymd(2024, 1, 1));
        assert_eq!(nodes.last_key(), ymd(2025, 1, 1));
    }

    #[test]
    fn test_ensure_first_df_one_already_one() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
        ]);
        let mut nodes = Nodes::from_f64_map(map);
        assert!(!nodes.ensure_first_df_one());
        assert_eq!(nodes.len(), 2);
    }

    #[test]
    fn test_ensure_first_df_one_inserts() {
        let map = IndexMap::from_iter(vec![
            (ymd(2025, 1, 1), 0.98),
            (ymd(2026, 1, 1), 0.96),
        ]);
        let mut nodes = Nodes::from_f64_map(map);
        // First value is 0.98, not 1.0, so it should insert 1.0 at that date
        assert!(nodes.ensure_first_df_one());
        // The first value should now be 1.0
        assert_eq!(nodes.get_value_at_index(0), Number::F64(1.0));
    }

    #[test]
    fn test_get_values_f64() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]);
        let nodes = Nodes::from_f64_map(map);
        let vals = nodes.get_values_f64();
        assert_eq!(vals, vec![1.0, 0.97, 0.94]);
    }

    #[test]
    fn test_get_values_f64_from_dual() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.97);
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]);
        let nodes = Nodes::from_dual_map(map);
        let vals = nodes.get_values_f64();
        assert_eq!(vals, vec![1.0, 0.97]);
    }

    #[test]
    fn test_keys() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
        ]);
        let nodes = Nodes::from_f64_map(map);
        let keys = nodes.keys();
        assert_eq!(keys, vec![ymd(2024, 1, 1), ymd(2025, 1, 1)]);
    }

    #[test]
    fn test_set_values_as_dual() {
        use indexmap::IndexSet;
        use std::sync::Arc;

        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]);
        let mut nodes = Nodes::from_f64_map(map);
        let var_names = Arc::new(IndexSet::from_iter(vec![
            "v0".to_string(),
            "v1".to_string(),
        ]));
        // ini_solve=1 means first node is constant (DF=1.0), next 2 are AD variables
        nodes.set_values_as_dual(&[1.0, 0.97, 0.94], var_names, 1);

        // Check it's now Dual variant
        if let Nodes::Dual(m) = &nodes {
            assert_eq!(m.len(), 3);
            // First node: constant (zero derivatives)
            let first = m.get_index(0).unwrap().1;
            assert_eq!(first.real(), 1.0);
            assert_eq!(first.dual[0], 0.0);
            assert_eq!(first.dual[1], 0.0);
            // Second node: AD var at index 0
            let second = m.get_index(1).unwrap().1;
            assert_eq!(second.real(), 0.97);
            assert_eq!(second.dual[0], 1.0);
            assert_eq!(second.dual[1], 0.0);
            // Third node: AD var at index 1
            let third = m.get_index(2).unwrap().1;
            assert_eq!(third.real(), 0.94);
            assert_eq!(third.dual[0], 0.0);
            assert_eq!(third.dual[1], 1.0);
        } else {
            panic!("Expected Dual variant");
        }
    }

    #[test]
    fn test_set_values_as_f64() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.97);
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]);
        let mut nodes = Nodes::from_dual_map(map);
        nodes.set_values_as_f64(&[1.0, 0.95]);

        if let Nodes::F64(m) = &nodes {
            assert_eq!(m.len(), 2);
            assert_eq!(*m.get_index(0).unwrap().1, 1.0);
            assert_eq!(*m.get_index(1).unwrap().1, 0.95);
        } else {
            panic!("Expected F64 variant");
        }
    }

    #[test]
    fn test_dual_nodes() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v0", 0.98);
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]);
        let nodes = Nodes::from_dual_map(map);
        assert_eq!(nodes.len(), 2);
        if let Number::Dual(d) = nodes.get_value_at_index(0) {
            assert_eq!(d.real(), 1.0);
        } else {
            panic!("Expected Dual");
        }
    }

    #[test]
    fn test_serde_nodes_f64_roundtrip() {
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
        ]);
        let nodes = Nodes::from_f64_map(map);
        let json = serde_json::to_string(&nodes).unwrap();
        let restored: Nodes = serde_json::from_str(&json).unwrap();
        assert_eq!(restored.len(), 2);
        assert_eq!(restored.get_values_f64(), vec![1.0, 0.97]);
        assert_eq!(restored.keys(), vec![ymd(2024, 1, 1), ymd(2025, 1, 1)]);
    }

    #[test]
    fn test_serde_nodes_dual_strips_ad() {
        let d1 = Dual::new("v0", 1.0);
        let d2 = Dual::new("v1", 0.97);
        let map = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), d1),
            (ymd(2025, 1, 1), d2),
        ]);
        let nodes = Nodes::from_dual_map(map);
        let json = serde_json::to_string(&nodes).unwrap();
        let restored: Nodes = serde_json::from_str(&json).unwrap();
        // Should always deserialize as F64
        assert_eq!(restored.get_values_f64(), vec![1.0, 0.97]);
        // Verify it's F64 variant
        if let Nodes::F64(_) = &restored {
            // OK
        } else {
            panic!("Expected Nodes::F64 after deserialization");
        }
    }
}
