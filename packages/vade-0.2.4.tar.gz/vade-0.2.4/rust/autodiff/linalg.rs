use crate::autodiff::dual::{Dual, Dual2};

/// Solve the linear system Ax = b via Gaussian elimination with partial pivoting.
/// Specialized for f64.
pub fn dsolve_f64(a: &[Vec<f64>], b: &[f64]) -> Vec<f64> {
    let n = b.len();
    assert_eq!(a.len(), n, "Matrix must be square");

    let mut aug: Vec<Vec<f64>> = Vec::with_capacity(n);
    for i in 0..n {
        let mut row = a[i].clone();
        row.push(b[i]);
        aug.push(row);
    }

    // Forward elimination with partial pivoting
    for col in 0..n {
        // Partial pivoting: find row with largest absolute value in column
        let mut pivot_row = col;
        let mut max_val = aug[col][col].abs();
        for row in (col + 1)..n {
            let val = aug[row][col].abs();
            if val > max_val {
                max_val = val;
                pivot_row = row;
            }
        }
        if pivot_row != col {
            aug.swap(pivot_row, col);
        }

        // Eliminate below
        for row in (col + 1)..n {
            let factor = aug[row][col] / aug[col][col];
            for j in col..=n {
                aug[row][j] = aug[row][j] - aug[col][j] * factor;
            }
        }
    }

    // Back substitution
    let mut x = vec![0.0_f64; n];
    for i in (0..n).rev() {
        let mut sum = aug[i][n];
        for j in (i + 1)..n {
            sum -= aug[i][j] * x[j];
        }
        x[i] = sum / aug[i][i];
    }
    x
}

/// Solve the linear system Ax = b via Gaussian elimination.
/// Specialized for Dual elements, propagating first-order derivatives.
#[allow(dead_code)]
pub fn dsolve(a: &[Vec<Dual>], b: &[Dual]) -> Vec<Dual> {
    let n = b.len();
    assert_eq!(a.len(), n, "Matrix must be square");

    let mut aug: Vec<Vec<Dual>> = Vec::with_capacity(n);
    for i in 0..n {
        let mut row = a[i].clone();
        row.push(b[i].clone());
        aug.push(row);
    }

    // Forward elimination (no pivoting for Dual -- compare by real value)
    for col in 0..n {
        let mut pivot_row = col;
        let mut max_val = aug[col][col].real().abs();
        for row in (col + 1)..n {
            let val = aug[row][col].real().abs();
            if val > max_val {
                max_val = val;
                pivot_row = row;
            }
        }
        if pivot_row != col {
            aug.swap(pivot_row, col);
        }

        for row in (col + 1)..n {
            let factor = &aug[row][col] / &aug[col][col];
            for j in col..=n {
                let val = &aug[col][j] * &factor;
                aug[row][j] = &aug[row][j] - &val;
            }
        }
    }

    // Back substitution
    let mut x: Vec<Dual> = b.to_vec();
    for i in (0..n).rev() {
        let mut sum = aug[i][n].clone();
        for j in (i + 1)..n {
            let prod = &aug[i][j] * &x[j];
            sum = &sum - &prod;
        }
        x[i] = &sum / &aug[i][i];
    }
    x
}

/// Solve the linear system Ax = b via Gaussian elimination.
/// Specialized for Dual2 elements, propagating first and second-order derivatives.
#[allow(dead_code)]
pub fn dsolve2(a: &[Vec<Dual2>], b: &[Dual2]) -> Vec<Dual2> {
    let n = b.len();
    assert_eq!(a.len(), n, "Matrix must be square");

    let mut aug: Vec<Vec<Dual2>> = Vec::with_capacity(n);
    for i in 0..n {
        let mut row = a[i].clone();
        row.push(b[i].clone());
        aug.push(row);
    }

    // Forward elimination
    for col in 0..n {
        let mut pivot_row = col;
        let mut max_val = aug[col][col].real().abs();
        for row in (col + 1)..n {
            let val = aug[row][col].real().abs();
            if val > max_val {
                max_val = val;
                pivot_row = row;
            }
        }
        if pivot_row != col {
            aug.swap(pivot_row, col);
        }

        for row in (col + 1)..n {
            let factor = &aug[row][col] / &aug[col][col];
            for j in col..=n {
                let val = &aug[col][j] * &factor;
                aug[row][j] = &aug[row][j] - &val;
            }
        }
    }

    // Back substitution
    let mut x: Vec<Dual2> = b.to_vec();
    for i in (0..n).rev() {
        let mut sum = aug[i][n].clone();
        for j in (i + 1)..n {
            let prod = &aug[i][j] * &x[j];
            sum = &sum - &prod;
        }
        x[i] = &sum / &aug[i][i];
    }
    x
}

/// Solve the linear system Ax = b where A is f64 and b is Dual.
/// The pivoting and elimination are purely f64; AD propagates through the RHS.
pub fn fdsolve(a: &[Vec<f64>], b: &[Dual]) -> Vec<Dual> {
    let n = b.len();
    assert_eq!(a.len(), n, "Matrix must be square");

    // Build augmented system: f64 matrix columns + Dual RHS column
    let mut a_aug: Vec<Vec<f64>> = a.to_vec();
    let mut b_aug: Vec<Dual> = b.to_vec();

    // Forward elimination with partial pivoting
    for col in 0..n {
        // Partial pivoting
        let mut pivot_row = col;
        let mut max_val = a_aug[col][col].abs();
        for row in (col + 1)..n {
            let val = a_aug[row][col].abs();
            if val > max_val {
                max_val = val;
                pivot_row = row;
            }
        }
        if pivot_row != col {
            a_aug.swap(pivot_row, col);
            b_aug.swap(pivot_row, col);
        }

        // Eliminate below
        for row in (col + 1)..n {
            let factor = a_aug[row][col] / a_aug[col][col];
            for j in col..n {
                a_aug[row][j] -= a_aug[col][j] * factor;
            }
            // b_aug[row] = b_aug[row] - factor * b_aug[col]
            let scaled = &b_aug[col] * &factor;
            b_aug[row] = &b_aug[row] - &scaled;
        }
    }

    // Back substitution
    let mut x: Vec<Dual> = b_aug.clone();
    for i in (0..n).rev() {
        let mut sum = b_aug[i].clone();
        for j in (i + 1)..n {
            let scaled = &x[j] * &a_aug[i][j];
            sum = &sum - &scaled;
        }
        x[i] = &sum * &(1.0 / a_aug[i][i]);
    }
    x
}

/// Solve the linear system Ax = b where A is f64 and b is Dual2.
/// The pivoting and elimination are purely f64; AD propagates through the RHS.
pub fn fdsolve2(a: &[Vec<f64>], b: &[Dual2]) -> Vec<Dual2> {
    let n = b.len();
    assert_eq!(a.len(), n, "Matrix must be square");

    let mut a_aug: Vec<Vec<f64>> = a.to_vec();
    let mut b_aug: Vec<Dual2> = b.to_vec();

    // Forward elimination with partial pivoting
    for col in 0..n {
        let mut pivot_row = col;
        let mut max_val = a_aug[col][col].abs();
        for row in (col + 1)..n {
            let val = a_aug[row][col].abs();
            if val > max_val {
                max_val = val;
                pivot_row = row;
            }
        }
        if pivot_row != col {
            a_aug.swap(pivot_row, col);
            b_aug.swap(pivot_row, col);
        }

        for row in (col + 1)..n {
            let factor = a_aug[row][col] / a_aug[col][col];
            for j in col..n {
                a_aug[row][j] -= a_aug[col][j] * factor;
            }
            let scaled = &b_aug[col] * &factor;
            b_aug[row] = &b_aug[row] - &scaled;
        }
    }

    // Back substitution
    let mut x: Vec<Dual2> = b_aug.clone();
    for i in (0..n).rev() {
        let mut sum = b_aug[i].clone();
        for j in (i + 1)..n {
            let scaled = &x[j] * &a_aug[i][j];
            sum = &sum - &scaled;
        }
        x[i] = &sum * &(1.0 / a_aug[i][i]);
    }
    x
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::autodiff::dual::Vars;

    #[test]
    fn test_dsolve_f64_2x2() {
        // [2, 1] [x]   [5]
        // [1, 3] [y] = [7]
        // Solution: x=1.6, y=1.8
        let a = vec![vec![2.0, 1.0], vec![1.0, 3.0]];
        let b = vec![5.0, 7.0];
        let x = dsolve_f64(&a, &b);
        assert!((x[0] - 1.6).abs() < 1e-12);
        assert!((x[1] - 1.8).abs() < 1e-12);
    }

    #[test]
    fn test_dsolve_f64_3x3() {
        let a = vec![
            vec![1.0, 2.0, 3.0],
            vec![4.0, 5.0, 6.0],
            vec![7.0, 8.0, 0.0],
        ];
        let b = vec![14.0, 32.0, 23.0];
        let x = dsolve_f64(&a, &b);
        assert!((x[0] - 1.0).abs() < 1e-10);
        assert!((x[1] - 2.0).abs() < 1e-10);
        assert!((x[2] - 3.0).abs() < 1e-10);
    }

    #[test]
    fn test_dsolve_dual_diagonal() {
        // Diagonal system: A = [[2,0],[0,1]], b = [Dual(4), Dual(3)]
        let x_var = Dual::new("x", 4.0);
        let y_var = Dual::new("x", 3.0);
        let two = Dual::new_from(&x_var, 2.0);
        let one = Dual::new_from(&x_var, 1.0);
        let zero = Dual::new_from(&x_var, 0.0);

        let a = vec![
            vec![two.clone(), zero.clone()],
            vec![zero.clone(), one.clone()],
        ];
        let b = vec![x_var, y_var];
        let result = dsolve(&a, &b);

        assert!((result[0].real() - 2.0).abs() < 1e-12);
        assert!((result[1].real() - 3.0).abs() < 1e-12);
        assert!((result[0].dual[0] - 0.5).abs() < 1e-12);
        assert!((result[1].dual[0] - 1.0).abs() < 1e-12);
    }

    #[test]
    fn test_dsolve_dual_with_derivative_in_matrix() {
        // A = [[a, 0], [0, a]] where a=Dual("a",2), b = [6, 4] (constants)
        // x = [6/a, 4/a] = [3, 2]
        // dx/da = [-6/a^2, -4/a^2] = [-1.5, -1.0]
        let a_val = Dual::new("a", 2.0);
        let zero = Dual::new_from(&a_val, 0.0);
        let b1 = Dual::try_new(6.0, vec!["a".to_string()], vec![0.0]).unwrap();
        let b2 = Dual::try_new(4.0, vec!["a".to_string()], vec![0.0]).unwrap();

        let a_mat = vec![
            vec![a_val.clone(), zero.clone()],
            vec![zero.clone(), a_val.clone()],
        ];
        let b_vec = vec![b1, b2];
        let result = dsolve(&a_mat, &b_vec);

        assert!((result[0].real() - 3.0).abs() < 1e-12);
        assert!((result[1].real() - 2.0).abs() < 1e-12);
        assert!((result[0].dual[0] - (-1.5)).abs() < 1e-12);
        assert!((result[1].dual[0] - (-1.0)).abs() < 1e-12);
    }

    #[test]
    fn test_dsolve_dual_2x2_full() {
        // A = [[2, 1], [1, 3]], b = [5, 7]
        // Solution: x=1.6, y=1.8 (same as f64 test)
        // All constants so derivatives should be 0
        let template = Dual::new("z", 0.0);
        let a11 = Dual::new_from(&template, 2.0);
        let a12 = Dual::new_from(&template, 1.0);
        let a21 = Dual::new_from(&template, 1.0);
        let a22 = Dual::new_from(&template, 3.0);
        let b1 = Dual::new_from(&template, 5.0);
        let b2 = Dual::new_from(&template, 7.0);

        let a = vec![vec![a11, a12], vec![a21, a22]];
        let b = vec![b1, b2];
        let result = dsolve(&a, &b);

        assert!((result[0].real() - 1.6).abs() < 1e-12);
        assert!((result[1].real() - 1.8).abs() < 1e-12);
    }

    #[test]
    fn test_fdsolve_identity() {
        // Identity matrix * Dual vector = same Dual vector
        let a = vec![vec![1.0, 0.0], vec![0.0, 1.0]];
        let b1 = Dual::try_new(3.0, vec!["x".to_string()], vec![1.0]).unwrap();
        let b2 = Dual::try_new(7.0, vec!["x".to_string()], vec![0.0]).unwrap();
        let result = fdsolve(&a, &[b1, b2]);
        assert!((result[0].real() - 3.0).abs() < 1e-12);
        assert!((result[1].real() - 7.0).abs() < 1e-12);
        assert!((result[0].dual[0] - 1.0).abs() < 1e-12);
        assert!((result[1].dual[0] - 0.0).abs() < 1e-12);
    }

    #[test]
    fn test_fdsolve_2x2() {
        // A = [[2, 1], [1, 3]] (f64), b = [Dual(5, dx=1), Dual(7, dx=0)]
        // Solution real: x=1.6, y=1.8
        let b1 = Dual::try_new(5.0, vec!["x".to_string()], vec![1.0]).unwrap();
        let b2 = Dual::try_new(7.0, vec!["x".to_string()], vec![0.0]).unwrap();
        let a = vec![vec![2.0, 1.0], vec![1.0, 3.0]];
        let result = fdsolve(&a, &[b1, b2]);
        assert!((result[0].real() - 1.6).abs() < 1e-12);
        assert!((result[1].real() - 1.8).abs() < 1e-12);
        // dx/dx for the solution: A^{-1} * [1, 0]
        // A^{-1} = 1/5 * [[3, -1], [-1, 2]]
        // x_deriv = 3/5 = 0.6, y_deriv = -1/5 = -0.2
        assert!((result[0].dual[0] - 0.6).abs() < 1e-12);
        assert!((result[1].dual[0] - (-0.2)).abs() < 1e-12);
    }

    #[test]
    fn test_fdsolve2_identity() {
        let a = vec![vec![1.0, 0.0], vec![0.0, 1.0]];
        let b1 = Dual2::try_new(3.0, vec!["x".to_string()], vec![1.0], vec![0.0]).unwrap();
        let b2 = Dual2::try_new(7.0, vec!["x".to_string()], vec![0.0], vec![0.0]).unwrap();
        let result = fdsolve2(&a, &[b1, b2]);
        assert!((result[0].real() - 3.0).abs() < 1e-12);
        assert!((result[1].real() - 7.0).abs() < 1e-12);
        assert!((result[0].dual[0] - 1.0).abs() < 1e-12);
    }

    #[test]
    fn test_fdsolve2_2x2() {
        let b1 = Dual2::try_new(5.0, vec!["x".to_string()], vec![1.0], vec![0.0]).unwrap();
        let b2 = Dual2::try_new(7.0, vec!["x".to_string()], vec![0.0], vec![0.0]).unwrap();
        let a = vec![vec![2.0, 1.0], vec![1.0, 3.0]];
        let result = fdsolve2(&a, &[b1, b2]);
        assert!((result[0].real() - 1.6).abs() < 1e-12);
        assert!((result[1].real() - 1.8).abs() < 1e-12);
        assert!((result[0].dual[0] - 0.6).abs() < 1e-12);
        assert!((result[1].dual[0] - (-0.2)).abs() < 1e-12);
    }
}
