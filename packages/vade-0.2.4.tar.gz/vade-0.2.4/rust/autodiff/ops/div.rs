use crate::autodiff::dual::{Dual, Dual2, Vars, VarsRelationship};
use auto_ops::impl_op_ex;
use std::sync::Arc;

// Div Dual / f64
impl_op_ex!(/ |a: &Dual, b: &f64| -> Dual {
    Dual { vars: Arc::clone(&a.vars), real: a.real / b, dual: (1.0_f64 / b) * &a.dual }
});

// Div f64 / Dual: a/b = a * (1/b), d/dx(a/b) = -a / b^2
impl_op_ex!(/ |a: &f64, b: &Dual| -> Dual {
    let inv_b = 1.0 / b.real;
    let inv_b2 = inv_b * inv_b;
    Dual {
        vars: Arc::clone(&b.vars),
        real: a * inv_b,
        dual: (-a * inv_b2) * &b.dual,
    }
});

// Div Dual2 / f64
impl_op_ex!(/ |a: &Dual2, b: &f64| -> Dual2 {
    let inv = 1.0_f64 / b;
    Dual2 { vars: Arc::clone(&a.vars), real: a.real * inv, dual: inv * &a.dual, dual2: inv * &a.dual2 }
});

// Div f64 / Dual2: implement via multiplication by inverse
// d/dx(a/b) = -a/b^2 * db/dx
// d2/dxdy(a/b) = 2a/b^3 * db/dx * db/dy - a/b^2 * d2b/dxdy
impl_op_ex!(/ |a: &f64, b: &Dual2| -> Dual2 {
    let inv_b = 1.0 / b.real;
    let inv_b2 = inv_b * inv_b;
    let inv_b3 = inv_b2 * inv_b;
    let real = a * inv_b;
    let dual = (-a * inv_b2) * &b.dual;
    // dual2: a * (2/b^3 * outer(db, db) - 1/b^2 * d2b)
    // In half-Hessian convention: store 0.5 * second derivative
    // d2(a/b)/dxdy = 2a/b^3 * db/dx * db/dy - a/b^2 * d2b/dxdy
    // Half of that: a/b^3 * db/dx * db/dy - 0.5*a/b^2 * d2b/dxdy
    // But dual2 in b stores 0.5 * d2b/dxdy, so:
    // half_hessian = a/b^3 * outer(db, db) - a*inv_b2 * b.dual2
    // Wait, let's be precise. b.dual2 stores 0.5 * d2b/dxdy.
    // We want to store 0.5 * d2(a/b)/dxdy.
    // d2(a/b)/dxdy = 2a/b^3 * db_dx * db_dy - a/b^2 * d2b/dxdy
    // 0.5 * d2(a/b)/dxdy = a/b^3 * db_dx * db_dy - 0.5 * a/b^2 * d2b/dxdy
    // = a*inv_b3 * outer(b.dual, b.dual) - a*inv_b2 * b.dual2
    use crate::autodiff::ops::mul::outer;
    let cross = outer(&b.dual.view(), &b.dual.view());
    let dual2 = a * inv_b3 * &cross - a * inv_b2 * &b.dual2;
    Dual2 {
        vars: Arc::clone(&b.vars),
        real,
        dual,
        dual2,
    }
});

// Div Dual / Dual: quotient rule
// a/b = a * (1/b)
// d(a/b) = (da * b - a * db) / b^2
impl_op_ex!(/ |a: &Dual, b: &Dual| -> Dual {
    let state = a.vars_cmp(b.vars());
    match state {
        VarsRelationship::ArcEquivalent | VarsRelationship::ValueEquivalent => {
            let inv_b2 = 1.0 / (b.real * b.real);
            Dual {
                real: a.real / b.real,
                dual: (&a.dual * b.real - &b.dual * a.real) * inv_b2,
                vars: Arc::clone(&a.vars),
            }
        }
        _ => {
            let (x, y) = a.to_union_vars(b, Some(state));
            let inv_b2 = 1.0 / (y.real * y.real);
            Dual {
                real: x.real / y.real,
                dual: (&x.dual * y.real - &y.dual * x.real) * inv_b2,
                vars: Arc::clone(&x.vars),
            }
        }
    }
});

// Div Dual2 / Dual2: implement via multiplication by inverse
// To get this right with second derivatives, use a * (1/b)
// where 1/b is computed with proper second derivatives
impl_op_ex!(/ |a: &Dual2, b: &Dual2| -> Dual2 {
    // Compute 1/b as a Dual2
    let inv_b = 1.0_f64 / b;
    a * &inv_b
});

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_div_f64() {
        let d = Dual::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0]).unwrap();
        let result = d / 2.0;
        let expected = Dual::try_new(0.5, vec!["v0".to_string(), "v1".to_string()], vec![0.5, 1.0]).unwrap();
        assert_eq!(result, expected);
    }

    #[test]
    fn test_f64_div_dual() {
        let d = Dual::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0]).unwrap();
        let result = 2.0 / d.clone();
        let expected = Dual::new_multi(2.0, vec![]) / d;
        assert_eq!(result, expected);
    }

    #[test]
    fn test_div_different_vars() {
        let d1 = Dual::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0]).unwrap();
        let d2 = Dual::try_new(2.0, vec!["v0".to_string(), "v2".to_string()], vec![0.0, 3.0]).unwrap();
        let expected = Dual::try_new(0.5, vec!["v0".to_string(), "v1".to_string(), "v2".to_string()], vec![0.5, 1.0, -0.75]).unwrap();
        let result = d1 / d2;
        assert_eq!(result, expected);
    }

    #[test]
    fn test_div_dual2() {
        let d1 = Dual2::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0], Vec::new()).unwrap();
        let d2 = Dual2::try_new(2.0, vec!["v0".to_string(), "v2".to_string()], vec![0.0, 3.0], Vec::new()).unwrap();
        let result = d1 / d2;
        let expected = Dual2::try_new(
            0.5,
            vec!["v0".to_string(), "v1".to_string(), "v2".to_string()],
            vec![0.5, 1.0, -0.75],
            vec![0., 0., -0.375, 0., 0., -0.75, -0.375, -0.75, 1.125],
        ).unwrap();
        assert_eq!(result, expected);
    }

    #[test]
    fn test_div_dual2_f64() {
        let d = Dual2::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0], Vec::new()).unwrap();
        let result = d / 2.0;
        let expected = Dual2::try_new(0.5, vec!["v0".to_string(), "v1".to_string()], vec![0.5, 1.0], Vec::new()).unwrap();
        assert_eq!(result, expected);
    }
}
