use crate::autodiff::dual::{Dual, Dual2};
use std::ops::Neg;
use std::sync::Arc;

impl Neg for Dual {
    type Output = Dual;
    fn neg(self) -> Dual {
        Dual {
            real: -self.real,
            vars: Arc::clone(&self.vars),
            dual: -self.dual,
        }
    }
}

impl Neg for &Dual {
    type Output = Dual;
    fn neg(self) -> Dual {
        Dual {
            real: -self.real,
            vars: Arc::clone(&self.vars),
            dual: -(&self.dual),
        }
    }
}

impl Neg for Dual2 {
    type Output = Dual2;
    fn neg(self) -> Dual2 {
        Dual2 {
            real: -self.real,
            vars: Arc::clone(&self.vars),
            dual: -self.dual,
            dual2: -self.dual2,
        }
    }
}

impl Neg for &Dual2 {
    type Output = Dual2;
    fn neg(self) -> Dual2 {
        Dual2 {
            real: -self.real,
            vars: Arc::clone(&self.vars),
            dual: -(&self.dual),
            dual2: -(&self.dual2),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_neg_dual() {
        let d = Dual::try_new(3.0, vec!["x".to_string()], vec![2.0]).unwrap();
        let result = -d;
        assert_eq!(result.real, -3.0);
        assert_eq!(result.dual, ndarray::Array1::from_vec(vec![-2.0]));
    }

    #[test]
    fn test_neg_dual_ref() {
        let d = Dual::try_new(3.0, vec!["x".to_string()], vec![2.0]).unwrap();
        let result = -&d;
        assert_eq!(result.real, -3.0);
        assert_eq!(d.real, 3.0); // original unchanged
    }

    #[test]
    fn test_neg_dual2() {
        let d = Dual2::try_new(3.0, vec!["x".to_string()], vec![2.0], vec![1.0]).unwrap();
        let result = -d;
        assert_eq!(result.real, -3.0);
        assert_eq!(result.dual, ndarray::Array1::from_vec(vec![-2.0]));
        assert_eq!(result.dual2, ndarray::Array2::from_elem((1,1), -1.0));
    }
}
