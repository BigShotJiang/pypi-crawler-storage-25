use crate::autodiff::dual::{Dual, Dual2};
use crate::autodiff::enums::Number;
use crate::autodiff::ops::mul::outer;
use num_traits::Pow;
use statrs::distribution::{ContinuousCDF, Normal};
use std::f64::consts::PI;
use std::sync::Arc;

/// Functions for common mathematical operations.
#[allow(dead_code)]
pub trait MathFuncs {
    /// Return the exponential of a value.
    fn exp(&self) -> Self;
    /// Return the natural logarithm of a value.
    fn log(&self) -> Self;
    /// Return the standard normal cumulative distribution function of a value.
    fn norm_cdf(&self) -> Self;
    /// Return the inverse standard normal cumulative distribution function of a value.
    fn inv_norm_cdf(&self) -> Self;
}

impl MathFuncs for f64 {
    fn exp(&self) -> Self {
        f64::exp(*self)
    }
    fn log(&self) -> Self {
        f64::ln(*self)
    }
    fn norm_cdf(&self) -> Self {
        Normal::new(0.0, 1.0).unwrap().cdf(*self)
    }
    fn inv_norm_cdf(&self) -> Self {
        Normal::new(0.0, 1.0).unwrap().inverse_cdf(*self)
    }
}

impl MathFuncs for Dual {
    fn exp(&self) -> Self {
        let c = self.real.exp();
        Dual {
            real: c,
            vars: Arc::clone(&self.vars),
            dual: c * &self.dual,
        }
    }
    fn log(&self) -> Self {
        Dual {
            real: self.real.ln(),
            vars: Arc::clone(&self.vars),
            dual: (1.0 / self.real) * &self.dual,
        }
    }
    fn norm_cdf(&self) -> Self {
        let n = Normal::new(0.0, 1.0).unwrap();
        let base = n.cdf(self.real);
        let scalar = 1.0 / (2.0 * PI).sqrt() * (-0.5_f64 * self.real.pow(2.0_f64)).exp();
        Dual {
            real: base,
            vars: Arc::clone(&self.vars),
            dual: scalar * &self.dual,
        }
    }
    fn inv_norm_cdf(&self) -> Self {
        let n = Normal::new(0.0, 1.0).unwrap();
        let base = n.inverse_cdf(self.real);
        let scalar = (2.0 * PI).sqrt() * (0.5_f64 * base.pow(2.0_f64)).exp();
        Dual {
            real: base,
            vars: Arc::clone(&self.vars),
            dual: scalar * &self.dual,
        }
    }
}

impl MathFuncs for Dual2 {
    fn exp(&self) -> Self {
        let c = self.real.exp();
        let cross = outer(&self.dual.view(), &self.dual.view());
        Dual2 {
            real: c,
            vars: Arc::clone(&self.vars),
            dual: c * &self.dual,
            dual2: c * (&self.dual2 + 0.5 * &cross),
        }
    }
    fn log(&self) -> Self {
        let scalar = 1.0 / self.real;
        let cross = outer(&self.dual.view(), &self.dual.view());
        Dual2 {
            real: self.real.ln(),
            vars: Arc::clone(&self.vars),
            dual: scalar * &self.dual,
            dual2: scalar * &self.dual2 - 0.5 * (scalar * scalar) * &cross,
        }
    }
    fn norm_cdf(&self) -> Self {
        let n = Normal::new(0.0, 1.0).unwrap();
        let base = n.cdf(self.real);
        let scalar = 1.0 / (2.0 * PI).sqrt() * (-0.5_f64 * self.real.pow(2.0_f64)).exp();
        let scalar2 = scalar * -self.real;
        let cross = outer(&self.dual.view(), &self.dual.view());
        Dual2 {
            real: base,
            vars: Arc::clone(&self.vars),
            dual: scalar * &self.dual,
            dual2: scalar * &self.dual2 + 0.5 * scalar2 * &cross,
        }
    }
    fn inv_norm_cdf(&self) -> Self {
        let n = Normal::new(0.0, 1.0).unwrap();
        let base = n.inverse_cdf(self.real);
        let scalar = (2.0 * PI).sqrt() * (0.5_f64 * base.pow(2.0_f64)).exp();
        let scalar2 = scalar.pow(2.0_f64) * base;
        let cross = outer(&self.dual.view(), &self.dual.view());
        Dual2 {
            real: base,
            vars: Arc::clone(&self.vars),
            dual: scalar * &self.dual,
            dual2: scalar * &self.dual2 + 0.5 * scalar2 * &cross,
        }
    }
}

macro_rules! math_func {
    ($self:ident, $name:ident) => {
        match $self {
            Number::F64(f) => Number::F64(f.$name()),
            Number::Dual(d) => Number::Dual(d.$name()),
            Number::Dual2(d) => Number::Dual2(d.$name()),
        }
    };
}

impl MathFuncs for Number {
    fn exp(&self) -> Self {
        math_func!(self, exp)
    }
    fn log(&self) -> Self {
        math_func!(self, log)
    }
    fn norm_cdf(&self) -> Self {
        math_func!(self, norm_cdf)
    }
    fn inv_norm_cdf(&self) -> Self {
        math_func!(self, inv_norm_cdf)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_exp_dual() {
        let d = Dual::try_new(2.0, vec!["x".to_string()], vec![1.0]).unwrap();
        let result = d.exp();
        let e2 = 2.0_f64.exp();
        assert!((result.real - e2).abs() < 1e-12);
        assert!((result.dual[0] - e2).abs() < 1e-12);
    }

    #[test]
    fn test_log_dual() {
        let d = Dual::try_new(2.0, vec!["x".to_string()], vec![1.0]).unwrap();
        let result = d.log();
        assert!((result.real - 2.0_f64.ln()).abs() < 1e-12);
        assert!((result.dual[0] - 0.5).abs() < 1e-12);
    }

    #[test]
    fn test_exp_dual2() {
        let d = Dual2::try_new(
            1.0,
            vec!["v0".to_string(), "v1".to_string()],
            vec![1.0, 2.0],
            Vec::new(),
        )
        .unwrap();
        let result = d.exp();
        let c = 1.0_f64.exp();
        assert!((result.real - c).abs() < 1e-12);
        assert!((result.dual[0] - c).abs() < 1e-12);
        assert!((result.dual[1] - 2.0 * c).abs() < 1e-12);
        assert!((result.dual2[[0, 0]] - c * 0.5).abs() < 1e-12);
        assert!((result.dual2[[0, 1]] - c * 1.0).abs() < 1e-12);
        assert!((result.dual2[[1, 1]] - c * 2.0).abs() < 1e-12);
    }

    #[test]
    fn test_log_dual2() {
        let d = Dual2::try_new(
            1.0,
            vec!["v0".to_string(), "v1".to_string()],
            vec![1.0, 2.0],
            Vec::new(),
        )
        .unwrap();
        let result = d.log();
        assert!((result.real - 0.0).abs() < 1e-12);
        assert!((result.dual[0] - 1.0).abs() < 1e-12);
        assert!((result.dual[1] - 2.0).abs() < 1e-12);
        assert!((result.dual2[[0, 0]] - (-0.5)).abs() < 1e-12);
        assert!((result.dual2[[0, 1]] - (-1.0)).abs() < 1e-12);
        assert!((result.dual2[[1, 1]] - (-2.0)).abs() < 1e-12);
    }

    #[test]
    fn test_norm_cdf_dual() {
        let d = Dual::try_new(0.0, vec!["x".to_string()], vec![1.0]).unwrap();
        let result = d.norm_cdf();
        assert!((result.real - 0.5).abs() < 1e-12);
        let expected_deriv = 1.0 / (2.0 * PI).sqrt();
        assert!((result.dual[0] - expected_deriv).abs() < 1e-12);
    }

    #[test]
    fn test_inv_norm_cdf_dual() {
        let d = Dual::try_new(0.5, vec!["x".to_string()], vec![1.0]).unwrap();
        let result = d.inv_norm_cdf();
        assert!((result.real - 0.0).abs() < 1e-12);
        let expected_deriv = (2.0 * PI).sqrt();
        assert!((result.dual[0] - expected_deriv).abs() < 1e-12);
    }

    #[test]
    fn test_norm_cdf_dual2() {
        let d = Dual2::try_new(0.0, vec!["x".to_string()], vec![1.0], Vec::new()).unwrap();
        let result = d.norm_cdf();
        assert!((result.real - 0.5).abs() < 1e-12);
        let pdf_0 = 1.0 / (2.0 * PI).sqrt();
        assert!((result.dual[0] - pdf_0).abs() < 1e-12);
        // At x=0: pdf'(0) = -0*pdf(0) = 0, so half-hessian = 0
        assert!((result.dual2[[0, 0]]).abs() < 1e-12);
    }

    #[test]
    fn test_mathfuncs_f64() {
        assert!((2.0_f64.exp() - std::f64::consts::E * std::f64::consts::E).abs() < 1e-12);
        assert!((MathFuncs::log(&1.0_f64) - 0.0).abs() < 1e-12);
        assert!((MathFuncs::norm_cdf(&0.0_f64) - 0.5).abs() < 1e-12);
        assert!((MathFuncs::inv_norm_cdf(&0.5_f64)).abs() < 1e-12);
    }

    #[test]
    fn test_mathfuncs_number() {
        let n = Number::Dual(Dual::new("x", 1.0));
        let result = n.exp();
        if let Number::Dual(d) = result {
            assert!((d.real - 1.0_f64.exp()).abs() < 1e-12);
        } else {
            panic!("Expected Dual");
        }
    }

    #[test]
    fn test_exp_preserves_arc() {
        let d = Dual::new("x", 2.0);
        let result = d.exp();
        assert!(Arc::ptr_eq(&d.vars, &result.vars));
    }

    #[test]
    fn test_log_preserves_arc() {
        let d = Dual::new("x", 2.0);
        let result = d.log();
        assert!(Arc::ptr_eq(&d.vars, &result.vars));
    }
}
