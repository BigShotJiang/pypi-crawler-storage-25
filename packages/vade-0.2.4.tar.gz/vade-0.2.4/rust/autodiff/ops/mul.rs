use crate::autodiff::dual::{Dual, Dual2, Vars, VarsRelationship};
use auto_ops::{impl_op_ex, impl_op_ex_commutative};
use itertools::Itertools;
use ndarray::{Array1, Array2};
use std::sync::Arc;

/// Outer product of two 1D arrays: result[i,j] = a[i] * b[j]
pub fn outer(a: &ndarray::ArrayView1<f64>, b: &ndarray::ArrayView1<f64>) -> Array2<f64> {
    let n = a.len();
    let m = b.len();
    Array1::from_vec(
        a.iter()
            .cartesian_product(b.iter())
            .map(|(x, y)| x * y)
            .collect(),
    )
    .into_shape_with_order((n, m))
    .expect("Reshape of outer product failed")
}

// Mul Dual * f64
impl_op_ex_commutative!(*|a: &Dual, b: &f64| -> Dual {
    Dual { vars: Arc::clone(&a.vars), real: a.real * b, dual: *b * &a.dual }
});

// Mul Dual2 * f64
impl_op_ex_commutative!(*|a: &Dual2, b: &f64| -> Dual2 {
    Dual2 { vars: Arc::clone(&a.vars), real: a.real * b, dual: *b * &a.dual, dual2: *b * &a.dual2 }
});

// Mul Dual * Dual (product rule)
impl_op_ex!(*|a: &Dual, b: &Dual| -> Dual {
    let state = a.vars_cmp(b.vars());
    match state {
        VarsRelationship::ArcEquivalent | VarsRelationship::ValueEquivalent => Dual {
            real: a.real * b.real,
            dual: &a.dual * b.real + &b.dual * a.real,
            vars: Arc::clone(&a.vars),
        },
        _ => {
            let (x, y) = a.to_union_vars(b, Some(state));
            Dual {
                real: x.real * y.real,
                dual: &x.dual * y.real + &y.dual * x.real,
                vars: Arc::clone(&x.vars),
            }
        }
    }
});

// Mul Dual2 * Dual2 (second-order product rule)
impl_op_ex!(*|a: &Dual2, b: &Dual2| -> Dual2 {
    let state = a.vars_cmp(b.vars());
    match state {
        VarsRelationship::ArcEquivalent | VarsRelationship::ValueEquivalent => {
            let mut dual2: Array2<f64> = &a.dual2 * b.real + &b.dual2 * a.real;
            let cross = outer(&a.dual.view(), &b.dual.view());
            dual2 = dual2 + 0.5_f64 * (&cross + &cross.t());
            Dual2 {
                real: a.real * b.real,
                dual: &a.dual * b.real + &b.dual * a.real,
                vars: Arc::clone(&a.vars),
                dual2,
            }
        }
        _ => {
            let (x, y) = a.to_union_vars(b, Some(state));
            let mut dual2: Array2<f64> = &x.dual2 * y.real + &y.dual2 * x.real;
            let cross = outer(&x.dual.view(), &y.dual.view());
            dual2 = dual2 + 0.5_f64 * (&cross + &cross.t());
            Dual2 {
                real: x.real * y.real,
                dual: &x.dual * y.real + &y.dual * x.real,
                vars: Arc::clone(&x.vars),
                dual2,
            }
        }
    }
});

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mul_f64() {
        let d = Dual::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0]).unwrap();
        let result = 10.0 * d * 2.0;
        let expected = Dual::try_new(20.0, vec!["v0".to_string(), "v1".to_string()], vec![20.0, 40.0]).unwrap();
        assert_eq!(result, expected);
    }

    #[test]
    fn test_mul_product_rule() {
        // f(x) = x * x at x=3: real = 9, dual = 6 (2x)
        let x = Dual::new("x", 3.0);
        let result = &x * &x;
        assert_eq!(result.real, 9.0);
        assert_eq!(result.dual, ndarray::Array1::from_vec(vec![6.0]));
    }

    #[test]
    fn test_mul_different_vars() {
        let d1 = Dual::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0]).unwrap();
        let d2 = Dual::try_new(2.0, vec!["v0".to_string(), "v2".to_string()], vec![0.0, 3.0]).unwrap();
        let expected = Dual::try_new(2.0, vec!["v0".to_string(), "v1".to_string(), "v2".to_string()], vec![2.0, 4.0, 3.0]).unwrap();
        let result = d1 * d2;
        assert_eq!(result, expected);
    }

    #[test]
    fn test_mul_dual2() {
        let d1 = Dual2::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0], Vec::new()).unwrap();
        let d2 = Dual2::try_new(2.0, vec!["v0".to_string(), "v2".to_string()], vec![0.0, 3.0], Vec::new()).unwrap();
        let expected = Dual2::try_new(
            2.0,
            vec!["v0".to_string(), "v1".to_string(), "v2".to_string()],
            vec![2.0, 4.0, 3.0],
            vec![0., 0., 1.5, 0., 0., 3., 1.5, 3., 0.],
        ).unwrap();
        let result = d1 * d2;
        assert_eq!(result, expected);
    }

    #[test]
    fn test_mul_dual2_f64() {
        let d = Dual2::try_new(1.0, vec!["v0".to_string(), "v1".to_string()], vec![1.0, 2.0], Vec::new()).unwrap();
        let result = 10.0 * d * 2.0;
        let expected = Dual2::try_new(20.0, vec!["v0".to_string(), "v1".to_string()], vec![20.0, 40.0], Vec::new()).unwrap();
        assert_eq!(result, expected);
    }
}
