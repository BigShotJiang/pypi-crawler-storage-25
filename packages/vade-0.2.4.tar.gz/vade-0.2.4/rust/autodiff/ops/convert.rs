use crate::autodiff::dual::{Dual, Dual2, Vars};
use crate::autodiff::enums::Number;
use indexmap::IndexSet;
use ndarray::{Array1, Array2};
use std::sync::Arc;

/// Extract the real (f64) value from any Number type.
#[allow(dead_code)]
pub fn set_order_0(x: &Number) -> f64 {
    match x {
        Number::F64(f) => *f,
        Number::Dual(d) => d.real(),
        Number::Dual2(d) => d.real(),
    }
}

/// Convert any Number type to a Dual (first-order).
#[allow(dead_code)]
pub fn set_order_1(x: &Number, vars: Vec<String>) -> Dual {
    match x {
        Number::F64(f) => {
            let arc_vars = Arc::new(IndexSet::from_iter(vars));
            let len = arc_vars.len();
            Dual {
                real: *f,
                vars: arc_vars,
                dual: Array1::zeros(len),
            }
        }
        Number::Dual(d) => d.clone(),
        Number::Dual2(d) => Dual {
            real: d.real(),
            vars: Arc::clone(d.vars()),
            dual: d.dual.clone(),
        },
    }
}

/// Convert any Number type to a Dual2 (second-order).
#[allow(dead_code)]
pub fn set_order_2(x: &Number, vars: Vec<String>) -> Dual2 {
    match x {
        Number::F64(f) => {
            let arc_vars = Arc::new(IndexSet::from_iter(vars));
            let len = arc_vars.len();
            Dual2 {
                real: *f,
                vars: arc_vars,
                dual: Array1::zeros(len),
                dual2: Array2::zeros((len, len)),
            }
        }
        Number::Dual(d) => {
            let len = d.vars().len();
            Dual2 {
                real: d.real(),
                vars: Arc::clone(d.vars()),
                dual: d.dual.clone(),
                dual2: Array2::zeros((len, len)),
            }
        }
        Number::Dual2(d) => d.clone(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_set_order_0_f64() {
        assert_eq!(set_order_0(&Number::F64(3.14)), 3.14);
    }

    #[test]
    fn test_set_order_0_dual() {
        let d = Dual::new("x", 2.5);
        assert_eq!(set_order_0(&Number::Dual(d)), 2.5);
    }

    #[test]
    fn test_set_order_0_dual2() {
        let d = Dual2::new("x", 7.0);
        assert_eq!(set_order_0(&Number::Dual2(d)), 7.0);
    }

    #[test]
    fn test_set_order_1_from_f64() {
        let result = set_order_1(&Number::F64(5.0), vec!["x".to_string(), "y".to_string()]);
        assert_eq!(result.real(), 5.0);
        assert_eq!(result.dual, Array1::<f64>::zeros(2));
        assert_eq!(result.vars().len(), 2);
    }

    #[test]
    fn test_set_order_1_from_dual() {
        let d = Dual::new("x", 3.0);
        let result = set_order_1(&Number::Dual(d.clone()), vec![]);
        assert_eq!(result, d);
    }

    #[test]
    fn test_set_order_1_from_dual2() {
        let d2 = Dual2::try_new(3.0, vec!["x".to_string()], vec![1.0], vec![0.5]).unwrap();
        let result = set_order_1(&Number::Dual2(d2), vec![]);
        assert_eq!(result.real(), 3.0);
        assert_eq!(result.dual, Array1::from_vec(vec![1.0]));
    }

    #[test]
    fn test_set_order_2_from_f64() {
        let result = set_order_2(&Number::F64(5.0), vec!["x".to_string()]);
        assert_eq!(result.real(), 5.0);
        assert_eq!(result.dual, Array1::<f64>::zeros(1));
        assert_eq!(result.dual2, Array2::<f64>::zeros((1, 1)));
    }

    #[test]
    fn test_set_order_2_from_dual() {
        let d = Dual::new("x", 3.0);
        let result = set_order_2(&Number::Dual(d), vec![]);
        assert_eq!(result.real(), 3.0);
        assert_eq!(result.dual, Array1::from_vec(vec![1.0]));
        assert_eq!(result.dual2, Array2::<f64>::zeros((1, 1)));
    }

    #[test]
    fn test_set_order_2_from_dual2() {
        let d2 = Dual2::new("x", 7.0);
        let result = set_order_2(&Number::Dual2(d2.clone()), vec![]);
        assert_eq!(result, d2);
    }
}
