use crate::autodiff::dual::{Dual, Dual2};
use crate::autodiff::ops::mul::outer;
use num_traits::Pow;
use std::sync::Arc;

// Pow Dual ^ f64
impl Pow<f64> for &Dual {
    type Output = Dual;
    fn pow(self, exp: f64) -> Dual {
        let real = self.real.powf(exp);
        let scalar = exp * self.real.powf(exp - 1.0);
        Dual {
            real,
            vars: Arc::clone(&self.vars),
            dual: scalar * &self.dual,
        }
    }
}

impl Pow<f64> for Dual {
    type Output = Dual;
    fn pow(self, exp: f64) -> Dual {
        (&self).pow(exp)
    }
}

// Pow Dual2 ^ f64
impl Pow<f64> for &Dual2 {
    type Output = Dual2;
    fn pow(self, exp: f64) -> Dual2 {
        let real = self.real.powf(exp);
        let scalar1 = exp * self.real.powf(exp - 1.0);
        let scalar2 = exp * (exp - 1.0) * self.real.powf(exp - 2.0);
        let cross = outer(&self.dual.view(), &self.dual.view());
        Dual2 {
            real,
            vars: Arc::clone(&self.vars),
            dual: scalar1 * &self.dual,
            dual2: scalar1 * &self.dual2 + 0.5 * scalar2 * &cross,
        }
    }
}

impl Pow<f64> for Dual2 {
    type Output = Dual2;
    fn pow(self, exp: f64) -> Dual2 {
        (&self).pow(exp)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_pow_dual_f64() {
        let x = Dual::new("x", 3.0);
        let result = x.pow(2.0);
        assert_eq!(result.real, 9.0);
        assert!((result.dual[0] - 6.0).abs() < 1e-12);
    }

    #[test]
    fn test_pow_dual_fractional() {
        let x = Dual::new("x", 4.0);
        let result = x.pow(0.5);
        assert!((result.real - 2.0).abs() < 1e-12);
        assert!((result.dual[0] - 0.25).abs() < 1e-12);
    }

    #[test]
    fn test_pow_dual2_f64() {
        let x = Dual2::new("x", 2.0);
        let result = x.pow(3.0);
        assert!((result.real - 8.0).abs() < 1e-12);
        assert!((result.dual[0] - 12.0).abs() < 1e-12);
        // Second derivative of x^3 is 6x = 12 at x=2. Half-Hessian stores 6.
        assert!((result.dual2[[0, 0]] - 6.0).abs() < 1e-12);
    }

    #[test]
    fn test_pow_dual_multi_var() {
        let d = Dual::try_new(5.0, vec!["x".to_string(), "y".to_string()], vec![1.0, 1.0]).unwrap();
        let result = d.pow(2.0);
        assert_eq!(result.real, 25.0);
        assert!((result.dual[0] - 10.0).abs() < 1e-12);
        assert!((result.dual[1] - 10.0).abs() < 1e-12);
    }
}
