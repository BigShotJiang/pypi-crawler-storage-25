use crate::autodiff::dual::{Dual, Dual2};
use crate::autodiff::ops::math_funcs::MathFuncs;
use num_traits::Pow;
use numpy::{IntoPyArray, PyArray1, PyArray2};
use pyo3::exceptions::PyTypeError;
use pyo3::prelude::*;

const CROSS_TYPE_ERR: &str = "Cannot mix Dual and Dual2 types";

#[derive(FromPyObject)]
#[allow(dead_code)]
enum DualOrFloat {
    D(Dual),
    D2(Dual2),
    F(f64),
}

#[derive(FromPyObject)]
#[allow(dead_code)]
enum Dual2OrFloat {
    D2(Dual2),
    D(Dual),
    F(f64),
}

macro_rules! dual_binop {
    ($self:ident, $other:ident, $op:tt) => {
        match $other {
            DualOrFloat::D(d) => Ok($self $op &d),
            DualOrFloat::D2(_) => Err(PyTypeError::new_err(CROSS_TYPE_ERR)),
            DualOrFloat::F(f) => Ok($self $op f),
        }
    };
}

macro_rules! dual_rbinop {
    ($self:ident, $other:ident, $op:tt) => {
        match $other {
            DualOrFloat::D(d) => Ok(&d $op $self),
            DualOrFloat::D2(_) => Err(PyTypeError::new_err(CROSS_TYPE_ERR)),
            DualOrFloat::F(f) => Ok(f $op $self),
        }
    };
}

macro_rules! dual2_binop {
    ($self:ident, $other:ident, $op:tt) => {
        match $other {
            Dual2OrFloat::D2(d) => Ok($self $op &d),
            Dual2OrFloat::D(_) => Err(PyTypeError::new_err(CROSS_TYPE_ERR)),
            Dual2OrFloat::F(f) => Ok($self $op f),
        }
    };
}

macro_rules! dual2_rbinop {
    ($self:ident, $other:ident, $op:tt) => {
        match $other {
            Dual2OrFloat::D2(d) => Ok(&d $op $self),
            Dual2OrFloat::D(_) => Err(PyTypeError::new_err(CROSS_TYPE_ERR)),
            Dual2OrFloat::F(f) => Ok(f $op $self),
        }
    };
}

// ---- Dual Python bindings ----

#[pymethods]
impl Dual {
    #[new]
    #[pyo3(signature = (var, real))]
    fn py_new(var: &str, real: f64) -> Self {
        Dual::new(var, real)
    }

    #[staticmethod]
    #[pyo3(signature = (real, vars, dual=None))]
    fn new_multi_py(real: f64, vars: Vec<String>, dual: Option<Vec<f64>>) -> PyResult<Self> {
        match dual {
            Some(d) => Dual::try_new(real, vars, d).map_err(|e| PyTypeError::new_err(e)),
            None => Ok(Dual::new_multi(real, vars)),
        }
    }

    #[getter]
    #[pyo3(name = "real")]
    fn py_real(&self) -> f64 {
        self.real
    }

    #[getter]
    #[pyo3(name = "vars")]
    fn py_vars(&self) -> Vec<String> {
        self.vars.iter().cloned().collect()
    }

    fn gradient<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        self.dual.clone().into_pyarray(py)
    }

    fn __add__(&self, other: DualOrFloat) -> PyResult<Self> {
        dual_binop!(self, other, +)
    }

    fn __radd__(&self, other: DualOrFloat) -> PyResult<Self> {
        self.__add__(other)
    }

    fn __sub__(&self, other: DualOrFloat) -> PyResult<Self> {
        dual_binop!(self, other, -)
    }

    fn __rsub__(&self, other: DualOrFloat) -> PyResult<Self> {
        dual_rbinop!(self, other, -)
    }

    fn __mul__(&self, other: DualOrFloat) -> PyResult<Self> {
        dual_binop!(self, other, *)
    }

    fn __rmul__(&self, other: DualOrFloat) -> PyResult<Self> {
        self.__mul__(other)
    }

    fn __truediv__(&self, other: DualOrFloat) -> PyResult<Self> {
        dual_binop!(self, other, /)
    }

    fn __rtruediv__(&self, other: DualOrFloat) -> PyResult<Self> {
        dual_rbinop!(self, other, /)
    }

    fn __neg__(&self) -> Self {
        -self
    }

    fn __pow__(&self, exp: f64, _modulo: Option<u32>) -> Self {
        Pow::pow(self, exp)
    }

    fn __float__(&self) -> f64 {
        self.real
    }

    fn __repr__(&self) -> String {
        let vars: Vec<String> = self.vars.iter().map(|v| format!("'{}'", v)).collect();
        let dual: Vec<String> = self.dual.iter().map(|d| format!("{}", d)).collect();
        format!(
            "Dual(real={}, vars=[{}], dual=[{}])",
            self.real,
            vars.join(", "),
            dual.join(", ")
        )
    }

    #[pyo3(name = "exp")]
    fn py_exp(&self) -> Self {
        MathFuncs::exp(self)
    }

    #[pyo3(name = "log")]
    fn py_log(&self) -> Self {
        MathFuncs::log(self)
    }
}

// ---- Dual2 Python bindings ----

#[pymethods]
impl Dual2 {
    #[new]
    #[pyo3(signature = (var, real))]
    fn py_new(var: &str, real: f64) -> Self {
        Dual2::new(var, real)
    }

    #[staticmethod]
    #[pyo3(signature = (real, vars, dual=None, dual2=None))]
    fn new_multi_py(
        real: f64,
        vars: Vec<String>,
        dual: Option<Vec<f64>>,
        dual2: Option<Vec<f64>>,
    ) -> PyResult<Self> {
        Dual2::try_new(
            real,
            vars,
            dual.unwrap_or_default(),
            dual2.unwrap_or_default(),
        )
        .map_err(|e| PyTypeError::new_err(e))
    }

    #[getter]
    #[pyo3(name = "real")]
    fn py_real(&self) -> f64 {
        self.real
    }

    #[getter]
    #[pyo3(name = "vars")]
    fn py_vars(&self) -> Vec<String> {
        self.vars.iter().cloned().collect()
    }

    fn gradient<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        self.dual.clone().into_pyarray(py)
    }

    fn gradient2<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<f64>> {
        let full_hessian = 2.0 * &self.dual2;
        full_hessian.into_pyarray(py)
    }

    fn __add__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        dual2_binop!(self, other, +)
    }

    fn __radd__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        self.__add__(other)
    }

    fn __sub__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        dual2_binop!(self, other, -)
    }

    fn __rsub__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        dual2_rbinop!(self, other, -)
    }

    fn __mul__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        dual2_binop!(self, other, *)
    }

    fn __rmul__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        self.__mul__(other)
    }

    fn __truediv__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        dual2_binop!(self, other, /)
    }

    fn __rtruediv__(&self, other: Dual2OrFloat) -> PyResult<Self> {
        dual2_rbinop!(self, other, /)
    }

    fn __neg__(&self) -> Self {
        -self
    }

    fn __pow__(&self, exp: f64, _modulo: Option<u32>) -> Self {
        Pow::pow(self, exp)
    }

    fn __float__(&self) -> f64 {
        self.real
    }

    fn __repr__(&self) -> String {
        let vars: Vec<String> = self.vars.iter().map(|v| format!("'{}'", v)).collect();
        let dual: Vec<String> = self.dual.iter().map(|d| format!("{}", d)).collect();
        format!(
            "Dual2(real={}, vars=[{}], dual=[{}])",
            self.real,
            vars.join(", "),
            dual.join(", ")
        )
    }

    #[pyo3(name = "exp")]
    fn py_exp(&self) -> Self {
        MathFuncs::exp(self)
    }

    #[pyo3(name = "log")]
    fn py_log(&self) -> Self {
        MathFuncs::log(self)
    }
}
