pub mod dual;
pub mod enums;
pub mod linalg;
pub mod ops;
mod py;

pub use dual::{Dual, Dual2};

use pyo3::prelude::*;

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<Dual>()?;
    m.add_class::<Dual2>()?;
    Ok(())
}
