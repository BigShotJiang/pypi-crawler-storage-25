use indexmap::IndexSet;
use pyo3::prelude::*;
use ndarray::{Array1, Array2};
use std::sync::Arc;

/// The relationship between variable sets of two dual numbers.
#[derive(Clone, Debug, PartialEq)]
pub enum VarsRelationship {
    /// The two structs share the same Arc pointer for their `vars`.
    ArcEquivalent,
    /// The structs have the same `vars` in the same order but not a shared Arc pointer.
    ValueEquivalent,
    /// The `vars` of the compared RHS is contained within those of the LHS.
    Superset,
    /// The `vars` of the calling LHS are contained within those of the RHS.
    Subset,
    /// Both the LHS and RHS have different `vars`.
    Difference,
}

/// Manages the `vars` of the manifold associated with a dual number.
pub trait Vars
where
    Self: Clone,
{
    /// Get a reference to the Arc pointer for the `IndexSet` containing the struct's variables.
    fn vars(&self) -> &Arc<IndexSet<String>>;

    /// Create a new dual number with `vars` aligned with given new Arc pointer.
    fn to_new_vars(
        &self,
        arc_vars: &Arc<IndexSet<String>>,
        state: Option<VarsRelationship>,
    ) -> Self;

    /// Compare the `vars` on a dual number with a given Arc pointer.
    fn vars_cmp(&self, arc_vars: &Arc<IndexSet<String>>) -> VarsRelationship {
        if Arc::ptr_eq(self.vars(), arc_vars) {
            VarsRelationship::ArcEquivalent
        } else if self.vars().len() == arc_vars.len()
            && self.vars().iter().zip(arc_vars.iter()).all(|(a, b)| a == b)
        {
            VarsRelationship::ValueEquivalent
        } else if self.vars().len() >= arc_vars.len()
            && arc_vars.iter().all(|var| self.vars().contains(var))
        {
            VarsRelationship::Superset
        } else if self.vars().len() < arc_vars.len()
            && self.vars().iter().all(|var| arc_vars.contains(var))
        {
            VarsRelationship::Subset
        } else {
            VarsRelationship::Difference
        }
    }

    /// Construct a tuple of 2 `Self` types whose `vars` are linked by an Arc pointer.
    fn to_union_vars(&self, other: &Self, state: Option<VarsRelationship>) -> (Self, Self)
    where
        Self: Sized,
    {
        let state_ = state.unwrap_or_else(|| self.vars_cmp(other.vars()));
        match state_ {
            VarsRelationship::ArcEquivalent => (self.clone(), other.clone()),
            VarsRelationship::ValueEquivalent => {
                (self.clone(), other.to_new_vars(self.vars(), Some(state_)))
            }
            VarsRelationship::Superset => (
                self.clone(),
                other.to_new_vars(self.vars(), Some(VarsRelationship::Subset)),
            ),
            VarsRelationship::Subset => {
                (self.to_new_vars(other.vars(), Some(state_)), other.clone())
            }
            VarsRelationship::Difference => {
                let comb_vars = Arc::new(IndexSet::from_iter(
                    self.vars().union(other.vars()).cloned(),
                ));
                (
                    self.to_new_vars(&comb_vars, Some(VarsRelationship::Difference)),
                    other.to_new_vars(&comb_vars, Some(VarsRelationship::Difference)),
                )
            }
        }
    }

    /// Compare if two dual number structs share the same `vars` by Arc pointer equivalence.
    fn ptr_eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(self.vars(), other.vars())
    }
}

/// A dual number data type supporting first order derivatives.
#[derive(Clone, Debug)]
#[pyclass(module = "vade._vade_rs.autodiff", from_py_object)]
pub struct Dual {
    pub(crate) real: f64,
    pub(crate) vars: Arc<IndexSet<String>>,
    pub(crate) dual: Array1<f64>,
}

/// A dual number data type supporting second order derivatives.
#[derive(Clone, Debug)]
#[pyclass(module = "vade._vade_rs.autodiff", from_py_object)]
pub struct Dual2 {
    pub(crate) real: f64,
    pub(crate) vars: Arc<IndexSet<String>>,
    pub(crate) dual: Array1<f64>,
    pub(crate) dual2: Array2<f64>,
}

impl PartialEq for Dual {
    fn eq(&self, other: &Self) -> bool {
        self.real == other.real && *self.vars == *other.vars && self.dual == other.dual
    }
}

impl PartialEq for Dual2 {
    fn eq(&self, other: &Self) -> bool {
        self.real == other.real
            && *self.vars == *other.vars
            && self.dual == other.dual
            && self.dual2 == other.dual2
    }
}

impl Dual {
    /// Construct a new `Dual` with the given variable name and real value.
    /// The derivative with respect to the variable is initialized to 1.0.
    pub fn new(var: &str, real: f64) -> Self {
        let vars = Arc::new(IndexSet::from_iter(vec![var.to_string()]));
        Self {
            real,
            dual: Array1::ones(1),
            vars,
        }
    }

    /// Construct a new `Dual` with multiple variables.
    /// All derivatives are initialized to 1.0.
    pub fn new_multi(real: f64, var_names: Vec<String>) -> Self {
        let vars = Arc::new(IndexSet::from_iter(var_names));
        let len = vars.len();
        Self {
            real,
            dual: Array1::ones(len),
            vars,
        }
    }

    /// Construct a new `Dual` with explicit dual values.
    pub fn try_new(real: f64, var_names: Vec<String>, dual: Vec<f64>) -> Result<Self, String> {
        let vars = Arc::new(IndexSet::from_iter(var_names));
        let dual_ = if dual.is_empty() {
            Array1::ones(vars.len())
        } else {
            Array1::from_vec(dual)
        };
        if vars.len() != dual_.len() {
            Err("`vars` and `dual` must have the same length.".to_string())
        } else {
            Ok(Self {
                real,
                vars,
                dual: dual_,
            })
        }
    }

    /// Construct a constant `Dual` sharing the `vars` Arc from another dual number.
    /// All derivatives are zero.
    pub fn new_from<T: Vars>(other: &T, real: f64) -> Self {
        Self {
            real,
            vars: Arc::clone(other.vars()),
            dual: Array1::zeros(other.vars().len()),
        }
    }

    /// Get the real component value.
    pub fn real(&self) -> f64 {
        self.real
    }
}

impl Dual2 {
    /// Construct a new `Dual2` with the given variable name and real value.
    /// First-order derivative initialized to 1.0, second-order to 0.0.
    pub fn new(var: &str, real: f64) -> Self {
        let vars = Arc::new(IndexSet::from_iter(vec![var.to_string()]));
        Self {
            real,
            dual: Array1::ones(1),
            dual2: Array2::zeros((1, 1)),
            vars,
        }
    }

    /// Construct a new `Dual2` with multiple variables.
    pub fn new_multi(real: f64, var_names: Vec<String>) -> Self {
        let vars = Arc::new(IndexSet::from_iter(var_names));
        let len = vars.len();
        Self {
            real,
            dual: Array1::ones(len),
            dual2: Array2::zeros((len, len)),
            vars,
        }
    }

    /// Construct a new `Dual2` with explicit dual and dual2 values.
    pub fn try_new(
        real: f64,
        var_names: Vec<String>,
        dual: Vec<f64>,
        dual2: Vec<f64>,
    ) -> Result<Self, String> {
        let vars = Arc::new(IndexSet::from_iter(var_names));
        let dual_ = if dual.is_empty() {
            Array1::ones(vars.len())
        } else {
            Array1::from_vec(dual)
        };
        if vars.len() != dual_.len() {
            return Err("`vars` and `dual` must have the same length.".to_string());
        }
        let dual2_ = if dual2.is_empty() {
            Array2::zeros((vars.len(), vars.len()))
        } else {
            if dual2.len() != vars.len() * vars.len() {
                return Err("`vars` and `dual2` must have compatible lengths.".to_string());
            }
            ndarray::Array::from_vec(dual2)
                .into_shape_with_order((vars.len(), vars.len()))
                .map_err(|e| format!("Reshape failed: {}", e))?
        };
        Ok(Self {
            real,
            vars,
            dual: dual_,
            dual2: dual2_,
        })
    }

    /// Construct a constant `Dual2` sharing the `vars` Arc from another dual number.
    /// All derivatives are zero.
    pub fn new_from<T: Vars>(other: &T, real: f64) -> Self {
        let len = other.vars().len();
        Self {
            real,
            vars: Arc::clone(other.vars()),
            dual: Array1::zeros(len),
            dual2: Array2::zeros((len, len)),
        }
    }

    /// Get the real component value.
    pub fn real(&self) -> f64 {
        self.real
    }
}

impl Vars for Dual {
    fn vars(&self) -> &Arc<IndexSet<String>> {
        &self.vars
    }

    fn to_new_vars(
        &self,
        arc_vars: &Arc<IndexSet<String>>,
        state: Option<VarsRelationship>,
    ) -> Self {
        let match_val = state.unwrap_or_else(|| self.vars_cmp(arc_vars));
        let dual_ = match match_val {
            VarsRelationship::ArcEquivalent | VarsRelationship::ValueEquivalent => {
                self.dual.clone()
            }
            _ => {
                let lookup_or_zero = |v: &String| match self.vars.get_index_of(v) {
                    Some(idx) => self.dual[idx],
                    None => 0.0_f64,
                };
                Array1::from_vec(arc_vars.iter().map(lookup_or_zero).collect())
            }
        };
        Self {
            real: self.real,
            vars: Arc::clone(arc_vars),
            dual: dual_,
        }
    }
}

impl Vars for Dual2 {
    fn vars(&self) -> &Arc<IndexSet<String>> {
        &self.vars
    }

    fn to_new_vars(
        &self,
        arc_vars: &Arc<IndexSet<String>>,
        state: Option<VarsRelationship>,
    ) -> Self {
        let match_val = state.unwrap_or_else(|| self.vars_cmp(arc_vars));
        match match_val {
            VarsRelationship::ArcEquivalent | VarsRelationship::ValueEquivalent => Self {
                real: self.real,
                vars: Arc::clone(arc_vars),
                dual: self.dual.clone(),
                dual2: self.dual2.clone(),
            },
            _ => {
                let lookup_or_zero = |v: &String| match self.vars.get_index_of(v) {
                    Some(idx) => self.dual[idx],
                    None => 0.0_f64,
                };
                let dual_ = Array1::from_vec(arc_vars.iter().map(lookup_or_zero).collect());

                let mut dual2_ = Array2::zeros((arc_vars.len(), arc_vars.len()));
                let indices: Vec<Option<usize>> =
                    arc_vars.iter().map(|x| self.vars.get_index_of(x)).collect();
                for (i, row_index) in indices.iter().enumerate() {
                    if let Some(row_value) = row_index {
                        for (j, col_index) in indices.iter().enumerate() {
                            if let Some(col_value) = col_index {
                                dual2_[[i, j]] = self.dual2[[*row_value, *col_value]];
                            }
                        }
                    }
                }

                Self {
                    real: self.real,
                    vars: Arc::clone(arc_vars),
                    dual: dual_,
                    dual2: dual2_,
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dual_new() {
        let x = Dual::new("x", 2.0);
        assert_eq!(x.real, 2.0);
        assert_eq!(x.dual, Array1::from_vec(vec![1.0]));
        assert!(x.vars.contains("x"));
    }

    #[test]
    fn test_dual_new_from() {
        let x = Dual::new("x", 2.0);
        let c = Dual::new_from(&x, 5.0);
        assert_eq!(c.real, 5.0);
        assert_eq!(c.dual, Array1::from_vec(vec![0.0]));
        assert!(c.ptr_eq(&x));
    }

    #[test]
    fn test_dual_try_new() {
        let d = Dual::try_new(3.0, vec!["x".to_string(), "y".to_string()], vec![1.0, 2.0]).unwrap();
        assert_eq!(d.real, 3.0);
        assert_eq!(d.dual, Array1::from_vec(vec![1.0, 2.0]));
    }

    #[test]
    fn test_dual_try_new_error() {
        let res = Dual::try_new(3.0, vec!["x".to_string()], vec![1.0, 2.0]);
        assert!(res.is_err());
    }

    #[test]
    fn test_vars_cmp() {
        let x = Dual::try_new(2.5, vec!["x".to_string(), "y".to_string()], vec![1.0, 0.0]).unwrap();
        let y = Dual::new("y", 1.5);
        let y2 = Dual::new("y", 1.5);
        let z = x.to_new_vars(y.vars(), None);
        let u = Dual::new("u", 1.5);
        assert_eq!(x.vars_cmp(y.vars()), VarsRelationship::Superset);
        assert_eq!(y.vars_cmp(z.vars()), VarsRelationship::ArcEquivalent);
        assert_eq!(y.vars_cmp(y2.vars()), VarsRelationship::ValueEquivalent);
        assert_eq!(y.vars_cmp(x.vars()), VarsRelationship::Subset);
        assert_eq!(y.vars_cmp(u.vars()), VarsRelationship::Difference);
    }

    #[test]
    fn test_to_union_vars_different() {
        let x = Dual::new("x", 1.0);
        let y = Dual::new("y", 1.5);
        let (a, b) = x.to_union_vars(&y, None);
        assert!(a.ptr_eq(&b));
        assert_eq!(a.dual, Array1::from_vec(vec![1.0, 0.0]));
        assert_eq!(b.dual, Array1::from_vec(vec![0.0, 1.0]));
    }

    #[test]
    fn test_to_new_vars() {
        let x = Dual::try_new(1.5, vec!["a".to_string(), "b".to_string()], vec![1., 2.]).unwrap();
        let y = Dual::try_new(2.0, vec!["a".to_string(), "c".to_string()], vec![3., 3.]).unwrap();
        let z = x.to_new_vars(&y.vars, None);
        assert_eq!(z.real, 1.5);
        assert!(y.ptr_eq(&z));
        assert_eq!(z.dual, Array1::from_vec(vec![1.0, 0.0]));
    }

    // Dual2 tests

    #[test]
    fn test_dual2_new() {
        let x = Dual2::new("x", 2.0);
        assert_eq!(x.real, 2.0);
        assert_eq!(x.dual, Array1::from_vec(vec![1.0]));
        assert_eq!(x.dual2, Array2::<f64>::zeros((1, 1)));
    }

    #[test]
    fn test_dual2_new_from() {
        let x = Dual2::new("x", 2.0);
        let c = Dual2::new_from(&x, 5.0);
        assert_eq!(c.real, 5.0);
        assert_eq!(c.dual, Array1::from_vec(vec![0.0]));
        assert!(c.ptr_eq(&x));
    }

    #[test]
    fn test_dual2_to_new_vars() {
        let d1 = Dual2::new("a", 20.0);
        let d2 = Dual2::new_multi(20.0, vec!["a".to_string(), "b".to_string()]);
        let d3 = d1.to_new_vars(&d2.vars, None);
        assert!(Arc::ptr_eq(&d3.vars, &d2.vars));
        assert_eq!(d3.dual.len(), 2);
        assert_eq!(d3.dual, Array1::from_vec(vec![1.0, 0.0]));
    }
}
