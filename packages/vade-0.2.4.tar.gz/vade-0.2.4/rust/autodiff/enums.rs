use crate::autodiff::dual::{Dual, Dual2};
use serde::{Serialize, Deserialize, Serializer, Deserializer};
use std::ops::Neg;

/// Container for the three core numeric types: f64, Dual, and Dual2.
#[derive(Debug, Clone)]
pub enum Number {
    F64(f64),
    Dual(Dual),
    Dual2(Dual2),
}

impl PartialEq for Number {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Number::F64(a), Number::F64(b)) => a == b,
            (Number::Dual(a), Number::Dual(b)) => a == b,
            (Number::Dual2(a), Number::Dual2(b)) => a == b,
            _ => false,
        }
    }
}

impl From<f64> for Number {
    fn from(f: f64) -> Self {
        Number::F64(f)
    }
}

impl From<Dual> for Number {
    fn from(d: Dual) -> Self {
        Number::Dual(d)
    }
}

impl From<Dual2> for Number {
    fn from(d: Dual2) -> Self {
        Number::Dual2(d)
    }
}

/// Promote an f64 to a constant Dual sharing the variable set from another Dual.
fn promote_f64_to_dual(f: f64, other: &Dual) -> Dual {
    Dual::new_from(other, f)
}

/// Promote an f64 to a constant Dual2 sharing the variable set from another Dual2.
fn promote_f64_to_dual2(f: f64, other: &Dual2) -> Dual2 {
    Dual2::new_from(other, f)
}

// Macro to implement binary ops for Number enum.
// Handles all variant combinations with proper promotion and cross-type rejection.
macro_rules! impl_number_binop {
    ($trait:ident, $method:ident, $op_str:expr) => {
        impl std::ops::$trait for &Number {
            type Output = Number;
            fn $method(self, rhs: &Number) -> Number {
                match (self, rhs) {
                    (Number::F64(a), Number::F64(b)) => {
                        Number::F64(std::ops::$trait::$method(*a, *b))
                    }
                    (Number::F64(a), Number::Dual(b)) => {
                        Number::Dual(std::ops::$trait::$method(&promote_f64_to_dual(*a, b), b))
                    }
                    (Number::F64(a), Number::Dual2(b)) => {
                        Number::Dual2(std::ops::$trait::$method(
                            &promote_f64_to_dual2(*a, b),
                            b,
                        ))
                    }
                    (Number::Dual(a), Number::F64(b)) => {
                        Number::Dual(std::ops::$trait::$method(a, &promote_f64_to_dual(*b, a)))
                    }
                    (Number::Dual(a), Number::Dual(b)) => {
                        Number::Dual(std::ops::$trait::$method(a, b))
                    }
                    (Number::Dual(_), Number::Dual2(_)) => {
                        panic!("Cannot mix dual types: Dual {} Dual2", $op_str)
                    }
                    (Number::Dual2(a), Number::F64(b)) => {
                        Number::Dual2(std::ops::$trait::$method(
                            a,
                            &promote_f64_to_dual2(*b, a),
                        ))
                    }
                    (Number::Dual2(_), Number::Dual(_)) => {
                        panic!("Cannot mix dual types: Dual2 {} Dual", $op_str)
                    }
                    (Number::Dual2(a), Number::Dual2(b)) => {
                        Number::Dual2(std::ops::$trait::$method(a, b))
                    }
                }
            }
        }

        impl std::ops::$trait for Number {
            type Output = Number;
            fn $method(self, rhs: Number) -> Number {
                std::ops::$trait::$method(&self, &rhs)
            }
        }
    };
}

impl_number_binop!(Add, add, "+");
impl_number_binop!(Sub, sub, "-");
impl_number_binop!(Mul, mul, "*");
impl_number_binop!(Div, div, "/");

// Number + f64 and f64 + Number convenience
macro_rules! impl_number_f64_binop {
    ($trait:ident, $method:ident) => {
        impl std::ops::$trait<f64> for &Number {
            type Output = Number;
            fn $method(self, rhs: f64) -> Number {
                std::ops::$trait::$method(self, &Number::F64(rhs))
            }
        }

        impl std::ops::$trait<f64> for Number {
            type Output = Number;
            fn $method(self, rhs: f64) -> Number {
                std::ops::$trait::$method(&self, &Number::F64(rhs))
            }
        }

        impl std::ops::$trait<Number> for f64 {
            type Output = Number;
            fn $method(self, rhs: Number) -> Number {
                std::ops::$trait::$method(&Number::F64(self), &rhs)
            }
        }

        impl std::ops::$trait<&Number> for f64 {
            type Output = Number;
            fn $method(self, rhs: &Number) -> Number {
                std::ops::$trait::$method(&Number::F64(self), rhs)
            }
        }
    };
}

impl_number_f64_binop!(Add, add);
impl_number_f64_binop!(Sub, sub);
impl_number_f64_binop!(Mul, mul);
impl_number_f64_binop!(Div, div);

// Neg for Number
impl Neg for Number {
    type Output = Number;
    fn neg(self) -> Number {
        match self {
            Number::F64(f) => Number::F64(-f),
            Number::Dual(d) => Number::Dual(-d),
            Number::Dual2(d) => Number::Dual2(-d),
        }
    }
}

impl Neg for &Number {
    type Output = Number;
    fn neg(self) -> Number {
        match self {
            Number::F64(f) => Number::F64(-f),
            Number::Dual(d) => Number::Dual(-d),
            Number::Dual2(d) => Number::Dual2(-d),
        }
    }
}

/// Custom Serialize for Number: always serializes as f64 (strips AD state per D-09).
impl Serialize for Number {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        match self {
            Number::F64(f) => serializer.serialize_f64(*f),
            Number::Dual(d) => serializer.serialize_f64(d.real()),
            Number::Dual2(d) => serializer.serialize_f64(d.real()),
        }
    }
}

/// Custom Deserialize for Number: always deserializes as Number::F64.
impl<'de> Deserialize<'de> for Number {
    fn deserialize<D: Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        let f = f64::deserialize(deserializer)?;
        Ok(Number::F64(f))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ndarray::Array1;

    // F64 + F64
    #[test]
    fn test_f64_add() {
        let a = Number::F64(1.0);
        let b = Number::F64(2.0);
        assert_eq!(&a + &b, Number::F64(3.0));
    }

    #[test]
    fn test_f64_sub() {
        let a = Number::F64(5.0);
        let b = Number::F64(2.0);
        assert_eq!(&a - &b, Number::F64(3.0));
    }

    #[test]
    fn test_f64_mul() {
        let a = Number::F64(3.0);
        let b = Number::F64(4.0);
        assert_eq!(&a * &b, Number::F64(12.0));
    }

    #[test]
    fn test_f64_div() {
        let a = Number::F64(6.0);
        let b = Number::F64(2.0);
        assert_eq!(&a / &b, Number::F64(3.0));
    }

    // Dual + Dual
    #[test]
    fn test_dual_add() {
        let d = Number::Dual(Dual::new("x", 3.0));
        assert_eq!(
            &d + &d,
            Number::Dual(Dual::try_new(6.0, vec!["x".to_string()], vec![2.0]).unwrap())
        );
    }

    #[test]
    fn test_dual_mul() {
        let d = Number::Dual(Dual::new("x", 3.0));
        assert_eq!(
            &d * &d,
            Number::Dual(Dual::try_new(9.0, vec!["x".to_string()], vec![6.0]).unwrap())
        );
    }

    // F64 + Dual promotion
    #[test]
    fn test_f64_plus_dual() {
        let f = Number::F64(2.0);
        let d = Number::Dual(Dual::new("x", 3.0));
        assert_eq!(
            &f + &d,
            Number::Dual(Dual::try_new(5.0, vec!["x".to_string()], vec![1.0]).unwrap())
        );
    }

    // F64 + Dual2 promotion
    #[test]
    fn test_f64_plus_dual2() {
        let f = Number::F64(2.0);
        let d = Number::Dual2(Dual2::new("x", 3.0));
        assert_eq!(
            &f + &d,
            Number::Dual2(Dual2::try_new(5.0, vec!["x".to_string()], vec![1.0], vec![0.0]).unwrap())
        );
    }

    // Dual + Dual2 REJECTED
    #[test]
    #[should_panic(expected = "Cannot mix dual types")]
    fn test_dual_plus_dual2_panics() {
        let d1 = Number::Dual(Dual::new("x", 2.0));
        let d2 = Number::Dual2(Dual2::new("y", 3.0));
        let _ = &d1 + &d2;
    }

    #[test]
    #[should_panic(expected = "Cannot mix dual types")]
    fn test_dual2_plus_dual_panics() {
        let d1 = Number::Dual2(Dual2::new("x", 2.0));
        let d2 = Number::Dual(Dual::new("y", 3.0));
        let _ = &d1 + &d2;
    }

    // Cross-type rejection for all ops
    #[test]
    #[should_panic(expected = "Cannot mix dual types")]
    fn test_dual_sub_dual2_panics() {
        let d1 = Number::Dual(Dual::new("x", 2.0));
        let d2 = Number::Dual2(Dual2::new("y", 3.0));
        let _ = &d1 - &d2;
    }

    #[test]
    #[should_panic(expected = "Cannot mix dual types")]
    fn test_dual_mul_dual2_panics() {
        let d1 = Number::Dual(Dual::new("x", 2.0));
        let d2 = Number::Dual2(Dual2::new("y", 3.0));
        let _ = &d1 * &d2;
    }

    #[test]
    #[should_panic(expected = "Cannot mix dual types")]
    fn test_dual_div_dual2_panics() {
        let d1 = Number::Dual(Dual::new("x", 2.0));
        let d2 = Number::Dual2(Dual2::new("y", 3.0));
        let _ = &d1 / &d2;
    }

    // Dual2 arithmetic
    #[test]
    fn test_dual2_mul() {
        let d1 = Number::Dual2(Dual2::new("x", 2.0));
        let d2 = Number::Dual2(Dual2::new("x", 3.0));
        if let Number::Dual2(result) = &d1 * &d2 {
            assert_eq!(result.real, 6.0);
        } else {
            panic!("Expected Dual2");
        }
    }

    // Neg
    #[test]
    fn test_neg_f64() {
        assert_eq!(-Number::F64(3.0), Number::F64(-3.0));
    }

    #[test]
    fn test_neg_dual() {
        let d = Number::Dual(Dual::new("x", 3.0));
        let result = -d;
        if let Number::Dual(r) = result {
            assert_eq!(r.real, -3.0);
            assert_eq!(r.dual, Array1::from_vec(vec![-1.0]));
        } else {
            panic!("Expected Dual");
        }
    }

    // f64 convenience
    #[test]
    fn test_f64_convenience() {
        let d = Number::Dual(Dual::new("x", 3.0));
        let res = 2.5_f64 + d;
        assert_eq!(
            res,
            Number::Dual(Dual::try_new(5.5, vec!["x".to_string()], vec![1.0]).unwrap())
        );
    }

    #[test]
    fn test_sub_f64_convenience() {
        let d = Number::Dual(Dual::new("x", 3.0));
        let res = d - 1.0;
        if let Number::Dual(r) = res {
            assert_eq!(r.real, 2.0);
        } else {
            panic!("Expected Dual");
        }
    }

    // Serde roundtrip tests
    #[test]
    fn test_serde_number_f64_roundtrip() {
        let n = Number::F64(3.14);
        let json = serde_json::to_string(&n).unwrap();
        assert_eq!(json, "3.14");
        let restored: Number = serde_json::from_str(&json).unwrap();
        assert_eq!(restored, Number::F64(3.14));
    }

    #[test]
    fn test_serde_number_dual_strips_ad() {
        let d = Number::Dual(Dual::new("x", 2.5));
        let json = serde_json::to_string(&d).unwrap();
        assert_eq!(json, "2.5");
        let restored: Number = serde_json::from_str(&json).unwrap();
        assert_eq!(restored, Number::F64(2.5));
    }

    #[test]
    fn test_serde_number_dual2_strips_ad() {
        let d = Number::Dual2(Dual2::new("x", 7.0));
        let json = serde_json::to_string(&d).unwrap();
        assert_eq!(json, "7.0");
        let restored: Number = serde_json::from_str(&json).unwrap();
        assert_eq!(restored, Number::F64(7.0));
    }
}
