use pyo3::prelude::*;

mod autodiff;
mod calendar;
mod cashflows;
mod marketcurves;
mod instruments;
mod models;
mod numerical;
mod solver;

#[pymodule]
fn _vade_rs(m: &Bound<'_, PyModule>) -> PyResult<()> {
    let autodiff_module = PyModule::new(m.py(), "autodiff")?;
    autodiff::register_module(&autodiff_module)?;
    m.add_submodule(&autodiff_module)?;

    let calendar_module = PyModule::new(m.py(), "calendar")?;
    calendar::register_module(&calendar_module)?;
    m.add_submodule(&calendar_module)?;

    let curves_module = PyModule::new(m.py(), "curves")?;
    marketcurves::py::register_module(&curves_module)?;
    m.add_submodule(&curves_module)?;

    let cashflows_module = PyModule::new(m.py(), "cashflows")?;
    cashflows::py::register_module(&cashflows_module)?;
    m.add_submodule(&cashflows_module)?;

    let instruments_module = PyModule::new(m.py(), "instruments")?;
    instruments::py::register_module(&instruments_module)?;
    m.add_submodule(&instruments_module)?;

    let solver_module = PyModule::new(m.py(), "solver")?;
    solver::py::register_module(&solver_module)?;
    m.add_submodule(&solver_module)?;

    let fx_module = PyModule::new(m.py(), "fx")?;
    marketcurves::fx::py::register_module(&fx_module)?;
    m.add_submodule(&fx_module)?;

    let numerical_module = PyModule::new(m.py(), "numerical")?;
    numerical::py::register_module(&numerical_module)?;
    m.add_submodule(&numerical_module)?;

    Ok(())
}
