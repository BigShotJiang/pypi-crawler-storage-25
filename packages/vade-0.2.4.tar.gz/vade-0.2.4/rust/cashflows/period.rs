use std::collections::HashMap;

use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::dateroll::add_business_days;
use crate::marketcurves::curve::CurveQuery;

use super::credit_period::{CreditPremiumPeriod, CreditProtectionPeriod};
use super::fixing::{self, FixingMethod, SpreadMethod};

// ---------------------------------------------------------------------------
// FixedPeriod (PER-01)
// ---------------------------------------------------------------------------

/// A fixed-rate accrual period.
///
/// NPV = -notional * dcf * (fixed_rate/100) * DF(payment)
#[derive(Clone, Serialize, Deserialize)]
pub struct FixedPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub notional: f64,
    /// Fixed rate in percentage (e.g. 5.0 for 5%).
    pub fixed_rate: f64,
    pub convention: DayCountConvention,
}

impl FixedPeriod {
    fn dcf(&self) -> f64 {
        self.convention
            .dcf(self.start, self.end, &DcfOptions::default())
            .unwrap()
    }

    /// Net present value of this period.
    pub fn npv(&self, curve: &dyn CurveQuery) -> Number {
        let dcf = self.dcf();
        let df = curve.discount_factor(self.payment);
        let cashflow_f64 = -self.notional * dcf * self.fixed_rate / 100.0;
        df * cashflow_f64
    }

    /// Analytic delta: sensitivity to a 1bp rate change.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let dcf = self.dcf();
        let df = curve.discount_factor(self.payment);
        df * (-self.notional * dcf / 10000.0)
    }

    /// Undiscounted cashflow.
    pub fn cashflow(&self) -> f64 {
        let dcf = self.dcf();
        -self.notional * dcf * self.fixed_rate / 100.0
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        curve: Option<&dyn CurveQuery>,
        _fixings: Option<&HashMap<NaiveDate, f64>>,
        currency: &str,
    ) -> CashflowRow {
        let dcf = self.dcf();
        let cf = self.cashflow();
        let (df, npv) = match curve {
            Some(c) => {
                let d = c.discount_factor(self.payment);
                let n = &d * cf;
                (Some(d), Some(n))
            }
            None => (None, None),
        };
        CashflowRow {
            period_type: "Fixed".to_string(),
            start: self.start,
            end: self.end,
            payment: self.payment,
            currency: currency.to_string(),
            notional: self.notional,
            fixing_rate: None,
            rate: self.fixed_rate / 100.0,
            spread: 0.0,
            dcf,
            cashflow: Number::F64(cf),
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

// ---------------------------------------------------------------------------
// FloatPeriod (PER-02, PER-06)
// ---------------------------------------------------------------------------

/// A floating-rate accrual period with RFR compounding.
#[derive(Clone, Serialize, Deserialize)]
pub struct FloatPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub notional: f64,
    /// Spread in percentage (e.g. 0.5 for 50bp).
    pub spread: f64,
    pub convention: DayCountConvention,
    pub fixing_method: FixingMethod,
    pub spread_method: SpreadMethod,
    pub calendar: BusinessCalendar,
}

impl FloatPeriod {
    fn dcf(&self) -> f64 {
        self.convention
            .dcf(self.start, self.end, &DcfOptions::default())
            .unwrap()
    }

    /// Compute the fixing rate (including spread per spread_method).
    pub fn rate(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        fixing::rfr_rate(
            &self.fixing_method,
            self.start,
            self.end,
            &self.convention,
            curve,
            fixings,
            self.spread,
            &self.spread_method,
            &self.calendar,
        )
    }

    /// Net present value of this period.
    pub fn npv(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let dcf = self.dcf();
        let rate = self.rate(curve, fixings);
        let df = curve.discount_factor(self.payment);
        // cashflow = -notional * dcf * rate (rate is decimal from rfr_rate)
        let cashflow = rate * (-self.notional * dcf);
        &cashflow * &df
    }

    /// Analytic delta: sensitivity to a 1bp rate change.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let dcf = self.dcf();
        let df = curve.discount_factor(self.payment);
        df * (-self.notional * dcf / 10000.0)
    }

    /// Dual-curve NPV: rate from forecast_curve, DF from disc_curve.
    pub fn npv_dual_curve(
        &self,
        forecast_curve: &dyn CurveQuery,
        disc_curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let dcf = self.dcf();
        let rate = self.rate(forecast_curve, fixings);
        let df = disc_curve.discount_factor(self.payment);
        let cashflow = rate * (-self.notional * dcf);
        &cashflow * &df
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        curve: Option<&dyn CurveQuery>,
        fixings: Option<&HashMap<NaiveDate, f64>>,
        currency: &str,
    ) -> CashflowRow {
        let dcf = self.dcf();
        let spread_decimal = self.spread / 100.0;

        let (fixing_rate, effective_rate, df, cashflow, npv) = match curve {
            Some(c) => {
                let total_rate = self.rate(c, fixings);
                // fixing_rate = total_rate - spread (for NoneSimple)
                // For ISDACompounding, fixing_rate is not easily separable
                let fr = &total_rate - spread_decimal;
                let cf = &total_rate * (-self.notional * dcf);
                let d = c.discount_factor(self.payment);
                let n = &cf * &d;
                (Some(fr), total_rate, Some(d), cf, Some(n))
            }
            None => (
                None,
                Number::F64(0.0),
                None,
                Number::F64(0.0),
                None,
            ),
        };

        let rate_f64 = match &effective_rate {
            Number::F64(r) => *r,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        CashflowRow {
            period_type: "Float".to_string(),
            start: self.start,
            end: self.end,
            payment: self.payment,
            currency: currency.to_string(),
            notional: self.notional,
            fixing_rate,
            rate: rate_f64,
            spread: spread_decimal,
            dcf,
            cashflow,
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

// ---------------------------------------------------------------------------
// IborPeriod (PER-07)
// ---------------------------------------------------------------------------

/// An IBOR fixing period with publication lag.
#[derive(Clone, Serialize, Deserialize)]
pub struct IborPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub notional: f64,
    /// Spread in percentage.
    pub spread: f64,
    pub convention: DayCountConvention,
    /// Business days before start for fixing date.
    pub fixing_lag: i32,
    pub calendar: BusinessCalendar,
}

impl IborPeriod {
    fn dcf(&self) -> f64 {
        self.convention
            .dcf(self.start, self.end, &DcfOptions::default())
            .unwrap()
    }

    /// The fixing date: start date minus fixing_lag business days.
    pub fn fixing_date(&self) -> NaiveDate {
        add_business_days(self.start, -self.fixing_lag, &self.calendar)
    }

    /// Get the IBOR rate from fixings or curve.
    fn ibor_rate(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let fix_date = self.fixing_date();
        if let Some(rate) = fixings.and_then(|f| f.get(&fix_date)) {
            Number::F64(*rate / 100.0)
        } else {
            curve.forward_rate(self.start, self.end)
        }
    }

    /// Net present value of this period.
    pub fn npv(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let dcf = self.dcf();
        let spread_decimal = self.spread / 100.0;
        let rate = self.ibor_rate(curve, fixings);
        let total_rate = &rate + spread_decimal;
        let df = curve.discount_factor(self.payment);
        let cashflow = total_rate * (-self.notional * dcf);
        &cashflow * &df
    }

    /// Analytic delta: sensitivity to a 1bp rate change.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let dcf = self.dcf();
        let df = curve.discount_factor(self.payment);
        df * (-self.notional * dcf / 10000.0)
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        curve: Option<&dyn CurveQuery>,
        fixings: Option<&HashMap<NaiveDate, f64>>,
        currency: &str,
    ) -> CashflowRow {
        let dcf = self.dcf();
        let spread_decimal = self.spread / 100.0;

        let (fixing_rate, rate_f64, df, cashflow, npv) = match curve {
            Some(c) => {
                let fr = self.ibor_rate(c, fixings);
                let total = &fr + spread_decimal;
                let cf = &total * (-self.notional * dcf);
                let d = c.discount_factor(self.payment);
                let n = &cf * &d;
                let r = match &total {
                    Number::F64(v) => *v,
                    Number::Dual(d) => d.real,
                    Number::Dual2(d) => d.real,
                };
                (Some(fr), r, Some(d), cf, Some(n))
            }
            None => (None, 0.0, None, Number::F64(0.0), None),
        };

        CashflowRow {
            period_type: "Float".to_string(),
            start: self.start,
            end: self.end,
            payment: self.payment,
            currency: currency.to_string(),
            notional: self.notional,
            fixing_rate,
            rate: rate_f64,
            spread: spread_decimal,
            dcf,
            cashflow,
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

// ---------------------------------------------------------------------------
// ZeroFixedPeriod (PER-03)
// ---------------------------------------------------------------------------

/// A zero-coupon fixed-rate period.
///
/// Cashflow = -notional * ((1 + rate/100)^dcf - 1), paid at end.
#[derive(Clone, Serialize, Deserialize)]
pub struct ZeroFixedPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub notional: f64,
    /// Fixed rate in percentage.
    pub fixed_rate: f64,
    pub convention: DayCountConvention,
}

impl ZeroFixedPeriod {
    fn dcf(&self) -> f64 {
        self.convention
            .dcf(self.start, self.end, &DcfOptions::default())
            .unwrap()
    }

    /// Undiscounted cashflow with compounded rate.
    pub fn cashflow(&self) -> f64 {
        let dcf = self.dcf();
        -self.notional * ((1.0 + self.fixed_rate / 100.0).powf(dcf) - 1.0)
    }

    /// Net present value of this period.
    pub fn npv(&self, curve: &dyn CurveQuery) -> Number {
        let cf = self.cashflow();
        let df = curve.discount_factor(self.payment);
        df * cf
    }

    /// Analytic delta: sensitivity to a 1bp rate change.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let dcf = self.dcf();
        let df = curve.discount_factor(self.payment);
        df * (-self.notional * dcf / 10000.0)
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        curve: Option<&dyn CurveQuery>,
        _fixings: Option<&HashMap<NaiveDate, f64>>,
        currency: &str,
    ) -> CashflowRow {
        let dcf = self.dcf();
        let cf = self.cashflow();
        let (df, npv) = match curve {
            Some(c) => {
                let d = c.discount_factor(self.payment);
                let n = &d * cf;
                (Some(d), Some(n))
            }
            None => (None, None),
        };
        CashflowRow {
            period_type: "Fixed".to_string(),
            start: self.start,
            end: self.end,
            payment: self.payment,
            currency: currency.to_string(),
            notional: self.notional,
            fixing_rate: None,
            rate: self.fixed_rate / 100.0,
            spread: 0.0,
            dcf,
            cashflow: Number::F64(cf),
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

// ---------------------------------------------------------------------------
// ZeroFloatPeriod (PER-03)
// ---------------------------------------------------------------------------

/// A zero-coupon floating-rate period.
///
/// Single-period, full-tenor RFR compounding.
#[derive(Clone, Serialize, Deserialize)]
pub struct ZeroFloatPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub notional: f64,
    /// Spread in percentage.
    pub spread: f64,
    pub convention: DayCountConvention,
    pub fixing_method: FixingMethod,
    pub spread_method: SpreadMethod,
    pub calendar: BusinessCalendar,
}

impl ZeroFloatPeriod {
    fn dcf(&self) -> f64 {
        self.convention
            .dcf(self.start, self.end, &DcfOptions::default())
            .unwrap()
    }

    /// Compute the fixing rate (including spread).
    pub fn rate(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        fixing::rfr_rate(
            &self.fixing_method,
            self.start,
            self.end,
            &self.convention,
            curve,
            fixings,
            self.spread,
            &self.spread_method,
            &self.calendar,
        )
    }

    /// Net present value of this period.
    pub fn npv(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let dcf = self.dcf();
        let rate = self.rate(curve, fixings);
        let df = curve.discount_factor(self.payment);
        // cashflow = -notional * dcf * rate
        let cashflow = rate * (-self.notional * dcf);
        &cashflow * &df
    }

    /// Analytic delta: sensitivity to a 1bp rate change.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let dcf = self.dcf();
        let df = curve.discount_factor(self.payment);
        df * (-self.notional * dcf / 10000.0)
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        curve: Option<&dyn CurveQuery>,
        fixings: Option<&HashMap<NaiveDate, f64>>,
        currency: &str,
    ) -> CashflowRow {
        let dcf = self.dcf();
        let spread_decimal = self.spread / 100.0;

        let (fixing_rate, rate_f64, df, cashflow, npv) = match curve {
            Some(c) => {
                let total_rate = self.rate(c, fixings);
                let fr = &total_rate - spread_decimal;
                let cf = &total_rate * (-self.notional * dcf);
                let d = c.discount_factor(self.payment);
                let n = &cf * &d;
                let r = match &total_rate {
                    Number::F64(v) => *v,
                    Number::Dual(d) => d.real,
                    Number::Dual2(d) => d.real,
                };
                (Some(fr), r, Some(d), cf, Some(n))
            }
            None => (None, 0.0, None, Number::F64(0.0), None),
        };

        CashflowRow {
            period_type: "Float".to_string(),
            start: self.start,
            end: self.end,
            payment: self.payment,
            currency: currency.to_string(),
            notional: self.notional,
            fixing_rate,
            rate: rate_f64,
            spread: spread_decimal,
            dcf,
            cashflow,
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

// ---------------------------------------------------------------------------
// CashflowPeriod (PER-04)
// ---------------------------------------------------------------------------

/// A simple notional exchange or fee cashflow.
///
/// NPV = -notional * DF(payment).
#[derive(Clone, Serialize, Deserialize)]
pub struct CashflowPeriod {
    pub payment: NaiveDate,
    pub notional: f64,
    pub currency: String,
}

impl CashflowPeriod {
    /// Net present value: -notional * DF(payment).
    pub fn npv(&self, curve: &dyn CurveQuery) -> Number {
        let df = curve.discount_factor(self.payment);
        df * (-self.notional)
    }

    /// Analytic delta is zero for a notional exchange.
    pub fn analytic_delta(&self, _curve: &dyn CurveQuery) -> Number {
        Number::F64(0.0)
    }

    /// Undiscounted cashflow.
    pub fn cashflow(&self) -> f64 {
        -self.notional
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        curve: Option<&dyn CurveQuery>,
        _fixings: Option<&HashMap<NaiveDate, f64>>,
        _currency_override: &str,
    ) -> CashflowRow {
        let cf = self.cashflow();
        let (df, npv) = match curve {
            Some(c) => {
                let d = c.discount_factor(self.payment);
                let n = &d * cf;
                (Some(d), Some(n))
            }
            None => (None, None),
        };
        CashflowRow {
            period_type: "Cashflow".to_string(),
            start: self.payment,
            end: self.payment,
            payment: self.payment,
            currency: self.currency.clone(),
            notional: self.notional,
            fixing_rate: None,
            rate: 0.0,
            spread: 0.0,
            dcf: 0.0,
            cashflow: Number::F64(cf),
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

// ---------------------------------------------------------------------------
// Period enum (for CustomLeg)
// ---------------------------------------------------------------------------

/// Unified period enum for CustomLeg dispatch.
#[derive(Clone, Serialize, Deserialize)]
pub enum Period {
    Fixed(FixedPeriod),
    Float(FloatPeriod),
    Ibor(IborPeriod),
    ZeroFixed(ZeroFixedPeriod),
    ZeroFloat(ZeroFloatPeriod),
    Cashflow(CashflowPeriod),
    CreditPremium(CreditPremiumPeriod),
    CreditProtection(CreditProtectionPeriod),
}

impl Period {
    /// Compute NPV, dispatching to the appropriate period type.
    ///
    /// The `credit_curve` parameter is required for CreditPremium and CreditProtection
    /// variants. For all other variants, pass `None`.
    pub fn npv(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
        credit_curve: Option<&dyn CurveQuery>,
    ) -> Number {
        match self {
            Period::Fixed(p) => p.npv(curve),
            Period::Float(p) => p.npv(curve, fixings),
            Period::Ibor(p) => p.npv(curve, fixings),
            Period::ZeroFixed(p) => p.npv(curve),
            Period::ZeroFloat(p) => p.npv(curve, fixings),
            Period::Cashflow(p) => p.npv(curve),
            Period::CreditPremium(p) => {
                let cc = credit_curve.expect("credit_curve required for CreditPremiumPeriod");
                p.npv(curve, cc, p.fixed_rate)
            }
            Period::CreditProtection(p) => {
                let cc = credit_curve.expect("credit_curve required for CreditProtectionPeriod");
                p.npv(curve, cc, p.recovery_rate)
            }
        }
    }

    /// Compute analytic delta, dispatching to the appropriate period type.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        match self {
            Period::Fixed(p) => p.analytic_delta(curve),
            Period::Float(p) => p.analytic_delta(curve),
            Period::Ibor(p) => p.analytic_delta(curve),
            Period::ZeroFixed(p) => p.analytic_delta(curve),
            Period::ZeroFloat(p) => p.analytic_delta(curve),
            Period::Cashflow(p) => p.analytic_delta(curve),
            Period::CreditPremium(_) => Number::F64(0.0),
            Period::CreditProtection(_) => Number::F64(0.0),
        }
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        curve: Option<&dyn CurveQuery>,
        fixings: Option<&HashMap<NaiveDate, f64>>,
        currency: &str,
    ) -> CashflowRow {
        match self {
            Period::Fixed(p) => p.to_cashflow_row(curve, fixings, currency),
            Period::Float(p) => p.to_cashflow_row(curve, fixings, currency),
            Period::Ibor(p) => p.to_cashflow_row(curve, fixings, currency),
            Period::ZeroFixed(p) => p.to_cashflow_row(curve, fixings, currency),
            Period::ZeroFloat(p) => p.to_cashflow_row(curve, fixings, currency),
            Period::Cashflow(p) => p.to_cashflow_row(curve, fixings, currency),
            Period::CreditPremium(p) => p.to_cashflow_row(curve, None, currency),
            Period::CreditProtection(p) => p.to_cashflow_row(curve, None, currency),
        }
    }
}

// ---------------------------------------------------------------------------
// CashflowRow (for DataFrame output)
// ---------------------------------------------------------------------------

/// Row of cashflow data for DataFrame output.
#[derive(Serialize, Deserialize)]
pub struct CashflowRow {
    pub period_type: String,
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub currency: String,
    pub notional: f64,
    pub fixing_rate: Option<Number>,
    pub rate: f64,
    pub spread: f64,
    pub dcf: f64,
    pub cashflow: Number,
    pub df: Option<Number>,
    pub npv: Option<Number>,
    // NDIRS settlement conversion fields (None for non-NDIRS instruments)
    #[serde(default)]
    pub settlement_amount: Option<Number>,
    #[serde(default)]
    pub fx_rate: Option<f64>,
    #[serde(default)]
    pub settlement_currency_label: Option<String>,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    #[test]
    fn test_fixed_period_npv() {
        let curve = test_curve();
        let p = FixedPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            fixed_rate: 5.0,
            convention: DayCountConvention::Act365F,
        };
        let npv = p.npv(&curve);
        if let Number::F64(v) = npv {
            // NPV = -1M * (366/365) * 0.05 * 0.97
            let dcf = 366.0 / 365.0;
            let expected = -1_000_000.0 * dcf * 0.05 * 0.97;
            assert!(
                (v - expected).abs() < 1e-6,
                "NPV={v}, expected={expected}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_fixed_period_analytic_delta() {
        let curve = test_curve();
        let p = FixedPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            fixed_rate: 5.0,
            convention: DayCountConvention::Act365F,
        };
        let delta = p.analytic_delta(&curve);
        if let Number::F64(v) = delta {
            let dcf = 366.0 / 365.0;
            let expected = -1_000_000.0 * dcf / 10000.0 * 0.97;
            assert!(
                (v - expected).abs() < 1e-6,
                "delta={v}, expected={expected}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_fixed_period_cashflow() {
        let p = FixedPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            fixed_rate: 5.0,
            convention: DayCountConvention::Act365F,
        };
        let cf = p.cashflow();
        let dcf = 366.0 / 365.0;
        let expected = -1_000_000.0 * dcf * 0.05;
        assert!((cf - expected).abs() < 1e-6);
    }

    #[test]
    fn test_cashflow_period_npv() {
        let curve = test_curve();
        let p = CashflowPeriod {
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            currency: "USD".to_string(),
        };
        let npv = p.npv(&curve);
        if let Number::F64(v) = npv {
            let expected = -1_000_000.0 * 0.97;
            assert!((v - expected).abs() < 1e-6);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_cashflow_period_analytic_delta() {
        let curve = test_curve();
        let p = CashflowPeriod {
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            currency: "USD".to_string(),
        };
        assert_eq!(p.analytic_delta(&curve), Number::F64(0.0));
    }

    #[test]
    fn test_zero_fixed_period_npv() {
        let curve = test_curve();
        let p = ZeroFixedPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            fixed_rate: 5.0,
            convention: DayCountConvention::Act365F,
        };
        let npv = p.npv(&curve);
        if let Number::F64(v) = npv {
            let dcf = 366.0 / 365.0;
            let cf = -1_000_000.0 * (1.05_f64.powf(dcf) - 1.0);
            let expected = cf * 0.97;
            assert!((v - expected).abs() < 1e-4, "NPV={v}, expected={expected}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_ibor_period_fixing_date() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let p = IborPeriod {
            start: ymd(2024, 1, 3), // Wednesday
            end: ymd(2024, 4, 3),
            payment: ymd(2024, 4, 3),
            notional: 1_000_000.0,
            spread: 0.0,
            convention: DayCountConvention::Act360,
            fixing_lag: 2,
            calendar: cal,
        };
        // 2 business days before Wed Jan 3 = Mon Jan 1
        assert_eq!(p.fixing_date(), ymd(2024, 1, 1));
    }

    #[test]
    fn test_period_enum_dispatch() {
        let curve = test_curve();
        let p = Period::Fixed(FixedPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            fixed_rate: 5.0,
            convention: DayCountConvention::Act365F,
        });
        let npv = p.npv(&curve, None, None);
        if let Number::F64(v) = npv {
            assert!(v < 0.0, "Pay leg NPV should be negative");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_fixed_period_to_cashflow_row() {
        let curve = test_curve();
        let p = FixedPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 1_000_000.0,
            fixed_rate: 5.0,
            convention: DayCountConvention::Act365F,
        };
        let row = p.to_cashflow_row(Some(&curve), None, "USD");
        assert_eq!(row.period_type, "Fixed");
        assert_eq!(row.currency, "USD");
        assert!(row.fixing_rate.is_none());
        assert!(row.df.is_some());
        assert!(row.npv.is_some());
    }

    #[test]
    fn test_period_enum_credit_premium() {
        use crate::marketcurves::credit::CreditImpliedCurve;

        let disc = test_curve();
        let cc_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.02),
        ]));
        let credit = CreditImpliedCurve::new(
            cc_nodes,
            DayCountConvention::Act365F,
            0.40,
            "credit".to_string(),
        );

        let p = Period::CreditPremium(CreditPremiumPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act360,
            premium_accrued: true,
            fixed_rate: 100.0,
            recovery_rate: 0.40,
        });

        let npv = p.npv(&disc, None, Some(&credit));
        if let Number::F64(v) = npv {
            assert!(v < 0.0, "Credit premium NPV should be negative, got {v}");
            assert!(v.is_finite());
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_period_enum_credit_protection() {
        use crate::marketcurves::credit::CreditImpliedCurve;

        let disc = test_curve();
        let cc_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.02),
        ]));
        let credit = CreditImpliedCurve::new(
            cc_nodes,
            DayCountConvention::Act365F,
            0.40,
            "credit".to_string(),
        );

        let p = Period::CreditProtection(CreditProtectionPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act365F,
            recovery_rate: 0.40,
        });

        let npv = p.npv(&disc, None, Some(&credit));
        if let Number::F64(v) = npv {
            assert!(v < 0.0, "Credit protection NPV should be negative, got {v}");
            assert!(v.is_finite());
        } else {
            panic!("Expected F64");
        }
    }
}
