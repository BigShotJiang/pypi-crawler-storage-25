use std::collections::HashMap;

use chrono::NaiveDate;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::autodiff::enums::Number;
use crate::calendar::convention::DayCountConvention;
use crate::calendar::py::{PyBusinessCalendar, PySchedule};
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::py::{PyDiscountCurve, PyLineCurve, PyNelsonSiegel, PyNelsonSiegelSvensson, PySmithWilson};

use super::amortization::Amortization;
use super::fixing::{FixingMethod, SpreadMethod};
use super::leg;
use super::period;

// ---- Reusable helpers ----

fn number_to_py(py: Python<'_>, n: Number) -> PyResult<Py<PyAny>> {
    match n {
        Number::F64(f) => Ok(f.into_pyobject(py).expect("f64 to py").into_any().unbind()),
        Number::Dual(d) => Ok(Py::new(py, d)?.into_any()),
        Number::Dual2(d) => Ok(Py::new(py, d)?.into_any()),
    }
}

fn option_number_to_py(py: Python<'_>, n: Option<Number>) -> PyResult<Py<PyAny>> {
    match n {
        Some(num) => number_to_py(py, num),
        None => Ok(py.None().into_pyobject(py).expect("None to py").unbind()),
    }
}

fn parse_day_count(s: &str) -> PyResult<DayCountConvention> {
    match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
        "act360" | "actual360" => Ok(DayCountConvention::Act360),
        "act365f" | "act365fixed" | "actual365fixed" => Ok(DayCountConvention::Act365F),
        "act365.25" | "act36525" => Ok(DayCountConvention::Act365_25),
        "act364" | "actual364" => Ok(DayCountConvention::Act364),
        "actactisda" | "actualactual" | "actact" => Ok(DayCountConvention::ActActISDA),
        "30/360" | "30360" | "thirty360" => Ok(DayCountConvention::Thirty360),
        "30e/360" | "30e360" | "thirtye360" => Ok(DayCountConvention::ThirtyE360),
        "30e/360isda" | "30e360isda" => Ok(DayCountConvention::ThirtyE360ISDA),
        "bus252" | "bus/252" => Ok(DayCountConvention::Bus252),
        "one" | "1" | "1/1" => Ok(DayCountConvention::One),
        _ => Err(PyValueError::new_err(format!(
            "Unknown day count convention: '{}'. Use: 'act360', 'act365f', 'actactisda', '30/360', etc.",
            s
        ))),
    }
}

fn parse_fixing_method(s: &str) -> PyResult<FixingMethod> {
    let normalized = s.to_lowercase().replace([' ', '-'], "_");
    match normalized.as_str() {
        "rfr_payment_delay" => Ok(FixingMethod::RFRPaymentDelay),
        "rfr_payment_delay_average" => Ok(FixingMethod::RFRPaymentDelayAverage),
        "rfr_observation_shift" => Ok(FixingMethod::RFRObservationShift(2)),
        "rfr_lockout" => Ok(FixingMethod::RFRLockout(2)),
        "rfr_lookback" => Ok(FixingMethod::RFRLookback(2)),
        "rfr_observation_shift_average" => Ok(FixingMethod::RFRObservationShiftAverage(2)),
        "rfr_lockout_average" => Ok(FixingMethod::RFRLookoutAverage(2)),
        "rfr_lookback_average" => Ok(FixingMethod::RFRLookbackAverage(2)),
        _ => {
            // Try parsing with trailing number: e.g., "rfr_observation_shift_5"
            if let Some(rest) = normalized.strip_prefix("rfr_observation_shift_") {
                if let Ok(n) = rest.parse::<i32>() {
                    return Ok(FixingMethod::RFRObservationShift(n));
                }
            }
            if let Some(rest) = normalized.strip_prefix("rfr_lockout_") {
                if rest != "average" {
                    if let Ok(n) = rest.parse::<i32>() {
                        return Ok(FixingMethod::RFRLockout(n));
                    }
                }
            }
            if let Some(rest) = normalized.strip_prefix("rfr_lookback_") {
                if rest != "average" {
                    if let Ok(n) = rest.parse::<i32>() {
                        return Ok(FixingMethod::RFRLookback(n));
                    }
                }
            }
            if let Some(rest) = normalized.strip_prefix("rfr_observation_shift_average_") {
                if let Ok(n) = rest.parse::<i32>() {
                    return Ok(FixingMethod::RFRObservationShiftAverage(n));
                }
            }
            if let Some(rest) = normalized.strip_prefix("rfr_lockout_average_") {
                if let Ok(n) = rest.parse::<i32>() {
                    return Ok(FixingMethod::RFRLookoutAverage(n));
                }
            }
            if let Some(rest) = normalized.strip_prefix("rfr_lookback_average_") {
                if let Ok(n) = rest.parse::<i32>() {
                    return Ok(FixingMethod::RFRLookbackAverage(n));
                }
            }
            Err(PyValueError::new_err(format!(
                "Unknown fixing method: '{}'. Use: 'rfr_payment_delay', 'rfr_observation_shift', \
                 'rfr_lockout', 'rfr_lookback' (with optional _N suffix and _average variant)",
                s
            )))
        }
    }
}

fn parse_spread_method(s: &str) -> PyResult<SpreadMethod> {
    match s.to_lowercase().replace([' ', '-'], "_").as_str() {
        "none_simple" | "nonesimple" | "simple" => Ok(SpreadMethod::NoneSimple),
        "isda_compounding" | "isdacompounding" | "isda" => Ok(SpreadMethod::ISDACompounding),
        _ => Err(PyValueError::new_err(format!(
            "Unknown spread method: '{}'. Use: 'none_simple', 'isda_compounding'",
            s
        ))),
    }
}

fn parse_amortization(obj: &Bound<'_, PyAny>) -> PyResult<Amortization> {
    if obj.is_none() {
        return Ok(Amortization::None);
    }
    // Try string: "constant_1000" or "percentage_5.0"
    if let Ok(s) = obj.extract::<String>() {
        let lower = s.to_lowercase();
        if let Some(rest) = lower.strip_prefix("constant_") {
            let amt: f64 = rest.parse().map_err(|_| {
                PyValueError::new_err(format!("Invalid constant amortization amount: '{}'", rest))
            })?;
            return Ok(Amortization::Constant(amt));
        }
        if let Some(rest) = lower.strip_prefix("percentage_") {
            let pct: f64 = rest.parse().map_err(|_| {
                PyValueError::new_err(format!("Invalid percentage amortization: '{}'", rest))
            })?;
            return Ok(Amortization::Percentage(pct));
        }
        if lower == "none" {
            return Ok(Amortization::None);
        }
        return Err(PyValueError::new_err(format!(
            "Unknown amortization: '{}'. Use: None, 'constant_AMOUNT', 'percentage_PCT', or list of notionals",
            s
        )));
    }
    // Try list of floats: custom notional schedule
    if let Ok(notionals) = obj.extract::<Vec<f64>>() {
        return Ok(Amortization::Custom(notionals));
    }
    Err(PyValueError::new_err(
        "amortization must be None, a string ('constant_1000', 'percentage_5.0'), or a list of notionals",
    ))
}

/// Extract a curve reference from a PyAny that could be DiscountCurve or LineCurve.
/// Returns an owned Box because we need to return a trait object.
fn extract_curve_ref<'py>(obj: &Bound<'py, PyAny>) -> PyResult<Box<dyn CurveQuery + 'py>> {
    if let Ok(dc) = obj.extract::<PyRef<'py, PyDiscountCurve>>() {
        // Clone the inner DiscountCurve so we can return an owned value
        Ok(Box::new(dc.inner.clone()))
    } else if let Ok(lc) = obj.extract::<PyRef<'py, PyLineCurve>>() {
        Ok(Box::new(lc.inner.clone()))
    } else if let Ok(ns) = obj.extract::<PyRef<'py, PyNelsonSiegel>>() {
        Ok(Box::new(ns.inner.clone()))
    } else if let Ok(nss) = obj.extract::<PyRef<'py, PyNelsonSiegelSvensson>>() {
        Ok(Box::new(nss.inner.clone()))
    } else if let Ok(sw) = obj.extract::<PyRef<'py, PySmithWilson>>() {
        Ok(Box::new(sw.inner.clone()))
    } else {
        Err(PyValueError::new_err(
            "curve must be a DiscountCurve, LineCurve, NelsonSiegel, NelsonSiegelSvensson, or SmithWilson",
        ))
    }
}

/// Parse Python fixings dict {date: float} to HashMap.
fn parse_fixings(obj: &Bound<'_, PyAny>) -> PyResult<HashMap<NaiveDate, f64>> {
    let dict = obj.cast::<pyo3::types::PyDict>().map_err(|_| {
        PyValueError::new_err("fixings must be a dict {date: float}")
    })?;
    let mut map = HashMap::new();
    for (k, v) in dict.iter() {
        let date: NaiveDate = k.extract()?;
        let rate: f64 = v.extract()?;
        map.insert(date, rate);
    }
    Ok(map)
}

// ---- PyCashflowRow ----

#[pyclass(name = "CashflowRow", module = "vade._vade_rs.cashflows")]
pub struct PyCashflowRow {
    pub inner: period::CashflowRow,
}

#[pymethods]
impl PyCashflowRow {
    #[getter]
    fn period_type(&self) -> &str {
        &self.inner.period_type
    }

    #[getter]
    fn start(&self) -> NaiveDate {
        self.inner.start
    }

    #[getter]
    fn end(&self) -> NaiveDate {
        self.inner.end
    }

    #[getter]
    fn payment(&self) -> NaiveDate {
        self.inner.payment
    }

    #[getter]
    fn currency(&self) -> &str {
        &self.inner.currency
    }

    #[getter]
    fn notional(&self) -> f64 {
        self.inner.notional
    }

    #[getter]
    fn fixing_rate(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        option_number_to_py(py, self.inner.fixing_rate.clone())
    }

    #[getter]
    fn rate(&self) -> f64 {
        self.inner.rate
    }

    #[getter]
    fn spread(&self) -> f64 {
        self.inner.spread
    }

    #[getter]
    fn dcf(&self) -> f64 {
        self.inner.dcf
    }

    #[getter]
    fn cashflow(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        number_to_py(py, self.inner.cashflow.clone())
    }

    #[getter]
    fn df(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        option_number_to_py(py, self.inner.df.clone())
    }

    #[getter]
    fn npv(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        option_number_to_py(py, self.inner.npv.clone())
    }

    #[getter]
    fn settlement_amount(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        option_number_to_py(py, self.inner.settlement_amount.clone())
    }

    #[getter]
    fn fx_rate(&self) -> Option<f64> {
        self.inner.fx_rate
    }

    #[getter]
    fn settlement_currency_label(&self) -> Option<&str> {
        self.inner.settlement_currency_label.as_deref()
    }

    fn __repr__(&self) -> String {
        format!(
            "CashflowRow(type='{}', payment={}, notional={})",
            self.inner.period_type, self.inner.payment, self.inner.notional
        )
    }
}

// ---- PyFixedPeriod ----

#[pyclass(name = "FixedPeriod", module = "vade._vade_rs.cashflows")]
pub struct PyFixedPeriod {
    pub inner: period::FixedPeriod,
}

#[pymethods]
impl PyFixedPeriod {
    #[new]
    #[pyo3(signature = (start, end, payment, notional, fixed_rate, convention="act360"))]
    fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        notional: f64,
        fixed_rate: f64,
        convention: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        Ok(PyFixedPeriod {
            inner: period::FixedPeriod {
                start,
                end,
                payment,
                notional,
                fixed_rate,
                convention: conv,
            },
        })
    }

    fn npv(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.npv(&*c))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    fn cashflow(&self) -> f64 {
        self.inner.cashflow()
    }

    fn __repr__(&self) -> String {
        format!(
            "FixedPeriod({} -> {}, notional={}, rate={})",
            self.inner.start, self.inner.end, self.inner.notional, self.inner.fixed_rate
        )
    }
}

// ---- PyFloatPeriod ----

#[pyclass(name = "FloatPeriod", module = "vade._vade_rs.cashflows")]
pub struct PyFloatPeriod {
    pub inner: period::FloatPeriod,
}

#[pymethods]
impl PyFloatPeriod {
    #[new]
    #[pyo3(signature = (start, end, payment, notional, calendar, spread=0.0, convention="act360", fixing_method="rfr_payment_delay", spread_method="none_simple"))]
    fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        notional: f64,
        calendar: &PyBusinessCalendar,
        spread: f64,
        convention: &str,
        fixing_method: &str,
        spread_method: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let sm = parse_spread_method(spread_method)?;
        Ok(PyFloatPeriod {
            inner: period::FloatPeriod {
                start,
                end,
                payment,
                notional,
                spread,
                convention: conv,
                fixing_method: fm,
                spread_method: sm,
                calendar: calendar.inner.clone(),
            },
        })
    }

    #[pyo3(signature = (curve, fixings=None))]
    fn npv(
        &self,
        py: Python<'_>,
        curve: &Bound<'_, PyAny>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        number_to_py(py, self.inner.npv(&*c, fix_map.as_ref()))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    #[pyo3(signature = (curve, fixings=None))]
    fn rate(
        &self,
        py: Python<'_>,
        curve: &Bound<'_, PyAny>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        number_to_py(py, self.inner.rate(&*c, fix_map.as_ref()))
    }

    fn __repr__(&self) -> String {
        format!(
            "FloatPeriod({} -> {}, notional={}, spread={})",
            self.inner.start, self.inner.end, self.inner.notional, self.inner.spread
        )
    }
}

// ---- PyIborPeriod ----

#[pyclass(name = "IborPeriod", module = "vade._vade_rs.cashflows")]
pub struct PyIborPeriod {
    pub inner: period::IborPeriod,
}

#[pymethods]
impl PyIborPeriod {
    #[new]
    #[pyo3(signature = (start, end, payment, notional, calendar, spread=0.0, convention="act360", fixing_lag=2))]
    fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        notional: f64,
        calendar: &PyBusinessCalendar,
        spread: f64,
        convention: &str,
        fixing_lag: i32,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        Ok(PyIborPeriod {
            inner: period::IborPeriod {
                start,
                end,
                payment,
                notional,
                spread,
                convention: conv,
                fixing_lag,
                calendar: calendar.inner.clone(),
            },
        })
    }

    #[pyo3(signature = (curve, fixings=None))]
    fn npv(
        &self,
        py: Python<'_>,
        curve: &Bound<'_, PyAny>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        number_to_py(py, self.inner.npv(&*c, fix_map.as_ref()))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    fn fixing_date(&self) -> NaiveDate {
        self.inner.fixing_date()
    }

    fn __repr__(&self) -> String {
        format!(
            "IborPeriod({} -> {}, notional={}, lag={})",
            self.inner.start, self.inner.end, self.inner.notional, self.inner.fixing_lag
        )
    }
}

// ---- PyZeroFixedPeriod ----

#[pyclass(name = "ZeroFixedPeriod", module = "vade._vade_rs.cashflows")]
pub struct PyZeroFixedPeriod {
    pub inner: period::ZeroFixedPeriod,
}

#[pymethods]
impl PyZeroFixedPeriod {
    #[new]
    #[pyo3(signature = (start, end, payment, notional, fixed_rate, convention="act360"))]
    fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        notional: f64,
        fixed_rate: f64,
        convention: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        Ok(PyZeroFixedPeriod {
            inner: period::ZeroFixedPeriod {
                start,
                end,
                payment,
                notional,
                fixed_rate,
                convention: conv,
            },
        })
    }

    fn npv(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.npv(&*c))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    fn cashflow(&self) -> f64 {
        self.inner.cashflow()
    }

    fn __repr__(&self) -> String {
        format!(
            "ZeroFixedPeriod({} -> {}, notional={}, rate={})",
            self.inner.start, self.inner.end, self.inner.notional, self.inner.fixed_rate
        )
    }
}

// ---- PyZeroFloatPeriod ----

#[pyclass(name = "ZeroFloatPeriod", module = "vade._vade_rs.cashflows")]
pub struct PyZeroFloatPeriod {
    pub inner: period::ZeroFloatPeriod,
}

#[pymethods]
impl PyZeroFloatPeriod {
    #[new]
    #[pyo3(signature = (start, end, payment, notional, calendar, spread=0.0, convention="act360", fixing_method="rfr_payment_delay", spread_method="none_simple"))]
    fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        notional: f64,
        calendar: &PyBusinessCalendar,
        spread: f64,
        convention: &str,
        fixing_method: &str,
        spread_method: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let sm = parse_spread_method(spread_method)?;
        Ok(PyZeroFloatPeriod {
            inner: period::ZeroFloatPeriod {
                start,
                end,
                payment,
                notional,
                spread,
                convention: conv,
                fixing_method: fm,
                spread_method: sm,
                calendar: calendar.inner.clone(),
            },
        })
    }

    #[pyo3(signature = (curve, fixings=None))]
    fn npv(
        &self,
        py: Python<'_>,
        curve: &Bound<'_, PyAny>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        number_to_py(py, self.inner.npv(&*c, fix_map.as_ref()))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    fn __repr__(&self) -> String {
        format!(
            "ZeroFloatPeriod({} -> {}, notional={}, spread={})",
            self.inner.start, self.inner.end, self.inner.notional, self.inner.spread
        )
    }
}

// ---- PyCashflowPeriod ----

#[pyclass(name = "CashflowPeriod", module = "vade._vade_rs.cashflows")]
pub struct PyCashflowPeriod {
    pub inner: period::CashflowPeriod,
}

#[pymethods]
impl PyCashflowPeriod {
    #[new]
    #[pyo3(signature = (payment, notional, currency="USD"))]
    fn new(payment: NaiveDate, notional: f64, currency: &str) -> Self {
        PyCashflowPeriod {
            inner: period::CashflowPeriod {
                payment,
                notional,
                currency: currency.to_string(),
            },
        }
    }

    fn npv(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.npv(&*c))
    }

    fn cashflow(&self) -> f64 {
        self.inner.cashflow()
    }

    fn __repr__(&self) -> String {
        format!(
            "CashflowPeriod(payment={}, notional={})",
            self.inner.payment, self.inner.notional
        )
    }
}

// ---- PyFixedLeg ----

#[pyclass(name = "FixedLeg", module = "vade._vade_rs.cashflows")]
pub struct PyFixedLeg {
    pub inner: leg::FixedLeg,
}

#[pymethods]
impl PyFixedLeg {
    #[new]
    #[pyo3(signature = (schedule, fixed_rate, notional, convention="act360", currency="USD", payment_lag=None, amortization=None))]
    fn new(
        schedule: &PySchedule,
        fixed_rate: f64,
        notional: f64,
        convention: &str,
        currency: &str,
        payment_lag: Option<i32>,
        amortization: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let amort = match amortization {
            Some(obj) => parse_amortization(obj)?,
            None => Amortization::None,
        };
        Ok(PyFixedLeg {
            inner: leg::FixedLeg::new(
                &schedule.inner,
                fixed_rate,
                notional,
                conv,
                currency.to_string(),
                payment_lag,
                amort,
            ),
        })
    }

    fn npv(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.npv(&*c))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    #[pyo3(signature = (curve=None))]
    fn cashflows(
        &self,
        curve: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let c: Option<Box<dyn CurveQuery>> = match curve {
            Some(obj) => Some(extract_curve_ref(obj)?),
            None => None,
        };
        let rows = self.inner.cashflows(c.as_deref());
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    #[getter]
    fn n_periods(&self) -> usize {
        self.inner.periods.len()
    }

    fn __repr__(&self) -> String {
        format!(
            "FixedLeg(periods={}, currency='{}')",
            self.inner.periods.len(),
            self.inner.currency,
        )
    }
}

// ---- PyFloatLeg ----

#[pyclass(name = "FloatLeg", module = "vade._vade_rs.cashflows")]
pub struct PyFloatLeg {
    pub inner: leg::FloatLeg,
}

#[pymethods]
impl PyFloatLeg {
    #[new]
    #[pyo3(signature = (schedule, notional, calendar, spread=0.0, convention="act360", fixing_method="rfr_payment_delay", spread_method="none_simple", currency="USD", payment_lag=None, amortization=None))]
    fn new(
        schedule: &PySchedule,
        notional: f64,
        calendar: &PyBusinessCalendar,
        spread: f64,
        convention: &str,
        fixing_method: &str,
        spread_method: &str,
        currency: &str,
        payment_lag: Option<i32>,
        amortization: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Self> {
        let _ = calendar;
        let conv = parse_day_count(convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let sm = parse_spread_method(spread_method)?;
        let amort = match amortization {
            Some(obj) => parse_amortization(obj)?,
            None => Amortization::None,
        };
        Ok(PyFloatLeg {
            inner: leg::FloatLeg::new(
                &schedule.inner,
                spread,
                notional,
                conv,
                fm,
                sm,
                currency.to_string(),
                payment_lag,
                amort,
            ),
        })
    }

    #[pyo3(signature = (curve, fixings=None))]
    fn npv(
        &self,
        py: Python<'_>,
        curve: &Bound<'_, PyAny>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        number_to_py(py, self.inner.npv(&*c, fix_map.as_ref()))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    #[pyo3(signature = (curve=None, fixings=None))]
    fn cashflows(
        &self,
        curve: Option<&Bound<'_, PyAny>>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let c: Option<Box<dyn CurveQuery>> = match curve {
            Some(obj) => Some(extract_curve_ref(obj)?),
            None => None,
        };
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        let rows = self.inner.cashflows(c.as_deref(), fix_map.as_ref());
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    #[getter]
    fn n_periods(&self) -> usize {
        self.inner.periods.len()
    }

    fn __repr__(&self) -> String {
        format!(
            "FloatLeg(periods={}, currency='{}')",
            self.inner.periods.len(),
            self.inner.currency,
        )
    }
}

// ---- PyZeroFixedLeg ----

#[pyclass(name = "ZeroFixedLeg", module = "vade._vade_rs.cashflows")]
pub struct PyZeroFixedLeg {
    pub inner: leg::ZeroFixedLeg,
}

#[pymethods]
impl PyZeroFixedLeg {
    #[new]
    #[pyo3(signature = (start, end, payment, fixed_rate, notional, convention="act360", currency="USD"))]
    fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        fixed_rate: f64,
        notional: f64,
        convention: &str,
        currency: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        Ok(PyZeroFixedLeg {
            inner: leg::ZeroFixedLeg::new(
                start, end, payment, fixed_rate, notional, conv, currency.to_string(),
            ),
        })
    }

    fn npv(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.npv(&*c))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    #[pyo3(signature = (curve=None))]
    fn cashflows(
        &self,
        curve: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let c: Option<Box<dyn CurveQuery>> = match curve {
            Some(obj) => Some(extract_curve_ref(obj)?),
            None => None,
        };
        let rows = self.inner.cashflows(c.as_deref());
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn __repr__(&self) -> String {
        format!(
            "ZeroFixedLeg(currency='{}')",
            self.inner.currency,
        )
    }
}

// ---- PyZeroFloatLeg ----

#[pyclass(name = "ZeroFloatLeg", module = "vade._vade_rs.cashflows")]
pub struct PyZeroFloatLeg {
    pub inner: leg::ZeroFloatLeg,
}

#[pymethods]
impl PyZeroFloatLeg {
    #[new]
    #[pyo3(signature = (start, end, payment, notional, calendar, spread=0.0, convention="act360", fixing_method="rfr_payment_delay", spread_method="none_simple", currency="USD"))]
    fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        notional: f64,
        calendar: &PyBusinessCalendar,
        spread: f64,
        convention: &str,
        fixing_method: &str,
        spread_method: &str,
        currency: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let sm = parse_spread_method(spread_method)?;
        Ok(PyZeroFloatLeg {
            inner: leg::ZeroFloatLeg::new(
                start, end, payment, notional, spread, conv, fm, sm,
                calendar.inner.clone(), currency.to_string(),
            ),
        })
    }

    #[pyo3(signature = (curve, fixings=None))]
    fn npv(
        &self,
        py: Python<'_>,
        curve: &Bound<'_, PyAny>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        number_to_py(py, self.inner.npv(&*c, fix_map.as_ref()))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    #[pyo3(signature = (curve=None, fixings=None))]
    fn cashflows(
        &self,
        curve: Option<&Bound<'_, PyAny>>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let c: Option<Box<dyn CurveQuery>> = match curve {
            Some(obj) => Some(extract_curve_ref(obj)?),
            None => None,
        };
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        let rows = self.inner.cashflows(c.as_deref(), fix_map.as_ref());
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn __repr__(&self) -> String {
        format!(
            "ZeroFloatLeg(currency='{}')",
            self.inner.currency,
        )
    }
}

// ---- PyCustomLeg ----

#[pyclass(name = "CustomLeg", module = "vade._vade_rs.cashflows")]
pub struct PyCustomLeg {
    pub inner: leg::CustomLeg,
}

#[pymethods]
impl PyCustomLeg {
    #[new]
    #[pyo3(signature = (periods, currency="USD"))]
    fn new(periods: Vec<Bound<'_, PyAny>>, currency: &str) -> PyResult<Self> {
        let mut rust_periods = Vec::new();
        for obj in &periods {
            if let Ok(p) = obj.extract::<PyRef<'_, PyFixedPeriod>>() {
                rust_periods.push(period::Period::Fixed(period::FixedPeriod {
                    start: p.inner.start,
                    end: p.inner.end,
                    payment: p.inner.payment,
                    notional: p.inner.notional,
                    fixed_rate: p.inner.fixed_rate,
                    convention: p.inner.convention,
                }));
            } else if let Ok(p) = obj.extract::<PyRef<'_, PyFloatPeriod>>() {
                rust_periods.push(period::Period::Float(period::FloatPeriod {
                    start: p.inner.start,
                    end: p.inner.end,
                    payment: p.inner.payment,
                    notional: p.inner.notional,
                    spread: p.inner.spread,
                    convention: p.inner.convention,
                    fixing_method: p.inner.fixing_method.clone(),
                    spread_method: p.inner.spread_method.clone(),
                    calendar: p.inner.calendar.clone(),
                }));
            } else if let Ok(p) = obj.extract::<PyRef<'_, PyIborPeriod>>() {
                rust_periods.push(period::Period::Ibor(period::IborPeriod {
                    start: p.inner.start,
                    end: p.inner.end,
                    payment: p.inner.payment,
                    notional: p.inner.notional,
                    spread: p.inner.spread,
                    convention: p.inner.convention,
                    fixing_lag: p.inner.fixing_lag,
                    calendar: p.inner.calendar.clone(),
                }));
            } else if let Ok(p) = obj.extract::<PyRef<'_, PyZeroFixedPeriod>>() {
                rust_periods.push(period::Period::ZeroFixed(period::ZeroFixedPeriod {
                    start: p.inner.start,
                    end: p.inner.end,
                    payment: p.inner.payment,
                    notional: p.inner.notional,
                    fixed_rate: p.inner.fixed_rate,
                    convention: p.inner.convention,
                }));
            } else if let Ok(p) = obj.extract::<PyRef<'_, PyZeroFloatPeriod>>() {
                rust_periods.push(period::Period::ZeroFloat(period::ZeroFloatPeriod {
                    start: p.inner.start,
                    end: p.inner.end,
                    payment: p.inner.payment,
                    notional: p.inner.notional,
                    spread: p.inner.spread,
                    convention: p.inner.convention,
                    fixing_method: p.inner.fixing_method.clone(),
                    spread_method: p.inner.spread_method.clone(),
                    calendar: p.inner.calendar.clone(),
                }));
            } else if let Ok(p) = obj.extract::<PyRef<'_, PyCashflowPeriod>>() {
                rust_periods.push(period::Period::Cashflow(period::CashflowPeriod {
                    payment: p.inner.payment,
                    notional: p.inner.notional,
                    currency: p.inner.currency.clone(),
                }));
            } else {
                return Err(PyValueError::new_err(
                    "Each period must be a FixedPeriod, FloatPeriod, IborPeriod, \
                     ZeroFixedPeriod, ZeroFloatPeriod, or CashflowPeriod",
                ));
            }
        }
        Ok(PyCustomLeg {
            inner: leg::CustomLeg::new(rust_periods, currency.to_string()),
        })
    }

    #[pyo3(signature = (curve, fixings=None))]
    fn npv(
        &self,
        py: Python<'_>,
        curve: &Bound<'_, PyAny>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        number_to_py(py, self.inner.npv(&*c, fix_map.as_ref()))
    }

    fn analytic_delta(&self, py: Python<'_>, curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let c = extract_curve_ref(curve)?;
        number_to_py(py, self.inner.analytic_delta(&*c))
    }

    #[pyo3(signature = (curve=None, fixings=None))]
    fn cashflows(
        &self,
        curve: Option<&Bound<'_, PyAny>>,
        fixings: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let c: Option<Box<dyn CurveQuery>> = match curve {
            Some(obj) => Some(extract_curve_ref(obj)?),
            None => None,
        };
        let fix_map = match fixings {
            Some(f) => Some(parse_fixings(f)?),
            None => None,
        };
        let rows = self.inner.cashflows(c.as_deref(), fix_map.as_ref());
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    #[getter]
    fn n_periods(&self) -> usize {
        self.inner.periods.len()
    }

    fn __repr__(&self) -> String {
        format!(
            "CustomLeg(periods={}, currency='{}')",
            self.inner.periods.len(),
            self.inner.currency,
        )
    }
}

// ---- Module registration ----

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyFixedPeriod>()?;
    m.add_class::<PyFloatPeriod>()?;
    m.add_class::<PyIborPeriod>()?;
    m.add_class::<PyZeroFixedPeriod>()?;
    m.add_class::<PyZeroFloatPeriod>()?;
    m.add_class::<PyCashflowPeriod>()?;
    m.add_class::<PyFixedLeg>()?;
    m.add_class::<PyFloatLeg>()?;
    m.add_class::<PyZeroFixedLeg>()?;
    m.add_class::<PyZeroFloatLeg>()?;
    m.add_class::<PyCustomLeg>()?;
    m.add_class::<PyCashflowRow>()?;
    Ok(())
}
