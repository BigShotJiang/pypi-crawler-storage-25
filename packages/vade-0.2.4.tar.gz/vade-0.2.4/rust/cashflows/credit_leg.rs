use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::convention::DayCountConvention;
use crate::calendar::schedule::Schedule;
use crate::marketcurves::curve::CurveQuery;

use super::credit_period::{CreditPremiumPeriod, CreditProtectionPeriod};
use super::period::CashflowRow;

// ---------------------------------------------------------------------------
// CreditPremiumLeg (LEG-04, D-24)
// ---------------------------------------------------------------------------

/// A leg of credit premium (fee) periods for CDS instruments.
///
/// Aggregates CreditPremiumPeriod NPVs and computes the premium annuity
/// for par spread calculation.
#[derive(Clone, Serialize, Deserialize)]
pub struct CreditPremiumLeg {
    pub periods: Vec<CreditPremiumPeriod>,
    pub notional: f64,
    pub fixed_rate: f64, // in basis points
    pub currency: String,
}

impl CreditPremiumLeg {
    /// Construct a CreditPremiumLeg from a Schedule.
    pub fn new(
        schedule: &Schedule,
        notional: f64,
        fixed_rate: f64,
        convention: DayCountConvention,
        currency: String,
        premium_accrued: bool,
        recovery_rate: f64,
    ) -> Self {
        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();

        let periods: Vec<CreditPremiumPeriod> = (0..n)
            .map(|i| CreditPremiumPeriod {
                start: dates[i],
                end: dates[i + 1],
                payment: dates[i + 1],
                notional,
                convention,
                premium_accrued,
                fixed_rate,
                recovery_rate,
            })
            .collect();

        CreditPremiumLeg {
            periods,
            notional,
            fixed_rate,
            currency,
        }
    }

    /// Net present value: sum of all period NPVs.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.npv(disc_curve, credit_curve, self.fixed_rate);
        }
        total
    }

    /// Premium annuity: sum of period annuities (for par spread calculation).
    pub fn annuity(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.annuity(disc_curve, credit_curve);
        }
        total
    }

    /// Collect cashflow rows from all periods.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        credit_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        self.periods
            .iter()
            .map(|p| p.to_cashflow_row(disc_curve, credit_curve, &self.currency))
            .collect()
    }
}

// ---------------------------------------------------------------------------
// CreditProtectionLeg (LEG-04, D-24)
// ---------------------------------------------------------------------------

/// A leg of credit protection periods for CDS instruments.
///
/// Aggregates CreditProtectionPeriod NPVs using piecewise analytical integration.
#[derive(Clone, Serialize, Deserialize)]
pub struct CreditProtectionLeg {
    pub periods: Vec<CreditProtectionPeriod>,
    pub notional: f64,
    pub recovery_rate: f64,
    pub currency: String,
}

impl CreditProtectionLeg {
    /// Construct a CreditProtectionLeg from a Schedule.
    pub fn new(
        schedule: &Schedule,
        notional: f64,
        recovery_rate: f64,
        convention: DayCountConvention,
        currency: String,
    ) -> Self {
        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();

        let periods: Vec<CreditProtectionPeriod> = (0..n)
            .map(|i| CreditProtectionPeriod {
                start: dates[i],
                end: dates[i + 1],
                payment: dates[i + 1],
                notional,
                convention,
                recovery_rate,
            })
            .collect();

        CreditProtectionLeg {
            periods,
            notional,
            recovery_rate,
            currency,
        }
    }

    /// Net present value: sum of all period NPVs.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.npv(disc_curve, credit_curve, self.recovery_rate);
        }
        total
    }

    /// Collect cashflow rows from all periods.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        credit_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        self.periods
            .iter()
            .map(|p| p.to_cashflow_row(disc_curve, credit_curve, &self.currency))
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::credit::CreditImpliedCurve;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::frequency::Frequency;
    use crate::calendar::adjuster::Adjuster;
    use indexmap::IndexMap;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn disc_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc".to_string(),
        )
    }

    fn credit_curve() -> CreditImpliedCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.02),
        ]));
        CreditImpliedCurve::new(
            nodes,
            DayCountConvention::Act365F,
            0.40,
            "credit".to_string(),
        )
    }

    fn test_schedule() -> Schedule {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            Frequency::Quarterly,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap()
    }

    #[test]
    fn test_credit_premium_leg_aggregation() {
        let dc = disc_curve();
        let cc = credit_curve();
        let schedule = test_schedule();

        let leg = CreditPremiumLeg::new(
            &schedule,
            10_000_000.0,
            100.0, // 100bp
            DayCountConvention::Act360,
            "USD".to_string(),
            true,
            0.40,
        );

        let npv = leg.npv(&dc, &cc);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "Premium leg NPV should be finite");
            assert!(v < 0.0, "Premium leg NPV should be negative (buyer pays)");
        } else {
            panic!("Expected F64");
        }

        // Verify sum of period NPVs equals leg NPV
        let mut sum = Number::F64(0.0);
        for p in &leg.periods {
            sum = sum + p.npv(&dc, &cc, leg.fixed_rate);
        }
        if let (Number::F64(leg_npv), Number::F64(sum_npv)) = (&npv, &sum) {
            assert!(
                (leg_npv - sum_npv).abs() < 1e-6,
                "Leg NPV ({leg_npv}) != sum of periods ({sum_npv})"
            );
        }
    }

    #[test]
    fn test_credit_premium_leg_annuity() {
        let dc = disc_curve();
        let cc = credit_curve();
        let schedule = test_schedule();

        let leg = CreditPremiumLeg::new(
            &schedule,
            10_000_000.0,
            100.0,
            DayCountConvention::Act360,
            "USD".to_string(),
            true,
            0.40,
        );

        let ann = leg.annuity(&dc, &cc);
        if let Number::F64(v) = ann {
            assert!(v > 0.0, "Annuity should be positive, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_protection_leg_npv() {
        let dc = disc_curve();
        let cc = credit_curve();
        let schedule = test_schedule();

        let leg = CreditProtectionLeg::new(
            &schedule,
            10_000_000.0,
            0.40,
            DayCountConvention::Act365F,
            "USD".to_string(),
        );

        let npv = leg.npv(&dc, &cc);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "Protection leg NPV should be finite");
            assert!(v < 0.0, "Protection leg NPV should be negative");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_premium_leg_cashflows() {
        let dc = disc_curve();
        let cc = credit_curve();
        let schedule = test_schedule();

        let leg = CreditPremiumLeg::new(
            &schedule,
            10_000_000.0,
            100.0,
            DayCountConvention::Act360,
            "USD".to_string(),
            true,
            0.40,
        );

        let rows = leg.cashflows(Some(&dc), Some(&cc));
        assert_eq!(rows.len(), leg.periods.len());
        for row in &rows {
            assert_eq!(row.period_type, "CreditPremium");
        }
    }
}
