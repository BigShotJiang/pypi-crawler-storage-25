use serde::{Serialize, Deserialize};

/// Amortization schedule types for notional reduction across leg periods.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Amortization {
    /// No amortization -- constant notional.
    None,
    /// Reduce notional by a constant amount each period.
    Constant(f64),
    /// Reduce notional by a percentage each period.
    Percentage(f64),
    /// Explicit notional for each period.
    Custom(Vec<f64>),
}

impl Default for Amortization {
    fn default() -> Self {
        Amortization::None
    }
}

impl Amortization {
    /// Generate notional schedule for `n` periods starting from `initial` notional.
    ///
    /// Returns a Vec of length `n` with the notional for each period.
    pub fn notional_schedule(&self, n: usize, initial: f64) -> Vec<f64> {
        match self {
            Amortization::None => vec![initial; n],
            Amortization::Constant(amt) => {
                (0..n).map(|i| initial - (i as f64) * amt).collect()
            }
            Amortization::Percentage(pct) => {
                let mut notionals = Vec::with_capacity(n);
                let mut current = initial;
                for _ in 0..n {
                    notionals.push(current);
                    current *= 1.0 - pct / 100.0;
                }
                notionals
            }
            Amortization::Custom(schedule) => schedule.clone(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_no_amortization() {
        let schedule = Amortization::None.notional_schedule(4, 1_000_000.0);
        assert_eq!(schedule, vec![1_000_000.0; 4]);
    }

    #[test]
    fn test_constant_amortization() {
        let schedule = Amortization::Constant(100_000.0).notional_schedule(4, 1_000_000.0);
        assert_eq!(schedule, vec![1_000_000.0, 900_000.0, 800_000.0, 700_000.0]);
    }

    #[test]
    fn test_percentage_amortization() {
        let schedule = Amortization::Percentage(10.0).notional_schedule(3, 1_000_000.0);
        assert_eq!(schedule[0], 1_000_000.0);
        assert!((schedule[1] - 900_000.0).abs() < 1e-6);
        assert!((schedule[2] - 810_000.0).abs() < 1e-6);
    }

    #[test]
    fn test_custom_amortization() {
        let custom = vec![1_000_000.0, 750_000.0, 500_000.0];
        let schedule = Amortization::Custom(custom.clone()).notional_schedule(3, 1_000_000.0);
        assert_eq!(schedule, custom);
    }
}
