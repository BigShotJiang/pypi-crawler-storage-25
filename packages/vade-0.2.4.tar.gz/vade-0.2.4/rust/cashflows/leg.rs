use std::collections::HashMap;

use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::DayCountConvention;
use crate::calendar::dateroll::add_business_days;
use crate::calendar::schedule::Schedule;
use crate::marketcurves::curve::CurveQuery;

use super::amortization::Amortization;
use super::fixing::{FixingMethod, SpreadMethod};
use super::period::{
    CashflowPeriod, CashflowRow, FixedPeriod, FloatPeriod, Period,
    ZeroFixedPeriod, ZeroFloatPeriod,
};

// ---------------------------------------------------------------------------
// Notional exchange generation (LEG-06)
// ---------------------------------------------------------------------------

/// Generate notional exchange CashflowPeriods for a leg.
///
/// Algorithm:
/// 1. Initial exchange at dates[0]: -initial_notional (receive)
/// 2. At each period boundary where notional changes: return difference
/// 3. Final exchange at dates[n]: return remaining notional
fn generate_notional_exchanges(
    dates: &[NaiveDate],
    notionals: &[f64],
    currency: &str,
) -> Vec<CashflowPeriod> {
    let n = notionals.len();
    if n == 0 || dates.len() < 2 {
        return vec![];
    }

    let mut exchanges = Vec::new();

    // Initial exchange: receive notional (negative = inflow in our sign convention)
    // CashflowPeriod.npv = -notional * DF, so notional field = initial_notional
    // means cashflow = -initial_notional (receive). But the plan says initial exchange
    // is -notional (receive), so we set notional = notionals[0] which yields
    // cashflow = -notionals[0].
    exchanges.push(CashflowPeriod {
        payment: dates[0],
        notional: notionals[0],
        currency: currency.to_string(),
    });

    // Intermediate exchanges for amortizing legs: at each boundary where notional changes
    for i in 0..n - 1 {
        let diff = notionals[i] - notionals[i + 1];
        if diff.abs() > 1e-12 {
            // Return the difference (positive = pay back partial notional)
            exchanges.push(CashflowPeriod {
                payment: dates[i + 1],
                notional: -diff,
                currency: currency.to_string(),
            });
        }
    }

    // Final exchange: return remaining notional
    // notional = -notionals[n-1] means cashflow = -(-notionals[n-1]) = +notionals[n-1]
    exchanges.push(CashflowPeriod {
        payment: dates[n],
        notional: -notionals[n - 1],
        currency: currency.to_string(),
    });

    exchanges
}

/// Compute payment date, optionally shifted by payment_lag business days.
fn payment_date(date: NaiveDate, payment_lag: Option<i32>, calendar: &BusinessCalendar) -> NaiveDate {
    match payment_lag {
        Some(lag) if lag != 0 => add_business_days(date, lag, calendar),
        _ => date,
    }
}

// ---------------------------------------------------------------------------
// FixedLeg (LEG-01)
// ---------------------------------------------------------------------------

/// A leg of fixed-rate accrual periods with optional amortization.
///
/// Constructs FixedPeriods from a Schedule and aggregates NPV, analytic delta,
/// and cashflow rows across all periods and notional exchanges.
#[derive(Clone, Serialize, Deserialize)]
pub struct FixedLeg {
    pub periods: Vec<FixedPeriod>,
    pub cashflow_periods: Vec<CashflowPeriod>,
    pub currency: String,
}

impl FixedLeg {
    /// Construct a FixedLeg from a Schedule.
    ///
    /// Iterates `schedule.adjusted_dates()` pairwise to create FixedPeriods.
    /// Uses `amortization.notional_schedule()` for per-period notionals.
    /// Generates notional exchange CashflowPeriods for amortization.
    pub fn new(
        schedule: &Schedule,
        fixed_rate: f64,
        notional: f64,
        convention: DayCountConvention,
        currency: String,
        payment_lag: Option<i32>,
        amortization: Amortization,
    ) -> Self {
        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let notionals = amortization.notional_schedule(n, notional);

        let periods: Vec<FixedPeriod> = (0..n)
            .map(|i| FixedPeriod {
                start: dates[i],
                end: dates[i + 1],
                payment: payment_date(dates[i + 1], payment_lag, &schedule.calendar),
                notional: notionals[i],
                fixed_rate,
                convention,
            })
            .collect();

        let cashflow_periods = generate_notional_exchanges(dates, &notionals, &currency);

        FixedLeg {
            periods,
            cashflow_periods,
            currency,
        }
    }

    /// Net present value: sum of all period NPVs + notional exchange NPVs.
    pub fn npv(&self, curve: &dyn CurveQuery) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.npv(curve);
        }
        for cf in &self.cashflow_periods {
            total = total + cf.npv(curve);
        }
        total
    }

    /// Analytic delta: sum of all period analytic deltas.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.analytic_delta(curve);
        }
        total
    }

    /// Collect cashflow rows from all periods and notional exchanges, sorted by payment date.
    pub fn cashflows(&self, curve: Option<&dyn CurveQuery>) -> Vec<CashflowRow> {
        let mut rows: Vec<CashflowRow> = Vec::new();
        for p in &self.periods {
            rows.push(p.to_cashflow_row(curve, None, &self.currency));
        }
        for cf in &self.cashflow_periods {
            rows.push(cf.to_cashflow_row(curve, None, &self.currency));
        }
        rows.sort_by_key(|r| r.payment);
        rows
    }
}

// ---------------------------------------------------------------------------
// FloatLeg (LEG-02)
// ---------------------------------------------------------------------------

/// A leg of floating-rate accrual periods with RFR compounding and optional amortization.
#[derive(Clone, Serialize, Deserialize)]
pub struct FloatLeg {
    pub periods: Vec<FloatPeriod>,
    pub cashflow_periods: Vec<CashflowPeriod>,
    pub currency: String,
}

impl FloatLeg {
    /// Construct a FloatLeg from a Schedule.
    pub fn new(
        schedule: &Schedule,
        spread: f64,
        notional: f64,
        convention: DayCountConvention,
        fixing_method: FixingMethod,
        spread_method: SpreadMethod,
        currency: String,
        payment_lag: Option<i32>,
        amortization: Amortization,
    ) -> Self {
        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let notionals = amortization.notional_schedule(n, notional);

        let periods: Vec<FloatPeriod> = (0..n)
            .map(|i| FloatPeriod {
                start: dates[i],
                end: dates[i + 1],
                payment: payment_date(dates[i + 1], payment_lag, &schedule.calendar),
                notional: notionals[i],
                spread,
                convention,
                fixing_method: fixing_method.clone(),
                spread_method: spread_method.clone(),
                calendar: schedule.calendar.clone(),
            })
            .collect();

        let cashflow_periods = generate_notional_exchanges(dates, &notionals, &currency);

        FloatLeg {
            periods,
            cashflow_periods,
            currency,
        }
    }

    /// Net present value: sum of all period NPVs + notional exchange NPVs.
    pub fn npv(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.npv(curve, fixings);
        }
        for cf in &self.cashflow_periods {
            total = total + cf.npv(curve);
        }
        total
    }

    /// Dual-curve NPV: rate from forecast_curve, DF from disc_curve.
    pub fn npv_dual_curve(
        &self,
        forecast_curve: &dyn CurveQuery,
        disc_curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.npv_dual_curve(forecast_curve, disc_curve, fixings);
        }
        for cf in &self.cashflow_periods {
            total = total + cf.npv(disc_curve);
        }
        total
    }

    /// Analytic delta: sum of all period analytic deltas.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.analytic_delta(curve);
        }
        total
    }

    /// Analytic delta using a separate discount curve for DF.
    pub fn analytic_delta_disc(&self, disc_curve: &dyn CurveQuery) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.analytic_delta(disc_curve);
        }
        total
    }

    /// Collect cashflow rows, sorted by payment date.
    pub fn cashflows(
        &self,
        curve: Option<&dyn CurveQuery>,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Vec<CashflowRow> {
        let mut rows: Vec<CashflowRow> = Vec::new();
        for p in &self.periods {
            rows.push(p.to_cashflow_row(curve, fixings, &self.currency));
        }
        for cf in &self.cashflow_periods {
            rows.push(cf.to_cashflow_row(curve, None, &self.currency));
        }
        rows.sort_by_key(|r| r.payment);
        rows
    }
}

// ---------------------------------------------------------------------------
// ZeroFixedLeg (LEG-03)
// ---------------------------------------------------------------------------

/// A zero-coupon fixed-rate leg with a single compounded period.
#[derive(Clone, Serialize, Deserialize)]
pub struct ZeroFixedLeg {
    pub period: ZeroFixedPeriod,
    pub cashflow_periods: Vec<CashflowPeriod>,
    pub currency: String,
}

impl ZeroFixedLeg {
    /// Construct a ZeroFixedLeg.
    ///
    /// Can accept a Schedule (uses first and last dates) or explicit dates.
    pub fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        fixed_rate: f64,
        notional: f64,
        convention: DayCountConvention,
        currency: String,
    ) -> Self {
        let period = ZeroFixedPeriod {
            start,
            end,
            payment,
            notional,
            fixed_rate,
            convention,
        };

        // Notional exchanges: initial and final
        let cashflow_periods = vec![
            CashflowPeriod {
                payment: start,
                notional,
                currency: currency.clone(),
            },
            CashflowPeriod {
                payment: end,
                notional: -notional,
                currency: currency.clone(),
            },
        ];

        ZeroFixedLeg {
            period,
            cashflow_periods,
            currency,
        }
    }

    /// Construct from a Schedule (uses first and last adjusted dates).
    pub fn from_schedule(
        schedule: &Schedule,
        fixed_rate: f64,
        notional: f64,
        convention: DayCountConvention,
        currency: String,
    ) -> Self {
        let dates = schedule.adjusted_dates();
        let start = dates[0];
        let end = *dates.last().unwrap();
        Self::new(start, end, end, fixed_rate, notional, convention, currency)
    }

    /// Net present value.
    pub fn npv(&self, curve: &dyn CurveQuery) -> Number {
        let mut total = self.period.npv(curve);
        for cf in &self.cashflow_periods {
            total = total + cf.npv(curve);
        }
        total
    }

    /// Analytic delta.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        self.period.analytic_delta(curve)
    }

    /// Cashflow rows.
    pub fn cashflows(&self, curve: Option<&dyn CurveQuery>) -> Vec<CashflowRow> {
        let mut rows = vec![
            self.period.to_cashflow_row(curve, None, &self.currency),
        ];
        for cf in &self.cashflow_periods {
            rows.push(cf.to_cashflow_row(curve, None, &self.currency));
        }
        rows.sort_by_key(|r| r.payment);
        rows
    }
}

// ---------------------------------------------------------------------------
// ZeroFloatLeg (LEG-03)
// ---------------------------------------------------------------------------

/// A zero-coupon floating-rate leg with a single RFR-compounded period.
#[derive(Clone, Serialize, Deserialize)]
pub struct ZeroFloatLeg {
    pub period: ZeroFloatPeriod,
    pub cashflow_periods: Vec<CashflowPeriod>,
    pub currency: String,
}

impl ZeroFloatLeg {
    /// Construct a ZeroFloatLeg.
    pub fn new(
        start: NaiveDate,
        end: NaiveDate,
        payment: NaiveDate,
        notional: f64,
        spread: f64,
        convention: DayCountConvention,
        fixing_method: FixingMethod,
        spread_method: SpreadMethod,
        calendar: BusinessCalendar,
        currency: String,
    ) -> Self {
        let period = ZeroFloatPeriod {
            start,
            end,
            payment,
            notional,
            spread,
            convention,
            fixing_method,
            spread_method,
            calendar,
        };

        let cashflow_periods = vec![
            CashflowPeriod {
                payment: start,
                notional,
                currency: currency.clone(),
            },
            CashflowPeriod {
                payment: end,
                notional: -notional,
                currency: currency.clone(),
            },
        ];

        ZeroFloatLeg {
            period,
            cashflow_periods,
            currency,
        }
    }

    /// Construct from a Schedule.
    pub fn from_schedule(
        schedule: &Schedule,
        notional: f64,
        spread: f64,
        convention: DayCountConvention,
        fixing_method: FixingMethod,
        spread_method: SpreadMethod,
        currency: String,
    ) -> Self {
        let dates = schedule.adjusted_dates();
        let start = dates[0];
        let end = *dates.last().unwrap();
        Self::new(
            start,
            end,
            end,
            notional,
            spread,
            convention,
            fixing_method,
            spread_method,
            schedule.calendar.clone(),
            currency,
        )
    }

    /// Net present value.
    pub fn npv(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let mut total = self.period.npv(curve, fixings);
        for cf in &self.cashflow_periods {
            total = total + cf.npv(curve);
        }
        total
    }

    /// Analytic delta.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        self.period.analytic_delta(curve)
    }

    /// Cashflow rows.
    pub fn cashflows(
        &self,
        curve: Option<&dyn CurveQuery>,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Vec<CashflowRow> {
        let mut rows = vec![
            self.period.to_cashflow_row(curve, fixings, &self.currency),
        ];
        for cf in &self.cashflow_periods {
            rows.push(cf.to_cashflow_row(curve, None, &self.currency));
        }
        rows.sort_by_key(|r| r.payment);
        rows
    }
}

// ---------------------------------------------------------------------------
// CustomLeg (LEG-05)
// ---------------------------------------------------------------------------

/// A leg with arbitrary heterogeneous period types via the Period enum.
///
/// Useful for non-standard instruments or manual period construction.
#[derive(Clone, Serialize, Deserialize)]
pub struct CustomLeg {
    pub periods: Vec<Period>,
    pub currency: String,
}

impl CustomLeg {
    /// Construct a CustomLeg from arbitrary Period instances.
    pub fn new(periods: Vec<Period>, currency: String) -> Self {
        CustomLeg { periods, currency }
    }

    /// Net present value: sum across all periods.
    pub fn npv(
        &self,
        curve: &dyn CurveQuery,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.npv(curve, fixings, None);
        }
        total
    }

    /// Analytic delta: sum across all periods.
    pub fn analytic_delta(&self, curve: &dyn CurveQuery) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.periods {
            total = total + p.analytic_delta(curve);
        }
        total
    }

    /// Cashflow rows from all periods, sorted by payment date.
    pub fn cashflows(
        &self,
        curve: Option<&dyn CurveQuery>,
        fixings: Option<&HashMap<NaiveDate, f64>>,
    ) -> Vec<CashflowRow> {
        let mut rows: Vec<CashflowRow> = self
            .periods
            .iter()
            .map(|p| p.to_cashflow_row(curve, fixings, &self.currency))
            .collect();
        rows.sort_by_key(|r| r.payment);
        rows
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::calendar::convention::DayCountConvention;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    #[test]
    fn test_generate_notional_exchanges_no_amort() {
        let dates = vec![ymd(2024, 1, 1), ymd(2024, 7, 1), ymd(2025, 1, 1)];
        let notionals = vec![1_000_000.0, 1_000_000.0];
        let exchanges = generate_notional_exchanges(&dates, &notionals, "USD");

        // Initial + final = 2 exchanges (no intermediate since notional is constant)
        assert_eq!(exchanges.len(), 2);
        assert_eq!(exchanges[0].notional, 1_000_000.0); // receive
        assert_eq!(exchanges[1].notional, -1_000_000.0); // return
    }

    #[test]
    fn test_generate_notional_exchanges_amortizing() {
        let dates = vec![
            ymd(2024, 1, 1),
            ymd(2024, 7, 1),
            ymd(2025, 1, 1),
            ymd(2025, 7, 1),
        ];
        let notionals = vec![1_000_000.0, 800_000.0, 600_000.0];
        let exchanges = generate_notional_exchanges(&dates, &notionals, "USD");

        // Initial + 2 intermediate + final = 4
        assert_eq!(exchanges.len(), 4);
        assert_eq!(exchanges[0].notional, 1_000_000.0); // receive 1M
        assert_eq!(exchanges[1].notional, -200_000.0); // return 200k diff
        assert_eq!(exchanges[2].notional, -200_000.0); // return 200k diff
        assert_eq!(exchanges[3].notional, -600_000.0); // return remaining
    }

    #[test]
    fn test_zero_fixed_leg() {
        let curve = test_curve();
        let leg = ZeroFixedLeg::new(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            ymd(2025, 1, 1),
            5.0,
            1_000_000.0,
            DayCountConvention::Act365F,
            "USD".to_string(),
        );

        let npv = leg.npv(&curve);
        // Should include period NPV + notional exchanges
        match npv {
            Number::F64(v) => assert!(v.is_finite(), "NPV should be finite, got {v}"),
            _ => panic!("Expected F64"),
        }

        let delta = leg.analytic_delta(&curve);
        match delta {
            Number::F64(v) => assert!(v < 0.0, "Delta should be negative for pay leg"),
            _ => panic!("Expected F64"),
        }

        let rows = leg.cashflows(Some(&curve));
        assert!(rows.len() >= 2, "Should have period + exchange rows");
    }

    #[test]
    fn test_custom_leg_mixed_periods() {
        let curve = test_curve();
        let periods = vec![
            Period::Fixed(FixedPeriod {
                start: ymd(2024, 1, 1),
                end: ymd(2024, 7, 1),
                payment: ymd(2024, 7, 1),
                notional: 1_000_000.0,
                fixed_rate: 5.0,
                convention: DayCountConvention::Act365F,
            }),
            Period::Cashflow(CashflowPeriod {
                payment: ymd(2025, 1, 1),
                notional: 500_000.0,
                currency: "USD".to_string(),
            }),
        ];

        let leg = CustomLeg::new(periods, "USD".to_string());
        let npv = leg.npv(&curve, None);
        match npv {
            Number::F64(v) => assert!(v.is_finite()),
            _ => panic!("Expected F64"),
        }

        let rows = leg.cashflows(Some(&curve), None);
        assert_eq!(rows.len(), 2);
    }
}
