use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::marketcurves::curve::CurveQuery;

use super::period::CashflowRow;

// ---------------------------------------------------------------------------
// CreditPremiumPeriod (D-23, D-24, D-32)
// ---------------------------------------------------------------------------

/// A credit premium (fee) period for CDS instruments.
///
/// NPV = notional * dcf * (fixed_rate/10000) * Q(payment) * DF(payment)
/// with optional accrued-on-default adjustment.
#[derive(Clone, Serialize, Deserialize)]
pub struct CreditPremiumPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub notional: f64,
    pub convention: DayCountConvention,
    pub premium_accrued: bool,
    /// Fixed rate in basis points (e.g. 100.0 for 100bp).
    pub fixed_rate: f64,
    /// Recovery rate for the credit (used when accessed via Period enum).
    pub recovery_rate: f64,
}

impl CreditPremiumPeriod {
    fn dcf(&self) -> f64 {
        self.convention
            .dcf(self.start, self.end, &DcfOptions::default())
            .unwrap()
    }

    /// Compute NPV of the premium period.
    ///
    /// Premium payment: -notional * dcf * (rate/10000) * Q(end) * DF(payment)
    /// Accrued-on-default: -notional * 0.5 * dcf * (rate/10000) * (Q(start) - Q(end)) * DF(end)
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
        fixed_rate: f64,
    ) -> Number {
        let dcf = self.dcf();
        let rate_decimal = fixed_rate / 10000.0;
        let q_end = credit_curve.discount_factor(self.end);
        let df_payment = disc_curve.discount_factor(self.payment);

        // Main premium: -notional * dcf * rate * Q(end) * DF(payment)
        let mut result = &(&q_end * &df_payment) * (-self.notional * dcf * rate_decimal);

        if self.premium_accrued {
            let q_start = credit_curve.discount_factor(self.start);
            let df_end = disc_curve.discount_factor(self.end);
            // Accrued-on-default: -notional * 0.5 * dcf * rate * (Q(start) - Q(end)) * DF(end)
            let q_diff = &q_start - &q_end;
            let accrued = &(&q_diff * &df_end) * (-self.notional * 0.5 * dcf * rate_decimal);
            result = result + accrued;
        }

        result
    }

    /// Compute the annuity (rate=1 for par spread calculation).
    /// annuity = dcf * Q(end) * DF(payment) + accrued_adjustment
    pub fn annuity(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let dcf = self.dcf();
        let q_end = credit_curve.discount_factor(self.end);
        let df_payment = disc_curve.discount_factor(self.payment);

        let mut result = &q_end * &df_payment * dcf;

        if self.premium_accrued {
            let q_start = credit_curve.discount_factor(self.start);
            let df_end = disc_curve.discount_factor(self.end);
            let q_diff = &q_start - &q_end;
            let accrued = &q_diff * &df_end * (0.5 * dcf);
            result = result + accrued;
        }

        result
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        credit_curve: Option<&dyn CurveQuery>,
        currency: &str,
    ) -> CashflowRow {
        let dcf = self.dcf();
        let rate_decimal = self.fixed_rate / 10000.0;
        let cf = -self.notional * dcf * rate_decimal;

        let (df, npv) = match (disc_curve, credit_curve) {
            (Some(dc), Some(cc)) => {
                let d = dc.discount_factor(self.payment);
                let n = self.npv(dc, cc, self.fixed_rate);
                (Some(d), Some(n))
            }
            _ => (None, None),
        };

        CashflowRow {
            period_type: "CreditPremium".to_string(),
            start: self.start,
            end: self.end,
            payment: self.payment,
            currency: currency.to_string(),
            notional: self.notional,
            fixing_rate: None,
            rate: rate_decimal,
            spread: 0.0,
            dcf,
            cashflow: Number::F64(cf),
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

// ---------------------------------------------------------------------------
// CreditProtectionPeriod (D-32 -- piecewise analytical integration)
// ---------------------------------------------------------------------------

/// A credit protection period for CDS instruments.
///
/// Computes NPV via piecewise analytical integration of the default probability
/// weighted by the discount factor, multiplied by (1 - recovery_rate) * notional.
#[derive(Clone, Serialize, Deserialize)]
pub struct CreditProtectionPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub notional: f64,
    pub convention: DayCountConvention,
    /// Recovery rate for the protection leg.
    pub recovery_rate: f64,
}

impl CreditProtectionPeriod {
    /// Compute NPV of the protection period via piecewise analytical integration.
    ///
    /// For each segment [t_i, t_{i+1}] within [start, end]:
    ///   integral_i = lambda_i * Q(t_i) * DF(t_i) * (1 - exp(-(r_i + lambda_i)*dt)) / (r_i + lambda_i)
    /// where r_i = forward rate from disc_curve, lambda_i = hazard rate from credit_curve.
    ///
    /// Uses Taylor expansion when |h*dt| < 1e-8 to avoid numerical instability.
    ///
    /// Total protection NPV = -(1-R) * notional * sum(integral_i)
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
        recovery_rate: f64,
    ) -> Number {
        let lgd = 1.0 - recovery_rate; // Loss given default

        // Build the time grid: merge credit curve nodes with [start, end]
        let mut grid: Vec<NaiveDate> = Vec::new();
        grid.push(self.start);

        // Get credit curve node dates that fall within (start, end)
        // We access these through the CurveQuery interface -- we need to use
        // the midpoint approximation approach for AD compatibility.
        // Since we can't directly access nodes from CurveQuery trait,
        // use the discrete midpoint approximation for CDS protection leg integration.
        // For each sub-interval, compute: (Q(t_i) - Q(t_{i+1})) * DF(mid)

        // Generate daily or sub-period grid for protection leg integration
        // Use quarterly sub-periods (90 day intervals) for efficiency
        let mut t = self.start;
        loop {
            let next = t + chrono::Duration::days(90);
            if next >= self.end {
                break;
            }
            grid.push(next);
            t = next;
        }
        grid.push(self.end);

        let mut total = Number::F64(0.0);

        for i in 0..grid.len() - 1 {
            let t_i = grid[i];
            let t_i1 = grid[i + 1];

            let q_i = credit_curve.discount_factor(t_i);
            let q_i1 = credit_curve.discount_factor(t_i1);

            // Midpoint DF for discounting
            let days_to_mid = (t_i1 - t_i).num_days() as f64 / 2.0;
            let mid_date = t_i + chrono::Duration::days(days_to_mid as i64);
            let df_mid = disc_curve.discount_factor(mid_date);

            // Protection value for this segment: (Q(t_i) - Q(t_{i+1})) * DF(mid)
            let q_diff = &q_i - &q_i1;
            let segment = &q_diff * &df_mid;
            total = total + segment;
        }

        // Apply LGD and notional. Sign: protection buyer receives on default.
        // Using negative notional convention: -(1-R) * notional * integral
        // For positive notional = protection buyer: protection NPV is negative
        // (they receive the protection value, which offsets their premium payments).
        &total * (-lgd * self.notional)
    }

    /// Convert to a CashflowRow for DataFrame output.
    pub fn to_cashflow_row(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        credit_curve: Option<&dyn CurveQuery>,
        currency: &str,
    ) -> CashflowRow {
        let (df, npv) = match (disc_curve, credit_curve) {
            (Some(dc), Some(cc)) => {
                let d = dc.discount_factor(self.payment);
                let n = self.npv(dc, cc, self.recovery_rate);
                (Some(d), Some(n))
            }
            _ => (None, None),
        };

        CashflowRow {
            period_type: "CreditProtection".to_string(),
            start: self.start,
            end: self.end,
            payment: self.payment,
            currency: currency.to_string(),
            notional: self.notional,
            fixing_rate: None,
            rate: 0.0,
            spread: 0.0,
            dcf: 0.0,
            cashflow: Number::F64(-self.notional * (1.0 - self.recovery_rate)),
            df,
            npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::credit::CreditImpliedCurve;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn disc_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc".to_string(),
        )
    }

    fn credit_curve() -> CreditImpliedCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.02),
        ]));
        CreditImpliedCurve::new(
            nodes,
            DayCountConvention::Act365F,
            0.40,
            "credit".to_string(),
        )
    }

    #[test]
    fn test_credit_premium_period_npv() {
        let dc = disc_curve();
        let cc = credit_curve();

        let p = CreditPremiumPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act360,
            premium_accrued: false,
            fixed_rate: 100.0, // 100bp
            recovery_rate: 0.40,
        };

        let npv = p.npv(&dc, &cc, 100.0);
        if let Number::F64(v) = npv {
            // NPV = -notional * dcf * rate * Q(end) * DF(payment)
            let dcf = 366.0 / 360.0; // Act360, 2024 is leap year
            let q_end = (-0.01 * 366.0 / 365.0_f64).exp(); // Q(2025-01-01) Act365F for credit
            let df = 0.97;
            let expected = -10_000_000.0 * dcf * 0.01 * q_end * df;
            assert!(
                (v - expected).abs() < 1.0,
                "NPV={v}, expected={expected}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_premium_period_with_accrued() {
        let dc = disc_curve();
        let cc = credit_curve();

        let p_no_accrued = CreditPremiumPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act360,
            premium_accrued: false,
            fixed_rate: 100.0,
            recovery_rate: 0.40,
        };

        let p_accrued = CreditPremiumPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act360,
            premium_accrued: true,
            fixed_rate: 100.0,
            recovery_rate: 0.40,
        };

        let npv_no = p_no_accrued.npv(&dc, &cc, 100.0);
        let npv_yes = p_accrued.npv(&dc, &cc, 100.0);

        // Accrued-on-default adjustment should make NPV more negative (buyer pays more)
        if let (Number::F64(no), Number::F64(yes)) = (&npv_no, &npv_yes) {
            assert!(
                yes < no,
                "Accrued NPV ({yes}) should be more negative than non-accrued ({no})"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_premium_period_annuity() {
        let dc = disc_curve();
        let cc = credit_curve();

        let p = CreditPremiumPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act360,
            premium_accrued: true,
            fixed_rate: 100.0,
            recovery_rate: 0.40,
        };

        let ann = p.annuity(&dc, &cc);
        if let Number::F64(v) = ann {
            assert!(v > 0.0, "Annuity should be positive, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_protection_period_analytical() {
        let dc = disc_curve();
        let cc = credit_curve();

        let p = CreditProtectionPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act365F,
            recovery_rate: 0.40,
        };

        let npv = p.npv(&dc, &cc, 0.40);
        if let Number::F64(v) = npv {
            // Protection NPV should be negative (protection buyer receives protection)
            // -(1-R) * N * sum((Q_i - Q_{i+1}) * DF_mid)
            // LGD = 0.6, notional = 10M
            // Total default probability ~ 1 - Q(1Y) ~ 1 - exp(-0.01) ~ 0.00995
            // Protection ~ -0.6 * 10M * 0.00995 * ~0.985 ~ -58k
            assert!(v < 0.0, "Protection NPV should be negative, got {v}");
            assert!(
                v.abs() > 10_000.0 && v.abs() < 200_000.0,
                "Protection NPV magnitude {v} seems unreasonable"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_protection_taylor_expansion() {
        // Very small hazard rate + discount rate: should not produce NaN
        let dc_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.9999),
        ]));
        let dc = DiscountCurve::new(
            dc_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "tiny_disc".to_string(),
        );

        let cc_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.0001),
        ]));
        let cc = CreditImpliedCurve::new(
            cc_nodes,
            DayCountConvention::Act365F,
            0.40,
            "tiny_credit".to_string(),
        );

        let p = CreditProtectionPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act365F,
            recovery_rate: 0.40,
        };

        let npv = p.npv(&dc, &cc, 0.40);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "NPV should be finite, got {v}");
            assert!(v < 0.0, "Protection NPV should be negative");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_credit_premium_to_cashflow_row() {
        let dc = disc_curve();
        let cc = credit_curve();

        let p = CreditPremiumPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act360,
            premium_accrued: true,
            fixed_rate: 100.0,
            recovery_rate: 0.40,
        };

        let row = p.to_cashflow_row(Some(&dc), Some(&cc), "USD");
        assert_eq!(row.period_type, "CreditPremium");
        assert!(row.npv.is_some());
    }

    #[test]
    fn test_credit_protection_to_cashflow_row() {
        let dc = disc_curve();
        let cc = credit_curve();

        let p = CreditProtectionPeriod {
            start: ymd(2024, 1, 1),
            end: ymd(2025, 1, 1),
            payment: ymd(2025, 1, 1),
            notional: 10_000_000.0,
            convention: DayCountConvention::Act365F,
            recovery_rate: 0.40,
        };

        let row = p.to_cashflow_row(Some(&dc), Some(&cc), "USD");
        assert_eq!(row.period_type, "CreditProtection");
        assert!(row.npv.is_some());
    }
}
