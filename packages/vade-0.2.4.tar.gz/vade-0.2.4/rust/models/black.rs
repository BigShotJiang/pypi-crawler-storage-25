//! Black-76 and Bachelier (normal) option pricing models.

use serde::{Deserialize, Serialize};

use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;

/// Volatility model for cap/floor pricing.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum VolModel {
    Black76,
    Bachelier,
}

/// Standard normal PDF: phi(x) = exp(-x^2/2) / sqrt(2*pi).
/// Implemented on Number for AD support.
fn norm_pdf(x: &Number) -> Number {
    let neg_half_x_sq = x * x * (-0.5);
    neg_half_x_sq.exp() * (1.0 / (2.0 * std::f64::consts::PI).sqrt())
}

/// Black-76 caplet/floorlet value (undiscounted, per unit notional, per unit dcf).
///
/// Returns the option value for a single caplet or floorlet.
/// All arithmetic on Number for AD propagation.
pub fn black76_caplet(
    forward: &Number,
    strike_decimal: f64,
    vol: f64,
    t: f64,
    is_cap: bool,
) -> Number {
    // Edge case: expired or at expiry
    if t <= 0.0 {
        let intrinsic = if is_cap {
            forward - strike_decimal
        } else {
            strike_decimal - forward
        };
        // max(intrinsic, 0) -- extract real and clamp
        let real_val = match &intrinsic {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        if real_val > 0.0 {
            return intrinsic;
        } else {
            return Number::F64(0.0);
        }
    }

    let vol_sqrt_t = vol * t.sqrt();

    // d1 = (ln(F) - ln(K) + 0.5 * vol^2 * t) / (vol * sqrt(t))
    let d1 = (forward.log() - Number::F64(strike_decimal.ln())
        + Number::F64(0.5 * vol * vol * t))
        / vol_sqrt_t;
    let d2 = &d1 - vol_sqrt_t;

    if is_cap {
        // Cap: F * N(d1) - K * N(d2)
        forward * &d1.norm_cdf() - strike_decimal * d2.norm_cdf()
    } else {
        // Floor: K * N(-d2) - F * N(-d1)
        strike_decimal * (-d2).norm_cdf() - forward * &(-d1).norm_cdf()
    }
}

/// Bachelier (normal model) caplet/floorlet value (undiscounted, per unit notional, per unit dcf).
pub fn bachelier_caplet(
    forward: &Number,
    strike_decimal: f64,
    vol: f64,
    t: f64,
    is_cap: bool,
) -> Number {
    if t <= 0.0 {
        let intrinsic = if is_cap {
            forward - strike_decimal
        } else {
            strike_decimal - forward
        };
        let real_val = match &intrinsic {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        if real_val > 0.0 {
            return intrinsic;
        } else {
            return Number::F64(0.0);
        }
    }

    let vol_sqrt_t = vol * t.sqrt();
    // d = (F - K) / (vol * sqrt(t))
    let d = (forward - strike_decimal) / vol_sqrt_t;
    let nd = d.norm_cdf();
    let npd = norm_pdf(&d);

    if is_cap {
        // Cap: (F - K) * N(d) + vol*sqrt(t) * n(d)
        (forward - strike_decimal) * nd + vol_sqrt_t * npd
    } else {
        // Floor: (K - F) * N(-d) + vol*sqrt(t) * n(d)
        (strike_decimal - forward) * (-d).norm_cdf() + vol_sqrt_t * npd
    }
}
