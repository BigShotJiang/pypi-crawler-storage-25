pub mod bootstrap;
pub mod result;
pub mod risk;
pub mod py;

use std::sync::Arc;
use std::time::Instant;
use indexmap::IndexSet;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::autodiff::linalg::dsolve_f64;
use crate::marketcurves::curve::{CurveQuery, DiscountCurve, LineCurve};
use crate::marketcurves::credit::CreditImpliedCurve;
use crate::marketcurves::forward_curve::ForwardCurve;
use crate::marketcurves::fx::rates::FXRates;
use crate::instruments::Instrument;

use result::SolverResult;

/// Reference to a curve owned by the solver.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum CurveRef {
    Discount(DiscountCurve),
    Line(LineCurve),
    CreditImplied(CreditImpliedCurve),
    Forward(ForwardCurve),
}

impl CurveRef {
    /// Get the number of solver variables for this curve.
    pub(crate) fn n_vars(&self) -> usize {
        match self {
            CurveRef::Discount(c) => c.n_vars(),
            CurveRef::Line(c) => c.n_vars(),
            CurveRef::CreditImplied(c) => c.n_vars(),
            CurveRef::Forward(c) => c.n_vars(),
        }
    }

    /// Get the ini_solve offset.
    pub(crate) fn ini_solve(&self) -> usize {
        match self {
            CurveRef::Discount(c) => c.ini_solve(),
            CurveRef::Line(c) => c.ini_solve(),
            CurveRef::CreditImplied(c) => c.ini_solve(),
            CurveRef::Forward(c) => c.ini_solve(),
        }
    }

    /// Get all node values as f64.
    pub(crate) fn get_node_values(&self) -> Vec<f64> {
        match self {
            CurveRef::Discount(c) => c.get_node_values(),
            CurveRef::Line(c) => c.get_node_values(),
            CurveRef::CreditImplied(c) => c.get_node_values(),
            CurveRef::Forward(c) => c.get_node_values(),
        }
    }

    /// Total number of nodes.
    #[allow(dead_code)]
    fn n_nodes(&self) -> usize {
        match self {
            CurveRef::Discount(c) => c.nodes.len(),
            CurveRef::Line(c) => c.nodes.len(),
            CurveRef::CreditImplied(c) => c.nodes.len(),
            CurveRef::Forward(c) => c.nodes.len(),
        }
    }

    /// Set node values as Dual for AD.
    #[allow(dead_code)]
    fn set_values_as_dual(&mut self, values: &[f64], var_names: Arc<IndexSet<String>>, ini_solve: usize) {
        match self {
            CurveRef::Discount(c) => c.nodes.set_values_as_dual(values, var_names, ini_solve),
            CurveRef::Line(c) => c.nodes.set_values_as_dual(values, var_names, ini_solve),
            CurveRef::CreditImplied(c) => c.nodes.set_values_as_dual(values, var_names, ini_solve),
            CurveRef::Forward(c) => c.nodes.set_values_as_dual(values, var_names, ini_solve),
        }
    }

    /// Set node values back to f64.
    fn set_values_as_f64(&mut self, values: &[f64]) {
        match self {
            CurveRef::Discount(c) => c.nodes.set_values_as_f64(values),
            CurveRef::Line(c) => c.nodes.set_values_as_f64(values),
            CurveRef::CreditImplied(c) => c.nodes.set_values_as_f64(values),
            CurveRef::Forward(c) => c.nodes.set_values_as_f64(values),
        }
    }

    /// Get a CurveQuery reference.
    pub(crate) fn as_curve_query(&self) -> &dyn CurveQuery {
        match self {
            CurveRef::Discount(c) => c,
            CurveRef::Line(c) => c,
            CurveRef::CreditImplied(c) => c,
            CurveRef::Forward(c) => c,
        }
    }

    /// Get the curve ID.
    fn id(&self) -> &str {
        match self {
            CurveRef::Discount(c) => &c.id,
            CurveRef::Line(c) => &c.id,
            CurveRef::CreditImplied(c) => &c.id,
            CurveRef::Forward(c) => &c.id,
        }
    }
}

/// An instrument entry in the solver, binding an instrument to curves and a target rate.
#[derive(Clone, Serialize, Deserialize)]
pub struct InstrumentEntry {
    pub instrument: Instrument,
    pub target: f64,
    pub disc_curve_idx: usize,
    pub forecast_curve_idx: Option<usize>,
    /// Human-readable label for risk reports (e.g., "5Y_IRS").
    pub label: String,
    /// Currency code for risk reports (e.g., "USD").
    pub currency: String,
    /// Leg2 discount curve index for XCS 4-curve model.
    pub leg2_disc_curve_idx: Option<usize>,
    /// Leg2 forecast curve index for XCS 4-curve model.
    pub leg2_forecast_curve_idx: Option<usize>,
}

/// Optimization algorithm for curve calibration.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Algorithm {
    /// Levenberg-Marquardt with damping parameters (lambda_init, success_scale, failure_scale).
    LevenbergMarquardt { ini_lambda: (f64, f64, f64) },
    /// Gauss-Newton (undamped least squares). Fails on singular J^T*J.
    GaussNewton,
    /// Gradient descent with Armijo backtracking line search.
    GradientDescent { learning_rate: f64 },
}

impl Default for Algorithm {
    fn default() -> Self {
        Algorithm::LevenbergMarquardt { ini_lambda: (1.0, 0.5, 2.0) }
    }
}

impl Algorithm {
    /// Human-readable name for SolverResult.
    pub fn name(&self) -> &'static str {
        match self {
            Algorithm::LevenbergMarquardt { .. } => "levenberg_marquardt",
            Algorithm::GaussNewton => "gauss_newton",
            Algorithm::GradientDescent { .. } => "gradient_descent",
        }
    }
}

/// Solver for curve calibration with selectable algorithm.
#[derive(Clone, Serialize, Deserialize)]
pub struct Solver {
    pub curves: Vec<CurveRef>,
    pub instruments: Vec<InstrumentEntry>,
    pub weights: Vec<f64>,
    pub func_tol: f64,
    pub grad_tol: f64,
    pub max_iter: usize,
    /// Optimization algorithm (default: Levenberg-Marquardt).
    #[serde(default)]
    pub algorithm: Algorithm,
    pub pre_solvers: Vec<Solver>,
    /// Optional FX rates for cross-currency instruments (D-48).
    pub fx_rates: Option<FXRates>,
}

impl Solver {
    /// Create a new solver with default tolerances.
    pub fn new() -> Self {
        Self {
            curves: Vec::new(),
            instruments: Vec::new(),
            weights: Vec::new(),
            func_tol: 1e-14,
            grad_tol: 1e-14,
            max_iter: 100,
            algorithm: Algorithm::default(),
            pre_solvers: Vec::new(),
            fx_rates: None,
        }
    }

    /// Total number of solver variables across all curves (excluding FX rates).
    /// FX rates are included in the Jacobian for sensitivity but not updated during LM solve.
    pub fn total_curve_vars(&self) -> usize {
        self.curves.iter().map(|c| c.n_vars()).sum()
    }

    /// Total number of AD variables (curves + FX rates) for Jacobian dimensions.
    pub fn total_vars(&self) -> usize {
        let curve_vars: usize = self.curves.iter().map(|c| c.n_vars()).sum();
        let fx_vars = self.fx_rates.as_ref().map(|fxr| fxr.n_fx_vars()).unwrap_or(0);
        curve_vars + fx_vars
    }

    /// Collect all current f64 values for solver variables (skipping ini_solve nodes).
    fn collect_var_values(&self) -> Vec<f64> {
        let mut vals = Vec::new();
        for cr in &self.curves {
            let all = cr.get_node_values();
            let ini = cr.ini_solve();
            vals.extend_from_slice(&all[ini..]);
        }
        vals
    }

    /// Build unified variable names across all curves (and FX rates if present).
    pub fn build_var_names(&self) -> Arc<IndexSet<String>> {
        let mut names = IndexSet::new();
        for cr in &self.curves {
            let n_v = cr.n_vars();
            let id = cr.id();
            for i in 0..n_v {
                names.insert(format!("{}{}", id, i));
            }
        }
        // Include FX rate variable names for cross-currency AD (D-49)
        if let Some(fxr) = &self.fx_rates {
            for name in fxr.var_names() {
                names.insert(name);
            }
        }
        Arc::new(names)
    }

    /// Set all curves to Dual mode with unified AD variables.
    /// Also sets FX rates as Dual if fx_rates is present (D-49).
    fn set_curves_dual(&mut self, var_names: &Arc<IndexSet<String>>) {
        let mut var_offset = 0;
        for cr in &mut self.curves {
            let all_vals = cr.get_node_values();
            let ini = cr.ini_solve();
            let n_v = cr.n_vars();
            cr.set_values_as_dual_offset(&all_vals, Arc::clone(var_names), ini, var_offset);
            var_offset += n_v;
        }
        // Set FX rates as Dual variables at offset after all curve variables (D-49)
        if let Some(fxr) = &mut self.fx_rates {
            fxr.set_rates_as_dual(Arc::clone(var_names), var_offset);
        }
    }

    /// Compute instrument rates using current curve state.
    fn compute_rates(&self) -> Vec<Number> {
        self.instruments.iter().map(|entry| {
            let disc = self.curves[entry.disc_curve_idx].as_curve_query();
            let forecast = entry.forecast_curve_idx
                .map(|idx| self.curves[idx].as_curve_query())
                .unwrap_or(disc);
            let leg2_disc = entry.leg2_disc_curve_idx
                .map(|idx| self.curves[idx].as_curve_query());
            let leg2_forecast = entry.leg2_forecast_curve_idx
                .map(|idx| self.curves[idx].as_curve_query());
            entry.instrument.rate(disc, forecast, self.fx_rates.as_ref(), leg2_disc, leg2_forecast)
        }).collect()
    }

    /// Auto flat-rate initial guess: if all curve values look uninitialized,
    /// set DFs to exp(-avg_rate * dcf) for discount curves.
    fn auto_initial_guess(&mut self) {
        if self.instruments.is_empty() {
            return;
        }
        let avg_target_raw: f64 = self.instruments.iter().map(|e| e.target).sum::<f64>()
            / self.instruments.len() as f64;
        // Convert from percentage to decimal if rates look like percentages (> 0.1)
        let avg_target = if avg_target_raw.abs() > 0.1 {
            avg_target_raw / 100.0
        } else {
            avg_target_raw
        };

        for cr in &mut self.curves {
            let vals = cr.get_node_values();
            let ini = cr.ini_solve();
            // Check if values look like defaults (all 1.0 for discount, all 0.0 for line)
            let is_default = match cr {
                CurveRef::Discount(_) => vals[ini..].iter().all(|&v| (v - 1.0).abs() < 1e-12),
                CurveRef::Line(_) => vals[ini..].iter().all(|&v| v.abs() < 1e-12),
                CurveRef::CreditImplied(_) => vals[ini..].iter().all(|&v| v.abs() < 1e-12),
                CurveRef::Forward(_) => vals[ini..].iter().all(|&v| v.abs() < 1e-12),
            };
            if is_default {
                match cr {
                    CurveRef::Discount(c) => {
                        let keys = c.nodes.keys();
                        let base = keys[0];
                        let mut new_vals = vals.clone();
                        for i in ini..new_vals.len() {
                            let days = (keys[i] - base).num_days() as f64;
                            let dcf = days / 365.25;
                            new_vals[i] = (-avg_target * dcf).exp();
                        }
                        c.nodes.set_values_as_f64(&new_vals);
                    }
                    CurveRef::Line(c) => {
                        let mut new_vals = vals.clone();
                        for i in ini..new_vals.len() {
                            new_vals[i] = avg_target;
                        }
                        c.nodes.set_values_as_f64(&new_vals);
                    }
                    CurveRef::CreditImplied(c) => {
                        // Initialize hazard rates with target (already decimal for CDS)
                        let mut new_vals = vals.clone();
                        for i in ini..new_vals.len() {
                            new_vals[i] = avg_target;
                        }
                        c.nodes.set_values_as_f64(&new_vals);
                    }
                    CurveRef::Forward(c) => {
                        // Initialize forward rates with avg_target (flat forward rate curve)
                        let keys = c.nodes.keys();
                        let _base = keys[0];
                        let mut new_vals = vals.clone();
                        // Convert annual rate to per-day rate for ForwardCurve
                        // The x-axis is num_days_from_ce, so rates need to be per-day
                        for i in ini..new_vals.len() {
                            new_vals[i] = avg_target;
                        }
                        c.set_node_values(&new_vals);
                    }
                }
            }
        }
    }

    /// Distribute a parameter delta vector back to curves.
    fn apply_delta(&mut self, v_old: &[f64], delta: &[f64]) {
        let mut offset = 0;
        for cr in &mut self.curves {
            let all_vals = cr.get_node_values();
            let ini = cr.ini_solve();
            let n_v = cr.n_vars();
            let mut new_vals = all_vals.clone();
            for i in 0..n_v {
                new_vals[ini + i] = v_old[offset + i] + delta[offset + i];
            }
            cr.set_values_as_f64(&new_vals);
            offset += n_v;
        }
    }

    /// Restore solver variable values from a saved vector.
    fn restore_values(&mut self, v_old: &[f64]) {
        let mut offset = 0;
        for cr in &mut self.curves {
            let all_vals = cr.get_node_values();
            let ini = cr.ini_solve();
            let n_v = cr.n_vars();
            let mut new_vals = all_vals.clone();
            for i in 0..n_v {
                new_vals[ini + i] = v_old[offset + i];
            }
            cr.set_values_as_f64(&new_vals);
            offset += n_v;
        }
    }

    /// Set all curves to Dual2 mode with unified AD variables (for gamma computation).
    #[allow(dead_code)]
    fn set_curves_dual2(&mut self, var_names: &Arc<IndexSet<String>>) {
        let mut var_offset = 0;
        for cr in &mut self.curves {
            let all_vals = cr.get_node_values();
            let ini = cr.ini_solve();
            let n_v = cr.n_vars();
            cr.set_values_as_dual2_offset(&all_vals, Arc::clone(var_names), ini, var_offset);
            var_offset += n_v;
        }
    }

    /// Compute delta risk for an instrument using the last iterate() Jacobian.
    /// Returns Vec<f64> of sensitivities per calibrating instrument.
    pub fn delta(
        &self,
        instrument: &Instrument,
        jacobian: &[Vec<f64>],
    ) -> Vec<f64> {
        risk::compute_delta(self, instrument, jacobian)
    }

    /// Compute gamma risk (cross-gamma matrix) for an instrument via Dual2.
    /// Returns n_instruments x n_instruments matrix.
    pub fn gamma(
        &self,
        instrument: &Instrument,
        jacobian: &[Vec<f64>],
    ) -> Vec<Vec<f64>> {
        risk::compute_gamma(self, instrument, jacobian)
    }

    /// Export risk sensitivities as a structured report.
    pub fn risk_report(
        &self,
        instrument: &Instrument,
        jacobian: &[Vec<f64>],
    ) -> risk::RiskReport {
        let deltas = self.delta(instrument, jacobian);
        let gammas = self.gamma(instrument, jacobian);
        risk::RiskReport { deltas, gammas }
    }

    /// Run the solver with the selected algorithm.
    pub fn iterate(&mut self) -> SolverResult {
        let timer = Instant::now();

        // Step a: Run pre-solvers
        for ps in &mut self.pre_solvers {
            ps.iterate();
        }

        let n_instruments = self.instruments.len();
        let n_vars = self.total_vars(); // includes FX vars for Jacobian
        let n_curve_vars = self.total_curve_vars(); // only curve vars for LM update

        if n_instruments == 0 || n_curve_vars == 0 {
            return SolverResult {
                converged: true,
                iterations: 0,
                objective: 0.0,
                residuals: vec![],
                jacobian: vec![],
                condition_number: 0.0,
                status: "No instruments or variables".to_string(),
                time_seconds: timer.elapsed().as_secs_f64(),
                algorithm: self.algorithm.name().to_string(),
            };
        }

        // Ensure weights
        if self.weights.is_empty() {
            self.weights = vec![1.0; n_instruments];
        }

        // Step c: Auto initial guess
        self.auto_initial_guess();

        let var_names = self.build_var_names();

        // Extract algorithm-specific state before loop
        let algo = self.algorithm.clone();
        let (mut lambda, success_scale, failure_scale) = match &algo {
            Algorithm::LevenbergMarquardt { ini_lambda } => *ini_lambda,
            _ => (0.0, 0.0, 0.0), // unused for non-LM
        };

        let mut g_prev = f64::INFINITY;
        let mut final_jacobian: Vec<Vec<f64>> = vec![vec![0.0; n_vars]; n_instruments];
        let mut final_residuals: Vec<f64> = vec![0.0; n_instruments];
        let mut converged = false;
        let mut status = String::new();
        let mut iterations = 0;

        for iter in 0..self.max_iter {
            iterations = iter + 1;

            // Set curves to Dual mode
            self.set_curves_dual(&var_names);

            // Compute instrument rates
            let rates = self.compute_rates();

            // Extract residuals and Jacobian
            let mut x = vec![0.0; n_instruments];
            let mut j_matrix: Vec<Vec<f64>> = vec![vec![0.0; n_vars]; n_instruments];

            for (i, (rate, entry)) in rates.iter().zip(self.instruments.iter()).enumerate() {
                match rate {
                    Number::Dual(d) => {
                        x[i] = d.real - entry.target;
                        let grad = &d.dual;
                        for k in 0..n_vars.min(grad.len()) {
                            j_matrix[i][k] = grad[k];
                        }
                    }
                    Number::F64(v) => {
                        x[i] = v - entry.target;
                    }
                    _ => {
                        x[i] = 0.0;
                    }
                }
            }

            // Compute objective
            let g: f64 = x.iter().zip(self.weights.iter())
                .map(|(xi, wi)| xi * xi * wi)
                .sum();

            final_jacobian = j_matrix.clone();
            final_residuals = x.clone();

            // Check convergence
            if g < self.func_tol {
                converged = true;
                g_prev = g;
                status = format!("Converged: objective {:.2e} < func_tol {:.2e}", g, self.func_tol);
                let v = self.collect_var_values();
                self.restore_values(&v);
                break;
            }
            if (g_prev - g).abs() < self.grad_tol && iter > 0 {
                converged = true;
                g_prev = g;
                status = format!("Converged: improvement {:.2e} < grad_tol {:.2e}", (g_prev - g).abs(), self.grad_tol);
                let v = self.collect_var_values();
                self.restore_values(&v);
                break;
            }

            // Algorithm-specific step computation
            match &algo {
                Algorithm::LevenbergMarquardt { .. } => {
                    // Lambda adjustment on objective increase/decrease
                    if g >= g_prev && iter > 0 {
                        lambda *= failure_scale;
                        let v_old = self.collect_var_values();
                        self.restore_values(&v_old);
                    } else if iter > 0 {
                        lambda *= success_scale;
                    }
                    let v_old = self.collect_var_values();
                    let delta = Self::lm_step(&j_matrix, &x, &self.weights, n_curve_vars, lambda);
                    self.apply_delta(&v_old, &delta);
                }
                Algorithm::GaussNewton => {
                    // Rollback on objective increase
                    if g >= g_prev && iter > 0 {
                        let v_old = self.collect_var_values();
                        self.restore_values(&v_old);
                    }
                    let v_old = self.collect_var_values();
                    match Self::gn_step(&j_matrix, &x, &self.weights, n_curve_vars) {
                        Ok(delta) => {
                            self.apply_delta(&v_old, &delta);
                        }
                        Err(err_msg) => {
                            converged = false;
                            status = err_msg;
                            self.restore_values(&v_old);
                            g_prev = g;
                            break;
                        }
                    }
                }
                Algorithm::GradientDescent { learning_rate } => {
                    let lr = *learning_rate;
                    let weights_clone = self.weights.clone();
                    let delta = self.gd_step(&j_matrix, &x, &weights_clone, n_curve_vars, lr, g, &var_names);
                    let v_old = self.collect_var_values();
                    self.apply_delta(&v_old, &delta);
                }
            }

            g_prev = g;
        }

        if !converged && status.is_empty() {
            status = format!("Max iterations ({}) reached, objective = {:.2e}", self.max_iter, g_prev);
            let v = self.collect_var_values();
            self.restore_values(&v);
        }

        // Compute condition number from final Jacobian
        let condition_number = compute_condition_number(&final_jacobian, n_vars);

        SolverResult {
            converged,
            iterations,
            objective: g_prev,
            residuals: final_residuals,
            jacobian: final_jacobian,
            condition_number,
            status,
            time_seconds: timer.elapsed().as_secs_f64(),
            algorithm: self.algorithm.name().to_string(),
        }
    }

    /// Levenberg-Marquardt step: solve (J^T*W*J + lambda*I) delta = -J^T*W*r.
    fn lm_step(
        j_matrix: &[Vec<f64>], x: &[f64], weights: &[f64],
        n_curve_vars: usize, lambda: f64,
    ) -> Vec<f64> {
        let n_instruments = x.len();
        let mut a_mat = vec![vec![0.0; n_curve_vars]; n_curve_vars];
        let mut b_vec = vec![0.0; n_curve_vars];
        for j_idx in 0..n_curve_vars {
            for k_idx in 0..n_curve_vars {
                let mut sum = 0.0;
                for i in 0..n_instruments {
                    sum += j_matrix[i][j_idx] * weights[i] * j_matrix[i][k_idx];
                }
                a_mat[j_idx][k_idx] = sum;
            }
            a_mat[j_idx][j_idx] += lambda;
            let mut b_sum = 0.0;
            for i in 0..n_instruments {
                b_sum += j_matrix[i][j_idx] * weights[i] * x[i];
            }
            b_vec[j_idx] = -b_sum;
        }
        dsolve_f64(&a_mat, &b_vec)
    }

    /// Gauss-Newton step: solve J^T*W*J*delta = -J^T*W*r (no damping).
    /// Returns Err if J^T*J is singular or near-singular.
    fn gn_step(
        j_matrix: &[Vec<f64>], x: &[f64], weights: &[f64],
        n_curve_vars: usize,
    ) -> Result<Vec<f64>, String> {
        let n_instruments = x.len();
        let mut a_mat = vec![vec![0.0; n_curve_vars]; n_curve_vars];
        let mut b_vec = vec![0.0; n_curve_vars];
        for j_idx in 0..n_curve_vars {
            for k_idx in 0..n_curve_vars {
                let mut sum = 0.0;
                for i in 0..n_instruments {
                    sum += j_matrix[i][j_idx] * weights[i] * j_matrix[i][k_idx];
                }
                a_mat[j_idx][k_idx] = sum;
            }
            // NO lambda on diagonal
            let mut b_sum = 0.0;
            for i in 0..n_instruments {
                b_sum += j_matrix[i][j_idx] * weights[i] * x[i];
            }
            b_vec[j_idx] = -b_sum;
        }
        // Singularity check via condition number of J
        let cond = compute_condition_number(j_matrix, n_curve_vars);
        if cond > 1e14 || cond.is_infinite() {
            return Err(format!(
                "Gauss-Newton: J^T*J is singular or near-singular (condition number: {:.2e}). \
                 Consider using LevenbergMarquardt instead.", cond
            ));
        }
        Ok(dsolve_f64(&a_mat, &b_vec))
    }

    /// Gradient descent step with Armijo backtracking line search.
    /// delta = -alpha * J^T * W * r, with alpha reduced until Armijo condition met.
    fn gd_step(
        &mut self, j_matrix: &[Vec<f64>], x: &[f64], weights: &[f64],
        n_curve_vars: usize, learning_rate: f64, g_current: f64,
        _var_names: &Arc<IndexSet<String>>,
    ) -> Vec<f64> {
        let n_instruments = x.len();
        // Compute gradient: grad_k = sum_i J[i][k] * w[i] * x[i]
        let mut grad = vec![0.0; n_curve_vars];
        for k in 0..n_curve_vars {
            for i in 0..n_instruments {
                grad[k] += j_matrix[i][k] * weights[i] * x[i];
            }
        }
        let grad_sq: f64 = grad.iter().map(|g| g * g).sum();
        if grad_sq < 1e-30 {
            return vec![0.0; n_curve_vars]; // zero gradient
        }

        // Armijo backtracking (D-09: c=1e-4, rho=0.5, max_backtracks=20)
        let c_armijo = 1e-4;
        let rho = 0.5;
        let max_backtracks = 20;
        let mut alpha = learning_rate; // D-10: default 1.0

        let v_old = self.collect_var_values();

        for _ in 0..max_backtracks {
            let delta: Vec<f64> = grad.iter().map(|g| -alpha * g).collect();
            // Trial: apply delta, evaluate objective
            self.apply_delta(&v_old, &delta);
            // Compute rates in f64 mode (curves have f64 values after apply_delta)
            let trial_rates = self.compute_rates();
            let g_trial: f64 = trial_rates.iter().zip(self.instruments.iter()).zip(self.weights.iter())
                .map(|((rate, entry), &w)| {
                    let r = match rate {
                        Number::F64(v) => v - entry.target,
                        Number::Dual(d) => d.real - entry.target,
                        _ => 0.0,
                    };
                    r * r * w
                }).sum();
            self.restore_values(&v_old); // rollback

            // Armijo condition: g_trial <= g_current - c * alpha * ||grad||^2
            if g_trial <= g_current - c_armijo * alpha * grad_sq {
                return delta;
            }
            alpha *= rho;
        }
        // Return last attempted step even if Armijo not satisfied
        grad.iter().map(|g| -alpha * g).collect()
    }
}

/// Compute condition number estimate from Jacobian.
/// Uses sqrt(max(diag(J^T*J)) / min(diag(J^T*J))).
fn compute_condition_number(j: &[Vec<f64>], n_vars: usize) -> f64 {
    if j.is_empty() || n_vars == 0 {
        return 0.0;
    }
    // Compute diagonal of J^T * J
    let n_inst = j.len();
    let mut diag = vec![0.0; n_vars];
    for k in 0..n_vars {
        let mut sum = 0.0;
        for i in 0..n_inst {
            sum += j[i][k] * j[i][k];
        }
        diag[k] = sum;
    }

    let max_d = diag.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let min_d = diag.iter().cloned().fold(f64::INFINITY, f64::min);

    if min_d < 1e-300 {
        f64::INFINITY
    } else {
        (max_d / min_d).sqrt()
    }
}

impl CurveRef {
    /// Set node values as Dual with a variable offset into the unified variable set.
    fn set_values_as_dual_offset(
        &mut self,
        values: &[f64],
        var_names: Arc<IndexSet<String>>,
        ini_solve: usize,
        var_offset: usize,
    ) {
        use ndarray::Array1;
        use crate::autodiff::dual::Dual;
        use indexmap::IndexMap;

        let keys = match self {
            CurveRef::Discount(c) => c.nodes.keys(),
            CurveRef::Line(c) => c.nodes.keys(),
            CurveRef::CreditImplied(c) => c.nodes.keys(),
            CurveRef::Forward(c) => c.nodes.keys(),
        };
        let n_vars_total = var_names.len();
        let mut map = IndexMap::new();

        for (i, (&date, &val)) in keys.iter().zip(values.iter()).enumerate() {
            if i < ini_solve {
                // Constant dual: zero derivatives
                let dual = Dual {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: Array1::zeros(n_vars_total),
                };
                map.insert(date, dual);
            } else {
                let var_idx = var_offset + (i - ini_solve);
                let mut dual_vec = Array1::zeros(n_vars_total);
                if var_idx < n_vars_total {
                    dual_vec[var_idx] = 1.0;
                }
                let dual = Dual {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: dual_vec,
                };
                map.insert(date, dual);
            }
        }

        use crate::marketcurves::nodes::Nodes;
        let nodes = Nodes::Dual(map);
        match self {
            CurveRef::Discount(c) => c.nodes = nodes,
            CurveRef::Line(c) => c.nodes = nodes,
            CurveRef::CreditImplied(c) => c.nodes = nodes,
            CurveRef::Forward(c) => c.nodes = nodes,
        }
    }

    /// Set node values as Dual2 with a variable offset into the unified variable set.
    #[allow(dead_code)]
    fn set_values_as_dual2_offset(
        &mut self,
        values: &[f64],
        var_names: Arc<IndexSet<String>>,
        ini_solve: usize,
        var_offset: usize,
    ) {
        use ndarray::{Array1, Array2};
        use crate::autodiff::dual::Dual2;
        use indexmap::IndexMap;

        let keys = match self {
            CurveRef::Discount(c) => c.nodes.keys(),
            CurveRef::Line(c) => c.nodes.keys(),
            CurveRef::CreditImplied(c) => c.nodes.keys(),
            CurveRef::Forward(c) => c.nodes.keys(),
        };
        let n_vars_total = var_names.len();
        let mut map = IndexMap::new();

        for (i, (&date, &val)) in keys.iter().zip(values.iter()).enumerate() {
            if i < ini_solve {
                // Constant Dual2: zero first and second derivatives
                let d2 = Dual2 {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: Array1::zeros(n_vars_total),
                    dual2: Array2::zeros((n_vars_total, n_vars_total)),
                };
                map.insert(date, d2);
            } else {
                let var_idx = var_offset + (i - ini_solve);
                let mut dual_vec = Array1::zeros(n_vars_total);
                if var_idx < n_vars_total {
                    dual_vec[var_idx] = 1.0;
                }
                let d2 = Dual2 {
                    real: val,
                    vars: Arc::clone(&var_names),
                    dual: dual_vec,
                    dual2: Array2::zeros((n_vars_total, n_vars_total)),
                };
                map.insert(date, d2);
            }
        }

        use crate::marketcurves::nodes::Nodes;
        let nodes = Nodes::Dual2(map);
        match self {
            CurveRef::Discount(c) => c.nodes = nodes,
            CurveRef::Line(c) => c.nodes = nodes,
            CurveRef::CreditImplied(c) => c.nodes = nodes,
            CurveRef::Forward(c) => c.nodes = nodes,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::instruments::irs::InterestRateSwap;
    use crate::instruments::deposit::DepositInstrument;
    use crate::cashflows::leg::{FixedLeg, FloatLeg};
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::cashflows::amortization::Amortization;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    /// Build a 5-instrument IRS calibration problem.
    fn build_5irs_solver() -> Solver {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);

        // Target rates for 1Y, 2Y, 3Y, 4Y, 5Y IRS
        let targets = vec![3.0, 3.2, 3.4, 3.5, 3.6];
        let tenors: Vec<(i32, u32, u32)> = vec![
            (2025, 1, 1), (2026, 1, 1), (2027, 1, 1), (2028, 1, 1), (2029, 1, 1),
        ];

        // Build a discount curve with default (uninitialized) DFs
        let mut node_map = IndexMap::new();
        node_map.insert(ymd(2024, 1, 1), 1.0);
        for &(y, m, d) in &tenors {
            node_map.insert(ymd(y, m, d), 1.0); // all 1.0 = "uninitialized"
        }
        let nodes = Nodes::from_f64_map(node_map);
        let curve = DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc".to_string(),
        );

        let mut solver = Solver::new();
        solver.curves.push(CurveRef::Discount(curve));

        for (i, (target, &(y, m, d))) in targets.iter().zip(tenors.iter()).enumerate() {
            let sched = Schedule::try_new(
                ymd(2024, 1, 1),
                ymd(y, m, d),
                Frequency::Annual,
                cal.clone(),
                Adjuster::ModifiedFollowing,
                None,
                None,
                None,
                StubInference::ShortFront,
            ).unwrap();

            let fixed_leg = FixedLeg::new(
                &sched,
                *target, // fixed rate
                1_000_000.0,
                DayCountConvention::Act365F,
                "USD".to_string(),
                None,
                Amortization::None,
            );
            let float_leg = FloatLeg::new(
                &sched,
                0.0,
                -1_000_000.0,
                DayCountConvention::Act365F,
                FixingMethod::RFRPaymentDelay,
                SpreadMethod::NoneSimple,
                "USD".to_string(),
                None,
                Amortization::None,
            );
            let irs = InterestRateSwap::new(fixed_leg, float_leg);
            solver.instruments.push(InstrumentEntry {
                instrument: Instrument::IRS(irs),
                target: *target,
                disc_curve_idx: 0,
                forecast_curve_idx: None,
                label: format!("{}Y_IRS", i + 1),
                currency: "USD".to_string(),
                leg2_disc_curve_idx: None,
                leg2_forecast_curve_idx: None,
            });
        }

        solver
    }

    #[test]
    fn test_solver_single_curve_calibration() {
        let mut solver = build_5irs_solver();
        let result = solver.iterate();

        assert!(result.converged, "Solver should converge, status: {}", result.status);
        assert!(result.iterations <= 20, "Should converge within 20 iterations, took {}", result.iterations);

        // Check residuals are all < 1e-10
        for (i, r) in result.residuals.iter().enumerate() {
            assert!(r.abs() < 1e-10, "Residual[{i}] = {r}, should be < 1e-10");
        }
        assert!(result.objective < 1e-10, "Objective = {}, should be < 1e-10", result.objective);
    }

    #[test]
    fn test_solver_jacobian_dimensions() {
        let mut solver = build_5irs_solver();
        let result = solver.iterate();

        // 5 instruments, 5 variables (6 nodes - 1 ini_solve)
        assert_eq!(result.jacobian.len(), 5, "Jacobian should have 5 rows (instruments)");
        for row in &result.jacobian {
            assert_eq!(row.len(), 5, "Jacobian row should have 5 columns (vars)");
        }
    }

    #[test]
    fn test_solver_jacobian_values_not_zero_or_nan() {
        let mut solver = build_5irs_solver();
        let result = solver.iterate();

        // At least some Jacobian entries should be nonzero
        let has_nonzero = result.jacobian.iter().any(|row| row.iter().any(|&v| v.abs() > 1e-20));
        assert!(has_nonzero, "Jacobian should have nonzero entries");

        // No NaN
        let has_nan = result.jacobian.iter().any(|row| row.iter().any(|v| v.is_nan()));
        assert!(!has_nan, "Jacobian should not have NaN entries");
    }

    #[test]
    fn test_solver_func_tol_termination() {
        let mut solver = build_5irs_solver();
        solver.func_tol = 1e-8; // more relaxed
        let result = solver.iterate();
        assert!(result.converged, "Should converge with func_tol=1e-8");
        assert!(result.objective < 1e-8, "Objective should be < func_tol");
    }

    #[test]
    fn test_solver_max_iter_termination() {
        let mut solver = build_5irs_solver();
        solver.max_iter = 1;
        let result = solver.iterate();
        // May or may not converge in 1 iteration, but should run
        assert_eq!(result.iterations, 1, "Should run exactly 1 iteration");
    }

    #[test]
    fn test_solver_auto_initial_guess() {
        let mut solver = build_5irs_solver();
        // Curves have all DFs = 1.0 (default)
        solver.auto_initial_guess();

        // After auto-guess, DFs should be monotonically decreasing and positive
        if let CurveRef::Discount(c) = &solver.curves[0] {
            let vals = c.get_node_values();
            assert_eq!(vals[0], 1.0, "First DF should remain 1.0");
            for i in 1..vals.len() {
                assert!(vals[i] > 0.0, "DF[{i}] = {} should be positive", vals[i]);
                assert!(vals[i] < vals[i - 1], "DF[{i}] = {} should be < DF[{}] = {}", vals[i], i - 1, vals[i - 1]);
            }
        }
    }

    #[test]
    fn test_solver_result_has_all_fields() {
        let mut solver = build_5irs_solver();
        let result = solver.iterate();

        // All diagnostic fields present and sensible
        assert!(result.time_seconds >= 0.0);
        assert!(!result.status.is_empty());
        assert!(result.condition_number > 0.0);
        assert!(result.condition_number.is_finite() || result.condition_number == f64::INFINITY);
    }

    #[test]
    fn test_solver_pre_solver_chain() {
        // Inner solver calibrates a 2-instrument curve, then outer solver uses it as frozen
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);

        // Inner solver: 2Y, 3Y IRS
        let inner_targets = vec![3.0, 3.2];
        let inner_tenors = vec![(2026, 1, 1), (2027, 1, 1)];

        let mut inner_node_map = IndexMap::new();
        inner_node_map.insert(ymd(2024, 1, 1), 1.0);
        for &(y, m, d) in &inner_tenors {
            inner_node_map.insert(ymd(y, m, d), 1.0);
        }
        let inner_nodes = Nodes::from_f64_map(inner_node_map);
        let inner_curve = DiscountCurve::new(
            inner_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "inner_disc".to_string(),
        );

        let mut inner_solver = Solver::new();
        inner_solver.curves.push(CurveRef::Discount(inner_curve));

        for (i, (target, &(y, m, d))) in inner_targets.iter().zip(inner_tenors.iter()).enumerate() {
            let sched = Schedule::try_new(
                ymd(2024, 1, 1),
                ymd(y, m, d),
                Frequency::Annual,
                cal.clone(),
                Adjuster::ModifiedFollowing,
                None, None, None,
                StubInference::ShortFront,
            ).unwrap();

            let fixed_leg = FixedLeg::new(
                &sched, *target, 1_000_000.0,
                DayCountConvention::Act365F,
                "USD".to_string(), None, Amortization::None,
            );
            let float_leg = FloatLeg::new(
                &sched, 0.0, -1_000_000.0,
                DayCountConvention::Act365F,
                FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple,
                "USD".to_string(), None, Amortization::None,
            );
            inner_solver.instruments.push(InstrumentEntry {
                instrument: Instrument::IRS(InterestRateSwap::new(fixed_leg, float_leg)),
                target: *target,
                disc_curve_idx: 0,
                forecast_curve_idx: None,
                label: format!("inner_{}Y_IRS", i + 2),
                currency: "USD".to_string(),
                leg2_disc_curve_idx: None,
                leg2_forecast_curve_idx: None,
            });
        }

        // Outer solver: 4Y, 5Y IRS on a separate curve
        let outer_targets = vec![3.5, 3.6];
        let outer_tenors = vec![(2028, 1, 1), (2029, 1, 1)];

        let mut outer_node_map = IndexMap::new();
        outer_node_map.insert(ymd(2024, 1, 1), 1.0);
        for &(y, m, d) in &outer_tenors {
            outer_node_map.insert(ymd(y, m, d), 1.0);
        }
        let outer_nodes = Nodes::from_f64_map(outer_node_map);
        let outer_curve = DiscountCurve::new(
            outer_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "outer_disc".to_string(),
        );

        let mut outer_solver = Solver::new();
        outer_solver.curves.push(CurveRef::Discount(outer_curve));

        for (i, (target, &(y, m, d))) in outer_targets.iter().zip(outer_tenors.iter()).enumerate() {
            let sched = Schedule::try_new(
                ymd(2024, 1, 1),
                ymd(y, m, d),
                Frequency::Annual,
                cal.clone(),
                Adjuster::ModifiedFollowing,
                None, None, None,
                StubInference::ShortFront,
            ).unwrap();

            let fixed_leg = FixedLeg::new(
                &sched, *target, 1_000_000.0,
                DayCountConvention::Act365F,
                "USD".to_string(), None, Amortization::None,
            );
            let float_leg = FloatLeg::new(
                &sched, 0.0, -1_000_000.0,
                DayCountConvention::Act365F,
                FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple,
                "USD".to_string(), None, Amortization::None,
            );
            outer_solver.instruments.push(InstrumentEntry {
                instrument: Instrument::IRS(InterestRateSwap::new(fixed_leg, float_leg)),
                target: *target,
                disc_curve_idx: 0,
                forecast_curve_idx: None,
                label: format!("outer_{}Y_IRS", i + 4),
                currency: "USD".to_string(),
                leg2_disc_curve_idx: None,
                leg2_forecast_curve_idx: None,
            });
        }

        outer_solver.pre_solvers.push(inner_solver);
        let result = outer_solver.iterate();

        // Inner solver should have converged during pre-solve
        assert!(result.converged, "Outer solver should converge, status: {}", result.status);
    }

    #[test]
    fn test_solver_condition_number() {
        let mut solver = build_5irs_solver();
        let result = solver.iterate();
        assert!(result.condition_number > 0.0, "Condition number should be positive");
        assert!(result.condition_number.is_finite(), "Condition number should be finite for well-posed problem");
    }

    #[test]
    fn test_solver_lambda_scaling() {
        // Use very tight tolerances and check convergence behavior
        let mut solver = build_5irs_solver();
        solver.func_tol = 1e-20;
        solver.grad_tol = 1e-20;
        solver.max_iter = 50;
        let result = solver.iterate();
        // Should still converge eventually (or hit grad_tol)
        assert!(result.iterations > 1, "Should take more than 1 iteration");
    }

    #[test]
    fn test_solver_credit_curve_calibration() {
        use crate::instruments::cds;
        use crate::marketcurves::credit::CreditImpliedCurve;

        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);

        // Discount curve for CDS pricing
        let disc_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
        ]));
        let disc_curve = DiscountCurve::new(
            disc_nodes, Interpolator::LogLinear,
            DayCountConvention::Act365F, "disc".to_string(),
        );

        // Credit curve to calibrate (hazard rates)
        let credit_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.01),
            (ymd(2026, 1, 1), 0.01),
            (ymd(2027, 1, 1), 0.01),
        ]));
        let credit_curve = CreditImpliedCurve::new(
            credit_nodes, DayCountConvention::Act365F, 0.40, "credit".to_string(),
        );

        let mut solver = Solver::new();
        solver.curves.push(CurveRef::Discount(disc_curve));
        solver.curves.push(CurveRef::CreditImplied(credit_curve));

        // Build 3 CDS instruments with different spreads
        let targets = vec![120.0, 150.0, 180.0]; // bp
        let tenors = vec![(2025, 1, 1), (2026, 1, 1), (2027, 1, 1)];

        for (i, (target, &(y, m, d))) in targets.iter().zip(tenors.iter()).enumerate() {
            let sched = crate::calendar::schedule::Schedule::try_new(
                ymd(2024, 1, 1), ymd(y, m, d),
                crate::calendar::frequency::Frequency::Quarterly,
                cal.clone(), crate::calendar::adjuster::Adjuster::ModifiedFollowing,
                None, None, None,
                crate::calendar::schedule::StubInference::ShortFront,
            ).unwrap();

            let premium_leg = crate::cashflows::credit_leg::CreditPremiumLeg::new(
                &sched, 10_000_000.0, *target, DayCountConvention::Act360,
                "USD".to_string(), true, 0.40,
            );
            let protection_leg = crate::cashflows::credit_leg::CreditProtectionLeg::new(
                &sched, 10_000_000.0, 0.40, DayCountConvention::Act365F, "USD".to_string(),
            );
            let cds_inst = crate::instruments::CreditDefaultSwap::new(
                premium_leg, protection_leg, 0.40, 10_000_000.0, *target, "USD".to_string(),
            );
            solver.instruments.push(InstrumentEntry {
                instrument: Instrument::CDS(cds_inst),
                target: *target,
                disc_curve_idx: 0,
                forecast_curve_idx: Some(1), // credit curve
                label: format!("{}Y_CDS", i + 1),
                currency: "USD".to_string(),
                leg2_disc_curve_idx: None,
                leg2_forecast_curve_idx: None,
            });
        }

        let result = solver.iterate();
        // CDS calibration should converge (credit curve has correct structure)
        assert!(result.converged, "Credit curve calibration should converge: {}", result.status);
        for (i, r) in result.residuals.iter().enumerate() {
            assert!(r.abs() < 0.1, "CDS residual[{i}] = {r}, should be < 0.1bp");
        }
    }

    #[test]
    fn test_solver_with_fx_rates() {
        use crate::marketcurves::fx::rates::FXRates;
        use crate::marketcurves::fx::pair::FXPair;

        let mut solver = build_5irs_solver();
        let fxr = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        );
        solver.fx_rates = Some(fxr);

        // total_vars should include FX variables
        let curve_vars = solver.total_curve_vars();
        let total = solver.total_vars();
        assert_eq!(total, curve_vars + 1, "Should have 1 extra FX variable");

        // Solver should still converge (IRS instruments don't use FX rates)
        let result = solver.iterate();
        assert!(result.converged, "Solver with fx_rates should converge: {}", result.status);
    }

    #[test]
    fn test_solver_forward_curve() {
        use crate::marketcurves::forward_curve::ForwardCurve;

        // Create a ForwardCurve with 3 nodes
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.03),
            (ymd(2025, 1, 1), 0.035),
            (ymd(2026, 1, 1), 0.04),
        ]));
        let curve = ForwardCurve::new(
            nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd_test".to_string(),
        );

        // Wrap in CurveRef::Forward and verify delegation
        let cr = CurveRef::Forward(curve);
        assert_eq!(cr.ini_solve(), 0, "ForwardCurve ini_solve should be 0");
        assert_eq!(cr.n_vars(), 3, "ForwardCurve n_vars should be 3");
        assert_eq!(cr.n_nodes(), 3, "ForwardCurve n_nodes should be 3");
        assert_eq!(cr.id(), "fwd_test");
        assert_eq!(cr.get_node_values(), vec![0.03, 0.035, 0.04]);

        // Verify CurveQuery delegation
        let cq = cr.as_curve_query();
        let df = cq.discount_factor(ymd(2024, 1, 1));
        if let Number::F64(v) = df {
            assert!((v - 1.0).abs() < 1e-15, "DF at first node should be 1.0, got {}", v);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_instrument_entry_leg2_fields() {
        let entry = InstrumentEntry {
            instrument: Instrument::IRS(crate::instruments::irs::tests::make_test_irs()),
            target: 3.0,
            disc_curve_idx: 0,
            forecast_curve_idx: None,
            label: "test".to_string(),
            currency: "USD".to_string(),
            leg2_disc_curve_idx: Some(2),
            leg2_forecast_curve_idx: Some(3),
        };
        assert_eq!(entry.leg2_disc_curve_idx, Some(2));
        assert_eq!(entry.leg2_forecast_curve_idx, Some(3));
    }

    #[test]
    fn test_solver_fx_ad_jacobian() {
        use crate::marketcurves::fx::rates::FXRates;
        use crate::marketcurves::fx::pair::FXPair;
        use crate::instruments::fx_forward::FXForwardInstrument;

        // Build a solver with an FX forward instrument
        let eur_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
        ]));
        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
        ]));
        let eur_curve = DiscountCurve::new(
            eur_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "eur".to_string(),
        );
        let usd_curve = DiscountCurve::new(
            usd_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd".to_string(),
        );

        let fxr = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        );

        let fwd = FXForwardInstrument::new(
            FXPair::new("eur", "usd"), 1_000_000.0, ymd(2025, 1, 1), "eur".to_string(),
        );

        let mut solver = Solver::new();
        solver.curves.push(CurveRef::Discount(eur_curve));
        solver.curves.push(CurveRef::Discount(usd_curve));
        solver.fx_rates = Some(fxr);

        solver.instruments.push(InstrumentEntry {
            instrument: Instrument::FXForward(fwd),
            target: 1.1 * 0.98 / 0.97, // IRP forward rate
            disc_curve_idx: 0,         // EUR (domestic)
            forecast_curve_idx: Some(1), // USD (foreign)
            label: "EURUSD_1Y".to_string(),
            currency: "EUR".to_string(),
            leg2_disc_curve_idx: None,
            leg2_forecast_curve_idx: None,
        });

        // Build var names and check FX vars are included
        let var_names = solver.build_var_names();
        assert!(var_names.contains("fx_eurusd"), "Var names should include FX variable");

        // total_vars includes FX: 1 eur var + 1 usd var + 1 FX var = 3
        assert_eq!(solver.total_vars(), 3, "Should have 3 total vars (1 eur + 1 usd + 1 fx)");
        assert_eq!(solver.total_curve_vars(), 2, "Should have 2 curve vars");

        // Set curves to dual and compute rates
        let var_names_arc = solver.build_var_names();
        solver.set_curves_dual(&var_names_arc);
        let rates = solver.compute_rates();

        // Check that the rate is Dual and has FX sensitivity
        match &rates[0] {
            Number::Dual(d) => {
                assert!(d.real > 0.0, "FXForward rate should be positive, got {}", d.real);
                // The FX variable should be at index 2 (after 1 eur + 1 usd curve var)
                let fx_idx = d.vars.get_index_of("fx_eurusd");
                assert!(fx_idx.is_some(), "Should have fx_eurusd in Dual vars");
                let fx_idx = fx_idx.unwrap();
                assert!(d.dual[fx_idx].abs() > 1e-10,
                    "FX sensitivity should be non-zero, got {}", d.dual[fx_idx]);
            }
            _ => panic!("Expected Dual from FXForward rate computation"),
        }
    }

    #[test]
    fn test_solver_fx_ad_irs_zero() {
        use crate::marketcurves::fx::rates::FXRates;
        use crate::marketcurves::fx::pair::FXPair;

        // Build solver with IRS + FX rates
        let mut solver = build_5irs_solver();
        let fxr = FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        );
        solver.fx_rates = Some(fxr);

        let var_names_arc = solver.build_var_names();
        solver.set_curves_dual(&var_names_arc);
        let rates = solver.compute_rates();

        // IRS instruments should have zero FX sensitivity
        for (i, rate) in rates.iter().enumerate() {
            match rate {
                Number::Dual(d) => {
                    let fx_idx = d.vars.get_index_of("fx_eurusd");
                    if let Some(idx) = fx_idx {
                        assert!(
                            d.dual[idx].abs() < 1e-15,
                            "IRS[{i}] FX sensitivity should be zero, got {}", d.dual[idx]
                        );
                    }
                }
                _ => {} // f64 rates have no AD info, OK
            }
        }
    }

    #[test]
    fn test_serde_solver_roundtrip() {
        let solver = build_5irs_solver();
        let json = serde_json::to_string(&solver).unwrap();
        let mut restored: Solver = serde_json::from_str(&json).unwrap();
        // Rebuild FXRates adjacency if present
        if let Some(ref mut fx) = restored.fx_rates {
            fx.rebuild_adjacency();
        }
        // Rebuild spline interpolators on all curves
        for curve_ref in &mut restored.curves {
            match curve_ref {
                CurveRef::Discount(c) => c.rebuild_spline(),
                CurveRef::Line(c) => c.rebuild_spline(),
                CurveRef::CreditImplied(_) => {}
                CurveRef::Forward(c) => c.rebuild_spline(),
            }
        }
        // Verify structure intact
        assert_eq!(solver.curves.len(), restored.curves.len());
        assert_eq!(solver.instruments.len(), restored.instruments.len());
        // Verify curve IDs match
        for (orig, rest) in solver.curves.iter().zip(restored.curves.iter()) {
            assert_eq!(orig.id(), rest.id());
        }
    }

    #[test]
    fn test_serde_solver_result_roundtrip() {
        let result = SolverResult {
            converged: true,
            iterations: 10,
            objective: 1e-15,
            residuals: vec![1e-8, 2e-8],
            jacobian: vec![vec![1.0, 0.0], vec![0.0, 1.0]],
            condition_number: 1.5,
            status: "converged".to_string(),
            time_seconds: 0.05,
            algorithm: "levenberg_marquardt".to_string(),
        };
        let json = serde_json::to_string(&result).unwrap();
        let restored: SolverResult = serde_json::from_str(&json).unwrap();
        assert_eq!(restored.converged, true);
        assert_eq!(restored.iterations, 10);
        assert!((restored.objective - 1e-15).abs() < 1e-30);
    }
}
