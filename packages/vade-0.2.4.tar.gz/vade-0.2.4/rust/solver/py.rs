use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};

use crate::marketcurves::py::{PyDiscountCurve, PyLineCurve, PyCreditImpliedCurve, PyForwardCurve};
use crate::marketcurves::fx::py::PyFXRates;
use crate::solver::{CurveRef, InstrumentEntry, Solver, Algorithm};
use crate::solver::bootstrap::{BootstrapConfig, BootstrapInstrument, bootstrap as rust_bootstrap};
use crate::solver::result::SolverResult;

// ---- PySolverResult ----

#[pyclass(name = "PySolverResult", module = "vade._vade_rs.solver")]
pub struct PySolverResult {
    pub inner: SolverResult,
}

#[pymethods]
impl PySolverResult {
    #[getter]
    fn converged(&self) -> bool {
        self.inner.converged
    }

    #[getter]
    fn iterations(&self) -> usize {
        self.inner.iterations
    }

    #[getter]
    fn objective(&self) -> f64 {
        self.inner.objective
    }

    #[getter]
    fn residuals(&self) -> Vec<f64> {
        self.inner.residuals.clone()
    }

    #[getter]
    fn jacobian<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyAny>> {
        // Convert Vec<Vec<f64>> to numpy 2D array
        let n_rows = self.inner.jacobian.len();
        if n_rows == 0 {
            let np = py.import("numpy")?;
            let arr = np.call_method1("zeros", ((0, 0),))?;
            return Ok(arr);
        }
        let n_cols = self.inner.jacobian[0].len();
        // Flatten to 1D then reshape
        let flat: Vec<f64> = self.inner.jacobian.iter().flat_map(|r| r.iter().copied()).collect();
        let np = py.import("numpy")?;
        let arr = np.call_method1("array", (flat,))?;
        let reshaped = arr.call_method1("reshape", ((n_rows, n_cols),))?;
        Ok(reshaped)
    }

    #[getter]
    fn condition_number(&self) -> f64 {
        self.inner.condition_number
    }

    #[getter]
    fn status(&self) -> &str {
        &self.inner.status
    }

    #[getter]
    fn time_seconds(&self) -> f64 {
        self.inner.time_seconds
    }

    #[getter]
    fn algorithm(&self) -> &str {
        &self.inner.algorithm
    }

    fn __repr__(&self) -> String {
        format!(
            "SolverResult(converged={}, iterations={}, objective={:.2e}, algorithm='{}')",
            self.inner.converged, self.inner.iterations, self.inner.objective, self.inner.algorithm
        )
    }
}

// Use the shared extract_instrument helper from instruments/py.rs
use crate::instruments::py::extract_instrument;

fn extract_curve_ref(obj: &Bound<'_, PyAny>) -> PyResult<CurveRef> {
    if let Ok(dc) = obj.extract::<PyRef<'_, PyDiscountCurve>>() {
        return Ok(CurveRef::Discount(dc.inner.clone()));
    }
    if let Ok(lc) = obj.extract::<PyRef<'_, PyLineCurve>>() {
        return Ok(CurveRef::Line(lc.inner.clone()));
    }
    if let Ok(cc) = obj.extract::<PyRef<'_, PyCreditImpliedCurve>>() {
        return Ok(CurveRef::CreditImplied(cc.inner.clone()));
    }
    if let Ok(fc) = obj.extract::<PyRef<'_, PyForwardCurve>>() {
        return Ok(CurveRef::Forward(fc.inner.clone()));
    }
    Err(PyValueError::new_err(
        "curve must be a DiscountCurve, LineCurve, CreditImpliedCurve, or ForwardCurve",
    ))
}

// ---- PySolver ----

#[pyclass(name = "PySolver", module = "vade._vade_rs.solver")]
pub struct PySolver {
    pub inner: Solver,
}

#[pymethods]
impl PySolver {
    #[new]
    #[pyo3(signature = (
        curves,
        instruments,
        weights = None,
        func_tol = 1e-14,
        grad_tol = 1e-14,
        max_iter = 100,
        ini_lambda = None,
        pre_solvers = None,
        fx_rates = None,
        algorithm = None,
        learning_rate = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        curves: &Bound<'_, PyList>,
        instruments: &Bound<'_, PyList>,
        weights: Option<Vec<f64>>,
        func_tol: f64,
        grad_tol: f64,
        max_iter: usize,
        ini_lambda: Option<(f64, f64, f64)>,
        pre_solvers: Option<&Bound<'_, PyList>>,
        fx_rates: Option<PyRef<'_, PyFXRates>>,
        algorithm: Option<&str>,
        learning_rate: Option<f64>,
    ) -> PyResult<Self> {
        let mut solver = Solver::new();
        solver.func_tol = func_tol;
        solver.grad_tol = grad_tol;
        solver.max_iter = max_iter;

        // Determine algorithm (D-11, D-12)
        let algo_str = algorithm.unwrap_or("levenberg_marquardt");
        solver.algorithm = match algo_str {
            "levenberg_marquardt" => {
                if learning_rate.is_some() {
                    return Err(PyValueError::new_err(
                        "learning_rate is not valid for levenberg_marquardt algorithm"
                    ));
                }
                match ini_lambda {
                    Some(lam) => Algorithm::LevenbergMarquardt { ini_lambda: lam },
                    None => Algorithm::default(),
                }
            }
            "gauss_newton" => {
                if ini_lambda.is_some() {
                    return Err(PyValueError::new_err(
                        "ini_lambda is not valid for gauss_newton algorithm"
                    ));
                }
                if learning_rate.is_some() {
                    return Err(PyValueError::new_err(
                        "learning_rate is not valid for gauss_newton algorithm"
                    ));
                }
                Algorithm::GaussNewton
            }
            "gradient_descent" => {
                if ini_lambda.is_some() {
                    return Err(PyValueError::new_err(
                        "ini_lambda is not valid for gradient_descent algorithm"
                    ));
                }
                Algorithm::GradientDescent {
                    learning_rate: learning_rate.unwrap_or(1.0), // D-10: default 1.0
                }
            }
            other => {
                return Err(PyValueError::new_err(format!(
                    "Unknown algorithm: '{}'. Use 'levenberg_marquardt', 'gauss_newton', or 'gradient_descent'",
                    other
                )));
            }
        };

        // Set FX rates if provided (D-48)
        if let Some(fxr) = fx_rates {
            solver.fx_rates = Some(fxr.inner.clone());
        }

        // Parse curves
        for i in 0..curves.len() {
            let curve_obj = curves.get_item(i)?;
            let cr = extract_curve_ref(&curve_obj)?;
            solver.curves.push(cr);
        }

        // Parse instruments: list of tuples or dicts.
        // Tuple format: (instrument, target[, disc_idx[, label[, currency]]])
        // Dict format: {"instrument": inst, "target": float, "disc_curve_idx": int, ...}
        for i in 0..instruments.len() {
            let item = instruments.get_item(i)?;

            // Try dict format first (supports leg2 indices for XCS)
            if let Ok(dict) = item.cast::<PyDict>() {
                let inst_obj = dict.get_item("instrument")?.ok_or_else(|| {
                    PyValueError::new_err("Dict instrument entry must have 'instrument' key")
                })?;
                let target: f64 = dict.get_item("target")?.ok_or_else(|| {
                    PyValueError::new_err("Dict instrument entry must have 'target' key")
                })?.extract()?;
                let instrument = extract_instrument(&inst_obj)?;

                let disc_idx: usize = dict.get_item("disc_curve_idx")?
                    .map(|v| v.extract().unwrap_or(0)).unwrap_or(0);
                let forecast_idx: Option<usize> = dict.get_item("forecast_curve_idx")?
                    .map(|v| v.extract().ok()).flatten();
                let leg2_disc_idx: Option<usize> = dict.get_item("leg2_disc_curve_idx")?
                    .map(|v| v.extract().ok()).flatten();
                let leg2_forecast_idx: Option<usize> = dict.get_item("leg2_forecast_curve_idx")?
                    .map(|v| v.extract().ok()).flatten();
                let label: String = dict.get_item("label")?
                    .map(|v| v.extract().unwrap_or_else(|_| format!("inst_{}", i)))
                    .unwrap_or_else(|| format!("inst_{}", i));
                let currency: String = dict.get_item("currency")?
                    .map(|v| v.extract().unwrap_or_else(|_| "USD".to_string()))
                    .unwrap_or_else(|| "USD".to_string());

                solver.instruments.push(InstrumentEntry {
                    instrument,
                    target,
                    disc_curve_idx: disc_idx,
                    forecast_curve_idx: forecast_idx,
                    label,
                    currency,
                    leg2_disc_curve_idx: leg2_disc_idx,
                    leg2_forecast_curve_idx: leg2_forecast_idx,
                });
                continue;
            }

            // Tuple format
            let tuple = item.cast::<pyo3::types::PyTuple>().map_err(|_| {
                PyValueError::new_err("Each instrument must be a tuple (instrument, target_rate) or a dict")
            })?;

            if tuple.len() < 2 {
                return Err(PyValueError::new_err(
                    "Each instrument tuple must have at least 2 elements: (instrument, target_rate)",
                ));
            }

            let inst_obj = tuple.get_item(0)?;
            let target: f64 = tuple.get_item(1)?.extract()?;

            let instrument = extract_instrument(&inst_obj)?;

            let (disc_idx, forecast_idx) = if tuple.len() >= 3 {
                let idx: usize = tuple.get_item(2)?.extract().unwrap_or(0);
                (idx, None)
            } else {
                (0, None)
            };

            // Extract optional label (4th element) and currency (5th element)
            let label = if tuple.len() >= 4 {
                tuple.get_item(3)?.extract::<String>().unwrap_or_else(|_| format!("inst_{}", i))
            } else {
                format!("inst_{}", i)
            };
            let currency = if tuple.len() >= 5 {
                tuple.get_item(4)?.extract::<String>().unwrap_or_else(|_| "USD".to_string())
            } else {
                "USD".to_string()
            };

            solver.instruments.push(InstrumentEntry {
                instrument,
                target,
                disc_curve_idx: disc_idx,
                forecast_curve_idx: forecast_idx,
                label,
                currency,
                leg2_disc_curve_idx: None,
                leg2_forecast_curve_idx: None,
            });
        }

        // Set weights
        if let Some(w) = weights {
            solver.weights = w;
        }

        // Parse pre-solvers
        if let Some(ps_list) = pre_solvers {
            for i in 0..ps_list.len() {
                let ps_obj = ps_list.get_item(i)?;
                let ps = ps_obj.extract::<PyRef<'_, PySolver>>()?;
                solver.pre_solvers.push(ps.inner.clone());
            }
        }

        Ok(PySolver { inner: solver })
    }

    fn iterate(&mut self) -> PyResult<PySolverResult> {
        let result = self.inner.iterate();
        Ok(PySolverResult { inner: result })
    }

    fn get_curve(&self, py: Python<'_>, index: usize) -> PyResult<Py<PyAny>> {
        if index >= self.inner.curves.len() {
            return Err(PyValueError::new_err(format!(
                "Curve index {} out of range (have {} curves)",
                index,
                self.inner.curves.len()
            )));
        }
        match &self.inner.curves[index] {
            CurveRef::Discount(c) => Ok(Py::new(py, PyDiscountCurve { inner: c.clone() })?.into_any()),
            CurveRef::Line(c) => Ok(Py::new(py, PyLineCurve { inner: c.clone() })?.into_any()),
            CurveRef::CreditImplied(c) => Ok(Py::new(py, PyCreditImpliedCurve { inner: c.clone() })?.into_any()),
            CurveRef::Forward(c) => Ok(Py::new(py, PyForwardCurve { inner: c.clone() })?.into_any()),
        }
    }

    fn get_curve_by_id(&self, py: Python<'_>, id: &str) -> PyResult<Py<PyAny>> {
        for cr in &self.inner.curves {
            if cr.id() == id {
                return match cr {
                    CurveRef::Discount(c) => Ok(Py::new(py, PyDiscountCurve { inner: c.clone() })?.into_any()),
                    CurveRef::Line(c) => Ok(Py::new(py, PyLineCurve { inner: c.clone() })?.into_any()),
                    CurveRef::CreditImplied(c) => Ok(Py::new(py, PyCreditImpliedCurve { inner: c.clone() })?.into_any()),
                    CurveRef::Forward(c) => Ok(Py::new(py, PyForwardCurve { inner: c.clone() })?.into_any()),
                };
            }
        }
        Err(PyValueError::new_err(format!(
            "No curve with id '{}' found in solver",
            id
        )))
    }

    /// Return the string IDs of all curves in the solver.
    fn curve_ids(&self) -> Vec<String> {
        self.inner.curves.iter().map(|cr| cr.id().to_string()).collect()
    }

    /// Return the labels of calibrating instruments (for DataFrame construction).
    fn instrument_labels(&self) -> Vec<String> {
        self.inner.instruments.iter().map(|entry| entry.label.clone()).collect()
    }

    /// Return the tenor dates of calibrating instruments (for DataFrame construction).
    fn instrument_tenors(&self) -> Vec<String> {
        self.inner.instruments.iter().map(|entry| {
            entry.instrument.pillar_date().format("%Y-%m-%d").to_string()
        }).collect()
    }

    /// Return the currencies of calibrating instruments (for DataFrame construction).
    fn instrument_currencies(&self) -> Vec<String> {
        self.inner.instruments.iter().map(|entry| entry.currency.clone()).collect()
    }

    /// Compute delta risk for a single instrument. Returns Vec<f64>.
    fn delta(
        &self,
        py: Python<'_>,
        instrument: &Bound<'_, PyAny>,
        jacobian: Vec<Vec<f64>>,
    ) -> PyResult<Py<PyAny>> {
        let inst = extract_instrument(instrument)?;
        let deltas = self.inner.delta(&inst, &jacobian);
        Ok(deltas.into_pyobject(py).expect("vec to py").into_any().unbind())
    }

    /// Compute gamma risk for a single instrument. Returns Vec<Vec<f64>>.
    fn gamma(
        &self,
        py: Python<'_>,
        instrument: &Bound<'_, PyAny>,
        jacobian: Vec<Vec<f64>>,
    ) -> PyResult<Py<PyAny>> {
        let inst = extract_instrument(instrument)?;
        let gammas = self.inner.gamma(&inst, &jacobian);
        Ok(gammas.into_pyobject(py).expect("vec to py").into_any().unbind())
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        let inner: Solver = serde_json::from_str(s)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn __repr__(&self) -> String {
        format!(
            "Solver(curves={}, instruments={})",
            self.inner.curves.len(),
            self.inner.instruments.len()
        )
    }
}

// ---- bootstrap() Python function ----

/// Python-callable bootstrap function for node-by-node curve calibration.
///
/// Per D-21: bootstrap is exposed as a standalone function rather than a Solver method.
///
/// # Arguments
/// * `curves` - List of curve objects (DiscountCurve, LineCurve, ForwardCurve, CreditImpliedCurve)
/// * `instruments` - List of dicts with keys: instrument, target, disc_curve_idx, forecast_curve_idx (opt), label (opt)
/// * `target_curve_idx` - Index of the curve to calibrate
/// * `tol` - Convergence tolerance (default: 1e-12)
/// * `max_outer` - Max outer iterations for global interpolators (default: 10)
/// * `max_brent` - Max Brent iterations per node (default: 100)
/// * `bracket_low` - Lower bracket for root search (default: -0.05)
/// * `bracket_high` - Upper bracket for root search (default: 0.30)
///
/// # Returns
/// The calibrated target curve (same type as input)
#[pyfunction]
#[pyo3(signature = (
    curves,
    instruments,
    target_curve_idx,
    tol = None,
    max_outer = None,
    max_brent = None,
    bracket_low = None,
    bracket_high = None,
))]
#[allow(clippy::too_many_arguments)]
fn bootstrap(
    py: Python<'_>,
    curves: &Bound<'_, PyList>,
    instruments: &Bound<'_, PyList>,
    target_curve_idx: usize,
    tol: Option<f64>,
    max_outer: Option<usize>,
    max_brent: Option<usize>,
    bracket_low: Option<f64>,
    bracket_high: Option<f64>,
) -> PyResult<Py<PyAny>> {
    // Build CurveRef vec from Python curve objects
    let mut curve_refs: Vec<CurveRef> = Vec::new();
    for i in 0..curves.len() {
        let curve_obj = curves.get_item(i)?;
        let cr = extract_curve_ref(&curve_obj)?;
        curve_refs.push(cr);
    }

    if target_curve_idx >= curve_refs.len() {
        return Err(PyValueError::new_err(format!(
            "target_curve_idx {} out of range (have {} curves)",
            target_curve_idx, curve_refs.len()
        )));
    }

    // Build BootstrapInstrument vec from Python dicts
    let mut boot_instruments: Vec<BootstrapInstrument> = Vec::new();
    for i in 0..instruments.len() {
        let item = instruments.get_item(i)?;
        let dict = item.cast::<PyDict>().map_err(|_| {
            PyValueError::new_err("Each bootstrap instrument must be a dict with keys: instrument, target, disc_curve_idx")
        })?;

        let inst_obj = dict.get_item("instrument")?.ok_or_else(|| {
            PyValueError::new_err("Bootstrap instrument dict must have 'instrument' key")
        })?;
        let target: f64 = dict.get_item("target")?.ok_or_else(|| {
            PyValueError::new_err("Bootstrap instrument dict must have 'target' key")
        })?.extract()?;
        let disc_idx: usize = dict.get_item("disc_curve_idx")?
            .map(|v| v.extract().unwrap_or(0)).unwrap_or(0);
        let forecast_idx: Option<usize> = dict.get_item("forecast_curve_idx")?
            .and_then(|v| v.extract().ok());
        let label: String = dict.get_item("label")?
            .map(|v| v.extract().unwrap_or_else(|_| format!("inst_{}", i)))
            .unwrap_or_else(|| format!("inst_{}", i));

        let instrument = extract_instrument(&inst_obj)?;

        boot_instruments.push(BootstrapInstrument {
            instrument,
            target,
            disc_curve_idx: disc_idx,
            forecast_curve_idx: forecast_idx,
            label,
        });
    }

    // Build config with defaults
    let mut config = BootstrapConfig::default();
    if let Some(t) = tol { config.tol = t; }
    if let Some(mo) = max_outer { config.max_outer = mo; }
    if let Some(mb) = max_brent { config.max_brent = mb; }
    if let Some(bl) = bracket_low { config.bracket_low = bl; }
    if let Some(bh) = bracket_high { config.bracket_high = bh; }

    // Run bootstrap
    rust_bootstrap(&boot_instruments, &mut curve_refs, target_curve_idx, &config)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;

    // Return calibrated target curve as Python object
    match &curve_refs[target_curve_idx] {
        CurveRef::Discount(c) => Ok(Py::new(py, PyDiscountCurve { inner: c.clone() })?.into_any()),
        CurveRef::Line(c) => Ok(Py::new(py, PyLineCurve { inner: c.clone() })?.into_any()),
        CurveRef::CreditImplied(c) => Ok(Py::new(py, PyCreditImpliedCurve { inner: c.clone() })?.into_any()),
        CurveRef::Forward(c) => Ok(Py::new(py, PyForwardCurve { inner: c.clone() })?.into_any()),
    }
}

// ---- Module registration ----

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PySolver>()?;
    m.add_class::<PySolverResult>()?;
    m.add_function(wrap_pyfunction!(bootstrap, m)?)?;
    Ok(())
}
