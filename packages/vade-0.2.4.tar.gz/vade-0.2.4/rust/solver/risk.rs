use crate::autodiff::enums::Number;
use crate::autodiff::linalg::dsolve_f64;
use crate::instruments::Instrument;
use super::{Solver, CurveRef};

/// Structured risk report containing delta and gamma sensitivities.
pub struct RiskReport {
    /// Delta sensitivities: dNPV/ds per calibrating instrument.
    pub deltas: Vec<f64>,
    /// Cross-gamma matrix: d2NPV/d(s_i * s_j).
    pub gammas: Vec<Vec<f64>>,
}

/// Set cloned curves to Dual mode with unified AD variables.
fn set_curves_dual_on(curves: &mut Vec<CurveRef>, var_names: &std::sync::Arc<indexmap::IndexSet<String>>) {
    use ndarray::Array1;
    use crate::autodiff::dual::Dual;
    use crate::marketcurves::nodes::Nodes;
    use std::sync::Arc;
    use indexmap::IndexMap;

    let mut var_offset = 0;
    for cr in curves.iter_mut() {
        let all_vals = cr.get_node_values();
        let ini = cr.ini_solve();
        let n_v = cr.n_vars();
        let n_vars_total = var_names.len();

        let keys = match cr {
            CurveRef::Discount(c) => c.nodes.keys(),
            CurveRef::Line(c) => c.nodes.keys(),
            CurveRef::CreditImplied(c) => c.nodes.keys(),
            CurveRef::Forward(c) => c.nodes.keys(),
        };

        let mut map = IndexMap::new();
        for (i, (&date, &val)) in keys.iter().zip(all_vals.iter()).enumerate() {
            if i < ini {
                let dual = Dual {
                    real: val,
                    vars: Arc::clone(var_names),
                    dual: Array1::zeros(n_vars_total),
                };
                map.insert(date, dual);
            } else {
                let var_idx = var_offset + (i - ini);
                let mut dual_vec = Array1::zeros(n_vars_total);
                if var_idx < n_vars_total {
                    dual_vec[var_idx] = 1.0;
                }
                let dual = Dual {
                    real: val,
                    vars: Arc::clone(var_names),
                    dual: dual_vec,
                };
                map.insert(date, dual);
            }
        }

        let nodes = Nodes::Dual(map);
        match cr {
            CurveRef::Discount(c) => c.nodes = nodes,
            CurveRef::Line(c) => c.nodes = nodes,
            CurveRef::CreditImplied(c) => c.nodes = nodes,
            CurveRef::Forward(c) => c.nodes = nodes,
        }
        var_offset += n_v;
    }
}

/// Set cloned curves to Dual2 mode with unified AD variables.
fn set_curves_dual2_on(curves: &mut Vec<CurveRef>, var_names: &std::sync::Arc<indexmap::IndexSet<String>>) {
    use ndarray::{Array1, Array2};
    use crate::autodiff::dual::Dual2;
    use crate::marketcurves::nodes::Nodes;
    use std::sync::Arc;
    use indexmap::IndexMap;

    let mut var_offset = 0;
    for cr in curves.iter_mut() {
        let all_vals = cr.get_node_values();
        let ini = cr.ini_solve();
        let n_v = cr.n_vars();
        let n_vars_total = var_names.len();

        let keys = match cr {
            CurveRef::Discount(c) => c.nodes.keys(),
            CurveRef::Line(c) => c.nodes.keys(),
            CurveRef::CreditImplied(c) => c.nodes.keys(),
            CurveRef::Forward(c) => c.nodes.keys(),
        };

        let mut map = IndexMap::new();
        for (i, (&date, &val)) in keys.iter().zip(all_vals.iter()).enumerate() {
            if i < ini {
                let d2 = Dual2 {
                    real: val,
                    vars: Arc::clone(var_names),
                    dual: Array1::zeros(n_vars_total),
                    dual2: Array2::zeros((n_vars_total, n_vars_total)),
                };
                map.insert(date, d2);
            } else {
                let var_idx = var_offset + (i - ini);
                let mut dual_vec = Array1::zeros(n_vars_total);
                if var_idx < n_vars_total {
                    dual_vec[var_idx] = 1.0;
                }
                let d2 = Dual2 {
                    real: val,
                    vars: Arc::clone(var_names),
                    dual: dual_vec,
                    dual2: Array2::zeros((n_vars_total, n_vars_total)),
                };
                map.insert(date, d2);
            }
        }

        let nodes = Nodes::Dual2(map);
        match cr {
            CurveRef::Discount(c) => c.nodes = nodes,
            CurveRef::Line(c) => c.nodes = nodes,
            CurveRef::CreditImplied(c) => c.nodes = nodes,
            CurveRef::Forward(c) => c.nodes = nodes,
        }
        var_offset += n_v;
    }
}

/// Compute delta risk: dNPV/ds_k for each calibrating instrument k.
///
/// Algorithm:
/// 1. Set curves to Dual mode at converged values
/// 2. Compute dNPV/d(var_j) for the given instrument via Dual arithmetic
/// 3. Solve J^T * delta = grad to get per-calibrating-instrument sensitivities
///    where J is the Jacobian from the last iterate() call
///
/// Returns Vec<f64> of length n_instruments (one delta per calibrating instrument).
pub fn compute_delta(
    solver: &Solver,
    instrument: &Instrument,
    jacobian: &[Vec<f64>],
) -> Vec<f64> {
    let n_vars = solver.total_vars();
    let n_instruments = solver.instruments.len();

    // Clone solver curves to avoid mutating the original
    let mut curves_clone = solver.curves.clone();
    let var_names = solver.build_var_names();

    // Set cloned curves to Dual mode
    set_curves_dual_on(&mut curves_clone, &var_names);

    // Compute dNPV/d(var_j) using the first curve as both disc and forecast
    // For multi-curve setups, the instrument's curve mapping would be used
    let disc = curves_clone[0].as_curve_query();
    let forecast = if curves_clone.len() > 1 {
        curves_clone[1].as_curve_query()
    } else {
        disc
    };
    let npv = instrument.npv(disc, forecast, solver.fx_rates.as_ref(), None, None);
    let grad: Vec<f64> = match &npv {
        Number::Dual(d) => d.dual.to_vec(),
        _ => vec![0.0; n_vars],
    };

    // Solve J^T * delta = grad for delta
    // J is n_instruments x n_vars, J^T is n_vars x n_instruments
    if n_instruments == n_vars {
        let mut jt = vec![vec![0.0; n_instruments]; n_vars];
        for i in 0..n_instruments {
            for j in 0..n_vars {
                jt[j][i] = jacobian[i][j];
            }
        }
        dsolve_f64(&jt, &grad)
    } else {
        // Non-square case: return zeros (not typical for calibration)
        vec![0.0; n_instruments]
    }
}

/// Compute gamma risk: cross-gamma matrix d2NPV/d(s_i * s_j) via Dual2.
///
/// Algorithm per D-03:
/// 1. Set curves to Dual2 mode at converged values (no re-iteration)
/// 2. Evaluate instrument NPV -- AD propagates second derivatives
/// 3. Extract Hessian d2NPV/d(var_j * var_k) from Dual2.dual2
///    IMPORTANT: dual2 stores 0.5 * d2f/dxdy (half-Hessian), multiply by 2
/// 4. Transform to calibrating instrument space:
///    gamma = J_inv^T * H * J_inv
///
/// Returns Vec<Vec<f64>> matrix of size n_instruments x n_instruments.
pub fn compute_gamma(
    solver: &Solver,
    instrument: &Instrument,
    jacobian: &[Vec<f64>],
) -> Vec<Vec<f64>> {
    let n_vars = solver.total_vars();
    let n_instruments = solver.instruments.len();

    // Clone solver curves
    let mut curves_clone = solver.curves.clone();
    let var_names = solver.build_var_names();

    // Set cloned curves to Dual2 mode at converged values
    set_curves_dual2_on(&mut curves_clone, &var_names);

    // Compute NPV with Dual2
    let disc = curves_clone[0].as_curve_query();
    let forecast = if curves_clone.len() > 1 {
        curves_clone[1].as_curve_query()
    } else {
        disc
    };
    let npv = instrument.npv(disc, forecast, solver.fx_rates.as_ref(), None, None);

    // Extract Hessian (second derivatives)
    let hessian: Vec<Vec<f64>> = match &npv {
        Number::Dual2(d2) => {
            let mut h = vec![vec![0.0; n_vars]; n_vars];
            for j in 0..n_vars {
                for k in 0..n_vars {
                    // Half-Hessian convention: multiply by 2
                    h[j][k] = d2.dual2[[j, k]] * 2.0;
                }
            }
            h
        }
        _ => vec![vec![0.0; n_vars]; n_vars],
    };

    // Transform Hessian to calibrating instrument space
    // gamma = J_inv^T * H * J_inv
    if n_instruments != n_vars {
        return vec![vec![0.0; n_instruments]; n_instruments];
    }

    // Compute J_inv column by column: solve J^T * x_k = e_k
    let jt: Vec<Vec<f64>> = (0..n_vars).map(|j| {
        (0..n_instruments).map(|i| jacobian[i][j]).collect()
    }).collect();

    let mut j_inv = vec![vec![0.0; n_vars]; n_vars];
    for k in 0..n_vars {
        let mut e_k = vec![0.0; n_vars];
        e_k[k] = 1.0;
        let col = dsolve_f64(&jt, &e_k);
        for j in 0..n_vars {
            j_inv[j][k] = col[j];
        }
    }

    // gamma = J_inv^T * H * J_inv
    let mut gamma = vec![vec![0.0; n_instruments]; n_instruments];
    for i in 0..n_instruments {
        for j in 0..n_instruments {
            let mut sum = 0.0;
            for p in 0..n_vars {
                for q in 0..n_vars {
                    sum += j_inv[p][i] * hessian[p][q] * j_inv[q][j];
                }
            }
            gamma[i][j] = sum;
        }
    }

    gamma
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::instruments::irs::InterestRateSwap;
    use crate::cashflows::leg::{FixedLeg, FloatLeg};
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::cashflows::amortization::Amortization;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::solver::InstrumentEntry;
    use indexmap::IndexMap;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    /// Build a 5-instrument IRS calibration problem and solve it.
    fn build_and_solve_5irs() -> (Solver, crate::solver::result::SolverResult) {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let targets = vec![3.0, 3.2, 3.4, 3.5, 3.6];
        let tenors: Vec<(i32, u32, u32)> = vec![
            (2025, 1, 1), (2026, 1, 1), (2027, 1, 1), (2028, 1, 1), (2029, 1, 1),
        ];

        let mut node_map = IndexMap::new();
        node_map.insert(ymd(2024, 1, 1), 1.0);
        for &(y, m, d) in &tenors {
            node_map.insert(ymd(y, m, d), 1.0);
        }
        let nodes = Nodes::from_f64_map(node_map);
        let curve = DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc".to_string(),
        );

        let mut solver = Solver::new();
        solver.curves.push(CurveRef::Discount(curve));

        for (i, (target, &(y, m, d))) in targets.iter().zip(tenors.iter()).enumerate() {
            let sched = Schedule::try_new(
                ymd(2024, 1, 1),
                ymd(y, m, d),
                Frequency::Annual,
                cal.clone(),
                Adjuster::ModifiedFollowing,
                None, None, None,
                StubInference::ShortFront,
            ).unwrap();

            let fixed_leg = FixedLeg::new(
                &sched, *target, 1_000_000.0,
                DayCountConvention::Act365F,
                "USD".to_string(), None, Amortization::None,
            );
            let float_leg = FloatLeg::new(
                &sched, 0.0, -1_000_000.0,
                DayCountConvention::Act365F,
                FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple,
                "USD".to_string(), None, Amortization::None,
            );
            let irs = InterestRateSwap::new(fixed_leg, float_leg);
            solver.instruments.push(InstrumentEntry {
                instrument: Instrument::IRS(irs),
                target: *target,
                disc_curve_idx: 0,
                forecast_curve_idx: None,
                label: format!("{}Y_IRS", i + 1),
                currency: "USD".to_string(),
                leg2_disc_curve_idx: None,
                leg2_forecast_curve_idx: None,
            });
        }

        let result = solver.iterate();
        assert!(result.converged, "Solver should converge: {}", result.status);
        (solver, result)
    }

    #[test]
    fn test_delta_dimensions() {
        let (solver, result) = build_and_solve_5irs();
        // Use 3Y IRS as test instrument
        let test_inst = &solver.instruments[2].instrument;
        let delta = solver.delta(test_inst, &result.jacobian);
        assert_eq!(delta.len(), 5, "Delta should have 5 elements (one per calibrating instrument)");
    }

    #[test]
    fn test_delta_self_sensitivity() {
        let (solver, result) = build_and_solve_5irs();
        // Compute delta of each calibrating instrument w.r.t. itself
        // Each should have dominant sensitivity to its own instrument
        for (i, entry) in solver.instruments.iter().enumerate() {
            let delta = solver.delta(&entry.instrument, &result.jacobian);
            // The i-th element should be the largest in absolute value
            let abs_delta_i = delta[i].abs();
            assert!(abs_delta_i > 0.0, "Delta[{i}] for instrument {i} should be nonzero");
            // All values should be finite
            for (j, &d) in delta.iter().enumerate() {
                assert!(d.is_finite(), "Delta[{j}] should be finite, got {d}");
            }
        }
    }

    #[test]
    fn test_delta_near_zero_check() {
        let (solver, result) = build_and_solve_5irs();
        // The 1Y IRS delta should have meaningful values
        let test_inst = &solver.instruments[0].instrument;
        let delta = solver.delta(test_inst, &result.jacobian);
        let has_nonzero = delta.iter().any(|&d| d.abs() > 1e-10);
        assert!(has_nonzero, "Delta vector should have nonzero entries");
    }

    #[test]
    fn test_gamma_dimensions() {
        let (solver, result) = build_and_solve_5irs();
        let test_inst = &solver.instruments[2].instrument;
        let gamma = solver.gamma(test_inst, &result.jacobian);
        assert_eq!(gamma.len(), 5, "Gamma should have 5 rows");
        for row in &gamma {
            assert_eq!(row.len(), 5, "Gamma row should have 5 columns");
        }
    }

    #[test]
    fn test_gamma_symmetry() {
        let (solver, result) = build_and_solve_5irs();
        let test_inst = &solver.instruments[2].instrument;
        let gamma = solver.gamma(test_inst, &result.jacobian);
        for i in 0..gamma.len() {
            for j in 0..gamma[i].len() {
                assert!(
                    (gamma[i][j] - gamma[j][i]).abs() < 1e-6,
                    "Gamma[{i}][{j}] = {} != Gamma[{j}][{i}] = {}",
                    gamma[i][j], gamma[j][i]
                );
            }
        }
    }

    #[test]
    fn test_gamma_finite() {
        let (solver, result) = build_and_solve_5irs();
        let test_inst = &solver.instruments[2].instrument;
        let gamma = solver.gamma(test_inst, &result.jacobian);
        for (i, row) in gamma.iter().enumerate() {
            for (j, &v) in row.iter().enumerate() {
                assert!(v.is_finite(), "Gamma[{i}][{j}] should be finite, got {v}");
            }
        }
    }

    #[test]
    fn test_risk_report() {
        let (solver, result) = build_and_solve_5irs();
        let test_inst = &solver.instruments[2].instrument;
        let report = solver.risk_report(test_inst, &result.jacobian);
        assert_eq!(report.deltas.len(), 5);
        assert_eq!(report.gammas.len(), 5);
        assert_eq!(report.gammas[0].len(), 5);
    }
}
