use serde::{Serialize, Deserialize};

/// Result of a solver iteration, containing convergence diagnostics.
#[derive(Serialize, Deserialize)]
pub struct SolverResult {
    /// Whether the solver converged to within tolerance.
    pub converged: bool,
    /// Number of iterations performed.
    pub iterations: usize,
    /// Final objective value (sum of weighted squared residuals).
    pub objective: f64,
    /// Final residuals vector (rate - target for each instrument).
    pub residuals: Vec<f64>,
    /// Final Jacobian matrix (n_instruments rows x n_vars cols).
    /// Each row is d(rate_i)/d(var_j).
    pub jacobian: Vec<Vec<f64>>,
    /// Condition number of the Jacobian (ratio of max to min singular values).
    pub condition_number: f64,
    /// Status message describing termination reason.
    pub status: String,
    /// Wall-clock time in seconds.
    pub time_seconds: f64,
    /// Algorithm used for optimization.
    #[serde(default)]
    pub algorithm: String,
}
