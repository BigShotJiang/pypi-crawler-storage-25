use crate::autodiff::enums::Number;
use crate::instruments::Instrument;
use crate::numerical::brent::brent;
use crate::solver::CurveRef;

/// Extract f64 value from a Number (real part for Dual/Dual2).
fn number_to_f64(n: &Number) -> f64 {
    match n {
        Number::F64(v) => *v,
        Number::Dual(d) => d.real(),
        Number::Dual2(d) => d.real(),
    }
}

/// Configuration for iterative bootstrap calibration.
#[derive(Clone, Debug)]
pub struct BootstrapConfig {
    /// Convergence tolerance for residuals (default: 1e-12).
    pub tol: f64,
    /// Maximum outer iterations for global interpolators (default: 10).
    pub max_outer: usize,
    /// Maximum Brent iterations per node (default: 100).
    pub max_brent: usize,
    /// Lower bracket for root search.
    pub bracket_low: f64,
    /// Upper bracket for root search.
    pub bracket_high: f64,
}

impl Default for BootstrapConfig {
    fn default() -> Self {
        Self {
            tol: 1e-12,
            max_outer: 10,
            max_brent: 100,
            bracket_low: -0.05,
            bracket_high: 0.30,
        }
    }
}

impl BootstrapConfig {
    /// Config suited for discount factor curves (bracket for DF values).
    #[allow(dead_code)]
    pub fn for_discount() -> Self {
        Self {
            bracket_low: 0.001,
            bracket_high: 2.0,
            ..Default::default()
        }
    }

    /// Config suited for forward rate curves (bracket for rate values).
    #[allow(dead_code)]
    pub fn for_forward() -> Self {
        Self::default()
    }
}

/// Errors from bootstrap calibration.
#[derive(Clone, Debug)]
pub enum BootstrapError {
    /// A single node failed to converge in Brent root-finding.
    NodeFailed {
        node: usize,
        instrument_label: String,
        message: String,
    },
    /// Outer iteration loop exhausted without convergence.
    OuterIterationFailed {
        max_residual: f64,
        worst_node: usize,
    },
    /// Number of instruments does not match number of calibratable nodes.
    InstrumentCountMismatch {
        instruments: usize,
        nodes: usize,
    },
}

impl std::fmt::Display for BootstrapError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            BootstrapError::NodeFailed { node, instrument_label, message } => {
                write!(f, "Bootstrap node {} ({}) failed: {}", node, instrument_label, message)
            }
            BootstrapError::OuterIterationFailed { max_residual, worst_node } => {
                write!(
                    f,
                    "Bootstrap outer iteration failed: max residual {:.2e} at node {}",
                    max_residual, worst_node
                )
            }
            BootstrapError::InstrumentCountMismatch { instruments, nodes } => {
                write!(
                    f,
                    "Bootstrap instrument count mismatch: {} instruments vs {} nodes",
                    instruments, nodes
                )
            }
        }
    }
}

impl std::error::Error for BootstrapError {}

/// An instrument for bootstrap calibration, mapping one instrument to one curve node.
pub struct BootstrapInstrument {
    pub instrument: Instrument,
    pub target: f64,
    pub disc_curve_idx: usize,
    pub forecast_curve_idx: Option<usize>,
    pub label: String,
}

/// Set a single node value on the target curve (by absolute node index).
/// Uses the curve's set_node_values method to ensure internal state (integrals etc.) is updated.
fn set_node_value(curves: &mut [CurveRef], curve_idx: usize, node_idx: usize, value: f64) {
    let curve = &mut curves[curve_idx];
    let mut vals = curve.get_node_values();
    vals[node_idx] = value;
    match curve {
        CurveRef::Discount(c) => c.set_node_values(&vals),
        CurveRef::Line(c) => c.nodes.set_values_as_f64(&vals),
        CurveRef::CreditImplied(c) => c.nodes.set_values_as_f64(&vals),
        CurveRef::Forward(c) => c.set_node_values(&vals),
    }
}

/// Rebuild spline/interpolator state for a curve after node modification.
fn rebuild_spline_for_curve(curves: &mut [CurveRef], curve_idx: usize) {
    match &mut curves[curve_idx] {
        CurveRef::Discount(c) => c.rebuild_spline(),
        CurveRef::Line(c) => c.rebuild_spline(),
        CurveRef::CreditImplied(_) => {} // no stateful interpolator
        CurveRef::Forward(c) => c.rebuild_spline(),
    }
}

/// Compute the rate for a single bootstrap instrument given the current curve state.
fn compute_instrument_rate(inst: &BootstrapInstrument, curves: &[CurveRef]) -> f64 {
    let disc = curves[inst.disc_curve_idx].as_curve_query();
    let forecast_idx = inst.forecast_curve_idx.unwrap_or(inst.disc_curve_idx);
    let forecast = curves[forecast_idx].as_curve_query();
    let rate = inst.instrument.rate(disc, forecast, None, None, None);
    number_to_f64(&rate)
}

/// Iterative bootstrap calibration: calibrate a target curve node-by-node using
/// Brent root-finding, with outer iterations for global interpolators.
///
/// Each instrument `i` calibrates node `ini_solve + i` on the target curve.
///
/// For local interpolators (flat forward, linear), a single sweep suffices.
/// For global interpolators (natural cubic, B-spline), outer iterations are needed
/// because changing one node affects interpolation at other nodes.
///
/// # Arguments
/// * `instruments` - Bootstrap instruments, one per calibratable node, ordered by maturity
/// * `curves` - Mutable slice of all curves (target + any fixed curves)
/// * `target_curve_idx` - Index of the curve to calibrate in `curves`
/// * `config` - Bootstrap configuration (tolerances, brackets)
///
/// # Returns
/// `Ok(())` on successful convergence, `Err(BootstrapError)` otherwise.
pub fn bootstrap(
    instruments: &[BootstrapInstrument],
    curves: &mut [CurveRef],
    target_curve_idx: usize,
    config: &BootstrapConfig,
) -> Result<(), BootstrapError> {
    let n_vars = curves[target_curve_idx].n_vars();
    let ini_solve = curves[target_curve_idx].ini_solve();

    // Validate instrument count matches calibratable nodes
    if instruments.len() != n_vars {
        return Err(BootstrapError::InstrumentCountMismatch {
            instruments: instruments.len(),
            nodes: n_vars,
        });
    }

    if instruments.is_empty() {
        return Ok(());
    }

    // Outer iteration loop (needed for global interpolators)
    for _outer in 0..config.max_outer {
        // Inner loop: calibrate each node sequentially
        for i in 0..instruments.len() {
            let node_idx = ini_solve + i;

            // Use a local copy of curves for the Brent closure.
            // We need FnMut because we modify curve state inside the closure.
            let inst = &instruments[i];
            let disc_idx = inst.disc_curve_idx;
            let forecast_idx = inst.forecast_curve_idx.unwrap_or(inst.disc_curve_idx);
            let target = inst.target;

            let result = brent(
                |v| {
                    set_node_value(curves, target_curve_idx, node_idx, v);
                    rebuild_spline_for_curve(curves, target_curve_idx);
                    let disc = curves[disc_idx].as_curve_query();
                    let forecast = curves[forecast_idx].as_curve_query();
                    let rate = inst.instrument.rate(disc, forecast, None, None, None);
                    number_to_f64(&rate) - target
                },
                config.bracket_low,
                config.bracket_high,
                config.tol,
                config.max_brent,
            );

            match result {
                Ok(v) => {
                    // Set final converged value and rebuild
                    set_node_value(curves, target_curve_idx, node_idx, v);
                    rebuild_spline_for_curve(curves, target_curve_idx);
                }
                Err(msg) => {
                    return Err(BootstrapError::NodeFailed {
                        node: i,
                        instrument_label: inst.label.clone(),
                        message: msg,
                    });
                }
            }
        }

        // Check all residuals after full sweep
        let mut max_residual = 0.0_f64;
        let mut _worst_node = 0;
        for (i, inst) in instruments.iter().enumerate() {
            let rate = compute_instrument_rate(inst, curves);
            let residual = (rate - inst.target).abs();
            if residual > max_residual {
                max_residual = residual;
                _worst_node = i;
            }
        }

        if max_residual < config.tol {
            return Ok(());
        }
    }

    // Recompute final residual stats for error reporting
    let mut max_residual = 0.0_f64;
    let mut worst_node = 0;
    for (i, inst) in instruments.iter().enumerate() {
        let rate = compute_instrument_rate(inst, curves);
        let residual = (rate - inst.target).abs();
        if residual > max_residual {
            max_residual = residual;
            worst_node = i;
        }
    }

    Err(BootstrapError::OuterIterationFailed {
        max_residual,
        worst_node,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::forward_curve::ForwardCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::interpolation::natural_cubic::NaturalCubicInterpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::instruments::irs::InterestRateSwap;
    use crate::cashflows::leg::{FixedLeg, FloatLeg};
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::cashflows::amortization::Amortization;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use chrono::NaiveDate;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    /// Build a set of IRS instruments and a DiscountCurve for bootstrap testing.
    /// Returns (instruments, curves) with the discount curve at index 0.
    fn build_bootstrap_irs(
        interpolator: Interpolator,
        n_instruments: usize,
    ) -> (Vec<BootstrapInstrument>, Vec<CurveRef>) {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let base_date = ymd(2024, 1, 1);

        // Target rates for 1Y, 2Y, 3Y IRS (or fewer) — in percentage terms (3.0 = 3%)
        let all_targets = vec![3.0, 3.2, 3.4, 3.5, 3.6];
        let all_tenors: Vec<(i32, u32, u32)> = vec![
            (2025, 1, 1),
            (2026, 1, 1),
            (2027, 1, 1),
            (2028, 1, 1),
            (2029, 1, 1),
        ];

        let targets = &all_targets[..n_instruments];
        let tenors = &all_tenors[..n_instruments];

        // Build discount curve with reasonable initial guess DFs
        // exp(-0.03 * years) for ~3% flat rate
        let mut node_map = IndexMap::new();
        node_map.insert(base_date, 1.0);
        for (i, &(y, m, d)) in tenors.iter().enumerate() {
            let years = (i + 1) as f64;
            node_map.insert(ymd(y, m, d), (-0.03 * years).exp());
        }
        let nodes = Nodes::from_f64_map(node_map);
        let curve = DiscountCurve::new(nodes, interpolator, DayCountConvention::Act365F, "disc".to_string());

        let mut instruments = Vec::new();
        for (i, (&target, &(y, m, d))) in targets.iter().zip(tenors.iter()).enumerate() {
            let sched = Schedule::try_new(
                base_date,
                ymd(y, m, d),
                Frequency::Annual,
                cal.clone(),
                Adjuster::ModifiedFollowing,
                None,
                None,
                None,
                StubInference::ShortFront,
            )
            .unwrap();

            let fixed_leg = FixedLeg::new(
                &sched,
                target,
                1_000_000.0,
                DayCountConvention::Act365F,
                "USD".to_string(),
                None,
                Amortization::None,
            );
            let float_leg = FloatLeg::new(
                &sched,
                0.0,
                -1_000_000.0,
                DayCountConvention::Act365F,
                FixingMethod::RFRPaymentDelay,
                SpreadMethod::NoneSimple,
                "USD".to_string(),
                None,
                Amortization::None,
            );
            let irs = InterestRateSwap::new(fixed_leg, float_leg);
            instruments.push(BootstrapInstrument {
                instrument: Instrument::IRS(irs),
                target,
                disc_curve_idx: 0,
                forecast_curve_idx: None,
                label: format!("{}Y_IRS", i + 1),
            });
        }

        let curves = vec![CurveRef::Discount(curve)];
        (instruments, curves)
    }

    #[test]
    fn test_bootstrap_local_single_sweep() {
        // Flat forward is a local interpolator: should converge in 1 sweep
        let (instruments, mut curves) = build_bootstrap_irs(Interpolator::FlatForward, 3);
        let config = BootstrapConfig::for_discount();
        let result = bootstrap(&instruments, &mut curves, 0, &config);
        assert!(result.is_ok(), "Bootstrap should converge: {:?}", result.err());

        // Verify all residuals < 1e-12
        for (i, inst) in instruments.iter().enumerate() {
            let rate = compute_instrument_rate(inst, &curves);
            let residual = (rate - inst.target).abs();
            assert!(
                residual < 1e-12,
                "Instrument {} residual {:.2e} should be < 1e-12",
                i,
                residual
            );
        }
    }

    #[test]
    fn test_bootstrap_global_outer() {
        // Natural cubic is a global interpolator: may need >1 outer sweep.
        // Use a tighter bracket to avoid cubic overshoot with extreme DF values.
        let (instruments, mut curves) = build_bootstrap_irs(
            Interpolator::NaturalCubic(NaturalCubicInterpolator::placeholder()),
            3,
        );
        let config = BootstrapConfig {
            bracket_low: 0.80,
            bracket_high: 1.05,
            ..BootstrapConfig::for_discount()
        };
        let result = bootstrap(&instruments, &mut curves, 0, &config);
        assert!(result.is_ok(), "Bootstrap with natural cubic should converge: {:?}", result.err());

        // Verify all residuals < 1e-12
        for (i, inst) in instruments.iter().enumerate() {
            let rate = compute_instrument_rate(inst, &curves);
            let residual = (rate - inst.target).abs();
            assert!(
                residual < 1e-12,
                "Instrument {} residual {:.2e} should be < 1e-12",
                i,
                residual
            );
        }
    }

    #[test]
    fn test_bootstrap_residual_tolerance() {
        let (instruments, mut curves) = build_bootstrap_irs(Interpolator::LogLinear, 3);
        let config = BootstrapConfig::for_discount();
        bootstrap(&instruments, &mut curves, 0, &config).unwrap();

        // Recompute all rates and assert max |rate - target| < 1e-12
        let max_residual: f64 = instruments
            .iter()
            .map(|inst| {
                let rate = compute_instrument_rate(inst, &curves);
                (rate - inst.target).abs()
            })
            .fold(0.0_f64, f64::max);

        assert!(
            max_residual < 1e-12,
            "Max residual {:.2e} should be < 1e-12",
            max_residual
        );
    }

    #[test]
    fn test_bootstrap_fail_fast() {
        // Set bracket that excludes the root — DFs around 0.97, bracket [1.5, 2.0] excludes it
        let (instruments, mut curves) = build_bootstrap_irs(Interpolator::FlatForward, 3);
        let config = BootstrapConfig {
            bracket_low: 1.5,
            bracket_high: 2.0,
            ..BootstrapConfig::default()
        };
        let result = bootstrap(&instruments, &mut curves, 0, &config);
        assert!(result.is_err(), "Bootstrap should fail with bad bracket");
        match result.unwrap_err() {
            BootstrapError::NodeFailed { node, instrument_label, .. } => {
                assert_eq!(node, 0, "Should fail at first node");
                assert!(instrument_label.contains("1Y"), "Label should reference instrument");
            }
            other => panic!("Expected NodeFailed, got {:?}", other),
        }
    }

    #[test]
    fn test_bootstrap_forward_curve() {
        // ForwardCurve stores forward rates per-day (x-axis is num_days_from_ce).
        // With flat_forward, node i sets the rate from node_i to node_{i+1}.
        // Each instrument's maturity must extend beyond its node for sensitivity.
        //
        // Setup: 3 nodes [base, 1Y, 2Y], 3 instruments [1Y, 2Y, 3Y IRS].
        // inst 0 (1Y IRS) depends on node 0 (fwd rate from base to 1Y).
        // inst 1 (2Y IRS) depends on nodes 0,1 (calibrates node 1).
        // inst 2 (3Y IRS) depends on nodes 0,1,2 (calibrates node 2).
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let base_date = ymd(2024, 1, 1);
        let daily_rate = 0.03 / 365.0;

        let node_dates = vec![base_date, ymd(2025, 1, 1), ymd(2026, 1, 1)];
        let mut node_map = IndexMap::new();
        for &d in &node_dates {
            node_map.insert(d, daily_rate);
        }
        let nodes = Nodes::from_f64_map(node_map);
        let fwd_curve = ForwardCurve::new(
            nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd".to_string(),
        );

        let mut curves = vec![CurveRef::Forward(fwd_curve)];

        // 3 instruments for 3 nodes
        let inst_targets = vec![3.0, 3.2, 3.4]; // percentage
        let inst_end_dates = vec![ymd(2025, 1, 1), ymd(2026, 1, 1), ymd(2027, 1, 1)];

        let mut instruments = Vec::new();
        for (i, (&target, &end_date)) in inst_targets.iter().zip(inst_end_dates.iter()).enumerate() {
            let sched = Schedule::try_new(
                base_date,
                end_date,
                Frequency::Annual,
                cal.clone(),
                Adjuster::ModifiedFollowing,
                None, None, None,
                StubInference::ShortFront,
            ).unwrap();

            let fixed_leg = FixedLeg::new(&sched, target, 1_000_000.0, DayCountConvention::Act365F, "USD".to_string(), None, Amortization::None);
            let float_leg = FloatLeg::new(&sched, 0.0, -1_000_000.0, DayCountConvention::Act365F, FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple, "USD".to_string(), None, Amortization::None);
            let irs = InterestRateSwap::new(fixed_leg, float_leg);
            instruments.push(BootstrapInstrument {
                instrument: Instrument::IRS(irs),
                target,
                disc_curve_idx: 0,
                forecast_curve_idx: None,
                label: format!("{}Y_IRS", i + 1),
            });
        }

        // Bracket for per-day forward rates
        let config = BootstrapConfig {
            bracket_low: -0.001,
            bracket_high: 0.002,
            ..BootstrapConfig::for_forward()
        };
        let result = bootstrap(&instruments, &mut curves, 0, &config);
        assert!(result.is_ok(), "ForwardCurve bootstrap should converge: {:?}", result.err());

        // Verify residuals
        for (i, inst) in instruments.iter().enumerate() {
            let rate = compute_instrument_rate(inst, &curves);
            let residual = (rate - inst.target).abs();
            assert!(
                residual < 1e-12,
                "ForwardCurve instrument {} residual {:.2e} should be < 1e-12",
                i,
                residual
            );
        }
    }

    #[test]
    fn test_bootstrap_multi_curve() {
        // Multi-curve: fixed discount curve, calibrate forward curve
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let base_date = ymd(2024, 1, 1);

        // Build a pre-calibrated discount curve (with known DFs)
        let disc_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (base_date, 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
        ]));
        let disc_curve = DiscountCurve::new(
            disc_nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc".to_string(),
        );

        // Build forward curve to calibrate.
        // ForwardCurve stores per-day forward rates, nodes at [base, 1Y, 2Y].
        // 3 nodes = 3 calibratable vars, 3 instruments [1Y, 2Y, 3Y].
        let daily_rate = 0.035 / 365.0;
        let fwd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (base_date, daily_rate),
            (ymd(2025, 1, 1), daily_rate),
            (ymd(2026, 1, 1), daily_rate),
        ]));
        let fwd_curve = ForwardCurve::new(
            fwd_nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "fwd".to_string(),
        );

        let mut curves = vec![
            CurveRef::Discount(disc_curve),  // index 0: fixed discount
            CurveRef::Forward(fwd_curve),     // index 1: calibrate this
        ];

        let targets = vec![3.5, 3.7, 3.9]; // percentage, 3 instruments
        let tenors = vec![ymd(2025, 1, 1), ymd(2026, 1, 1), ymd(2027, 1, 1)];

        let mut instruments = Vec::new();
        for (i, (&target, &end_date)) in targets.iter().zip(tenors.iter()).enumerate() {
            let sched = Schedule::try_new(
                base_date,
                end_date,
                Frequency::Annual,
                cal.clone(),
                Adjuster::ModifiedFollowing,
                None,
                None,
                None,
                StubInference::ShortFront,
            )
            .unwrap();

            let fixed_leg = FixedLeg::new(
                &sched,
                target,
                1_000_000.0,
                DayCountConvention::Act365F,
                "USD".to_string(),
                None,
                Amortization::None,
            );
            let float_leg = FloatLeg::new(
                &sched,
                0.0,
                -1_000_000.0,
                DayCountConvention::Act365F,
                FixingMethod::RFRPaymentDelay,
                SpreadMethod::NoneSimple,
                "USD".to_string(),
                None,
                Amortization::None,
            );
            let irs = InterestRateSwap::new(fixed_leg, float_leg);
            instruments.push(BootstrapInstrument {
                instrument: Instrument::IRS(irs),
                target,
                disc_curve_idx: 0,      // discount from fixed disc curve
                forecast_curve_idx: Some(1), // forecast from forward curve
                label: format!("{}Y_IRS", i + 1),
            });
        }

        // Bracket for per-day forward rates
        let config = BootstrapConfig {
            bracket_low: -0.001,
            bracket_high: 0.002,
            ..BootstrapConfig::for_forward()
        };
        let result = bootstrap(&instruments, &mut curves, 1, &config);
        assert!(result.is_ok(), "Multi-curve bootstrap should converge: {:?}", result.err());

        // Verify residuals
        for (i, inst) in instruments.iter().enumerate() {
            let rate = compute_instrument_rate(inst, &curves);
            let residual = (rate - inst.target).abs();
            assert!(
                residual < 1e-12,
                "Multi-curve instrument {} residual {:.2e} should be < 1e-12",
                i,
                residual
            );
        }
    }

    #[test]
    fn test_bootstrap_instrument_count_mismatch() {
        // 3 instruments but 4 calibratable nodes (5 total - 1 ini_solve = 4)
        let (mut instruments, mut curves) = build_bootstrap_irs(Interpolator::FlatForward, 3);
        // Add an extra node to the curve
        let curve = match &curves[0] {
            CurveRef::Discount(c) => c.clone(),
            _ => unreachable!(),
        };
        let mut node_map = IndexMap::new();
        for (&date, &val) in curve.nodes.keys().iter().zip(curve.nodes.get_values_f64().iter()) {
            node_map.insert(date, val);
        }
        node_map.insert(ymd(2030, 1, 1), 1.0); // extra node
        let new_nodes = Nodes::from_f64_map(node_map);
        let new_curve = DiscountCurve::new(
            new_nodes,
            Interpolator::FlatForward,
            DayCountConvention::Act365F,
            "disc".to_string(),
        );
        curves[0] = CurveRef::Discount(new_curve);

        let config = BootstrapConfig::for_discount();
        let result = bootstrap(&instruments, &mut curves, 0, &config);
        assert!(result.is_err(), "Should fail with mismatched count");
        match result.unwrap_err() {
            BootstrapError::InstrumentCountMismatch { instruments: n_inst, nodes: n_nodes } => {
                assert_eq!(n_inst, 3);
                assert_eq!(n_nodes, 4); // 5 total - 1 ini_solve = 4
            }
            other => panic!("Expected InstrumentCountMismatch, got {:?}", other),
        }
    }
}
