use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::cashflows::period::CashflowRow;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::marketcurves::curve::CurveQuery;
use crate::models::hull_white::HullWhiteTree;
use crate::numerical::brent::brent;

use super::bond::BondInstrument;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/// Call exercise schedule: `(exercise_date, strike_price)` pairs.
pub type CallSchedule = Vec<(NaiveDate, f64)>;

/// Put exercise schedule: `(exercise_date, strike_price)` pairs.
pub type PutSchedule = Vec<(NaiveDate, f64)>;

// ---------------------------------------------------------------------------
// CallableBondInstrument
// ---------------------------------------------------------------------------

/// Callable (and/or puttable) bond priced via a Hull-White trinomial tree.
///
/// Wraps a [`BondInstrument`] with call and put schedules.  Pricing uses
/// backward induction on a Hull-White one-factor short-rate tree.
///
/// The tree is build-once / price-many: `tree_price` rebuilds per call but
/// `oas` builds the tree once and reprices with varying spread.
#[derive(Clone, Serialize, Deserialize)]
pub struct CallableBondInstrument {
    pub bond: BondInstrument,
    pub call_schedule: CallSchedule,
    pub put_schedule: Option<PutSchedule>,
}

impl CallableBondInstrument {
    /// Create a new CallableBondInstrument.
    ///
    /// # Panics
    /// Panics if `call_schedule` is empty AND `put_schedule` is None/empty.
    pub fn new(
        bond: BondInstrument,
        call_schedule: CallSchedule,
        put_schedule: Option<PutSchedule>,
    ) -> Self {
        let has_calls = !call_schedule.is_empty();
        let has_puts = put_schedule.as_ref().map_or(false, |p| !p.is_empty());
        assert!(
            has_calls || has_puts,
            "CallableBondInstrument requires at least one call or put entry"
        );
        let mut sorted_calls = call_schedule;
        sorted_calls.sort_by_key(|&(d, _)| d);
        CallableBondInstrument {
            bond,
            call_schedule: sorted_calls,
            put_schedule,
        }
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /// Collect all mandatory dates for the tree: cashflow payment dates,
    /// call dates, put dates, and bond termination.
    fn mandatory_dates(&self) -> Vec<NaiveDate> {
        let cfs = self.bond.variant.bond_cashflows(
            self.bond.effective,
            self.bond.face_value,
            self.bond.termination,
            None,
        );
        let mut dates: Vec<NaiveDate> = cfs.iter().map(|cf| cf.payment).collect();
        dates.extend(self.call_schedule.iter().map(|&(d, _)| d));
        if let Some(ref puts) = self.put_schedule {
            dates.extend(puts.iter().map(|&(d, _)| d));
        }
        dates.push(self.bond.termination);
        dates.sort();
        dates.dedup();
        dates
    }

    /// Convert bond cashflows to `(time, amount)` pairs.
    fn cashflow_pairs(&self, conv: DayCountConvention) -> Vec<(f64, f64)> {
        let cfs = self.bond.variant.bond_cashflows(
            self.bond.effective,
            self.bond.face_value,
            self.bond.termination,
            None,
        );
        cfs.iter()
            .map(|cf| {
                let t = conv
                    .dcf(self.bond.effective, cf.payment, &DcfOptions::default())
                    .unwrap_or(0.0);
                let amt = match &cf.amount {
                    Number::F64(v) => *v,
                    Number::Dual(d) => d.real,
                    Number::Dual2(d) => d.real,
                };
                (t, amt)
            })
            .collect()
    }

    /// Convert a schedule of `(NaiveDate, f64)` to `(time, f64)`.
    fn schedule_to_times(
        &self,
        schedule: &[(NaiveDate, f64)],
        conv: DayCountConvention,
    ) -> Vec<(f64, f64)> {
        schedule
            .iter()
            .map(|&(d, strike)| {
                let t = conv
                    .dcf(self.bond.effective, d, &DcfOptions::default())
                    .unwrap_or(0.0);
                (t, strike)
            })
            .collect()
    }

    /// Build tree (helper for internal use).
    fn build_tree(&self, curve: &dyn CurveQuery, a: f64, sigma: f64) -> HullWhiteTree {
        let dates = self.mandatory_dates();
        HullWhiteTree::build(
            a,
            sigma,
            curve,
            self.bond.effective,
            &dates,
            self.bond.convention,
        )
    }

    /// Price using a pre-built tree with a given spread.
    fn price_with_tree(&self, tree: &HullWhiteTree, spread: f64) -> f64 {
        let conv = self.bond.convention;
        let cf_pairs = self.cashflow_pairs(conv);
        let call_times = self.schedule_to_times(&self.call_schedule, conv);
        let put_times = match &self.put_schedule {
            Some(puts) => self.schedule_to_times(puts, conv),
            None => vec![],
        };
        tree.price_callable(&cf_pairs, &call_times, &put_times, spread)
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /// Price the callable bond using a Hull-White tree.
    ///
    /// * `curve` -- discount curve for tree calibration
    /// * `a` -- HW mean-reversion speed
    /// * `sigma` -- HW short-rate volatility
    /// * `spread` -- OAS spread (0.0 for model price without spread)
    pub fn tree_price(
        &self,
        curve: &dyn CurveQuery,
        a: f64,
        sigma: f64,
        spread: f64,
    ) -> f64 {
        let tree = self.build_tree(curve, a, sigma);
        self.price_with_tree(&tree, spread)
    }

    /// Compute the option-adjusted spread (OAS).
    ///
    /// Finds spread `s` such that `tree_price(s) = market_price`.
    /// Builds the tree ONCE and varies spread in backward induction (efficient).
    pub fn oas(
        &self,
        curve: &dyn CurveQuery,
        market_price: f64,
        a: f64,
        sigma: f64,
    ) -> Result<f64, String> {
        let tree = self.build_tree(curve, a, sigma);
        brent(
            |s| self.price_with_tree(&tree, s) - market_price,
            -0.20,
            0.20,
            1e-10,
            100,
        )
    }

    /// Effective duration via symmetric bump-and-reprice on the OAS spread.
    ///
    /// `(P_down - P_up) / (2 * P * bump)`
    pub fn effective_duration(
        &self,
        curve: &dyn CurveQuery,
        a: f64,
        sigma: f64,
        oas: f64,
        bump: f64,
    ) -> f64 {
        let tree = self.build_tree(curve, a, sigma);
        let p = self.price_with_tree(&tree, oas);
        let p_up = self.price_with_tree(&tree, oas + bump);
        let p_down = self.price_with_tree(&tree, oas - bump);
        (p_down - p_up) / (2.0 * p * bump)
    }

    /// Effective convexity via symmetric bump-and-reprice on the OAS spread.
    ///
    /// `(P_up + P_down - 2*P) / (bump^2 * P)`
    pub fn effective_convexity(
        &self,
        curve: &dyn CurveQuery,
        a: f64,
        sigma: f64,
        oas: f64,
        bump: f64,
    ) -> f64 {
        let tree = self.build_tree(curve, a, sigma);
        let p = self.price_with_tree(&tree, oas);
        let p_up = self.price_with_tree(&tree, oas + bump);
        let p_down = self.price_with_tree(&tree, oas - bump);
        (p_up + p_down - 2.0 * p) / (bump * bump * p)
    }

    /// Vega: sensitivity to Hull-White sigma.
    ///
    /// Requires two full tree rebuilds (different sigma => different geometry).
    pub fn vega(
        &self,
        curve: &dyn CurveQuery,
        a: f64,
        sigma: f64,
        oas: f64,
        bump: f64,
    ) -> f64 {
        let p_up = self.tree_price(curve, a, sigma + bump, oas);
        let p_down = self.tree_price(curve, a, sigma - bump, oas);
        (p_up - p_down) / (2.0 * bump)
    }

    // -----------------------------------------------------------------------
    // Instrument trait delegation
    // -----------------------------------------------------------------------

    /// Rate: delegate to underlying bond.
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.bond.rate(disc_curve, forecast_curve)
    }

    /// NPV: delegate to underlying bond.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.bond.npv(disc_curve, forecast_curve, false, None)
    }

    /// Cashflows: delegate to underlying bond.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        self.bond.cashflows(disc_curve, forecast_curve)
    }

    /// Spread: delegate to underlying bond.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.bond.spread(disc_curve, forecast_curve)
    }

    /// Pillar date: bond termination.
    pub fn pillar_date(&self) -> NaiveDate {
        self.bond.termination
    }

    /// Analytic delta: delegate to underlying bond.
    pub fn analytic_delta(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.bond.analytic_delta(disc_curve, forecast_curve)
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn flat_curve_3pct() -> DiscountCurve {
        let rate = 0.03;
        let base = ymd(2024, 1, 1);
        let conv = DayCountConvention::Act365F;
        let mut map = IndexMap::new();
        for yr in 0..=10 {
            let d = ymd(2024 + yr, 1, 1);
            let t = conv.dcf(base, d, &DcfOptions::default()).unwrap_or(0.0);
            let df = (-rate * t).exp();
            map.insert(d, df);
        }
        DiscountCurve::new(
            Nodes::from_f64_map(map),
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "flat3pct".to_string(),
        )
    }

    pub fn make_test_callable_bond() -> CallableBondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![0, 1, 2, 3, 4]);
        let bond = BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.04,
            Frequency::Annual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        );
        let call_schedule = vec![
            (ymd(2026, 1, 1), 100.0),
            (ymd(2027, 1, 1), 100.0),
            (ymd(2028, 1, 1), 100.0),
        ];
        CallableBondInstrument::new(bond, call_schedule, None)
    }

    #[test]
    fn test_create_callable_bond() {
        let cb = make_test_callable_bond();
        assert_eq!(cb.call_schedule.len(), 3);
        assert!(cb.put_schedule.is_none());
        assert_eq!(cb.bond.termination, ymd(2029, 1, 1));
    }

    #[test]
    fn test_oas_round_trip() {
        let curve = flat_curve_3pct();
        let cb = make_test_callable_bond();

        // Compute model price at spread=0
        let model_price = cb.tree_price(&curve, 0.1, 0.01, 0.0);
        assert!(model_price > 0.0, "Model price should be positive");

        // OAS given that price should be ~0
        let oas = cb.oas(&curve, model_price, 0.1, 0.01).unwrap();
        assert!(
            oas.abs() < 1e-8,
            "OAS round-trip should give ~0, got {}", oas
        );
    }

    #[test]
    fn test_effective_duration_positive() {
        let curve = flat_curve_3pct();
        let cb = make_test_callable_bond();
        let dur = cb.effective_duration(&curve, 0.1, 0.01, 0.0, 0.0001);
        assert!(
            dur > 0.0 && dur.is_finite(),
            "Effective duration should be positive and finite, got {}", dur
        );
    }

    #[test]
    fn test_vega_negative() {
        let curve = flat_curve_3pct();
        let cb = make_test_callable_bond();
        let v = cb.vega(&curve, 0.1, 0.01, 0.0, 0.0001);
        // For a callable bond holder, higher vol => higher option value to issuer
        // => lower bond price => vega < 0
        assert!(
            v < 0.0 && v.is_finite(),
            "Vega should be negative and finite for a callable bond, got {}", v
        );
    }

    #[test]
    fn test_instrument_enum_dispatch() {
        use crate::instruments::Instrument;

        let curve = flat_curve_3pct();
        let cb = make_test_callable_bond();
        let inst = Instrument::CallableBond(cb);

        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "Rate should be finite"),
            _ => panic!("Expected F64"),
        }

        let npv = inst.npv(&curve, &curve, None, None, None);
        match npv {
            Number::F64(v) => assert!(v.is_finite(), "NPV should be finite"),
            _ => panic!("Expected F64"),
        }

        let pillar = inst.pillar_date();
        assert_eq!(pillar, ymd(2029, 1, 1));
    }
}
