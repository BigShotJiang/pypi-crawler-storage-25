use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::convention::DcfOptions;
use crate::cashflows::credit_leg::{CreditPremiumLeg, CreditProtectionLeg};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;

/// Credit Default Swap instrument composing a CreditPremiumLeg and CreditProtectionLeg.
///
/// CDS is priced using a financial discount curve (disc_curve) and a credit implied
/// curve (credit_curve, which provides survival probabilities via CurveQuery::discount_factor).
///
/// Supports Big Bang conventions (D-31): standard coupon (100bp or 500bp) + upfront payment.
#[derive(Clone, Serialize, Deserialize)]
pub struct CreditDefaultSwap {
    pub premium_leg: CreditPremiumLeg,
    pub protection_leg: CreditProtectionLeg,
    pub recovery_rate: f64,
    pub notional: f64,
    /// Fixed coupon rate in basis points (e.g. 100.0 for 100bp).
    pub fixed_rate: f64,
    pub currency: String,
}

impl CreditDefaultSwap {
    /// Construct a CDS from pre-built legs.
    pub fn new(
        premium_leg: CreditPremiumLeg,
        protection_leg: CreditProtectionLeg,
        recovery_rate: f64,
        notional: f64,
        fixed_rate: f64,
        currency: String,
    ) -> Self {
        Self {
            premium_leg,
            protection_leg,
            recovery_rate,
            notional,
            fixed_rate,
            currency,
        }
    }

    /// Par spread: the rate (in basis points) at which premium NPV equals protection NPV.
    ///
    /// rate = protection_npv / annuity (result scaled to basis points via annuity normalization).
    ///
    /// For Instrument enum dispatch: disc_curve = financial DF, forecast_curve = credit curve.
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let prot_npv = self.protection_leg.npv(disc_curve, credit_curve);
        let annuity = self.premium_leg.annuity(disc_curve, credit_curve);
        // Protection NPV is negative (buyer receives), annuity is positive.
        // Par spread in decimal = |protection_npv| / annuity = -protection_npv / annuity
        // Then convert to basis points: * 10000
        let spread_decimal = &(-&prot_npv) / &(&annuity * self.notional);
        &spread_decimal * 10000.0
    }

    /// Net present value of the CDS from the protection buyer's perspective.
    ///
    /// NPV = -protection_leg.npv + premium_leg.npv
    ///
    /// Protection leg NPV is negative by convention (cost to seller = value to buyer).
    /// Premium leg NPV is negative by convention (cost to buyer).
    /// Negating protection makes it positive (value received), adding premium (negative) = net.
    /// At par spread, NPV ~ 0.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let prem = self.premium_leg.npv(disc_curve, credit_curve);
        let prot = self.protection_leg.npv(disc_curve, credit_curve);
        // Protection value to buyer = -prot (negate seller's cost)
        // Premium cost to buyer = prem (already negative)
        -prot + prem
    }

    /// Spread: difference between par spread and fixed coupon (in basis points).
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let par = self.rate(disc_curve, credit_curve);
        &par - self.fixed_rate
    }

    /// Cashflow rows from both premium and protection legs.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        credit_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let mut rows = self.premium_leg.cashflows(disc_curve, credit_curve);
        rows.extend(self.protection_leg.cashflows(disc_curve, credit_curve));
        rows.sort_by_key(|r| r.payment);
        rows
    }

    /// Accrued premium from last coupon date to today.
    ///
    /// accrued = notional * dcf(last_coupon, today) * fixed_rate / 10000
    pub fn accrued(&self, today: NaiveDate) -> f64 {
        // Find the last coupon date that is <= today
        let mut last_coupon = None;
        let mut next_coupon_end = None;
        for p in &self.premium_leg.periods {
            if p.start <= today && today < p.end {
                last_coupon = Some(p.start);
                next_coupon_end = Some(p.end);
                break;
            }
        }

        match (last_coupon, next_coupon_end) {
            (Some(start), Some(_end)) => {
                let convention = self.premium_leg.periods[0].convention;
                let dcf = convention
                    .dcf(start, today, &DcfOptions::default())
                    .unwrap();
                self.notional * dcf * self.fixed_rate / 10000.0
            }
            _ => 0.0,
        }
    }

    /// Analytic recovery risk: dNPV/dR.
    ///
    /// Since protection NPV is proportional to (1-R), analytic_rec_risk = protection_npv / (R - 1).
    pub fn analytic_rec_risk(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let prot_npv = self.protection_leg.npv(disc_curve, credit_curve);
        // protection_npv = -(1-R) * N * integral
        // d/dR [protection_npv] = N * integral = protection_npv / (R - 1)
        &prot_npv / (self.recovery_rate - 1.0)
    }

    /// Pillar date: last protection period end date (maturity).
    pub fn pillar_date(&self) -> NaiveDate {
        self.protection_leg
            .periods
            .last()
            .map(|p| p.end)
            .unwrap_or_else(|| {
                self.premium_leg
                    .periods
                    .last()
                    .map(|p| p.end)
                    .expect("CDS must have at least one period")
            })
    }

    /// Jump-to-Default: immediate loss if default occurs now.
    ///
    /// JTD = (1 - R) * N - accrued
    pub fn jtd(&self, today: NaiveDate) -> f64 {
        (1.0 - self.recovery_rate) * self.notional - self.accrued(today)
    }

    /// Exposure at Default.
    ///
    /// EAD = (1 - R) * N
    pub fn ead(&self) -> f64 {
        (1.0 - self.recovery_rate) * self.notional
    }

    /// Upfront payment as percentage of notional (D-31, Big Bang conventions).
    ///
    /// ISDA 2009 Big Bang: CDS trades with standard coupon + upfront payment.
    /// upfront = (protection_npv + premium_npv) / notional * 100
    /// Positive = buyer pays upfront, Negative = buyer receives.
    pub fn upfront(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let npv = self.npv(disc_curve, credit_curve);
        // NPV from buyer's perspective: premium (negative, buyer pays) + protection (negative, buyer receives)
        // Upfront = -NPV / notional * 100 (percentage of notional)
        &(&npv / self.notional) * 100.0
    }

    /// Upfront amount (raw Number value, not percentage).
    pub fn upfront_amount(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        self.npv(disc_curve, credit_curve)
    }

    /// Convert par spread to upfront+coupon format (D-31).
    ///
    /// upfront_spread = (par_spread - fixed_rate) * risky_annuity
    /// This is the spread-equivalent of the upfront payment.
    pub fn to_upfront_spread(
        &self,
        disc_curve: &dyn CurveQuery,
        credit_curve: &dyn CurveQuery,
    ) -> Number {
        let par_spread = self.rate(disc_curve, credit_curve);
        let spread_diff = &par_spread - self.fixed_rate;
        let annuity = self.premium_leg.annuity(disc_curve, credit_curve);
        // Risky annuity per unit notional
        let risky_annuity = &annuity * self.notional;
        // upfront_spread in bp * annuity_value
        &spread_diff * &risky_annuity
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::credit::CreditImpliedCurve;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::frequency::Frequency;
    use crate::calendar::adjuster::Adjuster;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn disc_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.88),
            (ymd(2029, 1, 1), 0.85),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "disc".to_string(),
        )
    }

    fn credit_curve() -> CreditImpliedCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 0.01),
            (ymd(2025, 1, 1), 0.02),
            (ymd(2026, 1, 1), 0.02),
            (ymd(2027, 1, 1), 0.02),
            (ymd(2028, 1, 1), 0.02),
            (ymd(2029, 1, 1), 0.02),
        ]));
        CreditImpliedCurve::new(
            nodes,
            DayCountConvention::Act365F,
            0.40,
            "credit".to_string(),
        )
    }

    fn test_schedule() -> Schedule {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            Frequency::Quarterly,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap()
    }

    pub fn make_test_cds() -> CreditDefaultSwap {
        let schedule = test_schedule();
        let premium_leg = CreditPremiumLeg::new(
            &schedule,
            10_000_000.0,
            100.0, // 100bp
            DayCountConvention::Act360,
            "USD".to_string(),
            true,
            0.40,
        );
        let protection_leg = CreditProtectionLeg::new(
            &schedule,
            10_000_000.0,
            0.40,
            DayCountConvention::Act365F,
            "USD".to_string(),
        );
        CreditDefaultSwap::new(
            premium_leg,
            protection_leg,
            0.40,
            10_000_000.0,
            100.0,
            "USD".to_string(),
        )
    }

    #[test]
    fn test_cds_par_spread() {
        let dc = disc_curve();
        let cc = credit_curve();
        let cds = make_test_cds();

        let par = cds.rate(&dc, &cc);
        if let Number::F64(r) = par {
            // Par spread should be positive and in reasonable range (basis points)
            assert!(r > 0.0, "Par spread should be positive, got {r}");
            assert!(r < 1000.0, "Par spread should be < 1000bp, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_cds_npv_at_par() {
        let dc = disc_curve();
        let cc = credit_curve();
        let schedule = test_schedule();

        // Get par spread first
        let cds_for_rate = make_test_cds();
        let par_spread = match cds_for_rate.rate(&dc, &cc) {
            Number::F64(r) => r,
            _ => panic!("Expected F64"),
        };

        // Build CDS at par spread
        let premium_leg = CreditPremiumLeg::new(
            &schedule,
            10_000_000.0,
            par_spread,
            DayCountConvention::Act360,
            "USD".to_string(),
            true,
            0.40,
        );
        let protection_leg = CreditProtectionLeg::new(
            &schedule,
            10_000_000.0,
            0.40,
            DayCountConvention::Act365F,
            "USD".to_string(),
        );
        let cds = CreditDefaultSwap::new(
            premium_leg,
            protection_leg,
            0.40,
            10_000_000.0,
            par_spread,
            "USD".to_string(),
        );

        let npv = cds.npv(&dc, &cc);
        if let Number::F64(v) = npv {
            assert!(
                v.abs() < 1.0,
                "NPV at par spread should be ~0, got {v}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_cds_spread() {
        let dc = disc_curve();
        let cc = credit_curve();
        let cds = make_test_cds();

        let par = cds.rate(&dc, &cc);
        let spread = cds.spread(&dc, &cc);
        if let (Number::F64(p), Number::F64(s)) = (&par, &spread) {
            let expected = p - 100.0; // fixed_rate = 100bp
            assert!(
                (s - expected).abs() < 1e-10,
                "Spread ({s}) should equal rate ({p}) - fixed_rate (100)"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_cds_pillar_date() {
        let cds = make_test_cds();
        let pillar = cds.pillar_date();
        assert_eq!(pillar, ymd(2029, 1, 1), "Pillar should be maturity date");
    }

    #[test]
    fn test_cds_jtd() {
        let cds = make_test_cds();
        // Before the first coupon period (no accrued)
        let jtd = cds.jtd(ymd(2023, 12, 31));
        let expected = (1.0 - 0.40) * 10_000_000.0;
        assert!(
            (jtd - expected).abs() < 1e-6,
            "JTD should be {expected}, got {jtd}"
        );
    }

    #[test]
    fn test_cds_ead() {
        let cds = make_test_cds();
        let ead = cds.ead();
        let expected = (1.0 - 0.40) * 10_000_000.0;
        assert!(
            (ead - expected).abs() < 1e-6,
            "EAD should be {expected}, got {ead}"
        );
    }

    #[test]
    fn test_cds_cashflows() {
        let dc = disc_curve();
        let cc = credit_curve();
        let cds = make_test_cds();

        let rows = cds.cashflows(Some(&dc), Some(&cc));
        assert!(!rows.is_empty(), "Should have cashflow rows");

        let has_premium = rows.iter().any(|r| r.period_type == "CreditPremium");
        let has_protection = rows.iter().any(|r| r.period_type == "CreditProtection");
        assert!(has_premium, "Should have CreditPremium rows");
        assert!(has_protection, "Should have CreditProtection rows");
    }

    #[test]
    fn test_cds_instrument_enum() {
        use crate::instruments::Instrument;

        let dc = disc_curve();
        let cc = credit_curve();
        let cds = make_test_cds();
        let inst = Instrument::CDS(cds);

        let rate = inst.rate(&dc, &cc, None, None, None);
        if let Number::F64(r) = rate {
            assert!(r > 0.0, "CDS rate via enum should be positive, got {r}");
        } else {
            panic!("Expected F64");
        }

        let npv = inst.npv(&dc, &cc, None, None, None);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "CDS NPV via enum should be finite, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_cds_upfront() {
        let dc = disc_curve();
        let cc = credit_curve();
        let cds = make_test_cds();

        let upfront = cds.upfront(&dc, &cc);
        if let Number::F64(v) = upfront {
            assert!(v.is_finite(), "Upfront should be finite, got {v}");
        } else {
            panic!("Expected F64");
        }

        // Upfront amount should equal NPV
        let npv = cds.npv(&dc, &cc);
        let upfront_amt = cds.upfront_amount(&dc, &cc);
        if let (Number::F64(n), Number::F64(u)) = (&npv, &upfront_amt) {
            assert!(
                (n - u).abs() < 1e-10,
                "Upfront amount ({u}) should equal NPV ({n})"
            );
        }
    }

    #[test]
    fn test_cds_to_upfront_spread() {
        let dc = disc_curve();
        let cc = credit_curve();
        let cds = make_test_cds();

        let upfront_spread = cds.to_upfront_spread(&dc, &cc);
        if let Number::F64(v) = upfront_spread {
            assert!(v.is_finite(), "Upfront spread should be finite, got {v}");
        } else {
            panic!("Expected F64");
        }
    }
}
