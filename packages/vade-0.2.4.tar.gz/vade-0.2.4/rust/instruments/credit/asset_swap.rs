use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;

use super::bond::{BondInstrument, BondVariant};

// ---------------------------------------------------------------------------
// AssetSwapType
// ---------------------------------------------------------------------------

/// Type of asset swap: par-par or market value (non-par).
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub enum AssetSwapType {
    Par,
    MarketValue,
}

// ---------------------------------------------------------------------------
// AssetSwapInstrument
// ---------------------------------------------------------------------------

/// Asset swap instrument computing par or non-par (market value) spread.
///
/// Owns a BondInstrument and computes the spread over a float index that
/// equates the present value of the bond leg with the float leg.
///
/// - Par: spread = (model_dirty - face_value) / (annuity * face_value)
/// - MarketValue: spread = (model_dirty - dirty_target) / (annuity * face_value)
#[derive(Clone, Serialize, Deserialize)]
pub struct AssetSwapInstrument {
    pub bond: BondInstrument,
    pub asw_type: AssetSwapType,
    pub dirty_price: Option<f64>,
    pub fixed_spread: Option<f64>,
}

impl AssetSwapInstrument {
    /// Create a new AssetSwapInstrument.
    ///
    /// # Panics
    /// Panics if `asw_type` is `MarketValue` and `dirty_price` is `None`.
    pub fn new(
        bond: BondInstrument,
        asw_type: AssetSwapType,
        dirty_price: Option<f64>,
        fixed_spread: Option<f64>,
    ) -> Self {
        if asw_type == AssetSwapType::MarketValue && dirty_price.is_none() {
            panic!("dirty_price is required for MarketValue (non-par) asset swap");
        }
        AssetSwapInstrument {
            bond,
            asw_type,
            dirty_price,
            fixed_spread,
        }
    }

    /// Compute the annuity (PV01) of the bond: sum of DF(payment_i) * dcf_i
    /// for all remaining coupon periods.
    ///
    /// Returns Number to preserve AD derivatives.
    fn compute_annuity(&self, curve: &dyn CurveQuery) -> Number {
        match &self.bond.variant {
            BondVariant::FixedRate(data) => {
                let mut annuity = Number::F64(0.0);
                for period in &data.periods {
                    let df = curve.discount_factor(period.payment);
                    annuity = annuity + df * period.dcf;
                }
                annuity
            }
            BondVariant::Bill(_) | BondVariant::ZeroCoupon(_) => {
                // Single period: effective to termination
                let dcf = self.bond.convention
                    .dcf(
                        self.bond.effective,
                        self.bond.termination,
                        &crate::calendar::convention::DcfOptions::default(),
                    )
                    .unwrap_or(1.0);
                let df = curve.discount_factor(self.bond.termination);
                df * dcf
            }
            BondVariant::FloatRateNote(data) => {
                let mut annuity = Number::F64(0.0);
                for period in &data.periods {
                    let df = curve.discount_factor(period.payment);
                    annuity = annuity + df * period.dcf;
                }
                annuity
            }
            BondVariant::StepUp(data) => {
                let mut annuity = Number::F64(0.0);
                for period in &data.periods {
                    let df = curve.discount_factor(period.payment);
                    annuity = annuity + df * period.dcf;
                }
                annuity
            }
            BondVariant::Amortizing(data) => {
                let mut annuity = Number::F64(0.0);
                for period in &data.periods {
                    let df = curve.discount_factor(period.payment);
                    annuity = annuity + df * period.dcf;
                }
                annuity
            }
            BondVariant::PIK(data) => {
                let mut annuity = Number::F64(0.0);
                for period in &data.periods {
                    let df = curve.discount_factor(period.payment);
                    annuity = annuity + df * period.dcf;
                }
                annuity
            }
            BondVariant::SubPeriodFRN(data) => {
                let mut annuity = Number::F64(0.0);
                for period in &data.periods {
                    // Use the total dcf across sub-periods
                    let total_dcf: f64 = period.sub_periods.iter().map(|sp| sp.dcf).sum();
                    let df = curve.discount_factor(period.payment);
                    annuity = annuity + df * total_dcf;
                }
                annuity
            }
            BondVariant::CappedFloored(data) => {
                let mut annuity = Number::F64(0.0);
                for period in &data.periods {
                    let df = curve.discount_factor(period.payment);
                    annuity = annuity + df * period.dcf;
                }
                annuity
            }
        }
    }

    /// Compute the fair asset swap spread (rate).
    ///
    /// - Par: (model_dirty - face_value) / (annuity * face_value)
    /// - MarketValue: (model_dirty - dirty_target) / (annuity * face_value)
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let annuity = self.compute_annuity(disc_curve);

        // Guard: if annuity is near zero, return 0
        let annuity_mag = match &annuity {
            Number::F64(v) => v.abs(),
            Number::Dual(d) => d.real.abs(),
            Number::Dual2(d) => d.real.abs(),
        };
        if annuity_mag < 1e-12 {
            return Number::F64(0.0);
        }

        let face_val = self.bond.face_value;
        let denom = annuity * face_val;

        match self.asw_type {
            AssetSwapType::Par => {
                let dirty = self.bond.dirty_price(disc_curve, None, None);
                (dirty - Number::F64(face_val)) / denom
            }
            AssetSwapType::MarketValue => {
                let dirty_target = Number::F64(self.dirty_price.unwrap());
                let model_dirty = self.bond.dirty_price(disc_curve, None, None);
                (model_dirty - dirty_target) / denom
            }
        }
    }

    /// Compute NPV given a fixed spread.
    ///
    /// If `fixed_spread` is set, NPV = (model_dirty - target) + spread * annuity * face.
    /// If `fixed_spread` is None, NPV = 0.0 (fair spread by definition).
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        if let Some(s) = self.fixed_spread {
            let annuity = self.compute_annuity(disc_curve);
            let face_val = self.bond.face_value;
            let spread_pv = annuity * face_val * s;

            match self.asw_type {
                AssetSwapType::Par => {
                    let dirty = self.bond.dirty_price(disc_curve, None, None);
                    // NPV = (dirty - face) - spread * annuity * face
                    // At fair spread s = (dirty - face) / (annuity * face), NPV = 0
                    dirty - Number::F64(face_val) - spread_pv
                }
                AssetSwapType::MarketValue => {
                    let dirty_target = Number::F64(self.dirty_price.unwrap());
                    let model_dirty = self.bond.dirty_price(disc_curve, None, None);
                    // NPV = (model_dirty - dirty_target) - spread * annuity * face
                    model_dirty - dirty_target - spread_pv
                }
            }
        } else {
            Number::F64(0.0)
        }
    }

    /// Return the bond leg cashflows.
    pub fn cashflows(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Vec<CashflowRow> {
        self.bond.cashflows(Some(disc_curve), Some(forecast_curve))
    }

    /// Spread IS the rate for an asset swap.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.rate(disc_curve, forecast_curve)
    }

    /// Pillar date: bond termination.
    pub fn pillar_date(&self) -> NaiveDate {
        self.bond.termination
    }

    /// Analytic delta: delegate to bond.
    pub fn analytic_delta(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.bond.analytic_delta(disc_curve, forecast_curve)
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use indexmap::IndexMap;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.9704),
            (ymd(2026, 1, 1), 0.9418),
            (ymd(2027, 1, 1), 0.9139),
            (ymd(2028, 1, 1), 0.8869),
            (ymd(2029, 1, 1), 0.8607),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_asset_swap() -> AssetSwapInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bond = BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.04,
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        );
        AssetSwapInstrument::new(bond, AssetSwapType::Par, None, None)
    }

    #[test]
    fn test_par_spread_finite() {
        let curve = test_curve();
        let asw = make_test_asset_swap();
        let spread = asw.rate(&curve, &curve);
        match spread {
            Number::F64(s) => {
                assert!(s.is_finite(), "Par spread should be finite, got {s}");
                // 4% coupon on ~3% curve => bond prices above par => positive spread
                assert!(s > 0.0, "Par spread should be positive for above-par bond, got {s}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_non_par_spread_finite() {
        let curve = test_curve();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bond = BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.04,
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        );
        // Use dirty_price = 102.0 as target
        let asw = AssetSwapInstrument::new(
            bond,
            AssetSwapType::MarketValue,
            Some(102.0),
            None,
        );
        let spread = asw.rate(&curve, &curve);
        match spread {
            Number::F64(s) => {
                assert!(s.is_finite(), "Non-par spread should be finite, got {s}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_npv_at_fair_spread_is_zero() {
        let curve = test_curve();
        let asw = make_test_asset_swap();
        // Get fair spread
        let fair_spread = match asw.rate(&curve, &curve) {
            Number::F64(s) => s,
            _ => panic!("Expected F64"),
        };
        // Create instrument with fair spread as fixed_spread
        let asw_with_spread = AssetSwapInstrument::new(
            asw.bond.clone(),
            AssetSwapType::Par,
            None,
            Some(fair_spread),
        );
        let npv = asw_with_spread.npv(&curve, &curve);
        match npv {
            Number::F64(v) => {
                assert!(
                    v.abs() < 1e-8,
                    "NPV at fair spread should be ~0, got {v}"
                );
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_npv_no_spread_is_zero() {
        let curve = test_curve();
        let asw = make_test_asset_swap();
        let npv = asw.npv(&curve, &curve);
        match npv {
            Number::F64(v) => {
                assert!(
                    v.abs() < 1e-12,
                    "NPV without fixed_spread should be exactly 0, got {v}"
                );
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    #[should_panic(expected = "dirty_price is required")]
    fn test_market_value_without_dirty_price_panics() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bond = BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.04,
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        );
        let _ = AssetSwapInstrument::new(bond, AssetSwapType::MarketValue, None, None);
    }

    #[test]
    fn test_pillar_date() {
        let asw = make_test_asset_swap();
        assert_eq!(asw.pillar_date(), ymd(2029, 1, 1));
    }

    #[test]
    fn test_cashflows_non_empty() {
        let curve = test_curve();
        let asw = make_test_asset_swap();
        let cfs = asw.cashflows(&curve, &curve);
        assert!(!cfs.is_empty(), "Asset swap should have cashflows from bond leg");
    }

    #[test]
    fn test_analytic_delta_finite() {
        let curve = test_curve();
        let asw = make_test_asset_swap();
        let ad = asw.analytic_delta(&curve, &curve);
        match ad {
            Number::F64(v) => assert!(v.is_finite(), "Analytic delta should be finite, got {v}"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_enum_dispatch() {
        use crate::instruments::Instrument;

        let curve = test_curve();
        let asw = make_test_asset_swap();
        let inst = Instrument::AssetSwap(asw);

        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "AssetSwap rate should be finite"),
            _ => panic!("Expected F64"),
        }

        let npv = inst.npv(&curve, &curve, None, None, None);
        match npv {
            Number::F64(v) => assert!(v.abs() < 1e-12, "AssetSwap NPV should be 0 (no fixed spread)"),
            _ => panic!("Expected F64"),
        }

        let cfs = inst.cashflows(Some(&curve), Some(&curve), None, None, None);
        assert!(!cfs.is_empty(), "AssetSwap should have cashflows");

        let spread = inst.spread(&curve, &curve, None, None, None);
        match spread {
            Number::F64(s) => assert!(s.is_finite(), "AssetSwap spread should be finite"),
            _ => panic!("Expected F64"),
        }

        let pillar = inst.pillar_date();
        assert_eq!(pillar, ymd(2029, 1, 1));
    }
}
