use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::autodiff::enums::Number;
use crate::calendar::adjuster::Adjuster;
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::DayCountConvention;
use crate::calendar::frequency::Frequency;
use crate::calendar::schedule::StubInference;
use crate::cashflows::amortization::Amortization;
use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::py::{PyDiscountCurve, PyLineCurve, PyCreditImpliedCurve, PyCompositeCurve, PyFXImpliedCurve, PyNelsonSiegel, PyNelsonSiegelSvensson, PySmithWilson, PyFittedBondCurve};
use crate::instruments::ir_future::QuoteConvention;

pub(crate) fn number_to_py(py: Python<'_>, n: Number) -> PyResult<Py<PyAny>> {
    match n {
        Number::F64(f) => Ok(f.into_pyobject(py).expect("f64 to py").into_any().unbind()),
        Number::Dual(d) => Ok(Py::new(py, d)?.into_any()),
        Number::Dual2(d) => Ok(Py::new(py, d)?.into_any()),
    }
}

pub(crate) fn parse_day_count(s: &str) -> PyResult<DayCountConvention> {
    match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
        "act360" | "actual360" => Ok(DayCountConvention::Act360),
        "act365f" | "act365fixed" | "actual365fixed" => Ok(DayCountConvention::Act365F),
        "act365.25" | "act36525" => Ok(DayCountConvention::Act365_25),
        "act364" | "actual364" => Ok(DayCountConvention::Act364),
        "actactisda" | "actualactual" | "actact" => Ok(DayCountConvention::ActActISDA),
        "30/360" | "30360" | "thirty360" => Ok(DayCountConvention::Thirty360),
        "30e/360" | "30e360" | "thirtye360" => Ok(DayCountConvention::ThirtyE360),
        "30e/360isda" | "30e360isda" => Ok(DayCountConvention::ThirtyE360ISDA),
        "bus252" | "bus/252" => Ok(DayCountConvention::Bus252),
        "one" | "1" | "1/1" => Ok(DayCountConvention::One),
        _ => Err(PyValueError::new_err(format!(
            "Unknown day count convention: '{}'.",
            s
        ))),
    }
}

pub(crate) fn parse_adjuster(s: &str) -> PyResult<Adjuster> {
    match s.to_lowercase().as_str() {
        "actual" | "none" => Ok(Adjuster::Actual),
        "following" | "fol" | "f" => Ok(Adjuster::Following),
        "modified_following" | "modfollowing" | "mod_following" | "mf" => {
            Ok(Adjuster::ModifiedFollowing)
        }
        "preceding" | "pre" | "p" => Ok(Adjuster::Preceding),
        "modified_preceding" | "modpreceding" | "mod_preceding" | "mp" => {
            Ok(Adjuster::ModifiedPreceding)
        }
        _ => Err(PyValueError::new_err(format!(
            "Unknown adjuster: '{}'.",
            s
        ))),
    }
}

pub(crate) fn parse_frequency(s: &str) -> PyResult<Frequency> {
    match s.to_lowercase().as_str() {
        "m" | "monthly" | "1m" => Ok(Frequency::Monthly),
        "q" | "quarterly" | "3m" => Ok(Frequency::Quarterly),
        "s" | "semiannual" | "semi_annual" | "6m" => Ok(Frequency::SemiAnnual),
        "a" | "annual" | "1y" | "12m" => Ok(Frequency::Annual),
        "z" | "zerocoupon" | "zero_coupon" | "zero" => Ok(Frequency::ZeroCoupon),
        _ => Err(PyValueError::new_err(format!(
            "Unknown frequency: '{}'. Use: 'm', 'q', 's', 'a', 'z'.",
            s
        ))),
    }
}

pub(crate) fn parse_fixing_method(s: &str) -> PyResult<FixingMethod> {
    let normalized = s.to_lowercase().replace([' ', '-'], "_");
    match normalized.as_str() {
        "rfr_payment_delay" => Ok(FixingMethod::RFRPaymentDelay),
        "rfr_payment_delay_average" => Ok(FixingMethod::RFRPaymentDelayAverage),
        "rfr_observation_shift" => Ok(FixingMethod::RFRObservationShift(2)),
        "rfr_lockout" => Ok(FixingMethod::RFRLockout(2)),
        "rfr_lookback" => Ok(FixingMethod::RFRLookback(2)),
        "rfr_observation_shift_average" => Ok(FixingMethod::RFRObservationShiftAverage(2)),
        "rfr_lockout_average" => Ok(FixingMethod::RFRLookoutAverage(2)),
        "rfr_lookback_average" => Ok(FixingMethod::RFRLookbackAverage(2)),
        _ => {
            if let Some(rest) = normalized.strip_prefix("rfr_observation_shift_") {
                if let Ok(n) = rest.parse::<i32>() {
                    return Ok(FixingMethod::RFRObservationShift(n));
                }
            }
            if let Some(rest) = normalized.strip_prefix("rfr_lockout_") {
                if rest != "average" {
                    if let Ok(n) = rest.parse::<i32>() {
                        return Ok(FixingMethod::RFRLockout(n));
                    }
                }
            }
            if let Some(rest) = normalized.strip_prefix("rfr_lookback_") {
                if rest != "average" {
                    if let Ok(n) = rest.parse::<i32>() {
                        return Ok(FixingMethod::RFRLookback(n));
                    }
                }
            }
            Err(PyValueError::new_err(format!(
                "Unknown fixing method: '{}'.",
                s
            )))
        }
    }
}

#[allow(dead_code)]
pub(crate) fn parse_spread_method(s: &str) -> PyResult<SpreadMethod> {
    match s.to_lowercase().replace([' ', '-'], "_").as_str() {
        "none_simple" | "nonesimple" | "simple" => Ok(SpreadMethod::NoneSimple),
        "isda_compounding" | "isdacompounding" | "isda" => Ok(SpreadMethod::ISDACompounding),
        _ => Err(PyValueError::new_err(format!(
            "Unknown spread method: '{}'.",
            s
        ))),
    }
}

pub(crate) fn parse_amortization(obj: &Bound<'_, PyAny>) -> PyResult<Amortization> {
    if obj.is_none() {
        return Ok(Amortization::None);
    }
    if let Ok(s) = obj.extract::<String>() {
        let lower = s.to_lowercase();
        if let Some(rest) = lower.strip_prefix("constant_") {
            let amt: f64 = rest
                .parse()
                .map_err(|_| PyValueError::new_err(format!("Invalid constant amortization: '{}'", rest)))?;
            return Ok(Amortization::Constant(amt));
        }
        if let Some(rest) = lower.strip_prefix("percentage_") {
            let pct: f64 = rest
                .parse()
                .map_err(|_| PyValueError::new_err(format!("Invalid percentage amortization: '{}'", rest)))?;
            return Ok(Amortization::Percentage(pct));
        }
        if lower == "none" {
            return Ok(Amortization::None);
        }
        return Err(PyValueError::new_err(format!(
            "Unknown amortization: '{}'. Use: None, 'constant_AMOUNT', 'percentage_PCT', or list.",
            s
        )));
    }
    if let Ok(notionals) = obj.extract::<Vec<f64>>() {
        return Ok(Amortization::Custom(notionals));
    }
    Err(PyValueError::new_err(
        "amortization must be None, a string, or a list of notionals",
    ))
}

/// Resolve compounding_method string to (FixingMethod, SpreadMethod).
///
/// Maps high-level compounding method names to the appropriate RFR fixing and
/// spread method combination, with optional lockout/lookback day overrides.
pub(crate) fn resolve_compounding(
    method: &str,
    lockout: Option<i32>,
    lookback: Option<i32>,
) -> PyResult<(FixingMethod, SpreadMethod)> {
    match method.to_lowercase().replace([' ', '-'], "_").as_str() {
        "standard" => {
            let fm = match (lockout, lookback) {
                (Some(n), _) => FixingMethod::RFRLockout(n),
                (_, Some(n)) => FixingMethod::RFRLookback(n),
                _ => FixingMethod::RFRPaymentDelay,
            };
            Ok((fm, SpreadMethod::ISDACompounding))
        }
        "spread_exclusive" => {
            let fm = match (lockout, lookback) {
                (Some(n), _) => FixingMethod::RFRLockout(n),
                (_, Some(n)) => FixingMethod::RFRLookback(n),
                _ => FixingMethod::RFRPaymentDelay,
            };
            Ok((fm, SpreadMethod::NoneSimple))
        }
        "simple_average" => {
            let fm = match (lockout, lookback) {
                (Some(n), _) => FixingMethod::RFRLookoutAverage(n),
                (_, Some(n)) => FixingMethod::RFRLookbackAverage(n),
                _ => FixingMethod::RFRPaymentDelayAverage,
            };
            Ok((fm, SpreadMethod::NoneSimple))
        }
        _ => Err(PyValueError::new_err(format!(
            "Unknown compounding_method: '{}'. Use: 'standard', 'spread_exclusive', 'simple_average'.",
            method
        ))),
    }
}

/// Resolve per-leg amortization from shared and/or per-leg parameters.
///
/// Returns (fixed_amort, float_amort). Raises error if both shared and per-leg
/// amortization are specified (mutual exclusion).
pub(crate) fn resolve_per_leg_amortization(
    amortization: Option<&Bound<'_, PyAny>>,
    fixed_amortization: Option<&Bound<'_, PyAny>>,
    float_amortization: Option<&Bound<'_, PyAny>>,
) -> PyResult<(Amortization, Amortization)> {
    let has_shared = amortization.map_or(false, |a| !a.is_none());
    let has_per_leg = fixed_amortization.map_or(false, |a| !a.is_none())
        || float_amortization.map_or(false, |a| !a.is_none());

    if has_shared && has_per_leg {
        return Err(PyValueError::new_err(
            "Cannot specify both 'amortization' and 'fixed_amortization'/'float_amortization'. Use one style."
        ));
    }

    if has_per_leg {
        let fa = match fixed_amortization {
            Some(obj) if !obj.is_none() => parse_amortization(obj)?,
            _ => Amortization::None,
        };
        let fla = match float_amortization {
            Some(obj) if !obj.is_none() => parse_amortization(obj)?,
            _ => Amortization::None,
        };
        Ok((fa, fla))
    } else if has_shared {
        let a = parse_amortization(amortization.unwrap())?;
        Ok((a.clone(), a))
    } else {
        Ok((Amortization::None, Amortization::None))
    }
}

pub(crate) fn parse_quote_convention(s: &str) -> PyResult<QuoteConvention> {
    match s.to_lowercase().as_str() {
        "price" => Ok(QuoteConvention::Price),
        "rate" => Ok(QuoteConvention::Rate),
        _ => Err(PyValueError::new_err(format!(
            "Unknown quote_convention: '{}'. Use: 'price', 'rate'.",
            s
        ))),
    }
}

/// Extract a curve reference from a PyAny (DiscountCurve, LineCurve, CreditImpliedCurve,
/// CompositeCurve, or FXImpliedCurve).
pub(crate) fn extract_curve_ref<'py>(obj: &Bound<'py, PyAny>) -> PyResult<Box<dyn CurveQuery + 'py>> {
    if let Ok(dc) = obj.extract::<PyRef<'py, PyDiscountCurve>>() {
        Ok(Box::new(dc.inner.clone()))
    } else if let Ok(lc) = obj.extract::<PyRef<'py, PyLineCurve>>() {
        Ok(Box::new(lc.inner.clone()))
    } else if let Ok(cc) = obj.extract::<PyRef<'py, PyCreditImpliedCurve>>() {
        Ok(Box::new(cc.inner.clone()))
    } else if let Ok(comp) = obj.extract::<PyRef<'py, PyCompositeCurve>>() {
        Ok(Box::new(comp.inner.clone()))
    } else if let Ok(proxy) = obj.extract::<PyRef<'py, PyFXImpliedCurve>>() {
        Ok(Box::new(proxy.inner.clone()))
    } else if let Ok(ns) = obj.extract::<PyRef<'py, PyNelsonSiegel>>() {
        Ok(Box::new(ns.inner.clone()))
    } else if let Ok(nss) = obj.extract::<PyRef<'py, PyNelsonSiegelSvensson>>() {
        Ok(Box::new(nss.inner.clone()))
    } else if let Ok(sw) = obj.extract::<PyRef<'py, PySmithWilson>>() {
        Ok(Box::new(sw.inner.clone()))
    } else if let Ok(fbc) = obj.extract::<PyRef<'py, PyFittedBondCurve>>() {
        Ok(Box::new(fbc.inner.clone()))
    } else {
        Err(PyValueError::new_err(
            "curve must be a DiscountCurve, LineCurve, CreditImpliedCurve, CompositeCurve, FXImpliedCurve, NelsonSiegel, NelsonSiegelSvensson, SmithWilson, or FittedBondCurve",
        ))
    }
}

/// Parse curve input from Python: single curve, 2-element list, or dict.
/// Returns (disc_curve, forecast_curve). If single curve provided, both are the same.
pub(crate) fn parse_curves<'py>(obj: &Bound<'py, PyAny>) -> PyResult<(Box<dyn CurveQuery + 'py>, Box<dyn CurveQuery + 'py>)> {
    // Try dict: {"disc": curve, "forecast": curve}
    if let Ok(dict) = obj.cast::<pyo3::types::PyDict>() {
        let disc_obj = dict
            .get_item("disc")?
            .ok_or_else(|| PyValueError::new_err("curve dict must have 'disc' key"))?;
        let forecast_obj = dict
            .get_item("forecast")?
            .ok_or_else(|| PyValueError::new_err("curve dict must have 'forecast' key"))?;
        let disc = extract_curve_ref(&disc_obj)?;
        let forecast = extract_curve_ref(&forecast_obj)?;
        return Ok((disc, forecast));
    }
    // Try list/tuple: [forecast, disc]
    if let Ok(list) = obj.cast::<pyo3::types::PyList>() {
        if list.len() == 2 {
            let forecast = extract_curve_ref(&list.get_item(0)?)?;
            let disc = extract_curve_ref(&list.get_item(1)?)?;
            return Ok((disc, forecast));
        }
    }
    if let Ok(tuple) = obj.cast::<pyo3::types::PyTuple>() {
        if tuple.len() == 2 {
            let forecast = extract_curve_ref(&tuple.get_item(0)?)?;
            let disc = extract_curve_ref(&tuple.get_item(1)?)?;
            return Ok((disc, forecast));
        }
    }
    // Single curve: used for both disc and forecast
    let c = extract_curve_ref(obj)?;
    let c2 = extract_curve_ref(obj)?;
    Ok((c, c2))
}

/// Parse optional curves: returns (Option<disc>, Option<forecast>)
#[allow(dead_code)]
pub(crate) fn parse_curves_optional<'py>(
    obj: Option<&Bound<'py, PyAny>>,
) -> PyResult<(Option<Box<dyn CurveQuery + 'py>>, Option<Box<dyn CurveQuery + 'py>>)> {
    match obj {
        Some(o) => {
            let (d, f) = parse_curves(o)?;
            Ok((Some(d), Some(f)))
        }
        None => Ok((None, None)),
    }
}

pub(crate) fn build_calendar(calendar_str: Option<&str>) -> BusinessCalendar {
    // For now, use a default calendar. Calendar resolution by string will be expanded.
    match calendar_str {
        Some(_) => BusinessCalendar::new_custom(vec![], vec![5, 6]),
        None => BusinessCalendar::new_custom(vec![], vec![5, 6]),
    }
}

pub(crate) fn parse_stub(s: &str) -> StubInference {
    match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
        "shortfront" => StubInference::ShortFront,
        "longfront" => StubInference::LongFront,
        "shortback" => StubInference::ShortBack,
        "longback" => StubInference::LongBack,
        _ => StubInference::ShortFront,
    }
}
