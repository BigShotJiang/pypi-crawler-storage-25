use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::instruments;

// Re-export for external consumers (curves/py.rs uses crate::instruments::py::PyBondInstrument)
pub use super::credit::py::PyBondInstrument;

// Import all 17 PyClass types for extract_instrument
use super::rates::py::{
    PyInterestRateSwap, PyForwardRateAgreement, PyZeroCouponSwap,
    PySingleBasisSwap, PyOvernightIndexedSwap, PyDeposit, PyIRFuture,
};
use super::fx::py::{
    PyXCS, PyFXForwardInst, PyNDFInstrument, PyNDIRSInstrument, PyNDXCSInstrument,
};
use super::credit::py::{PyCDS, PyAssetSwap, PyCallableBond};

/// Extract an Instrument enum from a PyAny object by trying each known instrument type.
/// Used by solver/py.rs and curves/py.rs (bucket_delta).
pub fn extract_instrument(obj: &Bound<'_, PyAny>) -> PyResult<instruments::Instrument> {
    // NDIRS must be checked before IRS since both wrap InterestRateSwap
    if let Ok(inst) = obj.extract::<PyRef<'_, PyNDIRSInstrument>>() {
        return Ok(instruments::Instrument::NDIRS(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyInterestRateSwap>>() {
        return Ok(instruments::Instrument::IRS(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyForwardRateAgreement>>() {
        return Ok(instruments::Instrument::FRA(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyZeroCouponSwap>>() {
        return Ok(instruments::Instrument::ZCS(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PySingleBasisSwap>>() {
        return Ok(instruments::Instrument::SBS(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyOvernightIndexedSwap>>() {
        return Ok(instruments::Instrument::OIS(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyDeposit>>() {
        return Ok(instruments::Instrument::Deposit(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyIRFuture>>() {
        return Ok(instruments::Instrument::IRFuture(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyBondInstrument>>() {
        return Ok(instruments::Instrument::Bond(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyCDS>>() {
        return Ok(instruments::Instrument::CDS(inst.inner.clone()));
    }
    // NDXCS must be checked before XCS since both wrap CrossCurrencySwap
    if let Ok(inst) = obj.extract::<PyRef<'_, PyNDXCSInstrument>>() {
        return Ok(instruments::Instrument::NDXCS(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyXCS>>() {
        return Ok(instruments::Instrument::XCS(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyFXForwardInst>>() {
        return Ok(instruments::Instrument::FXForward(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyAssetSwap>>() {
        return Ok(instruments::Instrument::AssetSwap(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyCallableBond>>() {
        return Ok(instruments::Instrument::CallableBond(inst.inner.clone()));
    }
    if let Ok(inst) = obj.extract::<PyRef<'_, PyNDFInstrument>>() {
        return Ok(instruments::Instrument::NDF(inst.inner.clone()));
    }
    Err(PyValueError::new_err(
        "instrument must be a supported instrument type (NDXCS, NDIRS, IRS, FRA, ZCS, SBS, OIS, Deposit, \
         IRFuture, BondInstrument, CreditDefaultSwap, CrossCurrencySwap, FXForward, AssetSwap, CallableBond, or NDF)",
    ))
}

/// Register all instrument PyClass types with the Python module.
/// Delegates to per-product register() functions.
pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    super::rates::py::register(m)?;
    super::fx::py::register(m)?;
    super::credit::py::register(m)?;
    Ok(())
}
