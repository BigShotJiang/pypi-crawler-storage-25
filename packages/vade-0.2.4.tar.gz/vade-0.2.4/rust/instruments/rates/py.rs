use chrono::NaiveDate;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::calendar::schedule::Schedule;
use crate::cashflows::amortization::Amortization;
use crate::cashflows::fixing::SpreadMethod;
use crate::cashflows::leg;
use crate::cashflows::py::PyCashflowRow;
use crate::instruments;
use crate::instruments::py_utils::{
    number_to_py, parse_day_count, parse_adjuster, parse_frequency,
    parse_fixing_method, resolve_compounding, resolve_per_leg_amortization,
    parse_quote_convention, extract_curve_ref, parse_curves, build_calendar, parse_stub,
};

// ---- PyInterestRateSwap ----

#[pyclass(name = "PyInterestRateSwap", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyInterestRateSwap {
    pub inner: instruments::InterestRateSwap,
}

#[pymethods]
impl PyInterestRateSwap {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        frequency = "a",
        fixed_rate = 0.0,
        notional = 1000000.0,
        convention = "act360",
        float_convention = "act360",
        fixing_method = "rfr_payment_delay",
        spread = 0.0,
        calendar = None,
        payment_lag = None,
        currency = "USD",
        amortization = None,
        modifier = "mf",
        stub = "shortfront",
        fixed_amortization = None,
        float_amortization = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        fixed_rate: f64,
        notional: f64,
        convention: &str,
        float_convention: &str,
        fixing_method: &str,
        spread: f64,
        calendar: Option<&str>,
        payment_lag: Option<i32>,
        currency: &str,
        amortization: Option<&Bound<'_, PyAny>>,
        modifier: &str,
        stub: &str,
        fixed_amortization: Option<&Bound<'_, PyAny>>,
        float_amortization: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let conv = parse_day_count(convention)?;
        let fconv = parse_day_count(float_convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let adj = parse_adjuster(modifier)?;
        let stub_inf = parse_stub(stub);
        let (fixed_amort, float_amort) = resolve_per_leg_amortization(
            amortization, fixed_amortization, float_amortization,
        )?;
        let cal = build_calendar(calendar);

        let schedule = Schedule::try_new(
            effective,
            termination,
            freq,
            cal.clone(),
            adj,
            None,
            None,
            None,
            stub_inf,
        )
        .map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        let fixed_leg = leg::FixedLeg::new(
            &schedule,
            fixed_rate,
            notional,
            conv,
            currency.to_string(),
            payment_lag,
            fixed_amort,
        );
        let float_leg = leg::FloatLeg::new(
            &schedule,
            spread,
            -notional,
            fconv,
            fm,
            SpreadMethod::NoneSimple,
            currency.to_string(),
            payment_lag,
            float_amort,
        );

        Ok(PyInterestRateSwap {
            inner: instruments::InterestRateSwap::new(fixed_leg, float_leg),
        })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "InterestRateSwap(...)".to_string()
    }
}

// ---- PyForwardRateAgreement ----

#[pyclass(name = "PyForwardRateAgreement", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyForwardRateAgreement {
    pub inner: instruments::ForwardRateAgreement,
}

#[pymethods]
impl PyForwardRateAgreement {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        notional = 1000000.0,
        fixed_rate = 0.0,
        convention = "act360",
        fixing_method = "rfr_payment_delay",
        calendar = None,
    ))]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        notional: f64,
        fixed_rate: f64,
        convention: &str,
        fixing_method: &str,
        calendar: Option<&str>,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let cal = build_calendar(calendar);

        Ok(PyForwardRateAgreement {
            inner: instruments::ForwardRateAgreement::new(
                effective,
                termination,
                notional,
                fixed_rate,
                conv,
                fm,
                cal,
            ),
        })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "ForwardRateAgreement(...)".to_string()
    }
}

// ---- PyZeroCouponSwap ----

#[pyclass(name = "PyZeroCouponSwap", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyZeroCouponSwap {
    pub inner: instruments::ZeroCouponSwap,
}

#[pymethods]
impl PyZeroCouponSwap {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        fixed_rate = 0.0,
        notional = 1000000.0,
        convention = "act360",
        float_convention = "act360",
        fixing_method = "rfr_payment_delay",
        spread = 0.0,
        calendar = None,
        currency = "USD",
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        fixed_rate: f64,
        notional: f64,
        convention: &str,
        float_convention: &str,
        fixing_method: &str,
        spread: f64,
        calendar: Option<&str>,
        currency: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let fconv = parse_day_count(float_convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let cal = build_calendar(calendar);

        let fixed_leg = leg::ZeroFixedLeg::new(
            effective,
            termination,
            termination,
            fixed_rate,
            notional,
            conv,
            currency.to_string(),
        );
        let float_leg = leg::ZeroFloatLeg::new(
            effective,
            termination,
            termination,
            -notional,
            spread,
            fconv,
            fm,
            SpreadMethod::NoneSimple,
            cal,
            currency.to_string(),
        );

        Ok(PyZeroCouponSwap {
            inner: instruments::ZeroCouponSwap::new(fixed_leg, float_leg),
        })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "ZeroCouponSwap(...)".to_string()
    }
}

// ---- PySingleBasisSwap ----

#[pyclass(name = "PySingleBasisSwap", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PySingleBasisSwap {
    pub inner: instruments::SingleBasisSwap,
}

#[pymethods]
impl PySingleBasisSwap {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        frequency = "q",
        leg2_frequency = "s",
        notional = 1000000.0,
        spread = 0.0,
        convention = "act360",
        leg2_convention = "act360",
        fixing_method = "rfr_payment_delay",
        leg2_fixing_method = "rfr_payment_delay",
        calendar = None,
        payment_lag = None,
        currency = "USD",
        modifier = "mf",
        stub = "shortfront",
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        leg2_frequency: &str,
        notional: f64,
        spread: f64,
        convention: &str,
        leg2_convention: &str,
        fixing_method: &str,
        leg2_fixing_method: &str,
        calendar: Option<&str>,
        payment_lag: Option<i32>,
        currency: &str,
        modifier: &str,
        stub: &str,
    ) -> PyResult<Self> {
        let freq1 = parse_frequency(frequency)?;
        let freq2 = parse_frequency(leg2_frequency)?;
        let conv1 = parse_day_count(convention)?;
        let conv2 = parse_day_count(leg2_convention)?;
        let fm1 = parse_fixing_method(fixing_method)?;
        let fm2 = parse_fixing_method(leg2_fixing_method)?;
        let adj = parse_adjuster(modifier)?;
        let stub_inf = parse_stub(stub);
        let cal = build_calendar(calendar);

        let schedule1 = Schedule::try_new(
            effective, termination, freq1, cal.clone(), adj, None, None, None, stub_inf,
        )
        .map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        let schedule2 = Schedule::try_new(
            effective, termination, freq2, cal.clone(), adj, None, None, None, stub_inf,
        )
        .map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        let leg1 = leg::FloatLeg::new(
            &schedule1,
            0.0,
            notional,
            conv1,
            fm1,
            SpreadMethod::NoneSimple,
            currency.to_string(),
            payment_lag,
            Amortization::None,
        );
        let leg2 = leg::FloatLeg::new(
            &schedule2,
            spread,
            -notional,
            conv2,
            fm2,
            SpreadMethod::NoneSimple,
            currency.to_string(),
            payment_lag,
            Amortization::None,
        );

        Ok(PySingleBasisSwap {
            inner: instruments::SingleBasisSwap::new(leg1, leg2),
        })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "SingleBasisSwap(...)".to_string()
    }
}

// ---- PyOvernightIndexedSwap ----

#[pyclass(name = "PyOvernightIndexedSwap", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyOvernightIndexedSwap {
    pub inner: instruments::OvernightIndexedSwap,
}

#[pymethods]
impl PyOvernightIndexedSwap {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        frequency = "a",
        fixed_rate = 0.0,
        notional = 1000000.0,
        convention = "act360",
        float_convention = "act360",
        fixing_method = "rfr_payment_delay",
        spread = 0.0,
        calendar = None,
        payment_lag = None,
        currency = "USD",
        amortization = None,
        modifier = "mf",
        stub = "shortfront",
        compounding_method = None,
        lockout = None,
        lookback = None,
        fixed_amortization = None,
        float_amortization = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        fixed_rate: f64,
        notional: f64,
        convention: &str,
        float_convention: &str,
        fixing_method: &str,
        spread: f64,
        calendar: Option<&str>,
        payment_lag: Option<i32>,
        currency: &str,
        amortization: Option<&Bound<'_, PyAny>>,
        modifier: &str,
        stub: &str,
        compounding_method: Option<&str>,
        lockout: Option<i32>,
        lookback: Option<i32>,
        fixed_amortization: Option<&Bound<'_, PyAny>>,
        float_amortization: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let conv = parse_day_count(convention)?;
        let fconv = parse_day_count(float_convention)?;
        let adj = parse_adjuster(modifier)?;
        let stub_inf = parse_stub(stub);
        let (fixed_amort, float_amort) = resolve_per_leg_amortization(
            amortization, fixed_amortization, float_amortization,
        )?;
        let cal = build_calendar(calendar);

        // Determine fixing method and spread method
        let (fm, sm) = if let Some(cm) = compounding_method {
            resolve_compounding(cm, lockout, lookback)?
        } else {
            let fm = parse_fixing_method(fixing_method)?;
            (fm, SpreadMethod::NoneSimple)
        };

        let schedule = Schedule::try_new(
            effective, termination, freq, cal.clone(), adj, None, None, None, stub_inf,
        )
        .map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        let fixed_leg = leg::FixedLeg::new(
            &schedule,
            fixed_rate,
            notional,
            conv,
            currency.to_string(),
            payment_lag,
            fixed_amort,
        );
        let float_leg = leg::FloatLeg::new(
            &schedule,
            spread,
            -notional,
            fconv,
            fm,
            sm,
            currency.to_string(),
            payment_lag,
            float_amort,
        );

        Ok(PyOvernightIndexedSwap {
            inner: instruments::OvernightIndexedSwap::new(fixed_leg, float_leg),
        })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "OvernightIndexedSwap(...)".to_string()
    }
}

// ---- PyDeposit ----

#[pyclass(name = "PyDeposit", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyDeposit {
    pub inner: instruments::DepositInstrument,
}

#[pymethods]
impl PyDeposit {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        rate = 0.0,
        notional = 1000000.0,
        convention = "act360",
    ))]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        rate: f64,
        notional: f64,
        convention: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        Ok(PyDeposit {
            inner: instruments::DepositInstrument::new(effective, termination, notional, rate, conv),
        })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate_from_curve(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "Deposit(...)".to_string()
    }
}

// ---- PyIRFuture ----

#[pyclass(name = "PyIRFuture", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyIRFuture {
    pub inner: instruments::IRFutureInstrument,
}

#[pymethods]
impl PyIRFuture {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        price = 100.0,
        notional = 1000000.0,
        convexity_adjustment = 0.0,
        convention = "act360",
        quote_convention = "price",
        sigma = None,
        tick_size = None,
        notional_multiplier = None,
        contract_size = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        price: f64,
        notional: f64,
        convexity_adjustment: f64,
        convention: &str,
        quote_convention: &str,
        sigma: Option<f64>,
        tick_size: Option<f64>,
        notional_multiplier: Option<f64>,
        contract_size: Option<f64>,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let qc = parse_quote_convention(quote_convention)?;
        Ok(PyIRFuture {
            inner: instruments::IRFutureInstrument::new_extended(
                effective,
                termination,
                notional,
                price,
                convexity_adjustment,
                conv,
                qc,
                sigma,
                tick_size,
                notional_multiplier,
                contract_size,
            ),
        })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "IRFuture(...)".to_string()
    }
}

// ---- PyCapFloor ----

#[pyclass(name = "PyCapFloor", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyCapFloor {
    pub inner: instruments::cap_floor::CapFloor,
}

#[pymethods]
impl PyCapFloor {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        strike = 0.0,
        vol = 0.0,
        notional = 1000000.0,
        frequency = "q",
        cap_floor_type = "cap",
        model = "black76",
        convention = "act360",
        currency = "USD",
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        strike: f64,
        vol: f64,
        notional: f64,
        frequency: &str,
        cap_floor_type: &str,
        model: &str,
        convention: &str,
        currency: &str,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let conv = parse_day_count(convention)?;
        let cf_type = match cap_floor_type.to_lowercase().as_str() {
            "cap" => instruments::cap_floor::CapFloorType::Cap,
            "floor" => instruments::cap_floor::CapFloorType::Floor,
            _ => return Err(PyValueError::new_err(
                format!("Unknown cap_floor_type: '{}'. Use 'cap' or 'floor'.", cap_floor_type)
            )),
        };
        let vol_model = match model.to_lowercase().as_str() {
            "black76" | "black" | "lognormal" => crate::models::black::VolModel::Black76,
            "bachelier" | "normal" => crate::models::black::VolModel::Bachelier,
            _ => return Err(PyValueError::new_err(
                format!("Unknown model: '{}'. Use 'black76' or 'bachelier'.", model)
            )),
        };

        Ok(PyCapFloor {
            inner: instruments::cap_floor::CapFloor {
                cap_floor_type: cf_type,
                model: vol_model,
                vol,
                strike,
                effective,
                termination,
                frequency: freq,
                notional,
                convention: conv,
                currency: currency.to_string(),
            },
        })
    }

    fn npv(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        number_to_py(py, self.inner.npv(&*dc, &*fc))
    }

    fn cashflows(&self, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        let rows = self.inner.cashflows(&*dc, &*fc);
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn __repr__(&self) -> String {
        "CapFloor(...)".to_string()
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyInterestRateSwap>()?;
    m.add_class::<PyForwardRateAgreement>()?;
    m.add_class::<PyZeroCouponSwap>()?;
    m.add_class::<PySingleBasisSwap>()?;
    m.add_class::<PyOvernightIndexedSwap>()?;
    m.add_class::<PyDeposit>()?;
    m.add_class::<PyIRFuture>()?;
    m.add_class::<PyCapFloor>()?;
    Ok(())
}
