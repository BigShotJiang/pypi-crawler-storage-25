use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::cashflows::leg::FloatLeg;
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;

/// Single Basis Swap: two FloatLegs with different indices/conventions.
///
/// leg1 typically pays one floating index, leg2 receives another.
/// The spread that makes NPV = 0 is the basis spread.
#[derive(Clone, Serialize, Deserialize)]
pub struct SingleBasisSwap {
    pub leg1: FloatLeg,
    pub leg2: FloatLeg,
}

impl SingleBasisSwap {
    /// Construct from pre-built float legs.
    pub fn new(leg1: FloatLeg, leg2: FloatLeg) -> Self {
        Self { leg1, leg2 }
    }

    /// Par spread: the spread on leg2 that makes NPV = 0.
    ///
    /// spread = -(leg1_npv + leg2_npv) / (leg2_analytic_delta * 100)
    /// This returns the spread in percentage.
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let leg1_npv = self.leg1.npv_dual_curve(forecast_curve, disc_curve, None);
        let leg2_npv = self.leg2.npv_dual_curve(forecast_curve, disc_curve, None);
        let total_npv = &leg1_npv + &leg2_npv;
        let leg2_ad = self.leg2.analytic_delta_disc(disc_curve);
        // spread that zeroes NPV: total_npv / (leg2_ad * (-100))
        &total_npv / &(&leg2_ad * (-100.0))
    }

    /// NPV = leg1_npv + leg2_npv.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let leg1_npv = self.leg1.npv_dual_curve(forecast_curve, disc_curve, None);
        let leg2_npv = self.leg2.npv_dual_curve(forecast_curve, disc_curve, None);
        leg1_npv + leg2_npv
    }

    /// Cashflow rows from both legs.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let fc = forecast_curve.or(disc_curve);
        let mut rows = self.leg1.cashflows(fc, None);
        rows.extend(self.leg2.cashflows(fc, None));
        rows.sort_by_key(|r| r.payment);
        rows
    }

    /// Spread: same as rate for SBS.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.rate(disc_curve, forecast_curve)
    }

    /// Pillar date: last period end date.
    pub fn pillar_date(&self) -> NaiveDate {
        let d1 = self.leg1.periods.last().map(|p| p.end);
        let d2 = self.leg2.periods.last().map(|p| p.end);
        match (d1, d2) {
            (Some(a), Some(b)) => a.max(b),
            (Some(a), None) => a,
            (None, Some(b)) => b,
            (None, None) => panic!("SBS has no periods"),
        }
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::cashflows::amortization::Amortization;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_sbs() -> SingleBasisSwap {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap();

        let leg1 = FloatLeg::new(
            &schedule,
            0.0,
            1_000_000.0, // pay
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        );

        let leg2 = FloatLeg::new(
            &schedule,
            0.0,
            -1_000_000.0, // receive
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        );

        SingleBasisSwap::new(leg1, leg2)
    }

    #[test]
    fn test_sbs_rate() {
        let curve = test_curve();
        let sbs = make_test_sbs();
        let rate = sbs.rate(&curve, &curve);
        if let Number::F64(r) = rate {
            assert!(r.is_finite(), "SBS rate should be finite, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_sbs_npv() {
        let curve = test_curve();
        let sbs = make_test_sbs();
        let npv = sbs.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            // With same curve and opposite notionals, NPV should be ~0
            assert!(
                v.abs() < 1e-6,
                "SBS NPV with same curve should be ~0, got {v}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_sbs_pillar_date() {
        let sbs = make_test_sbs();
        assert_eq!(sbs.pillar_date(), ymd(2026, 1, 1));
    }

    #[test]
    fn test_sbs_cashflows() {
        let curve = test_curve();
        let sbs = make_test_sbs();
        let rows = sbs.cashflows(Some(&curve), Some(&curve));
        assert!(!rows.is_empty(), "SBS should have cashflow rows");
    }
}
