use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;

/// Deposit instrument: single-period discount instrument for short-end calibration.
///
/// rate = (1/DF - 1) / dcf
/// npv = notional * (1 - (1 + rate * dcf) * DF)
#[derive(Clone, Serialize, Deserialize)]
pub struct DepositInstrument {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub notional: f64,
    pub rate: f64,
    pub convention: DayCountConvention,
}

impl DepositInstrument {
    pub fn new(
        start: NaiveDate,
        end: NaiveDate,
        notional: f64,
        rate: f64,
        convention: DayCountConvention,
    ) -> Self {
        Self { start, end, notional, rate, convention }
    }

    fn dcf(&self) -> f64 {
        self.convention.dcf(self.start, self.end, &DcfOptions::default()).unwrap()
    }

    /// Implied deposit rate from the discount curve.
    /// rate = (1/DF - 1) / dcf
    pub fn rate_from_curve(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let dcf = self.dcf();
        let df = disc_curve.discount_factor(self.end);
        // rate = (1/DF - 1) / dcf
        let one = Number::F64(1.0);
        let inv_df = &one / &df;
        let numerator = &inv_df - &one;
        &numerator / &Number::F64(dcf)
    }

    /// NPV = notional * (1 - (1 + rate * dcf) * DF)
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let dcf = self.dcf();
        let df = disc_curve.discount_factor(self.end);
        let accrual = 1.0 + self.rate * dcf;
        let pv_factor = &df * accrual;
        let one = Number::F64(1.0);
        let diff = &one - &pv_factor;
        &diff * &Number::F64(self.notional)
    }

    /// Cashflow rows.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        _forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let dcf = self.dcf();
        let cashflow_amount = self.notional * self.rate * dcf;
        let (df_val, npv_val) = if let Some(dc) = disc_curve {
            let df = dc.discount_factor(self.end);
            let npv = &df * cashflow_amount;
            (Some(df), Some(npv))
        } else {
            (None, None)
        };

        vec![CashflowRow {
            period_type: "Deposit".to_string(),
            start: self.start,
            end: self.end,
            payment: self.end,
            notional: self.notional,
            currency: String::new(),
            fixing_rate: None,
            rate: self.rate,
            spread: 0.0,
            dcf,
            cashflow: Number::F64(cashflow_amount),
            df: df_val,
            npv: npv_val,
            settlement_amount: None,
            fx_rate: None,
            settlement_currency_label: None,
        }]
    }

    /// Spread: not applicable for deposits, returns 0.
    pub fn spread(
        &self,
        _disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        Number::F64(0.0)
    }

    /// Pillar date: end date.
    pub fn pillar_date(&self) -> NaiveDate {
        self.end
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2024, 4, 1), 0.9925),
            (ymd(2024, 7, 1), 0.985),
            (ymd(2025, 1, 1), 0.97),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_deposit() -> DepositInstrument {
        DepositInstrument::new(
            ymd(2024, 1, 1),
            ymd(2024, 4, 1),
            1_000_000.0,
            3.0, // 3% rate (decimal, as stored)
            DayCountConvention::Act365F,
        )
    }

    #[test]
    fn test_deposit_rate_from_curve() {
        let curve = test_curve();
        let dep = make_test_deposit();
        let rate = dep.rate_from_curve(&curve, &curve);
        if let Number::F64(r) = rate {
            // DF at 2024-04-01 = 0.9925
            // rate = (1/0.9925 - 1) / dcf
            let dcf = DayCountConvention::Act365F
                .dcf(ymd(2024, 1, 1), ymd(2024, 4, 1), &DcfOptions::default())
                .unwrap();
            let expected = (1.0 / 0.9925 - 1.0) / dcf;
            assert!(
                (r - expected).abs() < 1e-10,
                "Deposit rate={r}, expected={expected}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_deposit_npv() {
        let curve = test_curve();
        let dep = make_test_deposit();
        let npv = dep.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "Deposit NPV should be finite, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_deposit_pillar_date() {
        let dep = make_test_deposit();
        assert_eq!(dep.pillar_date(), ymd(2024, 4, 1));
    }

    #[test]
    fn test_deposit_cashflows() {
        let curve = test_curve();
        let dep = make_test_deposit();
        let rows = dep.cashflows(Some(&curve), None);
        assert_eq!(rows.len(), 1, "Deposit should have 1 cashflow row");
        assert_eq!(rows[0].period_type, "Deposit");
    }

    #[test]
    fn test_deposit_rate_at_par_gives_zero_npv() {
        // If deposit rate matches the curve-implied rate, NPV ~ 0
        let curve = test_curve();
        let implied_rate = match DepositInstrument::new(
            ymd(2024, 1, 1),
            ymd(2024, 4, 1),
            1_000_000.0,
            0.0, // placeholder
            DayCountConvention::Act365F,
        ).rate_from_curve(&curve, &curve) {
            Number::F64(r) => r,
            _ => panic!("Expected F64"),
        };

        let dep = DepositInstrument::new(
            ymd(2024, 1, 1),
            ymd(2024, 4, 1),
            1_000_000.0,
            implied_rate,
            DayCountConvention::Act365F,
        );
        let npv = dep.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            assert!(v.abs() < 1e-4, "NPV at par rate should be ~0, got {v}");
        } else {
            panic!("Expected F64");
        }
    }
}
