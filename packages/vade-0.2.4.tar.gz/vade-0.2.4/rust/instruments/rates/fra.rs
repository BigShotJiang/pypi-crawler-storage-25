use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::cashflows::period::{CashflowRow, FixedPeriod, FloatPeriod};
use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::DayCountConvention;
use crate::marketcurves::curve::CurveQuery;

/// Forward Rate Agreement: single-period forward rate instrument.
///
/// Composed of a single FixedPeriod + single FloatPeriod.
/// rate() returns the forward rate for the FRA accrual period.
#[derive(Clone, Serialize, Deserialize)]
pub struct ForwardRateAgreement {
    pub fixed_period: FixedPeriod,
    pub float_period: FloatPeriod,
}

impl ForwardRateAgreement {
    /// Construct a FRA from dates and parameters.
    pub fn new(
        start: NaiveDate,
        end: NaiveDate,
        notional: f64,
        fixed_rate: f64,
        convention: DayCountConvention,
        fixing_method: FixingMethod,
        calendar: BusinessCalendar,
    ) -> Self {
        let fixed_period = FixedPeriod {
            start,
            end,
            payment: end,
            notional,
            fixed_rate,
            convention,
        };

        let float_period = FloatPeriod {
            start,
            end,
            payment: end,
            notional: -notional, // opposite sign
            spread: 0.0,
            convention,
            fixing_method,
            spread_method: SpreadMethod::NoneSimple,
            calendar,
        };

        Self { fixed_period, float_period }
    }

    /// FRA rate: the forward rate for the accrual period.
    pub fn rate(
        &self,
        _disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        // Forward rate from the forecast curve for the FRA period
        forecast_curve.forward_rate(self.float_period.start, self.float_period.end)
    }

    /// NPV: fixed + float period NPVs.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let fixed_npv = self.fixed_period.npv(disc_curve);
        let float_npv = self.float_period.npv_dual_curve(forecast_curve, disc_curve, None);
        fixed_npv + float_npv
    }

    /// Cashflow rows.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let mut rows = vec![
            self.fixed_period.to_cashflow_row(disc_curve, None, ""),
        ];
        if let Some(fc) = forecast_curve {
            rows.push(self.float_period.to_cashflow_row(Some(fc), None, ""));
        } else {
            rows.push(self.float_period.to_cashflow_row(None, None, ""));
        }
        rows
    }

    /// Spread: not applicable for FRA, returns 0.
    pub fn spread(
        &self,
        _disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        Number::F64(0.0)
    }

    /// Pillar date: end date of the FRA period.
    pub fn pillar_date(&self) -> NaiveDate {
        self.float_period.end
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_fra() -> ForwardRateAgreement {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        ForwardRateAgreement::new(
            ymd(2025, 1, 1),
            ymd(2025, 7, 1),
            1_000_000.0,
            3.0, // 3% fixed rate
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            cal,
        )
    }

    #[test]
    fn test_fra_rate_returns_forward_rate() {
        let curve = test_curve();
        let fra = make_test_fra();
        let rate = fra.rate(&curve, &curve);
        if let Number::F64(r) = rate {
            // Forward rate should be positive (upward sloping discount curve)
            assert!(r > 0.0, "FRA rate should be positive, got {r}");
            // Should be a reasonable rate
            assert!(r < 0.2, "FRA rate should be < 20% decimal, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_fra_npv() {
        let curve = test_curve();
        let fra = make_test_fra();
        let npv = fra.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "FRA NPV should be finite, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_fra_pillar_date() {
        let fra = make_test_fra();
        assert_eq!(fra.pillar_date(), ymd(2025, 7, 1));
    }

    #[test]
    fn test_fra_cashflows() {
        let curve = test_curve();
        let fra = make_test_fra();
        let rows = fra.cashflows(Some(&curve), Some(&curve));
        assert_eq!(rows.len(), 2, "FRA should have 2 cashflow rows (fixed + float)");
    }
}
