use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;

/// Quote convention for IR futures: price-based (default) or rate-based.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum QuoteConvention {
    /// Default: rate = (100 - price) / 100
    Price,
    /// User passes rate directly in the price field
    Rate,
}

impl Default for QuoteConvention {
    fn default() -> Self {
        QuoteConvention::Price
    }
}

/// STIR (Short-Term Interest Rate) Futures instrument.
///
/// Contract rate = (100 - price) / 100 + convexity_adjustment
/// rate() returns the forward rate implied by the curve for the futures period.
#[derive(Clone, Serialize, Deserialize)]
pub struct IRFutureInstrument {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub notional: f64,
    pub price: f64,
    pub convexity_adjustment: f64,
    pub convention: DayCountConvention,
    /// How the price field is interpreted (Price or Rate).
    pub quote_convention: QuoteConvention,
    /// Hull-White volatility for automatic convexity adjustment computation.
    pub sigma: Option<f64>,
    /// Minimum price increment (contract spec).
    pub tick_size: Option<f64>,
    /// Contract notional per point (contract spec).
    pub notional_multiplier: Option<f64>,
    /// Underlying notional (contract spec).
    pub contract_size: Option<f64>,
}

impl IRFutureInstrument {
    /// Create with backward-compatible signature (new fields default).
    pub fn new(
        start: NaiveDate,
        end: NaiveDate,
        notional: f64,
        price: f64,
        convexity_adjustment: f64,
        convention: DayCountConvention,
    ) -> Self {
        Self {
            start,
            end,
            notional,
            price,
            convexity_adjustment,
            convention,
            quote_convention: QuoteConvention::Price,
            sigma: None,
            tick_size: None,
            notional_multiplier: None,
            contract_size: None,
        }
    }

    /// Create with all fields including new quote convention, sigma, and contract specs.
    pub fn new_extended(
        start: NaiveDate,
        end: NaiveDate,
        notional: f64,
        price: f64,
        convexity_adjustment: f64,
        convention: DayCountConvention,
        quote_convention: QuoteConvention,
        sigma: Option<f64>,
        tick_size: Option<f64>,
        notional_multiplier: Option<f64>,
        contract_size: Option<f64>,
    ) -> Self {
        Self {
            start,
            end,
            notional,
            price,
            convexity_adjustment,
            convention,
            quote_convention,
            sigma,
            tick_size,
            notional_multiplier,
            contract_size,
        }
    }

    fn dcf(&self) -> f64 {
        self.convention.dcf(self.start, self.end, &DcfOptions::default()).unwrap()
    }

    /// Contract rate implied by the futures price (without sigma-based CA).
    /// For Hull-White CA, use `contract_rate_with_valuation`.
    pub fn contract_rate(&self) -> f64 {
        self.contract_rate_with_valuation(None)
    }

    /// Contract rate with optional Hull-White convexity adjustment.
    ///
    /// If `convexity_adjustment` field is non-zero, it takes precedence.
    /// Otherwise, if `sigma` is set and `valuation_date` is provided,
    /// computes CA = 0.5 * sigma^2 * T1 * T2 (Hull-White formula).
    pub fn contract_rate_with_valuation(&self, valuation_date: Option<NaiveDate>) -> f64 {
        let base_rate = match self.quote_convention {
            QuoteConvention::Price => (100.0 - self.price) / 100.0,
            QuoteConvention::Rate => self.price,
        };
        let ca = if self.convexity_adjustment != 0.0 {
            self.convexity_adjustment
        } else if let Some(sigma) = self.sigma {
            if let Some(val_date) = valuation_date {
                let dcf_opts = DcfOptions::default();
                let t1 = DayCountConvention::Act365F
                    .dcf(val_date, self.start, &dcf_opts)
                    .unwrap_or(0.0);
                let t2 = DayCountConvention::Act365F
                    .dcf(val_date, self.end, &dcf_opts)
                    .unwrap_or(0.0);
                0.5 * sigma * sigma * t1 * t2
            } else {
                0.0
            }
        } else {
            0.0
        };
        base_rate + ca
    }

    /// Forward rate implied by the curve for this futures period.
    pub fn rate(
        &self,
        _disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        forecast_curve.forward_rate(self.start, self.end)
    }

    /// NPV based on difference between implied rate and contract rate.
    /// npv = notional * dcf * (implied_rate - contract_rate)
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let dcf = self.dcf();
        let implied_rate = self.rate(disc_curve, forecast_curve);
        let contract_rate = self.contract_rate();
        let diff = &implied_rate - &Number::F64(contract_rate);
        &diff * &Number::F64(self.notional * dcf)
    }

    /// Cashflow rows.
    pub fn cashflows(
        &self,
        _disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let dcf = self.dcf();
        let contract_rate = self.contract_rate();
        let cashflow_val = if let Some(fc) = forecast_curve {
            let implied = fc.forward_rate(self.start, self.end);
            let diff = &implied - &Number::F64(contract_rate);
            &diff * &Number::F64(self.notional * dcf)
        } else {
            Number::F64(f64::NAN)
        };

        vec![CashflowRow {
            period_type: "IRFuture".to_string(),
            start: self.start,
            end: self.end,
            payment: self.end,
            notional: self.notional,
            currency: String::new(),
            fixing_rate: None,
            rate: contract_rate,
            spread: self.convexity_adjustment,
            dcf,
            cashflow: cashflow_val,
            df: Some(Number::F64(1.0)), // futures are margined, no discounting
            npv: None,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        }]
    }

    /// Spread: not applicable for futures, returns 0.
    pub fn spread(
        &self,
        _disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        Number::F64(0.0)
    }

    /// Pillar date: end date.
    pub fn pillar_date(&self) -> NaiveDate {
        self.end
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2024, 4, 1), 0.9925),
            (ymd(2024, 7, 1), 0.985),
            (ymd(2025, 1, 1), 0.97),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_ir_future() -> IRFutureInstrument {
        IRFutureInstrument::new(
            ymd(2024, 4, 1),
            ymd(2024, 7, 1),
            1_000_000.0,
            97.0, // price -> rate ~ 3%
            0.0,  // no convexity adjustment
            DayCountConvention::Act365F,
        )
    }

    #[test]
    fn test_ir_future_contract_rate() {
        let fut = make_test_ir_future();
        let cr = fut.contract_rate();
        assert!((cr - 0.03).abs() < 1e-12, "Contract rate should be 3%, got {cr}");
    }

    #[test]
    fn test_ir_future_rate_from_curve() {
        let curve = test_curve();
        let fut = make_test_ir_future();
        let rate = fut.rate(&curve, &curve);
        if let Number::F64(r) = rate {
            assert!(r > 0.0, "Forward rate should be positive, got {r}");
            assert!(r < 0.2, "Forward rate should be reasonable, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_ir_future_npv() {
        let curve = test_curve();
        let fut = make_test_ir_future();
        let npv = fut.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "IRFuture NPV should be finite, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_ir_future_pillar_date() {
        let fut = make_test_ir_future();
        assert_eq!(fut.pillar_date(), ymd(2024, 7, 1));
    }

    #[test]
    fn test_ir_future_cashflows() {
        let curve = test_curve();
        let fut = make_test_ir_future();
        let rows = fut.cashflows(None, Some(&curve));
        assert_eq!(rows.len(), 1, "IRFuture should have 1 cashflow row");
        assert_eq!(rows[0].period_type, "IRFuture");
    }

    #[test]
    fn test_ir_future_with_convexity_adjustment() {
        let fut = IRFutureInstrument::new(
            ymd(2024, 4, 1),
            ymd(2024, 7, 1),
            1_000_000.0,
            97.0,
            0.001, // 10bp convexity adjustment
            DayCountConvention::Act365F,
        );
        let cr = fut.contract_rate();
        assert!((cr - 0.031).abs() < 1e-12, "Contract rate with CA should be 3.1%, got {cr}");
    }

    #[test]
    fn test_quote_convention_rate() {
        let fut = IRFutureInstrument::new_extended(
            ymd(2024, 4, 1),
            ymd(2024, 7, 1),
            1_000_000.0,
            0.03, // rate directly
            0.0,
            DayCountConvention::Act365F,
            QuoteConvention::Rate,
            None,
            None,
            None,
            None,
        );
        let cr = fut.contract_rate();
        assert!((cr - 0.03).abs() < 1e-12, "Rate convention should return 0.03, got {cr}");
    }

    #[test]
    fn test_hull_white_ca() {
        let sigma = 0.01;
        let val_date = ymd(2024, 1, 1);
        let fut = IRFutureInstrument::new_extended(
            ymd(2024, 4, 1),
            ymd(2024, 7, 1),
            1_000_000.0,
            97.0, // price
            0.0,  // no explicit CA
            DayCountConvention::Act365F,
            QuoteConvention::Price,
            Some(sigma),
            None,
            None,
            None,
        );
        let cr = fut.contract_rate_with_valuation(Some(val_date));
        let dcf_opts = DcfOptions::default();
        let t1 = DayCountConvention::Act365F.dcf(val_date, ymd(2024, 4, 1), &dcf_opts).unwrap();
        let t2 = DayCountConvention::Act365F.dcf(val_date, ymd(2024, 7, 1), &dcf_opts).unwrap();
        let expected_ca = 0.5 * sigma * sigma * t1 * t2;
        let expected_rate = (100.0 - 97.0) / 100.0 + expected_ca;
        assert!(
            (cr - expected_rate).abs() < 1e-12,
            "Hull-White CA: expected {expected_rate}, got {cr}"
        );
        assert!(expected_ca > 0.0, "CA should be positive");
    }

    #[test]
    fn test_sigma_overridden_by_explicit_ca() {
        let fut = IRFutureInstrument::new_extended(
            ymd(2024, 4, 1),
            ymd(2024, 7, 1),
            1_000_000.0,
            97.0,
            0.002, // explicit CA
            DayCountConvention::Act365F,
            QuoteConvention::Price,
            Some(0.01), // sigma also set
            None,
            None,
            None,
        );
        let cr = fut.contract_rate_with_valuation(Some(ymd(2024, 1, 1)));
        let expected = (100.0 - 97.0) / 100.0 + 0.002;
        assert!(
            (cr - expected).abs() < 1e-12,
            "Explicit CA should override sigma: expected {expected}, got {cr}"
        );
    }

    #[test]
    fn test_contract_specs_stored() {
        let fut = IRFutureInstrument::new_extended(
            ymd(2024, 4, 1),
            ymd(2024, 7, 1),
            1_000_000.0,
            97.0,
            0.0,
            DayCountConvention::Act365F,
            QuoteConvention::Price,
            None,
            Some(0.005),
            Some(2500.0),
            Some(1_000_000.0),
        );
        assert_eq!(fut.tick_size, Some(0.005));
        assert_eq!(fut.notional_multiplier, Some(2500.0));
        assert_eq!(fut.contract_size, Some(1_000_000.0));
    }
}
