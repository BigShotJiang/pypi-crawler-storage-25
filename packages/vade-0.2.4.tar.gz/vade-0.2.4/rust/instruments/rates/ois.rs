use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::cashflows::leg::{FixedLeg, FloatLeg};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;

/// Overnight Indexed Swap: FixedLeg + FloatLeg with RFR fixing.
///
/// Structurally identical to IRS but constructed with RFR-based fixing method
/// by default. The float leg compounds overnight rates.
#[derive(Clone, Serialize, Deserialize)]
pub struct OvernightIndexedSwap {
    pub fixed_leg: FixedLeg,
    pub float_leg: FloatLeg,
}

impl OvernightIndexedSwap {
    /// Construct from pre-built legs.
    pub fn new(fixed_leg: FixedLeg, float_leg: FloatLeg) -> Self {
        Self { fixed_leg, float_leg }
    }

    /// Par rate: the fixed rate that makes NPV = 0.
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let float_npv = self.float_leg_coupon_npv(forecast_curve, disc_curve);
        let fixed_ad = self.fixed_leg.analytic_delta(disc_curve);
        &float_npv / &(&fixed_ad * (-100.0))
    }

    /// NPV = fixed_leg_npv + float_leg_npv (coupon only).
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let fixed_npv = self.fixed_leg_coupon_npv(disc_curve);
        let float_npv = self.float_leg_coupon_npv(forecast_curve, disc_curve);
        fixed_npv + float_npv
    }

    /// Fixed leg coupon NPV only.
    fn fixed_leg_coupon_npv(&self, disc_curve: &dyn CurveQuery) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.fixed_leg.periods {
            total = total + p.npv(disc_curve);
        }
        total
    }

    /// Float leg coupon NPV only, dual-curve.
    fn float_leg_coupon_npv(
        &self,
        forecast_curve: &dyn CurveQuery,
        disc_curve: &dyn CurveQuery,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.float_leg.periods {
            total = total + p.npv_dual_curve(forecast_curve, disc_curve, None);
        }
        total
    }

    /// Cashflow rows from both legs.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let mut rows = self.fixed_leg.cashflows(disc_curve);
        if let (Some(fc), Some(_dc)) = (forecast_curve, disc_curve) {
            rows.extend(self.float_leg.cashflows(Some(fc), None));
        } else {
            rows.extend(self.float_leg.cashflows(None, None));
        }
        rows.sort_by_key(|r| r.payment);
        rows
    }

    /// Spread in percentage on the float leg that makes NPV = 0.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let npv = self.npv(disc_curve, forecast_curve);
        let float_ad = self.float_leg.analytic_delta_disc(disc_curve);
        &npv / &(&float_ad * (-100.0))
    }

    /// Pillar date: last period end date.
    pub fn pillar_date(&self) -> NaiveDate {
        self.float_leg.periods.last()
            .map(|p| p.end)
            .unwrap_or_else(|| self.fixed_leg.periods.last().unwrap().end)
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::cashflows::amortization::Amortization;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.88),
            (ymd(2029, 1, 1), 0.85),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_ois() -> OvernightIndexedSwap {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::Annual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap();

        let fixed_leg = FixedLeg::new(
            &schedule,
            3.0,
            1_000_000.0,
            DayCountConvention::Act365F,
            "USD".to_string(),
            None,
            Amortization::None,
        );

        let float_leg = FloatLeg::new(
            &schedule,
            0.0,
            -1_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        );

        OvernightIndexedSwap::new(fixed_leg, float_leg)
    }

    #[test]
    fn test_ois_rate_returns_par_rate() {
        let curve = test_curve();
        let ois = make_test_ois();
        let rate = ois.rate(&curve, &curve);
        if let Number::F64(r) = rate {
            assert!(r > 0.0, "Par rate should be positive, got {r}");
            assert!(r < 20.0, "Par rate should be < 20%, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_ois_npv_at_par_rate_near_zero() {
        let curve = test_curve();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::Annual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap();

        let ois_for_rate = make_test_ois();
        let par_rate = match ois_for_rate.rate(&curve, &curve) {
            Number::F64(r) => r,
            _ => panic!("Expected F64"),
        };

        let fixed_leg = FixedLeg::new(
            &schedule,
            par_rate,
            1_000_000.0,
            DayCountConvention::Act365F,
            "USD".to_string(),
            None,
            Amortization::None,
        );
        let float_leg = FloatLeg::new(
            &schedule,
            0.0,
            -1_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        );
        let ois = OvernightIndexedSwap::new(fixed_leg, float_leg);
        let npv = ois.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            assert!(v.abs() < 1e-6, "NPV at par rate should be ~0, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_ois_spread() {
        let curve = test_curve();
        let ois = make_test_ois();
        let spread = ois.spread(&curve, &curve);
        if let Number::F64(s) = spread {
            assert!(s.is_finite(), "Spread should be finite, got {s}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_ois_cashflows() {
        let curve = test_curve();
        let ois = make_test_ois();
        let rows = ois.cashflows(Some(&curve), Some(&curve));
        assert!(!rows.is_empty(), "Should have cashflow rows");
    }

    #[test]
    fn test_ois_pillar_date() {
        let ois = make_test_ois();
        let pillar = ois.pillar_date();
        assert!(pillar > ymd(2024, 1, 1), "Pillar should be after start");
    }
}
