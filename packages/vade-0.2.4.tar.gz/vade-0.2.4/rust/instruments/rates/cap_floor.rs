use chrono::NaiveDate;
use serde::{Deserialize, Serialize};

use crate::autodiff::enums::Number;
use crate::calendar::adjuster::Adjuster;
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::frequency::Frequency;
use crate::calendar::schedule::{Schedule, StubInference};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;
use crate::models::black::{black76_caplet, bachelier_caplet, VolModel};

/// Cap or floor type.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum CapFloorType {
    Cap,
    Floor,
}

/// A cap or floor instrument priced via Black-76 or Bachelier model.
///
/// Pricing-only: NOT added to the Instrument enum (D-04).
/// Supports full AD via Number type for delta/gamma risk.
#[derive(Clone, Serialize, Deserialize)]
pub struct CapFloor {
    pub cap_floor_type: CapFloorType,
    pub model: VolModel,
    /// Flat volatility in decimal (e.g. 0.20 for 20%).
    pub vol: f64,
    /// Strike rate in percentage (e.g. 3.0 for 3%).
    pub strike: f64,
    pub effective: NaiveDate,
    pub termination: NaiveDate,
    pub frequency: Frequency,
    pub notional: f64,
    pub convention: DayCountConvention,
    pub currency: String,
}

impl CapFloor {
    /// Compute the net present value of the cap or floor.
    ///
    /// Uses forecast_curve for forward rates, disc_curve for discounting.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let is_cap = matches!(self.cap_floor_type, CapFloorType::Cap);
        let strike_decimal = self.strike / 100.0;
        let act365f = DayCountConvention::Act365F;

        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            self.effective,
            self.termination,
            self.frequency.clone(),
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("CapFloor: failed to build schedule");

        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let mut total = Number::F64(0.0);

        for i in 0..n {
            let start = dates[i];
            let end = dates[i + 1];

            let forward = forecast_curve.forward_rate(start, end);
            let df = disc_curve.discount_factor(end);
            let dcf = self
                .convention
                .dcf(start, end, &DcfOptions::default())
                .unwrap();

            // Time to expiry: from effective to period start in Act365F years
            let t = act365f
                .dcf(self.effective, start, &DcfOptions::default())
                .unwrap();

            let caplet_val = match self.model {
                VolModel::Black76 => {
                    black76_caplet(&forward, strike_decimal, self.vol, t, is_cap)
                }
                VolModel::Bachelier => {
                    bachelier_caplet(&forward, strike_decimal, self.vol, t, is_cap)
                }
            };

            let caplet_pv = df * dcf * self.notional * caplet_val;
            total = total + caplet_pv;
        }

        total
    }

    /// Return per-period cashflow decomposition.
    ///
    /// Each row represents one caplet or floorlet with its forward rate,
    /// discount factor, and present value.
    pub fn cashflows(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Vec<CashflowRow> {
        let is_cap = matches!(self.cap_floor_type, CapFloorType::Cap);
        let strike_decimal = self.strike / 100.0;
        let act365f = DayCountConvention::Act365F;
        let period_type = if is_cap {
            "Caplet".to_string()
        } else {
            "Floorlet".to_string()
        };

        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            self.effective,
            self.termination,
            self.frequency.clone(),
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("CapFloor: failed to build schedule");

        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let mut rows = Vec::with_capacity(n);

        for i in 0..n {
            let start = dates[i];
            let end = dates[i + 1];

            let forward = forecast_curve.forward_rate(start, end);
            let df = disc_curve.discount_factor(end);
            let dcf = self
                .convention
                .dcf(start, end, &DcfOptions::default())
                .unwrap();
            let t = act365f
                .dcf(self.effective, start, &DcfOptions::default())
                .unwrap();

            let caplet_val = match self.model {
                VolModel::Black76 => {
                    black76_caplet(&forward, strike_decimal, self.vol, t, is_cap)
                }
                VolModel::Bachelier => {
                    bachelier_caplet(&forward, strike_decimal, self.vol, t, is_cap)
                }
            };

            // Extract forward rate as f64
            let rate_f64 = match &forward {
                Number::F64(v) => *v,
                Number::Dual(d) => d.real,
                Number::Dual2(d) => d.real,
            };

            let cashflow = &caplet_val * (self.notional * dcf);
            let npv = &df * &cashflow;

            rows.push(CashflowRow {
                period_type: period_type.clone(),
                start,
                end,
                payment: end,
                notional: self.notional,
                currency: self.currency.clone(),
                fixing_rate: None,
                rate: rate_f64,
                spread: self.vol,
                dcf,
                cashflow,
                df: Some(df),
                npv: Some(npv),
                        settlement_amount: None,
            fx_rate: None,
            settlement_currency_label: None,
            });
        }

        rows
    }

    /// Rate method: returns NPV / notional as a "premium rate".
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let npv = self.npv(disc_curve, forecast_curve);
        npv / self.notional
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::autodiff::dual::Dual;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.88),
            (ymd(2029, 1, 1), 0.85),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    fn test_curve_dual() -> DiscountCurve {
        let map: IndexMap<NaiveDate, Dual> = IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), Dual::new("df0", 1.0)),
            (ymd(2025, 1, 1), Dual::new("df1", 0.97)),
            (ymd(2026, 1, 1), Dual::new("df2", 0.94)),
            (ymd(2027, 1, 1), Dual::new("df3", 0.91)),
            (ymd(2028, 1, 1), Dual::new("df4", 0.88)),
            (ymd(2029, 1, 1), Dual::new("df5", 0.85)),
        ]);
        let nodes = Nodes::from_dual_map(map);
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    fn make_test_cap() -> CapFloor {
        CapFloor {
            cap_floor_type: CapFloorType::Cap,
            model: VolModel::Black76,
            vol: 0.20,
            strike: 3.0,
            effective: ymd(2024, 1, 1),
            termination: ymd(2025, 1, 1),
            frequency: Frequency::Quarterly,
            notional: 1_000_000.0,
            convention: DayCountConvention::Act365F,
            currency: "USD".to_string(),
        }
    }

    #[test]
    fn test_black76_cap_price() {
        let curve = test_curve();
        let cap = make_test_cap();
        let npv = cap.npv(&curve, &curve);
        match npv {
            Number::F64(v) => {
                assert!(v.is_finite(), "NPV should be finite, got {v}");
                assert!(v > 0.0, "Cap NPV should be positive, got {v}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_bachelier_cap_price() {
        let curve = test_curve();
        let cap = CapFloor {
            model: VolModel::Bachelier,
            vol: 0.005, // normal vol ~50bp
            ..make_test_cap()
        };
        let npv = cap.npv(&curve, &curve);
        match npv {
            Number::F64(v) => {
                assert!(v.is_finite(), "NPV should be finite, got {v}");
                assert!(v > 0.0, "Cap NPV should be positive, got {v}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_floor_price_positive_when_itm() {
        let curve = test_curve();
        // Strike = 5% with ~3% flat curve => floor is ITM
        let floor = CapFloor {
            cap_floor_type: CapFloorType::Floor,
            strike: 5.0,
            ..make_test_cap()
        };
        let npv = floor.npv(&curve, &curve);
        match npv {
            Number::F64(v) => {
                assert!(v > 0.0, "ITM floor NPV should be positive, got {v}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_cap_floor_parity() {
        // Cap - Floor = sum of (F-K)*dcf*df*N for each period
        let curve = test_curve();

        let cap = make_test_cap();
        let floor = CapFloor {
            cap_floor_type: CapFloorType::Floor,
            ..make_test_cap()
        };

        let cap_npv = match cap.npv(&curve, &curve) {
            Number::F64(v) => v,
            _ => panic!("Expected F64"),
        };
        let floor_npv = match floor.npv(&curve, &curve) {
            Number::F64(v) => v,
            _ => panic!("Expected F64"),
        };

        // Compute forward swap value: sum of (F-K)*dcf*df*N
        let strike_decimal = cap.strike / 100.0;
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            cap.effective,
            cap.termination,
            cap.frequency.clone(),
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();
        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let mut forward_swap = 0.0;
        for i in 0..n {
            let start = dates[i];
            let end = dates[i + 1];
            let forward = match curve.forward_rate(start, end) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };
            let df = match curve.discount_factor(end) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            };
            let dcf = cap
                .convention
                .dcf(start, end, &DcfOptions::default())
                .unwrap();
            forward_swap += (forward - strike_decimal) * dcf * df * cap.notional;
        }

        let parity_diff = (cap_npv - floor_npv) - forward_swap;
        assert!(
            parity_diff.abs() < 1e-4,
            "Cap-Floor parity violated: cap={cap_npv}, floor={floor_npv}, swap={forward_swap}, diff={parity_diff}"
        );
    }

    #[test]
    fn test_caplet_cashflows_count() {
        let curve = test_curve();
        let cap = make_test_cap();
        let cfs = cap.cashflows(&curve, &curve);
        // 1Y quarterly = 4 periods
        assert_eq!(
            cfs.len(),
            4,
            "1Y quarterly cap should have 4 caplet cashflows, got {}",
            cfs.len()
        );
        for cf in &cfs {
            assert_eq!(cf.period_type, "Caplet");
        }
    }

    #[test]
    fn test_cap_ad_gradients_nonzero() {
        let curve = test_curve_dual();
        let cap = make_test_cap();
        let npv = cap.npv(&curve, &curve);
        match npv {
            Number::Dual(d) => {
                assert!(d.real.is_finite(), "NPV real should be finite");
                // At least some gradients should be non-zero
                let max_grad = d.dual.iter().map(|v| v.abs()).fold(0.0_f64, f64::max);
                assert!(
                    max_grad > 1e-10,
                    "At least one AD gradient should be non-zero, max={}",
                    max_grad
                );
            }
            _ => panic!("Expected Dual result from Dual curve"),
        }
    }

    #[test]
    fn test_cap_strike_percentage_convention() {
        let curve = test_curve();
        // Strike = 3.0 (percentage) should be different from strike = 0.03
        let cap_pct = CapFloor {
            strike: 3.0,
            ..make_test_cap()
        };
        let cap_dec = CapFloor {
            strike: 0.03,
            ..make_test_cap()
        };

        let npv_pct = match cap_pct.npv(&curve, &curve) {
            Number::F64(v) => v,
            _ => panic!("Expected F64"),
        };
        let npv_dec = match cap_dec.npv(&curve, &curve) {
            Number::F64(v) => v,
            _ => panic!("Expected F64"),
        };

        assert!(
            (npv_pct - npv_dec).abs() > 1e-2,
            "Strike=3.0 vs strike=0.03 should differ: pct={npv_pct}, dec={npv_dec}"
        );
    }
}
