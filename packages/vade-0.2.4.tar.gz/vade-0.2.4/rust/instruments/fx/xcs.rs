use std::collections::HashMap;
use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::convention::DcfOptions;
use crate::cashflows::leg::{FixedLeg, FloatLeg};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::fx::pair::FXPair;
use crate::marketcurves::fx::rates::FXRates;

/// XCS leg type: either Fixed or Float.
#[derive(Clone, Serialize, Deserialize)]
pub enum XCSLeg {
    Fixed(FixedLeg),
    Float(FloatLeg),
}

impl XCSLeg {
    /// Compute coupon-only NPV (excluding notional exchanges) using dual-curve.
    #[allow(dead_code)]
    fn coupon_npv(&self, forecast_curve: &dyn CurveQuery, disc_curve: &dyn CurveQuery) -> Number {
        match self {
            XCSLeg::Fixed(leg) => {
                // Fixed leg: rate from leg itself, discounted with disc_curve
                let mut total = Number::F64(0.0);
                for p in &leg.periods {
                    total = total + p.npv(disc_curve);
                }
                total
            }
            XCSLeg::Float(leg) => {
                leg.npv_dual_curve(forecast_curve, disc_curve, None)
            }
        }
    }

    /// Compute full NPV including notional exchanges.
    fn full_npv(&self, forecast_curve: &dyn CurveQuery, disc_curve: &dyn CurveQuery) -> Number {
        match self {
            XCSLeg::Fixed(leg) => leg.npv(disc_curve),
            XCSLeg::Float(leg) => leg.npv_dual_curve(forecast_curve, disc_curve, None),
        }
    }

    /// Analytic delta for the leg.
    fn analytic_delta(&self, disc_curve: &dyn CurveQuery) -> Number {
        match self {
            XCSLeg::Fixed(leg) => leg.analytic_delta(disc_curve),
            XCSLeg::Float(leg) => leg.analytic_delta_disc(disc_curve),
        }
    }

    /// Cashflow rows.
    fn cashflows(&self, disc_curve: Option<&dyn CurveQuery>, forecast_curve: Option<&dyn CurveQuery>) -> Vec<CashflowRow> {
        match self {
            XCSLeg::Fixed(leg) => leg.cashflows(disc_curve),
            XCSLeg::Float(leg) => leg.cashflows(forecast_curve, None),
        }
    }

    /// Last period end date.
    fn end_date(&self) -> NaiveDate {
        match self {
            XCSLeg::Fixed(leg) => leg.periods.last().map(|p| p.end).unwrap_or(NaiveDate::MIN),
            XCSLeg::Float(leg) => leg.periods.last().map(|p| p.end).unwrap_or(NaiveDate::MIN),
        }
    }
}

/// Cross Currency Swap: two legs in different currencies with 4-curve pricing.
///
/// Supports all variants: FixedFloat, FloatFloat, FixedFixed.
/// Uses 4 curves: leg1 discount, leg1 forecast, leg2 discount, leg2 forecast.
///
/// Notional exchange: initial and final exchange of notionals at inception FX rate.
/// MTM notional resets: optional periodic notional adjustment on one leg.
#[derive(Clone, Serialize, Deserialize)]
pub struct CrossCurrencySwap {
    pub leg1: XCSLeg,
    pub leg2: XCSLeg,
    pub leg1_currency: String,
    pub leg2_currency: String,
    pub notional_exchange: bool,
    pub leg1_notional: f64,
    pub leg2_notional: f64,
    pub initial_fx_rate: f64,
    pub mtm_leg: Option<u8>,
    pub fx_fixings: Vec<f64>,
    // NDXCS-specific (all None for plain XCS)
    #[serde(default)]
    pub settlement_currency: Option<String>,
    #[serde(default)]
    pub nd_leg: Option<u8>,
    #[serde(default)]
    pub nd_fx_fixings: Option<HashMap<NaiveDate, f64>>,
}

impl CrossCurrencySwap {
    pub fn new(
        leg1: XCSLeg,
        leg2: XCSLeg,
        leg1_currency: String,
        leg2_currency: String,
        notional_exchange: bool,
        leg1_notional: f64,
        leg2_notional: f64,
        initial_fx_rate: f64,
        mtm_leg: Option<u8>,
    ) -> Self {
        Self {
            leg1,
            leg2,
            leg1_currency,
            leg2_currency,
            notional_exchange,
            leg1_notional,
            leg2_notional,
            initial_fx_rate,
            mtm_leg,
            fx_fixings: Vec::new(),
            settlement_currency: None,
            nd_leg: None,
            nd_fx_fixings: None,
        }
    }

    /// Construct an NDXCS (non-deliverable cross-currency swap).
    pub fn new_ndxcs(
        leg1: XCSLeg,
        leg2: XCSLeg,
        leg1_currency: String,
        leg2_currency: String,
        notional_exchange: bool,
        leg1_notional: f64,
        leg2_notional: f64,
        initial_fx_rate: f64,
        mtm_leg: Option<u8>,
        settlement_currency: String,
        nd_leg: u8,
        nd_fx_fixings: Option<HashMap<NaiveDate, f64>>,
    ) -> Self {
        Self {
            leg1,
            leg2,
            leg1_currency,
            leg2_currency,
            notional_exchange,
            leg1_notional,
            leg2_notional,
            initial_fx_rate,
            mtm_leg,
            fx_fixings: Vec::new(),
            settlement_currency: Some(settlement_currency),
            nd_leg: Some(nd_leg),
            nd_fx_fixings,
        }
    }

    /// Check if this instrument is configured as an NDXCS.
    pub fn is_ndxcs(&self) -> bool {
        self.nd_leg.is_some()
    }

    /// Get FX rate for a date: use known ND fixing if available, else IRP implied forward.
    /// IRP: fwd = spot * DF_settlement(T) / DF_restricted(T)
    fn fx_for_date(
        &self,
        date: NaiveDate,
        spot: &Number,
        settle_disc: &dyn CurveQuery,
        restricted_disc: &dyn CurveQuery,
    ) -> Number {
        if let Some(fixings) = &self.nd_fx_fixings {
            if let Some(&fx) = fixings.get(&date) {
                return Number::F64(fx);
            }
        }
        // IRP implied forward: fwd = spot * DF_settle / DF_restricted
        let df_s = settle_disc.discount_factor(date);
        let df_r = restricted_disc.discount_factor(date);
        &(spot * &df_s) / &df_r
    }

    /// Par basis spread: the spread on the specified leg (metric) that makes NPV = 0.
    ///
    /// metric = "leg1" or "leg2" (which leg receives the spread).
    /// Returns the spread in basis points.
    ///
    /// 4-curve model:
    /// - leg1_disc: discount curve for leg1 currency
    /// - leg1_forecast: forecast curve for leg1 (if float)
    /// - leg2_disc: discount curve for leg2 currency
    /// - leg2_forecast: forecast curve for leg2 (if float)
    pub fn rate(
        &self,
        leg1_disc: &dyn CurveQuery,
        leg1_forecast: &dyn CurveQuery,
        leg2_disc: &dyn CurveQuery,
        leg2_forecast: &dyn CurveQuery,
        fx_rates: &FXRates,
        metric: &str,
    ) -> Number {
        let leg1_npv = self.leg1.full_npv(leg1_forecast, leg1_disc);
        let leg2_npv = self.leg2.full_npv(leg2_forecast, leg2_disc);

        // Convert leg1 NPV to leg2 currency for comparison
        let fx = fx_rates.rate_for_ccy(&self.leg1_currency, &self.leg2_currency);

        match metric {
            "leg2" => {
                // Spread on leg2: solve leg1_npv_in_leg2_ccy + leg2_npv + spread * leg2_annuity = 0
                let leg1_converted = &leg1_npv * &fx;
                let total_npv = &leg1_converted + &leg2_npv;
                let leg2_ad = self.leg2.analytic_delta(leg2_disc);
                // spread = -total_npv / (leg2_annuity * 100) => in percentage
                // Then * 100 => in basis points... actually:
                // analytic_delta is -notional * dcf / 10000 per period, so total ~ -notional * weighted_dcf / 10000
                // spread (%) = total_npv / (ad * (-100))
                // Return in basis points: * 100
                let spread_pct = &total_npv / &(&leg2_ad * (-100.0));
                &spread_pct * 100.0  // convert percentage to basis points
            }
            "leg1" => {
                // Spread on leg1: convert leg2 NPV to leg1 currency
                let fx_inv = fx_rates.rate_for_ccy(&self.leg2_currency, &self.leg1_currency);
                let leg2_converted = &leg2_npv * &fx_inv;
                let total_npv = &leg1_npv + &leg2_converted;
                let leg1_ad = self.leg1.analytic_delta(leg1_disc);
                let spread_pct = &total_npv / &(&leg1_ad * (-100.0));
                &spread_pct * 100.0
            }
            _ => panic!("metric must be 'leg1' or 'leg2', got '{}'", metric),
        }
    }

    /// NPV of the XCS: both legs converted to a common currency.
    ///
    /// Converts all cashflows to leg1 currency by default.
    pub fn npv(
        &self,
        leg1_disc: &dyn CurveQuery,
        leg1_forecast: &dyn CurveQuery,
        leg2_disc: &dyn CurveQuery,
        leg2_forecast: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let leg1_npv = self.leg1.full_npv(leg1_forecast, leg1_disc);
        let leg2_npv = self.leg2.full_npv(leg2_forecast, leg2_disc);
        // Convert leg2 to leg1 currency
        let fx = fx_rates.rate_for_ccy(&self.leg2_currency, &self.leg1_currency);
        let leg2_converted = &leg2_npv * &fx;
        leg1_npv + leg2_converted
    }

    /// Spread: same as rate for XCS (basis spread).
    pub fn spread(
        &self,
        leg1_disc: &dyn CurveQuery,
        leg1_forecast: &dyn CurveQuery,
        leg2_disc: &dyn CurveQuery,
        leg2_forecast: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        self.rate(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates, "leg2")
    }

    /// Cashflow rows from both legs with currency labels.
    pub fn cashflows(
        &self,
        leg1_disc: Option<&dyn CurveQuery>,
        leg1_forecast: Option<&dyn CurveQuery>,
        leg2_disc: Option<&dyn CurveQuery>,
        leg2_forecast: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let mut rows = self.leg1.cashflows(leg1_disc, leg1_forecast);
        rows.extend(self.leg2.cashflows(leg2_disc, leg2_forecast));
        rows.sort_by_key(|r| r.payment);
        rows
    }

    /// Pillar date: max of leg1 and leg2 end dates.
    pub fn pillar_date(&self) -> NaiveDate {
        self.leg1.end_date().max(self.leg2.end_date())
    }

    // -----------------------------------------------------------------------
    // NDXCS-specific methods
    // -----------------------------------------------------------------------

    /// NDXCS NPV: convert ND-leg cashflows per-period via FX, discount with settlement curve.
    ///
    /// When nd_leg=2: leg2 is ND (restricted), leg1 is non-ND (settlement currency).
    /// When nd_leg=1: leg1 is ND (restricted), leg2 is non-ND (settlement currency).
    pub fn ndxcs_npv(
        &self,
        leg1_disc: &dyn CurveQuery,
        leg1_forecast: &dyn CurveQuery,
        leg2_disc: &dyn CurveQuery,
        leg2_forecast: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let nd = self.nd_leg.expect("NDXCS requires nd_leg");
        let pair = FXPair::new(
            &self.leg1_currency.to_lowercase(),
            &self.leg2_currency.to_lowercase(),
        );
        let spot = fx_rates.rate(&pair);

        // Determine which disc curve is settlement vs restricted
        let (settle_disc, restricted_disc) = if nd == 2 {
            (leg1_disc, leg2_disc)
        } else {
            (leg2_disc, leg1_disc)
        };

        // Non-ND leg: standard NPV
        let non_nd_npv = if nd == 2 {
            self.leg1.full_npv(leg1_forecast, leg1_disc)
        } else {
            self.leg2.full_npv(leg2_forecast, leg2_disc)
        };

        // ND leg: per-period FX-converted NPV
        let nd_leg_ref = if nd == 2 { &self.leg2 } else { &self.leg1 };
        let nd_forecast = if nd == 2 { leg2_forecast } else { leg1_forecast };
        let nd_notional = if nd == 2 { self.leg2_notional } else { self.leg1_notional };

        let mut nd_npv = Number::F64(0.0);

        // Coupon cashflows on the ND leg
        match nd_leg_ref {
            XCSLeg::Fixed(leg) => {
                for p in &leg.periods {
                    let restricted_cf = Number::F64(p.cashflow());
                    let fx = self.fx_for_date(p.payment, &spot, settle_disc, restricted_disc);
                    let settle_cf = &restricted_cf / &fx;
                    let df = settle_disc.discount_factor(p.payment);
                    nd_npv = nd_npv + &settle_cf * &df;
                }
            }
            XCSLeg::Float(leg) => {
                for p in &leg.periods {
                    let rate = p.rate(nd_forecast, None);
                    let dcf = p.convention.dcf(p.start, p.end, &DcfOptions::default()).unwrap();
                    // cashflow = rate * (-notional * dcf) -- rate is decimal from rfr_rate
                    let restricted_cf = &rate * (-p.notional * dcf);
                    let fx = self.fx_for_date(p.payment, &spot, settle_disc, restricted_disc);
                    let settle_cf = &restricted_cf / &fx;
                    let df = settle_disc.discount_factor(p.payment);
                    nd_npv = nd_npv + &settle_cf * &df;
                }
            }
        }

        // Notional exchanges on the ND leg
        if self.notional_exchange {
            let start_date = match nd_leg_ref {
                XCSLeg::Fixed(l) => l.periods.first().map(|p| p.start),
                XCSLeg::Float(l) => l.periods.first().map(|p| p.start),
            };
            let end_date = match nd_leg_ref {
                XCSLeg::Fixed(l) => l.periods.last().map(|p| p.end),
                XCSLeg::Float(l) => l.periods.last().map(|p| p.end),
            };

            if let Some(sd) = start_date {
                // Initial exchange: ND leg receives notional (positive)
                let fx = self.fx_for_date(sd, &spot, settle_disc, restricted_disc);
                let settle_init = &Number::F64(nd_notional) / &fx;
                let df = settle_disc.discount_factor(sd);
                nd_npv = nd_npv + &settle_init * &df;
            }
            if let Some(ed) = end_date {
                // Final exchange: ND leg returns notional (negative)
                let fx = self.fx_for_date(ed, &spot, settle_disc, restricted_disc);
                let settle_final = &Number::F64(-nd_notional) / &fx;
                let df = settle_disc.discount_factor(ed);
                nd_npv = nd_npv + &settle_final * &df;
            }
        }

        // Combine: convert non-ND NPV to settlement currency if needed
        if nd == 2 {
            // leg1 NPV already in settlement (leg1) currency
            non_nd_npv + nd_npv
        } else {
            // leg2 NPV in leg2 currency, convert to leg1 currency via spot
            &non_nd_npv / &spot + nd_npv
        }
    }

    /// NDXCS par rate: the floating spread on the ND leg that makes settlement-currency NPV = 0.
    pub fn ndxcs_rate(
        &self,
        leg1_disc: &dyn CurveQuery,
        leg1_forecast: &dyn CurveQuery,
        leg2_disc: &dyn CurveQuery,
        leg2_forecast: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let nd = self.nd_leg.expect("NDXCS requires nd_leg");
        let pair = FXPair::new(
            &self.leg1_currency.to_lowercase(),
            &self.leg2_currency.to_lowercase(),
        );
        let spot = fx_rates.rate(&pair);

        let (settle_disc, restricted_disc) = if nd == 2 {
            (leg1_disc, leg2_disc)
        } else {
            (leg2_disc, leg1_disc)
        };

        let npv = self.ndxcs_npv(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates);

        // ND leg analytic delta (FX-converted)
        let nd_leg_ref = if nd == 2 { &self.leg2 } else { &self.leg1 };
        let mut nd_ad = Number::F64(0.0);
        match nd_leg_ref {
            XCSLeg::Fixed(leg) => {
                for p in &leg.periods {
                    let dcf = p.convention.dcf(p.start, p.end, &DcfOptions::default()).unwrap();
                    let ad = -p.notional * dcf / 10000.0;
                    let fx = self.fx_for_date(p.payment, &spot, settle_disc, restricted_disc);
                    let df = settle_disc.discount_factor(p.payment);
                    nd_ad = nd_ad + &(&Number::F64(ad) / &fx) * &df;
                }
            }
            XCSLeg::Float(leg) => {
                for p in &leg.periods {
                    let dcf = p.convention.dcf(p.start, p.end, &DcfOptions::default()).unwrap();
                    let ad = -p.notional * dcf / 10000.0;
                    let fx = self.fx_for_date(p.payment, &spot, settle_disc, restricted_disc);
                    let df = settle_disc.discount_factor(p.payment);
                    nd_ad = nd_ad + &(&Number::F64(ad) / &fx) * &df;
                }
            }
        }

        // spread = npv / (ad * -100)
        &npv / &(&nd_ad * (-100.0))
    }

    /// NDXCS cashflows: base XCS cashflows plus settlement conversion info on ND leg.
    pub fn ndxcs_cashflows(
        &self,
        leg1_disc: Option<&dyn CurveQuery>,
        leg1_forecast: Option<&dyn CurveQuery>,
        leg2_disc: Option<&dyn CurveQuery>,
        leg2_forecast: Option<&dyn CurveQuery>,
        fx_rates: Option<&FXRates>,
    ) -> Vec<CashflowRow> {
        let nd = self.nd_leg.expect("NDXCS requires nd_leg");
        let settle_ccy = self.settlement_currency.as_deref().unwrap_or("???");

        // Get base XCS cashflows
        let mut rows = self.cashflows(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast);

        // Add settlement conversion info to ND leg rows
        if let (Some(l1d), Some(l2d), Some(fxr)) = (leg1_disc, leg2_disc, fx_rates) {
            let pair = FXPair::new(
                &self.leg1_currency.to_lowercase(),
                &self.leg2_currency.to_lowercase(),
            );
            let spot = fxr.rate(&pair);
            let (settle_disc, restricted_disc) = if nd == 2 {
                (l1d, l2d)
            } else {
                (l2d, l1d)
            };

            let nd_ccy = if nd == 2 { &self.leg2_currency } else { &self.leg1_currency };

            for row in &mut rows {
                if row.currency.eq_ignore_ascii_case(nd_ccy) {
                    let fx = self.fx_for_date(row.payment, &spot, settle_disc, restricted_disc);
                    let fx_f64 = match &fx {
                        Number::F64(f) => *f,
                        Number::Dual(d) => d.real,
                        Number::Dual2(d) => d.real,
                    };
                    let settle_cf = &row.cashflow / &fx;
                    row.settlement_amount = Some(settle_cf);
                    row.fx_rate = Some(fx_f64);
                    row.settlement_currency_label = Some(settle_ccy.to_string());
                }
            }
        }

        rows
    }

    /// NDXCS spread: par basis spread on ND leg that makes settlement-currency NPV = 0.
    pub fn ndxcs_spread(
        &self,
        leg1_disc: &dyn CurveQuery,
        leg1_forecast: &dyn CurveQuery,
        leg2_disc: &dyn CurveQuery,
        leg2_forecast: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        self.ndxcs_rate(leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates)
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use std::collections::HashMap;
    use crate::cashflows::leg::{FixedLeg, FloatLeg};
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::cashflows::amortization::Amortization;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::fx::pair::FXPair;
    use crate::marketcurves::fx::rates::FXRates;
    use indexmap::IndexMap;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn usd_disc_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd_disc".to_string())
    }

    fn eur_disc_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
            (ymd(2026, 1, 1), 0.96),
        ]));
        DiscountCurve::new(nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "eur_disc".to_string())
    }

    fn fx_rates() -> FXRates {
        FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        )
    }

    fn make_schedule() -> Schedule {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None, None, None,
            StubInference::ShortFront,
        ).unwrap()
    }

    pub fn make_test_xcs() -> CrossCurrencySwap {
        let schedule = make_schedule();
        let leg1 = XCSLeg::Float(FloatLeg::new(
            &schedule,
            0.0,
            1_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "EUR".to_string(),
            None,
            Amortization::None,
        ));
        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule,
            0.0,
            -1_100_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        ));
        CrossCurrencySwap::new(
            leg1, leg2,
            "eur".to_string(), "usd".to_string(),
            true,
            1_000_000.0, 1_100_000.0,
            1.1,
            None,
        )
    }

    #[test]
    fn test_xcs_float_float_npv() {
        let usd = usd_disc_curve();
        let eur = eur_disc_curve();
        let fxr = fx_rates();
        let xcs = make_test_xcs();

        let npv = xcs.npv(&eur, &eur, &usd, &usd, &fxr);
        match npv {
            Number::Dual(d) => assert!(d.real.is_finite(), "XCS NPV should be finite, got {}", d.real),
            Number::F64(v) => assert!(v.is_finite(), "XCS NPV should be finite, got {}", v),
            _ => panic!("Unexpected Number variant"),
        }
    }

    #[test]
    fn test_xcs_rate_metric_leg2() {
        let usd = usd_disc_curve();
        let eur = eur_disc_curve();
        let fxr = fx_rates();
        let xcs = make_test_xcs();

        let spread = xcs.rate(&eur, &eur, &usd, &usd, &fxr, "leg2");
        match spread {
            Number::Dual(d) => {
                assert!(d.real.is_finite(), "XCS spread should be finite, got {}", d.real);
            }
            Number::F64(v) => {
                assert!(v.is_finite(), "XCS spread should be finite, got {}", v);
            }
            _ => panic!("Unexpected Number variant"),
        }
    }

    #[test]
    fn test_xcs_notional_exchange() {
        let xcs = make_test_xcs();
        assert!(xcs.notional_exchange, "XCS should have notional exchange enabled");
        assert_eq!(xcs.leg1_notional, 1_000_000.0);
        assert_eq!(xcs.leg2_notional, 1_100_000.0);
        assert_eq!(xcs.initial_fx_rate, 1.1);
    }

    #[test]
    fn test_xcs_pillar_date() {
        let xcs = make_test_xcs();
        assert_eq!(xcs.pillar_date(), ymd(2026, 1, 1));
    }

    #[test]
    fn test_xcs_cashflows() {
        let usd = usd_disc_curve();
        let eur = eur_disc_curve();
        let xcs = make_test_xcs();

        let rows = xcs.cashflows(Some(&eur), Some(&eur), Some(&usd), Some(&usd));
        assert!(!rows.is_empty(), "XCS should have cashflow rows");
    }

    #[test]
    fn test_xcs_fixed_float() {
        let schedule = make_schedule();
        let leg1 = XCSLeg::Fixed(FixedLeg::new(
            &schedule,
            2.0,
            1_000_000.0,
            DayCountConvention::Act365F,
            "EUR".to_string(),
            None,
            Amortization::None,
        ));
        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule,
            0.0,
            -1_100_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        ));
        let xcs = CrossCurrencySwap::new(
            leg1, leg2,
            "eur".to_string(), "usd".to_string(),
            true, 1_000_000.0, 1_100_000.0, 1.1, None,
        );

        let usd = usd_disc_curve();
        let eur = eur_disc_curve();
        let fxr = fx_rates();

        let npv = xcs.npv(&eur, &eur, &usd, &usd, &fxr);
        match npv {
            Number::Dual(d) => assert!(d.real.is_finite(), "FixedFloat XCS NPV should be finite"),
            Number::F64(v) => assert!(v.is_finite(), "FixedFloat XCS NPV should be finite"),
            _ => panic!("Unexpected Number variant"),
        }
    }

    #[test]
    fn test_xcs_mtm_leg_field() {
        let schedule = make_schedule();
        let leg1 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, 1_000_000.0,
            DayCountConvention::Act365F, FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple, "EUR".to_string(), None, Amortization::None,
        ));
        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, -1_100_000.0,
            DayCountConvention::Act365F, FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple, "USD".to_string(), None, Amortization::None,
        ));
        let xcs = CrossCurrencySwap::new(
            leg1, leg2,
            "eur".to_string(), "usd".to_string(),
            true, 1_000_000.0, 1_100_000.0, 1.1,
            Some(2), // MTM on leg2
        );
        assert_eq!(xcs.mtm_leg, Some(2));
    }

    // -----------------------------------------------------------------------
    // NDXCS test helpers and tests
    // -----------------------------------------------------------------------

    fn number_real(n: &Number) -> f64 {
        match n {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        }
    }

    fn brl_disc_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.88),
            (ymd(2026, 1, 1), 0.77),
        ]));
        DiscountCurve::new(nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "brl_disc".to_string())
    }

    fn ndxcs_fx_rates() -> FXRates {
        FXRates::new(
            vec![(FXPair::new("usd", "brl"), 5.0)],
            ymd(2024, 1, 15),
        )
    }

    fn make_ndxcs_schedule() -> Schedule {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None, None, None,
            StubInference::ShortFront,
        ).unwrap()
    }

    pub fn make_test_ndxcs() -> CrossCurrencySwap {
        let schedule = make_ndxcs_schedule();
        let leg1 = XCSLeg::Float(FloatLeg::new(
            &schedule,
            0.0,
            1_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        ));
        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule,
            0.0,
            -5_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "BRL".to_string(),
            None,
            Amortization::None,
        ));
        CrossCurrencySwap::new_ndxcs(
            leg1, leg2,
            "usd".to_string(), "brl".to_string(),
            true,
            1_000_000.0, 5_000_000.0,
            5.0,
            None,
            "USD".to_string(),
            2,
            None,
        )
    }

    #[test]
    fn test_ndxcs_rate_returns_finite() {
        let usd = usd_disc_curve();
        let brl = brl_disc_curve();
        let fxr = ndxcs_fx_rates();
        let ndxcs = make_test_ndxcs();

        let rate = ndxcs.ndxcs_rate(&usd, &usd, &brl, &brl, &fxr);
        let r = number_real(&rate);
        assert!(r.is_finite(), "NDXCS rate should be finite, got {r}");
    }

    #[test]
    fn test_ndxcs_npv_near_zero_at_par() {
        let usd = usd_disc_curve();
        let brl = brl_disc_curve();
        let fxr = ndxcs_fx_rates();
        let ndxcs = make_test_ndxcs();

        let npv = ndxcs.ndxcs_npv(&usd, &usd, &brl, &brl, &fxr);
        let v = number_real(&npv);
        assert!(v.is_finite(), "NDXCS NPV should be finite, got {v}");
    }

    #[test]
    fn test_ndxcs_cashflows_have_settlement_fields() {
        let usd = usd_disc_curve();
        let brl = brl_disc_curve();
        let fxr = ndxcs_fx_rates();
        let ndxcs = make_test_ndxcs();

        let rows = ndxcs.ndxcs_cashflows(
            Some(&usd), Some(&usd), Some(&brl), Some(&brl), Some(&fxr),
        );
        assert!(!rows.is_empty(), "NDXCS should have cashflow rows");

        // ND leg (BRL) rows should have settlement fields
        let brl_rows: Vec<_> = rows.iter().filter(|r| r.currency == "BRL").collect();
        assert!(!brl_rows.is_empty(), "Should have BRL rows");
        for r in &brl_rows {
            assert!(r.settlement_amount.is_some(), "BRL row should have settlement_amount");
            assert!(r.fx_rate.is_some(), "BRL row should have fx_rate");
            assert_eq!(r.settlement_currency_label.as_deref(), Some("USD"));
        }

        // Non-ND leg (USD) rows should NOT have settlement fields
        let usd_rows: Vec<_> = rows.iter().filter(|r| r.currency == "USD").collect();
        for r in &usd_rows {
            assert!(r.settlement_amount.is_none(), "USD row should not have settlement_amount");
        }
    }

    #[test]
    fn test_ndxcs_spread_returns_finite() {
        let usd = usd_disc_curve();
        let brl = brl_disc_curve();
        let fxr = ndxcs_fx_rates();
        let ndxcs = make_test_ndxcs();

        let spread = ndxcs.ndxcs_spread(&usd, &usd, &brl, &brl, &fxr);
        let s = number_real(&spread);
        assert!(s.is_finite(), "NDXCS spread should be finite, got {s}");
    }

    #[test]
    fn test_ndxcs_notional_exchange_fx() {
        let usd = usd_disc_curve();
        let brl = brl_disc_curve();
        let fxr = ndxcs_fx_rates();

        // With notional exchange
        let ndxcs_with = make_test_ndxcs();
        assert!(ndxcs_with.notional_exchange);
        let rows_with = ndxcs_with.ndxcs_cashflows(
            Some(&usd), Some(&usd), Some(&brl), Some(&brl), Some(&fxr),
        );

        // Without notional exchange
        let schedule = make_ndxcs_schedule();
        let leg1 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, 1_000_000.0, DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple,
            "USD".to_string(), None, Amortization::None,
        ));
        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, -5_000_000.0, DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple,
            "BRL".to_string(), None, Amortization::None,
        ));
        let ndxcs_no = CrossCurrencySwap::new_ndxcs(
            leg1, leg2,
            "usd".to_string(), "brl".to_string(),
            false, 1_000_000.0, 5_000_000.0, 5.0, None,
            "USD".to_string(), 2, None,
        );
        let rows_no = ndxcs_no.ndxcs_cashflows(
            Some(&usd), Some(&usd), Some(&brl), Some(&brl), Some(&fxr),
        );

        // NPVs should differ when notional exchange is toggled
        let npv_with = number_real(&ndxcs_with.ndxcs_npv(&usd, &usd, &brl, &brl, &fxr));
        let npv_no = number_real(&ndxcs_no.ndxcs_npv(&usd, &usd, &brl, &brl, &fxr));
        assert!(npv_with.is_finite() && npv_no.is_finite());
        // They should be different (exchange adds value)
        assert!((npv_with - npv_no).abs() > 1.0, "Notional exchange should materially affect NPV");
    }

    #[test]
    fn test_ndxcs_serde_backward_compat() {
        // Serialize a plain XCS (no ND fields)
        let xcs = make_test_xcs();
        let json = serde_json::to_string(&xcs).unwrap();
        let restored: CrossCurrencySwap = serde_json::from_str(&json).unwrap();
        assert!(restored.settlement_currency.is_none());
        assert!(restored.nd_leg.is_none());
        assert!(restored.nd_fx_fixings.is_none());
        assert!(!restored.is_ndxcs());
    }

    #[test]
    fn test_ndxcs_is_ndxcs_helper() {
        let xcs = make_test_xcs();
        assert!(!xcs.is_ndxcs(), "Plain XCS should return false");
        let ndxcs = make_test_ndxcs();
        assert!(ndxcs.is_ndxcs(), "NDXCS should return true");
    }

    #[test]
    fn test_ndxcs_known_fixing_used() {
        let usd = usd_disc_curve();
        let brl = brl_disc_curve();
        let fxr = ndxcs_fx_rates();

        // Create NDXCS with a known fixing for the first payment date
        let schedule = make_ndxcs_schedule();
        let leg1 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, 1_000_000.0, DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple,
            "USD".to_string(), None, Amortization::None,
        ));
        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, -5_000_000.0, DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay, SpreadMethod::NoneSimple,
            "BRL".to_string(), None, Amortization::None,
        ));

        // Get the first BRL period payment date
        let first_payment = match &leg2 {
            XCSLeg::Float(l) => l.periods[0].payment,
            _ => unreachable!(),
        };

        let mut fixings = HashMap::new();
        fixings.insert(first_payment, 4.8);  // known fixing different from spot (5.0)

        let ndxcs = CrossCurrencySwap::new_ndxcs(
            leg1, leg2,
            "usd".to_string(), "brl".to_string(),
            true, 1_000_000.0, 5_000_000.0, 5.0, None,
            "USD".to_string(), 2, Some(fixings),
        );

        let rows = ndxcs.ndxcs_cashflows(
            Some(&usd), Some(&usd), Some(&brl), Some(&brl), Some(&fxr),
        );

        // Find the BRL row for the first payment date and verify the known fixing was used
        let first_brl_row = rows.iter()
            .find(|r| r.currency == "BRL" && r.payment == first_payment)
            .expect("Should find BRL row for first payment");
        let fx_used = first_brl_row.fx_rate.expect("fx_rate should be set");
        assert!((fx_used - 4.8).abs() < 1e-10, "Known fixing 4.8 should be used, got {fx_used}");
    }
}
