use chrono::NaiveDate;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::cashflows::amortization::Amortization;
use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
use crate::cashflows::leg::{self, FixedLeg, FloatLeg};
use crate::cashflows::py::PyCashflowRow;
use crate::marketcurves::fx::pair::FXPair;
use crate::marketcurves::fx::py::PyFXRates;
use crate::instruments;
use crate::instruments::xcs::XCSLeg;
use crate::instruments::py_utils::{
    number_to_py, parse_day_count, parse_adjuster, parse_frequency,
    parse_fixing_method, parse_stub, build_calendar, extract_curve_ref,
    resolve_per_leg_amortization, parse_amortization,
};

// ---- PyXCS (CrossCurrencySwap) ----

#[pyclass(name = "CrossCurrencySwap", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyXCS {
    pub inner: instruments::CrossCurrencySwap,
}

#[pymethods]
impl PyXCS {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        frequency = "q",
        leg1_currency = "EUR",
        leg2_currency = "USD",
        leg1_notional = 1000000.0,
        leg2_notional = 1100000.0,
        initial_fx_rate = 1.1,
        fixed_rate = None,
        notional_exchange = true,
        convention = "act360",
        leg2_convention = None,
        fixing_method = "rfr_payment_delay",
        spread = 0.0,
        modifier = "mf",
        stub = "shortfront",
        mtm_leg = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        leg1_currency: &str,
        leg2_currency: &str,
        leg1_notional: f64,
        leg2_notional: f64,
        initial_fx_rate: f64,
        fixed_rate: Option<f64>,
        notional_exchange: bool,
        convention: &str,
        leg2_convention: Option<&str>,
        fixing_method: &str,
        spread: f64,
        modifier: &str,
        stub: &str,
        mtm_leg: Option<u8>,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let conv = parse_day_count(convention)?;
        let conv2 = match leg2_convention {
            Some(s) => parse_day_count(s)?,
            None => conv,
        };
        let fm = parse_fixing_method(fixing_method)?;
        let adj = parse_adjuster(modifier)?;
        let stub_inf = parse_stub(stub);
        let cal = build_calendar(None);

        let schedule = crate::calendar::schedule::Schedule::try_new(
            effective, termination, freq, cal, adj,
            None, None, None, stub_inf,
        ).map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        let leg1 = match fixed_rate {
            Some(fr) => XCSLeg::Fixed(FixedLeg::new(
                &schedule, fr, leg1_notional, conv, leg1_currency.to_string(),
                None, Amortization::None,
            )),
            None => XCSLeg::Float(FloatLeg::new(
                &schedule, spread, leg1_notional, conv, fm.clone(),
                SpreadMethod::NoneSimple, leg1_currency.to_string(),
                None, Amortization::None,
            )),
        };

        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, -leg2_notional, conv2, fm,
            SpreadMethod::NoneSimple, leg2_currency.to_string(),
            None, Amortization::None,
        ));

        Ok(PyXCS {
            inner: instruments::CrossCurrencySwap::new(
                leg1, leg2,
                leg1_currency.to_string(), leg2_currency.to_string(),
                notional_exchange, leg1_notional, leg2_notional,
                initial_fx_rate, mtm_leg,
            ),
        })
    }

    #[pyo3(signature = (
        leg1_disc,
        leg1_forecast,
        leg2_disc,
        leg2_forecast,
        fx_rates,
        metric = "leg2",
    ))]
    fn rate(
        &self,
        py: Python<'_>,
        leg1_disc: &Bound<'_, PyAny>,
        leg1_forecast: &Bound<'_, PyAny>,
        leg2_disc: &Bound<'_, PyAny>,
        leg2_forecast: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
        metric: &str,
    ) -> PyResult<Py<PyAny>> {
        let l1d = extract_curve_ref(leg1_disc)?;
        let l1f = extract_curve_ref(leg1_forecast)?;
        let l2d = extract_curve_ref(leg2_disc)?;
        let l2f = extract_curve_ref(leg2_forecast)?;
        number_to_py(py, self.inner.rate(&*l1d, &*l1f, &*l2d, &*l2f, &fx_rates.inner, metric))
    }

    fn npv(
        &self,
        py: Python<'_>,
        leg1_disc: &Bound<'_, PyAny>,
        leg1_forecast: &Bound<'_, PyAny>,
        leg2_disc: &Bound<'_, PyAny>,
        leg2_forecast: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Py<PyAny>> {
        let l1d = extract_curve_ref(leg1_disc)?;
        let l1f = extract_curve_ref(leg1_forecast)?;
        let l2d = extract_curve_ref(leg2_disc)?;
        let l2f = extract_curve_ref(leg2_forecast)?;
        number_to_py(py, self.inner.npv(&*l1d, &*l1f, &*l2d, &*l2f, &fx_rates.inner))
    }

    fn cashflows(
        &self,
        leg1_disc: &Bound<'_, PyAny>,
        leg1_forecast: &Bound<'_, PyAny>,
        leg2_disc: &Bound<'_, PyAny>,
        leg2_forecast: &Bound<'_, PyAny>,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let l1d = extract_curve_ref(leg1_disc)?;
        let l1f = extract_curve_ref(leg1_forecast)?;
        let l2d = extract_curve_ref(leg2_disc)?;
        let l2f = extract_curve_ref(leg2_forecast)?;
        let rows = self.inner.cashflows(Some(&*l1d), Some(&*l1f), Some(&*l2d), Some(&*l2f));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn __repr__(&self) -> String {
        format!(
            "CrossCurrencySwap({}/{}, notional_exchange={})",
            self.inner.leg1_currency, self.inner.leg2_currency, self.inner.notional_exchange
        )
    }
}

// ---- PyFXForwardInst (FXForward) ----

#[pyclass(name = "FXForward", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyFXForwardInst {
    pub inner: instruments::FXForwardInstrument,
}

#[pymethods]
impl PyFXForwardInst {
    #[new]
    #[pyo3(signature = (pair, notional, delivery, currency = "USD"))]
    fn new(pair: &str, notional: f64, delivery: NaiveDate, currency: &str) -> PyResult<Self> {
        let fx_pair = FXPair::from_str(pair)
            .map_err(|e| PyValueError::new_err(e))?;
        Ok(PyFXForwardInst {
            inner: instruments::FXForwardInstrument::new(
                fx_pair, notional, delivery, currency.to_string(),
            ),
        })
    }

    fn rate(
        &self,
        py: Python<'_>,
        disc_curve: &Bound<'_, PyAny>,
        forecast_curve: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        number_to_py(py, self.inner.rate(&*dc, &*fc, &fx_rates.inner))
    }

    fn npv(
        &self,
        py: Python<'_>,
        disc_curve: &Bound<'_, PyAny>,
        forecast_curve: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        number_to_py(py, self.inner.npv(&*dc, &*fc, &fx_rates.inner))
    }

    fn cashflows(
        &self,
        disc_curve: &Bound<'_, PyAny>,
        forecast_curve: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        let rows = self.inner.cashflows(Some(&*dc), Some(&*fc), Some(&fx_rates.inner));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn __repr__(&self) -> String {
        format!("FXForward(pair='{}', delivery={})", self.inner.pair, self.inner.delivery)
    }
}

// ---- PyNDFInstrument (NDF) ----

#[pyclass(name = "NDF", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyNDFInstrument {
    pub inner: instruments::FXForwardInstrument,
}

#[pymethods]
impl PyNDFInstrument {
    #[new]
    #[pyo3(signature = (pair, notional, delivery, settlement_currency, contracted_rate, currency = "USD", fx_fixing = None, leg2_fx_fixing = None))]
    fn new(
        pair: &str,
        notional: f64,
        delivery: NaiveDate,
        settlement_currency: &str,
        contracted_rate: f64,
        currency: &str,
        fx_fixing: Option<f64>,
        leg2_fx_fixing: Option<f64>,
    ) -> PyResult<Self> {
        let fx_pair = FXPair::from_str(pair)
            .map_err(|e| PyValueError::new_err(e))?;
        Ok(PyNDFInstrument {
            inner: instruments::FXForwardInstrument::new_ndf(
                fx_pair, notional, delivery, currency.to_string(),
                settlement_currency.to_string(), contracted_rate,
                fx_fixing, leg2_fx_fixing,
            ),
        })
    }

    fn rate(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        number_to_py(py, self.inner.ndf_rate(&*dc, &*fc, &fx_rates.inner))
    }

    fn npv(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        number_to_py(py, self.inner.ndf_npv(&*dc, &*fc, &fx_rates.inner))
    }

    fn cashflows(&self, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Vec<PyCashflowRow>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        let rows = self.inner.ndf_cashflows(Some(&*dc), Some(&*fc), Some(&fx_rates.inner));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        number_to_py(py, self.inner.ndf_spread(&*dc, &*fc, &fx_rates.inner))
    }

    fn pillar_date(&self) -> NaiveDate {
        self.inner.pillar_date()
    }

    fn __repr__(&self) -> String {
        format!(
            "NDF(pair='{}', delivery={}, settlement_currency='{}')",
            self.inner.pair, self.inner.delivery,
            self.inner.settlement_currency.as_deref().unwrap_or("?")
        )
    }
}

// ---- PyNDIRSInstrument (NDIRS) ----
// Note: NDIRS wraps an InterestRateSwap with ND fields, but belongs in fx/ because
// it involves cross-currency FX settlement mechanics.

#[pyclass(name = "NDIRS", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyNDIRSInstrument {
    pub inner: instruments::InterestRateSwap,
}

#[pymethods]
impl PyNDIRSInstrument {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        frequency,
        fixed_rate,
        notional,
        convention,
        float_convention,
        fixing_method,
        spread,
        settlement_currency,
        pair,
        currency,
        modifier = "mf",
        stub = "shortfront",
        calendar = None,
        payment_lag = None,
        fx_fixings = None,
        amortization = None,
        fixed_amortization = None,
        float_amortization = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        fixed_rate: f64,
        notional: f64,
        convention: &str,
        float_convention: &str,
        fixing_method: &str,
        spread: f64,
        settlement_currency: &str,
        pair: &str,
        currency: &str,
        modifier: &str,
        stub: &str,
        calendar: Option<&str>,
        payment_lag: Option<i32>,
        fx_fixings: Option<std::collections::HashMap<NaiveDate, f64>>,
        amortization: Option<&Bound<'_, PyAny>>,
        fixed_amortization: Option<&Bound<'_, PyAny>>,
        float_amortization: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let conv = parse_day_count(convention)?;
        let fconv = parse_day_count(float_convention)?;
        let fm = parse_fixing_method(fixing_method)?;
        let adj = parse_adjuster(modifier)?;
        let stub_inf = parse_stub(stub);
        let (fixed_amort, float_amort) = resolve_per_leg_amortization(
            amortization, fixed_amortization, float_amortization,
        )?;
        let cal = build_calendar(calendar);

        let fx_pair = FXPair::from_str(pair)
            .map_err(|e| PyValueError::new_err(e))?;

        let schedule = crate::calendar::schedule::Schedule::try_new(
            effective,
            termination,
            freq,
            cal.clone(),
            adj,
            None,
            None,
            None,
            stub_inf,
        )
        .map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        let fixed_leg = leg::FixedLeg::new(
            &schedule,
            fixed_rate,
            notional,
            conv,
            currency.to_string(),
            payment_lag,
            fixed_amort,
        );
        let float_leg = leg::FloatLeg::new(
            &schedule,
            spread,
            -notional,
            fconv,
            fm,
            SpreadMethod::NoneSimple,
            currency.to_string(),
            payment_lag,
            float_amort,
        );

        Ok(PyNDIRSInstrument {
            inner: instruments::InterestRateSwap::new_ndirs(
                fixed_leg,
                float_leg,
                settlement_currency.to_string(),
                fx_pair,
                fx_fixings,
            ),
        })
    }

    fn rate(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, leg2_disc_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        let l2d = extract_curve_ref(leg2_disc_curve)?;
        number_to_py(py, self.inner.ndirs_rate(&*dc, &*fc, &*l2d, &fx_rates.inner))
    }

    fn npv(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, leg2_disc_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        let l2d = extract_curve_ref(leg2_disc_curve)?;
        number_to_py(py, self.inner.ndirs_npv(&*dc, &*fc, &*l2d, &fx_rates.inner))
    }

    fn cashflows(&self, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, leg2_disc_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Vec<PyCashflowRow>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        let l2d = extract_curve_ref(leg2_disc_curve)?;
        let rows = self.inner.ndirs_cashflows(Some(&*dc), Some(&*fc), Some(&*l2d), Some(&fx_rates.inner));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, forecast_curve: &Bound<'_, PyAny>, leg2_disc_curve: &Bound<'_, PyAny>, fx_rates: &PyFXRates) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let fc = extract_curve_ref(forecast_curve)?;
        let l2d = extract_curve_ref(leg2_disc_curve)?;
        number_to_py(py, self.inner.ndirs_spread(&*dc, &*fc, &*l2d, &fx_rates.inner))
    }

    fn pillar_date(&self) -> NaiveDate {
        self.inner.pillar_date()
    }

    fn __repr__(&self) -> String {
        format!(
            "NDIRS(settlement_currency='{}', pair='{}')",
            self.inner.settlement_currency.as_deref().unwrap_or("?"),
            self.inner.pair.as_ref().map(|p| p.to_string()).unwrap_or_else(|| "?".to_string()),
        )
    }
}

// ---- PyNDXCSInstrument (NDXCS) ----

#[pyclass(name = "NDXCS", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyNDXCSInstrument {
    pub inner: instruments::CrossCurrencySwap,
}

#[pymethods]
impl PyNDXCSInstrument {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        frequency = "q",
        leg1_currency = "USD",
        leg2_currency = "BRL",
        leg1_notional = 1000000.0,
        leg2_notional = 5000000.0,
        initial_fx_rate = 5.0,
        fixed_rate = None,
        notional_exchange = true,
        convention = "act360",
        leg2_convention = None,
        fixing_method = "rfr_payment_delay",
        spread = 0.0,
        modifier = "mf",
        stub = "shortfront",
        mtm_leg = None,
        settlement_currency = "usd",
        nd_leg = 2,
        calendar = None,
        nd_fx_fixings = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        leg1_currency: &str,
        leg2_currency: &str,
        leg1_notional: f64,
        leg2_notional: f64,
        initial_fx_rate: f64,
        fixed_rate: Option<f64>,
        notional_exchange: bool,
        convention: &str,
        leg2_convention: Option<&str>,
        fixing_method: &str,
        spread: f64,
        modifier: &str,
        stub: &str,
        mtm_leg: Option<u8>,
        settlement_currency: &str,
        nd_leg: u8,
        calendar: Option<&str>,
        nd_fx_fixings: Option<std::collections::HashMap<NaiveDate, f64>>,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let conv = parse_day_count(convention)?;
        let conv2 = match leg2_convention {
            Some(s) => parse_day_count(s)?,
            None => conv,
        };
        let fm = parse_fixing_method(fixing_method)?;
        let adj = parse_adjuster(modifier)?;
        let stub_inf = parse_stub(stub);
        let cal = build_calendar(calendar);

        let schedule = crate::calendar::schedule::Schedule::try_new(
            effective, termination, freq, cal, adj,
            None, None, None, stub_inf,
        ).map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        let leg1 = match fixed_rate {
            Some(fr) => XCSLeg::Fixed(FixedLeg::new(
                &schedule, fr, leg1_notional, conv, leg1_currency.to_string(),
                None, Amortization::None,
            )),
            None => XCSLeg::Float(FloatLeg::new(
                &schedule, spread, leg1_notional, conv, fm.clone(),
                SpreadMethod::NoneSimple, leg1_currency.to_string(),
                None, Amortization::None,
            )),
        };

        let leg2 = XCSLeg::Float(FloatLeg::new(
            &schedule, 0.0, -leg2_notional, conv2, fm,
            SpreadMethod::NoneSimple, leg2_currency.to_string(),
            None, Amortization::None,
        ));

        Ok(PyNDXCSInstrument {
            inner: instruments::CrossCurrencySwap::new_ndxcs(
                leg1, leg2,
                leg1_currency.to_string(), leg2_currency.to_string(),
                notional_exchange, leg1_notional, leg2_notional,
                initial_fx_rate, mtm_leg,
                settlement_currency.to_uppercase(),
                nd_leg,
                nd_fx_fixings,
            ),
        })
    }

    #[pyo3(signature = (leg1_disc, leg1_forecast, leg2_disc, leg2_forecast, fx_rates))]
    fn rate(
        &self,
        py: Python<'_>,
        leg1_disc: &Bound<'_, PyAny>,
        leg1_forecast: &Bound<'_, PyAny>,
        leg2_disc: &Bound<'_, PyAny>,
        leg2_forecast: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Py<PyAny>> {
        let l1d = extract_curve_ref(leg1_disc)?;
        let l1f = extract_curve_ref(leg1_forecast)?;
        let l2d = extract_curve_ref(leg2_disc)?;
        let l2f = extract_curve_ref(leg2_forecast)?;
        number_to_py(py, self.inner.ndxcs_rate(&*l1d, &*l1f, &*l2d, &*l2f, &fx_rates.inner))
    }

    fn npv(
        &self,
        py: Python<'_>,
        leg1_disc: &Bound<'_, PyAny>,
        leg1_forecast: &Bound<'_, PyAny>,
        leg2_disc: &Bound<'_, PyAny>,
        leg2_forecast: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Py<PyAny>> {
        let l1d = extract_curve_ref(leg1_disc)?;
        let l1f = extract_curve_ref(leg1_forecast)?;
        let l2d = extract_curve_ref(leg2_disc)?;
        let l2f = extract_curve_ref(leg2_forecast)?;
        number_to_py(py, self.inner.ndxcs_npv(&*l1d, &*l1f, &*l2d, &*l2f, &fx_rates.inner))
    }

    fn cashflows(
        &self,
        leg1_disc: &Bound<'_, PyAny>,
        leg1_forecast: &Bound<'_, PyAny>,
        leg2_disc: &Bound<'_, PyAny>,
        leg2_forecast: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Vec<PyCashflowRow>> {
        let l1d = extract_curve_ref(leg1_disc)?;
        let l1f = extract_curve_ref(leg1_forecast)?;
        let l2d = extract_curve_ref(leg2_disc)?;
        let l2f = extract_curve_ref(leg2_forecast)?;
        let rows = self.inner.ndxcs_cashflows(
            Some(&*l1d), Some(&*l1f), Some(&*l2d), Some(&*l2f), Some(&fx_rates.inner),
        );
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(
        &self,
        py: Python<'_>,
        leg1_disc: &Bound<'_, PyAny>,
        leg1_forecast: &Bound<'_, PyAny>,
        leg2_disc: &Bound<'_, PyAny>,
        leg2_forecast: &Bound<'_, PyAny>,
        fx_rates: &PyFXRates,
    ) -> PyResult<Py<PyAny>> {
        let l1d = extract_curve_ref(leg1_disc)?;
        let l1f = extract_curve_ref(leg1_forecast)?;
        let l2d = extract_curve_ref(leg2_disc)?;
        let l2f = extract_curve_ref(leg2_forecast)?;
        number_to_py(py, self.inner.ndxcs_spread(&*l1d, &*l1f, &*l2d, &*l2f, &fx_rates.inner))
    }

    fn pillar_date(&self) -> NaiveDate {
        self.inner.pillar_date()
    }

    fn __repr__(&self) -> String {
        format!(
            "NDXCS(settlement_currency='{}', nd_leg={}, {}x{})",
            self.inner.settlement_currency.as_deref().unwrap_or("?"),
            self.inner.nd_leg.unwrap_or(0),
            self.inner.leg1_currency,
            self.inner.leg2_currency,
        )
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyXCS>()?;
    m.add_class::<PyFXForwardInst>()?;
    m.add_class::<PyNDFInstrument>()?;
    m.add_class::<PyNDIRSInstrument>()?;
    m.add_class::<PyNDXCSInstrument>()?;
    Ok(())
}
