use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::fx::pair::FXPair;
use crate::marketcurves::fx::rates::FXRates;

/// FX Forward instrument: a single FX exchange at a future delivery date.
///
/// Prices via interest rate parity (IRP):
///   implied_forward = spot * DF_domestic(delivery) / DF_foreign(delivery)
///
/// disc_curve = domestic currency discount curve
/// forecast_curve = foreign currency discount curve
///
/// When NDF-specific fields are set (settlement_currency, contracted_rate),
/// additional NDF methods (ndf_rate, ndf_npv, ndf_cashflows, ndf_spread)
/// provide non-deliverable forward pricing with net settlement.
#[derive(Clone, Serialize, Deserialize)]
pub struct FXForwardInstrument {
    pub pair: FXPair,
    pub notional: f64,
    pub delivery: NaiveDate,
    pub currency: String,
    // NDF-specific (all None for plain FXForward)
    #[serde(default)]
    pub settlement_currency: Option<String>,
    #[serde(default)]
    pub contracted_rate: Option<f64>,
    #[serde(default)]
    pub fx_fixing: Option<f64>,
    #[serde(default)]
    pub leg2_fx_fixing: Option<f64>,
}

impl FXForwardInstrument {
    pub fn new(pair: FXPair, notional: f64, delivery: NaiveDate, currency: String) -> Self {
        Self {
            pair,
            notional,
            delivery,
            currency,
            settlement_currency: None,
            contracted_rate: None,
            fx_fixing: None,
            leg2_fx_fixing: None,
        }
    }

    /// Construct an NDF (non-deliverable forward).
    pub fn new_ndf(
        pair: FXPair,
        notional: f64,
        delivery: NaiveDate,
        currency: String,
        settlement_currency: String,
        contracted_rate: f64,
        fx_fixing: Option<f64>,
        leg2_fx_fixing: Option<f64>,
    ) -> Self {
        Self {
            pair,
            notional,
            delivery,
            currency,
            settlement_currency: Some(settlement_currency),
            contracted_rate: Some(contracted_rate),
            fx_fixing,
            leg2_fx_fixing,
        }
    }

    /// Check if this instrument is configured as an NDF.
    #[allow(dead_code)]
    fn is_ndf(&self) -> bool {
        self.settlement_currency.is_some()
    }

    /// Implied forward rate via IRP: spot * DF_dom / DF_for.
    ///
    /// disc_curve = domestic currency curve, forecast_curve = foreign currency curve.
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let spot = fx_rates.rate(&self.pair);
        let df_dom = disc_curve.discount_factor(self.delivery);
        let df_for = forecast_curve.discount_factor(self.delivery);
        // implied_forward = spot * DF_dom / DF_for
        &(&spot * &df_dom) / &df_for
    }

    /// NDF fair rate: identical to rate() since the IRP implied forward IS the NDF fair rate.
    pub fn ndf_rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        self.rate(disc_curve, forecast_curve, fx_rates)
    }

    /// NDF NPV: discounted net settlement amount in the settlement currency.
    ///
    /// For 2-currency NDF (settlement_currency == pair.lhs or pair.rhs):
    /// - If settlement_currency == pair.rhs: NPV = notional * (fixing_rate - contracted) * DF
    /// - If settlement_currency == pair.lhs: NPV = notional * (1/contracted - 1/fixing) * fixing * DF
    ///
    /// For 3-currency NDF (settlement_currency != either pair currency):
    /// - Both legs converted to settlement currency via FX fixings/forwards, then discounted.
    pub fn ndf_npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let settlement_ccy = self.settlement_currency.as_ref()
            .expect("ndf_npv requires settlement_currency");
        let contracted = self.contracted_rate.unwrap_or(0.0);

        // Get the fixing rate: use fx_fixing if provided, otherwise implied forward
        let fixing_rate = match self.fx_fixing {
            Some(f) => Number::F64(f),
            None => self.rate(disc_curve, forecast_curve, fx_rates),
        };

        let df = disc_curve.discount_factor(self.delivery);

        if settlement_ccy == &self.pair.lhs || settlement_ccy == &self.pair.rhs {
            // 2-currency NDF
            if settlement_ccy == &self.pair.rhs {
                // Settlement in RHS (e.g., USDBRL settled in BRL... unusual but supported)
                // net_settlement = notional * (fixing_rate - contracted_rate)
                let net = &(&fixing_rate - &Number::F64(contracted)) * self.notional;
                &net * &df
            } else {
                // Settlement in LHS (e.g., USDBRL settled in USD -- most common)
                // net_settlement = notional * (1/contracted - 1/fixing) * fixing
                // = notional * (fixing - contracted) / contracted
                let net_rhs = &(&fixing_rate - &Number::F64(contracted)) * self.notional;
                let net_lhs = &net_rhs / &fixing_rate;
                &net_lhs * &df
            }
        } else {
            // 3-currency NDF: settlement_currency differs from both pair currencies
            // Use fx_fixing for pair.rhs -> settlement conversion
            // Use leg2_fx_fixing for pair.lhs -> settlement conversion
            let implied_fwd = self.rate(disc_curve, forecast_curve, fx_rates);

            // Domestic leg (LHS): -notional in LHS currency
            // Foreign leg (RHS): +notional * contracted_rate in RHS currency
            // Net in pair terms: notional * (implied_fwd - contracted) in RHS terms

            // Convert RHS to settlement using fx_fixing (rhs_per_settlement or settlement_per_rhs)
            let rhs_to_settle = match self.fx_fixing {
                Some(f) => Number::F64(f),
                None => {
                    // Use FXRates to get conversion from RHS to settlement
                    let settle_pair = FXPair::new(&self.pair.rhs, settlement_ccy);
                    fx_rates.rate(&settle_pair)
                }
            };

            let lhs_to_settle = match self.leg2_fx_fixing {
                Some(f) => Number::F64(f),
                None => {
                    let settle_pair = FXPair::new(&self.pair.lhs, settlement_ccy);
                    fx_rates.rate(&settle_pair)
                }
            };

            // Domestic leg value in settlement: -notional * lhs_to_settle
            let _dom_settle = &Number::F64(-self.notional) * &lhs_to_settle;
            // Foreign leg value in settlement: +notional * contracted * rhs_to_settle... wait
            // Actually: we pay notional LHS, receive notional*contracted RHS
            // At market: we would receive notional*implied_fwd RHS
            // NPV = (notional*implied_fwd - notional*contracted) in RHS, convert to settlement
            let net_rhs = &(&implied_fwd - &Number::F64(contracted)) * self.notional;
            let net_settle = &net_rhs * &rhs_to_settle;
            &net_settle * &df
        }
    }

    /// NDF cashflows: 2 rows representing the domestic and foreign legs.
    ///
    /// Row 1 (NDF_Domestic): LHS currency leg
    /// Row 2 (NDF_Foreign): RHS currency leg with fixing rate
    pub fn ndf_cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
        fx_rates: Option<&FXRates>,
    ) -> Vec<CashflowRow> {
        let mut rows = Vec::new();
        let contracted = self.contracted_rate.unwrap_or(0.0);

        let (df_dom, df_for, fwd_rate) = match (disc_curve, forecast_curve, fx_rates) {
            (Some(dc), Some(fc), Some(fxr)) => {
                let df_d = dc.discount_factor(self.delivery);
                let df_f = fc.discount_factor(self.delivery);
                let fwd = self.rate(dc, fc, fxr);
                (Some(df_d), Some(df_f), Some(fwd))
            }
            _ => (None, None, None),
        };

        // Fixing rate for display: use fx_fixing if provided, else implied forward
        let fixing_for_display = match self.fx_fixing {
            Some(f) => Some(Number::F64(f)),
            None => fwd_rate.clone(),
        };

        // Domestic leg: pay notional in LHS currency
        let dom_cf = -self.notional;
        let (dom_npv, dom_df) = match &df_dom {
            Some(d) => (Some(d * dom_cf), Some(d.clone())),
            None => (None, None),
        };
        rows.push(CashflowRow {
            period_type: "NDF_Domestic".to_string(),
            start: self.delivery,
            end: self.delivery,
            payment: self.delivery,
            currency: self.pair.lhs.clone(),
            notional: -self.notional,
            fixing_rate: None,
            rate: 0.0,
            spread: 0.0,
            dcf: 0.0,
            cashflow: Number::F64(dom_cf),
            df: dom_df,
            npv: dom_npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        });

        // Foreign leg: receive notional * contracted_rate in RHS currency
        let for_notional = self.notional * contracted;
        let for_cf = for_notional;
        let (for_npv, for_df) = match &df_for {
            Some(d) => (Some(d * for_cf), Some(d.clone())),
            None => (None, None),
        };
        rows.push(CashflowRow {
            period_type: "NDF_Foreign".to_string(),
            start: self.delivery,
            end: self.delivery,
            payment: self.delivery,
            currency: self.pair.rhs.clone(),
            notional: for_notional,
            fixing_rate: fixing_for_display,
            rate: contracted,
            spread: 0.0,
            dcf: 0.0,
            cashflow: Number::F64(for_cf),
            df: for_df,
            npv: for_npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        });

        rows
    }

    /// NDF spread: forward points = contracted_rate - implied_forward.
    pub fn ndf_spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let implied = self.rate(disc_curve, forecast_curve, fx_rates);
        let contracted = Number::F64(self.contracted_rate.unwrap_or(0.0));
        &contracted - &implied
    }

    /// NPV of the FX forward from the domestic perspective.
    ///
    /// At inception, NPV ~ 0 (fair value). Off-market forwards have non-zero NPV.
    /// NPV = notional * (implied_forward - contract_forward) * DF_for / spot
    /// But for rate-based solver usage: NPV = notional * (DF_dom - forward * DF_for / spot)
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let spot = fx_rates.rate(&self.pair);
        let df_dom = disc_curve.discount_factor(self.delivery);
        let df_for = forecast_curve.discount_factor(self.delivery);

        // Domestic leg: -notional * DF_dom (pay domestic)
        let domestic_pv = &df_dom * (-self.notional);
        // Foreign leg: notional * DF_dom (at implied forward rate, converted back)
        // The implied forward = spot * DF_dom / DF_for
        // Foreign amount = notional * forward, PV in foreign = notional * forward * DF_for
        // Convert to domestic: / spot = notional * DF_dom
        // So NPV = -notional*DF_dom + notional*DF_dom = 0 at market (correct).
        // For solver rate-matching, this is the value of the swap.
        let _foreign_pv = &(&spot * &df_for) * (self.notional);
        // Convert foreign PV to domestic: PV_for * (1/spot) = notional * DF_for
        // Wait, let me reconsider. The forward is worth:
        // Pay notional in domestic, receive notional*forward_rate in foreign at delivery.
        // NPV_dom_leg = -notional * DF_dom
        // NPV_for_leg = notional * F * DF_for / spot (convert foreign cashflow to domestic PV)
        // NPV = -notional * DF_dom + notional * F * DF_for / spot
        // where F = contract rate. At fair value: F = spot * DF_dom / DF_for => NPV = 0.
        // But for pricing, we don't have a contract rate -- we compute the implied forward.
        // NPV is essentially 0 at inception. For solver use, rate() is what matters.
        &domestic_pv + &(&df_for * self.notional)
    }

    /// Cashflow rows: one domestic, one foreign.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
        fx_rates: Option<&FXRates>,
    ) -> Vec<CashflowRow> {
        let mut rows = Vec::new();

        let (df_dom, df_for, fwd_rate) = match (disc_curve, forecast_curve, fx_rates) {
            (Some(dc), Some(fc), Some(fxr)) => {
                let df_d = dc.discount_factor(self.delivery);
                let df_f = fc.discount_factor(self.delivery);
                let fwd = self.rate(dc, fc, fxr);
                (Some(df_d), Some(df_f), Some(fwd))
            }
            _ => (None, None, None),
        };

        // Domestic leg: pay notional
        let dom_cf = -self.notional;
        let (dom_npv, dom_df) = match &df_dom {
            Some(d) => (Some(d * dom_cf), Some(d.clone())),
            None => (None, None),
        };
        rows.push(CashflowRow {
            period_type: "FXForward_Domestic".to_string(),
            start: self.delivery,
            end: self.delivery,
            payment: self.delivery,
            currency: self.pair.lhs.clone(),
            notional: self.notional,
            fixing_rate: None,
            rate: 0.0,
            spread: 0.0,
            dcf: 0.0,
            cashflow: Number::F64(dom_cf),
            df: dom_df,
            npv: dom_npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        });

        // Foreign leg: receive notional * forward
        let fwd_real = match &fwd_rate {
            Some(Number::F64(v)) => *v,
            Some(Number::Dual(d)) => d.real,
            Some(Number::Dual2(d)) => d.real,
            None => 0.0,
        };
        let for_cf = self.notional * fwd_real;
        let (for_npv, for_df) = match &df_for {
            Some(d) => (Some(d * for_cf), Some(d.clone())),
            None => (None, None),
        };
        rows.push(CashflowRow {
            period_type: "FXForward_Foreign".to_string(),
            start: self.delivery,
            end: self.delivery,
            payment: self.delivery,
            currency: self.pair.rhs.clone(),
            notional: self.notional * fwd_real,
            fixing_rate: fwd_rate,
            rate: fwd_real,
            spread: 0.0,
            dcf: 0.0,
            cashflow: Number::F64(for_cf),
            df: for_df,
            npv: for_npv,
        settlement_amount: None,
        fx_rate: None,
        settlement_currency_label: None,
        });

        rows
    }

    /// Spread: the difference between implied forward and some reference in basis points.
    pub fn spread(
        &self,
        _disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
        _fx_rates: &FXRates,
    ) -> Number {
        // For FXForward, spread is not well-defined in the same way as IRS.
        // Return 0.0 (at-market).
        Number::F64(0.0)
    }

    /// Pillar date: delivery date.
    pub fn pillar_date(&self) -> NaiveDate {
        self.delivery
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::calendar::convention::DayCountConvention;
    use indexmap::IndexMap;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn usd_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd".to_string())
    }

    fn eur_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
            (ymd(2026, 1, 1), 0.96),
        ]));
        DiscountCurve::new(nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "eur".to_string())
    }

    fn brl_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.88),
            (ymd(2026, 1, 1), 0.77),
        ]));
        DiscountCurve::new(nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "brl".to_string())
    }

    fn fx_rates() -> FXRates {
        FXRates::new(
            vec![(FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        )
    }

    fn fx_rates_usdbrl() -> FXRates {
        FXRates::new(
            vec![(FXPair::new("usd", "brl"), 5.0)],
            ymd(2024, 1, 15),
        )
    }

    pub fn make_test_fx_forward() -> FXForwardInstrument {
        FXForwardInstrument::new(
            FXPair::new("eur", "usd"),
            1_000_000.0,
            ymd(2025, 1, 1),
            "eur".to_string(),
        )
    }

    pub fn make_test_ndf() -> FXForwardInstrument {
        FXForwardInstrument::new_ndf(
            FXPair::new("usd", "brl"),
            1_000_000.0,
            ymd(2025, 1, 1),
            "usd".to_string(),
            "usd".to_string(),
            5.50,
            None,
            None,
        )
    }

    #[test]
    fn test_fx_forward_rate_irp() {
        let usd = usd_curve();
        let eur = eur_curve();
        let fxr = fx_rates();
        let fwd = make_test_fx_forward();

        // IRP: forward = spot * DF_dom / DF_for
        // disc_curve = EUR (domestic=lhs), forecast_curve = USD (foreign=rhs)
        let rate = fwd.rate(&eur, &usd, &fxr);
        let expected = 1.1 * 0.98 / 0.97; // spot * DF_eur / DF_usd

        match rate {
            Number::Dual(d) => {
                assert!(
                    (d.real - expected).abs() < 1e-8,
                    "Forward rate {:.6} should be ~{:.6}", d.real, expected
                );
            }
            Number::F64(v) => {
                assert!(
                    (v - expected).abs() < 1e-8,
                    "Forward rate {:.6} should be ~{:.6}", v, expected
                );
            }
            _ => panic!("Unexpected Number variant"),
        }
    }

    #[test]
    fn test_fx_forward_pillar_date() {
        let fwd = make_test_fx_forward();
        assert_eq!(fwd.pillar_date(), ymd(2025, 1, 1));
    }

    #[test]
    fn test_fx_forward_cashflows() {
        let usd = usd_curve();
        let eur = eur_curve();
        let fxr = fx_rates();
        let fwd = make_test_fx_forward();

        let rows = fwd.cashflows(Some(&eur), Some(&usd), Some(&fxr));
        assert_eq!(rows.len(), 2, "Should have 2 cashflow rows (domestic + foreign)");
        assert_eq!(rows[0].period_type, "FXForward_Domestic");
        assert_eq!(rows[1].period_type, "FXForward_Foreign");
    }

    // ---- NDF Tests ----

    #[test]
    fn test_ndf_construction() {
        let ndf = make_test_ndf();
        assert!(ndf.is_ndf());
        assert_eq!(ndf.settlement_currency, Some("usd".to_string()));
        assert_eq!(ndf.contracted_rate, Some(5.50));
        assert_eq!(ndf.fx_fixing, None);
        assert_eq!(ndf.leg2_fx_fixing, None);
        assert_eq!(ndf.pair.lhs, "usd");
        assert_eq!(ndf.pair.rhs, "brl");
    }

    #[test]
    fn test_ndf_rate_equals_fx_forward_rate() {
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = fx_rates_usdbrl();

        let ndf = make_test_ndf();
        let fwd = FXForwardInstrument::new(
            FXPair::new("usd", "brl"),
            1_000_000.0,
            ymd(2025, 1, 1),
            "usd".to_string(),
        );

        let ndf_rate = ndf.ndf_rate(&usd, &brl, &fxr);
        let fwd_rate = fwd.rate(&usd, &brl, &fxr);

        let ndf_real = match &ndf_rate {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let fwd_real = match &fwd_rate {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        assert!(
            (ndf_real - fwd_real).abs() < 1e-12,
            "NDF rate {:.8} should equal FXForward rate {:.8}",
            ndf_real, fwd_real
        );
    }

    #[test]
    fn test_ndf_npv_2ccy_lhs_settlement() {
        // USDBRL settled in USD (lhs)
        // contracted_rate = 5.50, notional = 1M USD
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = fx_rates_usdbrl();
        let ndf = make_test_ndf();

        let npv = ndf.ndf_npv(&usd, &brl, &fxr);
        let npv_val = match &npv {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // implied_forward = 5.0 * 0.97 / 0.88 = 5.511363636...
        // fixing_rate = implied_forward (no fx_fixing)
        // net_rhs = (5.511363636 - 5.50) * 1_000_000 = 11363.636...
        // net_lhs = net_rhs / fixing_rate = 11363.636... / 5.511363636... = 2061.855...
        // npv = net_lhs * DF_usd(delivery) = 2061.855... * 0.97 = 1999.999...
        assert!(npv_val.is_finite(), "NDF NPV should be finite");
        // The NPV should be positive (implied forward > contracted rate)
        let implied = 5.0 * 0.97 / 0.88;
        assert!(implied > 5.50, "Sanity check: implied forward should be > contracted");
        assert!(npv_val > 0.0, "NPV should be positive when implied > contracted, got {}", npv_val);
    }

    #[test]
    fn test_ndf_npv_with_fixing() {
        // USDBRL settled in USD, with fx_fixing = 5.42 (fixing below contracted)
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = fx_rates_usdbrl();
        let ndf = FXForwardInstrument::new_ndf(
            FXPair::new("usd", "brl"),
            1_000_000.0,
            ymd(2025, 1, 1),
            "usd".to_string(),
            "usd".to_string(),
            5.50,
            Some(5.42),
            None,
        );

        let npv = ndf.ndf_npv(&usd, &brl, &fxr);
        let npv_val = match &npv {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // fixing_rate = 5.42 (from fx_fixing, not implied)
        // net_rhs = (5.42 - 5.50) * 1_000_000 = -80_000
        // net_lhs = -80_000 / 5.42 = -14_760.147...
        // npv = -14_760.147... * 0.97 = -14_317.343...
        assert!(npv_val < 0.0, "NPV should be negative when fixing < contracted, got {}", npv_val);

        // Verify exact calculation
        let expected_net_rhs = (5.42 - 5.50) * 1_000_000.0;
        let expected_net_lhs = expected_net_rhs / 5.42;
        let expected_npv = expected_net_lhs * 0.97;
        assert!(
            (npv_val - expected_npv).abs() < 1.0, // within $1 tolerance
            "NPV {:.2} should be ~{:.2}", npv_val, expected_npv
        );
    }

    #[test]
    fn test_ndf_cashflows_2_rows() {
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = fx_rates_usdbrl();
        let ndf = make_test_ndf();

        let rows = ndf.ndf_cashflows(Some(&usd), Some(&brl), Some(&fxr));
        assert_eq!(rows.len(), 2, "NDF should have 2 cashflow rows");
        assert_eq!(rows[0].period_type, "NDF_Domestic");
        assert_eq!(rows[1].period_type, "NDF_Foreign");

        // Domestic: LHS currency (USD), notional = -1M
        assert_eq!(rows[0].currency, "usd");
        assert!((rows[0].notional - (-1_000_000.0)).abs() < 1e-6);

        // Foreign: RHS currency (BRL), notional = 1M * 5.50
        assert_eq!(rows[1].currency, "brl");
        assert!((rows[1].notional - (1_000_000.0 * 5.50)).abs() < 1e-6);

        // Foreign row should have fixing rate
        assert!(rows[1].fixing_rate.is_some());
    }

    #[test]
    fn test_ndf_spread_forward_points() {
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = fx_rates_usdbrl();
        let ndf = make_test_ndf();

        let spread = ndf.ndf_spread(&usd, &brl, &fxr);
        let spread_val = match &spread {
            Number::F64(v) => *v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // spread = contracted - implied = 5.50 - (5.0 * 0.97 / 0.88)
        let implied = 5.0 * 0.97 / 0.88;
        let expected = 5.50 - implied;
        assert!(
            (spread_val - expected).abs() < 1e-6,
            "Spread {:.6} should be ~{:.6}", spread_val, expected
        );
    }

    #[test]
    fn test_ndf_pillar_date() {
        let ndf = make_test_ndf();
        assert_eq!(ndf.pillar_date(), ymd(2025, 1, 1));
    }

    #[test]
    fn test_fx_forward_serde_backward_compat() {
        // Serialize an FXForward with no NDF fields, deserialize back
        let fwd = make_test_fx_forward();
        let json = serde_json::to_string(&fwd).unwrap();

        // Should deserialize successfully with NDF fields as None
        let restored: FXForwardInstrument = serde_json::from_str(&json).unwrap();
        assert_eq!(restored.settlement_currency, None);
        assert_eq!(restored.contracted_rate, None);
        assert_eq!(restored.fx_fixing, None);
        assert_eq!(restored.leg2_fx_fixing, None);
        assert_eq!(restored.pair.lhs, fwd.pair.lhs);
        assert_eq!(restored.pair.rhs, fwd.pair.rhs);
        assert_eq!(restored.delivery, fwd.delivery);

        // Also test that NDF fields roundtrip correctly
        let ndf = make_test_ndf();
        let ndf_json = serde_json::to_string(&ndf).unwrap();
        let ndf_restored: FXForwardInstrument = serde_json::from_str(&ndf_json).unwrap();
        assert_eq!(ndf_restored.settlement_currency, Some("usd".to_string()));
        assert_eq!(ndf_restored.contracted_rate, Some(5.50));
    }

    // Verify that plain FXForward is not NDF
    #[test]
    fn test_fx_forward_not_ndf() {
        let fwd = make_test_fx_forward();
        assert!(!fwd.is_ndf());
    }
}
