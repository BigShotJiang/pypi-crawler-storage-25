use chrono::{Days, NaiveDate};

use super::cal::BusinessCalendar;

/// Add a given number of business days to a date, skipping weekends and holidays.
///
/// If `days` is positive, step forward. If negative, step backward.
/// If `days` is zero and the date is a business day, return it unchanged.
/// If `days` is zero and the date is not a business day, roll forward.
pub fn add_business_days(date: NaiveDate, days: i32, cal: &BusinessCalendar) -> NaiveDate {
    if days == 0 {
        // Roll forward to nearest business day
        let mut d = date;
        while !cal.is_business_day(d) {
            d = d + Days::new(1);
        }
        return d;
    }

    let mut current = date;
    // First, if starting on a non-business day, roll to nearest business day in the direction of travel
    if !cal.is_business_day(current) {
        if days > 0 {
            while !cal.is_business_day(current) {
                current = current + Days::new(1);
            }
        } else {
            while !cal.is_business_day(current) {
                current = current - Days::new(1);
            }
        }
        // That roll counts as the first step (matching lag business days behavior)
        if days > 0 {
            return add_business_days_from_bd(current, days - 1, cal);
        } else {
            return add_business_days_from_bd(current, days + 1, cal);
        }
    }

    add_business_days_from_bd(current, days, cal)
}

/// Add business days starting from a known business day.
fn add_business_days_from_bd(date: NaiveDate, days: i32, cal: &BusinessCalendar) -> NaiveDate {
    let mut current = date;
    let mut remaining = days.abs();
    let step = if days >= 0 { Days::new(1) } else { Days::new(1) };

    while remaining > 0 {
        if days >= 0 {
            current = current + step;
        } else {
            current = current - step;
        }
        if cal.is_business_day(current) {
            remaining -= 1;
        }
    }
    current
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    #[test]
    fn test_add_business_days_forward() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        // Monday + 2 business days = Wednesday
        assert_eq!(add_business_days(ymd(2024, 1, 1), 2, &cal), ymd(2024, 1, 3));
    }

    #[test]
    fn test_add_business_days_over_weekend() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        // Friday + 1 business day = Monday
        assert_eq!(add_business_days(ymd(2024, 1, 5), 1, &cal), ymd(2024, 1, 8));
    }

    #[test]
    fn test_add_business_days_backward() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        // Wednesday - 2 business days = Monday
        assert_eq!(add_business_days(ymd(2024, 1, 3), -2, &cal), ymd(2024, 1, 1));
    }

    #[test]
    fn test_add_business_days_with_holiday() {
        let cal = BusinessCalendar::new_named("NYC").unwrap();
        // 2024-12-24 (Tue) + 1 business day = 2024-12-26 (Thu, skips Christmas Wed)
        assert_eq!(add_business_days(ymd(2024, 12, 24), 1, &cal), ymd(2024, 12, 26));
    }

    #[test]
    fn test_add_business_days_zero_on_business_day() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        assert_eq!(add_business_days(ymd(2024, 1, 3), 0, &cal), ymd(2024, 1, 3));
    }

    #[test]
    fn test_add_business_days_zero_on_weekend() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        // Saturday + 0 business days -> rolls forward to Monday
        assert_eq!(add_business_days(ymd(2024, 1, 6), 0, &cal), ymd(2024, 1, 8));
    }

    #[test]
    fn test_payment_lag_2_days() {
        let cal = BusinessCalendar::new_named("NYC").unwrap();
        // Payment lag of 2 business days from a Thursday
        let result = add_business_days(ymd(2024, 1, 4), 2, &cal);
        assert_eq!(result, ymd(2024, 1, 8)); // Skips weekend
    }
}
