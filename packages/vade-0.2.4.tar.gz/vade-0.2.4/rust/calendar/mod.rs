use pyo3::prelude::*;

pub mod cal;
pub mod named;
pub mod adjuster;
pub mod convention;
pub mod dateroll;
pub mod frequency;
pub mod py;
pub mod schedule;
pub mod tenor;

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    py::register_module(m)
}
