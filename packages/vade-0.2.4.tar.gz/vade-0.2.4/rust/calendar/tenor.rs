use chrono::{Days, NaiveDate};
use serde::{Serialize, Deserialize};

use super::cal::BusinessCalendar;
use super::dateroll::add_business_days;
use super::frequency::add_months;

/// A parsed tenor representing a time period.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum Tenor {
    Years(i32),
    Months(i32),
    Weeks(i32),
    Days(i32),
    BusinessDays(i32),
}

impl Tenor {
    /// Parse a tenor string like "2Y", "6M", "1W", "3D", "3B".
    ///
    /// Supported suffixes: Y (years), M (months), W (weeks), D (days), B (business days).
    pub fn parse(s: &str) -> Result<Self, String> {
        let s = s.trim().to_uppercase();
        if s.is_empty() {
            return Err("Empty tenor string".to_string());
        }

        let suffix = s.chars().last().unwrap();
        let num_str = &s[..s.len() - 1];
        let num: i32 = num_str
            .parse()
            .map_err(|_| format!("Invalid number in tenor: {}", num_str))?;

        match suffix {
            'Y' => Ok(Tenor::Years(num)),
            'M' => Ok(Tenor::Months(num)),
            'W' => Ok(Tenor::Weeks(num)),
            'D' => Ok(Tenor::Days(num)),
            'B' => Ok(Tenor::BusinessDays(num)),
            _ => Err(format!("Unknown tenor suffix: {}", suffix)),
        }
    }

    /// Add this tenor to a date. Business day tenors require a calendar.
    pub fn add_to(
        &self,
        date: NaiveDate,
        cal: Option<&BusinessCalendar>,
    ) -> Result<NaiveDate, String> {
        match self {
            Tenor::Years(n) => Ok(add_months(date, *n * 12)),
            Tenor::Months(n) => Ok(add_months(date, *n)),
            Tenor::Weeks(n) => {
                let total_days = *n * 7;
                if total_days >= 0 {
                    Ok(date + Days::new(total_days as u64))
                } else {
                    Ok(date - Days::new((-total_days) as u64))
                }
            }
            Tenor::Days(n) => {
                if *n >= 0 {
                    Ok(date + Days::new(*n as u64))
                } else {
                    Ok(date - Days::new((-*n) as u64))
                }
            }
            Tenor::BusinessDays(n) => {
                let cal = cal.ok_or("Business day tenor requires a calendar")?;
                Ok(add_business_days(date, *n, cal))
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    #[test]
    fn test_parse_years() {
        assert_eq!(Tenor::parse("2Y").unwrap(), Tenor::Years(2));
        assert_eq!(Tenor::parse("10y").unwrap(), Tenor::Years(10));
    }

    #[test]
    fn test_parse_months() {
        assert_eq!(Tenor::parse("6M").unwrap(), Tenor::Months(6));
    }

    #[test]
    fn test_parse_weeks() {
        assert_eq!(Tenor::parse("1W").unwrap(), Tenor::Weeks(1));
    }

    #[test]
    fn test_parse_days() {
        assert_eq!(Tenor::parse("30D").unwrap(), Tenor::Days(30));
    }

    #[test]
    fn test_parse_business_days() {
        assert_eq!(Tenor::parse("3B").unwrap(), Tenor::BusinessDays(3));
    }

    #[test]
    fn test_parse_invalid() {
        assert!(Tenor::parse("").is_err());
        assert!(Tenor::parse("X").is_err());
        assert!(Tenor::parse("2Z").is_err());
    }

    #[test]
    fn test_add_years() {
        let result = Tenor::Years(2).add_to(ymd(2024, 3, 15), None).unwrap();
        assert_eq!(result, ymd(2026, 3, 15));
    }

    #[test]
    fn test_add_months() {
        let result = Tenor::Months(6).add_to(ymd(2024, 3, 15), None).unwrap();
        assert_eq!(result, ymd(2024, 9, 15));
    }

    #[test]
    fn test_add_weeks() {
        let result = Tenor::Weeks(1).add_to(ymd(2024, 3, 15), None).unwrap();
        assert_eq!(result, ymd(2024, 3, 22));
    }

    #[test]
    fn test_add_days() {
        let result = Tenor::Days(30).add_to(ymd(2024, 3, 1), None).unwrap();
        assert_eq!(result, ymd(2024, 3, 31));
    }

    #[test]
    fn test_add_business_days() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let result = Tenor::BusinessDays(3)
            .add_to(ymd(2024, 1, 3), Some(&cal))
            .unwrap();
        // Wed + 3 business days = Mon (Thu, Fri, skip weekend, Mon)
        assert_eq!(result, ymd(2024, 1, 8));
    }

    #[test]
    fn test_add_business_days_requires_calendar() {
        let result = Tenor::BusinessDays(3).add_to(ymd(2024, 1, 1), None);
        assert!(result.is_err());
    }

    #[test]
    fn test_add_years_eom() {
        // Feb 29 leap year + 1 year = Feb 28 non-leap
        let result = Tenor::Years(1).add_to(ymd(2024, 2, 29), None).unwrap();
        assert_eq!(result, ymd(2025, 2, 28));
    }
}
