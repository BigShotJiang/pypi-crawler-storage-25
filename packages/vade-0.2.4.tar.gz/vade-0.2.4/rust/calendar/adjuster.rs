use chrono::{Datelike, Days, NaiveDate};
use serde::{Serialize, Deserialize};

use super::cal::BusinessCalendar;

/// Business day adjustment rules.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum Adjuster {
    /// No adjustment -- return the date as-is.
    Actual,
    /// Roll forward to the next business day.
    Following,
    /// Roll forward, but if the result crosses a month boundary, roll backward instead.
    ModifiedFollowing,
    /// Roll backward to the previous business day.
    Preceding,
    /// Roll backward, but if the result crosses a month boundary, roll forward instead.
    ModifiedPreceding,
}

impl Adjuster {
    /// Adjust a date according to the adjustment rule and calendar.
    pub fn adjust(&self, date: NaiveDate, cal: &BusinessCalendar) -> NaiveDate {
        match self {
            Adjuster::Actual => date,
            Adjuster::Following => roll_forward(date, cal),
            Adjuster::ModifiedFollowing => {
                let rolled = roll_forward(date, cal);
                if rolled.month() != date.month() {
                    roll_backward(date, cal)
                } else {
                    rolled
                }
            }
            Adjuster::Preceding => roll_backward(date, cal),
            Adjuster::ModifiedPreceding => {
                let rolled = roll_backward(date, cal);
                if rolled.month() != date.month() {
                    roll_forward(date, cal)
                } else {
                    rolled
                }
            }
        }
    }
}

/// Roll forward to the next business day (or return date if already a business day).
fn roll_forward(date: NaiveDate, cal: &BusinessCalendar) -> NaiveDate {
    let mut d = date;
    while !cal.is_business_day(d) {
        d = d + Days::new(1);
    }
    d
}

/// Roll backward to the previous business day (or return date if already a business day).
fn roll_backward(date: NaiveDate, cal: &BusinessCalendar) -> NaiveDate {
    let mut d = date;
    while !cal.is_business_day(d) {
        d = d - Days::new(1);
    }
    d
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn nyc_cal() -> BusinessCalendar {
        BusinessCalendar::new_named("NYC").unwrap()
    }

    #[test]
    fn test_actual_no_adjustment() {
        let cal = nyc_cal();
        // Christmas is a holiday but Actual returns it unchanged
        assert_eq!(Adjuster::Actual.adjust(ymd(2024, 12, 25), &cal), ymd(2024, 12, 25));
    }

    #[test]
    fn test_following_holiday() {
        let cal = nyc_cal();
        // 2024-12-25 (Wed, holiday) -> 2024-12-26 (Thu)
        assert_eq!(
            Adjuster::Following.adjust(ymd(2024, 12, 25), &cal),
            ymd(2024, 12, 26)
        );
    }

    #[test]
    fn test_following_already_business_day() {
        let cal = nyc_cal();
        assert_eq!(
            Adjuster::Following.adjust(ymd(2024, 12, 24), &cal),
            ymd(2024, 12, 24)
        );
    }

    #[test]
    fn test_modified_following_stays_in_month() {
        // 2024-08-31 is Saturday. Following would go to Sep 2 (Monday).
        // ModifiedFollowing stays in August -> rolls back to Aug 30 (Friday).
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        assert_eq!(
            Adjuster::ModifiedFollowing.adjust(ymd(2024, 8, 31), &cal),
            ymd(2024, 8, 30)
        );
    }

    #[test]
    fn test_modified_following_no_month_cross() {
        let cal = nyc_cal();
        // 2024-12-25 (Wed) -> Following goes to 12-26, still in December
        assert_eq!(
            Adjuster::ModifiedFollowing.adjust(ymd(2024, 12, 25), &cal),
            ymd(2024, 12, 26)
        );
    }

    #[test]
    fn test_preceding_holiday() {
        let cal = nyc_cal();
        // 2024-12-25 (Wed, holiday) -> 2024-12-24 (Tue)
        assert_eq!(
            Adjuster::Preceding.adjust(ymd(2024, 12, 25), &cal),
            ymd(2024, 12, 24)
        );
    }

    #[test]
    fn test_modified_preceding_stays_in_month() {
        // 2024-09-01 is Sunday. Preceding would go to Aug 30 (Friday).
        // ModifiedPreceding stays in September -> rolls forward to Sep 2 (Monday).
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        assert_eq!(
            Adjuster::ModifiedPreceding.adjust(ymd(2024, 9, 1), &cal),
            ymd(2024, 9, 2)
        );
    }

    #[test]
    fn test_following_weekend() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        // Saturday Dec 28 -> Monday Dec 30
        assert_eq!(
            Adjuster::Following.adjust(ymd(2024, 12, 28), &cal),
            ymd(2024, 12, 30)
        );
    }

    #[test]
    fn test_preceding_weekend() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        // Sunday Dec 29 -> Friday Dec 27
        assert_eq!(
            Adjuster::Preceding.adjust(ymd(2024, 12, 29), &cal),
            ymd(2024, 12, 27)
        );
    }
}
