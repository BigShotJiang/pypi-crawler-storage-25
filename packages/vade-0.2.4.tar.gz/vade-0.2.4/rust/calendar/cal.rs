use chrono::{Datelike, NaiveDate};
use serde::{Serialize, Deserialize};
use std::collections::HashSet;

use super::named;

/// A business day calendar containing holidays and a weekend bitmask.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BusinessCalendar {
    /// Set of specific holiday dates (non-business days).
    pub holidays: HashSet<NaiveDate>,
    /// Bitmask of weekend days: bit `i` set means day `i` is a weekend
    /// (0=Mon, 6=Sun, matching chrono `Weekday::num_days_from_monday()`).
    pub weekmask: u8,
}

/// Convert a slice of weekend day numbers (0=Mon … 6=Sun) to a bitmask.
#[inline]
fn weekmask_from_slice(days: &[u8]) -> u8 {
    let mut mask = 0u8;
    for &d in days {
        mask |= 1 << d;
    }
    mask
}

impl BusinessCalendar {
    /// Create a calendar from a named market identifier.
    ///
    /// Supported names: NYC, LDN, TGT, TYO, SYD, ZUR, STK, OSL, TRO, FED, WLG, MUM, MEX, BJS, NSW, SAO, SEL, TAI, MNL, JAK
    pub fn new_named(name: &str) -> Result<Self, String> {
        let (holidays_strs, weekmask) = match name.to_uppercase().as_str() {
            "NYC" => (named::nyc::HOLIDAYS, named::nyc::WEEKMASK),
            "LDN" => (named::ldn::HOLIDAYS, named::ldn::WEEKMASK),
            "TGT" => (named::tgt::HOLIDAYS, named::tgt::WEEKMASK),
            "TYO" => (named::tyo::HOLIDAYS, named::tyo::WEEKMASK),
            "SYD" => (named::syd::HOLIDAYS, named::syd::WEEKMASK),
            "ZUR" => (named::zur::HOLIDAYS, named::zur::WEEKMASK),
            "STK" => (named::stk::HOLIDAYS, named::stk::WEEKMASK),
            "OSL" => (named::osl::HOLIDAYS, named::osl::WEEKMASK),
            "TRO" => (named::tro::HOLIDAYS, named::tro::WEEKMASK),
            "FED" => (named::fed::HOLIDAYS, named::fed::WEEKMASK),
            "WLG" => (named::wlg::HOLIDAYS, named::wlg::WEEKMASK),
            "MUM" => (named::mum::HOLIDAYS, named::mum::WEEKMASK),
            "MEX" => (named::mex::HOLIDAYS, named::mex::WEEKMASK),
            "BJS" => (named::bjs::HOLIDAYS, named::bjs::WEEKMASK),
            "NSW" => (named::nsw::HOLIDAYS, named::nsw::WEEKMASK),
            "SAO" => (named::sao::HOLIDAYS, named::sao::WEEKMASK),
            "SEL" => (named::sel::HOLIDAYS, named::sel::WEEKMASK),
            "TAI" => (named::tai::HOLIDAYS, named::tai::WEEKMASK),
            "MNL" => (named::mnl::HOLIDAYS, named::mnl::WEEKMASK),
            "JAK" => (named::jak::HOLIDAYS, named::jak::WEEKMASK),
            _ => return Err(format!("Unknown calendar name: {}", name)),
        };

        let holidays: HashSet<NaiveDate> = holidays_strs
            .iter()
            .map(|s| NaiveDate::parse_from_str(s, "%Y-%m-%d").expect("Invalid holiday date"))
            .collect();

        Ok(BusinessCalendar {
            holidays,
            weekmask: weekmask_from_slice(weekmask),
        })
    }

    /// Create a custom calendar with arbitrary holidays and weekend mask.
    ///
    /// `weekmask` is a list of weekend day numbers (0=Mon … 6=Sun),
    /// converted internally to a bitmask.
    pub fn new_custom(holidays: Vec<NaiveDate>, weekmask: Vec<u8>) -> Self {
        BusinessCalendar {
            holidays: holidays.into_iter().collect(),
            weekmask: weekmask_from_slice(&weekmask),
        }
    }

    /// Returns true if the date is a specific holiday.
    pub fn is_holiday(&self, date: NaiveDate) -> bool {
        self.holidays.contains(&date)
    }

    /// Returns true if the date falls on a weekend day (per weekmask).
    #[inline]
    pub fn is_weekend(&self, date: NaiveDate) -> bool {
        let dow = date.weekday().num_days_from_monday();
        (self.weekmask >> dow) & 1 == 1
    }

    /// Returns true if the date is a business day (not a holiday and not a weekend).
    pub fn is_business_day(&self, date: NaiveDate) -> bool {
        !self.is_holiday(date) && !self.is_weekend(date)
    }

    /// Create a union calendar: any holiday from either calendar is a holiday.
    /// Weekend mask is the union of both masks.
    pub fn union(a: &Self, b: &Self) -> Self {
        let holidays: HashSet<NaiveDate> = a.holidays.union(&b.holidays).cloned().collect();
        BusinessCalendar { holidays, weekmask: a.weekmask | b.weekmask }
    }

    /// Create an intersection calendar: only shared holidays are holidays.
    /// Weekend mask is the intersection of both masks.
    pub fn intersection(a: &Self, b: &Self) -> Self {
        let holidays: HashSet<NaiveDate> =
            a.holidays.intersection(&b.holidays).cloned().collect();
        BusinessCalendar { holidays, weekmask: a.weekmask & b.weekmask }
    }

    /// Count business days between start (inclusive) and end (exclusive).
    pub fn bus_day_count(&self, start: NaiveDate, end: NaiveDate) -> i32 {
        if start >= end {
            return 0;
        }
        let mut count = 0i32;
        let mut d = start;
        while d < end {
            if self.is_business_day(d) {
                count += 1;
            }
            d = d.succ_opt().expect("date overflow");
        }
        count
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    #[test]
    fn test_new_named_nyc() {
        let cal = BusinessCalendar::new_named("NYC").unwrap();
        // Christmas 2024 is a holiday
        assert!(cal.is_holiday(ymd(2024, 12, 25)));
        // Christmas Eve 2024 (Tuesday) is not a holiday
        assert!(!cal.is_holiday(ymd(2024, 12, 24)));
    }

    #[test]
    fn test_is_business_day_holiday() {
        let cal = BusinessCalendar::new_named("NYC").unwrap();
        // Christmas 2024 (Wednesday) - holiday, not a business day
        assert!(!cal.is_business_day(ymd(2024, 12, 25)));
    }

    #[test]
    fn test_is_business_day_weekday() {
        let cal = BusinessCalendar::new_named("NYC").unwrap();
        // Dec 24, 2024 (Tuesday) - not a holiday, is a business day
        assert!(cal.is_business_day(ymd(2024, 12, 24)));
    }

    #[test]
    fn test_is_business_day_weekend() {
        let cal = BusinessCalendar::new_named("NYC").unwrap();
        // Dec 28, 2024 (Saturday) - weekend
        assert!(!cal.is_business_day(ymd(2024, 12, 28)));
    }

    #[test]
    fn test_new_named_unknown() {
        assert!(BusinessCalendar::new_named("INVALID").is_err());
    }

    #[test]
    fn test_union() {
        let nyc = BusinessCalendar::new_named("NYC").unwrap();
        let ldn = BusinessCalendar::new_named("LDN").unwrap();
        let combined = BusinessCalendar::union(&nyc, &ldn);

        // NYC-specific holiday: Veterans Day 2024 (Nov 11)
        assert!(combined.is_holiday(ymd(2024, 11, 11)));
        // LDN-specific holiday: August Bank Holiday 2024 (Aug 26)
        assert!(combined.is_holiday(ymd(2024, 8, 26)));
    }

    #[test]
    fn test_intersection() {
        let nyc = BusinessCalendar::new_named("NYC").unwrap();
        let ldn = BusinessCalendar::new_named("LDN").unwrap();
        let combined = BusinessCalendar::intersection(&nyc, &ldn);

        // Christmas 2024 is a holiday in both
        assert!(combined.is_holiday(ymd(2024, 12, 25)));
        // Veterans Day is NYC only - not in intersection
        assert!(!combined.is_holiday(ymd(2024, 11, 11)));
    }

    #[test]
    fn test_custom_calendar() {
        let holidays = vec![ymd(2024, 1, 1), ymd(2024, 12, 25)];
        let cal = BusinessCalendar::new_custom(holidays, vec![5, 6]);
        assert!(cal.is_holiday(ymd(2024, 1, 1)));
        assert!(!cal.is_holiday(ymd(2024, 1, 2)));
        assert!(cal.is_business_day(ymd(2024, 1, 2))); // Tuesday
    }

    #[test]
    fn test_bus_day_count() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        // Mon Jan 1 to Fri Jan 5 = 4 business days (Mon, Tue, Wed, Thu)
        assert_eq!(cal.bus_day_count(ymd(2024, 1, 1), ymd(2024, 1, 5)), 4);
        // Full week Mon-Mon = 5 business days
        assert_eq!(cal.bus_day_count(ymd(2024, 1, 1), ymd(2024, 1, 8)), 5);
    }

    #[test]
    fn test_all_named_calendars_load() {
        let names = [
            "NYC", "LDN", "TGT", "TYO", "SYD", "ZUR", "STK", "OSL", "TRO", "FED", "WLG",
            "MUM", "MEX", "BJS", "NSW", "SAO", "SEL", "TAI", "MNL", "JAK",
        ];
        for name in &names {
            let cal = BusinessCalendar::new_named(name);
            assert!(cal.is_ok(), "Failed to load calendar: {}", name);
        }
    }

    // Verify specific known holidays per market
    #[test]
    fn test_ldn_holiday() {
        let cal = BusinessCalendar::new_named("LDN").unwrap();
        assert!(cal.is_holiday(ymd(2024, 8, 26))); // August Bank Holiday
    }

    #[test]
    fn test_tgt_holiday() {
        let cal = BusinessCalendar::new_named("TGT").unwrap();
        assert!(cal.is_holiday(ymd(2024, 5, 1))); // Labour Day
    }

    #[test]
    fn test_tyo_holiday() {
        let cal = BusinessCalendar::new_named("TYO").unwrap();
        assert!(cal.is_holiday(ymd(2024, 1, 3))); // Bank Holiday
    }

    #[test]
    fn test_fed_holiday() {
        let cal = BusinessCalendar::new_named("FED").unwrap();
        assert!(cal.is_holiday(ymd(2024, 11, 11))); // Veterans Day
    }

    #[test]
    fn test_syd_holiday() {
        let cal = BusinessCalendar::new_named("SYD").unwrap();
        assert!(cal.is_holiday(ymd(2022, 9, 22))); // National Day of Mourning
    }

    #[test]
    fn test_wlg_holiday() {
        let cal = BusinessCalendar::new_named("WLG").unwrap();
        assert!(cal.is_holiday(ymd(2034, 7, 7))); // Matariki
    }

    #[test]
    fn test_mum_holiday() {
        let cal = BusinessCalendar::new_named("MUM").unwrap();
        assert!(cal.is_holiday(ymd(2025, 1, 26))); // Republic Day
    }

    #[test]
    fn test_stk_holiday() {
        let cal = BusinessCalendar::new_named("STK").unwrap();
        assert!(cal.is_holiday(ymd(2024, 6, 6))); // National Day
    }

    #[test]
    fn test_osl_holiday() {
        let cal = BusinessCalendar::new_named("OSL").unwrap();
        assert!(cal.is_holiday(ymd(2024, 5, 17))); // Constitution Day
    }

    #[test]
    fn test_zur_holiday() {
        let cal = BusinessCalendar::new_named("ZUR").unwrap();
        assert!(cal.is_holiday(ymd(2024, 8, 1))); // Swiss National Day
    }

    #[test]
    fn test_tro_holiday() {
        let cal = BusinessCalendar::new_named("TRO").unwrap();
        assert!(cal.is_holiday(ymd(2024, 9, 30))); // Reconciliation Day
    }

    #[test]
    fn test_sao_holiday() {
        let cal = BusinessCalendar::new_named("SAO").unwrap();
        assert!(cal.is_holiday(ymd(2024, 2, 13))); // Carnival Tuesday
        assert!(cal.is_holiday(ymd(2024, 3, 29))); // Good Friday
        assert!(cal.is_holiday(ymd(2024, 11, 15))); // Republic Day
    }

    #[test]
    fn test_sel_holiday() {
        let cal = BusinessCalendar::new_named("SEL").unwrap();
        assert!(cal.is_holiday(ymd(2024, 2, 9))); // Lunar New Year (eve)
        assert!(cal.is_holiday(ymd(2024, 3, 1))); // Independence Movement Day
        assert!(cal.is_holiday(ymd(2024, 10, 3))); // National Foundation Day
    }

    #[test]
    fn test_tai_holiday() {
        let cal = BusinessCalendar::new_named("TAI").unwrap();
        assert!(cal.is_holiday(ymd(2024, 2, 28))); // Peace Memorial Day
        assert!(cal.is_holiday(ymd(2024, 10, 10))); // National Day
        assert!(cal.is_holiday(ymd(2024, 6, 10))); // Dragon Boat Festival
    }

    #[test]
    fn test_mnl_holiday() {
        let cal = BusinessCalendar::new_named("MNL").unwrap();
        assert!(cal.is_holiday(ymd(2024, 6, 12))); // Independence Day
        assert!(cal.is_holiday(ymd(2024, 12, 25))); // Christmas
        assert!(cal.is_holiday(ymd(2024, 12, 30))); // Rizal Day
    }

    #[test]
    fn test_jak_holiday() {
        let cal = BusinessCalendar::new_named("JAK").unwrap();
        assert!(cal.is_holiday(ymd(2023, 8, 17))); // Independence Day
        assert!(cal.is_holiday(ymd(2024, 12, 25))); // Christmas
        assert!(cal.is_holiday(ymd(2024, 5, 1))); // Labour Day
    }

    #[test]
    fn test_bjs_no_standard_weekmask() {
        let cal = BusinessCalendar::new_named("BJS").unwrap();
        // BJS has no standard weekmask (0) - weekends are encoded as holidays
        assert_eq!(cal.weekmask, 0);
    }
}
