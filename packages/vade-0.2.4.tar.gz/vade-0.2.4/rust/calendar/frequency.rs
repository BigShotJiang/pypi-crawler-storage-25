use chrono::{Datelike, NaiveDate};
use serde::{Serialize, Deserialize};

/// Frequency for periodic schedules.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum Frequency {
    Monthly,
    Quarterly,
    SemiAnnual,
    Annual,
    ZeroCoupon,
}

impl Frequency {
    /// Number of months per period.
    pub fn months(&self) -> u32 {
        match self {
            Frequency::Monthly => 1,
            Frequency::Quarterly => 3,
            Frequency::SemiAnnual => 6,
            Frequency::Annual => 12,
            Frequency::ZeroCoupon => 0,
        }
    }

    /// Periods per year (for ActActICMA and similar).
    pub fn periods_per_annum(&self) -> f64 {
        match self {
            Frequency::Monthly => 12.0,
            Frequency::Quarterly => 4.0,
            Frequency::SemiAnnual => 2.0,
            Frequency::Annual => 1.0,
            Frequency::ZeroCoupon => 1.0,
        }
    }
}

/// Roll day specification for determining period end dates.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum RollDay {
    /// A specific day of the month (1-31). If the month has fewer days, use the last day.
    Day(u32),
    /// End of month: always roll to the last day of the target month.
    Eom,
    /// IMM date: the third Wednesday of the month.
    Imm,
}

impl RollDay {
    /// Compute the date in a given year/month that matches this roll day.
    pub fn date_in_month(&self, year: i32, month: u32) -> NaiveDate {
        match self {
            RollDay::Day(d) => {
                let last = last_day_of_month(year, month);
                let day = (*d).min(last);
                NaiveDate::from_ymd_opt(year, month, day).unwrap()
            }
            RollDay::Eom => {
                let last = last_day_of_month(year, month);
                NaiveDate::from_ymd_opt(year, month, last).unwrap()
            }
            RollDay::Imm => imm_date(year, month),
        }
    }
}

/// Get the last day of a given month.
pub fn last_day_of_month(year: i32, month: u32) -> u32 {
    if month == 12 {
        31
    } else {
        NaiveDate::from_ymd_opt(year, month + 1, 1)
            .unwrap()
            .pred_opt()
            .unwrap()
            .day()
    }
}

/// Get the IMM date (3rd Wednesday) for a given year and month.
pub fn imm_date(year: i32, month: u32) -> NaiveDate {
    let first = NaiveDate::from_ymd_opt(year, month, 1).unwrap();
    let first_weekday = first.weekday().num_days_from_monday(); // 0=Mon, 2=Wed
    // Days until first Wednesday
    let days_to_wed = (2 + 7 - first_weekday) % 7;
    // Third Wednesday = first Wednesday + 14
    let imm_day = 1 + days_to_wed + 14;
    NaiveDate::from_ymd_opt(year, month, imm_day).unwrap()
}

/// Return the most recent 20th of Mar/Jun/Sep/Dec on or before the given date.
///
/// Implements QuantLib's `previousTwentieth` for CDS2015.
/// If the date is exactly on a CDS IMM 20th, returns that date.
pub fn previous_imm_cds_date(date: NaiveDate) -> NaiveDate {
    let mut result = NaiveDate::from_ymd_opt(date.year(), date.month(), 20).unwrap();
    if result > date {
        result = add_months(result, -1);
        result = NaiveDate::from_ymd_opt(result.year(), result.month(), 20).unwrap();
    }
    let m = result.month();
    if m % 3 != 0 {
        let skip = m % 3;
        result = add_months(result, -(skip as i32));
        result = NaiveDate::from_ymd_opt(result.year(), result.month(), 20).unwrap();
    }
    result
}

/// Return the next 20th of Mar/Jun/Sep/Dec on or after the given date.
///
/// Implements QuantLib's `nextTwentieth` for CDS2015.
/// If the date is exactly on a CDS IMM 20th, returns that date.
pub fn next_imm_cds_date(date: NaiveDate) -> NaiveDate {
    let mut result = NaiveDate::from_ymd_opt(date.year(), date.month(), 20).unwrap();
    if result < date {
        result = add_months(result, 1);
        result = NaiveDate::from_ymd_opt(result.year(), result.month(), 20).unwrap();
    }
    let m = result.month();
    if m % 3 != 0 {
        let skip = 3 - (m % 3);
        result = add_months(result, skip as i32);
        result = NaiveDate::from_ymd_opt(result.year(), result.month(), 20).unwrap();
    }
    result
}

/// Compute the CDS maturity date from a trade date and tenor in months.
///
/// Implements QuantLib's CDS2015 `cdsMaturity` algorithm:
/// 1. Find anchor = previous_imm_cds_date(trade_date)
/// 2. If anchor is on Jun 20 or Dec 20 and tenor > 0, shift anchor back 3 months
///    (semi-annual roll adjustment)
/// 3. Maturity = anchor + (tenor + 3) months, pinned to 20th
pub fn cds_maturity(trade_date: NaiveDate, tenor_months: i32) -> NaiveDate {
    let mut anchor = previous_imm_cds_date(trade_date);
    let anchor_month = anchor.month();
    // CDS2015 semi-annual roll: if anchor is Jun 20 or Dec 20, go back 3M
    if (anchor_month == 6 || anchor_month == 12) && tenor_months > 0 {
        anchor = add_months(anchor, -3);
        anchor = NaiveDate::from_ymd_opt(anchor.year(), anchor.month(), 20).unwrap();
    }
    let maturity = add_months(anchor, tenor_months + 3);
    NaiveDate::from_ymd_opt(maturity.year(), maturity.month(), 20).unwrap()
}

/// Advance a date by a given number of months with roll day handling.
pub fn add_months(date: NaiveDate, months: i32) -> NaiveDate {
    let total_months = date.year() * 12 + date.month() as i32 - 1 + months;
    let new_year = total_months.div_euclid(12);
    let new_month = (total_months.rem_euclid(12) + 1) as u32;
    let last = last_day_of_month(new_year, new_month);
    let day = date.day().min(last);
    NaiveDate::from_ymd_opt(new_year, new_month, day).unwrap()
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    #[test]
    fn test_frequency_months() {
        assert_eq!(Frequency::Monthly.months(), 1);
        assert_eq!(Frequency::Quarterly.months(), 3);
        assert_eq!(Frequency::SemiAnnual.months(), 6);
        assert_eq!(Frequency::Annual.months(), 12);
    }

    #[test]
    fn test_roll_day_specific() {
        assert_eq!(RollDay::Day(15).date_in_month(2024, 3), ymd(2024, 3, 15));
        // Feb 30 clamped to Feb 29 in leap year
        assert_eq!(RollDay::Day(30).date_in_month(2024, 2), ymd(2024, 2, 29));
        // Feb 30 clamped to Feb 28 in non-leap year
        assert_eq!(RollDay::Day(30).date_in_month(2025, 2), ymd(2025, 2, 28));
    }

    #[test]
    fn test_roll_day_eom() {
        assert_eq!(RollDay::Eom.date_in_month(2024, 2), ymd(2024, 2, 29));
        assert_eq!(RollDay::Eom.date_in_month(2025, 2), ymd(2025, 2, 28));
        assert_eq!(RollDay::Eom.date_in_month(2024, 12), ymd(2024, 12, 31));
    }

    #[test]
    fn test_roll_day_imm() {
        // Jan 2024: 1st is Monday. 1st Wed = Jan 3. 3rd Wed = Jan 17.
        assert_eq!(RollDay::Imm.date_in_month(2024, 1), ymd(2024, 1, 17));
        // Mar 2024: 1st is Friday. 1st Wed = Mar 6. 3rd Wed = Mar 20.
        assert_eq!(RollDay::Imm.date_in_month(2024, 3), ymd(2024, 3, 20));
    }

    #[test]
    fn test_add_months_simple() {
        assert_eq!(add_months(ymd(2024, 1, 15), 3), ymd(2024, 4, 15));
        assert_eq!(add_months(ymd(2024, 1, 15), 12), ymd(2025, 1, 15));
    }

    #[test]
    fn test_add_months_eom_clamping() {
        // Jan 31 + 1 month = Feb 29 (2024 is leap year)
        assert_eq!(add_months(ymd(2024, 1, 31), 1), ymd(2024, 2, 29));
        // Jan 31 + 1 month = Feb 28 (2025 not leap)
        assert_eq!(add_months(ymd(2025, 1, 31), 1), ymd(2025, 2, 28));
    }

    #[test]
    fn test_add_months_negative() {
        assert_eq!(add_months(ymd(2024, 3, 15), -1), ymd(2024, 2, 15));
        assert_eq!(add_months(ymd(2024, 1, 15), -2), ymd(2023, 11, 15));
    }

    #[test]
    fn test_imm_date() {
        // June 2024: 1st is Saturday. 1st Wed = June 5. 3rd Wed = June 19.
        assert_eq!(imm_date(2024, 6), ymd(2024, 6, 19));
    }

    // --- CDS IMM date helper tests (QuantLib CDS2015 test vectors) ---

    #[test]
    fn test_previous_imm_cds_date_before_20th() {
        // Before 20th of IMM month -> goes back to previous IMM quarter 20th
        assert_eq!(previous_imm_cds_date(ymd(2016, 3, 19)), ymd(2015, 12, 20));
    }

    #[test]
    fn test_previous_imm_cds_date_on_20th() {
        // On IMM 20th -> returns itself
        assert_eq!(previous_imm_cds_date(ymd(2016, 3, 20)), ymd(2016, 3, 20));
    }

    #[test]
    fn test_previous_imm_cds_date_after_20th() {
        // After 20th of IMM month -> returns that month's 20th
        assert_eq!(previous_imm_cds_date(ymd(2016, 3, 21)), ymd(2016, 3, 20));
    }

    #[test]
    fn test_previous_imm_cds_date_non_quarter_month() {
        // Non-quarter month -> skips back to nearest IMM quarter month
        assert_eq!(previous_imm_cds_date(ymd(2016, 4, 15)), ymd(2016, 3, 20));
    }

    #[test]
    fn test_previous_imm_cds_date_jun_dec() {
        assert_eq!(previous_imm_cds_date(ymd(2016, 6, 20)), ymd(2016, 6, 20));
        assert_eq!(previous_imm_cds_date(ymd(2016, 12, 20)), ymd(2016, 12, 20));
    }

    #[test]
    fn test_next_imm_cds_date_before_20th() {
        assert_eq!(next_imm_cds_date(ymd(2016, 3, 19)), ymd(2016, 3, 20));
    }

    #[test]
    fn test_next_imm_cds_date_on_20th() {
        assert_eq!(next_imm_cds_date(ymd(2016, 3, 20)), ymd(2016, 3, 20));
    }

    #[test]
    fn test_next_imm_cds_date_after_20th() {
        assert_eq!(next_imm_cds_date(ymd(2016, 3, 21)), ymd(2016, 6, 20));
    }

    #[test]
    fn test_next_imm_cds_date_non_quarter_month() {
        assert_eq!(next_imm_cds_date(ymd(2016, 4, 15)), ymd(2016, 6, 20));
    }

    // --- cds_maturity tests (QuantLib CDS2015 with semi-annual roll) ---

    #[test]
    fn test_cds_maturity_before_mar_20() {
        // trade 2016-03-19, 5Y: anchor=Dec 20 2015 (Jun/Dec -> shift back 3M to Sep 20 2015), +63M = 2020-12-20
        assert_eq!(cds_maturity(ymd(2016, 3, 19), 60), ymd(2020, 12, 20));
    }

    #[test]
    fn test_cds_maturity_on_mar_20() {
        // trade 2016-03-20, 5Y: anchor=Mar 20 2016 (not Jun/Dec, no adjust), +63M = 2021-06-20
        assert_eq!(cds_maturity(ymd(2016, 3, 20), 60), ymd(2021, 6, 20));
    }

    #[test]
    fn test_cds_maturity_on_jun_20() {
        // trade 2016-06-20, 5Y: anchor=Jun 20 2016 (Jun -> shift back 3M to Mar 20 2016), +63M = 2021-06-20
        assert_eq!(cds_maturity(ymd(2016, 6, 20), 60), ymd(2021, 6, 20));
    }

    #[test]
    fn test_cds_maturity_on_sep_20() {
        // trade 2016-09-20, 5Y: anchor=Sep 20 2016 (not Jun/Dec, no adjust), +63M = 2021-12-20
        assert_eq!(cds_maturity(ymd(2016, 9, 20), 60), ymd(2021, 12, 20));
    }

    #[test]
    fn test_cds_maturity_before_dec_20() {
        // trade 2016-12-12, 5Y: anchor=Sep 20 2016 (not Jun/Dec, no adjust), +63M = 2021-12-20
        assert_eq!(cds_maturity(ymd(2016, 12, 12), 60), ymd(2021, 12, 20));
    }

    #[test]
    fn test_cds_maturity_on_dec_20() {
        // trade 2016-12-20, 5Y: anchor=Dec 20 2016 (Dec -> shift back 3M to Sep 20 2016), +63M = 2021-12-20
        assert_eq!(cds_maturity(ymd(2016, 12, 20), 60), ymd(2021, 12, 20));
    }
}
