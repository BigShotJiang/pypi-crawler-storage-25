xKanaele

A modern, flexible TCP/IP communication module for Python. This repository provides a client and a server implementation with a robust protocol supporting multiple data types and timeouts. The package is designed to be installed via PyPI.

Installation
- Ensure Python 3.8+ is installed.
- Build the distribution: python -m build
- Publish to PyPI (optional, requires credentials): twine upload dist/*

Usage (example)
- Lightweight example showing client-server interaction with a simple string payload.
- See the source code in xKanaele/xKanaele.py and xKanaele/xKanaeleServer.py for details.

Contributing
- Follow the project conventions in the modules.
- Add tests and ensure compatibility with school usage.
