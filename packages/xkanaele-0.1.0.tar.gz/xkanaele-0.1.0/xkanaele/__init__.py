"""xKanaele PyPI compatible shim.

This lightweight wrapper loads the existing, capitalized modules
from the repository and exposes frontend-compatible API:
- xKanaele class
- xKanaeleServer class
"""
import importlib.util
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]  # project root/xKanaele
SERVER_PATH = BASE / 'xKanaele' / 'xKanaeleServer.py'
CLIENT_PATH = BASE / 'xKanaele' / 'xKanaele.py'

def _load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

_client = _load_module('xkanaele_client', CLIENT_PATH)
_server = _load_module('xkanaele_server', SERVER_PATH)

# Expose common API
class xKanaele(_client.xKanaele):
    pass

class xKanaeleServer(_server.xKanaeleServer):
    pass

__all__ = ['xKanaele','xKanaeleServer']
