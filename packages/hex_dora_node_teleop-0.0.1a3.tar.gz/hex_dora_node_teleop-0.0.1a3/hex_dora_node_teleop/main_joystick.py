#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-15
################################################################

import os
import select
import threading
import traceback

from dora import Node
from evdev import InputDevice, list_devices, ecodes
from hex_util_runtime import get_dora_node_name, dict_encode

_NAME_REMAP = {
    "BTN_NORTH": "BTN_Y",
    "BTN_WEST": "BTN_X",
    "BTN_TL": "BTN_LB",
    "BTN_TR": "BTN_RB",
    "BTN_TL2": "BTN_LT",
    "BTN_TR2": "BTN_RT",
    "ABS_Z": "ABS_LT",
    "ABS_RZ": "ABS_RT",
}


def _code_name(code, type_dict):
    """Resolve an evdev code to its human-readable name."""
    name = type_dict.get(code)
    if name is None:
        return str(code)
    if isinstance(name, (list, tuple)):
        return name[0]
    return name


def _has_joystick_buttons(caps):
    """Check if the device has joystick/gamepad buttons (0x120-0x13f)."""
    key_codes = caps.get(ecodes.EV_KEY, [])
    return any(0x120 <= code <= 0x13f for code in key_codes)


def find_joysticks():
    """Find joystick / gamepad devices.

    Prefer devices that have both ABS axes and joystick/gamepad buttons.
    Fall back to any ABS_X/ABS_Y device only if no real gamepad is found.
    """
    gamepads = []
    fallback = []
    for path in list_devices():
        dev = InputDevice(path)
        caps = dev.capabilities(absinfo=False)
        if ecodes.EV_ABS not in caps:
            continue
        abs_codes = caps[ecodes.EV_ABS]
        if ecodes.ABS_X not in abs_codes and ecodes.ABS_Y not in abs_codes:
            continue
        if _has_joystick_buttons(caps):
            print(f"[joystick] found gamepad: {dev.path} {dev.name}")
            gamepads.append(dev)
        else:
            print(f"[joystick] found candidate: {dev.path} {dev.name}")
            fallback.append(dev)
    return gamepads if gamepads else fallback


class JoystickStateReader:
    """Background reader that maintains joystick button and axis states."""

    def __init__(self, device):
        self._device = device
        self._lock = threading.Lock()
        self._running = False

        key_types = ecodes.bytype.get(ecodes.EV_KEY, {})
        abs_types = ecodes.bytype.get(ecodes.EV_ABS, {})

        caps_simple = device.capabilities(absinfo=False)
        self._button_codes = []
        self._button_names = []
        for code in caps_simple.get(ecodes.EV_KEY, []):
            name = _code_name(code, key_types)
            if name.startswith("BTN_"):
                self._button_codes.append(code)
                self._button_names.append(name)

        caps_abs = device.capabilities(absinfo=True)
        self._axis_codes = []
        self._axis_names = []
        self._axis_info = {}
        for code, absinfo in caps_abs.get(ecodes.EV_ABS, []):
            name = _code_name(code, abs_types)
            self._axis_codes.append(code)
            self._axis_names.append(name)
            self._axis_info[code] = absinfo

        self._button_state = {code: 0 for code in self._button_codes}
        self._axis_state = {}
        for code in self._axis_codes:
            info = self._axis_info[code]
            self._axis_state[code] = self._normalize(info.value, info)

    @staticmethod
    def _normalize(value, absinfo):
        lo, hi = absinfo.min, absinfo.max
        if hi == lo:
            return 0.0
        return 2.0 * (value - lo) / (hi - lo) - 1.0

    def start(self):
        self._running = True
        t = threading.Thread(target=self._read_loop, daemon=True)
        t.start()

    def stop(self):
        self._running = False

    def _read_loop(self):
        dev = self._device
        while self._running:
            r, _, _ = select.select([dev.fd], [], [], 0.01)
            if not r:
                continue
            try:
                for event in dev.read():
                    if event.type == ecodes.EV_KEY and event.code in self._button_state:
                        with self._lock:
                            self._button_state[
                                event.code] = 0 if event.value == 0 else 1
                    elif event.type == ecodes.EV_ABS and event.code in self._axis_state:
                        with self._lock:
                            info = self._axis_info[event.code]
                            self._axis_state[event.code] = self._normalize(
                                event.value, info)
            except OSError:
                break

    @property
    def button_names(self):
        return list(self._button_names)

    @property
    def axis_names(self):
        return list(self._axis_names)

    def get_buttons(self):
        with self._lock:
            return [self._button_state[code] for code in self._button_codes]

    def get_axes(self):
        with self._lock:
            return [self._axis_state[code] for code in self._axis_codes]


def main():
    node_name = get_dora_node_name(os.getenv("NODE_NAME", ""))
    device_path = os.getenv("DEVICE_PATH", "")

    if device_path:
        devices = [InputDevice(device_path)]
        print(f"[joystick] using: {devices[0].path} {devices[0].name}")
    else:
        devices = find_joysticks()

    if not devices:
        print("[joystick] no joystick device found")
        print((
            "[joystick] This may be caused by permission denied when accessing /dev/input/*\n"
            "[joystick] Please add your user to the 'input' group and re-login:\n"
            "[joystick]   sudo usermod -aG input $USER"))
        return

    device = devices[0]
    reader = JoystickStateReader(device)
    reader.start()

    print(f"[joystick] buttons: {reader.button_names}")
    print(f"[joystick] axes: {reader.axis_names}")

    try:
        node = Node(node_name)
        for event in node:
            if event["type"] == "INPUT":
                if event["id"] == "tick":
                    buttons = reader.get_buttons()
                    axes = reader.get_axes()
                    btn_names = [
                        _NAME_REMAP.get(n, n) for n in reader.button_names
                    ]
                    axis_names = [
                        _NAME_REMAP.get(n, n) for n in reader.axis_names
                    ]
                    btn_dict = dict(zip(btn_names, buttons))
                    storage, metadata = dict_encode(btn_names, btn_dict, {})
                    node.send_output("buttons", storage, metadata)

                    axis_dict = dict(zip(axis_names, axes))
                    storage, metadata = dict_encode(axis_names, axis_dict,
                                                    {})
                    node.send_output("axes", storage, metadata)
            elif event["type"] == "ERROR":
                raise RuntimeError(event["error"])
    except Exception:
        traceback.print_exc()
    finally:
        reader.stop()


if __name__ == "__main__":
    main()
