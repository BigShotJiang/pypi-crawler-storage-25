#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-15
################################################################

import os, sys, traceback

from dora import Node
from hex_util_runtime import get_dora_node_name, dict_decode


def show_joystick_state(btn_dict, axis_dict):
    lines = ["=== Joystick State ==="]
    if btn_dict is not None:
        lines.append("Buttons:")
        for name, val in btn_dict.items():
            mark = "*" if val else "."
            lines.append(f"  {name:>16s}: {mark}")
    if axis_dict is not None:
        lines.append("Axes:")
        for name, val in axis_dict.items():
            lines.append(f"  {name:>16s}: {val:+.4f}")
    output = "\033[H"
    for line in lines:
        output += line + "\033[K\n"
    output += "\033[J"
    sys.stdout.write(output)
    sys.stdout.flush()


def main():
    node_name = get_dora_node_name(os.getenv("NODE_NAME", ""))

    show_cnt = 0
    btn_dict = None
    axis_dict = None

    try:
        node = Node(node_name)
        for event in node:
            if event["type"] == "INPUT":
                if event["id"] == "tick":
                    show_cnt += 1
                    if show_cnt >= 10:
                        show_cnt = 0
                        show_joystick_state(btn_dict, axis_dict)

                elif event["id"] == "buttons":
                    btn_dict = dict_decode(event["value"],
                                           event["metadata"])

                elif event["id"] == "axes":
                    axis_dict = dict_decode(event["value"],
                                            event["metadata"])

            elif event["type"] == "ERROR":
                raise RuntimeError(event["error"])
    except Exception:
        traceback.print_exc()


if __name__ == "__main__":
    main()
