#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-15
################################################################

import os
import select
import threading
import traceback

from dora import Node
from evdev import InputDevice, list_devices, ecodes
from hex_util_runtime import get_dora_node_name, dict_encode

LETTER_CODES = [
    getattr(ecodes, f"KEY_{chr(c)}") for c in range(ord('A'),
                                                    ord('Z') + 1)
]
LETTER_NAMES = [chr(c) for c in range(ord('a'), ord('z') + 1)]


def find_keyboards():
    """Find all keyboard devices that have letter keys."""
    keyboards = []
    for path in list_devices():
        dev = InputDevice(path)
        caps = dev.capabilities(absinfo=False)
        if ecodes.EV_KEY in caps and ecodes.KEY_A in caps[ecodes.EV_KEY]:
            print(f"[keyboard] found: {dev.path} {dev.name}")
            keyboards.append(dev)
    return keyboards


class KeyboardStateReader:
    """Background reader that maintains keyboard letter key states via evdev."""

    def __init__(self, devices):
        self._devices = devices
        self._state = {code: 0 for code in LETTER_CODES}
        self._lock = threading.Lock()
        self._running = False

    def start(self):
        self._running = True
        for dev in self._devices:
            t = threading.Thread(target=self._read_loop,
                                 args=(dev, ),
                                 daemon=True)
            t.start()

    def stop(self):
        self._running = False

    def _read_loop(self, dev):
        while self._running:
            r, _, _ = select.select([dev.fd], [], [], 0.01)
            if not r:
                continue
            try:
                for event in dev.read():
                    if event.type == ecodes.EV_KEY and event.code in self._state:
                        with self._lock:
                            self._state[
                                event.code] = 0 if event.value == 0 else 1
            except OSError:
                break

    def get_state(self):
        with self._lock:
            return [self._state[code] for code in LETTER_CODES]


def main():
    node_name = get_dora_node_name(os.getenv("NODE_NAME", ""))
    device_path = os.getenv("DEVICE_PATH", "")

    if device_path:
        devices = [InputDevice(device_path)]
        print(f"[keyboard] using: {devices[0].path} {devices[0].name}")
    else:
        devices = find_keyboards()

    if not devices:
        print("[keyboard] no keyboard device found")
        print((
            "[keyboard] This may be caused by permission denied when accessing /dev/input/*\n"
            "[keyboard] Please add your user to the 'input' group and re-login:\n"
            "[keyboard]   sudo usermod -aG input $USER"))
        return

    reader = KeyboardStateReader(devices)
    reader.start()

    try:
        node = Node(node_name)
        for event in node:
            if event["type"] == "INPUT":
                if event["id"] == "tick":
                    state = reader.get_state()
                    state_dict = dict(zip(LETTER_NAMES, state))
                    storage, metadata = dict_encode(
                        LETTER_NAMES, state_dict, {})
                    node.send_output("state", storage, metadata)
            elif event["type"] == "ERROR":
                raise RuntimeError(event["error"])
    except Exception:
        traceback.print_exc()
    finally:
        reader.stop()


if __name__ == "__main__":
    main()
