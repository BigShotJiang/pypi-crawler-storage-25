#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-15
################################################################

import os, sys, traceback

from dora import Node
from hex_util_runtime import get_dora_node_name, dict_decode


def show_keyboard_state(state_dict):
    pressed = [k for k, v in state_dict.items() if v]
    row = "  ".join(f"{k}:{'*' if v else '.'}"
                    for k, v in state_dict.items())
    lines = ["=== Keyboard State ===", row, f"Pressed: {pressed}"]
    output = "\033[H"
    for line in lines:
        output += line + "\033[K\n"
    output += "\033[J"
    sys.stdout.write(output)
    sys.stdout.flush()


def main():
    node_name = get_dora_node_name(os.getenv("NODE_NAME", ""))

    show_cnt = 0
    state_dict = None

    try:
        node = Node(node_name)
        for event in node:
            if event["type"] == "INPUT":
                if event["id"] == "tick":
                    show_cnt += 1
                    if show_cnt >= 10 and state_dict is not None:
                        show_cnt = 0
                        show_keyboard_state(state_dict)

                elif event["id"] == "state":
                    state_dict = dict_decode(event["value"],
                                             event["metadata"])

            elif event["type"] == "ERROR":
                raise RuntimeError(event["error"])
    except Exception:
        traceback.print_exc()


if __name__ == "__main__":
    main()
