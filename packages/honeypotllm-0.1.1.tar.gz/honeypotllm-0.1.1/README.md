# 🍯 honeypotllm

[![PyPI version](https://badge.fury.io/py/honeypotllm.svg)](https://pypi.org/project/honeypotllm/)
[![CI](https://github.com/viveks-codes/honeypotllm/actions/workflows/ci.yml/badge.svg)](https://github.com/viveks-codes/honeypotllm/actions/workflows/ci.yml)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-green.svg)](LICENSE)

```bash
pip install honeypotllm
```

> **"Turn your LLM API into a legal trap. If someone steals your model, their stolen model becomes the evidence."**

**honeypotllm** is an open-source Python SDK that protects LLM APIs from corporate data theft and unauthorized model replication — by making the stolen data itself the forensic evidence.

---

## The Problem

AI companies invest millions training proprietary LLMs. A bad actor can:

1. Obtain API access legitimately (or via stolen keys)
2. Make millions of queries and collect input–output pairs
3. Fine-tune a smaller open-source model on this dataset
4. Deploy a "new" model that closely mimics the original — at near-zero cost

**Current defenses are inadequate:** rate limiting is bypassable, IP blocking is trivially circumvented, and Terms of Service are unenforceable without forensic proof.

## The Solution

honeypotllm **fingerprints the stolen data before the attacker trains on it.** It uses:

| Layer | What it does |
|---|---|
| **Suspicion Scoring** | Monitors per-key request rate, sequential patterns, gaps, volume |
| **Output Watermarking** | Subtly modifies responses with invisible, fine-tuning-robust signatures |
| **Behavioral Fingerprinting** | Injects identity trapdoors — stolen model learns to identify itself as yours |
| **Forensic Evidence** | Immutable, HMAC-chained audit log exportable as court-ready packages |

If the attacker trains on poisoned data, their model **inherits your fingerprint** — detectable by probing and provable in court.

---

## Quick Start

### Install

```bash
pip install honeypotllm

# With FastAPI support
pip install honeypotllm[fastapi]
```

### 1. Generate a config file

```bash
honeypotllm init-config --output honeypot_config.yaml
```

### 2. Integrate in 4 lines

```python
from honeypotllm import HoneypotMiddleware

honeypot = HoneypotMiddleware.from_yaml("honeypot_config.yaml")
await honeypot.init()

# Wrap every LLM response:
result = await honeypot.process(
    api_key=request.headers["Authorization"].removeprefix("Bearer "),
    response_text=llm_response,
    prompt=user_prompt,
)
return result.response_text  # Watermarked if suspicious, unchanged if normal
```

That's it. Legitimate users always get the original, unchanged response. Scrapers get watermarked responses that act as tracking devices.

### FastAPI / Starlette (automatic ASGI integration)

```python
from fastapi import FastAPI
from honeypotllm.middleware import FastAPIMiddleware
from honeypotllm.config import HoneypotConfig

app = FastAPI()
config = HoneypotConfig.from_yaml("honeypot_config.yaml")
app.add_middleware(FastAPIMiddleware, config=config)
# Done — all routes are now protected automatically
```

### Config file reference

```yaml
secret_key: ""             # Set via HONEYPOT_SECRET_KEY env var in production
suspicion_threshold: 0.75  # Score 0.0–1.0 above which a key is flagged

watermark:
  strategies: [lexical, unicode]   # lexical / syntactic / unicode (combinable)
  global_seed: 42

scoring:
  requests_per_minute_threshold: 30
  requests_per_hour_threshold: 500
  requests_per_day_threshold: 5000
  min_gap_seconds: 0.5             # Sub-0.5s gaps between requests = suspicious

trusted_keys: []           # SHA-256 hashes of keys that always get real responses
bypass_token: ""           # Internal services: pass this to skip all checks
```

---

## How It Works

### Step 1 — Suspicion Scoring
Every request is scored 0.0–1.0 using 4 independent heuristics. All four must combine to exceed the threshold, preventing false positives from legitimate high-volume users:

| Heuristic | Signal | Weight |
|---|---|---|
| **Rate** | Requests exceed RPM/RPH/RPD thresholds | 35% |
| **Sequential** | Consecutive prompts have similar word patterns | 30% |
| **Gap** | Sub-second gaps between all requests (bots don't pause) | 20% |
| **Volume** | Total daily volume far exceeds typical usage | 15% |

Scores **decay over time** (default: 5% per idle hour) so legitimate burst traffic self-corrects.

### Step 2 — Watermarking
Three complementary strategies, all combinable:

| Strategy | How it works | Best for |
|---|---|---|
| `lexical` | Replaces words with seed-selected synonyms (WordNet) | Training-data robustness |
| `syntactic` | Alters conjunction choice, Oxford comma, adverb placement | Structural fingerprinting |
| `unicode` | Encodes a binary fingerprint using invisible zero-width chars | Copy-paste detection |

All watermarks are **key-unique** (different per API key) and **deterministic** (same seed always produces the same watermark — critical for attribution).

> ℹ️ For fine-tuning-robust watermarks, use `lexical` or `syntactic`. Zero-width chars (`unicode`) are often stripped by LLM tokenizers.

### Step 3 — Behavioral Fingerprinting
For the BharatGen-style "identity injection" scenario: honeypotllm can inject subtle identity strings into poisoned responses. If an attacker fine-tunes on this data, their stolen model learns to say *"I am [your model name]"* when probed. See `examples/bharatgen_honeypot.py` for a complete implementation.

### Step 4 — Forensic Evidence
The audit log uses **HMAC-SHA256 chaining**: each entry's integrity depends on the previous one. Tampering with any record breaks the entire chain. This makes the log suitable as tamper-evident forensic evidence.

```bash
honeypotllm verify-log                  # Verify chain is intact
honeypotllm export-evidence \
  --key-hash <sha256> \
  --output evidence.json               # Court-ready JSON package
```

---

## Protecting Legitimate Users

honeypotllm is designed to have **zero impact on real users**:

- **`trusted_keys`** — Whitelist partner/internal API key hashes. These always receive real responses, never tracked.
- **`bypass_token`** — Internal services pass a secret token to skip all checks entirely.
- **Score decay** — A burst of traffic gradually returns to 0.0 over time if the pattern normalizes.
- **4-heuristic requirement** — All four signals must combine to exceed the threshold. A batch processor triggers 1–2 signals; a scraper triggers all 4 at maximum intensity.
- **Watermark failure is silent** — If watermarking ever fails (e.g., text too short), the original response is served unchanged. A watermarking bug can never harm a real user.

```python
# Whitelist a business partner permanently
from honeypotllm.scoring import SuspicionScorer
key_hash = SuspicionScorer.hash_key("partner-api-key-here")
# Add key_hash to trusted_keys in your config

# Internal service bypass (per-request)
result = await honeypot.process(
    api_key=internal_key,
    response_text=response,
    bypass_token="your-bypass-token",   # Matches config.bypass_token
)
```

---

## CLI Reference

```bash
# Generate a config file
honeypotllm init-config --output honeypot_config.yaml

# Show current configuration
honeypotllm status --config honeypot_config.yaml

# Run detection against a suspected stolen model's outputs
honeypotllm detect \
  --outputs suspect_outputs.jsonl \
  --watermark-ids <uuid-1> <uuid-2> \
  --config honeypot_config.yaml \
  --report detection_report.json

# Export forensic evidence for a specific API key
honeypotllm export-evidence \
  --key-hash <sha256-hex> \
  --output evidence.json

# Verify the audit log chain is intact (tamper detection)
honeypotllm verify-log --config honeypot_config.yaml
```

---

## Examples

| Example | Description |
|---|---|
| [`simple_protection.py`](examples/simple_protection.py) | Zero-framework example — works with any Python HTTP lib |
| [`fastapi_example.py`](examples/fastapi_example.py) | Full FastAPI integration with admin dashboard endpoints |
| [`detect_stolen_model.py`](examples/detect_stolen_model.py) | Complete forensic attribution workflow |
| [`bharatgen_honeypot.py`](examples/bharatgen_honeypot.py) | Identity-injection trapdoor for branded AI models |

---

## Compatibility

| Python | Status |
|---|---|
| 3.10 | ✅ Supported |
| 3.11 | ✅ Supported |
| 3.12 | ✅ Supported |
| 3.13 | 🔄 Tested informally |

| Framework | Integration | How |
|---|---|---|
| **FastAPI / Starlette** | ✅ Native ASGI middleware | `FastAPIMiddleware` |
| **Any async framework** | ✅ Manual | `honeypot.process()` |
| **Sync frameworks** | ✅ With `asyncio.run()` wrapper | `honeypot.process()` |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│            Your LLM API Server                       │
│                                                      │
│  ┌──────────────┐     ┌──────────────────────────┐  │
│  │  Incoming    │────▶│   HoneypotMiddleware      │  │
│  │  API Request │     │  1. Hash API key          │  │
│  └──────────────┘     │  2. Score suspicion       │  │
│                       │  3. Route decision        │  │
│                       └────────────┬─────────────┘  │
│                ┌───────────────────┴────────────┐   │
│            [Normal]                        [Flagged] │
│                │                                 │   │
│                ▼                                 ▼   │
│     ┌────────────────┐          ┌──────────────────┐ │
│     │ Real response  │          │  WatermarkEngine  │ │
│     │  (unchanged)   │          │  lexical+syntactic│ │
│     └────────────────┘          └────────┬─────────┘ │
│                                          │           │
│                                 ┌────────▼─────────┐ │
│                                 │   AuditLogger    │ │
│                                 │  (HMAC-chained)  │ │
│                                 └──────────────────┘ │
└─────────────────────────────────────────────────────┘
```

---

## Development

```bash
git clone https://github.com/viveks-codes/honeypotllm
cd honeypotllm
pip install -e ".[dev,fastapi]"

# Download NLTK data (needed for lexical watermarking)
python -c "
import nltk
nltk.download('wordnet')
nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger')
nltk.download('averaged_perceptron_tagger_eng')
"

# Run tests
pytest

# Lint + type check
ruff check honeypotllm
mypy honeypotllm
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for the full guide.

---

## Comparison with Alternatives

| Approach | Detects Scraping | Forensic Proof | Zero False Positives | Open Source |
|---|---|---|---|---|
| **honeypotllm** | ✅ Yes | ✅ Yes | ✅ Yes (trusted_keys) | ✅ Yes |
| Rate Limiting | ⚠️ Slows scrapers | ❌ No | ❌ Blocks legit users | ✅ Varies |
| IP Blocking | ❌ Trivially bypassed | ❌ No | ❌ No | ✅ Varies |
| ToS Agreement | ❌ No | ❌ No | ✅ Yes | ✅ N/A |
| API Key Revocation | ⚠️ Reactive only | ❌ No | ✅ Yes | ✅ N/A |

---

## Roadmap

- **v0.1.1** — Bug fixes: sequential heuristic, FastAPI body reading, LRU memory bound, new examples ✅
- **v0.2.0** — Behavioral fingerprinting (automated probe suite), Slack/webhook alerts
- **v1.0.0** — Monitoring dashboard (FastAPI + React), Docker Compose, full docs site
- **Post v1.0** — LangChain/LiteLLM integration, PostgreSQL backend, multi-tenant support

---

## Security Notes

- **API keys are NEVER stored in plaintext** — only SHA-256 hashes are persisted
- **Watermark seeds are key-unique** — one key's watermark doesn't affect others
- **Audit log is HMAC-chained** — any tampering is detectable
- **No phone-home behavior** — operates entirely within your infrastructure
- **Watermarking failures are silent** — real user responses are NEVER affected

> ⚠️ **Set `HONEYPOT_SECRET_KEY`** in production via environment variable. An empty secret key degrades HMAC and watermark security.

---

## Legal & Ethical Use

honeypotllm is designed for **defensive use only** — protecting AI companies' intellectual property from theft. Users must:

- Explicitly prohibit unauthorized model replication in their Terms of Service
- Minimize false positives; wrongly flagging a legitimate user is harmful
- Comply with applicable data retention laws (GDPR, India's DPDP Act, CCPA)
- Have forensic evidence reviewed by qualified legal counsel before litigation

**Offensive use is explicitly prohibited.** See [CONTRIBUTING.md](CONTRIBUTING.md).

---

## License

Apache 2.0 — see [LICENSE](LICENSE).

## Citation

If you use honeypotllm in academic research, please cite:

```bibtex
@software{honeypotllm2026,
  title   = {honeypotllm: LLM API Protection via Watermarking and Behavioral Fingerprinting},
  author  = {Vivek},
  year    = {2026},
  url     = {https://github.com/viveks-codes/honeypotllm},
  license = {Apache-2.0},
}
```
