# Changelog

All notable changes to **honeypotllm** are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

### Planned for v0.2.0
- Behavioral fingerprinting: trapdoor injection + automated probe suite
- `honeypotllm probe` CLI command

### Planned for v1.0.0
- Monitoring dashboard (FastAPI backend + React frontend)
- Docker Compose self-hosted deployment
- Full MkDocs documentation site

---

## [0.1.1] — 2026-04-04

### Fixed
- **Critical — Sequential heuristic** (`scoring.py`): The `_sequential_heuristic` was
  comparing SHA-256 hex hashes using character-level Jaccard similarity. Because all hex
  strings share the same character alphabet `{0-9a-f}`, this returned ~0.5 for ALL pairs
  of prompts regardless of similarity — making the heuristic non-functional. Fixed by
  storing the first 120 chars of the actual prompt text and using **word-bigram Jaccard
  similarity** instead, which correctly scores scraper-style sequential prompts high and
  diverse real-user prompts near 0.
- **Critical — FastAPIMiddleware prompt extraction** (`middleware.py`): Body was read via
  `request._body` which is a non-existent private attribute and always returns `None`.
  Fixed to use `await request.body()` (Starlette's official cached body accessor) before
  `call_next()`, so the prompt is correctly extracted for sequential scoring.
- **Sequential similarity threshold** (`config.py`): Default lowered from `0.85` to
  `0.40` — appropriate for real word-bigram Jaccard where scraper prompts score 0.3–0.6
  and unrelated prompts score near 0.

### Added
- **LRU memory bound** (`scoring.py`): `ScoringState` dictionary is now capped at
  10,000 entries. Least-recently-seen keys are evicted when the limit is reached,
  preventing unbounded memory growth on long-running servers.
- **`CONTRIBUTING.md`**: Contribution guide, ethical use policy, development setup,
  and PR process. Previously referenced in README but never created.
- **`examples/simple_protection.py`**: Minimal, framework-agnostic example demonstrating
  normal user, scraper, and trusted bypass scenarios.
- **`examples/detect_stolen_model.py`**: Full forensic detection workflow — generates a
  poisoned corpus, runs attribution detection, and saves a JSON evidence file.

---

## [0.1.0] — 2026-04-03

### Added
- **Core SDK package** (`honeypotllm`)
  - `HoneypotMiddleware`: framework-agnostic middleware with per-request processing
  - `FastAPIMiddleware`: Starlette/FastAPI ASGI middleware wrapper
  - `SuspicionScorer`: in-memory scoring engine with rate, sequential, gap,
    and volume heuristics; configurable weights and score decay
  - `WatermarkEngine`: orchestrates multiple watermarking strategies
    - `LexicalWatermarkStrategy`: WordNet synonym substitution (NLTK)
    - `SyntacticWatermarkStrategy`: rule-based conjunction and adverb transforms
    - `UnicodeWatermarkStrategy`: zero-width character steganography
  - `AuditLogger`: HMAC-SHA256 chained, append-only audit log (SQLite/PostgreSQL)
  - `Detector`: multi-candidate watermark attribution with `DetectionReport`
  - `TrapdoorInjector`: behavioral fingerprinting via trapdoor injection (Phase 2)
  - `probe_model_endpoint()`: async probe utility for suspected stolen models

- **CLI** (`honeypotllm` command)
  - `detect`: run watermark detection against a JSONL file of suspected outputs
  - `export-evidence`: export a forensic evidence package for an API key
  - `verify-log`: verify HMAC chain integrity of the audit log
  - `status`: display current configuration summary
  - `init-config`: generate a sample `honeypot_config.yaml`

- **Configuration** (`HoneypotConfig`, `WatermarkConfig`, `ScoringConfig`)
  - Pydantic v2 models with full validation
  - YAML load/save (`from_yaml()` / `to_yaml()`)
  - Environment variable support for `HONEYPOT_SECRET_KEY`

- **Data models** (SQLAlchemy 2.0)
  - `APIKeyProfile`, `WatermarkRecord`, `SuspicionEvent`, `AuditLogEntry`,
    `DetectionResultRecord`

- **Test suite** (pytest + pytest-asyncio)
  - `tests/test_config.py`
  - `tests/test_watermark.py`
  - `tests/test_scoring.py`
  - `tests/test_middleware.py`
  - `tests/test_logging.py`
  - `tests/test_detection.py`

- **CI/CD** (GitHub Actions)
  - Lint: ruff (check + format)
  - Type-check: mypy
  - Tests: Python 3.10, 3.11, 3.12
  - Build validation: `python -m build` + `twine check`
  - PyPI publish: OIDC trusted publishing on GitHub release

- **Example** (`examples/fastapi_example.py`)
  - Full working FastAPI integration with admin endpoints

### Security
- API keys are stored as SHA-256 hashes only — never plaintext
- Watermark seeds are deterministically derived per key, never shared
- HMAC-chained audit log is tamper-evident
- Watermarking failures silently fall back to the original response

### Known Limitations
- `lexical` strategy requires NLTK data download on first use
- Watermarked ZWC characters may be stripped by some LLM tokenizers (use `lexical` for fine-tuning-robust watermarks)
- Behavioral fingerprinting (`fingerprint` module) is in early access — production hardening planned for v0.2.0

[Unreleased]: https://github.com/viveks-codes/honeypotllm/compare/v0.1.1...HEAD
[0.1.1]: https://github.com/viveks-codes/honeypotllm/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/viveks-codes/honeypotllm/releases/tag/v0.1.0
