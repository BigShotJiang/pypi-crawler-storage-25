"""Tests for watermark strategies."""

from __future__ import annotations

import pytest

from honeypotllm.watermark.base import WatermarkStrategy
from honeypotllm.watermark.syntactic import SyntacticWatermarkStrategy
from honeypotllm.watermark.unicode import UnicodeWatermarkStrategy, _seed_to_fingerprint_bits
from honeypotllm.watermark import WatermarkEngine
from honeypotllm.config import WatermarkConfig


SAMPLE_TEXT = (
    "Machine learning models require substantial computational resources "
    "during the training process. The optimization algorithm iterates over "
    "the dataset multiple times, adjusting parameters to minimize the loss function. "
    "Modern neural networks contain billions of parameters, making efficient "
    "training infrastructure essential for competitive development."
)

WATERMARK_ID = "550e8400-e29b-41d4-a716-446655440000"


# ─── Unicode Strategy ─────────────────────────────────────────────────────────


class TestUnicodeWatermarkStrategy:
    def setup_method(self):
        self.strategy = UnicodeWatermarkStrategy()

    def test_apply_produces_different_text(self):
        result = self.strategy.apply(SAMPLE_TEXT, seed=42)
        assert result.was_modified
        assert result.watermarked_text != result.original_text

    def test_apply_is_deterministic(self):
        r1 = self.strategy.apply(SAMPLE_TEXT, seed=42)
        r2 = self.strategy.apply(SAMPLE_TEXT, seed=42)
        assert r1.watermarked_text == r2.watermarked_text

    def test_different_seeds_produce_different_watermarks(self):
        r1 = self.strategy.apply(SAMPLE_TEXT, seed=42)
        r2 = self.strategy.apply(SAMPLE_TEXT, seed=99)
        assert r1.watermarked_text != r2.watermarked_text

    def test_strip_watermark_returns_original(self):
        result = self.strategy.apply(SAMPLE_TEXT, seed=42)
        clean = UnicodeWatermarkStrategy.strip_watermark(result.watermarked_text)
        assert clean == SAMPLE_TEXT

    def test_detect_watermarked_text_scores_high(self):
        result = self.strategy.apply(SAMPLE_TEXT, seed=42)
        score = self.strategy.detect([result.watermarked_text], seed=42)
        assert score.score > 0.5, f"Expected score > 0.5, got {score.score}"

    def test_detect_wrong_seed_scores_low(self):
        result = self.strategy.apply(SAMPLE_TEXT, seed=42)
        score = self.strategy.detect([result.watermarked_text], seed=999)
        assert score.score < 0.5, f"Expected score < 0.5, got {score.score}"

    def test_detect_unwatermarked_text_scores_zero(self):
        score = self.strategy.detect([SAMPLE_TEXT], seed=42)
        assert score.score == 0.0

    def test_apply_empty_text(self):
        result = self.strategy.apply("", seed=42)
        assert result.strategy == "unicode"

    def test_fingerprint_bits_deterministic(self):
        bits1 = _seed_to_fingerprint_bits(42)
        bits2 = _seed_to_fingerprint_bits(42)
        assert bits1 == bits2
        assert len(bits1) == 32

    def test_fingerprint_bits_differ_per_seed(self):
        bits1 = _seed_to_fingerprint_bits(42)
        bits2 = _seed_to_fingerprint_bits(43)
        assert bits1 != bits2

    def test_strategy_name(self):
        assert self.strategy.name == "unicode"


# ─── Syntactic Strategy ───────────────────────────────────────────────────────


class TestSyntacticWatermarkStrategy:
    def setup_method(self):
        self.strategy = SyntacticWatermarkStrategy(
            perturbation_rate=1.0,  # Apply to every sentence for testing
            operations=["conjunction_swap"],
        )

    def test_apply_returns_watermark_result(self):
        result = self.strategy.apply(SAMPLE_TEXT, seed=42)
        assert result.strategy == "syntactic"
        assert result.original_text == SAMPLE_TEXT

    def test_apply_is_deterministic(self):
        r1 = self.strategy.apply(SAMPLE_TEXT, seed=42)
        r2 = self.strategy.apply(SAMPLE_TEXT, seed=42)
        assert r1.watermarked_text == r2.watermarked_text

    def test_different_seeds_may_differ(self):
        r1 = self.strategy.apply(SAMPLE_TEXT, seed=1)
        r2 = self.strategy.apply(SAMPLE_TEXT, seed=2)
        # May or may not differ depending on which conjunction is chosen
        assert r1.strategy == r2.strategy == "syntactic"

    def test_detect_returns_score(self):
        result = self.strategy.apply(SAMPLE_TEXT, seed=0)
        score = self.strategy.detect([result.watermarked_text], seed=0)
        assert 0.0 <= score.score <= 1.0

    def test_oxford_comma_operation(self):
        strategy = SyntacticWatermarkStrategy(
            perturbation_rate=1.0, operations=["oxford_comma"]
        )
        text = "I enjoy reading, writing and coding daily."
        result = strategy.apply(text, seed=0)
        assert result.strategy == "syntactic"

    def test_strategy_name(self):
        assert self.strategy.name == "syntactic"

    def test_empty_text(self):
        result = self.strategy.apply("", seed=42)
        assert result.strategy == "syntactic"


# ─── WatermarkEngine ─────────────────────────────────────────────────────────


class TestWatermarkEngine:
    def test_engine_with_unicode_strategy(self):
        config = WatermarkConfig(strategies=["unicode"], global_seed=42)
        engine = WatermarkEngine(config)
        result = engine.apply(SAMPLE_TEXT, watermark_id=WATERMARK_ID)
        assert result.watermarked_text != SAMPLE_TEXT

    def test_engine_combined_strategies(self):
        config = WatermarkConfig(strategies=["syntactic", "unicode"], global_seed=42)
        engine = WatermarkEngine(config)
        result = engine.apply(SAMPLE_TEXT, watermark_id=WATERMARK_ID)
        assert len(result.strategy_results) == 2

    def test_engine_detection_round_trip(self):
        config = WatermarkConfig(strategies=["unicode"], global_seed=42)
        engine = WatermarkEngine(config)
        wm_result = engine.apply(SAMPLE_TEXT, watermark_id=WATERMARK_ID)
        # Test multiple copies (simulate a stolen training corpus)
        texts = [wm_result.watermarked_text] * 10
        score = engine.detect(texts, watermark_id=WATERMARK_ID)
        assert score.overall_score > 0.5

    def test_engine_wrong_watermark_id_scores_low(self):
        config = WatermarkConfig(strategies=["unicode"], global_seed=42)
        engine = WatermarkEngine(config)
        wm_result = engine.apply(SAMPLE_TEXT, watermark_id=WATERMARK_ID)
        texts = [wm_result.watermarked_text] * 10
        # Test against a different watermark_id
        wrong_id = "00000000-0000-0000-0000-000000000000"
        score = engine.detect(texts, watermark_id=wrong_id)
        assert score.overall_score < 0.6

    def test_engine_strategy_names(self):
        config = WatermarkConfig(strategies=["unicode", "syntactic"], global_seed=1)
        engine = WatermarkEngine(config)
        assert "unicode" in engine.strategy_names
        assert "syntactic" in engine.strategy_names

    def test_engine_unknown_strategy_raises(self):
        from honeypotllm.exceptions import WatermarkError

        config = WatermarkConfig.__new__(WatermarkConfig)
        # Manually override to bypass Pydantic validation for this test
        object.__setattr__(config, "strategies", ["unknown_strategy"])
        object.__setattr__(config, "global_seed", 1)
        object.__setattr__(config, "lexical", WatermarkConfig().lexical)
        object.__setattr__(config, "syntactic", WatermarkConfig().syntactic)
        object.__setattr__(config, "unicode", WatermarkConfig().unicode)

        with pytest.raises(WatermarkError, match="Unknown watermark strategy"):
            WatermarkEngine(config)

    def test_detect_empty_texts(self):
        config = WatermarkConfig(strategies=["unicode"], global_seed=42)
        engine = WatermarkEngine(config)
        score = engine.detect([], watermark_id=WATERMARK_ID)
        assert score.overall_score == 0.0

    def test_derive_key_seed_unique_per_key(self):
        config = WatermarkConfig(strategies=["unicode"], global_seed=42)
        engine = WatermarkEngine(config)
        strategy = engine._strategies[0]
        seed1 = strategy.derive_key_seed(42, "key-uuid-1")
        seed2 = strategy.derive_key_seed(42, "key-uuid-2")
        assert seed1 != seed2

    def test_derive_key_seed_deterministic(self):
        config = WatermarkConfig(strategies=["unicode"], global_seed=42)
        engine = WatermarkEngine(config)
        strategy = engine._strategies[0]
        seed1 = strategy.derive_key_seed(42, WATERMARK_ID)
        seed2 = strategy.derive_key_seed(42, WATERMARK_ID)
        assert seed1 == seed2
