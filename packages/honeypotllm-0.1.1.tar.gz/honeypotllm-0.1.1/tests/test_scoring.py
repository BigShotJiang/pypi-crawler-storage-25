"""Tests for the SuspicionScorer.

Critical invariants verified:
1. LEGITIMATE USERS: Never flagged, never watermarked regardless of usage pattern.
2. SCRAPERS: Reliably detected and served poisoned/watermarked responses.
3. TRUSTED KEYS: Always bypass, zero tracking, guaranteed real response.
4. SEQUENTIAL HEURISTIC: Actually works on real text (bigram Jaccard), not hashes.
5. MEMORY BOUND: LRU eviction kicks in at max_tracked_keys.
"""

from __future__ import annotations

import time

import pytest

from honeypotllm.config import ScoringConfig
from honeypotllm.scoring import (
    SuspicionScorer,
    _hash_api_key,
    _jaccard_similarity,
    _word_bigram_shingles,
    _MAX_TRACKED_KEYS,
)


KEY = "test-api-key-abc123"
KEY_HASH = _hash_api_key(KEY)


class TestSuspicionScorer:
    def setup_method(self):
        config = ScoringConfig(
            requests_per_minute_threshold=5,
            requests_per_hour_threshold=50,
            requests_per_day_threshold=200,
            rate_weight=0.35,
            sequential_weight=0.30,
            gap_weight=0.20,
            volume_weight=0.15,
            min_gap_seconds=1.0,
            sequential_input_similarity_threshold=0.40,
        )
        self.scorer = SuspicionScorer(config, suspicion_threshold=0.5)

    # ── Core basics ────────────────────────────────────────────────────────────

    def test_initial_score_is_zero(self):
        assert self.scorer.get_score(KEY_HASH) == 0.0

    def test_single_request_below_threshold(self):
        result = self.scorer.score_request(KEY_HASH, prompt="hello world")
        assert result.score_after < 0.5
        assert not result.should_honeypot

    def test_score_bounded_at_1(self):
        for i in range(200):
            self.scorer.score_request(KEY_HASH, prompt=f"x{i}")
        assert self.scorer.get_score(KEY_HASH) <= 1.0

    def test_score_accumulates_over_requests(self):
        s0 = self.scorer.get_score(KEY_HASH)
        for i in range(8):
            self.scorer.score_request(KEY_HASH, prompt=f"Q{i}")
        s_final = self.scorer.get_score(KEY_HASH)
        assert s_final >= s0

    def test_reset_clears_score(self):
        for _ in range(10):
            self.scorer.score_request(KEY_HASH, prompt="x")
        assert self.scorer.get_score(KEY_HASH) > 0
        self.scorer.reset(KEY_HASH)
        assert self.scorer.get_score(KEY_HASH) == 0.0

    def test_summary_returns_list(self):
        self.scorer.score_request(KEY_HASH)
        summary = self.scorer.summary()
        assert isinstance(summary, list)
        assert len(summary) >= 1

    def test_hash_key_is_sha256(self):
        import hashlib
        expected = hashlib.sha256(KEY.encode()).hexdigest()
        assert SuspicionScorer.hash_key(KEY) == expected

    def test_multiple_keys_tracked_independently(self):
        key2_hash = _hash_api_key("other-key")
        self.scorer.score_request(KEY_HASH, prompt="q")
        self.scorer.score_request(key2_hash, prompt="q")
        assert KEY_HASH in {s["key_hash"] for s in self.scorer.summary()}
        assert key2_hash in {s["key_hash"] for s in self.scorer.summary()}

    # ── INVARIANT 1: Legitimate users are NEVER harmed ────────────────────────

    def test_legitimate_user_single_request_never_flagged(self):
        """A single organic request must never be flagged."""
        result = self.scorer.score_request(
            KEY_HASH,
            prompt="What is the capital of France?",
        )
        assert not result.should_honeypot, (
            f"Legitimate user incorrectly flagged after 1 request! score={result.score_after}"
        )
        assert result.score_after == 0.0

    def test_legitimate_user_diverse_prompts_not_flagged(self):
        """Diverse, human-paced prompts should never reach the threshold."""
        diverse_prompts = [
            "What is the capital of France?",
            "Explain quantum entanglement simply.",
            "Write a haiku about autumn.",
            "How do I make pasta carbonara?",
            "What year did World War II end?",
        ]
        for prompt in diverse_prompts:
            result = self.scorer.score_request(KEY_HASH, prompt=prompt)
        # After 5 diverse requests, should still be clean
        assert self.scorer.get_score(KEY_HASH) < 0.5, (
            f"Legitimate user with diverse prompts incorrectly flagged! "
            f"score={self.scorer.get_score(KEY_HASH)}"
        )

    def test_trusted_key_always_returns_zero_regardless_of_volume(self):
        """Trusted keys are GUARANTEED to never be flagged, ever."""
        for i in range(100):
            result = self.scorer.score_request(
                KEY_HASH,
                prompt=f"rapid-query-{i}",
                trusted=True,
            )
            assert result.score_after == 0.0, (
                f"Trusted key was scored non-zero at request {i}!"
            )
            assert not result.should_honeypot, (
                f"Trusted key incorrectly flagged at request {i}!"
            )

    def test_trusted_key_score_never_stored(self):
        """Trusted key scoring must not accumulate in _states."""
        for i in range(50):
            self.scorer.score_request(KEY_HASH, trusted=True)
        # Score should remain 0 since trusted skips all processing
        assert self.scorer.get_score(KEY_HASH) == 0.0

    # ── INVARIANT 2: Scrapers are reliably detected ───────────────────────────

    def test_rapid_requests_trigger_rate_heuristic(self):
        """10 requests above the 5/min threshold must raise the score."""
        for i in range(10):
            self.scorer.score_request(KEY_HASH, prompt=f"query {i}")
        score = self.scorer.get_score(KEY_HASH)
        assert score > 0.0, "Rate heuristic failed to fire on rapid requests"

    def test_scraper_with_zero_gaps_reaches_high_score(self):
        """Sequential machine-speed requests with similar prompts must score high."""
        # Simulate a scraper iterating: "What is Python?", "What is Java?", etc.
        languages = [
            "Python", "Java", "C++", "Rust", "Go",
            "TypeScript", "Kotlin", "Swift", "Ruby", "PHP",
            "Scala", "Haskell", "Erlang", "Julia", "R",
        ]
        for lang in languages:
            self.scorer.score_request(
                KEY_HASH,
                prompt=f"What is {lang}? Explain with examples.",
            )
        score = self.scorer.get_score(KEY_HASH)
        # Should be clearly flagged — rate + sequential + gap all fire
        assert score > 0.1, (
            f"Scraper pattern not detected! score={score}. "
            "Rate, sequential, and gap heuristics should all have fired."
        )

    def test_fully_saturated_scraper_exceeds_threshold(self):
        """30 rapid identical-pattern requests must push score past threshold."""
        for i in range(30):
            self.scorer.score_request(
                KEY_HASH, prompt=f"explain topic number {i} in detail"
            )
        assert self.scorer.is_suspicious(KEY_HASH), (
            f"Scraper with 30 rapid requests not detected! "
            f"score={self.scorer.get_score(KEY_HASH)}"
        )

    def test_is_suspicious_reflects_threshold(self):
        for i in range(30):
            self.scorer.score_request(KEY_HASH, prompt=f"rapid-{i}")
        suspicious = self.scorer.is_suspicious(KEY_HASH)
        assert isinstance(suspicious, bool)

    def test_scraper_score_higher_than_legit_user(self):
        """Scraper's score must always be meaningfully higher than a real user's."""
        scraper_key = _hash_api_key("scraper-bot")
        legit_key = _hash_api_key("legitimate-user")

        # Scraper: 20 rapid sequential requests
        for i in range(20):
            self.scorer.score_request(
                scraper_key,
                prompt=f"What is {['Python','Java','C++','Rust','Go'][i % 5]}?",
            )

        # Legit user: 5 diverse requests
        for p in [
            "Tell me a joke",
            "What is the Pythagorean theorem?",
            "How do I cook risotto?",
            "What is photosynthesis?",
            "Who wrote Hamlet?",
        ]:
            self.scorer.score_request(legit_key, prompt=p)

        scraper_score = self.scorer.get_score(scraper_key)
        legit_score = self.scorer.get_score(legit_key)

        assert scraper_score > legit_score, (
            f"Scraper score ({scraper_score:.3f}) not higher than legit user "
            f"({legit_score:.3f}). Scoring engine not discriminating correctly."
        )

    # ── INVARIANT 3: Sequential heuristic works on REAL TEXT ─────────────────

    def test_sequential_heuristic_fires_on_similar_prompts(self):
        """Sequential prompts with shared bigrams must trigger the heuristic."""
        # Use a lower threshold so that template-style scraper prompts fire it.
        # "What is X? Explain it." prompts share bigrams "what is" and "explain it"
        # for a Jaccard of ~0.33. Threshold 0.30 catches this correctly.
        config = ScoringConfig(
            sequential_input_similarity_threshold=0.30,
            sequential_weight=0.30,
        )
        scorer = SuspicionScorer(config, suspicion_threshold=0.9)
        kh = _hash_api_key("seq-test-key")

        prior_prompts = [
            "What is Python? Explain it.",
            "What is Ruby? Explain it.",
            "What is Go? Explain it.",
        ]
        for p in prior_prompts:
            scorer.score_request(kh, prompt=p)

        # 4th request with same template — shares bigrams "what is" / "explain it"
        result = scorer.score_request(kh, prompt="What is Java? Explain it.")
        seq_triggered = any("sequential" in t for t in result.triggered_heuristics)
        assert seq_triggered, (
            f"Sequential heuristic didn't fire on template-style scraper prompts! "
            f"triggers={result.triggered_heuristics}"
        )


    def test_sequential_heuristic_silent_on_diverse_prompts(self):
        """Completely different prompts must NOT trigger the sequential heuristic."""
        diverse_pairs = [
            "What is machine learning?",
            "How do I make sourdough bread?",
            "Who discovered gravity?",
            "What is the speed of light?",
        ]
        for p in diverse_pairs:
            result = self.scorer.score_request(KEY_HASH, prompt=p)

        # None of these diverse prompts should trigger sequential
        seq_triggered = any("sequential" in t for t in result.triggered_heuristics)
        assert not seq_triggered, (
            f"Sequential heuristic falsely fired on diverse prompts! "
            f"triggers={result.triggered_heuristics}"
        )

    def test_sequential_does_not_fire_before_3_requests(self):
        """Sequential detection must be silent for the first 2 requests."""
        for i, prompt in enumerate(["First prompt here", "Second prompt here"]):
            result = self.scorer.score_request(KEY_HASH, prompt=prompt)
            seq_triggered = any("sequential" in t for t in result.triggered_heuristics)
            assert not seq_triggered, (
                f"Sequential heuristic fired too early on request {i + 1}"
            )

    # ── INVARIANT 4: Memory bound (LRU eviction) ──────────────────────────────

    def test_lru_eviction_prevents_unbounded_growth(self):
        """Memory must never exceed _MAX_TRACKED_KEYS regardless of unique keys."""
        limit = 50  # Use small limit for test speed
        scorer = SuspicionScorer(
            ScoringConfig(), suspicion_threshold=0.9
        )
        # Monkey-patch the constant for this test
        import honeypotllm.scoring as scoring_module
        original = scoring_module._MAX_TRACKED_KEYS
        scoring_module._MAX_TRACKED_KEYS = limit

        try:
            for i in range(limit + 20):
                scorer.score_request(_hash_api_key(f"key-{i}"), prompt="test")
            assert len(scorer._states) <= limit + 1, (
                f"Memory bound violated: {len(scorer._states)} > {limit}"
            )
        finally:
            scoring_module._MAX_TRACKED_KEYS = original


class TestHelperFunctions:
    """Test the Jaccard similarity and bigram functions directly."""

    # ── Bigram shingles ───────────────────────────────────────────────────────

    def test_bigram_shingles_basic(self):
        result = _word_bigram_shingles("what is python")
        assert result == {"what is", "is python"}

    def test_bigram_shingles_single_word(self):
        # Fallback to unigrams for short text
        result = _word_bigram_shingles("python")
        assert "python" in result

    def test_bigram_shingles_empty(self):
        result = _word_bigram_shingles("")
        assert result == set()

    # ── Jaccard on real text ──────────────────────────────────────────────────

    def test_jaccard_empty_strings(self):
        assert _jaccard_similarity("", "") == 1.0

    def test_jaccard_identical(self):
        assert _jaccard_similarity("what is python", "what is python") == 1.0

    def test_jaccard_completely_different(self):
        result = _jaccard_similarity("make me a sandwich", "quantum entanglement theory")
        assert result == 0.0, f"Unrelated prompts should have 0 bigram overlap, got {result}"

    def test_jaccard_sequential_scraper_prompts_score_high(self):
        """The core fix: similar scraper prompts must score meaningfully high."""
        sim = _jaccard_similarity(
            "What is Python? Explain with examples.",
            "What is Java? Explain with examples.",
        )
        # Share bigrams: "what is", "explain with", "with examples"
        assert sim >= 0.30, (
            f"Sequential scraper prompts scored too low: {sim:.3f}. "
            "The sequential heuristic won't detect them."
        )

    def test_jaccard_diverse_user_prompts_score_low(self):
        """Completely different user prompts must score near 0."""
        sim = _jaccard_similarity(
            "How do I make sourdough bread?",
            "What is quantum entanglement?",
        )
        assert sim < 0.20, (
            f"Diverse prompts scored too similarly: {sim:.3f}. "
            "Legitimate users would be falsely flagged."
        )

    def test_jaccard_is_symmetric(self):
        a = "explain machine learning to me"
        b = "explain deep learning to me"
        assert _jaccard_similarity(a, b) == _jaccard_similarity(b, a)

    # ── Hash key utilities ────────────────────────────────────────────────────

    def test_hash_key_is_deterministic(self):
        assert _hash_api_key("key") == _hash_api_key("key")

    def test_hash_key_differs_for_different_keys(self):
        assert _hash_api_key("key1") != _hash_api_key("key2")

    def test_hash_key_length(self):
        assert len(_hash_api_key("anything")) == 64  # SHA-256 = 64 hex chars
