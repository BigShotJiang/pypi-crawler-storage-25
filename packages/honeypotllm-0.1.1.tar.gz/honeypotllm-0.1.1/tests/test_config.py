"""Tests for HoneypotConfig validation and YAML loading."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
import yaml

from honeypotllm.config import HoneypotConfig, ScoringConfig, WatermarkConfig
from honeypotllm.exceptions import ConfigurationError


class TestHoneypotConfig:
    def test_default_config_is_valid(self):
        cfg = HoneypotConfig(secret_key="test-key")
        assert cfg.suspicion_threshold == 0.75
        assert cfg.log_backend == "sqlite"
        assert cfg.watermark.strategies == ["lexical", "unicode"]

    def test_suspicion_threshold_bounds(self):
        with pytest.raises(Exception):
            HoneypotConfig(secret_key="k", suspicion_threshold=1.5)
        with pytest.raises(Exception):
            HoneypotConfig(secret_key="k", suspicion_threshold=-0.1)

    def test_invalid_db_url_raises(self):
        with pytest.raises(Exception):
            HoneypotConfig(secret_key="k", db_url="mysql://localhost/db")

    def test_sqlite_db_url_accepted(self):
        cfg = HoneypotConfig(secret_key="k", db_url="sqlite+aiosqlite:///test.db")
        assert "sqlite" in cfg.db_url

    def test_postgres_db_url_accepted(self):
        cfg = HoneypotConfig(
            secret_key="k", db_url="postgresql+asyncpg://user:pw@localhost/db"
        )
        assert "postgresql" in cfg.db_url

    def test_empty_secret_warns(self, recwarn):
        _ = HoneypotConfig(secret_key="")
        assert len(recwarn) >= 1

    def test_from_yaml(self, tmp_path: Path):
        config_data = {
            "secret_key": "yaml-test-key",
            "suspicion_threshold": 0.8,
            "log_backend": "sqlite",
            "db_url": "sqlite+aiosqlite:///test.db",
            "watermark": {"strategies": ["unicode"], "global_seed": 42},
        }
        config_file = tmp_path / "test_config.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config_data, f)

        cfg = HoneypotConfig.from_yaml(config_file)
        assert cfg.suspicion_threshold == 0.8
        assert cfg.watermark.strategies == ["unicode"]

    def test_from_yaml_missing_file(self):
        with pytest.raises(ConfigurationError, match="not found"):
            HoneypotConfig.from_yaml("/nonexistent/path/config.yaml")

    def test_from_yaml_invalid_yaml(self, tmp_path: Path):
        bad_file = tmp_path / "bad.yaml"
        bad_file.write_text("{invalid: yaml: content::")
        with pytest.raises(ConfigurationError):
            HoneypotConfig.from_yaml(bad_file)

    def test_to_yaml_roundtrip(self, tmp_path: Path):
        cfg = HoneypotConfig(
            secret_key="roundtrip-key",
            suspicion_threshold=0.65,
            watermark=WatermarkConfig(strategies=["syntactic"], global_seed=7),
        )
        output = tmp_path / "output.yaml"
        cfg.to_yaml(output)
        reloaded = HoneypotConfig.from_yaml(output)
        assert reloaded.suspicion_threshold == 0.65
        assert reloaded.watermark.strategies == ["syntactic"]
        assert reloaded.watermark.global_seed == 7

    def test_trusted_keys_default_empty(self):
        cfg = HoneypotConfig(secret_key="k")
        assert cfg.trusted_keys == []


class TestScoringConfig:
    def test_weights_sum_exceeds_1_raises(self):
        with pytest.raises(Exception, match="weights sum"):
            ScoringConfig(
                rate_weight=0.5,
                sequential_weight=0.4,
                gap_weight=0.3,
                volume_weight=0.2,
            )

    def test_valid_weights(self):
        cfg = ScoringConfig(
            rate_weight=0.25,
            sequential_weight=0.25,
            gap_weight=0.25,
            volume_weight=0.25,
        )
        assert cfg.rate_weight == 0.25

    def test_threshold_defaults(self):
        cfg = ScoringConfig()
        assert cfg.requests_per_minute_threshold == 30
        assert cfg.requests_per_hour_threshold == 500


class TestWatermarkConfig:
    def test_empty_strategies_raises(self):
        with pytest.raises(Exception):
            WatermarkConfig(strategies=[])

    def test_invalid_strategy_passes_validation(self):
        # Pydantic should catch invalid Literal
        with pytest.raises(Exception):
            WatermarkConfig(strategies=["nonexistent"])  # type: ignore[list-item]

    def test_all_strategies_valid(self):
        cfg = WatermarkConfig(strategies=["lexical", "syntactic", "unicode"])
        assert len(cfg.strategies) == 3
