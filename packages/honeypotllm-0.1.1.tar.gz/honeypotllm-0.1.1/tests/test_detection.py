"""Tests for the detection module."""

from __future__ import annotations

import pytest

from honeypotllm.config import HoneypotConfig, WatermarkConfig
from honeypotllm.detection import Detector, DetectionReport
from honeypotllm.exceptions import DetectionError
from honeypotllm.watermark import WatermarkEngine


WATERMARK_ID_1 = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
WATERMARK_ID_2 = "11111111-2222-3333-4444-555555555555"

SAMPLE_TEXT = (
    "The training process for large language models involves significant "
    "computational overhead and careful hyperparameter tuning. "
    "Gradient checkpointing reduces memory usage at the cost of additional computation."
)


@pytest.fixture
def detector(minimal_config: HoneypotConfig) -> Detector:
    return Detector(minimal_config)


@pytest.fixture
def watermarked_texts(minimal_config: HoneypotConfig) -> list[str]:
    """Generate watermarked texts for WATERMARK_ID_1."""
    engine = WatermarkEngine(minimal_config.watermark)
    texts = []
    for i in range(5):
        result = engine.apply(f"{SAMPLE_TEXT} Variant {i}.", watermark_id=WATERMARK_ID_1)
        texts.append(result.watermarked_text)
    return texts


class TestDetector:
    def test_detect_correct_watermark_id(
        self, detector: Detector, watermarked_texts: list[str]
    ):
        report = detector.detect(
            texts=watermarked_texts,
            candidate_watermark_ids=[WATERMARK_ID_1, WATERMARK_ID_2],
        )
        assert report.all_candidates[0]["watermark_id"] == WATERMARK_ID_1

    def test_detect_empty_texts_raises(self, detector: Detector):
        with pytest.raises(DetectionError, match="empty"):
            detector.detect(texts=[], candidate_watermark_ids=[WATERMARK_ID_1])

    def test_detect_no_candidates_raises(self, detector: Detector):
        with pytest.raises(DetectionError, match="candidate"):
            detector.detect(texts=[SAMPLE_TEXT], candidate_watermark_ids=[])

    def test_report_fields(self, detector: Detector, watermarked_texts: list[str]):
        report = detector.detect(
            texts=watermarked_texts,
            candidate_watermark_ids=[WATERMARK_ID_1],
            target_model_name="Stolen Model v1",
        )
        assert isinstance(report, DetectionReport)
        assert report.num_texts == len(watermarked_texts)
        assert report.target_model_name == "Stolen Model v1"
        assert 0.0 <= report.overall_score <= 1.0
        assert report.confidence_level in ("low", "medium", "high")
        assert report.result_id != ""
        assert report.created_at != ""

    def test_report_to_dict(self, detector: Detector, watermarked_texts: list[str]):
        report = detector.detect(
            texts=watermarked_texts,
            candidate_watermark_ids=[WATERMARK_ID_1],
        )
        d = report.to_dict()
        assert "overall_score" in d
        assert "confidence_level" in d
        assert "attribution" in d

    def test_report_to_json(self, detector: Detector, watermarked_texts: list[str]):
        report = detector.detect(
            texts=watermarked_texts,
            candidate_watermark_ids=[WATERMARK_ID_1],
        )
        import json
        parsed = json.loads(report.to_json())
        assert "overall_score" in parsed

    def test_report_save_to_file(
        self, detector: Detector, watermarked_texts: list[str], tmp_path
    ):
        report = detector.detect(
            texts=watermarked_texts,
            candidate_watermark_ids=[WATERMARK_ID_1],
        )
        output = str(tmp_path / "report.json")
        report.save(output)
        from pathlib import Path
        assert Path(output).exists()

    def test_detect_single(self, detector: Detector, watermarked_texts: list[str]):
        score = detector.detect_single(
            texts=watermarked_texts,
            watermark_id=WATERMARK_ID_1,
        )
        assert 0.0 <= score.overall_score <= 1.0

    def test_is_attributed_false_when_score_low(self, detector: Detector):
        # Non-watermarked texts should not be attributed
        report = detector.detect(
            texts=[SAMPLE_TEXT] * 5,
            candidate_watermark_ids=[WATERMARK_ID_1],
        )
        # Score should be low for non-watermarked texts
        if report.overall_score < 0.60:
            assert not report.is_attributed

    def test_all_candidates_sorted_descending(
        self, detector: Detector, watermarked_texts: list[str]
    ):
        report = detector.detect(
            texts=watermarked_texts,
            candidate_watermark_ids=[WATERMARK_ID_1, WATERMARK_ID_2],
        )
        scores = [c["overall_score"] for c in report.all_candidates]
        assert scores == sorted(scores, reverse=True)
