"""
simple_protection.py
====================
The simplest possible honeypotllm integration — no framework needed.

Works with any Python HTTP server (aiohttp, httpx, raw asyncio, etc.).

Run:
    python simple_protection.py

What it demonstrates:
    1. Normal user  → real response returned unchanged
    2. Scraper bot  → response returned with invisible watermark injected
    3. Trusted key  → always bypassed (for your own internal services)
"""

from __future__ import annotations

import asyncio
import time

from honeypotllm import HoneypotMiddleware
from honeypotllm.config import HoneypotConfig, ScoringConfig, WatermarkConfig


async def main() -> None:
    # ── 1. Configure ────────────────────────────────────────────────────────────
    config = HoneypotConfig(
        secret_key="demo-secret-key-change-in-production",
        suspicion_threshold=0.65,
        watermark=WatermarkConfig(strategies=["unicode", "syntactic"]),
        scoring=ScoringConfig(
            requests_per_minute_threshold=10,  # Low for demo
            min_gap_seconds=0.5,
        ),
        trusted_keys=[],  # Put partner API key SHA-256 hashes here
        bypass_token="internal-service-secret",
    )

    # ── 2. Initialize ────────────────────────────────────────────────────────────
    honeypot = HoneypotMiddleware(config)
    await honeypot.init()
    print("🍯 Honeypot initialized\n")

    # ── Helper: simulate calling your real LLM ───────────────────────────────────
    def call_llm(prompt: str) -> str:
        return (
            f"This is a real response to: '{prompt}'. "
            "In production, this would be your actual LLM output."
        )

    # ── 3. Simulate a NORMAL user (1 request, organic pace) ─────────────────────
    print("=" * 60)
    print("SCENARIO A: Normal user — 1 request")
    print("=" * 60)

    result = await honeypot.process(
        api_key="normal-user-key",
        response_text=call_llm("What is machine learning?"),
        prompt="What is machine learning?",
    )
    print(f"Suspicion score : {result.suspicion_score:.4f}")
    print(f"Was watermarked : {result.was_watermarked}")
    print(f"Response        : {result.response_text[:80]}...")
    print()

    # ── 4. Simulate a SCRAPER (15 rapid sequential requests) ────────────────────
    print("=" * 60)
    print("SCENARIO B: Scraper — 15 rapid sequential requests")
    print("=" * 60)

    scraper_key = "scraper-bot-001"
    templates = [
        "What is {}?",
        "Explain {} in simple terms.",
        "Describe {}.",
        "Tell me about {}.",
        "What do you know about {}?",
    ]
    topics = ["Python", "Java", "C++", "Rust", "Go", "TypeScript", "Kotlin"]

    for i in range(15):
        prompt = templates[i % len(templates)].format(topics[i % len(topics)])
        result = await honeypot.process(
            api_key=scraper_key,
            response_text=call_llm(prompt),
            prompt=prompt,
        )
        status = "🚨 WATERMARKED" if result.was_watermarked else "✅ clean"
        print(
            f"  Request {i+1:02d} | score={result.suspicion_score:.3f} | "
            f"{status} | triggers={result.triggered_heuristics or 'none'}"
        )
        # No sleep — bot behaviour

    print()

    # ── 5. Check the scraper's final status ──────────────────────────────────────
    score = honeypot.get_suspicion_score(scraper_key)
    is_sus = honeypot.is_suspicious(scraper_key)
    print(f"Scraper final score : {score:.4f}")
    print(f"Is suspicious       : {is_sus}")
    print()

    # ── 6. Simulate a TRUSTED internal service (always bypasses) ─────────────────
    print("=" * 60)
    print("SCENARIO C: Internal service with bypass token")
    print("=" * 60)

    for _ in range(5):
        result = await honeypot.process(
            api_key="internal-batch-processor",
            response_text=call_llm("internal query"),
            prompt="internal query",
            bypass_token="internal-service-secret",  # Matches config.bypass_token
        )
        print(
            f"  score={result.suspicion_score:.3f} | "
            f"watermarked={result.was_watermarked} ← always False for trusted"
        )

    print()

    # ── 7. Summary of all tracked keys ───────────────────────────────────────────
    print("=" * 60)
    print("ALL TRACKED KEYS SUMMARY")
    print("=" * 60)
    for entry in honeypot.summary():
        print(
            f"  {entry['key_hash'][:12]}… | "
            f"score={entry['score']} | "
            f"suspicious={entry['is_suspicious']} | "
            f"requests={entry['total_requests']}"
        )

    await honeypot.close()
    print("\n✅ Done.")


if __name__ == "__main__":
    asyncio.run(main())
