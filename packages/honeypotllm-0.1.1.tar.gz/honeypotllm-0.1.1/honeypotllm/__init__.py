"""honeypotllm — LLM API protection via watermarking & behavioral fingerprinting.

Protect your AI API from data theft and unauthorized model replication.

Quickstart::

    from honeypotllm import HoneypotMiddleware

    honeypot = HoneypotMiddleware.from_yaml("honeypot_config.yaml")

    @app.post("/v1/chat/completions")
    async def chat(request: Request):
        response = await your_llm.generate(request)
        return await honeypot.process(request, response)

"""

from __future__ import annotations

from honeypotllm.__version__ import __version__
from honeypotllm.config import HoneypotConfig, ScoringConfig, WatermarkConfig
from honeypotllm.detection import Detector, DetectionReport
from honeypotllm.exceptions import (
    HoneypotError,
    ConfigurationError,
    WatermarkError,
    DetectionError,
    AuditLogError,
)
from honeypotllm.middleware import HoneypotMiddleware
from honeypotllm.scoring import SuspicionScorer
from honeypotllm.audit import AuditLogger

__all__ = [
    "__version__",
    # Config
    "HoneypotConfig",
    "ScoringConfig",
    "WatermarkConfig",
    # Core classes
    "HoneypotMiddleware",
    "SuspicionScorer",
    "Detector",
    "AuditLogger",
    # Results
    "DetectionReport",
    # Exceptions
    "HoneypotError",
    "ConfigurationError",
    "WatermarkError",
    "DetectionError",
    "AuditLogError",
]
