"""Abstract base class for all honeypotllm watermarking strategies.

Every strategy must implement:
- ``apply(text, seed)`` — embed a watermark into the text
- ``detect(texts, seed)`` — return a match score in [0.0, 1.0]

The ``seed`` is deterministically derived from the API key's watermark_id,
ensuring watermarks are unique per key and reproducible for detection.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class WatermarkResult:
    """Result of applying a watermark to a text."""

    original_text: str
    watermarked_text: str
    strategy: str
    seed: int
    changes_made: int = 0
    metadata: dict = field(default_factory=dict)

    @property
    def was_modified(self) -> bool:
        return self.original_text != self.watermarked_text


@dataclass
class DetectionScore:
    """Result of running watermark detection against a corpus of texts."""

    strategy: str
    score: float  # 0.0 = no match, 1.0 = certain match
    p_value: float | None = None
    num_texts: int = 0
    num_matches: int = 0
    metadata: dict = field(default_factory=dict)

    @property
    def confidence_level(self) -> str:
        if self.score >= 0.85:
            return "high"
        elif self.score >= 0.60:
            return "medium"
        return "low"


class WatermarkStrategy(ABC):
    """Abstract base for watermarking strategies.

    Args:
        name: Human-readable strategy identifier (e.g. ``"lexical"``).
    """

    name: str

    @abstractmethod
    def apply(self, text: str, seed: int) -> WatermarkResult:
        """Embed a watermark into ``text`` using ``seed`` as entropy.

        Args:
            text: The original LLM response text to watermark.
            seed: A deterministic integer seed derived from the API key's watermark_id.
                  Must produce identical output for identical (text, seed) pairs.

        Returns:
            A :class:`WatermarkResult` describing the transformation.
        """
        ...

    @abstractmethod
    def detect(self, texts: list[str], seed: int) -> DetectionScore:
        """Measure how strongly a corpus of texts matches the given seed's watermark.

        Args:
            texts: Outputs from a suspected stolen model.
            seed:  The seed expected for the watermarked key being investigated.

        Returns:
            A :class:`DetectionScore` with a match score in ``[0.0, 1.0]``.
        """
        ...

    def derive_key_seed(self, global_seed: int, watermark_id: str) -> int:
        """Combine the global seed with a per-key ``watermark_id`` into a unique integer seed.

        Uses a deterministic hash so the same (global_seed, watermark_id) always
        produces the same per-key seed.

        Args:
            global_seed: The master seed from :class:`~honeypotllm.config.WatermarkConfig`.
            watermark_id: A UUID string unique to the API key.

        Returns:
            A deterministic integer seed unique to this key.
        """
        import hashlib

        raw = f"{global_seed}:{watermark_id}:{self.name}".encode()
        digest = hashlib.sha256(raw).digest()
        # Take first 8 bytes → unsigned 64-bit int, mod down to fit in Python random seed
        return int.from_bytes(digest[:8], "big") % (2**31)
