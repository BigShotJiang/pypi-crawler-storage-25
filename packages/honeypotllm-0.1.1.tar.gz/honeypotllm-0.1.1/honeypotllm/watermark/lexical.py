"""Lexical substitution watermarking strategy.

Replaces eligible words in the response with semantically equivalent synonyms
chosen via a seeded pseudorandom process.  The same (text, seed) pair always
produces the same output, which is critical for forensic attribution.

Detection is based on a chi-squared frequency test: watermarked text will
show a statistically anomalous preference for the rare synonyms selected by
the seeded substitution table.

Dependencies: ``nltk`` (WordNet + tokenization).
"""

from __future__ import annotations

import logging
import random
import re
import string
from collections import defaultdict
from typing import TYPE_CHECKING

from honeypotllm.watermark.base import DetectionScore, WatermarkResult, WatermarkStrategy

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# POS tags that WordNet handles well and are safe to substitute
_ELIGIBLE_POS = frozenset({"NN", "NNS", "VB", "VBP", "VBZ", "JJ", "RB"})

# Map Penn Treebank tags → WordNet POS
_POS_MAP = {
    "NN": "n",
    "NNS": "n",
    "VB": "v",
    "VBP": "v",
    "VBZ": "v",
    "JJ": "a",
    "RB": "r",
}


def _ensure_nltk_data() -> None:
    """Download required NLTK corpora on first use (idempotent)."""
    import nltk

    for resource in ("wordnet", "averaged_perceptron_tagger", "punkt", "punkt_tab"):
        try:
            nltk.data.find(f"tokenizers/{resource}" if "punkt" in resource else f"corpora/{resource}")
        except LookupError:
            logger.info("Downloading NLTK resource: %s", resource)
            nltk.download(resource, quiet=True)


def _get_synonyms(word: str, pos: str) -> list[str]:
    """Return synonyms for *word* from WordNet (same POS, different lemma)."""
    from nltk.corpus import wordnet as wn  # type: ignore[import-untyped]

    synonyms: set[str] = set()
    for synset in wn.synsets(word, pos=pos):
        for lemma in synset.lemmas():
            candidate = lemma.name().replace("_", " ")
            if candidate.lower() != word.lower() and " " not in candidate:
                synonyms.add(candidate)
    return sorted(synonyms)


def _tokenize(text: str) -> list[str]:
    """Tokenize *text* into words + whitespace/punctuation tokens."""
    # Split on word boundaries, preserving delimiters for reconstruction
    return re.split(r"(\W+)", text)


class LexicalWatermarkStrategy(WatermarkStrategy):
    """WordNet-based lexical substitution watermarker.

    Args:
        substitution_rate: Fraction of eligible words to replace (0.01–0.5).
        min_word_length:  Minimum word length to consider for substitution.
        eligible_pos_tags: Penn Treebank POS tags eligible for substitution.
    """

    name = "lexical"

    def __init__(
        self,
        substitution_rate: float = 0.15,
        min_word_length: int = 4,
        eligible_pos_tags: list[str] | None = None,
    ) -> None:
        self.substitution_rate = substitution_rate
        self.min_word_length = min_word_length
        self.eligible_pos_tags = frozenset(eligible_pos_tags or _ELIGIBLE_POS)

    def apply(self, text: str, seed: int) -> WatermarkResult:  # noqa: D102
        _ensure_nltk_data()
        import nltk  # type: ignore[import-untyped]

        rng = random.Random(seed)
        tokens = nltk.word_tokenize(text)
        pos_tags: list[tuple[str, str]] = nltk.pos_tag(tokens)

        result_tokens: list[str] = []
        changes = 0
        seen: dict[str, str] = {}  # cache: original → chosen synonym (per-seed)

        for word, pos in pos_tags:
            if (
                pos in self.eligible_pos_tags
                and len(word) >= self.min_word_length
                and word.lower() not in string.punctuation
                and rng.random() < self.substitution_rate
            ):
                wn_pos = _POS_MAP.get(pos)
                if wn_pos is None:
                    result_tokens.append(word)
                    continue

                cache_key = f"{word.lower()}:{wn_pos}:{seed}"
                if cache_key in seen:
                    synonym = seen[cache_key]
                else:
                    synonyms = _get_synonyms(word.lower(), wn_pos)
                    if synonyms:
                        synonym = rng.choice(synonyms)
                        # Preserve original capitalization
                        if word[0].isupper():
                            synonym = synonym.capitalize()
                        seen[cache_key] = synonym
                    else:
                        result_tokens.append(word)
                        continue

                result_tokens.append(synonym)
                changes += 1
            else:
                result_tokens.append(word)

        # Reconstruct — NLTK tokenizer splits on spaces, so rejoin with spaces
        # Use original text's whitespace structure where possible
        watermarked = self._detokenize(result_tokens, text)

        return WatermarkResult(
            original_text=text,
            watermarked_text=watermarked,
            strategy=self.name,
            seed=seed,
            changes_made=changes,
        )

    def detect(self, texts: list[str], seed: int) -> DetectionScore:  # noqa: D102
        """Estimate match score by checking if tokens match the seed-expected synonyms.

        Uses a simple ratio: (tokens matching expected synonym) / (eligible tokens).
        """
        _ensure_nltk_data()
        import nltk  # type: ignore[import-untyped]

        rng = random.Random(seed)
        total_eligible = 0
        total_matches = 0

        for text in texts:
            tokens = nltk.word_tokenize(text)
            pos_tags: list[tuple[str, str]] = nltk.pos_tag(tokens)

            for word, pos in pos_tags:
                if pos not in self.eligible_pos_tags or len(word) < self.min_word_length:
                    continue
                wn_pos = _POS_MAP.get(pos)
                if wn_pos is None:
                    continue

                # Check if this word is a synonym that would have been chosen
                synonyms = _get_synonyms(word.lower(), wn_pos)
                if not synonyms:
                    continue

                total_eligible += 1
                # Expected synonym for this word at this seed position
                expected = rng.choice(synonyms)
                if word.lower() == expected.lower():
                    total_matches += 1

        if total_eligible == 0:
            return DetectionScore(strategy=self.name, score=0.0, num_texts=len(texts))

        score = total_matches / total_eligible
        return DetectionScore(
            strategy=self.name,
            score=min(score * 3.0, 1.0),  # amplify: expected random baseline is ~1/N
            num_texts=len(texts),
            num_matches=total_matches,
            metadata={"eligible_tokens": total_eligible},
        )

    @staticmethod
    def _detokenize(tokens: list[str], original: str) -> str:
        """Reconstruct text from NLTK word_tokenize output.

        NLTK's word_tokenize splits contractions and punctuation; this method
        attempts a faithful reconstruction using the original whitespace pattern.
        """
        try:
            from nltk.tokenize.treebank import TreebankWordDetokenizer  # type: ignore[import-untyped]

            return TreebankWordDetokenizer().detokenize(tokens)
        except Exception:
            return " ".join(tokens)


def build_substitution_table(
    vocab: list[str], seed: int, rate: float = 0.15
) -> dict[str, str]:
    """Pre-build a word substitution table for a given seed.

    Useful for batch processing or caching the watermark table.

    Args:
        vocab: List of candidate words to potentially substitute.
        seed:  Key-specific seed.
        rate:  Fraction of vocab to include in the table.

    Returns:
        Mapping of ``{original_word: synonym}``.
    """
    _ensure_nltk_data()

    rng = random.Random(seed)
    table: dict[str, str] = {}

    import nltk  # type: ignore[import-untyped]

    pos_tags: list[tuple[str, str]] = nltk.pos_tag(vocab)

    for word, pos in pos_tags:
        if rng.random() > rate:
            continue
        wn_pos = _POS_MAP.get(pos)
        if wn_pos is None:
            continue
        synonyms = _get_synonyms(word.lower(), wn_pos)
        if synonyms:
            table[word.lower()] = rng.choice(synonyms)

    return table


def _compute_chi_squared(observed: dict[str, int], expected: dict[str, float]) -> float:
    """Compute chi-squared statistic for observed vs expected frequencies."""
    chi2 = 0.0
    for word, obs in observed.items():
        exp = expected.get(word, 0.0)
        if exp > 0:
            chi2 += (obs - exp) ** 2 / exp
    return chi2
