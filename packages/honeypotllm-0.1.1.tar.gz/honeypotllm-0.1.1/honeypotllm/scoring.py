"""Suspicion scoring engine.

Computes a suspicion score in [0.0, 1.0] for each API key based on observed
request behaviour.  The score is updated on every request and compared against
the configured threshold to decide whether to watermark responses.

Heuristics:
- **rate_heuristic**: Sustained high request rate (requests/min/hour/day).
- **sequential_heuristic**: Consecutive inputs with high Jaccard similarity
  (indicator of dataset enumeration).
- **gap_heuristic**: No pauses between requests (organic users pause; scrapers don't).
- **volume_heuristic**: Total request volume disproportionate to typical API usage.

Score decay: scores decrease over time when no suspicious activity is detected,
allowing a key to return to normal status after cooling off.

All state is in-memory for performance.  Persistent state (SuspicionEvent records)
is written to the database by the middleware via the AuditLogger.
"""

from __future__ import annotations

import hashlib
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import TypedDict

from honeypotllm.config import ScoringConfig

logger = logging.getLogger(__name__)

# Maximum number of API keys tracked in memory.
# When exceeded, the least-recently-seen keys are evicted (LRU).
_MAX_TRACKED_KEYS = 10_000

# Chars of prompt stored for sequential detection (privacy: never store full prompts)
_PROMPT_SNIPPET_LEN = 120


class RequestRecord(TypedDict):
    """A single recorded API request from a key."""

    timestamp: float
    input_tokens: int
    input_text_hash: str  # SHA-256 of the prompt (kept for reference)


@dataclass
class ScoringState:
    """In-memory scoring state for a single API key."""

    key_hash: str
    score: float = 0.0
    total_requests: int = 0
    last_seen: float = field(default_factory=time.time)
    # Rolling windows (deque with maxlen for O(1) pops)
    window_1min: deque[float] = field(default_factory=lambda: deque())
    window_1hour: deque[float] = field(default_factory=lambda: deque())
    window_1day: deque[float] = field(default_factory=lambda: deque())
    # Last N prompt SNIPPETS for sequential detection (not hashes — see fix notes)
    # Only the first _PROMPT_SNIPPET_LEN chars are stored for privacy.
    recent_prompts: deque[str] = field(default_factory=lambda: deque(maxlen=10))
    # Triggered heuristics for the last request
    triggered_heuristics: list[str] = field(default_factory=list)


@dataclass
class ScoringResult:
    """Output of the scoring engine for a single request."""

    key_hash: str
    score_before: float
    score_after: float
    score_delta: float
    triggered_heuristics: list[str]
    should_honeypot: bool

    @property
    def escalated(self) -> bool:
        """True if this request pushed the key into honeypot mode."""
        return not (self.score_before >= 0) and self.should_honeypot


def _sha256_short(text: str) -> str:
    """Return the first 16 hex chars of the SHA-256 digest of *text*."""
    return hashlib.sha256(text.encode()).hexdigest()[:16]


def _word_bigram_shingles(text: str) -> set[str]:
    """Return the set of word-level bigram shingles from *text*.

    Example::

        _word_bigram_shingles("what is python") == {"what is", "is python"}

    Using bigrams (pairs of consecutive words) gives much better sensitivity
    than character-level Jaccard for detecting semantically similar prompts.
    """
    words = text.lower().split()
    if len(words) < 2:
        return set(words)  # Fallback: unigrams for very short prompts
    return {f"{words[i]} {words[i+1]}" for i in range(len(words) - 1)}


def _jaccard_similarity(a: str, b: str) -> float:
    """Word-bigram Jaccard similarity between two prompt snippets.

    Returns a value in [0.0, 1.0] where:
    - ``1.0`` means the prompts are identical
    - ``0.0`` means the prompts share no common word bigrams

    This correctly identifies sequential enumeration (e.g. 'What is Python?'
    vs 'What is Java?' share the bigram 'what is' → similarity ≈ 0.33)
    while returning ~0.0 for completely unrelated prompts.

    .. note::
        Previous versions compared SHA-256 hex hashes using character-level
        Jaccard, which was non-functional because all hex strings share the
        same character alphabet {0-9a-f}. This fix uses the actual prompt text.
    """
    if not a and not b:
        return 1.0
    shingles_a = _word_bigram_shingles(a)
    shingles_b = _word_bigram_shingles(b)
    if not shingles_a and not shingles_b:
        return 1.0
    intersection = len(shingles_a & shingles_b)
    union = len(shingles_a | shingles_b)
    return intersection / union if union else 0.0


def _hash_api_key(raw_key: str) -> str:
    """Return SHA-256 hex digest of an API key. The raw key is NEVER stored."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


class SuspicionScorer:
    """Stateful, in-memory suspicion scoring engine.

    Args:
        config: A :class:`~honeypotllm.config.ScoringConfig` instance.
        suspicion_threshold: Score above which a key is considered suspicious.
    """

    def __init__(self, config: ScoringConfig, suspicion_threshold: float = 0.75) -> None:
        self.config = config
        self.threshold = suspicion_threshold
        self._states: dict[str, ScoringState] = {}

    # ─── Public API ───────────────────────────────────────────────────────────

    def score_request(
        self,
        key_hash: str,
        *,
        prompt: str = "",
        input_tokens: int = 0,
        trusted: bool = False,
    ) -> ScoringResult:
        """Update and return the suspicion score for ``key_hash`` given a new request.

        Args:
            key_hash:     SHA-256 hash of the API key.
            prompt:       The user's prompt text (used for sequential detection).
            input_tokens: Token count (used for volume heuristics).
            trusted:      If True, skip scoring (always returns score=0.0).

        Returns:
            A :class:`ScoringResult` with the old and new scores.
        """
        if trusted:
            return ScoringResult(
                key_hash=key_hash,
                score_before=0.0,
                score_after=0.0,
                score_delta=0.0,
                triggered_heuristics=[],
                should_honeypot=False,
            )

        state = self._get_or_create(key_hash)
        score_before = state.score
        now = time.time()

        # Apply score decay for elapsed inactivity
        self._apply_decay(state, now)

        # Record the request
        state.total_requests += 1
        state.last_seen = now
        # Store a short snippet of the prompt for sequential detection.
        # We never store the full prompt — only the first _PROMPT_SNIPPET_LEN chars.
        prompt_snippet = prompt[:_PROMPT_SNIPPET_LEN] if prompt else ""

        # Update sliding windows
        self._update_windows(state, now)

        # Compute score contributions from each heuristic
        triggered: list[str] = []
        delta = 0.0

        rate_contribution = self._rate_heuristic(state)
        if rate_contribution > 0:
            delta += rate_contribution * self.config.rate_weight
            triggered.append(f"rate_spike(+{rate_contribution:.2f})")

        seq_contribution = self._sequential_heuristic(state, prompt_snippet)
        if seq_contribution > 0:
            delta += seq_contribution * self.config.sequential_weight
            triggered.append(f"sequential_input(+{seq_contribution:.2f})")

        gap_contribution = self._gap_heuristic(state, now)
        if gap_contribution > 0:
            delta += gap_contribution * self.config.gap_weight
            triggered.append(f"no_gap(+{gap_contribution:.2f})")

        vol_contribution = self._volume_heuristic(state)
        if vol_contribution > 0:
            delta += vol_contribution * self.config.volume_weight
            triggered.append(f"high_volume(+{vol_contribution:.2f})")

        # Update state — append snippet AFTER computing sequential score
        if prompt_snippet:
            state.recent_prompts.append(prompt_snippet)

        new_score = min(state.score + delta, 1.0)
        state.score = new_score
        state.triggered_heuristics = triggered

        logger.debug(
            "Scored key %s…: before=%.3f after=%.3f delta=%.3f triggers=%s",
            key_hash[:8],
            score_before,
            new_score,
            delta,
            triggered,
        )

        return ScoringResult(
            key_hash=key_hash,
            score_before=score_before,
            score_after=new_score,
            score_delta=delta,
            triggered_heuristics=triggered,
            should_honeypot=new_score >= self.threshold,
        )

    def get_score(self, key_hash: str) -> float:
        """Return the current suspicion score for a key (0.0 if unseen)."""
        return self._states.get(key_hash, ScoringState(key_hash=key_hash)).score

    def is_suspicious(self, key_hash: str) -> bool:
        """Return True if the key's score exceeds the suspicion threshold."""
        return self.get_score(key_hash) >= self.threshold

    def reset(self, key_hash: str) -> None:
        """Manually reset a key's score to 0.0 (e.g. after human review)."""
        if key_hash in self._states:
            self._states[key_hash].score = 0.0
            self._states[key_hash].triggered_heuristics = []
            logger.info("Score reset for key %s…", key_hash[:8])

    def summary(self) -> list[dict]:
        """Return a serialisable summary of all tracked keys."""
        return [
            {
                "key_hash": s.key_hash,
                "score": round(s.score, 4),
                "total_requests": s.total_requests,
                "last_seen": s.last_seen,
                "is_suspicious": s.score >= self.threshold,
                "triggered": s.triggered_heuristics,
            }
            for s in self._states.values()
        ]

    @staticmethod
    def hash_key(raw_key: str) -> str:
        """Public helper to hash an API key before passing to the scorer."""
        return _hash_api_key(raw_key)

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _get_or_create(self, key_hash: str) -> ScoringState:
        if key_hash not in self._states:
            # Evict least-recently-seen key if at memory limit
            if len(self._states) >= _MAX_TRACKED_KEYS:
                lrs_key = min(self._states, key=lambda k: self._states[k].last_seen)
                del self._states[lrs_key]
                logger.warning(
                    "ScoringState LRU eviction: removed key %s… (limit=%d)",
                    lrs_key[:8],
                    _MAX_TRACKED_KEYS,
                )
            self._states[key_hash] = ScoringState(key_hash=key_hash)
        return self._states[key_hash]

    def _apply_decay(self, state: ScoringState, now: float) -> None:
        """Reduce score based on time elapsed since last request."""
        elapsed_hours = (now - state.last_seen) / 3600.0
        decay = elapsed_hours * self.config.score_decay_rate
        state.score = max(0.0, state.score - decay)

    def _update_windows(self, state: ScoringState, now: float) -> None:
        """Add current timestamp to rolling windows and purge stale entries."""
        state.window_1min.append(now)
        state.window_1hour.append(now)
        state.window_1day.append(now)

        cutoffs = (now - 60, now - 3600, now - 86400)
        for window, cutoff in zip(
            [state.window_1min, state.window_1hour, state.window_1day], cutoffs
        ):
            while window and window[0] < cutoff:
                window.popleft()

    def _rate_heuristic(self, state: ScoringState) -> float:
        """Return a [0.0, 1.0] signal based on sustained request rate."""
        rpm = len(state.window_1min)
        rph = len(state.window_1hour)
        rpd = len(state.window_1day)

        score = 0.0
        if rpm > self.config.requests_per_minute_threshold:
            score = max(
                score, min((rpm - self.config.requests_per_minute_threshold) / rpm, 1.0)
            )
        if rph > self.config.requests_per_hour_threshold:
            score = max(
                score, min((rph - self.config.requests_per_hour_threshold) / rph, 1.0)
            )
        if rpd > self.config.requests_per_day_threshold:
            score = max(
                score, min((rpd - self.config.requests_per_day_threshold) / rpd, 1.0)
            )
        return round(score, 4)

    def _sequential_heuristic(self, state: ScoringState, current_prompt: str) -> float:
        """Return a signal if recent prompts look like sequential dataset enumeration.

        Uses word-bigram Jaccard similarity on actual prompt snippets.
        Requires at least 3 prior prompts before activating.

        Scrapers iterating a dataset will send prompts like:
            'What is Python?' → 'What is Java?' → 'What is C++?'
        These share the bigram 'what is', giving similarity ≈ 0.33.

        Real users ask diverse questions with near-zero bigram overlap.
        """
        if len(state.recent_prompts) < 3 or not current_prompt:
            return 0.0
        last_prompt = state.recent_prompts[-1]
        sim = _jaccard_similarity(current_prompt, last_prompt)
        if sim >= self.config.sequential_input_similarity_threshold:
            return round(sim, 4)
        return 0.0

    def _gap_heuristic(self, state: ScoringState, now: float) -> float:
        """Return a signal if the request came in with no human-scale pause."""
        if state.total_requests < 5:
            return 0.0  # Not enough history
        if len(state.window_1min) < 2:
            return 0.0
        # Check gap between the previous and current request
        recent = sorted(state.window_1min)
        if len(recent) < 2:
            return 0.0
        last_gap = recent[-1] - recent[-2]
        if last_gap < self.config.min_gap_seconds:
            # Normalize: shorter gap → stronger signal
            return round(
                max(0.0, 1.0 - (last_gap / self.config.min_gap_seconds)), 4
            )
        return 0.0

    def _volume_heuristic(self, state: ScoringState) -> float:
        """Return a signal based on disproportionate total request volume."""
        # Normalized against day threshold; anything above 2× threshold is suspicious
        daily_volume = len(state.window_1day)
        threshold = self.config.requests_per_day_threshold
        if daily_volume > threshold * 2:
            return min((daily_volume - threshold * 2) / (threshold * 8), 1.0)
        return 0.0
