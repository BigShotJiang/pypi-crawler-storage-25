"""Custom exception hierarchy for honeypotllm.

All public exceptions inherit from :class:`HoneypotError` so callers can
catch the entire family with a single ``except HoneypotError`` clause.
"""

from __future__ import annotations


class HoneypotError(Exception):
    """Base class for all honeypotllm errors."""


class ConfigurationError(HoneypotError):
    """Raised when configuration is invalid or missing required fields."""


class WatermarkError(HoneypotError):
    """Raised when a watermarking strategy fails to apply or detect."""


class DetectionError(HoneypotError):
    """Raised when the detection pipeline encounters an unrecoverable error."""


class AuditLogError(HoneypotError):
    """Raised when the audit log cannot be written or its integrity is broken."""


class FingerprintError(HoneypotError):
    """Raised when behavioral fingerprinting encounters an error."""


class ScoringError(HoneypotError):
    """Raised when the suspicion scoring engine encounters an error."""
