"""SQLAlchemy 2.0 ORM models for honeypotllm's audit database.

Mirrors the conceptual data model from the project specification.
Uses async-compatible declarative base.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""


# ─── API Key Profile ──────────────────────────────────────────────────────────


class APIKeyProfile(Base):
    """Tracks suspicion state and watermark assignment per API key.

    Notes:
        - ``key_hash`` stores SHA-256(raw_api_key) — never the raw key.
        - ``watermark_id`` is unique per key and drives per-key watermark seeds.
    """

    __tablename__ = "api_key_profiles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    key_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    watermark_id: Mapped[str] = mapped_column(
        String(36),
        unique=True,
        nullable=False,
        default=lambda: str(uuid.uuid4()),
    )
    first_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )
    total_requests: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    suspicion_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    is_honeypotted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_trusted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    suspicion_events: Mapped[list["SuspicionEvent"]] = relationship(
        "SuspicionEvent", back_populates="api_key_profile", cascade="all, delete-orphan"
    )
    watermark_records: Mapped[list["WatermarkRecord"]] = relationship(
        "WatermarkRecord", back_populates="api_key_profile", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return (
            f"APIKeyProfile(key_hash={self.key_hash[:8]}…, "
            f"score={self.suspicion_score:.2f}, "
            f"honeypotted={self.is_honeypotted})"
        )


# ─── Watermark Record ─────────────────────────────────────────────────────────


class WatermarkRecord(Base):
    """Records a watermarking event — which strategy was applied and when.

    Notes:
        - ``seed`` is the per-application seed (deterministic for attribution).
        - ``sample_responses_enc`` stores AES-256-GCM encrypted response samples.
    """

    __tablename__ = "watermark_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    watermark_uuid: Mapped[str] = mapped_column(
        String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4())
    )
    api_key_profile_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("api_key_profiles.id", ondelete="CASCADE"), nullable=False, index=True
    )
    strategy_used: Mapped[str] = mapped_column(String(64), nullable=False)
    seed: Mapped[str] = mapped_column(String(128), nullable=False)
    applied_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    sample_responses_enc: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    api_key_profile: Mapped["APIKeyProfile"] = relationship(
        "APIKeyProfile", back_populates="watermark_records"
    )

    def __repr__(self) -> str:
        return f"WatermarkRecord(uuid={self.watermark_uuid[:8]}…, strategy={self.strategy_used})"


# ─── Suspicion Event ─────────────────────────────────────────────────────────


class SuspicionEvent(Base):
    """Records an individual signal that changed a key's suspicion score."""

    __tablename__ = "suspicion_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event_uuid: Mapped[str] = mapped_column(
        String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4())
    )
    api_key_profile_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("api_key_profiles.id", ondelete="CASCADE"), nullable=False, index=True
    )
    event_type: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment="e.g. rate_spike | sequential_input | gap_missing | volume_threshold",
    )
    score_before: Mapped[float] = mapped_column(Float, nullable=False)
    score_after: Mapped[float] = mapped_column(Float, nullable=False)
    score_delta: Mapped[float] = mapped_column(Float, nullable=False)
    metadata_: Mapped[Optional[dict]] = mapped_column("metadata", JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    api_key_profile: Mapped["APIKeyProfile"] = relationship(
        "APIKeyProfile", back_populates="suspicion_events"
    )

    def __repr__(self) -> str:
        return (
            f"SuspicionEvent(type={self.event_type}, "
            f"delta={self.score_delta:+.3f}, "
            f"score_after={self.score_after:.3f})"
        )


# ─── Audit Log Entry ─────────────────────────────────────────────────────────


class AuditLogEntry(Base):
    """A single HMAC-chained audit log entry."""

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    entry_uuid: Mapped[str] = mapped_column(
        String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4())
    )
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    timestamp_iso: Mapped[Optional[str]] = mapped_column(
        String(64), nullable=True,
        comment="Exact ISO 8601 string used in HMAC computation. Avoids round-trip formatting bugs."
    )
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    api_key_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    prev_entry_uuid: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    prev_hmac: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    entry_hmac: Mapped[str] = mapped_column(String(128), nullable=False)

    def __repr__(self) -> str:
        return f"AuditLogEntry(uuid={self.entry_uuid[:8]}…, type={self.event_type})"


# ─── Detection Result ─────────────────────────────────────────────────────────


class DetectionResultRecord(Base):
    """Persisted result of a watermark detection run."""

    __tablename__ = "detection_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    result_uuid: Mapped[str] = mapped_column(
        String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4())
    )
    target_model_name: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    num_probe_inputs: Mapped[int] = mapped_column(Integer, nullable=False)
    watermark_match_score: Mapped[float] = mapped_column(Float, nullable=False)
    attributed_watermark_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    confidence_level: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        comment="low | medium | high",
    )
    strategy_scores: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    forensic_report_path: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    def __repr__(self) -> str:
        return (
            f"DetectionResultRecord(uuid={self.result_uuid[:8]}…, "
            f"score={self.watermark_match_score:.3f}, "
            f"confidence={self.confidence_level})"
        )
