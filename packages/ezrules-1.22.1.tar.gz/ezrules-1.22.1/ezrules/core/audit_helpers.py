"""
Helper functions for recording audit trail entries.

These functions create history records for user lists, outcomes, and labels
whenever mutations occur. They should be called from the API routes before
or after the mutation, depending on the action type.
"""

import datetime

from ezrules.models.backend_core import (
    AIRuleAuthoringHistory,
    AlertRuleHistory,
    ApiKeyHistory,
    FeatureDefinitionHistory,
    FieldTypeHistory,
    LabelHistory,
    OutcomeHistory,
    RolePermissionHistory,
    StrictModeHistory,
    UserAccountHistory,
    UserListHistory,
)


def save_user_list_history(
    db,
    ul_id: int,
    list_name: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
) -> None:
    """Record an audit entry for a user list action."""
    history = UserListHistory(
        ul_id=ul_id,
        list_name=list_name,
        action=action,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_outcome_history(
    db,
    ao_id: int,
    outcome_name: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
) -> None:
    """Record an audit entry for an outcome action."""
    history = OutcomeHistory(
        ao_id=ao_id,
        outcome_name=outcome_name,
        action=action,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_label_history(
    db,
    el_id: int,
    label: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
) -> None:
    """Record an audit entry for a label action."""
    history = LabelHistory(
        el_id=el_id,
        label=label,
        action=action,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_user_account_history(
    db,
    user_id: int,
    user_email: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
) -> None:
    """Record an audit entry for a user account action."""
    history = UserAccountHistory(
        user_id=user_id,
        user_email=user_email,
        action=action,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_field_type_history(
    db,
    field_name: str,
    configured_type: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
    datetime_format: str | None = None,
    required: bool = False,
) -> None:
    """Record an audit entry for a field type config action."""
    history = FieldTypeHistory(
        field_name=field_name,
        configured_type=configured_type,
        datetime_format=datetime_format,
        required=required,
        action=action,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_feature_definition_history(
    db,
    fd_id: int,
    entity: str,
    feature_name: str,
    action: str,
    version: int,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
) -> None:
    """Record an audit entry for a feature definition action."""
    history = FeatureDefinitionHistory(
        fd_id=fd_id,
        entity=entity,
        feature_name=feature_name,
        action=action,
        version=version,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_api_key_history(
    db,
    api_key_gid: str,
    label: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
) -> None:
    """Record an audit entry for an API key action."""
    history = ApiKeyHistory(
        api_key_gid=api_key_gid,
        label=label,
        action=action,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_ai_rule_authoring_history(
    db,
    generation_id: str,
    action: str,
    mode: str,
    evaluation_lane: str,
    provider: str,
    model: str,
    prompt_hash: str,
    validation_status: str,
    repair_attempted: bool,
    applyable: bool,
    o_id: int,
    r_id: int | None = None,
    prompt_excerpt: str | None = None,
    changed_by: str | None = None,
) -> None:
    """Record an audit entry for AI-assisted rule authoring activity."""
    history = AIRuleAuthoringHistory(
        generation_id=generation_id,
        r_id=r_id,
        action=action,
        mode=mode,
        evaluation_lane=evaluation_lane,
        provider=provider,
        model=model,
        prompt_excerpt=prompt_excerpt,
        prompt_hash=prompt_hash,
        validation_status=validation_status,
        repair_attempted=repair_attempted,
        applyable=applyable,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_role_history(
    db,
    role_id: int,
    role_name: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
) -> None:
    """Record an audit entry for a role or permission action."""
    history = RolePermissionHistory(
        role_id=role_id,
        role_name=role_name,
        action=action,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_strict_mode_history(
    db,
    enabled: bool,
    action: str,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
) -> None:
    """Record an audit entry for a strict mode state change."""
    history = StrictModeHistory(
        enabled=enabled,
        action=action,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)


def save_alert_rule_history(
    db,
    alert_rule_id: int,
    name: str,
    action: str,
    o_id: int,
    changed_by: str | None = None,
    details: str | None = None,
) -> None:
    """Record an audit entry for an alert rule action."""
    history = AlertRuleHistory(
        alert_rule_id=alert_rule_id,
        name=name,
        action=action,
        details=details,
        o_id=o_id,
        changed=datetime.datetime.now(datetime.UTC),
        changed_by=changed_by,
    )
    db.add(history)
