"""
FastAPI routes for audit trail.

These endpoints provide access to the version history of rules and configurations.
All endpoints require authentication and ACCESS_AUDIT_TRAIL permission.
"""

from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ezrules.backend.api_v2.auth.dependencies import (
    get_current_active_user,
    get_current_org_id,
    get_db,
    require_permission,
)
from ezrules.backend.api_v2.schemas.audit import (
    AIRuleAuthoringAuditListResponse,
    AIRuleAuthoringHistoryEntry,
    ApiKeyAuditListResponse,
    ApiKeyHistoryEntry,
    AuditSummaryResponse,
    ConfigAuditListResponse,
    FeatureDefinitionAuditListResponse,
    FeatureDefinitionHistoryEntry,
    FieldTypeAuditListResponse,
    FieldTypeHistoryEntry,
    LabelAuditListResponse,
    LabelHistoryEntry,
    OutcomeAuditListResponse,
    OutcomeHistoryEntry,
    RolePermissionAuditListResponse,
    RolePermissionHistoryEntry,
    RuleAuditResponse,
    RuleEngineConfigHistoryEntry,
    RuleHistoryEntry,
    RulesAuditListResponse,
    StrictModeAuditListResponse,
    StrictModeHistoryEntry,
    UserAccountAuditListResponse,
    UserAccountHistoryEntry,
    UserListAuditListResponse,
    UserListHistoryEntry,
)
from ezrules.core.permissions_constants import PermissionAction
from ezrules.models.backend_core import (
    AIRuleAuthoringHistory,
    ApiKeyHistory,
    FeatureDefinitionHistory,
    FieldTypeHistory,
    LabelHistory,
    OutcomeHistory,
    RolePermissionHistory,
    Rule,
    RuleEngineConfigHistory,
    RuleHistory,
    StrictModeHistory,
    User,
    UserAccountHistory,
    UserListHistory,
)

router = APIRouter(prefix="/api/v2/audit", tags=["Audit Trail"])


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================


def rule_history_to_response(history: RuleHistory) -> RuleHistoryEntry:
    """Convert a rule history record to API response."""
    changed = history.changed if history.changed is not None else None

    return RuleHistoryEntry(
        r_id=int(history.r_id),
        rid=str(history.rid),
        version=int(history.version),
        logic=str(history.logic),
        description=str(history.description),
        execution_order=int(history.execution_order),
        action=str(history.action),
        status=history.status,
        to_status=history.to_status,
        effective_from=history.effective_from if history.effective_from is not None else None,  # type: ignore[arg-type]
        changed=changed,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def user_list_history_to_response(history: UserListHistory) -> UserListHistoryEntry:
    """Convert a user list history record to API response."""
    return UserListHistoryEntry(
        id=int(history.id),
        ul_id=int(history.ul_id),
        list_name=str(history.list_name),
        action=str(history.action),
        details=str(history.details) if history.details else None,
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def outcome_history_to_response(history: OutcomeHistory) -> OutcomeHistoryEntry:
    """Convert an outcome history record to API response."""
    return OutcomeHistoryEntry(
        id=int(history.id),
        ao_id=int(history.ao_id),
        outcome_name=str(history.outcome_name),
        action=str(history.action),
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def label_history_to_response(history: LabelHistory) -> LabelHistoryEntry:
    """Convert a label history record to API response."""
    return LabelHistoryEntry(
        id=int(history.id),
        el_id=int(history.el_id),
        label=str(history.label),
        action=str(history.action),
        details=str(history.details) if history.details else None,
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def user_account_history_to_response(history: UserAccountHistory) -> UserAccountHistoryEntry:
    """Convert a user account history record to API response."""
    return UserAccountHistoryEntry(
        id=int(history.id),
        user_id=int(history.user_id),
        user_email=str(history.user_email),
        action=str(history.action),
        details=str(history.details) if history.details else None,
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def config_history_to_response(history: RuleEngineConfigHistory) -> RuleEngineConfigHistoryEntry:
    """Convert a config history record to API response."""
    changed = history.changed if history.changed is not None else None

    return RuleEngineConfigHistoryEntry(
        re_id=int(history.re_id),
        label=str(history.label),
        version=int(history.version),
        config=history.config if history.config else {},
        changed=changed,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def field_type_history_to_response(history: FieldTypeHistory) -> FieldTypeHistoryEntry:
    """Convert a field type history record to API response."""
    return FieldTypeHistoryEntry(
        id=int(history.id),
        field_name=str(history.field_name),
        configured_type=str(history.configured_type),
        required=bool(history.required),
        datetime_format=str(history.datetime_format) if history.datetime_format else None,
        action=str(history.action),
        details=str(history.details) if history.details else None,
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def feature_definition_history_to_response(history: FeatureDefinitionHistory) -> FeatureDefinitionHistoryEntry:
    """Convert a feature definition history record to API response."""
    return FeatureDefinitionHistoryEntry(
        id=int(history.id),
        fd_id=int(history.fd_id),
        entity=str(history.entity),
        feature_name=str(history.feature_name),
        action=str(history.action),
        version=int(history.version),
        details=str(history.details) if history.details else None,
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def api_key_history_to_response(history: ApiKeyHistory) -> ApiKeyHistoryEntry:
    """Convert an API key history record to API response."""
    return ApiKeyHistoryEntry(
        id=int(history.id),
        api_key_gid=str(history.api_key_gid),
        label=str(history.label),
        action=str(history.action),
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def ai_rule_authoring_history_to_response(history: AIRuleAuthoringHistory) -> AIRuleAuthoringHistoryEntry:
    """Convert an AI rule authoring history record to API response."""
    return AIRuleAuthoringHistoryEntry(
        id=int(history.id),
        generation_id=str(history.generation_id),
        r_id=int(history.r_id) if history.r_id is not None else None,
        action=str(history.action),
        mode=str(history.mode),
        evaluation_lane=str(history.evaluation_lane),
        provider=str(history.provider),
        model=str(history.model),
        prompt_excerpt=str(history.prompt_excerpt) if history.prompt_excerpt else None,
        prompt_hash=str(history.prompt_hash),
        validation_status=str(history.validation_status),
        repair_attempted=bool(history.repair_attempted),
        applyable=bool(history.applyable),
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def role_permission_history_to_response(history: RolePermissionHistory) -> RolePermissionHistoryEntry:
    """Convert a role permission history record to API response."""
    return RolePermissionHistoryEntry(
        id=int(history.id),
        role_id=int(history.role_id),
        role_name=str(history.role_name),
        action=str(history.action),
        details=str(history.details) if history.details else None,
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


def strict_mode_history_to_response(history: StrictModeHistory) -> StrictModeHistoryEntry:
    """Convert a strict mode history record to API response."""
    return StrictModeHistoryEntry(
        id=int(history.id),
        enabled=bool(history.enabled),
        action=str(history.action),
        details=str(history.details) if history.details else None,
        changed=history.changed if history.changed is not None else None,  # type: ignore[arg-type]
        changed_by=str(history.changed_by) if history.changed_by else None,
    )


# =============================================================================
# AUDIT SUMMARY
# =============================================================================


@router.get("", response_model=AuditSummaryResponse)
def get_audit_summary(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> AuditSummaryResponse:
    """
    Get a summary of audit trail data.

    Returns counts of version history entries.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    total_rule_versions = db.query(RuleHistory).filter(RuleHistory.o_id == current_org_id).count()
    total_config_versions = (
        db.query(RuleEngineConfigHistory).filter(RuleEngineConfigHistory.o_id == current_org_id).count()
    )

    # Count distinct rules/configs with history
    rules_with_changes = db.query(RuleHistory.r_id).filter(RuleHistory.o_id == current_org_id).distinct().count()
    configs_with_changes = (
        db.query(RuleEngineConfigHistory.re_id)
        .filter(RuleEngineConfigHistory.o_id == current_org_id)
        .distinct()
        .count()
    )

    total_user_list_actions = db.query(UserListHistory).filter(UserListHistory.o_id == current_org_id).count()
    total_outcome_actions = db.query(OutcomeHistory).filter(OutcomeHistory.o_id == current_org_id).count()
    total_label_actions = db.query(LabelHistory).filter(LabelHistory.o_id == current_org_id).count()
    total_user_account_actions = db.query(UserAccountHistory).filter(UserAccountHistory.o_id == current_org_id).count()
    total_role_permission_actions = (
        db.query(RolePermissionHistory).filter(RolePermissionHistory.o_id == current_org_id).count()
    )
    total_field_type_actions = db.query(FieldTypeHistory).filter(FieldTypeHistory.o_id == current_org_id).count()
    total_feature_definition_actions = (
        db.query(FeatureDefinitionHistory).filter(FeatureDefinitionHistory.o_id == current_org_id).count()
    )
    total_api_key_actions = db.query(ApiKeyHistory).filter(ApiKeyHistory.o_id == current_org_id).count()
    total_ai_rule_authoring_actions = (
        db.query(AIRuleAuthoringHistory).filter(AIRuleAuthoringHistory.o_id == current_org_id).count()
    )
    total_strict_mode_actions = db.query(StrictModeHistory).filter(StrictModeHistory.o_id == current_org_id).count()

    return AuditSummaryResponse(
        total_rule_versions=total_rule_versions,
        total_config_versions=total_config_versions,
        rules_with_changes=rules_with_changes,
        configs_with_changes=configs_with_changes,
        total_user_list_actions=total_user_list_actions,
        total_outcome_actions=total_outcome_actions,
        total_label_actions=total_label_actions,
        total_user_account_actions=total_user_account_actions,
        total_role_permission_actions=total_role_permission_actions,
        total_field_type_actions=total_field_type_actions,
        total_feature_definition_actions=total_feature_definition_actions,
        total_api_key_actions=total_api_key_actions,
        total_ai_rule_authoring_actions=total_ai_rule_authoring_actions,
        total_strict_mode_actions=total_strict_mode_actions,
    )


# =============================================================================
# RULE HISTORY
# =============================================================================


@router.get("/rules", response_model=RulesAuditListResponse)
def list_rule_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    rule_id: int | None = Query(default=None, description="Filter by rule ID"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> RulesAuditListResponse:
    """
    Get paginated rule version history.

    Returns all rule changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(RuleHistory).filter(RuleHistory.o_id == current_org_id)

    # Apply filters
    if start_date:
        query = query.filter(RuleHistory.changed >= start_date)
    if end_date:
        query = query.filter(RuleHistory.changed <= end_date)
    if rule_id:
        query = query.filter(RuleHistory.r_id == rule_id)

    # Get total count before pagination
    total = query.count()

    # Apply ordering and pagination
    items = query.order_by(RuleHistory.changed.desc()).offset(offset).limit(limit).all()

    return RulesAuditListResponse(
        total=total,
        items=[rule_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


@router.get("/rules/{rule_id}", response_model=RuleAuditResponse)
def get_rule_audit(
    rule_id: int,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> RuleAuditResponse:
    """
    Get complete version history for a specific rule.

    Returns all versions of the rule from oldest to newest.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    rule = db.query(Rule).filter(Rule.r_id == rule_id, Rule.o_id == current_org_id).first()
    history = (
        db.query(RuleHistory)
        .filter(RuleHistory.r_id == rule_id, RuleHistory.o_id == current_org_id)
        .order_by(RuleHistory.version.asc())
        .all()
    )

    if not rule and not history:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Rule with id {rule_id} not found",
        )

    current_version = int(rule.version) if rule is not None else int(history[-1].version)
    rid = str(rule.rid) if rule is not None else str(history[-1].rid)

    return RuleAuditResponse(
        r_id=rule_id,
        rid=rid,
        current_version=current_version,
        history=[rule_history_to_response(h) for h in history],
    )


# =============================================================================
# CONFIG HISTORY
# =============================================================================


@router.get("/config", response_model=ConfigAuditListResponse)
def list_config_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    config_id: int | None = Query(default=None, description="Filter by config ID"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> ConfigAuditListResponse:
    """
    Get paginated config version history.

    Returns all config changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(RuleEngineConfigHistory).filter(RuleEngineConfigHistory.o_id == current_org_id)

    # Apply filters
    if start_date:
        query = query.filter(RuleEngineConfigHistory.changed >= start_date)
    if end_date:
        query = query.filter(RuleEngineConfigHistory.changed <= end_date)
    if config_id:
        query = query.filter(RuleEngineConfigHistory.re_id == config_id)

    # Get total count before pagination
    total = query.count()

    # Apply ordering and pagination
    items = query.order_by(RuleEngineConfigHistory.changed.desc()).offset(offset).limit(limit).all()

    return ConfigAuditListResponse(
        total=total,
        items=[config_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# STRICT MODE HISTORY
# =============================================================================


@router.get("/strict-mode", response_model=StrictModeAuditListResponse)
def list_strict_mode_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> StrictModeAuditListResponse:
    """Get paginated strict mode action history for the caller's organization."""
    query = db.query(StrictModeHistory).filter(StrictModeHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(StrictModeHistory.changed >= start_date)
    if end_date:
        query = query.filter(StrictModeHistory.changed <= end_date)

    total = query.count()
    items = (
        query.order_by(StrictModeHistory.changed.desc(), StrictModeHistory.id.desc()).offset(offset).limit(limit).all()
    )

    return StrictModeAuditListResponse(
        total=total,
        items=[strict_mode_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# USER LIST HISTORY
# =============================================================================


@router.get("/user-lists", response_model=UserListAuditListResponse)
def list_user_list_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    list_id: int | None = Query(default=None, description="Filter by user list ID"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> UserListAuditListResponse:
    """
    Get paginated user list action history.

    Returns all user list changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(UserListHistory).filter(UserListHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(UserListHistory.changed >= start_date)
    if end_date:
        query = query.filter(UserListHistory.changed <= end_date)
    if list_id:
        query = query.filter(UserListHistory.ul_id == list_id)

    total = query.count()
    items = query.order_by(UserListHistory.changed.desc()).offset(offset).limit(limit).all()

    return UserListAuditListResponse(
        total=total,
        items=[user_list_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# OUTCOME HISTORY
# =============================================================================


@router.get("/outcomes", response_model=OutcomeAuditListResponse)
def list_outcome_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> OutcomeAuditListResponse:
    """
    Get paginated outcome action history.

    Returns all outcome changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(OutcomeHistory).filter(OutcomeHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(OutcomeHistory.changed >= start_date)
    if end_date:
        query = query.filter(OutcomeHistory.changed <= end_date)

    total = query.count()
    items = query.order_by(OutcomeHistory.changed.desc()).offset(offset).limit(limit).all()

    return OutcomeAuditListResponse(
        total=total,
        items=[outcome_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# LABEL HISTORY
# =============================================================================


@router.get("/labels", response_model=LabelAuditListResponse)
def list_label_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> LabelAuditListResponse:
    """
    Get paginated label action history.

    Returns all label changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(LabelHistory).filter(LabelHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(LabelHistory.changed >= start_date)
    if end_date:
        query = query.filter(LabelHistory.changed <= end_date)

    total = query.count()
    items = query.order_by(LabelHistory.changed.desc()).offset(offset).limit(limit).all()

    return LabelAuditListResponse(
        total=total,
        items=[label_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# USER ACCOUNT HISTORY
# =============================================================================


@router.get("/users", response_model=UserAccountAuditListResponse)
def list_user_account_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    user_id: int | None = Query(default=None, description="Filter by target user ID"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> UserAccountAuditListResponse:
    """
    Get paginated user account action history.

    Returns all user account changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(UserAccountHistory).filter(UserAccountHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(UserAccountHistory.changed >= start_date)
    if end_date:
        query = query.filter(UserAccountHistory.changed <= end_date)
    if user_id is not None:
        query = query.filter(UserAccountHistory.user_id == user_id)

    total = query.count()
    items = query.order_by(UserAccountHistory.changed.desc()).offset(offset).limit(limit).all()

    return UserAccountAuditListResponse(
        total=total,
        items=[user_account_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# ROLE PERMISSION HISTORY
# =============================================================================


@router.get("/roles", response_model=RolePermissionAuditListResponse)
def list_role_permission_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    role_id: int | None = Query(default=None, description="Filter by role ID"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> RolePermissionAuditListResponse:
    """
    Get paginated role permission action history.

    Returns all role and permission changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(RolePermissionHistory).filter(RolePermissionHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(RolePermissionHistory.changed >= start_date)
    if end_date:
        query = query.filter(RolePermissionHistory.changed <= end_date)
    if role_id is not None:
        query = query.filter(RolePermissionHistory.role_id == role_id)

    total = query.count()
    items = query.order_by(RolePermissionHistory.changed.desc()).offset(offset).limit(limit).all()

    return RolePermissionAuditListResponse(
        total=total,
        items=[role_permission_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# FIELD TYPE HISTORY
# =============================================================================


@router.get("/field-types", response_model=FieldTypeAuditListResponse)
def list_field_type_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    field_name: str | None = Query(default=None, description="Filter by field name"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> FieldTypeAuditListResponse:
    """
    Get paginated field type config action history.

    Returns all field type configuration changes with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(FieldTypeHistory).filter(FieldTypeHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(FieldTypeHistory.changed >= start_date)
    if end_date:
        query = query.filter(FieldTypeHistory.changed <= end_date)
    if field_name is not None:
        query = query.filter(FieldTypeHistory.field_name == field_name)

    total = query.count()
    items = query.order_by(FieldTypeHistory.changed.desc()).offset(offset).limit(limit).all()

    return FieldTypeAuditListResponse(
        total=total,
        items=[field_type_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


@router.get("/features", response_model=FeatureDefinitionAuditListResponse)
def list_feature_definition_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    fd_id: int | None = Query(default=None, description="Filter by feature definition ID"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> FeatureDefinitionAuditListResponse:
    """Get paginated feature definition action history."""
    query = db.query(FeatureDefinitionHistory).filter(FeatureDefinitionHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(FeatureDefinitionHistory.changed >= start_date)
    if end_date:
        query = query.filter(FeatureDefinitionHistory.changed <= end_date)
    if fd_id is not None:
        query = query.filter(FeatureDefinitionHistory.fd_id == fd_id)

    total = query.count()
    items = query.order_by(FeatureDefinitionHistory.changed.desc()).offset(offset).limit(limit).all()

    return FeatureDefinitionAuditListResponse(
        total=total,
        items=[feature_definition_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# API KEY HISTORY
# =============================================================================


@router.get("/api-keys", response_model=ApiKeyAuditListResponse)
def list_api_key_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> ApiKeyAuditListResponse:
    """
    Get paginated API key action history.

    Returns all API key create and revoke events with optional filtering.
    Requires ACCESS_AUDIT_TRAIL permission.
    """
    query = db.query(ApiKeyHistory).filter(ApiKeyHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(ApiKeyHistory.changed >= start_date)
    if end_date:
        query = query.filter(ApiKeyHistory.changed <= end_date)

    total = query.count()
    items = query.order_by(ApiKeyHistory.changed.desc()).offset(offset).limit(limit).all()

    return ApiKeyAuditListResponse(
        total=total,
        items=[api_key_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )


# =============================================================================
# AI RULE AUTHORING HISTORY
# =============================================================================


@router.get("/ai-rule-authoring", response_model=AIRuleAuthoringAuditListResponse)
def list_ai_rule_authoring_history(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.ACCESS_AUDIT_TRAIL)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
    start_date: datetime | None = Query(default=None, description="Filter by start date"),
    end_date: datetime | None = Query(default=None, description="Filter by end date"),
    action: str | None = Query(default=None, description="Filter by action type"),
    limit: int = Query(default=50, ge=1, le=100, description="Page size"),
    offset: int = Query(default=0, ge=0, description="Offset"),
) -> AIRuleAuthoringAuditListResponse:
    """Get paginated AI rule authoring history."""
    query = db.query(AIRuleAuthoringHistory).filter(AIRuleAuthoringHistory.o_id == current_org_id)

    if start_date:
        query = query.filter(AIRuleAuthoringHistory.changed >= start_date)
    if end_date:
        query = query.filter(AIRuleAuthoringHistory.changed <= end_date)
    if action is not None:
        query = query.filter(AIRuleAuthoringHistory.action == action)

    total = query.count()
    items = query.order_by(AIRuleAuthoringHistory.changed.desc()).offset(offset).limit(limit).all()

    return AIRuleAuthoringAuditListResponse(
        total=total,
        items=[ai_rule_authoring_history_to_response(h) for h in items],
        limit=limit,
        offset=offset,
    )
