import csv
import io
from dataclasses import dataclass, field

from ezrules.backend.label_assignments import assign_event_version_label, get_labelable_event_version
from ezrules.core.application_context import get_organization_id
from ezrules.models.backend_core import Label


@dataclass
class AppliedLabelAssignment:
    """A successful label assignment applied from an upload row."""

    row_number: int
    transaction_id: str
    event_version: int
    label_name: str
    label_id: int

    @property
    def event_id(self) -> str:
        return self.transaction_id


@dataclass
class LabelUploadResult:
    """Result of a label upload operation"""

    success_count: int
    error_count: int
    errors: list[str]
    applied_assignments: list[AppliedLabelAssignment] = field(default_factory=list)


@dataclass
class ParsedRow:
    """A parsed CSV row with validation status"""

    row_number: int
    transaction_id: str
    event_version: int | None
    label_name: str
    is_valid: bool
    error_message: str = ""

    @property
    def event_id(self) -> str:
        return self.transaction_id


class LabelUploadService:
    """Service for handling CSV label upload operations"""

    def __init__(self, db_session, org_id: int | None = None):
        self.db_session = db_session
        self.org_id = org_id

    def _resolved_org_id(self) -> int:
        org_id = self.org_id if self.org_id is not None else get_organization_id()
        if org_id is None:
            raise RuntimeError("An organization context is required for label upload operations.")
        return org_id

    def parse_csv_content(self, csv_content: str) -> tuple[list[ParsedRow], list[str]]:
        """Parse CSV content and validate format"""
        stream = io.StringIO(csv_content)
        csv_reader = csv.reader(stream)

        parsed_rows = []
        format_errors = []

        for row_num, row in enumerate(csv_reader, 1):
            if len(row) not in (2, 3):
                format_errors.append(
                    "Row "
                    f"{row_num}: Expected 2 or 3 columns "
                    f"(transaction_id,label or transaction_id,event_version,label), got {len(row)}"
                )
                continue

            if len(row) == 2:
                transaction_id, label_name = row
                event_version = None
            else:
                transaction_id, event_version_raw, label_name = row
                try:
                    event_version = int(event_version_raw.strip())
                except ValueError:
                    format_errors.append(f"Row {row_num}: event_version must be an integer")
                    continue
                if event_version < 1:
                    format_errors.append(f"Row {row_num}: event_version must be greater than 0")
                    continue
            transaction_id = transaction_id.strip()
            label_name = label_name.strip().upper()

            if not transaction_id or not label_name:
                format_errors.append(f"Row {row_num}: Empty transaction_id or label_name")
                continue

            parsed_rows.append(
                ParsedRow(
                    row_number=row_num,
                    transaction_id=transaction_id,
                    event_version=event_version,
                    label_name=label_name,
                    is_valid=True,
                )
            )

        return parsed_rows, format_errors

    def get_label_cache(self) -> dict[str, Label]:
        """Get a dictionary mapping label names to Label objects"""
        all_labels = self.db_session.query(Label).filter(Label.o_id == self._resolved_org_id()).all()
        return {str(label.label).upper(): label for label in all_labels}

    def process_label_assignments(
        self, parsed_rows: list[ParsedRow], label_cache: dict[str, Label]
    ) -> LabelUploadResult:
        """Process the actual label assignments to events"""
        success_count = 0
        error_count = 0
        errors: list[str] = []
        applied_assignments: list[AppliedLabelAssignment] = []

        for row in parsed_rows:
            try:
                org_id = self._resolved_org_id()
                event_record = get_labelable_event_version(
                    self.db_session,
                    o_id=org_id,
                    transaction_id=row.transaction_id,
                    event_version=row.event_version,
                )
                if event_record is None:
                    suffix = f" version {row.event_version}" if row.event_version is not None else ""
                    error_count += 1
                    errors.append(
                        f"Row {row.row_number}: Served transaction with id '{row.transaction_id}'{suffix} not found"
                    )
                    continue

                # Find the label from cache
                label = label_cache.get(row.label_name)
                if not label:
                    error_count += 1
                    errors.append(f"Row {row.row_number}: Label '{row.label_name}' not found")
                    continue

                assign_event_version_label(
                    self.db_session,
                    o_id=org_id,
                    event_version=event_record,
                    label=label,
                    assigned_by=None,
                )
                success_count += 1
                applied_assignments.append(
                    AppliedLabelAssignment(
                        row_number=row.row_number,
                        transaction_id=row.transaction_id,
                        event_version=int(event_record.event_version),
                        label_name=row.label_name,
                        label_id=int(label.el_id),
                    )
                )

            except Exception as e:
                error_count += 1
                errors.append(f"Row {row.row_number}: Database error - {str(e)}")

        return LabelUploadResult(
            success_count=success_count,
            error_count=error_count,
            errors=errors,
            applied_assignments=applied_assignments,
        )

    def upload_labels_from_csv(self, csv_content: str) -> LabelUploadResult:
        """Complete workflow for uploading labels from CSV content"""
        # Step 1: Parse and validate CSV format
        parsed_rows, format_errors = self.parse_csv_content(csv_content)

        if not parsed_rows and format_errors:
            return LabelUploadResult(success_count=0, error_count=len(format_errors), errors=format_errors)

        # Step 2: Get label cache
        label_cache = self.get_label_cache()

        # Step 3: Process assignments
        result = self.process_label_assignments(parsed_rows, label_cache)

        # Combine format errors with processing errors
        all_errors = format_errors + result.errors

        return LabelUploadResult(
            success_count=result.success_count,
            error_count=result.error_count + len(format_errors),
            errors=all_errors,
            applied_assignments=result.applied_assignments,
        )
