import pandas as pd
import tkinter as tk
from tkinter import ttk


class ViewTable:
    def __init__(self, dataset, info=True):
        self.dataset = dataset
        self.info = info
        self.root = tk.Tk()
        self.root.title("Viewtb")
        self.root.geometry("800x600")
        self.root.iconbitmap('../assets/redketchup/favicon.ico')
        self.setup_style()

        if self.info:
            self.create_layout()
        else:
            self.create_table(self.root)

        self.root.mainloop()

    # 🎨 Style
    def setup_style(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure(
            "Treeview",
            # background="#FFFFFF",
            foreground="black",
            # fieldbackground="#FFFFFF",
            rowheight=30,
            font=("Segoe UI", 11)
        )

        style.configure(
            "Treeview.Heading",
            background="#1A0C48",
            foreground="white",
            font=("Segoe UI", 12, "bold")
        )

        style.map(
            "Treeview",
            background=[("selected", "#6A5ACD")],
            foreground=[("selected", "white")]
        )

    # 🧱 Layout
    def create_layout(self):
        container = tk.Frame(self.root)
        container.pack(fill="both", expand=True)

        # SIDEBAR
        self.sidebar = tk.Frame(container, bg="#1A0C48", width=200)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        # ! make heading 
        tk.Label(
            self.sidebar,
            text="Dataset Info",
            bg="#1A0C48",
            fg="white",
            font=("Segoe UI", 14, "bold"),
            anchor="w",
            justify="left"
        ).pack(fill="x",padx=10)
        #! 📊 Data Info
        for col in self.dataset.columns:
            tk.Label(
                self.sidebar,
                text=f"{col}: {self.dataset[col].dtype}, Nulls: {self.dataset[col].isnull().sum()}",
                bg="#1A0C48",
                fg="white",
                font=("Segoe UI", 10),
                anchor="w"
            ).pack(fill="x", padx=10, pady=2)
             # ! make heading 
        #! memoery usage
        tk.Label(
            self.sidebar,
            text="Memory Usage",
            bg="#1A0C48",
            fg="white",
            font=("Segoe UI", 14, "bold"),
            anchor="w",
            justify="left"
        ).pack(fill="x",padx=10)
        tk.Label(
                self.sidebar,
                text=f"Memory: {self.dataset.memory_usage(deep=True).sum()} bytes",
                bg="#1A0C48",
                fg="white",
                font=("Segoe UI", 10),
                anchor="w"
            ).pack(fill="x", padx=10, pady=2)
        # ! count
        tk.Label(
            self.sidebar,
            text="Table info",
            bg="#1A0C48",
            fg="white",
            font=("Segoe UI", 14, "bold"),
            anchor="w",
            justify="left"
        ).pack(fill="x",padx=10)
        # ! column count
        tk.Label(
                self.sidebar,
                text=f"col count : {self.dataset.columns.size}",
                bg="#1A0C48",
                fg="white",
                font=("Segoe UI", 10),
                anchor="w"
            ).pack(fill="x", padx=10)
        # ! row count
        tk.Label(
                self.sidebar,
                text=f"row count : {self.dataset.values.size}",
                bg="#1A0C48",
                fg="white",
                font=("Segoe UI", 10),
                anchor="w"
            ).pack(fill="x", padx=10)
        
        #! 🔥 RESIZER
        self.resizer = tk.Frame(container, bg="#444", width=5, cursor="sb_h_double_arrow")
        self.resizer.pack(side="left", fill="y")

        # MAIN AREA
        self.main = tk.Frame(container, bg="#f5f5f5")
        self.main.pack(side="left", fill="both", expand=True)

        # Bind resize
        self.resizer.bind("<Button-1>", self.start_resize)
        self.resizer.bind("<B1-Motion>", self.do_resize)

        self.resizer.bind("<Enter>", lambda e: self.resizer.config(bg="#666"))
        self.resizer.bind("<Leave>", lambda e: self.resizer.config(bg="#444"))

        self.create_table(self.main)

    # 🔧 Resize logic
    def start_resize(self, event):
        self.start_x = event.x_root
        self.start_width = self.sidebar.winfo_width()

    def do_resize(self, event):
        dx = event.x_root - self.start_x
        new_width = self.start_width + dx

        if 120 < new_width < 300:
            self.sidebar.config(width=new_width)

    # 📊 Table
    def create_table(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, padx=5, pady=5)

        y_scroll = ttk.Scrollbar(frame, orient="vertical")
        x_scroll = ttk.Scrollbar(frame, orient="horizontal")

        self.tree = ttk.Treeview(
            frame,
            columns=list(self.dataset.columns),
            show="headings",
            yscrollcommand=y_scroll.set,
            xscrollcommand=x_scroll.set
        )

        y_scroll.config(command=self.tree.yview)
        x_scroll.config(command=self.tree.xview)

        y_scroll.pack(side="right", fill="y")
        x_scroll.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

        # Columns
        for col in self.dataset.columns:
            self.tree.heading(col, text=col, anchor="center")
            self.tree.column(col, anchor="center", width=120)

        # Rows (faster method)
        for i, row in enumerate(self.dataset.itertuples(index=False, name=None)):
         tag = "even" if i % 2 == 0 else "odd"
         self.tree.insert("", "end", values=row, tags=(tag,))
        # Styling
        self.tree.tag_configure("even", background="#E7E7E7", foreground="#000")
        self.tree.tag_configure("odd", background="#FFFFFF", foreground="#000")

