from setuptools import setup, find_packages

setup(
    name="Viewtb",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pandas",
    ],
    author="Sarthak Sachdeva",
    description="A simple package to view pandas DataFrames in a Tkinter GUI.",
)
