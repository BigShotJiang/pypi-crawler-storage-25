"""UI Intelligence tools — layout, touch targets, accessibility."""
