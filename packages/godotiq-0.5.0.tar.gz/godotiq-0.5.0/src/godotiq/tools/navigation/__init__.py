"""Navigation tools — pathfinding, navmesh analysis."""
