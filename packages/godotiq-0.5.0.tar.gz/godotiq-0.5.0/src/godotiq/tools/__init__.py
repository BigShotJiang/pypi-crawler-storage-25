"""GodotIQ MCP tool categories."""
