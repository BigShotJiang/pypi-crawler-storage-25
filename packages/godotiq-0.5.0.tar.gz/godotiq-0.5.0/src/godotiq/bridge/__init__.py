"""GodotIQ bridge layer — WebSocket communication with the Godot editor addon."""
