from godotiq.cli import cli_main

cli_main()
