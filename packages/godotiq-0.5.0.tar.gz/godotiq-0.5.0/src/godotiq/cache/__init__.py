"""File caching with hash-based staleness detection."""
