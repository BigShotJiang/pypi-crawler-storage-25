"""Godot file parsers (.tscn, .gd, .tres)."""
