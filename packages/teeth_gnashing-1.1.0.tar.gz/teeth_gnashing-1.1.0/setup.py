"""Setup configuration for teeth-gnashing package"""
from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="teeth-gnashing",
    version="1.1.0",
    author="Kirill Nikitenko",
    author_email="Cyan11777@gmail.com",
    description="A production-ready Python library for dynamic snapshot-based encryption using server-client architecture",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/crie123/teeth-gnashing",
    project_urls={
        "Bug Tracker": "https://github.com/crie123/teeth-gnashing/issues",
        "Repository": "https://github.com/crie123/teeth-gnashing",
        "Documentation": "https://github.com/crie123/teeth-gnashing#readme",
    },
    license="GPL-2.0",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: GNU General Public License v2 (GPLv2)",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Rust",
        "Topic :: Security :: Cryptography",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "teeth_gnashing": ["*.dll", "*.so", "*.dylib"],
    },
    python_requires=">=3.8",
    install_requires=[
        "fastapi>=0.68.0",
        "uvicorn[standard]>=0.15.0",
        "aiohttp>=3.8.0",
        "pydantic>=1.8.0",
        "python-multipart>=0.0.5",
        "python-jose[cryptography]>=3.3.0",
        "cryptography>=41.0.0",
        "blake3>=0.3.3",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "mypy>=1.0.0",
            "pylint>=2.17.0",
        ],
    },
    keywords=["encryption", "cryptography", "security", "ffi", "rust"],
)
