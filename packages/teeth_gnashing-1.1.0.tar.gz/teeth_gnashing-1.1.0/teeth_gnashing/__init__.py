"""
teeth-gnashing: Production-ready Python library for dynamic snapshot-based encryption
using server-client architecture.
"""

__version__ = "1.1.0"
__author__ = "Kirill Nikitenko"
__license__ = "GPL-2.0"

from .client import (
    CryptoClient,
    CryptoConfig,
    CryptoError,
    AuthenticationError,
    SnapshotError,
)
from .server import (
    ServerConfig,
)
from .crypto_ffi import (
    CryptoFFI,
    CryptoFFIError,
    get_crypto_ffi,
)

__all__ = [
    "CryptoClient",
    "CryptoConfig",
    "ServerConfig",
    "CryptoError",
    "AuthenticationError",
    "SnapshotError",
    "CryptoFFI",
    "CryptoFFIError",
    "get_crypto_ffi",
]
