from unittest import mock
import os
import pytest
import subprocess

import refclone


REPOHOME = '/repos'

# Each entry: (url, expected path relative to REPOHOME)
# Tests define desired behaviour; failing ones show what the parser still needs to handle.
URL_CASES = [
    # ── HTTPS ──────────────────────────────────────────────────────────────
    ('https://github.com/owner/repo.git',               'github.com/owner/repo'),
    ('https://github.com/owner/repo',                   'github.com/owner/repo'),
    ('https://github.com/owner/repo/',                  'github.com/owner/repo'),
    ('https://user@github.com/owner/repo.git',          'github.com/owner/repo'),
    ('https://user:token@github.com/owner/repo.git',    'github.com/owner/repo'),

    # ── HTTP ───────────────────────────────────────────────────────────────
    ('http://github.com/owner/repo.git',                'github.com/owner/repo'),

    # ── git:// ─────────────────────────────────────────────────────────────
    ('git://github.com/owner/repo.git',                 'github.com/owner/repo'),
    ('git://github.com/owner/repo',                     'github.com/owner/repo'),

    # ── SCP-style SSH (git@host:path) ──────────────────────────────────────
    ('git@github.com:owner/repo.git',                   'github.com/owner/repo'),
    ('git@github.com:owner/repo',                       'github.com/owner/repo'),
    ('custom-user@github.com:owner/repo.git',           'github.com/owner/repo'),

    # ── ssh:// ─────────────────────────────────────────────────────────────
    ('ssh://git@github.com/owner/repo.git',             'github.com/owner/repo'),
    ('ssh://git@github.com:22/owner/repo.git',          'github.com/owner/repo'),

    # ── compound schemes ───────────────────────────────────────────────────
    ('git+ssh://git@github.com/owner/repo.git',         'github.com/owner/repo'),
    ('git+https://github.com/owner/repo.git',           'github.com/owner/repo'),

    # ── GitLab-style subgroups ─────────────────────────────────────────────
    ('https://gitlab.com/group/subgroup/repo.git',      'gitlab.com/group/subgroup/repo'),
    ('git@gitlab.com:group/subgroup/repo.git',          'gitlab.com/group/subgroup/repo'),
]


@pytest.mark.parametrize('url,expected_rel', URL_CASES,
    ids=[u for u, _ in URL_CASES])
def test_clone_directory_url_schemes(url, expected_rel):
    result = refclone._get_clone_directory(REPOHOME, url)
    expected = os.path.join(REPOHOME, expected_rel)
    assert result == expected, f'{url!r} → {result!r}, want {expected!r}'


@pytest.mark.parametrize('url,expected_rel', URL_CASES,
    ids=[u for u, _ in URL_CASES])
def test_clone_directory_no_scheme_in_result(url, expected_rel):
    """Result must not contain the URL scheme or protocol noise."""
    result = refclone._get_clone_directory(REPOHOME, url)
    for noise in ('://', 'git+', '.git', '@'):
        assert noise not in result, (
            f'{url!r} → {result!r} still contains {noise!r}'
        )


@pytest.mark.parametrize('url,expected_rel', URL_CASES,
    ids=[u for u, _ in URL_CASES])
def test_clone_directory_no_trailing_slash(url, expected_rel):
    result = refclone._get_clone_directory(REPOHOME, url)
    assert not result.endswith('/'), (
        f'{url!r} → {result!r} has a trailing slash'
    )


def test_nonexisting_clonedir():
    """Test for a directory that does not exist."""
    dd = refclone._get_clone_directory('/tmpzzz', 'anyurl')
    assert dd == '/tmpzzz/anyurl'


def test_clonedir_empty_name():
    """Test for a directory name that is an empty string."""
    dd = refclone._get_clone_directory('', 'anyurl')
    assert dd == 'anyurl'


def test_parseargs_default_repohome():
    """Test that the default repohome is ~/ref."""
    with mock.patch('sys.argv', ['refclone', 'https://git.example.com/user/repo']):
        args = refclone._parseargs()
    assert args.repohome == os.path.expanduser('~/ref')


@mock.patch('refclone.subprocess')
@mock.patch('refclone.os')
def test_clone(x_os, x_subprocess):
    """Test refclone.clone() happy path."""
    x_os.path.isdir.return_value = False
    x_subprocess.run.return_value = subprocess.CompletedProcess('', 0)

    with mock.patch('refclone._get_clone_directory') as x_get_clone_directory:
        x_get_clone_directory.return_value = '/tmp/git.example.com/user/repo'
        
        refclone.clone('git.example.com/user/repo', '/tmp/refdir')

        x_os.makedirs.assert_called_with('/tmp/git.example.com/user/repo')
        expected_cmd = 'git clone git.example.com/user/repo /tmp/git.example.com/user/repo'
        x_subprocess.run.assert_called_with(tuple(expected_cmd.split()))


@mock.patch('refclone.subprocess')
@mock.patch('refclone.os')
def test_clone_into_existing_dir(x_os, x_subprocess):
    """Test that clone aborts when directory already exists."""
    x_os.path.isdir.return_value = True

    with mock.patch('refclone._get_clone_directory') as x_get_clone_directory:
        x_get_clone_directory.return_value = '/tmp/existing_dir'
        refclone.clone('git.example.com/user/repo', '/tmp/refdir')
        x_os.path.makedirs.assert_not_called()
        x_subprocess.run.assert_not_called()


@mock.patch('refclone.subprocess')
@mock.patch('refclone.os')
def test_failed_git_clone_command(x_os, x_subprocess):
    """Test, what happens when git clone command fails."""
    x_os.path.isdir.return_value = False
    x_subprocess.run.return_value.returncode = 1

    with mock.patch('refclone._get_clone_directory') as x_get_clone_directory:
        x_get_clone_directory.return_value = '/tmp/git.example.com/user/repo'
        refclone.clone('git.example.com/user/repo', '/tmp/refdir')
        x_os.makedirs.assert_called_with('/tmp/git.example.com/user/repo')
        assert x_subprocess.run.called
