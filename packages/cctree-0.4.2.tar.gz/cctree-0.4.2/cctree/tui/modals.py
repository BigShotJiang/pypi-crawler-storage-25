"""Modal screen widgets (search overlay, input prompt)."""
from __future__ import annotations

import os

from .columns import _escape_markup
from textual.app import ComposeResult
from textual.binding import Binding
from textual.events import Click
from textual.screen import ModalScreen
from textual.widgets import Input, Label, ListItem, ListView
from textual.containers import Vertical

from ..core.store import SessionStore
from .columns import _highlight_term


# ─── Column layout constants ────────────────────────────────────────────────

_COL_TYPE = 7
_COL_NAME = 12
_COL_STARTED = 9
_COL_ACTIVE = 9
_COL_MSGS = 4
_COL_SIZE = 5
_SEP = "  "


def _format_date(dt):
    """Format datetime as 'MM/DD HHh' in local time. Returns '-' if None."""
    if dt is None:
        return "-"
    if dt.tzinfo is not None:
        dt = dt.astimezone()
    return dt.strftime("%m/%d %Hh")


def _format_file_size(path: str) -> str:
    """Format file size as human-readable, e.g. '1.2M', '340K'."""
    try:
        size = os.path.getsize(path)
    except OSError:
        return "-"
    if size < 1024:
        return f"{size}B"
    elif size < 1024 * 1024:
        return f"{size // 1024}K"
    else:
        mb = size / (1024 * 1024)
        if mb >= 100:
            return f"{int(mb)}M"
        return f"{mb:.1f}M"


def _truncate(text: str, width: int) -> str:
    """Truncate text to width with trailing ellipsis."""
    if len(text) <= width:
        return text
    if width <= 1:
        return "\u2026"
    return text[: width - 1] + "\u2026"


def _build_header() -> str:
    """Build the bold header row for search results."""
    row = (
        f"{'TYPE':<{_COL_TYPE}}{_SEP}"
        f"{'NAME':<{_COL_NAME}}{_SEP}"
        f"{'STARTED':<{_COL_STARTED}}{_SEP}"
        f"{'ACTIVE':<{_COL_ACTIVE}}{_SEP}"
        f"{'MSGS':>{_COL_MSGS}}{_SEP}"
        f"{'SIZE':>{_COL_SIZE}}{_SEP}"
        f"CONTEXT"
    )
    return f"[bold]{row}[/bold]"


class SearchScreen(ModalScreen[str | None]):
    """Search overlay — type a query, see matching sessions + messages."""

    BINDINGS = [Binding("escape", "dismiss(None)", "Close")]

    def __init__(self, store: SessionStore) -> None:
        super().__init__()
        self.store = store
        self._search_timer = None
        self._last_query: str = ""

    def compose(self) -> ComposeResult:
        yield Vertical(
            Input(placeholder="Search sessions (text, slug, UUID)...", id="search-input"),
            Label("", id="search-header", markup=True),
            ListView(id="search-results"),
            id="search-container",
        )

    def on_mount(self) -> None:
        self.query_one("#search-input", Input).focus()
        self.query_one("#search-header", Label).display = False

    def on_click(self, event: Click) -> None:
        """Disable mouse click selection in search overlay."""
        event.prevent_default()
        event.stop()

    def on_key(self, event) -> None:
        """Down arrow from input → results. Up arrow from results → input."""
        search_input = self.query_one("#search-input", Input)
        results = self.query_one("#search-results", ListView)

        if event.key == "down" and search_input.has_focus:
            if len(results.children) > 0:
                results.focus()
                results.index = 0
                event.prevent_default()
        elif event.key == "up" and results.has_focus:
            if results.index == 0 or results.index is None:
                search_input.focus()
                event.prevent_default()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Debounce search — wait 300ms after last keystroke before searching."""
        if self._search_timer is not None:
            self._search_timer.stop()
        query = event.value.strip()
        if len(query) < 2:
            self.query_one("#search-results", ListView).clear()
            self.query_one("#search-header", Label).display = False
            return
        self._search_timer = self.set_timer(0.3, lambda: self._do_search(query))

    def _build_matches(self, query: str) -> list[tuple[str, str, str]]:
        """Build the list of (label, session_uuid, msg_uuid) matches.

        Each label is a fixed-width columnar row:
        TYPE  NAME  STARTED  ACTIVE  MSGS  SIZE  CONTEXT
        """
        query_lower = query.lower()
        escaped_query = _escape_markup(query)
        matches: list[tuple[str, str, str]] = []

        for session in self.store.sessions.values():
            type_str = ""
            context = ""
            msg_uuid = ""

            if session.uuid.lower().startswith(query_lower):
                type_str = "uuid"
                ctx = _highlight_term(
                    _escape_markup(session.uuid[:12]), escaped_query, markup="reverse",
                )
                context = ctx
            elif session.slug and query_lower in session.slug.lower():
                type_str = "slug"
                ctx = _highlight_term(
                    _escape_markup(session.slug), escaped_query, markup="reverse",
                )
                context = ctx
            elif session.custom_title and query_lower in session.custom_title.lower():
                type_str = "title"
                ctx = _highlight_term(
                    _escape_markup(session.custom_title), escaped_query, markup="reverse",
                )
                context = ctx
            else:
                for evt in session.events:
                    if evt.is_message:
                        text = evt.text_content.lower()
                        idx = text.find(query_lower)
                        if idx >= 0:
                            start = max(0, idx - 60)
                            end = min(len(text), idx + len(query_lower) + 60)
                            excerpt = evt.text_content[start:end].replace("\n", " ")
                            safe_excerpt = _escape_markup(excerpt)
                            highlighted = _highlight_term(
                                safe_excerpt, escaped_query, markup="reverse",
                            )
                            type_str = "content"
                            context = f"...{highlighted}..."
                            msg_uuid = evt.uuid or ""
                            break

            if not type_str:
                continue

            # Build columnar label — pad plain text BEFORE escaping for correct
            # visual width (Rich markup tags are zero-width in rendering).
            raw_name = session.display_name
            name_padded = f"{_truncate(raw_name, _COL_NAME):<{_COL_NAME}}"

            label = (
                f"{type_str:<{_COL_TYPE}}{_SEP}"
                f"{_escape_markup(name_padded)}{_SEP}"
                f"{_format_date(session.started_at):<{_COL_STARTED}}{_SEP}"
                f"{_format_date(session.last_activity_at):<{_COL_ACTIVE}}{_SEP}"
                f"{session.message_count:>{_COL_MSGS}}{_SEP}"
                f"{_format_file_size(session.path):>{_COL_SIZE}}{_SEP}"
                f"{context}"
            )
            matches.append((label, session.uuid, msg_uuid))

            if len(matches) >= 50:
                break

        return matches

    def _do_search(self, query: str) -> None:
        """Execute the actual search — called after debounce delay."""
        self._last_query = query
        results = self.query_one("#search-results", ListView)
        results.clear()
        header = self.query_one("#search-header", Label)

        matches = self._build_matches(query)
        if matches:
            header.update(_build_header())
            header.display = True
        else:
            header.display = False

        for label, s_uuid, m_uuid in matches:
            results.append(ListItem(Label(label, markup=True), name=f"{s_uuid}|{m_uuid}"))

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        name = event.item.name or ""
        # Append the search query as third field
        self.dismiss(f"{name}|{self._last_query}")


class InputModal(ModalScreen[str | None]):
    """Generic input modal — prompts for a string and returns it."""

    BINDINGS = [Binding("escape", "dismiss(None)", "Close")]

    def __init__(self, title: str, placeholder: str, default: str = "") -> None:
        super().__init__()
        self._title = title
        self._placeholder = placeholder
        self._default = default

    def compose(self) -> ComposeResult:
        yield Vertical(
            Label(self._title, id="input-modal-title"),
            Input(placeholder=self._placeholder, value=self._default, id="input-modal-field"),
            id="input-modal-container",
        )

    def on_mount(self) -> None:
        self.query_one("#input-modal-field", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        value = event.value.strip()
        self.dismiss(value if value else None)
