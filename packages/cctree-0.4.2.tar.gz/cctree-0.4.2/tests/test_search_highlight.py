"""Tests for search highlighting — _highlight_term helper and search result formatting."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


# ─── Unit tests for _highlight_term ──────────────────────────────────────────


class TestHighlightTerm:
    """Pure unit tests for the _highlight_term helper."""

    def test_single_match(self):
        from cctree.tui.columns import _highlight_term

        result = _highlight_term("fix the database issue", "database")
        assert result == "fix the [reverse]database[/reverse] issue"

    def test_multiple_matches(self):
        from cctree.tui.columns import _highlight_term

        result = _highlight_term("db is a database for databases", "database")
        assert result == "db is a [reverse]database[/reverse] for [reverse]database[/reverse]s"

    def test_case_insensitive_preserves_case(self):
        from cctree.tui.columns import _highlight_term

        result = _highlight_term("Check the Database and DATABASE", "database")
        assert result == "Check the [reverse]Database[/reverse] and [reverse]DATABASE[/reverse]"

    def test_no_match_returns_unchanged(self):
        from cctree.tui.columns import _highlight_term

        text = "nothing to find here"
        result = _highlight_term(text, "missing")
        assert result == text

    def test_term_with_regex_special_chars(self):
        from cctree.tui.columns import _highlight_term

        result = _highlight_term("call file.py now", "file.py")
        assert result == "call [reverse]file.py[/reverse] now"

    def test_term_with_rich_markup_brackets(self):
        """Search term with [ chars — should be escaped before matching."""
        from cctree.tui.columns import _highlight_term
        from rich.markup import escape as _escape_markup

        # In practice, text passed to _highlight_term is already escaped
        text = _escape_markup("check [config] value")
        term = "[config]"
        escaped_term = _escape_markup(term)
        result = _highlight_term(text, escaped_term)
        assert "[reverse]" in result

    def test_custom_markup(self):
        from cctree.tui.columns import _highlight_term

        result = _highlight_term("find me", "me", markup="bold")
        assert result == "find [bold]me[/bold]"

    def test_empty_term_returns_unchanged(self):
        from cctree.tui.columns import _highlight_term

        text = "some text"
        result = _highlight_term(text, "")
        assert result == text

    def test_empty_text_returns_empty(self):
        from cctree.tui.columns import _highlight_term

        result = _highlight_term("", "term")
        assert result == ""


class TestHighlightEscapeBoundary:
    """Rich escape() + Textual Content.from_markup() interaction bug.

    Root cause: ``rich.markup.escape()`` only escapes tag-like ``[lowercase...]``
    sequences.  Textual's ``Content.from_markup()`` is stricter — it parses
    **any** ``[...]`` as a potential tag.  When session text contains an
    incomplete tag like ``[/`` (no closing ``]``), ``escape()`` leaves it
    untouched.  ``_highlight_term`` then inserts ``[reverse]...[/reverse]``
    nearby, and the ``]`` from ``[reverse]`` is picked up by Textual's parser
    to close the stray ``[/`` — forming a bogus closing tag that triggers
    ``MarkupError``.
    """

    def test_incomplete_closing_bracket_with_highlight(self):
        """Text with unescaped [/ must not form a tag via highlight's ]."""
        from textual.content import Content
        from cctree.tui.columns import _escape_markup, _highlight_term

        # "use [/ to start closing" — rich.markup.escape() leaves [/ alone
        raw = "use [/ to start closing"
        escaped = _escape_markup(raw)
        highlighted = _highlight_term(escaped, _escape_markup("start"), markup="reverse")
        label = f"\\[content] session — ...{highlighted}..."

        # Must not raise MarkupError
        Content.from_markup(label)

    def test_slash_search_hitting_incomplete_tag(self):
        """Slash-search matching text right after [/ must not error."""
        from textual.content import Content
        from cctree.tui.columns import _escape_markup, _highlight_term

        # User discusses Rich closing tags: "use [/bold to close"
        # User searches for "/bold"
        raw = "use [/bold to close formatting"
        escaped = _escape_markup(raw)
        highlighted = _highlight_term(escaped, _escape_markup("/bold"), markup="reverse")
        label = f"\\[content] session — ...{highlighted}..."

        Content.from_markup(label)

    def test_excerpt_starting_with_incomplete_tag(self):
        """Excerpt that starts at [/ boundary must render safely."""
        from textual.content import Content
        from cctree.tui.columns import _escape_markup, _highlight_term

        raw = "[/rest of the text here"
        escaped = _escape_markup(raw)
        highlighted = _highlight_term(escaped, _escape_markup("rest"), markup="reverse")
        label = f"\\[content] session — ...{highlighted}..."

        Content.from_markup(label)

    def test_uppercase_tag_not_stripped(self):
        """Uppercase [TAG] must survive as visible text, not be parsed as tag."""
        from textual.content import Content
        from cctree.tui.columns import _escape_markup, _highlight_term

        raw = "check [WARNING] value for results"
        escaped = _escape_markup(raw)
        highlighted = _highlight_term(escaped, _escape_markup("results"), markup="reverse")

        c = Content.from_markup(highlighted)
        assert "[WARNING]" in c.plain, (
            f"[WARNING] was stripped by parser: plain={c.plain!r}"
        )


# ─── Unit tests for search result formatting ────────────────────────────────


class TestSearchResultFormat:
    """Verify uniform [type] session — context format in search results."""

    @pytest.fixture
    def store_with_sessions(self, tmp_path):
        """Create a SessionStore with sessions for each match type."""
        from cctree.core.store import SessionStore

        # Session with a known slug + content
        session_id = "aaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
        lines = [
            json.dumps({"type": "user", "uuid": "u1", "parentUuid": None,
                        "message": {"role": "user", "content": "tell me about the migration script"},
                        "sessionId": session_id, "slug": "elegant-seeking-corbato",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "a1", "parentUuid": "u1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "The migration handles schema changes."}]},
                        "sessionId": session_id, "slug": "elegant-seeking-corbato",
                        "timestamp": "2026-04-01T10:00:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))

        store = SessionStore(project_dir=tmp_path)
        # Access .sessions to trigger lazy-load
        _ = store.sessions
        return store

    def test_uuid_match_format(self, store_with_sessions):
        """UUID match should show [uuid] label with highlighted prefix."""
        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(store_with_sessions)
        # Simulate the search logic directly
        matches = screen._build_matches("aaaa")
        assert len(matches) >= 1
        label, _, _ = matches[0]
        assert label.startswith("uuid")
        assert "aaaa" in label.lower()

    def test_slug_match_format(self, store_with_sessions):
        """Slug match should show slug type in columnar format."""
        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("elegant")
        assert len(matches) >= 1
        label, _, _ = matches[0]
        assert label.startswith("slug")
        assert "elegant" in label.lower()

    def test_content_match_format(self, store_with_sessions):
        """Content match should show content type in columnar format."""
        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("migration")
        assert len(matches) >= 1
        label, _, _ = matches[0]
        assert label.startswith("content")
        assert "migration" in label.lower()

    def test_content_excerpt_width_60(self, store_with_sessions):
        """Content excerpts should use 60-char context on each side."""
        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("migration")
        assert len(matches) >= 1
        label, _, _ = matches[0]
        # The excerpt should contain context around "migration"
        assert "..." in label

    def test_dismiss_includes_query(self, store_with_sessions):
        """Dismiss string should include the query as third pipe-delimited field."""
        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("migration")
        assert len(matches) >= 1
        _, s_uuid, m_uuid = matches[0]
        # Build the dismiss string as SearchScreen would
        dismiss_str = f"{s_uuid}|{m_uuid}|migration"
        parts = dismiss_str.split("|", 2)
        assert len(parts) == 3
        assert parts[2] == "migration"


# ─── Integration tests for search highlight in tree ──────────────────────────


class TestSearchHighlightInTree:
    """Async Textual tests for highlight injection, n/N nav, Escape clearing."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        """Session with multiple occurrences of a search term across messages."""
        session_id = "sess-highlight-0000-0000-000000000001"
        lines = [
            json.dumps({"type": "user", "uuid": "hu1", "parentUuid": None,
                        "message": {"role": "user", "content": "fix the database connection"},
                        "sessionId": session_id, "slug": "highlight-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "ha1", "parentUuid": "hu1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "I'll check the database config and database logs."}]},
                        "sessionId": session_id, "slug": "highlight-test",
                        "timestamp": "2026-04-01T10:00:05Z"}),
            json.dumps({"type": "user", "uuid": "hu2", "parentUuid": "ha1",
                        "message": {"role": "user", "content": "also check the database schema"},
                        "sessionId": session_id, "slug": "highlight-test",
                        "timestamp": "2026-04-01T10:01:00Z"}),
            json.dumps({"type": "assistant", "uuid": "ha2", "parentUuid": "hu2",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "The schema looks correct."}]},
                        "sessionId": session_id, "slug": "highlight-test",
                        "timestamp": "2026-04-01T10:01:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))
        return tmp_path

    def _find_highlighted_nodes(self, node):
        """DFS walk to find all nodes with [reverse] in their label markup."""
        found = []
        label = node.label
        markup = label.markup if hasattr(label, "markup") else str(label)
        if "[reverse]" in markup:
            found.append(node)
        for child in node.children:
            found.extend(self._find_highlighted_nodes(child))
        return found

    @pytest.mark.asyncio
    async def test_search_injects_highlights_in_tree(self, project_dir):
        """After selecting a search result, tree content should have [reverse] highlights."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("slash")
            await pilot.pause()

            for ch in "database":
                await pilot.press(ch)
            await pilot.pause(delay=0.5)

            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            assert app.current_session is not None
            assert app._search_term == "database"

            # Expand all to make content visible
            tree = app.query_one("#session-tree", Tree)
            from cctree.tui.fold import set_fold_level
            set_fold_level(tree.root, target_depth=999)

            highlighted = self._find_highlighted_nodes(tree.root)
            assert len(highlighted) > 0, "No highlighted nodes found after search"

    @pytest.mark.asyncio
    async def test_n_jumps_to_next_match(self, project_dir):
        """Pressing n should move cursor to the next highlighted node."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            # Search and select
            await pilot.press("slash")
            await pilot.pause()
            for ch in "database":
                await pilot.press(ch)
            await pilot.pause(delay=0.5)
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            from cctree.tui.fold import set_fold_level
            set_fold_level(tree.root, target_depth=999)
            await pilot.pause()

            # Record starting position
            start_node = tree.cursor_node

            # Press n to go to next match
            await pilot.press("n")
            await pilot.pause()

            next_node = tree.cursor_node
            # Should have moved (or if only one match, wrapped back)
            assert next_node is not None
            markup = next_node.label.markup if hasattr(next_node.label, "markup") else str(next_node.label)
            assert "[reverse]" in markup, f"n should land on a highlighted node, got: {markup}"

    @pytest.mark.asyncio
    async def test_N_jumps_to_prev_match(self, project_dir):
        """Pressing N should move cursor to the previous highlighted node."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("slash")
            await pilot.pause()
            for ch in "database":
                await pilot.press(ch)
            await pilot.pause(delay=0.5)
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            from cctree.tui.fold import set_fold_level
            set_fold_level(tree.root, target_depth=999)
            await pilot.pause()

            # Press N to go to prev match
            await pilot.press("N")
            await pilot.pause()

            node = tree.cursor_node
            assert node is not None
            markup = node.label.markup if hasattr(node.label, "markup") else str(node.label)
            assert "[reverse]" in markup, f"N should land on a highlighted node, got: {markup}"

    @pytest.mark.asyncio
    async def test_escape_clears_highlights(self, project_dir):
        """Pressing Escape should clear all search highlights."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("slash")
            await pilot.pause()
            for ch in "database":
                await pilot.press(ch)
            await pilot.pause(delay=0.5)
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            assert app._search_term == "database"

            # Press Escape to clear
            await pilot.press("escape")
            await pilot.pause()

            assert app._search_term is None

            # Tree should have no highlighted nodes
            tree = app.query_one("#session-tree", Tree)
            from cctree.tui.fold import set_fold_level
            set_fold_level(tree.root, target_depth=999)

            highlighted = self._find_highlighted_nodes(tree.root)
            assert len(highlighted) == 0, "Highlights should be cleared after Escape"

    @pytest.mark.asyncio
    async def test_escape_col_focus_takes_priority(self, project_dir):
        """If column focus is active, Escape exits column focus first, not search."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("slash")
            await pilot.pause()
            for ch in "database":
                await pilot.press(ch)
            await pilot.pause(delay=0.5)
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            # Search term should be set
            assert app._search_term == "database"

            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()

            # Enter column focus mode via Tab on a user turn
            await pilot.press("tab")
            await pilot.pause()

            if app._col_focus_index is not None:
                # Column focus is active — Escape should exit col focus, not clear search
                await pilot.press("escape")
                await pilot.pause()
                assert app._col_focus_index is None, "Column focus should be cleared"
                assert app._search_term == "database", "Search term should still be active"
