import pyxel

class Teste:
    def __init__(self):
        pyxel.init(800, 600, title="O meu jogo")
        
        self.segundos = 0
        
        pyxel.run(self.update, self.draw)

    def update(self):
        if pyxel.frame_count % 30 == 0:
            self.segundos += 1

    def draw(self):
        pyxel.cls(pyxel.COLOR_BLACK)
        
        pyxel.text(50, 400, f"Segundos: {self.segundos}", pyxel.COLOR_WHITE, pyxel.Font('fontTest17_PYXEL.ttf', 100))

if __name__ == "__main__":
    Teste()