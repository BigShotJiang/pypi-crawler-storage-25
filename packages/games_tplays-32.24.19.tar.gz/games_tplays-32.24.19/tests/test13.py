from games import *
import random

class Jogo(Window):
    def __init__(self):
        # Inicializa o motor normalmente
        super().__init__(width=800, height=600, title="Space Invaders - MANUAL RAW DATA")
        
        self.bgColor = RGBA(10, 10, 25)
        self.fps = 60
        
        # --- JOGADOR ---
        # Estrutura do retângulo: [x, y, width, height, rgba, rotation, layer, tipo]
        self.jogador = [375, 50, 50, 30, RGBA(0, 200, 255), 0.0, 2, self.RECTANGLES]
        self.draws.append(self.jogador)
        
        self.velocidade_jogador = 7
        self.pontuacao = 0
        
        # --- UI (TEXTO) ---
        # Estrutura do texto: [text, font_name, size, x, y, rgba, rotation, bold, italic, tex_id, layer, tipo]
        self.texto_score = ["Score: 0", "Arial", 30, 20, 550, RGBA(255, 255, 255), 0.0, True, False, None, 10, self.TEXTS]
        self.draws.append(self.texto_score)
        
        # --- POOL FIXA DE TIROS ---
        self.max_tiros = 5
        self.lista_tiros = []
        for _ in range(self.max_tiros):
            tiro = [0, -100, 8, 20, RGBA(255, 255, 0), 0.0, 3, self.RECTANGLES]
            self.lista_tiros.append(tiro)
            self.draws.append(tiro)
            
        self.velocidade_tiro = 10
        
        # --- INIMIGOS ---
        self.lista_invertida_inimigos = []
        self.velocidade_inimigo = 3
        for _ in range(6):
            # Inimigos começam no topo da tela (y entre 500 e 600)
            inimigo = [random.randint(50, 750), random.randint(500, 600), 40, 40, RGBA(255, 50, 50), 0.0, 2, self.RECTANGLES]
            self.lista_invertida_inimigos.append(inimigo)
            self.draws.append(inimigo)
            
        # --- ESTRELA DE FUNDO ---
        # Estrutura do círculo: [centerX, centerY, radius, rgba, layer, tipo]
        for _ in range(25):
            estrela = [random.randint(0, 800), random.randint(0, 600), random.randint(1, 3), RGBA(255, 255, 200, 0.5), 1, self.CIRCLES]
            self.draws.append(estrela)

    def animation(self):
        # 1. MOVIMENTO DO JOGADOR
        if self.pressed("left") or self.pressed("a"):
            self.jogador[0] -= self.velocidade_jogador
            if self.jogador[0] < 0: 
                self.jogador[0] = 0
                
        if self.pressed("right") or self.pressed("d"):
            self.jogador[0] += self.velocidade_jogador
            if self.jogador[0] > 800 - self.jogador[2]: 
                self.jogador[0] = 800 - self.jogador[2]

        # 2. DISPARAR TIROS (Ativando os de Y < 0)
        if (self.pressed("space") or self.pressed("w")) and self.after(200):
            for tiro in self.lista_tiros:
                if tiro[1] < 0:  
                    tiro[0] = self.jogador[0] + (self.jogador[2] / 2) - 4
                    tiro[1] = self.jogador[1] + self.jogador[3]
                    break

        # 3. ATUALIZAR TIROS
        for tiro in self.lista_tiros:
            if tiro[1] >= 0:
                tiro[1] += self.velocidade_tiro
                if tiro[1] > 600:
                    tiro[1] = -100

        # 4. ATUALIZAR INIMIGOS
        for inimigo in self.lista_invertida_inimigos:
            # Inimigos descem em direção ao jogador
            inimigo[1] -= self.velocidade_inimigo
            
            # Se passar do fundo do ecrã, reseta para o topo
            if inimigo[1] < -40:
                inimigo[0] = random.randint(50, 750)
                inimigo[1] = random.randint(580, 650)
            
            if self.collided(self.jogador, inimigo):
                print(f"Game Over! Pontuação Final: {self.pontuacao}")
                self.close()

        # 5. COLISÕES
        for tiro in self.lista_tiros:
            if tiro[1] < 0: 
                continue
            
            for inimigo in self.lista_invertida_inimigos:
                if self.collided(tiro, inimigo):
                    tiro[1] = -100  
                    inimigo[0] = random.randint(50, 750)
                    inimigo[1] = random.randint(580, 650)
                    
                    self.pontuacao += 10
                    self.texto_score[0] = f"Score: {self.pontuacao}"

if __name__ == "__main__":
    Jogo().run()