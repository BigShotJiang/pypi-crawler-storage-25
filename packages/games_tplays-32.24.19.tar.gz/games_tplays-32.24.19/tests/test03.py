from games import Window, RGBA, math
import random

class AnimacaoHipnotica(Window):
    def __init__(self):
        # Inicializamos com uma resolução HD
        super().__init__(800, 600, "Animação Hipnótica | games._2DGame")
        self.bgColor = RGBA(5, 5, 15) # Fundo azul muito escuro
        self.fps = 60
        
        self.circulos = []
        self.quantidade = 12
        self.tempo = 0
        
        # Criamos vários círculos em posições diferentes
        for i in range(self.quantidade):
            # Usamos a tua função RGBA para cores neon
            cor = RGBA(random.randint(100, 255), 50, 255, 0.6)
            # Guardamos a referência do desenho
            obj = self.draw_circle(400, 300, 20, cor)
            self.circulos.append(obj)

        # Um retângulo central que roda
        self.bloco = self.draw_rectangle(375, 275, 50, 50, RGBA(255, 255, 255, 0.8))

    def animation(self):
        self.tempo += 0.05
        
        # 1. Animamos os círculos em órbita
        for i, c in enumerate(self.circulos):
            # Distribuímos os círculos num círculo completo (2 * PI)
            fase = i * (math.pi * 2 / self.quantidade)
            distancia = 150 + math.sin(self.tempo) * 50
            
            # Aplicamos a tua lógica de Y positivo para cima
            c[self.X['CIRCLES']] = 400 + math.cos(self.tempo + fase) * distancia
            c[self.Y['CIRCLES']] = 300 + math.sin(self.tempo + fase) * distancia
            
            # Alteramos o raio dinamicamente para um efeito de "pulsação"
            c[self.RADIUS['CIRCLES']] = 15 + math.cos(self.tempo * 2) * 10

        # 2. Rodamos o bloco central usando o teu sistema de ROTATION
        self.bloco[self.ROTATION['RECTANGLES']] += 2
        
        # 3. Interatividade: Se premires Espaço, os círculos dispersam
        if self.pressed('space'):
            self.bgColor = RGBA(40, 0, 0) # Fundo fica avermelhado
        else:
            self.bgColor = RGBA(5, 5, 15)

        # Atalho para fechar
        if self.pressed('escape'):
            self.close()

if __name__ == "__main__":
    AnimacaoHipnotica().run()