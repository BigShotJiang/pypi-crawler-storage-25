from games import get_color, __version__, VERSION

print(len(get_color()))
print(__version__)
print(VERSION)