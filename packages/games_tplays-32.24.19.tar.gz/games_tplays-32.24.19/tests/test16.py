from games import Window, get_color, path, audio

class Audio(Window):
    def __init__(self):
        super().__init__(800, 600, 'Áudio')
        self.cor = get_color()

        self.bgColor = self.cor['white']

        self.draw_text('Clica no "1" para ativar/desativar a batida', 'Arial', 20, 50, 100, self.cor['black'], bold=True)
        self.draw_text('Clica no "2" para ativar/desativar a música', 'Arial', 20, 50, 70, self.cor['black'], bold=True)

        self.batidaPath = path('music1Test16.mp3')
        self.musicaPath = path('music2Test16.mp3')

        self.batida = audio(self.batidaPath, loop=True)
        self.musica = audio(self.musicaPath, loop=True)

        self.play_audios(self.musica)

        self.batida_ativa = False
        self.musica_ativa = True

    def animation(self):
        if self.clicked(1): 
            if self.batida_ativa: 
                self.stop_audio(self.batidaPath)
                self.batida_ativa = False

            else:
                self.play_audio(self.batida)
                self.batida_ativa = True

        if self.clicked(2): 
            if self.musica_ativa:
                self.stop_audio(self.musicaPath)
                self.musica_ativa = False

            else: 
                self.play_audio(self.musica)
                self.musica_ativa = True

Audio().run()