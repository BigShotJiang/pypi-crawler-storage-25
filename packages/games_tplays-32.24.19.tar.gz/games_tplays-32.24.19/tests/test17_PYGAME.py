import pygame, requests, io

pygame.init()

tela = pygame.display.set_mode((800, 600))
pygame.display.set_caption('O meu jogo')

pygame.display.set_icon(pygame.image.load(
    io.BytesIO(requests.get(
        'https://tse3.mm.bing.net/th/id/OIP.kB2t1VMox767tj41hP6MawHaHY?rs=1&pid=ImgDetMain&o=7&rm=3&adlt=strict'
    ).content)
))

frames = 0
segundos = 0

cor = pygame.color.THECOLORS
relogio = pygame.time.Clock()

jogando = True
while jogando:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            jogando = False

    tela.fill(cor['black'])

    frames += 1
    if frames % 60 == 0:
        segundos += 1

    tela.blit(pygame.font.SysFont('Arial', 100, bold=True).render(
        f'Segundos: {segundos}', True, cor['white']
    ), (50, 450))

    pygame.display.flip()
    relogio.tick(60)

pygame.quit()