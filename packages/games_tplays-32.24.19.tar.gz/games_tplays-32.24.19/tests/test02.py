# PYGAME
import pygame

pygame.init()

tela = pygame.display.set_mode((640, 480))
pygame.display.set_caption('O meu jogo | pygame')

jogador = pygame.Rect(600 / 2, 420, 40, 60)

correr = True
while correr:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            correr = False

    tela.fill((0, 0, 0))

    pygame.draw.rect(tela, (255, 255, 0), jogador)
    vel_jogador = 5

    tecla = pygame.key.get_pressed()

    if tecla[pygame.K_w]: jogador.y -= vel_jogador
    if tecla[pygame.K_s]: jogador.y += vel_jogador
    if tecla[pygame.K_a]: jogador.x -= vel_jogador
    if tecla[pygame.K_d]: jogador.x += vel_jogador

    tela.blit(
        pygame.font.SysFont(
            'Arial', 30,
            True,
            True
        ).render(
            'Jogo com pygame',
            True,
            (255, 0, 0)
        ), (0, 0)
    )

    pygame.display.flip()
    pygame.time.Clock().tick(100)

pygame.quit()

# games._2DGame
from games import _2DGame, RGBA

class jogo(_2DGame):
    def __init__(self):
        super().__init__(640, 480, 'O meu jogo | games._2DGame')
        self.bgColor = RGBA(0, 0, 0)
        self.fps = 0

        self.jogador = self.draw_rectangle(600 / 2, 0, 40, 60, RGBA(255, 255, 0))

        self.draw_text('Jogo com games._2DGame', 'Arial', 30, 0, 450, RGBA(255, 0, 0), True, True)
    
    def animation(self):
        self.vel_jogador = 5
        if self.pressed('w'): self.jogador[self.Y['RECTANGLES']] += self.vel_jogador
        if self.pressed('s'): self.jogador[self.Y['RECTANGLES']] -= self.vel_jogador
        if self.pressed('a'): self.jogador[self.X['RECTANGLES']] -= self.vel_jogador
        if self.pressed('d'): self.jogador[self.X['RECTANGLES']] += self.vel_jogador

jogo().run()