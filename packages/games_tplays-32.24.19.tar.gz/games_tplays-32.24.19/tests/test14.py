from games import *
import random

class Jogo(Window):
    def __init__(self):
        # Inicializa o motor normalmente
        super().__init__(width=800, height=600, title="Space Invaders - Funções Draw & SELF Maiúsculos")
        
        self.bgColor = RGBA(10, 10, 25)
        self.fps = 60
        
        # --- JOGADOR ---
        self.jogador = self.draw_rectangle(
            x=375, y=50, 
            width=50, height=30, 
            rgba=RGBA(0, 200, 255), 
            layer=2
        )
        self.velocidade_jogador = 7
        self.pontuacao = 0
        
        # --- UI (TEXTO) ---
        self.texto_score = self.draw_text(
            text="Score: 0", 
            font_name="Arial", 
            size=30, 
            x=20, y=550, 
            rgba=RGBA(255, 255, 255), 
            italic=True, 
            layer=10
        )
        
        # --- POOL FIXA DE TIROS ---
        self.max_tiros = 5
        self.lista_tiros = []
        for _ in range(self.max_tiros):
            tiro = self.draw_rectangle(
                x=0, y=-100, 
                width=8, height=20, 
                rgba=RGBA(255, 255, 0), 
                layer=3
            )
            self.lista_tiros.append(tiro)
            
        self.velocidade_tiro = 10
        
        # --- INIMIGOS ---
        self.lista_invertida_inimigos = []
        self.velocidade_inimigo = 3
        for _ in range(6):
            inimigo = self.draw_rectangle(
                x=random.randint(50, 750), 
                y=random.randint(500, 600), 
                width=40, height=40, 
                rgba=RGBA(255, 50, 50), 
                layer=2
            )
            self.lista_invertida_inimigos.append(inimigo)
            
        # --- ESTRELAS DE FUNDO ---
        for _ in range(25):
            self.draw_circle(
                centerX=random.randint(0, 800), 
                centerY=random.randint(0, 600), 
                radius=random.randint(1, 3), 
                rgba=RGBA(255, 255, 200, 0.5), 
                layer=1
            )

    def animation(self):
        # 1. MOVIMENTO DO JOGADOR
        if self.pressed("left") or self.pressed("a"):
            self.jogador[self.X['RECTANGLES']] -= self.velocidade_jogador
            if self.jogador[self.X['RECTANGLES']] < 0: 
                self.jogador[self.X['RECTANGLES']] = 0
                
        if self.pressed("right") or self.pressed("d"):
            self.jogador[self.X['RECTANGLES']] += self.velocidade_jogador
            if self.jogador[self.X['RECTANGLES']] > 800 - self.jogador[self.WIDTH['RECTANGLES']]: 
                self.jogador[self.X['RECTANGLES']] = 800 - self.jogador[self.WIDTH['RECTANGLES']]

        # 2. DISPARAR TIROS (Ativando os de Y < 0)
        if (self.pressed("space") or self.pressed("w")) and self.after(200):
            for tiro in self.lista_tiros:
                if tiro[self.Y['RECTANGLES']] < 0:  
                    tiro[self.X['RECTANGLES']] = self.jogador[self.X['RECTANGLES']] + (self.jogador[self.WIDTH['RECTANGLES']] / 2) - 4
                    tiro[self.Y['RECTANGLES']] = self.jogador[self.Y['RECTANGLES']] + self.jogador[self.HEIGHT['RECTANGLES']]
                    break

        # 3. ATUALIZAR TIROS
        for tiro in self.lista_tiros:
            if tiro[self.Y['RECTANGLES']] >= 0:
                tiro[self.Y['RECTANGLES']] += self.velocidade_tiro
                if tiro[self.Y['RECTANGLES']] > 600:
                    tiro[self.Y['RECTANGLES']] = -100

        # 4. ATUALIZAR INIMIGOS
        for inimigo in self.lista_invertida_inimigos:
            # Inimigos descem em direção ao jogador
            inimigo[self.Y['RECTANGLES']] -= self.velocidade_inimigo
            
            # Se passar do fundo do ecrã, reseta para o topo
            if inimigo[self.Y['RECTANGLES']] < -40:
                inimigo[self.X['RECTANGLES']] = random.randint(50, 750)
                inimigo[self.Y['RECTANGLES']] = random.randint(580, 650)
            
            if self.collided(self.jogador, inimigo):
                print(f"Game Over! Pontuação Final: {self.pontuacao}")
                self.close()

        # 5. COLISÕES
        for tiro in self.lista_tiros:
            if tiro[self.Y['RECTANGLES']] < 0: 
                continue
            
            for inimigo in self.lista_invertida_inimigos:
                if self.collided(tiro, inimigo):
                    tiro[self.Y['RECTANGLES']] = -100  
                    inimigo[self.X['RECTANGLES']] = random.randint(50, 750)
                    inimigo[self.Y['RECTANGLES']] = random.randint(580, 650)
                    
                    self.pontuacao += 10
                    self.texto_score[self.CONTENT['TEXTS']] = f"Score: {self.pontuacao}"

if __name__ == "__main__":
    Jogo().run()