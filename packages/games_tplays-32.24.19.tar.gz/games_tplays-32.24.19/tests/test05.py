from games import Window, RGBA
import random

arte = Window(1000, 800, "Arte - GLITCH")
arte.bgColor = RGBA(5, 5, 10)

for _ in range(500):
    w = random.randint(1, 100)
    h = random.randint(1, 10)
    x = random.randint(0, 1000)
    y = random.randint(0, 800)
    arte.draw_rectangle(x, y, w, h, RGBA(random.randint(0, 255), 0, 255, 50))

arte.draw_text("SISTEMA CORROMPIDO", "Courier", 60, 250, 380, RGBA(0, 255, 150))

arte.run()
#arte.create_exe()
print('oi')