import pygame
import random
import sys

# Inicialização do Pygame
pygame.init()
pygame.font.init()

# --- CONFIGURAÇÕES DA JANELA ---
LARGURA, ALTURA = 800, 600
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Space Invaders - Pygame Puro")
clock = pygame.time.Clock()
FPS = 60

# --- CORES (RGB) ---
COR_FUNDO = (10, 10, 25)
COR_JOGADOR = (0, 200, 255)
COR_INIMIGO = (255, 50, 50)
COR_TIRO = (255, 255, 0)
COR_TEXTO = (255, 255, 255)
COR_ESTRELA = (255, 255, 200)

# --- CONFIGURAÇÃO DO JOGADOR ---
# Usamos o pygame.Rect nativo para facilitar movimento e colisões
jogador = pygame.Rect(375, 520, 50, 30)
velocidade_jogador = 7
pontuacao = 0

# --- FONTE DA UI ---
fonte = pygame.font.SysFont("Arial", 30, bold=True)

# --- POOL FIXA DE TIROS ---
max_tiros = 5
lista_tiros = []
for _ in range(max_tiros):
    # Começam fora do ecrã (inativos)
    tiro = pygame.Rect(0, -100, 8, 20)
    lista_tiros.append(tiro)
velocidade_tiro = 10

# Cooldown de disparo manual usando milissegundos do Pygame
ultimo_disparo = 0
cooldown_disparo = 200  # milissegundos

# --- INIMIGOS ---
lista_inimigos = []
velocidade_inimigo = 3
for _ in range(6):
    inimigo = pygame.Rect(random.randint(50, 750), random.randint(-100, -40), 40, 40)
    lista_inimigos.append(inimigo)

# --- ESTRELAS DE FUNDO ---
lista_estrelas = []
for _ in range(25):
    estrela = {
        "x": random.randint(0, LARGURA),
        "y": random.randint(0, ALTURA),
        "raio": random.randint(1, 3)
    }
    lista_estrelas.append(estrela)

# --- CICLO PRINCIPAL DO JOGO ---
running = True
while running:
    # 1. GESTÃO DE EVENTOS
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()

    # 2. CAPTURA DE TECLAS (INPUT)
    teclas = pygame.key.get_pressed()

    # Movimento do jogador
    if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
        jogador.x -= velocidade_jogador
        if jogador.x < 0:
            jogador.x = 0
            
    if teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
        jogador.x += velocidade_jogador
        if jogador.x > LARGURA - jogador.width:
            jogador.x = LARGURA - jogador.width

    # Disparo de tiros (com cooldown baseado no tempo atual)
    tempo_atual = pygame.time.get_ticks()
    if (teclas[pygame.K_SPACE] or teclas[pygame.K_w]) and (tempo_atual - ultimo_disparo > cooldown_disparo):
        for tiro in lista_tiros:
            if tiro.y < 0:  # Encontra um tiro livre na pool
                tiro.x = jogador.x + (jogador.width / 2) - (tiro.width / 2)
                tiro.y = jogador.y - tiro.height
                ultimo_disparo = tempo_atual
                break

    # 3. ATUALIZAÇÃO DA LÓGICA DO JOGO

    # Atualizar Posição dos Tiros
    for tiro in lista_tiros:
        if tiro.y >= 0:
            tiro.y -= velocidade_tiro  # No Pygame normal, o Y diminui para subir

    # Atualizar Posição dos Inimigos
    for inimigo in lista_inimigos:
        inimigo.y += velocidade_inimigo  # No Pygame normal, o Y aumenta para descer
        
        # Se passar do fundo do ecrã, reseta para o topo
        if inimigo.y > ALTURA:
            inimigo.x = random.randint(50, 750)
            inimigo.y = random.randint(-100, -40)
        
        # Colisão Inimigo vs Jogador
        if jogador.colliderect(inimigo):
            print(f"Game Over! Pontuação Final: {pontuacao}")
            running = False

    # Verificar Colisões Tiro vs Inimigo
    for tiro in lista_tiros:
        if tiro.y < 0:
            continue
        for inimigo in lista_inimigos:
            if tiro.colliderect(inimigo):
                tiro.y = -100  # Desativa o tiro mandando de volta para a pool
                inimigo.x = random.randint(50, 750)
                inimigo.y = random.randint(-100, -40)
                pontuacao += 10

    # 4. RENDERIZAÇÃO / DESENHO (DRAW)
    tela.fill(COR_FUNDO)

    # Desenhar as Estrelas de Fundo
    for estrela in lista_estrelas:
        pygame.draw.circle(tela, COR_ESTRELA, (estrela["x"], estrela["y"]), estrela["raio"])

    # Desenhar os Tiros Ativos
    for tiro in lista_tiros:
        if tiro.y >= 0:
            pygame.draw.rect(tela, COR_TIRO, tiro)

    # Desenhar o Jogador
    pygame.draw.rect(tela, COR_JOGADOR, jogador)

    # Desenhar os Inimigos
    for inimigo in lista_inimigos:
        pygame.draw.rect(tela, COR_INIMIGO, inimigo)

    # Renderizar e Desenhar o Texto do Score
    superficie_texto = fonte.render(f"Score: {pontuacao}", True, COR_TEXTO)
    tela.blit(superficie_texto, (20, 20))

    # Atualizar o ecrã e controlar o FPS
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()