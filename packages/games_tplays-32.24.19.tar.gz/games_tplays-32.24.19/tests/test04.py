def GAMES():
    import random
    from games import _2DGame, RGBA

    class TheGlitchMundo(_2DGame):
        def __init__(self):
            super().__init__(1000, 800, "The Glitch: Engine Mode")
            self.bgColor = RGBA(10, 10, 15)
            self.game_over = False
            
            # Jogador estático no centro
            self.player = self.draw_circle(500, 400, 15, RGBA(0, 255, 100))
            
            # Criar cenário
            paredes = [self.draw_rectangle(random.randint(-2500, 2500), 
                                          random.randint(-2500, 2500), 
                                          50, 50, RGBA(80, 0, 0)) for _ in range(150)]
            m_vis = self.draw_triangle(800, 800, 830, 800, 815, 830, RGBA(255, 0, 0))
            
            # Grupo do Mundo
            self.mundo = self.draw_group(0, 0, m_vis, *paredes)
            self.monstro = self.mundo[self.CONTENT['GROUPS']][0]

        def animation(self):
            # Limpa textos da frame anterior
            self.clear_objects(self.TEXTS)
            
            if self.game_over:
                # EFEITO VAZIO: Não desenhamos nada do mundo, apenas o erro
                self.clear_objects()

                self.draw_text("SISTEMA CORROMPIDO: GLITCH DETETADO", "Arial", 40, 120, 350, RGBA(255, 0, 0))
                self.draw_text("Pressione 'R' para reinicializar", "Arial", 20, 380, 420, RGBA(200, 200, 200))
                
                if self.pressed('r'):
                    self.game_over = False
                    self.__init__() # Reinicia o estado da classe
                return

            # Lógica de Movimento (Passadeira)
            v = 7
            dx, dy = 0, 0
            if self.pressed('w'): dy = -v # Sobe -> Mundo desce
            if self.pressed('s'): dy = v  # Desce -> Mundo sobe
            if self.pressed('a'): dx = v  # Esquerda -> Mundo direita
            if self.pressed('d'): dx = -v # Direita -> Mundo esquerda

            self.mundo[self.X['GROUPS']] += dx
            self.mundo[self.Y['GROUPS']] += dy

            # IA do Monstro (Perseguição X e Y)
            m_speed = 3
            m_dx = m_speed if self.monstro[0] < 500 else -m_speed
            m_dy = m_speed if self.monstro[1] < 400 else -m_speed
            for i in range(0, 6, 2):
                self.monstro[i] += m_dx
                self.monstro[i + 1] += m_dy

            # Verificação de Morte
            if self.collided(self.player, self.monstro):
                self.game_over = True
                # Escondemos o mundo removendo-o da renderização visual (opcional se usares flags no motor)
                # Mas aqui basta o 'return' no topo do frame seguinte para limpar tudo

            # Colisão com Paredes
            for i in range(1, len(self.mundo[self.CONTENT['GROUPS']])):
                if self.collided(self.player, self.mundo[self.CONTENT['GROUPS']][i]):
                    self.mundo[self.X['GROUPS']] -= dx
                    self.mundo[self.Y['GROUPS']] -= dy
                    break

            self.draw_text(f"X: {int(self.mundo[0])} Y: {int(self.mundo[1])}", "Arial", 18, 20, 760, RGBA(255,255,255))

    TheGlitchMundo().run()
def PYGAME():
    import pygame
    import random

    pygame.init()
    screen = pygame.display.set_mode((1000, 800))
    clock = pygame.time.Clock()
    f_msg = pygame.font.SysFont("Arial", 45)
    f_sub = pygame.font.SysFont("Arial", 22)

    player_pos = [500, 400]
    camera_offset = [0, 0]
    walls = [[random.randint(-2500, 2500), random.randint(-2500, 2500), 50, 50] for _ in range(150)]
    monster_pos = [800, 800]
    game_over = False

    running = True
    while running:
        screen.fill((10, 10, 15)) # Limpa o fundo sempre
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False

        if not game_over:
            keys = pygame.key.get_pressed()
            v = 7
            dx, dy = 0, 0
            if keys[pygame.K_w]: dy = v
            if keys[pygame.K_s]: dy = -v
            if keys[pygame.K_a]: dx = v
            if keys[pygame.K_d]: dx = -v

            camera_offset[0] += dx
            camera_offset[1] += dy

            # Colisão Paredes
            p_rect = pygame.Rect(player_pos[0]-15, player_pos[1]-15, 30, 30)
            for w in walls:
                w_rect = pygame.Rect(w[0] + camera_offset[0], w[1] + camera_offset[1], w[2], w[3])
                if p_rect.colliderect(w_rect):
                    camera_offset[0] -= dx
                    camera_offset[1] -= dy
                    break

            # IA Monstro
            target_x, target_y = 500 - camera_offset[0], 400 - camera_offset[1]
            if monster_pos[0] < target_x: monster_pos[0] += 3
            elif monster_pos[0] > target_x: monster_pos[0] -= 3
            if monster_pos[1] < target_y: monster_pos[1] += 3
            elif monster_pos[1] > target_y: monster_pos[1] -= 3

            # DESENHAR MUNDO (Só desenha se o jogo estiver ativo)
            for w in walls:
                pygame.draw.rect(screen, (80, 0, 0), (w[0] + camera_offset[0], w[1] + camera_offset[1], w[2], w[3]))
            
            vx, vy = monster_pos[0] + camera_offset[0], monster_pos[1] + camera_offset[1]
            pygame.draw.polygon(screen, (255, 0, 0), [(vx + 15, vy), (vx, vy + 30), (vx + 30, vy + 30)])
            pygame.draw.circle(screen, (0, 255, 100), player_pos, 15)

            # Verificar Morte
            m_rect = pygame.Rect(vx, vy, 30, 30)
            if p_rect.colliderect(m_rect):
                game_over = True
        else:
            # TELA DE MORTE (Mundo não é desenhado aqui, fica vazio)
            txt = f_msg.render("CONEXÃO INTERROMPIDA PELO GLITCH", True, (255, 0, 0))
            sub = f_sub.render("Pressione 'R' para reiniciar o sistema", True, (180, 180, 180))
            screen.blit(txt, (100, 350))
            screen.blit(sub, (340, 420))
            
            if pygame.key.get_pressed()[pygame.K_r]:
                PYGAME() # Recursão para resetar
                return

        pygame.display.flip()
        clock.tick(60)
    pygame.quit()

GAMES()