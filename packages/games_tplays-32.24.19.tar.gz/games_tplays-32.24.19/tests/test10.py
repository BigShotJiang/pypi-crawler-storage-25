from games import get_color

linhas = [f"{name} - {rgba}" for name, rgba in get_color().items()]

with open("tests/coresTest10.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(linhas))