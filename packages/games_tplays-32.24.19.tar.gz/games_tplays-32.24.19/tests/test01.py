from games import Window, RGBA, math
import random

class JogoEspacial(Window):
    def __init__(self):
        super().__init__(800, 600, "Sobrevivência Orbital 2.0 - Tiago")
        
        # --- CONFIGURAÇÃO DO ESPAÇO ---
        self.sol_x, self.sol_y = 400, 300
        self.sol = self.draw_circle(self.sol_x, self.sol_y, 55, RGBA(255, 220, 0))
        
        # --- JOGADOR (TERRA) ---
        self.terra = self.draw_rectangle(0, 0, 25, 25, RGBA(0, 180, 255))
        self.distancia = 200
        self.angulo = 0.0
        
        # --- INIMIGOS (ASTEROIDES) ---
        self.asteroides = []
        self.velocidade_asteroide = 1.5
        for _ in range(6):
            self.criar_asteroide()
            
        self.vitorias = 0
        self.game_over = False

    def criar_asteroide(self):
        lado = random.choice(['N', 'S', 'E', 'W'])
        if lado == 'N': x, y = random.randint(0, 800), 650
        elif lado == 'S': x, y = random.randint(0, 800), -50
        elif lado == 'E': x, y = 850, random.randint(0, 600)
        else: x, y = -50, random.randint(0, 600)
        
        cor = random.randint(100, 180)
        t = self.draw_triangle(x, y, x+25, y+45, x+50, y, RGBA(cor, cor, cor))
        dx = (self.sol_x - x) / 200
        dy = (self.sol_y - y) / 200
        self.asteroides.append({'obj': t, 'dx': dx, 'dy': dy})

    def animation(self):
        # 1. Verificação de Saída e Reinício
        if self.pressed('escape'): 
            self.close()

        if self.game_over:
            if self.pressed('r'):
                # Limpamos os desenhos antigos da memória antes de reiniciar
                self.clear_drawings()
                self.__init__()
            return

        # 2. MOVIMENTO DA TERRA
        self.angulo += 0.04
        if self.pressed('w'): self.distancia += 4
        if self.pressed('s'): self.distancia -= 4
        
        self.distancia = max(65, min(self.distancia, 350))

        nx = self.sol_x + math.cos(self.angulo) * self.distancia
        ny = self.sol_y + math.sin(self.angulo) * self.distancia
        
        self.terra[self.X[self.RECTANGLES]] = nx - 12.5
        self.terra[self.Y[self.RECTANGLES]] = ny - 12.5
        self.terra[self.ROTATION[self.RECTANGLES]] += 5

        # 3. MOVIMENTO E LÓGICA DOS ASTEROIDES
        for ast in self.asteroides[:]:
            ast['obj'][0] += ast['dx'] * self.velocidade_asteroide
            ast['obj'][2] += ast['dx'] * self.velocidade_asteroide
            ast['obj'][4] += ast['dx'] * self.velocidade_asteroide
            
            ast['obj'][1] += ast['dy'] * self.velocidade_asteroide
            ast['obj'][3] += ast['dy'] * self.velocidade_asteroide
            ast['obj'][5] += ast['dy'] * self.velocidade_asteroide
            
            ast['obj'][7] += 2 

            if self.collided(self.terra, ast['obj']):
                self.finalizar_jogo("BATESTE NUM ASTEROIDE!")
                return

            if self.collided(ast['obj'], self.sol):
                # Removemos o desenho da lista de triângulos (índice 3)
                if ast['obj'] in self.draws[3]:
                    self.draws[3].remove(ast['obj'])
                self.asteroides.remove(ast)
                self.criar_asteroide()
                self.vitorias += 1
                self.velocidade_asteroide += 0.05
                print(f"Pontos: {self.vitorias} | Vel: {self.velocidade_asteroide:.1f}")

        # 4. COLISÃO COM O SOL
        if self.collided(self.terra, self.sol):
            self.finalizar_jogo("O SOL QUEIMOU A TERRA!")

    def finalizar_jogo(self, mensagem):
        self.game_over = True
        self.terra[self.COLOR[self.RECTANGLES]] = RGBA(255, 0, 0)
        print("\n" + "="*30)
        print(f"GAME OVER: {mensagem}")
        print(f"PONTUAÇÃO FINAL: {self.vitorias}")
        print("Pressiona 'R' para recomeçar ou 'ESC' para sair.")
        print("="*30)

if __name__ == "__main__":
    try:
        jogo = JogoEspacial()
        jogo.run()

    except (SystemExit, KeyboardInterrupt):
        pass