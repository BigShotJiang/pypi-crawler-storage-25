import arcade

cor = arcade.color

class Teste(arcade.Window):
    def __init__(self):
        super().__init__(800, 600, "O meu jogo")
        arcade.set_background_color(cor.BLACK)
        
        self.segundos = 0
        self.total_time = 0.0

    def on_draw(self):
        self.clear()
        
        arcade.draw_text(
            f"Segundos: {self.segundos}",
            50, 50,
            cor.WHITE,
            font_size=50,
            font_name="Arial",
            bold=True
        )

    def on_update(self, delta_time):
        self.total_time += delta_time
        
        if self.total_time >= 1.0:
            self.segundos += 1
            self.total_time -= 1.0

if __name__ == "__main__":
    window = Teste()
    arcade.run()