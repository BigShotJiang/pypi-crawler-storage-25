import os
import warnings

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
warnings.filterwarnings("ignore", category=UserWarning)

import pygame
from OpenGL.GL import *
from OpenGL.GLU import gluOrtho2D
import math
import re
import sys
import shutil
import subprocess
import time
import matplotlib.colors as mc
import requests
import io
import inspect
import time

__author__ = 'TiagoPlays'
__version__ = '32.24.19'
VERSION = tuple(map(int, __version__.split('.')))

__all__ = ['VERSION', 'Window', 'RGBA', 'get_color', 'url', 'path', 'audio']

def RGBA(red: int | float = 0, green: int | float = 0, blue: int | float = 0, alpha: int | float = 1.0) -> tuple:
    r, g, b, a = max(0, min(255, red)), max(0, min(255, green)), max(0, min(255, blue)), max(0, min(1, alpha))
    return (r, g, b, a)

def get_color() -> dict:
    colors = {
        'transparent': RGBA(alpha=0),
        'invisible': RGBA(alpha=0)
    }
    for name, hex_color in mc.CSS4_COLORS.items():
        r, g, b, a = mc.to_rgba(hex_color)
        colors[name.lower()] = RGBA(int(r*255), int(g*255), int(b*255), a)

    base_names = list(mc.CSS4_COLORS.keys())
    style_modifiers = {
        'dark': -60, 'darker': -85, 'deep': -40, 'dim': -25, 'shadow': -70,
        'cold': -15, 'soft': -8, 'pale': 15, 'light': 25, 'lighter': 55,
        'warm': 12, 'bright': 40, 'intense': 60, 'neon': 75, 'pastel': 45,
        'rich': 18, 'vibrant': 50, 'clear': 30, 'sun': 35, 'night': -65,
        'muted': -20, 'electric': 65, 'faded': 22, 'matte': -12, 'tinted': 10, 'shaded': -45,
        'ghost': 0.2, 'glass': 0.5
    }

    for style, modifier in style_modifiers.items():
        for name in base_names:
            r, g, b, a = mc.to_rgba(mc.CSS4_COLORS[name])
            if isinstance(modifier, float):
                nr, ng, nb = int(r*255), int(g*255), int(b*255)
                na = modifier
            else:
                nr = max(0, min(255, int(r * 255 + modifier)))
                ng = max(0, min(255, int(g * 255 + modifier)))
                nb = max(0, min(255, int(b * 255 + modifier)))
                na = a
            colors[f'{style}_{name}'] = RGBA(nr, ng, nb, na)
    return colors

class _GroupList2DGame(list):
    def __init__(self, data: list, game_ref):
        super().__init__(data)
        self.game = game_ref

    def __setitem__(self, index: int, value: list):
        if index == 0 or index == 1:
            diff = value - self[index]
            for obj in self[2]:
                if isinstance(obj, _GroupList2DGame):
                    obj[index] += diff
                    continue
                
                kind = obj[-1]
                if kind in [self.game.RECTANGLES, self.game.CIRCLES]:
                    obj[0] += diff if index == 0 else 0
                    obj[1] += diff if index == 1 else 0
                elif kind == self.game.TRIANGLES:
                    for i in range(index, 6, 2): obj[i] += diff
                elif kind == self.game.LINES:
                    for i in range(index, 4, 2): obj[i] += diff
                elif kind == self.game.TEXTS:
                    obj[index + 3] += diff
                elif kind == self.game.IMAGES:
                    obj[index + 1] += diff
        super().__setitem__(index, value)

class path:
    def __init__(self, path: str):
        script_path = os.path.realpath(sys.argv[0])
        base_dir = os.path.dirname(script_path)
        self.__fullPath__ = os.path.join(base_dir, path)

    def __getIcon__(self) -> io.BytesIO:
        with open(self.__fullPath__, "rb") as f:
            return io.BytesIO(f.read())

class url:
    def __init__(self, url: str):
        self.__url__ = url

    def __getIcon__(self) -> io.BytesIO:
        response = requests.get(self.__url__)
        return io.BytesIO(response.content)
    
__default_icon__ = url('https://tse3.mm.bing.net/th/id/OIP.kB2t1VMox767tj41hP6MawHaHY?rs=1&pid=ImgDetMain&o=7&rm=3&adlt=strict')

class audio:
    def __init__(self, audio: path | url, loop: bool = False):
        self.__audio__ = [audio, loop]

class Window:
    def __init__(self, width: int | float, height: int | float, title: str = 'games.Window', icon: path | url = __default_icon__, show_errors_icon: bool = True):
        pygame.init()
        pygame.font.init()

        self.windowSize: tuple = (width, height)
        self.title = title
        self.bgColor: tuple = RGBA(20, 20, 20)
        self.fps = 60

        try:
            if isinstance(icon, (url, path)):
                buffer = icon.__getIcon__()
                icon_surface = pygame.image.load(buffer)
            pygame.display.set_icon(icon_surface)
        except:
            if show_errors_icon:
                if isinstance(icon, path):
                    print(f'It was not possible to load the icon from the URL "{icon.__fullPath__}"')
                else:
                    print(f'Could not load the icon from the path "{icon.__url__}"')

        self.fps_counter = 0
        initial_keys = pygame.key.get_pressed()
        self.__last_keys = initial_keys
        self.__current_keys_state = initial_keys

        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2)
            pygame.mixer.set_num_channels(16)
        except Exception as e:
            print(f"Failed to initialize audio mixer: {e}")

        self.__audio_players = {}

        self.RECTANGLES = 'RECTANGLE_TYPE'
        self.CIRCLES = 'CIRCLE_TYPE'
        self.LINES = 'LINE_TYPE'
        self.TRIANGLES = 'TRIANGLE_TYPE'
        self.TEXTS = 'TEXT_TYPE'
        self.GROUPS = 'GROUP_TYPE'
        self.IMAGES = 'IMAGE_TYPE'

        self.CONTENT = {self.TEXTS: 0, self.GROUPS: 2, self.IMAGES: 0}
        self.FONT_NAME = {self.TEXTS: 1}
        self.FONT_SIZE = {self.TEXTS: 2}
        self.X = {self.RECTANGLES: 0, self.CIRCLES: 0, self.LINES: {'start': 0, 'end': 2}, self.TRIANGLES: {'vertex1': 0, 'vertex2': 2, 'vertex3': 4}, self.TEXTS: 3, self.GROUPS: 0, self.IMAGES: 1}
        self.Y = {self.RECTANGLES: 1, self.CIRCLES: 1, self.LINES: {'start': 1, 'end': 3}, self.TRIANGLES: {'vertex1': 1, 'vertex2': 3, 'vertex3': 5}, self.TEXTS: 4, self.GROUPS: 1, self.IMAGES: 2}
        self.WIDTH = {self.RECTANGLES: 2, self.TEXTS: 5, self.IMAGES: 3}
        self.HEIGHT = {self.RECTANGLES: 3, self.TEXTS: 6, self.IMAGES: 4}
        self.RADIUS = {self.CIRCLES: 2}
        self.COLOR = {self.RECTANGLES: 4, self.CIRCLES: 3, self.LINES: 5, self.TRIANGLES: 6, self.TEXTS: 5}
        self.THICKNESS = {self.LINES: 4}
        self.ROTATION = {self.RECTANGLES: 5, self.TRIANGLES: 7, self.LINES: 6, self.TEXTS: 6, self.GROUPS: 3, self.IMAGES: 6}
        self.BOLD = {self.TEXTS: 7}
        self.ITALIC = {self.TEXTS: 8}
        self.ROUNDING = {self.IMAGES: 5}
        self.LAYER = {self.RECTANGLES: 6, self.CIRCLES: 4, self.LINES: 7, self.TRIANGLES: 8, self.TEXTS: 10, self.GROUPS: 4, self.IMAGES: 11}

        self.draws = []

    def after(self, milliseconds: int) -> bool:
        if not hasattr(self, '_timers'):
            self._timers = {}
        
        current_time = time.perf_counter() * 1000
        if not hasattr(self, '_last_frame_time'):
            self._last_frame_time = current_time

        delta_ms = current_time - self._last_frame_time
        self._last_frame_time = current_time

        frame = inspect.currentframe().f_back
        timer_id = f"{frame.f_code.co_filename}:{frame.f_lineno}"

        if timer_id not in self._timers:
            self._timers[timer_id] = {
                'accumulated': 0.0
            }

        timer = self._timers[timer_id]

        timer['accumulated'] += delta_ms

        if timer['accumulated'] >= milliseconds:
            timer['accumulated'] -= milliseconds
            return True

        return False

    def draw_rectangle(self, x: int | float, y: int | float, width: int | float, height: int | float, rgba: tuple, rotation: int | float = 0.0, layer: int = 1) -> list:
        config = [x, y, width, height, rgba, rotation, max(1, layer), self.RECTANGLES]
        self.draws.append(config)
        return self.draws[-1]

    def draw_circle(self, centerX: int | float, centerY: int | float, radius: int | float, rgba: tuple, layer: int = 1) -> list:
        config = [centerX, centerY, radius, rgba, max(1, layer), self.CIRCLES]
        self.draws.append(config)
        return self.draws[-1]

    def draw_line(self, startX: int | float, startY: int | float, endX:int | float, endY: int | float, rgba: tuple, thickness: int | float = 3, rotation: int | float = 0.0, layer: int = 1) -> list:
        config = [startX, startY, endX, endY, thickness, rgba, rotation, max(1, layer), self.LINES]
        self.draws.append(config)
        return self.draws[-1]

    def draw_triangle(self, vertex1X: int | float, vertex1Y: int | float, vertex2X: int | float, vertex2Y: int | float, vertex3X: int | float, vertex3Y: int | float, rgba: tuple, rotation: int | float = 0.0, layer: int = 1) -> list:
        config = [vertex1X, vertex1Y, vertex2X, vertex2Y, vertex3X, vertex3Y, rgba, rotation, max(1, layer), self.TRIANGLES]
        self.draws.append(config)
        return self.draws[-1]

    def draw_text(self, text: str, font_name: str, size: int | float, x: int | float, y: int | float, rgba: tuple, bold: bool = False, italic: bool = False, rotation: int | float = 0.0, layer: int = 1) -> list:
        config = [text, font_name, size, x, y, rgba, rotation, bold, italic, None, max(1, layer), self.TEXTS]
        self.draws.append(config)
        return self.draws[-1]
    
    def draw_image(self, image: path | url, x: int | float, y: int | float, width: int | float, height: int | float, rounding: int | float = 0.0, rotation: int | float = 0.0, show_errors: bool = True, layer: int = 1) -> list:
        config = [image, x, y, width, height, rounding, rotation, None, "IMAGE_FLAG", show_errors, None, max(1, layer), self.IMAGES]
        self.draws.append(config)
        return self.draws[-1]

    def draw_group(self, x: int | float, y: int | float, *drawings, rotation: int | float = 0.0, layer: int = 1) -> list:
        for drawing in drawings:
            self.clear_drawings(drawing)
        config = _GroupList2DGame([x, y, list(drawings), rotation, max(1, layer), self.GROUPS], self)
        self.draws.append(config)
        return self.draws[-1]
    
    def play_audio(self, audio: audio, show_errors: bool = True):
        try:
            _audio, loop = audio.__audio__

            m_key = _audio.__fullPath__ if isinstance(_audio, path) else _audio.__url__

            if m_key in self.__audio_players:
                self.stop_audio(_audio)

            if isinstance(_audio, path):
                sound_obj = pygame.mixer.Sound(_audio.__fullPath__)
            else:
                response = requests.get(_audio.__url__)
                response.raise_for_status()
                sound_buffer = io.BytesIO(response.content)
                sound_obj = pygame.mixer.Sound(sound_buffer)

            channel = pygame.mixer.find_channel()
            if channel is None:
                if show_errors: print("Error: no free audio channels available")
                return

            self.__audio_players[m_key] = channel

            channel.play(sound_obj, loops=-1 if loop else 0)

        except Exception as e:
            if show_errors: print(f"Error: audio (play): {e}")

    def play_audios(self, *audios: audio, show_errors: bool = True):
        for audio in audios:
            self.play_audio(audio, show_errors)

    def stop_audio(self, audio: path | url, show_errors: bool = True):
        try:
            m_key = audio.__fullPath__ if isinstance(audio, path) else audio.__url__
            if m_key in self.__audio_players:
                channel = self.__audio_players[m_key]
                if channel.get_busy():
                    channel.stop()
                del self.__audio_players[m_key]
        except Exception as e:
            if show_errors: print(f"Error: audio (stop): {e}")

    def stop_audios(self, *audios: path | url, show_errors: bool = True):
        for audio in audios:
            self.stop_audio(audio, show_errors)

    def stop_all_audios(self, show_errors: bool = True):
        try:
            pygame.mixer.stop()
            self.__audio_players.clear()
        except Exception as e:
            if show_errors: print(f"Error: audio (stop_all): {e}")

    def __get_aabb(self, draw: list) -> list:
        if isinstance(draw, _GroupList2DGame):
            if not draw[2]: return [draw[0], draw[1], draw[0], draw[1]]
            boxes = [self.__get_aabb(item) for item in draw[2]]
            return [min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes)]

        kind = draw[-1]
        if kind == self.RECTANGLES:
            return [draw[0], draw[1], draw[0]+draw[2], draw[1]+draw[3]]
        elif kind == self.CIRCLES:
            return [draw[0]-draw[2], draw[1]-draw[2], draw[0]+draw[2], draw[1]+draw[2]]
        elif kind == self.TRIANGLES:
            return [min(draw[0:5:2]), min(draw[1:6:2]), max(draw[0:5:2]), max(draw[1:6:2])]
        elif kind == self.LINES:
            return [min(draw[0], draw[2]), min(draw[1], draw[3]), max(draw[0], draw[2]), max(draw[1], draw[3])]
        elif kind == self.TEXTS:
            return [draw[3], draw[4], draw[3]+50, draw[4]+20]
        elif kind == self.IMAGES:
            return [draw[1], draw[2], draw[1]+draw[3], draw[2]+draw[4]]
        return [0, 0, 0, 0]

    def collided(self, draw1: list, draw2: list) -> bool:
        if not isinstance(draw1, _GroupList2DGame) and not isinstance(draw2, _GroupList2DGame):
            if draw1[-1] == self.CIRCLES and draw2[-1] == self.CIRCLES:
                return ((draw1[0]-draw2[0])**2 + (draw1[1]-draw2[1])**2) <= (draw1[2]+draw2[2])**2
            
        b1, b2 = self.__get_aabb(draw1), self.__get_aabb(draw2)
        return b1[0] < b2[2] and b1[2] > b2[0] and b1[1] < b2[3] and b1[3] > b2[1]

    def __check_key_state(self, key: str | int, keys_buffer: list) -> bool:
        k_val = str(key).strip()

        if k_val.isdigit():
            try:
                if keys_buffer[getattr(pygame, f"K_{k_val}")]: return True
            except (AttributeError, IndexError): pass
            
            try:
                if keys_buffer[getattr(pygame, f"K_KP{k_val}")]: return True
            except (AttributeError, IndexError): pass

        if "+" in k_val:
            parts = k_val.split("+")
            return all(self.__check_key_state(p.strip(), keys_buffer) for p in parts)

        k_str = k_val.lower()
        mapping = {
            "ctrl": [pygame.K_LCTRL, pygame.K_RCTRL],
            "shift": [pygame.K_LSHIFT, pygame.K_RSHIFT],
            "alt": [pygame.K_LALT, pygame.K_RALT],
            "win": [pygame.K_LSUPER, pygame.K_RSUPER],
            "cmd": [pygame.K_LMETA, pygame.K_RMETA],
            "enter": [pygame.K_RETURN, pygame.K_KP_ENTER],
            "esc": [pygame.K_ESCAPE]
        }

        if k_str in mapping:
            try: return any(keys_buffer[k_code] for k_code in mapping[k_str])
            except IndexError: return False

        try:
            suffix = k_str if len(k_str) == 1 else k_str.upper()
            key_code = getattr(pygame, f"K_{suffix}")
            return bool(keys_buffer[key_code])
        except (AttributeError, IndexError):
            return False

    def pressed(self, key: str | int) -> bool:
        return self.__check_key_state(key, self.__current_keys_state)

    def __was_pressed(self, key: str | int) -> bool:
        if self.__last_keys is None: return False
        return self.__check_key_state(key, self.__last_keys)

    def clicked(self, key: str | int) -> bool:
        return self.pressed(key) and not self.__was_pressed(key)

    def animation(self):
        pass

    def clear_objects(self, *categories):
        if not categories:
            self.draws.clear()
        else:
            self.draws = [obj for obj in self.draws if obj[-1] not in categories]

    def clear_drawings(self, *drawings):
        for drawing in drawings:
            if drawing in self.draws:
                self.draws.remove(drawing)

    def close(self):
        self.running = False

    def run(self):
        pygame.display.set_mode(self.windowSize, pygame.DOUBLEBUF | pygame.OPENGL)
        pygame.display.set_caption(self.title)
        
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        def setup_2d():
            glMatrixMode(GL_PROJECTION)
            glLoadIdentity()
            gluOrtho2D(0, self.windowSize[0], 0, self.windowSize[1])
            glMatrixMode(GL_MODELVIEW)
            glLoadIdentity()

        def render_item(item):
            if isinstance(item, _GroupList2DGame):
                gx, gy, items, g_angle, glayer, gkind = item
                glPushMatrix()
                glTranslatef(gx, gy, 0)
                glRotatef(-g_angle, 0, 0, 1)
                glTranslatef(-gx, -gy, 0)
                for sub_item in items:
                    render_item(sub_item)
                glPopMatrix()
                return

            kind = item[-1]
            
            if kind == self.RECTANGLES:
                x, y, w, h, c, angle, layer, _ = item
                r, g, b, a = c
                glPushMatrix()
                glTranslatef(x + w/2, y + h/2, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-w/2, -h/2, 0)
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_QUADS)
                glVertex2f(0, 0); glVertex2f(w, 0); glVertex2f(w, h); glVertex2f(0, h)
                glEnd()
                glPopMatrix()

            elif kind == self.CIRCLES:
                cx, cy, radius, c, layer, _ = item
                r, g, b, a = c
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_POLYGON)
                for i in range(360):
                    theta = i * math.pi / 180
                    glVertex2f(cx + math.cos(theta) * radius, cy + math.sin(theta) * radius)
                glEnd()

            elif kind == self.LINES:
                x1, y1, x2, y2, t, c, angle, layer, _ = item
                r, g, b, a = c
                mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                glPushMatrix()
                glTranslatef(mid_x, mid_y, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-mid_x, -mid_y, 0)
                glLineWidth(0.1 if t <= 0 else t)
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_LINES)
                glVertex2f(x1, y1); glVertex2f(x2, y2)
                glEnd()
                glPopMatrix()

            elif kind == self.TRIANGLES:
                v1x, v1y, v2x, v2y, v3x, v3y, c, angle, layer, _ = item
                r, g, b, a = c
                cx, cy = (v1x + v2x + v3x)/3, (v1y + v2y + v3y)/3
                glPushMatrix()
                glTranslatef(cx, cy, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-cx, -cy, 0)
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_TRIANGLES)
                glVertex2f(v1x, v1y); glVertex2f(v2x, v2y); glVertex2f(v3x, v3y)
                glEnd()
                glPopMatrix()

            elif kind == self.TEXTS:
                txt_string, f_name, f_size, x, y, c, angle, is_bold, is_italic, tex_data_store, layer, _ = item
                r, g, b, a = c
                
                glPushMatrix()
                font = pygame.font.SysFont(f_name, f_size, is_bold, is_italic)
                surf = font.render(txt_string, True, (255, 255, 255))
                w, h = surf.get_size()
                
                glTranslatef(x + w/2, y + h/2, 0)
                glRotatef(-angle, 0, 0, 1)
                glTranslatef(-w/2, -h/2, 0)
                glEnable(GL_TEXTURE_2D)
                
                if not isinstance(tex_data_store, dict) or tex_data_store.get("txt") != txt_string:
                    if isinstance(tex_data_store, dict) and "id" in tex_data_store:
                        glDeleteTextures([tex_data_store["id"]])
                    
                    text_bytes = pygame.image.tostring(surf, "RGBA", True)
                    new_tex_id = glGenTextures(1)
                    glBindTexture(GL_TEXTURE_2D, new_tex_id)
                    glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
                    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, text_bytes)
                    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
                    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
                    
                    item[9] = {"txt": txt_string, "id": new_tex_id}
                else:
                    glBindTexture(GL_TEXTURE_2D, tex_data_store["id"])
                
                glColor4f(r/255, g/255, b/255, a)
                glBegin(GL_QUADS)
                glTexCoord2f(0, 0); glVertex2f(0, 0)
                glTexCoord2f(1, 0); glVertex2f(w, 0)
                glTexCoord2f(1, 1); glVertex2f(w, h)
                glTexCoord2f(0, 1); glVertex2f(0, h)
                glEnd()
                glDisable(GL_TEXTURE_2D)
                glPopMatrix()

            elif kind == self.IMAGES:
                img_obj, x, y, w, h, _, angle, _, _, show_errors, _, _, _ = item
                if item[7] is None and item[10] is None:
                    try:
                        buffer = img_obj.__getIcon__()
                        surf = pygame.image.load(buffer).convert_alpha()
                        surf = pygame.transform.scale(surf, (int(w), int(h)))
                        img_data = pygame.image.tostring(surf, "RGBA", True)
                        item[7] = glGenTextures(1)
                        glBindTexture(GL_TEXTURE_2D, item[7])
                        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, int(w), int(h), 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)
                        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
                        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
                    except Exception as e:
                        item[10] = True
                        if show_errors:
                            if isinstance(img_obj, path):
                                print(f'Error loading image from path "{img_obj.__fullPath__}": {e}')
                            elif isinstance(img_obj, url):
                                print(f'Error loading image from URL "{img_obj.__url__}": {e}')
                            else:
                                print(f'Error loading image: {e}')
                        return

                if item[7] is not None:
                    glPushMatrix()
                    glTranslatef(x + w/2, y + h/2, 0)
                    glRotatef(-angle, 0, 0, 1)
                    glTranslatef(-w/2, -h/2, 0)
                    glEnable(GL_TEXTURE_2D)
                    glBindTexture(GL_TEXTURE_2D, item[7])
                    glColor4f(1.0, 1.0, 1.0, 1.0)
                    glBegin(GL_QUADS)
                    glTexCoord2f(0, 0); glVertex2f(0, 0)
                    glTexCoord2f(1, 0); glVertex2f(w, 0)
                    glTexCoord2f(1, 1); glVertex2f(w, h)
                    glTexCoord2f(0, 1); glVertex2f(0, h)
                    glEnd()
                    glDisable(GL_TEXTURE_2D)
                    glPopMatrix()

        def draw():
            sorted_draws = sorted(
                self.draws, 
                key=lambda obj: obj[4] if isinstance(obj, _GroupList2DGame) else obj[-2]
            )
            for item in sorted_draws:
                render_item(item)

        self.running = True
        clock = pygame.time.Clock()

        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.close()

            self.__last_keys = self.__current_keys_state
            self.__current_keys_state = pygame.key.get_pressed()

            self.fps_counter += 1
            self.animation()

            if not self.running: break

            r, g, b, a = self.bgColor
            r *= a; g *= a; b *= a

            glClearColor(r / 255, g / 255, b / 255, 1.0)
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

            setup_2d()
            draw()

            pygame.display.flip()
            clock.tick(self.fps if self.fps > 0 else 1)

        for item in self.draws:
            if isinstance(item, _GroupList2DGame):
                continue
            kind = item[-1]
            if kind == self.TEXTS and item[9] is not None:
                try: glDeleteTextures([item[9]])
                except: pass
            elif kind == self.IMAGES and item[7] is not None:
                try: glDeleteTextures([item[7]])
                except: pass

        pygame.quit()

    def create_exe(self, show_mensages: bool = True, show_errors: bool = True, show_building_outputs: bool = False):
        safe_title = re.sub(r'[\\\\/*?:"<>|]', "", self.title).strip().replace(" ", "_")
        original_script = os.path.abspath(sys.argv[0])
        root_dir = os.path.dirname(original_script)
        temp_build_folder = os.path.join(root_dir, f"_temp_build_{safe_title}")
        temp_script = os.path.join(root_dir, f"{safe_title}_temp.py")
        
        try:
            if not os.path.exists(temp_build_folder): os.makedirs(temp_build_folder)
            with open(original_script, 'r', encoding='utf-8') as f: lines = f.readlines()
            with open(temp_script, 'w', encoding='utf-8') as f:
                for line in lines:
                    if '.create_exe(' in line: continue
                    f.write(line)

            stdout_setting = None if show_building_outputs else subprocess.DEVNULL
            stderr_setting = None if show_building_outputs else subprocess.DEVNULL

            if show_mensages: print(f"Generating executable: {safe_title}...")
            subprocess.run([
                sys.executable, '-m', 'PyInstaller', '--onefile', '--noconsole',
                '--name', safe_title, '--specpath', temp_build_folder,
                '--workpath', os.path.join(temp_build_folder, "build"),
                '--distpath', os.path.join(temp_build_folder, "dist"), temp_script
            ], stdout=stdout_setting, stderr=stderr_setting, check=True)

            exe_ext = ".exe" if os.name == 'nt' else ""
            exe_name = f"{safe_title}{exe_ext}"
            source_exe = os.path.join(temp_build_folder, "dist", exe_name)
            final_exe_path = os.path.join(root_dir, exe_name)

            time.sleep(3) 
            if os.path.exists(source_exe):
                if os.path.exists(final_exe_path): os.remove(final_exe_path)
                shutil.move(source_exe, final_exe_path)

            if os.path.exists(temp_script): os.remove(temp_script)

            def force_remove(action, name, exc):
                try:
                    os.chmod(name, 0o777)
                    if os.path.isdir(name): shutil.rmtree(name)
                    else: os.remove(name)
                except Exception: pass

            if os.path.exists(temp_build_folder):
                for _ in range(5):
                    try:
                        shutil.rmtree(temp_build_folder, onerror=force_remove)
                        break
                    except: time.sleep(1)

            if show_mensages: print(f"Success! Executable created at: {final_exe_path}.")
        except subprocess.CalledProcessError:
            if show_errors: print("Error: PyInstaller failed.")
        except Exception as e:
            if show_errors: print(f"Unexpected error: {e}")