"""
PV-tool Integration Wrapper
Integreert de PV-tool functionaliteit in de Streamlit app
"""

import sys
from pathlib import Path

# Voeg de pv-tool directory toe aan het Python path
PV_TOOL_PATH = Path(__file__).parent.parent / "pv-tool-submodule"
if str(PV_TOOL_PATH) not in sys.path:
    sys.path.insert(0, str(PV_TOOL_PATH))

# Importeer PV-tool modules
try:
    from pv_tool.imports.import_data import Dbase
    from pv_tool.cphi_analysis.c_phi_analysis import CPhiAnalyse
    from pv_tool.shansep_analysis.shansep_analysis import SHANSEP
    from pv_tool.sutabel_analysis.sutabel_analysis import SUTABEL

    PV_TOOL_AVAILABLE = True
except ImportError as e:
    print(f"Warning: PV-tool modules not available: {e}")
    PV_TOOL_AVAILABLE = False
    Dbase = None
    CPhiAnalyse = None
    SHANSEP = None
    SUTABEL = None


class PVToolWrapper:
    """Wrapper class voor PV-tool functionaliteit"""

    def __init__(self):
        self.available = PV_TOOL_AVAILABLE
        self._dbase = None

    @property
    def dbase(self):
        """Get dbase, restore from streamlit session state if needed"""
        # Probeer eerst uit session state te halen
        try:
            import streamlit as st
            if 'dbase' in st.session_state and st.session_state['dbase'] is not None:
                self._dbase = st.session_state['dbase']
        except:
            pass
        return self._dbase

    @dbase.setter
    def dbase(self, value):
        """Set dbase and save to session state"""
        self._dbase = value
        try:
            import streamlit as st
            st.session_state['dbase'] = value
        except:
            pass

    def create_dbase(self):
        """Maak een nieuwe Dbase instance"""
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")
        self._dbase = Dbase()
        try:
            import streamlit as st
            st.session_state['dbase'] = self._dbase
        except:
            pass
        return self._dbase

    def import_excel(self, file_path, source='Dbase'):
        """
        Importeer Excel data met PV-tool

        Args:
            file_path: Path object of string naar het Excel bestand
            source: Type bron ('Dbase', 'PV-tool', 'Stowa')

        Returns:
            DataFrame met geïmporteerde data
        """
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")

        if self._dbase is None:
            self._dbase = Dbase()

        file_path = Path(file_path)
        df = self._dbase.import_data(source=source, source_dir=file_path)

        # Bewaar in session state
        try:
            import streamlit as st
            st.session_state['dbase'] = self._dbase
            st.session_state['data'] = df
        except:
            pass

        return df

    def validate_data(self, export_path=None):
        """
        Valideer data met PV-tool validatie regels

        Args:
            export_path: Optioneel pad voor export van validatie resultaten

        Returns:
            Tuple (DataFrame, critical_errors, warnings)
        """
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")

        if self.dbase is None:
            raise ValueError("Geen data geladen. Gebruik eerst import_excel()")

        if export_path:
            export_path = Path(export_path)
            # Run full validation with export
            self.dbase.validate_data(export_path=export_path)
            critical_errors = self.dbase.validation.critical_error_log
            warnings = self.dbase.validation.warning_error_log
        else:
            # Run validation zonder export - maak tijdelijke export
            import tempfile
            with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp:
                tmp_path = Path(tmp.name)

            try:
                self.dbase.validate_data(export_path=tmp_path)
                critical_errors = self.dbase.validation.critical_error_log
                warnings = self.dbase.validation.warning_error_log
            finally:
                # Verwijder tijdelijk bestand
                if tmp_path.exists():
                    tmp_path.unlink()

        return self.dbase.dbase_df, critical_errors, warnings

    def export_dbase_to_template(self, export_dir, export_name="Template_PVtool5_0.xlsx"):
        """
        Exporteer data naar PV-tool Excel template

        Args:
            export_dir: Directory waar het bestand opgeslagen moet worden
            export_name: Naam van het geëxporteerde bestand

        Returns:
            Path naar het geëxporteerde bestand
        """
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")

        if self.dbase is None:
            raise ValueError("Geen data geladen. Gebruik eerst import_excel()")

        export_path = Path(export_dir) / export_name
        self.dbase.export_dbase_to_template(export_dir=export_dir, export_name=export_name)
        return export_path


    def get_investigation_groups(self):
        """
        Haal alle onderzoeksgroepen op uit de data

        Returns:
            List met unieke onderzoeksgroep namen
        """
        # Gebruik de property om dbase uit session state te halen indien nodig
        if self.dbase is None or self.dbase.dbase_df is None:
            return []

        # Zoek naar de kolom met groep informatie
        df = self.dbase.dbase_df
        group_columns = ['PV_NAAM', 'pv_naam', 'PV-naam', 'onderzoeksgroep', 'groep']

        for col in group_columns:
            if col in df.columns:
                # Haal unieke waarden op, filter NaN en lege strings, converteer naar string
                groups = df[col].dropna().unique()
                # Converteer alles naar string en filter lege waarden
                groups = [str(g).strip() for g in groups if str(g).strip() and str(g) != 'nan']
                # Sorteer en return
                return sorted(groups)

        return []

    def export_dbase_to_template(self, export_dir, export_name="Template_PVtool5_0.xlsx"):
        """
        Exporteer dbase naar PV-tool Excel template

        Args:
            export_dir: Directory waar het bestand opgeslagen wordt
            export_name: Naam van het export bestand

        Returns:
            Path naar het geëxporteerde bestand
        """
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")

        if self.dbase is None:
            raise ValueError("Geen data geladen. Gebruik eerst import_excel()")

        export_path = Path(export_dir) / export_name
        self.dbase.export_dbase_to_template(export_dir=export_dir, export_name=export_name)
        return export_path

        return []

    def create_cphi_analysis(self, analysis_type='TXT_CPhi',
                            investigation_groups=None,
                            effective_stress='eindsterkte'):
        """
        Maak een C-Phi analyse instance

        Args:
            analysis_type: 'TXT_CPhi', 'TXT_SH', 'DSS_CPhi', 'DSS_SH'
            investigation_groups: List met groepen om te analyseren
            effective_stress: '2% rek', '5% rek', '15% rek', 'pieksterkte', 'eindsterkte'

        Returns:
            CPhiAnalyse instance
        """
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")

        if self.dbase is None:
            raise ValueError("Geen data geladen. Gebruik eerst import_excel()")

        if investigation_groups is None:
            investigation_groups = self.get_investigation_groups()

        return CPhiAnalyse(
            dbase=self.dbase,
            analysis_type=analysis_type,
            investigation_groups=investigation_groups,
            effective_stress=effective_stress
        )

    def create_shansep_analysis(self, investigation_groups=None):
        """
        Maak een SHANSEP analyse instance

        Args:
            investigation_groups: List met groepen om te analyseren

        Returns:
            SHANSEP instance
        """
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")

        if self.dbase is None:
            raise ValueError("Geen data geladen. Gebruik eerst import_excel()")

        if investigation_groups is None:
            investigation_groups = self.get_investigation_groups()

        return SHANSEP(
            dbase=self.dbase,
            investigation_groups=investigation_groups
        )

    def create_sutabel_analysis(self, investigation_groups=None):
        """
        Maak een SU-tabel analyse instance

        Args:
            investigation_groups: List met groepen om te analyseren

        Returns:
            SUTABEL instance
        """
        if not self.available:
            raise ImportError("PV-tool modules niet beschikbaar")

        if self.dbase is None:
            raise ValueError("Geen data geladen. Gebruik eerst import_excel()")

        if investigation_groups is None:
            investigation_groups = self.get_investigation_groups()

        return SUTABEL(
            dbase=self.dbase,
            investigation_groups=investigation_groups
        )


# Singleton instance
pv_tool = PVToolWrapper()

