# src/ - Source Code Directory

## Inhoud

### `pv_tool_wrapper.py`
Integratie wrapper voor de PV-tool. Biedt een eenvoudige interface naar de PV-tool functionaliteit.

## PV-tool Wrapper

De wrapper module maakt het eenvoudig om PV-tool functionaliteit te gebruiken in de Streamlit app.

### Import
```python
from src.pv_tool_wrapper import pv_tool
```

### Gebruik

#### Check Beschikbaarheid
```python
if pv_tool.available:
    print("PV-tool is beschikbaar!")
```

#### Import Data
```python
# Importeer Excel file
df = pv_tool.import_excel(
    file_path="data.xlsx",
    source='Dbase'  # of 'PV-tool' of 'Stowa'
)
```

#### Valideer Data
```python
# Valideer zonder export
validated_df = pv_tool.validate_data()

# Valideer met export
validated_df = pv_tool.validate_data(export_path="validation_report.xlsx")
```

#### Onderzoeksgroepen
```python
# Haal alle groepen op
groups = pv_tool.get_investigation_groups()
print(f"Gevonden groepen: {groups}")
```

#### C-Phi Analyse
```python
cphi_analysis = pv_tool.create_cphi_analysis(
    analysis_type='TXT_CPhi',  # of TXT_SH, DSS_CPhi, DSS_SH
    investigation_groups=['Groep1', 'Groep2'],
    effective_stress='eindsterkte'  # of '2% rek', '5% rek', etc.
)
```

#### SHANSEP Analyse
```python
shansep_analysis = pv_tool.create_shansep_analysis(
    investigation_groups=['Groep1', 'Groep2']
)
```

#### SU-Tabel Analyse
```python
su_analysis = pv_tool.create_sutabel_analysis(
    investigation_groups=['Groep1', 'Groep2']
)
```

## Technische Details

### Singleton Pattern
De wrapper gebruikt een singleton pattern (`pv_tool`), wat betekent dat er maar één instantie is die gedeeld wordt door alle modules.

### Session State
De `dbase` instance wordt opgeslagen in de wrapper en is toegankelijk via `pv_tool.dbase`.

In Streamlit wordt deze ook opgeslagen in session state:
```python
st.session_state['dbase'] = pv_tool.dbase
```

### Error Handling
De wrapper gooit `ImportError` als PV-tool niet beschikbaar is, en `ValueError` als er geen data geladen is.

```python
try:
    cphi = pv_tool.create_cphi_analysis(...)
except ImportError:
    print("PV-tool niet beschikbaar")
except ValueError:
    print("Geen data geladen")
```

## Module Structuur

```
src/
└── pv_tool_wrapper.py
    ├── PVToolWrapper (class)
    │   ├── __init__()
    │   ├── create_dbase()
    │   ├── import_excel()
    │   ├── validate_data()
    │   ├── get_investigation_groups()
    │   ├── create_cphi_analysis()
    │   ├── create_shansep_analysis()
    │   └── create_sutabel_analysis()
    └── pv_tool (singleton instance)
```

## Dependencies

De wrapper vereist dat de PV-tool repository gekloond is in `pv-tool-submodule/`:

```
pv-tool-app/
├── src/
│   └── pv_tool_wrapper.py
└── pv-tool-submodule/
    └── pv_tool/
        ├── imports/
        ├── cphi_analysis/
        ├── shansep_analysis/
        └── sutabel_analysis/
```

## Troubleshooting

### PV-tool niet gevonden
Als `pv_tool.available == False`:

1. Check of `pv-tool-submodule/` bestaat
2. Check of `pv-tool-submodule/pv_tool/` bestaat
3. Herinstalleer PV-tool:
   ```bash
   git clone https://github.com/PVorganization/PV-tool.git pv-tool-submodule
   ```

### Import errors
Als je `ImportError` krijgt bij het maken van analyses:

1. Check of alle dependencies geïnstalleerd zijn:
   ```bash
   pip install -r requirements.txt
   ```

2. Test de import:
   ```python
   from src.pv_tool_wrapper import pv_tool
   print(f"Available: {pv_tool.available}")
   ```

## Referenties

- [PV-tool Repository](https://github.com/PVorganization/PV-tool)
- [PV-tool Integration Docs](../docs/PV_TOOL_INTEGRATION.md)
- [Main README](../README.md)

