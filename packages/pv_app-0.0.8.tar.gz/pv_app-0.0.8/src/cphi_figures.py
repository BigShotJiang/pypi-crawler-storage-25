"""
C-Phi Analyse Figuur Generatie
Bevat functies voor het maken van Mohr-Coulomb plots voor C-Phi analyses
"""

import plotly.graph_objects as go
import plotly.io as pio
import numpy as np
import streamlit as st


def configure_plotly_for_streamlit():
    """Configureer plotly om inline te blijven in Streamlit (geen nieuwe vensters)"""
    pio.renderers.default = "browser"
    try:
        import plotly.offline as pyo
        pyo.init_notebook_mode(connected=True)
    except:
        pass


def create_mohr_coulomb_plot(coh_gem, phi_gem, coh_kar, phi_kar, analysis_type="C-Phi", effective_stress="eindsterkte", selected_groups=None):
    """
    Maak een Mohr-Coulomb failure envelope plot

    Args:
        coh_gem (float): Cohesie gemiddeld (kPa)
        phi_gem (float): Frictiehoek gemiddeld (graden)
        coh_kar (float): Cohesie karakteristiek (kPa)
        phi_kar (float): Frictiehoek karakteristiek (graden)
        analysis_type (str): Type analyse voor titel
        effective_stress (str): Effectieve sterkte voor titel
        selected_groups (list): Geselecteerde groepen voor titel

    Returns:
        plotly.graph_objects.Figure: Plotly figuur object
    """
    configure_plotly_for_streamlit()

    # Bereken tau waarden voor verschillende sigma waarden
    sigma = np.linspace(0, 100, 100)
    tau_gem = coh_gem + sigma * np.tan(np.radians(phi_gem))
    tau_kar = coh_kar + sigma * np.tan(np.radians(phi_kar))

    # Maak plotly figuur
    fig = go.Figure()

    # Voeg gemiddelde lijn toe
    fig.add_trace(go.Scatter(
        x=sigma,
        y=tau_gem,
        mode='lines',
        name=f'Gemiddeld: c={coh_gem:.1f} kPa, φ={phi_gem:.1f}°',
        line=dict(color='blue', width=3),
        hovertemplate='<b>Gemiddeld</b><br>σ: %{x:.1f} kPa<br>τ: %{y:.1f} kPa<extra></extra>'
    ))

    # Voeg karakteristieke lijn toe
    fig.add_trace(go.Scatter(
        x=sigma,
        y=tau_kar,
        mode='lines',
        name=f'Karakteristiek: c={coh_kar:.1f} kPa, φ={phi_kar:.1f}°',
        line=dict(color='red', width=3, dash='dash'),
        hovertemplate='<b>Karakteristiek</b><br>σ: %{x:.1f} kPa<br>τ: %{y:.1f} kPa<extra></extra>'
    ))

    # Maak titel
    groups_text = f" ({', '.join(selected_groups)})" if selected_groups else ""
    title = f'{analysis_type} analyse met {effective_stress}{groups_text}'

    # Layout configuratie
    fig.update_layout(
        title=title,
        xaxis_title='Normale spanning σ (kPa)',
        yaxis_title='Schuifspanning τ (kPa)',
        width=800,
        height=500,
        showlegend=True,
        template='plotly_white',
        hovermode='closest'
    )

    # Grid en assen styling
    fig.update_xaxes(
        showgrid=True,
        gridwidth=1,
        gridcolor='lightgray',
        range=[0, 100]
    )
    fig.update_yaxes(
        showgrid=True,
        gridwidth=1,
        gridcolor='lightgray',
        range=[0, max(tau_gem[-1], tau_kar[-1]) * 1.1]
    )

    return fig


def create_parameter_comparison_plot(coh_gem, phi_gem, coh_kar, phi_kar, analysis_type="C-Phi", effective_stress="eindsterkte", selected_groups=None):
    """
    Maak twee identieke Mohr-Coulomb subplots naast elkaar

    Args:
        coh_gem (float): Cohesie gemiddeld (kPa)
        phi_gem (float): Frictiehoek gemiddeld (graden)
        coh_kar (float): Cohesie karakteristiek (kPa)
        phi_kar (float): Frictiehoek karakteristiek (graden)
        analysis_type (str): Type analyse voor titel
        effective_stress (str): Effectieve sterkte voor titel
        selected_groups (list): Geselecteerde groepen voor titel

    Returns:
        plotly.graph_objects.Figure: Plotly figuur object met twee subplots
    """
    configure_plotly_for_streamlit()

    # Maak subplot figuur met twee plots naast elkaar
    from plotly.subplots import make_subplots

    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=('Mohr-Coulomb Plot A', 'Mohr-Coulomb Plot B'),
        specs=[[{"secondary_y": False}, {"secondary_y": False}]]
    )

    # Bereken tau waarden voor verschillende sigma waarden
    sigma = np.linspace(0, 100, 100)
    tau_gem = coh_gem + sigma * np.tan(np.radians(phi_gem))
    tau_kar = coh_kar + sigma * np.tan(np.radians(phi_kar))

    # Linker subplot (Plot A) - Beide lijnen
    fig.add_trace(
        go.Scatter(
            x=sigma,
            y=tau_gem,
            mode='lines',
            name='Gemiddeld A',
            line=dict(color='blue', width=3),
            hovertemplate='<b>Gemiddeld</b><br>σ: %{x:.1f} kPa<br>τ: %{y:.1f} kPa<extra></extra>',
            showlegend=True
        ),
        row=1, col=1
    )

    fig.add_trace(
        go.Scatter(
            x=sigma,
            y=tau_kar,
            mode='lines',
            name='Karakteristiek A',
            line=dict(color='red', width=3, dash='dash'),
            hovertemplate='<b>Karakteristiek</b><br>σ: %{x:.1f} kPa<br>τ: %{y:.1f} kPa<extra></extra>',
            showlegend=True
        ),
        row=1, col=1
    )

    # Rechter subplot (Plot B) - Identieke lijnen
    fig.add_trace(
        go.Scatter(
            x=sigma,
            y=tau_gem,
            mode='lines',
            name='Gemiddeld B',
            line=dict(color='blue', width=3),
            hovertemplate='<b>Gemiddeld</b><br>σ: %{x:.1f} kPa<br>τ: %{y:.1f} kPa<extra></extra>',
            showlegend=False  # Vermijd duplicate legend entries
        ),
        row=1, col=2
    )

    fig.add_trace(
        go.Scatter(
            x=sigma,
            y=tau_kar,
            mode='lines',
            name='Karakteristiek B',
            line=dict(color='red', width=3, dash='dash'),
            hovertemplate='<b>Karakteristiek</b><br>σ: %{x:.1f} kPa<br>τ: %{y:.1f} kPa<extra></extra>',
            showlegend=False  # Vermijd duplicate legend entries
        ),
        row=1, col=2
    )

    # Update layout
    groups_text = f" ({', '.join(selected_groups)})" if selected_groups else ""
    title = f'Dubbele Mohr-Coulomb Plot - {analysis_type}{groups_text}'

    fig.update_layout(
        title=title,
        showlegend=True,
        height=500,
        template='plotly_white',
        hovermode='closest'
    )

    # Update x-axes voor beide subplots
    fig.update_xaxes(
        title_text="Normale spanning σ (kPa)",
        showgrid=True,
        gridwidth=1,
        gridcolor='lightgray',
        range=[0, 100],
        row=1, col=1
    )

    fig.update_xaxes(
        title_text="Normale spanning σ (kPa)",
        showgrid=True,
        gridwidth=1,
        gridcolor='lightgray',
        range=[0, 100],
        row=1, col=2
    )

    # Update y-axes voor beide subplots
    y_max = max(tau_gem[-1], tau_kar[-1]) * 1.1

    fig.update_yaxes(
        title_text="Schuifspanning τ (kPa)",
        showgrid=True,
        gridwidth=1,
        gridcolor='lightgray',
        range=[0, y_max],
        row=1, col=1
    )

    fig.update_yaxes(
        title_text="Schuifspanning τ (kPa)",
        showgrid=True,
        gridwidth=1,
        gridcolor='lightgray',
        range=[0, y_max],
        row=1, col=2
    )

    return fig


def display_parameter_comparison(coh_gem, phi_gem, coh_kar, phi_kar, analysis_type="C-Phi", effective_stress="eindsterkte", selected_groups=None):
    """
    Toon dubbele Mohr-Coulomb subplots in Streamlit

    Args:
        coh_gem (float): Cohesie gemiddeld (kPa)
        phi_gem (float): Frictiehoek gemiddeld (graden)
        coh_kar (float): Cohesie karakteristiek (kPa)
        phi_kar (float): Frictiehoek karakteristiek (graden)
        analysis_type (str): Type analyse voor titel
        effective_stress (str): Effectieve sterkte voor titel
        selected_groups (list): Geselecteerde groepen voor titel

    Returns:
        bool: True als succesvol, False als gefaald
    """
    try:
        fig = create_parameter_comparison_plot(
            coh_gem, phi_gem, coh_kar, phi_kar,
            analysis_type, effective_stress, selected_groups
        )

        st.plotly_chart(fig, use_container_width=True, config={
            'displayModeBar': True,
            'showTips': True,
            'displaylogo': False,
            'toImageButtonOptions': {
                'format': 'png',
                'filename': 'figuur_2_dubbele_mohr_coulomb',
                'height': 500,
                'width': 1000,
                'scale': 1
            }
        })

        return True

    except Exception as e:
        st.error(f"❌ Dubbele Mohr-Coulomb subplot kon niet worden gegenereerd: {str(e)}")
        return False


def display_plot1(coh_gem, phi_gem, coh_kar, phi_kar, analysis_type="C-Phi", effective_stress="eindsterkte", selected_groups=None):
    """
    Maak en toon een Mohr-Coulomb plot in Streamlit

    Args:
        coh_gem (float): Cohesie gemiddeld (kPa)
        phi_gem (float): Frictiehoek gemiddeld (graden)
        coh_kar (float): Cohesie karakteristiek (kPa)
        phi_kar (float): Frictiehoek karakteristiek (graden)
        analysis_type (str): Type analyse voor titel
        effective_stress (str): Effectieve sterkte voor titel
        selected_groups (list): Geselecteerde groepen voor titel

    Returns:
        bool: True als succesvol, False als gefaald
    """
    try:
        # Maak plotly figuur
        fig = create_mohr_coulomb_plot(
            coh_gem, phi_gem, coh_kar, phi_kar,
            analysis_type, effective_stress, selected_groups
        )

        # Toon figuur inline in Streamlit (voorkomt nieuwe vensters)
        st.plotly_chart(fig, use_container_width=True, config={
            'displayModeBar': True,
            'showTips': True,
            'displaylogo': False,
            'modeBarButtonsToRemove': ['pan2d', 'lasso2d', 'select2d', 'autoScale2d'],
            'toImageButtonOptions': {
                'format': 'png',
                'filename': 'figuur_1_mohr_coulomb',
                'height': 500,
                'width': 800,
                'scale': 1
            }
        })

        return True

    except Exception as e:
        st.error(f"❌ Plotly figuur kon niet worden gegenereerd: {str(e)}")
        return False



def display_matplotlib_fallback(coh_gem, phi_gem, coh_kar, phi_kar):
    """
    Matplotlib fallback als plotly niet werkt

    Args:
        coh_gem (float): Cohesie gemiddeld (kPa)
        phi_gem (float): Frictiehoek gemiddeld (graden)
        coh_kar (float): Cohesie karakteristiek (kPa)
        phi_kar (float): Frictiehoek karakteristiek (graden)

    Returns:
        bool: True als succesvol, False als gefaald
    """
    try:
        import matplotlib.pyplot as plt

        # Zet matplotlib backend voor Streamlit
        plt.switch_backend('Agg')

        # Maak figuur
        fig, ax = plt.subplots(figsize=(10, 6))

        # Bereken tau waarden
        sigma = np.linspace(0, 100, 100)
        tau_gem = coh_gem + sigma * np.tan(np.radians(phi_gem))
        tau_kar = coh_kar + sigma * np.tan(np.radians(phi_kar))

        # Plot lijnen
        ax.plot(sigma, tau_gem, 'b-',
                label=f'Gemiddeld: c={coh_gem:.1f} kPa, φ={phi_gem:.1f}°',
                linewidth=2)
        ax.plot(sigma, tau_kar, 'r--',
                label=f'Karakteristiek: c={coh_kar:.1f} kPa, φ={phi_kar:.1f}°',
                linewidth=2)

        # Styling
        ax.set_xlabel('Normale spanning σ (kPa)')
        ax.set_ylabel('Schuifspanning τ (kPa)')
        ax.set_title('Mohr-Coulomb Failure Envelope')
        ax.grid(True, alpha=0.3)
        ax.legend()
        ax.set_xlim(0, 100)
        ax.set_ylim(0, max(tau_gem[-1], tau_kar[-1]) * 1.1)

        # Toon in Streamlit
        st.pyplot(fig, clear_figure=True)
        plt.close(fig)

        st.info("📊 Matplotlib fallback figuur getoond")
        return True

    except Exception as e:
        st.error(f"❌ Ook matplotlib fallback mislukt: {str(e)}")
        return False


def create_cphi_figures(coh_gem, phi_gem, coh_kar, phi_kar, analysis_type="C-Phi", effective_stress="eindsterkte", selected_groups=None):
    """
    Hoofdfunctie voor het maken van C-Phi figuren
    Toont twee figuren: Mohr-Coulomb plot en parameter vergelijking

    Args:
        coh_gem (float): Cohesie gemiddeld (kPa)
        phi_gem (float): Frictiehoek gemiddeld (graden)
        coh_kar (float): Cohesie karakteristiek (kPa)
        phi_kar (float): Frictiehoek karakteristiek (graden)
        analysis_type (str): Type analyse voor titel
        effective_stress (str): Effectieve sterkte voor titel
        selected_groups (list): Geselecteerde groepen voor titel

    Returns:
        bool: True als alle figuren succesvol zijn getoond
    """
    st.subheader("📊 Figuren")

    success_count = 0

    # Figuur 1
    st.markdown("### Figuur 1")
    if display_plot1(coh_gem, phi_gem, coh_kar, phi_kar, analysis_type, effective_stress, selected_groups):
        success_count += 1

    # Ruimte tussen figuren
    st.markdown("<br>", unsafe_allow_html=True)

    # Figuur 2
    st.markdown("### Figuur 2")
    if display_parameter_comparison(coh_gem, phi_gem, coh_kar, phi_kar, analysis_type, effective_stress, selected_groups):
        success_count += 1

    # Resultaat feedback
    if success_count == 2:
        st.success("✅ Beide figuren succesvol gegenereerd!")
        return True
    elif success_count == 1:
        st.warning("⚠️ Slechts één figuur kon worden gegenereerd")
        return True
    else:
        # Als beide plotly figuren falen, probeer matplotlib fallback voor de eerste
        st.warning("⚠️ Plotly figuren mislukt, probeer matplotlib fallback...")
        st.markdown("### Figuur 1: Mohr-Coulomb (Matplotlib Fallback)")
        if display_matplotlib_fallback(coh_gem, phi_gem, coh_kar, phi_kar):
            return True

        # Als alles faalt
        st.error("❌ Alle figuur methoden gefaald")
        st.info("🔧 Figuur functionaliteit wordt verder ontwikkeld...")
        return False
