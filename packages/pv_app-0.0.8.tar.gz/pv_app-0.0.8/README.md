# PV tool

## Summary
- [Quick Start Guide](QUICK_START.md) ⚡
- [About The Project](#about-the-project)
- [Requirements](#requirements)
- [Installation](#installation)
- [Usage](#usage)
- [Project Structure](#project-structure)
- [Additional Documentation](#additional-documentation)
- [Troubleshooting](#troubleshooting)
- [Contact](#contact)

## About The Project

This project is a Streamlit frontend for the [PV-tool](https://github.com/PVorganization/PV-tool) - a comprehensive Python toolset for geotechnical analysis of soil samples.

### PV-tool Integration

The app integrates directly with the PV-tool repository to provide:
- **Import & Validation**: Load and validate geotechnical data from PV-tool Excel templates
- **C-Phi Analysis**: Determine cohesion and friction angle parameters (Mohr-Coulomb)
- **SHANSEP Analysis**: Stress History And Normalized Soil Engineering Properties
- **SU Analysis**: Undrained shear strength tables and profiles

The PV-tool repository is cloned into `pv-tool-submodule/` during installation. See [PV-tool Integration Documentation](docs/PV_TOOL_INTEGRATION.md) for detailed technical information.

### Features

✅ Multi-page Streamlit interface  
✅ Full PV-tool integration via wrapper module  
✅ Session state management for data sharing  
✅ Interactive visualizations with Plotly  
✅ Export capabilities (Excel, PDF, CSV)  
✅ Support for multiple analysis types and investigation groups  

This repository hosts a development version at [http://localhost:8501](http://localhost:8501/) when running.

## Requirements

- [Python 3.11](https://www.python.org/downloads/release/python-31114/)
- [Streamlit](https://docs.streamlit.io/get-started/installation) >= 1.39.0
- pandas >= 2.0.0
- numpy >= 1.24.0
- plotly >= 5.18.0
- IDE for development - [Visual Studio Code](https://code.visualstudio.com/) or [PyCharm](https://www.jetbrains.com/pycharm/)

## Installation

### 1. Clone this repository

```shell
git clone https://github.com/your-username/pv-tool-app.git
cd pv-tool-app
```

### 2. Clone the PV-tool repository

The PV-tool is integrated as a separate repository in the `pv-tool-submodule/` directory:

```shell
git clone https://github.com/PVorganization/PV-tool.git pv-tool-submodule
```

**Alternative: Use as git submodule** (optional, for advanced users):
```shell
git submodule add https://github.com/PVorganization/PV-tool.git pv-tool-submodule
git submodule update --init --recursive
```

### 3. Install dependencies

```shell
pip install -r requirements.txt
```

This will install:
- Streamlit and all UI dependencies
- PV-tool dependencies (scipy, matplotlib, openpyxl, etc.)
- Data processing libraries (pandas, numpy)
- Visualization tools (plotly, kaleido)

### 4. Verify installation

Check if the PV-tool wrapper loads correctly:

```python
python -c "from src.pv_tool_wrapper import pv_tool; print(f'PV-tool available: {pv_tool.available}')"
```

If you see `PV-tool available: True`, you're ready to go! 🎉

### Run the app

```shell
streamlit run app.py
```

Or use the convenience scripts:
- **Windows PowerShell**: `.\run.ps1`
- **Windows Command Prompt**: `run.bat`

The app will open in your default browser at `http://localhost:8501`

> **Note:** The Streamlit server must be running to access the app. If you navigate to http://localhost:8501 and see "This site can't be reached", you need to start the server first using one of the commands above.

## Usage

### Quick Start

1. **Start the server** (first time or after reboot):
   ```shell
   streamlit run app.py
   ```
   Or double-click `run.bat` or `run.ps1`

2. **Access the app** in your browser at http://localhost:8501

3. **Stop the server** when done: Press `Ctrl+C` in the terminal

> **Important:** The server needs to be running for the app to be accessible. Think of it like starting a web server - you can't visit a website if the server isn't running!

### Available Pages

Once the app runs, you can access the following pages:

1. **Home** - Landing page with overview of available analyses
2. **📥 Import en Validate** - Import and validate geotechnical data from various formats (CSV, Excel, GEF, XML)
3. **📊 C-Phi analyse** - Analyze cohesion and friction angle parameters using Mohr-Coulomb failure envelope
4. **🔬 SHANSEP analyse** - Stress History And Normalized Soil Engineering Properties analysis
5. **📈 SU-analyse** - Undrained shear strength analysis and interpretation

### Navigation

- Use the sidebar to navigate between different analysis pages
- Each page includes demo data functionality for testing
- Data flows between pages using Streamlit's session state
- Start with "Import en Validate" to load your data, then proceed to specific analyses

## Project Structure

```
pv-tool-app/
├── app.py                          # Main landing page
├── pages/                          # Streamlit multipage structure
│   ├── 1_📥_Import_en_Validate.py  # Data import and validation
│   ├── 2_📊_C-Phi_Analyse.py       # C-Phi analysis
│   ├── 3_🔬_SHANSEP_Analyse.py     # SHANSEP analysis
│   └── 4_📈_SU-Analyse.py          # SU analysis
├── requirements.txt                # Python dependencies
├── docs/                           # Documentation
├── src/                            # Source code (future)
├── static/                         # Static assets
└── test/                           # Tests

```

## Additional Documentation

See the `docs/` folder for additional documentation:
- [PV-tool Integration](docs/PV_TOOL_INTEGRATION.md) - Technical details about PV-tool integration
- [Getting Started](docs/GETTING_STARTED.md) - Detailed getting started guide
- [Why Run Server](docs/WHY_RUN_SERVER.md) - Explanation of Streamlit server requirement
- [Quick Start](QUICK_START.md) - Quick reference card

### PV-tool Resources

- [PV-tool GitHub Repository](https://github.com/PVorganization/PV-tool)
- [PV-tool Documentation](https://github.com/PVorganization/PV-tool/blob/main/README.md)
- [STOWA Proevenverzameling](https://publicwiki.deltares.nl/spaces/HWBPMacro/pages/217120830)
- Analysis methodologies
- Data format specifications

## Troubleshooting

### Submodule Issues

If the PV-tool submodule is not properly loaded:

```shell
git submodule update --init --recursive
```

### Missing Dependencies

If you encounter import errors:

```shell
pip install -r requirements.txt --upgrade
```

### Import Errors

Make sure you're running Python 3.11 and all dependencies are installed:

```shell
python --version
pip list
```

## Contact

Product owner: [Tjalda Deenekamp](http://github.com/TjaldaDeenekamp)
