import streamlit as st

st.set_page_config(page_title="PV Tool App", page_icon="☀️", layout="wide")

st.title("PV Tool App")
st.markdown("### Welkom bij de PV-tool")

st.write("""
Deze applicatie integreert met de [PV-tool](https://github.com/PVorganization/PV-tool) 
en biedt een gebruiksvriendelijke interface voor geotechnische analyses:
""")

col1, col2 = st.columns(2)

with col1:
    st.info("📥 **Import en Validate**\n\nImporteer en valideer je invoerdata")
    st.info("📊 **C-Phi analyse**\n\nBepalen gedraineerde parameters (C en Phi)")

with col2:
    st.info("🔬 **SHANSEP analyse**\n\nBepalen ongedraineerde parameters (S, m en POP)")
    st.info("📈 **SU-analyse**\n\nBepalen ongedraineerde parameters (SU-tabel)")

st.markdown("---")

# Quick start instructies
with st.expander("🚀 Quick Start - Hoe te gebruiken"):
    st.markdown("""
    ### Stappen:
    
    1. **📥 Import en Validate**
       - Upload een PV-tool Excel bestand
       - Selecteer het bron type (Uitwisselformat, Excelversie proevenverzamelingtool (versie 4.2n of hoger), of Stowa)
       - Valideer de data
    
    2. **Kies een analyse**
       - 📊 **C-Phi**: Voor gedraineerde parameters (C en Phi)
       - 🔬 **SHANSEP**: Voor ongedraineerde parameters (S, m en POP)
       - 📈 **SU-tabel**: Voor ongedraineerde parameters (SU)
    
    3. **Selecteer onderzoeksgroepen**
       - Kies één of meer groepen uit je dataset
       - Configureer analyse parameters
    
    4. **Run analyse en bekijk resultaten**
       - Pas parameters of instellingen aan en herhaal indien nodig
       - Bekijk grafieken en tabellen
       - Export resultaten naar Excel of PDF
       
    Zie [PV-tool Integratie Documentatie](docs/PV_TOOL_INTEGRATION.md) voor details.
    """)

# Info over PV-tool
with st.expander("ℹ️ Over de PV-tool"):
    st.markdown("""
    ### STOWA Proevenverzameling tool v5.0
    
    De **PV-tool** (Proevenverzameling tool) is ontwikkeld voor het opstellen van lokale of 
    regionale proevenverzamelingen voor het bepalen van geotechnische parameters.
    
    #### Functionaliteit:
    - Importeren en valideren van geotechnische data
    - Bepalen van gedraineerde sterkte parameters (c, φ)
    - Bepalen van ongedraineerde sterkte parameters (S, m, POP)
    
    #### Methodologie:
    Alle functionaliteiten zijn opgesteld conform *Statistische methoden t.b.v. proevenverzamelingen, DIV, v1.0*
    
    #### Data Uitwisseling:
    De onderliggende data om een proevenverzameling samen te stellen is beschreven in een 
    vaste structuur. Deze structuur is vastgelegd in een uitwisselformat. 
    Het uitwisselformat-database-proevnverzemling_versie_4_2x.xlsx. De geotechnische laboratoria kennen deze database 
    en kunnen deze database vullen met resultaten van grond- en laboratoriumonderzoek. Op deze wijze ontstaat 
    er uniformering op het gebied van data-uitwiddeling en -opslag van proefresultaten.
    
    **Meer informatie:** [PV-tool GitHub Repository](https://github.com/PVorganization/PV-tool)
    """)

st.markdown("---")
st.caption("👈 Selecteer een pagina via de sidebar om te beginnen")


