import streamlit as st
import pandas as pd
import sys
import tempfile
from pathlib import Path

# Voeg parent directory toe aan path voor src import
parent_path = Path(__file__).parent.parent
if str(parent_path) not in sys.path:
    sys.path.insert(0, str(parent_path))

# Probeer PV-tool te importeren
try:
    from src.pv_tool_wrapper import pv_tool
    PV_TOOL_IMPORTED = True
    import_error = None
except Exception as e:
    PV_TOOL_IMPORTED = False
    import_error = str(e)

st.set_page_config(page_title="Import en Validate", page_icon="📥", layout="wide")

st.title("📥 Import en Validate")
st.markdown("Importeer en valideer je brondata met de PV-tool")

# Main content
st.subheader("1. Data Importeren")

st.markdown("""
Upload het PV-tool Excel template bestand met je geotechnische data.  
""")

uploaded_file = st.file_uploader(
    "Upload PV-tool Excel bestand",
    type=["xlsx", "xls"],
    help="Selecteer een PV-tool template bestand"
)

# Bron type selectie
if uploaded_file is not None:
    source_display = st.selectbox(
        "Bron type",
        ["Proevenverzamelingtool 5.0", "Proevenverzamelingtool 4.2n of hoger", "STOWA uitwisselingsformat 4.2x"],
        help="Selecteer het type bron database"
    )

    # Map display names naar PV-tool waarden
    source_mapping = {
        "Proevenverzamelingtool 5.0": "Dbase",
        "Proevenverzamelingtool 4.2n of hoger": "PV-tool",
        "STOWA uitwisselingsformat 4.2x": "Stowa"
    }
    source_type = source_mapping[source_display]

    st.info("""
    **Proevenverzamelingtool 5.0**: Nieuwe PV-tool 5.0 template  
    **Proevenverzamelingtool 4.2n of hoger**: Oude PV-tool Excel  
    **STOWA uitwisselingsformat 4.2x**: STOWA database
    """)

    # Import knop
    if st.button("📥 Importeer Data", type="primary", use_container_width=True):
        try:
            # Bewaar uploaded file tijdelijk
            with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_path = tmp_file.name

            with st.spinner("Data wordt ingeladen..."):
                # Importeer data met PV-tool
                df = pv_tool.import_excel(tmp_path, source=source_type)

                # Bewaar in session state
                st.session_state['dbase'] = pv_tool.dbase
                st.session_state['data'] = df
                st.session_state['file_name'] = uploaded_file.name

            st.success(f"✅ Bestand succesvol ingeladen: {uploaded_file.name}")
            st.write(f"Aantal rijen: {len(df)}, Aantal kolommen: {len(df.columns)}")

            # Verwijder tijdelijk bestand
            Path(tmp_path).unlink()

            st.rerun()

        except Exception as e:
            st.error(f"❌ Fout bij importeren: {str(e)}")
            with st.expander("🔍 Fout details"):
                st.code(str(e))
                import traceback
                st.code(traceback.format_exc())

# Toon data als deze geladen is
if (uploaded_file is not None and 'data' in st.session_state) or \
   ('data' in st.session_state and st.session_state['data'] is not None):

    df = st.session_state['data']

    # Data tabel direct tonen
    st.dataframe(df, use_container_width=True, height=400)

    # Validatie sectie
    st.subheader("2. Data Validatie")

    if st.button("🔍 Valideer Data", type="primary", use_container_width=True):
        with st.spinner("Data wordt gevalideerd..."):
            try:
                # Valideer zonder export
                validated_df, critical_errors, warnings = pv_tool.validate_data()

                st.session_state['validated'] = True
                st.session_state['validation_complete'] = True
                st.session_state['critical_errors'] = critical_errors
                st.session_state['warnings'] = warnings

                # Toon resultaat
                if critical_errors and len(critical_errors) > 0:
                    st.warning(f"⚠️ Validatie compleet met {len(critical_errors)} kritieke fout(en)")
                else:
                    st.success("✅ Validatie compleet - Geen kritieke fouten!")

            except Exception as e:
                st.error(f"❌ Validatie fout: {str(e)}")
                with st.expander("🔍 Details"):
                    st.code(str(e))

    # Toon validatie resultaten
    if st.session_state.get('validation_complete', False):
        st.info("✅ Data is gevalideerd en klaar voor analyse")

        # Toon critical errors
        if st.session_state.get('critical_errors'):
            with st.expander(f"⚠️ Kritieke Fouten ({len(st.session_state['critical_errors'])})", expanded=True):
                for error in st.session_state['critical_errors']:
                    st.write(f"- {error}")

        # Toon warnings
        if st.session_state.get('warnings'):
            with st.expander(f"ℹ️ Waarschuwingen ({len(st.session_state['warnings'])})"):
                for warning in st.session_state['warnings']:
                    st.write(f"- {warning}")

        # Export validatierapport knop
        st.markdown("---")
        col1, col2 = st.columns(2)
        with col1:
            export_name = st.text_input("Validatierapport naam", value="validatie_rapport.xlsx")
        with col2:
            st.write("")  # Spacing
            st.write("")  # Spacing
            if st.button("📄 Exporteer Validatierapport", use_container_width=True):
                try:
                    import tempfile
                    temp_dir = Path(tempfile.gettempdir())
                    export_path = temp_dir / export_name

                    with st.spinner("Validatierapport wordt gegenereerd..."):
                        # Run validatie met export
                        _, _, _ = pv_tool.validate_data(export_path=export_path)

                    # Download het rapport
                    with open(export_path, 'rb') as f:
                        st.download_button(
                            label="⬇️ Download Validatierapport",
                            data=f.read(),
                            file_name=export_name,
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            use_container_width=True
                        )

                    # Verwijder tijdelijk bestand
                    export_path.unlink()

                except Exception as e:
                    st.error(f"❌ Fout bij exporteren: {str(e)}")


    # Exporteer naar template knop
    st.markdown("---")
    if st.button("📤 Exporteer Data naar PV-tool Template", use_container_width=True):
        try:
            import tempfile
            temp_dir = Path(tempfile.gettempdir())
            export_name = f"export_{st.session_state.get('file_name', 'data')}"
            export_path = temp_dir / export_name

            with st.spinner("Data wordt geëxporteerd..."):
                pv_tool.export_dbase_to_template(export_dir=export_path.parent, export_name=export_path.name)

            # Download het bestand
            with open(export_path, 'rb') as f:
                st.download_button(
                    label="⬇️ Download PV-tool Template",
                    data=f.read(),
                    file_name=export_name,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True
                )

            # Verwijder tijdelijk bestand
            export_path.unlink()

        except Exception as e:
            st.error(f"❌ Fout bij exporteren: {str(e)}")


# Alleen tonen als er geen data is
if uploaded_file is None and 'data' not in st.session_state:
    st.info("👆 Upload een bestand om te beginnen")
