import streamlit as st
import sys
from pathlib import Path

# Voeg parent directory toe aan path voor src import
parent_path = Path(__file__).parent.parent
if str(parent_path) not in sys.path:
    sys.path.insert(0, str(parent_path))

# Import PV-tool wrapper
from src.pv_tool_wrapper import pv_tool
from src.cphi_figures import create_cphi_figures

st.set_page_config(page_title="C-Phi Analyse", page_icon="📊", layout="wide")

st.title("📊 C-Phi Analyse")
st.markdown("Analyseer cohesie (c) en frictiehoek (φ) parameters")

# Check of data beschikbaar is
if ('dbase' not in st.session_state or st.session_state.get('dbase') is None) and \
   ('data' not in st.session_state or st.session_state.get('data') is None):
    st.warning("⚠️ Geen data beschikbaar. Importeer eerst data via 'Import en Validate'")
    st.info("👈 Ga naar de 'Import en Validate' pagina om data te laden")
    st.stop()

# Sidebar voor analyse instellingen
with st.sidebar:
    # Selecteer onderzoeksgroepen
    st.header("Onderzoeksgroepen")
    available_groups = pv_tool.get_investigation_groups()

    # Herstel vorige selectie uit session state
    if 'cphi_selected_groups' in st.session_state:
        default_groups = st.session_state['cphi_selected_groups']
    else:
        default_groups = available_groups[:1] if available_groups else []

    if available_groups:
        selected_groups = st.multiselect(
            "Selecteer groepen",
            available_groups,
            default=default_groups
        )
        st.session_state['cphi_selected_groups'] = selected_groups
    else:
        st.warning("Geen groepen gevonden in data")
        selected_groups = []

    st.header("Analyse Instellingen")

    # Analyse type
    default_analysis_idx = 0
    if 'cphi_analysis_type' in st.session_state:
        try:
            analysis_types = ["TXT_CPhi", "TXT_SH", "DSS_CPhi", "DSS_SH"]
            default_analysis_idx = analysis_types.index(st.session_state['cphi_analysis_type'])
        except:
            pass

    analysis_type = st.selectbox(
        "Analyse Type",
        ["TXT_CPhi", "TXT_SH", "DSS_CPhi", "DSS_SH"],
        index=default_analysis_idx
    )
    st.session_state['cphi_analysis_type'] = analysis_type

    # Rekpercentage
    if analysis_type.startswith('TXT'):
        stress_options = ['2% rek', '5% rek', '15% rek', 'pieksterkte', 'eindsterkte']
    else:
        stress_options = ['2% rek', '5% rek', '10% rek', '15% rek', '20% rek', 'pieksterkte', 'eindsterkte']

    default_stress_idx = len(stress_options)-1
    if 'cphi_effective_stress' in st.session_state and st.session_state['cphi_effective_stress'] in stress_options:
        default_stress_idx = stress_options.index(st.session_state['cphi_effective_stress'])

    effective_stress = st.selectbox(
        "Rekpercentage",
        stress_options,
        index=default_stress_idx
    )
    st.session_state['cphi_effective_stress'] = effective_stress

    st.divider()

    # Alpha en materiaalfactoren
    st.header("Rekenwaarde Parameters")

    alpha_default = st.session_state.get('global_alpha', 0.75)
    alpha = st.number_input(
        "Alpha (lokaal = 1.0, regionaal = 0.75)",
        min_value=0.0,
        max_value=1.0,
        value=alpha_default,
        step=0.05,
        format="%.2f"
    )
    st.session_state['global_alpha'] = alpha

    st.subheader("Materiaalfactoren")

    gamma_phi_default = st.session_state.get('global_gamma_phi', 1.0)
    gamma_phi = st.number_input(
        "γ_φ (Frictiehoek)",
        min_value=1.0,
        max_value=2.0,
        value=gamma_phi_default,
        step=0.05
    )
    st.session_state['global_gamma_phi'] = gamma_phi

    gamma_c_default = st.session_state.get('global_gamma_c', 1.0)
    gamma_c = st.number_input(
        "γ_c (Cohesie)",
        min_value=1.0,
        max_value=2.0,
        value=gamma_c_default,
        step=0.05
    )
    st.session_state['global_gamma_c'] = gamma_c

# Main content
if selected_groups:
    # Run analyse button
    if st.button("🚀 Start C-Phi Analyse", type="primary", use_container_width=True):
        try:
            with st.spinner("C-Phi analyse wordt uitgevoerd..."):
                cphi_analysis = pv_tool.create_cphi_analysis(
                    analysis_type=analysis_type,
                    investigation_groups=selected_groups,
                    effective_stress=effective_stress
                )

                cphi_analysis._run()
                st.session_state['cphi_analysis'] = cphi_analysis
                st.session_state['cphi_results'] = True

                st.success("✅ Analyse compleet!")
                st.rerun()

        except Exception as e:
            st.error(f"❌ Fout bij analyse: {str(e)}")

    # Toon parameter tabel als analyse beschikbaar is
    if st.session_state.get('cphi_results', False) and 'cphi_analysis' in st.session_state:
        analysis = st.session_state['cphi_analysis']

        st.divider()
        st.subheader("📊 C-Phi Parameters Tabel")

        st.markdown("**Opgeven invoer effectieve schuifsterkteparameters (fit):**")

        # Probeer benaderingswaarden op te halen
        try:
            phi_gem_benadering = round(analysis.eerste_benadering_a2_gem, 2)
            coh_gem_benadering = round(analysis.eerste_benadering_a1_gem, 2)
            phi_kar_benadering = round(analysis.eerste_benadering_a2_kar, 2)
            coh_kar_benadering = round(analysis.eerste_benadering_a1_kar, 2)
        except:
            # Fallback waarden
            st.warning("⚠️ Kon geen benaderingswaarden vinden")

        # Session state keys voor deze groep
        group_key = selected_groups[0] if selected_groups else 'default'

        # Tabel headers
        col1, col2, col3 = st.columns([3, 2, 2])
        with col1:
            st.write("**Parameter**")
        with col2:
            st.write("**Benadering**")
        with col3:
            st.write("**Invoer**")

        # Phi gemiddeld (alleen weergave)
        col1, col2, col3 = st.columns([3, 2, 2])
        with col1:
            st.write("φ gemiddeld")
        with col2:
            st.write(f"{phi_gem_benadering}")
        with col3:
            st.write(" ")

        # Cohesie gemiddeld (aanpasbaar)
        col1, col2, col3 = st.columns([3, 2, 2])
        with col1:
            st.write("Cohesie gemiddeld")
        with col2:
            st.write(f"{coh_gem_benadering}")
        with col3:
            coh_gem_key = f"cphi_{group_key}_coh_gem"
            coh_gem_manual = st.number_input(
                "coh_gem",
                value=st.session_state.get(coh_gem_key, coh_gem_benadering),
                step=0.1,
                key=f"input_coh_gem_{group_key}",
                label_visibility="collapsed"
            )
            st.session_state[coh_gem_key] = coh_gem_manual

        # Phi karakteristiek (aanpasbaar)
        col1, col2, col3 = st.columns([3, 2, 2])
        with col1:
            st.write("φ karakteristiek")
        with col2:
            st.write(f"{phi_kar_benadering}")
        with col3:
            phi_kar_key = f"cphi_{group_key}_phi_kar"
            phi_kar_manual = st.number_input(
                "phi_kar",
                value=st.session_state.get(phi_kar_key, phi_kar_benadering),
                step=0.1,
                key=f"input_phi_kar_{group_key}",
                label_visibility="collapsed"
            )
            st.session_state[phi_kar_key] = phi_kar_manual

        # Cohesie karakteristiek (aanpasbaar)
        col1, col2, col3 = st.columns([3, 2, 2])
        with col1:
            st.write("Cohesie karakteristiek")
        with col2:
            st.write(f"{coh_kar_benadering}")
        with col3:
            coh_kar_key = f"cphi_{group_key}_coh_kar"
            coh_kar_manual = st.number_input(
                "coh_kar",
                value=st.session_state.get(coh_kar_key, coh_kar_benadering),
                step=0.1,
                key=f"input_coh_kar_{group_key}",
                label_visibility="collapsed"
            )
            st.session_state[coh_kar_key] = coh_kar_manual

        st.divider()

        # Pas parameters toe knop
        if st.button("🔧 Pas Parameters Toe", type="secondary", use_container_width=True):
            try:
                analysis.apply_parameters(
                    cohesie_gem=coh_gem_manual,
                    phi_kar=phi_kar_manual,
                    cohesie_kar=coh_kar_manual
                )

                analysis.apply_settings(
                    material_factor_cohesion=gamma_c,
                    material_factor_tan_phi=gamma_phi,
                    alpha=alpha
                )

                st.session_state['cphi_parameters_applied'] = True
                st.success("✅ Parameters toegepast!")

                # Toon direct de resultaten
                st.subheader("📈 Definitieve Resultaten")

                try:
                    results_df = analysis.get_short_results()
                    st.dataframe(results_df, use_container_width=True)

                    # Toon figuren
                    create_cphi_figures(
                        coh_gem=coh_gem_manual,
                        phi_gem=phi_gem_benadering,
                        coh_kar=coh_kar_manual,
                        phi_kar=phi_kar_manual,
                        analysis_type=analysis_type,
                        effective_stress=effective_stress,
                        selected_groups=selected_groups
                    )

                    # Export knop onderaan
                    st.divider()
                    if st.button("💾 Exporteer Resultaten", use_container_width=True):
                        try:
                            import tempfile
                            temp_dir = Path(tempfile.gettempdir())
                            export_path = temp_dir / "cphi_resultaten.xlsx"

                            analysis.add_results_to_template(path=temp_dir, export_name="cphi_resultaten.xlsx")

                            with open(export_path, 'rb') as f:
                                st.download_button(
                                    label="⬇️ Download Resultaten Excel",
                                    data=f.read(),
                                    file_name="cphi_resultaten.xlsx",
                                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    use_container_width=True
                                )
                            st.success("✅ Resultaten geëxporteerd!")
                        except Exception as exp_e:
                            st.error(f"❌ Fout bij exporteren: {str(exp_e)}")
                            st.info("🔧 Export functionaliteit wordt verder geïmplementeerd...")

                except Exception as res_e:
                    st.error(f"❌ Fout bij ophalen resultaten: {str(res_e)}")

            except Exception as e:
                st.error(f"❌ Fout bij toepassen parameters: {str(e)}")

        # Toon ook resultaten als ze al eerder zijn toegepast (voor als je de pagina refresht)
        elif st.session_state.get('cphi_parameters_applied', False):
            st.subheader("📈 Definitieve Resultaten")

            try:
                results_df = analysis.get_short_results()
                st.dataframe(results_df, use_container_width=True)

                # Figuren sectie
                try:
                    # Haal de handmatige waarden op uit session state
                    group_key = selected_groups[0] if selected_groups else 'default'
                    coh_gem = st.session_state.get(f"cphi_{group_key}_coh_gem", 5.0)
                    phi_kar = st.session_state.get(f"cphi_{group_key}_phi_kar", 25.0)
                    coh_kar = st.session_state.get(f"cphi_{group_key}_coh_kar", 3.0)

                    try:
                        phi_gem = analysis.eerste_benadering_a2_gem
                    except:
                        phi_gem = 30.0

                    # Gebruik de nieuwe figuur functie
                    create_cphi_figures(
                        coh_gem=coh_gem,
                        phi_gem=phi_gem,
                        coh_kar=coh_kar,
                        phi_kar=phi_kar,
                        analysis_type=analysis_type,
                        effective_stress=effective_stress,
                        selected_groups=selected_groups
                    )

                except Exception as fig_e:
                    st.error(f"❌ Fout bij figuren: {str(fig_e)}")

                # Export knop
                st.divider()
                if st.button("💾 Exporteer Resultaten", use_container_width=True):
                    try:
                        import tempfile
                        temp_dir = Path(tempfile.gettempdir())
                        export_path = temp_dir / "cphi_resultaten.xlsx"

                        analysis.add_results_to_template(path=temp_dir, export_name="cphi_resultaten.xlsx")

                        with open(export_path, 'rb') as f:
                            st.download_button(
                                label="⬇️ Download Resultaten Excel",
                                data=f.read(),
                                file_name="cphi_resultaten.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                use_container_width=True
                            )
                        st.success("✅ Resultaten geëxporteerd!")
                    except Exception as exp_e:
                        st.error(f"❌ Fout bij exporteren: {str(exp_e)}")

            except Exception as res_e:
                st.error(f"❌ Fout bij ophalen resultaten: {str(res_e)}")

else:
    st.info("👈 Selecteer één of meer onderzoeksgroepen in de sidebar om te beginnen")

# Info sectie
with st.expander("ℹ️ Over C-Phi Analyse"):
    st.markdown("""
    Hier kunnen we extra informatie zetten.
    """)
