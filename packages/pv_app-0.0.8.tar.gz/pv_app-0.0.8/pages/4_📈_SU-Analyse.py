import streamlit as st
import pandas as pd
import sys
from pathlib import Path

# Voeg parent directory toe aan path voor src import
parent_path = Path(__file__).parent.parent
if str(parent_path) not in sys.path:
    sys.path.insert(0, str(parent_path))

from src.pv_tool_wrapper import pv_tool

st.set_page_config(page_title="SU-Analyse", page_icon="📈", layout="wide")

st.title("📈 SU-Analyse")
st.markdown("Ongedraineerde schuifsterkte (Su) analyse en tabel generatie")

# Check of data beschikbaar is
if 'dbase' not in st.session_state or st.session_state.get('dbase') is None:
    st.warning("⚠️ Geen data beschikbaar. Importeer eerst data via 'Import en Validate'")
    st.info("👈 Ga naar de 'Import en Validate' pagina om data te laden")
    st.stop()

# Sidebar voor analyse instellingen
with st.sidebar:
    st.header("SU-Tabel Instellingen")

    st.info("""
    De SU-analyse genereert een tabel met ongedraineerde 
    schuifsterkte waarden per dieptezone.
    """)

    st.divider()

    # Selecteer onderzoeksgroepen
    st.subheader("Onderzoeksgroepen")
    available_groups = pv_tool.get_investigation_groups()

    if available_groups:
        selected_groups = st.multiselect(
            "Selecteer groepen",
            available_groups,
            default=available_groups[:1] if available_groups else []
        )
    else:
        st.warning("Geen groepen gevonden in data")
        selected_groups = []

    st.divider()

    # Diepte instellingen
    st.subheader("Diepte Zones")
    use_auto_zones = st.checkbox("Automatische zones", value=True)

    if not use_auto_zones:
        depth_start = st.number_input("Start diepte (m)", value=0.0, step=0.5)
        depth_end = st.number_input("Eind diepte (m)", value=20.0, step=0.5)
        depth_interval = st.number_input("Interval (m)", value=1.0, step=0.1)

    st.divider()

    # Rekenwaarde parameters
    st.header("Rekenwaarde Parameters")

    # Alpha factor
    alpha_default = st.session_state.get('global_alpha', 0.75)
    alpha = st.number_input(
        "Alpha",
        min_value=0.0,
        max_value=1.0,
        value=alpha_default,
        step=0.05,
        help="Alpha factor: lokaal = 1.0, regionaal = 0.75"
    )
    st.session_state['global_alpha'] = alpha
    st.caption("Lokaal = 1.0, Regionaal = 0.75")

    st.divider()

    # Materiaalfactoren
    st.subheader("Materiaalfactoren")

    gamma_su_default = st.session_state.get('global_gamma_su', 1.0)
    gamma_su = st.number_input(
        "γ_Su (Ongedraineerde schuifsterkte)",
        min_value=1.0,
        max_value=2.0,
        value=gamma_su_default,
        step=0.05,
        help="Materiaalfactor voor Su"
    )
    st.session_state['global_gamma_su'] = gamma_su

    st.info(f"""
    **Huidige waarden:**
    - α = {alpha}
    - γ_Su = {gamma_su}
    """)

# Main content
if selected_groups:
    st.subheader("1. Geselecteerde Groepen")

    st.write(f"**SU-analyse voor {len(selected_groups)} groep(en):**")
    for group in selected_groups:
        st.write(f"- {group}")

    # Run analyse button
    if st.button("🚀 Start SU-Analyse", type="primary", use_container_width=True):
        try:
            with st.spinner("SU-analyse wordt uitgevoerd..."):
                # Maak analyse instance
                su_analysis = pv_tool.create_sutabel_analysis(
                    investigation_groups=selected_groups
                )

                # Bewaar in session state
                st.session_state['su_analysis'] = su_analysis
                st.session_state['su_results'] = True

                st.success("✅ Analyse compleet!")
                st.rerun()

        except Exception as e:
            st.error(f"❌ Fout bij analyse: {str(e)}")
            with st.expander("Details"):
                st.exception(e)

    # Toon resultaten als beschikbaar
    if st.session_state.get('su_results', False) and 'su_analysis' in st.session_state:
        analysis = st.session_state['su_analysis']

        st.divider()
        st.subheader("2. Analyse Resultaten")

        # Tabs voor verschillende resultaten
        tab1, tab2, tab3, tab4 = st.tabs(["📊 SU-Tabel", "📈 Grafieken", "📋 Data", "💾 Export"])

        with tab1:
            st.markdown("### SU-Tabel per Dieptezone")

            st.info("""
            De SU-tabel geeft de ongedraineerde schuifsterkte per dieptezone, 
            inclusief gemiddelde, karakteristieke en rekenwaarden.
            """)

            # Toon tabellen per groep
            for group in selected_groups:
                with st.expander(f"**{group}**", expanded=True):
                    st.markdown(f"#### SU-waarden voor {group}")

                    # Voorbeeld tabel structuur
                    st.info("Tabel wordt gegenereerd door de PV-tool SU-tabel analyse")

                    # Placeholder voor tabel
                    st.markdown("""
                    **Kolommen:**
                    - Diepte zone (m NAP)
                    - Aantal metingen
                    - Su gemiddeld (kPa)
                    - Su karakteristiek (kPa)
                    - Su rekenwaarde (kPa)
                    - Standaard deviatie
                    - Variatiecoëfficiënt
                    """)

        with tab2:
            st.markdown("### Visualisaties")

            st.write("**Su Diepte Profiel**")
            st.info("Diepte profiel met Su waarden wordt gegenereerd door de PV-tool")

            st.write("**Su vs σ'v Plot**")
            st.info("Relatie tussen Su en effectieve spanning")

            st.write("**Su/σ'v Ratio**")
            st.info("Genormaliseerde sterkte per diepte")

        with tab3:
            st.markdown("### Analyse Data")

            # Toon de onderliggende data
            if hasattr(analysis, 'dbase_df'):
                df = analysis.dbase_df

                # Filter relevante kolommen
                relevant_cols = [col for col in df.columns if any(
                    keyword in col.lower() for keyword in
                    ['su', 'diepte', 'depth', 'sigma', 'pv_naam', 'proeftype']
                )]

                if relevant_cols:
                    st.dataframe(df[relevant_cols], use_container_width=True, height=400)
                else:
                    st.dataframe(df, use_container_width=True, height=400)
            else:
                st.info("Geen data beschikbaar voor weergave")

        with tab4:
            st.markdown("### Export Opties")

            col1, col2, col3 = st.columns(3)

            with col1:
                if st.button("📄 Export naar Excel", use_container_width=True):
                    st.info("Export functionaliteit wordt geïmplementeerd")

            with col2:
                if st.button("📊 Export naar PDF", use_container_width=True):
                    st.info("PDF export wordt geïmplementeerd")

            with col3:
                if st.button("📋 Export SU-tabel CSV", use_container_width=True):
                    st.info("CSV export wordt geïmplementeerd")

            st.markdown("---")
            st.caption("Export gebruikt PV-tool's ingebouwde export functies")
else:
    st.info("👈 Selecteer één of meer onderzoeksgroepen in de sidebar om te beginnen")

# Info sectie
with st.expander("ℹ️ Over SU-Analyse"):
    st.markdown("""
    ### Ongedraineerde Schuifsterkte (Su)
    
    De **Su-analyse** bepaalt de ongedraineerde schuifsterkte van cohesieve grond (klei, leem, veen).
    
    ### Wat is Su?
    
    **Su** is de schuifsterkte van grond wanneer water niet kan ontsnappen tijdens belasting:
    - Relevant voor **korte-termijn** stabiliteit
    - Belangrijk voor **snelle** belastingscenario's
    - Gebruikt in **dijkstabiliteit** berekeningen
    
    ### Bepaling van Su:
    
    Su kan bepaald worden met verschillende proeven:
    
    1. **Triaxiaal proef (TXT)**: CU of UU proef
    2. **Direct Simple Shear (DSS)**: Simulatie van in-situ omstandigheden
    3. **Veldproeven**: Vane test, CPT correlaties
    
    ### SU-Tabel:
    
    De SU-tabel geeft per dieptezone:
    
    - **Su,gem**: Gemiddelde waarde (alle metingen)
    - **Su,kar**: Karakteristieke waarde (5% ondergrens)
    - **Su,rek**: Rekenwaarde (Su,kar / γm)
    
    Waarbij γm de materiaalfactor is (typisch 1.0 - 1.2)
    
    ### Normalisatie:
    
    Vaak wordt Su genormaliseerd met de effectieve spanning:
    
    **Su / σ'v**
    
    Dit geeft inzicht in:
    - Consolidatie geschiedenis
    - Plasticiteit
    - Grondtype
    
    Typische waarden:
    - **NC klei**: Su/σ'v ≈ 0.20 - 0.25
    - **OC klei**: Su/σ'v > 0.25
    - **Veen**: Su/σ'v ≈ 0.15 - 0.30
    
    ### Toepassingen:
    
    1. **Dijkstabiliteit**: Korte-termijn stabiliteit tijdens hoogwater
    2. **Bouwkuip**: Bodemstabiliteit tijdens ontgraving
    3. **Funderingen**: Draagvermogen analyse
    4. **Grondverbetering**: Voor/na vergelijking
    
    ### Analyse Stappen:
    
    1. Importeer proefgegevens (TXT, DSS, Vane)
    2. Groepeer per laag/zone
    3. Bereken statistieken per zone
    4. Bepaal karakteristieke waarden
    5. Genereer SU-tabel en profielen
    6. Export resultaten voor gebruik in berekeningen
    """)


