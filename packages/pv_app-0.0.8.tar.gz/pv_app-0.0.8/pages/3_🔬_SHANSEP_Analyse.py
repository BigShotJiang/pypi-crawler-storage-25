import streamlit as st
import pandas as pd
import sys
from pathlib import Path

# Voeg parent directory toe aan path voor src import
parent_path = Path(__file__).parent.parent
if str(parent_path) not in sys.path:
    sys.path.insert(0, str(parent_path))

from src.pv_tool_wrapper import pv_tool

st.set_page_config(page_title="SHANSEP Analyse", page_icon="🔬", layout="wide")

st.title("🔬 SHANSEP Analyse")
st.markdown("**S**tress **H**istory **A**nd **N**ormalized **S**oil **E**ngineering **P**roperties")

# Check of data beschikbaar is
if 'dbase' not in st.session_state or st.session_state.get('dbase') is None:
    st.warning("⚠️ Geen data beschikbaar. Importeer eerst data via 'Import en Validate'")
    st.info("👈 Ga naar de 'Import en Validate' pagina om data te laden")
    st.stop()

# Sidebar voor analyse instellingen
with st.sidebar:
    st.header("SHANSEP Parameters")
    st.markdown("### Su/σ'vc = S · (OCR)^m")

    st.info("""
    De SHANSEP methode normaliseert de ongedraineerde schuifsterkte 
    ten opzichte van de consolidatiespanning.
    """)

    st.divider()

    # Selecteer onderzoeksgroepen
    st.subheader("Onderzoeksgroepen")
    available_groups = pv_tool.get_investigation_groups()

    if available_groups:
        selected_groups = st.multiselect(
            "Selecteer groepen",
            available_groups,
            default=available_groups[:1] if available_groups else []
        )
    else:
        st.warning("Geen groepen gevonden in data")
        selected_groups = []

    st.divider()

    # Rekenwaarde parameters
    st.header("Rekenwaarde Parameters")

    # Alpha factor
    alpha_default = st.session_state.get('global_alpha', 0.75)
    alpha = st.number_input(
        "Alpha",
        min_value=0.0,
        max_value=1.0,
        value=alpha_default,
        step=0.05,
        help="Alpha factor: lokaal = 1.0, regionaal = 0.75"
    )
    st.session_state['global_alpha'] = alpha
    st.caption("Lokaal = 1.0, Regionaal = 0.75")

    st.divider()

    # Materiaalfactoren
    st.subheader("Materiaalfactoren")

    gamma_s_default = st.session_state.get('global_gamma_s', 1.0)
    gamma_s = st.number_input(
        "γ_S (SHANSEP S parameter)",
        min_value=1.0,
        max_value=2.0,
        value=gamma_s_default,
        step=0.05,
        help="Materiaalfactor voor S parameter"
    )
    st.session_state['global_gamma_s'] = gamma_s

    gamma_m_default = st.session_state.get('global_gamma_m', 1.0)
    gamma_m = st.number_input(
        "γ_m (SHANSEP m parameter)",
        min_value=1.0,
        max_value=2.0,
        value=gamma_m_default,
        step=0.05,
        help="Materiaalfactor voor m parameter"
    )
    st.session_state['global_gamma_m'] = gamma_m

    st.info(f"""
    **Huidige waarden:**
    - α = {alpha}
    - γ_S = {gamma_s}
    - γ_m = {gamma_m}
    """)

# Main content
if selected_groups:
    st.subheader("1. Geselecteerde Groepen")

    st.write(f"**Analyse voor {len(selected_groups)} groep(en):**")
    for group in selected_groups:
        st.write(f"- {group}")

    # Run analyse button
    if st.button("🚀 Start SHANSEP Analyse", type="primary", use_container_width=True):
        try:
            with st.spinner("SHANSEP analyse wordt uitgevoerd..."):
                # Maak analyse instance
                shansep_analysis = pv_tool.create_shansep_analysis(
                    investigation_groups=selected_groups
                )

                # Bewaar in session state
                st.session_state['shansep_analysis'] = shansep_analysis
                st.session_state['shansep_results'] = True

                st.success("✅ Analyse compleet!")
                st.rerun()

        except Exception as e:
            st.error(f"❌ Fout bij analyse: {str(e)}")
            with st.expander("Details"):
                st.exception(e)

    # Toon resultaten als beschikbaar
    if st.session_state.get('shansep_results', False) and 'shansep_analysis' in st.session_state:
        analysis = st.session_state['shansep_analysis']

        st.divider()
        st.subheader("2. Analyse Resultaten")

        # Tabs voor verschillende resultaten
        tab1, tab2, tab3, tab4 = st.tabs(["📊 Parameters", "📈 Grafieken", "📋 Data", "💾 Export"])

        with tab1:
            st.markdown("### SHANSEP Parameters")

            st.latex(r"\frac{S_u}{\sigma'_{vc}} = S \cdot OCR^m")

            # Toon parameters per groep
            for group in selected_groups:
                with st.expander(f"**{group}**", expanded=True):
                    col1, col2, col3 = st.columns(3)

                    with col1:
                        st.metric("S parameter (gemiddeld)", "---")
                        st.metric("S parameter (karakteristiek)", "---")
                        st.metric("S parameter (rekenwaarde)", "---")

                    with col2:
                        st.metric("m exponent (gemiddeld)", "---")
                        st.metric("m exponent (karakteristiek)", "---")
                        st.metric("m exponent (rekenwaarde)", "---")

                    with col3:
                        st.metric("OCR bereik", "--- - ---")
                        st.metric("Aantal metingen", "---")
                        st.metric("R² waarde", "---")

                    st.markdown("**Interpretatie:**")
                    st.info("""
                    - **S**: Sterkte ratio bij NC conditie (OCR=1)
                    - **m**: Invloed van overconsolidatie
                    - **Typisch**: S = 0.20-0.25, m = 0.8
                    """)

        with tab2:
            st.markdown("### Visualisaties")

            st.write("**SHANSEP Relatie: Su/σ'vc vs OCR**")
            st.info("Grafiek wordt gegenereerd door de PV-tool analyse")

            st.write("**Diepte Profielen**")
            st.info("Diepte profielen worden gegenereerd door de PV-tool")

            st.write("**OCR Distributie**")
            st.info("OCR distributie wordt gevisualiseerd door de PV-tool")

        with tab3:
            st.markdown("### Analyse Data")

            # Toon de onderliggende data
            if hasattr(analysis, 'dbase_df'):
                df = analysis.dbase_df

                # Filter relevante kolommen
                relevant_cols = [col for col in df.columns if any(
                    keyword in col.lower() for keyword in
                    ['ocr', 'su', 'sigma', 'diepte', 'depth', 'pv_naam']
                )]

                if relevant_cols:
                    st.dataframe(df[relevant_cols], use_container_width=True, height=400)
                else:
                    st.dataframe(df, use_container_width=True, height=400)
            else:
                st.info("Geen data beschikbaar voor weergave")

        with tab4:
            st.markdown("### Export Opties")

            col1, col2 = st.columns(2)

            with col1:
                if st.button("📄 Export naar Excel", use_container_width=True):
                    st.info("Export functionaliteit wordt geïmplementeerd")

            with col2:
                if st.button("📊 Export naar PDF", use_container_width=True):
                    st.info("PDF export wordt geïmplementeerd")

            st.markdown("---")
            st.caption("Export gebruikt PV-tool's ingebouwde export functies")
else:
    st.info("👈 Selecteer één of meer onderzoeksgroepen in de sidebar om te beginnen")

# Info sectie
with st.expander("ℹ️ Over SHANSEP Analyse"):
    st.markdown("""
    ### SHANSEP Methodologie
    
    **SHANSEP** staat voor **S**tress **H**istory **A**nd **N**ormalized **S**oil **E**ngineering **P**roperties.
    
    Deze methode is ontwikkeld om de ongedraineerde schuifsterkte van klei te voorspellen op basis van:
    - **Consolidatie geschiedenis** (OCR - Over Consolidation Ratio)
    - **Normalisatie** van sterkte parameters
    
    ### De SHANSEP Relatie:
    
    **Su / σ'vc = S · (OCR)^m**
    
    Waar:
    - **Su** = Ongedraineerde schuifsterkte
    - **σ'vc** = Effectieve verticale consolidatiespanning
    - **S** = Sterkte parameter bij normally consolidated (OCR=1)
    - **m** = Exponent die de invloed van OCR beschrijft
    - **OCR** = Over Consolidation Ratio (σ'vmax / σ'vc)
    
    ### Typische Waarden:
    
    - **S**: 0.20 - 0.25 (afhankelijk van grondtype)
    - **m**: 0.7 - 0.9 (meestal rond 0.8)
    
    ### Toepassingen:
    
    1. **Dijkstabiliteit**: Bepaling van kleiparameters onder verschillende belastingen
    2. **Funderingen**: Schuifsterkte bij verschillende consolidatiestaten
    3. **Grondverbetering**: Effect van voorbelasten op sterkte
    
    ### Analyse Stappen:
    
    1. Bepaal σ'vc en σ'vmax uit veldgegevens
    2. Bereken OCR = σ'vmax / σ'vc
    3. Meet Su uit laboratoriumproeven
    4. Plot Su/σ'vc vs OCR op log-log schaal
    5. Fit SHANSEP relatie om S en m te bepalen
    6. Bereken karakteristieke en rekenwaarden
    """)

    with tab1:
        st.subheader("SHANSEP Relatie: Su/σ'vc vs OCR")

        # Check if required columns exist
        if 'OCR' in df.columns and 'Su_ratio' in df.columns:

            col1, col2 = st.columns([2, 1])

            with col1:
                # Main SHANSEP plot
                fig = go.Figure()

                # Scatter plot of data
                fig.add_trace(go.Scatter(
                    x=df['OCR'],
                    y=df['Su_ratio'],
                    mode='markers',
                    name='Meetdata',
                    marker=dict(
                        size=10,
                        color=df['depth_m'] if 'depth_m' in df.columns else 'blue',
                        colorscale='Viridis',
                        showscale=True,
                        colorbar=dict(title="Diepte (m)")
                    ),
                    text=[f"Diepte: {d:.1f}m<br>OCR: {o:.2f}<br>Su/σ'vc: {r:.3f}"
                          for d, o, r in zip(df['depth_m'], df['OCR'], df['Su_ratio'])],
                    hovertemplate='%{text}<extra></extra>'
                ))

                # Theoretical SHANSEP line
                ocr_theory = np.linspace(df['OCR'].min(), df['OCR'].max(), 100)
                su_ratio_theory = S_param * (ocr_theory ** m_param)

                fig.add_trace(go.Scatter(
                    x=ocr_theory,
                    y=su_ratio_theory,
                    mode='lines',
                    name=f'SHANSEP: S={S_param}, m={m_param}',
                    line=dict(color='red', width=3, dash='dash')
                ))

                fig.update_layout(
                    title="SHANSEP Normalisatie",
                    xaxis_title="OCR (-)",
                    yaxis_title="Su / σ'vc (-)",
                    xaxis_type="log",
                    yaxis_type="log",
                    height=500,
                    hovermode='closest',
                    showlegend=True
                )

                st.plotly_chart(fig, use_container_width=True)

            with col2:
                st.markdown("### SHANSEP Formule")
                st.latex(r"\frac{S_u}{\sigma'_{vc}} = S \cdot OCR^m")

                st.markdown("**Huidige parameters:**")
                st.code(f"S = {S_param}\nm = {m_param}")

                st.markdown("**Interpretatie:**")
                st.markdown(f"""
                - **S**: Sterkte ratio bij NC conditie (OCR=1)
                - **m**: Invloed van overconsolidatie
                - **Typisch**: S = 0.20-0.25, m = 0.8
                """)

                if st.button("🔄 Bereken Best Fit"):
                    # Simple log-log regression
                    log_ocr = np.log(df['OCR'])
                    log_ratio = np.log(df['Su_ratio'])

                    coeffs = np.polyfit(log_ocr, log_ratio, 1)
                    m_fit = coeffs[0]
                    S_fit = np.exp(coeffs[1])

                    st.success(f"**Best fit:**\nS = {S_fit:.3f}\nm = {m_fit:.2f}")

        else:
            st.error("❌ Kolommen 'OCR' en 'Su_ratio' zijn vereist voor SHANSEP analyse")
            st.info("Voeg deze kolommen toe aan je data of gebruik demo data")

    with tab2:
        st.subheader("Diepte Profielen")

        if 'depth_m' in df.columns and 'Su_kPa' in df.columns:
            col1, col2 = st.columns(2)

            with col1:
                # Su profile
                fig1 = go.Figure()
                fig1.add_trace(go.Scatter(
                    y=df['depth_m'],
                    x=df['Su_kPa'],
                    mode='markers+lines',
                    name='Su',
                    line=dict(color='darkblue', width=2)
                ))

                fig1.update_layout(
                    title="Ongedraineerde Schuifsterkte Profiel",
                    xaxis_title="Su (kPa)",
                    yaxis_title="Diepte (m)",
                    yaxis=dict(autorange="reversed"),
                    height=600
                )
                st.plotly_chart(fig1, use_container_width=True)

            with col2:
                # OCR profile
                if 'OCR' in df.columns:
                    fig2 = go.Figure()
                    fig2.add_trace(go.Scatter(
                        y=df['depth_m'],
                        x=df['OCR'],
                        mode='markers+lines',
                        name='OCR',
                        line=dict(color='darkred', width=2)
                    ))

                    # Add reference line at OCR=1
                    fig2.add_vline(x=1, line_dash="dash", line_color="gray",
                                  annotation_text="NC")

                    fig2.update_layout(
                        title="Overconsolidatie Ratio Profiel",
                        xaxis_title="OCR (-)",
                        yaxis_title="Diepte (m)",
                        yaxis=dict(autorange="reversed"),
                        height=600
                    )
                    st.plotly_chart(fig2, use_container_width=True)
        else:
            st.warning("Kolommen voor diepteprofielen ontbreken")

    with tab3:
        st.subheader("Parameter Fitting & Optimalisatie")

        col1, col2 = st.columns([1, 1])

        with col1:
            st.markdown("### Handmatige Aanpassing")

            S_manual = st.slider("S parameter", 0.10, 0.40, S_param, 0.01)
            m_manual = st.slider("m exponent", 0.5, 1.2, m_param, 0.05)

            if st.button("📊 Update Plot met Nieuwe Parameters"):
                st.info(f"Plot bijgewerkt: S={S_manual:.3f}, m={m_manual:.2f}")

        with col2:
            st.markdown("### Automatische Fit")

            fit_method = st.radio(
                "Fit methode",
                ["Least Squares", "Maximum Likelihood", "Robust Regression"]
            )

            if st.button("🎯 Run Optimalisatie", type="primary"):
                with st.spinner("Optimaliseren..."):
                    # Placeholder for actual optimization
                    st.success("""
                    ✅ **Optimalisatie voltooid**
                    
                    Resultaten:
                    - S = 0.228 ± 0.015
                    - m = 0.82 ± 0.06
                    - R² = 0.94
                    - RMSE = 0.018
                    """)

        st.divider()

        # Residual analysis
        st.markdown("### Residual Analyse")
        st.caption("Verschil tussen gemeten en voorspelde waarden")

        if 'OCR' in df.columns and 'Su_ratio' in df.columns:
            df['Su_ratio_predicted'] = S_param * (df['OCR'] ** m_param)
            df['residual'] = df['Su_ratio'] - df['Su_ratio_predicted']

            fig_res = px.scatter(
                df, x='OCR', y='residual',
                color='depth_m',
                labels={'residual': 'Residual', 'OCR': 'OCR (-)'},
                title="Residuals vs OCR"
            )
            fig_res.add_hline(y=0, line_dash="dash", line_color="red")
            st.plotly_chart(fig_res, use_container_width=True)

    with tab4:
        st.subheader("Samenvatting & Export")

        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("S parameter", f"{S_param:.3f}")
        with col2:
            st.metric("m exponent", f"{m_param:.2f}")
        with col3:
            st.metric("Datapunten", len(df))
        with col4:
            st.metric("R² fit", "0.94" if len(df) > 0 else "N/A")

        st.divider()

        # Results table
        st.markdown("### Analyse Resultaten")

        if all(col in df.columns for col in ['depth_m', 'OCR', 'Su_kPa', 'Su_ratio']):
            results_df = df[['depth_m', 'OCR', 'Su_kPa', 'Su_ratio']].copy()
            results_df.columns = ['Diepte (m)', 'OCR', 'Su (kPa)', 'Su/σ\'vc']

            st.dataframe(results_df, use_container_width=True)

            # Export options
            st.markdown("### 💾 Export Opties")

            col1, col2 = st.columns(2)

            with col1:
                csv = results_df.to_csv(index=False)
                st.download_button(
                    "⬇️ Download Resultaten (CSV)",
                    csv,
                    "shansep_results.csv",
                    "text/csv"
                )

            with col2:
                if st.button("📊 Genereer Rapport"):
                    st.info("Rapport generatie: integratie met PV-tool gepland")

# Info section
with st.expander("ℹ️ Over SHANSEP Methodologie"):
    st.markdown("""
    ### SHANSEP Principe
    
    De SHANSEP methode normaliseert grondsterkte naar consolidatiespanning:
    
    **Su / σ'vc = S · (OCR)^m**
    
    **Parameters:**
    - **S**: Genormaliseerde sterkte bij NC conditie (typically 0.20-0.25)
    - **m**: Exponent die invloed OCR beschrijft (typically 0.8)
    - **OCR**: Overconsolidation Ratio = σ'p / σ'vc
    
    **Voordelen:**
    - Normaliseert voor verschillende spanningsniveaus
    - Rekent systematisch met stress history
    - Goed toepasbaar voor kleigronden
    
    **PV-tool integratie (toekomstig):**
    - `pv_tool.shansep.analyze()`
    - `pv_tool.shansep.fit_parameters()`
    - `pv_tool.shansep.predict_su()`
    """)

