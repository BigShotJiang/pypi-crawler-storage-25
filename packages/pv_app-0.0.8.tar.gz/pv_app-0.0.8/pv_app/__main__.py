import subprocess
import webbrowser
import time
import threading
from pathlib import Path

def open_browser():
    """Open browser after a short delay to ensure streamlit is running"""
    time.sleep(2)  # Wait 2 seconds for streamlit to start
    webbrowser.open("http://localhost:8501")

def main():
    # Find the app.py file relative to this package
    package_dir = Path(__file__).parent.parent
    app_path = package_dir / "app.py"
    
    if not app_path.exists():
        print(f"Error: Could not find app.py at {app_path}")
        return
    
    # Start browser in background thread
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()
    
    # Start streamlit app with absolute path
    subprocess.run(["streamlit", "run", str(app_path)])

if __name__ == "__main__":
    main()
