import numpy as np
import argparse
import os.path
import sys
import glob
import tempfile
import json
import logging
import PIL.Image
from bids import BIDSLayout
from nilearn.plotting import plot_img
import matplotlib.pyplot as plt
import nibabel as nb
from reportlab.platypus import (
    Paragraph,
    Image,
    Table,
    SimpleDocTemplate,
    PageBreak,
    TableStyle,
    Spacer,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors


logger = logging.getLogger(__name__)

MAX_IMG_HEIGHT = 80
MAX_IMG_WIDTH = 80


def enhance_brightness(
    img: PIL.Image, target_brightness=100, threshold=10
) -> PIL.Image:
    """Attempts to change the brightness of an image to the target brightness."""
    arr = np.array(img, dtype="float32")
    mask = arr > threshold
    rms = np.sqrt(np.mean(np.square(arr[mask])))
    brightness_factor = target_brightness / rms
    arr[mask] *= brightness_factor
    return PIL.Image.fromarray(arr).convert("L")


def create_slice_img(
    img_path: str,
    out_dir: str,
    ds_path: str,
    display_mode="x",
    cut_coords=np.array([0]),
    colorbar=False,
    ds_root=None,
    downsample=None,
) -> None:
    """Creates a png of a slice(s) of a nifti. Defaults to a single midline
    sagittal slice."""

    logger.debug(f"Creating png from {img_path}")
    try:
        img = nb.load(img_path)
    except FileNotFoundError:
        logger.warning("Skipping %s because file was not found." % img_path)
        return

    if ds_root:
        relpath = os.path.relpath(img_path, ds_path)
        out_file = relpath.replace("/", ":") + ".png"
    else:
        out_file = os.path.basename(img_path) + ".png"

    out_path = os.path.join(out_dir, out_file)

    if len(img.shape) == 3:
        try:
            plot_img(
                img,
                display_mode=display_mode,
                cut_coords=cut_coords,
                colorbar=colorbar,
                annotate=False,
            )
        except (EOFError, np._core._exceptions._ArrayMemoryError) as e:
            logger.warning("Skipping %s due to the following error: %s" % (img_path, e))
            plt.close()
            return

        plt.savefig(out_path, transparent=True)
    elif len(img.shape) == 2:
        logger.warning("%s is a 2D image." % img_path)
        img_data = img.get_fdata()
        img_data = np.flipud(img_data.T)

        out_path = out_path.replace(".png", "_2D.png")
        plt.imsave(out_path, img_data, cmap="gray")
    plt.close()

    # Remove transparent margins
    png = PIL.Image.open(out_path)
    new_png = png.crop(png.getbbox()).convert("L")

    if downsample:
        height, width = new_png.size
        new_size = (round(height / downsample), round(width / downsample))
        new_png = new_png.resize(new_size)

    new_png = enhance_brightness(new_png)

    new_png.save(out_path)


def create_sized_img(img_path: str) -> Image:
    """Creates a reportlab Image from a .png, scaled to fit within
    MAX_IMG_HEIGHT x MAX_IMG_WIDTH while maintaining aspect ratio."""
    img = PIL.Image.open(img_path)
    width, height = img.size

    h_ratio = MAX_IMG_HEIGHT / height
    w_ratio = MAX_IMG_WIDTH / width

    if h_ratio >= 1 and w_ratio >= 1:
        return Image(img_path, height=height, width=width)
    elif h_ratio <= w_ratio:
        new_height = MAX_IMG_HEIGHT
        new_width = h_ratio * width
    else:
        new_width = MAX_IMG_WIDTH
        new_height = w_ratio * height
    return Image(img_path, height=new_height, width=new_width)


def create_filename_caption(img_path: str) -> str:
    """Returns the filename of the image, formatted for use as a caption."""
    caption_text = os.path.basename(img_path)
    caption_text = caption_text.replace(":", "/")
    caption_text = os.path.relpath(caption_text)
    caption_text = caption_text.removesuffix(".png")
    if caption_text.endswith("_2D"):
        caption_text = caption_text.removesuffix("_2D")
        caption_text += " (2D)"

    return caption_text


def create_mosaic_table(img_dir_path: str, page_width: int, styles) -> Table:
    """Creates reportlab Table of slice images with image-name captions."""
    caption_style = ParagraphStyle(
        "Caption",
        parent=styles["Normal"],
        fontSize=6,
        leading=6,
        textColor=colors.black,
        alignment="CENTER",
        leftIndent=0,
        rightIndent=0,
        spaceAfter=0,
        spaceBefore=0,
    )

    image_path_list = sorted(glob.glob(img_dir_path + "/*"))

    if not image_path_list:
        logger.error(f"No images found in {img_dir_path}")
        sys.exit(1)

    table_data = [
        [
            create_sized_img(img_path),
            Paragraph(
                f"<para align=center spaceb=3>{create_filename_caption(img_path)}</para>",
                caption_style,
            ),
        ]
        for img_path in image_path_list
    ]

    largest_img_width = max(row[0]._width for row in table_data)
    num_col = int(page_width / largest_img_width)
    col_width = int(page_width / num_col)

    table_data_rows = [
        table_data[i : i + num_col] for i in range(0, len(image_path_list), num_col)
    ]

    table_style = TableStyle(
        [
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 2),
            ("RIGHTPADDING", (0, 0), (-1, -1), 2),
            ("TOPPADDING", (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.grey),
            ("BOX", (0, 0), (-1, -1), 0.25, colors.black),
        ]
    )
    table = Table(table_data_rows, colWidths=col_width)
    table.setStyle(table_style)

    return table


def create_metadata_table(metadata: str) -> Table:
    """Creates a reportlab Table containing user-inputted metadata."""
    metadata_dict = json.loads(metadata)
    metadata_list = list(metadata_dict.items())

    table_style = TableStyle(
        [
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.grey),
            ("BOX", (0, 0), (-1, -1), 0.25, colors.black),
        ]
    )

    table = Table(metadata_list)
    table.setStyle(table_style)

    return table


def create_pdf(img_dir_path: str, out_path: str, metadata=None) -> None:
    """Creates a pdf containing images aligned in a grid"""
    styles = getSampleStyleSheet()
    pdf = SimpleDocTemplate(
        out_path,
        pagesize=(612, 792),
        leftMargin=18,
        rightMargin=18,
        topMargin=36,
        bottomMargin=36,
    )
    page_width = int(pdf.width)

    flowables = []

    for d in glob.glob(os.path.join(img_dir_path, "*")):
        title_text = os.path.basename(d) + " Images"
        title = Paragraph(title_text, styles["Title"])
        flowables.append(title)
        flowables.append(Spacer(0, 15))

        mosaic_table = create_mosaic_table(d, page_width, styles)
        flowables.append(mosaic_table)

        flowables.append(PageBreak())

    if metadata:
        title = Paragraph("Metadata", styles["Title"])
        flowables.append(title)
        flowables.append(Spacer(0, 15))

        metadata_table = create_metadata_table(metadata)
        flowables.append(metadata_table)

    pdf.build(flowables)

    logger.info("Successfully created pdf")


def create_anat_images(layout: BIDSLayout, png_dir: str, downsample=None) -> None:
    """Creates anatomical mosaic .png files."""
    anat_layout_kwargs = {
        "datatype": "anat",
        "extension": ["nii", "nii.gz"],
    }

    files = layout.get(**anat_layout_kwargs)
    anat_png_dir = os.path.join(png_dir, "Anatomical")
    os.makedirs(anat_png_dir, exist_ok=True)

    for file in files:
        create_slice_img(file.path, anat_png_dir, layout.root, downsample=downsample)


def create_fs_images(fs_dir: str, png_dir: str, downsample=None) -> None:
    """Creates freesurfer mosaic .png files."""
    fs_png_dir = os.path.join(png_dir, "Freesurfer")
    os.makedirs(fs_png_dir, exist_ok=True)

    for file_path in glob.glob(os.path.join(fs_dir, "sub-*/mri/orig/*")):
        create_slice_img(
            file_path, fs_png_dir, fs_dir, ds_root=fs_dir, downsample=downsample
        )


def create_mosaic_pdf(
    dataset: str,
    out_file: str,
    anat=True,
    png_out_dir=None,
    downsample=None,
    freesurfer=None,
    metadata=None,
) -> None:
    """Creates a mosaic pdf."""
    if png_out_dir:
        png_dir = png_out_dir
    else:
        temp_dir_obj = tempfile.TemporaryDirectory()
        png_dir = temp_dir_obj.name

    layout = BIDSLayout(dataset, validate=False)

    if anat:
        logger.info(f"Creating anat images in {png_dir}")
        create_anat_images(layout, png_dir, downsample=downsample)
    if freesurfer:
        logger.info(f"Creating freesurfer images in {png_dir}")
        create_fs_images(freesurfer, png_dir, downsample=downsample)

    logger.info(f"Creating pdf at {out_file}")
    create_pdf(png_dir, out_file, metadata)

    if not png_out_dir:
        temp_dir_obj.cleanup()


def main():
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=str, help="Path to dataset")
    parser.add_argument(
        "-o",
        "--out-file",
        type=str,
        help="Path to output pdf. Defaults to <input dir name>_mosaics.pdf in working directory.",
    )
    parser.add_argument(
        "--png-in-dir",
        type=str,
        help="Path to existing directory of .png files, bypassing creation of those from .nii files.",
    )
    parser.add_argument(
        "--png-out-dir",
        type=str,
        help="Path to directory to output .png slice images to, instead of creating a temp directory.",
    )
    parser.add_argument(
        "-m",
        "--metadata",
        type=str,
        help="JSON string to include as metadata at the end of the output file.",
    )
    parser.add_argument(
        "--no-anat",
        action="store_false",
        dest="anat",
        help="Do not include anatomical images.",
    )
    parser.add_argument(
        "--freesurfer",
        type=str,
        help="Path to freesurfer data.",
    )
    parser.add_argument(
        "--downsample",
        type=int,
        help="Factor by which to downsample images.",
    )
    parser.add_argument(
        "--max-img-height",
        type=int,
        help="Max height of images.",
    )
    parser.add_argument(
        "--max-img-width",
        type=int,
        help="Max width of images.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Set logging level to DEBUG.",
    )

    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    if args.max_img_height:
        global MAX_IMG_HEIGHT
        MAX_IMG_HEIGHT = args.max_img_height
    if args.max_img_width:
        global MAX_IMG_WIDTH
        MAX_IMG_WIDTH = args.max_img_width

    if args.out_file:
        out_file = args.out_file
    else:
        in_abs = os.path.abspath(args.dataset)
        out_file = os.path.basename(in_abs) + "_mosaic.pdf"

    if not args.png_in_dir:
        create_mosaic_pdf(
            args.dataset,
            out_file,
            anat=args.anat,
            png_out_dir=args.png_out_dir,
            downsample=args.downsample,
            freesurfer=args.freesurfer,
            metadata=args.metadata,
        )
    else:
        logger.info(f"Creating pdf at {out_file}")
        create_pdf(args.png_in_dir, out_file, args.metadata)


if __name__ == "__main__":
    main()
