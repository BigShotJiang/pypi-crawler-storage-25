from __future__ import annotations

import re
from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping

ParamValue = str | int | float | bool | None


@dataclass(frozen=True, slots=True)
class Dataset:
    name: str
    path: str
    plan: str | None
    event_col: str | None
    disclosure_col: str | None
    ignored_params: tuple[str, ...] = ()
    default_params: tuple[tuple[str, ParamValue], ...] = ()
    ttl_hours: int | None = None
    notes: str = ""

    def defaults(self) -> dict[str, ParamValue]:
        return dict(self.default_params)


_DATASETS: dict[str, Dataset] = {
    "congresstrading": Dataset(
        name="congresstrading",
        path="/beta/bulk/congresstrading",
        plan="hobbyist",
        event_col="Traded",
        disclosure_col="Filed",
        ignored_params=("date_from", "date_to"),
        notes=(
            "Congressional stock trades. Use available_at/Filed for "
            "point-in-time analysis; Traded is the event date. Pass "
            "version='V2' explicitly to opt into the V2 schema; default "
            "sends no version, matching the published API examples."
        ),
    ),
    "insiders": Dataset(
        name="insiders",
        path="/beta/live/insiders",
        plan="hobbyist",
        event_col="Date",
        disclosure_col="fileDate",
        default_params=(("limit_codes", True),),
        notes=(
            "Recent insider transactions. Date is the transaction date; "
            "fileDate is when the filing became available."
        ),
    ),
    "lobbying": Dataset(
        name="lobbying",
        path="/beta/historical/lobbying/SEARCHALL",
        plan="hobbyist",
        event_col="Date",
        disclosure_col=None,
        notes=(
            "Corporate lobbying search. The advertised schema exposes one "
            "Date column, so quiverfeed adds event_time but not available_at."
        ),
    ),
    "bill_summaries": Dataset(
        name="bill_summaries",
        path="/beta/live/billSummaries",
        plan="hobbyist",
        event_col="lastActionDate",
        disclosure_col=None,
        default_params=(("summary_limit", 5000),),
        notes=(
            "Recent congressional bill summaries. lastActionDate is modeled "
            "as event_time; no separate disclosure date is advertised."
        ),
    ),
    "politicians": Dataset(
        name="politicians",
        path="/beta/bulk/congress/politicians",
        plan="hobbyist",
        event_col=None,
        disclosure_col=None,
        notes=(
            "Roster of congressional traders, sortable by activity. Reference "
            "data, not an event stream — no event_time / available_at columns "
            "are added."
        ),
    ),
}

DATASETS: Mapping[str, Dataset] = MappingProxyType(_DATASETS)

# User-registered datasets via register_dataset(); they override built-ins on
# name collision so callers can patch a built-in entry whose schema has
# drifted upstream without forking the package.
_USER_DATASETS: dict[str, Dataset] = {}


def normalize_dataset_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


def all_datasets() -> dict[str, Dataset]:
    merged = dict(_DATASETS)
    merged.update(_USER_DATASETS)
    return merged


def register_dataset(dataset: Dataset, *, replace: bool = False) -> None:
    if not replace and dataset.name in _USER_DATASETS:
        raise ValueError(
            f"Dataset {dataset.name!r} already registered; pass replace=True "
            "to overwrite."
        )
    _USER_DATASETS[dataset.name] = dataset


def unregister_dataset(name: str) -> None:
    _USER_DATASETS.pop(name, None)


def get_dataset(name: str) -> Dataset | None:
    catalog = all_datasets()
    if name in catalog:
        return catalog[name]

    normalized = normalize_dataset_name(name)
    matches = [
        dataset
        for key, dataset in catalog.items()
        if normalize_dataset_name(key) == normalized
    ]
    if len(matches) == 1:
        return matches[0]
    return None
