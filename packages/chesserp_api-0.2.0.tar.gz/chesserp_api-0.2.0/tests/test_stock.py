"""Tests for get_stock, get_stock_raw, and date conversion."""

import pytest

from chesserp.services.inventory import InventoryService


BASE_URL = "http://test-api.local"
API_PATH = "/web/api/chess/v1/"
STOCK_URL = BASE_URL + API_PATH + "stock/"


def _make_stock_item(id_articulo: int, cant_bultos: float = 10.0):
    return {
        "fecha": None,
        "idDeposito": 1,
        "idAlmacen": 0,
        "idArticulo": id_articulo,
        "dsArticulo": f"Articulo {id_articulo}",
        "fecVtoLote": None,
        "cantBultos": cant_bultos,
        "cantUnidades": cant_bultos * 12,
    }


def _make_response(items: list):
    return {"dsStockFisicoApi": {"dsStock": items}}


class TestToDateConversion:
    """Tests for _to_ddmmyyyy static method."""

    def test_iso_to_ddmmyyyy(self):
        assert InventoryService._to_ddmmyyyy("2026-04-11") == "11-04-2026"

    def test_iso_to_ddmmyyyy_january(self):
        assert InventoryService._to_ddmmyyyy("2026-01-05") == "05-01-2026"

    def test_already_ddmmyyyy_passthrough(self):
        assert InventoryService._to_ddmmyyyy("11-04-2026") == "11-04-2026"

    def test_empty_string(self):
        assert InventoryService._to_ddmmyyyy("") == ""

    def test_other_format_passthrough(self):
        assert InventoryService._to_ddmmyyyy("04/11/2026") == "04/11/2026"


class TestGetStockRaw:
    """Tests for inventory.get_stock_raw."""

    def test_returns_full_api_dict(self, mock_api, client):
        items = [_make_stock_item(1), _make_stock_item(2)]
        mock_api.get(STOCK_URL, json=_make_response(items))

        result = client.inventory.get_stock_raw(id_deposito=1)
        assert "dsStockFisicoApi" in result
        assert len(result["dsStockFisicoApi"]["dsStock"]) == 2

    def test_fecha_iso_converted(self, mock_api, client):
        mock_api.get(STOCK_URL, json=_make_response([]))

        client.inventory.get_stock_raw(id_deposito=1, fecha="2026-04-11")
        assert "fechastock=11-04-2026" in mock_api.last_request.url

    def test_fecha_ddmmyyyy_passthrough(self, mock_api, client):
        mock_api.get(STOCK_URL, json=_make_response([]))

        client.inventory.get_stock_raw(id_deposito=1, fecha="11-04-2026")
        assert "fechastock=11-04-2026" in mock_api.last_request.url

    def test_no_fecha_sends_empty(self, mock_api, client):
        mock_api.get(STOCK_URL, json=_make_response([]))

        client.inventory.get_stock_raw(id_deposito=1)
        assert "fechastock=" in mock_api.last_request.url

    def test_frescura_false_not_sent(self, mock_api, client):
        mock_api.get(STOCK_URL, json=_make_response([]))

        client.inventory.get_stock_raw(id_deposito=1, frescura=False)
        assert "frescura" not in mock_api.last_request.url

    def test_frescura_true_sent(self, mock_api, client):
        mock_api.get(STOCK_URL, json=_make_response([]))

        client.inventory.get_stock_raw(id_deposito=1, frescura=True)
        assert "frescura=true" in mock_api.last_request.url


class TestGetStock:
    """Tests for inventory.get_stock."""

    def test_returns_raw_dicts(self, mock_api, client):
        items = [_make_stock_item(1), _make_stock_item(2), _make_stock_item(3)]
        mock_api.get(STOCK_URL, json=_make_response(items))

        result = client.inventory.get_stock(id_deposito=1, raw=True)
        assert len(result) == 3
        assert result[0]["idArticulo"] == 1

    def test_returns_pydantic_models(self, mock_api, client):
        from chesserp.models.inventory import StockFisico

        items = [_make_stock_item(10)]
        mock_api.get(STOCK_URL, json=_make_response(items))

        result = client.inventory.get_stock(id_deposito=1)
        assert len(result) == 1
        assert isinstance(result[0], StockFisico)
        assert result[0].id_articulo == 10

    def test_empty_response(self, mock_api, client):
        mock_api.get(STOCK_URL, json={"dsStockFisicoApi": {}})

        result = client.inventory.get_stock(id_deposito=1, raw=True)
        assert result == [] or result is None

    def test_fecha_passed_to_raw(self, mock_api, client):
        mock_api.get(STOCK_URL, json=_make_response([_make_stock_item(1)]))

        client.inventory.get_stock(id_deposito=1, fecha="2026-04-11", raw=True)
        assert "fechastock=11-04-2026" in mock_api.last_request.url

    def test_frescura_passed_to_raw(self, mock_api, client):
        mock_api.get(STOCK_URL, json=_make_response([_make_stock_item(1)]))

        client.inventory.get_stock(id_deposito=1, frescura=True, raw=True)
        assert "frescura=true" in mock_api.last_request.url
