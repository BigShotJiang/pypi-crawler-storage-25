"""
liquid-harness
A fine-tuning tool for foundation models by Liquid AI
"""


def liquid_harness() -> str:
    """Placeholder function that returns the package name."""
    return "liquid-harness"
