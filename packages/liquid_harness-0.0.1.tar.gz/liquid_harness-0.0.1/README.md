# liquid-harness

A fine-tuning tool for foundation models by Liquid AI

## Installation

```bash
pip install liquid-harness
```

Or with uv:

```bash
uv add liquid-harness
```

## Usage

```python
from liquid_harness import liquid_harness

print(liquid_harness())
# => 'liquid-harness'
```

## License

MIT &copy; 2026 Liquid AI
