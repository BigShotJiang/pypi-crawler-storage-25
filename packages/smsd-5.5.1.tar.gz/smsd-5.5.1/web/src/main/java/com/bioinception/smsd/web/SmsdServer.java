/*
 * SPDX-License-Identifier: Apache-2.0
 * © 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd.web;

import io.javalin.Javalin;
import io.javalin.http.staticfiles.Location;

/**
 * SMSD Web Server — lightweight Javalin-based REST API + PWA frontend.
 * Single JAR, single command: {@code java -jar smsd-web.jar}
 *
 * @author Syed Asad Rahman
 */
public class SmsdServer {

    public static final int DEFAULT_PORT = 7070;

    public static void main(String[] args) {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        Javalin app = Javalin.create(config -> {
            config.staticFiles.add("/static", Location.CLASSPATH);
            config.http.defaultContentType = "application/json";
        });

        ApiHandler api = new ApiHandler();

        // Molecule validation & properties
        app.post("/api/validate", api::validate);

        // Depiction (2D SVG rendering)
        app.get("/api/depict", api::depict);

        // Substructure search
        app.post("/api/sub", api::substructure);

        // MCS search
        app.post("/api/mcs", api::mcs);

        // Export
        app.post("/api/export", api::export);

        app.start(port);

        int cpus = Runtime.getRuntime().availableProcessors();
        System.out.println("SMSD Java web server");
        System.out.println("  backend  Java " + System.getProperty("java.version") + " / CDK 2.11");
        System.out.println("  threads  " + cpus + " available processors");
        System.out.println("  URL      http://localhost:" + port);
    }
}
