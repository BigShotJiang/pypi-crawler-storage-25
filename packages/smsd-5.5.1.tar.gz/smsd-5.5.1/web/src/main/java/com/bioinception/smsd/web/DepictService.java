/*
 * SPDX-License-Identifier: Apache-2.0
 * © 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd.web;

import org.openscience.cdk.depict.Depiction;
import org.openscience.cdk.depict.DepictionGenerator;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IBond;
import org.openscience.cdk.interfaces.IChemObject;
import org.openscience.cdk.layout.StructureDiagramGenerator;
import org.openscience.cdk.silent.SilentChemObjectBuilder;
import org.openscience.cdk.smiles.SmilesParser;
import org.openscience.cdk.tools.manipulator.AtomContainerManipulator;
import org.openscience.cdk.tools.manipulator.MolecularFormulaManipulator;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.*;

/**
 * High-quality 2D molecule depiction with atom/bond highlighting.
 * Supports SVG, PNG, PDF, EPS output for publication-grade images.
 *
 * @author Syed Asad Rahman
 */
public class DepictService {

    private static final SmilesParser SP = new SmilesParser(SilentChemObjectBuilder.getInstance());
    private static final StructureDiagramGenerator SDG = new StructureDiagramGenerator();

    // Publication-quality highlight colors (semi-transparent for overlay)
    public static final Color QUERY_COLOR  = new Color(41, 98, 255, 80);    // blue
    public static final Color TARGET_COLOR = new Color(213, 0, 0, 80);      // red
    public static final Color MCS_COLOR    = new Color(0, 150, 60, 80);     // green
    public static final Color MATCH_COLOR  = new Color(255, 171, 0, 80);    // amber

    /** Supported output formats. */
    public enum Format { SVG, PNG, PDF, EPS }

    /** Parse SMILES and generate 2D coordinates. */
    public static IAtomContainer parseAndLayout(String smiles) throws Exception {
        IAtomContainer mol = SP.parseSmiles(smiles);
        AtomContainerManipulator.percieveAtomTypesAndConfigureAtoms(mol);
        synchronized (SDG) {
            SDG.setMolecule(mol, false);
            SDG.generateCoordinates();
            return SDG.getMolecule();
        }
    }

    /**
     * Create a publication-quality DepictionGenerator.
     *
     * @param width       width in pixels
     * @param height      height in pixels
     * @param showNumbers show atom index numbers
     * @param zoom        zoom factor (2.0 = double size, good for print)
     */
    public static DepictionGenerator createGenerator(int width, int height,
                                                      boolean showNumbers, double zoom) {
        DepictionGenerator dg = new DepictionGenerator()
                .withSize(width, height)
                .withAtomColors()
                .withBackgroundColor(Color.WHITE)
                .withAromaticDisplay()
                .withMargin(15)
                .withPadding(8)
                .withZoom(zoom)
                .withFillToFit();

        if (showNumbers) dg = dg.withAtomNumbers().withAnnotationScale(0.6);
        return dg;
    }

    /**
     * Apply atom/bond highlighting to a generator.
     *
     * @param dg             base generator
     * @param mol            molecule
     * @param highlightAtoms atom indices to highlight (may be null)
     * @param color          highlight color
     * @return generator with highlights applied
     */
    public static DepictionGenerator applyHighlights(DepictionGenerator dg, IAtomContainer mol,
                                                      Set<Integer> highlightAtoms, Color color) {
        if (highlightAtoms == null || highlightAtoms.isEmpty()) return dg;
        List<IChemObject> hlObjects = new ArrayList<>();
        for (int idx : highlightAtoms) hlObjects.add(mol.getAtom(idx));
        for (IBond bond : mol.bonds()) {
            int a = mol.indexOf(bond.getAtom(0));
            int b = mol.indexOf(bond.getAtom(1));
            if (highlightAtoms.contains(a) && highlightAtoms.contains(b)) hlObjects.add(bond);
        }
        return dg.withHighlight(hlObjects, color).withOuterGlowHighlight(4.0);
    }

    /** Render molecule as SVG string. */
    public static String depictSvg(IAtomContainer mol, Set<Integer> highlightAtoms,
                                    Color color, int width, int height,
                                    boolean showNumbers) throws Exception {
        DepictionGenerator dg = createGenerator(width, height, showNumbers, 2.0);
        dg = applyHighlights(dg, mol, highlightAtoms, color);
        return dg.depict(mol).toSvgStr();
    }

    /** Render molecule as PNG bytes. */
    public static byte[] depictPng(IAtomContainer mol, Set<Integer> highlightAtoms,
                                    Color color, int width, int height,
                                    boolean showNumbers) throws Exception {
        DepictionGenerator dg = createGenerator(width, height, showNumbers, 3.0);
        dg = applyHighlights(dg, mol, highlightAtoms, color);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        dg.depict(mol).writeTo(Depiction.PNG_FMT, baos);
        return baos.toByteArray();
    }

    /** Render molecule as PDF bytes. */
    public static byte[] depictPdf(IAtomContainer mol, Set<Integer> highlightAtoms,
                                    Color color, int width, int height,
                                    boolean showNumbers) throws Exception {
        DepictionGenerator dg = createGenerator(width, height, showNumbers, 3.0);
        dg = applyHighlights(dg, mol, highlightAtoms, color);
        return dg.depict(mol).toPdf();
    }

    /** Write depiction to file in any format. */
    public static void depictToFile(IAtomContainer mol, Set<Integer> highlightAtoms,
                                     Color color, int width, int height,
                                     boolean showNumbers, Format format,
                                     String filePath) throws Exception {
        DepictionGenerator dg = createGenerator(width, height, showNumbers, 3.0);
        dg = applyHighlights(dg, mol, highlightAtoms, color);
        Depiction dep = dg.depict(mol);
        switch (format) {
            case SVG: dep.writeTo(Depiction.SVG_FMT, new File(filePath)); break;
            case PNG: dep.writeTo(Depiction.PNG_FMT, new File(filePath)); break;
            case PDF: dep.writeTo(Depiction.PDF_FMT, new File(filePath)); break;
            case EPS: dep.writeTo(Depiction.EPS_FMT, new File(filePath)); break;
        }
    }

    /** Convenience: render SMILES as SVG string. */
    public static String depictSmiles(String smiles, Set<Integer> highlightAtoms,
                                       Color color, int width, int height,
                                       boolean showNumbers) throws Exception {
        return depictSvg(parseAndLayout(smiles), highlightAtoms, color, width, height, showNumbers);
    }

    /** Compute molecular properties. */
    public static Map<String, Object> computeProperties(IAtomContainer mol) {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("atomCount", mol.getAtomCount());
        props.put("bondCount", mol.getBondCount());
        try {
            var formula = MolecularFormulaManipulator.getMolecularFormula(mol);
            props.put("formula", MolecularFormulaManipulator.getString(formula));
            props.put("mass", Math.round(MolecularFormulaManipulator.getMass(formula) * 100.0) / 100.0);
        } catch (Exception e) {
            props.put("formula", "?");
            props.put("mass", 0);
        }
        int ringAtoms = 0, aromaticAtoms = 0;
        for (int i = 0; i < mol.getAtomCount(); i++) {
            if (mol.getAtom(i).isInRing()) ringAtoms++;
            if (mol.getAtom(i).isAromatic()) aromaticAtoms++;
        }
        props.put("ringAtoms", ringAtoms);
        props.put("aromaticAtoms", aromaticAtoms);
        return props;
    }
}
