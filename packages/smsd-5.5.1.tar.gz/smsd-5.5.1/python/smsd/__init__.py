"""
SMSD -- Substructure & Maximum Common Substructure search for chemical graphs.

Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs.
Licensed under Apache 2.0.

Quick start::

    from smsd import parse_smiles, find_mcs, is_substructure, similarity

    benzene = parse_smiles("c1ccccc1")
    phenol  = parse_smiles("c1ccc(O)cc1")

    assert is_substructure(benzene, phenol)

    mcs = find_mcs(benzene, phenol)
    print(f"MCS size: {len(mcs)}")

    sim = similarity(benzene, phenol)
    print(f"Similarity: {sim:.3f}")
"""

__version__ = "5.3.1"
__author__ = "Syed Asad Rahman"

from smsd._smsd import (
    # Types
    ChemOptions,
    McsOptions,
    MolGraph,
    MolGraphBuilder,
    # Enums
    BondOrderMode,
    AromaticityMode,
    RingFusionMode,
    # SMILES / SMARTS
    parse_smiles,
    to_smiles,
    to_smarts,
    # Substructure
    is_substructure,
    find_substructure,
    # MCS
    find_mcs,
    # RASCAL
    similarity_upper_bound,
    screen_targets,
    # Fingerprints
    path_fingerprint,
    mcs_fingerprint,
    fingerprint_subset,
    analyze_fp_quality,
    # GPU / compute backend query (CUDA on Linux/Windows, Metal on macOS)
    gpu_is_available,
    gpu_device_info,
)


# ---------------------------------------------------------------------------
# Convenience helpers that wrap the raw C++ bindings with Pythonic defaults
# ---------------------------------------------------------------------------

def similarity(mol1, mol2):
    """Compute RASCAL similarity upper bound between two molecules.

    Accepts either MolGraph objects or SMILES strings.

    Returns:
        float: Tanimoto-like similarity in [0.0, 1.0].
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    return similarity_upper_bound(g1, g2)


def mcs(mol1, mol2, *, tautomer_aware=False, timeout_ms=10000, **kwargs):
    """Find Maximum Common Substructure between two molecules.

    Accepts either MolGraph objects or SMILES strings.

    Args:
        mol1: First molecule (MolGraph or SMILES string).
        mol2: Second molecule (MolGraph or SMILES string).
        tautomer_aware: Use tautomer-aware matching.
        timeout_ms: Timeout in milliseconds.
        **kwargs: Additional McsOptions fields (e.g. connected_only=False).

    Returns:
        dict: Mapping from mol1 atom indices to mol2 atom indices.
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    chem = ChemOptions.tautomer_profile() if tautomer_aware else ChemOptions()
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return find_mcs(g1, g2, chem, opts)


def substructure_search(query, target, *, timeout_ms=10000):
    """Find a substructure mapping of query in target.

    Accepts either MolGraph objects or SMILES strings.

    Returns:
        list: List of (query_atom, target_atom) pairs, or empty list if not
        a substructure.
    """
    q = _ensure_mol(query)
    t = _ensure_mol(target)
    return find_substructure(q, t, ChemOptions(), timeout_ms)


def fingerprint(mol, *, kind="mcs", path_length=7, fp_size=2048):
    """Compute a molecular fingerprint.

    Args:
        mol: MolGraph or SMILES string.
        kind: "path" for simple path fingerprint, "mcs" for MCS-aware.
        path_length: Maximum bond path length (default 7).
        fp_size: Fingerprint size in bits (default 2048).

    Returns:
        list[int]: Sorted list of set bit positions.
    """
    g = _ensure_mol(mol)
    if kind == "path":
        return path_fingerprint(g, path_length, fp_size)
    elif kind == "mcs":
        return mcs_fingerprint(g, path_length, fp_size)
    else:
        raise ValueError(f"Unknown fingerprint kind: {kind!r}. Use 'path' or 'mcs'.")


def tanimoto(fp1, fp2, fp_size=2048):
    """Compute Tanimoto coefficient between two fingerprints.

    Args:
        fp1: List of set bit positions (from fingerprint()).
        fp2: List of set bit positions (from fingerprint()).
        fp_size: Fingerprint size in bits.

    Returns:
        float: Tanimoto similarity in [0.0, 1.0].
    """
    s1 = set(fp1)
    s2 = set(fp2)
    intersection = len(s1 & s2)
    union = len(s1 | s2)
    if union == 0:
        return 1.0
    return intersection / union


def batch_substructure(query, targets, *, timeout_ms=10000):
    """Check whether query is a substructure of each molecule in targets.

    Automatically dispatches to multi-core OpenMP via the C++ extension.
    Pass pre-parsed MolGraph objects for best performance (avoids per-call
    SMILES parsing).

    Args:
        query:      MolGraph or SMILES string.
        targets:    List of MolGraph or SMILES strings.
        timeout_ms: Per-pair timeout in milliseconds.

    Returns:
        list[bool]: True at index i when query is a substructure of targets[i].
    """
    from smsd._smsd import batch_substructure as _batch_sub  # type: ignore[import]
    q = _ensure_mol(query)
    ts = [_ensure_mol(t) for t in targets]
    return _batch_sub(q, ts, ChemOptions(), timeout_ms)


def batch_mcs(query, targets, *, timeout_ms=10000, **kwargs):
    """Compute MCS between query and every molecule in targets in parallel.

    Dispatches to multi-core OpenMP automatically.

    Args:
        query:      MolGraph or SMILES string.
        targets:    List of MolGraph or SMILES strings.
        timeout_ms: Per-pair timeout in milliseconds.
        **kwargs:   Extra McsOptions fields (e.g. connected_only=False).

    Returns:
        list[dict]: MCS atom mappings (query → target index) for each target.
    """
    from smsd._smsd import batch_mcs as _batch_mcs  # type: ignore[import]
    q = _ensure_mol(query)
    ts = [_ensure_mol(t) for t in targets]
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return _batch_mcs(q, ts, ChemOptions(), opts)


def _ensure_mol(obj):
    """Convert a SMILES string to MolGraph, or return MolGraph as-is."""
    if isinstance(obj, str):
        return parse_smiles(obj)
    if isinstance(obj, MolGraph):
        return obj
    raise TypeError(
        f"Expected MolGraph or SMILES string, got {type(obj).__name__}"
    )


__all__ = [
    # Types
    "ChemOptions",
    "McsOptions",
    "MolGraph",
    "MolGraphBuilder",
    # Enums
    "BondOrderMode",
    "AromaticityMode",
    "RingFusionMode",
    # SMILES / SMARTS
    "parse_smiles",
    "to_smiles",
    "to_smarts",
    # Substructure
    "is_substructure",
    "find_substructure",
    "substructure_search",
    # MCS
    "find_mcs",
    "mcs",
    # Similarity
    "similarity",
    "similarity_upper_bound",
    "screen_targets",
    # Fingerprints
    "fingerprint",
    "path_fingerprint",
    "mcs_fingerprint",
    "fingerprint_subset",
    "analyze_fp_quality",
    "tanimoto",
    # Parallel batch
    "batch_substructure",
    "batch_mcs",
    # GPU / compute backend
    "gpu_is_available",
    "gpu_device_info",
]
