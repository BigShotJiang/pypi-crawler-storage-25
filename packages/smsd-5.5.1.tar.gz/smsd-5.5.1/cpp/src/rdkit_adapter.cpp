/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * RDKit adapter: converts RDKit ROMol to SMSD MolGraph.
 * This is the ONLY file that depends on RDKit.
 * The core algorithms (mol_graph.hpp, vf2pp.hpp, mcs.hpp) are RDKit-free.
 */

#ifdef SMSD_WITH_RDKIT

#include "smsd/mol_graph.hpp"
#include <GraphMol/GraphMol.h>
#include <GraphMol/SmilesParse/SmilesParse.h>
#include <GraphMol/MolOps.h>
#include <GraphMol/RingInfo.h>
#include <memory>
#include <stdexcept>

namespace smsd {

/// Convert an RDKit ROMol to an SMSD MolGraph.
/// Strips explicit hydrogens by default.
MolGraph fromRDKit(const RDKit::ROMol& mol, bool removeHs = true) {
    // Optionally remove Hs
    std::unique_ptr<RDKit::RWMol> molCopy;
    const RDKit::ROMol* m = &mol;
    if (removeHs) {
        molCopy.reset(new RDKit::RWMol(mol));
        RDKit::MolOps::removeHs(*molCopy);
        m = molCopy.get();
    }

    int n = m->getNumAtoms();
    MolGraph g;
    g.n = n;
    g.atomicNum.resize(n);
    g.formalCharge.resize(n);
    g.aromatic.resize(n);
    g.ring.resize(n);
    g.degree.resize(n);
    g.label.resize(n);
    g.massNumber.resize(n, 0);
    g.neighbors.resize(n);

    // Ring info
    RDKit::MolOps::findSSSR(*const_cast<RDKit::ROMol*>(m));
    const auto* ri = m->getRingInfo();

    for (int i = 0; i < n; ++i) {
        const auto* atom = m->getAtomWithIdx(i);
        g.atomicNum[i] = atom->getAtomicNum();
        g.formalCharge[i] = atom->getFormalCharge();
        g.aromatic[i] = atom->getIsAromatic();
        g.ring[i] = ri->numAtomRings(i) > 0;
        g.massNumber[i] = atom->getIsotope();
        g.label[i] = (g.atomicNum[i] << 2) | (g.aromatic[i] ? 2 : 0) | (g.ring[i] ? 1 : 0);
    }

    // Build adjacency
    for (const auto& bond : m->bonds()) {
        int a = bond->getBeginAtomIdx();
        int b = bond->getEndAtomIdx();
        g.neighbors[a].push_back(b);
        g.neighbors[b].push_back(a);
    }
    for (int i = 0; i < n; ++i) g.degree[i] = static_cast<int>(g.neighbors[i].size());

    // Bond matrices
    g.initBondMatrices(*m);
    g.initDerived();

    return g;
}

/// Parse SMILES string to MolGraph.
MolGraph fromSmiles(const std::string& smiles) {
    std::unique_ptr<RDKit::RWMol> mol(RDKit::SmilesToMol(smiles));
    if (!mol) throw std::invalid_argument("Failed to parse SMILES: " + smiles);
    return fromRDKit(*mol);
}

} // namespace smsd

#endif // SMSD_WITH_RDKIT
