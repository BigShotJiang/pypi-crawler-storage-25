/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * GPU / Metal integration tests.
 * Only compiled when SMSD is built with SMSD_ENABLE_CUDA or SMSD_ENABLE_METAL.
 *
 * Tests:
 *   1. gpu::isAvailable() — runtime detection is consistent with device info.
 *   2. gpu::deviceInfo()  — non-empty, contains "GPU:" or "CPU:" or "Metal".
 *   3. batchRascalScreenAuto() correctness — same results as CPU reference.
 *   4. Zero-molecule edge case.
 *   5. Threshold filtering.
 */

#include "smsd/gpu.hpp"
#include "smsd/smiles_parser.hpp"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Tiny test framework
// ---------------------------------------------------------------------------

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, msg)                                           \
    do {                                                           \
        if (cond) {                                                \
            ++g_pass;                                              \
        } else {                                                   \
            ++g_fail;                                              \
            std::fprintf(stderr, "FAIL  %s  (%s:%d)\n",           \
                         (msg), __FILE__, __LINE__);               \
        }                                                          \
    } while (0)

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

static smsd::MolGraph parse(const char* smi) {
    return smsd::parseSMILES(smi);
}

// Collect screen hits above threshold, sorted by index.
static std::vector<smsd::gpu::ScreenHit> screen(
    const smsd::MolGraph&              q,
    const std::vector<smsd::MolGraph>& ts,
    double                             threshold = 0.0)
{
    auto hits = smsd::gpu::batchRascalScreenAuto(q, ts, threshold);
    std::sort(hits.begin(), hits.end(),
              [](const smsd::gpu::ScreenHit& a, const smsd::gpu::ScreenHit& b) {
                  return a.index < b.index;
              });
    return hits;
}

// CPU reference: similarityUpperBound for every target.
static std::vector<double> cpu_ref(
    const smsd::MolGraph&              q,
    const std::vector<smsd::MolGraph>& ts)
{
    std::vector<double> r;
    r.reserve(ts.size());
    for (auto& t : ts)
        r.push_back(smsd::similarityUpperBound(q, t));
    return r;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

static void test_device_info() {
    std::string info = smsd::gpu::deviceInfo();
    CHECK(!info.empty(), "deviceInfo() non-empty");

    bool ok = info.find("GPU:")    != std::string::npos
           || info.find("CPU:")    != std::string::npos
           || info.find("Metal")   != std::string::npos;
    CHECK(ok, "deviceInfo() contains GPU/CPU/Metal prefix");

    std::printf("  deviceInfo: %s\n", info.c_str());
    std::printf("  isAvailable: %s\n", smsd::gpu::isAvailable() ? "true" : "false");
}

static void test_correctness_small() {
    // 6 small molecules
    const std::vector<std::string> smiles = {
        "c1ccccc1",          // benzene
        "Oc1ccccc1",         // phenol
        "CC(=O)Oc1ccccc1C(=O)O", // aspirin
        "C",                 // methane
        "CC",                // ethane
        "c1ccc2ccccc2c1",    // naphthalene
    };

    std::vector<smsd::MolGraph> mols;
    for (auto& s : smiles) mols.push_back(parse(s.c_str()));

    auto query = parse("c1ccccc1");  // benzene

    auto hits = screen(query, mols, 0.0);
    auto ref  = cpu_ref(query, mols);

    // All 6 targets should appear at threshold 0.
    CHECK(hits.size() == mols.size(), "all targets returned at threshold=0");

    // GPU scores should be close to CPU reference (float vs double precision).
    bool scores_match = true;
    for (auto& h : hits) {
        double diff = std::abs(h.score - ref[h.index]);
        if (diff > 0.02) {   // 2% tolerance for float vs double
            scores_match = false;
            std::fprintf(stderr, "  score mismatch at index %d: gpu=%.4f cpu=%.4f\n",
                         h.index, h.score, ref[h.index]);
        }
    }
    CHECK(scores_match, "GPU scores match CPU reference (2% tolerance)");
}

static void test_threshold_filtering() {
    std::vector<smsd::MolGraph> targets = {
        parse("c1ccccc1"),            // benzene — identical to query, score=1
        parse("C"),                   // methane — very different, score≈0
        parse("c1ccc2ccccc2c1"),      // naphthalene — similar, score≈0.67
    };
    auto query = parse("c1ccccc1");

    // Threshold 0.5 should keep benzene and naphthalene, drop methane.
    auto hits = screen(query, targets, 0.5);
    bool has_benzene     = false;
    bool has_naphthalene = false;
    bool has_methane     = false;
    for (auto& h : hits) {
        if (h.index == 0) has_benzene     = true;
        if (h.index == 1) has_methane     = true;
        if (h.index == 2) has_naphthalene = true;
    }
    CHECK(has_benzene,      "threshold=0.5: benzene included");
    CHECK(has_naphthalene,  "threshold=0.5: naphthalene included");
    CHECK(!has_methane,     "threshold=0.5: methane excluded");
}

static void test_empty_targets() {
    auto query = parse("c1ccccc1");
    std::vector<smsd::MolGraph> empty;
    auto hits = screen(query, empty, 0.0);
    CHECK(hits.empty(), "empty targets → empty hits");
}

static void test_self_match() {
    auto mol = parse("CC(C)Cc1ccc(CC(C)C(=O)O)cc1");  // ibuprofen
    auto hits = screen(mol, {mol}, 0.0);
    CHECK(hits.size() == 1, "self-match returns 1 hit");
    if (!hits.empty())
        CHECK(std::abs(hits[0].score - 1.0) < 0.01, "self-match score ≈ 1.0");
}

static void test_large_batch() {
    // 500 copies of various molecules — exercises thread-group scheduling.
    std::vector<std::string> pool = {
        "c1ccccc1", "Oc1ccccc1", "CC(=O)O", "c1ccncc1", "C1CCCCC1",
        "CC(C)C",   "CCCO",      "c1ccc(O)cc1", "CCCCC",  "c1ccc2ccccc2c1",
    };
    std::vector<smsd::MolGraph> targets;
    targets.reserve(500);
    for (int i = 0; i < 500; ++i)
        targets.push_back(parse(pool[i % pool.size()].c_str()));

    auto query = parse("c1ccccc1");
    auto hits  = screen(query, targets, 0.0);
    CHECK(hits.size() == 500, "large batch: 500 hits at threshold=0");
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

int main() {
    std::printf("=== SMSD GPU / Metal tests ===\n");

    test_device_info();
    test_correctness_small();
    test_threshold_filtering();
    test_empty_targets();
    test_self_match();
    test_large_batch();

    std::printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
