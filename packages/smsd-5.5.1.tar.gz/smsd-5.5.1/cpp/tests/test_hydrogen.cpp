/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * C++ tests for implicit / explicit hydrogen handling in SMSD.
 *
 * Key invariants tested
 * ---------------------
 * 1. Implicit-H SMILES and bracket-H SMILES give the same heavy-atom MCS.
 * 2. Explicit [H] atoms written as graph nodes are real atoms — a 5-node
 *    explicit-H methane cannot be substructure of a 1-node implicit methane.
 * 3. [CH4], C, and [C@@H] all parse to the same single heavy-atom.
 * 4. H-count normalisation does not affect ring or aromaticity perception.
 * 5. Formal charge and H count are orthogonal.
 */

#include "smsd/smsd.hpp"
#include "smsd/smiles_parser.hpp"
#include <cassert>
#include <iostream>
#include <stdexcept>

static int sPassed = 0, sFailed = 0;

#define RUN_TEST(name) do { \
    std::cout << "  [" #name "] "; \
    try { test_##name(); sPassed++; std::cout << "PASS\n"; } \
    catch (const std::exception& e) { sFailed++; std::cout << "FAIL: " << e.what() << "\n"; } \
    catch (...) { sFailed++; std::cout << "FAIL (unknown)\n"; } \
} while(0)

static smsd::McsOptions defaultMcsOpts() {
    smsd::McsOptions o;
    o.timeoutMs = 10000;
    return o;
}

static int mcsSize(const std::string& smi1, const std::string& smi2,
                   smsd::ChemOptions chem = smsd::ChemOptions{}) {
    auto g1 = smsd::parseSMILES(smi1);
    auto g2 = smsd::parseSMILES(smi2);
    auto m  = smsd::findMCS(g1, g2, chem, defaultMcsOpts());
    return static_cast<int>(m.size());
}

static bool isSub(const std::string& query, const std::string& target,
                  smsd::ChemOptions chem = smsd::ChemOptions{}) {
    auto q = smsd::parseSMILES(query);
    auto t = smsd::parseSMILES(target);
    return smsd::isSubstructure(q, t, chem, 10000);
}

// ============================================================================
// 1. Implicit-H normalisation
// ============================================================================

// [CH4] and C both parse to a single-carbon heavy-atom graph
void test_methane_implicit_vs_bracket() {
    assert(isSub("[CH4]", "C"));
    assert(isSub("C", "[CH4]"));
    int sz = mcsSize("C", "[CH4]");
    std::cout << "mcs=" << sz << " ";
    assert(sz == 1);
}

// Benzene with aromatic [cH] notation vs implicit aromaticity
void test_benzene_bracketed_aromatic_h() {
    int sz = mcsSize("c1ccccc1", "[cH]1[cH][cH][cH][cH][cH]1");
    std::cout << "mcs=" << sz << " ";
    assert(sz == 6);
}

// [CH3][CH2][OH] vs CCO — same 3-atom ethanol skeleton
void test_ethanol_bracket_vs_implicit() {
    int sz = mcsSize("CCO", "[CH3][CH2][OH]");
    std::cout << "mcs=" << sz << " ";
    assert(sz == 3);
}

// Aspirin with one [CH3] bracket — still 13-atom heavy skeleton
void test_aspirin_bracket_notation() {
    int sz = mcsSize(
        "CC(=O)Oc1ccccc1C(=O)O",
        "[CH3]C(=O)Oc1ccccc1C(=O)O"
    );
    std::cout << "mcs=" << sz << " ";
    assert(sz == 13);
}

// [OH2] and O are the same water molecule
void test_water_OH2_vs_implicit() {
    assert(isSub("O",     "[OH2]"));
    assert(isSub("[OH2]", "O"));
    std::cout << "both_ways=ok ";
}

// ============================================================================
// 2. Explicit [H] as graph nodes
// ============================================================================

// [H]C([H])([H])[H] has 5 atoms (C + 4×H)
void test_explicit_H_methane_atom_count() {
    auto mol = smsd::parseSMILES("[H]C([H])([H])[H]");
    std::cout << "n=" << mol.n << " ";
    assert(mol.n == 5);
}

// 5-atom explicit-H methane cannot be substructure of 1-atom implicit methane
void test_explicit_H_query_no_match_implicit_target() {
    bool sub = isSub("[H]C([H])([H])[H]", "C");
    std::cout << "sub=" << (sub ? "true" : "false") << " ";
    assert(!sub);
}

// [H]O[H] (3-atom) vs O (1-atom) — MCS is just the oxygen
void test_explicit_H_water_mcs_heavy_only() {
    int sz = mcsSize("[H]O[H]", "O");
    std::cout << "mcs=" << sz << " ";
    assert(sz == 1);
}

// Hydrogen molecule [H][H] matches itself
void test_H2_self_match() {
    assert(isSub("[H][H]", "[H][H]"));
    std::cout << "ok ";
}

// ============================================================================
// 3. H-count notation does not affect ring / aromaticity
// ============================================================================

// Cyclohexane with [CH2] brackets vs implicit — 6-atom MCS
void test_cyclohexane_CH2_notation() {
    int sz = mcsSize("C1CCCCC1", "[CH2]1[CH2][CH2][CH2][CH2][CH2]1");
    std::cout << "mcs=" << sz << " ";
    assert(sz == 6);
}

// Caffeine vs theophylline — [nH] notation must not shrink MCS
void test_caffeine_theophylline_nH() {
    int sz = mcsSize(
        "Cn1cnc2c1c(=O)n(C)c(=O)n2C",
        "Cn1cnc2c1c(=O)[nH]c(=O)n2C"
    );
    std::cout << "mcs=" << sz << " ";
    assert(sz >= 11);
}

// ============================================================================
// 4. Drug-like molecules
// ============================================================================

// Morphine — stereo/H notation variants must give same heavy-atom MCS
void test_morphine_stereo_h_notation() {
    int sz = mcsSize(
        "CN1CCC23C4C1CC5=C(C2C(C=C4)O3)C=C(C=C5)O",
        "C[N]1CC[C@@]23[C@@H]4[C@H]1C[C@@H]5=C([C@@H]2[C@H](C=C4)O3)C=C(C=C5)O"
    );
    std::cout << "mcs=" << sz << " ";
    assert(sz >= 17);
}

// Ibuprofen — [C@@H] stereo bracket must not shrink MCS
void test_ibuprofen_stereo_bracket() {
    int sz = mcsSize(
        "CC(C)Cc1ccc(CC(C)C(=O)O)cc1",
        "[CH3][C@@H]([CH3])Cc1ccc(CC(C)C(=O)O)cc1"
    );
    std::cout << "mcs=" << sz << " ";
    assert(sz >= 12);
}

// ============================================================================
// 5. Formal charge orthogonality
// ============================================================================

// NH4+ vs NH3 — MCS is the single nitrogen (charge ignored)
void test_ammonium_vs_ammonia_no_charge() {
    smsd::ChemOptions chem;
    chem.matchFormalCharge = false;
    int sz = mcsSize("N", "[NH4+]", chem);
    std::cout << "mcs=" << sz << " ";
    assert(sz == 1);
}

// CC(=O)[O-] vs CC(=O)O — 4-atom skeleton charge-agnostic
void test_carboxylate_vs_acid_no_charge() {
    smsd::ChemOptions chem;
    chem.matchFormalCharge = false;
    int sz = mcsSize("CC(=O)[O-]", "CC(=O)O", chem);
    std::cout << "mcs=" << sz << " ";
    assert(sz == 4);
}

// ============================================================================
// main
// ============================================================================

int main() {
    std::cout << "=== SMSD C++ Hydrogen Handling Tests ===\n\n";

    std::cout << "-- 1. Implicit-H normalisation --\n";
    RUN_TEST(methane_implicit_vs_bracket);
    RUN_TEST(benzene_bracketed_aromatic_h);
    RUN_TEST(ethanol_bracket_vs_implicit);
    RUN_TEST(aspirin_bracket_notation);
    RUN_TEST(water_OH2_vs_implicit);

    std::cout << "\n-- 2. Explicit [H] as graph nodes --\n";
    RUN_TEST(explicit_H_methane_atom_count);
    RUN_TEST(explicit_H_query_no_match_implicit_target);
    RUN_TEST(explicit_H_water_mcs_heavy_only);
    RUN_TEST(H2_self_match);

    std::cout << "\n-- 3. Ring / aromaticity unaffected by H notation --\n";
    RUN_TEST(cyclohexane_CH2_notation);
    RUN_TEST(caffeine_theophylline_nH);

    std::cout << "\n-- 4. Drug-like molecules --\n";
    RUN_TEST(morphine_stereo_h_notation);
    RUN_TEST(ibuprofen_stereo_bracket);

    std::cout << "\n-- 5. Formal charge orthogonality --\n";
    RUN_TEST(ammonium_vs_ammonia_no_charge);
    RUN_TEST(carboxylate_vs_acid_no_charge);

    std::cout << "\n=========================================\n";
    std::cout << "Passed: " << sPassed << "  Failed: " << sFailed << "\n";
    return sFailed > 0 ? 1 : 0;
}
