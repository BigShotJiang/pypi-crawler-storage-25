/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * SMSD C++ advanced feature tests:
 *   - findNMCS (N-molecule MCS)
 *   - validateMapping
 *   - isMappingMaximal
 *   - murckoScaffold
 *   - findScaffoldMCS
 *   - decomposeRGroups
 *   - mapReaction
 */

#include "smsd/smsd.hpp"
#include <cassert>
#include <iostream>
#include <string>

// ---------------------------------------------------------------------------
// finalize helper -- initialize bond matrices and derived fields
// (same pattern as test_main.cpp)
// ---------------------------------------------------------------------------
static void finalize(smsd::MolGraph& g, int bondOrd, bool bondRing, bool bondArom) {
    int n = g.n;
    int words = (n + 63) >> 6;
    g.adjLong.assign(n, std::vector<uint64_t>(words, 0));
    g.useDense = (n <= 200);
    if (g.useDense) {
        g.bondOrdMatrix.assign(n, std::vector<int>(n, 0));
        g.bondRingMatrix.assign(n, std::vector<bool>(n, false));
        g.bondAromMatrix.assign(n, std::vector<bool>(n, false));
    }
    for (int i = 0; i < n; ++i) {
        for (int j : g.neighbors[i]) {
            g.adjLong[i][j >> 6] |= uint64_t(1) << (j & 63);
            if (g.useDense) {
                g.bondOrdMatrix[i][j] = bondOrd;
                g.bondRingMatrix[i][j] = bondRing;
                g.bondAromMatrix[i][j] = bondArom;
            }
        }
    }
    g.morganRank.assign(n, 0);
    g.tautomerClass.assign(n, -1);
    g.orbit.resize(n);
    g.ringCount.assign(n, 0);
    g.tetraChirality.assign(n, 0);
    g.canonicalLabel.resize(n);
    for (int i = 0; i < n; ++i) {
        g.morganRank[i] = g.label[i];
        g.orbit[i] = i;
        g.canonicalLabel[i] = i;
    }
}

// ---------------------------------------------------------------------------
// Molecule builders
// ---------------------------------------------------------------------------

// Benzene: 6C aromatic ring
static smsd::MolGraph makeBenzene() {
    smsd::MolGraph g;
    g.n = 6;
    g.atomicNum = {6,6,6,6,6,6};
    g.formalCharge = {0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true};
    g.ring = {true,true,true,true,true,true};
    g.massNumber = {0,0,0,0,0,0};
    g.label.resize(6);
    g.degree.resize(6);
    g.neighbors.resize(6);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1; // carbon, aromatic, ring
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    finalize(g, 4, true, true);
    return g;
}

// Toluene: benzene + methyl (atom 6 = C, bonded to atom 0)
static smsd::MolGraph makeToluene() {
    smsd::MolGraph g;
    g.n = 7;
    g.atomicNum = {6,6,6,6,6,6,6};
    g.formalCharge = {0,0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true,false};
    g.ring = {true,true,true,true,true,true,false};
    g.massNumber = {0,0,0,0,0,0,0};
    g.label.resize(7);
    g.degree.resize(7);
    g.neighbors.resize(7);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1; // carbon, aromatic, ring
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    // Methyl carbon bonded to ring atom 0
    g.neighbors[0].push_back(6); g.degree[0] = 3;
    g.label[6] = (6 << 2); // carbon, not aromatic, not in ring
    g.neighbors[6] = {0}; g.degree[6] = 1;

    finalize(g, 4, true, true);
    // Override the C(ring)-C(methyl) bond to single, not ring, not aromatic
    g.bondOrdMatrix[0][6] = 1; g.bondOrdMatrix[6][0] = 1;
    g.bondRingMatrix[0][6] = false; g.bondRingMatrix[6][0] = false;
    g.bondAromMatrix[0][6] = false; g.bondAromMatrix[6][0] = false;
    return g;
}

// Phenol: benzene + OH (atom 6 = O, bonded to atom 0)
static smsd::MolGraph makePhenol() {
    smsd::MolGraph g;
    g.n = 7;
    g.atomicNum = {6,6,6,6,6,6,8};
    g.formalCharge = {0,0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true,false};
    g.ring = {true,true,true,true,true,true,false};
    g.massNumber = {0,0,0,0,0,0,0};
    g.label.resize(7);
    g.degree.resize(7);
    g.neighbors.resize(7);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1;
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    g.neighbors[0].push_back(6); g.degree[0] = 3;
    g.label[6] = (8 << 2);
    g.neighbors[6] = {0}; g.degree[6] = 1;

    finalize(g, 4, true, true);
    g.bondOrdMatrix[0][6] = 1; g.bondOrdMatrix[6][0] = 1;
    g.bondRingMatrix[0][6] = false; g.bondRingMatrix[6][0] = false;
    g.bondAromMatrix[0][6] = false; g.bondAromMatrix[6][0] = false;
    return g;
}

// ---------------------------------------------------------------------------
// Test harness
// ---------------------------------------------------------------------------
static int testsPassed = 0, testsFailed = 0;

#define RUN_TEST(name) do { \
    std::cout << "[" #name "] "; \
    try { test_##name(); testsPassed++; std::cout << "PASS\n"; } \
    catch (const std::exception& e) { testsFailed++; std::cout << "FAIL: " << e.what() << "\n"; } \
    catch (...) { testsFailed++; std::cout << "FAIL: unknown\n"; } \
} while(0)

// ===========================================================================
// Test: N-MCS -- benzene, toluene, phenol should share a 6-atom common core
// ===========================================================================
void test_findNMCS() {
    auto benz = makeBenzene();
    auto tol  = makeToluene();
    auto phen = makePhenol();

    std::vector<smsd::MolGraph> molecules = {benz, tol, phen};
    smsd::ChemOptions opts;

    auto nmcs = smsd::findNMCS(molecules, opts, 1.0, 10000);
    std::cout << "NMCS size=" << nmcs.size() << " ";
    assert(static_cast<int>(nmcs.size()) == 6);
}

// ===========================================================================
// Test: validateMapping -- correct mapping passes, incorrect fails
// ===========================================================================
void test_validateMapping_correct() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;

    // Get a valid MCS mapping
    auto mcs = smsd::findMCS(benz, phen, opts, mopts);
    assert(!mcs.empty());

    // Validate should return no errors
    auto errors = smsd::validateMapping(benz, phen, mcs, opts);
    std::cout << "errors=" << errors.size() << " ";
    assert(errors.empty());
}

void test_validateMapping_incorrect() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;

    // Create an incorrect mapping: map carbon to oxygen
    std::map<int,int> badMapping;
    badMapping[0] = 6; // carbon in benzene -> oxygen in phenol

    auto errors = smsd::validateMapping(benz, phen, badMapping, opts);
    std::cout << "errors=" << errors.size() << " ";
    assert(!errors.empty()); // should have atom mismatch error
}

// ===========================================================================
// Test: isMappingMaximal -- full MCS is maximal, partial is not
// ===========================================================================
void test_isMappingMaximal_full() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;

    auto mcs = smsd::findMCS(benz, phen, opts, mopts);
    assert(static_cast<int>(mcs.size()) == 6);

    bool maximal = smsd::isMappingMaximal(benz, phen, mcs, opts);
    std::cout << "maximal=" << maximal << " ";
    assert(maximal);
}

void test_isMappingMaximal_partial() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;

    auto mcs = smsd::findMCS(benz, phen, opts, mopts);
    assert(static_cast<int>(mcs.size()) >= 2);

    // Remove one pair to make it non-maximal
    std::map<int,int> partial = mcs;
    partial.erase(partial.begin());

    bool maximal = smsd::isMappingMaximal(benz, phen, partial, opts);
    std::cout << "maximal=" << maximal << " ";
    assert(!maximal);
}

// ===========================================================================
// Test: murckoScaffold -- toluene -> benzene (strip methyl)
// ===========================================================================
void test_murckoScaffold_toluene() {
    auto tol = makeToluene();

    auto scaffold = smsd::murckoScaffold(tol);
    std::cout << "scaffold_atoms=" << scaffold.n << " ";
    // Toluene's methyl (non-ring, not a linker) should be stripped -> 6 atoms
    assert(scaffold.n == 6);
}

void test_murckoScaffold_benzene() {
    auto benz = makeBenzene();
    // Benzene is all ring -> scaffold == benzene
    auto scaffold = smsd::murckoScaffold(benz);
    std::cout << "scaffold_atoms=" << scaffold.n << " ";
    assert(scaffold.n == 6);
}

// ===========================================================================
// Test: findScaffoldMCS -- scaffold MCS of toluene and phenol is benzene (6)
// ===========================================================================
void test_findScaffoldMCS() {
    auto tol  = makeToluene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;

    auto scaffMcs = smsd::findScaffoldMCS(tol, phen, opts, mopts);
    std::cout << "scaffoldMCS_size=" << scaffMcs.size() << " ";
    assert(static_cast<int>(scaffMcs.size()) == 6);
}

// ===========================================================================
// Test: decomposeRGroups -- benzene core on toluene -> R1=methyl,
//                           benzene core on phenol  -> R1=OH
// ===========================================================================
void test_decomposeRGroups_toluene() {
    auto benz = makeBenzene();
    auto tol  = makeToluene();
    smsd::ChemOptions opts;

    std::vector<smsd::MolGraph> molecules = {tol};
    auto results = smsd::decomposeRGroups(benz, molecules, opts, 10000);
    assert(results.size() == 1);

    auto& decomp = results[0];
    std::cout << "core=" << decomp.core.n << " rgroups=" << decomp.rgroups.size() << " ";
    assert(decomp.core.n == 6);   // benzene core
    assert(decomp.rgroups.size() == 1); // one R-group (methyl)

    // The R-group should be 1 atom (methyl carbon)
    auto it = decomp.rgroups.find("R1");
    assert(it != decomp.rgroups.end());
    assert(it->second.n == 1);
    assert(it->second.atomicNum[0] == 6); // carbon
}

void test_decomposeRGroups_phenol() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;

    std::vector<smsd::MolGraph> molecules = {phen};
    auto results = smsd::decomposeRGroups(benz, molecules, opts, 10000);
    assert(results.size() == 1);

    auto& decomp = results[0];
    std::cout << "core=" << decomp.core.n << " rgroups=" << decomp.rgroups.size() << " ";
    assert(decomp.core.n == 6);   // benzene core
    assert(decomp.rgroups.size() == 1); // one R-group (OH)

    auto it = decomp.rgroups.find("R1");
    assert(it != decomp.rgroups.end());
    assert(it->second.n == 1);
    assert(it->second.atomicNum[0] == 8); // oxygen
}

// ===========================================================================
// Test: mapReaction -- simple identity-like mapping between same molecule
// ===========================================================================
void test_mapReaction() {
    auto benz1 = makeBenzene();
    auto benz2 = makeBenzene();
    smsd::ChemOptions opts;

    auto mapping = smsd::mapReaction(benz1, benz2, opts, 10000);
    std::cout << "reaction_map_size=" << mapping.size() << " ";
    // Same molecule -> all 6 atoms should map
    assert(static_cast<int>(mapping.size()) == 6);
}

// ===========================================================================
// Test: extractSubgraph -- basic extraction works
// ===========================================================================
void test_extractSubgraph() {
    auto phen = makePhenol(); // 7 atoms: 6 ring C + 1 O
    std::vector<int> indices = {0, 1, 2, 3, 4, 5}; // ring atoms only
    auto sub = smsd::extractSubgraph(phen, indices);
    std::cout << "sub_atoms=" << sub.n << " ";
    assert(sub.n == 6);
    // All atoms should be carbon
    for (int i = 0; i < sub.n; ++i) {
        assert(sub.atomicNum[i] == 6);
    }
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------
int main() {
    std::cout << "SMSD C++ Advanced Feature Tests\n";
    std::cout << "================================================\n";

    RUN_TEST(findNMCS);
    RUN_TEST(validateMapping_correct);
    RUN_TEST(validateMapping_incorrect);
    RUN_TEST(isMappingMaximal_full);
    RUN_TEST(isMappingMaximal_partial);
    RUN_TEST(murckoScaffold_toluene);
    RUN_TEST(murckoScaffold_benzene);
    RUN_TEST(findScaffoldMCS);
    RUN_TEST(decomposeRGroups_toluene);
    RUN_TEST(decomposeRGroups_phenol);
    RUN_TEST(mapReaction);
    RUN_TEST(extractSubgraph);

    std::cout << "================================================\n";
    std::cout << testsPassed << " passed, " << testsFailed << " failed\n";
    return testsFailed > 0 ? 1 : 0;
}
