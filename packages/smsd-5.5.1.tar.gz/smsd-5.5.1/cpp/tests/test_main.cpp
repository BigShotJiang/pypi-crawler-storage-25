/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * SMSD C++ test suite — minimal test harness (no dependencies).
 */

#include "smsd/smsd.hpp"
#include <cassert>
#include <iostream>
#include <chrono>
#include <cmath>

// Initialize bond matrices and derived fields for a manually-built MolGraph
static void finalize(smsd::MolGraph& g, int bondOrd, bool bondRing, bool bondArom) {
    int n = g.n;
    int words = (n + 63) >> 6;
    g.adjLong.assign(n, std::vector<uint64_t>(words, 0));
    g.useDense = (n <= 200);
    if (g.useDense) {
        g.bondOrdMatrix.assign(n, std::vector<int>(n, 0));
        g.bondRingMatrix.assign(n, std::vector<bool>(n, false));
        g.bondAromMatrix.assign(n, std::vector<bool>(n, false));
    }
    for (int i = 0; i < n; ++i) {
        for (int j : g.neighbors[i]) {
            g.adjLong[i][j >> 6] |= uint64_t(1) << (j & 63);
            if (g.useDense) {
                g.bondOrdMatrix[i][j] = bondOrd;
                g.bondRingMatrix[i][j] = bondRing;
                g.bondAromMatrix[i][j] = bondArom;
            }
        }
    }
    g.morganRank.assign(n, 0);
    g.tautomerClass.assign(n, -1);
    g.orbit.resize(n);
    g.ringCount.assign(n, 0);
    g.tetraChirality.assign(n, 0);
    g.canonicalLabel.resize(n);
    for (int i = 0; i < n; ++i) { g.morganRank[i] = g.label[i]; g.orbit[i] = i; g.canonicalLabel[i] = i; }
}

// Helper: build benzene (6C aromatic ring)
static smsd::MolGraph makeBenzene() {
    smsd::MolGraph g;
    g.n = 6;
    g.atomicNum = {6,6,6,6,6,6};
    g.formalCharge = {0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true};
    g.ring = {true,true,true,true,true,true};
    g.massNumber = {0,0,0,0,0,0};
    g.label.resize(6);
    g.degree.resize(6);
    g.neighbors.resize(6);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1;
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    finalize(g, 4, true, true); // aromatic bonds in ring
    return g;
}

// Helper: build phenol (6C ring + O)
static smsd::MolGraph makePhenol() {
    smsd::MolGraph g;
    g.n = 7;
    g.atomicNum = {6,6,6,6,6,6,8};
    g.formalCharge = {0,0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true,false};
    g.ring = {true,true,true,true,true,true,false};
    g.massNumber = {0,0,0,0,0,0,0};
    g.label.resize(7);
    g.degree.resize(7);
    g.neighbors.resize(7);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1;
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    g.neighbors[0].push_back(6); g.degree[0] = 3;
    g.label[6] = (8 << 2);
    g.neighbors[6] = {0}; g.degree[6] = 1;
    // Bond orders: ring bonds = aromatic(4), C-O = single(1)
    finalize(g, 4, true, true); // default all aromatic ring bonds
    // Override C-O bond to single, not in ring, not aromatic
    g.bondOrdMatrix[0][6] = 1; g.bondOrdMatrix[6][0] = 1;
    g.bondRingMatrix[0][6] = false; g.bondRingMatrix[6][0] = false;
    g.bondAromMatrix[0][6] = false; g.bondAromMatrix[6][0] = false;
    return g;
}

static int testsPassed = 0, testsFailed = 0;

#define RUN_TEST(name) do { \
    std::cout << "[" #name "] "; \
    try { test_##name(); testsPassed++; std::cout << "PASS\n"; } \
    catch (const std::exception& e) { testsFailed++; std::cout << "FAIL: " << e.what() << "\n"; } \
    catch (...) { testsFailed++; std::cout << "FAIL: unknown\n"; } \
} while(0)

void test_benzene_self_sub() {
    auto benz = makeBenzene();
    smsd::ChemOptions opts;
    assert(smsd::isSubstructure(benz, benz, opts));
}

void test_benzene_in_phenol() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    assert(smsd::isSubstructure(benz, phen, opts));
}

void test_phenol_not_in_benzene() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    assert(!smsd::isSubstructure(phen, benz, opts));
}

void test_benzene_phenol_mcs() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions chem;
    smsd::McsOptions opts;
    auto mcs = smsd::findMCS(benz, phen, chem, opts);
    assert(static_cast<int>(mcs.size()) == 6);
    std::cout << "MCS=" << mcs.size() << " ";
}

void test_rascal() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    double sim = smsd::similarityUpperBound(benz, phen);
    assert(sim > 0.5);
    std::cout << "sim=" << sim << " ";
}

void test_performance() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    auto t0 = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 10000; ++i) {
        smsd::isSubstructure(benz, phen, opts);
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    double us = std::chrono::duration<double, std::micro>(t1 - t0).count() / 10000;
    std::cout << us << "us/call ";
    assert(us < 100);
}

int main() {
    std::cout << "SMSD C++ Tests\n";
    std::cout << "================================================\n";
    RUN_TEST(benzene_self_sub);
    RUN_TEST(benzene_in_phenol);
    RUN_TEST(phenol_not_in_benzene);
    RUN_TEST(benzene_phenol_mcs);
    RUN_TEST(rascal);
    RUN_TEST(performance);
    std::cout << "================================================\n";
    std::cout << testsPassed << " passed, " << testsFailed << " failed\n";
    return testsFailed > 0 ? 1 : 0;
}
