/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * Comprehensive SMARTS parser and matcher tests.
 * Compile with -DSMSD_TEST_SMARTS to enable.
 */

#ifdef SMSD_TEST_SMARTS

#include "smsd/smiles_parser.hpp"
#include "smsd/smarts_parser.hpp"

#include <cassert>
#include <iostream>
#include <string>
#include <stdexcept>

// ---------------------------------------------------------------------------
// Minimal test harness
// ---------------------------------------------------------------------------
static int g_passed = 0;
static int g_failed = 0;

#define RUN_SMARTS_TEST(name) do { \
    std::cout << "  [" #name "] "; \
    try { test_##name(); g_passed++; std::cout << "PASS\n"; } \
    catch (const std::exception& e) { g_failed++; std::cout << "FAIL: " << e.what() << "\n"; } \
    catch (...) { g_failed++; std::cout << "FAIL (unknown)\n"; } \
} while(0)

// Convenience helpers
static bool smartsMatches(const std::string& smarts, const std::string& smiles) {
    auto q = smsd::parseSMARTS(smarts);
    auto mol = smsd::parseSMILES(smiles);
    return q.matches(mol);
}

static int smartsCountAll(const std::string& smarts, const std::string& smiles, int max = 1000) {
    auto q = smsd::parseSMARTS(smarts);
    auto mol = smsd::parseSMILES(smiles);
    return static_cast<int>(q.findAll(mol, max).size());
}

// ===================================================================
// Atom primitive tests
// ===================================================================

void test_atom_atomic_num_carbon() {
    assert(smartsMatches("[#6]", "C"));
    assert(smartsMatches("[#6]", "CC"));
    assert(!smartsMatches("[#6]", "[He]"));
}

void test_atom_atomic_num_nitrogen() {
    assert(smartsMatches("[#7]", "N"));
    assert(!smartsMatches("[#7]", "C"));
}

void test_atom_not_hydrogen() {
    assert(smartsMatches("[!#1]", "C"));
    assert(smartsMatches("[!#1]", "N"));
    assert(smartsMatches("[!#1]", "O"));
    assert(!smartsMatches("[!#1]", "[H]"));
}

void test_atom_degree_2() {
    assert(smartsMatches("[D2]", "CCC"));   // middle C has degree 2
    assert(!smartsMatches("[D2]", "C"));     // single C has degree 0
}

void test_atom_degree_3() {
    assert(smartsMatches("[D3]", "CC(C)C")); // central C has degree 3
}

void test_atom_ring() {
    assert(smartsMatches("[R]", "C1CCC1"));
    assert(!smartsMatches("[R]", "CCCC"));
}

void test_atom_ring_size_6() {
    assert(smartsMatches("[r6]", "C1CCCCC1"));
    assert(!smartsMatches("[r6]", "C1CCC1"));
}

void test_atom_valence_4() {
    assert(smartsMatches("[v4]", "C(F)(F)(F)F"));
}

void test_atom_ring_connectivity_2() {
    assert(smartsMatches("[x2]", "C1CCC1"));
    assert(!smartsMatches("[x2]", "CCC"));
}

void test_atom_hcount_1() {
    assert(smartsMatches("[H1]", "C(Cl)(Cl)Cl")); // CHCl3: C has 1 implicit H
}

void test_atom_positive_charge() {
    assert(smartsMatches("[+1]", "[NH4+]"));
    assert(!smartsMatches("[+1]", "C"));
}

void test_atom_negative_charge() {
    assert(smartsMatches("[-1]", "[O-]"));
    assert(!smartsMatches("[-1]", "O"));
}

void test_atom_isotope() {
    assert(smartsMatches("[13C]", "[13CH4]"));
    assert(!smartsMatches("[13C]", "C"));
}

void test_atom_aromatic() {
    assert(smartsMatches("[a]", "c1ccccc1"));
    assert(!smartsMatches("[a]", "C1CCCCC1"));
}

void test_atom_aliphatic() {
    assert(smartsMatches("[A]", "C"));
    assert(smartsMatches("[A]", "CCC"));
}

void test_atom_wildcard_bracket() {
    assert(smartsMatches("[*]", "C"));
    assert(smartsMatches("[*]", "N"));
    assert(smartsMatches("[*]", "[He]"));
}

// ===================================================================
// Bond primitive tests
// ===================================================================

void test_bond_single() {
    assert(smartsMatches("C-C", "CC"));
    assert(!smartsMatches("C-C", "C=C"));
}

void test_bond_double() {
    assert(smartsMatches("C=C", "C=C"));
    assert(!smartsMatches("C=C", "CC"));
}

void test_bond_triple() {
    assert(smartsMatches("C#N", "C#N"));
    assert(!smartsMatches("C#N", "C=N"));
}

void test_bond_aromatic() {
    assert(smartsMatches("c:c", "c1ccccc1"));
}

void test_bond_any() {
    assert(smartsMatches("C~C", "CC"));
    assert(smartsMatches("C~C", "C=C"));
    assert(smartsMatches("C~C", "C#C"));
}

void test_bond_ring() {
    assert(smartsMatches("[#6]@[#6]", "C1CCC1"));
    assert(!smartsMatches("[#6]@[#6]", "CCC"));
}

void test_bond_wedge() {
    // / bond: currently matches any bond (stereo not yet stored in MolGraph)
    assert(smartsMatches("C/C", "CC"));
    assert(smartsMatches("C/C", "C=C"));
}

void test_bond_dash_stereo() {
    // \ bond: currently matches any bond
    assert(smartsMatches("C\\C", "CC"));
    assert(smartsMatches("C\\C", "C=C"));
}

// ===================================================================
// Logical operator tests
// ===================================================================

void test_logic_or() {
    assert(smartsMatches("[#6,#7]", "C"));
    assert(smartsMatches("[#6,#7]", "N"));
    assert(!smartsMatches("[#6,#7]", "O"));
}

void test_logic_and_low() {
    assert(smartsMatches("[#6;R]", "C1CCC1"));
    assert(!smartsMatches("[#6;R]", "CCC"));
}

void test_logic_and_high() {
    assert(smartsMatches("[#6&R]", "C1CCC1"));
    assert(!smartsMatches("[#6&R]", "CCC"));
}

void test_logic_not() {
    assert(!smartsMatches("[!#6]", "C"));
    assert(smartsMatches("[!#6]", "N"));
    assert(smartsMatches("[!#6]", "O"));
}

void test_logic_complex_or_and() {
    // [#6,#7;R] = (carbon OR nitrogen) AND ring
    assert(smartsMatches("[#6,#7;R]", "C1CCC1"));
    assert(!smartsMatches("[#6,#7;R]", "CCC"));
}

// ===================================================================
// Recursive SMARTS tests
// ===================================================================

void test_recursive_sp3_nitrogen() {
    assert(smartsMatches("[$([NX3])]", "CCN(C)C"));
}

void test_recursive_hydroxyl() {
    assert(smartsMatches("[$([OH])]", "CO"));
    assert(!smartsMatches("[$([OH])]", "C=O"));
}

void test_recursive_carbon_bonded_to_oxygen() {
    assert(smartsMatches("[$([#6][#8])]", "CCO"));
    assert(!smartsMatches("[$([#6][#8])]", "CCC"));
}

// ===================================================================
// Named predicate registry tests
// ===================================================================

void test_predicate_registry_basic() {
    auto reg = smsd::SmartsPredicateRegistry::builtinRegistry();
    std::string expanded = reg.expandPredicates("[$isHalogen]");
    assert(expanded == "[$([F,Cl,Br,I])]");
}

void test_predicate_registry_custom() {
    smsd::SmartsPredicateRegistry reg;
    reg.registerPredicate("myPred", "[#6]");
    std::string expanded = reg.expandPredicates("[$myPred]");
    assert(expanded == "[$([#6])]");
}

void test_predicate_no_clobber_recursive() {
    smsd::SmartsPredicateRegistry reg;
    reg.registerPredicate("foo", "[#7]");
    std::string input = "[$([#6])]";
    std::string expanded = reg.expandPredicates(input);
    assert(expanded == input);
}

void test_predicate_isKetone_expand() {
    auto reg = smsd::SmartsPredicateRegistry::builtinRegistry();
    std::string expanded = reg.expandPredicates("[$isKetone]");
    assert(expanded == "[$([#6][CX3](=O)[#6])]");
}

void test_predicate_isHalogen_match() {
    auto reg = smsd::SmartsPredicateRegistry::builtinRegistry();
    std::string expanded = reg.expandPredicates("[$isHalogen]");
    auto q = smsd::parseSMARTS(expanded);
    auto mol = smsd::parseSMILES("CF");
    assert(q.matches(mol));
}

void test_predicate_isPositive_match() {
    auto reg = smsd::SmartsPredicateRegistry::builtinRegistry();
    std::string expanded = reg.expandPredicates("[$isPositive]");
    auto q = smsd::parseSMARTS(expanded);
    assert(q.matches(smsd::parseSMILES("[NH4+]")));
    assert(!q.matches(smsd::parseSMILES("C")));
}

void test_predicate_isNegative_match() {
    auto reg = smsd::SmartsPredicateRegistry::builtinRegistry();
    std::string expanded = reg.expandPredicates("[$isNegative]");
    auto q = smsd::parseSMARTS(expanded);
    assert(q.matches(smsd::parseSMILES("[O-]C")));
}

// ===================================================================
// Complex pattern tests
// ===================================================================

void test_complex_carboxylic_acid() {
    assert(smartsMatches("[CX3](=O)[OX2H1]", "CC(=O)O"));
    assert(!smartsMatches("[CX3](=O)[OX2H1]", "CC"));
}

void test_complex_aromatic_ring() {
    assert(smartsMatches("c1ccccc1", "c1ccccc1"));
}

void test_complex_primary_amine_not_amide() {
    assert(smartsMatches("[NX3;H2,H1;!$(NC=O)]", "CCN"));
}

void test_complex_carbonyl() {
    assert(smartsMatches("[CX3]=[OX1]", "CC=O"));
    assert(smartsMatches("[CX3]=[OX1]", "CC(=O)C"));
}

// ===================================================================
// Edge case tests
// ===================================================================

void test_edge_empty_pattern() {
    auto q = smsd::parseSMARTS("");
    auto mol = smsd::parseSMILES("C");
    assert(q.matches(mol));
}

void test_edge_single_bracket_atom() {
    assert(smartsMatches("[C]", "C"));
    assert(smartsMatches("[C]", "CC"));
}

void test_edge_wildcard_star() {
    assert(smartsMatches("*", "C"));
    assert(smartsMatches("*", "N"));
    assert(smartsMatches("*", "[He]"));
    assert(smartsMatches("*", "c1ccccc1"));
}

void test_edge_invalid_smarts_throws() {
    bool threw = false;
    try {
        smsd::parseSMARTS("[#6");
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    assert(threw);
}

void test_edge_multi_component() {
    auto q = smsd::parseSMARTS("C.N");
    auto mol = smsd::parseSMILES("CN");
    assert(q.matches(mol));
}

void test_edge_findAll_count() {
    int count = smartsCountAll("[#6]", "CCCC");
    assert(count == 4);
}

// ===================================================================
// Drug molecule matching tests
// ===================================================================

void test_drug_benzene_in_aspirin() {
    // Aspirin: CC(=O)Oc1ccccc1C(=O)O
    assert(smartsMatches("c1ccccc1", "CC(=O)Oc1ccccc1C(=O)O"));
}

void test_drug_amide_in_acetaminophen() {
    // Acetaminophen: CC(=O)Nc1ccc(O)cc1
    assert(smartsMatches("C(=O)N", "CC(=O)Nc1ccc(O)cc1"));
}

void test_drug_carboxyl_in_aspirin() {
    assert(smartsMatches("C(=O)O", "CC(=O)Oc1ccccc1C(=O)O"));
}

void test_drug_hydroxyl_in_acetaminophen() {
    assert(smartsMatches("[OH]", "CC(=O)Nc1ccc(O)cc1"));
}

void test_drug_ester_in_aspirin() {
    assert(smartsMatches("[CX3](=O)[OX2][#6]", "CC(=O)Oc1ccccc1C(=O)O"));
}

// ===================================================================
// RDKit-parity SMARTS extension tests
// ===================================================================

// --- z<n>: heteroatom neighbor count ---

void test_ext_hetero_neighbors_z2_pyrimidine() {
    // Pyrimidine c1ncncc1: carbon between the two nitrogens has 2 hetero neighbors
    assert(smartsMatches("[z2]", "c1ncncc1"));
}

void test_ext_hetero_neighbors_z0() {
    // In ethane CC, each carbon only has carbon neighbors => z=0
    assert(smartsMatches("[z0]", "CC"));
    // z1 should not match pure carbon chain
    assert(!smartsMatches("[z1]", "CC"));
}

void test_ext_hetero_neighbors_z1_cn() {
    // In methylamine CN: carbon has N neighbor => z=1
    assert(smartsMatches("[z1]", "CN"));
}

void test_ext_hetero_neighbors_default() {
    // [z] without number = at least 1 heteroatom neighbor
    assert(smartsMatches("[z]", "CN"));
    assert(!smartsMatches("[z]", "CC"));
}

// --- Z<n>: aliphatic heteroatom neighbor count ---

void test_ext_aliphatic_hetero_Z1() {
    // In methylamine CN: C has aliphatic N neighbor => Z=1
    assert(smartsMatches("[Z1]", "CN"));
}

void test_ext_aliphatic_hetero_aromatic() {
    // In pyridine c1ccncc1: carbons adjacent to aromatic N have an aromatic
    // hetero neighbor. Since N is aromatic, Z (aliphatic hetero) should be 0
    // for all atoms. No atom should match [Z1].
    assert(!smartsMatches("[Z1]", "c1ccncc1"));
}

// --- d<n>: heavy degree (non-hydrogen connections) ---

void test_ext_heavy_degree_d2() {
    // In propane CCC, middle C has 2 heavy neighbors => d=2
    assert(smartsMatches("[d2]", "CCC"));
    // In ethylene C=C, each C has only 1 heavy neighbor => d=1, not d=2
    assert(!smartsMatches("[d2]", "C=C"));
}

void test_ext_heavy_degree_d1() {
    // Terminal carbons in ethane have 1 heavy neighbor
    assert(smartsMatches("[d1]", "CC"));
}

void test_ext_heavy_degree_d3() {
    // Central carbon in isobutane CC(C)C has 3 heavy neighbors
    assert(smartsMatches("[d3]", "CC(C)C"));
}

// --- ^<n>: hybridization ---

void test_ext_hybridization_sp2_aromatic() {
    // Aromatic carbons are SP2 => ^2
    assert(smartsMatches("[^2]", "c1ccccc1"));
}

void test_ext_hybridization_sp3() {
    // Methane/ethane carbons are SP3 => ^3
    assert(smartsMatches("[^3]", "C"));
    assert(smartsMatches("[^3]", "CC"));
}

void test_ext_hybridization_sp2_double_bond() {
    // Ethylene C=C: each carbon has 1 double bond => SP2
    assert(smartsMatches("[^2]", "C=C"));
}

void test_ext_hybridization_sp() {
    // Acetylene C#C: triple bond => SP (^1)
    assert(smartsMatches("[^1]", "C#C"));
}

void test_ext_hybridization_sp3_not_sp2() {
    // SP3 carbon should not match [^2]
    assert(!smartsMatches("[^2]", "C"));
}

// --- Range queries {n-m} ---

void test_ext_range_degree_2_to_4() {
    // [D{2-4}] matches degree 2, 3, or 4
    // Neopentane CC(C)(C)C: central C has D=4 => matches
    assert(smartsMatches("[D{2-4}]", "CC(C)(C)C"));
    // Single carbon C has D=0 => no match
    assert(!smartsMatches("[D{2-4}]", "C"));
}

void test_ext_range_min_only() {
    // [D{2-}] matches degree >= 2
    assert(smartsMatches("[D{2-}]", "CCC"));       // middle C, D=2
    assert(smartsMatches("[D{2-}]", "CC(C)(C)C")); // central C, D=4
    assert(!smartsMatches("[D{2-}]", "C"));         // D=0
}

void test_ext_range_max_only() {
    // [D{-2}] matches degree <= 2
    assert(smartsMatches("[D{-2}]", "CCC")); // terminal C has D=1, middle has D=2
    assert(smartsMatches("[D{-2}]", "C"));   // D=0
}

void test_ext_range_hcount() {
    // [H{1-3}] matches atoms with 1 to 3 hydrogens
    assert(smartsMatches("[H{1-3}]", "CCC"));
    // CCl4: C has 0 H
    assert(!smartsMatches("[H{1-3}]", "C(Cl)(Cl)(Cl)Cl"));
}

void test_ext_range_exact_brace() {
    // [D{3}] means exact match D=3 (like D3)
    assert(smartsMatches("[D{3}]", "CC(C)C")); // central C has D3
    assert(!smartsMatches("[D{3}]", "CCC"));   // max D=2
}

void test_ext_combined_hybridization_and_element() {
    // [#6^2] carbon AND SP2
    assert(smartsMatches("[#6^2]", "C=C"));
    assert(!smartsMatches("[#6^2]", "CC")); // SP3 carbon
}

void test_ext_range_valence() {
    // [v{2-4}] matches atoms with valence between 2 and 4
    assert(smartsMatches("[v{2-4}]", "C=C"));  // each C has valence 2
    assert(!smartsMatches("[v{2-4}]", "C"));   // valence 0 (no explicit bonds)
}

void test_ext_range_hetero_neighbors() {
    // [z{1-2}] matches atoms with 1 or 2 heteroatom neighbors
    assert(smartsMatches("[z{1-2}]", "CN"));  // C has 1 N neighbor => z=1
    assert(!smartsMatches("[z{1-2}]", "CC")); // z=0 for all
}

// ===================================================================
// Main
// ===================================================================

int main() {
    std::cout << "SMSD C++ SMARTS Comprehensive Tests\n";
    std::cout << "====================================\n";

    // Atom primitives (16 tests)
    RUN_SMARTS_TEST(atom_atomic_num_carbon);
    RUN_SMARTS_TEST(atom_atomic_num_nitrogen);
    RUN_SMARTS_TEST(atom_not_hydrogen);
    RUN_SMARTS_TEST(atom_degree_2);
    RUN_SMARTS_TEST(atom_degree_3);
    RUN_SMARTS_TEST(atom_ring);
    RUN_SMARTS_TEST(atom_ring_size_6);
    RUN_SMARTS_TEST(atom_valence_4);
    RUN_SMARTS_TEST(atom_ring_connectivity_2);
    RUN_SMARTS_TEST(atom_hcount_1);
    RUN_SMARTS_TEST(atom_positive_charge);
    RUN_SMARTS_TEST(atom_negative_charge);
    RUN_SMARTS_TEST(atom_isotope);
    RUN_SMARTS_TEST(atom_aromatic);
    RUN_SMARTS_TEST(atom_aliphatic);
    RUN_SMARTS_TEST(atom_wildcard_bracket);

    // Bond primitives (8 tests)
    RUN_SMARTS_TEST(bond_single);
    RUN_SMARTS_TEST(bond_double);
    RUN_SMARTS_TEST(bond_triple);
    RUN_SMARTS_TEST(bond_aromatic);
    RUN_SMARTS_TEST(bond_any);
    RUN_SMARTS_TEST(bond_ring);
    RUN_SMARTS_TEST(bond_wedge);
    RUN_SMARTS_TEST(bond_dash_stereo);

    // Logical operators (5 tests)
    RUN_SMARTS_TEST(logic_or);
    RUN_SMARTS_TEST(logic_and_low);
    RUN_SMARTS_TEST(logic_and_high);
    RUN_SMARTS_TEST(logic_not);
    RUN_SMARTS_TEST(logic_complex_or_and);

    // Recursive SMARTS (3 tests)
    RUN_SMARTS_TEST(recursive_sp3_nitrogen);
    RUN_SMARTS_TEST(recursive_hydroxyl);
    RUN_SMARTS_TEST(recursive_carbon_bonded_to_oxygen);

    // Named predicates (7 tests)
    RUN_SMARTS_TEST(predicate_registry_basic);
    RUN_SMARTS_TEST(predicate_registry_custom);
    RUN_SMARTS_TEST(predicate_no_clobber_recursive);
    RUN_SMARTS_TEST(predicate_isKetone_expand);
    RUN_SMARTS_TEST(predicate_isHalogen_match);
    RUN_SMARTS_TEST(predicate_isPositive_match);
    RUN_SMARTS_TEST(predicate_isNegative_match);

    // Complex patterns (4 tests)
    RUN_SMARTS_TEST(complex_carboxylic_acid);
    RUN_SMARTS_TEST(complex_aromatic_ring);
    RUN_SMARTS_TEST(complex_primary_amine_not_amide);
    RUN_SMARTS_TEST(complex_carbonyl);

    // Edge cases (6 tests)
    RUN_SMARTS_TEST(edge_empty_pattern);
    RUN_SMARTS_TEST(edge_single_bracket_atom);
    RUN_SMARTS_TEST(edge_wildcard_star);
    RUN_SMARTS_TEST(edge_invalid_smarts_throws);
    RUN_SMARTS_TEST(edge_multi_component);
    RUN_SMARTS_TEST(edge_findAll_count);

    // Drug molecule matching (5 tests)
    RUN_SMARTS_TEST(drug_benzene_in_aspirin);
    RUN_SMARTS_TEST(drug_amide_in_acetaminophen);
    RUN_SMARTS_TEST(drug_carboxyl_in_aspirin);
    RUN_SMARTS_TEST(drug_hydroxyl_in_acetaminophen);
    RUN_SMARTS_TEST(drug_ester_in_aspirin);

    // RDKit-parity SMARTS extensions (22 tests)
    RUN_SMARTS_TEST(ext_hetero_neighbors_z2_pyrimidine);
    RUN_SMARTS_TEST(ext_hetero_neighbors_z0);
    RUN_SMARTS_TEST(ext_hetero_neighbors_z1_cn);
    RUN_SMARTS_TEST(ext_hetero_neighbors_default);
    RUN_SMARTS_TEST(ext_aliphatic_hetero_Z1);
    RUN_SMARTS_TEST(ext_aliphatic_hetero_aromatic);
    RUN_SMARTS_TEST(ext_heavy_degree_d2);
    RUN_SMARTS_TEST(ext_heavy_degree_d1);
    RUN_SMARTS_TEST(ext_heavy_degree_d3);
    RUN_SMARTS_TEST(ext_hybridization_sp2_aromatic);
    RUN_SMARTS_TEST(ext_hybridization_sp3);
    RUN_SMARTS_TEST(ext_hybridization_sp2_double_bond);
    RUN_SMARTS_TEST(ext_hybridization_sp);
    RUN_SMARTS_TEST(ext_hybridization_sp3_not_sp2);
    RUN_SMARTS_TEST(ext_range_degree_2_to_4);
    RUN_SMARTS_TEST(ext_range_min_only);
    RUN_SMARTS_TEST(ext_range_max_only);
    RUN_SMARTS_TEST(ext_range_hcount);
    RUN_SMARTS_TEST(ext_range_exact_brace);
    RUN_SMARTS_TEST(ext_combined_hybridization_and_element);
    RUN_SMARTS_TEST(ext_range_valence);
    RUN_SMARTS_TEST(ext_range_hetero_neighbors);

    std::cout << "====================================\n";
    std::cout << g_passed << " passed, " << g_failed << " failed\n";
    return g_failed > 0 ? 1 : 0;
}

#else
// Compile with -DSMSD_TEST_SMARTS to enable SMARTS tests
int main() {
    return 0;
}
#endif // SMSD_TEST_SMARTS
