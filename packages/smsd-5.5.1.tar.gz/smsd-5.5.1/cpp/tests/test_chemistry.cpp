/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * SMSD C++ chemistry tests — mirrors Java adversarial test suite.
 * Uses parseSMILES to build molecules from SMILES strings.
 */

#include "smsd/smsd.hpp"
#include "smsd/smiles_parser.hpp"
#include <cassert>
#include <iostream>

static int testsPassed = 0, testsFailed = 0;

#define RUN_TEST(name) do { \
    std::cout << "[" #name "] "; \
    try { test_##name(); testsPassed++; std::cout << "PASS\n"; } \
    catch (const std::exception& e) { testsFailed++; std::cout << "FAIL: " << e.what() << "\n"; } \
    catch (...) { testsFailed++; std::cout << "FAIL: unknown\n"; } \
} while(0)

// ============================================================================
// Test 1: Ring fusion STRICT — naphthalene vs biphenyl MCS must be < 10
//
// Naphthalene has two fused rings (shared edge), biphenyl has two isolated
// rings connected by a single bond. Under STRICT ring fusion, atoms in a
// fused ring (ringCount=2) should NOT match atoms in a single ring
// (ringCount=1), so the MCS should be smaller than a full ring (10 atoms).
// ============================================================================

void test_ring_fusion_strict_naphthalene_biphenyl() {
    auto naphthalene = smsd::parseSMILES("c1ccc2ccccc2c1");   // 10 atoms, fused
    auto biphenyl    = smsd::parseSMILES("c1ccc(-c2ccccc2)cc1"); // 12 atoms, non-fused

    smsd::ChemOptions chem;
    chem.ringFusionMode = smsd::ChemOptions::RingFusionMode::STRICT;
    chem.ringMatchesRingOnly = true;

    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;

    auto mcs = smsd::findMCS(naphthalene, biphenyl, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " ";

    // Under STRICT ring fusion, fused-ring atoms (ringCount=2) cannot match
    // single-ring atoms (ringCount=1), so MCS must be less than 10.
    assert(mcsSize < 10);
}

// ============================================================================
// Test 2: Crown ether — COCCOC is a substructure of 18-crown-6
//
// 18-crown-6: C1COCCOCCOCCOCCOCCO1 (24 atoms)
// Query:      COCCOC (6 atoms)
// ============================================================================

void test_crown_ether_substructure() {
    auto crown6 = smsd::parseSMILES("C1COCCOCCOCCOCCOCCO1");
    auto query  = smsd::parseSMILES("COCCOC");

    smsd::ChemOptions opts;
    bool isSub = smsd::isSubstructure(query, crown6, opts);
    std::cout << "sub=" << (isSub ? "true" : "false") << " ";
    assert(isSub);
}

// ============================================================================
// Test 3: Tautomer — keto/enol MCS with tautomer profile
//
// Keto form:  CC(=O)C  (acetone / propan-2-one)
// Enol form:  CC(O)=C  (propen-2-ol)
// With tautomer-aware matching, MCS should cover all heavy atoms (4).
// ============================================================================

void test_tautomer_keto_enol_mcs() {
    auto keto = smsd::parseSMILES("CC(=O)C");
    auto enol = smsd::parseSMILES("CC(O)=C");

    smsd::ChemOptions chem = smsd::ChemOptions::tautomerProfile();

    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;

    auto mcs = smsd::findMCS(keto, enol, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " ";

    // Tautomer-aware matching should map all 4 heavy atoms.
    assert(mcsSize == 4);
}

// ============================================================================
// Test 4: Symmetric molecules — self-match
//
// Adamantane (C1C2CC3CC1CC(C2)C3) and cubane (C12C3C4C1C5C4C3C25) should
// have perfect self-match (MCS size == atom count).
// ============================================================================

void test_adamantane_self_match() {
    auto adam = smsd::parseSMILES("C1C2CC3CC1CC(C2)C3");

    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;

    auto mcs = smsd::findMCS(adam, adam, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " n=" << adam.n << " ";

    assert(mcsSize == adam.n);
}

void test_cubane_self_match() {
    auto cubane = smsd::parseSMILES("C12C3C4C1C5C4C3C25");

    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;

    auto mcs = smsd::findMCS(cubane, cubane, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " n=" << cubane.n << " ";

    assert(mcsSize == cubane.n);
}

// ============================================================================
// Test 5: ATP / ADP MCS >= 27
//
// ATP and ADP share the adenine base, ribose sugar, and two phosphate groups.
// Their MCS should be at least 27 atoms (the ADP heavy-atom count).
// ============================================================================

void test_atp_adp_mcs() {
    // ATP: adenosine triphosphate
    auto atp = smsd::parseSMILES(
        "c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N");
    // ADP: adenosine diphosphate
    auto adp = smsd::parseSMILES(
        "c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)O)O)O)N");

    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 30000;

    auto mcs = smsd::findMCS(atp, adp, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " ";

    // ADP is a substructure of ATP; MCS should cover at least 27 atoms.
    assert(mcsSize >= 27);
}

// ============================================================================
// main
// ============================================================================

int main() {
    std::cout << "=== SMSD C++ Chemistry Tests ===\n";

    RUN_TEST(ring_fusion_strict_naphthalene_biphenyl);
    RUN_TEST(crown_ether_substructure);
    RUN_TEST(tautomer_keto_enol_mcs);
    RUN_TEST(adamantane_self_match);
    RUN_TEST(cubane_self_match);
    RUN_TEST(atp_adp_mcs);

    std::cout << "\n" << testsPassed << " passed, " << testsFailed << " failed\n";
    return testsFailed > 0 ? 1 : 0;
}
