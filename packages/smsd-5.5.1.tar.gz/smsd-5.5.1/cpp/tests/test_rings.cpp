/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * Tests for smsd::ring_finder.hpp — SSSR, RCB, and URF algorithms.
 */

#include "smsd/smiles_parser.hpp"
#include "smsd/ring_finder.hpp"
#include <cassert>
#include <cstdio>
#include <cstdlib>

static int g_pass = 0;
static int g_fail = 0;

#define TEST_ASSERT(cond, msg) do { \
    if (!(cond)) { \
        std::fprintf(stderr, "FAIL: %s  [%s:%d]\n", msg, __FILE__, __LINE__); \
        g_fail++; \
    } else { \
        g_pass++; \
    } \
} while(0)

#define TEST_ASSERT_EQ(actual, expected, msg) do { \
    auto _a = (actual); auto _e = (expected); \
    if (_a != _e) { \
        std::fprintf(stderr, "FAIL: %s  (got %d, expected %d)  [%s:%d]\n", \
                     msg, static_cast<int>(_a), static_cast<int>(_e), __FILE__, __LINE__); \
        g_fail++; \
    } else { \
        g_pass++; \
    } \
} while(0)

#define TEST_ASSERT_GEQ(actual, minimum, msg) do { \
    auto _a = (actual); auto _m = (minimum); \
    if (_a < _m) { \
        std::fprintf(stderr, "FAIL: %s  (got %d, expected >= %d)  [%s:%d]\n", \
                     msg, static_cast<int>(_a), static_cast<int>(_m), __FILE__, __LINE__); \
        g_fail++; \
    } else { \
        g_pass++; \
    } \
} while(0)

// -----------------------------------------------------------------------
// Benzene: 1 ring, 1 relevant cycle, 1 URF
// -----------------------------------------------------------------------
static void testBenzene() {
    auto g = smsd::parseSMILES("c1ccccc1");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "benzene MCB=1");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 1, "benzene RCB=1");

    auto urfs = smsd::computeURFs(g);
    TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 1, "benzene URF=1");
}

// -----------------------------------------------------------------------
// Naphthalene: 2 SSSR, 2 RCB (the 10-membered perimeter is NOT relevant), 2 URFs
// -----------------------------------------------------------------------
static void testNaphthalene() {
    auto g = smsd::parseSMILES("c1ccc2ccccc2c1");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 2, "naphthalene MCB=2");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 2, "naphthalene RCB=2");

    auto urfs = smsd::computeURFs(g);
    TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 2, "naphthalene URF=2");
}

// -----------------------------------------------------------------------
// Cubane: MCB=5, RCB=6, URF=1 (all 6 faces are symmetry-equivalent)
// -----------------------------------------------------------------------
static void testCubane() {
    auto g = smsd::parseSMILES("C12C3C4C1C5C4C3C25");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 5, "cubane MCB=5");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 6, "cubane RCB=6");

    auto urfs = smsd::computeURFs(g);
    TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 1, "cubane URF=1");
}

// -----------------------------------------------------------------------
// Adamantane: MCB=3 (bridged tricyclic), RCB=4
// -----------------------------------------------------------------------
static void testAdamantane() {
    auto g = smsd::parseSMILES("C1C2CC3CC1CC(C2)C3");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 3, "adamantane MCB=3");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 4, "adamantane RCB=4");
}

// -----------------------------------------------------------------------
// Norbornane (bicyclo[2.2.1]heptane): MCB=2, RCB=2
// -----------------------------------------------------------------------
static void testNorbornane() {
    auto g = smsd::parseSMILES("C1CC2CC1CC2");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 2, "norbornane MCB=2");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 2, "norbornane RCB=2");
}

// -----------------------------------------------------------------------
// Spiro[4.4]nonane: MCB=2, RCB=2, URF=2 (two rings share only 1 atom)
// -----------------------------------------------------------------------
static void testSpiro() {
    auto g = smsd::parseSMILES("C1CCC2(C1)CCCC2");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 2, "spiro MCB=2");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 2, "spiro RCB=2");

    auto urfs = smsd::computeURFs(g);
    TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 2, "spiro URF=2");
}

// -----------------------------------------------------------------------
// Anthracene: MCB=3, RCB>=3
// -----------------------------------------------------------------------
static void testAnthracene() {
    auto g = smsd::parseSMILES("c1ccc2cc3ccccc3cc2c1");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 3, "anthracene MCB=3");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_GEQ(static_cast<int>(rcb.size()), 3, "anthracene RCB>=3");
}

// -----------------------------------------------------------------------
// Butane (acyclic): MCB=0
// -----------------------------------------------------------------------
static void testButane() {
    auto g = smsd::parseSMILES("CCCC");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 0, "butane MCB=0");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 0, "butane RCB=0");

    auto urfs = smsd::computeURFs(g);
    TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 0, "butane URF=0");
}

// -----------------------------------------------------------------------
// Cyclopropane: MCB=1
// -----------------------------------------------------------------------
static void testCyclopropane() {
    auto g = smsd::parseSMILES("C1CC1");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "cyclopropane MCB=1");

    // Single 3-membered ring
    TEST_ASSERT_EQ(static_cast<int>(mcb[0].size()), 3, "cyclopropane ring size=3");
}

// -----------------------------------------------------------------------
// bfsPath basic test
// -----------------------------------------------------------------------
static void testBfsPath() {
    // Linear chain: 0-1-2-3
    auto g = smsd::parseSMILES("CCCC");

    // Path from 0 to 3 avoiding no particular edge (use non-existent edge)
    auto path = smsd::bfsPath(g, 0, 3, -1, -1);
    TEST_ASSERT_EQ(static_cast<int>(path.size()), 4, "bfsPath linear 0->3 len=4");
    TEST_ASSERT_EQ(path.front(), 0, "bfsPath start=0");
    TEST_ASSERT_EQ(path.back(), 3, "bfsPath end=3");

    // Path from 0 to 0 (trivial)
    auto trivial = smsd::bfsPath(g, 0, 0, -1, -1);
    TEST_ASSERT_EQ(static_cast<int>(trivial.size()), 1, "bfsPath trivial size=1");

    // Benzene: path from 0 to 3 avoiding edge 0-1
    auto benz = smsd::parseSMILES("C1CCCCC1");
    auto p2 = smsd::bfsPath(benz, 0, 1, 0, 1);
    // Should go the long way around
    TEST_ASSERT(static_cast<int>(p2.size()) > 2, "bfsPath benzene avoids direct edge");
}

// -----------------------------------------------------------------------
// Empty graph
// -----------------------------------------------------------------------
static void testEmptyGraph() {
    smsd::MolGraph g;
    g.n = 0;

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 0, "empty MCB=0");

    auto rcb = smsd::computeRelevantCycles(g);
    TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 0, "empty RCB=0");

    auto urfs = smsd::computeURFs(g);
    TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 0, "empty URF=0");
}

// -----------------------------------------------------------------------
// Cyclohexane (non-aromatic): MCB=1
// -----------------------------------------------------------------------
static void testCyclohexane() {
    auto g = smsd::parseSMILES("C1CCCCC1");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "cyclohexane MCB=1");
    TEST_ASSERT_EQ(static_cast<int>(mcb[0].size()), 6, "cyclohexane ring size=6");
}

// -----------------------------------------------------------------------
// Disconnected molecule: ethane + cyclopropane
// -----------------------------------------------------------------------
static void testDisconnected() {
    auto g = smsd::parseSMILES("CC.C1CC1");

    auto mcb = smsd::computeRings(g);
    TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "disconnected MCB=1");
}

// -----------------------------------------------------------------------
// main
// -----------------------------------------------------------------------
int main() {
    std::printf("=== Ring Finder Tests ===\n");

    testBfsPath();
    testEmptyGraph();
    testBenzene();
    testNaphthalene();
    testCubane();
    testAdamantane();
    testNorbornane();
    testSpiro();
    testAnthracene();
    testButane();
    testCyclopropane();
    testCyclohexane();
    testDisconnected();

    std::printf("\n=== Results: %d passed, %d failed ===\n", g_pass, g_fail);
    return g_fail > 0 ? 1 : 0;
}
