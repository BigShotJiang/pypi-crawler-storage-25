/*
 * SPDX-License-Identifier: Apache-2.0
 * (c) 2025-2026 BioInception PVT LTD.
 *
 * Header-only SMARTS pattern parser and matcher for smsd::MolGraph.
 * Zero external dependencies -- pure C++17 standard library.
 *
 * Supports:
 *   - Atom primitives: #n, A, a, D<n>, v<n>, R, r<n>, +/-, H<n>, *, elements
 *   - RDKit-parity extensions: z<n> (heteroatom neighbors), Z<n> (aliphatic
 *     heteroatom neighbors), d<n> (heavy degree), ^<n> (hybridization)
 *   - Range queries: {n-m}, {n-}, {-m} on numeric primitives
 *   - Logical operators: , (OR), & (AND high), ; (AND low), ! (NOT)
 *   - Bond primitives: - (single), = (double), # (triple), : (aromatic),
 *                       ~ (any), @ (ring bond), / (wedge), \ (dash)
 *   - Ring closures, branches ()
 *   - Recursive SMARTS: $(...)
 *   - Named predicate registry (SmartsPredicateRegistry) with 10 built-ins
 *   - VF2-style backtracking matcher
 */
#pragma once
#ifndef SMSD_SMARTS_PARSER_HPP
#define SMSD_SMARTS_PARSER_HPP

#include "mol_graph.hpp"

#include <algorithm>
#include <cassert>
#include <cctype>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <numeric>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace smsd {

// ============================================================================
// Forward declarations
// ============================================================================
struct SmartsQuery;
SmartsQuery parseSMARTS(const std::string& smarts);

// ============================================================================
// Element table for SMARTS (shared inline, same as smiles_parser)
// ============================================================================
namespace smarts_detail {

inline int elementToAtomicNum(const std::string& sym) {
    static const std::unordered_map<std::string, int> table = {
        {"*",0},
        {"H",1},{"He",2},
        {"Li",3},{"Be",4},{"B",5},{"C",6},{"N",7},{"O",8},{"F",9},{"Ne",10},
        {"Na",11},{"Mg",12},{"Al",13},{"Si",14},{"P",15},{"S",16},{"Cl",17},{"Ar",18},
        {"K",19},{"Ca",20},
        {"Sc",21},{"Ti",22},{"V",23},{"Cr",24},{"Mn",25},{"Fe",26},{"Co",27},{"Ni",28},
        {"Cu",29},{"Zn",30},{"Ga",31},{"Ge",32},{"As",33},{"Se",34},{"Br",35},{"Kr",36},
        {"Rb",37},{"Sr",38},
        {"Y",39},{"Zr",40},{"Nb",41},{"Mo",42},{"Tc",43},{"Ru",44},{"Rh",45},{"Pd",46},
        {"Ag",47},{"Cd",48},{"In",49},{"Sn",50},{"Sb",51},{"Te",52},{"I",53},{"Xe",54},
        {"Cs",55},{"Ba",56},
        {"La",57},{"Ce",58},{"Pr",59},{"Nd",60},{"Pm",61},{"Sm",62},{"Eu",63},{"Gd",64},
        {"Tb",65},{"Dy",66},{"Ho",67},{"Er",68},{"Tm",69},{"Yb",70},{"Lu",71},
        {"Hf",72},{"Ta",73},{"W",74},{"Re",75},{"Os",76},{"Ir",77},{"Pt",78},
        {"Au",79},{"Hg",80},{"Tl",81},{"Pb",82},{"Bi",83},{"Po",84},{"At",85},{"Rn",86},
        {"Fr",87},{"Ra",88},
        {"Ac",89},{"Th",90},{"Pa",91},{"U",92},{"Np",93},{"Pu",94},{"Am",95},{"Cm",96},
        {"Bk",97},{"Cf",98},{"Es",99},{"Fm",100},{"Md",101},{"No",102},{"Lr",103},
        {"Rf",104},{"Db",105},{"Sg",106},{"Bh",107},{"Hs",108},{"Mt",109},{"Ds",110},
        {"Rg",111},{"Cn",112},{"Nh",113},{"Fl",114},{"Mc",115},{"Lv",116},{"Ts",117},{"Og",118},
        // Aromatic lowercase forms
        {"b",5},{"c",6},{"n",7},{"o",8},{"p",15},{"s",16},{"se",34},{"te",52},
    };
    auto it = table.find(sym);
    return it != table.end() ? it->second : -1;
}

// ============================================================================
// Atom expression tree
// ============================================================================

enum class AtomPrimType {
    TRUE_,           // matches anything (wildcard)
    ATOMIC_NUM,      // #n
    ELEMENT,         // specific element (also encodes atomicNum)
    AROMATIC,        // a
    ALIPHATIC,       // A
    DEGREE,          // D<n>
    VALENCE,         // v<n>
    IN_RING,         // R (any ring) or R<n> (ring count)
    RING_SIZE,       // r<n>
    CHARGE,          // +n / -n
    HCOUNT,          // H<n>
    RING_CONNECTIVITY, // x<n>
    MASS,            // isotope
    RECURSIVE,       // $(...)
    HETERO_NEIGHBORS,          // z<n> — count of heteroatom neighbors (not C, not H)
    ALIPHATIC_HETERO_NEIGHBORS,// Z<n> — count of aliphatic heteroatom neighbors
    HEAVY_DEGREE,              // d<n> — non-hydrogen degree (heavy atom connections)
    HYBRIDIZATION,             // ^<n> — hybridization (0=S,1=SP,2=SP2,3=SP3,4=SP3D,5=SP3D2)
};

enum class ExprOp {
    PRIM,    // leaf
    AND,
    OR,
    NOT,
};

struct AtomExpr {
    ExprOp op = ExprOp::PRIM;

    // For PRIM:
    AtomPrimType primType = AtomPrimType::TRUE_;
    int intVal = 0;                // numeric value for the primitive
    bool hasValue = false;         // whether intVal is meaningful
    // Range query support: {min-max}  (rangeQuery == true overrides intVal)
    bool rangeQuery = false;       // true when {n-m} syntax was used
    int rangeMin = 0;              // minimum (inclusive), -1 = unbounded
    int rangeMax = 0;              // maximum (inclusive), -1 = unbounded
    // For RECURSIVE:
    std::string recursiveSmarts; // parsed lazily when evaluated

    // For AND/OR: children
    std::vector<AtomExpr> children;
    // For NOT: single child in children[0]

    static AtomExpr makePrim(AtomPrimType t, int val = 0, bool hasVal = false) {
        AtomExpr e;
        e.op = ExprOp::PRIM;
        e.primType = t;
        e.intVal = val;
        e.hasValue = hasVal;
        return e;
    }

    static AtomExpr makeNot(AtomExpr child) {
        AtomExpr e;
        e.op = ExprOp::NOT;
        e.children.push_back(std::move(child));
        return e;
    }

    static AtomExpr makeAnd(std::vector<AtomExpr> ch) {
        if (ch.size() == 1) return std::move(ch[0]);
        AtomExpr e;
        e.op = ExprOp::AND;
        e.children = std::move(ch);
        return e;
    }

    static AtomExpr makeOr(std::vector<AtomExpr> ch) {
        if (ch.size() == 1) return std::move(ch[0]);
        AtomExpr e;
        e.op = ExprOp::OR;
        e.children = std::move(ch);
        return e;
    }
};

// ============================================================================
// Bond expression tree
// ============================================================================

enum class BondPrimType {
    ANY,       // ~ or implicit (default)
    SINGLE,    // -
    DOUBLE,    // =
    TRIPLE,    // #
    AROMATIC,  // :
    RING,      // @
    WEDGE,     // / (up bond / E-Z stereo)
    DASH,      // \ (down bond / E-Z stereo)
    DEFAULT_,  // implicit bond (single or aromatic in aromatic context)
};

struct BondExpr {
    ExprOp op = ExprOp::PRIM;
    BondPrimType primType = BondPrimType::DEFAULT_;
    std::vector<BondExpr> children;

    static BondExpr makePrim(BondPrimType t) {
        BondExpr e;
        e.op = ExprOp::PRIM;
        e.primType = t;
        return e;
    }

    static BondExpr makeNot(BondExpr child) {
        BondExpr e;
        e.op = ExprOp::NOT;
        e.children.push_back(std::move(child));
        return e;
    }

    static BondExpr makeAnd(std::vector<BondExpr> ch) {
        if (ch.size() == 1) return std::move(ch[0]);
        BondExpr e;
        e.op = ExprOp::AND;
        e.children = std::move(ch);
        return e;
    }

    static BondExpr makeOr(std::vector<BondExpr> ch) {
        if (ch.size() == 1) return std::move(ch[0]);
        BondExpr e;
        e.op = ExprOp::OR;
        e.children = std::move(ch);
        return e;
    }
};

// ============================================================================
// SMARTS query atom and bond
// ============================================================================

struct SmartsAtom {
    AtomExpr expr;
    bool isAromatic = false;   // hint from lowercase symbol (for default bond)
};

struct SmartsBond {
    int from = -1;
    int to = -1;
    BondExpr expr;
};

// ============================================================================
// Compute valence for matching v<n> primitive
// ============================================================================
inline int computeValence(const MolGraph& g, int idx) {
    int val = 0;
    for (int nb : g.neighbors[idx]) {
        val += g.bondOrder(idx, nb);
    }
    return val;
}

// Compute total H count (we approximate: valence model)
// For organic subset: implicit H = default valence - explicit valence - abs(charge)
inline int computeHCount(const MolGraph& g, int idx) {
    // Default valences for common elements
    static const std::unordered_map<int, std::vector<int>> defaultValences = {
        {5,  {3}},       // B
        {6,  {4}},       // C
        {7,  {3}},       // N
        {8,  {2}},       // O
        {9,  {1}},       // F
        {14, {4}},       // Si
        {15, {3, 5}},    // P
        {16, {2, 4, 6}}, // S
        {17, {1}},       // Cl
        {32, {4}},       // Ge
        {33, {3, 5}},    // As
        {34, {2, 4, 6}}, // Se
        {35, {1}},       // Br
        {52, {2, 4, 6}}, // Te
        {53, {1, 3, 5, 7}}, // I
    };

    int z = g.atomicNum[idx];
    auto it = defaultValences.find(z);
    if (it == defaultValences.end()) return 0;

    int explicitVal = computeValence(g, idx);
    int charge = std::abs(g.formalCharge[idx]);

    // Find the smallest default valence >= explicitVal + charge
    for (int dv : it->second) {
        int hc = dv - explicitVal - charge;
        if (hc >= 0) return hc;
    }
    return 0;
}

// Compute ring membership count (how many SSSR rings the atom belongs to)
inline int computeRingMembership(const MolGraph& g, int idx) {
    g.ensureRingCounts();   // ringCount is lazy
    if (idx < static_cast<int>(g.ringCount.size()))
        return g.ringCount[idx];
    return g.ring[idx] ? 1 : 0;
}

// Compute smallest ring size containing atom
inline int computeSmallestRingSize(const MolGraph& g, int idx) {
    if (!g.ring[idx]) return 0;
    // BFS from idx to idx through ring bonds to find shortest cycle
    // Use BFS distance to each neighbor, excluding direct edge
    int best = 999;
    for (int nb : g.neighbors[idx]) {
        if (!g.bondInRing(idx, nb)) continue;
        // BFS from nb to idx, not going through direct edge idx-nb
        std::vector<int> dist(g.n, -1);
        dist[nb] = 1;
        std::deque<int> queue;
        queue.push_back(nb);
        bool found = false;
        while (!queue.empty() && !found) {
            int u = queue.front(); queue.pop_front();
            for (int v : g.neighbors[u]) {
                if (u == nb && v == idx) continue;  // skip the direct edge
                if (v == idx) {
                    int ringSize = dist[u] + 1;
                    if (ringSize < best) best = ringSize;
                    found = true;
                    break;
                }
                if (dist[v] == -1) {
                    dist[v] = dist[u] + 1;
                    queue.push_back(v);
                }
            }
        }
    }
    return best < 999 ? best : 0;
}

// Compute ring connectivity (total ring bonds on atom)
inline int computeRingConnectivity(const MolGraph& g, int idx) {
    int rc = 0;
    for (int nb : g.neighbors[idx]) {
        if (g.bondInRing(idx, nb)) rc++;
    }
    return rc;
}

// Compute heteroatom neighbor count (atoms where atomicNum != 6 && atomicNum != 1)
inline int computeHeteroNeighbors(const MolGraph& g, int idx) {
    int count = 0;
    for (int nb : g.neighbors[idx]) {
        int z = g.atomicNum[nb];
        if (z != 6 && z != 1) count++;
    }
    return count;
}

// Compute aliphatic heteroatom neighbor count (heteroatom neighbors that are not aromatic)
inline int computeAliphaticHeteroNeighbors(const MolGraph& g, int idx) {
    int count = 0;
    for (int nb : g.neighbors[idx]) {
        int z = g.atomicNum[nb];
        if (z != 6 && z != 1 && !g.aromatic[nb]) count++;
    }
    return count;
}

// Compute heavy degree (number of non-hydrogen neighbors)
inline int computeHeavyDegree(const MolGraph& g, int idx) {
    int count = 0;
    for (int nb : g.neighbors[idx]) {
        if (g.atomicNum[nb] != 1) count++;
    }
    return count;
}

// Compute hybridization from bond orders and aromaticity.
// Returns: 0=S, 1=SP, 2=SP2, 3=SP3, 4=SP3D, 5=SP3D2
inline int computeHybridization(const MolGraph& g, int idx) {
    if (g.aromatic[idx]) return 2; // aromatic => SP2

    int nDouble = 0, nTriple = 0;
    for (int nb : g.neighbors[idx]) {
        int bo = g.bondOrder(idx, nb);
        if (bo == 2) nDouble++;
        else if (bo == 3) nTriple++;
    }

    if (nTriple >= 1 || nDouble >= 2) return 1; // SP
    if (nDouble == 1) return 2;                   // SP2
    return 3;                                      // SP3
}

// ============================================================================
// Expression evaluation
// ============================================================================

// Forward declarations
inline bool evalAtomExpr(const AtomExpr& expr, const MolGraph& g, int idx);
inline bool evalRecursiveSmarts(const AtomExpr& expr, const MolGraph& g, int idx);

// Helper: compare a computed value against an exact value or range
inline bool matchNumeric(const AtomExpr& expr, int computed) {
    if (expr.rangeQuery) {
        bool ok = true;
        if (expr.rangeMin >= 0) ok = ok && (computed >= expr.rangeMin);
        if (expr.rangeMax >= 0) ok = ok && (computed <= expr.rangeMax);
        return ok;
    }
    return computed == expr.intVal;
}

inline bool evalAtomPrim(const AtomExpr& expr, const MolGraph& g, int idx) {
    switch (expr.primType) {
        case AtomPrimType::TRUE_:
            return true;

        case AtomPrimType::ATOMIC_NUM:
            return g.atomicNum[idx] == expr.intVal;

        case AtomPrimType::ELEMENT:
            return g.atomicNum[idx] == expr.intVal;

        case AtomPrimType::AROMATIC:
            return g.aromatic[idx];

        case AtomPrimType::ALIPHATIC:
            return !g.aromatic[idx];

        case AtomPrimType::DEGREE:
            return matchNumeric(expr, g.degree[idx]);

        case AtomPrimType::VALENCE:
            return matchNumeric(expr, computeValence(g, idx));

        case AtomPrimType::IN_RING:
            if (!expr.hasValue && !expr.rangeQuery) return g.ring[idx];
            if (!expr.rangeQuery && expr.intVal == 0) return !g.ring[idx];
            return matchNumeric(expr, computeRingMembership(g, idx));

        case AtomPrimType::RING_SIZE:
            if (!expr.hasValue && !expr.rangeQuery) return g.ring[idx];
            return matchNumeric(expr, computeSmallestRingSize(g, idx));

        case AtomPrimType::CHARGE:
            return g.formalCharge[idx] == expr.intVal;

        case AtomPrimType::HCOUNT:
            return matchNumeric(expr, computeHCount(g, idx));

        case AtomPrimType::RING_CONNECTIVITY:
            if (!expr.hasValue && !expr.rangeQuery) return computeRingConnectivity(g, idx) > 0;
            return matchNumeric(expr, computeRingConnectivity(g, idx));

        case AtomPrimType::MASS:
            return g.massNumber[idx] == expr.intVal;

        case AtomPrimType::RECURSIVE:
            // Deferred to evalRecursiveSmarts() defined after SmartsQuery
            return evalRecursiveSmarts(expr, g, idx);

        case AtomPrimType::HETERO_NEIGHBORS:
            if (!expr.hasValue && !expr.rangeQuery) return computeHeteroNeighbors(g, idx) >= 1;
            return matchNumeric(expr, computeHeteroNeighbors(g, idx));

        case AtomPrimType::ALIPHATIC_HETERO_NEIGHBORS:
            if (!expr.hasValue && !expr.rangeQuery) return computeAliphaticHeteroNeighbors(g, idx) >= 1;
            return matchNumeric(expr, computeAliphaticHeteroNeighbors(g, idx));

        case AtomPrimType::HEAVY_DEGREE:
            return matchNumeric(expr, computeHeavyDegree(g, idx));

        case AtomPrimType::HYBRIDIZATION:
            return computeHybridization(g, idx) == expr.intVal;
    }
    return false;
}

inline bool evalAtomExpr(const AtomExpr& expr, const MolGraph& g, int idx) {
    switch (expr.op) {
        case ExprOp::PRIM:
            return evalAtomPrim(expr, g, idx);

        case ExprOp::AND:
            for (auto& child : expr.children) {
                if (!evalAtomExpr(child, g, idx)) return false;
            }
            return true;

        case ExprOp::OR:
            for (auto& child : expr.children) {
                if (evalAtomExpr(child, g, idx)) return true;
            }
            return false;

        case ExprOp::NOT:
            return !evalAtomExpr(expr.children[0], g, idx);
    }
    return false;
}

inline bool evalBondPrim(const BondExpr& expr, const MolGraph& g, int i, int j) {
    switch (expr.primType) {
        case BondPrimType::ANY:
            return true;

        case BondPrimType::SINGLE:
            return g.bondOrder(i, j) == 1 && !g.bondAromatic(i, j);

        case BondPrimType::DOUBLE:
            return g.bondOrder(i, j) == 2;

        case BondPrimType::TRIPLE:
            return g.bondOrder(i, j) == 3;

        case BondPrimType::AROMATIC:
            return g.bondAromatic(i, j) || g.bondOrder(i, j) == 4;

        case BondPrimType::RING:
            return g.bondInRing(i, j);

        case BondPrimType::WEDGE:
            // TODO: Full E/Z stereo matching requires per-bond direction
            // storage in MolGraph. For now, WEDGE matches any bond (same as ~).
            return true;

        case BondPrimType::DASH:
            // TODO: Full E/Z stereo matching requires per-bond direction
            // storage in MolGraph. For now, DASH matches any bond (same as ~).
            return true;

        case BondPrimType::DEFAULT_:
            // Default: single or aromatic
            return g.hasBond(i, j);
    }
    return false;
}

inline bool evalBondExpr(const BondExpr& expr, const MolGraph& g, int i, int j) {
    switch (expr.op) {
        case ExprOp::PRIM:
            return evalBondPrim(expr, g, i, j);

        case ExprOp::AND:
            for (auto& child : expr.children) {
                if (!evalBondExpr(child, g, i, j)) return false;
            }
            return true;

        case ExprOp::OR:
            for (auto& child : expr.children) {
                if (evalBondExpr(child, g, i, j)) return true;
            }
            return false;

        case ExprOp::NOT:
            return !evalBondExpr(expr.children[0], g, i, j);
    }
    return false;
}

// ============================================================================
// SMARTS parser
// ============================================================================

class SmartsParser {
    const std::string& smarts_;
    int pos_ = 0;

    char peek() const {
        if (pos_ >= static_cast<int>(smarts_.size())) return '\0';
        return smarts_[pos_];
    }

    char advance() {
        if (pos_ >= static_cast<int>(smarts_.size())) return '\0';
        return smarts_[pos_++];
    }

    bool match(char c) {
        if (peek() == c) { pos_++; return true; }
        return false;
    }

    int parseDigits() {
        int val = 0;
        bool gotDigit = false;
        while (pos_ < static_cast<int>(smarts_.size()) && std::isdigit(peek())) {
            val = val * 10 + (advance() - '0');
            gotDigit = true;
        }
        return gotDigit ? val : -1;
    }

    // Try to parse a range query {min-max}, {min-}, or {-max}.
    // Returns true if a range was parsed; fills min/max (-1 = unbounded).
    bool tryParseRange(int& rmin, int& rmax) {
        if (peek() != '{') return false;
        int saved = pos_;
        advance(); // consume '{'
        rmin = -1;
        rmax = -1;
        int d = parseDigits();
        if (d >= 0) rmin = d;
        if (peek() == '-') {
            advance(); // consume '-'
            d = parseDigits();
            if (d >= 0) rmax = d;
        } else {
            // {n} without dash means exact match: min == max
            if (rmin >= 0) rmax = rmin;
        }
        if (peek() == '}') {
            advance(); // consume '}'
            return true;
        }
        // Not a valid range, rewind
        pos_ = saved;
        return false;
    }

    // After parsing a numeric primitive, check for optional range {n-m}.
    // If range found, set expr fields accordingly. Otherwise keep exact value.
    void applyOptionalRange(AtomExpr& expr) {
        int rmin, rmax;
        if (tryParseRange(rmin, rmax)) {
            expr.rangeQuery = true;
            expr.rangeMin = rmin;
            expr.rangeMax = rmax;
            expr.hasValue = true;
        }
    }

    // Check if current position starts a two-letter element (e.g., Al, Br, Cl)
    bool isTwoLetterElement(char upper) const {
        if (pos_ + 1 >= static_cast<int>(smarts_.size())) return false;
        char next = smarts_[pos_ + 1];
        if (!std::islower(next)) return false;
        std::string twoChar{upper, next};
        return elementToAtomicNum(twoChar) >= 0;
    }

    // Parse an element symbol (uppercase or lowercase, 1 or 2 chars)
    AtomExpr parseElementSymbol() {
        char c = peek();
        if (std::isupper(c)) {
            advance();
            std::string sym(1, c);
            if (pos_ < static_cast<int>(smarts_.size()) && std::islower(peek())) {
                std::string twoChar = sym + peek();
                if (elementToAtomicNum(twoChar) >= 0) {
                    sym = twoChar;
                    advance();
                }
            }
            int z = elementToAtomicNum(sym);
            if (z < 0) throw std::invalid_argument("Unknown element in SMARTS: " + sym);
            return AtomExpr::makePrim(AtomPrimType::ELEMENT, z, true);
        }
        if (std::islower(c)) {
            advance();
            std::string sym(1, c);
            if (pos_ < static_cast<int>(smarts_.size()) && std::islower(peek())) {
                std::string twoChar = sym + peek();
                if (elementToAtomicNum(twoChar) >= 0) {
                    sym = twoChar;
                    advance();
                }
            }
            int z = elementToAtomicNum(sym);
            if (z < 0) throw std::invalid_argument("Unknown aromatic element in SMARTS: " + sym);
            // Aromatic element: AND(element, aromatic)
            std::vector<AtomExpr> parts;
            parts.push_back(AtomExpr::makePrim(AtomPrimType::ELEMENT, z, true));
            parts.push_back(AtomExpr::makePrim(AtomPrimType::AROMATIC));
            return AtomExpr::makeAnd(std::move(parts));
        }
        throw std::invalid_argument(
            std::string("Expected element symbol in SMARTS at '") + c + "'");
    }

    // Parse a single atom primitive inside brackets
    AtomExpr parsePrimitive() {
        char c = peek();

        // # followed by digits = atomic number
        if (c == '#') {
            advance();
            int num = parseDigits();
            if (num < 0) throw std::invalid_argument("Expected number after # in SMARTS");
            return AtomExpr::makePrim(AtomPrimType::ATOMIC_NUM, num, true);
        }

        // * = any atom
        if (c == '*') {
            advance();
            return AtomExpr::makePrim(AtomPrimType::TRUE_);
        }

        // A = aliphatic (but Al, Ag, As, Au, Ac, Am, Ar, At = elements)
        if (c == 'A') {
            if (isTwoLetterElement('A')) return parseElementSymbol();
            advance();
            return AtomExpr::makePrim(AtomPrimType::ALIPHATIC);
        }

        // a = aromatic atom primitive
        if (c == 'a') {
            advance();
            return AtomExpr::makePrim(AtomPrimType::AROMATIC);
        }

        // D = degree (but Dy, Db, Ds = elements)
        if (c == 'D') {
            if (isTwoLetterElement('D')) return parseElementSymbol();
            advance();
            int num = parseDigits();
            if (num < 0) num = 1;  // D without number = D1
            auto expr = AtomExpr::makePrim(AtomPrimType::DEGREE, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // d = heavy degree (non-hydrogen degree) — inside brackets only
        // Note: 'd' could be deuterium in some contexts but we treat it as
        // a primitive inside bracket atoms (like RDKit).
        if (c == 'd') {
            advance();
            int num = parseDigits();
            if (num < 0) num = 1;  // d without number = d1
            auto expr = AtomExpr::makePrim(AtomPrimType::HEAVY_DEGREE, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // v = valence
        if (c == 'v') {
            advance();
            int num = parseDigits();
            if (num < 0) num = 1;
            auto expr = AtomExpr::makePrim(AtomPrimType::VALENCE, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // R = ring membership (but Rb, Re, Rf, Rg, Rh, Rn, Ru = elements)
        if (c == 'R') {
            if (isTwoLetterElement('R')) return parseElementSymbol();
            advance();
            int num = parseDigits();
            if (num < 0) {
                auto expr = AtomExpr::makePrim(AtomPrimType::IN_RING, 0, false);
                applyOptionalRange(expr);
                return expr;
            }
            auto expr = AtomExpr::makePrim(AtomPrimType::IN_RING, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // r = ring size
        if (c == 'r') {
            advance();
            int num = parseDigits();
            if (num < 0) {
                auto expr = AtomExpr::makePrim(AtomPrimType::RING_SIZE, 0, false);
                applyOptionalRange(expr);
                return expr;
            }
            auto expr = AtomExpr::makePrim(AtomPrimType::RING_SIZE, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // x = ring connectivity
        if (c == 'x') {
            advance();
            int num = parseDigits();
            if (num < 0) {
                auto expr = AtomExpr::makePrim(AtomPrimType::RING_CONNECTIVITY, 0, false);
                applyOptionalRange(expr);
                return expr;
            }
            auto expr = AtomExpr::makePrim(AtomPrimType::RING_CONNECTIVITY, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // z = heteroatom neighbor count
        if (c == 'z') {
            advance();
            int num = parseDigits();
            if (num < 0) {
                // z without number = at least 1 heteroatom neighbor
                auto expr = AtomExpr::makePrim(AtomPrimType::HETERO_NEIGHBORS, 0, false);
                applyOptionalRange(expr);
                return expr;
            }
            auto expr = AtomExpr::makePrim(AtomPrimType::HETERO_NEIGHBORS, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // Z = aliphatic heteroatom neighbor count (but Zn, Zr = elements)
        // Only treat as primitive inside brackets when followed by digit, '{', or
        // at end/delimiter position (not followed by lowercase letter forming element).
        if (c == 'Z') {
            if (isTwoLetterElement('Z')) return parseElementSymbol();
            advance();
            int num = parseDigits();
            if (num < 0) {
                auto expr = AtomExpr::makePrim(AtomPrimType::ALIPHATIC_HETERO_NEIGHBORS, 0, false);
                applyOptionalRange(expr);
                return expr;
            }
            auto expr = AtomExpr::makePrim(AtomPrimType::ALIPHATIC_HETERO_NEIGHBORS, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // ^ = hybridization (^0=S, ^1=SP, ^2=SP2, ^3=SP3, ^4=SP3D, ^5=SP3D2)
        if (c == '^') {
            advance();
            int num = parseDigits();
            if (num < 0 || num > 5) {
                throw std::invalid_argument("Expected digit 0-5 after ^ in SMARTS hybridization");
            }
            return AtomExpr::makePrim(AtomPrimType::HYBRIDIZATION, num, true);
        }

        // + = positive charge
        if (c == '+') {
            advance();
            int num = parseDigits();
            if (num < 0) {
                num = 1;
                while (peek() == '+') { advance(); num++; }
            }
            return AtomExpr::makePrim(AtomPrimType::CHARGE, num, true);
        }

        // - = negative charge (inside brackets only, not a bond)
        if (c == '-') {
            advance();
            int num = parseDigits();
            if (num < 0) {
                num = 1;
                while (peek() == '-') { advance(); num++; }
            }
            return AtomExpr::makePrim(AtomPrimType::CHARGE, -num, true);
        }

        // H = hydrogen count (but Hf, Hg, Ho, Hs = elements)
        if (c == 'H') {
            if (pos_ + 1 < static_cast<int>(smarts_.size())) {
                char next = smarts_[pos_ + 1];
                if (next == 'f' || next == 'g' || next == 'o' || next == 's') {
                    return parseElementSymbol();
                }
            }
            advance();
            int num = parseDigits();
            if (num < 0) num = 1;  // H without number = H1
            auto expr = AtomExpr::makePrim(AtomPrimType::HCOUNT, num, true);
            applyOptionalRange(expr);
            return expr;
        }

        // $ = recursive SMARTS
        if (c == '$') {
            advance();
            if (peek() != '(') throw std::invalid_argument("Expected '(' after '$' in recursive SMARTS");
            advance(); // consume '('
            int depth = 1;
            int start = pos_;
            while (pos_ < static_cast<int>(smarts_.size()) && depth > 0) {
                if (smarts_[pos_] == '(') depth++;
                else if (smarts_[pos_] == ')') depth--;
                if (depth > 0) pos_++;
            }
            if (depth != 0) throw std::invalid_argument("Unmatched '(' in recursive SMARTS");
            std::string subSmarts = smarts_.substr(start, pos_ - start);
            advance(); // consume ')'

            AtomExpr expr;
            expr.op = ExprOp::PRIM;
            expr.primType = AtomPrimType::RECURSIVE;
            expr.recursiveSmarts = subSmarts; // parsed lazily in evalRecursiveSmarts
            return expr;
        }

        // Element symbol (uppercase or lowercase)
        if (std::isalpha(c)) {
            return parseElementSymbol();
        }

        // Isotope: digits at the start of a bracket atom
        if (std::isdigit(c)) {
            int num = parseDigits();
            return AtomExpr::makePrim(AtomPrimType::MASS, num, true);
        }

        throw std::invalid_argument(
            std::string("Unexpected character in SMARTS atom: '") + c + "'");
    }

    // Parse NOT-level: !prim
    AtomExpr parseNotExpr() {
        if (peek() == '!') {
            advance();
            return AtomExpr::makeNot(parseNotExpr());
        }
        return parsePrimitive();
    }

    // Parse AND-high: prim & prim & ... (implicit AND between consecutive primitives)
    AtomExpr parseAndHigh() {
        std::vector<AtomExpr> parts;
        parts.push_back(parseNotExpr());

        while (pos_ < static_cast<int>(smarts_.size())) {
            char c = peek();
            if (c == '&') {
                advance();
                parts.push_back(parseNotExpr());
            } else if (c == ',' || c == ';' || c == ']' || c == '\0') {
                break;
            } else {
                // Implicit AND: adjacent primitives
                parts.push_back(parseNotExpr());
            }
        }
        return AtomExpr::makeAnd(std::move(parts));
    }

    // Parse OR: ... , ...
    AtomExpr parseOr() {
        std::vector<AtomExpr> parts;
        parts.push_back(parseAndHigh());

        while (peek() == ',') {
            advance();
            parts.push_back(parseAndHigh());
        }
        return AtomExpr::makeOr(std::move(parts));
    }

    // Parse AND-low (semicolon): ... ; ...
    AtomExpr parseAndLow() {
        std::vector<AtomExpr> parts;
        parts.push_back(parseOr());

        while (peek() == ';') {
            advance();
            parts.push_back(parseOr());
        }
        return AtomExpr::makeAnd(std::move(parts));
    }

    // Parse bracket atom expression: everything between [ and ]
    AtomExpr parseBracketAtomExpr() {
        return parseAndLow();
    }

    // Parse a bond expression
    BondExpr parseBondExpr() {
        std::vector<BondExpr> parts;

        while (pos_ < static_cast<int>(smarts_.size())) {
            char c = peek();
            BondExpr be;
            bool gotBond = false;

            if (c == '!') {
                advance();
                be = BondExpr::makeNot(parseSingleBond());
                gotBond = true;
            } else if (c == '-') {
                advance();
                be = BondExpr::makePrim(BondPrimType::SINGLE);
                gotBond = true;
            } else if (c == '=') {
                advance();
                be = BondExpr::makePrim(BondPrimType::DOUBLE);
                gotBond = true;
            } else if (c == '#') {
                advance();
                be = BondExpr::makePrim(BondPrimType::TRIPLE);
                gotBond = true;
            } else if (c == ':') {
                advance();
                be = BondExpr::makePrim(BondPrimType::AROMATIC);
                gotBond = true;
            } else if (c == '~') {
                advance();
                be = BondExpr::makePrim(BondPrimType::ANY);
                gotBond = true;
            } else if (c == '@') {
                advance();
                be = BondExpr::makePrim(BondPrimType::RING);
                gotBond = true;
            } else if (c == '/') {
                advance();
                be = BondExpr::makePrim(BondPrimType::WEDGE);
                gotBond = true;
            } else if (c == '\\') {
                advance();
                be = BondExpr::makePrim(BondPrimType::DASH);
                gotBond = true;
            } else {
                break;
            }

            if (gotBond) {
                // Check for logical operators between bonds
                if (peek() == ',') {
                    // OR: collect all OR'd bonds
                    std::vector<BondExpr> orParts;
                    orParts.push_back(std::move(be));
                    while (peek() == ',') {
                        advance();
                        orParts.push_back(parseSingleBond());
                    }
                    parts.push_back(BondExpr::makeOr(std::move(orParts)));
                } else {
                    parts.push_back(std::move(be));
                }
            }
        }

        if (parts.empty()) return BondExpr::makePrim(BondPrimType::DEFAULT_);
        if (parts.size() == 1) return std::move(parts[0]);
        return BondExpr::makeAnd(std::move(parts));
    }

    BondExpr parseSingleBond() {
        char c = peek();
        if (c == '!') {
            advance();
            return BondExpr::makeNot(parseSingleBond());
        }
        if (c == '-') { advance(); return BondExpr::makePrim(BondPrimType::SINGLE); }
        if (c == '=') { advance(); return BondExpr::makePrim(BondPrimType::DOUBLE); }
        if (c == '#') { advance(); return BondExpr::makePrim(BondPrimType::TRIPLE); }
        if (c == ':') { advance(); return BondExpr::makePrim(BondPrimType::AROMATIC); }
        if (c == '~') { advance(); return BondExpr::makePrim(BondPrimType::ANY); }
        if (c == '@') { advance(); return BondExpr::makePrim(BondPrimType::RING); }
        if (c == '/') { advance(); return BondExpr::makePrim(BondPrimType::WEDGE); }
        if (c == '\\') { advance(); return BondExpr::makePrim(BondPrimType::DASH); }
        return BondExpr::makePrim(BondPrimType::DEFAULT_);
    }

    bool isBondChar(char c) const {
        return c == '-' || c == '=' || c == '#' || c == ':' || c == '~'
            || c == '@' || c == '!' || c == '/' || c == '\\';
    }

    bool isAtomStart(char c) const {
        return c == '[' || c == '*' || std::isalpha(c);
    }

public:
    SmartsParser(const std::string& smarts) : smarts_(smarts) {}

    // Parse the full SMARTS string into atoms and bonds
    void parse(std::vector<SmartsAtom>& atoms, std::vector<SmartsBond>& bonds) {
        if (smarts_.empty()) return;

        std::vector<int> branchStack;   // stack of parent atom indices
        int currentAtom = -1;
        std::unordered_map<int, std::pair<int, BondExpr>> ringClosures;
        BondExpr pendingBond;
        bool hasPendingBond = false;

        while (pos_ < static_cast<int>(smarts_.size())) {
            char c = peek();

            if (c == '(') {
                advance();
                branchStack.push_back(currentAtom);
                hasPendingBond = false;
                continue;
            }

            if (c == ')') {
                advance();
                if (branchStack.empty()) {
                    throw std::invalid_argument("Unmatched ')' in SMARTS");
                }
                currentAtom = branchStack.back();
                branchStack.pop_back();
                hasPendingBond = false;
                continue;
            }

            // Bond symbol?
            if (isBondChar(c)) {
                pendingBond = parseBondExpr();
                hasPendingBond = true;
                continue;
            }

            // Ring closure digit or %nn
            if (std::isdigit(c) || c == '%') {
                int ringNum;
                if (c == '%') {
                    advance();
                    ringNum = parseDigits();
                    if (ringNum < 0) throw std::invalid_argument("Expected digits after % in ring closure");
                } else {
                    ringNum = advance() - '0';
                }

                if (currentAtom < 0) {
                    throw std::invalid_argument("Ring closure before any atom");
                }

                auto it = ringClosures.find(ringNum);
                if (it != ringClosures.end()) {
                    // Close the ring
                    SmartsBond bond;
                    bond.from = it->second.first;
                    bond.to = currentAtom;
                    // Use the bond from open if it had one, or the current pending bond
                    if (hasPendingBond) {
                        bond.expr = std::move(pendingBond);
                        hasPendingBond = false;
                    } else if (it->second.second.primType != BondPrimType::DEFAULT_
                               || it->second.second.op != ExprOp::PRIM) {
                        bond.expr = std::move(it->second.second);
                    } else {
                        bond.expr = BondExpr::makePrim(BondPrimType::DEFAULT_);
                    }
                    bonds.push_back(std::move(bond));
                    ringClosures.erase(it);
                } else {
                    // Open the ring
                    BondExpr ringBondExpr = hasPendingBond
                        ? std::move(pendingBond)
                        : BondExpr::makePrim(BondPrimType::DEFAULT_);
                    hasPendingBond = false;
                    ringClosures[ringNum] = {currentAtom, std::move(ringBondExpr)};
                }
                continue;
            }

            // Atom: [ bracket atom ] or organic shorthand
            if (c == '[') {
                advance(); // consume [

                SmartsAtom atom;
                atom.expr = parseBracketAtomExpr();

                if (peek() != ']') {
                    throw std::invalid_argument(
                        "Expected ']' in bracket atom at pos " + std::to_string(pos_));
                }
                advance(); // consume ]

                int newIdx = static_cast<int>(atoms.size());
                atoms.push_back(std::move(atom));

                if (currentAtom >= 0) {
                    SmartsBond bond;
                    bond.from = currentAtom;
                    bond.to = newIdx;
                    bond.expr = hasPendingBond
                        ? std::move(pendingBond)
                        : BondExpr::makePrim(BondPrimType::DEFAULT_);
                    hasPendingBond = false;
                    bonds.push_back(std::move(bond));
                }
                currentAtom = newIdx;
                continue;
            }

            // Organic shorthand atoms: B C N O P S F Cl Br I * and aromatic b c n o p s
            if (c == '*') {
                advance();
                SmartsAtom atom;
                atom.expr = AtomExpr::makePrim(AtomPrimType::TRUE_);
                int newIdx = static_cast<int>(atoms.size());
                atoms.push_back(std::move(atom));

                if (currentAtom >= 0) {
                    SmartsBond bond;
                    bond.from = currentAtom;
                    bond.to = newIdx;
                    bond.expr = hasPendingBond
                        ? std::move(pendingBond)
                        : BondExpr::makePrim(BondPrimType::DEFAULT_);
                    hasPendingBond = false;
                    bonds.push_back(std::move(bond));
                }
                currentAtom = newIdx;
                continue;
            }

            if (std::isalpha(c)) {
                bool aromatic = std::islower(c);
                std::string sym(1, c);
                advance();

                if (pos_ < static_cast<int>(smarts_.size()) && std::islower(peek())) {
                    std::string twoChar = sym + peek();
                    if (elementToAtomicNum(twoChar) >= 0) {
                        sym = twoChar;
                        advance();
                    }
                }

                int z = elementToAtomicNum(sym);
                if (z < 0) {
                    throw std::invalid_argument("Unknown element in SMARTS: " + sym);
                }

                SmartsAtom atom;
                atom.isAromatic = aromatic;
                if (aromatic) {
                    std::vector<AtomExpr> parts;
                    parts.push_back(AtomExpr::makePrim(AtomPrimType::ELEMENT, z, true));
                    parts.push_back(AtomExpr::makePrim(AtomPrimType::AROMATIC));
                    atom.expr = AtomExpr::makeAnd(std::move(parts));
                } else {
                    // Aliphatic organic atom: element AND aliphatic
                    std::vector<AtomExpr> parts;
                    parts.push_back(AtomExpr::makePrim(AtomPrimType::ELEMENT, z, true));
                    parts.push_back(AtomExpr::makePrim(AtomPrimType::ALIPHATIC));
                    atom.expr = AtomExpr::makeAnd(std::move(parts));
                }

                int newIdx = static_cast<int>(atoms.size());
                atoms.push_back(std::move(atom));

                if (currentAtom >= 0) {
                    SmartsBond bond;
                    bond.from = currentAtom;
                    bond.to = newIdx;
                    bond.expr = hasPendingBond
                        ? std::move(pendingBond)
                        : BondExpr::makePrim(BondPrimType::DEFAULT_);
                    hasPendingBond = false;
                    bonds.push_back(std::move(bond));
                }
                currentAtom = newIdx;
                continue;
            }

            // Skip whitespace
            if (std::isspace(static_cast<unsigned char>(c))) {
                advance();
                continue;
            }

            // Dot (disconnected)
            if (c == '.') {
                advance();
                currentAtom = -1;
                hasPendingBond = false;
                continue;
            }

            throw std::invalid_argument(
                std::string("Unexpected character in SMARTS: '") + c
                + "' at position " + std::to_string(pos_));
        }

        if (!branchStack.empty()) {
            throw std::invalid_argument("Unmatched '(' in SMARTS");
        }
        if (!ringClosures.empty()) {
            throw std::invalid_argument("Unclosed ring in SMARTS");
        }
    }
};

} // namespace smarts_detail

// ============================================================================
// SmartsQuery -- the parsed SMARTS pattern
// ============================================================================

struct SmartsQuery {
    std::vector<smarts_detail::SmartsAtom> atoms;
    std::vector<smarts_detail::SmartsBond> bonds;

    // Adjacency for the query graph
    std::vector<std::vector<int>> neighbors;   // neighbor atom indices
    std::vector<std::vector<int>> bondIndices;  // parallel to neighbors: bond index

    int atomCount() const { return static_cast<int>(atoms.size()); }

    // Build adjacency from atoms/bonds
    void buildAdjacency() {
        int n = atomCount();
        neighbors.assign(n, {});
        bondIndices.assign(n, {});
        for (int bi = 0; bi < static_cast<int>(bonds.size()); bi++) {
            int a = bonds[bi].from, b = bonds[bi].to;
            neighbors[a].push_back(b);
            neighbors[b].push_back(a);
            bondIndices[a].push_back(bi);
            bondIndices[b].push_back(bi);
        }
    }

    // ------------------------------------------------------------------
    // VF2-style backtracking matcher
    // ------------------------------------------------------------------

    bool atomCompat(int qi, const MolGraph& target, int ti) const {
        return smarts_detail::evalAtomExpr(atoms[qi].expr, target, ti);
    }

    bool bondCompat(int bi, const MolGraph& target, int ti, int tj) const {
        return smarts_detail::evalBondExpr(bonds[bi].expr, target, ti, tj);
    }

    // Find a matching order (simple: BFS from atom 0)
    std::vector<int> matchingOrder() const {
        int n = atomCount();
        if (n == 0) return {};
        std::vector<int> order;
        order.reserve(n);
        std::vector<bool> visited(n, false);
        std::deque<int> queue;
        queue.push_back(0);
        visited[0] = true;
        while (!queue.empty()) {
            int u = queue.front(); queue.pop_front();
            order.push_back(u);
            for (int v : neighbors[u]) {
                if (!visited[v]) {
                    visited[v] = true;
                    queue.push_back(v);
                }
            }
        }
        // Handle disconnected components
        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                visited[i] = true;
                queue.push_back(i);
                while (!queue.empty()) {
                    int u = queue.front(); queue.pop_front();
                    order.push_back(u);
                    for (int v : neighbors[u]) {
                        if (!visited[v]) {
                            visited[v] = true;
                            queue.push_back(v);
                        }
                    }
                }
            }
        }
        return order;
    }

    // Backtracking search: find one or all matches
    void backtrack(const MolGraph& target,
                   const std::vector<int>& order,
                   int pos,
                   std::vector<int>& q2t,
                   std::vector<bool>& tUsed,
                   std::vector<std::map<int,int>>& results,
                   int maxMatches) const {
        if (static_cast<int>(results.size()) >= maxMatches) return;

        int qn = atomCount();
        if (pos == qn) {
            std::map<int,int> mapping;
            for (int i = 0; i < qn; i++) mapping[i] = q2t[i];
            results.push_back(std::move(mapping));
            return;
        }

        int qi = order[pos];

        // Determine candidate target atoms
        // If qi has already-matched neighbors, constrain to their target neighbors
        std::vector<int> candidates;
        bool constrained = false;

        for (size_t ni = 0; ni < neighbors[qi].size(); ni++) {
            int qk = neighbors[qi][ni];
            if (q2t[qk] >= 0) {
                int tk = q2t[qk];
                // Candidates must be neighbors of tk in target
                if (!constrained) {
                    constrained = true;
                    for (int tn : target.neighbors[tk]) {
                        if (!tUsed[tn] && atomCompat(qi, target, tn)) {
                            candidates.push_back(tn);
                        }
                    }
                } else {
                    // Intersect with neighbors of tk
                    std::unordered_set<int> nbSet(target.neighbors[tk].begin(),
                                                  target.neighbors[tk].end());
                    candidates.erase(
                        std::remove_if(candidates.begin(), candidates.end(),
                            [&](int c) { return nbSet.find(c) == nbSet.end(); }),
                        candidates.end());
                }
            }
        }

        if (!constrained) {
            // No matched neighbors: try all target atoms
            candidates.reserve(target.n);
            for (int t = 0; t < target.n; t++) {
                if (!tUsed[t] && atomCompat(qi, target, t)) {
                    candidates.push_back(t);
                }
            }
        }

        for (int ti : candidates) {
            if (tUsed[ti]) continue;

            // Check bond compatibility with all already-matched neighbors
            bool bondsOk = true;
            for (size_t ni = 0; ni < neighbors[qi].size(); ni++) {
                int qk = neighbors[qi][ni];
                if (q2t[qk] >= 0) {
                    int tk = q2t[qk];
                    int bi = bondIndices[qi][ni];
                    if (!target.hasBond(ti, tk) || !bondCompat(bi, target, ti, tk)) {
                        bondsOk = false;
                        break;
                    }
                }
            }
            if (!bondsOk) continue;

            // Map qi -> ti
            q2t[qi] = ti;
            tUsed[ti] = true;

            backtrack(target, order, pos + 1, q2t, tUsed, results, maxMatches);

            q2t[qi] = -1;
            tUsed[ti] = false;

            if (static_cast<int>(results.size()) >= maxMatches) return;
        }
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    bool matches(const MolGraph& target) const {
        if (atomCount() == 0) return true;
        if (target.n < atomCount()) return false;

        auto order = matchingOrder();
        std::vector<int> q2t(atomCount(), -1);
        std::vector<bool> tUsed(target.n, false);
        std::vector<std::map<int,int>> results;
        backtrack(target, order, 0, q2t, tUsed, results, 1);
        return !results.empty();
    }

    std::vector<std::map<int,int>> findAll(const MolGraph& target, int maxMatches = 1000) const {
        if (atomCount() == 0) return {{}};
        if (target.n < atomCount()) return {};

        auto order = matchingOrder();
        std::vector<int> q2t(atomCount(), -1);
        std::vector<bool> tUsed(target.n, false);
        std::vector<std::map<int,int>> results;
        backtrack(target, order, 0, q2t, tUsed, results, maxMatches);
        return results;
    }

    // Match with atom 0 of query anchored to a specific target atom
    // (used for recursive SMARTS)
    bool matchesAtAtom(const MolGraph& target, int targetAtom) const {
        if (atomCount() == 0) return true;
        if (target.n < atomCount()) return false;

        auto order = matchingOrder();
        // Ensure atom 0 is first in order (it should be since BFS starts from 0)
        assert(!order.empty() && order[0] == 0);

        // Check if atom 0 is compatible with targetAtom
        if (!atomCompat(0, target, targetAtom)) return false;

        std::vector<int> q2t(atomCount(), -1);
        std::vector<bool> tUsed(target.n, false);

        // Fix atom 0 -> targetAtom
        q2t[0] = targetAtom;
        tUsed[targetAtom] = true;

        std::vector<std::map<int,int>> results;
        backtrack(target, order, 1, q2t, tUsed, results, 1);
        return !results.empty();
    }
};

// Deferred recursive SMARTS evaluation (needs complete SmartsQuery type)
inline bool evalRecursiveSmarts(const smarts_detail::AtomExpr& expr, const MolGraph& g, int idx) {
    if (!expr.recursiveSmarts.empty()) {
        auto query = parseSMARTS(expr.recursiveSmarts);
        return query.matchesAtAtom(g, idx);
    }
    return false;
}

// ============================================================================
// Named predicate registry (mirrors Java Standardiser.expandNamedPredicates)
// ============================================================================

class SmartsPredicateRegistry {
    std::unordered_map<std::string, std::string> predicates_;

public:
    SmartsPredicateRegistry() = default;

    /// Register a named predicate: name -> SMARTS definition.
    void registerPredicate(const std::string& name, const std::string& smarts) {
        predicates_[name] = smarts;
    }

    /// Expand all `$name` tokens (inside brackets) with `$(definition)`.
    /// Scans for `$` followed by an identifier (alphanumeric + underscore);
    /// if the identifier is a registered predicate, replaces `$name` with
    /// `$(definition)`.  Tokens already of the form `$(...)` are left alone.
    std::string expandPredicates(const std::string& input) const {
        std::string result;
        result.reserve(input.size());
        size_t i = 0;
        while (i < input.size()) {
            if (input[i] == '$' && i + 1 < input.size() && input[i + 1] != '(') {
                // Collect the identifier after '$'
                size_t start = i + 1;
                size_t end = start;
                while (end < input.size() &&
                       (std::isalnum(static_cast<unsigned char>(input[end])) || input[end] == '_')) {
                    ++end;
                }
                std::string name = input.substr(start, end - start);
                auto it = predicates_.find(name);
                if (it != predicates_.end()) {
                    result += "$(";
                    result += it->second;
                    result += ')';
                    i = end;
                } else {
                    result += input[i];
                    ++i;
                }
            } else {
                result += input[i];
                ++i;
            }
        }
        return result;
    }

    /// Create a registry pre-loaded with the 10 built-in predicates
    /// (same set as Java Standardiser).
    static SmartsPredicateRegistry builtinRegistry() {
        SmartsPredicateRegistry reg;
        reg.registerPredicate("isAmideN",
            "[$([NX3;H2,H1;!$(NC=O)]),$([NX3;$(NC=O)])]");
        reg.registerPredicate("isCarboxylC",
            "[CX3](=O)[OX2H1,OX1-]");
        reg.registerPredicate("isSulfonamideN",
            "[NX3;$(NS(=O)=O)]");
        reg.registerPredicate("isEster",
            "[#6][CX3](=O)[OX2][#6]");
        reg.registerPredicate("isKetone",
            "[#6][CX3](=O)[#6]");
        reg.registerPredicate("isHalogen",
            "[F,Cl,Br,I]");
        reg.registerPredicate("isPositive",
            "[*+]");
        reg.registerPredicate("isNegative",
            "[*-]");
        reg.registerPredicate("isHBDonor",
            "[N!H0,O!H0,S!H0]");
        reg.registerPredicate("isHBAcceptor",
            "[N,O,S;H0;!+0]");
        return reg;
    }
};

// ============================================================================
// parseSMARTS -- top-level API
// ============================================================================

inline SmartsQuery parseSMARTS(const std::string& smarts) {
    if (smarts.empty()) return SmartsQuery{};

    SmartsQuery query;
    smarts_detail::SmartsParser parser(smarts);
    parser.parse(query.atoms, query.bonds);
    query.buildAdjacency();
    return query;
}

} // namespace smsd

// ============================================================================
// Basic tests (compile with -DSMSD_TEST_SMARTS)
// ============================================================================
#ifdef SMSD_TEST_SMARTS

#include "smiles_parser.hpp"
#include <cassert>
#include <iostream>

namespace smsd_smarts_test {

inline void testWildcard() {
    auto q = smsd::parseSMARTS("*");
    auto mol = smsd::parseSMILES("C");
    assert(q.matches(mol));
    std::cout << "  [PASS] testWildcard\n";
}

inline void testElementMatch() {
    auto q = smsd::parseSMARTS("[#6]");
    auto mol = smsd::parseSMILES("C");
    assert(q.matches(mol));

    auto q2 = smsd::parseSMARTS("[#7]");
    assert(!q2.matches(mol));
    std::cout << "  [PASS] testElementMatch\n";
}

inline void testOrganicShorthand() {
    auto q = smsd::parseSMARTS("C");
    auto mol = smsd::parseSMILES("CC");
    assert(q.matches(mol));

    auto q2 = smsd::parseSMARTS("N");
    assert(!q2.matches(mol));
    std::cout << "  [PASS] testOrganicShorthand\n";
}

inline void testBondSingle() {
    auto q = smsd::parseSMARTS("C-C");
    auto mol = smsd::parseSMILES("CC");
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("C=C");
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testBondSingle\n";
}

inline void testBondDouble() {
    auto q = smsd::parseSMARTS("C=O");
    auto mol = smsd::parseSMILES("CC=O");
    assert(q.matches(mol));
    std::cout << "  [PASS] testBondDouble\n";
}

inline void testBondTriple() {
    auto q = smsd::parseSMARTS("C#N");
    auto mol = smsd::parseSMILES("CC#N");
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("CC=N");
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testBondTriple\n";
}

inline void testBondAny() {
    auto q = smsd::parseSMARTS("C~C");
    auto mol1 = smsd::parseSMILES("CC");
    auto mol2 = smsd::parseSMILES("C=C");
    assert(q.matches(mol1));
    assert(q.matches(mol2));
    std::cout << "  [PASS] testBondAny\n";
}

inline void testDegree() {
    // D2 = degree 2
    auto q = smsd::parseSMARTS("[D2]");
    auto mol = smsd::parseSMILES("CCC");  // middle C has degree 2
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("C");   // single C has degree 0
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testDegree\n";
}

inline void testRing() {
    auto q = smsd::parseSMARTS("[R]");
    auto mol = smsd::parseSMILES("C1CCC1");
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("CCC");
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testRing\n";
}

inline void testNotRing() {
    auto q = smsd::parseSMARTS("[!R]");
    auto mol = smsd::parseSMILES("CCC");
    assert(q.matches(mol));
    std::cout << "  [PASS] testNotRing\n";
}

inline void testOrExpression() {
    // [#6,#7] = carbon or nitrogen
    auto q = smsd::parseSMARTS("[#6,#7]");
    auto molC = smsd::parseSMILES("C");
    auto molN = smsd::parseSMILES("N");
    auto molO = smsd::parseSMILES("O");
    assert(q.matches(molC));
    assert(q.matches(molN));
    assert(!q.matches(molO));
    std::cout << "  [PASS] testOrExpression\n";
}

inline void testAndExpression() {
    // [#6&D2] = carbon with degree 2
    auto q = smsd::parseSMARTS("[#6&D2]");
    auto mol = smsd::parseSMILES("CCC");
    assert(q.matches(mol));  // middle C is #6 and D2
    std::cout << "  [PASS] testAndExpression\n";
}

inline void testCharge() {
    auto q = smsd::parseSMARTS("[+1]");
    auto mol = smsd::parseSMILES("[NH4+]");
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("C");
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testCharge\n";
}

inline void testTwoLetterElement() {
    auto q = smsd::parseSMARTS("[Cl]");
    auto mol = smsd::parseSMILES("CCl");
    assert(q.matches(mol));
    std::cout << "  [PASS] testTwoLetterElement\n";
}

inline void testPattern_CC() {
    auto q = smsd::parseSMARTS("CC");
    auto mol = smsd::parseSMILES("CCC");  // has C-C substructure
    auto matches = q.findAll(mol, 100);
    assert(!matches.empty());
    std::cout << "  [PASS] testPattern_CC (" << matches.size() << " matches)\n";
}

inline void testAromatic() {
    auto q = smsd::parseSMARTS("[a]");
    auto mol = smsd::parseSMILES("c1ccccc1");  // benzene
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("C1CCCCC1");  // cyclohexane
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testAromatic\n";
}

inline void testRingBond() {
    auto q = smsd::parseSMARTS("[#6]@[#6]");
    auto mol = smsd::parseSMILES("C1CCC1");  // cyclobutane: ring bond
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("CCC");  // no ring
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testRingBond\n";
}

inline void testBranches() {
    // C(=O)O = carboxylic acid
    auto q = smsd::parseSMARTS("C(=O)O");
    auto mol = smsd::parseSMILES("CC(=O)O");  // acetic acid
    assert(q.matches(mol));
    std::cout << "  [PASS] testBranches (carboxylic acid)\n";
}

inline void testNotOperator() {
    // [!#6] = not carbon
    auto q = smsd::parseSMARTS("[!#6]");
    auto molC = smsd::parseSMILES("C");
    auto molN = smsd::parseSMILES("N");
    assert(!q.matches(molC));
    assert(q.matches(molN));
    std::cout << "  [PASS] testNotOperator\n";
}

inline void testRingClosure() {
    // c1ccccc1 = aromatic 6-ring
    auto q = smsd::parseSMARTS("c1ccccc1");
    auto mol = smsd::parseSMILES("c1ccccc1");
    assert(q.matches(mol));
    std::cout << "  [PASS] testRingClosure\n";
}

inline void testEmptySmarts() {
    auto q = smsd::parseSMARTS("");
    auto mol = smsd::parseSMILES("C");
    assert(q.matches(mol));  // empty pattern matches anything
    std::cout << "  [PASS] testEmptySmarts\n";
}

inline void testInvalidSmarts() {
    bool threw = false;
    try {
        smsd::parseSMARTS("[#6");  // missing ]
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    assert(threw);
    std::cout << "  [PASS] testInvalidSmarts\n";
}

inline void testSemicolonAnd() {
    // [#6;R] = carbon AND in ring (semicolon = low-priority AND)
    auto q = smsd::parseSMARTS("[#6;R]");
    auto mol = smsd::parseSMILES("C1CCC1");
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("CCC");
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testSemicolonAnd\n";
}

inline void testMultipleMatches() {
    auto q = smsd::parseSMARTS("[#6]");
    auto mol = smsd::parseSMILES("CCCC");
    auto matches = q.findAll(mol, 100);
    assert(static_cast<int>(matches.size()) == 4);  // 4 carbons
    std::cout << "  [PASS] testMultipleMatches (" << matches.size() << " matches)\n";
}

inline void testRecursiveSmarts() {
    // [$([#6][#8])] = carbon bonded to oxygen
    auto q = smsd::parseSMARTS("[$([#6][#8])]");
    auto mol = smsd::parseSMILES("CCO");
    assert(q.matches(mol));  // C bonded to O

    auto mol2 = smsd::parseSMILES("CCC");
    assert(!q.matches(mol2));
    std::cout << "  [PASS] testRecursiveSmarts\n";
}

inline void testHeteroNeighbors() {
    // z1 in methylamine: C has 1 N neighbor
    auto q1 = smsd::parseSMARTS("[z1]");
    auto mol1 = smsd::parseSMILES("CN");
    assert(q1.matches(mol1));

    // z0 in ethane: only carbon neighbors
    auto q2 = smsd::parseSMARTS("[z0]");
    auto mol2 = smsd::parseSMILES("CC");
    assert(q2.matches(mol2));

    std::cout << "  [PASS] testHeteroNeighbors\n";
}

inline void testHeavyDegree() {
    // d2 in propane: middle C has 2 heavy neighbors
    auto q = smsd::parseSMARTS("[d2]");
    auto mol = smsd::parseSMILES("CCC");
    assert(q.matches(mol));
    std::cout << "  [PASS] testHeavyDegree\n";
}

inline void testHybridization() {
    // ^2 matches SP2 (aromatic carbon)
    auto q1 = smsd::parseSMARTS("[^2]");
    auto mol1 = smsd::parseSMILES("c1ccccc1");
    assert(q1.matches(mol1));

    // ^3 matches SP3 (methane)
    auto q2 = smsd::parseSMARTS("[^3]");
    auto mol2 = smsd::parseSMILES("C");
    assert(q2.matches(mol2));

    // ^1 matches SP (acetylene)
    auto q3 = smsd::parseSMARTS("[^1]");
    auto mol3 = smsd::parseSMILES("C#C");
    assert(q3.matches(mol3));

    std::cout << "  [PASS] testHybridization\n";
}

inline void testRangeQuery() {
    // D{2-4} matches degree 2 through 4
    auto q = smsd::parseSMARTS("[D{2-4}]");
    auto mol = smsd::parseSMILES("CC(C)(C)C"); // central C has D4
    assert(q.matches(mol));

    auto mol2 = smsd::parseSMILES("C"); // D0
    assert(!q.matches(mol2));

    // D{2-} means >= 2
    auto q2 = smsd::parseSMARTS("[D{2-}]");
    auto mol3 = smsd::parseSMILES("CCC"); // middle C has D2
    assert(q2.matches(mol3));

    std::cout << "  [PASS] testRangeQuery\n";
}

inline void runAllTests() {
    std::cout << "smarts_parser tests:\n";
    testWildcard();
    testElementMatch();
    testOrganicShorthand();
    testBondSingle();
    testBondDouble();
    testBondTriple();
    testBondAny();
    testDegree();
    testRing();
    testNotRing();
    testOrExpression();
    testAndExpression();
    testCharge();
    testTwoLetterElement();
    testPattern_CC();
    testAromatic();
    testRingBond();
    testBranches();
    testNotOperator();
    testRingClosure();
    testEmptySmarts();
    testInvalidSmarts();
    testSemicolonAnd();
    testMultipleMatches();
    testRecursiveSmarts();
    testHeteroNeighbors();
    testHeavyDegree();
    testHybridization();
    testRangeQuery();
    std::cout << "All smarts_parser tests passed.\n";
}

} // namespace smsd_smarts_test

#endif // SMSD_TEST_SMARTS

#endif // SMSD_SMARTS_PARSER_HPP
