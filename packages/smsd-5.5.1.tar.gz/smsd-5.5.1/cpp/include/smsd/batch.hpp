/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2009-2026 Syed Asad Rahman, BioInception Labs
 *
 * Header-only OpenMP batch processing for SMSD.
 *
 * Provides multi-CPU parallel batch operations:
 *   - batchSubstructure: 1 query vs N targets, returns hit mask
 *   - batchMCS: 1 query vs N targets, returns all MCS mappings
 *   - screenAndMatch: RASCAL pre-screen + exact MCS on hits
 *   - batchFingerprint: parallel fingerprint generation
 *
 * Falls back to sequential execution when OpenMP is unavailable.
 * Thread-safe: each thread uses its own scratch buffers.
 *
 * Compile with: -fopenmp (gcc/clang) or /openmp (MSVC)
 * On macOS with clang: brew install libomp, then -Xpreprocessor -fopenmp -lomp
 */
#pragma once
#ifndef SMSD_BATCH_HPP
#define SMSD_BATCH_HPP

#include "smsd/mol_graph.hpp"
#include "smsd/vf2pp.hpp"
#include "smsd/mcs.hpp"

#include <algorithm>
#include <cstdint>
#include <functional>
#include <map>
#include <numeric>
#include <utility>
#include <vector>

#ifdef _OPENMP
#include <omp.h>
#endif

namespace smsd {
namespace batch {

// ============================================================================
// Internal: thread count resolution
// ============================================================================
namespace detail {

/// Resolve thread count: 0 = auto (use all available), else clamp to [1, max].
inline int resolveThreads(int numThreads) {
#ifdef _OPENMP
    if (numThreads <= 0) {
        return omp_get_max_threads();
    }
    return std::max(1, std::min(numThreads, omp_get_max_threads()));
#else
    (void)numThreads;
    return 1;
#endif
}

/// Simple path-based fingerprint generation for a single molecule.
/// Enumerates all paths up to pathLength and hashes them into fpSize bits.
/// Returns a vector of uint64_t words representing the fingerprint.
inline std::vector<uint64_t> computePathFingerprint(
    const MolGraph& mol, int pathLength, int fpSize)
{
    int numWords = (fpSize + 63) / 64;
    std::vector<uint64_t> fp(numWords, 0ULL);

    if (mol.n == 0) return fp;

    // Hash helper: FNV-1a 64-bit
    auto fnv1a = [](const int* data, int len) -> uint64_t {
        uint64_t h = 14695981039346656037ULL;
        for (int i = 0; i < len; ++i) {
            h ^= static_cast<uint64_t>(static_cast<uint32_t>(data[i]));
            h *= 1099511628211ULL;
        }
        return h;
    };

    // DFS-based path enumeration from each atom
    // Stack-based to avoid recursion overhead
    struct Frame {
        int atom;
        int depth;
        int nbIdx;   // neighbor iteration index — resume after backtrack
        int path[8]; // max path length + 1
    };

    std::vector<bool> visited(mol.n, false);
    Frame stack[256]; // bounded by MAX_ATOMS + depth

    for (int start = 0; start < mol.n; ++start) {
        // Single atom path
        {
            int p[1] = { mol.label[start] };
            uint64_t h = fnv1a(p, 1);
            int bit = static_cast<int>(h % static_cast<uint64_t>(fpSize));
            fp[bit / 64] |= (1ULL << (bit % 64));
        }

        // Multi-atom paths via iterative DFS
        int top = 0;
        stack[0].atom = start;
        stack[0].depth = 0;
        stack[0].nbIdx = 0;
        stack[0].path[0] = mol.label[start];
        visited[start] = true;

        while (top >= 0) {
            Frame& f = stack[top];
            bool expanded = false;

            if (f.depth < pathLength) {
                const auto& nbs = mol.neighbors[f.atom];
                int nbCount = static_cast<int>(nbs.size());
                for (; f.nbIdx < nbCount; ++f.nbIdx) {
                    int nb = nbs[f.nbIdx];
                    if (visited[nb]) continue;

                    // Build path including bond order
                    int newDepth = f.depth + 1;
                    int bondOrd = mol.bondOrder(f.atom, nb);

                    // Hash: atom labels + bond orders interleaved
                    // path = [label0, bond01, label1, bond12, label2, ...]
                    int pathData[16]; // max 2*pathLength + 1
                    int pathLen = 0;
                    for (int d = 0; d <= f.depth; ++d) {
                        pathData[pathLen++] = f.path[d];
                        if (d < f.depth) {
                            // bond order already encoded in path from parent
                        }
                    }
                    // Append bond + new label
                    pathData[pathLen++] = bondOrd + 1000; // offset to distinguish from labels
                    pathData[pathLen++] = mol.label[nb];

                    uint64_t h = fnv1a(pathData, pathLen);
                    int bit = static_cast<int>(h % static_cast<uint64_t>(fpSize));
                    fp[bit / 64] |= (1ULL << (bit % 64));

                    // Also hash reversed path for canonical invariance
                    int revData[16];
                    for (int r = 0; r < pathLen; ++r)
                        revData[r] = pathData[pathLen - 1 - r];
                    uint64_t h2 = fnv1a(revData, pathLen);
                    int bit2 = static_cast<int>(h2 % static_cast<uint64_t>(fpSize));
                    fp[bit2 / 64] |= (1ULL << (bit2 % 64));

                    // Push to stack if we can go deeper
                    if (newDepth < pathLength && top + 1 < 255) {
                        visited[nb] = true;
                        f.nbIdx++; // advance BEFORE push so we resume at next neighbor on return
                        top++;
                        stack[top].atom = nb;
                        stack[top].depth = newDepth;
                        stack[top].nbIdx = 0; // fresh start for new depth
                        for (int d = 0; d <= stack[top-1].depth; ++d)
                            stack[top].path[d] = stack[top-1].path[d];
                        stack[top].path[newDepth] = mol.label[nb];
                        expanded = true;
                        break; // DFS: go deeper first
                    }
                }
            }

            if (!expanded) {
                visited[stack[top].atom] = false;
                top--;
            }
        }

        visited[start] = false;
    }

    return fp;
}

} // namespace detail

// ============================================================================
// Batch Substructure: 1 query vs N targets
// ============================================================================

/// Check if query is a substructure of each target molecule.
/// Returns a boolean vector: true if query is substructure of targets[i].
///
/// Thread-safe: each thread runs its own VF2PP instance with independent state.
/// @param numThreads  0 = auto (all cores), >0 = specific thread count.
inline std::vector<bool> batchSubstructure(
    const MolGraph& query,
    const std::vector<MolGraph>& targets,
    const ChemOptions& opts,
    int numThreads = 0)
{
    const int N = static_cast<int>(targets.size());

    if (N == 0 || query.n == 0) return std::vector<bool>(N, false);

    // Use uint8_t instead of vector<bool> — vector<bool> packs bits into
    // shared bytes, causing data races under OpenMP concurrent writes.
    std::vector<uint8_t> buf(N, 0);

    int nThreads = detail::resolveThreads(numThreads);
    (void)nThreads; // suppress unused warning when no OpenMP

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic, 4) num_threads(nThreads)
#endif
    for (int i = 0; i < N; ++i) {
        if (targets[i].n >= query.n) {
            buf[i] = isSubstructure(query, targets[i], opts) ? 1 : 0;
        }
    }

    return std::vector<bool>(buf.begin(), buf.end());
}

// ============================================================================
// Batch MCS: 1 query vs N targets
// ============================================================================

/// Find the MCS between query and each target molecule.
/// Returns a vector of mappings (query atom -> target atom).
/// Empty map means no significant common substructure found.
///
/// Thread-safe: each thread creates its own MCS scratch buffers internally.
/// @param numThreads  0 = auto, >0 = specific thread count.
inline std::vector<std::map<int,int>> batchMCS(
    const MolGraph& query,
    const std::vector<MolGraph>& targets,
    const ChemOptions& chem,
    const McsOptions& opts,
    int numThreads = 0)
{
    const int N = static_cast<int>(targets.size());
    std::vector<std::map<int,int>> results(N);

    if (N == 0 || query.n == 0) return results;

    int nThreads = detail::resolveThreads(numThreads);
    (void)nThreads;

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic, 1) num_threads(nThreads)
#endif
    for (int i = 0; i < N; ++i) {
        if (targets[i].n > 0) {
            results[i] = findMCS(query, targets[i], chem, opts);
        }
    }

    return results;
}

// ============================================================================
// Screen and Match: RASCAL pre-screen + exact MCS on hits
// ============================================================================

/// Two-phase pipeline:
///   Phase 1: RASCAL similarity upper-bound screening (parallel)
///   Phase 2: Exact MCS computation on hits only (parallel)
///
/// Returns vector of (target_index, MCS_mapping) for targets that pass
/// the RASCAL threshold AND have a non-empty MCS.
///
/// This is the recommended workflow for large databases: RASCAL screening
/// eliminates ~90% of targets cheaply, then exact MCS runs only on candidates.
inline std::vector<std::pair<int, std::map<int,int>>> screenAndMatch(
    const MolGraph& query,
    const std::vector<MolGraph>& targets,
    const ChemOptions& chem,
    const McsOptions& opts,
    double rascalThreshold = 0.3,
    int numThreads = 0)
{
    const int N = static_cast<int>(targets.size());
    if (N == 0 || query.n == 0) return {};

    int nThreads = detail::resolveThreads(numThreads);
    (void)nThreads;

    // --- Phase 1: RASCAL screening (parallel) ---
    std::vector<double> scores(N, 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic, 64) num_threads(nThreads)
#endif
    for (int i = 0; i < N; ++i) {
        if (targets[i].n > 0) {
            scores[i] = similarityUpperBound(query, targets[i]);
        }
    }

    // Collect hits
    std::vector<int> hits;
    hits.reserve(N / 10);
    for (int i = 0; i < N; ++i) {
        if (scores[i] >= rascalThreshold) {
            hits.push_back(i);
        }
    }

    if (hits.empty()) return {};

    // --- Phase 2: Exact MCS on hits only (parallel) ---
    const int H = static_cast<int>(hits.size());
    std::vector<std::map<int,int>> mcsMaps(H);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic, 1) num_threads(nThreads)
#endif
    for (int h = 0; h < H; ++h) {
        int idx = hits[h];
        mcsMaps[h] = findMCS(query, targets[idx], chem, opts);
    }

    // Collect non-empty results
    std::vector<std::pair<int, std::map<int,int>>> results;
    results.reserve(H);
    for (int h = 0; h < H; ++h) {
        if (!mcsMaps[h].empty()) {
            results.emplace_back(hits[h], std::move(mcsMaps[h]));
        }
    }

    return results;
}

// ============================================================================
// Batch Fingerprint Generation
// ============================================================================

/// Generate path-based fingerprints for all molecules in parallel.
/// Each fingerprint is a vector of uint64_t words (fpSize / 64 words).
///
/// @param pathLength  Maximum path length to enumerate (default 7).
/// @param fpSize      Fingerprint size in bits (default 1024, must be multiple of 64).
/// @param numThreads  0 = auto, >0 = specific thread count.
inline std::vector<std::vector<uint64_t>> batchFingerprint(
    const std::vector<MolGraph>& mols,
    int pathLength = 7,
    int fpSize = 1024,
    int numThreads = 0)
{
    const int N = static_cast<int>(mols.size());
    std::vector<std::vector<uint64_t>> results(N);

    if (N == 0) return results;

    // Ensure fpSize is a multiple of 64
    fpSize = ((fpSize + 63) / 64) * 64;

    int nThreads = detail::resolveThreads(numThreads);
    (void)nThreads;

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic, 8) num_threads(nThreads)
#endif
    for (int i = 0; i < N; ++i) {
        results[i] = detail::computePathFingerprint(mols[i], pathLength, fpSize);
    }

    return results;
}

// ============================================================================
// Utility: Tanimoto similarity between two fingerprints
// ============================================================================

/// Compute Tanimoto coefficient between two fingerprints.
inline double fingerprintTanimoto(
    const std::vector<uint64_t>& a,
    const std::vector<uint64_t>& b)
{
    if (a.empty() || b.empty()) return 0.0;

    int minWords = static_cast<int>(std::min(a.size(), b.size()));
    int maxWords = static_cast<int>(std::max(a.size(), b.size()));

    int andBits = 0, orBits = 0;

    // Use the portable popcount64 from bitops.hpp (no need for inline lambda)
    for (int i = 0; i < minWords; ++i) {
        andBits += popcount64(a[i] & b[i]);
        orBits  += popcount64(a[i] | b[i]);
    }

    // Extra words in the longer fingerprint contribute only to OR
    const auto& longer = (a.size() > b.size()) ? a : b;
    for (int i = minWords; i < maxWords; ++i) {
        orBits += popcount64(longer[i]);
    }

    return (orBits == 0) ? 1.0 : static_cast<double>(andBits) /
                                  static_cast<double>(orBits);
}

/// Check if fingerprint a is a subset of fingerprint b (all ON bits of a are ON in b).
/// Used for substructure pre-screening: if query is substructure of target,
/// then query FP must be a subset of target FP.
inline bool fingerprintSubset(
    const std::vector<uint64_t>& query,
    const std::vector<uint64_t>& target)
{
    if (query.empty()) return true;

    int qWords = static_cast<int>(query.size());
    int tWords = static_cast<int>(target.size());

    for (int i = 0; i < qWords; ++i) {
        uint64_t qw = query[i];
        uint64_t tw = (i < tWords) ? target[i] : 0ULL;
        if ((qw & tw) != qw) return false;
    }
    return true;
}

// ============================================================================
// Batch Fingerprint Subset Screen (CPU)
// ============================================================================

/// CPU-based fingerprint subset screening: 1 query vs N targets.
/// Returns indices of targets where query FP is a subset of target FP.
inline std::vector<int> batchFingerprintScreen(
    const std::vector<uint64_t>& queryFP,
    const std::vector<std::vector<uint64_t>>& targetFPs,
    int numThreads = 0)
{
    const int N = static_cast<int>(targetFPs.size());
    if (N == 0 || queryFP.empty()) return {};

    std::vector<int> mask(N, 0);
    int nThreads = detail::resolveThreads(numThreads);
    (void)nThreads;

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic, 64) num_threads(nThreads)
#endif
    for (int i = 0; i < N; ++i) {
        mask[i] = fingerprintSubset(queryFP, targetFPs[i]) ? 1 : 0;
    }

    std::vector<int> hits;
    for (int i = 0; i < N; ++i) {
        if (mask[i]) hits.push_back(i);
    }
    return hits;
}

} // namespace batch
} // namespace smsd

#endif // SMSD_BATCH_HPP
