/*
 * SPDX-License-Identifier: Apache-2.0
 * © 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.cli.SMSDcli.OutputUtil;
import com.bioinception.smsd.core.ChemOptions;
import com.bioinception.smsd.core.SMSD;
import java.io.ByteArrayOutputStream;
import java.util.*;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;

@DisplayName("OutputUtil Tests")
class OutputUtilTest extends TestBase {

  private static IAtomContainer parse(String smi) throws Exception {
    return mol(smi);
  }

  @Nested
  @DisplayName("JSON Output")
  class JsonOutput {

    @Test
    @DisplayName("JSON contains expected keys")
    void jsonKeys() throws Exception {
      IAtomContainer q = parse("c1ccccc1");
      IAtomContainer t = parse("c1ccc(C)cc1");
      SMSD smsd = new SMSD(q, t, new ChemOptions());
      smsd.isSubstructure();
      List<Map<Integer, Integer>> mappings = smsd.findAllSubstructures(10, 5000);

      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      OutputUtil.writeMappings(q, t, mappings, OutputUtil.OutType.JSON, baos, false);
      String json = baos.toString("UTF-8");

      assertTrue(json.contains("query_size"), "JSON should contain query_size");
      assertTrue(json.contains("target_size"), "JSON should contain target_size");
      assertTrue(json.contains("mappings"), "JSON should contain mappings");
      assertTrue(json.contains("pairs"), "JSON should contain pairs");
      assertTrue(json.contains("query_atoms"), "JSON should contain query_atoms");
      assertTrue(json.contains("target_atoms"), "JSON should contain target_atoms");
    }

    @Test
    @DisplayName("Pretty JSON contains newlines")
    void prettyJson() throws Exception {
      IAtomContainer q = parse("c1ccccc1");
      IAtomContainer t = parse("c1ccc(C)cc1");
      SMSD smsd = new SMSD(q, t, new ChemOptions());
      smsd.isSubstructure();
      List<Map<Integer, Integer>> mappings = smsd.findAllSubstructures(10, 5000);

      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      OutputUtil.writeMappings(q, t, mappings, OutputUtil.OutType.JSON, baos, true);
      String json = baos.toString("UTF-8");

      assertTrue(json.contains("\n"), "Pretty JSON should contain newlines");
      assertTrue(json.contains("  "), "Pretty JSON should contain indentation");
    }

    @Test
    @DisplayName("JSON with similarity upper bound")
    void jsonWithSimilarity() throws Exception {
      IAtomContainer q = parse("c1ccccc1");
      IAtomContainer t = parse("c1ccc(C)cc1");
      List<Map<Integer, Integer>> mappings = new ArrayList<>();
      Map<Integer, Integer> m = new LinkedHashMap<>();
      m.put(0, 0);
      m.put(1, 1);
      m.put(2, 2);
      mappings.add(m);

      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      OutputUtil.writeMappings(q, t, mappings, OutputUtil.OutType.JSON, baos, false, 0.85);
      String json = baos.toString("UTF-8");

      assertTrue(
          json.contains("similarity_upper_bound"), "JSON should contain similarity_upper_bound");
      assertTrue(json.contains("0.85"), "JSON should contain the bound value");
    }

    @Test
    @DisplayName("JSON without similarity (NaN)")
    void jsonWithoutSimilarity() throws Exception {
      IAtomContainer q = parse("c1ccccc1");
      IAtomContainer t = parse("c1ccc(C)cc1");
      List<Map<Integer, Integer>> mappings = Collections.singletonList(Collections.emptyMap());

      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      OutputUtil.writeMappings(q, t, mappings, OutputUtil.OutType.JSON, baos, false, Double.NaN);
      String json = baos.toString("UTF-8");

      assertFalse(
          json.contains("similarity_upper_bound"),
          "JSON should NOT contain similarity_upper_bound when NaN");
    }
  }

  @Nested
  @DisplayName("SMILES Output")
  class SmilesOutput {

    @Test
    @DisplayName("SMI output produces mapped SMILES")
    void smiOutput() throws Exception {
      IAtomContainer q = parse("c1ccccc1");
      IAtomContainer t = parse("c1ccc(C)cc1");
      SMSD smsd = new SMSD(q, t, new ChemOptions());
      smsd.isSubstructure();
      List<Map<Integer, Integer>> mappings = smsd.findAllSubstructures(1, 5000);

      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      OutputUtil.writeMappings(q, t, mappings, OutputUtil.OutType.SMI, baos, false);
      String output = baos.toString("UTF-8").trim();

      assertFalse(output.isEmpty(), "SMILES output should not be empty");
    }
  }

  @Nested
  @DisplayName("Edge Cases")
  class EdgeCases {

    @Test
    @DisplayName("Empty mappings → valid JSON with empty array")
    void emptyMappings() throws Exception {
      IAtomContainer t = parse("c1ccccc1");
      List<Map<Integer, Integer>> mappings = Collections.emptyList();

      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      OutputUtil.writeMappings(null, t, mappings, OutputUtil.OutType.JSON, baos, false);
      String json = baos.toString("UTF-8");

      assertTrue(
          json.contains("\"mappings\":[]") || json.contains("\"mappings\" : [ ]"),
          "Empty mappings should produce empty array");
    }

    @Test
    @DisplayName("Null target → NullPointerException")
    void nullTarget() {
      assertThrows(
          NullPointerException.class,
          () ->
              OutputUtil.writeMappings(
                  null,
                  null,
                  Collections.emptyList(),
                  OutputUtil.OutType.JSON,
                  new ByteArrayOutputStream(),
                  false));
    }

    @Test
    @DisplayName("Null mappings → NullPointerException")
    void nullMappings() throws Exception {
      IAtomContainer t = parse("C");
      assertThrows(
          NullPointerException.class,
          () ->
              OutputUtil.writeMappings(
                  null, t, null, OutputUtil.OutType.JSON, new ByteArrayOutputStream(), false));
    }

    @Test
    @DisplayName("writeMolecule SMI format")
    void writeMoleculeSmi() throws Exception {
      IAtomContainer mol = parse("c1ccccc1");
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      OutputUtil.writeMolecule(mol, OutputUtil.OutType.SMI, baos);
      String output = baos.toString("UTF-8").trim();
      assertFalse(output.isEmpty(), "SMILES output should not be empty");
    }
  }
}
