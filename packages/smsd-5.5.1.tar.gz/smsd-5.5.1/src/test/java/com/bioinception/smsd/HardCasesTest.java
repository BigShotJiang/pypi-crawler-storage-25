/*
 * SPDX-License-Identifier: Apache-2.0
 * (c) 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;

/**
 * Hard cases test suite: SMARTS substructure stress, highly branched molecules,
 * stereoisomer equivalence, reaction-relevant MCS, multi-ring topology, and
 * pharmacophore-relevant MCS. 70 non-redundant tests.
 *
 * @author Syed Asad Rahman
 */
@TestMethodOrder(MethodOrderer.DisplayName.class)
public class HardCasesTest extends TestBase {

  private static int mcsSize(String smi1, String smi2, ChemOptions opts, long timeoutMs) throws Exception {
    SMSD smsd = new SMSD(mol(smi1), mol(smi2), opts);
    smsd.setMcsTimeoutMs(timeoutMs);
    Map<Integer, Integer> mcs = smsd.findMCS(false, true, timeoutMs);
    return mcs.size();
  }

  private static int mcsSize(String smi1, String smi2) throws Exception {
    return mcsSize(smi1, smi2, new ChemOptions(), 10_000L);
  }

  private static ChemOptions looseOpts() {
    ChemOptions c = new ChemOptions();
    c.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
    c.aromaticityMode = ChemOptions.AromaticityMode.FLEXIBLE;
    c.ringMatchesRingOnly = false;
    c.matchFormalCharge = false;
    return c;
  }

  // ======================================================================
  // 1. SMARTS SUBSTRUCTURE STRESS (20 tests)
  // ======================================================================

  @Nested
  @DisplayName("1. SMARTS Substructure Stress")
  class SmartsSubstructureStress {

    /** Helper: assert SMARTS matches target SMILES */
    private void assertSmartsMatch(String smarts, String targetSmi, String msg) throws Exception {
      SMSD smsd = new SMSD(smarts, mol(targetSmi), new ChemOptions());
      assertTrue(smsd.isSubstructure(5000), msg);
    }

    /** Helper: assert SMARTS does NOT match */
    private void assertSmartsNoMatch(String smarts, String targetSmi, String msg) throws Exception {
      SMSD smsd = new SMSD(smarts, mol(targetSmi), new ChemOptions());
      assertFalse(smsd.isSubstructure(5000), msg);
    }

    @Test @Timeout(10) @DisplayName("1.01 4-carbon chain in butanol")
    void fourCarbonChainInButanol() throws Exception {
      assertSmartsMatch("[#6]~[#6]~[#6]~[#6]", "CCCCO",
          "4-carbon chain should match in butanol");
    }

    @Test @Timeout(10) @DisplayName("1.02 4-carbon chain NOT in propane")
    void fourCarbonChainNotInPropane() throws Exception {
      assertSmartsNoMatch("[#6]~[#6]~[#6]~[#6]", "CCC",
          "4-carbon chain should NOT match in propane");
    }

    @Test @Timeout(10) @DisplayName("1.03 Primary amine in amphetamine")
    void primaryAmineInAmphetamine() throws Exception {
      // amphetamine: CC(N)Cc1ccccc1
      assertSmartsMatch("[NX3;H2,H1;!$(NC=O)]", "CC(N)Cc1ccccc1",
          "Primary amine should match in amphetamine");
    }

    @Test @Timeout(10) @DisplayName("1.04 Primary amine NOT in acetanilide")
    void primaryAmineNotInAcetanilide() throws Exception {
      // acetanilide: CC(=O)Nc1ccccc1 — the N is an amide
      assertSmartsNoMatch("[NX3;H2;!$(NC=O)]", "CC(=O)Nc1ccccc1",
          "Primary amine (H2) should NOT match amide nitrogen in acetanilide");
    }

    @Test @Timeout(10) @DisplayName("1.05 Carboxylic acid in ibuprofen")
    void carboxylicAcidInIbuprofen() throws Exception {
      assertSmartsMatch("[CX3](=O)[OX2H1]", "CC(C)Cc1ccc(cc1)C(C)C(=O)O",
          "Carboxylic acid should match in ibuprofen");
    }

    @Test @Timeout(10) @DisplayName("1.06 Amide in acetaminophen")
    void amideInAcetaminophen() throws Exception {
      assertSmartsMatch("[CX3](=O)[NX3]", "CC(=O)Nc1ccc(O)cc1",
          "Amide should match in acetaminophen");
    }

    @Test @Timeout(10) @DisplayName("1.07 Aromatic 6-ring in toluene")
    void aromatic6RingInToluene() throws Exception {
      assertSmartsMatch("[cX3]1[cX3][cX3][cX3][cX3][cX3]1", "Cc1ccccc1",
          "Aromatic 6-ring in toluene");
    }

    @Test @Timeout(10) @DisplayName("1.08 C=C double bond in styrene")
    void doubleBondInStyrene() throws Exception {
      assertSmartsMatch("[#6]=[#6]", "C=Cc1ccccc1",
          "C=C should match in styrene");
    }

    @Test @Timeout(10) @DisplayName("1.09 Non-amide amine in tyramine")
    void nonAmideAmineInTyramine() throws Exception {
      // tyramine: NCCc1ccc(O)cc1
      assertSmartsMatch("[NX3;$([NH2]),$([NH1]);!$(NC=O)]", "NCCc1ccc(O)cc1",
          "Non-amide amine should match in tyramine");
    }

    @Test @Timeout(10) @DisplayName("1.10 Hydroxyl in ethanol")
    void hydroxylInEthanol() throws Exception {
      assertSmartsMatch("[OX2H]", "CCO",
          "Hydroxyl should match in ethanol");
    }

    @Test @Timeout(10) @DisplayName("1.11 Thiol in cysteine")
    void thiolInCysteine() throws Exception {
      assertSmartsMatch("[#16X2H]", "N[C@@H](CS)C(=O)O",
          "Thiol should match in cysteine");
    }

    @Test @Timeout(10) @DisplayName("1.12 Nitrile in benzonitrile")
    void nitrileInBenzonitrile() throws Exception {
      assertSmartsMatch("[$([NX1]#[CX2])]", "N#Cc1ccccc1",
          "Nitrile should match in benzonitrile");
    }

    @Test @Timeout(10) @DisplayName("1.13 Halogen in chlorobenzene")
    void halogenInChlorobenzene() throws Exception {
      assertSmartsMatch("[F,Cl,Br,I]", "Clc1ccccc1",
          "Halogen should match in chlorobenzene");
    }

    @Test @Timeout(10) @DisplayName("1.14 Ketone in acetone")
    void ketoneInAcetone() throws Exception {
      assertSmartsMatch("[CX3](=[OX1])[CX4]", "CC(=O)C",
          "Ketone should match in acetone");
    }

    @Test @Timeout(10) @DisplayName("1.15 Aldehyde in benzaldehyde")
    void aldehydeInBenzaldehyde() throws Exception {
      assertSmartsMatch("[CX3H1](=[OX1])", "O=Cc1ccccc1",
          "Aldehyde should match in benzaldehyde");
    }

    @Test @Timeout(10) @DisplayName("1.16 Nitro group in nitrobenzene")
    void nitroInNitrobenzene() throws Exception {
      // CDK represents nitro as [N+](=O)[O-], use charge-aware SMARTS
      assertSmartsMatch("[NX3+](=[OX1])[OX1-]", "[O-][N+](=O)c1ccccc1",
          "Nitro should match in nitrobenzene");
    }

    @Test @Timeout(10) @DisplayName("1.17 Hydroxylated aromatic ring in catechol")
    void hydroxylatedRingInCatechol() throws Exception {
      // catechol: Oc1ccccc1O
      assertSmartsMatch("[OX2H]c1ccccc1", "Oc1ccccc1O",
          "Hydroxylated ring pattern should match in catechol");
    }

    @Test @Timeout(10) @DisplayName("1.18 Heteroatom count in caffeine via SMARTS")
    void heteroatomInCaffeine() throws Exception {
      // caffeine: Cn1c(=O)c2c(ncn2C)n(C)c1=O — has N and O heteroatoms
      assertSmartsMatch("[!#1;!#6]", "Cn1c(=O)c2c(ncn2C)n(C)c1=O",
          "Heteroatom SMARTS should match in caffeine");
    }

    @Test @Timeout(10) @DisplayName("1.19 Quaternary carbon in neopentane")
    void quaternaryCarbonInNeopentane() throws Exception {
      // neopentane: CC(C)(C)C — central C has degree 4
      assertSmartsMatch("[CX4;D4]", "CC(C)(C)C",
          "Quaternary carbon should match in neopentane");
    }

    @Test @Timeout(10) @DisplayName("1.20 Ester in methyl benzoate")
    void esterInMethylBenzoate() throws Exception {
      // methyl benzoate: COC(=O)c1ccccc1
      assertSmartsMatch("[CX3](=O)[OX2][#6]", "COC(=O)c1ccccc1",
          "Ester should match in methyl benzoate");
    }
  }

  // ======================================================================
  // 2. HIGHLY BRANCHED / DENDRIMER-LIKE (10 tests)
  // ======================================================================

  @Nested
  @DisplayName("2. Highly Branched Molecules")
  class HighlyBranched {

    @Test @Timeout(10) @DisplayName("2.01 Neopentane self-match MCS = 5")
    void neopentaneSelfMcs() throws Exception {
      assertEquals(5, mcsSize("CC(C)(C)C", "CC(C)(C)C"),
          "Neopentane self-match should be 5 heavy atoms");
    }

    @Test @Timeout(10) @DisplayName("2.02 Neopentane substructure in 2,2-dimethylbutane")
    void neopentaneIn22Dimethylbutane() throws Exception {
      // 2,2-dimethylbutane: CCC(C)(C)C
      int sz = mcsSize("CC(C)(C)C", "CCC(C)(C)C");
      assertTrue(sz >= 5, "Neopentane should be substructure of 2,2-dimethylbutane");
    }

    @Test @Timeout(10) @DisplayName("2.03 Triphenylamine self-match")
    void triphenylamineSelfMatch() throws Exception {
      String tpa = "c1ccc(N(c2ccccc2)c3ccccc3)cc1";
      int sz = mcsSize(tpa, tpa);
      assertTrue(sz >= 18, "Triphenylamine self-match should be >= 18 heavy atoms");
    }

    @Test @Timeout(10) @DisplayName("2.04 Pentaerythritol self-match MCS = 9")
    void pentaerythritolSelfMatch() throws Exception {
      // OCC(CO)(CO)CO has 9 heavy atoms
      int sz = mcsSize("OCC(CO)(CO)CO", "OCC(CO)(CO)CO");
      assertEquals(9, sz, "Pentaerythritol self-match should be 9");
    }

    @Test @Timeout(10) @DisplayName("2.05 Tri-tert-butylmethane self-match")
    void triTertButylMethaneSelfMatch() throws Exception {
      String ttbm = "CC(C)(C)C(C(C)(C)C)C(C)(C)C";
      int sz = mcsSize(ttbm, ttbm);
      assertTrue(sz >= 13, "Tri-tert-butylmethane self-match should be >= 13");
    }

    @Test @Timeout(10) @DisplayName("2.06 Neopentane substructure in triphenylamine (loose)")
    void neopentaneNotInTriphenylamine() throws Exception {
      // Neopentane has no aromatic atoms; triphenylamine does — no overlap in strict ring match
      int sz = mcsSize("CC(C)(C)C", "c1ccc(N(c2ccccc2)c3ccccc3)cc1");
      assertTrue(sz >= 1, "Should share at least one common atom type");
    }

    @Test @Timeout(10) @DisplayName("2.07 Star-shaped glycerol self-match = 6")
    void glycerolSelfMatch() throws Exception {
      // glycerol: OCC(O)CO has 6 heavy atoms
      int sz = mcsSize("OCC(O)CO", "OCC(O)CO");
      assertEquals(6, sz, "Glycerol self-match should be 6");
    }

    @Test @Timeout(10) @DisplayName("2.08 Pentaerythritol in larger derivative")
    void pentaerythritolInTetraAcetate() throws Exception {
      // Pentaerythritol tetraacetate: CC(=O)OCC(COC(C)=O)(COC(C)=O)COC(C)=O
      int sz = mcsSize("OCC(CO)(CO)CO",
          "CC(=O)OCC(COC(C)=O)(COC(C)=O)COC(C)=O", looseOpts(), 10_000L);
      assertTrue(sz >= 5, "Pentaerythritol core should be found in tetraacetate");
    }

    @Test @Timeout(10) @DisplayName("2.09 Trimethylolpropane self-match")
    void trimethylolpropaneSelfMatch() throws Exception {
      // CCC(CO)(CO)CO — 10 heavy atoms
      int sz = mcsSize("CCC(CO)(CO)CO", "CCC(CO)(CO)CO");
      assertTrue(sz >= 9, "Trimethylolpropane self-match should be >= 9");
    }

    @Test @Timeout(10) @DisplayName("2.10 Isooctane self-match = 8")
    void isooctaneSelfMatch() throws Exception {
      // isooctane: CC(C)CC(C)(C)C — 8 carbons
      int sz = mcsSize("CC(C)CC(C)(C)C", "CC(C)CC(C)(C)C");
      assertEquals(8, sz, "Isooctane self-match should be 8");
    }
  }

  // ======================================================================
  // 3. STEREOISOMER EQUIVALENCE (10 tests)
  // ======================================================================

  @Nested
  @DisplayName("3. Stereoisomer Equivalence")
  class StereoisomerEquivalence {

    @Test @Timeout(10) @DisplayName("3.01 L-alanine vs D-alanine same MCS size (no chirality)")
    void alanineEnantiomersNoChirality() throws Exception {
      int sz = mcsSize("N[C@@H](C)C(=O)O", "N[C@H](C)C(=O)O");
      assertEquals(6, sz, "Enantiomers should have same heavy-atom MCS without chirality");
    }

    @Test @Timeout(10) @DisplayName("3.02 L-alanine vs D-alanine with chirality: not substructure")
    void alanineEnantiomersWithChirality() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      SMSD smsd = new SMSD(mol("N[C@@H](C)C(=O)O"), mol("N[C@H](C)C(=O)O"), opts);
      // With chirality on, enantiomers differ at chiral center
      // but MCS should still find overlap (non-chiral atoms match)
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4, "Even with chirality, should share most atoms");
    }

    @Test @Timeout(10) @DisplayName("3.03 R-thalidomide vs S-thalidomide no chirality")
    void thalidomideEnantiomersNoChirality() throws Exception {
      // Thalidomide: O=C1CCC(N2C(=O)c3ccccc3C2=O)C(=O)N1
      String rThal = "O=C1CC[C@H](N2C(=O)c3ccccc3C2=O)C(=O)N1";
      String sThal = "O=C1CC[C@@H](N2C(=O)c3ccccc3C2=O)C(=O)N1";
      int sz = mcsSize(rThal, sThal);
      assertTrue(sz >= 17, "Thalidomide enantiomers should match fully without chirality");
    }

    @Test @Timeout(10) @DisplayName("3.04 Cis-decalin vs trans-decalin no stereo")
    void cisVsTransDecalinNoStereo() throws Exception {
      // cis-decalin
      String cisDec = "[C@H]1(CCC[C@@H]2CCCC1)C2";
      // trans-decalin
      String transDec = "[C@@H]1(CCC[C@@H]2CCCC1)C2";
      // Without stereo, these are the same constitutional formula
      int sz = mcsSize(cisDec, transDec);
      assertTrue(sz >= 10, "Decalin isomers should fully overlap without stereo");
    }

    @Test @Timeout(10) @DisplayName("3.05 D-glucose vs L-glucose same MCS no chirality")
    void glucoseEnantiomersNoChirality() throws Exception {
      String dGluc = "OC[C@@H](O)[C@H](O)[C@@H](O)[C@@H](O)C=O";
      String lGluc = "OC[C@H](O)[C@@H](O)[C@H](O)[C@H](O)C=O";
      int sz = mcsSize(dGluc, lGluc);
      assertTrue(sz >= 12, "Glucose enantiomers should fully match without chirality");
    }

    @Test @Timeout(10) @DisplayName("3.06 Methadone vs levomethadone same MCS no chirality")
    void methadoneVsLevomethadone() throws Exception {
      // Methadone: CC(C(=O)CC)(c1ccccc1)c1ccccc1 (racemic)
      // Levomethadone: C[C@@H](C(=O)CC)(c1ccccc1) — but SMILES may vary
      // Use the shared scaffold
      String rac = "CCC(=O)C(CC)(c1ccccc1)c1ccccc1";
      String levo = "CCC(=O)[C@@](CC)(c1ccccc1)c1ccccc1";
      int sz = mcsSize(rac, levo);
      assertTrue(sz >= 15, "Racemic and levo-methadone should share full scaffold");
    }

    @Test @Timeout(10) @DisplayName("3.07 R,S-alanine vs unspecified alanine")
    void alanineVsUnspecified() throws Exception {
      int sz = mcsSize("NC(C)C(=O)O", "N[C@@H](C)C(=O)O");
      assertEquals(6, sz, "Unspecified should match chiral alanine fully");
    }

    @Test @Timeout(10) @DisplayName("3.08 E-stilbene vs Z-stilbene no bond stereo")
    void eVsZStilbeneNoBondStereo() throws Exception {
      String eStilb = "C(/c1ccccc1)=C/c1ccccc1";
      String zStilb = "C(/c1ccccc1)=C\\c1ccccc1";
      int sz = mcsSize(eStilb, zStilb);
      assertTrue(sz >= 14, "E/Z stilbene should fully match without bond stereo");
    }

    @Test @Timeout(10) @DisplayName("3.09 E-stilbene vs Z-stilbene WITH bond stereo")
    void eVsZStilbeneWithBondStereo() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useBondStereo = true;
      String eStilb = "C(/c1ccccc1)=C/c1ccccc1";
      String zStilb = "C(/c1ccccc1)=C\\c1ccccc1";
      int sz = mcsSize(eStilb, zStilb, opts, 5000L);
      // With bond stereo, the double bond center may not match, but rings still do
      assertTrue(sz >= 6, "Even with bond stereo, phenyl rings should overlap");
    }

    @Test @Timeout(10) @DisplayName("3.10 Meso-tartaric acid vs L-tartaric acid")
    void mesoVsLTartaricAcid() throws Exception {
      String meso = "OC(=O)[C@@H](O)[C@H](O)C(=O)O";
      String lTart = "OC(=O)[C@H](O)[C@H](O)C(=O)O";
      int sz = mcsSize(meso, lTart);
      assertTrue(sz >= 10, "Tartaric acid diastereomers share full connectivity");
    }
  }

  // ======================================================================
  // 4. REACTION-RELEVANT MCS (10 tests)
  // ======================================================================

  @Nested
  @DisplayName("4. Reaction-relevant MCS")
  class ReactionRelevantMcs {

    @Test @Timeout(10) @DisplayName("4.01 Ethanol to acetaldehyde: MCS reveals OH->CHO")
    void ethanolToAcetaldehyde() throws Exception {
      // ethanol: CCO, acetaldehyde: CC=O
      int sz = mcsSize("CCO", "CC=O", looseOpts(), 5000L);
      assertTrue(sz >= 2, "Should share at least CC fragment");
    }

    @Test @Timeout(10) @DisplayName("4.02 Aniline to acetanilide: MCS reveals amide formation")
    void anilineToAcetanilide() throws Exception {
      // aniline: Nc1ccccc1, acetanilide: CC(=O)Nc1ccccc1
      int sz = mcsSize("Nc1ccccc1", "CC(=O)Nc1ccccc1");
      assertTrue(sz >= 7, "Aniline ring+N should be in acetanilide MCS");
    }

    @Test @Timeout(10) @DisplayName("4.03 Acetic acid to ethyl acetate: ester formation")
    void aceticAcidToEthylAcetate() throws Exception {
      int sz = mcsSize("CC(=O)O", "CCOC(C)=O");
      assertTrue(sz >= 3, "Should share acetyl core");
    }

    @Test @Timeout(10) @DisplayName("4.04 Phenol to anisole: O-methylation")
    void phenolToAnisole() throws Exception {
      // phenol: Oc1ccccc1, anisole: COc1ccccc1
      int sz = mcsSize("Oc1ccccc1", "COc1ccccc1");
      assertTrue(sz >= 7, "Phenol is substructure of anisole");
    }

    @Test @Timeout(10) @DisplayName("4.05 Propylene to propylene oxide: epoxidation")
    void propyleneToEpoxide() throws Exception {
      // propylene: CC=C, propylene oxide: CC1CO1
      int sz = mcsSize("CC=C", "CC1CO1", looseOpts(), 5000L);
      assertTrue(sz >= 2, "Should share CC fragment");
    }

    @Test @Timeout(10) @DisplayName("4.06 Benzene to phenol: hydroxylation")
    void benzeneToPheno() throws Exception {
      int sz = mcsSize("c1ccccc1", "Oc1ccccc1");
      assertTrue(sz >= 6, "Benzene should be substructure of phenol");
    }

    @Test @Timeout(10) @DisplayName("4.07 Cyclohexane to cyclohexanone: oxidation")
    void cyclohexaneToCyclohexanone() throws Exception {
      int sz = mcsSize("C1CCCCC1", "O=C1CCCCC1", looseOpts(), 5000L);
      assertTrue(sz >= 5, "Should share 5+ ring carbons");
    }

    @Test @Timeout(10) @DisplayName("4.08 Toluene to benzoic acid: side-chain oxidation")
    void tolueneTobenzoicAcid() throws Exception {
      int sz = mcsSize("Cc1ccccc1", "OC(=O)c1ccccc1");
      assertTrue(sz >= 6, "Should share benzene ring");
    }

    @Test @Timeout(10) @DisplayName("4.09 Benzaldehyde to benzoic acid: oxidation")
    void benzaldehydeToBenzoicAcid() throws Exception {
      int sz = mcsSize("O=Cc1ccccc1", "OC(=O)c1ccccc1", looseOpts(), 5000L);
      assertTrue(sz >= 7, "Aldehyde and acid share ring + carbonyl carbon");
    }

    @Test @Timeout(10) @DisplayName("4.10 Nitrobenzene to aniline: reduction")
    void nitrobenzeneToAniline() throws Exception {
      int sz = mcsSize("[O-][N+](=O)c1ccccc1", "Nc1ccccc1", looseOpts(), 5000L);
      assertTrue(sz >= 6, "Should share benzene ring");
    }
  }

  // ======================================================================
  // 5. MULTI-RING TOPOLOGY (10 tests)
  // ======================================================================

  @Nested
  @DisplayName("5. Multi-ring Topology")
  class MultiRingTopology {

    @Test @Timeout(10) @DisplayName("5.01 Bicyclo[2.1.0]pentane self-match")
    void housaneSelfMatch() throws Exception {
      // bicyclo[2.1.0]pentane: C1CC2CC12
      int sz = mcsSize("C1CC2CC12", "C1CC2CC12");
      assertEquals(5, sz, "Housane self-match should be 5");
    }

    @Test @Timeout(10) @DisplayName("5.02 Prismane self-match")
    void prismaneSelfMatch() throws Exception {
      // prismane: C12C3C1C4C2C34 — 6 carbons
      int sz = mcsSize("C12C3C1C4C2C34", "C12C3C1C4C2C34");
      assertEquals(6, sz, "Prismane self-match should be 6");
    }

    @Test @Timeout(10) @DisplayName("5.03 Spiro[4.4]nonane self-match = 9")
    void spiro44NonaneSelfMatch() throws Exception {
      // spiro[4.4]nonane: C1CCC2(C1)CCCC2
      int sz = mcsSize("C1CCC2(C1)CCCC2", "C1CCC2(C1)CCCC2");
      assertEquals(9, sz, "Spiro[4.4]nonane self-match");
    }

    @Test @Timeout(10) @DisplayName("5.04 Spiro[5.5]undecane self-match = 11")
    void spiro55UndecaneSelfMatch() throws Exception {
      // spiro[5.5]undecane: C1CCCCC1(CCCCC1)  -> C1CCCCC12CCCCC2
      int sz = mcsSize("C1CCCCC12CCCCC2", "C1CCCCC12CCCCC2");
      assertEquals(11, sz, "Spiro[5.5]undecane self-match");
    }

    @Test @Timeout(10) @DisplayName("5.05 Norbornane self-match = 7")
    void norbornaneSelfMatch() throws Exception {
      // norbornane (bicyclo[2.2.1]heptane): C1CC2CC1CC2
      int sz = mcsSize("C1CC2CC1CC2", "C1CC2CC1CC2");
      assertEquals(7, sz, "Norbornane self-match");
    }

    @Test @Timeout(10) @DisplayName("5.06 Bicyclo[2.2.2]octane self-match = 8")
    void bicyclo222OctaneSelfMatch() throws Exception {
      // C1CC2CCC1CC2
      int sz = mcsSize("C1CC2CCC1CC2", "C1CC2CCC1CC2");
      assertEquals(8, sz, "Bicyclo[2.2.2]octane self-match");
    }

    @Test @Timeout(10) @DisplayName("5.07 Norbornane as substructure of norbornene")
    void norbornaneInNorbornene() throws Exception {
      // norbornene: C1=CC2CC1CC2
      int sz = mcsSize("C1CC2CC1CC2", "C1=CC2CC1CC2", looseOpts(), 5000L);
      assertTrue(sz >= 7, "Norbornane should map fully into norbornene (loose)");
    }

    @Test @Timeout(10) @DisplayName("5.08 Biphenylene self-match")
    void biphenyleneSelfMatch() throws Exception {
      // biphenylene: c1ccc2-c3ccccc3-c2c1 (12 atoms)
      int sz = mcsSize("c1ccc2-c3ccccc3-c2c1", "c1ccc2-c3ccccc3-c2c1");
      assertEquals(12, sz, "Biphenylene self-match");
    }

    @Test @Timeout(10) @DisplayName("5.09 Indane self-match = 9")
    void indaneSelfMatch() throws Exception {
      // indane: C1Cc2ccccc2C1 — 9 heavy atoms
      int sz = mcsSize("C1Cc2ccccc2C1", "C1Cc2ccccc2C1");
      assertEquals(9, sz, "Indane self-match");
    }

    @Test @Timeout(10) @DisplayName("5.10 Fluorene self-match = 13")
    void fluoreneSelfMatch() throws Exception {
      // fluorene: c1ccc2c(c1)Cc1ccccc1-2  — 13 heavy atoms
      int sz = mcsSize("c1ccc2c(c1)Cc1ccccc1-2", "c1ccc2c(c1)Cc1ccccc1-2");
      assertEquals(13, sz, "Fluorene self-match");
    }
  }

  // ======================================================================
  // 6. PHARMACOPHORE-RELEVANT MCS (10 tests)
  // ======================================================================

  @Nested
  @DisplayName("6. Pharmacophore-relevant MCS")
  class PharmacophoreMcs {

    @Test @Timeout(10) @DisplayName("6.01 Sildenafil vs tadalafil: PDE5 inhibitors share fused ring")
    void sildenafilVsTadalafil() throws Exception {
      // sildenafil: CCCc1nn(C)c2c1nc(nc2OCC)-c1cc(ccc1OCC)S(=O)(=O)N1CCN(C)CC1
      // tadalafil: O=C1N(CC(N2C1Cc1c2[nH]c2ccccc12)c1ccc2OCOc2c1)C
      // Both are large; use loose matching. They share a small common scaffold.
      String sildenafil = "CCCc1nn(C)c2c(N)nc(nc12)-c1cc(ccc1OCC)S(=O)(=O)N1CCN(C)CC1";
      String tadalafil = "O=C1N(CC(N2C1Cc1c2[nH]c2ccccc12)c1ccc2OCOc2c1)C";
      int sz = mcsSize(sildenafil, tadalafil, looseOpts(), 10_000L);
      assertTrue(sz >= 5, "PDE5 inhibitors should share at least a heterocyclic fragment");
    }

    @Test @Timeout(10) @DisplayName("6.02 Omeprazole vs lansoprazole: PPIs share benzimidazole")
    void omeprazoleVsLansoprazole() throws Exception {
      String omeprazole = "COc1ccc2[nH]c(S(=O)Cc3ncc(C)c(OC)c3C)nc2c1";
      String lansoprazole = "Cc1c(OCC(F)(F)F)ccn1Cc1nc2ccccc2[nH]1";
      // Loose opts — they share benzimidazole moiety (9 atoms)
      int sz = mcsSize(omeprazole, lansoprazole, looseOpts(), 10_000L);
      assertTrue(sz >= 8, "PPIs should share benzimidazole scaffold");
    }

    @Test @Timeout(10) @DisplayName("6.03 Atenolol vs metoprolol: beta-blockers share aryloxypropanolamine")
    void atenololVsMetoprolol() throws Exception {
      String atenolol = "CC(C)NCC(O)COc1ccc(CC(N)=O)cc1";
      String metoprolol = "CC(C)NCC(O)COc1ccc(CCOC)cc1";
      int sz = mcsSize(atenolol, metoprolol, new ChemOptions(), 10_000L);
      assertTrue(sz >= 14, "Beta-blockers should share aryloxypropanolamine core");
    }

    @Test @Timeout(10) @DisplayName("6.04 Cetirizine vs loratadine: antihistamines")
    void cetirizineVsLoratadine() throws Exception {
      String cetirizine = "OC(=O)COCCN1CCN(CC1)C(c1ccccc1)c1ccc(Cl)cc1";
      String loratadine = "CCOC(=O)N1CCC(=C2c3ccc(Cl)cc3CCc3ncccc32)CC1";
      int sz = mcsSize(cetirizine, loratadine, looseOpts(), 10_000L);
      assertTrue(sz >= 6, "Antihistamines should share chlorophenyl + piperidine fragment");
    }

    @Test @Timeout(10) @DisplayName("6.05 Simvastatin vs pravastatin: statins share lactone/acid")
    void simvastatinVsPravastatin() throws Exception {
      String simvastatin = "CCC(C)(C)C(=O)OC1CC(O)C=C2C=CC(C)C(CCC3CC(O)CC(=O)O3)C21";
      String pravastatin = "CCC(C)(C)C(=O)OC1CC(O)C=C2C=CC(C)C(CCC(O)CC(O)CC(=O)O)C21";
      int sz = mcsSize(simvastatin, pravastatin, looseOpts(), 10_000L);
      assertTrue(sz >= 15, "Statins should share large decalin + side chain core");
    }

    @Test @Timeout(10) @DisplayName("6.06 Diazepam vs alprazolam: benzodiazepines")
    void diazepamVsAlprazolam() throws Exception {
      String diazepam = "CN1C(=O)CN=C(c2ccccc2)c2cc(Cl)ccc21";
      String alprazolam = "Cc1nnc2n1-c1ccc(Cl)cc1C(=NC2)c1ccccc1";
      int sz = mcsSize(diazepam, alprazolam, looseOpts(), 10_000L);
      assertTrue(sz >= 10, "Benzodiazepines should share chlorophenyl-diazepine core");
    }

    @Test @Timeout(10) @DisplayName("6.07 Ibuprofen vs naproxen: NSAIDs share arylpropionic acid")
    void ibuprofenVsNaproxen() throws Exception {
      String ibuprofen = "CC(C)Cc1ccc(cc1)C(C)C(=O)O";
      String naproxen = "COc1ccc2cc(C(C)C(=O)O)ccc2c1";
      int sz = mcsSize(ibuprofen, naproxen, new ChemOptions(), 10_000L);
      assertTrue(sz >= 8, "NSAIDs should share arylpropionic acid scaffold");
    }

    @Test @Timeout(10) @DisplayName("6.08 Morphine vs codeine MCS")
    void morphineVsCodeine() throws Exception {
      String morphine = "CN1CCC23C4C1CC5=C(C2C(C=C4)O3)C=C(C=C5)O";
      String codeine = "CN1CCC23C4C1CC5=C(C2C(C=C4)OC3)C=C(C=C5)O";
      // Differ by one O vs OC — share most of the skeleton
      int sz = mcsSize(morphine, codeine);
      assertTrue(sz >= 18, "Morphine and codeine differ by one methyl, large MCS");
    }

    @Test @Timeout(10) @DisplayName("6.09 Fluoxetine vs paroxetine: SSRIs")
    void fluoxetineVsParoxetine() throws Exception {
      String fluoxetine = "CNCCC(Oc1ccc(C(F)(F)F)cc1)c1ccccc1";
      String paroxetine = "Fc1ccc(C2CCNCC2COc2ccc3OCOc3c2)cc1";
      int sz = mcsSize(fluoxetine, paroxetine, looseOpts(), 10_000L);
      assertTrue(sz >= 6, "SSRIs should share fluorophenyl + amine fragment");
    }

    @Test @Timeout(10) @DisplayName("6.10 Captopril vs enalaprilat: ACE inhibitors")
    void captoprilVsEnalaprilat() throws Exception {
      String captopril = "CC(CS)C(=O)N1CCCC1C(=O)O";
      String enalaprilat = "OC(=O)C(CC(=O)O)NC(C)C(=O)N1CCCC1C(=O)O";
      int sz = mcsSize(captopril, enalaprilat, looseOpts(), 10_000L);
      assertTrue(sz >= 7, "ACE inhibitors should share proline + acyl fragment");
    }
  }
}
