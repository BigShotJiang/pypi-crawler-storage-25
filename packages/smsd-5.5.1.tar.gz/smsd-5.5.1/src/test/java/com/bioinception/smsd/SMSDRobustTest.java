/*
 * SPDX-License-Identifier: Apache-2.0
 * © 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.params.provider.Arguments.arguments;

import com.bioinception.smsd.core.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.smiles.SmilesParser;

/**
 * Parameterised tests across diverse chemical cases: chains, aromatics, stereo, disconnections,
 * functionals, recursive SMARTS, extras. Every assertion is chemically validated.
 */
public class SMSDRobustTest extends TestBase {

  // -----------------------------
  // Case generators
  // -----------------------------

  /** Alkane chains: C×k is always a substructure of C×(k+2). */
  static Stream<Arguments> chainCases() {
    List<Arguments> out = new ArrayList<>();
    for (int k = 2; k <= 21; k++) {
      out.add(arguments("chain_" + k, "C".repeat(k), "C".repeat(k + 2), true));
    }
    return out.stream();
  }

  /** Aromatic: benzene in naphthalene (true); aromatic vs Kekulé benzene (true). */
  static Stream<Arguments> aromCases() {
    return Stream.of(
        arguments("arom_0", "c1ccccc1", "c1ccc2ccccc2c1", true),
        arguments("arom_1", "c1ccccc1", "C1=CC=CC=C1", true));
  }

  /** Stereo: no stereo flag enabled → topological match → both true. */
  static Stream<Arguments> stereoCases() {
    return Stream.of(
        arguments("stereo_0", "C/C=C\\C", "C/C=C\\C", true),
        arguments("stereo_1", "C/C=C\\C", "C/C=C/C", true));
  }

  /** Disconnected fragments: two separate C atoms found in ethane. */
  static Stream<Arguments> disconnCases() {
    return Stream.of(arguments("disc_0", "C.C", "CC", true));
  }

  /**
   * Functional group tests: fx_0: amide NC(=O) is in NCC(=O)NCCC → true fx_1: [O-]C=O vs OC=O →
   * false (matchFormalCharge=true by default: [O-] ≠ O)
   */
  static Stream<Arguments> functionalCases() {
    return Stream.of(
        arguments("fx_0", "NC(=O)", "NCC(=O)NCCC", true),
        arguments("fx_1", "[O-]C=O", "OC=O", false));
  }

  /**
   * Extra diverse cases. Expected results are chemically validated: - extra_g: CF3 (fluoroform) is
   * NOT a substructure of CC(C)(F)F (only 2 fluorines)
   */
  static Stream<Arguments> extraCases() {
    return Stream.of(
        arguments("extra_a", "c1ccccc1CC", "c1ccccc1CCCC", true),
        arguments("extra_b", "CCN(CC)CC", "CCN(CC)CCO", true),
        // Cyclohexane is NOT a substructure of cycloheptane with ringMatchesRingOnly=true:
        // a 6-membered ring cannot map into a 7-membered ring as an induced subgraph
        arguments("extra_c", "C1CCCCC1", "C1CCCCCC1", false),
        arguments("extra_d", "[13CH3]C", "CC", true),
        arguments("extra_e", "c1ncccc1", "c1ncccc1Cl", true),
        arguments("extra_f", "N1CCOCC1", "O=C(N1CCOCC1)C", true),
        arguments("extra_g", "FC(F)F", "CC(C)(F)F", false),
        arguments("extra_h", "O=S(=O)N", "O=S(=O)NCC", true),
        arguments("extra_i", "P(=O)(O)O", "OP(=O)(O)OCC", true),
        arguments("extra_j", "Clc1ccccc1", "Clc1ccc(Cl)cc1", true));
  }

  /** All SMILES-based substructure cases with expected boolean. */
  static Stream<Arguments> allSmilesCases() {
    return Stream.of(
            chainCases(),
            aromCases(),
            stereoCases(),
            disconnCases(),
            functionalCases(),
            extraCases())
        .flatMap(s -> s);
  }

  /** SMARTS query cases: must use the SMARTS constructor for correct matching. */
  static Stream<Arguments> smartsCases() {
    return Stream.of(
        // rec_0: recursive SMARTS for carboxyl carbon matches acetic acid
        arguments("rec_0", "[C;$(C(=O)O)]", "CC(=O)O", true),
        // rec_1: named predicate $isAmideN matches amide nitrogen in target
        arguments("rec_1", "[N;$isAmideN]", "CC(=O)NCC", true));
  }

  /** MCS subset: first 30 SMILES cases. */
  static Stream<Arguments> mcsSubset() {
    return allSmilesCases().limit(30);
  }

  // Removed: extraCasesRepeated() was running 90 duplicate tests (9 copies of 10 cases).

  // -----------------------------
  // Tests
  // -----------------------------

  @ParameterizedTest(name = "{0}")
  @MethodSource("allSmilesCases")
  @DisplayName("Substructure SMILES cases with chemical assertions")
  void test_substructure_smiles(String name, String q, String t, boolean expected)
      throws Exception {
    SmilesParser sp = new SmilesParser(DefaultChemObjectBuilder.getInstance());
    IAtomContainer queryMol = sp.parseSmiles(q);
    IAtomContainer targetMol = sp.parseSmiles(t);
    SMSD smsd = new SMSD(queryMol, targetMol, new ChemOptions());
    boolean ok = smsd.isSubstructure();
    assertEquals(expected, ok, name + ": '" + q + "' vs '" + t + "' expected " + expected);
  }

  // Removed: test_substructure_extra_repeated ran 90 duplicate tests identical to extraCases.

  @ParameterizedTest(name = "{0}")
  @MethodSource("smartsCases")
  @DisplayName("SMARTS query substructure (uses SMARTS constructor)")
  void test_substructure_smarts(String name, String smarts, String t, boolean expected)
      throws Exception {
    SmilesParser sp = new SmilesParser(DefaultChemObjectBuilder.getInstance());
    IAtomContainer targetMol = sp.parseSmiles(t);
    targetMol = Standardiser.standardise(targetMol, Standardiser.TautomerMode.NONE);
    // Expand named predicates (e.g., $isAmideN) before matching
    Standardiser.PredicateRegistry reg = new Standardiser.PredicateRegistry();
    String expanded = Standardiser.expandNamedPredicates(smarts, reg);
    SMSD smsd = new SMSD(expanded, targetMol, new ChemOptions());
    boolean ok = smsd.isSubstructure();
    assertEquals(
        expected,
        ok,
        name
            + ": SMARTS '"
            + smarts
            + "' (expanded: '"
            + expanded
            + "') vs '"
            + t
            + "' expected "
            + expected);
  }

  @ParameterizedTest(name = "{0}")
  @MethodSource("mcsSubset")
  @DisplayName("MCS on subset (induced, connected)")
  void test_mcs_runs_mcisd(String name, String q, String t, boolean ignoredExpected)
      throws Exception {
    SmilesParser sp = new SmilesParser(DefaultChemObjectBuilder.getInstance());
    IAtomContainer queryMol = sp.parseSmiles(q);
    IAtomContainer targetMol = sp.parseSmiles(t);
    SMSD smsd = new SMSD(queryMol, targetMol, new ChemOptions());
    Map<Integer, Integer> mr = smsd.findMCS(true, true, 2500L);
    assertNotNull(mr, name + ": MCS should not be null");
    // Query and target always share at least some atoms
    // For cases where both molecules share atom types, MCS should be non-empty
    // For cases where they don't (e.g., fx_1: [O-]C=O vs OC=O with charge matching),
    // MCS may be empty. Just verify it returned a valid map.
    assertNotNull(mr, name + ": MCS result should not be null");
  }

  // Removed: test_cli_json_shape_comment was a trivially-passing placeholder (assertTrue(true)).
}
