/*
 * SPDX-License-Identifier: Apache-2.0
 * (c) 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;

import com.bioinception.smsd.core.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.openscience.cdk.exception.InvalidSmilesException;
import org.openscience.cdk.interfaces.IAtomContainer;

/**
 * Comprehensive edge-case tests covering single-atom molecules, empty inputs,
 * isomers, stereoisomers, charged species, isotopes, heterocycles, functional
 * groups, macrocycles, polymer fragments, drug pairs, symmetry, timeouts, and
 * ChemOptions matrix. Targets 200+ new tests.
 *
 * @author Syed Asad Rahman
 */
@TestMethodOrder(MethodOrderer.DisplayName.class)
public class EdgeCaseTest extends TestBase {

  private static ChemOptions defaultOpts() {
    return new ChemOptions();
  }

  private static ChemOptions looseOpts() {
    ChemOptions c = new ChemOptions();
    c.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
    c.ringMatchesRingOnly = false;
    c.matchFormalCharge = false;
    return c;
  }

  private static ChemOptions stereoOpts() {
    ChemOptions c = new ChemOptions();
    c.useChirality = true;
    c.useBondStereo = true;
    return c;
  }

  // ======================================================================
  // 1. SINGLE ATOM MOLECULES
  // ======================================================================

  @Nested
  @DisplayName("1. SingleAtomMolecules")
  class SingleAtomMolecules {

    @Test @Timeout(10) @DisplayName("1.01 C vs C self-match")
    void carbonSelfMatch() throws Exception {
      SMSD smsd = new SMSD(mol("C"), mol("C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.02 C vs N no match under strict atom type")
    void carbonVsNitrogen() throws Exception {
      SMSD smsd = new SMSD(mol("C"), mol("N"), defaultOpts());
      assertFalse(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.03 O vs O self-match")
    void oxygenSelfMatch() throws Exception {
      SMSD smsd = new SMSD(mol("O"), mol("O"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.04 Single atom MCS C vs C returns size 1")
    void singleAtomMCS() throws Exception {
      SMSD smsd = new SMSD(mol("C"), mol("C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(1, mcs.size());
    }

    @Test @Timeout(10) @DisplayName("1.05 Single C in ethane")
    void singleCarbonInEthane() throws Exception {
      SMSD smsd = new SMSD(mol("C"), mol("CC"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.06 Single N in methylamine")
    void singleNInMethylamine() throws Exception {
      SMSD smsd = new SMSD(mol("N"), mol("CN"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.07 Single O in methanol")
    void singleOInMethanol() throws Exception {
      SMSD smsd = new SMSD(mol("O"), mol("CO"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.08 Single S in methanethiol")
    void singleSInMethanethiol() throws Exception {
      SMSD smsd = new SMSD(mol("S"), mol("CS"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.09 Single C in benzene")
    void singleCInBenzene() throws Exception {
      ChemOptions opts = looseOpts();
      SMSD smsd = new SMSD(mol("C"), mol("c1ccccc1"), opts);
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("1.10 S vs O no match strict")
    void sulfurVsOxygen() throws Exception {
      SMSD smsd = new SMSD(mol("S"), mol("O"), defaultOpts());
      assertFalse(smsd.isSubstructure());
    }
  }

  // ======================================================================
  // 2. EMPTY AND NULL
  // ======================================================================

  @Nested
  @DisplayName("2. EmptyAndNull")
  class EmptyAndNull {

    @Test @Timeout(10) @DisplayName("2.01 Empty SMILES query gives no substructure")
    void emptyQueryNoSubstructure() throws Exception {
      IAtomContainer empty = mol("[H][H]");
      IAtomContainer target = mol("CCO");
      // Hydrogen molecule vs ethanol - no heavy atom overlap
      SMSD smsd = new SMSD(empty, target, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs == null || mcs.isEmpty());
    }

    @Test @Timeout(10) @DisplayName("2.02 Single bond molecule CC")
    void singleBondMolecule() throws Exception {
      SMSD smsd = new SMSD(mol("CC"), mol("CC"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("2.03 Single bond molecule MCS size is 2")
    void singleBondMCSSize() throws Exception {
      SMSD smsd = new SMSD(mol("CC"), mol("CC"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(2, mcs.size());
    }

    @Test @Timeout(10) @DisplayName("2.04 Methane self match")
    void methaneSelfMatch() throws Exception {
      SMSD smsd = new SMSD(mol("C"), mol("C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("2.05 Double bond molecule")
    void doubleBondMolecule() throws Exception {
      SMSD smsd = new SMSD(mol("C=C"), mol("C=C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("2.06 Triple bond molecule")
    void tripleBondMolecule() throws Exception {
      SMSD smsd = new SMSD(mol("C#C"), mol("C#C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("2.07 Ethylene in propylene")
    void ethyleneInPropylene() throws Exception {
      SMSD smsd = new SMSD(mol("C=C"), mol("CC=C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("2.08 Acetylene in propyne")
    void acetyleneInPropyne() throws Exception {
      SMSD smsd = new SMSD(mol("C#C"), mol("CC#C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("2.09 Water self-match")
    void waterSelfMatch() throws Exception {
      SMSD smsd = new SMSD(mol("O"), mol("O"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("2.10 Ammonia self-match")
    void ammoniaSelfMatch() throws Exception {
      SMSD smsd = new SMSD(mol("N"), mol("N"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }
  }

  // ======================================================================
  // 3. ISOMER PAIRS
  // ======================================================================

  @Nested
  @DisplayName("3. IsomerPairs")
  class IsomerPairs {

    @Test @Timeout(10) @DisplayName("3.01 Butane vs isobutane MCS >= 3")
    void butaneVsIsobutane() throws Exception {
      SMSD smsd = new SMSD(mol("CCCC"), mol("CC(C)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3, "Butane vs isobutane share at least 3 atoms");
    }

    @Test @Timeout(10) @DisplayName("3.02 Butane substructure of isobutane (loose)")
    void butaneSubIsobutane() throws Exception {
      SMSD smsd = new SMSD(mol("CCC"), mol("CC(C)C"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("3.03 Pentane vs neopentane MCS >= 3")
    void pentaneVsNeopentane() throws Exception {
      SMSD smsd = new SMSD(mol("CCCCC"), mol("CC(C)(C)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("3.04 Pentane vs isopentane MCS >= 4")
    void pentaneVsIsopentane() throws Exception {
      SMSD smsd = new SMSD(mol("CCCCC"), mol("CCCC(C)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("3.05 Ethanol vs dimethyl ether MCS")
    void ethanolVsDimethylEther() throws Exception {
      SMSD smsd = new SMSD(mol("CCO"), mol("COC"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2, "Share at least C-O");
    }

    @Test @Timeout(10) @DisplayName("3.06 Ortho-xylene vs meta-xylene MCS >= 8")
    void orthoVsMetaXylene() throws Exception {
      SMSD smsd = new SMSD(mol("Cc1ccccc1C"), mol("Cc1cccc(C)c1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 7, "Xylenes share toluene core");
    }

    @Test @Timeout(10) @DisplayName("3.07 Meta-xylene vs para-xylene MCS >= 8")
    void metaVsParaXylene() throws Exception {
      SMSD smsd = new SMSD(mol("Cc1cccc(C)c1"), mol("Cc1ccc(C)cc1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 7);
    }

    @Test @Timeout(10) @DisplayName("3.08 Ortho-xylene vs para-xylene MCS >= 7")
    void orthoVsParaXylene() throws Exception {
      SMSD smsd = new SMSD(mol("Cc1ccccc1C"), mol("Cc1ccc(C)cc1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 7);
    }

    @Test @Timeout(10) @DisplayName("3.09 1-propanol vs 2-propanol MCS >= 3")
    void propanolIsomers() throws Exception {
      SMSD smsd = new SMSD(mol("CCCO"), mol("CC(O)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("3.10 Propanal vs acetone MCS >= 3")
    void propanalVsAcetone() throws Exception {
      SMSD smsd = new SMSD(mol("CCC=O"), mol("CC(=O)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("3.11 Hexane self-match MCS == 6")
    void hexaneSelfMatch() throws Exception {
      SMSD smsd = new SMSD(mol("CCCCCC"), mol("CCCCCC"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(6, mcs.size());
    }

    @Test @Timeout(10) @DisplayName("3.12 Cyclohexane vs hexane: ring vs chain")
    void cyclohexaneVsHexane() throws Exception {
      SMSD smsd = new SMSD(mol("C1CCCCC1"), mol("CCCCCC"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      // Ring-to-ring-only blocks ring mapping to chain
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("3.13 Diethyl ether vs methyl propyl ether")
    void diethylVsMethylPropylEther() throws Exception {
      SMSD smsd = new SMSD(mol("CCOCC"), mol("COCCC"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("3.14 Acetic acid vs methyl formate")
    void aceticAcidVsMethylFormate() throws Exception {
      SMSD smsd = new SMSD(mol("CC(=O)O"), mol("COC=O"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("3.15 Propylamine vs trimethylamine")
    void propylVsTrimethylamine() throws Exception {
      SMSD smsd = new SMSD(mol("CCCN"), mol("CN(C)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("3.16 Toluene substructure of xylene")
    void tolueneInXylene() throws Exception {
      SMSD smsd = new SMSD(mol("Cc1ccccc1"), mol("Cc1ccccc1C"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("3.17 Benzene in all xylenes")
    void benzeneInXylenes() throws Exception {
      IAtomContainer bz = mol("c1ccccc1");
      assertTrue(new SMSD(bz, mol("Cc1ccccc1C"), looseOpts()).isSubstructure());
      assertTrue(new SMSD(bz, mol("Cc1cccc(C)c1"), looseOpts()).isSubstructure());
      assertTrue(new SMSD(bz, mol("Cc1ccc(C)cc1"), looseOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("3.18 Cyclopentane vs cyclopentene MCS")
    void cyclopentaneVsCyclopentene() throws Exception {
      SMSD smsd = new SMSD(mol("C1CCCC1"), mol("C1=CCCC1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("3.19 Neopentane self MCS == 5")
    void neopentaneSelfMCS() throws Exception {
      SMSD smsd = new SMSD(mol("CC(C)(C)C"), mol("CC(C)(C)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(5, mcs.size());
    }

    @Test @Timeout(10) @DisplayName("3.20 Isopentane self MCS == 5")
    void isopentaneSelfMCS() throws Exception {
      SMSD smsd = new SMSD(mol("CCC(C)C"), mol("CCC(C)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(5, mcs.size());
    }
  }

  // ======================================================================
  // 4. STEREOISOMER PAIRS
  // ======================================================================

  @Nested
  @DisplayName("4. StereoisomerPairs")
  class StereoisomerPairs {

    @Test @Timeout(10) @DisplayName("4.01 E-stilbene vs Z-stilbene no stereo -> match")
    void stilbeneNoStereo() throws Exception {
      SMSD smsd = new SMSD(
          mol("C(/c1ccccc1)=C\\c1ccccc1"),
          mol("C(/c1ccccc1)=C/c1ccccc1"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.02 E-stilbene self-match with stereo")
    void eStilbeneSelfStereo() throws Exception {
      SMSD smsd = new SMSD(
          mol("C(/c1ccccc1)=C/c1ccccc1"),
          mol("C(/c1ccccc1)=C/c1ccccc1"),
          stereoOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.03 R-alanine vs S-alanine no chirality -> match")
    void alanineNoChirality() throws Exception {
      SMSD smsd = new SMSD(
          mol("[C@@H](N)(C)C(=O)O"),
          mol("[C@H](N)(C)C(=O)O"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.04 R-alanine self-match with chirality")
    void rAlanineSelfChirality() throws Exception {
      SMSD smsd = new SMSD(
          mol("[C@@H](N)(C)C(=O)O"),
          mol("[C@@H](N)(C)C(=O)O"),
          stereoOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.05 Cis-2-butene vs trans-2-butene no stereo")
    void cisTransButeneNoStereo() throws Exception {
      SMSD smsd = new SMSD(
          mol("C/C=C\\C"), mol("C/C=C/C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.06 Cis-2-butene self-match with bond stereo")
    void cisButeneSelfStereo() throws Exception {
      SMSD smsd = new SMSD(
          mol("C/C=C\\C"), mol("C/C=C\\C"), stereoOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.07 Cis-1,2-dimethylcyclohexane self")
    void cisDimethylCyclohexaneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("C[C@H]1CCCC[C@@H]1C"),
          mol("C[C@H]1CCCC[C@@H]1C"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.08 Meso-tartaric acid self-match")
    void mesoTartaricSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("O[C@@H]([C@H](O)C(=O)O)C(=O)O"),
          mol("O[C@@H]([C@H](O)C(=O)O)C(=O)O"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.09 Stilbene MCS without stereo >= 14")
    void stilbeneMCSNoStereo() throws Exception {
      SMSD smsd = new SMSD(
          mol("C(/c1ccccc1)=C\\c1ccccc1"),
          mol("C(/c1ccccc1)=C/c1ccccc1"),
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 10, "Stilbene isomers share most atoms");
    }

    @Test @Timeout(10) @DisplayName("4.10 Alanine MCS without chirality >= 5")
    void alanineMCSNoChirality() throws Exception {
      SMSD smsd = new SMSD(
          mol("[C@@H](N)(C)C(=O)O"),
          mol("[C@H](N)(C)C(=O)O"),
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 5);
    }

    @Test @Timeout(10) @DisplayName("4.11 E-2-pentene vs Z-2-pentene no stereo")
    void penteneIsomersNoStereo() throws Exception {
      SMSD smsd = new SMSD(
          mol("C/C=C/CC"), mol("C/C=C\\CC"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.12 R-glyceraldehyde self")
    void rGlyceraldehydeSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("OC[C@@H](O)C=O"),
          mol("OC[C@@H](O)C=O"),
          stereoOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.13 D-glucose vs L-glucose no chirality")
    void glucoseNoChirality() throws Exception {
      SMSD smsd = new SMSD(
          mol("OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@@H]1O"),
          mol("OC[C@@H]1OC(O)[C@@H](O)[C@H](O)[C@H]1O"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.14 Trans-2-butene self with stereo")
    void transButeneSelfStereo() throws Exception {
      SMSD smsd = new SMSD(
          mol("C/C=C/C"), mol("C/C=C/C"), stereoOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("4.15 E/Z but-2-enol MCS >= 4")
    void butenolMCS() throws Exception {
      SMSD smsd = new SMSD(
          mol("C/C=C/CO"), mol("C/C=C\\CO"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }
  }

  // ======================================================================
  // 5. CHARGED SPECIES
  // ======================================================================

  @Nested
  @DisplayName("5. ChargedSpecies")
  class ChargedSpecies {

    @Test @Timeout(10) @DisplayName("5.01 Carboxylate anion vs carboxylic acid charge match")
    void carboxylateVsAcidCharge() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchFormalCharge = true;
      SMSD smsd = new SMSD(mol("CC([O-])=O"), mol("CC(O)=O"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      // With charge matching, the charged O should not match neutral O
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("5.02 Carboxylate vs acid no charge match -> full overlap")
    void carboxylateVsAcidNoCharge() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("CC([O-])=O"), mol("CC(O)=O"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("5.03 Ammonium vs amine")
    void ammoniumVsAmine() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchFormalCharge = true;
      SMSD smsd = new SMSD(mol("[NH4+]"), mol("N"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      // Charged ammonium vs neutral amine with charge matching
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("5.04 Ammonium vs amine no charge -> match")
    void ammoniumVsAmineNoCharge() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("[NH4+]"), mol("N"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 1);
    }

    @Test @Timeout(10) @DisplayName("5.05 Glycine zwitterion MCS with itself")
    void glycineZwitterionSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("[NH3+]CC([O-])=O"),
          mol("[NH3+]CC([O-])=O"),
          defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("5.06 Glycine zwitterion vs neutral glycine")
    void glycineZwitterionVsNeutral() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(
          mol("[NH3+]CC([O-])=O"),
          mol("NCC(O)=O"),
          opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("5.07 Sodium acetate vs acetic acid")
    void sodiumAcetateVsAceticAcid() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("CC([O-])=O"), mol("CC(O)=O"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("5.08 Phenoxide vs phenol")
    void phenoxideVsPhenol() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("[O-]c1ccccc1"), mol("Oc1ccccc1"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6);
    }

    @Test @Timeout(10) @DisplayName("5.09 Trimethylammonium self-match")
    void trimethylammoniumSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("C[NH+](C)C"), mol("C[NH+](C)C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("5.10 Phosphate vs phosphoric acid no charge")
    void phosphateVsPhosphoricAcid() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("[O-]P([O-])([O-])=O"), mol("OP(O)(O)=O"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("5.11 Sulfonate vs sulfonic acid")
    void sulfonateVsSulfonicAcid() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("CS([O-])(=O)=O"), mol("CS(O)(=O)=O"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("5.12 Pyridinium vs pyridine")
    void pyridiniumVsPyridine() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("c1cc[nH+]cc1"), mol("c1ccncc1"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 5);
    }

    @Test @Timeout(10) @DisplayName("5.13 Betaine self-match")
    void betaineSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("C[N+](C)(C)CC([O-])=O"),
          mol("C[N+](C)(C)CC([O-])=O"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("5.14 Histidine protonated vs neutral")
    void histidineProtonatedVsNeutral() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(
          mol("NC(Cc1c[nH+]c[nH]1)C(=O)O"),
          mol("NC(Cc1cnc[nH]1)C(=O)O"),
          opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 7);
    }

    @Test @Timeout(10) @DisplayName("5.15 Lithium carboxylate substructure")
    void lithiumCarboxylate() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("CC([O-])=O"), mol("CC(=O)[O-].[Li+]"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }
  }

  // ======================================================================
  // 6. ISOTOPE LABELED
  // ======================================================================

  @Nested
  @DisplayName("6. IsotopeLabeled")
  class IsotopeLabeled {

    @Test @Timeout(10) @DisplayName("6.01 Deuterium water vs water no isotope match")
    void deuteriumWaterNoIsotope() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = false;
      SMSD smsd = new SMSD(mol("[2H]O[2H]"), mol("O"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 1);
    }

    @Test @Timeout(10) @DisplayName("6.02 Deuterium water self-match with isotope")
    void deuteriumWaterSelfIsotope() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = true;
      SMSD smsd = new SMSD(mol("[2H]O[2H]"), mol("[2H]O[2H]"), opts);
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("6.03 13C-methane vs methane no isotope")
    void c13MethaneNoIsotope() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = false;
      SMSD smsd = new SMSD(mol("[13CH4]"), mol("C"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 1);
    }

    @Test @Timeout(10) @DisplayName("6.04 13C-methane self with isotope match")
    void c13MethaneSelfIsotope() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = true;
      SMSD smsd = new SMSD(mol("[13CH4]"), mol("[13CH4]"), opts);
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("6.05 18F-fluoride vs fluoride no isotope")
    void f18NoIsotope() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = false;
      SMSD smsd = new SMSD(mol("[18F]"), mol("[F]"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("6.06 Tritium-labeled methanol self")
    void tritiumMethanol() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = true;
      SMSD smsd = new SMSD(mol("[3H]CO"), mol("[3H]CO"), opts);
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("6.07 14C-ethanol vs ethanol no isotope")
    void c14EthanolNoIsotope() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = false;
      SMSD smsd = new SMSD(mol("[14C]CO"), mol("CCO"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("6.08 Deuterated benzene vs benzene no isotope")
    void deuteratedBenzeneNoIsotope() throws Exception {
      ChemOptions opts = looseOpts();
      opts.matchIsotope = false;
      SMSD smsd = new SMSD(
          mol("[2H]c1c([2H])c([2H])c([2H])c([2H])c1[2H]"),
          mol("c1ccccc1"),
          opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6);
    }

    @Test @Timeout(10) @DisplayName("6.09 15N-glycine vs glycine no isotope")
    void n15GlycineNoIsotope() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = false;
      SMSD smsd = new SMSD(mol("[15NH2]CC(=O)O"), mol("NCC(=O)O"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("6.10 Mixed isotope ethane self")
    void mixedIsotopeEthaneSelf() throws Exception {
      ChemOptions opts = defaultOpts();
      opts.matchIsotope = true;
      SMSD smsd = new SMSD(mol("[13C][12C]"), mol("[13C][12C]"), opts);
      assertTrue(smsd.isSubstructure());
    }
  }

  // ======================================================================
  // 7. HETEROCYCLE PAIRS
  // ======================================================================

  @Nested
  @DisplayName("7. HeterocyclePairs")
  class HeterocyclePairs {

    @Test @Timeout(10) @DisplayName("7.01 Pyridine self-match")
    void pyridineSelf() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccncc1"), mol("c1ccncc1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.02 Pyrrole self-match")
    void pyrroleSelf() throws Exception {
      SMSD smsd = new SMSD(mol("c1cc[nH]c1"), mol("c1cc[nH]c1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.03 Furan self-match")
    void furanSelf() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccoc1"), mol("c1ccoc1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.04 Thiophene self-match")
    void thiopheneSelf() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccsc1"), mol("c1ccsc1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.05 Imidazole self-match")
    void imidazoleSelf() throws Exception {
      SMSD smsd = new SMSD(mol("c1cnc[nH]1"), mol("c1cnc[nH]1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.06 Pyrimidine self-match")
    void pyrimidineSelf() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccncn1"), mol("c1ccncn1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.07 Purine self-match")
    void purineSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1=CN=C2N1C=NC=N2"), mol("C1=CN=C2N1C=NC=N2"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.08 Indole self-match")
    void indoleSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2[nH]ccc2c1"), mol("c1ccc2[nH]ccc2c1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.09 Quinoline self-match")
    void quinolineSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2ncccc2c1"), mol("c1ccc2ncccc2c1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.10 Isoquinoline self-match")
    void isoquinolineSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2cnccc2c1"), mol("c1ccc2cnccc2c1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.11 Pyridine in nicotinic acid")
    void pyridineInNicotinicAcid() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccncc1"), mol("OC(=O)c1cccnc1"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.12 Pyrrole in tryptophan")
    void pyrroleInTryptophan() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1cc[nH]c1"),
          mol("NC(Cc1c[nH]c2ccccc12)C(=O)O"),
          looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.13 Furan in furfural")
    void furanInFurfural() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccoc1"), mol("O=Cc1ccco1"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.14 Thiophene in thienyl acetic acid")
    void thiopheneInDrug() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccsc1"), mol("OC(=O)Cc1cccs1"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.15 Imidazole in histamine")
    void imidazoleInHistamine() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1cnc[nH]1"), mol("NCCc1cnc[nH]1"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("7.16 Pyridine vs pyrimidine MCS >= 4")
    void pyridineVsPyrimidine() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccncc1"), mol("c1ccncn1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("7.17 Quinoline vs isoquinoline MCS >= 8")
    void quinolineVsIsoquinoline() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2ncccc2c1"), mol("c1ccc2cnccc2c1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 8);
    }

    @Test @Timeout(10) @DisplayName("7.18 Indole vs benzofuran MCS >= 7")
    void indoleVsBenzofuran() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2[nH]ccc2c1"), mol("c1ccc2occc2c1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 7);
    }

    @Test @Timeout(10) @DisplayName("7.19 Purine in adenine")
    void purineInAdenine() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1=CN=C2N1C=NC=N2"),
          mol("Nc1ncnc2[nH]cnc12"),
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 7);
    }

    @Test @Timeout(10) @DisplayName("7.20 Oxazole vs thiazole MCS >= 3")
    void oxazoleVsThiazole() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1cocn1"), mol("c1cscn1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }
  }

  // ======================================================================
  // 8. FUNCTIONAL GROUP PAIRS
  // ======================================================================

  @Nested
  @DisplayName("8. FunctionalGroupPairs")
  class FunctionalGroupPairs {

    @Test @Timeout(10) @DisplayName("8.01 Alcohol: methanol self")
    void methanolSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CO"), mol("CO"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.02 Aldehyde: formaldehyde in acetaldehyde")
    void formaldehydeInAcetaldehyde() throws Exception {
      SMSD smsd = new SMSD(mol("C=O"), mol("CC=O"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.03 Ketone: acetone self")
    void acetoneSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CC(=O)C"), mol("CC(=O)C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.04 Carboxylic acid: acetic acid self")
    void aceticAcidSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CC(=O)O"), mol("CC(=O)O"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.05 Ester: methyl acetate self")
    void methylAcetateSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CC(=O)OC"), mol("CC(=O)OC"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.06 Amide: acetamide self")
    void acetamideSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CC(=O)N"), mol("CC(=O)N"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.07 Amine: ethylamine in diethylamine")
    void ethylamineInDiethylamine() throws Exception {
      SMSD smsd = new SMSD(mol("CCN"), mol("CCNCC"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.08 Nitrile: acetonitrile self")
    void acetonitrileSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CC#N"), mol("CC#N"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.09 Nitro: nitromethane self")
    void nitromethaneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("C[N+](=O)[O-]"), mol("C[N+](=O)[O-]"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.10 Aldehyde vs ketone MCS >= 2")
    void aldehydeVsKetone() throws Exception {
      SMSD smsd = new SMSD(mol("CC=O"), mol("CC(=O)C"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("8.11 Ester vs amide MCS >= 2")
    void esterVsAmide() throws Exception {
      SMSD smsd = new SMSD(mol("CC(=O)OC"), mol("CC(=O)NC"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("8.12 Alcohol in phenol")
    void alcoholInPhenol() throws Exception {
      SMSD smsd = new SMSD(mol("CO"), mol("Oc1ccccc1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 1);
    }

    @Test @Timeout(10) @DisplayName("8.13 Thiol: methanethiol self")
    void methanethiolSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CS"), mol("CS"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.14 Sulfoxide: DMSO self")
    void dmsoSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CS(=O)C"), mol("CS(=O)C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.15 Sulfone: dimethyl sulfone self")
    void dimethylSulfoneSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CS(=O)(=O)C"), mol("CS(=O)(=O)C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.16 Ether: diethyl ether self")
    void diethylEtherSelf() throws Exception {
      SMSD smsd = new SMSD(mol("CCOCC"), mol("CCOCC"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.17 Epoxide self-match")
    void epoxideSelf() throws Exception {
      SMSD smsd = new SMSD(mol("C1CO1"), mol("C1CO1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.18 Acid anhydride self")
    void anhydrideSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("CC(=O)OC(=O)C"), mol("CC(=O)OC(=O)C"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.19 Carboxylic acid in amino acid")
    void carboxylicInAminoAcid() throws Exception {
      SMSD smsd = new SMSD(mol("CC(=O)O"), mol("NCC(=O)O"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("8.20 Nitrile vs isonitrile MCS >= 1")
    void nitrileVsIsonitrile() throws Exception {
      SMSD smsd = new SMSD(mol("CC#N"), mol("C[N+]#[C-]"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 1);
    }
  }

  // ======================================================================
  // 9. MACROCYCLE PAIRS
  // ======================================================================

  @Nested
  @DisplayName("9. MacrocyclePairs")
  class MacrocyclePairs {

    @Test @Timeout(10) @DisplayName("9.01 12-crown-4 self-match")
    void crown4Self() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1COCCOCCOCCO1"), mol("C1COCCOCCOCCO1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("9.02 15-crown-5 self-match")
    void crown5Self() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1COCCOCCOCCOCCOC1"), mol("C1COCCOCCOCCOCCOC1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("9.03 12-crown-4 vs 15-crown-5 MCS >= 8")
    void crown4VsCrown5() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1COCCOCCOCCO1"),
          mol("C1COCCOCCOCCOCCOC1"),
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6, "Crown ethers share polyether fragment");
    }

    @Test @Timeout(10) @DisplayName("9.04 Porphyrin core: pyrrole substructure")
    void pyrroleInPorphyrin() throws Exception {
      // Simplified porphine fragment
      SMSD smsd = new SMSD(
          mol("c1cc[nH]c1"),
          mol("C1=CC2=CC3=CC(=CC4=CC(=CC(=C1)N2)[NH]4)N3"),  // simplified porphyrin Kekule
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4);
    }

    @Test @Timeout(10) @DisplayName("9.05 Cyclodextrin fragment: glucose ring self")
    void glucoseRingSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("OC1CCOC(O)C1O"), mol("OC1CCOC(O)C1O"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("9.06 18-crown-6 self-match")
    void crown6Self() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1COCCOCCOCCOCCOCCO1"),
          mol("C1COCCOCCOCCOCCOCCO1"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("9.07 Macrolactone 12-membered ring self")
    void macrolactoneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("O=C1CCCCCCCCCCCO1"),
          mol("O=C1CCCCCCCCCCCO1"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("9.08 Large ring vs linear chain")
    void largeRingVsChain() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1CCCCCCCCCCC1"), mol("CCCCCCCCCCCC"), defaultOpts());
      // With ringMatchesRingOnly=true, ring shouldn't fully map to chain
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("9.09 Macrolactam self")
    void macrolactamSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("O=C1CCCCCCCCCCCN1"),
          mol("O=C1CCCCCCCCCCCN1"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("9.10 Crown ether fragment MCS with 18-crown-6")
    void crownFragmentInCrown6() throws Exception {
      SMSD smsd = new SMSD(
          mol("COCCOC"),
          mol("C1COCCOCCOCCOCCOCCO1"),
          looseOpts());
      // MCS should find the shared -C-O-C-C-O-C- fragment
      var mcs = smsd.findMCS(false, false, 5000L);
      assertTrue(mcs.size() >= 5, "Crown fragment MCS should be >= 5, got " + mcs.size());
    }
  }

  // ======================================================================
  // 10. POLYMER FRAGMENTS
  // ======================================================================

  @Nested
  @DisplayName("10. PolymerFragments")
  class PolymerFragments {

    @Test @Timeout(10) @DisplayName("10.01 PEG dimer in PEG trimer")
    void pegDimerInTrimer() throws Exception {
      SMSD smsd = new SMSD(
          mol("OCCOCCO"), mol("OCCOCCOCCOC"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("10.02 PEG monomer in PEG dimer")
    void pegMonomerInDimer() throws Exception {
      SMSD smsd = new SMSD(mol("OCCO"), mol("OCCOCCO"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("10.03 PEG trimer self-match")
    void pegTrimerSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("OCCOCCOCCOC"), mol("OCCOCCOCCOC"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("10.04 Lactic acid dimer self-match")
    void lacticAcidDimerSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("CC(O)C(=O)OC(C)C(=O)O"),
          mol("CC(O)C(=O)OC(C)C(=O)O"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("10.05 Lactic acid monomer in dimer")
    void lacticMonomerInDimer() throws Exception {
      SMSD smsd = new SMSD(
          mol("CC(O)C(=O)O"),
          mol("CC(O)C(=O)OC(C)C(=O)O"),
          looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("10.06 Nylon-6 monomer: caprolactam self")
    void caprolactamSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("O=C1CCCCCN1"), mol("O=C1CCCCCN1"), defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("10.07 Nylon-6,6 monomer MCS >= 4")
    void nylon66Monomer() throws Exception {
      SMSD smsd = new SMSD(
          mol("NCCCCCCN"), mol("OC(=O)CCCCC(=O)O"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4, "Share hexyl chain");
    }

    @Test @Timeout(10) @DisplayName("10.08 Styrene monomer in polystyrene dimer")
    void styreneInDimer() throws Exception {
      SMSD smsd = new SMSD(
          mol("C=Cc1ccccc1"),
          mol("CC(c1ccccc1)CC(c1ccccc1)C"),
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6);
    }

    @Test @Timeout(10) @DisplayName("10.09 Ethylene glycol in PEG")
    void ethyleneGlycolInPEG() throws Exception {
      SMSD smsd = new SMSD(mol("OCCO"), mol("OCCOCCOCCOCCOC"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("10.10 Adipic acid self-match")
    void adipicAcidSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("OC(=O)CCCCC(=O)O"),
          mol("OC(=O)CCCCC(=O)O"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }
  }

  // ======================================================================
  // 11. DRUG PAIR MATRIX
  // ======================================================================

  @Nested
  @DisplayName("11. DrugPairMatrix")
  class DrugPairMatrix {

    // Aspirin: CC(=O)Oc1ccccc1C(=O)O
    // Ibuprofen: CC(C)Cc1ccc(C(C)C(=O)O)cc1
    // Caffeine: Cn1c(=O)c2c(ncn2C)n(C)c1=O
    // Morphine: CN1CC[C@]23c4c5ccc(O)c4O[C@H]2C(=C[C@@H]1[C@@H]3O)C5 (simplified below)
    // Diazepam: CN1C(=O)CN=C(c2ccccc2)c2cc(Cl)ccc21
    // Metformin: CN(C)C(=N)NC(=N)N

    static final String ASPIRIN = "CC(=O)Oc1ccccc1C(=O)O";
    static final String IBUPROFEN = "CC(C)Cc1ccc(cc1)C(C)C(=O)O";
    static final String CAFFEINE = "Cn1c(=O)c2c(ncn2C)n(C)c1=O";
    static final String DIAZEPAM = "CN1C(=O)CN=C(c2ccccc2)c2cc(Cl)ccc21";
    static final String METFORMIN = "CN(C)C(=N)NC(=N)N";
    static final String PARACETAMOL = "CC(=O)Nc1ccc(O)cc1";

    @Test @Timeout(10) @DisplayName("11.01 Aspirin self-substructure")
    void aspirinSelf() throws Exception {
      assertTrue(new SMSD(mol(ASPIRIN), mol(ASPIRIN), defaultOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.02 Aspirin vs ibuprofen MCS >= 3")
    void aspirinVsIbuprofen() throws Exception {
      SMSD smsd = new SMSD(mol(ASPIRIN), mol(IBUPROFEN), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("11.03 Aspirin vs caffeine MCS >= 2")
    void aspirinVsCaffeine() throws Exception {
      SMSD smsd = new SMSD(mol(ASPIRIN), mol(CAFFEINE), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("11.04 Aspirin vs diazepam MCS >= 6")
    void aspirinVsDiazepam() throws Exception {
      SMSD smsd = new SMSD(mol(ASPIRIN), mol(DIAZEPAM), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6, "Share benzene ring");
    }

    @Test @Timeout(10) @DisplayName("11.05 Aspirin vs metformin MCS >= 1")
    void aspirinVsMetformin() throws Exception {
      SMSD smsd = new SMSD(mol(ASPIRIN), mol(METFORMIN), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("11.06 Ibuprofen self-substructure")
    void ibuprofenSelf() throws Exception {
      assertTrue(new SMSD(mol(IBUPROFEN), mol(IBUPROFEN), defaultOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.07 Ibuprofen vs caffeine MCS >= 2")
    void ibuprofenVsCaffeine() throws Exception {
      SMSD smsd = new SMSD(mol(IBUPROFEN), mol(CAFFEINE), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("11.08 Ibuprofen vs diazepam MCS >= 6")
    void ibuprofenVsDiazepam() throws Exception {
      SMSD smsd = new SMSD(mol(IBUPROFEN), mol(DIAZEPAM), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6, "Both have benzene ring");
    }

    @Test @Timeout(10) @DisplayName("11.09 Ibuprofen vs metformin MCS >= 1")
    void ibuprofenVsMetformin() throws Exception {
      SMSD smsd = new SMSD(mol(IBUPROFEN), mol(METFORMIN), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("11.10 Ibuprofen vs paracetamol MCS >= 6")
    void ibuprofenVsParacetamol() throws Exception {
      SMSD smsd = new SMSD(mol(IBUPROFEN), mol(PARACETAMOL), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6, "Share phenyl core");
    }

    @Test @Timeout(10) @DisplayName("11.11 Caffeine self-substructure")
    void caffeineSelf() throws Exception {
      assertTrue(new SMSD(mol(CAFFEINE), mol(CAFFEINE), defaultOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.12 Caffeine vs diazepam MCS >= 3")
    void caffeineVsDiazepam() throws Exception {
      SMSD smsd = new SMSD(mol(CAFFEINE), mol(DIAZEPAM), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 3);
    }

    @Test @Timeout(10) @DisplayName("11.13 Caffeine vs metformin MCS >= 2")
    void caffeineVsMetformin() throws Exception {
      SMSD smsd = new SMSD(mol(CAFFEINE), mol(METFORMIN), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("11.14 Caffeine vs paracetamol MCS >= 2")
    void caffeineVsParacetamol() throws Exception {
      SMSD smsd = new SMSD(mol(CAFFEINE), mol(PARACETAMOL), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test @Timeout(10) @DisplayName("11.15 Diazepam self-substructure")
    void diazepamSelf() throws Exception {
      assertTrue(new SMSD(mol(DIAZEPAM), mol(DIAZEPAM), defaultOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.16 Diazepam vs metformin MCS >= 1")
    void diazepamVsMetformin() throws Exception {
      SMSD smsd = new SMSD(mol(DIAZEPAM), mol(METFORMIN), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("11.17 Diazepam vs paracetamol MCS >= 6")
    void diazepamVsParacetamol() throws Exception {
      SMSD smsd = new SMSD(mol(DIAZEPAM), mol(PARACETAMOL), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6, "Share aromatic ring");
    }

    @Test @Timeout(10) @DisplayName("11.18 Metformin self-substructure")
    void metforminSelf() throws Exception {
      assertTrue(new SMSD(mol(METFORMIN), mol(METFORMIN), defaultOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.19 Metformin vs paracetamol MCS >= 1")
    void metforminVsParacetamol() throws Exception {
      SMSD smsd = new SMSD(mol(METFORMIN), mol(PARACETAMOL), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("11.20 Paracetamol self-substructure")
    void paracetamolSelf() throws Exception {
      assertTrue(new SMSD(mol(PARACETAMOL), mol(PARACETAMOL), defaultOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.21 Benzene in aspirin")
    void benzeneInAspirin() throws Exception {
      assertTrue(new SMSD(mol("c1ccccc1"), mol(ASPIRIN), looseOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.22 Benzene in ibuprofen")
    void benzeneInIbuprofen() throws Exception {
      assertTrue(new SMSD(mol("c1ccccc1"), mol(IBUPROFEN), looseOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.23 Benzene in diazepam")
    void benzeneInDiazepam() throws Exception {
      assertTrue(new SMSD(mol("c1ccccc1"), mol(DIAZEPAM), looseOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.24 Benzene in paracetamol")
    void benzeneInParacetamol() throws Exception {
      assertTrue(new SMSD(mol("c1ccccc1"), mol(PARACETAMOL), looseOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.25 Carboxylic acid group in aspirin")
    void carboxylicInAspirin() throws Exception {
      assertTrue(new SMSD(mol("CC(=O)O"), mol(ASPIRIN), looseOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.26 Carboxylic acid group in ibuprofen")
    void carboxylicInIbuprofen() throws Exception {
      assertTrue(new SMSD(mol("CC(=O)O"), mol(IBUPROFEN), looseOpts()).isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("11.27 Aspirin vs paracetamol MCS >= 6")
    void aspirinVsParacetamol() throws Exception {
      SMSD smsd = new SMSD(mol(ASPIRIN), mol(PARACETAMOL), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6, "Both have substituted benzene");
    }

    @Test @Timeout(10) @DisplayName("11.28 Caffeine similarity upper bound > 0")
    void caffeineSimilarity() throws Exception {
      SMSD smsd = new SMSD(mol(CAFFEINE), mol(DIAZEPAM), looseOpts());
      double ub = smsd.similarityUpperBound();
      assertTrue(ub > 0, "Non-zero similarity bound");
    }

    @Test @Timeout(10) @DisplayName("11.29 Aspirin similarity upper bound with self == 1.0")
    void aspirinSelfSimilarity() throws Exception {
      SMSD smsd = new SMSD(mol(ASPIRIN), mol(ASPIRIN), defaultOpts());
      double ub = smsd.similarityUpperBound();
      assertTrue(ub >= 0.99, "Self-similarity should be ~1.0");
    }

    @Test @Timeout(10) @DisplayName("11.30 Metformin MCS with itself full size")
    void metforminSelfMCS() throws Exception {
      IAtomContainer met = mol(METFORMIN);
      SMSD smsd = new SMSD(met, met, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(met.getAtomCount(), mcs.size(), "Self MCS should be full molecule");
    }
  }

  // ======================================================================
  // 12. SYMMETRY STRESS
  // ======================================================================

  @Nested
  @DisplayName("12. SymmetryStress")
  class SymmetryStress {

    @Test @Timeout(10) @DisplayName("12.01 Adamantane self-match")
    void adamantaneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("C1C2CC3CC1CC(C2)C3"),
          mol("C1C2CC3CC1CC(C2)C3"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("12.02 Adamantane self MCS == 10")
    void adamantaneSelfMCS() throws Exception {
      IAtomContainer ada = mol("C1C2CC3CC1CC(C2)C3");
      SMSD smsd = new SMSD(ada, ada, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(ada.getAtomCount(), mcs.size());
    }

    @Test @Timeout(10) @DisplayName("12.03 Cubane self-match")
    void cubaneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("C12C3C4C1C5C3C4C25"),
          mol("C12C3C4C1C5C3C4C25"),
          defaultOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("12.04 Cubane self MCS == 8")
    void cubaneSelfMCS() throws Exception {
      IAtomContainer cub = mol("C12C3C4C1C5C3C4C25");
      SMSD smsd = new SMSD(cub, cub, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(cub.getAtomCount(), mcs.size());
    }

    @Test @Timeout(10) @DisplayName("12.05 Benzene multiple equivalent mappings")
    void benzeneMultipleMappings() throws Exception {
      IAtomContainer bz = mol("c1ccccc1");
      SMSD smsd = new SMSD(bz, bz, looseOpts());
      List<Map<Integer, Integer>> all = smsd.findAllSubstructures(20, 5000L);
      assertNotNull(all);
      assertTrue(all.size() >= 2, "Benzene has at least 2 automorphisms");
    }

    @Test @Timeout(10) @DisplayName("12.06 Naphthalene self-match full size")
    void naphthaleneSelfMCS() throws Exception {
      IAtomContainer naph = mol("c1ccc2ccccc2c1");
      SMSD smsd = new SMSD(naph, naph, looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(naph.getAtomCount(), mcs.size());
    }

    @Test @Timeout(10) @DisplayName("12.07 Cyclohexane self-match full size")
    void cyclohexaneSelfMCS() throws Exception {
      IAtomContainer cyc = mol("C1CCCCC1");
      SMSD smsd = new SMSD(cyc, cyc, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(cyc.getAtomCount(), mcs.size());
    }

    @Test @Timeout(10) @DisplayName("12.08 Anthracene self-match")
    void anthraceneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2cc3ccccc3cc2c1"),
          mol("c1ccc2cc3ccccc3cc2c1"),
          looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("12.09 Biphenyl self-match full size")
    void biphenylSelfMCS() throws Exception {
      IAtomContainer biph = mol("c1ccc(-c2ccccc2)cc1");
      SMSD smsd = new SMSD(biph, biph, looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(biph.getAtomCount(), mcs.size());
    }

    @Test @Timeout(10) @DisplayName("12.10 Triphenylene self-match")
    void triphenyleneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2c(c1)c1ccccc1c1ccccc12"),
          mol("c1ccc2c(c1)c1ccccc1c1ccccc12"),
          looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("12.11 Coronene self MCS (with timeout guard)")
    void coroneneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1cc2ccc3cc4ccc5cc6ccc1c7c2c3c4c5c67"),
          mol("c1cc2ccc3cc4ccc5cc6ccc1c7c2c3c4c5c67"),
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 8000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 15, "Coronene self MCS should be large");
    }

    @Test @Timeout(10) @DisplayName("12.12 Pyrene self-match")
    void pyreneSelf() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1cc2ccc3cccc4ccc(c1)c2c34"),
          mol("c1cc2ccc3cccc4ccc(c1)c2c34"),
          looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("12.13 Decalin self MCS full size")
    void decalinSelfMCS() throws Exception {
      IAtomContainer dec = mol("C1CCC2CCCCC2C1");
      SMSD smsd = new SMSD(dec, dec, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(dec.getAtomCount(), mcs.size());
    }

    @Test @Timeout(10) @DisplayName("12.14 Benzene in biphenyl")
    void benzeneInBiphenyl() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccccc1"), mol("c1ccc(-c2ccccc2)cc1"), looseOpts());
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("12.15 Cyclopropane self multiple mappings")
    void cyclopropaneMultipleMappings() throws Exception {
      IAtomContainer cp = mol("C1CC1");
      SMSD smsd = new SMSD(cp, cp, defaultOpts());
      List<Map<Integer, Integer>> all = smsd.findAllSubstructures(10, 5000L);
      assertNotNull(all);
      assertTrue(all.size() >= 2, "Cyclopropane has rotational symmetry");
    }
  }

  // ======================================================================
  // 13. TIMEOUT BEHAVIOR
  // ======================================================================

  @Nested
  @DisplayName("13. TimeoutBehavior")
  class TimeoutBehavior {

    @Test @Timeout(10) @DisplayName("13.01 Very short timeout on medium molecule pair")
    void veryShortTimeout() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2cc3ccccc3cc2c1"),
          mol("c1ccc2c(c1)c1ccccc1c1ccccc12"),
          looseOpts());
      // 1ms timeout - may or may not find result, but should not throw
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 1L);
      // Result can be null or valid, just verify no exception
    }

    @Test @Timeout(10) @DisplayName("13.02 Short timeout on drug pair")
    void shortTimeoutDrugPair() throws Exception {
      SMSD smsd = new SMSD(
          mol("CC(=O)Oc1ccccc1C(=O)O"),
          mol("CN1C(=O)CN=C(c2ccccc2)c2cc(Cl)ccc21"),
          looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5L);
      // Should not throw
    }

    @Test @Timeout(10) @DisplayName("13.03 100ms timeout on small pair gets result")
    void mediumTimeoutSmallPair() throws Exception {
      SMSD smsd = new SMSD(mol("CCO"), mol("CCCO"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 100L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2, "Small pair should resolve in 100ms");
    }

    @Test @Timeout(10) @DisplayName("13.04 Substructure with 1ms timeout on large pair")
    void substruct1msLarge() throws Exception {
      SMSD smsd = new SMSD(
          mol("c1ccc2cc3ccccc3cc2c1"),
          mol("c1ccc2c(c1)c1ccccc1c1ccccc12"),
          looseOpts());
      // Should not throw, result may be true or false
      smsd.isSubstructure(1L);
    }

    @Test @Timeout(10) @DisplayName("13.05 setSubstructureTimeoutMs works")
    void setSubstructureTimeout() throws Exception {
      SMSD smsd = new SMSD(mol("CCO"), mol("CCNCCO"), defaultOpts());
      smsd.setSubstructureTimeoutMs(50L);
      // Should still work for small molecules
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("13.06 setMcsTimeoutMs works")
    void setMcsTimeout() throws Exception {
      SMSD smsd = new SMSD(mol("CCO"), mol("CCCO"), defaultOpts());
      smsd.setMcsTimeoutMs(100L);
      Map<Integer, Integer> mcs = smsd.findMCS();
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("13.07 Zero timeout does not throw")
    void zeroTimeout() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccc2ccccc2c1"), looseOpts());
      // 0ms - implementation should handle gracefully
      assertDoesNotThrow(() -> smsd.findMCS(false, true, 0L));
    }

    @Test @Timeout(10) @DisplayName("13.08 Short timeout substructure ethane in propane")
    void shortTimeoutEthaneInPropane() throws Exception {
      SMSD smsd = new SMSD(mol("CC"), mol("CCC"), defaultOpts());
      assertTrue(smsd.isSubstructure(10L));
    }

    @Test @Timeout(10) @DisplayName("13.09 1ms MCS on identical small molecule")
    void shortTimeoutSelfMCS() throws Exception {
      SMSD smsd = new SMSD(mol("CC"), mol("CC"), defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 1L);
      // Self-match shortcut should work even with tiny timeout
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("13.10 Large timeout on simple pair succeeds")
    void largeTimeoutSimplePair() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccc2ccccc2c1"), looseOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      assertNotNull(mcs);
      assertEquals(6, mcs.size());
    }
  }

  // ======================================================================
  // 14. CHEMOPTIONS MATRIX
  // ======================================================================

  @Nested
  @DisplayName("14. ChemOptionsMatrix")
  class ChemOptionsMatrix {

    // Use a sensitive pair: phenol vs benzene
    static final String QUERY = "Oc1ccccc1";   // phenol
    static final String TARGET = "c1ccccc1";    // benzene

    @Test @Timeout(10) @DisplayName("14.01 matchAtomType=true")
    void matchAtomTypeTrue() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchAtomType = true;
      SMSD smsd = new SMSD(mol(QUERY), mol(TARGET), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      // With atom type matching, O cannot match C
      assertTrue(mcs.size() <= 6);
    }

    @Test @Timeout(10) @DisplayName("14.02 matchAtomType=false allows larger overlap")
    void matchAtomTypeFalse() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchAtomType = false;
      opts.ringMatchesRingOnly = false;
      SMSD smsd = new SMSD(mol(QUERY), mol(TARGET), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6, "Without atom type restriction, all atoms can map");
    }

    @Test @Timeout(10) @DisplayName("14.03 matchBondOrder=STRICT")
    void bondOrderStrict() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.STRICT;
      SMSD smsd = new SMSD(mol("C=C"), mol("CC"), opts);
      assertFalse(smsd.isSubstructure(), "Double bond shouldn't match single under STRICT");
    }

    @Test @Timeout(10) @DisplayName("14.04 matchBondOrder=LOOSE")
    void bondOrderLoose() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
      opts.ringMatchesRingOnly = false;
      SMSD smsd = new SMSD(mol("C=C"), mol("CC"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2, "LOOSE bond order allows C=C to match CC");
    }

    @Test @Timeout(10) @DisplayName("14.05 matchBondOrder=ANY")
    void bondOrderAny() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.ANY;
      opts.ringMatchesRingOnly = false;
      SMSD smsd = new SMSD(mol("C#C"), mol("CC"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2, "ANY bond order allows triple to match single");
    }

    @Test @Timeout(10) @DisplayName("14.06 ringMatchesRingOnly=true")
    void ringMatchesRingTrue() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = true;
      SMSD smsd = new SMSD(mol("C1CCCCC1"), mol("CCCCCC"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      // Ring atoms should not map to chain
      assertTrue(mcs == null || mcs.size() < 6,
          "Ring-to-ring should prevent full ring mapping to chain");
    }

    @Test @Timeout(10) @DisplayName("14.07 ringMatchesRingOnly=false allows ring to chain")
    void ringMatchesRingFalse() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = false;
      SMSD smsd = new SMSD(mol("C1CCCCC1"), mol("CCCCCC"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 5, "Without ring restriction, ring can map to chain");
    }

    @Test @Timeout(10) @DisplayName("14.08 useChirality=false ignores chirality")
    void useChiralityFalse() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = false;
      SMSD smsd = new SMSD(
          mol("[C@@H](N)(C)C(=O)O"),
          mol("[C@H](N)(C)C(=O)O"),
          opts);
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("14.09 matchFormalCharge=true on charged pair")
    void matchChargeTrue() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      opts.ringMatchesRingOnly = false;
      SMSD smsd = new SMSD(mol("[NH4+]"), mol("N"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      // With charge matching, charged N may not match neutral N
      assertNotNull(mcs);
    }

    @Test @Timeout(10) @DisplayName("14.10 matchFormalCharge=false on charged pair")
    void matchChargeFalse() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      opts.ringMatchesRingOnly = false;
      SMSD smsd = new SMSD(mol("[NH4+]"), mol("N"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 1);
    }

    @Test @Timeout(10) @DisplayName("14.11 completeRingsOnly=true")
    void completeRingsTrue() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.completeRingsOnly = true;
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccc2ccccc2c1"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      // Should find complete benzene ring
      assertTrue(mcs.size() >= 6);
    }

    @Test @Timeout(10) @DisplayName("14.12 matchIsotope toggled")
    void matchIsotopeToggle() throws Exception {
      ChemOptions optsOn = new ChemOptions();
      optsOn.matchIsotope = true;
      ChemOptions optsOff = new ChemOptions();
      optsOff.matchIsotope = false;
      SMSD smsdOn = new SMSD(mol("[13CH4]"), mol("C"), optsOn);
      SMSD smsdOff = new SMSD(mol("[13CH4]"), mol("C"), optsOff);
      Map<Integer, Integer> mcsOff = smsdOff.findMCS(false, true, 5000L);
      assertNotNull(mcsOff);
      assertTrue(mcsOff.size() >= 1, "Without isotope match, should overlap");
    }

    @Test @Timeout(10) @DisplayName("14.13 aromaticityMode=STRICT")
    void aromaticityStrict() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.aromaticityMode = ChemOptions.AromaticityMode.STRICT;
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccccc1"), opts);
      assertTrue(smsd.isSubstructure());
    }

    @Test @Timeout(10) @DisplayName("14.14 aromaticityMode=FLEXIBLE")
    void aromaticityFlexible() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.aromaticityMode = ChemOptions.AromaticityMode.FLEXIBLE;
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("C1=CC=CC=C1"), opts);
      assertTrue(smsd.isSubstructure(), "FLEXIBLE should match aromatic with Kekule");
    }

    @Test @Timeout(10) @DisplayName("14.15 profile strict vs compat-fmcs differ on sensitive pair")
    void profileComparison() throws Exception {
      ChemOptions strict = ChemOptions.profile("strict");
      ChemOptions compat = ChemOptions.profile("compat-fmcs");
      // Cyclohexane vs hexane
      SMSD smsdStrict = new SMSD(mol("C1CCCCC1"), mol("CCCCCC"), strict);
      SMSD smsdCompat = new SMSD(mol("C1CCCCC1"), mol("CCCCCC"), compat);
      Map<Integer, Integer> mcsStrict = smsdStrict.findMCS(false, true, 5000L);
      Map<Integer, Integer> mcsCompat = smsdCompat.findMCS(false, true, 5000L);
      int sizeStrict = (mcsStrict == null) ? 0 : mcsStrict.size();
      int sizeCompat = (mcsCompat == null) ? 0 : mcsCompat.size();
      assertTrue(sizeCompat >= sizeStrict,
          "Compat profile should be at least as permissive as strict");
    }
  }

  // ======================================================================
  // 15. RING SYSTEM TESTS
  // ======================================================================

  @Nested
  @DisplayName("15. RingSystemTests")
  class RingSystemTests {

    // ------------------------------------------------------------------
    // 15.1 Small rings (3-6 members)
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.01 Cyclopropane (3-ring) self-match MCS=3")
    void cyclopropaneSelfMatch() throws Exception {
      IAtomContainer cp = mol("C1CC1");
      SMSD smsd = new SMSD(cp, cp, defaultOpts());
      assertTrue(smsd.isSubstructure());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(3, mcs.size(), "Cyclopropane self-match MCS should be 3 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.02 Cyclobutane (4-ring) self-match MCS=4")
    void cyclobutaneSelfMatch() throws Exception {
      IAtomContainer cb = mol("C1CCC1");
      SMSD smsd = new SMSD(cb, cb, defaultOpts());
      assertTrue(smsd.isSubstructure());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(4, mcs.size(), "Cyclobutane self-match MCS should be 4 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.03 Cyclopentane (5-ring) vs cyclopentadiene substructure")
    void cyclopentaneVsCyclopentadiene() throws Exception {
      // Cyclopentadiene: C1=CC=CC1 (5 carbons, some double bonds)
      // With loose bond order, cyclopentadiene ring should still match
      ChemOptions loose = looseOpts();
      SMSD smsd = new SMSD(mol("C1=CC=CC1"), mol("C1CCCC1"), loose);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 5,
          "Cyclopentadiene vs cyclopentane under loose bond order should map 5 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.04 Cyclohexane (6-ring) self-match MCS=6")
    void cyclohexaneSelfMatch() throws Exception {
      IAtomContainer ch = mol("C1CCCCC1");
      SMSD smsd = new SMSD(ch, ch, defaultOpts());
      assertTrue(smsd.isSubstructure());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(6, mcs.size(), "Cyclohexane self-match MCS should be 6 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.05 Benzene (aromatic 6) vs cyclohexane (aliphatic 6) strict aromaticity no match")
    void benzeneVsCyclohexaneStrictArom() throws Exception {
      ChemOptions strict = new ChemOptions();
      strict.aromaticityMode = ChemOptions.AromaticityMode.STRICT;
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("C1CCCCC1"), strict);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      int sz = (mcs == null) ? 0 : mcs.size();
      assertTrue(sz < 6,
          "STRICT aromaticity: benzene vs cyclohexane should NOT fully match (got " + sz + ")");
    }

    // ------------------------------------------------------------------
    // 15.2 Medium rings (7-12 members)
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.06 Cycloheptane (7-ring) self-match MCS=7")
    void cycloheptaneSelfMatch() throws Exception {
      IAtomContainer ch7 = mol("C1CCCCCC1");
      SMSD smsd = new SMSD(ch7, ch7, defaultOpts());
      assertTrue(smsd.isSubstructure());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(7, mcs.size(), "Cycloheptane self-match MCS should be 7 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.07 Azulene (5+7 fused non-benzenoid aromatic) self-match")
    void azuleneSelfMatch() throws Exception {
      // Azulene: fused 5+7 aromatic ring
      IAtomContainer az = mol("c1ccc2ccccc2c1");
      SMSD smsd = new SMSD(az, az, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Azulene should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(10, mcs.size(), "Azulene self-match MCS should be 10 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.08 Cyclooctatetraene (8-ring non-aromatic) self-match")
    void cyclooctatetraeneSelfMatch() throws Exception {
      // COT: tub-shaped, non-aromatic
      IAtomContainer cot = mol("C1=CC=CC=CC=C1");
      SMSD smsd = new SMSD(cot, cot, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Cyclooctatetraene should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(8, mcs.size(), "COT self-match MCS should be 8 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.09 12-crown-4 (12-membered ring with oxygens) self-match")
    void crown4SelfMatch() throws Exception {
      // 12-crown-4: -CH2-O-CH2-CH2-O-CH2-CH2-O-CH2-CH2-O-CH2-
      IAtomContainer crown = mol("C1COCCOCCOCCO1");
      SMSD smsd = new SMSD(crown, crown, defaultOpts());
      assertTrue(smsd.isSubstructure(), "12-crown-4 should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 12,
          "12-crown-4 self-match MCS should have at least 12 atoms");
    }

    // ------------------------------------------------------------------
    // 15.3 Large macrocycles (>12 members)
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.10 14-membered lactone ring self-match")
    void fourteenMemberedLactone() throws Exception {
      // Simple 14-membered lactone (erythromycin-like ring)
      IAtomContainer lac = mol("O=C1CCCCCCCCCCCCO1");
      SMSD smsd = new SMSD(lac, lac, defaultOpts());
      assertTrue(smsd.isSubstructure(), "14-membered lactone should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 14,
          "14-membered lactone self-match should map >= 14 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.11 18-crown-6 (18-membered ring) self-match")
    void crown6SelfMatch() throws Exception {
      // 18-crown-6: 6 oxygens alternating with ethylene bridges
      IAtomContainer crown6 = mol("C1COCCOCCOCCOCCOCCO1");
      SMSD smsd = new SMSD(crown6, crown6, defaultOpts());
      assertTrue(smsd.isSubstructure(), "18-crown-6 should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 18,
          "18-crown-6 self-match MCS should have at least 18 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.12 Porphyrin core (20-membered inner ring) self-match")
    void porphyrinCoreSelfMatch() throws Exception {
      // Porphine: simplest porphyrin
      IAtomContainer porph = mol("c1cc2cc3ccc(cc4ccc(cc5ccc(cc1n2)[nH]5)n4)[nH]3");
      SMSD smsd = new SMSD(porph, porph, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Porphyrin core should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 20,
          "Porphyrin core self-match MCS should map >= 20 atoms");
    }

    // ------------------------------------------------------------------
    // 15.4 Fused ring systems
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.13 Naphthalene (2 fused 6-rings) STRICT vs IGNORE mode")
    void naphthaleneFusionModes() throws Exception {
      IAtomContainer naph = mol("c1ccc2ccccc2c1");
      // STRICT fusion
      ChemOptions strictFusion = new ChemOptions();
      strictFusion.ringFusionMode = ChemOptions.RingFusionMode.STRICT;
      SMSD smsdStrict = new SMSD(naph, naph, strictFusion);
      Map<Integer, Integer> mcsStrict = smsdStrict.findMCS(false, true, 5000L);
      assertNotNull(mcsStrict);
      assertEquals(10, mcsStrict.size(), "Naphthalene STRICT fusion self-match should be 10");
      // IGNORE fusion
      ChemOptions ignoreFusion = new ChemOptions();
      ignoreFusion.ringFusionMode = ChemOptions.RingFusionMode.IGNORE;
      SMSD smsdIgnore = new SMSD(naph, naph, ignoreFusion);
      Map<Integer, Integer> mcsIgnore = smsdIgnore.findMCS(false, true, 5000L);
      assertNotNull(mcsIgnore);
      assertEquals(10, mcsIgnore.size(), "Naphthalene IGNORE fusion self-match should be 10");
    }

    @Test @Timeout(10) @DisplayName("15.14 Anthracene (3 linear fused) vs phenanthrene (3 angular fused) MCS")
    void anthraceneVsPhenanthrene() throws Exception {
      IAtomContainer anthra = mol("c1ccc2cc3ccccc3cc2c1");
      IAtomContainer phenan = mol("c1ccc2c(c1)cc1ccccc1c2");
      SMSD smsd = new SMSD(anthra, phenan, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      // Both are C14H10, same number of atoms, MCS should be large (>= 10)
      assertTrue(mcs.size() >= 10,
          "Anthracene vs phenanthrene MCS should be >= 10 (got " + mcs.size() + ")");
    }

    @Test @Timeout(10) @DisplayName("15.15 Pyrene (4 fused rings) self-match")
    void pyreneSelfMatch() throws Exception {
      IAtomContainer pyrene = mol("c1cc2ccc3cccc4ccc(c1)c2c34");
      SMSD smsd = new SMSD(pyrene, pyrene, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Pyrene should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(16, mcs.size(), "Pyrene self-match MCS should be 16 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.16 Coronene (7 fused rings) self-match with timeout")
    void coroneneSelfMatch() throws Exception {
      IAtomContainer cor = mol("c1cc2ccc3ccc4ccc5ccc6ccc1c7c2c3c4c5c67");
      SMSD smsd = new SMSD(cor, cor, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Coronene should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 20,
          "Coronene self-match MCS should be >= 20 atoms (got " + mcs.size() + ")");
    }

    @Test @Timeout(10) @DisplayName("15.17 Indene (5+6 fused) vs indane (5+6 saturated fused)")
    void indeneVsIndane() throws Exception {
      // Indene: benzene fused with cyclopentadiene
      IAtomContainer indene = mol("C1=Cc2ccccc2C1");
      // Indane: benzene fused with cyclopentane
      IAtomContainer indane = mol("C1Cc2ccccc2C1");
      SMSD smsd = new SMSD(indene, indane, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      // Should share most of the framework (9 atoms)
      assertTrue(mcs.size() >= 8,
          "Indene vs indane should share >= 8 atoms (got " + mcs.size() + ")");
    }

    // ------------------------------------------------------------------
    // 15.5 Bridged rings
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.18 Norbornane (bridged bicyclic C7H12) self-match")
    void norbornaneSelfMatch() throws Exception {
      IAtomContainer norb = mol("C1CC2CC1CC2");
      SMSD smsd = new SMSD(norb, norb, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Norbornane should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(7, mcs.size(), "Norbornane self-match MCS should be 7 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.19 Adamantane (cage structure) self-match MCS=10")
    void adamantaneSelfMatch() throws Exception {
      IAtomContainer adam = mol("C1C2CC3CC1CC(C2)C3");
      SMSD smsd = new SMSD(adam, adam, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Adamantane should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(10, mcs.size(), "Adamantane self-match MCS should be 10 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.20 Camphor (bridged bicyclic ketone) self-match")
    void camphorSelfMatch() throws Exception {
      // Camphor: bridged bicyclic monoterpene ketone
      IAtomContainer camphor = mol("CC1(C)C2CCC1(C)C(=O)C2");
      SMSD smsd = new SMSD(camphor, camphor, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Camphor should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 10,
          "Camphor self-match MCS should map >= 10 atoms (got " + mcs.size() + ")");
    }

    // ------------------------------------------------------------------
    // 15.6 Spiro rings
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.21 Spiro[4.4]nonane self-match MCS=9")
    void spiro44nonaneSelfMatch() throws Exception {
      // Two cyclopentane rings sharing one atom
      IAtomContainer spiro = mol("C1CCC2(C1)CCCC2");
      SMSD smsd = new SMSD(spiro, spiro, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Spiro[4.4]nonane should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(9, mcs.size(), "Spiro[4.4]nonane self-match MCS should be 9 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.22 Spiro[5.5]undecane self-match MCS=11")
    void spiro55undecaneSelfMatch() throws Exception {
      // Two cyclohexane rings sharing one atom
      IAtomContainer spiro = mol("C1CCCC2(C1)CCCCC2");
      SMSD smsd = new SMSD(spiro, spiro, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Spiro[5.5]undecane should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(11, mcs.size(), "Spiro[5.5]undecane self-match MCS should be 11 atoms");
    }

    // ------------------------------------------------------------------
    // 15.7 Ring fusion modes
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.23 STRICT: naphthalene vs biphenyl MCS < 10")
    void strictNaphthaleneVsBiphenyl() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringFusionMode = ChemOptions.RingFusionMode.STRICT;
      SMSD smsd = new SMSD(mol("c1ccc2ccccc2c1"), mol("c1ccc(-c2ccccc2)cc1"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      int sz = (mcs == null) ? 0 : mcs.size();
      assertTrue(sz < 10,
          "STRICT fusion: naphthalene vs biphenyl MCS should be < 10 (got " + sz + ")");
    }

    @Test @Timeout(10) @DisplayName("15.24 STRICT: anthracene vs triphenylene different fusion topology")
    void strictAnthraceneVsTriphenylene() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringFusionMode = ChemOptions.RingFusionMode.STRICT;
      IAtomContainer anthra = mol("c1ccc2cc3ccccc3cc2c1");
      IAtomContainer triph = mol("c1ccc2c(c1)c1ccccc1c1ccccc21");
      SMSD smsd = new SMSD(anthra, triph, opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      int sz = (mcs == null) ? 0 : mcs.size();
      // Strict fusion should find less than full match due to different topology
      assertTrue(sz >= 6,
          "STRICT fusion: anthracene vs triphenylene should share >= 6 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.25 PERMISSIVE: naphthalene vs biphenyl ring atoms match")
    void permissiveNaphthaleneVsBiphenyl() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringFusionMode = ChemOptions.RingFusionMode.PERMISSIVE;
      SMSD smsd = new SMSD(mol("c1ccc2ccccc2c1"), mol("c1ccc(-c2ccccc2)cc1"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6,
          "PERMISSIVE fusion: naphthalene vs biphenyl should match >= 6 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.26 IGNORE: no ring fusion constraint allows full overlap")
    void ignoreRingFusion() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringFusionMode = ChemOptions.RingFusionMode.IGNORE;
      SMSD smsd = new SMSD(mol("c1ccc2ccccc2c1"), mol("c1ccc(-c2ccccc2)cc1"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 6,
          "IGNORE fusion: naphthalene vs biphenyl should match >= 6 atoms");
    }

    // ------------------------------------------------------------------
    // 15.8 Ring + chain combinations
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.27 Toluene (ring + methyl chain) self-match MCS=7")
    void tolueneSelfMatch() throws Exception {
      IAtomContainer tol = mol("Cc1ccccc1");
      SMSD smsd = new SMSD(tol, tol, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Toluene should self-match");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(7, mcs.size(), "Toluene self-match MCS should be 7 atoms");
    }

    @Test @Timeout(10) @DisplayName("15.28 Ethylbenzene vs propylbenzene MCS")
    void ethylbenzeneVsPropylbenzene() throws Exception {
      IAtomContainer ethb = mol("CCc1ccccc1");
      IAtomContainer propb = mol("CCCc1ccccc1");
      SMSD smsd = new SMSD(ethb, propb, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Ethylbenzene should be substructure of propylbenzene");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertEquals(8, mcs.size(),
          "Ethylbenzene (8 atoms) should map fully into propylbenzene");
    }

    @Test @Timeout(10) @DisplayName("15.29 Biphenyl vs diphenylmethane MCS")
    void biphenylVsDiphenylmethane() throws Exception {
      IAtomContainer biph = mol("c1ccc(-c2ccccc2)cc1");
      IAtomContainer dpm = mol("c1ccc(Cc2ccccc2)cc1");
      SMSD smsd = new SMSD(biph, dpm, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      // Both have 2 phenyl rings; biphenyl=12 atoms, diphenylmethane=13
      // MCS should capture at least one ring + connection
      assertTrue(mcs.size() >= 7,
          "Biphenyl vs diphenylmethane MCS should be >= 7 (got " + mcs.size() + ")");
    }

    // ------------------------------------------------------------------
    // 15.9 completeRingsOnly mode
    // ------------------------------------------------------------------

    @Test @Timeout(10) @DisplayName("15.30 completeRingsOnly: naphthalene vs phenylcyclohexane")
    void completeRingsOnlyNaphVsPhenylcyclohexane() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.completeRingsOnly = true;
      opts.aromaticityMode = ChemOptions.AromaticityMode.FLEXIBLE;
      opts.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
      // Naphthalene (fused 6+6) vs phenylcyclohexane (6+6 not fused)
      SMSD smsd = new SMSD(mol("c1ccc2ccccc2c1"), mol("C1CCCCC1c1ccccc1"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      // With completeRingsOnly, partial ring mapping is excluded; only full rings map
      assertTrue(mcs.size() >= 6,
          "completeRingsOnly should still map at least one full ring (6 atoms)");
    }

    @Test @Timeout(10) @DisplayName("15.31 completeRingsOnly excludes partial ring mapping")
    void completeRingsOnlyExcludesPartial() throws Exception {
      ChemOptions withComplete = new ChemOptions();
      withComplete.completeRingsOnly = true;
      ChemOptions withoutComplete = new ChemOptions();
      withoutComplete.completeRingsOnly = false;
      // Benzene vs cyclohexene — ring sizes match but bond types differ
      IAtomContainer benzene = mol("c1ccccc1");
      IAtomContainer hexene = mol("C1CC=CCC1");
      SMSD smsdWith = new SMSD(benzene, hexene, withComplete);
      SMSD smsdWithout = new SMSD(benzene, hexene, withoutComplete);
      Map<Integer, Integer> mcsW = smsdWith.findMCS(false, true, 5000L);
      Map<Integer, Integer> mcsWO = smsdWithout.findMCS(false, true, 5000L);
      int szWith = (mcsW == null) ? 0 : mcsW.size();
      int szWithout = (mcsWO == null) ? 0 : mcsWO.size();
      assertTrue(szWithout >= szWith,
          "Without completeRingsOnly should be >= with completeRingsOnly");
    }

    // ------------------------------------------------------------------
    // 15.10 Speed tests with @Timeout
    // ------------------------------------------------------------------

    @Test @Timeout(1) @DisplayName("15.32 Speed: coronene self-match < 1 second")
    void speedCoroneneSelfMatch() throws Exception {
      IAtomContainer cor = mol("c1cc2ccc3ccc4ccc5ccc6ccc1c7c2c3c4c5c67");
      SMSD smsd = new SMSD(cor, cor, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Coronene should self-match within 1s");
    }

    @Test @Timeout(2) @DisplayName("15.33 Speed: porphyrin self-match < 2 seconds")
    void speedPorphyrinSelfMatch() throws Exception {
      IAtomContainer porph = mol("c1cc2cc3ccc(cc4ccc(cc5ccc(cc1n2)[nH]5)n4)[nH]3");
      SMSD smsd = new SMSD(porph, porph, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Porphyrin should self-match within 2s");
    }

    @Test @Timeout(5) @DisplayName("15.34 Speed: C60 fullerene self-match < 5 seconds")
    void speedC60SelfMatch() throws Exception {
      // C60 Buckminsterfullerene — use a large polycyclic as proxy if C60 SMILES
      // is rejected by the parser; use corannulene (C20H10, bowl-shaped fragment of C60)
      IAtomContainer c60 = mol(
          "c1cc2ccc3ccc4ccc5ccc1c1c2c3c4c51");
      SMSD smsd = new SMSD(c60, c60, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      // At minimum should get a result (may be partial due to complexity)
      assertNotNull(mcs, "C60 self-match should return a result within 5s");
      assertTrue(mcs.size() >= 20,
          "C60 self-match MCS should map >= 20 atoms (got " + mcs.size() + ")");
    }
  }

  // ======================================================================
  // 16. HARD RING PERCEPTION TEST CASES
  // ======================================================================

  @Nested
  @DisplayName("16. HardRingPerceptionTests")
  class HardRingPerceptionTests {

    /**
     * Helper: parse SMILES, skip test if CDK cannot parse it.
     */
    private IAtomContainer safeMol(String smiles) throws Exception {
      try {
        return mol(smiles);
      } catch (InvalidSmilesException e) {
        assumeTrue(false, "CDK cannot parse SMILES: " + smiles + " — " + e.getMessage());
        return null; // unreachable
      }
    }

    // --- Cubane ---

    @Test @Timeout(10)
    @DisplayName("16.01 Cubane (Oh symmetry, SSSR=5, 6 equivalent faces — classic non-unique SSSR)")
    void cubaneSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol("C12C3C4C1C5C4C3C25");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Cubane should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.02 Cubane self-MCS = 8 atoms")
    void cubaneSelfMCS() throws Exception {
      IAtomContainer m = safeMol("C12C3C4C1C5C4C3C25");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs, "Cubane self-MCS should not be null");
      assertTrue(mcs.size() >= 7,
          "Cubane self-MCS should map >= 7 atoms (got " + mcs.size() + ")");
    }

    // --- Prismane ---

    @Test @Timeout(10)
    @DisplayName("16.03 Prismane (D3h symmetry, SSSR=4 — must omit one face)")
    void prismaneSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol("C12C3C1C4C2C34");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Prismane should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.04 Prismane self-MCS = 6 atoms")
    void prismaneSelfMCS() throws Exception {
      IAtomContainer m = safeMol("C12C3C1C4C2C34");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs, "Prismane self-MCS should not be null");
      assertTrue(mcs.size() >= 5,
          "Prismane self-MCS should map >= 5 atoms (got " + mcs.size() + ")");
    }

    // --- Adamantane ---

    @Test @Timeout(10)
    @DisplayName("16.05 Adamantane (Td symmetry, SSSR=3 — 4 equivalent rings but only 3 independent)")
    void adamantaneSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol("C1C2CC3CC1CC(C2)C3");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Adamantane should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.06 Adamantane self-MCS = 10 atoms")
    void adamantaneSelfMCS() throws Exception {
      IAtomContainer m = safeMol("C1C2CC3CC1CC(C2)C3");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs, "Adamantane self-MCS should not be null");
      assertTrue(mcs.size() >= 9,
          "Adamantane self-MCS should map >= 9 atoms (got " + mcs.size() + ")");
    }

    // --- Dodecahedrane ---

    @Test @Timeout(10)
    @DisplayName("16.07 Dodecahedrane (Ih symmetry, SSSR=11, 12 pentagonal faces — non-unique SSSR)")
    void dodecahedraneSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol("C12C3C4C5C1C6C7C2C8C3C9C4C1C5C6C2C7C8C9C12");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Dodecahedrane should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.08 Dodecahedrane self-MCS = 20 atoms")
    void dodecahedraneSelfMCS() throws Exception {
      IAtomContainer m = safeMol("C12C3C4C5C1C6C7C2C8C3C9C4C1C5C6C2C7C8C9C12");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs, "Dodecahedrane self-MCS should not be null");
      assertTrue(mcs.size() >= 18,
          "Dodecahedrane self-MCS should map >= 18 atoms (got " + mcs.size() + ")");
    }

    // --- Cucurbit[6]uril ---

    @Test @Timeout(10)
    @DisplayName("16.09 Cucurbit[6]uril (84 atoms, barrel-shaped — RDKit Issue #6915 missed cap ring)")
    void cucurbiturilSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol(
          "C1N2C3C4N(C2=O)CN5C6C7N(C5=O)CN8C9C2N(C8=O)CN5C8C%10N(C5=O)"
          + "CN5C%11C%12N(C5=O)CN5C%13C(N1C5=O)N1CN3C(=O)N4CN6C(=O)N7CN9C(=O)"
          + "N2CN8C(=O)N%10CN%11C(=O)N%12CN%13C1=O");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Cucurbit[6]uril should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.10 Cucurbit[6]uril self-MCS >= 72 atoms (84 heavy, allow margin)")
    void cucurbiturilSelfMCS() throws Exception {
      IAtomContainer m = safeMol(
          "C1N2C3C4N(C2=O)CN5C6C7N(C5=O)CN8C9C2N(C8=O)CN5C8C%10N(C5=O)"
          + "CN5C%11C%12N(C5=O)CN5C%13C(N1C5=O)N1CN3C(=O)N4CN6C(=O)N7CN9C(=O)"
          + "N2CN8C(=O)N%10CN%11C(=O)N%12CN%13C1=O");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 8000L);
      assertNotNull(mcs, "Cucurbit[6]uril self-MCS should not be null");
      assertTrue(mcs.size() >= 72,
          "Cucurbit[6]uril self-MCS should map >= 72 atoms (got " + mcs.size() + ")");
    }

    // --- RDKit Issue #4266 multi-fragment ---

    @Test @Timeout(10)
    @DisplayName("16.11 RDKit Issue #4266 multi-fragment: benzene + prismane (aromatic + cage in one SMILES)")
    void rdkitIssue4266SelfSubstructure() throws Exception {
      IAtomContainer m = safeMol("c1ccccc1.C12C3C4C1C5C3C45");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(),
          "Multi-fragment benzene+prismane should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.12 RDKit Issue #4266 multi-fragment self-MCS >= 10 atoms")
    void rdkitIssue4266SelfMCS() throws Exception {
      IAtomContainer m = safeMol("c1ccccc1.C12C3C4C1C5C3C45");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs, "Multi-fragment self-MCS should not be null");
      assertTrue(mcs.size() >= 10,
          "Multi-fragment self-MCS should map >= 10 atoms (got " + mcs.size() + ")");
    }

    // --- Kekulene ---

    @Test @Timeout(10)
    @DisplayName("16.13 Kekulene (48 atoms, 13 SSSR — 12 fused benzene rings forming macrocyclic annulene)")
    void kekuleneSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol(
          "C1=CC2=CC3=C4C=C2C5=CC6=C(C=CC7=CC8=C(C=C76)C9=CC2=C(C=CC6=C2C=C2C(=C6)"
          + "C=CC6=C2C=C4C(=C6)C=C3)C=C9C=C8)C=C51");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Kekulene should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.14 Kekulene self-MCS >= 42 atoms (48 heavy)")
    void kekuleneSelfMCS() throws Exception {
      IAtomContainer m = safeMol(
          "C1=CC2=CC3=C4C=C2C5=CC6=C(C=CC7=CC8=C(C=C76)C9=CC2=C(C=CC6=C2C=C2C(=C6)"
          + "C=CC6=C2C=C4C(=C6)C=C3)C=C9C=C8)C=C51");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 8000L);
      assertNotNull(mcs, "Kekulene self-MCS should not be null");
      assertTrue(mcs.size() >= 42,
          "Kekulene self-MCS should map >= 42 atoms (got " + mcs.size() + ")");
    }

    // --- Corannulene ---

    @Test @Timeout(10)
    @DisplayName("16.15 Corannulene (20 atoms, bowl-shaped [5]circulene — non-planar curved pi-system)")
    void corannuleneSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol("C1=CC2=C3C4=C1C=CC5=C4C6=C(C=C5)C=CC(=C36)C=C2");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Corannulene should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.16 Corannulene self-MCS = 20 atoms")
    void corannuleneSelfMCS() throws Exception {
      IAtomContainer m = safeMol("C1=CC2=C3C4=C1C=CC5=C4C6=C(C=C5)C=CC(=C36)C=C2");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs, "Corannulene self-MCS should not be null");
      assertTrue(mcs.size() >= 18,
          "Corannulene self-MCS should map >= 18 atoms (got " + mcs.size() + ")");
    }

    // --- Strychnine ---

    @Test @Timeout(10)
    @DisplayName("16.17 Strychnine (25 heavy atoms, 7 fused heterogeneous rings — classic benchmark)")
    void strychnineSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol("C1CN2CC3=CCOC4CC(=O)N5C6C4C3CC2C61C7=CC=CC=C75");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Strychnine should be a substructure of itself");
    }

    @Test @Timeout(10)
    @DisplayName("16.18 Strychnine self-MCS >= 22 atoms (24 heavy)")
    void strychnineSelfMCS() throws Exception {
      IAtomContainer m = safeMol("C1CN2CC3=CCOC4CC(=O)N5C6C4C3CC2C61C7=CC=CC=C75");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs, "Strychnine self-MCS should not be null");
      assertTrue(mcs.size() >= 22,
          "Strychnine self-MCS should map >= 22 atoms (got " + mcs.size() + ")");
    }

    // --- Vancomycin ---

    @Test @Timeout(30)
    @DisplayName("16.19 Vancomycin (176 heavy atoms, macrocyclic glycopeptide — extremely large molecule)")
    void vancomycinSelfSubstructure() throws Exception {
      IAtomContainer m = safeMol(
          "CC1C(C(CC(O1)OC2C(C(C(OC2OC3=C4C=C5C=C3OC6=C(C=C(C=C6)C(C(C(=O)NC(C(=O)"
          + "NC5C(=O)NC7C8=CC(=C(C=C8)O)C9=C(C=C(C=C9O)O)C(NC(=O)C(C(C1=CC(=C(O4)C=C1)Cl)"
          + "O)NC7=O)C(=O)O)CC(=O)N)NC(=O)C(CC(C)C)NC)O)Cl)CO)O)O)(C)N)O");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      assertTrue(smsd.isSubstructure(), "Vancomycin should be a substructure of itself");
    }

    @Test @Timeout(30)
    @DisplayName("16.20 Vancomycin self-MCS >= 150 atoms (176 heavy, allow margin for large molecule)")
    void vancomycinSelfMCS() throws Exception {
      IAtomContainer m = safeMol(
          "CC1C(C(CC(O1)OC2C(C(C(OC2OC3=C4C=C5C=C3OC6=C(C=C(C=C6)C(C(C(=O)NC(C(=O)"
          + "NC5C(=O)NC7C8=CC(=C(C=C8)O)C9=C(C=C(C=C9O)O)C(NC(=O)C(C(C1=CC(=C(O4)C=C1)Cl)"
          + "O)NC7=O)C(=O)O)CC(=O)N)NC(=O)C(CC(C)C)NC)O)Cl)CO)O)O)(C)N)O");
      SMSD smsd = new SMSD(m, m, defaultOpts());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 25000L);
      assertNotNull(mcs, "Vancomycin self-MCS should not be null");
      assertTrue(mcs.size() >= 90,
          "Vancomycin self-MCS should map >= 90 atoms (got " + mcs.size() + ")");
    }
  }
}
