/*
 * SPDX-License-Identifier: Apache-2.0
 * (c) 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;

/**
 * Tests targeting the five new SearchEngine optimizations: 1. Bit-parallel candidate domains
 * (long[] bitsets) 2. Bron-Kerbosch + RRSplit pruning for MCS 3. RASCAL similarity upper bound
 * screening 4. FASTiso-style aligned ordering with forward checking 5. Greedy probing search
 *
 * <p>Also includes performance regression tests and large molecule tests.
 *
 * @author Syed Asad Rahman
 */
public class OptimizationTest extends TestBase {

  // ======================================================================
  // 1. BIT-PARALLEL CANDIDATE DOMAINS
  // ======================================================================

  @Nested
  @DisplayName("Bit-Parallel Candidate Domains")
  class BitParallelDomainTests {

    @Test
    @DisplayName("Single atom query vs single atom target")
    void singleAtomQueryVsSingleAtomTarget() throws Exception {
      IAtomContainer query = mol("C");
      IAtomContainer target = mol("C");
      SMSD smsd = new SMSD(query, target, new ChemOptions());
      assertTrue(smsd.isSubstructure(), "Single C should match single C");
      Map<Integer, Integer> mcs = smsd.findMCS(true, true, 5000L);
      assertEquals(1, mcs.size(), "MCS of single atoms should be 1");
    }

    @Test
    @DisplayName("Single atom query vs single different atom target")
    void singleAtomMismatch() throws Exception {
      assertFalse(
          new SMSD(mol("N"), mol("C"), new ChemOptions()).isSubstructure(),
          "Nitrogen should not match carbon");
    }

    @Test
    @DisplayName("Query with >64 atoms triggers multi-word bitset (68 carbons)")
    void multiWordBitsetLongChain() throws Exception {
      // 68 carbons - requires 2 long words (>64 bits)
      String chain68 = "C".repeat(68);
      String chain70 = "C".repeat(70);
      IAtomContainer query = mol(chain68);
      IAtomContainer target = mol(chain70);
      assertEquals(68, query.getAtomCount(), "Query should have 68 atoms");
      assertTrue(target.getAtomCount() >= 70, "Target should have >= 70 atoms");

      SMSD smsd = new SMSD(query, target, new ChemOptions());
      assertTrue(
          smsd.isSubstructure(), "68-carbon chain should be substructure of 70-carbon chain");
    }

    @Test
    @DisplayName("Multi-word bitset: 65-atom query matches 65-atom self")
    void multiWordBitsetSelfMatch() throws Exception {
      String chain65 = "C".repeat(65);
      IAtomContainer m = mol(chain65);
      SMSD smsd = new SMSD(m, m, new ChemOptions());
      assertTrue(smsd.isSubstructure(), "65-carbon chain should match itself");
    }

    @Test
    @DisplayName("Bit-parallel feasibility toggle: results consistent on/off")
    void bitParallelToggleConsistency() throws Exception {
      IAtomContainer query = mol("c1ccccc1");
      IAtomContainer target = mol("c1ccc2ccccc2c1");

      ChemOptions on = new ChemOptions();
      on.useBitParallelFeasibility = true;
      ChemOptions off = new ChemOptions();
      off.useBitParallelFeasibility = false;

      boolean resultOn = new SMSD(query, target, on).isSubstructure();
      boolean resultOff = new SMSD(query, target, off).isSubstructure();
      assertEquals(resultOn, resultOff, "Bit-parallel toggle should not change correctness");
    }

    @Test
    @DisplayName("Empty molecule as query yields no substructure")
    void emptyMoleculeQuery() throws Exception {
      // CDK parseSmiles("") returns empty molecule
      IAtomContainer empty = SP.parseSmiles("");
      IAtomContainer target = mol("CCCC");
      // Empty query has 0 atoms; vacuously a substructure or handled as edge case
      SMSD smsd = new SMSD(empty, target, new ChemOptions());
      // The key test: it should NOT throw an exception
      smsd.isSubstructure();
    }

    @Test
    @DisplayName("Empty molecule as target yields no substructure for non-empty query")
    void emptyMoleculeTarget() throws Exception {
      IAtomContainer query = mol("C");
      IAtomContainer empty = SP.parseSmiles("");
      SMSD smsd = new SMSD(query, empty, new ChemOptions());
      assertFalse(smsd.isSubstructure(), "Non-empty query cannot be substructure of empty target");
    }
  }

  // ======================================================================
  // 2. BRON-KERBOSCH + RRSPLIT MCS
  // ======================================================================

  @Nested
  @DisplayName("Bron-Kerbosch + RRSplit MCS")
  class BronKerboschTests {

    @Test
    @DisplayName("Symmetric: naphthalene vs anthracene (equiv class pruning)")
    void naphthaleneVsAnthracene() throws Exception {
      // Naphthalene (10 atoms) vs anthracene (14 atoms)
      IAtomContainer naphth = mol("c1ccc2ccccc2c1");
      IAtomContainer anthra = mol("c1ccc2cc3ccccc3cc2c1");
      SMSD smsd = new SMSD(naphth, anthra, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Naphthalene is a substructure of anthracene
      assertEquals(10, mcs.size(), "Full naphthalene should map into anthracene");
    }

    @Test
    @DisplayName("Identical molecules: benzene vs benzene (MCS = full molecule)")
    void identicalBenzene() throws Exception {
      IAtomContainer b1 = mol("c1ccccc1");
      IAtomContainer b2 = mol("c1ccccc1");
      SMSD smsd = new SMSD(b1, b2, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(true, true, 5000L);
      assertEquals(6, mcs.size(), "MCS of identical benzenes should be 6 atoms");
    }

    @Test
    @DisplayName("Adamantane vs diamantane (cage structures)")
    void adamantaneVsDiamantane() throws Exception {
      // Adamantane: C1C2CC3CC1CC(C2)C3 (10 carbons)
      // Diamantane: C1C2CC3CC4CC(CC1C24)C3 (14 carbons, diamond lattice)
      IAtomContainer adam = mol("C1C2CC3CC1CC(C2)C3");
      IAtomContainer diam = mol("C1C2CC3CC4CC(CC1C24)C3");
      SMSD smsd = new SMSD(adam, diam, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 15000L);
      assertNotNull(mcs);
      assertTrue(
          mcs.size() >= 8, "Cage structures should share significant subgraph, got " + mcs.size());
    }

    @Test
    @DisplayName("Steroid scaffold pairs: estradiol vs testosterone core")
    void steroidScaffoldPair() throws Exception {
      // Gonane (steroid core): 4 fused rings
      // Use simplified steroid backbones
      String estradiol = "OC1CCC2C(C1)CCC1C2CCC2=CC(=O)CCC12";
      String testosterone = "OC1CCC2C(C1)CCC1C2CCC2=CC(=O)CCC12";
      IAtomContainer m1 = mol(estradiol);
      IAtomContainer m2 = mol(testosterone);
      SMSD smsd = new SMSD(m1, m2, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 15000L);
      // Same SMILES, so MCS should be full molecule
      assertEquals(m1.getAtomCount(), mcs.size(), "Identical steroid scaffolds should fully match");
    }

    @Test
    @DisplayName("Phenanthrene vs anthracene (isomeric polycyclics)")
    void phenanthreneVsAnthracene() throws Exception {
      IAtomContainer phen = mol("c1ccc2c(c1)ccc1ccccc12");
      IAtomContainer anthra = mol("c1ccc2cc3ccccc3cc2c1");
      SMSD smsd = new SMSD(phen, anthra, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Both are C14H10 tricyclic; MCS should share naphthalene at minimum
      assertTrue(
          mcs.size() >= 10,
          "Phenanthrene and anthracene should share at least naphthalene, got " + mcs.size());
    }

    @Test
    @DisplayName("Two ring systems with different symmetry")
    void cyclohexaneVsCyclopentane() throws Exception {
      // Both are all-carbon rings with high symmetry
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = false;
      IAtomContainer c6 = mol("C1CCCCC1");
      IAtomContainer c5 = mol("C1CCCC1");
      SMSD smsd = new SMSD(c5, c6, opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 4, "Should share at least 4 carbons in MCS");
    }
  }

  // ======================================================================
  // 3. RASCAL SIMILARITY UPPER BOUND SCREENING
  // ======================================================================

  @Nested
  @DisplayName("RASCAL Similarity Upper Bound")
  class RascalTests {

    @Test
    @DisplayName("Upper bound returns value in [0,1]")
    void upperBoundInRange() throws Exception {
      IAtomContainer m1 = mol("c1ccccc1");
      IAtomContainer m2 = mol("c1ccc(O)cc1");
      double ub = SearchEngine.similarityUpperBound(m1, m2, new ChemOptions());
      assertTrue(ub >= 0.0, "Upper bound should be >= 0, got " + ub);
      assertTrue(ub <= 1.0, "Upper bound should be <= 1, got " + ub);
    }

    @Test
    @DisplayName("Identical molecules yield upper bound = 1.0")
    void identicalMoleculesUpperBound() throws Exception {
      IAtomContainer m = mol("c1ccccc1");
      double ub = SearchEngine.similarityUpperBound(m, m, new ChemOptions());
      assertEquals(1.0, ub, 1e-9, "Identical molecules should have upper bound 1.0");
    }

    @Test
    @DisplayName("Completely different molecules yield upper bound near 0")
    void completelyDifferentUpperBound() throws Exception {
      // All nitrogen vs all carbon - no atom label overlap
      IAtomContainer allC = mol("CCCCCC");
      IAtomContainer allN = mol("[NH2][NH][NH][NH][NH2]");
      double ub = SearchEngine.similarityUpperBound(allC, allN, new ChemOptions());
      assertEquals(0.0, ub, 1e-9, "No shared atom types should give upper bound 0");
    }

    @Test
    @DisplayName("Upper bound >= actual Tanimoto from MCS")
    void upperBoundGEActualTanimoto() throws Exception {
      IAtomContainer m1 = mol("CC(=O)Oc1ccccc1C(=O)O"); // aspirin
      IAtomContainer m2 = mol("CC(=O)Nc1ccc(O)cc1"); // acetaminophen
      double ub = SearchEngine.similarityUpperBound(m1, m2, new ChemOptions());

      // Compute actual MCS Tanimoto
      SMSD smsd = new SMSD(m1, m2, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      int mcsSize = mcs.size();
      int n1 = m1.getAtomCount();
      int n2 = m2.getAtomCount();
      double actualTanimoto = (double) mcsSize / (n1 + n2 - mcsSize);

      assertTrue(
          ub >= actualTanimoto - 1e-9,
          "Upper bound (" + ub + ") should be >= actual Tanimoto (" + actualTanimoto + ")");
    }

    @Test
    @DisplayName("Upper bound is consistent between symmetric calls")
    void upperBoundSymmetric() throws Exception {
      IAtomContainer ibu = mol("CC(C)Cc1ccc(C(C)C(=O)O)cc1"); // ibuprofen
      IAtomContainer nap = mol("COc1ccc2cc(C(C)C(=O)O)ccc2c1"); // naproxen
      double ub1 = SearchEngine.similarityUpperBound(ibu, nap, new ChemOptions());
      double ub2 = SearchEngine.similarityUpperBound(nap, ibu, new ChemOptions());
      assertEquals(ub1, ub2, 1e-9, "Upper bound should be symmetric");
      assertTrue(ub1 > 0.0, "Related drugs should have positive upper bound");
      assertTrue(ub1 <= 1.0, "Upper bound should be <= 1.0");
    }

    @Test
    @DisplayName("Empty molecule gives upper bound 0")
    void emptyMoleculeUpperBound() throws Exception {
      IAtomContainer empty = SP.parseSmiles("");
      IAtomContainer benzene = mol("c1ccccc1");
      double ub = SearchEngine.similarityUpperBound(empty, benzene, new ChemOptions());
      assertEquals(0.0, ub, 1e-9, "Empty molecule should give upper bound 0");
    }

    @Test
    @DisplayName("batchMCS with threshold filters dissimilar pairs")
    void batchMCSWithThreshold() throws Exception {
      List<IAtomContainer> molecules = new ArrayList<>();
      molecules.add(mol("c1ccccc1")); // benzene (all C aromatic)
      molecules.add(mol("c1ccc(O)cc1")); // phenol  (similar to benzene)
      molecules.add(mol("[NH2][NH][NH][NH2]")); // hydrazine chain (all N, very different)

      ChemOptions chemOpts = new ChemOptions();
      SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
      mcsOpts.timeoutMillis = 10000L;

      // High threshold should filter out the dissimilar N-chain pair
      Map<Integer, Map<Integer, Integer>> results =
          SearchEngine.batchMCS(molecules, chemOpts, mcsOpts, 0.5);

      // benzene-phenol should pass the threshold; hydrazine pairs should not
      boolean hasBenzenePhenol = false;
      boolean hasHydrazinePair = false;
      int n = molecules.size();
      for (Map.Entry<Integer, Map<Integer, Integer>> e : results.entrySet()) {
        int key = e.getKey();
        int i = key / n, j = key % n;
        if ((i == 0 && j == 1) || (i == 1 && j == 0)) hasBenzenePhenol = true;
        if (i == 2 || j == 2) hasHydrazinePair = true;
      }
      assertTrue(hasBenzenePhenol, "Benzene-phenol pair should pass 0.5 threshold");
      assertFalse(hasHydrazinePair, "Hydrazine should be filtered by 0.5 threshold");
    }

    @Test
    @DisplayName("batchMCS with threshold 0 includes all pairs")
    void batchMCSZeroThreshold() throws Exception {
      List<IAtomContainer> molecules = new ArrayList<>();
      molecules.add(mol("c1ccccc1"));
      molecules.add(mol("c1ccc(O)cc1"));
      molecules.add(mol("CCCC"));

      ChemOptions chemOpts = new ChemOptions();
      SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
      mcsOpts.timeoutMillis = 10000L;

      Map<Integer, Map<Integer, Integer>> results =
          SearchEngine.batchMCS(molecules, chemOpts, mcsOpts, 0.0);

      // With threshold 0, all 3 pairs should be computed (some may be empty though)
      // At minimum benzene-phenol and benzene-butane should have non-empty MCS
      assertFalse(results.isEmpty(), "Threshold 0 should compute at least some MCS pairs");
    }
  }

  // ======================================================================
  // 4. FASTISO-STYLE ALIGNED ORDERING WITH FORWARD CHECKING
  // ======================================================================

  @Nested
  @DisplayName("FASTiso Ordering and Forward Checking")
  class FastisoTests {

    @Test
    @DisplayName("Heterogeneous drug molecule match (heteroatoms aid ordering)")
    void heterogeneousDrugMatch() throws Exception {
      // Aspirin has O, N absent; acetaminophen has N, O -- distinct labels help FASTiso
      IAtomContainer aspirin = mol("CC(=O)Oc1ccccc1C(=O)O");
      IAtomContainer phenol = mol("Oc1ccccc1");
      assertTrue(
          new SMSD(phenol, aspirin, new ChemOptions()).isSubstructure(),
          "Phenol should be substructure of aspirin");
    }

    @Test
    @DisplayName("Caffeine contains purine (multiple heteroatoms)")
    void caffeinePurine() throws Exception {
      IAtomContainer purine = mol("c1ncnc2[nH]cnc12");
      IAtomContainer caffeine = mol("Cn1c(=O)c2c(ncn2C)n(C)c1=O");
      assertTrue(
          new SMSD(purine, caffeine, ChemOptions.profile("compat-substruct")).isSubstructure(),
          "Purine should be found in caffeine");
    }

    @Test
    @DisplayName("Homogeneous all-carbon chain match (no heteroatom guidance)")
    void homogeneousChainMatch() throws Exception {
      // All-carbon chains: ordering must rely on degree/topology alone
      IAtomContainer c10 = mol("CCCCCCCCCC");
      IAtomContainer c15 = mol("CCCCCCCCCCCCCCC");
      assertTrue(
          new SMSD(c10, c15, new ChemOptions()).isSubstructure(),
          "C10 chain should be substructure of C15 chain");
    }

    @Test
    @DisplayName("Branched carbon skeleton match")
    void branchedCarbonSkeleton() throws Exception {
      // Neopentane (branched) in larger branched skeleton
      IAtomContainer neopentane = mol("CC(C)(C)C");
      IAtomContainer target = mol("CC(C)(C)CC(C)(C)C");
      assertTrue(
          new SMSD(neopentane, target, new ChemOptions()).isSubstructure(),
          "Neopentane should be substructure of di-tert-butyl");
    }

    // Removed: forwardCheckingMixedHeteroatoms — duplicated by
    // SMSDComprehensiveTest.HeterocycleTests.morpholineInDrug (same SMILES pair).

    @Test
    @DisplayName("All NLF pruning modes give consistent results")
    void nlfPruningConsistency() throws Exception {
      IAtomContainer query = mol("c1ccncc1"); // pyridine
      IAtomContainer target = mol("c1ccnc(N)c1"); // 2-aminopyridine

      // All combinations of 2-hop and 3-hop NLF pruning
      boolean[][] configs = {{true, true}, {true, false}, {false, true}, {false, false}};
      Boolean first = null;

      for (boolean[] cfg : configs) {
        ChemOptions opts = new ChemOptions();
        opts.useTwoHopNLF = cfg[0];
        opts.useThreeHopNLF = cfg[1];
        boolean result = new SMSD(query, target, opts).isSubstructure();
        if (first == null) first = result;
        else
          assertEquals(
              first,
              result,
              "NLF pruning config [2hop="
                  + cfg[0]
                  + ",3hop="
                  + cfg[1]
                  + "] should give same result");
      }
    }
  }

  // ======================================================================
  // 5. GREEDY PROBING SEARCH
  // ======================================================================

  @Nested
  @DisplayName("Greedy Probing Search")
  class GreedyProbingTests {

    @Test
    @DisplayName("Easy case: distinctive atom labels (greedy should succeed)")
    void easyDistinctiveLabels() throws Exception {
      // Unique heteroatom pattern makes greedy probing likely to succeed
      IAtomContainer query = mol("c1ccnc(Cl)c1"); // 2-chloropyridine
      IAtomContainer target = mol("c1cc(Br)nc(Cl)c1"); // 2-chloro-4-bromopyridine
      assertTrue(
          new SMSD(query, target, new ChemOptions()).isSubstructure(),
          "Distinctive labels should allow greedy match");
    }

    @Test
    @DisplayName("Easy case: functional group anchor")
    void easyFunctionalGroupAnchor() throws Exception {
      // Nitro group provides strong anchor for greedy search
      IAtomContainer query = mol("[N+](=O)[O-]");
      IAtomContainer target = mol("c1ccc([N+](=O)[O-])cc1");
      assertTrue(
          new SMSD(query, target, new ChemOptions()).isSubstructure(),
          "Nitro group with distinctive labels should match greedily");
    }

    @Test
    @DisplayName("Hard case: symmetric all-carbon needs backtracking")
    void hardSymmetricAllCarbon() throws Exception {
      // Two all-carbon rings: high symmetry forces backtracking
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = false;
      IAtomContainer query = mol("C1CCCC1"); // cyclopentane
      IAtomContainer target = mol("C1CCCCC1CCCC"); // cyclohexane + chain
      SMSD smsd = new SMSD(query, target, opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 5, "Should find cyclopentane in target via backtracking");
    }

    @Test
    @DisplayName("Hard case: all same element graph requires exhaustive search")
    void hardAllSameElement() throws Exception {
      // Large all-carbon molecule pair: greedy may fail, full search needed
      IAtomContainer query = mol("C1CC1C1CC1"); // spiro bis-cyclopropane
      IAtomContainer target = mol("C1CC1C1CC1C"); // with extra C
      SMSD smsd = new SMSD(query, target, new ChemOptions());
      assertTrue(
          smsd.isSubstructure(), "Spiro bis-cyclopropane should be substructure with backtracking");
    }

    @Test
    @DisplayName("Mixed easy/hard: partial greedy then backtrack")
    void mixedEasyHard() throws Exception {
      // Unique nitrogen anchors one end, symmetric carbons on the other
      IAtomContainer query = mol("NCCCCCC");
      IAtomContainer target = mol("NCCCCCCCCCC");
      assertTrue(
          new SMSD(query, target, new ChemOptions()).isSubstructure(),
          "N-anchor helps greedy, carbon chain requires extension");
    }
  }

  // ======================================================================
  // 6. PERFORMANCE REGRESSION TESTS
  // ======================================================================

  @Nested
  @DisplayName("Performance Regression")
  class PerformanceTests {

    @Test
    @DisplayName("Benzene in naphthalene completes < 50ms")
    void benzeneInNaphthaleneFast() throws Exception {
      IAtomContainer query = mol("c1ccccc1");
      IAtomContainer target = mol("c1ccc2ccccc2c1");

      // Warm up
      for (int i = 0; i < 50; i++) {
        new SMSD(query, target, new ChemOptions()).isSubstructure();
      }

      long start = System.nanoTime();
      boolean result = new SMSD(query, target, new ChemOptions()).isSubstructure();
      long elapsed = (System.nanoTime() - start) / 1_000_000L;

      assertTrue(result, "Benzene should be substructure of naphthalene");
      assertTrue(elapsed < 50, "Should complete in < 50ms, took " + elapsed + "ms");
    }

    @Test
    @DisplayName("Aspirin vs acetaminophen MCS completes < 500ms")
    void aspirinAcetaminophenMCSFast() throws Exception {
      IAtomContainer aspirin = mol("CC(=O)Oc1ccccc1C(=O)O");
      IAtomContainer acetaminophen = mol("CC(=O)Nc1ccc(O)cc1");

      // Warm up
      for (int i = 0; i < 20; i++) {
        new SMSD(aspirin, acetaminophen, new ChemOptions()).findMCS(true, true, 5000L);
      }

      long start = System.nanoTime();
      Map<Integer, Integer> mcs =
          new SMSD(aspirin, acetaminophen, new ChemOptions()).findMCS(true, true, 5000L);
      long elapsed = (System.nanoTime() - start) / 1_000_000L;

      assertFalse(mcs.isEmpty(), "MCS should not be empty");
      assertTrue(elapsed < 500, "MCS should complete in < 500ms, took " + elapsed + "ms");
    }

    @Test
    @DisplayName("Morphine vs codeine MCS completes < 200ms")
    void morphineCodeineMCSFast() throws Exception {
      IAtomContainer morphine = mol("CN1CCC23C4C1CC5=C(C2C(C=C4)O3)C=C(C=C5)O");
      IAtomContainer codeine = mol("CN1CCC23C4C1CC5=C(C2C(C=C4)OC3)C=C(C=C5)O");

      // Warm up
      for (int i = 0; i < 20; i++) {
        new SMSD(morphine, codeine, new ChemOptions()).findMCS(false, true, 5000L);
      }

      long start = System.nanoTime();
      Map<Integer, Integer> mcs =
          new SMSD(morphine, codeine, new ChemOptions()).findMCS(false, true, 5000L);
      long elapsed = (System.nanoTime() - start) / 1_000_000L;

      assertTrue(
          mcs.size() >= 15, "Morphine-codeine MCS should share most atoms, got " + mcs.size());
      assertTrue(elapsed < 200, "MCS should complete in < 200ms, took " + elapsed + "ms");
    }
  }

  // ======================================================================
  // 7. LARGE MOLECULE TESTS (MACRO)
  // ======================================================================

  @Nested
  @DisplayName("Large Molecule Tests")
  class LargeMoleculeTests {

    @Test
    @DisplayName("Chain of 100 carbons as substructure of chain of 150")
    void longChainSubstructure() throws Exception {
      IAtomContainer c100 = mol("C".repeat(100));
      IAtomContainer c150 = mol("C".repeat(150));
      assertEquals(100, c100.getAtomCount());
      assertEquals(150, c150.getAtomCount());

      SMSD smsd = new SMSD(c100, c150, new ChemOptions());
      assertTrue(smsd.isSubstructure(30000L), "C100 should be substructure of C150");
    }

    @Test
    @DisplayName("Large polycyclic aromatic MCS: anthracene vs pyrene")
    void largePolycyclicAromaticMCS() throws Exception {
      // Anthracene (14 atoms) and pyrene (16 atoms) -- both polycyclic aromatics
      IAtomContainer anthracene = mol("c1ccc2cc3ccccc3cc2c1");
      IAtomContainer pyrene = mol("c1cc2ccc3cccc4ccc(c1)c2c34");
      assertTrue(anthracene.getAtomCount() >= 14, "Anthracene should have >= 14 atoms");
      assertTrue(pyrene.getAtomCount() >= 16, "Pyrene should have >= 16 atoms");

      // They should share a significant MCS (at least naphthalene-sized)
      SMSD smsd = new SMSD(anthracene, pyrene, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 15000L);
      assertTrue(
          mcs.size() >= 10,
          "Anthracene and pyrene should share at least naphthalene unit, got " + mcs.size());
    }

    @Test
    @DisplayName("Multi-word domain: branched 70-atom molecule")
    void largeBranchedMolecule() throws Exception {
      // Create a branched molecule with >64 atoms
      // Long chain with branches: main chain of 50 + branches totaling >14
      String smiles = "C".repeat(50) + "(CCCCCCCCCC)" + "CCCCCCCCCC";
      IAtomContainer branched = mol(smiles);
      assertTrue(
          branched.getAtomCount() >= 65,
          "Branched molecule should have >64 atoms for multi-word test");

      // A shorter subchain should match
      IAtomContainer sub = mol("C".repeat(30));
      SMSD smsd = new SMSD(sub, branched, new ChemOptions());
      assertTrue(
          smsd.isSubstructure(15000L),
          "C30 chain should be substructure of large branched molecule");
    }

    @Test
    @DisplayName("MCS of two medium polycyclic aromatics")
    void mediumPolycyclicMCS() throws Exception {
      // Pyrene (16 atoms) vs triphenylene (18 atoms)
      IAtomContainer pyrene = mol("c1cc2ccc3cccc4ccc(c1)c2c34");
      IAtomContainer triphenylene = mol("c1ccc2c(c1)c1ccccc1c1ccccc21");
      SMSD smsd = new SMSD(pyrene, triphenylene, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 15000L);
      assertTrue(
          mcs.size() >= 10,
          "Pyrene and triphenylene should share at least naphthalene unit, got " + mcs.size());
    }
  }

  // ======================================================================
  // 8. MATCHER ENGINE CONSISTENCY ACROSS OPTIMIZATIONS
  // ======================================================================

  @Nested
  @DisplayName("Matcher Engine Consistency")
  class MatcherEngineConsistencyTests {

    @Test
    @DisplayName("VF2, VF2PP, VF3 all agree on benzene substructure")
    void allEnginesAgreeBenzene() throws Exception {
      IAtomContainer query = mol("c1ccccc1");
      IAtomContainer target = mol("c1ccc2ccccc2c1");

      for (ChemOptions.MatcherEngine engine : ChemOptions.MatcherEngine.values()) {
        ChemOptions opts = new ChemOptions();
        opts.matcherEngine = engine;
        boolean result = new SMSD(query, target, opts).isSubstructure();
        assertTrue(result, "Engine " + engine + " should find benzene in naphthalene");
      }
    }

    @Test
    @DisplayName("VF2, VF2PP, VF3 all agree on negative case")
    void allEnginesAgreeNegative() throws Exception {
      IAtomContainer query = mol("c1ccncc1"); // pyridine (has N)
      IAtomContainer target = mol("c1ccccc1"); // benzene (no N)

      for (ChemOptions.MatcherEngine engine : ChemOptions.MatcherEngine.values()) {
        ChemOptions opts = new ChemOptions();
        opts.matcherEngine = engine;
        boolean result = new SMSD(query, target, opts).isSubstructure();
        assertFalse(result, "Engine " + engine + " should not find pyridine in benzene");
      }
    }
  }

  // ======================================================================
  // 9. AMINO ACIDS & PEPTIDES
  // ======================================================================

  @Nested
  @DisplayName("Amino Acids & Peptides")
  class AminoAcidTests {

    @Test
    @DisplayName("Glycine backbone is substructure of alanine")
    void glycineSubstructureOfAlanine() throws Exception {
      // Glycine: NCC(=O)O, Alanine: NC(C)C(=O)O
      IAtomContainer glycine = mol("NCC(=O)O");
      IAtomContainer alanine = mol("NC(C)C(=O)O");
      ChemOptions opts = ChemOptions.profile("compat-substruct");
      assertTrue(
          new SMSD(glycine, alanine, opts).isSubstructure(),
          "Glycine backbone (NCC(=O)O) should be substructure of alanine");
    }

    @Test
    @DisplayName("Phenylalanine contains benzene ring")
    void phenylalanineContainsBenzene() throws Exception {
      IAtomContainer benzene = mol("c1ccccc1");
      // Phenylalanine: NC(Cc1ccccc1)C(=O)O
      IAtomContainer phe = mol("NC(Cc1ccccc1)C(=O)O");
      assertTrue(
          new SMSD(benzene, phe, new ChemOptions()).isSubstructure(),
          "Phenylalanine should contain a benzene ring");
    }

    @Test
    @DisplayName("Two amino acids share backbone MCS (N-C-C(=O)-O)")
    void twoAminoAcidsSharedBackbone() throws Exception {
      // Valine and leucine both have the amino acid backbone
      IAtomContainer valine = mol("NC(C(C)C)C(=O)O");
      IAtomContainer leucine = mol("NC(CC(C)C)C(=O)O");
      SMSD smsd = new SMSD(valine, leucine, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Shared backbone N-C-C(=O)-O = at least 5 heavy atoms
      assertTrue(
          mcs.size() >= 5,
          "Valine and leucine should share at least the amino acid backbone, got " + mcs.size());
    }
  }

  // ======================================================================
  // 10. NUCLEOTIDES & BASES
  // ======================================================================

  @Nested
  @DisplayName("Nucleotides & Bases")
  class NucleotideTests {

    @Test
    @DisplayName("Adenine (purine) substructure search in adenosine")
    void adenineInAdenosine() throws Exception {
      // Adenine: c1ncnc2[nH]cnc12
      IAtomContainer adenine = mol("c1ncnc2[nH]cnc12");
      // Adenosine: adenine + ribose
      IAtomContainer adenosine = mol("c1ncnc2c1ncn2C1OC(CO)C(O)C1O");
      assertTrue(
          new SMSD(adenine, adenosine, ChemOptions.profile("compat-substruct")).isSubstructure(),
          "Adenine should be a substructure of adenosine");
    }

    @Test
    @DisplayName("Purine vs pyrimidine MCS (shared atoms)")
    void purineVsPyrimidineMCS() throws Exception {
      // Purine: fused 6+5 ring, Pyrimidine: single 6-membered ring
      IAtomContainer purine = mol("c1ncnc2[nH]cnc12");
      IAtomContainer pyrimidine = mol("c1ccnc(N)n1"); // cytosine-like pyrimidine
      SMSD smsd = new SMSD(pyrimidine, purine, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Should share some ring atoms (pyrimidine ring is part of purine)
      assertTrue(
          mcs.size() >= 4,
          "Purine and pyrimidine should share at least 4 atoms, got " + mcs.size());
    }

    @Test
    @DisplayName("Cytosine vs uracil MCS")
    void cytosineVsUracilMCS() throws Exception {
      // Cytosine: O=C1N=C(N)C=CN1, Uracil: O=C1NC(=O)C=CN1
      IAtomContainer cytosine = mol("O=C1N=C(N)C=CN1");
      IAtomContainer uracil = mol("O=C1NC(=O)C=CN1");
      SMSD smsd = new SMSD(cytosine, uracil, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Both are pyrimidine derivatives, should share the ring core
      assertTrue(
          mcs.size() >= 5, "Cytosine and uracil should share pyrimidine core, got " + mcs.size());
    }
  }

  // ======================================================================
  // 11. SUGARS & CARBOHYDRATES
  // ======================================================================

  @Nested
  @DisplayName("Sugars & Carbohydrates")
  class SugarTests {

    @Test
    @DisplayName("Glucose vs fructose MCS (same formula, different structure)")
    void glucoseVsFructoseMCS() throws Exception {
      // D-glucose (pyranose): OCC1OC(O)C(O)C(O)C1O
      // D-fructose (furanose): OCC(O)C1OC(O)(CO)C1O
      IAtomContainer glucose = mol("OCC1OC(O)C(O)C(O)C1O");
      IAtomContainer fructose = mol("OCC(O)C1OC(O)(CO)C1O");
      SMSD smsd = new SMSD(glucose, fructose, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Both C6H12O6, should share significant fragment
      assertTrue(
          mcs.size() >= 6, "Glucose and fructose should share significant MCS, got " + mcs.size());
    }

    @Test
    @DisplayName("Ribose substructure in nucleoside-like molecule")
    void riboseSubstructureCheck() throws Exception {
      // Ribose (furanose): OC1C(O)C(O)C(CO)O1
      IAtomContainer ribose = mol("OC1C(O)C(O)C(CO)O1");
      // Adenosine contains ribose
      IAtomContainer adenosine = mol("c1ncnc2c1ncn2C1OC(CO)C(O)C1O");
      ChemOptions opts = ChemOptions.profile("compat-substruct");
      SMSD smsd = new SMSD(ribose, adenosine, opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Should find ribose or significant part of it
      assertTrue(
          mcs.size() >= 5,
          "Ribose should substantially overlap with adenosine sugar moiety, got " + mcs.size());
    }
  }

  // ======================================================================
  // 12. FORMAL CHARGES
  // ======================================================================

  @Nested
  @DisplayName("Formal Charge Matching")
  class FormalChargeTests {

    @Test
    @DisplayName("Carboxylate anion matches with matchFormalCharge=false")
    void carboxylateAnionLooseCharge() throws Exception {
      // Carboxylate anion: [O-]C(=O) vs neutral carboxylic acid: OC(=O)
      IAtomContainer anion = mol("[O-]C=O");
      IAtomContainer acid = mol("OC(=O)CC");
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      // With charge matching off, [O-] should match O
      assertTrue(
          new SMSD(anion, acid, opts).isSubstructure(),
          "Carboxylate anion should match acid when matchFormalCharge=false");
    }

    @Test
    @DisplayName("Carboxylate anion does NOT match neutral with matchFormalCharge=true")
    void carboxylateAnionStrictCharge() throws Exception {
      IAtomContainer anion = mol("[O-]C=O");
      IAtomContainer acid = mol("OC(=O)CC");
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      assertFalse(
          new SMSD(anion, acid, opts).isSubstructure(),
          "Carboxylate anion should NOT match neutral acid when matchFormalCharge=true");
    }

    @Test
    @DisplayName("Ammonium cation matches with matchFormalCharge=false")
    void ammoniumCationLooseCharge() throws Exception {
      IAtomContainer ammonium = mol("[NH4+]");
      IAtomContainer amine = mol("NCC");
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      // With charge matching off, [NH4+] nitrogen should match N
      assertTrue(
          new SMSD(ammonium, amine, opts).isSubstructure(),
          "Ammonium should match amine when matchFormalCharge=false");
    }
  }

  // ======================================================================
  // 13. TAUTOMER-LIKE PAIRS
  // ======================================================================

  @Nested
  @DisplayName("Tautomer-like Pairs")
  class TautomerTests {

    @Test
    @DisplayName("Keto and enol forms share substructure")
    void ketoEnolSharedSubstructure() throws Exception {
      // Acetone (keto): CC(=O)C
      // Propen-2-ol (enol): CC(=C)O
      IAtomContainer keto = mol("CC(=O)C");
      IAtomContainer enol = mol("CC(=C)O");
      SMSD smsd = new SMSD(keto, enol, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Should share at least C-C-C or C-C=X backbone
      assertTrue(
          mcs.size() >= 2, "Keto and enol should share at least 2 atoms in MCS, got " + mcs.size());
    }

    @Test
    @DisplayName("Amide and imidic acid share substructure")
    void amideImidiicAcidMCS() throws Exception {
      // Acetamide: CC(=O)N
      // Acetimidic acid: CC(=N)O
      IAtomContainer amide = mol("CC(=O)N");
      IAtomContainer imidic = mol("CC(=N)O");
      SMSD smsd = new SMSD(amide, imidic, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Should share at least C-C backbone
      assertTrue(
          mcs.size() >= 2, "Amide and imidic acid should share atoms in MCS, got " + mcs.size());
    }
  }

  // ======================================================================
  // 14. MULTI-RING FUSED SYSTEMS
  // ======================================================================

  @Nested
  @DisplayName("Multi-ring Fused Systems")
  class FusedRingTests {

    @Test
    @DisplayName("Fluorene vs carbazole MCS")
    void fluoreneVsCarbazole() throws Exception {
      // Fluorene: c1ccc2c(c1)Cc1ccccc1-2  (two benzene + CH2 bridge)
      // Carbazole: c1ccc2c(c1)[nH]c1ccccc12 (two benzene + NH bridge)
      IAtomContainer fluorene = mol("c1ccc2c(c1)Cc1ccccc1-2");
      IAtomContainer carbazole = mol("c1ccc2c(c1)[nH]c1ccccc12");
      SMSD smsd = new SMSD(fluorene, carbazole, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 15000L);
      // Both have biphenyl-like framework, should share most atoms
      assertTrue(
          mcs.size() >= 10,
          "Fluorene and carbazole should share significant ring system, got " + mcs.size());
    }

    @Test
    @DisplayName("Indole vs benzofuran MCS")
    void indoleVsBenzofuran() throws Exception {
      // Indole: c1ccc2[nH]ccc2c1
      // Benzofuran: c1ccc2occc2c1
      IAtomContainer indole = mol("c1ccc2[nH]ccc2c1");
      IAtomContainer benzofuran = mol("c1ccc2occc2c1");
      SMSD smsd = new SMSD(indole, benzofuran, ChemOptions.profile("compat-substruct"));
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Both are benzene fused with 5-membered hetero ring, should share benzene + shared carbons
      assertTrue(
          mcs.size() >= 6,
          "Indole and benzofuran should share benzene ring + fused atoms, got " + mcs.size());
    }

    @Test
    @DisplayName("Quinoline vs isoquinoline MCS")
    void quinolineVsIsoquinoline() throws Exception {
      // Quinoline: c1ccc2ncccc2c1
      // Isoquinoline: c1ccc2cnccc2c1
      IAtomContainer quinoline = mol("c1ccc2ncccc2c1");
      IAtomContainer isoquinoline = mol("c1ccc2cnccc2c1");
      SMSD smsd = new SMSD(quinoline, isoquinoline, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      // Both are naphthalene with one N, same atoms, should share most of the structure
      assertTrue(
          mcs.size() >= 8,
          "Quinoline and isoquinoline should share most of the bicyclic system, got " + mcs.size());
    }
  }

  // ======================================================================
  // 15. STEREOCHEMISTRY EDGE CASES
  // ======================================================================

  @Nested
  @DisplayName("Stereochemistry Edge Cases")
  class StereochemistryTests {

    @Test
    @DisplayName("E vs Z stilbene with useBondStereo=false (should match)")
    void eZStilbeneBondStereoOff() throws Exception {
      // E-stilbene: /C=C\ vs Z-stilbene: /C=C/
      IAtomContainer eStilbene = mol("C(=C/c1ccccc1)\\c1ccccc1");
      IAtomContainer zStilbene = mol("C(=C\\c1ccccc1)\\c1ccccc1");
      ChemOptions opts = new ChemOptions();
      opts.useBondStereo = false;
      assertTrue(
          new SMSD(eStilbene, zStilbene, opts).isSubstructure(),
          "E and Z stilbene should match when useBondStereo=false");
    }

    @Test
    @DisplayName("R vs S alanine with useChirality=false (should match)")
    void rsAlanineChiralityOff() throws Exception {
      IAtomContainer rAla = mol("N[C@H](C)C(=O)O");
      IAtomContainer sAla = mol("N[C@@H](C)C(=O)O");
      ChemOptions opts = new ChemOptions();
      opts.useChirality = false;
      assertTrue(
          new SMSD(rAla, sAla, opts).isSubstructure(),
          "R and S alanine should match when useChirality=false");
    }

    @Test
    @DisplayName("R vs S alanine with useChirality=true (should NOT match)")
    void rsAlanineChiralityOn() throws Exception {
      IAtomContainer rAla = mol("N[C@H](C)C(=O)O");
      IAtomContainer sAla = mol("N[C@@H](C)C(=O)O");
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      assertFalse(
          new SMSD(rAla, sAla, opts).isSubstructure(),
          "R and S alanine should NOT match when useChirality=true");
    }
  }

  // ======================================================================
  // 16. TIMEOUT & EDGE CASES
  // ======================================================================

  @Nested
  @DisplayName("Timeout & Edge Cases")
  class TimeoutEdgeCaseTests {

    @Test
    @DisplayName("Very low timeout stops search without exception")
    void veryLowTimeoutStopsSearch() throws Exception {
      // Large molecules to make the search non-trivial
      IAtomContainer query = mol("c1ccc2cc3ccccc3cc2c1"); // anthracene
      IAtomContainer target = mol("c1cc2ccc3cccc4ccc(c1)c2c34"); // pyrene
      // 1ms timeout - should not throw, just return a result (possibly incomplete)
      SMSD smsd = new SMSD(query, target, new ChemOptions());
      assertDoesNotThrow(
          () -> smsd.isSubstructure(1L), "Very low timeout should not throw an exception");
    }

    @Test
    @DisplayName("Query larger than target returns false for substructure")
    void queryLargerThanTarget() throws Exception {
      IAtomContainer large = mol("c1ccc2cc3ccccc3cc2c1"); // anthracene (14 atoms)
      IAtomContainer small = mol("c1ccccc1"); // benzene (6 atoms)
      assertFalse(
          new SMSD(large, small, new ChemOptions()).isSubstructure(),
          "Larger query cannot be substructure of smaller target");
    }

    @Test
    @DisplayName("Target == query (exact match) is a valid substructure")
    void exactSelfMatch() throws Exception {
      IAtomContainer mol = mol("CC(=O)Oc1ccccc1C(=O)O"); // aspirin
      SMSD smsd = new SMSD(mol, mol, new ChemOptions());
      assertTrue(smsd.isSubstructure(), "A molecule should be a substructure of itself");
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertEquals(
          mol.getAtomCount(), mcs.size(), "MCS of self should equal the full molecule atom count");
    }
  }

  // ======================================================================
  // 17. ALL ChemOptions PROFILES
  // ======================================================================

  @Nested
  @DisplayName("ChemOptions Profiles")
  class ProfileTests {

    @Test
    @DisplayName("profile('strict') enforces strict bond order and aromaticity")
    void strictProfile() throws Exception {
      ChemOptions strict = ChemOptions.profile("strict");
      assertEquals(
          ChemOptions.BondOrderMode.STRICT,
          strict.matchBondOrder,
          "Strict profile should have STRICT bond order mode");
      assertEquals(
          ChemOptions.AromaticityMode.STRICT,
          strict.aromaticityMode,
          "Strict profile should have STRICT aromaticity mode");

      // Benzene substructure of naphthalene with strict profile should still work
      IAtomContainer benzene = mol("c1ccccc1");
      IAtomContainer naphthalene = mol("c1ccc2ccccc2c1");
      assertTrue(
          new SMSD(benzene, naphthalene, strict).isSubstructure(),
          "Strict profile should still find aromatic benzene in aromatic naphthalene");
    }

    @Test
    @DisplayName("profile('compat-substruct') uses loose bond order and flexible aromaticity")
    void compatSubstructProfile() throws Exception {
      ChemOptions compat = ChemOptions.profile("compat-substruct");
      assertEquals(
          ChemOptions.BondOrderMode.LOOSE,
          compat.matchBondOrder,
          "Compat profile should have LOOSE bond order mode");
      assertEquals(
          ChemOptions.AromaticityMode.FLEXIBLE,
          compat.aromaticityMode,
          "Compat profile should have FLEXIBLE aromaticity mode");
      assertFalse(compat.ringMatchesRingOnly, "Compat profile should disable ringMatchesRingOnly");
    }

    @Test
    @DisplayName("Strict profile may reject match that compat-substruct accepts")
    void strictVsCompatDifference() throws Exception {
      // Cyclohexane (non-aromatic ring) substructure of benzene (aromatic ring)
      // Strict aromaticity should reject; compat might accept
      IAtomContainer cyclohexane = mol("C1CCCCC1");
      IAtomContainer benzene = mol("c1ccccc1");
      ChemOptions strict = ChemOptions.profile("strict");
      ChemOptions compat = ChemOptions.profile("compat-substruct");
      boolean strictResult = new SMSD(cyclohexane, benzene, strict).isSubstructure();
      // Strict should NOT match non-aromatic ring vs aromatic ring
      assertFalse(
          strictResult,
          "Strict profile should not match cyclohexane in benzene (aromatic mismatch)");
    }
  }

  // ======================================================================
  // 18. RASCAL BATCH EDGE CASES
  // ======================================================================

  @Nested
  @DisplayName("RASCAL Batch Edge Cases")
  class RascalBatchEdgeCaseTests {

    @Test
    @DisplayName("batchMCS with empty list returns empty results")
    void batchMCSEmptyList() throws Exception {
      List<IAtomContainer> empty = new ArrayList<>();
      ChemOptions chemOpts = new ChemOptions();
      SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
      mcsOpts.timeoutMillis = 5000L;
      Map<Integer, Map<Integer, Integer>> results =
          SearchEngine.batchMCS(empty, chemOpts, mcsOpts, 0.0);
      assertTrue(results.isEmpty(), "batchMCS on empty list should return empty map");
    }

    @Test
    @DisplayName("batchMCS with single molecule returns empty (no pairs)")
    void batchMCSSingleMolecule() throws Exception {
      List<IAtomContainer> single = new ArrayList<>();
      single.add(mol("c1ccccc1"));
      ChemOptions chemOpts = new ChemOptions();
      SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
      mcsOpts.timeoutMillis = 5000L;
      Map<Integer, Map<Integer, Integer>> results =
          SearchEngine.batchMCS(single, chemOpts, mcsOpts, 0.0);
      assertTrue(results.isEmpty(), "batchMCS with single molecule should return empty (no pairs)");
    }

    @Test
    @DisplayName("batchMCS with threshold=1.0 only matches identical pairs")
    void batchMCSThresholdOne() throws Exception {
      List<IAtomContainer> mols = new ArrayList<>();
      mols.add(mol("c1ccccc1")); // benzene
      mols.add(mol("c1ccccc1")); // benzene again
      mols.add(mol("c1ccc(O)cc1")); // phenol (different)
      ChemOptions chemOpts = new ChemOptions();
      SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
      mcsOpts.timeoutMillis = 5000L;
      Map<Integer, Map<Integer, Integer>> results =
          SearchEngine.batchMCS(mols, chemOpts, mcsOpts, 1.0);
      // Only the identical benzene-benzene pair (indices 0,1) should pass threshold=1.0
      int n = mols.size();
      boolean hasIdenticalPair = results.containsKey(0 * n + 1);
      boolean hasPhenolPair01 = results.containsKey(0 * n + 2);
      boolean hasPhenolPair12 = results.containsKey(1 * n + 2);
      assertTrue(hasIdenticalPair, "Identical benzene pair should pass threshold=1.0");
      assertFalse(hasPhenolPair01, "Benzene-phenol pair should NOT pass threshold=1.0");
      assertFalse(hasPhenolPair12, "Benzene-phenol pair should NOT pass threshold=1.0");
    }
  }

  // ---------------------------------------------------------------
  // 11. Advanced Stereochemistry Tests
  // ---------------------------------------------------------------
  @Nested
  @DisplayName("Advanced Stereochemistry Tests")
  class AdvancedStereoTests {

    @Test
    @DisplayName("Mixed aromatic/non-aromatic ring: indane contains benzene")
    void indaneContainsBenzene() throws Exception {
      IAtomContainer indane = mol("C1CC2=CC=CC=C2C1");
      IAtomContainer benzene = mol("c1ccccc1");
      ChemOptions opts = new ChemOptions();
      SMSD smsd = new SMSD(benzene, indane, opts);
      assertTrue(smsd.isSubstructure(), "Benzene should be substructure of indane");
    }

    @Test
    @DisplayName("Fused heteroaromatic MCS: benzimidazole vs benzoxazole")
    void benzimidazoleVsBenzoxazole() throws Exception {
      IAtomContainer bim = mol("c1ccc2[nH]cnc2c1");
      IAtomContainer box = mol("c1ccc2ocnc2c1");
      SMSD smsd = new SMSD(bim, box, new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000);
      assertTrue(
          mcs.size() >= 7,
          "Benzimidazole/benzoxazole MCS should share ≥7 atoms, got " + mcs.size());
    }

    @Test
    @DisplayName("Biphenyl contains benzene")
    void biphenylContainsBenzene() throws Exception {
      IAtomContainer biphenyl = mol("c1ccc(-c2ccccc2)cc1");
      IAtomContainer benzene = mol("c1ccccc1");
      SMSD smsd = new SMSD(benzene, biphenyl, new ChemOptions());
      assertTrue(smsd.isSubstructure(), "Benzene should be substructure of biphenyl");
    }

    // Removed: chiralityInsensitive — duplicated by StereochemistryTests.rsAlanineChiralityOff
    // above.
    // Removed: quinolineIsoquinolineMcs — duplicated by FusedRingTests.quinolineVsIsoquinoline
    // above.
  }
}
