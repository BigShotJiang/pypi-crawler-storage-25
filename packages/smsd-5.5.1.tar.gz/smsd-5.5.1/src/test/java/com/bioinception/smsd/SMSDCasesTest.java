/*
 * SPDX-License-Identifier: Apache-2.0
 * © 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.ChemOptions;
import com.bioinception.smsd.core.SMSD;
import com.bioinception.smsd.core.Standardiser;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.openscience.cdk.interfaces.IAtomContainer;

/**
 * A comprehensive test suite for the SMSD library, with tests grouped by functionality. Each test
 * is self-contained and follows a consistent "Parse -> Standardise -> Test" pattern.
 */
public class SMSDCasesTest extends TestBase {

  // Alias for local use (original code used instance field 'sp')
  private final org.openscience.cdk.smiles.SmilesParser sp = SP;

  @Nested
  @DisplayName("Core Substructure Tests")
  class SubstructureTests {

    @Test
    @DisplayName("should find a simple alkane substructure")
    void findSimpleAlkane() throws Exception {
      IAtomContainer q = sp.parseSmiles("CCC"); // Propane
      IAtomContainer t = sp.parseSmiles("CCCCCC"); // Hexane
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should not find a longer chain in a shorter one")
    void notFindLongerChain() throws Exception {
      IAtomContainer q = sp.parseSmiles("CCCCCCCC"); // Octane
      IAtomContainer t = sp.parseSmiles("CCCCCC"); // Hexane
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertFalse(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should find a heterocycle substructure")
    void findHeterocycle() throws Exception {
      IAtomContainer q = sp.parseSmiles("c1ncccc1"); // Pyridine
      IAtomContainer t = sp.parseSmiles("Clc1ncccc1"); // 2-Chloropyridine
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should match formal charges when required")
    void matchFormalCharge() throws Exception {
      IAtomContainer q = sp.parseSmiles("[O-]C=O"); // Carboxylate
      IAtomContainer t = sp.parseSmiles("CC(=O)[O-]"); // Acetate
      ChemOptions options = ChemOptions.profile("compat-substruct");
      options.matchFormalCharge = true;
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              options);
      assertTrue(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should ignore formal charges when not required")
    void ignoreFormalCharge() throws Exception {
      IAtomContainer q = sp.parseSmiles("OC=O"); // Carboxylic acid
      IAtomContainer t = sp.parseSmiles("CC(=O)[O-]"); // Acetate
      ChemOptions options = ChemOptions.profile("compat-substruct");
      options.matchFormalCharge = false;
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              options);
      assertTrue(smsd.isSubstructure());
    }
  }

  @Nested
  @DisplayName("Advanced SMARTS Feature Tests")
  class SmartsFeatureTests {

    @Test
    @DisplayName("should handle recursive SMARTS for carboxyl carbon")
    void recursiveSmartsCarboxyl() throws Exception {

      String qSmarts = "[C;$(C(=O)O)]";
      IAtomContainer t = sp.parseSmiles("CC(=O)O");
      SMSD smsd =
          new SMSD(
              qSmarts,
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should handle recursive SMARTS for amide nitrogen")
    void recursiveSmartsAmide() throws Exception {

      String qSmarts = "[N;$(NC=O)]";
      IAtomContainer t = sp.parseSmiles("CC(=O)NCC");
      SMSD smsd =
          new SMSD(
              qSmarts,
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should match disconnected query fragments in a target")
    void disconnectedFragments() throws Exception {
      IAtomContainer q = sp.parseSmiles("C.C");
      IAtomContainer t = sp.parseSmiles("CCC");
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure());
    }
  }

  @Nested
  @DisplayName("Stereo and Aromaticity Tests")
  class StereoAndAromaticityTests {

    @Test
    @DisplayName("should match identical stereoisomers when stereo is ignored")
    void stereoMatch() throws Exception {
      IAtomContainer q = sp.parseSmiles("C/C=C\\C");
      IAtomContainer t = sp.parseSmiles("C/C=C\\C");
      ChemOptions options = ChemOptions.profile("strict");
      options.useBondStereo = false; // Disabling stereo check to allow topological pass
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              options);
      assertTrue(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should not match different stereoisomers with strict settings")
    void stereoMismatch() throws Exception {
      IAtomContainer q = sp.parseSmiles("C/C=C\\C");
      IAtomContainer t = sp.parseSmiles("C/C=C/C");
      ChemOptions options = ChemOptions.profile("strict");
      options.useBondStereo = true;
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              options);
      assertFalse(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should match aromatic and Kekule forms with flexible settings")
    void aromaticFlexibleMatch() throws Exception {
      IAtomContainer q = sp.parseSmiles("c1ccccc1");
      IAtomContainer t = sp.parseSmiles("C1=CC=CC=C1");
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure());
    }

    @Test
    @DisplayName("should not match aromatic and non-aromatic rings with strict settings")
    void aromaticStrictMismatch() throws Exception {
      IAtomContainer q = sp.parseSmiles("c1ccccc1");
      IAtomContainer t = sp.parseSmiles("C1CCCCC1"); // Cyclohexane
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(q, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(t, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("strict"));
      assertFalse(smsd.isSubstructure());
    }
  }

  @Nested
  @DisplayName("Maximum Common Substructure (MCS) Tests")
  class McsTests {

    @Test
    @DisplayName("should find benzene as the MCS of benzene and naphthalene")
    void mcsBenzeneNaphthalene() throws Exception {
      IAtomContainer a = sp.parseSmiles("c1ccccc1");
      IAtomContainer b = sp.parseSmiles("c1ccc2ccccc2c1");
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(a, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(b, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-fmcs"));
      Map<Integer, Integer> m = smsd.findMCS(true, true, 2500L);
      assertNotNull(m);
      assertEquals(6, m.size());
    }

    @Test
    @DisplayName("should find a common core between two different structures")
    void mcsCommonCore() throws Exception {
      IAtomContainer a = sp.parseSmiles("CC(C)c1ccc(C(=O)O)cc1"); // Ibuprofen core
      IAtomContainer b = sp.parseSmiles("CC(C(=O)O)c1ccc2ccccc2c1"); // Naproxen core
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(a, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(b, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-fmcs"));
      Map<Integer, Integer> m = smsd.findMCS(true, true, 2500L);
      assertNotNull(m);
      assertTrue(m.size() >= 4);
    }
  }

  @Nested
  @DisplayName("Drug and Real-World Molecule Tests")
  class DrugMoleculeTests {

    @Test
    @DisplayName("should find the salicylic acid core in Aspirin")
    void testSalicylicAcidInAspirin() throws Exception {
      IAtomContainer query = sp.parseSmiles("c1(C(=O)O)ccccc1O"); // Salicylic acid
      IAtomContainer target = sp.parseSmiles("CC(=O)Oc1ccccc1C(=O)O"); // Aspirin
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(query, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(target, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure(), "Salicylic acid is a substructure of Aspirin");
    }

    @Test
    @DisplayName("should find the catechol pharmacophore in Dopamine")
    void testCatecholInDopamine() throws Exception {
      IAtomContainer query = sp.parseSmiles("c1ccc(O)c(O)c1"); // Catechol
      IAtomContainer target = sp.parseSmiles("C1=CC(=C(C=C1CCN)O)O"); // Dopamine
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(query, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(target, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertTrue(smsd.isSubstructure(), "Catechol is a substructure of Dopamine");
    }

    @Test
    @DisplayName("should confirm a complex fragment is not present")
    void testIndoleNotInAspirin() throws Exception {
      IAtomContainer query = sp.parseSmiles("c1ccc2[nH]ccc2c1"); // Indole
      IAtomContainer target = sp.parseSmiles("CC(=O)Oc1ccccc1C(=O)O"); // Aspirin
      SMSD smsd =
          new SMSD(
              Standardiser.standardise(query, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(target, Standardiser.TautomerMode.NONE),
              ChemOptions.profile("compat-substruct"));
      assertFalse(smsd.isSubstructure(), "Indole is not a substructure of Aspirin");
    }

    @Test
    @DisplayName("should find a large MCS between Morphine and Codeine")
    void testMcsMorphineVsCodeine() throws Exception {
      // Morphine (21 atoms) and Codeine (22 atoms) differ at the ether bridge:
      // Morphine has a direct C-O bridge; Codeine has C-O-CH3.
      // Induced MCS = 19 (bridge topology mismatch), non-induced = 20.
      IAtomContainer morphine = sp.parseSmiles("CN1CCC23C4C1CC5=C(C2C(C=C4)O3)C=C(C=C5)O");
      IAtomContainer codeine = sp.parseSmiles("CN1CCC23C4C1CC5=C(C2C(C=C4)OC3)C=C(C=C5)O");

      SMSD smsd =
          new SMSD(
              Standardiser.standardise(morphine, Standardiser.TautomerMode.NONE),
              Standardiser.standardise(codeine, Standardiser.TautomerMode.NONE),
              new ChemOptions());

      Map<Integer, Integer> mcsInduced = smsd.findMCS(true, true, 30000L);
      assertNotNull(mcsInduced);
      assertTrue(
          mcsInduced.size() >= 19,
          "Induced MCS of Morphine/Codeine should be >= 19 (got " + mcsInduced.size() + ")");

      Map<Integer, Integer> mcsNonInduced = smsd.findMCS(false, true, 30000L);
      assertNotNull(mcsNonInduced);
      assertEquals(
          20,
          mcsNonInduced.size(),
          "Non-induced MCS of Morphine/Codeine should be 20 (all shared atoms except bridge"
              + " methyl)");
    }
  }
}
