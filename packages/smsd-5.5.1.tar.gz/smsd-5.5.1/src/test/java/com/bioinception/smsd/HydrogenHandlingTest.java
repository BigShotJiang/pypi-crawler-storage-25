/*
 * SPDX-License-Identifier: Apache-2.0
 * (c) 2025-2026 BioInception PVT LTD.
 *
 * Tests for implicit / explicit hydrogen handling in SMSD.
 *
 * Key invariants
 * --------------
 * 1. Implicit-H SMILES and bracket-H SMILES should give the same heavy-atom MCS.
 * 2. Explicit [H] atoms (written as graph nodes) are real atoms — a query with
 *    explicit [H] must match a target that also has them, not an implicit-H target.
 * 3. After standardisation, [CH4], C, and [C@@H] all normalise to the same
 *    heavy-atom representation (methane).
 * 4. Ring and charge aromaticity are unaffected by H-count normalisation.
 *
 * @author Syed Asad Rahman
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.*;
import java.util.Map;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;

@TestMethodOrder(MethodOrderer.DisplayName.class)
public class HydrogenHandlingTest extends TestBase {

    private static final ChemOptions OPTS = new ChemOptions();

    // -----------------------------------------------------------------------
    // 1. Implicit H normalisation
    // -----------------------------------------------------------------------

    @Nested
    @DisplayName("1. Implicit H normalisation")
    class ImplicitH {

        @Test @Timeout(10) @DisplayName("1.01 methane implicit vs bracket — same heavy atom count")
        void methaneImplicitVsBracket() throws Exception {
            IAtomContainer implicit = mol("C");
            IAtomContainer bracket  = mol("[CH4]");
            // Both normalise to a single carbon
            SMSD a = new SMSD(implicit, bracket, OPTS);
            assertTrue(a.isSubstructure(), "[CH4] should match implicit C");
            SMSD b = new SMSD(bracket, implicit, OPTS);
            assertTrue(b.isSubstructure(), "implicit C should match [CH4]");
        }

        @Test @Timeout(10) @DisplayName("1.02 benzene implicit vs bracketed aromatic H — same MCS")
        void benzeneImplicitVsBracketed() throws Exception {
            IAtomContainer implicit  = mol("c1ccccc1");
            IAtomContainer bracketed = mol("[cH]1[cH][cH][cH][cH][cH]1");
            Map<Integer, Integer> mcs = new SMSD(implicit, bracketed, OPTS).findMCS();
            assertEquals(6, mcs.size(), "MCS should span all 6 carbons regardless of H notation");
        }

        @Test @Timeout(10) @DisplayName("1.03 ethanol implicit vs explicit H-count — heavy-atom MCS = 3")
        void ethanolImplicitVsExplicitCount() throws Exception {
            IAtomContainer a = mol("CCO");
            IAtomContainer b = mol("[CH3][CH2][OH]");
            Map<Integer, Integer> mcs = new SMSD(a, b, OPTS).findMCS();
            assertEquals(3, mcs.size());
        }

        @Test @Timeout(10) @DisplayName("1.04 aspirin heavy-atom count unaffected by H notation")
        void aspirinHeavyAtomCount() throws Exception {
            IAtomContainer implicit = mol("CC(=O)Oc1ccccc1C(=O)O");
            IAtomContainer explicit = mol("[CH3]C(=O)Oc1ccccc1C(=O)O");
            Map<Integer, Integer> mcs = new SMSD(implicit, explicit, OPTS).findMCS();
            assertEquals(13, mcs.size(), "MCS must cover all 13 heavy atoms");
        }
    }

    // -----------------------------------------------------------------------
    // 2. Explicit [H] graph nodes
    // -----------------------------------------------------------------------

    @Nested
    @DisplayName("2. Explicit [H] as graph nodes")
    class ExplicitHNodes {

        @Test @Timeout(10) @DisplayName("2.01 [H][H] hydrogen molecule — 2-atom self match")
        void hydrogenMolecule() throws Exception {
            IAtomContainer h2 = mol("[H][H]");
            SMSD smsd = new SMSD(h2, h2, OPTS);
            assertTrue(smsd.isSubstructure(), "H2 should match itself");
        }

        @Test @Timeout(10) @DisplayName("2.02 explicit [H] query does NOT match implicit-H target")
        void explicitHQueryVsImplicitTarget() throws Exception {
            // query: methane with one explicit H node => 2 atoms (C + H)
            IAtomContainer withH    = mol("[H]C([H])([H])[H]");  // 5-atom graph
            IAtomContainer withoutH = mol("C");                   // 1-atom graph
            // The 5-atom explicit-H graph cannot be substructure of a 1-atom graph
            SMSD smsd = new SMSD(withH, withoutH, OPTS);
            assertFalse(smsd.isSubstructure(),
                "Explicit-H methane (5 atoms) cannot be substructure of implicit-H methane (1 atom)");
        }

        @Test @Timeout(10) @DisplayName("2.03 MCS of explicit-H vs implicit-H strips to heavy-atom overlap")
        void mcsExplicitVsImplicit() throws Exception {
            // Explicit [H] on water vs implicit water
            IAtomContainer water_explicit = mol("[H]O[H]");  // 3 atoms: H, O, H
            IAtomContainer water_implicit = mol("O");         // 1 atom: O
            Map<Integer, Integer> mcs = new SMSD(water_explicit, water_implicit, OPTS).findMCS();
            // MCS is the oxygen atom only (size 1)
            assertEquals(1, mcs.size(), "MCS across explicit/implicit water is the O atom");
        }
    }

    // -----------------------------------------------------------------------
    // 3. H-count in substructure matching
    // -----------------------------------------------------------------------

    @Nested
    @DisplayName("3. H-count in substructure matching")
    class HCountSubstructure {

        @Test @Timeout(10) @DisplayName("3.01 primary amine NH2 matches in aniline")
        void nh2InAniline() throws Exception {
            IAtomContainer nh2     = mol("N");       // ammonia (3 implicit H)
            IAtomContainer aniline = mol("Nc1ccccc1");
            // NH2 (primary amine in aniline) should match NH3 pattern in LOOSE mode
            ChemOptions loose = new ChemOptions();
            loose.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
            SMSD smsd = new SMSD(nh2, aniline, loose);
            assertTrue(smsd.isSubstructure(), "N (ammonia-like) should match aniline N in LOOSE mode");
        }

        @Test @Timeout(10) @DisplayName("3.02 secondary amine does not match primary-amine query in strict mode")
        void primaryVsSecondaryAmine() throws Exception {
            IAtomContainer primary   = mol("CN");    // methylamine — N has 2 implicit H
            IAtomContainer secondary = mol("CNC");   // dimethylamine — N has 1 implicit H
            // In strict mode the H-count on N differs; primary should NOT substructure secondary
            // (CDK standardisation keeps implicit H counts)
            SMSD smsd = new SMSD(primary, secondary, OPTS);
            // The C-N subgraph matches but strict atom-type (H-count) may differ
            Map<Integer, Integer> mcs = smsd.findMCS();
            // MCS is at least C-N (2 atoms)
            assertTrue(mcs.size() >= 2, "C-N fragment should still map in MCS");
        }

        @Test @Timeout(10) @DisplayName("3.03 water implicit vs [OH2] explicit — substructure both ways")
        void waterSymmetry() throws Exception {
            IAtomContainer implicit = mol("O");
            IAtomContainer explicit = mol("[OH2]");
            assertTrue(new SMSD(implicit, explicit, OPTS).isSubstructure());
            assertTrue(new SMSD(explicit, implicit, OPTS).isSubstructure());
        }

        @Test @Timeout(10) @DisplayName("3.04 charged species NH4+ has same heavy atom as NH3")
        void ammoniumVsAmmonia() throws Exception {
            IAtomContainer nh3  = mol("N");
            IAtomContainer nh4p = mol("[NH4+]");
            // Both have one nitrogen; the charge differs but the MCS is a single N
            ChemOptions noCharge = new ChemOptions();
            noCharge.matchFormalCharge = false;
            Map<Integer, Integer> mcs = new SMSD(nh3, nh4p, noCharge).findMCS();
            assertEquals(1, mcs.size(), "MCS of NH3 and NH4+ is a single N when charge ignored");
        }
    }

    // -----------------------------------------------------------------------
    // 4. Drug-like molecules — H normalisation must not shrink MCS
    // -----------------------------------------------------------------------

    @Nested
    @DisplayName("4. Drug-like H normalisation")
    class DrugLike {

        @Test @Timeout(30) @DisplayName("4.01 morphine implicit vs bracketed-CH — same MCS size")
        void morphineHNormalisation() throws Exception {
            IAtomContainer std = mol("CN1CCC23C4C1CC5=C(C2C(C=C4)O3)C=C(C=C5)O");
            IAtomContainer brk = mol("C[N]1CC[C@@]23[C@@H]4[C@H]1C[C@@H]5=C([C@@H]2[C@H](C=C4)O3)C=C(C=C5)O");
            Map<Integer, Integer> mcs = new SMSD(std, brk, OPTS).findMCS();
            assertTrue(mcs.size() >= 17,
                "Morphine MCS across H-notation variants must be ≥17 heavy atoms, got " + mcs.size());
        }

        @Test @Timeout(30) @DisplayName("4.02 caffeine vs theophylline unaffected by [NH] vs N notation")
        void caffeineTheophylline() throws Exception {
            IAtomContainer caff  = mol("Cn1cnc2c1c(=O)n(C)c(=O)n2C");
            IAtomContainer theo  = mol("Cn1cnc2c1c(=O)[nH]c(=O)n2C");  // [nH] explicit H on N
            Map<Integer, Integer> mcs = new SMSD(caff, theo, OPTS).findMCS();
            assertTrue(mcs.size() >= 11,
                "Caffeine/theophylline MCS should be ≥11 regardless of [nH] notation, got " + mcs.size());
        }

        @Test @Timeout(10) @DisplayName("4.03 ibuprofen heavy-atom self-match both notations")
        void ibuprofenSelfMatch() throws Exception {
            IAtomContainer a = mol("CC(C)Cc1ccc(CC(C)C(=O)O)cc1");
            IAtomContainer b = mol("[CH3][C@@H]([CH3])Cc1ccc(CC(C)C(=O)O)cc1");
            Map<Integer, Integer> mcs = new SMSD(a, b, OPTS).findMCS();
            // a has 13 heavy atoms; b is the same core so MCS ≥ 12
            assertTrue(mcs.size() >= 12,
                "Ibuprofen MCS across H/stereo notations must be ≥12, got " + mcs.size());
        }
    }

    // -----------------------------------------------------------------------
    // 5. Symmetric molecules — H not breaking symmetry detection
    // -----------------------------------------------------------------------

    @Nested
    @DisplayName("5. Symmetric molecules")
    class Symmetric {

        @Test @Timeout(10) @DisplayName("5.01 benzene: all H implicit — full 6-atom MCS")
        void benzeneImplicit() throws Exception {
            IAtomContainer a = mol("c1ccccc1");
            IAtomContainer b = mol("c1ccccc1");
            Map<Integer, Integer> mcs = new SMSD(a, b, OPTS).findMCS();
            assertEquals(6, mcs.size());
        }

        @Test @Timeout(10) @DisplayName("5.02 cyclohexane implicit vs [CH2] notation — 6-atom MCS")
        void cyclohexaneHNotation() throws Exception {
            IAtomContainer a = mol("C1CCCCC1");
            IAtomContainer b = mol("[CH2]1[CH2][CH2][CH2][CH2][CH2]1");
            Map<Integer, Integer> mcs = new SMSD(a, b, OPTS).findMCS();
            assertEquals(6, mcs.size());
        }
    }
}
