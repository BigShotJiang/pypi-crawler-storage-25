/*
 * SPDX-License-Identifier: Apache-2.0
 * (c) 2025-2026 BioInception PVT LTD.
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.MolGraph;
import java.util.*;
import org.junit.jupiter.api.*;

/**
 * Tests for the Unique Ring Families (URF) ring finder.
 * Validates computeRelevantCycles() and computeURFs() against known
 * molecular ring topologies.
 *
 * @author Syed Asad Rahman
 */
@TestMethodOrder(MethodOrderer.DisplayName.class)
public class RingFinderTest extends TestBase {

  private static MolGraph graph(String smi) throws Exception {
    return new MolGraph(mol(smi));
  }

  private static void assertValidCycles(MolGraph g, int[][] cycles) {
    for (int[] c : cycles) {
      assertTrue(c.length >= 3, "Cycle must have at least 3 atoms");
      for (int i = 0; i < c.length; i++) {
        int a = c[i], b = c[(i + 1) % c.length];
        assertTrue(g.hasBond(a, b),
            "Atoms " + a + " and " + b + " should be bonded in cycle");
      }
    }
  }

  private static Set<Integer> cycleLengths(int[][] cycles) {
    Set<Integer> lengths = new HashSet<>();
    for (int[] c : cycles) lengths.add(c.length);
    return lengths;
  }

  @Test
  @DisplayName("Benzene: MCB=1, relevant=1, URFs=1")
  void testBenzene() throws Exception {
    MolGraph g = graph("c1ccccc1");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(1, mcb.length, "Benzene MCB should have 1 ring");
    assertEquals(1, relevant.length, "Benzene should have 1 relevant cycle");
    assertEquals(1, urfs.length, "Benzene should have 1 URF");
    assertEquals(6, relevant[0].length, "The relevant cycle should be 6-membered");
    assertValidCycles(g, relevant);
  }

  @Test
  @DisplayName("Cyclohexane: MCB=1, relevant=1, URFs=1")
  void testCyclohexane() throws Exception {
    MolGraph g = graph("C1CCCCC1");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(1, mcb.length);
    assertEquals(1, relevant.length);
    assertEquals(1, urfs.length);
    assertValidCycles(g, relevant);
  }

  @Test
  @DisplayName("Biphenyl: MCB=2, relevant=2, URFs=2 (each phenyl is its own URF family)")
  void testBiphenyl() throws Exception {
    MolGraph g = graph("c1ccc(-c2ccccc2)cc1");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(2, mcb.length);
    assertEquals(2, relevant.length);
    // The single bond connecting the rings is not a ring bond, so the two phenyl
    // rings cannot be interconverted by single-edge-exchange within the RCB.
    assertEquals(2, urfs.length, "Biphenyl: two independent phenyl URF families");
    assertValidCycles(g, relevant);
  }

  @Test
  @DisplayName("Naphthalene: MCB=2, relevant=2, URFs=2 (fused rings — each is its own URF)")
  void testNaphthalene() throws Exception {
    MolGraph g = graph("c1ccc2ccccc2c1");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(2, mcb.length);
    assertEquals(2, relevant.length);
    // The shared bond (ring fusion) means neither ring can be exchanged into the
    // other by a single-edge-exchange within the RCB → two URF families (Kolodzik 2012).
    assertEquals(2, urfs.length, "Naphthalene: two URF families (fused 6-rings, exchange blocked)");
    assertValidCycles(g, relevant);

    Set<Integer> lengths = cycleLengths(relevant);
    assertTrue(lengths.contains(6), "Should contain 6-membered rings");
    assertFalse(lengths.contains(10), "10-ring is XOR of two 6-rings — not relevant");
  }

  @Test
  @DisplayName("Cubane: MCB=5, relevant=6, URFs=1")
  void testCubane() throws Exception {
    // CORRECT Cubane SMILES (not the Cuneane typo C12C3C4C1C5C3C4C25)
    MolGraph g = graph("C12C3C4C1C5C4C3C25");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(5, mcb.length, "Cubane MCB should have 5 rings");
    assertEquals(6, relevant.length, "Cubane should have 6 relevant cycles (all 6 faces)");
    assertEquals(1, urfs.length, "Cubane should have 1 URF (all 6 faces equivalent)");
    assertValidCycles(g, relevant);

    for (int[] c : relevant) {
      assertEquals(4, c.length, "All cubane relevant cycles should be 4-membered");
    }
  }

  @Test
  @DisplayName("Norbornane: MCB=2, relevant=2")
  void testNorbornane() throws Exception {
    MolGraph g = graph("C1CC2CC1CC2");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();

    assertEquals(2, mcb.length, "Norbornane MCB should have 2 rings");
    // The outer 6-ring = XOR of two 5-rings → mathematically NOT relevant
    assertEquals(2, relevant.length, "Norbornane should have exactly 2 relevant cycles");
    assertValidCycles(g, relevant);
  }

  @Test
  @DisplayName("Adamantane: MCB=3, relevant=4")
  void testAdamantane() throws Exception {
    MolGraph g = graph("C1C2CC3CC1CC(C2)C3");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();

    assertEquals(3, mcb.length);
    assertEquals(4, relevant.length, "Adamantane should have 4 relevant cycles");
    assertValidCycles(g, relevant);

    for (int[] c : relevant) {
      assertEquals(6, c.length, "All adamantane relevant cycles should be 6-membered");
    }
  }

  @Test
  @DisplayName("Butane: no rings")
  void testButane() throws Exception {
    MolGraph g = graph("CCCC");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(0, mcb.length);
    assertEquals(0, relevant.length);
    assertEquals(0, urfs.length);
  }

  @Test
  @DisplayName("Cyclopropane: MCB=1, relevant=1, URFs=1")
  void testCyclopropane() throws Exception {
    MolGraph g = graph("C1CC1");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(1, mcb.length);
    assertEquals(1, relevant.length);
    assertEquals(1, urfs.length);
    assertEquals(3, relevant[0].length);
    assertValidCycles(g, relevant);
  }

  @Test
  @DisplayName("Spiro[4.4]nonane: MCB=2, relevant=2, URFs=2 (each 5-ring is its own URF)")
  void testSpiro() throws Exception {
    MolGraph g = graph("C1CCC2(C1)CCCC2");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();
    int[][][] urfs = g.computeURFs();

    assertEquals(2, mcb.length);
    assertEquals(2, relevant.length);
    // The spiro atom is shared but no ring bond is shared, so no single-edge-exchange
    // can move atoms between the two rings → two distinct URF families (Kolodzik 2012).
    assertEquals(2, urfs.length, "Spiro: two URF families (rings share only a spiro atom)");
    assertValidCycles(g, relevant);
  }

  @Test
  @DisplayName("Anthracene: MCB=3, relevant >= 3")
  void testAnthracene() throws Exception {
    MolGraph g = graph("c1ccc2cc3ccccc3cc2c1");
    int[][] mcb = g.computeRings();
    int[][] relevant = g.computeRelevantCycles();

    assertEquals(3, mcb.length);
    assertTrue(relevant.length >= 3, "Anthracene should have at least 3 relevant cycles");
    assertValidCycles(g, relevant);
  }

  @Test
  @DisplayName("Relevant cycles are deterministic")
  void testDeterministic() throws Exception {
    MolGraph g1 = graph("c1ccc2ccccc2c1");
    MolGraph g2 = graph("c1ccc2ccccc2c1");
    int[][] r1 = g1.computeRelevantCycles();
    int[][] r2 = g2.computeRelevantCycles();

    assertEquals(r1.length, r2.length, "Same molecule should give same number of relevant cycles");
  }
}
