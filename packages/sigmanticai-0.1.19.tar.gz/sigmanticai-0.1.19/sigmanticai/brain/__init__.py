"""
SigmanticAI Brain — Persistent Project Memory.

The brain is a `.sigmanticaicache/` directory that stores structured
project knowledge as separate files. The agent reads/writes these
files through its existing tools (read_file, write_file, etc.) —
the brain is external memory, NOT loaded into context.

Directory structure:
    .sigmanticaicache/
    ├── meta.json              # Version, timestamps, source file hashes
    ├── file_map.json          # 100% accurate file inventory (NEW in v2.0)
    ├── ports.json             # Module port definitions (best-effort regex)
    ├── architecture.json      # Module hierarchy, FSMs, interfaces
    ├── decisions.json         # Design decisions log (append-only)
    ├── symbols.json           # UVM classes, instances, naming conventions
    ├── coverage_state.json    # Intent graph snapshot, gaps, coverage
    └── context_summary.md     # LLM-readable project summary

Population triggers:
    1. Auto-parse: Agent enters a directory with HDL files → extract file_map + ports/symbols
    2. Pipeline:   After generation stages → write architecture/symbols/coverage
    3. Compress:   On context compression → persist summary + decisions to disk
    4. Explicit:   Agent writes to cache files via write_file during conversation

Reliability tiers:
    - file_map.json:   100% accurate (just a directory scan, can't miss anything)
    - ports/symbols:   Best-effort regex (may miss unusual formatting)
    - architecture:    From pipeline state (accurate when pipeline runs)
"""

from sigmanticai.brain.cache import (
    BrainCache,
    CACHE_DIR_NAME,
    populate_cache_from_codebase,
    write_cache_from_pipeline_state,
    persist_compression_to_cache,
)

__all__ = [
    "BrainCache",
    "CACHE_DIR_NAME",
    "populate_cache_from_codebase",
    "write_cache_from_pipeline_state",
    "persist_compression_to_cache",
]

