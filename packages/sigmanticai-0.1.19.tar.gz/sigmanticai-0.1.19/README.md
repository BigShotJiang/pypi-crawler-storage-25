# SigmanticAI

**AI-powered hardware verification from the command line.**

SigmanticAI generates complete chip verification environments — UVM testbenches, SystemVerilog assertions, coverage models, and RTL — from natural language descriptions. Just describe what you need and the AI builds, compiles, and iterates until your design works.

## Installation

```bash
pip install sigmanticai
```

Requires Python 3.10+. Verilator is included automatically.

> **`sigmanticai: command not found`?** Your Python scripts directory may not be on PATH.
> Try `python3 -m sigmanticai` as a workaround, or add the path shown in pip's install output to your shell profile:
> - **macOS/Linux:** `export PATH="$HOME/.local/bin:$PATH"` (add to `~/.zshrc` or `~/.bashrc`)
> - **Windows:** Add `%APPDATA%\Python\PythonXX\Scripts` to your system PATH

## Quick Start

```bash
# Sign in (opens browser)
sigmanticai login

# Interactive mode — chat with the AI agent
sigmanticai

# One-shot generation
sigmanticai generate "Build a UVM testbench for a 32-bit AXI4 FIFO"

# Check your account
sigmanticai whoami
sigmanticai status
```

## What It Does

- **Generate verification environments** — UVM testbenches, scoreboards, coverage, and assertions from a single prompt
- **Design RTL modules** — counters, FIFOs, arbiters, interfaces, and more
- **Edit existing code** — point the agent at your codebase and ask for changes
- **Run compilation & simulation** — Verilator (bundled), Questa, VCS, Xcelium, and other EDA tools
- **Iterative debugging** — the agent automatically fixes compilation errors and re-runs until tests pass
- **Multi-vendor EDA support** — configure your toolchain once, the agent uses the right commands everywhere

## Commands

| Command | Description |
|---------|-------------|
| `sigmanticai` | Interactive REPL (main mode) |
| `sigmanticai login` | Sign in via browser |
| `sigmanticai login --email <e> --password <p>` | Headless login (SSH/CI) |
| `sigmanticai login --google --email <e>` | Login via email code (Google accounts) |
| `sigmanticai logout` | Clear stored credentials |
| `sigmanticai whoami` | Show current user |
| `sigmanticai status` | Show plan, quota, account info |
| `sigmanticai jobs` | List recent generation jobs |
| `sigmanticai generate "<prompt>"` | One-shot generation |

## Interactive Commands

Inside the REPL:

| Command | Description |
|---------|-------------|
| `/tool` | Configure EDA tools (simulator, lint, coverage, formal) |
| `/tool reset` | Reset tools to defaults (Verilator) |
| `/tool preset <vendor>` | Apply vendor preset (synopsys, cadence, siemens, open_source) |
| `/upload <path>` | Upload a file or directory for the agent to use |
| `/help` | Show available commands |
| `exit` / `quit` / `q` | End session |

## EDA Tool Support

SigmanticAI supports multiple EDA vendors out of the box:

| Category | Supported Tools |
|----------|----------------|
| **Lint** | Verilator, Synopsys SpyGlass, Cadence HAL, Siemens Questa Lint |
| **Simulator** | Verilator, Synopsys VCS, Cadence Xcelium, Siemens Questa, AMD XSIM |
| **Coverage** | Synopsys VCS Coverage, Cadence IMC, Siemens Questa Coverage |
| **Formal** | Synopsys VC Formal, Cadence JasperGold, Siemens Questa Formal |

Configure your toolchain with `/tool` — the agent automatically uses the correct commands, flags, and error patterns for your tools.

## Requirements

- Python 3.10+
- Internet connection
- A SigmanticAI account — sign up at [sigmanticai.com](https://sigmanticai.com)

## Links

- **Website:** [sigmanticai.com](https://sigmanticai.com)
- **Documentation:** [docs.sigmanticai.com](https://docs.sigmanticai.com)
- **Support:** team@sigmanticai.com
