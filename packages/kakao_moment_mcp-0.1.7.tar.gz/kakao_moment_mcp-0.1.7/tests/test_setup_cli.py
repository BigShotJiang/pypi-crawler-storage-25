from pathlib import Path

from kakao_moment_mcp.scripts import setup_cli


def test_claude_desktop_config_paths_include_msix_cache(monkeypatch, tmp_path):
    appdata = tmp_path / "Roaming"
    localappdata = tmp_path / "Local"
    package = localappdata / "Packages" / "Claude_pzs8sxrjxfjjc"
    package.mkdir(parents=True)

    monkeypatch.setattr(setup_cli.sys, "platform", "win32")
    monkeypatch.setenv("APPDATA", str(appdata))
    monkeypatch.setenv("LOCALAPPDATA", str(localappdata))

    paths = setup_cli._claude_desktop_config_paths()

    assert paths == [
        appdata / "Claude" / "claude_desktop_config.json",
        package
        / "LocalCache"
        / "Roaming"
        / "Claude"
        / "claude_desktop_config.json",
    ]


def test_claude_desktop_config_path_uses_first_candidate(monkeypatch, tmp_path):
    appdata = tmp_path / "Roaming"

    monkeypatch.setattr(setup_cli.sys, "platform", "win32")
    monkeypatch.setenv("APPDATA", str(appdata))
    monkeypatch.delenv("LOCALAPPDATA", raising=False)

    assert setup_cli._claude_desktop_config_path() == Path(
        appdata / "Claude" / "claude_desktop_config.json"
    )
