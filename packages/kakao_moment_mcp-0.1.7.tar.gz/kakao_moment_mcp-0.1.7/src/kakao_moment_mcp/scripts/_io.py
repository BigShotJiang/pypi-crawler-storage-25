"""CLI stdio 인코딩 유틸.

영문 Windows (cp1252) 같은 환경에서 한글 출력 시 UnicodeEncodeError 가 나는 걸 방지.
Python 3.7+ 의 `sys.stdout.reconfigure` 로 UTF-8 강제. 실패하면 조용히 통과.

MCP 서버 본체(stdio 프로토콜)에서는 절대 호출하지 말 것 — 프로토콜 바이트가 깨진다.
오직 사용자 대화형 CLI (`*_cli.py`, `authorize.py`) 의 진입점에서만 호출.
"""
from __future__ import annotations

import sys


def force_utf8_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except (AttributeError, ValueError):
            # Python <3.7 또는 텍스트 스트림이 아닌 경우 — 무시.
            pass


__all__ = ["force_utf8_stdio"]
