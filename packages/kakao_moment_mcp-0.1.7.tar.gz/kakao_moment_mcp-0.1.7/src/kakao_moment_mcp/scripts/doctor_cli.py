"""진단 CLI — 문제 생겼을 때 한 줄로 상태 확인.

사용:
    uvx --from kakao-moment-mcp kakao-moment-mcp-doctor
    uv run kakao-moment-mcp-doctor

체크 항목:
  1. ~/.kakao-moment-mcp/.env 존재 + 필수 키
  2. ~/.kakao-moment-mcp/tokens.json 존재 + 만료 여부
  3. ~/.kakao-moment-mcp/logs 디렉토리 쓰기 가능
  4. MCP 클라이언트 config (Claude Desktop / Cursor / Cline) 에 kakao-moment 등록 여부
  5. (옵션, --live) /v2/user/me 호출로 토큰 실제 유효성 확인
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from ..auth.token_store import load_tokens
from ..config import HOME_CONFIG_DIR, HOME_ENV_PATH, TOKEN_PATH
from ._io import force_utf8_stdio

_REQUIRED_ENV_KEYS = (
    "KAKAO_REST_API_KEY",
    "KAKAO_CLIENT_SECRET",
    "KAKAO_AD_ACCOUNT_ID",
)


def _ok(msg: str) -> None:
    print(f"  ✅ {msg}")


def _warn(msg: str) -> None:
    print(f"  ⚠️  {msg}")


def _fail(msg: str) -> None:
    print(f"  ❌ {msg}")


def _check_env() -> bool:
    print("[1/4] 자격증명 .env")
    if not HOME_ENV_PATH.exists():
        _fail(f"파일 없음: {HOME_ENV_PATH} — `kakao-moment-mcp-setup` 을 실행하세요.")
        return False
    text = HOME_ENV_PATH.read_text()
    present: dict[str, bool] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        present[k.strip()] = bool(v.strip())
    missing = [k for k in _REQUIRED_ENV_KEYS if not present.get(k)]
    if missing:
        _fail(f"필수 키 누락: {', '.join(missing)} — setup 을 다시 실행하세요.")
        return False
    _ok(f"{HOME_ENV_PATH} (필수 키 {len(_REQUIRED_ENV_KEYS)}개 모두 존재)")
    return True


def _check_tokens() -> bool:
    print("[2/4] OAuth 토큰")
    if not TOKEN_PATH.exists():
        _fail(
            f"토큰 파일 없음: {TOKEN_PATH} — "
            "`uvx --from kakao-moment-mcp kakao-moment-mcp-authorize` 를 실행하세요."
        )
        return False
    tokens = load_tokens()
    if tokens is None:
        _fail(f"{TOKEN_PATH} 파싱 실패 — 파일이 손상됐을 수 있습니다. 재인증 필요.")
        return False
    if tokens.is_expired(leeway=0):
        _warn(
            "토큰이 만료됐습니다. "
            "`kakao-moment-mcp-authorize` 로 재인증하세요. "
            f"(scope: {tokens.scope or 'unknown'})"
        )
        return False
    _ok(f"유효 (scope: {tokens.scope or 'unknown'})")
    return True


def _check_logs() -> bool:
    print("[3/4] 로그 디렉토리")
    log_dir_raw = os.environ.get("KAKAO_MCP_LOG_DIR")
    log_dir = (
        Path(log_dir_raw).expanduser()
        if log_dir_raw
        else HOME_CONFIG_DIR / "logs"
    )
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except (PermissionError, OSError) as e:
        _fail(f"디렉토리 생성 불가: {log_dir} ({e})")
        return False
    probe = log_dir / ".doctor_probe"
    try:
        probe.write_text("ok")
        probe.unlink()
    except (PermissionError, OSError) as e:
        _fail(f"쓰기 권한 없음: {log_dir} ({e})")
        return False
    files = sorted(log_dir.glob("server.jsonl*"))
    if files:
        _ok(f"{log_dir} (로그 파일 {len(files)}개)")
    else:
        _ok(f"{log_dir} (아직 로그 없음 — 서버 첫 호출 시 생성)")
    return True


def _client_configs() -> list[tuple[str, Path | None]]:
    from .setup_cli import (
        _claude_desktop_config_paths,
        _cline_config_path,
        _cursor_config_path,
    )

    configs: list[tuple[str, Path | None]] = [
        ("Cursor", _cursor_config_path()),
        ("Cline (VSCode)", _cline_config_path()),
    ]
    claude_paths = _claude_desktop_config_paths()
    if claude_paths:
        configs = [
            (f"Claude Desktop #{idx}", path)
            for idx, path in enumerate(claude_paths, start=1)
        ] + configs
    else:
        configs = [("Claude Desktop", None), *configs]
    return configs


def _check_clients() -> bool:
    print("[4/4] MCP 클라이언트 등록")
    found_any = False
    for name, path in _client_configs():
        if path is None:
            _warn(f"{name}: 이 OS 에서 자동 설정 미지원")
            continue
        if not path.exists():
            _warn(f"{name}: config 없음 ({path}) — 설치되어 있지 않거나 미등록")
            continue
        try:
            cfg = json.loads(path.read_text() or "{}")
        except json.JSONDecodeError:
            _fail(f"{name}: {path} JSON 파싱 실패")
            continue
        servers = cfg.get("mcpServers") or {}
        if isinstance(servers, dict) and "kakao-moment" in servers:
            _ok(f"{name}: 등록됨 ({path})")
            found_any = True
        else:
            _warn(f"{name}: kakao-moment 미등록 — setup 을 다시 돌리세요. ({path})")
    if not found_any:
        _warn("어떤 클라이언트에도 등록되어 있지 않습니다.")
    return found_any


async def _check_live() -> bool:
    """실제 카카오 API 호출로 토큰 유효성 확인."""
    print("[5/5] 라이브 API 호출 (광고계정 조회)")
    try:
        from ..config import load_settings
        from ..kakao.client import KakaoMomentClient
    except Exception as e:  # noqa: BLE001
        _fail(f"설정 로드 실패: {e}")
        return False
    try:
        settings = load_settings()
    except Exception as e:  # noqa: BLE001
        _fail(f"설정 검증 실패: {e}")
        return False
    client = KakaoMomentClient(settings)
    try:
        data = await client.get(f"/openapi/v4/adAccounts/{settings.ad_account_id}")
        body = (
            data.get("data") if isinstance(data, dict) and "data" in data else data
        )
        name = (
            body.get("name") if isinstance(body, dict) else None
        ) or "(이름 미상)"
        _ok(f"광고계정 조회 성공: 「{name}」")
        return True
    except Exception as e:  # noqa: BLE001
        _fail(f"API 호출 실패: {e}")
        return False
    finally:
        await client.aclose()


def main() -> int:
    force_utf8_stdio()
    parser = argparse.ArgumentParser(
        prog="kakao-moment-mcp-doctor",
        description="kakao-moment-mcp 상태 진단",
    )
    parser.add_argument(
        "--live",
        action="store_true",
        help="실제 카카오 API 호출로 토큰 유효성까지 확인",
    )
    args = parser.parse_args()

    print("=" * 60)
    print("  kakao-moment-mcp — Doctor")
    print("=" * 60)
    print()

    results = [
        _check_env(),
        _check_tokens(),
        _check_logs(),
        _check_clients(),
    ]
    print()

    if args.live:
        import asyncio

        live_ok = asyncio.run(_check_live())
        results.append(live_ok)
        print()

    passed = sum(1 for r in results if r)
    total = len(results)
    if passed == total:
        print(f"🎉 {passed}/{total} 통과 — 정상 동작 상태입니다.")
        return 0
    print(f"⚠️  {passed}/{total} 통과 — 위 항목을 확인하세요.")
    print()
    print("도움이 필요하면 이 출력 전체와 함께 이슈를 등록해 주세요:")
    print("  https://github.com/jun7680/kakao-moment-mcp/issues")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
