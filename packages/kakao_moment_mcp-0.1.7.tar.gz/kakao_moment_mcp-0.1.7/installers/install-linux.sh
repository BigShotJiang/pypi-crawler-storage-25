#!/usr/bin/env bash
# Linux 인스톨러.
# 데스크탑 환경에서는 더블클릭 시 "실행" 옵션을 고르면 됩니다.
# 또는 터미널에서:  bash install-linux.sh

trap 'echo; read -n 1 -s -r -p "창을 닫으려면 아무 키나 누르세요."; echo' EXIT
set -e

echo "============================================================"
echo "  Kakao Moment MCP — Linux Installer"
echo "============================================================"
echo
echo "이 인스톨러가 자동으로 처리하는 일:"
echo "  1) Python 패키지 관리자 (uv) 설치"
echo "  2) 카카오모먼트 MCP 마법사 실행 (자격증명, OAuth, 클라이언트 등록)"
echo
echo "ℹ️  Linux 에는 Claude Desktop 앱이 없습니다."
echo "    Claude Code (CLI) / Cursor / Cline (VSCode 확장) 에서 동작합니다."
echo
read -n 1 -s -r -p "진행하려면 아무 키나 누르세요. (취소: Ctrl+C)"
echo
echo

# ---- uv 설치 ----
if command -v uv >/dev/null 2>&1; then
  echo "[1/2] ✓ uv 이미 설치됨. 건너뜁니다."
else
  echo "[1/2] uv 설치 중..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
  echo "✓ uv 설치 완료"
fi
echo

# ---- setup 마법사 ----
echo "[2/2] kakao-moment-mcp 마법사 실행..."
echo "      (카카오 REST API Key / Client Secret / 광고계정 ID 를 준비해 주세요)"
echo
if uvx --from kakao-moment-mcp kakao-moment-mcp-setup; then
  echo
  echo "============================================================"
  echo "  ✅ 설치 완료"
  echo "============================================================"
  echo
  echo "사용 중인 클라이언트를 재시작하면 도구 7개가 보입니다."
  echo
  echo "문제가 생기면 다음 명령으로 진단:"
  echo "   uvx --from kakao-moment-mcp kakao-moment-mcp-doctor"
else
  RC=$?
  echo
  echo "============================================================"
  echo "  ⚠️  설치가 중단되었습니다 (exit code: $RC)"
  echo "============================================================"
  echo
  echo "같은 인스톨러를 다시 실행해도 안전합니다."
fi
echo
