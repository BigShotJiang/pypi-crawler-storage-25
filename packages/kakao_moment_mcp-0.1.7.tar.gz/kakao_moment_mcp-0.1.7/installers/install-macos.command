#!/usr/bin/env bash
# macOS 더블클릭 인스톨러.
# Finder 에서 이 파일을 더블클릭하면 터미널이 자동으로 열리며 설치가 진행됩니다.
#
# 처음 더블클릭 시 macOS Gatekeeper 가 차단할 수 있습니다.
# 그 경우: Finder 에서 우클릭 → 열기 → "열기" 버튼 (한 번만 허용하면 이후 자동).

# 어떤 경로로 종료되든 창이 닫히기 전에 사용자가 메시지를 읽을 수 있게 한다.
trap 'echo; read -n 1 -s -r -p "창을 닫으려면 아무 키나 누르세요."; echo' EXIT
set -e

echo "============================================================"
echo "  Kakao Moment MCP — macOS Installer"
echo "============================================================"
echo
echo "이 인스톨러가 자동으로 처리하는 일:"
echo "  1) Python 패키지 관리자 (uv) 설치"
echo "  2) 카카오모먼트 MCP 마법사 실행 (자격증명, OAuth, 클라이언트 등록)"
echo
read -n 1 -s -r -p "진행하려면 아무 키나 누르세요. (취소: Ctrl+C)"
echo
echo

# ---- uv 설치 ----
if command -v uv >/dev/null 2>&1; then
  echo "[1/2] ✓ uv 이미 설치됨. 건너뜁니다."
else
  echo "[1/2] uv 설치 중... (잠시만 기다려 주세요)"
  if command -v brew >/dev/null 2>&1; then
    brew install uv
  else
    curl -LsSf https://astral.sh/uv/install.sh | sh
    # 새로 설치한 uv 경로를 현재 세션에 추가
    export PATH="$HOME/.local/bin:$PATH"
  fi
  echo "✓ uv 설치 완료"
fi
echo

# ---- setup 마법사 ----
echo "[2/2] kakao-moment-mcp 마법사 실행..."
echo "      (카카오 REST API Key / Client Secret / 광고계정 ID 를 준비해 주세요)"
echo
if uvx --from kakao-moment-mcp kakao-moment-mcp-setup; then
  echo
  echo "============================================================"
  echo "  ✅ 설치 완료"
  echo "============================================================"
  echo
  echo "Claude Desktop / Cursor / Cline / Claude Code 를 재시작하면"
  echo "도구 7개가 보입니다."
  echo
  echo "문제가 생기면 다음 명령으로 진단:"
  echo "   uvx --from kakao-moment-mcp kakao-moment-mcp-doctor"
else
  RC=$?
  echo
  echo "============================================================"
  echo "  ⚠️  설치가 중단되었습니다 (exit code: $RC)"
  echo "============================================================"
  echo
  echo "같은 인스톨러를 다시 실행해도 안전합니다."
fi

# trap 이 처리하므로 별도 read 불필요
