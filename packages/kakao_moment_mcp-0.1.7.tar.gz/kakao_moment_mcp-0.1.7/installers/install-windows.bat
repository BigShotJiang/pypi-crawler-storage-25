@echo off
chcp 65001 >nul 2>&1
title Kakao Moment MCP - Windows Installer

echo ============================================================
echo   Kakao Moment MCP - Windows Installer
echo ============================================================
echo.
echo 1) uv (Python 패키지 관리자) 설치
echo 2) 마법사로 카카오 자격증명 입력 + OAuth 인증
echo 3) Claude Desktop 설정에 kakao-moment 자동 등록
echo.
echo 진행하려면 아무 키나 누르세요.
pause >nul
echo.

REM ===== 1) uv =====
where uv >nul 2>&1
if errorlevel 1 (
    echo [1/3] uv 설치 중...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
    if errorlevel 1 (
        echo.
        echo [실패] uv 설치 실패. 인터넷 또는 PowerShell 정책을 확인하세요.
        goto end_fail
    )
) else (
    echo [1/3] uv 이미 설치됨.
)
set "PATH=%USERPROFILE%\.local\bin;%LOCALAPPDATA%\uv\bin;%PATH%"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

REM ===== 2) 마법사 =====
echo.
echo [2/3] 카카오 자격증명 입력 + OAuth 인증
echo       REST API Key / Client Secret / 광고계정 ID 를 준비해 주세요.
echo.
uvx --from kakao-moment-mcp kakao-moment-mcp-setup
if errorlevel 1 (
    echo.
    echo [실패] 마법사가 중단되었습니다. 같은 .bat 를 다시 실행하면 됩니다.
    goto end_fail
)

REM ===== 3) Claude Desktop config 절대경로 보정 =====
REM GitHub 의 .ps1 을 다운받아 실행 (인라인 PowerShell 따옴표 헬 회피)
echo.
echo [3/3] Claude 종료 + config 자동 보정...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "irm https://raw.githubusercontent.com/jun7680/kakao-moment-mcp/main/installers/_fix-claude-config.ps1 | iex"
if errorlevel 1 (
    echo.
    echo [경고] config 자동 보정 실패. 마법사가 등록한 그대로 사용.
    echo        문제 시 다음 파일을 수동 편집하세요:
    echo        %APPDATA%\Claude\claude_desktop_config.json
)

echo.
echo ============================================================
echo   [성공] 설치 완료
echo ============================================================
echo.
echo Claude Desktop 을 완전히 종료한 후 재시작하면 도구 7개가 보입니다.
echo.
echo 문제 진단:
echo    uvx --from kakao-moment-mcp kakao-moment-mcp-doctor

:end_ok
echo.
echo 창을 닫으려면 아무 키나 누르세요.
pause >nul
exit /b 0

:end_fail
echo.
echo 창을 닫으려면 아무 키나 누르세요.
pause >nul
exit /b 1
