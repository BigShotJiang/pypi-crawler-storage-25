@echo off
chcp 65001 >nul 2>&1
title Merge Claude Desktop MCP configs

echo ============================================================
echo   Claude Desktop MCP config merge
echo ============================================================
echo.
echo This will:
echo   1) Stop Claude Desktop
echo   2) Find Claude config files
echo   3) Pick the config containing MAILPLUG / Atlassian as target
echo   4) Merge google / naver / kakao-moment entries into that target
echo   5) Backup the target before writing
echo.
echo Press any key to continue.
pause >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference = 'Stop';" ^
  "try { Stop-Process -Name 'claude' -Force -ErrorAction SilentlyContinue } catch {};" ^
  "$files = @();" ^
  "$primary = Join-Path $env:APPDATA 'Claude\claude_desktop_config.json';" ^
  "if (Test-Path $primary) { $files += Get-Item $primary };" ^
  "$packageConfigs = Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Packages\*\LocalCache\Roaming\Claude\claude_desktop_config.json') -ErrorAction SilentlyContinue;" ^
  "if ($packageConfigs) { $files += $packageConfigs };" ^
  "if (-not $files -or $files.Count -eq 0) { Write-Host '[ERROR] No Claude config files found.'; exit 1 };" ^
  "$configs = @();" ^
  "foreach ($file in $files) {" ^
  "  try {" ^
  "    $obj = Get-Content $file.FullName -Raw | ConvertFrom-Json;" ^
  "    $servers = @();" ^
  "    if ($obj.mcpServers) { $servers = @($obj.mcpServers.PSObject.Properties.Name) };" ^
  "    $configs += [pscustomobject]@{ Path = $file.FullName; Obj = $obj; Servers = $servers; HasMailplug = (($servers -join ' ') -match 'MAILPLUG|Atlassian|jira') };" ^
  "    Write-Host ''; Write-Host ('[OK] ' + $file.FullName); Write-Host 'servers:'; $servers | ForEach-Object { Write-Host ('  - ' + $_) };" ^
  "  } catch {" ^
  "    Write-Host ('[SKIP] Broken JSON: ' + $file.FullName); Write-Host $_.Exception.Message;" ^
  "  }" ^
  "};" ^
  "$target = $configs | Where-Object { $_.HasMailplug } | Select-Object -First 1;" ^
  "if (-not $target) { Write-Host ''; Write-Host '[ERROR] Could not find config containing MAILPLUG / Atlassian / jira.'; exit 1 };" ^
  "Write-Host ''; Write-Host ('[TARGET] ' + $target.Path);" ^
  "if (-not $target.Obj.PSObject.Properties.Match('mcpServers').Count) { Add-Member -InputObject $target.Obj -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{}) };" ^
  "$merged = @();" ^
  "foreach ($src in $configs) {" ^
  "  if (-not $src.Obj.mcpServers) { continue };" ^
  "  foreach ($prop in $src.Obj.mcpServers.PSObject.Properties) {" ^
  "    $name = $prop.Name;" ^
  "    if ($name -match 'google|naver|kakao-moment') {" ^
  "      if ($target.Obj.mcpServers.PSObject.Properties.Match($name).Count) { $target.Obj.mcpServers.$name = $prop.Value }" ^
  "      else { Add-Member -InputObject $target.Obj.mcpServers -NotePropertyName $name -NotePropertyValue $prop.Value };" ^
  "      $merged += $name;" ^
  "    }" ^
  "  }" ^
  "};" ^
  "$stamp = Get-Date -Format 'yyyyMMdd-HHmmss';" ^
  "$backup = $target.Path + '.backup-before-merge-' + $stamp + '.bak';" ^
  "Copy-Item $target.Path $backup -Force;" ^
  "$target.Obj | ConvertTo-Json -Depth 30 | Set-Content -Path $target.Path -Encoding UTF8;" ^
  "$verify = Get-Content $target.Path -Raw | ConvertFrom-Json;" ^
  "Write-Host ''; Write-Host ('[BACKUP] ' + $backup);" ^
  "Write-Host ('[UPDATED] ' + $target.Path);" ^
  "Write-Host ''; Write-Host 'servers now:'; $verify.mcpServers.PSObject.Properties.Name | ForEach-Object { Write-Host ('  - ' + $_) };" ^
  "Write-Host ''; Write-Host '[DONE] Start Claude Desktop again and check the MCP log.';"

if errorlevel 1 (
  echo.
  echo [FAILED] Merge did not complete.
  echo Copy the output above and send it for diagnosis.
) else (
  echo.
  echo [OK] Merge complete. Start Claude Desktop again.
)

echo.
echo Press any key to close.
pause >nul
