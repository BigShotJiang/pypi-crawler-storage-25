# kakao-moment 의 Claude Desktop config 를 uvx 절대경로로 보정하는 PowerShell 스크립트.
# Windows GUI 앱이 사용자 PATH 의 uvx 를 못 찾아 MCP spawn 실패하는 케이스를 해결.
#
# 직접 실행:
#   powershell -NoProfile -ExecutionPolicy Bypass -File installers\_fix-claude-config.ps1
#
# 또는 원격에서:
#   powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://raw.githubusercontent.com/jun7680/kakao-moment-mcp/main/installers/_fix-claude-config.ps1 | iex"

$ErrorActionPreference = 'Stop'

# Claude 종료 (트레이 잔존 포함)
Write-Host "[1/3] Claude Desktop 종료..."
try { Stop-Process -Name 'claude' -Force -ErrorAction SilentlyContinue } catch {}

# config 경로 후보
$cfgCandidates = New-Object System.Collections.Generic.List[string]
if ($env:APPDATA) {
    $cfgCandidates.Add((Join-Path $env:APPDATA 'Claude\claude_desktop_config.json'))
}
if ($env:LOCALAPPDATA) {
    $packages = Join-Path $env:LOCALAPPDATA 'Packages'
    if (Test-Path $packages) {
        Get-ChildItem -Path $packages -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue | ForEach-Object {
            $cfgCandidates.Add((Join-Path $_.FullName 'LocalCache\Roaming\Claude\claude_desktop_config.json'))
        }
    }
}

$cfgs = $cfgCandidates | Select-Object -Unique
$existingCfgs = @($cfgs | Where-Object { Test-Path $_ })
if ($existingCfgs.Count -gt 0) {
    $targetCfgs = $existingCfgs
} else {
    $targetCfgs = @($cfgs | Select-Object -First 1)
}
if (-not $targetCfgs -or $targetCfgs.Count -eq 0) {
    Write-Host "[!] Claude Desktop config 경로를 찾을 수 없습니다." -ForegroundColor Yellow
    exit 1
}

# uvx 절대경로 탐색
$uvx = (Get-Command uvx -ErrorAction SilentlyContinue).Source
if (-not $uvx) {
    Write-Host "[!] uvx 를 PATH 에서 찾을 수 없습니다. 먼저 uv 를 설치하세요." -ForegroundColor Yellow
    Write-Host "    powershell -ExecutionPolicy ByPass -c `"irm https://astral.sh/uv/install.ps1 | iex`""
    exit 1
}
Write-Host "[2/3] uvx 경로: $uvx"

$entry = [pscustomobject]@{ command = $uvx; args = @('kakao-moment-mcp') }
foreach ($cfg in $targetCfgs) {
    $dir = Split-Path $cfg -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    # 기존 config 읽기 (또는 새로 생성)
    $obj = if ((Test-Path $cfg) -and ((Get-Item $cfg).Length -gt 0)) {
        Get-Content $cfg -Raw | ConvertFrom-Json
    } else {
        [pscustomobject]@{}
    }

    # mcpServers 보장
    if (-not $obj.PSObject.Properties.Match('mcpServers').Count) {
        Add-Member -InputObject $obj -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{})
    }

    # kakao-moment 항목 (기존이 있으면 교체, 없으면 추가)
    if ($obj.mcpServers.PSObject.Properties.Match('kakao-moment').Count) {
        $obj.mcpServers.'kakao-moment' = $entry
    } else {
        Add-Member -InputObject $obj.mcpServers -NotePropertyName 'kakao-moment' -NotePropertyValue $entry
    }

    # 저장 (UTF-8)
    $obj | ConvertTo-Json -Depth 10 | Set-Content -Path $cfg -Encoding UTF8
    Write-Host "[3/3] config 갱신 완료: $cfg"
}

Write-Host ""
Write-Host "[OK] 끝. 이제 시작 메뉴에서 Claude Desktop 을 다시 실행하세요."
