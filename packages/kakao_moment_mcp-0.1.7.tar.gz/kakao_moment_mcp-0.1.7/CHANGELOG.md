# Changelog

이 프로젝트의 모든 주목할만한 변경은 이 파일에 기록됩니다.
형식은 [Keep a Changelog](https://keepachangelog.com/ko/1.1.0/) 를 따르며,
버전은 [SemVer](https://semver.org/lang/ko/) 를 사용합니다.

## [0.1.1] - 2026-05-19

### Fixed
- 패키지 메타데이터 정정: author/Copyright/Homepage URL 을 개인 계정으로 교체. (0.1.0 은 yank 예정)
- README 의 머신별 절대경로 → 일반화된 placeholder.
- SECURITY.md 의 취약점 제보 채널을 GitHub Security Advisory 로 단일화.

## [0.1.2] - 2026-05-19

### Added
- **더블클릭 인스톨러** 3종 (`installers/install-{windows.bat,macos.command,linux.sh}`) — 터미널 명령 한 줄도 치기 싫은 사용자가 OS별 인스톨러 파일을 다운로드해 더블클릭만 하면 uv 설치 + setup 마법사 자동 실행.
- **Makefile** — `make install/test/lint/build/publish/release` 타깃. `make publish` 가 keyring (macOS Keychain) 에서 PyPI 토큰을 자동 로드.

### Changed
- README 가독성 전면 개선: 배지 5종, Mermaid 아키텍처 다이어그램, OS별/클라이언트별 접이식 탭, 자연어→도구 매핑 표, 설치 옵션을 "딸깍" vs "명령어" 두 갈래로 분기.
- 수동 MCP 등록 섹션을 옵션으로 명확히 표기 (마법사가 이미 처리하므로 99% 사용자는 건너뜀).

### Notes
- 런타임 변경 없음. PyPI 페이지의 README 표시 갱신 목적.

## [0.1.3] - 2026-05-19

### Fixed
- **영문 Windows (cp1252)** 에서 CLI 도구 실행 시 `UnicodeEncodeError` 가 나던 문제. 모든 CLI 진입점 (`*_cli.py`, `authorize.py`) 이 시작 시 stdout/stderr 을 UTF-8 로 재설정 (`force_utf8_stdio()`).
- `install-windows.bat` 을 cp949 → UTF-8 (no BOM) + CRLF + `chcp 65001` 패턴으로 변경 → 한국어/영문 Windows 모두 한글 정상 출력.
- `.bat` 이 `PYTHONUTF8=1` / `PYTHONIOENCODING=utf-8` 을 env 로 주입해 자식 Python 프로세스도 UTF-8 stdio 강제.

### Added
- `scripts/_io.py` — `force_utf8_stdio()` 헬퍼. MCP 서버 본체에는 영향 없도록 CLI 진입점에서만 호출.

## [0.1.5] - 2026-05-19

### Fixed
- `auth/oauth.py` 가 사용자 설정과 무관하게 **항상 `moment_management` 를 scope 에 포함** (카카오모먼트 API 필수 권한). 사용자가 추가 scope 을 지정한 경우 함께 전달.

## [0.1.4] - 2026-05-19

### Fixed
- **OAuth "missing scope parameter" 에러** 픽스. Kakao Business OAuth (`/oauth/business/authorize`) 는 scope 파라미터가 필수인데 0.1.2 이후 `.env.example` 기본값이 비어있어서 인증 실패하던 회귀.
- `.env.example` 의 `KAKAO_OAUTH_SCOPES` 기본값을 `moment_management` 로 복원.
- `auth/oauth.py` 가 scope 가 비어있으면 `moment_management` 를 자동 fallback (이후 0.1.5 에서 항상 포함으로 강화됨).

## [0.1.6] - 2026-05-19

### Changed
- **Enter 만 누르면 진행**: 미감지된 MCP 클라이언트 (Cursor / Cline 미설치 등) 에 대해서는 더 이상 등록 여부를 묻지 않고 조용히 skip. 카카오 자격증명 3개 입력 외에는 Enter 만으로 끝까지 진행 가능.
- 모든 확인 프롬프트 `default=True` 유지 (Enter = Y 로 진행).

### Added
- `installers/_fix-claude-config.ps1`: Windows Claude Desktop 에서 `uvx` PATH 못 찾는 문제를 자동 해결하는 PowerShell 스크립트. .bat 가 GitHub raw 에서 받아 실행하도록 변경 (인라인 PowerShell 따옴표 헬 제거).

## [0.1.7] - 2026-05-19

### Added
- **Microsoft Store Claude Desktop 자동 지원**: setup 마법사와 doctor 가 `%LOCALAPPDATA%\Packages\Claude*\LocalCache\Roaming\Claude\claude_desktop_config.json` 경로도 함께 탐색·등록.
- `_claude_desktop_config_paths()` 가 list 를 반환 (Windows 의 표준 + MSIX 캐시 경로 둘 다).
- 새 유틸 `installers/merge-claude-configs-windows.bat` — 여러 Claude config 위치를 한 번에 머지.

### Fixed
- 표준 인스톨러 + MS Store 둘 다 깔린 환경에서 한 쪽에만 등록되던 문제.

## [Unreleased]

### Added
- **구조화 로깅**: `~/.kakao-moment-mcp/logs/server.jsonl` (자정 회전, 7일 보관). 도구별 `request_id` 응답에 자동 포함. 환경변수 `KAKAO_MCP_LOG_LEVEL`, `KAKAO_MCP_LOG_DIR`.
- **HTTP 호출 자동 로깅**: httpx event hook 으로 method/path/status/duration/call_id 기록. 429/5xx 재시도 시도 횟수도 로그.
- **사용자 친화 에러 메시지**: 카카오 코드 + HTTP status 별 한글 가이드 (`kakao/errors.py` 매핑 확장).
- **도구 응답 보강**:
  - 모든 도구에 한국어 `summary` 1줄.
  - `get_today_status`: 시간대별 페이스, 현재 페이스 기준 마감 예상 소진율.
  - `get_bizmoney`: 최근 7일 일별 소진 추이, 잔액 기준 잔여 일수 추정.
  - `list_*`: detail 엔드포인트 자동 동시 fetch 로 daily_budget/bid_amount/createdDate 등 보강 (`with_details=True` 기본).
- **자연어 트리거**: 7개 도구 docstring 에 "이런 질문에 사용하세요" 섹션. LLM 의 도구 선택 정확도 향상.
- **다중 MCP 클라이언트 자동 등록**: Cursor (`~/.cursor/mcp.json`), Cline (VSCode 확장) 자동 감지/등록. Claude Desktop/Code 와 동일 마법사로.
- **`kakao-moment-mcp-doctor`**: 진단 CLI. env/토큰/로그/클라이언트 등록 상태 한 줄로 점검. `--live` 로 실제 API 호출 검증.
- **OS 별 설치 가이드**: README 에 macOS/Windows/Linux 접이식 블록.

### Changed
- 리포트 응답 신형 포맷(`{dimensions, metrics}`) 자동 unwrap. 구형 flat 포맷도 계속 지원.
- 리포트 breakdown 파라미터를 `metricsGroup` (단수) → `metricsGroups` (복수) 로 수정. 카카오가 단수형을 거부하던 회귀 픽스.
- 재시도 대상 확장: 기존 429 + 5xx(500/502/503/504) 도 동일 backoff.

### Fixed
- `list_campaigns`/`list_adgroups`/`list_creatives` 의 `daily_budget`/`bid_amount` 가 항상 null 이던 문제. LIST 엔드포인트가 lightweight 라 detail 별도 호출 필요했음.

## [0.1.0] - 2026-05-18

### Added
- 초기 릴리즈. Phase 1 조회/리포트 도구 7개:
  - `get_ad_account_info`, `get_bizmoney`, `get_today_status`
  - `list_campaigns`, `list_adgroups`, `list_creatives`
  - `get_performance_report`
- CLI 마법사 `kakao-moment-mcp-setup` 으로 자격증명 입력 → OAuth → Claude Desktop/Code 자동 등록.
- 비즈니스 OAuth 토큰 저장 (`~/.kakao-moment-mcp/tokens.json`, 0600).
