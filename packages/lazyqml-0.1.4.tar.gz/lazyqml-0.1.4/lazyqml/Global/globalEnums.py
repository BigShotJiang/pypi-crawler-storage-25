"""
------------------------------------------------------------------------------------------------------------------
    This file is devoted to define the global enums for easening the interface.
------------------------------------------------------------------------------------------------------------------
"""

from enum import Enum

class BaseEnum(Enum):
    @classmethod
    def list(cls):
        return list(cls)

# Enum for selecting the Ansatz circuits
class Ansatzs(BaseEnum):
    ALL = 1
    HCZRX = 2
    TREE_TENSOR = 3
    TWO_LOCAL = 4
    HARDWARE_EFFICIENT = 5
    ANNULAR = 6

# Enum for selecting the Embedding circuits
class Embedding(BaseEnum):
    ALL = 1
    RX = 2
    RZ = 3
    RY = 4
    ZZ = 5
    AMP = 6
    DENSE_ANGLE = 7
    HIGHER_ORDER = 8

# Enum for selecting the Models 
class Model(BaseEnum):
    ALL      = 1
    QKNN     = 2
    QNN      = 3
    QNNBAG   = 4
    QSVM     = 5
    FastQKNN = 6
    FastQSVM = 7
    MPSQKNN  = 8
    MPSQNN   = 9
    MPSQSVM  = 10


class Backend(BaseEnum):
    defaultQubit    = "default.qubit"
    lightningQubit  = "lightning.qubit"
    lightningGPU    = "lightning.gpu"
    defaultTensor   = "default.tensor"
    lightningTensor = "lightning.tensor"