"""
Product configuration template for HieraChain.

This module provides the default Product configuration template as a Python string,
ensuring it works both in development and when installed as a pip package.
"""

# Product configuration template for .env.HRC.example
PRODUCT_CONFIG_TEMPLATE = """# === HieraChain Product Auto-Configuration ===
# Auto-generated for production environment
# Copy this content to .env and customize as needed

# Environment
HRC_ENV=product

# API Settings
HRC_API_HOST=0.0.0.0
HRC_API_PORT=2661

# ==================== DATABASE CONFIGURATION ====================
# Supported backends: sqlite, postgres, mysql, memory
# Default: sqlite (for development ease)
# For production, recommended: postgres or mysql

# Database Backend (uncomment and modify as needed)
# HRC_STORAGE_BACKEND=sqlite
# HRC_DATABASE_URL=sqlite:///hierachain.db

# Example: PostgreSQL (uncomment and modify)
# HRC_STORAGE_BACKEND=postgres
# HRC_DATABASE_URL=postgresql://user:password@localhost:5432/hierachain

# Example: MySQL (uncomment and modify)
# HRC_STORAGE_BACKEND=mysql
# HRC_DATABASE_URL=mysql://user:password@localhost:3306/hierachain

# Example: Redis (uncomment and modify)
# HRC_STORAGE_BACKEND=redis
# REDIS_HOST=localhost
# REDIS_PORT=6379
# REDIS_DB=0

# ==================== END DATABASE CONFIGURATION ====================

# Security - Authentication (MANDATORY in production)
HRC_AUTH_ENABLED=true

# Security - CORS (Restricted in production)
HRC_CORS_ALLOW_ALL=false
HRC_CORS_ORIGINS=

# Security - P2P Network
HRC_P2P_TRUST_POLICY=strict
HRC_P2P_REQUIRE_SIGNATURES=true

# Security - HTTPS/HSTS
HRC_HSTS_ENABLED=true

# Security - Rate Limiting
HRC_RATE_LIMIT=true
HRC_RATE_LIMIT_RPM=100

# Storage Backend (Optional - uncomment and configure for production)
# HRC_STORAGE_BACKEND=redis
# REDIS_HOST=localhost
# REDIS_PORT=6379
# REDIS_DB=0

# Default: SQLite (for development)
HRC_DATABASE_URL=sqlite:///hierachain.db

# Master Key Management (Env-based in production)
HRC_MASTER_KEY_SOURCE=env

# ==================== IPFS STORAGE CONFIGURATION ====================
# Enable IPFS for off-chain storage of large payloads
HRC_IPFS_ENABLED=false

# IPFS Daemon API Address (multiaddr format)
HRC_IPFS_HOST=/ip4/127.0.0.1/tcp/5001

# Automatic Pinning to prevent garbage collection
HRC_IPFS_AUTO_PIN=true

# IPFS Request Timeout (seconds)
HRC_IPFS_TIMEOUT=120

# Encryption Key (32-byte hex) - CRITICAL: Must be the same for all nodes in Channel/Org
# Generate with: python -c "import os; print(os.urandom(32).hex())"
HRC_IPFS_ENCRYPTION_KEY=
# ==================== END IPFS CONFIGURATION ====================

# Logging - Less verbose in production
LOG_LEVEL=WARNING
HRC_LOG_SQL_DETAIL=false
"""
