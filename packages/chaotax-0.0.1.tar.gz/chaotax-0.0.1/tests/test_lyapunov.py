import jax
import jax.numpy as jnp
import pytest

from chaotax import lyapunov


def test_linear_expanding_map():
    A = jnp.array([[2.0, 0.0], [0.0, 1.5]])
    spectral_radius = 2.0

    def stepper(x):
        return A @ x

    compute = lyapunov(stepper, rollout_steps=5000, warmup_steps=0, discard_steps=0)
    u_0 = jnp.array([1.0, 0.0])
    result = compute(u_0, key=jax.random.PRNGKey(0))
    assert jnp.allclose(result, jnp.log(spectral_radius), atol=0.05)


def test_linear_contracting_map():
    A = jnp.array([[0.5, 0.0], [0.0, 0.3]])

    def stepper(x):
        return A @ x

    compute = lyapunov(stepper, rollout_steps=5000, warmup_steps=0, discard_steps=0)
    u_0 = jnp.array([1.0, 0.0])
    result = compute(u_0, key=jax.random.PRNGKey(0))
    assert result < 0


def test_error_both_noise_and_key():
    def stepper(x):
        return x

    compute = lyapunov(stepper, rollout_steps=10, warmup_steps=0, discard_steps=0)
    u_0 = jnp.array([1.0])
    noise = jnp.array([0.1])
    with pytest.raises(ValueError):
        compute(u_0, noise, key=jax.random.PRNGKey(0))


def test_error_neither_noise_nor_key():
    def stepper(x):
        return x

    compute = lyapunov(stepper, rollout_steps=10, warmup_steps=0, discard_steps=0)
    u_0 = jnp.array([1.0])
    with pytest.raises(ValueError):
        compute(u_0)
