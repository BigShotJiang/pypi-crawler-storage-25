import equinox as eqx
import jax
import jax.numpy as jnp

from chaotax import lyapunov, lyapunov_spectrum


class LinearStepper(eqx.Module):
    matrix: jax.Array

    def __call__(self, x):
        return self.matrix @ x


def test_vmap_lyapunov_over_steppers():
    matrices = jnp.array(
        [
            [[0.9, 0.0], [0.0, 0.8]],
            [[2.0, 0.0], [0.0, 1.5]],
        ]
    )

    steppers = eqx.filter_vmap(lambda m: LinearStepper(matrix=m))(matrices)

    exponents = eqx.filter_vmap(
        lambda stepper: lyapunov(
            stepper, rollout_steps=500, warmup_steps=0, discard_steps=0
        )(jnp.array([1.0, 0.0]), key=jax.random.key(0))
    )(steppers)

    assert exponents.shape == (2,)
    # First stepper is contracting (spectral radius 0.9 < 1)
    assert exponents[0] < 0
    # Second stepper is expanding (spectral radius 2.0 > 1)
    assert exponents[1] > 0
    assert jnp.allclose(exponents[1], jnp.log(2.0), atol=0.05)


def test_vmap_lyapunov_spectrum_over_steppers():
    matrices = jnp.array(
        [
            [[3.0, 0.0], [0.0, 0.5]],
            [[0.4, 0.0], [0.0, 0.2]],
        ]
    )

    steppers = eqx.filter_vmap(lambda m: LinearStepper(matrix=m))(matrices)

    spectra = eqx.filter_vmap(
        lambda stepper: lyapunov_spectrum(
            stepper, rollout_steps=500, warmup_steps=0, discard_steps=0
        )(jnp.array([1.0, 1.0]), key=jax.random.key(0))
    )(steppers)

    assert spectra.shape == (2, 2)

    # First stepper: eigenvalues 3.0 and 0.5
    expected_0 = jnp.sort(jnp.log(jnp.array([3.0, 0.5])))[::-1]
    assert jnp.allclose(spectra[0], expected_0, atol=0.05)

    # Second stepper: eigenvalues 0.4 and 0.2 (both contracting)
    expected_1 = jnp.sort(jnp.log(jnp.array([0.4, 0.2])))[::-1]
    assert jnp.allclose(spectra[1], expected_1, atol=0.05)


def test_vmap_lyapunov_over_initial_conditions():
    A = jnp.array([[2.0, 0.0], [0.0, 1.5]])
    stepper = LinearStepper(matrix=A)

    compute = lyapunov(stepper, rollout_steps=500, warmup_steps=0, discard_steps=0)

    u_0s = jax.random.normal(jax.random.key(0), (5, 2))
    keys = jax.random.split(jax.random.key(1), 5)

    exponents = jax.vmap(compute)(u_0s, key=keys)

    assert exponents.shape == (5,)
    # All should converge to the same largest exponent
    assert jnp.allclose(exponents, jnp.log(2.0), atol=0.05)


def test_vmap_lyapunov_spectrum_over_initial_conditions():
    A = jnp.array([[3.0, 0.0], [0.0, 0.5]])
    stepper = LinearStepper(matrix=A)

    compute = lyapunov_spectrum(
        stepper, rollout_steps=500, warmup_steps=0, discard_steps=0
    )

    u_0s = jax.random.normal(jax.random.key(0), (5, 2))
    keys = jax.random.split(jax.random.key(1), 5)

    spectra = jax.vmap(compute)(u_0s, key=keys)

    assert spectra.shape == (5, 2)
    expected = jnp.sort(jnp.log(jnp.array([3.0, 0.5])))[::-1]
    # All initial conditions should converge to the same spectrum
    for i in range(5):
        assert jnp.allclose(spectra[i], expected, atol=0.05)
