import jax
import jax.numpy as jnp
import pytest

from chaotax import lyapunov_spectrum


def test_linear_map_spectrum():
    A = jnp.array([[3.0, 0.0], [0.0, 0.5]])

    def stepper(x):
        return A @ x

    compute = lyapunov_spectrum(
        stepper, rollout_steps=5000, warmup_steps=0, discard_steps=0
    )
    u_0 = jnp.array([1.0, 1.0])
    noise_matrix = jax.random.normal(jax.random.PRNGKey(0), (2, 2))
    result = compute(u_0, noise_matrix)

    singular_values = jnp.linalg.svd(A, compute_uv=False)
    expected = jnp.sort(jnp.log(singular_values))[::-1]

    assert jnp.allclose(result, expected, atol=0.05)


def test_sum_rule():
    A = jnp.array([[3.0, 0.5], [0.0, 2.0]])

    def stepper(x):
        return A @ x

    compute = lyapunov_spectrum(
        stepper, rollout_steps=5000, warmup_steps=0, discard_steps=0
    )
    u_0 = jnp.array([1.0, 1.0])
    noise_matrix = jax.random.normal(jax.random.PRNGKey(0), (2, 2))
    result = compute(u_0, noise_matrix)

    expected_sum = jnp.log(jnp.abs(jnp.linalg.det(A)))
    assert jnp.allclose(jnp.sum(result), expected_sum, atol=0.1)


def test_error_both_noise_and_key():
    def stepper(x):
        return x

    compute = lyapunov_spectrum(
        stepper, rollout_steps=10, warmup_steps=0, discard_steps=0
    )
    u_0 = jnp.array([1.0])
    noise = jnp.array([0.1])
    with pytest.raises(ValueError):
        compute(u_0, noise, key=jax.random.PRNGKey(0))


def test_error_incorrect_noise_shape():
    def stepper(x):
        return x

    compute = lyapunov_spectrum(
        stepper, rollout_steps=10, warmup_steps=0, discard_steps=0
    )
    u_0 = jnp.array([1.0, 2.0])
    noise = jnp.array([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]])
    with pytest.raises(ValueError):
        compute(u_0, noise)
