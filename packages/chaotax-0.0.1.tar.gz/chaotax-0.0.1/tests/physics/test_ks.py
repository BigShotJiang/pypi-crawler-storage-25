import exponax as ex
import jax

import chaotax

NUM_POINTS = 64
DT = 0.1


def _make_stepper():
    return ex.stepper.KuramotoSivashinskyConservative(1, 60.0, NUM_POINTS, DT)


def test_max_exponent_positive():
    stepper = _make_stepper()
    u0 = jax.random.normal(jax.random.PRNGKey(1), (1, stepper.num_points))
    result = chaotax.lyapunov(
        stepper,
        rollout_steps=5000,
        warmup_steps=500,
        discard_steps=500,
        dt=DT,
    )(u0, key=jax.random.PRNGKey(0))
    assert float(result) > 0.0
