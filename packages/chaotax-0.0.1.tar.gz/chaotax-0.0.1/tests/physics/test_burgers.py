import exponax as ex
import jax
import jax.numpy as jnp
import pytest

import chaotax

NUM_POINTS = 32
DT = 0.1


def _make_stepper():
    return ex.stepper.Burgers(1, 1.0, NUM_POINTS, DT)


def _make_ic(stepper, seed=0):
    return ex.ic.RandomTruncatedFourierSeries(1, max_one=True)(
        stepper.num_points, key=jax.random.PRNGKey(seed)
    )


def test_max_exponent_non_positive():
    stepper = _make_stepper()
    u0 = _make_ic(stepper)
    result = chaotax.lyapunov(
        stepper,
        rollout_steps=500,
        warmup_steps=100,
        discard_steps=50,
        dt=DT,
    )(u0, key=jax.random.PRNGKey(1))
    assert float(result) <= 0.01


def test_spectrum_one_zero_rest_negative():
    stepper = _make_stepper()
    u0 = _make_ic(stepper)
    spectrum = chaotax.lyapunov_spectrum(
        stepper,
        rollout_steps=500,
        warmup_steps=100,
        discard_steps=50,
        dt=DT,
    )(u0, key=jax.random.PRNGKey(1))
    # Leading exponent is zero (translation invariance)
    assert float(spectrum[0]) == pytest.approx(0.0, abs=0.01)
    # All remaining exponents are strictly negative (diffusive)
    assert bool(jnp.all(spectrum[1:] < -0.1))
