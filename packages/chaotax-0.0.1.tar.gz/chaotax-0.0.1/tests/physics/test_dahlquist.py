import jax
import jax.numpy as jnp
import pytest

import chaotax

from .conftest import DT, rk4_step

LAMBDA = -0.5


def _rhs(state):
    return LAMBDA * state


def _stepper(state):
    return rk4_step(_rhs, state, DT)


def test_negative_exponent():
    u0 = jnp.array([1.0])
    estimate = chaotax.lyapunov(
        _stepper,
        rollout_steps=20_000,
        warmup_steps=0,
        discard_steps=0,
        dt=DT,
    )
    result = estimate(u0, key=jax.random.PRNGKey(0))
    assert result == pytest.approx(LAMBDA, abs=0.01)
