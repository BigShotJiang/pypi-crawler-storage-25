import jax
import jax.numpy as jnp
import pytest

import chaotax

from .conftest import DT, rk4_step

SIGMA = 10.0
RHO = 28.0
BETA = 8.0 / 3.0


def _rhs(state):
    x, y, z = state
    return jnp.array([SIGMA * (y - x), x * (RHO - z) - y, x * y - BETA * z])


def _stepper(state):
    return rk4_step(_rhs, state, DT)


def test_max_exponent():
    u0 = jnp.array([1.0, 1.0, 1.0])
    estimate = chaotax.lyapunov(
        _stepper,
        rollout_steps=50_000,
        warmup_steps=500,
        discard_steps=1000,
        dt=DT,
    )
    result = estimate(u0, key=jax.random.PRNGKey(0))
    assert result == pytest.approx(0.9056, abs=0.05)


def test_spectrum():
    u0 = jnp.array([1.0, 1.0, 1.0])
    estimate = chaotax.lyapunov_spectrum(
        _stepper,
        rollout_steps=50_000,
        warmup_steps=500,
        discard_steps=1000,
        dt=DT,
    )
    spectrum = estimate(u0, key=jax.random.PRNGKey(0))
    lam1, lam2, lam3 = float(spectrum[0]), float(spectrum[1]), float(spectrum[2])
    assert lam1 == pytest.approx(0.91, abs=0.05)
    assert lam2 == pytest.approx(0.0, abs=0.1)
    assert lam3 == pytest.approx(-14.57, abs=0.2)


def test_partial_spectrum():
    u0 = jnp.array([1.0, 1.0, 1.0])
    estimate = chaotax.lyapunov_spectrum(
        _stepper,
        rollout_steps=50_000,
        warmup_steps=500,
        discard_steps=1000,
        dt=DT,
        num_exponents=2,
    )
    spectrum = estimate(u0, key=jax.random.PRNGKey(0))
    assert spectrum.shape == (2,)
    assert float(spectrum[0]) == pytest.approx(0.91, abs=0.05)
    assert float(spectrum[1]) == pytest.approx(0.0, abs=0.1)
