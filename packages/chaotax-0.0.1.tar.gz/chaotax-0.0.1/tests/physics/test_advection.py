import exponax as ex
import jax
import pytest

import chaotax

NUM_POINTS = 32
DT = 0.1


def _make_stepper():
    return ex.stepper.Advection(1, 1.0, NUM_POINTS, DT)


def _make_ic(stepper, seed=0):
    return ex.ic.RandomTruncatedFourierSeries(1, max_one=True)(
        stepper.num_points, key=jax.random.PRNGKey(seed)
    )


def test_max_exponent_zero():
    stepper = _make_stepper()
    u0 = _make_ic(stepper)
    result = chaotax.lyapunov(
        stepper,
        rollout_steps=500,
        warmup_steps=0,
        discard_steps=50,
        dt=DT,
    )(u0, key=jax.random.PRNGKey(1))
    assert result == pytest.approx(0.0, abs=0.01)


def test_spectrum_all_zero():
    stepper = _make_stepper()
    u0 = _make_ic(stepper)
    spectrum = chaotax.lyapunov_spectrum(
        stepper,
        rollout_steps=500,
        warmup_steps=0,
        discard_steps=50,
        dt=DT,
    )(u0, key=jax.random.PRNGKey(1))
    # The last exponent corresponds to the Nyquist mode which the spectral
    # method damps numerically, so we exclude it.
    for i in range(len(spectrum) - 1):
        assert float(spectrum[i]) == pytest.approx(0.0, abs=0.01)
