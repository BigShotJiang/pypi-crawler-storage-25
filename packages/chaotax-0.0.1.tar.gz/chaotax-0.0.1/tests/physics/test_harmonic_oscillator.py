import jax
import jax.numpy as jnp
import pytest

import chaotax

from .conftest import DT, rk4_step


def _rhs(state):
    x, v = state
    return jnp.array([v, -x])


def _stepper(state):
    return rk4_step(_rhs, state, DT)


def test_zero_spectrum():
    u0 = jnp.array([1.0, 0.0])
    estimate = chaotax.lyapunov_spectrum(
        _stepper,
        rollout_steps=50_000,
        warmup_steps=500,
        discard_steps=1000,
        dt=DT,
    )
    spectrum = estimate(u0, key=jax.random.PRNGKey(0))
    assert float(spectrum[0]) == pytest.approx(0.0, abs=0.01)
    assert float(spectrum[1]) == pytest.approx(0.0, abs=0.01)
