import pytest


def rk4_step(rhs, state, dt):
    """Single RK4 integration step."""
    k1 = rhs(state)
    k2 = rhs(state + 0.5 * dt * k1)
    k3 = rhs(state + 0.5 * dt * k2)
    k4 = rhs(state + dt * k3)
    return state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


DT = 0.01


@pytest.fixture()
def dt():
    return DT
