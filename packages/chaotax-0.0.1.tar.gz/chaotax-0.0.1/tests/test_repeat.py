import jax.numpy as jnp

from chaotax import repeat


def test_identity_stepper():
    def f(x):
        return x

    x = jnp.array([1.0, 2.0, 3.0])
    result = repeat(f, 10)(x)
    assert jnp.allclose(result, x)


def test_linear_stepper():
    def f(x):
        return 2.0 * x

    x = jnp.array(1.0)
    for n in [1, 2, 5]:
        result = repeat(f, n)(x)
        expected = 2.0**n * x
        assert jnp.allclose(result, expected), f"n={n}: {result} != {expected}"


def test_n_zero():
    def f(x):
        return 100.0 * x

    x = jnp.array([5.0, 6.0])
    result = repeat(f, 0)(x)
    assert jnp.allclose(result, x)
