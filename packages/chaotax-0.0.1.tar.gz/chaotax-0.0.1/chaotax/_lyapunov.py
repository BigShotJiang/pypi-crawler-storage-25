from collections.abc import Callable

import jax
import jax.numpy as jnp
from jaxtyping import Float, Inexact, PRNGKeyArray

from ._temporal_utils import repeat


def rollout_growth(
    stepper: Callable[
        [Inexact[jax.Array, "*state_shape"]], Inexact[jax.Array, "*state_shape"]
    ],
    n: int,
) -> Callable[
    [Inexact[jax.Array, "*state_shape"], Inexact[jax.Array, "*state_shape"]],
    Float[jax.Array, " n"],
]:
    """Compute per-step tangent growth factors along a trajectory.

    Rolls out the stepper for ``n`` steps while tracking how an initial
    perturbation vector grows under the linearised dynamics (via JVP).
    The perturbation is re-normalised after each step.

    Args:
        stepper: One-step state transition function.
        n: Number of rollout steps.

    Returns:
        A function ``(u_0, eps_0) -> growth`` that returns the growth factor
        at each step.
    """

    def scan_fn(
        carry: tuple[
            Inexact[jax.Array, "*state_shape"], Inexact[jax.Array, "*state_shape"]
        ],
        _: None,
    ) -> tuple[
        tuple[Inexact[jax.Array, "*state_shape"], Inexact[jax.Array, "*state_shape"]],
        Float[jax.Array, ""],
    ]:
        u, eps = carry
        u_next, eps_next = jax.jvp(stepper, (u,), (eps,))

        growth = jnp.linalg.norm(eps_next)
        eps_next_normalized = eps_next / growth

        carry_next = (u_next, eps_next_normalized)

        return carry_next, growth

    def rollout_with_growth_fn(
        u_0: Inexact[jax.Array, "*state_shape"],
        eps_0: Inexact[jax.Array, "*state_shape"],
    ) -> Float[jax.Array, " n"]:
        initial_carry = (u_0, eps_0 / jnp.linalg.norm(eps_0))

        _, growth_trj = jax.lax.scan(scan_fn, initial_carry, None, length=n)

        return growth_trj

    return rollout_with_growth_fn


def lyapunov(
    stepper: Callable[
        [Inexact[jax.Array, "*state_shape"]], Inexact[jax.Array, "*state_shape"]
    ],
    *,
    rollout_steps: int = 20_000,
    warmup_steps: int = 500,
    discard_steps: int = 1000,
    dt: float = 1,
) -> Callable[
    [Inexact[jax.Array, "*state_shape"], Inexact[jax.Array, "*state_shape"]],
    Float[jax.Array, ""],
]:
    """Estimate the largest Lyapunov exponent of a dynamical system."""

    def lorenz_computing(
        u_0: Inexact[jax.Array, "*state_shape"],
        noise: Inexact[jax.Array, "*state_shape"] | None = None,
        *,
        key: PRNGKeyArray | None = None,
    ):
        if noise is None:
            if key is None:
                raise ValueError("Either noise or key must be provided.")
            noise = jax.random.normal(key, shape=u_0.shape)
        else:
            if key is not None:
                raise ValueError("Provide either noise or key, not both.")

        u_0_warmed = repeat(stepper, warmup_steps)(u_0)
        growth_trj = rollout_growth(stepper, rollout_steps + discard_steps)(
            u_0_warmed,
            noise,
        )
        log_growth_trj = jnp.log(growth_trj)
        log_growth_trj_crop = log_growth_trj[discard_steps:]
        return jnp.mean(log_growth_trj_crop) / dt

    return lorenz_computing


def rollout_growth_spectrum(
    stepper: Callable[
        [Inexact[jax.Array, "*state_shape"]], Inexact[jax.Array, "*state_shape"]
    ],
    n: int,
) -> Callable[
    [
        Inexact[jax.Array, "*state_shape"],
        Inexact[jax.Array, " n_dof *state_shape"],
    ],
    Float[jax.Array, " n n_dof"],
]:
    """Compute per-step growth factors for a set of perturbation vectors.

    Like :func:`rollout_growth`, but tracks a matrix of perturbation
    directions simultaneously using QR re-orthonormalisation at each step.
    The perturbation matrix may have fewer rows than ``n_dof`` to compute
    only the leading exponents (cost per step is ``O(n_dof * p)`` instead
    of ``O(n_dof²)`` for the full spectrum).

    Args:
        stepper: One-step state transition function.
        n: Number of rollout steps.

    Returns:
        A function ``(u_0, eps_matrix_0) -> growth`` where *growth* has shape
        ``(n, p)`` containing the diagonal R-factor at each step.
    """

    def rollout_with_growth_fn(
        u_0: Inexact[jax.Array, "*state_shape"],
        eps_matrix_0: Inexact[jax.Array, " p *state_shape"],
    ) -> Float[jax.Array, " n p"]:
        shape = u_0.shape
        n_dof = jnp.prod(jnp.array(shape))
        p = eps_matrix_0.shape[0]
        eps_matrix_0 = eps_matrix_0.reshape((p, n_dof))
        u_0 = u_0.reshape((n_dof,))

        def scan_fn(
            carry: tuple[
                Inexact[jax.Array, " n_dof"],
                Inexact[jax.Array, " p n_dof"],
            ],
            _: None,
        ) -> tuple[
            tuple[
                Inexact[jax.Array, " n_dof"],
                Inexact[jax.Array, " p n_dof"],
            ],
            Float[jax.Array, " p"],
        ]:
            u_flat, du_matrix_flat = carry
            u = u_flat.reshape(shape)
            du_matrix_semi_flat = du_matrix_flat.reshape((p, *shape))

            u_next, jvp_fn = jax.linearize(stepper, u)

            du_matrix_next_semi_flat = jax.vmap(jvp_fn)(du_matrix_semi_flat)

            # Need transposition because `du_matrix` is of format (lyapunov_dim,
            # state_dim) while we want to perform QR decomposition on the state_dim
            q, r = jnp.linalg.qr(du_matrix_next_semi_flat.reshape((p, n_dof)).T)
            q = q.T  # Transpose back for consistent row-wise perturbations

            # Growth factors are the diagonal elements of the R matrix
            growth = jnp.diag(r)
            du_matrix_next_flat_normalized = q

            u_next_flat = u_next.reshape((n_dof,))

            return (u_next_flat, du_matrix_next_flat_normalized), growth

        q, _ = jnp.linalg.qr(eps_matrix_0.T)

        initial_carry = (u_0, q.T)

        _, growth_trj = jax.lax.scan(scan_fn, initial_carry, None, length=n)

        return growth_trj

    return rollout_with_growth_fn


def lyapunov_spectrum(
    stepper: Callable[
        [Inexact[jax.Array, "*state_shape"]], Inexact[jax.Array, "*state_shape"]
    ],
    *,
    rollout_steps: int = 20_000,
    warmup_steps: int = 500,
    discard_steps: int = 1000,
    dt: float = 1,
    num_exponents: int | None = None,
) -> Callable[
    [
        Inexact[jax.Array, "*state_shape"],
        Inexact[jax.Array, " p *state_shape"] | None,
    ],
    Float[jax.Array, " p"],
]:
    """Estimate the Lyapunov spectrum of a dynamical system.

    Returns a callable that computes Lyapunov exponents (in descending
    order) by tracking a matrix of perturbation vectors with QR
    re-orthonormalisation. When ``num_exponents`` is smaller than the
    number of degrees of freedom, only the leading exponents are
    computed at reduced cost (``O(n_dof * num_exponents)`` per step
    instead of ``O(n_dof²)``).
    """

    def lorenz_spectrum_computing(
        u_0: Inexact[jax.Array, "*state_shape"],
        noise_matrix: Inexact[jax.Array, " p *state_shape"] | None = None,
        *,
        key: PRNGKeyArray | None = None,
    ) -> Float[jax.Array, " p"]:
        p = num_exponents if num_exponents is not None else u_0.size
        noise_shape = (p, *u_0.shape)

        if noise_matrix is None:
            if key is None:
                raise ValueError("Either noise_matrix or key must be provided.")
            noise_matrix = jax.random.normal(key, noise_shape)
        else:
            if key is not None:
                raise ValueError("Provide either noise_matrix or key, not both.")
            if noise_matrix.shape != noise_shape:
                raise ValueError(
                    f"noise_matrix has shape {noise_matrix.shape}, "
                    f"but expected {noise_shape}."
                )
        u_0_warmed = repeat(stepper, warmup_steps)(u_0)
        growth_trj = rollout_growth_spectrum(stepper, rollout_steps + discard_steps)(
            u_0_warmed,
            noise_matrix,
        )
        log_growth_trj = jnp.log(jnp.abs(growth_trj))
        log_growth_trj_crop = log_growth_trj[discard_steps:]
        return jnp.mean(log_growth_trj_crop, axis=0) / dt

    return lorenz_spectrum_computing
