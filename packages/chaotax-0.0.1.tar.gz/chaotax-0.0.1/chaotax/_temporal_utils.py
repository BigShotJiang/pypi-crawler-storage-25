from collections.abc import Callable

import jax
from jaxtyping import PyTree, Shaped


def repeat(
    stepper: Callable[
        [PyTree[Shaped[jax.Array, "?leaf_shape"], " T"]],
        PyTree[Shaped[jax.Array, "?leaf_shape"], " T"],
    ],
    n: int,
) -> Callable[
    [PyTree[Shaped[jax.Array, "?leaf_shape"], " T"]],
    PyTree[Shaped[jax.Array, "?leaf_shape"], " T"],
]:
    """Repeat application of a stepper function n times.

    Args:
        stepper: A function that takes in the current state and returns the next state.
        n: Number of times to apply the stepper function.

    Returns:
        A function that takes in the initial state and returns the state
        after n applications of the stepper.
    """

    def scan_fn(u, _):
        u_next = stepper(u)
        return u_next, u_next

    def repeat_stepper_fn(u_0):
        u_n, _ = jax.lax.scan(scan_fn, u_0, None, length=n)
        return u_n

    return repeat_stepper_fn
