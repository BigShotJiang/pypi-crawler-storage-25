Getting Started
===============

Installation
------------

.. code-block:: bash

   pip install chaotax

Quick Start
-----------

Estimate the largest Lyapunov exponent of any stepper function:

.. code-block:: python

   import jax
   import chaotax

   exponent = chaotax.lyapunov(stepper)(
       u_0,
       key=jax.random.key(0),
   )


