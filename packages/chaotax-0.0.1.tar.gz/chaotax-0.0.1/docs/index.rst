.. image:: _static/logo.svg
   :align: center
   :width: 200px

chaotax
=======

**Measure chaos in dynamical systems with JAX.**

* Differentiable, JIT-compatible, vectorizable Lyapunov exponent computation
* Full spectrum via QR decomposition
* Efficient implementation via forward-mode automatic differentiation
* Works with any JAX-compatible stepper function

.. code-block:: bash

   pip install chaotax

.. code-block:: python

   import jax, chaotax

   exponent = chaotax.lyapunov(stepper)(u_0, key=jax.random.key(0))

.. toctree::
   :hidden:

   getting_started
   api
