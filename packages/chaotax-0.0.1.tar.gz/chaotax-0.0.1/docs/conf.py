project = "chaotax"
version = "0.1.0"
author = "chaotax contributors"

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.intersphinx",
    "sphinx.ext.viewcode",
    "sphinx.ext.todo",
    "sphinx_autodoc_typehints",
    "nbsphinx",
]

todo_include_todos = True

exclude_patterns = ["_build", "**.ipynb_checkpoints"]

nbsphinx_execute = "always"

html_theme = "furo"
html_static_path = ["_static"]
html_logo = "_static/logo.svg"
html_favicon = "_static/logo.svg"
html_theme_options = {
    "source_repository": "https://github.com/Ceyron/chaotax-new",
    "source_branch": "main",
    "source_directory": "docs/",
}

intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "jax": ("https://jax.readthedocs.io/en/latest/", None),
    "numpy": ("https://numpy.org/doc/stable/", None),
}

autodoc_member_order = "bysource"
autodoc_typehints = "description"
always_use_bars_union = True
