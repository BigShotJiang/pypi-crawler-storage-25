"""Compatibility re-exports for external graph helpers."""

from daylily_tapdb.services.external_refs import (
    ALLOWED_AUTH_MODES,
    ExternalGraphRef,
    _apply_forwarded_auth,
    _require_http_url,
    external_ref_payloads,
    fetch_remote_graph,
    fetch_remote_object_detail,
    get_external_ref_by_index,
    namespace_external_graph,
    resolve_external_graph_refs,
    urlopen,
)

__all__ = [
    "ALLOWED_AUTH_MODES",
    "ExternalGraphRef",
    "_apply_forwarded_auth",
    "_require_http_url",
    "external_ref_payloads",
    "fetch_remote_graph",
    "fetch_remote_object_detail",
    "get_external_ref_by_index",
    "namespace_external_graph",
    "resolve_external_graph_refs",
    "urlopen",
]
