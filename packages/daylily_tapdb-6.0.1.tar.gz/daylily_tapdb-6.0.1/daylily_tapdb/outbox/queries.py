"""Admin query helpers for outbox and inbox observability.

All functions accept an active SQLAlchemy session and return lightweight
result objects. No mutations are performed.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.outbox import (
    inbox_message,
    outbox_event,
    outbox_event_attempt,
)


@dataclass(frozen=True, slots=True)
class OutboxStatusSummary:
    """Aggregate counts by status for outbox_event."""

    pending: int = 0
    delivering: int = 0
    received: int = 0
    processed: int = 0
    failed: int = 0
    dead_letter: int = 0
    rejected: int = 0
    canceled: int = 0


def outbox_status_summary(
    session: Session,
    *,
    domain_code: str | None = None,
    issuer_app_code: str | None = None,
) -> OutboxStatusSummary:
    """Return aggregate counts of outbox events by status."""
    q = select(
        outbox_event.status,
        func.count().label("cnt"),
    ).group_by(outbox_event.status)
    if domain_code is not None:
        q = q.where(outbox_event.domain_code == domain_code)
    if issuer_app_code is not None:
        q = q.where(outbox_event.issuer_app_code == issuer_app_code)

    rows = {r.status: r.cnt for r in session.execute(q).all()}
    return OutboxStatusSummary(
        **{k: rows.get(k, 0) for k in OutboxStatusSummary.__dataclass_fields__}
    )


def list_failed_events(
    session: Session,
    *,
    domain_code: str | None = None,
    issuer_app_code: str | None = None,
    limit: int = 100,
) -> list[outbox_event]:
    """List outbox events in failed or dead_letter status."""
    q = (
        select(outbox_event)
        .where(outbox_event.status.in_(("failed", "dead_letter")))
        .order_by(outbox_event.last_attempt_dt.desc().nullslast())
        .limit(limit)
    )
    if domain_code is not None:
        q = q.where(outbox_event.domain_code == domain_code)
    if issuer_app_code is not None:
        q = q.where(outbox_event.issuer_app_code == issuer_app_code)
    return list(session.execute(q).scalars().all())


def list_stale_delivering(
    session: Session,
    *,
    domain_code: str | None = None,
    limit: int = 100,
) -> list[outbox_event]:
    """List events stuck in 'delivering' past their lease expiry."""
    q = (
        select(outbox_event)
        .where(
            outbox_event.status == "delivering",
            outbox_event.lease_expires_dt < func.now(),
        )
        .order_by(outbox_event.claimed_dt.asc().nullslast())
        .limit(limit)
    )
    if domain_code is not None:
        q = q.where(outbox_event.domain_code == domain_code)
    return list(session.execute(q).scalars().all())


def get_event_attempts(
    session: Session,
    outbox_event_id: int,
) -> list[outbox_event_attempt]:
    """Return all delivery attempts for a given outbox event."""
    q = (
        select(outbox_event_attempt)
        .where(outbox_event_attempt.outbox_event_id == outbox_event_id)
        .order_by(outbox_event_attempt.attempt_no.asc())
    )
    return list(session.execute(q).scalars().all())


@dataclass(frozen=True, slots=True)
class InboxStatusSummary:
    """Aggregate counts by status for inbox_message."""

    received: int = 0
    processing: int = 0
    processed: int = 0
    failed: int = 0
    rejected: int = 0


def inbox_status_summary(
    session: Session,
    *,
    domain_code: str | None = None,
    issuer_app_code: str | None = None,
) -> InboxStatusSummary:
    """Return aggregate counts of inbox messages by status."""
    q = select(
        inbox_message.status,
        func.count().label("cnt"),
    ).group_by(inbox_message.status)
    if domain_code is not None:
        q = q.where(inbox_message.domain_code == domain_code)
    if issuer_app_code is not None:
        q = q.where(inbox_message.issuer_app_code == issuer_app_code)

    rows = {r.status: r.cnt for r in session.execute(q).all()}
    return InboxStatusSummary(
        **{k: rows.get(k, 0) for k in InboxStatusSummary.__dataclass_fields__}
    )


def list_events_by_destination(
    session: Session,
    destination: str,
    *,
    domain_code: str | None = None,
    issuer_app_code: str | None = None,
    status: str | None = None,
    limit: int = 100,
) -> list[outbox_event]:
    """List outbox events for a given destination, optionally filtered by status."""
    q = select(outbox_event).where(outbox_event.destination == destination)
    if domain_code is not None:
        q = q.where(outbox_event.domain_code == domain_code)
    if issuer_app_code is not None:
        q = q.where(outbox_event.issuer_app_code == issuer_app_code)
    if status is not None:
        q = q.where(outbox_event.status == status)
    q = q.order_by(outbox_event.created_dt.desc()).limit(limit)
    return list(session.execute(q).scalars().all())


def list_by_destination(
    session: Session,
    destination: str,
    *,
    domain_code: str | None = None,
    issuer_app_code: str | None = None,
    status: str | None = None,
    limit: int = 100,
) -> list[outbox_event]:
    """Spec-compatible alias for ``list_events_by_destination``."""
    return list_events_by_destination(
        session,
        destination,
        domain_code=domain_code,
        issuer_app_code=issuer_app_code,
        status=status,
        limit=limit,
    )


def get_outbox_event_by_receipt_uuid(
    session: Session,
    receipt_machine_uuid,
) -> outbox_event | None:
    """Look up an outbox event by its receipt_machine_uuid."""
    q = select(outbox_event).where(
        outbox_event.receipt_machine_uuid == receipt_machine_uuid
    )
    return session.execute(q).scalar_one_or_none()


def lookup_by_machine_uuid(
    session: Session,
    machine_uuid,
    *,
    domain_code: str | None = None,
    issuer_app_code: str | None = None,
) -> outbox_event | None:
    """Look up an outbox event by its canonical message machine_uuid."""
    q = (
        select(outbox_event)
        .join(generic_instance, outbox_event.message_uid == generic_instance.uid)
        .where(generic_instance.machine_uuid == machine_uuid)
    )
    if domain_code is not None:
        q = q.where(outbox_event.domain_code == domain_code)
    if issuer_app_code is not None:
        q = q.where(outbox_event.issuer_app_code == issuer_app_code)
    return session.execute(q).scalar_one_or_none()
