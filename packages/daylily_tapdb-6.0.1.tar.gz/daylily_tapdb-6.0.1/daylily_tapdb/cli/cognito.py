"""TAPDB Cognito integration commands.

Operational lifecycle is delegated to the daylily-auth-cognito CLI (`daycog`).
TAPDB stores only Cognito pool ID in tapdb config.
"""

from __future__ import annotations

import json
import os
import re
import stat
import subprocess
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

import typer
import yaml
from cli_core_yo import ccyo_out
from rich.console import Console

from daylily_tapdb import TAPDBConnection
from daylily_tapdb.cli.context import resolve_context
from daylily_tapdb.cli.db import Environment
from daylily_tapdb.cli.db_config import get_config_path, get_db_config_for_env
from daylily_tapdb.user_store import create_or_get

console = Console()
cognito_app = typer.Typer(help="Cognito auth integration commands (via daycog)")
config_app = typer.Typer(help="Daycog context utilities")
cognito_app.add_typer(config_app, name="config")
DEFAULT_COGNITO_CALLBACK_PORT = 8911
REQUIRED_COGNITO_CLIENT_NAME = "tapdb"


def _ui_pid_file_for_env(env: Environment) -> Path:
    ctx = resolve_context(
        require_keys=True,
        env_name=env.value,
    )
    return ctx.ui_dir(env.value) / "ui.pid"


def _split_uri_values(raw: str) -> list[str]:
    return [v for v in re.split(r"[,\s]+", raw.strip()) if v]


def _iter_cognito_uri_values(values: dict[str, str]) -> list[tuple[str, str]]:
    uri_keys = [
        "COGNITO_CALLBACK_URL",
        "COGNITO_LOGOUT_URL",
        "COGNITO_CALLBACK_URLS",
        "COGNITO_LOGOUT_URLS",
        "COGNITO_REDIRECT_URI",
        "COGNITO_REDIRECT_URIS",
        "COGNITO_POST_LOGOUT_REDIRECT_URI",
        "COGNITO_POST_LOGOUT_REDIRECT_URIS",
    ]

    pairs: list[tuple[str, str]] = []
    for key in uri_keys:
        raw = (values.get(key) or "").strip()
        if not raw:
            continue
        for uri in _split_uri_values(raw):
            pairs.append((key, uri))
    return pairs


def _detect_running_ui_port(env: Environment) -> tuple[Optional[int], str]:
    """Best-effort detection of current TAPDB UI port from PID command line."""
    ui_pid_file = _ui_pid_file_for_env(env)
    if not ui_pid_file.exists():
        return None, "ui not running"
    try:
        pid = int(ui_pid_file.read_text(encoding="utf-8").strip())
        os.kill(pid, 0)
    except Exception:
        return None, "ui pid missing/stale"

    try:
        proc = subprocess.run(
            ["ps", "-p", str(pid), "-o", "command="],
            capture_output=True,
            text=True,
            timeout=2,
        )
    except Exception:
        return None, "could not inspect ui process"
    if proc.returncode != 0:
        return None, "could not inspect ui process"

    cmd = (proc.stdout or "").strip()
    m = re.search(r"--port\s+(\d+)", cmd)
    if not m:
        return None, "ui process port not detected"
    return int(m.group(1)), "running ui process"


def _resolve_expected_ui_port(env: Environment) -> tuple[int, str]:
    cfg = get_db_config_for_env(env.value)
    configured = (cfg.get("ui_port") or "").strip()
    if configured.isdigit():
        return int(configured), f"config environments.{env.value}.ui_port"

    running_port, source = _detect_running_ui_port(env)
    if running_port is not None:
        return running_port, source

    return DEFAULT_COGNITO_CALLBACK_PORT, f"default ({source})"


def _validate_bound_cognito_uris(
    env: Environment,
    values: dict[str, str],
) -> tuple[int, str, list[str], list[str]]:
    """Validate Cognito URI fields against TAPDB UI HTTPS + local port rules."""
    expected_port, port_source = _resolve_expected_ui_port(env)
    uri_pairs = _iter_cognito_uri_values(values)
    if not uri_pairs:
        return expected_port, port_source, [], []

    local_hosts = {"localhost", "127.0.0.1", "::1"}
    errors: list[str] = []
    notices: list[str] = []

    for key, uri in uri_pairs:
        parsed = urlparse(uri)
        if not parsed.scheme or not parsed.netloc:
            errors.append(f"{key}: invalid URI: {uri}")
            continue

        scheme = parsed.scheme.lower()
        host = (parsed.hostname or "").lower()
        port = parsed.port
        if port is None:
            port = 443 if scheme == "https" else 80

        if scheme != "https":
            errors.append(f"{key}: must use https (got {scheme}): {uri}")
            continue

        # Enforce local callback/logout URI ports to match active TAPDB UI port.
        if host in local_hosts and port != expected_port:
            errors.append(
                f"{key}: port {port} does not match TAPDB UI port "
                f"{expected_port}: {uri}"
            )
            continue

        notices.append(f"{key}: {uri}")

    return expected_port, port_source, errors, notices


def _daycog_config_path() -> Path:
    return Path.home() / ".config" / "daycog" / "config.yaml"


def _sanitize_filename_part(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-") or "app"


def _default_pool_name(env: Environment) -> str:
    cfg = get_db_config_for_env(env.value)
    db_name = (cfg.get("database") or f"tapdb_{env.value}").strip()
    raw = f"tapdb-{db_name}-users"
    name = re.sub(r"[^a-zA-Z0-9-]+", "-", raw).strip("-").lower()
    return re.sub(r"-{2,}", "-", name)


def _parse_daycog_context_name(name: str) -> tuple[str, str, str]:
    match = re.match(
        r"^(?P<pool>.+)\.(?P<region>[a-z]{2}(?:-[a-z0-9]+)+-\d+)(?:\.(?P<app>.+))?$",
        name,
    )
    if not match:
        return "", "", ""
    return (
        (match.group("pool") or "").strip(),
        (match.group("region") or "").strip(),
        (match.group("app") or "").strip(),
    )


def _load_daycog_contexts() -> tuple[str, dict[str, dict[str, str]]]:
    path = _daycog_config_path()
    if not path.exists():
        raise RuntimeError(f"daycog config store not found: {path}")
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        raise RuntimeError(f"invalid daycog config store: {path}")
    active_name = str(raw.get("active_context") or "").strip()
    raw_contexts = raw.get("contexts") if isinstance(raw.get("contexts"), dict) else {}
    contexts: dict[str, dict[str, str]] = {}
    if isinstance(raw_contexts, dict):
        for name, values in raw_contexts.items():
            if not isinstance(values, dict):
                continue
            contexts[str(name)] = {
                str(key): str(value)
                for key, value in values.items()
                if value is not None
            }
    return active_name, contexts


def _score_daycog_context_match(
    name: str,
    values: dict[str, str],
    *,
    active_name: str = "",
    prefer_region: Optional[str] = None,
    prefer_client_name: Optional[str] = None,
) -> tuple[int, str]:
    """Return sort key for Daycog stored-context preference (higher score is better)."""
    score = 0
    region = (values.get("COGNITO_REGION") or values.get("AWS_REGION") or "").strip()
    client_name = (values.get("COGNITO_CLIENT_NAME") or "").strip()

    if name == active_name:
        score += 10

    pool_name, context_region, context_app = _parse_daycog_context_name(name)
    if pool_name and context_region and not context_app:
        score += 70
    elif pool_name and context_region and context_app:
        safe_client = _sanitize_filename_part(client_name)
        if context_app == safe_client:
            score += 60

    if prefer_region and region == prefer_region:
        score += 25
    if prefer_client_name and client_name == prefer_client_name:
        score += 15

    return (score, name)


def _find_pool_context_by_id(
    pool_id: str,
    *,
    prefer_region: Optional[str] = None,
    prefer_client_name: Optional[str] = None,
) -> tuple[str, dict[str, str]]:
    active_name, contexts = _load_daycog_contexts()
    matches: list[tuple[str, dict[str, str]]] = []
    for context_name, values in contexts.items():
        if (values.get("COGNITO_USER_POOL_ID") or "").strip() == pool_id:
            matches.append((context_name, values))

    if matches:
        matches.sort(
            key=lambda item: _score_daycog_context_match(
                item[0],
                item[1],
                active_name=active_name,
                prefer_region=prefer_region,
                prefer_client_name=prefer_client_name,
            ),
            reverse=True,
        )
        return matches[0]

    raise RuntimeError(
        f"No Daycog stored context maps to pool ID {pool_id}. "
        "Expected a Daycog context in "
        f"{_daycog_config_path()} with "
        f"COGNITO_USER_POOL_ID={pool_id}."
    )


def _validate_required_client_name(
    values: dict[str, str],
    *,
    context_label: str,
) -> str:
    actual = (values.get("COGNITO_CLIENT_NAME") or "").strip()
    if actual != REQUIRED_COGNITO_CLIENT_NAME:
        display = actual or "(missing)"
        raise RuntimeError(
            f"{context_label} must select Cognito app client name "
            f"'{REQUIRED_COGNITO_CLIENT_NAME}' (got: {display})."
        )
    return actual


def _resolve_daycog_pool_id_after_setup(
    *,
    pool_name: str,
    region: str,
    client_name: str,
) -> tuple[str, str]:
    """Resolve pool ID from the canonical Daycog YAML context store."""
    active_name, contexts = _load_daycog_contexts()
    pool_context_name = f"{pool_name}.{region}"
    app_context_name = f"{pool_name}.{region}.{_sanitize_filename_part(client_name)}"

    for context_name in [pool_context_name, app_context_name, active_name]:
        if not context_name:
            continue
        values = contexts.get(context_name) or {}
        pool_id = (values.get("COGNITO_USER_POOL_ID") or "").strip()
        if pool_id:
            return pool_id, context_name

    for context_name, values in sorted(contexts.items()):
        candidate_pool, candidate_region, _candidate_app = _parse_daycog_context_name(
            context_name
        )
        if candidate_pool != pool_name or candidate_region != region:
            continue
        pool_id = (values.get("COGNITO_USER_POOL_ID") or "").strip()
        if pool_id:
            return pool_id, context_name

    raise RuntimeError(
        "daycog setup completed but pool ID was not found in "
        f"{_daycog_config_path()} for pool {pool_name} ({region})."
    )


def _write_pool_id_to_tapdb_config(env: Environment, pool_id: str) -> Path:
    config_path = get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if config_path.exists():
        raw = config_path.read_text(encoding="utf-8")
        try:
            import yaml  # type: ignore

            existing = yaml.safe_load(raw) or {}
        except ModuleNotFoundError:
            existing = json.loads(raw) if raw.strip() else {}

    envs = existing.setdefault("environments", {})
    env_cfg = envs.setdefault(env.value, {})
    env_cfg["cognito_user_pool_id"] = pool_id
    try:
        ctx = resolve_context(require_keys=False, env_name=env.value)
    except RuntimeError:
        ctx = None
    if ctx:
        meta = existing.get("meta") if isinstance(existing, dict) else None
        existing["meta"] = {
            "config_version": 3,
            "client_id": ctx.client_id,
            "database_name": ctx.database_name,
            "owner_repo_name": str((meta or {}).get("owner_repo_name") or ""),
            "domain_registry_path": str((meta or {}).get("domain_registry_path") or ""),
            "prefix_ownership_registry_path": str(
                (meta or {}).get("prefix_ownership_registry_path") or ""
            ),
        }

    try:
        import yaml  # type: ignore

        config_path.write_text(
            yaml.dump(existing, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )
    except ModuleNotFoundError:
        config_path.write_text(json.dumps(existing, indent=2) + "\n", encoding="utf-8")

    os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    return config_path


def _run_daycog(args: list[str], env: Optional[dict[str, str]] = None) -> str:
    cmd = ["daycog", *args]
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env,
    )
    if result.returncode != 0:
        msg = (result.stdout + "\n" + result.stderr).strip()
        raise RuntimeError(msg or f"daycog failed ({result.returncode})")
    return (result.stdout or "").strip()


def _run_daycog_printing(args: list[str], env: Optional[dict[str, str]] = None) -> None:
    out = _run_daycog(args, env=env)
    if out:
        ccyo_out.print_text(out)


def _build_daycog_setup_args(
    *,
    command: str,
    selected_pool_name: str,
    region: str,
    domain_prefix: Optional[str],
    attach_domain: bool,
    port: int,
    callback_path: str,
    oauth_flows: str,
    scopes: str,
    idps: str,
    password_min_length: int,
    mfa: str,
    profile: Optional[str],
    client_name: Optional[str],
    callback_url: Optional[str],
    logout_url: Optional[str],
    autoprovision: bool,
    generate_secret: bool,
    require_uppercase: bool,
    require_lowercase: bool,
    require_numbers: bool,
    require_symbols: bool,
    tags: Optional[str],
) -> list[str]:
    path = callback_path if callback_path.startswith("/") else f"/{callback_path}"
    resolved_callback_url = callback_url or f"https://localhost:{port}{path}"
    resolved_logout_url = logout_url or f"https://localhost:{port}/"

    args = [
        command,
        "--name",
        selected_pool_name,
        "--region",
        region,
        "--port",
        str(port),
        "--callback-path",
        path,
        "--callback-url",
        resolved_callback_url,
        "--logout-url",
        resolved_logout_url,
        "--oauth-flows",
        oauth_flows,
        "--scopes",
        scopes,
        "--idp",
        idps,
        "--password-min-length",
        str(password_min_length),
        "--mfa",
        mfa,
    ]
    if domain_prefix:
        args.extend(["--domain-prefix", domain_prefix])
    if attach_domain:
        args.append("--attach-domain")
    else:
        args.append("--no-attach-domain")
    if profile:
        args.extend(["--profile", profile])
    if client_name:
        args.extend(["--client-name", client_name])
    if autoprovision:
        args.append("--autoprovision")
    if generate_secret:
        args.append("--generate-secret")
    if require_uppercase:
        args.append("--require-uppercase")
    else:
        args.append("--no-require-uppercase")
    if require_lowercase:
        args.append("--require-lowercase")
    else:
        args.append("--no-require-lowercase")
    if require_numbers:
        args.append("--require-numbers")
    else:
        args.append("--no-require-numbers")
    if require_symbols:
        args.append("--require-symbols")
    else:
        args.append("--no-require-symbols")
    if tags:
        args.extend(["--tags", tags])
    return args


def _finalize_setup_binding(
    *,
    env: Environment,
    selected_pool_name: str,
    selected_client_name: str,
    region: str,
) -> None:
    try:
        pool_id, context_name = _resolve_daycog_pool_id_after_setup(
            pool_name=selected_pool_name,
            region=region,
            client_name=selected_client_name,
        )
    except RuntimeError as e:
        ccyo_out.error(f"{e}")
        raise typer.Exit(1)

    # Ensure the selected daycog context is bound to the required TAPDB app client.
    try:
        _context_name, values = _find_pool_context_by_id(
            pool_id,
            prefer_region=region,
            prefer_client_name=REQUIRED_COGNITO_CLIENT_NAME,
        )
        _validate_required_client_name(
            values,
            context_label="daycog bound context",
        )
    except RuntimeError as e:
        ccyo_out.error(f"{e}")
        raise typer.Exit(1)

    cfg_path = _write_pool_id_to_tapdb_config(env, pool_id)
    ccyo_out.success(f"Bound pool ID to tapdb config: {pool_id}")
    ccyo_out.print_text(f"  TAPDB config: [dim]{cfg_path}[/dim]")
    ccyo_out.print_text(
        f"  Daycog context: [dim]{_daycog_config_path()} :: {context_name}[/dim]"
    )


def _resolve_bound_daycog_context(
    env: Environment,
) -> tuple[str, str, dict[str, str], dict[str, str]]:
    cfg = get_db_config_for_env(env.value)
    pool_id = (cfg.get("cognito_user_pool_id") or "").strip()
    if not pool_id:
        raise RuntimeError(
            f"No cognito_user_pool_id set for env {env.value}. "
            f"Run: tapdb cognito setup {env.value}"
        )

    context_name, values = _find_pool_context_by_id(
        pool_id,
        prefer_client_name=REQUIRED_COGNITO_CLIENT_NAME,
    )
    _validate_required_client_name(values, context_label=f"env {env.value}")
    proc_env = os.environ.copy()
    proc_env.update(values)
    return pool_id, context_name, values, proc_env


def _resolve_pool_command_context(
    env: Environment,
    *,
    pool_name: Optional[str] = None,
    region: Optional[str] = None,
    profile: Optional[str] = None,
) -> tuple[str, Optional[dict[str, str]], str, Optional[str]]:
    selected_pool = pool_name or _default_pool_name(env)
    selected_region = region
    selected_profile = profile
    proc_env: Optional[dict[str, str]] = None

    try:
        _, _, values, bound_proc_env = _resolve_bound_daycog_context(env)
        proc_env = bound_proc_env
        selected_region = selected_region or (
            values.get("COGNITO_REGION") or values.get("AWS_REGION") or None
        )
        selected_profile = selected_profile or values.get("AWS_PROFILE") or None
    except RuntimeError:
        # It's valid to manage apps before binding into TAPDB config.
        pass

    return selected_pool, proc_env, selected_region or "us-east-1", selected_profile


def _ensure_actor_user_row(
    env: Environment,
    *,
    email: str,
    role: str = "user",
    display_name: Optional[str] = None,
) -> None:
    """Ensure TAPDB has an actor-backed user row for the Cognito identity."""
    normalized_email = (email or "").strip().lower()
    if not normalized_email:
        raise RuntimeError("email is required for TAPDB actor user creation")
    if role not in ("admin", "user"):
        raise RuntimeError(f"invalid role: {role}")
    cfg = get_db_config_for_env(env.value)
    engine_type = (cfg.get("engine_type") or "local").strip().lower()
    iam_auth = (cfg.get("iam_auth") or "true").strip().lower() in (
        "true",
        "1",
        "yes",
        "on",
    )
    region = (cfg.get("region") or "us-west-2").strip()

    with TAPDBConnection(
        db_hostname=f"{cfg['host']}:{cfg['port']}",
        db_user=cfg["user"],
        db_pass=cfg.get("password") or None,
        db_name=cfg["database"],
        engine_type=engine_type,
        region=region,
        iam_auth=iam_auth,
        app_username=normalized_email,
        domain_code=str(cfg["domain_code"]),
        owner_repo_name=str(cfg["owner_repo_name"]),
    ) as conn:
        with conn.session_scope(commit=True) as session:
            user, _ = create_or_get(
                session,
                login_identifier=normalized_email,
                email=normalized_email,
                display_name=display_name,
                role=role,
                is_active=True,
                require_password_change=False,
                password_hash=None,
                cognito_username=normalized_email,
            )
    if not user.is_active:
        raise RuntimeError(f"TAPDB user {normalized_email} is inactive")


@cognito_app.command("setup")
def cognito_setup(
    env: Environment = typer.Argument(..., help="Target environment"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", "-n", help="Cognito pool name (defaults from DB name)"
    ),
    client_name: Optional[str] = typer.Option(
        None,
        "--client-name",
        help="App client name (must be 'tapdb'; default: tapdb)",
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: AWS_PROFILE env var)"
    ),
    region: str = typer.Option("us-east-1", "--region", "-r", help="AWS region"),
    domain_prefix: Optional[str] = typer.Option(
        None,
        "--domain-prefix",
        help="Hosted UI domain prefix (default: pool name)",
    ),
    attach_domain: bool = typer.Option(
        True,
        "--attach-domain/--no-attach-domain",
        help="Attach/ensure Cognito Hosted UI domain",
    ),
    port: Optional[int] = typer.Option(
        None,
        "--port",
        "-p",
        help="Callback port for daycog (defaults to environments.<env>.ui_port)",
    ),
    callback_path: str = typer.Option(
        "/auth/callback",
        "--callback-path",
        help="Callback path used with --port when --callback-url is not set",
    ),
    callback_url: Optional[str] = typer.Option(
        None, "--callback-url", help="Full callback URL override"
    ),
    logout_url: Optional[str] = typer.Option(
        None, "--logout-url", help="Optional logout URL for app client"
    ),
    autoprovision: bool = typer.Option(
        True,
        "--autoprovision/--no-autoprovision",
        help="Reuse existing app client by --client-name (default: enabled)",
    ),
    generate_secret: bool = typer.Option(
        False,
        "--generate-secret",
        help="Create app client with a generated secret",
    ),
    oauth_flows: str = typer.Option(
        "code", "--oauth-flows", help="Comma-separated OAuth flows"
    ),
    scopes: str = typer.Option(
        "openid,email,profile", "--scopes", help="Comma-separated OAuth scopes"
    ),
    idps: str = typer.Option(
        "COGNITO", "--idp", help="Comma-separated identity providers"
    ),
    password_min_length: int = typer.Option(
        8, "--password-min-length", help="Minimum password length"
    ),
    require_uppercase: bool = typer.Option(
        True,
        "--require-uppercase/--no-require-uppercase",
        help="Require uppercase characters in passwords",
    ),
    require_lowercase: bool = typer.Option(
        True,
        "--require-lowercase/--no-require-lowercase",
        help="Require lowercase characters in passwords",
    ),
    require_numbers: bool = typer.Option(
        True,
        "--require-numbers/--no-require-numbers",
        help="Require numbers in passwords",
    ),
    require_symbols: bool = typer.Option(
        False,
        "--require-symbols/--no-require-symbols",
        help="Require symbols in passwords",
    ),
    mfa: str = typer.Option("off", "--mfa", help="MFA mode: off|optional|required"),
    tags: Optional[str] = typer.Option(
        None, "--tags", help="Comma-separated tags in key=value format"
    ),
) -> None:
    """Create/reuse Cognito pool via daycog and bind pool ID into tapdb config."""
    cfg = get_db_config_for_env(env.value)
    configured_port = int(str(cfg.get("ui_port") or DEFAULT_COGNITO_CALLBACK_PORT))
    if port is None:
        selected_port = configured_port
    elif port != configured_port:
        ccyo_out.error(
            "--port does not match configured TAPDB UI port for env "
            f"{env.value}: {configured_port}"
        )
        raise typer.Exit(1)
    else:
        selected_port = port

    selected_pool_name = pool_name or _default_pool_name(env)
    selected_client_name = client_name or REQUIRED_COGNITO_CLIENT_NAME
    if selected_client_name != REQUIRED_COGNITO_CLIENT_NAME:
        ccyo_out.error(
            f"TAPDB requires Cognito app client name '{REQUIRED_COGNITO_CLIENT_NAME}'."
        )
        raise typer.Exit(1)
    ccyo_out.print_text(
        f"[cyan]Setting up Cognito pool[/cyan] [bold]{selected_pool_name}[/bold] "
        f"for env [bold]{env.value}[/bold]"
    )

    args = _build_daycog_setup_args(
        command="setup",
        selected_pool_name=selected_pool_name,
        region=region,
        domain_prefix=domain_prefix,
        attach_domain=attach_domain,
        port=selected_port,
        callback_path=callback_path,
        oauth_flows=oauth_flows,
        scopes=scopes,
        idps=idps,
        password_min_length=password_min_length,
        mfa=mfa,
        profile=profile,
        client_name=selected_client_name,
        callback_url=callback_url,
        logout_url=logout_url,
        autoprovision=autoprovision,
        generate_secret=generate_secret,
        require_uppercase=require_uppercase,
        require_lowercase=require_lowercase,
        require_numbers=require_numbers,
        require_symbols=require_symbols,
        tags=tags,
    )

    _run_daycog(args)
    _finalize_setup_binding(
        env=env,
        selected_pool_name=selected_pool_name,
        selected_client_name=selected_client_name,
        region=region,
    )


@cognito_app.command("setup-with-google")
def cognito_setup_with_google(
    env: Environment = typer.Argument(..., help="Target environment"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", "-n", help="Cognito pool name (defaults from DB name)"
    ),
    client_name: Optional[str] = typer.Option(
        None,
        "--client-name",
        help="App client name (must be 'tapdb'; default: tapdb)",
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: AWS_PROFILE env var)"
    ),
    region: str = typer.Option("us-east-1", "--region", "-r", help="AWS region"),
    domain_prefix: Optional[str] = typer.Option(
        None,
        "--domain-prefix",
        help="Hosted UI domain prefix (default: pool name)",
    ),
    attach_domain: bool = typer.Option(
        True,
        "--attach-domain/--no-attach-domain",
        help="Attach/ensure Cognito Hosted UI domain",
    ),
    port: Optional[int] = typer.Option(
        None,
        "--port",
        "-p",
        help="Callback port for daycog (defaults to environments.<env>.ui_port)",
    ),
    callback_path: str = typer.Option(
        "/auth/callback",
        "--callback-path",
        help="Callback path used with --port when --callback-url is not set",
    ),
    callback_url: Optional[str] = typer.Option(
        None, "--callback-url", help="Full callback URL override"
    ),
    logout_url: Optional[str] = typer.Option(
        None, "--logout-url", help="Optional logout URL for app client"
    ),
    autoprovision: bool = typer.Option(
        True,
        "--autoprovision/--no-autoprovision",
        help="Reuse existing app client by --client-name (default: enabled)",
    ),
    generate_secret: bool = typer.Option(
        False,
        "--generate-secret",
        help="Create app client with a generated secret",
    ),
    oauth_flows: str = typer.Option(
        "code", "--oauth-flows", help="Comma-separated OAuth flows"
    ),
    scopes: str = typer.Option(
        "openid,email,profile", "--scopes", help="Comma-separated OAuth scopes"
    ),
    idps: str = typer.Option(
        "COGNITO", "--idp", help="Comma-separated identity providers"
    ),
    password_min_length: int = typer.Option(
        8, "--password-min-length", help="Minimum password length"
    ),
    require_uppercase: bool = typer.Option(
        True,
        "--require-uppercase/--no-require-uppercase",
        help="Require uppercase characters in passwords",
    ),
    require_lowercase: bool = typer.Option(
        True,
        "--require-lowercase/--no-require-lowercase",
        help="Require lowercase characters in passwords",
    ),
    require_numbers: bool = typer.Option(
        True,
        "--require-numbers/--no-require-numbers",
        help="Require numbers in passwords",
    ),
    require_symbols: bool = typer.Option(
        False,
        "--require-symbols/--no-require-symbols",
        help="Require symbols in passwords",
    ),
    mfa: str = typer.Option("off", "--mfa", help="MFA mode: off|optional|required"),
    tags: Optional[str] = typer.Option(
        None, "--tags", help="Comma-separated tags in key=value format"
    ),
    google_client_id: Optional[str] = typer.Option(
        None, "--google-client-id", help="Google OAuth client ID"
    ),
    google_client_secret: Optional[str] = typer.Option(
        None, "--google-client-secret", help="Google OAuth client secret"
    ),
    google_client_json: Optional[str] = typer.Option(
        None, "--google-client-json", help="Path to Google OAuth client JSON"
    ),
    google_scopes: str = typer.Option(
        "openid email profile", "--google-scopes", help="Google authorize scopes"
    ),
) -> None:
    """Create/reuse Cognito pool+app and configure Google IdP; bind pool ID."""
    cfg = get_db_config_for_env(env.value)
    configured_port = int(str(cfg.get("ui_port") or DEFAULT_COGNITO_CALLBACK_PORT))
    if port is None:
        selected_port = configured_port
    elif port != configured_port:
        ccyo_out.error(
            "--port does not match configured TAPDB UI port for env "
            f"{env.value}: {configured_port}"
        )
        raise typer.Exit(1)
    else:
        selected_port = port

    selected_pool_name = pool_name or _default_pool_name(env)
    selected_client_name = client_name or REQUIRED_COGNITO_CLIENT_NAME
    if selected_client_name != REQUIRED_COGNITO_CLIENT_NAME:
        ccyo_out.error(
            f"TAPDB requires Cognito app client name '{REQUIRED_COGNITO_CLIENT_NAME}'."
        )
        raise typer.Exit(1)
    ccyo_out.print_text(
        f"[cyan]Setting up Cognito (Google)[/cyan] [bold]{selected_pool_name}[/bold] "
        f"for env [bold]{env.value}[/bold]"
    )

    args = _build_daycog_setup_args(
        command="setup-with-google",
        selected_pool_name=selected_pool_name,
        region=region,
        domain_prefix=domain_prefix,
        attach_domain=attach_domain,
        port=selected_port,
        callback_path=callback_path,
        oauth_flows=oauth_flows,
        scopes=scopes,
        idps=idps,
        password_min_length=password_min_length,
        mfa=mfa,
        profile=profile,
        client_name=selected_client_name,
        callback_url=callback_url,
        logout_url=logout_url,
        autoprovision=autoprovision,
        generate_secret=generate_secret,
        require_uppercase=require_uppercase,
        require_lowercase=require_lowercase,
        require_numbers=require_numbers,
        require_symbols=require_symbols,
        tags=tags,
    )
    if google_client_id:
        args.extend(["--google-client-id", google_client_id])
    if google_client_secret:
        args.extend(["--google-client-secret", google_client_secret])
    if google_client_json:
        args.extend(["--google-client-json", google_client_json])
    if google_scopes:
        args.extend(["--google-scopes", google_scopes])

    _run_daycog(args)
    _finalize_setup_binding(
        env=env,
        selected_pool_name=selected_pool_name,
        selected_client_name=selected_client_name,
        region=region,
    )


@cognito_app.command("bind")
def cognito_bind(
    env: Environment = typer.Argument(..., help="Target environment"),
    pool_id: str = typer.Option(..., "--pool-id", help="Cognito user pool ID"),
) -> None:
    """Bind an existing Cognito pool ID into tapdb config."""
    cfg_path = _write_pool_id_to_tapdb_config(env, pool_id.strip())
    ccyo_out.success(f"Bound {pool_id.strip()} to env '{env.value}'")
    ccyo_out.print_text(f"  TAPDB config: [dim]{cfg_path}[/dim]")


@cognito_app.command("status")
def cognito_status(
    env: Environment = typer.Argument(..., help="Target environment"),
) -> None:
    """Show TAPDB Cognito binding and the mapped Daycog context."""
    cfg = get_db_config_for_env(env.value)
    pool_id = (cfg.get("cognito_user_pool_id") or "").strip()
    if not pool_id:
        ccyo_out.warning(f"No cognito_user_pool_id set for env {env.value}")
        raise typer.Exit(1)

    context_name, values = _find_pool_context_by_id(
        pool_id,
        prefer_client_name=REQUIRED_COGNITO_CLIENT_NAME,
    )
    try:
        _validate_required_client_name(values, context_label=f"env {env.value}")
    except RuntimeError as e:
        ccyo_out.error(f"{e}")
        raise typer.Exit(1)
    region = values.get("COGNITO_REGION") or values.get("AWS_REGION") or "(missing)"
    client_id = values.get("COGNITO_APP_CLIENT_ID") or "(missing)"
    client_name = values.get("COGNITO_CLIENT_NAME") or "(missing)"
    domain = values.get("COGNITO_DOMAIN") or "(not set)"
    callback_url = values.get("COGNITO_CALLBACK_URL") or "(missing)"
    logout_url = values.get("COGNITO_LOGOUT_URL") or "(not set)"
    profile = values.get("AWS_PROFILE") or "(missing)"
    ui_pid_file = _ui_pid_file_for_env(env)
    ccyo_out.success(f"Env:        {env.value}")
    ccyo_out.success(f"Pool ID:    {pool_id}")
    ccyo_out.success(f"Daycog context: {_daycog_config_path()} :: {context_name}")
    ccyo_out.success(f"Region:     {region}")
    ccyo_out.success(f"Client ID:  {client_id}")
    ccyo_out.success(f"Client:     {client_name}")
    ccyo_out.success(f"Domain:     {domain}")
    ccyo_out.success(f"Callback:   {callback_url}")
    ccyo_out.success(f"Logout:     {logout_url}")
    ccyo_out.success(f"Profile:    {profile}")
    ccyo_out.success(f"UI PID:     {ui_pid_file}")

    expected_port, port_source, errors, notices = _validate_bound_cognito_uris(
        env,
        values,
    )
    ccyo_out.success(f"TAPDB UI port expectation: {expected_port} ({port_source})")
    if notices:
        ccyo_out.success(f"URI checks inspected: {len(notices)}")
    if errors:
        ccyo_out.error("Cognito URI validation failed:")
        for msg in errors:
            ccyo_out.print_text(f"  - {msg}")
        raise typer.Exit(1)
    ccyo_out.success("Cognito URI validation passed")


@cognito_app.command("list-pools")
def cognito_list_pools(
    env: Environment = typer.Argument(..., help="Target environment"),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: active Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: active Daycog context)"
    ),
) -> None:
    """List Cognito pools in the selected region via daycog."""
    _, proc_env, selected_region, selected_profile = _resolve_pool_command_context(
        env,
        region=region,
        profile=profile,
    )
    args = ["list-pools", "--region", selected_region]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    _run_daycog_printing(args, env=proc_env)


@cognito_app.command("list-apps")
def cognito_list_apps(
    env: Environment = typer.Argument(..., help="Target environment"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: Daycog context)"
    ),
) -> None:
    """List app clients for a Cognito pool via daycog."""
    selected_pool, proc_env, selected_region, selected_profile = (
        _resolve_pool_command_context(
            env,
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    args = ["list-apps", "--pool-name", selected_pool, "--region", selected_region]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    _run_daycog_printing(args, env=proc_env)


@cognito_app.command("add-app")
def cognito_add_app(
    env: Environment = typer.Argument(..., help="Target environment"),
    app_name: str = typer.Option(..., "--app-name", help="New app client name"),
    callback_url: str = typer.Option(..., "--callback-url", help="OAuth callback URL"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: Daycog context)"
    ),
    logout_url: Optional[str] = typer.Option(
        None, "--logout-url", help="Optional logout URL"
    ),
    generate_secret: bool = typer.Option(
        False, "--generate-secret", help="Create app client with secret"
    ),
    oauth_flows: str = typer.Option("code", "--oauth-flows", help="OAuth flows CSV"),
    scopes: str = typer.Option(
        "openid,email,profile", "--scopes", help="OAuth scopes CSV"
    ),
    idps: str = typer.Option("COGNITO", "--idp", help="Identity providers CSV"),
    set_default: bool = typer.Option(
        False,
        "--set-default",
        help="Update the pool context and active Daycog context to this app",
    ),
) -> None:
    """Create a new app client in the pool via daycog."""
    selected_pool, proc_env, selected_region, selected_profile = (
        _resolve_pool_command_context(
            env,
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    args = [
        "add-app",
        "--pool-name",
        selected_pool,
        "--app-name",
        app_name,
        "--callback-url",
        callback_url,
        "--oauth-flows",
        oauth_flows,
        "--scopes",
        scopes,
        "--idp",
        idps,
        "--region",
        selected_region,
    ]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    if logout_url:
        args.extend(["--logout-url", logout_url])
    if generate_secret:
        args.append("--generate-secret")
    if set_default:
        args.append("--set-default")
    _run_daycog_printing(args, env=proc_env)


@cognito_app.command("edit-app")
def cognito_edit_app(
    env: Environment = typer.Argument(..., help="Target environment"),
    app_name: Optional[str] = typer.Option(
        None, "--app-name", help="Existing app client name"
    ),
    client_id: Optional[str] = typer.Option(
        None, "--client-id", help="Existing app client ID"
    ),
    new_app_name: Optional[str] = typer.Option(
        None, "--new-app-name", help="Rename app client"
    ),
    callback_url: Optional[str] = typer.Option(
        None, "--callback-url", help="Override callback URL"
    ),
    logout_url: Optional[str] = typer.Option(
        None, "--logout-url", help="Override logout URL"
    ),
    oauth_flows: Optional[str] = typer.Option(
        None, "--oauth-flows", help="OAuth flows CSV"
    ),
    scopes: Optional[str] = typer.Option(None, "--scopes", help="OAuth scopes CSV"),
    idps: Optional[str] = typer.Option(None, "--idp", help="Identity providers CSV"),
    set_default: bool = typer.Option(
        False,
        "--set-default",
        help="Update the pool context and active Daycog context to this app",
    ),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: Daycog context)"
    ),
) -> None:
    """Edit an existing app client in the pool via daycog."""
    if not app_name and not client_id:
        ccyo_out.error("Provide one of --app-name or --client-id")
        raise typer.Exit(1)

    selected_pool, proc_env, selected_region, selected_profile = (
        _resolve_pool_command_context(
            env,
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    args = ["edit-app", "--pool-name", selected_pool, "--region", selected_region]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    if app_name:
        args.extend(["--app-name", app_name])
    if client_id:
        args.extend(["--client-id", client_id])
    if new_app_name:
        args.extend(["--new-app-name", new_app_name])
    if callback_url:
        args.extend(["--callback-url", callback_url])
    if logout_url:
        args.extend(["--logout-url", logout_url])
    if oauth_flows:
        args.extend(["--oauth-flows", oauth_flows])
    if scopes:
        args.extend(["--scopes", scopes])
    if idps:
        args.extend(["--idp", idps])
    if set_default:
        args.append("--set-default")
    _run_daycog_printing(args, env=proc_env)


@cognito_app.command("remove-app")
def cognito_remove_app(
    env: Environment = typer.Argument(..., help="Target environment"),
    app_name: Optional[str] = typer.Option(None, "--app-name", help="App client name"),
    client_id: Optional[str] = typer.Option(None, "--client-id", help="App client ID"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: Daycog context)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    delete_config: bool = typer.Option(
        True,
        "--delete-config/--keep-config",
        help="Delete the app-scoped Daycog context (default: true)",
    ),
) -> None:
    """Remove an app client from the pool via daycog."""
    if not app_name and not client_id:
        ccyo_out.error("Provide one of --app-name or --client-id")
        raise typer.Exit(1)

    selected_pool, proc_env, selected_region, selected_profile = (
        _resolve_pool_command_context(
            env,
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    args = ["remove-app", "--pool-name", selected_pool, "--region", selected_region]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    if app_name:
        args.extend(["--app-name", app_name])
    if client_id:
        args.extend(["--client-id", client_id])
    if force:
        args.append("--force")
    if not delete_config:
        args.append("--keep-config")
    _run_daycog_printing(args, env=proc_env)


@cognito_app.command("add-google-idp")
def cognito_add_google_idp(
    env: Environment = typer.Argument(..., help="Target environment"),
    app_name: Optional[str] = typer.Option(None, "--app-name", help="App client name"),
    client_id: Optional[str] = typer.Option(None, "--client-id", help="App client ID"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: active Daycog context)"
    ),
    google_client_id: Optional[str] = typer.Option(
        None, "--google-client-id", help="Google OAuth client ID"
    ),
    google_client_secret: Optional[str] = typer.Option(
        None, "--google-client-secret", help="Google OAuth client secret"
    ),
    google_client_json: Optional[str] = typer.Option(
        None, "--google-client-json", help="Path to Google OAuth client JSON"
    ),
    scopes: str = typer.Option(
        "openid email profile", "--scopes", help="Google authorize scopes"
    ),
) -> None:
    """Configure Google IdP for a pool/app via daycog."""
    if not app_name and not client_id:
        ccyo_out.error("Provide one of --app-name or --client-id")
        raise typer.Exit(1)

    selected_pool, proc_env, selected_region, selected_profile = (
        _resolve_pool_command_context(
            env,
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    args = [
        "add-google-idp",
        "--pool-name",
        selected_pool,
        "--region",
        selected_region,
        "--scopes",
        scopes,
    ]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    if app_name:
        args.extend(["--app-name", app_name])
    if client_id:
        args.extend(["--client-id", client_id])
    if google_client_id:
        args.extend(["--google-client-id", google_client_id])
    if google_client_secret:
        args.extend(["--google-client-secret", google_client_secret])
    if google_client_json:
        args.extend(["--google-client-json", google_client_json])
    _run_daycog_printing(args, env=proc_env)


@cognito_app.command("fix-auth-flows")
def cognito_fix_auth_flows(
    env: Environment = typer.Argument(..., help="Target environment"),
) -> None:
    """Enable required auth flows on the active daycog app client."""
    try:
        _, _, _, proc_env = _resolve_bound_daycog_context(env)
    except RuntimeError as e:
        ccyo_out.error(f"{e}")
        raise typer.Exit(1)
    _run_daycog_printing(["fix-auth-flows"], env=proc_env)


@config_app.command("print")
def cognito_config_print(
    env: Environment = typer.Argument(..., help="Target environment"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: Daycog context)"
    ),
) -> None:
    """Print the Daycog context entry for the target pool."""
    selected_pool, proc_env, selected_region, _ = _resolve_pool_command_context(
        env,
        pool_name=pool_name,
        region=region,
        profile=None,
    )
    args = [
        "config",
        "print",
        "--pool-name",
        selected_pool,
        "--region",
        selected_region,
    ]
    _run_daycog_printing(args, env=proc_env)


@config_app.command("create")
def cognito_config_create(
    env: Environment = typer.Argument(..., help="Target environment"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: active Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: active Daycog context)"
    ),
) -> None:
    """Create a Daycog pool context from AWS and update the active context."""
    selected_pool, proc_env, selected_region, selected_profile = (
        _resolve_pool_command_context(
            env,
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    args = [
        "config",
        "create",
        "--pool-name",
        selected_pool,
        "--region",
        selected_region,
    ]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    _run_daycog_printing(args, env=proc_env)


@config_app.command("update")
def cognito_config_update(
    env: Environment = typer.Argument(..., help="Target environment"),
    pool_name: Optional[str] = typer.Option(
        None, "--pool-name", help="Cognito pool name (default from env DB name)"
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile", help="AWS profile (fallback: active Daycog context)"
    ),
    region: Optional[str] = typer.Option(
        None, "--region", "-r", help="AWS region (fallback: active Daycog context)"
    ),
) -> None:
    """Update a Daycog pool context from AWS and refresh the active context."""
    selected_pool, proc_env, selected_region, selected_profile = (
        _resolve_pool_command_context(
            env,
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    args = [
        "config",
        "update",
        "--pool-name",
        selected_pool,
        "--region",
        selected_region,
    ]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    _run_daycog_printing(args, env=proc_env)


@cognito_app.command("add-user")
def cognito_add_user(
    env: Environment = typer.Argument(..., help="Target environment"),
    email: str = typer.Argument(..., help="User email"),
    password: str = typer.Option(..., "--password", "-p", help="Initial password"),
    role: str = typer.Option("user", "--role", "-r", help="tapdb role: admin|user"),
    display_name: Optional[str] = typer.Option(
        None,
        "--name",
        "-n",
        help="Optional display name for TAPDB actor user",
    ),
    no_verify: bool = typer.Option(
        True,
        "--no-verify/--verify-email",
        help="Set permanent password and mark email verified",
    ),
) -> None:
    """Create a Cognito user in the TAPDB-bound pool via daycog."""
    if role not in ("admin", "user"):
        ccyo_out.error(f"Invalid role: {role}. Must be admin or user")
        raise typer.Exit(1)

    try:
        pool_id, context_name, _, proc_env = _resolve_bound_daycog_context(env)
    except RuntimeError as e:
        ccyo_out.error(f"{e}")
        raise typer.Exit(1)

    args = ["add-user", email, "--password", password]
    if no_verify:
        args.append("--no-verify")
    _run_daycog(args, env=proc_env)

    try:
        _ensure_actor_user_row(
            env,
            email=email,
            role=role,
            display_name=display_name,
        )
    except Exception as e:
        ccyo_out.error(
            f"Cognito user created, but failed to provision TAPDB actor user: {e}"
        )
        raise typer.Exit(1)

    ccyo_out.success(f"Created Cognito user: {email}")
    ccyo_out.print_text(f"  Pool: [dim]{pool_id}[/dim]")
    ccyo_out.print_text(
        f"  Daycog context: [dim]{_daycog_config_path()} :: {context_name}[/dim]"
    )
    ccyo_out.print_text(f"  tapdb role: [dim]{role}[/dim]")
