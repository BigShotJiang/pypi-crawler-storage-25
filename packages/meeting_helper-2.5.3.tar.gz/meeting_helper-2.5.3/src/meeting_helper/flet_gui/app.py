"""Flet application entry point — Material Design 3 dark theme with navigation rail."""

from __future__ import annotations

import json
import threading
import urllib.request
from typing import TYPE_CHECKING

import flet as ft

import subprocess
from pathlib import Path as _Path

from meeting_helper.flet_gui.components.workspace_switcher import WorkspaceSwitcher
from meeting_helper.flet_gui.components.manage_workspaces_modal import ManageWorkspacesModal
from meeting_helper.workspace_switch import switch_workspace

if TYPE_CHECKING:
    from meeting_helper.config import Config


# ---------------------------------------------------------------------------
# Theme colours (matching overlay palette)
# ---------------------------------------------------------------------------
TEAL = "#4ec9b0"
ERROR_RED = "#f14c4c"
SURFACE = "#1e1e1e"
BG = "#0d0d0d"


def _poll_daemon_loop(port: int, callback):
    """Poll /health every 3 s and call *callback(daemon_running, session_active, meeting_name)*.
    Must be called via page.run_thread() so page.update() works."""
    while True:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{port}/health")
            with urllib.request.urlopen(req, timeout=1) as resp:
                data = json.loads(resp.read().decode())
            callback(True, data.get("session_active", False), data.get("meeting", ""))
        except Exception:
            callback(False, False, "")
        threading.Event().wait(3)


def run_flet_gui(config: "Config") -> None:
    """Launch the Flet-based GUI."""
    # Hide the Python host process from the macOS dock (only Flutter window should show)
    try:
        from AppKit import NSApplication, NSApplicationActivationPolicyAccessory
        NSApplication.sharedApplication().setActivationPolicy_(NSApplicationActivationPolicyAccessory)
    except Exception:
        pass

    # Brand the Flet desktop client with our app name
    try:
        import os as _os
        import shutil
        import subprocess as _sp
        from pathlib import Path

        branded_dir = Path.home() / ".meeting-helper" / "flet-client"

        for flet_src in sorted(Path.home().glob(".flet/client/*/Flet.app"), reverse=True):
            branded_app = branded_dir / "Meeting Helper.app"
            src_version = flet_src.parent.name

            version_marker = branded_dir / ".version"
            if (not branded_app.exists()
                    or not version_marker.exists()
                    or version_marker.read_text().strip() != src_version):
                for old in branded_dir.glob("*.app"):
                    shutil.rmtree(old)
                branded_dir.mkdir(parents=True, exist_ok=True)
                shutil.copytree(str(flet_src), str(branded_app))
                version_marker.write_text(src_version)

                plist = branded_app / "Contents" / "Info.plist"
                if plist.exists():
                    for key, val in [
                        ("CFBundleName", "Meeting Helper"),
                        ("CFBundleDisplayName", "Meeting Helper"),
                    ]:
                        _sp.run(["/usr/libexec/PlistBuddy", "-c", f"Set :{key} '{val}'", str(plist)], capture_output=True)
                        _sp.run(["/usr/libexec/PlistBuddy", "-c", f"Add :{key} string '{val}'", str(plist)], capture_output=True)
                    _sp.run(["codesign", "--force", "--deep", "--sign", "-", str(branded_app)], capture_output=True)

            _os.environ["FLET_VIEW_PATH"] = str(branded_dir)
            break
    except Exception:
        pass

    def main(page: ft.Page):
        page.title = "Meeting Helper"

        # Theme from config (default: system)
        theme_pref = config._data.get("gui_theme", "system")
        _THEME_MAP = {"dark": ft.ThemeMode.DARK, "light": ft.ThemeMode.LIGHT, "system": ft.ThemeMode.SYSTEM}
        page.theme_mode = _THEME_MAP.get(theme_pref, ft.ThemeMode.SYSTEM)

        # Light theme — Material derives a coordinated palette from the
        # TEAL seed; we keep the brand primary explicit so accent buttons
        # stay teal regardless of the seed's derivation.
        page.theme = ft.Theme(
            color_scheme_seed=TEAL,
            color_scheme=ft.ColorScheme(
                primary=TEAL,
                on_primary="#ffffff",
                error=ERROR_RED,
            ),
        )
        page.dark_theme = ft.Theme(
            color_scheme_seed=TEAL,
            color_scheme=ft.ColorScheme(
                primary=TEAL,
                on_primary="#ffffff",
                surface=SURFACE,
                on_surface="#cccccc",
                error=ERROR_RED,
            ),
        )
        page.window.width = 1200
        page.window.height = 800
        page.window.min_width = 1000
        page.window.min_height = 700

        # Center window on screen — hide until positioned
        page.window.wait_until_ready_to_show = True
        try:
            from AppKit import NSScreen
            f = NSScreen.mainScreen().frame()
            sw, sh = int(f.size.width), int(f.size.height)
            page.window.top = (sh - 800) // 2
            page.window.left = (sw - 1200) // 2
        except Exception:
            pass
        page.padding = 0

        # --- Screens ---
        # WorkspaceScreen is intentionally not mounted; the module is kept so it
        # can be re-enabled by adding it back here and to the rail destinations.
        from meeting_helper.flet_gui.screens import (
            CopilotScreen,
            RecordingsScreen,
            SettingsScreen,
        )

        copilot = CopilotScreen(page, config)
        recordings = RecordingsScreen(page, config)
        settings_screen = SettingsScreen(page, config)

        screens = [copilot, recordings, settings_screen]
        content_area = ft.Container(
            content=screens[0],
            expand=True,
            padding=0,
        )

        # --- Workspace top bar ---
        switching_overlay = ft.AlertDialog(
            modal=True,
            content=ft.Row(
                [
                    ft.ProgressRing(width=18, height=18, stroke_width=2),
                    ft.Text("Switching workspace…", size=13),
                ],
                spacing=12,
                tight=True,
            ),
        )
        page.overlay.append(switching_overlay)

        def _show_dialog(d: ft.AlertDialog) -> None:
            if d not in page.overlay:
                page.overlay.append(d)
            d.open = True
            page.update()

        def _hide_dialog(d: ft.AlertDialog) -> None:
            d.open = False
            page.update()

        def _cli_path() -> str:
            import shutil, sys
            p = _Path(sys.executable).parent / "meeting-helper"
            if p.exists():
                return str(p)
            return shutil.which("meeting-helper") or "meeting-helper"

        def _spawn_daemon():
            subprocess.Popen(
                [_cli_path(), "start"],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )

        def _read_log_tail(n: int = 20) -> str:
            from meeting_helper.config import LOG_FILE
            try:
                lines = LOG_FILE.read_text(errors="replace").splitlines()
                return "\n".join(lines[-n:])
            except Exception:
                return "(no log available)"

        def _show_failure_dialog(error: str, previous: str, do_retry, do_switch_back):
            log_tail = _read_log_tail()
            dlg = ft.AlertDialog(
                modal=True,
                title=ft.Text("Workspace switch failed"),
                content=ft.Container(
                    width=520,
                    content=ft.Column([
                        ft.Text(error, color=ft.Colors.ERROR),
                        ft.Text("Daemon log (last 20 lines):", size=11, weight=ft.FontWeight.W_500),
                        ft.Container(
                            content=ft.Text(log_tail, font_family="monospace", size=11, selectable=True),
                            bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.ON_SURFACE),
                            padding=8,
                            border_radius=6,
                        ),
                    ], tight=True, spacing=8),
                ),
                actions=[
                    ft.TextButton("Cancel", on_click=lambda e: _hide_dialog(dlg)),
                    ft.TextButton(
                        f"Switch back to '{previous}'",
                        on_click=lambda e: (_hide_dialog(dlg), do_switch_back()),
                    ),
                    ft.FilledButton("Retry", on_click=lambda e: (_hide_dialog(dlg), do_retry())),
                ],
            )
            _show_dialog(dlg)

        def _on_pick_workspace(name: str):
            from meeting_helper.config import load_state as _ls
            previous = _ls()["active_workspace"]

            def _wait_for_daemon_up() -> bool:
                import urllib.request, time as _t
                from meeting_helper.config import get_config as _gc
                deadline = _t.time() + 10
                while _t.time() < deadline:
                    try:
                        port = _gc(reload=True).port
                        urllib.request.urlopen(
                            f"http://127.0.0.1:{port}/health", timeout=1
                        )
                        return True
                    except Exception:
                        _t.sleep(0.3)
                return False

            def _finish_success():
                switching_overlay.open = False
                workspace_switcher.refresh()
                for s in screens:
                    fn = getattr(s, "on_workspace_changed", None)
                    if callable(fn):
                        fn()
                page.update()

            def _attempt(target: str, prev: str):
                result = switch_workspace(target, spawn=_spawn_daemon)
                if not result.ok:
                    switching_overlay.open = False
                    page.update()
                    if result.transient:
                        # Soft error (lock held, recording active) — snackbar only
                        sb = ft.SnackBar(content=ft.Text(result.error))
                        page.overlay.append(sb)
                        sb.open = True
                        page.update()
                    else:
                        _show_failure_dialog(
                            result.error,
                            previous=prev,
                            do_retry=lambda: page.run_thread(_do_switch),
                            do_switch_back=lambda: page.run_thread(
                                lambda: _attempt(prev, target)
                            ),
                        )
                    return
                if not _wait_for_daemon_up():
                    switching_overlay.open = False
                    page.update()
                    _show_failure_dialog(
                        "New daemon did not become healthy within 10 seconds.",
                        previous=prev,
                        do_retry=lambda: page.run_thread(_do_switch),
                        do_switch_back=lambda: page.run_thread(
                            lambda: _attempt(prev, target)
                        ),
                    )
                    return
                _finish_success()

            def _do_switch():
                switching_overlay.open = True
                page.update()
                _attempt(name, previous)

            page.run_thread(_do_switch)

        manage_modal = ManageWorkspacesModal(
            page=page,
            on_change=lambda: workspace_switcher.refresh(),
        )
        workspace_switcher = WorkspaceSwitcher(
            on_pick=_on_pick_workspace,
            on_manage=manage_modal.open,
        )

        top_bar = ft.Container(
            content=ft.Row(
                [workspace_switcher],
                alignment=ft.MainAxisAlignment.START,
            ),
            height=44,
            bgcolor=ft.Colors.SURFACE,
            border=ft.border.only(bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
        )

        # --- Status indicator ---
        status_icon = ft.Icon(ft.Icons.CIRCLE, color="#5a5a5a", size=12)
        status_text = ft.Text("Stopped", size=11, color="#808080")

        def on_status(daemon_running: bool, session_active: bool, meeting_name: str):
            if session_active:
                status_icon.color = ERROR_RED
                status_text.value = "Recording"
                status_text.color = ERROR_RED
            elif daemon_running:
                status_icon.color = TEAL
                status_text.value = "Ready"
                status_text.color = TEAL
            else:
                status_icon.color = "#5a5a5a"
                status_text.value = "Stopped"
                status_text.color = "#808080"

            copilot.update_status(daemon_running, session_active, meeting_name)
            # Detect external workspace switches (e.g., from menu bar)
            try:
                from meeting_helper.config import load_state as _ls
                current = _ls().get("active_workspace", "")
                if current != getattr(workspace_switcher, "_last_seen_active", None):
                    workspace_switcher._last_seen_active = current
                    workspace_switcher.refresh()
                    for s in screens:
                        fn = getattr(s, "on_workspace_changed", None)
                        if callable(fn):
                            fn()
            except Exception:
                pass
            try:
                page.update()
            except Exception:
                pass

        page.run_thread(_poll_daemon_loop, config.port, on_status)

        # --- Navigation rail ---
        def on_nav_change(e):
            idx = e.control.selected_index
            # Stop audio when leaving Recordings
            if content_area.content is recordings:
                recordings.cleanup()
            content_area.content = screens[idx]
            if hasattr(screens[idx], "on_activate"):
                screens[idx].on_activate()
            page.update()

        rail = ft.NavigationRail(
            selected_index=0,
            label_type=ft.NavigationRailLabelType.ALL,
            bgcolor=ft.Colors.SURFACE,
            min_width=100,
            min_extended_width=200,
            expand=True,
            destinations=[
                ft.NavigationRailDestination(
                    icon=ft.Icons.AUTO_AWESOME_OUTLINED,
                    selected_icon=ft.Icons.AUTO_AWESOME,
                    label="Copilot",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.MIC_NONE_OUTLINED,
                    selected_icon=ft.Icons.MIC,
                    label="Recordings",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.SETTINGS_OUTLINED,
                    selected_icon=ft.Icons.SETTINGS,
                    label="Settings",
                ),
            ],
            on_change=on_nav_change,
        )

        sidebar = ft.Container(
            content=ft.Column(
                [
                    rail,
                    ft.Container(
                        content=ft.Row(
                            [status_icon, status_text],
                            spacing=6,
                            alignment=ft.MainAxisAlignment.CENTER,
                        ),
                        padding=ft.padding.only(bottom=16, top=8),
                    ),
                ],
                spacing=0,
                expand=True,
            ),
            width=100,
            bgcolor=ft.Colors.SURFACE,
        )

        # Cleanup audio on window close
        def _on_disconnect(e):
            recordings.cleanup()

        page.on_disconnect = _on_disconnect

        page.add(
            ft.Column(
                [
                    top_bar,
                    ft.Row(
                        [
                            sidebar,
                            ft.VerticalDivider(width=1),
                            content_area,
                        ],
                        expand=True,
                        spacing=0,
                    ),
                ],
                spacing=0,
                expand=True,
            )
        )

    ft.app(target=main)
