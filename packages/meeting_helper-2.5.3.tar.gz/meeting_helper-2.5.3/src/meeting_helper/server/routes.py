"""HTTP routes: health, config, transcribe, summarize."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time

from aiohttp import web

from meeting_helper.state import state
from meeting_helper.server.websocket import ws_handler

logger = logging.getLogger(__name__)


def _hot_moment_window_sec(request) -> float:
    """Resolve the configured Hot Moment window in seconds.

    Reads hot_moment_window_minutes from the request app config.
    Returns 0 if no config is reachable (arm_hot_moment becomes a no-op).
    """
    try:
        cfg = request.app.get("config")
        if cfg is not None:
            return cfg.hot_moment_window_minutes * 60.0
    except Exception:
        pass
    return 0.0

try:
    from anthropic import AsyncAnthropic
except ImportError:
    AsyncAnthropic = None  # tests patch this


def _parse_brief_script_to_sentences(script: str) -> list[str]:
    """Extract first-person bullet sentences from the brief markdown script.

    Each bullet line (lines starting with '-' or '*') is treated as one
    sentence. Section headers (**Today**, etc.) are skipped.
    """
    sentences: list[str] = []
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        # Skip section headers
        if line.startswith("**") and line.endswith("**"):
            continue
        # Bullets
        if line.startswith("- ") or line.startswith("* "):
            text = line[2:].strip()
            if text:
                sentences.append(text)
    return sentences


def _ticket_ids_in(text: str) -> list[str]:
    """Extract unique ticket IDs (e.g. PROJ-123) preserving first-occurrence order."""
    seen: list[str] = []
    for m in re.finditer(r"[A-Z]{2,}-\d+", text):
        tid = m.group(0)
        if tid not in seen:
            seen.append(tid)
    return seen


def _seed_warm_cache_from_brief(script: str, brief_cards: list[dict]) -> dict:
    """After /brief succeeds, seed state.self_buffer + state.current_topic +
    state.current_topic_cards so subsequent queries have grounded context.

    Returns the seeded `current_topic` dict (also assigned to state).
    """
    sentences = _parse_brief_script_to_sentences(script)
    if state.self_buffer is not None:
        for s in sentences:
            state.self_buffer.append_final(s)

    # Pick the first "Today" bullet as the primary topic statement.
    # The script's structure is:
    #   **Today**
    #   - I'm working on PROJ-123 ...
    #   **Yesterday**
    #   - I finished PROJ-111 ...
    today_bullet = ""
    section = None
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("**") and line.endswith("**"):
            header = line.strip("*").strip().lower()
            section = header
            continue
        if section == "today" and (line.startswith("- ") or line.startswith("* ")):
            today_bullet = line[2:].strip()
            break  # take the FIRST today bullet

    last_user_statement = today_bullet or (sentences[0] if sentences else "")
    ticket_ids = _ticket_ids_in(script)
    # Topic = a short noun phrase from the today bullet, falling back to the bullet itself
    topic = ""
    if today_bullet:
        # Strip leading first-person "I'm working on " etc.
        cleaned = re.sub(
            r"^(I['’]m\s+(working on|continuing|on)|I'm\s+(working on|continuing|on)|I am\s+(working on|continuing|on))\s+",
            "",
            today_bullet,
            flags=re.IGNORECASE,
        )
        # Take up to the first em-dash or "—" or first 80 chars
        for sep in [" — ", " - ", ": "]:
            if sep in cleaned:
                topic = cleaned.split(sep, 1)[0].strip()
                break
        if not topic:
            topic = cleaned[:80].strip()

    # Search query — best-effort keywords from the topic
    search_query = topic.lower() if topic else " ".join(ticket_ids[:2])

    current_topic = {
        "topic": topic,
        "ticket_ids": ticket_ids,
        "search_query": search_query,
        "last_user_statement": last_user_statement,
    }
    state.current_topic = current_topic
    state.current_topic_cards = list(brief_cards or [])
    return current_topic


async def health_handler(request: web.Request) -> web.Response:
    meeting_name = ""
    if state.meeting_info:
        meeting_name = getattr(state.meeting_info, "meeting_name", "") or ""
    return web.Response(
        text=json.dumps({
            "status": "ok",
            "meeting": meeting_name,
            "session_active": state.session_active,
            "uptime": round(time.time() - state.started_at) if state.started_at else 0,
        }),
        content_type="application/json",
    )


async def workspace_handler(request: web.Request) -> web.Response:
    """Return the active workspace name and the daemon's bound port."""
    from meeting_helper.config import get_config, load_state
    state_data = load_state()
    cfg = get_config()
    return web.Response(
        text=json.dumps({
            "name": state_data["active_workspace"],
            "port": cfg.port,
        }),
        content_type="application/json",
    )


async def shutdown_handler(request: web.Request) -> web.Response:
    """Trigger graceful daemon shutdown via SIGTERM (handled in run_daemon)."""
    import os
    import signal
    asyncio.get_event_loop().call_later(
        0.1, lambda: os.kill(os.getpid(), signal.SIGTERM)
    )
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def config_get_handler(request: web.Request) -> web.Response:
    """Return current workspace config."""
    config = request.app["config"]
    return web.Response(
        text=json.dumps({
            "repos": config.repos,
            "repos_workspaces": config.repos_workspaces,
            "repos_workspace": config.repos_workspace,  # compat
            "knowledge_paths": config.knowledge_paths,
            "knowledge_path": config.knowledge_path,    # compat
            "ignored_repos": config.ignored_repos,
            "ignored_knowledge": config.ignored_knowledge,
        }),
        content_type="application/json",
    )


async def config_post_handler(request: web.Request) -> web.Response:
    """Update workspace config mid-session. Rebuilds system prompt."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]
    changed = False

    if "repos" in body:
        config.repos = body["repos"]
        changed = True
    if "repos_workspaces" in body:
        config.repos_workspaces = body["repos_workspaces"]
        changed = True
    elif "repos_workspace" in body:
        config.repos_workspace = body["repos_workspace"]
        changed = True
    if "knowledge_paths" in body:
        config.knowledge_paths = body["knowledge_paths"]
        changed = True
    elif "knowledge_path" in body:
        config.knowledge_path = body["knowledge_path"]
        changed = True
    if "ignored_repos" in body:
        config.ignored_repos = body["ignored_repos"]
    if "ignored_knowledge" in body:
        config.ignored_knowledge = body["ignored_knowledge"]
    if "hot_moment_window_minutes" in body:
        # Live tunable — TopicWorker reads this on every self-sentence to
        # arm the Hot Moment, so updates take effect on the next sentence.
        config.hot_moment_window_minutes = float(body["hot_moment_window_minutes"])
    if "local_todo_mcp" in body:
        # MCP config changed — close existing client and rebuild against new endpoint.
        new_mcp = dict(body["local_todo_mcp"] or {})
        config.local_todo_mcp = new_mcp
        if state.local_todo is not None:
            try:
                await state.local_todo.close()
            except Exception as exc:
                logger.warning("local-todo close error during reconfig: %s", exc)
            state.local_todo = None
        kind = (new_mcp.get("type") or "stdio").strip().lower()
        configured = bool(new_mcp.get("url")) if kind == "http" else bool(new_mcp.get("command"))
        if configured:
            try:
                from meeting_helper.local_todo import LocalTodoClient
                state.local_todo = LocalTodoClient(mcp_config=new_mcp)
                logger.info(
                    "local-todo MCP rewired (%s %s)",
                    kind,
                    new_mcp.get("url") if kind == "http" else new_mcp.get("command"),
                )
            except Exception as exc:
                logger.warning("local-todo rewire failed: %s", exc)
                state.local_todo = None
        else:
            logger.info("local-todo MCP cleared via /config")
    # Broadcast so overlay refreshes chips immediately
    if "ignored_repos" in body or "ignored_knowledge" in body:
        from meeting_helper.server.websocket import broadcast
        asyncio.ensure_future(broadcast({
            "type": "config_changed",
            "ignored_repos": config.ignored_repos,
            "ignored_knowledge": config.ignored_knowledge,
        }))

    if changed:
        from meeting_helper.ai.prompts import build_system_prompt
        knowledge_folders = body.get("knowledge_folders")

        # Run file I/O in a thread so we don't block the event loop / audio pipeline
        if knowledge_folders is not None:
            from meeting_helper.context_loader import build_selective_context
            context_block = await asyncio.to_thread(
                build_selective_context, config.repos, config.knowledge_path, knowledge_folders
            )
        else:
            from meeting_helper.context_loader import build_full_context
            context_block = await asyncio.to_thread(
                build_full_context, config.repos, config.knowledge_paths or config.knowledge_path
            )
        state.system_prompt = build_system_prompt(context_block)

    return web.Response(
        text=json.dumps({"ok": True, "changed": changed}),
        content_type="application/json",
    )


async def transcript_handler_get(request: web.Request) -> web.Response:
    """GET /transcript — return the last N sentences from the buffer."""
    n = int(request.query.get("n", "10"))
    sentences = []
    if state.sentence_buffer is not None:
        sentences = state.sentence_buffer.get_last_n(n)
    interim = None
    if state.sentence_buffer is not None:
        interim = state.sentence_buffer.get_interim()
    return web.Response(
        text=json.dumps({"sentences": sentences, "interim": interim}),
        content_type="application/json",
    )


async def transcript_clear_handler(request: web.Request) -> web.Response:
    """POST /transcript/clear — clear the accumulated transcript buffer."""
    if state.sentence_buffer is not None:
        state.sentence_buffer.clear()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def last_response_handler(request: web.Request) -> web.Response:
    """GET /last_response — return the last AI response text."""
    return web.Response(
        text=json.dumps({"text": state.last_response or ""}),
        content_type="application/json",
    )


async def last_cards_handler(request: web.Request) -> web.Response:
    """GET /last_cards — returns the last query's local-todo source cards."""
    return web.Response(
        text=json.dumps({"items": state.last_cards or []}),
        content_type="application/json",
    )


async def current_topic_handler(request: web.Request) -> web.Response:
    """GET /current_topic — current topic + warm-cache info from TopicWorker."""
    return web.Response(
        text=json.dumps({
            "topic": state.current_topic or {
                "topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": "",
            },
            "cards_count": len(state.current_topic_cards or []),
            "cards": state.current_topic_cards or [],
        }),
        content_type="application/json",
    )


async def query_handler(request: web.Request) -> web.Response:
    """POST /query — send a manual text query to Claude."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    text = body.get("text", "").strip()
    if not text:
        return web.Response(status=400, text='{"error": "text required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import handle_manual_query
    config = request.app["config"]

    try:
        await handle_manual_query(state, config, text)
        return web.Response(
            text=json.dumps({"ok": True}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def transcribe_handler(request: web.Request) -> web.Response:
    """POST /transcribe — transcribe an MP3 file with Whisper."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    mp3_path = body.get("mp3_path", "")
    if not mp3_path:
        return web.Response(status=400, text='{"error": "mp3_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import transcribe_audio_file
    config = request.app["config"]

    try:
        transcript = await asyncio.to_thread(transcribe_audio_file, mp3_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "transcript": transcript}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def summarize_handler(request: web.Request) -> web.Response:
    """POST /summarize — summarize a transcript with Claude."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    transcript_path = body.get("transcript_path", "")
    if not transcript_path:
        return web.Response(status=400, text='{"error": "transcript_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import summarize_transcript
    config = request.app["config"]

    try:
        summary = await summarize_transcript(transcript_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "summary": summary}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def extract_task_handler(request: web.Request) -> web.Response:
    """POST /extract-task — extract new action items from the in-memory transcript."""
    from meeting_helper.ai.client import extract_tasks
    from meeting_helper.server.websocket import broadcast

    config = request.app["config"]
    try:
        added = await extract_tasks(state, config)
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    await broadcast({"type": "tasks_extracted", "added": len(added)})
    await broadcast({"type": "tasks", "tasks": list(state.session_tasks)})

    return web.Response(
        text=json.dumps({"added": len(added), "total": len(state.session_tasks)}),
        content_type="application/json",
    )


async def tasks_get_handler(request: web.Request) -> web.Response:
    """GET /tasks — return the current session's extracted tasks."""
    return web.Response(
        text=json.dumps({"tasks": list(state.session_tasks)}),
        content_type="application/json",
    )


async def brief_handler(request: web.Request) -> web.Response:
    """POST /brief — generate a first-person standup script + source cards from local-todo."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    from meeting_helper.ai.prompts import BRIEF_SYSTEM_PROMPT
    import httpx

    config = request.app.get("config")
    if state.local_todo is None:
        return web.json_response(
            {"error": "local-todo MCP not configured"}, status=503,
        )
    if not getattr(config, "anthropic_api_key", ""):
        return web.json_response(
            {"error": "Anthropic API key not configured"}, status=503,
        )

    try:
        active_tasks = await state.local_todo.my_active_tasks()
    except Exception as exc:
        logger.warning("brief: my_active_tasks failed: %s", exc)
        return web.json_response({"error": f"local-todo error: {exc}"}, status=502)

    user_msg = (
        "## My active tasks (from local-todo):\n"
        + json.dumps(active_tasks, indent=2)
        + "\n\nGenerate the standup script as JSON."
    )

    client = AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )
    msg = await client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=getattr(config, "max_tokens", 800),
        system=BRIEF_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_msg}],
    )

    raw = msg.content[0].text.strip()
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        return web.json_response({"error": "AI returned non-JSON", "raw": raw[:500]}, status=502)
    try:
        parsed = json.loads(match.group())
    except json.JSONDecodeError as exc:
        return web.json_response({"error": f"JSON parse: {exc}", "raw": raw[:500]}, status=502)

    script = parsed.get("script", "").strip()
    card_ids = parsed.get("card_ids", []) or []

    # Build id → board_id lookup from active_tasks (since task ids are scoped per board)
    id_to_board: dict[str, int] = {}
    for t in active_tasks:
        tid = str(t.get("id", ""))
        bid = t.get("board_id")
        if tid and bid is not None:
            id_to_board[tid] = bid

    cards: list[dict] = []
    for cid in card_ids:
        cid = str(cid)
        bid = id_to_board.get(cid)
        if bid is None:
            # Card id not in our active set — skip or try first available board
            logger.warning("brief: card_id %s not in active task set; skipping backfill", cid)
            continue
        record = None
        try:
            record = await state.local_todo.get("task", cid, board_id=bid)
            if record:
                record.setdefault("kind", "task")
                record.setdefault("board_id", bid)
        except Exception:
            record = None
        if not record:
            try:
                record = await state.local_todo.get("doc", cid, board_id=bid)
                if record:
                    record.setdefault("kind", "doc")
                    record.setdefault("board_id", bid)
            except Exception as exc:
                logger.warning("brief: failed to backfill %s: %s", cid, exc)
                continue
        if record:
            cards.append(record)

    payload = {"script": script, "cards": cards}

    # Seed warm cache so subsequent /query calls have grounded context
    # even before the user speaks aloud.
    try:
        seeded_topic = _seed_warm_cache_from_brief(script, cards)
        # Broadcast topic so UIs update immediately
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast({
                "type": "topic",
                "topic": seeded_topic.get("topic", ""),
                "ticket_ids": seeded_topic.get("ticket_ids", []),
                "last_user_statement": seeded_topic.get("last_user_statement", ""),
                "cards": cards,
            })
        except Exception as exc:
            logger.warning("topic broadcast (from brief) failed: %s", exc)
    except Exception as exc:
        logger.warning("brief warm-cache seeding failed: %s", exc)

    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "brief", **payload})
    except Exception as exc:
        logger.warning("brief broadcast failed: %s", exc)

    return web.json_response(payload)


async def debug_say_handler(request: web.Request) -> web.Response:
    """POST /debug/say — inject a sentence into self_buffer or other_buffer
    for testing without a mic. Body: {"text": "...", "role": "self"|"other"}.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    text = (body.get("text") or "").strip()
    if not text:
        return web.json_response({"error": "text required"}, status=400)
    role = (body.get("role") or "self").strip().lower()
    if role not in ("self", "other"):
        return web.json_response({"error": "role must be 'self' or 'other'"}, status=400)

    buf = state.self_buffer if role == "self" else state.other_buffer
    if buf is None:
        return web.json_response(
            {"error": f"{role}_buffer not initialized — start a session first"},
            status=409,
        )

    buf.append_final(text)
    logger.info("debug/say: injected '%s' into %s_buffer", text[:80], role)
    return web.json_response({"ok": True, "role": role, "text": text})


async def knowledge_tree_handler(request: web.Request) -> web.Response:
    """GET /knowledge-tree — return folder structure of the knowledge base."""
    config = request.app["config"]
    if not config.knowledge_path:
        return web.Response(
            text=json.dumps({"tree": []}), content_type="application/json"
        )
    from meeting_helper.context_loader import get_knowledge_tree
    tree = get_knowledge_tree(config.knowledge_path)
    return web.Response(
        text=json.dumps({"tree": tree}), content_type="application/json"
    )


async def ignore_handler(request: web.Request) -> web.Response:
    """POST /ignore — add or remove a repo/knowledge folder from the ignore list.

    Body: {"type": "repo"|"knowledge", "name": "folder_name", "action": "add"|"remove"}
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}', content_type="application/json")

    config = request.app["config"]
    item_type = body.get("type")  # "repo" or "knowledge"
    name = body.get("name", "").strip()
    action = body.get("action", "add")  # "add" or "remove"

    if not name or item_type not in ("repo", "knowledge"):
        return web.Response(status=400, text='{"error": "type and name required"}', content_type="application/json")

    if item_type == "repo":
        lst = list(config.ignored_repos)
        if action == "add" and name not in lst:
            lst.append(name)
        elif action == "remove":
            lst = [x for x in lst if x != name]
        config.ignored_repos = lst
    else:
        lst = list(config.ignored_knowledge)
        if action == "add" and name not in lst:
            lst.append(name)
        elif action == "remove":
            lst = [x for x in lst if x != name]
        config.ignored_knowledge = lst

    # config is AppConfig (dataclass) — no save() method. Disk write happens in GUI.
    return web.Response(
        text=json.dumps({"ok": True, "ignored_repos": config.ignored_repos, "ignored_knowledge": config.ignored_knowledge}),
        content_type="application/json",
    )


async def conversations_handler(request: web.Request) -> web.Response:
    """GET /conversations?repo=<path> — list past Claude Code conversations for a repo."""
    repo = request.query.get("repo", "").strip()
    if not repo:
        return web.Response(
            status=400,
            text=json.dumps({"error": "repo query param required"}),
            content_type="application/json",
        )
    from meeting_helper.claude_history import list_conversations
    convs = await asyncio.to_thread(list_conversations, repo)
    return web.Response(
        text=json.dumps({"conversations": convs}),
        content_type="application/json",
    )


async def conversation_attach_handler(request: web.Request) -> web.Response:
    """POST /conversation/attach — attach a past Claude Code conversation as primary context.

    Body: {"repo": "<absolute path>", "session_id": "<uuid>"}
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(
            status=400,
            text='{"error": "invalid JSON"}',
            content_type="application/json",
        )

    repo = (body.get("repo") or "").strip()
    session_id = (body.get("session_id") or "").strip()
    if not repo or not session_id:
        return web.Response(
            status=400,
            text='{"error": "repo and session_id required"}',
            content_type="application/json",
        )

    from meeting_helper.claude_history import reconstruct_conversation
    from meeting_helper.ai.prompts import build_system_prompt, build_conversation_context_block
    from pathlib import Path

    try:
        conv = await asyncio.to_thread(reconstruct_conversation, repo, session_id)
    except FileNotFoundError as exc:
        return web.Response(
            status=404,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    repo_name = Path(repo).expanduser().resolve().name
    context_block = build_conversation_context_block(
        title=conv["title"],
        repo_name=repo_name,
        body=conv["body"],
        truncated=conv["truncated"],
    )
    state.system_prompt = build_system_prompt(context_block)
    # Clear any prior Q&A turns so answers grounded in the OLD context don't
    # leak into answers for the NEW conversation. Safe whether this is the
    # first attach or a switch from another conversation.
    state.conversation_history = []
    state.attached_conversation = {
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "attached_at": time.time(),
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    }

    from meeting_helper.server.websocket import broadcast
    await broadcast({
        "type": "conversation_attached",
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    })

    return web.Response(
        text=json.dumps({
            "ok": True,
            "title": conv["title"],
            "chars": conv["chars"],
            "truncated": conv["truncated"],
            "turn_count": conv["turn_count"],
        }),
        content_type="application/json",
    )


async def conversation_detach_handler(request: web.Request) -> web.Response:
    """POST /conversation/detach — clear an attached Claude Code conversation.

    Rebuilds the system prompt from the current auto-context selection so
    the user falls back to whatever the AutoContextSelector had picked,
    rather than dropping to a bare prompt.
    """
    if state.attached_conversation is None:
        return web.Response(
            text=json.dumps({"ok": True, "was_attached": False}),
            content_type="application/json",
        )

    state.attached_conversation = None
    # Clear Q&A turns grounded in the conversation we're detaching from.
    state.conversation_history = []
    config = request.app["config"]

    from meeting_helper.ai.prompts import build_system_prompt
    selection = state.auto_context_selection or {"repos": [], "knowledge": []}
    sel_repos = selection.get("repos") or []
    sel_knowledge = selection.get("knowledge") or []

    if sel_repos or sel_knowledge:
        from meeting_helper.context_loader import build_selective_context, get_repos_from_workspaces
        all_repos = {
            r["name"]: r["path"]
            for r in get_repos_from_workspaces(
                config.repos_workspaces or (
                    [config.repos_workspace] if config.repos_workspace else []
                ),
                ignored=config.ignored_repos,
            )
        }
        selected_paths = [all_repos[n] for n in sel_repos if n in all_repos]
        kp_list = config.knowledge_paths or (
            [config.knowledge_path] if config.knowledge_path else []
        )
        kp = kp_list[0] if kp_list else ""
        context_block = await asyncio.to_thread(
            build_selective_context, selected_paths, kp, sel_knowledge
        )
        state.system_prompt = build_system_prompt(context_block)
    else:
        # Fall back to the low-level index if available, otherwise bare prompt.
        state.system_prompt = build_system_prompt(state.auto_context_index or "")

    from meeting_helper.server.websocket import broadcast
    await broadcast({"type": "conversation_detached"})

    return web.Response(
        text=json.dumps({"ok": True, "was_attached": True}),
        content_type="application/json",
    )


async def auto_context_handler(request: web.Request) -> web.Response:
    """GET /auto-context — return current auto-context state."""
    return web.Response(
        text=json.dumps({
            "index_loaded": bool(state.auto_context_index),
            "index_len": len(state.auto_context_index),
            "selection": state.auto_context_selection,
        }),
        content_type="application/json",
    )


async def session_start_handler(request: web.Request) -> web.Response:
    """POST /session/start — manually start a full recording session."""
    if state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "already_active": True}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_start()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def session_stop_handler(request: web.Request) -> web.Response:
    """POST /session/stop — manually stop the current recording session."""
    if not state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "was_active": False}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_stop()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def proactive_handler(request: web.Request) -> web.Response:
    """POST /proactive — enable or disable proactive answers for current session."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}', content_type="application/json")

    enabled = bool(body.get("enabled", True))
    monitor = state.proactive_monitor
    if monitor is not None:
        monitor.set_enabled(enabled)
    auto_ctx = state.auto_context_selector
    if auto_ctx is not None:
        auto_ctx.set_enabled(enabled)

    return web.Response(
        text=json.dumps({"ok": True, "enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


async def proactive_status_handler(request: web.Request) -> web.Response:
    """GET /proactive — return current proactive enabled state."""
    monitor = state.proactive_monitor
    enabled = monitor.is_enabled() if monitor is not None else False
    return web.Response(
        text=json.dumps({"enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


def _resolve_ai_model(config) -> str:
    """Return the display model string for the current provider config."""
    if config.preferred_provider == "local":
        return config.local_model
    if config.preferred_provider == "gemini":
        return config.gemini_model
    return config.claude_model


async def provider_get_handler(request: web.Request) -> web.Response:
    """GET /provider — return current provider/model/transcriber state."""
    config = request.app["config"]
    return web.Response(
        text=json.dumps({
            "provider": config.preferred_provider or "claude",
            "claude_model": config.claude_model_alias,
            "gemini_model": config.gemini_model_alias,
            "local_model": config.local_model,
            "transcriber": config.preferred_transcriber or "whisper",
        }),
        content_type="application/json",
    )


async def provider_post_handler(request: web.Request) -> web.Response:
    """POST /provider — switch AI provider, model, or transcriber at runtime."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]
    changed = False

    # AI provider switch
    if "provider" in body:
        config.preferred_provider = body["provider"]
        changed = True
    if "claude_model" in body:
        from meeting_helper.config import CLAUDE_MODELS
        alias = body["claude_model"]
        config.claude_model_alias = alias
        config.claude_model = CLAUDE_MODELS.get(alias, alias)
        changed = True
    if "gemini_model" in body:
        from meeting_helper.config import GEMINI_MODELS
        alias = body["gemini_model"]
        config.gemini_model_alias = alias
        config.gemini_model = GEMINI_MODELS.get(alias, alias)
        changed = True
    if "local_model" in body:
        config.local_model = body["local_model"]
        changed = True

    # Transcriber switch
    transcriber_changed = False
    if "transcriber" in body:
        config.preferred_transcriber = body["transcriber"]
        transcriber_changed = True
        changed = True

    if transcriber_changed and state.session_active:
        session = state.meeting_session
        if session is not None:
            t_name = await asyncio.to_thread(
                session.swap_transcriber, body["transcriber"], config
            )
            state.transcriber_name = t_name

    # Update displayed AI model
    if changed:
        state.ai_model = _resolve_ai_model(config)

        # Broadcast info update to overlay/dashboard
        from meeting_helper.server.websocket import broadcast_info
        await broadcast_info()

        # Persist to disk config
        from meeting_helper.config import get_config
        disk = get_config()
        disk.preferred_provider = config.preferred_provider
        disk.claude_model = config.claude_model_alias
        disk.gemini_model = config.gemini_model_alias
        disk.local_model = config.local_model
        disk.preferred_transcriber = config.preferred_transcriber
        disk.save()

    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


def setup_routes(app: web.Application) -> None:
    app.router.add_get("/health", health_handler)
    app.router.add_get("/config", config_get_handler)
    app.router.add_post("/config", config_post_handler)
    app.router.add_get("/knowledge-tree", knowledge_tree_handler)
    app.router.add_get("/transcript", transcript_handler_get)
    app.router.add_post("/transcript/clear", transcript_clear_handler)
    app.router.add_get("/last_response", last_response_handler)
    app.router.add_get("/last_cards", last_cards_handler)
    app.router.add_get("/current_topic", current_topic_handler)
    app.router.add_post("/query", query_handler)
    app.router.add_post("/transcribe", transcribe_handler)
    app.router.add_post("/summarize", summarize_handler)
    app.router.add_post("/extract-task", extract_task_handler)
    app.router.add_get("/tasks", tasks_get_handler)
    app.router.add_post("/brief", brief_handler)
    app.router.add_post("/debug/say", debug_say_handler)
    app.router.add_post("/ignore", ignore_handler)
    app.router.add_get("/auto-context", auto_context_handler)
    app.router.add_get("/conversations", conversations_handler)
    app.router.add_post("/conversation/attach", conversation_attach_handler)
    app.router.add_post("/conversation/detach", conversation_detach_handler)
    app.router.add_post("/proactive", proactive_handler)
    app.router.add_get("/proactive", proactive_status_handler)
    app.router.add_post("/session/start", session_start_handler)
    app.router.add_post("/session/stop", session_stop_handler)
    app.router.add_get("/provider", provider_get_handler)
    app.router.add_post("/provider", provider_post_handler)
    app.router.add_get("/workspace", workspace_handler)
    app.router.add_post("/shutdown", shutdown_handler)
    app.router.add_get("/ws", ws_handler)
