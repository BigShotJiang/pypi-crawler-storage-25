"""Verify handle_query / handle_manual_query consume warm topic cache + cards."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from meeting_helper.ai import client as client_mod
from meeting_helper.buffer import SentenceBuffer
from meeting_helper.state import AppState


class FakeConfig:
    preferred_provider = "claude"
    anthropic_api_key = "test-key"
    google_api_key = ""
    deepgram_api_key = ""
    claude_model = "claude-test"
    gemini_model = "gemini-test"
    local_model = "qwen"
    ollama_host = "http://localhost:11434"
    max_tokens = 1000
    max_history_turns = 5
    sentence_window = 5
    system_prompt = ""


def test_format_cards_markdown_empty():
    assert client_mod._format_cards_markdown([]) == ""


def test_format_cards_markdown_basic():
    cards = [
        {"kind": "task", "id": "PROJ-123", "title": "Refresh tokens",
         "status": "in_progress", "sprint": "W17", "due": "2026-05-02",
         "body": "Implement rotation on /auth/refresh."},
    ]
    md = client_mod._format_cards_markdown(cards)
    assert "[PROJ-123]" in md
    assert "Refresh tokens" in md
    assert "in_progress" in md
    assert "Sprint W17" in md
    assert "Due 2026-05-02" in md
    # Body is now on its own line after a "Body:" header (allows newlines in body)
    assert "Body:" in md
    assert "Implement rotation" in md


@pytest.mark.asyncio
async def test_handle_manual_query_uses_warm_cache():
    state = AppState()
    state.self_buffer = SentenceBuffer(role="self")
    state.self_buffer.append_final("I'm working on the auth refresh.")
    state.other_buffer = SentenceBuffer(role="other")
    state.conversation_history = []
    # Pre-populate the warm cache as TopicWorker would
    state.current_topic = {
        "topic": "Auth refresh",
        "ticket_ids": ["PROJ-123"],
        "search_query": "auth refresh",
        "last_user_statement": "I'm working on the auth refresh.",
    }
    state.current_topic_cards = [
        {"kind": "task", "id": "PROJ-123", "title": "Refresh tokens", "status": "in_progress"}
    ]

    captured_payloads: list[dict] = []

    async def fake_broadcast(payload):
        captured_payloads.append(payload)

    async def fake_stream_ai(state, config, messages, system_prompt):
        captured_payloads.append({"type": "_test_system_prompt", "value": system_prompt})
        captured_payloads.append({"type": "_test_user_msg", "value": messages[-1]["content"]})
        return "answer text"

    with patch("meeting_helper.server.websocket.broadcast", new=fake_broadcast), \
         patch("meeting_helper.ai.client._stream_ai", new=fake_stream_ai):
        await client_mod.handle_manual_query(state, FakeConfig(), "what's the status of refresh?")

    # Cards broadcast should have happened from warm cache
    assert any(p.get("type") == "cards" for p in captured_payloads), \
        f"expected cards broadcast, got: {[p.get('type') for p in captured_payloads]}"

    # The system prompt embeds the cards markdown
    sys_prompt = next(p["value"] for p in captured_payloads if p.get("type") == "_test_system_prompt")
    assert "PROJ-123" in sys_prompt
    assert "Refresh tokens" in sys_prompt

    # The user message has the new sectioned shape
    user_msg = next(p["value"] for p in captured_payloads if p.get("type") == "_test_user_msg")
    assert "## Topic just discussed" in user_msg
    assert "Auth refresh" in user_msg
    assert "## What I just said" in user_msg
    assert "## What was just asked" in user_msg
    assert "what's the status of refresh?" in user_msg
