"""Endpoint validation utilities — IPv6 handling, TLS fingerprinting, URL parsing."""

import hashlib
import ipaddress
import logging
import socket
import ssl
from typing import Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


def bracket_ipv6(hostname: str) -> str:
    """Wrap bare IPv6 addresses in brackets for use in URLs."""
    try:
        addr = ipaddress.ip_address(hostname)
        if addr.version == 6:
            return f"[{hostname}]"
    except ValueError:
        pass
    return hostname


def is_ip_endpoint(endpoint: str) -> bool:
    """Return True if the endpoint hostname is an IP address (not a domain)."""
    hostname = urlparse(endpoint).hostname
    if not hostname:
        return False
    try:
        ipaddress.ip_address(hostname)
        return True
    except ValueError:
        return False


def insecure_ssl_context() -> ssl.SSLContext:
    """SSL context that skips certificate verification (for self-signed certs)."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def test_tls(hostname: str, port: int) -> tuple[bool, Optional[str], str]:
    """Test TLS handshake. Return (ok, fingerprint, message)."""
    try:
        ctx = insecure_ssl_context()
        with socket.create_connection((hostname, port), timeout=10) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as tls:
                der = tls.getpeercert(binary_form=True)
                fp = hashlib.sha256(der).hexdigest() if der else None
                return True, fp, "OK"
    except Exception as e:
        return False, None, str(e)


def get_cert_fingerprint(endpoint: str) -> Optional[str]:
    """Fetch the SHA256 fingerprint of the TLS leaf certificate."""
    parsed = urlparse(endpoint)
    hostname = parsed.hostname
    port = parsed.port or 443
    if not hostname:
        return None
    ok, fingerprint, _ = test_tls(hostname, port)
    if not ok:
        logger.warning("Could not fetch TLS certificate from %s", endpoint)
        return None
    return fingerprint
