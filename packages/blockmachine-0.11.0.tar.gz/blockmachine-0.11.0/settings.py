"""Application defaults with environment variable overrides."""

import os
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version

try:
    _PACKAGE_VERSION = version("blockmachine")
except PackageNotFoundError:
    _PACKAGE_VERSION = "dev"


@dataclass(frozen=True)
class NetworkConfig:
    auth_url: str
    api_url: str
    netuid: int
    client_id: str


MAINNET = NetworkConfig(
    auth_url="https://auth.taostats.io",
    api_url="https://api.blockmachine.io",
    netuid=19,
    client_id="35cc50f5-6bf5-432b-8892-84c3b0e856b2",
)

TESTNET = NetworkConfig(
    auth_url="https://test-auth.taostats.io",
    api_url="https://testnet-api.blockmachine.io",
    netuid=417,
    client_id="07f5c729-5ca7-412a-b5e7-4966e132548e",
)

# Active network — set by --testnet flag via main.py callback
_network: NetworkConfig = MAINNET


def get_network() -> NetworkConfig:
    return _network


def set_network(network: NetworkConfig) -> None:
    global _network
    _network = network


def auth_url() -> str:
    return os.environ.get("BM_AUTH_URL", _network.auth_url)


def api_url() -> str:
    return os.environ.get("BM_API_URL", _network.api_url)


def netuid() -> int:
    env = os.environ.get("BM_NETUID")
    if env:
        return int(env)
    return _network.netuid


AUDIENCE = "bittensor-apps"


def client_id() -> str:
    return os.environ.get("BM_CLIENT_ID", _network.client_id)


def jwks_uri() -> str:
    return f"{auth_url()}/.well-known/jwks.json"


def miner_scopes() -> list[str]:
    return [f"subnet:{netuid()}:miner"]


def validator_scopes() -> list[str]:
    return [f"subnet:{netuid()}:validator"]


def network_name() -> str:
    """Return 'testnet' or 'mainnet' based on the active network."""
    return "testnet" if _network is TESTNET else "mainnet"


def user_agent() -> str:
    return f"blockmachine-cli/{_PACKAGE_VERSION}"
