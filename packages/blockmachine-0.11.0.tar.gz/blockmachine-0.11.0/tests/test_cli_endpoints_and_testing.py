"""Unit tests for cli/endpoints.py and cli/testing.py (introduced in refactor/common-cli-cleanup)."""

import ssl
from unittest.mock import MagicMock, patch


# ── cli/endpoints.py ────────────────────────────────────────────────────────


class TestBracketIPv6:
    """bracket_ipv6 wraps bare IPv6 addresses for URL use."""

    def test_bare_ipv6_gets_bracketed(self):
        from cli.endpoints import bracket_ipv6

        assert bracket_ipv6("2001:db8::1") == "[2001:db8::1]"

    def test_ipv4_unchanged(self):
        from cli.endpoints import bracket_ipv6

        assert bracket_ipv6("1.2.3.4") == "1.2.3.4"

    def test_hostname_unchanged(self):
        from cli.endpoints import bracket_ipv6

        assert bracket_ipv6("example.com") == "example.com"

    def test_already_bracketed_ipv6_unchanged(self):
        """Already-bracketed address is not an IP literal, so passes through unchanged."""
        from cli.endpoints import bracket_ipv6

        # urlparse strips brackets, so "[::1]" as a raw string is a hostname, not an IP
        result = bracket_ipv6("[::1]")
        assert result == "[::1]"

    def test_loopback_ipv6_gets_bracketed(self):
        from cli.endpoints import bracket_ipv6

        assert bracket_ipv6("::1") == "[::1]"

    def test_empty_string_unchanged(self):
        from cli.endpoints import bracket_ipv6

        assert bracket_ipv6("") == ""


class TestIsIpEndpoint:
    """is_ip_endpoint detects IP-address-based endpoints."""

    def test_ipv4_endpoint_detected(self):
        from cli.endpoints import is_ip_endpoint

        assert is_ip_endpoint("wss://1.2.3.4:9944") is True

    def test_ipv4_no_port_detected(self):
        from cli.endpoints import is_ip_endpoint

        assert is_ip_endpoint("wss://192.168.0.1") is True

    def test_ipv6_bracketed_detected(self):
        from cli.endpoints import is_ip_endpoint

        assert is_ip_endpoint("wss://[2001:db8::1]:443") is True

    def test_domain_not_detected(self):
        from cli.endpoints import is_ip_endpoint

        assert is_ip_endpoint("wss://example.com") is False

    def test_subdomain_not_detected(self):
        from cli.endpoints import is_ip_endpoint

        assert is_ip_endpoint("wss://node.mychain.io:443/ws") is False

    def test_no_hostname_returns_false(self):
        from cli.endpoints import is_ip_endpoint

        assert is_ip_endpoint("not-a-url") is False

    def test_empty_string_returns_false(self):
        from cli.endpoints import is_ip_endpoint

        assert is_ip_endpoint("") is False


class TestInsecureSslContext:
    """insecure_ssl_context returns an SSLContext with hostname/cert checks disabled."""

    def test_returns_ssl_context(self):
        from cli.endpoints import insecure_ssl_context

        ctx = insecure_ssl_context()
        assert isinstance(ctx, ssl.SSLContext)

    def test_hostname_check_disabled(self):
        from cli.endpoints import insecure_ssl_context

        ctx = insecure_ssl_context()
        assert ctx.check_hostname is False

    def test_cert_verification_disabled(self):
        from cli.endpoints import insecure_ssl_context

        ctx = insecure_ssl_context()
        assert ctx.verify_mode == ssl.CERT_NONE

    def test_returns_new_context_each_call(self):
        from cli.endpoints import insecure_ssl_context

        ctx1 = insecure_ssl_context()
        ctx2 = insecure_ssl_context()
        assert ctx1 is not ctx2


class TestTestTls:
    """test_tls wraps socket/SSL handshake and returns (ok, fingerprint, msg)."""

    def test_success_returns_ok_true_and_fingerprint(self):
        from cli.endpoints import test_tls

        fake_der = b"\x01\x02\x03"
        mock_tls = MagicMock()
        mock_tls.getpeercert.return_value = fake_der
        mock_tls.__enter__ = MagicMock(return_value=mock_tls)
        mock_tls.__exit__ = MagicMock(return_value=False)

        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        mock_ctx = MagicMock()
        mock_ctx.wrap_socket.return_value = mock_tls

        with (
            patch("cli.endpoints.socket.create_connection", return_value=mock_sock),
            patch("cli.endpoints.insecure_ssl_context", return_value=mock_ctx),
        ):
            ok, fp, msg = test_tls("example.com", 443)

        assert ok is True
        assert fp is not None
        assert len(fp) == 64  # SHA256 hex digest
        assert msg == "OK"

    def test_connection_error_returns_ok_false(self):
        from cli.endpoints import test_tls

        with patch(
            "cli.endpoints.socket.create_connection",
            side_effect=ConnectionRefusedError("refused"),
        ):
            ok, fp, msg = test_tls("example.com", 443)

        assert ok is False
        assert fp is None
        assert "refused" in msg

    def test_no_cert_returns_none_fingerprint(self):
        from cli.endpoints import test_tls

        mock_tls = MagicMock()
        mock_tls.getpeercert.return_value = None
        mock_tls.__enter__ = MagicMock(return_value=mock_tls)
        mock_tls.__exit__ = MagicMock(return_value=False)

        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        mock_ctx = MagicMock()
        mock_ctx.wrap_socket.return_value = mock_tls

        with (
            patch("cli.endpoints.socket.create_connection", return_value=mock_sock),
            patch("cli.endpoints.insecure_ssl_context", return_value=mock_ctx),
        ):
            ok, fp, msg = test_tls("example.com", 443)

        assert ok is True
        assert fp is None


class TestGetCertFingerprint:
    """get_cert_fingerprint returns fingerprint or None on failure."""

    def test_returns_fingerprint_on_success(self):
        from cli.endpoints import get_cert_fingerprint

        with patch("cli.endpoints.test_tls", return_value=(True, "abc123", "OK")):
            result = get_cert_fingerprint("wss://example.com:443")

        assert result == "abc123"

    def test_returns_none_on_tls_failure(self):
        from cli.endpoints import get_cert_fingerprint

        with patch("cli.endpoints.test_tls", return_value=(False, None, "timeout")):
            result = get_cert_fingerprint("wss://example.com:443")

        assert result is None

    def test_returns_none_when_no_hostname(self):
        from cli.endpoints import get_cert_fingerprint

        result = get_cert_fingerprint("not-a-url")
        assert result is None

    def test_uses_default_port_443(self):
        """Endpoint without port defaults to port 443."""
        from cli.endpoints import get_cert_fingerprint

        with patch("cli.endpoints.test_tls", return_value=(True, "fp", "OK")) as mock:
            get_cert_fingerprint("wss://example.com")
            _, kwargs = mock.call_args
            # test_tls is called positionally; check the second arg (port)
            args = mock.call_args.args
            assert args[1] == 443

    def test_uses_explicit_port(self):
        from cli.endpoints import get_cert_fingerprint

        with patch("cli.endpoints.test_tls", return_value=(True, "fp", "OK")) as mock:
            get_cert_fingerprint("wss://example.com:9944")
            args = mock.call_args.args
            assert args[1] == 9944


# ── cli/testing.py ───────────────────────────────────────────────────────────


class TestParseSystemHealth:
    """_parse_system_health parses JSON-RPC system_health responses."""

    def test_synced_node(self):
        from cli.testing import _parse_system_health

        data = {"result": {"peers": 5, "isSyncing": False}}
        ok, msg = _parse_system_health(data)
        assert ok is True
        assert "peers=5" in msg
        assert "synced" in msg

    def test_syncing_node(self):
        from cli.testing import _parse_system_health

        data = {"result": {"peers": 2, "isSyncing": True}}
        ok, msg = _parse_system_health(data)
        assert ok is True
        assert "syncing" in msg

    def test_missing_peers_uses_question_mark(self):
        from cli.testing import _parse_system_health

        data = {"result": {"isSyncing": False}}
        ok, msg = _parse_system_health(data)
        assert ok is True
        assert "peers=?" in msg

    def test_rpc_error_response(self):
        from cli.testing import _parse_system_health

        data = {"error": {"message": "Method not found"}}
        ok, msg = _parse_system_health(data)
        assert ok is False
        assert "Method not found" in msg

    def test_unexpected_response_format(self):
        from cli.testing import _parse_system_health

        data = {"something": "unexpected"}
        ok, msg = _parse_system_health(data)
        assert ok is False
        assert "RPC error" in msg

    def test_empty_response(self):
        from cli.testing import _parse_system_health

        ok, msg = _parse_system_health({})
        assert ok is False


class TestTestHealth:
    """test_health checks HTTP /health on port 80."""

    def test_200_response_returns_ok(self):
        from cli.testing import test_health

        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch("cli.testing.httpx.get", return_value=mock_response):
            ok, msg = test_health("1.2.3.4")

        assert ok is True
        assert msg == "OK"

    def test_non_200_returns_not_ok(self):
        from cli.testing import test_health

        mock_response = MagicMock()
        mock_response.status_code = 503

        with patch("cli.testing.httpx.get", return_value=mock_response):
            ok, msg = test_health("1.2.3.4")

        assert ok is False
        assert "503" in msg

    def test_connection_error_returns_not_ok(self):
        from cli.testing import test_health

        with patch(
            "cli.testing.httpx.get",
            side_effect=Exception("connection refused"),
        ):
            ok, msg = test_health("1.2.3.4")

        assert ok is False
        assert "connection refused" in msg

    def test_brackets_ipv6_hostname(self):
        """IPv6 address is bracketed before constructing the URL."""
        from cli.testing import test_health

        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch("cli.testing.httpx.get", return_value=mock_response) as mock_get:
            test_health("::1")
            url = mock_get.call_args.args[0]
            assert "[::1]" in url


class TestTestRpc:
    """test_rpc sends system_health RPC over HTTPS."""

    def test_success_returns_ok_and_latency(self):
        from cli.testing import test_rpc

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"result": {"peers": 3, "isSyncing": False}}

        with patch("cli.testing.httpx.post", return_value=mock_response):
            ok, latency, msg = test_rpc("1.2.3.4", 9944, "mysecret")

        assert ok is True
        assert latency is not None
        assert latency > 0
        assert "peers=3" in msg

    def test_401_returns_auth_failure(self):
        from cli.testing import test_rpc

        mock_response = MagicMock()
        mock_response.status_code = 401

        with patch("cli.testing.httpx.post", return_value=mock_response):
            ok, latency, msg = test_rpc("1.2.3.4", 9944, "wrong-secret")

        assert ok is False
        assert latency is None
        assert "Authentication failed" in msg

    def test_non_200_non_401_returns_http_error(self):
        from cli.testing import test_rpc

        mock_response = MagicMock()
        mock_response.status_code = 500

        with patch("cli.testing.httpx.post", return_value=mock_response):
            ok, latency, msg = test_rpc("1.2.3.4", 9944, "secret")

        assert ok is False
        assert "500" in msg

    def test_rpc_error_response_returns_not_ok(self):
        from cli.testing import test_rpc

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"error": {"message": "Method not found"}}

        with patch("cli.testing.httpx.post", return_value=mock_response):
            ok, latency, msg = test_rpc("1.2.3.4", 9944, "secret")

        assert ok is False
        assert latency is None
        assert "Method not found" in msg

    def test_connection_error_returns_not_ok(self):
        from cli.testing import test_rpc

        with patch(
            "cli.testing.httpx.post",
            side_effect=Exception("timeout"),
        ):
            ok, latency, msg = test_rpc("1.2.3.4", 9944, "secret")

        assert ok is False
        assert latency is None
        assert "timeout" in msg

    def test_uses_system_health_payload(self):
        """RPC call sends the canonical system_health payload."""
        from cli.testing import SYSTEM_HEALTH_PAYLOAD, test_rpc

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"result": {"peers": 1, "isSyncing": False}}

        with patch("cli.testing.httpx.post", return_value=mock_response) as mock_post:
            test_rpc("1.2.3.4", 9944, "secret")
            call_kwargs = mock_post.call_args.kwargs
            assert call_kwargs["json"] == SYSTEM_HEALTH_PAYLOAD

    def test_sends_auth_header(self):
        from cli.testing import test_rpc

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"result": {"peers": 1, "isSyncing": False}}

        with patch("cli.testing.httpx.post", return_value=mock_response) as mock_post:
            test_rpc("1.2.3.4", 9944, "mysecret")
            headers = mock_post.call_args.kwargs["headers"]
            assert headers["Authorization"] == "Bearer mysecret"

    def test_brackets_ipv6_in_url(self):
        from cli.testing import test_rpc

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"result": {"peers": 1, "isSyncing": False}}

        with patch("cli.testing.httpx.post", return_value=mock_response) as mock_post:
            test_rpc("::1", 9944, "secret")
            url = mock_post.call_args.args[0]
            assert "[::1]" in url
