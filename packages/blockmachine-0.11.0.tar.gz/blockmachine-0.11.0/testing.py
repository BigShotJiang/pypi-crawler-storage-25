"""Infrastructure testing functions — health, WSS, and RPC connectivity checks."""

import asyncio
import json
import time
from typing import Optional

import httpx

from cli.endpoints import bracket_ipv6, insecure_ssl_context

SYSTEM_HEALTH_PAYLOAD = {
    "jsonrpc": "2.0",
    "method": "system_health",
    "params": [],
    "id": 1,
}


def _parse_system_health(data: dict) -> tuple[bool, str]:
    """Parse system_health RPC response. Return (ok, message)."""
    if "result" in data:
        result = data["result"]
        peers = result.get("peers", "?")
        syncing = result.get("isSyncing", False)
        status = "syncing" if syncing else "synced"
        return True, f"peers={peers}, {status}"
    error = data.get("error", {}).get("message", json.dumps(data))
    return False, f"RPC error: {error}"


def test_health(hostname: str) -> tuple[bool, str]:
    """Test HTTP health endpoint on port 80."""
    try:
        r = httpx.get(
            f"http://{bracket_ipv6(hostname)}/health",
            timeout=10,
            follow_redirects=True,
        )
        if r.status_code == 200:
            return True, "OK"
        return False, f"HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)


def test_wss(
    hostname: str, port: int, secret: str
) -> tuple[bool, Optional[float], str]:
    """Connect via WSS and send system_health RPC.

    Uses self-signed TLS (verification disabled). Mirrors the registry
    liveness checker: WSS connect with auth header, then JSON-RPC over
    the WebSocket. Return (ok, latency_ms, msg).
    """
    try:
        import websockets
        from websockets.exceptions import InvalidHandshake
    except ImportError:
        return False, None, "websockets not installed (pip install websockets)"

    url = f"wss://{bracket_ipv6(hostname)}:{port}"
    ctx = insecure_ssl_context()
    headers = {"Authorization": f"Bearer {secret}"}
    payload = json.dumps(SYSTEM_HEALTH_PAYLOAD)

    async def _run() -> tuple[bool, Optional[float], str]:
        try:
            async with asyncio.timeout(15):
                start = time.monotonic()
                async with websockets.connect(
                    url,
                    ssl=ctx,
                    additional_headers=headers,
                    open_timeout=10,
                ) as ws:
                    await ws.send(payload)
                    raw = await asyncio.wait_for(ws.recv(), timeout=5)
                    latency = (time.monotonic() - start) * 1000
                    data = json.loads(raw)
                    ok, msg = _parse_system_health(data)
                    return ok, latency, msg
        except asyncio.TimeoutError:
            return False, None, "Connection timeout"
        except InvalidHandshake as e:
            return False, None, f"WebSocket handshake failed: {e}"
        except Exception as e:
            return False, None, str(e)

    return asyncio.run(_run())


def test_rpc(
    hostname: str, port: int, secret: str
) -> tuple[bool, Optional[float], str]:
    """Send system_health RPC over HTTPS. Return (ok, latency_ms, message)."""
    url = f"https://{bracket_ipv6(hostname)}:{port}"
    try:
        start = time.monotonic()
        r = httpx.post(
            url,
            json=SYSTEM_HEALTH_PAYLOAD,
            headers={"Authorization": f"Bearer {secret}"},
            timeout=10,
            verify=False,
        )
        latency = (time.monotonic() - start) * 1000
        if r.status_code == 401:
            return False, None, "Authentication failed (secret mismatch)"
        if r.status_code != 200:
            return False, None, f"HTTP {r.status_code}"
        ok, msg = _parse_system_health(r.json())
        return ok, latency if ok else None, msg
    except Exception as e:
        return False, None, str(e)
