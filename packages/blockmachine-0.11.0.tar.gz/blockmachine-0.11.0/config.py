"""CLI configuration management — wraps shared auth config with CLI concerns."""

import logging
from typing import Optional

import jwt

from cli import settings
from cli.auth_config import (
    AuthConfig,
    NetworkEntry,
    TokenEntry,
    get_config_dir,
    get_config_path,
    load_auth_config,
    save_auth_config,
)

logger = logging.getLogger(__name__)

_jwks_client: jwt.PyJWKClient | None = None

# Re-export for existing callers
__all__ = [
    "CLIConfig",
    "get_config_dir",
    "get_config_path",
    "load_config",
    "save_config",
    "validate_token",
    "is_token_valid",
    "clear_token",
]


def _get_jwks_client() -> jwt.PyJWKClient:
    global _jwks_client
    if _jwks_client is None:
        _jwks_client = jwt.PyJWKClient(
            settings.jwks_uri(),
            headers={"User-Agent": settings.user_agent()},
        )
    return _jwks_client


class CLIConfig:
    """CLI-facing config that delegates to AuthConfig.

    Maintains backward compatibility: callers set active network/role,
    then access .access_token, .refresh_token, etc. as properties.
    """

    def __init__(
        self,
        auth: Optional[AuthConfig] = None,
        *,
        # Legacy kwargs for backward compatibility (tests, direct construction)
        access_token: Optional[str] = None,
        refresh_token: Optional[str] = None,
        token_expires_at: Optional[str] = None,
        api_url: Optional[str] = None,
        auth_url: Optional[str] = None,
        client_id: Optional[str] = None,
        active_miner_node: Optional[str] = None,
    ):
        self._auth = auth or AuthConfig()
        self._network = settings.network_name()
        self._role = "miner"

        if active_miner_node is not None:
            self._auth.active_miner_node = active_miner_node
        if access_token is not None:
            self.access_token = access_token
        if refresh_token is not None:
            self.refresh_token = refresh_token
        if token_expires_at is not None:
            self.token_expires_at = token_expires_at
        if api_url is not None:
            self.api_url = api_url
        if auth_url is not None:
            self.auth_url = auth_url
        if client_id is not None:
            self.client_id = client_id

    def set_role(self, role: str) -> None:
        self._role = role

    @property
    def active_miner_node(self) -> Optional[str]:
        return self._auth.active_miner_node

    @active_miner_node.setter
    def active_miner_node(self, value: Optional[str]) -> None:
        self._auth.active_miner_node = value

    def _net(self) -> NetworkEntry:
        return self._auth.get_network(self._network)

    def _tok(self) -> TokenEntry:
        return self._auth.get_token(self._network, self._role) or TokenEntry()

    def _ensure_tok(self) -> TokenEntry:
        entry = self._auth.get_token(self._network, self._role)
        if entry is None:
            entry = TokenEntry()
            self._auth.set_token(self._network, self._role, entry)
        return entry

    # -- Network-level settings (config override > app default) --

    @property
    def auth_url(self) -> str:
        return self._net().auth_url or settings.auth_url()

    @auth_url.setter
    def auth_url(self, value: Optional[str]) -> None:
        self._net().auth_url = value

    @property
    def api_url(self) -> str:
        return self._net().api_url or settings.api_url()

    @api_url.setter
    def api_url(self, value: Optional[str]) -> None:
        self._net().api_url = value

    @property
    def client_id(self) -> str:
        return self._net().client_id or settings.client_id()

    @client_id.setter
    def client_id(self, value: Optional[str]) -> None:
        self._net().client_id = value

    # -- Token accessors --

    @property
    def access_token(self) -> Optional[str]:
        return self._tok().access_token

    @access_token.setter
    def access_token(self, value: Optional[str]) -> None:
        self._ensure_tok().access_token = value

    @property
    def refresh_token(self) -> Optional[str]:
        return self._tok().refresh_token

    @refresh_token.setter
    def refresh_token(self, value: Optional[str]) -> None:
        self._ensure_tok().refresh_token = value

    @property
    def token_expires_at(self) -> Optional[str]:
        return self._tok().token_expires_at

    @token_expires_at.setter
    def token_expires_at(self, value: Optional[str]) -> None:
        self._ensure_tok().token_expires_at = value

    @property
    def networks(self) -> dict[str, NetworkEntry]:
        return self._auth.networks


def load_config() -> CLIConfig:
    return CLIConfig(load_auth_config())


def save_config(config: CLIConfig) -> None:
    save_auth_config(config._auth)


# -- Token validation --


def _fetch_signing_key(token: str) -> jwt.PyJWK:
    """Fetch the signing key, falling back to the sole key when kid is absent."""
    global _jwks_client
    try:
        return _get_jwks_client().get_signing_key_from_jwt(token)
    except (jwt.PyJWKClientError, jwt.PyJWKClientConnectionError):
        logger.info("JWKS key lookup failed, refreshing cached client")
        _jwks_client = None
        try:
            return _get_jwks_client().get_signing_key_from_jwt(token)
        except jwt.PyJWKClientError:
            jwk_set = _get_jwks_client().get_jwk_set()
            if len(jwk_set.keys) == 1:
                return jwk_set.keys[0]
            raise


def validate_token(token: str) -> dict | None:
    """Validate a JWT against the JWKS and expected issuer."""
    try:
        signing_key = _fetch_signing_key(token)
        return jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=settings.auth_url(),
            audience=settings.AUDIENCE,
            options={"require": ["exp", "iss", "sub"]},
        )
    except jwt.ExpiredSignatureError:
        logger.debug("Token expired (JWT exp claim)")
        return None
    except jwt.InvalidIssuerError:
        logger.warning("Token issuer mismatch")
        return None
    except jwt.PyJWTError as e:
        logger.warning("JWT validation failed: %s", e)
        return None


def is_token_valid(config: CLIConfig) -> bool:
    """Check if the active token is valid via JWT signature + issuer."""
    if not config.access_token:
        return False
    return validate_token(config.access_token) is not None


def clear_token(config: CLIConfig) -> CLIConfig:
    """Clear tokens for the active role on the active network."""
    net = config._auth.networks.get(config._network)
    if net and config._role in net.tokens:
        del net.tokens[config._role]
    save_config(config)
    return config
