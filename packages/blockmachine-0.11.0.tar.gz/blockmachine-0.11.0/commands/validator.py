"""Validator commands: authentication for the verification gateway"""

import typer
from rich.console import Console

from cli import settings
from cli.commands.auth import device_login, save_token

app = typer.Typer(help="Validator authentication")

console = Console()


@app.command("login")
def login(
    client_id: str = typer.Option(None, "--client-id", help="OAuth client ID"),
    auth_url: str = typer.Option(None, "--auth-url", help="TaoStats auth URL"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Don't auto-open browser"
    ),
) -> None:
    """Login with validator scopes for the verification gateway."""
    resolved_client_id = client_id or settings.client_id()
    resolved_auth_url = auth_url or settings.auth_url()

    token_data = device_login(
        scopes=settings.validator_scopes(),
        client_id=resolved_client_id,
        auth_url=resolved_auth_url,
        no_browser=no_browser,
    )

    save_token(
        token_data,
        "validator",
        client_id=resolved_client_id,
        auth_url=resolved_auth_url,
    )

    console.print("[dim]Restart the validator to pick up the new tokens.[/dim]")
