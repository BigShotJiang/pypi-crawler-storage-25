from __future__ import annotations

import os


def ensure_huggingface_hub_compat() -> None:
    try:
        import huggingface_hub as huggingface_hub
    except ImportError:
        return

    if hasattr(huggingface_hub, "is_offline_mode"):
        return

    def _is_offline_mode() -> bool:
        value = os.environ.get("HF_HUB_OFFLINE", "")
        return value.strip().lower() in {"1", "true", "yes", "on"}

    huggingface_hub.is_offline_mode = _is_offline_mode

    try:
        from huggingface_hub import dataclasses as huggingface_hub_dataclasses
    except ImportError:
        return

    if hasattr(huggingface_hub_dataclasses, "validate_typed_dict"):
        return

    def _validate_typed_dict(*args, **kwargs):  # type: ignore[no-untyped-def]
        if args:
            return args[0]
        return kwargs.get("value")

    huggingface_hub_dataclasses.validate_typed_dict = _validate_typed_dict
