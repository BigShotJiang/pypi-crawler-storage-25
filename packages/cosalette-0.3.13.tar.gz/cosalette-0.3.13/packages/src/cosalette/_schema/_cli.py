"""CLI subcommands for schema validation and tooling.

Provides ``cosalette schema validate|check|dump|init|slice``
subcommands for static validation, CI gating, and schema generation.

AsyncAPI conversion utilities live in :mod:`cosalette._schema._asyncapi`.

See Also:
    ADR-033 — MQTT schema enforcement.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from cosalette._constants import EXIT_CONFIG_ERROR, EXIT_OK
from cosalette._introspect import build_registry_snapshot
from cosalette._schema._asyncapi import (
    _registry_to_asyncapi_dict,
    _snapshot_to_asyncapi,
)
from cosalette._schema._cli_helpers import (
    _import_app,
    _load_schema_or_exit,
    _print_check_results,
)
from cosalette._schema._enforcement import _validate_registrations

# ---------------------------------------------------------------------------
# Schema subcommand group
# ---------------------------------------------------------------------------

schema_app = typer.Typer(help="Schema validation and tooling.")


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@schema_app.command()
def validate(
    path: Annotated[
        Path,
        typer.Argument(
            help="Path to AsyncAPI schema file",
            exists=True,
            file_okay=True,
            readable=True,
        ),
    ],
) -> None:
    """Validate an AsyncAPI schema document.

    Loads and validates the schema file, checking for structural
    correctness and cosalette-specific extensions.
    """
    registry = _load_schema_or_exit(path)

    # For network-level schemas, we need to get the title from the original document
    # since registry.app_name is set to None for network schemas
    if registry.enforcement.network_level and registry.app_name is None:
        # Load the YAML again to get the title - this double-read is intentional
        # as the SchemaRegistry doesn't preserve the original title for network schemas
        try:
            import yaml
        except ImportError as exc:
            typer.echo(
                "Error: PyYAML is required for this command.\n\n"
                "Hint: Install schema dependencies with: pip install cosalette[schema]",
                err=True,
            )
            raise typer.Exit(EXIT_CONFIG_ERROR) from exc

        yaml_content = path.read_text(encoding="utf-8")
        doc = yaml.safe_load(yaml_content)
        title = doc.get("info", {}).get("title", "(untitled)")
    else:
        title = registry.app_name or "(untitled)"

    # Print summary
    typer.echo(f"✅ Schema validated: {title} v{registry.app_version}")
    typer.echo(f"   AsyncAPI version: {registry.asyncapi_version}")
    typer.echo(f"   Channels: {len(registry.channels)}")

    if registry.enforcement.network_level:
        app_count = len(registry.all_app_names())
        typer.echo(f"   Apps in network: {app_count}")
        typer.echo("   Schema type: network-level")
    else:
        typer.echo("   Schema type: single-app")

    raise typer.Exit(EXIT_OK)


@schema_app.command()
def slice(
    network: Annotated[
        Path,
        typer.Option(
            "--network",
            help="Path to network-level schema file",
            exists=True,
            file_okay=True,
            readable=True,
        ),
    ],
    app: Annotated[
        str,
        typer.Option("--app", help="App name to extract from network schema"),
    ],
) -> None:
    """Extract app portion from network schema.

    Filters a network-level schema to include only channels relevant
    to the specified app, outputting the result as YAML.
    """
    registry = _load_schema_or_exit(network)

    # Verify this is a network-level schema
    if not registry.enforcement.network_level:
        typer.echo(
            "Error: Schema is not network-level. Use --network flag only with "
            "schemas that have x-cosalette-enforcement.network_level: true",
            err=True,
        )
        raise typer.Exit(EXIT_CONFIG_ERROR)

    # Check if app exists in schema
    available_apps = registry.all_app_names()
    if app not in available_apps:
        typer.echo(
            f"Error: App '{app}' not found in schema. "
            f"Available apps: {', '.join(sorted(available_apps))}",
            err=True,
        )
        raise typer.Exit(EXIT_CONFIG_ERROR)

    # Filter for the specified app
    filtered_registry = registry.filter_for_app(app)

    # Convert back to AsyncAPI dict and output as YAML
    try:
        import yaml
    except ImportError as exc:
        typer.echo(
            "Error: PyYAML is required for this command.\n\n"
            "Hint: Install schema dependencies with: pip install cosalette[schema]",
            err=True,
        )
        raise typer.Exit(EXIT_CONFIG_ERROR) from exc

    output_dict = _registry_to_asyncapi_dict(filtered_registry)
    yaml_output = yaml.safe_dump(output_dict, default_flow_style=False, sort_keys=False)
    typer.echo(yaml_output.rstrip())

    raise typer.Exit(EXIT_OK)


@schema_app.command()
def check(
    app_spec: Annotated[
        str, typer.Option("--app", help="App import spec (module:attr)")
    ],
    schema_path: Annotated[
        Path,
        typer.Option(
            "--schema",
            help="Path to schema file",
            exists=True,
            file_okay=True,
            readable=True,
        ),
    ],
) -> None:
    """Check app registrations against schema (CI gate).

    Imports the specified app, extracts its registrations, loads the schema,
    and validates that all schema-expected devices are registered.
    Returns exit code 0 for compliance, 1 for violations.
    """
    # Import the app
    app = _import_app(app_spec)

    # Extract registered names
    registered_names = app.registered_names()

    # Load schema
    registry = _load_schema_or_exit(schema_path)

    # For network-level schemas, filter to this app's slice
    if registry.enforcement.network_level:
        # Verify the app exists in the schema
        available_apps = registry.all_app_names()
        app_name = app.name
        if app_name not in available_apps:
            typer.echo(
                f"Error: App '{app_name}' not found in schema. "
                f"Available apps: {', '.join(sorted(available_apps))}",
                err=True,
            )
            raise typer.Exit(EXIT_CONFIG_ERROR)

        # Filter for the app
        registry = registry.filter_for_app(app_name)

    # Validate registrations
    violations = _validate_registrations(registered_names, registry)

    # Print results and exit
    _print_check_results(registered_names, registry, violations, schema_path, app.name)


@schema_app.command()
def dump(
    app_spec: Annotated[
        str, typer.Option("--app", help="App import spec (module:attr)")
    ],
) -> None:
    """Generate AsyncAPI YAML from app's registry.

    Imports the specified app, extracts its registrations via introspection,
    and converts them to a minimal AsyncAPI 3.0.0 document.
    """
    # Import the app
    app = _import_app(app_spec)

    # Build registry snapshot
    snapshot = build_registry_snapshot(app)

    # Convert to AsyncAPI dict
    asyncapi_dict = _snapshot_to_asyncapi(
        app_name=snapshot["app"]["name"],
        app_version=snapshot["app"]["version"],
        snapshot=snapshot,
        include_extensions=False,
    )

    # Output as YAML
    import yaml

    yaml_output = yaml.safe_dump(
        asyncapi_dict, default_flow_style=False, sort_keys=False
    )
    typer.echo(yaml_output.rstrip())

    raise typer.Exit(EXIT_OK)


@schema_app.command()
def init(
    app_spec: Annotated[
        str, typer.Option("--app", help="App import spec (module:attr)")
    ],
) -> None:
    """Generate starter schema with cosalette extensions.

    Like dump but scaffolded for editing — includes x-cosalette-enforcement
    section and archetype extensions on channels for user customization.
    """
    # Import the app
    app = _import_app(app_spec)

    # Build registry snapshot
    snapshot = build_registry_snapshot(app)

    # Convert to AsyncAPI dict with extensions
    asyncapi_dict = _snapshot_to_asyncapi(
        app_name=snapshot["app"]["name"],
        app_version=snapshot["app"]["version"],
        snapshot=snapshot,
        include_extensions=True,
    )

    # Output as YAML
    import yaml

    yaml_output = yaml.safe_dump(
        asyncapi_dict, default_flow_style=False, sort_keys=False
    )
    typer.echo(yaml_output.rstrip())

    raise typer.Exit(EXIT_OK)


@schema_app.command()
def acl(
    schema_path: Annotated[Path, typer.Argument(help="Path to AsyncAPI schema file.")],
    format_name: Annotated[
        str, typer.Option("--format", "-f", help="Broker format.")
    ] = "mosquitto",
) -> None:
    """Generate broker ACL configuration from schema."""
    from cosalette._schema._acl import FORMATTERS, derive_acl_principals

    if format_name not in FORMATTERS:
        available = ", ".join(sorted(FORMATTERS))
        typer.echo(
            f"Unknown format: {format_name}. Available: {available}",
            err=True,
        )
        raise typer.Exit(EXIT_CONFIG_ERROR)

    registry = _load_schema_or_exit(schema_path)
    principals = derive_acl_principals(registry)
    output = FORMATTERS[format_name](principals)
    typer.echo(output)


@schema_app.command(name="ha-discovery")
def ha_discovery(
    schema_path: Annotated[Path, typer.Argument(help="Path to AsyncAPI schema file.")],
    prefix: Annotated[
        str, typer.Option("--prefix", "-p", help="Discovery topic prefix.")
    ] = "homeassistant",
    format_name: Annotated[
        str, typer.Option("--format", "-f", help="Output format (json or yaml).")
    ] = "json",
) -> None:
    """Generate Home Assistant MQTT discovery payloads from schema."""
    from cosalette._schema._consumer_gen import (
        HaDiscoveryGenerator,
        ha_discovery_to_json,
    )

    if format_name not in ("json", "yaml"):
        typer.echo(f"Unknown format: {format_name}. Available: json, yaml", err=True)
        raise typer.Exit(EXIT_CONFIG_ERROR)

    registry = _load_schema_or_exit(schema_path)
    generator = HaDiscoveryGenerator(registry=registry, discovery_prefix=prefix)
    payloads = generator.generate()

    if format_name == "json":
        typer.echo(ha_discovery_to_json(payloads))
    else:
        try:
            import yaml
        except ImportError as exc:
            typer.echo(
                "Error: PyYAML is required for YAML output.\n\n"
                "Hint: Install schema dependencies with:"
                " pip install cosalette[schema]",
                err=True,
            )
            raise typer.Exit(EXIT_CONFIG_ERROR) from exc

        data = [{"topic": p.topic, "config": p.config} for p in payloads]
        typer.echo(
            yaml.safe_dump(data, default_flow_style=False, sort_keys=False).rstrip()
        )


@schema_app.command()
def openhab(
    schema_path: Annotated[Path, typer.Argument(help="Path to AsyncAPI schema file.")],
    broker_uid: Annotated[
        str, typer.Option("--broker-uid", "-b", help="OpenHAB broker Thing UID.")
    ] = "broker",
    output: Annotated[
        str, typer.Option("--output", "-o", help="Output: things, items, or both.")
    ] = "both",
) -> None:
    """Generate OpenHAB .things/.items configuration from schema."""
    from cosalette._schema._consumer_gen import OpenHabGenerator

    if output not in ("things", "items", "both"):
        typer.echo(
            f"Unknown output: {output}. Available: things, items, both",
            err=True,
        )
        raise typer.Exit(EXIT_CONFIG_ERROR)

    registry = _load_schema_or_exit(schema_path)
    generator = OpenHabGenerator(registry=registry, broker_uid=broker_uid)

    if output in ("things", "both"):
        typer.echo(generator.generate_things())
    if output == "both":
        typer.echo("// ---")
        typer.echo()
    if output in ("items", "both"):
        typer.echo(generator.generate_items())


@schema_app.command()
def monitor(
    schema_path: Annotated[
        Path, typer.Argument(help="Path to network-level AsyncAPI schema.")
    ],
    broker: Annotated[
        str, typer.Option("--broker", "-b", help="MQTT broker host:port.")
    ] = "localhost:1883",
    timeout: Annotated[
        float, typer.Option("--timeout", "-t", help="Collection period in seconds.")
    ] = 10.0,
) -> None:
    """Monitor fleet schema compliance via MQTT."""
    import asyncio

    from cosalette._schema._monitor import run_monitor

    registry = _load_schema_or_exit(schema_path)

    if not registry.enforcement.network_level:
        typer.echo("Warning: schema is not marked as network_level", err=True)

    typer.echo(f"Monitoring {broker} for {timeout}s...")
    typer.echo(f"Expected apps: {', '.join(sorted(registry.all_app_names()))}")
    typer.echo()

    report = asyncio.run(run_monitor(broker, registry, timeout=timeout))
    typer.echo(report.summary())

    if report.non_compliant or report.offline:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# CLI entry point (for standalone usage)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    schema_app()
