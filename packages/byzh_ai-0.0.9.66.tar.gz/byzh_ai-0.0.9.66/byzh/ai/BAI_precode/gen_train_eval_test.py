from jinja2 import Environment

PART_IMPORT = \
r"""
import os
import time
import torch

from byzh.core.Btqdm import B_ModernBar
from byzh.ai.Butils import b_get_device

from .plot import plot_metrics, plot_matrix
from .utils import save_checkpoint, load_checkpoint
{% if use_spikingjelly %}

from spikingjelly.activation_based import functional
from spikingjelly.activation_based import neuron, surrogate
from spikingjelly.activation_based import layer
{% else %}
{% endif %}
"""

PART_TRAIN_ONCE = \
r"""
def train_once(dataloader, model, optimizer, criterion, epoch, epochs, device='cuda'):
    model.train()

    # logger
    iters = len(dataloader)
    logger = B_ModernBar(
        total=iters,
        headers=['epoch', 'iter', 'loss'],
        widths=[8, 10, 10],
        prefix=['┌ ', '│ ', '│ ']
    )

    correct_num, total_num = 0, 0
    loss_sum = 0.0
    for i, (inputs, labels) in enumerate(dataloader):
        inputs = inputs.to(device)
        labels = labels.to(device)

        # forward
        outputs = model(inputs)

        # backward
        optimizer.zero_grad()
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
{% if use_spikingjelly %}

        # spikingjelly
        functional.reset_net(model)
        
{% else %}
        
{% endif %}
        # 统计
        loss_sum += loss.item()

        preds = outputs.argmax(dim=1)
        correct_num += (preds == labels).sum().item()
        total_num += labels.size(0)

        # logger
        logger.update(i, {
            'epoch': f'{epoch}/{epochs}',
            'iter': f'{i}/{iters}',
            'loss': loss.item(),
        })

    train_acc = correct_num / total_num
    train_loss = loss_sum / len(dataloader)

    return train_acc, train_loss
"""

PART_EVAL_ONCE = \
r"""
@torch.no_grad()
def eval_once(dataloader, model, criterion, device='cuda'):
    model.eval()

    correct_num, total_num = 0, 0
    loss_sum = 0.0

    for inputs, labels in dataloader:
        inputs = inputs.to(device)
        labels = labels.to(device)

        # forward
        outputs = model(inputs)
        eval_loss = criterion(outputs, labels)
{% if use_spikingjelly %}

        # spikingjelly
        functional.reset_net(model)
        
{% else %}
        
{% endif %}
        # 统计
        loss_sum += eval_loss.item()

        preds = outputs.argmax(dim=1)
        correct_num += (preds == labels).sum().item()
        total_num += labels.size(0)

    eval_acc = correct_num / total_num
    eval_loss = loss_sum / len(dataloader)

    return eval_acc, eval_loss
"""

PART_TEST_ONCE = \
r"""
@torch.no_grad()
def test_once(dataloader, model, criterion, device='cuda'):
    model.eval()

    correct_num, total_num = 0, 0
    loss_sum = 0.0
    
    all_preds = []
    all_labels = []
    
    for inputs, labels in dataloader:
        inputs = inputs.to(device)
        labels = labels.to(device)

        # forward
        outputs = model(inputs)
        eval_loss = criterion(outputs, labels)
{% if use_spikingjelly %}

        # spikingjelly
        functional.reset_net(model)
        
{% else %}
        
{% endif %}
        # 统计
        loss_sum += eval_loss.item()

        preds = outputs.argmax(dim=1)
        correct_num += (preds == labels).sum().item()
        total_num += labels.size(0)
        
        all_preds.extend(
            preds.cpu().numpy()
        )

        all_labels.extend(
            labels.cpu().numpy()
        )
        
    test_acc = correct_num / total_num
    test_loss = loss_sum / len(dataloader)
    print('\n[Test]')
    print(f'    acc: {test_acc:.4f}, loss: {test_loss:.4f}')

    return test_acc, test_loss, all_labels, all_preds
"""

PART_TRAIN_EVAL = \
r"""
def train_eval(
    epochs,
    train_loader, val_loader,
    model, optimizer, criterion,
    device,
    ckpt_dir
):
    best_acc = 0.0

    train_acc_lst, train_loss_lst = [], []
    val_acc_lst, val_loss_lst = [], []

    for epoch in range(1, epochs + 1):
        print(f'===== Epoch {epoch} =====')
        train_acc, train_loss = train_once(train_loader, model, optimizer, criterion, epoch, epochs, device)
        val_acc, val_loss = eval_once(val_loader, model, criterion, device)

        train_acc_lst.append(train_acc)
        val_acc_lst.append(val_acc)
        train_loss_lst.append(train_loss)
        val_loss_lst.append(val_loss)

        print(f'│   Train -> acc: {train_acc:.4f}, loss: {train_loss:.4f}')
        print(f'└   Val   -> acc: {val_acc:.4f}, loss: {val_loss:.4f}')

        # ===== 保存 last checkpoint =====
        save_checkpoint(
            save_path=os.path.join(ckpt_dir, 'last.pth'),
            epoch=epoch,
            model=model,
            optimizer=optimizer,
            best_metric=best_acc,
        )

        # ===== 保存 best checkpoint =====
        if val_acc > best_acc:
            best_acc = val_acc

            save_checkpoint(
                save_path=os.path.join(ckpt_dir, 'best.pth'),
                epoch=epoch,
                model=model,
                optimizer=optimizer,
                best_metric=best_acc,
            )

            print(f'[*] Best model saved! acc={best_acc:.4f}')

    return train_acc_lst, train_loss_lst, val_acc_lst, val_loss_lst
"""

PART_TRAIN_EVAL_TEST = \
r"""
def train_eval_test(
    epochs,
    train_loader, val_loader, test_loader,
    model, optimizer, criterion,
    device,
    save_dir
):
    os.makedirs(os.path.join(save_dir, 'plots'), exist_ok=True)
    os.makedirs(os.path.join(save_dir, 'checkpoints'), exist_ok=True)

    # ==== train_eval ====
    train_acc_lst, train_loss_lst, val_acc_lst, val_loss_lst = train_eval(
        epochs,
        train_loader,
        val_loader,
        model,
        optimizer,
        criterion,
        device,
        os.path.join(save_dir, 'checkpoints')
    )
    # loss-acc
    plt = plot_metrics(epochs, train_acc_lst, train_loss_lst, val_acc_lst, val_loss_lst)
    plt.savefig(os.path.join(save_dir, 'plots', 'metrics.png'), bbox_inches='tight')
    plt.close()

    # ==== test ====
    test_acc, test_loss, all_labels, all_preds = test_once(test_loader, model, criterion, device)
    # matrix
    plt = plot_matrix(all_labels, all_preds)
    plt.savefig(os.path.join(save_dir, 'plots', 'matrix.png'), bbox_inches='tight')
    plt.close()
"""

def process_strings(*args):
    args_lst = []
    for x in args:
        args_lst.append(x.strip())

    return "\n\n".join(args_lst)

def b_gen_train_eval_test(train_path, use_spikingjelly=False):
    env = Environment(
        trim_blocks=True,
        lstrip_blocks=True,
    )

    template_text = process_strings(
        """
#######################################
# Train_Eval_Test
#######################################
        """,
        PART_IMPORT,
        PART_TRAIN_ONCE,
        PART_EVAL_ONCE,
        PART_TEST_ONCE,
        PART_TRAIN_EVAL,
        PART_TRAIN_EVAL_TEST,
    )

    template = env.from_string(template_text)

    code = template.render(
        use_spikingjelly=use_spikingjelly
    )

    with open(train_path, mode="w", encoding="utf-8") as f:
        f.write(code)

if __name__ == '__main__':
    b_gen_train_eval_test(r'E:\byzh_workingplace\byzh-rc-to-pypi\awa1.py')