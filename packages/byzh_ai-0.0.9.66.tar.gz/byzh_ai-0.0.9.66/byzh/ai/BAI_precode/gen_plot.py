from jinja2 import Environment

PLOT_IMPORT = \
r"""
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文
plt.rcParams['axes.unicode_minus'] = False    # 负号

from sklearn.metrics import confusion_matrix
"""

PLOT_METRICS = \
r"""
def plot_metrics(
    epochs,
    train_acc_lst,
    train_loss_lst,
    val_acc_lst,
    val_loss_lst,
):
    x = list(range(1, epochs + 1))

    # 创建 1x2 子图
    fig, axes = plt.subplots(
        nrows=1,
        ncols=2,
        figsize=(12, 4)
    )

    # =========================
    # Loss
    # =========================
    ax = axes[0]
    ax.plot(
        x,
        train_loss_lst,
        label='Train Loss',
        marker='o'
    )
    ax.plot(
        x,
        val_loss_lst,
        label='Val Loss',
        marker='s'
    )
    ax.set_title('Loss 曲线')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Loss')
    ax.legend()
    ax.grid(True)

    # =========================
    # Accuracy
    # =========================
    ax = axes[1]
    ax.plot(
        x,
        train_acc_lst,
        label='Train Acc',
        marker='o'
    )
    ax.plot(
        x,
        val_acc_lst,
        label='Val Acc',
        marker='s'
    )
    ax.set_title('Accuracy 曲线')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Accuracy')
    ax.legend()
    ax.grid(True)

    fig.tight_layout()
    return plt
"""

PLOT_MATRIX = \
r"""
def plot_matrix(
    y_true,
    y_pred,
    class_names=None,
    normalize=False,
    title='Confusion Matrix',
):
    cm = confusion_matrix(y_true, y_pred)

    if normalize:
        cm = cm.astype(np.float32)
        cm = cm / cm.sum(
            axis=1,
            keepdims=True
        )

    if class_names is None:
        num_classes = cm.shape[0]
        class_names = [
            str(i)
            for i in range(num_classes)
        ]

    fig, ax = plt.subplots(
        figsize=(6, 5)
    )

    sns.heatmap(
        cm,
        annot=True,
        fmt='.2f' if normalize else 'd',
        cmap='Blues',
        xticklabels=class_names,
        yticklabels=class_names,
        ax=ax,
    )

    ax.set_xlabel('预测类别')
    ax.set_ylabel('真实类别')
    ax.set_title(title)

    fig.tight_layout()
    return plt
"""

def process_strings(*args):
    args_lst = []
    for x in args:
        args_lst.append(x.strip())

    return "\n\n".join(args_lst)

def b_gen_plot(plot_path):
    env = Environment(
        trim_blocks=True,
        lstrip_blocks=True,
    )

    template_text = process_strings(
        """
#######################################
# Plot
#######################################
        """,
        PLOT_IMPORT,
        PLOT_METRICS,
        PLOT_MATRIX,
    )

    template = env.from_string(template_text)

    code = template.render(
        use_spikingjelly=True
    )

    with open(plot_path, mode="w", encoding="utf-8") as f:
        f.write(code)

if __name__ == '__main__':
    b_gen_plot(r'E:\byzh_workingplace\byzh-rc-to-pypi\awa2.py')