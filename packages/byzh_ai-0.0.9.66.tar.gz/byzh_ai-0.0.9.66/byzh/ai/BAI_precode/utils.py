import torch

def save_checkpoint(
    save_path,
    epoch,
    model,
    optimizer,
    best_metric=None,
):
    ckpt = {
        'epoch': epoch,
        'model': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'best_metric': best_metric,
    }

    torch.save(ckpt, save_path)

def load_checkpoint(
    ckpt_path,
    model,
    optimizer=None,
    map_location='cpu'
):
    ckpt = torch.load(
        ckpt_path,
        map_location=map_location
    )

    model.load_state_dict(ckpt['model'])

    if optimizer is not None:
        optimizer.load_state_dict(ckpt['optimizer'])

    epoch = ckpt.get('epoch', 0)
    best_metric = ckpt.get('best_metric', None)

    return epoch, best_metric