from jinja2 import Environment

UTILS_IMPORT = \
r"""
import torch

def save_checkpoint(
    save_path,
    epoch,
    model,
    optimizer,
    best_metric=None,
):
    ckpt = {
        'epoch': epoch,
        'model': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'best_metric': best_metric,
    }

    torch.save(ckpt, save_path)
    
def load_checkpoint(
    ckpt_path,
    model,
    optimizer=None,
    map_location='cpu'
):
    ckpt = torch.load(
        ckpt_path,
        map_location=map_location
    )

    model.load_state_dict(ckpt['model'])

    if optimizer is not None:
        optimizer.load_state_dict(ckpt['optimizer'])

    epoch = ckpt.get('epoch', 0)
    best_metric = ckpt.get('best_metric', None)

    return epoch, best_metric
"""


def process_strings(*args):
    args_lst = []
    for x in args:
        args_lst.append(x.strip())

    return "\n\n".join(args_lst)

def b_gen_utils(utils_path):
    env = Environment(
        trim_blocks=True,
        lstrip_blocks=True,
    )

    template_text = process_strings(
        """
#######################################
# Utils
#######################################
        """,
        UTILS_IMPORT,
    )

    template = env.from_string(template_text)

    code = template.render(
        use_spikingjelly=True
    )

    with open(utils_path, mode="w", encoding="utf-8") as f:
        f.write(code)

if __name__ == '__main__':
    b_gen_utils(r'E:\byzh_workingplace\byzh-rc-to-pypi\awa3.py')