#######################################
# 训练train - 验证eval - 测试test
# 1. model.train()和model.eval()是模型行为开关 -> (Dropout, BatchNorm)
#    - train时Dropout, 神经元随机失活
#    - eval时Dropout, 不生效
#    - train时BatchNorm, 使用`当前这个batch的 均值&方差`
#    - eval时BatchNorm, 使用`训练阶段积累的 running_mean / running_var`
# 2. @torch.no_grad()是自动求导开关 -> (要不要构建计算图, 能不能反向传播)
#    - 默认情况: 记录所有计算, 保存中间变量, 为 backward 做准备
#    - no_grad()情况: 不记录计算图, 不存中间梯度 -> 更快, 更省显存
#######################################

#######################################
# 脉冲神经网络:
# from spikingjelly.activation_based import functional
# from spikingjelly.activation_based import neuron, surrogate
# from spikingjelly.activation_based import layer
#######################################

import os
import time
import torch

from byzh.core.Btqdm import B_ModernBar
from byzh.ai.Butils import b_get_device

from .plot import plot_metrics, plot_matrix
from .utils import save_checkpoint, load_checkpoint

def train_once(dataloader, model, optimizer, criterion, epoch, epochs, device='cuda'):
    model.train()

    # logger
    iters = len(dataloader)
    logger = B_ModernBar(
        total=iters,
        headers=['epoch', 'iter', 'loss'],
        widths=[8, 10, 10],
        prefix=['┌ ', '│ ', '│ ']
    )

    correct_num, total_num = 0, 0
    loss_sum = 0.0
    for i, (inputs, labels) in enumerate(dataloader):
        inputs = inputs.to(device)
        labels = labels.to(device)

        # forward
        outputs = model(inputs)

        # backward
        optimizer.zero_grad()
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        # spikingjelly
        # functional.reset_net(model)

        # 统计
        loss_sum += loss.item()

        preds = outputs.argmax(dim=1)
        correct_num += (preds == labels).sum().item()
        total_num += labels.size(0)

        # logger
        logger.update(i, {
            'epoch': f'{epoch}/{epochs}',
            'iter': f'{i}/{iters}',
            'loss': loss.item(),
        })

    train_acc = correct_num / total_num
    train_loss = loss_sum / len(dataloader)

    return train_acc, train_loss

@torch.no_grad()
def eval_once(dataloader, model, criterion, device='cuda'):
    model.eval()

    correct_num, total_num = 0, 0
    loss_sum = 0.0

    for inputs, labels in dataloader:
        inputs = inputs.to(device)
        labels = labels.to(device)

        # forward
        outputs = model(inputs)
        eval_loss = criterion(outputs, labels)

        # spikingjelly
        # functional.reset_net(model)

        # 统计
        loss_sum += eval_loss.item()

        preds = outputs.argmax(dim=1)
        correct_num += (preds == labels).sum().item()
        total_num += labels.size(0)

    eval_acc = correct_num / total_num
    eval_loss = loss_sum / len(dataloader)

    return eval_acc, eval_loss


@torch.no_grad()
def test_once(dataloader, model, criterion, device='cuda'):
    model.eval()

    correct_num, total_num = 0, 0
    loss_sum = 0.0

    all_preds = []
    all_labels = []

    for inputs, labels in dataloader:
        inputs = inputs.to(device)
        labels = labels.to(device)

        # forward
        outputs = model(inputs)
        eval_loss = criterion(outputs, labels)

        # spikingjelly
        # functional.reset_net(model)

        # 统计
        loss_sum += eval_loss.item()

        preds = outputs.argmax(dim=1)
        correct_num += (preds == labels).sum().item()
        total_num += labels.size(0)

        all_preds.extend(
            preds.cpu().numpy()
        )

        all_labels.extend(
            labels.cpu().numpy()
        )

    test_acc = correct_num / total_num
    test_loss = loss_sum / len(dataloader)
    print('\n[Test]')
    print(f'    acc: {test_acc:.4f}, loss: {test_loss:.4f}')

    return test_acc, test_loss, all_labels, all_preds

def train_eval(
    epochs,
    train_loader, val_loader,
    model, optimizer, criterion,
    device,
    ckpt_dir
):
    best_acc = 0.0

    train_acc_lst, train_loss_lst = [], []
    val_acc_lst, val_loss_lst = [], []

    for epoch in range(1, epochs + 1):
        print(f'===== Epoch {epoch} =====')
        train_acc, train_loss = train_once(train_loader, model, optimizer, criterion, epoch, epochs, device)
        val_acc, val_loss = eval_once(val_loader, model, criterion, device)

        train_acc_lst.append(train_acc)
        val_acc_lst.append(val_acc)
        train_loss_lst.append(train_loss)
        val_loss_lst.append(val_loss)

        print(f'│   Train -> acc: {train_acc:.4f}, loss: {train_loss:.4f}')
        print(f'└   Val   -> acc: {val_acc:.4f}, loss: {val_loss:.4f}')

        # ===== 保存 last checkpoint =====
        save_checkpoint(
            save_path=os.path.join(ckpt_dir, 'last.pth'),
            epoch=epoch,
            model=model,
            optimizer=optimizer,
            best_metric=best_acc,
        )

        # ===== 保存 best checkpoint =====
        if val_acc > best_acc:
            best_acc = val_acc

            save_checkpoint(
                save_path=os.path.join(ckpt_dir, 'best.pth'),
                epoch=epoch,
                model=model,
                optimizer=optimizer,
                best_metric=best_acc,
            )

            print(f'[*] Best model saved! acc={best_acc:.4f}')

    return train_acc_lst, train_loss_lst, val_acc_lst, val_loss_lst

def train_eval_test(
    epochs,
    train_loader, val_loader, test_loader,
    model, optimizer, criterion,
    device,
    save_dir
):
    os.makedirs(os.path.join(save_dir, 'plots'), exist_ok=True)
    os.makedirs(os.path.join(save_dir, 'checkpoints'), exist_ok=True)

    # ==== train_eval ====
    train_acc_lst, train_loss_lst, val_acc_lst, val_loss_lst = train_eval(
        epochs,
        train_loader,
        val_loader,
        model,
        optimizer,
        criterion,
        device,
        os.path.join(save_dir, 'checkpoints')
    )
    # loss-acc
    plt = plot_metrics(epochs, train_acc_lst, train_loss_lst, val_acc_lst, val_loss_lst)
    plt.savefig(os.path.join(save_dir, 'plots', 'metrics.png'), bbox_inches='tight')
    plt.close()

    # ==== test ====
    test_acc, test_loss, all_labels, all_preds = test_once(test_loader, model, criterion, device)
    # matrix
    plt = plot_matrix(all_labels, all_preds)
    plt.savefig(os.path.join(save_dir, 'plots', 'matrix.png'), bbox_inches='tight')
    plt.close()

def main():
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset

    # ====== 模型 ======
    class SimpleNet(nn.Module):
        def __init__(self, in_dim=20, num_classes=3):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(in_dim, 64),
                nn.ReLU(),
                nn.Linear(64, num_classes)
            )

        def forward(self, x):
            return self.net(x)

    # ====== 基本配置 ======
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    device = b_get_device(use_idle_gpu=False, sout=False)

    input_dim = 20
    num_classes = 3
    num_samples = 1000
    batch_size = 32

    # ====== 构造随机数据 ======
    X = torch.randn(num_samples, input_dim)
    y = torch.randint(0, num_classes, (num_samples,))

    dataset = TensorDataset(X, y)

    # 简单拆分 train / val / test
    train_set, val_set, test_set = torch.utils.data.random_split(
        dataset,
        [800, 100, 100]
    )

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    val_loader   = DataLoader(val_set, batch_size=batch_size)
    test_loader  = DataLoader(test_set, batch_size=batch_size)

    # ====== 模型 / 优化器 / 损失 ======
    model = SimpleNet(input_dim, num_classes).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.CrossEntropyLoss()

    # ====== 训练 / 验证 / 测试 ======
    epochs = 5
    train_eval_test(epochs, train_loader, val_loader, test_loader, model, optimizer, criterion, device, save_dir='./run')


if __name__ == '__main__':
    main()