import torch
import torch.nn as nn
import torch.nn.functional as F


class Word2Vec(nn.Module):
    """
    Word2Vec

    支持:
        1. CBOW
        2. Skip-Gram
    """

    def __init__(
        self,
        vocab_size,
        embedding_dim,
        model_type="skipgram",
    ):
        super().__init__()

        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.model_type = model_type.lower()

        # W: [V, N]
        # 输入词向量矩阵
        self.embedding = nn.Embedding( # nn.Embedding 等价于 `one-hot` & `embedding matrix`
            num_embeddings=vocab_size,
            embedding_dim=embedding_dim,
        )

        # W': [N, V]
        # 输出投影矩阵
        self.output = nn.Linear(
            embedding_dim,
            vocab_size,
            bias=False,
        )

    def forward(self, x):
        """
        Skip-Gram:
            x shape: [batch_size]

        CBOW:
            x shape: [batch_size, context_size]
        """

        # =====================================================
        # Skip-Gram
        # =====================================================
        if self.model_type == "skipgram":

            # [B] -> [B, N]
            h = self.embedding(x)

            # [B, N] -> [B, V]
            logits = self.output(h)

            return logits

        # =====================================================
        # CBOW
        # =====================================================
        elif self.model_type == "cbow":

            # [B, C] -> [B, C, N]
            emb = self.embedding(x)

            # 对上下文词向量取平均
            # [B, C, N] -> [B, N]
            h = emb.mean(dim=1)

            # [B, N] -> [B, V]
            logits = self.output(h)

            return logits

        else:
            raise ValueError("model_type must be 'skipgram' or 'cbow'")


if __name__ == "__main__":
    batch = 32
    vocab_size = 10000 # 词表大小
    embedding_dim = 128 # 词向量维度

    # =========================================================
    # Skip-Gram
    # =========================================================

    skipgram_model = Word2Vec(
        vocab_size=vocab_size,
        embedding_dim=embedding_dim,
        model_type="skipgram",
    )

    # 当前单词
    print("Skip-Gram shape:")

    inputs = torch.randint(0, vocab_size, (batch,))
    logits = skipgram_model(inputs)
    print("- logits:", logits.shape)  # 映射回词表的预测概率: [32, vocab_size]

    x = torch.randint(0, vocab_size, (batch,))
    print("- x_embedding:", skipgram_model.embedding(x).shape) # 真正要的word2vec的词向量

    # =========================================================
    # CBOW
    # =========================================================

    cbow_model = Word2Vec(
        vocab_size=vocab_size,
        embedding_dim=embedding_dim,
        model_type="cbow",
    )

    # 上下文单词
    print("CBOW shape:")

    inputs = torch.randint(0, vocab_size, (batch, 4)) # 4代表: 4个上下文单词
    logits = cbow_model(inputs)
    print("- logits:", logits.shape)  # 映射回词表的预测概率: [32, vocab_size]

    x = torch.randint(0, vocab_size, (batch,))
    print("- x_embedding:", cbow_model.embedding(x).shape) # 真正要的word2vec的词向量