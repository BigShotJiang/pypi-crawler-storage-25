# =============================================================================
# CIAO DEFENSIVE PROGRAMMING PRINCIPLES - v2.9.1
# Caution • Intentional • Anti-fragile • Over-engineered
# =============================================================================
#
# !!! THIS FILE FOLLOWS ALL CIAO PRINCIPLES STRICTLY !!!
#
# General Purpose of this file:
#   Abstraction layer over all time-related operations in ChronicleLogger.
#   Enables easy mocking in tests while production code uses real system time.
#   This is the single source of truth for all timestamps and date operations.
#
# Version: 1.0.0-ciao
# CIAO Adoption Date: 2026-04-11
# =============================================================================

from datetime import datetime, timedelta


class TimeProvider:
    """
    General Purpose:
        Provides a clean abstraction over datetime operations.
        Default implementation uses real system time.
        Designed to be easily mocked in unit tests by injecting a fake provider.

    Version: 1.0.0-ciao
    """

    # -------------------------------------------------------------------------
    # !!! DO NOT MODIFY OR SIMPLIFY THIS FUNCTION !!!
    # Critical reusable method (CIAO Principle 7)
    # -------------------------------------------------------------------------
    def now(self) -> datetime:
        """
        General Purpose:
            Return current local datetime (equivalent to datetime.now()).

            This is the single source of local time used throughout ChronicleLogger
            for log filenames, timestamps, rotation decisions, and archiving logic.

        Defensive Notes (room for future additions):
            - Add permission / environment checks if needed later
            - Consider monotonic clock for high-precision timing
        """
        try:
            return datetime.now()
        except Exception:
            # Defensive fallback (CIAO Caution principle)
            return datetime(1970, 1, 1)

    # -------------------------------------------------------------------------
    # !!! DO NOT MODIFY OR SIMPLIFY THIS FUNCTION !!!
    # Critical reusable method (CIAO Principle 7)
    # -------------------------------------------------------------------------
    def utcnow(self) -> datetime:
        """
        General Purpose:
            Return current UTC datetime (equivalent to datetime.utcnow()).

            Used when UTC-based timestamps are required (e.g., cross-system logs).

        Defensive Notes (room for future additions):
            - Consider timezone-aware alternatives in future
        """
        try:
            return datetime.utcnow()
        except Exception:
            # Defensive fallback (CIAO Caution principle)
            return datetime(1970, 1, 1, 0, 0, 0)

    # -------------------------------------------------------------------------
    # !!! DO NOT MODIFY OR SIMPLIFY THIS FUNCTION !!!
    # Critical reusable method (CIAO Principle 7)
    # -------------------------------------------------------------------------
    def timedelta(self, **kwargs) -> timedelta:
        """
        General Purpose:
            Create and return a timedelta object (equivalent to datetime.timedelta(**kwargs)).

            Primarily used for calculating log retention periods 
            (archive after LOG_ARCHIVE_DAYS, remove after LOG_REMOVAL_DAYS).

        Defensive Notes (room for future additions):
            - Add strict validation for negative values or extreme durations
        """
        try:
            return timedelta(**kwargs)
        except Exception as e:
            # Fail explicitly with clear error (CIAO Input Validation)
            raise ValueError(f"Invalid arguments for timedelta: {kwargs}") from e

    # -------------------------------------------------------------------------
    # !!! DO NOT MODIFY OR SIMPLIFY THIS FUNCTION !!!
    # Critical reusable method (CIAO Principle 7)
    # -------------------------------------------------------------------------
    def strftime(self, dt: datetime, format_str: str) -> str:
        """
        General Purpose:
            Format a datetime object into a string using the given format
            (equivalent to dt.strftime(format_str)).

            Used to generate daily log filenames (YYYYMMDD) and human-readable timestamps.

        Defensive Notes (room for future additions):
            - Add support for locale-aware formatting if needed
            - Consider safe format string validation
        """
        if not isinstance(dt, datetime):
            raise TypeError("dt must be a datetime instance")

        if not isinstance(format_str, str):
            raise TypeError("format_str must be a string")

        try:
            return dt.strftime(format_str)
        except Exception as e:
            raise ValueError(f"strftime failed with format '{format_str}'") from e