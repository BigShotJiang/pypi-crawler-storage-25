# -*- coding: utf-8 -*-
# src/chronicle_logger/ChronicleLogger.py

"""
CIAO-DEFENSIVE v2.9.1 HEADER
============================
This file follows CIAO Defensive Programming Principles v2.9.1
(Caution • Intentional • Anti-fragile • Over-engineered)

Project: ChronicleLogger
Purpose: High-performance, cross-version (Python 2.7 ↔ 3.x) logging utility with
         daily rotation, archiving, privilege-aware paths, and environment detection.

General Purpose:
    Provide a robust, backward-compatible logging class that automatically handles
    daily log files, archiving, cleanup, and correct storage paths across root,
    user, venv, pyenv, and conda environments while maintaining Python 2/3 compatibility.

Version: 1.3.0-ciao (independent module versioning per CIAO Principle 12)
"""

from __future__ import print_function, absolute_import, division, unicode_literals

import os
import sys
import ctypes
import tarfile
import re
from datetime import datetime
import subprocess

from .Suroot import _Suroot
from .TimeProvider import TimeProvider

try:
    basestring
except NameError:
    basestring = str

try:
    from io import open as io_open
except ImportError:
    io_open = open


class ChronicleLogger:
    """Main logging class with environment-aware, privilege-aware, rotating logs."""

    CLASSNAME = "ChronicleLogger"
    MAJOR_VERSION = 1
    MINOR_VERSION = 2
    PATCH_VERSION = 3

    LOG_ARCHIVE_DAYS = 7
    LOG_REMOVAL_DAYS = 30

    # -------------------------------------------------------------------------
    # General Purpose: Initialize the logger with application name and optional custom paths.
    #
    # Current Logic:
    #   - Sets internal attributes to None/empty.
    #   - Assigns TimeProvider (default or injected).
    #   - Early return if logname is empty.
    #   - Calls logName(), baseDir(), logDir() to trigger path resolution and directory creation.
    #   - Stores current logfile path and ensures directory + write test.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def __init__(self, logname=b"app", logdir=b"", basedir=b"", is_quiet=False, time_provider=None):
        """
        Initialize the logger with application name and optional custom paths.

        Args:
            logname (bytes or str): Application/logger name
                                   (will be automatically kebab-cased in Python mode)
            logdir (bytes or str, optional): Explicit log directory path.
                                            If empty → auto-detected
            basedir (bytes or str, optional): Explicit base directory (configs).
                                             If empty → auto-detected

        Detection priority when not provided explicitly:
            1. Explicit value
            2. Active conda/pyenv/venv environment + /.app/<appname>
            3. User home: ~/.app/<appname> (non-root) or /var/<appname> (root)

        Side effects:
            - Creates log directory if needed
            - Tests write permission by writing an empty line
        """
        self.__logname__ = None
        self.__basedir__ = None
        self.__logdir__ = None
        self.__old_logfile_path__ = ctypes.c_char_p(b"")
        self.__is_python__ = None
        self.__is_quiet__ = is_quiet
        self.time_provider = time_provider or TimeProvider()
        if not logname or logname in (b"", ""):
            return

        self.logName(logname)
        self.baseDir(basedir if basedir else "")
        if logdir:
            self.logDir(logdir)
        else:
            self.logDir("")  # triggers default path + directory creation

        self.__current_logfile_path__ = self._get_log_filename()
        self.ensure_directory_exists(self.__logdir__)

        if self._has_write_permission(self.__current_logfile_path__):
            self.write_to_file("\n")

    # -------------------------------------------------------------------------
    # General Purpose: Simple wrapper to print message to stdout.
    #
    # Current Logic: Direct call to built-in print.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def prn(self, msg):
        """Simple wrapper: print message to stdout."""
        if not self.__is_quiet__:
            print(msg)

    # -------------------------------------------------------------------------
    # General Purpose: Simple wrapper to print message to stderr.
    #
    # Current Logic: Direct call to built-in print with file=sys.stderr.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def prn_err(self, msg):
        """Simple wrapper: print message to stderr."""
        if not self.__is_quiet__:
            print(msg, file=sys.stderr)

    # -------------------------------------------------------------------------
    # General Purpose: Convert string, bytes or None → bytes (UTF-8).
    #
    # Current Logic: Checks type and encodes strings; passes bytes/None through; raises on others.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def strToByte(self, value):
        """
        Convert string, bytes or None → bytes (UTF-8).

        Args:
            value: str, bytes or None

        Returns:
            bytes or None

        Raises:
            TypeError: on unsupported type
        """
        if isinstance(value, basestring):
            return value.encode('utf-8')
        elif value is None or isinstance(value, bytes):
            return value
        raise TypeError("Expected str/bytes/None, got {0}".format(type(value).__name__))

    # -------------------------------------------------------------------------
    # General Purpose: Convert bytes, str or None → string (UTF-8 decoded).
    #
    # Current Logic: Passes str/None through; decodes bytes; raises on others.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def byteToStr(self, value):
        """
        Convert bytes, str or None → string (UTF-8 decoded).

        Args:
            value: str, bytes or None

        Returns:
            str or None

        Raises:
            TypeError: on unsupported type
        """
        if value is None or isinstance(value, basestring):
            return value
        elif isinstance(value, bytes):
            return value.decode('utf-8')
        raise TypeError("Expected str/bytes/None, got {0}".format(type(value).__name__))

    # -------------------------------------------------------------------------
    # General Purpose: Split path into components using OS-appropriate separator.
    #
    # Current Logic: Prefers / split, falls back to \, otherwise returns single-element list.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def split_cmd(self, cmd_path):
        """Split path into components using OS-appropriate separator."""
        if "/" in cmd_path:
            return cmd_path.split("/")
        if "\\" in cmd_path:
            return cmd_path.split("\\")
        return [cmd_path]

    # -------------------------------------------------------------------------
    # General Purpose: Extract basename from executable path.
    #
    # Current Logic: Uses split_cmd and takes the last element.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def cmd_name(self, cmd_path):
        """Extract basename from executable path."""
        return self.split_cmd(cmd_path)[-1]

    # -------------------------------------------------------------------------
    # General Purpose: Check whether we are running in a Python interpreter (vs Cython compiled binary).
    #
    # Current Logic: Lazy cache; inspects sys.executable basename for python* patterns.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def inPython(self):
        """
        Check whether we are running in a Python interpreter (vs Cython compiled binary).

        Returns:
            bool: True if running via python*/python[23].*
        """
        if self.__is_python__ is None:
            exe_name = self.cmd_name(sys.executable)
            if exe_name.startswith("python2.") or exe_name.startswith("python3."):
                self.__is_python__ = True
            else:
                self.__is_python__ = exe_name in ['python', 'python2', 'python3']
        return self.__is_python__

    # -------------------------------------------------------------------------
    # General Purpose: Check if interpreter is managed by pyenv.
    #
    # Current Logic: Lazy cache; simple substring check '/.pyenv/' in sys.executable.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def inPyenv(self):
        """
        Check if interpreter is managed by pyenv.

        Detection method: '/.pyenv/' substring in sys.executable (case-sensitive)

        Returns:
            bool
        """
        if not hasattr(self, '__is_pyenv__'):
            self.__is_pyenv__ = '/.pyenv/' in sys.executable
        return self.__is_pyenv__

    # -------------------------------------------------------------------------
    # General Purpose: Get path of active standard Python virtual environment (venv).
    #
    # Current Logic: Lazy cache from VIRTUAL_ENV env var.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def venv_path(self):
        """
        Get path of active standard Python virtual environment (venv).

        Returns:
            str: path or empty string
        """
        if not hasattr(self, '__venv_path__'):
            self.__venv_path__ = os.environ.get('VIRTUAL_ENV', '')
        return self.__venv_path__

    # -------------------------------------------------------------------------
    # General Purpose: Check if running inside a standard Python venv.
    #
    # Current Logic: Lazy cache based on presence of VIRTUAL_ENV.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def inVenv(self):
        """
        Check if running inside a standard Python venv.

        Returns:
            bool
        """
        if not hasattr(self, '__in_venv__'):
            venv_env = os.environ.get('VIRTUAL_ENV', '')
            self.__in_venv__ = bool(venv_env)
        return self.__in_venv__

    # !!! DO NOT MODIFY OR SIMPLIFY THIS FUNCTION !!!
    @staticmethod
    def pyenv_versions():
        """Execute 'pyenv versions' command and return output."""
        return subprocess.check_output(['pyenv', 'versions'], stderr=subprocess.STDOUT)

    # -------------------------------------------------------------------------
    # General Purpose: Get parent-parent directory (two levels up).
    #
    # Current Logic: Splits path and joins all but last two elements.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def grand_path(self, path):
        """Get parent-parent directory (two levels up)."""
        if "/" in path:
            return "/".join(self.split_cmd(path)[:-2])
        if "\\" in path:
            return "\\".join(self.split_cmd(path)[:-2])
        return ''

    # -------------------------------------------------------------------------
    # General Purpose: Get path of currently active pyenv-virtualenv environment.
    #
    # Current Logic: Lazy cache; tries executable path then parses 'pyenv versions' output for * --> path.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def pyenvVenv(self):
        """
        Get path of currently active pyenv-virtualenv environment.

        Uses 'pyenv versions' output to find active (*) venv.
        Caches result.

        Returns:
            str: venv path or empty string
        """
        if not hasattr(self, '__pyenv_venv_path__'):
            self.__pyenv_venv_path__ = ''
            if self.inPyenv():
                if self.split_cmd(sys.executable)[-2] == 'bin':
                    self.__pyenv_venv_path__ = self.grand_path(sys.executable)
                try:
                    result = self.pyenv_versions()
                    if hasattr(result, 'decode'):
                        output = result.decode('utf-8') if sys.version_info[0] < 3 else result.decode('utf-8')
                    else:
                        output = result
                    lines = output.strip().split('\n')
                    for line in lines:
                        if '*' in line and '-->' in line:
                            path_start = line.find('--> ') + 4
                            path = line[path_start:].strip()
                            if ' (' in path:
                                path = path.rsplit(' (', 1)[0].strip()
                            if path and os.path.exists(path):
                                self.__pyenv_venv_path__ = path
                                break
                except (subprocess.CalledProcessError, FileNotFoundError, IndexError):
                    self.__pyenv_venv_path__ = ''
        return self.__pyenv_venv_path__

    # -------------------------------------------------------------------------
    # General Purpose: Check if running inside a Conda/Anaconda/Miniconda environment.
    #
    # Current Logic: Lazy cache from CONDA_DEFAULT_ENV or 'conda' in executable.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def inConda(self):
        """
        Check if running inside a Conda/Anaconda/Miniconda environment.

        Returns:
            bool
        """
        if not hasattr(self, '__in_conda__'):
            conda_env = os.environ.get('CONDA_DEFAULT_ENV', '')
            self.__in_conda__ = bool(conda_env) or 'conda' in sys.executable
        return self.__in_conda__

    # !!! DO NOT MODIFY OR SIMPLIFY THIS FUNCTION !!!
    @staticmethod
    def conda_env_list():
        """Execute 'conda env list' command and return output."""
        return subprocess.check_output(['conda', 'env', 'list'], stderr=subprocess.STDOUT)

    # -------------------------------------------------------------------------
    # General Purpose: Get path of currently active Conda environment.
    #
    # Current Logic: Lazy cache; runs conda env list and parses line with *.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def condaPath(self):
        """
        Get path of currently active Conda environment.

        Priority: CONDA_DEFAULT_ENV → parse 'conda env list'

        Returns:
            str: env path or empty string
        """
        if not hasattr(self, '__conda_path__'):
            self.__conda_path__ = ''
            try:
                result = ChronicleLogger.conda_env_list()
                output = result.decode('utf-8') if sys.version_info[0] < 3 else result.decode('utf-8')
                lines = output.strip().split('\n')
                for line in lines:
                    if "#" not in line and '*' in line:
                        parts = re.split(r'\s{2,}', line.strip())
                        if len(parts) >= 2:
                            path = parts[-1].strip()
                            if path and os.path.exists(path):
                                self.__conda_path__ = path
                                break
            except (subprocess.CalledProcessError, FileNotFoundError):
                self.__conda_path__ = ''
        return self.__conda_path__

    # -------------------------------------------------------------------------
    # General Purpose: Get or set the logger name (with kebab-case in Python mode).
    #
    # Current Logic: On set, stores as bytes and applies CamelCase→kebab if inPython(); on get, decodes.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def logName(self, logname=None):
        """
        Get or set the logger name.

        In Python mode (not Cython): converts CamelCase → kebab-case

        Args:
            logname (bytes/str/None): new name or None to get current

        Returns:
            str: current name (decoded)
        """
        if logname is not None:
            self.__logname__ = self.strToByte(logname)
            if self.inPython():
                name = self.__logname__.decode('utf-8')
                name = re.sub(r'(?<!^)(?=[A-Z])', '-', name).lower()
                self.__logname__ = name.encode('utf-8')
        else:
            return self.__logname__.decode('utf-8')

    # -------------------------------------------------------------------------
    # General Purpose: Internal: lazy set base directory according to environment hierarchy.
    #
    # Current Logic: Uses conda > pyenvVenv > venv > user_home (root → /var, else ~/.app).
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def __set_base_dir__(self, basedir=b""):
        """Internal: lazy set base directory according to environment hierarchy."""
        basedir_str = self.byteToStr(basedir)
        if basedir_str and basedir_str != '':
            self.__basedir__ = basedir_str
        else:
            appname = self.byteToStr(self.__logname__)
            if not hasattr(self, '__basedir__') or self.__basedir__ is None:
                conda_path = self.condaPath()
                if self.inConda() and conda_path:
                    self.__basedir__ = os.path.join(conda_path, ".app", appname)
                else:
                    pyenv_path = self.pyenvVenv()
                    if pyenv_path:
                        self.__basedir__ = os.path.join(pyenv_path, ".app", appname)
                    else:
                        venv_path = self.venv_path()
                        if venv_path:
                            self.__basedir__ = os.path.join(venv_path, ".app", appname)
                        else:
                            user_home = ChronicleLogger.user_home()
                            app_path = os.path.join(user_home, ".app", appname)
                            if self.is_root():
                                self.__basedir__ = "/var/{0}".format(appname)
                            else:
                                self.__basedir__ = app_path

    # -------------------------------------------------------------------------
    # General Purpose: Get or set base directory (configs, not logs).
    #
    # Current Logic: On set calls __set_base_dir__; on get ensures computation then returns.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def baseDir(self, basedir=None):
        """
        Get or set base directory (configs, not logs).

        Args:
            basedir (bytes/str/None): new value or None to get

        Returns:
            str: current base directory (decoded)
        """
        if basedir is not None:
            self.__set_base_dir__(basedir)
        else:
            if self.__basedir__ is None:
                self.__set_base_dir__(b"")
            return self.__basedir__

    # -------------------------------------------------------------------------
    # General Purpose: Get current user's home directory.
    #
    # Current Logic: os.path.expanduser("~")
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    @staticmethod
    def user_home():
        """Get current user's home directory."""
        return os.path.expanduser("~")

    # -------------------------------------------------------------------------
    # General Purpose: Check if current effective user is root.
    #
    # Current Logic: Delegates to _Suroot.is_root()
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    @staticmethod
    def is_root():
        """Check if current effective user is root."""
        return _Suroot.is_root()

    # -------------------------------------------------------------------------
    # General Purpose: Check if sudo is available without password.
    #
    # Current Logic: Delegates to _Suroot.can_sudo_without_password()
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    @staticmethod
    def can_sudo():
        """Check if sudo is available without password."""
        return _Suroot.can_sudo_without_password()

    # -------------------------------------------------------------------------
    # General Purpose: Check if we are root or can become root without password.
    #
    # Current Logic: Combines can_sudo and is_root.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    @staticmethod
    def root_or_sudo():
        """Check if we are root or can become root without password."""
        return _Suroot.can_sudo_without_password() or _Suroot.is_root()

    # -------------------------------------------------------------------------
    # General Purpose: Internal: lazy set log directory (defaults to baseDir/log).
    #
    # Current Logic: Explicit path or baseDir + "/log"
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def __set_log_dir__(self, logdir=b""):
        """Internal: lazy set log directory (defaults to baseDir/log)."""
        logdir_str = self.byteToStr(logdir)
        if logdir_str and logdir_str != '':
            self.__logdir__ = logdir_str
        else:
            self.baseDir()  # ensure baseDir is computed
            appname = self.byteToStr(self.__logname__)
            self.__logdir__ = "{0}/log".format(self.__basedir__)

    # -------------------------------------------------------------------------
    # General Purpose: Get or set log directory path.
    #
    # Current Logic: On set calls __set_log_dir__; on get ensures computation.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def logDir(self, logdir=None):
        """
        Get or set log directory path.

        Default when unset: baseDir() + "/log"

        Args:
            logdir (bytes/str/None): new value or None to get

        Returns:
            str: current log directory (decoded)
        """
        if logdir is not None:
            self.__set_log_dir__(logdir)
        else:
            if self.__logdir__ is None:
                self.__set_log_dir__(b"")
            return self.__logdir__

    # -------------------------------------------------------------------------
    # General Purpose: Check if debug mode is enabled via environment variable.
    #
    # Current Logic: Lazy cache; checks DEBUG or debug env var for "show"/"true"/"1".
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def isDebug(self):
        """
        Check if debug mode is enabled via environment variable.

        Accepted values (case-insensitive): "show", "true", "1"

        Returns:
            bool
        """
        if not hasattr(self, '__is_debug__'):
            debug = os.getenv("DEBUG", "").lower()
            if not debug:
                debug = os.getenv("debug", "").lower()
            self.__is_debug__ = (
                debug == "show" or
                debug == "true" or
                debug == "1"
            )
        return self.__is_debug__

    # -------------------------------------------------------------------------
    # General Purpose: Return current version string of this class.
    #
    # Current Logic: Formats CLASSNAME + MAJOR.MINOR.PATCH
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    @staticmethod
    def class_version():
        """Return current version string of this class."""
        return "{0.CLASSNAME} v{0.MAJOR_VERSION}.{0.MINOR_VERSION}.{0.PATCH_VERSION}".format(ChronicleLogger)

    # -------------------------------------------------------------------------
    # General Purpose: Create directory recursively if it doesn't exist.
    #
    # Current Logic: os.makedirs; prints success message; catches exceptions silently (except old Python 2 handling).
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def ensure_directory_exists(self, dir_path):
        """
        Create directory recursively if it doesn't exist.

        Args:
            dir_path (str/bytes): directory to create

        Side effects:
            Prints creation message to stdout on success
        """
        try:
            os.makedirs(dir_path)
            self.prn("Created directory: {0}".format(dir_path))
        except Exception:
            if sys.version_info[0] < 3:
                exc_type, exc_value, exc_tb = sys.exc_info()
                e = exc_value
            else:
                exc_type, exc_value, exc_tb = sys.exc_info()
                e = exc_value

    # -------------------------------------------------------------------------
    # General Purpose: Generate full path to current daily log file.
    #
    # Current Logic: Uses TimeProvider for YYYYMMDD; builds <logdir>/<kebab-name>-YYYYMMDD.log as bytes.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def _get_log_filename(self):
        """
        Generate full path to current daily log file.

        Returns:
            bytes: encoded path
        """
        date_str = self.time_provider.strftime(
            self.time_provider.now(), '%Y%m%d'
        )
        dir_decoded = self.__logdir__.decode('utf-8') if isinstance(self.__logdir__, bytes) else self.__logdir__
        name_decoded = self.__logname__.decode('utf-8')
        filename = "{0}/{1}-{2}.log".format(dir_decoded, name_decoded, date_str)
        return ctypes.c_char_p(filename.encode('utf-8')).value

    # -------------------------------------------------------------------------
    # General Purpose: Main logging method with rotation, archiving, console mirroring and file write.
    #
    # Current Logic: Builds formatted entry; detects date change → triggers rotation; outputs to stderr for errors else stdout; writes to file if permitted.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def log_message(self, message, level=b"INFO", component=b""):
        """
        Main logging method.

        Format example:
            [2025-12-25 14:30:45] pid:12345 [INFO] @database :] Connected successfully

        Features:
            - Automatic daily rotation
            - Archiving & cleanup on rotation
            - Console output (stdout/stderr)
            - File write with permission check

        Args:
            message (str/bytes): log content
            level (bytes/str): INFO/WARNING/ERROR/CRITICAL/FATAL/DEBUG
            component (bytes/str): optional subsystem name
        """
        pid = os.getpid()
        timestamp = self.time_provider.strftime(
            self.time_provider.now(), "%Y-%m-%d %H:%M:%S"
        )
        component_str = " @{0}".format(self.byteToStr(component)) if component else ""
        message_str = self.byteToStr(message)
        level_str = self.byteToStr(level).upper()

        log_entry = "[{0}] pid:{1} [{2}]{3} :] {4}\n".format(
            timestamp, pid, level_str, component_str, message_str)

        new_path = self._get_log_filename()

        if self.__old_logfile_path__ != new_path:
            self.log_rotation()
            self.__old_logfile_path__ = new_path
            if self.isDebug():
                new_path_decoded = new_path.decode('utf-8') if isinstance(new_path, bytes) else new_path
                header = "[{0}] pid:{1} [INFO] @logger :] Using {2}\n".format(
                    timestamp, pid, new_path_decoded)
                log_entry = header + log_entry

        if self._has_write_permission(new_path):
            if level_str in ("ERROR", "CRITICAL", "FATAL"):
                self.prn_err(log_entry.strip())
            else:
                self.prn(log_entry.strip())
            self.write_to_file(log_entry)

    # -------------------------------------------------------------------------
    # General Purpose: Test whether we can append to the given file.
    #
    # Current Logic: Tries open(..., 'a'); returns True/False and prints permission warning on failure.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def _has_write_permission(self, file_path):
        """
        Test whether we can append to the given file.

        Returns:
            bool: True if writable, False otherwise (prints warning to stderr)
        """
        try:
            with open(file_path, 'a'):
                return True
        except:
            if sys.version_info[0] < 3:
                exc_type, exc_value, exc_tb = sys.exc_info()
                if issubclass(exc_type, (OSError, IOError)):
                    self.prn_err("Permission denied for writing to {0}".format(file_path))
                    return False
            else:
                exc_type, exc_value, exc_tb = sys.exc_info()
                if issubclass(exc_type, (OSError, IOError)):
                    self.prn_err("Permission denied for writing to {0}".format(file_path))
                    return False

    # -------------------------------------------------------------------------
    # General Purpose: Append log entry to current log file using UTF-8 encoding.
    #
    # Current Logic: Uses io_open(..., 'a', encoding='utf-8')
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def write_to_file(self, log_entry):
        """Append log entry to current log file using UTF-8 encoding."""
        with io_open(self.__current_logfile_path__, 'a', encoding='utf-8') as f:
            f.write(log_entry)

    # -------------------------------------------------------------------------
    # General Purpose: Trigger log maintenance when date changes (archive + remove old).
    #
    # Current Logic: Skips if dir empty; calls archive_old_logs then remove_old_logs.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def log_rotation(self):
        """
        Trigger log maintenance when date changes:
        - archive old logs
        - remove very old logs
        """
        if not os.path.exists(self.__logdir__) or not os.listdir(self.__logdir__):
            return
        self.archive_old_logs()
        self.remove_old_logs()

    # -------------------------------------------------------------------------
    # General Purpose: Archive logs older than LOG_ARCHIVE_DAYS to .tar.gz.
    #
    # Current Logic: Scans .log files; uses TimeProvider for age check; calls _archive_log on old ones.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def archive_old_logs(self):
        try:
            now = self.time_provider.now()  # ← Add this
            
            for file in os.listdir(self.__logdir__):
                if file.endswith(".log"):
                    date_part = file.split('-')[-1].split('.')[0]
                    try:
                        log_date = datetime.strptime(date_part, '%Y%m%d')
                        if (now - log_date).days > self.LOG_ARCHIVE_DAYS:
                            self._archive_log(file)
                    except ValueError:
                        continue
        except Exception:
            exc_type, exc_value, exc_tb = sys.exc_info()
            e = exc_value
            self.prn_err("Error during archive: {0}".format(e))

    # -------------------------------------------------------------------------
    # General Purpose: Internal: archive single log file to tar.gz and remove original.
    #
    # Current Logic: Creates tar.gz with original name inside; removes .log file; prints success.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def _archive_log(self, filename):
        """Internal: archive single log file to tar.gz and remove original."""
        log_path = os.path.join(self.__logdir__, filename)
        archive_path = log_path + ".tar.gz"
        try:
            with tarfile.open(archive_path, "w:gz") as tar:
                tar.add(log_path, arcname=filename)
            os.remove(log_path)
            self.prn("Archived log file: {0}".format(archive_path))
        except Exception:
            exc_type, exc_value, exc_tb = sys.exc_info()
            e = exc_value
            self.prn_err("Error archiving {0}: {1}".format(filename, e))

    # -------------------------------------------------------------------------
    # General Purpose: Permanently delete old .log and .tar.gz files older than LOG_REMOVAL_DAYS.
    #
    # Current Logic: Uses TimeProvider for threshold; parses date from filename; removes matching files (with debug print).
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def remove_old_logs(self):
        """
        Permanently delete:
        - Original .log files older than LOG_REMOVAL_DAYS (30)
        - Archived .tar.gz files older than LOG_REMOVAL_DAYS (30)
        """
        try:
            now = self.time_provider.now()
            removal_threshold = now - self.time_provider.timedelta(days=self.LOG_REMOVAL_DAYS)

            for filename in os.listdir(self.__logdir__):
                full_path = os.path.join(self.__logdir__, filename)

                # Skip if not a log or archive file
                if not (filename.endswith(".log") or filename.endswith(".log.tar.gz")):
                    continue

                # Extract date part (works for both .log and .log.tar.gz)
                try:
                    # Take part before the first .log or .tar.gz
                    base = filename.rsplit('.log', 1)[0]
                    date_part = base.rsplit('-', 1)[-1]
                    log_date = datetime.strptime(date_part, '%Y%m%d')
                except (ValueError, IndexError):
                    continue  # Skip invalid filenames

                if log_date < removal_threshold:
                    if self.isDebug():
                        self.prn(f"Removing old log file: {full_path}")
                    try:
                        os.remove(full_path)
                    except OSError as e:
                        self.prn_err(f"Failed to remove {full_path}: {e}")

        except Exception as e:
            self.prn_err(f"Error during removal process: {e}")

    # -------------------------------------------------------------------------
    # General Purpose: Return the full path to the current active log file.
    #
    # Current Logic: Returns decoded path from _get_log_filename() or empty string if not set.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def currentLogFile(self):
        """
        Return the full path to the current active log file.
        
        Returns:
            str: Absolute path to the log file being written to (e.g. /path/to/test-app-20251225.log)
                 Returns empty string if not initialized properly.
        """
        if self.__current_logfile_path__ is None:
            return ""
        # Convert bytes back to str (since we store it as c_char_p bytes)
        path_bytes = self._get_log_filename()
        return path_bytes.decode('utf-8') if isinstance(path_bytes, bytes) else path_bytes    

    # -------------------------------------------------------------------------
    # General Purpose: Return the absolute path to the current log directory.
    #
    # Current Logic: Returns decoded __logdir__ or empty string.
    # Defensive Notes: 
    # -------------------------------------------------------------------------
    def absoluteLogDir(self):
        """
        Return the absolute path to the current log directory.
        """
        if self.__logdir__ is None:
            return ""
        dir_bytes = self.__logdir__
        return dir_bytes.decode('utf-8') if isinstance(dir_bytes, bytes) else dir_bytes