# -*- coding: utf-8 -*-
# logged_example/__init__.py

"""
CIAO-DEFENSIVE v2.9.1 HEADER
============================
This file follows CIAO Defensive Programming Principles v2.9.1
(Caution • Intentional • Anti-fragile • Over-engineered)

Project: ChronicleLogger (logged_example package)
Purpose: Package initialization for ChronicleLogger module.
         Exposes main classes for easy import while maintaining clean public API.

General Purpose:
    Serve as the package entry point that re-exports the core classes 
    (ChronicleLogger and TimeProvider) and defines package metadata (__all__ and __version__).
    Ensures controlled, explicit exports to prevent accidental exposure of internal classes
    such as _Suroot.

Version: 1.3.0-ciao (independent module versioning per CIAO Principle 12)
Last Updated: 2026-04-11
"""

# ------------------------------------------------------------------------------
# General Purpose: Package-level imports and public API definition.
#
# Current Logic:
#   - Imports the three main internal modules/classes (_Suroot is imported but not exposed).
#   - Defines __all__ to explicitly control what gets imported with "from package import *".
#     Note: __all__ currently references dotted names (ChronicleLogger.ChronicleLogger etc.),
#     which is unusual but preserved exactly as original.
#   - Sets __version__ as a simple string for package metadata.
#
# Defensive Notes:
#   - No runtime code execution beyond imports.
#   - _Suroot remains private (not in __all__), following least-privilege principle.
# ------------------------------------------------------------------------------
from .Suroot import _Suroot
from .TimeProvider import TimeProvider
from .ChronicleLogger import ChronicleLogger

__all__ = ['ChronicleLogger.ChronicleLogger', 'TimeProvider.TimeProvider']
__version__ = "1.3.0"