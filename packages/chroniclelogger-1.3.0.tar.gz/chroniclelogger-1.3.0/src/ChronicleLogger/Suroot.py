# -*- coding: utf-8 -*-
# src/ChronicleLogger/Suroot.py

"""
CIAO-DEFENSIVE v2.9.1 HEADER
============================
This file follows CIAO Defensive Programming Principles v2.9.1
(Caution • Intentional • Anti-fragile • Over-engineered)

Project: ChronicleLogger
Purpose: Minimal, safe, non-interactive root/sudo detector for internal use only.
         Decides between /var/... and ~/.app/... log paths without ever prompting
         or printing anything.

General Purpose:
    Provide a tiny, zero-dependency, backward-compatible (Python 2.7+) privilege
    detection class that never interacts with the user, never prints, and is safe
    for CI/CD, tests, and production use.

Version: 1.3.0-ciao (independent module versioning per CIAO Principle 12)
"""

# NEW: Additional __future__ for better Py2 compatibility (unicode_literals for strings)
from __future__ import unicode_literals

import os
# NEW: Full import for subprocess module access in shim
import subprocess
from subprocess import Popen

# Python 2.7 compatibility shim
if not hasattr(subprocess, 'DEVNULL'):
    DEVNULL = open(os.devnull, 'wb')
else:
    DEVNULL = subprocess.DEVNULL


class _Suroot:
    """
    Tiny, zero-dependency, non-interactive privilege detector.
    Used by ChronicleLogger to decide log directory (/var/log vs ~/.app).
    NEVER prompts, NEVER prints, safe in CI/CD and tests.
    """

    CLASSNAME = "Suroot"
    MAJOR_VERSION = 1
    MINOR_VERSION = 2
    PATCH_VERSION = 3

    _is_root = None
    _can_sudo_nopasswd = None

    # -------------------------------------------------------------------------
    # General Purpose: Return the class name and version string.
    #
    # Current Logic:
    #   Uses .format() for Python 2/3 compatibility (no f-strings).
    #   Returns string in the form "Suroot v1.3.0".
    # Defensive Notes:
    # -------------------------------------------------------------------------
    @staticmethod
    def class_version():
        """Return the class name and version string."""
        # NEW: Replaced f-string with .format() for Py2 compat (f-strings Py3.6+)
        return "{0.CLASSNAME} v{0.MAJOR_VERSION}.{0.MINOR_VERSION}.{0.PATCH_VERSION}".format(_Suroot)

    # -------------------------------------------------------------------------
    # General Purpose: Check if we are currently running as root (euid == 0).
    #
    # Current Logic:
    #   Lazy cached result in class attribute _is_root.
    #   Calls os.geteuid() once and stores boolean result.
    # Defensive Notes:
    # -------------------------------------------------------------------------
    @staticmethod
    def is_root():  # NEW: Removed -> bool type hint (Py3.5+ syntax error in Py2)
        """Are we currently running as root (euid == 0)?"""
        if _Suroot._is_root is None:
            _Suroot._is_root = os.geteuid() == 0
        return _Suroot._is_root

    # -------------------------------------------------------------------------
    # General Purpose: Check if we can run 'sudo' commands without being asked for a password.
    #
    # Current Logic:
    #   Lazy cached result in _can_sudo_nopasswd.
    #   Runs "sudo -n true" non-interactively with all streams to DEVNULL.
    #   Uses version check for communicate(timeout=5) because Py2 does not support timeout.
    #   Returns True only if returncode == 0, otherwise False on any exception.
    # Defensive Notes:
    # -------------------------------------------------------------------------
    @staticmethod
    def can_sudo_without_password():  # NEW: Removed -> bool type hint
        """Can we run 'sudo' commands without being asked for a password?"""
        if _Suroot._can_sudo_nopasswd is not None:
            return _Suroot._can_sudo_nopasswd
        try:
            proc = Popen(
                ["sudo", "-n", "true"],
                stdin=DEVNULL,
                stdout=DEVNULL,
                stderr=DEVNULL,
            )
            # NEW: Py2 compat for communicate(timeout=5): Py2 Popen.communicate() lacks timeout (Py3.3+); use version check and fallback to no timeout (or add threading if strict timeout needed)
            if sys.version_info[0] >= 3 and sys.version_info[1] >= 3:
                proc.communicate(timeout=5)
            else:
                proc.communicate()  # No timeout in Py2; process may hang if sudo hangs, but non-interactive -n prevents prompts
            _Suroot._can_sudo_nopasswd = proc.returncode == 0
        except Exception:
            _Suroot._can_sudo_nopasswd = False

        return _Suroot._can_sudo_nopasswd