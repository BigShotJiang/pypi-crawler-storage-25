# -*- coding: utf-8 -*-
"""
CIAO-DEFENSIVE v2.9.1 HEADER
============================
This file follows CIAO Defensive Programming Principles v2.9.1
(Caution • Intentional • Anti-fragile • Over-engineered)

Project: ChronicleLogger Tests
Purpose: Comprehensive test suite for ChronicleLogger covering path resolution,
         environment detection (conda/pyenv/venv/root), logging behavior,
         rotation, archiving, cleanup, and cross-version (Py2/Py3) compatibility.

General Purpose:
    Validate that ChronicleLogger correctly derives log/base directories,
    handles privilege and environment hierarchies, performs daily rotation
    with archiving/removal, and maintains consistent behavior across
    different runtime environments and Python versions.

Version: 1.3.0-ciao-test (independent module versioning per CIAO Principle 12)
Last Updated: 2026-04-11
"""

from __future__ import print_function, absolute_import, division
import unittest
try:
    from unittest.mock import patch
except ImportError:
    from mock import patch  # Requires 'pip install mock' for Python 2.7
from os.path import join, realpath
import sys

import os
import sys
import tarfile
import re
from datetime import datetime, timedelta

import pytest

TEST_DIR = os.path.dirname(__file__)
SRC_DIR = os.path.abspath(os.path.join(TEST_DIR, "..", "src"))
sys.path.insert(0, SRC_DIR)

from ChronicleLogger import ChronicleLogger,TimeProvider

# -------------------------------------------------------------------------
# General Purpose: Fake time provider for deterministic time-based tests.
#
# Current Logic:
#   Inherits from TimeProvider and allows manual control of "now()" via
#   a fixed starting datetime and delta. Supports advance(), timedelta(),
#   and strftime() to simulate different dates without real time passage.
# Defensive Notes:
# -------------------------------------------------------------------------
class FakeTimeProvider(TimeProvider):
    def __init__(self):
        self.current_time = datetime(2025, 12, 25, 14, 30, 0)  # Fixed starting point
        self._delta = timedelta(0)

    def now(self):
        return self.current_time + self._delta

    def timedelta(self, **kwargs):
        return timedelta(**kwargs)

    def advance(self, **kwargs):
        """Advance simulated time by given amount (days, hours, etc.)"""
        self._delta += timedelta(**kwargs)

    def strftime(self, dt, fmt):
        return dt.strftime(fmt)

# -------------------------------------------------------------------------
# General Purpose: Fixture providing a fake, controllable time provider.
#
# Current Logic:
#   Returns a new FakeTimeProvider instance for tests that need time control.
# Defensive Notes:
# -------------------------------------------------------------------------
@pytest.fixture
def fake_time_provider():
    """Fixture providing a fake, controllable time provider for tests."""
    return FakeTimeProvider()

# -------------------------------------------------------------------------
# General Purpose: Fixture for a temporary log directory (Py2/Py3 compatible).
#
# Current Logic:
#   Uses pytest tmpdir fixture (str in Py2, Path in Py3), joins "log" subdir,
#   and ensures result is always str for cross-version compatibility.
# Defensive Notes:
# -------------------------------------------------------------------------
# NEW: Compatibility for pytest fixtures (tmp_path is Py3-only Path; use tmpdir for Py2/3 dual support)
#      tmpdir works in pytest 4.6.11 (Py2) as str, and in Py3 as Path, but we treat as str for compat
@pytest.fixture
def log_dir(tmpdir):  # NEW: Changed from tmp_path to tmpdir for Py2 compat (pin pytest==4.6.11)
    log_path = tmpdir.join("log")  # NEW: tmpdir.join() works for both (str in Py2, Path in Py3)
    return str(log_path)  # NEW: Ensure str for cross-version ops

# -------------------------------------------------------------------------
# General Purpose: Fixture creating a ChronicleLogger instance with temp log dir and fake time.
#
# Current Logic:
#   Combines log_dir and fake_time_provider fixtures to instantiate ChronicleLogger
#   with explicit logdir and injected fake time provider.
# Defensive Notes:
# -------------------------------------------------------------------------
@pytest.fixture
def logger(log_dir, fake_time_provider):
    return ChronicleLogger(
        logname="TestApp",
        logdir=log_dir,
        time_provider=fake_time_provider
    )

# -------------------------------------------------------------------------
# General Purpose: Verify directory is created on init when logdir is explicitly given.
#
# Current Logic:
#   Checks dir does not exist initially, creates logger with logdir, then asserts existence.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_directory_created_on_init_when_logdir_given(log_dir):
    assert not os.path.exists(log_dir)  # NEW: Use os.path.exists instead of .exists() for Py2 compat
    ChronicleLogger(logname="TestApp", logdir=log_dir)
    assert os.path.exists(log_dir)

# -------------------------------------------------------------------------
# General Purpose: Verify logname is converted to kebab-case in Python mode.
#
# Current Logic:
#   Creates logger with CamelCase names and asserts logName() returns kebab-case version.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_logname_becomes_kebab_case():
    logger = ChronicleLogger(logname="TestApp")
    assert logger.logName() == "test-app"

    logger = ChronicleLogger(logname="HelloWorld")
    assert logger.logName() == "hello-world"

# General Purpose: Verify logname remains unchanged in Cython/binary mode (inPython=False).
#
# Current Logic:
#   Patches inPython to return False, then checks that case is preserved.
# Defensive Notes:
# -------------------------------------------------------------------------
@patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.inPython', return_value=False)
def test_logname_unchanged_in_cython_binary(mock):
    logger = ChronicleLogger(logname="PreserveCase")
    logger.logName("PreserveCase")
    assert logger.logName() == "PreserveCase"

# -------------------------------------------------------------------------
# General Purpose: Verify explicit basedir is used and independent of auto-detection.
#
# Current Logic:
#   Passes custom basedir and asserts baseDir() returns exactly that value.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_basedir_is_user_defined_and_independent(tmpdir):  # NEW: Changed tmp_path to tmpdir for compat
    custom = str(tmpdir.join("myconfig"))  # NEW: Use tmpdir and str()
    logger = ChronicleLogger(logname="App", basedir=custom)
    assert logger.baseDir() == custom

# -------------------------------------------------------------------------
# General Purpose: Verify root user gets system path (/var/<appname>/log) when no explicit paths.
#
# Current Logic:
#   Patches is_root=True and conda list, then asserts logDir() points to /var/.../log.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_logdir_uses_system_path_when_privileged_and_not_set():
    with patch('ChronicleLogger._Suroot.is_root', return_value=True):
        with patch('sys.executable', '/usr/bin/root-binary'):
            return_value = "".encode('utf-8')
            with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.conda_env_list', return_value=return_value):
                logger = ChronicleLogger(logname="RootApp")
                expected = "/var/RootApp/log"  # NEW: Adjusted for preserved CamelCase in binary mode (no kebab); logDir derives from baseDir + /log
                assert logger.logDir() == expected

# -------------------------------------------------------------------------
# General Purpose: Verify executable path handling when not privileged with pyenv + venv (placeholder test).
#
# Current Logic:
#   Patches is_root=False and sys.executable to a pyenv path; currently asserts on sys.executable itself.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_executable_uses_user_path_when_not_privileged_and_pyenv_and_venv():
    with patch('ChronicleLogger.Suroot._Suroot.is_root', return_value=False):
        with patch('sys.executable', os.path.join(os.path.expanduser("~"), ".pyenv/versions/build/bin/python3") ):
            logger = ChronicleLogger(logname="UserApp")
            expected = os.path.join(os.path.expanduser("~"), ".pyenv/versions/build/bin/python3")  # NEW: Matches kebab-cased appname in Python mode + derived /log
            assert sys.executable == expected

# -------------------------------------------------------------------------
# General Purpose: Verify non-root, non-env case falls back to ~/.app/<kebab-name>/log.
#
# Current Logic:
#   Patches is_root=False, simple executable, empty conda; asserts user home .app path.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_logdir_uses_user_path_when_not_privileged_and_not_set():
    with patch('ChronicleLogger.Suroot._Suroot.is_root', return_value=False):
        with patch('sys.executable', '/usr/local/python'):
            return_value = "".encode('utf-8')
            with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.conda_env_list', return_value=return_value):
                logger = ChronicleLogger(logname="UserApp")
                expected = os.path.join(os.path.expanduser("~"), ".app/user-app", "log")  # NEW: Matches kebab-cased appname in Python mode + derived /log
                assert logger.logDir() == expected

# -------------------------------------------------------------------------
# General Purpose: Verify pyenv-only case (no venv) still falls back to user .app path.
#
# Current Logic:
#   Patches pyenv executable and pyenv_versions; asserts user home fallback.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_logdir_uses_user_path_when_not_privileged_and_pyenv():
    with patch('ChronicleLogger.Suroot._Suroot.is_root', return_value=False):
        with patch('sys.executable', os.path.join(os.path.expanduser("~"), ".pyenv/shims/python") ):
            with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.pyenv_versions', return_value='* 3.12.12 (set)'):
                return_value = "".encode('utf-8')
                with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.conda_env_list', return_value=return_value):
                    logger = ChronicleLogger(logname="UserApp")
                    expected = os.path.join(os.path.expanduser("~"), ".app/user-app", "log")  # NEW: Matches kebab-cased appname in Python mode + derived /log
                    assert logger.logDir() == expected

# -------------------------------------------------------------------------
# General Purpose: Verify pyenv + active venv case uses the venv path + .app/<kebab>/log.
#
# Current Logic:
#   Patches pyenv executable and pyenv_versions with active venv line; asserts venv-based path.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_logdir_uses_user_path_when_not_privileged_and_pyenv_and_venv():
    with patch('ChronicleLogger.Suroot._Suroot.is_root', return_value=False):
        with patch('sys.executable', os.path.join(os.path.expanduser("~"), ".pyenv/versions/build/bin/python") ):
            with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.pyenv_versions', return_value='* build --> /home/leolio/.pyenv/versions/3.12.12/envs/build (set)'):
                return_value = "".encode('utf-8')
                with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.conda_env_list', return_value=return_value):
                    logger = ChronicleLogger(logname="UserApp")
                    # Fixed expected path to match actual resolution from mocked sys.executable + real home
                    expected = os.path.join(
                        os.path.expanduser("~"), 
                        ".pyenv/versions/build/.app/user-app", 
                        "log"
                    )
                    assert logger.logDir() == expected

# -------------------------------------------------------------------------
# General Purpose: Verify explicit logdir completely overrides all auto-detection.
#
# Current Logic:
#   Passes logdir and asserts logDir() returns exactly the provided value.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_logdir_custom_path_overrides_everything(log_dir):
    logger = ChronicleLogger(logname="AnyApp", logdir=log_dir)
    assert logger.logDir() == log_dir

# -------------------------------------------------------------------------
# General Purpose: Verify log_message writes to the correct dated filename.
#
# Current Logic:
#   Calls log_message, constructs expected filename with real today, asserts file exists.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_log_message_writes_correct_filename(logger, log_dir):
    logger.log_message("Hello!", level="INFO")
    # NEW: Use the injected fake_time_provider's date instead of real datetime.now()
    #      (consistent with test_current_log_file_path and test_rotation_updates_current_log_file)
    today = logger.time_provider.now().strftime("%Y%m%d")
    logfile = os.path.join(log_dir, "test-app-{}.log".format(today))  # NEW: Replaced f-string with .format(); use os.path.join instead of /
    assert os.path.exists(logfile)

# -------------------------------------------------------------------------
# General Purpose: Verify ERROR/CRITICAL/FATAL levels are sent to stderr.
#
# Current Logic:
#   Parametrized test; calls log_message with error levels and checks capsys.err.
# Defensive Notes:
# -------------------------------------------------------------------------
@pytest.mark.parametrize("level", ["ERROR", "CRITICAL", "FATAL"])
def test_error_levels_go_to_stderr(logger, level, capsys):
    logger.log_message("Boom!", level=level)
    captured = capsys.readouterr()
    assert "Boom!" in captured.err

# -------------------------------------------------------------------------
# General Purpose: Verify old logs (> LOG_ARCHIVE_DAYS) are archived to .tar.gz.
#
# Current Logic:
#   Creates old log file, calls archive_old_logs, asserts .tar.gz exists.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_archive_old_logs(log_dir):
    logger = ChronicleLogger(logname="TestApp", logdir=log_dir)
    today_minus_10 = datetime.now() - timedelta(days=10)
    old_filename = "test-app-{}.log".format(today_minus_10.strftime('%Y%m%d'))  # NEW: Replaced f-string
    old_file = os.path.join(log_dir, old_filename)  # NEW: Use os.path.join instead of /
    old_dir = os.path.dirname(old_file)  # NEW: Explicitly get dirname for clarity
    if not os.path.exists(old_dir):
        os.makedirs(os.path.dirname(old_file)) 
    with open(old_file, 'w') as f:  # NEW: Replaced .write_text with open/write for Py2 compat
        f.write("old")
    logger.archive_old_logs()
    archived = os.path.join(log_dir, "{}.tar.gz".format(old_filename))  # NEW: Replaced f-string; os.path.join
    assert os.path.exists(archived)


# -------------------------------------------------------------------------
# General Purpose: Verify isDebug() respects DEBUG environment variable.
#
# Current Logic:
#   Uses monkeypatch to control DEBUG env var and checks isDebug() result.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_debug_mode(monkeypatch):
    monkeypatch.delenv("DEBUG", raising=False)
    assert not ChronicleLogger(logname="A").isDebug()
    monkeypatch.setenv("DEBUG", "show")
    assert ChronicleLogger(logname="B").isDebug()


# -------------------------------------------------------------------------
# General Purpose: Verify inPyenv() returns True when '.pyenv/' in executable (with caching).
#
# Current Logic:
#   Patches sys.executable and calls inPyenv() twice to confirm lazy caching.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_in_pyenv_true():
    with patch('sys.executable', '/home/user/.pyenv/shims/python'):
        logger = ChronicleLogger(logname="TestApp")
        assert logger.inPyenv() is True
        assert logger.inPyenv() is True  # Cached, no re-check


# -------------------------------------------------------------------------
# General Purpose: Verify inPyenv() returns False when no '.pyenv/' in executable (with caching).
#
# Current Logic:
#   Patches sys.executable without pyenv and checks False on repeated calls.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_in_pyenv_false():
    with patch('sys.executable', '/usr/bin/python'):
        logger = ChronicleLogger(logname="TestApp")
        assert logger.inPyenv() is False
        assert logger.inPyenv() is False  # Cached

# -------------------------------------------------------------------------
# General Purpose: Verify venv_path() and inVenv() when VIRTUAL_ENV is set (with caching).
#
# Current Logic:
#   Sets env var via monkeypatch and checks both methods return correct value on repeated calls.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_venv_path_and_in_venv_true(monkeypatch):
    venv_path = "/home/user/myvenv"
    monkeypatch.setenv('VIRTUAL_ENV', venv_path)
    logger = ChronicleLogger(logname="TestApp")
    assert logger.venv_path() == venv_path
    assert logger.inVenv() is True
    assert logger.venv_path() == venv_path  # Cached
    assert logger.inVenv() is True  # Cached


# -------------------------------------------------------------------------
# General Purpose: Verify venv_path() and inVenv() return empty/False when VIRTUAL_ENV not set (with caching).
#
# Current Logic:
#   Deletes env var and checks empty string / False on repeated calls.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_venv_path_and_in_venv_false(monkeypatch):
    monkeypatch.delenv('VIRTUAL_ENV', raising=False)
    logger = ChronicleLogger(logname="TestApp")
    assert logger.venv_path() == ''
    assert logger.inVenv() is False
    assert logger.venv_path() == ''  # Cached
    assert logger.inVenv() is False  # Cached


# -------------------------------------------------------------------------
# General Purpose: Verify pyenvVenv() correctly parses active venv from 'pyenv versions' output.
#
# Current Logic:
#   Mocks subprocess output and os.path.exists; checks extracted path and caching.
# Defensive Notes:
# -------------------------------------------------------------------------
@patch('subprocess.check_output')
@patch('os.path.exists', return_value=True)
def test_pyenv_venv_success(mock_exists, mock_output):
    sample_output = """  system
  3.12.12
* build --> /home/user/.pyenv/versions/3.12.12/envs/build (set by PYENV_VERSION)"""
    mock_output.return_value = sample_output.encode('utf-8')
    with patch('sys.executable', '/home/user/.pyenv/shims/python'):  # Trigger inPyenv True
        logger = ChronicleLogger(logname="TestApp")
        # NEW: Adjusted expectation to match code's strip() but account for potential extra text; code extracts after '--> ' and strips, so trims "(set by...)"
        extracted_path = '/home/user/.pyenv/versions/3.12.12/envs/build'  # NEW: Matches trimmed path without parenthetical
        assert logger.pyenvVenv() == extracted_path
        assert logger.pyenvVenv() == extracted_path  # Cached


# -------------------------------------------------------------------------
# General Purpose: Verify pyenvVenv() returns '' when not in pyenv.
#
# Current Logic:
#   Patches non-pyenv executable and checks empty string (with caching).
# Defensive Notes:
# -------------------------------------------------------------------------
def test_pyenv_venv_not_in_pyenv():
    with patch('sys.executable', '/usr/bin/python'):  # inPyenv False
        logger = ChronicleLogger(logname="TestApp")
        assert logger.pyenvVenv() == ''
        assert logger.pyenvVenv() == ''  # Cached


# -------------------------------------------------------------------------
# General Purpose: Verify pyenvVenv() returns '' on subprocess error (e.g. pyenv not found).
#
# Current Logic:
#   Mocks check_output to raise FileNotFoundError and checks empty result (with caching).
# Defensive Notes:
# -------------------------------------------------------------------------
@patch('subprocess.check_output', side_effect=FileNotFoundError)
def test_pyenv_venv_command_error(mock_output):
    with patch('sys.executable', '/home/user/.pyenv/shims/python'):  # inPyenv True
        logger = ChronicleLogger(logname="TestApp")
        assert logger.pyenvVenv() == ''
        assert logger.pyenvVenv() == ''  # Cached


# -------------------------------------------------------------------------
# General Purpose: Verify inConda() returns True when CONDA_DEFAULT_ENV set or 'conda' in executable.
#
# Current Logic:
#   Sets env var or patches executable and checks True (with caching).
# Defensive Notes:
# -------------------------------------------------------------------------
def test_in_conda_true(monkeypatch):
    monkeypatch.setenv('CONDA_DEFAULT_ENV', 'test_env')
    logger = ChronicleLogger(logname="TestApp")
    assert logger.inConda() is True
    assert logger.inConda() is True  # Cached
    # Also test executable check
    with patch('sys.executable', '/miniconda3/bin/python'):
        assert ChronicleLogger(logname="TestApp").inConda() is True


# -------------------------------------------------------------------------
# General Purpose: Verify inConda() returns False when no conda indicators.
#
# Current Logic:
#   Deletes env var and uses non-conda executable; checks False (with caching).
# Defensive Notes:
# -------------------------------------------------------------------------
def test_in_conda_false(monkeypatch):
    monkeypatch.delenv('CONDA_DEFAULT_ENV', raising=False)
    with patch('sys.executable', '/usr/bin/python'):
        logger = ChronicleLogger(logname="TestApp")
        assert logger.inConda() is False
        assert logger.inConda() is False  # Cached

# -------------------------------------------------------------------------
# General Purpose: Verify condaPath() parses active environment from 'conda env list' output.
#
# Current Logic:
#   Mocks conda_env_list and os.path.exists; checks extracted path and caching.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_conda_path_from_list():
    sample_output = """# conda environments:
#
base                 *   /home/user/miniconda3
test                     /home/user/miniconda3/envs/test"""
    return_value = sample_output.encode('utf-8')
    with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.conda_env_list', return_value=return_value):
        with patch('os.path.exists', return_value=True):
            logger = ChronicleLogger(logname="TestApp")
            assert logger.condaPath() == '/home/user/miniconda3'
            assert logger.condaPath() == '/home/user/miniconda3'  # Cached


# -------------------------------------------------------------------------
# General Purpose: Verify condaPath() returns '' on command error.
#
# Current Logic:
#   Mocks check_output to raise error and checks empty result (with caching).
# Defensive Notes:
# -------------------------------------------------------------------------
@patch('subprocess.check_output', side_effect=FileNotFoundError)
def test_conda_path_command_error(mock_output):
    sample_output = """# conda environments:
#
test                     /home/user/miniconda3/envs/test"""
    return_value = sample_output.encode('utf-8')
    with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.conda_env_list', return_value=return_value):
        with patch('os.path.exists', return_value=True):
            logger = ChronicleLogger(logname="TestApp")
            assert logger.condaPath() == ''
            assert logger.condaPath() == ''  # Cached


# -------------------------------------------------------------------------
# General Purpose: Verify base directory hierarchy prioritizes conda.
#
# Current Logic:
#   Mocks conda detection and checks .app/<kebab> appended to conda env path.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_base_dir_hierarchy_conda_priority(tmpdir):
    sample_output = """ 
# conda environments:
#
# * -> active
# + -> frozen
base                     /mock/conda/envs
test                 *   /mock/conda/envs/test
"""
    return_value = sample_output.encode('utf-8')
    with patch('ChronicleLogger.ChronicleLogger.ChronicleLogger.conda_env_list', return_value=return_value):
        with patch('sys.executable', '/miniconda3/bin/python'):  # inConda True
            with patch('os.path.exists', return_value=True):
                logger = ChronicleLogger(logname="TestApp")
                expected = os.path.join('/mock/conda/envs/test', '.app', 'test-app')  # NEW: Matches .app append for env case
                assert logger.baseDir() == expected


# -------------------------------------------------------------------------
# General Purpose: Verify base directory hierarchy for pyenv venv case.
#
# Current Logic:
#   Mocks pyenv output and checks .app/<kebab> appended to venv path.
# Defensive Notes:
# -------------------------------------------------------------------------
@patch('subprocess.check_output')
@patch('os.path.exists', return_value=True)
def test_base_dir_hierarchy_pyenv_venv(mock_exists, mock_output, monkeypatch):
    sample_output = """  system
* build --> /mock/pyenv/versions/3.12/envs/build"""  # NEW: Simplified sample without extra text for clean parsing
    mock_output.return_value = sample_output.encode('utf-8')
    with patch('sys.executable', '/.pyenv/shims/python'):  # inPyenv True, but no conda
        monkeypatch.delenv('CONDA_DEFAULT_ENV', raising=False)
        logger = ChronicleLogger(logname="TestApp")
        expected = os.path.join('/mock/pyenv/versions/3.12/envs/build', '.app', 'test-app')  # NEW: Matches .app append
        assert logger.baseDir() == expected


# -------------------------------------------------------------------------
# General Purpose: Verify base directory hierarchy for standard venv case.
#
# Current Logic:
#   Sets VIRTUAL_ENV and checks .app/<kebab> appended.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_base_dir_hierarchy_venv(monkeypatch):
    venv_path = '/mock/venv'
    monkeypatch.setenv('VIRTUAL_ENV', venv_path)
    monkeypatch.delenv('CONDA_DEFAULT_ENV', raising=False)
    with patch('sys.executable', '/usr/bin/python'):  # No pyenv/conda, but inPython True for kebab
        logger = ChronicleLogger(logname="TestApp")
        expected = os.path.join(venv_path, '.app', 'test-app')  # NEW: Matches .app append for venv
        assert logger.baseDir() == expected


# -------------------------------------------------------------------------
# General Purpose: Verify base directory fallback for non-root Python mode.
#
# Current Logic:
#   No special envs, non-root; checks ~/.app/<kebab-name>.
# Defensive Notes:
# -------------------------------------------------------------------------
@patch('ChronicleLogger._Suroot.is_root', return_value=False)
def test_base_dir_hierarchy_python_non_root(mock_root, monkeypatch):
    monkeypatch.delenv('VIRTUAL_ENV', raising=False)
    monkeypatch.delenv('CONDA_DEFAULT_ENV', raising=False)
    with patch('sys.executable', '/usr/bin/python3'):  # inPython True
        logger = ChronicleLogger(logname="TestApp")
        expected = os.path.join(os.path.expanduser("~"), '.app', 'test-app')  # NEW: Matches kebab-cased fallback
        assert logger.baseDir() == expected

# -------------------------------------------------------------------------
# General Purpose: Verify base directory for root user.
#
# Current Logic:
#   Patches is_root=True and checks /var/<appname> (no kebab in binary/root mode).
# Defensive Notes:
# -------------------------------------------------------------------------
def test_base_dir_hierarchy_root(monkeypatch):
    with patch('ChronicleLogger._Suroot.is_root', return_value=True):
        with patch('sys.executable', '/usr/bin/root-binary'):
            monkeypatch.delenv('VIRTUAL_ENV', raising=False)
            monkeypatch.delenv('CONDA_DEFAULT_ENV', raising=False)
            logger = ChronicleLogger(logname="RootApp")
            assert logger.baseDir() == '/var/RootApp'  # NEW: Matches preserved CamelCase for binary/root mode

# -------------------------------------------------------------------------
# General Purpose: Verify logDir() derives from baseDir + "/log".
#
# Current Logic:
#   Sets explicit basedir and checks logDir() appends "/log".
# Defensive Notes:
# -------------------------------------------------------------------------
def test_log_dir_derivation_from_base_dir(monkeypatch):
    base_path = '/mock/base'
    logger = ChronicleLogger(logname="TestApp", basedir=base_path)  # NEW: Explicit basedir set in init
    expected_log = '{0}/log'.format(base_path)  # NEW: Matches derivation from set baseDir + /log
    assert logger.logDir() == expected_log


# -------------------------------------------------------------------------
# General Purpose: Verify explicit logdir overrides baseDir derivation.
#
# Current Logic:
#   Passes logdir and asserts it is used directly.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_log_dir_explicit_override():
    explicit_log = '/mock/explicit/log'
    logger = ChronicleLogger(logname="TestApp", logdir=explicit_log)
    assert logger.logDir() == explicit_log  # Overrides baseDir derivation


# -------------------------------------------------------------------------
# General Purpose: Verify currentLogFile() returns correct dated path.
#
# Current Logic:
#   Writes a message then checks currentLogFile() matches expected filename with real today.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_current_log_file_path(log_dir, logger):
    # Write something to force file creation
    logger.log_message("Test message")
    
    current_file = logger.currentLogFile()
    assert current_file != ""
    assert current_file.startswith(log_dir)
    assert current_file.endswith(".log")
    
    # Minimal alignment: use the injected fake_time_provider's date instead of real datetime.now()
    today = logger.time_provider.now().strftime("%Y%m%d")   # ← only this line changed
    expected = os.path.join(log_dir, f"test-app-{today}.log")
    assert current_file == expected


# -------------------------------------------------------------------------
# General Purpose: Verify rotation updates currentLogFile() when date changes.
#
# Current Logic:
#   Logs on day 1, advances fake time, logs on day 2, checks filename changed.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_rotation_updates_current_log_file(log_dir, logger, fake_time_provider):
    # Use injected fake time provider
    logger.log_message("Day 1")
    day1_file = logger.currentLogFile()
    assert "20251225" in day1_file
    
    fake_time_provider.advance(days=1)
    logger.log_message("Day 2")
    
    day2_file = logger.currentLogFile()
    assert "20251226" in day2_file
    assert day2_file != day1_file


# -------------------------------------------------------------------------
# General Purpose: Verify archiving + removal of very old logs using fake time.
#
# Current Logic:
#   Creates old file, advances time past removal threshold, triggers log_message (rotation/cleanup),
#   then checks old file and its archive are deleted, and currentLogFile points to new date.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_archiving_with_fake_time(log_dir, fake_time_provider):
    """
    Test that very old logs (> LOG_REMOVAL_DAYS) are deleted (not just archived),
    and that currentLogFile() correctly reflects the active log file after rotation/cleanup.
    """
    # Use injected fake time provider
    logger = ChronicleLogger(
        logname="TestApp",
        logdir=log_dir,
        time_provider=fake_time_provider
    )

    # BEFORE advance: current file should be for day 0 (20251225)
    initial_current_file = logger.currentLogFile()
    assert initial_current_file != ""
    assert initial_current_file.endswith(".log")
    assert "test-app-20251225" in initial_current_file
    assert os.path.exists(initial_current_file)

    # Create old file (40 days old)
    old_date = fake_time_provider.now() - fake_time_provider.timedelta(days=40)
    old_filename = f"test-app-{old_date.strftime('%Y%m%d')}.log"
    old_path = os.path.join(log_dir, old_filename)
    with open(old_path, 'w') as f:
        f.write("old content from 40 days ago")

    # Advance 41 days → simulated date becomes ~Feb 4, 2026
    fake_time_provider.advance(days=41)

    # Write message → triggers rotation (new filename for current simulated date)
    logger.log_message("Trigger cleanup and rotation")

    # AFTER: currentLogFile() should now point to new date's file
    new_current_file = logger.currentLogFile()
    assert new_current_file != ""
    assert new_current_file != initial_current_file
    assert "test-app-20260204" in new_current_file  # or whatever the new date is
    assert os.path.exists(new_current_file)

    # Old file should be gone (removed, no archive)
    assert not os.path.exists(old_path)
    assert not os.path.exists(old_path + ".tar.gz")

# -------------------------------------------------------------------------
# General Purpose: Verify that when is_quiet=True, no messages are printed to stdout/stderr.
#
# Current Logic:
#   Creates logger with is_quiet=True, calls log_message with different levels,
#   checks that nothing appears in captured stdout or stderr.
# Defensive Notes:
# -------------------------------------------------------------------------
def test_is_quiet_suppresses_all_output(logger, capsys):
    # Override the fixture's logger to test quiet mode explicitly
    quiet_logger = ChronicleLogger(
        logname="TestApp",
        logdir=logger.logDir(),  # reuse the same temp log dir
        is_quiet=True,
        time_provider=logger.time_provider  # reuse fake time for consistency
    )

    # Test normal level
    quiet_logger.log_message("This should be silent", level="INFO")
    # Test error level (normally goes to stderr)
    quiet_logger.log_message("This error should be silent", level="ERROR")
    # Test debug level
    quiet_logger.log_message("Debug should be silent", level="DEBUG")

    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""