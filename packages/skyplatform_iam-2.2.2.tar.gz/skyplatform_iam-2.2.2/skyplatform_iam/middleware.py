"""
SkyPlatform IAM SDK 中间件模块
"""
import asyncio
import logging
from typing import Optional, Callable, Dict, Any

from fastapi import Request, Response, HTTPException, status
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from starlette.types import ASGIApp, Receive, Scope, Send
import jwt

from .config import AuthConfig, decode_jwt_token, get_global_jwks_manager
from .exceptions import (
    AuthenticationError,
    AuthorizationError,
    ConfigurationError,
)

logger = logging.getLogger(__name__)


class AuthMiddleware:
    """
    纯 ASGI 认证中间件。
    自动拦截请求进行 Token 验证和权限检查。
    """

    def __init__(
        self,
        app: ASGIApp,
        config: AuthConfig,
        skip_validation: Optional[Callable[[Request], bool]] = None,
    ):
        self.app = app
        self.config = config
        self.skip_validation = skip_validation

        try:
            self.config.validate_config()
        except ValueError as e:
            raise ConfigurationError(str(e))

        from . import get_iam_client
        self.iam_client = get_iam_client(config)

    def is_path_whitelisted(self, path: str) -> bool:
        if not self.config:
            return False
        return self.config.is_path_whitelisted(path)

    async def __call__(self, scope: Scope, receive: Receive, send: Send):
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive, send)

        try:
            api_path = request.url.path
            method = request.method

            if method == "OPTIONS":
                await self.app(scope, receive, send)
                return

            if self.is_path_whitelisted(api_path):
                logger.info(f"路径 {api_path} 在本地白名单中，跳过认证直接允许访问")
                request.state.user = None
                request.state.authenticated = False
                request.state.is_whitelist = True
                request.state.is_service_call = False
                await self.app(scope, receive, send)
                return

            service_token = request.headers.get("SERVICE-TOKEN")
            if service_token:
                svc_info = verify_service_token_locally(
                    service_token, self.config.server_name
                )
                if svc_info:
                    request.state.user = svc_info
                    request.state.authenticated = True
                    request.state.is_whitelist = False
                    request.state.is_service_call = True
                    await self.app(scope, receive, send)
                    return
                else:
                    response = self._create_error_response(
                        status_code=401,
                        message="SERVICE-TOKEN验证失败",
                        detail="服务间调用令牌无效、已过期或 audience 不匹配",
                    )
                    await response(scope, receive, send)
                    return

            token = self._extract_token(request)

            user_info = await self._verify_token_and_permission(request, token)
            if not user_info:
                response = self._create_error_response(
                    status_code=401,
                    message="Token验证失败",
                    detail="提供的Token无效或已过期",
                )
                await response(scope, receive, send)
                return

            if user_info.get('is_whitelist', False):
                request.state.user = None
                request.state.authenticated = False
                request.state.is_whitelist = True
            else:
                request.state.user = user_info
                request.state.authenticated = True
                request.state.is_whitelist = False
            request.state.is_service_call = False

            await self.app(scope, receive, send)

        except HTTPException as e:
            response = self._create_error_response(
                status_code=e.status_code,
                message=str(e.detail),
                detail=getattr(e, 'detail', None),
            )
            await response(scope, receive, send)
        except AuthenticationError as e:
            response = self._create_error_response(
                status_code=e.status_code, message=e.message, detail=e.detail,
            )
            await response(scope, receive, send)
        except AuthorizationError as e:
            response = self._create_error_response(
                status_code=e.status_code, message=e.message, detail=e.detail,
            )
            await response(scope, receive, send)
        except Exception as e:
            logger.error(f"认证中间件处理异常: {str(e)}")
            if self.config.enable_debug:
                logger.exception("详细异常信息:")
            response = self._create_error_response(
                status_code=500,
                message="内部服务器错误",
                detail=str(e) if self.config.enable_debug else None,
            )
            await response(scope, receive, send)

    def _extract_token(self, request: Request) -> Optional[str]:
        """从请求中提取用户 Bearer Token"""
        auth_header = request.headers.get(self.config.token_header)
        if auth_header and auth_header.startswith(self.config.token_prefix):
            return auth_header[len(self.config.token_prefix):].strip()

        token = request.query_params.get("token")
        if token:
            return token

        return None

    async def _verify_token_and_permission(self, request: Request, token: Optional[str]) -> Optional[Dict[str, Any]]:
        """
        通过 IAM 远程验证用户 token 和接口权限。
        不再转发请求头中的 SERVER-AK/SERVER-SK，服务身份由 SDK 自身的 machine_token 标识。
        """
        try:
            api_path = request.url.path
            method = request.method

            user_info = await asyncio.to_thread(
                self.iam_client.verify_token,
                token=token or "",
                api=api_path,
                method=method,
            )
            return user_info

        except HTTPException:
            raise
        except Exception as e:
            if self.config.enable_sdk_logging:
                logger.error(f"Token验证异常: {str(e)}")
                if self.config.enable_debug:
                    logger.exception("详细异常信息:")
            return None

    def _create_error_response(
            self,
            status_code: int,
            message: str,
            detail: Optional[str] = None
    ) -> JSONResponse:
        """
        创建错误响应
        """
        error_data = {
            "success": False,
            "message": message,
            "status_code": status_code
        }

        if detail:
            error_data["detail"] = detail

        return JSONResponse(
            status_code=status_code,
            content=error_data
        )


def verify_service_token_locally(
    service_token: str, server_name: str
) -> Optional[Dict[str, Any]]:
    """
    使用 JWKS 公钥本地验证 service-to-service token。
    校验：签名、过期、audience（必须为 svc:<server_name>）、type。
    """
    mgr = get_global_jwks_manager()
    if not mgr:
        logger.warning("SERVICE-TOKEN 验证失败: JWKS 管理器未初始化")
        return None

    expected_audience = f"svc:{server_name}"

    try:
        kid = None
        try:
            kid = jwt.get_unverified_header(service_token).get("kid")
        except Exception:
            pass

        pub_key = mgr.get_public_key(kid)
        if not pub_key:
            pub_key = mgr.get_public_key_or_refresh(kid)
        if not pub_key:
            logger.warning("SERVICE-TOKEN 验证失败: 无可用公钥")
            return None

        payload = jwt.decode(
            service_token,
            pub_key,
            algorithms=["RS256"],
            audience=expected_audience,
            leeway=30,
        )

        if payload.get("type") != "service_to_service":
            logger.warning(f"SERVICE-TOKEN type 不匹配: {payload.get('type')}")
            return None

        svc_info = {
            "source_service": payload.get("source_service"),
            "source_space_id": payload.get("source_space_id"),
            "user_id": payload.get("sub"),
            "is_service_call": True,
        }
        logger.info(f"SERVICE-TOKEN 本地验签成功: source={svc_info['source_service']}")
        return svc_info

    except jwt.ExpiredSignatureError:
        logger.warning("SERVICE-TOKEN 已过期")
        return None
    except jwt.InvalidAudienceError:
        logger.warning(f"SERVICE-TOKEN audience 不匹配, 期望 {expected_audience}")
        return None
    except Exception as e:
        logger.error(f"SERVICE-TOKEN 验证异常: {e}")
        return None


class AuthService:
    """
    认证服务类
    提供依赖注入式的认证功能
    """

    def __init__(self, auth_config: AuthConfig):
        if auth_config is None:
            raise ValueError("auth_config参数不能为None，必须传入AuthConfig配置对象")
        self.security = HTTPBearer(auto_error=False)
        self.auth_config = auth_config

        from . import get_iam_client
        self.iam_client = get_iam_client(auth_config)

    def is_path_whitelisted(self, path: str) -> bool:
        if not self.auth_config:
            return False
        return self.auth_config.is_path_whitelisted(path)

    async def verify_token(self, request: Request):
        """验证token和权限（支持 SERVICE-TOKEN 本地验签 + 用户 token IAM 远程鉴权）"""
        api_path = request.url.path

        if self.is_path_whitelisted(api_path):
            logger.info(f"路径 {api_path} 在白名单中，跳过IAM鉴权")
            return True

        service_token = request.headers.get("SERVICE-TOKEN")
        if service_token:
            svc_info = verify_service_token_locally(
                service_token, self.auth_config.server_name
            )
            return svc_info is not None

        credentials: HTTPAuthorizationCredentials = await self.security(request)
        method = request.method

        token = ""
        if credentials is not None:
            token = credentials.credentials
        user_info_by_iam = await asyncio.to_thread(
            self.iam_client.verify_token, token, api_path, method
        )
        if user_info_by_iam:
            return True
        return False

    async def get_current_user(self, request: Request) -> Optional[Dict]:
        """获取当前用户信息"""
        try:
            if not await self.verify_token(request):
                return None

            credentials: HTTPAuthorizationCredentials = await self.security(request)
            if not credentials:
                return None

            token = credentials.credentials

            payload = decode_jwt_token(token)
            if not payload:
                logger.error("JWT token解析失败")
                return None

            iam_user_id = payload.get("sub")
            username = None

            all_credentials = payload.get("all_credentials", [])
            total_credentials = payload.get("total_credentials", 0)

            for cred in all_credentials:
                if cred.get("type") == "username":
                    username = cred.get("value")
                    break

            if not all_credentials:
                credentials_list = []
                if payload.get("username"):
                    username = payload.get("username")
                    credentials_list.append({"type": "username", "value": username})
                if payload.get("email"):
                    credentials_list.append({"type": "email", "value": payload.get("email")})
                if payload.get("phone"):
                    credentials_list.append({"type": "phone", "value": payload.get("phone")})
                all_credentials = credentials_list
                total_credentials = len(credentials_list)

            user_info = {
                "id": iam_user_id,
                "username": username,
                "all_credentials": all_credentials,
                "total_credentials": total_credentials,
                "space": payload.get("space"),
                "space_id": payload.get("space_id")
            }

            for cred in all_credentials:
                if cred.get("type") == "email":
                    user_info["email"] = cred.get("value")
                elif cred.get("type") == "phone":
                    user_info["phone"] = cred.get("value")
                elif cred.get("type") == "username" and not user_info.get("username"):
                    user_info["username"] = cred.get("value")

            cred_types = [cred.get("type") for cred in all_credentials]
            cred_type_count = {cred_type: cred_types.count(cred_type) for cred_type in set(cred_types)}

            logger.info(
                f"用户认证成功: user_id={iam_user_id}, username={username}, "
                f"凭证数量={total_credentials}, 凭证类型分布={cred_type_count}"
            )
            logger.debug(f"JWT payload: {payload}")

            request.state.user = user_info
            return user_info

        except HTTPException:
            return None
        except Exception as e:
            logger.error(f"获取当前用户信息失败: {str(e)}")
            return None

    async def require_auth(self, request: Request) -> Dict:
        """要求用户必须登录"""
        try:
            user_info = await self.get_current_user(request)
            if not user_info:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="需要登录认证",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            return user_info
        except HTTPException:
            raise

    async def optional_auth(self, request: Request) -> Optional[Dict]:
        """可选的用户认证（不强制要求登录）"""
        try:
            return await self.get_current_user(request)
        except HTTPException:
            raise


# 全局认证服务实例（延迟初始化）
auth_service = None


def setup_auth_middleware(auth_config: AuthConfig) -> None:
    """
    设置认证中间件配置
    
    Args:
        auth_config: 认证配置实例，包含白名单路径等配置
    """
    global auth_service
    auth_service = AuthService(auth_config)
    if auth_config.enable_sdk_logging:
        logger.info(f"认证中间件已配置，白名单路径数量: {len(auth_config.get_whitelist_paths())}")


# 便捷的依赖函数
async def get_current_user(request: Request) -> Dict:
    """获取当前用户的依赖函数"""
    if auth_service is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="认证服务未初始化，请先调用setup_auth_middleware函数进行配置"
        )
    return await auth_service.require_auth(request)


async def get_optional_user(request: Request) -> Optional[Dict]:
    """获取可选当前用户的依赖函数"""
    if auth_service is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="认证服务未初始化，请先调用setup_auth_middleware函数进行配置"
        )
    return await auth_service.optional_auth(request)
