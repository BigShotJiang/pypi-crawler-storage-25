import requests
import requests.exceptions
import logging
import traceback
import copy
import time
from enum import Enum
from typing import Optional, Union, Dict, Any

from fastapi import HTTPException, status

from .config import decode_jwt_token, JWKSManager, set_global_jwks_manager
from .exceptions import NetworkError, IAMServiceError

logger = logging.getLogger(__name__)


class CredentialTypeEnum(str, Enum):
    USERNAME = "username"
    EMAIL = "email"
    PHONE = "phone"
    WECHAT_OPENID = "wechat_openid"


class ConnectSkyplatformIam:
    _instance = None
    _initialized = False

    def __new__(cls, config=None, **_kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, config=None, **_kwargs):
        if self._initialized:
            return

        if config is None:
            raise ValueError("必须传入AuthConfig配置对象")

        self.config = config

        self._session = requests.Session()
        self._session.verify = getattr(config, 'ssl_verify', True)

        self.skyplatform_iam_host = config.skyplatform_iam_host
        self.server_name = config.server_name
        self.access_key = config.access_key
        self.machine_token = config.machine_token or ""
        self.ssl_verify = getattr(config, 'ssl_verify', True)
        self._machine_token_exp = None
        self._machine_token_last_fetch = None
        self._default_machine_token_ttl = 7200

        logger.info("使用传入的AuthConfig配置")

        for attr, label in [
            (self.skyplatform_iam_host, "SKYPLATFORM_IAM_HOST"),
            (self.server_name, "SKYPLATFORM_SERVER_NAME"),
            (self.access_key, "SKYPLATFORM_ACCESS_KEY"),
        ]:
            if not attr:
                logger.warning(f"{label} 配置未设置")

        logger.info(
            f"初始化SkyplatformIAM连接器 - Host: {self.skyplatform_iam_host}, "
            f"Server: {self._mask_sensitive(self.server_name)}"
        )

        self.service_credential_headers = {
            "Content-Type": "application/json",
            "SERVER-AK": self.server_name,
            "SERVER-SK": self.access_key,
        }

        self.jwks_manager = None
        if self.skyplatform_iam_host:
            jwks_url = self.skyplatform_iam_host.rstrip("/") + "/api/v2/service/jwks.json"
            self.jwks_manager = JWKSManager(jwks_url, ssl_verify=self.ssl_verify)
            set_global_jwks_manager(self.jwks_manager)
            try:
                self.jwks_manager.refresh()
            except Exception as e:
                logger.warning(f"初始化时拉取 JWKS 公钥失败，将在首次验签时重试: {e}")

        try:
            self.ensure_machine_token()
        except Exception:
            pass

        self._service_token_cache: Dict[str, tuple] = {}
        self._authorized_services: list = []
        self._authorized_services_last_fetch: float = 0
        self._authorized_services_ttl: int = 300
        try:
            self._fetch_authorized_services()
        except Exception as e:
            logger.warning(f"初始化时拉取授权服务列表失败，将在首次调用时重试: {e}")

        self._initialized = True

    def _build_headers(self) -> dict:
        self.ensure_machine_token()
        h = {"Content-Type": "application/json"}
        if self.machine_token:
            h["MACHINE-TOKEN"] = self.machine_token
        return h

    def _build_service_credential_headers(self) -> dict:
        return self.service_credential_headers.copy()

    def _request_with_retry(
        self, method: str, url: str, max_retries: int = 2, **kwargs
    ) -> requests.Response:
        last_exc: Optional[Exception] = None
        for attempt in range(1, max_retries + 1):
            try:
                response = self._session.request(method, url, timeout=10, **kwargs)
                return response
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
                last_exc = e
                if attempt < max_retries:
                    logger.warning(f"请求失败（第 {attempt} 次），将重试: {url}")
                    time.sleep(0.5 * attempt)
                else:
                    raise
        raise last_exc  # type: ignore[misc]

    @staticmethod
    def _classify_request_error(exc: Exception, method_name: str):
        if isinstance(exc, (requests.exceptions.ConnectionError, requests.exceptions.Timeout)):
            raise NetworkError(f"[{method_name}] 无法连接 IAM 服务: {exc}") from exc
        if isinstance(exc, requests.exceptions.SSLError):
            raise NetworkError(f"[{method_name}] SSL/TLS 验证失败: {exc}") from exc
        raise IAMServiceError(f"[{method_name}] 请求异常: {exc}") from exc

    def _update_machine_token(self, token: str):
        self.machine_token = token
        self._machine_token_last_fetch = time.time()
        try:
            payload = decode_jwt_token(token) or {}
            self._machine_token_exp = payload.get("exp")
        except Exception:
            self._machine_token_exp = None
        try:
            self.config.machine_token = token
        except Exception:
            pass

    def _is_machine_token_valid(self, margin: int = 300) -> bool:
        if not self.machine_token:
            return False
        if self._machine_token_exp:
            return (time.time() + margin) < float(self._machine_token_exp)
        if self._machine_token_last_fetch:
            return (time.time() - self._machine_token_last_fetch) < (self._default_machine_token_ttl - margin)
        return True

    def reload_config(self, config):
        if config is None:
            raise ValueError("必须传入AuthConfig配置对象")

        logger.info("重新加载配置")

        self.config = config
        self.skyplatform_iam_host = config.skyplatform_iam_host
        self.server_name = config.server_name
        self.access_key = config.access_key
        self.ssl_verify = getattr(config, 'ssl_verify', True)
        self._session.verify = self.ssl_verify

        for attr, label in [
            (self.skyplatform_iam_host, "SKYPLATFORM_IAM_HOST"),
            (self.server_name, "SKYPLATFORM_SERVER_NAME"),
            (self.access_key, "SKYPLATFORM_ACCESS_KEY"),
        ]:
            if not attr:
                logger.warning(f"{label} 配置未设置")

        self.service_credential_headers = {
            "Content-Type": "application/json",
            "SERVER-AK": self.server_name,
            "SERVER-SK": self.access_key,
        }

        if self.skyplatform_iam_host:
            jwks_url = self.skyplatform_iam_host.rstrip("/") + "/api/v2/service/jwks.json"
            if self.jwks_manager:
                self.jwks_manager._jwks_url = jwks_url
                self.jwks_manager._ssl_verify = self.ssl_verify
                try:
                    self.jwks_manager.refresh()
                except Exception:
                    pass
            else:
                self.jwks_manager = JWKSManager(jwks_url, ssl_verify=self.ssl_verify)
                set_global_jwks_manager(self.jwks_manager)
                try:
                    self.jwks_manager.refresh()
                except Exception:
                    pass

        self._authorized_services = []
        self._authorized_services_last_fetch = 0

        self.ensure_machine_token()
        self._fetch_authorized_services()

        logger.info(
            f"配置重新加载完成 - Host: {self.skyplatform_iam_host}, "
            f"Server: {self._mask_sensitive(self.server_name)}"
        )

    def ensure_machine_token(self) -> str:
        try:
            if self._is_machine_token_valid():
                return self.machine_token
            token = self._fetch_machine_token()
            if token:
                return token
        except (NetworkError, IAMServiceError):
            raise
        except Exception as e:
            logger.warning(f"[ensure_machine_token] 自动获取machine_token失败: {str(e)}")
        if not self.machine_token:
            raise NetworkError("无法获取 machine_token，请检查 skyplatform_iam_host 和 access_key 配置")
        return self.machine_token

    def _fetch_machine_token(self) -> Optional[str]:
        method_name = "fetch_machine_token"
        endpoints = [
            "/api/v2/service/get_machine_token",
            "/api/v2/service/machine_token",
        ]
        body = {
            "server_name": self.server_name,
            "access_key": self.access_key,
        }
        for uri in endpoints:
            try:
                url = self.skyplatform_iam_host + uri
                service_headers = self._build_service_credential_headers()
                self._log_request(method_name, url, service_headers, body)
                response = self._request_with_retry(
                    "POST", url, headers=service_headers, json=body
                )
                self._log_response(method_name, response)
                if response.status_code == 200:
                    data = {}
                    try:
                        data = response.json()
                    except Exception:
                        data = {}
                    token = None
                    container = data.get("data", data)
                    if isinstance(container, dict):
                        token = container.get("machine_token") or container.get("machine_access_token")
                    elif isinstance(container, str):
                        token = container
                    if token:
                        logger.info(f"[{method_name}] 获取machine_token成功")
                        self._update_machine_token(token)
                        return token
            except Exception as e:
                logger.warning(f"[{method_name}] 尝试 {uri} 失败: {str(e)}")
        logger.warning(f"[{method_name}] 无法自动获取machine_token")
        return None

    # ── 服务间授权列表 + 调用令牌 ──

    def _fetch_authorized_services(self):
        method_name = "fetch_authorized_services"
        try:
            self.ensure_machine_token()
            url = self.skyplatform_iam_host + "/api/v2/service/authorized_services"
            self._log_request(method_name, url, self._build_headers(), None)
            response = self._request_with_retry("GET", url, headers=self._build_headers())
            self._log_response(method_name, response)
            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    self._authorized_services = data.get("data", {}).get("authorized", [])
                    self._authorized_services_last_fetch = time.time()
                    logger.info(f"[{method_name}] 授权服务列表: {self._authorized_services}")
                    return
            logger.warning(f"[{method_name}] 拉取失败: status={response.status_code}")
        except Exception as e:
            logger.warning(f"[{method_name}] 异常: {e}")

    def _ensure_authorized_services(self):
        if (
            not self._authorized_services
            or (time.time() - self._authorized_services_last_fetch > self._authorized_services_ttl)
        ):
            self._fetch_authorized_services()

    def get_authorized_services(self) -> list:
        self._ensure_authorized_services()
        return list(self._authorized_services)

    def get_service_token(self, target_service: str, ttl: int = 1800) -> str:
        method_name = "get_service_token"

        self._ensure_authorized_services()
        if self._authorized_services and target_service not in self._authorized_services:
            logger.warning(
                f"[{method_name}] 服务 '{target_service}' 不在授权列表中，"
                f"当前授权: {self._authorized_services}"
            )
            return ""

        cached = self._service_token_cache.get(target_service)
        if cached:
            token_str, exp_ts = cached
            if time.time() + 300 < exp_ts:
                return token_str

        logger.info(f"[{method_name}] 请求签发 service_token -> {target_service}")
        try:
            self.ensure_machine_token()
            body = {"target_service": target_service, "ttl": ttl}
            uri = "/api/v2/service/get_service_token"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry(
                "POST", url, headers=self._build_headers(), json=body
            )
            self._log_response(method_name, response)

            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    st = data["data"]["service_token"]
                    exp_in = data["data"].get("expires_in", ttl)
                    self._service_token_cache[target_service] = (st, time.time() + exp_in)
                    logger.info(f"[{method_name}] 获取 service_token 成功, target={target_service}")
                    return st
                else:
                    logger.warning(f"[{method_name}] IAM 拒绝: {data.get('message')}")
            else:
                logger.warning(f"[{method_name}] 请求失败: status={response.status_code}")
        except Exception as e:
            logger.error(f"[{method_name}] 异常: {e}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")

        return ""

    def build_service_call_headers(self, target_service: str, ttl: int = 1800) -> dict:
        token = self.get_service_token(target_service, ttl)
        h = {"Content-Type": "application/json"}
        if token:
            h["SERVICE-TOKEN"] = token
        return h

    def _mask_sensitive(self, value, mask_char="*", show_chars=4):
        if not value or not isinstance(value, str):
            return str(value) if value else "None"
        if len(value) <= show_chars:
            return mask_char * len(value)
        return value[:show_chars] + mask_char * (len(value) - show_chars)

    def _sanitize_log_data(self, data):
        if not isinstance(data, dict):
            return data
        sensitive_fields = [
            'password', 'access_key', 'token', 'refresh_token',
            'SERVER-SK', 'new_password', 'server_sk',
        ]
        sanitized = copy.deepcopy(data)
        for key, value in sanitized.items():
            if key.lower() in [f.lower() for f in sensitive_fields]:
                sanitized[key] = self._mask_sensitive(str(value))
            elif isinstance(value, dict):
                sanitized[key] = self._sanitize_log_data(value)
        return sanitized

    def _log_request(self, method_name, url, headers, body):
        sanitized_headers = self._sanitize_log_data(headers)
        sanitized_body = self._sanitize_log_data(body)
        logger.info(f"[{method_name}] 发送请求 - URL: {url}")
        logger.info(f"[{method_name}] 请求头: {sanitized_headers}")
        logger.info(f"[{method_name}] 请求体: {sanitized_body}")

    def _log_response(self, method_name, response):
        try:
            response_data = response.json() if response.content else {}
            sanitized_response = self._sanitize_log_data(response_data)
            logger.info(f"[{method_name}] 响应状态码: {response.status_code}")
            logger.info(f"[{method_name}] 响应内容: {sanitized_response}")
        except Exception as e:
            logger.info(f"[{method_name}] 响应状态码: {response.status_code}")
            logger.info(f"[{method_name}] 响应内容解析失败: {str(e)}")

    def register(
        self, cred_type=None, cred_value=None, password=None,
        nickname=None, avatar_url=None, username=None, phone=None,
    ) -> Optional[dict]:
        """
        注册用户时，同步至iam

        返回:
        - 成功: 返回包含用户信息的字典
        - 失败: 返回None
        """
        method_name = "register"
        logger.info(
            f"[{method_name}] 开始用户注册 - cred_type: {cred_type}, "
            f"cred_value: {self._mask_sensitive(str(cred_value))}"
        )

        try:
            self.ensure_machine_token()
            if cred_type is None and cred_value is None:
                if username:
                    cred_type = CredentialTypeEnum.USERNAME
                    cred_value = username
                elif phone:
                    cred_type = CredentialTypeEnum.PHONE
                    cred_value = phone
                else:
                    raise ValueError("必须提供 cred_type+cred_value 或 username/phone")

            if isinstance(cred_type, str):
                cred_type = CredentialTypeEnum(cred_type)

            body: Dict[str, Any] = {
                "cred_type": cred_type.value,
                "cred_value": cred_value,
            }
            if password:
                body["password"] = password
            if nickname:
                body["nickname"] = nickname
            if avatar_url:
                body["avatar_url"] = avatar_url

            uri = "/api/v2/service/register"
            url = self.skyplatform_iam_host + uri
            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    logger.info(f"[{method_name}] 用户注册成功")
                    return result.get("data")
                else:
                    logger.warning(f"[{method_name}] 用户注册失败 - 响应: {result}")
            else:
                logger.warning(f"[{method_name}] 用户注册失败 - 状态码: {response.status_code}")

            return None
        except Exception as e:
            logger.error(f"[{method_name}] 注册请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return None

    def login_with_password(
        self, cred_type=None, cred_value=None, password=None,
        ip_address=None, user_agent=None, username=None,
    ) -> Optional[dict]:
        """
        账号密码登陆时，同步至iam，由iam签发token

        返回:
        - 成功: 返回包含 access_token / refresh_token 的字典
        - 失败: 返回None
        """
        method_name = "login_with_password"
        logger.info(
            f"[{method_name}] 开始密码登录 - cred_type: {cred_type}, "
            f"cred_value: {self._mask_sensitive(str(cred_value))}"
        )

        try:
            if cred_type is None and cred_value is None:
                if username:
                    cred_type = CredentialTypeEnum.USERNAME
                    cred_value = username
                else:
                    raise ValueError("必须提供 cred_type+cred_value 或 username")

            if isinstance(cred_type, str):
                cred_type = CredentialTypeEnum(cred_type)

            body: Dict[str, Any] = {
                "cred_type": cred_type.value,
                "cred_value": cred_value,
                "password": password,
            }
            if ip_address:
                body["ip_address"] = ip_address
            if user_agent:
                body["user_agent"] = user_agent

            uri = "/api/v2/service/login"
            url = self.skyplatform_iam_host + uri
            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    logger.info(f"[{method_name}] 密码登录成功")
                    return result.get("data")
                else:
                    logger.warning(f"[{method_name}] 密码登录失败 - 响应: {result}")
            else:
                logger.warning(f"[{method_name}] 密码登录失败 - 状态码: {response.status_code}")

            return None
        except Exception as e:
            logger.error(f"[{method_name}] 密码登录请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return None

    def logout(self, token) -> bool:
        method_name = "logout"
        logger.info(f"[{method_name}] 开始用户登出 - token: {self._mask_sensitive(token)}")

        try:
            self.ensure_machine_token()
            body = {"token": token}
            uri = "/api/v2/service/logout"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                logger.info(f"[{method_name}] 用户登出成功")
                return True
            else:
                logger.warning(f"[{method_name}] 用户登出失败 - 状态码: {response.status_code}")

            return False
        except Exception as e:
            logger.error(f"[{method_name}] 登出请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return False

    def verify_token(
        self, token, api, method, server_ak="", server_sk="", machine_token=""
    ) -> Optional[dict]:
        """
        请求 IAM 进行用户 token 鉴权。
        server_ak / server_sk / machine_token 参数已废弃。

        返回:
        - 成功且有权限: 返回用户信息字典
        - 成功但无权限: 抛出403异常
        - token无效或其他错误: 返回None
        """
        method_name = "verify_token"
        logger.info(
            f"[{method_name}] 开始token验证 - api: {api}, method: {method}, "
            f"token: {self._mask_sensitive(token)}"
        )

        try:
            self.ensure_machine_token()
            body = {
                "token": token,
                "api": api,
                "method": method,
            }
            uri = "/api/v2/service/verify"

            if self.skyplatform_iam_host is None:
                raise ValueError("SKYPLATFORM_IAM_HOST 配置未设置或为空，请确保传入正确的AuthConfig对象")

            url = self.skyplatform_iam_host + uri
            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success") and result.get("valid"):
                    if result.get("has_permission"):
                        user_info = {
                            "user_id": result.get("user_id"),
                            "username": result.get("username"),
                            "session_id": result.get("session_id"),
                            "space": result.get("space"),
                            "is_whitelist": result.get("is_whitelist", False),
                        }
                        logger.info(
                            f"[{method_name}] token验证成功，用户有权限 - user_id: {user_info.get('user_id')}"
                        )
                        return user_info
                    else:
                        logger.warning(f"[{method_name}] token有效但用户无权限访问API: {api}")
                        raise HTTPException(
                            status_code=status.HTTP_403_FORBIDDEN,
                            detail=result.get("message", "用户无权限访问此API"),
                        )
                else:
                    logger.warning(
                        f"[{method_name}] token验证失败 - success: {result.get('success')}, "
                        f"valid: {result.get('valid')}"
                    )

            elif response.status_code == 403:
                result = response.json()
                logger.warning(f"[{method_name}] 收到403响应 - {result.get('message', '用户无权限访问此API')}")
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=result.get("message", "用户无权限访问此API"),
                )
            else:
                logger.warning(f"[{method_name}] token验证失败 - 状态码: {response.status_code}")

            return None
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"[{method_name}] Token验证异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            self._classify_request_error(e, method_name)

    def refresh_token(self, refresh_token) -> Optional[dict]:
        """
        机机接口：刷新用户令牌

        返回: 包含 access_token / refresh_token 的字典，或 None
        """
        method_name = "refresh_token"
        logger.info(f"[{method_name}] 开始刷新令牌 - refresh_token: {self._mask_sensitive(refresh_token)}")

        try:
            self.ensure_machine_token()
            body = {"refresh_token": refresh_token}
            uri = "/api/v2/service/refresh_token"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    logger.info(f"[{method_name}] 令牌刷新成功")
                    return result.get("data")
                else:
                    logger.warning(f"[{method_name}] 令牌刷新失败 - 响应: {result}")
            else:
                logger.warning(f"[{method_name}] 令牌刷新失败 - 状态码: {response.status_code}")

            return None
        except Exception as e:
            logger.error(f"[{method_name}] 刷新令牌请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return None

    def get_user_info(self, user_id) -> Optional[dict]:
        """
        机机接口：获取用户信息

        返回:
        - 成功: 用户信息字典
        - 失败: 返回None
        """
        method_name = "get_user_info"
        logger.info(f"[{method_name}] 获取用户信息 - user_id: {user_id}")

        try:
            self.ensure_machine_token()
            body = {"user_id": user_id}
            uri = "/api/v2/service/get_user_info"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    return data.get("data")
                else:
                    logger.warning(f"[{method_name}] IAM 拒绝: {data.get('message')}")
            else:
                logger.warning(f"[{method_name}] 请求失败: status={response.status_code}")
        except Exception as e:
            logger.error(f"[{method_name}] 异常: {e}")
            self._classify_request_error(e, method_name)

        return None

    def add_custom_config(self, user_id, config_name, config_value=None) -> Optional[dict]:
        """
        机机接口：添加用户自定义配置

        返回:
        - 成功: 返回响应数据字典
        - 失败: 返回None
        """
        method_name = "add_custom_config"
        logger.info(f"[{method_name}] 开始添加用户自定义配置 - user_id: {user_id}, config_name: {config_name}")

        try:
            self.ensure_machine_token()
            body = {
                "user_id": user_id,
                "config_name": config_name,
                "config_value": config_value,
            }
            uri = "/api/v2/service/add_custom_config"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    logger.info(f"[{method_name}] 添加用户自定义配置成功")
                    return result.get("data")
                else:
                    logger.warning(f"[{method_name}] 添加失败 - 响应: {result}")
            else:
                logger.warning(f"[{method_name}] 添加用户自定义配置失败 - 状态码: {response.status_code}")

            return None
        except Exception as e:
            logger.error(f"[{method_name}] 添加用户自定义配置请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return None

    def get_custom_configs(self, user_id) -> Optional[dict]:
        """
        机机接口：获取用户自定义配置

        返回:
        - 成功: 返回配置数据字典
        - 失败: 返回None
        """
        method_name = "get_custom_configs"
        logger.info(f"[{method_name}] 开始获取用户自定义配置 - user_id: {user_id}")

        try:
            self.ensure_machine_token()
            body = {"user_id": user_id}
            uri = "/api/v2/service/get_custom_configs"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    logger.info(f"[{method_name}] 获取用户自定义配置成功")
                    return result.get("data")
                else:
                    logger.warning(f"[{method_name}] 获取失败 - 响应: {result}")
            else:
                logger.warning(f"[{method_name}] 获取用户自定义配置失败 - 状态码: {response.status_code}")

            return None
        except Exception as e:
            logger.error(f"[{method_name}] 获取用户自定义配置请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return None

    def delete_custom_config(self, user_id, config_name) -> Optional[dict]:
        """
        机机接口：删除用户自定义配置

        返回:
        - 成功: 返回响应数据字典
        - 失败: 返回None
        """
        method_name = "delete_custom_config"
        logger.info(f"[{method_name}] 开始删除用户自定义配置 - user_id: {user_id}, config_name: {config_name}")

        try:
            self.ensure_machine_token()
            body = {
                "user_id": user_id,
                "config_name": config_name,
            }
            uri = "/api/v2/service/delete_custom_config"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    logger.info(f"[{method_name}] 删除用户自定义配置成功")
                    return result.get("data")
                else:
                    logger.warning(f"[{method_name}] 删除失败 - 响应: {result}")
            else:
                logger.warning(f"[{method_name}] 删除用户自定义配置失败 - 状态码: {response.status_code}")

            return None
        except Exception as e:
            logger.error(f"[{method_name}] 删除用户自定义配置请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return None

    def get_space_users(
        self, search=None, user_status=None, cred_type=None, user_id=None,
        page=1, per_page=20, sort_by="create_time", sort_order="desc",
    ) -> Optional[dict]:
        """
        机机接口：获取空间用户列表

        返回:
        - 成功: 返回包含分页数据的字典
        - 失败: 返回None
        """
        method_name = "get_space_users"
        logger.info(
            f"[{method_name}] 开始获取空间用户列表 - search: {search}, page: {page}, per_page: {per_page}"
        )

        try:
            self.ensure_machine_token()

            if cred_type is not None and isinstance(cred_type, str):
                cred_type = CredentialTypeEnum(cred_type)

            body: Dict[str, Any] = {
                "page": page,
                "per_page": min(per_page, 100),
                "sort_by": sort_by,
                "sort_order": sort_order,
            }
            if search is not None:
                body["search"] = search
            if user_status is not None:
                body["status"] = user_status if isinstance(user_status, str) else user_status.value
            if cred_type is not None:
                body["cred_type"] = cred_type.value if hasattr(cred_type, 'value') else cred_type
            if user_id is not None:
                body["user_id"] = user_id

            uri = "/api/v2/service/space_users/list"
            url = self.skyplatform_iam_host + uri

            self._log_request(method_name, url, self._build_headers(), body)
            response = self._request_with_retry("POST", url, headers=self._build_headers(), json=body)
            self._log_response(method_name, response)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    logger.info(f"[{method_name}] 获取空间用户列表成功")
                    return result.get("data")
                else:
                    logger.warning(f"[{method_name}] 获取失败 - 响应: {result}")
            else:
                logger.warning(f"[{method_name}] 获取空间用户列表失败 - 状态码: {response.status_code}")

            return None
        except Exception as e:
            logger.error(f"[{method_name}] 获取空间用户列表请求异常: {str(e)}")
            logger.debug(f"[{method_name}] 异常堆栈: {traceback.format_exc()}")
            return None
