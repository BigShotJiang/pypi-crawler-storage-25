"""
SkyPlatform IAM SDK 配置模块
"""
import logging
import fnmatch
import threading
import time
import base64
from typing import List, Optional, Dict, Any

import jwt
import requests
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
from cryptography.hazmat.backends import default_backend
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class JWKSManager:
    """
    JWKS 公钥管理器
    负责从 IAM 的 /jwks.json 端点拉取、缓存、自动刷新 RSA 公钥，
    供 SDK 本地做 JWT 签名验证。
    """

    def __init__(self, jwks_url: str, refresh_interval: int = 3600, ssl_verify: bool = True):
        self._jwks_url = jwks_url
        self._refresh_interval = refresh_interval
        self._ssl_verify = ssl_verify
        self._keys: Dict[str, Any] = {}
        self._raw_jwks: Dict[str, Any] = {"keys": []}
        self._last_refresh: float = 0
        self._lock = threading.Lock()

    @property
    def jwks_url(self) -> str:
        return self._jwks_url

    def refresh(self) -> bool:
        """从 IAM 拉取最新 JWKS 并构建公钥缓存，返回是否成功。"""
        try:
            resp = requests.get(self._jwks_url, timeout=10, verify=self._ssl_verify)
            resp.raise_for_status()
            jwks_data = resp.json()
        except Exception as exc:
            logger.warning(f"[JWKSManager] 拉取 JWKS 失败: {exc}")
            return False

        keys_map: Dict[str, Any] = {}
        for jwk in jwks_data.get("keys", []):
            if jwk.get("kty") != "RSA":
                continue
            kid = jwk.get("kid", "default")
            try:
                pub_key = self._jwk_to_public_key(jwk)
                keys_map[kid] = pub_key
            except Exception as exc:
                logger.warning(f"[JWKSManager] 解析 kid={kid} 的 JWK 失败: {exc}")

        if keys_map:
            with self._lock:
                self._keys = keys_map
                self._raw_jwks = jwks_data
                self._last_refresh = time.time()
            logger.info(f"[JWKSManager] 成功加载 {len(keys_map)} 个公钥")
            return True

        logger.warning("[JWKSManager] JWKS 中未找到可用的 RSA 公钥")
        return False

    def get_public_key(self, kid: Optional[str] = None) -> Optional[Any]:
        """
        按 kid 获取公钥。如果缓存过期或为空，自动触发刷新。
        kid 为 None 时返回第一个可用公钥。
        """
        if self._should_refresh():
            self.refresh()

        with self._lock:
            if kid and kid in self._keys:
                return self._keys[kid]
            if self._keys:
                return next(iter(self._keys.values()))
        return None

    def get_public_key_or_refresh(self, kid: Optional[str] = None) -> Optional[Any]:
        """
        强制刷新后获取公钥，用于 kid 不匹配 / 验签失败时的重试场景。
        """
        self.refresh()
        return self.get_public_key(kid)

    def _should_refresh(self) -> bool:
        return (not self._keys) or (time.time() - self._last_refresh > self._refresh_interval)

    @staticmethod
    def _b64url_decode(data: str) -> bytes:
        padding = 4 - len(data) % 4
        if padding != 4:
            data += "=" * padding
        return base64.urlsafe_b64decode(data)

    @classmethod
    def _jwk_to_public_key(cls, jwk: Dict[str, str]) -> Any:
        n_bytes = cls._b64url_decode(jwk["n"])
        e_bytes = cls._b64url_decode(jwk["e"])
        n_int = int.from_bytes(n_bytes, "big")
        e_int = int.from_bytes(e_bytes, "big")
        return RSAPublicNumbers(e_int, n_int).public_key(default_backend())


class AuthConfig(BaseModel):
    """
    认证配置类
    仅支持代码显式传入配置
    """
    # IAM服务配置
    skyplatform_iam_host: str
    server_name: str
    access_key: str
    machine_token: Optional[str] = ""

    ssl_verify: bool = True
    token_header: str = "Authorization"
    token_prefix: str = "Bearer "

    # 错误处理配置
    enable_debug: bool = False
    
    # SDK日志控制配置
    enable_sdk_logging: bool = True

    # 白名单路径配置（实例变量）
    whitelist_paths: List[str] = Field(default_factory=list)

    def validate_config(self) -> bool:
        """
        验证配置是否完整
        """
        required_fields = ['skyplatform_iam_host', 'server_name', 'access_key']
        for field in required_fields:
            if not getattr(self, field):
                raise ValueError(f"配置项 {field} 不能为空")
        return True

    def _normalize_path(self, path: str) -> str:
        """
        标准化路径格式
        """
        if not path:
            return path

        # 确保路径以 / 开头
        if not path.startswith('/'):
            path = '/' + path

        # 移除重复的斜杠
        while '//' in path:
            path = path.replace('//', '/')

        return path

    def add_whitelist_path(self, path: str) -> None:
        """
        添加白名单路径
        """
        if not path:
            return

        normalized_path = self._normalize_path(path)
        if normalized_path not in self.whitelist_paths:
            self.whitelist_paths.append(normalized_path)

    def add_whitelist_paths(self, paths: List[str]) -> None:
        """
        批量添加白名单路径
        """
        for path in paths:
            self.add_whitelist_path(path)

    def remove_whitelist_path(self, path: str) -> None:
        """
        移除白名单路径
        """
        if not path:
            return

        normalized_path = self._normalize_path(path)
        if normalized_path in self.whitelist_paths:
            self.whitelist_paths.remove(normalized_path)

    def clear_whitelist_paths(self) -> None:
        """
        清空所有白名单路径
        """
        self.whitelist_paths.clear()

    def get_whitelist_paths(self) -> List[str]:
        """
        获取所有白名单路径
        """
        return self.whitelist_paths.copy()

    def is_path_whitelisted(self, path: str) -> bool:
        """
        检查路径是否在白名单中（支持通配符匹配）
        """
        if not path:
            return False

        normalized_path = self._normalize_path(path)

        builtin_suffix = (
            "/openapi.json",
            "/docs",
            "/redoc",
            "/.well-known/appspecific/com.chrome.devtools.json",
        )
        for suffix in builtin_suffix:
            if normalized_path.endswith(suffix):
                return True

        for whitelist_path in self.whitelist_paths:
            # 支持通配符匹配
            if fnmatch.fnmatch(normalized_path, whitelist_path):
                return True

        return False


_global_jwks_manager: Optional[JWKSManager] = None


def set_global_jwks_manager(manager: JWKSManager) -> None:
    global _global_jwks_manager
    _global_jwks_manager = manager


def get_global_jwks_manager() -> Optional[JWKSManager]:
    return _global_jwks_manager


def decode_jwt_token(token: str, jwks_manager: Optional[JWKSManager] = None) -> Optional[Dict]:
    """
    解析 JWT token 获取 payload。
    优先使用 JWKS 公钥做签名验证；若公钥不可用则降级为仅解析（不验签）。
    """
    mgr = jwks_manager or _global_jwks_manager
    try:
        if mgr:
            kid = _extract_kid(token)
            pub_key = mgr.get_public_key(kid)
            if pub_key:
                try:
                    payload = jwt.decode(token, pub_key, algorithms=["RS256"], leeway=30)
                    logger.debug(f"JWT token 签名验证+解析成功")
                    return payload
                except jwt.ExpiredSignatureError:
                    logger.warning("JWT token 已过期")
                    return None
                except (jwt.InvalidSignatureError, jwt.DecodeError):
                    pub_key = mgr.get_public_key_or_refresh(kid)
                    if pub_key:
                        try:
                            payload = jwt.decode(token, pub_key, algorithms=["RS256"], leeway=30)
                            logger.debug("JWT token 刷新公钥后验证成功")
                            return payload
                        except Exception as retry_exc:
                            logger.error(f"JWT token 刷新公钥后仍验证失败: {retry_exc}")
                            return None
                    logger.warning("刷新 JWKS 后仍无可用公钥，降级为不验签解析")

        payload = jwt.decode(token, options={"verify_signature": False}, leeway=30)
        logger.debug("JWT token 解析成功（未验签）")
        return payload
    except jwt.InvalidTokenError as e:
        logger.error(f"JWT token 解析失败: {e}")
        return None
    except Exception as e:
        logger.error(f"JWT token 解析异常: {e}")
        return None


def _extract_kid(token: str) -> Optional[str]:
    """从 JWT header 中提取 kid。"""
    try:
        header = jwt.get_unverified_header(token)
        return header.get("kid")
    except Exception:
        return None
