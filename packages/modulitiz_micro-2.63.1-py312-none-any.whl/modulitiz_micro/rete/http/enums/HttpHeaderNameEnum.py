from enum import StrEnum
from enum import unique


@unique
class HttpHeaderNameEnum(StrEnum):
	"""
	Header names
	"""
	AUTHORIZATION="Authorization"
	COOKIE="Cookie"
	RANGE="Range"
	SET_COOKIE="Set-Cookie"
	USER_AGENT="User-Agent"
