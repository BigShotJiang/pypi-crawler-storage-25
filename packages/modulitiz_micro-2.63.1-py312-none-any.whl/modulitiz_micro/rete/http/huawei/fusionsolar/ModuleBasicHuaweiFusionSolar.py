from modulitiz_micro.rete.http.huawei.fusionsolar.ModuleHuaweiFusionSolar import ModuleHuaweiFusionSolar
from modulitiz_micro.rete.http.huawei.fusionsolar.beans.device.DeviceDataBattery import DeviceDataBattery
from modulitiz_micro.rete.http.huawei.fusionsolar.enums.BatteryStatusEnum import BatteryStatusEnum


class ModuleBasicHuaweiFusionSolar(ModuleHuaweiFusionSolar):
	
	def __init__(self,*args,**kwargs):
		super().__init__(*args,**kwargs)
	
	@staticmethod
	def hasBattery(info:DeviceDataBattery)->bool:
		return info.run_state and info.battery_status!=BatteryStatusEnum.FAULTY
