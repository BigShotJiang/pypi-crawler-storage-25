from enum import IntEnum
from enum import unique


@unique
class BatteryStatusEnum(IntEnum):
	OFFLINE=0
	STANDBY=1
	RUNNING=2
	FAULTY=3
	HIBERNATING=4
