from modulitiz_micro.rete.http.huawei.fusionsolar.enums.DevTypeIdEnum import DevTypeIdEnum
from modulitiz_nano.EnumUtil import EnumUtil


class DeviceBean(object):
	def __init__(self,diz:dict):
		self.idDevice=diz["id"]
		self.idType=EnumUtil.checkValueIn(diz["devTypeId"],DevTypeIdEnum)
