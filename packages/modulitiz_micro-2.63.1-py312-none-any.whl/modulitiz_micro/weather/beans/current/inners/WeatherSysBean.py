class WeatherSysBean(object):
	def __init__(self,data:dict):
		self.country: str=data["country"]
		self.sunrise: int=data["sunrise"]
		self.sunset: int=data["sunset"]
