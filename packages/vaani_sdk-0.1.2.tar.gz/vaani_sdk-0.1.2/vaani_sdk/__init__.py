"""
vaani-sdk — Python SDK for the Vaani External API.

Quick start::

    from vaani_sdk import VaaniClient

    with VaaniClient(api_key="vaani_xxxxxxxx") as client:
        health = client.health()
        history = client.get_call_history()
        result = client.trigger_call(
            agent_id="my-agent",
            contact_number="+1234567890",
            name="Alice",
        )

For async usage::

    from vaani_sdk import AsyncVaaniClient

    async with AsyncVaaniClient(api_key="vaani_xxxxxxxx") as client:
        health = await client.health()
"""

from .client import AsyncVaaniClient, VaaniClient
from .exceptions import (
    AuthenticationError,
    ConnectionError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    VaaniError,
)
from .models import (
    AgentConfigResponse,
    AnalysisUpdate,
    AudioStream,
    CallDetailsResponse,
    CallHistoryResponse,
    CallRecord,
    CreateAgentRequest,
    CreateAgentResponse,
    DeploymentUpdate,
    ExperienceUpdate,
    HealthResponse,
    PaginationInfo,
    PersonaUpdate,
    TrainingUpdate,
    TranscriptResponse,
    TriggerCallRequest,
    TriggerCallResponse,
    WebRTCTokenRequest,
    WebRTCTokenResponse,
)

__version__ = "0.1.0"
__all__ = [
    # Clients
    "VaaniClient",
    "AsyncVaaniClient",
    # Request models
    "TriggerCallRequest",
    "CreateAgentRequest",
    "WebRTCTokenRequest",
    "PersonaUpdate",
    "TrainingUpdate",
    "ExperienceUpdate",
    "AnalysisUpdate",
    "DeploymentUpdate",
    # Response models
    "AudioStream",
    "CallDetailsResponse",
    "CallHistoryResponse",
    "CallRecord",
    "HealthResponse",
    "PaginationInfo",
    "TranscriptResponse",
    "TriggerCallResponse",
    "CreateAgentResponse",
    "WebRTCTokenResponse",
    "AgentConfigResponse",
    # Exceptions
    "VaaniError",
    "AuthenticationError",
    "ConnectionError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimeoutError",
]
