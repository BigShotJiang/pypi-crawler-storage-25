"""
Exceptions for the Vaani SDK.
"""

from typing import Optional


class VaaniError(Exception):
    """Base exception for all Vaani SDK errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class AuthenticationError(VaaniError):
    """Raised when the API key is missing, invalid, or rejected (HTTP 401/403)."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, status_code=401)


class NotFoundError(VaaniError):
    """Raised when the requested resource does not exist (HTTP 404)."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, status_code=404)


class RateLimitError(VaaniError):
    """Raised when the API rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message, status_code=429)


class ServerError(VaaniError):
    """Raised when the server returns a 5xx error."""

    def __init__(self, message: str = "Internal server error", status_code: int = 500):
        super().__init__(message, status_code=status_code)


class TimeoutError(VaaniError):
    """Raised when a request to the API times out."""

    def __init__(self, message: str = "Request timed out"):
        super().__init__(message)


class ConnectionError(VaaniError):
    """Raised when the SDK cannot connect to the Vaani API."""

    def __init__(self, message: str = "Could not connect to Vaani API"):
        super().__init__(message)
