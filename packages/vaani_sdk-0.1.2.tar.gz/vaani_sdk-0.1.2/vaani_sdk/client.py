"""
Vaani API clients — synchronous (VaaniClient) and asynchronous (AsyncVaaniClient).
"""

from __future__ import annotations

from typing import Any, AsyncIterator, Dict, Iterator, Optional, Union

import httpx

from .exceptions import (
    AuthenticationError,
    ConnectionError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    VaaniError,
)
from .models import (
    AgentConfigResponse,
    AudioStream,
    CallDetailsResponse,
    CallHistoryResponse,
    CreateAgentRequest,
    CreateAgentResponse,
    HealthResponse,
    TranscriptResponse,
    TriggerCallRequest,
    TriggerCallResponse,
    WebRTCTokenRequest,
    WebRTCTokenResponse,
)

DEFAULT_BASE_URL = "https://api.vaanivoice.ai"
DEFAULT_TIMEOUT = 120.0


def _raise_for_status(response: httpx.Response) -> None:
    """Translate httpx HTTP error responses into typed SDK exceptions."""
    code = response.status_code
    if code < 400:
        return

    try:
        detail = response.json().get("detail", response.text)
    except Exception:
        detail = response.text

    if code in (401, 403):
        raise AuthenticationError(str(detail))
    if code == 404:
        raise NotFoundError(str(detail))
    if code == 429:
        raise RateLimitError(str(detail))
    if code >= 500:
        raise ServerError(str(detail), status_code=code)
    raise VaaniError(str(detail), status_code=code)


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------


class VaaniClient:
    """
    Synchronous client for the Vaani External API.

    Usage::

        from vaani_sdk import VaaniClient

        client = VaaniClient(api_key="vaani_xxxxxxxx")

        health = client.health()
        print(health.status)          # "healthy"

        result = client.trigger_call(
            agent_id="my-agent",
            contact_number="+1234567890",
            name="Alice",
        )
        print(result.call_id)

    The client should be used as a context manager when possible so the
    underlying ``httpx.Client`` is properly closed::

        with VaaniClient(api_key="vaani_xxxxxxxx") as client:
            history = client.get_call_history()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        """
        Args:
            api_key:     Your Vaani API key (``X-API-Key`` header value).
            base_url:    Base URL of the Vaani External API.
            timeout:     Request timeout in seconds (default 120 s).
            http_client: Optional pre-configured ``httpx.Client`` instance.
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._owns_client = http_client is None
        self._client: httpx.Client = http_client or httpx.Client(timeout=timeout)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "VaaniClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._owns_client:
            self._client.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _headers(self) -> Dict[str, str]:
        return {"X-API-Key": self._api_key}

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        url = f"{self._base_url}{path}"
        try:
            response = self._client.get(url, headers=self._headers, params=params)
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Request to {path} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc
        _raise_for_status(response)
        return response

    def _post(self, path: str, json: Dict[str, Any]) -> Any:
        url = f"{self._base_url}{path}"
        try:
            response = self._client.post(url, headers=self._headers, json=json)
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Request to {path} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc
        _raise_for_status(response)
        return response

    def _patch(self, path: str, json: Dict[str, Any]) -> Any:
        url = f"{self._base_url}{path}"
        try:
            response = self._client.patch(url, headers=self._headers, json=json)
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Request to {path} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc
        _raise_for_status(response)
        return response

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    def health(self) -> HealthResponse:
        """
        Check the health of the Vaani External API.

        Returns:
            :class:`~vaani_sdk.models.HealthResponse`

        Example::

            resp = client.health()
            assert resp.status == "healthy"
        """
        response = self._get("/api/health")
        return HealthResponse.from_dict(response.json())

    def trigger_call(
        self,
        agent_id: str,
        contact_number: str,
        name: str,
        voice: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        outbound_number: Optional[str] = None,
        sip_trunk_id: Optional[str] = None,
        test_mode: Optional[bool] = None,
    ) -> TriggerCallResponse:
        """
        Trigger an outbound call.

        Args:
            agent_id:        Agent UUID or agent name.
            contact_number:  Destination number in E.164 format (e.g. '+1234567890').
            name:            Display name of the contact.
            voice:           Voice identifier (optional).
            metadata:        Arbitrary key-value pairs forwarded to the agent.
            outbound_number: Caller ID in E.164 format (optional).
            sip_trunk_id:    SIP trunk identifier (optional).
            test_mode:       Trigger a test-mode call (optional).

        Returns:
            :class:`~vaani_sdk.models.TriggerCallResponse`

        Example::

            result = client.trigger_call(
                agent_id="support-bot",
                contact_number="+1234567890",
                name="Bob",
                metadata={"ticket_id": "T-42"},
            )
            print(result.call_id)
        """
        req = TriggerCallRequest(
            agent_id=agent_id,
            contact_number=contact_number,
            name=name,
            voice=voice,
            metadata=metadata or {},
            outbound_number=outbound_number,
            sip_trunk_id=sip_trunk_id,
            test_mode=test_mode,
        )
        response = self._post("/api/trigger-call/", json=req.to_dict())
        return TriggerCallResponse.from_dict(response.json())

    def get_call_history(
        self,
        page: int = 1,
        page_size: int = 50,
    ) -> CallHistoryResponse:
        """
        Retrieve paginated call history for the authenticated user.

        Args:
            page:      Page number (1-indexed, default 1).
            page_size: Number of records per page (1–200, default 50).

        Returns:
            :class:`~vaani_sdk.models.CallHistoryResponse`

        Example::

            history = client.get_call_history(page=1, page_size=10)
            for call in history.data:
                print(call.call_id)
        """
        response = self._get("/api/call-history", params={"page": page, "page_size": page_size})
        return CallHistoryResponse.from_dict(response.json())

    def get_transcript(self, call_id: str) -> TranscriptResponse:
        """
        Retrieve the transcript for a specific call.

        Args:
            call_id: The unique call identifier.

        Returns:
            :class:`~vaani_sdk.models.TranscriptResponse`

        Example::

            transcript = client.get_transcript("abc-123")
            print(transcript.transcript)
        """
        response = self._get(f"/api/transcript/{call_id}")
        return TranscriptResponse.from_dict(response.json())

    def get_call_details(self, call_id: str) -> CallDetailsResponse:
        """
        Retrieve detailed information about a specific call.

        Args:
            call_id: The unique call identifier.

        Returns:
            :class:`~vaani_sdk.models.CallDetailsResponse`

        Example::

            details = client.get_call_details("abc-123")
            print(details.raw)
        """
        response = self._get(f"/api/call_details/{call_id}")
        return CallDetailsResponse.from_dict(response.json())

    def stream_audio(self, call_id: str) -> AudioStream:
        """
        Download the audio recording for a specific call.

        The entire audio content is buffered in memory. For very large files
        use the ``stream_audio_iter`` method instead.

        Args:
            call_id: The unique call identifier.

        Returns:
            :class:`~vaani_sdk.models.AudioStream` with ``content`` populated.

        Example::

            audio = client.stream_audio("abc-123")
            with open("call.wav", "wb") as f:
                f.write(audio.content)
        """
        response = self._get(f"/api/stream/{call_id}")
        return AudioStream(
            content_type=response.headers.get("content-type", "application/octet-stream"),
            content=response.content,
        )

    def stream_audio_iter(self, call_id: str) -> Iterator[bytes]:
        """
        Stream the audio recording for a specific call as an iterator of bytes chunks.

        Args:
            call_id: The unique call identifier.

        Yields:
            Raw bytes chunks of the audio recording.

        Example::

            with open("call.wav", "wb") as f:
                for chunk in client.stream_audio_iter("abc-123"):
                    f.write(chunk)
        """
        url = f"{self._base_url}/api/stream/{call_id}"
        try:
            with self._client.stream("GET", url, headers=self._headers) as response:
                _raise_for_status(response)
                yield from response.iter_bytes()
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Streaming audio for {call_id} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc

    def create_agent(
        self,
        agent_display_name: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> CreateAgentResponse:
        """
        Create a new agent associated with your client.

        Args:
            agent_display_name: Display name for the new agent.
            config:             Optional initial agent configuration payload.

        Returns:
            :class:`~vaani_sdk.models.CreateAgentResponse`

        Example::

            result = client.create_agent(
                agent_display_name="my-support-bot",
                config={
                    "persona": {
                        "identity": {
                            "system_prompt": "You are a helpful support agent."
                        }
                    }
                },
            )
            print(result.agent_id)
        """
        req = CreateAgentRequest(
            agent_display_name=agent_display_name,
            config=config or {},
        )
        response = self._post("/api/create-agent", json=req.to_dict())
        return CreateAgentResponse.from_dict(response.json())

    def webrtc_token(
        self,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        voice_gender: str = "female",
        primary_language: str = "hi",
        secondary_language: str = "en",
        welcome_message: Optional[str] = None,
        welcome_interruptible: bool = True,
        bg_noise_enabled: bool = False,
        bg_noise_volume: int = 60,
        voice_speed: float = 1.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> WebRTCTokenResponse:
        """
        Generate a WebRTC token for voice chat with an agent.

        Args:
            agent_id:              Agent UUID (optional).
            agent_name:            Agent name (optional).
            voice_gender:          Voice gender ('male' or 'female').
            primary_language:      Primary language code.
            secondary_language:    Secondary language code.
            welcome_message:       Welcome message text (optional).
            welcome_interruptible: Whether welcome message is interruptible.
            bg_noise_enabled:      Whether background noise is enabled.
            bg_noise_volume:       Background noise volume (0-100).
            voice_speed:           Voice speed multiplier (0.6-1.4).
            metadata:              Arbitrary key-value pairs (optional).

        Returns:
            :class:`~vaani_sdk.models.WebRTCTokenResponse`

        Example::

            result = client.webrtc_token(
                agent_id="my-agent-uuid",
                voice_gender="female",
                primary_language="en",
            )
            print(result.token)
        """
        req = WebRTCTokenRequest(
            agent_id=agent_id,
            agent_name=agent_name,
            voice_gender=voice_gender,
            primary_language=primary_language,
            secondary_language=secondary_language,
            welcome_message=welcome_message,
            welcome_interruptible=welcome_interruptible,
            bg_noise_enabled=bg_noise_enabled,
            bg_noise_volume=bg_noise_volume,
            voice_speed=voice_speed,
            metadata=metadata,
        )
        response = self._post("/api/webrtc/token", json=req.to_dict())
        return WebRTCTokenResponse.from_dict(response.json())

    def update_agent_persona(
        self,
        agent_id: str,
        persona: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the persona section of an agent's configuration.

        Args:
            agent_id: The agent UUID.
            persona:  Persona configuration dict (identity, senses_capabilities, actions, memories).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`

        Example::

            result = client.update_agent_persona(
                agent_id="my-agent-uuid",
                persona={
                    "identity": {
                        "system_prompt": "You are a helpful customer service agent.",
                        "greeting_message": {
                            "agent_message": "Hi! How can I help you today?",
                            "interruptible": True,
                        }
                    }
                },
            )
            print(result.agent_display_name)
        """
        response = self._patch(f"/api/config/agent-specific-config/{agent_id}/persona", json=persona)
        return AgentConfigResponse.from_dict(response.json())

    def update_agent_training(
        self,
        agent_id: str,
        training: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the training section of an agent's configuration.

        Args:
            agent_id: The agent UUID.
            training: Training configuration dict (knowledge, know_how).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`

        Example::

            result = client.update_agent_training(
                agent_id="my-agent-uuid",
                training={
                    "know_how": {
                        "faq": {
                            "What are your hours?": "We are open 9 AM to 5 PM.",
                        }
                    }
                },
            )
        """
        response = self._patch(f"/api/config/agent-specific-config/{agent_id}/training", json=training)
        return AgentConfigResponse.from_dict(response.json())

    def update_agent_experience(
        self,
        agent_id: str,
        experience: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the experience section of an agent's configuration.

        Args:
            agent_id:   The agent UUID.
            experience: Experience configuration dict (conversational_experience, settings).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`

        Example::

            result = client.update_agent_experience(
                agent_id="my-agent-uuid",
                experience={
                    "settings": {
                        "call_settings": {
                            "max_call_duration": 30,
                        }
                    }
                },
            )
        """
        response = self._patch(f"/api/config/agent-specific-config/{agent_id}/experience", json=experience)
        return AgentConfigResponse.from_dict(response.json())

    def update_agent_analysis(
        self,
        agent_id: str,
        analysis: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the analysis section of an agent's configuration.

        Args:
            agent_id: The agent UUID.
            analysis: Analysis configuration dict (evaluations, extraction).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`

        Example::

            result = client.update_agent_analysis(
                agent_id="my-agent-uuid",
                analysis={
                    "evaluations": {
                        "dispositions": {
                            "enabled": True,
                        }
                    }
                },
            )
        """
        response = self._patch(f"/api/config/agent-specific-config/{agent_id}/analysis", json=analysis)
        return AgentConfigResponse.from_dict(response.json())

    def update_agent_deployment(
        self,
        agent_id: str,
        deployment: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the deployment section of an agent's configuration.

        Args:
            agent_id:   The agent UUID.
            deployment: Deployment configuration dict (phone call types).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`

        Example::

            result = client.update_agent_deployment(
                agent_id="my-agent-uuid",
                deployment={
                    "deployment": {
                        "phone": {
                            "call_type": {
                                "Outbound": ["+919876543210"]
                            }
                        }
                    }
                },
            )
        """
        response = self._patch(f"/api/config/agent-specific-config/{agent_id}/deployment", json=deployment)
        return AgentConfigResponse.from_dict(response.json())


# ---------------------------------------------------------------------------
# Asynchronous client
# ---------------------------------------------------------------------------


class AsyncVaaniClient:
    """
    Asynchronous client for the Vaani External API.

    Usage::

        import asyncio
        from vaani_sdk import AsyncVaaniClient

        async def main():
            async with AsyncVaaniClient(api_key="vaani_xxxxxxxx") as client:
                health = await client.health()
                print(health.status)

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        """
        Args:
            api_key:     Your Vaani API key (``X-API-Key`` header value).
            base_url:    Base URL of the Vaani External API.
            timeout:     Request timeout in seconds (default 120 s).
            http_client: Optional pre-configured ``httpx.AsyncClient`` instance.
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._owns_client = http_client is None
        self._client: httpx.AsyncClient = http_client or httpx.AsyncClient(timeout=timeout)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "AsyncVaaniClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying async HTTP client."""
        if self._owns_client:
            await self._client.aclose()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _headers(self) -> Dict[str, str]:
        return {"X-API-Key": self._api_key}

    async def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> httpx.Response:
        url = f"{self._base_url}{path}"
        try:
            response = await self._client.get(url, headers=self._headers, params=params)
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Request to {path} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc
        _raise_for_status(response)
        return response

    async def _post(self, path: str, json: Dict[str, Any]) -> httpx.Response:
        url = f"{self._base_url}{path}"
        try:
            response = await self._client.post(url, headers=self._headers, json=json)
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Request to {path} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc
        _raise_for_status(response)
        return response

    async def _patch(self, path: str, json: Dict[str, Any]) -> httpx.Response:
        url = f"{self._base_url}{path}"
        try:
            response = await self._client.patch(url, headers=self._headers, json=json)
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Request to {path} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc
        _raise_for_status(response)
        return response

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    async def health(self) -> HealthResponse:
        """
        Check the health of the Vaani External API.

        Returns:
            :class:`~vaani_sdk.models.HealthResponse`
        """
        response = await self._get("/api/health")
        return HealthResponse.from_dict(response.json())

    async def trigger_call(
        self,
        agent_id: str,
        contact_number: str,
        name: str,
        voice: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        outbound_number: Optional[str] = None,
        sip_trunk_id: Optional[str] = None,
        test_mode: Optional[bool] = None,
    ) -> TriggerCallResponse:
        """
        Trigger an outbound call.

        Args:
            agent_id:        Agent UUID or agent name.
            contact_number:  Destination number in E.164 format.
            name:            Display name of the contact.
            voice:           Voice identifier (optional).
            metadata:        Arbitrary key-value pairs forwarded to the agent.
            outbound_number: Caller ID in E.164 format (optional).
            sip_trunk_id:    SIP trunk identifier (optional).
            test_mode:       Trigger a test-mode call (optional).

        Returns:
            :class:`~vaani_sdk.models.TriggerCallResponse`
        """
        req = TriggerCallRequest(
            agent_id=agent_id,
            contact_number=contact_number,
            name=name,
            voice=voice,
            metadata=metadata or {},
            outbound_number=outbound_number,
            sip_trunk_id=sip_trunk_id,
            test_mode=test_mode,
        )
        response = await self._post("/api/trigger-call/", json=req.to_dict())
        return TriggerCallResponse.from_dict(response.json())

    async def get_call_history(
        self,
        page: int = 1,
        page_size: int = 50,
    ) -> CallHistoryResponse:
        """
        Retrieve paginated call history for the authenticated user.

        Args:
            page:      Page number (1-indexed, default 1).
            page_size: Number of records per page (1–200, default 50).

        Returns:
            :class:`~vaani_sdk.models.CallHistoryResponse`
        """
        response = await self._get(
            "/api/call-history", params={"page": page, "page_size": page_size}
        )
        return CallHistoryResponse.from_dict(response.json())

    async def get_transcript(self, call_id: str) -> TranscriptResponse:
        """
        Retrieve the transcript for a specific call.

        Args:
            call_id: The unique call identifier.

        Returns:
            :class:`~vaani_sdk.models.TranscriptResponse`
        """
        response = await self._get(f"/api/transcript/{call_id}")
        return TranscriptResponse.from_dict(response.json())

    async def get_call_details(self, call_id: str) -> CallDetailsResponse:
        """
        Retrieve detailed information about a specific call.

        Args:
            call_id: The unique call identifier.

        Returns:
            :class:`~vaani_sdk.models.CallDetailsResponse`
        """
        response = await self._get(f"/api/call_details/{call_id}")
        return CallDetailsResponse.from_dict(response.json())

    async def stream_audio(self, call_id: str) -> AudioStream:
        """
        Download the audio recording for a specific call.

        The entire audio content is buffered in memory. For very large files
        use the ``stream_audio_iter`` async generator instead.

        Args:
            call_id: The unique call identifier.

        Returns:
            :class:`~vaani_sdk.models.AudioStream` with ``content`` populated.
        """
        response = await self._get(f"/api/stream/{call_id}")
        return AudioStream(
            content_type=response.headers.get("content-type", "application/octet-stream"),
            content=response.content,
        )

    async def stream_audio_iter(self, call_id: str) -> AsyncIterator[bytes]:
        """
        Stream the audio recording for a specific call as an async iterator.

        Args:
            call_id: The unique call identifier.

        Yields:
            Raw bytes chunks of the audio recording.

        Example::

            async with open("call.wav", "wb") as f:
                async for chunk in client.stream_audio_iter("abc-123"):
                    f.write(chunk)
        """
        url = f"{self._base_url}/api/stream/{call_id}"
        try:
            async with self._client.stream("GET", url, headers=self._headers) as response:
                _raise_for_status(response)
                async for chunk in response.aiter_bytes():
                    yield chunk
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Streaming audio for {call_id} timed out") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not connect to Vaani API at {self._base_url}") from exc

    async def create_agent(
        self,
        agent_display_name: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> CreateAgentResponse:
        """
        Create a new agent associated with your client.

        Args:
            agent_display_name: Display name for the new agent.
            config:             Optional initial agent configuration payload.

        Returns:
            :class:`~vaani_sdk.models.CreateAgentResponse`
        """
        req = CreateAgentRequest(
            agent_display_name=agent_display_name,
            config=config or {},
        )
        response = await self._post("/api/create-agent", json=req.to_dict())
        return CreateAgentResponse.from_dict(response.json())

    async def webrtc_token(
        self,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        voice_gender: str = "female",
        primary_language: str = "hi",
        secondary_language: str = "en",
        welcome_message: Optional[str] = None,
        welcome_interruptible: bool = True,
        bg_noise_enabled: bool = False,
        bg_noise_volume: int = 60,
        voice_speed: float = 1.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> WebRTCTokenResponse:
        """
        Generate a WebRTC token for voice chat with an agent.

        Args:
            agent_id:              Agent UUID (optional).
            agent_name:            Agent name (optional).
            voice_gender:          Voice gender ('male' or 'female').
            primary_language:      Primary language code.
            secondary_language:    Secondary language code.
            welcome_message:       Welcome message text (optional).
            welcome_interruptible: Whether welcome message is interruptible.
            bg_noise_enabled:      Whether background noise is enabled.
            bg_noise_volume:       Background noise volume (0-100).
            voice_speed:           Voice speed multiplier (0.6-1.4).
            metadata:              Arbitrary key-value pairs (optional).

        Returns:
            :class:`~vaani_sdk.models.WebRTCTokenResponse`
        """
        req = WebRTCTokenRequest(
            agent_id=agent_id,
            agent_name=agent_name,
            voice_gender=voice_gender,
            primary_language=primary_language,
            secondary_language=secondary_language,
            welcome_message=welcome_message,
            welcome_interruptible=welcome_interruptible,
            bg_noise_enabled=bg_noise_enabled,
            bg_noise_volume=bg_noise_volume,
            voice_speed=voice_speed,
            metadata=metadata,
        )
        response = await self._post("/api/webrtc/token", json=req.to_dict())
        return WebRTCTokenResponse.from_dict(response.json())

    async def update_agent_persona(
        self,
        agent_id: str,
        persona: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the persona section of an agent's configuration.

        Args:
            agent_id: The agent UUID.
            persona:  Persona configuration dict (identity, senses_capabilities, actions, memories).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`
        """
        response = await self._patch(f"/api/config/agent-specific-config/{agent_id}/persona", json=persona)
        return AgentConfigResponse.from_dict(response.json())

    async def update_agent_training(
        self,
        agent_id: str,
        training: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the training section of an agent's configuration.

        Args:
            agent_id: The agent UUID.
            training: Training configuration dict (knowledge, know_how).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`
        """
        response = await self._patch(f"/api/config/agent-specific-config/{agent_id}/training", json=training)
        return AgentConfigResponse.from_dict(response.json())

    async def update_agent_experience(
        self,
        agent_id: str,
        experience: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the experience section of an agent's configuration.

        Args:
            agent_id:   The agent UUID.
            experience: Experience configuration dict (conversational_experience, settings).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`
        """
        response = await self._patch(f"/api/config/agent-specific-config/{agent_id}/experience", json=experience)
        return AgentConfigResponse.from_dict(response.json())

    async def update_agent_analysis(
        self,
        agent_id: str,
        analysis: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the analysis section of an agent's configuration.

        Args:
            agent_id: The agent UUID.
            analysis: Analysis configuration dict (evaluations, extraction).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`
        """
        response = await self._patch(f"/api/config/agent-specific-config/{agent_id}/analysis", json=analysis)
        return AgentConfigResponse.from_dict(response.json())

    async def update_agent_deployment(
        self,
        agent_id: str,
        deployment: Dict[str, Any],
    ) -> AgentConfigResponse:
        """
        Partially update the deployment section of an agent's configuration.

        Args:
            agent_id:   The agent UUID.
            deployment: Deployment configuration dict (phone call types).

        Returns:
            :class:`~vaani_sdk.models.AgentConfigResponse`
        """
        response = await self._patch(f"/api/config/agent-specific-config/{agent_id}/deployment", json=deployment)
        return AgentConfigResponse.from_dict(response.json())

