"""
Request and response models for the Vaani SDK.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


@dataclass
class TriggerCallRequest:
    """
    Parameters for triggering an outbound call.

    Attributes:
        agent_id:         Agent UUID or agent name.
        contact_number:   Phone number in E.164 format (e.g. '+1234567890').
        name:             Display name of the contact.
        voice:            Voice identifier (optional, defaults to empty string).
        metadata:         Arbitrary key-value pairs forwarded to the agent.
        outbound_number:  Caller ID in E.164 format (optional).
        sip_trunk_id:     SIP trunk identifier (optional).
        test_mode:        When True, triggers a test-mode call (optional).
    """

    agent_id: str
    contact_number: str
    name: str
    voice: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    outbound_number: Optional[str] = None
    sip_trunk_id: Optional[str] = None
    test_mode: Optional[bool] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "agent_id": self.agent_id,
            "contact_number": self.contact_number,
            "name": self.name,
            "voice": self.voice,
            "metadata": self.metadata,
        }
        if self.outbound_number is not None:
            data["outbound_number"] = self.outbound_number
        if self.sip_trunk_id is not None:
            data["sip_trunk_id"] = self.sip_trunk_id
        if self.test_mode is not None:
            data["test_mode"] = self.test_mode
        return data


@dataclass
class CreateAgentRequest:
    """
    Parameters for creating a new agent.

    Attributes:
        agent_display_name: Display name for the new agent.
        config:             Optional initial agent configuration payload.
    """

    agent_display_name: str
    config: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_display_name": self.agent_display_name,
            "config": self.config,
        }


@dataclass
class WebRTCTokenRequest:
    """
    Parameters for generating a WebRTC token.

    Attributes:
        agent_id:              Agent UUID (optional).
        agent_name:            Agent name (optional).
        voice_gender:          Voice gender ('male' or 'female').
        primary_language:      Primary language code.
        secondary_language:    Secondary language code.
        welcome_message:       Welcome message text (optional).
        welcome_interruptible: Whether welcome message is interruptible.
        bg_noise_enabled:      Whether background noise is enabled.
        bg_noise_volume:       Background noise volume (0-100).
        voice_speed:           Voice speed multiplier (0.6-1.4).
        metadata:              Arbitrary key-value pairs (optional).
    """

    agent_id: Optional[str] = None
    agent_name: Optional[str] = None
    voice_gender: str = "female"
    primary_language: str = "hi"
    secondary_language: str = "en"
    welcome_message: Optional[str] = None
    welcome_interruptible: bool = True
    bg_noise_enabled: bool = False
    bg_noise_volume: int = 60
    voice_speed: float = 1.0
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "voice_gender": self.voice_gender,
            "primary_language": self.primary_language,
            "secondary_language": self.secondary_language,
            "welcome_interruptible": self.welcome_interruptible,
            "bg_noise_enabled": self.bg_noise_enabled,
            "bg_noise_volume": self.bg_noise_volume,
            "voice_speed": self.voice_speed,
        }
        if self.agent_id is not None:
            data["agent_id"] = self.agent_id
        if self.agent_name is not None:
            data["agent_name"] = self.agent_name
        if self.welcome_message is not None:
            data["welcome_message"] = self.welcome_message
        if self.metadata is not None:
            data["metadata"] = self.metadata
        return data


@dataclass
class PersonaUpdate:
    """
    Persona section update payload.

    Attributes:
        identity:             Identity configuration (system_prompt, greeting, personality).
        senses_capabilities:  Senses configuration (STT, LLM, TTS providers).
        actions:              Actions/tools configuration.
        memories:             Memories configuration.
        metadata:             Custom metadata.
    """

    identity: Optional[Dict[str, Any]] = None
    senses_capabilities: Optional[Dict[str, Any]] = None
    actions: Optional[Dict[str, Any]] = None
    memories: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if self.identity is not None:
            data["identity"] = self.identity
        if self.senses_capabilities is not None:
            data["senses_capabilities"] = self.senses_capabilities
        if self.actions is not None:
            data["actions"] = self.actions
        if self.memories is not None:
            data["memories"] = self.memories
        if self.metadata is not None:
            data["metadata"] = self.metadata
        return data


@dataclass
class TrainingUpdate:
    """
    Training section update payload.

    Attributes:
        knowledge: Knowledge base configuration (use_rag, rag_knowledge_base_dict).
        know_how:  FAQ, pain points, and guardrails configuration.
    """

    knowledge: Optional[Dict[str, Any]] = None
    know_how: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if self.knowledge is not None:
            data["knowledge"] = self.knowledge
        if self.know_how is not None:
            data["know_how"] = self.know_how
        return data


@dataclass
class ExperienceUpdate:
    """
    Experience section update payload.

    Attributes:
        conversational_experience: Conversational settings (bg_noise, filler_words, eagerness).
        settings:                  Call settings (idle, end_call, max_duration).
    """

    conversational_experience: Optional[Dict[str, Any]] = None
    settings: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if self.conversational_experience is not None:
            data["conversational_experience"] = self.conversational_experience
        if self.settings is not None:
            data["settings"] = self.settings
        return data


@dataclass
class AnalysisUpdate:
    """
    Analysis section update payload.

    Attributes:
        evaluations: Dispositions and conversation evaluation configuration.
        extraction:  Data collection and concerns extraction configuration.
    """

    evaluations: Optional[Dict[str, Any]] = None
    extraction: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if self.evaluations is not None:
            data["evaluations"] = self.evaluations
        if self.extraction is not None:
            data["extraction"] = self.extraction
        return data


@dataclass
class DeploymentUpdate:
    """
    Deployment section update payload.

    Attributes:
        deployment: Deployment configuration (phone call types, inbound/outbound numbers).
    """

    deployment: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if self.deployment is not None:
            data["deployment"] = self.deployment
        return data


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


@dataclass
class HealthResponse:
    """
    Response from the health-check endpoint.

    Attributes:
        status:  Status string (e.g. 'healthy').
        service: Service identifier.
        raw:     Full raw response dict.
    """

    status: str
    service: str
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HealthResponse":
        return cls(
            status=data.get("status", ""),
            service=data.get("service", ""),
            raw=data,
        )


@dataclass
class TriggerCallResponse:
    """
    Response from the trigger-call endpoint.

    Attributes:
        call_id: The ID of the newly created call (may be None if not returned).
        raw:     Full raw response dict.
    """

    call_id: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TriggerCallResponse":
        call_id = (
            data.get("call_id")
            or data.get("output", {}).get("call_id")
        )
        return cls(call_id=call_id, raw=data)


@dataclass
class CallRecord:
    """A single call record within the call-history response."""

    call_id: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CallRecord":
        return cls(call_id=data.get("call_id"), raw=data)


@dataclass
class PaginationInfo:
    """Pagination metadata returned alongside call-history results."""

    page: int
    page_size: int
    total: int
    total_pages: int
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PaginationInfo":
        return cls(
            page=data.get("page", 1),
            page_size=data.get("page_size", 50),
            total=data.get("total", 0),
            total_pages=data.get("total_pages", 0),
            raw=data,
        )


@dataclass
class CallHistoryResponse:
    """
    Response from the call-history endpoint.

    Attributes:
        data:       List of :class:`CallRecord` objects.
        pagination: :class:`PaginationInfo` with paging metadata.
        raw:        Full raw response dict.
    """

    data: List[CallRecord]
    pagination: Optional[PaginationInfo]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CallHistoryResponse":
        records = [CallRecord.from_dict(r) for r in data.get("data", [])]
        pagination = None
        if "pagination" in data:
            pagination = PaginationInfo.from_dict(data["pagination"])
        return cls(data=records, pagination=pagination, raw=data)


@dataclass
class TranscriptResponse:
    """
    Response from the transcript endpoint.

    Attributes:
        transcript: Transcript text or list of utterances (raw value from API).
        raw:        Full raw response dict.
    """

    transcript: Any
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TranscriptResponse":
        transcript = data.get("transcript", data)
        return cls(transcript=transcript, raw=data)


@dataclass
class CallDetailsResponse:
    """
    Response from the call-details endpoint.

    Attributes:
        call_id: The call ID.
        raw:     Full raw response dict.
    """

    call_id: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CallDetailsResponse":
        return cls(call_id=data.get("call_id"), raw=data)


@dataclass
class CreateAgentResponse:
    """
    Response from the create-agent endpoint.

    Attributes:
        agent_id:   The ID of the newly created agent.
        agent_name: The generated agent name.
        raw:        Full raw response dict.
    """

    agent_id: Optional[str]
    agent_name: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CreateAgentResponse":
        return cls(
            agent_id=data.get("agent_id"),
            agent_name=data.get("agent_name"),
            raw=data,
        )


@dataclass
class WebRTCTokenResponse:
    """
    Response from the webrtc-token endpoint.

    Attributes:
        token:    The WebRTC connection token.
        room_url: The LiveKit room URL (optional).
        raw:      Full raw response dict.
    """

    token: Optional[str]
    room_url: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WebRTCTokenResponse":
        return cls(
            token=data.get("token"),
            room_url=data.get("room_url"),
            raw=data,
        )


@dataclass
class AgentConfigResponse:
    """
    Response from agent configuration update endpoints.

    Attributes:
        agent_id:            The agent ID.
        agent_display_name:  The agent display name.
        raw:                 Full raw response dict with complete agent config.
    """

    agent_id: Optional[str]
    agent_display_name: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentConfigResponse":
        return cls(
            agent_id=data.get("agent_id"),
            agent_display_name=data.get("agent_display_name"),
            raw=data,
        )


@dataclass
class AudioStream:
    """
    Wrapper for a streaming audio response.

    Attributes:
        content_type: MIME type of the audio data.
        content:      Raw audio bytes (available when not using streaming iteration).
        iterator:     Iterator over raw bytes chunks (for streaming usage).
    """

    content_type: str
    content: bytes = field(default_factory=bytes)
    iterator: Optional[Iterator[bytes]] = field(default=None, repr=False)
