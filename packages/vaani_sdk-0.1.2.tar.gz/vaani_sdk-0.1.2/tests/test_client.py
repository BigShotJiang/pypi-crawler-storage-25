"""
Unit tests for VaaniClient and AsyncVaaniClient using respx to mock httpx.
"""

import pytest
import respx
import httpx

from vaani_sdk import (
    AsyncVaaniClient,
    VaaniClient,
    AuthenticationError,
    NotFoundError,
    ServerError,
    TriggerCallRequest,
)
from vaani_sdk.models import (
    AudioStream,
    CallDetailsResponse,
    CallHistoryResponse,
    HealthResponse,
    TranscriptResponse,
    TriggerCallResponse,
)

BASE_URL = "http://test.vaani.local"
API_KEY = "vaani_testkey123"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_client() -> VaaniClient:
    return VaaniClient(api_key=API_KEY, base_url=BASE_URL)


def make_async_client() -> AsyncVaaniClient:
    return AsyncVaaniClient(api_key=API_KEY, base_url=BASE_URL)


# ---------------------------------------------------------------------------
# TriggerCallRequest model
# ---------------------------------------------------------------------------


class TestTriggerCallRequest:
    def test_to_dict_required_fields(self):
        req = TriggerCallRequest(
            agent_id="agent-1",
            contact_number="+1234567890",
            name="Alice",
        )
        data = req.to_dict()
        assert data["agent_id"] == "agent-1"
        assert data["contact_number"] == "+1234567890"
        assert data["name"] == "Alice"
        assert data["voice"] == ""
        assert data["metadata"] == {}
        assert "outbound_number" not in data
        assert "sip_trunk_id" not in data
        assert "test_mode" not in data

    def test_to_dict_optional_fields(self):
        req = TriggerCallRequest(
            agent_id="agent-1",
            contact_number="+1234567890",
            name="Bob",
            outbound_number="+10987654321",
            sip_trunk_id="trunk-1",
            test_mode=True,
            metadata={"k": "v"},
        )
        data = req.to_dict()
        assert data["outbound_number"] == "+10987654321"
        assert data["sip_trunk_id"] == "trunk-1"
        assert data["test_mode"] is True
        assert data["metadata"] == {"k": "v"}


# ---------------------------------------------------------------------------
# Sync client — happy paths
# ---------------------------------------------------------------------------


class TestVaaniClientSync:
    @respx.mock
    def test_health(self):
        respx.get(f"{BASE_URL}/api/health").mock(
            return_value=httpx.Response(200, json={"status": "healthy", "service": "vaani-external-api"})
        )
        with make_client() as client:
            resp = client.health()
        assert isinstance(resp, HealthResponse)
        assert resp.status == "healthy"
        assert resp.service == "vaani-external-api"

    @respx.mock
    def test_trigger_call(self):
        respx.post(f"{BASE_URL}/api/trigger-call/").mock(
            return_value=httpx.Response(200, json={"call_id": "call-abc", "status": "initiated"})
        )
        with make_client() as client:
            resp = client.trigger_call(
                agent_id="agent-1",
                contact_number="+1234567890",
                name="Alice",
            )
        assert isinstance(resp, TriggerCallResponse)
        assert resp.call_id == "call-abc"

    @respx.mock
    def test_trigger_call_nested_call_id(self):
        respx.post(f"{BASE_URL}/api/trigger-call/").mock(
            return_value=httpx.Response(200, json={"output": {"call_id": "call-xyz"}})
        )
        with make_client() as client:
            resp = client.trigger_call(
                agent_id="agent-1",
                contact_number="+1234567890",
                name="Bob",
            )
        assert resp.call_id == "call-xyz"

    @respx.mock
    def test_get_call_history(self):
        payload = {
            "data": [
                {"call_id": "c1", "duration": 30},
                {"call_id": "c2", "duration": 45},
            ],
            "pagination": {"page": 1, "page_size": 50, "total": 2, "total_pages": 1},
        }
        respx.get(f"{BASE_URL}/api/call-history").mock(
            return_value=httpx.Response(200, json=payload)
        )
        with make_client() as client:
            resp = client.get_call_history(page=1, page_size=50)
        assert isinstance(resp, CallHistoryResponse)
        assert len(resp.data) == 2
        assert resp.data[0].call_id == "c1"
        assert resp.pagination.total == 2
        assert resp.pagination.total_pages == 1

    @respx.mock
    def test_get_call_history_pagination_params(self):
        route = respx.get(f"{BASE_URL}/api/call-history").mock(
            return_value=httpx.Response(200, json={"data": [], "pagination": {}})
        )
        with make_client() as client:
            client.get_call_history(page=3, page_size=10)
        assert route.called
        request = route.calls.last.request
        assert b"page=3" in request.url.query
        assert b"page_size=10" in request.url.query

    @respx.mock
    def test_get_transcript(self):
        respx.get(f"{BASE_URL}/api/transcript/call-123").mock(
            return_value=httpx.Response(200, json={"transcript": "Hello world"})
        )
        with make_client() as client:
            resp = client.get_transcript("call-123")
        assert isinstance(resp, TranscriptResponse)
        assert resp.transcript == "Hello world"

    @respx.mock
    def test_get_call_details(self):
        respx.get(f"{BASE_URL}/api/call_details/call-123").mock(
            return_value=httpx.Response(200, json={"call_id": "call-123", "duration": 60})
        )
        with make_client() as client:
            resp = client.get_call_details("call-123")
        assert isinstance(resp, CallDetailsResponse)
        assert resp.call_id == "call-123"

    @respx.mock
    def test_stream_audio(self):
        audio_bytes = b"\x00\x01\x02\x03"
        respx.get(f"{BASE_URL}/api/stream/call-123").mock(
            return_value=httpx.Response(
                200,
                content=audio_bytes,
                headers={"content-type": "audio/wav"},
            )
        )
        with make_client() as client:
            resp = client.stream_audio("call-123")
        assert isinstance(resp, AudioStream)
        assert resp.content == audio_bytes
        assert resp.content_type == "audio/wav"

    def test_x_api_key_header_injected(self):
        """Verify the X-API-Key header is sent on every request."""
        with respx.mock:
            route = respx.get(f"{BASE_URL}/api/health").mock(
                return_value=httpx.Response(200, json={"status": "healthy", "service": "test"})
            )
            with make_client() as client:
                client.health()
            sent_headers = dict(route.calls.last.request.headers)
            assert sent_headers.get("x-api-key") == API_KEY


# ---------------------------------------------------------------------------
# Sync client — error paths
# ---------------------------------------------------------------------------


class TestVaaniClientErrors:
    @respx.mock
    def test_401_raises_authentication_error(self):
        respx.get(f"{BASE_URL}/api/call-history").mock(
            return_value=httpx.Response(401, json={"detail": "Invalid API key"})
        )
        with make_client() as client:
            with pytest.raises(AuthenticationError) as exc_info:
                client.get_call_history()
        assert exc_info.value.status_code == 401

    @respx.mock
    def test_404_raises_not_found_error(self):
        respx.get(f"{BASE_URL}/api/transcript/missing").mock(
            return_value=httpx.Response(404, json={"detail": "Not found"})
        )
        with make_client() as client:
            with pytest.raises(NotFoundError) as exc_info:
                client.get_transcript("missing")
        assert exc_info.value.status_code == 404

    @respx.mock
    def test_500_raises_server_error(self):
        respx.post(f"{BASE_URL}/api/trigger-call/").mock(
            return_value=httpx.Response(500, json={"detail": "Internal error"})
        )
        with make_client() as client:
            with pytest.raises(ServerError) as exc_info:
                client.trigger_call(
                    agent_id="a", contact_number="+1", name="X"
                )
        assert exc_info.value.status_code == 500

    @respx.mock
    def test_timeout_raises_timeout_error(self):
        respx.get(f"{BASE_URL}/api/health").mock(side_effect=httpx.TimeoutException(""))
        from vaani_sdk import TimeoutError as VaaniTimeout
        with make_client() as client:
            with pytest.raises(VaaniTimeout):
                client.health()

    @respx.mock
    def test_connect_error_raises_connection_error(self):
        respx.get(f"{BASE_URL}/api/health").mock(side_effect=httpx.ConnectError(""))
        from vaani_sdk import ConnectionError as VaaniConnectionError
        with make_client() as client:
            with pytest.raises(VaaniConnectionError):
                client.health()


# ---------------------------------------------------------------------------
# Async client — happy paths
# ---------------------------------------------------------------------------


class TestAsyncVaaniClient:
    @respx.mock
    @pytest.mark.asyncio
    async def test_health(self):
        respx.get(f"{BASE_URL}/api/health").mock(
            return_value=httpx.Response(200, json={"status": "healthy", "service": "vaani-external-api"})
        )
        async with make_async_client() as client:
            resp = await client.health()
        assert resp.status == "healthy"

    @respx.mock
    @pytest.mark.asyncio
    async def test_trigger_call(self):
        respx.post(f"{BASE_URL}/api/trigger-call/").mock(
            return_value=httpx.Response(200, json={"call_id": "async-call-1"})
        )
        async with make_async_client() as client:
            resp = await client.trigger_call(
                agent_id="agent-async",
                contact_number="+9876543210",
                name="Carol",
            )
        assert resp.call_id == "async-call-1"

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_call_history(self):
        payload = {
            "data": [{"call_id": "a1"}],
            "pagination": {"page": 1, "page_size": 50, "total": 1, "total_pages": 1},
        }
        respx.get(f"{BASE_URL}/api/call-history").mock(
            return_value=httpx.Response(200, json=payload)
        )
        async with make_async_client() as client:
            resp = await client.get_call_history()
        assert len(resp.data) == 1
        assert resp.data[0].call_id == "a1"

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_transcript(self):
        respx.get(f"{BASE_URL}/api/transcript/call-async").mock(
            return_value=httpx.Response(200, json={"transcript": "async transcript"})
        )
        async with make_async_client() as client:
            resp = await client.get_transcript("call-async")
        assert resp.transcript == "async transcript"

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_call_details(self):
        respx.get(f"{BASE_URL}/api/call_details/call-async").mock(
            return_value=httpx.Response(200, json={"call_id": "call-async"})
        )
        async with make_async_client() as client:
            resp = await client.get_call_details("call-async")
        assert resp.call_id == "call-async"

    @respx.mock
    @pytest.mark.asyncio
    async def test_stream_audio(self):
        audio_bytes = b"\xff\xfe\xfd"
        respx.get(f"{BASE_URL}/api/stream/call-async").mock(
            return_value=httpx.Response(
                200,
                content=audio_bytes,
                headers={"content-type": "audio/mpeg"},
            )
        )
        async with make_async_client() as client:
            resp = await client.stream_audio("call-async")
        assert resp.content == audio_bytes
        assert resp.content_type == "audio/mpeg"

    @respx.mock
    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(self):
        respx.get(f"{BASE_URL}/api/call-history").mock(
            return_value=httpx.Response(401, json={"detail": "Unauthorized"})
        )
        async with make_async_client() as client:
            with pytest.raises(AuthenticationError):
                await client.get_call_history()
