from functools import lru_cache
from typing import Dict, Generator, Generic, Set
from followthemoney import registry, ValueEntity, Statement, SE

from nomenklatura.resolver.identifier import Identifier, StrIdent


class Linker(Generic[SE]):
    """A class to manage the canonicalisation of entities. This stores only the positive
    merges of entities and is used as a lightweight way to apply the harmonisation
    post de-duplication."""

    def __init__(self, entities: Dict[Identifier, Set[Identifier]] = {}) -> None:
        """
        Args:
            entities: an entry for each entity with its connected set of entities.
        """
        self._entities: Dict[Identifier, Set[Identifier]] = entities

    def connected(self, node: Identifier) -> Set[Identifier]:
        nodes = self._entities.get(node)
        if nodes is None:
            return {node}
        return nodes

    @lru_cache(maxsize=1024)
    def get_canonical(self, entity_id: StrIdent) -> str:
        """Return the canonical identifier for the given entity ID."""
        node = Identifier.get(entity_id)
        best = max(self.connected(node))
        if best.canonical:
            return best.id
        return node.id

    def canonicals(self) -> Generator[Identifier, None, None]:
        """Return all the canonical cluster identifiers."""
        for node in self._entities.keys():
            if not node.canonical:
                continue
            canonical = self.get_canonical(node)
            if canonical == node.id:
                yield node

    def get_referents(
        self, canonical_id: StrIdent, canonicals: bool = True
    ) -> Set[str]:
        """Get all the non-canonical entity identifiers which refer to a given
        canonical identifier."""
        node = Identifier.get(canonical_id)
        referents: Set[str] = set()
        for connected in self.connected(node):
            if not canonicals and connected.canonical:
                continue
            if connected == node:
                continue
            referents.add(connected.id)
        return referents

    def apply(self, proxy: SE) -> SE:
        """Replace all entity references in a given proxy with their canonical
        identifiers. This is essentially the harmonisation post de-dupe."""
        if proxy.id is None:
            return proxy
        proxy.id = self.get_canonical(proxy.id)
        return self.apply_properties(proxy)

    def apply_stream(self, proxy: ValueEntity) -> ValueEntity:
        if proxy.id is None:
            return proxy
        proxy.id = self.get_canonical(proxy.id)
        for prop in proxy.iterprops():
            if prop.type == registry.entity:
                values = proxy.pop(prop)
                for value in values:
                    proxy.unsafe_add(prop, self.get_canonical(value), cleaned=True)
        return proxy

    def apply_properties(self, proxy: SE) -> SE:
        for stmt in proxy._iter_stmt():
            if proxy.id is not None:
                stmt.canonical_id = proxy.id
            if stmt.prop_type == registry.entity.name:
                canon_value = self.get_canonical(stmt._value)
                if canon_value != stmt.value:
                    stmt = stmt.clone(
                        value=canon_value,
                        original_value=stmt.original_value or stmt._value,
                    )
        return proxy

    def apply_statement(self, stmt: Statement) -> Statement:
        if stmt.entity_id is not None:
            stmt.canonical_id = self.get_canonical(stmt.entity_id)
        if stmt.prop_type == registry.entity.name:
            canon_value = self.get_canonical(stmt._value)
            if canon_value != stmt._value:
                stmt = stmt.clone(
                    value=canon_value,
                    original_value=stmt.original_value or stmt._value,
                )
        return stmt

    def __repr__(self) -> str:
        return f"<Linker({len(self._entities)})>"
