from normality import slugify
import requests
import logging
from banal import hash_data
from typing import Generator, Optional, Dict, Any
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from followthemoney import DS, SE, registry

from nomenklatura.cache import Cache
from nomenklatura.enrich.common import Enricher, EnricherConfig

log = logging.getLogger(__name__)


class BrightQueryEnricher(Enricher[DS]):
    """Enricher for the BrightQuery Business Identity API."""

    BASE_URL = "https://apigateway.brightquery.com/auth/business-identity-api/org"

    def __init__(
        self,
        dataset: DS,
        cache: Cache,
        config: EnricherConfig,
        session: Optional[requests.Session] = None,
    ):
        super().__init__(dataset, cache, config, session)
        self._user = self.get_config_expand("username", "${BRIGHTQUERY_USERNAME}")
        self._password = self.get_config_expand("password", "${BRIGHTQUERY_PASSWORD}")
        if not self._user or not self._password:
            raise ValueError(
                "Missing BrightQuery credentials: brightquery_user and/or brightquery_pass"
            )

        # BrightQuery sometimes returns transient 401 responses; retry POST calls.
        retries = Retry(
            total=5,
            backoff_factor=3,
            status_forcelist=[
                401, # 401 Unauthorized is sometimes returned even though we have valid credentials
                504, # 504 Gateway Timeout
                502, # 502 Bad Gateway
                ] + list(Retry.RETRY_AFTER_STATUS_CODES),
            allowed_methods=frozenset(["POST"]),
        )
        adapter = HTTPAdapter(max_retries=retries)
        self.session.mount("https://apigateway.brightquery.com", adapter)
        self.session.auth = (self._user, self._password)

        self.skip_jurisdictions = set(self.get_config_list("skip_jurisdictions"))
        """Set of jurisdiction codes to skip during enrichment because they're not covered by
        BrightQuery/opendata.org."""

    def create_proxy(
        self, entity: SE, child: Dict[str, Any]
    ) -> Generator[SE, None, None]:
        # Primary, most common name of the Organization, which equals the name of
        # the ultimate parent or sole entity that comprises the Organization.
        org_name = child.get("bq_organization_name")
        # Some records do not have Legal Entity names. Then we fall back to the org_name.
        name = child.get("bq_legal_entity_name") or org_name
        if not name:
            log.warning(
                "BrightQuery record without name: %s",
                child.get("bq_legal_entity_id"),
            )
            return
        proxy = self.make_entity(entity, "Company")
        # Unique ID of the Organization. An Organization is the concept of a company,
        # which is constructed as a collection of Legal Entities (child and parent entities)
        # and Locations (e.g., offices, stores).
        bq_org_id = child.get("bq_organization_id")
        # Unique ID of the Legal Entity. A Legal Entity is part of an Organization and is
        # registered with the Secretary of State of a jurisdiction.
        # LegalEntity is the primary object of interest for our processing.
        bq_entity_id = child.get("bq_legal_entity_id")
        if bq_entity_id is not None:
            proxy.id = slugify(bq_entity_id, "-")
        if proxy.id is None and bq_org_id is not None:
            proxy.id = f"bqo-{slugify(bq_org_id, '-')}"

        if proxy.id is None:
            log.error("BrightQuery record without IDs: %s", name)
            return

        if len(proxy.id) > registry.entity.max_length:
            log.error(
                "BrightQuery generated ID too long (%d): %s",
                len(proxy.id),
                proxy.id,
            )
            return

        if not proxy.id.startswith("bq-") and not proxy.id.startswith("bqo-"):
            log.error("BrightQuery ID without prefix: %s", proxy.id)
            return

        # Legal name of the Legal Entity
        proxy.add("name", name)
        proxy.add("brightQueryOrgId", bq_org_id)
        proxy.add("brightQueryId", bq_entity_id)
        # Link to the Organization's primary website.
        proxy.add("website", child.get("bq_website"))
        proxy.add("address", child.get("bq_legal_entity_address_summary"))
        # Jurisdiction code (2-digit state name) in which the Legal Entity is registered,
        # typically with the Secretary of State.
        proxy.add("jurisdiction", child.get("bq_legal_entity_jurisdiction_code"))
        # Date on which the Legal Entity was registered with the Secretary of State.
        founded = child.get("bq_legal_entity_date_founded")
        proxy.add("incorporationDate", founded)
        log.info("Candidate [%s]: %s", proxy.id, name)
        yield proxy

    def search(self, payload: dict[str, Any]) -> Generator[Dict[str, str], None, None]:
        cache_id = hash_data(payload)
        cache_key = f"{self.BASE_URL}:{cache_id}"

        # We have to re-implement http_post_json_cached here because the endpoint doesn't
        # return JSON when there are no results.
        resp_data = self.cache.get_json(cache_key, max_age=self.cache_days)
        if not resp_data:
            log.info("BrightQuery search: %r", payload)
            response = self.session.post(self.BASE_URL, json=payload, timeout=15)
            # When no results are found, the API helpfully doesn't return JSON
            # but just a 204 with an empty response body.
            if response.status_code == 204:
                # Cache the empty result to avoid hitting the API again
                # for the same query.
                self.cache.set_json(cache_key, {})
                return
            response.raise_for_status()
            resp_data = response.json()
            self.cache.set_json(cache_key, resp_data)
        # Number of records per hit is 10. Records are sorted by revenue and employees headcount.
        for child in resp_data.get("root", {}).get("children", []):
            yield child

    def match(self, entity: SE) -> Generator[SE, None, None]:
        if not entity.schema.is_a("Organization"):
            return

        countries = entity.get_type_values(registry.country, matchable=True)
        if len(countries) > 0 and all(c in self.skip_jurisdictions for c in countries):
            log.info(
                "Skipping BrightQuery enrichment for %r: unsupported jurisdictions %r",
                entity.id,
                countries,
            )
            return

        # Get the name and address to search
        addresses = entity.get("address")
        address = max(addresses, key=len) if len(addresses) > 0 else None
        for name in entity.get("name"):
            # If we have an address, we can search by both name and address
            payload = {"company_name": name}
            if address:
                payload["address"] = address
            for match in self.search(payload):
                yield from self.create_proxy(entity, match)

    def expand(self, entity: SE, match: SE) -> Generator[SE, None, None]:
        yield match
