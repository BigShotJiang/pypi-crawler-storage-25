# Attack Simulation CLI

CLI frontend for the attack simulation manager REST API. Wraps the manager's HTTP endpoints in an argparse-based command interface.

- **Language:** Python 3.14+, Hatchling build
- **HTTP client:** httpx
- **Entry point:** `src/simulation_cli/__main__.py`
- **Installed command:** `simulation-cli`

## Build & Run

```bash
uv sync                    # install deps
uv run simulation-cli --help

# Auth via flags
uv run simulation-cli --url http://localhost:3000 --token <JWT> catalog list

# Auth via env / .env file
export MANAGER_URL=http://localhost:3000
export MANAGER_API_TOKEN=<JWT>
uv run simulation-cli catalog list
```

## Lint & Typecheck

```bash
uv run ruff check src/     # lint
uv run ruff format src/    # format
uv run pyright src/        # strict mode
```

Pyright is configured as `strict` in `pyproject.toml`. All code must pass with zero errors.

## Architecture

```
src/simulation_cli/
  __main__.py              # argparse entry point, dispatch
  client.py                # ManagerClient — thin httpx wrapper over manager REST API
  types.py                 # Snapshot type alias (TODO: replace with brava package models)
  commands/
    catalog.py             # catalog list/get — browse simulation metadata
    run.py                 # run simulation create/list/get, run goal create/list/get
  reporting/
    protocol.py            # IResultPrinter — output format protocol
    json_printer.py        # JsonPrinter — indented JSON to stdout
```

### Command structure

```
simulation-cli catalog list [--search X] [--offset N] [--limit N]
simulation-cli catalog get <id>
simulation-cli run simulation create --simulation-id SIM1 --account-id UUID --region us-east-1 [--params '{}']
simulation-cli run simulation list [--account-id UUID] [--offset N] [--limit N]
simulation-cli run simulation get <id>
simulation-cli run goal create --goal "text" --account-id UUID --region us-east-1 [--profile-identifier ARN]
simulation-cli run goal list [--account-id UUID] [--offset N] [--limit N]
simulation-cli run goal get <id>
```

### Key patterns

- **Printing is behind a protocol.** `IResultPrinter` in `reporting/protocol.py` defines the output contract. `JsonPrinter` is the current implementation. New formats (table, YAML, etc.) implement the same protocol.
- **`Snapshot` is a temporary type alias** (`dict[str, Any] | list[Any]`). It will be replaced by typed Pydantic models from `brava-attack-simulation-manager` once the manager CI generates and publishes them.
- **Client methods never raise on HTTP errors.** They call `sys.exit()` with a message. Command modules don't need try/except around client calls.
- **`--params` accepts a JSON string**, parsed and validated in `commands/run.py` before forwarding to the client.

## Conventions

- Follow the coding principles in the [root AGENTS.md](../AGENTS.md) — sad-path defaults, minimal nesting, focused helpers.
- New commands go in `commands/` — each module exports `register(subparsers)` and `execute(args, client, printer)`.
- All client methods return `Snapshot` and live in `client.py` grouped by manager resource.
- Use `jj` for version control (colocated jj+git repo).
