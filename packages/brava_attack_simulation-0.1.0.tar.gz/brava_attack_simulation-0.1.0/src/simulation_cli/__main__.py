"""Entry point for ``python -m simulation_cli``."""

from simulation_cli.app import app

if __name__ == "__main__":
    app()
