"""Shared type aliases for simulation_cli.

TODO: Replace Snapshot with typed Pydantic DTOs from brava-attack-simulation-manager
      once generate-pydantic is wired into the manager CI pipeline and the package
      is republished with REST API response models.
"""

from typing import Any

Snapshot = dict[str, Any] | list[Any]
