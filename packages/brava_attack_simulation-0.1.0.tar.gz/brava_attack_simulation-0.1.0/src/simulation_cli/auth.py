"""Credential storage and retrieval for the Brava CLI."""

import json
from pathlib import Path
from typing import NamedTuple

CONFIG_DIR = Path.home() / ".config" / "brava-cli"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"


class StoredCredentials(NamedTuple):
    token: str
    url: str


def store_credentials(token: str, url: str) -> None:
    """Persist API token and URL to disk."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(json.dumps({"token": token, "url": url}))
    CREDENTIALS_FILE.chmod(0o600)


def load_credentials() -> StoredCredentials | None:
    """Load stored credentials, or ``None`` if not found."""
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        data = json.loads(CREDENTIALS_FILE.read_text())
        return StoredCredentials(token=data["token"], url=data["url"])
    except json.JSONDecodeError, KeyError:
        return None


def clear_credentials() -> None:
    """Remove stored credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
