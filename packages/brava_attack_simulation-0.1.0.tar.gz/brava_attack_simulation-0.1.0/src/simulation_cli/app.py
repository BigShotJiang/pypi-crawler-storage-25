"""Brava CLI — enterprise attack simulation management."""

import os
import sys
from typing import Annotated, Optional

import typer
from dotenv import load_dotenv

from simulation_cli import auth
from simulation_cli.client import BravaClient
from simulation_cli.context import CliContext

load_dotenv()

app = typer.Typer(
    name="brava",
    help="Brava Security — attack simulation CLI",
    no_args_is_help=True,
)

auth_app = typer.Typer(help="Manage authentication credentials")
catalog_app = typer.Typer(help="Browse the simulation catalog")
run_app = typer.Typer(help="Manage simulation and goal runs")
sim_app = typer.Typer(help="Simulation run commands")
goal_app = typer.Typer(help="Describe-goal run commands")
doctor_app = typer.Typer(help="Check CLI prerequisites")

app.add_typer(auth_app, name="auth")
app.add_typer(catalog_app, name="catalog")
app.add_typer(run_app, name="run")
app.add_typer(doctor_app, name="doctor")
run_app.add_typer(sim_app, name="simulation")
run_app.add_typer(goal_app, name="goal")


def _resolve_context(json_mode: bool = False) -> CliContext:
    """Resolve URL and token from args, env, or stored credentials."""
    url = os.environ.get("BRAVA_URL")
    token = os.environ.get("BRAVA_API_TOKEN")

    if not url or not token:
        stored = auth.load_credentials()
        if stored:
            token = token or stored.token
            url = url or stored.url

    if not url:
        typer.echo(
            "Error: No Brava URL configured. Run `brava auth login` or set BRAVA_URL.",
            err=True,
        )
        raise typer.Exit(1)

    if not token:
        typer.echo(
            "Error: Not authenticated. Run `brava auth login --token <PAT>` or set BRAVA_API_TOKEN.",
            err=True,
        )
        raise typer.Exit(1)

    client = BravaClient(url=url, token=token)
    return CliContext(client=client, json_mode=json_mode)


# ---------------------------------------------------------------------------
# auth commands
# ---------------------------------------------------------------------------


@auth_app.command("login")
def auth_login(
    token: Annotated[
        str, typer.Option("--token", "-t", help="Personal access token (PAT)")
    ],
    url: Annotated[
        str, typer.Option("--url", help="Brava platform URL")
    ] = "https://console.brava.security",
) -> None:
    """Store credentials for the Brava platform."""
    auth.store_credentials(token, url)
    typer.echo(f"Credentials saved. Platform URL: {url}")


@auth_app.command("logout")
def auth_logout() -> None:
    """Remove stored credentials."""
    auth.clear_credentials()
    typer.echo("Credentials removed.")


@auth_app.command("status")
def auth_status() -> None:
    """Show current authentication status."""
    env_token = os.environ.get("BRAVA_API_TOKEN")
    stored = auth.load_credentials()

    if env_token:
        typer.echo(
            f"Authenticated via BRAVA_API_TOKEN env var (prefix: {env_token[:12]}...)"
        )
    elif stored:
        token, url = stored
        typer.echo(f"Authenticated via stored credentials (prefix: {token[:12]}...)")
        typer.echo(f"  Platform URL: {url}")
    else:
        typer.echo(
            "Not authenticated. Run `brava auth login --token <PAT>` or set BRAVA_API_TOKEN."
        )
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# catalog commands
# ---------------------------------------------------------------------------


@catalog_app.command("list")
def catalog_list(
    search: Annotated[
        Optional[str], typer.Option(help="Filter by name/description")
    ] = None,
    limit: Annotated[Optional[int], typer.Option(help="Max results")] = None,
    offset: Annotated[Optional[int], typer.Option(help="Skip N results")] = None,
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """List available simulations from the catalog."""
    ctx = _resolve_context(json)
    result = ctx.client.list_simulations(search=search, limit=limit, offset=offset)
    ctx.print(result)


@catalog_app.command("get")
def catalog_get(
    id: Annotated[str, typer.Argument(help="Simulation ID (e.g. SIM1)")],
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """Get simulation details by ID."""
    ctx = _resolve_context(json)
    result = ctx.client.get_simulation(id)
    ctx.print(result)


# ---------------------------------------------------------------------------
# run simulation commands
# ---------------------------------------------------------------------------


@sim_app.command("create")
def sim_create(
    simulation_id: Annotated[
        str, typer.Option("--simulation-id", help="Simulation ID (e.g. SIM1)")
    ],
    account_id: Annotated[
        str, typer.Option("--account-id", help="Brava environment UUID")
    ],
    region: Annotated[str, typer.Option("--region", help="Target AWS region")],
    params: Annotated[
        Optional[str], typer.Option(help="Runtime params as JSON string")
    ] = None,
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """Create a new simulation run."""
    import json as json_mod

    parsed_params = None
    if params:
        try:
            parsed_params = json_mod.loads(params)
        except json_mod.JSONDecodeError as exc:
            typer.echo(f"Error: Invalid --params JSON: {exc}", err=True)
            raise typer.Exit(1)

    ctx = _resolve_context(json)
    result = ctx.client.create_run(
        simulation_id=simulation_id,
        account_id=account_id,
        region=region,
        params=parsed_params,
    )
    ctx.print(result)


@sim_app.command("list")
def sim_list(
    account_id: Annotated[
        Optional[str], typer.Option("--account-id", help="Filter by environment")
    ] = None,
    limit: Annotated[Optional[int], typer.Option(help="Max results")] = None,
    offset: Annotated[Optional[int], typer.Option(help="Skip N results")] = None,
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """List simulation runs."""
    ctx = _resolve_context(json)
    result = ctx.client.list_runs(account_id=account_id, limit=limit, offset=offset)
    ctx.print(result)


@sim_app.command("get")
def sim_get(
    id: Annotated[str, typer.Argument(help="Simulation run UUID")],
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """Get simulation run details."""
    ctx = _resolve_context(json)
    result = ctx.client.get_run(id)
    ctx.print(result)


@sim_app.command("watch")
def sim_watch(
    id: Annotated[str, typer.Argument(help="Simulation run UUID")],
    interval: Annotated[int, typer.Option(help="Poll interval in seconds")] = 5,
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """Watch a simulation run until completion."""
    import time
    from rich.live import Live
    from rich.text import Text

    ctx = _resolve_context(json)
    terminal_statuses = {
        "COMPLETED",
        "FAILED",
        "TIMED_OUT",
        "completed",
        "failed",
        "timed_out",
    }

    if ctx.json_mode:
        while True:
            data = ctx.client.get_run(id)
            status = data.get("status", "") if isinstance(data, dict) else ""
            ctx.print(data)
            if status in terminal_statuses:
                raise typer.Exit(0 if status.lower() == "completed" else 1)
            time.sleep(interval)
    else:
        with Live(Text("Polling..."), refresh_per_second=1) as live:
            while True:
                data = ctx.client.get_run(id)
                status = data.get("status", "") if isinstance(data, dict) else ""
                live.update(ctx.format(data))
                if status in terminal_statuses:
                    ctx.print(data)
                    raise typer.Exit(0 if status.lower() == "completed" else 1)
                time.sleep(interval)


# ---------------------------------------------------------------------------
# run goal commands
# ---------------------------------------------------------------------------


@goal_app.command("create")
def goal_create(
    goal: Annotated[str, typer.Option("--goal", help="Free-text research goal")],
    account_id: Annotated[
        str, typer.Option("--account-id", help="Brava environment UUID")
    ],
    region: Annotated[str, typer.Option("--region", help="Target AWS region")],
    profile_identifier: Annotated[
        Optional[str], typer.Option("--profile", help="Profile identifier (role ARN)")
    ] = None,
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """Create a new describe-goal run."""
    ctx = _resolve_context(json)
    result = ctx.client.create_goal_run(
        goal=goal,
        account_id=account_id,
        region=region,
        profile_identifier=profile_identifier,
    )
    ctx.print(result)


@goal_app.command("list")
def goal_list(
    account_id: Annotated[
        Optional[str], typer.Option("--account-id", help="Filter by environment")
    ] = None,
    limit: Annotated[Optional[int], typer.Option(help="Max results")] = None,
    offset: Annotated[Optional[int], typer.Option(help="Skip N results")] = None,
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """List describe-goal runs."""
    ctx = _resolve_context(json)
    result = ctx.client.list_goal_runs(
        account_id=account_id, limit=limit, offset=offset
    )
    ctx.print(result)


@goal_app.command("get")
def goal_get(
    id: Annotated[str, typer.Argument(help="Describe-goal run UUID")],
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """Get describe-goal run details."""
    ctx = _resolve_context(json)
    result = ctx.client.get_goal_run(id)
    ctx.print(result)


@goal_app.command("watch")
def goal_watch(
    id: Annotated[str, typer.Argument(help="Describe-goal run UUID")],
    interval: Annotated[int, typer.Option(help="Poll interval in seconds")] = 5,
    json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
) -> None:
    """Watch a describe-goal run until completion."""
    import time
    from rich.live import Live
    from rich.text import Text

    ctx = _resolve_context(json)
    terminal_statuses = {"complete", "failed", "COMPLETED", "FAILED"}

    if ctx.json_mode:
        while True:
            data = ctx.client.get_goal_run(id)
            status = data.get("status", "") if isinstance(data, dict) else ""
            ctx.print(data)
            if status in terminal_statuses:
                raise typer.Exit(0 if status.lower() == "complete" else 1)
            time.sleep(interval)
    else:
        with Live(Text("Polling..."), refresh_per_second=1) as live:
            while True:
                data = ctx.client.get_goal_run(id)
                status = data.get("status", "") if isinstance(data, dict) else ""
                live.update(ctx.format(data))
                if status in terminal_statuses:
                    ctx.print(data)
                    raise typer.Exit(0 if status.lower() == "complete" else 1)
                time.sleep(interval)


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


@doctor_app.callback(invoke_without_command=True)
def doctor() -> None:
    """Check CLI prerequisites and connectivity."""
    from rich.console import Console
    from rich.table import Table

    console = Console()
    checks: list[tuple[str, bool, str]] = []

    py = sys.version_info
    checks.append(
        ("Python >= 3.12", py >= (3, 12), f"{py.major}.{py.minor}.{py.micro}")
    )

    env_token = os.environ.get("BRAVA_API_TOKEN")
    stored = auth.load_credentials()
    auth_ok = bool(env_token or stored)
    if env_token:
        detail = "via BRAVA_API_TOKEN env var"
    elif stored:
        detail = f"stored credentials ({stored.url})"
    else:
        detail = "not authenticated"
    checks.append(("Authentication", auth_ok, detail))

    url = os.environ.get("BRAVA_URL") or (stored.url if stored else None)
    token = env_token or (stored.token if stored else None)
    if url:
        try:
            import httpx

            r = httpx.get(f"{url}/api/v1/health", timeout=5.0)
            checks.append(
                (
                    "Platform connectivity",
                    r.status_code == 200,
                    f"{url} -> HTTP {r.status_code}",
                )
            )
        except Exception as exc:
            checks.append(("Platform connectivity", False, str(exc)[:80]))
    else:
        checks.append(("Platform connectivity", False, "no URL configured"))

    if url and token:
        try:
            import httpx

            r = httpx.get(
                f"{url}/api/v1/attack-simulation/simulation",
                headers={"Authorization": f"Bearer {token}"},
                params={"limit": "1"},
                timeout=5.0,
            )
            if r.status_code == 200:
                checks.append(("Token validation", True, "token accepted by platform"))
            elif r.status_code == 401:
                checks.append(("Token validation", False, "invalid or expired token"))
                auth_ok = False
            else:
                checks.append(
                    ("Token validation", False, f"unexpected HTTP {r.status_code}")
                )
        except Exception as exc:
            checks.append(("Token validation", False, str(exc)[:80]))
    elif auth_ok:
        checks.append(("Token validation", False, "skipped (no URL)"))

    table = Table(title="brava doctor")
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    all_ok = True
    for name, ok, detail in checks:
        status = "[green]OK[/green]" if ok else "[red]FAIL[/red]"
        if not ok:
            all_ok = False
        table.add_row(name, status, detail)

    console.print()
    console.print(table)
    console.print()
    console.print(
        "[green]All checks passed.[/green]"
        if all_ok
        else "[yellow]Some checks failed.[/yellow]"
    )


if __name__ == "__main__":
    app()
