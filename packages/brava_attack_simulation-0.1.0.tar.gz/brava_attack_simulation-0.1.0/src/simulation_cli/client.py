"""HTTP client for the Brava platform API (via BFF)."""

import sys
from typing import Any

import httpx

from simulation_cli.types import Snapshot


class BravaClient:
    """Authenticated HTTP client for the Brava BFF.

    Routes requests through the backend-for-frontend which validates
    the PAT via auth-service and proxies to downstream microservices.
    """

    def __init__(self, url: str, token: str) -> None:
        self._http = httpx.Client(
            base_url=url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> Snapshot:
        try:
            response = self._http.request(method, path, **kwargs)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            sys.exit(f"HTTP {exc.response.status_code}: {exc.response.text}")
        except httpx.RequestError as exc:
            sys.exit(f"Request failed: {exc}")
        return response.json()

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Snapshot:
        return self._request("GET", path, params=params)

    def _post(self, path: str, body: dict[str, Any]) -> Snapshot:
        return self._request("POST", path, json=body)

    # --- simulation catalog (via BFF) ---

    def list_simulations(
        self,
        search: str | None = None,
        offset: int | None = None,
        limit: int | None = None,
    ) -> Snapshot:
        params: dict[str, Any] = {}
        if search is not None:
            params["search"] = search
        if offset is not None:
            params["offset"] = offset
        if limit is not None:
            params["limit"] = limit
        return self._get("/api/v1/attack-simulation/simulation", params or None)

    def get_simulation(self, id: str) -> Snapshot:
        return self._get(f"/api/v1/attack-simulation/simulation/{id}")

    # --- simulation runs (via BFF) ---

    def create_run(
        self,
        simulation_id: str,
        account_id: str,
        region: str,
        params: dict[str, Any] | None = None,
    ) -> Snapshot:
        body: dict[str, Any] = {
            "simulationMetadataId": simulation_id,
            "targetAccountId": account_id,
            "targetRegion": region,
        }
        if params is not None:
            body["params"] = params
        return self._post("/api/v1/attack-simulation/simulation-run", body)

    def list_runs(
        self,
        account_id: str | None = None,
        offset: int | None = None,
        limit: int | None = None,
    ) -> Snapshot:
        params: dict[str, Any] = {}
        if account_id is not None:
            params["accountId"] = account_id
        if offset is not None:
            params["offset"] = offset
        if limit is not None:
            params["limit"] = limit
        return self._get("/api/v1/attack-simulation/simulation-run", params or None)

    def get_run(self, id: str) -> Snapshot:
        return self._get(f"/api/v1/attack-simulation/simulation-run/{id}")

    # --- describe-goal runs (via BFF) ---

    def create_goal_run(
        self,
        goal: str,
        account_id: str,
        region: str,
        profile_identifier: str | None = None,
    ) -> Snapshot:
        body: dict[str, Any] = {
            "goal": goal,
            "targetAccountId": account_id,
            "targetRegion": region,
        }
        if profile_identifier is not None:
            body["profileIdentifier"] = profile_identifier
        return self._post("/api/v1/attack-simulation/describe-goal-run", body)

    def list_goal_runs(
        self,
        account_id: str | None = None,
        offset: int | None = None,
        limit: int | None = None,
    ) -> Snapshot:
        params: dict[str, Any] = {}
        if account_id is not None:
            params["accountId"] = account_id
        if offset is not None:
            params["offset"] = offset
        if limit is not None:
            params["limit"] = limit
        return self._get("/api/v1/attack-simulation/describe-goal-run", params or None)

    def get_goal_run(self, id: str) -> Snapshot:
        return self._get(f"/api/v1/attack-simulation/describe-goal-run/{id}")

    # --- health ---

    def health(self) -> Snapshot:
        return self._get("/api/v1/health")
