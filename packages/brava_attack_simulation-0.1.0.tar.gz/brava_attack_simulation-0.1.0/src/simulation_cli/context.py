"""CLI context with dual-mode output (Rich for TTY, JSON for CI)."""

# pyright: reportUnknownArgumentType=false, reportUnknownVariableType=false, reportUnknownMemberType=false

import json
import sys

from rich.console import Console, RenderableType
from rich.panel import Panel
from rich.table import Table

from simulation_cli.client import BravaClient
from simulation_cli.types import Snapshot

STATUS_COLORS: dict[str, str] = {
    "planning": "yellow",
    "executing": "blue",
    "collecting": "cyan",
    "complete": "green",
    "completed": "green",
    "failed": "red",
    "timed_out": "red",
    "PLANNING": "yellow",
    "EXECUTING": "blue",
    "COLLECTING": "cyan",
    "COMPLETED": "green",
    "FAILED": "red",
    "TIMED_OUT": "red",
}

PREFERRED_COLUMNS: list[str] = [
    "id",
    "cid",
    "name",
    "status",
    "goal",
    "simulationMetadataId",
    "targetAccountId",
    "targetRegion",
    "provider",
    "createdAt",
]


class CliContext:
    """Holds the authenticated client and output mode."""

    def __init__(self, client: BravaClient, json_mode: bool = False) -> None:
        self.client = client
        self.json_mode = json_mode or not sys.stdout.isatty()
        self.console = Console()

    def print(self, data: Snapshot) -> None:
        if self.json_mode:
            print(json.dumps(data, indent=2, default=str))
        else:
            self.console.print(self.format(data))

    def format(self, data: Snapshot) -> RenderableType:
        if isinstance(data, list):
            return _format_list(data)
        if "data" in data and isinstance(data["data"], list):
            return _format_paginated(data)
        return _format_dict(data)


def _format_list(items: list[dict[str, object] | object]) -> Table:
    if not items:
        return Table(title="No results")

    first = items[0]
    if not isinstance(first, dict):
        table = Table(show_lines=False)
        table.add_column("value")
        for item in items:
            table.add_row(str(item))
        return table

    all_keys: list[str] = list(first.keys())
    keys = [k for k in PREFERRED_COLUMNS if k in all_keys]
    if not keys:
        keys = [k for k in all_keys if not isinstance(first.get(k), (dict, list))][:8]

    table = Table(show_lines=False)
    for key in keys:
        table.add_column(key, style="bold" if key in ("id", "cid", "name") else "")

    for item in items:
        if not isinstance(item, dict):
            continue
        row: list[str] = []
        for key in keys:
            val = item.get(key, "")
            if key == "status":
                color = STATUS_COLORS.get(str(val), "white")
                row.append(f"[{color}]{val}[/{color}]")
            elif key == "createdAt" and isinstance(val, str) and len(val) > 10:
                row.append(val[:10])
            else:
                s = str(val) if val is not None else ""
                row.append(s[:60] + "..." if len(s) > 60 else s)
        table.add_row(*row)
    return table


def _format_paginated(data: dict[str, object]) -> Table:
    items = data["data"]
    assert isinstance(items, list)
    total = data.get("total", len(items))
    table = _format_list(items)
    table.caption = f"Showing {len(items)} of {total}"
    return table


def _format_dict(data: dict[str, object]) -> Panel:
    lines: list[str] = []
    for key, val in data.items():
        if key == "status":
            color = STATUS_COLORS.get(str(val), "white")
            lines.append(f"[bold]{key}:[/bold] [{color}]{val}[/{color}]")
        elif isinstance(val, list) and len(val) > 3:
            lines.append(f"[bold]{key}:[/bold] ({len(val)} items)")
        elif isinstance(val, dict):
            lines.append(f"[bold]{key}:[/bold] {{...}}")
        else:
            lines.append(f"[bold]{key}:[/bold] {val}")

    title = str(data.get("id", data.get("name", "Result")))
    return Panel("\n".join(lines), title=title, expand=False)
