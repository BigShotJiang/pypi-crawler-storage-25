from utils import lists


def test_first_returns_first_element():
    assert lists.first([1, 2, 3]) == 1


def test_first_empty_returns_default():
    assert lists.first([], default="x") == "x"


def test_last_returns_last_element():
    assert lists.last([1, 2, 3]) == 3


def test_last_empty_returns_default():
    assert lists.last([], default=0) == 0


def test_nth_returns_indexed_element():
    assert lists.nth(["a", "b", "c"], 1) == "b"


def test_nth_out_of_range_returns_default():
    assert lists.nth([1], 5, default=None) is None


def test_sort_ascending():
    assert lists.sort([3, 1, 2]) == [1, 2, 3]


def test_sort_descending():
    assert lists.sort([3, 1, 2], descending=True) == [3, 2, 1]


def test_sort_by_nth():
    rows = [(2, "b"), (1, "a"), (3, "c")]
    assert lists.sort_by_nth(rows, 0) == [(1, "a"), (2, "b"), (3, "c")]


def test_sort_by_func_default_descending():
    assert lists.sort_by_func([-1, -3, -2], abs) == [-3, -2, -1]


def test_sort_by_func_ascending():
    assert lists.sort_by_func([-1, -3, -2], abs, descending=False) == [-1, -2, -3]


def test_sort_by_attribute():
    class Item:
        def __init__(self, v):
            self.v = v

    items = [Item(3), Item(1), Item(2)]
    assert [x.v for x in lists.sort_by_attribute(items, "v")] == [1, 2, 3]


def test_sort_by_method():
    class Item:
        def __init__(self, v):
            self._v = v

        def key(self):
            return self._v

    items = [Item(3), Item(1)]
    assert [x.key() for x in lists.sort_by_method(items, "key", descending=False)] == [1, 3]


def test_frequency_dict():
    assert dict(lists.frequency_dict(["a", "b", "a"])) == {"a": 2, "b": 1}
