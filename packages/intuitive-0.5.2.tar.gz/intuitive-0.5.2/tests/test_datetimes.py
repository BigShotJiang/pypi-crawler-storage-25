import datetime

import pytest

from utils import datetimes


def test_parse_date_string():
    assert datetimes.parse_date_string("2024-03-15") == datetime.date(2024, 3, 15)


def test_parse_date_string_year_first():
    assert datetimes.parse_date_string("2024-03-15", year_first=True) == datetime.date(2024, 3, 15)


def test_convert_format_replaces_simple_codes():
    fmt = "year-month-day"
    assert "%Y" in datetimes.convert_format(fmt)
    assert "%m" in datetimes.convert_format(fmt)
    assert "%d" in datetimes.convert_format(fmt)


def test_string_to_date():
    d = datetimes.string_to_date("2024-05-01", "year-month-day")
    assert d == datetime.date(2024, 5, 1)


def test_string_to_datetime():
    dt = datetimes.string_to_datetime("2024-05-01 14:30:00", "year-month-day hour:minute:second")
    assert dt == datetime.datetime(2024, 5, 1, 14, 30, 0)


def test_date_to_string():
    d = datetime.date(2024, 6, 1)
    s = datetimes.date_to_string(d, "year-month-day")
    assert s == "2024-06-01"


def test_datetime_to_string():
    dt = datetime.datetime(2024, 6, 1, 9, 5, 7)
    s = datetimes.datetime_to_string(dt, "year-month-day hour:minute:second")
    assert s == "2024-06-01 09:05:07"


def test_timestamp_round_trip():
    dt = datetime.datetime(2020, 1, 2, 3, 4, 5)
    ts = datetimes.datetime_to_timestamp(dt)
    assert datetimes.timestamp_to_datetime(ts) == dt
    assert datetimes.timestamp_to_date(ts) == dt.date()


def test_date_to_datetime_min_and_max_time():
    d = datetime.date(2024, 1, 1)
    min_dt = datetimes.date_to_datetime(d, min_time=True)
    max_dt = datetimes.date_to_datetime(d, min_time=False)
    assert min_dt.time() == datetime.datetime.min.time()
    assert max_dt.time() == datetime.datetime.max.time()


def test_date_generator():
    start = datetime.date(2024, 1, 1)
    end = datetime.date(2024, 1, 3)
    assert list(datetimes.date_generator(start, end)) == [
        datetime.date(2024, 1, 1),
        datetime.date(2024, 1, 2),
        datetime.date(2024, 1, 3),
    ]


def test_date_generator_interval():
    start = datetime.date(2024, 1, 1)
    end = datetime.date(2024, 1, 5)
    assert list(datetimes.date_generator(start, end, interval=2)) == [
        datetime.date(2024, 1, 1),
        datetime.date(2024, 1, 3),
        datetime.date(2024, 1, 5),
    ]


def test_reverse_date_generator():
    end = datetime.date(2024, 1, 3)
    start = datetime.date(2024, 1, 1)
    assert list(datetimes.reverse_date_generator(end, start)) == [
        datetime.date(2024, 1, 3),
        datetime.date(2024, 1, 2),
        datetime.date(2024, 1, 1),
    ]


def test_month_generator():
    start = datetime.date(2024, 1, 15)
    end = datetime.date(2024, 4, 1)
    assert list(datetimes.month_generator(start, end)) == [
        datetime.date(2024, 1, 15),
        datetime.date(2024, 2, 15),
        datetime.date(2024, 3, 15),
    ]


def test_reverse_month_generator():
    end = datetime.date(2024, 3, 15)
    start = datetime.date(2024, 1, 15)
    assert list(datetimes.reverse_month_generator(end, start)) == [
        datetime.date(2024, 3, 15),
        datetime.date(2024, 2, 15),
        datetime.date(2024, 1, 15),
    ]


def test_date_for_humans():
    d = datetime.date(2024, 3, 4)  # Monday
    assert datetimes.date_for_humans(d, include_day=True) == "Monday March 04, 2024"
    assert datetimes.date_for_humans(d, include_day=False) == "March 04, 2024"


def test_date_by_weekday_generator():
    start = datetime.date(2024, 3, 4)  # Monday
    end = datetime.date(2024, 3, 25)
    mondays = list(datetimes.date_by_weekday_generator(start, end, weekday=0))
    assert mondays[0] == datetime.date(2024, 3, 4)
    assert all(d.weekday() == 0 for d in mondays)
    assert mondays[-1] <= end
