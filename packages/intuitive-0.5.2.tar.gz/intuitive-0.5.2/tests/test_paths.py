import os
import tempfile
from pathlib import Path

import pytest

from utils.paths import (
    coerce_pathlib,
    coerce_string,
    depth_from_start,
    depth_to_end,
    is_subdirectory,
    is_valid_path,
)


def test_is_subdirectory_true_when_base_is_ancestor_of_candidate():
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp) / "a" / "b"
        child = Path(tmp) / "a" / "b" / "c" / "d"
        base.mkdir(parents=True)
        child.mkdir(parents=True)
        assert is_subdirectory(base, child) is True


def test_is_subdirectory_false_when_not_ancestor():
    with tempfile.TemporaryDirectory() as tmp:
        other = Path(tmp) / "x"
        other.mkdir()
        leaf = Path(tmp) / "a" / "b"
        leaf.mkdir(parents=True)
        assert is_subdirectory(leaf, other) is False


def test_is_valid_path_empty_string():
    assert is_valid_path("") is False


def test_is_valid_path_non_string():
    assert is_valid_path(None) is False


def test_is_valid_path_reasonable_paths():
    assert is_valid_path("C:\\Users\\example\\file.txt") is True
    assert is_valid_path("/tmp/foo/bar") is True


def test_is_valid_path_invalid_characters():
    assert is_valid_path("foo<>bar") is False


def test_coerce_pathlib_converts_argument():
    @coerce_pathlib(0)
    def take(p):
        return p

    result = take("some/path")
    assert isinstance(result, Path)
    assert result == Path("some/path")


def test_coerce_string_converts_argument():
    @coerce_string(0)
    def take(p):
        return p

    assert take(Path("x")) == "x"


def test_depth_from_start(tmp_path):
    d = tmp_path / "a" / "b"
    d.mkdir(parents=True)
    assert depth_from_start(d) == len(d.parents)


def test_depth_to_end_no_files_returns_zero(tmp_path):
    assert depth_to_end(tmp_path) == 0


def test_depth_to_end_nested_file(tmp_path):
    sub = tmp_path / "nested" / "deep"
    sub.mkdir(parents=True)
    (sub / "f.txt").write_text("x", encoding="utf-8")
    (tmp_path / "root.txt").write_text("y", encoding="utf-8")
    deepest = depth_to_end(tmp_path)
    assert deepest >= 1
