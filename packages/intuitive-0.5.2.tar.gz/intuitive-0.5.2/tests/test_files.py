import tempfile
from pathlib import Path

from utils import files


def test_file_size(tmp_path):
    p = tmp_path / "a.txt"
    p.write_bytes(b"hello")
    assert files.file_size(p) == 5


def test_directory_size(tmp_path):
    (tmp_path / "a.txt").write_bytes(b"ab")
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "b.txt").write_bytes(b"cde")
    assert files.directory_size(tmp_path) == 5


def test_size_file(tmp_path):
    p = tmp_path / "f.bin"
    p.write_bytes(b"x" * 10)
    assert files.size(p) == 10


def test_size_directory(tmp_path):
    (tmp_path / "x").write_text("hi", encoding="utf-8")
    assert files.size(tmp_path) == 2


def test_size_missing_returns_default():
    with tempfile.TemporaryDirectory() as tmp:
        missing = Path(tmp) / "nope"
        assert files.size(missing, default=-1) == -1


def test_created_modified_accessed_are_ints(tmp_path):
    p = tmp_path / "t.txt"
    p.write_text("z", encoding="utf-8")
    assert isinstance(files.created_at(p), int)
    assert isinstance(files.modified_at(p), int)
    assert isinstance(files.accessed_at(p), int)


def test_file_statistics(tmp_path):
    p = tmp_path / "s.txt"
    p.write_bytes(b"data")
    st = files.file_statistics(p)
    assert st.st_size == 4
