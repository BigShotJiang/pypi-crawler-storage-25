from utils import printers


def test_print_list(capsys):
    printers.print_list([1, 2, 3])
    out = capsys.readouterr().out
    assert out == "1\n2\n3\n"


def test_print_dict(capsys):
    printers.print_dict({"a": 1, "b": 2})
    out = capsys.readouterr().out
    assert "a: 1" in out
    assert "b: 2" in out
