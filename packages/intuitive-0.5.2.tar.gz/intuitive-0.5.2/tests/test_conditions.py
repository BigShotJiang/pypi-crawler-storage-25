import pytest

from utils.conditions import both, either, neither


@pytest.mark.parametrize(
    ("a", "b", "expected"),
    [
        (True, True, True),
        (True, False, False),
        (False, True, False),
        (False, False, False),
    ],
)
def test_both(a, b, expected):
    assert both(a, b) is expected


@pytest.mark.parametrize(
    ("a", "b", "expected"),
    [
        (True, True, True),
        (True, False, True),
        (False, True, True),
        (False, False, False),
    ],
)
def test_either(a, b, expected):
    assert either(a, b) is expected


@pytest.mark.parametrize(
    ("a", "b", "expected"),
    [
        (True, True, False),
        (True, False, False),
        (False, True, False),
        (False, False, True),
    ],
)
def test_neither(a, b, expected):
    assert neither(a, b) is expected
