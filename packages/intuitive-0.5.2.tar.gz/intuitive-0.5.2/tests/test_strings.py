import string

from utils.strings import ensure_single_spaced, remove_punctuation


def test_remove_punctuation_replaces_punctuation_with_spaces():
    s = "hello, world!"
    out = remove_punctuation(s)
    assert "," not in out
    assert "!" not in out
    assert "hello" in out
    assert "world" in out


def test_remove_punctuation_preserves_non_punctuation():
    assert remove_punctuation("abc123") == "abc123"


def test_remove_punctuation_all_punctuation_becomes_spaces():
    s = string.punctuation
    out = remove_punctuation(s)
    assert out.strip() == ""
    assert len(out) == len(s)


def test_ensure_single_spaced_collapses_whitespace():
    assert ensure_single_spaced("  a   b  c  ") == "a b c"


def test_ensure_single_spaced_strips_ends():
    assert ensure_single_spaced("\n\tfoo\n") == "foo"
