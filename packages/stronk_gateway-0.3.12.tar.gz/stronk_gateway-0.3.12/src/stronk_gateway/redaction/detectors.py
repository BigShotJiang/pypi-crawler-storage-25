from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Protocol

from stronk_gateway.config import Settings

from .models import DetectorType, SpanMatch
from .presidio_backend import PresidioBackendConfig, PresidioDetector

EMAIL_RE = re.compile(r"\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b", re.IGNORECASE)
US_PHONE_RE = re.compile(
    r"(?<!\d)(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?){2}\d{4}(?!\d)"
)
CN_PHONE_RE = re.compile(r"(?<!\d)(?:\+?86[-.\s]?)?1[3-9]\d{9}(?!\d)")
CHINA_BUSINESS_ID_CONTEXT_RE = re.compile(
    r"(?:统一社会信用代码|统一信用代码|社会信用代码|纳税人识别号|纳税编码|税号)"
    r"\s*[:：]?\s*([0-9A-Z]{8,20})"
)
OPENAI_KEY_RE = re.compile(r"\bsk(?:-proj)?-[A-Za-z0-9_\-]{20,}\b")
ANTHROPIC_KEY_RE = re.compile(r"\bsk-ant-[A-Za-z0-9_\-]{16,}\b")
GENERIC_KEY_RE = re.compile(r"\b(?:ghp|rk|pk|xoxb|xoxp)_[A-Za-z0-9_\-]{20,}\b", re.IGNORECASE)
GENERIC_BEARER_RE = re.compile(
    r"\bBearer\s+[A-Za-z0-9._\-]{16,}\b",
    re.IGNORECASE,
)
SPLIT_BEARER_RE = re.compile(
    r"\bB(?:[ \t\r\n\u200b\u200c\u200d\ufeff]*)e(?:[ \t\r\n\u200b\u200c\u200d\ufeff]*)"
    r"a(?:[ \t\r\n\u200b\u200c\u200d\ufeff]*)r(?:[ \t\r\n\u200b\u200c\u200d\ufeff]*)"
    r"e(?:[ \t\r\n\u200b\u200c\u200d\ufeff]*)r(?:[ \t\r\n\u200b\u200c\u200d\ufeff]*)"
    r"[A-Za-z0-9._\-\u200b\u200c\u200d\ufeff ]{16,}",
    re.IGNORECASE,
)
SPLIT_KEY_RE = re.compile(
    r"\b(?:s(?:[\u200b\u200c\u200d\ufeff]*)k(?:[\u200b\u200c\u200d\ufeff]*)-"
    r"(?:[A-Za-z0-9_\-\u200b\u200c\u200d\ufeff]){20,})\b",
    re.IGNORECASE,
)
JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\b")
ENGLISH_PERSON_TOKEN = r"(?:[A-Z][a-z]{1,29}|[A-Z]{2,29})"
ENGLISH_PERSON_CONTEXT_RE = re.compile(
    r"(?i:\b(?:name|contact|employee|customer|patient|client|manager|founder|ceo|cto)\b)"
    rf"\s*(?:(?i:is)\b|:)?\s*({ENGLISH_PERSON_TOKEN}(?:\s+{ENGLISH_PERSON_TOKEN}){{1,2}})\b"
)
ENGLISH_PERSON_HONORIFIC_RE = re.compile(
    rf"\b(?:Mr|Mrs|Ms|Dr|Prof)\.?\s+({ENGLISH_PERSON_TOKEN}(?:\s+{ENGLISH_PERSON_TOKEN}){{1,2}})\b"
)
ENGLISH_PERSON_SIGNATURE_RE = re.compile(
    r"\b([A-Z]{2,29}(?:\s+[A-Z]{1,29}){1,3})(?=,\s*"
    r"(?:Director|Manager|CEO|CFO|CTO|President|Chairman|Owner|Representative)\b)"
)
ENGLISH_PERSON_STANDALONE_RE = re.compile(
    r"^[A-Z][a-z]{1,29}(?:\s+[A-Z][a-z]{1,29}){1,2}$"
)
CHINESE_PERSON_CONTEXT_RE = re.compile(
    r"(?:姓名|名字|联系人|收件人|客户|负责人|患者|老师|叫|是|联系|找)\s*[:：]?\s*([\u4e00-\u9fff]{2,4})"
)
CHINESE_PERSON_RE = re.compile(
    r"(?<![\u4e00-\u9fff])"
    r"(?:赵|钱|孙|李|周|吴|郑|王|冯|陈|褚|卫|蒋|沈|韩|杨|朱|秦|许|何|吕|施|张|孔|曹|严|华|"
    r"金|魏|陶|姜|谢|邹|喻|柏|水|窦|章|云|苏|潘|葛|范|彭|郎|鲁|韦|昌|马|苗|凤|方|俞|任|"
    r"袁|柳|唐|罗|薛|雷|贺|倪|汤|殷|毕|郝|安|常|乐|于|傅|皮|齐|康|伍|余|元|顾|孟|黄|和|"
    r"穆|萧|尹|姚|邵|湛|汪|祁|毛|禹|狄|米|贝|明|臧|计|伏|成|戴|谈|宋|茅|庞|熊|纪|舒|屈|项|祝|董|梁)"
    r"[\u4e00-\u9fff]{1,2}(?![\u4e00-\u9fff])"
)
ENGLISH_ORG_RE = re.compile(
    r"\b[A-Z][A-Za-z0-9&.\-]*(?:\s+[A-Z][A-Za-z0-9&.\-]*){0,6}\s+"
    r"(?i:inc\.?|llc|ltd\.?|corp\.?|corporation|company|group|university|bank|hospital|"
    r"institute|foundation|association|school|college|technologies?|systems?|labs?)"
    r"(?=$|[^A-Za-z0-9&.\-])"
)
CHINESE_ORG_SUFFIX_RE = re.compile(
    r"(?:有限责任公司|股份有限公司|公司|集团|大学|医院|银行|研究院|研究所|学院|科技)"
)
CHINESE_ORG_RE = re.compile(
    r"[\u4e00-\u9fffA-Za-z0-9]{2,40}"
    r"(?:有限责任公司|股份有限公司|公司|集团|大学|医院|银行|研究院|研究所|学院|科技)"
)
ENGLISH_ADDRESS_RE = re.compile(
    r"\b\d{1,5}\s+(?:[A-Z][A-Za-z0-9.'\-]*\s){0,5}"
    r"(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|Court|Ct|Way|Place|Pl)"
    r"\b(?:[^\n,;]{0,40})",
    re.IGNORECASE,
)
CHINESE_ADDRESS_RE = re.compile(
    r"(?:北京市|上海市|天津市|重庆市|[\u4e00-\u9fff]{2,8}(?:省|市|自治区))?"
    r"[\u4e00-\u9fff0-9]{2,20}(?:区|县|镇|乡|街道|路|街|巷|号|室)"
)

PERSON_STOPWORDS = {
    "OpenAI",
    "Anthropic",
    "FastAPI",
    "Docker",
    "Compose",
    "Street",
    "Road",
    "Avenue",
    "Corporation",
    "Company",
    "Group",
    "University",
    "Hospital",
    "Technology",
    "Technologies",
    "Systems",
}
PERSON_STOPWORDS_LOWER = {item.lower() for item in PERSON_STOPWORDS}
CHINA_UNIFIED_SOCIAL_CREDIT_CODE_ALPHABET = frozenset("0123456789ABCDEFGHJKLMNPQRTUWXY")
CHINESE_ORG_LEADING_CONTEXT = (
    "现为",
    "委托",
    "受托方",
    "委托方",
    "合作方",
    "供应商",
    "客户",
    "由",
    "与",
    "向",
    "为",
)


class Detector(Protocol):
    def detect(self, text: str) -> list[SpanMatch]:
        ...


def _build_match(
    detector: DetectorType,
    match: re.Match[str],
    value: str | None = None,
) -> SpanMatch:
    return SpanMatch(
        detector=detector,
        start=match.start(1) if match.lastindex else match.start(),
        end=match.end(1) if match.lastindex else match.end(),
        value=value or (match.group(1) if match.lastindex else match.group(0)),
    )


class RegexDetector:
    def __init__(self, detector: DetectorType, pattern: re.Pattern[str]) -> None:
        self.detector = detector
        self.pattern = pattern

    def detect(self, text: str) -> list[SpanMatch]:
        return [_build_match(self.detector, match) for match in self.pattern.finditer(text)]


class EnglishPersonDetector:
    def detect(self, text: str) -> list[SpanMatch]:
        matches: list[SpanMatch] = []
        stripped = text.strip()
        if stripped and ENGLISH_PERSON_STANDALONE_RE.fullmatch(stripped):
            candidate = stripped
            if _is_plausible_english_person(candidate):
                start = text.find(candidate)
                synthetic_match = SpanMatch(
                    detector=DetectorType.PERSON_NAME,
                    start=start,
                    end=start + len(candidate),
                    value=candidate,
                )
                matches.append(synthetic_match)

        for match in ENGLISH_PERSON_CONTEXT_RE.finditer(text):
            candidate = match.group(1)
            if _is_plausible_english_person(candidate):
                matches.append(_build_match(DetectorType.PERSON_NAME, match, candidate))
        for match in ENGLISH_PERSON_HONORIFIC_RE.finditer(text):
            candidate = match.group(1)
            if _is_plausible_english_person(candidate):
                matches.append(_build_match(DetectorType.PERSON_NAME, match, candidate))
        for match in ENGLISH_PERSON_SIGNATURE_RE.finditer(text):
            candidate = match.group(1)
            if _is_plausible_english_person(candidate):
                matches.append(_build_match(DetectorType.PERSON_NAME, match, candidate))
        return matches


class ChinesePersonDetector:
    def detect(self, text: str) -> list[SpanMatch]:
        matches: list[SpanMatch] = []
        for match in CHINESE_PERSON_CONTEXT_RE.finditer(text):
            matches.append(_build_match(DetectorType.PERSON_NAME, match, match.group(1)))
        for match in CHINESE_PERSON_RE.finditer(text):
            matches.append(_build_match(DetectorType.PERSON_NAME, match))
        return matches


class ChineseBusinessIdDetector:
    def detect(self, text: str) -> list[SpanMatch]:
        matches: list[SpanMatch] = []
        for match in CHINA_BUSINESS_ID_CONTEXT_RE.finditer(text):
            candidate = match.group(1).strip()
            if _is_plausible_business_identifier(candidate):
                matches.append(_build_match(DetectorType.BUSINESS_ID, match, candidate))
        return matches


class ChineseOrganizationDetector:
    def detect(self, text: str) -> list[SpanMatch]:
        matches: list[SpanMatch] = []
        for match in CHINESE_ORG_RE.finditer(text):
            raw_value = match.group(0)
            candidate = _trim_chinese_org_prefix(raw_value)
            if not candidate or not _is_plausible_chinese_org(candidate):
                continue
            start = match.start() + raw_value.index(candidate)
            end = start + len(candidate)
            matches.append(
                SpanMatch(
                    detector=DetectorType.ORGANIZATION,
                    start=start,
                    end=end,
                    value=candidate,
                )
            )
        return matches


def _is_plausible_english_person(candidate: str) -> bool:
    parts = candidate.split()
    if len(parts) < 2:
        return False
    return not any(part.rstrip(".").lower() in PERSON_STOPWORDS_LOWER for part in parts)


def _is_plausible_business_identifier(candidate: str) -> bool:
    normalized = candidate.strip().upper()
    if len(normalized) == 18:
        return set(normalized) <= CHINA_UNIFIED_SOCIAL_CREDIT_CODE_ALPHABET
    if 8 <= len(normalized) <= 20:
        return normalized.isdigit()
    return False


def _trim_chinese_org_prefix(candidate: str) -> str:
    trimmed = candidate.strip()
    changed = True
    while changed:
        changed = False
        for prefix in CHINESE_ORG_LEADING_CONTEXT:
            if trimmed.startswith(prefix) and len(trimmed) > len(prefix) + 2:
                trimmed = trimmed[len(prefix) :]
                changed = True
                break
    return trimmed


def _is_plausible_chinese_org(candidate: str) -> bool:
    return bool(candidate and CHINESE_ORG_SUFFIX_RE.search(candidate))


def default_detectors() -> tuple[Detector, ...]:
    return (
        RegexDetector(DetectorType.EMAIL, EMAIL_RE),
        RegexDetector(DetectorType.PHONE, US_PHONE_RE),
        RegexDetector(DetectorType.PHONE, CN_PHONE_RE),
        ChineseBusinessIdDetector(),
        RegexDetector(DetectorType.API_KEY, OPENAI_KEY_RE),
        RegexDetector(DetectorType.API_KEY, ANTHROPIC_KEY_RE),
        RegexDetector(DetectorType.API_KEY, GENERIC_KEY_RE),
        RegexDetector(DetectorType.API_KEY, SPLIT_KEY_RE),
        RegexDetector(DetectorType.BEARER_TOKEN, GENERIC_BEARER_RE),
        RegexDetector(DetectorType.BEARER_TOKEN, SPLIT_BEARER_RE),
        RegexDetector(DetectorType.JWT, JWT_RE),
        RegexDetector(DetectorType.ORGANIZATION, ENGLISH_ORG_RE),
        ChineseOrganizationDetector(),
        RegexDetector(DetectorType.ADDRESS, ENGLISH_ADDRESS_RE),
        RegexDetector(DetectorType.ADDRESS, CHINESE_ADDRESS_RE),
        EnglishPersonDetector(),
        ChinesePersonDetector(),
    )


def build_detectors(settings: Settings | None = None) -> tuple[Detector, ...]:
    detectors = list(default_detectors())
    if settings is None or not settings.presidio_enabled:
        return tuple(detectors)
    detectors.append(
        PresidioDetector(
            PresidioBackendConfig(
                languages=settings.presidio_language_list,
                english_model=settings.presidio_english_model,
                chinese_model=settings.presidio_chinese_model,
                score_threshold=settings.presidio_score_threshold,
            )
        )
    )
    return tuple(detectors)


def collect_matches(text: str, detectors: Iterable[Detector] | None = None) -> list[SpanMatch]:
    resolved_detectors = tuple(detectors or default_detectors())
    matches: list[SpanMatch] = []
    for detector in resolved_detectors:
        matches.extend(detector.detect(text))
    return matches
