from __future__ import annotations

import json
import sqlite3
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from threading import Lock

from stronk_gateway.admin.models import AdminAccessRecord, AdminEnrollmentRecord, AdminSessionRecord
from stronk_gateway.security.audit import AuditEventRecord


class AuditStore:
    def __init__(
        self,
        path: str,
        *,
        max_events: int = 2_000,
        max_access_logs: int = 500,
        prune_interval: int = 64,
    ) -> None:
        self.path = Path(path)
        self.max_events = max_events
        self.max_access_logs = max_access_logs
        self.prune_interval = prune_interval
        self._write_lock = Lock()
        self._event_writes_since_prune = 0
        self._access_writes_since_prune = 0
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._bootstrap()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    @contextmanager
    def _session(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def _bootstrap(self) -> None:
        with self._session() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS audit_events (
                    request_id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    endpoint TEXT NOT NULL,
                    model TEXT,
                    stream INTEGER NOT NULL,
                    outcome TEXT NOT NULL,
                    status_code INTEGER NOT NULL,
                    latency_ms INTEGER NOT NULL,
                    detection_count INTEGER NOT NULL,
                    detection_types TEXT NOT NULL,
                    actions TEXT NOT NULL,
                    placeholder_count INTEGER NOT NULL,
                    rehydration_count INTEGER NOT NULL,
                    masked_paths TEXT NOT NULL,
                    blocked INTEGER NOT NULL,
                    route_local INTEGER NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS admin_access_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    roles TEXT NOT NULL,
                    path TEXT NOT NULL,
                    method TEXT NOT NULL,
                    status_code INTEGER NOT NULL,
                    source_ip TEXT
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS admin_sessions (
                    token_hash TEXT PRIMARY KEY,
                    user TEXT NOT NULL,
                    roles TEXT NOT NULL,
                    device_id TEXT,
                    auth_binding TEXT,
                    created_at INTEGER NOT NULL,
                    last_seen_at INTEGER NOT NULL,
                    absolute_expires_at INTEGER NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS admin_enrollments (
                    device_id TEXT PRIMARY KEY,
                    tailscale_login TEXT NOT NULL,
                    browser_public_key TEXT NOT NULL,
                    approved_role TEXT,
                    approved_at TEXT,
                    last_seen_at TEXT NOT NULL,
                    revoked_at TEXT
                )
                """
            )
            self._ensure_column(
                connection,
                table="admin_sessions",
                column="device_id",
                definition="device_id TEXT",
            )
            self._ensure_column(
                connection,
                table="admin_sessions",
                column="auth_binding",
                definition="auth_binding TEXT",
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_admin_sessions_user
                ON admin_sessions(user)
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_admin_sessions_device
                ON admin_sessions(device_id)
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_admin_enrollments_login
                ON admin_enrollments(tailscale_login)
                """
            )
            self._prune_events(connection)
            self._prune_access_logs(connection)
            self._prune_sessions(connection, now=int(time.time()))

    def _ensure_column(
        self,
        connection: sqlite3.Connection,
        *,
        table: str,
        column: str,
        definition: str,
    ) -> None:
        rows = connection.execute(f"PRAGMA table_info({table})").fetchall()
        if any(str(row["name"]) == column for row in rows):
            return
        connection.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")

    def record_event(self, event: AuditEventRecord) -> None:
        self.record_event_batch([event])

    def record_event_batch(self, events: list[AuditEventRecord]) -> None:
        if not events:
            return
        with self._write_lock:
            with self._session() as connection:
                connection.executemany(
                    """
                    INSERT OR REPLACE INTO audit_events (
                        request_id,
                        created_at,
                        provider,
                        endpoint,
                        model,
                        stream,
                        outcome,
                        status_code,
                        latency_ms,
                        detection_count,
                        detection_types,
                        actions,
                        placeholder_count,
                        rehydration_count,
                        masked_paths,
                        blocked,
                        route_local
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            event.request_id,
                            event.created_at,
                            event.provider,
                            event.endpoint,
                            event.model,
                            int(event.stream),
                            event.outcome,
                            event.status_code,
                            event.latency_ms,
                            event.detection_count,
                            json.dumps(
                                event.detection_types, separators=(",", ":"), sort_keys=True
                            ),
                            json.dumps(event.actions, separators=(",", ":"), sort_keys=True),
                            event.placeholder_count,
                            event.rehydration_count,
                            json.dumps(list(event.masked_paths), separators=(",", ":")),
                            int(event.blocked),
                            int(event.route_local),
                        )
                        for event in events
                    ],
                )
                self._event_writes_since_prune += len(events)
                if self._event_writes_since_prune >= self.prune_interval:
                    self._prune_events(connection)
                    self._event_writes_since_prune = 0

    def record_access(self, record: AdminAccessRecord) -> None:
        self.record_access_batch([record])

    def record_access_batch(self, records: list[AdminAccessRecord]) -> None:
        if not records:
            return
        with self._write_lock:
            with self._session() as connection:
                connection.executemany(
                    """
                    INSERT INTO admin_access_logs (
                        created_at,
                        actor,
                        roles,
                        path,
                        method,
                        status_code,
                        source_ip
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            record.created_at,
                            record.actor,
                            json.dumps(list(record.roles), separators=(",", ":")),
                            record.path,
                            record.method,
                            record.status_code,
                            record.source_ip,
                        )
                        for record in records
                    ],
                )
                self._access_writes_since_prune += len(records)
                if self._access_writes_since_prune >= self.prune_interval:
                    self._prune_access_logs(connection)
                    self._access_writes_since_prune = 0

    def overview(self) -> dict[str, object]:
        events = self.list_events(limit=self.max_events)
        provider_counts: dict[str, int] = {}
        detector_counts: dict[str, int] = {}
        action_counts: dict[str, int] = {}
        masked_requests = 0
        blocked_requests = 0
        route_local_requests = 0
        rehydrated_responses = 0
        error_requests = 0

        for event in events:
            provider_counts[event.provider] = provider_counts.get(event.provider, 0) + 1
            for name, count in event.detection_types.items():
                detector_counts[name] = detector_counts.get(name, 0) + count
            for name, count in event.actions.items():
                action_counts[name] = action_counts.get(name, 0) + count
            if event.actions.get("mask", 0) > 0:
                masked_requests += 1
            if event.blocked:
                blocked_requests += 1
            if event.route_local:
                route_local_requests += 1
            if event.rehydration_count > 0:
                rehydrated_responses += 1
            if event.status_code >= 400:
                error_requests += 1

        return {
            "total_requests": len(events),
            "masked_requests": masked_requests,
            "blocked_requests": blocked_requests,
            "route_local_requests": route_local_requests,
            "rehydrated_responses": rehydrated_responses,
            "error_requests": error_requests,
            "provider_counts": provider_counts,
            "detector_counts": detector_counts,
            "action_counts": action_counts,
            "last_event_at": events[0].created_at if events else None,
        }

    def list_events(self, *, limit: int = 50, offset: int = 0) -> list[AuditEventRecord]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT *
                FROM audit_events
                ORDER BY created_at DESC
                LIMIT ?
                OFFSET ?
                """,
                (limit, offset),
            ).fetchall()
        return [self._event_from_row(row) for row in rows]

    def get_event(self, request_id: str) -> AuditEventRecord | None:
        with self._session() as connection:
            row = connection.execute(
                "SELECT * FROM audit_events WHERE request_id = ?",
                (request_id,),
            ).fetchone()
        if row is None:
            return None
        return self._event_from_row(row)

    def list_access_logs(self, *, limit: int = 20) -> list[AdminAccessRecord]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT created_at, actor, roles, path, method, status_code, source_ip
                FROM admin_access_logs
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [
            AdminAccessRecord(
                created_at=str(row["created_at"]),
                actor=str(row["actor"]),
                roles=tuple(json.loads(str(row["roles"]))),
                path=str(row["path"]),
                method=str(row["method"]),
                status_code=int(row["status_code"]),
                source_ip=str(row["source_ip"]) if row["source_ip"] is not None else None,
            )
            for row in rows
        ]

    def replace_user_session(
        self,
        *,
        token_hash: str,
        user: str,
        roles: tuple[str, ...],
        device_id: str | None,
        auth_binding: str,
        created_at: int,
        absolute_expires_at: int,
    ) -> None:
        with self._write_lock:
            with self._session() as connection:
                if device_id is None:
                    connection.execute(
                        "DELETE FROM admin_sessions WHERE user = ? AND device_id IS NULL",
                        (user,),
                    )
                else:
                    connection.execute(
                        "DELETE FROM admin_sessions WHERE user = ? AND device_id = ?",
                        (user, device_id),
                    )
                connection.execute(
                    """
                    INSERT OR REPLACE INTO admin_sessions (
                        token_hash,
                        user,
                        roles,
                        device_id,
                        auth_binding,
                        created_at,
                        last_seen_at,
                        absolute_expires_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        token_hash,
                        user,
                        json.dumps(list(roles), separators=(",", ":")),
                        device_id,
                        auth_binding,
                        created_at,
                        created_at,
                        absolute_expires_at,
                    ),
                )
                self._prune_sessions(connection, now=created_at)

    def get_session(
        self,
        token_hash: str,
        *,
        idle_ttl_seconds: int,
        now: int | None = None,
    ) -> AdminSessionRecord | None:
        resolved_now = int(time.time()) if now is None else now
        with self._write_lock:
            with self._session() as connection:
                row = connection.execute(
                    """
                    SELECT
                        token_hash,
                        user,
                        roles,
                        device_id,
                        auth_binding,
                        created_at,
                        last_seen_at,
                        absolute_expires_at
                    FROM admin_sessions
                    WHERE token_hash = ?
                    """,
                    (token_hash,),
                ).fetchone()
                if row is None:
                    return None
                last_seen_at = int(row["last_seen_at"])
                absolute_expires_at = int(row["absolute_expires_at"])
                if (
                    resolved_now > absolute_expires_at
                    or resolved_now - last_seen_at > idle_ttl_seconds
                ):
                    connection.execute(
                        "DELETE FROM admin_sessions WHERE token_hash = ?",
                        (token_hash,),
                    )
                    return None
                connection.execute(
                    """
                    UPDATE admin_sessions
                    SET last_seen_at = ?
                    WHERE token_hash = ?
                    """,
                    (resolved_now, token_hash),
                )
                self._prune_sessions(connection, now=resolved_now)
        return AdminSessionRecord(
            token_hash=str(row["token_hash"]),
            user=str(row["user"]),
            roles=tuple(json.loads(str(row["roles"]))),
            device_id=str(row["device_id"]) if row["device_id"] is not None else None,
            auth_binding=str(row["auth_binding"]) if row["auth_binding"] is not None else None,
            created_at=int(row["created_at"]),
            last_seen_at=resolved_now,
            absolute_expires_at=absolute_expires_at,
        )

    def delete_session(self, token_hash: str) -> None:
        with self._write_lock:
            with self._session() as connection:
                connection.execute(
                    "DELETE FROM admin_sessions WHERE token_hash = ?",
                    (token_hash,),
                )

    def delete_sessions_for_device(self, device_id: str) -> None:
        with self._write_lock:
            with self._session() as connection:
                connection.execute(
                    "DELETE FROM admin_sessions WHERE device_id = ?",
                    (device_id,),
                )

    def list_enrollments(self, *, limit: int = 100) -> list[AdminEnrollmentRecord]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT
                    device_id,
                    tailscale_login,
                    browser_public_key,
                    approved_role,
                    approved_at,
                    last_seen_at,
                    revoked_at
                FROM admin_enrollments
                ORDER BY last_seen_at DESC, device_id ASC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._enrollment_from_row(row) for row in rows]

    def enrollment_counts(self) -> dict[str, int]:
        with self._session() as connection:
            row = connection.execute(
                """
                SELECT
                    SUM(
                        CASE WHEN revoked_at IS NULL AND approved_at IS NOT NULL THEN 1 ELSE 0 END
                    ) AS approved,
                    SUM(
                        CASE WHEN revoked_at IS NULL AND approved_at IS NULL THEN 1 ELSE 0 END
                    ) AS pending,
                    SUM(CASE WHEN revoked_at IS NOT NULL THEN 1 ELSE 0 END) AS revoked
                FROM admin_enrollments
                """
            ).fetchone()
        if row is None:
            return {
                "approved": 0,
                "pending": 0,
                "revoked": 0,
            }
        return {
            "approved": int(row["approved"] or 0),
            "pending": int(row["pending"] or 0),
            "revoked": int(row["revoked"] or 0),
        }

    def get_enrollment(self, device_id: str) -> AdminEnrollmentRecord | None:
        with self._session() as connection:
            row = connection.execute(
                """
                SELECT
                    device_id,
                    tailscale_login,
                    browser_public_key,
                    approved_role,
                    approved_at,
                    last_seen_at,
                    revoked_at
                FROM admin_enrollments
                WHERE device_id = ?
                """,
                (device_id,),
            ).fetchone()
        if row is None:
            return None
        return self._enrollment_from_row(row)

    def upsert_enrollment_request(
        self,
        *,
        device_id: str,
        tailscale_login: str,
        browser_public_key: str,
        last_seen_at: str,
    ) -> AdminEnrollmentRecord:
        with self._write_lock:
            with self._session() as connection:
                row = connection.execute(
                    """
                    SELECT
                        device_id,
                        tailscale_login,
                        browser_public_key,
                        approved_role,
                        approved_at,
                        last_seen_at,
                        revoked_at
                    FROM admin_enrollments
                    WHERE device_id = ?
                    """,
                    (device_id,),
                ).fetchone()
                if row is None:
                    connection.execute(
                        """
                        INSERT INTO admin_enrollments (
                            device_id,
                            tailscale_login,
                            browser_public_key,
                            approved_role,
                            approved_at,
                            last_seen_at,
                            revoked_at
                        ) VALUES (?, ?, ?, NULL, NULL, ?, NULL)
                        """,
                        (device_id, tailscale_login, browser_public_key, last_seen_at),
                    )
                else:
                    current = self._enrollment_from_row(row)
                    if current.revoked_at is not None:
                        raise ValueError(
                            "Revoked device IDs may not be reused for enrollment."
                        )
                    if current.tailscale_login != tailscale_login:
                        raise ValueError(
                            "Device enrollment login does not match the existing record."
                        )
                    if current.browser_public_key != browser_public_key:
                        raise ValueError(
                            "Device enrollment key does not match the existing record."
                        )
                    connection.execute(
                        """
                        UPDATE admin_enrollments
                        SET last_seen_at = ?
                        WHERE device_id = ?
                        """,
                        (last_seen_at, device_id),
                    )
        record = self.get_enrollment(device_id)
        assert record is not None
        return record

    def approve_enrollment(
        self,
        *,
        device_id: str,
        approved_role: str,
        approved_at: str,
    ) -> AdminEnrollmentRecord | None:
        with self._write_lock:
            with self._session() as connection:
                row = connection.execute(
                    """
                    SELECT revoked_at
                    FROM admin_enrollments
                    WHERE device_id = ?
                    """,
                    (device_id,),
                ).fetchone()
                if row is None:
                    return None
                if row["revoked_at"] is not None:
                    raise ValueError("Revoked device IDs may not be approved again.")
                connection.execute(
                    """
                    UPDATE admin_enrollments
                    SET approved_role = ?, approved_at = ?, last_seen_at = ?
                    WHERE device_id = ?
                    """,
                    (approved_role, approved_at, approved_at, device_id),
                )
                connection.execute(
                    "DELETE FROM admin_sessions WHERE device_id = ?",
                    (device_id,),
                )
        return self.get_enrollment(device_id)

    def touch_enrollment(self, *, device_id: str, last_seen_at: str) -> None:
        with self._write_lock:
            with self._session() as connection:
                connection.execute(
                    """
                    UPDATE admin_enrollments
                    SET last_seen_at = ?
                    WHERE device_id = ?
                    """,
                    (last_seen_at, device_id),
                )

    def revoke_enrollment(self, *, device_id: str, revoked_at: str) -> AdminEnrollmentRecord | None:
        with self._write_lock:
            with self._session() as connection:
                row = connection.execute(
                    """
                    SELECT device_id
                    FROM admin_enrollments
                    WHERE device_id = ?
                    """,
                    (device_id,),
                ).fetchone()
                if row is None:
                    return None
                connection.execute(
                    """
                    UPDATE admin_enrollments
                    SET revoked_at = ?, last_seen_at = ?
                    WHERE device_id = ?
                    """,
                    (revoked_at, revoked_at, device_id),
                )
                connection.execute(
                    "DELETE FROM admin_sessions WHERE device_id = ?",
                    (device_id,),
                )
        return self.get_enrollment(device_id)

    def _prune_sessions(self, connection: sqlite3.Connection, *, now: int) -> None:
        connection.execute(
            """
            DELETE FROM admin_sessions
            WHERE absolute_expires_at < ?
            """,
            (now,),
        )

    def _prune_events(self, connection: sqlite3.Connection) -> None:
        connection.execute(
            """
            DELETE FROM audit_events
            WHERE request_id NOT IN (
                SELECT request_id
                FROM audit_events
                ORDER BY created_at DESC
                LIMIT ?
            )
            """,
            (self.max_events,),
        )

    def _prune_access_logs(self, connection: sqlite3.Connection) -> None:
        connection.execute(
            """
            DELETE FROM admin_access_logs
            WHERE id NOT IN (
                SELECT id
                FROM admin_access_logs
                ORDER BY id DESC
                LIMIT ?
            )
            """,
            (self.max_access_logs,),
        )

    def _enrollment_from_row(self, row: sqlite3.Row) -> AdminEnrollmentRecord:
        return AdminEnrollmentRecord(
            device_id=str(row["device_id"]),
            tailscale_login=str(row["tailscale_login"]),
            browser_public_key=str(row["browser_public_key"]),
            approved_role=str(row["approved_role"]) if row["approved_role"] is not None else None,
            approved_at=str(row["approved_at"]) if row["approved_at"] is not None else None,
            last_seen_at=str(row["last_seen_at"]),
            revoked_at=str(row["revoked_at"]) if row["revoked_at"] is not None else None,
        )

    def _event_from_row(self, row: sqlite3.Row) -> AuditEventRecord:
        return AuditEventRecord(
            request_id=str(row["request_id"]),
            created_at=str(row["created_at"]),
            provider=str(row["provider"]),
            endpoint=str(row["endpoint"]),
            model=str(row["model"]) if row["model"] is not None else None,
            stream=bool(row["stream"]),
            outcome=str(row["outcome"]),
            status_code=int(row["status_code"]),
            latency_ms=int(row["latency_ms"]),
            detection_count=int(row["detection_count"]),
            detection_types=dict(json.loads(str(row["detection_types"]))),
            actions=dict(json.loads(str(row["actions"]))),
            placeholder_count=int(row["placeholder_count"]),
            rehydration_count=int(row["rehydration_count"]),
            masked_paths=tuple(json.loads(str(row["masked_paths"]))),
            blocked=bool(row["blocked"]),
            route_local=bool(row["route_local"]),
        )
