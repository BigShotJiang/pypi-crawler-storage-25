from __future__ import annotations

from dataclasses import dataclass

from stronk_gateway.config import Settings
from stronk_gateway.redaction.models import DetectorType, PolicyAction


@dataclass(frozen=True)
class PolicyEngine:
    actions: dict[DetectorType, PolicyAction]

    @classmethod
    def from_settings(cls, settings: Settings) -> PolicyEngine:
        return cls(
            actions={
                DetectorType.EMAIL: _parse_action(settings.email_action),
                DetectorType.PHONE: _parse_action(settings.phone_action),
                DetectorType.BUSINESS_ID: _parse_action(settings.business_id_action),
                DetectorType.PERSON_NAME: _parse_action(settings.person_name_action),
                DetectorType.ORGANIZATION: _parse_action(settings.organization_action),
                DetectorType.ADDRESS: _parse_action(settings.address_action),
                DetectorType.API_KEY: _parse_action(settings.api_key_action),
                DetectorType.BEARER_TOKEN: _parse_action(settings.bearer_token_action),
                DetectorType.JWT: _parse_action(settings.jwt_action),
            }
        )

    def decide(self, detector: DetectorType, path: str) -> PolicyAction:
        if path.startswith("/tools/"):
            return PolicyAction.BLOCK
        return self.actions.get(detector, PolicyAction.BLOCK)


def _parse_action(value: str) -> PolicyAction:
    try:
        return PolicyAction(value.strip().lower())
    except ValueError as error:
        raise ValueError(f"Unsupported policy action: {value}") from error
