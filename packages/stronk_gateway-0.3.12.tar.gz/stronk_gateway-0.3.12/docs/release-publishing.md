# Release Publishing

This document records the current local PyPI publishing path for the `stronk-gateway` runtime repo.

Scope:

- local wheel build and PyPI publish for the current runtime package
- Bitwarden Secrets Manager lookup for `UV_PUBLISH_TOKEN`
- GitHub Actions Trusted Publishing and GHCR release path
- no raw token values written to disk or pasted into chat

Out of scope:

- GHCR image publishing from a local shell
- final multi-repo release orchestration in `stronk-gateway-deploy`

For GHCR, prefer GitHub Actions with `GITHUB_TOKEN`. For PyPI, prefer Trusted Publishing in GitHub Actions and keep the local Bitwarden-backed token flow as a fallback.

## Preferred CI Release Path

The preferred release path is now the GitHub Actions workflow in [publish-release.yml](/Users/eyy/Documents/Work/Dev/repos/stronk-gateway/.github/workflows/publish-release.yml).

Current contract:

- trigger the workflow by pushing a `v*` tag
- the workflow requires the tag version to match `project.version` in `pyproject.toml`
- the workflow runs tests, builds the Python distributions, pushes the multi-arch GHCR image, and publishes to PyPI through Trusted Publishing
- the workflow expects a PyPI Trusted Publisher entry that points at:
  - owner: `EYYCHEEV`
  - repo: `stronk-gateway`
  - workflow file: `.github/workflows/publish-release.yml`
  - environment: `pypi`

## Current Secret Source

The PyPI publish token is currently stored in Bitwarden Secrets Manager under:

- project: `stronk terminal`
- secret key: `UV_PUBLISH_TOKEN`

The local shell must already have a Bitwarden Secrets Manager access token in:

- `BWS_STRONK_TERMINAL_ACCESS_TOKEN`

`bws` itself expects `BWS_ACCESS_TOKEN`, so the publish flow maps the Stronk-specific shell variable into the CLI invocation without rewriting the user shell profile.

For committed docs, prefer `bws run` over `bws secret get`. That keeps raw Bitwarden UUIDs and direct secret-fetch plumbing out of the release guide.

## Prerequisites

- `bws` installed and able to read the Stronk Bitwarden project
- `uv` installed locally
- PyPI token already stored in Bitwarden as the secret above
- publish is run from the `stronk-gateway` repo root

## Local Publish Flow

Use this only as a fallback when GitHub Actions Trusted Publishing is unavailable or when a local manual publish is explicitly required.

1. Move into the repo root:

```bash
cd /Users/eyy/Documents/Work/Dev/repos/stronk-gateway
```

2. Verify the Bitwarden access token shell variable exists:

```bash
[[ -n "$BWS_STRONK_TERMINAL_ACCESS_TOKEN" ]]
```

3. Build the wheel and source distribution:

```bash
uv build
```

4. Publish to PyPI with `UV_PUBLISH_TOKEN` injected by Bitwarden at command runtime:

```bash
BWS_ACCESS_TOKEN="$BWS_STRONK_TERMINAL_ACCESS_TOKEN" \
bws run -- uv publish
```

`bws run` injects accessible secrets into the child process environment by secret key, so `uv publish` receives `UV_PUBLISH_TOKEN` without printing it or writing it to disk.

5. Clear any shell-local `UV_PUBLISH_TOKEN` only if you explicitly exported one for troubleshooting. The normal `bws run` flow does not leave it behind:

```bash
unset UV_PUBLISH_TOKEN
```

## Recommended Verification

Before publishing:

```bash
python3 -m pytest
```

After `uv build`, confirm the expected artifacts exist:

```bash
ls -1 dist/
```

After `uv publish`, verify the new release on PyPI through the project page rather than printing token-backed command output into logs.

## Safety Notes

- Do not paste the PyPI token into chat, shell history notes, or repo docs.
- Do not write the token into `.pypirc`.
- Do not commit generated `dist/` artifacts.
- Prefer `bws run -- uv publish` so the token never needs to be materialized in the parent shell.
- If you temporarily export `UV_PUBLISH_TOKEN` for debugging, unset it after publish.
