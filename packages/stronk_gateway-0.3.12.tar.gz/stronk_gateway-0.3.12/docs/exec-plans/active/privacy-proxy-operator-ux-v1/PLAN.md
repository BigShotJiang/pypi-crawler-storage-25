# Privacy Proxy Operator UX v1

## Objective

Make `stronk-gateway` easy to deploy as a privacy proxy, then provide an authenticated monitoring experience that stays privacy-safe by default.

## Scope

- harden first-run setup for local Docker Compose and single-node deployment
- add a separate admin/control plane with sanitized runtime telemetry
- add a read-only monitoring UI with light and dark mode
- keep the admin plane isolated from caller-facing proxy routes

## Constraints

- no raw request bodies, response bodies, rehydrated text, headers, secrets, or placeholder maps persisted by default
- admin API and UI disabled by default
- admin plane must require trusted identity headers and role checks when enabled
- proxy behavior for OpenAI and Anthropic routes must remain intact
- `route_local` remains fail-closed

## Non-Goals

- browser-based policy editing
- raw transcript inspection or request replay
- multi-node control-plane orchestration
- local-model execution for `route_local`

## UX Direction

### Visual Thesis

A privacy control room with taut typography, low-chrome surfaces, and a warm graphite / porcelain palette that feels precise in both dark and light mode.

### Content Plan

1. Operational overview
2. Live event river
3. Request inspector
4. Setup and readiness rail

### Interaction Thesis

- measured first-load sweep for the overview workspace
- dark/light theme morph without hard flash
- row-to-inspector transitions for event triage

## Task Checklist

- [x] Phase 0: lock the admin-plane boundary and safe event schema
- [x] Phase 1: initialize ExecPlan scaffold and implementation notes
- [x] Phase 2: add sanitized event persistence and proxy-side event emission
- [x] Phase 3: add authenticated admin API and access logging
- [x] Phase 4: build the monitoring UI with dark/light mode and modern visual system
- [x] Phase 5: update Docker/Compose for proxy + admin deployment
- [x] Phase 6: document setup, auth model, and safety guarantees
- [x] Phase 7: verify backend tests, frontend build, and regression coverage

## Validation Gates

- admin endpoints return `401` without trusted identity headers and `403` for disallowed roles
- no raw sensitive values appear in persisted audit rows, admin API payloads, or logs
- proxy regression suite still passes for `/chat/completions`, `/responses`, and `/messages`
- frontend production build succeeds and serves both light and dark mode
- local compose path exposes the proxy and admin plane separately

## Follow-Up Questions

- should the production path ship a documented `oauth2-proxy` reference deployment next, or stay reverse-proxy agnostic for one more cycle?
- should admin access logs gain explicit time-based retention in addition to max-entry pruning?
- should the next phase add a controlled break-glass export path for incident response, or keep the control plane strictly sanitized-only?
