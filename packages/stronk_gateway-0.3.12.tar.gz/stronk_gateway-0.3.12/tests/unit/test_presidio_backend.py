from __future__ import annotations

from stronk_gateway.config import Settings
from stronk_gateway.redaction.detectors import build_detectors
from stronk_gateway.redaction.models import DetectorType, SpanMatch
from stronk_gateway.redaction.presidio_backend import (
    PRESIDIO_ENTITY_MAP,
    PresidioBackendConfig,
    PresidioDetector,
)


class _FakeRecognizerResult:
    def __init__(self, entity_type: str, start: int, end: int) -> None:
        self.entity_type = entity_type
        self.start = start
        self.end = end


class _FakeBackend:
    def analyze(self, *, text: str, language: str) -> list[_FakeRecognizerResult]:
        del text
        if language == "zh":
            return [_FakeRecognizerResult("ORG", 0, 8)]
        return [_FakeRecognizerResult("PERSON", 9, 17)]


def test_presidio_detector_maps_supported_entities(monkeypatch) -> None:
    config = PresidioBackendConfig(
        languages=("en", "zh"),
        english_model="en_core_web_sm",
        chinese_model="zh_core_web_sm",
        score_threshold=0.7,
    )
    monkeypatch.setattr(
        "stronk_gateway.redaction.presidio_backend._load_backend",
        lambda _: _FakeBackend(),
    )
    detector = PresidioDetector(config)
    text = "佛山市川东磁电股份有限公司 YAN YI MIN"

    matches = detector.detect(text)

    assert SpanMatch(
        detector=DetectorType.ORGANIZATION,
        start=0,
        end=8,
        value=text[0:8],
        source="presidio",
    ) in matches
    assert any(item.detector is DetectorType.PERSON_NAME for item in matches)


def test_build_detectors_adds_presidio_when_enabled() -> None:
    settings = Settings(presidio_enabled=True)

    detectors = build_detectors(settings)

    assert any(type(detector).__name__ == "PresidioDetector" for detector in detectors)


def test_presidio_entity_map_stays_narrow() -> None:
    assert PRESIDIO_ENTITY_MAP["PERSON"] is DetectorType.PERSON_NAME
    assert PRESIDIO_ENTITY_MAP["ORG"] is DetectorType.ORGANIZATION


def test_presidio_detector_ignores_matches_inside_file_paths(monkeypatch) -> None:
    class _PathBackend:
        def analyze(self, *, text: str, language: str) -> list[_FakeRecognizerResult]:
            del language
            start = text.index("SIGNED")
            return [_FakeRecognizerResult("ORG", start, start + len("SIGNED"))]

    config = PresidioBackendConfig(
        languages=("en",),
        english_model="en_core_web_sm",
        chinese_model="zh_core_web_sm",
        score_threshold=0.7,
    )
    monkeypatch.setattr(
        "stronk_gateway.redaction.presidio_backend._load_backend",
        lambda _: _PathBackend(),
    )
    detector = PresidioDetector(config)

    matches = detector.detect("Read /Users/eyy/Downloads/委托书_SIGNED.pdf")

    assert matches == []
