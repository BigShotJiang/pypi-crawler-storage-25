from __future__ import annotations

import asyncio
import json

from stronk_gateway.proxy.sse import SSERehydrator
from stronk_gateway.redaction.models import DetectorType, PlaceholderVault


async def _collect_async_bytes(rehydrator: SSERehydrator, chunks: list[bytes]) -> str:
    async def iterator():
        for chunk in chunks:
            yield chunk

    parts: list[bytes] = []
    async for chunk in rehydrator.transform(iterator()):
        parts.append(chunk)
    return b"".join(parts).decode("utf-8")


def test_sse_rehydrates_placeholder_split_across_events() -> None:
    vault = PlaceholderVault(occupied_text="")
    placeholder = vault.issue_placeholder(DetectorType.EMAIL, "alice@example.com")
    half = len(placeholder) // 2
    first = json.dumps(
        {"choices": [{"delta": {"content": f"hello {placeholder[:half]}"}}]},
        ensure_ascii=False,
    )
    second = json.dumps(
        {"choices": [{"delta": {"content": f"{placeholder[half:]} done"}}]},
        ensure_ascii=False,
    )
    rehydrator = SSERehydrator(vault)

    output = asyncio.run(
        _collect_async_bytes(
            rehydrator,
            [f"data: {first}\n\n".encode(), f"data: {second}\n\n".encode()],
        )
    )

    assert "alice@example.com" in output
    assert placeholder not in output


def test_sse_rehydrates_placeholder_split_after_first_bracket() -> None:
    vault = PlaceholderVault(occupied_text="")
    placeholder = vault.issue_placeholder(DetectorType.EMAIL, "alice@example.com")
    rehydrator = SSERehydrator(vault)
    first = json.dumps(
        {"choices": [{"delta": {"content": f"hello {placeholder[:1]}"}}]},
        ensure_ascii=False,
    )
    second = json.dumps(
        {"choices": [{"delta": {"content": f"{placeholder[1:]} done"}}]},
        ensure_ascii=False,
    )

    output = asyncio.run(
        _collect_async_bytes(
            rehydrator,
            [f"data: {first}\n\n".encode(), f"data: {second}\n\n".encode()],
        )
    )

    assert "alice@example.com" in output
    assert placeholder not in output


def test_sse_keeps_normal_underscore_tails_intact() -> None:
    vault = PlaceholderVault(occupied_text="")
    vault.issue_placeholder(DetectorType.EMAIL, "alice@example.com")
    rehydrator = SSERehydrator(vault)

    output = asyncio.run(
        _collect_async_bytes(
            rehydrator,
            [b'data: {"choices":[{"delta":{"content":"value__"}}]}\n\n'],
        )
    )

    assert "value__" in output


def test_sse_rehydrator_bounds_debug_capture_to_tail() -> None:
    vault = PlaceholderVault(occupied_text="")
    placeholder = vault.issue_placeholder(DetectorType.EMAIL, "alice@example.com")
    rehydrator = SSERehydrator(vault, capture_limit_bytes=48)
    first = json.dumps(
        {"choices": [{"delta": {"content": f"prefix-{placeholder}-"}}]},
        ensure_ascii=False,
    )
    second = json.dumps(
        {"choices": [{"delta": {"content": "suffix-tail"}}]},
        ensure_ascii=False,
    )

    output = asyncio.run(
        _collect_async_bytes(
            rehydrator,
            [f"data: {first}\n\n".encode(), f"data: {second}\n\n".encode()],
        )
    )

    assert "alice@example.com" in output
    assert rehydrator.rehydrated_stream_text.startswith("[truncated ")
    assert "suffix-tail" in rehydrator.rehydrated_stream_text
