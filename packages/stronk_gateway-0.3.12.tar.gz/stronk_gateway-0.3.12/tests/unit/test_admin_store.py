from __future__ import annotations

from stronk_gateway.admin.models import AdminAccessRecord
from stronk_gateway.admin.store import AuditStore


def test_access_log_retention_prunes_old_entries(tmp_path) -> None:
    store = AuditStore(str(tmp_path / "audit.sqlite3"), max_access_logs=3, prune_interval=1)

    for index in range(5):
        store.record_access(
            AdminAccessRecord(
                created_at=f"2026-03-27T00:00:0{index}Z",
                actor=f"operator-{index}",
                roles=("operator",),
                path=f"/api/events/{index}",
                method="GET",
                status_code=200,
                source_ip=f"10.0.0.{index}",
            )
        )

    records = store.list_access_logs(limit=10)

    assert len(records) == 3
    assert [record.actor for record in records] == ["operator-4", "operator-3", "operator-2"]


def test_session_store_replaces_previous_user_session_and_expires_idle_sessions(tmp_path) -> None:
    store = AuditStore(str(tmp_path / "audit.sqlite3"), prune_interval=1)

    store.replace_user_session(
        token_hash="token-a",
        user="operator",
        roles=("admin", "operator"),
        device_id=None,
        auth_binding="binding-a",
        created_at=1_000,
        absolute_expires_at=2_000,
    )
    store.replace_user_session(
        token_hash="token-b",
        user="operator",
        roles=("admin", "operator"),
        device_id=None,
        auth_binding="binding-b",
        created_at=1_100,
        absolute_expires_at=2_000,
    )

    assert store.get_session("token-a", idle_ttl_seconds=600, now=1_101) is None

    active = store.get_session("token-b", idle_ttl_seconds=600, now=1_200)
    expired = store.get_session("token-b", idle_ttl_seconds=600, now=1_900)

    assert active is not None
    assert active.user == "operator"
    assert active.roles == ("admin", "operator")
    assert active.auth_binding == "binding-b"
    assert expired is None


def test_session_store_keeps_distinct_device_bound_sessions(tmp_path) -> None:
    store = AuditStore(str(tmp_path / "audit.sqlite3"), prune_interval=1)

    store.replace_user_session(
        token_hash="token-device-a",
        user="alice@example.com",
        roles=("operator",),
        device_id="device-a",
        auth_binding="binding-device-a",
        created_at=1_000,
        absolute_expires_at=3_000,
    )
    store.replace_user_session(
        token_hash="token-device-b",
        user="alice@example.com",
        roles=("operator",),
        device_id="device-b",
        auth_binding="binding-device-b",
        created_at=1_100,
        absolute_expires_at=3_000,
    )

    session_a = store.get_session("token-device-a", idle_ttl_seconds=600, now=1_200)
    session_b = store.get_session("token-device-b", idle_ttl_seconds=600, now=1_200)

    assert session_a is not None
    assert session_b is not None
    assert session_a.device_id == "device-a"
    assert session_b.device_id == "device-b"


def test_enrollment_approval_and_revocation_invalidate_device_sessions(tmp_path) -> None:
    store = AuditStore(str(tmp_path / "audit.sqlite3"), prune_interval=1)

    requested = store.upsert_enrollment_request(
        device_id="device-a",
        tailscale_login="alice@example.com",
        browser_public_key="browser-key",
        last_seen_at="2026-03-30T20:00:00Z",
    )

    assert requested.is_approved is False
    assert requested.revoked_at is None

    approved = store.approve_enrollment(
        device_id="device-a",
        approved_role="operator",
        approved_at="2026-03-30T20:05:00Z",
    )

    assert approved is not None
    assert approved.is_approved is True
    assert approved.approved_role == "operator"

    store.replace_user_session(
        token_hash="token-device-a",
        user="alice@example.com",
        roles=("operator",),
        device_id="device-a",
        auth_binding="binding-device-a",
        created_at=2_000,
        absolute_expires_at=4_000,
    )

    active = store.get_session("token-device-a", idle_ttl_seconds=600, now=2_100)
    assert active is not None

    revoked = store.revoke_enrollment(
        device_id="device-a",
        revoked_at="2026-03-30T20:10:00Z",
    )

    assert revoked is not None
    assert revoked.revoked_at == "2026-03-30T20:10:00Z"
    assert store.get_session("token-device-a", idle_ttl_seconds=600, now=2_101) is None
