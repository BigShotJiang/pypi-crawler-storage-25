from __future__ import annotations

from stronk_gateway.config import Settings
from stronk_gateway.policy.engine import PolicyEngine
from stronk_gateway.providers import OPENAI_CHAT_COMPLETIONS
from stronk_gateway.redaction.pipeline import RedactionEngine
from stronk_gateway.security.audit import build_audit_event, build_audit_summary


def test_audit_summary_never_exposes_plaintext_values() -> None:
    engine = RedactionEngine(policy=PolicyEngine.from_settings(Settings()))
    result = engine.redact_payload({"message": "email alice@example.com"})
    summary = build_audit_summary(result)

    assert summary["masked"] is True
    assert summary["detection_types"] == {"email": 1}
    assert "alice@example.com" not in str(summary)


def test_audit_event_record_stays_sanitized() -> None:
    engine = RedactionEngine(policy=PolicyEngine.from_settings(Settings()))
    result = engine.redact_payload({"message": "email alice@example.com"})
    event = build_audit_event(
        request_id="req_1",
        spec=OPENAI_CHAT_COMPLETIONS,
        payload={"model": "gpt-4.1", "message": "email alice@example.com"},
        result=result,
        status_code=200,
        stream=False,
        latency_ms=12,
        rehydration_count=1,
    )

    payload = event.to_payload()
    assert payload["endpoint"] == "/v1/chat/completions"
    assert payload["detection_types"] == {"email": 1}
    assert payload["masked_paths"] == ["/message"]
    assert "alice@example.com" not in str(payload)


def test_audit_event_sanitizes_model_and_json_keys() -> None:
    engine = RedactionEngine(policy=PolicyEngine.from_settings(Settings()))
    result = engine.redact_payload({"metadata": {"customer_email": "alice@example.com"}})
    secret_like_model = "sk-proj-abcdefghijklmnopqrstuvwxyz123456"
    event = build_audit_event(
        request_id="req_2",
        spec=OPENAI_CHAT_COMPLETIONS,
        payload={"model": secret_like_model, "metadata": {"customer_email": "alice@example.com"}},
        result=result,
        status_code=200,
        stream=False,
        latency_ms=8,
    )

    payload = event.to_payload()
    assert payload["model"] == "<redacted-model>"
    assert payload["masked_paths"] == ["/metadata/{key}"]
    assert secret_like_model not in str(payload)
    assert "customer_email" not in str(payload)


def test_audit_event_marks_upstream_rejection_distinctly() -> None:
    engine = RedactionEngine(policy=PolicyEngine.from_settings(Settings()))
    result = engine.redact_payload({"message": "email alice@example.com"})
    event = build_audit_event(
        request_id="req_3",
        spec=OPENAI_CHAT_COMPLETIONS,
        payload={"model": "gpt-4.1", "message": "email alice@example.com"},
        result=result,
        status_code=429,
        stream=False,
        latency_ms=15,
    )

    assert event.outcome == "upstream_rejection"
