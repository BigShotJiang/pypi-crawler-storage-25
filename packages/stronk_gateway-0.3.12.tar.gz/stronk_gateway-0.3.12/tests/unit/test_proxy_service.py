from __future__ import annotations

import asyncio
import json
import sqlite3
import time

from stronk_gateway.config import Settings
from stronk_gateway.providers import OPENAI_CHAT_COMPLETIONS, OPENAI_RESPONSES
from stronk_gateway.proxy.responses_ws import ResponsesWebsocketCheckpoint, ResponsesWebsocketSession
from stronk_gateway.proxy.service import ProxyService, _WebSocketReceiveCoordinator


class FakeWebSocket:
    def __init__(self, *, headers: dict[str, str], messages: list[dict[str, object]]) -> None:
        self.headers = headers
        self._messages = list(messages)
        self.accept_headers: list[tuple[bytes, bytes]] | None = None
        self.sent_texts: list[str] = []
        self.closed_code: int | None = None

    async def accept(self, headers: list[tuple[bytes, bytes]] | None = None) -> None:
        self.accept_headers = headers

    async def receive(self) -> dict[str, object]:
        if self._messages:
            return self._messages.pop(0)
        return {"type": "websocket.disconnect", "code": 1000}

    async def send_text(self, text: str) -> None:
        self.sent_texts.append(text)

    async def close(self, code: int = 1000) -> None:
        self.closed_code = code


class FailingRedaction:
    def redact_payload(self, payload: object) -> object:
        raise AssertionError("oversized websocket frames must be rejected before redaction")


class FailingSession:
    def checkpoint(self) -> ResponsesWebsocketCheckpoint:
        return ResponsesWebsocketCheckpoint(
            last_request=None,
            last_completed_output=[],
            last_response_id=None,
            last_response_local=False,
        )

    def release_owner(self, owner_token: str) -> None:
        return None

    def normalize(self, raw_text: str) -> object:
        raise AssertionError(
            "oversized websocket frames must be rejected before parse/session mutation"
        )


def test_websocket_oversized_frame_is_rejected_before_parse_redaction_and_session_mutation() -> (
    None
):
    service = ProxyService(
        Settings(
            openai_upstream_base_url="http://openai.test",
            allow_insecure_upstreams=True,
            allow_nonstandard_upstream_hosts=True,
            websocket_frame_byte_cap=1024,
        )
    )
    service.redaction = FailingRedaction()  # type: ignore[assignment]
    service._resolve_websocket_session = lambda websocket: (  # type: ignore[method-assign]
        "turn-oversized-1",
        FailingSession(),
        "owner-oversized-1",
    )
    oversized_frame = json.dumps(
        {
            "type": "response.create",
            "model": "gpt-4.1",
            "input": [
                {
                    "role": "user",
                    "content": [{"type": "input_text", "text": "x" * 2_000}],
                }
            ],
        }
    )
    websocket = FakeWebSocket(
        headers={},
        messages=[{"type": "websocket.receive", "text": oversized_frame}],
    )

    asyncio.run(service.handle_responses_websocket(websocket, OPENAI_RESPONSES))

    error = json.loads(websocket.sent_texts[0])
    assert error["type"] == "error"
    assert error["status"] == 413
    assert error["error"]["type"] == "invalid_websocket_frame"
    assert websocket.closed_code == 1009


def test_websocket_rejects_invalid_turn_state_header() -> None:
    service = ProxyService(
        Settings(
            openai_upstream_base_url="http://openai.test",
            allow_insecure_upstreams=True,
            allow_nonstandard_upstream_hosts=True,
        )
    )
    websocket = FakeWebSocket(headers={"x-codex-turn-state": "bad value!"}, messages=[])

    asyncio.run(service.handle_responses_websocket(websocket, OPENAI_RESPONSES))

    error = json.loads(websocket.sent_texts[0])
    assert error["type"] == "error"
    assert error["status"] == 400
    assert error["error"]["type"] == "invalid_websocket_turn"
    assert websocket.closed_code == 1008


def test_websocket_session_cap_is_rejected_without_eviction() -> None:
    service = ProxyService(
        Settings(
            openai_upstream_base_url="http://openai.test",
            allow_insecure_upstreams=True,
            allow_nonstandard_upstream_hosts=True,
            websocket_active_session_cap=1,
        )
    )
    existing_session = ResponsesWebsocketSession()
    service.websocket_turn_sessions["turn-existing-1"] = existing_session
    websocket = FakeWebSocket(headers={"x-codex-turn-state": "turn-new-1"}, messages=[])

    asyncio.run(service.handle_responses_websocket(websocket, OPENAI_RESPONSES))

    error = json.loads(websocket.sent_texts[0])
    assert error["type"] == "error"
    assert error["status"] == 503
    assert error["error"]["type"] == "invalid_websocket_turn"
    assert websocket.closed_code == 1008
    assert service.websocket_turn_sessions == {"turn-existing-1": existing_session}


class QueueWebSocket:
    def __init__(self) -> None:
        self._messages: asyncio.Queue[dict[str, object]] = asyncio.Queue()

    async def receive(self) -> dict[str, object]:
        return await self._messages.get()

    async def push(self, message: dict[str, object]) -> None:
        await self._messages.put(message)


def test_receive_coordinator_marks_active_turn_overlap_as_turn_signal() -> None:
    async def run() -> None:
        websocket = QueueWebSocket()
        coordinator = _WebSocketReceiveCoordinator(websocket, idle_timeout_seconds=0.1)
        await coordinator.start()
        try:
            await websocket.push(
                {
                    "type": "websocket.receive",
                    "text": '{"type":"response.create","model":"gpt-4.1"}',
                }
            )
            first_message = await coordinator.receive_turn_input()
            assert first_message["type"] == "websocket.receive"

            await websocket.push(
                {
                    "type": "websocket.receive",
                    "text": '{"type":"response.create","model":"gpt-4.1","input":[]}',
                }
            )
            await asyncio.sleep(0)

            turn_signal = coordinator.turn_signal()
            assert turn_signal is not None
            assert turn_signal.message["type"] == "websocket.receive"
        finally:
            coordinator.finish_turn()
            await coordinator.close()

    asyncio.run(run())


def test_receive_coordinator_reuses_pending_receive_for_next_turn_input() -> None:
    async def run() -> None:
        websocket = QueueWebSocket()
        coordinator = _WebSocketReceiveCoordinator(websocket, idle_timeout_seconds=0.1)
        await coordinator.start()
        try:
            await websocket.push(
                {
                    "type": "websocket.receive",
                    "text": '{"type":"response.create","model":"gpt-4.1"}',
                }
            )
            await coordinator.receive_turn_input()

            await websocket.push(
                {
                    "type": "websocket.receive",
                    "text": '{"type":"response.create","model":"gpt-4.1","input":[]}',
                }
            )
            await asyncio.sleep(0)
            coordinator.finish_turn()

            next_message = await coordinator.receive_turn_input()
            assert next_message["type"] == "websocket.receive"
            assert next_message["text"] == '{"type":"response.create","model":"gpt-4.1","input":[]}'
            assert coordinator.turn_signal() is None
        finally:
            coordinator.finish_turn()
            await coordinator.close()

    asyncio.run(run())


def test_audit_worker_retries_transient_flush_failure_without_losing_event(tmp_path) -> None:
    async def run() -> None:
        service = ProxyService(
            Settings(
                openai_upstream_base_url="http://openai.test",
                allow_insecure_upstreams=True,
                allow_nonstandard_upstream_hosts=True,
                audit_storage_enabled=True,
                audit_db_path=str(tmp_path / "audit.sqlite3"),
            )
        )
        assert service.audit_store is not None

        calls = {"count": 0}
        original_record_event_batch = service.audit_store.record_event_batch

        def flaky_record_event_batch(events):
            calls["count"] += 1
            if calls["count"] == 1:
                raise sqlite3.OperationalError("database is locked")
            return original_record_event_batch(events)

        service.audit_store.record_event_batch = flaky_record_event_batch  # type: ignore[method-assign]

        await service.startup()
        try:
            service._record_event(
                request_id="req-retry-1",
                spec=OPENAI_CHAT_COMPLETIONS,
                payload={"messages": [{"role": "user", "content": "Alice alice@example.com"}]},
                result=None,
                stream=False,
                status_code=200,
                started_at=time.perf_counter(),
            )
        finally:
            await service.shutdown()

        assert calls["count"] >= 2
        events = service.audit_store.list_events(limit=10)
        assert [event.request_id for event in events] == ["req-retry-1"]

    asyncio.run(run())
