from __future__ import annotations

import json
from pathlib import Path

import httpx

from tests.helpers import (
    StaticAsyncByteStream,
    build_runtime_clients,
    build_test_client,
    contains_placeholder,
    eventually,
)
from tests.integration.test_admin_plane import build_admin_client, login_admin

ADMIN_PROXY_SECRET = "test-admin-proxy-secret"
DEBUG_GATEWAY_SECRET = "test-unsafe-debug-gateway-secret"
ADMIN_HEADERS = {
    "X-Stronk-Admin-User": "operator",
    "X-Stronk-Admin-Roles": "operator",
    "X-Stronk-Admin-Proxy-Secret": ADMIN_PROXY_SECRET,
    "X-Stronk-Unsafe-Debug-Gateway": DEBUG_GATEWAY_SECRET,
}


def test_proxy_debug_api_requires_admin_headers(tmp_path: Path) -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(200, json={"ok": True}),
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
    )

    response = client.get("/api/debug/traces")

    assert response.status_code == 404


def test_public_runtime_app_does_not_mount_debug_routes(tmp_path: Path) -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-runtime-1",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": masked_text},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    with build_runtime_clients(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
    ) as (public_client, debug_client, _transport):
        assert public_client.app.title == "Stronk Gateway"
        assert debug_client.app.title == "Stronk Gateway Debug Bridge"

        response = public_client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4.1",
                "messages": [{"role": "user", "content": "Please contact Alice Johnson"}],
            },
        )

        assert response.status_code == 200
        assert debug_client.get("/health").json()["app"] == "Stronk Gateway"
        assert public_client.get("/api/debug/traces", headers=ADMIN_HEADERS).status_code == 404
        traces = debug_client.get("/api/debug/traces", headers=ADMIN_HEADERS)
        assert traces.status_code == 200
        assert len(traces.json()["items"]) == 1


def test_proxy_debug_api_exposes_http_before_after_when_enabled(tmp_path: Path) -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-1",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    client, _ = build_test_client(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
    )
    original = "Please contact Alice Johnson at alice@example.com"

    response = client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": original}]},
    )

    assert response.status_code == 200

    traces = client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    assert traces.status_code == 200
    request_id = traces.json()["items"][0]["request_id"]

    detail = client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    assert detail.status_code == 200
    assert detail.headers["cache-control"] == "no-store, private, max-age=0"
    assert detail.headers["pragma"] == "no-cache"
    assert detail.headers["expires"] == "0"
    payload = detail.json()
    assert payload["request_original"]["messages"][0]["content"] == original
    assert "Alice Johnson" not in json.dumps(payload["request_masked"], ensure_ascii=False)
    assert "alice@example.com" not in json.dumps(payload["request_masked"], ensure_ascii=False)
    assert contains_placeholder(json.dumps(payload["request_masked"], ensure_ascii=False))
    assert contains_placeholder(json.dumps(payload["response_upstream"], ensure_ascii=False))
    assert payload["response_rehydrated"]["choices"][0]["message"]["content"] == f"Echo: {original}"


def test_proxy_debug_api_exposes_websocket_before_after_when_enabled(tmp_path: Path) -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["input"][0]["content"][0]["text"]
        chunks = [
            (
                "data: "
                + json.dumps(
                    {"type": "response.output_text.delta", "delta": masked_text},
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {
                            "id": "resp_debug_1",
                            "output": [
                                {
                                    "type": "message",
                                    "content": [
                                        {
                                            "type": "output_text",
                                            "text": masked_text,
                                        }
                                    ],
                                }
                            ],
                        },
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, _ = build_test_client(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
    )
    original = "请联系张三，邮箱是 zhangsan@example.com"

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [
                        {
                            "role": "user",
                            "content": [{"type": "input_text", "text": original}],
                        }
                    ],
                },
                ensure_ascii=False,
            )
        )
        _ = json.loads(websocket.receive_text())
        _ = json.loads(websocket.receive_text())

    traces = client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    request_id = traces.json()["items"][0]["request_id"]
    detail = client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    assert detail.status_code == 200
    payload = detail.json()
    assert payload["request_original"]["type"] == "response.create"
    assert payload["request_original"]["input"][0]["content"][0]["text"] == original
    assert contains_placeholder(json.dumps(payload["request_masked"], ensure_ascii=False))
    assert contains_placeholder(payload["response_upstream"])
    assert original in payload["response_rehydrated"]
    assert "resp_debug_1" in payload["response_rehydrated"]


def test_proxy_debug_api_records_masked_payload_for_blocked_http_requests(tmp_path: Path) -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(200, json={"ok": True}),
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
    )

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4.1",
            "messages": [{"role": "user", "content": "Use sk-1234567890abcdef1234567890abcdef"}],
        },
    )

    assert response.status_code == 422

    traces = client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    request_id = traces.json()["items"][0]["request_id"]
    detail = client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    assert detail.status_code == 200
    payload = detail.json()
    assert payload["request_masked"] is not None
    assert contains_placeholder(json.dumps(payload["request_masked"], ensure_ascii=False))


def test_proxy_debug_api_records_masked_payload_for_route_local_http_requests(
    tmp_path: Path,
) -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(200, json={"ok": True}),
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
        phone_action="route_local",
    )

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4.1",
            "messages": [{"role": "user", "content": "Call me at +1 415 555 2671"}],
        },
    )

    assert response.status_code == 503

    traces = client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    request_id = traces.json()["items"][0]["request_id"]
    detail = client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    assert detail.status_code == 200
    payload = detail.json()
    assert payload["request_masked"] is not None
    assert contains_placeholder(json.dumps(payload["request_masked"], ensure_ascii=False))


def test_proxy_debug_api_truncates_large_json_response_capture(tmp_path: Path) -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        masked_text = json.loads(body)["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-large-json",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text * 24}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    client, _ = build_test_client(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
        unsafe_debug_body_capture_bytes=256,
    )
    original = "Alice Johnson alice@example.com"

    response = client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": original}]},
    )

    assert response.status_code == 200
    assert response.json()["choices"][0]["message"]["content"] == f"Echo: {original * 24}"

    traces = client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    request_id = traces.json()["items"][0]["request_id"]
    detail = client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    payload = detail.json()
    assert isinstance(payload["response_upstream"], str)
    assert isinstance(payload["response_rehydrated"], str)
    assert payload["response_upstream"].startswith("[truncated ")
    assert payload["response_rehydrated"].startswith("[truncated ")


def test_proxy_debug_api_truncates_large_text_response_capture(tmp_path: Path) -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        masked_text = json.loads(body)["messages"][0]["content"]
        return httpx.Response(
            200,
            text=f"Echo: {masked_text * 24}",
            headers={"content-type": "text/plain"},
        )

    client, _ = build_test_client(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
        unsafe_debug_body_capture_bytes=256,
    )
    original = "Call Alice Johnson at alice@example.com"

    response = client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": original}]},
    )

    assert response.status_code == 200
    assert response.text == f"Echo: {original * 24}"

    traces = client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    request_id = traces.json()["items"][0]["request_id"]
    detail = client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    payload = detail.json()
    assert isinstance(payload["response_upstream"], str)
    assert isinstance(payload["response_rehydrated"], str)
    assert payload["response_upstream"].startswith("[truncated ")
    assert payload["response_rehydrated"].startswith("[truncated ")


def test_proxy_debug_api_truncates_long_websocket_stream_capture(tmp_path: Path) -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["input"][0]["content"][0]["text"]
        chunks = [
            (
                "data: "
                + json.dumps(
                    {"type": "response.output_text.delta", "delta": masked_text * 16},
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {
                            "id": "resp_debug_tail_1",
                            "output": [
                                {
                                    "type": "message",
                                    "content": [
                                        {
                                            "type": "output_text",
                                            "text": masked_text * 16,
                                        }
                                    ],
                                }
                            ],
                        },
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, _ = build_test_client(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(tmp_path / "audit.sqlite3"),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
        unsafe_debug_stream_tail_bytes=256,
    )
    original = "请联系张三，邮箱是 zhangsan@example.com"

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [
                        {
                            "role": "user",
                            "content": [{"type": "input_text", "text": original}],
                        }
                    ],
                },
                ensure_ascii=False,
            )
        )
        delta = json.loads(websocket.receive_text())
        completed = json.loads(websocket.receive_text())

    assert delta["delta"] == original * 16
    assert completed["response"]["output"][0]["content"][0]["text"] == original * 16

    traces = client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    request_id = traces.json()["items"][0]["request_id"]
    detail = client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    payload = detail.json()
    assert isinstance(payload["response_upstream"], str)
    assert isinstance(payload["response_rehydrated"], str)
    assert payload["response_upstream"].startswith("[truncated ")
    assert payload["response_rehydrated"].startswith("[truncated ")
    assert "[DONE]" in payload["response_rehydrated"]


def test_proxy_debug_api_reads_appear_in_admin_access_logs(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.sqlite3"

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-1",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": masked_text},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    proxy_client, _ = build_test_client(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(db_path),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
    )
    proxy_client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4.1",
            "messages": [{"role": "user", "content": "Alice Johnson alice@example.com"}],
        },
    )

    traces = proxy_client.get("/api/debug/traces", headers=ADMIN_HEADERS)
    request_id = traces.json()["items"][0]["request_id"]
    detail = proxy_client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)

    assert traces.status_code == 200
    assert detail.status_code == 200

    admin_client = build_admin_client(db_path)
    login_admin(admin_client)
    config = eventually(
        lambda: admin_client.get("/api/config"),
        predicate=lambda response: (
            response.status_code == 200
            and "/api/debug/traces" in [entry["path"] for entry in response.json()["recent_access"]]
            and f"/api/debug/traces/{request_id}"
            in [entry["path"] for entry in response.json()["recent_access"]]
        ),
    )
    recent_paths = [entry["path"] for entry in config.json()["recent_access"]]

    assert "/api/debug/traces" in recent_paths
    assert f"/api/debug/traces/{request_id}" in recent_paths


def test_proxy_debug_api_ignores_forwarded_for_when_recording_access_logs(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.sqlite3"

    proxy_client, _ = build_test_client(
        lambda request, body: httpx.Response(200, json={"ok": True}),
        audit_storage_enabled=True,
        audit_db_path=str(db_path),
        enable_unsafe_debug_view=True,
        admin_proxy_secret=ADMIN_PROXY_SECRET,
        unsafe_debug_gateway_secret=DEBUG_GATEWAY_SECRET,
    )

    response = proxy_client.get(
        "/api/debug/traces",
        headers={
            **ADMIN_HEADERS,
            "X-Forwarded-For": "203.0.113.9",
        },
    )

    assert response.status_code == 200

    admin_client = build_admin_client(db_path)
    login_admin(admin_client)
    config = eventually(
        lambda: admin_client.get("/api/config"),
        predicate=lambda result: (
            result.status_code == 200
            and any(
                entry["path"] == "/api/debug/traces" for entry in result.json()["recent_access"]
            )
        ),
    )
    debug_access = next(
        entry for entry in config.json()["recent_access"] if entry["path"] == "/api/debug/traces"
    )

    assert debug_access["source_ip"] != "203.0.113.9"
