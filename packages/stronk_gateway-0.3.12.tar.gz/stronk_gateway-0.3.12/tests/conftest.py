from __future__ import annotations

import os
from collections.abc import Iterator

import pytest

from stronk_gateway.config import Settings


@pytest.fixture(autouse=True)
def isolate_settings_from_local_env(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    original_env_file = Settings.model_config.get("env_file")
    Settings.model_config["env_file"] = None
    for key in list(os.environ):
        if key.startswith("STRONK_GATEWAY_") or key.startswith("PROVIDER_"):
            monkeypatch.delenv(key, raising=False)
    yield
    Settings.model_config["env_file"] = original_env_file
