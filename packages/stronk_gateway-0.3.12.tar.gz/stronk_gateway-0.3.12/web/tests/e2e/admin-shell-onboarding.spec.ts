import { expect, test, type Page } from "@playwright/test";

import type {
  AccessSummary,
  ApplyJobSummary,
  ConfigSummary,
  ModelAliasInput,
  ModelSummary,
  OperatorStateSummary,
  Overview,
  PolicySummary,
  ProviderDraftInput,
  ProviderSummary,
  SessionSummary,
  SystemSummary,
} from "../../src/types";

const PROVIDER_ID = "openai-production";
const PROVIDER_LABEL = "OpenAI Production";
const PROVIDER_BASE_URL = "https://api.openai.com/v1";
const PROVIDER_SECRET_REF = "PROVIDER_OPENAI_API_KEY";
const UPSTREAM_MODEL_ID = "gpt-4.1";
const PUBLIC_ALIAS = "stronk-lm";
const PRIVACY_POLICY_ID = "default";
const SESSION_USERNAME = "operator";
const SESSION_PASSWORD = "not-a-secret";
const LIVE_TIME = "2026-04-03T18:10:00Z";

type Stage = "initial" | "provider-created" | "model-published" | "applied";

type MockAdminState = {
  loggedIn: boolean;
  stage: Stage;
  loginPayload: { username: string; password: string } | null;
  providerPayload: ProviderDraftInput | null;
  modelPayload: ModelAliasInput | null;
  calls: {
    session: number;
    login: number;
    overview: number;
    config: number;
    providers: number;
    models: number;
    policy: number;
    access: number;
    system: number;
    events: number;
    operatorState: number;
    createProvider: number;
    verifyProvider: number;
    discoverProvider: number;
    createModel: number;
    applyStart: number;
    applyPoll: number;
  };
};

function buildSession(): SessionSummary {
  return {
    viewer: {
      user: SESSION_USERNAME,
      roles: ["admin"],
    },
    auth_mode: "session",
    access_mode: "loopback",
    trace_access: true,
    trace_allowed_roles: ["admin"],
    content_trace_enabled: true,
    device_id: null,
    trusted_proxy_login: null,
    session_secure_cookies: false,
  };
}

function buildConfig(): ConfigSummary {
  return {
    app_name: "Stronk Gateway",
    app_env: "e2e",
    proxy_surfaces: ["admin-ui", "hermes"],
    control_plane: {
      admin_api_enabled: true,
      admin_ui_enabled: true,
      audit_storage_enabled: true,
      ui_built: true,
      content_trace_enabled: true,
      content_trace_ttl_seconds: 300,
    },
    upstreams: {
      openai_host: "https://api.openai.com",
      anthropic_host: "https://api.anthropic.com",
      allow_insecure_upstreams: false,
      allow_nonstandard_upstream_hosts: false,
    },
    policy_actions: {
      redact: "Redact content in-place",
      block: "Block the request",
    },
    auth: {
      auth_mode: "session",
      allowed_roles: ["admin"],
      trace_allowed_roles: ["admin"],
      session_cookie_name: "stronk_admin_session",
      session_secure_cookies: false,
      viewer: {
        user: SESSION_USERNAME,
        roles: ["admin"],
      },
      trace_access: true,
    },
    access: {
      mode: "loopback",
      http_bind: "127.0.0.1",
      http_port: 8080,
      allowed_origins: ["http://127.0.0.1:8788"],
      trusted_proxy_mode: "disabled",
      enrollment_required: false,
    },
    gateway_artifacts: {
      artifact_dir: "/var/lib/stronk-gateway",
      schema_version: "2026-04-03",
      warnings: [],
    },
    warnings: [],
    recent_access: [],
  };
}

function buildProviderSummary(stage: Stage): ProviderSummary {
  const hasProvider = stage !== "initial";
  return {
    schema_version: "2026-04-03",
    artifact_dir: "/var/lib/stronk-gateway",
    materialization_required: stage !== "applied",
    last_materialized_at: stage === "applied" ? LIVE_TIME : null,
    last_doctor_generated_at: stage === "applied" ? LIVE_TIME : null,
    last_doctor_status: stage === "applied" ? "healthy" : "warning",
    warnings: [],
    items: hasProvider
      ? [
          {
            label: PROVIDER_LABEL,
            readiness_posture: stage === "applied" ? "ready" : "pending",
            auth_source_type: "env",
            materialized_at: stage === "applied" ? LIVE_TIME : null,
          },
        ]
      : [],
  };
}

function buildModelSummary(stage: Stage): ModelSummary {
  return {
    schema_version: "2026-04-03",
    artifact_dir: "/var/lib/stronk-gateway",
    materialization_required: stage !== "applied",
    last_materialized_at: stage === "applied" ? LIVE_TIME : null,
    recommended_model_aliases: stage === "applied" ? [PUBLIC_ALIAS] : [],
    warnings: [],
    items: stage === "applied"
      ? [
          {
            public_alias: PUBLIC_ALIAS,
            backend_id: UPSTREAM_MODEL_ID,
            endpoint_id: PROVIDER_ID,
            readiness_posture: "ready",
            fallback_note: null,
            recommended_for_hermes: true,
          },
        ]
      : [],
  };
}

function buildOverview(stage: Stage): Overview {
  const providerReady = stage === "initial" ? 0 : 1;
  const modelReady = stage === "applied" ? 1 : 0;
  const providerTotal = stage === "initial" ? 0 : 1;
  const modelTotal = stage === "initial" ? 0 : 1;

  return {
    total_requests: 0,
    masked_requests: 0,
    blocked_requests: 0,
    route_local_requests: 0,
    rehydrated_responses: 0,
    error_requests: 0,
    provider_counts: {},
    detector_counts: {},
    action_counts: {},
    last_event_at: null,
    gateway: {
      schema_version: "2026-04-03",
      artifact_dir: "/var/lib/stronk-gateway",
      warnings: [],
      provider_summary: {
        ready: providerReady,
        total: providerTotal,
        last_materialized_at: stage === "applied" ? LIVE_TIME : null,
      },
      model_summary: {
        ready: modelReady,
        total: modelTotal,
        recommended_aliases: stage === "applied" ? [PUBLIC_ALIAS] : [],
      },
      doctor: {
        status: stage === "applied" ? "healthy" : "warn",
        private_surface_posture: stage === "applied" ? "sealed" : "review",
        bundle_version: "e2e-bundle-1",
      },
      hermes: {
        public_base_url: "https://gateway.example.com",
        recommended_model_aliases: stage === "applied" ? [PUBLIC_ALIAS] : [],
        credential_flow: "cli_only",
        copy_snippets: [],
      },
    },
  };
}

function buildPolicy(): PolicySummary {
  return {
    warnings: [],
    detector_readiness: {
      presidio_enabled: true,
      languages: ["en"],
      score_threshold: 0.85,
      english_model: "en_core_web_sm",
      chinese_model: "zh_core_web_sm",
    },
    fail_closed_actions: {
      redact: "Redact content in-place",
      block: "Block the request",
    },
    endpoint_posture: [],
  };
}

function buildAccess(): AccessSummary {
  return {
    mode: "loopback",
    viewer: {
      user: SESSION_USERNAME,
      roles: ["admin"],
    },
    trace_allowed_roles: ["admin"],
    session_posture: {
      cookie_name: "stronk_admin_session",
      secure_cookies: false,
      idle_timeout_seconds: 1800,
      absolute_timeout_seconds: 7200,
      csrf_same_origin_required: true,
      login_attempt_limit: 5,
      login_attempt_window_seconds: 300,
    },
    remote_access: {
      allowed_origins: ["http://127.0.0.1:8788"],
      trusted_proxy_mode: "disabled",
      enrollment_required: false,
    },
    enrollment: {
      approved: 1,
      pending: 0,
      revoked: 0,
      active_device: null,
      recent: [],
    },
  };
}

function buildSystem(): SystemSummary {
  return {
    schema_version: "2026-04-03",
    artifact_dir: "/var/lib/stronk-gateway",
    bundle_version: "e2e-bundle-1",
    generated_at: LIVE_TIME,
    private_surface_posture: "sealed",
    check_status: "healthy",
    checks: [
      {
        name: "admin-ui",
        status: "healthy",
        message: "Browser smoke path available.",
        evidence_ref: null,
      },
    ],
    image_pins: {
      "stronk-gateway": "e2e-bundle-1",
    },
    topology: {
      browser_admin_runtime: "browser",
      public_runtime: "public",
      private_backplane: "private",
      browser_direct_cliproxyapi: false,
      supported_access_modes: ["loopback"],
      current_access_mode: "loopback",
    },
    warnings: [],
  };
}

function buildOperatorState(stage: Stage): OperatorStateSummary {
  const providerModels =
    stage === "model-published" || stage === "applied"
      ? [
          {
            upstream_id: UPSTREAM_MODEL_ID,
            public_alias: PUBLIC_ALIAS,
            privacy_policy_id: PRIVACY_POLICY_ID,
            enabled: true,
          },
        ]
      : [];

  return {
    schema_version: "2026-04-03",
    providers:
      stage === "initial"
        ? []
        : [
            {
              id: PROVIDER_ID,
              label: PROVIDER_LABEL,
              kind: "openai_compat",
              base_url: PROVIDER_BASE_URL,
              secret_ref: PROVIDER_SECRET_REF,
              cliproxy_provider_name: PROVIDER_ID,
              models: providerModels,
            },
          ],
    privacy_policies: [
      {
        id: PRIVACY_POLICY_ID,
        presidio_required: true,
        spacy_required: true,
        fail_closed_detector_types: ["email"],
      },
    ],
  };
}

function buildCreatedProvider(): {
  id: string;
  label: string;
  kind: string;
  base_url: string;
  secret_ref: string;
  cliproxy_provider_name: string;
  models: [];
} {
  return {
    id: PROVIDER_ID,
    label: PROVIDER_LABEL,
    kind: "openai_compat",
    base_url: PROVIDER_BASE_URL,
    secret_ref: PROVIDER_SECRET_REF,
    cliproxy_provider_name: PROVIDER_ID,
    models: [],
  };
}

function buildApplyJob(status: ApplyJobSummary["status"]): ApplyJobSummary {
  return {
    job_id: "job-1",
    status,
    steps:
      status === "running"
        ? [
            {
              name: "validate_draft",
              status: "running",
              message: null,
            },
          ]
        : [],
    error: null,
    rollback_available: false,
    finished_at: status === "running" ? null : LIVE_TIME,
  };
}

async function mockAdminPlane(page: Page): Promise<MockAdminState> {
  const state: MockAdminState = {
    loggedIn: false,
    stage: "initial",
    loginPayload: null,
    providerPayload: null,
    modelPayload: null,
    calls: {
      session: 0,
      login: 0,
      overview: 0,
      config: 0,
      providers: 0,
      models: 0,
      policy: 0,
      access: 0,
      system: 0,
      events: 0,
      operatorState: 0,
      createProvider: 0,
      verifyProvider: 0,
      discoverProvider: 0,
      createModel: 0,
      applyStart: 0,
      applyPoll: 0,
    },
  };

  await page.route("**/api/**", async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    const method = request.method();
    const segments = url.pathname.split("/").filter(Boolean);

    async function fulfill(status: number, payload?: unknown) {
      if (payload === undefined) {
        await route.fulfill({ status, body: "" });
        return;
      }
      await route.fulfill({ status, json: payload });
    }

    if (segments[0] !== "api") {
      throw new Error(`Unexpected non-API route intercepted: ${method} ${url.pathname}`);
    }

    if (segments[1] === "session" && segments.length === 2 && method === "GET") {
      state.calls.session += 1;
      if (!state.loggedIn) {
        await fulfill(401, { error: { code: "unauthorized" } });
        return;
      }
      await fulfill(200, buildSession());
      return;
    }

    if (segments[1] === "session" && segments[2] === "login" && method === "POST") {
      state.calls.login += 1;
      state.loginPayload = request.postDataJSON() as { username: string; password: string };
      state.loggedIn = true;
      await fulfill(200, buildSession());
      return;
    }

    if (segments[1] === "session" && segments[2] === "logout" && method === "POST") {
      state.loggedIn = false;
      await fulfill(204);
      return;
    }

    if (!state.loggedIn) {
      await fulfill(401, { error: { code: "unauthorized" } });
      return;
    }

    if (segments[1] === "overview" && method === "GET") {
      state.calls.overview += 1;
      await fulfill(200, buildOverview(state.stage));
      return;
    }

    if (segments[1] === "config" && method === "GET") {
      state.calls.config += 1;
      await fulfill(200, buildConfig());
      return;
    }

    if (segments[1] === "providers" && segments.length === 2 && method === "GET") {
      state.calls.providers += 1;
      await fulfill(200, buildProviderSummary(state.stage));
      return;
    }

    if (segments[1] === "models" && method === "GET") {
      state.calls.models += 1;
      await fulfill(200, buildModelSummary(state.stage));
      return;
    }

    if (segments[1] === "policy" && method === "GET") {
      state.calls.policy += 1;
      await fulfill(200, buildPolicy());
      return;
    }

    if (segments[1] === "access" && method === "GET") {
      state.calls.access += 1;
      await fulfill(200, buildAccess());
      return;
    }

    if (segments[1] === "system" && method === "GET") {
      state.calls.system += 1;
      await fulfill(200, buildSystem());
      return;
    }

    if (segments[1] === "events" && method === "GET") {
      state.calls.events += 1;
      await fulfill(200, { items: [] });
      return;
    }

    if (segments[1] === "operator-state" && method === "GET") {
      state.calls.operatorState += 1;
      await fulfill(200, buildOperatorState(state.stage));
      return;
    }

    if (segments[1] === "providers" && segments.length === 2 && method === "POST") {
      state.calls.createProvider += 1;
      state.providerPayload = request.postDataJSON() as ProviderDraftInput;
      state.stage = "provider-created";
      await fulfill(200, buildCreatedProvider());
      return;
    }

    if (segments[1] === "providers" && segments.length === 4 && segments[3] === "test" && method === "POST") {
      state.calls.verifyProvider += 1;
      await fulfill(200, { ok: true, latency_ms: 87 });
      return;
    }

    if (segments[1] === "providers" && segments.length === 4 && segments[3] === "discover" && method === "POST") {
      state.calls.discoverProvider += 1;
      await fulfill(200, {
        models: [
          {
            id: UPSTREAM_MODEL_ID,
          },
        ],
      });
      return;
    }

    if (segments[1] === "providers" && segments.length === 4 && segments[3] === "models" && method === "POST") {
      state.calls.createModel += 1;
      state.modelPayload = request.postDataJSON() as ModelAliasInput;
      state.stage = "model-published";
      await fulfill(204);
      return;
    }

    if (segments[1] === "apply" && segments.length === 2 && method === "POST") {
      state.calls.applyStart += 1;
      await fulfill(200, buildApplyJob("running"));
      return;
    }

    if (segments[1] === "apply" && segments.length === 3 && segments[2] === "job-1" && method === "GET") {
      state.calls.applyPoll += 1;
      state.stage = "applied";
      await fulfill(200, buildApplyJob("success"));
      return;
    }

    if (segments[1] === "apply" && segments.length === 4 && segments[3] === "rollback" && method === "POST") {
      await fulfill(200, { status: "rolled_back" });
      return;
    }

    throw new Error(`Unhandled API route: ${method} ${url.pathname}`);
  });

  return state;
}

async function signIn(page: Page) {
  await page.goto("/");

  await expect(page).toHaveTitle("Stronk Gateway Admin");
  await expect(page.getByRole("button", { name: "Open operator console" })).toBeVisible();
  await expect(page.getByLabel("Username")).toBeVisible();
  await expect(page.getByLabel("Password")).toBeVisible();

  await page.getByLabel("Username").fill(SESSION_USERNAME);
  await page.getByLabel("Password").fill(SESSION_PASSWORD);
  await page.getByRole("button", { name: "Open operator console" }).click();

  await expect(page.getByRole("button", { name: "Sign out" })).toBeVisible();
  await expect(page.getByRole("navigation", { name: "Primary" })).toBeVisible();
}

test("signs in and walks the first-time onboarding flow to completion", async ({ page }) => {
  const state = await mockAdminPlane(page);

  await test.step("authenticate", async () => {
    await signIn(page);
    await expect(page.getByText("Setup wizard")).toBeVisible();
  });

  await test.step("create the provider", async () => {
    await expect(page.getByLabel("Label")).toBeVisible();
    await page.getByLabel("Label").fill(PROVIDER_LABEL);
    await page.getByLabel("Base URL").fill(PROVIDER_BASE_URL);
    await page.getByLabel("Secret env var name").fill(PROVIDER_SECRET_REF);
    await page.getByRole("button", { name: "Save + Verify" }).click();

    await expect(page.getByLabel("Public alias")).toBeVisible();
    await expect(page.getByRole("button", { name: "Publish alias draft" })).toBeVisible();
    expect(state.stage).toBe("provider-created");
  });

  await test.step("publish the alias and apply the config", async () => {
    await page.getByLabel("Public alias").fill(PUBLIC_ALIAS);
    await page.getByRole("button", { name: "Publish alias draft" }).click();

    await expect(page.getByRole("button", { name: "Publish alias" })).toBeVisible();
    await page.getByRole("button", { name: "Publish alias" }).click();

    await expect(page.getByText("Staged config applied successfully")).toBeVisible();
    await expect(page.getByRole("button", { name: "Review providers" })).toBeVisible();
    await expect(page.getByRole("button", { name: "Review aliases" })).toBeVisible();
  });

  expect(state.loginPayload).toEqual({
    username: SESSION_USERNAME,
    password: SESSION_PASSWORD,
  });
  expect(state.providerPayload).toEqual({
    label: PROVIDER_LABEL,
    kind: "openai_compat",
    base_url: PROVIDER_BASE_URL,
    secret_ref: PROVIDER_SECRET_REF,
  });
  expect(state.modelPayload).toEqual({
    upstream_id: UPSTREAM_MODEL_ID,
    public_alias: PUBLIC_ALIAS,
    privacy_policy_id: PRIVACY_POLICY_ID,
    enabled: true,
  });
  expect(state.stage).toBe("applied");
  expect(state.calls.createProvider).toBe(1);
  expect(state.calls.discoverProvider).toBe(1);
  expect(state.calls.createModel).toBe(1);
  expect(state.calls.applyStart).toBe(1);
  expect(state.calls.applyPoll).toBeGreaterThanOrEqual(1);
  expect(state.calls.models).toBeGreaterThan(1);
});
