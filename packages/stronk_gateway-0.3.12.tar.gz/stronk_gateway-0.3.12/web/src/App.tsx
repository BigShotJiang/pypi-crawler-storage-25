import { useEffect, useMemo, useState } from "react";

import {
  ApiError,
  createProvider,
  createProviderModel,
  deleteProvider,
  deleteProviderModel,
  discoverProviderModels,
  fetchAccess,
  fetchApplyStatus,
  fetchConfig,
  fetchDebugTrace,
  fetchEvent,
  fetchEvents,
  fetchModels,
  fetchOperatorState,
  fetchOverview,
  fetchPolicy,
  fetchProviders,
  fetchSession,
  fetchSystem,
  loginSession,
  logoutSession,
  rollbackApply,
  startApply,
  testProvider,
  updateProvider,
  updateProviderModel,
} from "./api";
import {
  AccessPage,
  buildRouteWarnings,
  ConsoleShell,
  ConsoleRoute,
  getRouteDescription,
  getRouteTitle,
  LoadingShell,
  LoginShell,
  ModelsPage,
  OverviewPage,
  parseRoute,
  PolicyPage,
  ProvidersPage,
  RequestsPage,
  SystemPage,
  ThemeMode,
} from "./pages";
import type {
  AccessSummary,
  ApplyJobSummary,
  AuditEvent,
  ConfigSummary,
  DebugTrace,
  DiscoveredModel,
  ModelAliasInput,
  ModelSummary,
  OperatorStateSummary,
  Overview,
  PolicySummary,
  ProviderDraftInput,
  ProviderSummary,
  ProviderTestResult,
  SessionSummary,
  SystemSummary,
} from "./types";

const THEME_KEY = "stronk-gateway-theme";
const REFRESH_MS = 8000;
const APPLY_POLL_MS = 1500;
const PROVIDER_SECRET_REF_RE = /^PROVIDER_[A-Z0-9_]+$/;
const LOCAL_HTTP_HOSTS = new Set(["localhost", "127.0.0.1", "::1", "fake-openai-upstream"]);

function isSafeProviderBaseUrl(value: string): boolean {
  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return false;
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    return false;
  }
  if (!parsed.hostname || parsed.username || parsed.password || parsed.search || parsed.hash) {
    return false;
  }
  if (parsed.protocol === "http:" && !LOCAL_HTTP_HOSTS.has(parsed.hostname)) {
    return false;
  }
  return true;
}

function sanitizeOperatorStatePayload(payload: OperatorStateSummary): {
  payload: OperatorStateSummary;
  warnings: string[];
} {
  const warnings: string[] = [];
  const providers = payload.providers.map((provider) => {
    const nextProvider = { ...provider };
    if (!isSafeProviderBaseUrl(provider.base_url)) {
      warnings.push(
        `Provider ${provider.label} has an invalid staged base URL. The browser withheld the raw value until the draft is corrected.`,
      );
      nextProvider.base_url = "Invalid provider URL withheld";
    }
    if (provider.secret_ref && !PROVIDER_SECRET_REF_RE.test(provider.secret_ref)) {
      warnings.push(
        `Provider ${provider.label} has an invalid staged secret reference. The browser withheld the raw value until the draft is corrected.`,
      );
      nextProvider.secret_ref = "";
    }
    return nextProvider;
  });
  return {
    payload: {
      ...payload,
      providers,
    },
    warnings: [...new Set(warnings)],
  };
}

function hasPublishedOrRecommendedAlias(modelSummary: ModelSummary | null): boolean {
  if (!modelSummary) {
    return false;
  }
  return (
    modelSummary.recommended_model_aliases.length > 0 ||
    modelSummary.items.some((item) => item.recommended_for_hermes)
  );
}

function isUnauthorized(error: unknown): error is ApiError {
  return error instanceof ApiError && error.status === 401;
}

function buildProviderSaveError(): string {
  return "Provider settings were rejected. Use an HTTPS base URL, or HTTP only for local providers, and use a PROVIDER_* secret env var name only when the provider needs a key.";
}

function buildProviderDiscoverError(): string {
  return "Model discovery failed. Verify the provider settings and retry discovery.";
}

function buildModelSaveError(): string {
  return "Alias draft could not be saved. Review the public alias and privacy policy, then try again.";
}

function buildRollbackError(): string {
  return "Rollback could not be completed. Review the runtime and retry from the current apply job.";
}

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const stored = window.localStorage.getItem(THEME_KEY);
    if (stored === "light" || stored === "dark") {
      return stored;
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });
  const [route, setRoute] = useState<ConsoleRoute>(() => parseRoute(window.location.pathname));
  const [session, setSession] = useState<SessionSummary | null>(null);
  const [authResolved, setAuthResolved] = useState(false);
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [config, setConfig] = useState<ConfigSummary | null>(null);
  const [providers, setProviders] = useState<ProviderSummary | null>(null);
  const [models, setModels] = useState<ModelSummary | null>(null);
  const [policy, setPolicy] = useState<PolicySummary | null>(null);
  const [access, setAccess] = useState<AccessSummary | null>(null);
  const [system, setSystem] = useState<SystemSummary | null>(null);
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<AuditEvent | null>(null);
  const [selectedDebugTrace, setSelectedDebugTrace] = useState<DebugTrace | null>(null);
  const [operatorState, setOperatorState] = useState<OperatorStateSummary | null>(null);
  const [operatorStateWarnings, setOperatorStateWarnings] = useState<string[]>([]);
  const [selectedProviderId, setSelectedProviderId] = useState<string | null>(null);
  const [providerCreateMode, setProviderCreateMode] = useState(false);
  const [verificationByProvider, setVerificationByProvider] = useState<Record<string, ProviderTestResult | null>>({});
  const [discoveredModelsByProvider, setDiscoveredModelsByProvider] = useState<Record<string, DiscoveredModel[]>>({});
  const [providerBusyId, setProviderBusyId] = useState<string | null>(null);
  const [modelBusyProviderId, setModelBusyProviderId] = useState<string | null>(null);
  const [providerFormError, setProviderFormError] = useState<string | null>(null);
  const [modelFormError, setModelFormError] = useState<string | null>(null);
  const [applyJob, setApplyJob] = useState<ApplyJobSummary | null>(null);
  const [refreshToken, setRefreshToken] = useState(0);
  const applyBusy = applyJob?.status === "running";

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  useEffect(() => {
    const handlePopState = () => {
      setRoute(parseRoute(window.location.pathname));
    };
    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  useEffect(() => {
    let active = true;
    void fetchSession()
      .then((payload) => {
        if (!active) {
          return;
        }
        setSession(payload);
        setAuthResolved(true);
      })
      .catch((loadError) => {
        if (!active) {
          return;
        }
        setLoginError(loadError instanceof Error ? loadError.message : "Failed to resolve the admin session.");
        setAuthResolved(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!session) {
      setOverview(null);
      setConfig(null);
      setProviders(null);
      setModels(null);
      setPolicy(null);
      setAccess(null);
      setSystem(null);
      setEvents([]);
      setSelectedEvent(null);
      setSelectedDebugTrace(null);
      setOperatorState(null);
      setOperatorStateWarnings([]);
      setSelectedProviderId(null);
      setProviderCreateMode(false);
      setVerificationByProvider({});
      setDiscoveredModelsByProvider({});
      setProviderBusyId(null);
      setModelBusyProviderId(null);
      setProviderFormError(null);
      setModelFormError(null);
      setApplyJob(null);
      setError(null);
      return;
    }

    let active = true;

    async function load() {
      try {
        const [
          overviewPayload,
          configPayload,
          providersPayload,
          modelsPayload,
          policyPayload,
          accessPayload,
          systemPayload,
          eventsPayload,
          operatorStatePayload,
        ] = await Promise.all([
          fetchOverview(),
          fetchConfig(),
          fetchProviders(),
          fetchModels(),
          fetchPolicy(),
          fetchAccess(),
          fetchSystem(),
          fetchEvents(),
          fetchOperatorState(),
        ]);
        const sanitizedOperatorState = sanitizeOperatorStatePayload(operatorStatePayload);
        if (!active) {
          return;
        }
        setOverview(overviewPayload);
        setConfig(configPayload);
        setProviders(providersPayload);
        setModels(modelsPayload);
        setPolicy(policyPayload);
        setAccess(accessPayload);
        setSystem(systemPayload);
        setEvents(eventsPayload.items);
        setOperatorState(sanitizedOperatorState.payload);
        setOperatorStateWarnings(sanitizedOperatorState.warnings);
        setError(null);
      } catch (loadError) {
        if (!active) {
          return;
        }
        if (isUnauthorized(loadError)) {
          setSession(null);
          setLoginError("Your admin session expired. Sign in again to continue.");
          return;
        }
        setError(loadError instanceof Error ? loadError.message : "Failed to load control plane data.");
      }
    }

    void load();
    const timer = window.setInterval(() => {
      void load();
    }, REFRESH_MS);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [refreshToken, session]);

  useEffect(() => {
    if (!session || route.key !== "requestDetail") {
      setSelectedEvent(null);
      setSelectedDebugTrace(null);
      setError(null);
      return;
    }

    let active = true;
    const contentTraceEnabled = config?.control_plane.content_trace_enabled ?? session.content_trace_enabled;
    const traceAccess = config?.auth.trace_access ?? session.trace_access;
    setSelectedEvent(null);
    setSelectedDebugTrace(null);
    setError(null);

    void Promise.all([
      fetchEvent(route.requestId),
      contentTraceEnabled && traceAccess ? fetchDebugTrace(route.requestId) : Promise.resolve(null),
    ])
      .then(([eventPayload, debugTracePayload]) => {
        if (!active) {
          return;
        }
        setSelectedEvent(eventPayload);
        setSelectedDebugTrace(debugTracePayload);
        setError(null);
      })
      .catch((loadError) => {
        if (!active) {
          return;
        }
        if (isUnauthorized(loadError)) {
          setSession(null);
          setLoginError("Your admin session expired. Sign in again to continue.");
          return;
        }
        setSelectedEvent(null);
        setSelectedDebugTrace(null);
        setError(loadError instanceof Error ? loadError.message : "Failed to load selected request.");
      });

    return () => {
      active = false;
    };
  }, [
    config?.auth.trace_access,
    config?.control_plane.content_trace_enabled,
    route,
    session,
  ]);

  useEffect(() => {
    const providerIds = new Set(operatorState?.providers.map((provider) => provider.id) ?? []);
    setSelectedProviderId((current) => {
      if (!providerIds.size) {
        return null;
      }
      if (current && providerIds.has(current)) {
        return current;
      }
      return operatorState?.providers[0]?.id ?? null;
    });
    if (!providerIds.size) {
      setProviderCreateMode(false);
    }
    setVerificationByProvider((current) =>
      Object.fromEntries(Object.entries(current).filter(([providerId]) => providerIds.has(providerId))),
    );
    setDiscoveredModelsByProvider((current) =>
      Object.fromEntries(Object.entries(current).filter(([providerId]) => providerIds.has(providerId))),
    );
  }, [operatorState]);

  useEffect(() => {
    const activeJob = applyJob;
    if (!session || !activeJob || activeJob.status !== "running") {
      return;
    }
    const runningJobId = activeJob.job_id;

    let active = true;

    async function poll() {
      try {
        const nextJob = await fetchApplyStatus(runningJobId);
        if (!active) {
          return;
        }
        setApplyJob(nextJob);
        if (nextJob.status !== "running") {
          setRefreshToken((current) => current + 1);
        }
      } catch (pollError) {
        if (!active) {
          return;
        }
        if (isUnauthorized(pollError)) {
          setSession(null);
          setLoginError("Your admin session expired. Sign in again to continue.");
          return;
        }
        setApplyJob({
          job_id: runningJobId,
          status: "failed",
          steps: [],
          error: "Apply status could not be refreshed. Review the staged configuration and try again.",
          rollback_available: false,
          finished_at: null,
        });
      }
    }

    void poll();
    const timer = window.setInterval(() => {
      void poll();
    }, APPLY_POLL_MS);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [applyJob, session]);

  const viewer = config?.auth.viewer ?? session?.viewer ?? null;
  const traceAccess = config?.auth.trace_access ?? session?.trace_access ?? false;
  const contentTraceEnabled =
    config?.control_plane.content_trace_enabled ?? session?.content_trace_enabled ?? false;
  const currentTitle = getRouteTitle(route);
  const currentDescription = getRouteDescription(route);
  const routeWarnings = [
    ...new Set([
      ...buildRouteWarnings(route, overview, config, providers, models, policy, system),
      ...operatorStateWarnings,
    ]),
  ];
  const recentRequests = useMemo(() => events.slice(0, 6), [events]);
  const stagedProviders = operatorState?.providers ?? [];
  const selectedProvider =
    stagedProviders.find((provider) => provider.id === selectedProviderId) ?? stagedProviders[0] ?? null;
  const providersPageSelection = providerCreateMode ? null : selectedProviderId;
  const onboardingVisible = operatorState !== null && !hasPublishedOrRecommendedAlias(models);
  const onboardingDiscoveredModels = selectedProvider ? discoveredModelsByProvider[selectedProvider.id] ?? [] : [];
  const onboardingVerification = selectedProvider ? verificationByProvider[selectedProvider.id] ?? null : null;

  async function reloadOperatorState() {
    const nextState = sanitizeOperatorStatePayload(await fetchOperatorState());
    setOperatorState(nextState.payload);
    setOperatorStateWarnings(nextState.warnings);
    return nextState.payload;
  }

  function handleSelectProvider(providerId: string | null) {
    setProviderCreateMode(providerId === null);
    if (providerId !== null) {
      setSelectedProviderId(providerId);
    }
  }

  async function handleLogin(username: string, password: string) {
    setLoginBusy(true);
    setLoginError(null);
    try {
      const nextSession = await loginSession(username, password);
      setSession(nextSession);
    } catch (loginFailure) {
      if (loginFailure instanceof ApiError && loginFailure.status === 401) {
        setLoginError("Invalid username or password.");
        return;
      }
      setLoginError(
        loginFailure instanceof Error ? loginFailure.message : "Failed to sign in.",
      );
    } finally {
      setLoginBusy(false);
    }
  }

  async function handleLogout() {
    try {
      await logoutSession();
    } finally {
      setSession(null);
      setLoginError(null);
    }
  }

  function navigateTo(path: string) {
    if (window.location.pathname === path) {
      return;
    }
    window.history.pushState({}, "", path);
    setRoute(parseRoute(path));
  }

  async function runProviderDiscovery(providerId: string, manageBusy = true): Promise<DiscoveredModel[]> {
    if (manageBusy) {
      setProviderBusyId(providerId);
    }
    try {
      const discovered = await discoverProviderModels(providerId);
      setDiscoveredModelsByProvider((current) => ({
        ...current,
        [providerId]: discovered,
      }));
      setProviderFormError(null);
      return discovered;
    } catch (discoverError) {
      if (isUnauthorized(discoverError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return [];
      }
      setProviderFormError(buildProviderDiscoverError());
      return [];
    } finally {
      if (manageBusy) {
        setProviderBusyId(null);
      }
    }
  }

  async function runProviderVerification(providerId: string, manageBusy = true): Promise<ProviderTestResult> {
    if (manageBusy) {
      setProviderBusyId(providerId);
    }
    try {
      const result = await testProvider(providerId);
      setVerificationByProvider((current) => ({
        ...current,
        [providerId]: result,
      }));
      if (result.ok) {
        await runProviderDiscovery(providerId, false);
      } else {
        setDiscoveredModelsByProvider((current) => ({
          ...current,
          [providerId]: [],
        }));
        setProviderFormError(result.error ?? buildProviderDiscoverError());
      }
      return result;
    } catch (verifyError) {
      if (isUnauthorized(verifyError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return {
          ok: false,
          latency_ms: 0,
          error: "Your admin session expired. Sign in again to continue.",
        };
      }
      const failure = {
        ok: false,
        latency_ms: 0,
        error: "Verification could not be completed. Review the base URL, secret env var name, and allowlist, then try again.",
      };
      setVerificationByProvider((current) => ({
        ...current,
        [providerId]: failure,
      }));
      setDiscoveredModelsByProvider((current) => ({
        ...current,
        [providerId]: [],
      }));
      setProviderFormError(failure.error);
      return failure;
    } finally {
      if (manageBusy) {
        setProviderBusyId(null);
      }
    }
  }

  async function handleSaveProvider(providerId: string | null, value: ProviderDraftInput) {
    setProviderFormError(null);
    setModelFormError(null);
    setProviderBusyId(providerId ?? "create");
    try {
      const provider = providerId
        ? await updateProvider(providerId, value)
        : await createProvider(value);
      await reloadOperatorState();
      setProviderCreateMode(false);
      setSelectedProviderId(provider.id);
      setVerificationByProvider((current) => ({
        ...current,
        [provider.id]: { ok: true, latency_ms: 0 },
      }));
      await runProviderDiscovery(provider.id, false);
    } catch (saveError) {
      if (isUnauthorized(saveError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return;
      }
      setProviderFormError(buildProviderSaveError());
    } finally {
      setProviderBusyId(null);
    }
  }

  async function handleDeleteProvider(providerId: string) {
    setProviderFormError(null);
    setModelFormError(null);
    setProviderBusyId(providerId);
    try {
      await deleteProvider(providerId);
      await reloadOperatorState();
      setProviderCreateMode(false);
      setSelectedProviderId(null);
      setVerificationByProvider((current) =>
        Object.fromEntries(Object.entries(current).filter(([key]) => key !== providerId)),
      );
      setDiscoveredModelsByProvider((current) =>
        Object.fromEntries(Object.entries(current).filter(([key]) => key !== providerId)),
      );
    } catch (deleteError) {
      if (isUnauthorized(deleteError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return;
      }
      setProviderFormError("Provider deletion failed. Refresh the page and try again.");
    } finally {
      setProviderBusyId(null);
    }
  }

  async function handleSaveModel(providerId: string, value: ModelAliasInput, existing: boolean) {
    setModelFormError(null);
    setModelBusyProviderId(providerId);
    try {
      if (existing) {
        await updateProviderModel(providerId, value.upstream_id, value);
      } else {
        await createProviderModel(providerId, value);
      }
      await reloadOperatorState();
      setSelectedProviderId(providerId);
    } catch (saveError) {
      if (isUnauthorized(saveError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return;
      }
      setModelFormError(buildModelSaveError());
    } finally {
      setModelBusyProviderId(null);
    }
  }

  async function handleDeleteModel(providerId: string, upstreamId: string) {
    setModelFormError(null);
    setModelBusyProviderId(providerId);
    try {
      await deleteProviderModel(providerId, upstreamId);
      await reloadOperatorState();
      setSelectedProviderId(providerId);
    } catch (deleteError) {
      if (isUnauthorized(deleteError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return;
      }
      setModelFormError("Alias deletion failed. Refresh the page and try again.");
    } finally {
      setModelBusyProviderId(null);
    }
  }

  async function handleApply() {
    setProviderFormError(null);
    setModelFormError(null);
    try {
      const job = await startApply();
      setApplyJob(job);
    } catch (startError) {
      if (isUnauthorized(startError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return;
      }
      setApplyJob({
        job_id: `apply-failed-${Date.now()}`,
        status: "failed",
        steps: [],
        error: "The apply job could not be started. Review the staged configuration and try again.",
        rollback_available: false,
        finished_at: null,
      });
    }
  }

  async function handleRollbackApply(jobId: string) {
    try {
      await rollbackApply(jobId);
      const nextJob = await fetchApplyStatus(jobId);
      setApplyJob(nextJob);
      setRefreshToken((current) => current + 1);
    } catch (rollbackError) {
      if (isUnauthorized(rollbackError)) {
        setSession(null);
        setLoginError("Your admin session expired. Sign in again to continue.");
        return;
      }
      setApplyJob((current) =>
        current
          ? {
              ...current,
              status: "failed",
              error: buildRollbackError(),
            }
          : {
              job_id: jobId,
              status: "failed",
              steps: [],
              error: buildRollbackError(),
              rollback_available: false,
              finished_at: null,
            },
      );
    }
  }

  if (!authResolved) {
    return (
      <LoadingShell
        theme={theme}
        onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      />
    );
  }

  if (!session) {
    return (
      <LoginShell
        theme={theme}
        loginBusy={loginBusy}
        error={loginError}
        onSubmit={handleLogin}
        onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      />
    );
  }

  return (
    <ConsoleShell
      theme={theme}
      route={route}
      viewerUser={viewer?.user ?? "operator"}
      viewerRoles={viewer?.roles ?? ["admin"]}
      traceAccess={traceAccess}
      session={session}
      overview={overview}
      currentTitle={currentTitle}
      currentDescription={currentDescription}
      error={error}
      applyJob={applyJob}
      routeWarnings={routeWarnings}
      onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      onLogout={handleLogout}
      onNavigate={navigateTo}
      onRollbackApply={handleRollbackApply}
      onDismissApplyBanner={() => setApplyJob(null)}
    >
      {route.key === "overview" ? (
        <OverviewPage
          overview={overview}
          config={config}
          recentRequests={recentRequests}
          showOnboarding={onboardingVisible}
          onboardingProvider={selectedProvider}
          privacyPolicies={operatorState?.privacy_policies ?? []}
          discoveredModels={onboardingDiscoveredModels}
          verification={onboardingVerification}
          applyJob={applyJob}
          providerBusy={providerBusyId !== null}
          providerError={providerFormError}
          modelBusy={modelBusyProviderId !== null}
          modelError={modelFormError}
          configLocked={applyBusy}
          onCreateProvider={(value) => handleSaveProvider(null, value)}
          onVerifyProvider={async (providerId) => {
            await runProviderVerification(providerId);
          }}
          onSaveModel={(value, existing) =>
            selectedProvider ? handleSaveModel(selectedProvider.id, value, existing) : Promise.resolve()
          }
          onApply={handleApply}
          onOpenRequest={(requestId) => navigateTo(`/requests/${encodeURIComponent(requestId)}`)}
          onOpenProviders={() => navigateTo("/providers")}
          onOpenModels={() => navigateTo("/models")}
        />
      ) : null}

      {route.key === "requests" || route.key === "requestDetail" ? (
        <RequestsPage
          route={route}
          events={events}
          selectedEvent={selectedEvent}
          selectedDebugTrace={selectedDebugTrace}
          traceAccess={traceAccess}
          contentTraceEnabled={contentTraceEnabled}
          onOpenRequest={(requestId) => navigateTo(`/requests/${encodeURIComponent(requestId)}`)}
          onBackToRequests={() => navigateTo("/requests")}
        />
      ) : null}

      {route.key === "providers" ? (
        <ProvidersPage
          providers={stagedProviders}
          runtimeSummary={providers}
          selectedProviderId={providersPageSelection}
          verificationByProvider={verificationByProvider}
          discoveredModelsByProvider={discoveredModelsByProvider}
          providerBusyId={providerBusyId}
          formError={providerFormError}
          onSelectProvider={handleSelectProvider}
          onSaveProvider={handleSaveProvider}
          onDeleteProvider={handleDeleteProvider}
          onVerifyProvider={async (providerId) => {
            await runProviderVerification(providerId);
          }}
          onDiscoverProvider={async (providerId) => {
            await runProviderDiscovery(providerId);
          }}
          onApply={handleApply}
          applyBusy={applyBusy}
        />
      ) : null}

      {route.key === "models" ? (
        <ModelsPage
          providers={stagedProviders}
          runtimeSummary={models}
          privacyPolicies={operatorState?.privacy_policies ?? []}
          selectedProviderId={selectedProviderId}
          discoveredModelsByProvider={discoveredModelsByProvider}
          busyProviderId={modelBusyProviderId}
          formError={modelFormError}
          onSelectProvider={setSelectedProviderId}
          onDiscoverProvider={async (providerId) => {
            await runProviderDiscovery(providerId);
          }}
          onSaveModel={handleSaveModel}
          onDeleteModel={handleDeleteModel}
          onOpenProviders={() => navigateTo("/providers")}
          onApply={handleApply}
          applyBusy={applyBusy}
        />
      ) : null}
      {route.key === "policy" ? <PolicyPage policy={policy} /> : null}
      {route.key === "access" ? <AccessPage access={access} /> : null}
      {route.key === "system" ? <SystemPage system={system} config={config} /> : null}
    </ConsoleShell>
  );
}
