"""silly_kicks.tracking --- tracking-data namespace.

PR-S19 (silly-kicks 2.7.0) shipped the primitive layer: schema, per-provider
adapters, and the link_actions_to_frames primitive. PR-S20 (silly-kicks 2.8.0,
ADR-005) shipped the first tracking-aware feature set (action_context: 4
features + aggregator + lift_to_states extension utility) on top of those
primitives. PR-S21 (silly-kicks 2.9.0) shipped pre_shot_gk_position_*. PR-S24
(silly-kicks 3.1.0) ships TF-6 sync_score, TF-8 smoothing/velocity, TF-9
interpolation, TF-12 pre_shot_gk_angle_* + the shared `preprocess` module.
PR-S27 ships TF-13 defending_gk_from_frames + TF-14 compute_defensive_line +
6 per-Series action-coupled features + add_defensive_line + defensive_line_xfns.
PR-S31 ships TF-7 pitch_control subpackage (Spearman/Fernandez-Bornn/Voronoi) +
action-coupled VAEP integration (pitch_control_at_action + add_pitch_control +
pitch_control_xfns factory). PR-S33 ships TF-31 team shape envelope
(compute_team_shape + add_team_shape + team_shape_xfns) + TF-32 Ward-clustering
line-breaking (detect_line_breaking + add_line_break method="ward" dispatch +
line_breaking_ward_xfns).
"""

__all__ = [
    "KLOPPY_TRACKING_FRAMES_COLUMNS",
    "PFF_TRACKING_FRAMES_COLUMNS",
    "SPORTEC_TRACKING_FRAMES_COLUMNS",
    "TRACKING_CATEGORICAL_DOMAINS",
    "TRACKING_CONSTRAINTS",
    "TRACKING_FRAMES_COLUMNS",
    "ActionFrameContext",
    "FernandezBornnParams",
    "LineBreakingParams",
    "LinkReport",
    "PitchControlSurface",
    "PreprocessConfig",
    "SpearmanParams",
    "TrackingConversionReport",
    "VoronoiParams",
    "actor_speed",
    "add_action_context",
    "add_das",
    "add_defensive_line",
    "add_gk_influence",
    "add_line_break",
    "add_off_ball_context",
    "add_off_ball_runs",
    "add_pitch_control",
    "add_pre_shot_gk_angle",
    "add_pre_shot_gk_position",
    "add_sync_score",
    "add_team_shape",
    "back_line_high_x",
    "back_n_count",
    "ball_carrier_at_action",
    "compactness_x",
    "compute_defensive_line",
    "compute_pitch_control",
    "compute_pitch_control_at_points",
    "compute_team_shape",
    "compute_tti",
    "das_at_action",
    "das_xfns",
    "defenders_in_triangle_to_goal",
    "defending_gk_from_frames",
    "defensive_line_x",
    "defensive_line_xfns",
    "derive_team_in_possession",
    "derive_velocities",
    "detect_line_breaking",
    "feature_framework",
    "features",
    "get_das",
    "get_individual_das",
    "get_provider_defaults",
    "get_xc",
    "gk_closing_time_mean_s",
    "gk_closing_time_min_s",
    "gk_influence_xfns",
    "gk_pitch_control_share_weighted",
    "gk_reachable_area_m2",
    "infer_ball_carrier",
    "interpolate_frames",
    "kloppy",
    "lateral_width",
    "lift_to_states",
    "line_breaking_ward_xfns",
    "link_actions_to_frames",
    "max_lateral_gap",
    "nearest_defender_distance",
    "off_ball_context_xfns",
    "pff",
    "pitch_control",
    "pitch_control_at_action",
    "pitch_control_default_xfns",
    "pitch_control_xfns",
    "play_left_to_right",
    "pre_shot_gk_angle_default_xfns",
    "pre_shot_gk_angle_off_goal_line",
    "pre_shot_gk_angle_to_shot_trajectory",
    "pre_shot_gk_default_xfns",
    "pre_shot_gk_full_default_xfns",
    "preprocess",
    "receiver_zone_density",
    "schema",
    "select_back_line_players",
    "slice_around_event",
    "smooth_frames",
    "sportec",
    "sync_score",
    "team_shape_xfns",
    "tracking_default_xfns",
    "utils",
]

from . import feature_framework, features, pff, pitch_control, preprocess, schema, sportec, utils
from ._ball_carrier import derive_team_in_possession, infer_ball_carrier
from ._das import get_das, get_individual_das, get_xc
from ._defensive_line import compute_defensive_line, select_back_line_players
from ._line_breaking import LineBreakingParams, detect_line_breaking
from ._team_shape import compute_team_shape
from .feature_framework import ActionFrameContext, lift_to_states
from .features import (
    actor_speed,
    add_action_context,
    add_das,
    add_defensive_line,
    add_gk_influence,
    add_line_break,
    add_off_ball_context,
    add_off_ball_runs,
    add_pitch_control,
    add_pre_shot_gk_angle,
    add_pre_shot_gk_position,
    add_team_shape,
    back_line_high_x,
    back_n_count,
    ball_carrier_at_action,
    compactness_x,
    das_at_action,
    das_xfns,
    defenders_in_triangle_to_goal,
    defending_gk_from_frames,
    defensive_line_x,
    defensive_line_xfns,
    gk_closing_time_mean_s,
    gk_closing_time_min_s,
    gk_influence_xfns,
    gk_pitch_control_share_weighted,
    gk_reachable_area_m2,
    lateral_width,
    line_breaking_ward_xfns,
    max_lateral_gap,
    nearest_defender_distance,
    off_ball_context_xfns,
    pitch_control_at_action,
    pitch_control_default_xfns,
    pitch_control_xfns,
    pre_shot_gk_angle_default_xfns,
    pre_shot_gk_angle_off_goal_line,
    pre_shot_gk_angle_to_shot_trajectory,
    pre_shot_gk_default_xfns,
    pre_shot_gk_full_default_xfns,
    receiver_zone_density,
    team_shape_xfns,
    tracking_default_xfns,
)
from .pitch_control import (
    FernandezBornnParams,
    PitchControlSurface,
    SpearmanParams,
    VoronoiParams,
    compute_pitch_control,
    compute_pitch_control_at_points,
    compute_tti,
)
from .preprocess import (
    PreprocessConfig,
    derive_velocities,
    get_provider_defaults,
    interpolate_frames,
    smooth_frames,
)
from .schema import (
    KLOPPY_TRACKING_FRAMES_COLUMNS,
    PFF_TRACKING_FRAMES_COLUMNS,
    SPORTEC_TRACKING_FRAMES_COLUMNS,
    TRACKING_CATEGORICAL_DOMAINS,
    TRACKING_CONSTRAINTS,
    TRACKING_FRAMES_COLUMNS,
    LinkReport,
    TrackingConversionReport,
)
from .utils import add_sync_score, link_actions_to_frames, play_left_to_right, slice_around_event, sync_score

try:
    from . import kloppy
except ImportError:
    pass
