"""ARXML parser for AUTOSAR DCM/CanTp module configuration."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

from lxml import etree

from udsxml2tex.models import (
    STANDARD_NRCS,
    UDS_SERVICE_NAMES,
    ClearDtcNotification,
    ComControlConfig,
    ComControlSubNode,
    DataElement,
    DiagSession,
    Did,
    DidRange,
    DtcDefinition,
    DtcExtendedDataRecord,
    DtcSnapshotRecord,
    IoControlDid,
    MemoryRange,
    NrcEntry,
    PeriodicDid,
    RequestFileTransferConfig,
    ResponseOnEventConfig,
    Routine,
    RoutineParameter,
    STANDARD_ADDRESSING_MODES,
    STANDARD_SUB_FUNCTIONS,
    SecurityLevel,
    SubFunction,
    UdsService,
    UdsSpecification,
)

logger = logging.getLogger(__name__)

# Common AUTOSAR namespaces
AR_NAMESPACES = {
    "ar": "http://autosar.org/schema/r4.0",
    "ar3": "http://autosar.org/3.0.2",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
}


def _detect_namespace(root: etree._Element) -> dict[str, str]:
    """Detect the AUTOSAR namespace from the root element."""
    ns = root.nsmap
    # Try to find the AUTOSAR namespace
    for prefix, uri in ns.items():
        if "autosar.org" in uri:
            return {"ar": uri}
    # Check if there's a default namespace
    if None in ns and "autosar.org" in ns[None]:
        return {"ar": ns[None]}
    # Fallback: try without namespace
    return {}


def _xpath(element: etree._Element, path: str, ns: dict[str, str]) -> list:
    """Execute XPath query with namespace handling."""
    if ns:
        return element.xpath(path, namespaces=ns)
    # Fallback: try without namespace prefix
    clean_path = re.sub(r"ar:", "", path)
    return element.xpath(clean_path)


def _xpath_text(
    element: etree._Element, path: str, ns: dict[str, str], default: str = ""
) -> str:
    """Get text content from XPath query."""
    results = _xpath(element, path, ns)
    if results:
        if isinstance(results[0], etree._Element):
            return results[0].text or default
        return str(results[0]) or default
    return default


def _xpath_int(
    element: etree._Element, path: str, ns: dict[str, str], default: int = 0
) -> int:
    """Get integer value from XPath query."""
    text = _xpath_text(element, path, ns)
    if not text:
        return default
    try:
        if text.startswith("0x") or text.startswith("0X"):
            return int(text, 16)
        return int(text)
    except ValueError:
        return default


def _xpath_float(
    element: etree._Element, path: str, ns: dict[str, str], default: float = 0.0
) -> float:
    """Get float value from XPath query."""
    text = _xpath_text(element, path, ns)
    if not text:
        return default
    try:
        return float(text)
    except ValueError:
        return default


class ArxmlParser:
    """Parser for AUTOSAR DCM/CanTp ARXML files."""

    def __init__(self) -> None:
        self.ns: dict[str, str] = {}
        self.tree: Optional[etree._ElementTree] = None
        self.root: Optional[etree._Element] = None

    def parse(self, arxml_path: str | Path) -> UdsSpecification:
        """Parse an ARXML file and return a UDS specification.

        Args:
            arxml_path: Path to the ARXML file.

        Returns:
            UdsSpecification with all parsed data.
        """
        arxml_path = Path(arxml_path)
        if not arxml_path.exists():
            raise FileNotFoundError(f"ARXML file not found: {arxml_path}")

        logger.info("Parsing ARXML file: %s", arxml_path)

        parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
        self.tree = etree.parse(str(arxml_path), parser)
        self.root = self.tree.getroot()
        self.ns = _detect_namespace(self.root)

        spec = UdsSpecification()

        # Parse ECU name from module configuration
        self._parse_ecu_info(spec)

        # Parse DSL (Diagnostic Session Layer) - protocol, timing
        self._parse_dsl(spec)

        # Parse DSP (Diagnostic Service Processing) - sessions, security, DIDs, routines
        self._parse_s3_server(spec)
        self._parse_sessions(spec)
        self._parse_security(spec)
        self._parse_dids(spec)
        self._parse_routines(spec)
        self._parse_dtcs(spec)
        self._parse_memory_ranges(spec)
        self._parse_io_control_dids(spec)
        self._parse_periodic_dids(spec)
        self._parse_did_ranges(spec)
        self._parse_com_control(spec)
        self._parse_response_on_event(spec)
        self._parse_dtc_status_availability_mask(spec)
        self._parse_max_num_resp_pend(spec)
        self._parse_max_response_length(spec)
        self._parse_request_file_transfer(spec)
        self._parse_clear_dtc_notifications(spec)

        # Parse DSD (Diagnostic Service Dispatcher) - service table
        self._parse_services(spec)

        # Try to parse CanTp configuration from the same file
        self._parse_cantp(spec, arxml_path)

        logger.info(
            "Parsed: %d sessions, %d security levels, %d services, %d DIDs, %d routines",
            len(spec.sessions),
            len(spec.security_levels),
            len(spec.services),
            len(spec.dids),
            len(spec.routines),
        )

        return spec

    def parse_multi(self, arxml_paths: list[str | Path]) -> UdsSpecification:
        """Parse multiple ARXML files and merge results.

        Args:
            arxml_paths: List of paths to ARXML files.

        Returns:
            Merged UdsSpecification.
        """
        specs = [self.parse(p) for p in arxml_paths]
        if not specs:
            return UdsSpecification()

        merged = specs[0]
        for s in specs[1:]:
            merged.sessions.extend(s.sessions)
            merged.security_levels.extend(s.security_levels)
            merged.services.extend(s.services)
            merged.dids.extend(s.dids)
            merged.routines.extend(s.routines)
            merged.dtcs.extend(s.dtcs)
            merged.memory_ranges.extend(s.memory_ranges)
            merged.io_control_dids.extend(s.io_control_dids)
            merged.periodic_dids.extend(s.periodic_dids)
            merged.did_ranges.extend(s.did_ranges)
            merged.response_on_event.extend(s.response_on_event)
            merged.request_file_transfer.extend(s.request_file_transfer)
            merged.clear_dtc_notifications.extend(s.clear_dtc_notifications)
            if s.com_control is not None:
                if merged.com_control is None:
                    merged.com_control = s.com_control
                else:
                    merged.com_control.sub_nodes.extend(s.com_control.sub_nodes)
            if s.dtc_status_availability_mask != 0xFF:
                merged.dtc_status_availability_mask = s.dtc_status_availability_mask
            if s.max_num_resp_pend > 0:
                merged.max_num_resp_pend = s.max_num_resp_pend
            if s.max_response_length > 0:
                merged.max_response_length = s.max_response_length
            # Merge transport config
            if s.transport_config is not None:
                if merged.transport_config is None:
                    merged.transport_config = s.transport_config
                else:
                    merged.transport_config.channels.extend(
                        s.transport_config.channels
                    )

        return merged

    def _parse_ecu_info(self, spec: UdsSpecification) -> None:
        """Extract ECU name from module configuration."""
        assert self.root is not None

        # Try to find ECU-INSTANCE or MODULE-CONFIGURATION short name
        for path in [
            ".//ar:ECU-INSTANCE/ar:SHORT-NAME",
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES/ar:SHORT-NAME",
            ".//ar:ECUC-VALUE-COLLECTION/ar:SHORT-NAME",
            ".//ar:MODULE-CONFIGURATION/ar:SHORT-NAME",
        ]:
            name = _xpath_text(self.root, path, self.ns)
            if name:
                # Clean up "Dcm" prefix if present
                spec.ecu_name = name.replace("Dcm", "").strip("_") or name
                return

        # Try from SHORT-NAME of top-level AR-PACKAGE
        name = _xpath_text(self.root, ".//ar:AR-PACKAGE/ar:SHORT-NAME", self.ns)
        if name:
            spec.ecu_name = name

    def _parse_cantp(self, spec: UdsSpecification, arxml_path: Path) -> None:
        """Try to parse CanTp configuration from the ARXML file."""
        assert self.root is not None

        # Check if this file contains CanTp module configuration
        cantp_indicators = [
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[ar:SHORT-NAME='CanTp']",
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[contains(ar:SHORT-NAME/text(), 'CanTp')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpChannel')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpRxNSdu')]",
        ]
        has_cantp = False
        for path in cantp_indicators:
            if _xpath(self.root, path, self.ns):
                has_cantp = True
                break

        if has_cantp:
            try:
                from udsxml2tex.cantp_parser import CanTpParser

                cantp_parser = CanTpParser()
                config = cantp_parser.parse(arxml_path)
                if config.channels:
                    spec.transport_config = config
                    logger.info(
                        "CanTp: %d transport channels parsed",
                        len(config.channels),
                    )
            except Exception as e:
                logger.warning("Failed to parse CanTp config: %s", e)

    def _parse_dsl(self, spec: UdsSpecification) -> None:
        """Parse Diagnostic Session Layer configuration."""
        assert self.root is not None

        # Search for DcmDsl protocol configuration
        protocols = []
        for proto_path in [
            ".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='DcmDslProtocolRow']",
            ".//ar:CONTAINER[ar:SHORT-NAME='DcmDslProtocolRow']",
            ".//ar:SUB-CONTAINER[ar:SHORT-NAME='DcmDslProtocolRow']",
        ]:
            protocols = _xpath(self.root, proto_path, self.ns)
            if protocols:
                break

        # Extract protocol type from DcmDslProtocolRow
        for proto in protocols:
            ptype = self._get_param_value_text(proto, "DcmDslProtocolType")
            if ptype:
                spec.protocol_type = ptype
                logger.debug("  Protocol type: %s", ptype)
                break

        # Parse DSL buffer sizes from DcmDsl container
        dsl_containers = self._find_containers("DcmDsl")
        for dsl in dsl_containers:
            rx_buf = self._get_param_value_int(dsl, "DcmDslRxBufferSize")
            tx_buf = self._get_param_value_int(dsl, "DcmDslTxBufferSize")
            if rx_buf > 0:
                spec.dsl_rx_buffer_size = rx_buf
            if tx_buf > 0:
                spec.dsl_tx_buffer_size = tx_buf

        # Try to find CAN IDs from DcmDslConnection
        for conn_path in [
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDslConnection')]",
            ".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), 'DcmDslConnection')]",
        ]:
            connections = _xpath(self.root, conn_path, self.ns)
            if connections:
                for conn in connections:
                    for param_path in [
                        ".//ar:ECUC-NUMERICAL-PARAM-VALUE",
                        ".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE",
                    ]:
                        params = _xpath(conn, param_path, self.ns)
                        for param in params:
                            def_ref = _xpath_text(
                                param, "ar:DEFINITION-REF", self.ns
                            ) or _xpath_text(param, "ar:DEFINITION-REF/@DEST", self.ns)
                            value = _xpath_text(param, "ar:VALUE", self.ns)
                            if "RxPduId" in def_ref or "RxAddr" in def_ref:
                                spec.can_rx_id = value
                            elif "TxPduId" in def_ref or "TxAddr" in def_ref:
                                spec.can_tx_id = value
                break

    def _parse_s3_server(self, spec: UdsSpecification) -> None:
        """Parse the S3Server timeout from DcmDsp configuration."""
        assert self.root is not None

        # S3Server is a global parameter under DcmDsp
        dsp_containers = self._find_containers("DcmDsp")
        for container in dsp_containers:
            s3 = self._get_param_value_float(
                container, "DcmDspSessionS3Server", 0.0
            )
            if s3 > 0:
                spec.s3_server = s3
                logger.debug("  S3Server timeout: %.2f s", s3)
                return

    def _parse_sessions(self, spec: UdsSpecification) -> None:
        """Parse diagnostic session definitions."""
        assert self.root is not None

        # Search for DcmDspSession containers
        session_containers = self._find_containers("DcmDspSession")

        for container in session_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspSession":
                # This might be the parent container; look for sub-containers
                sub_containers = _xpath(
                    container,
                    ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                ) or _xpath(
                    container,
                    ".//ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_session(sub, spec)
                continue

            self._parse_single_session(container, spec)

    def _parse_single_session(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single session container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspSession",):
            return

        session_id = self._get_param_value_int(container, "DcmDspSessionLevel")
        if session_id == 0:
            session_id = self._get_param_value_int(container, "DcmDspSessionForBoot")

        p2 = self._get_param_value_float(container, "DcmDspSessionP2ServerMax", 0.05)
        p2_star = self._get_param_value_float(
            container, "DcmDspSessionP2StarServerMax", 5.0
        )

        session = DiagSession(
            short_name=short_name,
            session_id=session_id,
            p2_server_max=p2,
            p2_star_server_max=p2_star,
        )
        spec.sessions.append(session)
        logger.debug("  Session: %s (0x%02X)", short_name, session_id)

    def _parse_security(self, spec: UdsSpecification) -> None:
        """Parse security access level definitions."""
        assert self.root is not None

        sec_containers = self._find_containers("DcmDspSecurityRow")
        if not sec_containers:
            sec_containers = self._find_containers("DcmDspSecurity")

        for container in sec_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspSecurity":
                sub_containers = _xpath(
                    container,
                    ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_security(sub, spec)
                continue
            self._parse_single_security(container, spec)

    def _parse_single_security(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single security level container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspSecurity", "DcmDspSecurityRow"):
            # Check sub-containers
            subs = _xpath(
                container, ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
            )
            for sub in subs:
                self._parse_single_security(sub, spec)
            return

        level = self._get_param_value_int(container, "DcmDspSecurityLevel")
        max_attempts = self._get_param_value_int(
            container, "DcmDspSecurityNumAttDelay", 3
        )
        attempt_delay = self._get_param_value_float(
            container, "DcmDspSecurityDelayTime", 0.0
        )
        key_size = self._get_param_value_int(
            container, "DcmDspSecurityKeySize", 0
        )
        seed_size = self._get_param_value_int(
            container, "DcmDspSecuritySeedSize", 0
        )
        adr_size = self._get_param_value_int(
            container, "DcmDspSecurityADRSize", 0
        )

        sec = SecurityLevel(
            short_name=short_name,
            security_level=level,
            num_max_attempts=max_attempts,
            attempt_delay=attempt_delay,
            key_size=key_size,
            seed_size=seed_size,
            adr_size=adr_size,
        )
        spec.security_levels.append(sec)
        logger.debug("  Security: %s (level=%d)", short_name, level)

    def _parse_dids(self, spec: UdsSpecification) -> None:
        """Parse Data Identifier definitions."""
        assert self.root is not None

        did_containers = self._find_containers("DcmDspDid")

        for container in did_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspDid":
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_did(sub, spec)
                continue
            self._parse_single_did(container, spec)

    def _parse_single_did(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DID container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspDid",):
            return
        # Skip signal/data sub-containers that are not actual DIDs
        if "Signal" in short_name and "DID" not in short_name.upper().replace("SIGNAL", ""):
            return

        did_id = self._get_param_value_int(container, "DcmDspDidIdentifier")
        if did_id == 0:
            # Try to extract from the short name like "DID_F190"
            match = re.search(r"(?:DID[_]?)([0-9A-Fa-f]{4})", short_name)
            if match:
                did_id = int(match.group(1), 16)

        # Extract description
        description = self._get_description(container)

        # Check read/write access
        read_access = True
        write_access = False
        read_ref = self._get_param_ref(container, "DcmDspDidRead")
        write_ref = self._get_param_ref(container, "DcmDspDidWrite")
        if read_ref is not None:
            read_access = True
        if write_ref is not None:
            write_access = True

        # Parse session and security references
        sessions = self._get_ref_list(container, "DcmDspDidReadSessionRef")
        sessions.extend(self._get_ref_list(container, "DcmDspDidWriteSessionRef"))
        security = self._get_ref_list(container, "DcmDspDidReadSecurityLevelRef")
        security.extend(
            self._get_ref_list(container, "DcmDspDidWriteSecurityLevelRef")
        )

        # Check for snapshot/freeze-frame reference
        snapshot_ref = self._get_param_ref(container, "DcmDspDidFreezeFrameRef")
        snapshot_record = snapshot_ref is not None
        if not snapshot_record:
            # Also check for DcmDspSnapshotRecord sub-container
            snapshot_containers = _xpath(
                container,
                ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'SnapshotRecord')]",
                self.ns,
            ) or _xpath(
                container,
                ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'FreezeFrame')]",
                self.ns,
            )
            snapshot_record = len(snapshot_containers) > 0

        # Parse data elements (DcmDspDidSignal)
        data_elements: list[DataElement] = []
        signal_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'Signal')]",
            self.ns,
        ) or _xpath(
            container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sig in signal_containers:
            sig_name = _xpath_text(sig, "ar:SHORT-NAME", self.ns)
            if sig_name and "Signal" in sig_name:
                byte_pos = self._get_param_value_int(
                    sig, "DcmDspDidBytePosition"
                ) or self._get_param_value_int(sig, "DcmDspDidDataByteOffset")
                bit_size = self._get_param_value_int(
                    sig, "DcmDspDidBitSize"
                ) or self._get_param_value_int(sig, "DcmDspDidDataSize", 8)
                data_type = self._get_param_value_text(
                    sig, "DcmDspDidDataType"
                ) or self._get_param_value_text(sig, "DcmDspDataType", "uint8")
                unit = self._get_param_value_text(sig, "DcmDspDidDataUnit")
                min_val_text = self._get_param_value_text(sig, "DcmDspDidDataMinValue")
                max_val_text = self._get_param_value_text(sig, "DcmDspDidDataMaxValue")
                coding = self._get_param_value_text(sig, "DcmDspDidDataCoding")
                endianness = self._get_param_value_text(
                    sig, "DcmDspDidDataEndianness"
                ) or self._get_param_value_text(sig, "DcmDspDataEndianness")
                fixed_len_text = self._get_param_value_text(
                    sig, "DcmDspDidDataFixedLength"
                ) or self._get_param_value_text(sig, "DcmDspDidFixedLength")
                fixed_length = fixed_len_text.lower() != "false" if fixed_len_text else True

                de = DataElement(
                    short_name=sig_name,
                    byte_position=byte_pos,
                    bit_size=bit_size,
                    data_type=data_type,
                    unit=unit,
                    coding=coding,
                    endianness=endianness,
                    fixed_length=fixed_length,
                    min_value=float(min_val_text) if min_val_text else None,
                    max_value=float(max_val_text) if max_val_text else None,
                )
                data_elements.append(de)

        # Calculate total byte length
        total_bytes = self._get_param_value_int(container, "DcmDspDidDataSize")
        if total_bytes == 0 and data_elements:
            max_end = max(
                de.byte_position + (de.bit_size + 7) // 8 for de in data_elements
            )
            total_bytes = max_end

        did = Did(
            short_name=short_name,
            did_id=did_id,
            description=description,
            data_elements=data_elements,
            read_access=read_access,
            write_access=write_access,
            snapshot_record=snapshot_record,
            supported_sessions=list(set(sessions)),
            required_security_levels=list(set(security)),
            total_byte_length=total_bytes,
        )
        spec.dids.append(did)
        logger.debug("  DID: %s (0x%04X)", short_name, did_id)

    def _parse_routines(self, spec: UdsSpecification) -> None:
        """Parse Routine Control definitions."""
        assert self.root is not None

        routine_containers = self._find_containers("DcmDspRoutine")

        for container in routine_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspRoutine":
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_routine(sub, spec)
                continue
            self._parse_single_routine(container, spec)

    def _parse_single_routine(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single routine container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspRoutine",):
            return

        routine_id = self._get_param_value_int(
            container, "DcmDspRoutineIdentifier"
        ) or self._get_param_value_int(container, "DcmDspRoutineId")

        if routine_id == 0:
            match = re.search(r"(?:Routine[_]?)([0-9A-Fa-f]{4})", short_name)
            if match:
                routine_id = int(match.group(1), 16)

        # Check start/stop/result support
        start_ref = self._get_param_ref(container, "DcmDspStartRoutine")
        stop_ref = self._get_param_ref(container, "DcmDspStopRoutine")
        result_ref = self._get_param_ref(container, "DcmDspRequestRoutineResults")

        sessions = self._get_ref_list(container, "DcmDspRoutineSessionRef")
        security = self._get_ref_list(container, "DcmDspRoutineSecurityLevelRef")

        routine = Routine(
            short_name=short_name,
            routine_id=routine_id,
            description=self._get_description(container),
            start_supported=start_ref is not None or True,
            stop_supported=stop_ref is not None,
            result_supported=result_ref is not None,
            in_parameters=self._parse_routine_params(container, "in"),
            out_parameters=self._parse_routine_params(container, "out"),
            supported_sessions=sessions,
            required_security_levels=security,
        )
        spec.routines.append(routine)
        logger.debug("  Routine: %s (0x%04X)", short_name, routine_id)

    def _parse_routine_params(
        self, container: etree._Element, direction: str
    ) -> list[RoutineParameter]:
        """Parse routine in/out signal parameters."""
        params: list[RoutineParameter] = []
        # DcmDspRoutineInSignal / DcmDspRoutineOutSignal sub-containers
        tag = "InSignal" if direction == "in" else "OutSignal"
        sig_containers = _xpath(
            container,
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{tag}')]",
            self.ns,
        )
        for sig in sig_containers:
            sig_name = _xpath_text(sig, "ar:SHORT-NAME", self.ns)
            if not sig_name:
                continue
            byte_pos = self._get_param_value_int(sig, "DcmDspRoutineSignalPos")
            bit_size = self._get_param_value_int(sig, "DcmDspRoutineSignalLength", 8)
            data_type = self._get_param_value_text(
                sig, "DcmDspRoutineSignalType", "uint8"
            )
            params.append(
                RoutineParameter(
                    short_name=sig_name,
                    direction=direction,
                    byte_position=byte_pos,
                    bit_size=bit_size,
                    data_type=data_type,
                )
            )
        return sorted(params, key=lambda p: p.byte_position)

    def _parse_dtcs(self, spec: UdsSpecification) -> None:
        """Parse DTC (Diagnostic Trouble Code) definitions."""
        assert self.root is not None

        dtc_containers = self._find_containers("DcmDspDtc")
        for container in dtc_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspDtc":
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_dtc(sub, spec)
                continue
            self._parse_single_dtc(container, spec)

    def _parse_single_dtc(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DTC container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspDtc",):
            return

        dtc_id = self._get_param_value_int(container, "DcmDspDtcId")
        if dtc_id == 0:
            dtc_id = self._get_param_value_int(container, "DcmDspDtcValue")
        func_unit = self._get_param_value_text(container, "DcmDspDtcFunctionalUnit")
        severity = self._get_param_value_text(container, "DcmDspDtcSeverity")
        description = self._get_description(container)

        dtc = DtcDefinition(
            short_name=short_name,
            dtc_id=dtc_id,
            functional_unit=func_unit,
            severity=severity,
            description=description,
            extended_data_records=self._parse_dtc_extended_data(container),
            snapshot_records=self._parse_dtc_snapshots(container),
        )
        spec.dtcs.append(dtc)
        logger.debug("  DTC: %s (0x%06X)", short_name, dtc_id)

    def _parse_dtc_extended_data(
        self, container: etree._Element
    ) -> list[DtcExtendedDataRecord]:
        """Parse DcmDspDtcExtendedDataRecord sub-containers within a DTC."""
        records: list[DtcExtendedDataRecord] = []
        subs = _xpath(
            container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sub in subs:
            sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
            if not sn or "ExtendedData" not in sn:
                # Also check DEFINITION-REF
                def_ref = _xpath_text(
                    sub,
                    ".//ar:DEFINITION-REF",
                    self.ns,
                )
                if not def_ref or "ExtendedDataRecord" not in def_ref:
                    continue
            rec_num = self._get_param_value_int(
                sub, "DcmDspExtendedDataRecordNumber"
            ) or self._get_param_value_int(sub, "DcmDspDtcExtDataRecordNumber")
            data_size = self._get_param_value_int(
                sub, "DcmDspExtendedDataRecordSize"
            ) or self._get_param_value_int(sub, "DcmDspDtcExtDataRecordSize")
            records.append(
                DtcExtendedDataRecord(
                    record_number=rec_num,
                    short_name=sn or "",
                    data_size=data_size,
                )
            )
        return sorted(records, key=lambda r: r.record_number)

    def _parse_dtc_snapshots(
        self, container: etree._Element
    ) -> list[DtcSnapshotRecord]:
        """Parse DcmDspDtcSnapshotRecord sub-containers within a DTC."""
        records: list[DtcSnapshotRecord] = []
        subs = _xpath(
            container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sub in subs:
            sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
            if not sn or "Snapshot" not in sn:
                def_ref = _xpath_text(
                    sub,
                    ".//ar:DEFINITION-REF",
                    self.ns,
                )
                if not def_ref or "SnapshotRecord" not in def_ref:
                    continue
            rec_num = self._get_param_value_int(
                sub, "DcmDspDtcSnapshotRecordNumber"
            ) or self._get_param_value_int(sub, "DcmDspSnapshotRecordNumber")
            # Parse referenced DIDs
            did_refs = self._get_ref_list(sub, "DcmDspDtcSnapshotRecordDidRef")
            did_ids: list[int] = []
            for ref in did_refs:
                # extract DID ID from reference name like "DID_F190_VIN"
                match = re.search(r"(?:DID[_]?)([0-9A-Fa-f]{4})", ref)
                if match:
                    did_ids.append(int(match.group(1), 16))
            records.append(
                DtcSnapshotRecord(
                    record_number=rec_num,
                    short_name=sn or "",
                    dids=did_ids,
                )
            )
        return sorted(records, key=lambda r: r.record_number)

    def _parse_memory_ranges(self, spec: UdsSpecification) -> None:
        """Parse memory access range definitions."""
        assert self.root is not None

        for tag in ("DcmDspReadMemoryRangeInfo", "DcmDspWriteMemoryRangeInfo",
                     "DcmDspMemoryRangeInfo"):
            containers = self._find_containers(tag)
            for container in containers:
                sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                if not sn or sn == tag:
                    subs = _xpath(
                        container,
                        "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                        self.ns,
                    )
                    for sub in subs:
                        self._parse_single_memory_range(sub, spec, tag)
                    continue
                self._parse_single_memory_range(container, spec, tag)

    def _parse_single_memory_range(
        self, container: etree._Element, spec: UdsSpecification, tag: str
    ) -> None:
        """Parse a single memory range container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name:
            return

        start_addr = self._get_param_value_int(
            container, "DcmDspMemoryRangeStartAddress"
        ) or self._get_param_value_int(container, "DcmDspReadMemoryRangeLow")
        end_addr = self._get_param_value_int(
            container, "DcmDspMemoryRangeEndAddress"
        ) or self._get_param_value_int(container, "DcmDspReadMemoryRangeHigh")

        read_access = "Read" in tag or "MemoryRange" in tag
        write_access = "Write" in tag

        sessions = self._get_ref_list(container, "DcmDspMemoryRangeSessionRef")
        security = self._get_ref_list(container, "DcmDspMemoryRangeSecurityLevelRef")

        mr = MemoryRange(
            short_name=short_name,
            start_address=start_addr,
            end_address=end_addr,
            read_access=read_access,
            write_access=write_access,
            supported_sessions=sessions,
            required_security_levels=security,
        )
        spec.memory_ranges.append(mr)
        logger.debug("  MemoryRange: %s (0x%08X–0x%08X)", short_name, start_addr, end_addr)

    def _parse_io_control_dids(self, spec: UdsSpecification) -> None:
        """Parse IO Control DID definitions."""
        assert self.root is not None

        # IO control info is stored as DcmDspDidControl inside DcmDspDid containers
        did_containers = self._find_containers("DcmDspDid")
        for container in did_containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspDid":
                subs = _xpath(
                    container, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._try_parse_io_control_did(sub, spec)
                continue
            self._try_parse_io_control_did(container, spec)

    def _try_parse_io_control_did(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Try to parse a DID container as IO-control-capable."""
        # Check for DcmDspDidControl sub-container
        ctrl_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDspDidControl')]",
            self.ns,
        )
        if not ctrl_containers:
            return

        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name:
            return

        did_id = self._get_param_value_int(container, "DcmDspDidIdentifier")
        ctrl = ctrl_containers[0]
        mask_size = self._get_param_value_int(ctrl, "DcmDspDidControlMaskSize")
        freeze = self._get_param_value_bool(ctrl, "DcmDspDidFreezeCurrentState")
        reset = self._get_param_value_bool(ctrl, "DcmDspDidResetToDefault")
        short_term = self._get_param_value_bool(ctrl, "DcmDspDidShortTermAdjustment")
        return_ctrl = self._get_param_value_bool(ctrl, "DcmDspDidReturnControlToEcu")

        sessions = self._get_ref_list(container, "DcmDspDidControlSessionRef")
        if not sessions:
            sessions = self._get_ref_list(container, "DcmDspDidReadSessionRef")
        security = self._get_ref_list(container, "DcmDspDidControlSecurityLevelRef")
        if not security:
            security = self._get_ref_list(container, "DcmDspDidReadSecurityLevelRef")

        io_did = IoControlDid(
            short_name=short_name,
            did_id=did_id,
            control_mask_size=mask_size,
            freeze_current_state=freeze,
            reset_to_default=reset,
            short_term_adjustment=short_term,
            return_control_to_ecu=return_ctrl,
            supported_sessions=sessions,
            required_security_levels=security,
        )
        spec.io_control_dids.append(io_did)
        logger.debug("  IOControlDID: %s (0x%04X)", short_name, did_id)

    def _parse_periodic_dids(self, spec: UdsSpecification) -> None:
        """Parse periodic / ReadDataByPeriodicIdentifier DID definitions."""
        assert self.root is not None

        periodic_containers = self._find_containers("DcmDspPeriodicDid")
        for container in periodic_containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspPeriodicDid":
                subs = _xpath(
                    container, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._parse_single_periodic_did(sub, spec)
                continue
            self._parse_single_periodic_did(container, spec)

    def _parse_single_periodic_did(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single periodic DID container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspPeriodicDid",):
            return

        did_id = self._get_param_value_int(container, "DcmDspPeriodicDidIdentifier")
        mode = self._get_param_value_text(container, "DcmDspPeriodicTransmissionMode")
        sessions = self._get_ref_list(container, "DcmDspPeriodicDidSessionRef")

        pdid = PeriodicDid(
            short_name=short_name,
            did_id=did_id,
            transmission_mode=mode,
            supported_sessions=sessions,
        )
        spec.periodic_dids.append(pdid)
        logger.debug("  PeriodicDID: %s (0x%04X)", short_name, did_id)

    def _parse_did_ranges(self, spec: UdsSpecification) -> None:
        """Parse DcmDspDidRange definitions."""
        assert self.root is not None

        containers = self._find_containers("DcmDspDidRange")
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspDidRange":
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_did_range(sub, spec)
                continue
            self._parse_single_did_range(container, spec)

    def _parse_single_did_range(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DID range container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspDidRange",):
            return

        lower = self._get_param_value_int(
            container, "DcmDspDidRangeIdentifierLowerLimit"
        ) or self._get_param_value_int(container, "DcmDspDidRangeLowerLimit")
        upper = self._get_param_value_int(
            container, "DcmDspDidRangeIdentifierUpperLimit"
        ) or self._get_param_value_int(container, "DcmDspDidRangeUpperLimit")

        has_read = self._get_param_value_bool(container, "DcmDspDidRangeHasGaps") is not None
        # Check read/write access via references or flags
        read_access = True  # default for DID ranges
        write_access = False
        read_ref = self._get_param_ref(container, "DcmDspDidRangeRead")
        write_ref = self._get_param_ref(container, "DcmDspDidRangeWrite")
        if read_ref:
            read_access = True
        if write_ref:
            write_access = True

        sessions = self._get_ref_list(container, "DcmDspDidRangeSessionRef")
        security = self._get_ref_list(container, "DcmDspDidRangeSecurityLevelRef")

        dr = DidRange(
            short_name=short_name,
            lower_did=lower,
            upper_did=upper,
            read_access=read_access,
            write_access=write_access,
            supported_sessions=sessions,
            required_security_levels=security,
        )
        spec.did_ranges.append(dr)
        logger.debug(
            "  DIDRange: %s (0x%04X–0x%04X)", short_name, lower, upper
        )

    def _parse_services(self, spec: UdsSpecification) -> None:
        """Parse Diagnostic Service Dispatcher (DSD) service table."""
        assert self.root is not None

        service_containers = self._find_containers("DcmDsdService")

        for container in service_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name in ("DcmDsdService", "DcmDsdServiceTable"):
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_service(sub, spec)
                continue
            self._parse_single_service(container, spec)

    def _parse_single_service(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single service container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in (
            "DcmDsdService",
            "DcmDsdServiceTable",
        ):
            return

        service_id = self._get_param_value_int(container, "DcmDsdSidTabServiceId")
        if service_id == 0:
            service_id = self._get_param_value_int(container, "DcmDsdServiceId")

        # Check if subfunctions supported
        has_subfunc = self._get_param_value_bool(
            container, "DcmDsdSidTabSubfuncAvail"
        )

        # Check suppressPosRspMsgIndicationBit
        suppress_pos_rsp = self._get_param_value_bool(
            container, "DcmDsdSidTabSuppressPosRsp"
        )

        # Get session and security info
        sessions = self._get_ref_list(container, "DcmDsdSidTabSessionLevelRef")
        security = self._get_ref_list(container, "DcmDsdSidTabSecurityLevelRef")

        # Get addressing mode
        addressing = []
        addr_val = self._get_param_value_text(container, "DcmDsdSidTabAddressingMode")
        if addr_val:
            # Normalize AUTOSAR enum values
            val = addr_val.upper()
            if "FUNC" in val and "PHYS" in val:
                addressing = ["physical", "functional"]
            elif "FUNC" in val:
                addressing = ["functional"]
            elif "PHYS" in val:
                addressing = ["physical"]
            else:
                addressing = [addr_val]
        else:
            # Fall back to ISO 14229-1 standard addressing modes
            addressing = STANDARD_ADDRESSING_MODES.get(service_id, ["physical"])

        # Use standard service name if available
        name = UDS_SERVICE_NAMES.get(service_id, short_name)

        # Parse sub-functions from ARXML (DcmDsdSubService containers)
        sub_functions = self._parse_sub_services(container)
        if not sub_functions and has_subfunc:
            # Fall back to ISO 14229-1 standard sub-functions
            std_sfs = STANDARD_SUB_FUNCTIONS.get(service_id, [])
            sub_functions = [
                SubFunction(short_name=sf_name, sub_function_id=sf_id)
                for sf_id, sf_name in std_sfs
            ]

        # Build NRC list: prefer ARXML definitions, fall back to defaults
        nrc_list = self._parse_service_nrcs(container)
        if not nrc_list:
            nrc_list = self._build_default_nrcs(service_id, has_subfunc)

        service = UdsService(
            short_name=name,
            service_id=service_id,
            supported_sessions=sessions,
            required_security_levels=security,
            sub_functions=sub_functions,
            nrc_list=nrc_list,
            addressing_modes=addressing,
            suppress_pos_rsp=suppress_pos_rsp,
        )
        spec.services.append(service)
        logger.debug("  Service: %s (0x%02X), %d sub-functions",
                     name, service_id, len(sub_functions))

    def _parse_sub_services(
        self, service_container: etree._Element
    ) -> list[SubFunction]:
        """Parse DcmDsdSubService sub-containers within a service."""
        sub_functions: list[SubFunction] = []
        # Look for DcmDsdSubService containers
        sub_svc_containers = _xpath(
            service_container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sub_c in sub_svc_containers:
            sn = _xpath_text(sub_c, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue
            sf_id_text = self._get_param_value_text(sub_c, "DcmDsdSubServiceId")
            if not sf_id_text and not sn.lower().startswith("subservice"):
                # No sub-service ID found and name doesn't indicate a sub-service
                continue
            sf_id = self._get_param_value_int(sub_c, "DcmDsdSubServiceId")
            sf_sessions = self._get_ref_list(
                sub_c, "DcmDsdSubServiceSessionLevelRef"
            )
            sf_security = self._get_ref_list(
                sub_c, "DcmDsdSubServiceSecurityLevelRef"
            )
            sf_suppress = self._get_param_value_bool(
                sub_c, "DcmDsdSubServiceSuppressPosRsp"
            )
            sub_functions.append(
                SubFunction(
                    short_name=sn,
                    sub_function_id=sf_id,
                    supported_sessions=sf_sessions,
                    required_security_levels=sf_security,
                    suppress_pos_rsp=sf_suppress,
                )
            )
        return sorted(sub_functions, key=lambda s: s.sub_function_id)

    def _parse_service_nrcs(
        self, service_container: etree._Element
    ) -> list[NrcEntry]:
        """Parse NRC definitions from DcmDsdNegativeResponseCode sub-containers."""
        nrcs: list[NrcEntry] = []
        # Look for NRC containers within service
        nrc_containers = _xpath(
            service_container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for nc in nrc_containers:
            sn = _xpath_text(nc, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue
            # Check if this is a NRC container via DEFINITION-REF or name
            def_ref = _xpath_text(nc, ".//ar:DEFINITION-REF", self.ns) or ""
            if "NegativeResponseCode" not in def_ref and "Nrc" not in sn and "NRC" not in sn:
                continue
            nrc_code = self._get_param_value_int(nc, "DcmDsdNegativeResponseCodeValue")
            if nrc_code == 0:
                nrc_code = self._get_param_value_int(nc, "DcmDsdNrcValue")
            if nrc_code == 0:
                # Try to extract from name like NRC_0x31 or NRC_31
                match = re.search(r"(?:0x)?([0-9A-Fa-f]{2})", sn)
                if match:
                    nrc_code = int(match.group(1), 16)
            if nrc_code == 0:
                continue
            nrc_name = STANDARD_NRCS.get(nrc_code, sn)
            nrcs.append(NrcEntry(nrc_code=nrc_code, nrc_name=nrc_name))
        return sorted(nrcs, key=lambda n: n.nrc_code)

    def _build_default_nrcs(
        self, service_id: int, has_subfunc: bool
    ) -> list[NrcEntry]:
        """Build default NRC list for a service."""
        nrcs = []
        # Common NRCs for all services
        common_nrc_codes = [0x10, 0x11, 0x13, 0x22, 0x7F]
        if has_subfunc:
            common_nrc_codes.append(0x12)
            common_nrc_codes.append(0x7E)

        # Service-specific NRCs
        if service_id == 0x11:  # ECUReset
            common_nrc_codes.extend([0x33])
        elif service_id == 0x14:  # ClearDiagnosticInformation
            common_nrc_codes.extend([0x31])
        elif service_id == 0x19:  # ReadDTCInformation
            common_nrc_codes.extend([0x31])
        elif service_id == 0x27:  # SecurityAccess
            common_nrc_codes.extend([0x24, 0x31, 0x33, 0x35, 0x36, 0x37])
        elif service_id == 0x29:  # Authentication
            common_nrc_codes.extend([0x24, 0x31, 0x33, 0x70])
        elif service_id == 0x28:  # CommunicationControl
            common_nrc_codes.extend([0x31])
        elif service_id in (0x22, 0x2E):  # Read/Write DID
            common_nrc_codes.extend([0x31, 0x33])
        elif service_id == 0x31:  # RoutineControl
            common_nrc_codes.extend([0x24, 0x31, 0x33])
        elif service_id == 0x34:  # RequestDownload
            common_nrc_codes.extend([0x31, 0x33, 0x70])
        elif service_id == 0x36:  # TransferData
            common_nrc_codes.extend([0x24, 0x31, 0x71, 0x72, 0x73])
        elif service_id == 0x37:  # RequestTransferExit
            common_nrc_codes.extend([0x24, 0x31, 0x72])
        elif service_id == 0x85:  # ControlDTCSetting
            common_nrc_codes.extend([0x31])

        for code in sorted(set(common_nrc_codes)):
            name = STANDARD_NRCS.get(code, f"NRC_{code:02X}")
            nrcs.append(NrcEntry(nrc_code=code, nrc_name=name))

        return nrcs

    def _parse_com_control(self, spec: UdsSpecification) -> None:
        """Parse DcmDspComControl configuration."""
        assert self.root is not None

        containers = self._find_containers("DcmDspComControl")
        if not containers:
            return

        sub_nodes: list[ComControlSubNode] = []
        sessions: list[str] = []
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if sn == "DcmDspComControl":
                sessions = self._get_ref_list(container, "DcmDspComControlSessionRef")
            # Look for sub-node containers
            subs = _xpath(
                container,
                ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                self.ns,
            ) or [container]
            for sub in subs:
                sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                if not sub_sn or sub_sn == "DcmDspComControl":
                    continue
                comm_type = self._get_param_value_int(
                    sub, "DcmDspComControlCommunicationType"
                )
                subnet = self._get_param_value_int(
                    sub, "DcmDspComControlSubNodeId"
                ) or self._get_param_value_int(sub, "DcmDspComControlSubnetNumber")
                sub_nodes.append(
                    ComControlSubNode(
                        short_name=sub_sn,
                        communication_type=comm_type,
                        subnet_number=subnet,
                    )
                )
        if sub_nodes:
            spec.com_control = ComControlConfig(
                sub_nodes=sub_nodes,
                supported_sessions=sessions,
            )
            logger.debug("  ComControl: %d sub-nodes", len(sub_nodes))

    def _parse_response_on_event(self, spec: UdsSpecification) -> None:
        """Parse DcmDspResponseOnEvent / DcmDspRoe configuration."""
        assert self.root is not None

        for tag in ("DcmDspResponseOnEvent", "DcmDspRoe"):
            containers = self._find_containers(tag)
            for container in containers:
                sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                if not sn or sn in (tag,):
                    subs = _xpath(
                        container,
                        "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                        self.ns,
                    )
                    for sub in subs:
                        self._parse_single_roe(sub, spec)
                    continue
                self._parse_single_roe(container, spec)

    def _parse_single_roe(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single ResponseOnEvent entry."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return

        ewt = self._get_param_value_int(container, "DcmDspRoeEventWindowTime")
        if ewt == 0:
            ewt = self._get_param_value_int(container, "DcmDspResponseOnEventWindowTime")
        store = self._get_param_value_bool(container, "DcmDspRoeStoreEvent")
        svc_to_resp = self._get_param_value_int(
            container, "DcmDspRoeServiceToRespondTo"
        )
        event_type = self._get_param_value_text(container, "DcmDspRoeEventType")
        sessions = self._get_ref_list(container, "DcmDspRoeSessionRef")

        roe = ResponseOnEventConfig(
            short_name=sn,
            event_window_time=ewt,
            store_event=store,
            service_to_respond_to=svc_to_resp,
            event_type=event_type,
            supported_sessions=sessions,
        )
        spec.response_on_event.append(roe)
        logger.debug("  ROE: %s (eventType=%s)", sn, event_type)

    def _parse_dtc_status_availability_mask(self, spec: UdsSpecification) -> None:
        """Parse DcmDspDtcStatusAvailabilityMask from DcmDsp container."""
        assert self.root is not None

        dsp_containers = self._find_containers("DcmDsp")
        for container in dsp_containers:
            mask = self._get_param_value_int(
                container, "DcmDspDtcStatusAvailabilityMask", 0
            )
            if mask > 0:
                spec.dtc_status_availability_mask = mask
                logger.debug("  DTC StatusAvailabilityMask: 0x%02X", mask)
                return

    def _parse_max_num_resp_pend(self, spec: UdsSpecification) -> None:
        """Parse DcmDslDiagRespMaxNumRespPend from DcmDsl."""
        assert self.root is not None

        dsl_containers = self._find_containers("DcmDsl")
        for container in dsl_containers:
            val = self._get_param_value_int(
                container, "DcmDslDiagRespMaxNumRespPend", 0
            )
            if val > 0:
                spec.max_num_resp_pend = val
                logger.debug("  MaxNumRespPend: %d", val)
                return
        # Also try in DcmDslProtocolRow
        proto_containers = self._find_containers("DcmDslProtocolRow")
        for container in proto_containers:
            val = self._get_param_value_int(
                container, "DcmDslDiagRespMaxNumRespPend", 0
            )
            if val > 0:
                spec.max_num_resp_pend = val
                return

    def _parse_max_response_length(self, spec: UdsSpecification) -> None:
        """Parse DcmDslProtocolMaximumResponseLength."""
        assert self.root is not None

        for tag in ("DcmDslProtocolRow", "DcmDsl"):
            containers = self._find_containers(tag)
            for container in containers:
                val = self._get_param_value_int(
                    container, "DcmDslProtocolMaximumResponseLength", 0
                )
                if val > 0:
                    spec.max_response_length = val
                    logger.debug("  MaxResponseLength: %d", val)
                    return

    def _parse_request_file_transfer(self, spec: UdsSpecification) -> None:
        """Parse DcmDspRequestFileTransfer configuration."""
        assert self.root is not None

        containers = self._find_containers("DcmDspRequestFileTransfer")
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspRequestFileTransfer":
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_file_transfer(sub, spec)
                continue
            self._parse_single_file_transfer(container, spec)

    def _parse_single_file_transfer(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single file transfer config."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return

        max_path = self._get_param_value_int(
            container, "DcmDspRequestFileTransferMaxFilePathLength"
        )
        max_size = self._get_param_value_int(
            container, "DcmDspRequestFileTransferMaxFileSize"
        )
        sessions = self._get_ref_list(
            container, "DcmDspRequestFileTransferSessionRef"
        )
        security = self._get_ref_list(
            container, "DcmDspRequestFileTransferSecurityLevelRef"
        )

        rft = RequestFileTransferConfig(
            short_name=sn,
            max_file_path_length=max_path,
            max_file_size=max_size,
            supported_sessions=sessions,
            required_security_levels=security,
        )
        spec.request_file_transfer.append(rft)
        logger.debug("  FileTransfer: %s", sn)

    def _parse_clear_dtc_notifications(self, spec: UdsSpecification) -> None:
        """Parse DcmDspClearDtcNotification configuration."""
        assert self.root is not None

        containers = self._find_containers("DcmDspClearDTCNotification")
        if not containers:
            containers = self._find_containers("DcmDspClearDtcNotification")
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue
            notif_class = self._get_param_value_text(
                container, "DcmDspClearDTCNotificationClass"
            ) or self._get_param_value_text(
                container, "DcmDspClearDtcNotificationType"
            )
            spec.clear_dtc_notifications.append(
                ClearDtcNotification(short_name=sn, notification_class=notif_class)
            )
            logger.debug("  ClearDTC notify: %s (%s)", sn, notif_class)

    # ---- Helper methods ----

    def _find_containers(self, name: str) -> list:
        """Find ECUC container values by SHORT-NAME pattern."""
        assert self.root is not None
        results = []

        # Try multiple XPath patterns for different ARXML structures
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='{name}']",
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
            f".//ar:CONTAINER[ar:SHORT-NAME='{name}']",
            f".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]

        for pattern in patterns:
            found = _xpath(self.root, pattern, self.ns)
            if found:
                results.extend(found)
                break

        return results

    def _get_param_value_int(
        self, container: etree._Element, param_name: str, default: int = 0
    ) -> int:
        """Get integer parameter value from container."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    if text.startswith("0x") or text.startswith("0X"):
                        return int(text, 16)
                    return int(float(text))
                except ValueError:
                    pass
        return default

    def _get_param_value_float(
        self, container: etree._Element, param_name: str, default: float = 0.0
    ) -> float:
        """Get float parameter value from container."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    return float(text)
                except ValueError:
                    pass
        return default

    def _get_param_value_text(
        self, container: etree._Element, param_name: str, default: str = ""
    ) -> str:
        """Get text parameter value from container."""
        for path in [
            f".//ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                return text
        return default

    def _get_param_value_bool(
        self, container: etree._Element, param_name: str, default: bool = False
    ) -> bool:
        """Get boolean parameter value from container."""
        text = self._get_param_value_text(container, param_name)
        if text.lower() in ("true", "1"):
            return True
        if text.lower() in ("false", "0"):
            return False
        return default

    def _get_param_ref(
        self, container: etree._Element, param_name: str
    ) -> Optional[str]:
        """Get a reference parameter value."""
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            if results:
                elem = results[0]
                return elem.text if isinstance(elem, etree._Element) else str(elem)
        return None

    def _get_ref_list(
        self, container: etree._Element, param_name: str
    ) -> list[str]:
        """Get a list of reference names for a parameter."""
        refs: list[str] = []
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            for r in results:
                text = r.text if isinstance(r, etree._Element) else str(r)
                if text:
                    # Extract the last part of the reference path
                    ref_name = text.rsplit("/", 1)[-1]
                    refs.append(ref_name)
        # Remove duplicates caused by overlapping XPath patterns, preserving order
        return list(dict.fromkeys(refs))

    def _get_description(self, container: etree._Element) -> str:
        """Extract a description from standard AUTOSAR elements."""
        # Try DESC/L-2 (AUTOSAR R4)
        for path in [
            "ar:DESC/ar:L-2",
            "ar:ADMIN-DATA/ar:DOC-REVISIONS/ar:DOC-REVISION/ar:DESC/ar:L-2",
            "ar:LONG-NAME/ar:L-4",
            "ar:LABEL/ar:L-4",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text and text.strip():
                return text.strip()
        # Try DcmDspDidDescription textual param
        desc = self._get_param_value_text(container, "Description")
        if desc:
            return desc
        return ""
