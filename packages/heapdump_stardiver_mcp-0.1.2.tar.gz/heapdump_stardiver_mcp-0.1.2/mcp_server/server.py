# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Zac Policzer

"""HeapDumpStarDiver 的 MCP 服务器 — JVM 堆转储分析。

工具:
  会话生命周期:
    - convert_heap_dump   将 HPROF 转换为 Parquet 并打开会话
    - open_session        基于已有的 Parquet 文件打开会话
    - list_sessions       显示所有会话及其状态
    - close_session       关闭会话的 DuckDB 连接（保留文件）
    - cleanup_session     关闭连接并删除 Parquet 文件

  分析:
    - list_parquet_files  发现可用的表，包含行数和 schema 信息
    - query_heap          对 Parquet 文件执行任意 DuckDB SQL 查询
    - analyze_heap        自动化内存浪费检测和堆分析
"""

import asyncio
import json
import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from .analysis import (
    ParquetResolver,
    format_bytes,
    run_summary,
    run_top_types,
    run_category_breakdown,
    run_byte_array_distribution,
    run_large_byte_arrays,
    run_waste_analysis,
)
from .heap_state import manager

DEFAULT_PAGE_SIZE = 1000

mcp = FastMCP(
    name="HeapDumpStarDiver",
    instructions=(
        "JVM 堆转储分析器。会话在多次调用之间跟踪状态。\n\n"
        "快速开始:\n"
        "  convert_heap_dump(hprof_path) -> 自动打开一个会话\n"
        "  open_session(parquet_dir)     -> 从已有的 Parquet 文件恢复\n\n"
        "会话打开后:\n"
        "  list_parquet_files()  -> 查看可用的表\n"
        "  query_heap(sql)       -> 对 Parquet 文件执行 DuckDB SQL 查询\n"
        "  analyze_heap()        -> 自动化内存浪费检测\n\n"
        "完成后:\n"
        "  close_session(id)   -> 关闭连接，保留文件以便后续使用\n"
        "  cleanup_session(id) -> 关闭连接并删除文件\n\n"
        "如果只有一个会话处于活跃状态，查询工具可以省略 session_id。\n"
        "使用 list_sessions() 查看所有活跃会话。"
    ),
)


def _json(obj) -> str:
    """序列化为紧凑的 JSON 格式。"""
    return json.dumps(obj, indent=2, default=str)


# ---------------------------------------------------------------------------
# 资源 — 代理可按需读取的参考资料
# ---------------------------------------------------------------------------

@mcp.resource(
    "heapdump://guides/setup",
    name="安装指南",
    description="如何构建 HeapDumpStarDiver 并安装 MCP 服务器依赖",
    mime_type="text/markdown",
)
def guide_setup() -> str:
    return """\
# 安装指南

## 构建 HeapDumpStarDiver 二进制文件

Rust 二进制文件用于将 HPROF 堆转储转换为 Parquet 文件。在使用
`convert_heap_dump` 之前必须先构建它。

```bash
# 1. 克隆 jvm-hprof 依赖（相对于仓库根目录）
mkdir -p ../../bitbucket
git clone https://bitbucket.org/ZacAttack/jvm-hprof-rs-li-hackweek.git ../../bitbucket/jvm-hprof-rs-li-hackweek

# 2. 构建二进制文件
cargo build --release
```

二进制文件输出到 `target/release/HeapDumpStarDiver`。

## 安装 MCP 服务器 Python 依赖

```bash
python3 -m venv .venv
.venv/bin/pip install -e .
```

## 二进制文件查找顺序

MCP 服务器按以下顺序查找二进制文件：
1. `HEAP_DUMP_STAR_DIVER_BINARY_OVERRIDE` 环境变量
2. 相对于仓库根目录的 `target/release/HeapDumpStarDiver`
3. PATH 中的 `HeapDumpStarDiver`
"""


@mcp.resource(
    "heapdump://guides/sql-examples",
    name="SQL 示例",
    description="常见堆转储分析任务的 DuckDB SQL 查询示例",
    mime_type="text/markdown",
)
def guide_sql_examples() -> str:
    return """\
# query_heap 的 SQL 示例

所有查询使用 DuckDB 语法。通过 `read_parquet('pattern')` 引用 Parquet 文件。
Robo 模式文件使用 `_chunk*.parquet` 后缀，引用字段为裸 UInt64 ID。

## 按对象数量排列的顶部类型
```sql
SELECT type_name, COUNT(*) as cnt
FROM read_parquet('_object_index_chunk*.parquet')
GROUP BY type_name ORDER BY cnt DESC LIMIT 20
```

## 查找某个对象 ID 所属的类型
```sql
SELECT * FROM read_parquet('_object_index_chunk*.parquet')
WHERE obj_id = 12345678
```

## 线程栈分析
```sql
SELECT sf.class_name, sf.method_name, COUNT(*) as appearances
FROM '_stack_traces.parquet' st, UNNEST(st.frame_ids) AS t(fid)
JOIN '_stack_frames.parquet' sf ON sf.frame_id = t.fid
GROUP BY sf.class_name, sf.method_name
ORDER BY appearances DESC LIMIT 10
```

## 重复字符串及浪费估算
```sql
WITH str_bytes AS (
    SELECT s.obj_id, s.value as byte_id,
           md5(CAST(b.values AS VARCHAR)) as hash, len(b.values) as len
    FROM read_parquet('java.lang.String_*_chunk*.parquet') s
    JOIN read_parquet('_primitive_arrays_byte_chunk*.parquet') b ON s.value = b.obj_id
)
SELECT hash, COUNT(*) as dups, MIN(len) as str_len
FROM str_bytes GROUP BY hash HAVING COUNT(*) > 1
ORDER BY dups * str_len DESC LIMIT 20
```

## 按类型统计 GC 根
```sql
SELECT root_type, COUNT(*) as cnt
FROM read_parquet('_gc_roots_chunk*.parquet')
GROUP BY root_type ORDER BY cnt DESC
```

## 类继承关系（查找子类）
```sql
SELECT * FROM read_parquet('_class_hierarchy.parquet')
WHERE super_class_name = 'java.util.AbstractMap'
```

## 统计特定类的对象数量
```sql
SELECT COUNT(*) FROM read_parquet('com.example.MyClass_*_chunk*.parquet')
```

## 将实例字段与对象索引关联以解析类型
```sql
SELECT i.*, idx.type_name as ref_type
FROM read_parquet('com.example.MyClass_*_chunk*.parquet') i
JOIN read_parquet('_object_index_chunk*.parquet') idx ON i.some_ref_field = idx.obj_id
LIMIT 20
```
"""


@mcp.resource(
    "heapdump://guides/waste-checks",
    name="浪费检查参考",
    description="每个浪费分析层级检查的内容及其检测目标",
    mime_type="text/markdown",
)
def guide_waste_checks() -> str:
    return """\
# 浪费分析检查项

`analyze_heap` 工具通过 `waste_tier` 参数控制浪费检查。
更高的层级包含所有低层级检查以及额外的检查项。

| 层级 | 检查项 | 检测内容 |
|------|--------|----------|
| 1 | 重复字符串 | 具有相同 byte[] 内容的字符串 |
| 1 | 不良集合 | 空的或单元素的 HashMap、ArrayList、LinkedList、TreeMap、ConcurrentHashMap |
| 1 | 不良对象数组 | 零长度、全 null、单元素、稀疏（>70% null）的对象数组 |
| 1 | 不良基本类型数组 | 所有 8 种基本类型中零长度、全零、单元素的数组 |
| 1 | 装箱基本类型 | Integer、Long、Double 等包装类的额外开销 |
| 2 | 集合容量 | 稀疏 HashMap（<33% 利用率）、ArrayList 后备数组过大 |
| 2 | 重复 byte[] | 相同的字节数组（MD5 哈希，数组 <=10KB） |
| 2 | 类数量 | >20K 个类可能表示类加载器泄漏 |
| 2 | GC 根 | 根类型分布（线程膨胀、JNI 泄漏） |
| 2 | DirectByteBuffer | 堆外容量、空缓冲区 |
| 2 | 线程栈 | 线程数量和栈深度分析 |
| 3 | 重复对象数组 | 相同元素且相同顺序的数组 |
| 3 | 估算浅层大小 | 按类型估算堆内存使用量 |

## 严重程度级别

严重程度基于估算的浪费字节数：
- **严重 (CRITICAL)**: >100 MB
- **高 (HIGH)**: >10 MB
- **中等 (MEDIUM)**: >1 MB
- **低 (LOW)**: >100 KB
- **信息 (INFO)**: <=100 KB

## 建议

- 使用 `waste_tier=1` 进行快速扫描（5 项检查）
- 使用 `waste_tier=2`（默认）进行全面分析（11 项检查）
- 仅在需要高开销检查时使用 `waste_tier=3`（13 项检查，大堆上较慢）
"""


# ---------------------------------------------------------------------------
# 会话生命周期工具
# ---------------------------------------------------------------------------

@mcp.tool()
async def convert_heap_dump(
    hprof_path: str,
    session_id: str = "",
    flush_rows: int = 500_000,
) -> str:
    """将 JVM 堆转储（HPROF）转换为 Parquet 文件并打开分析会话。

    始终使用 robo 模式以生成 LLM 优化的输出。
    输出写入 <hprof_parent>/<session_id>/parquet/。

    Args:
        hprof_path: .hprof 文件的绝对路径。
        session_id: 可选的会话名称。默认为 HPROF 文件名（不含扩展名）。
        flush_rows: 刷新前缓冲的行数。值越小，内存占用越低。
    """
    hprof = Path(hprof_path).resolve()
    if not hprof.is_file():
        return _json({"error": f"文件未找到: {hprof}"})

    if manager.rust_binary is None:
        return _json({
            "error": "未找到 HeapDumpStarDiver 二进制文件。",
            "hint": "请在仓库根目录运行 `cargo build --release`，或设置 "
                    "HEAP_DUMP_STAR_DIVER_BINARY_OVERRIDE 环境变量指向二进制文件路径。",
        })

    # 在创建目录之前确定会话 ID
    sid = session_id or hprof.stem

    # 在 HPROF 文件旁创建会话专用工作目录。
    # Rust 二进制文件将 Parquet 写入相对于 CWD 的 parquet/ 目录，因此路径为：
    #   <hprof_parent>/<session_id>/parquet/
    work_dir = hprof.parent / sid
    work_dir.mkdir(parents=True, exist_ok=True)
    parquet_dir = work_dir / "parquet"

    cmd = [
        str(manager.rust_binary),
        "-f", str(hprof),
        "dump-objects-to-parquet",
        "--flush-rows", str(flush_rows),
        "--robo-mode",
    ]

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=str(work_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()

    if proc.returncode != 0:
        return _json({
            "error": f"转换失败（退出码 {proc.returncode}）",
            "stderr": stderr.decode(),
        })

    sess = manager.create_session(
        parquet_dir=parquet_dir,
        hprof_path=hprof,
        session_id=sid,
    )

    pq_files = sorted(parquet_dir.glob("*.parquet"))
    total_size = sum(f.stat().st_size for f in pq_files)

    return _json({
        "status": "ok",
        "session_id": sess.session_id,
        "parquet_dir": str(parquet_dir),
        "files_created": len(pq_files),
        "total_size": format_bytes(total_size),
        "rust_output": stdout.decode().strip() or stderr.decode().strip(),
    })


@mcp.tool()
def open_session(
    parquet_dir: str,
    session_id: str = "",
) -> str:
    """基于已有的 Parquet 目录打开分析会话。

    用于恢复之前转换过的堆转储的分析工作。

    Args:
        parquet_dir: 包含 .parquet 文件的目录路径。
        session_id: 可选的会话名称。默认为目录名。
    """
    pdir = Path(parquet_dir).resolve()
    if not pdir.is_dir():
        return _json({"error": f"目录未找到: {pdir}"})

    pq_files = sorted(pdir.glob("*.parquet"))
    if not pq_files:
        return _json({"error": f"在 {pdir} 中未找到 .parquet 文件"})

    sess = manager.create_session(
        parquet_dir=pdir,
        session_id=session_id or None,
    )

    return _json({
        "status": "ok",
        "session_id": sess.session_id,
        "parquet_dir": str(pdir),
        "files_available": len(pq_files),
    })


@mcp.tool()
def list_sessions() -> str:
    """列出所有堆转储会话及其状态。"""
    sessions = manager.list_all()
    if not sessions:
        return _json({
            "sessions": [],
            "note": "暂无会话。请使用 convert_heap_dump 或 open_session 开始。",
        })
    return _json({"sessions": sessions})


@mcp.tool()
def close_session(session_id: str) -> str:
    """关闭会话的 DuckDB 连接，但保留磁盘上的 Parquet 文件。

    之后可以通过 open_session 重新打开该会话。

    Args:
        session_id: 要关闭的会话。
    """
    try:
        manager.close_session(session_id)
    except KeyError as e:
        return _json({"error": str(e)})
    return _json({
        "status": "ok",
        "session_id": session_id,
        "note": "连接已关闭。Parquet 文件已保留。",
    })


@mcp.tool()
def cleanup_session(session_id: str, confirm: bool = False) -> str:
    """关闭会话并删除其磁盘上的 Parquet 文件。

    此操作具有破坏性 — Parquet 文件将被永久删除。
    设置 confirm=True 以继续。

    Args:
        session_id: 要清理的会话。
        confirm: 必须为 True 才能执行文件删除。
    """
    if not confirm:
        return _json({
            "error": "破坏性操作 — 请设置 confirm=True 以删除 Parquet 文件。",
            "session_id": session_id,
        })
    try:
        files_deleted, dir_path = manager.cleanup_session(session_id)
    except KeyError as e:
        return _json({"error": str(e)})

    return _json({
        "status": "ok",
        "session_id": session_id,
        "files_deleted": files_deleted,
        "directory": dir_path,
    })


# ---------------------------------------------------------------------------
# 分析工具
# ---------------------------------------------------------------------------

@mcp.tool()
def list_parquet_files(session_id: str = "") -> str:
    """列出可用的 Parquet 文件，包含行数和 schema 信息。

    Args:
        session_id: 要查询的会话。如果省略，使用唯一的活跃会话。
    """
    try:
        sess = manager.get(session_id or None)
    except (KeyError, ValueError) as e:
        return _json({"error": str(e)})

    pdir = sess.parquet_dir
    pq_files = sorted(pdir.glob("*.parquet"))
    if not pq_files:
        return _json({"error": f"在 {pdir} 中未找到 .parquet 文件"})

    con = sess.connection
    original_dir = os.getcwd()
    os.chdir(pdir)

    try:
        system_files = []
        class_files = []

        for pf in pq_files:
            name = pf.stem
            try:
                row_count = con.execute(
                    f"SELECT COUNT(*) FROM read_parquet('{pf.name}')"
                ).fetchone()[0]
                schema_rows = con.execute(
                    f"DESCRIBE SELECT * FROM read_parquet('{pf.name}')"
                ).fetchall()
                columns = [{"name": r[0], "type": r[1]} for r in schema_rows]
            except Exception:
                row_count = -1
                columns = []

            entry = {
                "file": pf.name,
                "row_count": row_count,
                "columns": columns,
            }

            if name.startswith("_"):
                system_files.append(entry)
            else:
                class_files.append(entry)

        class_files.sort(key=lambda x: x["row_count"], reverse=True)

        return _json({
            "session_id": sess.session_id,
            "parquet_dir": str(pdir),
            "total_files": len(pq_files),
            "system_files": system_files,
            "class_files": class_files,
        })
    finally:
        os.chdir(original_dir)


@mcp.tool()
def query_heap(
    sql: str,
    session_id: str = "",
    limit: int = DEFAULT_PAGE_SIZE,
    offset: int = 0,
) -> str:
    """对堆转储 Parquet 文件执行 DuckDB SQL 查询。

    结果支持分页。使用 limit/offset 翻阅大型结果集。
    使用 read_parquet('filename_pattern') 引用表。示例：
        SELECT * FROM read_parquet('java.lang.String_*.parquet')

    Args:
        sql: DuckDB SQL 查询语句。
        session_id: 要查询的会话。如果省略，使用唯一的活跃会话。
        limit: 每页返回的最大行数。默认 1000。
        offset: 跳过的行数。默认 0。
    """
    try:
        sess = manager.get(session_id or None)
    except (KeyError, ValueError) as e:
        return _json({"error": str(e)})

    con = sess.connection
    original_dir = os.getcwd()
    os.chdir(sess.parquet_dir)

    try:
        # 用分页包装用户的查询
        paginated_sql = f"SELECT * FROM ({sql}) LIMIT {limit + 1} OFFSET {offset}"
        result = con.execute(paginated_sql)
        columns = [desc[0] for desc in result.description]
        rows = result.fetchall()

        has_more = len(rows) > limit
        if has_more:
            rows = rows[:limit]

        data = [dict(zip(columns, row)) for row in rows]

        response = {
            "session_id": sess.session_id,
            "columns": columns,
            "row_count": len(data),
            "offset": offset,
            "limit": limit,
            "has_more": has_more,
            "rows": data,
        }
        if has_more:
            response["next_offset"] = offset + limit
        return _json(response)
    except Exception as e:
        return _json({"error": str(e)})
    finally:
        os.chdir(original_dir)


@mcp.tool()
def analyze_heap(
    session_id: str = "",
    waste: bool = True,
    waste_tier: int = 2,
    top_n: int = 30,
) -> str:
    """运行自动化堆分析，包括内存浪费检测。

    Args:
        session_id: 要分析的会话。如果省略，使用唯一的活跃会话。
        waste: 是否启用内存浪费分析。
        waste_tier: 分析深度：1=快速（5 项检查），2=默认（11 项检查），3=全面（13 项检查）。
        top_n: 显示的顶部类型数量。
    """
    try:
        sess = manager.get(session_id or None)
    except (KeyError, ValueError) as e:
        return _json({"error": str(e)})

    con = sess.connection
    resolver = ParquetResolver(str(sess.parquet_dir))
    original_dir = os.getcwd()
    os.chdir(sess.parquet_dir)

    try:
        result = {
            "session_id": sess.session_id,
            "parquet_dir": str(sess.parquet_dir),
        }

        summary = run_summary(con, resolver)
        if summary:
            result["summary"] = summary[0]

        result["top_types"] = run_top_types(con, resolver, limit=top_n)
        result["categories"] = run_category_breakdown(con, resolver)
        result["byte_array_distribution"] = run_byte_array_distribution(con, resolver)
        result["large_byte_arrays"] = run_large_byte_arrays(con, resolver)

        if waste:
            findings = run_waste_analysis(con, resolver, max_tier=waste_tier)
            total_waste = sum(f.estimated_waste_bytes for f in findings)
            result["waste_findings"] = [
                {
                    "check_name": f.check_name,
                    "tier": f.tier,
                    "severity": f.severity,
                    "affected_count": f.affected_count,
                    "estimated_waste_bytes": f.estimated_waste_bytes,
                    "estimated_waste_human": format_bytes(f.estimated_waste_bytes),
                    "details": f.details,
                    "recommendation": f.recommendation,
                    "sub_findings": f.sub_findings,
                }
                for f in findings
            ]
            result["total_estimated_waste"] = format_bytes(total_waste)
            result["total_estimated_waste_bytes"] = total_waste

        return _json(result)
    except Exception as e:
        return _json({"error": str(e)})
    finally:
        os.chdir(original_dir)


# ---------------------------------------------------------------------------
# 入口点
# ---------------------------------------------------------------------------

def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
