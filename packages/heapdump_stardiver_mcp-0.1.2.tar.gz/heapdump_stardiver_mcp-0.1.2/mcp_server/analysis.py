# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Zac Policzer

"""分析功能的公共导出层。

所有分析逻辑内联在 _analysis_impl 模块中，以便作为 PyPI 包正常分发。
"""

from ._analysis_impl import (  # noqa: F401
    ParquetResolver,
    WasteFinding,
    classify_severity,
    format_bytes,
    query,
    try_query,
    run_summary,
    run_top_types,
    run_category_breakdown,
    run_byte_array_distribution,
    run_large_byte_arrays,
    run_waste_analysis,
    ALL_CHECKS,
)
