from .ms_cli import main


if __name__ == "__main__":
    main()
