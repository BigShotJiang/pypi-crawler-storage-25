# alumnium-cli-darwin-x64

Alumnium CLI binary package for darwin-x64. See [the main `alumnium` package page](https://pypi.org/project/alumnium/) for more details.
