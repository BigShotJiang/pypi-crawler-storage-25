# alumnium-cli-linux-arm64

Alumnium CLI binary package for linux-arm64. See [the main `alumnium` package page](https://pypi.org/project/alumnium/) for more details.
