from pathlib import Path

BIN_NAME = "alumnium-0.20.0-alpha.11-windows-arm64.exe"


def bin_path() -> Path:
    return Path(__file__).with_name(BIN_NAME)


__all__ = ["bin_path"]
