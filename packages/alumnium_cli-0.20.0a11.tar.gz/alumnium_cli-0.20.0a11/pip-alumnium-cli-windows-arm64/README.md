# alumnium-cli-windows-arm64

Alumnium CLI binary package for windows-arm64. See [the main `alumnium` package page](https://pypi.org/project/alumnium/) for more details.
