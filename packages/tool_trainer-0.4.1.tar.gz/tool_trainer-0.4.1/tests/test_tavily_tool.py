"""SqliteSearchCache + ReplaySearchTool."""

from __future__ import annotations

from pathlib import Path

import pytest

from tool_trainer.tools import CacheMiss, ReplaySearchTool, SqliteSearchCache


def test_cache_hit_miss_overwrite(tmp_path: Path) -> None:
    cache = SqliteSearchCache(tmp_path / "c.sqlite")
    params = {"max_results": 5, "search_depth": "basic", "include_raw_content": False}

    assert cache.get("foo", params) is None

    cache.put("foo", params, {"results": [{"title": "A"}]})
    got = cache.get("foo", params)
    assert got == {"results": [{"title": "A"}]}

    cache.put("foo", params, {"results": [{"title": "B"}]})
    assert cache.get("foo", params) == {"results": [{"title": "B"}]}

    # Different params → different key, different cache slot.
    other = dict(params, max_results=3)
    assert cache.get("foo", other) is None


def test_replay_raises_on_miss(tmp_path: Path) -> None:
    cache = SqliteSearchCache(tmp_path / "c.sqlite")
    tool = ReplaySearchTool(cache)
    with pytest.raises(CacheMiss):
        tool.search("never-cached-query")


def test_replay_returns_cached(tmp_path: Path) -> None:
    cache = SqliteSearchCache(tmp_path / "c.sqlite")
    params = {"max_results": 5, "search_depth": "basic", "include_raw_content": False}
    cache.put("x", params, {"results": [{"title": "Hit"}]})
    tool = ReplaySearchTool(cache)
    assert tool.search("x", max_results=5) == {"results": [{"title": "Hit"}]}
