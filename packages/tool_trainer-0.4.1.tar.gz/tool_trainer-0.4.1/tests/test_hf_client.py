"""HFInferenceClient behavior with a mocked transformers+torch stack.

Hermetic: no model downloads, no torch imports at test-collect time beyond what
the patches provide."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock


def _install_fake_torch() -> None:
    """Install a fake `torch` module into sys.modules so HFInferenceClient.__init__
    can import it without the real torch being installed."""
    fake_torch = types.ModuleType("torch")
    fake_torch.bfloat16 = "bfloat16_dtype"
    fake_torch.float16 = "float16_dtype"
    fake_torch.float32 = "float32_dtype"

    cuda_ns = types.SimpleNamespace(is_available=lambda: False)
    fake_torch.cuda = cuda_ns

    backends_ns = types.ModuleType("torch.backends")
    backends_ns.mps = types.SimpleNamespace(is_available=lambda: False)
    fake_torch.backends = backends_ns

    class _FakeInferenceMode:
        def __enter__(self):
            return self

        def __exit__(self, *exc):
            return False

    fake_torch.inference_mode = _FakeInferenceMode

    sys.modules["torch"] = fake_torch
    sys.modules["torch.backends"] = backends_ns


def _install_fake_transformers(tokenizer, model) -> None:
    """Install a fake `transformers` module so the lazy import in hf.py works."""
    fake_trf = types.ModuleType("transformers")
    fake_trf.AutoTokenizer = MagicMock()
    fake_trf.AutoTokenizer.from_pretrained = MagicMock(return_value=tokenizer)
    fake_trf.AutoModelForCausalLM = MagicMock()
    fake_trf.AutoModelForCausalLM.from_pretrained = MagicMock(return_value=model)
    sys.modules["transformers"] = fake_trf


def _fake_tokenizer() -> MagicMock:
    tok = MagicMock()
    tok.pad_token_id = 0
    tok.eos_token_id = 0

    class _FakeTensor:
        """Mimics the bits of torch.Tensor that HFInferenceClient uses."""

        def __init__(self, length: int, values=None):
            self._length = length
            self._values = values or list(range(length))
            self.shape = (1, length)

        def to(self, device):
            return self

        def __getitem__(self, idx):
            # output_ids[0, input_len:] → slice the flat list.
            if isinstance(idx, tuple) and len(idx) == 2 and idx[0] == 0:
                s = idx[1]
                if isinstance(s, slice):
                    sub = self._values[s]
                    out = _FakeTensor(len(sub), sub)
                    return out
            raise NotImplementedError(f"_FakeTensor slice {idx!r}")

    tok.apply_chat_template.return_value = _FakeTensor(5)
    tok.decode.return_value = ' assistant: {"judgment": "CORRECT"}'
    tok._FakeTensor = _FakeTensor  # expose for test setup
    return tok


def _fake_model(generated_ids) -> MagicMock:
    model = MagicMock()
    model.device = "cpu"
    model.generate.return_value = generated_ids
    model.eval.return_value = model
    model.to.return_value = model
    return model


def test_hf_client_generate_basic() -> None:
    """Happy path: messages → tokenize → generate → decode; usage is populated."""
    _install_fake_torch()

    tok = _fake_tokenizer()
    gen = tok._FakeTensor(15, list(range(15)))
    model = _fake_model(gen)
    _install_fake_transformers(tok, model)

    from tool_trainer.llm.hf import HFInferenceClient

    client = HFInferenceClient(
        base_model="fake/base-model",
        device="cpu",
        dtype="bfloat16",
        max_new_tokens=32,
    )
    result = client.complete([{"role": "user", "content": "hi"}])

    # Chat template was applied.
    assert tok.apply_chat_template.called
    tc_kwargs = tok.apply_chat_template.call_args.kwargs
    assert tc_kwargs["add_generation_prompt"] is True

    # Leading "assistant:" stripped by post-processing.
    assert result["content"].startswith('{"judgment"')
    assert result["tool_calls"] == []
    # Usage: input_len=5, output_len=15-5=10.
    assert result["usage"]["prompt_tokens"] == 5
    assert result["usage"]["completion_tokens"] == 10


def test_hf_client_injects_json_hint_when_requested() -> None:
    _install_fake_torch()
    tok = _fake_tokenizer()
    gen = tok._FakeTensor(7, list(range(7)))
    model = _fake_model(gen)
    _install_fake_transformers(tok, model)

    from tool_trainer.llm.hf import HFInferenceClient

    client = HFInferenceClient(base_model="fake", device="cpu", dtype="float32")
    client.complete(
        [{"role": "user", "content": "What is 2+2?"}],
        response_format={"type": "json_object"},
    )

    sent_messages = tok.apply_chat_template.call_args.args[0]
    assert "valid JSON" in sent_messages[-1]["content"]
    assert "What is 2+2?" in sent_messages[-1]["content"]


def test_hf_client_handles_batch_encoding_return() -> None:
    """transformers 5.x returns a BatchEncoding (dict-like) from apply_chat_template
    when tokenize=True + return_tensors='pt'. The client must unwrap it rather
    than calling .shape on the dict."""
    _install_fake_torch()
    tok = _fake_tokenizer()
    inner = tok._FakeTensor(8, list(range(8)))

    class _FakeBatchEncoding:
        """Mimics transformers.BatchEncoding: dict-like with .input_ids plus
        __getitem__."""

        input_ids = inner

        def __getitem__(self, key):
            return inner if key == "input_ids" else None

    tok.apply_chat_template.return_value = _FakeBatchEncoding()

    gen = tok._FakeTensor(18, list(range(18)))
    model = _fake_model(gen)
    _install_fake_transformers(tok, model)

    from tool_trainer.llm.hf import HFInferenceClient

    client = HFInferenceClient(base_model="fake", device="cpu", dtype="float32")
    result = client.complete([{"role": "user", "content": "hi"}])
    # 8 prompt tokens, 18-8=10 new tokens.
    assert result["usage"]["prompt_tokens"] == 8
    assert result["usage"]["completion_tokens"] == 10


def test_hf_client_adapter_path_loads_peft() -> None:
    _install_fake_torch()
    tok = _fake_tokenizer()
    gen = tok._FakeTensor(6)
    model = _fake_model(gen)
    _install_fake_transformers(tok, model)

    # Fake peft module.
    fake_peft = types.ModuleType("peft")
    peft_model_cls = MagicMock()
    peft_model_cls.from_pretrained.return_value = model
    fake_peft.PeftModel = peft_model_cls
    sys.modules["peft"] = fake_peft

    from tool_trainer.llm.hf import HFInferenceClient

    HFInferenceClient(
        base_model="fake/base",
        adapter_path="./some/adapter",
        device="cpu",
        dtype="float32",
    )

    peft_model_cls.from_pretrained.assert_called_once()
    args = peft_model_cls.from_pretrained.call_args.args
    assert args[1] == "./some/adapter"
