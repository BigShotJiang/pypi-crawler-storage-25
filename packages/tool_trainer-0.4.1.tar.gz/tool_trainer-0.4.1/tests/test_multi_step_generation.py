"""Multi-step critique loop — agent behavior when `max_search_steps > 1`."""

from __future__ import annotations

import json

from tool_trainer.generate import generate_trajectory
from tool_trainer.schemas import GenerationConfig, RawQuestion


def _search_router() -> str:
    return json.dumps({"decision": "search", "reason": "freshness"})


def test_critic_says_answer_first_iteration(fake_llm, fake_search) -> None:
    """Critic stops the loop after the first search → 4 messages, 1 search, no critic msg."""
    fake_llm.queue(
        _search_router(),
        json.dumps({"query": "q1 2026"}),
        json.dumps({"decision": "answer", "reason": "results sufficient"}),
        "final answer",
    )

    q = RawQuestion(id="q1", question="When was X elected?")
    traj = generate_trajectory(
        q,
        teacher=fake_llm,
        search_tool=fake_search,
        generation=GenerationConfig(max_search_steps=3),
    )

    assert traj.labels.num_search_steps == 1
    assert len(traj.messages) == 4  # user, tool_call, tool, answer
    # No critic content message in the trajectory when critic says answer immediately.
    assert all(
        not (
            m.role == "assistant"
            and m.tool_call is None
            and isinstance(m.content, str)
            and m.content.startswith("Critique:")
        )
        for m in traj.messages
    )
    assert fake_search.calls == [("q1 2026", 5)]


def test_critic_re_searches_once_then_answers(fake_llm, fake_search) -> None:
    """Critic says re_search once, then answer → 2 searches, 1 critic content message."""
    fake_llm.queue(
        _search_router(),
        json.dumps({"query": "first query"}),  # query_writer #1
        json.dumps({"decision": "re_search", "reason": "no year in results"}),  # critic #1
        json.dumps({"query": "refined query 2026"}),  # query_writer #2
        json.dumps({"decision": "answer", "reason": "now sufficient"}),  # critic #2
        "final answer",  # answerer
    )

    q = RawQuestion(id="q2", question="?")
    traj = generate_trajectory(
        q,
        teacher=fake_llm,
        search_tool=fake_search,
        generation=GenerationConfig(max_search_steps=3),
    )

    assert traj.labels.num_search_steps == 2
    # user, tool_call_1, tool_1, critic_content, tool_call_2, tool_2, answer = 7
    assert len(traj.messages) == 7
    critic_msgs = [
        m
        for m in traj.messages
        if m.role == "assistant"
        and m.tool_call is None
        and isinstance(m.content, str)
        and m.content.startswith("Critique:")
    ]
    assert len(critic_msgs) == 1
    assert "no year in results" in critic_msgs[0].content
    assert fake_search.calls == [("first query", 5), ("refined query 2026", 5)]


def test_max_search_steps_hard_caps_loop(fake_llm, fake_search) -> None:
    """max_search_steps=3, critic always says re_search → exactly 3 searches, 2 critic msgs."""
    fake_llm.queue(
        _search_router(),
        json.dumps({"query": "q1"}),  # qw #1
        json.dumps({"decision": "re_search", "reason": "need more"}),  # critic #1
        json.dumps({"query": "q2"}),  # qw #2
        json.dumps({"decision": "re_search", "reason": "still not enough"}),  # critic #2
        json.dumps({"query": "q3"}),  # qw #3
        # No critic call after the 3rd search — hard cap kicks in before it would fire.
        "final answer",  # answerer
    )

    q = RawQuestion(id="q3", question="?")
    traj = generate_trajectory(
        q,
        teacher=fake_llm,
        search_tool=fake_search,
        generation=GenerationConfig(max_search_steps=3),
    )

    assert traj.labels.num_search_steps == 3
    # user + 3×(tool_call, tool) + 2 critic msgs + answer = 1 + 6 + 2 + 1 = 10
    assert len(traj.messages) == 10
    critic_msgs = [
        m
        for m in traj.messages
        if m.role == "assistant"
        and m.tool_call is None
        and isinstance(m.content, str)
        and m.content.startswith("Critique:")
    ]
    assert len(critic_msgs) == 2
    assert [c[0] for c in fake_search.calls] == ["q1", "q2", "q3"]


def test_malformed_critic_output_treated_as_answer(fake_llm, fake_search) -> None:
    """Critic returns garbage → we stop rather than loop forever."""
    fake_llm.queue(
        _search_router(),
        json.dumps({"query": "q1"}),
        "not json at all",  # critic — unparseable
        "final answer",  # answerer
    )

    q = RawQuestion(id="q4", question="?")
    traj = generate_trajectory(
        q,
        teacher=fake_llm,
        search_tool=fake_search,
        generation=GenerationConfig(max_search_steps=3),
    )

    # Fail-closed: critic parse failure → treat as "answer", no further search.
    assert traj.labels.num_search_steps == 1
    assert fake_search.calls == [("q1", 5)]


def test_re_search_without_reason_falls_back_to_answer(fake_llm, fake_search) -> None:
    """A critic that returns {decision: re_search} with no reason is useless — force-stop."""
    fake_llm.queue(
        _search_router(),
        json.dumps({"query": "q1"}),
        json.dumps({"decision": "re_search", "reason": ""}),  # empty reason
        "final answer",
    )

    q = RawQuestion(id="q5", question="?")
    traj = generate_trajectory(
        q,
        teacher=fake_llm,
        search_tool=fake_search,
        generation=GenerationConfig(max_search_steps=3),
    )

    assert traj.labels.num_search_steps == 1
