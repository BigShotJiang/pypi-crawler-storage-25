"""End-to-end single-round trajectory generation with scripted LLM + fake SearchTool.

These tests pin `max_search_steps=1` to exercise the degenerate single-search case.
Multi-step coverage lives in `test_multi_step_generation.py`."""

from __future__ import annotations

import json

from tool_trainer.generate import generate_trajectory
from tool_trainer.schemas import GenerationConfig, RawQuestion


def _single_step() -> GenerationConfig:
    return GenerationConfig(max_search_steps=1)


def test_search_path_emits_4_messages(fake_llm, fake_search) -> None:
    # Router → search; query_writer → query; answerer → answer
    fake_llm.queue(
        json.dumps({"decision": "search", "reason": "freshness"}),
        json.dumps({"query": "current president of Argentina 2026"}),
        "The current president of Argentina is Example Name.",
    )

    q = RawQuestion(id="q1", question="Who is the current president of Argentina?")
    traj = generate_trajectory(
        q, teacher=fake_llm, search_tool=fake_search, generation=_single_step()
    )

    assert traj.id == "q1"
    assert traj.labels.search_used is True
    assert traj.labels.search_reason == "freshness"
    assert traj.labels.num_search_steps == 1
    assert len(traj.messages) == 4

    assert traj.messages[0].role == "user"
    assert traj.messages[1].role == "assistant"
    assert traj.messages[1].tool_call is not None
    assert traj.messages[1].tool_call.name == "web_search"
    assert traj.messages[1].tool_call.arguments["query"] == "current president of Argentina 2026"

    assert traj.messages[2].role == "tool"
    assert traj.messages[2].name == "web_search"
    assert isinstance(traj.messages[2].content, dict)
    assert "results" in traj.messages[2].content

    assert traj.messages[3].role == "assistant"
    assert traj.messages[3].content == "The current president of Argentina is Example Name."

    # Fake search got called exactly once with the teacher's query.
    assert fake_search.calls == [("current president of Argentina 2026", 5)]


def test_no_search_path_emits_2_messages(fake_llm, fake_search) -> None:
    fake_llm.queue(
        json.dumps({"decision": "no_search", "reason": "arithmetic"}),
        "408",
    )

    q = RawQuestion(id="q2", question="What is 17 * 24?")
    traj = generate_trajectory(
        q, teacher=fake_llm, search_tool=fake_search, generation=_single_step()
    )

    assert traj.labels.search_used is False
    assert traj.labels.search_reason == "arithmetic"
    assert traj.labels.num_search_steps == 0
    assert len(traj.messages) == 2
    assert traj.messages[0].role == "user"
    assert traj.messages[1].role == "assistant"
    assert traj.messages[1].content == "408"
    assert fake_search.calls == []


def test_router_handles_malformed_json_defaults_to_search(fake_llm, fake_search) -> None:
    fake_llm.queue("not json", json.dumps({"query": "q"}), "answer")
    q = RawQuestion(id="q3", question="?")
    traj = generate_trajectory(
        q, teacher=fake_llm, search_tool=fake_search, generation=_single_step()
    )
    # Default is to search on parse failure (safer — don't silently suppress retrieval).
    assert traj.labels.search_used is True


def test_non_dict_json_response_treated_as_empty(fake_llm, fake_search) -> None:
    """Small/under-trained local models sometimes return a bare string or list
    instead of a JSON object. Those must not crash downstream parsing."""
    # Router returns a plain string (valid JSON but not a dict).
    fake_llm.queue(json.dumps("search"))
    # Query writer also returns a string — same problem.
    fake_llm.queue(json.dumps("just a query string"))
    fake_llm.queue("final answer")

    q = RawQuestion(id="q-bad-json", question="?")
    traj = generate_trajectory(
        q, teacher=fake_llm, search_tool=fake_search, generation=_single_step()
    )
    # Router fell back to search + freshness.
    assert traj.labels.search_used is True
    # query_writer fallback: reuse the question text when parse fails.
    assert "?" in str(traj.messages[1].tool_call.arguments["query"])


def test_trajectory_serializes_without_none_fields(fake_llm, fake_search) -> None:
    fake_llm.queue(
        json.dumps({"decision": "search", "reason": "freshness"}),
        json.dumps({"query": "q"}),
        "answer",
    )
    q = RawQuestion(id="q4", question="?")
    traj = generate_trajectory(
        q, teacher=fake_llm, search_tool=fake_search, generation=_single_step()
    )
    compact = traj.model_dump_compact()
    # Assistant message carrying tool_call must NOT have a content:null field.
    assert "content" not in compact["messages"][1]
    # Assistant final message must NOT carry tool_call.
    assert "tool_call" not in compact["messages"][3]
