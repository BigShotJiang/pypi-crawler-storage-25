"""`tt eval` CLI smoke tests — hermetic via OpenAIClient + TavilyClient patching."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from tool_trainer.cli import app

runner = CliRunner()


class _StubbedClients:
    """Context manager that replaces OpenAIClient and TavilyClient with
    scripted fakes so `tt eval` runs end-to-end without network."""

    def __init__(self, teacher_responses: list[str], judge_responses: list[str]) -> None:
        self._teacher_responses = teacher_responses
        self._judge_responses = judge_responses

    def __enter__(self) -> _StubbedClients:
        self._patches = []

        # Stub OpenAI client so both teacher and judge use the same underlying factory,
        # but each gets its own response queue in order of construction.
        response_queues = [self._teacher_responses, self._judge_responses]

        def fake_openai_client(api_key: str, model: str, temperature: float = 0.2):
            queue = response_queues.pop(0)

            class _Fake:
                def __init__(self, q):
                    self._q = list(q)

                def complete(self, messages, **kwargs):
                    if not self._q:
                        raise RuntimeError("fake OpenAIClient out of scripted responses")
                    content = self._q.pop(0)
                    return {"content": content, "tool_calls": [], "usage": {}}

            return _Fake(queue)

        # Patch OpenAIClient at origin — the resolver imports it lazily inside
        # resolve_llm, so patching cli.OpenAIClient no longer intercepts.
        p1 = patch("tool_trainer.llm.openai.OpenAIClient", side_effect=fake_openai_client)
        self._patches.append(p1)
        p1.start()

        # Stub Tavily client — returns an empty results payload.
        # Patch at origin because TavilyClient is lazy-imported inside TavilySearchTool.
        fake_tavily = MagicMock()
        fake_tavily.search.return_value = {"results": []}
        p2 = patch("tavily.TavilyClient", return_value=fake_tavily)
        self._patches.append(p2)
        p2.start()

        return self

    def __exit__(self, *exc) -> None:
        for p in self._patches:
            p.stop()


def test_eval_end_to_end(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.setenv("TAVILY_API_KEY", "tvly-test")
    monkeypatch.chdir(tmp_path)

    # Minimal config.
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        "tool:\n  cache_path: ./cache.sqlite\nteacher:\n  model: test-teacher\n"
        "evaluation:\n  judge_model: test-judge\n",
        encoding="utf-8",
    )
    eval_file = tmp_path / "eval.jsonl"
    eval_file.write_text(
        '{"id":"e1","question":"What is 17 * 24?","answer":"408","metadata":{"requires_search":false}}\n',
        encoding="utf-8",
    )
    output = tmp_path / "out"

    teacher_responses = [
        json.dumps({"decision": "no_search", "reason": "arithmetic"}),
        "408",
    ]
    judge_responses = [json.dumps({"judgment": "CORRECT", "reason": "exact match"})]

    with _StubbedClients(teacher_responses, judge_responses):
        result = runner.invoke(
            app,
            [
                "eval",
                "--config",
                str(cfg),
                "--benchmark",
                f"local:{eval_file}",
                "--output",
                str(output),
                "--cache",
                "off",
            ],
        )

    assert result.exit_code == 0, result.output
    assert (output / "summary.json").exists()
    assert (output / "failures.jsonl").exists()
    assert (output / "report.md").exists()

    summary = json.loads((output / "summary.json").read_text())
    assert summary["n"] == 1
    assert summary["n_correct"] == 1
    assert summary["answer_accuracy"] == 1.0
    assert summary["benchmark"] == "local"
    # Summary now stores the full model spec (e.g. 'openai:test-teacher') instead
    # of the bare name, so reports are self-describing regardless of backend.
    assert summary["teacher_model"] == "openai:test-teacher"
    assert summary["judge_model"] == "openai:test-judge"


def test_eval_rejects_unknown_benchmark(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.setenv("TAVILY_API_KEY", "tvly-test")
    cfg = tmp_path / "config.yaml"
    cfg.write_text("teacher:\n  model: test\n", encoding="utf-8")
    result = runner.invoke(
        app,
        [
            "eval",
            "--config",
            str(cfg),
            "--benchmark",
            "not-a-benchmark",
            "--output",
            str(tmp_path / "out"),
        ],
    )
    assert result.exit_code != 0
