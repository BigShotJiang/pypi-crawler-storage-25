"""Model-spec parsing and LLMClient resolution."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from tool_trainer.llm import parse_spec, resolve_llm


def test_parse_openai_spec() -> None:
    scheme, kwargs = parse_spec("openai:gpt-4o-mini")
    assert scheme == "openai"
    assert kwargs == {"model": "gpt-4o-mini"}


def test_parse_hf_base_only() -> None:
    scheme, kwargs = parse_spec("hf:Qwen/Qwen2.5-7B-Instruct")
    assert scheme == "hf"
    assert kwargs == {"base_model": "Qwen/Qwen2.5-7B-Instruct"}


def test_parse_hf_with_lora() -> None:
    scheme, kwargs = parse_spec("hf:Qwen/Qwen2.5-7B-Instruct+lora:./outputs/checkpoints/sft-001")
    assert scheme == "hf"
    assert kwargs == {
        "base_model": "Qwen/Qwen2.5-7B-Instruct",
        "adapter_path": "./outputs/checkpoints/sft-001",
    }


def test_parse_hf_local_path() -> None:
    scheme, kwargs = parse_spec("hf:./my-local-model")
    assert scheme == "hf"
    assert kwargs == {"base_model": "./my-local-model"}


def test_parse_unknown_scheme_raises() -> None:
    with pytest.raises(ValueError, match="Unknown model-spec scheme"):
        parse_spec("anthropic:claude-opus-4")


def test_parse_no_colon_raises() -> None:
    with pytest.raises(ValueError, match="Invalid model spec"):
        parse_spec("gpt-4o-mini")


def test_resolve_openai_requires_api_key() -> None:
    with pytest.raises(ValueError, match="OPENAI_API_KEY"):
        resolve_llm("openai:gpt-4o-mini")


def test_resolve_openai_builds_client() -> None:
    # Patch at origin since resolve_llm does a lazy local import.
    with patch("tool_trainer.llm.openai.OpenAIClient") as fake_client:
        resolve_llm("openai:gpt-4o-mini", openai_api_key="sk-test")
    fake_client.assert_called_once()
    _, kwargs = fake_client.call_args
    assert kwargs["api_key"] == "sk-test"
    assert kwargs["model"] == "gpt-4o-mini"


def test_resolve_hf_builds_client_with_adapter() -> None:
    with patch("tool_trainer.llm.hf.HFInferenceClient") as fake_client:
        resolve_llm(
            "hf:Qwen/Qwen2.5-7B-Instruct+lora:./adapter",
            temperature=0.1,
        )
    fake_client.assert_called_once()
    _, kwargs = fake_client.call_args
    assert kwargs["base_model"] == "Qwen/Qwen2.5-7B-Instruct"
    assert kwargs["adapter_path"] == "./adapter"
    assert kwargs["temperature"] == 0.1


def test_resolve_hf_no_openai_key_needed() -> None:
    """hf: specs must work without an OpenAI key — this is the whole point of local inference."""
    with patch("tool_trainer.llm.hf.HFInferenceClient") as fake_client:
        resolve_llm("hf:./my-model")  # No openai_api_key passed.
    fake_client.assert_called_once()
