"""HTML report renders correctly for summary + failures."""

from __future__ import annotations

from pathlib import Path

from tool_trainer.eval.report import write_html_report
from tool_trainer.schemas import (
    EvalRow,
    EvalScores,
    EvalSummary,
    Message,
    ToolCall,
    Trajectory,
    TrajectoryLabels,
)


def _traj(search: bool, answer: str = "ans") -> Trajectory:
    if not search:
        return Trajectory(
            id="t",
            messages=[
                Message(role="user", content="Q?"),
                Message(role="assistant", content=answer),
            ],
            labels=TrajectoryLabels(search_used=False, num_search_steps=0),
        )
    return Trajectory(
        id="t",
        messages=[
            Message(role="user", content="Q?"),
            Message(
                role="assistant",
                tool_call=ToolCall(name="web_search", arguments={"query": "q"}),
            ),
            Message(
                role="tool",
                name="web_search",
                content={"results": [{"title": "T", "url": "https://example.com"}]},
            ),
            Message(role="assistant", content=answer),
        ],
        labels=TrajectoryLabels(search_used=True, num_search_steps=1),
    )


def test_html_report_contains_metrics_and_failures(tmp_path: Path) -> None:
    rows = [
        EvalRow(
            id="e1",
            question="What is 17*24?",
            gold_answer="408",
            trajectory=_traj(search=False, answer="408"),
            scores=EvalScores(answer_correct=True, answer_judgment="correct", num_searches=0),
            latency_ms=100,
        ),
        EvalRow(
            id="e2",
            question="Who won the 2024 Nobel Prize?",
            gold_answer="Hinton and Hopfield",
            trajectory=_traj(search=True, answer="nope"),
            scores=EvalScores(
                answer_correct=False,
                answer_judgment="incorrect",
                answer_judge_reason="does not match gold",
                num_searches=1,
            ),
            latency_ms=200,
        ),
    ]
    summary = EvalSummary(
        benchmark="local",
        teacher_model="gpt-4o-mini",
        judge_model="gpt-4o-mini",
        n=2,
        answer_accuracy=0.5,
        search_decision_accuracy=None,
        avg_searches_per_example=0.5,
        avg_latency_ms=150,
        total_tokens_in=1000,
        total_tokens_out=50,
        n_correct=1,
        n_incorrect=1,
    )

    path = write_html_report(tmp_path, summary, rows)
    assert path.exists()
    html = path.read_text(encoding="utf-8")

    # Title + benchmark.
    assert "Eval report — local" in html
    # Metric table.
    assert "answer_accuracy" in html
    assert "search_decision_accuracy" in html
    # Both row IDs appear — correct one shouldn't be in failures, but HTML doesn't need to list correct rows.
    # What matters: the incorrect one (e2) is in the failure section, correct (e1) is not.
    assert "e2" in html
    # Judge reason for e2 shows up.
    assert "does not match gold" in html
    # Tool-call trajectory is rendered.
    assert "web_search" in html
    # Inline CSS is present (no external assets).
    assert "<style>" in html
    # Self-contained — no links to stylesheets or JS.
    assert "<link " not in html
    assert "<script " not in html


def test_html_report_with_no_failures(tmp_path: Path) -> None:
    rows = [
        EvalRow(
            id="e1",
            question="Q?",
            gold_answer="A",
            trajectory=_traj(search=False, answer="A"),
            scores=EvalScores(answer_correct=True, answer_judgment="correct", num_searches=0),
            latency_ms=50,
        ),
    ]
    summary = EvalSummary(
        benchmark="local",
        teacher_model="t",
        judge_model="j",
        n=1,
        answer_accuracy=1.0,
        avg_searches_per_example=0.0,
        avg_latency_ms=50,
        n_correct=1,
    )
    path = write_html_report(tmp_path, summary, rows)
    html = path.read_text(encoding="utf-8")
    # No failures section when there are none.
    assert "Worst failures" not in html
    # Still renders the summary.
    assert "1.000" in html
