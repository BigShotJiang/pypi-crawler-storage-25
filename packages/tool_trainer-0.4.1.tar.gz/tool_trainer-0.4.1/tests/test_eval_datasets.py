"""Benchmark loader tests — hermetic (mocks the HF dataset for SimpleQA,
uses an in-memory CSV fixture for BrowseComp)."""

from __future__ import annotations

import csv
from pathlib import Path
from unittest.mock import patch

import pytest

from tool_trainer.eval.datasets import (
    BrowseCompLoader,
    LocalJsonlLoader,
    SimpleQALoader,
    resolve_loader,
)
from tool_trainer.eval.datasets.browsecomp import decrypt_field, encrypt_field

# ----------------------------------------------------------------------------
# LocalJsonlLoader
# ----------------------------------------------------------------------------


def test_local_loader_reads_rows(tmp_path: Path) -> None:
    path = tmp_path / "eval.jsonl"
    path.write_text(
        '{"id":"q1","question":"Q?","answer":"A"}\n'
        '{"id":"q2","question":"Q2?","answer":"A2","metadata":{"requires_search":true}}\n',
        encoding="utf-8",
    )
    loader = LocalJsonlLoader(path)
    rows = list(loader.load())
    assert len(rows) == 2
    assert rows[0].id == "q1"
    assert rows[1].metadata["requires_search"] is True


def test_local_loader_respects_limit(tmp_path: Path) -> None:
    path = tmp_path / "eval.jsonl"
    path.write_text(
        "\n".join(f'{{"id":"q{i}","question":"?"}}' for i in range(5)),
        encoding="utf-8",
    )
    assert len(list(LocalJsonlLoader(path).load(limit=3))) == 3


def test_local_loader_missing_file(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        LocalJsonlLoader(tmp_path / "missing.jsonl")


# ----------------------------------------------------------------------------
# SimpleQALoader — mock the HF dataset
# ----------------------------------------------------------------------------


def test_simpleqa_maps_rows_correctly() -> None:
    fake_rows = [
        {
            "metadata": {"topic": "Science", "answer_type": "Person", "urls": ["u1"]},
            "problem": "Who?",
            "answer": "Alice",
        },
        {
            "metadata": "{'topic': 'History', 'answer_type': 'Date', 'urls': []}",
            "problem": "When?",
            "answer": "1492",
        },
    ]
    with patch("datasets.load_dataset", return_value=fake_rows):
        rows = list(SimpleQALoader().load())

    assert len(rows) == 2
    assert rows[0].id == "simpleqa_00000"
    assert rows[0].question == "Who?"
    assert rows[0].answer == "Alice"
    assert rows[0].metadata["benchmark"] == "simpleqa"
    assert rows[0].metadata["topic"] == "Science"
    # String-formatted metadata also parsed:
    assert rows[1].metadata["topic"] == "History"


# ----------------------------------------------------------------------------
# BrowseCompLoader — encrypt/decrypt is symmetric; build a CSV fixture
# ----------------------------------------------------------------------------


def test_browsecomp_decrypt_roundtrip() -> None:
    canary = "secret-canary-string"
    plaintext = "What was the score of game 7 of the 2016 NBA finals?"
    ciphertext = encrypt_field(plaintext, canary)
    assert decrypt_field(ciphertext, canary) == plaintext


def test_browsecomp_loader_reads_fixture(tmp_path: Path) -> None:
    canary = "canary-xyz"
    rows_plain = [
        ("What is the capital of France?", "Paris"),
        ("Who painted the Mona Lisa?", "Leonardo da Vinci"),
    ]
    csv_path = tmp_path / "browsecomp_fixture.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["problem", "answer", "canary"])
        writer.writeheader()
        for q, a in rows_plain:
            writer.writerow(
                {
                    "problem": encrypt_field(q, canary),
                    "answer": encrypt_field(a, canary),
                    "canary": canary,
                }
            )

    loader = BrowseCompLoader(csv_path=csv_path)
    rows = list(loader.load())
    assert len(rows) == 2
    assert rows[0].question == "What is the capital of France?"
    assert rows[0].answer == "Paris"
    assert rows[0].metadata["requires_search"] is True
    assert rows[0].metadata["benchmark"] == "browsecomp"
    assert rows[0].id == "browsecomp_00000"


# ----------------------------------------------------------------------------
# resolve_loader
# ----------------------------------------------------------------------------


def test_resolve_loader_local(tmp_path: Path) -> None:
    path = tmp_path / "eval.jsonl"
    path.write_text('{"id":"q1","question":"?"}\n', encoding="utf-8")
    loader = resolve_loader(f"local:{path}")
    assert isinstance(loader, LocalJsonlLoader)


def test_resolve_loader_simpleqa() -> None:
    assert isinstance(resolve_loader("simpleqa"), SimpleQALoader)


def test_resolve_loader_browsecomp() -> None:
    assert isinstance(resolve_loader("browsecomp"), BrowseCompLoader)


def test_resolve_loader_unknown() -> None:
    with pytest.raises(ValueError, match="Unknown --benchmark spec"):
        resolve_loader("not-a-benchmark")
