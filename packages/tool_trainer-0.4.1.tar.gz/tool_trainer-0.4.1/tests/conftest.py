"""Shared fakes for hermetic tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from tool_trainer.schemas import GenerationConfig


class FakeLLM:
    """Scripted LLM — returns queued responses in order. Each response is
    either a str (used as `content`) or a dict already matching the client return shape."""

    def __init__(self, responses: list[Any] | None = None) -> None:
        self.responses: list[Any] = list(responses or [])
        self.calls: list[dict[str, Any]] = []

    def queue(self, *responses: Any) -> None:
        self.responses.extend(responses)

    def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        response_format: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        self.calls.append(
            {"messages": messages, "tools": tools, "response_format": response_format}
        )
        if not self.responses:
            raise RuntimeError("FakeLLM ran out of scripted responses")
        r = self.responses.pop(0)
        if isinstance(r, str):
            return {"content": r, "tool_calls": []}
        return r


class FakeSearch:
    """Returns canned results for any query; records calls."""

    def __init__(self, results: dict[str, Any] | None = None) -> None:
        self._results = results or {
            "results": [
                {"title": "Example result", "url": "https://example.com", "content": "snippet"}
            ]
        }
        self.calls: list[tuple[str, int]] = []

    def search(self, query: str, max_results: int = 5) -> dict[str, Any]:
        self.calls.append((query, max_results))
        return self._results


@pytest.fixture
def fake_llm() -> FakeLLM:
    return FakeLLM()


@pytest.fixture
def fake_search() -> FakeSearch:
    return FakeSearch()


@pytest.fixture
def generation_config() -> GenerationConfig:
    return GenerationConfig()


@pytest.fixture
def router_search_json() -> str:
    return json.dumps({"decision": "search", "reason": "freshness"})


@pytest.fixture
def router_nosearch_json() -> str:
    return json.dumps({"decision": "no_search", "reason": "parametric_ok"})


@pytest.fixture
def query_writer_json() -> str:
    return json.dumps({"query": "current president of Argentina 2026"})


@pytest.fixture
def tmp_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """cd into a temp dir so .env loading, relative paths etc. don't bleed."""
    monkeypatch.chdir(tmp_path)
    return tmp_path
