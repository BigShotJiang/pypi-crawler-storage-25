"""Judge-based scoring and deterministic signal extraction."""

from __future__ import annotations

import json

from tool_trainer.eval.scorer import score_trajectory
from tool_trainer.schemas import Message, ToolCall, Trajectory, TrajectoryLabels


def _search_trajectory(answer: str = "The president is X.") -> Trajectory:
    return Trajectory(
        id="t",
        messages=[
            Message(role="user", content="Who is the current president of Argentina?"),
            Message(
                role="assistant",
                tool_call=ToolCall(
                    name="web_search", arguments={"query": "president argentina 2026"}
                ),
            ),
            Message(role="tool", name="web_search", content={"results": []}),
            Message(role="assistant", content=answer),
        ],
        labels=TrajectoryLabels(search_used=True, search_reason="freshness", num_search_steps=1),
    )


def _no_search_trajectory(answer: str = "408") -> Trajectory:
    return Trajectory(
        id="t",
        messages=[
            Message(role="user", content="What is 17 * 24?"),
            Message(role="assistant", content=answer),
        ],
        labels=TrajectoryLabels(search_used=False, search_reason="arithmetic", num_search_steps=0),
    )


def test_correct_judgment_maps_to_answer_correct_true(fake_llm) -> None:
    fake_llm.queue(json.dumps({"judgment": "CORRECT", "reason": "matches gold"}))
    scores, usage = score_trajectory(
        _search_trajectory("Javier Milei"),
        gold_answer="Javier Milei",
        requires_search=True,
        judge=fake_llm,
    )
    assert scores.answer_correct is True
    assert scores.answer_judgment == "correct"
    assert scores.answer_judge_reason == "matches gold"
    assert scores.search_decision_correct is True
    assert scores.num_searches == 1


def test_incorrect_judgment_counts_against(fake_llm) -> None:
    fake_llm.queue(json.dumps({"judgment": "INCORRECT", "reason": "wrong"}))
    scores, _ = score_trajectory(
        _search_trajectory("Wrong Person"),
        gold_answer="Javier Milei",
        requires_search=True,
        judge=fake_llm,
    )
    assert scores.answer_correct is False
    assert scores.answer_judgment == "incorrect"


def test_not_attempted_counts_against(fake_llm) -> None:
    fake_llm.queue(json.dumps({"judgment": "NOT_ATTEMPTED", "reason": "declined"}))
    scores, _ = score_trajectory(
        _search_trajectory("I don't know."),
        gold_answer="Javier Milei",
        requires_search=True,
        judge=fake_llm,
    )
    assert scores.answer_correct is False
    assert scores.answer_judgment == "not_attempted"


def test_missing_gold_skips_judge(fake_llm) -> None:
    scores, usage = score_trajectory(
        _search_trajectory("anything"),
        gold_answer=None,
        requires_search=True,
        judge=fake_llm,
    )
    assert scores.answer_correct is None
    assert scores.answer_judgment is None
    # Judge was not called.
    assert fake_llm.calls == []
    assert usage.prompt_tokens == 0


def test_search_decision_correct_both_branches(fake_llm) -> None:
    fake_llm.queue(json.dumps({"judgment": "CORRECT", "reason": "ok"}))
    # requires_search=True, searched=True → correct
    s, _ = score_trajectory(
        _search_trajectory(),
        gold_answer="X",
        requires_search=True,
        judge=fake_llm,
    )
    assert s.search_decision_correct is True

    fake_llm.queue(json.dumps({"judgment": "CORRECT", "reason": "ok"}))
    # requires_search=False, searched=False → correct
    s, _ = score_trajectory(
        _no_search_trajectory(),
        gold_answer="408",
        requires_search=False,
        judge=fake_llm,
    )
    assert s.search_decision_correct is True

    fake_llm.queue(json.dumps({"judgment": "CORRECT", "reason": "ok"}))
    # requires_search=True, searched=False → incorrect
    s, _ = score_trajectory(
        _no_search_trajectory(),
        gold_answer="X",
        requires_search=True,
        judge=fake_llm,
    )
    assert s.search_decision_correct is False


def test_search_decision_none_when_unlabeled(fake_llm) -> None:
    fake_llm.queue(json.dumps({"judgment": "CORRECT", "reason": "ok"}))
    s, _ = score_trajectory(
        _search_trajectory(),
        gold_answer="X",
        requires_search=None,
        judge=fake_llm,
    )
    assert s.search_decision_correct is None


def test_malformed_judge_output_falls_back_to_not_attempted(fake_llm) -> None:
    fake_llm.queue("this is not json")
    s, _ = score_trajectory(
        _search_trajectory(),
        gold_answer="X",
        requires_search=True,
        judge=fake_llm,
    )
    assert s.answer_judgment == "not_attempted"
    assert s.answer_correct is False
