"""End-to-end eval run with fake teacher + fake judge + fake search."""

from __future__ import annotations

import json
from pathlib import Path

from tool_trainer.eval import EvalRunner, aggregate
from tool_trainer.eval.datasets import LocalJsonlLoader
from tool_trainer.eval.report import write_failures_jsonl, write_report, write_summary
from tool_trainer.generate import TraceGenerator
from tool_trainer.schemas import GenerationConfig


def test_runner_produces_rows_and_summary(tmp_path: Path, fake_search) -> None:
    # Input: 2 questions, one with gold answer, one without.
    eval_file = tmp_path / "eval.jsonl"
    eval_file.write_text(
        '{"id": "e1", "question": "What is 17 * 24?", "answer": "408", '
        '"metadata": {"requires_search": false}}\n'
        '{"id": "e2", "question": "Fresh question?", '
        '"metadata": {"requires_search": true}}\n',
        encoding="utf-8",
    )

    # Two fake LLMs — teacher (scripted for both examples), judge (only called for e1).
    from tests.conftest import FakeLLM

    teacher = FakeLLM()
    # e1: router → no_search + arithmetic, answerer → "408"
    teacher.queue(json.dumps({"decision": "no_search", "reason": "arithmetic"}))
    teacher.queue("408")
    # e2: router → search + freshness, query_writer, answerer
    teacher.queue(json.dumps({"decision": "search", "reason": "freshness"}))
    teacher.queue(json.dumps({"query": "fresh query 2026"}))
    teacher.queue("Fresh answer.")

    judge = FakeLLM()
    # Judge is called only for e1 (e2 has no gold answer).
    judge.queue(json.dumps({"judgment": "CORRECT", "reason": "matches 408"}))

    generator = TraceGenerator(
        teacher=teacher,
        search_tool=fake_search,
        generation=GenerationConfig(max_search_steps=1),
    )
    runner = EvalRunner(generator=generator, judge=judge, loader=LocalJsonlLoader(eval_file))

    rows = list(runner.run())
    assert len(rows) == 2

    # e1: judged correct, no search
    e1 = next(r for r in rows if r.id == "e1")
    assert e1.scores.answer_correct is True
    assert e1.scores.answer_judgment == "correct"
    assert e1.scores.num_searches == 0
    assert e1.scores.search_decision_correct is True  # requires_search=False, searched=False
    assert e1.latency_ms >= 0

    # e2: ungraded (no gold), searched, search_decision_correct=True
    e2 = next(r for r in rows if r.id == "e2")
    assert e2.scores.answer_correct is None
    assert e2.scores.num_searches == 1
    assert e2.scores.search_decision_correct is True

    summary = aggregate(
        rows, benchmark="local", teacher_model="test-teacher", judge_model="test-judge"
    )
    assert summary.n == 2
    assert summary.n_correct == 1
    assert summary.n_ungraded == 1
    # 1 graded row, 1 correct → accuracy = 1.0
    assert summary.answer_accuracy == 1.0
    # Both rows have search_decision_correct=True → accuracy = 1.0
    assert summary.search_decision_accuracy == 1.0


def test_aggregate_with_zero_graded_returns_none() -> None:
    summary = aggregate([], benchmark="local", teacher_model="t", judge_model="j")
    assert summary.n == 0
    assert summary.answer_accuracy is None


def test_report_writers_produce_files(tmp_path: Path, fake_search) -> None:
    from tests.conftest import FakeLLM

    teacher = FakeLLM()
    teacher.queue(json.dumps({"decision": "no_search", "reason": "arithmetic"}))
    teacher.queue("wrong answer")
    judge = FakeLLM()
    judge.queue(json.dumps({"judgment": "INCORRECT", "reason": "not 408"}))

    eval_file = tmp_path / "eval.jsonl"
    eval_file.write_text(
        '{"id":"e1","question":"What is 17 * 24?","answer":"408","metadata":{"requires_search":false}}\n',
        encoding="utf-8",
    )
    generator = TraceGenerator(
        teacher=teacher, search_tool=fake_search, generation=GenerationConfig(max_search_steps=1)
    )
    runner = EvalRunner(generator=generator, judge=judge, loader=LocalJsonlLoader(eval_file))
    rows = list(runner.run())
    summary = aggregate(rows, benchmark="local", teacher_model="t", judge_model="j")

    out = tmp_path / "out"
    write_summary(out, summary)
    write_failures_jsonl(out, rows)
    write_report(out, summary, rows)

    assert (out / "summary.json").exists()
    assert (out / "failures.jsonl").exists()
    assert (out / "report.md").exists()

    parsed = json.loads((out / "summary.json").read_text())
    assert parsed["n"] == 1
    assert parsed["n_incorrect"] == 1
    assert parsed["answer_accuracy"] == 0.0

    report_md = (out / "report.md").read_text()
    assert "# Eval report — local" in report_md
    assert "answer_accuracy" in report_md
    assert "e1 — INCORRECT" in report_md
