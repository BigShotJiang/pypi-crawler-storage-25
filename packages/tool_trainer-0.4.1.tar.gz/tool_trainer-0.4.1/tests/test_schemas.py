"""The Trajectory schema must round-trip the example JSON from CLAUDE.md
§'Generated SFT trace schema' losslessly — that's our data contract."""

from __future__ import annotations

from tool_trainer.schemas import RawQuestion, Trajectory

SPEC_TRAJECTORY = {
    "id": "q1",
    "messages": [
        {"role": "user", "content": "Who is the current president of Argentina?"},
        {
            "role": "assistant",
            "tool_call": {
                "name": "web_search",
                "arguments": {
                    "query": "current president of Argentina April 2026",
                    "max_results": 5,
                },
            },
        },
        {
            "role": "tool",
            "name": "web_search",
            "content": {
                "results": [
                    {
                        "title": "Official government source ...",
                        "url": "...",
                        "snippet": "...",
                    }
                ]
            },
        },
        {"role": "assistant", "content": "The current president of Argentina is ..."},
    ],
    "labels": {
        "search_used": True,
        "search_reason": "freshness",
        "num_search_steps": 1,
    },
}


def test_trajectory_round_trip_matches_spec() -> None:
    t = Trajectory.model_validate(SPEC_TRAJECTORY)
    compact = t.model_dump_compact()
    # Field shape must match (ordering of keys doesn't, so compare as dicts).
    assert compact["id"] == SPEC_TRAJECTORY["id"]
    assert compact["labels"] == SPEC_TRAJECTORY["labels"]
    assert len(compact["messages"]) == 4
    # message 2 is the assistant tool_call — no `content` field should be emitted.
    assert "content" not in compact["messages"][1]
    assert compact["messages"][1]["tool_call"] == SPEC_TRAJECTORY["messages"][1]["tool_call"]
    # message 3 is the tool result.
    assert compact["messages"][2]["role"] == "tool"
    assert compact["messages"][2]["name"] == "web_search"
    assert compact["messages"][2]["content"] == SPEC_TRAJECTORY["messages"][2]["content"]


def test_raw_question_accepts_minimal_and_rich() -> None:
    assert RawQuestion.model_validate({"id": "q1", "question": "?"}).answer is None
    rich = RawQuestion.model_validate(
        {"id": "q2", "question": "?", "answer": "yes", "metadata": {"category": "x"}}
    )
    assert rich.metadata == {"category": "x"}
