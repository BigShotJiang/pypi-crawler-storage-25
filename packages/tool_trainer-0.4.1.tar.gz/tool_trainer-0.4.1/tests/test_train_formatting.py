"""Trajectory → SFT rows — the format the trainer consumes."""

from __future__ import annotations

import json

from tool_trainer.schemas import Message, ToolCall, Trajectory, TrajectoryLabels
from tool_trainer.train import trajectory_to_sft_rows


def _no_search_trajectory() -> Trajectory:
    return Trajectory(
        id="q2",
        messages=[
            Message(role="user", content="What is 17 * 24?"),
            Message(role="assistant", content="408"),
        ],
        labels=TrajectoryLabels(search_used=False, search_reason="arithmetic", num_search_steps=0),
    )


def _search_trajectory() -> Trajectory:
    return Trajectory(
        id="q1",
        messages=[
            Message(role="user", content="Who is the current president of Argentina?"),
            Message(
                role="assistant",
                tool_call=ToolCall(
                    name="web_search",
                    arguments={"query": "president of Argentina 2026", "max_results": 5},
                ),
            ),
            Message(
                role="tool",
                name="web_search",
                content={
                    "results": [
                        {
                            "title": "President of Argentina — Wikipedia",
                            "url": "https://en.wikipedia.org/wiki/President_of_Argentina",
                            "snippet": "As of 2026, the president is Javier Milei.",
                        }
                    ]
                },
            ),
            Message(role="assistant", content="Javier Milei."),
        ],
        labels=TrajectoryLabels(search_used=True, search_reason="freshness", num_search_steps=1),
    )


def test_no_search_produces_two_rows() -> None:
    rows = trajectory_to_sft_rows(_no_search_trajectory())
    assert len(rows) == 2
    assert [r.step for r in rows] == ["router", "answerer"]

    # Router row: user prompt contains the question; assistant target is JSON with no_search.
    assert "17 * 24" in rows[0].user
    router_resp = json.loads(rows[0].assistant)
    assert router_resp == {"decision": "no_search", "reason": "arithmetic"}

    # Answerer row: assistant target is the final answer verbatim.
    assert rows[1].assistant == "408"
    # Results block is empty for no-search.
    assert "Search results:" not in rows[1].user


def test_search_produces_three_rows() -> None:
    rows = trajectory_to_sft_rows(_search_trajectory())
    assert len(rows) == 3
    assert [r.step for r in rows] == ["router", "query_writer", "answerer"]

    router_resp = json.loads(rows[0].assistant)
    assert router_resp == {"decision": "search", "reason": "freshness"}

    qw_resp = json.loads(rows[1].assistant)
    assert qw_resp == {"query": "president of Argentina 2026"}
    # Query-writer prompt carries the routing reason so the query can use recency terms.
    assert "freshness" in rows[1].user

    # Answerer row: prompt includes the search-rounds block with the snippet.
    assert "Search rounds:" in rows[2].user
    assert "Round 1" in rows[2].user
    assert "Javier Milei" in rows[2].user
    assert rows[2].assistant == "Javier Milei."


def test_row_to_messages_is_openai_chat_shape() -> None:
    row = trajectory_to_sft_rows(_no_search_trajectory())[0]
    msgs = row.to_messages()
    assert msgs[0]["role"] == "user"
    assert msgs[1]["role"] == "assistant"
    assert msgs[0]["content"] == row.user
    assert msgs[1]["content"] == row.assistant


def _multi_step_trajectory() -> Trajectory:
    """2-step search trajectory with one critic message in the middle."""
    return Trajectory(
        id="q_multi",
        messages=[
            Message(role="user", content="What is the current population of Tokyo?"),
            Message(
                role="assistant",
                tool_call=ToolCall(
                    name="web_search", arguments={"query": "Tokyo population", "max_results": 5}
                ),
            ),
            Message(
                role="tool",
                name="web_search",
                content={
                    "results": [
                        {
                            "title": "Tokyo — Wikipedia",
                            "url": "https://en.wikipedia.org/wiki/Tokyo",
                            "snippet": "Tokyo is the capital of Japan.",
                        }
                    ]
                },
            ),
            Message(
                role="assistant",
                content="Critique: no current figure in results. Decision: re_search.",
            ),
            Message(
                role="assistant",
                tool_call=ToolCall(
                    name="web_search",
                    arguments={
                        "query": "Tokyo population 2026 metropolitan area",
                        "max_results": 5,
                    },
                ),
            ),
            Message(
                role="tool",
                name="web_search",
                content={
                    "results": [
                        {
                            "title": "Tokyo population 2026",
                            "url": "https://example.com/pop",
                            "snippet": "As of 2026, Tokyo has approx 13.9M residents.",
                        }
                    ]
                },
            ),
            Message(role="assistant", content="Approximately 13.9 million."),
        ],
        labels=TrajectoryLabels(search_used=True, search_reason="freshness", num_search_steps=2),
    )


def test_multi_step_produces_fanned_rows() -> None:
    """2-step trajectory → [router, query_writer_1, critic_1, query_writer_2, answerer] = 5 rows."""
    rows = trajectory_to_sft_rows(_multi_step_trajectory())
    assert [r.step for r in rows] == [
        "router",
        "query_writer",
        "critic",
        "query_writer",
        "answerer",
    ]
    assert len(rows) == 5

    # Router targets {decision: search, reason: freshness}.
    assert json.loads(rows[0].assistant) == {"decision": "search", "reason": "freshness"}

    # query_writer_1 uses the router's reason ("freshness"); target is the first query.
    assert "freshness" in rows[1].user
    assert json.loads(rows[1].assistant) == {"query": "Tokyo population"}

    # critic_1 target is re_search with the exact reason extracted from the trajectory.
    critic = json.loads(rows[2].assistant)
    assert critic["decision"] == "re_search"
    assert "no current figure" in critic["reason"]
    # Critic prompt carries the round's query + results.
    assert "Tokyo population" in rows[2].user

    # query_writer_2 uses the critic's reason as its input.
    assert "no current figure" in rows[3].user
    assert json.loads(rows[3].assistant) == {"query": "Tokyo population 2026 metropolitan area"}

    # Answerer sees both rounds concatenated.
    assert "Search rounds:" in rows[4].user
    assert "Round 1" in rows[4].user
    assert "Round 2" in rows[4].user
    assert "13.9M" in rows[4].user
    assert rows[4].assistant == "Approximately 13.9 million."
