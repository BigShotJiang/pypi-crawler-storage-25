"""EvalRunner with concurrency > 1 runs examples in parallel via threads."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from tool_trainer.eval import EvalRunner
from tool_trainer.eval.datasets import LocalJsonlLoader
from tool_trainer.generate import TraceGenerator
from tool_trainer.schemas import GenerationConfig


class _SleepyLLM:
    """Fake LLM that sleeps on every call — used to measure parallelism."""

    def __init__(self, sleep_s: float, responses: list[str]) -> None:
        self._sleep_s = sleep_s
        self._responses = list(responses)
        self._idx = 0

    def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        response_format: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        time.sleep(self._sleep_s)
        # Cycle through responses so we don't run out.
        r = self._responses[self._idx % len(self._responses)]
        self._idx += 1
        return {"content": r, "tool_calls": []}


def _make_eval_file(tmp_path: Path, n: int) -> Path:
    path = tmp_path / "eval.jsonl"
    path.write_text(
        "\n".join(
            json.dumps(
                {
                    "id": f"q{i}",
                    "question": f"Q{i}?",
                    "answer": "A",
                    "metadata": {"requires_search": False},
                }
            )
            for i in range(n)
        ),
        encoding="utf-8",
    )
    return path


def _build_runner(eval_file: Path, sleep_s: float, concurrency: int, fake_search):
    teacher_responses = [
        json.dumps({"decision": "no_search", "reason": "parametric_ok"}),
        "A",
    ]
    judge_responses = [json.dumps({"judgment": "CORRECT", "reason": "ok"})]

    teacher = _SleepyLLM(sleep_s, teacher_responses)
    judge = _SleepyLLM(sleep_s, judge_responses)

    generator = TraceGenerator(
        teacher=teacher, search_tool=fake_search, generation=GenerationConfig(max_search_steps=1)
    )
    return EvalRunner(
        generator=generator,
        judge=judge,
        loader=LocalJsonlLoader(eval_file),
        concurrency=concurrency,
    )


def test_concurrent_runner_completes_all_rows(tmp_path: Path, fake_search) -> None:
    eval_file = _make_eval_file(tmp_path, n=8)
    runner = _build_runner(eval_file, sleep_s=0.05, concurrency=4, fake_search=fake_search)
    rows = list(runner.run())
    assert len(rows) == 8
    # All rows scored as CORRECT by the fake judge.
    assert all(r.scores.answer_correct for r in rows)
    # All ids present (regardless of order — concurrent runner yields in completion order).
    assert {r.id for r in rows} == {f"q{i}" for i in range(8)}


def test_concurrent_runner_is_faster_than_sequential(tmp_path: Path, fake_search) -> None:
    """Smoke: 8 tasks × 50ms sleep per LLM call × 2 calls (teacher no-search + judge)
    ≈ 800ms sequential. With concurrency=4 we expect well under 500ms wall-clock."""
    eval_file = _make_eval_file(tmp_path, n=8)
    runner = _build_runner(eval_file, sleep_s=0.05, concurrency=4, fake_search=fake_search)

    t0 = time.perf_counter()
    rows = list(runner.run())
    elapsed = time.perf_counter() - t0

    assert len(rows) == 8
    # Generous bound to avoid CI flakes: sequential ≥ 0.8s, concurrent should be under 0.6s.
    assert elapsed < 0.6, f"concurrent run took {elapsed:.2f}s — threading likely not working"


def test_concurrency_1_matches_sequential_order(tmp_path: Path, fake_search) -> None:
    eval_file = _make_eval_file(tmp_path, n=3)
    runner = _build_runner(eval_file, sleep_s=0.0, concurrency=1, fake_search=fake_search)
    rows = list(runner.run())
    # Sequential path preserves input order.
    assert [r.id for r in rows] == ["q0", "q1", "q2"]
