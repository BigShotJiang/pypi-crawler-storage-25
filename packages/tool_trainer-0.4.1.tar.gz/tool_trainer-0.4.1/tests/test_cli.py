"""Smoke tests for each CLI command using Typer's CliRunner.

Tests are hermetic: no OpenAI/Tavily keys required, no network.
`tt validate --no-ping` is used to skip teacher-LLM health checks.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from tool_trainer.cli import app

runner = CliRunner()


def test_init_creates_expected_files(tmp_workspace: Path) -> None:
    result = runner.invoke(app, ["init", "--path", str(tmp_workspace / "proj")])
    assert result.exit_code == 0, result.output

    proj = tmp_workspace / "proj"
    assert (proj / "config.yaml").exists()
    assert (proj / ".env.example").exists()
    assert (proj / "data" / "train.jsonl").exists()
    assert (proj / "prompts" / "router.txt").exists()
    assert (proj / "prompts" / "query_writer.txt").exists()
    assert (proj / "prompts" / "answerer.txt").exists()
    assert (proj / "outputs").is_dir()


def test_init_idempotent_without_force(tmp_workspace: Path) -> None:
    runner.invoke(app, ["init", "--path", str(tmp_workspace / "proj")])
    (tmp_workspace / "proj" / "config.yaml").write_text("# custom")
    runner.invoke(app, ["init", "--path", str(tmp_workspace / "proj")])
    # Custom content preserved without --force.
    assert (tmp_workspace / "proj" / "config.yaml").read_text() == "# custom"


def test_validate_flags_missing_keys(tmp_workspace: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("TAVILY_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    runner.invoke(app, ["init", "--path", str(tmp_workspace / "proj")])
    result = runner.invoke(
        app,
        [
            "validate",
            "--config",
            str(tmp_workspace / "proj" / "config.yaml"),
            "--data",
            str(tmp_workspace / "proj" / "data" / "train.jsonl"),
            "--no-ping",
        ],
    )
    assert result.exit_code != 0
    assert "TAVILY_API_KEY" in result.output
    assert "OPENAI_API_KEY" in result.output


def test_validate_catches_bad_dataset(tmp_workspace: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TAVILY_API_KEY", "test")
    monkeypatch.setenv("OPENAI_API_KEY", "test")

    runner.invoke(app, ["init", "--path", str(tmp_workspace / "proj")])
    bad = tmp_workspace / "proj" / "data" / "bad.jsonl"
    bad.write_text('{"id": "q1", "question": "ok"}\n{"missing_id": true}\n')

    result = runner.invoke(
        app,
        [
            "validate",
            "--config",
            str(tmp_workspace / "proj" / "config.yaml"),
            "--data",
            str(bad),
            "--no-ping",
        ],
    )
    assert result.exit_code != 0
    assert "invalid rows" in result.output


def test_inspect_renders(tmp_workspace: Path) -> None:
    traj = {
        "id": "q1",
        "messages": [
            {"role": "user", "content": "Who is the current president of Argentina?"},
            {
                "role": "assistant",
                "tool_call": {"name": "web_search", "arguments": {"query": "q", "max_results": 5}},
            },
            {
                "role": "tool",
                "name": "web_search",
                "content": {"results": [{"title": "T", "url": "U", "snippet": "S"}]},
            },
            {"role": "assistant", "content": "answer"},
        ],
        "labels": {"search_used": True, "search_reason": "freshness", "num_search_steps": 1},
    }
    path = tmp_workspace / "t.jsonl"
    path.write_text(json.dumps(traj) + "\n")
    result = runner.invoke(app, ["inspect", str(path)])
    assert result.exit_code == 0, result.output
    assert "q1" in result.output
    assert "Argentina" in result.output


def test_replay_fails_on_missing_cache(
    tmp_workspace: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test")
    runner.invoke(app, ["init", "--path", str(tmp_workspace / "proj")])
    result = runner.invoke(
        app,
        [
            "replay",
            "--config",
            str(tmp_workspace / "proj" / "config.yaml"),
            "--input",
            str(tmp_workspace / "proj" / "data" / "train.jsonl"),
            "--cache",
            str(tmp_workspace / "nonexistent.sqlite"),
            "--output",
            str(tmp_workspace / "out.jsonl"),
        ],
    )
    assert result.exit_code != 0
    assert "Cache file not found" in result.output


def test_stub_commands_exit_nonzero(tmp_workspace: Path) -> None:
    """serve/export/doctor are registered for --help parity but not implemented yet."""
    for cmd in ["serve", "export", "doctor"]:
        result = runner.invoke(app, [cmd])
        assert result.exit_code != 0, f"{cmd} should fast-fail"
        assert "not yet implemented" in result.output


def test_version_flag() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "tool-trainer" in result.output
