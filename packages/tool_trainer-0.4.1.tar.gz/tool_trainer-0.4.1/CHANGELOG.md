# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.1] — 2026-04-25

### Fixed
- `publish.yml` GitHub Actions workflow now grants `contents: read` permission so `actions/checkout` can fetch the repo at the tagged commit. Without it, setting `id-token: write` removed all default permissions and the workflow failed at the checkout step. (v0.4.0 tag was created but never reached PyPI.)

## [0.4.0] — 2026-04-24 *(withdrawn — never published; superseded by 0.4.1)*

### Added
- **Multi-step critique loop.** `tt generate` and `tt eval` now run an agentic search loop: after each retrieval, a new critic prompt decides `answer` vs. `re_search`; on `re_search`, the query_writer rebuilds the query using the critic's reason. Loop is bounded by `max_search_steps` and fails closed on malformed critic output.
- **`critique.txt` prompt** — new teacher prompt with strict JSON output (`{decision, reason}`).
- **Critic reasoning inside trajectories.** Each re-search round inserts an assistant content message (`"Critique: <reason>. Decision: re_search."`) before the next `tool_call`. Matches ReAct-style patterns, enables richer DPO training in v0.5.
- **Multi-step SFT fan-out.** `trajectory_to_sft_rows` walks multi-step trajectories and emits `router → (query_writer → critic)×(N-1) → query_writer → answerer` (2N+1 rows). Each critic row teaches the model when to re-search; each query_writer row's "reason" input is the preceding critic's reason.
- **`--max-search-steps` CLI flag** on `tt generate` is now active (was a forward-compat stub in v0.1-v0.3). Overrides `config.generation.max_search_steps`.

### Changed
- **`GenerationConfig.max_search_steps` default: 1 → 2.** One-step is the degenerate case; the product is agentic by default now.
- **Answerer sees all search rounds** concatenated (`"Round 1 (query: …):\n[results]\n\nRound 2 …"`), not just the last. `query_writer` prompt relaxed to accept free-text critic reasons in addition to router reason codes.
- Unified the generator loop — dropped the single-step carve-out from `generate_trajectory_with_usage`. Single-search is just `len(rounds) == 1`.

## [0.3.0] — 2026-04-24

### Added
- **`tt train --method sft`** — fine-tune a base model with LoRA on trajectories from `tt generate`. Uses TRL's `SFTTrainer` + PEFT LoRA adapters. Defaults target Qwen2.5-7B-Instruct on a single 24GB+ GPU.
- **`HFInferenceClient`** (`tool_trainer.llm.hf`) — `LLMClient` implementation using `transformers` + optional `peft` adapters. Makes `tt eval` and `tt generate` runnable against any local HF checkpoint.
- **Model-spec scheme** — `resolve_llm(spec)` parses `openai:<model>`, `hf:<path_or_hub_id>`, and `hf:<base>+lora:<adapter_path>` forms uniformly.
- **`--teacher-model` flag** on `tt generate`, `tt eval`, `tt replay` — overrides `config.teacher` with any resolved spec.
- **`--judge-model` flag** on `tt eval` — accepts the same spec scheme (OpenAI or local).
- **`TrainingConfig`** block in `config.yaml` — base model, LoRA r/alpha/dropout, epochs, LR, batch size, seq length, bf16, report-to, seed.
- **`[train]` optional extra** — `torch`, `transformers`, `trl`, `peft`, `accelerate`. Base install stays light; heavy deps are opt-in.
- `metadata.json` written alongside every checkpoint: tool-trainer version, git SHA, base model, training config snapshot, row counts.

### Changed
- `_build_teacher` / `_build_judge` now route through `resolve_llm`, so `tt eval` summary files show the full model spec (e.g. `openai:gpt-4o-mini`, `hf:Qwen/Qwen2.5-7B-Instruct+lora:./outputs/sft-001`) instead of just the bare model name.

## [0.2.1] — 2026-04-24

### Added
- **HTML report** — `tt eval` now writes `report.html` alongside `report.md`. Self-contained (inline CSS, no external assets), with collapsible per-failure drill-downs showing the full trajectory (user → tool_call → tool result → final answer).
- **Concurrent eval** — `tt eval --concurrency N` runs up to N examples in parallel via a `ThreadPoolExecutor`. Defaults to 1 (sequential, matches v0.2 behavior). Near-linear speedup on long runs where network I/O dominates.

### Changed
- `EvalRunner` gained a `concurrency: int = 1` constructor arg; when > 1, rows are yielded in completion order rather than input order.

## [0.2.0] — 2026-04-24

### Added
- **`tt eval`** — evaluate the pipeline on tool-use benchmarks. Writes `summary.json`, `failures.jsonl`, and `report.md` into an output directory.
- Benchmark loaders: `local:<path>` (local JSONL), `simpleqa` (HuggingFace `basicv8vc/SimpleQA`), `browsecomp` (OpenAI CSV with XOR/SHA256-canary decryption).
- Core eval metrics: `answer_accuracy` (LLM-as-judge with SimpleQA-style CORRECT/INCORRECT/NOT_ATTEMPTED rubric), `search_decision_accuracy`, `searches_per_example`, `latency_ms`, token cost.
- `EvaluationConfig` block in `config.yaml` for judge model + settings.
- Judge prompt (`prompts/judge_answer.txt`) ported from SimpleQA paper rubric.
- `TraceGenerator.generate_one(question) → (Trajectory, Usage)` — per-example token accounting.
- `OpenAIClient` now returns token usage alongside content/tool_calls.
- `datasets` dependency for HF benchmark loading.

### Changed
- LLMClient return shape extended with optional `usage` key (fakes unaffected).

## [0.1.0] — 2026-04-24

### Added
- Initial release: thin end-to-end trace-generation pipeline.
- `tt init` — scaffold a new project (config, sample data, prompts).
- `tt validate` — config schema, API-key, and dataset checks.
- `tt generate --mode sft` — router → query_writer → Tavily → answerer loop producing SFT-format tool-use trajectories.
- `tt inspect` — rich-rendered trajectory viewer.
- `tt replay` — deterministic re-runs from SQLite search cache.
- `SearchTool` + `LLMClient` Protocols with Tavily and OpenAI implementations.
- Pydantic v2 schemas for `RawQuestion`, `Trajectory`, `ToolCall`, `Message`, `Config`.
- SQLite-backed search cache.
- Apache-2.0 license, PyPI packaging, GitHub Actions CI + publish workflows.

[Unreleased]: https://github.com/Galhadarr/tool-trainer/compare/v0.4.1...HEAD
[0.4.1]: https://github.com/Galhadarr/tool-trainer/compare/v0.3.0...v0.4.1
[0.4.0]: https://github.com/Galhadarr/tool-trainer/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/Galhadarr/tool-trainer/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/Galhadarr/tool-trainer/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/Galhadarr/tool-trainer/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/Galhadarr/tool-trainer/releases/tag/v0.1.0
