"""SearchTool Protocol — everything that can be swapped out lives behind this shape."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


class CacheMiss(KeyError):
    """Raised by replay-only tools when a query isn't in the cache."""


@runtime_checkable
class SearchTool(Protocol):
    def search(self, query: str, max_results: int = 5) -> dict[str, Any]:
        """Return a raw search response. Shape follows Tavily's:
        {"query": str, "results": [{"title": str, "url": str, "content"/"snippet": str, "score": float}, ...], ...}
        """
        ...
