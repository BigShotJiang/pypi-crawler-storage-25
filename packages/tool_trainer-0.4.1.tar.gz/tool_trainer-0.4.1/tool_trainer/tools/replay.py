"""Read-only SearchTool backed by a populated SqliteSearchCache. Raises on miss
so generations are fully deterministic and never accidentally call Tavily."""

from __future__ import annotations

from typing import Any

from tool_trainer.tools.base import CacheMiss
from tool_trainer.tools.cache import SqliteSearchCache


class ReplaySearchTool:
    def __init__(
        self,
        cache: SqliteSearchCache,
        *,
        search_depth: str = "basic",
        include_raw_content: bool = False,
    ) -> None:
        self._cache = cache
        self._search_depth = search_depth
        self._include_raw_content = include_raw_content

    def search(self, query: str, max_results: int = 5) -> dict[str, Any]:
        params = {
            "max_results": max_results,
            "search_depth": self._search_depth,
            "include_raw_content": self._include_raw_content,
        }
        cached = self._cache.get(query, params)
        if cached is None:
            raise CacheMiss(
                f"No cached result for query {query!r} with params {params!r}. "
                "Re-run `tt generate` to populate the cache first."
            )
        return cached
