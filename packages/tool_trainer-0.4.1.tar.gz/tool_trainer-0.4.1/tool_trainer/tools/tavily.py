"""Tavily search tool, with optional read-through SQLite cache."""

from __future__ import annotations

from typing import Any

from tool_trainer.tools.cache import SqliteSearchCache


class TavilySearchTool:
    def __init__(
        self,
        api_key: str,
        *,
        search_depth: str = "basic",
        include_raw_content: bool = False,
        cache: SqliteSearchCache | None = None,
    ) -> None:
        # Import lazily so the test suite doesn't need tavily-python if it mocks this tool.
        from tavily import TavilyClient

        self._client = TavilyClient(api_key=api_key)
        self._search_depth = search_depth
        self._include_raw_content = include_raw_content
        self._cache = cache

    def _params(self, max_results: int) -> dict[str, Any]:
        return {
            "max_results": max_results,
            "search_depth": self._search_depth,
            "include_raw_content": self._include_raw_content,
        }

    def search(self, query: str, max_results: int = 5) -> dict[str, Any]:
        params = self._params(max_results)
        if self._cache is not None:
            cached = self._cache.get(query, params)
            if cached is not None:
                return cached

        response = self._client.search(
            query=query,
            max_results=max_results,
            search_depth=self._search_depth,
            include_raw_content=self._include_raw_content,
        )

        if self._cache is not None:
            self._cache.put(query, params, response)
        return response
