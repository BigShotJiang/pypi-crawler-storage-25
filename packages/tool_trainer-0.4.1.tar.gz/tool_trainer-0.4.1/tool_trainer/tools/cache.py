"""SQLite-backed search cache. Used both for TavilySearchTool (store-on-miss)
and ReplaySearchTool (read-only)."""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any

from tool_trainer.utils.hashing import cache_key
from tool_trainer.utils.io import ensure_parent

_SCHEMA = """
CREATE TABLE IF NOT EXISTS search_cache (
    key TEXT PRIMARY KEY,
    query TEXT NOT NULL,
    params TEXT NOT NULL,
    results TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
"""


class SqliteSearchCache:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        ensure_parent(self.path)
        self._conn = sqlite3.connect(str(self.path))
        self._conn.execute(_SCHEMA)
        self._conn.commit()

    def get(self, query: str, params: dict[str, Any]) -> dict[str, Any] | None:
        key = cache_key(query, params)
        row = self._conn.execute(
            "SELECT results FROM search_cache WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        return json.loads(row[0])

    def put(self, query: str, params: dict[str, Any], results: dict[str, Any]) -> None:
        key = cache_key(query, params)
        self._conn.execute(
            "INSERT OR REPLACE INTO search_cache (key, query, params, results, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                key,
                query,
                json.dumps(params, sort_keys=True),
                json.dumps(results, ensure_ascii=False),
                int(time.time()),
            ),
        )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()
