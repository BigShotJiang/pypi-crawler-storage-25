"""Stable hashing for cache keys."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def cache_key(query: str, params: dict[str, Any]) -> str:
    """Deterministic sha256 over (query, sorted JSON of params)."""
    payload = json.dumps({"query": query, "params": params}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
