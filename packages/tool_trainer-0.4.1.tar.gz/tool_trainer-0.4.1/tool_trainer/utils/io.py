"""Filesystem helpers."""

from __future__ import annotations

from pathlib import Path


def resolve_path(p: str | Path) -> Path:
    return Path(p).expanduser().resolve()


def ensure_dir(p: str | Path) -> Path:
    path = resolve_path(p)
    path.mkdir(parents=True, exist_ok=True)
    return path


def ensure_parent(p: str | Path) -> Path:
    path = resolve_path(p)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path
