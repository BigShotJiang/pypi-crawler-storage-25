"""Rich-backed logger. Single shared instance; import `log` where you need it."""

from __future__ import annotations

import logging

from rich.console import Console
from rich.logging import RichHandler

_console = Console(stderr=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(console=_console, rich_tracebacks=True, show_path=False)],
)

log = logging.getLogger("tool_trainer")
console = Console()
