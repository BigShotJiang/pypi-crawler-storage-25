"""Typer CLI. Each command body is thin; logic lives in the submodules."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from rich.panel import Panel
from rich.table import Table

from tool_trainer import __version__
from tool_trainer.data.loaders import load_questions, load_trajectories, read_jsonl
from tool_trainer.data.writers import append_jsonl
from tool_trainer.eval import EvalRunner, aggregate
from tool_trainer.eval.datasets import resolve_loader
from tool_trainer.eval.report import (
    load_seen_ids,
    write_failures_jsonl,
    write_html_report,
    write_report,
    write_summary,
)
from tool_trainer.generate import TraceGenerator
from tool_trainer.llm import OpenAIClient
from tool_trainer.logging import console, log
from tool_trainer.prompts import prompt_files
from tool_trainer.schemas import Config, EvalRow, RawQuestion, Trajectory
from tool_trainer.settings import load_settings
from tool_trainer.tools import CacheMiss, ReplaySearchTool, SqliteSearchCache, TavilySearchTool
from tool_trainer.utils.io import ensure_dir, ensure_parent

app = typer.Typer(
    name="tt",
    help="Train LLMs to use web search as a tool.",
    no_args_is_help=True,
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"tool-trainer {__version__}")
        raise typer.Exit()


@app.callback()
def _main(
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit."
    ),
) -> None:
    """tool-trainer: generate tool-use trajectories, fine-tune, evaluate."""


# ----------------------------------------------------------------------------
# tt init
# ----------------------------------------------------------------------------

_MINIMAL_CONFIG = """\
project:
  name: my-tool-trainer-run
  output_dir: ./outputs

tool:
  provider: tavily
  api_key_env: TAVILY_API_KEY
  search_depth: basic
  max_results: 5
  include_raw_content: false
  cache_path: ./outputs/caches/search.sqlite

teacher:
  provider: openai
  model: gpt-4o-mini
  temperature: 0.2

generation:
  mode: sft
  max_search_steps: 2
  search_budget: 2
  include_no_search_examples: true
"""

_SAMPLE_DATA = """\
{"id": "q1", "question": "Who is the current president of Argentina?"}
{"id": "q2", "question": "What is 17 * 24?", "answer": "408"}
{"id": "q3", "question": "What changed in the latest PyTorch release?"}
{"id": "q4", "question": "Who wrote the novel 'Crime and Punishment'?", "answer": "Fyodor Dostoevsky"}
{"id": "q5", "question": "What is the current population of Tokyo?"}
"""

_ENV_EXAMPLE = """\
TAVILY_API_KEY=
OPENAI_API_KEY=
"""


@app.command()
def init(
    path: Path = typer.Option(Path("."), "--path", help="Target directory."),
    template: str = typer.Option("minimal", "--template", help="Starter template (minimal)."),
    force: bool = typer.Option(False, "--force", help="Overwrite existing files."),
) -> None:
    """Scaffold a starter project (config, sample data, prompts)."""
    if template != "minimal":
        raise typer.BadParameter("only --template minimal is currently supported")

    root = ensure_dir(path)
    to_write: dict[Path, str] = {
        root / "config.yaml": _MINIMAL_CONFIG,
        root / ".env.example": _ENV_EXAMPLE,
        root / "data" / "train.jsonl": _SAMPLE_DATA,
    }
    for name, content in prompt_files().items():
        to_write[root / "prompts" / f"{name}.txt"] = content

    created, skipped = [], []
    for p, content in to_write.items():
        if p.exists() and not force:
            skipped.append(p)
            continue
        ensure_parent(p)
        p.write_text(content, encoding="utf-8")
        created.append(p)

    ensure_dir(root / "outputs")

    console.print(
        Panel.fit(
            "\n".join(
                ["[green]Created:[/green]"]
                + [f"  {p.relative_to(root)}" for p in created]
                + (["\n[yellow]Skipped (already existed):[/yellow]"] if skipped else [])
                + [f"  {p.relative_to(root)}" for p in skipped]
            ),
            title="tt init",
        )
    )


# ----------------------------------------------------------------------------
# tt validate
# ----------------------------------------------------------------------------


@app.command()
def validate(
    config: Path = typer.Option(None, "--config", help="Path to config.yaml."),
    data: Path = typer.Option(None, "--data", help="Path to a JSONL dataset to validate."),
    ping: bool = typer.Option(True, "--ping/--no-ping", help="Health-check the teacher LLM."),
) -> None:
    """Validate config, env vars, and (optionally) a dataset."""
    problems: list[str] = []
    cfg: Config | None = None

    if config is not None:
        try:
            cfg = Config.load(config)
            console.print(f"[green]✓[/green] Config parsed: {config}")
        except Exception as exc:
            problems.append(f"Config {config} failed to parse: {exc}")

    settings = load_settings()
    if not settings.tavily_api_key:
        problems.append("TAVILY_API_KEY is not set (check .env or environment).")
    else:
        console.print("[green]✓[/green] TAVILY_API_KEY present")
    if not settings.openai_api_key:
        problems.append("OPENAI_API_KEY is not set (check .env or environment).")
    else:
        console.print("[green]✓[/green] OPENAI_API_KEY present")

    if ping and settings.openai_api_key and cfg is not None:
        try:
            client = OpenAIClient(
                api_key=settings.openai_api_key,
                model=cfg.teacher.model,
                temperature=cfg.teacher.temperature,
            )
            client.complete(messages=[{"role": "user", "content": "ping"}], temperature=0.0)
            console.print(f"[green]✓[/green] Teacher reachable: {cfg.teacher.model}")
        except Exception as exc:
            problems.append(f"Teacher ping failed: {exc}")

    if data is not None:
        bad: list[str] = []
        n = 0
        for i, obj in enumerate(read_jsonl(data), start=1):
            try:
                RawQuestion.model_validate(obj)
                n += 1
            except Exception as exc:
                if len(bad) < 10:
                    bad.append(f"  line {i}: {exc}")
        if bad:
            problems.append(f"Dataset {data} has invalid rows:\n" + "\n".join(bad))
        else:
            console.print(f"[green]✓[/green] Dataset {data}: {n} rows valid")

    if problems:
        for p in problems:
            console.print(f"[red]✗[/red] {p}")
        raise typer.Exit(code=1)
    console.print("[bold green]All checks passed.[/bold green]")


# ----------------------------------------------------------------------------
# tt generate
# ----------------------------------------------------------------------------


def _build_search_tool(cfg: Config, api_key: str, cache_on: bool) -> TavilySearchTool:
    cache = SqliteSearchCache(cfg.tool.cache_path) if cache_on else None
    return TavilySearchTool(
        api_key=api_key,
        search_depth=cfg.tool.search_depth,
        include_raw_content=cfg.tool.include_raw_content,
        cache=cache,
    )


def _build_teacher(cfg: Config, api_key: str | None, *, spec: str | None = None):
    """Resolve the teacher LLMClient. `spec` overrides config when provided;
    otherwise the spec is derived from `config.teacher.provider:config.teacher.model`."""
    from tool_trainer.llm import resolve_llm

    effective_spec = spec or f"{cfg.teacher.provider}:{cfg.teacher.model}"
    return resolve_llm(
        effective_spec,
        openai_api_key=api_key,
        temperature=cfg.teacher.temperature,
    )


def _seen_ids(path: Path) -> set[str]:
    if not path.exists():
        return set()
    seen: set[str] = set()
    for obj in read_jsonl(path):
        if isinstance(obj, dict) and "id" in obj:
            seen.add(obj["id"])
    return seen


def _generate_impl(
    *,
    config: Path,
    input_path: Path,
    output_path: Path,
    mode: str,
    limit: int | None,
    resume: bool,
    cache_on: bool,
    search_tool_override: Any | None = None,
    teacher_override: Any | None = None,
    teacher_spec: str | None = None,
    max_search_steps: int | None = None,
) -> int:
    """Shared generation loop for `tt generate` and `tt replay`."""
    if mode != "sft":
        raise typer.BadParameter(
            f"--mode {mode!r} is not yet implemented; only 'sft' is supported."
        )

    cfg = Config.load(config)
    if max_search_steps is not None:
        cfg.generation.max_search_steps = max_search_steps
    settings = load_settings()

    # hf: specs don't need OPENAI_API_KEY; build via resolver directly.
    if teacher_override is not None:
        teacher = teacher_override
    else:
        uses_openai = (teacher_spec or f"{cfg.teacher.provider}:").startswith("openai:")
        if uses_openai and not settings.openai_api_key:
            teacher = None
        else:
            teacher = _build_teacher(cfg, settings.openai_api_key, spec=teacher_spec)
    if teacher is None:
        raise typer.Exit("OPENAI_API_KEY is not set.")

    search_tool = search_tool_override or (
        _build_search_tool(cfg, settings.tavily_api_key or "", cache_on)
        if settings.tavily_api_key
        else None
    )
    if search_tool is None:
        raise typer.Exit("TAVILY_API_KEY is not set.")

    questions = load_questions(input_path)
    seen = _seen_ids(output_path) if resume else set()
    if seen:
        log.info("Resuming: skipping %d already-emitted ids", len(seen))

    if not resume:
        ensure_parent(output_path)
        output_path.write_text("", encoding="utf-8")

    gen = TraceGenerator(
        teacher=teacher,
        search_tool=search_tool,
        generation=cfg.generation,
        max_results=cfg.tool.max_results,
    )
    written = 0
    for traj in gen.generate(questions, limit=limit, already_seen_ids=seen):
        append_jsonl(output_path, traj)
        written += 1
        log.info("[%d/%s] %s", written, limit if limit else len(questions) - len(seen), traj.id)

    console.print(f"[bold green]Wrote {written} trajectories → {output_path}[/bold green]")
    return written


@app.command()
def generate(
    config: Path = typer.Option(..., "--config", help="Path to config.yaml."),
    input_path: Path = typer.Option(..., "--input", help="JSONL of RawQuestion rows."),
    output: Path = typer.Option(..., "--output", help="JSONL trajectory output."),
    mode: str = typer.Option("sft", "--mode", help="Generation mode (currently: sft)."),
    limit: int = typer.Option(None, "--limit", help="Max trajectories to generate."),
    resume: bool = typer.Option(False, "--resume", help="Skip ids already in output."),
    cache: str = typer.Option("on", "--cache", help="on|off — use SQLite search cache."),
    max_search_steps: int = typer.Option(
        None,
        "--max-search-steps",
        help="Max Tavily calls per example (overrides config.generation.max_search_steps).",
    ),
    teacher_model: str = typer.Option(
        None,
        "--teacher-model",
        help="Model spec (openai:gpt-4o-mini | hf:<path> | hf:<base>+lora:<adapter>). "
        "Overrides config.teacher.",
    ),
) -> None:
    """Generate tool-use training trajectories."""
    _generate_impl(
        config=config,
        input_path=input_path,
        output_path=output,
        mode=mode,
        limit=limit,
        resume=resume,
        cache_on=(cache.lower() == "on"),
        teacher_spec=teacher_model,
        max_search_steps=max_search_steps,
    )


# ----------------------------------------------------------------------------
# tt inspect
# ----------------------------------------------------------------------------


def _render_trajectory(traj: Trajectory) -> Panel:
    question = next((m.content for m in traj.messages if m.role == "user"), "")
    assistant_call = next(
        (m for m in traj.messages if m.role == "assistant" and m.tool_call is not None), None
    )
    tool_msg = next((m for m in traj.messages if m.role == "tool"), None)
    final = next(
        (
            m
            for m in traj.messages
            if m.role == "assistant" and m.tool_call is None and m.content is not None
        ),
        None,
    )

    t = Table.grid(padding=(0, 1))
    t.add_column(style="bold")
    t.add_column()
    t.add_row("id:", traj.id)
    t.add_row("question:", str(question))
    t.add_row("search_used:", "yes" if traj.labels.search_used else "no")
    if traj.labels.search_reason:
        t.add_row("reason:", traj.labels.search_reason)
    if assistant_call and assistant_call.tool_call:
        t.add_row("query:", str(assistant_call.tool_call.arguments.get("query", "")))
    if tool_msg and isinstance(tool_msg.content, dict):
        results = tool_msg.content.get("results", [])[:3]
        for i, r in enumerate(results, 1):
            t.add_row(f"result {i}:", f"{r.get('title', '')} — {r.get('url', '')}")
    if final and final.content:
        t.add_row("answer:", str(final.content))
    return Panel(t, title=f"Trajectory {traj.id}", border_style="cyan")


@app.command()
def inspect(
    path: Path = typer.Argument(..., help="Path to trajectories.jsonl."),
    id: str = typer.Option(None, "--id", help="Show only this trajectory id."),
) -> None:
    """Pretty-print trajectories."""
    trajectories = load_trajectories(path)
    if id:
        trajectories = [t for t in trajectories if t.id == id]
        if not trajectories:
            console.print(f"[yellow]No trajectory with id={id} in {path}[/yellow]")
            raise typer.Exit(code=1)
    for t in trajectories:
        console.print(_render_trajectory(t))


# ----------------------------------------------------------------------------
# tt replay
# ----------------------------------------------------------------------------


@app.command()
def replay(
    config: Path = typer.Option(..., "--config"),
    input_path: Path = typer.Option(..., "--input"),
    cache: Path = typer.Option(..., "--cache", help="Path to SQLite search cache."),
    output: Path = typer.Option(..., "--output"),
    teacher_model: str = typer.Option(
        None, "--teacher-model", help="Model spec override (openai:... | hf:...)."
    ),
) -> None:
    """Re-run generation using only cached search results (no live Tavily calls)."""
    if not cache.exists():
        raise typer.Exit(f"Cache file not found: {cache}")
    cfg = Config.load(config)
    settings = load_settings()

    effective_spec = teacher_model or f"{cfg.teacher.provider}:{cfg.teacher.model}"
    if effective_spec.startswith("openai:") and not settings.openai_api_key:
        raise typer.Exit("OPENAI_API_KEY is not set.")

    replay_tool = ReplaySearchTool(
        SqliteSearchCache(cache),
        search_depth=cfg.tool.search_depth,
        include_raw_content=cfg.tool.include_raw_content,
    )
    teacher = _build_teacher(cfg, settings.openai_api_key, spec=teacher_model)

    try:
        _generate_impl(
            config=config,
            input_path=input_path,
            output_path=output,
            mode="sft",
            limit=None,
            resume=False,
            cache_on=False,
            search_tool_override=replay_tool,
            teacher_override=teacher,
        )
    except CacheMiss as exc:
        raise typer.Exit(f"Replay failed: {exc}") from exc


# ----------------------------------------------------------------------------
# Stubs — registered for `--help` parity with the full spec.
# ----------------------------------------------------------------------------


def _not_implemented(cmd: str) -> None:
    raise typer.Exit(f"`tt {cmd}` is not yet implemented. See ROADMAP.md for planned versions.")


@app.command()
def train(
    config: Path = typer.Option(..., "--config", help="Path to config.yaml."),
    method: str = typer.Option("sft", "--method", help="Training method (currently: sft)."),
    data: Path = typer.Option(..., "--data", help="JSONL of trajectories from `tt generate`."),
    base_model: str = typer.Option(
        None, "--base-model", help="Base HF model (overrides config.training.base_model)."
    ),
    output: Path = typer.Option(..., "--output", help="Output checkpoint directory."),
    epochs: int = typer.Option(None, "--epochs"),
    lr: float = typer.Option(None, "--lr", help="Learning rate."),
    batch_size: int = typer.Option(None, "--batch-size", help="Per-device batch size."),
    lora_r: int = typer.Option(None, "--lora-r"),
    lora_alpha: int = typer.Option(None, "--lora-alpha"),
    bf16: bool = typer.Option(None, "--bf16/--no-bf16"),
    report_to: str = typer.Option(None, "--report-to", help="none|wandb"),
    seed: int = typer.Option(None, "--seed"),
) -> None:
    """Fine-tune a model with LoRA SFT on trajectories from `tt generate`."""
    if method != "sft":
        raise typer.BadParameter(
            f"--method {method!r} is not yet implemented; only 'sft' is supported."
        )

    cfg = Config.load(config)

    # Apply CLI overrides on top of config.training.
    training = cfg.training
    if base_model is not None:
        training.base_model = base_model
    if epochs is not None:
        training.epochs = epochs
    if lr is not None:
        training.learning_rate = lr
    if batch_size is not None:
        training.per_device_batch_size = batch_size
    if lora_r is not None:
        training.lora_r = lora_r
    if lora_alpha is not None:
        training.lora_alpha = lora_alpha
    if bf16 is not None:
        training.bf16 = bf16
    if report_to is not None:
        if report_to not in ("none", "wandb"):
            raise typer.BadParameter("--report-to must be 'none' or 'wandb'")
        training.report_to = report_to  # type: ignore[assignment]
    if seed is not None:
        training.seed = seed

    # Lazy import — keeps `tt --help` cheap for users without the [train] extra.
    from tool_trainer.train.sft import run_sft

    output_dir = run_sft(data_path=data, output_dir=output, training=training)
    console.print(f"[bold green]Training complete → {output_dir}[/bold green]")
    console.print(
        f"  Evaluate with: [cyan]tt eval --teacher-model "
        f"hf:{training.base_model}+lora:{output_dir} --benchmark simpleqa --output outputs/eval[/cyan]"
    )


def _build_judge(cfg: Config, api_key: str | None, *, spec: str | None = None):
    """Resolve the judge LLMClient. `spec` overrides config when provided."""
    from tool_trainer.llm import resolve_llm

    effective_spec = spec or f"{cfg.evaluation.judge_provider}:{cfg.evaluation.judge_model}"
    return resolve_llm(
        effective_spec,
        openai_api_key=api_key,
        temperature=cfg.evaluation.judge_temperature,
    )


@app.command(name="eval")
def eval_cmd(
    config: Path = typer.Option(..., "--config", help="Path to config.yaml."),
    benchmark: str = typer.Option(
        ...,
        "--benchmark",
        help="Benchmark spec: local:<path>, simpleqa, or browsecomp.",
    ),
    output: Path = typer.Option(..., "--output", help="Output directory."),
    limit: int = typer.Option(None, "--limit", help="Max examples to evaluate."),
    teacher_model: str = typer.Option(
        None,
        "--teacher-model",
        help="Model spec (openai:gpt-4o-mini | hf:<path> | hf:<base>+lora:<adapter>). "
        "Overrides config.teacher.",
    ),
    judge_model: str = typer.Option(
        None,
        "--judge-model",
        help="Judge model spec (openai:gpt-4o-mini | hf:<path>). "
        "Overrides config.evaluation.judge_model.",
    ),
    cache: str = typer.Option("on", "--cache", help="on|off — use SQLite search cache."),
    resume: bool = typer.Option(False, "--resume", help="Skip ids already in failures.jsonl."),
    save_failures_only: bool = typer.Option(
        False,
        "--save-failures-only",
        help="Keep only incorrect rows in failures.jsonl (summary still covers all).",
    ),
    concurrency: int = typer.Option(
        1,
        "--concurrency",
        help="Parallel in-flight examples (default 1 = sequential).",
    ),
) -> None:
    """Evaluate the pipeline on a tool-use benchmark."""
    cfg = Config.load(config)

    settings = load_settings()
    # Only require OPENAI_API_KEY if any resolved spec actually needs it.
    teacher_spec_effective = teacher_model or f"{cfg.teacher.provider}:{cfg.teacher.model}"
    judge_spec_effective = judge_model or (
        f"{cfg.evaluation.judge_provider}:{cfg.evaluation.judge_model}"
    )
    needs_openai = teacher_spec_effective.startswith("openai:") or judge_spec_effective.startswith(
        "openai:"
    )
    if needs_openai and not settings.openai_api_key:
        raise typer.Exit("OPENAI_API_KEY is not set (required by an openai: model spec).")
    if not settings.tavily_api_key:
        raise typer.Exit("TAVILY_API_KEY is not set.")

    loader = resolve_loader(benchmark)
    teacher = _build_teacher(cfg, settings.openai_api_key, spec=teacher_model)
    judge = _build_judge(cfg, settings.openai_api_key, spec=judge_model)
    search_tool = _build_search_tool(cfg, settings.tavily_api_key, cache.lower() == "on")

    generator = TraceGenerator(
        teacher=teacher,
        search_tool=search_tool,
        generation=cfg.generation,
        max_results=cfg.tool.max_results,
    )
    runner = EvalRunner(generator=generator, judge=judge, loader=loader, concurrency=concurrency)

    output_dir = ensure_dir(output)
    seen = load_seen_ids(output_dir) if resume else set()
    if seen:
        log.info("Resuming: skipping %d already-scored ids", len(seen))

    rows: list[EvalRow] = []
    for i, row in enumerate(runner.run(limit=limit, already_seen_ids=seen), start=1):
        rows.append(row)
        log.info(
            "[%d%s] %s — %s",
            i,
            f"/{limit}" if limit else "",
            row.id,
            (row.scores.answer_judgment or "ungraded"),
        )
        # Stream per-example progress so long runs don't lose state on crash.
        append_jsonl(output_dir / "failures.jsonl.partial", row)

    # Finalize: merge with any prior rows when resuming, write final artifacts.
    prior_rows: list[EvalRow] = []
    if seen:
        failures_path = output_dir / "failures.jsonl"
        if failures_path.exists():
            for obj in read_jsonl(failures_path):
                prior_rows.append(EvalRow.model_validate(obj))
    all_rows = prior_rows + rows

    summary = aggregate(
        all_rows,
        benchmark=loader.name,
        teacher_model=teacher_spec_effective,
        judge_model=judge_spec_effective,
    )
    summary_path = write_summary(output_dir, summary)
    failures_path = write_failures_jsonl(output_dir, all_rows, failures_only=save_failures_only)
    report_path = write_report(output_dir, summary, all_rows)
    html_path = write_html_report(output_dir, summary, all_rows)

    # Clean up the streaming partial.
    partial = output_dir / "failures.jsonl.partial"
    if partial.exists():
        partial.unlink()

    console.print(
        f"[bold green]Evaluated {len(rows)} new rows (total {summary.n}) — "
        f"answer_accuracy = {summary.answer_accuracy if summary.answer_accuracy is not None else 'n/a'}[/bold green]"
    )
    console.print(f"  summary:  {summary_path}")
    console.print(f"  failures: {failures_path}")
    console.print(f"  report:   {report_path}")
    console.print(f"  html:     {html_path}")


@app.command()
def serve() -> None:
    """Agent serving (not yet implemented — see ROADMAP v0.4.1)."""
    _not_implemented("serve")


@app.command()
def export() -> None:
    """Convert datasets to external formats (not yet implemented)."""
    _not_implemented("export")


@app.command()
def doctor() -> None:
    """Environment health check (not yet implemented)."""
    _not_implemented("doctor")


if __name__ == "__main__":  # pragma: no cover
    app()
