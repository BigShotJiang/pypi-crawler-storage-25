"""tool-trainer: train LLMs to use web search as a tool."""

__version__ = "0.4.1"
