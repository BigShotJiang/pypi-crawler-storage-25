"""Trace generator for `--mode sft`.

Implements the agent loop:
  1. router    — search vs no_search + reason
  2. if search: loop of
       query_writer → search_tool → critic
     until the critic says "answer" or max_search_steps is reached.
  3. answerer  — grounded in all search rounds

Single-step search (max_search_steps=1) is the degenerate case of the loop —
no special-case code path.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from tool_trainer.llm.base import LLMClient
from tool_trainer.prompts import load_prompt
from tool_trainer.schemas import (
    GenerationConfig,
    Message,
    RawQuestion,
    ToolCall,
    Trajectory,
    TrajectoryLabels,
    Usage,
)
from tool_trainer.tools.base import SearchTool

_VALID_ROUTER_REASONS = {
    "freshness",
    "specificity",
    "beyond_parametric",
    "parametric_ok",
    "arithmetic",
}


def _parse_json_response(content: str | None) -> dict[str, Any]:
    if not content:
        return {}
    text = content.strip()
    # Tolerate code fences even though we told the model not to use them.
    if text.startswith("```"):
        text = text.strip("`").lstrip("json").strip()
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    return parsed


def _usage_from_response(result: dict[str, Any]) -> Usage:
    u = result.get("usage") or {}
    return Usage(
        prompt_tokens=int(u.get("prompt_tokens", 0)),
        completion_tokens=int(u.get("completion_tokens", 0)),
    )


def _trim_results(results: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {
            "title": r.get("title", ""),
            "url": r.get("url", ""),
            "snippet": (r.get("content") or r.get("snippet") or "")[:500],
        }
        for r in results.get("results", [])
    ]


def _format_rounds(rounds: list[tuple[str, dict[str, Any]]]) -> str:
    """Render (query, results) rounds as the answerer/critic `results_block`."""
    if not rounds:
        return ""
    parts: list[str] = []
    for i, (query, results) in enumerate(rounds, start=1):
        parts.append(f"Round {i} (query: {query}):")
        parts.append(json.dumps(_trim_results(results), ensure_ascii=False, indent=2))
        parts.append("")
    return "Search rounds:\n" + "\n".join(parts).rstrip()


def _format_single_round(results: dict[str, Any]) -> str:
    """Compact single-round block used by the critic prompt."""
    return json.dumps(_trim_results(results), ensure_ascii=False, indent=2)


def _route(
    teacher: LLMClient, question: str, overrides_dir: str | Path | None
) -> tuple[bool, str, Usage]:
    """Ask the router. Returns (search_used, reason, usage)."""
    prompt = load_prompt("router", overrides_dir=overrides_dir).format(question=question)
    result = teacher.complete(
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    parsed = _parse_json_response(result.get("content"))
    decision = parsed.get("decision", "search")
    reason = parsed.get("reason", "freshness")
    if reason not in _VALID_ROUTER_REASONS:
        reason = "freshness" if decision == "search" else "parametric_ok"
    return decision == "search", reason, _usage_from_response(result)


def _write_query(
    teacher: LLMClient, question: str, reason: str, overrides_dir: str | Path | None
) -> tuple[str, Usage]:
    prompt = load_prompt("query_writer", overrides_dir=overrides_dir).format(
        question=question, reason=reason
    )
    result = teacher.complete(
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    parsed = _parse_json_response(result.get("content"))
    query = (parsed.get("query") or question).strip()
    return query[:500], _usage_from_response(result)


def _critic(
    teacher: LLMClient,
    question: str,
    query: str,
    results: dict[str, Any],
    overrides_dir: str | Path | None,
) -> tuple[str, str, Usage]:
    """Ask the critic. Returns (decision, reason, usage) with decision in {'answer','re_search'}.
    Malformed output falls back to 'answer' — we'd rather stop than loop on bad JSON."""
    prompt = load_prompt("critique", overrides_dir=overrides_dir).format(
        question=question,
        query=query,
        results_block=_format_single_round(results),
    )
    result = teacher.complete(
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    parsed = _parse_json_response(result.get("content"))
    raw_decision = str(parsed.get("decision", "")).lower()
    reason = str(parsed.get("reason", "")).strip()
    decision = "re_search" if raw_decision == "re_search" else "answer"
    if decision == "re_search" and not reason:
        # A "re_search" without a reason is useless downstream — force-stop.
        decision = "answer"
    return decision, reason, _usage_from_response(result)


def _answer(
    teacher: LLMClient,
    question: str,
    rounds: list[tuple[str, dict[str, Any]]],
    overrides_dir: str | Path | None,
) -> tuple[str, Usage]:
    prompt = load_prompt("answerer", overrides_dir=overrides_dir).format(
        question=question, results_block=_format_rounds(rounds)
    )
    result = teacher.complete(messages=[{"role": "user", "content": prompt}])
    return (result.get("content") or "").strip(), _usage_from_response(result)


def generate_trajectory_with_usage(
    question: RawQuestion,
    *,
    teacher: LLMClient,
    search_tool: SearchTool,
    generation: GenerationConfig,
    max_results: int = 5,
    overrides_dir: str | Path | None = None,
) -> tuple[Trajectory, Usage]:
    """Produce a Trajectory and the aggregate teacher-LLM token usage for one RawQuestion."""
    total_usage = Usage()

    search_used, router_reason, u = _route(teacher, question.question, overrides_dir)
    total_usage += u

    if not search_used:
        answer, u = _answer(teacher, question.question, rounds=[], overrides_dir=overrides_dir)
        total_usage += u
        return (
            Trajectory(
                id=question.id,
                messages=[
                    Message(role="user", content=question.question),
                    Message(role="assistant", content=answer),
                ],
                labels=TrajectoryLabels(
                    search_used=False, search_reason=router_reason, num_search_steps=0
                ),
            ),
            total_usage,
        )

    # Search path — loop until the critic says "answer" or we hit max_search_steps.
    max_steps = max(1, generation.max_search_steps)
    query, u = _write_query(teacher, question.question, router_reason, overrides_dir)
    total_usage += u

    messages: list[Message] = [Message(role="user", content=question.question)]
    rounds: list[tuple[str, dict[str, Any]]] = []

    while True:
        results = search_tool.search(query, max_results=max_results)
        rounds.append((query, results))
        messages.append(
            Message(
                role="assistant",
                tool_call=ToolCall(
                    name="web_search",
                    arguments={"query": query, "max_results": max_results},
                ),
            )
        )
        messages.append(
            Message(
                role="tool",
                name="web_search",
                content={"results": _trim_results(results)},
            )
        )

        if len(rounds) >= max_steps:
            break  # hard cap — force answer

        decision, critic_reason, u = _critic(
            teacher, question.question, query, results, overrides_dir
        )
        total_usage += u
        if decision == "answer":
            break

        # Re-search: record the critic's reasoning as an assistant content message,
        # then ask the query_writer for a refined query.
        messages.append(
            Message(
                role="assistant",
                content=f"Critique: {critic_reason}. Decision: re_search.",
            )
        )
        query, u = _write_query(teacher, question.question, critic_reason, overrides_dir)
        total_usage += u

    answer, u = _answer(teacher, question.question, rounds, overrides_dir)
    total_usage += u
    messages.append(Message(role="assistant", content=answer))

    return (
        Trajectory(
            id=question.id,
            messages=messages,
            labels=TrajectoryLabels(
                search_used=True,
                search_reason=router_reason,
                num_search_steps=len(rounds),
            ),
        ),
        total_usage,
    )


def generate_trajectory(
    question: RawQuestion,
    *,
    teacher: LLMClient,
    search_tool: SearchTool,
    generation: GenerationConfig,
    max_results: int = 5,
    overrides_dir: str | Path | None = None,
) -> Trajectory:
    """Thin wrapper — returns the Trajectory only, drops the usage tally."""
    traj, _ = generate_trajectory_with_usage(
        question,
        teacher=teacher,
        search_tool=search_tool,
        generation=generation,
        max_results=max_results,
        overrides_dir=overrides_dir,
    )
    return traj


class TraceGenerator:
    """Iterates questions → trajectories. `already_seen_ids` supports --resume."""

    def __init__(
        self,
        *,
        teacher: LLMClient,
        search_tool: SearchTool,
        generation: GenerationConfig,
        max_results: int = 5,
        overrides_dir: str | Path | None = None,
    ) -> None:
        self._teacher = teacher
        self._search_tool = search_tool
        self._generation = generation
        self._max_results = max_results
        self._overrides_dir = overrides_dir

    def generate(
        self,
        questions: list[RawQuestion],
        *,
        limit: int | None = None,
        already_seen_ids: set[str] | None = None,
    ) -> Iterator[Trajectory]:
        seen = already_seen_ids or set()
        emitted = 0
        for q in questions:
            if q.id in seen:
                continue
            if limit is not None and emitted >= limit:
                break
            traj = generate_trajectory(
                q,
                teacher=self._teacher,
                search_tool=self._search_tool,
                generation=self._generation,
                max_results=self._max_results,
                overrides_dir=self._overrides_dir,
            )
            emitted += 1
            yield traj

    def generate_one(self, question: RawQuestion) -> tuple[Trajectory, Usage]:
        """Generate a single trajectory and return its aggregate token usage."""
        return generate_trajectory_with_usage(
            question,
            teacher=self._teacher,
            search_tool=self._search_tool,
            generation=self._generation,
            max_results=self._max_results,
            overrides_dir=self._overrides_dir,
        )
