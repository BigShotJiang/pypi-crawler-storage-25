"""JSONL readers."""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from tool_trainer.schemas import RawQuestion, Trajectory


def read_jsonl(path: str | Path) -> Iterator[dict[str, Any]]:
    """Yield parsed objects. Skips blank lines; raises on malformed JSON with line number."""
    p = Path(path)
    with p.open("r", encoding="utf-8") as fh:
        for lineno, line in enumerate(fh, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{p}:{lineno}: invalid JSON — {e.msg}") from e


def load_questions(path: str | Path) -> list[RawQuestion]:
    return [RawQuestion.model_validate(obj) for obj in read_jsonl(path)]


def load_trajectories(path: str | Path) -> list[Trajectory]:
    return [Trajectory.model_validate(obj) for obj in read_jsonl(path)]
