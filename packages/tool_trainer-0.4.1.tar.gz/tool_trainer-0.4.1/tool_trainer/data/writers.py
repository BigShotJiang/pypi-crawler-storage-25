"""JSONL writers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from tool_trainer.utils.io import ensure_parent


def _to_json(obj: Any) -> str:
    if hasattr(obj, "model_dump_compact"):
        obj = obj.model_dump_compact()
    elif hasattr(obj, "model_dump"):
        obj = obj.model_dump(exclude_none=True)
    return json.dumps(obj, ensure_ascii=False, separators=(",", ": "))


def append_jsonl(path: str | Path, row: Any) -> None:
    """Append a single object. Used during streaming generation (resume-friendly)."""
    p = Path(path)
    ensure_parent(p)
    with p.open("a", encoding="utf-8") as fh:
        fh.write(_to_json(row) + "\n")
