"""Small helper to save a metadata.json alongside a trained LoRA adapter."""

from __future__ import annotations

import datetime as _dt
import json
import subprocess
from pathlib import Path
from typing import Any

from tool_trainer import __version__


def _git_sha() -> str | None:
    try:
        out = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
        )
        return out.stdout.strip()
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None


def save_training_metadata(
    output_dir: Path,
    *,
    base_model: str,
    data_path: Path,
    training_config: dict[str, Any],
    extra: dict[str, Any] | None = None,
) -> Path:
    """Write `metadata.json` next to the adapter files.

    Captures: tool-trainer version, git sha, base model, training data path,
    training config snapshot, and timestamp. Loaded back by `tt eval` if we
    ever want to auto-fill `--teacher-model` from a checkpoint path."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    payload: dict[str, Any] = {
        "tool_trainer_version": __version__,
        "git_sha": _git_sha(),
        "base_model": base_model,
        "data_path": str(data_path),
        "training_config": training_config,
        "created_at": _dt.datetime.now(tz=_dt.timezone.utc).isoformat(),
    }
    if extra:
        payload.update(extra)

    path = output_dir / "metadata.json"
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path
