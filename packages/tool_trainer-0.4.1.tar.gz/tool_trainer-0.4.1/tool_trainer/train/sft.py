"""SFT training with LoRA using TRL's SFTTrainer.

Heavy deps (transformers, trl, peft, accelerate, torch) are imported lazily
inside `run_sft` so this module can be imported without the `train` extra."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from tool_trainer.data.loaders import load_trajectories
from tool_trainer.schemas import TrainingConfig
from tool_trainer.train.checkpoints import save_training_metadata
from tool_trainer.train.formatting import trajectories_to_sft_rows


def _check_train_deps() -> None:
    """Early, friendly error if the user forgot the `[train]` extra."""
    missing = []
    try:
        import torch  # noqa: F401
    except ImportError:
        missing.append("torch")
    try:
        import transformers  # noqa: F401
    except ImportError:
        missing.append("transformers")
    try:
        import trl  # noqa: F401
    except ImportError:
        missing.append("trl")
    try:
        import peft  # noqa: F401
    except ImportError:
        missing.append("peft")
    if missing:
        raise RuntimeError(
            "Training deps missing: "
            + ", ".join(missing)
            + ".\nInstall with:  pip install 'tool-trainer[train]'"
        )


def run_sft(
    *,
    data_path: Path,
    output_dir: Path,
    training: TrainingConfig,
    overrides_dir: str | Path | None = None,
) -> Path:
    """Run LoRA SFT on a trajectory JSONL. Returns the output directory.

    Side effects: writes adapter files + metadata.json into `output_dir`.
    """
    _check_train_deps()

    # Lazy imports — only after we've confirmed the deps exist.
    from datasets import Dataset
    from peft import LoraConfig
    from transformers import AutoTokenizer
    from trl import SFTConfig, SFTTrainer

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Load trajectories and flatten to per-prompt SFT rows.
    trajectories = load_trajectories(data_path)
    sft_rows = trajectories_to_sft_rows(trajectories, overrides_dir=overrides_dir)
    if not sft_rows:
        raise ValueError(f"No trajectories found in {data_path!r}.")

    # 2. Build a HF Dataset of {"messages": [...]} rows. TRL's SFTTrainer applies
    #    the tokenizer's chat template and masks loss to the assistant turn.
    ds = Dataset.from_list([{"messages": row.to_messages()} for row in sft_rows])

    # 3. Tokenizer — needed by SFTTrainer for chat templating.
    tokenizer = AutoTokenizer.from_pretrained(training.base_model)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    # 4. LoRA config.
    peft_config = LoraConfig(
        r=training.lora_r,
        lora_alpha=training.lora_alpha,
        lora_dropout=training.lora_dropout,
        target_modules="all-linear",
        bias="none",
        task_type="CAUSAL_LM",
    )

    # 5. Training args.
    # `max_seq_length` moved out of SFTConfig in TRL 1.x; we pass it via tokenizer
    # truncation instead. Keep the config knob for future multi-step trajectories.
    sft_config_kwargs: dict[str, Any] = {
        "output_dir": str(output_dir),
        "num_train_epochs": training.epochs,
        "learning_rate": training.learning_rate,
        "per_device_train_batch_size": training.per_device_batch_size,
        "gradient_accumulation_steps": training.gradient_accumulation_steps,
        "bf16": training.bf16,
        "gradient_checkpointing": training.gradient_checkpointing,
        "seed": training.seed,
        "report_to": training.report_to if training.report_to != "none" else [],
        "logging_steps": 10,
        "save_strategy": "epoch",
        "save_total_limit": 2,
        "packing": False,
    }
    # `max_length` is the TRL 1.x name for the old `max_seq_length`; older TRL
    # uses `max_seq_length`. Try the modern name first.
    try:
        sft_config = SFTConfig(**sft_config_kwargs, max_length=training.max_seq_length)
    except TypeError:
        sft_config = SFTConfig(**sft_config_kwargs, max_seq_length=training.max_seq_length)

    # 6. Train. SFTTrainer loads the model itself; passing `model=<str>` lets it
    #    handle device placement via `accelerate`.
    trainer = SFTTrainer(
        model=training.base_model,
        args=sft_config,
        train_dataset=ds,
        processing_class=tokenizer,
        peft_config=peft_config,
    )
    trainer.train()
    trainer.save_model(str(output_dir))

    # 7. Write our own metadata snapshot alongside the adapter.
    save_training_metadata(
        output_dir,
        base_model=training.base_model,
        data_path=data_path,
        training_config=_training_config_dict(training),
        extra={"n_trajectories": len(trajectories), "n_sft_rows": len(sft_rows)},
    )
    return output_dir


def _training_config_dict(training: TrainingConfig) -> dict[str, Any]:
    return training.model_dump()
