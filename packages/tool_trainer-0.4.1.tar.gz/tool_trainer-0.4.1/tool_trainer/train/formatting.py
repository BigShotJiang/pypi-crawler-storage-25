"""Convert Trajectory objects into per-prompt SFT rows.

For a multi-step trajectory, we fan out to:
    router → (query_writer → critic){N-1} → query_writer → answerer
where N is num_search_steps. Critic runs between searches, not after the last
one, so there are N query_writer rows and (N-1) critic rows.

Training per-prompt directly optimizes what `TraceGenerator` does at inference
time, keeping the format model-agnostic (no chat-template-native tool tags).
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tool_trainer.prompts import load_prompt
from tool_trainer.schemas import Trajectory


@dataclass
class SFTRow:
    """A single user→assistant pair ready for chat-template SFT."""

    step: str  # "router" | "query_writer" | "critic" | "answerer"
    user: str
    assistant: str

    def to_messages(self) -> list[dict[str, str]]:
        return [
            {"role": "user", "content": self.user},
            {"role": "assistant", "content": self.assistant},
        ]


_CRITIC_CONTENT_RE = re.compile(r"^Critique:\s*(?P<reason>.+?)\.\s*Decision:\s*re_search\.?\s*$")


def _extract_user_question(traj: Trajectory) -> str:
    for msg in traj.messages:
        if msg.role == "user":
            return str(msg.content or "")
    return ""


def _extract_final_answer(traj: Trajectory) -> str:
    for msg in reversed(traj.messages):
        if msg.role == "assistant" and msg.tool_call is None and msg.content is not None:
            txt = str(msg.content)
            # Skip critic messages ("Critique: ... Decision: re_search.") so the
            # final natural-language answer is what we find.
            if not _CRITIC_CONTENT_RE.match(txt.strip()):
                return txt
    return ""


def _trim_tool_content(tool_content: Any) -> list[dict[str, str]]:
    if not isinstance(tool_content, dict):
        return []
    return [
        {
            "title": r.get("title", ""),
            "url": r.get("url", ""),
            "snippet": (r.get("snippet") or r.get("content") or "")[:500],
        }
        for r in tool_content.get("results", [])
    ]


def _format_rounds(rounds: list[tuple[str, list[dict[str, str]]]]) -> str:
    if not rounds:
        return ""
    parts: list[str] = []
    for i, (query, results) in enumerate(rounds, start=1):
        parts.append(f"Round {i} (query: {query}):")
        parts.append(json.dumps(results, ensure_ascii=False, indent=2))
        parts.append("")
    return "Search rounds:\n" + "\n".join(parts).rstrip()


def _format_single_round(results: list[dict[str, str]]) -> str:
    return json.dumps(results, ensure_ascii=False, indent=2)


def _iter_search_rounds(
    traj: Trajectory,
) -> list[tuple[str, list[dict[str, str]], str | None]]:
    """Walk the trajectory and yield (query, results, critic_reason_or_None) per round.

    `critic_reason` is the critic's reason that follows this round's tool result,
    or `None` if this round was the last one (critic never runs after the final
    search). For a 1-step trajectory: one round, critic_reason=None.
    """
    rounds: list[tuple[str, list[dict[str, str]], str | None]] = []
    i = 0
    msgs = traj.messages
    while i < len(msgs):
        msg = msgs[i]
        if msg.role == "assistant" and msg.tool_call is not None:
            query = str(msg.tool_call.arguments.get("query", ""))
            # Next message should be the tool result.
            if i + 1 < len(msgs) and msgs[i + 1].role == "tool":
                results = _trim_tool_content(msgs[i + 1].content)
                # Optional critic message follows the tool result before the next tool_call.
                critic_reason: str | None = None
                j = i + 2
                if j < len(msgs):
                    nxt = msgs[j]
                    if (
                        nxt.role == "assistant"
                        and nxt.tool_call is None
                        and isinstance(nxt.content, str)
                    ):
                        match = _CRITIC_CONTENT_RE.match(nxt.content.strip())
                        if match:
                            critic_reason = match.group("reason").strip()
                rounds.append((query, results, critic_reason))
                i = j if critic_reason else (i + 2)
                continue
        i += 1
    return rounds


def trajectory_to_sft_rows(
    traj: Trajectory, *, overrides_dir: str | Path | None = None
) -> list[SFTRow]:
    """Fan a single trajectory out into its per-prompt SFT rows.

    - No-search trajectory         → [router, answerer]                             (2 rows)
    - 1-step search trajectory     → [router, query_writer, answerer]               (3 rows)
    - N-step search trajectory     → [router, (query_writer, critic)×(N-1),
                                       query_writer, answerer]                      (2N + 1 rows)
    """
    question = _extract_user_question(traj)
    labels = traj.labels
    rows: list[SFTRow] = []

    # 1) Router row — always present.
    router_prompt = load_prompt("router", overrides_dir=overrides_dir).format(question=question)
    router_decision = "search" if labels.search_used else "no_search"
    router_response = json.dumps(
        {"decision": router_decision, "reason": labels.search_reason or ""},
        ensure_ascii=False,
    )
    rows.append(SFTRow(step="router", user=router_prompt, assistant=router_response))

    # 2) No-search trajectories stop here with just an answerer row.
    if not labels.search_used:
        answerer_prompt = load_prompt("answerer", overrides_dir=overrides_dir).format(
            question=question, results_block=""
        )
        rows.append(
            SFTRow(step="answerer", user=answerer_prompt, assistant=_extract_final_answer(traj))
        )
        return rows

    # 3) Search path — fan out each round into query_writer (+ optional critic) rows.
    search_rounds = _iter_search_rounds(traj)
    if not search_rounds:
        # Defensive: labels say searched but no tool_call messages exist.
        return rows

    prior_reason = labels.search_reason or ""
    for idx, (query, results, critic_reason) in enumerate(search_rounds):
        qw_prompt = load_prompt("query_writer", overrides_dir=overrides_dir).format(
            question=question, reason=prior_reason
        )
        qw_response = json.dumps({"query": query}, ensure_ascii=False)
        rows.append(SFTRow(step="query_writer", user=qw_prompt, assistant=qw_response))

        # Critic runs only between searches — not after the last round.
        is_last_round = idx == len(search_rounds) - 1
        if not is_last_round:
            critic_prompt = load_prompt("critique", overrides_dir=overrides_dir).format(
                question=question,
                query=query,
                results_block=_format_single_round(results),
            )
            critic_response = json.dumps(
                {
                    "decision": "re_search",
                    "reason": critic_reason or "results insufficient",
                },
                ensure_ascii=False,
            )
            rows.append(SFTRow(step="critic", user=critic_prompt, assistant=critic_response))
            # Next query_writer uses the critic's reason as its input.
            prior_reason = critic_reason or prior_reason

    # 4) Final answerer row — sees all rounds concatenated.
    rounds_for_block: list[tuple[str, list[dict[str, str]]]] = [
        (q, r) for (q, r, _) in search_rounds
    ]
    answerer_prompt = load_prompt("answerer", overrides_dir=overrides_dir).format(
        question=question, results_block=_format_rounds(rounds_for_block)
    )
    rows.append(
        SFTRow(step="answerer", user=answerer_prompt, assistant=_extract_final_answer(traj))
    )
    return rows


def trajectories_to_sft_rows(
    trajectories: Iterable[Trajectory], *, overrides_dir: str | Path | None = None
) -> list[SFTRow]:
    """Fan a collection of trajectories into a flat SFT-row list."""
    out: list[SFTRow] = []
    for traj in trajectories:
        out.extend(trajectory_to_sft_rows(traj, overrides_dir=overrides_dir))
    return out
