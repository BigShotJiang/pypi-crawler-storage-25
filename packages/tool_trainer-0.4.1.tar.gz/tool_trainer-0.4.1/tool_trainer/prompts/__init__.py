"""Prompt loading. Prompts ship as package data; users can override per-project."""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path

_PROMPT_NAMES = ("router", "query_writer", "critique", "answerer", "judge_answer")
_TT_INIT_PROMPTS = ("router", "query_writer", "critique", "answerer")  # what `tt init` scaffolds


def load_prompt(name: str, *, overrides_dir: str | Path | None = None) -> str:
    """Load a named prompt. Overrides: if `overrides_dir/<name>.txt` exists, use it
    instead of the packaged version."""
    if name not in _PROMPT_NAMES:
        raise ValueError(f"Unknown prompt {name!r}; known: {_PROMPT_NAMES}")

    if overrides_dir is not None:
        candidate = Path(overrides_dir) / f"{name}.txt"
        if candidate.exists():
            return candidate.read_text(encoding="utf-8")

    return files("tool_trainer.prompts").joinpath(f"{name}.txt").read_text(encoding="utf-8")


def prompt_files() -> dict[str, str]:
    """Return {name: content} for the project-scaffold prompts. Used by `tt init`.
    (Excludes eval-side prompts like judge_answer which users don't typically edit.)"""
    return {name: load_prompt(name) for name in _TT_INIT_PROMPTS}
