"""Eval runner: loads questions → runs agent pipeline → scores → yields EvalRow.

`concurrency > 1` parallelizes the per-example loop with a ThreadPoolExecutor.
The bottleneck is network I/O (OpenAI + Tavily), so threads suffice — no async.
Rows are yielded in completion order (not input order) when concurrent."""

from __future__ import annotations

import time
from collections.abc import Iterator
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path

from tool_trainer.eval.datasets.base import BenchmarkLoader
from tool_trainer.eval.scorer import score_trajectory
from tool_trainer.generate import TraceGenerator
from tool_trainer.llm.base import LLMClient
from tool_trainer.schemas import EvalRow, RawQuestion


class EvalRunner:
    def __init__(
        self,
        *,
        generator: TraceGenerator,
        judge: LLMClient,
        loader: BenchmarkLoader,
        overrides_dir: str | Path | None = None,
        concurrency: int = 1,
    ) -> None:
        self._generator = generator
        self._judge = judge
        self._loader = loader
        self._overrides_dir = str(overrides_dir) if overrides_dir else None
        self._concurrency = max(1, concurrency)

    def run(
        self,
        *,
        limit: int | None = None,
        already_seen_ids: set[str] | None = None,
    ) -> Iterator[EvalRow]:
        seen = already_seen_ids or set()

        # Pre-filter inputs so limit/seen semantics are clear before threading.
        def _pending() -> Iterator[RawQuestion]:
            emitted = 0
            for q in self._loader.load(limit=None):
                if q.id in seen:
                    continue
                if limit is not None and emitted >= limit:
                    break
                emitted += 1
                yield q

        if self._concurrency == 1:
            for q in _pending():
                yield self._score_one(q)
            return

        # Concurrent path: keep a rolling window of in-flight tasks equal to concurrency.
        with ThreadPoolExecutor(max_workers=self._concurrency) as pool:
            pending_iter = _pending()
            in_flight = {}
            # Prime the window.
            for _ in range(self._concurrency):
                try:
                    q = next(pending_iter)
                except StopIteration:
                    break
                in_flight[pool.submit(self._score_one, q)] = q

            while in_flight:
                done, _ = wait(in_flight.keys(), return_when=FIRST_COMPLETED)
                for fut in done:
                    in_flight.pop(fut)
                    try:
                        q = next(pending_iter)
                    except StopIteration:
                        pass
                    else:
                        in_flight[pool.submit(self._score_one, q)] = q
                    yield fut.result()

    def _score_one(self, question: RawQuestion) -> EvalRow:
        t0 = time.perf_counter()
        trajectory, teacher_usage = self._generator.generate_one(question)
        scores, judge_usage = score_trajectory(
            trajectory,
            question.answer,
            question.metadata.get("requires_search"),
            judge=self._judge,
            overrides_dir=self._overrides_dir,
        )
        total = teacher_usage + judge_usage
        return EvalRow(
            id=question.id,
            question=question.question,
            gold_answer=question.answer,
            trajectory=trajectory,
            scores=scores,
            latency_ms=int((time.perf_counter() - t0) * 1000),
            tokens_in=total.prompt_tokens,
            tokens_out=total.completion_tokens,
        )
