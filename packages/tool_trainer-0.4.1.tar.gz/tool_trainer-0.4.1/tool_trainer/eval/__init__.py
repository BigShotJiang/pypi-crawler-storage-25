"""Evaluation: score pipeline trajectories against tool-use benchmarks."""

from tool_trainer.eval.metrics import aggregate
from tool_trainer.eval.runner import EvalRunner
from tool_trainer.eval.scorer import score_trajectory

__all__ = ["EvalRunner", "aggregate", "score_trajectory"]
