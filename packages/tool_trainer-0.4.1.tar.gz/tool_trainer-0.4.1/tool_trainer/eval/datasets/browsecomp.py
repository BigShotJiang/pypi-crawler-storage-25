"""BrowseComp loader.

Source: OpenAI's simple-evals (https://github.com/openai/simple-evals).
Data file: https://openaipublic.blob.core.windows.net/simple-evals/browse_comp_test_set.csv
Columns: `problem`, `answer`, `canary` — `problem` and `answer` are XOR-encrypted with
the SHA256 key derived from the `canary` password (same scheme used by OpenAI).

The encryption is OpenAI's way of preventing training-data leakage — it's not a secret,
the canary is right there in the CSV. Decryption is deterministic and public.
"""

from __future__ import annotations

import base64
import csv
import hashlib
import urllib.request
from collections.abc import Iterator
from pathlib import Path

from tool_trainer.schemas import RawQuestion

DATA_URL = "https://openaipublic.blob.core.windows.net/simple-evals/browse_comp_test_set.csv"
CACHE_DIR = Path.home() / ".cache" / "tool-trainer" / "browsecomp"


def _derive_key(password: str, length: int) -> bytes:
    """Repeat SHA256(password) to reach `length` bytes."""
    h = hashlib.sha256(password.encode("utf-8")).digest()
    reps = (length // len(h)) + 1
    return (h * reps)[:length]


def derive_key(password: str, length: int) -> bytes:
    """Public helper — exported so tests can encrypt test fixtures."""
    return _derive_key(password, length)


def decrypt_field(ciphertext_b64: str, password: str) -> str:
    """XOR-decrypt a base64-encoded field with the SHA256-derived key."""
    ct = base64.b64decode(ciphertext_b64)
    key = _derive_key(password, len(ct))
    return bytes(a ^ b for a, b in zip(ct, key, strict=False)).decode("utf-8")


def encrypt_field(plaintext: str, password: str) -> str:
    """Inverse of decrypt_field — useful only for test fixtures."""
    pt = plaintext.encode("utf-8")
    key = _derive_key(password, len(pt))
    return base64.b64encode(bytes(a ^ b for a, b in zip(pt, key, strict=False))).decode("ascii")


def _ensure_cached_csv(url: str = DATA_URL, cache_dir: Path = CACHE_DIR) -> Path:
    cache_dir.mkdir(parents=True, exist_ok=True)
    dest = cache_dir / "browse_comp_test_set.csv"
    if not dest.exists():
        with urllib.request.urlopen(url) as resp, dest.open("wb") as fh:
            fh.write(resp.read())
    return dest


class BrowseCompLoader:
    name = "browsecomp"

    def __init__(
        self,
        *,
        url: str = DATA_URL,
        cache_dir: Path = CACHE_DIR,
        csv_path: Path | None = None,
    ) -> None:
        """`csv_path` overrides download — used by tests to point at a fixture file."""
        self._url = url
        self._cache_dir = cache_dir
        self._csv_path = csv_path

    def _resolve_path(self) -> Path:
        if self._csv_path is not None:
            return self._csv_path
        return _ensure_cached_csv(self._url, self._cache_dir)

    def load(self, limit: int | None = None) -> Iterator[RawQuestion]:
        path = self._resolve_path()
        with path.open("r", encoding="utf-8", newline="") as fh:
            reader = csv.DictReader(fh)
            for i, row in enumerate(reader):
                if limit is not None and i >= limit:
                    break
                canary = row.get("canary", "")
                question = decrypt_field(row.get("problem", ""), canary)
                answer = decrypt_field(row.get("answer", ""), canary)
                yield RawQuestion(
                    id=f"browsecomp_{i:05d}",
                    question=question,
                    answer=answer,
                    metadata={
                        "benchmark": "browsecomp",
                        "requires_search": True,  # definitionally true for BrowseComp
                    },
                )
