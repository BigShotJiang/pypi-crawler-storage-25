"""Benchmark loaders. Resolve a `--benchmark SPEC` string to a BenchmarkLoader."""

from __future__ import annotations

from tool_trainer.eval.datasets.base import BenchmarkLoader
from tool_trainer.eval.datasets.browsecomp import BrowseCompLoader
from tool_trainer.eval.datasets.local_jsonl import LocalJsonlLoader
from tool_trainer.eval.datasets.simpleqa import SimpleQALoader

__all__ = [
    "BenchmarkLoader",
    "BrowseCompLoader",
    "LocalJsonlLoader",
    "SimpleQALoader",
    "resolve_loader",
]


def resolve_loader(spec: str) -> BenchmarkLoader:
    """Parse a benchmark spec into a loader.

    Forms:
      local:/path/to/eval.jsonl
      simpleqa
      browsecomp
    """
    if spec.startswith("local:"):
        return LocalJsonlLoader(path=spec[len("local:") :])
    if spec == "simpleqa":
        return SimpleQALoader()
    if spec == "browsecomp":
        return BrowseCompLoader()
    raise ValueError(
        f"Unknown --benchmark spec {spec!r}. Use one of: local:<path>, simpleqa, browsecomp."
    )
