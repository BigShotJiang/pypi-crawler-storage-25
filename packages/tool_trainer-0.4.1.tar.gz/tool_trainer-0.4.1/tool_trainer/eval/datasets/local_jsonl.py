"""Load a benchmark from a local JSONL file of RawQuestion rows."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from tool_trainer.data.loaders import read_jsonl
from tool_trainer.schemas import RawQuestion


class LocalJsonlLoader:
    name = "local"

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        if not self._path.exists():
            raise FileNotFoundError(f"Benchmark file not found: {self._path}")

    def load(self, limit: int | None = None) -> Iterator[RawQuestion]:
        for i, obj in enumerate(read_jsonl(self._path)):
            if limit is not None and i >= limit:
                break
            yield RawQuestion.model_validate(obj)
