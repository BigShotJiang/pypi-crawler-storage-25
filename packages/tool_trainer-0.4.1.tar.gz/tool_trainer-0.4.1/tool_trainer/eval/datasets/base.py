"""BenchmarkLoader Protocol."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Protocol, runtime_checkable

from tool_trainer.schemas import RawQuestion


@runtime_checkable
class BenchmarkLoader(Protocol):
    name: str

    def load(self, limit: int | None = None) -> Iterator[RawQuestion]: ...
