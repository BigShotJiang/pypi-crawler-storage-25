"""SimpleQA loader.

Source: https://huggingface.co/datasets/basicv8vc/SimpleQA (public, MIT, 4326 rows).
Row schema: {"metadata": {"topic": str, "answer_type": str, "urls": list[str]},
             "problem": str, "answer": str}.
"""

from __future__ import annotations

import ast
from collections.abc import Iterator
from typing import Any

from tool_trainer.schemas import RawQuestion

HF_REPO = "basicv8vc/SimpleQA"
HF_SPLIT = "test"


def _coerce_metadata(raw: Any) -> dict[str, Any]:
    """HF rows sometimes serialize `metadata` as a Python-dict string. Handle both."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = ast.literal_eval(raw)
            return parsed if isinstance(parsed, dict) else {}
        except (ValueError, SyntaxError):
            return {}
    return {}


class SimpleQALoader:
    name = "simpleqa"

    def __init__(self, repo: str = HF_REPO, split: str = HF_SPLIT) -> None:
        self._repo = repo
        self._split = split

    def load(self, limit: int | None = None) -> Iterator[RawQuestion]:
        # Lazy import so tests without `datasets` installed can still import this module
        # and the surrounding eval package.
        from datasets import load_dataset

        ds = load_dataset(self._repo, split=self._split)
        for i, row in enumerate(ds):
            if limit is not None and i >= limit:
                break
            meta = _coerce_metadata(row.get("metadata"))
            yield RawQuestion(
                id=f"simpleqa_{i:05d}",
                question=str(row["problem"]),
                answer=str(row["answer"]),
                metadata={
                    "benchmark": "simpleqa",
                    "topic": meta.get("topic"),
                    "answer_type": meta.get("answer_type"),
                    "reference_urls": meta.get("urls", []),
                    # SimpleQA rows don't have a per-row requires_search label.
                    # Leaving it absent so search_decision_accuracy stays None.
                },
            )
