"""Aggregate per-example EvalRow[] into an EvalSummary."""

from __future__ import annotations

from tool_trainer.schemas import EvalRow, EvalSummary


def _safe_ratio(num: int, denom: int) -> float | None:
    return (num / denom) if denom > 0 else None


def aggregate(
    rows: list[EvalRow],
    *,
    benchmark: str,
    teacher_model: str,
    judge_model: str,
) -> EvalSummary:
    n = len(rows)
    if n == 0:
        return EvalSummary(
            benchmark=benchmark, teacher_model=teacher_model, judge_model=judge_model, n=0
        )

    graded = [r for r in rows if r.scores.answer_correct is not None]
    n_correct = sum(1 for r in graded if r.scores.answer_correct)
    n_incorrect = sum(1 for r in graded if r.scores.answer_judgment == "incorrect")
    n_not_attempted = sum(1 for r in graded if r.scores.answer_judgment == "not_attempted")
    n_ungraded = n - len(graded)

    sd_graded = [r for r in rows if r.scores.search_decision_correct is not None]
    sd_correct = sum(1 for r in sd_graded if r.scores.search_decision_correct)

    return EvalSummary(
        benchmark=benchmark,
        teacher_model=teacher_model,
        judge_model=judge_model,
        n=n,
        answer_accuracy=_safe_ratio(n_correct, len(graded)),
        search_decision_accuracy=_safe_ratio(sd_correct, len(sd_graded)),
        avg_searches_per_example=sum(r.scores.num_searches for r in rows) / n,
        avg_latency_ms=sum(r.latency_ms for r in rows) / n,
        total_tokens_in=sum(r.tokens_in for r in rows),
        total_tokens_out=sum(r.tokens_out for r in rows),
        n_correct=n_correct,
        n_incorrect=n_incorrect,
        n_not_attempted=n_not_attempted,
        n_ungraded=n_ungraded,
    )
