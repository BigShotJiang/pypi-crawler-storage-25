"""Per-trajectory scoring.

One LLM judge call per example (for answer_accuracy). Everything else is
deterministic from the trajectory."""

from __future__ import annotations

import json
from typing import Any

from tool_trainer.llm.base import LLMClient
from tool_trainer.prompts import load_prompt
from tool_trainer.schemas import EvalScores, Trajectory, Usage

_JUDGMENT_MAP = {
    "CORRECT": ("correct", True),
    "INCORRECT": ("incorrect", False),
    "NOT_ATTEMPTED": ("not_attempted", False),
}


def _final_assistant_answer(trajectory: Trajectory) -> str:
    """Extract the model's final natural-language answer (last assistant
    message without a tool_call)."""
    for msg in reversed(trajectory.messages):
        if msg.role == "assistant" and msg.tool_call is None and msg.content is not None:
            return str(msg.content)
    return ""


def _parse_judge(content: str | None) -> tuple[str, str]:
    """Return (judgment_token, reason). Falls back to NOT_ATTEMPTED on parse failure."""
    if not content:
        return "NOT_ATTEMPTED", "judge returned empty content"
    text = content.strip()
    if text.startswith("```"):
        text = text.strip("`").lstrip("json").strip()
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return "NOT_ATTEMPTED", f"judge returned non-JSON: {text[:80]}"
    judgment = str(parsed.get("judgment", "")).upper()
    reason = str(parsed.get("reason", ""))
    if judgment not in _JUDGMENT_MAP:
        return "NOT_ATTEMPTED", f"judge returned unknown judgment: {judgment!r}"
    return judgment, reason


def score_trajectory(
    trajectory: Trajectory,
    gold_answer: str | None,
    requires_search: bool | None,
    *,
    judge: LLMClient,
    overrides_dir: str | None = None,
) -> tuple[EvalScores, Usage]:
    """Score one trajectory. Returns (scores, judge_usage)."""
    judge_usage = Usage()

    # Deterministic signals first.
    num_searches = trajectory.labels.num_search_steps
    if requires_search is None:
        search_decision_correct: bool | None = None
    else:
        search_decision_correct = bool(requires_search) == bool(trajectory.labels.search_used)

    # Judge the answer only if there's a gold to judge against.
    if gold_answer is None:
        return (
            EvalScores(
                answer_correct=None,
                answer_judgment=None,
                answer_judge_reason=None,
                search_decision_correct=search_decision_correct,
                num_searches=num_searches,
            ),
            judge_usage,
        )

    question = next(
        (m.content for m in trajectory.messages if m.role == "user"),
        "",
    )
    predicted = _final_assistant_answer(trajectory)

    prompt = load_prompt("judge_answer", overrides_dir=overrides_dir).format(
        question=str(question),
        gold_answer=gold_answer,
        predicted_answer=predicted or "(model produced no final answer)",
    )
    result: dict[str, Any] = judge.complete(
        messages=[{"role": "user", "content": prompt}],
        temperature=0.0,
        response_format={"type": "json_object"},
    )
    judgment_token, reason = _parse_judge(result.get("content"))
    judgment_label, is_correct = _JUDGMENT_MAP[judgment_token]

    u = result.get("usage") or {}
    judge_usage = Usage(
        prompt_tokens=int(u.get("prompt_tokens", 0)),
        completion_tokens=int(u.get("completion_tokens", 0)),
    )

    return (
        EvalScores(
            answer_correct=is_correct,
            answer_judgment=judgment_label,  # type: ignore[arg-type]
            answer_judge_reason=reason,
            search_decision_correct=search_decision_correct,
            num_searches=num_searches,
        ),
        judge_usage,
    )
