"""Write eval outputs: summary.json, failures.jsonl, report.md, report.html."""

from __future__ import annotations

import datetime as _dt
import html as _html
import json
from pathlib import Path

from tool_trainer.schemas import EvalRow, EvalSummary
from tool_trainer.utils.io import ensure_dir

SUMMARY_FILE = "summary.json"
FAILURES_FILE = "failures.jsonl"
REPORT_FILE = "report.md"
HTML_REPORT_FILE = "report.html"


def write_summary(output_dir: Path, summary: EvalSummary) -> Path:
    ensure_dir(output_dir)
    path = output_dir / SUMMARY_FILE
    path.write_text(
        json.dumps(summary.model_dump(), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return path


def _final_answer(row: EvalRow) -> str:
    for msg in reversed(row.trajectory.messages):
        if msg.role == "assistant" and msg.tool_call is None and msg.content is not None:
            return str(msg.content)
    return ""


def _query_used(row: EvalRow) -> str | None:
    for msg in row.trajectory.messages:
        if msg.role == "assistant" and msg.tool_call is not None:
            return str(msg.tool_call.arguments.get("query", ""))
    return None


def _fmt_opt(value: float | None, fmt: str = ".3f") -> str:
    return "n/a" if value is None else format(value, fmt)


def write_report(
    output_dir: Path,
    summary: EvalSummary,
    rows: list[EvalRow],
    *,
    max_failures: int = 10,
) -> Path:
    ensure_dir(output_dir)
    lines: list[str] = []
    lines.append(f"# Eval report — {summary.benchmark}")
    lines.append("")
    lines.append(f"- Teacher: `{summary.teacher_model}`")
    lines.append(f"- Judge: `{summary.judge_model}`")
    lines.append(f"- N: {summary.n}")
    lines.append(f"- Date: {_dt.date.today().isoformat()}")
    lines.append("")
    lines.append("## Metrics")
    lines.append("")
    lines.append("| metric | value |")
    lines.append("| --- | --- |")
    lines.append(f"| answer_accuracy | {_fmt_opt(summary.answer_accuracy)} |")
    lines.append(f"| search_decision_accuracy | {_fmt_opt(summary.search_decision_accuracy)} |")
    lines.append(f"| avg_searches_per_example | {summary.avg_searches_per_example:.3f} |")
    lines.append(f"| avg_latency_ms | {summary.avg_latency_ms:.0f} |")
    lines.append(
        f"| tokens (in / out) | {summary.total_tokens_in:,} / {summary.total_tokens_out:,} |"
    )
    lines.append("")
    lines.append("## Breakdown")
    lines.append("")
    lines.append(
        f"- correct: {summary.n_correct}  |  incorrect: {summary.n_incorrect}  |  "
        f"not_attempted: {summary.n_not_attempted}  |  ungraded: {summary.n_ungraded}"
    )
    lines.append("")

    failures = [r for r in rows if r.scores.answer_correct is False][:max_failures]
    if failures:
        lines.append(f"## Worst failures (up to {max_failures})")
        lines.append("")
        for r in failures:
            label = (r.scores.answer_judgment or "?").upper()
            lines.append(f"### {r.id} — {label}")
            lines.append("")
            lines.append(f"**Question:** {r.question}")
            lines.append("")
            if r.gold_answer is not None:
                lines.append(f"**Gold:** {r.gold_answer}")
                lines.append("")
            lines.append(f"**Model answer:** {_final_answer(r) or '(empty)'}")
            lines.append("")
            if r.scores.answer_judge_reason:
                lines.append(f"**Judge reason:** {r.scores.answer_judge_reason}")
                lines.append("")
            q = _query_used(r)
            lines.append(
                f"**Searched?** {'yes' if r.trajectory.labels.search_used else 'no'} "
                f"({r.scores.num_searches} step{'s' if r.scores.num_searches != 1 else ''})"
                + (f" — query: `{q}`" if q else "")
            )
            lines.append("")

    path = output_dir / REPORT_FILE
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def write_failures_jsonl(
    output_dir: Path, rows: list[EvalRow], *, failures_only: bool = False
) -> Path:
    ensure_dir(output_dir)
    path = output_dir / FAILURES_FILE
    to_write = rows if not failures_only else [r for r in rows if r.scores.answer_correct is False]
    with path.open("w", encoding="utf-8") as fh:
        for r in to_write:
            fh.write(json.dumps(r.model_dump(exclude_none=True), ensure_ascii=False) + "\n")
    return path


_HTML_CSS = """
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
       max-width: 960px; margin: 2em auto; padding: 0 1em; color: #1f2328; line-height: 1.5; }
h1 { border-bottom: 1px solid #d0d7de; padding-bottom: 0.3em; }
h2 { margin-top: 2em; border-bottom: 1px solid #d0d7de; padding-bottom: 0.2em; }
code, pre { font-family: ui-monospace, "SF Mono", Menlo, monospace; background: #f6f8fa;
            padding: 0.1em 0.4em; border-radius: 4px; font-size: 0.9em; }
pre { padding: 0.8em; overflow-x: auto; }
table { border-collapse: collapse; margin: 1em 0; }
th, td { border: 1px solid #d0d7de; padding: 0.4em 0.8em; text-align: left; }
th { background: #f6f8fa; }
.bar { display: inline-block; height: 10px; background: #2da44e; border-radius: 4px;
       vertical-align: middle; margin-left: 0.5em; }
.bar-track { display: inline-block; height: 10px; width: 120px; background: #eaeef2;
             border-radius: 4px; vertical-align: middle; margin-left: 0.5em; position: relative; }
.bar-fill { position: absolute; left: 0; top: 0; height: 100%; background: #2da44e;
            border-radius: 4px; }
.bar-fill.low { background: #cf222e; }
.bar-fill.mid { background: #bf8700; }
details { margin: 0.5em 0; padding: 0.6em 1em; background: #f6f8fa; border-radius: 6px; }
summary { cursor: pointer; font-weight: 600; }
.label { display: inline-block; padding: 0.1em 0.6em; border-radius: 4px; font-size: 0.85em;
         font-weight: 600; color: white; }
.label.correct { background: #2da44e; }
.label.incorrect { background: #cf222e; }
.label.not_attempted { background: #8250df; }
.meta { color: #656d76; font-size: 0.9em; margin-bottom: 1em; }
.msg { margin: 0.5em 0; padding: 0.6em 1em; border-left: 3px solid #d0d7de; background: #fff; }
.msg.user { border-left-color: #0969da; }
.msg.assistant { border-left-color: #2da44e; }
.msg.tool { border-left-color: #bf8700; }
.role { font-weight: 600; color: #656d76; font-size: 0.85em; text-transform: uppercase; }
"""


def _bar(value: float | None, *, width: int = 120) -> str:
    """Inline HTML bar showing 0..1 value, colored by bucket. `None` → empty track."""
    if value is None:
        return f'<span class="bar-track" style="width:{width}px;"></span>'
    pct = max(0.0, min(1.0, float(value))) * 100
    color = "low" if value < 0.5 else ("mid" if value < 0.8 else "")
    return (
        f'<span class="bar-track" style="width:{width}px;">'
        f'<span class="bar-fill {color}" style="width:{pct:.1f}%;"></span>'
        f"</span>"
    )


def _html_message(role: str, body: str) -> str:
    return (
        f'<div class="msg {_html.escape(role)}">'
        f'<div class="role">{_html.escape(role)}</div>'
        f"<div>{body}</div></div>"
    )


def _render_trajectory_html(row: EvalRow) -> str:
    """Render the full trajectory of an EvalRow as a series of message boxes."""
    parts: list[str] = []
    for msg in row.trajectory.messages:
        if msg.role == "user":
            parts.append(_html_message("user", _html.escape(str(msg.content or ""))))
        elif msg.role == "assistant" and msg.tool_call is not None:
            args = json.dumps(msg.tool_call.arguments, ensure_ascii=False)
            parts.append(
                _html_message(
                    "assistant",
                    f"<code>tool_call: {_html.escape(msg.tool_call.name)}"
                    f"({_html.escape(args)})</code>",
                )
            )
        elif msg.role == "tool":
            content = msg.content
            if isinstance(content, dict):
                results = content.get("results", [])
                items = "".join(
                    f"<li>{_html.escape(r.get('title', ''))} — "
                    f"<code>{_html.escape(r.get('url', ''))}</code></li>"
                    for r in results[:5]
                )
                parts.append(_html_message("tool", f"<ul>{items}</ul>"))
            else:
                parts.append(_html_message("tool", _html.escape(str(content or ""))))
        elif msg.role == "assistant":
            parts.append(_html_message("assistant", _html.escape(str(msg.content or ""))))
    return "".join(parts)


def write_html_report(
    output_dir: Path,
    summary: EvalSummary,
    rows: list[EvalRow],
    *,
    max_failures: int = 20,
) -> Path:
    """Self-contained HTML (inline CSS, no external assets). Opens directly in a browser."""
    ensure_dir(output_dir)
    e = _html.escape

    parts: list[str] = [
        "<!DOCTYPE html>",
        '<html lang="en"><head><meta charset="utf-8">',
        f"<title>Eval report — {e(summary.benchmark)}</title>",
        f"<style>{_HTML_CSS}</style>",
        "</head><body>",
        f"<h1>Eval report — {e(summary.benchmark)}</h1>",
        '<div class="meta">',
        f"Teacher: <code>{e(summary.teacher_model)}</code> · ",
        f"Judge: <code>{e(summary.judge_model)}</code> · ",
        f"N: {summary.n} · ",
        f"Date: {_dt.date.today().isoformat()}",
        "</div>",
        "<h2>Metrics</h2>",
        "<table>",
        "<tr><th>metric</th><th>value</th><th>bar</th></tr>",
        f"<tr><td>answer_accuracy</td><td>{_fmt_opt(summary.answer_accuracy)}</td>"
        f"<td>{_bar(summary.answer_accuracy)}</td></tr>",
        f"<tr><td>search_decision_accuracy</td><td>{_fmt_opt(summary.search_decision_accuracy)}</td>"
        f"<td>{_bar(summary.search_decision_accuracy)}</td></tr>",
        f"<tr><td>avg_searches_per_example</td>"
        f"<td>{summary.avg_searches_per_example:.3f}</td><td></td></tr>",
        f"<tr><td>avg_latency_ms</td><td>{summary.avg_latency_ms:.0f}</td><td></td></tr>",
        f"<tr><td>tokens (in / out)</td>"
        f"<td>{summary.total_tokens_in:,} / {summary.total_tokens_out:,}</td><td></td></tr>",
        "</table>",
        "<h2>Breakdown</h2>",
        "<p>",
        f"correct: <strong>{summary.n_correct}</strong> · ",
        f"incorrect: <strong>{summary.n_incorrect}</strong> · ",
        f"not_attempted: <strong>{summary.n_not_attempted}</strong> · ",
        f"ungraded: <strong>{summary.n_ungraded}</strong>",
        "</p>",
    ]

    failures = [r for r in rows if r.scores.answer_correct is False][:max_failures]
    if failures:
        parts.append(f"<h2>Worst failures (up to {max_failures})</h2>")
        for r in failures:
            judgment = (r.scores.answer_judgment or "incorrect").lower()
            label_html = f'<span class="label {judgment}">{judgment}</span>'
            gold_html = (
                f"<p><strong>Gold:</strong> {e(r.gold_answer)}</p>"
                if r.gold_answer is not None
                else ""
            )
            reason_html = (
                f"<p><strong>Judge reason:</strong> {e(r.scores.answer_judge_reason)}</p>"
                if r.scores.answer_judge_reason
                else ""
            )
            query = _query_used(r)
            searched = (
                f"<p><strong>Searched?</strong> "
                f"{'yes' if r.trajectory.labels.search_used else 'no'} "
                f"({r.scores.num_searches} step"
                f"{'s' if r.scores.num_searches != 1 else ''})"
                + (f" — query: <code>{e(query)}</code>" if query else "")
                + "</p>"
            )
            parts.append(
                f"<details><summary>{e(r.id)} — {label_html}</summary>"
                f"<p><strong>Question:</strong> {e(r.question)}</p>"
                f"{gold_html}"
                f"<p><strong>Model answer:</strong> {e(_final_answer(r) or '(empty)')}</p>"
                f"{reason_html}"
                f"{searched}"
                f"<h4>Full trajectory</h4>"
                f"{_render_trajectory_html(r)}"
                f"</details>"
            )

    parts.append("</body></html>")
    path = output_dir / HTML_REPORT_FILE
    path.write_text("\n".join(parts), encoding="utf-8")
    return path


def load_seen_ids(output_dir: Path) -> set[str]:
    """For --resume: read the existing failures.jsonl and return all ids already written."""
    path = output_dir / FAILURES_FILE
    if not path.exists():
        return set()
    seen: set[str] = set()
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict) and "id" in obj:
                seen.add(obj["id"])
    return seen
