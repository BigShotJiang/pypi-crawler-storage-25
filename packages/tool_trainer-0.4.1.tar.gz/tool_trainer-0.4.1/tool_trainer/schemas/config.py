"""Config schema (YAML → Pydantic).

Top-level sections: `project`, `tool`, `teacher`, `generation`, `evaluation`,
`training`. Each is optional — missing sections fall back to class defaults.
Unknown sections pass through (`extra='allow'`) so users can carry extra keys
without tripping validation."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field


class ProjectConfig(BaseModel):
    name: str = "tool-trainer-project"
    output_dir: str = "./outputs"


class ToolConfig(BaseModel):
    provider: Literal["tavily"] = "tavily"
    api_key_env: str = "TAVILY_API_KEY"
    search_depth: Literal["basic", "advanced"] = "basic"
    max_results: int = 5
    include_raw_content: bool = False
    cache_path: str = "./outputs/caches/search.sqlite"


class TeacherConfig(BaseModel):
    provider: Literal["openai"] = "openai"
    model: str = "gpt-4o-mini"
    temperature: float = 0.2


class GenerationConfig(BaseModel):
    mode: Literal["sft", "preference", "router", "citations"] = "sft"
    # Default raised in v0.4: the product is agentic, one step is the degenerate case.
    max_search_steps: int = 2
    search_budget: int = 2
    include_no_search_examples: bool = True
    include_query_rewrites: bool = False
    include_negatives: bool = False


class EvaluationConfig(BaseModel):
    judge_model: str = "gpt-4o-mini"
    judge_provider: Literal["openai"] = "openai"
    judge_temperature: float = 0.0
    max_examples: int | None = None
    save_failures_only: bool = False


class TrainingConfig(BaseModel):
    method: Literal["sft"] = "sft"
    base_model: str = "Qwen/Qwen2.5-7B-Instruct"
    epochs: int = 2
    learning_rate: float = 2e-4
    per_device_batch_size: int = 4
    gradient_accumulation_steps: int = 4
    max_seq_length: int = 4096
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    bf16: bool = True
    gradient_checkpointing: bool = True
    seed: int = 42
    report_to: Literal["none", "wandb"] = "none"


class Config(BaseModel):
    """Top-level config. Unknown sections pass through."""

    model_config = ConfigDict(extra="allow")

    project: ProjectConfig = Field(default_factory=ProjectConfig)
    tool: ToolConfig = Field(default_factory=ToolConfig)
    teacher: TeacherConfig = Field(default_factory=TeacherConfig)
    generation: GenerationConfig = Field(default_factory=GenerationConfig)
    evaluation: EvaluationConfig = Field(default_factory=EvaluationConfig)
    training: TrainingConfig = Field(default_factory=TrainingConfig)

    @classmethod
    def load(cls, path: str | Path) -> Config:
        path = Path(path)
        data: dict[str, Any] = yaml.safe_load(path.read_text()) or {}
        return cls.model_validate(data)
