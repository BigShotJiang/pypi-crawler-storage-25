"""Tool-call / tool-result shapes."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ToolCall(BaseModel):
    name: str
    arguments: dict[str, Any]


class SearchResult(BaseModel):
    title: str
    url: str
    snippet: str | None = None
    score: float | None = None


class ToolResult(BaseModel):
    """The `content` payload we return for a role=tool message."""

    results: list[SearchResult] = Field(default_factory=list)
    query: str | None = None
    answer: str | None = None
