"""Eval-time schemas: per-trajectory scores, per-example rows, and summary aggregate."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from tool_trainer.schemas.trajectory import Trajectory


class EvalScores(BaseModel):
    """Scores for a single trajectory. `None`-valued fields indicate the signal
    couldn't be computed (e.g., no gold answer, or no requires_search label)."""

    answer_correct: bool | None = None
    answer_judgment: Literal["correct", "incorrect", "not_attempted"] | None = None
    answer_judge_reason: str | None = None
    search_decision_correct: bool | None = None
    num_searches: int = 0


class EvalRow(BaseModel):
    """One scored example. Written as one line of failures.jsonl."""

    id: str
    question: str
    gold_answer: str | None = None
    trajectory: Trajectory
    scores: EvalScores
    latency_ms: int
    tokens_in: int = 0
    tokens_out: int = 0


class EvalSummary(BaseModel):
    """Aggregate metrics across all rows. Written as summary.json."""

    benchmark: str
    teacher_model: str
    judge_model: str
    n: int
    answer_accuracy: float | None = None
    search_decision_accuracy: float | None = None
    avg_searches_per_example: float = 0.0
    avg_latency_ms: float = 0.0
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    # Breakdown counts for transparency.
    n_correct: int = 0
    n_incorrect: int = 0
    n_not_attempted: int = 0
    n_ungraded: int = 0


class Usage(BaseModel):
    """Token-usage tally. Aggregated across multiple LLM calls for one example."""

    prompt_tokens: int = 0
    completion_tokens: int = 0

    def __iadd__(self, other: Usage) -> Usage:
        self.prompt_tokens += other.prompt_tokens
        self.completion_tokens += other.completion_tokens
        return self

    def __add__(self, other: Usage) -> Usage:
        return Usage(
            prompt_tokens=self.prompt_tokens + other.prompt_tokens,
            completion_tokens=self.completion_tokens + other.completion_tokens,
        )


__all__ = ["EvalRow", "EvalScores", "EvalSummary", "Usage"]
