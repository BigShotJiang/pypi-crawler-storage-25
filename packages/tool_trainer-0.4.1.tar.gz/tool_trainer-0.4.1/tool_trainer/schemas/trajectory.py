"""SFT trajectory schema.

Byte-for-byte compatible with the shape in CLAUDE.md §"Generated SFT trace schema":
assistant messages carry either `content` (final answer) or `tool_call` (search
request); tool messages carry `name` + structured `content`.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel

from tool_trainer.schemas.tool_call import ToolCall


class Message(BaseModel):
    role: Literal["user", "assistant", "tool"]
    content: str | dict | None = None
    tool_call: ToolCall | None = None
    name: str | None = None

    def model_dump_compact(self) -> dict[str, Any]:
        """Serialize excluding None fields so JSONL output is clean."""
        return self.model_dump(exclude_none=True)


class TrajectoryLabels(BaseModel):
    search_used: bool
    search_reason: str | None = None
    num_search_steps: int = 0


class Trajectory(BaseModel):
    id: str
    messages: list[Message]
    labels: TrajectoryLabels

    def model_dump_compact(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "messages": [m.model_dump_compact() for m in self.messages],
            "labels": self.labels.model_dump(exclude_none=True),
        }
