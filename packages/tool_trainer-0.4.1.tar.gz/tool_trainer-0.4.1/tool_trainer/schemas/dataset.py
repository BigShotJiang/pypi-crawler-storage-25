"""Input dataset schema. Strict superset of BrowseComp/GAIA/SimpleQA row shapes."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class RawQuestion(BaseModel):
    """A single input question. Optional fields (category, difficulty, requires_search,
    source, ...) go in `metadata` so we don't keep growing the top-level schema."""

    id: str
    question: str
    answer: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
