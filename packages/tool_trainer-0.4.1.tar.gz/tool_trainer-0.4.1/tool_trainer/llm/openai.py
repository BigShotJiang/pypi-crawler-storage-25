"""OpenAI chat-completions client wrapper.

Normalizes the OpenAI response into `{'content': ..., 'tool_calls': [...], 'usage': {...}}`
so downstream code doesn't import OpenAI types. Tool-call arguments are parsed from
JSON strings into dicts here."""

from __future__ import annotations

import json
from typing import Any


class OpenAIClient:
    def __init__(self, api_key: str, *, model: str, temperature: float = 0.2) -> None:
        # Lazy import keeps import-time cheap and lets tests run without the SDK.
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key)
        self._model = model
        self._default_temperature = temperature

    def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        response_format: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "temperature": self._default_temperature if temperature is None else temperature,
        }
        if tools:
            kwargs["tools"] = tools
        if response_format is not None:
            kwargs["response_format"] = response_format

        response = self._client.chat.completions.create(**kwargs)
        msg = response.choices[0].message

        tool_calls: list[dict[str, Any]] = []
        for tc in msg.tool_calls or []:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {"_raw": tc.function.arguments}
            tool_calls.append({"name": tc.function.name, "arguments": args})

        usage = {"prompt_tokens": 0, "completion_tokens": 0}
        if response.usage is not None:
            usage["prompt_tokens"] = response.usage.prompt_tokens or 0
            usage["completion_tokens"] = response.usage.completion_tokens or 0

        return {"content": msg.content, "tool_calls": tool_calls, "usage": usage}
