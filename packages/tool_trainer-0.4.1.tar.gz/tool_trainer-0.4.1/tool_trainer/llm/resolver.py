"""Resolve a string model-spec into an LLMClient.

Spec forms:
  openai:<model>                                 → OpenAIClient
  hf:<path_or_hub_id>                            → HFInferenceClient (base only)
  hf:<base>+lora:<adapter_path>                  → HFInferenceClient w/ adapter

Examples:
  openai:gpt-4o-mini
  hf:Qwen/Qwen2.5-7B-Instruct
  hf:Qwen/Qwen2.5-7B-Instruct+lora:./outputs/checkpoints/sft-001
  hf:./my-local-merged-model
"""

from __future__ import annotations

from tool_trainer.llm.base import LLMClient


def parse_spec(spec: str) -> tuple[str, dict[str, str]]:
    """Parse a spec into (scheme, kwargs). Raises ValueError on unknown schemes."""
    if ":" not in spec:
        raise ValueError(f"Invalid model spec {spec!r}. Expected 'openai:<model>' or 'hf:<path>'.")
    scheme, rest = spec.split(":", 1)
    scheme = scheme.lower()

    if scheme == "openai":
        if not rest:
            raise ValueError("openai: spec requires a model name, e.g. openai:gpt-4o-mini")
        return "openai", {"model": rest}

    if scheme == "hf":
        if "+lora:" in rest:
            base, adapter = rest.split("+lora:", 1)
            return "hf", {"base_model": base, "adapter_path": adapter}
        return "hf", {"base_model": rest}

    raise ValueError(
        f"Unknown model-spec scheme {scheme!r} in {spec!r}. Supported schemes: openai, hf."
    )


def resolve_llm(
    spec: str,
    *,
    openai_api_key: str | None = None,
    temperature: float = 0.2,
    hf_device: str = "auto",
    hf_dtype: str = "bfloat16",
    hf_max_new_tokens: int = 512,
) -> LLMClient:
    """Build an LLMClient for the given spec. Lazy-imports the backend."""
    scheme, kwargs = parse_spec(spec)

    if scheme == "openai":
        if not openai_api_key:
            raise ValueError(
                "openai: spec requires an OPENAI_API_KEY. Set it in .env or environment."
            )
        from tool_trainer.llm.openai import OpenAIClient

        return OpenAIClient(api_key=openai_api_key, model=kwargs["model"], temperature=temperature)

    if scheme == "hf":
        from tool_trainer.llm.hf import HFInferenceClient

        return HFInferenceClient(
            base_model=kwargs["base_model"],
            adapter_path=kwargs.get("adapter_path"),
            device=hf_device,
            dtype=hf_dtype,
            max_new_tokens=hf_max_new_tokens,
            temperature=temperature,
        )

    raise AssertionError(f"unreachable: scheme={scheme!r}")  # pragma: no cover
