"""LLMClient Protocol. Return shape is provider-agnostic so trace generation
doesn't leak OpenAI/Anthropic/vLLM specifics upward.

Return dict keys:
    content:    str | None
    tool_calls: list[{'name': str, 'arguments': dict}]  (may be empty)
    usage:      {'prompt_tokens': int, 'completion_tokens': int}  (optional; omitted by fakes)
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class LLMClient(Protocol):
    def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        response_format: dict[str, Any] | None = None,
    ) -> dict[str, Any]: ...
