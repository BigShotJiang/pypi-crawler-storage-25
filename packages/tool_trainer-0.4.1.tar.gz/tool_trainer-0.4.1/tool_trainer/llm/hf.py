"""Hugging Face inference client.

Implements `LLMClient` on top of `transformers` + (optional) `peft` adapters.
Lazy imports keep the base install free of torch/transformers — this module
only loads when a user actually uses `hf:` model specs."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

# Hint added to system/user prompts when response_format={"type":"json_object"}.
# Local chat models don't support OpenAI's structured-output flag, so we nudge
# via text and rely on the same JSON-parse tolerance as the rest of the pipeline.
_JSON_HINT = (
    "\n\nIMPORTANT: Respond ONLY with a valid JSON object. "
    "No prose before or after. No code fences."
)


def _resolve_device(requested: str) -> str:
    """`auto` resolves to the best available local device."""
    if requested != "auto":
        return requested

    # Imports kept local to avoid pulling in torch at module-load time.
    import torch

    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


class HFInferenceClient:
    """A local `LLMClient` backed by `transformers.AutoModelForCausalLM`.

    Only supports text generation — no native tool-use. Fine for tool-trainer
    since the pipeline passes tool calls as plain text inside prompts."""

    def __init__(
        self,
        base_model: str,
        *,
        adapter_path: str | Path | None = None,
        device: str = "auto",
        dtype: str = "bfloat16",
        max_new_tokens: int = 512,
        temperature: float = 0.2,
    ) -> None:
        # Lazy imports — only pay the cost when someone actually uses an HF model.
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self._max_new_tokens = max_new_tokens
        self._default_temperature = temperature
        self._device = _resolve_device(device)

        torch_dtype = {
            "bfloat16": torch.bfloat16,
            "float16": torch.float16,
            "float32": torch.float32,
        }[dtype]

        self._tokenizer = AutoTokenizer.from_pretrained(base_model)
        model = AutoModelForCausalLM.from_pretrained(
            base_model,
            torch_dtype=torch_dtype,
            device_map=self._device if self._device != "cpu" else None,
        )
        if self._device == "cpu":
            model = model.to("cpu")

        if adapter_path is not None:
            # Import lazily — peft is only needed when loading a LoRA.
            from peft import PeftModel

            model = PeftModel.from_pretrained(model, str(adapter_path))

        model.eval()
        self._model = model

        # Most chat-fine-tuned tokenizers set pad_token=eos_token; fill it in if
        # the tokenizer left pad_token unset so batched generation doesn't crash.
        if self._tokenizer.pad_token_id is None:
            self._tokenizer.pad_token_id = self._tokenizer.eos_token_id

    @staticmethod
    def _maybe_inject_json_hint(
        messages: list[dict[str, Any]], response_format: dict[str, Any] | None
    ) -> list[dict[str, Any]]:
        if response_format is None or response_format.get("type") != "json_object":
            return messages
        out = [dict(m) for m in messages]
        # Append hint to the last user message (or first, if none exist).
        for i in range(len(out) - 1, -1, -1):
            if out[i].get("role") == "user":
                out[i]["content"] = str(out[i].get("content", "")) + _JSON_HINT
                return out
        out.append({"role": "user", "content": _JSON_HINT.strip()})
        return out

    def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        response_format: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        import torch

        msgs = self._maybe_inject_json_hint(messages, response_format)

        # Apply the model's chat template; add_generation_prompt=True so the model
        # continues in the assistant role. transformers 5.x returns a BatchEncoding
        # (dict-like); earlier versions returned a raw tensor. Handle both.
        prompt_ids = self._tokenizer.apply_chat_template(
            msgs,
            add_generation_prompt=True,
            tokenize=True,
            return_tensors="pt",
        )
        if hasattr(prompt_ids, "input_ids"):
            prompt_ids = prompt_ids["input_ids"]
        input_len = prompt_ids.shape[-1]
        prompt_ids = prompt_ids.to(self._model.device)

        temp = self._default_temperature if temperature is None else temperature
        do_sample = temp > 0
        generate_kwargs: dict[str, Any] = {
            "max_new_tokens": self._max_new_tokens,
            "do_sample": do_sample,
            "pad_token_id": self._tokenizer.pad_token_id,
        }
        if do_sample:
            generate_kwargs["temperature"] = temp

        with torch.inference_mode():
            output_ids = self._model.generate(prompt_ids, **generate_kwargs)

        # Decode only the newly-generated tokens (skip the prompt).
        gen_ids = output_ids[0, input_len:]
        text = self._tokenizer.decode(gen_ids, skip_special_tokens=True).strip()

        # Strip common chat-template artifacts if they leak through.
        text = re.sub(r"^(assistant\s*:?\s*)", "", text, flags=re.IGNORECASE).strip()

        return {
            "content": text,
            "tool_calls": [],
            "usage": {
                "prompt_tokens": int(input_len),
                "completion_tokens": int(gen_ids.shape[-1]),
            },
        }
