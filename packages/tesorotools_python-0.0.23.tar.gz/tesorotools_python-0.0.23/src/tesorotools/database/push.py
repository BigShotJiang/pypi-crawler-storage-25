from __future__ import annotations

import json
from typing import Any

import pandas as pd
from sqlalchemy import create_engine


def get_connection_string(
    engine: str,
    driver: str,
    username: str,
    password: str,
    host: str,
    database: str,
) -> str:
    return f"{engine}+{driver}://{username}:{password}@{host}/{database}"


def flash_to_database_format(data: pd.DataFrame) -> pd.DataFrame:
    """Transform the data in *flash* format to data in *database* format

    This operation takes a little while"""

    data.columns.name = "name"
    stacked_data: pd.DataFrame = data.stack().to_frame(name="value")  # type: ignore[assignment]
    database_data: pd.DataFrame = pd.DataFrame(stacked_data.reset_index())  # type: ignore[reportUnknownMemberType]

    def _to_dimensions(row: pd.Series[Any]) -> str:
        return json.dumps(
            {
                "offset": row["offset"],
                "difference_type": row["difference_type"],
                "stat": row["stat"],
            }
        )

    database_data["dimensions"] = database_data.apply(
        _to_dimensions,
        axis=1,
    )
    database_data = database_data.drop(
        columns=["offset", "difference_type", "stat"]
    )
    database_data["value_meta"] = pd.NA
    print(database_data)
    return database_data


def database_to_flash_format() -> None:
    pass


def push_to_database(data: pd.DataFrame, conn_string: str, table: str) -> None:
    engine: Any = create_engine(url=conn_string)
    data.to_sql(
        name=table,
        con=engine,
        if_exists="append",
        chunksize=1000,
        index=False,
    )


def pull_from_database(
    conn_string: str, start: str, end: str, series: list[str]
) -> None:
    _ = conn_string, start, end, series
