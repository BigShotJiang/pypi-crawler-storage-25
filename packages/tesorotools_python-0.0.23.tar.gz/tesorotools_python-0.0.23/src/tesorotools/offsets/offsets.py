from __future__ import annotations

from collections.abc import Callable, Iterable
from datetime import datetime
from enum import Enum
from typing import Any

import numpy as np
import pandas as pd

# stats and stat functions
type AnyStatFunction = Callable[..., float]
type StatFunction = Callable[[pd.Series[Any]], float]
type StatRollingFunction = Callable[..., float]


class Stat(Enum):
    VALUE = "value"
    ROLL_AVG = "roll_avg"
    ROLL_STD = "roll_std"

    @property
    def stat_function(self) -> StatFunction:
        match self:
            case Stat.VALUE:
                return lambda x: float(x.iloc[-1])
            case Stat.ROLL_AVG:
                return lambda x: float(np.mean(x))
            case Stat.ROLL_STD:
                return lambda x: float(np.std(x, ddof=0))

    @property
    def update_function(self) -> StatRollingFunction:
        match self:
            case Stat.VALUE:
                return lambda **kwargs: kwargs["newest_point"]  # type: ignore[no-any-return]
            case Stat.ROLL_AVG:
                return lambda **kwargs: _update_rolling_avg(**kwargs)  # type: ignore[arg-type]
            case Stat.ROLL_STD:
                return lambda **kwargs: _update_rolling_std(**kwargs)  # type: ignore[arg-type]


# offsets and offset functions
type OffsetFunction = Callable[[pd.DatetimeIndex], pd.DatetimeIndex]


def _fixed_date_offset_function(reference_date: datetime) -> OffsetFunction:
    return lambda dates: pd.DatetimeIndex([reference_date] * len(dates))


class FloatingOffset(Enum):
    NO = "no"
    BDAY = "bday"
    FTD = "ftd"
    MTD = "mtd"
    YTD = "ytd"

    @property
    def offset_function(self) -> OffsetFunction:
        match self:
            case FloatingOffset.BDAY:
                return lambda dates: dates - pd.tseries.offsets.BDay(1)
            case FloatingOffset.FTD:
                return lambda dates: dates - pd.tseries.offsets.Week(weekday=4)
            case FloatingOffset.MTD:
                return lambda dates: (
                    dates - pd.offsets.MonthBegin() - pd.tseries.offsets.BDay(1)
                )
            case FloatingOffset.YTD:
                return lambda dates: (
                    dates - pd.offsets.YearBegin() - pd.tseries.offsets.BDay(1)
                )
            case FloatingOffset.NO:
                msg = "FloatingOffset.NO has no offset function"
                raise ValueError(msg)


# differences and difference functions
type DifferenceFunction = Callable[
    [pd.Series[Any], pd.Series[Any]], pd.Series[Any]
]


class Difference(Enum):
    NO = "no"
    ABS = "absolute"
    REL = "relative"

    @property
    def difference_function(self) -> DifferenceFunction:
        match self:
            case Difference.ABS:
                return lambda original, offset: original - offset
            case Difference.REL:
                return lambda original, offset: (original - offset) / offset
            case Difference.NO:
                msg = "Difference.NO has no difference function"
                raise ValueError(msg)


def process_raw_data(raw_data: pd.DataFrame, **config: Any) -> pd.DataFrame:
    # preprocess index
    dates: pd.DatetimeIndex = pd.DatetimeIndex(pd.to_datetime(raw_data.index))
    raw_data.index = dates
    raw_data = raw_data.sort_index()

    # parse config and compute common values
    window: int = min(config["window"], len(raw_data.index))
    offsets_dict = _parse_offsets(config["offsets"], dates)
    differences_dict = _parse_differences(config["differences"])
    stats_dict = _parse_stats(config["stats"])

    names = ["date", "offset", "difference_type"]
    columns = stats_dict.keys()

    offset_df, raw_df = _result_templates(
        dates,
        offsets_dict.keys(),
        differences_dict.keys(),
        names,
        columns,
        columns_name="stat",
    )

    # computing enriched data
    def _apply_column(x: pd.Series[Any]) -> pd.Series[Any]:
        return _process_raw_data(
            x,
            offsets_dict,
            differences_dict,
            stats_dict,
            raw_df=raw_df,
            offset_df=offset_df,
            window=window,
        )

    enriched_data: pd.DataFrame = raw_data.apply(_apply_column)
    return enriched_data


def _parse_offsets(
    offsets_cfg: list[str | datetime], dates: pd.DatetimeIndex
) -> dict[str, pd.DatetimeIndex]:
    offsets: dict[str, OffsetFunction] = {}
    for offset_str in offsets_cfg:
        if offset_str == FloatingOffset.NO.value:
            continue
        if isinstance(offset_str, str) and offset_str in [
            e.value for e in FloatingOffset
        ]:
            offset_enum = FloatingOffset(offset_str)
            offsets[offset_str] = offset_enum.offset_function
        elif isinstance(offset_str, datetime):
            offsets[str(offset_str)] = _fixed_date_offset_function(offset_str)
        else:
            offsets[str(offset_str)] = _fixed_date_offset_function(
                datetime.fromisoformat(str(offset_str))
            )
    offsets_dict: dict[str, pd.DatetimeIndex] = {
        offset_key: offset_function(dates)
        for offset_key, offset_function in offsets.items()
    }
    return offsets_dict


def _parse_differences(
    differences_cfg: list[str],
) -> dict[str, DifferenceFunction]:
    differences: dict[str, DifferenceFunction] = {
        diff_str: Difference(diff_str).difference_function
        for diff_str in differences_cfg
        if diff_str != Difference.NO.value
    }
    return differences


def _parse_stats(
    stats_cfg: list[str], update: bool = False
) -> dict[str, AnyStatFunction]:
    if update:
        stats_result: dict[str, AnyStatFunction] = {
            stat_str: Stat(stat_str).update_function for stat_str in stats_cfg
        }
        stats_result[Stat.VALUE.value] = Stat.VALUE.update_function
    else:
        stats_result = {
            stat_str: Stat(stat_str).stat_function for stat_str in stats_cfg
        }
        stats_result[Stat.VALUE.value] = Stat.VALUE.stat_function
    return stats_result


def _result_templates(
    dates: pd.DatetimeIndex,
    offsets: Iterable[str],
    differences: Iterable[str],
    names: list[str],
    columns: Iterable[str],
    columns_name: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:

    offset_idx: pd.MultiIndex = pd.MultiIndex.from_product(
        [
            dates,
            list(offsets),
            list(differences),
        ],
        names=names,
    )
    columns_list = list(columns)
    offset_df: pd.DataFrame = pd.DataFrame(
        index=offset_idx,
        columns=columns_list,
    )
    offset_df.columns.name = columns_name

    raw_idx: pd.MultiIndex = pd.MultiIndex.from_product(
        [
            dates,
            [FloatingOffset.NO.value],
            [Difference.NO.value],
        ],
        names=names,
    )

    raw_df: pd.DataFrame = pd.DataFrame(
        index=raw_idx,
        columns=columns_list,
    )
    raw_df.columns.name = columns_name

    return offset_df, raw_df


def _process_raw_data(
    column: pd.Series[Any],
    offsets_dict: dict[str, pd.DatetimeIndex],
    differences_dict: dict[str, DifferenceFunction],
    stats_dict: dict[str, AnyStatFunction],
    *,
    raw_df: pd.DataFrame,
    offset_df: pd.DataFrame,
    window: int,
) -> pd.Series[Any]:

    stat_functions = list(stats_dict.values())

    # for every non trivial offset and difference apply all the stats
    for offset_str, offset_idx in offsets_dict.items():
        for diff_str, diff_func in differences_dict.items():
            offset_data = column.reindex(offset_idx)
            offset_data.index = column.index
            diff_data = diff_func(column, offset_data)
            stat_data: pd.DataFrame = diff_data.rolling(
                window=window, min_periods=0
            ).agg(stat_functions)
            offset_df.loc[(slice(None), offset_str, diff_str), :] = (
                stat_data.values
            )
    offset_series: pd.Series[Any] = offset_df.stack()  # type: ignore[assignment]

    # apply the stats to the original data
    stat_data = column.rolling(window=window, min_periods=0).agg(stat_functions)
    raw_df.loc[(slice(None)), :] = stat_data.values
    raw_series: pd.Series[Any] = raw_df.stack()  # type: ignore[assignment]

    result = pd.concat([offset_series, raw_series])
    result = result.apply(pd.to_numeric, errors="coerce")
    return result


def trim(
    full_data: pd.DataFrame | pd.Series[Any],
) -> pd.DataFrame | pd.Series[Any]:
    indexer = (
        slice(None),
        FloatingOffset.NO.value,
        Difference.NO.value,
        Stat.VALUE.value,
    )
    if isinstance(full_data, pd.DataFrame):
        trimmed_data: pd.DataFrame | pd.Series[Any] = full_data.loc[indexer, :]
    else:
        trimmed_data = full_data.loc[indexer]
    trimmed_data.index = trimmed_data.index.get_level_values(level=0)
    return trimmed_data


def add_rows(
    old_full_df: pd.DataFrame,
    new_trimmed_df: pd.DataFrame,
    offsets_cfg: dict[str, Any],
) -> pd.DataFrame:
    ## sanity check (raise if failed)
    # same columns
    # simple index
    # datetime index
    # sorted index
    # dates not in the old df

    dates: pd.DatetimeIndex = pd.DatetimeIndex(
        old_full_df.index.get_level_values(level=0).unique()
    )
    window: int = min(
        offsets_cfg["window"],
        len(dates) + len(new_trimmed_df.index),
    )
    offsets_dict = _parse_offsets(
        offsets_cfg["offsets"],
        pd.DatetimeIndex(new_trimmed_df.index),
    )
    differences_dict = _parse_differences(offsets_cfg["differences"])
    stats_dict = _parse_stats(offsets_cfg["stats"], update=True)
    names = ["date", "offset", "difference_type"]
    columns = stats_dict.keys()
    offset_df, raw_df = _result_templates(
        pd.DatetimeIndex(new_trimmed_df.index),
        offsets_dict.keys(),
        differences_dict.keys(),
        names,
        columns,
        columns_name="stat",
    )

    def _apply_new_column(x: pd.Series[Any]) -> pd.Series[Any]:
        return _process_new_data(
            x,
            old_full_df.loc[:, x.name],  # type: ignore[arg-type]
            offsets_dict,
            differences_dict,
            stats_dict,
            raw_df=raw_df,
            offset_df=offset_df,
            window=window,
        )

    updated_data: pd.DataFrame = new_trimmed_df.apply(_apply_new_column)
    result: pd.DataFrame = pd.concat([old_full_df, updated_data])
    return result


def _process_new_data(
    new_trimmed_column: pd.Series[Any],
    old_full_column: pd.Series[Any],
    offsets_dict: dict[str, pd.DatetimeIndex],
    differences_dict: dict[str, DifferenceFunction],
    stats_dict: dict[str, AnyStatFunction],
    *,
    raw_df: pd.DataFrame,
    offset_df: pd.DataFrame,
    window: int,
) -> pd.Series[Any]:

    old_trimmed_column: pd.Series[Any] = trim(old_full_column)  # type: ignore[assignment]
    fused_trimmed_column: pd.Series[Any] = pd.concat(
        [old_trimmed_column, new_trimmed_column]
    )

    # for every non trivial offset and difference apply all the stats
    for offset_str, offset_idx in offsets_dict.items():
        for diff_str, diff_func in differences_dict.items():
            offset_data = fused_trimmed_column.reindex(offset_idx)
            offset_data.index = new_trimmed_column.index
            diff_data = diff_func(new_trimmed_column, offset_data)
            old_diff_stats: pd.Series[Any] = old_full_column.loc[
                (slice(None), offset_str, diff_str)
            ]
            stat_data: pd.DataFrame = _rolling_update(
                window, diff_data, old_diff_stats, stats_dict
            )
            offset_df.loc[(stat_data.index.values, offset_str, diff_str), :] = (
                stat_data.values
            )
    offset_series: pd.Series[Any] = offset_df.stack()  # type: ignore[assignment]

    # apply the stats to the original data
    old_stats: pd.Series[Any] = old_full_column.loc[
        (slice(None), FloatingOffset.NO.value, Difference.NO.value)
    ]
    stat_data = _rolling_update(
        window, new_trimmed_column, old_stats, stats_dict
    )
    raw_df.loc[(slice(None)), :] = stat_data.values
    raw_series: pd.Series[Any] = raw_df.stack()  # type: ignore[assignment]

    result = pd.concat([offset_series, raw_series])
    result = result.apply(pd.to_numeric, errors="coerce")
    return result


def _rolling_update(
    window: int,
    new_trimmed_data: pd.Series[Any],
    old_full_data: pd.Series[Any],
    stats_dict: dict[str, AnyStatFunction],
) -> pd.DataFrame:
    result_df: pd.DataFrame = old_full_data.unstack(level=-1)
    fused_values: pd.Series[Any] = pd.concat(
        [result_df.loc[:, Stat.VALUE.value], new_trimmed_data]
    )
    result_df = result_df.reindex(fused_values.index)
    for index, value in new_trimmed_data.items():
        current_position: int = int(fused_values.index.get_loc(index))  # type: ignore[arg-type]
        previous_position: int = max(current_position - window, 0)
        previous_value = fused_values.iloc[previous_position]
        actual_window: int = min(window, current_position + 1)
        expanding: bool = actual_window < window
        for f_name, function in stats_dict.items():
            result_df.loc[index, f_name] = function(
                window=actual_window,
                expanding=expanding,
                old_stat=result_df.iloc[current_position - 1][f_name],
                oldest_point=previous_value,
                newest_point=value,
                other_stats=result_df.iloc[current_position - 1],
            )
    return result_df.loc[new_trimmed_data.index, :]


def _update_rolling_std(
    window: int,
    expanding: bool,
    old_stat: float,
    oldest_point: float,
    newest_point: float,
    other_stats: pd.Series[Any],
    **_: Any,
) -> float:
    old_rolling_mean: float = other_stats[Stat.ROLL_AVG.value]
    if expanding:
        # https://math.stackexchange.com/questions/374881/recursive-formula-for-variance
        new_rolling_var = (
            old_stat**2
            + (1 / (window + 1)) * (old_rolling_mean - newest_point) ** 2
        ) * (window / (window + 1))
    else:
        # https://jonisalonen.com/2014/efficient-and-accurate-rolling-standard-deviation/

        delta = newest_point - oldest_point
        new_rolling_mean = old_rolling_mean + (delta / window)
        new_rolling_var = old_stat**2 + (delta / window) * (
            newest_point - new_rolling_mean + oldest_point - old_rolling_mean
        )
    new_rolling_var = max(new_rolling_var, 0)  # avoid complex numbers
    return new_rolling_var**0.5


def _update_rolling_avg(
    window: int,
    expanding: bool,
    old_stat: float,
    oldest_point: float,
    newest_point: float,
    **_: Any,
) -> float:
    if expanding:
        return ((window - 1) * old_stat + newest_point) / window
    else:
        return old_stat + (newest_point - oldest_point) / window
