from pathlib import Path
from typing import Any

import yaml

from tesorotools.utils.template import TemplateLoader


def clean_config_dicts(
    config_dicts: dict[str, Any],
) -> dict[str, Any]:
    return {k: v for k, v in config_dicts.items() if not k.startswith(".")}


def read_config(
    config_file: Path,
    loader: type[yaml.FullLoader] | None = None,
    clean: bool = True,
) -> Any:
    actual_loader: type[yaml.FullLoader] = (
        yaml.FullLoader if loader is None else TemplateLoader
    )
    with open(config_file, encoding="utf8") as file:
        config_dict: Any = yaml.load(file, Loader=actual_loader)
        if clean and isinstance(config_dict, dict):
            config_dict = clean_config_dicts(config_dict)  # type: ignore[reportUnknownArgumentType]
    return config_dict


def merge(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    # a overrides
    for key in b:
        if key in a:
            if isinstance(a[key], dict) and isinstance(b[key], dict):
                merge(a[key], b[key])
        else:
            a[key] = b[key]
    return a
