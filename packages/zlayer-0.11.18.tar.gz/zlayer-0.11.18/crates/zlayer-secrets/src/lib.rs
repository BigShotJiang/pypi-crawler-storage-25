//! `ZLayer` Secrets Management
//!
//! Provides secure storage and retrieval of secrets for container workloads.
//!
//! ## Scoping
//! Secrets are organized hierarchically:
//! - Deployment-level: Shared by all services in a deployment
//! - Service-level: Specific to a single service
//!
//! ## Syntax
//! - `$S:secret-name` - Deployment-level secret
//! - `$S:@service/secret-name` - Service-specific secret
//! - `$secret://<env>/<KEY>` - Environment-scoped secret (requires an
//!   [`EnvScopeProvider`] wired via [`SecretsResolver::with_env_resolver`])
//! - `$secret://<env>/<KEY>/<field>` - With JSON field extraction

mod encryption;
mod error;
mod jwt;
mod key_manager;
mod provider;
pub mod sealed;
mod types;

#[cfg(feature = "persistent")]
pub mod client_keys;

#[cfg(feature = "persistent")]
mod persistent;

#[cfg(feature = "persistent")]
pub mod credentials;

#[cfg(feature = "persistent")]
pub mod registry_credentials;

#[cfg(feature = "persistent")]
pub mod git_credentials;

#[cfg(feature = "vault")]
mod vault;

pub use encryption::EncryptionKey;
pub use error::{Result, SecretsError};
pub use jwt::{JwtSecretManager, ENV_JWT_SECRET};
pub use key_manager::KeyManager;
pub use provider::{EnvScopeProvider, SecretsProvider, SecretsResolver, SecretsStore};
pub use sealed::{RecipientPrivateKey, RecipientPublicKey, SealedError, SealedSecret};
pub use types::{RotationResult, Secret, SecretMetadata, SecretRef, SecretScope};

#[cfg(feature = "persistent")]
pub use client_keys::{ActorKind, ClientKeyStore, ClientPublicKey, PersistentClientKeyStore};

#[cfg(feature = "persistent")]
pub use persistent::PersistentSecretsStore;

#[cfg(feature = "persistent")]
pub use credentials::CredentialStore;

#[cfg(feature = "persistent")]
pub use git_credentials::{GitCredential, GitCredentialKind, GitCredentialStore};

#[cfg(feature = "persistent")]
pub use registry_credentials::{RegistryAuthType, RegistryCredential, RegistryCredentialStore};

#[cfg(feature = "vault")]
pub use vault::VaultSecretsProvider;
