"""Pure metric functions (port of ``pss.metrics``).

Re-exports the Rust-backed implementations from ``semvec._core``.
"""

from semvec._core import (
    calculate_advanced_metrics,
    calculate_fsm,
    calculate_metrics,
)

__all__ = ["calculate_advanced_metrics", "calculate_fsm", "calculate_metrics"]
