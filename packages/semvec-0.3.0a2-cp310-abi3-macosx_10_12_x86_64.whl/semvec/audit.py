"""Audit logging for semvec — lightweight, opt-in, structured.

semvec's license and rate-limit gates live in the Rust core; they raise
typed exceptions (``LicenseExpiredError``, ``RateLimitError``) but do
not themselves log. This module provides a thin Python-side helper so
production deployments can emit structured JSON-line audit records to
any sink (stderr, a file, a syslog socket, a SIEM forwarder) at the
application boundary.

Usage:

    from semvec.audit import audit_log, audited, set_sink
    from pathlib import Path

    # Send all audit records to a JSON-lines file
    set_sink(Path("/var/log/semvec/audit.log").open("a"))

    audit_log("license.denied", reason="expired", tier="Pro")

    @audited("state.update")
    def update_wrapper(state, emb, text):
        return state.update(emb, text)

Every emitted record is a single JSON line with at least:

- ``ts`` — UTC ISO-8601 timestamp
- ``event`` — dotted event name
- ``pid`` — OS process id
- ``host`` — result of ``socket.gethostname()``

plus whatever keyword arguments the caller passed. No credentials are
logged by default — ``SEMVEC_LICENSE_KEY`` is never read by this module.
"""

from __future__ import annotations

import json
import os
import socket
import sys
import time
from collections.abc import Callable
from datetime import datetime, timezone
from functools import wraps
from typing import Any, TextIO

try:
    from semvec import (
        LicenseError,
        LicenseExpiredError,
        RateLimitError,
    )
except ImportError:  # pragma: no cover — only during bootstrap
    LicenseError = Exception  # type: ignore[assignment,misc]
    LicenseExpiredError = Exception  # type: ignore[assignment,misc]
    RateLimitError = Exception  # type: ignore[assignment,misc]


_SINK: TextIO = sys.stderr
_HOSTNAME: str = socket.gethostname()


def set_sink(sink: TextIO) -> None:
    """Route audit records to *sink* (any writable text stream).

    Pass ``sys.stderr`` or ``sys.stdout`` for console, an open file for
    durable storage, or a ``io.StringIO`` in tests. The module never
    closes the sink — the caller owns its lifecycle.
    """
    global _SINK
    _SINK = sink


def get_sink() -> TextIO:
    """Return the current sink (useful for tests)."""
    return _SINK


def audit_log(event: str, **fields: Any) -> None:
    """Emit one JSON-lines audit record.

    Keyword fields are merged into the record. Unserialisable values are
    coerced via ``repr``. Empty-string fields are preserved; ``None``
    fields are dropped.
    """
    record: dict[str, Any] = {
        "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
        "event": event,
        "pid": os.getpid(),
        "host": _HOSTNAME,
    }
    for k, v in fields.items():
        if v is None:
            continue
        try:
            json.dumps(v)
            record[k] = v
        except (TypeError, ValueError):
            record[k] = repr(v)
    try:
        _SINK.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
        _SINK.flush()
    except Exception:  # pragma: no cover — audit sink is best-effort
        pass


def audited(event: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that logs license / rate-limit failures around a call.

    Success is logged at ``event + ".ok"`` with a ``duration_ms`` field.
    Failures emit ``event + ".license_denied"``, ``event + ".rate_limited"``,
    or ``event + ".error"`` with the exception class name and message.
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(fn)
        def wrapped(*args: Any, **kwargs: Any) -> Any:
            t0 = time.perf_counter()
            try:
                result = fn(*args, **kwargs)
            except LicenseExpiredError as e:
                audit_log(
                    f"{event}.license_denied",
                    reason="expired",
                    detail=str(e),
                )
                raise
            except RateLimitError as e:
                retry_after = getattr(e, "retry_after", None)
                retry_seconds = (
                    retry_after.total_seconds()
                    if retry_after is not None and hasattr(retry_after, "total_seconds")
                    else None
                )
                audit_log(
                    f"{event}.rate_limited",
                    retry_after_seconds=retry_seconds,
                    detail=str(e),
                )
                raise
            except LicenseError as e:
                audit_log(
                    f"{event}.license_denied",
                    reason=type(e).__name__,
                    detail=str(e),
                )
                raise
            except Exception as e:
                audit_log(
                    f"{event}.error",
                    exc_type=type(e).__name__,
                    detail=str(e),
                )
                raise
            audit_log(
                f"{event}.ok",
                duration_ms=round((time.perf_counter() - t0) * 1000, 2),
            )
            return result

        return wrapped

    return decorator
