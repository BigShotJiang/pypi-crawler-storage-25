"""LLM client abstraction for Ollama and OpenAI-compatible APIs.

Provides a unified callable interface ``(List[ChatMessage]) -> str`` that
plugs directly into ``SemvecChatProxy.llm_call``.

Ported verbatim from ``pss.token_reduction.llm_client``.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass

import requests

from .chat_proxy import ChatMessage


@dataclass
class LLMConfig:
    """Configuration for an LLM backend."""

    provider: str  # "ollama" or "openai"
    base_url: str = ""
    model: str = ""
    api_key: str = ""
    temperature: float = 0.7
    max_tokens: int = 512

    @classmethod
    def from_env(cls, provider: str, prefix: str = "") -> LLMConfig:
        """Load config from environment variables.

        Args:
            provider: ``"ollama"`` or ``"openai"``.
            prefix:   Optional prefix for env var names (e.g. ``"JUDGE"``).
                      With ``prefix="JUDGE"`` and ``provider="openai"``, reads
                      ``JUDGE_OPENAI_BASE_URL`` first, falls back to
                      ``OPENAI_BASE_URL``.

        For ``provider="ollama"``::

            [PREFIX_]OLLAMA_BASE_URL, [PREFIX_]OLLAMA_MODEL

        For ``provider="openai"``::

            [PREFIX_]OPENAI_BASE_URL, [PREFIX_]OPENAI_MODEL, [PREFIX_]OPENAI_API_KEY
        """
        if provider not in ("ollama", "openai"):
            raise ValueError(f"Unknown provider: {provider!r}")

        prov_upper = provider.upper()

        def _get(var_suffix: str) -> str:
            if prefix:
                prefixed = f"{prefix}_{prov_upper}_{var_suffix}"
                val = os.environ.get(prefixed, "")
                if val:
                    return val
            return os.environ.get(f"{prov_upper}_{var_suffix}", "")

        base_url = _get("BASE_URL")
        model = _get("MODEL")
        api_key = _get("API_KEY") if provider == "openai" else ""

        if not base_url:
            raise ValueError(f"{prov_upper}_BASE_URL not set — base_url required")
        if not model:
            raise ValueError(f"{prov_upper}_MODEL not set — model required")

        return cls(
            provider=provider,
            base_url=base_url,
            model=model,
            api_key=api_key,
        )

    def validate(self) -> None:
        """Raise ``ValueError`` if config is incomplete."""
        if not self.base_url:
            raise ValueError("base_url is required")
        if not self.model:
            raise ValueError("model is required")
        if self.provider == "openai" and not self.api_key:
            raise ValueError("api_key is required for OpenAI provider")


class BaseLLMClient(ABC):
    """Abstract base for LLM clients."""

    def __init__(self, config: LLMConfig) -> None:
        self._config = config
        self.last_usage: dict | None = None

    @abstractmethod
    def __call__(self, messages: list[ChatMessage]) -> str:
        """Send messages and return the assistant response text."""
        ...

    @property
    def config(self) -> LLMConfig:
        return self._config

    @staticmethod
    def _to_dicts(messages: list[ChatMessage]) -> list[dict]:
        """Convert ``ChatMessage`` list to API-ready dicts."""
        return [{"role": m.role, "content": m.content} for m in messages]


class OllamaClient(BaseLLMClient):
    """Client for Ollama API (``/api/chat`` endpoint)."""

    def __call__(self, messages: list[ChatMessage]) -> str:
        url = f"{self._config.base_url.rstrip('/')}/api/chat"
        payload = {
            "model": self._config.model,
            "messages": self._to_dicts(messages),
            "stream": False,
            "options": {
                "temperature": self._config.temperature,
                "num_predict": self._config.max_tokens,
            },
        }
        resp = requests.post(url, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        return data["message"]["content"]


class OpenAIClient(BaseLLMClient):
    """Client for OpenAI-compatible APIs (OpenRouter, vLLM, sglang, etc.)."""

    def __call__(self, messages: list[ChatMessage]) -> str:
        url = f"{self._config.base_url.rstrip('/')}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._config.api_key}",
        }
        payload = {
            "model": self._config.model,
            "messages": self._to_dicts(messages),
            "temperature": self._config.temperature,
            "max_tokens": self._config.max_tokens,
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        self.last_usage = data.get("usage") or None
        choices = data.get("choices", [])
        if not choices:
            raise ValueError("LLM returned empty choices list")
        content = choices[0]["message"]["content"]
        return content if content is not None else ""


def create_llm_client(provider: str = "openai", prefix: str = "") -> BaseLLMClient:
    """Factory: create an LLM client from environment variables.

    Args:
        provider: ``"ollama"`` or ``"openai"``.
        prefix:   Optional env var prefix (e.g. ``"JUDGE"`` for ``JUDGE_OPENAI_*``).
    """
    config = LLMConfig.from_env(provider, prefix=prefix)
    config.validate()
    if provider == "ollama":
        return OllamaClient(config)
    if provider == "openai":
        return OpenAIClient(config)
    raise ValueError(f"Unknown provider: {provider!r}")
