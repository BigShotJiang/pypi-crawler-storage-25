"""Benchmark harnesses shipped with semvec.

All benchmarks are pure-Python thin wrappers over the Rust-backed core.
They are primarily intended for reproducibility / regression verification
against the pss reference implementation.
"""
