"""Module entry for ``python -m semvec.benchmarks.longmemeval``."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
