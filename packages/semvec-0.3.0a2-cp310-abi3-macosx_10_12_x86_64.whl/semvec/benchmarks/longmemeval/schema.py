"""Dataclasses for the LongMemEval benchmark.

Represents the multi-session haystack structure:
  - Session: one chat session with user/assistant turns
  - LongMemEvalEntry: one benchmark question with haystack + ground truth
  - LongMemEvalDataset: collection of entries with filtering
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Session:
    """A single chat session containing user/assistant turn pairs."""

    session_id: str
    turns: list[dict]  # [{"role": "user"|"assistant", "content": str}, ...]
    has_answer: bool = False
    session_date: str = ""

    @property
    def approx_tokens(self) -> int:
        """Rough token estimate (chars / 4, minimum 1 for non-empty sessions)."""
        total_chars = sum(len(t.get("content", "")) for t in self.turns)
        if total_chars == 0:
            return 0
        return max(1, total_chars // 4)

    def as_text(self) -> str:
        """Flatten session turns into a single newline-joined text blob."""
        parts = []
        for t in self.turns:
            role = t.get("role", "unknown")
            content = t.get("content", "")
            parts.append(f"{role}: {content}")
        return "\n".join(parts)


@dataclass
class LongMemEvalEntry:
    """A single LongMemEval benchmark question with haystack sessions."""

    question_id: str
    question_type: str
    question: str
    answer: str
    question_date: str
    haystack_sessions: list[Session]
    answer_session_ids: list[str]

    @property
    def total_sessions(self) -> int:
        return len(self.haystack_sessions)

    @property
    def evidence_sessions(self) -> list[Session]:
        """Return only the sessions that contain evidence for the answer."""
        return [s for s in self.haystack_sessions if s.has_answer]

    @property
    def approx_total_tokens(self) -> int:
        """Rough total token count across all sessions."""
        return sum(s.approx_tokens for s in self.haystack_sessions)


@dataclass
class LongMemEvalDataset:
    """Collection of LongMemEval entries with filtering helpers."""

    variant: str  # "S", "M", or "oracle"
    entries: list[LongMemEvalEntry]

    @property
    def question_types(self) -> set[str]:
        return {e.question_type for e in self.entries}

    def filter(
        self,
        question_types: list[str] | None = None,
        max_entries: int | None = None,
        per_type: int | None = None,
    ) -> LongMemEvalDataset:
        """Return a filtered copy of this dataset.

        Applied in order: question_types → per_type → max_entries.
        """
        result = list(self.entries)
        if question_types:
            type_set = set(question_types)
            result = [e for e in result if e.question_type in type_set]
        if per_type is not None:
            by_type: dict[str, list[LongMemEvalEntry]] = {}
            for e in result:
                by_type.setdefault(e.question_type, []).append(e)
            balanced: list[LongMemEvalEntry] = []
            for qtype in sorted(by_type):
                balanced.extend(by_type[qtype][:per_type])
            result = balanced
        if max_entries is not None:
            result = result[:max_entries]
        return LongMemEvalDataset(variant=self.variant, entries=result)
