"""semvec port of the LongMemEval benchmark harness.

Public surface mirrors ``pss.benchmarks.longmemeval``:

- ``Session``, ``LongMemEvalEntry``, ``LongMemEvalDataset`` — dataset shapes
- ``load_from_file`` / ``load_dataset`` / ``download_dataset`` — loaders
- ``LLMCallCounter`` — proxy for tracking LLM cost
- ``LongMemEvalRunner`` — single-PSS runner
- ``MultiPSSRunner`` — 3-PSS runner (user/assistant/QA clusters)
- ``GroundTruthEvaluator``, ``EvalResult``, ``BenchmarkSummary`` — judging
- ``EntryResult`` — raw runner output

Mem0Runner was NOT ported (requires external ``mem0ai`` dependency).
"""

from .call_counter import LLMCallCounter
from .evaluator import (
    BenchmarkSummary,
    EvalResult,
    GroundTruthEvaluator,
    SimpleEvalVerdict,
)
from .loader import download_dataset, load_dataset, load_from_file
from .runner import EntryResult, LongMemEvalRunner, MultiPSSRunner
from .schema import LongMemEvalDataset, LongMemEvalEntry, Session

__all__ = [
    "BenchmarkSummary",
    "EntryResult",
    "EvalResult",
    "GroundTruthEvaluator",
    "LLMCallCounter",
    "LongMemEvalDataset",
    "LongMemEvalEntry",
    "LongMemEvalRunner",
    "MultiPSSRunner",
    "Session",
    "SimpleEvalVerdict",
    "download_dataset",
    "load_dataset",
    "load_from_file",
]
