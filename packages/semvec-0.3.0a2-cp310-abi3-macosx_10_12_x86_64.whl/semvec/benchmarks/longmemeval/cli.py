"""CLI entry point for the LongMemEval benchmark.

Usage:
    python -m semvec.benchmarks.longmemeval --variant S
    python -m semvec.benchmarks.longmemeval --local-file data.json --max-entries 10
    python -m semvec.benchmarks.longmemeval --multi-pss --per-type 10 --temperature 0.0

Mem0 comparison mode (``--mem0``) from the pss original is NOT ported —
Mem0 requires a separate ``mem0ai`` dependency stack and lives outside
the semvec core wheel.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def _temperature_in_range(value: str) -> float:
    try:
        f = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Invalid temperature: {value!r}") from exc
    if not (0.0 <= f <= 2.0):
        raise argparse.ArgumentTypeError(
            f"Temperature {f} out of range [0.0, 2.0]"
        )
    return f


def _positive_int(value: str) -> int:
    try:
        n = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Invalid integer: {value!r}") from exc
    if n < 1:
        raise argparse.ArgumentTypeError(f"Value must be >= 1, got {n}")
    return n


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="LongMemEval benchmark for semvec vs full-history baseline",
    )
    parser.add_argument("--variant", choices=["S", "M", "oracle"], default="S")
    parser.add_argument("--local-file", default=None, help="Path to a local LongMemEval JSON file")
    parser.add_argument("--provider", choices=["openai", "ollama"], default="openai")
    parser.add_argument("--judge-provider", choices=["openai", "ollama"], default="openai")
    parser.add_argument("--max-entries", type=int, default=None, help="Limit to first N entries")
    parser.add_argument(
        "--skip-entries",
        type=int,
        default=0,
        help="Skip the first N entries (for resuming a crashed run)",
    )
    parser.add_argument(
        "--per-type",
        type=_positive_int,
        default=None,
        help="Take first N entries per question type (balanced sampling)",
    )
    parser.add_argument("--question-types", nargs="+", default=None)
    parser.add_argument("--output", default=None, help="Path for JSON results file")
    parser.add_argument(
        "--temperature",
        type=_temperature_in_range,
        default=0.0,
        help="LLM temperature for generation AND judge (default 0.0 for reproducibility)",
    )
    parser.add_argument(
        "--n-judges",
        type=_positive_int,
        default=1,
        help="Judge ensemble size — majority vote (default 1)",
    )
    parser.add_argument(
        "--embed-model",
        default="all-MiniLM-L6-v2",
        help="SentenceTransformer model (matches pss default)",
    )
    parser.add_argument(
        "--embed-device",
        choices=["cpu", "cuda", "mps"],
        default="cpu",
        help="Torch device for the embedder",
    )
    parser.add_argument(
        "--multi-pss",
        action="store_true",
        default=False,
        help="Use MultiPSSRunner with 3 PSS instances (user/assistant/QA cluster)",
    )
    return parser


def _build_embedder(model_name: str, device: str):
    """Construct a SentenceTransformer-backed embedder — hard-fail if missing."""
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as e:
        raise RuntimeError(
            "sentence-transformers is required (no hash fallback). Install:\n"
            "    pip install sentence-transformers"
        ) from e

    import numpy as np

    model = SentenceTransformer(model_name, device=device)
    dim = int(model.get_sentence_embedding_dimension() or 384)

    class _STEmbedder:
        model_name = model_name
        device = device

        def get_dimension(self) -> int:
            return dim

        def get_embedding(self, text: str):
            if not text.strip():
                return np.zeros(dim, dtype=np.float64)
            vec = model.encode(
                text,
                normalize_embeddings=True,
                show_progress_bar=False,
                convert_to_numpy=True,
            )
            return np.asarray(vec, dtype=np.float64)

    return _STEmbedder()


def main(argv: list[str] | None = None) -> int:
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass

    args = build_parser().parse_args(argv)

    from semvec.token_reduction import create_llm_client

    from .evaluator import BenchmarkSummary, GroundTruthEvaluator
    from .loader import load_dataset, load_from_file
    from .runner import LongMemEvalRunner, MultiPSSRunner
    from .schema import LongMemEvalDataset

    # Load + filter dataset
    if args.local_file:
        dataset = load_from_file(Path(args.local_file), variant=args.variant)
    else:
        dataset = load_dataset(variant=args.variant)

    dataset = dataset.filter(
        question_types=args.question_types,
        per_type=args.per_type,
        max_entries=args.max_entries,
    )

    if args.skip_entries > 0:
        original = len(dataset.entries)
        dataset = LongMemEvalDataset(
            variant=dataset.variant,
            entries=dataset.entries[args.skip_entries:],
        )
        print(
            f"LongMemEval-{args.variant}: {len(dataset.entries)} entries "
            f"(skipped first {args.skip_entries} of {original})"
        )
    else:
        print(f"LongMemEval-{args.variant}: {len(dataset.entries)} entries")
    print(f"Question types: {sorted(dataset.question_types)}")
    print()

    # LLM clients
    llm = create_llm_client(args.provider)
    judge_llm = create_llm_client(args.judge_provider, prefix="JUDGE")
    llm._config.temperature = args.temperature
    judge_llm._config.temperature = args.temperature
    print(f"Temperature: {args.temperature}")

    # Embedder (shared across runner instances)
    embedder = _build_embedder(args.embed_model, args.embed_device)
    dim = embedder.get_dimension()
    print(f"Embedder: {args.embed_model} (dim={dim}, device={args.embed_device})")

    if args.multi_pss:
        runner = MultiPSSRunner(
            dataset=dataset,
            llm=llm,
            embedder=embedder,
            pss_config_dimension=dim,
        )
        print("Mode: MultiPSS (3 instances: user/assistant/QA cluster)")
    else:
        runner = LongMemEvalRunner(
            dataset=dataset,
            llm=llm,
            embedder=embedder,
            pss_config_dimension=dim,
        )
        print("Mode: Single PSS")

    evaluator = GroundTruthEvaluator(judge_llm=judge_llm, n_judges=args.n_judges)
    if args.n_judges > 1:
        print(f"Judge ensemble: {args.n_judges} votes per entry (majority rule)")

    print("Running benchmark (incremental: run + judge per entry)...")
    eval_results: list = []
    total = len(dataset.entries)
    for i, entry in enumerate(dataset.entries, 1):
        print(
            f"  [{i}/{total}] {entry.question_id} "
            f"({entry.total_sessions} sessions, type={entry.question_type})",
            flush=True,
        )
        entry_result = runner.run_entry(entry)
        eval_result = evaluator.evaluate_entry(entry_result)
        eval_results.append(eval_result)

        if args.output:
            partial = BenchmarkSummary.from_results(eval_results)
            _write_results(args.output, partial, eval_results)

        er = entry_result
        print(
            f"    calls={er.pss_total_calls} tokens={er.pss_total_tokens:,} "
            f"time={er.wall_clock_seconds:.1f}s",
            flush=True,
        )
        if i % 10 == 0:
            partial = BenchmarkSummary.from_results(eval_results)
            print(
                f"    --- Checkpoint {i}/{total}: "
                f"PSS {partial.pss_accuracy:.0%} | "
                f"Base {partial.baseline_accuracy:.0%} | "
                f"Savings {partial.savings_pct:.1f}% | "
                f"Wall {partial.total_wall_clock_seconds:.0f}s "
                f"(avg {partial.avg_wall_clock_seconds_per_entry:.1f}s/entry)",
                flush=True,
            )

    summary = BenchmarkSummary.from_results(eval_results)
    print()
    print("=" * 60)
    print(f"LongMemEval-{args.variant} Results")
    print("=" * 60)
    print(f"  Entries:           {summary.total_entries}")
    print(f"  PSS Accuracy:      {summary.pss_accuracy:.1%}")
    print(f"  Baseline Accuracy: {summary.baseline_accuracy:.1%}")
    print(f"  Token Savings:     {summary.savings_pct:.1f}%")
    print()
    print("  Production Cost:")
    print(f"    Memory LLM calls:      {summary.total_memory_system_calls:>10,}")
    print(f"    Memory tokens:         {summary.total_memory_system_tokens:>10,}")
    print(f"    Baseline LLM calls:    {summary.total_baseline_calls:>10,}")
    print(f"    Baseline tokens:       {summary.total_baseline_full_tokens:>10,}")
    print(f"    Total wall-clock:      {summary.total_wall_clock_seconds:>10.1f}s")
    print(f"    Avg per entry:         {summary.avg_wall_clock_seconds_per_entry:>10.2f}s")
    print()
    print("  Per Question Type:")
    for qtype, stats in sorted(summary.per_type.items()):
        print(
            f"    {qtype:<42} PSS {stats['pss_accuracy']:.0%}  "
            f"Base {stats['baseline_accuracy']:.0%}  (n={stats['count']})"
        )

    if args.output:
        _write_results(args.output, summary, eval_results)
        print(f"\nResults saved to {args.output}")

    return 0


def _write_results(path: str, summary, eval_results: list) -> None:
    """Write results JSON (safe for incremental updates)."""
    output_data = {
        "summary": summary.to_dict(),
        "results": [
            {
                "question_id": r.question_id,
                "question_type": r.question_type,
                "pss_correct": r.pss_correct,
                "baseline_correct": r.baseline_correct,
                "explanation": r.explanation,
                "pss_query_tokens": r.pss_query_tokens,
                "baseline_query_tokens": r.baseline_query_tokens,
                "pss_total_calls": r.pss_total_calls,
                "baseline_total_calls": r.baseline_total_calls,
                "pss_total_tokens": r.pss_total_tokens,
                "baseline_total_tokens": r.baseline_total_tokens,
                "wall_clock_seconds": r.wall_clock_seconds,
            }
            for r in eval_results
        ],
    }
    Path(path).write_text(json.dumps(output_data, indent=2, ensure_ascii=False))
