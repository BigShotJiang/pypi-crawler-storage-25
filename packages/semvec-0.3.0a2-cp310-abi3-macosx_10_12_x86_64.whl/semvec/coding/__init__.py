"""Semvec Coding — context-compaction toolkit for coding agents.

The numeric primitives (CodePointer, CodePointerIndex, NegativeAttractor,
NegativeAttractorSet, PromptBuilder) live in the Rust core. The
orchestration layer (engine, transcript parsing, persistence) stays in
Python so callers can plug in any embedder / MCP server / hook runtime.
"""

from semvec._core import (
    CodePointer,
    CodePointerIndex,
    CompactionEngine,
    NegativeAttractor,
    NegativeAttractorSet,
    PromptBuilder,
)
from semvec.coding.engine import PyCompactionEngine as CodingEngine
from semvec.coding.persistence import (
    CompactionState,
    load_state,
    save_state,
)
from semvec.coding.transcript_parser import (
    ChunkType,
    TranscriptChunk,
    TranscriptParser,
)

__all__ = [
    "ChunkType",
    "CodePointer",
    "CodePointerIndex",
    "CodingEngine",
    "CompactionEngine",
    "CompactionState",
    "NegativeAttractor",
    "NegativeAttractorSet",
    "PromptBuilder",
    "TranscriptChunk",
    "TranscriptParser",
    "load_state",
    "save_state",
]
