"""MCP server for the Semvec Coding compaction backend.

Exposes :class:`semvec.coding.CodingEngine` as MCP tools via FastMCP
(stdio transport). Claude Code can call these tools to update PSS
state, retrieve compacted context, check anti-resonance, and persist.

Usage in ``.claude/settings.json``::

    "mcpServers": {
        "semvec": {
            "command": "uv",
            "args": ["run", "python", "-m", "semvec.coding.mcp_server"],
            "env": {
                "PSS_STATE_DIR": ".semvec",
                "PSS_WORKSPACE": ".",
                "PSS_EMBED_MODEL": "all-MiniLM-L6-v2",
                "PSS_EMBED_DEVICE": "cpu"
            }
        }
    }

Ported from ``pss.compaction.mcp_server``. semvec's CodingEngine
requires an explicit embedder — the server constructs one from a
shared ``SentenceTransformer`` (no hash fallback).
"""

from __future__ import annotations

import logging
import os
import warnings
from typing import Any

from semvec.coding import CodingEngine

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Environment-variable resolver
#
# semvec 0.1.0a2 renamed the operator-facing env vars from the legacy
# PSS_* prefix to SEMVEC_*. The legacy name is still honoured but
# emits a DeprecationWarning. Scheduled for removal in semvec 0.2.0.


def _env(name: str, default: str | None = None) -> str | None:
    """Look up ``SEMVEC_<NAME>`` with a one-shot fallback to ``PSS_<NAME>``.

    Used by the MCP server, the pre_compact + session_start hooks, and
    any other runtime entrypoint that reads operator config from the
    environment. The legacy PSS_* spellings remain usable during the
    0.1.x deprecation window — accessing one of them emits a
    ``DeprecationWarning`` that names the current SEMVEC_* replacement
    and the removal target (``0.2.0``).

    Args:
        name: suffix after the prefix (e.g. ``"STATE_DIR"``).
        default: returned if neither ``SEMVEC_<NAME>`` nor ``PSS_<NAME>``
            is set.
    """
    new_key = f"SEMVEC_{name}"
    old_key = f"PSS_{name}"
    value = os.environ.get(new_key)
    if value is not None:
        return value
    legacy = os.environ.get(old_key)
    if legacy is not None:
        warnings.warn(
            f"Environment variable {old_key} is deprecated and will be "
            f"removed in semvec 0.2.0. Use {new_key} instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return legacy
    return default


# ---------------------------------------------------------------------------
# Embedder


def _build_embedder(model_name: str, device: str):
    """Construct a SentenceTransformer-backed embedder or hard-fail."""
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as e:
        raise RuntimeError(
            "sentence-transformers is required for the MCP server "
            "(no hash fallback). Install: pip install sentence-transformers"
        ) from e

    import numpy as np

    model = SentenceTransformer(model_name, device=device)
    dim = int(model.get_sentence_embedding_dimension() or 384)

    class _STEmbedder:
        def get_dimension(self) -> int:
            return dim

        def get_embedding(self, text: str):
            if not text.strip():
                return np.zeros(dim, dtype=np.float64)
            vec = model.encode(
                text,
                normalize_embeddings=True,
                show_progress_bar=False,
                convert_to_numpy=True,
            )
            return np.asarray(vec, dtype=np.float64)

    return _STEmbedder()


# ---------------------------------------------------------------------------
# Engine factory


def create_engine(
    state_dir: str | None = None,
    workspace_dir: str | None = None,
    embedder: object | None = None,
) -> CodingEngine:
    """Build a :class:`CodingEngine` from env or explicit args."""
    state_dir = state_dir or _env("STATE_DIR", default=".semvec")
    workspace_dir = workspace_dir or _env("WORKSPACE")
    if embedder is None:
        model = _env("EMBED_MODEL", default="all-MiniLM-L6-v2")
        device = _env("EMBED_DEVICE", default="cpu")
        embedder = _build_embedder(model, device)
    engine = CodingEngine(
        state_dir=state_dir,
        workspace_dir=workspace_dir,
        embedder=embedder,
    )
    engine.load_state()
    return engine


# ---------------------------------------------------------------------------
# Tool handler functions (testable without the MCP transport)


def handle_get_context(
    engine: CodingEngine,
    task: str,
    invariants: list[str] | None = None,
    test_summary: str | None = None,
    git_diff: str | None = None,
) -> str:
    """Get compacted context for a task."""
    return engine.get_compacted_context(
        task,
        invariants=invariants,
        test_summary=test_summary,
        git_diff=git_diff,
    )


def handle_update(
    engine: CodingEngine,
    text: str,
    update_type: str,
    metadata: dict[str, Any] | None = None,
) -> str:
    """Fold information into PSS state."""
    metadata = metadata or {}

    if update_type == "code_change":
        file_path = metadata.get("file_path", "unknown")
        signature = metadata.get("signature", "")
        engine.register_code_change(file_path, text, signature)
        return f"OK: registered code change for {file_path}"

    if update_type in ("error", "test_failure"):
        engine.record_error(text, source=update_type)
        return f"OK: recorded {update_type}"

    if update_type == "conversation":
        return "OK: ingested conversation"

    return f"OK: unknown type '{update_type}', ignored"


def handle_check_anti_resonance(engine: CodingEngine, proposal: str) -> str:
    """Check proposal against known error patterns."""
    warnings = engine.check_anti_resonance(proposal)
    if not warnings:
        return "Clear: 0 warnings. Proposal does not match known error patterns."
    lines = [f"Found {len(warnings)} warning(s):"]
    for w in warnings[:5]:
        lines.append(f"- {w.description}")
    return "\n".join(lines)


def handle_register_code(
    engine: CodingEngine,
    file_path: str,
    intent: str,
    signature: str,
) -> str:
    """Register a code pointer."""
    engine.register_code_change(file_path, intent, signature)
    return f"OK: registered {file_path}"


def handle_record_error(
    engine: CodingEngine,
    error_text: str,
    source: str,
) -> str:
    """Record an error as a negative attractor."""
    engine.record_error(error_text, source)
    return f"OK: recorded error from {source}"


def handle_save(engine: CodingEngine) -> str:
    """Persist state to disk."""
    path = engine.save_state()
    return f"OK: saved to {path}"


# ---------------------------------------------------------------------------
# FastMCP server setup


def create_mcp_server(engine: CodingEngine | None = None):
    """Create the FastMCP server with all tools registered."""
    from fastmcp import FastMCP

    mcp = FastMCP(
        "Semvec Coding",
        instructions=(
            "Semvec PSS (Persistent Semantic State) compaction backend. "
            "Maintains O(1) semantic memory across coding sessions. "
            "Use pss_get_context to retrieve compressed prior context, "
            "pss_update to fold new information, and pss_save to persist."
        ),
    )

    if engine is None:
        engine = create_engine()

    @mcp.tool()
    def pss_get_context(
        task: str,
        invariants: list[str] | None = None,
        test_summary: str | None = None,
    ) -> str:
        """Get compacted context for the current task.

        Returns a budget-controlled summary of prior work including
        relevant code pointers, anti-resonance warnings, and memories.
        """
        return handle_get_context(
            engine, task, invariants=invariants, test_summary=test_summary
        )

    @mcp.tool()
    def pss_update(
        text: str,
        update_type: str = "conversation",
        file_path: str | None = None,
        signature: str | None = None,
    ) -> str:
        """Fold information into PSS state.

        ``update_type``: ``conversation``, ``code_change``, ``error``,
        ``test_failure``. For ``code_change``, also provide ``file_path``
        and ``signature``.
        """
        metadata: dict[str, Any] = {}
        if file_path:
            metadata["file_path"] = file_path
        if signature:
            metadata["signature"] = signature
        return handle_update(engine, text, update_type, metadata)

    @mcp.tool()
    def pss_check_anti_resonance(proposal: str) -> str:
        """Check if a proposal resembles known past errors."""
        return handle_check_anti_resonance(engine, proposal)

    @mcp.tool()
    def pss_register_code(
        file_path: str,
        intent: str,
        signature: str,
    ) -> str:
        """Register a code file with its semantic intent."""
        return handle_register_code(engine, file_path, intent, signature)

    @mcp.tool()
    def pss_record_error(error_text: str, source: str = "runtime_error") -> str:
        """Record an error for anti-resonance checking.

        ``source`` ∈ {``test_failure``, ``runtime_error``, ``user_correction``}.
        """
        return handle_record_error(engine, error_text, source)

    @mcp.tool()
    def pss_save() -> str:
        """Persist PSS state to disk."""
        return handle_save(engine)

    return mcp


def main():
    server = create_mcp_server()
    server.run()


if __name__ == "__main__":
    main()
