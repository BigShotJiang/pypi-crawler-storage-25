"""Atomic JSON persistence for Semvec Coding compaction state."""

from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from semvec._core import CodePointerIndex, NegativeAttractorSet


class _NumpyEncoder(json.JSONEncoder):
    def default(self, obj: Any) -> Any:
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        return super().default(obj)


@dataclass
class CompactionState:
    code_pointers: CodePointerIndex = field(default_factory=lambda: CodePointerIndex(capacity=100))
    negative_attractors: NegativeAttractorSet = field(
        default_factory=lambda: NegativeAttractorSet(capacity=30)
    )
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code_pointers": self.code_pointers.to_dict(),
            "negative_attractors": self.negative_attractors.to_dict(),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CompactionState":
        return cls(
            code_pointers=CodePointerIndex.from_dict(data.get("code_pointers", {})),
            negative_attractors=NegativeAttractorSet.from_dict(
                data.get("negative_attractors", {})
            ),
            metadata=data.get("metadata", {}),
        )


def _compute_checksum(data: dict[str, Any]) -> str:
    clean = {k: v for k, v in data.items() if k != "checksum"}
    raw = json.dumps(clean, sort_keys=True, cls=_NumpyEncoder)
    return hashlib.sha256(raw.encode()).hexdigest()


def save_state(state: CompactionState, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    data = state.to_dict()
    data["checksum"] = _compute_checksum(data)

    content = json.dumps(data, indent=2, cls=_NumpyEncoder)

    fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp", prefix=".semvec_")
    try:
        with open(fd, "w") as f:
            f.write(content)
        Path(tmp_path).replace(path)
    except BaseException:
        Path(tmp_path).unlink(missing_ok=True)
        raise


def load_state(path: Path, verify_checksum: bool = False) -> CompactionState:
    path = Path(path)
    if not path.exists():
        return CompactionState()

    data = json.loads(path.read_text())

    if verify_checksum:
        stored = data.get("checksum", "")
        computed = _compute_checksum(data)
        if stored != computed:
            raise ValueError(
                f"Checksum mismatch: stored={stored[:12]}... computed={computed[:12]}..."
            )

    return CompactionState.from_dict(data)
