"""High-level orchestrator for Semvec Coding compaction."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol

import numpy as np

from semvec._core import (
    CodePointer,
    CodePointerIndex,
    NegativeAttractorSet,
    PromptBuilder,
)
from semvec.coding.persistence import CompactionState, load_state, save_state
from semvec.coding.transcript_parser import ChunkType, TranscriptParser


class Embedder(Protocol):
    """Minimal interface for embedding text to vectors."""

    def get_embedding(self, text: str) -> np.ndarray: ...
    def get_dimension(self) -> int: ...


_MISSING_EMBEDDER_MSG = (
    "CodingEngine requires an explicit embedder — there is no hash-based "
    "fallback. Random-noise vectors invalidate PSS metrics and phase "
    "detection, so the library refuses to silently substitute one.\n\n"
    "Pass a `SentenceTransformer` wrapper (matches the pss default):\n\n"
    "    from sentence_transformers import SentenceTransformer\n"
    "    import numpy as np\n\n"
    "    class STEmbedder:\n"
    "        def __init__(self, name='all-MiniLM-L6-v2', device='cpu'):\n"
    "            self._m = SentenceTransformer(name, device=device)\n"
    "            self._dim = self._m.get_sentence_embedding_dimension()\n"
    "        def get_dimension(self): return self._dim\n"
    "        def get_embedding(self, text):\n"
    "            if not text.strip(): return np.zeros(self._dim)\n"
    "            return np.asarray(\n"
    "                self._m.encode(text, normalize_embeddings=True,\n"
    "                               show_progress_bar=False,\n"
    "                               convert_to_numpy=True),\n"
    "                dtype=np.float64,\n"
    "            )\n\n"
    "    engine = CodingEngine(state_dir='~/.semvec', embedder=STEmbedder())\n\n"
    "Install: pip install sentence-transformers"
)


class PyCompactionEngine:
    """Orchestrator for PSS-based context compaction.

    Wraps the Rust-backed CodePointerIndex, NegativeAttractorSet and
    PromptBuilder with Python glue for embedding, transcript parsing,
    and atomic persistence.
    """

    def __init__(
        self,
        state_dir: str,
        workspace_dir: str | None = None,
        embedder: Embedder | None = None,
        context_budget: int = 6000,
        pointer_capacity: int = 100,
        attractor_capacity: int = 30,
    ) -> None:
        if embedder is None:
            raise RuntimeError(_MISSING_EMBEDDER_MSG)
        self._state_dir = Path(state_dir)
        self._workspace_dir = Path(workspace_dir) if workspace_dir else None
        self._embedder = embedder
        self._parser = TranscriptParser()
        self._prompt_builder = PromptBuilder(budget=context_budget)

        self._code_pointers = CodePointerIndex(capacity=pointer_capacity)
        self._negative_attractors = NegativeAttractorSet(capacity=attractor_capacity)

    @property
    def code_pointers(self) -> CodePointerIndex:
        return self._code_pointers

    @property
    def negative_attractors(self) -> NegativeAttractorSet:
        return self._negative_attractors

    def _embed(self, text: str) -> np.ndarray:
        return self._embedder.get_embedding(text)

    def register_code_change(
        self,
        file_path: str,
        intent: str,
        signature: str,
    ) -> None:
        pointer = CodePointer(
            intent_vector=self._embed(intent),
            file_path=file_path,
            signature=signature,
        )
        self._code_pointers.register(pointer)

    def record_error(self, error_text: str, source: str) -> None:
        self._negative_attractors.add(
            error_vector=self._embed(error_text),
            description=error_text[:300],
            source=source,
        )

    def check_anti_resonance(
        self, proposal: str, threshold: float | None = None
    ) -> list:
        # The default threshold previously appeared in plain-text
        # source as 0.7; centralise in the Rust extension so the
        # Python layer no longer leaks the tuning value.
        if threshold is None:
            from semvec._core import _tuning_defaults

            threshold = _tuning_defaults()["coding_anti_resonance_threshold"]
        vec = self._embed(proposal)
        return self._negative_attractors.check(vec, threshold=threshold)

    def ingest_transcript(self, path: Path | str) -> dict[str, int]:
        chunks = self._parser.parse(path)
        stats = {
            "conversation_chunks": 0,
            "code_changes": 0,
            "test_failures": 0,
            "errors": 0,
        }
        for chunk in chunks:
            if chunk.chunk_type == ChunkType.CONVERSATION:
                stats["conversation_chunks"] += 1
            elif chunk.chunk_type == ChunkType.CODE_CHANGE:
                file_path = chunk.metadata.get("file_path", "")
                signatures = chunk.metadata.get("signatures", [])
                sig_str = ", ".join(signatures[:3]) if signatures else "unknown"
                self.register_code_change(file_path, chunk.text, sig_str)
                stats["code_changes"] += 1
            elif chunk.chunk_type == ChunkType.TEST_FAILURE:
                self.record_error(chunk.text, source="test_failure")
                stats["test_failures"] += 1
            elif chunk.chunk_type == ChunkType.ERROR:
                self.record_error(chunk.text, source="runtime_error")
                stats["errors"] += 1
        return stats

    def get_compacted_context(
        self,
        task: str,
        *,
        invariants: list[str] | None = None,
        test_summary: str | None = None,
        git_diff: str | None = None,
        pss_memories: list[str] | None = None,
        phase: str | None = None,
    ) -> str:
        task_vector = self._embed(task)
        return self._prompt_builder.build(
            code_pointers=self._code_pointers,
            negative_attractors=self._negative_attractors,
            task_vector=task_vector,
            invariants=invariants,
            test_summary=test_summary,
            git_diff=git_diff,
            pss_memories=pss_memories,
            phase=phase,
        )

    def save_state(self) -> Path:
        state = CompactionState(
            code_pointers=self._code_pointers,
            negative_attractors=self._negative_attractors,
            metadata={
                "workspace_dir": str(self._workspace_dir) if self._workspace_dir else None,
            },
        )
        path = self._state_dir / "state.json"
        save_state(state, path)
        return path

    def load_state(self) -> bool:
        path = self._state_dir / "state.json"
        exists = path.exists()
        state = load_state(path)
        self._code_pointers = state.code_pointers
        self._negative_attractors = state.negative_attractors
        return exists
