"""Parse Claude Code JSONL transcripts into structured chunks."""

from __future__ import annotations

import ast
import json
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class ChunkType(Enum):
    CONVERSATION = "conversation"
    CODE_CHANGE = "code_change"
    TEST_FAILURE = "test_failure"
    ERROR = "error"


@dataclass
class TranscriptChunk:
    text: str
    chunk_type: ChunkType
    metadata: dict[str, Any] = field(default_factory=dict)


_PYTEST_FAIL_RE = re.compile(r"FAILED\s+(\S+)")
_ERROR_TYPE_RE = re.compile(r"(\w+(?:Error|Exception))")
_TRACEBACK_RE = re.compile(r"Traceback \(most recent call last\)")


def _extract_signatures(source: str) -> list[str]:
    sigs: list[str] = []
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return sigs
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ClassDef):
            sigs.append(f"class {node.name}")
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = ", ".join(a.arg for a in node.args.args)
            sigs.append(f"def {node.name}({args})")
    return sigs


class TranscriptParser:
    """Parse Claude Code JSONL transcripts into structured chunks."""

    def __init__(self, max_chunk_text: int = 500) -> None:
        self._max_text = max_chunk_text

    def parse(self, path: Path | str) -> list[TranscriptChunk]:
        path = Path(path)
        if not path.exists():
            return []
        return self.parse_string(path.read_text())

    def parse_string(self, jsonl: str) -> list[TranscriptChunk]:
        messages: list[dict] = []
        for line in jsonl.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                messages.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return self._process_messages(messages)

    def _process_messages(self, messages: list[dict]) -> list[TranscriptChunk]:
        chunks: list[TranscriptChunk] = []
        pending_user_text: str = ""
        pending_tool_use: dict | None = None

        for msg in messages:
            msg_type = msg.get("type", "")
            if msg_type in ("system", "result"):
                continue

            if msg_type == "user":
                for item in self._get_content_items(msg):
                    item_type = item.get("type", "")
                    if item_type == "text":
                        pending_user_text = item.get("text", "")
                    elif item_type == "tool_result":
                        result_text = item.get("content", "")
                        is_error = item.get("is_error", False)
                        if pending_tool_use:
                            chunks.extend(
                                self._process_tool_result(pending_tool_use, result_text, is_error)
                            )
                            pending_tool_use = None

            elif msg_type == "assistant":
                assistant_text = ""
                for item in self._get_content_items(msg):
                    item_type = item.get("type", "")
                    if item_type == "text":
                        assistant_text = item.get("text", "")
                    elif item_type == "tool_use":
                        pending_tool_use = item

                if pending_user_text and assistant_text:
                    combined = f"Q: {pending_user_text}\nA: {assistant_text}"
                    chunks.append(
                        TranscriptChunk(
                            text=self._truncate(combined),
                            chunk_type=ChunkType.CONVERSATION,
                        )
                    )
                    pending_user_text = ""

        return chunks

    def _process_tool_result(
        self,
        tool_use: dict,
        result_text: str,
        is_error: bool,
    ) -> list[TranscriptChunk]:
        chunks: list[TranscriptChunk] = []
        tool_name = tool_use.get("name", "")
        tool_input = tool_use.get("input", {})

        if tool_name in ("Write", "Edit"):
            file_path = tool_input.get("file_path", "")
            content = tool_input.get("content", "")
            new_string = tool_input.get("new_string", "")
            source = content or new_string
            signatures = _extract_signatures(source) if source else []
            intent = f"{tool_name} {file_path}"
            if signatures:
                intent += f": {', '.join(signatures[:5])}"
            chunks.append(
                TranscriptChunk(
                    text=self._truncate(intent),
                    chunk_type=ChunkType.CODE_CHANGE,
                    metadata={
                        "file_path": file_path,
                        "tool": tool_name,
                        "signatures": signatures,
                    },
                )
            )
        elif tool_name == "Bash":
            if _PYTEST_FAIL_RE.search(result_text):
                failed_tests = _PYTEST_FAIL_RE.findall(result_text)
                chunks.append(
                    TranscriptChunk(
                        text=self._truncate(result_text),
                        chunk_type=ChunkType.TEST_FAILURE,
                        metadata={
                            "failed_tests": failed_tests,
                            "command": tool_input.get("command", ""),
                        },
                    )
                )
            elif is_error or _TRACEBACK_RE.search(result_text):
                match = _ERROR_TYPE_RE.search(result_text)
                error_type = match.group(1) if match else ""
                chunks.append(
                    TranscriptChunk(
                        text=self._truncate(result_text),
                        chunk_type=ChunkType.ERROR,
                        metadata={
                            "error_type": error_type,
                            "command": tool_input.get("command", ""),
                        },
                    )
                )
        return chunks

    def _get_content_items(self, msg: dict) -> list[dict]:
        content = msg.get("message", {}).get("content", [])
        if isinstance(content, list):
            return [c for c in content if isinstance(c, dict)]
        if isinstance(content, str):
            return [{"type": "text", "text": content}]
        return []

    def _truncate(self, text: str) -> str:
        if len(text) <= self._max_text:
            return text
        return text[: self._max_text]
