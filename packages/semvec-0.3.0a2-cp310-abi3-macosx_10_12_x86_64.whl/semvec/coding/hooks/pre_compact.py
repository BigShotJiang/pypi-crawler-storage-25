"""PreCompact hook for Claude Code.

Fires before context compaction. Ingests the conversation transcript
into semvec's CodingEngine, saves state, and logs the compacted context.

Claude Code sends JSON to stdin::

    {
        "session_id": "abc123",
        "transcript_path": "/path/to/transcript.jsonl",
        "cwd": "/workspace",
        "trigger": "auto" | "manual"
    }

Ported from ``pss.compaction.hooks.pre_compact``. semvec requires an
explicit embedder — the subprocess constructs one from a shared
``SentenceTransformer`` (no hash fallback).
"""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


def handle_pre_compact(
    hook_input: dict[str, Any],
    state_dir: str | None = None,
    embedder: object | None = None,
) -> dict[str, Any]:
    """Handle a PreCompact hook event.

    Args:
        hook_input: Parsed JSON payload from Claude Code stdin.
        state_dir:  Override for the PSS state directory
                    (defaults to ``$PSS_STATE_DIR`` or ``.semvec``).
        embedder:   Optional embedder injection. When ``None``, a
                    SentenceTransformer-backed embedder is built from
                    ``$PSS_EMBED_MODEL`` / ``$PSS_EMBED_DEVICE``.

    Returns:
        Result dict with ``status``, ``ingested_chunks``, ``context``,
        ``session_id``, and ``trigger``.
    """
    from semvec.coding import CodingEngine

    from semvec.coding.mcp_server import _env

    state_dir = state_dir or _env("STATE_DIR", default=".semvec")
    workspace_dir = hook_input.get("cwd")
    transcript_path = hook_input.get("transcript_path", "")

    if embedder is None:
        from semvec.coding.mcp_server import _build_embedder

        embedder = _build_embedder(
            _env("EMBED_MODEL", default="all-MiniLM-L6-v2"),
            _env("EMBED_DEVICE", default="cpu"),
        )

    engine = CodingEngine(
        state_dir=state_dir,
        workspace_dir=workspace_dir,
        embedder=embedder,
    )
    engine.load_state()

    total_chunks = 0
    if transcript_path and Path(transcript_path).exists():
        stats = engine.ingest_transcript(transcript_path)
        total_chunks = sum(stats.values())
        log.info(
            "pre_compact: ingested %d chunks from %s",
            total_chunks,
            transcript_path,
        )

    engine.save_state()

    context = engine.get_compacted_context(
        task=f"session {hook_input.get('session_id', 'unknown')}",
    )

    return {
        "status": "ok",
        "ingested_chunks": total_chunks,
        "context": context,
        "session_id": hook_input.get("session_id", ""),
        "trigger": hook_input.get("trigger", ""),
    }


def main() -> None:
    """Entry point: read JSON from stdin, process, log to stderr."""
    data = sys.stdin.read()
    try:
        hook_input = json.loads(data)
    except json.JSONDecodeError:
        # Pass the raw payload through unchanged on parse failure
        print(data, end="")
        sys.exit(0)

    result = handle_pre_compact(hook_input)

    # Log result to stderr (Claude Code reads this)
    print(json.dumps(result), file=sys.stderr)
    # Pass the original data through stdout (Claude Code expects this)
    print(data, end="")


if __name__ == "__main__":
    main()
