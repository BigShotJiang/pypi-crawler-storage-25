"""Hook scripts for Claude Code integration.

Run as subprocesses triggered by Claude Code events:

- ``pre_compact``: fires before context compaction; ingests the transcript
  and persists state.
- ``session_start``: fires when a new session begins; loads prior state
  and reports counts.

Install via ``.claude/settings.json``::

    "hooks": {
        "PreCompact": [{
            "command": "python -m semvec.coding.hooks.pre_compact",
            "timeout": 30000
        }],
        "SessionStart": [{
            "command": "python -m semvec.coding.hooks.session_start",
            "timeout": 10000
        }]
    }
"""
