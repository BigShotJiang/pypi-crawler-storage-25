"""Semvec — patent-pending persistent semantic state engine.

This software implements algorithms covered by patent application
**EP 25 188 105.8** (filed 2025, CIP in progress). Independent
re-implementations of the persistent semantic state update equation,
the phase-detection FSM, the multi-resolution memory consolidation,
or the Field Stability Metric (FSM) may fall under the claims of
this patent application even when written from scratch.

For licensing inquiries see https://www.semvec.io.

----------------------------------------------------------------------
Notice on patent wording: this docstring is provisional and pending
formal review by patent counsel before the next stable release. The
core technical statement (filed application, covered subject matter)
is accurate; only the exact claim language may change.
----------------------------------------------------------------------

The public surface is PEP-8 compliant PascalCase. Legacy PSS-prefixed
names (``PSS_State_V4``, ``PSSConfig``, ``PSSError``) remain importable
as deprecated aliases — accessing them raises :class:`DeprecationWarning`.
Aliases are scheduled for removal in semvec 0.2.0.

Optional anonymous init telemetry: see ``semvec._telemetry`` and
https://www.semvec.io/privacy. Disabled by default; opt in with
``SEMVEC_TELEMETRY=1``.
"""

from __future__ import annotations

import warnings as _warnings
from typing import Any as _Any

from semvec._core import (
    AdaptiveParameters,
    CodeEntity,
    ConfigurationError,
    EmbeddingError,
    LicenseError,
    LicenseExpiredError,
    LiteralCache,
    MemoryUnit,
    MultiResolutionMemory,
    PhaseDetector,
    RateLimitError,
    ResonanceTrigger,
    SemvecConfig,
    SemvecError,
    SemvecState,
    StateCorruptionError,
    safe_cosine_similarity,
)

# `EmbeddingService` is intentionally **not** re-exported. The class
# exists in `semvec._core` for isinstance() compatibility with the
# pre-Rust pss reference, but its `get_embedding()` raises
# `NotImplementedError` — the production embedder ships in user
# space (sentence-transformers, OpenAI, ONNX, …). Audit-5 found
# users were importing it from `semvec` and tripping over the
# stub; removing it from the public surface forces the documented
# pattern of bringing your own embedder. See README "Installation
# → Embedder".
from semvec.literal_cache import EntityKind

__version__ = "0.3.0a2"
__author__ = "Michael Neuberger"


# ---------------------------------------------------------------------------
# Default-on init telemetry + diversity-sketch report at process exit.
# Both are gated by SEMVEC_TELEMETRY=0 (opt-out). Implementations:
#   - semvec/_telemetry.py — single init ping
#   - semvec/_diversity.py — HyperLogLog sketch over calculate_*
#     inputs, posted at atexit. Output is a single integer
#     cardinality estimate; raw inputs never leave the process.
from semvec._telemetry import maybe_report_init as _maybe_report_init

try:
    _maybe_report_init(__version__)
except Exception:
    pass
finally:
    del _maybe_report_init

try:
    from semvec._diversity import (
        maybe_report_at_exit as _diversity_maybe_report_at_exit,
    )
    _diversity_maybe_report_at_exit(__version__)
    # NOTE: wiring the HLL sketch into the actual SemvecState
    # calculate_* call sites needs a Rust-side hook — PyO3 method
    # dispatch goes through tp_methods (C level), so a Python
    # `setattr(SemvecState, 'calculate_fsm', wrapper)` does not
    # intercept the runtime calls. The infrastructure is in place
    # (`semvec._diversity.add(values)` is callable; the atexit
    # reporter is registered and a no-op when the sketch is
    # empty) and a follow-up release that adds the hook in
    # `src/bindings.rs` flips this on without further client
    # changes. See ARCHITECTURE.md.
    del _diversity_maybe_report_at_exit
except Exception:
    pass

__all__ = [
    "AdaptiveParameters",
    "CodeEntity",
    "ConfigurationError",
    "EmbeddingError",
    "EntityKind",
    "LicenseError",
    "LicenseExpiredError",
    "LiteralCache",
    "MemoryUnit",
    "MultiResolutionMemory",
    "PhaseDetector",
    "RateLimitError",
    "ResonanceTrigger",
    "SemvecConfig",
    "SemvecError",
    "SemvecState",
    "StateCorruptionError",
    "safe_cosine_similarity",
]


# ---------------------------------------------------------------------------
# Deprecated aliases — emit a DeprecationWarning on access, resolve to the
# current PEP-8 names. Scheduled for removal in 0.2.0.

_DEPRECATED_ALIASES: dict[str, tuple[str, _Any]] = {
    "PSS_State_V4": ("SemvecState", SemvecState),
    "PSSConfig": ("SemvecConfig", SemvecConfig),
    "PSSError": ("SemvecError", SemvecError),
}


# ---------------------------------------------------------------------------
# 0.2.0a5 patent-protection hardening: the top-level free functions
# `_core.calculate_fsm` / `_core.calculate_metrics` /
# `_core.calculate_advanced_metrics` no longer forward to the
# unsalted Rust kernel — they raise RuntimeError pointing at the
# state-bound API.
#
# Why a hard error instead of a DeprecationWarning?  The audit-2
# review of 0.2.0a4 found that a surrogate trainer simply silenced
# the warning with `warnings.filterwarnings('ignore')` and read
# unsalted kernel outputs in 220 k calls/s. The DeprecationWarning
# was protection theatre. A hard error closes the bypass.
from semvec import _core as _semvec_core_mod


def _make_disabled_calc(name: str):
    def _wrapper(*_args, **_kwargs):
        raise RuntimeError(
            f"_core.{name} was removed in semvec 0.2.0a5 — use the "
            f"state-bound SemvecState.{name} method instead. The free "
            f"function used to return unsalted reference outputs; that "
            f"path is closed because surrogate models could harvest it "
            f"without a license. See ARCHITECTURE.md for context."
        )

    _wrapper.__name__ = name
    _wrapper.__qualname__ = name
    _wrapper.__doc__ = (
        f"REMOVED — call {name}() on a SemvecState instance instead."
    )
    return _wrapper


for _calc_name in ("calculate_fsm", "calculate_metrics", "calculate_advanced_metrics"):
    if hasattr(_semvec_core_mod, _calc_name):
        setattr(
            _semvec_core_mod,
            _calc_name,
            _make_disabled_calc(_calc_name),
        )

del _make_disabled_calc, _semvec_core_mod, _calc_name


def __getattr__(name: str) -> _Any:
    alias = _DEPRECATED_ALIASES.get(name)
    if alias is not None:
        replacement_name, obj = alias
        _warnings.warn(
            f"{name} is deprecated and will be removed in semvec 0.2.0. "
            f"Use {replacement_name} instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return obj
    raise AttributeError(f"module 'semvec' has no attribute {name!r}")
