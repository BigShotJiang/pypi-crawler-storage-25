"""Anonymous init telemetry for semvec.

**Default-on as of 0.2.0a4.** On every import, exactly one HTTP POST
is sent per Python process to the configured endpoint (default:
``https://semvec-telemetry.versino.workers.dev/init``),
fire-and-forget, with a 500 ms timeout. A one-line notice is printed
to stderr the first time the ping fires per process; silence the
notice with ``SEMVEC_TELEMETRY_QUIET=1``.

To **disable** telemetry: set ``SEMVEC_TELEMETRY=0`` in the
environment before importing semvec. Anything other than the literal
string ``0`` is treated as enabled — the previous opt-in
``SEMVEC_TELEMETRY=1`` keeps working unchanged.

The body contains:

- ``v``       — semvec version
- ``machine`` — SHA-256(persistent_local_salt || machine_id)[:32].
                The local salt lives in ``~/.semvec/telemetry-salt``;
                without it the pseudonym is not reproducible.
- ``os``      — ``linux`` / ``darwin`` / ``windows`` / …
- ``arch``    — ``x86_64`` / ``aarch64`` / …
- ``py``      — Python interpreter version

No IP, no user-agent string from the user's environment, no command
line, no environment dump, no inference data. The schema is
authoritatively documented at https://www.semvec.io/privacy.

**Lawful basis**: GDPR Art. 6(1)(f) — legitimate interest in patent
enforcement (EP 25 188 105.8). The pseudonymous pseudonym, the
absence of personally identifiable data, the 90-day retention, and
the trivial opt-out (``SEMVEC_TELEMETRY=0``) keep the data
collection proportionate to the purpose. Pro / Enterprise license
holders have telemetry coverage addressed separately in their
license agreement; for those callers the lawful basis shifts to
Art. 6(1)(b) (contract).

To rotate the pseudonym, delete ``~/.semvec/telemetry-salt``.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
import threading
import urllib.request
from pathlib import Path

DEFAULT_ENDPOINT = "https://semvec-telemetry.versino.workers.dev/init"
TIMEOUT_SECONDS = 0.5
SALT_FILE = Path.home() / ".semvec" / "telemetry-salt"
ENV_FLAG = "SEMVEC_TELEMETRY"
ENV_ENDPOINT_OVERRIDE = "SEMVEC_TELEMETRY_ENDPOINT"
ENV_QUIET = "SEMVEC_TELEMETRY_QUIET"

_NOTICE_PRINTED = False
_REPORTED = False


def _enabled() -> bool:
    """Telemetry is on by default (0.2.0a4+). Only the literal env
    string ``0`` disables it. Anything else — empty, ``1``, ``true``,
    ``yes``, garbage — leaves it on. This makes the opt-out path
    explicit and impossible to enable accidentally by setting the
    variable to some non-zero value.
    """
    return os.environ.get(ENV_FLAG, "") != "0"


def _quiet() -> bool:
    return os.environ.get(ENV_QUIET, "") == "1"


def _read_machine_id() -> str:
    """Best-effort stable machine identifier across platforms.

    Falls back to ``platform.node()`` (the hostname) if no
    machine-id-style file is available — which is fine for the
    purpose of de-duplicating installs.
    """
    candidate_paths = [
        "/etc/machine-id",
        "/var/lib/dbus/machine-id",
    ]
    for p in candidate_paths:
        try:
            value = Path(p).read_text(encoding="ascii").strip()
            if value:
                return value
        except OSError:
            continue
    return platform.node() or "unknown"


def _ensure_salt() -> bytes:
    """Read or create the persistent per-user telemetry salt.

    Stored under ``~/.semvec/telemetry-salt`` with mode 0600. If the
    home directory is not writable we fall back to a deterministic
    in-memory salt so the pseudonym is at least stable within the
    process.
    """
    try:
        SALT_FILE.parent.mkdir(parents=True, exist_ok=True)
        if SALT_FILE.exists():
            existing = SALT_FILE.read_bytes()
            if len(existing) >= 16:
                return existing
        salt = os.urandom(32)
        SALT_FILE.write_bytes(salt)
        try:
            SALT_FILE.chmod(0o600)
        except OSError:
            # Windows doesn't honour 0600 the same way; not fatal.
            pass
        return salt
    except OSError:
        # Read-only home, container without writable HOME, etc.
        # Use a stable fallback derived from the machine-id alone —
        # the pseudonym then degrades to "stable per machine, not
        # per user", which is still acceptable for opt-in use.
        return hashlib.sha256(b"semvec-telemetry-fallback-v1").digest()


def _machine_pseudonym() -> str:
    salt = _ensure_salt()
    machine = _read_machine_id().encode("utf-8", errors="replace")
    digest = hashlib.sha256(salt + b":" + machine).hexdigest()
    return digest[:32]


def _payload(version: str) -> bytes:
    body = {
        "v": version,
        "machine": _machine_pseudonym(),
        "os": platform.system().lower(),
        "arch": platform.machine().lower() or "unknown",
        "py": platform.python_version(),
    }
    return json.dumps(body, separators=(",", ":")).encode("utf-8")


def _print_notice() -> None:
    global _NOTICE_PRINTED
    if _NOTICE_PRINTED or _quiet():
        return
    _NOTICE_PRINTED = True
    sys.stderr.write(
        "[semvec] anonymous init telemetry is on (one ping per process).\n"
        "[semvec] schema + lawful basis: https://www.semvec.io/privacy\n"
        "[semvec] opt out: SEMVEC_TELEMETRY=0  ·  silence: SEMVEC_TELEMETRY_QUIET=1\n"
    )


def _user_agent(version: str) -> str:
    """Honest, identifiable User-Agent — no spoofing.

    The default ``Python-urllib/<ver>`` UA is rejected outright by
    several CDN bot-protection layers (we hit a Cloudflare 403 with
    it during testing). An explicit semvec UA also lets us
    distinguish opt-in pings from probes in the worker's request log.
    """
    return f"semvec-telemetry/{version} (python {platform.python_version()})"


def _send(endpoint: str, body: bytes, version: str) -> None:
    """Fire-and-forget POST. Exceptions are swallowed; this must
    never disrupt the caller's import.
    """
    try:
        req = urllib.request.Request(
            endpoint,
            data=body,
            headers={
                "content-type": "application/json",
                "user-agent": _user_agent(version),
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            resp.read(0)  # consume nothing; we don't care about the body
    except Exception:
        # Network failure, DNS fail, endpoint not deployed yet, TLS error,
        # firewall, captive portal — all silently ignored. Telemetry must
        # never affect the user.
        pass


def maybe_report_init(version: str) -> None:
    """Called once at semvec import time.

    No-op unless ``SEMVEC_TELEMETRY=1``. When enabled:

    1. Prints the privacy notice on stderr (once per process,
       suppressible with ``SEMVEC_TELEMETRY_QUIET=1``).
    2. Sends one anonymous ping in a daemon thread so the import is
       not blocked even if the network is slow.

    Idempotent across multiple calls in the same process.
    """
    global _REPORTED
    if _REPORTED:
        return
    _REPORTED = True

    if not _enabled():
        return

    _print_notice()

    endpoint = os.environ.get(ENV_ENDPOINT_OVERRIDE, "").strip() or DEFAULT_ENDPOINT
    payload = _payload(version)

    thread = threading.Thread(
        target=_send,
        args=(endpoint, payload, version),
        name="semvec-telemetry-init",
        daemon=True,
    )
    thread.start()
