"""FastAPI application factory for the Semvec REST API.

Wires auth + rate limiting + CORS + routers. CORS origins come from the
``CORS_ORIGINS`` env var (comma-separated); an empty value blocks
cross-origin requests by default.
"""

from __future__ import annotations

import os

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from slowapi.errors import RateLimitExceeded

from semvec.api.auth import verify_basic_auth
from semvec.api.metrics_export import get_metrics_response, setup_metrics

from semvec.api.cluster_manager import ClusterManager
from semvec.api.cluster_routes import cluster_router, set_cluster_manager
from semvec.api.database import create_tables
from semvec.api.event_bus import DriftEventBus
from semvec.api.global_observer import ObserverManager
from semvec.api.literal_cache_routes import (
    literal_router,
    set_literal_session_manager,
)
from semvec.api.network_manager import NetworkManager
from semvec.api.network_routes import network_router, set_network_manager
from semvec.api.observer_routes import observer_router, set_observer_manager
from semvec.api.regional_manager import RegionalManager
from semvec.api.regional_routes import regional_router, set_regional_manager
from semvec.api.routes import (
    limiter,
    router as core_router,
    set_layer3_managers,
    set_session_manager,
)
from semvec.api.session_delta_routes import (
    delta_router,
    set_delta_session_manager,
)
from semvec.api.session_manager import SessionManager


def _get_cors_origins() -> list[str]:
    raw = os.environ.get("CORS_ORIGINS", "")
    if not raw.strip():
        return []
    return [origin.strip() for origin in raw.split(",") if origin.strip()]


def create_app() -> FastAPI:
    """Build and return the Semvec REST API FastAPI application."""
    app = FastAPI(
        title="Semvec REST API — Persistent Semantic State",
        description=(
            "Framework-agnostic semantic memory service. Feed text into "
            "Semvec sessions and retrieve context-aware memories. Auth "
            "via Ed25519-signed license JWTs (SEMVEC_LICENSE_KEY)."
        ),
        version="1.0.0",
    )

    app.state.limiter = limiter

    def _rate_limit_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
        return JSONResponse(
            status_code=429,
            content={"detail": "Too many requests"},
            headers={"Retry-After": "60"},
        )

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_get_cors_origins(),
        allow_methods=["GET", "POST", "PATCH", "DELETE", "PUT", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-API-Key"],
    )

    setup_metrics(app)

    @app.get("/metrics")
    def _metrics(_: bool = Depends(verify_basic_auth)) -> Response:
        return get_metrics_response()

    create_tables()

    manager = SessionManager()
    set_session_manager(manager)
    set_delta_session_manager(manager)
    set_literal_session_manager(manager)
    app.state.session_manager = manager

    cluster_manager = ClusterManager(manager)
    set_cluster_manager(cluster_manager)
    app.state.cluster_manager = cluster_manager

    event_bus = DriftEventBus()
    regional_manager = RegionalManager(manager, cluster_manager, event_bus)
    set_regional_manager(regional_manager)
    app.state.regional_manager = regional_manager
    app.state.drift_event_bus = event_bus

    # routes.run() publishes drift events through these managers.
    set_layer3_managers(cluster_manager, regional_manager)

    observer_manager = ObserverManager(cluster_manager, regional_manager, manager)
    set_observer_manager(observer_manager)
    app.state.observer_manager = observer_manager

    network_manager = NetworkManager(manager)
    set_network_manager(network_manager)
    app.state.network_manager = network_manager

    app.include_router(core_router)
    app.include_router(delta_router)
    app.include_router(literal_router)
    app.include_router(cluster_router)
    app.include_router(regional_router)
    app.include_router(observer_router)
    app.include_router(network_router)

    return app
