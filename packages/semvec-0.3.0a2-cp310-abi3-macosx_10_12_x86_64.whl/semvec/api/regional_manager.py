"""Layer 3 — Regional manager for the Semvec REST API.

Regions aggregate multiple clusters. When a configurable fraction of
member clusters report drift within a rolling time window, a regional
realignment is triggered (captured as a summary update into the region's
meta-session). Drift events are async — no agent turn is ever blocked.
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from semvec.api.cluster_manager import ClusterManager
from semvec.api.event_bus import DriftEvent, DriftEventBus
from semvec.api.session_manager import SessionManager

logger = logging.getLogger(__name__)


@dataclass
class RegionRecord:
    region_id: str
    name: str
    cluster_ids: list[str] = field(default_factory=list)
    meta_session_id: str = ""
    consensus_threshold: float = 0.5
    vote_window_seconds: float = 60.0
    owner_subject: str | None = None


class RegionalManager:
    """Thread-safe in-memory store for Semvec regions (Layer 3)."""

    def __init__(
        self,
        session_manager: SessionManager,
        cluster_manager: ClusterManager,
        event_bus: DriftEventBus,
    ) -> None:
        self._session_manager = session_manager
        self._cluster_manager = cluster_manager
        self._event_bus = event_bus
        self._regions: dict[str, RegionRecord] = {}
        self._lock = threading.Lock()
        self._callbacks: dict[str, Any] = {}
        self._realignment_counts: dict[str, int] = {}
        self._last_realignment_at: dict[str, float | None] = {}

    @staticmethod
    def _check_ownership(
        record: RegionRecord, owner_subject: str | None
    ) -> bool:
        if owner_subject is None or record.owner_subject is None:
            return True
        return record.owner_subject == owner_subject

    # ------------------------------------------------------------------
    # CRUD

    def create_region(
        self,
        name: str,
        consensus_threshold: float = 0.5,
        vote_window_seconds: float = 60.0,
        owner_subject: str | None = None,
    ) -> RegionRecord:
        region_id = str(uuid.uuid4())
        meta_session_id = self._session_manager.create_session(
            owner_subject=owner_subject
        )
        record = RegionRecord(
            region_id=region_id,
            name=name,
            cluster_ids=[],
            meta_session_id=meta_session_id,
            consensus_threshold=consensus_threshold,
            vote_window_seconds=vote_window_seconds,
            owner_subject=owner_subject,
        )
        with self._lock:
            self._regions[region_id] = record
            self._realignment_counts[region_id] = 0
            self._last_realignment_at[region_id] = None

        cb = self._make_drift_callback(region_id)
        self._callbacks[region_id] = cb
        self._event_bus.subscribe(region_id, cb)
        return record

    def get_region(
        self, region_id: str, owner_subject: str | None = None
    ) -> RegionRecord | None:
        with self._lock:
            record = self._regions.get(region_id)
        if record is None:
            return None
        if not self._check_ownership(record, owner_subject):
            return None
        return record

    def list_regions(
        self, owner_subject: str | None = None
    ) -> list[RegionRecord]:
        with self._lock:
            return [
                r
                for r in self._regions.values()
                if self._check_ownership(r, owner_subject)
            ]

    def delete_region(
        self, region_id: str, owner_subject: str | None = None
    ) -> bool:
        with self._lock:
            record = self._regions.get(region_id)
            if record is None:
                return False
            if not self._check_ownership(record, owner_subject):
                return False
            del self._regions[region_id]
            meta_sid = record.meta_session_id

        cb = self._callbacks.pop(region_id, None)
        if cb is not None:
            self._event_bus.unsubscribe(region_id, cb)

        self._session_manager.delete_session(
            meta_sid, owner_subject=owner_subject
        )

        with self._lock:
            self._realignment_counts.pop(region_id, None)
            self._last_realignment_at.pop(region_id, None)
        return True

    # ------------------------------------------------------------------
    # Cluster membership

    def add_cluster(
        self,
        region_id: str,
        cluster_id: str,
        owner_subject: str | None = None,
    ) -> bool:
        with self._lock:
            record = self._regions.get(region_id)
            if record is None:
                return False
            if not self._check_ownership(record, owner_subject):
                return False
            if cluster_id not in record.cluster_ids:
                record.cluster_ids.append(cluster_id)
        return True

    def remove_cluster(
        self,
        region_id: str,
        cluster_id: str,
        owner_subject: str | None = None,
    ) -> bool:
        with self._lock:
            record = self._regions.get(region_id)
            if record is None:
                return False
            if not self._check_ownership(record, owner_subject):
                return False
            if cluster_id not in record.cluster_ids:
                return False
            record.cluster_ids.remove(cluster_id)
        return True

    def get_region_for_cluster(self, cluster_id: str) -> str | None:
        with self._lock:
            for record in self._regions.values():
                if cluster_id in record.cluster_ids:
                    return record.region_id
        return None

    # ------------------------------------------------------------------
    # State

    def get_region_state(
        self, region_id: str, owner_subject: str | None = None
    ) -> dict[str, Any] | None:
        record = self.get_region(region_id, owner_subject=owner_subject)
        if record is None:
            return None
        with self._lock:
            last_realignment = self._last_realignment_at.get(region_id)
        recent = [
            {
                "cluster_id": ev.cluster_id,
                "region_id": ev.region_id,
                "drift_score": ev.drift_score,
                "drift_phase": ev.drift_phase,
                "timestamp": ev.timestamp,
            }
            for ev in self._event_bus.get_recent_events(region_id, limit=20)
        ]
        return {
            "region_id": record.region_id,
            "name": record.name,
            "meta_session_id": record.meta_session_id,
            "cluster_count": len(record.cluster_ids),
            "consensus_threshold": record.consensus_threshold,
            "recent_drift_events": recent,
            "last_realignment": last_realignment,
        }

    # ------------------------------------------------------------------
    # Drift event publishing + consensus

    def publish_drift(
        self,
        cluster_id: str,
        region_id: str,
        drift_score: float,
        drift_phase: str,
    ) -> None:
        self._event_bus.publish(
            DriftEvent(
                cluster_id=cluster_id,
                region_id=region_id,
                drift_score=drift_score,
                drift_phase=drift_phase,
                timestamp=time.time(),
            )
        )

    def get_recent_events(
        self, region_id: str, limit: int = 20
    ) -> list[DriftEvent]:
        return self._event_bus.get_recent_events(region_id, limit=limit)

    def _make_drift_callback(self, region_id: str):
        def _on_drift(event: DriftEvent) -> None:
            with self._lock:
                record = self._regions.get(region_id)
                if record is None:
                    return
                cluster_ids = list(record.cluster_ids)
                threshold = record.consensus_threshold
                window = record.vote_window_seconds

            if not cluster_ids:
                return

            now = time.time()
            recent_events = self._event_bus.get_recent_events(
                region_id, limit=1000
            )
            voted_clusters = {
                ev.cluster_id
                for ev in recent_events
                if (now - ev.timestamp) <= window
                and ev.cluster_id in cluster_ids
            }
            if not voted_clusters:
                return

            # Equal weighting — a ratio over member count is enough for
            # consensus; influence weighting per cluster is a future extension.
            ratio = len(voted_clusters) / len(cluster_ids)
            if ratio > threshold:
                self._realign_region(region_id, voted_clusters)

        return _on_drift

    def _realign_region(
        self, region_id: str, voted_clusters: set[str]
    ) -> None:
        with self._lock:
            record = self._regions.get(region_id)
            if record is None:
                return
            self._realignment_counts[region_id] = (
                self._realignment_counts.get(region_id, 0) + 1
            )
            self._last_realignment_at[region_id] = time.time()
            meta_sid = record.meta_session_id

        summary = (
            f"Regional realignment triggered: {len(voted_clusters)} clusters "
            f"reported drift in region {region_id}"
        )
        try:
            self._session_manager.update_state(meta_sid, summary)
        except Exception:
            logger.exception("Failed to record realignment summary")
