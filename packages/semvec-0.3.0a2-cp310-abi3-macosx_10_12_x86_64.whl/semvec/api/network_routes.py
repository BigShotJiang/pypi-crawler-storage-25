"""Phase G — Layer 5 network routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from semvec.api.auth import verify_license
from semvec.api.network_manager import NetworkManager
from semvec.api.schemas import (
    ActiveUserResponse,
    ConsensusProposalRequest,
    ConsensusProposalResponse,
    DeltaTransferRequest,
    DeltaTransferResponse,
    TrustScoresResponse,
    UserSerializeResponse,
    UserSwitchRequest,
    UserSwitchResponse,
)

network_router = APIRouter(prefix="/v1/network")

_network_manager: NetworkManager | None = None


def set_network_manager(manager: NetworkManager) -> None:
    global _network_manager
    _network_manager = manager


def _mgr() -> NetworkManager:
    if _network_manager is None:
        raise RuntimeError("NetworkManager not injected into network_router")
    return _network_manager


@network_router.post(
    "/transfer",
    response_model=DeltaTransferResponse,
    dependencies=[Depends(verify_license)],
)
def transfer_delta(body: DeltaTransferRequest):
    result = _mgr().transfer_delta(
        source_session_id=body.source_session_id,
        target_session_id=body.target_session_id,
        max_weight=body.max_weight,
    )
    if result is None:
        raise HTTPException(
            status_code=404, detail="One or both sessions not found"
        )
    return DeltaTransferResponse(
        source_session_id=body.source_session_id,
        target_session_id=body.target_session_id,
        delta_norm=float(result["delta_norm"]),
    )


@network_router.post(
    "/users/switch",
    response_model=UserSwitchResponse,
    dependencies=[Depends(verify_license)],
)
def switch_user(body: UserSwitchRequest):
    result = _mgr().switch_user(body.user_id)
    return UserSwitchResponse(
        active_user=result["active_user"],
        previous_user=result["previous_user"],
    )


@network_router.get(
    "/users/active",
    response_model=ActiveUserResponse,
    dependencies=[Depends(verify_license)],
)
def get_active_user():
    return ActiveUserResponse(active_user=_mgr().get_active_user())


@network_router.post(
    "/users/{user_id}/serialize",
    response_model=UserSerializeResponse,
    dependencies=[Depends(verify_license)],
)
def serialize_user(user_id: str):
    state = _mgr().serialize_user(user_id)
    if state is None:
        raise HTTPException(
            status_code=404, detail=f"User partition '{user_id}' not found"
        )
    return UserSerializeResponse(user_id=user_id, state=state)


@network_router.post(
    "/consensus",
    response_model=ConsensusProposalResponse,
    dependencies=[Depends(verify_license)],
)
def propose_consensus(body: ConsensusProposalRequest):
    result = _mgr().propose_consensus(
        proposer_session_id=body.proposer_session_id,
        target_embedding=body.target_embedding,
    )
    if result is None:
        raise HTTPException(status_code=404, detail="Proposer session not found")
    return ConsensusProposalResponse(
        accepted=result["accepted"], trust_scores=result["trust_scores"]
    )


@network_router.get(
    "/consensus/trust",
    response_model=TrustScoresResponse,
    dependencies=[Depends(verify_license)],
)
def get_trust_scores():
    return TrustScoresResponse(trust_scores=_mgr().get_trust_scores())
