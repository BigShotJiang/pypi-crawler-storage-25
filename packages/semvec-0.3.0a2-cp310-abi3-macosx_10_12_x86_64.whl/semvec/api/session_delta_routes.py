"""Phase-C routes — session-control surface over the feature-delta features.

Each route depends on ``verify_license`` (like the Phase-B router) and
delegates to :class:`SessionManager` for the actual state mutation.

Endpoints:
  POST/DELETE /v1/session/{id}/trigger              — resonance triggers
  POST        /v1/session/{id}/anchor               — drift anchors
  GET         /v1/session/{id}/anchor_score
  PUT         /v1/session/{id}/isolation            — isolation filter
  POST        /v1/session/{id}/isolation/release
  POST        /v1/session/{id}/memory               — synthetic memory inject
  GET         /v1/session/{id}/export               — state + checksum
  POST        /v1/session/{id}/import
  POST        /v1/session/{id}/verify               — behavioral consistency
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request

from semvec.api.auth import license_subject, verify_license
from semvec.api.schemas import (
    AnchorRequest,
    AnchorResponse,
    AnchorScoreResponse,
    ExportResponse,
    ImportRequest,
    ImportResponse,
    IsolationReleaseResponse,
    IsolationRequest,
    IsolationResponse,
    MemoryInjectRequest,
    MemoryInjectResponse,
    TriggerRequest,
    TriggerResponse,
    VerifyRequest,
    VerifyResponse,
)
from semvec.api.session_manager import SessionManager

delta_router = APIRouter(prefix="/v1")


def _get_manager() -> SessionManager:
    raise RuntimeError("SessionManager not injected — call set_delta_session_manager()")


def set_delta_session_manager(manager: SessionManager) -> None:
    global _get_manager

    def _impl() -> SessionManager:
        return manager

    _get_manager = _impl  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Resonance triggers


@delta_router.post(
    "/session/{session_id}/trigger",
    response_model=TriggerResponse,
    dependencies=[Depends(verify_license)],
)
def add_trigger(session_id: str, request: Request, req: TriggerRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    count = mgr.add_trigger(
        session_id,
        keyword=req.keyword,
        embedding=req.embedding,
        threshold=req.threshold,
        owner_subject=subject,
    )
    if count is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return TriggerResponse(session_id=session_id, trigger_count=count)


@delta_router.delete(
    "/session/{session_id}/trigger",
    response_model=TriggerResponse,
    dependencies=[Depends(verify_license)],
)
def clear_triggers(session_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    count = mgr.clear_triggers(session_id, owner_subject=subject)
    if count is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return TriggerResponse(session_id=session_id, trigger_count=0)


# ---------------------------------------------------------------------------
# Drift anchors


@delta_router.post(
    "/session/{session_id}/anchor",
    response_model=AnchorResponse,
    dependencies=[Depends(verify_license)],
)
def add_anchor(session_id: str, request: Request, req: AnchorRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    count = mgr.add_anchor(session_id, req.embedding, owner_subject=subject)
    if count is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return AnchorResponse(session_id=session_id, anchor_count=count)


@delta_router.get(
    "/session/{session_id}/anchor_score",
    response_model=AnchorScoreResponse,
    dependencies=[Depends(verify_license)],
)
def anchor_score(session_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    score = mgr.get_anchor_score(session_id, owner_subject=subject)
    if score is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return AnchorScoreResponse(session_id=session_id, **score)


# ---------------------------------------------------------------------------
# Input isolation


@delta_router.put(
    "/session/{session_id}/isolation",
    response_model=IsolationResponse,
    dependencies=[Depends(verify_license)],
)
def set_isolation(session_id: str, request: Request, req: IsolationRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    ok = mgr.set_isolation(
        session_id,
        req.level,
        exclusion_embeddings=req.exclusion_embeddings,
        allowlist_embeddings=req.allowlist_embeddings,
        similarity_threshold=req.similarity_threshold,
        owner_subject=subject,
    )
    if not ok:
        raise HTTPException(status_code=404, detail="Session not found")
    return IsolationResponse(session_id=session_id, level=req.level)


@delta_router.post(
    "/session/{session_id}/isolation/release",
    response_model=IsolationReleaseResponse,
    dependencies=[Depends(verify_license)],
)
def release_isolation(session_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    count = mgr.release_quarantine(session_id, owner_subject=subject)
    if count is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return IsolationReleaseResponse(session_id=session_id, released_count=count)


# ---------------------------------------------------------------------------
# Synthetic memory injection


@delta_router.post(
    "/session/{session_id}/memory",
    response_model=MemoryInjectResponse,
    dependencies=[Depends(verify_license)],
)
def inject_memory(session_id: str, request: Request, req: MemoryInjectRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    total = mgr.inject_memory(
        session_id,
        embedding=req.embedding,
        text=req.text,
        tier=req.tier,
        importance=req.importance,
        access_count=req.access_count,
        owner_subject=subject,
    )
    if total is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return MemoryInjectResponse(session_id=session_id, tier=req.tier, total_memories=total)


# ---------------------------------------------------------------------------
# Export / Import / Verify


@delta_router.get(
    "/session/{session_id}/export",
    response_model=ExportResponse,
    dependencies=[Depends(verify_license)],
)
def export_session_state(session_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    payload = mgr.export_state(session_id, owner_subject=subject)
    if payload is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return ExportResponse(**payload)


@delta_router.post(
    "/session/{session_id}/import",
    response_model=ImportResponse,
    dependencies=[Depends(verify_license)],
)
def import_session_state(session_id: str, request: Request, req: ImportRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    # Ensure the target session exists first.
    if mgr.get_session(session_id, owner_subject=subject) is None:
        raise HTTPException(status_code=404, detail="Session not found")
    ok = mgr.import_state(session_id, req.state_dict, owner_subject=subject)
    if not ok:
        raise HTTPException(status_code=400, detail="Malformed or tampered state_dict")
    return ImportResponse(session_id=session_id, imported=True)


@delta_router.post(
    "/session/{session_id}/verify",
    response_model=VerifyResponse,
    dependencies=[Depends(verify_license)],
)
def verify_session_consistency(session_id: str, request: Request, req: VerifyRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    consistent = mgr.verify_consistency(
        session_id, req.test_embeddings, owner_subject=subject
    )
    if consistent is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return VerifyResponse(session_id=session_id, consistent=bool(consistent))
