"""License-based authentication for the Semvec REST API.

Every request (except ``/v1/health``) must carry a valid Ed25519-signed
license JWT — either via ``Authorization: Bearer <jwt>`` or via
``X-API-Key: <jwt>``. The token is verified by the Rust core
(``semvec._core.verify_license_token``), which extracts the tier
(community / pro / enterprise) and the ``sub`` claim. The subject is
used as the ownership key for sessions/clusters/regions; the tier
drives the rate limiter.

No password store, no separate API-key table. The license JWT is the
single source of truth.
"""

from __future__ import annotations

import base64
import os
from typing import Any

from fastapi import HTTPException, Request

from semvec import LicenseError, LicenseExpiredError
from semvec._core import dev_anonymous_enabled, verify_license_token
from semvec.api.models import ANONYMOUS_SUBJECT

# Compile-time flag baked into the Rust core. PyPI release wheels build
# without the `dev-anonymous` Cargo feature, so this returns False and the
# SEMVEC_ALLOW_ANONYMOUS env-var bypass below is unreachable. Only local
# development wheels (`maturin develop --features dev-anonymous`) flip it on.
_DEV_ANONYMOUS_ALLOWED: bool = dev_anonymous_enabled()

# ---------------------------------------------------------------------------
# Client IP resolution (reverse-proxy aware)
# ---------------------------------------------------------------------------


def get_client_ip(request: Request) -> str | None:
    """Return the real client IP, respecting X-Forwarded-For and X-Real-IP."""
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip.strip()
    return request.client.host if request.client else None


# ---------------------------------------------------------------------------
# License JWT extraction + verification
# ---------------------------------------------------------------------------


def _extract_token(request: Request) -> str | None:
    """Pull the license JWT from Authorization: Bearer or X-API-Key."""
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:].strip() or None
    api_key = request.headers.get("X-API-Key")
    if api_key:
        return api_key.strip() or None
    return None


def verify_license(request: Request) -> dict[str, Any]:
    """FastAPI dependency: verify the caller's license JWT.

    On success, returns a claims dict with ``tier``, ``products``,
    ``expiry_unix``, ``subject``. Attaches the same payload to
    ``request.state.license`` for downstream handlers.

    Raises 401 if the header is missing, 402 if the license is expired,
    403 if the license is valid but doesn't cover ``semvec`` as a product,
    400 for malformed tokens.
    """
    # Allow the health endpoint through without auth.
    if request.url.path.endswith("/v1/health"):
        return {"tier": "community", "subject": ANONYMOUS_SUBJECT, "products": []}

    token = _extract_token(request)
    if not token:
        # Dev-only escape hatch. Gated by the Rust compile-time
        # `dev-anonymous` feature AND the env var — both must be in place.
        # In PyPI release wheels the feature is off, so the env var alone
        # cannot unlock anonymous access.
        if _DEV_ANONYMOUS_ALLOWED and os.environ.get("SEMVEC_ALLOW_ANONYMOUS", "") == "1":
            payload = {
                "tier": "community",
                "subject": ANONYMOUS_SUBJECT,
                "products": ["semvec"],
                "expiry_unix": 0,
            }
            request.state.license = payload
            return payload
        raise HTTPException(
            status_code=401,
            detail="Missing license token — send Authorization: Bearer <jwt> or X-API-Key",
        )

    try:
        claims = verify_license_token(token)
    except LicenseExpiredError as exc:
        raise HTTPException(status_code=402, detail=str(exc)) from exc
    except LicenseError as exc:
        raise HTTPException(status_code=401, detail=f"Invalid license: {exc}") from exc

    subject = claims.get("subject") or ANONYMOUS_SUBJECT
    tier = claims.get("tier", "community")
    payload = {
        "tier": tier,
        "subject": subject,
        "products": claims.get("products", []),
        "expiry_unix": claims.get("expiry_unix", 0),
    }
    request.state.license = payload
    return payload


def license_subject(request: Request) -> str:
    """Return the owning subject of the current request.

    Falls back to ANONYMOUS_SUBJECT when the license is unset (e.g. on
    the /health path or in dev anonymous mode).
    """
    lic = getattr(request.state, "license", None)
    if lic is None:
        return ANONYMOUS_SUBJECT
    return lic.get("subject") or ANONYMOUS_SUBJECT


def license_tier(request: Request) -> str:
    """Return the tier for the current request."""
    lic = getattr(request.state, "license", None)
    if lic is None:
        return "community"
    return lic.get("tier", "community")


# ---------------------------------------------------------------------------
# Basic Auth — still used for /metrics, driven by env vars.
# ---------------------------------------------------------------------------


def verify_basic_auth(request: Request) -> bool:
    """Verify HTTP Basic Auth for the /metrics endpoint."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Basic "):
        raise HTTPException(status_code=401, detail="Missing Basic Auth")
    try:
        decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
        username, password = decoded.split(":", 1)
    except Exception as exc:  # pragma: no cover — malformed header
        raise HTTPException(status_code=401, detail="Invalid Basic Auth header") from exc

    expected_user = os.environ.get("METRICS_USER", "")
    expected_pass = os.environ.get("METRICS_PASSWORD", "")
    if not expected_user or not expected_pass:
        raise HTTPException(status_code=503, detail="Metrics auth not configured")
    if username != expected_user or password != expected_pass:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return True
