"""Phase F — Layer 4 global observer routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from semvec.api.auth import license_subject, verify_license
from semvec.api.global_observer import GlobalObserver, ObserverManager
from semvec.api.schemas import (
    ObserverCreate,
    ObserverInfo,
)

observer_router = APIRouter(prefix="/v1/observer")

_NOT_FOUND = "Observer not found — call POST /v1/observer/ first"


def _get_manager() -> ObserverManager:
    raise RuntimeError("ObserverManager not injected")


def set_observer_manager(manager: ObserverManager) -> None:
    global _get_manager

    def _impl() -> ObserverManager:
        return manager

    _get_manager = _impl  # type: ignore[assignment]


def _resolve(mgr: ObserverManager, subject: str | None) -> GlobalObserver:
    obs = mgr.get_for_subject(subject)
    if obs is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return obs


@observer_router.post(
    "/",
    response_model=ObserverInfo,
    status_code=201,
    dependencies=[Depends(verify_license)],
)
def create_observer(request: Request, req: ObserverCreate):
    mgr = _get_manager()
    subject = license_subject(request)
    obs = mgr.create_observer(
        sample_interval_seconds=req.sample_interval_seconds,
        owner_subject=subject,
    )
    for rid in req.region_ids:
        obs.register_region(rid)
    return ObserverInfo(
        observer_id=obs.observer_id,
        registered_regions=len(obs.get_registered_regions()),
        meta_session_id=obs.meta_session_id,
    )


@observer_router.get("/summary", dependencies=[Depends(verify_license)])
def observer_summary(request: Request):
    subject = license_subject(request)
    return _resolve(_get_manager(), subject).get_summary()


@observer_router.post("/sample", dependencies=[Depends(verify_license)])
def observer_sample(request: Request):
    subject = license_subject(request)
    return _resolve(_get_manager(), subject).sample()


@observer_router.get("/anomalies", dependencies=[Depends(verify_license)])
def observer_anomalies(
    request: Request,
    limit: int = Query(default=20, ge=1, le=1000),
):
    subject = license_subject(request)
    obs = _resolve(_get_manager(), subject)
    return [
        {
            "anomaly_id": a.anomaly_id,
            "timestamp": a.timestamp,
            "anomaly_type": a.anomaly_type,
            "affected_cluster_ids": a.affected_cluster_ids,
            "description": a.description,
            "severity": a.severity,
        }
        for a in obs.get_anomalies(limit=limit)
    ]


@observer_router.delete("/anomalies", dependencies=[Depends(verify_license)])
def observer_clear_anomalies(request: Request):
    subject = license_subject(request)
    return {"cleared": _resolve(_get_manager(), subject).clear_anomalies()}


@observer_router.post("/regions", dependencies=[Depends(verify_license)])
def observer_register_region(request: Request, body: dict):
    subject = license_subject(request)
    region_id = body.get("region_id")
    if not region_id:
        raise HTTPException(status_code=422, detail="region_id is required")
    _resolve(_get_manager(), subject).register_region(region_id)
    return {"registered": True}


@observer_router.delete(
    "/regions/{region_id}", dependencies=[Depends(verify_license)]
)
def observer_unregister_region(region_id: str, request: Request):
    subject = license_subject(request)
    _resolve(_get_manager(), subject).unregister_region(region_id)
    return {"unregistered": True}
