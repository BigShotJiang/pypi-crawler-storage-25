"""Pydantic request/response schemas for the Semvec REST API.

Mirrors the original PSS API surface so existing clients keep working:
``/run`` → compressed context + drift, ``/store`` → learn from Q&A,
``/session/*`` → per-session create/delete/metrics/context.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Health


class HealthResponse(BaseModel):
    status: str = "ok"
    active_sessions: int = 0
    version: str = "1.0.0"


# ---------------------------------------------------------------------------
# /v1/run — single-turn run (retrieve context + optionally store previous answer)


class RunRequest(BaseModel):
    message: str = Field(..., min_length=1, description="User message")
    session_id: str | None = Field(
        default=None,
        description="Reuse an existing session. Omit to create a fresh one.",
    )
    response: str | None = Field(
        default=None,
        description="Previous LLM answer — stored inline as the previous turn's Q&A.",
    )
    short_circuit_threshold: float = Field(
        default=0.85, ge=-1.0, le=1.0,
        description="Similarity threshold for the short-circuit flag.",
    )
    reset_context: bool = Field(
        default=False,
        description="Wipe all memories and restart the session from scratch.",
    )


class RunResponse(BaseModel):
    session_id: str
    context: str = Field(
        ..., description="Compressed context block — inject as system prompt."
    )
    top_similarity: float = 0.0
    short_circuit: bool = False
    drift_score: float = 0.0
    drift_detected: bool = False
    drift_phase: Literal["stable", "shifting", "drifted"] = "stable"


# ---------------------------------------------------------------------------
# /v1/store


class StoreRequest(BaseModel):
    session_id: str
    response: str = Field(..., min_length=1)


class StoreResponse(BaseModel):
    session_id: str


# ---------------------------------------------------------------------------
# /v1/session/* — advanced per-session controls


class CreateSessionRequest(BaseModel):
    dimension: int = 384
    model_name: str = "all-MiniLM-L6-v2"
    use_meta_pss: bool = False
    enable_topic_switch: bool = True
    template_embedding: list[float] | None = None
    policy_vectors: list[dict[str, Any]] | None = None


class CreateSessionResponse(BaseModel):
    session_id: str
    created: bool = True


class SessionIdOnly(BaseModel):
    session_id: str


class MetricsResponse(BaseModel):
    session_id: str
    phase: str
    interaction_count: int
    total_memories: int
    beta_history: list[float]
    similarity_history: list[float]
    fsm_history: list[float]
    norm_history: list[float] | None = None
    phase_history: list[str]


class ContextItem(BaseModel):
    text: str
    relevance: float
    memory_hash: str = ""
    truncated: bool = True


class ContextResponse(BaseModel):
    session_id: str
    context: list[ContextItem]


class MemoryExpandResponse(BaseModel):
    session_id: str
    memory_hash: str
    text: str
    truncated: bool = False
    importance: float
    access_count: int
    timestamp: float


# ---------------------------------------------------------------------------
# Resonance Triggers


class TriggerRequest(BaseModel):
    keyword: str | None = None
    embedding: list[float] | None = None
    threshold: float = 0.8


class TriggerResponse(BaseModel):
    session_id: str
    trigger_count: int


# ---------------------------------------------------------------------------
# State Serialization


class ExportResponse(BaseModel):
    session_id: str
    state_dict: dict[str, Any]
    checksum: str


class ImportRequest(BaseModel):
    state_dict: dict[str, Any]


class ImportResponse(BaseModel):
    session_id: str
    imported: bool


class VerifyRequest(BaseModel):
    test_embeddings: list[list[float]]


class VerifyResponse(BaseModel):
    session_id: str
    consistent: bool


# ---------------------------------------------------------------------------
# Drift Anchors


class AnchorRequest(BaseModel):
    embedding: list[float]


class AnchorResponse(BaseModel):
    session_id: str
    anchor_count: int


class AnchorScoreResponse(BaseModel):
    session_id: str
    anchor_score: float
    anchor_count: int
    drift_threshold: float
    realignment_remaining: int


# ---------------------------------------------------------------------------
# Input Isolation


class IsolationRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    level: Literal["OPEN", "FILTER", "QUARANTINE", "LOCKDOWN"]
    exclusion_embeddings: list[list[float]] | None = None
    allowlist_embeddings: list[list[float]] | None = None
    similarity_threshold: float = 0.7


class IsolationResponse(BaseModel):
    session_id: str
    level: str


class IsolationReleaseResponse(BaseModel):
    session_id: str
    released_count: int


# ---------------------------------------------------------------------------
# Synthetic Memory Injection


class MemoryInjectRequest(BaseModel):
    embedding: list[float]
    text: str
    tier: Literal["short_term", "medium_term", "long_term"] = "short_term"
    importance: float = 0.5
    access_count: int = 0


class MemoryInjectResponse(BaseModel):
    session_id: str
    tier: str
    total_memories: int


# ---------------------------------------------------------------------------
# Literal cache (Phase H)


class EntityCreate(BaseModel):
    key: str
    kind: Literal[
        "variable",
        "function",
        "class",
        "path",
        "error",
        "signature",
        "constant",
        "type",
    ]
    value: str
    context: str = ""
    importance: float = 1.0


class EntityResponse(BaseModel):
    session_id: str
    key: str
    size: int


class EntityListItem(BaseModel):
    key: str
    kind: str
    value: str
    context: str | None = None
    importance: float
    access_count: int = 0


class EntityListResponse(BaseModel):
    session_id: str
    entities: list[EntityListItem]
    total: int


class EntityDeletedResponse(BaseModel):
    session_id: str
    key: str
    removed: bool


# ---------------------------------------------------------------------------
# Clusters (Phase D)


class ClusterCreate(BaseModel):
    name: str = Field(..., min_length=1)
    aggregation_mode: Literal["weighted_average", "attention"] = "weighted_average"
    coupling_factor: float = Field(default=0.0, ge=0.0, le=1.0)


class ClusterInfo(BaseModel):
    cluster_id: str
    name: str
    aggregation_mode: str
    coupling_factor: float


class ClusterListItem(BaseModel):
    cluster_id: str
    name: str
    member_count: int


class ClusterState(ClusterInfo):
    member_count: int
    phase: str
    interaction_count: int
    total_memories: int
    aggregate_vector: list[float]


class ClusterFeedbackResponse(BaseModel):
    cluster_id: str
    sessions_updated: int


class MemberRequest(BaseModel):
    session_id: str


class MemberResponse(BaseModel):
    cluster_id: str
    session_id: str
    added: bool


class MemberRemovedResponse(BaseModel):
    cluster_id: str
    session_id: str
    removed: bool


class DeletedResponse(BaseModel):
    deleted: bool


# ---------------------------------------------------------------------------
# Region + Observer (Phases E/F)


class RegionCreate(BaseModel):
    name: str = Field(..., min_length=1)
    consensus_threshold: float = 0.5
    vote_window_seconds: float = 60.0


class RegionInfo(BaseModel):
    region_id: str
    name: str
    meta_session_id: str


class RegionListItem(BaseModel):
    region_id: str
    name: str
    cluster_count: int


class RegionState(RegionInfo):
    cluster_count: int
    consensus_threshold: float
    recent_drift_events: list[dict[str, Any]]
    last_realignment: float | None


class RegionClusterRequest(BaseModel):
    cluster_id: str


class DriftEventItem(BaseModel):
    cluster_id: str
    region_id: str
    drift_score: float
    drift_phase: str
    timestamp: float


class ObserverCreate(BaseModel):
    sample_interval_seconds: float = 30.0
    region_ids: list[str] = Field(default_factory=list)


class ObserverInfo(BaseModel):
    observer_id: str
    registered_regions: int
    meta_session_id: str


class ObserverSummary(ObserverInfo):
    total_clusters_observed: int
    last_sample_at: float | None
    anomaly_count: int
    recent_anomalies: list[dict[str, Any]]


class AnomalyItem(BaseModel):
    anomaly_id: str
    timestamp: float
    anomaly_type: Literal[
        "systemic_drift", "cross_cluster_convergence", "cluster_divergence"
    ]
    affected_cluster_ids: list[str]
    description: str
    severity: float


# ---------------------------------------------------------------------------
# Network (Phase G)


class DeltaTransferRequest(BaseModel):
    source_session_id: str
    target_session_id: str
    max_weight: float = 0.15


class DeltaTransferResponse(BaseModel):
    source_session_id: str
    target_session_id: str
    delta_norm: float


class UserSwitchRequest(BaseModel):
    user_id: str


class UserSwitchResponse(BaseModel):
    active_user: str
    previous_user: str


class ActiveUserResponse(BaseModel):
    active_user: str


class UserSerializeResponse(BaseModel):
    user_id: str
    state: dict[str, Any]


class ConsensusProposalRequest(BaseModel):
    proposer_session_id: str
    target_embedding: list[float]


class ConsensusProposalResponse(BaseModel):
    accepted: bool
    trust_scores: dict[str, float]


class TrustScoresResponse(BaseModel):
    trust_scores: dict[str, float]
