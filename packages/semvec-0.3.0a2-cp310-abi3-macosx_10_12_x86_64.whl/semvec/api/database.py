"""SQLAlchemy engine/session for the Semvec REST API.

Defaults to a local SQLite file (``semvec.db``). Override with the
``DATABASE_URL`` environment variable for production Postgres.
"""

from __future__ import annotations

import os

from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session, sessionmaker

_engine: Engine | None = None
_SessionLocal: sessionmaker | None = None


def get_engine() -> Engine:
    """Return the global SQLAlchemy engine (created on first call)."""
    global _engine, _SessionLocal
    if _engine is None:
        url = os.environ.get("DATABASE_URL", "sqlite:///semvec.db")
        # asyncpg URL → sync psycopg2 for simplicity in sync FastAPI.
        if url.startswith("postgresql+asyncpg://"):
            url = url.replace("postgresql+asyncpg://", "postgresql://", 1)
        connect_args: dict[str, object] = {}
        if url.startswith("sqlite"):
            connect_args["check_same_thread"] = False
        _engine = create_engine(url, echo=False, connect_args=connect_args)
        _SessionLocal = sessionmaker(bind=_engine, autoflush=False, autocommit=False)
    return _engine


def get_db_session() -> Session:
    """Create a new database session. Caller must close() it."""
    get_engine()
    assert _SessionLocal is not None
    return _SessionLocal()


def create_tables() -> None:
    """Create all tables (idempotent)."""
    from semvec.api.models import Base

    engine = get_engine()
    Base.metadata.create_all(bind=engine)


def reset_engine() -> None:
    """Dispose the global engine (used by tests to swap DATABASE_URL)."""
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _SessionLocal = None
