"""In-memory session store for the Semvec REST API.

Each session holds its own :class:`SemvecState` and an embedder
(SentenceTransformer by default). Thread-safe via a global lock.

Advanced features (all optional, off by default):
  * MetaPSS (SemvecCortexObserver) — cross-session knowledge sharing.

Hash-based fallback embedders are **not** supported — the embedder must
be a real sentence-transformer (or equivalent). A session started
without a usable embedder raises :class:`RuntimeError` on construction.

This is the MVP scope for API Phase B. Session-Control methods
(resonance triggers, anchors, isolation, synthetic memory injection,
state export/import/verify, literal cache) are layered on in Phase C+.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
import uuid
from dataclasses import dataclass
from typing import Any

import numpy as np

from semvec import SemvecConfig, SemvecState

logger = logging.getLogger(__name__)


def _load_sentence_transformer_embedder(
    model_name: str, dimension: int
):
    """Build a SentenceTransformer-backed embedder, or None if unavailable."""
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        return None

    class _STEmbedder:
        def __init__(self) -> None:
            self._model = SentenceTransformer(model_name)
            self._dimension = dimension

        def get_dimension(self) -> int:
            return self._dimension

        def get_embedding(self, text: str) -> np.ndarray:
            if not text.strip():
                return np.zeros(self._dimension)
            v = self._model.encode(text, normalize_embeddings=True)
            return np.asarray(v, dtype=np.float64)

    return _STEmbedder()


@dataclass
class _Session:
    """Internal session holding Semvec state, embedding service, metadata."""

    pss_state: SemvecState
    embedder: Any
    config: SemvecConfig
    use_meta_pss: bool = False
    chat_proxy: Any = None
    pending_message: str | None = None
    owner_subject: str | None = None


class _SessionProxy:
    """Lightweight proxy for SemvecCortexObserver aggregation."""

    def __init__(self, session: _Session) -> None:
        self.pss_state = session.pss_state
        self.local_coherence = 0.2
        self.global_influence = 1.0
        if session.pss_state.beta_history:
            self.local_coherence = max(0.15, float(session.pss_state.beta_history[-1]))

    def get_state_vector(self) -> np.ndarray:
        return np.asarray(self.pss_state.semantic_state)


class SessionManager:
    """Thread-safe in-memory store for Semvec sessions."""

    def __init__(self) -> None:
        self._sessions: dict[str, _Session] = {}
        self._lock = threading.Lock()
        self._meta_pss: Any = None
        self._shared_embedder: Any = None
        self._embedder_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Embedder management

    def _get_shared_embedder(
        self, model_name: str = "all-MiniLM-L6-v2", dimension: int = 384
    ) -> Any:
        if self._shared_embedder is not None:
            return self._shared_embedder

        with self._embedder_lock:
            if self._shared_embedder is not None:
                return self._shared_embedder

            svc = _load_sentence_transformer_embedder(model_name, dimension)
            if svc is None:
                raise RuntimeError(
                    "No embedder available — install `sentence-transformers` "
                    "or provide a custom embedder via SessionManager.inject_embedder(). "
                    "Hash-based pseudo-embeddings are not supported; they "
                    "invalidate the PSS metrics."
                )
            self._shared_embedder = svc
            logger.info("Shared embedder: SentenceTransformer %s (%d-d)", model_name, dimension)
            return self._shared_embedder

    def inject_embedder(self, embedder: Any) -> None:
        """Swap the shared embedder (used by tests with fake embedders)."""
        with self._embedder_lock:
            self._shared_embedder = embedder

    # ------------------------------------------------------------------
    # Session lifecycle

    def create_session(
        self,
        dimension: int = 384,
        model_name: str = "all-MiniLM-L6-v2",
        use_meta_pss: bool = False,
        enable_topic_switch: bool = True,
        owner_subject: str | None = None,
        session_id: str | None = None,
        template_embedding: list[float] | None = None,
        policy_vectors: list[dict[str, Any]] | None = None,
    ) -> str:
        session_id = session_id or str(uuid.uuid4())
        env_ts = os.environ.get("SEMVEC_TOPIC_SWITCH", os.environ.get("PSS_TOPIC_SWITCH"))
        if env_ts is not None and env_ts.lower() in ("0", "false", "off"):
            enable_topic_switch = False

        config_kwargs: dict[str, Any] = dict(
            dimension=dimension,
            model_name=model_name,
            enable_topic_switch=enable_topic_switch,
        )
        if template_embedding is not None:
            arr = np.asarray(template_embedding, dtype=np.float64)
            norm = np.linalg.norm(arr)
            if norm > 1e-8:
                arr = arr / norm
            config_kwargs["template_vectors"] = [arr]
        if policy_vectors:
            from semvec._core import PolicyVector

            config_kwargs["policy_vectors"] = [
                PolicyVector(
                    embedding=np.asarray(pv["embedding"], dtype=np.float64),
                    weight=float(pv.get("weight", 1.0)),
                    promote=bool(pv.get("promote", True)),
                )
                for pv in policy_vectors
            ]

        config = SemvecConfig(**config_kwargs)
        pss_state = SemvecState(config=config)
        embedder = self._get_shared_embedder(model_name=model_name, dimension=dimension)

        if use_meta_pss and self._meta_pss is None:
            from semvec.cortex import SemvecCortexObserver

            self._meta_pss = SemvecCortexObserver(dimension=dimension)

        with self._lock:
            self._sessions[session_id] = _Session(
                pss_state=pss_state,
                embedder=embedder,
                config=config,
                use_meta_pss=use_meta_pss,
                owner_subject=owner_subject,
            )
        return session_id

    def _check_ownership(self, session: _Session, owner_subject: str | None) -> bool:
        if owner_subject is None or session.owner_subject is None:
            return True
        return session.owner_subject == owner_subject

    def reset_session(self, session_id: str, owner_subject: str | None = None) -> bool:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return False
        config = session.config
        session.pss_state = SemvecState(config=config)
        session.pending_message = None
        return True

    def delete_session(self, session_id: str, owner_subject: str | None = None) -> bool:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return False
            if not self._check_ownership(session, owner_subject):
                return False
            del self._sessions[session_id]
            return True

    def get_session(
        self, session_id: str, owner_subject: str | None = None
    ) -> _Session | None:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return None
            if not self._check_ownership(session, owner_subject):
                return None
            return session

    def get_session_vector(
        self, session_id: str, owner_subject: str | None = None
    ) -> np.ndarray | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        return np.asarray(session.pss_state.semantic_state)

    def set_session_vector(
        self,
        session_id: str,
        vector: np.ndarray,
        owner_subject: str | None = None,
    ) -> bool:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return False
        session.pss_state.semantic_state = vector.copy()
        return True

    def session_count(self) -> int:
        with self._lock:
            return len(self._sessions)

    # ------------------------------------------------------------------
    # State update + retrieval

    def update_state(
        self, session_id: str, text: str, owner_subject: str | None = None
    ) -> dict[str, Any] | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None

        embedding = np.asarray(session.embedder.get_embedding(text), dtype=np.float64)
        if embedding is None or np.linalg.norm(embedding) < 1e-8:
            return None

        if session.use_meta_pss and self._meta_pss is not None:
            gs = np.asarray(self._meta_pss.global_state)
            if np.linalg.norm(gs) > 1e-8:
                alpha = 0.1
                embedding = (1 - alpha) * embedding + alpha * gs
                n = np.linalg.norm(embedding)
                if n > 1e-8:
                    embedding = embedding / n

        metrics = session.pss_state.update(embedding, text)

        if session.use_meta_pss and self._meta_pss is not None:
            sync_result = self.sync_sessions()
            metrics["global_coherence"] = sync_result.get("global_coherence", 0.0)
            metrics["network_resonance"] = sync_result.get("network_resonance", 0.0)

        return metrics

    def store_qa(
        self,
        session_id: str,
        response: str,
        owner_subject: str | None = None,
    ) -> dict[str, Any] | None:
        """Combine pending_message + response into a Q&A chunk and store it."""
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None

        if session.pending_message:
            chunk = f"Q: {session.pending_message} A: {response}"
            session.pending_message = None
        else:
            chunk = response
        return self.update_state(session_id, chunk, owner_subject=owner_subject)

    def get_metrics(
        self, session_id: str, owner_subject: str | None = None
    ) -> dict[str, Any] | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None

        pss = session.pss_state
        # SemvecState exposes get_total_stored via the MultiResolutionMemory facade.
        total = (
            len(pss.memory.short_term)
            + len(pss.memory.medium_term)
            + len(pss.memory.long_term)
        )
        return {
            "session_id": session_id,
            "phase": pss.phase_detector.current_phase,
            "interaction_count": int(pss.interaction_count),
            "total_memories": int(total),
            "beta_history": list(pss.beta_history),
            "similarity_history": list(pss.similarity_history),
            "fsm_history": list(pss.fsm_history),
            "norm_history": list(getattr(pss, "norm_history", [])),
            "phase_history": list(pss.phase_history),
        }

    def get_context(
        self,
        session_id: str,
        top_k: int | None = None,
        owner_subject: str | None = None,
        full_first: bool = False,
    ) -> list[dict[str, Any]] | None:
        """Return the top-k relevant memories.

        Each entry carries a ``memory_hash`` (the MemoryUnit's stable
        semantic hash) so the client can later expand a single item via
        :meth:`get_memory_by_hash`. By default every ``text`` field is
        truncated to 500 chars and ``truncated=True``; when *full_first*
        is set, the first entry comes back ungutted with
        ``truncated=False``.
        """
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None

        pss = session.pss_state
        if pss.interaction_count == 0:
            return []

        if top_k is None:
            top_k = 5

        try:
            relevant = pss.memory.get_relevant_memories(
                np.asarray(pss.semantic_state), top_k=top_k
            )
            out: list[dict[str, Any]] = []
            for i, mem in enumerate(relevant):
                full = full_first and i == 0
                text = mem.text if full else mem.text[:500]
                truncated = (not full) and len(mem.text) > 500
                out.append(
                    {
                        "text": text,
                        "relevance": round(float(mem.importance), 4),
                        "memory_hash": str(getattr(mem, "semantic_hash", "") or ""),
                        "truncated": bool(truncated),
                    }
                )
            return out
        except Exception:
            logger.debug("Could not retrieve memories", exc_info=True)
            return []

    def get_memory_by_hash(
        self,
        session_id: str,
        memory_hash: str,
        owner_subject: str | None = None,
    ) -> dict[str, Any] | None:
        """Return the full MemoryUnit that matches *memory_hash*, or None.

        Walks the short / medium / long term buffers in order so the
        newest tier wins on the rare hash collision.
        """
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        mem_root = session.pss_state.memory
        for tier in (mem_root.short_term, mem_root.medium_term, mem_root.long_term):
            for mem in tier:
                if str(getattr(mem, "semantic_hash", "")) == memory_hash:
                    return {
                        "memory_hash": memory_hash,
                        "text": mem.text,
                        "importance": float(mem.importance),
                        "access_count": int(getattr(mem, "access_count", 0)),
                        "timestamp": float(getattr(mem, "timestamp", 0.0)),
                    }
        return None

    def sync_sessions(self) -> dict[str, Any]:
        if self._meta_pss is None:
            return {"global_coherence": 0.0, "network_resonance": 0.0, "total_instances": 0}

        with self._lock:
            proxies = [_SessionProxy(s) for s in self._sessions.values() if s.use_meta_pss]

        if not proxies:
            return {"global_coherence": 0.0, "network_resonance": 0.0, "total_instances": 0}

        return self._meta_pss.update_global_state(proxies)

    # ------------------------------------------------------------------
    # Convenience used by /run for short-circuit + drift

    def compute_short_circuit(
        self, session_id: str, text: str, threshold: float = 0.85
    ) -> tuple[float, bool]:
        """Return (top_similarity, short_circuit_flag) against cached memories."""
        session = self.get_session(session_id)
        if session is None:
            return 0.0, False
        pss = session.pss_state
        if pss.interaction_count == 0:
            return 0.0, False
        emb = np.asarray(session.embedder.get_embedding(text), dtype=np.float64)
        if np.linalg.norm(emb) < 1e-8:
            return 0.0, False
        try:
            relevant = pss.memory.get_relevant_memories(emb, top_k=1)
        except Exception:
            return 0.0, False
        if not relevant:
            return 0.0, False
        # Cosine against first memory embedding.
        me = np.asarray(relevant[0].embedding, dtype=np.float64)
        num = float(np.dot(me, emb))
        den = float(np.linalg.norm(me) * np.linalg.norm(emb))
        top = num / den if den > 1e-12 else 0.0
        return top, top >= threshold

    def compute_drift(self, session_id: str, text: str) -> tuple[float, bool, str]:
        """Return (drift_score, drift_detected, drift_phase) for the current input."""
        session = self.get_session(session_id)
        if session is None:
            return 0.0, False, "stable"
        pss = session.pss_state
        emb = np.asarray(session.embedder.get_embedding(text), dtype=np.float64)
        if np.linalg.norm(emb) < 1e-8:
            return 0.0, False, "stable"
        cur = np.asarray(pss.semantic_state, dtype=np.float64)
        if np.linalg.norm(cur) < 1e-8:
            return 0.0, False, "stable"
        # Drift = 1 - cosine between current state and new input.
        num = float(np.dot(cur, emb))
        den = float(np.linalg.norm(cur) * np.linalg.norm(emb))
        cos = num / den if den > 1e-12 else 0.0
        drift = max(0.0, 1.0 - (cos + 1.0) / 2.0)
        if drift >= 0.5:
            phase = "drifted"
        elif drift >= 0.3:
            phase = "shifting"
        else:
            phase = "stable"
        return drift, drift >= 0.5, phase

    def buffer_message(self, session_id: str, message: str) -> None:
        session = self.get_session(session_id)
        if session is not None:
            session.pending_message = message

    # ------------------------------------------------------------------
    # Phase C — Session Control: resonance triggers

    def add_trigger(
        self,
        session_id: str,
        keyword: str | None = None,
        embedding: list[float] | None = None,
        threshold: float = 0.8,
        owner_subject: str | None = None,
    ) -> int | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        from semvec._core import ResonanceTrigger

        # ResonanceTrigger signatures in the Rust binding accept keyword /
        # threshold kwargs; embedding is attached via a setter when given.
        kwargs: dict[str, Any] = {"threshold": float(threshold)}
        if keyword is not None:
            kwargs["keyword"] = keyword
        if embedding is not None:
            kwargs["trigger_embedding"] = np.asarray(embedding, dtype=np.float64)
        trigger = ResonanceTrigger(**kwargs)
        session.pss_state.add_resonance_trigger(trigger)
        return int(session.pss_state.resonance_trigger_count)

    def clear_triggers(
        self, session_id: str, owner_subject: str | None = None
    ) -> int | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        session.pss_state.clear_resonance_triggers()
        return 0

    # ------------------------------------------------------------------
    # Phase C — Session Control: drift anchors

    def add_anchor(
        self,
        session_id: str,
        embedding: list[float],
        owner_subject: str | None = None,
    ) -> int | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        arr = np.asarray(embedding, dtype=np.float64)
        session.pss_state.add_anchor(list(arr))
        return int(session.pss_state.anchor_count)

    def get_anchor_score(
        self, session_id: str, owner_subject: str | None = None
    ) -> dict[str, Any] | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        pss = session.pss_state
        return {
            "anchor_score": float(pss.anchor_score),
            "anchor_count": int(pss.anchor_count),
            "drift_threshold": float(pss.drift_threshold),
            "realignment_remaining": int(pss.realignment_remaining),
        }

    # ------------------------------------------------------------------
    # Phase C — Session Control: input isolation

    def set_isolation(
        self,
        session_id: str,
        level: str,
        exclusion_embeddings: list[list[float]] | None = None,
        allowlist_embeddings: list[list[float]] | None = None,
        similarity_threshold: float = 0.7,
        owner_subject: str | None = None,
    ) -> bool:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return False
        from semvec._core import InputIsolationFilter

        iso = InputIsolationFilter(level=level.lower(), exclusion_threshold=float(similarity_threshold))
        for emb in exclusion_embeddings or []:
            iso.add_exclusion_criterion(list(np.asarray(emb, dtype=np.float64)))
        for emb in allowlist_embeddings or []:
            iso.add_allowlist(list(np.asarray(emb, dtype=np.float64)))
        session.pss_state.set_isolation_filter(iso)
        return True

    def release_quarantine(
        self, session_id: str, owner_subject: str | None = None
    ) -> int | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        return int(session.pss_state.release_quarantine_count())

    # ------------------------------------------------------------------
    # Phase C — Session Control: synthetic memory injection

    def inject_memory(
        self,
        session_id: str,
        embedding: list[float],
        text: str,
        tier: str = "short_term",
        importance: float = 0.5,
        access_count: int = 0,
        owner_subject: str | None = None,
    ) -> int | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        arr = np.asarray(embedding, dtype=np.float64)
        n = np.linalg.norm(arr)
        if n > 1e-8:
            arr = arr / n
        session.pss_state.inject_memory(
            embedding=list(arr),
            text=text,
            tier=tier,
            importance=float(importance),
            access_count=int(access_count),
        )
        pss = session.pss_state
        total = (
            len(pss.memory.short_term)
            + len(pss.memory.medium_term)
            + len(pss.memory.long_term)
        )
        return int(total)

    # ------------------------------------------------------------------
    # Phase C — Session Control: export / import / verify

    def export_state(
        self, session_id: str, owner_subject: str | None = None
    ) -> dict[str, Any] | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        state_dict = session.pss_state.to_dict()
        checksum = str(state_dict.get("checksum", ""))
        if not checksum:
            # Compute a fallback checksum over the semantic vector + hist so
            # clients can at least detect tampering across the wire even when
            # the Rust core didn't embed one.
            data = np.asarray(session.pss_state.semantic_state).tobytes()
            checksum = hashlib.sha256(data).hexdigest()
            state_dict = dict(state_dict)
            state_dict["checksum"] = checksum
        return {
            "session_id": session_id,
            "state_dict": state_dict,
            "checksum": checksum,
        }

    def import_state(
        self,
        session_id: str,
        state_dict: dict[str, Any],
        owner_subject: str | None = None,
    ) -> bool:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return False
        # Minimal shape validation — reject dicts that don't look like an
        # exported SemvecState. `semantic_state` is the load-bearing vector;
        # anything else is optional on the Rust side and will silently
        # default, which would mask tampered payloads.
        if not isinstance(state_dict, dict) or "semantic_state" not in state_dict:
            return False
        try:
            restored = SemvecState.from_dict(state_dict)
        except Exception:
            return False
        session.pss_state = restored
        return True

    # ------------------------------------------------------------------
    # Phase H — Literal cache (verbatim code-entity memory tier)

    def store_entity(
        self,
        session_id: str,
        key: str,
        kind: str,
        value: str,
        context: str = "",
        importance: float = 1.0,
        owner_subject: str | None = None,
    ) -> int | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        from semvec._core import CodeEntity
        from semvec.literal_cache import EntityKind

        kind_map = {
            "variable": EntityKind.VARIABLE,
            "function": EntityKind.FUNCTION,
            "class": EntityKind.CLASS,
            "path": EntityKind.PATH,
            "error": EntityKind.ERROR,
            "signature": EntityKind.SIGNATURE,
            "constant": EntityKind.CONSTANT,
            "type": EntityKind.TYPE,
        }
        try:
            entity_kind = kind_map[kind]
        except KeyError as exc:
            raise ValueError(f"unknown entity kind: {kind!r}") from exc

        entity = CodeEntity(key, entity_kind, value, context, float(importance))
        session.pss_state.literal_cache.store(entity)
        return int(session.pss_state.literal_cache.size)

    def query_entities(
        self,
        session_id: str,
        query_text: str = "",
        max_results: int = 20,
        owner_subject: str | None = None,
    ) -> list[dict[str, Any]] | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        cache = session.pss_state.literal_cache
        if query_text:
            entities = cache.query(query_text, max_results=max_results)
        else:
            entities = cache.all_entities[:max_results]
        return [
            {
                "key": e.key,
                "kind": (
                    e.kind.name.lower()
                    if hasattr(e.kind, "name")
                    else str(e.kind).lower()
                ),
                "value": e.value,
                "context": getattr(e, "context", "") or "",
                "importance": float(getattr(e, "importance", 1.0)),
                "access_count": int(getattr(e, "access_count", 0)),
            }
            for e in entities
        ]

    def remove_entity(
        self,
        session_id: str,
        key: str,
        owner_subject: str | None = None,
    ) -> bool | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        return bool(session.pss_state.literal_cache.remove(key))

    def get_entity_count(
        self, session_id: str, owner_subject: str | None = None
    ) -> int | None:
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        return int(session.pss_state.literal_cache.size)

    def verify_consistency(
        self,
        session_id: str,
        test_embeddings: list[list[float]],
        owner_subject: str | None = None,
        reference_session_id: str | None = None,
        tolerance: float = 1e-3,
    ) -> bool | None:
        """Python-level port of pss.core.verify_behavioral_consistency.

        Runs the given embeddings through the current session; compares
        the resulting similarity history against a reference session
        (defaults to the same session, which trivially returns True).
        """
        session = self.get_session(session_id, owner_subject=owner_subject)
        if session is None:
            return None
        ref_sid = reference_session_id or session_id
        reference = self.get_session(ref_sid, owner_subject=owner_subject)
        if reference is None:
            return None
        if not test_embeddings:
            return True

        def _run_similarities(state: SemvecState, embs: list[list[float]]) -> list[float]:
            sims: list[float] = []
            cur = np.asarray(state.semantic_state, dtype=np.float64)
            for e in embs:
                arr = np.asarray(e, dtype=np.float64)
                num = float(np.dot(cur, arr))
                den = float(np.linalg.norm(cur) * np.linalg.norm(arr))
                sims.append(num / den if den > 1e-12 else 0.0)
            return sims

        left = _run_similarities(session.pss_state, test_embeddings)
        right = _run_similarities(reference.pss_state, test_embeddings)
        return all(abs(a - b) <= tolerance for a, b in zip(left, right, strict=True))

    def context_block(
        self,
        session_id: str,
        query_text: str,
        top_k: int = 5,
    ) -> str:
        """Render a compact context block for ``/run``.

        Falls back to a turn-0 header when the session has no memories.
        """
        session = self.get_session(session_id)
        if session is None:
            return ""
        pss = session.pss_state
        hdr = f"[Semvec Context | Turn {pss.interaction_count} | "
        if pss.interaction_count == 0:
            return hdr + "0 memories]"
        emb = np.asarray(session.embedder.get_embedding(query_text), dtype=np.float64)
        try:
            relevant = pss.memory.get_relevant_memories(emb, top_k=top_k) if np.linalg.norm(emb) > 1e-8 else []
        except Exception:
            relevant = []
        lines = [hdr + f"{len(relevant)} memories]", "Relevant context:"]
        for i, mem in enumerate(relevant, start=1):
            t = mem.text.replace("\n", " ")[:150]
            lines.append(f"  {i}. [{float(mem.importance):.2f}] {t}")
        return "\n".join(lines)
