"""Prometheus metrics export for the Semvec REST API.

A custom ``CollectorRegistry`` isolates the metrics from any globally
registered prometheus clients (avoids clashes in test runners that
import the module multiple times).
"""

from __future__ import annotations

import time
from collections.abc import Callable

from fastapi import FastAPI, Request, Response
from prometheus_client import (
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)

REGISTRY = CollectorRegistry()

semvec_requests_total = Counter(
    "semvec_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status"],
    registry=REGISTRY,
)

semvec_request_duration_seconds = Histogram(
    "semvec_request_duration_seconds",
    "Request duration in seconds",
    ["method", "endpoint"],
    registry=REGISTRY,
)

semvec_active_sessions = Gauge(
    "semvec_active_sessions",
    "Number of active Semvec sessions",
    registry=REGISTRY,
)


def setup_metrics(app: FastAPI) -> None:
    """Attach the request-counter + duration-histogram middleware."""

    @app.middleware("http")
    async def metrics_middleware(
        request: Request, call_next: Callable
    ) -> Response:
        if request.url.path == "/metrics":
            return await call_next(request)

        start = time.perf_counter()
        response = await call_next(request)
        duration = time.perf_counter() - start

        endpoint = request.url.path
        method = request.method
        status = str(response.status_code)

        semvec_requests_total.labels(
            method=method, endpoint=endpoint, status=status
        ).inc()
        semvec_request_duration_seconds.labels(
            method=method, endpoint=endpoint
        ).observe(duration)
        return response


def get_metrics_response() -> Response:
    data = generate_latest(REGISTRY)
    return Response(
        content=data,
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )
