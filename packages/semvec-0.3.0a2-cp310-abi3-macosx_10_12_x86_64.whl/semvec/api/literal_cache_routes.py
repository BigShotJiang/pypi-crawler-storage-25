"""Phase H — Literal cache (verbatim code-entity memory) routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from semvec.api.auth import license_subject, verify_license
from semvec.api.schemas import (
    EntityCreate,
    EntityDeletedResponse,
    EntityListItem,
    EntityListResponse,
    EntityResponse,
)
from semvec.api.session_manager import SessionManager

literal_router = APIRouter(prefix="/v1")

_NOT_FOUND = "Session not found"
_ENTITY_NOT_FOUND = "Entity not found"


def _get_manager() -> SessionManager:
    raise RuntimeError("SessionManager not injected")


def set_literal_session_manager(manager: SessionManager) -> None:
    global _get_manager

    def _impl() -> SessionManager:
        return manager

    _get_manager = _impl  # type: ignore[assignment]


@literal_router.post(
    "/session/{session_id}/entities",
    response_model=EntityResponse,
    status_code=201,
    dependencies=[Depends(verify_license)],
)
def store_entity(session_id: str, request: Request, body: EntityCreate):
    mgr = _get_manager()
    subject = license_subject(request)
    try:
        size = mgr.store_entity(
            session_id=session_id,
            key=body.key,
            kind=body.kind,
            value=body.value,
            context=body.context,
            importance=body.importance,
            owner_subject=subject,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if size is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return EntityResponse(session_id=session_id, key=body.key, size=size)


@literal_router.get(
    "/session/{session_id}/entities",
    response_model=EntityListResponse,
    dependencies=[Depends(verify_license)],
)
def query_entities(
    session_id: str,
    request: Request,
    q: str = Query(default=""),
    max_results: int = Query(default=20, ge=1, le=1000),
):
    mgr = _get_manager()
    subject = license_subject(request)
    total = mgr.get_entity_count(session_id=session_id, owner_subject=subject)
    if total is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)

    entity_dicts = mgr.query_entities(
        session_id=session_id,
        query_text=q,
        max_results=max_results,
        owner_subject=subject,
    ) or []
    return EntityListResponse(
        session_id=session_id,
        entities=[EntityListItem(**e) for e in entity_dicts],
        total=total,
    )


@literal_router.delete(
    "/session/{session_id}/entities/{key:path}",
    response_model=EntityDeletedResponse,
    dependencies=[Depends(verify_license)],
)
def remove_entity(session_id: str, key: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    removed = mgr.remove_entity(
        session_id=session_id, key=key, owner_subject=subject
    )
    if removed is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    if not removed:
        raise HTTPException(status_code=404, detail=_ENTITY_NOT_FOUND)
    return EntityDeletedResponse(session_id=session_id, key=key, removed=True)
