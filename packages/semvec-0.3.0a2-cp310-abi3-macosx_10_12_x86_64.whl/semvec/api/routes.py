"""Phase-B routes — health, run, store, session CRUD, metrics, context."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from slowapi import Limiter
from slowapi.util import get_remote_address

from semvec.api.auth import (
    get_client_ip,
    license_subject,
    license_tier,
    verify_license,
)
from semvec.api.schemas import (
    ContextItem,
    ContextResponse,
    CreateSessionRequest,
    CreateSessionResponse,
    HealthResponse,
    MemoryExpandResponse,
    MetricsResponse,
    RunRequest,
    RunResponse,
    SessionIdOnly,
    StoreRequest,
    StoreResponse,
)
from semvec.api.session_manager import SessionManager

logger = logging.getLogger(__name__)

SEMVEC_API_VERSION = "1.0.0"

router = APIRouter(prefix="/v1")

limiter = Limiter(key_func=get_remote_address)


def _get_manager() -> SessionManager:
    raise RuntimeError("SessionManager not injected — call set_session_manager() in app.py")


def set_session_manager(manager: SessionManager) -> None:
    global _get_manager

    def _get_manager_impl() -> SessionManager:
        return manager

    _get_manager = _get_manager_impl  # type: ignore[assignment]


# Optional Layer 2/3 publish hook set by app.py.
_cluster_manager = None
_regional_manager = None


def set_layer3_managers(cluster_mgr: Any, regional_mgr: Any) -> None:
    global _cluster_manager, _regional_manager
    _cluster_manager = cluster_mgr
    _regional_manager = regional_mgr


def _publish_drift_event(session_id: str, drift_score: float, drift_phase: str) -> None:
    if _cluster_manager is None or _regional_manager is None:
        return
    cluster_id = _cluster_manager.get_cluster_for_session(session_id)
    if cluster_id is None:
        return
    region_id = _regional_manager.get_region_for_cluster(cluster_id)
    if region_id is None:
        return
    _regional_manager.publish_drift(cluster_id, region_id, drift_score, drift_phase)


# ---------------------------------------------------------------------------
# Health (no auth)


@router.get("/health", response_model=HealthResponse)
def health():
    mgr = _get_manager()
    return HealthResponse(
        status="ok",
        active_sessions=mgr.session_count(),
        version=SEMVEC_API_VERSION,
    )


# ---------------------------------------------------------------------------
# /run — retrieve compressed context + optionally store previous turn


@router.post("/run", response_model=RunResponse, dependencies=[Depends(verify_license)])
def run(request: Request, req: RunRequest):
    mgr = _get_manager()
    subject = license_subject(request)

    session_id = req.session_id
    if session_id is None:
        session_id = mgr.create_session(owner_subject=subject)
    elif req.reset_context:
        if mgr.get_session(session_id, owner_subject=subject) is None:
            session_id = mgr.create_session(session_id=session_id, owner_subject=subject)
        else:
            mgr.reset_session(session_id, owner_subject=subject)
    elif mgr.get_session(session_id, owner_subject=subject) is None:
        raise HTTPException(status_code=404, detail="Session not found")

    # Inline-store the previous LLM response if provided.
    if req.response:
        mgr.store_qa(session_id, req.response, owner_subject=subject)

    # Compute short-circuit + drift BEFORE buffering the new message.
    top_sim, short_circuit = mgr.compute_short_circuit(
        session_id, req.message, threshold=req.short_circuit_threshold
    )
    drift_score, drift_detected, drift_phase = mgr.compute_drift(session_id, req.message)

    mgr.buffer_message(session_id, req.message)
    context = mgr.context_block(session_id, req.message, top_k=5)

    if drift_detected:
        _publish_drift_event(session_id, drift_score, drift_phase)

    return RunResponse(
        session_id=session_id,
        context=context,
        top_similarity=float(top_sim),
        short_circuit=bool(short_circuit),
        drift_score=float(drift_score),
        drift_detected=bool(drift_detected),
        drift_phase=drift_phase,  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------------
# /store — learn from the LLM answer


@router.post("/store", response_model=StoreResponse, dependencies=[Depends(verify_license)])
def store(request: Request, req: StoreRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    result = mgr.store_qa(req.session_id, req.response, owner_subject=subject)
    if result is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return StoreResponse(session_id=req.session_id)


# ---------------------------------------------------------------------------
# /session/* — CRUD


@router.post(
    "/session/create",
    response_model=CreateSessionResponse,
    dependencies=[Depends(verify_license)],
)
def create_session(request: Request, req: CreateSessionRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    session_id = mgr.create_session(
        dimension=req.dimension,
        model_name=req.model_name,
        use_meta_pss=req.use_meta_pss,
        enable_topic_switch=req.enable_topic_switch,
        owner_subject=subject,
        template_embedding=req.template_embedding,
        policy_vectors=req.policy_vectors,
    )
    return CreateSessionResponse(session_id=session_id, created=True)


@router.delete(
    "/session/{session_id}",
    response_model=SessionIdOnly,
    dependencies=[Depends(verify_license)],
)
def delete_session(session_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    ok = mgr.delete_session(session_id, owner_subject=subject)
    if not ok:
        raise HTTPException(status_code=404, detail="Session not found")
    return SessionIdOnly(session_id=session_id)


@router.get(
    "/metrics/{session_id}",
    response_model=MetricsResponse,
    dependencies=[Depends(verify_license)],
)
@router.get(
    "/state/metrics",
    response_model=MetricsResponse,
    dependencies=[Depends(verify_license)],
)
def session_metrics(
    request: Request,
    session_id: str | None = None,
    query_session_id: str | None = Query(default=None, alias="session_id"),
):
    mgr = _get_manager()
    subject = license_subject(request)
    sid = session_id or query_session_id
    if sid is None:
        raise HTTPException(status_code=422, detail="Missing session_id")
    m = mgr.get_metrics(sid, owner_subject=subject)
    if m is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return MetricsResponse(**m)


@router.get(
    "/state/context",
    response_model=ContextResponse,
    dependencies=[Depends(verify_license)],
)
def session_context(
    request: Request,
    session_id: str = Query(...),
    top_k: int = Query(default=5, ge=1, le=50),
    full_first: bool = Query(
        default=False,
        description=(
            "When true, the first memory is returned ungutted (truncated=False) "
            "so the caller can read the top hit in full without a follow-up /memories/{hash} expand."
        ),
    ),
):
    mgr = _get_manager()
    subject = license_subject(request)
    items = mgr.get_context(
        session_id,
        top_k=top_k,
        owner_subject=subject,
        full_first=full_first,
    )
    if items is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return ContextResponse(
        session_id=session_id,
        context=[ContextItem(**i) for i in items],
    )


@router.get(
    "/session/{session_id}/memories/{memory_hash}",
    response_model=MemoryExpandResponse,
    dependencies=[Depends(verify_license)],
)
def expand_memory(session_id: str, memory_hash: str, request: Request):
    """Return the full text + metadata of a single memory.

    Paired with ``/v1/state/context``: the context endpoint returns
    each item's ``memory_hash``; the client drills into individual
    memories here when it needs the full text beyond the 500-char
    default truncation.
    """
    mgr = _get_manager()
    subject = license_subject(request)
    # Existence probe: if the session itself is missing, 404 for that
    # first so clients can distinguish "bad session" from "bad hash".
    if mgr.get_session(session_id, owner_subject=subject) is None:
        raise HTTPException(status_code=404, detail="Session not found")
    mem = mgr.get_memory_by_hash(
        session_id, memory_hash, owner_subject=subject
    )
    if mem is None:
        raise HTTPException(status_code=404, detail="Memory not found")
    return MemoryExpandResponse(
        session_id=session_id,
        memory_hash=mem["memory_hash"],
        text=mem["text"],
        truncated=False,
        importance=mem["importance"],
        access_count=mem["access_count"],
        timestamp=mem["timestamp"],
    )
