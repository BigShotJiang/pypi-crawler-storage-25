"""Semvec REST API — framework-agnostic HTTP access to the Rust core.

The API is auth-gated by the bundled Ed25519 JWT licensing system.
Clients send their license JWT via ``Authorization: Bearer <jwt>`` or
``X-API-Key: <jwt>``; the server verifies the signature, extracts the
tier (community/pro/enterprise), and enforces rate limits accordingly.

A SQLite database (``DATABASE_URL``, default ``sqlite:///semvec.db``)
stores session/cluster/member/audit metadata — no password store, no
separate API-key table. The license JWT is the single source of truth.

Start with::

    semvec serve --host 0.0.0.0 --port 8080

or programmatically::

    from semvec.api import create_app
    app = create_app()
"""

from __future__ import annotations

from semvec.api.app import create_app

__all__ = ["create_app"]
