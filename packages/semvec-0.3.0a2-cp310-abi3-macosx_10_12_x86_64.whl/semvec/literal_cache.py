"""Literal cache (Rust-backed) plus Python-side EntityKind enum.

The Rust extension stores entity kind as a string. On the Python side
we expose the usual Enum so existing `EntityKind.VARIABLE` usage keeps
working — the enum subclasses :class:`str` so equality with the raw
string returned by the Rust getter is transparent.
"""

from __future__ import annotations

from enum import Enum

from semvec._core import CodeEntity, LiteralCache


class EntityKind(str, Enum):
    """Category of a stored code entity."""

    VARIABLE = "variable"
    FUNCTION = "function"
    CLASS = "class"
    PATH = "path"
    ERROR = "error"
    SIGNATURE = "signature"
    CONSTANT = "constant"
    TYPE = "type"
    IMPORT = "import"
    TEST_RESULT = "test_result"
    ERROR_PATTERN = "error_pattern"
    DECISION = "decision"
    INVARIANT = "invariant"
    OTHER = "other"


__all__ = ["CodeEntity", "EntityKind", "LiteralCache"]
