"""Semvec Cortex — multi-agent coordination layer.

Public classes (PEP-8 compliant):

- ``SemvecAgentNetwork`` — orchestrator for a collection of agents
- ``SemvecAgent`` — per-agent local state (wraps a compiled ``SemvecState``)
- ``SemvecCortexObserver`` — hierarchical-resonance aggregator
- ``SemvecCortexService`` — cortex-as-a-service facade
- ``WeightedAverageAggregation``, ``AttentionAggregation`` — aggregation strategies
- ``ConsensusEngine``, ``ConsensusProposal`` — voting engine
- ``ConsensusLevel``, ``TransferType`` — string enums
- ``StateVectorPacket`` — SHA-256/16 checksummed transfer packet

Legacy aliases (``PSSNetwork``, ``LocalPSSInstance``, ``MetaPSSInstance``,
``MetaPSSService``) remain importable with a ``DeprecationWarning``.
Scheduled for removal in semvec 0.2.0.
"""

from __future__ import annotations

import warnings as _warnings
from enum import Enum
from typing import Any as _Any

from semvec._core import (
    AttentionAggregation,
    ConsensusEngine,
    ConsensusProposal,
    SemvecAgent,
    SemvecAgentNetwork,
    SemvecCortexObserver,
    StateVectorPacket,
    WeightedAverageAggregation,
)
from semvec.cortex.service import SemvecCortexService


class TransferType(str, Enum):
    FULL_STATE = "full_state"
    PARTIAL_STATE = "partial_state"
    SEMANTIC_DELTA = "semantic_delta"
    MEMORY_FRAGMENT = "memory_fragment"
    COHERENCE_FIELD = "coherence_field"


class ConsensusLevel(str, Enum):
    SIMPLE_MAJORITY = "simple_majority"
    QUALIFIED_MAJORITY = "qualified_majority"
    UNANIMOUS = "unanimous"
    WEIGHTED_VOTE = "weighted_vote"
    ADAPTIVE_THRESHOLD = "adaptive_threshold"


# Compat alias kept from the pre-rename surface (NOT pss-prefixed, so
# no DeprecationWarning — it just points at the canonical strategy).
AggregationStrategy = WeightedAverageAggregation


__all__ = [
    "AggregationStrategy",
    "AttentionAggregation",
    "ConsensusEngine",
    "ConsensusLevel",
    "ConsensusProposal",
    "SemvecAgent",
    "SemvecAgentNetwork",
    "SemvecCortexObserver",
    "SemvecCortexService",
    "StateVectorPacket",
    "TransferType",
    "WeightedAverageAggregation",
]


# ---------------------------------------------------------------------------
# Deprecated aliases — emit a DeprecationWarning on access, resolve to the
# current PEP-8 names. Scheduled for removal in 0.2.0.

_DEPRECATED_ALIASES: dict[str, tuple[str, _Any]] = {
    "PSSNetwork": ("SemvecAgentNetwork", SemvecAgentNetwork),
    "LocalPSSInstance": ("SemvecAgent", SemvecAgent),
    "MetaPSSInstance": ("SemvecCortexObserver", SemvecCortexObserver),
    "MetaPSSService": ("SemvecCortexService", SemvecCortexService),
}


def __getattr__(name: str) -> _Any:
    alias = _DEPRECATED_ALIASES.get(name)
    if alias is not None:
        replacement_name, obj = alias
        _warnings.warn(
            f"{name} is deprecated and will be removed in semvec 0.2.0. "
            f"Use {replacement_name} instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return obj
    raise AttributeError(f"module 'semvec.cortex' has no attribute {name!r}")
