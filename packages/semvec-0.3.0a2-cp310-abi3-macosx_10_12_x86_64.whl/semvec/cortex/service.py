"""SemvecCortexService — cortex-as-a-service facade.

Port of ``pss.integrations.meta_pss_service.MetaPSSService`` covering the
multi-agent coordination surface used by higher-level applications
(previously versino-brain). Responsibilities:

* Register named agents (1 per task / tenant) and feed input texts to
  their individual :class:`SemvecState` instances.
* Aggregate local states into a global state via the attention-based or
  weighted-average strategy, then expose global coherence + network
  resonance as a feedback signal.
* Optionally pull active states from a persistence store conforming to
  the :class:`_StateStore` protocol (one async method,
  ``list_active_states() -> Iterable[tuple[str, SemvecState]]``).

The store parameter is duck-typed on purpose so callers can plug any
backend — Postgres, Redis, in-memory fake — without semvec needing a
runtime dependency on a specific driver. When ``pss_store`` is ``None``,
the service runs fully in-memory: callers drive agents directly via
``register_agent()`` + ``process_input()`` (or
``network.process_input_embedding()``), and ``update_global_state()``
aggregates whatever is already in the in-memory cache.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

import numpy as np

from semvec._core import (
    AttentionAggregation,
    SemvecAgent,
    SemvecAgentNetwork,
    SemvecCortexObserver,
    WeightedAverageAggregation,
)

if TYPE_CHECKING:
    from semvec import SemvecState

DEFAULT_DIMENSION = 384


@runtime_checkable
class _StateStore(Protocol):
    """Duck-typed persistence store.

    Implementations must expose a single async method returning an
    iterable of ``(agent_id, pss_state)`` pairs.
    """

    async def list_active_states(self) -> Any: ...


class SemvecCortexService:
    """Cortex-as-a-service facade.

    Args:
        pss_store: Optional async store yielding ``(agent_id, SemvecState)``
            pairs via ``list_active_states()``. If ``None``, the service
            works in-memory via :attr:`network`.
        aggregation: Either ``"attention"`` (AttentionAggregation, default)
            or ``"weighted"`` (WeightedAverageAggregation). Any other value
            raises :class:`ValueError`.
        dimension: Embedding dimension shared by every agent state and the
            aggregator. Defaults to 384 (MiniLM-L6-v2).
    """

    def __init__(
        self,
        pss_store: _StateStore | None = None,
        aggregation: str = "attention",
        dimension: int = DEFAULT_DIMENSION,
    ) -> None:
        self.pss_store = pss_store
        self.dimension = int(dimension)

        if aggregation == "attention":
            strategy: Any = AttentionAggregation(
                attention_dim=self.dimension, dimension=self.dimension
            )
        elif aggregation == "weighted":
            strategy = WeightedAverageAggregation(dimension=self.dimension)
        else:
            raise ValueError(
                f"Unknown aggregation strategy: {aggregation!r}. "
                "Expected 'attention' or 'weighted'."
            )

        self.meta_pss: SemvecCortexObserver = SemvecCortexObserver(
            strategy, dimension=self.dimension
        )
        self._local_cache: dict[str, SemvecAgent] = {}
        # In-memory coordination network for the store-less path.
        self.network: SemvecAgentNetwork = SemvecAgentNetwork(
            aggregation_strategy=strategy,
            enable_feedback=True,
            feedback_strength=0.3,
            max_instances=100,
            dimension=self.dimension,
        )

    # ------------------------------------------------------------------
    # Lifecycle

    def register_agent(self, agent_id: str) -> bool:
        """Register a new agent on the in-memory network.

        Returns ``True`` if the agent was added, ``False`` if ``agent_id``
        was already known.
        """
        return bool(self.network.add_local_instance(agent_id))

    def process_input(self, agent_id: str, text: str) -> dict[str, Any]:
        """Drive one turn of the named agent's local state (in-memory path)."""
        return self.network.process_input(agent_id, text)

    # ------------------------------------------------------------------
    # Global state

    async def update_global_state(self) -> dict[str, Any]:
        """Aggregate all active agents into a global state.

        Returns the dict produced by
        :meth:`SemvecCortexObserver.update_global_state`, which carries
        ``global_state`` / ``global_coherence`` / ``network_resonance``
        / ``active_instances`` keys.
        """
        local_instances: list[SemvecAgent]
        if self.pss_store is not None:
            active = await self.pss_store.list_active_states()
            local_instances = []
            for agent_id, pss_state in active:
                agent = SemvecAgent(agent_id)
                agent.pss_state = pss_state  # setter added in Path-C port
                agent.local_coherence = self._calculate_coherence(pss_state)
                agent.global_influence = self._calculate_influence(pss_state)
                local_instances.append(agent)
                self._local_cache[agent_id] = agent
        else:
            local_instances = list(self._local_cache.values())
            # Also pull any agents registered via `register_agent()` that
            # haven't been cached yet — the in-memory network owns them.
            net_state = self.network.get_network_state()
            instance_states = net_state.get("instance_states", {}) or {}
            for agent_id in instance_states:
                if agent_id in self._local_cache:
                    continue
                # SemvecAgentNetwork does not expose its SemvecAgent list
                # directly; we skip unknown agents here — callers that need
                # store-less aggregation should drive process_input() via
                # this service, which we cache below when extended.

        return self.meta_pss.update_global_state(local_instances)

    async def get_global_context(self) -> str:
        """Return a human-readable global-context summary for system prompts."""
        result = await self.update_global_state()
        return (
            f"Global Coherence: {result['global_coherence']:.2f}, "
            f"Network Resonance: {result['network_resonance']:.2f}, "
            f"Active Agents: {result['active_instances']}"
        )

    # ------------------------------------------------------------------
    # Feedback + metrics

    def get_feedback_for_agent(self, agent_id: str) -> np.ndarray:
        """Return the global feedback vector for a specific agent.

        Agents use this signal to align their local state with the network
        consensus. Shape: ``(dimension,)``.
        """
        fb = self.meta_pss.get_feedback_for_instance(agent_id)
        return np.asarray(fb, dtype=np.float64)

    def _calculate_coherence(self, state: "SemvecState") -> float:
        """Coherence metric for one agent state — 1:1 port of MetaPSSService._calculate_coherence."""
        if state.interaction_count == 0:
            return 0.0

        norm = float(np.linalg.norm(np.asarray(state.semantic_state)))
        stability = min(state.interaction_count / 20.0, 1.0)

        sim_hist = state.similarity_history
        if sim_hist:
            recent = list(sim_hist)[-5:]
            recent_sim = float(np.mean(recent))
        else:
            recent_sim = 0.0

        coherence = recent_sim * 0.5 + stability * 0.3 + min(norm, 1.0) * 0.2
        return float(np.clip(coherence, 0.0, 1.0))

    def _calculate_influence(self, state: "SemvecState") -> float:
        """Influence metric — how much this state contributes to the global state."""
        coherence = self._calculate_coherence(state)
        experience = min(state.interaction_count / 50.0, 1.0)
        return float(np.clip(coherence * (0.6 + 0.4 * experience), 0.0, 1.0))


__all__ = ["SemvecCortexService", "DEFAULT_DIMENSION"]
