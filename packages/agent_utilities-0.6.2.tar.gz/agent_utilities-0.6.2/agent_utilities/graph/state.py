#!/usr/bin/python
"""Graph State Module.

This module defines the core data structures for managing the state and
dependencies of the agent graph orchestrator. It includes GraphDeps for
runtime configuration and GraphState for tracking queries, plans,
execution results, and usage statistics across the agent lifecycle.
"""

from __future__ import annotations

import asyncio
import contextvars
import logging
import os
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from pydantic_ai import Agent

if TYPE_CHECKING:
    from ..knowledge_graph.engine import RegistryGraphEngine
    from ..models import ModelRegistry
    from .models import Policy, ProcessFlow

from agent_utilities.core.config import (
    DEFAULT_GRAPH_AGENT_MODEL,
    DEFAULT_GRAPH_ROUTER_TIMEOUT,
    DEFAULT_GRAPH_VERIFIER_TIMEOUT,
    DEFAULT_LLM_API_KEY,
    DEFAULT_LLM_BASE_URL,
    DEFAULT_PROVIDER,
    DEFAULT_ROUTER_MODEL,
    DEFAULT_SSL_VERIFY,
    TOOL_GUARD_MODE,
)

from ..models import (
    ExecutionBudget,
    GraphPlan,
    ParallelBatch,
    ProgressLog,
    SprintContract,
    Tasks,
    UsageStatistics,
    WideSearchWorkboard,
)

logger = logging.getLogger(__name__)

# Callback type for bridging graph plan state to ACP.
# Accepts (event_type, plan_entries_as_dicts) and runs async.
PlanSyncCallback = Callable[
    [str, list[dict[str, Any]]],
    Coroutine[Any, Any, None],
]


# Per-request model override id, populated by the FastAPI middleware in
# :mod:`agent_utilities.server` from the ``x-agent-model-id`` header.
# Using a ContextVar lets downstream code (including the ACP adapter's
# ``run_graph_flow`` closure, which has no direct request access) read the
# value without a thread-through kwarg. ``run_graph`` / ``run_graph_stream``
# also fall back to this when ``requested_model_id`` is not passed
# explicitly.
REQUESTED_MODEL_ID_CTX: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "agent_utilities.requested_model_id", default=None
)


@dataclass
class GraphDeps:
    """Runtime dependencies and configuration for graph execution.

    This container is passed to every node in the graph, providing
    access to shared resources like MCP toolsets, model configurations,
    and event queues.
    """

    tag_prompts: dict[str, str]
    tag_env_vars: dict[str, str]
    mcp_toolsets: list[Any]
    nodes: dict[str, Any] = field(default_factory=dict)
    """Registry of graph nodes (Steps) for explicit transitions.
    Typed as Any to avoid circular dependencies with Step."""
    mcp_url: str = ""
    mcp_config: str = ""
    router_model: Any | None = DEFAULT_ROUTER_MODEL
    agent_model: Any | None = DEFAULT_GRAPH_AGENT_MODEL
    min_confidence: float = 0.6
    sub_agents: dict[str, str | Agent] = field(default_factory=dict)
    provider: str | None = DEFAULT_PROVIDER
    base_url: str | None = DEFAULT_LLM_BASE_URL
    api_key: str | None = DEFAULT_LLM_API_KEY
    ssl_verify: bool = DEFAULT_SSL_VERIFY
    event_queue: asyncio.Queue[Any] | None = None
    request_id: str = ""
    routing_strategy: str = "hybrid"
    enable_llm_validation: bool = False
    router_timeout: float = DEFAULT_GRAPH_ROUTER_TIMEOUT
    verifier_timeout: float = DEFAULT_GRAPH_VERIFIER_TIMEOUT
    project_root: str = ""
    max_parallel_agents: int = 3
    auto_approve_plan: bool = False
    auto_approve_tasks: bool = False
    approval_timeout: float = 0.0
    tool_guard_mode: str = TOOL_GUARD_MODE
    message_history_cache: dict[str, Any] = field(default_factory=dict)
    server_health: dict[str, Any] = field(default_factory=dict)
    discovery_metadata: dict[str, list[str]] = field(default_factory=dict)
    """Map of server_id to list of tool names found during discovery phase."""
    secrets_client: Any | None = None
    """Optional SecretsClient for encrypted credential resolution.
    CONCEPT:OS-5.1 — Secrets & Authentication"""

    plan_sync: PlanSyncCallback | None = None
    """Optional async callback for syncing graph plan state to ACP.
    Set by the ACP adapter when running inside an ACP session.
    Called with (event_type, plan_entries_as_dicts) where event_type
    is 'plan_created', 'step_started', or 'step_completed'."""

    approval_manager: Any | None = None
    """Optional :class:`~agent_utilities.approval_manager.ApprovalManager`
    instance for human-in-the-loop tool approval.  Typed as Any to avoid
    a circular import.  When set, the graph executor uses
    :func:`~agent_utilities.approval_manager.run_with_approvals` instead
    of terminating when ``DeferredToolRequests`` is returned."""

    knowledge_engine: RegistryGraphEngine | None = None
    """Engine for topological and semantic discovery of specialists and memories."""

    model_registry: ModelRegistry | None = None
    """Optional :class:`~agent_utilities.models.ModelRegistry` used by the
    specialist-spawning path. When populated (typically from the host
    FastAPI ``app.state.model_registry``), the executor calls
    ``registry.pick_for_task(complexity=tier, required_tags=...)`` to
    choose a model per node based on a tier hint; otherwise it falls back
    to ``agent_model``."""

    requested_model_id: str | None = None
    """Optional per-turn model override id.

    Populated by the ``_model_override_middleware`` in :mod:`server`
    from the ``x-agent-model-id`` request header and propagated through
    the protocol wrappers (AG-UI, SSE, ACP). When set and the id resolves
    inside :attr:`model_registry`, :func:`pick_specialist_model` uses it
    verbatim for every specialist node, bypassing the tier/tag heuristic.
    Invalid or unknown ids fall back to the default selection logic."""

    cognitive_scheduler: Any | None = None
    """Optional :class:`~agent_utilities.core.cognitive_scheduler.CognitiveScheduler`
    for priority-aware agent management.  Typed as Any to avoid circular import.
    CONCEPT:OS-5.2 — Cognitive Scheduler"""

    permissions_kernel: Any | None = None
    """Optional :class:`~agent_utilities.security.permissions_kernel.PermissionsKernel`
    for identity-based tool governance.  Typed as Any to avoid circular import.
    CONCEPT:OS-5.1 — Permissions Kernel"""

    agent_identity: Any | None = None
    """The signed ``AgentIdentity`` for this execution context.
    Populated by the ``PermissionsKernel`` when the graph is initialised.
    CONCEPT:OS-5.1 — Permissions Kernel"""

    resource_optimizer: Any | None = None
    """Optional :class:`~agent_utilities.core.resource_optimizer.ResourceOptimizer`
    for budget-aware model tier selection.  When populated,
    :func:`pick_specialist_model` consults it for homeostatic downgrade.
    CONCEPT:OS-5.2 — Homeostatic Model Downgrade"""

    routing_percentile: float = float(os.getenv("ROUTING_PERCENTILE", "50.0"))
    """Confidence threshold percentile for adaptive model tier routing.
    Values above ``routing_percentile / 100`` trigger a tier downgrade;
    values below ``1 - threshold`` trigger escalation.  Default 50 gives
    a balanced split; lower values route more aggressively to cheap models.
    CONCEPT:ORCH-1.2 — Confidence-Gated Router"""


@dataclass
class GraphState:
    """The central state container for an orchestrator session.

    This class tracks the entire lifecycle of a request, from the initial
    query and high-level plan to parallel execution results and final
    verification feedback. It supports persistence and usage monitoring.
    """

    query: str
    """The original user query."""

    query_parts: list[dict[str, Any]] = field(default_factory=list)
    """Rich multi-modal parts of the user query (text, images, etc.)."""

    # Pro Mode State
    topology: str = "basic"  # "basic" or "pro"
    mode: str = "ask"  # "ask", "plan", or "execute"
    exploration_notes: str = ""
    architectural_decisions: str = ""
    verification_feedback: str = ""

    validation_feedback: str | None = None
    """Feedback from ValidatorNode to DomainNode for self-correction."""

    routed_domain: str = ""
    """The domain tag this query was routed to."""

    results: dict[str, Any] = field(default_factory=dict)
    """Accumulated results keyed by domain."""

    error: str | None = None
    """Error message if something went wrong."""

    session_id: str = ""
    """Unique session identifier for checkpoint resumption."""

    checkpoint_ts: float = 0.0
    """Timestamp of the last checkpoint."""

    node_history: list[str] = field(default_factory=list)
    """History of executed nodes."""

    retry_count: int = 0
    """Number of retries attempted in ErrorRecoveryNode."""

    parallel_domains: list[str] = field(default_factory=list)
    """List of domains for parallel execution."""

    task_list: Tasks = field(default_factory=Tasks)
    """Ordered tasks for Spec-Driven Development."""

    progress_log: ProgressLog = field(default_factory=ProgressLog)
    """Historical progress log for Project Mode."""

    sprint_contract: SprintContract = field(default_factory=SprintContract)
    """Sprint goals and definition of done."""

    project_root: str = ""
    """Root directory for project artifacts."""

    current_batch_ids: list[str] = field(default_factory=list)
    """IDs of tasks currently executing in parallel."""

    last_git_commit: str | None = None
    """The last recorded git commit hash for this session/project."""

    human_approval_required: bool = False
    """Flag to pause for human intervention."""

    session_usage: UsageStatistics = field(default_factory=UsageStatistics)
    """Aggregated token usage and cost for this session."""

    execution_budget: ExecutionBudget = field(default_factory=ExecutionBudget)
    """CONCEPT:ORCH-1.3 — Execution Budget. Defines caps for this session."""

    user_redirect_feedback: str | None = None
    """Feedback from a triage pause that redirects the graph to a different domain."""

    # Dynamic Planning State
    plan: GraphPlan = field(default_factory=GraphPlan)
    """The fully determined execution plan for this run."""

    step_cursor: int = 0
    """Current index in the sequential plan steps."""

    results_registry: dict[str, Any] = field(default_factory=dict)
    """Aggregated results from each execution step."""

    pending_parallel_count: int = 0
    """Number of parallel tasks we are currently waiting for."""

    current_node_retries: int = 0
    """Number of local retries attempted on the current expert node."""

    global_research_loops: int = 0
    """Number of times the entire graph has looped back to research/re-planning."""

    verification_attempts: int = 0
    """Number of times the verifier has attempted to validate the results."""

    deferred_events: list[dict[str, Any]] = field(default_factory=list)
    """Events received asynchronously during execution that need to be processed by the dispatcher."""

    pending_batch: ParallelBatch | None = None
    """Temporary storage for a batch of tasks during transition from dispatcher to processor."""

    needs_replan: bool = False
    """Flag to trigger a re-evaluation of the graph plan due to implementation failures."""

    node_transitions: int = 0
    """Total number of node transitions during this execution. Used for infinite-loop protection."""

    MAX_NODE_TRANSITIONS: int = 50
    """Hard ceiling on the total number of node transitions before the graph force-terminates."""

    current_flow_id: str | None = None
    """ID of the current ProcessFlow being executed."""

    current_process_flow: ProcessFlow | None = None
    """The full ProcessFlow model for the current session."""

    active_policies: list[Policy] = field(default_factory=list)
    """List of policies applicable to the current context."""

    signal_board: dict[str, list[str]] = field(default_factory=dict)
    """CONCEPT:ORCH-1.0 — Stigmergy Signal Board.
    Lightweight pub/sub within the graph execution session. Specialists
    emit signals (e.g., ``dependency_gap``, ``security_concern``) via
    ``emit_signal()`` and the dispatcher injects relevant signals into
    subsequent specialist system prompts.

    Schema: ``{signal_type: [message, ...]}``."""

    routing_confidence_log: list[dict[str, Any]] = field(default_factory=list)
    """CONCEPT:ORCH-1.2 — Log of confidence-gated routing decisions.
    Each entry records the specialist id, confidence signal, original
    tier, routed tier, and timestamp for observability and diagnostics.

    Schema: ``[{specialist_id, confidence, original_tier, routed_tier, timestamp}, ...]``."""

    recursion_depth: int = 0
    """CONCEPT:ORCH-1.1 — Current nesting depth for recursive graph orchestration.
    Incremented when a nested run_graph() is spawned as a specialist step.
    Capped at MAX_RECURSION_DEPTH (default 2, configurable via env var).
    Inspired by the RL Conductor's self-referential recursive topologies
    (Nielsen et al., ICLR 2026)."""

    workboard: WideSearchWorkboard | None = None
    """CONCEPT:ORCH-1.1 — Pydantic-Native Shared Workboard.
    A thread-safe/merge-safe shared memory scratchpad for parallel workers
    during wide-search extraction tasks."""

    context_provenance: list[dict[str, Any]] = field(default_factory=list)
    """CONCEPT:KG-2.9 — Cross-Agent Context Provenance.
    Tracks retrieval quality scores and failure modes across agent boundaries.
    Each entry is a serialized ``ContextProvenanceRecord`` from
    ``retrieval_quality.py``. Downstream agents inspect this to assess
    the reliability of upstream context."""

    subagent_pattern: str | None = None
    """CONCEPT:ORCH-1.6 — Active Subagent Lifecycle Pattern.
    Records which interaction pattern (inline_tool, fan_out, agent_pool,
    teams) was selected for this execution. Used for telemetry and
    pattern-outcome learning."""

    def merge_workboard_data(self, entity_id: str, row_data: dict[str, Any]):
        """Safely merge extracted data into the shared workboard."""
        if not self.workboard:
            self.workboard = WideSearchWorkboard()

        if entity_id in self.workboard.row_slots:
            # Simple conflict log for now
            self.workboard.conflict_log.append(
                {
                    "entity_id": entity_id,
                    "existing": self.workboard.row_slots[entity_id],
                    "new": row_data,
                }
            )
            # Merge dicts
            self.workboard.row_slots[entity_id].update(row_data)
        else:
            self.workboard.row_slots[entity_id] = row_data

    def _update_usage(self, result_usage: Any):
        """Update the accumulated session usage statistics.

        Processes usage metadata from an agent run and increments input,
        output, and total token counts. Also performs simple cost
        estimation.

        Args:
            result_usage: The usage object returned by a pydantic-ai Agent.

        """
        if not result_usage:
            return

        def _to_int(val: Any) -> int:
            if isinstance(val, int | float):
                return int(val)
            try:
                return int(val)
            except (TypeError, ValueError):
                return 0

        req_tokens = _to_int(getattr(result_usage, "request_tokens", 0))
        res_tokens = _to_int(getattr(result_usage, "response_tokens", 0))
        tot_tokens = _to_int(getattr(result_usage, "total_tokens", 0))

        self.session_usage.input_tokens += req_tokens
        self.session_usage.output_tokens += res_tokens
        self.session_usage.total_tokens += tot_tokens

        # Simple cost estimation based on Sonnet 3.5 defaults
        self.session_usage.estimated_cost_usd = (
            self.session_usage.input_tokens * 0.000003
        ) + (self.session_usage.output_tokens * 0.000015)

        cost = self.session_usage.estimated_cost_usd
        total = self.session_usage.total_tokens

        # Safe logging to avoid formatting errors on Mocks (though _to_int should handle it)
        cost_str = f"{cost:.4f}" if isinstance(cost, int | float) else str(cost)
        logger.debug(f"Usage Updated: ${cost_str} ({total} tokens)")

    def sync_to_disk(self, artifact_prefix: str = ""):
        """Persist key state artifacts to the local workspace for inspection.

        Serializes task lists, progress logs, and usage statistics to
        JSON files within the project root.

        Args:
            artifact_prefix: Optional prefix for the generated filenames.

        """
        root = self.project_root or os.getcwd()
        if not os.path.exists(root):
            try:
                os.makedirs(root, exist_ok=True)
            except Exception:
                return

        mappings = {
            "tasks.json": self.task_list,
            "progress.json": self.progress_log,
            "sprint.json": self.sprint_contract,
            "usage.json": self.session_usage,
        }
        for filename, model in mappings.items():
            path = os.path.join(root, f"{artifact_prefix}{filename}")
            try:
                with open(path, "w") as f:
                    f.write(model.model_dump_json(indent=2))
            except Exception as e:
                logger.warning(f"Failed to sync artifact {filename}: {e}")

    def load_from_disk(self):
        """Recover project state from existing JSON artifacts in the workspace.

        Attempts to reload task lists, logs, and usage data from the
        file system to resume a previous session.

        Returns:
            True if any artifacts were successfully loaded, False otherwise.

        """
        root = self.project_root or os.getcwd()
        mappings = {
            "tasks.json": ("task_list", Tasks),
            "progress.json": ("progress_log", ProgressLog),
            "sprint.json": ("sprint_contract", SprintContract),
            "usage.json": ("session_usage", UsageStatistics),
        }
        loaded = False
        for filename, (attr, m_cls) in mappings.items():
            model_cls: Any = m_cls
            path = os.path.join(root, filename)
            if os.path.exists(path):
                try:
                    with open(path) as f:
                        data = f.read()
                        if data.strip():
                            setattr(self, attr, model_cls.model_validate_json(data))
                            loaded = True
                    logger.info(f"Loaded {filename} for project state.")
                except Exception as e:
                    logger.warning(f"Could not load {filename}: {e}")
        return loaded
