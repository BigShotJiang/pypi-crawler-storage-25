import logging
from typing import Any

from pydantic_ai import RunContext

from agent_utilities.protocols.a2a import (
    delete_a2a_peer as delete_a2a_peer_util,
)
from agent_utilities.protocols.a2a import (
    list_a2a_peers as list_a2a_peers_util,
)
from agent_utilities.protocols.a2a import (
    register_a2a_peer as register_a2a_peer_util,
)

from .versioning import tool_version

logger = logging.getLogger(__name__)


@tool_version("1.0.0")
async def list_a2a_peers(ctx: RunContext[Any]) -> list[str]:
    """List all known A2A peer agents in the Knowledge Graph.

    Args:
        ctx: The agent run context.

    Returns:
        A list of known A2A peers and their metadata.

    """
    model = list_a2a_peers_util()
    return [
        f"{name} ({peer.url}): {peer.description}" for name, peer in model.peers.items()
    ]


@tool_version("1.0.0")
async def register_a2a_peer(
    ctx: RunContext[Any],
    name: str,
    url: str,
    description: str = "",
    capabilities: str = "",
    auth: str = "none",
) -> str:
    """Register or update an A2A agent for delegated task execution.

    Args:
        ctx: The agent run context.
        name: The unique identifier for the peer agent.
        url: The connection URL for the peer service.
        description: A brief summary of the peer's purpose.
        capabilities: A comma-separated list of peer specialties.
        auth: Authentication type.

    Returns:
        A confirmation message indicating success.

    """
    return register_a2a_peer_util(name, url, description, capabilities, auth)


@tool_version("1.0.0")
async def delete_a2a_peer(ctx: RunContext[Any], name: str) -> str:
    """Remove an A2A peer agent from the Knowledge Graph.

    Args:
        ctx: The agent run context.
        name: The name of the peer to remove.

    Returns:
        A confirmation message indicating success.

    """
    return delete_a2a_peer_util(name)


# Tool grouping for registration
a2a_tools = [
    list_a2a_peers,
    register_a2a_peer,
    delete_a2a_peer,
]
