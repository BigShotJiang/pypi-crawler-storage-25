# SPDX-FileCopyrightText: 2026 ModelCloud.ai
# SPDX-FileCopyrightText: 2026 qubitium@modelcloud.ai
# SPDX-License-Identifier: Apache-2.0
# Contact: qubitium@modelcloud.ai, x.com/qubitium

import torch
import torch.nn as nn
from torch.nn import functional as F

from defuser.modeling.unfused_moe.common import run_routed_experts


class LinearQwen2MoeSparseMoeBlock(nn.Module):
    """Qwen2 MoE block rewritten to expose one ``nn.Module`` per expert."""

    def __init__(self, config):
        super().__init__()
        from transformers.models.qwen2_moe.modeling_qwen2_moe import Qwen2MoeMLP, Qwen2MoeTopKRouter

        self.num_experts = config.num_experts
        self.top_k = config.num_experts_per_tok
        self.norm_topk_prob = config.norm_topk_prob

        # Reuse the upstream router module so `output_router_logits` hooks still attach.
        self.gate = Qwen2MoeTopKRouter(config)
        self.experts = nn.ModuleList(
            [Qwen2MoeMLP(config, intermediate_size=config.moe_intermediate_size) for _ in range(self.num_experts)]
        )

        self.shared_expert = Qwen2MoeMLP(config, intermediate_size=config.shared_expert_intermediate_size)
        self.shared_expert_gate = torch.nn.Linear(config.hidden_size, 1, bias=False)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Route tokens exactly like HF Qwen2 MoE, then run explicit expert modules."""
        batch_size, sequence_length, hidden_dim = hidden_states.shape
        hidden_states = hidden_states.view(-1, hidden_dim)
        shared_expert_output = self.shared_expert(hidden_states)
        _, routing_weights, selected_experts = self.gate(hidden_states)
        routing_weights = routing_weights.to(hidden_states.dtype)
        final_hidden_states = run_routed_experts(
            self.experts,
            hidden_states,
            routing_weights,
            selected_experts,
            self.num_experts,
        )

        shared_expert_output = F.sigmoid(self.shared_expert_gate(hidden_states)) * shared_expert_output

        final_hidden_states = final_hidden_states + shared_expert_output

        final_hidden_states = final_hidden_states.reshape(batch_size, sequence_length, hidden_dim)
        return final_hidden_states
