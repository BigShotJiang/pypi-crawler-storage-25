"""
sen2p: Download Sentinel-2 imagery from Microsoft Planetary Computer.

Focused on data discovery, download, and satellite utilities.
Processing/analysis is handled by rasteric.
"""

import os
import sys
import csv
import json
import time
import argparse
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Dict, Any, Union, Tuple

from tqdm import tqdm
import pandas as pd
import xarray as xr
import rioxarray as rxr
import geopandas as gpd
import rasterio
from shapely.geometry import mapping, Point, box, shape as shapely_shape
from shapely.geometry.base import BaseGeometry
from shapely.ops import unary_union
from rasterio.enums import Resampling
from pystac_client import Client
import planetary_computer as pc


# ============================================================================
# Band Reference
# ============================================================================

BAND_ALIASES = {
    # Friendly name → STAC asset key
    "blue": "B02",
    "green": "B03",
    "red": "B04",
    "rededge1": "B05",
    "rededge2": "B06",
    "rededge3": "B07",
    "nir": "B08",
    "nir08": "B8A",
    "nir09": "B09",
    "swir1": "B11",
    "swir2": "B12",
    "coastal": "B01",
    "water_vapour": "B09",
    "cirrus": "B10",
    "qa60": "QA60",
    "scl": "SCL",
    "aot": "AOT",
    "wvp": "WVP",
    # Also accept lowercase band names
    "b01": "B01", "b02": "B02", "b03": "B03", "b04": "B04",
    "b05": "B05", "b06": "B06", "b07": "B07", "b08": "B08",
    "b8a": "B8A", "b09": "B09", "b10": "B10", "b11": "B11", "b12": "B12",
}

BAND_INFO = {
    "B01": {"name": "Coastal aerosol", "resolution": "60m", "wavelength": "443nm"},
    "B02": {"name": "Blue", "resolution": "10m", "wavelength": "490nm"},
    "B03": {"name": "Green", "resolution": "10m", "wavelength": "560nm"},
    "B04": {"name": "Red", "resolution": "10m", "wavelength": "665nm"},
    "B05": {"name": "Vegetation Red Edge 1", "resolution": "20m", "wavelength": "705nm"},
    "B06": {"name": "Vegetation Red Edge 2", "resolution": "20m", "wavelength": "740nm"},
    "B07": {"name": "Vegetation Red Edge 3", "resolution": "20m", "wavelength": "783nm"},
    "B08": {"name": "NIR", "resolution": "10m", "wavelength": "842nm"},
    "B8A": {"name": "Narrow NIR", "resolution": "20m", "wavelength": "865nm"},
    "B09": {"name": "Water vapour", "resolution": "60m", "wavelength": "940nm"},
    "B10": {"name": "Cirrus", "resolution": "60m", "wavelength": "1375nm"},
    "B11": {"name": "SWIR 1", "resolution": "20m", "wavelength": "1610nm"},
    "B12": {"name": "SWIR 2", "resolution": "20m", "wavelength": "2190nm"},
    "QA60": {"name": "Quality assessment", "resolution": "60m", "wavelength": "N/A"},
    "SCL": {"name": "Scene classification", "resolution": "20m", "wavelength": "N/A"},
    "AOT": {"name": "Aerosol optical thickness", "resolution": "10m", "wavelength": "N/A"},
    "WVP": {"name": "Water vapour pressure", "resolution": "10m", "wavelength": "N/A"},
}


def resolve_band_names(bands: List[str]) -> List[str]:
    """Resolve friendly band names to STAC asset keys."""
    resolved = []
    for b in bands:
        key = BAND_ALIASES.get(b.lower(), b)
        if key not in BAND_INFO and not key.startswith("B"):
            raise ValueError(f"Unknown band: '{b}'. Use one of: {list(BAND_ALIASES.keys())}")
        resolved.append(key)
    return resolved


def bandinfo(band: str) -> Dict[str, str]:
    """
    Get information about a Sentinel-2 band.

    Args:
        band: Band name or alias (e.g., "B08", "nir", "red").

    Returns:
        Dict with name, resolution, wavelength.

    Example:
        >>> bandinfo("nir")
        {'name': 'NIR', 'resolution': '10m', 'wavelength': '842nm'}
    """
    key = BAND_ALIASES.get(band.lower(), band.upper())
    if key not in BAND_INFO:
        raise ValueError(f"Unknown band: '{band}'. Available: {list(BAND_INFO.keys())}")
    info = BAND_INFO[key].copy()
    info["band"] = key
    return info


def bands() -> Dict[str, Dict[str, str]]:
    """
    List all available Sentinel-2 bands with their metadata.

    Returns:
        Dict mapping band keys to info dicts.

    Example:
        >>> for k, v in bands().items():
        ...     print(f"{k}: {v['name']} ({v['resolution']})")
    """
    return BAND_INFO.copy()


# ============================================================================
# Helper Functions
# ============================================================================

def _get_catalog() -> Client:
    """Open Planetary Computer STAC catalog with URL signing."""
    return Client.open(
        "https://planetarycomputer.microsoft.com/api/stac/v1",
        modifier=pc.sign_inplace,
    )


def clean_geometry_to_wgs84(gdf: gpd.GeoDataFrame) -> Tuple[BaseGeometry, List[float]]:
    """Reproject GeoDataFrame to EPSG:4326, fix geometries, and union."""
    if gdf.empty:
        raise ValueError("Input GeoDataFrame is empty.")
    if gdf.crs is None:
        raise ValueError("Input GeoDataFrame has no CRS defined.")

    gdf = gdf.to_crs(4326)
    geom_types = set(gdf.geom_type.str.lower())
    if geom_types.issubset({"point", "multipoint", "linestring", "multilinestring"}):
        gdf["geometry"] = gdf.geometry.buffer(0.0005)
    gdf["geometry"] = gdf.geometry.buffer(0)
    gdf["geometry"] = gdf.geometry.simplify(0.0001, preserve_topology=True)

    geometry = unary_union(gdf.geometry)
    if geometry.is_empty:
        raise ValueError("Unified geometry is empty after processing.")
    return geometry, list(gdf.total_bounds)


def convert_location_to_geojson(
    location: Union[List[float], Dict[str, Any], str]
) -> Tuple[Dict[str, Any], Optional[List[float]]]:
    """Convert location input to GeoJSON geometry (EPSG:4326)."""
    if isinstance(location, list):
        if len(location) == 2:
            return mapping(Point(location[0], location[1])), None
        elif len(location) == 4:
            if not (-180 <= location[0] <= location[2] <= 180 and -90 <= location[1] <= location[3] <= 90):
                raise ValueError("Invalid bounding box coordinates.")
            return mapping(box(*location)), location
        else:
            raise ValueError("Location list must have 2 or 4 elements.")
    if isinstance(location, dict):
        return location, None
    if isinstance(location, str):
        path = Path(location)
        if path.suffix.lower() in {".shp", ".geojson", ".json"}:
            gdf = gpd.read_file(location, engine="fiona")
            geometry, bbox = clean_geometry_to_wgs84(gdf)
            return mapping(geometry), bbox
    raise ValueError("Invalid location format.")


def print_aoi_info(geometry_dict: Dict[str, Any], bbox: Optional[List[float]]) -> None:
    """Print Area of Interest details."""
    geometry = shapely_shape(geometry_dict)
    cx, cy = geometry.centroid.coords[0]
    minx, miny, maxx, maxy = geometry.bounds
    print("📍 Area of Interest (WGS84)")
    print(f"   • Centroid: lat={cy:.6f}, lon={cx:.6f}")
    print(f"   • Bounds:   [{minx:.6f}, {miny:.6f}, {maxx:.6f}, {maxy:.6f}]")


def _extract_satellite(item_id: str) -> str:
    """Extract satellite name from item ID (e.g., S2A, S2B, S2C)."""
    parts = item_id.split("_")
    for p in parts:
        if p.startswith("S2"):
            return p
    return "S2?"


def _extract_tile(item_id: str) -> str:
    """Extract tile ID from item ID."""
    parts = item_id.split("_")
    for p in parts:
        if len(p) == 5 and p[0] == "T":
            return p
    return "N/A"


# ============================================================================
# STAC Search
# ============================================================================

def search_stac_items(
    catalog: Client,
    geometry: Dict[str, Any],
    bbox: Optional[List[float]],
    start_date: str,
    end_date: str,
    max_items: Optional[int],
    collection: str,
    cloud_max: Optional[float] = None,
) -> List[Any]:
    """Search STAC catalog with geometry, date range, and cloud filter."""
    query = {"eo:cloud_cover": {"lte": cloud_max}} if cloud_max is not None else None

    if max_items is None:
        preliminary = catalog.search(
            collections=[collection], intersects=geometry,
            datetime=f"{start_date}/{end_date}", query=query, max_items=1000,
        )
        items = list(preliminary.get_items())
        max_items = len(items)
        if not items and bbox:
            preliminary = catalog.search(
                collections=[collection], bbox=bbox,
                datetime=f"{start_date}/{end_date}", query=query, max_items=1000,
            )
            items = list(preliminary.get_items())
            max_items = len(items)
    else:
        items = []

    try:
        s = catalog.search(
            collections=[collection], intersects=geometry,
            datetime=f"{start_date}/{end_date}", query=query, max_items=max_items,
        )
        items = list(s.get_items())
        if not items and bbox:
            s = catalog.search(
                collections=[collection], bbox=bbox,
                datetime=f"{start_date}/{end_date}", query=query, max_items=max_items,
            )
            items = list(s.get_items())
    except Exception:
        if not bbox:
            raise
        s = catalog.search(
            collections=[collection], bbox=bbox,
            datetime=f"{start_date}/{end_date}", query=query, max_items=max_items,
        )
        items = list(s.get_items())

    if not items:
        raise ValueError("No items found for the given location/date range.")
    return items


def _item_to_dict(item: Any) -> Dict[str, Any]:
    """Convert a STAC item to a metadata dict."""
    available_bands = [k for k in item.assets.keys() if k.upper().startswith("B")]
    return {
        "item_id": item.id,
        "datetime": item.properties.get("datetime", "N/A"),
        "cloud_cover": item.properties.get("eo:cloud_cover", "N/A"),
        "satellite": _extract_satellite(item.id),
        "tile": _extract_tile(item.id),
        "bands": available_bands,
        "geometry": item.geometry,
    }


# ============================================================================
# Band Processing
# ============================================================================

def _download_with_retry(href: str, max_retries: int = 3, retry_delay: float = 2.0) -> xr.DataArray:
    """Download a raster with configurable retry logic."""
    for attempt in range(max_retries):
        try:
            return rxr.open_rasterio(href)
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            wait = retry_delay * (2 ** attempt)
            print(f"⚠️ Download failed (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {wait:.0f}s...")
            time.sleep(wait)


def process_band(
    band: str, item: Any, item_output_dir: Optional[str],
    overwrite: bool, show_progress: bool, tqdm_iter: Any,
    max_retries: int = 3, retry_delay: float = 2.0,
) -> Tuple[Optional[str], Optional[xr.DataArray]]:
    """Download and save a single band from a STAC item."""
    href = pc.sign(item.assets[band].href)
    file_path = os.path.join(item_output_dir, f"{item.id}_{band}.tif") if item_output_dir else None

    if file_path and os.path.exists(file_path) and not overwrite:
        if show_progress:
            tqdm_iter.write(f"  ♻️ Reusing: {file_path}")
        return file_path, rxr.open_rasterio(file_path)

    if show_progress and hasattr(tqdm_iter, "set_description"):
        tqdm_iter.set_description(f"{item.id}: {band}")

    band_array = _download_with_retry(href, max_retries=max_retries, retry_delay=retry_delay)

    if file_path:
        cloud = item.properties.get("eo:cloud_cover", "N/A")
        band_array.rio.to_raster(file_path, tags={"CLOUD_COVER": str(cloud)})
        if show_progress:
            tqdm_iter.write(f"  ✅ Saved: {file_path}")

    return file_path, band_array


def merge_bands_into_geotiff(
    band_data: List[Tuple[str, xr.DataArray]], band_names: List[str],
    item_id: str, item_output_dir: str, merged_filename: Optional[str],
    cell_size: Optional[float], overwrite: bool, show_progress: bool,
) -> str:
    """Merge multiple bands into a single GeoTIFF."""
    merged_path = os.path.join(item_output_dir, merged_filename or f"{item_id}_merged.tif")
    if os.path.exists(merged_path) and not overwrite:
        if show_progress:
            print(f"  ♻️ Reusing merged: {merged_path}")
        return merged_path

    if cell_size is None:
        cell_size = abs(band_data[0][1].rio.transform()[0]) or 10.0

    resampled = []
    for _, arr in band_data:
        cur_res = abs(arr.rio.transform()[0])
        if abs(cur_res - cell_size) > 0.01:
            method = Resampling.bilinear if cur_res < cell_size else Resampling.nearest
            resampled.append(arr.rio.reproject(arr.rio.crs, resolution=(cell_size, cell_size), resampling=method))
        else:
            resampled.append(arr)

    merged = xr.concat(resampled, dim="band")
    cloud = band_data[0][1].attrs.get("CLOUD_COVER", "N/A")
    merged.rio.to_raster(
        merged_path,
        tags={"BAND_NAMES": ",".join(band_names), "CLOUD_COVER": str(cloud)},
        descriptions=band_names,
    )
    if show_progress:
        print(f"  📦 Merged: {merged_path}")
    return merged_path


def check_all_files_exist(
    item_id: str, bands_list: List[str], item_output_dir: str,
    merge_bands: bool, merged_filename: Optional[str],
) -> bool:
    """Check if all required files already exist."""
    for band in bands_list:
        if not os.path.exists(os.path.join(item_output_dir, f"{item_id}_{band}.tif")):
            return False
    if merge_bands:
        if not os.path.exists(os.path.join(item_output_dir, merged_filename or f"{item_id}_merged.tif")):
            return False
    return True


# ============================================================================
# Public API: Search
# ============================================================================

def search(
    start_date: str,
    end_date: str,
    location: Union[List[float], Dict[str, Any], str],
    collection: str = "sentinel-2-l2a",
    cloud_max: Optional[float] = None,
    max_items: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Search for Sentinel-2 items without downloading.

    Args:
        start_date: Start date (YYYY-MM-DD).
        end_date: End date (YYYY-MM-DD).
        location: [lon, lat], bbox, GeoJSON dict, or shapefile path.
        collection: STAC collection ID.
        cloud_max: Maximum cloud cover %.
        max_items: Maximum items to return.

    Returns:
        List of dicts with item_id, datetime, cloud_cover, satellite, tile, bands, geometry.
    """
    catalog = _get_catalog()
    geometry, bbox = convert_location_to_geojson(location)
    items = search_stac_items(catalog, geometry, bbox, start_date, end_date, max_items, collection, cloud_max=cloud_max)
    return [_item_to_dict(item) for item in items]


def best_item(
    start_date: str,
    end_date: str,
    location: Union[List[float], Dict[str, Any], str],
    collection: str = "sentinel-2-l2a",
    prefer_date: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Find the best Sentinel-2 image based on cloud cover, coverage, and date proximity.

    Scoring (lower is better):
    - Cloud cover (weight: 0.5)
    - Date distance from prefer_date or midpoint (weight: 0.3)
    - Geometric coverage of AOI (weight: 0.2)

    Args:
        start_date: Start date (YYYY-MM-DD).
        end_date: End date (YYYY-MM-DD).
        location: [lon, lat], bbox, GeoJSON dict, or shapefile path.
        collection: STAC collection ID.
        prefer_date: Preferred date (YYYY-MM-DD). Defaults to midpoint of date range.

    Returns:
        Best item dict.

    Example:
        item = best_item("2023-06-01", "2023-06-30", [172.1, -43.5])
    """
    catalog = _get_catalog()
    geometry, bbox = convert_location_to_geojson(location)
    aoi_shape = shapely_shape(geometry)

    items = search_stac_items(catalog, geometry, bbox, start_date, end_date, None, collection)

    # Calculate preferred date
    if prefer_date:
        target = datetime.strptime(prefer_date, "%Y-%m-%d")
    else:
        d1 = datetime.strptime(start_date, "%Y-%m-%d")
        d2 = datetime.strptime(end_date, "%Y-%m-%d")
        target = d1 + (d2 - d1) / 2

    max_days = max((target - datetime.strptime(start_date, "%Y-%m-%d")).days,
                    (datetime.strptime(end_date, "%Y-%m-%d") - target).days, 1)

    scored = []
    for item in items:
        cloud = item.properties.get("eo:cloud_cover", 100) or 100

        # Date score (0-1, lower is better)
        item_date = datetime.strptime(item.properties["datetime"][:10], "%Y-%m-%d")
        date_dist = abs((item_date - target).days)
        date_score = min(date_dist / max_days, 1.0)

        # Coverage score (0-1, lower is better = more coverage)
        try:
            item_geom = shapely_shape(item.geometry)
            if aoi_shape.is_valid and item_geom.is_valid:
                intersection = aoi_shape.intersection(item_geom).area
                coverage = intersection / aoi_shape.area if aoi_shape.area > 0 else 0
                coverage_score = 1.0 - min(coverage, 1.0)
            else:
                coverage_score = 0.5
        except Exception:
            coverage_score = 0.5

        total = 0.5 * (cloud / 100) + 0.3 * date_score + 0.2 * coverage_score
        scored.append((total, item))

    if not scored:
        raise ValueError("No items found.")

    scored.sort(key=lambda x: x[0])
    return _item_to_dict(scored[0][1])


def nearest(
    date: str,
    location: Union[List[float], Dict[str, Any], str],
    collection: str = "sentinel-2-l2a",
    cloud_max: Optional[float] = None,
    window_days: int = 30,
) -> Dict[str, Any]:
    """
    Find the Sentinel-2 image closest to a specific date.

    Args:
        date: Target date (YYYY-MM-DD).
        location: [lon, lat], bbox, GeoJSON dict, or shapefile path.
        collection: STAC collection ID.
        cloud_max: Maximum cloud cover %.
        window_days: Search window in days before and after the date.

    Returns:
        Nearest item dict.

    Example:
        item = nearest("2024-02-01", [172.1, -43.5], cloud_max=20)
    """
    from datetime import timedelta
    target = datetime.strptime(date, "%Y-%m-%d")
    start = (target - timedelta(days=window_days)).strftime("%Y-%m-%d")
    end = (target + timedelta(days=window_days)).strftime("%Y-%m-%d")

    catalog = _get_catalog()
    geometry, bbox = convert_location_to_geojson(location)
    items = search_stac_items(catalog, geometry, bbox, start, end, None, collection, cloud_max=cloud_max)

    if not items:
        raise ValueError(f"No items found near {date} within {window_days} days.")

    best = min(items, key=lambda it: abs((datetime.strptime(it.properties["datetime"][:10], "%Y-%m-%d") - target).days))
    return _item_to_dict(best)


# ============================================================================
# Public API: Download
# ============================================================================

def download(
    start_date: str,
    end_date: str,
    location: Union[List[float], Dict[str, Any], str],
    bands: Optional[List[str]] = None,
    output_dir: Optional[str] = None,
    show_progress: bool = True,
    merge_bands: bool = True,
    merged_filename: Optional[str] = None,
    overwrite: bool = False,
    cell_size: Optional[float] = None,
    max_items: Optional[int] = None,
    collection: str = "sentinel-2-l2a",
    cloud_max: Optional[float] = None,
    workers: int = 1,
    max_retries: int = 3,
    retry_delay: float = 2.0,
) -> List[Dict[str, Any]]:
    """
    Download Sentinel-2 imagery from Microsoft Planetary Computer.

    Args:
        start_date: Start date (YYYY-MM-DD).
        end_date: End date (YYYY-MM-DD).
        location: [lon, lat], bbox, GeoJSON dict, or shapefile path.
        bands: Band names (e.g., ["B02", "blue", "nir"]). None = all available.
        output_dir: Output directory.
        show_progress: Show progress bars and logs.
        merge_bands: Merge bands into single GeoTIFF.
        merged_filename: Custom filename for merged output.
        overwrite: Overwrite existing files.
        cell_size: Target resolution (meters). None = auto.
        max_items: Maximum items to download.
        collection: STAC collection ID.
        cloud_max: Max cloud cover %.
        workers: Number of parallel download threads.
        max_retries: Retry attempts per band download.
        retry_delay: Base delay between retries (seconds, doubles each attempt).

    Returns:
        List of dicts with item metadata and file paths.
    """
    catalog = _get_catalog()
    geometry, bbox = convert_location_to_geojson(location)
    print_aoi_info(geometry, bbox)

    items = search_stac_items(catalog, geometry, bbox, start_date, end_date, max_items, collection, cloud_max=cloud_max)

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    # Resolve band aliases
    if bands is not None:
        bands = resolve_band_names(bands)

    results = []
    for item in items:
        item_id = item.id
        available_bands = [k for k in item.assets.keys() if k.upper().startswith("B")]
        cloud_cover = item.properties.get("eo:cloud_cover", "N/A")

        if cloud_max is not None and isinstance(cloud_cover, (int, float)) and cloud_cover > cloud_max:
            if show_progress:
                print(f"⏭️ Skipping {item_id}: cloud {cloud_cover}% > {cloud_max}%")
            continue

        bands_to_download = available_bands if bands is None else bands
        missing = [b for b in bands_to_download if b not in available_bands]
        if missing:
            if show_progress:
                print(f"⏭️ Skipping {item_id}: missing bands {missing}")
            continue

        item_output_dir = os.path.join(output_dir, item_id) if output_dir else None
        if item_output_dir:
            os.makedirs(item_output_dir, exist_ok=True)

        if item_output_dir and not overwrite:
            if check_all_files_exist(item_id, bands_to_download, item_output_dir, merge_bands, merged_filename):
                if show_progress:
                    print(f"♻️ All files for {item_id} exist, skipping.")
                result = {"item_id": item_id, "cloud_cover": cloud_cover}
                for band in bands_to_download:
                    result[band] = os.path.join(item_output_dir, f"{item_id}_{band}.tif")
                if merge_bands:
                    result["merged"] = os.path.join(item_output_dir, merged_filename or f"{item_id}_merged.tif")
                results.append(result)
                continue

        result = {"item_id": item_id, "cloud_cover": cloud_cover}

        if workers > 1 and len(bands_to_download) > 1:
            # Parallel download
            band_results = {}
            with ThreadPoolExecutor(max_workers=workers) as executor:
                futures = {
                    executor.submit(
                        process_band, band, item, item_output_dir,
                        overwrite, False, None, max_retries, retry_delay,
                    ): band
                    for band in bands_to_download
                }
                for future in tqdm(as_completed(futures), total=len(futures), desc=f"Downloading {item_id}", disable=not show_progress):
                    band = futures[future]
                    try:
                        file_path, band_array = future.result()
                        band_results[band] = (file_path, band_array)
                        result[band] = file_path or band_array
                    except Exception as e:
                        if show_progress:
                            print(f"  ❌ Failed {band}: {e}")

            band_data = [(b, r[1]) for b, r in band_results.items() if r[1] is not None]
            band_names_list = [b for b in band_results if band_results[b][1] is not None]
        else:
            # Sequential download
            band_data, band_names_list = [], []
            iterable = tqdm(bands_to_download, desc=f"Processing {item_id}") if show_progress else bands_to_download
            for band in iterable:
                file_path, band_array = process_band(
                    band, item, item_output_dir, overwrite, show_progress, iterable,
                    max_retries=max_retries, retry_delay=retry_delay,
                )
                result[band] = file_path or band_array
                if merge_bands and band_array is not None:
                    band_data.append((band, band_array))
                    band_names_list.append(band)

        if merge_bands and item_output_dir and band_data:
            result["merged"] = merge_bands_into_geotiff(
                band_data, band_names_list, item_id, item_output_dir,
                merged_filename, cell_size, overwrite, show_progress,
            )

        results.append(result)

    if show_progress:
        print(f"\n✅ Downloaded {len(results)} item(s).")
    return results


# ============================================================================
# Public API: Metadata
# ============================================================================

def meta_df(items: List[Dict[str, Any]]) -> pd.DataFrame:
    """
    Convert search results to a pandas DataFrame.

    Args:
        items: List of dicts from search() or download().

    Returns:
        DataFrame with columns: item_id, datetime, cloud_cover, satellite, tile.

    Example:
        items = search("2023-06-01", "2023-06-10", [172.1, -43.5])
        df = meta_df(items)
    """
    rows = []
    for item in items:
        rows.append({
            "item_id": item.get("item_id", ""),
            "datetime": item.get("datetime", "N/A"),
            "cloud_cover": item.get("cloud_cover", "N/A"),
            "satellite": item.get("satellite", _extract_satellite(item.get("item_id", ""))),
            "tile": item.get("tile", _extract_tile(item.get("item_id", ""))),
        })
    return pd.DataFrame(rows)


def export_meta(items: List[Dict[str, Any]], output: str) -> str:
    """
    Export item metadata to CSV.

    Args:
        items: List of dicts from search() or download().
        output: Output CSV file path.

    Returns:
        Path to the output CSV.
    """
    df = meta_df(items)
    df.to_csv(output, index=False)
    return output


def export_footprint(items: List[Dict[str, Any]], output: str) -> str:
    """
    Export item footprints as GeoJSON.

    Args:
        items: List of dicts from search() (must contain 'geometry').
        output: Output GeoJSON file path.

    Returns:
        Path to the output GeoJSON.
    """
    features = []
    for item in items:
        geom = item.get("geometry")
        if geom is None:
            continue
        features.append({
            "type": "Feature",
            "geometry": geom,
            "properties": {
                "item_id": item.get("item_id", ""),
                "datetime": item.get("datetime", ""),
                "cloud_cover": item.get("cloud_cover", ""),
                "satellite": item.get("satellite", ""),
                "tile": item.get("tile", ""),
            },
        })

    geojson = {"type": "FeatureCollection", "features": features}
    with open(output, "w") as f:
        json.dump(geojson, f, indent=2)
    return output


def show_meta(file_path: str) -> None:
    """Display metadata for a raster file."""
    with rasterio.open(file_path) as src:
        tags = src.tags()
        print(f"📄 File: {file_path}")
        if "CLOUD_COVER" in tags:
            print(f"☁️ Cloud cover: {tags['CLOUD_COVER']}%")
        if "BAND_NAMES" in tags:
            print(f"🏷️ Bands: {tags['BAND_NAMES']}")
        print(f"📐 Dimensions: {src.width} x {src.height}")
        print(f"📊 Band count: {src.count}")
        print(f"🗺️ CRS: {src.crs}")
        print(f"📏 Resolution: {src.res}")
        print(f"📌 Bounds: {src.bounds}")


# ============================================================================
# Public API: Visualization (lightweight, no analysis)
# ============================================================================

def preview(item: Dict[str, Any]) -> None:
    """
    Print a quick preview of a search result item.

    Args:
        item: Dict from search() or download().
    """
    print(f"🛰️  {item.get('item_id', 'N/A')}")
    print(f"   📅 Date:     {item.get('datetime', 'N/A')[:10]}")
    print(f"   ☁️  Cloud:    {item.get('cloud_cover', 'N/A')}%")
    print(f"   🛰️  Satellite: {item.get('satellite', 'N/A')}")
    print(f"   🗺️  Tile:     {item.get('tile', 'N/A')}")
    print(f"   📊 Bands:    {len(item.get('bands', []))}")


def timeline(items: List[Dict[str, Any]]) -> None:
    """
    Print a text timeline of available images with cloud cover.

    Args:
        items: List of dicts from search().

    Example:
        items = search("2023-06-01", "2023-06-30", [172.1, -43.5])
        timeline(items)
    """
    if not items:
        print("No items to display.")
        return

    sorted_items = sorted(items, key=lambda x: x.get("datetime", ""))
    max_bar = 40

    for item in sorted_items:
        dt = str(item.get("datetime", ""))[:10]
        cloud = item.get("cloud_cover", 0)
        if not isinstance(cloud, (int, float)):
            cloud = 0

        bar_len = int(cloud / 100 * max_bar)
        bar = "█" * bar_len + "░" * (max_bar - bar_len)

        # Color coding
        if cloud <= 10:
            marker = "🟢"
        elif cloud <= 30:
            marker = "🟡"
        else:
            marker = "🔴"

        sat = item.get("satellite", "")
        print(f"  {dt}  {marker} {bar}  {cloud:5.1f}%  {sat}")


# ============================================================================
# Public API: Collections
# ============================================================================

def collections() -> List[Dict[str, str]]:
    """
    List available STAC collections on Planetary Computer.

    Returns:
        List of dicts with collection id, title, and description.

    Example:
        for c in collections():
            print(c['id'], c['title'])
    """
    catalog = _get_catalog()
    results = []
    for coll in catalog.get_children():
        try:
            results.append({
                "id": coll.id,
                "title": getattr(coll, "title", ""),
                "description": getattr(coll, "description", "")[:100],
            })
        except Exception:
            continue
    return results


# ============================================================================
# CLI Entry Point
# ============================================================================

def main():
    """Command-line interface for sen2p."""
    parser = argparse.ArgumentParser(
        prog="sen2p",
        description="Search and download Sentinel-2 imagery from Microsoft Planetary Computer.",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- search ---
    sp = subparsers.add_parser("search", help="Search for items")
    sp.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    sp.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    sp.add_argument("--location", required=True, help="[lon,lat] or path to .shp")
    sp.add_argument("--cloud-max", type=float, help="Max cloud cover %%")
    sp.add_argument("--max-items", type=int, help="Max items")
    sp.add_argument("--collection", default="sentinel-2-l2a")

    # --- best ---
    sp = subparsers.add_parser("best", help="Find best image (low cloud, good coverage)")
    sp.add_argument("--start", required=True)
    sp.add_argument("--end", required=True)
    sp.add_argument("--location", required=True)
    sp.add_argument("--prefer-date", help="Preferred date (YYYY-MM-DD)")
    sp.add_argument("--collection", default="sentinel-2-l2a")

    # --- nearest ---
    sp = subparsers.add_parser("nearest", help="Find image closest to a date")
    sp.add_argument("--date", required=True, help="Target date (YYYY-MM-DD)")
    sp.add_argument("--location", required=True)
    sp.add_argument("--cloud-max", type=float)
    sp.add_argument("--window", type=int, default=30, help="Search window in days")
    sp.add_argument("--collection", default="sentinel-2-l2a")

    # --- download ---
    sp = subparsers.add_parser("download", help="Download bands")
    sp.add_argument("--start", required=True)
    sp.add_argument("--end", required=True)
    sp.add_argument("--location", required=True)
    sp.add_argument("--bands", help="Comma-separated bands (e.g., blue,green,red,nir)")
    sp.add_argument("--output", default=".")
    sp.add_argument("--cloud-max", type=float)
    sp.add_argument("--max-items", type=int)
    sp.add_argument("--no-merge", action="store_true")
    sp.add_argument("--overwrite", action="store_true")
    sp.add_argument("--cell-size", type=float)
    sp.add_argument("--workers", type=int, default=1, help="Parallel download threads")
    sp.add_argument("--retries", type=int, default=3)
    sp.add_argument("--collection", default="sentinel-2-l2a")

    # --- meta ---
    sp = subparsers.add_parser("meta", help="Show raster metadata")
    sp.add_argument("file", help="Path to raster file")

    # --- bandinfo ---
    sp = subparsers.add_parser("bandinfo", help="Show band information")
    sp.add_argument("band", help="Band name (e.g., B08, nir, red)")

    # --- bands ---
    subparsers.add_parser("bands", help="List all Sentinel-2 bands")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "search":
        items = search(args.start, args.end, _parse_loc(args.location), args.collection, args.cloud_max, args.max_items)
        print(f"\nFound {len(items)} item(s):\n")
        for r in items:
            print(f"  {r['item_id']}  |  {r['datetime'][:10]}  |  cloud: {r['cloud_cover']}%  |  {r['satellite']}  |  tile: {r['tile']}")

    elif args.command == "best":
        item = best_item(args.start, args.end, _parse_loc(args.location), args.collection, args.prefer_date)
        print("\n🏆 Best item:\n")
        preview(item)

    elif args.command == "nearest":
        item = nearest(args.date, _parse_loc(args.location), args.collection, args.cloud_max, args.window)
        print(f"\n📍 Nearest to {args.date}:\n")
        preview(item)

    elif args.command == "download":
        band_list = args.bands.split(",") if args.bands else None
        download(
            args.start, args.end, _parse_loc(args.location),
            bands=band_list, output_dir=args.output, cloud_max=args.cloud_max,
            max_items=args.max_items, merge_bands=not args.no_merge,
            overwrite=args.overwrite, cell_size=args.cell_size,
            workers=args.workers, max_retries=args.retries, collection=args.collection,
        )

    elif args.command == "meta":
        show_meta(args.file)

    elif args.command == "bandinfo":
        info = bandinfo(args.band)
        print(f"\n📡 Band: {info['band']}")
        print(f"   Name:       {info['name']}")
        print(f"   Resolution: {info['resolution']}")
        print(f"   Wavelength: {info['wavelength']}")

    elif args.command == "bands":
        print("\n📡 Sentinel-2 Bands:\n")
        for k, v in BAND_INFO.items():
            print(f"  {k:5s}  {v['name']:30s}  {v['resolution']:5s}  {v['wavelength']}")


def _parse_loc(loc_str: str) -> Union[List[float], str]:
    """Parse location string from CLI."""
    if os.path.exists(loc_str):
        return loc_str
    try:
        return [float(x.strip()) for x in loc_str.split(",")]
    except ValueError:
        raise ValueError(f"Invalid location: {loc_str}")


if __name__ == "__main__":
    main()
