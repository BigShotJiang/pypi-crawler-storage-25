"""sen2p: Download Sentinel-2 imagery from Microsoft Planetary Computer."""

from .download import (
    search,
    best_item,
    nearest,
    download,
    meta_df,
    export_meta,
    export_footprint,
    show_meta,
    preview,
    timeline,
    collections,
    bandinfo,
    bands,
    resolve_band_names,
    BAND_ALIASES,
    BAND_INFO,
)

__version__ = "0.2.0"
__all__ = [
    "search",
    "best_item",
    "nearest",
    "download",
    "meta_df",
    "export_meta",
    "export_footprint",
    "show_meta",
    "preview",
    "timeline",
    "collections",
    "bandinfo",
    "bands",
    "resolve_band_names",
    "BAND_ALIASES",
    "BAND_INFO",
]
