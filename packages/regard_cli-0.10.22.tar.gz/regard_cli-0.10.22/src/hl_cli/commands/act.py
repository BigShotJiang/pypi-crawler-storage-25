"""Act commands — order, cancel, cancel-all, leverage, stop, transfer, preflight."""

import sys
from typing import Annotated, Optional

import typer

from hl_cli.client import get_account_mode, get_active_asset_data, get_address, get_all_mids, get_all_orders, get_all_positions, get_collateral_map, get_dex_for_coin, get_exchange, get_info
from hl_cli.main import hl_app
from hl_cli.output import die, output
from hl_cli.resolver import get_resolver

SIDE_MAP = {"buy": True, "long": True, "sell": False, "short": False}


def _validate_trigger_direction(trigger_px: float, mid: float, is_long: bool, is_tp: bool):
    """Validate that a stop/TP trigger price is on the correct side of market.

    Dies with BAD_STOP or BAD_TP if the trigger would fire immediately.
    No-op if mid price is unavailable (mid <= 0).
    """
    if mid <= 0:
        return
    if not is_tp:
        if is_long and trigger_px >= mid:
            die("validation_error", "BAD_STOP",
                f"Stop loss {trigger_px:.6g} is above market ({mid:.6g}) for a long — would trigger immediately",
                hint="Stop loss for longs must be below current price")
        if not is_long and trigger_px <= mid:
            die("validation_error", "BAD_STOP",
                f"Stop loss {trigger_px:.6g} is below market ({mid:.6g}) for a short — would trigger immediately",
                hint="Stop loss for shorts must be above current price")
    else:
        if is_long and trigger_px <= mid:
            die("validation_error", "BAD_TP",
                f"Take profit {trigger_px:.6g} is below market ({mid:.6g}) for a long — would trigger immediately",
                hint="Take profit for longs must be above current price")
        if not is_long and trigger_px >= mid:
            die("validation_error", "BAD_TP",
                f"Take profit {trigger_px:.6g} is above market ({mid:.6g}) for a short — would trigger immediately",
                hint="Take profit for shorts must be below current price")


def _die_with_dex_hint(asset: str, msg: str):
    """Die with a dex balance hint for HIP-3 assets with insufficient margin."""
    dex = get_dex_for_coin(asset)
    if dex and "insufficient margin" in msg.lower():
        try:
            info = get_info()
            addr = get_address()
            dex_state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex})
            dex_val = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {})).get("accountValue", "0")
            die("venue_error", "ORDER_REJECTED", msg,
                hint=f"{dex} dex balance: ${dex_val}. Transfer funds: regard hl transfer <amount> --to {dex}",
                exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass
    die("venue_error", "ORDER_REJECTED", msg, exit_code=4)


def _parse_order_response(resp, asset: str, side_str: str, size: str):
    """Parse SDK order response into CLI output format."""
    if resp.get("status") == "err":
        msg = resp.get("response", str(resp))
        _die_with_dex_hint(asset, msg)

    data = resp.get("response", {}).get("data", {})
    statuses = data.get("statuses", [])
    if not statuses:
        die("venue_error", "ORDER_REJECTED", "No status in response", exit_code=4)

    st = statuses[0]
    if "error" in st:
        _die_with_dex_hint(asset, st["error"])

    if "filled" in st:
        filled = st["filled"]
        return {
            "status": "filled",
            "oid": filled.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": filled.get("totalSz", size),
            "avg_price": filled.get("avgPx", ""),
        }
    elif "resting" in st:
        resting = st["resting"]
        return {
            "status": "resting",
            "oid": resting.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": size,
        }
    else:
        return {"status": "unknown", "raw": st}



@hl_app.command()
def order(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    side: Annotated[str, typer.Argument(help="buy/long or sell/short")],
    size: Annotated[str, typer.Argument(help="Amount in base asset")],
    price: Annotated[Optional[str], typer.Argument(help="Limit price")] = None,
    market: Annotated[bool, typer.Option("--market", help="Market order (IOC)")] = False,
    tif: Annotated[Optional[str], typer.Option("--tif", help="gtc|ioc|alo")] = None,
    reduce_only: Annotated[bool, typer.Option("--reduce-only", help="Reduce only")] = False,
    tp: Annotated[Optional[str], typer.Option("--tp", help="Take profit trigger price")] = None,
    sl: Annotated[Optional[str], typer.Option("--sl", help="Stop loss trigger price")] = None,
    cloid: Annotated[Optional[str], typer.Option("--cloid", help="Client order ID (hex)")] = None,
):
    """Place an order."""
    opts = ctx.obj

    side_lower = side.lower()
    if side_lower not in SIDE_MAP:
        die("validation_error", "INVALID_SIDE", f"Invalid side: {side}", hint="Use buy/long or sell/short", param="side")

    is_buy = SIDE_MAP[side_lower]
    sz = float(size)

    exchange = get_exchange(opts["testnet"])
    resolver = get_resolver(exchange.info)
    resolved = resolver.resolve(asset)

    from hyperliquid.utils.types import Cloid as SdkCloid
    sdk_cloid = SdkCloid.from_str(cloid) if cloid else None

    if market or price is None:
        # Market order
        try:
            resp = exchange.market_open(resolved, is_buy, sz, cloid=sdk_cloid)
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        result = _parse_order_response(resp, resolved, side_lower, size)
        output(result, opts["fields"])
        return

    # Limit order
    px = float(price)
    tif_map = {"gtc": "Gtc", "ioc": "Ioc", "alo": "Alo"}
    tif_val = tif_map.get((tif or "gtc").lower())
    if not tif_val:
        die("validation_error", "INVALID_TIF", f"Invalid TIF: {tif}", hint="Valid values: gtc, ioc, alo", param="tif")
    order_type = {"limit": {"tif": tif_val}}

    if tp or sl:
        # Validate TP/SL direction before submitting
        mids = get_all_mids(exchange.info)
        mid = float(mids.get(resolved, "0"))
        if sl:
            _validate_trigger_direction(float(sl), mid, is_buy, is_tp=False)
        if tp:
            _validate_trigger_direction(float(tp), mid, is_buy, is_tp=True)

        # Parent + TP/SL as grouped order
        order_requests = [
            {
                "coin": resolved,
                "is_buy": is_buy,
                "sz": sz,
                "limit_px": px,
                "order_type": order_type,
                "reduce_only": reduce_only,
                "cloid": sdk_cloid,
            }
        ]
        if tp:
            tp_type = {"trigger": {"triggerPx": float(tp), "isMarket": True, "tpsl": "tp"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": float(tp),
                "order_type": tp_type,
                "reduce_only": True,
            })
        if sl:
            sl_type = {"trigger": {"triggerPx": float(sl), "isMarket": True, "tpsl": "sl"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": float(sl),
                "order_type": sl_type,
                "reduce_only": True,
            })

        try:
            resp = exchange.bulk_orders(
                [exchange._order_request_to_wire(r) for r in order_requests]
                if hasattr(exchange, "_order_request_to_wire")
                else order_requests,
                grouping="normalTpsl",
            )
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        result = _parse_order_response(resp, resolved, side_lower, size)
        output(result, opts["fields"])
    else:
        try:
            resp = exchange.order(resolved, is_buy, sz, px, order_type, reduce_only, cloid=sdk_cloid)
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        result = _parse_order_response(resp, resolved, side_lower, size)
        output(result, opts["fields"])


@hl_app.command()
def cancel(
    ctx: typer.Context,
    first: Annotated[str, typer.Argument(help="OID or asset name")],
    second: Annotated[Optional[str], typer.Argument(help="OID (if first is asset)")] = None,
    cloid: Annotated[Optional[str], typer.Option("--cloid", help="Cancel by client order ID")] = None,
    asset_opt: Annotated[Optional[str], typer.Option("--asset", help="Asset for cloid cancel")] = None,
):
    """Cancel a specific order."""
    opts = ctx.obj
    exchange = get_exchange(opts["testnet"])

    if cloid:
        # Cancel by client order ID
        if not asset_opt:
            die("validation_error", "MISSING_ARGUMENT", "Must specify --asset with --cloid", hint="regard hl cancel --cloid 0x... --asset BTC")
        resolver = get_resolver(exchange.info)
        resolved = resolver.resolve(asset_opt)
        from hyperliquid.utils.types import Cloid as SdkCloid
        resp = exchange.cancel_by_cloid(resolved, SdkCloid.from_str(cloid))
        output({"status": "cancelled", "asset": resolved, "cloid": cloid}, opts["fields"])
        return

    if second is not None:
        # hl cancel BTC 77738308
        resolver = get_resolver(exchange.info)
        resolved = resolver.resolve(first)
        oid = int(second)
        exchange.cancel(resolved, oid)
        output({"status": "cancelled", "oid": oid, "asset": resolved}, opts["fields"])
    else:
        # hl cancel 77738308 — auto-lookup asset from open orders
        oid = int(first)
        addr = get_address()
        open_orders = exchange.info.open_orders(addr)
        coin = None
        for o in open_orders:
            if o["oid"] == oid:
                coin = o["coin"]
                break
        if not coin:
            die("validation_error", "ORDER_NOT_FOUND", f"Order {oid} not found in open orders", hint=f"Pass asset explicitly: regard hl cancel BTC {oid}")
        exchange.cancel(coin, oid)
        output({"status": "cancelled", "oid": oid, "asset": coin}, opts["fields"])


@hl_app.command(name="cancel-all")
def cancel_all(
    ctx: typer.Context,
    asset: Annotated[Optional[str], typer.Argument(help="Cancel only this asset's orders")] = None,
):
    """Cancel all open orders."""
    opts = ctx.obj
    exchange = get_exchange(opts["testnet"])
    info = exchange.info
    addr = get_address()
    all_orders = get_all_orders(info, addr)

    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)
        all_orders = [o for o in all_orders if o["coin"] == resolved]

    if not all_orders:
        output({"cancelled": 0, "assets": []}, opts["fields"])
        return

    cancel_requests = [{"coin": o["coin"], "oid": o["oid"]} for o in all_orders]
    exchange.bulk_cancel(cancel_requests)

    assets_cancelled = sorted(set(o["coin"] for o in all_orders))
    output({"cancelled": len(all_orders), "assets": assets_cancelled}, opts["fields"])


@hl_app.command()
def leverage(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    lev: Annotated[int, typer.Argument(help="Leverage (integer)")],
    cross: Annotated[bool, typer.Option("--cross", help="Cross margin")] = False,
    isolated: Annotated[bool, typer.Option("--isolated", help="Isolated margin")] = False,
):
    """Set leverage for an asset."""
    opts = ctx.obj

    if cross and isolated:
        die("validation_error", "CONFLICTING_OPTIONS", "Cannot specify both --cross and --isolated")

    exchange = get_exchange(opts["testnet"])
    resolver = get_resolver(exchange.info)
    resolved = resolver.resolve(asset)

    is_cross = not isolated  # default is cross
    if is_cross and ":" in resolved:
        print("Warning: HIP-3 assets support isolated margin only. Using isolated.", file=sys.stderr)
        is_cross = False

    exchange.update_leverage(lev, resolved, is_cross)

    output({
        "asset": resolved,
        "leverage": lev,
        "margin_mode": "cross" if is_cross else "isolated",
    }, opts["fields"])


@hl_app.command()
def stop(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    price: Annotated[str, typer.Argument(help="Trigger price")],
    tp: Annotated[bool, typer.Option("--tp", help="Take profit instead of stop loss")] = False,
):
    """Set a stop loss (or take profit) on an existing position via trigger order."""
    opts = ctx.obj
    exchange = get_exchange(opts["testnet"])
    resolver = get_resolver(exchange.info)
    resolved = resolver.resolve(asset)

    # Look up the current position across all dexes (default + HIP-3)
    addr = get_address()
    all_pos = get_all_positions(exchange.info, addr)
    position = None
    for pos in all_pos:
        if pos["coin"] == resolved:
            position = pos
            break

    if not position:
        die("validation_error", "NO_POSITION", f"No open position for {resolved}",
            hint=f"Check positions: regard hl positions {asset}")

    size = abs(float(position["szi"]))
    is_long = float(position["szi"]) > 0
    trigger_px = float(price)

    # Validate trigger direction (shared with order --sl/--tp)
    mids = get_all_mids(exchange.info)
    mid = float(mids.get(resolved, "0"))
    _validate_trigger_direction(trigger_px, mid, is_long, is_tp=tp)

    # Warn if stop loss is inside liquidation price (stop will never trigger)
    warnings = []
    if not tp:
        liq_px_str = position.get("liquidationPx", "")
        if liq_px_str:
            liq_px = float(liq_px_str)
            if liq_px > 0:
                if is_long and liq_px > trigger_px:
                    warnings.append({
                        "code": "LIQ_ABOVE_STOP",
                        "message": f"Liquidation at {liq_px:.6g} — any stop below that will never trigger (yours: {trigger_px:.6g})",
                        "liq_price": liq_px,
                    })
                elif not is_long and liq_px < trigger_px:
                    warnings.append({
                        "code": "LIQ_BELOW_STOP",
                        "message": f"Liquidation at {liq_px:.6g} — any stop above that will never trigger (yours: {trigger_px:.6g})",
                        "liq_price": liq_px,
                    })

    tpsl = "tp" if tp else "sl"
    trigger_type = {"trigger": {"triggerPx": trigger_px, "isMarket": True, "tpsl": tpsl}}

    # Trigger order: opposite side, reduce-only, at trigger price
    is_buy = not is_long  # close a long = sell, close a short = buy
    resp = exchange.order(resolved, is_buy, size, trigger_px, trigger_type, reduce_only=True)
    result = _parse_order_response(resp, resolved, "sell" if is_long else "buy", str(size))
    result["trigger_price"] = price
    result["type"] = "take_profit" if tp else "stop_loss"
    result["position_side"] = "long" if is_long else "short"
    if warnings:
        result["warnings"] = warnings
    output(result, opts["fields"])


@hl_app.command()
def transfer(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[Optional[str], typer.Option("--token", help="Token name (required for spot transfers, e.g. USDH)")] = None,
    to: Annotated[Optional[str], typer.Option("--to", help="Destination: dex name or 'spot'")] = None,
    from_dex: Annotated[Optional[str], typer.Option("--from", help="Source: dex name or 'spot'")] = None,
):
    """Transfer funds between perp dexes or spot (e.g. default ↔ xyz, default ↔ spot)."""
    opts = ctx.obj

    if not to and not from_dex:
        die("validation_error", "MISSING_OPTION", "Specify --to or --from dex name",
            hint="regard hl transfer 5.00 --to xyz  OR  regard hl transfer 1.0 --to spot --token USDC")

    source = from_dex or ""
    dest = to or ""
    # Normalize "default" → "" (API uses empty string for default dex)
    if source == "default":
        source = ""
    if dest == "default":
        dest = ""
    source_label = source or "default"
    dest_label = dest or "default"
    is_spot = source == "spot" or dest == "spot"

    exchange = get_exchange(opts["testnet"])
    info = get_info(opts["testnet"])
    addr = get_address()

    if is_spot:
        # Spot transfers require explicit token name
        if not token:
            # Default to USDC for perp→spot transfers
            if source != "spot":
                token = "USDC"
            else:
                die("validation_error", "MISSING_TOKEN",
                    "Specify --token for spot transfers (e.g. --token USDH)",
                    exit_code=2)
        token_name = token
    else:
        # Perp-to-perp: resolve collateral token from dex metadata
        collateral_map = get_collateral_map(info)
        src_token = collateral_map.get(source, ("USDC", 0))
        dst_token = collateral_map.get(dest, ("USDC", 0))

        if src_token[1] != dst_token[1]:
            die("validation_error", "COLLATERAL_MISMATCH",
                f"{source_label} dex uses {src_token[0]} but {dest_label} dex uses {dst_token[0]} — "
                f"cannot transfer between dexes with different collateral tokens",
                exit_code=2)
        token_name = token or src_token[0]

    # Check source balance — use withdrawable (not accountValue) to avoid
    # draining margin from open positions which would trigger liquidation.
    # Skip for spot — harder to validate.
    if source != "spot":
        try:
            state = exchange.info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": source})
            available = float(state.get("withdrawable", "0"))
            transfer_amount = float(amount)
            if transfer_amount > available:
                die("venue_error", "INSUFFICIENT_BALANCE",
                    f"{source_label} dex has ${available:.2f} withdrawable {token_name}, cannot transfer ${transfer_amount:.2f}",
                    hint="Some balance may be locked as margin for open positions",
                    exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass

    # Execute transfer
    try:
        resp = exchange.send_asset(addr, source, dest, token_name, float(amount))
        if resp.get("status") == "err":
            die("venue_error", "TRANSFER_FAILED", resp.get("response", str(resp)), exit_code=4)
    except Exception as e:
        die("venue_error", "TRANSFER_FAILED", str(e), exit_code=4)

    output({
        "amount": amount,
        "from_dex": source_label,
        "to_dex": dest_label,
        "token": token_name,
    }, opts["fields"])


@hl_app.command()
def preflight(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    side: Annotated[str, typer.Argument(help="buy/long or sell/short")],
    size: Annotated[str, typer.Argument(help="Size to check")],
    sl: Annotated[Optional[str], typer.Option("--sl", help="Planned stop loss price")] = None,
):
    """Pre-trade risk check: margin, leverage, liq price, position sizing, warnings."""
    opts = ctx.obj

    side_lower = side.lower()
    if side_lower not in SIDE_MAP:
        die("validation_error", "INVALID_SIDE", f"Invalid side: {side}", hint="Use buy/long or sell/short", param="side")

    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)
    addr = get_address()
    dex = get_dex_for_coin(resolved)
    is_buy = SIDE_MAP[side_lower]
    idx = 0 if is_buy else 1

    # Get active asset data (max trade sizes, available margin)
    asset_data = get_active_asset_data(info, addr, resolved)

    result = {
        "asset": resolved,
        "dex": dex or "default",
        "side": side_lower,
        "requested_size": size,
    }

    warnings = []

    if asset_data:
        max_szs = asset_data.get("maxTradeSzs", ["0", "0"])
        avail = asset_data.get("availableToTrade", ["0", "0"])
        mark_px = float(asset_data.get("markPx", "0"))
        lev_info = asset_data.get("leverage", {})
        lev_value = lev_info.get("value", 1)
        lev_type = lev_info.get("type", "cross")

        result["mark_px"] = asset_data.get("markPx", "")
        result["leverage"] = lev_info
        result["max_size"] = max_szs[idx]
        result["available_to_trade"] = avail[idx]
        result["can_trade"] = float(max_szs[idx]) >= float(size)

        # --- Risk metrics ---
        sz = float(size)

        # Notional exposure
        notional = sz * mark_px
        result["notional"] = round(notional, 2)

        # Equity — for unified accounts, use total account value (includes spot),
        # not dex-specific balance which is misleadingly small.
        try:
            acct_mode = get_account_mode(info, addr)
            if acct_mode == "unifiedAccount":
                state = info.user_state(addr)
            else:
                dex_name = dex or ""
                state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex_name})
            margin = state.get("marginSummary", state.get("crossMarginSummary", {}))
            equity = float(margin.get("accountValue", "0"))
            result["equity"] = round(equity, 2)
            if equity > 0:
                notional_pct = (notional / equity) * 100
                result["notional_pct"] = round(notional_pct, 1)
                if notional_pct > 50:
                    warnings.append({
                        "code": "HIGH_NOTIONAL",
                        "message": f"{notional_pct:.1f}% of equity in one trade (${notional:.2f} / ${equity:.2f})",
                    })
        except Exception:
            pass

        # Margin required (approximate)
        if lev_value > 0:
            result["margin_required"] = round(notional / lev_value, 2)

        # Liquidation price estimate (isolated only — cross liq depends on full portfolio)
        if mark_px > 0 and lev_value > 0:
            if lev_type == "isolated":
                if is_buy:
                    liq_est = mark_px * (1 - 1 / lev_value)
                else:
                    liq_est = mark_px * (1 + 1 / lev_value)
                result["liq_price_est"] = round(liq_est, 6)
            else:
                result["liq_price_est"] = None  # cross: depends on portfolio

        # Stop loss analysis
        if sl is not None:
            sl_px = float(sl)
            result["stop_price"] = sl
            max_loss = sz * abs(mark_px - sl_px)
            result["max_loss"] = round(max_loss, 2)

            # Check liq vs stop
            liq_est = result.get("liq_price_est")
            if liq_est is not None:
                if is_buy and liq_est > sl_px:
                    safe_lev = max(1, int(mark_px / (mark_px - sl_px * 0.95)))
                    warnings.append({
                        "code": "LIQ_ABOVE_STOP",
                        "message": f"Liquidation at {liq_est:.6g} — any stop below that will never trigger (yours: {sl_px:.6g})",
                        "liq_price": liq_est,
                        "suggested_leverage": safe_lev,
                    })
                elif not is_buy and liq_est < sl_px:
                    safe_lev = max(1, int(mark_px / (sl_px * 1.05 - mark_px)))
                    warnings.append({
                        "code": "LIQ_BELOW_STOP",
                        "message": f"Liquidation at {liq_est:.6g} — any stop above that will never trigger (yours: {sl_px:.6g})",
                        "liq_price": liq_est,
                        "suggested_leverage": safe_lev,
                    })
    else:
        result["can_trade"] = False
        result["error"] = "Could not fetch asset data"

    # If can't trade on HIP-3, check dex balance
    if not result.get("can_trade") and dex:
        try:
            dex_state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex})
            dex_margin = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {}))
            dex_val = dex_margin.get("accountValue", "0")
            result["dex_balance"] = dex_val
            if float(dex_val) == 0:
                result["recovery"] = {
                    "action": "transfer_funds",
                    "dex": dex,
                    "command": f"regard hl transfer <amount> --to {dex}",
                }
        except Exception:
            pass

    # Existing position check
    try:
        all_pos = get_all_positions(info, addr)
        for pos in all_pos:
            if pos["coin"] == resolved:
                pos_size = float(pos["szi"])
                result["existing_position"] = {
                    "side": "long" if pos_size > 0 else "short",
                    "size": abs(pos_size),
                    "entry_px": pos.get("entryPx", ""),
                    "unrealized_pnl": pos.get("unrealizedPnl", ""),
                    "liq_price": pos.get("liquidationPx", ""),
                }
                warnings.append({
                    "code": "EXISTING_POSITION",
                    "message": f"Already {'long' if pos_size > 0 else 'short'} {abs(pos_size)} {resolved} from {pos.get('entryPx', '?')}",
                })
                break
    except Exception:
        pass

    result["warnings"] = warnings

    # Build display
    lines = [f"Preflight: {side_lower} {size} {resolved}"]
    lines.append(f"  Mark price     {result.get('mark_px', '?')}")
    lev = result.get("leverage", {})
    if lev:
        lines.append(f"  Leverage       {lev.get('value', '?')}x {lev.get('type', '')}")
    lines.append(f"  Can trade      {'yes' if result.get('can_trade') else 'NO'}")
    if "notional" in result:
        lines.append(f"  Notional       ${result['notional']}")
    if "equity" in result:
        lines.append(f"  Equity         ${result['equity']}")
    if "notional_pct" in result:
        lines.append(f"  Exposure       {result['notional_pct']}% of equity")
    if "margin_required" in result:
        lines.append(f"  Margin req     ${result['margin_required']}")
    if result.get("liq_price_est") is not None:
        lines.append(f"  Liq price est  {result['liq_price_est']:.6g}")
    elif result.get("liq_price_est") is None and lev.get("type") == "cross":
        lines.append(f"  Liq price est  n/a (cross margin — depends on portfolio)")
    if sl is not None:
        lines.append(f"  Stop loss      {sl}")
    if "max_loss" in result:
        lines.append(f"  Max loss       ${result['max_loss']}")
    if result.get("existing_position"):
        ep = result["existing_position"]
        lines.append(f"  Existing pos   {ep['side']} {ep['size']} @ {ep['entry_px']}")
    if warnings:
        lines.append("")
        for w in warnings:
            lines.append(f"  ⚠ {w['code']}: {w['message']}")
            if "suggested_leverage" in w:
                lines.append(f"    → Suggested leverage: {w['suggested_leverage']}x")
    result["display"] = "\n".join(lines)

    output(result, opts["fields"])
