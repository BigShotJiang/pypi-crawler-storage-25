"""Auth setup — secure credential onboarding via real terminal (read -s)."""

import getpass
import json
import os
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer

auth_app = typer.Typer(
    name="auth",
    no_args_is_help=True,
    help="Credential setup for trading venues.",
)


def _find_settings_path() -> Path:
    """Global Claude Code settings — works across all projects."""
    return Path.home() / ".claude" / "settings.local.json"


def _save_env_var(key: str, value: str, settings_path: Path):
    """Merge an env var into settings.local.json."""
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    settings = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    settings.setdefault("env", {})[key] = value
    settings_path.write_text(json.dumps(settings, indent=2) + "\n")


def _validate_hex_key(key: str) -> str:
    """Validate and normalize a hex private key."""
    key = key.strip()
    if key.startswith("0x"):
        key = key[2:]
    if len(key) != 64:
        return ""
    try:
        int(key, 16)
    except ValueError:
        return ""
    return "0x" + key


@auth_app.command()
def hl(
    key: Annotated[Optional[str], typer.Argument(help="Private key (or omit to enter interactively)")] = None,
):
    """Set up Hyperliquid trading credentials.

    Run this in a regular terminal (not inside Claude Code).
    Your key is saved to ~/.claude/settings.local.json (global)
    and never appears in any conversation transcript.
    """
    if not key:
        if not sys.stdin.isatty():
            print("Error: this command requires an interactive terminal.", file=sys.stderr)
            print("Run it in a regular terminal, not inside Claude Code.", file=sys.stderr)
            raise SystemExit(1)

        print()
        print("  Regard — Hyperliquid credential setup")
        print()
        print("  You can use either key type:")
        print()
        print("    Agent wallet key  — can trade, cannot transfer funds")
        print("    Master wallet key — full access (trade + fund management)")
        print()
        print("  Create an agent wallet: https://app.hyperliquid.xyz/API")
        print()

        key = getpass.getpass("  Paste your key (input is hidden): ")

    normalized = _validate_hex_key(key)
    if not normalized:
        print()
        print("  Invalid key. Expected 0x + 64 hex characters.", file=sys.stderr)
        raise SystemExit(1)

    # Detect key type via userRole API
    try:
        import eth_account
        from hyperliquid.info import Info
        from hyperliquid.utils.constants import MAINNET_API_URL

        address = eth_account.Account.from_key(normalized).address
        info = Info(MAINNET_API_URL, skip_ws=True)
        role_result = info.post("/info", {"type": "userRole", "user": address})
        role = role_result.get("role", "unknown")

        if role == "agent":
            master = role_result["data"]["user"]
            env_var = "HYPERLIQUID_AGENT_KEY"
            print()
            print(f"  Agent wallet detected.")
            print(f"  Master account: {master}")
            print(f"  Mode: trade only (transfers require Hyperliquid web UI)")
        else:
            env_var = "HYPERLIQUID_PRIVATE_KEY"
            print()
            print(f"  Master wallet detected.")
            print(f"  Address: {address}")
            print(f"  Mode: full access (trade + fund management)")
    except Exception as e:
        # Fallback: can't detect, default to agent key
        env_var = "HYPERLIQUID_AGENT_KEY"
        print()
        print(f"  Could not detect key type ({e}). Saving as agent key.")

    # Save to settings.local.json
    settings_path = _find_settings_path()
    _save_env_var(env_var, normalized, settings_path)

    # Remove the other key type if present (avoid conflicts)
    other_var = "HYPERLIQUID_PRIVATE_KEY" if env_var == "HYPERLIQUID_AGENT_KEY" else "HYPERLIQUID_AGENT_KEY"
    try:
        settings = json.loads(settings_path.read_text())
        if other_var in settings.get("env", {}):
            del settings["env"][other_var]
            settings_path.write_text(json.dumps(settings, indent=2) + "\n")
    except Exception:
        pass

    print()
    print(f"  Saved to {settings_path}")
    print()
    print("  Return to Claude Code — your key is ready.")
    print("  If Claude Code was already running, the key is")
    print("  picked up automatically on the next command.")
    print()


@auth_app.command()
def poly(
    key: Annotated[Optional[str], typer.Argument(help="Private key (or omit to enter interactively)")] = None,
):
    """Set up Polymarket trading credentials.

    Run this in a regular terminal (not inside Claude Code).
    Uses the same Polygon wallet key for CLOB API auth.
    CLOB credentials are derived at runtime — no separate API key needed.
    """
    if not key:
        if not sys.stdin.isatty():
            print("Error: this command requires an interactive terminal.", file=sys.stderr)
            print("Run it in a regular terminal, not inside Claude Code.", file=sys.stderr)
            raise SystemExit(1)

        print()
        print("  Regard — Polymarket credential setup")
        print()
        print("  Enter your Polygon wallet private key.")
        print("  This is the same key used for Hyperliquid if you share the wallet.")
        print()
        print("  CLOB API credentials are derived automatically from this key.")
        print("  No separate Polymarket API key is needed.")
        print()
        print("  Note: Polymarket trading is geo-restricted.")
        print("  You need a Dublin VPN for order placement.")
        print()

        key = getpass.getpass("  Paste your key (input is hidden): ")

    normalized = _validate_hex_key(key)
    if not normalized:
        print()
        print("  Invalid key. Expected 0x + 64 hex characters.", file=sys.stderr)
        raise SystemExit(1)

    try:
        import eth_account
        address = eth_account.Account.from_key(normalized).address
        print()
        print(f"  Polygon address: {address}")
    except Exception:
        print()
        print("  Could not derive address. Saving key anyway.")

    settings_path = _find_settings_path()
    _save_env_var("POLYMARKET_PRIVATE_KEY", normalized, settings_path)

    print()
    print(f"  Saved to {settings_path}")
    print()
    print("  Return to Claude Code — your key is ready.")
    print()
    print("  Note: Polymarket trading is geo-restricted.")
    print("  Order placement requires a non-US/non-SG IP (e.g. Ireland).")
    print()


@auth_app.command()
def check():
    """Check which venues have credentials configured."""
    result = {"venues": {}}

    # Fallback: read from settings file if env vars missing
    from hl_cli.client import _load_settings_env
    settings_env = _load_settings_env()

    # Hyperliquid
    hl_agent = os.environ.get("HYPERLIQUID_AGENT_KEY") or settings_env.get("HYPERLIQUID_AGENT_KEY")
    hl_master = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or settings_env.get("HYPERLIQUID_PRIVATE_KEY")

    if hl_agent or hl_master:
        mode = "agent" if hl_agent else "master"
        try:
            import eth_account
            from hyperliquid.info import Info
            from hyperliquid.utils.constants import MAINNET_API_URL

            key = hl_agent or hl_master
            address = eth_account.Account.from_key(key).address
            info = Info(MAINNET_API_URL, skip_ws=True)

            if hl_agent:
                role_result = info.post("/info", {"type": "userRole", "user": address})
                if role_result.get("role") == "agent":
                    master = role_result["data"]["user"]
                    result["venues"]["hyperliquid"] = {
                        "configured": True, "mode": "agent",
                        "agent_address": address, "master_address": master,
                    }
                else:
                    result["venues"]["hyperliquid"] = {
                        "configured": True, "mode": "agent", "address": address,
                    }
            else:
                result["venues"]["hyperliquid"] = {
                    "configured": True, "mode": "master", "address": address,
                }
        except Exception:
            result["venues"]["hyperliquid"] = {"configured": True, "mode": mode}
    else:
        result["venues"]["hyperliquid"] = {
            "configured": False,
            "setup_command": "regard auth hl",
        }

    # Polymarket
    poly_key = os.environ.get("POLYMARKET_PRIVATE_KEY") or settings_env.get("POLYMARKET_PRIVATE_KEY")
    if poly_key:
        try:
            import eth_account
            address = eth_account.Account.from_key(poly_key).address
            result["venues"]["polymarket"] = {
                "configured": True, "address": address,
            }
        except Exception:
            result["venues"]["polymarket"] = {"configured": True}
    else:
        result["venues"]["polymarket"] = {
            "configured": False,
            "setup_command": "regard auth poly",
        }

    from hl_cli.output import output as _output
    _output(result, None)


@auth_app.command()
def sync(
    export: Annotated[bool, typer.Option("--export", help="Output export commands for eval")] = False,
):
    """Sync credentials from global to project settings.

    Without --export: writes to project .claude/settings.local.json (JSON output).
    With --export: outputs shell export commands for eval (no JSON, for sourcing).

    Usage from Claude Code skill:
      eval "$(regard auth sync --export)" && regard hl status
    """
    global_path = Path.home() / ".claude" / "settings.local.json"
    project_path = Path.cwd() / ".claude" / "settings.local.json"

    if not global_path.exists():
        if export:
            print("echo 'No global settings. Run regard auth hl first.' >&2; false", end="")
            raise SystemExit(3)
        from hl_cli.output import die as _die
        _die("auth_error", "NO_GLOBAL_SETTINGS",
             "No global settings found. Run 'regard auth hl' first.",
             exit_code=3)

    try:
        global_settings = json.loads(global_path.read_text())
    except (json.JSONDecodeError, OSError):
        if export:
            print("echo 'Could not read global settings.' >&2; false", end="")
            raise SystemExit(7)
        from hl_cli.output import die as _die
        _die("internal_error", "INVALID_SETTINGS",
             "Could not read global settings.",
             exit_code=7)

    # Extract venue credential env vars
    venue_keys = {k: v for k, v in global_settings.get("env", {}).items()
                  if any(venue in k for venue in ("HYPERLIQUID", "POLYMARKET"))}

    if not venue_keys:
        if export:
            print("echo 'No credentials found. Run regard auth hl first.' >&2; false", end="")
            raise SystemExit(3)
        from hl_cli.output import die as _die
        _die("auth_error", "NO_CREDENTIALS",
             "No venue credentials in global settings. Run 'regard auth hl' first.",
             exit_code=3)

    # Merge into project settings
    project_path.parent.mkdir(parents=True, exist_ok=True)
    project_settings = {}
    if project_path.exists():
        try:
            project_settings = json.loads(project_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    project_settings.setdefault("env", {}).update(venue_keys)
    project_path.write_text(json.dumps(project_settings, indent=2) + "\n")

    if export:
        # Output export commands — consumed by eval, never appears in stdout
        for k, v in venue_keys.items():
            print(f"export {k}={v}")
    else:
        from hl_cli.output import output as _output
        _output({"synced": len(venue_keys), "path": str(project_path)}, None)
