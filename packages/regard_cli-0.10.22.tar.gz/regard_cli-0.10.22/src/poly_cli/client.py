"""Client factory — creates Polymarket CLOB and Gamma API clients."""

import os

import eth_account
import httpx

from hl_cli.output import die

GAMMA_BASE_URL = "https://gamma-api.polymarket.com"
CLOB_BASE_URL = "https://clob.polymarket.com"
DEFAULT_POLYGON_RPC = "https://rpc.regard.computer/regard/evm/137"

# Polymarket Polygon mainnet contracts
CONTRACTS = {
    "USDC_E": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
    "CTF": "0x4D97DCd97eC945f40cF65F87097ACe5EA0476045",
    "CTF_EXCHANGE": "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E",
    "NEG_RISK_CTF_EXCHANGE": "0xC5d563A36AE78145C45a50134d48A1215220f80a",
    "NEG_RISK_ADAPTER": "0xd91E80cF2E7be2e162c6513ceD06f1dD0dA35296",
}

ERC20_ABI = [
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}], "name": "balanceOf", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}, {"name": "_spender", "type": "address"}], "name": "allowance", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
    {"constant": False, "inputs": [{"name": "_spender", "type": "address"}, {"name": "_value", "type": "uint256"}], "name": "approve", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
]

CTF_ABI = [
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}, {"name": "_operator", "type": "address"}], "name": "isApprovedForAll", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
    {"constant": False, "inputs": [{"name": "_operator", "type": "address"}, {"name": "_approved", "type": "bool"}], "name": "setApprovalForAll", "outputs": [], "type": "function"},
]

EXCHANGE_ABI = [
    {"constant": True, "inputs": [], "name": "getCollateral", "outputs": [{"name": "", "type": "address"}], "type": "function"},
]

# Known token names by address (for display)
TOKEN_NAMES = {
    "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174": "USDC.e",
    "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359": "USDC",
}


def _get_key() -> str:
    key = os.environ.get("POLYMARKET_PRIVATE_KEY")
    if not key:
        # Fallback: read from settings file directly
        from hl_cli.client import _load_settings_env
        key = _load_settings_env().get("POLYMARKET_PRIVATE_KEY")
    if not key:
        die(
            "auth_error", "NO_KEY",
            "No Polymarket key set",
            hint="Run 'regard auth poly' in a separate terminal to set up credentials",
            exit_code=3,
        )
    return key


def get_address(explicit: str = None) -> str:
    """Get Polygon wallet address. Priority: explicit arg > derived from key."""
    if explicit:
        return explicit
    key = _get_key()
    return eth_account.Account.from_key(key).address


def get_gamma_client() -> httpx.Client:
    """Create Gamma API client (unauthenticated, no geo-restriction)."""
    return httpx.Client(base_url=GAMMA_BASE_URL, timeout=30.0)


def get_clob_client():
    """Create authenticated CLOB client with derived API credentials.

    Geo-restricted — will fail from blocked regions (US, Singapore, etc.).
    Use Dublin VPN for trading.
    """
    from py_clob_client.client import ClobClient

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    address = eth_account.Account.from_key(key).address

    client = ClobClient(
        CLOB_BASE_URL,
        key=key,
        chain_id=137,
        signature_type=0,
        funder=address,
    )
    creds = client.create_or_derive_api_creds()
    client.set_api_creds(creds)
    return client


def get_web3():
    """Create Web3 client for Polygon mainnet.

    Uses POLYGON_RPC from settings if set (with eRPC as fallback),
    otherwise the default eRPC endpoint.
    """
    from web3 import Web3
    from hl_cli.client import _load_settings_env

    custom = _load_settings_env().get("POLYGON_RPC")
    rpcs = [custom, DEFAULT_POLYGON_RPC] if custom else [DEFAULT_POLYGON_RPC]

    for rpc_url in rpcs:
        try:
            w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 10}))
            if w3.is_connected():
                return w3
        except Exception:
            continue

    return Web3(Web3.HTTPProvider(DEFAULT_POLYGON_RPC, request_kwargs={"timeout": 30}))


def get_collateral_token(w3=None) -> dict:
    """Discover the collateral token Polymarket uses.

    Reads on-chain from CTF Exchange getCollateral(). Falls back to
    hardcoded USDC.e address if RPC is unavailable.

    Returns {"address": "0x...", "name": "USDC.e", "source": "on-chain"|"fallback"}.
    """
    from web3 import Web3

    if w3 is None:
        w3 = get_web3()

    fallback = CONTRACTS["USDC_E"]

    try:
        exchange = w3.eth.contract(
            address=w3.to_checksum_address(CONTRACTS["CTF_EXCHANGE"]),
            abi=EXCHANGE_ABI,
        )
        address = exchange.functions.getCollateral().call()
        name = TOKEN_NAMES.get(address, "unknown")

        if address.lower() != fallback.lower():
            import sys
            print(f"warning: collateral token changed to {name} ({address})", file=sys.stderr)

        return {"address": address, "name": name, "source": "on-chain"}
    except Exception:
        return {"address": fallback, "name": "USDC.e", "source": "fallback"}


USDC_NATIVE = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"


def get_wallet_balances(w3=None, address=None) -> dict:
    """Get on-chain wallet balances on Polygon (USDC.e, USDC native, POL).

    Returns {"usdc_e": "0.00", "usdc": "5.00", "pol": "2.94", "rpc_ok": true}.
    Sets rpc_ok=false if RPC is unreachable — balances may be stale/wrong.
    """
    if w3 is None:
        w3 = get_web3()
    if address is None:
        address = get_address()

    checksummed = w3.to_checksum_address(address)
    result = {"usdc_e": "0.00", "usdc": "0.00", "pol": "0.00", "rpc_ok": False}

    ok = False
    try:
        pol_wei = w3.eth.get_balance(checksummed)
        result["pol"] = f"{pol_wei / 1e18:.4f}"
        ok = True
    except Exception:
        pass
    try:
        usdc_e = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["USDC_E"]), abi=ERC20_ABI)
        result["usdc_e"] = f"{usdc_e.functions.balanceOf(checksummed).call() / 1e6:.2f}"
        ok = True
    except Exception:
        pass
    try:
        usdc = w3.eth.contract(address=w3.to_checksum_address(USDC_NATIVE), abi=ERC20_ABI)
        result["usdc"] = f"{usdc.functions.balanceOf(checksummed).call() / 1e6:.2f}"
        ok = True
    except Exception:
        pass

    result["rpc_ok"] = ok
    return result


def check_geo_block():
    """Check if CLOB trading is accessible from current IP.

    Calls a lightweight CLOB endpoint. Dies with actionable hint if blocked.
    """
    try:
        resp = httpx.get(f"{CLOB_BASE_URL}/time", timeout=10.0)
        if resp.status_code == 403:
            die(
                "geo_error", "GEO_BLOCKED",
                "Polymarket trading is restricted from your region",
                hint="Polymarket trading requires a non-US/non-SG IP (e.g. Ireland VPN)",
                exit_code=4,
            )
    except httpx.HTTPError:
        pass  # network error, let the actual trade call handle it
