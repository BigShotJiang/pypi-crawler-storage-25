"""Shared test fixtures — mock SDK, CliRunner, patched client imports."""

import pytest
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

import hl_cli.resolver as resolver_mod

# ---------------------------------------------------------------------------
# Mock data — realistic shapes matching the real Hyperliquid API responses
# ---------------------------------------------------------------------------

MIDS = {"BTC": "69666.5", "ETH": "3250.0", "SOL": "140.0", "xyz:TSLA": "350.0"}

USER_STATE = {
    "crossMarginSummary": {
        "accountValue": "10000.00",
        "totalMarginUsed": "500.00",
        "totalNtlPos": "5000.00",
    },
    "withdrawable": "9500.00",
    "assetPositions": [
        {
            "position": {
                "coin": "BTC",
                "szi": "0.05",
                "entryPx": "68000.00",
                "unrealizedPnl": "83.33",
                "liquidationPx": "62000.00",
                "leverage": {"type": "cross", "value": 10},
                "marginUsed": "340.00",
            }
        },
        {
            "position": {
                "coin": "ETH",
                "szi": "-1.0",
                "entryPx": "3300.00",
                "unrealizedPnl": "50.00",
                "liquidationPx": "3800.00",
                "leverage": {"type": "cross", "value": 5},
                "marginUsed": "660.00",
            }
        },
    ],
}

OPEN_ORDERS = [
    {
        "coin": "BTC",
        "oid": 100001,
        "side": "B",
        "limitPx": "65000.0",
        "sz": "0.01",
        "orderType": "Limit",
        "tif": "Gtc",
        "reduceOnly": False,
        "timestamp": 1773000000000,
    },
    {
        "coin": "ETH",
        "oid": 100002,
        "side": "A",
        "limitPx": "3500.0",
        "sz": "0.5",
        "orderType": "Limit",
        "tif": "Gtc",
        "reduceOnly": True,
        "timestamp": 1773000000000,
    },
]

META_AND_ASSET_CTXS = [
    {
        "universe": [
            {"name": "BTC", "maxLeverage": 50},
            {"name": "ETH", "maxLeverage": 50},
            {"name": "SOL", "maxLeverage": 20},
        ]
    },
    [
        {
            "markPx": "69661.0",
            "oraclePx": "69693.0",
            "prevDayPx": "70363.0",
            "funding": "0.0001",
            "openInterest": "12500000.00",
            "dayNtlVlm": "850000000.00",
            "premium": "0.0002",
        },
        {
            "markPx": "3248.0",
            "oraclePx": "3252.0",
            "prevDayPx": "3200.0",
            "funding": "0.00005",
            "openInterest": "5000000.00",
            "dayNtlVlm": "300000000.00",
            "premium": "0.0001",
        },
        {
            "markPx": "139.5",
            "oraclePx": "140.2",
            "prevDayPx": "142.0",
            "funding": "-0.0002",
            "openInterest": "2000000.00",
            "dayNtlVlm": "100000000.00",
            "premium": "-0.0001",
        },
    ],
]

L2_SNAPSHOT = {
    "levels": [
        [
            {"px": "69660.0", "sz": "2.50", "n": 3},
            {"px": "69659.0", "sz": "1.20", "n": 1},
            {"px": "69658.0", "sz": "0.80", "n": 2},
        ],
        [
            {"px": "69662.0", "sz": "1.80", "n": 2},
            {"px": "69663.0", "sz": "3.10", "n": 4},
            {"px": "69664.0", "sz": "0.50", "n": 1},
        ],
    ]
}

FUNDING_HISTORY = [
    {"fundingRate": "0.0001", "premium": "0.0002", "time": 1773000000000},
    {"fundingRate": "0.00012", "premium": "0.00015", "time": 1772971200000},
    {"fundingRate": "0.00008", "premium": "0.00010", "time": 1772942400000},
]

CANDLES = [
    {
        "t": 1773000000000, "o": "69000.0", "h": "69800.0",
        "l": "68900.0", "c": "69666.0", "v": "1250.5", "n": 4521,
    },
    {
        "t": 1772913600000, "o": "68500.0", "h": "69200.0",
        "l": "68400.0", "c": "69000.0", "v": "980.3", "n": 3200,
    },
]

USER_FILLS = [
    {
        "coin": "BTC", "side": "B", "dir": "Open Long",
        "px": "69000.0", "sz": "0.1", "fee": "3.105",
        "closedPnl": "0.0", "time": 1773000000000,
    },
    {
        "coin": "ETH", "side": "A", "dir": "Open Short",
        "px": "3300.0", "sz": "1.0", "fee": "1.485",
        "closedPnl": "0.0", "time": 1772990000000,
    },
]

SPOT_USER_STATE = {
    "balances": [
        {"token": 0, "holds": "100000000000", "withdrawn": "0"},       # USDC: 1000.0 (8 weiDecimals)
        {"token": 1, "holds": "500000000000000000", "withdrawn": "0"},  # HYPE: 0.5 (18 weiDecimals)
        {"token": 2, "holds": "0", "withdrawn": "0"},                   # zero balance, filtered
    ]
}

SPOT_META = {
    "tokens": [
        {"name": "USDC", "szDecimals": 2, "weiDecimals": 8, "index": 0, "tokenId": "0x1", "isCanonical": True},
        {"name": "HYPE", "szDecimals": 2, "weiDecimals": 18, "index": 1, "tokenId": "0x2", "isCanonical": True},
        {"name": "PURR", "szDecimals": 0, "weiDecimals": 18, "index": 2, "tokenId": "0x3", "isCanonical": True},
    ],
    "universe": [
        {"tokens": [1, 0], "name": "HYPE/USDC", "index": 0, "isCanonical": True},
        {"tokens": [2, 0], "name": "PURR/USDC", "index": 1, "isCanonical": True},
    ],
}

SPOT_META_AND_ASSET_CTXS = [
    SPOT_META,
    [
        {
            "markPx": "39.50", "prevDayPx": "38.00",
            "dayNtlVlm": "5000000.00", "midPx": "39.45",
            "circulatingSupply": "333000000", "coin": "HYPE/USDC",
        },
        {
            "markPx": "0.078", "prevDayPx": "0.082",
            "dayNtlVlm": "300000.00", "midPx": "0.0775",
            "circulatingSupply": "1000000000", "coin": "PURR/USDC",
        },
    ],
]

MOCK_SPOT_BALANCES = [
    {"token": "USDC", "balance": "1000.00", "token_index": 0},
    {"token": "HYPE", "balance": "0.50", "token_index": 1},
]

MOCK_DEX_BALANCES = [
    {"dex": "default", "account_value": "10000.00", "positions": 2},
]

ACTIVE_ASSET_DATA = {
    "user": "0xTEST",
    "coin": "BTC",
    "leverage": {"type": "cross", "value": 10},
    "maxTradeSzs": ["100.0", "100.0"],
    "availableToTrade": ["50.0", "50.0"],
    "markPx": "69666.0",
}

ACTIVE_ASSET_DATA_EMPTY = {
    "user": "0xTEST",
    "coin": "xyz:CL",
    "leverage": {"type": "isolated", "value": 20, "rawUsd": "0.0"},
    "maxTradeSzs": ["0.0", "0.0"],
    "availableToTrade": ["0.0", "0.0"],
    "markPx": "100.50",
}

ORDER_RESPONSE_FILLED = {
    "status": "ok",
    "response": {
        "type": "order",
        "data": {
            "statuses": [
                {"filled": {"oid": 200001, "totalSz": "0.1", "avgPx": "69666.0"}}
            ]
        },
    },
}

ORDER_RESPONSE_RESTING = {
    "status": "ok",
    "response": {
        "type": "order",
        "data": {
            "statuses": [
                {"resting": {"oid": 200002}}
            ]
        },
    },
}

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_info():
    info = MagicMock()
    info.coin_to_asset = {"BTC": 0, "ETH": 1, "SOL": 2, "xyz:TSLA": 110001}
    info.all_mids.return_value = dict(MIDS)
    info.user_state.return_value = USER_STATE
    info.frontend_open_orders.return_value = list(OPEN_ORDERS)
    info.open_orders.return_value = [
        {"coin": o["coin"], "oid": o["oid"]} for o in OPEN_ORDERS
    ]
    info.meta_and_asset_ctxs.return_value = META_AND_ASSET_CTXS
    info.l2_snapshot.return_value = L2_SNAPSHOT
    info.funding_history.return_value = list(FUNDING_HISTORY)
    info.candles_snapshot.return_value = list(CANDLES)
    info.user_fills.return_value = list(USER_FILLS)
    info.user_fills_by_time.return_value = list(USER_FILLS)
    # perpDexs / allPerpMetas: default + xyz dex for HIP-3 testing
    def _mock_post(endpoint, payload):
        req_type = payload.get("type", "")
        if req_type == "perpDexs":
            return [{"name": "default"}, {"name": "xyz"}]
        if req_type == "allPerpMetas":
            return [
                {"universe": [{"name": "BTC", "maxLeverage": 50}], "collateralToken": 0},
                {"universe": [{"name": "xyz:TSLA", "maxLeverage": 10}], "collateralToken": 0},
            ]
        if req_type == "metaAndAssetCtxs":
            dex = payload.get("dex", "")
            if dex == "xyz":
                return [
                    {"universe": [{"name": "xyz:TSLA", "maxLeverage": 10}]},
                    [{"markPx": "350.0", "oraclePx": "351.0", "prevDayPx": "340.0",
                      "funding": "0.00005", "openInterest": "50000", "dayNtlVlm": "10000000",
                      "premium": "0.0001"}],
                ]
            return META_AND_ASSET_CTXS
        if req_type == "frontendOpenOrders":
            return []
        if req_type == "clearinghouseState":
            dex = payload.get("dex", "")
            if dex in ("", None):
                return USER_STATE  # default dex: full state with balance
            return {"crossMarginSummary": {"accountValue": "0"}, "withdrawable": "0"}
        if req_type == "activeAssetData":
            return ACTIVE_ASSET_DATA_EMPTY
        if req_type == "perpConciseAnnotations":
            return [["xyz:TSLA", {"category": "stocks"}]]
        return [{"name": "default"}]
    info.post.side_effect = _mock_post
    info.spot_user_state.return_value = SPOT_USER_STATE
    info.spot_meta.return_value = SPOT_META
    info.spot_meta_and_asset_ctxs.return_value = SPOT_META_AND_ASSET_CTXS
    info.query_user_abstraction_state.return_value = "default"
    return info


@pytest.fixture
def mock_exchange(mock_info):
    exchange = MagicMock()
    exchange.info = mock_info
    exchange.market_open.return_value = ORDER_RESPONSE_FILLED
    exchange.order.return_value = ORDER_RESPONSE_RESTING
    exchange.bulk_orders.return_value = ORDER_RESPONSE_RESTING
    exchange.cancel.return_value = {"status": "ok"}
    exchange.cancel_by_cloid.return_value = {"status": "ok"}
    exchange.bulk_cancel.return_value = {"status": "ok"}
    exchange.update_leverage.return_value = {"status": "ok"}
    return exchange


@pytest.fixture(autouse=True)
def _clear_resolver_cache():
    """Clear resolver singleton cache between tests."""
    resolver_mod._resolvers.clear()
    yield
    resolver_mod._resolvers.clear()


@pytest.fixture
def patched(mock_info, mock_exchange):
    """Patch all client imports across all command modules."""
    patches = [
        # orient
        patch("hl_cli.commands.orient.get_info", return_value=mock_info),
        patch("hl_cli.commands.orient.get_address", return_value="0xTEST"),
        patch("hl_cli.commands.orient.get_all_mids", return_value=dict(MIDS)),
        patch("hl_cli.commands.orient.get_account_mode", return_value="default"),
        patch("hl_cli.commands.orient.get_spot_balances", return_value=list(MOCK_SPOT_BALANCES)),
        patch("hl_cli.commands.orient.get_dex_balances", return_value=list(MOCK_DEX_BALANCES)),
        # research
        patch("hl_cli.commands.research.get_info", return_value=mock_info),
        patch("hl_cli.commands.research.get_all_mids", return_value=dict(MIDS)),
        # act
        patch("hl_cli.commands.act.get_exchange", return_value=mock_exchange),
        patch("hl_cli.commands.act.get_address", return_value="0xTEST"),
        patch("hl_cli.commands.act.get_info", return_value=mock_info),
        patch("hl_cli.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA),
        patch("hl_cli.commands.act.get_account_mode", return_value="default"),
        patch("hl_cli.commands.act.get_collateral_map", return_value={
            "": ("USDC", 0), "xyz": ("USDC", 0), "flx": ("USDH", 360), "hyna": ("USDE", 235),
        }),
        # review
        patch("hl_cli.commands.review.get_info", return_value=mock_info),
        patch("hl_cli.commands.review.get_address", return_value="0xTEST"),
    ]
    for p in patches:
        p.start()
    yield {"info": mock_info, "exchange": mock_exchange}
    for p in patches:
        p.stop()
