"""Eight ultra-realistic high-stakes fintech bugs for the v5 demo suite.

Each scenario mirrors a CEO-level pain pattern: real-time payment outages,
third-party processor ransomware, AI fraud-model drift, stablecoin
reconciliation, consent/privacy violations (Section 1033), mobile-OS
edge cases, sponsor-bank throttling storms, and agentic-AI commerce
authorization failures.

Conventions match v3/v4:
  - Each function unconditionally raises the right exception type with
    rich frame locals + breadcrumbs.
  - Custom exception classes mirror real production hierarchies.
  - sentry_sdk breadcrumbs reflect the realistic causal chain so the
    orchestrator's context tools have signal to work with.

Honest expectations on first run:
  - 5–7 / 8 verified-shipped (single-frame deterministic crashes).
  - 1–3 human_review (multi-system state coupling that frame locals
    alone cannot reconstruct).
"""

from __future__ import annotations

import sentry_sdk


# ============================================================================
# 1. Peak-hour RTP / FedNow / Venmo-style payment outage
# ============================================================================
class PaymentTimeoutError(Exception):
    """Mirrors gateway-side timeouts on real-time rails."""


def process_realtime_payment(
    transaction_id: str, amount: float, user_id: int,
    processor: str, attempt: int,
) -> None:
    """Real-time payment via RTP/FedNow rails — times out under spike load.

    Pain: ledger ends up inconsistent — some retries succeed silently,
    duplicating the debit, others drop. Frame locals only show ONE
    side of the failure; multi-tx ledger drift requires session
    reconstruction.
    """
    sentry_sdk.add_breadcrumb(
        category="rtp", message=f"submit transfer {transaction_id} via {processor}",
        data={"amount": amount, "rail": "RTP", "user_id": user_id,
              "queue_depth": 4821}, level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="rtp", message="processor returned 504 after 8.2s",
        data={"upstream": processor, "attempt": attempt,
              "circuit_state": "half_open"}, level="warning",
    )
    sentry_sdk.add_breadcrumb(
        category="ledger", message="entry pending — no settlement confirmation",
        data={"tx_id": transaction_id, "ledger_state": "INFLIGHT"},
        level="warning",
    )
    raise PaymentTimeoutError(
        f"realtime payment {transaction_id} amount={amount} via {processor} "
        f"timed out after 8.2s (attempt {attempt}); ledger state INFLIGHT"
    )


# ============================================================================
# 2. Third-party processor ransomware / outage (BridgePay-style)
# ============================================================================
class UpstreamServiceUnavailable(Exception):
    """Mirrors processor-side hard outages — 503/504 cascading."""


def call_card_processor(
    processor: str, operation: str, merchant_id: str,
    amount: float, retries_exhausted: bool,
) -> None:
    """Processor (BridgePay/TrueLayer/Stripe) hit by ransomware → all
    card+ACH+instant-pay flows down. Cascading retry storm.
    """
    sentry_sdk.add_breadcrumb(
        category="http", message=f"POST https://api.{processor}.com/v1/{operation}",
        data={"merchant_id": merchant_id, "amount": amount},
        level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="http", message=f"{processor}: connection refused (3rd consecutive)",
        data={"errno": 111, "ms_since_last_success": 432_000},
        level="error",
    )
    sentry_sdk.add_breadcrumb(
        category="circuit-breaker", message="OPEN — all retries exhausted",
        data={"breaker": f"{processor}.payments",
              "open_for_s": 540, "fallback": "cash_only"},
        level="error",
    )
    raise UpstreamServiceUnavailable(
        f"{processor} ({operation}) unavailable for merchant_id={merchant_id} "
        f"amount={amount}; retries_exhausted={retries_exhausted}; "
        "circuit breaker OPEN — fallback to cash-only"
    )


# ============================================================================
# 3. AI fraud-model drift / false-negative explosion
# ============================================================================
class FraudEngineException(Exception):
    """ML fraud engine raised — score outside calibrated range."""


def evaluate_fraud_signals(
    transaction_amount: float, model_score: float,
    threshold: float, model_version: str, drift_score: float,
) -> None:
    """Agentic fraud engine drifts after a new attack pattern emerges.
    High-value txns get approved before drift detector triggers.
    """
    sentry_sdk.add_breadcrumb(
        category="fraud-engine", message=f"model {model_version} scoring",
        data={"score": model_score, "threshold": threshold,
              "amount": transaction_amount}, level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="fraud-engine", message="drift detector triggered",
        data={"drift_score": drift_score,
              "calibration_window_h": 24,
              "false_negative_rate": 0.18}, level="warning",
    )
    sentry_sdk.add_breadcrumb(
        category="audit", message="ledger inconsistency: 3 approvals reverted",
        data={"audit_control": "SOC2-CC6.6"}, level="error",
    )
    raise FraudEngineException(
        f"model {model_version} drift={drift_score:.3f} (>0.15 threshold); "
        f"score {model_score} below {threshold} on amount={transaction_amount}; "
        "model output unreliable — block approvals"
    )


# ============================================================================
# 4. Stablecoin / tokenized asset reconciliation mismatch
# ============================================================================
class LedgerReconciliationError(Exception):
    """Internal ledger ↔ on-chain state divergence."""


def reconcile_atomic_swap(
    chain_tx_hash: str, ledger_amount: float, chain_amount: float,
    sponsor_bank: str, settlement_status: str,
) -> None:
    """Atomic-swap reconciliation: internal ledger vs blockchain disagree
    on amount → funds appear locked or double-spent.
    """
    sentry_sdk.add_breadcrumb(
        category="chain", message=f"chain confirm {chain_tx_hash}",
        data={"block": 0xABCD12, "chain_amount": chain_amount,
              "sponsor_bank": sponsor_bank},
        level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="ledger", message="internal ledger disagrees on amount",
        data={"ledger_amount": ledger_amount,
              "delta": chain_amount - ledger_amount,
              "audit_window_open": True}, level="error",
    )
    sentry_sdk.add_breadcrumb(
        category="settlement", message="sponsor-bank settlement frozen",
        data={"status": settlement_status, "regulator_alert": True},
        level="error",
    )
    raise LedgerReconciliationError(
        f"chain_tx={chain_tx_hash} ledger={ledger_amount} chain={chain_amount} "
        f"delta={chain_amount - ledger_amount:.6f} via {sponsor_bank}; "
        f"settlement status={settlement_status}"
    )


# ============================================================================
# 5. Consent / privacy violation — Section 1033 / Open Banking
# ============================================================================
class ConsentTokenExpiredError(Exception):
    """Open Banking consent token lapsed — accessing data without auth."""


def fetch_account_data_open_banking(
    institution_id: str, account_id: str, consent_token: str,
    issued_at: str, expires_at: str, scope: str,
) -> None:
    """Microservice forgot to refresh consent token before pulling
    sensitive account data. Audit-log gap = compliance breach.
    """
    sentry_sdk.add_breadcrumb(
        category="oauth", message="consent token validation",
        data={"institution_id": institution_id, "scope": scope,
              "issued_at": issued_at, "expires_at": expires_at},
        level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="audit",
        message="audit log not written (token expired before write)",
        data={"control_id": "PCI-DSS-10.2", "section_1033_compliant": False},
        level="error",
    )
    raise ConsentTokenExpiredError(
        f"consent token expired_at={expires_at} for institution={institution_id} "
        f"account={account_id} scope={scope!r}; data access UNAUTHORIZED"
    )


# ============================================================================
# 6. Mobile transaction crash — iOS 19 / Android 16 edge case
# ============================================================================
def confirm_payment_mobile(
    device_id: str, os_version: str,
    transaction_state: dict, payment_token: str | None,
    user_tier: str,
) -> None:
    """Final 'confirm payment' step crashes on specific OS edge case for
    high-net-worth users. NullPointer-equivalent: payment_token=None
    arrives via a race in the mobile keychain refresh.
    """
    sentry_sdk.add_breadcrumb(
        category="mobile", message=f"device {device_id} OS {os_version}",
        data={"user_tier": user_tier,
              "keychain_refresh_completed": False}, level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="mobile", message="confirm_payment invoked",
        data={"state_keys": list(transaction_state.keys()),
              "token_present": payment_token is not None},
        level="info",
    )
    if payment_token is None:
        # Force the AttributeError that appears in the Sentry trace:
        # `'NoneType' object has no attribute 'startswith'`.
        return payment_token.startswith("tok_")  # type: ignore[union-attr]
    raise RuntimeError("unreachable")


# ============================================================================
# 7. Sponsor-bank rate-limit / dependency throttling storm
# ============================================================================
class RateLimitExceeded(Exception):
    """BaaS partner bank throttling under market volatility."""


def submit_lending_order(
    sponsor_bank: str, order_id: str, amount: float,
    qps_observed: int, qps_limit: int, market_state: str,
) -> None:
    """Sponsor bank throttles aggressively under market volatility →
    your circuit breakers cascade → entire lending/investing flow
    collapses during market hours.
    """
    sentry_sdk.add_breadcrumb(
        category="baas", message=f"submit order {order_id} to {sponsor_bank}",
        data={"amount": amount, "market_state": market_state,
              "rate_limit_token_bucket_remaining": 0}, level="warning",
    )
    sentry_sdk.add_breadcrumb(
        category="baas",
        message=f"observed {qps_observed} qps vs limit {qps_limit}",
        data={"breach_pct": round(100 * (qps_observed - qps_limit) / qps_limit, 1),
              "duration_s": 87}, level="error",
    )
    sentry_sdk.add_breadcrumb(
        category="circuit-breaker",
        message="lending pipeline OPEN; investing OPEN; payouts DEGRADED",
        data={"propagation_latency_ms": 320}, level="error",
    )
    raise RateLimitExceeded(
        f"sponsor_bank={sponsor_bank} order_id={order_id} amount={amount} "
        f"qps_observed={qps_observed} qps_limit={qps_limit} "
        f"market_state={market_state!r} → cascading circuit-breaker open"
    )


# ============================================================================
# 8. Agentic-AI commerce authorization edge case (2026)
# ============================================================================
class AgentAuthorizationError(Exception):
    """Agent tried a high-value action that failed unforeseen policy."""


def authorize_agentic_purchase(
    agent_id: str, transaction_id: str, amount: float,
    policy_check_result: str, tool_call_chain: list,
    customer_consent_scope: str,
) -> None:
    """Customer's AI agent kicks off a high-value transaction; emerging
    AI-specific policy denies it AFTER partial side-effects landed →
    ambiguous duplicate-charge risk + AI-governance audit finding.
    """
    sentry_sdk.add_breadcrumb(
        category="agent", message=f"agent {agent_id} initiated tx {transaction_id}",
        data={"amount": amount,
              "consent_scope": customer_consent_scope,
              "tool_calls_completed": len(tool_call_chain)},
        level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="policy", message="AI commerce policy check",
        data={"policy_id": "ai-purchase-2026.04",
              "result": policy_check_result,
              "side_effects_landed": ["debit_pending"]},
        level="warning",
    )
    sentry_sdk.add_breadcrumb(
        category="audit", message="rolling back partial side effects",
        data={"compensating_actions": 1, "duplicate_charge_risk": True},
        level="error",
    )
    raise AgentAuthorizationError(
        f"agent {agent_id} tx {transaction_id} amount={amount} "
        f"failed policy check ({policy_check_result}) after "
        f"{len(tool_call_chain)} tool calls; consent_scope={customer_consent_scope!r}"
    )


# ============================================================================
# Registry — used by the capture script
# ============================================================================

SCENARIOS = [
    {
        "id": "v5_01_rtp_payment_timeout",
        "title": "Peak-hour RTP/FedNow timeout — ledger inflight",
        "func": process_realtime_payment,
        "kwargs": {"transaction_id": "rtp-7782913", "amount": 24500.00,
                   "user_id": 88421, "processor": "fednow", "attempt": 3},
        "is_async": False,
        "expected_exc": "PaymentTimeoutError",
    },
    {
        "id": "v5_02_processor_ransomware",
        "title": "Card processor ransomware — cascading 503",
        "func": call_card_processor,
        "kwargs": {"processor": "bridgepay", "operation": "charge",
                   "merchant_id": "merch-58102", "amount": 1899.50,
                   "retries_exhausted": True},
        "is_async": False,
        "expected_exc": "UpstreamServiceUnavailable",
    },
    {
        "id": "v5_03_fraud_model_drift",
        "title": "AI fraud model drift — false-negative explosion",
        "func": evaluate_fraud_signals,
        "kwargs": {"transaction_amount": 49999.00, "model_score": 0.42,
                   "threshold": 0.65, "model_version": "fraud-v3.6.2",
                   "drift_score": 0.221},
        "is_async": False,
        "expected_exc": "FraudEngineException",
    },
    {
        "id": "v5_04_stablecoin_reconciliation",
        "title": "Stablecoin atomic-swap reconciliation mismatch",
        "func": reconcile_atomic_swap,
        "kwargs": {"chain_tx_hash": "0xabc123def456abc123def456abc123def456abc1",
                   "ledger_amount": 12500.000000, "chain_amount": 12500.025000,
                   "sponsor_bank": "evolve", "settlement_status": "FROZEN"},
        "is_async": False,
        "expected_exc": "LedgerReconciliationError",
    },
    {
        "id": "v5_05_consent_token_expired",
        "title": "Open Banking consent expired — Section 1033 breach",
        "func": fetch_account_data_open_banking,
        "kwargs": {"institution_id": "inst-39281", "account_id": "acct-771",
                   "consent_token": "ct_abc123", "issued_at": "2026-04-29T00:00:00Z",
                   "expires_at": "2026-05-06T18:00:00Z", "scope": "balances,tx"},
        "is_async": False,
        "expected_exc": "ConsentTokenExpiredError",
    },
    {
        "id": "v5_06_mobile_confirm_crash",
        "title": "Mobile confirm-payment NullPointer (iOS 19 edge)",
        "func": confirm_payment_mobile,
        "kwargs": {"device_id": "iPhone16,2", "os_version": "iOS 19.0.1",
                   "transaction_state": {"amount": 1850.00,
                                          "recipient": "u_44021",
                                          "currency": "USD"},
                   "payment_token": None, "user_tier": "premier"},
        "is_async": False,
        "expected_exc": "AttributeError",
    },
    {
        "id": "v5_07_sponsor_bank_ratelimit",
        "title": "Sponsor-bank rate-limit storm during market volatility",
        "func": submit_lending_order,
        "kwargs": {"sponsor_bank": "atlantic_capital", "order_id": "ord-9301",
                   "amount": 75000.00, "qps_observed": 412, "qps_limit": 100,
                   "market_state": "VIX>35"},
        "is_async": False,
        "expected_exc": "RateLimitExceeded",
    },
    {
        "id": "v5_08_agent_authorization",
        "title": "Agentic-AI commerce authorization edge case",
        "func": authorize_agentic_purchase,
        "kwargs": {"agent_id": "agt-5512", "transaction_id": "tx-agent-44782",
                   "amount": 8499.00, "policy_check_result": "DENIED_HIGH_VALUE",
                   "tool_call_chain": ["read_balance", "check_recipient",
                                        "estimate_fee", "submit_payment"],
                   "customer_consent_scope": "purchases:auto<=500"},
        "is_async": False,
        "expected_exc": "AgentAuthorizationError",
    },
]
