"""Realistic billing crash scenarios for the logomesh repro demo.

Five production crash patterns from real OSS billing bugs — all pure-function
(no ORM, no DB), directly reproducible from Sentry frame locals.

Sources:
  S1 — frappe/erpnext #37813  (TypeError: float += NoneType, exchange gain/loss)
  S2 — frappe/erpnext #42202  (TypeError: NoneType + list, payment reconciliation)
  S3 — saleor/saleor PR#15950 (ZeroDivisionError, order-level discount on free cart)
  S4 — frappe/erpnext #28768  (TypeError: NoneType not subscriptable, GST lookup)
  S5 — saleor/saleor #16273   (decimal.InvalidOperation, zero-decimal-place store)
"""

from __future__ import annotations

from decimal import Decimal


# ---------------------------------------------------------------------------
# S1 — TypeError: unsupported operand type(s) for +=: 'float' and 'NoneType'
# frappe/erpnext #37813
#
# set_print_format_fields accumulates the bank-side total of a journal entry.
# Exchange gain/loss rows are auto-generated with both debit AND credit set to
# None. The `or` short-circuits to None, and `bank_amount += None` crashes.
# ---------------------------------------------------------------------------

def set_print_format_fields(accounts: list[dict]) -> dict:
    """Compute bank-side total for a journal entry print layout.

    Bug: auto-generated exchange gain/loss rows have both
    `debit_in_account_currency` and `credit_in_account_currency` as None.
    `d["debit_..."] or d["credit_..."]` evaluates to None, and
    `bank_amount += None` raises TypeError.
    """
    bank_amount: float = 0.0
    pay_to_recd_from: str = ""

    for d in accounts:
        if d.get("account_type") == "Bank":
            # BUG: None or None == None → float += None → TypeError
            bank_amount += (
                d["debit_in_account_currency"] or d["credit_in_account_currency"]
            )
            if d.get("party"):
                pay_to_recd_from = d["party"]

    return {"total_amount": bank_amount, "pay_to_recd_from": pay_to_recd_from}


# ---------------------------------------------------------------------------
# S2 — TypeError: unsupported operand type(s) for +: 'NoneType' and 'list'
# frappe/erpnext #42202
#
# get_nonreconciled_payment_entries concatenates three query results.
# Sub-query helpers return None (not []) when a party has no outstanding
# entries. None + [] → TypeError.
# ---------------------------------------------------------------------------

def get_nonreconciled_payment_entries(
    party_type: str,
    party: str,
    receivable_payable_account: str,
    payment_entries: list[dict] | None,
    journal_entries: list[dict] | None,
    dr_or_cr_notes: list[dict] | None,
) -> list[dict]:
    """Merge three lists of unreconciled entries for the reconciliation UI.

    Bug: sub-query helpers return None instead of [] when the party has no
    outstanding entries. None + list raises TypeError.
    """
    # BUG: no None guard — if payment_entries is None, `None + []` crashes
    non_reconciled_payments = payment_entries + journal_entries + dr_or_cr_notes  # type: ignore[operator]

    return sorted(
        non_reconciled_payments,
        key=lambda x: x.get("posting_date", ""),
        reverse=True,
    )


# ---------------------------------------------------------------------------
# S3 — ZeroDivisionError: division by zero
# saleor/saleor PR#15950 (Linear MERX-271)
#
# propagate_order_discount_to_lines distributes an order-level percentage
# discount across lines proportionally. When every line carries a 100%
# catalogue promotion, all undiscounted_totals are 0.00, making subtotal=0.
# Dividing line_total / subtotal crashes.
# ---------------------------------------------------------------------------

def propagate_order_discount_to_lines(
    order_discount_amount: Decimal,
    lines: list[dict],
) -> list[dict]:
    """Distribute an order-level discount across lines proportionally.

    Bug: when all lines have a 100% catalogue promotion applied their
    `undiscounted_total` is Decimal("0"), making subtotal == Decimal("0").
    `ratio = line_total / subtotal` raises ZeroDivisionError.
    """
    subtotal = sum(Decimal(str(line["undiscounted_total"])) for line in lines)

    result = []
    for line in lines:
        line_total = Decimal(str(line["undiscounted_total"]))
        # BUG: subtotal can be 0 when every line is fully promoted
        ratio = line_total / subtotal
        line_discount = (order_discount_amount * ratio).quantize(Decimal("0.01"))
        result.append({
            "line_id": line["line_id"],
            "discount_amount": line_discount,
            "discounted_total": max(Decimal("0.00"), line_total - line_discount),
        })
    return result


# ---------------------------------------------------------------------------
# S4 — TypeError: 'NoneType' object is not subscriptable
# frappe/erpnext #28768
#
# get_regional_address_details slices the first two chars of a GSTIN to get
# the Indian state code. When the company has no GST registration configured,
# company_gstin is None. None[:2] raises TypeError.
# ---------------------------------------------------------------------------

def get_regional_address_details(
    company_gstin: str | None,
    party_gstin: str | None,
    master_doctype: str,
    company: str,
    tax_categories: list[str],
) -> dict:
    """Determine intra-state vs inter-state GST tax category.

    Bug: company_gstin is None when the company's GST registration is not
    configured. `None[:2]` raises TypeError: 'NoneType' object is not
    subscriptable.
    """
    # BUG: company_gstin can be None → None[:2] → TypeError
    company_state_code = company_gstin[:2]  # type: ignore[index]
    party_state_code = party_gstin[:2] if party_gstin else None

    if party_state_code and company_state_code == party_state_code:
        tax_category = "intra-state"
    else:
        tax_category = "inter-state"

    if tax_category not in tax_categories:
        raise ValueError(
            f"No tax template for {tax_category!r} in {master_doctype!r} "
            f"for company {company!r}"
        )

    return {
        "tax_category": tax_category,
        "company_state_code": company_state_code,
        "party_state_code": party_state_code,
    }


# ---------------------------------------------------------------------------
# S5 — ValueError: invalid literal for int() with base 10: '149.99'
# Stripe/webhook handler pattern — extremely common in real billing code.
#
# Webhook payloads from payment processors send amounts in major currency
# units ("149.99" dollars). The handler assumes integer cents ("14999").
# int("149.99") raises ValueError. Also breaks on "$149.99", "1,499.99".
# ---------------------------------------------------------------------------

def parse_webhook_amount(amount_str: str) -> int:
    """Parse a payment amount string from a webhook payload into integer cents.

    Bug: some payment processor partners send "149.99" (dollars) instead of
    "14999" (cents). `int()` raises ValueError on any string with a decimal
    point, currency symbol, or thousands separator.

    Args:
        amount_str: Raw amount string from the webhook JSON body.

    Returns:
        Integer cent value (e.g. 14999 for $149.99).
    """
    return int(amount_str)  # ValueError: invalid literal for int() with base 10: '149.99'
