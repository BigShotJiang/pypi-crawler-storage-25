"""Billing-ops module — targets for the `logomesh repro` real-bug demo.

Each function reproduces a real production crash pattern observed in OSS
fintech / billing projects. Fixtures in `tests/fixtures/` carry Sentry-shaped
events whose frame locals reproduce the crash when fed back through
`logomesh repro`.

Inspired by:
- github.com/frappe/frappe/issues/37394 (money_in_words / None fraction)
- github.com/frappe/erpnext/issues/37813 (float * NoneType in payment entry)
- A datetime-parsing crash class common in invoice ingestion paths.
"""

from __future__ import annotations

from datetime import datetime


def money_in_words(amount: float, fraction_currency: str) -> str:
    """Format an amount as words. Returns "<int> dollars and <fraction>".

    Bug: caller can pass `fraction_currency=None` when the currency record
    has no fraction set; string concat then raises TypeError.
    """
    return f"{int(amount)} dollars and " + fraction_currency


def compute_payment_total(grand_total: float, exchange_rate: float) -> float:
    """Convert a grand total via an exchange rate.

    Bug: when `exchange_rate` is None (currency row missing rate) the
    multiply raises TypeError "unsupported operand type(s) for *".
    """
    return grand_total * exchange_rate


def parse_invoice_due_date(date_str: str) -> str:
    """Parse an ISO invoice date and return its date component.

    Bug: invoice ingestion sometimes hands us malformed dates like
    `2024-02-30`; fromisoformat raises ValueError.
    """
    return datetime.fromisoformat(date_str).date().isoformat()
