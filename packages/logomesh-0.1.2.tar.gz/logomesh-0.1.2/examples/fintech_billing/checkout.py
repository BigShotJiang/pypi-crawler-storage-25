"""Toy fintech billing module — used by the `logomesh repro` demo.

Mirrors a realistic checkout pricing path: a pricing engine upstream of
this function sometimes hands it an out-of-range `discount_pct`, which
raises in production and lands in Sentry.
"""

from __future__ import annotations


def apply_discount(price: float, qty: int, discount_pct: float) -> float:
    """Line-item total with percentage discount.

    Args:
        price: per-unit price in major currency units (e.g. dollars).
        qty: integer quantity, must be >= 0.
        discount_pct: percentage discount, 0..100.

    Raises:
        ValueError: discount_pct outside 0..100 or qty negative.
    """
    if not 0 <= discount_pct <= 100:
        raise ValueError(
            f"discount_pct must be 0..100, got {discount_pct}"
        )
    if qty < 0:
        raise ValueError(f"qty must be >= 0, got {qty}")
    return round(price * qty * (1 - discount_pct / 100), 2)
