"""Ten deliberately-broken fintech functions for the v3 demo suite.

Each function:
  - Raises a realistic production exception type.
  - Has frame-locals that match the exact spec the user provided.
  - Adds breadcrumbs that hint at the *cause* (DB ops, async events,
    Redis lock attempts, HTTP retries) so the orchestrator's
    ScientificContextEngine has signal to work with.

These are the bugs the orchestrator will be asked to reproduce
deterministically. Running each function should raise; the capture
script in `scripts/generate_v3_fixtures.py` intercepts the sentry_sdk
event and writes a fixture JSON to `tests/fixtures/v3_*.json`.

The whole module is intentionally NOT robust — try/except is forbidden
inside the bug functions. The `run_*` wrappers below sit *outside* the
crash function so the wrapper itself doesn't appear in the in-app frame
the orchestrator picks up.
"""

from __future__ import annotations

import datetime as _dt
from decimal import Decimal

import sentry_sdk


# ==========================================================================
# 1. Async Celery refund task — stale DB state
# ==========================================================================
class StaleDataError(Exception):
    """Mirrors sqlalchemy.exc.StaleDataError without the runtime dep."""


def celery_refund_apply(refund_id: int, expected_balance: float, task_id: str, user_id: int) -> None:
    """Background refund task — fails when the user's balance has been
    mutated by another worker between enqueue and execution.
    """
    sentry_sdk.add_breadcrumb(
        category="db", message=f"SELECT balance FROM users WHERE id={user_id}",
        data={"op": "select", "table": "users"}, level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="db", message=f"UPDATE users SET balance=99.50 WHERE id={user_id}",
        data={"op": "update", "table": "users", "by_worker": "checkout-2"}, level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="celery", message=f"task {task_id} resumed",
        data={"task": task_id}, level="info",
    )
    actual_balance = 99.50  # mutated by another worker
    if actual_balance != expected_balance:
        raise StaleDataError(
            f"refund {refund_id}: expected balance {expected_balance}, "
            f"got {actual_balance} (mutated by another transaction)"
        )


# ==========================================================================
# 2. Race condition — concurrent balance debit goes negative
# ==========================================================================
def debit_balance(current_balance: float, debit_amount: float,
                  transaction_id: int, lock_acquired: bool) -> float:
    """Withdraw funds — racy: lock_acquired=False means another tx is
    debiting the same row concurrently.
    """
    sentry_sdk.add_breadcrumb(
        category="lock", message="SELECT FOR UPDATE NOWAIT failed",
        data={"row": "user.balance", "lock_acquired": lock_acquired}, level="warning",
    )
    sentry_sdk.add_breadcrumb(
        category="db", message="concurrent debit detected via WAL",
        data={"transaction_id": transaction_id}, level="warning",
    )
    new_balance = current_balance - debit_amount
    assert new_balance >= 0, "balance cannot go negative"
    return new_balance


# ==========================================================================
# 3. Dependency version conflict — sqlalchemy 2.0.35 missing AsyncSession
# ==========================================================================
def init_async_session(package: str, installed_version: str, expected_attr: str) -> None:
    """Imports a moved attribute — emulates a real upgrade-broken module."""
    sentry_sdk.add_breadcrumb(
        category="import", message=f"import {package}=={installed_version}", level="info",
    )
    # Synthesize the AttributeError exactly as the real failure would surface.
    # We do NOT import sqlalchemy here — the attribute name encodes the bug.
    raise AttributeError(
        f"module '{package}' has no attribute '{expected_attr}'  "
        f"(installed {installed_version}; AsyncSession moved to {package}.ext.asyncio)"
    )


# ==========================================================================
# 4. Timezone mismatch — naive datetime in daily billing batch
# ==========================================================================
def daily_proration(billing_date: str, user_tz: str, server_tz: str, prorated_days: int) -> float:
    """Computes prorated charge — naive billing_date treated as UTC,
    user is on America/Los_Angeles → off-by-1 day → prorated_days=0.
    """
    sentry_sdk.add_breadcrumb(
        category="batch", message=f"daily_billing run server_tz={server_tz}",
        data={"server_tz": server_tz, "user_tz": user_tz}, level="info",
    )
    parsed = _dt.datetime.fromisoformat(billing_date)
    if parsed.tzinfo is None:
        raise ValueError(
            f"naive datetime in billing batch: {billing_date!r} "
            f"(user_tz={user_tz}, server_tz={server_tz}, prorated_days={prorated_days})"
        )
    return prorated_days * 1.50


# ==========================================================================
# 5. Payment gateway SDK C-extension crash (Stripe-style)
# ==========================================================================
def stripe_create_refund(gateway: str, operation: str, charge_id: str = "ch_unknown") -> None:
    """Wraps a hypothetical native call. Frame locals are intentionally
    sparse — the real C-extension wouldn't surface internals.
    """
    sentry_sdk.add_breadcrumb(
        category="http", message=f"POST https://api.{gateway}.com/v1/refunds",
        data={"gateway": gateway, "operation": operation}, level="info",
    )
    raise OSError(
        f"native call failed in {gateway} SDK ({operation}): "
        "libstripe.so.4: undefined symbol _stripe_signed_request_v2"
    )


# ==========================================================================
# 6. DB connection pool exhaustion in async task queue
# ==========================================================================
class PoolTimeoutError(Exception):
    """Mirrors sqlalchemy.exc.OperationalError(QueuePool limit) without the dep."""


async def process_payout_async(pool_size: int, max_overflow: int, task_type: str) -> None:
    """Async task contention — pool exhausted under spike load."""
    sentry_sdk.add_breadcrumb(
        category="db.pool", message=f"checkout requested pool_size={pool_size}",
        data={"checked_out": pool_size, "overflow": max_overflow}, level="warning",
    )
    sentry_sdk.add_breadcrumb(
        category="db.pool", message="QueuePool limit of size 15 overflow 10 reached",
        data={"waited_s": 30}, level="error",
    )
    raise PoolTimeoutError(
        f"QueuePool limit of size {pool_size} overflow {max_overflow} reached "
        f"in async task '{task_type}'; timeout 30s"
    )


# ==========================================================================
# 7. Tax rule change — outdated tax_rate vs. effective_date
# ==========================================================================
class TaxValidationError(Exception):
    """Domain validation error for tax computation."""


def validate_tax(tax_rate: float, jurisdiction: str, effective_date: str) -> None:
    """Tax-table lookup — local cache is stale relative to current date."""
    sentry_sdk.add_breadcrumb(
        category="tax", message=f"loaded local tax cache for {jurisdiction}",
        data={"cached_rate": tax_rate, "effective": effective_date}, level="info",
    )
    canonical_rate = 0.0875  # what the upstream service now publishes
    if abs(tax_rate - canonical_rate) > 1e-6:
        raise TaxValidationError(
            f"tax_rate {tax_rate} outdated for jurisdiction={jurisdiction}; "
            f"effective_date {effective_date} → canonical {canonical_rate}"
        )


# ==========================================================================
# 8. Idempotency failure — duplicate webhook → IntegrityError
# ==========================================================================
class IntegrityError(Exception):
    """Mirrors sqlalchemy.exc.IntegrityError unique-constraint failure."""


def webhook_record_charge(reference: str, amount: float, already_processed: bool) -> None:
    """Stripe webhook retried before idempotency-key TTL expired."""
    sentry_sdk.add_breadcrumb(
        category="webhook", message=f"received reference={reference}",
        data={"already_processed": already_processed, "amount": amount}, level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="db", message=f"INSERT INTO transactions (reference, amount) "
                                f"VALUES ({reference!r}, {amount})",
        data={"op": "insert"}, level="warning",
    )
    if already_processed:
        raise IntegrityError(
            f"UNIQUE constraint failed: transactions.reference "
            f"(reference={reference!r}, amount={amount})"
        )


# ==========================================================================
# 9. PII leak — frame locals contain card data (PCI edge case)
# ==========================================================================
def process_card_payment(card_last4: str, cvv: str, partial_pan: str, amount: float) -> None:
    """Processes a payment — locals deliberately contain PII. The
    orchestrator's PII redaction must scrub these before writing the
    deterministic test, even though the function itself is innocuous.
    """
    sentry_sdk.add_breadcrumb(
        category="payment", message="card token validation",
        data={"last4": card_last4}, level="info",
    )
    if amount <= 0:
        raise ValueError(
            f"amount must be > 0, got {amount} "
            f"(card_last4={card_last4}, partial_pan={partial_pan})"
        )


# ==========================================================================
# 10. Async task — missing Redis distributed lock
# ==========================================================================
class RedisLockError(Exception):
    """Mirrors redis.exceptions.LockError."""


async def refund_with_lock(lock_key: str, timeout: int, refund_id: int = 837291) -> None:
    """Distributed lock guarding refund — can't acquire under contention."""
    sentry_sdk.add_breadcrumb(
        category="redis", message=f"SET {lock_key} NX EX {timeout}",
        data={"lock_key": lock_key, "timeout_s": timeout}, level="info",
    )
    sentry_sdk.add_breadcrumb(
        category="redis", message=f"GET {lock_key} → already held",
        data={"holder_pid": 4421}, level="warning",
    )
    raise RedisLockError(
        f"could not acquire lock {lock_key!r} within {timeout}s "
        f"(refund_id={refund_id}, contention from another worker)"
    )


# ==========================================================================
# Registry — used by the capture script
# ==========================================================================

SCENARIOS = [
    {
        "id": "v3_01_celery_refund_stale_db",
        "title": "Celery refund task — stale DB state",
        "func": celery_refund_apply,
        "kwargs": {"refund_id": 837291, "expected_balance": 124.50,
                   "task_id": "refund-3921", "user_id": 47821},
        "is_async": False,
        "expected_exc": "StaleDataError",
    },
    {
        "id": "v3_02_balance_debit_race",
        "title": "Concurrent balance debit — race condition",
        "func": debit_balance,
        "kwargs": {"current_balance": 8.25, "debit_amount": 12.00,
                   "transaction_id": 837292, "lock_acquired": False},
        "is_async": False,
        "expected_exc": "AssertionError",
    },
    {
        "id": "v3_03_dep_version_conflict",
        "title": "Dependency version conflict (sqlalchemy AsyncSession moved)",
        "func": init_async_session,
        "kwargs": {"package": "sqlalchemy", "installed_version": "2.0.35",
                   "expected_attr": "AsyncSession"},
        "is_async": False,
        "expected_exc": "AttributeError",
    },
    {
        "id": "v3_04_tz_naive_datetime",
        "title": "Timezone mismatch in daily billing batch",
        "func": daily_proration,
        "kwargs": {"billing_date": "2026-05-06T00:00:00",
                   "user_tz": "America/Los_Angeles", "server_tz": "UTC",
                   "prorated_days": 0},
        "is_async": False,
        "expected_exc": "ValueError",
    },
    {
        "id": "v3_05_stripe_c_ext_crash",
        "title": "Stripe SDK C-extension crash (sparse locals)",
        "func": stripe_create_refund,
        "kwargs": {"gateway": "stripe", "operation": "create_refund"},
        "is_async": False,
        "expected_exc": "OSError",
    },
    {
        "id": "v3_06_db_pool_exhaustion",
        "title": "DB connection pool exhaustion (async)",
        "func": process_payout_async,
        "kwargs": {"pool_size": 15, "max_overflow": 10, "task_type": "process_payout"},
        "is_async": True,
        "expected_exc": "PoolTimeoutError",
    },
    {
        "id": "v3_07_tax_rule_drift",
        "title": "Tax rule change — outdated cached rate",
        "func": validate_tax,
        "kwargs": {"tax_rate": 0.0825, "jurisdiction": "CA",
                   "effective_date": "2026-04-01"},
        "is_async": False,
        "expected_exc": "TaxValidationError",
    },
    {
        "id": "v3_08_webhook_idempotency",
        "title": "Idempotency failure — duplicate webhook",
        "func": webhook_record_charge,
        "kwargs": {"reference": "ch_3PqRstUvwXyz", "amount": 49.99,
                   "already_processed": True},
        "is_async": False,
        "expected_exc": "IntegrityError",
    },
    {
        "id": "v3_09_pii_in_locals",
        "title": "PII present in frame locals (PCI edge case)",
        "func": process_card_payment,
        "kwargs": {"card_last4": "4242", "cvv": "123",
                   "partial_pan": "4111111111114242", "amount": -1.00},
        "is_async": False,
        "expected_exc": "ValueError",
    },
    {
        "id": "v3_10_redis_lock_missing",
        "title": "Async task — missing Redis distributed lock",
        "func": refund_with_lock,
        "kwargs": {"lock_key": "refund:837291", "timeout": 30},
        "is_async": True,
        "expected_exc": "RedisLockError",
    },
]
