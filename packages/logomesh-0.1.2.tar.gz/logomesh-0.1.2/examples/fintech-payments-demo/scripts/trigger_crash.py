#!/usr/bin/env python3
from __future__ import annotations

import argparse
import concurrent.futures
import json
import time

import requests


def _post(url: str, payload: dict) -> dict:
    r = requests.post(url, json=payload, timeout=15)
    return {"status": r.status_code, "body": r.text}


def create_order(base_url: str) -> str:
    payload = {
        "amount_cents": 14999,
        "currency": "USD",
        "customer_email": "buyer@example.com",
        "customer_stripe_id": "cus_demo_race",
        "idempotency_token": "idem-race-demo",
    }
    r = requests.post(f"{base_url}/api/orders", json=payload, timeout=15)
    r.raise_for_status()
    data = r.json()
    return data["order_id"]


def trigger_integrity_race(base_url: str) -> None:
    order_id = create_order(base_url)
    print(f"order_id={order_id}")

    pay_url = f"{base_url}/api/orders/{order_id}/pay"
    payload_a = {"payment_token": "tok_visa", "simulate": "integrity_race", "request_id": "race-a"}
    payload_b = {"payment_token": "tok_visa", "simulate": "integrity_race", "request_id": "race-b"}

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        futs = [ex.submit(_post, pay_url, payload_a), ex.submit(_post, pay_url, payload_b)]
        for fut in concurrent.futures.as_completed(futs):
            print(json.dumps(fut.result(), indent=2))

    print("queued two payment tasks for same order; watch worker logs for IntegrityError duplicate order_id")


def trigger_single_case(base_url: str, case: str) -> None:
    order_id = create_order(base_url)
    pay_url = f"{base_url}/api/orders/{order_id}/pay"
    payload = {"payment_token": "tok_visa", "simulate": case, "request_id": f"case-{case}"}
    out = _post(pay_url, payload)
    print(json.dumps(out, indent=2))
    print("task queued; inspect worker logs for exception path")


def main() -> None:
    parser = argparse.ArgumentParser(description="Trigger logomesh-friendly crash scenarios")
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument(
        "--case",
        choices=["integrity_race", "stale_race", "fk_violation", "timing_race", "transient_db"],
        default="integrity_race",
    )
    args = parser.parse_args()

    if args.case == "integrity_race":
        trigger_integrity_race(args.base_url)
    else:
        trigger_single_case(args.base_url, args.case)


if __name__ == "__main__":
    main()
