from django.contrib import admin
from django.urls import path

from core.views import healthz
from payments.views import create_order, start_payment, stripe_webhook

urlpatterns = [
    path("admin/", admin.site.urls),
    path("healthz", healthz, name="healthz"),
    path("api/orders", create_order, name="create_order"),
    path("api/orders/<uuid:order_id>/pay", start_payment, name="start_payment"),
    path("api/stripe/webhook", stripe_webhook, name="stripe_webhook"),
]
