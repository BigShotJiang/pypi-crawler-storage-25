from __future__ import annotations

from django.http import JsonResponse
from django.utils.timezone import now


def healthz(_request):
    return JsonResponse({"ok": True, "service": "fintech-payments-demo", "ts": now().isoformat()})
