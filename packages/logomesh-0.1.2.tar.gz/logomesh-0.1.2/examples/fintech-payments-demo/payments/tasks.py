from __future__ import annotations

import logging
import random
import time
from typing import Any

import sentry_sdk
from celery import shared_task
from django.db import IntegrityError, OperationalError, transaction
from django.db.models import F
from django.utils import timezone
from sqlalchemy.orm.exc import StaleDataError

from payments.models import Order, OrderStatus, Payment, PaymentAttempt, SettlementRecord
from payments.stripe_client import create_charge

logger = logging.getLogger("payments.tasks")


def deterministic_value_failure(*, amount_cents: int, currency: str, reason: str) -> None:
    normalized = currency.upper()
    if amount_cents <= 0 or normalized not in {"USD", "EUR"}:
        raise ValueError(
            f"invalid settlement input amount_cents={amount_cents} currency={normalized} reason={reason}"
        )


def deterministic_type_failure(*, retries, max_retries: int) -> int:
    # Deliberately type-unsafe to trigger deterministic TypeError.
    return retries + max_retries


def deterministic_key_failure(*, payload: dict[str, Any]) -> str:
    return payload["customer_id"]


@shared_task(bind=True, max_retries=1, default_retry_delay=2, queue="payments")
def process_payment(
    self,
    *,
    order_id: str,
    payment_token: str,
    request_id: str = "",
    simulate: str = "",
) -> str:
    """Primary payment orchestration task.

    Expected flow:
      1) Fetch order
      2) Charge Stripe
      3) Insert Payment row (unique by order_id)
      4) Mark order paid
      5) Enqueue receipt

    Known deliberate weakness for logomesh evaluation:
      - No idempotency key on provider call
      - No de-dup guard around Payment creation
    """
    t0 = time.time()
    task_id = getattr(self.request, "id", "")
    retries = int(getattr(self.request, "retries", 0) or 0)

    # Sentry routing — tags drive `transaction` + searchable filters.
    sentry_sdk.set_tag("transaction", "celery.process_payment")
    sentry_sdk.set_tag("celery.task_id", task_id)
    sentry_sdk.set_tag("celery.retries", retries)
    sentry_sdk.set_tag("simulate", simulate or "none")
    sentry_sdk.set_context(
        "celery_task",
        {
            "task_name": "payments.tasks.process_payment",
            "task_id": task_id,
            "retries": retries,
            "queue": "payments",
            "request_id": request_id,
        },
    )

    sentry_sdk.add_breadcrumb(
        category="payments",
        type="info",
        level="info",
        message="order_lookup_started",
        data={"order_id": order_id, "task_id": task_id, "retries": retries},
    )
    try:
        order = Order.objects.get(pk=order_id)
    except Order.DoesNotExist as exc:
        logger.error("order_not_found", extra={"order_id": order_id, "task_id": task_id})
        sentry_sdk.add_breadcrumb(
            category="payments", type="error", level="error",
            message="order_not_found",
            data={"order_id": order_id, "task_id": task_id},
        )
        sentry_sdk.capture_exception(exc)
        raise

    sentry_sdk.add_breadcrumb(
        category="payments", type="info", level="info",
        message="order_lookup_completed",
        data={
            "order_id": str(order.id),
            "public_id": order.public_id,
            "status": order.status,
            "version": order.version,
            "amount_cents": order.amount_cents,
            "currency": order.currency,
        },
    )

    PaymentAttempt.objects.create(
        order=order,
        task_id=task_id,
        attempt=retries,
        status="started",
    )

    logger.info(
        "process_payment_started",
        extra={
            "order_id": str(order.id),
            "public_id": order.public_id,
            "amount_cents": order.amount_cents,
            "currency": order.currency,
            "task_id": task_id,
            "retries": retries,
            "simulate": simulate,
            "request_id": request_id,
        },
    )
    sentry_sdk.add_breadcrumb(
        category="payments", type="info", level="info",
        message="process_payment_started",
        data={
            "order_id": str(order.id),
            "task_id": task_id,
            "retries": retries,
            "simulate": simulate,
        },
    )

    try:
        order.mark_processing()
        sentry_sdk.add_breadcrumb(
            category="payments", type="info",
            message="order_marked_processing",
            data={"order_id": str(order.id), "from_status": "pending", "to_status": "processing"},
        )

        if simulate == "transient_db":
            sentry_sdk.add_breadcrumb(
                category="payments", type="error", level="error",
                message="simulate_transient_db_outage",
                data={"order_id": str(order.id), "simulate": simulate},
            )
            raise OperationalError("simulated transient DB outage")

        sentry_sdk.add_breadcrumb(
            category="stripe", type="http", level="info",
            message="stripe_charge_started",
            data={
                "order_id": str(order.id),
                "amount_cents": order.amount_cents,
                "currency": order.currency,
                "customer_stripe_id": order.customer_stripe_id,
            },
        )
        charge = create_charge(
            amount_cents=order.amount_cents,
            currency=order.currency,
            customer_stripe_id=order.customer_stripe_id,
            source=payment_token,
            metadata={"order_id": order.public_id, "request_id": request_id, "task_id": task_id},
        )
        sentry_sdk.add_breadcrumb(
            category="stripe", type="http", level="info",
            message="stripe_charge_completed",
            data={"order_id": str(order.id), "charge_id": charge.get("id", "")},
        )

        # Deliberate race window for duplicate Payment rows under retries/racing workers.
        if simulate in {"integrity_race", "timing_race"}:
            sentry_sdk.add_breadcrumb(
                category="payments", type="info", level="warning",
                message="race_window_open",
                data={"order_id": str(order.id), "simulate": simulate, "sleep_ms": 350},
            )
            time.sleep(0.35 + random.random() * 0.2)

        sentry_sdk.add_breadcrumb(
            category="payments", type="info",
            message="payment_insert_attempted",
            data={
                "order_id": str(order.id),
                "stripe_charge_id": charge.get("id", ""),
                "amount_cents": order.amount_cents,
            },
        )
        payment = Payment.objects.create(
            order=order,
            stripe_charge_id=charge["id"],
            amount_cents=order.amount_cents,
            currency=order.currency,
            provider_response=dict(charge),
        )

        if simulate == "fk_violation":
            # Partial provider success happened above; now we write an invalid FK edge.
            sentry_sdk.add_breadcrumb(
                category="payments", type="info", level="warning",
                message="settlement_record_with_invalid_fk",
                data={
                    "payment_id": "00000000-0000-0000-0000-000000000000",
                    "provider_event_id": charge.get("id", ""),
                    "simulate": simulate,
                },
            )
            SettlementRecord.objects.create(payment_id="00000000-0000-0000-0000-000000000000", provider_event_id=charge["id"])
        else:
            SettlementRecord.objects.create(payment=payment, provider_event_id=charge["id"])

        sentry_sdk.add_breadcrumb(
            category="payments", type="info",
            message="optimistic_mark_paid_attempted",
            data={"order_id": str(order.id), "expected_version": order.version},
        )
        _optimistic_mark_paid(order=order, expected_version=order.version, simulate=simulate)

        if simulate == "timing_race":
            sentry_sdk.add_breadcrumb(
                category="payments", type="info", level="warning",
                message="reconcile_order_state_dispatched",
                data={
                    "order_id": str(order.id),
                    "target_state": OrderStatus.FAILED,
                    "reason": "fraud_hold",
                    "simulate": simulate,
                },
            )
            reconcile_order_state.apply_async(
                kwargs={"order_id": str(order.id), "target_state": OrderStatus.FAILED, "reason": "fraud_hold"},
                queue="reconcile",
                countdown=0,
            )

        send_receipt.apply_async(kwargs={"order_id": str(order.id)}, queue="receipts")

        PaymentAttempt.objects.create(
            order=order,
            task_id=task_id,
            attempt=retries,
            status="success",
        )

        logger.info(
            "process_payment_succeeded",
            extra={
                "order_id": str(order.id),
                "payment_id": str(payment.id),
                "stripe_charge_id": payment.stripe_charge_id,
                "duration_ms": int((time.time() - t0) * 1000),
            },
        )
        return str(payment.id)

    except (IntegrityError, OperationalError, StaleDataError) as exc:
        sentry_sdk.add_breadcrumb(
            category="payments", type="error", level="error",
            message="process_payment_failed",
            data={
                "order_id": str(order.id),
                "task_id": task_id,
                "error_type": type(exc).__name__,
                "error_message": str(exc)[:200],
                "retries": retries,
            },
        )
        PaymentAttempt.objects.create(
            order=order,
            task_id=task_id,
            attempt=retries,
            status="failure",
            error_code=type(exc).__name__,
            error_message=str(exc),
        )
        order.last_error_text = str(exc)
        order.status = OrderStatus.FAILED
        order.save(update_fields=["status", "last_error_text", "updated_at"])

        logger.exception(
            "process_payment_failed",
            extra={
                "order_id": str(order.id),
                "error_type": type(exc).__name__,
                "request_id": request_id,
                "retries": retries,
            },
        )
        sentry_sdk.capture_exception(exc)

        if retries < self.max_retries:
            sentry_sdk.add_breadcrumb(
                category="celery", type="info", level="warning",
                message="task_retry_scheduled",
                data={"task_id": task_id, "next_attempt": retries + 1},
            )
            raise self.retry(exc=exc)
        raise


@shared_task(bind=True, max_retries=3, default_retry_delay=5, queue="receipts")
def send_receipt(self, *, order_id: str) -> None:
    order = Order.objects.get(pk=order_id)
    logger.info(
        "receipt_queued",
        extra={
            "order_id": str(order.id),
            "public_id": order.public_id,
            "customer_email": order.customer_email,
            "task_id": getattr(self.request, "id", ""),
        },
    )


@shared_task(bind=True, max_retries=0, queue="reconcile")
def reconcile_order_state(self, *, order_id: str, target_state: str, reason: str) -> None:
    """Intentional async state race.

    Competes with the happy-path paid update; whoever writes last wins.
    """
    sentry_sdk.set_tag("transaction", "celery.reconcile_order_state")
    sentry_sdk.add_breadcrumb(
        category="payments", type="info", level="warning",
        message="reconcile_order_state_started",
        data={"order_id": order_id, "target_state": target_state, "reason": reason},
    )
    order = Order.objects.get(pk=order_id)
    old = order.status
    order.status = target_state
    order.last_error_text = f"state_overwrite:{reason}"
    order.save(update_fields=["status", "last_error_text", "updated_at"])
    sentry_sdk.add_breadcrumb(
        category="payments", type="info", level="warning",
        message="order_state_overwrite",
        data={"order_id": str(order.id), "from": old, "to": target_state, "reason": reason},
    )
    logger.warning(
        "order_state_overwrite",
        extra={"order_id": str(order.id), "from": old, "to": target_state, "reason": reason},
    )


def _optimistic_mark_paid(*, order: Order, expected_version: int, simulate: str) -> None:
    """Optimistic-lock style status update.

    Raises StaleDataError when version changed concurrently.
    """
    if simulate == "stale_race":
        # Simulate concurrent writer that bumps version first.
        Order.objects.filter(pk=order.pk).update(version=F("version") + 1)

    updated = (
        Order.objects
        .filter(pk=order.pk, version=expected_version)
        .update(
            status=OrderStatus.PAID,
            paid_at=timezone.now(),
            version=F("version") + 1,
            updated_at=timezone.now(),
        )
    )
    if updated == 0:
        raise StaleDataError(
            f"Optimistic lock failed for order={order.pk}; expected version={expected_version}"
        )
