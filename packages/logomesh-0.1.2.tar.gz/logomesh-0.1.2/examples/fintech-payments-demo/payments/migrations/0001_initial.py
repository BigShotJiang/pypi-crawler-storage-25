from __future__ import annotations

import uuid

from django.db import migrations, models


def default_public_id() -> str:
    return f"ORD-{uuid.uuid4().hex[:8].upper()}"


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Order",
            fields=[
                ("id", models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, serialize=False)),
                ("public_id", models.CharField(max_length=24, unique=True, default=default_public_id)),
                ("status", models.CharField(max_length=24, default="pending", choices=[("pending", "Pending"), ("processing", "Processing"), ("paid", "Paid"), ("failed", "Failed")])),
                ("amount_cents", models.PositiveIntegerField()),
                ("currency", models.CharField(max_length=3, default="USD")),
                ("customer_email", models.EmailField(max_length=254)),
                ("customer_stripe_id", models.CharField(max_length=128)),
                ("idempotency_token", models.CharField(max_length=64, default="", blank=True)),
                ("last_error_text", models.TextField(default="", blank=True)),
                ("version", models.PositiveIntegerField(default=0)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("paid_at", models.DateTimeField(null=True, blank=True)),
            ],
            options={"db_table": "payments_order"},
        ),
        migrations.CreateModel(
            name="Payment",
            fields=[
                ("id", models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, serialize=False)),
                ("stripe_charge_id", models.CharField(max_length=128, unique=True)),
                ("amount_cents", models.PositiveIntegerField()),
                ("currency", models.CharField(max_length=3)),
                ("provider_response", models.JSONField(default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("order", models.OneToOneField(on_delete=models.deletion.CASCADE, related_name="payment", to="payments.order")),
            ],
            options={"db_table": "payments_payment"},
        ),
        migrations.CreateModel(
            name="SettlementRecord",
            fields=[
                ("id", models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, serialize=False)),
                ("provider_event_id", models.CharField(max_length=128)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("payment", models.ForeignKey(on_delete=models.deletion.CASCADE, related_name="settlements", to="payments.payment")),
            ],
            options={"db_table": "payments_settlement_record"},
        ),
        migrations.CreateModel(
            name="PaymentAttempt",
            fields=[
                ("id", models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, serialize=False)),
                ("task_id", models.CharField(max_length=64)),
                ("attempt", models.PositiveSmallIntegerField(default=0)),
                ("status", models.CharField(max_length=24)),
                ("error_code", models.CharField(max_length=64, default="", blank=True)),
                ("error_message", models.TextField(default="", blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("order", models.ForeignKey(on_delete=models.deletion.CASCADE, related_name="attempts", to="payments.order")),
            ],
            options={"db_table": "payments_payment_attempt"},
        ),
        migrations.AddIndex(
            model_name="order",
            index=models.Index(fields=["status", "created_at"], name="payments_or_status_a8a6ee_idx"),
        ),
        migrations.AddIndex(
            model_name="order",
            index=models.Index(fields=["customer_stripe_id"], name="payments_or_custome_2453a8_idx"),
        ),
        migrations.AddIndex(
            model_name="paymentattempt",
            index=models.Index(fields=["order", "created_at"], name="payments_pa_order_i_8f4909_idx"),
        ),
        migrations.AddIndex(
            model_name="paymentattempt",
            index=models.Index(fields=["task_id"], name="payments_pa_task_id_27cca9_idx"),
        ),
    ]
