from __future__ import annotations

from django.core.management.base import BaseCommand, CommandError

from payments.tasks import (
    deterministic_key_failure,
    deterministic_type_failure,
    deterministic_value_failure,
)


class Command(BaseCommand):
    help = "Trigger deterministic easy crashes with rich locals"

    def add_arguments(self, parser):
        parser.add_argument("case", choices=["value", "type", "key"])

    def handle(self, *args, **options):
        case = options["case"]
        if case == "value":
            deterministic_value_failure(amount_cents=-14999, currency="usd", reason="negative settlement delta")
        if case == "type":
            deterministic_type_failure(retries="one", max_retries=1)
        if case == "key":
            deterministic_key_failure(payload={"order_id": "ORD-9182", "charge_id": "ch_missing"})
        raise CommandError("unreachable")
