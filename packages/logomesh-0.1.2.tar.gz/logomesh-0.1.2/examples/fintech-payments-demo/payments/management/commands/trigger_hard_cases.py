from __future__ import annotations

from django.core.management.base import BaseCommand

from payments.models import Order
from payments.tasks import process_payment


class Command(BaseCommand):
    help = "Trigger race-oriented hard cases"

    def add_arguments(self, parser):
        parser.add_argument("case", choices=["integrity_race", "stale_race", "fk_violation", "timing_race", "transient_db"])
        parser.add_argument("--order-id", default="")

    def handle(self, *args, **options):
        case = options["case"]
        order_id = options["order_id"]

        if not order_id:
            order = Order.objects.create(
                amount_cents=14999,
                currency="USD",
                customer_email="hardcase@example.com",
                customer_stripe_id="cus_hardcase_1",
            )
        else:
            order = Order.objects.get(pk=order_id)

        self.stdout.write(f"order={order.id} public_id={order.public_id} case={case}")

        if case == "integrity_race":
            # Two tasks for same order, same token. Missing idempotency means
            # duplicate attempts can collide on payment.order unique constraint.
            process_payment.delay(order_id=str(order.id), payment_token="tok_visa", simulate="integrity_race", request_id="race-a")
            process_payment.delay(order_id=str(order.id), payment_token="tok_visa", simulate="integrity_race", request_id="race-b")
        else:
            process_payment.delay(order_id=str(order.id), payment_token="tok_visa", simulate=case, request_id=f"hard-{case}")

        self.stdout.write(self.style.SUCCESS("tasks enqueued"))
