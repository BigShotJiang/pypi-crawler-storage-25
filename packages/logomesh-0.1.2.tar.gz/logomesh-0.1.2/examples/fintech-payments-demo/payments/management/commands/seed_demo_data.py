from django.core.management.base import BaseCommand

from payments.models import Order


class Command(BaseCommand):
    help = "Seed deterministic demo order data"

    def handle(self, *args, **options):
        if Order.objects.exists():
            self.stdout.write("orders already seeded")
            return
        for idx in range(1, 6):
            Order.objects.create(
                public_id=f"ORD-900{idx}",
                amount_cents=14999 + idx,
                currency="USD",
                customer_email=f"buyer{idx}@example.com",
                customer_stripe_id=f"cus_demo_{idx}",
            )
        self.stdout.write(self.style.SUCCESS("seeded 5 demo orders"))
