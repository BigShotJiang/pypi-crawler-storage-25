from __future__ import annotations

import json
import logging
from typing import Any

import stripe
from django.conf import settings
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

from payments.models import Order
from payments.tasks import process_payment

logger = logging.getLogger("payments.views")


def _json_body(request: HttpRequest) -> dict[str, Any]:
    if not request.body:
        return {}
    return json.loads(request.body.decode("utf-8"))


@csrf_exempt
def create_order(request: HttpRequest) -> JsonResponse:
    if request.method != "POST":
        return JsonResponse({"error": "method_not_allowed"}, status=405)

    payload = _json_body(request)
    order = Order.objects.create(
        amount_cents=int(payload.get("amount_cents", 14999)),
        currency=str(payload.get("currency", "USD")).upper(),
        customer_email=str(payload.get("customer_email", "buyer@example.com")),
        customer_stripe_id=str(payload.get("customer_stripe_id", "cus_demo_123")),
        idempotency_token=str(payload.get("idempotency_token", "")),
    )
    logger.info("order_created", extra={"order_id": str(order.id), "public_id": order.public_id})
    return JsonResponse(
        {
            "order_id": str(order.id),
            "public_id": order.public_id,
            "status": order.status,
            "amount_cents": order.amount_cents,
            "currency": order.currency,
        },
        status=201,
    )


@csrf_exempt
def start_payment(request: HttpRequest, order_id: str) -> JsonResponse:
    if request.method != "POST":
        return JsonResponse({"error": "method_not_allowed"}, status=405)

    payload = _json_body(request)
    payment_token = str(payload.get("payment_token", "tok_visa"))
    simulate = str(payload.get("simulate", ""))
    request_id = str(payload.get("request_id", "req-demo"))

    task = process_payment.apply_async(
        kwargs={
            "order_id": order_id,
            "payment_token": payment_token,
            "simulate": simulate,
            "request_id": request_id,
        },
        queue="payments",
    )

    logger.info("payment_task_enqueued", extra={"order_id": order_id, "task_id": task.id, "simulate": simulate})
    return JsonResponse({"queued": True, "task_id": task.id, "order_id": order_id, "simulate": simulate})


@csrf_exempt
def stripe_webhook(request: HttpRequest) -> HttpResponse:
    """Stripe webhook skeleton with signature verification.

    Events accepted:
      - charge.succeeded
      - charge.failed
      - payment_intent.payment_failed
    """
    payload = request.body
    sig_header = request.headers.get("Stripe-Signature", "")

    try:
        if settings.STRIPE_WEBHOOK_SECRET:
            event = stripe.Webhook.construct_event(payload, sig_header, settings.STRIPE_WEBHOOK_SECRET)
        else:
            event = json.loads(payload.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.exception("stripe_webhook_invalid", extra={"error": str(exc)})
        return HttpResponse(status=400)

    event_type = event.get("type", "unknown")
    logger.info("stripe_webhook_received", extra={"type": event_type, "id": event.get("id", "")})

    return HttpResponse(status=200)
