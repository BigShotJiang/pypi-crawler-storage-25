from django.contrib import admin

from payments.models import Order, Payment, PaymentAttempt, SettlementRecord


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("public_id", "status", "amount_cents", "currency", "version", "created_at")
    search_fields = ("public_id", "customer_email", "customer_stripe_id")


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("id", "order", "stripe_charge_id", "amount_cents", "created_at")
    search_fields = ("stripe_charge_id", "order__public_id")


@admin.register(PaymentAttempt)
class PaymentAttemptAdmin(admin.ModelAdmin):
    list_display = ("id", "order", "task_id", "attempt", "status", "created_at")


@admin.register(SettlementRecord)
class SettlementRecordAdmin(admin.ModelAdmin):
    list_display = ("id", "payment", "provider_event_id", "created_at")
