"""Pure-python crash lab for deterministic Sentry replay tests.

This module mirrors payment-domain failure signatures without Django imports,
so logomesh sandbox can run replays with zero external dependencies.
"""

from __future__ import annotations


class IntegrityError(Exception):
    pass


class ForeignKeyViolation(Exception):
    pass


class StaleDataError(Exception):
    pass


def process_payment(*, order_id: str, seen_order_ids: list[str], amount_cents: int, charge_id: str) -> str:
    """Deliberate idempotency bug simulation.

    If order_id already exists in seen_order_ids, raise same Postgres-like
    duplicate-key signature logomesh should classify.
    """
    if order_id in seen_order_ids:
        raise IntegrityError(
            'duplicate key value violates unique constraint "payments_payment_order_id_key"\n'
            f"DETAIL:  Key (order_id)=({order_id}) already exists."
        )
    if amount_cents <= 0:
        raise ValueError(f"invalid amount_cents={amount_cents}")
    seen_order_ids.append(order_id)
    return charge_id


def settle_payment(*, payment_id: str, known_payment_ids: set[str]) -> None:
    if payment_id not in known_payment_ids:
        raise IntegrityError(
            f"insert or update on table \"payments_settlement_record\" violates foreign key constraint; payment_id={payment_id}"
        )


def optimistic_mark_paid(*, order_id: str, expected_version: int, actual_version: int) -> None:
    if expected_version != actual_version:
        raise StaleDataError(
            f"Optimistic lock failed for order={order_id}; expected version={expected_version}, actual={actual_version}"
        )


def crash_type_path(*, retries, max_retries: int) -> int:
    return retries + max_retries


def crash_key_path(*, payload: dict) -> str:
    return payload["customer_id"]
