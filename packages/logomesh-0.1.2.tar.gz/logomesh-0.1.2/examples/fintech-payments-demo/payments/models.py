from __future__ import annotations

import uuid

from django.db import models
from django.utils import timezone


def default_public_id() -> str:
    return f"ORD-{uuid.uuid4().hex[:8].upper()}"


class OrderStatus(models.TextChoices):
    PENDING = "pending", "Pending"
    PROCESSING = "processing", "Processing"
    PAID = "paid", "Paid"
    FAILED = "failed", "Failed"


class Order(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    public_id = models.CharField(max_length=24, unique=True, default=default_public_id)
    status = models.CharField(max_length=24, choices=OrderStatus.choices, default=OrderStatus.PENDING)
    amount_cents = models.PositiveIntegerField()
    currency = models.CharField(max_length=3, default="USD")
    customer_email = models.EmailField()
    customer_stripe_id = models.CharField(max_length=128)
    idempotency_token = models.CharField(max_length=64, blank=True, default="")
    last_error_text = models.TextField(blank=True, default="")
    version = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "payments_order"
        indexes = [
            models.Index(fields=["status", "created_at"]),
            models.Index(fields=["customer_stripe_id"]),
        ]

    def mark_processing(self) -> None:
        self.status = OrderStatus.PROCESSING
        self.save(update_fields=["status", "updated_at"])

    def mark_paid(self) -> None:
        self.status = OrderStatus.PAID
        self.paid_at = timezone.now()
        self.save(update_fields=["status", "paid_at", "updated_at"])


class Payment(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.OneToOneField(Order, related_name="payment", on_delete=models.CASCADE)
    stripe_charge_id = models.CharField(max_length=128, unique=True)
    amount_cents = models.PositiveIntegerField()
    currency = models.CharField(max_length=3)
    provider_response = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "payments_payment"


class SettlementRecord(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    payment = models.ForeignKey(Payment, related_name="settlements", on_delete=models.CASCADE)
    provider_event_id = models.CharField(max_length=128)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "payments_settlement_record"


class PaymentAttempt(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.ForeignKey(Order, related_name="attempts", on_delete=models.CASCADE)
    task_id = models.CharField(max_length=64)
    attempt = models.PositiveSmallIntegerField(default=0)
    status = models.CharField(max_length=24)
    error_code = models.CharField(max_length=64, blank=True, default="")
    error_message = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "payments_payment_attempt"
        indexes = [
            models.Index(fields=["order", "created_at"]),
            models.Index(fields=["task_id"]),
        ]
