from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

import stripe

stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")


def create_charge(*, amount_cents: int, currency: str, customer_stripe_id: str, source: str, metadata: dict):
    use_fake = os.getenv("STRIPE_USE_FAKE_GATEWAY", "1").strip().lower() in {"1", "true", "yes", "on"}
    if use_fake:
        return {
            "id": f"ch_fake_{uuid.uuid4().hex[:24]}",
            "status": "succeeded",
            "amount": amount_cents,
            "currency": currency.lower(),
            "customer": customer_stripe_id,
            "source": source,
            "metadata": metadata,
            "created": datetime.now(timezone.utc).isoformat(),
            "livemode": False,
        }

    return stripe.Charge.create(
        amount=amount_cents,
        currency=currency.lower(),
        customer=customer_stripe_id,
        source=source,
        metadata=metadata,
        # Deliberate product bug: missing Stripe idempotency key. This is the
        # reproducible race path when task retries or workers race.
    )
