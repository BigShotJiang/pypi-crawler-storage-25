# fintech-payments-demo

Hyper-realistic Django fintech payments backend intentionally designed to demonstrate where logomesh is strong (deterministic repro from rich locals) and where humans still need to review (mismatched exception paths, race-only failures, source resolution gaps).

## Stack

- Django 5.1
- Celery 5.4
- PostgreSQL 16
- Redis 7
- Stripe API (with local fake gateway mode by default)
- Optional Sentry SDK integration

## Quick Start (< 60s)

```bash
cp .env.example .env
docker compose up --build
```

System boots:
- API: `http://localhost:8000`
- Health endpoint: `http://localhost:8000/healthz`
- Celery worker + beat included

## Main Domain Objects

- `Order`: payment intent + lifecycle (`pending` -> `processing` -> `paid|failed`)
- `Payment`: provider charge record. **One payment per order enforced by unique `order_id`**
- `PaymentAttempt`: per-task execution audit trail
- `SettlementRecord`: post-charge bookkeeping

## Critical Bug (Deliberate)

`payments/tasks.py` task `process_payment` intentionally omits provider-level idempotency and de-dup guards before `Payment.objects.create(...)`.

When two workers process same order (or task retries), system can hit:

`IntegrityError: duplicate key value violates unique constraint "payments_payment_order_id_key"`

This is the exact race-condition class logomesh should identify and replay.

## Endpoints

### Create order

```bash
curl -sS -X POST http://localhost:8000/api/orders \
  -H 'content-type: application/json' \
  -d '{
    "amount_cents": 14999,
    "currency": "USD",
    "customer_email": "buyer@example.com",
    "customer_stripe_id": "cus_demo_123"
  }' | jq
```

### Queue payment task

```bash
curl -sS -X POST http://localhost:8000/api/orders/<ORDER_ID>/pay \
  -H 'content-type: application/json' \
  -d '{"payment_token":"tok_visa","simulate":"integrity_race","request_id":"manual-test"}' | jq
```

### Stripe webhook skeleton

```bash
curl -sS -X POST http://localhost:8000/api/stripe/webhook \
  -H 'content-type: application/json' \
  -d '{"id":"evt_demo","type":"charge.succeeded","data":{"object":{"id":"ch_demo"}}}' -i
```

## Hard Crash Scenarios

All hard cases implemented in `payments/tasks.py`.

1. `integrity_race`
   - Two tasks create `Payment` for same order.
   - Triggers duplicate key on `payments_payment_order_id_key`.

2. `stale_race`
   - Optimistic lock update with version mismatch.
   - Raises `sqlalchemy.orm.exc.StaleDataError`.

3. `fk_violation`
   - Simulates partial Stripe success, then writes invalid FK settlement row.
   - Triggers DB `IntegrityError` (FK violation).

4. `timing_race`
   - Concurrent task overwrites order status with conflicting state.
   - Demonstrates timing-sensitive state races.

5. `transient_db`
   - Throws `OperationalError`, Celery retries once.
   - Retry path can amplify duplicate races.

Trigger helper:

```bash
python scripts/trigger_crash.py --case integrity_race
python scripts/trigger_crash.py --case stale_race
python scripts/trigger_crash.py --case fk_violation
python scripts/trigger_crash.py --case timing_race
python scripts/trigger_crash.py --case transient_db
```

## Easy Deterministic Crash Scenarios

Management command with rich locals:

```bash
docker compose exec web python manage.py trigger_easy_crashes value
docker compose exec web python manage.py trigger_easy_crashes type
docker compose exec web python manage.py trigger_easy_crashes key
```

## logomesh Repro Workflow

Use from repo root where logomesh is installed:

```bash
# Example Sentry URL form (replace with your issue)
logomesh repro https://your-org.sentry.io/issues/1234567890/ --repo ./fintech-payments-demo --details
```

Expected outcomes:
- `Reproduced`: sandbox failure exception type matches Sentry incident type.
- `Needs human review`: sandbox failed but exception type mismatched.
- `Cannot reproduce`: test passed or no failure collected.

## Local Dev Notes

- Default `.env.example` uses fake Stripe gateway (`STRIPE_USE_FAKE_GATEWAY=1`) for deterministic local runs.
- Set `STRIPE_USE_FAKE_GATEWAY=0` and a real `STRIPE_SECRET_KEY` for live Stripe.
- Set `SENTRY_DSN` to capture exceptions in Sentry.

## Production-Like Logging

`process_payment` writes structured breadcrumbs:
- `process_payment_started`
- `process_payment_succeeded`
- `process_payment_failed`
- `order_state_overwrite`

Use logs to correlate retries, races, and task IDs.

## How to use this repo to test logomesh

### 1) Spin up stack

```bash
cp .env.example .env
docker compose up --build
```

### 2) Trigger hard IntegrityError race

```bash
python scripts/trigger_crash.py --case integrity_race
```

Then create/point a Sentry issue at the captured `IntegrityError`, and run:

```bash
logomesh repro https://your-org.sentry.io/issues/<ISSUE_ID>/ --repo ./fintech-payments-demo --details
```

### 3) Trigger easy deterministic crashes

```bash
docker compose exec web python manage.py trigger_easy_crashes value
docker compose exec web python manage.py trigger_easy_crashes type
docker compose exec web python manage.py trigger_easy_crashes key
```

### 4) Trigger medium/hard scenario variants

```bash
python scripts/trigger_crash.py --case stale_race
python scripts/trigger_crash.py --case fk_violation
python scripts/trigger_crash.py --case timing_race
python scripts/trigger_crash.py --case transient_db
```

