from target import *

def test_sentry_replay_id_7470722083():
    """Replay: IntegrityError: insert or update on table 'payments_settlement_record' violates foreign key constraint"""
    settle_payment(payment_id='[REDACTED:PAN]-[REDACTED:PAN]', known_payment_ids='set()')
