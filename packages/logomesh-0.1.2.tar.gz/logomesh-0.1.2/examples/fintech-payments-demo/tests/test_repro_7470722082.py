from target import *

def test_sentry_replay_id_7470722082():
    """Replay: StaleDataError: Optimistic lock failed for order=ORD-9182; expected version=3, actual=4"""
    optimistic_mark_paid(order_id='ORD-9182', expected_version=3, actual_version=4)
