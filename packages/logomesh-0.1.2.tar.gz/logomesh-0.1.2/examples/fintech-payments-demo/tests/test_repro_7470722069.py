from target import *

def test_sentry_replay_id_7470722069():
    """Replay: IntegrityError: duplicate key value violates unique constraint 'payments_payment_order_id_key'"""
    process_payment(order_id='ORD-9182', seen_order_ids=['ORD-9182'], amount_cents=14999, charge_id='ch_3PqX9LK2eZvKYlo20001')
