# Pilot deployment — warm customer in 30 minutes

This is the runbook for putting logomesh on a public URL so a real
Sentry organization can drive the wizard end-to-end without you on
Zoom.

The goal is **Item 1 of the ready-to-ship checklist**: a customer
clicks the wizard, connects Sentry, their first crash fires, and they
see the verdict + sealed artifact in their Sentry issue thread without
the operator touching anything.

## What you need before you start

- A box (your laptop is fine for the first pilot) with Docker running.
- A public hostname for the box. Cloudflare Tunnel works in 60 seconds:
  ```bash
  brew install cloudflared
  cloudflared tunnel --url http://localhost:8080
  # → prints https://<random>.trycloudflare.com
  ```
- Optional but recommended: a Supabase project. The dev backend has an
  in-memory fallback (`LOGOMESH_DEV_MEMORY_BACKEND=1`) but anything you
  store dies on restart, including the customer's wizard secrets.
- An OpenAI key with a budget of at least \$5 (the cost cap is \$1/run,
  default).
- The customer's source tree cloned at a path you can name in
  `LOGOMESH_REPO_PATH` (or per-install `repo_path` later).

## Required env

```bash
# crypto
export LOGOMESH_MASTER_KEY=$(python -c "import os,base64;print(base64.urlsafe_b64encode(os.urandom(32)).decode())")
# storage
export SUPABASE_URL=https://<your-project>.supabase.co
export SUPABASE_SERVICE_KEY=<service-role-key>
# public host the wizard prints in the Sentry webhook URL
export LOGOMESH_PUBLIC_HOST=https://<your-tunnel>.trycloudflare.com
# LLM
export OPENAI_API_KEY=sk-...
export LOGOMESH_LLM_PROVIDER=openai
export LOGOMESH_ORCHESTRATOR_MODEL=gpt-5-mini
export LOGOMESH_REPRO_MODEL=gpt-5-mini
# customer source
export LOGOMESH_REPO_PATH=/srv/repos/<customer>
# safety: refuse to boot in production without Docker isolation
export LOGOMESH_ENV=production
# safety: 200k/40k tokens, $1.00 hard cap per run
# (defaults; override only to tighten further)
```

If you skip Supabase for the demo, set
`LOGOMESH_DEV_MEMORY_BACKEND=1` and accept that wizard secrets vanish
on restart. **Do not run a real customer on the in-memory backend.**

## Apply the schema

```bash
psql $SUPABASE_DB_URL -f migrations/0001_installation_secrets.sql
psql $SUPABASE_DB_URL -f migrations/0002_runs.sql
```

## Boot

```bash
uv run uvicorn server.app:app --port 8080 --app-dir src
```

Health check:

```bash
curl https://<your-tunnel>.trycloudflare.com/health
# → {"status": "ok"}
```

## What happens when the customer arrives

1. They open `<wizard-URL>/onboarding`. Step 1 is welcome; step 2
   creates an install.
2. The wizard's `POST /api/installations` returns
   `{id, client_secret, webhook_url}`. The wizard saves both id and
   secret to localStorage; every subsequent call presents the secret
   as a Bearer token.
3. Step 3 prints `webhook_url` and `client_secret`. The customer pastes
   them into Sentry's *Custom Integration* form (Settings →
   Developer Settings → New Internal Integration). Permissions:
   `event:read` + `event:write` on Issue/Comment.
4. The customer pastes their Sentry auth token back into the wizard.
   `PUT /sentry-token` validates it against Sentry's `/api/0/auth/`
   live — if the scope is wrong, the customer sees a 400 with a real
   reason ("403 forbidden — token lacks required scopes") instead of a
   silent failure on the first crash.
5. Step 4 collects a GitHub PAT + repo. `PUT /github` validates the
   PAT can push to the repo. Read-only PATs are rejected immediately.
6. Step 5 (optional) collects a Slack incoming webhook URL. `PUT
   /slack` posts a real test message; bad URLs surface as 400.
7. The customer hits "Send test event". `POST /test` runs the
   orchestrator end-to-end against a checked-in fixture; the wizard
   polls `/runs` and shows `status: shipped, verified: true` ~30s later.
   No external comments posted (the issue ID is synthetic).
8. They go back to their app and trigger a real exception. Sentry
   POSTs the issue webhook to `LOGOMESH_PUBLIC_HOST/webhooks/sentry/{id}`.
9. HMAC verify runs against the per-install `client_secret`.
   Orchestrator fetches the real Sentry event with the per-install
   auth token, runs the deterministic synthesizer + sandbox, produces
   the sealed artifact.
10. The verdict is posted back to the Sentry issue as a comment via
    the per-install token. If a draft PR step is configured, it opens
    on the per-install GitHub repo.

## Pre-flight check before handing the URL to the customer

Run this against your tunnelled URL — if every step prints a 2xx, the
customer can drive the wizard alone.

```bash
HOST=https://<your-tunnel>.trycloudflare.com
curl -sf $HOST/health

# 1. Create install
CREATE=$(curl -sf -X POST $HOST/api/installations -H "Content-Type: application/json" -d '{}')
ID=$(echo "$CREATE" | jq -r .id)
SECRET=$(echo "$CREATE" | jq -r .client_secret)

# 2. Save Sentry token (real, not skipped)
curl -i -X PUT -H "Authorization: Bearer $SECRET" -H "Content-Type: application/json" \
  -d "{\"token\": \"$SENTRY_AUTH_TOKEN\"}" \
  "$HOST/api/installations/$ID/sentry-token"

# 3. Save GitHub creds (real)
curl -i -X PUT -H "Authorization: Bearer $SECRET" -H "Content-Type: application/json" \
  -d "{\"token\": \"$GITHUB_TOKEN\", \"repo\": \"<customer>/<repo>\"}" \
  "$HOST/api/installations/$ID/github"

# 4. Fire a synthetic crash through the full pipeline
curl -i -X POST -H "Authorization: Bearer $SECRET" -H "Content-Type: application/json" -d '{}' \
  "$HOST/api/installations/$ID/test"

# 5. Wait + read the artifact
sleep 45
curl -s -H "Authorization: Bearer $SECRET" "$HOST/api/installations/$ID/runs?limit=1" | jq
```

If step 5 shows `status: "shipped"` and `verified_exception_match: true`,
the warm pilot can drive the wizard without you on the call.

## Things that will go wrong on a real customer

| Symptom | Cause | Fix |
|---|---|---|
| 401 on `POST /webhooks/sentry/{id}` | Customer mistyped the client_secret in Sentry's Custom Integration form | Have them re-paste from the wizard's Step 3 |
| `frame_locals_insufficient` on every crash | Sentry events don't carry frame locals — they enabled `attach_stacktrace` but not `with_locals` | Have them set `with_locals=True` in their `sentry_sdk.init` |
| Comments don't appear on the Sentry issue | Token lacks `event:write` on `comment` | Customer creates a new auth token with the right scope; re-paste in wizard |
| Draft PRs fail | The PAT validation passed read but the repo's branch protections require signed commits | Either disable signed-commit enforcement on the bot's branch or use GitHub App auth (post-pilot) |
| Pipeline runs cost $0.50+ | Customer triggered a path the model retried multiple times; budget cap will hard-stop at $1 | Tune `LOGOMESH_USD_BUDGET` lower for sensitive deploys |

## What you must NOT promise the first pilot

- Anything about prod throughput. The semaphore caps in-flight runs at
  3. Above that, Sentry retries.
- Comment posting on the synthetic `/test` event. The fake issue id
  doesn't exist in their Sentry org.
- Per-install OpenAI keys — the platform pays for tokens in v1; the
  cost cap protects you. Per-install LLM keys land post-pilot.
