# logomesh Pipeline Manual

> Written for someone who built this but hasn't sat with the full picture yet.
> Read Part 1 top-to-bottom once. Use the debug exercises to poke things yourself.
> Parts 2–4 are reference — jump to them when you need them.

---

## Table of Contents

- [Part 1 — The `repro` Command](#part-1--the-repro-command)
  - [1.1 Overview](#11-overview)
  - [1.2 Stage 1: Parse the Sentry URL](#12-stage-1-parse-the-sentry-url)
  - [1.3 Stage 2: Fetch the Crash from Sentry](#13-stage-2-fetch-the-crash-from-sentry)
  - [1.4 Stage 3: Find the Right Frame](#14-stage-3-find-the-right-frame)
  - [1.5 Stage 4: Read the Source](#15-stage-4-read-the-source)
  - [1.6 Stage 5: Synthesize the Test](#16-stage-5-synthesize-the-test)
  - [1.7 Stage 6: Run in the Sandbox](#17-stage-6-run-in-the-sandbox)
  - [1.8 Stage 7: Retry if Not Reproduced](#18-stage-7-retry-if-not-reproduced)
  - [1.9 Stage 8: Output the Result](#19-stage-8-output-the-result)
  - [1.10 Full Data Flow Diagram](#110-full-data-flow-diagram)
- [Part 2 — The Orchestrator (Agentic Wrapper)](#part-2--the-orchestrator-agentic-wrapper)
  - [2.1 The Compliance Contract](#21-the-compliance-contract)
  - [2.2 Stage O1: Supervisor (LangGraph)](#22-stage-o1-supervisor-langgraph)
  - [2.3 Stage O2: Deterministic Repro (sealed)](#23-stage-o2-deterministic-repro-sealed)
  - [2.4 Stage O3: Path B Primitives](#24-stage-o3-path-b-primitives)
  - [2.5 Stage O4: prepare_environment](#25-stage-o4-prepare_environment)
  - [2.6 Stage O5: Self-Refusal Loop](#26-stage-o5-self-refusal-loop)
  - [2.7 Stage O6: Critic + Verification Gate](#27-stage-o6-critic--verification-gate)
  - [2.8 Stage O7: Artifact (SOC2 / PCI)](#28-stage-o7-artifact-soc2--pci)
  - [2.9 Stage O8: Hypothesis Report (Last-Resort Fallback)](#29-stage-o8-hypothesis-report-last-resort-fallback)
  - [2.10 Generic Repo-Analysis Primitives](#210-generic-repo-analysis-primitives)
  - [2.11 What Was Cut and Why](#211-what-was-cut-and-why)
  - [2.12 Golden Regression Suite (Hard Cases)](#212-golden-regression-suite-hard-cases)
- [Part 3 — The Wizard & Installation Layer](#part-3--the-wizard--installation-layer)
  - [3.1 Overview](#31-overview)
  - [3.2 Installation Lifecycle](#32-installation-lifecycle)
  - [3.3 Secrets & Encryption](#33-secrets--encryption)
  - [3.4 Supabase Schema](#34-supabase-schema)
  - [3.5 Token Budget & Cost Tracking](#35-token-budget--cost-tracking)
- [Part 4 — Module Map](#part-4--module-map)
- [Part 5 — Debug Exercises](#part-5--debug-exercises)
  - [Exercise 1: Add a log statement and watch it fire](#exercise-1-add-a-log-statement-and-watch-it-fire)
  - [Exercise 2: Run the sandbox directly](#exercise-2-run-the-sandbox-directly)
  - [Exercise 3: Read a Sentry frame without the API](#exercise-3-read-a-sentry-frame-without-the-api)
  - [Exercise 4: Trace what the LLM generates](#exercise-4-trace-what-the-llm-generates)
  - [Exercise 5: Understand a Finding](#exercise-5-understand-a-finding)
- [Part 6 — Common Failure Modes](#part-6--common-failure-modes)
- [Part 7 — Manuals](#part-7--manuals)
  - [Manual A: How to Read Your Own Code](#manual-a-how-to-read-your-own-code)
  - [Manual B: Become a Better Engineer](#manual-b-become-a-better-engineer)
  - [Manual C: Online Resources](#manual-c-online-resources)
- [Appendix — Sprint Changelog](#appendix--sprint-changelog)

---

## Part 1 — The `repro` Command

### 1.1 Overview

`logomesh repro` is the product. You paste a Sentry URL, and logomesh:

```
"What crashed, where, with what values?"
 → writes a pytest calling that function with the same inputs
 → runs it in a sandboxed container
 → tells you if it reproduced, with a signed artifact
```

The other command, `logomesh check`, adversarially tests a changed Python file. It powers the GitHub App and uses the same sandbox under the hood. It's deprioritized for now — `repro` is what you demo.

| Command | What it does | Status |
|---|---|---|
| `logomesh repro <sentry-url>` | Reproduce a Sentry crash as a sealed pytest | **Current product** |
| `logomesh check <path>` | Adversarially test a changed Python file | Deprioritized |

---

### 1.2 Stage 1: Parse the Sentry URL

**File:** `src/cli/repro.py` → `parse_sentry_url()`

Extracts `org` and `issue_id` from a Sentry issue URL.

```python
# Try it yourself:
from cli.repro import parse_sentry_url
org, issue_id = parse_sentry_url("https://sentry.io/organizations/acme/issues/12345678/")
print(org, issue_id)  # → acme  12345678
```

> **What can go wrong:** URL doesn't match the pattern → `ValueError`. Must be an issue URL (contains `/issues/`), not a project or alert URL.

---

### 1.3 Stage 2: Fetch the Crash from Sentry

**File:** `src/oracles/sentry_replay.py` → `fetch_event_by_issue()`

Calls the Sentry API with your `SENTRY_AUTH_TOKEN`. Returns a `SentryException`:

```python
exc.error_type      # "decimal.InvalidOperation"
exc.error_message   # "invalid literal for Decimal()"
exc.stacktrace      # list of frames, innermost last
```

> **What can go wrong:**
> - `SENTRY_AUTH_TOKEN` missing → `"SENTRY_AUTH_TOKEN is not set"`
> - Issue too old, event purged → empty stacktrace
> - Token wrong scope → 403

> **Tip:** Set `LOGOMESH_SENTRY_FIXTURE=<path>` to bypass the API and use a local JSON fixture. Useful offline or without a token.

**Extended fields populated when present** (PR2, 2026-05-10):

```python
exc.request       # SentryRequest | None — HTTP method/url/headers/body
exc.modules       # dict[str, str] — pip-freeze at crash time
exc.breadcrumbs   # list[SentryBreadcrumb] — ordered events with data
exc.threads       # list[SentryThread] — per-thread state + held_locks
exc.runtime       # SentryRuntime | None — name/version/build (CPython 3.12.5)
exc.release       # str — release identifier (often a git SHA)
exc.transaction   # str — framework route / task name
```

Each surface runs through PII redaction at parse time. Headers use an allowlist (`Content-Type`, `Accept`, `User-Agent`, `X-Request-Id`, etc); everything else becomes `[REDACTED:HEADER]`. Request body + breadcrumb data go through the same recursive `redact_mapping` that frame locals use.

These fields feed three downstream paths:
- `exc.modules` → `prepare_environment(module_versions=...)` (Stage O4)
- `exc.runtime.version` → `Sandbox.run(python_version=...)` (allowlisted `{3.10, 3.11, 3.12, 3.13}`)
- `exc.request` → optional `build_request_replay_test_v2` synthesizer that emits a `client.request(...)` test from the captured method/url/body
- `exc.breadcrumbs` + `exc.threads` → hypothesis report evidence extractor (Stage O8)

---

### 1.4 Stage 3: Find the Right Frame

**File:** `src/oracles/sentry_replay.py` → `find_innermost_app_frame()`

Picks the innermost frame in your app code (not library code). Filters out:
- Frames from `site-packages/`
- Frames from `<string>` or `<frozen importlib>`
- Frames where `in_app` is `False`

```python
frame.function   # "apply_discount"
frame.filename   # "src/billing/discount.py"
frame.lineno     # 42
frame.variables  # {"price": "49.95", "qty": "-1"}  ← gold
```

`frame.variables` holds the **real values in memory at crash time**. This is why the repro test is accurate instead of made-up.

> **What can go wrong:** Returns `None` if every frame is library code. The crash hit middleware before reaching app code — try a different Sentry issue.

---

### 1.5 Stage 4: Read the Source

**File:** `src/cli/repro.py` → `_read_target_source()`

Walks up from repo root, matching the Sentry filename against the local filesystem.

- **Found:** Full Python file goes into the sandbox as `target.py`.
- **Not found:** Falls back to `frame.context_line` — one line from Sentry. Enough to attempt a repro.

> **What can go wrong:** Sentry uses prod absolute paths (`/app/src/billing/discount.py`). Your local repo has `src/billing/discount.py`. The resolver strips leading path components — but if local layout differs from prod, it misses. Use `--repo /path/to/your/repo` to help.

---

### 1.6 Stage 5: Synthesize the Test

**File:** `src/oracles/sentry_replay.py` → `synthesize_test_llm()`

Asks an LLM to write a pytest from the crash info (error type, message, frame locals, source). The generated test:

1. Imports the crashing function from `target.py`
2. Calls it with the same arguments that were in memory at crash time
3. Does **not** use `pytest.raises` — the exception must propagate naturally

```python
from target import apply_discount

def test_repro_apply_discount_decimal_invalidoperation():
    # frame locals at crash: price="49.95", qty=-1
    result = apply_discount(price="49.95", qty=-1)
    assert result >= 0
```

Pass `--no-llm` to skip the LLM and use `build_replay_test()` — a deterministic version that plugs frame locals straight in.

> **What can go wrong:**
> - LLM returns no `def test_` → falls back to deterministic
> - LLM writes `pytest.raises` (which the prompt forbids) → test "passes" but doesn't prove the crash

---

### 1.7 Stage 6: Run in the Sandbox

**File:** `src/business_logic/sandbox/__init__.py` → `Sandbox.run()`

1. Creates a temp directory
2. Writes `target.py` + `test_target.py`
3. Runs `pytest` inside Docker (subprocess fallback if Docker unavailable)
4. Returns a result dict

```python
{
    "passed": 0,
    "failed": 1,       # ← want this. failure = crash reproduced
    "total": 1,
    "output": "FAILED test_target.py::test_repro... ZeroDivisionError",
    "success": True,   # sandbox itself ran OK (separate from test pass/fail)
}
```

Docker container is airgapped: no network, no pip-installing from the PR, 512KB file cap, randomized report filename. Prevents supply-chain attacks from test code.

**"Reproduced" = `result["failed"] > 0`**. The test *failed*, which means the bug *exists*.

> **What can go wrong:**
> - `success=False, total=0` → sandbox itself crashed (syntax error, import error). Check `output`.
> - `success=True, failed=0` → test passed. Bug not reproduced. Stage 7 retries.
> - Docker not available → subprocess fallback kicks in. Less isolated, still works.

> **Tip:** Run the sandbox directly to test it without touching Sentry — see [Exercise 2](#exercise-2-run-the-sandbox-directly).

---

### 1.8 Stage 7: Retry if Not Reproduced

**File:** `src/cli/repro.py` → `_retry_with_analysis()`

If the first test passed (bug not reproduced), logomesh sends the failing test + passing output back to the LLM and asks it to refine the test. Runs once. If the retry also passes → "not reproduced."

Common reason the retry helps: first test used the wrong type (`qty="-1"` as string instead of `qty=-1` as int).

---

### 1.9 Stage 8: Output the Result

**File:** `src/cli/repro.py` → `_render_result()`

| Exit code | Meaning |
|---|---|
| `0` | Reproduced — test failed = bug confirmed on this branch |
| `1` | Not reproduced — test passed = bug may be fixed, or repro insufficient |
| `2` | Error — bad URL, missing token, sandbox failure |

With `--artifact`: JSON envelope with crash evidence, git branch/commit, and compliance mappings to **SOC2 CC7.3 + CC7.4** and **PCI DSS 12.10.5** (incident response). Earlier docs referenced PCI 6.3.2 — that's pre-release code review, wrong mapping for a post-incident artifact.

---

### 1.10 Full Data Flow Diagram

```
logomesh repro <url>
        │
        ▼
parse_sentry_url()          → (org, issue_id)
        │
        ▼
fetch_event_by_issue()      → SentryException
        │
        ▼
find_innermost_app_frame()  → StackFrame (function, filename, lineno, variables)
        │
        ▼
_read_target_source()       → Python source string
        │
        ▼
synthesize_test_llm()       → pytest string ("def test_repro_...")
        │
        ▼
Sandbox.run()               → {failed: N, passed: M, output: "..."}
        │
        ├── failed > 0 → exit 0  ✓ REPRODUCED
        │
        ├── failed = 0 → _retry_with_analysis()
        │                      │
        │                      ├── failed > 0 → exit 0  ✓ REPRODUCED
        │                      └── failed = 0 → exit 1  ✗ NOT REPRODUCED
        │
        └── sandbox error → exit 2  ! ERROR
```

---

## Part 2 — The Orchestrator (Agentic Wrapper)

Part 1 is the **deterministic core** — a calculator. The orchestrator is the **person sitting in front of the calculator** deciding which buttons to press. It's a LangGraph supervisor that calls the deterministic core as a tool.

The core stays sealed and ships byte-identical artifacts regardless of which model drives the wrapper.

---

### 2.1 The Compliance Contract

Three rules govern every code change in the orchestrator. Breaking any one turns logomesh into a normal autofix tool.

**Rule 1 — Sealed evidence path.**
Bytes in the artifact came from the deterministic synthesizer + sandbox only. No LLM token touches the call expression, the test code, or the sandbox output. Stamped: `evidence_path_seal.llm_in_evidence_path: false`.

**Rule 2 — Verified exception match.**
"Reproduced" means the sandbox raised the **same exception type** the Sentry event captured. `failed > 0` alone is not enough — a `NameError` from a busted import also counts as failed. `verified_exception_match: true` only when the types match.

**Rule 3 — No silent ship on mismatch.**
If verification fails → `needs_human_review: true` with a reason. Never a green "shipped" with a wrong artifact.

> These rules are the regulated-buyer moat. Lose them and the product is indistinguishable from any LLM autofix.

---

### 2.2 Stage O1: Supervisor (LangGraph)

**File:** `logomesh_orchestrator.py` → `_build_graph()` + `supervisor_node()`

LangGraph is a state-machine library. Each "box" is a Python function; edges are conditional; a shared `OrchestratorState` dict gets passed around.

```python
class OrchestratorState(TypedDict, total=False):
    sentry_event_raw: dict
    repro_result: ReproResult | None       # sealed bytes go here
    critic_report: CriticReport | None
    critic_attempts: int
    step_count: int                        # supervisor turns taken
    max_tool_calls: int                    # optional override; 0 => default cap
    needs_human_review: bool
    artifact: dict | None
    environment_prep: dict | None          # advisory infra block
    audit_session_id: str
```

Graph shape:

```
START → supervisor → tool_node → supervisor → critic → finalizer → END
                       ↑__________|              |
                       (loop while critic        (forced finalize on
                        rejects, max 3)           verification fail OR
                                                  max-step guard)
```

**Tools (11 total, Pydantic-typed):**

| # | Tool | Role | Advisory or Sealed? |
|---|---|---|---|
| 1 | `fetch_sentry_event` | pulls event or fixture | advisory |
| 2 | `deterministic_repro` | **only sealed-evidence tool** | **sealed** |
| 3 | `hypothesis_invariant_suggester` | ranks property hypotheses | advisory |
| 4 | `context_reconstructor` | db/async/globals/c-ext probe | advisory |
| 5 | `critic_validate` | fires verification gate | advisory |
| 6 | `web_search` | Tavily / PyPI / GitHub / CVE | advisory |
| 7 | `rag_search` | local index + grep fallback | advisory |
| 8 | `build_artifact` | stamps `evidence_path_seal` from sealed `ReproResult` | advisory |
| 9 | `create_draft_pr` | opens PR with sealed artifact | advisory |
| 10 | `prepare_environment` | auto-builds wheel snapshot for sandbox; accepts `module_versions` (from `exc.modules`) to pin manifest deps to prod pip-freeze | advisory |
| 11 | `introspect_repo` | scans the repo and returns structured evidence (imports, manifest deps, class shapes, callable decorators, config files, entrypoints) — never names a framework, never decides routing | advisory |

> **Courtroom analogy:** advisory tools are the lawyer's research notes. `deterministic_repro` is the signed exhibit. The exhibit cannot contain notes — only what was on the stand under oath.

Supervisor hard-stop rail:
- `step_count` increments after each supervisor LLM call.
- If `step_count >= _max_supervisor_steps(...)` (default 10), graph no longer follows tool calls.
- Router forces `critic_gate` (if sealed repro exists and critic not run) else `finalizer`.
- Finalizer preserves `needs_human_review=True` with reason `orchestrator_max_steps_exceeded`.

---

### 2.3 Stage O2: Deterministic Repro (sealed)

**File:** `logomesh_orchestrator.py` → `_tool_deterministic_repro()`

The only path that produces artifact bytes.

1. Compute `crash_signature(error_type, function, filename)` → cache key
2. If `_REPRO_REGISTRY[sig]` exists → return cached `ReproResult`
3. Pick innermost in-app frame (`find_innermost_app_frame`)
4. Source resolution via `resolve_source_with_hints` (Path B + self-refusal)
5. Synthesize via `build_replay_test_v2(exc, frame, source)` — pure-Python, no LLM
6. Run sandbox. On import failure + not yet retried → auto-invoke `prepare_environment` and re-run with `deps_snapshot`
7. Parse sandbox exception type via `parse_sandbox_exception_type`
8. Stamp `ReproResult` with `verified_exception_match=True` iff types match
9. Store sealed result in `_REPRO_REGISTRY[session_id]`

If `verified_exception_match=False`, the critic refuses to ship in O6.

---

### 2.4 Stage O3: Path B Primitives

**File:** `src/oracles/sentry_replay_v2.py`

Extracted into a `_v2` sibling because IDE auto-format kept reverting `sentry_replay.py`. `_v2` is the source of truth for synthesis and parsing.

| Primitive | What it does | Why it matters |
|---|---|---|
| `parse_sandbox_exception_type(output)` | Regex `^E\s+(CamelCase):` against pytest stderr | Without this, a `NameError` from a bad import looks identical to a real crash — kills Rule 2 |
| `safe_repr_typed(value, type_hint)` | Type-aware repr: `float` → `0.0825`, `Decimal` → `Decimal("0.0825")` | Sentry serializes locals as strings; naïve paste breaks types |
| `resolve_source_fuzzy(filename, root)` | 4-strategy file resolve: abs → repo+rel → strip-prefix → rglob basename | Prod path `/app/src/billing/x.py` rarely matches local layout |
| `resolve_source_with_hints(filename, root, hints)` | Tries supervisor-supplied paths first, falls through to fuzzy | Powers the self-refusal loop |
| `function_param_names(source, name)` | AST scan → set of param names | Filter Sentry locals to params the function actually accepts |
| `is_async_function(source, name)` | Regex `^async def name` | Wrap call in `asyncio.run(...)` so coroutine isn't garbage-collected |

---

### 2.5 Stage O4: prepare_environment

**File:** `logomesh_orchestrator.py` → `_tool_prepare_environment()`

Bridges `web_search` + `dep_installer` + sandbox `deps_snapshot` mount for repos with unknown dependencies.

1. Read `pyproject.toml` + `requirements.txt` + `requirements/*.txt`
2. Extract missing module names from sandbox stderr: `_missing_modules_from_error(output)`
3. Map import name → PyPI dist name (`PIL → Pillow`, `cv2 → opencv-python`, …)
4. Dedup against manifest specs
5. PyPI version probe: `dep_installer.fetch_latest_pypi_version(pkg)`
6. Optional CVE advisory via `web_search(source='cve')`
7. `dep_installer.prepare_snapshot(...)` → wheel directory at `/tmp/.../`
8. Sandbox re-runs with `deps_snapshot=<path>` mounted r/o at `/deps`

**Compliance:** artifact gets a separate `environment_prep` block with `in_evidence_path: False`. The sealed `evidence_path_seal` is untouched.

Auto-retry: `_tool_deterministic_repro` invokes this once on `_has_import_failure(output)`. Capped via `auto_retry_done` flag. Supervisor can also call it proactively.

---

### 2.6 Stage O5: Self-Refusal Loop

**File:** `logomesh_orchestrator.py` → source-not-found block in `_tool_deterministic_repro()`

**Before:** `resolve_source_fuzzy` fails → immediate `human_review`. Agent did nothing.

**After:** structured retry.

| Attempt | Tool returns | Supervisor expected to do |
|---|---|---|
| 1st miss | `{retryable: True, reason: "source_not_found", basename, module_guess, next_action}` | `rag_search` + `web_search` → re-call with `path_hints=[…]` |
| 2nd miss | `{human_review: True, reason: "source_not_found_retry_exhausted", tried_hints}` | escalate |
| Hit | normal sealed `ReproResult` | proceed to critic |

Compliance preserved: `path_hints` is path strings only. LLM-recovered hints never flow into `test_code` or `sandbox_output`. Sealed bytes are byte-identical to the pre-fix happy path.

---

### 2.7 Stage O6: Critic + Verification Gate

**File:** `logomesh_orchestrator.py` → `_tool_critic_validate()`

```python
report = CriticReport(
    fidelity = score(...),                       # 0.0–1.0
    blockers = [...],
    verified  = repro.verified_exception_match,  # ← from Stage O2, not re-derived
)

if not report.verified:
    state["needs_human_review"] = True
    state["human_review_reason"] = (
        f"sandbox raised {repro.sandbox_exception_type!r} but "
        f"event captured {repro.expected_exception_type!r}"
    )
    return END  # never ships
```

The critic does **not** re-derive the exception type by asking an LLM. It only consumes the boolean already stamped on the sealed `ReproResult`.

---

### 2.8 Stage O7: Artifact (SOC2 / PCI)

**File:** `_tool_build_artifact()` → wraps `src/cli/artifact.py:render_artifact`

```json
{
  "control_mappings": ["SOC2 CC7.3", "SOC2 CC7.4", "PCI DSS 12.10.5"],
  "evidence_path_seal": {
    "llm_in_evidence_path": false,
    "synthesizer": "frame-locals → pytest (deterministic)",
    "sandbox_exception_type": "ValueError",
    "expected_exception_type": "ValueError",
    "verified_exception_match": true,
    "test_sha256_first16": "203ba3cdb6803e85"
  },
  "environment_prep": {
    "snapshot_path": "/tmp/logomesh_deps_xyz",
    "deps_added": ["redis==5.0.1"],
    "cve_advisories": [],
    "in_evidence_path": false
  },
  "session_audit": [],
  "git": {"branch": "...", "commit": "..."}
}
```

The auditor's question: *"Prove no LLM mutated the evidence."* The seal is the proof — hashes of the bytes + the `synthesizer` field naming the deterministic function.

---

### 2.9 Stage O8: Hypothesis Report (Last-Resort Fallback)

**File:** `src/oracles/hypothesis_report.py` + finalizer wiring in `logomesh_orchestrator.py`

Reproduction is the primary goal. The hypothesis report is the **last-resort** deliverable — it fires only when the agent has genuinely exhausted retry attempts (different bootstraps, different fixture strategies, prepare_environment, self-refusal loop) and `deterministic_repro` still can't ship a sealed test.

When the finalizer routes to `needs_human_review`, it builds a `HypothesisReport`:

```python
@dataclass
class HypothesisReport:
    crash_class: CrashClass         # 10 classes incl. "deadlock"
    confidence: float
    one_line_summary: str
    hypotheses: list[Hypothesis]    # ranked + difficulty
    violated_invariants: list[Invariant]
    evidence: list[EvidenceLine]    # breadcrumb / thread / frame_local
    suggested_repro_approach: str   # plain-English plan
    suggested_fix_pattern: str      # SELECT FOR UPDATE / etc
    related_files: list[str]
    out_of_scope_reason: str
    in_evidence_path: bool = False  # ALWAYS False — advisory only
```

The report is **never** stamped in `evidence_path_seal`. It's attached separately under `artifact["hypothesis_report"]` and `result["hypothesis_report"]` with `in_evidence_path: false`, so auditors can still tell sealed bytes apart from advisory analysis.

**Classification signals (no LLM):**
- error_type + error_message regex match (`StaleDataError`, `IntegrityError`, FK words, timeout words)
- frame_locals keywords (`task_id`, `version`, `expected_version` → optimistic-lock signal)
- breadcrumb content (`state_overwrite`, `race_window_open`)
- thread structure: 2+ threads holding locks AND ≥1 BLOCKED → `deadlock` class (highest confidence: 0.85)
- held_locks present anywhere → race-class confidence boost (+0.10, capped 0.95)
- breadcrumb timeline (<50ms cluster of N events → "concurrent execution" evidence line)

**Phase A** (schema + wiring) — `HypothesisReport` dataclass, finalizer always builds when routed to human_review, surfaced via API + artifact.

**Phase B** (better signals) — `classify_crash`, `extract_race_signals`, structured breadcrumb/thread consumers. Accepts both `SentryBreadcrumb` dataclasses and raw dicts (dual-shape — the accessors `_breadcrumb_*` and `_thread_attr` abstract over both).

**Phase C** (actionable suggestions) — `suggest_fix_pattern` + `suggest_repro_approach` lookup tables per crash class. Plain English, no LLM.

When the report says "deadlock" the dashboard renders specific recipes: *"Establish a global lock-acquisition order shared by every thread (e.g. sort lock keys lexicographically before acquiring) so cycles cannot form."* The pattern lookup table lives in `_FIX_PATTERNS` and `_REPRO_APPROACHES` — add new classes there.

---

### 2.10 Generic Repo-Analysis Primitives

Three modules sit alongside the orchestrator. Each is a pure analysis primitive — no IO side effects, no framework-specific switch statements. The agent (via the supervisor LLM) reads their output and decides what to do.

**`src/business_logic/repo_introspection.py`** — `scan_repo(path)` walks the repo and produces a `RepoIntrospection`:

```python
class RepoIntrospection:
    manifests: list[ManifestRead]        # pyproject.toml + requirements*.txt + setup.py
    evidence: list[EvidenceItem]         # imports, decorators, class bases, manifest deps
    classes: list[ClassDef]              # name, bases, fields, body source (truncated)
    callables: list[CallableDef]         # name, decorators, args, is_async
    config_files: list[str]              # *settings*.py, *config*.py
    entrypoint_modules: list[str]        # manage.py, app.py, asgi.py, wsgi.py
    imports_seen: dict[str, int]         # module → count
```

Exposed to the supervisor LLM via the `introspect_repo` tool (Stage O1 tool #11). The agent reasons over the evidence. **Tools never decide framework**; the supervisor does, with the evidence + the crash context.

**`src/business_logic/orm_materializer.py`** — `analyze_class_source(source, class_name)` walks AST, returns a `ClassShape` (required vs optional fields, base classes, decorators). `synthesize_constructor_call(shape, raw_locals)` returns `(call_source, notes, unresolved)`. If a required field has no captured value, it appears in `unresolved` — the materializer never silently placeholders. `placeholder_for_missing=True` opts into the legacy fill behavior.

**`src/business_logic/sandbox_planner.py`** — inert `SandboxSpec` types + agent-led primitives (`build_sandbox_spec`, `make_env_step`, `make_conftest_step`, `make_exec_step`). Pure utilities `dependencies_from_manifests` + `python_version_from_manifests`. `suggest_starter_spec()` is an OPTIONAL low-confidence starter that supplies only deps + Python version + hygiene defaults — **no framework routing**. The agent overrides via `build_sandbox_spec(...)`.

**Anti-hardcoding rule (do not break):** if you find yourself adding `if framework == "django"` anywhere under `src/business_logic/`, you're in the wrong layer. Move that decision into the agent's reasoning step (the supervisor's prompt + audit-driven retry), not into a tool.

---

### 2.11 What Was Cut and Why

**BattleMemory + UCB1 ReproStrategyEvolver** — cut 2026-05-06 after A/B test.

| Metric | learning_ON | learning_OFF |
|---|---|---|
| Verified shipped | 36/36 | 36/36 |
| Avg sec/run | 42.75 | 43.05 |
| Avg audit events | 7.2 | **5.9** |

Decision: **cut** (verified Δ=0, speed Δ=0.7% = noise). Both layers keyed per `crash_signature` exact-match. UCB1 needs hundreds of trials to converge; we had 16. Memory was empty on first-encounter by design. Restore when a customer Sentry org gives 200+ real crashes against the same signatures.

Full writeup: `docs/run_results/learning_layer_ab.md`. Archived code: `logomesh_legacy/agentbeats_evolvers/_extracted_classes.py.txt`.

`recall_memory` tool removed with this cut. Tool count: 11 → 10. Orchestrator LOC: 2466 → 2284 (−7.4%).

---

### 2.12 Golden Regression Suite (Hard Cases)

The demo repo `fintech-payments-demo/` is now the hard-case orchestrator
regression suite. It is not a toy fixture-only smoke test — it runs the full
webhook entrypoint (`handle_sentry_webhook`) after triggering realistic crash
paths in Dockerized Django/Celery services.

**Runner script:** `scripts/run_demo_orchestrator_suite.py`

```bash
uv run python scripts/run_demo_orchestrator_suite.py \
  --out results/demo_orchestrator_suite.json
```

What it does per case:
1. `docker compose up -d --wait` on `fintech-payments-demo/`
2. Triggers crash path via management command in `web` container
3. Invokes full orchestrator (`handle_sentry_webhook`) with issue id + repo path
4. Measures pilot metrics and compliance gate output
5. Writes machine-readable report JSON

Hard cases currently in-suite:
- `integrity_race` (duplicate `payments_payment_order_id_key`)
- `stale_race` (`StaleDataError` optimistic-lock race)
- `fk_violation` (post-charge FK integrity failure)

Metrics captured per run:
- `needs_human_review` and reason
- advisory tool call count (`web_search`, `rag_search`, `prepare_environment`, critic, dep-resolution)
- whether self-refusal source-resolution loop fired
- token usage / USD cost
- wall time and orchestrator duration
- evidence-path compliance checks (`sealed`, `llm_in_evidence_path=false`, `verified_exception_match=true`)

Latest baseline (`results/demo_orchestrator_suite.json`):
- total cases: 3
- verified repro cases: 3
- verified rate: 100%
- human review cases: 0
- compliance failures: 0

Pilot readiness guideline:
- target at least 70–80% verified repro on real customer crash sets
- if verified rate drops below that, `needs_human_review` burden stays too high
  and buyers still feel like they are doing manual triage

Important nuance:
- This suite is controlled and deterministic by design.
- It validates orchestrator behavior and compliance gating.
- It does **not** replace a live-event benchmark against real customer Sentry
  incidents (which should be run separately before broad pilot rollout).

---

## Part 3 — The Wizard & Installation Layer

### 3.1 Overview

The wizard is a 4-minute onboarding flow at `/onboarding` that provisions an installation and validates all three secrets (Sentry, GitHub, Slack). After setup, the installation is live and the Sentry webhook is routed per-install.

The backend for this lives in `src/server/installations_api.py`. It talks to Supabase for persistence and to external APIs for live validation.

---

### 3.2 Installation Lifecycle

```
POST /api/installations
  → creates row in installations + installation_secrets
  → returns {id, client_secret, webhook_url}

PATCH /api/installations/{id}/sentry
  → validates token live against sentry.io/api/0/auth/
  → stores encrypted in installation_secrets

PATCH /api/installations/{id}/github
  → validates token: GET /user + GET /repos/{repo} + push permission check
  → stores encrypted in installation_secrets

PATCH /api/installations/{id}/slack
  → sends real test message to webhook URL
  → stores encrypted in installation_secrets

POST /api/installations/{id}/test
  → creates pending run row
  → runs handle_sentry_webhook() async with a fixture event
  → responds immediately (run result polled via GET /api/installations/{id}/runs)
```

**Auth:** every `PATCH` and `POST` (except the anonymous create) requires `Authorization: Bearer <client_secret>`. The `client_secret` is shown once at creation — not recoverable after that.

---

### 3.3 Secrets & Encryption

**File:** `src/core/installation_secrets.py`

Every secret value is AES-256-GCM encrypted at the application layer before touching the DB. The DB sees only opaque blobs prefixed `lmsec-v1:`.

```python
from core.installation_secrets import encrypt_value, decrypt_value

blob = encrypt_value("sk-my-token")     # "lmsec-v1:<urlsafe-b64(nonce||ct||tag)>"
plain = decrypt_value(blob)             # "sk-my-token"
```

`LOGOMESH_MASTER_KEY` must be set. Accepts either a URL-safe base64 string or a 64-char hex string (32 raw bytes either way).

`resolve_secrets(installation_id)` is the single call-site the orchestrator uses:
1. Tries Supabase first — decrypts all columns
2. Falls back to env vars (`LOGOMESH_SENTRY_AUTH_TOKEN`, `GITHUB_TOKEN`, etc.)

> **Warning:** Losing `LOGOMESH_MASTER_KEY` means losing all stored secrets permanently. Back it up before rotating.

---

### 3.4 Supabase Schema

Three tables in `public` schema:

| Table | Purpose |
|---|---|
| `installations` | One row per customer install. UUID PK, no RLS (service-role only) |
| `installation_secrets` | Encrypted secret columns. RLS: service_role only |
| `runs` | Per-orchestrator-dispatch audit log. RLS: service_role only |

Apply migrations fresh:

```bash
psql $SUPABASE_DB_URL -f migrations/0001_installation_secrets.sql
psql $SUPABASE_DB_URL -f migrations/0002_runs.sql
```

Or via Supabase CLI:

```bash
supabase db push
```

The `runs` table is what the wizard reads via `GET /api/installations/{id}/runs` to show "your last 20 runs."

---

### 3.5 Token Budget & Cost Tracking

**File:** `src/core/usage_tracker.py`

Token usage is tracked per-orchestrator-run via a ContextVar holding a mutable dict (so child asyncio tasks share the same reference).

```python
from core.usage_tracker import reset_usage, add_usage, get_usage, estimate_cost_usd, usage_summary

reset_usage()
add_usage(tokens_in=1000, tokens_out=400, model="gpt-5-mini")
summary = usage_summary()
# → {tokens_in: 1000, tokens_out: 400, model: "gpt-5-mini", cost_usd: 0.0...}
```

**Budget enforcement** (`check_budget()`) reads env vars each call:

| Env var | Default | Meaning |
|---|---|---|
| `LOGOMESH_TOKEN_BUDGET_IN` | `200000` | Max input tokens per run |
| `LOGOMESH_TOKEN_BUDGET_OUT` | `40000` | Max output tokens per run |
| `LOGOMESH_USD_BUDGET` | `1.00` | Max estimated cost per run (USD) |

On budget exceeded → `TokenBudgetExceeded` raised. The orchestrator catches it and routes to `human_review` with reason `"token_budget_exceeded"`, preserving any partial artifact.

**Model cost table** (per million tokens):

| Model | Input | Output |
|---|---|---|
| `gpt-5-mini` | $0.25 | $2.00 |
| `claude-sonnet` baseline | $3.00 | $15.00 |
| Local models (qwen-coder, etc.) | $0.00 | $0.00 |

---

## Part 4 — Module Map

```
src/
├── core/                         ← shared infrastructure
│   ├── pipeline.py               ← verify_file() — the check flow
│   ├── repro_gate.py             ← confirms crash is consistent + not in base
│   ├── config.py                 ← .logomesh.toml reader
│   ├── llm_utils.py              ← temperature, model selection helpers
│   ├── logomesh_log.py           ← structured JSON logger
│   ├── anthropic_adapter.py      ← Anthropic API → OpenAI-shaped interface
│   ├── responses_adapter.py      ← OpenAI Responses API → chat.completions interface
│   ├── usage_tracker.py          ← per-run token counter (ContextVar mutable dict)
│   ├── installation_secrets.py   ← AES-256-GCM encrypt/decrypt + resolve_secrets()
│   ├── supabase_client.py        ← Supabase client + in-memory shim for dev/test
│   └── runs_log.py               ← create_pending_run / record_run_finished / list_runs
│
├── cli/                          ← CLI commands (argparse entrypoints)
│   ├── main.py                   ← `logomesh` dispatcher
│   ├── repro.py                  ← `logomesh repro <url>`
│   ├── check.py                  ← `logomesh check`
│   ├── artifact.py               ← PCI/SOC2 audit artifact builder
│   ├── draft_pr.py               ← open GitHub draft PR
│   ├── codebase_context.py       ← AST + BM25 context extraction
│   └── state_fixtures.py         ← logomesh-capture state file loader
│
├── server/                       ← HTTP layer (FastAPI)
│   ├── installations_api.py      ← /api/installations CRUD + secret validation
│   └── sentry_webhook.py         ← /webhooks/sentry/{installation_id}
│
├── oracles/                      ← crash inputs from external sources
│   ├── sentry_replay.py          ← fetch Sentry events + synthesize tests (v1)
│   ├── sentry_replay_v2.py       ← Path B primitives (source of truth for synthesis)
│   └── hypothesis_report.py      ← structured investigation report (Stage O8)
│
├── business_logic/               ← the engine
│   ├── generator/
│   │   ├── api.py                ← PropertyTestGenerator (public API)
│   │   ├── inference.py          ← LLM: "what properties does this function have?"
│   │   ├── codegen.py            ← write the actual pytest code
│   │   ├── ast_analysis.py       ← parse Python AST → FunctionInfo
│   │   └── models.py             ← Property, FunctionInfo, RoundContext dataclasses
│   ├── sandbox/
│   │   └── __init__.py           ← Sandbox class + _TRACE_HOOK injection + image_for_python_version
│   ├── classifier/
│   │   └── core.py               ← Finding dataclass + classify()
│   ├── validator/
│   │   └── __init__.py           ← validate_findings_with_meta()
│   ├── change_scope/             ← AST diff: what changed between base and head?
│   ├── diff_review/              ← static pattern detection (auth guards, secrets, etc.)
│   ├── repo_introspection.py     ← generic AST + manifest scanner (no framework names)
│   ├── orm_materializer.py       ← generic ClassShape analyzer + constructor synthesis
│   └── sandbox_planner.py        ← agent-led SandboxSpec primitives + starter suggestion
│
└── capture/                      ← logomesh-capture agent (runs in prod apps)
    ├── sentry_hook.py            ← Sentry beforeSend hook
    ├── ring_buffer.py            ← in-memory circular buffer of recent state
    ├── writer.py                 ← writes state snapshots to disk
    └── hooks/                    ← per-framework hooks (FastAPI, SQLAlchemy, Redis, etc.)
```

Top-level files:

```
logomesh_orchestrator.py      ← LangGraph supervisor + all tools (~2284 LOC)
usage_tracker.py              ← module-level re-export (src/core/usage_tracker.py)
migrations/
  0001_installation_secrets.sql
  0002_runs.sql
scripts/
  honest_hit_rates.py         ← reproducible per-category hit-rate measurement
  generate_v3_fixtures.py
  generate_v5_fixtures.py
  run_v3_demo.py
  run_v5_dual_model.py
  ab_test_learning_layer.py
docs/
  honest_hit_rates.md         ← source of truth for all published hit-rate numbers
  pilot_deployment.md         ← 30-min pilot runbook
  run_results/                ← timestamped JSON + MD from each measurement run
logomesh_legacy/              ← archived code (never delete — move here instead)
```

---

## Part 5 — Debug Exercises

These are real things you'll need to do when the pipeline breaks. Run them yourself.

---

### Exercise 1: Add a log statement and watch it fire

The logger is at `src/core/logomesh_log.py`. Every module imports it the same way:

```python
from logomesh_log import log
log.info("my_component", "something happened", key="value")
```

**Try it:** open `src/oracles/sentry_replay.py`, find where it calls `fetch_event_by_issue`, add:

```python
log.info("repro", "fetching sentry event", issue_id=issue_id, org=org)
```

Run with `LOGOMESH_LOG_PRETTY=1`. You'll see your line print with a timestamp and component label.

This is how you debug: add `log.info()` → run → see what was actually passed.

---

### Exercise 2: Run the sandbox directly

Test the sandbox without touching Sentry.

```python
# uv run python -c "..."
from business_logic.sandbox import Sandbox

s = Sandbox()

target_code = """
def apply_discount(price, pct):
    return price * (1 - pct / 100)
"""

test_code = """
from target import apply_discount

def test_negative_discount():
    result = apply_discount(100, -50)
    assert result <= 100  # fails: apply_discount(100, -50) = 150
"""

result = s.run({"target.py": target_code, "test_target.py": test_code})
print("failed:", result["failed"])
print(result["output"][:500])
```

**Expected:** `failed: 1`. Change the assert to `assert result >= 0` — now `150 >= 0` passes. That's a bug logomesh would catch.

---

### Exercise 3: Read a Sentry frame without the API

```python
from oracles.sentry_replay import SentryException, StackFrame, find_innermost_app_frame

exc = SentryException(
    error_type="ZeroDivisionError",
    error_message="division by zero",
    issue_id="fake123",
    stacktrace=[
        StackFrame(
            filename="src/billing/checkout.py",
            function="calculate_total",
            lineno=55,
            context_line="    return subtotal / item_count",
            variables={"subtotal": "99.99", "item_count": "0"},
            in_app=True,
        )
    ]
)

frame = find_innermost_app_frame(exc)
print(frame.function)   # → calculate_total
print(frame.variables)  # → {"subtotal": "99.99", "item_count": "0"}
```

Now you can test `synthesize_test_llm()` against this fake frame without hitting any API.

---

### Exercise 4: Trace what the LLM generates

In `src/cli/repro.py`, inside `_run_async()`, find where `test_code` is assigned. Add:

```python
print("=== GENERATED TEST ===")
print(test_code)
print("======================")
```

Run `logomesh repro <url>`. You'll see exactly what the LLM wrote before it enters the sandbox. If the test looks wrong, the generation prompt needs tuning — not the sandbox.

---

### Exercise 5: Understand a Finding

```python
from business_logic.classifier import Finding

f = Finding(
    test_name="test_apply_discount_zero_div",
    kind="unhandled_crash",        # exception escaped the function
    error_type="ZeroDivisionError",
    error_message="division by zero",
    input_code="apply_discount(price=100, qty=0)",
    property_desc="",              # populated for assertion failures
    lineno=42,
)

print(f.kind)          # "unhandled_crash" vs "property_violation" vs "noise"
print(f.input_code)    # what was called
print(f.fp_reason)     # why the validator might have dropped it
```

**How findings get dropped (in order):**

1. `kind="noise"` → dropped immediately, never validated (e.g. import error in test setup)
2. Validator says `"false_positive"` → LLM decided crash is intentional behavior
3. Repro gate can't reproduce a second time → `repro_gate_dropped += 1`
4. Base also crashes → regression gate drops it (not a new bug)

---

## Part 6 — Common Failure Modes

| Symptom | Where to look | Fix |
|---|---|---|
| `"SENTRY_AUTH_TOKEN is not set"` | `src/cli/repro.py:107` | `export SENTRY_AUTH_TOKEN=...` |
| `"no usable in-app frame"` | `sentry_replay.py:find_innermost_app_frame` | All frames are library code — try a different issue |
| Test generates but always passes | `src/cli/repro.py:_retry_with_analysis` | Print `test_code` before sandbox run; inspect what was generated |
| `sandbox run failed: collection error` | `src/business_logic/sandbox/__init__.py` | Syntax error in generated test — print `test_code` first |
| Docker not found → subprocess fallback | `src/business_logic/sandbox/__init__.py` | Install Docker or set `LOGOMESH_SANDBOX_MODE=subprocess` |
| `"source code did not parse cleanly"` | `src/core/pipeline.py:143` | `head_source` has a syntax error |
| All findings dropped by validator | `src/business_logic/validator/__init__.py` | Check `LOGOMESH_REASONING_VALIDATION` env; try different model |
| `GraphRecursionError` | `logomesh_orchestrator.py` | First verify max-step rail: `step_count` / `orchestrator_max_steps_exceeded`. Recursion limit is fallback (`LOGOMESH_RECURSION_LIMIT`, default 40) |
| `TokenBudgetExceeded` | `src/core/usage_tracker.py` | Increase `LOGOMESH_USD_BUDGET` or `LOGOMESH_TOKEN_BUDGET_IN` |
| Wizard: 401 on PATCH secret | `src/server/installations_api.py` | `client_secret` not in Authorization header or wrong value |
| Supabase writes silently no-op | `src/core/supabase_client.py` | URL (`SUPABASE_URL` or `SUPABASE_PROJECT_REF`) or service key (`SUPABASE_SERVICE_KEY` / `SUPABASE_SERVICE_ROLE_KEY`) not set → in-memory shim active |
| Sandbox runs on wrong Python version | `src/business_logic/sandbox/__init__.py:image_for_python_version` | Allowlist is `{3.10, 3.11, 3.12, 3.13}`. `exc.runtime.version` outside the set silently falls back to default. Add to `_ALLOWED_PYTHON_VERSIONS` if you mean to support more |
| `prepare_environment` not pinning prod versions | `logomesh_orchestrator.py:_tool_prepare_environment` | Caller didn't pass `module_versions=exc.modules`. Check finalizer wiring + that the Sentry payload populated `modules` |
| `build_request_replay_test_v2` returns `None` | `src/oracles/sentry_replay_v2.py` | `exc.request` is `None`, OR `method` / `url` missing on the captured request. Sentry-side SDK config (`include_request_data=True` on the integration) controls this |
| Hypothesis report missing on human_review | `logomesh_orchestrator.py:finalizer_node` | Build wrapped in try/except — check `log.warning` for "hypothesis report build failed". Most common cause: `_EVENT_REGISTRY[sid]` empty (session cleared early) |
| `introspect_repo` returns `error` | `logomesh_orchestrator.py:_tool_introspect_repo` | `repo_path` doesn't exist OR perm denied. Tool returns `{"error": ..., "type": ...}` instead of raising. Check the JSON |

---

## Part 7 — Manuals

### Manual A: How to Read Your Own Code

You have ~2300 lines of orchestrator + 515 unit tests + sibling `_v2` modules. That's the size where most juniors lose the plot.

**A.1 — Read by data shape, not by call graph.**

A call graph is hard to hold in your head. A data shape ("what does the dict look like at this point?") is easy. The four shapes that matter:

- `SentryException` — what we receive from upstream
- `StackFrame` — what we pull out of the exception
- `ReproResult` — what the deterministic core produces
- the `artifact` dict — what we ship

Name those four and you can read any function in this codebase in under a minute.

**A.2 — Trace one happy-path end-to-end with `print` debugging.**

```bash
LOGOMESH_SENTRY_FIXTURE=tests/fixtures/sentry_v3_01_celery_refund_stale_db.json \
  uv run python -m scripts.run_v3_demo
```

Add at the top of every function in the data-flow diagram:

```python
print(f"[{__name__}.<func>] in =", repr(<arg>))
print(f"[{__name__}.<func>] out =", repr(<ret>))
```

Re-run. Read the prints in order. The whole pipeline becomes one linear story. Delete prints after.

**A.3 — Read the test for a function before its body.**

```bash
rg -l "def test_.*<func_name>" tests/
```

Tests describe what a function is *supposed* to do. The body describes *how* — much harder.

**A.4 — Use the module map as a launcher, not documentation.**

For the repro path the four directories that matter: `cli/`, `oracles/`, `business_logic/sandbox/`, `core/`. Hide the rest in your editor.

**A.5 — When something feels too complex, ask "could this be 3 functions instead of one?"**

`_tool_deterministic_repro` does: (1) cache lookup, (2) frame pick, (3) source resolve, (4) synth, (5) sandbox, (6) verification, (7) prep auto-retry. Seven steps. Splitting along these seams is a net-zero LOC change but a 10× readability change.

---

### Manual B: Become a Better Engineer

**B.1 — Read tracebacks bottom-up.**
The most specific information is at the bottom. The verification gate exists because we used to skip this and trust `failed > 0`.

**B.2 — Never ship code you can't explain in one paragraph.**
If you can't explain *why* in 4–5 sentences to Josh, the change is doing too many things.

**B.3 — Distrust your past self.**
Every TODO/FIXME from 3 weeks ago is now load-bearing production code. The verification gate was a TODO for two days. Two days of demos shipped fake "reproduced" results.

**B.4 — Test the boundary, not the inside.**
Integration tests on `fixture → artifact → seal` catch more than 10 unit tests on internals. Parametrize across `tests/fixtures/sentry_v3_*.json`, assert on `evidence_path_seal`. The single A/B test caught more behavior than the 6 unit tests around it.

**B.5 — Always measure before adding ML scaffolding.**
The BattleMemory + UCB1 cut is the canonical example. Added on day 1. Took 6 months and one A/B test to admit they did nothing. Always run the A/B before committing to "learning."

**B.6 — When stuck, write the smallest reproducer.**
If a bug only repros inside the orchestrator with three tools loaded, you don't have a bug — you have a mystery. Strip until 5 lines reproduce it. This is literally what the product does for users. Use it on yourself.

**B.7 — Keep a "what surprised me today" doc.**

One line per surprise. Read it weekly.

> - 2026-04-29: assumed `Decimal("0.0825") == 0.0825`. False.
> - 2026-05-02: assumed pytest exit 1 means "test failed." Also means "no tests collected."
> - 2026-05-04: `_extract_scalar_hint` recursed forever on `dict`. Bound your loops.
> - 2026-05-06: BattleMemory + UCB1 helped on zero of 18 unseen crashes.
> - 2026-05-08: ContextVar writes in asyncio child tasks don't propagate to parent. Fixed by making it a mutable dict instead of a scalar.

**B.8 — Read library source you depend on.**
You will be a better logomesh engineer if you've read 200 lines of LangGraph than another 2000 of logomesh.

**B.9 — Working code today beats elegant code tomorrow.**
`sentry_replay_v2.py` exists because v1 kept getting auto-reverted by the IDE. Better engineer move: split, name `_v2`, ship, move on.

**B.10 — The compliance contract is your moat. Protect it like a DB invariant.**
Every PR touching evidence-path code must answer: *"Does this introduce LLM tokens into `evidence_path_seal`-stamped bytes?"* If yes, doesn't merge. Add `tests/test_artifact_seal.py` that greps the artifact JSON for known LLM-output markers — this test does not exist yet. Add it before the pilot.

---

### Manual C: Online Resources

Skip generic "learn Python." You're past that.

**C.1 — LangGraph + agent orchestration**
- LangGraph docs: `https://langchain-ai.github.io/langgraph/` — read "StateGraph", "ToolNode", "MemorySaver", "Conditional Edges". Skip the rest.
- LangGraph examples: `https://github.com/langchain-ai/langgraph/tree/main/examples` — `customer-support` and `agent-supervisor` are closest to our shape.
- "Building Effective Agents" (Anthropic, Dec 2024): `https://www.anthropic.com/research/building-effective-agents` — the document we self-graded against. Read it twice.

**C.2 — Sentry SDK + event format**
- Event Payload spec: `https://develop.sentry.dev/sdk/data-model/event-payloads/` — source of truth for the JSON shape we parse.
- Python SDK source: `https://github.com/getsentry/sentry-python` — `sentry_sdk/utils.py:event_from_exception` shows how frame locals get serialized as strings (why `safe_repr_typed` exists).

**C.3 — Docker security / sandboxing**
- Docker Security cheat sheet: `https://cheatsheetseries.owasp.org/cheatsheets/Docker_Security_Cheat_Sheet.html` — covers `--network none`, `--user nobody`, `--pids-limit`, `--memory`.
- "Container Security" by Liz Rice — concise, technical, exactly the depth a 19-year-old founder needs.

**C.4 — Python AST + code parsing**
- Green Tree Snakes: `https://greentreesnakes.readthedocs.io/` — best Python AST guide. Free.
- `ast` stdlib: `https://docs.python.org/3/library/ast.html` — reference, not reading material.

**C.5 — Pydantic + tool schemas**
- Pydantic v2 migration: `https://docs.pydantic.dev/latest/migration/` — half the bugs you hit are v1↔v2 confusion.
- OpenAI tool-calling spec: `https://platform.openai.com/docs/guides/function-calling` — what `StructuredTool` schemas have to satisfy.

**C.6 — Property-based reasoning + fintech bug taxonomy**
- "Property-Based Testing with PropEr, Erlang, Elixir" by Fred Hebert — first 4 chapters explain *properties* vs *examples*. 2 hours.
- Hypothesis (Python): `https://hypothesis.readthedocs.io/` — we don't use it directly, but the mental model maps 1:1 onto `inference.py`.
- Stripe engineering blog: `https://stripe.com/blog/engineering` — search "idempotency", "ledger", "race conditions". Real fintech postmortems.
- PCI DSS v4.0: read **§12.10.5** (incident response), **§3.4** (PAN protection), **§3.5** (key/secret protection). Skip §6.3.2 — it's pre-release code review.
- AICPA TSC 2017 (SOC2): read **CC7.3** (event evaluation), **CC7.4** (incident response), **CC6.7** (data transmission). The CC7.x family is what an audit-prep VPE will ask about.

**C.7 — Distributed-systems intuition (the bugs we ship for)**
- "Designing Data-Intensive Applications" by Martin Kleppmann — chapters 7, 8, 9 explain *why* the v3/v5 fixtures crash. If you read one book this year, this one.
- Aphyr's Jepsen series: `https://aphyr.com/tags/jepsen` — what real concurrency bugs look like in production.
- "The Tail at Scale" (Dean & Barroso, 2013): `https://research.google/pubs/the-tail-at-scale/` — 4 pages. Why p99 matters for fintech.

**C.8 — Junior → mid-level engineering**
- "The Pragmatic Programmer" (20th anniv ed.) — every chapter is one habit.
- "A Philosophy of Software Design" by John Ousterhout — short, opinionated, will reframe how you think about modules.
- Julia Evans' zines: `https://wizardzines.com/` — visual, friendly, technically correct.

**C.9 — Avoid**
- LinkedIn AI-influencer threads. Attention farming.
- Generic "Top 10 Python tricks" videos.
- Twitter takes on whether agents work. Half are sales, the other half vendetta posts. Build, measure, ship.

---

## Appendix — Sprint Changelog

### 2026-05-08

| What | Why | Where |
|---|---|---|
| Supabase schema applied to live project | Persistent installation + run storage | `migrations/0001`, `migrations/0002` via Supabase MCP |
| `installations_api.py` rewritten | Match wizard frontend spec; live secret validation | `src/server/installations_api.py` |
| `installation_secrets.py` added | AES-256-GCM column encryption + per-install secret resolution | `src/core/installation_secrets.py` |
| `runs_log.py` added | Per-run audit trail readable by wizard | `src/core/runs_log.py` |
| `usage_tracker.py` rewritten | ContextVar mutable dict (asyncio child-task write propagation fix) | `src/core/usage_tracker.py` |
| `supabase_client.py` added | Chainable shim auto-fallback for dev/test | `src/core/supabase_client.py` |
| `honest_hit_rates.py` added | Reproducible per-category hit-rate measurement | `scripts/honest_hit_rates.py` |
| `docs/honest_hit_rates.md` added | Source of truth for all published numbers | `docs/honest_hit_rates.md` |
| `docs/pilot_deployment.md` added | 30-min pilot runbook | `docs/pilot_deployment.md` |

### 2026-05-06

| What | Why | Where |
|---|---|---|
| Added `prepare_environment` tool (#10) | Generalize sandbox to unknown repos via auto wheel-snapshot build | `logomesh_orchestrator.py` Stage O4 |
| Added self-refusal loop | Agent recovers from `source_not_found` instead of immediate human_review | Stage O5 |
| Cut BattleMemory + UCB1 | A/B test showed zero uplift at 18 fixtures | `logomesh_legacy/agentbeats_evolvers/` |
| Removed `recall_memory` tool | Cleanup after memory layer cut | Tool count 11 → 10 |
| Suite | 509 → 515 passing | `tests/` |

---

You're 19. You won UC Berkeley AgentBears. You're shipping a real product to real fintech buyers.

Most of "becoming a better engineer" is **showing up to the same codebase for 2 years and refusing to skip the boring parts.** Read your tracebacks. Run your tests. Trace your data. Throw away code that no longer fits. Repeat.

The compliance contract is your moat. The deterministic core is your product. The agent shell is what makes it generalize. Everything else is replaceable.

Build.
