# Honest Hit-Rate Reporting

_Last updated: 2026-05-08_

logomesh's customer-facing claim is that we **deterministically reproduce
production crashes from Sentry events as sealed pytest evidence**. That
claim is a function of the deterministic synthesizer's hit rate against
real-world bug categories. This document is the source of truth for what
we know and what we don't.

## What we measure

The orchestrator's success path is narrowly defined. A run is a "verified
ship" iff:

1. `evidence_path_seal.llm_in_evidence_path == False`
2. `evidence_path_seal.verified_exception_match == True`
3. `repro.reproduced == True` (sandbox raised the captured exception)
4. The artifact serializes cleanly with no PII in the visible bytes

Anything else routes to `human_review` with a structured reason. We do
not count `human_review` outcomes as misses — we count them as honest
refusals. We DO count exceptions thrown out of the orchestrator (e.g.
LangGraph recursion limit) as errors.

## Measured numbers — synthetic fixtures only

The latest run is the source of truth for every number we publish.
Methodology and raw results live in:

- `scripts/honest_hit_rates.py` — the runnable measurement script.
  Buyers can re-run it against the same fixtures and audit the math.
- `docs/run_results/honest_hit_rates_<date>.json` — raw per-fixture
  output, including refusal reasons + sandbox exception types.
- `docs/run_results/honest_hit_rates_<date>.md` — human-readable
  summary of the same run.

### 2026-05-08 — gpt-5-mini, 23 fixtures (v3 + v4 + v5)

**Overall: 18/23 verified (78.3%).** Average wall-clock 55s/fixture.
Total LLM cost across the entire run: \$0.31.

| Category | Total | Verified | Hit-rate |
|---|---:|---:|---:|
| `input_validation` | 4 | 4 | **100%** |
| `domain_exception` | 5 | 5 | **100%** |
| `external_api` | 3 | 3 | **100%** |
| `c_extension` | 1 | 1 | **100%** |
| `async_concurrency` | 6 | 3 | **50%** |
| `db_consistency` | 4 | 2 | **50%** |

The 5 misses break down as:

- 4× `source file did not resolve on disk after retry` (v4 fixtures
  whose stored frame.filename uses an absolute path the fuzzy
  resolver couldn't reconstruct under the smoke-data layout)
- 1× `GraphRecursionError` (v4_01_stripe_webhook_dup) — supervisor
  hit the 40-step LangGraph recursion limit. Configurable via
  `LOGOMESH_RECURSION_LIMIT`.

Critically: **none** of the verified rows had `llm_in_evidence_path = True`.
The synthesizer is deterministic in every shipped artifact.

## What these numbers ARE NOT

These are **synthetic fixtures** designed to crash deterministically
from primitive frame locals. They establish the synthesizer's ceiling
on its sweet-spot input distribution; **they do not measure real-world
hit rate against arbitrary customer Sentry orgs.**

- The `input_validation` 100% is on hand-crafted ValueError /
  TypeError / AttributeError patterns. A customer's input validation
  bug might look like one of those, or it might involve a deserializer
  layer we never hit.
- The `domain_exception` 100% measures custom-subclass-throwing
  business logic. A real org's domain exceptions might be tightly
  coupled to DB row state we don't have in the fixture.
- The `async_concurrency` 50% on synthetic fixtures probably
  over-states real-world performance — race conditions in production
  often depend on multi-process state we can't capture from a single
  Sentry frame.

Per-category numbers should be read as "how does the synthesizer
perform on representative examples of this bug class" — not "what
your team's first month will look like."

## What we don't know yet

We have **zero measured hit rate against real customer Sentry orgs.**

We have not run the orchestrator against:

- a fintech's actual production Sentry feed
- crashes that involve real Stripe / Plaid / payment-rail failures
  (fixtures simulate these; real ones differ)
- crashes that depend on DB row state or Redis content that a frame
  doesn't capture
- async / Celery / asyncio task-graph crashes in production
- race conditions in multi-worker deployments
- timezone / DST bugs on a non-UTC sandbox
- distributed transactions or sharded-DB crashes
- C-extension segfaults (the synthetic v3_05 case raises OSError, not
  a true segfault)
- bugs that depend on environment variables we don't have

Engineering judgment estimate (not measured): we expect the real-world
verified-ship rate to land in the **30–60% range** on the bug
distribution that fires most often in a Python fintech production
environment — input validation, type coercion, decimal precision,
off-by-one, None-where-an-object-was-expected, missing-key,
missing-fixture. The remaining 40–70% will route to `human_review`
with structured reasons (see Refusal taxonomy below).

We will publish measured numbers per category as soon as we have a
design partner running on their real org for ≥2 weeks.

## What we publish

- **Synthetic suites:** the per-category numbers above, with the
  explicit "synthetic" caveat. We never quote them as "production hit
  rate."
- **Real-world numbers:** none yet. We refuse to invent a number.
- **Honest refusal reason:** every `human_review` ships a structured
  `reason` (not a vague "couldn't repro"). Customers can audit the
  refusal taxonomy and see where we currently fail.

## Refusal taxonomy (current)

When the orchestrator returns `needs_human_review=True`, the
`human_review_reason` is one of:

| Reason | Meaning |
|---|---|
| `source_not_found_retry_exhausted` | Resolver + supervisor retry both failed to find the target file in the customer repo |
| `frame_locals_insufficient` | Captured locals don't include the values needed to reconstruct the call |
| `c_ext` | Crash is inside a C extension (segfault, ABI mismatch); sandbox can't faithfully replay it |
| `verification_mismatch` | Sandbox raised a different exception type than Sentry captured |
| `dep_install_failed` | `prepare_environment` couldn't build a wheel snapshot for the missing modules |
| `pipeline_timeout` | Orchestrator hit the 120s budget |
| `no_usable_in_app_frame` | Every frame in the stacktrace is library code |
| `token_budget_exceeded` | Per-run LLM cost cap (default \$1) exceeded |
| `supervisor exited without invoking deterministic_repro` | LLM produced text-only response instead of a tool call |

Each refusal is logged in the audit trail with the relevant context.
Customers see the reason; we don't pretend it didn't happen.

## How to reproduce

```bash
# Apply the schema if you haven't already.
psql $SUPABASE_DB_URL -f migrations/0001_installation_secrets.sql
psql $SUPABASE_DB_URL -f migrations/0002_runs.sql

# Run the measurement (~12 min on gpt-5-mini, all 23 fixtures).
export OPENAI_API_KEY=sk-...
uv run python scripts/honest_hit_rates.py
```

The script:

1. Loads the v3, v4, v5 fixture indexes from `/tmp/logomesh_smoke_data`
   (override with `LOGOMESH_SMOKE_DATA_DIR=...`).
2. Categorizes each fixture per the hand-curated `CATEGORY` table at
   the top of the script. The categorization is the auditable input;
   anyone can challenge it.
3. Runs each fixture through `handle_sentry_webhook()` end-to-end —
   real LangGraph supervisor, real sandbox execution, real artifact
   sealing.
4. Disables draft-PR creation so the run can't side-effect this repo's
   active branch.
5. Aggregates verified-ship counts per category, dumps refusal
   taxonomy, and writes a timestamped MD + JSON to
   `docs/run_results/`.

A buyer auditing our claims can re-run this and compare against the
JSON we published.

## What we promise design partners

- "We will measure on your data and publish the per-category numbers
  back to you weekly during the pilot."
- "The numbers above are synthetic. Do not generalize from them."
- "If real-org hit rate is below 30% on your specific category mix,
  we'll refund the pilot fee."

That last bullet exists because it forces us to ship honest measurement
infrastructure before we ship a production claim.

## When this document is wrong

This file is the authoritative source for hit-rate language across the
README, sales calls, marketing site, and pilot agreements. If a number
appears anywhere else (slide, deck, blog post, tweet), it must trace
back to this file or be updated to match. When real-world data lands,
**update this file first**, then propagate.

Drift in this document = drift in customer trust.
