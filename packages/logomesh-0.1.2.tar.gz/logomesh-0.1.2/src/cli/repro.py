"""`logomesh repro <sentry-url>` — fetch a Sentry issue and reproduce it
locally as a pytest run against the current working tree.

Demo command for the customer discovery sprint. End-to-end:

    $ SENTRY_AUTH_TOKEN=... logomesh repro https://sentry.io/issues/1234567/

Returns:
    exit 0 — reproduced (test failed in sandbox = bug exists on this branch)
    exit 1 — not reproduced (test passed = bug fixed or wrong target)
    exit 2 — error (bad URL, missing token, network, sandbox unavailable)
"""

from __future__ import annotations

import argparse
import asyncio
import json as _json
import os
import re
import sys
from pathlib import Path


_SENTRY_HOSTS = ("sentry.io",)


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    p = subparsers.add_parser(
        "repro",
        help="Reproduce a Sentry issue as a local pytest",
        description=(
            "Fetch the latest event for a Sentry issue, synthesize a pytest "
            "replay, and run it in the sandbox against the current working "
            "tree. Requires SENTRY_AUTH_TOKEN with `event:read` scope."
        ),
    )
    p.add_argument("sentry_url", help="Sentry issue URL")
    p.add_argument(
        "--repo", default=".", type=Path,
        help="Path to local repo (default: cwd)",
    )
    p.add_argument(
        "--json", dest="output_json", action="store_true",
        help="Emit machine-readable JSON instead of human text",
    )
    p.add_argument(
        "--artifact", dest="emit_artifact", action="store_true",
        help="Emit a PCI DSS / SOC2 audit artifact JSON envelope",
    )
    p.add_argument(
        "--state-file", default=None,
        help="Path to a logomesh-capture state file to seed the replay "
             "(default: read from event.extras.logomesh_state_file)",
    )
    p.add_argument(
        "--no-llm", dest="use_llm", action="store_false", default=True,
        help="Skip LLM synthesis; use deterministic frame-locals replay only",
    )
    p.add_argument(
        "--timeout", type=int, default=60,
        help="Total wall-clock timeout in seconds (default: 60)",
    )
    p.add_argument(
        "--draft-pr", dest="draft_pr", action="store_true",
        help="Create a draft GitHub PR with the repro test attached",
    )
    p.add_argument(
        "--pr-url", dest="pr_url", default="",
        help="Existing PR URL to embed in the audit artifact",
    )
    p.add_argument(
        "--fix-diff", dest="fix_diff", default="", metavar="PATH",
        help="Path to a unified diff file to include in the audit artifact",
    )
    p.set_defaults(func=run_repro)


def parse_sentry_url(url: str) -> tuple[str | None, str]:
    """Extract `(org, issue_id)` from a Sentry issue URL.

    Supported forms:
        https://sentry.io/organizations/{org}/issues/{issue_id}/
        https://sentry.io/issues/{issue_id}/
        https://{org}.sentry.io/issues/{issue_id}/
        https://{org}.sentry.io/organizations/{org}/issues/{issue_id}/

    Raises ValueError on anything else.
    """
    m = re.match(
        r"^https?://([^/]+)/(?:organizations/([^/]+)/)?issues/(\d+)/?",
        url.strip(),
        re.IGNORECASE,
    )
    if not m:
        raise ValueError(f"unrecognized Sentry issue URL: {url!r}")

    host, path_org, issue_id = m.group(1), m.group(2), m.group(3)
    host_lower = host.lower()

    subdomain_org: str | None = None
    if host_lower.endswith(".sentry.io"):
        sub = host_lower[: -len(".sentry.io")]
        if sub and sub not in ("www", "us", "eu", "de"):
            subdomain_org = sub
    elif host_lower not in _SENTRY_HOSTS:
        raise ValueError(f"not a Sentry URL host: {host!r}")

    org = path_org or subdomain_org
    return org, issue_id


def run_repro(args: argparse.Namespace) -> int:
    try:
        org, issue_id = parse_sentry_url(args.sentry_url)
    except ValueError as e:
        return _emit_error(str(e), args.output_json)

    if not os.getenv("SENTRY_AUTH_TOKEN", "").strip() and not os.getenv("LOGOMESH_SENTRY_FIXTURE", "").strip():
        return _emit_error(
            "SENTRY_AUTH_TOKEN is not set. Create a Sentry auth token with "
            "`event:read` scope and export it: "
            "`export SENTRY_AUTH_TOKEN=...`",
            args.output_json,
        )

    try:
        return asyncio.run(_run_async(args, org, issue_id))
    except asyncio.TimeoutError:
        return _emit_error(
            f"timed out after {args.timeout}s", args.output_json,
        )
    except RuntimeError as e:
        return _emit_error(str(e), args.output_json)
    except Exception as e:
        return _emit_error(f"{type(e).__name__}: {e}", args.output_json)


async def _run_async(
    args: argparse.Namespace, org: str | None, issue_id: str,
) -> int:
    from oracles.sentry_replay import (
        build_replay_test,
        fetch_event_by_issue,
        find_innermost_app_frame,
        synthesize_test_llm,
    )
    from cli.codebase_context import extract_codebase_context
    from cli.state_fixtures import load_state_file

    async def _do() -> int:
        exc = await fetch_event_by_issue(issue_id, org=org)
        frame = find_innermost_app_frame(exc)
        if frame is None or not frame.function or frame.function == "<module>":
            return _emit_error(
                f"Sentry issue {issue_id} has no usable in-app frame "
                "(only library frames or module-level code).",
                args.output_json,
            )

        target_path = frame.filename or "<unknown>"
        target_lineno = frame.lineno

        # Source for the function under attack. Try the local repo first
        # (frame.filename is usually a repo-relative path); fall back to the
        # context_line snippet Sentry attached.
        source = _read_target_source(args.repo, frame.filename) or frame.context_line or ""

        # Load state file if user provided one or sentry event referenced it.
        state_bundle = None
        state_path = getattr(args, "state_file", None) or _state_path_from_event(exc)
        if state_path:
            try:
                state_bundle = load_state_file(state_path)
            except (FileNotFoundError, ValueError) as e:
                # Don't abort — state is an enrichment, not a hard requirement.
                if not args.output_json:
                    print(f"  (state file unavailable: {e})", file=sys.stderr)

        # Codebase context (AST import graph + BM25/embedding fixtures).
        ctx = {"function_source": source, "imports_raw": "",
               "dependency_defs": "", "existing_fixtures": ""}
        try:
            ctx = extract_codebase_context(source, frame.function, Path(args.repo))
        except Exception as e:
            if not args.output_json:
                print(f"  (codebase context skipped: {e})", file=sys.stderr)

        # Mock setup code from state bundle (empty if no state).
        from cli.state_fixtures import render_mock_setup
        mock_setup = render_mock_setup(state_bundle)

        # Supplementary context: HTTP mocks, timezone, DB hints, SQLAlchemy fault injection, races.
        from oracles.crash_context import (
            build_supplementary_mock_code,
            inject_freeze_time_decorator,
            tz_for_sandbox,
        )
        from oracles.signal_detectors import build_signal_harnesses
        supplementary = build_supplementary_mock_code(frame, exc, source, args.repo)
        signal_code, signal_meta = build_signal_harnesses(frame, exc, source)
        if signal_code:
            supplementary = signal_code + ("\n" if supplementary else "") + supplementary
        if supplementary:
            mock_setup = supplementary + ("\n" if mock_setup else "") + mock_setup

        # Inject crash timezone into sandbox so time.localtime() uses correct zone.
        crash_tz = tz_for_sandbox(exc)
        sandbox_extra_env: dict[str, str] = {}
        if crash_tz:
            sandbox_extra_env["TZ"] = crash_tz

        # Test synthesis: LLM path with fallback to deterministic.
        if getattr(args, "use_llm", True):
            test_code = await synthesize_test_llm(
                exc, frame, ctx, state_bundle, mock_setup,
            )
        else:
            test_code = build_replay_test(exc, frame, source)

        # Pin time to crash moment on the deterministic path (LLM path gets it via prompt).
        if test_code and not getattr(args, "use_llm", True):
            test_code = inject_freeze_time_decorator(test_code, exc)

        if not test_code:
            return _emit_error(
                f"could not synthesize a replay test for "
                f"{frame.function}() in {target_path}",
                args.output_json,
            )

        # Prepend mock setup so the rendered test sees _REDIS_MOCK etc.
        if mock_setup and mock_setup not in test_code:
            test_code = mock_setup + "\n" + test_code

        # Run the synthesized pytest in the sandbox.
        from business_logic.sandbox import Sandbox

        sandbox_source = source if source.strip() else f"# Sentry frame: {frame.context_line}\n"

        sandbox_files: dict[str, object] = {
            "target.py": sandbox_source,
            "test_target.py": test_code,
        }
        if state_bundle is not None:
            if state_bundle.sqlite_path is not None:
                try:
                    sandbox_files["state.db"] = state_bundle.sqlite_path.read_bytes()
                except OSError:
                    pass
            sandbox_files["mock_config.json"] = _json.dumps({
                "redis": state_bundle.redis_mock,
                "http": state_bundle.http_mock,
            })

        sandbox = Sandbox()
        result = sandbox.run(sandbox_files, extra_env=sandbox_extra_env or None)

        # PYTHONHASHSEED sweep: if KeyError + dict/set locals, retry with seeds 0-19.
        hashseeds = signal_meta.get("try_hashseeds", [])
        if hashseeds and result.get("failed", 0) == 0 and result.get("total", 0) > 0:
            for seed in hashseeds:
                seed_env = dict(sandbox_extra_env)
                seed_env["PYTHONHASHSEED"] = str(seed)
                seed_result = sandbox.run(sandbox_files, extra_env=seed_env)
                if seed_result.get("failed", 0) > 0:
                    result = seed_result
                    sandbox_extra_env["PYTHONHASHSEED"] = str(seed)
                    if not args.output_json:
                        print(f"  (reproduced with PYTHONHASHSEED={seed})", file=sys.stderr)
                    break

        # Retry once on no-repro: the test passed but we expected a crash.
        # Hand the LLM the test + the passing output and ask for a refinement.
        if (
            getattr(args, "use_llm", True)
            and result.get("failed", 0) == 0
            and result.get("total", 0) > 0
        ):
            retry_code = await _retry_with_analysis(
                exc, frame, test_code, result.get("output", ""), ctx, mock_setup,
            )
            if retry_code and retry_code != test_code:
                sandbox_files["test_target.py"] = retry_code
                result = sandbox.run(sandbox_files, extra_env=sandbox_extra_env or None)

        pr_url = getattr(args, "pr_url", "").strip()

        fix_diff = ""
        fix_diff_path = getattr(args, "fix_diff", "").strip()
        if fix_diff_path:
            try:
                fix_diff = Path(fix_diff_path).read_text(errors="replace")
            except OSError as e:
                if not args.output_json:
                    print(f"  (fix-diff unreadable: {e})", file=sys.stderr)

        if getattr(args, "draft_pr", False):
            try:
                from cli.draft_pr import create_draft_pr
                pr_url = create_draft_pr(
                    repo_path=args.repo,
                    issue_id=issue_id,
                    test_code=test_code,
                    exc=exc,
                    frame=frame,
                    result=result,
                )
                if not args.output_json:
                    print(f"  Draft PR: {pr_url}")
            except RuntimeError as e:
                if not args.output_json:
                    print(f"  (draft PR failed: {e})", file=sys.stderr)

        return _render_result(
            args, exc, frame, target_path, target_lineno, result,
            pr_url=pr_url, fix_diff=fix_diff,
        )

    return await asyncio.wait_for(_do(), timeout=max(5, args.timeout))


def _state_path_from_event(exc) -> str:
    """Pull `extra.logomesh_state_file` off the Sentry event if present.

    `SentryException` doesn't currently carry a generic extras dict, so this
    is a best-effort lookup against either an `extras` attribute (forward-compat)
    or a `raw_event` attribute (forward-compat). Returns "" if absent.
    """
    extras = getattr(exc, "extras", None)
    if isinstance(extras, dict):
        v = extras.get("logomesh_state_file")
        if isinstance(v, str) and v:
            return v
    raw = getattr(exc, "raw_event", None)
    if isinstance(raw, dict):
        v = (raw.get("extra") or {}).get("logomesh_state_file")
        if isinstance(v, str) and v:
            return v
    return ""


async def _retry_with_analysis(
    exc, frame, prior_test: str, prior_output: str, ctx: dict, mock_setup: str,
) -> str:
    """Single retry: ask the LLM to refine the test given the passing output.

    Returns the new test source, or "" if no improvement available.
    """
    if not os.getenv("OPENAI_API_KEY", "").strip():
        return ""
    try:
        from openai import AsyncOpenAI  # type: ignore
    except ImportError:
        return ""

    prompt = f"""The following pytest was generated to reproduce a production crash, but it PASSED in the sandbox — meaning it failed to reproduce the bug. Refine the test so it triggers the same exception path.

## Original crash
{exc.error_type}: {exc.error_message}
Function: {frame.function}() at {frame.filename}:{frame.lineno}

## Frame locals at crash
{dict(list(frame.variables.items())[:12])}

## Crashing function source
```python
{(ctx.get('function_source') or '')[:2500]}
```

## Test that did NOT reproduce
```python
{prior_test[:2500]}
```

## Sandbox output (passing)
{prior_output[-2000:]}

## Mock setup available
```python
{mock_setup}
```

Return ONLY the refined pytest source. Same constraints: import from `target`, no try/except, no pytest.raises, single test function.
"""
    client = AsyncOpenAI(timeout=30.0, max_retries=1)
    model_name = os.getenv("LOGOMESH_REPRO_MODEL", "gpt-5-mini")
    is_gpt5 = model_name.startswith("gpt-5") or model_name.startswith("o")
    create_kwargs: dict = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
    }
    # gpt-5 / o-* reject `temperature` and `max_tokens`; map appropriately.
    if not is_gpt5:
        create_kwargs["temperature"] = 0
    create_kwargs["max_completion_tokens" if is_gpt5 else "max_tokens"] = 1500
    try:
        resp = await client.chat.completions.create(**create_kwargs)
    except Exception:
        return ""
    # Usage accounting + budget check (CLI path mirrors orchestrator).
    try:
        from core.usage_tracker import add_usage, check_budget  # type: ignore
        u = getattr(resp, "usage", None)
        if u is not None:
            add_usage(
                getattr(u, "prompt_tokens", 0) or 0,
                getattr(u, "completion_tokens", 0) or 0,
                model=model_name,
            )
            check_budget()
    except ImportError:
        pass
    text = (resp.choices[0].message.content or "").strip()
    if not text or "def test_" not in text:
        return ""
    # Strip markdown fences if any.
    if text.startswith("```"):
        nl = text.find("\n")
        if nl != -1:
            text = text[nl + 1:]
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-3].rstrip()
    return text


def _read_target_source(repo: Path, filename: str) -> str:
    """Try to read `filename` from the local repo. Returns "" on failure."""
    if not filename:
        return ""
    try:
        repo_root = Path(repo).resolve()
    except Exception:
        return ""
    candidates = [
        repo_root / filename,
        repo_root / filename.lstrip("/"),
    ]
    # Sentry filenames sometimes are absolute paths from the prod box; strip
    # leading components and try suffix-matching against the repo.
    parts = Path(filename).parts
    for i in range(len(parts)):
        candidates.append(repo_root.joinpath(*parts[i:]))

    for c in candidates:
        try:
            if c.is_file():
                return c.read_text(errors="replace")
        except Exception:
            continue
    return ""


def _render_result(
    args: argparse.Namespace,
    exc,
    frame,
    target_path: str,
    target_lineno: int,
    result: dict,
    pr_url: str = "",
    fix_diff: str = "",
) -> int:
    if not result.get("success", False) and result.get("total", 0) == 0:
        # Sandbox itself failed to run (e.g. collection error, syntax error).
        reason = (result.get("output") or "sandbox run failed").splitlines()[0][:300]
        return _emit_error(f"sandbox run failed: {reason}", args.output_json)

    reproduced = result.get("failed", 0) > 0

    # Compliance artifact path: if --artifact, the audit envelope replaces the
    # default JSON payload. Auditors get the control-mapped evidence chain.
    if getattr(args, "emit_artifact", False):
        from cli.artifact import render_artifact, get_git_metadata
        branch, commit = get_git_metadata(str(args.repo))
        artifact = render_artifact(
            exc,
            frame,
            result,
            branch=branch,
            commit=commit,
            sandbox_mode=result.get("sandbox_mode", ""),
            pr_url=pr_url,
            fix_diff=fix_diff,
        )
        print(_json.dumps(artifact, indent=2))
        return 0 if reproduced else 1

    payload = {
        "status": "reproduced" if reproduced else "not_reproduced",
        "issue_id": exc.issue_id,
        "exception": exc.error_type,
        "message": exc.error_message,
        "file": target_path,
        "line": target_lineno,
        "function": frame.function,
        "tests_run": result.get("total", 0),
        "tests_failed": result.get("failed", 0),
    }

    if args.output_json:
        if not reproduced:
            payload["details"] = (
                "test passed against current branch — bug appears fixed or "
                "the captured locals are insufficient to reproduce"
            )
        print(_json.dumps(payload, indent=2))
        return 0 if reproduced else 1

    if reproduced:
        print(
            f"  ✓ Reproduced: {exc.error_type} at {target_path}:{target_lineno}"
        )
        if exc.error_message:
            print(f"     {exc.error_message[:200]}")
        if frame.context_line:
            print(f"     {frame.context_line.strip()[:200]}")
        return 0

    print(
        f"  ✗ Cannot reproduce {exc.error_type} at "
        f"{target_path}:{target_lineno}"
    )
    print("     The synthesized test passed against the current branch.")
    print("     Either the bug is fixed, or the captured locals are insufficient.")
    return 1


def _emit_error(msg: str, as_json: bool) -> int:
    if as_json:
        print(_json.dumps({"status": "error", "details": msg}, indent=2))
    else:
        print(f"  ! {msg}", file=sys.stderr)
    return 2
