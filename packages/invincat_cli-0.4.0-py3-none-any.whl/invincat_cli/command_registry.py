"""Unified slash-command registry.

Every slash command is declared once as a `SlashCommand` entry in `COMMANDS`.
Bypass-tier frozensets and autocomplete tuples are derived automatically — no
other file should hard-code command metadata.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from invincat_cli.skills.load import ExtendedSkillMetadata


class BypassTier(StrEnum):
    """Classification that controls whether a command can skip the message queue."""

    ALWAYS = "always"
    """Execute regardless of any busy state, including mid-thread-switch."""

    CONNECTING = "connecting"
    """Bypass only during initial server connection, not during agent/shell."""

    IMMEDIATE_UI = "immediate_ui"
    """Open modal UI immediately; real work deferred via `_defer_action` callback."""

    SIDE_EFFECT_FREE = "side_effect_free"
    """Execute the side effect immediately; defer chat output until idle."""

    QUEUED = "queued"
    """Must wait in the queue when the app is busy."""


@dataclass(frozen=True, slots=True, kw_only=True)
class SlashCommand:
    """A single slash-command definition."""

    name: str
    """Canonical command name (e.g. `/quit`)."""

    description_key: str
    """Translation key for user-facing description."""

    bypass_tier: BypassTier
    """Queue-bypass classification."""

    hidden_keywords: str = ""
    """Space-separated terms for fuzzy matching (never displayed)."""

    aliases: tuple[str, ...] = ()
    """Alternative names (e.g. `("/q",)` for `/quit`)."""

    @property
    def description(self) -> str:
        """Get the localized description for this command.

        Returns:
            The translated description string.
        """
        from invincat_cli.i18n import t

        return t(f"command.{self.description_key}")


COMMANDS: tuple[SlashCommand, ...] = (
    SlashCommand(
        name="/clear",
        description_key="clear",
        bypass_tier=BypassTier.QUEUED,
        hidden_keywords="reset",
    ),
    SlashCommand(
        name="/editor",
        description_key="editor",
        bypass_tier=BypassTier.QUEUED,
    ),
    SlashCommand(
        name="/mcp",
        description_key="mcp",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
        hidden_keywords="servers",
    ),
    SlashCommand(
        name="/memory",
        description_key="memory",
        bypass_tier=BypassTier.IMMEDIATE_UI,
        hidden_keywords="store status active archived",
    ),
    SlashCommand(
        name="/wecombot-start",
        description_key="wecombot_start",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
        hidden_keywords="wecom wechat bot long connection run",
    ),
    SlashCommand(
        name="/wecombot-status",
        description_key="wecombot_status",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
        hidden_keywords="wecom wechat bot long connection status",
    ),
    SlashCommand(
        name="/wecombot-stop",
        description_key="wecombot_stop",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
        hidden_keywords="wecom wechat bot long connection stop",
    ),
    SlashCommand(
        name="/model",
        description_key="model",
        bypass_tier=BypassTier.IMMEDIATE_UI,
    ),
    SlashCommand(
        name="/offload",
        description_key="offload",
        bypass_tier=BypassTier.QUEUED,
        hidden_keywords="compact",
        aliases=("/compact",),
    ),
    SlashCommand(
        name="/plan",
        description_key="plan",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
        hidden_keywords="design propose dry-run readonly",
    ),
    SlashCommand(
        name="/exit-plan",
        description_key="exit_plan",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
        hidden_keywords="leave planner mode",
    ),
    SlashCommand(
        name="/skill-creator",
        description_key="skill_creator",
        bypass_tier=BypassTier.QUEUED,
    ),
    SlashCommand(
        name="/threads",
        description_key="threads",
        bypass_tier=BypassTier.IMMEDIATE_UI,
        hidden_keywords="continue history sessions",
    ),
    SlashCommand(
        name="/trace",
        description_key="trace",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
    ),
    SlashCommand(
        name="/tokens",
        description_key="tokens",
        bypass_tier=BypassTier.QUEUED,
        hidden_keywords="cost",
    ),
    SlashCommand(
        name="/reload",
        description_key="reload",
        bypass_tier=BypassTier.QUEUED,
        hidden_keywords="refresh",
    ),
    SlashCommand(
        name="/theme",
        description_key="theme",
        bypass_tier=BypassTier.IMMEDIATE_UI,
        hidden_keywords="dark light color appearance",
    ),
    # SlashCommand(
    #     name="/update",
    #     description_key="update",
    #     bypass_tier=BypassTier.QUEUED,
    #     hidden_keywords="upgrade",
    # ),
    # SlashCommand(
    #     name="/auto-update",
    #     description_key="auto_update",
    #     bypass_tier=BypassTier.SIDE_EFFECT_FREE,
    # ),
    SlashCommand(
        name="/changelog",
        description_key="changelog",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
    ),
    SlashCommand(
        name="/version",
        description_key="version",
        bypass_tier=BypassTier.CONNECTING,
    ),
    SlashCommand(
        name="/feedback",
        description_key="feedback",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
    ),
    SlashCommand(
        name="/docs",
        description_key="docs",
        bypass_tier=BypassTier.SIDE_EFFECT_FREE,
    ),
    SlashCommand(
        name="/help",
        description_key="help",
        bypass_tier=BypassTier.QUEUED,
    ),
    SlashCommand(
        name="/language",
        description_key="language",
        bypass_tier=BypassTier.IMMEDIATE_UI,
        hidden_keywords="locale i18n chinese english",
    ),
    SlashCommand(
        name="/schedule",
        description_key="schedule",
        bypass_tier=BypassTier.IMMEDIATE_UI,
        hidden_keywords="cron timer task recurring run list pause resume delete",
    ),
    SlashCommand(
        name="/quit",
        description_key="quit",
        bypass_tier=BypassTier.ALWAYS,
        hidden_keywords="close leave",
        aliases=("/q",),
    ),
)
"""All slash commands."""


# ---------------------------------------------------------------------------
# Derived bypass-tier frozensets
# ---------------------------------------------------------------------------


def _build_bypass_set(tier: BypassTier) -> frozenset[str]:
    """Build a frozenset of command names (including aliases) for a tier.

    Args:
        tier: The bypass tier to collect.

    Returns:
        Frozenset of all names and aliases that belong to `tier`.
    """
    names: set[str] = set()
    for cmd in COMMANDS:
        if cmd.bypass_tier == tier:
            names.add(cmd.name)
            names.update(cmd.aliases)
    return frozenset(names)


ALWAYS_IMMEDIATE: frozenset[str] = _build_bypass_set(BypassTier.ALWAYS)
"""Commands that execute regardless of any busy state."""

BYPASS_WHEN_CONNECTING: frozenset[str] = _build_bypass_set(BypassTier.CONNECTING)
"""Commands that bypass only during initial server connection."""

IMMEDIATE_UI: frozenset[str] = _build_bypass_set(BypassTier.IMMEDIATE_UI)
"""Commands that open modal UI immediately, deferring real work."""

SIDE_EFFECT_FREE: frozenset[str] = _build_bypass_set(BypassTier.SIDE_EFFECT_FREE)
"""Commands whose side effect fires immediately; chat output deferred until idle."""

QUEUE_BOUND: frozenset[str] = _build_bypass_set(BypassTier.QUEUED)
"""Commands that must wait in the queue when the app is busy."""

ALL_CLASSIFIED: frozenset[str] = (
    ALWAYS_IMMEDIATE
    | BYPASS_WHEN_CONNECTING
    | IMMEDIATE_UI
    | SIDE_EFFECT_FREE
    | QUEUE_BOUND
)
"""Union of all five tiers — used by drift tests."""


# ---------------------------------------------------------------------------
# Autocomplete tuples
# ---------------------------------------------------------------------------

SLASH_COMMANDS: list[tuple[str, str, str]] = [
    entry
    for cmd in COMMANDS
    for entry in (
        [(cmd.name, cmd.description, cmd.hidden_keywords)]
        + [(alias, cmd.description, cmd.hidden_keywords) for alias in cmd.aliases]
    )
]
"""`(name, description, hidden_keywords)` tuples for `SlashCommandController`.

Aliases are included as separate entries so they appear in autocomplete."""


def parse_skill_command(command: str) -> tuple[str, str]:
    """Extract skill name and args from a `/skill:<name>` command.

    Args:
        command: The full command string (e.g., `/skill:web-research find X`).

    Returns:
        Tuple of `(skill_name, args)`.

            The skill name is normalized to lowercase. Both are empty strings
            when the command has no skill name after the prefix.
    """
    after_prefix = command[len("/skill:") :].strip()
    parts = after_prefix.split(maxsplit=1)
    if not parts or not parts[0]:
        return "", ""
    skill_name = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""
    return skill_name, args

def build_skill_commands(
    skills: list[ExtendedSkillMetadata],
) -> list[tuple[str, str, str]]:
    """Build autocomplete tuples for discovered skills.

    Each skill becomes a `/skill:<name>` entry with its description
    and the skill name as a hidden keyword for fuzzy matching.

    Args:
        skills: List of discovered skill metadata.

    Returns:
        List of `(name, description, hidden_keywords)` tuples.
    """
    return [
        (f"/skill:{skill['name']}", skill["description"], skill["name"])
        for skill in skills
    ]
