"""Lightweight runtime context type for CLI model overrides.

Extracted from `configurable_model` so hot-path modules (`app`,
`textual_adapter`) can import `CLIContext` without pulling in the langchain
middleware stack.
"""

from __future__ import annotations

from typing import Any

from typing_extensions import TypedDict


class CLIContext(TypedDict, total=False):
    """Runtime context passed via `context=` to the LangGraph graph.

    Carries per-invocation overrides that `ConfigurableModelMiddleware`
    reads from `request.runtime.context`.
    """

    model: str | None
    """Model spec to swap at runtime (e.g. `'openai:gpt-4o'`)."""

    model_params: dict[str, Any]
    """Invocation params (e.g. `temperature`, `max_tokens`) to merge
    into `model_settings`."""

    memory_model: str | None
    """Optional dedicated model spec for the memory agent.

    When unset, memory extraction uses the active primary model.
    """

    memory_model_params: dict[str, Any]
    """Invocation params for the dedicated memory model."""

    wecom_enabled: bool
    """Whether this invocation is running from the WeCom bridge.

    WeCom-only tools use this flag to expose their schemas only for
    `/wecombot` turns.
    """

    scheduled_run: bool
    """Whether this turn was triggered by the scheduler (not by the user).

    When True, ``ScheduleMiddleware`` hides all task-management tools to
    prevent recursive scheduled-task creation.
    """
