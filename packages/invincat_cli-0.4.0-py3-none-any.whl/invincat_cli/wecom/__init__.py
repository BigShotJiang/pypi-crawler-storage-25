"""WeCom integration package."""
