"""Allow running the CLI as: python -m deepagents.cli."""

from invincat_cli.main import cli_main

if __name__ == "__main__":
    cli_main()
