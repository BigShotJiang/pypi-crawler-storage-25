"""MCP integration package."""
