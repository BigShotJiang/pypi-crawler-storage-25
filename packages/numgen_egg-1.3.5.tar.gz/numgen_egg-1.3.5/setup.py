from setuptools import setup, find_packages

setup(
    name="gen",
    version="1.3.5",
    packages=find_packages(),
    description="A Python package for generating pseudo-random high entropy number strings.",
    author="",
    python_requires=">=3.7",
)
