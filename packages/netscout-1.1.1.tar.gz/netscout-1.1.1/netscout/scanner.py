"""
Async scanning engine — host discovery via ICMP sweep and TCP SYN fallback.

Design principles:
  - SPEED FIRST: single nmap call for entire target set when available
  - Fan-out concurrently with asyncio + semaphore gating
  - Never poll sequentially; everything runs in parallel
  - Randomise scan order to evade rate limiting
  - Cache results; never re-probe the same IP
"""

from __future__ import annotations

import asyncio
import platform
import random
import re
import shutil
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Callable

from . import resolver

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class PortInfo:
    """Per-port scan result."""
    port: int
    state: str = "closed"      # "open" | "closed" | "filtered"
    banner: str = ""           # first line of grabbed banner
    service: str = ""          # service name guess

@dataclass
class HostResult:
    """Aggregated result for one host."""
    ip: str
    alive: bool = False
    method: str = ""           # "icmp" | "tcp" | "nmap-sn"
    hostname: str = ""
    mac: str = ""
    vendor: str = ""
    rtt_ms: float = 0.0
    ttl: int = 0
    os_guess: str = ""
    open_ports: list[int] = field(default_factory=list)
    port_details: dict[int, PortInfo] = field(default_factory=dict)

# ---------------------------------------------------------------------------
# Well-known service table (port → service name)
# ---------------------------------------------------------------------------

WELL_KNOWN_SERVICES: dict[int, str] = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns",
    80: "http", 88: "kerberos", 110: "pop3", 111: "rpcbind",
    135: "msrpc", 139: "netbios-ssn", 143: "imap", 389: "ldap",
    443: "https", 445: "microsoft-ds", 465: "smtps", 587: "submission",
    636: "ldaps", 993: "imaps", 995: "pop3s", 1433: "mssql",
    1521: "oracle", 2049: "nfs", 3306: "mysql", 3389: "ms-wbt-server",
    5432: "postgresql", 5900: "vnc", 5985: "wsman", 5986: "wsmans",
    6379: "redis", 8080: "http-proxy", 8443: "https-alt",
    8888: "sun-answerbook", 9090: "zeus-admin", 27017: "mongodb",
}

# ---------------------------------------------------------------------------
# TTL → OS heuristic
# ---------------------------------------------------------------------------

TTL_OS_MAP: list[tuple[range, str]] = [
    (range(0, 33),   "Network Device / Unknown"),
    (range(33, 65),  "Linux/Unix"),
    (range(65, 129), "Windows"),
    (range(129, 256), "Cisco/Network OS"),
]

def guess_os_from_ttl(ttl: int) -> str:
    """Return an OS guess string based on the observed TTL value."""
    for ttl_range, os_name in TTL_OS_MAP:
        if ttl in ttl_range:
            return os_name
    return "Unknown"

# ---------------------------------------------------------------------------
# nmap availability check
# ---------------------------------------------------------------------------

def nmap_available() -> bool:
    """Check if nmap is on PATH."""
    return shutil.which("nmap") is not None

# ---------------------------------------------------------------------------
# nmap-based host discovery  (-sn)
# ---------------------------------------------------------------------------

async def _nmap_ping_sweep(
    targets: list[str],
    fast: bool = False,
    callback: Callable[[HostResult], None] | None = None,
) -> dict[str, HostResult]:
    """
    Run a single `nmap -sn` against all targets at once.
    Returns dict[ip, HostResult].
    """
    timing = "-T5" if fast else "-T4"
    cmd = [
        "nmap", "-sn", timing,
        "-oX", "-",   # XML to stdout
    ]
    if fast:
        cmd.extend(["--min-parallelism", "100", "--max-retries", "1"])
        
    cmd.extend(targets)

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()

    results: dict[str, HostResult] = {}
    try:
        root = ET.fromstring(stdout.decode(errors="replace"))
    except ET.ParseError:
        return results

    for host_el in root.findall("host"):
        status_el = host_el.find("status")
        if status_el is None:
            continue
        alive = status_el.get("state") == "up"

        addr_el = host_el.find("address[@addrtype='ipv4']")
        if addr_el is None:
            continue
        ip = addr_el.get("addr", "")

        hr = HostResult(ip=ip, alive=alive, method="nmap-sn")

        # MAC
        mac_el = host_el.find("address[@addrtype='mac']")
        if mac_el is not None:
            hr.mac = mac_el.get("addr", "")
            hr.vendor = mac_el.get("vendor", "")

        # Hostname from nmap
        hostnames_el = host_el.find("hostnames")
        if hostnames_el is not None:
            hn = hostnames_el.find("hostname")
            if hn is not None:
                hr.hostname = hn.get("name", "")

        # RTT / srtt (nmap stores in seconds as string)
        times_el = host_el.find("times")
        if times_el is not None:
            srtt = times_el.get("srtt", "0")
            try:
                hr.rtt_ms = int(srtt) / 1000.0
            except ValueError:
                pass

        results[ip] = hr
        if callback and alive:
            callback(hr)

    return results


# ---------------------------------------------------------------------------
# asyncio-based ICMP ping sweep (fallback when nmap unavailable)
# ---------------------------------------------------------------------------

_PING_TTL_RE = {
    "Windows": re.compile(r"TTL[=:](\d+)", re.IGNORECASE),
    "default": re.compile(r"ttl=(\d+)", re.IGNORECASE),
}

_PING_RTT_RE = {
    "Windows": re.compile(r"time[=<](\d+\.?\d*)", re.IGNORECASE),
    "default": re.compile(r"time=(\d+\.?\d*)", re.IGNORECASE),
}


async def _ping_host(
    ip: str,
    timeout: float,
    sem: asyncio.Semaphore,
) -> HostResult:
    """Ping a single host via subprocess."""
    is_win = platform.system() == "Windows"
    count_flag = "-n" if is_win else "-c"
    timeout_flag = "-w" if is_win else "-W"
    timeout_val = str(int(timeout * 1000)) if is_win else str(int(timeout))

    cmd = ["ping", count_flag, "1", timeout_flag, timeout_val, ip]

    async with sem:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, _ = await asyncio.wait_for(
                proc.communicate(), timeout=timeout + 2
            )
        except (asyncio.TimeoutError, OSError):
            return HostResult(ip=ip, alive=False, method="icmp")

    output = stdout_bytes.decode(errors="replace")
    alive = proc.returncode == 0

    hr = HostResult(ip=ip, alive=alive, method="icmp")

    if alive:
        # Extract TTL
        pattern_key = "Windows" if is_win else "default"
        ttl_m = _PING_TTL_RE[pattern_key].search(output)
        if ttl_m:
            hr.ttl = int(ttl_m.group(1))
            hr.os_guess = guess_os_from_ttl(hr.ttl)

        # Extract RTT
        rtt_m = _PING_RTT_RE[pattern_key].search(output)
        if rtt_m:
            hr.rtt_ms = float(rtt_m.group(1))

    return hr


async def _icmp_sweep(
    ips: list[str],
    timeout: float = 1.0,
    threads: int = 150,
    callback: Callable[[HostResult], None] | None = None,
) -> dict[str, HostResult]:
    """Fan-out ping to all IPs concurrently with semaphore gating."""
    sem = asyncio.Semaphore(threads)
    tasks = [_ping_host(ip, timeout, sem) for ip in ips]
    results: dict[str, HostResult] = {}
    for coro in asyncio.as_completed(tasks):
        hr = await coro
        results[hr.ip] = hr
        if callback and hr.alive:
            callback(hr)
    return results


# ---------------------------------------------------------------------------
# TCP SYN fallback for ICMP-dark hosts
# ---------------------------------------------------------------------------

TCP_FALLBACK_PORTS = [22, 80, 443, 445, 3389]


async def _tcp_probe_host(
    ip: str,
    ports: list[int],
    timeout: float,
    sem: asyncio.Semaphore,
) -> HostResult:
    """Attempt TCP connect to given ports; first open port = alive."""
    hr = HostResult(ip=ip, alive=False, method="tcp")
    for port in ports:
        async with sem:
            try:
                _, writer = await asyncio.wait_for(
                    asyncio.open_connection(ip, port),
                    timeout=timeout,
                )
                hr.alive = True
                hr.open_ports.append(port)
                writer.close()
                await writer.wait_closed()
                break  # first response wins
            except (asyncio.TimeoutError, OSError, ConnectionRefusedError):
                continue
    return hr


async def _tcp_fallback(
    ips: list[str],
    ports: list[int] | None = None,
    timeout: float = 0.5,
    threads: int = 150,
    callback: Callable[[HostResult], None] | None = None,
) -> dict[str, HostResult]:
    """TCP connect scan on ICMP-dark hosts."""
    probe_ports = ports or TCP_FALLBACK_PORTS
    sem = asyncio.Semaphore(threads)
    tasks = [_tcp_probe_host(ip, probe_ports, timeout, sem) for ip in ips]
    results: dict[str, HostResult] = {}
    for coro in asyncio.as_completed(tasks):
        hr = await coro
        results[hr.ip] = hr
        if callback and hr.alive:
            callback(hr)
    return results


# ---------------------------------------------------------------------------
# Public scan entry point
# ---------------------------------------------------------------------------

async def discover_hosts(
    ips: list[str],
    *,
    tcp_fallback: bool = False,
    tcp_ports: list[int] | None = None,
    timeout: float = 1.0,
    threads: int = 150,
    fast: bool = False,
    os_guess: bool = False,
    callback: Callable[[HostResult], None] | None = None,
) -> dict[str, HostResult]:
    """
    Primary discovery: ICMP sweep → optional TCP fallback.

    Strategy:
      1. If nmap available → single `nmap -sn` call (fastest)
      2. Else → asyncio-based ping sweep
      3. If tcp_fallback → probe ICMP-dark hosts on common ports
      4. Randomise scan order to evade rate limiting
    """
    # Shuffle to evade rate limiting
    shuffled = list(ips)
    random.shuffle(shuffled)

    # Phase 1: Host discovery
    if nmap_available():
        results = await _nmap_ping_sweep(
            [str(ip) for ip in shuffled], fast=fast, callback=callback
        )
        # Fill in missing IPs as dead
        for ip_str in (str(ip) for ip in ips):
            if ip_str not in results:
                results[ip_str] = HostResult(ip=ip_str, alive=False, method="nmap-sn")
    else:
        results = await _icmp_sweep(
            [str(ip) for ip in shuffled],
            timeout=timeout,
            threads=threads,
            callback=callback,
        )

    # Phase 2: TCP fallback for dead hosts
    if tcp_fallback:
        dead_ips = [ip for ip, hr in results.items() if not hr.alive]
        if dead_ips:
            tcp_results = await _tcp_fallback(
                dead_ips,
                ports=tcp_ports,
                timeout=0.5,
                threads=threads,
                callback=callback,
            )
            for ip, hr in tcp_results.items():
                if hr.alive:
                    results[ip] = hr

    # Phase 3: TTL-based OS guess if requested and not already set
    if os_guess:
        for hr in results.values():
            if hr.alive and hr.ttl and not hr.os_guess:
                hr.os_guess = guess_os_from_ttl(hr.ttl)

    return results
