"""View executor integration tests."""
