"""Shared helpers for BigQuery integration tests."""

from __future__ import annotations

import os
import re
import uuid
from pathlib import Path
from typing import Any

import pytest

from sqlbuild.adapter.shared.models import StatementRecorder
from sqlbuild.integrations.bigquery.client import BigQueryAdapter

_ENV_KEYS: tuple[str, ...] = ("SQB_TEST_BIGQUERY_PROJECT",)
_DEFAULT_LOCATION: str = "europe-west2"


def build_bigquery_connection_config(*, schema: str | None = None) -> dict[str, object]:
    """Return BigQuery connection config from required env vars or skip."""

    missing: list[str] = [key for key in _ENV_KEYS if not os.environ.get(key)]
    if missing:
        pytest.skip("BigQuery credentials not configured: " + ", ".join(sorted(missing)))
    return {
        "project": os.environ["SQB_TEST_BIGQUERY_PROJECT"],
        "location": os.environ.get("SQB_TEST_BIGQUERY_LOCATION", _DEFAULT_LOCATION),
        "schema": schema,
    }


def build_unique_dataset_name(*, prefix: str) -> str:
    """Build a BigQuery-safe unique dataset name."""

    normalized_prefix: str = re.sub(r"[^A-Za-z0-9_]", "_", prefix).lower().strip("_")
    suffix: str = uuid.uuid4().hex[:10].lower()
    return f"{normalized_prefix}_{suffix}"


def qualified_name(*, project: str, dataset: str, name: str) -> str:
    """Build a fully qualified BigQuery relation name."""

    return f"`{project}.{dataset}.{name}`"


def execute_statements(
    *,
    adapter: BigQueryAdapter,
    connection: Any,
    statements: tuple[str, ...],
) -> None:
    """Execute a sequence of SQL statements against BigQuery."""

    statement: str
    for statement in statements:
        adapter.execute(connection, statement)


def fetch_rows(
    *, adapter: BigQueryAdapter, connection: Any, sql: str
) -> tuple[tuple[object, ...], ...]:
    """Fetch all rows for a query."""

    cursor: Any = adapter.execute(connection, sql)
    try:
        return tuple(tuple(row) for row in cursor.fetchall())
    finally:
        cursor.close()


def write_seed_file(*, tmp_path: Path, filename: str, contents: str) -> Path:
    """Write a seed CSV file for BigQuery adapter tests."""

    file_path: Path = tmp_path / filename
    file_path.write_text(contents, encoding="utf-8")
    return file_path


def build_statement_recorder() -> StatementRecorder:
    """Build a statement recorder for adapter mutation operations."""

    return StatementRecorder()
