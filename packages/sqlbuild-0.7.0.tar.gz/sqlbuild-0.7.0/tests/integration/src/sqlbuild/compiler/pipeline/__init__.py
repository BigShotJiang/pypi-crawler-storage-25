"""Compiler pipeline integration tests."""
