"""Shared diagnostics support."""
