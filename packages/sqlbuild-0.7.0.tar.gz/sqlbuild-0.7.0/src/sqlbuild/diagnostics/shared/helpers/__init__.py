"""Diagnostics helper functions."""
