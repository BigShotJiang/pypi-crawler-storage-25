"""Diff executor helper package."""
