"""Diff executor package."""
