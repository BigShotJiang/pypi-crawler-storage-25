"""Diff executor entrypoint package."""
