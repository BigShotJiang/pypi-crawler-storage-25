"""Executor pipeline package."""
