"""Executor shared package."""
