"""Clean executor package."""
