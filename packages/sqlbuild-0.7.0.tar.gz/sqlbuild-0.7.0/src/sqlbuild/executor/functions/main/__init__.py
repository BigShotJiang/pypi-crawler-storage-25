"""SQL function execution entrypoints."""
