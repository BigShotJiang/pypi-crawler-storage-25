"""Placeholder model spec module."""
