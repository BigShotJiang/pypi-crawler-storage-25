"""DuckDB adapter integration."""
