"""DuckDB adapter helpers."""
