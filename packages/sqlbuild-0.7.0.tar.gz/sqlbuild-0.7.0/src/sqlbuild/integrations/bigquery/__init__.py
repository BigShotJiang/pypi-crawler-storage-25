"""BigQuery integration package."""
