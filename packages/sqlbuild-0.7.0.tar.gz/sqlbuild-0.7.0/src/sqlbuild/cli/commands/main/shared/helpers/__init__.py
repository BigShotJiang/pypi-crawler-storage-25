"""Shared CLI helpers."""
