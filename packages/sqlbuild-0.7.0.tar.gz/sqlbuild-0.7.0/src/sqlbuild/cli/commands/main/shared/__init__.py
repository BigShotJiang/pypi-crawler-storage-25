"""Shared CLI support package."""
