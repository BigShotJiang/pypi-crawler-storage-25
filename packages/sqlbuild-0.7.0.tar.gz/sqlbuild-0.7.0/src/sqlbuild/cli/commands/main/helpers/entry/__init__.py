"""CLI entry package."""
