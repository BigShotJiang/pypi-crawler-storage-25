"""Compile command helpers."""
