"""Main CLI command package."""
