"""Compiler shared package."""
