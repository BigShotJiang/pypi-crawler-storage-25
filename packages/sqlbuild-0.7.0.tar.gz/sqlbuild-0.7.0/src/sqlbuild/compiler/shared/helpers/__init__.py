"""Shared compiler helper utilities."""
