"""Pipeline helpers."""
