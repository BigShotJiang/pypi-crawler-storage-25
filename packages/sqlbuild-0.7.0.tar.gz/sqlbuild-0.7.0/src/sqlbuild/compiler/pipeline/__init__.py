"""Compiler orchestration pipeline package."""
