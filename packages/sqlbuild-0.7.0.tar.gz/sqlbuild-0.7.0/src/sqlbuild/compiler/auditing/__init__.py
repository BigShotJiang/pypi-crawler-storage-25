"""Compiler auditing package."""
