"""Compile package."""
