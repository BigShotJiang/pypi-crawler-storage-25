"""Compile public entry modules."""
