"""Column lineage semantic analysis."""
