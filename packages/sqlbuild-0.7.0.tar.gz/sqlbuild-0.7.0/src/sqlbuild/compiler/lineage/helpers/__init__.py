"""Column lineage helper utilities."""
