"""Planner helper utilities."""
