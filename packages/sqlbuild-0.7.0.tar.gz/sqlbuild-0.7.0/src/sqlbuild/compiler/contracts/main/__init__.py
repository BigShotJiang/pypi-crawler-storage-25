"""Contract validation entrypoints."""
