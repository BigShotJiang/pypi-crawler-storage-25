"""Model contract validation."""
