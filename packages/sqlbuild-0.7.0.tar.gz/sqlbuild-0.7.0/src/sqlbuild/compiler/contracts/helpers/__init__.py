"""Contract validation helper functions."""
