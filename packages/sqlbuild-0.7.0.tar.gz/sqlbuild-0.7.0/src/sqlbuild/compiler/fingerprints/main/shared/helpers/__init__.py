"""Fingerprint helper utilities."""
