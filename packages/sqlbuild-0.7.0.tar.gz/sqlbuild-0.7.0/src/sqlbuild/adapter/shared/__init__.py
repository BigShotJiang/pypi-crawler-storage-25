"""Shared adapter mixin classes."""
