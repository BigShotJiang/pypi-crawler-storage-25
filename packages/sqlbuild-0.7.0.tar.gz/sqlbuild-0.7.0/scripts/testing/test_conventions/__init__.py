"""Test convention checker package."""
