"""Type annotation script package."""
