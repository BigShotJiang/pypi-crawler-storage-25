"""Structure script package."""
