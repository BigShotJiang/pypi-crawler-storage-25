"""Structure convention checker package."""
