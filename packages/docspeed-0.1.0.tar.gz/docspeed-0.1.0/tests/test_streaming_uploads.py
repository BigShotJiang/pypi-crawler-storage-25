from pathlib import Path

import httpx
from typer.testing import CliRunner

from docspeed import Docspeed
from docspeed.cli import app


def _request_url(url: object) -> str:
    raw = str(url)
    if raw.startswith("http://") or raw.startswith("https://"):
        return raw
    return f"https://docspeed.ai{raw}"


def test_files_upload_passes_live_path_file_handle(monkeypatch, tmp_path: Path) -> None:
    sample = tmp_path / "sample.pdf"
    sample.write_bytes(b"%PDF-1.7 fake")
    captured: dict[str, object] = {}

    def fake_request(self, method, url, **kwargs):  # type: ignore[no-untyped-def]
        captured["files"] = kwargs["files"]
        return httpx.Response(
            200,
            json={
                "file_id": "file_123",
                "filename": "sample.pdf",
                "content_type": "application/pdf",
                "size_bytes": sample.stat().st_size,
                "created_at": 1.0,
            },
            request=httpx.Request(method, _request_url(url)),
        )

    monkeypatch.setattr(httpx.Client, "request", fake_request)

    with Docspeed(api_key="test-key") as client:
        uploaded = client.files.upload(sample)

    files = captured["files"]
    assert isinstance(files, dict)
    part = files["file"]
    assert part[0] == "sample.pdf"
    assert part[1].__class__.__name__ != "bytes"
    assert hasattr(part[1], "read")
    assert uploaded.file_id == "file_123"


def test_files_upload_uses_provided_file_object_without_copy(monkeypatch, tmp_path: Path) -> None:
    sample = tmp_path / "sample.pdf"
    sample.write_bytes(b"%PDF-1.7 fake")
    captured: dict[str, object] = {}

    def fake_request(self, method, url, **kwargs):  # type: ignore[no-untyped-def]
        captured["files"] = kwargs["files"]
        return httpx.Response(
            200,
            json={
                "file_id": "file_456",
                "filename": "sample.pdf",
                "content_type": "application/pdf",
                "size_bytes": sample.stat().st_size,
                "created_at": 1.0,
            },
            request=httpx.Request(method, _request_url(url)),
        )

    monkeypatch.setattr(httpx.Client, "request", fake_request)

    with sample.open("rb") as handle:
        with Docspeed(api_key="test-key") as client:
            client.files.upload(handle)
        part = captured["files"]["file"]
        assert part[1] is handle


def test_cli_parse_file_auto_upload_reuses_streaming_upload_path(monkeypatch, tmp_path: Path) -> None:
    sample = tmp_path / "sample.pdf"
    sample.write_bytes(b"%PDF-1.7 fake")
    calls: dict[str, object] = {}

    class FakeFiles:
        def upload(self, value):  # type: ignore[no-untyped-def]
            calls["upload_value"] = value
            return type("Uploaded", (), {"file_id": "file_uploaded"})()

    class FakeClient:
        def __init__(self) -> None:
            self.files = FakeFiles()

        def __enter__(self):  # type: ignore[no-untyped-def]
            return self

        def __exit__(self, exc_type, exc, tb):  # type: ignore[no-untyped-def]
            return None

        def parse(self, payload):  # type: ignore[no-untyped-def]
            calls["parse_payload"] = payload
            return {"job_id": "job_123", "operation": "parse", "status": "pending", "execution_mode": "async", "created_at": 1.0, "updated_at": 1.0}

        class jobs:
            @staticmethod
            def wait(job_id, poll_interval=2.0, timeout=600.0):  # type: ignore[no-untyped-def]
                return {"job_id": job_id, "status": "completed", "markdown": "# done"}

    monkeypatch.setattr("docspeed.cli._build_client", lambda state: FakeClient())
    runner = CliRunner()

    result = runner.invoke(
        app,
        ["--api-key", "test-key", "parse", "--file", str(sample), "--wait"],
    )

    assert result.exit_code == 0
    assert calls["upload_value"] == sample
    assert calls["parse_payload"]["input"]["file_id"] == "file_uploaded"


def test_cli_chat_multi_uploads_multiple_file_paths(monkeypatch, tmp_path: Path) -> None:
    sample_a = tmp_path / "a.pdf"
    sample_b = tmp_path / "b.pdf"
    sample_a.write_bytes(b"a")
    sample_b.write_bytes(b"b")
    uploads: list[Path] = []

    class FakeFiles:
        def upload(self, value):  # type: ignore[no-untyped-def]
            uploads.append(value)
            return type("Uploaded", (), {"file_id": f"file_{len(uploads)}"})()

    class FakeClient:
        def __init__(self) -> None:
            self.files = FakeFiles()

        def __enter__(self):  # type: ignore[no-untyped-def]
            return self

        def __exit__(self, exc_type, exc, tb):  # type: ignore[no-untyped-def]
            return None

        def chat_multi(self, payload):  # type: ignore[no-untyped-def]
            return {"answer": "ok", "citations": [], "doc_ids": [item["file_id"] for item in payload["inputs"]]}

    monkeypatch.setattr("docspeed.cli._build_client", lambda state: FakeClient())
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "--api-key",
            "test-key",
            "chat-multi",
            "--file",
            str(sample_a),
            "--file",
            str(sample_b),
            "--query",
            "Which is larger?",
            "--execution-mode",
            "sync",
        ],
    )

    assert result.exit_code == 0
    assert uploads == [sample_a, sample_b]
