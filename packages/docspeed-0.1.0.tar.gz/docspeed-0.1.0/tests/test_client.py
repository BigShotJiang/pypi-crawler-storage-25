import time
from pathlib import Path

import httpx

from docspeed import Docspeed
from docspeed.exceptions import DocspeedAPIError


def test_parse_sync_returns_typed_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["Authorization"] == "Bearer test-key"
        return httpx.Response(
            200,
            json={
                "doc_id": "doc_123",
                "version": "0.1.0",
                "language": None,
                "markdown": "# Parsed",
                "pages": [{"page_index": 0, "markdown": "# Parsed", "ocr_lines": []}],
                "regions": [],
                "spans": [],
                "metadata": {"grounding": "regions"},
                "artifacts": [],
            },
            request=request,
        )

    client = Docspeed(
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler), base_url="https://docspeed.ai"),
    )
    result = client.parse({"input": {"file_id": "file_123"}, "execution_mode": "sync"})

    assert result.markdown == "# Parsed"
    assert result.metadata["grounding"] == "regions"


def test_parse_async_returns_job_ref() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "job_id": "job_123",
                "operation": "parse",
                "status": "pending",
                "execution_mode": "async",
                "created_at": 1.0,
                "updated_at": 1.0,
            },
            request=request,
        )

    client = Docspeed(
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler), base_url="https://docspeed.ai"),
    )
    result = client.parse({"input": {"file_id": "file_123"}, "execution_mode": "async"})

    assert result.job_id == "job_123"
    assert result.operation == "parse"


def test_jobs_wait_polls_until_result(monkeypatch) -> None:
    call_count = {"jobs": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/v1/jobs/job_123":
            call_count["jobs"] += 1
            status = "pending" if call_count["jobs"] == 1 else "completed"
            return httpx.Response(
                200,
                json={
                    "job_id": "job_123",
                    "operation": "parse",
                    "status": status,
                    "execution_mode": "async",
                    "created_at": 1.0,
                    "updated_at": 2.0,
                },
                request=request,
            )
        if request.url.path == "/v1/jobs/job_123/result":
            return httpx.Response(200, json={"markdown": "# done"}, request=request)
        raise AssertionError(f"Unexpected request path: {request.url.path}")

    monkeypatch.setattr(time, "sleep", lambda _: None)
    client = Docspeed(
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler), base_url="https://docspeed.ai"),
    )

    result = client.jobs.wait("job_123", poll_interval=0.01, timeout=1.0)

    assert result == {"markdown": "# done"}
    assert call_count["jobs"] == 2


def test_api_error_exposes_status_and_code() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            422,
            json={
                "detail": {
                    "code": "table_codegen_provider_policy_blocked",
                    "message": "Provider policy blocked the table extraction request.",
                    "details": {"provider": "mock"},
                }
            },
            request=request,
        )

    client = Docspeed(
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler), base_url="https://docspeed.ai"),
    )

    try:
        client.tables({"input": {"file_id": "file_123"}, "execution_mode": "sync"})
    except DocspeedAPIError as exc:
        assert exc.status_code == 422
        assert exc.code == "table_codegen_provider_policy_blocked"
        assert exc.details["provider"] == "mock"
    else:
        raise AssertionError("Expected DocspeedAPIError")
