import httpx

from docspeed import Docspeed
from docspeed.agent_tools import anthropic, openai


def test_openai_agent_tools_return_function_schemas_and_handlers() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/v1/agents/tools":
            return httpx.Response(
                200,
                json={
                    "tools": [
                        {
                            "name": "parse",
                            "description": "Parse PDFs and images into markdown and structured artifacts.",
                            "endpoint": "/v1/parse",
                        }
                    ]
                },
                request=request,
            )
        if request.url.path == "/v1/parse":
            return httpx.Response(
                200,
                json={
                    "doc_id": "doc_123",
                    "version": "0.1.0",
                    "language": None,
                    "markdown": "# Parsed",
                    "pages": [{"page_index": 0, "markdown": "# Parsed", "ocr_lines": []}],
                    "regions": [],
                    "spans": [],
                    "metadata": {"grounding": "regions"},
                    "artifacts": [],
                },
                request=request,
            )
        raise AssertionError(f"Unexpected request path: {request.url.path}")

    client = Docspeed(
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler), base_url="https://docspeed.ai"),
    )
    bundle = openai(client, ["parse"])

    assert bundle.tools[0]["type"] == "function"
    assert bundle.tools[0]["name"] == "parse"
    result = bundle.handlers["parse"]({"input": {"file_id": "file_123"}, "execution_mode": "sync"})
    assert result.markdown == "# Parsed"


def test_anthropic_agent_tools_return_input_schema_shape() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "tools": [
                    {
                        "name": "chat_single",
                        "description": "Ask grounded questions against one document.",
                        "endpoint": "/v1/chat/single",
                    }
                ]
            },
            request=request,
        )

    client = Docspeed(
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler), base_url="https://docspeed.ai"),
    )
    bundle = anthropic(client, ["chat_single"])

    assert bundle.tools[0]["name"] == "chat_single"
    assert "input_schema" in bundle.tools[0]
