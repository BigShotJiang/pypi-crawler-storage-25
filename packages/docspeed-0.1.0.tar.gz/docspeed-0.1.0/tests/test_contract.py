from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]


def test_vendored_contract_covers_full_public_surface() -> None:
    payload = REPO_ROOT.joinpath("contracts", "customer_api_v1_openapi.json").read_text()

    for endpoint in [
        "/v1/files",
        "/v1/files/{file_id}",
        "/v1/files/{file_id}/pages/{page_index}/image",
        "/v1/parse",
        "/v1/layout",
        "/v1/ocr",
        "/v1/classify",
        "/v1/split",
        "/v1/tables",
        "/v1/equations",
        "/v1/charts",
        "/v1/schema/auto",
        "/v1/extract",
        "/v1/chat/single",
        "/v1/chat/multi",
        "/v1/agents/tools",
        "/v1/agents",
        "/v1/jobs/{job_id}",
        "/v1/jobs/{job_id}/result",
    ]:
        assert endpoint in payload


def test_pyproject_keeps_core_dependencies_thin() -> None:
    pyproject = REPO_ROOT.joinpath("pyproject.toml").read_text()

    assert '"httpx>=' in pyproject
    assert '"pydantic>=' in pyproject
    assert '"typer>=' in pyproject
    assert "openai>=" not in pyproject
    assert "anthropic>=" not in pyproject
