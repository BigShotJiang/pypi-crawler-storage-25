# Docspeed Python SDK

Thin Python SDK and CLI for the hosted Docspeed `/v1/*` customer API.

## Install

```bash
pip install docspeed
```

CLI installs also work with:

```bash
pipx install docspeed
uv tool install docspeed
```

## Python Quickstart

```python
from docspeed import Docspeed

with Docspeed(api_key="docspeed_sk_...") as client:
    uploaded = client.files.upload("sample.pdf")
    parsed = client.parse(
        {
            "input": {"file_id": uploaded.file_id},
            "execution_mode": "sync",
            "grounding": "ocr_lines",
            "include_artifacts": True,
        }
    )
    print(parsed.markdown[:500])
```

## CLI Quickstart

```bash
docspeed --api-key "$DOCSPEED_API_KEY" parse --file sample.pdf --execution-mode sync
```

The package is intentionally thin:

- hosted API client only
- streaming multipart uploads for large files
- core dependencies limited to `httpx`, `pydantic`, and `typer`
- provider-native agent SDKs are not required
