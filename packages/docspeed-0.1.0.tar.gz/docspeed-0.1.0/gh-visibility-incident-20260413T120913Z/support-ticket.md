Subject: Public profile/repo return 404 while authenticated APIs show repo as public

Severity/Impact:
Production release blocked; public users cannot access owner profile or repository.

Context (UTC):
- Incident date: 2026-04-13
- Owner/repo: docspeed-ai/docspeed-python
- Authenticated API shows repo as public/private=false with recent push.

Observed behavior:
- https://github.com/docspeed-ai => HTTP 404 (X-GitHub-Request-Id: BF26:333450:105DAA70:10ADB4F1:69DCDCF1)
- https://github.com/docspeed-ai/docspeed-python => HTTP 404 (X-GitHub-Request-Id: BF2E:FAE51:104D3B8A:109CD2A2:69DCDCF2)
- https://api.github.com/users/docspeed-ai => HTTP 404 (X-GitHub-Request-Id: 87AE:3C62C6:139E9B61:13EE8E77:69DCDCF4)
- https://api.github.com/repos/docspeed-ai/docspeed-python => HTTP 404 (X-GitHub-Request-Id: 87BA:FAA69:12E0BB7B:1331AD5C:69DCDCF5)

Control check:
- https://api.github.com/users/octocat => HTTP 200

Authenticated confirmation:
- visibility: public
- private: false
- pushed_at: 2026-04-13T11:54:14Z
- authenticated repo request id: 87A4:185734:11C9B1E0:121A1FDA:69DCDCEE

Explicit request:
Please review this account for possible account-level restriction/flagging/trust-safety state that suppresses anonymous visibility. Authenticated API calls succeed, but anonymous web/API endpoints return 404 for both the owner and repo. Please confirm root cause and restore normal public visibility for docspeed-ai.

Attachment:
- Full evidence bundle directory: gh-visibility-incident-20260413T120913Z
