Hello GitHub Support,

I am requesting an account review/reinstatement check for user `docspeed-ai`.

Issue summary:
- Authenticated GitHub access works for this account.
- Repository `docspeed-ai/docspeed-python` is configured public and successfully pushed.
- But anonymous/public access returns 404 for both owner and repo endpoints.

Impact:
- Public release is blocked because users cannot access the profile/repository.

Observed URLs returning 404 anonymously:
- https://github.com/docspeed-ai
- https://github.com/docspeed-ai/docspeed-python
- https://api.github.com/users/docspeed-ai
- https://api.github.com/repos/docspeed-ai/docspeed-python

Control check:
- https://api.github.com/users/octocat returns 200.

Explicit request:
Please review this account for possible account-level restriction/flagging/trust-safety state suppressing anonymous visibility. If restricted/flagged, please restore normal public visibility for `docspeed-ai` and `docspeed-ai/docspeed-python`.

Evidence attached:
- gh-visibility-incident-20260413T120913Z.tar.gz
- Includes UTC timestamps, headers, request IDs, authenticated vs anonymous outputs.
