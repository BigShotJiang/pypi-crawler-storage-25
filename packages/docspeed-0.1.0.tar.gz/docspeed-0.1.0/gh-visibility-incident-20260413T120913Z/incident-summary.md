# GitHub Visibility Incident Summary

- Generated (UTC): 2026-04-13T12:09:57Z
- Owner/Repo: docspeed-ai/docspeed-python
- Bundle directory: gh-visibility-incident-20260413T120913Z

## Authenticated state
- Repo visibility: public
- Repo private: false
- Repo pushed_at: 2026-04-13T11:54:14Z
- Auth repo request id: 87A4:185734:11C9B1E0:121A1FDA:69DCDCEE

## Anonymous/public state
- GET https://github.com/docspeed-ai => HTTP 404 (request id: BF26:333450:105DAA70:10ADB4F1:69DCDCF1)
- GET https://github.com/docspeed-ai/docspeed-python => HTTP 404 (request id: BF2E:FAE51:104D3B8A:109CD2A2:69DCDCF2)
- GET https://api.github.com/users/docspeed-ai => HTTP 404 (request id: 87AE:3C62C6:139E9B61:13EE8E77:69DCDCF4)
- GET https://api.github.com/repos/docspeed-ai/docspeed-python => HTTP 404 (request id: 87BA:FAA69:12E0BB7B:1331AD5C:69DCDCF5)

## Control
- GET https://api.github.com/users/octocat => HTTP 200

## Assessment
- Authenticated GitHub access shows repo as public.
- Anonymous access returns 404 for owner and repo endpoints.
- Pattern indicates account/platform visibility suppression rather than local git config.

## Independent Vantage Check
- Source: Codex web-fetch environment (separate from local shell session)
- https://api.github.com/users/octocat => 200
- https://api.github.com/users/docspeed-ai => 404
- Confirms issue is not isolated to local machine/browser cache.
