from __future__ import annotations

import shutil
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = (REPO_ROOT.parent / "docspeed" / "public_artifacts" / "openapi" / "customer_api_v1_openapi.json").resolve()
DESTINATION = REPO_ROOT / "contracts" / "customer_api_v1_openapi.json"


def sync_contract(source: Path = DEFAULT_SOURCE) -> Path:
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, DESTINATION)
    return DESTINATION


def main() -> None:
    sync_contract()


if __name__ == "__main__":
    main()
