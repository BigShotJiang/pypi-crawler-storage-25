from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, model_validator


ExecutionMode = Literal["async", "sync"]
GroundingMode = Literal["none", "regions", "ocr_lines", "cell"]
LayoutMode = Literal["nested", "non_overlapping"]
InputType = Literal["markdown", "image", "pdf", "text", "auto"]
ClassificationScope = Literal["document", "page"]
ClassificationVerbosity = Literal["none", "debug"]
OcrLanguage = Literal["auto", "global"]
OcrMode = Literal["regular", "classic", "agentic"]
JobStatus = Literal["pending", "processing", "completed", "failed"]


class InputSource(BaseModel):
    file_id: Optional[str] = None
    text: Optional[str] = None
    markdown: Optional[str] = None
    image_base64: Optional[str] = None
    pdf_base64: Optional[str] = None
    filename: Optional[str] = None

    @model_validator(mode="after")
    def validate_one_source(self) -> "InputSource":
        provided = [
            bool(self.file_id),
            bool(self.text),
            bool(self.markdown),
            bool(self.image_base64),
            bool(self.pdf_base64),
        ]
        if sum(provided) != 1:
            raise ValueError(
                "Exactly one input source must be provided: file_id, text, markdown, image_base64, or pdf_base64."
            )
        return self


class FileRef(BaseModel):
    file_id: str
    filename: str
    content_type: Optional[str] = None
    size_bytes: int
    created_at: float


class JobRef(BaseModel):
    job_id: str
    operation: str
    status: JobStatus
    execution_mode: ExecutionMode
    created_at: float
    updated_at: float


class GroundingRegion(BaseModel):
    region_id: str
    page_index: int
    label: Optional[str] = None
    shape: Dict[str, Any]


class OcrLine(BaseModel):
    line_id: str
    text: str
    bbox: Optional[List[int]] = None
    page_index: int
    polygon: Optional[List[float]] = None


class MarkdownPage(BaseModel):
    page_index: int
    markdown: str
    ocr_lines: List[OcrLine] = Field(default_factory=list)


class LayoutRegion(BaseModel):
    region_id: str
    page_index: int
    region_type: str
    bbox: List[int]
    score: Optional[float] = None
    nested_children: List[str] = Field(default_factory=list)


class TableCell(BaseModel):
    value: str
    row: Optional[int] = None
    col: Optional[int] = None
    cell_id: Optional[str] = None
    source_order: Optional[int] = None
    is_header: bool = False
    row_index: Optional[int] = None
    col_index: Optional[int] = None
    rowspan: int = 1
    colspan: int = 1
    text: Optional[str] = None
    html: Optional[str] = None
    page_index: Optional[int] = None
    line_ids: List[str] = Field(default_factory=list)
    region_ids: List[str] = Field(default_factory=list)
    effective_region_ids: List[str] = Field(default_factory=list)
    bbox: Optional[List[int]] = None


class TableRenderGridCell(BaseModel):
    cell_id: str
    source_order: int
    row_index: int
    col_index: int
    rowspan: int = 1
    colspan: int = 1
    is_header: bool = False
    value: str = ""
    region_ids: List[str] = Field(default_factory=list)
    effective_region_ids: List[str] = Field(default_factory=list)


class TableRenderGridRow(BaseModel):
    row_index: int
    is_header: bool = False
    cells: List[TableRenderGridCell] = Field(default_factory=list)


class TableRenderGrid(BaseModel):
    rows: List[TableRenderGridRow] = Field(default_factory=list)


class TableResult(BaseModel):
    page_index: Optional[int] = None
    source_page_indexes: List[int] = Field(default_factory=list)
    html: str
    region_type: str = "table_body"
    region_ids: List[str] = Field(default_factory=list)
    bbox: Optional[List[int]] = None
    header_row_count: int = 0
    grid_row_count: int = 0
    grid_col_count: int = 0
    mapping_quality: Literal["exact", "heuristic", "fallback"] = "fallback"
    render_grid: TableRenderGrid = Field(default_factory=TableRenderGrid)
    cells: List[TableCell] = Field(default_factory=list)
    table_render_diagnostics: Optional[Dict[str, Any]] = Field(default=None, exclude=True)


class TableExtractResponse(BaseModel):
    grounding: Literal["none", "table", "cell"]
    tables: List[TableResult] = Field(default_factory=list)
    grounding_regions: Optional[List[GroundingRegion]] = None


class EquationResult(BaseModel):
    equation_id: str
    page_index: int
    latex: str = ""
    source_text: str = ""
    display_mode: Literal["inline", "block"] = "block"
    confidence: float = 0.0
    bbox: Optional[List[int]] = None
    line_ids: List[str] = Field(default_factory=list)
    region_ids: List[str] = Field(default_factory=list)
    codegen_trace: Optional[Dict[str, Any]] = Field(default=None, exclude=True)


class EquationExtractResponse(BaseModel):
    engine: Literal["equation_codegen", "parse_fallback"] = "equation_codegen"
    pages: int = 0
    equations: List[EquationResult] = Field(default_factory=list)
    grounding_regions: List[GroundingRegion] = Field(default_factory=list)
    codegen_diagnostics: Optional[Dict[str, Any]] = Field(default=None, exclude=True)


class ChartAxes(BaseModel):
    x_label: str = ""
    y_label: str = ""


class ChartSeriesPoint(BaseModel):
    x: Optional[Any] = None
    y: Optional[Any] = None
    label: Optional[str] = None


class ChartSeries(BaseModel):
    name: str = ""
    points: List[ChartSeriesPoint] = Field(default_factory=list)


class ChartItem(BaseModel):
    item_id: str
    page_index: int
    kind: Literal["chart", "figure", "diagram", "flowchart", "engineering_diagram"] = "figure"
    title: str = ""
    summary: str = ""
    insights: List[str] = Field(default_factory=list)
    axes: ChartAxes = Field(default_factory=ChartAxes)
    series: List[ChartSeries] = Field(default_factory=list)
    mermaid: str = ""
    confidence: float = 0.0
    bbox: Optional[List[int]] = None
    line_ids: List[str] = Field(default_factory=list)
    region_ids: List[str] = Field(default_factory=list)
    codegen_trace: Optional[Dict[str, Any]] = Field(default=None, exclude=True)


class ChartDescribeResponse(BaseModel):
    engine: Literal["chart_codegen", "parse_fallback"] = "chart_codegen"
    pages: int = 0
    items: List[ChartItem] = Field(default_factory=list)
    grounding_regions: List[GroundingRegion] = Field(default_factory=list)
    codegen_diagnostics: Optional[Dict[str, Any]] = Field(default=None, exclude=True)


class ClassificationPage(BaseModel):
    page_index: int
    doc_class: str
    page_role: Optional[str] = None
    components_present: Optional[List[str]] = None
    document_identity_hints: Optional[Dict[str, Any]] = None
    confidence: Optional[float] = None


class ClassificationMetadata(BaseModel):
    classification_scope: ClassificationScope = "document"
    verbosity: ClassificationVerbosity = "none"
    budget_limited: bool = False
    total_pages: int = 1
    processed_pages: int = 1
    sampled_page_indexes: List[int] = Field(default_factory=list)
    class_count: int = 0


class PageDimension(BaseModel):
    page_index: int
    width: int
    height: int


class ClassificationDebug(BaseModel):
    sampled_page_classifications: List[ClassificationPage] = Field(default_factory=list)


class ClassificationResult(BaseModel):
    doc_class: str
    input_type: InputType = "auto"
    model: str
    page_count: int = 1
    page_classifications: List[ClassificationPage] = Field(default_factory=list)
    document_identity_hints: Dict[str, Any] = Field(default_factory=dict)
    page_dimensions: List[PageDimension] = Field(default_factory=list)
    classification_metadata: ClassificationMetadata = Field(default_factory=ClassificationMetadata)
    debug: Optional[ClassificationDebug] = None


class ClassDefinition(BaseModel):
    label: str
    description: str


class SplitSegment(BaseModel):
    start_page: int
    end_page: int
    doc_class: str
    title: Optional[str] = None
    confidence: Optional[float] = None
    reason: Optional[str] = None
    file_ref: Optional[FileRef] = None


class SplitPlan(BaseModel):
    total_pages: int
    documents: List[SplitSegment]
    split_metadata: Optional[Dict[str, Any]] = None
    page_summaries: Optional[List[Dict[str, Any]]] = None


class SchemaResult(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    mode: Literal["zero_doc", "single_doc", "multi_doc_global"]
    schema_payload: Dict[str, Any] = Field(
        alias="schema",
        serialization_alias="schema",
        validation_alias=AliasChoices("schema", "schema_payload"),
    )


class ExtractionResult(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    schema_payload: Dict[str, Any] = Field(
        alias="schema",
        serialization_alias="schema",
        validation_alias=AliasChoices("schema", "schema_payload"),
    )
    result: Dict[str, Any]
    grounding_mode: str
    page_count: int = 1


class ChatCitation(BaseModel):
    doc_id: Optional[str] = None
    region_ids: List[str] = Field(default_factory=list)


class ChatAnswer(BaseModel):
    answer: str
    citations: List[ChatCitation] = Field(default_factory=list)


class ParseSpan(BaseModel):
    span_id: str
    start: int
    end: int
    region_ids: List[str] = Field(default_factory=list)
    entity_type: str = "unknown"


class ParseResponse(BaseModel):
    doc_id: Optional[str] = None
    version: Optional[str] = None
    language: Optional[str] = None
    markdown: str
    pages: List[MarkdownPage] = Field(default_factory=list)
    regions: List[GroundingRegion] = Field(default_factory=list)
    spans: List[ParseSpan] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    artifacts: List[Dict[str, Any]] = Field(default_factory=list)


class LayoutPage(BaseModel):
    page_index: int
    width: int
    height: int
    image_ref: Optional[str] = None
    regions: List[LayoutRegion] = Field(default_factory=list)


class LayoutResponse(BaseModel):
    mode: LayoutMode
    pages: List[LayoutPage] = Field(default_factory=list)


class OcrPage(BaseModel):
    page_index: int
    width: int
    height: int
    text: str
    lines: List[OcrLine] = Field(default_factory=list)


class OcrResponse(BaseModel):
    language: OcrLanguage
    mode: Literal["regular", "classic"]
    pages: List[OcrPage] = Field(default_factory=list)


class ToolDefinition(BaseModel):
    name: str
    description: str
    endpoint: Optional[str] = None
    mcp_name: Optional[str] = None


class AgentDefinition(BaseModel):
    agent_id: str
    name: str
    description: str
    instructions: str
    tools: List[ToolDefinition] = Field(default_factory=list)


class AgentToolsResponse(BaseModel):
    tools: List[ToolDefinition] = Field(default_factory=list)


class AgentCreateResponse(AgentDefinition):
    created_at: float


class ParseRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"
    grounding: Literal["none", "regions", "ocr_lines"] = "regions"
    include_artifacts: bool = False


class LayoutRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"
    mode: LayoutMode = "non_overlapping"


class OcrRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"
    language: OcrLanguage = "auto"
    mode: OcrMode = "regular"


class ClassifyRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"
    input_type: InputType = "auto"
    classification_scope: ClassificationScope = "document"
    verbosity: ClassificationVerbosity = "none"
    class_definitions: List[ClassDefinition] = Field(default_factory=list)


class SplitRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"
    verbosity: ClassificationVerbosity = "none"


class TableExtractRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"
    grounding: Literal["none", "table", "cell"] = "cell"
    detection_policy: Literal["strict", "liberal"] = "strict"


class EquationExtractRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"


class ChartDescribeRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"


class SchemaAutoRequest(BaseModel):
    inputs: List[InputSource] = Field(default_factory=list)
    execution_mode: ExecutionMode = "async"
    description: Optional[str] = None

    @model_validator(mode="after")
    def validate_schema_request(self) -> "SchemaAutoRequest":
        if self.description and self.inputs:
            raise ValueError("Zero-document schema generation cannot be combined with document inputs.")
        if not self.description and not self.inputs:
            raise ValueError("Provide either a description or one or more inputs.")
        return self


class ExtractRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    input: InputSource
    execution_mode: ExecutionMode = "async"
    schema_payload: Optional[Dict[str, Any]] = Field(
        default=None,
        alias="schema",
        serialization_alias="schema",
        validation_alias=AliasChoices("schema", "schema_payload"),
    )
    grounding: Literal["none", "regions", "cell"] = "cell"


class ChatSingleRequest(BaseModel):
    input: InputSource
    execution_mode: ExecutionMode = "async"
    query: str
    include_grounding: bool = True


class ChatMultiRequest(BaseModel):
    inputs: List[InputSource]
    execution_mode: ExecutionMode = "async"
    query: str
    include_grounding: bool = True


class SchemaAutoResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    mode: Literal["zero_doc", "single_doc", "multi_doc_global"]
    schema_payload: Dict[str, Any] = Field(
        alias="schema",
        serialization_alias="schema",
        validation_alias=AliasChoices("schema", "schema_payload"),
    )
    attempts: Optional[List[Dict[str, Any]]] = None


class ChatMultiResponse(ChatAnswer):
    doc_ids: List[str] = Field(default_factory=list)


class AgentCreateRequest(BaseModel):
    name: str
    description: str
    instructions: str
    tool_names: List[str] = Field(default_factory=list)
