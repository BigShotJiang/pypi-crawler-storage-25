from __future__ import annotations

from typing import Any


class DocspeedError(Exception):
    """Base exception for Docspeed SDK errors."""


class DocspeedConfigError(DocspeedError):
    """Raised when client configuration is invalid or incomplete."""


class DocspeedTransportError(DocspeedError):
    """Raised when the SDK cannot talk to the Docspeed API."""


class DocspeedAPIError(DocspeedError):
    """Raised when the Docspeed API returns an error response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        code: str | None = None,
        details: dict[str, Any] | None = None,
        raw_body: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.details = details or {}
        self.raw_body = raw_body


class DocspeedJobError(DocspeedError):
    """Raised when an async Docspeed job fails."""

    def __init__(self, job_id: str, status: str, error: str | None = None) -> None:
        message = f"Docspeed job {job_id} ended with status={status}"
        if error:
            message = f"{message}: {error}"
        super().__init__(message)
        self.job_id = job_id
        self.status = status
        self.error = error


class DocspeedJobTimeoutError(DocspeedJobError):
    """Raised when waiting for a Docspeed job times out."""
