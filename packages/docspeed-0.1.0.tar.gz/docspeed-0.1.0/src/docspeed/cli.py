from __future__ import annotations

import asyncio
import base64
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import typer

from .client import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, Docspeed
from .models import AgentCreateRequest, InputSource, JobRef


app = typer.Typer(no_args_is_help=True, help="Docspeed CLI for the hosted /v1 customer API.")
files_app = typer.Typer(no_args_is_help=True)
jobs_app = typer.Typer(no_args_is_help=True)
agents_app = typer.Typer(no_args_is_help=True)
app.add_typer(files_app, name="files")
app.add_typer(jobs_app, name="jobs")
app.add_typer(agents_app, name="agents")


@dataclass
class CLIState:
    api_key: str | None
    base_url: str
    timeout: float
    output_format: str
    request_id: str | None


def _json_dump(payload: Any, pretty: bool) -> str:
    if pretty:
        return json.dumps(payload, indent=2, sort_keys=True)
    return json.dumps(payload, separators=(",", ":"), sort_keys=True)


def _emit(state: CLIState, payload: Any) -> None:
    typer.echo(_json_dump(payload, pretty=state.output_format == "pretty"))


def _parse_json_value(raw_value: str | None) -> Any:
    if raw_value is None:
        return None
    if raw_value.startswith("@"):
        raw_text = Path(raw_value[1:]).read_text()
    else:
        raw_text = raw_value
    return json.loads(raw_text)


def _build_client(state: CLIState) -> Docspeed:
    return Docspeed(
        api_key=state.api_key,
        base_url=state.base_url,
        timeout=state.timeout,
        request_id=state.request_id,
    )


def _single_source(
    client: Docspeed,
    *,
    file_path: Path | None,
    file_id: str | None,
    text: str | None,
    markdown: str | None,
) -> dict[str, Any]:
    provided = [file_path is not None, bool(file_id), text is not None, markdown is not None]
    if sum(provided) != 1:
        raise typer.BadParameter("Provide exactly one of --file, --file-id, --text, or --markdown.")
    if file_path is not None:
        uploaded = client.files.upload(file_path)
        return InputSource(file_id=uploaded.file_id).model_dump(mode="json", exclude_none=True)
    return InputSource(file_id=file_id, text=text, markdown=markdown).model_dump(mode="json", exclude_none=True)


def _multi_sources(
    client: Docspeed,
    *,
    file_paths: list[Path],
    file_ids: list[str],
    texts: list[str],
    markdowns: list[str],
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for path in file_paths:
        uploaded = client.files.upload(path)
        items.append(InputSource(file_id=uploaded.file_id).model_dump(mode="json", exclude_none=True))
    for file_id in file_ids:
        items.append(InputSource(file_id=file_id).model_dump(mode="json", exclude_none=True))
    for text in texts:
        items.append(InputSource(text=text).model_dump(mode="json", exclude_none=True))
    for markdown in markdowns:
        items.append(InputSource(markdown=markdown).model_dump(mode="json", exclude_none=True))
    if not items:
        raise typer.BadParameter("Provide at least one --file, --file-id, --text, or --markdown input.")
    return items


def _coerce_job_ref(payload: Any) -> JobRef | None:
    if isinstance(payload, JobRef):
        return payload
    if isinstance(payload, dict) and {"job_id", "status", "execution_mode"} <= set(payload):
        return JobRef.model_validate(payload)
    return None


def _finalize_operation_result(
    client: Docspeed,
    result: Any,
    *,
    wait: bool,
    poll_interval: float,
    wait_timeout: float,
) -> Any:
    if not wait:
        return result
    job = _coerce_job_ref(result.model_dump(mode="json") if hasattr(result, "model_dump") else result)
    if job is None:
        return result
    return client.jobs.wait(job.job_id, poll_interval=poll_interval, timeout=wait_timeout)


def _model_or_mapping(payload: Any) -> Any:
    if hasattr(payload, "model_dump"):
        return payload.model_dump(mode="json", by_alias=True, exclude_none=True)
    return payload


def _maybe_schema(raw_schema: str | None) -> Any:
    return _parse_json_value(raw_schema) if raw_schema else None


def _common_execution_options() -> tuple[str, bool, float, float]:
    raise RuntimeError("Helper should never be called directly.")


@app.callback()
def main_callback(
    ctx: typer.Context,
    api_key: str | None = typer.Option(None, "--api-key", envvar="DOCSPEED_API_KEY"),
    base_url: str = typer.Option(DEFAULT_BASE_URL, "--base-url", envvar="DOCSPEED_BASE_URL"),
    timeout: float = typer.Option(DEFAULT_TIMEOUT, "--timeout", envvar="DOCSPEED_TIMEOUT"),
    output_format: str = typer.Option("json", "--format", case_sensitive=False),
    request_id: str | None = typer.Option(None, "--request-id"),
) -> None:
    ctx.obj = CLIState(
        api_key=api_key,
        base_url=base_url,
        timeout=timeout,
        output_format=output_format,
        request_id=request_id,
    )


@app.command()
def parse(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    text: str | None = typer.Option(None, "--text"),
    markdown: str | None = typer.Option(None, "--markdown"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    grounding: str = typer.Option("regions", "--grounding"),
    include_artifacts: bool = typer.Option(False, "--include-artifacts"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {
                "input": _single_source(client, file_path=file_path, file_id=file_id, text=text, markdown=markdown),
                "execution_mode": execution_mode,
                "grounding": grounding,
                "include_artifacts": include_artifacts,
            }
        result = _finalize_operation_result(client, client.parse(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command()
def layout(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    mode: str = typer.Option("non_overlapping", "--mode"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {"input": _single_source(client, file_path=file_path, file_id=file_id, text=None, markdown=None), "execution_mode": execution_mode, "mode": mode}
        result = _finalize_operation_result(client, client.layout(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command()
def ocr(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    language: str = typer.Option("auto", "--language"),
    mode: str = typer.Option("regular", "--mode"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {"input": _single_source(client, file_path=file_path, file_id=file_id, text=None, markdown=None), "execution_mode": execution_mode, "language": language, "mode": mode}
        result = _finalize_operation_result(client, client.ocr(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command()
def classify(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    text: str | None = typer.Option(None, "--text"),
    markdown: str | None = typer.Option(None, "--markdown"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    input_type: str = typer.Option("auto", "--input-type"),
    classification_scope: str = typer.Option("document", "--classification-scope"),
    verbosity: str = typer.Option("none", "--verbosity"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {
                "input": _single_source(client, file_path=file_path, file_id=file_id, text=text, markdown=markdown),
                "execution_mode": execution_mode,
                "input_type": input_type,
                "classification_scope": classification_scope,
                "verbosity": verbosity,
            }
        result = _finalize_operation_result(client, client.classify(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command()
def split(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    verbosity: str = typer.Option("none", "--verbosity"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {"input": _single_source(client, file_path=file_path, file_id=file_id, text=None, markdown=None), "execution_mode": execution_mode, "verbosity": verbosity}
        result = _finalize_operation_result(client, client.split(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command("tables")
def tables_command(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    grounding: str = typer.Option("cell", "--grounding"),
    detection_policy: str = typer.Option("strict", "--detection-policy"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {
                "input": _single_source(client, file_path=file_path, file_id=file_id, text=None, markdown=None),
                "execution_mode": execution_mode,
                "grounding": grounding,
                "detection_policy": detection_policy,
            }
        result = _finalize_operation_result(client, client.tables(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command("equations")
def equations_command(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {"input": _single_source(client, file_path=file_path, file_id=file_id, text=None, markdown=None), "execution_mode": execution_mode}
        result = _finalize_operation_result(client, client.equations(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command("charts")
def charts_command(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {"input": _single_source(client, file_path=file_path, file_id=file_id, text=None, markdown=None), "execution_mode": execution_mode}
        result = _finalize_operation_result(client, client.charts(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command("schema-auto")
def schema_auto_command(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_paths: list[Path] = typer.Option([], "--file"),
    file_ids: list[str] = typer.Option([], "--file-id"),
    texts: list[str] = typer.Option([], "--text"),
    markdowns: list[str] = typer.Option([], "--markdown"),
    description: str | None = typer.Option(None, "--description"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            if description:
                payload = {"description": description, "execution_mode": execution_mode}
            else:
                payload = {
                    "inputs": _multi_sources(client, file_paths=file_paths, file_ids=file_ids, texts=texts, markdowns=markdowns),
                    "execution_mode": execution_mode,
                }
        result = _finalize_operation_result(client, client.schema_auto(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command()
def extract(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    schema: str | None = typer.Option(None, "--schema"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    grounding: str = typer.Option("cell", "--grounding"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            payload = {
                "input": _single_source(client, file_path=file_path, file_id=file_id, text=None, markdown=None),
                "execution_mode": execution_mode,
                "grounding": grounding,
            }
            schema_payload = _maybe_schema(schema)
            if schema_payload is not None:
                payload["schema"] = schema_payload
        result = _finalize_operation_result(client, client.extract(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command("chat-single")
def chat_single_command(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_path: Path | None = typer.Option(None, "--file"),
    file_id: str | None = typer.Option(None, "--file-id"),
    text: str | None = typer.Option(None, "--text"),
    markdown: str | None = typer.Option(None, "--markdown"),
    query: str | None = typer.Option(None, "--query"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    include_grounding: bool = typer.Option(True, "--include-grounding/--no-include-grounding"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            if not query:
                raise typer.BadParameter("--query is required unless --request is provided.")
            payload = {
                "input": _single_source(client, file_path=file_path, file_id=file_id, text=text, markdown=markdown),
                "execution_mode": execution_mode,
                "query": query,
                "include_grounding": include_grounding,
            }
        result = _finalize_operation_result(client, client.chat_single(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@app.command("chat-multi")
def chat_multi_command(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    file_paths: list[Path] = typer.Option([], "--file"),
    file_ids: list[str] = typer.Option([], "--file-id"),
    texts: list[str] = typer.Option([], "--text"),
    markdowns: list[str] = typer.Option([], "--markdown"),
    query: str | None = typer.Option(None, "--query"),
    execution_mode: str = typer.Option("async", "--execution-mode"),
    include_grounding: bool = typer.Option(True, "--include-grounding/--no-include-grounding"),
    wait: bool = typer.Option(False, "--wait"),
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    wait_timeout: float = typer.Option(600.0, "--wait-timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            if not query:
                raise typer.BadParameter("--query is required unless --request is provided.")
            payload = {
                "inputs": _multi_sources(client, file_paths=file_paths, file_ids=file_ids, texts=texts, markdowns=markdowns),
                "execution_mode": execution_mode,
                "query": query,
                "include_grounding": include_grounding,
            }
        result = _finalize_operation_result(client, client.chat_multi(payload), wait=wait, poll_interval=poll_interval, wait_timeout=wait_timeout)
        _emit(state, _model_or_mapping(result))


@files_app.command("upload")
def files_upload(ctx: typer.Context, path: Path) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        uploaded = client.files.upload(path)
        _emit(state, uploaded.model_dump(mode="json"))


@files_app.command("page-image")
def files_page_image(
    ctx: typer.Context,
    file_id: str = typer.Option(..., "--file-id"),
    page_index: int = typer.Option(..., "--page-index"),
    output: Path | None = typer.Option(None, "--output"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        image = client.files.page_image(file_id, page_index)
        if output is not None:
            output.write_bytes(image.content)
            payload = {
                "content_type": image.content_type,
                "output_path": str(output),
                "size_bytes": len(image.content),
            }
        else:
            payload = {
                "content_type": image.content_type,
                "bytes_base64": base64.b64encode(image.content).decode("ascii"),
            }
        _emit(state, payload)


@jobs_app.command("get")
def jobs_get(ctx: typer.Context, job_id: str) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        job = client.jobs.get(job_id)
        _emit(state, job.model_dump(mode="json"))


@jobs_app.command("result")
def jobs_result(ctx: typer.Context, job_id: str) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        _emit(state, client.jobs.result(job_id))


@jobs_app.command("wait")
def jobs_wait(
    ctx: typer.Context,
    job_id: str,
    poll_interval: float = typer.Option(2.0, "--poll-interval"),
    timeout: float = typer.Option(600.0, "--timeout"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        _emit(state, client.jobs.wait(job_id, poll_interval=poll_interval, timeout=timeout))


@agents_app.command("tools")
def agents_tools(ctx: typer.Context) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = client.agents.tools()
        _emit(state, payload.model_dump(mode="json"))


@agents_app.command("create")
def agents_create(
    ctx: typer.Context,
    request: str | None = typer.Option(None, "--request"),
    name: str | None = typer.Option(None, "--name"),
    description: str | None = typer.Option(None, "--description"),
    instructions: str | None = typer.Option(None, "--instructions"),
    tool_names: list[str] = typer.Option([], "--tool-name"),
) -> None:
    state = ctx.obj
    with _build_client(state) as client:
        payload = _parse_json_value(request)
        if payload is None:
            if not name or not description or not instructions:
                raise typer.BadParameter("--name, --description, and --instructions are required unless --request is provided.")
            payload = AgentCreateRequest(
                name=name,
                description=description,
                instructions=instructions,
                tool_names=tool_names,
            ).model_dump(mode="json", exclude_none=True)
        created = client.agents.create(payload)
        _emit(state, created.model_dump(mode="json"))


def main() -> None:
    app()
