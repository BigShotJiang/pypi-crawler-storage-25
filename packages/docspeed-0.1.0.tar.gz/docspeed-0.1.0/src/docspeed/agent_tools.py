from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping

from . import models


@dataclass(frozen=True)
class AgentToolBundle:
    tools: list[dict[str, Any]]
    handlers: dict[str, Callable[[Mapping[str, Any]], Any]]


_TOOL_MODEL_BY_NAME: dict[str, type[models.BaseModel]] = {
    "parse": models.ParseRequest,
    "layout": models.LayoutRequest,
    "ocr": models.OcrRequest,
    "classify": models.ClassifyRequest,
    "split": models.SplitRequest,
    "tables_extract": models.TableExtractRequest,
    "equations_extract": models.EquationExtractRequest,
    "charts_describe": models.ChartDescribeRequest,
    "schema_auto": models.SchemaAutoRequest,
    "extract": models.ExtractRequest,
    "chat_single": models.ChatSingleRequest,
    "chat_multi": models.ChatMultiRequest,
}

_CLIENT_METHOD_BY_TOOL_NAME = {
    "parse": "parse",
    "layout": "layout",
    "ocr": "ocr",
    "classify": "classify",
    "split": "split",
    "tables_extract": "tables",
    "equations_extract": "equations",
    "charts_describe": "charts",
    "schema_auto": "schema_auto",
    "extract": "extract",
    "chat_single": "chat_single",
    "chat_multi": "chat_multi",
}


def _resolve_tools(
    client: Any,
    *,
    provider: str,
    tool_names: list[str] | None = None,
) -> AgentToolBundle:
    selected_names = list(tool_names or _TOOL_MODEL_BY_NAME)
    tools: list[dict[str, Any]] = []
    handlers: dict[str, Callable[[Mapping[str, Any]], Any]] = {}

    available_tools = {tool.name: tool for tool in client.agents.tools().tools}
    for name in selected_names:
        request_model = _TOOL_MODEL_BY_NAME.get(name)
        method_name = _CLIENT_METHOD_BY_TOOL_NAME.get(name)
        public_tool = available_tools.get(name)
        if request_model is None or method_name is None or public_tool is None:
            raise ValueError(f"Unknown Docspeed tool name: {name}")

        schema = request_model.model_json_schema(by_alias=True)
        if provider == "openai":
            tool_payload = {
                "type": "function",
                "name": name,
                "description": public_tool.description,
                "parameters": schema,
            }
        elif provider == "anthropic":
            tool_payload = {
                "name": name,
                "description": public_tool.description,
                "input_schema": schema,
            }
        else:
            raise ValueError(f"Unsupported provider: {provider}")

        method = getattr(client, method_name)

        def _bound_handler(
            payload: Mapping[str, Any],
            *,
            _method: Callable[[Mapping[str, Any]], Any] = method,
            _model: type[models.BaseModel] = request_model,
        ) -> Any:
            validated = _model.model_validate(payload)
            return _method(validated.model_dump(mode="python", by_alias=True, exclude_none=True))

        tools.append(tool_payload)
        handlers[name] = _bound_handler
    return AgentToolBundle(tools=tools, handlers=handlers)


def openai(client: Any, tool_names: list[str] | None = None) -> AgentToolBundle:
    return _resolve_tools(client, provider="openai", tool_names=tool_names)


def anthropic(client: Any, tool_names: list[str] | None = None) -> AgentToolBundle:
    return _resolve_tools(client, provider="anthropic", tool_names=tool_names)
