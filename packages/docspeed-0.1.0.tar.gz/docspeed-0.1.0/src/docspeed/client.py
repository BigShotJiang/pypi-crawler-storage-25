from __future__ import annotations

import asyncio
import mimetypes
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Iterator, Mapping, TypeVar

import httpx
from pydantic import BaseModel

from . import models
from .exceptions import (
    DocspeedAPIError,
    DocspeedConfigError,
    DocspeedJobError,
    DocspeedJobTimeoutError,
    DocspeedTransportError,
)


DEFAULT_BASE_URL = "https://docspeed.ai"
DEFAULT_TIMEOUT = 300.0

ModelT = TypeVar("ModelT", bound=BaseModel)


@dataclass(frozen=True)
class PageImageResult:
    content: bytes
    content_type: str | None


@dataclass
class _UploadHandle:
    file_name: str
    content_type: str
    file_obj: BinaryIO
    should_close: bool


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def _parse_error_payload(response: httpx.Response) -> DocspeedAPIError:
    try:
        raw_body = response.json()
    except ValueError:
        raw_body = response.text
    detail = raw_body.get("detail") if isinstance(raw_body, dict) else None
    if isinstance(detail, dict):
        code = str(detail.get("code") or "").strip() or None
        message = str(detail.get("message") or response.reason_phrase or "Docspeed API request failed")
        details = detail.get("details")
        if not isinstance(details, dict):
            details = {}
        return DocspeedAPIError(
            message,
            status_code=response.status_code,
            code=code,
            details=details,
            raw_body=raw_body,
        )
    if isinstance(detail, str):
        message = detail
    elif isinstance(raw_body, dict) and isinstance(raw_body.get("error"), str):
        message = raw_body["error"]
    else:
        message = response.text or response.reason_phrase or "Docspeed API request failed"
    return DocspeedAPIError(message, status_code=response.status_code, raw_body=raw_body)


def _validate_model(payload: BaseModel | Mapping[str, Any], model_cls: type[ModelT]) -> ModelT:
    if isinstance(payload, BaseModel):
        return model_cls.model_validate(payload.model_dump(mode="python", by_alias=True, exclude_none=True))
    return model_cls.model_validate(dict(payload))


def _dump_request(payload: BaseModel | Mapping[str, Any], model_cls: type[BaseModel]) -> dict[str, Any]:
    validated = _validate_model(payload, model_cls)
    return validated.model_dump(mode="json", by_alias=True, exclude_none=True)


def _validate_response(payload: Any, model_cls: type[ModelT]) -> ModelT:
    return model_cls.model_validate(payload)


def _is_job_payload(payload: Any) -> bool:
    return isinstance(payload, dict) and {"job_id", "status", "execution_mode", "operation"} <= set(payload)


@contextmanager
def _open_upload_handle(path_or_file: str | Path | BinaryIO) -> Iterator[_UploadHandle]:
    if isinstance(path_or_file, (str, Path)):
        upload_path = Path(path_or_file).expanduser()
        file_obj = upload_path.open("rb")
        try:
            yield _UploadHandle(
                file_name=upload_path.name,
                content_type=mimetypes.guess_type(upload_path.name)[0] or "application/octet-stream",
                file_obj=file_obj,
                should_close=True,
            )
        finally:
            file_obj.close()
        return

    file_name = Path(getattr(path_or_file, "name", "upload.bin")).name
    yield _UploadHandle(
        file_name=file_name,
        content_type=mimetypes.guess_type(file_name)[0] or "application/octet-stream",
        file_obj=path_or_file,
        should_close=False,
    )


class _BaseClient:
    def __init__(
        self,
        *,
        api_key: str | None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        request_id: str | None = None,
    ) -> None:
        if not api_key:
            raise DocspeedConfigError("Docspeed API key is required.")
        self.api_key = api_key
        self.base_url = _normalize_base_url(base_url)
        self.timeout = timeout
        self.request_id = request_id

    def _headers(self, *, request_id: str | None = None) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.api_key}"}
        resolved_request_id = request_id or self.request_id
        if resolved_request_id:
            headers["X-Request-Id"] = resolved_request_id
        return headers


class _SyncBase(_BaseClient):
    def __init__(
        self,
        *,
        api_key: str | None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        request_id: str | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout, request_id=request_id)
        self._owns_client = http_client is None
        self._http = http_client or httpx.Client(base_url=self.base_url, timeout=self.timeout)

    def close(self) -> None:
        if self._owns_client:
            self._http.close()

    def __enter__(self) -> "_SyncBase":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        headers = dict(kwargs.pop("headers", {}) or {})
        request_id = kwargs.pop("request_id", None)
        headers.update(self._headers(request_id=request_id))
        try:
            response = self._http.request(method, path, headers=headers, **kwargs)
        except httpx.HTTPError as exc:
            raise DocspeedTransportError(str(exc)) from exc
        if response.is_error:
            raise _parse_error_payload(response)
        return response

    def _request_json(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        response = self._request(method, path, **kwargs)
        try:
            payload = response.json()
        except ValueError as exc:
            raise DocspeedTransportError("Docspeed API returned non-JSON output.") from exc
        if not isinstance(payload, dict):
            raise DocspeedTransportError("Docspeed API returned an unexpected JSON payload.")
        return payload

    def _post_model(self, path: str, payload: BaseModel | Mapping[str, Any], request_model: type[BaseModel], response_model: type[ModelT]) -> ModelT:
        body = _dump_request(payload, request_model)
        data = self._request_json("POST", path, json=body)
        return _validate_response(data, response_model)

    def _post_operation(
        self,
        path: str,
        payload: BaseModel | Mapping[str, Any],
        request_model: type[BaseModel],
        response_model: type[ModelT],
    ) -> ModelT | models.JobRef:
        body = _dump_request(payload, request_model)
        data = self._request_json("POST", path, json=body)
        if _is_job_payload(data):
            return models.JobRef.model_validate(data)
        return _validate_response(data, response_model)


class _AsyncBase(_BaseClient):
    def __init__(
        self,
        *,
        api_key: str | None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        request_id: str | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout, request_id=request_id)
        self._owns_client = http_client is None
        self._http = http_client or httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout)

    async def aclose(self) -> None:
        if self._owns_client:
            await self._http.aclose()

    async def __aenter__(self) -> "_AsyncBase":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        headers = dict(kwargs.pop("headers", {}) or {})
        request_id = kwargs.pop("request_id", None)
        headers.update(self._headers(request_id=request_id))
        try:
            response = await self._http.request(method, path, headers=headers, **kwargs)
        except httpx.HTTPError as exc:
            raise DocspeedTransportError(str(exc)) from exc
        if response.is_error:
            raise _parse_error_payload(response)
        return response

    async def _request_json(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        response = await self._request(method, path, **kwargs)
        try:
            payload = response.json()
        except ValueError as exc:
            raise DocspeedTransportError("Docspeed API returned non-JSON output.") from exc
        if not isinstance(payload, dict):
            raise DocspeedTransportError("Docspeed API returned an unexpected JSON payload.")
        return payload

    async def _post_model(
        self,
        path: str,
        payload: BaseModel | Mapping[str, Any],
        request_model: type[BaseModel],
        response_model: type[ModelT],
    ) -> ModelT:
        body = _dump_request(payload, request_model)
        data = await self._request_json("POST", path, json=body)
        return _validate_response(data, response_model)

    async def _post_operation(
        self,
        path: str,
        payload: BaseModel | Mapping[str, Any],
        request_model: type[BaseModel],
        response_model: type[ModelT],
    ) -> ModelT | models.JobRef:
        body = _dump_request(payload, request_model)
        data = await self._request_json("POST", path, json=body)
        if _is_job_payload(data):
            return models.JobRef.model_validate(data)
        return _validate_response(data, response_model)


class SyncFilesResource:
    def __init__(self, client: "Docspeed") -> None:
        self._client = client

    def upload(self, path_or_file: str | Path | BinaryIO, *, request_id: str | None = None) -> models.FileRef:
        with _open_upload_handle(path_or_file) as upload:
            payload = self._client._request_json(
                "POST",
                "/v1/files",
                files={"file": (upload.file_name, upload.file_obj, upload.content_type)},
                request_id=request_id,
            )
        return models.FileRef.model_validate(payload)

    def get(self, file_id: str, *, request_id: str | None = None) -> models.FileRef:
        payload = self._client._request_json("GET", f"/v1/files/{file_id}", request_id=request_id)
        return models.FileRef.model_validate(payload)

    def page_image(self, file_id: str, page_index: int, *, request_id: str | None = None) -> PageImageResult:
        response = self._client._request("GET", f"/v1/files/{file_id}/pages/{page_index}/image", request_id=request_id)
        return PageImageResult(content=response.content, content_type=response.headers.get("content-type"))


class AsyncFilesResource:
    def __init__(self, client: "AsyncDocspeed") -> None:
        self._client = client

    async def upload(self, path_or_file: str | Path | BinaryIO, *, request_id: str | None = None) -> models.FileRef:
        with _open_upload_handle(path_or_file) as upload:
            payload = await self._client._request_json(
                "POST",
                "/v1/files",
                files={"file": (upload.file_name, upload.file_obj, upload.content_type)},
                request_id=request_id,
            )
        return models.FileRef.model_validate(payload)

    async def get(self, file_id: str, *, request_id: str | None = None) -> models.FileRef:
        payload = await self._client._request_json("GET", f"/v1/files/{file_id}", request_id=request_id)
        return models.FileRef.model_validate(payload)

    async def page_image(self, file_id: str, page_index: int, *, request_id: str | None = None) -> PageImageResult:
        response = await self._client._request("GET", f"/v1/files/{file_id}/pages/{page_index}/image", request_id=request_id)
        return PageImageResult(content=response.content, content_type=response.headers.get("content-type"))


class SyncJobsResource:
    def __init__(self, client: "Docspeed") -> None:
        self._client = client

    def get(self, job_id: str, *, request_id: str | None = None) -> models.JobRef:
        payload = self._client._request_json("GET", f"/v1/jobs/{job_id}", request_id=request_id)
        return models.JobRef.model_validate(payload)

    def result(self, job_id: str, *, request_id: str | None = None) -> dict[str, Any]:
        return self._client._request_json("GET", f"/v1/jobs/{job_id}/result", request_id=request_id)

    def wait(
        self,
        job_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 600.0,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while True:
            job = self.get(job_id, request_id=request_id)
            if job.status == "completed":
                return self.result(job_id, request_id=request_id)
            if job.status == "failed":
                result_payload = self.result(job_id, request_id=request_id)
                raise DocspeedJobError(job_id, job.status, str(result_payload.get("error") or "Unknown job failure"))
            if time.monotonic() >= deadline:
                raise DocspeedJobTimeoutError(job_id, job.status, "Timed out while waiting for job result.")
            time.sleep(poll_interval)


class AsyncJobsResource:
    def __init__(self, client: "AsyncDocspeed") -> None:
        self._client = client

    async def get(self, job_id: str, *, request_id: str | None = None) -> models.JobRef:
        payload = await self._client._request_json("GET", f"/v1/jobs/{job_id}", request_id=request_id)
        return models.JobRef.model_validate(payload)

    async def result(self, job_id: str, *, request_id: str | None = None) -> dict[str, Any]:
        return await self._client._request_json("GET", f"/v1/jobs/{job_id}/result", request_id=request_id)

    async def wait(
        self,
        job_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 600.0,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while True:
            job = await self.get(job_id, request_id=request_id)
            if job.status == "completed":
                return await self.result(job_id, request_id=request_id)
            if job.status == "failed":
                result_payload = await self.result(job_id, request_id=request_id)
                raise DocspeedJobError(job_id, job.status, str(result_payload.get("error") or "Unknown job failure"))
            if time.monotonic() >= deadline:
                raise DocspeedJobTimeoutError(job_id, job.status, "Timed out while waiting for job result.")
            await asyncio.sleep(poll_interval)


class SyncAgentsResource:
    def __init__(self, client: "Docspeed") -> None:
        self._client = client

    def tools(self, *, request_id: str | None = None) -> models.AgentToolsResponse:
        payload = self._client._request_json("GET", "/v1/agents/tools", request_id=request_id)
        return models.AgentToolsResponse.model_validate(payload)

    def create(
        self,
        payload: models.AgentCreateRequest | Mapping[str, Any],
        *,
        request_id: str | None = None,
    ) -> models.AgentCreateResponse:
        body = _dump_request(payload, models.AgentCreateRequest)
        data = self._client._request_json("POST", "/v1/agents", json=body, request_id=request_id)
        return models.AgentCreateResponse.model_validate(data)


class AsyncAgentsResource:
    def __init__(self, client: "AsyncDocspeed") -> None:
        self._client = client

    async def tools(self, *, request_id: str | None = None) -> models.AgentToolsResponse:
        payload = await self._client._request_json("GET", "/v1/agents/tools", request_id=request_id)
        return models.AgentToolsResponse.model_validate(payload)

    async def create(
        self,
        payload: models.AgentCreateRequest | Mapping[str, Any],
        *,
        request_id: str | None = None,
    ) -> models.AgentCreateResponse:
        body = _dump_request(payload, models.AgentCreateRequest)
        data = await self._client._request_json("POST", "/v1/agents", json=body, request_id=request_id)
        return models.AgentCreateResponse.model_validate(data)


class Docspeed(_SyncBase):
    def __init__(
        self,
        *,
        api_key: str | None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        request_id: str | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout, request_id=request_id, http_client=http_client)
        self.files = SyncFilesResource(self)
        self.jobs = SyncJobsResource(self)
        self.agents = SyncAgentsResource(self)

    def parse(self, payload: models.ParseRequest | Mapping[str, Any]) -> models.ParseResponse | models.JobRef:
        return self._post_operation("/v1/parse", payload, models.ParseRequest, models.ParseResponse)

    def layout(self, payload: models.LayoutRequest | Mapping[str, Any]) -> models.LayoutResponse | models.JobRef:
        return self._post_operation("/v1/layout", payload, models.LayoutRequest, models.LayoutResponse)

    def ocr(self, payload: models.OcrRequest | Mapping[str, Any]) -> models.OcrResponse | models.JobRef:
        return self._post_operation("/v1/ocr", payload, models.OcrRequest, models.OcrResponse)

    def classify(self, payload: models.ClassifyRequest | Mapping[str, Any]) -> models.ClassificationResult | models.JobRef:
        return self._post_operation("/v1/classify", payload, models.ClassifyRequest, models.ClassificationResult)

    def split(self, payload: models.SplitRequest | Mapping[str, Any]) -> models.SplitPlan | models.JobRef:
        return self._post_operation("/v1/split", payload, models.SplitRequest, models.SplitPlan)

    def tables(self, payload: models.TableExtractRequest | Mapping[str, Any]) -> models.TableExtractResponse | models.JobRef:
        return self._post_operation("/v1/tables", payload, models.TableExtractRequest, models.TableExtractResponse)

    def equations(self, payload: models.EquationExtractRequest | Mapping[str, Any]) -> models.EquationExtractResponse | models.JobRef:
        return self._post_operation("/v1/equations", payload, models.EquationExtractRequest, models.EquationExtractResponse)

    def charts(self, payload: models.ChartDescribeRequest | Mapping[str, Any]) -> models.ChartDescribeResponse | models.JobRef:
        return self._post_operation("/v1/charts", payload, models.ChartDescribeRequest, models.ChartDescribeResponse)

    def schema_auto(self, payload: models.SchemaAutoRequest | Mapping[str, Any]) -> models.SchemaAutoResponse | models.JobRef:
        return self._post_operation("/v1/schema/auto", payload, models.SchemaAutoRequest, models.SchemaAutoResponse)

    def extract(self, payload: models.ExtractRequest | Mapping[str, Any]) -> models.ExtractionResult | models.JobRef:
        return self._post_operation("/v1/extract", payload, models.ExtractRequest, models.ExtractionResult)

    def chat_single(self, payload: models.ChatSingleRequest | Mapping[str, Any]) -> models.ChatAnswer | models.JobRef:
        return self._post_operation("/v1/chat/single", payload, models.ChatSingleRequest, models.ChatAnswer)

    def chat_multi(self, payload: models.ChatMultiRequest | Mapping[str, Any]) -> models.ChatMultiResponse | models.JobRef:
        return self._post_operation("/v1/chat/multi", payload, models.ChatMultiRequest, models.ChatMultiResponse)


class AsyncDocspeed(_AsyncBase):
    def __init__(
        self,
        *,
        api_key: str | None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        request_id: str | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout, request_id=request_id, http_client=http_client)
        self.files = AsyncFilesResource(self)
        self.jobs = AsyncJobsResource(self)
        self.agents = AsyncAgentsResource(self)

    async def parse(self, payload: models.ParseRequest | Mapping[str, Any]) -> models.ParseResponse | models.JobRef:
        return await self._post_operation("/v1/parse", payload, models.ParseRequest, models.ParseResponse)

    async def layout(self, payload: models.LayoutRequest | Mapping[str, Any]) -> models.LayoutResponse | models.JobRef:
        return await self._post_operation("/v1/layout", payload, models.LayoutRequest, models.LayoutResponse)

    async def ocr(self, payload: models.OcrRequest | Mapping[str, Any]) -> models.OcrResponse | models.JobRef:
        return await self._post_operation("/v1/ocr", payload, models.OcrRequest, models.OcrResponse)

    async def classify(self, payload: models.ClassifyRequest | Mapping[str, Any]) -> models.ClassificationResult | models.JobRef:
        return await self._post_operation("/v1/classify", payload, models.ClassifyRequest, models.ClassificationResult)

    async def split(self, payload: models.SplitRequest | Mapping[str, Any]) -> models.SplitPlan | models.JobRef:
        return await self._post_operation("/v1/split", payload, models.SplitRequest, models.SplitPlan)

    async def tables(self, payload: models.TableExtractRequest | Mapping[str, Any]) -> models.TableExtractResponse | models.JobRef:
        return await self._post_operation("/v1/tables", payload, models.TableExtractRequest, models.TableExtractResponse)

    async def equations(self, payload: models.EquationExtractRequest | Mapping[str, Any]) -> models.EquationExtractResponse | models.JobRef:
        return await self._post_operation("/v1/equations", payload, models.EquationExtractRequest, models.EquationExtractResponse)

    async def charts(self, payload: models.ChartDescribeRequest | Mapping[str, Any]) -> models.ChartDescribeResponse | models.JobRef:
        return await self._post_operation("/v1/charts", payload, models.ChartDescribeRequest, models.ChartDescribeResponse)

    async def schema_auto(self, payload: models.SchemaAutoRequest | Mapping[str, Any]) -> models.SchemaAutoResponse | models.JobRef:
        return await self._post_operation("/v1/schema/auto", payload, models.SchemaAutoRequest, models.SchemaAutoResponse)

    async def extract(self, payload: models.ExtractRequest | Mapping[str, Any]) -> models.ExtractionResult | models.JobRef:
        return await self._post_operation("/v1/extract", payload, models.ExtractRequest, models.ExtractionResult)

    async def chat_single(self, payload: models.ChatSingleRequest | Mapping[str, Any]) -> models.ChatAnswer | models.JobRef:
        return await self._post_operation("/v1/chat/single", payload, models.ChatSingleRequest, models.ChatAnswer)

    async def chat_multi(self, payload: models.ChatMultiRequest | Mapping[str, Any]) -> models.ChatMultiResponse | models.JobRef:
        return await self._post_operation("/v1/chat/multi", payload, models.ChatMultiRequest, models.ChatMultiResponse)
