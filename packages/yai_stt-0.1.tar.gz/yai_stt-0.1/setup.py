from setuptools import setup,find_packages
setup(
    name = "yai-STT",
    version = '0.1',
    author= 'Yasirpahadi',
    author_email= 'yas@gmail.com',
    description= 'this is speech to text pakcage created by ysirpahadi'
)
packages = find_packages(),
install_requirement = [
    'selenium',
    'webdriver_manager'
]

