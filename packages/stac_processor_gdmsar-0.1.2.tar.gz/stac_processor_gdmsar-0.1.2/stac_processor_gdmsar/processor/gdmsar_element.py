import abc
import logging
import os
import pystac

from stac_processor_gdmsar.explorer import make_explorer
import stac_processor_gdmsar.metadata.common_metadata as metadata

logger = logging.getLogger(__name__)

class GDMElement(metaclass=abc.ABCMeta):
    main_id: str = None # the id of the root element, which is used in all the child elements
    stac_id: str = None # the id that will be given to the stac object
    title: str = None
    file_name: str = None # the name of the file, with the json extension
    folder_name: str = None # the name of the folder where the stac file will be saved, without the path
    processing_id: str = None # this id comes from a field in the json files
    keywords: list[str] = None # will be loaded from the templates files
    stac_object: pystac.Item | pystac.Collection | pystac.Catalog = None # will be created in the to_stac function, and will contain the final stac object to be saved as a json file
    href: str = None

    def add_common_links(self):
        if self.stac_object is not None:
            for publication in metadata.publications:
                self.stac_object.add_link(pystac.Link(rel="cite-as", target=publication["href"]))
            self.stac_object.add_link(pystac.Link(rel="license", target=metadata.license_href))

    def link_to(self, relation: str, target: "GDMElement", target_relation: str = None):
        if self.stac_object is not None and target.stac_object is not None:
            link = pystac.Link(
                rel=relation, 
                target=target.stac_object.get_self_href() if target_relation is None else target_relation, 
                title=target.title, 
                media_type="application/json"
            )
            self.stac_object.add_link(link)

    def set_href(self, base_path: str):
        directory = f"{base_path}/{self.folder_name}" if base_path != "" else self.folder_name
        stac_path = f"{directory}/{self.file_name}"
        self.stac_object.set_self_href(stac_path)

    def write_stac_file(self, import_assets: bool = False):
        if self.stac_object is not None:
            stac_path = self.stac_object.get_self_href()
            directory = os.path.dirname(stac_path)
            os.makedirs(directory, exist_ok=True)
            # import the assets if needed, and update the href of the assets to point to the new location
            if import_assets:
                for asset_key in self.stac_object.assets:
                    asset = self.stac_object.assets[asset_key]
                    if asset.media_type != "text/html":
                        explorer = make_explorer(asset.href)
                        asset_name = os.path.basename(asset.href)
                        os.makedirs(f"{directory}/assets", exist_ok=True)
                        explorer.copy(asset.href, f"{directory}/assets/{asset_name}")
                        asset.href = f"assets/{asset_name}"
            # save the stac file
            if isinstance(self.stac_object, pystac.Item):
                self.stac_object.save_object(include_self_link=False) # for items, we need to remove the self link because it is not correct after saving the file, and it creates a problem when writing the file
            else:
                self.stac_object.save(catalog_type=pystac.CatalogType.SELF_CONTAINED,)

