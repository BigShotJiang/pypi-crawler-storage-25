import logging
import os
import shutil
import tempfile
from stac_processor_gdmsar.discover import get_uuid
from stac_processor_gdmsar.explorer import make_explorer
from pystac import Asset
from stac_processor_gdmsar.processor.gdmsar_collection import GDMCollection
from stac_processor_gdmsar.processor.gdmsar_geo import GDMGeo
from stac_processor_gdmsar.processor.gdmsar_radar import GDMRadar

logger = logging.getLogger(__name__)

def process(product_source: str, import_assets: bool = False) -> str:
    # process the product source, and return the path of the corresponding STAC collection in a temporary directory
    # make sure that the source URL ends with a slash
    if not product_source.endswith("/"):
        product_source += "/"
    # the source can either be a local directory, or a URL.
    explorer = make_explorer(product_source)
    # creates a temporary directory where the STAC files will be saved
    processed_artifact_dir = tempfile.mkdtemp()
    # os.chdir(processed_artifact_dir)

    try:
        # get the UUID of the product source, contained in the product source path
        uuid = get_uuid(product_source)
        logger.debug(f"Processing product source {product_source} with UUID {uuid}")
        # create a directory with the name of the UUID in the temporary directory
        uuid_dir = explorer.join(processed_artifact_dir, uuid)
        os.makedirs(uuid_dir, exist_ok=True)
        # os.chdir(uuid_dir)
        # list every files available in the source, without any filters
        files = []
        for file_name in explorer.list_dir(product_source):
            file = explorer.join(product_source, file_name)
            files.append(file)
        # search for the main id in the json files
        main_id = uuid
        for file in files:
            if file.endswith(".json"):
                json_content = explorer.load_json(file)
                if "id" in json_content and json_content["id"] is not None and json_content["id"] != "":
                    main_id = json_content["id"]
                    break
        logger.debug(f"Main ID is {main_id}, with {len(files)} files found in the product source")
        # TODO also create the root catalog, unless there is already one?
        # parse each json file one by one, create the STAC files and mkdir -p on the fly
        collection = GDMCollection(
            main_id=main_id,
            folder_name=uuid, files=files,
            # title_suffix="", # none, because it is the main collection
            title=main_id,
            codes=["run"], geometry="", # used to select the correct assets
            templates=["run_collection.md"], # templates provide a description and a list of keywords (represented as **{keyword}** in the md file).
            child_collections=[
                GDMGeo(main_id, files), 
                GDMRadar(main_id, files) 
            ])
        # add extra assets
        extra_assets = {
            "download": Asset(f"https://formater.osug.fr/download/gdm-sar-permanent/{uuid}",  title="Download source product", description="Link to the download page for the original source product, before STAC conversion.", media_type="text/html",  roles=["metadata"]),
            "documentation": Asset("https://formater.pages.in2p3.fr/flatsim/product.html",  title="Product description (general for NSBAS, including GDM-SAR-In and FLATSIM)", 
                description="Documentation page describing the product names and acronyms, information about the generation of the products, and metadata definitions.", media_type="text/html",  roles=["metadata"])
        }
        collection.add_extra_assets(extra_assets)
        # logger.debug(f"Main STAC collection {collection.stac_id} has been created")
        # update the stac objects to create links between them, and to set the correct hrefs for the assets
        collection.update_stac(processed_artifact_dir)
        # summarize the collection after updating the stac objects, to be sure that the summaries are consistent with the keywords of all the stac objects
        collection.summarize()
        # write all the stac files recursively
        logger.debug(f"Generating STAC files for the collection '{main_id}' in {uuid_dir}")
        collection.generate_stac_files(import_assets=import_assets)
        logger.debug(f"STAC files successfully generated for the collection '{main_id}'")

    except Exception as error:
        # if any error occurs during the processing, we need to clean the temporary directory before raising the error
        os.chdir("/tmp")
        shutil.rmtree(processed_artifact_dir)
        raise error

    # return the path of the temporary directory where the STAC collection has been saved
    return processed_artifact_dir