import logging
import os
import re
from pystac import Asset, MediaType
from stac_processor_gdmsar.processor.utils import load_json
from stac_processor_gdmsar.explorer import is_local

logger = logging.getLogger(__name__)

class Product:
    def __init__(self, code: str, geometry: str, regex: str, title: str, template: str = ""):
        self.code = code
        self.geometry = geometry
        self.regex = regex
        self.title = title
        self.template = template

# most of these information come from https://formater.pages.in2p3.fr/flatsim/product.html
products = [
    # Products from the interferogram package
    Product("InW", "WGS84", "_InW_geo_", "Wrapped Differential Interferograms in WGS84 geometry", "wrapped_interferogram.md"),
    Product("InW", "RADAR", "_InW_radar_", "Wrapped Differential Interferograms in radar geometry", "wrapped_interferogram.md"),
    Product("InWF", "WGS84", "_InWF_geo_", "Filtered Wrapped Differential Interferograms in WGS84 geometry", "filtered_wrapped_interferogram.md"),
    Product("InWF", "RADAR", "_InWF_radar_", "Filtered Wrapped Differential Interferograms in radar geometry", "filtered_wrapped_interferogram.md"),
    Product("APS", "WGS84", "_APS_geo_", "Interferogram Atmospheric Phase Screen from Global Atmospheric Model in WGS84 geometry", "atmospheric_phase_screen.md"),
    Product("APS", "RADAR", "_APS_radar_", "Interferogram Atmospheric Phase Screen from Global Atmospheric Model in radar geometry", "atmospheric_phase_screen.md"),
    Product("COH", "WGS84", "_Coh_geo_", "Spatial coherence in WGS84 geometry", "spatial_coherence.md"),
    Product("COH", "RADAR", "_Coh_radar_", "Spatial coherence in radar geometry", "spatial_coherence.md"),
    Product("INU", "WGS84", "_INU_geo_", "Unwrapped Differential Interferograms in WGS84 geometry", "unwrapped_interferogram.md"),
    Product("INU", "RADAR", "_INU_radar_", "Unwrapped Differential Interferograms in radar geometry", "unwrapped_interferogram.md"),
    # Products from the time-serie package
    Product("DTs_LOS", "WGS84", "_DTs_geo_", "Time series", "los_displacement_time_series.md"),
    Product("DTs_LOS", "RADAR", "_DTs_radar_", "Time series", "los_displacement_time_series.md"),
    Product("geo_TOT", "WGS84", "_geo_TOT_", "Preview for time series per date"),
    Product("MV-LOS", "WGS84", "_MV-LOS_geo_", "Mean LOS velocity", "mean_velocity_map.md"),
    Product("MV-LOS", "RADAR", "_MV-LOS_radar_", "Mean LOS velocity", "mean_velocity_map.md"),
    Product("Net", "WGS84", "_Net_geo_", "Network misclosure (Quality of times series inversion)", "network_misclosures.md"),
    Product("Net", "RADAR", "_Net_radar_", "Network misclosure (Quality of times series inversion)", "network_misclosures.md"),
    Product("Stk-In", "WGS84", "Stk-In_list_InU", "Stack of coregistered Interferograms"),
    Product("Stk-In", "RADAR", "Stk-In_list_InW", "Stack of coregistered Interferograms"),
    # Products from the auxiliary data package
    Product("LuT", "WGS84", "_LuT_geo_", "Lookup tables to pass from radar to ground geometry and vice versa", "lookup_table_sat_to_ground_coordinates.md"),
    Product("LuT", "RADAR", "_LuT_radar_", "Lookup tables to pass from radar to ground geometry and vice versa", "lookup_table_sat_to_ground_coordinates.md"),
    Product("CosNEU", "WGS84", "_CosNEU_geo_", "Map of LOS vector (NEU coefficient): convention: LOS vector is positive away from satellite to ground", "map_of_los_vector_neu.md"),
    Product("CosNEU", "RADAR", "_CosNEU_radar_", "Map of LOS vector (NEU coefficient): convention: LOS vector is positive away from satellite to ground", "map_of_los_vector_neu.md"),
    Product("CosENU", "WGS84", "_CosENU_geo_", "Map of LOS vector (ENU coefficient): convention: LOS vector is positive away from ground to satellite", "map_of_los_vector_enu.md"),
    Product("CosENU", "RADAR", "_CosENU_radar_", "Map of LOS vector (ENU coefficient): convention: LOS vector is positive away from ground to satellite", "map_of_los_vector_enu.md"),
    Product("DEM", "WGS84", "_DEM_geo_", "Digital Elevation Model", "digital_elevation_model.md"),
    Product("DEM", "RADAR", "_DEM_radar_", "Digital Elevation Model", "digital_elevation_model.md"),
    Product("TCoh", "WGS84", "_TCoh_geo_", "Temporal Coherence (Quality of measure)", "temporal_coherence.md"),
    Product("TCoh", "RADAR", "_TCoh_radar_", "Temporal Coherence (Quality of measure)", "temporal_coherence.md"),
    # Root collection assets
    Product("run", "", "nsbas.proc", "NSBAS run parameters"),
    Product("run", "", "interf_pair", "Interferogram Pair"),
    Product("run", "", "baseline.rsc", "Baseline Parameters"),
    Product("run", "", "baseline_top_bot.rsc", "Baseline Top-Bottom Parameters"),
    Product("run", "", "plot_time_lat_", "Time-Latitude Plot"),
    Product("run", "", "plot_interferograms", "Interferogram Plot"),
    Product("run", "", "orb_types", "Orbit Types"),
    Product("run", "", "success_coreg.txt", "Coregistration Success"),
    # Extra txt files
    Product("extra", "RADAR", "_interfero_spectraldiversity_", "Interferogram Spectral Diversity"),
    Product("extra", "RADAR", "_merge_", "Merged subswaths"),
    Product("extra", "RADAR", "success_coreg_", "Coregistration Success"),
    Product("extra", "RADAR", "liste_refer.txt", "Reference List"),
    Product("extra", "RADAR", "Stack_list_InW_", "Stack List InW"),
    Product("extra", "RADAR", "list_unw_frac", "Unwrapped Fraction List"),
    # Inversion parameters
    Product("inversion", "RADAR", "RMSdate.txt", "Inversion Parameter: RMS date"),
    Product("inversion", "RADAR", "RMSinterfero.txt", "Inversion Parameter: RMS interferogram"),
    Product("inversion", "RADAR", "Input_parameter_for_TS.txt", "Inversion Parameter: Input parameters for time series inversion")
]

def read_template(template_name: str, _id: str = "", _geometry: str = "", _processing_id: str = "", date: str = "") -> str:
    # some products may not have a template, in this case we return an empty description
    if template_name == "": return ""
    if os.path.exists(template_name):
        # this allows to use this function with a specific template file, useful for testing
        file = template_name
    else:
        # create an absolute path to the template file, even if the current working directory is different, and read the content of the file
        file = os.path.join(os.path.dirname(__file__), "..", "templates", template_name)
        if not file.endswith(".md"): file += ".md"
    # open the template file, read the content, and replace the variables by the corresponding values
    if os.path.exists(file):
        with open(file) as f:
            content = f.read()
            # the content may contain variables, surrounded by double curly brackets, that should be replaced by the corresponding values
            content = content.replace("{{id}}", _id)
            # if _geometry == "": _geometry = "unknown geometry"
            if _geometry != "": content = content.replace("{{geometry}}", _geometry)
            if _processing_id != "": content = content.replace("{{processing.id}}", _processing_id)
            # date_from, date_to = date.split("_") if "_" in date else ("unknown", "unknown")
            if "_" in date:
                date_from, date_to = date.split("_")
                content = content.replace("{{from}}", date_from)
                content = content.replace("{{to}}", date_to)
            if "{{" in content or "}}" in content:
                logger.warning(f"Template file {file} contains unreplaced variables, check the template and the code that replaces the variables.")
            return content
    logger.warning(f"Template file {file} not found, returning an empty description.")
    return ""

def get_product(file: str) -> Product | None:
    for product in products:
        if product.regex.lower() in file.lower():
            return product
    return None

def get_title(code: str, geometry: str) -> str:
    for product in products:
        if product.code.lower() == code.lower() and product.geometry.lower() == geometry.lower():
            return product.title
    logger.warning(f"No product found for code {code} and geometry {geometry}, returning 'Unknown' as title.")
    return "Unknown"

def get_description(code: str, geometry: str, _id: str = "", _processing_id: str = "", date: str = "") -> str:
    for product in products:
        if product.code.lower() == code.lower() and product.geometry.lower() == geometry.lower():
            return read_template(product.template, _id, geometry, _processing_id, date)
    logger.warning(f"No product found for code {code} and geometry {geometry}, returning an empty description.")
    return ""

def is_in_list(string: str, list: list[str]) -> bool:
    for element in list:
        if element.lower() == string.lower():
            return True
    return False

def get_matching_product(file: str, codes: list[str], geometry: str, _date: str = "", _resolution: str = "") -> Product | None:
    # get the product corresponding to the file
    product = get_product(file)
    if not product: return None
    # test for each field if it is not empty
    if not is_in_list(product.code, codes): return None
    if product.geometry.lower() != geometry.lower(): return None
    # date and resolution are optional, if they are not empty, they should be in the file name
    if _date != "" and _date.lower() not in file.lower(): return None
    if _resolution != "" and _resolution.lower() not in file.lower(): return None
    return product

def get_keywords_from_template(template_name: str, _id: str = "", _geometry: str = "", _processing_id: str = "", date: str = "") -> list:
    description = read_template(template_name, _id, _geometry, _processing_id, date)
    keywords = re.findall(r"\*\*(.*?)\*\*", description)
    return keywords

def get_keywords(files: list[str], codes: list[str], geometry: str, default_keywords: list[str] = None, _id: str = "", _processing_id: str = "", date: str = "") -> list:
    found_keywords = set()
    # add default keywords if any
    if default_keywords:
        found_keywords.update(default_keywords)
    # keywords based on elements in the file name
    for file in files:
        if get_matching_product(file, codes, geometry):
            # resolution
            match = re.search(r'_(\d+)rlks', file)
            if match: found_keywords.add(f"resolution_{match.group(1)}looks")
    # keywords based on templates
    for product in products:
        if is_in_list(product.code, codes) and product.geometry.lower() == geometry.lower():
            keywords = get_keywords_from_template(product.template, _id=_id, _geometry=geometry, _processing_id=_processing_id, date=date)
            found_keywords.update(keywords)
    return list(found_keywords)

def get_mime_type(file: str) -> str:
    # if the file does not have an extension, return application/octet-stream
    if "." not in file: return "application/octet-stream"
    # get the extension of the file
    extension = file.split(".")[-1].lower()
    # return the corresponding media type based on the extension
    if extension == "flatgeobuf" or extension == "fgb": return MediaType.FLATGEOBUF
    elif extension == "geojson": return MediaType.GEOJSON
    elif extension == "gpkg": return MediaType.GEOPACKAGE
    elif extension == "tif" or extension == "tiff": return MediaType.GEOTIFF
    elif extension == "hdf": return MediaType.HDF
    elif extension == "hdf5": return MediaType.HDF5
    elif extension == "html": return MediaType.HTML
    elif extension == "jpg" or extension == "jpeg": return MediaType.JPEG
    elif extension == "jp2": return MediaType.JPEG2000
    elif extension == "json": return MediaType.JSON
    elif extension == "png": return MediaType.PNG
    elif extension == "txt": return MediaType.TEXT
    elif extension == "kml": return MediaType.KML
    elif extension == "xml": return MediaType.XML
    elif extension == "pdf": return MediaType.PDF
    elif extension == "netcdf" or extension == "nc": return MediaType.NETCDF
    elif extension == "laszip" or extension == "copc": return MediaType.COPC
    elif extension == "pmtiles": return MediaType.VND_PMTILES
    elif extension == "parquet": return MediaType.VND_APACHE_PARQUET
    elif extension == "zarr": return MediaType.VND_ZARR
    # if the extension is not recognized, return application/octet-stream
    else: return "application/octet-stream"

def get_assets(files: list, codes: list[str], geometry: str, _date: str = "", _resolution: str = "", _id: str = "", _processing_id: str = "") -> dict:
    assets = {}
    for file in files:
        # exclude some files that are not relevant
        if file.endswith(".meta") or file.endswith(".aux.xml"): continue
        # get the product corresponding to the file
        product = get_matching_product(file, codes, geometry, _date, _resolution)
        if product:
            if file.endswith(".json") and not is_local(file):
                # if file is json and online, add the original as an asset with role "metadata"
                assets[file] = Asset(file, title="Source product", description="Link to the original source product, before STAC conversion.", media_type="text/html",  roles=["metadata"])
            elif not file.endswith(".json"):
                # for non-json files, use the product template to create a description for the asset, and use the product title as the asset title
                assets[os.path.basename(file)] = Asset(href=file, title=product.title, media_type=get_mime_type(file),
                    description=read_template(product.template, _id, geometry, _processing_id, _date),
                    roles=["data"]) # TODO maybe we can have different roles based on the file name or the content of the json file
    return assets

def get_json_files(files: list, codes: list[str], geometry: str) -> dict:
    json_files = {}
    for file in files:
        if file.endswith(".json"):
            product = get_matching_product(file, codes, geometry)
            if product:
                json = load_json(file)
                # the json file should contain the following fields: type, id, bbox, geometry, properties
                if "type" in json and "id" in json and "bbox" in json and "geometry" in json and "properties" in json:
                    json_files[file] = json
    return json_files
