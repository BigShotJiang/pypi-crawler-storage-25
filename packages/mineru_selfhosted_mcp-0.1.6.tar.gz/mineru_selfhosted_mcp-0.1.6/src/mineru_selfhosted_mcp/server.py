from __future__ import annotations

import os
from pathlib import Path
from time import time
from typing import Any

import httpx
from fastmcp import FastMCP


DEFAULT_BASE_URL = "http://42.51.34.112:8191"
BASE_URL = os.environ.get("MINERU_BASE_URL", DEFAULT_BASE_URL).strip().rstrip("/")
API_TOKEN = os.environ.get("MINERU_API_TOKEN", "").strip()
TIMEOUT = float(os.environ.get("MINERU_TIMEOUT", "1800"))
TRUST_ENV = os.environ.get("MINERU_TRUST_ENV", "").strip().lower() in {"1", "true", "yes"}
LOG_DIR = Path(os.environ.get("MINERU_LOG_DIR", "~/.mineru-selfhosted-mcp/logs")).expanduser()

OCR_LANGUAGES = [
    "ch",
    "en",
    "japan",
    "korean",
    "chinese_cht",
    "latin",
    "arabic",
    "east_slavic",
    "cyrillic",
    "devanagari",
    "ta",
    "te",
    "ka",
    "th",
    "el",
]

mcp = FastMCP("mineru-selfhosted")


def _headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    if API_TOKEN:
        headers["Authorization"] = f"Bearer {API_TOKEN}"
    return headers


def _extract_primary_result(result: dict[str, Any]) -> dict[str, Any]:
    parsed = result.get("results", {})
    first_key = next(iter(parsed), None)
    return parsed[first_key] if first_key else {}


def _ensure_log_dir() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return LOG_DIR


def _coerce_paths(file_paths: str | list[str]) -> list[Path]:
    raw_paths = [file_paths] if isinstance(file_paths, str) else file_paths
    resolved: list[Path] = []
    for raw_path in raw_paths:
        path = Path(raw_path).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        resolved.append(path)
    if not resolved:
        raise ValueError("at least one file path is required")
    return resolved


def _resolve_return_md(return_md: bool, middle_json_only: bool) -> bool:
    return False if middle_json_only else return_md


def _collect_directory_files(
    directory: str,
    pattern: str,
    recursive: bool,
) -> list[Path]:
    root = Path(directory).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"Directory not found: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"Not a directory: {root}")

    iterator = root.rglob(pattern) if recursive else root.glob(pattern)
    files = sorted(path.resolve() for path in iterator if path.is_file())
    if not files:
        raise ValueError(f"no files matched pattern {pattern!r} under {root}")
    return files


def _parse_files(
    file_paths: str | list[str],
    backend: str,
    language: str,
    start_page_id: int,
    end_page_id: int,
    return_md: bool,
    return_middle_json: bool,
    return_images: bool,
) -> dict[str, Any]:
    paths = _coerce_paths(file_paths)
    started_at = time()

    data = {
        "backend": backend,
        "return_md": str(return_md).lower(),
        "return_middle_json": str(return_middle_json).lower(),
        "return_images": str(return_images).lower(),
        "start_page_id": str(start_page_id),
        "end_page_id": str(end_page_id),
        "formula_enable": "true",
        "table_enable": "true",
        "response_format_zip": "false",
        "return_original_file": "false",
        "lang_list": language,
    }

    opened_files = [path.open("rb") for path in paths]
    try:
        files = [
            ("files", (path.name, file_handle, "application/octet-stream"))
            for path, file_handle in zip(paths, opened_files)
        ]
        with httpx.Client(
            timeout=TIMEOUT,
            headers=_headers(),
            trust_env=TRUST_ENV,
        ) as client:
            resp = client.post(f"{BASE_URL}/file_parse", data=data, files=files)
            resp.raise_for_status()
            result = resp.json()
    finally:
        for file_handle in opened_files:
            file_handle.close()

    elapsed_seconds = round(time() - started_at, 3)
    primary = _extract_primary_result(result)
    status = result.get("status")
    file_count = len(paths)
    return {
        "server": BASE_URL,
        "files": [str(path) for path in paths],
        "task_id": result.get("task_id"),
        "status": status,
        "backend": result.get("backend"),
        "elapsed_seconds": elapsed_seconds,
        "file_count": file_count,
        "completed_count": file_count if status == "completed" else 0,
        "failed_count": 0 if status == "completed" else file_count,
        "progress": {
            "current": file_count if status == "completed" else 0,
            "total": file_count,
            "percent": 100 if status == "completed" else 0,
            "stage": status or "unknown",
        },
        "markdown": primary.get("md_content"),
        "middle_json": primary.get("middle_json"),
        "raw_result": result,
    }


@mcp.tool
def mineru_health() -> dict[str, Any]:
    """Check whether the remote self-hosted MinerU API is healthy."""
    with httpx.Client(timeout=30.0, headers=_headers(), trust_env=TRUST_ENV) as client:
        resp = client.get(f"{BASE_URL}/health")
        resp.raise_for_status()
        return resp.json()


@mcp.tool
def parse_document(
    file_path: str,
    backend: str = "hybrid-auto-engine",
    language: str = "ch",
    start_page_id: int = 0,
    end_page_id: int = 99999,
    return_md: bool = True,
    return_middle_json: bool = False,
    return_images: bool = False,
    middle_json_only: bool = False,
) -> dict[str, Any]:
    """Parse a local document through the remote MinerU API."""
    result = _parse_files(
        file_paths=file_path,
        backend=backend,
        language=language,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=_resolve_return_md(return_md, middle_json_only),
        return_middle_json=(return_middle_json or middle_json_only),
        return_images=return_images,
    )
    result["file"] = result["files"][0]
    return result


@mcp.tool
def parse_documents(
    file_paths: list[str],
    backend: str = "hybrid-auto-engine",
    language: str = "ch",
    start_page_id: int = 0,
    end_page_id: int = 99999,
    return_md: bool = True,
    return_middle_json: bool = False,
    return_images: bool = False,
    middle_json_only: bool = False,
) -> dict[str, Any]:
    """Parse one or more local documents through the remote MinerU API."""
    return _parse_files(
        file_paths=file_paths,
        backend=backend,
        language=language,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=_resolve_return_md(return_md, middle_json_only),
        return_middle_json=(return_middle_json or middle_json_only),
        return_images=return_images,
    )


@mcp.tool
def parse_directory(
    directory: str,
    pattern: str = "*",
    recursive: bool = False,
    backend: str = "hybrid-auto-engine",
    language: str = "ch",
    start_page_id: int = 0,
    end_page_id: int = 99999,
    return_md: bool = True,
    return_middle_json: bool = False,
    return_images: bool = False,
    middle_json_only: bool = False,
) -> dict[str, Any]:
    """Parse all matching files in a directory through the remote MinerU API."""
    files = _collect_directory_files(directory, pattern, recursive)
    result = _parse_files(
        file_paths=[str(path) for path in files],
        backend=backend,
        language=language,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=_resolve_return_md(return_md, middle_json_only),
        return_middle_json=(return_middle_json or middle_json_only),
        return_images=return_images,
    )
    result["directory"] = str(Path(directory).expanduser().resolve())
    result["pattern"] = pattern
    result["recursive"] = recursive
    result["matched_count"] = len(files)
    return result


@mcp.tool
def get_ocr_languages() -> dict[str, Any]:
    """List common OCR language codes supported by MinerU."""
    return {
        "count": len(OCR_LANGUAGES),
        "languages": OCR_LANGUAGES,
    }


@mcp.tool
def clean_logs(days: int = 7) -> dict[str, Any]:
    """Delete local MCP log files older than the requested number of days."""
    if days < 0:
        raise ValueError("days must be >= 0")

    log_dir = _ensure_log_dir()
    cutoff = time() - (days * 86400)
    deleted: list[str] = []

    for path in log_dir.rglob("*"):
        if not path.is_file():
            continue
        if path.stat().st_mtime < cutoff:
            path.unlink()
            deleted.append(str(path))

    return {
        "log_dir": str(log_dir),
        "days": days,
        "deleted_count": len(deleted),
        "deleted_files": deleted,
    }


def main() -> None:
    mcp.run()
