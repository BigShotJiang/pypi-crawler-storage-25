"""Tripline — Runtime safety for AI agents.

Freeze, rollback, or kill your AI agents before damage is done.
"""

__version__ = "0.0.1"
