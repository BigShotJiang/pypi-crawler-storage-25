<!--
Sync Impact Report
===================
Version change: (new) → 1.0.0
Modified principles: N/A (initial ratification)
Added sections:
  - Core Principles (4 principles)
  - API Design Constraints
  - Development Workflow
  - Governance
Removed sections: None
Templates requiring updates:
  - .specify/templates/plan-template.md — ✅ no updates needed (generic Constitution Check placeholder)
  - .specify/templates/spec-template.md — ✅ no updates needed (generic template)
  - .specify/templates/tasks-template.md — ✅ no updates needed (generic template)
  - .specify/templates/checklist-template.md — ✅ no updates needed (generic template)
  - No command templates found to check
Follow-up TODOs: None
-->

# maketab Constitution

## Core Principles

### I. Library-First

maketab is a focused Python library. Every public feature MUST be
exposed as a composable Python API — not as a CLI, web endpoint, or
framework plugin. The library MUST remain self-contained with minimal
dependencies (currently: `jmespath`, `pydantic`). New dependencies
MUST be justified by a concrete capability gap that cannot be
reasonably addressed with existing dependencies or the standard
library.

### II. Type Safety and Schema-Driven Design

All public interfaces MUST use Python type hints. Pydantic models
define the output schema and MUST remain the sole mechanism for
declaring field-to-query mappings (via `Annotated` metadata). The
`Query` and `Explode` annotations MUST stay as the canonical way to
bind JMESPath expressions to output fields. Adding new annotation
types requires demonstrating that the existing two cannot express the
required semantics.

### III. Correctness Through Testing

Every user-facing behavior MUST have at least one corresponding
pytest test. Tests MUST use concrete input data and assert against
exact expected output (not structural checks). Edge cases — null
values, empty arrays, missing keys — MUST be covered before a
feature is considered complete. Tests MUST remain fast (no network,
no filesystem, no sleep).

### IV. Simplicity

Prefer straightforward implementations over abstractions. A new
helper, utility, or intermediate type MUST solve more than one
concrete problem before it is introduced. JMESPath handles query
complexity; maketab handles flattening logic — do not duplicate
either responsibility. When in doubt, keep the public API surface
small and the internal call chain shallow.

## API Design Constraints

- The public API surface is `flatten`, `Query`, and `Explode`
  (exported from `maketab/__init__.py`). Any addition to `__all__`
  MUST be accompanied by documentation and tests.
- `flatten` MUST accept `List[Dict]` input and return `List[T]`
  where `T` is a caller-supplied Pydantic model.
- Errors from malformed schemas (e.g., missing query annotations)
  MUST raise `ValueError` with a message identifying the offending
  field.
- Internal helpers (prefixed with `_`) are not part of the public
  contract and MAY change without notice.

## Development Workflow

- Python version: 3.10+ (as declared in `pyproject.toml`).
- Package manager: `uv`.
- Test runner: `pytest` (configured in `pyproject.toml`).
- All changes MUST pass `pytest` with zero failures before merge.
- Code style follows the project-level CLAUDE.md guidance: minimal
  comments, type hints on all public functions, Google-style
  docstrings on public APIs, and informative errors over silent
  failures.

## Governance

This constitution is the authoritative reference for project
principles and constraints. It supersedes informal conventions
wherever they conflict.

- **Amendments**: Any change to a principle or constraint MUST be
  documented with a version bump, rationale, and update to this
  file. Breaking changes to principles require a MAJOR version bump.
- **Compliance**: Pull requests and code reviews SHOULD verify
  alignment with the principles above. Violations MUST be justified
  in the PR description.
- **Versioning**: This constitution follows semantic versioning
  (MAJOR.MINOR.PATCH). See the version line below.

**Version**: 1.0.0 | **Ratified**: 2026-04-04 | **Last Amended**: 2026-04-04
