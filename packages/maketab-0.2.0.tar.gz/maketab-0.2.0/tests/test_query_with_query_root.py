"""Test using Query as root to reduce duplication for deep nested paths."""

from typing import Annotated

from pydantic import BaseModel

from maketab import Query
from .helpers import assert_flatten


# Shared Query root for deeply nested data
billing = Query("customer.addresses[?type=='billing'] | [0]")


class OrderBilling(BaseModel):
    order_id: Annotated[int, Query("id")]
    customer_name: Annotated[str, Query("customer.name")]
    billing_street: Annotated[str, Query("street", billing)]
    billing_city: Annotated[str, Query("city", billing)]
    billing_zip: Annotated[str, Query("zip", billing)]


TEST_ORDER = {
    "id": 999,
    "customer": {
        "name": "Jane Doe",
        "addresses": [
            {
                "type": "shipping",
                "street": "123 Ship St",
                "city": "Shiptown",
                "zip": "11111",
            },
            {
                "type": "billing",
                "street": "456 Bill Ave",
                "city": "Billville",
                "zip": "22222",
            },
        ],
    },
}


# @pytest.mark.xfail(
#     reason="Bug: Query root is incorrectly treated as Explode, iterating over string chars"
# )
def test_query_root_reduces_duplication():
    """Query as root should evaluate once and be shared by child queries."""
    assert_flatten(
        [TEST_ORDER],
        OrderBilling,
        [
            OrderBilling(
                order_id=999,
                customer_name="Jane Doe",
                billing_street="456 Bill Ave",
                billing_city="Billville",
                billing_zip="22222",
            ),
        ],
    )
