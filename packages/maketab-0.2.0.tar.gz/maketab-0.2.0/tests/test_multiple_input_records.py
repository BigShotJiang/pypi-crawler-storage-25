"""Test multiple input records are processed independently."""

from typing import Annotated

from pydantic import BaseModel

from maketab import Query, Explode
from .helpers import assert_flatten


tags = Explode("tags")


class TaggedItem(BaseModel):
    id: Annotated[int, Query("id")]
    tag: Annotated[str, Query("@", tags)]


TEST_ITEMS = [
    {"id": 1, "tags": ["a", "b"]},
    {"id": 2, "tags": ["x"]},
    {"id": 3, "tags": ["p", "q", "r"]},
]


def test_multiple_input_records():
    """Each input record should be processed independently, results concatenated."""
    assert_flatten(
        TEST_ITEMS,
        TaggedItem,
        [
            TaggedItem(id=1, tag="a"),
            TaggedItem(id=1, tag="b"),
            TaggedItem(id=2, tag="x"),
            TaggedItem(id=3, tag="p"),
            TaggedItem(id=3, tag="q"),
            TaggedItem(id=3, tag="r"),
        ],
    )
