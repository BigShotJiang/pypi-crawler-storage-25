from typing import Annotated

import pyarrow.parquet as pq
import pytest
from pydantic import BaseModel

from maketab import Query
from maketab.parquet import to_parquet


class SimpleRow(BaseModel):
    name: Annotated[str, Query("name")]
    age: Annotated[int, Query("age")]


class UnsupportedField(BaseModel):
    data: Annotated[list, Query("data")]


def test_empty_input_returns_valid_parquet():
    buf = to_parquet([], SimpleRow)
    table = pq.read_table(buf)

    assert table.num_rows == 0
    assert table.column_names == ["name", "age"]


def test_unsupported_type_raises_value_error():
    with pytest.raises(ValueError, match="unsupported type"):
        to_parquet([], UnsupportedField)
