"""Test that missing Query/Explode annotation raises ValueError."""

from typing import Annotated

import pytest
from pydantic import BaseModel

from maketab import Query, flatten


class InvalidModel(BaseModel):
    id: Annotated[int, Query("id")]
    name: str  # Missing Query annotation


def test_missing_query_raises_error():
    with pytest.raises(ValueError, match="does not specify a query"):
        flatten([{"id": 1, "name": "test"}], InvalidModel)
