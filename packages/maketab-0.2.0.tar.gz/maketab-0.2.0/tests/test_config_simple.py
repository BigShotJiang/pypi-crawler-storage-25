"""Test config-driven flatten with simple queries (no roots)."""

from maketab import SchemaConfig, flatten_config


CONFIG = SchemaConfig.model_validate(
    {
        "fields": [
            {"name": "id", "type": "int", "query": "id"},
            {"name": "name", "type": "str", "query": "name"},
            {"name": "price", "type": "float", "query": "price"},
        ],
    }
)

TEST_DATA = [{"id": 1, "name": "Widget", "price": 9.99}]


def test_simple_config_flatten():
    results = flatten_config(CONFIG, TEST_DATA)
    assert len(results) == 1
    row = results[0]
    assert row.id == 1
    assert row.name == "Widget"
    assert row.price == 9.99


def test_simple_config_multiple_records():
    data = [
        {"id": 1, "name": "Widget", "price": 9.99},
        {"id": 2, "name": "Gadget", "price": 19.99},
    ]
    results = flatten_config(CONFIG, data)
    assert len(results) == 2
    assert results[0].id == 1
    assert results[1].id == 2


def test_simple_config_model_dump():
    results = flatten_config(CONFIG, TEST_DATA)
    d = results[0].model_dump()
    assert d == {"id": 1, "name": "Widget", "price": 9.99}


def test_nullable_field():
    config = SchemaConfig.model_validate(
        {
            "fields": [
                {"name": "id", "type": "int", "query": "id"},
                {"name": "label", "type": "str", "query": "label", "nullable": True},
            ],
        }
    )
    results = flatten_config(config, [{"id": 1, "label": None}])
    assert results[0].label is None
