"""Test basic flat extraction with only Query annotations."""

from typing import Annotated

from pydantic import BaseModel

from maketab import Query
from .helpers import assert_flatten


class Product(BaseModel):
    id: Annotated[int, Query("id")]
    name: Annotated[str, Query("name")]
    price: Annotated[float, Query("price")]


TEST_DATA = {"id": 1, "name": "Widget", "price": 9.99}


def test_simple_queries():
    assert_flatten(
        [TEST_DATA],
        Product,
        [Product(id=1, name="Widget", price=9.99)],
    )
