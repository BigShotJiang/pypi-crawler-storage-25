"""Tests for timestamp, date, and decimal types in config-driven flattening and Parquet output."""

import datetime
from decimal import Decimal

import pyarrow as pa
import pyarrow.parquet as pq
import pytest

from maketab import SchemaConfig, flatten_config
from maketab.parquet import to_parquet, _get_arrow_schema
from maketab.config import _build_model


def _make_config(type_str: str, nullable: bool = False) -> SchemaConfig:
    return SchemaConfig.model_validate(
        {
            "fields": [
                {"name": "val", "type": type_str, "query": "val", "nullable": nullable}
            ]
        }
    )


class TestTimestamp:
    def test_flatten_iso8601(self):
        config = _make_config("timestamp")
        data = [{"val": "2026-01-15T10:30:00Z"}]
        rows = flatten_config(config, data)
        assert isinstance(rows[0].val, datetime.datetime)

    def test_round_trip_parquet(self):
        config = _make_config("timestamp")
        data = [{"val": "2026-01-15T10:30:00Z"}, {"val": "2025-06-01T00:00:00+00:00"}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.schema.field("val").type == pa.timestamp("us", tz="UTC")
        assert table.num_rows == 2

    def test_nullable_timestamp(self):
        config = _make_config("timestamp", nullable=True)
        data = [{"val": "2026-01-15T10:30:00Z"}, {"val": None}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist()[1] is None


class TestDate:
    def test_flatten_date_string(self):
        config = _make_config("date")
        data = [{"val": "2026-01-15"}]
        rows = flatten_config(config, data)
        assert isinstance(rows[0].val, datetime.date)

    def test_round_trip_parquet(self):
        config = _make_config("date")
        data = [{"val": "2026-01-15"}, {"val": "2025-06-01"}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.schema.field("val").type == pa.date32()
        values = table.column("val").to_pylist()
        assert values == [datetime.date(2026, 1, 15), datetime.date(2025, 6, 1)]

    def test_nullable_date(self):
        config = _make_config("date", nullable=True)
        data = [{"val": "2026-01-15"}, {"val": None}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist()[1] is None


class TestDecimal:
    def test_flatten_decimal_string(self):
        config = _make_config("decimal")
        data = [{"val": "123.456"}]
        rows = flatten_config(config, data)
        assert isinstance(rows[0].val, Decimal)

    def test_flatten_decimal_number(self):
        config = _make_config("decimal")
        data = [{"val": 99.5}]
        rows = flatten_config(config, data)
        assert isinstance(rows[0].val, Decimal)

    def test_round_trip_parquet(self):
        config = _make_config("decimal")
        data = [{"val": "123.456"}, {"val": "0.001"}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.schema.field("val").type == pa.decimal128(38, 18)
        assert table.num_rows == 2

    def test_nullable_decimal(self):
        config = _make_config("decimal", nullable=True)
        data = [{"val": "123.456"}, {"val": None}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist()[1] is None
