from typing import List, Type, TypeVar
from pydantic import BaseModel

from maketab import flatten

T = TypeVar("T", bound=BaseModel)


def assert_flatten(input_data: List[dict], schema: Type[T], expected: List[T]) -> None:
    """Common test helper for flatten assertions."""
    result = flatten(input_data, schema)
    assert result == expected, f"Expected {expected}, got {result}"
