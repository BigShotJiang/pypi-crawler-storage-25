"""Test handling of null/missing values in source data."""

from typing import Annotated, Optional

from pydantic import BaseModel

from maketab import Query
from .helpers import assert_flatten


class UserProfile(BaseModel):
    id: Annotated[int, Query("id")]
    name: Annotated[str, Query("name")]
    nickname: Annotated[Optional[str], Query("nickname")]
    bio: Annotated[Optional[str], Query("profile.bio")]


TEST_COMPLETE = {
    "id": 1,
    "name": "Alice",
    "nickname": "Ali",
    "profile": {"bio": "Hello"},
}
TEST_NULLS = {"id": 2, "name": "Bob", "nickname": None, "profile": {"bio": None}}
TEST_MISSING = {"id": 3, "name": "Charlie"}


def test_complete_data():
    assert_flatten(
        [TEST_COMPLETE],
        UserProfile,
        [UserProfile(id=1, name="Alice", nickname="Ali", bio="Hello")],
    )


def test_explicit_null_values():
    assert_flatten(
        [TEST_NULLS],
        UserProfile,
        [UserProfile(id=2, name="Bob", nickname=None, bio=None)],
    )


def test_missing_fields_resolve_to_none():
    assert_flatten(
        [TEST_MISSING],
        UserProfile,
        [UserProfile(id=3, name="Charlie", nickname=None, bio=None)],
    )
