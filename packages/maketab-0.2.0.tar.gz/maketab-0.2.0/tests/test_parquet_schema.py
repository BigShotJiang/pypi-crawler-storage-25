import datetime
from decimal import Decimal
from typing import Annotated, Optional

import pyarrow as pa
import pytest
from pydantic import BaseModel

from maketab.core import Query
from maketab.parquet import _get_arrow_schema


class AllTypes(BaseModel):
    s: Annotated[str, Query("s")]
    i: Annotated[int, Query("i")]
    f: Annotated[float, Query("f")]
    b: Annotated[bool, Query("b")]


class AllOptional(BaseModel):
    s: Annotated[Optional[str], Query("s")]
    i: Annotated[Optional[int], Query("i")]
    f: Annotated[Optional[float], Query("f")]
    b: Annotated[Optional[bool], Query("b")]


class UnsupportedType(BaseModel):
    x: Annotated[bytes, Query("x")]


class NewPrimitiveTypes(BaseModel):
    ts: Annotated[datetime.datetime, Query("ts")]
    d: Annotated[datetime.date, Query("d")]
    dec: Annotated[Decimal, Query("dec")]


class NewPrimitiveOptional(BaseModel):
    ts: Annotated[Optional[datetime.datetime], Query("ts")]
    d: Annotated[Optional[datetime.date], Query("d")]
    dec: Annotated[Optional[Decimal], Query("dec")]


def test_base_types_mapping():
    schema = _get_arrow_schema(AllTypes)
    assert schema.field("s").type == pa.string()
    assert schema.field("i").type == pa.int64()
    assert schema.field("f").type == pa.float64()
    assert schema.field("b").type == pa.bool_()


def test_base_types_not_nullable():
    schema = _get_arrow_schema(AllTypes)
    for field in schema:
        assert not field.nullable


def test_optional_types_mapping():
    schema = _get_arrow_schema(AllOptional)
    assert schema.field("s").type == pa.string()
    assert schema.field("i").type == pa.int64()
    assert schema.field("f").type == pa.float64()
    assert schema.field("b").type == pa.bool_()


def test_optional_types_nullable():
    schema = _get_arrow_schema(AllOptional)
    for field in schema:
        assert field.nullable


def test_unsupported_type_raises_value_error():
    with pytest.raises(ValueError, match="unsupported type"):
        _get_arrow_schema(UnsupportedType)


def test_new_primitive_types_mapping():
    schema = _get_arrow_schema(NewPrimitiveTypes)
    assert schema.field("ts").type == pa.timestamp("us", tz="UTC")
    assert schema.field("d").type == pa.date32()
    assert schema.field("dec").type == pa.decimal128(38, 18)


def test_new_primitive_types_not_nullable():
    schema = _get_arrow_schema(NewPrimitiveTypes)
    for field in schema:
        assert not field.nullable


def test_new_primitive_optional_mapping():
    schema = _get_arrow_schema(NewPrimitiveOptional)
    assert schema.field("ts").type == pa.timestamp("us", tz="UTC")
    assert schema.field("d").type == pa.date32()
    assert schema.field("dec").type == pa.decimal128(38, 18)


def test_new_primitive_optional_nullable():
    schema = _get_arrow_schema(NewPrimitiveOptional)
    for field in schema:
        assert field.nullable
