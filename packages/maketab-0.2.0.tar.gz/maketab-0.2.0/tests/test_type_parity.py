"""Test that config and parquet modules support the same set of types."""

import pytest

from maketab.config import SUPPORTED_TYPES, _parse_type_string, _resolve_type
from maketab.parquet import _TYPE_MAP, _get_arrow_schema, _resolve_arrow_type


def test_primitive_type_parity():
    """SUPPORTED_TYPES values (Python types) must equal _TYPE_MAP keys (Python types)."""
    config_python_types = set(SUPPORTED_TYPES.values())
    parquet_python_types = set(_TYPE_MAP.keys())
    assert config_python_types == parquet_python_types, (
        f"Type parity violation!\n"
        f"  In config but not parquet: {config_python_types - parquet_python_types}\n"
        f"  In parquet but not config: {parquet_python_types - config_python_types}"
    )


@pytest.mark.parametrize("prim_name", sorted(SUPPORTED_TYPES.keys()))
def test_list_compound_works_in_both(prim_name: str):
    """Every primitive can be used as list[T] in both config and parquet."""
    type_str = f"list[{prim_name}]"
    _parse_type_string(type_str)
    python_type = _resolve_type(type_str, nullable=False)
    _resolve_arrow_type(python_type)


@pytest.mark.parametrize("prim_name", sorted(SUPPORTED_TYPES.keys()))
def test_map_compound_works_in_both(prim_name: str):
    """Every primitive can be used as map[str, T] in both config and parquet."""
    type_str = f"map[str, {prim_name}]"
    _parse_type_string(type_str)
    python_type = _resolve_type(type_str, nullable=False)
    _resolve_arrow_type(python_type)


@pytest.mark.parametrize("prim_name", sorted(SUPPORTED_TYPES.keys()))
def test_list_map_compound_works_in_both(prim_name: str):
    """Every primitive can be used as list[map[str, T]] in both config and parquet."""
    type_str = f"list[map[str, {prim_name}]]"
    _parse_type_string(type_str)
    python_type = _resolve_type(type_str, nullable=False)
    _resolve_arrow_type(python_type)
