"""Test complex jmespath queries with filters, pipes, and array access."""

from typing import Annotated, List

from pydantic import BaseModel

from maketab import Query
from .helpers import assert_flatten


class EventSummary(BaseModel):
    event_id: Annotated[str, Query("event.id")]
    title: Annotated[str, Query("event.details.title")]
    host_email: Annotated[str, Query("event.participants[?role=='host'].email | [0]")]
    attendee_count: Annotated[
        int, Query("length(event.participants[?role=='attendee'])")
    ]
    tags: Annotated[List[str], Query("event.metadata.tags[*].name")]
    primary_tag: Annotated[str, Query("event.metadata.tags[0].name")]


TEST_EVENT = {
    "event": {
        "id": "evt-123",
        "details": {"title": "Team Standup", "duration": 30},
        "participants": [
            {"email": "host@example.com", "role": "host"},
            {"email": "alice@example.com", "role": "attendee"},
            {"email": "bob@example.com", "role": "attendee"},
            {"email": "charlie@example.com", "role": "attendee"},
        ],
        "metadata": {
            "tags": [
                {"name": "meeting", "color": "blue"},
                {"name": "recurring", "color": "green"},
            ]
        },
    }
}


def test_complex_jmespath_queries():
    assert_flatten(
        [TEST_EVENT],
        EventSummary,
        [
            EventSummary(
                event_id="evt-123",
                title="Team Standup",
                host_email="host@example.com",
                attendee_count=3,
                tags=["meeting", "recurring"],
                primary_tag="meeting",
            ),
        ],
    )
