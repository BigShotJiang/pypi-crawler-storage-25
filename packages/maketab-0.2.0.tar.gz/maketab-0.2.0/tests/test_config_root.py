"""Test config-driven flatten with query roots (explode and non-explode)."""

from maketab import SchemaConfig, flatten_config


def test_non_explode_root():
    """Fields sharing a non-explode root resolve queries against that root."""
    config = SchemaConfig.model_validate(
        {
            "query_roots": [
                {"name": "meta", "query": "metadata", "explode": False},
            ],
            "fields": [
                {"name": "id", "type": "int", "query": "id"},
                {"name": "region", "type": "str", "query": "region", "root": "meta"},
                {"name": "tier", "type": "str", "query": "tier", "root": "meta"},
            ],
        }
    )
    data = [{"id": 1, "metadata": {"region": "us-east", "tier": "premium"}}]
    results = flatten_config(config, data)
    assert len(results) == 1
    assert results[0].id == 1
    assert results[0].region == "us-east"
    assert results[0].tier == "premium"


def test_explode_root_with_fields():
    """Fields sharing an explode root zip together and multiply rows."""
    config = SchemaConfig.model_validate(
        {
            "query_roots": [
                {"name": "items", "query": "items[*]", "explode": True},
            ],
            "fields": [
                {"name": "order_id", "type": "int", "query": "id"},
                {"name": "item_name", "type": "str", "query": "name", "root": "items"},
                {
                    "name": "item_price",
                    "type": "float",
                    "query": "price",
                    "root": "items",
                },
            ],
        }
    )
    data = [
        {
            "id": 1,
            "items": [
                {"name": "Widget", "price": 9.99},
                {"name": "Gadget", "price": 19.99},
            ],
        }
    ]
    results = flatten_config(config, data)
    assert len(results) == 2
    assert results[0].order_id == 1
    assert results[0].item_name == "Widget"
    assert results[0].item_price == 9.99
    assert results[1].item_name == "Gadget"
    assert results[1].item_price == 19.99


def test_mixed_explode_and_non_explode_roots():
    """Config with both explode and non-explode roots."""
    config = SchemaConfig.model_validate(
        {
            "query_roots": [
                {"name": "items", "query": "items[*]", "explode": True},
                {"name": "meta", "query": "metadata", "explode": False},
            ],
            "fields": [
                {"name": "id", "type": "int", "query": "id"},
                {"name": "item_name", "type": "str", "query": "name", "root": "items"},
                {"name": "region", "type": "str", "query": "region", "root": "meta"},
            ],
        }
    )
    data = [
        {
            "id": 1,
            "items": [{"name": "A"}, {"name": "B"}],
            "metadata": {"region": "eu"},
        }
    ]
    results = flatten_config(config, data)
    assert len(results) == 2
    assert results[0].region == "eu"
    assert results[1].region == "eu"
    assert results[0].item_name == "A"
    assert results[1].item_name == "B"
