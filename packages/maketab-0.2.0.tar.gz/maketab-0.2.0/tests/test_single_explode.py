"""Test single Explode creating multiple output records."""

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel

from maketab import Query, Explode
from .helpers import assert_flatten


status_history = Explode("status_history")


class OrderSnapshot(BaseModel):
    id: Annotated[int, Query("id")]
    name: Annotated[str, Query("metadata[?key=='name'].value | [0]")]
    is_draft: Annotated[bool, Query("metadata[?key=='draft'].value | [0]")]
    status: Annotated[Literal["pending", "shipped"], Query("status", status_history)]
    changed_on: Annotated[date, Query("date", status_history)]


TEST_ORDER = {
    "id": 42,
    "metadata": [
        {"key": "sku", "value": "ABC-123"},
        {"key": "draft", "value": False},
        {"key": "name", "value": "Test Order"},
    ],
    "status_history": [
        {"status": "pending", "date": "2023-01-04"},
        {"status": "shipped", "date": "2023-01-06"},
    ],
}


def test_single_explode():
    assert_flatten(
        [TEST_ORDER],
        OrderSnapshot,
        [
            OrderSnapshot(
                id=42,
                name="Test Order",
                is_draft=False,
                status="pending",
                changed_on=date(2023, 1, 4),
            ),
            OrderSnapshot(
                id=42,
                name="Test Order",
                is_draft=False,
                status="shipped",
                changed_on=date(2023, 1, 6),
            ),
        ],
    )
