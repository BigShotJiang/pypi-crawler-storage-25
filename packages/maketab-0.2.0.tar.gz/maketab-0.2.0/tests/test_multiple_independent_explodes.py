"""Test two independent Explodes produce cartesian product."""

from typing import Annotated

from pydantic import BaseModel

from maketab import Query, Explode, flatten


# Two separate Explode instances
colors = Explode("colors")
sizes = Explode("sizes")


class ProductVariant(BaseModel):
    name: Annotated[str, Query("name")]
    color: Annotated[str, Query("@", colors)]
    size: Annotated[str, Query("@", sizes)]


TEST_PRODUCT = {
    "name": "T-Shirt",
    "colors": ["red", "blue"],
    "sizes": ["S", "M", "L"],
}


def test_independent_explodes_cartesian_product():
    """Two independent Explodes should produce cartesian product of records."""
    result = flatten([TEST_PRODUCT], ProductVariant)
    expected = [
        ProductVariant(name="T-Shirt", color="red", size="S"),
        ProductVariant(name="T-Shirt", color="red", size="M"),
        ProductVariant(name="T-Shirt", color="red", size="L"),
        ProductVariant(name="T-Shirt", color="blue", size="S"),
        ProductVariant(name="T-Shirt", color="blue", size="M"),
        ProductVariant(name="T-Shirt", color="blue", size="L"),
    ]
    # Compare as sorted tuples since order may vary
    result_tuples = sorted((r.name, r.color, r.size) for r in result)
    expected_tuples = sorted((e.name, e.color, e.size) for e in expected)
    assert result_tuples == expected_tuples
