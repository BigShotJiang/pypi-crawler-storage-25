"""Test config-driven flatten with explode query roots."""

from maketab import SchemaConfig, flatten_config


CONFIG = SchemaConfig.model_validate(
    {
        "query_roots": [
            {"name": "items", "query": "line_items", "explode": True},
        ],
        "fields": [
            {"name": "invoice_id", "type": "int", "query": "id"},
            {"name": "product", "type": "str", "query": "product", "root": "items"},
            {"name": "quantity", "type": "int", "query": "qty", "root": "items"},
        ],
    }
)

TEST_DATA = [
    {
        "id": 100,
        "line_items": [
            {"product": "Apples", "qty": 5},
            {"product": "Oranges", "qty": 3},
        ],
    }
]


def test_explode_via_config():
    results = flatten_config(CONFIG, TEST_DATA)
    assert len(results) == 2
    assert results[0].invoice_id == 100
    assert results[0].product == "Apples"
    assert results[0].quantity == 5
    assert results[1].product == "Oranges"
    assert results[1].quantity == 3


def test_explode_null_array():
    data = [{"id": 1, "line_items": None}]
    results = flatten_config(CONFIG, data)
    assert len(results) == 0


def test_explode_empty_array():
    data = [{"id": 1, "line_items": []}]
    results = flatten_config(CONFIG, data)
    assert len(results) == 0
