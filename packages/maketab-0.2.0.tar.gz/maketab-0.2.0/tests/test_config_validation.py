"""Test validation errors for invalid configs."""

import pytest
from pydantic import ValidationError

from maketab import SchemaConfig


def test_missing_query_field():
    with pytest.raises(ValidationError, match="query"):
        SchemaConfig.model_validate({"fields": [{"name": "id", "type": "int"}]})


def test_unsupported_type_name():
    with pytest.raises(ValidationError, match="unsupported type 'integer'"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "id", "type": "integer", "query": "id"}]}
        )


def test_duplicate_field_names():
    with pytest.raises(ValidationError, match="duplicate field names"):
        SchemaConfig.model_validate(
            {
                "fields": [
                    {"name": "id", "type": "int", "query": "id"},
                    {"name": "id", "type": "str", "query": "name"},
                ]
            }
        )


def test_duplicate_root_names():
    with pytest.raises(ValidationError, match="duplicate query root names"):
        SchemaConfig.model_validate(
            {
                "query_roots": [
                    {"name": "items", "query": "a[*]", "explode": True},
                    {"name": "items", "query": "b[*]", "explode": True},
                ],
                "fields": [{"name": "id", "type": "int", "query": "id"}],
            }
        )


def test_undefined_root_reference():
    with pytest.raises(
        ValidationError, match="references undefined query root 'missing'"
    ):
        SchemaConfig.model_validate(
            {"fields": [{"name": "x", "type": "str", "query": "x", "root": "missing"}]}
        )


def test_zero_fields():
    with pytest.raises(ValidationError):
        SchemaConfig.model_validate({"fields": []})


def test_empty_field_name():
    with pytest.raises(ValidationError, match="must be non-empty"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "", "type": "int", "query": "id"}]}
        )


def test_empty_query_string():
    with pytest.raises(ValidationError, match="must be non-empty"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "id", "type": "int", "query": ""}]}
        )


# --- New primitive type validation ---


def test_timestamp_type_accepted():
    config = SchemaConfig.model_validate(
        {"fields": [{"name": "ts", "type": "timestamp", "query": "ts"}]}
    )
    assert config.fields[0].type == "timestamp"


def test_date_type_accepted():
    config = SchemaConfig.model_validate(
        {"fields": [{"name": "d", "type": "date", "query": "d"}]}
    )
    assert config.fields[0].type == "date"


def test_decimal_type_accepted():
    config = SchemaConfig.model_validate(
        {"fields": [{"name": "amt", "type": "decimal", "query": "amt"}]}
    )
    assert config.fields[0].type == "decimal"


def test_datetime_misspelling_rejected():
    with pytest.raises(ValidationError, match="unsupported type 'datetime'"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "ts", "type": "datetime", "query": "ts"}]}
        )


def test_time_misspelling_rejected():
    with pytest.raises(ValidationError, match="unsupported type 'time'"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "t", "type": "time", "query": "t"}]}
        )


# --- List type validation (US2) ---


def test_list_str_accepted():
    config = SchemaConfig.model_validate(
        {"fields": [{"name": "tags", "type": "list[str]", "query": "tags"}]}
    )
    assert config.fields[0].type == "list[str]"


def test_list_unknown_rejected():
    with pytest.raises(ValidationError, match="unknown primitive 'unknown'"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "x", "type": "list[unknown]", "query": "x"}]}
        )


def test_list_empty_brackets_rejected():
    with pytest.raises(ValidationError, match="empty list element type"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "x", "type": "list[]", "query": "x"}]}
        )


def test_bare_list_rejected():
    with pytest.raises(ValidationError, match="unsupported type 'list'"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "x", "type": "list", "query": "x"}]}
        )


# --- Map type validation (US3) ---


def test_map_str_int_accepted():
    config = SchemaConfig.model_validate(
        {"fields": [{"name": "m", "type": "map[str, int]", "query": "m"}]}
    )
    assert config.fields[0].type == "map[str, int]"


def test_map_non_string_key_rejected():
    with pytest.raises(ValidationError, match="map key must be 'str'"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "m", "type": "map[int, str]", "query": "m"}]}
        )


def test_map_missing_value_type_rejected():
    with pytest.raises(ValidationError, match="map requires two arguments"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "m", "type": "map[str]", "query": "m"}]}
        )


def test_map_empty_brackets_rejected():
    with pytest.raises(ValidationError, match="map requires two arguments"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "m", "type": "map[]", "query": "m"}]}
        )


# --- List-of-map type validation (US4) ---


def test_list_map_str_int_accepted():
    config = SchemaConfig.model_validate(
        {"fields": [{"name": "x", "type": "list[map[str, int]]", "query": "x"}]}
    )
    assert config.fields[0].type == "list[map[str, int]]"


def test_list_list_rejected():
    with pytest.raises(ValidationError, match="nested lists are not supported"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "x", "type": "list[list[str]]", "query": "x"}]}
        )


def test_map_with_list_value_rejected():
    with pytest.raises(ValidationError, match="nested compound types in map values"):
        SchemaConfig.model_validate(
            {"fields": [{"name": "x", "type": "map[str, list[int]]", "query": "x"}]}
        )


# --- nullable_elements validation ---


def test_nullable_elements_on_primitive_rejected():
    with pytest.raises(ValidationError, match="only valid for compound types"):
        SchemaConfig.model_validate(
            {
                "fields": [
                    {
                        "name": "x",
                        "type": "str",
                        "query": "x",
                        "nullable_elements": True,
                    }
                ]
            }
        )


def test_nullable_elements_on_list_accepted():
    config = SchemaConfig.model_validate(
        {
            "fields": [
                {
                    "name": "x",
                    "type": "list[int]",
                    "query": "x",
                    "nullable_elements": True,
                }
            ]
        }
    )
    assert config.fields[0].nullable_elements is True
