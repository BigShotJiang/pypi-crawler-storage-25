import pyarrow.parquet as pq

from maketab import SchemaConfig, flatten_config, flatten_config_to_parquet, to_parquet
from maketab.config import _build_model


SIMPLE_CONFIG = SchemaConfig(
    fields=[
        {"name": "name", "type": "str", "query": "name"},
        {"name": "age", "type": "int", "query": "age"},
    ]
)

NULLABLE_CONFIG = SchemaConfig(
    fields=[
        {"name": "name", "type": "str", "query": "name"},
        {"name": "score", "type": "float", "query": "score", "nullable": True},
    ]
)

SAMPLE_DATA = [
    {"name": "Alice", "age": 30},
    {"name": "Bob", "age": 25},
]


def test_config_driven_round_trip():
    buf = flatten_config_to_parquet(SIMPLE_CONFIG, SAMPLE_DATA)
    table = pq.read_table(buf)

    assert table.num_rows == 2
    assert table.column_names == ["name", "age"]
    assert table.column("name").to_pylist() == ["Alice", "Bob"]
    assert table.column("age").to_pylist() == [30, 25]


def test_nullable_fields():
    data = [
        {"name": "Alice", "score": 95.5},
        {"name": "Bob", "score": None},
    ]
    buf = flatten_config_to_parquet(NULLABLE_CONFIG, data)
    table = pq.read_table(buf)

    assert table.column("score").to_pylist() == [95.5, None]
    assert table.schema.field("score").nullable


def test_equivalence_with_two_step():
    records = flatten_config(SIMPLE_CONFIG, SAMPLE_DATA)
    model = _build_model(SIMPLE_CONFIG)
    buf_two_step = to_parquet(records, model)
    buf_one_step = flatten_config_to_parquet(SIMPLE_CONFIG, SAMPLE_DATA)

    table_two = pq.read_table(buf_two_step)
    table_one = pq.read_table(buf_one_step)

    assert table_two.equals(table_one)
