"""Test empty explode array produces zero output records."""

from typing import Annotated

from pydantic import BaseModel

from maketab import Query, Explode
from .helpers import assert_flatten


items = Explode("items")


class LineItem(BaseModel):
    order_id: Annotated[int, Query("id")]
    item_name: Annotated[str, Query("name", items)]


TEST_EMPTY_ORDER = {"id": 1, "items": []}
TEST_MISSING_ITEMS = {"id": 2}


def test_empty_explode_array():
    """Empty explode array should produce zero output records."""
    assert_flatten([TEST_EMPTY_ORDER], LineItem, [])


# @pytest.mark.xfail(reason="Bug: code doesn't handle None when explode path missing")
def test_missing_explode_array():
    """Missing explode array (None) should produce zero output records."""
    assert_flatten([TEST_MISSING_ITEMS], LineItem, [])
