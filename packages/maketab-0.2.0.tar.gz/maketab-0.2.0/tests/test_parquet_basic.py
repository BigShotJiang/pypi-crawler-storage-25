from typing import Annotated, Optional

import pyarrow as pa
import pyarrow.parquet as pq
from pydantic import BaseModel

from maketab import Query, flatten
from maketab.parquet import to_parquet


class UserRow(BaseModel):
    name: Annotated[str, Query("name")]
    email: Annotated[Optional[str], Query("contact.email")]


class MixedTypes(BaseModel):
    s: Annotated[str, Query("s")]
    i: Annotated[int, Query("i")]
    f: Annotated[float, Query("f")]
    b: Annotated[bool, Query("b")]


def test_round_trip():
    data = [
        {"name": "Alice", "contact": {"email": "alice@test.com"}},
        {"name": "Bob", "contact": {"email": None}},
    ]
    rows = flatten(data, UserRow)
    buf = to_parquet(rows, UserRow)
    table = pq.read_table(buf)

    assert table.num_rows == 2
    assert table.column_names == ["name", "email"]
    assert table.column("name").to_pylist() == ["Alice", "Bob"]
    assert table.column("email").to_pylist() == ["alice@test.com", None]


def test_mixed_types_columns():
    data = [
        {"s": "hello", "i": 42, "f": 3.14, "b": True},
        {"s": "world", "i": 0, "f": -1.5, "b": False},
    ]
    rows = flatten(data, MixedTypes)
    buf = to_parquet(rows, MixedTypes)
    table = pq.read_table(buf)

    assert table.schema.field("s").type == pa.string()
    assert table.schema.field("i").type == pa.int64()
    assert table.schema.field("f").type == pa.float64()
    assert table.schema.field("b").type == pa.bool_()

    assert table.column("s").to_pylist() == ["hello", "world"]
    assert table.column("i").to_pylist() == [42, 0]
    assert table.column("f").to_pylist() == [3.14, -1.5]
    assert table.column("b").to_pylist() == [True, False]
