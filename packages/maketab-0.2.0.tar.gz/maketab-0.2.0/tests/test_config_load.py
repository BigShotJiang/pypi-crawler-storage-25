"""Test YAML config file loading."""

import pytest
import yaml

from maketab import SchemaConfig, load_config


def test_load_valid_yaml(tmp_path):
    config_file = tmp_path / "schema.yaml"
    config_file.write_text(
        "fields:\n" "  - name: id\n" "    type: int\n" "    query: id\n"
    )
    config = load_config(config_file)
    assert isinstance(config, SchemaConfig)
    assert len(config.fields) == 1
    assert config.fields[0].name == "id"


def test_load_with_query_roots(tmp_path):
    config_file = tmp_path / "schema.yaml"
    config_file.write_text(
        "query_roots:\n"
        "  - name: items\n"
        '    query: "items[*]"\n'
        "    explode: true\n"
        "fields:\n"
        "  - name: id\n"
        "    type: int\n"
        "    query: id\n"
        "  - name: item_name\n"
        "    type: str\n"
        "    query: name\n"
        "    root: items\n"
    )
    config = load_config(config_file)
    assert len(config.query_roots) == 1
    assert config.query_roots[0].explode is True


def test_load_file_not_found():
    with pytest.raises(FileNotFoundError, match="Config file not found"):
        load_config("/nonexistent/path/schema.yaml")


def test_load_invalid_yaml(tmp_path):
    config_file = tmp_path / "bad.yaml"
    config_file.write_text("fields:\n  - name: [unterminated")
    with pytest.raises(yaml.YAMLError):
        load_config(config_file)


def test_load_invalid_schema(tmp_path):
    config_file = tmp_path / "schema.yaml"
    config_file.write_text("fields: []")
    with pytest.raises(Exception):
        load_config(config_file)
