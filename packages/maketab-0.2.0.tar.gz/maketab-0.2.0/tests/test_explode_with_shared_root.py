"""Test multiple fields sharing the same Explode root stay zipped together."""

from typing import Annotated

from pydantic import BaseModel

from maketab import Query, Explode
from .helpers import assert_flatten


# Single Explode instance shared by multiple fields
items = Explode("line_items")


class InvoiceLine(BaseModel):
    invoice_id: Annotated[int, Query("id")]
    product: Annotated[str, Query("product", items)]
    quantity: Annotated[int, Query("qty", items)]
    unit_price: Annotated[float, Query("price", items)]


TEST_INVOICE = {
    "id": 100,
    "line_items": [
        {"product": "Apples", "qty": 5, "price": 1.50},
        {"product": "Oranges", "qty": 3, "price": 2.00},
        {"product": "Bananas", "qty": 10, "price": 0.75},
    ],
}


def test_shared_explode_root_zips_fields():
    """Fields sharing an Explode root should zip together, not cartesian product."""
    assert_flatten(
        [TEST_INVOICE],
        InvoiceLine,
        [
            InvoiceLine(invoice_id=100, product="Apples", quantity=5, unit_price=1.50),
            InvoiceLine(invoice_id=100, product="Oranges", quantity=3, unit_price=2.00),
            InvoiceLine(
                invoice_id=100, product="Bananas", quantity=10, unit_price=0.75
            ),
        ],
    )
