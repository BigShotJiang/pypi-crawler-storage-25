"""Tests for compound types: list[T], map[str, T], list[map[str, T]]."""

import datetime
from decimal import Decimal

import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from pydantic import ValidationError

from maketab import SchemaConfig, flatten_config
from maketab.config import _build_model
from maketab.parquet import to_parquet


def _make_config(
    type_str: str, nullable: bool = False, nullable_elements: bool = False
) -> SchemaConfig:
    return SchemaConfig.model_validate(
        {
            "fields": [
                {
                    "name": "val",
                    "type": type_str,
                    "query": "val",
                    "nullable": nullable,
                    "nullable_elements": nullable_elements,
                }
            ]
        }
    )


# ---- Phase 4: List types (US2) ----


class TestListTypes:
    @pytest.mark.parametrize(
        "prim,sample_data,arrow_element_type",
        [
            ("str", ["a", "b"], pa.string()),
            ("int", [1, 2, 3], pa.int64()),
            ("float", [1.1, 2.2], pa.float64()),
            ("bool", [True, False], pa.bool_()),
            ("date", ["2026-01-01", "2026-06-15"], pa.date32()),
            ("decimal", ["1.23", "4.56"], pa.decimal128(38, 18)),
        ],
    )
    def test_list_round_trip(self, prim, sample_data, arrow_element_type):
        config = _make_config(f"list[{prim}]")
        data = [{"val": sample_data}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        schema_type = table.schema.field("val").type
        assert isinstance(schema_type, pa.ListType)
        assert schema_type.value_type == arrow_element_type

    def test_list_timestamp_round_trip(self):
        config = _make_config("list[timestamp]")
        data = [{"val": ["2026-01-15T10:30:00Z", "2025-06-01T00:00:00+00:00"]}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        schema_type = table.schema.field("val").type
        assert isinstance(schema_type, pa.ListType)
        assert schema_type.value_type == pa.timestamp("us", tz="UTC")

    def test_empty_list_preserved(self):
        config = _make_config("list[str]")
        data = [{"val": []}]
        rows = flatten_config(config, data)
        assert rows[0].val == []
        model = _build_model(config)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist() == [[]]

    def test_null_list_when_nullable(self):
        config = _make_config("list[str]", nullable=True)
        data = [{"val": None}]
        rows = flatten_config(config, data)
        assert rows[0].val is None
        model = _build_model(config)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist() == [None]

    def test_null_elements_rejected_by_default(self):
        config = _make_config("list[int]")
        data = [{"val": [1, None, 3]}]
        with pytest.raises((ValidationError, Exception)):
            flatten_config(config, data)

    def test_null_elements_accepted_when_enabled(self):
        config = _make_config("list[int]", nullable_elements=True)
        data = [{"val": [1, None, 3]}]
        rows = flatten_config(config, data)
        assert rows[0].val == [1, None, 3]
        model = _build_model(config)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist() == [[1, None, 3]]


# ---- Phase 5: Map types (US3) ----


class TestMapTypes:
    @pytest.mark.parametrize(
        "prim,sample_data,arrow_value_type",
        [
            ("str", {"a": "x", "b": "y"}, pa.string()),
            ("int", {"count": 5, "total": 10}, pa.int64()),
            ("float", {"lat": 1.1, "lon": 2.2}, pa.float64()),
            ("bool", {"active": True, "deleted": False}, pa.bool_()),
            ("date", {"start": "2026-01-01"}, pa.date32()),
            ("decimal", {"amount": "9.99"}, pa.decimal128(38, 18)),
        ],
    )
    def test_map_round_trip(self, prim, sample_data, arrow_value_type):
        config = _make_config(f"map[str, {prim}]")
        data = [{"val": sample_data}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        schema_type = table.schema.field("val").type
        assert isinstance(schema_type, pa.MapType)
        assert schema_type.key_type == pa.string()

    def test_map_timestamp_round_trip(self):
        config = _make_config("map[str, timestamp]")
        data = [{"val": {"created": "2026-01-15T10:30:00Z"}}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        schema_type = table.schema.field("val").type
        assert isinstance(schema_type, pa.MapType)
        assert schema_type.item_type == pa.timestamp("us", tz="UTC")

    def test_empty_map_preserved(self):
        config = _make_config("map[str, str]")
        data = [{"val": {}}]
        rows = flatten_config(config, data)
        assert rows[0].val == {}
        model = _build_model(config)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        result = table.column("val").to_pylist()
        # Arrow maps serialize as list of (key, value) tuples
        assert result == [[]]

    def test_null_map_when_nullable(self):
        config = _make_config("map[str, str]", nullable=True)
        data = [{"val": None}]
        rows = flatten_config(config, data)
        assert rows[0].val is None
        model = _build_model(config)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist() == [None]

    def test_null_map_values_rejected_by_default(self):
        config = _make_config("map[str, str]")
        data = [{"val": {"a": "x", "b": None}}]
        with pytest.raises((ValidationError, Exception)):
            flatten_config(config, data)

    def test_null_map_values_accepted_when_enabled(self):
        config = _make_config("map[str, str]", nullable_elements=True)
        data = [{"val": {"a": "x", "b": None}}]
        rows = flatten_config(config, data)
        assert rows[0].val == {"a": "x", "b": None}


# ---- Phase 6: List-of-map types (US4) ----


class TestListMapTypes:
    @pytest.mark.parametrize(
        "prim,sample_data",
        [
            ("str", [{"k": "v"}, {"k2": "v2"}]),
            ("int", [{"count": 5}, {"total": 10}]),
        ],
    )
    def test_list_map_round_trip(self, prim, sample_data):
        config = _make_config(f"list[map[str, {prim}]]")
        data = [{"val": sample_data}]
        model = _build_model(config)
        rows = flatten_config(config, data)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        schema_type = table.schema.field("val").type
        assert isinstance(schema_type, pa.ListType)
        inner = schema_type.value_type
        assert isinstance(inner, pa.MapType)
        assert inner.key_type == pa.string()

    def test_empty_outer_list_preserved(self):
        config = _make_config("list[map[str, str]]")
        data = [{"val": []}]
        rows = flatten_config(config, data)
        assert rows[0].val == []
        model = _build_model(config)
        buf = to_parquet(rows, model)
        table = pq.read_table(buf)
        assert table.column("val").to_pylist() == [[]]

    def test_null_field_when_nullable(self):
        config = _make_config("list[map[str, str]]", nullable=True)
        data = [{"val": None}]
        rows = flatten_config(config, data)
        assert rows[0].val is None

    def test_nullable_elements_controls_map_values(self):
        config = _make_config("list[map[str, int]]", nullable_elements=True)
        data = [{"val": [{"a": 1, "b": None}]}]
        rows = flatten_config(config, data)
        assert rows[0].val == [{"a": 1, "b": None}]
