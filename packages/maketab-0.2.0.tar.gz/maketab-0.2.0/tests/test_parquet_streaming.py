from typing import Annotated

import pyarrow.parquet as pq
from pydantic import BaseModel

from maketab import Query, flatten
from maketab.parquet import to_parquet


class SimpleRow(BaseModel):
    name: Annotated[str, Query("name")]
    value: Annotated[int, Query("value")]


def test_file_like_interface():
    rows = flatten([{"name": "a", "value": 1}], SimpleRow)
    buf = to_parquet(rows, SimpleRow)

    assert buf.readable()
    assert buf.seekable()

    first_read = buf.read()
    assert len(first_read) > 0

    pos = buf.tell()
    assert pos == len(first_read)

    buf.seek(0)
    assert buf.tell() == 0

    second_read = buf.read()
    assert first_read == second_read


def test_parquet_magic_bytes():
    rows = flatten([{"name": "a", "value": 1}], SimpleRow)
    buf = to_parquet(rows, SimpleRow)
    data = buf.read()

    assert data[:4] == b"PAR1"
    assert data[-4:] == b"PAR1"


def test_large_dataset():
    input_data = [{"name": f"row_{i}", "value": i} for i in range(100_000)]
    rows = flatten(input_data, SimpleRow)
    buf = to_parquet(rows, SimpleRow)
    table = pq.read_table(buf)

    assert table.num_rows == 100_000
    assert table.column("value").to_pylist() == list(range(100_000))
