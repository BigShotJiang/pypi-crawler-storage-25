# maketab Development Guidelines

Auto-generated from all feature plans. Last updated: 2026-04-05

## Active Technologies
- Python 3.10+ + pydantic >=2.0.0, jmespath >=1.0.0, pyyaml >=6.0.0, pyarrow (new) (002-parquet-buffer-output)
- N/A (in-memory buffers only) (002-parquet-buffer-output)
- Python 3.10+ + pydantic >=2.0.0, jmespath >=1.0.0, pyarrow >=14.0.0, pyyaml >=6.0.0 (003-expand-type-support)
- Python 3.10+ + extual (new, optional extra), pydantic >=2.0.0, jmespath >=1.0.0, pyyaml >=6.0.0 (004-tui-schema-debugger)
- N/A (in-memory only, no persistence) (004-tui-schema-debugger)

- Python 3.10+ + pydantic >=2.0.0, jmespath >=1.0.0, pyyaml (new) (001-config-driven-schema)

## Project Structure

```text
src/
tests/
```

## Commands

cd src [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] pytest [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] ruff check .

## Code Style

Python 3.10+: Follow standard conventions

## Recent Changes
- 004-tui-schema-debugger: Added Python 3.10+ + extual (new, optional extra), pydantic >=2.0.0, jmespath >=1.0.0, pyyaml >=6.0.0
- 003-expand-type-support: Added Python 3.10+ + pydantic >=2.0.0, jmespath >=1.0.0, pyarrow >=14.0.0, pyyaml >=6.0.0
- 002-parquet-buffer-output: Added Python 3.10+ + pydantic >=2.0.0, jmespath >=1.0.0, pyyaml >=6.0.0, pyarrow (new)


<!-- MANUAL ADDITIONS START -->
<!-- MANUAL ADDITIONS END -->
