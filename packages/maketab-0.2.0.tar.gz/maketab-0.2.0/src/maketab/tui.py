"""Interactive TUI for testing and debugging maketab schema definitions.

Requires the 'tui' optional extra: pip install maketab[tui]
Launch via: maketab-tui or python -m maketab.tui
"""

import ast
import json
import traceback
from dataclasses import dataclass, field
from enum import Enum
from typing import Annotated, Any, Dict, List, Optional, Type

import yaml
from pydantic import BaseModel
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, RadioButton, RadioSet, Static, TextArea

from .config import SchemaConfig, flatten_config
from .core import Explode, Query, flatten


class SchemaFormat(Enum):
    YAML = "YAML"
    PYTHON = "Python"


class InputFormat(Enum):
    JSON = "JSON"
    PYTHON_DICT = "Python Dict"


@dataclass
class OutputField:
    name: str
    value: Any
    type: str


@dataclass
class OutputRow:
    fields: list[OutputField] = field(default_factory=list)


@dataclass
class EvaluationResult:
    success: bool
    rows: list[OutputRow] = field(default_factory=list)
    error: str = ""


def parse_yaml_schema(text: str) -> SchemaConfig:
    """Parse YAML text into a SchemaConfig."""
    raw = yaml.safe_load(text)
    return SchemaConfig.model_validate(raw)


def parse_python_schema(text: str) -> Type[BaseModel]:
    """Parse Python text defining a Pydantic model with Query/Explode annotations.

    Executes the text in a namespace pre-populated with maketab imports
    and returns the first BaseModel subclass found.
    """
    namespace: Dict[str, Any] = {
        "Query": Query,
        "Explode": Explode,
        "BaseModel": BaseModel,
        "Annotated": Annotated,
        "Optional": Optional,
        "List": List,
    }
    exec(text, namespace)  # noqa: S102
    for obj in namespace.values():
        if (
            isinstance(obj, type)
            and issubclass(obj, BaseModel)
            and obj is not BaseModel
        ):
            return obj
    raise ValueError("No BaseModel subclass found in the provided Python code")


def parse_json_input(text: str) -> dict:
    """Parse JSON text into a dict."""
    return json.loads(text, parse_float=str)


def parse_python_dict_input(text: str) -> dict:
    """Parse Python dict literal text into a dict."""
    result = ast.literal_eval(text)
    if not isinstance(result, dict):
        raise ValueError(f"Expected a dict, got {type(result).__name__}")
    return result


def evaluate(
    schema_text: str,
    schema_format: SchemaFormat,
    input_text: str,
    input_format: InputFormat,
) -> EvaluationResult:
    """Parse schema and input, run flattening, return result or error traceback."""
    try:
        if not schema_text.strip():
            return EvaluationResult(
                success=False,
                error="Schema is empty. Enter a schema definition in the left pane.",
            )
        if not input_text.strip():
            return EvaluationResult(
                success=False,
                error="Input is empty. Enter an input record in the top-right pane.",
            )

        if input_format == InputFormat.JSON:
            record = parse_json_input(input_text)
        else:
            record = parse_python_dict_input(input_text)

        if schema_format == SchemaFormat.YAML:
            config = parse_yaml_schema(schema_text)
            results = flatten_config(config, [record])
        else:
            model_cls = parse_python_schema(schema_text)
            results = flatten([record], model_cls)

        rows = []
        for result in results:
            fields = []
            for name, value in result.model_dump().items():
                fields.append(
                    OutputField(
                        name=name,
                        value=value,
                        type=type(value).__name__ if value is not None else "NoneType",
                    )
                )
            rows.append(OutputRow(fields=fields))

        return EvaluationResult(success=True, rows=rows)

    except Exception:
        return EvaluationResult(success=False, error=traceback.format_exc())


def format_output(result: EvaluationResult) -> str:
    """Format an EvaluationResult as display text."""
    if not result.success:
        return result.error

    if not result.rows:
        return "No output rows produced."

    # Build table
    headers = ["Field Name", "Value", "Type"]
    all_field_data: list[list[str]] = []
    for i, row in enumerate(result.rows):
        if i > 0:
            all_field_data.append(["---", "---", "---"])
        for f in row.fields:
            all_field_data.append([f.name, repr(f.value), f.type])

    col_widths = [len(h) for h in headers]
    for row_data in all_field_data:
        for j, cell in enumerate(row_data):
            col_widths[j] = max(col_widths[j], len(cell))

    def fmt_row(cells: list[str]) -> str:
        return " | ".join(cell.ljust(col_widths[j]) for j, cell in enumerate(cells))

    lines = [fmt_row(headers)]
    lines.append("-+-".join("-" * w for w in col_widths))
    for row_data in all_field_data:
        if row_data == ["---", "---", "---"]:
            lines.append("-+-".join("-" * w for w in col_widths))
        else:
            lines.append(fmt_row(row_data))

    return "\n".join(lines)


YAML_PLACEHOLDER = """\
fields:
  - name: user_name
    type: str
    query: user.name
  - name: email
    type: str
    query: user.email
"""

JSON_PLACEHOLDER = """\
{"user": {"name": "Alice", "email": "alice@example.com"}}
"""

OUTPUT_PLACEHOLDER = "Press Ctrl+R to evaluate the schema against the input record."

APP_CSS = """
Screen {
    layout: horizontal;
}

#left-pane {
    width: 1fr;
    height: 100%;
    border: solid $primary;
}

#right-pane {
    width: 1fr;
    height: 100%;
    layout: vertical;
}

#input-pane {
    height: 1fr;
    border: solid $primary;
}

#output-pane {
    height: 1fr;
    border: solid $accent;
}

.pane-header {
    dock: top;
    height: 1;
    background: $boost;
    color: $text;
    text-style: bold;
    padding: 0 1;
}

.toggle-set {
    dock: top;
    height: 3;
    layout: horizontal;
}

.toggle-set RadioSet {
    height: 3;
    width: auto;
}

#schema-editor {
    height: 1fr;
}

#input-editor {
    height: 1fr;
}

#output-display {
    height: 1fr;
    overflow-y: auto;
    padding: 0 1;
}
"""


class MaketabTUI(App):
    """Interactive TUI for testing maketab schema definitions."""

    CSS = APP_CSS
    TITLE = "maketab TUI"

    BINDINGS = [
        Binding("ctrl+r", "run_eval", "Run", show=True),
        Binding("ctrl+d", "quit", "Quit", show=True),
    ]

    schema_format: SchemaFormat = SchemaFormat.YAML
    input_format: InputFormat = InputFormat.JSON

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal():
            with Vertical(id="left-pane"):
                yield Static("Schema Definition", classes="pane-header")
                with RadioSet(id="schema-toggle", classes="toggle-set"):
                    yield RadioButton("YAML", value=True)
                    yield RadioButton("Python")
                yield TextArea(YAML_PLACEHOLDER, id="schema-editor", language="yaml")
            with Vertical(id="right-pane"):
                with Vertical(id="input-pane"):
                    yield Static("Input Record", classes="pane-header")
                    with RadioSet(id="input-toggle", classes="toggle-set"):
                        yield RadioButton("JSON", value=True)
                        yield RadioButton("Python Dict")
                    yield TextArea(JSON_PLACEHOLDER, id="input-editor", language="json")
                with Vertical(id="output-pane"):
                    yield Static("Output", classes="pane-header")
                    yield TextArea(
                        OUTPUT_PLACEHOLDER, id="output-display", read_only=True
                    )
        yield Footer()

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        if event.radio_set.id == "schema-toggle":
            if event.index == 0:
                self.schema_format = SchemaFormat.YAML
                self.query_one("#schema-editor", TextArea).language = "yaml"
            else:
                self.schema_format = SchemaFormat.PYTHON
                self.query_one("#schema-editor", TextArea).language = "python"
        elif event.radio_set.id == "input-toggle":
            if event.index == 0:
                self.input_format = InputFormat.JSON
                self.query_one("#input-editor", TextArea).language = "json"
            else:
                self.input_format = InputFormat.PYTHON_DICT
                self.query_one("#input-editor", TextArea).language = "python"

    def action_run_eval(self) -> None:
        schema_text = self.query_one("#schema-editor", TextArea).text
        input_text = self.query_one("#input-editor", TextArea).text

        result = evaluate(
            schema_text, self.schema_format, input_text, self.input_format
        )
        output_text = format_output(result)

        output_display = self.query_one("#output-display", TextArea)
        output_display.clear()
        output_display.insert(output_text)


def main() -> None:
    """Entry point for the maketab TUI."""
    app = MaketabTUI()
    app.run()


if __name__ == "__main__":
    main()
