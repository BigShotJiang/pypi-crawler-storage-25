from dataclasses import dataclass
import itertools
from typing import (
    Any,
    Callable,
    Dict,
    Generator,
    Iterable,
    Iterator,
    List,
    Type,
    TypeVar,
)
import jmespath
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)
I = TypeVar("I")
K = TypeVar("K")


class NoValueSentinel:
    pass


@dataclass
class Explode:
    query_string: str


@dataclass
class Query:
    query_string: str
    root: "Explode | Query | None" = None


@dataclass
class _FieldValue:
    name: str
    value: Any
    do_product: bool = False
    group: int | None = None


QueryType = Query | Explode
query_types = (Query, Explode)


def _get_queries(output_schema: Type[T]) -> Dict[str, QueryType]:
    queries = {}
    for field_name, field_info in output_schema.model_fields.items():
        query = next(
            (
                annotation
                for annotation in field_info.metadata
                if isinstance(annotation, query_types)
            ),
            None,
        )
        if query is None:
            raise ValueError(f"Model field '{field_name}' does not specify a query")
        queries[field_name] = query
    return queries


def _get_field_values(record: Dict, queries: Dict[str, QueryType]) -> List[_FieldValue]:
    values = []
    query_roots = {}
    for field_name, field_query in queries.items():
        if isinstance(field_query, Query):
            if field_query.root is None:
                field_value = _FieldValue(
                    name=field_name,
                    value=jmespath.search(field_query.query_string, record),
                )
            else:
                root_id = id(field_query.root)
                query_root = query_roots.get(root_id, NoValueSentinel)

                if query_root is NoValueSentinel:
                    query_root = jmespath.search(field_query.root.query_string, record)
                    query_roots[root_id] = query_root

                if query_root is None:
                    value = None
                elif isinstance(field_query.root, Explode):
                    value = [
                        jmespath.search(field_query.query_string, root_entry)
                        for root_entry in query_root
                    ]
                else:
                    value = jmespath.search(field_query.query_string, query_root)

                field_value = _FieldValue(
                    name=field_name,
                    value=value,
                    do_product=isinstance(field_query.root, Explode),
                    group=root_id,
                )

        elif isinstance(field_query, Explode):
            field_value = _FieldValue(
                name=field_name,
                value=jmespath.search(field_query.query_string, record),
                do_product=True,
            )
        else:
            raise RuntimeError(f"Unknown field_query type: {type(field_query)}")
        values.append(field_value)
    return values


def groupby_with_none_as_unique(
    iterable: Iterable[I], key: Callable[[I], K | None]
) -> Generator[tuple[K | None, Iterator[I]], None, None]:
    """Like groupby but None keys don't group together."""
    for k, g in itertools.groupby(iterable, key=key):
        if k is None:
            # Yield each item as its own group
            for item in g:
                yield k, iter([item])
        else:
            yield k, g


def _get_output_records(
    input_values: List[_FieldValue], output_schema: Type[T]
) -> List[T]:
    output_raw: List[Dict] = [{}]
    grouped_values = groupby_with_none_as_unique(input_values, lambda fv: fv.group)

    for _, group in grouped_values:
        group = list(group)
        do_product = group[
            0
        ].do_product  # todo: bit implicitly coupled to field value fetching, improve
        if do_product:
            exploded_records = [
                # Basically we're doing this shift:
                #   fv1(name=name1, value=[v1a, v1b])
                #   fv2(name=name2, value=[v2a, v2b])
                #   -> [{name1: v1a, name2: v2a}, {name1: v1b, name2: v2b}]
                dict(r)
                for r in zip(
                    *[
                        [
                            (fv.name, v)
                            for v in (
                                fv.value if fv.value is not None else []
                            )  # protect against the potential that explode root is None
                        ]
                        for fv in group
                    ]
                )
            ]
            new_output_raw = []
            for existing_record, exploded_record in itertools.product(
                output_raw, exploded_records
            ):
                new_output_raw.append(
                    {
                        **existing_record,
                        **exploded_record,
                    }
                )
            output_raw = new_output_raw
        else:
            group_values = {fv.name: fv.value for fv in group}
            output_raw = [{**record, **group_values} for record in output_raw]

    return [output_schema.model_validate(_or) for _or in output_raw]


def flatten(data: List[Dict], output_schema: Type[T]) -> List[T]:
    output: List[T] = []
    queries = _get_queries(output_schema)
    for record in data:
        values = _get_field_values(record, queries)
        output.extend(
            _get_output_records(values, output_schema),
        )
    return output
