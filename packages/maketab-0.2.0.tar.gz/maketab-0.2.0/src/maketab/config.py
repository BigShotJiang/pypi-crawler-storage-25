"""Config-driven schema definition and flattening.

Allows defining output schemas declaratively (via dicts or YAML files)
instead of writing Pydantic model classes with Annotated metadata.
"""

import datetime
from decimal import Decimal
from pathlib import Path
from typing import Annotated, Dict, List, Optional, Type

import yaml
from pydantic import BaseModel, create_model, field_validator, model_validator

from .core import Explode, Query, flatten


SUPPORTED_TYPES: Dict[str, type] = {
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "timestamp": datetime.datetime,
    "date": datetime.date,
    "decimal": Decimal,
}

_COMPOUND_HELP = (
    "or a compound type: list[<type>], map[str, <type>], list[map[str, <type>]]"
)


def _parse_type_string(type_str: str) -> tuple[str, str | None]:
    """Parse a type string into (primitive_name, compound_kind).

    Returns:
        A tuple of (primitive_name, compound_kind) where compound_kind is one of
        None (bare primitive), "list", "map", or "list_map".

    Raises:
        ValueError: If the type string is invalid syntax or uses an unsupported primitive.
    """
    s = type_str.strip()

    if s.startswith("list[map[") and s.endswith("]]"):
        inner = s[len("list[map[") : -2]
        parts = [p.strip() for p in inner.split(",", 1)]
        if len(parts) != 2 or parts[0] != "str":
            raise ValueError(
                f"unsupported type '{type_str}': map key must be 'str', "
                f"e.g. list[map[str, int]]"
            )
        prim = parts[1]
        if prim not in SUPPORTED_TYPES:
            supported = ", ".join(sorted(SUPPORTED_TYPES))
            raise ValueError(
                f"unsupported type '{type_str}': unknown primitive '{prim}', "
                f"must be one of: {supported}"
            )
        return prim, "list_map"

    if s.startswith("list[") and s.endswith("]"):
        inner = s[len("list[") : -1].strip()
        if not inner:
            raise ValueError(f"unsupported type '{type_str}': empty list element type")
        if inner.startswith("list["):
            raise ValueError(
                f"unsupported type '{type_str}': nested lists are not supported. "
                f"Supported compound types: list[<type>], map[str, <type>], "
                f"list[map[str, <type>]]"
            )
        if inner not in SUPPORTED_TYPES:
            supported = ", ".join(sorted(SUPPORTED_TYPES))
            raise ValueError(
                f"unsupported type '{type_str}': unknown primitive '{inner}', "
                f"must be one of: {supported}"
            )
        return inner, "list"

    if s.startswith("map[") and s.endswith("]"):
        inner = s[len("map[") : -1]
        parts = [p.strip() for p in inner.split(",", 1)]
        if len(parts) != 2:
            raise ValueError(
                f"unsupported type '{type_str}': map requires two arguments, "
                f"e.g. map[str, int]"
            )
        if parts[0] != "str":
            raise ValueError(
                f"unsupported type '{type_str}': map key must be 'str', "
                f"e.g. map[str, int]"
            )
        prim = parts[1].strip()
        if prim.startswith("list["):
            raise ValueError(
                f"unsupported type '{type_str}': nested compound types in map values "
                f"are not supported. Use list[map[str, <type>]] instead"
            )
        if prim not in SUPPORTED_TYPES:
            supported = ", ".join(sorted(SUPPORTED_TYPES))
            raise ValueError(
                f"unsupported type '{type_str}': unknown primitive '{prim}', "
                f"must be one of: {supported}"
            )
        return prim, "map"

    if s in SUPPORTED_TYPES:
        return s, None

    supported = ", ".join(sorted(SUPPORTED_TYPES))
    raise ValueError(
        f"unsupported type '{type_str}', must be one of: {supported}\n"
        f"{_COMPOUND_HELP}"
    )


class QueryRoot(BaseModel):
    """A named, reusable query root that fields can reference."""

    name: str
    query: str
    explode: bool

    @field_validator("name", "query")
    @classmethod
    def must_be_non_empty(cls, v: str, info) -> str:
        if not v.strip():
            raise ValueError(f"'{info.field_name}' must be non-empty")
        return v


class FieldConfig(BaseModel):
    """A single output field definition."""

    name: str
    type: str
    query: str
    root: Optional[str] = None
    nullable: bool = False
    nullable_elements: bool = False

    @field_validator("name", "query")
    @classmethod
    def must_be_non_empty(cls, v: str, info) -> str:
        if not v.strip():
            raise ValueError(f"'{info.field_name}' must be non-empty")
        return v

    @field_validator("type")
    @classmethod
    def must_be_supported_type(cls, v: str) -> str:
        _parse_type_string(v)
        return v

    @model_validator(mode="after")
    def validate_nullable_elements(self) -> "FieldConfig":
        _, compound_kind = _parse_type_string(self.type)
        if self.nullable_elements and compound_kind is None:
            raise ValueError(
                f"'nullable_elements' is only valid for compound types "
                f"(list, map, list[map]), not for primitive type '{self.type}'"
            )
        return self


class SchemaConfig(BaseModel):
    """Top-level config defining query roots and output fields."""

    query_roots: List[QueryRoot] = []
    fields: List[FieldConfig]

    @model_validator(mode="after")
    def validate_config(self) -> "SchemaConfig":
        if len(self.fields) < 1:
            raise ValueError("'fields' must contain at least one entry")

        root_names = [r.name for r in self.query_roots]
        dupes = [n for n in root_names if root_names.count(n) > 1]
        if dupes:
            raise ValueError(
                f"duplicate query root names: {', '.join(sorted(set(dupes)))}"
            )

        field_names = [f.name for f in self.fields]
        dupes = [n for n in field_names if field_names.count(n) > 1]
        if dupes:
            raise ValueError(f"duplicate field names: {', '.join(sorted(set(dupes)))}")

        root_name_set = set(root_names)
        for field in self.fields:
            if field.root is not None and field.root not in root_name_set:
                raise ValueError(
                    f"field '{field.name}' references undefined "
                    f"query root '{field.root}'"
                )

        return self


def _resolve_type(
    type_str: str, nullable: bool, nullable_elements: bool = False
) -> type:
    """Map a type string and nullable flag to a Python type."""
    prim_name, compound_kind = _parse_type_string(type_str)
    base = SUPPORTED_TYPES[prim_name]
    element_type = Optional[base] if nullable_elements else base

    if compound_kind is None:
        result = base
    elif compound_kind == "list":
        result = list[element_type]
    elif compound_kind == "map":
        result = dict[str, element_type]
    elif compound_kind == "list_map":
        result = list[dict[str, element_type]]
    else:
        raise ValueError(f"unknown compound kind: {compound_kind}")

    if nullable:
        return Optional[result]
    return result


def _build_model(config: SchemaConfig) -> Type[BaseModel]:
    """Dynamically generate a Pydantic model from a SchemaConfig."""
    roots_by_name: Dict[str, QueryRoot] = {r.name: r for r in config.query_roots}

    # Build shared root annotation objects (one per named root)
    # so fields sharing the same root get the same object identity.
    root_annotations: Dict[str, Query | Explode] = {}
    for root_cfg in config.query_roots:
        if root_cfg.explode:
            root_annotations[root_cfg.name] = Explode(root_cfg.query)
        else:
            root_annotations[root_cfg.name] = Query(root_cfg.query)

    field_definitions = {}
    for field in config.fields:
        python_type = _resolve_type(field.type, field.nullable, field.nullable_elements)

        if field.root is not None:
            annotation = Query(field.query, root=root_annotations[field.root])
        else:
            annotation = Query(field.query)

        annotated_type = Annotated[python_type, annotation]
        default = None if field.nullable else ...
        field_definitions[field.name] = (annotated_type, default)

    return create_model("DynamicSchema", **field_definitions)


def flatten_config(config: SchemaConfig, data: List[Dict]) -> List[BaseModel]:
    """Flatten nested data using a config-driven schema.

    Args:
        config: A SchemaConfig defining output fields and queries.
        data: List of nested dictionaries to flatten.

    Returns:
        List of dynamically generated Pydantic model instances.
    """
    model = _build_model(config)
    return flatten(data, model)


def load_config(path: str | Path) -> SchemaConfig:
    """Load a SchemaConfig from a YAML file.

    Args:
        path: Path to the YAML config file.

    Returns:
        A validated SchemaConfig instance.

    Raises:
        FileNotFoundError: If the file does not exist.
        yaml.YAMLError: If the file contains invalid YAML.
        ValidationError: If the parsed content fails schema validation.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path) as f:
        raw = yaml.safe_load(f)
    return SchemaConfig.model_validate(raw)
