"""Parquet output for flattened data.

Converts lists of Pydantic model instances into in-memory Parquet buffers,
enabling streaming to downstream tools without intermediate file I/O.
"""

import datetime
import io
from decimal import Decimal
from typing import Dict, List, Type, TypeVar, get_args, get_origin, Union

import pyarrow as pa
import pyarrow.parquet as pq
from pydantic import BaseModel

from .config import SchemaConfig, _build_model, flatten_config

T = TypeVar("T", bound=BaseModel)

_TYPE_MAP: Dict[type, pa.DataType] = {
    str: pa.string(),
    int: pa.int64(),
    float: pa.float64(),
    bool: pa.bool_(),
    datetime.datetime: pa.timestamp("us", tz="UTC"),
    datetime.date: pa.date32(),
    Decimal: pa.decimal128(38, 18),
}


def _is_optional(annotation: type) -> tuple[type, bool]:
    """Unwrap Optional[T] to (T, True) or return (annotation, False)."""
    origin = get_origin(annotation)
    if origin is Union:
        args = get_args(annotation)
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1 and type(None) in args:
            return non_none[0], True
    return annotation, False


def _resolve_arrow_type(python_type: type) -> pa.DataType:
    """Resolve a Python type (possibly generic) to a PyArrow DataType."""
    # Direct primitive lookup
    arrow_type = _TYPE_MAP.get(python_type)
    if arrow_type is not None:
        return arrow_type

    origin = get_origin(python_type)
    args = get_args(python_type)

    # list[T] or list[Optional[T]]
    if origin is list and len(args) == 1:
        inner_type, inner_nullable = _is_optional(args[0])
        inner_arrow = _resolve_arrow_type(inner_type)
        return pa.list_(pa.field("item", inner_arrow, nullable=inner_nullable))

    # dict[str, T] or dict[str, Optional[T]]
    if origin is dict and len(args) == 2 and args[0] is str:
        value_type, value_nullable = _is_optional(args[1])
        value_arrow = _resolve_arrow_type(value_type)
        return pa.map_(
            pa.string(),
            pa.field("value", value_arrow, nullable=value_nullable),
        )

    raise ValueError(f"unsupported type '{python_type}'")


def _get_arrow_schema(output_schema: Type[T]) -> pa.Schema:
    """Derive an Arrow schema from a Pydantic model class."""
    fields = []
    for field_name, field_info in output_schema.model_fields.items():
        annotation = field_info.annotation
        base_type, nullable = _is_optional(annotation)
        try:
            arrow_type = _resolve_arrow_type(base_type)
        except ValueError:
            supported = ", ".join(t.__name__ for t in _TYPE_MAP)
            raise ValueError(
                f"field '{field_name}' has unsupported type '{base_type}', "
                f"must be one of: {supported}\n"
                f"or a compound type: list[T], dict[str, T], list[dict[str, T]]"
            )
        fields.append(pa.field(field_name, arrow_type, nullable=nullable))
    return pa.schema(fields)


def to_parquet(records: List[T], output_schema: Type[T]) -> io.BytesIO:
    """Convert a list of Pydantic model instances to an in-memory Parquet buffer.

    Args:
        records: List of Pydantic model instances (e.g. output of ``flatten``).
        output_schema: The Pydantic model class used to derive the Parquet schema.

    Returns:
        A ``BytesIO`` buffer containing valid Parquet data, with seek position at 0.

    Raises:
        ValueError: If a field type in the model is not in the supported type mapping.
    """
    schema = _get_arrow_schema(output_schema)
    field_names = list(output_schema.model_fields.keys())

    columns: Dict[str, list] = {name: [] for name in field_names}
    for record in records:
        dumped = record.model_dump()
        for name in field_names:
            columns[name].append(dumped[name])

    arrays = [
        pa.array(columns[name], type=schema.field(name).type) for name in field_names
    ]
    table = pa.table(dict(zip(field_names, arrays)), schema=schema)

    buf = io.BytesIO()
    pq.write_table(table, buf)
    buf.seek(0)
    return buf


def flatten_config_to_parquet(config: SchemaConfig, data: List[Dict]) -> io.BytesIO:
    """Flatten nested data and convert to an in-memory Parquet buffer in one step.

    Args:
        config: A ``SchemaConfig`` defining output fields and queries.
        data: List of nested dictionaries to flatten.

    Returns:
        A ``BytesIO`` buffer containing valid Parquet data, with seek position at 0.

    Raises:
        ValueError: If a field type in the config is not in the supported type mapping.
    """
    model = _build_model(config)
    records = flatten_config(config, data)
    return to_parquet(records, model)
