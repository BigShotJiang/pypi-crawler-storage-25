# Public API Contract: Config Module

## New Public Symbols (added to `maketab/__init__.py`)

### `SchemaConfig` (Pydantic model)

Top-level config object. Constructed via `SchemaConfig(...)` or
`SchemaConfig.model_validate(dict)`.

**Fields**:
- `query_roots: List[QueryRoot]` — default `[]`
- `fields: List[FieldConfig]` — required, min length 1

**Validation** (raises `ValidationError`):
- `fields` must have at least one entry
- All query root names must be unique
- All field names must be unique
- All field `root` references must match a defined query root name

### `QueryRoot` (Pydantic model)

**Fields**:
- `name: str` — required, non-empty
- `query: str` — required, non-empty
- `explode: bool` — required

### `FieldConfig` (Pydantic model)

**Fields**:
- `name: str` — required, non-empty
- `type: str` — required, one of `"str"`, `"int"`, `"float"`, `"bool"`
- `query: str` — required, non-empty
- `root: Optional[str]` — default `None`
- `nullable: bool` — default `False`

### `flatten_config(config: SchemaConfig, data: List[Dict]) -> List[BaseModel]`

Generates a dynamic Pydantic model from `config` and delegates to
`flatten(data, DynamicModel)`. Returns the list of dynamic model
instances.

**Raises**:
- `ValidationError` if any record fails Pydantic type validation
  (same behavior as `flatten`)

### `load_config(path: str | Path) -> SchemaConfig`

Reads a YAML file, parses it with `yaml.safe_load()`, and returns
a validated `SchemaConfig` instance.

**Raises**:
- `FileNotFoundError` if path does not exist
- `yaml.YAMLError` if file has invalid YAML syntax
- `ValidationError` if parsed content fails SchemaConfig validation
