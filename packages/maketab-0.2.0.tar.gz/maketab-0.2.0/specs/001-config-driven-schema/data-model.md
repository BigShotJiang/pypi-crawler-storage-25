# Data Model: Config-Driven Output Schema

## Entities

### QueryRoot

A named, reusable query definition that serves as the evaluation
context for one or more fields.

| Attribute    | Type   | Required | Description                                      |
|--------------|--------|----------|--------------------------------------------------|
| name         | str    | yes      | Unique identifier referenced by fields           |
| query        | str    | yes      | JMESPath expression evaluated against each record |
| explode      | bool   | yes      | If true, produces one row per array element       |

**Validation rules**:
- `name` MUST be non-empty and unique within the `query_roots` list.
- `query` MUST be a non-empty string (syntactic validity is deferred
  to JMESPath at evaluation time).

### FieldConfig

A single output column definition.

| Attribute    | Type          | Required | Description                                    |
|--------------|---------------|----------|------------------------------------------------|
| name         | str           | yes      | Output field/column name                       |
| type         | str           | yes      | Python type name: "str", "int", "float", "bool"|
| query        | str           | yes      | JMESPath expression for extraction             |
| root         | str or None   | no       | Name of a QueryRoot to use as evaluation context|
| nullable     | bool          | no       | If true, wraps type as Optional (default false)|

**Validation rules**:
- `name` MUST be non-empty and unique across all fields.
- `type` MUST be one of the supported type strings.
- `query` MUST be non-empty.
- If `root` is specified, it MUST reference a name defined in
  `query_roots`.
- Fields without a `root` that are not themselves explode-typed
  evaluate their query directly against each input record.

**Query mode mapping** (config → annotation):
- No `root`, field not in an explode context → `Query(query_string)`
- Field itself acts as explode (not directly supported — use a
  QueryRoot with `explode: true` and reference it)
- `root` references a QueryRoot with `explode: false` →
  `Query(query_string, root=Query(root.query))`
- `root` references a QueryRoot with `explode: true` →
  `Query(query_string, root=Explode(root.query))`

### SchemaConfig

The top-level config object.

| Attribute    | Type              | Required | Description                        |
|--------------|-------------------|----------|------------------------------------|
| query_roots  | List[QueryRoot]   | no       | Named root queries (default: [])   |
| fields       | List[FieldConfig] | yes      | Output field definitions           |

**Validation rules**:
- `fields` MUST contain at least one entry.
- All `query_roots` names MUST be unique.
- All `fields` names MUST be unique.
- All field `root` references MUST resolve to a defined query root.

## Relationships

```text
SchemaConfig
├── query_roots: List[QueryRoot]  (0..N, names unique)
└── fields: List[FieldConfig]     (1..N, names unique)
       └── root? ──references──> QueryRoot.name
```

## YAML Representation

```yaml
query_roots:
  - name: order_items
    query: "order.items[*]"
    explode: true
  - name: metadata
    query: "order.metadata"
    explode: false

fields:
  - name: order_id
    type: int
    query: "order.id"
  - name: item_name
    type: str
    query: "name"
    root: order_items
  - name: item_price
    type: float
    query: "price"
    root: order_items
  - name: region
    type: str
    query: "region"
    root: metadata
```
