# Research: Config-Driven Output Schema

## Dynamic Pydantic Model Generation

**Decision**: Use `pydantic.create_model()` to generate output models at
runtime from config.

**Rationale**: `create_model()` fully supports `Annotated` field types
with custom metadata. Metadata items (e.g., `Query`, `Explode`) are
preserved in `field_info.metadata` identically to statically-defined
models. The existing `_get_queries()` function works without modification
on dynamically created models.

**Alternatives considered**:
- Manual `type()` metaclass construction: more complex, no Pydantic
  validation benefits.
- Template-based code generation (write .py files): unnecessary
  complexity, filesystem side effects.

**Field definition format for `create_model()`**:
```python
create_model('Name', field_name=(Annotated[int, Query("path")], ...))
```
The `...` (Ellipsis) marks the field as required. For Optional types,
use `(Annotated[Optional[str], Query("path")], None)`.

## Type String Mapping

**Decision**: Simple dict mapping from string names to Python types.
Supported: `str`, `int`, `float`, `bool`, plus `Optional[T]` variants
expressed as `nullable: true` on the field config.

**Rationale**: A fixed map is sufficient for the initial scope (scalar
types only). No need for `eval()` or AST parsing. The map is easy to
extend later.

**Alternatives considered**:
- `eval()` or `ast.literal_eval()`: security risk, overly permissive.
- Full type expression parser: over-engineered for scalar-only scope.

## YAML File Loading

**Decision**: Use `pyyaml` with `yaml.safe_load()` for reading config
files.

**Rationale**: `safe_load()` prevents arbitrary code execution from YAML.
Returns native Python dicts/lists that can be passed directly to
Pydantic's `model_validate()` for config parsing.

**Alternatives considered**:
- JSON via stdlib: decided against in clarification — YAML is more
  human-friendly for config authoring.
- TOML via stdlib `tomllib` (3.11+): requires Python 3.11+, project
  supports 3.10+.

## Compatibility with Existing `flatten`

**Decision**: No changes to `core.py`. The wrapper function generates a
model and calls `flatten(data, DynamicModel)` directly.

**Rationale**: Tested that `_get_queries()` iterates `model_fields` and
extracts `metadata` — this works identically for dynamic models.
`_get_field_values()` and `_get_output_records()` operate on the model
type, not on how it was defined.

## Gotchas Identified

- Dynamic model validators via `__validators__` dict are unreliable in
  Pydantic v2. Not needed here — validation is handled by Pydantic's
  built-in type coercion and the config model's own validators.
- Forward references require `model_rebuild()`. Not applicable here
  since all field types are concrete scalars.
- `field_info.annotation` returns the unwrapped type (not wrapped in
  Annotated). This is correct behavior and matches static models.
