# Tasks: Config-Driven Output Schema

**Input**: Design documents from `/specs/001-config-driven-schema/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Included — constitution Principle III mandates tests for all user-facing behavior.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Phase 1: Setup

**Purpose**: Add new dependency and create module skeleton

- [x] T001 Add pyyaml dependency in pyproject.toml
- [x] T002 Create src/maketab/config.py with module docstring and imports

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Implement the config Pydantic models that all user stories depend on

**CRITICAL**: No user story work can begin until these models exist

- [x] T003 Implement QueryRoot Pydantic model in src/maketab/config.py (fields: name, query, explode; non-empty string validators)
- [x] T004 Implement FieldConfig Pydantic model in src/maketab/config.py (fields: name, type, query, root, nullable; type validator restricting to str/int/float/bool)
- [x] T005 Implement SchemaConfig Pydantic model in src/maketab/config.py (fields: query_roots, fields; min-length-1 validator on fields, unique name validators, root-reference cross-validator)
- [x] T006 Implement type string mapping helper _resolve_type() in src/maketab/config.py (maps type string + nullable flag to Python type or Optional variant)

**Checkpoint**: Config models validated — can construct SchemaConfig from dicts and YAML-parsed data

---

## Phase 3: User Story 1 - Flatten Data Using a Config (Priority: P1)

**Goal**: Users can flatten nested data by providing a SchemaConfig instead of writing a Pydantic model

**Independent Test**: Provide config + sample data, assert returned model instances match expected values

### Tests for User Story 1

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [x] T007 [P] [US1] Test simple queries via config in tests/test_config_simple.py (3 scalar fields, no roots, verify attribute access on returned BaseModel instances)
- [x] T008 [P] [US1] Test explode via config in tests/test_config_explode.py (query root with explode: true, verify row multiplication)
- [x] T009 [P] [US1] Test query-with-root via config in tests/test_config_root.py (explode root + non-explode root, verify root-relative resolution matches annotation-based output)

### Implementation for User Story 1

- [x] T010 [US1] Implement _build_model() in src/maketab/config.py (uses pydantic.create_model with Annotated[type, Query/Explode] fields derived from SchemaConfig; resolves query roots to Query/Explode objects)
- [x] T011 [US1] Implement flatten_config() in src/maketab/config.py (calls _build_model then delegates to flatten from core; returns List[BaseModel])
- [x] T012 [US1] Export new public symbols in src/maketab/__init__.py (add SchemaConfig, FieldConfig, QueryRoot, flatten_config to __all__)

**Checkpoint**: flatten_config works for all query modes — simple, explode, query-with-root

---

## Phase 4: User Story 2 - Validation Errors for Invalid Configs (Priority: P2)

**Goal**: Malformed configs produce clear, actionable validation errors before data processing

**Independent Test**: Provide invalid configs, assert specific ValidationError messages

### Tests for User Story 2

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [x] T013 [P] [US2] Test validation errors in tests/test_config_validation.py: missing query field, unsupported type name, duplicate field names, duplicate root names, undefined root reference, zero fields, empty field name, empty query string

### Implementation for User Story 2

- [x] T014 [US2] Add/refine Pydantic validators on SchemaConfig in src/maketab/config.py (ensure error messages include field names and human-readable explanations per FR-007; add duplicate field name check, type name listing in error)

**Checkpoint**: All invalid config scenarios produce clear errors with field names

---

## Phase 5: User Story 3 - Load Config from YAML File (Priority: P3)

**Goal**: Users can load a SchemaConfig from a YAML file on disk

**Independent Test**: Write YAML to temp file, load it, verify identical to in-memory config

### Tests for User Story 3

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [x] T015 [P] [US3] Test YAML loading in tests/test_config_load.py: valid file roundtrip, file not found error, invalid YAML syntax error, YAML content failing schema validation

### Implementation for User Story 3

- [x] T016 [US3] Implement load_config() in src/maketab/config.py (reads file, yaml.safe_load, model_validate; raises FileNotFoundError/YAMLError/ValidationError as documented in contract)
- [x] T017 [US3] Export load_config in src/maketab/__init__.py (add to __all__)

**Checkpoint**: Full zero-code workflow operational — load YAML, flatten data, get results

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Ensure existing tests still pass and cleanup

- [x] T018 Run full test suite to verify no regressions in existing tests
- [x] T019 Remove debug print statement on line 84 of src/maketab/core.py

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Stories (Phase 3-5)**: All depend on Foundational phase completion
  - US1 can start immediately after Phase 2
  - US2 can start after Phase 2 (independent of US1 — tests validation, not flatten_config)
  - US3 can start after Phase 2 (independent of US1/US2 — tests file loading only)
- **Polish (Phase 6)**: Depends on all user stories being complete

### Within Each User Story

- Tests MUST be written and FAIL before implementation
- Models/helpers before wrapper functions
- Core implementation before exports

### Parallel Opportunities

- T007, T008, T009 can run in parallel (different test files)
- T013 can run in parallel with US1 tests
- T015 can run in parallel with US1/US2 tests
- US2 and US3 implementation can run in parallel after Phase 2

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational models
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: flatten_config works for all query modes
5. Proceed to US2 and US3

### Incremental Delivery

1. Setup + Foundational → Config models ready
2. Add User Story 1 → Config-driven flatten works (MVP!)
3. Add User Story 2 → Invalid configs caught with clear errors
4. Add User Story 3 → YAML file loading completes zero-code story
5. Polish → Regressions checked, debug print removed
