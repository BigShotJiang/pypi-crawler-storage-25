# Feature Specification: Config-Driven Output Schema

**Feature Branch**: `001-config-driven-schema`
**Created**: 2026-04-04
**Status**: Draft
**Input**: User description: "Drive the output schema from a config file rather than a Pydantic model, enabling zero-coding setup. Define a config file format (itself a Pydantic model) specifying output fields and queries. A new wrapper function accepts this config plus raw records, dynamically generates the Pydantic output model, and passes it through to the existing flatten function."

## Clarifications

### Session 2026-04-04

- Q: How should a field in a declarative config reference a shared root query? → A: A dedicated `query_roots` section in the config defines named query roots (each specifying its query expression and whether it explodes). Field configs reference these by name. Roots can be either explode or plain query types.
- Q: What on-disk file format for configs? → A: YAML (requires `pyyaml` dependency). File reading/parsing MUST be a separate function from the core wrapper — the wrapper accepts only the already-parsed config model, not a file path.
- Q: What should the wrapper function return? → A: `List[BaseModel]` — return the dynamically generated Pydantic model instances. Callers can use attribute access or call `.model_dump()` for dicts.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Flatten Data Using a Config File (Priority: P1)

A user who does not want to write Python code defines a configuration
file that describes the output columns and the queries to extract them
from nested data. They call a single function with that config and a
list of records, and receive a list of flat dictionaries (or validated
model instances) as output.

**Why this priority**: This is the core value proposition — enabling
zero-code flattening. Without this, none of the other stories matter.

**Independent Test**: Can be fully tested by providing a config
object and sample nested data, then asserting the returned flat
records match expectations.

**Acceptance Scenarios**:

1. **Given** a config defining three fields with simple queries and a
   list of nested records, **When** the user calls the config-driven
   flatten function, **Then** they receive a list of flat records with
   the three fields populated correctly.
2. **Given** a config that uses an explode query on an array field,
   **When** the user calls the config-driven flatten function, **Then**
   the output contains one row per array element with other fields
   repeated, matching the behavior of the existing `Explode` annotation.
3. **Given** a config with a query that references a root (shared
   explode context), **When** the user calls the config-driven flatten
   function, **Then** the output correctly resolves the root-relative
   query, matching existing `Query(root=...)` behavior.

---

### User Story 2 - Validation Errors for Invalid Configs (Priority: P2)

A user provides a config file with mistakes — missing query
expressions, invalid field type names, or duplicate field names. The
system rejects the config with clear, actionable error messages before
any data processing begins.

**Why this priority**: Without good validation, the zero-code
experience degrades into confusing runtime failures. This is essential
for usability but secondary to the happy path.

**Independent Test**: Can be tested by providing malformed config
objects and asserting specific error messages are raised.

**Acceptance Scenarios**:

1. **Given** a config where a field is missing its query expression,
   **When** the config is loaded, **Then** a validation error is raised
   identifying the field and the missing property.
2. **Given** a config where a field specifies an unsupported type name,
   **When** the config is loaded, **Then** a validation error is raised
   listing the invalid type and the supported alternatives.
3. **Given** a config with duplicate field names, **When** the config
   is loaded, **Then** a validation error is raised identifying the
   duplicates.

---

### User Story 3 - Load Config from a File Path (Priority: P3)

A user stores their config as a YAML file on disk and uses a dedicated
load function to parse it into a config model, then passes that model
to the wrapper flatten function. The load and flatten steps are
separate, composable operations.

**Why this priority**: File-based config is the natural end state for
"zero coding", but the core logic works without it — users can
construct the config model in Python as an intermediate step. This
story completes the experience.

**Acceptance Scenarios**:

1. **Given** a valid YAML config file on disk, **When** the user calls
   the load function with the file path, **Then** the file is read,
   parsed, and returned as a validated config model identical to one
   constructed in-memory.
2. **Given** a file path that does not exist, **When** the user calls
   the load function, **Then** a clear error is raised indicating the
   file was not found.
3. **Given** a YAML file with invalid syntax, **When** the user calls
   the load function, **Then** a parse error is raised before any data
   processing begins.

---

### Edge Cases

- What happens when the config defines zero fields? The system MUST
  reject it with a validation error requiring at least one field.
- What happens when an explode query resolves to `null` for a record?
  Behavior MUST match the existing `Explode` annotation (the record
  produces zero output rows for that explode).
- What happens when the config specifies a field type that cannot hold
  the extracted value (e.g., type is `int` but data is a string)?
  The existing Pydantic validation error propagates unchanged.
- What happens when a field references a query root name that does not
  exist in the `query_roots` section? A validation error MUST be
  raised at config load time.
- What happens when a query root is defined but no field references it?
  This SHOULD be allowed without error (unused roots are harmless).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The library MUST provide a config model (itself a
  Pydantic model) that describes output fields, their types, and their
  query expressions (simple query, explode, or query-with-root). The
  config MUST include an optional `query_roots` section for defining
  named, reusable root queries (each specifying a query expression and
  whether it explodes). Fields reference roots by name.
- **FR-002**: The library MUST provide a function that accepts a config
  instance and a list of records (`List[Dict]`) and returns flat output
  with the same semantics as the existing `flatten` function.
- **FR-003**: The config model MUST support all query modes currently
  available via annotations: simple `Query`, `Explode`, and
  `Query` with a `root` reference.
- **FR-004**: The wrapper function MUST dynamically generate a Pydantic
  model from the config and delegate to the existing `flatten`
  function — it MUST NOT re-implement flattening logic.
- **FR-005**: The config model MUST validate that every field has a
  query expression, that field names are unique, and that field type
  names map to supported Python types.
- **FR-006**: The library MUST provide a separate function to load a
  config from a YAML file path, returning the parsed config model.
  This function MUST be independent of the wrapper flatten function
  (which accepts only an already-parsed config model).
- **FR-007**: All errors from config validation MUST include the field
  name(s) involved and a human-readable explanation of the problem.

### Key Entities

- **QueryRoot**: A named, reusable query definition that can serve as
  the root context for multiple fields. Specifies a query expression
  and whether it explodes (produces multiple rows) or not.
- **FieldConfig**: Represents a single output column — its name, its
  Python type, and its query expression. May optionally reference a
  named query root.
- **SchemaConfig**: The top-level config object containing an optional
  `query_roots` section (named root definitions) and an ordered list
  of field configs. This is the object users construct or load from
  a file.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A user can flatten nested data into a specified tabular
  shape without writing any Python class definitions — only by
  providing a config object or file.
- **SC-002**: Every query mode supported by the annotation-based API
  (simple query, explode, query with root) is also expressible via
  config, with identical output for the same input data.
- **SC-003**: Invalid configs are rejected with errors that name the
  problematic field and explain the issue, before any data processing
  occurs.
- **SC-004**: The config-driven path produces output identical to the
  annotation-based path when given equivalent schemas and the same
  input records.

## Assumptions

- The config file format for on-disk files is YAML. This requires
  adding `pyyaml` as a dependency.
- The set of supported field types will initially be limited to common
  scalar types (`str`, `int`, `float`, `bool`) and `Optional` variants.
  Extending to complex types (lists, nested models) is out of scope for
  this feature.
- The wrapper function returns `List[BaseModel]` (dynamically generated
  Pydantic model instances). Callers can access fields via attributes or
  call `.model_dump()` to get dicts. The static type is `BaseModel`
  since the concrete model is generated at runtime.
- The existing `flatten` function and its public API (`Query`,
  `Explode`) remain unchanged. This feature is purely additive.
