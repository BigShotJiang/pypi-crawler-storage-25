# Implementation Plan: Config-Driven Output Schema

**Branch**: `001-config-driven-schema` | **Date**: 2026-04-04 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/001-config-driven-schema/spec.md`

## Summary

Enable zero-code flattening by introducing a config model (`SchemaConfig`)
that declaratively describes output fields, types, query expressions, and
reusable query roots. A new wrapper function accepts this config plus raw
records, dynamically generates a Pydantic model with the appropriate
`Query`/`Explode` annotations, and delegates to the existing `flatten`
function. A separate loader function reads YAML config files from disk.

## Technical Context

**Language/Version**: Python 3.10+
**Primary Dependencies**: pydantic >=2.0.0, jmespath >=1.0.0, pyyaml (new)
**Storage**: N/A
**Testing**: pytest >=8.0.0
**Target Platform**: Any (pure Python library)
**Project Type**: Library
**Performance Goals**: N/A (config parsing is a one-time cost; flattening
performance is unchanged since it delegates to existing `flatten`)
**Constraints**: Minimal new dependencies (pyyaml justified by clarification)
**Scale/Scope**: Small feature addition — 1 new module, ~150-250 LOC

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Library-First | PASS | Feature is a composable Python API. New dependency `pyyaml` justified by clarification — enables zero-code YAML config files, a capability not achievable with existing deps or stdlib. |
| II. Type Safety and Schema-Driven | PASS | Config model is itself a Pydantic model with full type hints. The generated output model uses `Annotated` metadata with existing `Query`/`Explode` annotations. No new annotation types introduced. |
| III. Correctness Through Testing | PASS (gate) | Tests MUST be written for all user stories. Covered in task planning. |
| IV. Simplicity | PASS | Wrapper delegates to existing `flatten` — no flattening logic duplicated. Config model is a thin declarative layer. |
| API Design Constraints | PASS | Existing `flatten`/`Query`/`Explode` API unchanged. New public symbols (`SchemaConfig`, `FieldConfig`, `QueryRoot`, `flatten_config`, `load_config`) will be added to `__all__` with tests. |

No violations. Complexity Tracking section not needed.

**Post-Design Re-Check** (after Phase 1):

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Library-First | PASS | Single new module `config.py`, one new dependency `pyyaml`. |
| II. Type Safety | PASS | All three config models are Pydantic models with full type hints. Dynamic model uses existing `Annotated` + `Query`/`Explode` pattern. No new annotation types. |
| III. Testing | PASS (gate) | 5 new test files planned covering all user stories and edge cases. |
| IV. Simplicity | PASS | ~150-250 LOC in one module. `flatten_config` is a thin wrapper around `create_model` + `flatten`. No new abstractions beyond the config models themselves. |
| API Design | PASS | 5 new public symbols, each with clear single responsibility. Existing API untouched. |

## Project Structure

### Documentation (this feature)

```text
specs/001-config-driven-schema/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
└── tasks.md             # Phase 2 output (/speckit.tasks)
```

### Source Code (repository root)

```text
src/maketab/
├── __init__.py          # Updated: add new public exports
├── core.py              # Unchanged: existing flatten logic
└── config.py            # New: SchemaConfig, FieldConfig, QueryRoot,
                         #      flatten_config, load_config

tests/
├── helpers.py           # Existing test helpers
├── test_simple_queries.py          # Existing
├── test_single_explode.py          # Existing
├── ...                             # Other existing tests
├── test_config_simple.py           # New: US1 simple query configs
├── test_config_explode.py          # New: US1 explode configs
├── test_config_root.py             # New: US1 query-with-root configs
├── test_config_validation.py       # New: US2 validation errors
└── test_config_load.py             # New: US3 YAML file loading
```

**Structure Decision**: Single new module `config.py` alongside existing
`core.py`. All config-related logic in one file to keep the project flat
and simple (matching existing structure). Tests follow the existing pattern
of one file per concern.
