# Quickstart: Config-Driven Output Schema

## Install

```bash
uv add pyyaml  # adds new dependency
```

## Usage with Python Config Object

```python
from maketab.config import SchemaConfig, flatten_config

config = SchemaConfig.model_validate({
    "query_roots": [
        {"name": "items", "query": "order.items[*]", "explode": True},
    ],
    "fields": [
        {"name": "order_id", "type": "int", "query": "order.id"},
        {"name": "item_name", "type": "str", "query": "name", "root": "items"},
        {"name": "item_price", "type": "float", "query": "price", "root": "items"},
    ],
})

data = [
    {
        "order": {
            "id": 1,
            "items": [
                {"name": "Widget", "price": 9.99},
                {"name": "Gadget", "price": 19.99},
            ],
        }
    }
]

results = flatten_config(config, data)

for row in results:
    print(row.order_id, row.item_name, row.item_price)
# 1 Widget 9.99
# 1 Gadget 19.99

# Convert to dicts if needed:
dicts = [r.model_dump() for r in results]
```

## Usage with YAML File

Create `schema.yaml`:

```yaml
query_roots:
  - name: items
    query: "order.items[*]"
    explode: true

fields:
  - name: order_id
    type: int
    query: "order.id"
  - name: item_name
    type: str
    query: "name"
    root: items
  - name: item_price
    type: float
    query: "price"
    root: items
```

Then load and use:

```python
from maketab.config import load_config, flatten_config

config = load_config("schema.yaml")
results = flatten_config(config, data)
```

## Validation Errors

```python
# Missing query expression
SchemaConfig.model_validate({
    "fields": [{"name": "id", "type": "int"}]
})
# ValidationError: field 'query' is required

# Invalid type name
SchemaConfig.model_validate({
    "fields": [{"name": "id", "type": "integer", "query": "id"}]
})
# ValidationError: unsupported type 'integer', must be one of: str, int, float, bool

# Unknown root reference
SchemaConfig.model_validate({
    "query_roots": [],
    "fields": [{"name": "x", "type": "str", "query": "x", "root": "missing"}]
})
# ValidationError: field 'x' references undefined query root 'missing'
```
