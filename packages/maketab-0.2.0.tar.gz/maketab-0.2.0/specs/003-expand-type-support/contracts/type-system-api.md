# Contract: Type System API

## Config Type Strings

The `type` field in `FieldConfig` accepts the following patterns:

### Primitives
```
str | int | float | bool | timestamp | date | decimal
```

### Compound Types
```
list[<primitive>]
map[str, <primitive>]
list[map[str, <primitive>]]
```

Where `<primitive>` is any of the seven primitives above.

## FieldConfig Schema

```yaml
name: string        # required, non-empty
type: string        # required, valid type string (see above)
query: string       # required, non-empty JMESPath expression
root: string?       # optional, reference to a query_root name
nullable: bool      # optional, default false — field value can be null
nullable_elements: bool  # optional, default false — elements in compound types can be null
```

### Validation Rules

- `nullable_elements: true` is only valid when `type` is a compound type (`list[...]`, `map[...]`, `list[map[...]]`)
- Setting `nullable_elements: true` on a primitive type raises a validation error

## Type Mapping Contract

For every primitive `P` in `SUPPORTED_TYPES`:
- `SUPPORTED_TYPES[P]` returns a Python type
- `_TYPE_MAP[SUPPORTED_TYPES[P]]` returns a PyArrow DataType
- This bidirectional mapping is enforced by an automated test

## Error Messages

Invalid type strings produce errors of the form:
```
unsupported type '<input>', must be one of: bool, date, decimal, float, int, str, timestamp
or a compound type: list[<type>], map[str, <type>], list[map[str, <type>]]
```
