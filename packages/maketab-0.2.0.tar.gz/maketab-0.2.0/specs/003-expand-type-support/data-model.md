# Data Model: Expand Supported Field Types

## Entities

### Primitive Type Registry

The canonical set of supported primitive types, shared between config and parquet modules.

| Config String | Python Type          | Arrow Type                        |
|---------------|----------------------|-----------------------------------|
| `str`         | `str`                | `pa.string()`                     |
| `int`         | `int`                | `pa.int64()`                      |
| `float`       | `float`              | `pa.float64()`                    |
| `bool`        | `bool`               | `pa.bool_()`                      |
| `timestamp`   | `datetime.datetime`  | `pa.timestamp("us", tz="UTC")`    |
| `date`        | `datetime.date`      | `pa.date32()`                     |
| `decimal`     | `decimal.Decimal`    | `pa.decimal128(38, 18)`           |

### Parsed Type Structure

Represents the result of parsing a type string from config. Three variants:

- **PrimitiveType**: A single primitive (e.g., `"str"` → primitive name `"str"`)
- **ListType**: A list of an inner type (e.g., `"list[str]"` → list wrapping primitive `"str"`)
- **MapType**: A map with string keys and a primitive value type (e.g., `"map[str, int]"` → map with value primitive `"int"`)

Compound nesting: `list[map[str, T]]` is a ListType whose inner type is a MapType.

### FieldConfig (updated)

Existing fields unchanged. New optional field:

| Field              | Type   | Default | Description                                                        |
|--------------------|--------|---------|--------------------------------------------------------------------|
| `nullable_elements`| `bool` | `false` | Whether elements within list/map values can be null. Only valid for compound types. |

### Nullability Model

Two independent axes:
1. **Field-level**: `nullable: true` — the entire field value can be null (existing behavior)
2. **Element-level**: `nullable_elements: true` — individual elements within a list or map values can be null (new)

For `list[map[str, T]]`: `nullable_elements` controls whether map values within the list elements can be null. The list elements themselves (the maps) follow field-level nullability.

## Relationships

- FieldConfig → (parsed type string) → ParsedType → Python type + Arrow type
- SUPPORTED_TYPES (config module) maps config string → Python type
- _TYPE_MAP (parquet module) maps Python type → Arrow type
- Type parity invariant: `set(SUPPORTED_TYPES.values()) == set(_TYPE_MAP.keys())`

## Validation Rules

1. Type string must parse successfully (valid syntax)
2. Inner primitive must exist in SUPPORTED_TYPES
3. Map key must be `str` (only supported key type)
4. `nullable_elements` must be `false` (or absent) for primitive type fields
5. Nesting beyond `list[map[str, T]]` is rejected
