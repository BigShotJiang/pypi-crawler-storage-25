# Feature Specification: Expand Supported Field Types

**Feature Branch**: `003-expand-type-support`  
**Created**: 2026-04-05  
**Status**: Draft  
**Input**: User description: "Some parts of the code base (flattening from config and outputting parquet) only support a limited set of types for fields (specifically str, int, float and bool). We should expand this to support timestamps, dates and decimals for a full set of primitive types. Further to this we should add support for lists of these primitives, maps/dicts of string keys to these primitives and lists of maps/dicts (of string -> primitive). The supported types for config driven flattening and parquet output should be the same and this should be guaranteed by an automated test."

## User Scenarios & Testing

### User Story 1 - Define Fields with Extended Primitive Types (Priority: P1)

A user configuring a data schema wants to define fields using timestamp, date, and decimal types in addition to the existing str, int, float, and bool. They specify these types in their YAML config, run the flattening pipeline, and produce Parquet output with correct type fidelity.

**Why this priority**: Primitive types are the foundation for all other type support. Without timestamps, dates, and decimals, users cannot accurately represent common data patterns (e.g., event times, financial amounts).

**Independent Test**: Can be fully tested by creating a config with timestamp, date, and decimal fields, flattening sample data, and verifying the Parquet output contains the correct Arrow types and values.

**Acceptance Scenarios**:

1. **Given** a config with a field of type `timestamp`, **When** the pipeline processes a record containing an ISO 8601 datetime string, **Then** the output Parquet file contains the value as a timestamp type.
2. **Given** a config with a field of type `date`, **When** the pipeline processes a record containing a date string (YYYY-MM-DD), **Then** the output Parquet file contains the value as a date type.
3. **Given** a config with a field of type `decimal`, **When** the pipeline processes a record containing a numeric string or number, **Then** the output Parquet file contains the value as a decimal type.
4. **Given** a config with a field using an unsupported type name, **When** validation runs, **Then** a clear error is raised listing all supported types.

---

### User Story 2 - Define Fields with List Types (Priority: P2)

A user wants to define fields that contain lists of primitive values (e.g., a list of strings, a list of integers). They specify these as list types in their config, and the pipeline correctly flattens and outputs them to Parquet as list columns.

**Why this priority**: Lists of primitives are a common data pattern (tags, scores, identifiers) and are the next most useful compound type after additional primitives.

**Independent Test**: Can be fully tested by creating a config with list-of-primitive fields, flattening sample data containing arrays, and verifying the Parquet output uses list types with the correct element types.

**Acceptance Scenarios**:

1. **Given** a config with a field of type `list[str]`, **When** the pipeline processes a record containing an array of strings, **Then** the output contains a list-of-string column.
2. **Given** a config with a field of type `list[int]`, **When** the pipeline processes a record with an array of integers, **Then** the output contains a list-of-int column.
3. **Given** a config with a list field and the data contains an empty array, **When** the pipeline runs, **Then** the empty list is preserved in the output.
4. **Given** a config with a list field and the data contains null, **When** the field is nullable, **Then** null is preserved (not converted to an empty list).

---

### User Story 3 - Define Fields with Map Types (Priority: P3)

A user wants to define fields containing maps (dictionaries) with string keys and primitive values. They specify these as map types in their config, and the pipeline outputs them as map columns in Parquet.

**Why this priority**: Maps with string keys are common for representing metadata, labels, and key-value properties in semi-structured data.

**Independent Test**: Can be fully tested by creating a config with map-type fields, processing records containing dictionaries, and verifying the Parquet output uses map types.

**Acceptance Scenarios**:

1. **Given** a config with a field of type `map[str, int]`, **When** the pipeline processes a record with a dictionary of string keys to integer values, **Then** the output contains a map column with string keys and integer values.
2. **Given** a config with a map field and the data contains an empty dictionary, **When** the pipeline runs, **Then** the empty map is preserved in output.
3. **Given** a config with a map field and the data contains null, **When** the field is nullable, **Then** null is preserved.

---

### User Story 4 - Define Fields with List-of-Map Types (Priority: P4)

A user wants to define fields that contain lists of maps (e.g., a list of key-value objects). They specify these as list-of-map types in their config, and the pipeline outputs them correctly.

**Why this priority**: List-of-map is a common pattern for representing arrays of structured objects (e.g., a list of attribute pairs), but is the most complex compound type.

**Independent Test**: Can be fully tested by creating a config with a list-of-map field, processing records containing arrays of dictionaries, and verifying the Parquet output uses list-of-map types.

**Acceptance Scenarios**:

1. **Given** a config with a field of type `list[map[str, str]]`, **When** the pipeline processes a record containing an array of string-to-string dictionaries, **Then** the output contains a list-of-map column.
2. **Given** a config with a list-of-map field and the data contains an empty outer list, **When** the pipeline runs, **Then** the empty list is preserved.

---

### User Story 5 - Type Parity Guarantee Between Config and Parquet (Priority: P1)

A developer or CI system wants assurance that every type supported in config-driven flattening is also supported in Parquet output, and vice versa. An automated test verifies this parity so that adding a type to one system without the other causes a test failure.

**Why this priority**: Without this guarantee, a user could define a config with a type that silently fails at Parquet output time. This is a correctness invariant.

**Independent Test**: Can be fully tested by running the automated parity test, which compares the set of types supported by config validation against the set supported by Parquet schema generation and asserts they are identical.

**Acceptance Scenarios**:

1. **Given** the current codebase, **When** the type parity test runs, **Then** it passes confirming both systems support the same set of types.
2. **Given** a hypothetical change that adds a type to config but not to Parquet, **When** the type parity test runs, **Then** it fails with a clear message identifying the mismatch.

---

### Edge Cases

- What happens when a list field contains elements of the wrong type (e.g., a string in a `list[int]`)? The system should raise a validation error.
- What happens when a map field has a non-string key in the data? The system should raise a validation error since only string keys are supported.
- What happens when decimal precision is not specified? The system should use a reasonable default precision.
- How does the system handle nested nulls (e.g., null elements within a list)? Null elements within lists and map values are supported but must be explicitly enabled in config; by default, elements are non-nullable and null values will raise a validation error.

## Requirements

### Functional Requirements

- **FR-001**: System MUST support the following primitive types in both config-driven flattening and Parquet output: `str`, `int`, `float`, `bool`, `timestamp`, `date`, `decimal`.
- **FR-002**: System MUST support list types for all supported primitives, specified as `list[<primitive>]` in config (e.g., `list[str]`, `list[timestamp]`).
- **FR-003**: System MUST support map types with string keys and primitive values, specified as `map[str, <primitive>]` in config (e.g., `map[str, int]`).
- **FR-004**: System MUST support list-of-map types, specified as `list[map[str, <primitive>]]` in config.
- **FR-005**: System MUST raise a clear, actionable error when an unsupported type is used in config, listing all valid types and compound type patterns.
- **FR-006**: System MUST preserve nullability semantics for all new types (primitive, list, map, and list-of-map fields can be nullable). For compound types (list, map, list-of-map), element-level nullability MUST be explicitly configured; elements are non-nullable by default.
- **FR-007**: System MUST include an automated test that verifies the set of types supported by config-driven flattening is identical to the set supported by Parquet output.
- **FR-008**: System MUST correctly map all supported types to their corresponding Parquet types with appropriate precision and semantics.
- **FR-009**: System MUST validate data values against their declared types during flattening (e.g., reject a string where an int is expected in a list).

### Key Entities

- **Type System**: The set of supported type identifiers (primitives: `str`, `int`, `float`, `bool`, `timestamp`, `date`, `decimal`) and compound type constructors (`list[T]`, `map[str, T]`, `list[map[str, T]]`).
- **Type Mapping**: The bidirectional relationship between config type strings, Python types, and Parquet types.

## Success Criteria

### Measurable Outcomes

- **SC-001**: All seven primitive types can be used in config and produce correct Parquet output with round-trip fidelity.
- **SC-002**: All compound types (list, map, list-of-map) can be used in config and produce correct Parquet output.
- **SC-003**: The type parity test passes and would catch any future divergence between config and Parquet type support.
- **SC-004**: Existing tests continue to pass with no regressions to the four originally supported types.
- **SC-005**: Users receive clear error messages when using invalid types, including the full list of valid type patterns.

## Clarifications

### Session 2026-04-05

- Q: Should timestamps be timezone-aware or timezone-naive? → A: Timezone-aware (timestamps always carry explicit UTC timezone in Parquet).
- Q: Should decimal precision/scale be configurable per-field? → A: Fixed default only (precision 38, scale 18 for all decimal fields).
- Q: Can individual elements within lists/maps be null? → A: Yes, but must be explicitly opted into via config; elements are non-nullable by default.

## Assumptions

- Timestamps are timezone-aware with explicit UTC timezone and microsecond precision.
- Dates are calendar dates without time or timezone components.
- Decimal fields use a fixed precision of 38 and scale of 18 for all decimal fields. Per-field configurability is out of scope for this feature.
- The type syntax in config uses bracket notation (e.g., `list[str]`, `map[str, int]`) which is parsed from the type string in field definitions.
- Map keys are always strings; non-string map keys are out of scope.
- Nested compound types beyond `list[map[str, T]]` are out of scope (e.g., `map[str, list[int]]` or `list[list[str]]` are not supported).
- The existing `nullable` field configuration continues to work for all new types.
