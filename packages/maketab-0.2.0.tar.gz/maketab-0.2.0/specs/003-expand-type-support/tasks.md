# Tasks: Expand Supported Field Types

**Input**: Design documents from `/specs/003-expand-type-support/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Included — required by constitution (Principle III) and spec (FR-007 parity test).

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Phase 1: Setup

**Purpose**: No setup tasks needed — project structure and dependencies already exist.

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Shared type system infrastructure that ALL user stories depend on. Expand the type registry, implement the type parser, and update config/parquet modules to handle new primitives and compound types.

- [x] T001 Add `timestamp`, `date`, and `decimal` to `SUPPORTED_TYPES` dict in `src/maketab/config.py` — map `"timestamp"` → `datetime.datetime`, `"date"` → `datetime.date`, `"decimal"` → `decimal.Decimal`
- [x] T002 Add `datetime.datetime`, `datetime.date`, and `decimal.Decimal` to `_TYPE_MAP` dict in `src/maketab/parquet.py` — map to `pa.timestamp("us", tz="UTC")`, `pa.date32()`, `pa.decimal128(38, 18)` respectively
- [x] T003 Implement `_parse_type_string(type_str: str)` function in `src/maketab/config.py` that parses type strings into a structured result: simple primitives return the primitive name; `list[X]` returns list wrapping primitive X; `map[str, X]` returns map wrapping primitive X; `list[map[str, X]]` returns list wrapping map wrapping X. Raises `ValueError` with helpful message for invalid syntax, unsupported primitives, or nesting beyond `list[map[str, T]]`
- [x] T004 Add `nullable_elements: bool = False` field to `FieldConfig` in `src/maketab/config.py` with a model validator that rejects `nullable_elements=True` when the type is a simple primitive (not a compound type)
- [x] T005 Update `must_be_supported_type` validator in `FieldConfig` in `src/maketab/config.py` to use `_parse_type_string` instead of direct `SUPPORTED_TYPES` lookup — accept compound type strings and produce error messages listing both primitive types and compound type patterns per the contract
- [x] T006 Update `_resolve_type` function in `src/maketab/config.py` to handle compound types: `list[T]` → `list[PythonT]`, `map[str, T]` → `dict[str, PythonT]`, `list[map[str, T]]` → `list[dict[str, PythonT]]`. Handle nullability for both field-level (`nullable`) and element-level (`nullable_elements`) using `Optional` wrappers appropriately
- [x] T007 Update `_get_arrow_schema` function in `src/maketab/parquet.py` to handle compound Python types: detect `list[T]` → `pa.list_(arrow_T)`, `dict[str, T]` → `pa.map_(pa.string(), arrow_T)`, `list[dict[str, T]]` → `pa.list_(pa.map_(pa.string(), arrow_T))`. Handle element-level nullability in Arrow field definitions
- [x] T008 Update `_is_optional` function in `src/maketab/parquet.py` to correctly unwrap compound `Optional` types (e.g., `Optional[list[str]]` → `(list[str], True)`) — verify it works with generic aliases from Python 3.10+
- [x] T009 Verify all existing tests pass after foundational changes by running `cd src && pytest` — fix any regressions before proceeding

**Checkpoint**: Type system infrastructure complete. All existing tests pass. New types and compound types are wired through config and parquet modules.

---

## Phase 3: User Story 1 + User Story 5 — Extended Primitives & Type Parity (Priority: P1) 🎯 MVP

**Goal**: Users can define `timestamp`, `date`, and `decimal` fields in config and produce correct Parquet output. Type parity between config and parquet is guaranteed by automated test.

**Independent Test**: Create config with all three new primitive types, flatten sample data, verify Parquet output contains correct Arrow types and values. Run parity test.

### Tests for US1 + US5

- [x] T010 [P] [US1] Write tests in `tests/test_new_primitives.py` for config-driven flattening with `timestamp`, `date`, and `decimal` types — test with valid ISO 8601 datetime, YYYY-MM-DD date, and numeric/string decimal inputs. Test nullable variants. Test round-trip through Parquet (flatten → to_parquet → read back → verify types and values)
- [x] T011 [P] [US1] Add tests to `tests/test_parquet_schema.py` for Arrow schema generation with the three new primitive types — verify `pa.timestamp("us", tz="UTC")`, `pa.date32()`, `pa.decimal128(38, 18)` and their nullable variants
- [x] T012 [P] [US1] Add tests to `tests/test_config_validation.py` for new primitive type names — verify `"timestamp"`, `"date"`, `"decimal"` are accepted; verify misspellings like `"datetime"` or `"time"` are rejected with helpful error
- [x] T013 [P] [US5] Create `tests/test_type_parity.py` — import `SUPPORTED_TYPES` from config and `_TYPE_MAP` from parquet, assert `set(SUPPORTED_TYPES.values()) == set(_TYPE_MAP.keys())`. Also test that every primitive can be used in `list[T]`, `map[str, T]`, and `list[map[str, T]]` patterns in both config validation and Arrow schema generation
- [x] T014 [US1] Run full test suite (`cd src && pytest`) — all new and existing tests must pass

**Checkpoint**: All seven primitive types work end-to-end. Type parity test passes. This is the MVP — users can work with timestamps, dates, and decimals.

---

## Phase 4: User Story 2 — List Types (Priority: P2)

**Goal**: Users can define `list[<primitive>]` fields in config and produce correct Parquet output with Arrow list columns.

**Independent Test**: Create config with list fields for multiple primitives, flatten data with arrays, verify Parquet output uses Arrow list types.

### Tests for US2

- [x] T015 [P] [US2] Create `tests/test_compound_types.py` with tests for `list[str]`, `list[int]`, `list[float]`, `list[bool]`, `list[timestamp]`, `list[date]`, `list[decimal]` — test flattening data containing arrays, verify Parquet output has Arrow `list_` columns with correct element types
- [x] T016 [P] [US2] Add list edge case tests to `tests/test_compound_types.py` — empty lists preserved, null field value preserved when nullable, null elements rejected when `nullable_elements=false`, null elements accepted when `nullable_elements=true`
- [x] T017 [P] [US2] Add list type validation tests to `tests/test_config_validation.py` — verify `list[str]` accepted, `list[unknown]` rejected, `list[]` rejected, `list` (no brackets) rejected
- [x] T018 [US2] Run full test suite (`cd src && pytest`) — all tests pass

**Checkpoint**: List types work end-to-end for all seven primitives. Edge cases (empty, null, nullable_elements) are covered.

---

## Phase 5: User Story 3 — Map Types (Priority: P3)

**Goal**: Users can define `map[str, <primitive>]` fields in config and produce correct Parquet output with Arrow map columns.

**Independent Test**: Create config with map fields, flatten data with dictionaries, verify Parquet output uses Arrow map types.

### Tests for US3

- [x] T019 [P] [US3] Add map type tests to `tests/test_compound_types.py` — test `map[str, str]`, `map[str, int]`, `map[str, float]`, `map[str, timestamp]` etc. Flatten data containing dicts, verify Arrow `map_` columns with `pa.string()` keys and correct value types
- [x] T020 [P] [US3] Add map edge case tests to `tests/test_compound_types.py` — empty dicts preserved, null field value preserved when nullable, null map values rejected when `nullable_elements=false`, null map values accepted when `nullable_elements=true`
- [x] T021 [P] [US3] Add map type validation tests to `tests/test_config_validation.py` — verify `map[str, int]` accepted, `map[int, str]` rejected (non-string key), `map[str]` rejected (missing value type), `map[]` rejected
- [x] T022 [US3] Run full test suite (`cd src && pytest`) — all tests pass

**Checkpoint**: Map types work end-to-end. String-key constraint is enforced.

---

## Phase 6: User Story 4 — List-of-Map Types (Priority: P4)

**Goal**: Users can define `list[map[str, <primitive>]]` fields in config and produce correct Parquet output.

**Independent Test**: Create config with list-of-map fields, flatten data with arrays of dicts, verify Parquet output.

### Tests for US4

- [x] T023 [P] [US4] Add list-of-map tests to `tests/test_compound_types.py` — test `list[map[str, str]]`, `list[map[str, int]]` etc. Flatten data containing arrays of dicts, verify Arrow `list_(map_(...))` columns
- [x] T024 [P] [US4] Add list-of-map edge case tests to `tests/test_compound_types.py` — empty outer list preserved, null field value when nullable, nullable_elements controlling null map values within list elements
- [x] T025 [P] [US4] Add list-of-map validation tests to `tests/test_config_validation.py` — verify `list[map[str, int]]` accepted, `list[list[str]]` rejected (unsupported nesting), `map[str, list[int]]` rejected
- [x] T026 [US4] Run full test suite (`cd src && pytest`) — all tests pass

**Checkpoint**: All compound types (list, map, list-of-map) work end-to-end.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Final validation and cleanup across all stories.

- [x] T027 [P] Update error messages in both `src/maketab/config.py` and `src/maketab/parquet.py` to list all valid types and compound patterns per the contract in `specs/003-expand-type-support/contracts/type-system-api.md`
- [x] T028 Run full test suite one final time (`cd src && pytest`) — zero failures across all existing and new tests
- [x] T029 Validate quickstart examples from `specs/003-expand-type-support/quickstart.md` work correctly by running representative examples as a manual smoke test

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: Skipped — project exists
- **Foundational (Phase 2)**: No dependencies — start immediately. BLOCKS all user stories.
- **US1+US5 (Phase 3)**: Depends on Phase 2 completion
- **US2 (Phase 4)**: Depends on Phase 2 completion — can run in parallel with Phase 3
- **US3 (Phase 5)**: Depends on Phase 2 completion — can run in parallel with Phases 3-4
- **US4 (Phase 6)**: Depends on Phase 2 completion — can run in parallel with Phases 3-5
- **Polish (Phase 7)**: Depends on all user story phases being complete

### User Story Dependencies

- **US1+US5 (P1)**: Can start after Phase 2 — no dependencies on other stories
- **US2 (P2)**: Can start after Phase 2 — no dependencies on other stories
- **US3 (P3)**: Can start after Phase 2 — no dependencies on other stories
- **US4 (P4)**: Can start after Phase 2 — no dependencies on other stories

### Within Each User Story

- Test tasks marked [P] can run in parallel
- Implementation verification (run full suite) is the final task per phase

### Parallel Opportunities

- T001 and T002 can run in parallel (different files: config.py and parquet.py)
- T010, T011, T012, T013 can all run in parallel (different test files)
- T015, T016, T017 can run in parallel
- T019, T020, T021 can run in parallel
- T023, T024, T025 can run in parallel
- All user story phases (3-6) can run in parallel after Phase 2 completes

---

## Parallel Example: Phase 2 (Foundational)

```
# These two can run in parallel (different source files):
T001: Add new primitives to SUPPORTED_TYPES in src/maketab/config.py
T002: Add new primitives to _TYPE_MAP in src/maketab/parquet.py
```

## Parallel Example: Phase 3 (US1+US5)

```
# All test files can be written in parallel:
T010: tests/test_new_primitives.py
T011: tests/test_parquet_schema.py (additions)
T012: tests/test_config_validation.py (additions)
T013: tests/test_type_parity.py (new file)
```

---

## Implementation Strategy

### MVP First (US1 + US5 Only)

1. Complete Phase 2: Foundational (type parser, registries, schema updates)
2. Complete Phase 3: US1 + US5 (new primitives + parity test)
3. **STOP and VALIDATE**: All seven primitives work. Parity test passes.
4. This alone delivers significant value — timestamps, dates, and decimals.

### Incremental Delivery

1. Phase 2 → Foundation ready
2. Phase 3 (US1+US5) → New primitives + parity guarantee (MVP!)
3. Phase 4 (US2) → List types added
4. Phase 5 (US3) → Map types added
5. Phase 6 (US4) → List-of-map types added
6. Phase 7 → Polish and final validation
7. Each phase adds compound type capability without breaking previous work

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- All user stories are fully independent after Phase 2
- `src/maketab/core.py` requires NO changes — it works with any Python types
- `src/maketab/__init__.py` requires NO changes — public API surface unchanged
- Commit after each task or logical group
- Stop at any checkpoint to validate independently
