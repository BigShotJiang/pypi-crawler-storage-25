# Implementation Plan: Expand Supported Field Types

**Branch**: `003-expand-type-support` | **Date**: 2026-04-05 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/003-expand-type-support/spec.md`

## Summary

Expand the type system from 4 primitives (str, int, float, bool) to 7 (adding timestamp, date, decimal) and introduce compound types (list, map, list-of-map). Ensure type parity between config-driven flattening and Parquet output via shared type registry and automated tests.

## Technical Context

**Language/Version**: Python 3.10+  
**Primary Dependencies**: pydantic >=2.0.0, jmespath >=1.0.0, pyarrow >=14.0.0, pyyaml >=6.0.0  
**Storage**: N/A (in-memory buffers only)  
**Testing**: pytest >=8.0.0  
**Target Platform**: Any Python 3.10+ environment  
**Project Type**: Library  
**Performance Goals**: N/A (type system expansion, no performance-critical changes)  
**Constraints**: No new dependencies allowed per constitution  
**Scale/Scope**: 4 source files, ~22 test files

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Library-First | PASS | All changes are to library internals. No new dependencies (datetime, decimal are stdlib). |
| II. Type Safety and Schema-Driven | PASS | Extends existing Pydantic/Annotated pattern. No new annotation types needed — compound types use Python generics with existing Query annotations. |
| III. Correctness Through Testing | PASS | Plan includes tests for all new types, compound types, edge cases, and parity test. |
| IV. Simplicity | PASS | Type parser is a focused utility solving one problem. No new abstractions beyond the parsed type representation. |
| API Design Constraints | PASS | No changes to public API surface (`flatten`, `Query`, `Explode`). Config API (`FieldConfig`, `SchemaConfig`) gains one optional field. |

**Post-Phase 1 Re-check**: PASS — No violations introduced by design decisions. The type parser is the only new internal function, justified by the parsing complexity of compound type strings.

## Project Structure

### Documentation (this feature)

```text
specs/003-expand-type-support/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   └── type-system-api.md
└── tasks.md             # Phase 2 output (created by /speckit.tasks)
```

### Source Code (repository root)

```text
src/
└── maketab/
    ├── __init__.py      # No changes needed
    ├── config.py        # SUPPORTED_TYPES expansion, type parser, FieldConfig update, _resolve_type update
    ├── core.py          # No changes needed (works with any Python types)
    └── parquet.py       # _TYPE_MAP expansion, compound Arrow type handling in _get_arrow_schema

tests/
├── test_config_simple.py         # Existing (no changes)
├── test_config_validation.py     # Add compound type validation tests
├── test_parquet_basic.py         # Add new primitive round-trip tests
├── test_parquet_schema.py        # Add compound Arrow schema tests
├── test_type_parity.py           # NEW: automated type parity test
├── test_compound_types.py        # NEW: end-to-end compound type tests
└── test_new_primitives.py        # NEW: end-to-end timestamp/date/decimal tests
```

**Structure Decision**: Existing single-project structure. New test files follow existing naming convention (`test_<topic>.py`). No new source modules needed — changes fit naturally in `config.py` and `parquet.py`.

## Complexity Tracking

No constitution violations to justify.
