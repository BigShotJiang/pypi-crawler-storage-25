# Research: Expand Supported Field Types

## R1: PyArrow Type Mappings for New Primitives

**Decision**: Use the following Arrow type mappings:
- `timestamp` → `pa.timestamp("us", tz="UTC")` (microsecond, timezone-aware UTC)
- `date` → `pa.date32()` (calendar date, no time component)
- `decimal` → `pa.decimal128(38, 18)` (fixed precision/scale)

**Rationale**: These are the most common Arrow representations. `timestamp("us", tz="UTC")` matches the clarified requirement for timezone-aware timestamps. `date32()` stores days since epoch which is compact and sufficient. `decimal128(38, 18)` provides maximum precision without per-field config.

**Alternatives considered**:
- `pa.timestamp("ns")` — nanosecond precision is overkill for most pipelines and can overflow for dates far from epoch
- `pa.date64()` — millisecond precision not needed for date-only values
- `pa.decimal256()` — unnecessary precision for practical use cases

## R2: Python Types for New Primitives

**Decision**: Map config type strings to Python standard library types:
- `"timestamp"` → `datetime.datetime`
- `"date"` → `datetime.date`
- `"decimal"` → `decimal.Decimal`

**Rationale**: These are the natural Python representations. Pydantic v2 natively validates and coerces all three from strings. `datetime.datetime` handles ISO 8601 parsing, `datetime.date` handles YYYY-MM-DD, and `decimal.Decimal` handles numeric strings with arbitrary precision.

**Alternatives considered**:
- Custom wrapper types — unnecessary complexity, Pydantic handles coercion
- `float` for decimal — loses precision, defeats the purpose

## R3: Compound Type Representation in Python

**Decision**: Map compound config types to Python generic types:
- `list[T]` → `list[PythonT]` (Python 3.10+ generic syntax)
- `map[str, T]` → `dict[str, PythonT]`
- `list[map[str, T]]` → `list[dict[str, PythonT]]`

**Rationale**: Python 3.10+ supports `list[str]`, `dict[str, int]` etc. as runtime type annotations. Pydantic v2 validates these natively including element-level type checking. No custom types needed.

**Alternatives considered**:
- `typing.List` / `typing.Dict` — deprecated in 3.10+, unnecessary

## R4: Compound Type Arrow Mappings

**Decision**: Map compound types to Arrow compound types:
- `list[T]` → `pa.list_(arrow_T)`
- `map[str, T]` → `pa.map_(pa.string(), arrow_T)`
- `list[map[str, T]]` → `pa.list_(pa.map_(pa.string(), arrow_T))`

**Rationale**: These are the standard Arrow compound types. PyArrow's `pa.array()` can construct these from Python lists/dicts natively.

**Alternatives considered**:
- Struct types instead of maps — less flexible, requires fixed key set
- JSON string columns — loses type safety and queryability

## R5: Config Syntax for Compound Types

**Decision**: Use bracket notation parsed from the `type` field string:
- `list[str]`, `list[timestamp]`, etc.
- `map[str, int]`, `map[str, decimal]`, etc.
- `list[map[str, bool]]`, etc.

A type parser function will extract the compound structure and validate the inner primitive type against SUPPORTED_TYPES.

**Rationale**: Bracket notation is familiar (Python-like), compact, and unambiguous. It fits naturally in YAML config without special escaping.

**Alternatives considered**:
- Nested YAML objects (e.g., `type: {list: str}`) — verbose, harder to read
- Separate `element_type` field — doesn't generalize to nested compounds

## R6: Element Nullability Configuration

**Decision**: Add an optional `nullable_elements: bool` field to FieldConfig (default `false`). This controls whether elements within list values and map values can be null.

**Rationale**: Consistent with existing `nullable` pattern. Keeps config simple. Applies to the immediate element type (for `list[int]`, controls whether list elements can be null; for `map[str, int]`, controls whether map values can be null; for `list[map[str, int]]`, controls whether map values within list elements can be null).

**Alternatives considered**:
- Type-string syntax like `list[int?]` — harder to parse, diverges from standard notation
- Separate element nullability per nesting level — too complex for current scope

## R7: Type Parser Design

**Decision**: Implement a `parse_type_string(type_str: str)` function that returns a structured representation (e.g., a dataclass or tuple) of the parsed type. The parser handles:
1. Simple primitives: returns the primitive name
2. `list[X]`: returns list wrapper around parsed X
3. `map[str, X]`: returns map wrapper around parsed X (validates first arg is `str`)
4. `list[map[str, X]]`: returns list wrapping map wrapping parsed X
5. Anything else: raises ValueError with helpful message

**Rationale**: A dedicated parser keeps the validation logic clean and testable. The grammar is simple enough for string manipulation (no need for a full parser library).

**Alternatives considered**:
- Regex-only approach — fragile for nested types
- AST parsing — overkill for this grammar

## R8: Type Parity Test Design

**Decision**: Create a test that:
1. Imports the set of primitive type strings from config module (SUPPORTED_TYPES keys)
2. Imports the set of Python types from parquet module (_TYPE_MAP keys)
3. Asserts SUPPORTED_TYPES values (Python types) == _TYPE_MAP keys (Python types)
4. Additionally validates that compound type constructors work for all primitives in both systems

**Rationale**: Testing at the type-set level catches drift immediately. Testing compound constructors ensures the parser and Arrow schema generator agree on what's valid.

**Alternatives considered**:
- Only testing primitive parity — misses compound type drift
- Runtime assertion instead of test — test is more discoverable and CI-friendly
