# Quickstart: Expand Supported Field Types

## What Changed

The type system for config-driven flattening and Parquet output now supports:
- **New primitives**: `timestamp`, `date`, `decimal` (in addition to existing `str`, `int`, `float`, `bool`)
- **Compound types**: `list[T]`, `map[str, T]`, `list[map[str, T]]` where T is any primitive
- **Element nullability**: Optional `nullable_elements` config flag for compound types

## Config Examples

### New Primitive Types

```yaml
fields:
  - name: created_at
    type: timestamp
    query: metadata.created_at
  - name: event_date
    type: date
    query: event.date
  - name: amount
    type: decimal
    query: transaction.amount
```

### Compound Types

```yaml
fields:
  - name: tags
    type: list[str]
    query: metadata.tags
  - name: scores
    type: list[int]
    query: results[*].score
  - name: labels
    type: map[str, str]
    query: metadata.labels
  - name: metrics
    type: map[str, float]
    query: measurements
  - name: attributes
    type: list[map[str, str]]
    query: items[*].attrs
```

### Element Nullability

```yaml
fields:
  - name: optional_scores
    type: list[int]
    query: scores
    nullable_elements: true   # allows [1, null, 3]
  - name: sparse_labels
    type: map[str, str]
    query: labels
    nullable_elements: true   # allows {"a": "x", "b": null}
```

## Running Tests

```bash
cd src && pytest
```

## Key Files

- `src/maketab/config.py` — Type parsing, SUPPORTED_TYPES, FieldConfig
- `src/maketab/parquet.py` — Arrow type mapping, schema generation
- `tests/test_type_parity.py` — Automated type parity test
