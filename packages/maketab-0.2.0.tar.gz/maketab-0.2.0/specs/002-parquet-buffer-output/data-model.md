# Data Model: Parquet Buffer Output

**Feature**: 002-parquet-buffer-output
**Date**: 2026-04-05

## Entities

### Type Mapping

Static mapping from Python/Pydantic types to Parquet column types:

| Python Type | Parquet Type | Nullable |
|-------------|-------------|----------|
| `str`       | STRING      | No       |
| `int`       | INT64       | No       |
| `float`     | FLOAT64     | No       |
| `bool`      | BOOLEAN     | No       |
| `Optional[str]` | STRING | Yes      |
| `Optional[int]` | INT64  | Yes      |
| `Optional[float]` | FLOAT64 | Yes  |
| `Optional[bool]` | BOOLEAN | Yes   |

### Parquet Buffer

- **Content**: Complete Parquet file bytes (header, row groups, footer, magic bytes)
- **Container**: `io.BytesIO` with seek position at 0
- **Schema**: Derived from Pydantic model field names and types
- **Columns**: One per model field, named identically to the field name
- **Rows**: One per Pydantic model instance in the input list

### Schema Derivation Flow

1. Input: `Type[BaseModel]` (the Pydantic model class)
2. Iterate `model_fields` to get field names
3. For each field, inspect `annotation` to get the Python type
4. Unwrap `Optional[T]` to `T` + nullable flag using `typing.get_args`
5. Map each base type to the corresponding Parquet type
6. Output: Parquet schema (ordered list of column name + type + nullable)

## Validation Rules

- All fields in the model MUST have a type in the supported mapping. Unsupported types raise `ValueError`.
- Input list elements MUST be instances of the declared Pydantic model (enforced by type hints; runtime validation is Pydantic's responsibility).
- Non-nullable columns MUST NOT contain None values. Arrow will raise a type error naturally if this occurs.

## Relationships

- `to_parquet` takes the output of `flatten` (list of model instances) and the model class
- `flatten_config_to_parquet` composes `flatten_config` + `to_parquet` into a single call
- The Parquet schema is derived from the same Pydantic model used for flattening, ensuring column names and types are always consistent
