# Public API Contract: Parquet Buffer Output

**Feature**: 002-parquet-buffer-output
**Date**: 2026-04-05

## New Public Functions

### `to_parquet`

Converts a list of Pydantic model instances into an in-memory Parquet buffer.

**Signature**:
```
to_parquet(records: List[T], output_schema: Type[T]) -> io.BytesIO
```

**Parameters**:
- `records`: List of Pydantic model instances (output of `flatten`)
- `output_schema`: The Pydantic model class used to derive the Parquet schema

**Returns**: `io.BytesIO` containing valid Parquet data, seek position at 0

**Raises**:
- `ValueError`: If a field type in the model is not in the supported type mapping

**Behavior**:
- Empty `records` list produces a valid zero-row Parquet buffer with correct schema
- Column names match model field names exactly
- Column types are mapped per the type mapping table in data-model.md
- Nullable fields (Optional[T]) allow None values in the column

---

### `flatten_config_to_parquet`

Combines config-driven flattening and Parquet conversion in a single call.

**Signature**:
```
flatten_config_to_parquet(config: SchemaConfig, data: List[Dict]) -> io.BytesIO
```

**Parameters**:
- `config`: A `SchemaConfig` defining output fields and queries
- `data`: List of nested dictionaries to flatten

**Returns**: `io.BytesIO` containing valid Parquet data, seek position at 0

**Raises**:
- `ValueError`: If a field type in the config is not in the supported type mapping
- Same errors as `flatten_config` for invalid configs or data

**Behavior**:
- Equivalent to calling `flatten_config(config, data)` then `to_parquet` on the result
- Produces identical output to calling the two functions separately

## Updated Exports

The following names are added to `maketab/__init__.py` `__all__`:
- `to_parquet`
- `flatten_config_to_parquet`
