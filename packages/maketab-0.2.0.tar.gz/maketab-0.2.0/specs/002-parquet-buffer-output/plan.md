# Implementation Plan: Parquet Buffer Output

**Branch**: `002-parquet-buffer-output` | **Date**: 2026-04-05 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/002-parquet-buffer-output/spec.md`

## Summary

Add Parquet output capability to maketab, allowing users to convert flattened data (lists of Pydantic model instances) into in-memory Parquet buffers. This enables streaming to downstream tools without intermediate file I/O. Supports both the programmatic (`flatten`) and config-driven (`flatten_config`) workflows.

## Technical Context

**Language/Version**: Python 3.10+
**Primary Dependencies**: pydantic >=2.0.0, jmespath >=1.0.0, pyyaml >=6.0.0, pyarrow (new)
**Storage**: N/A (in-memory buffers only)
**Testing**: pytest >=8.0.0
**Target Platform**: Cross-platform (library)
**Project Type**: Library
**Performance Goals**: Handle 100,000 records without errors or data loss
**Constraints**: Memory-bound only; no artificial limits
**Scale/Scope**: Single module addition; 2 new public functions

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Library-First | PASS | New functions exposed as composable Python API. No CLI/web/plugin. |
| II. Type Safety and Schema-Driven | PASS | Uses existing Pydantic model schema to derive Parquet column types. No new annotation types needed. |
| III. Correctness Through Testing | PASS (pending) | Tests will cover all type mappings, nullable fields, empty input, and round-trip validation. |
| IV. Simplicity | PASS | Two new public functions (`to_parquet`, `flatten_config_to_parquet`), no new abstractions. Internal helper maps Pydantic fields to Arrow types. |

**New dependency justification**: `pyarrow` is the standard Python library for Parquet I/O. There is no reasonable way to produce valid Parquet files using only the standard library or existing dependencies. This is a concrete capability gap per Principle I.

**API surface change**: Two new names added to `__all__`: `to_parquet` and `flatten_config_to_parquet`. Both will have documentation and tests per API Design Constraints.

## Project Structure

### Documentation (this feature)

```text
specs/002-parquet-buffer-output/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
└── tasks.md             # Phase 2 output (created by /speckit.tasks)
```

### Source Code (repository root)

```text
src/
└── maketab/
    ├── __init__.py      # Add to_parquet, flatten_config_to_parquet to __all__
    ├── core.py          # Existing flatten logic (unchanged)
    ├── config.py        # Existing config logic (unchanged)
    └── parquet.py       # NEW: to_parquet, flatten_config_to_parquet

tests/
├── test_parquet_basic.py         # NEW: basic type mapping, round-trip
├── test_parquet_nullable.py      # NEW: nullable fields, None handling
├── test_parquet_edge_cases.py    # NEW: empty input, large datasets
└── test_parquet_config.py        # NEW: config-driven parquet output
```

**Structure Decision**: Single new module `parquet.py` alongside existing `core.py` and `config.py`. Follows the existing pattern of one module per concern. Tests follow the existing pattern of one test file per scenario group.

## Complexity Tracking

No constitution violations to justify.
