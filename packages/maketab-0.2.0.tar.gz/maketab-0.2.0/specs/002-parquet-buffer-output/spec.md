# Feature Specification: Parquet Buffer Output

**Feature Branch**: `002-parquet-buffer-output`  
**Created**: 2026-04-05  
**Status**: Draft  
**Input**: User description: "Add support for outputting flattened data as parquet data, returned as a buffer so that data can be streamed to other tools"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Convert Flattened Data to Parquet Buffer (Priority: P1)

A user has nested data that they flatten using maketab's existing `flatten` or `flatten_config` functions. They want to convert the resulting flattened records into Parquet format and receive the output as an in-memory buffer rather than a file on disk. This allows them to stream the data directly to downstream tools, services, or storage systems without intermediate file I/O.

**Why this priority**: This is the core value proposition of the feature. Without buffer-based Parquet output, users must write to disk and re-read, adding latency and complexity to data pipelines.

**Independent Test**: Can be fully tested by flattening a sample dataset and verifying the returned buffer contains valid Parquet data that can be read back into records matching the original flattened output.

**Acceptance Scenarios**:

1. **Given** a list of flattened records (Pydantic model instances) produced by `flatten`, **When** the user requests Parquet output, **Then** they receive an in-memory buffer containing valid Parquet-formatted data.
2. **Given** a valid in-memory Parquet buffer returned by the system, **When** the buffer is read by any standard Parquet reader, **Then** the data matches the original flattened records with correct column names and types.
3. **Given** a list of flattened records with mixed types (strings, integers, floats, booleans), **When** the user requests Parquet output, **Then** the Parquet schema correctly maps each field to its appropriate column type.

---

### User Story 2 - Config-Driven Parquet Output (Priority: P2)

A user who defines their flattening schema via YAML config (using `flatten_config`) wants to flatten data and produce Parquet output in a single streamlined step, receiving the result as a buffer.

**Why this priority**: Many users rely on the config-driven workflow. Supporting Parquet output from this path ensures the feature is accessible to all users, not just those writing Pydantic models directly.

**Independent Test**: Can be tested by loading a YAML config, flattening sample data, and verifying the returned buffer is valid Parquet with correct schema and data.

**Acceptance Scenarios**:

1. **Given** a valid YAML schema config and nested input data, **When** the user requests config-driven Parquet output, **Then** they receive an in-memory buffer containing valid Parquet data matching the flattened result.
2. **Given** a config with nullable fields, **When** the input data contains null values for those fields, **Then** the Parquet output correctly represents nulls in the appropriate columns.

---

### User Story 3 - Stream Parquet Buffer to External Tool (Priority: P3)

A user wants to take the Parquet buffer and pass it directly to another tool or service (e.g., upload to cloud storage, send over a network connection, or pipe to another process) without writing to disk first.

**Why this priority**: This validates the streaming use case that motivates the buffer-based design. It ensures the buffer is compatible with standard I/O patterns.

**Independent Test**: Can be tested by verifying the buffer object supports standard read/seek operations and can be consumed by a file-like interface.

**Acceptance Scenarios**:

1. **Given** a Parquet buffer returned by the system, **When** the user passes it to any interface expecting a file-like object, **Then** the interface can read the Parquet data successfully.
2. **Given** a Parquet buffer, **When** the user reads its raw bytes, **Then** the bytes represent a valid Parquet file (correct magic bytes and structure).

---

### Edge Cases

- What happens when the flattened result is an empty list (no records)? The system should return a valid Parquet buffer with the correct schema but zero rows.
- What happens when a field contains None values in a non-nullable column? The system should raise a clear error before producing the buffer.
- What happens when the input data produces a very large number of flattened records? The system should handle it within available memory without corruption.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST accept a list of flattened Pydantic model instances and return an in-memory buffer containing valid Parquet data.
- **FR-002**: System MUST preserve all field names from the Pydantic model as column names in the Parquet output.
- **FR-003**: System MUST map field types (str, int, float, bool) to appropriate Parquet column types.
- **FR-004**: System MUST handle nullable fields, representing None values correctly in the Parquet output.
- **FR-005**: System MUST return a buffer object that supports standard file-like read and seek operations.
- **FR-006**: System MUST produce a valid Parquet buffer when given an empty list of records (zero rows, correct schema).
- **FR-007**: System MUST provide a config-driven path that combines flattening and Parquet output into a single operation.
- **FR-008**: System MUST raise a clear, descriptive error when data cannot be converted to Parquet (e.g., unsupported types, type mismatches).

### Key Entities

- **Parquet Buffer**: An in-memory byte buffer containing Parquet-formatted tabular data with a schema derived from the flattened output model. Supports file-like read/seek operations for streaming to downstream consumers.
- **Column Schema**: The mapping between Pydantic model field names/types and Parquet column names/types, derived automatically from the model definition.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Users can convert flattened data to Parquet format and receive the result as a buffer in a single function call.
- **SC-002**: 100% of supported field types (str, int, float, bool, and their nullable variants) are correctly represented in the Parquet output.
- **SC-003**: The returned buffer is usable as a file-like object, allowing users to stream data to any tool that accepts file-like input without writing to disk.
- **SC-004**: Conversion of 100,000 flattened records completes without errors or data loss.
- **SC-005**: Both the programmatic (Pydantic model) and config-driven (YAML) workflows produce identical Parquet output for the same input data.

## Assumptions

- Users have a Parquet-compatible reader available in their downstream tooling (this is standard in data engineering workflows).
- The buffer is intended for single-use or sequential access patterns; concurrent reads from the same buffer are not required.
- The feature scope covers in-memory buffer output only; direct file writing is out of scope (users can write the buffer to disk themselves if needed).
- The existing supported types (str, int, float, bool) are sufficient for Parquet output; complex nested types within columns are out of scope.
- Memory availability is the user's responsibility for very large datasets; the system does not impose artificial size limits but operates within available memory.
