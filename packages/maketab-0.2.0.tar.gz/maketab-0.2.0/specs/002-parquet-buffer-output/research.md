# Research: Parquet Buffer Output

**Feature**: 002-parquet-buffer-output
**Date**: 2026-04-05

## R1: Parquet Library Choice

**Decision**: Use `pyarrow` as the Parquet serialization library.

**Rationale**: pyarrow is the de facto standard for Parquet I/O in Python. It provides native in-memory buffer support via `pa.BufferOutputStream`, efficient columnar conversion, and comprehensive type mapping. It is actively maintained by the Apache Arrow project and is the most widely used Parquet library in the Python data ecosystem.

**Alternatives considered**:
- `fastparquet`: Lighter weight but depends on NumPy and has less robust in-memory buffer support. Would require extra work to produce a seekable buffer.
- `pandas` + `pyarrow`: Adds an unnecessary pandas dependency just for DataFrame-to-Parquet conversion. Since we already have structured data in Pydantic models, converting directly to Arrow tables avoids the overhead.
- Manual Parquet file format writing: Not feasible — Parquet is a complex columnar format with encoding, compression, and metadata requirements.

## R2: Type Mapping Strategy

**Decision**: Map Pydantic model field types to PyArrow types directly using a static mapping dictionary.

**Rationale**: maketab supports four base types (`str`, `int`, `float`, `bool`). Each maps cleanly to an Arrow type (`pa.string()`, `pa.int64()`, `pa.float64()`, `pa.bool_()`). Nullable fields use the same Arrow types — Arrow natively supports nulls in all column types. No complex type inference or reflection is needed.

**Alternatives considered**:
- Dynamic type inference from data values: Fragile and error-prone. A column of all nulls would have no inferable type. Explicit schema from the model is more reliable.
- Pandas dtype intermediary: Adds unnecessary conversion step and dependency.

## R3: Buffer Return Type

**Decision**: Return `io.BytesIO` containing the complete Parquet file bytes, with the seek position reset to 0.

**Rationale**: `io.BytesIO` is a standard library type that implements the full file-like interface (read, seek, tell, write). It is universally accepted by tools expecting file-like objects. Returning with position at 0 means the caller can immediately read or pass it to another consumer without manual seeking.

**Alternatives considered**:
- Return raw `bytes`: Simpler but loses file-like interface. Callers wanting to stream would need to wrap in `BytesIO` themselves, which defeats the purpose.
- Return `pa.Buffer` (Arrow native buffer): Non-standard, requires callers to know Arrow APIs. Would leak implementation details.
- Return a custom wrapper class: Over-engineered for the use case. `BytesIO` already does everything needed.

## R4: Schema Extraction from Pydantic Models

**Decision**: Extract field names and types by iterating `model.model_fields` and inspecting type annotations, handling `Optional[T]` by unwrapping to `T` with nullable flag.

**Rationale**: This approach works with both statically defined models and dynamically created models (from `config.py`'s `create_model`). The `model_fields` dict provides field names, and `annotation` gives the type. For `Optional` types, we unwrap using `get_args` from the `typing` module.

**Alternatives considered**:
- Using `model_json_schema()`: Produces JSON Schema which would need re-parsing. Indirect and lossy for our type mapping needs.
- Inspecting `__annotations__` directly: Works but `model_fields` is the documented Pydantic v2 API and handles inheritance correctly.

## R5: Empty Input Handling

**Decision**: When given an empty list, produce a valid Parquet buffer with the correct schema (columns and types) but zero rows.

**Rationale**: This is the principle of least surprise. Downstream tools that read the Parquet data can still inspect the schema even with no rows. Raising an error on empty input would be unnecessarily restrictive — empty results are a valid outcome of data processing.

**Alternatives considered**:
- Raise an error: Too restrictive. Empty results are common in data pipelines.
- Return an empty `BytesIO`: Invalid — not a proper Parquet file. Would break downstream readers.
