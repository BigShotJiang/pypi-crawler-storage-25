# Quickstart: Parquet Buffer Output

**Feature**: 002-parquet-buffer-output

## Prerequisites

Install the new dependency:
```
uv add pyarrow
```

## Usage: Programmatic (Pydantic Model)

```python
from typing import Annotated, Optional
from pydantic import BaseModel
from maketab import Query, Explode, flatten, to_parquet

class UserRow(BaseModel):
    name: Annotated[str, Query("name")]
    email: Annotated[Optional[str], Query("contact.email")]

data = [
    {"name": "Alice", "contact": {"email": "alice@example.com"}},
    {"name": "Bob", "contact": {"email": None}},
]

rows = flatten(data, UserRow)
buffer = to_parquet(rows, UserRow)

# buffer is an io.BytesIO — use it anywhere a file-like object is expected
# Example: upload to cloud storage
# storage_client.upload(buffer, "users.parquet")

# Example: read back with pyarrow
import pyarrow.parquet as pq
table = pq.read_table(buffer)
print(table.to_pandas())
```

## Usage: Config-Driven (YAML)

```python
from maketab import load_config, flatten_config_to_parquet

config = load_config("schema.yaml")
data = [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]

buffer = flatten_config_to_parquet(config, data)

# buffer is ready to stream
with open("output.parquet", "wb") as f:
    f.write(buffer.read())
```

## Empty Input

```python
rows = []
buffer = to_parquet(rows, UserRow)
# Valid Parquet file with correct schema, zero rows
```
