# Tasks: Parquet Buffer Output

**Input**: Design documents from `/specs/002-parquet-buffer-output/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Included per Constitution Principle III (Correctness Through Testing) — every user-facing behavior must have a corresponding pytest test.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup

**Purpose**: Add pyarrow dependency and create module skeleton

- [x] T001 Add pyarrow dependency to pyproject.toml
- [x] T002 Create empty module file at src/maketab/parquet.py

---

## Phase 2: Foundational (Type Mapping Infrastructure)

**Purpose**: Core type mapping logic that all user stories depend on

- [x] T003 Implement type mapping dict (str/int/float/bool to Arrow types) and schema extraction helper that derives an Arrow schema from a Pydantic model class in src/maketab/parquet.py
- [x] T004 Write tests for type mapping and schema extraction (all 4 base types, all 4 Optional variants, unsupported type raises ValueError) in tests/test_parquet_schema.py

**Checkpoint**: Type mapping infrastructure tested and ready — user story implementation can begin

---

## Phase 3: User Story 1 - Convert Flattened Data to Parquet Buffer (Priority: P1) 🎯 MVP

**Goal**: Users can pass a list of flattened Pydantic model instances to `to_parquet` and receive an `io.BytesIO` buffer containing valid Parquet data.

**Independent Test**: Flatten a sample dataset, call `to_parquet`, read the buffer back with pyarrow, and verify column names, types, and row data match exactly.

### Tests for User Story 1

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [x] T005 [P] [US1] Write round-trip test: flatten sample data, call to_parquet, read back with pyarrow, assert column names and values match in tests/test_parquet_basic.py
- [x] T006 [P] [US1] Write mixed-type test: model with str, int, float, bool fields; verify all column types are correct in tests/test_parquet_basic.py
- [x] T007 [P] [US1] Write empty-input test: to_parquet with empty list returns valid zero-row Parquet with correct schema in tests/test_parquet_edge_cases.py
- [x] T008 [P] [US1] Write error test: model with unsupported field type raises ValueError in tests/test_parquet_edge_cases.py

### Implementation for User Story 1

- [x] T009 [US1] Implement `to_parquet(records: List[T], output_schema: Type[T]) -> io.BytesIO` in src/maketab/parquet.py — convert model instances to columnar arrays, build Arrow table, write to buffer, return BytesIO at position 0
- [x] T010 [US1] Export `to_parquet` from src/maketab/__init__.py and add to __all__

**Checkpoint**: `to_parquet` works end-to-end with programmatic Pydantic models. All US1 tests pass.

---

## Phase 4: User Story 2 - Config-Driven Parquet Output (Priority: P2)

**Goal**: Users can flatten data via YAML config and produce a Parquet buffer in a single call using `flatten_config_to_parquet`.

**Independent Test**: Load a YAML config, call `flatten_config_to_parquet` with sample data, read the buffer back and verify it matches the expected flattened output.

### Tests for User Story 2

- [x] T011 [P] [US2] Write config-driven round-trip test: load config, call flatten_config_to_parquet, read back and verify data matches in tests/test_parquet_config.py
- [x] T012 [P] [US2] Write nullable fields test: config with nullable fields, input with None values, verify nulls represented correctly in Parquet output in tests/test_parquet_config.py
- [x] T013 [P] [US2] Write equivalence test: verify flatten_config + to_parquet produces identical output to flatten_config_to_parquet in tests/test_parquet_config.py

### Implementation for User Story 2

- [x] T014 [US2] Implement `flatten_config_to_parquet(config: SchemaConfig, data: List[Dict]) -> io.BytesIO` in src/maketab/parquet.py — compose flatten_config and to_parquet, passing the dynamically built model
- [x] T015 [US2] Export `flatten_config_to_parquet` from src/maketab/__init__.py and add to __all__

**Checkpoint**: Both programmatic and config-driven Parquet output work. All US1 and US2 tests pass.

---

## Phase 5: User Story 3 - Stream Parquet Buffer to External Tool (Priority: P3)

**Goal**: The returned buffer is confirmed to behave as a standard file-like object, usable anywhere a file-like interface is expected.

**Independent Test**: Verify the buffer supports read, seek, tell operations and contains valid Parquet magic bytes.

### Tests for User Story 3

- [x] T016 [P] [US3] Write file-like interface test: verify returned BytesIO supports read(), seek(), tell() and can be re-read after seeking to 0 in tests/test_parquet_streaming.py
- [x] T017 [P] [US3] Write Parquet magic bytes test: verify buffer starts with PAR1 magic bytes and ends with PAR1 footer in tests/test_parquet_streaming.py
- [x] T018 [P] [US3] Write large dataset test: convert 100,000 records to Parquet, verify no errors or data loss in tests/test_parquet_streaming.py

**Checkpoint**: All streaming and compatibility guarantees verified. All tests pass.

---

## Phase 6: Polish & Cross-Cutting Concerns

- [x] T019 Add Google-style docstrings to `to_parquet` and `flatten_config_to_parquet` in src/maketab/parquet.py
- [x] T020 Run full test suite (pytest) and verify all tests pass
- [x] T021 Run quickstart.md validation — execute the code examples and confirm they work

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — start immediately
- **Foundational (Phase 2)**: Depends on Phase 1 (pyarrow must be installed)
- **User Story 1 (Phase 3)**: Depends on Phase 2 (type mapping must exist)
- **User Story 2 (Phase 4)**: Depends on Phase 3 (needs `to_parquet` and model extraction)
- **User Story 3 (Phase 5)**: Depends on Phase 3 (needs working `to_parquet` to test buffer behavior)
- **Polish (Phase 6)**: Depends on all user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Depends only on Foundational phase
- **User Story 2 (P2)**: Depends on US1 (`flatten_config_to_parquet` calls `to_parquet` internally)
- **User Story 3 (P3)**: Can start after US1 (tests buffer from `to_parquet`). Can run in parallel with US2.

### Within Each User Story

- Tests written first and confirmed to fail
- Implementation follows
- Story checkpoint validates independently

### Parallel Opportunities

- T005, T006, T007, T008 can all run in parallel (different test scenarios, independent)
- T011, T012, T013 can all run in parallel
- T016, T017, T018 can all run in parallel
- US2 and US3 can run in parallel after US1 completes

---

## Parallel Example: User Story 1

```bash
# Launch all US1 tests together (they should all fail initially):
Task: "Round-trip test in tests/test_parquet_basic.py"
Task: "Mixed-type test in tests/test_parquet_basic.py"
Task: "Empty-input test in tests/test_parquet_edge_cases.py"
Task: "Error test in tests/test_parquet_edge_cases.py"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (add pyarrow, create module)
2. Complete Phase 2: Foundational (type mapping + schema extraction)
3. Complete Phase 3: User Story 1 (to_parquet + tests)
4. **STOP and VALIDATE**: Test to_parquet independently
5. Usable immediately — users can flatten then convert to Parquet

### Incremental Delivery

1. Setup + Foundational → Infrastructure ready
2. Add User Story 1 → `to_parquet` works → MVP!
3. Add User Story 2 → `flatten_config_to_parquet` works → Config users served
4. Add User Story 3 → Streaming guarantees validated → Full confidence
5. Polish → Docstrings, full suite validation

---

## Notes

- [P] tasks = different files or independent test scenarios, no dependencies
- [Story] label maps task to specific user story for traceability
- Constitution requires tests for all user-facing behavior (Principle III)
- Constitution requires docstrings on all public functions
- New pyarrow dependency justified per research.md (R1)
