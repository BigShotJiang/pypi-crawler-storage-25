# Contract: TUI Layout

**Feature**: 004-tui-schema-debugger  
**Date**: 2026-04-05

## Pane Layout

```
┌─────────────────────────┬─────────────────────────┐
│                         │     Input Record         │
│   Schema Definition     │   [JSON | Python Dict]   │
│   [YAML | Python]       │                         │
│                         ├─────────────────────────┤
│                         │     Output / Error       │
│                         │   (field, value, type)   │
│                         │                         │
└─────────────────────────┴─────────────────────────┘
          Footer: [Run: Ctrl+R]  [Quit: Ctrl+Q]
```

### Left Pane — Schema Definition (full height)
- Editable text area for schema content
- Toggle between YAML and Pydantic/Python format (visible in pane header)
- Scrollable when content overflows

### Top-Right Pane — Input Record (half height)
- Editable text area for input data
- Toggle between JSON and Python dict format (visible in pane header)
- Scrollable when content overflows

### Bottom-Right Pane — Output Display (half height)
- Read-only display area
- On success: shows table with columns — Field Name, Value, Type
- On error: shows full Python traceback text
- On empty/not-yet-run: shows instructional placeholder message
- Scrollable when content overflows

### Footer
- Shows key bindings: Run (Ctrl+R), Quit (Ctrl+Q), and format toggle hints
