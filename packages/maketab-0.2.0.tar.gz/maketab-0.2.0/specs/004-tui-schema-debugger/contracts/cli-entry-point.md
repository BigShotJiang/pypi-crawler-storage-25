# Contract: CLI Entry Point

**Feature**: 004-tui-schema-debugger  
**Date**: 2026-04-05

## Console Script

**Command**: `maketab-tui`

**Behavior**: Launches the Textual TUI application. No required arguments.

**Alternative invocation**: `python -m maketab.tui`

**Prerequisites**: The `tui` optional extra must be installed (`pip install maketab[tui]`).

**Error on missing dependency**: If `textual` is not installed and the user attempts to run the TUI, a clear error message must be displayed indicating they need to install the `[tui]` extra.

## Exit

The TUI exits cleanly on standard Textual quit actions (Ctrl+C, Ctrl+Q, or the quit binding).
