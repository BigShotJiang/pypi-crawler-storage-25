# Tasks: TUI Schema Debugger

**Input**: Design documents from `/specs/004-tui-schema-debugger/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Not explicitly requested in spec. Test tasks omitted.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project configuration and dependency setup for the TUI feature

- [x] T001 Add `textual` as optional dependency under `[project.optional-dependencies]` tui extra in pyproject.toml
- [x] T002 Add `maketab-tui` console script entry point in pyproject.toml pointing to `maketab.tui:main`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core TUI application shell and shared parsing utilities that all user stories depend on

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [x] T003 Create Textual app skeleton with three-pane layout (left full-height, top-right half-height, bottom-right half-height) in src/maketab/tui.py — include `main()` entry point and `if __name__ == "__main__"` block
- [x] T004 Implement YAML schema parsing function that takes text input and returns a `SchemaConfig` (reusing `maketab.config.SchemaConfig.model_validate` with `yaml.safe_load`) in src/maketab/tui.py
- [x] T005 [P] Implement Python/Pydantic schema parsing function that takes text input, executes it in a controlled namespace pre-populated with `Query`, `Explode`, `BaseModel`, `Annotated`, `Optional`, `List`, and extracts the `BaseModel` subclass from the resulting namespace in src/maketab/tui.py
- [x] T006 [P] Implement JSON input parsing function using `json.loads` and Python dict input parsing function using `ast.literal_eval` in src/maketab/tui.py
- [x] T007 Implement evaluation bridge function that takes a parsed schema (either `SchemaConfig` or `BaseModel` subclass) and a parsed input dict, calls `flatten_config` or `flatten` accordingly, and returns an `EvaluationResult` (success with rows or error with full traceback via `traceback.format_exc()`) in src/maketab/tui.py

**Checkpoint**: Foundation ready — TUI app launches with empty panes, all parsing and evaluation utilities available

---

## Phase 3: User Story 1 - Edit Schema and See Live Output (Priority: P1) 🎯 MVP

**Goal**: Users can enter a schema and input record, trigger evaluation, and see flattened output (field name, value, type) in the output pane

**Independent Test**: Launch TUI, type a valid YAML schema and JSON input, press Ctrl+R, verify output table appears

### Implementation for User Story 1

- [x] T008 [US1] Add editable TextArea widget to the left pane for schema input with a default YAML example placeholder in src/maketab/tui.py
- [x] T009 [US1] Add editable TextArea widget to the top-right pane for input record with a default JSON example placeholder in src/maketab/tui.py
- [x] T010 [US1] Add read-only output display widget to the bottom-right pane that renders a table (field name, value, type) or a placeholder message when no evaluation has run in src/maketab/tui.py
- [x] T011 [US1] Wire Ctrl+R key binding to trigger evaluation: read schema text + input text from panes, parse both, run evaluation bridge, and update output pane with result table or full traceback in src/maketab/tui.py
- [x] T012 [US1] Add footer bar showing key bindings (Run: Ctrl+R, Quit: Ctrl+Q) in src/maketab/tui.py
- [x] T013 [US1] Handle multiple output rows from explode fields — display all rows in the output table in src/maketab/tui.py

**Checkpoint**: User Story 1 fully functional — users can enter YAML schemas and JSON input, evaluate, and see output or errors

---

## Phase 4: User Story 2 - Debug Schema Errors (Priority: P1)

**Goal**: When evaluation fails, the output pane shows the full Python traceback instead of output data

**Independent Test**: Enter a broken schema (e.g., invalid JMESPath, malformed YAML), press Ctrl+R, verify full traceback is displayed

### Implementation for User Story 2

- [x] T014 [US2] Ensure schema parse errors (malformed YAML, invalid Python syntax) display the full traceback in the output pane instead of output data in src/maketab/tui.py
- [x] T015 [US2] Ensure input parse errors (malformed JSON, invalid Python dict literal) display the full traceback in the output pane in src/maketab/tui.py
- [x] T016 [US2] Ensure evaluation errors (invalid JMESPath, type mismatches, pydantic validation errors) display the full traceback in the output pane in src/maketab/tui.py
- [x] T017 [US2] Handle empty schema or empty input gracefully — display a descriptive message (not a cryptic error) in the output pane in src/maketab/tui.py

**Checkpoint**: All error paths produce readable, scrollable tracebacks in the output pane

---

## Phase 5: User Story 3 - Toggle Input/Output Formats (Priority: P2)

**Goal**: Users can switch between YAML/Python for schema and JSON/Python dict for input without restarting

**Independent Test**: Enter content, toggle format, trigger evaluation, verify parsing uses the new format

### Implementation for User Story 3

- [x] T018 [US3] Add toggle control (e.g., Textual RadioSet or TabPane header) to the schema pane to switch between YAML and Pydantic/Python mode, updating the pane header label in src/maketab/tui.py
- [x] T019 [US3] Add toggle control to the input pane to switch between JSON and Python dict mode, updating the pane header label in src/maketab/tui.py
- [x] T020 [US3] Wire toggle state into the evaluation flow — schema pane format determines which parser is called, input pane format determines which input parser is called in src/maketab/tui.py
- [x] T021 [US3] Ensure toggling format preserves existing text content in the pane (no clearing on toggle) in src/maketab/tui.py

**Checkpoint**: Users can freely switch formats and evaluate with any combination of schema + input format

---

## Phase 6: User Story 4 - Scroll Overflowing Content (Priority: P2)

**Goal**: All three panes are independently scrollable when content exceeds visible height

**Independent Test**: Enter content that exceeds pane height, scroll within each pane, verify independent scrolling

### Implementation for User Story 4

- [x] T022 [US4] Ensure the schema TextArea supports vertical scrolling for content exceeding pane height in src/maketab/tui.py
- [x] T023 [US4] Ensure the input TextArea supports vertical scrolling for content exceeding pane height in src/maketab/tui.py
- [x] T024 [US4] Ensure the output display area supports vertical scrolling for long output tables and long error tracebacks in src/maketab/tui.py

**Checkpoint**: All panes scroll independently — large schemas, deep inputs, and verbose tracebacks are fully accessible

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Final improvements across all user stories

- [x] T025 Add CSS styling for pane borders, headers, and visual separation between the three panes in src/maketab/tui.py
- [ ] T026 Validate quickstart.md scenarios work end-to-end (YAML+JSON example, Python+dict example) by running them manually in the TUI
- [x] T027 Ensure graceful terminal resize behaviour — panes maintain usable proportions on small terminals in src/maketab/tui.py

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Stories (Phase 3+)**: All depend on Foundational phase completion
  - US1 and US2 are both P1 but US2 builds on US1's evaluation flow — implement US1 first
  - US3 and US4 are P2 and can proceed independently after US1
- **Polish (Phase 7)**: Depends on all user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Foundational (Phase 2) — no dependencies on other stories
- **User Story 2 (P1)**: Depends on US1 (evaluation flow must exist to test error paths)
- **User Story 3 (P2)**: Can start after US1 (toggle affects parsing, which needs the evaluation flow)
- **User Story 4 (P2)**: Can start after Foundational (Phase 2) — scrolling is inherent to widget setup

### Within Each User Story

- Core widgets before wiring
- Parsing before evaluation
- Success path before error paths
- Commit after each task or logical group

### Parallel Opportunities

- T005 and T006 can run in parallel (independent parsing functions)
- US3 and US4 can start in parallel after US1 is complete
- T022, T023, T024 can all run in parallel (independent pane scrolling)

---

## Parallel Example: User Story 1

```bash
# After foundational phase, launch US1 tasks:
# T008 and T009 can run in parallel (independent pane widgets):
Task: "Add schema TextArea to left pane in src/maketab/tui.py"
Task: "Add input TextArea to top-right pane in src/maketab/tui.py"

# Then T010, T011 sequentially (output depends on both inputs being wired)
```

## Parallel Example: Foundational Phase

```bash
# T005 and T006 can run in parallel (independent parsing functions):
Task: "Implement Python/Pydantic schema parsing in src/maketab/tui.py"
Task: "Implement JSON and Python dict input parsing in src/maketab/tui.py"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (T001-T002)
2. Complete Phase 2: Foundational (T003-T007)
3. Complete Phase 3: User Story 1 (T008-T013)
4. **STOP and VALIDATE**: Launch `maketab-tui`, enter YAML schema + JSON input, press Ctrl+R, verify output
5. Working prototype ready for feedback

### Incremental Delivery

1. Complete Setup + Foundational → TUI app launches with empty panes
2. Add User Story 1 → Evaluation works with YAML/JSON → MVP!
3. Add User Story 2 → Error tracebacks visible → Debug-ready
4. Add User Story 3 → Format toggles work → Full format flexibility
5. Add User Story 4 → Scrolling works → Production-quality UX
6. Polish → Styled, validated, resize-safe

---

## Notes

- All implementation is in a single file: `src/maketab/tui.py`
- No changes to existing maketab modules (`core.py`, `config.py`, `parquet.py`, `__init__.py`)
- `textual` is the only new dependency, gated behind `[tui]` optional extra
- Tasks within the same file are sequential by default unless marked [P] (parallel-safe because they touch independent functions/widgets)
