# Research: TUI Schema Debugger

**Feature**: 004-tui-schema-debugger  
**Date**: 2026-04-05

## R1: Textual as TUI Framework

**Decision**: Use Textual (by Textualize) as the TUI framework.

**Rationale**: User explicitly requested "textualize". Textual provides CSS-based layout, built-in widgets (TextArea, Static, tabs/toggles), scrollable containers, and a testing framework (`pilot`) for automated UI tests. It is the most mature Python TUI framework for rich interactive applications.

**Alternatives considered**:
- **urwid**: Lower-level, more boilerplate for layout and styling. No built-in testing harness.
- **prompt_toolkit**: Better suited for CLI prompts than multi-pane applications.
- **curses/blessed**: Too low-level for this use case.

## R2: Optional Dependency Strategy

**Decision**: Add `textual` as an optional extra in `pyproject.toml` under `[project.optional-dependencies]` with a group name like `tui`.

**Rationale**: Constitution Principle I (Library-First) requires minimal core dependencies. Users install via `pip install maketab[tui]`. The `tui.py` module imports textual at the top level — if textual is not installed, the module simply cannot be imported, which is acceptable since it is not imported by `__init__.py`.

**Alternatives considered**:
- Lazy imports with try/except: Adds complexity for no benefit since the entire module is TUI-specific.
- Separate package (e.g., `maketab-tui`): Over-engineered for a single module.

## R3: Safe Evaluation of Python Dict Input

**Decision**: Use `ast.literal_eval` for parsing Python dict input strings.

**Rationale**: `ast.literal_eval` safely evaluates strings containing Python literals (dicts, lists, strings, numbers, booleans, None) without executing arbitrary code. This covers the use case of users typing `{"key": "value", "nested": [1, 2, 3]}` in the input pane.

**Alternatives considered**:
- `eval()`: Security risk — executes arbitrary code.
- `json.loads()`: Already covered by JSON mode; Python dict mode needs to handle Python-specific syntax like single quotes, `True`/`False`/`None`.

## R4: Pydantic/Python Schema Evaluation

**Decision**: Use `exec()` in a controlled namespace to evaluate Python schema definitions, then extract the Pydantic model class from the resulting namespace.

**Rationale**: Users need to write Python code defining Pydantic models with `Query`/`Explode` annotations. This inherently requires code execution. The TUI is a local development tool (not a web service), so the security risk is equivalent to running a Python script locally — acceptable for developer tooling. The namespace will be pre-populated with maketab imports (`Query`, `Explode`, `BaseModel`, `Annotated`, etc.).

**Alternatives considered**:
- AST-based approach: Cannot handle the full range of valid Pydantic model definitions (decorators, validators, complex type annotations).
- Restrict to YAML-only: Would eliminate half the feature's value — many users define schemas as Pydantic models directly.

## R5: TUI Entry Point

**Decision**: Provide a console script entry point `maketab-tui` and a `python -m maketab.tui` invocation.

**Rationale**: A console script is the standard way to expose CLI tools from Python packages. The `-m` fallback is conventional and requires no extra configuration. Both are gated behind the `[tui]` optional dependency being installed.

**Alternatives considered**:
- Subcommand of a `maketab` CLI: No CLI exists currently; creating one just for the TUI adds unnecessary scope.

## R6: Evaluation Trigger

**Decision**: Provide a keyboard shortcut (e.g., Ctrl+R or a visible "Run" button/footer binding) to trigger evaluation. Do not auto-evaluate on every keystroke.

**Rationale**: Auto-evaluation on every keystroke would cause excessive processing with potentially invalid intermediate states, leading to constant error flashing. An explicit trigger gives users control over when to evaluate, which is standard for REPL-like tools.

**Alternatives considered**:
- Auto-evaluate with debounce: Still produces many intermediate error states during typing. Could be added as a future enhancement.
- Auto-evaluate on focus change: Unintuitive — users may switch panes without wanting to evaluate.

## R7: Textual Testing Approach

**Decision**: Use Textual's `pilot` testing API for app-level tests, and standard pytest for parsing/evaluation logic unit tests.

**Rationale**: Textual provides `App.run_test()` which creates a headless app instance with a `Pilot` object for simulating user interactions. This allows testing layout, widget content, and interactions without a real terminal. Parsing logic (YAML, JSON, Python dict, Python schema) should be tested independently as pure functions.

**Alternatives considered**:
- Snapshot testing only: Fragile and hard to maintain for interactive apps.
- Manual testing only: Violates Constitution Principle III.
