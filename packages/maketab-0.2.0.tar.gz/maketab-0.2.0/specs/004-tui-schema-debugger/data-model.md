# Data Model: TUI Schema Debugger

**Feature**: 004-tui-schema-debugger  
**Date**: 2026-04-05

## Entities

### SchemaInput

Represents the user's schema definition text and its format.

- **text** (str): Raw text content from the schema editor pane
- **format** (enum: YAML | PYTHON): Currently selected schema format

### RecordInput

Represents the user's input record text and its format.

- **text** (str): Raw text content from the input record editor pane
- **format** (enum: JSON | PYTHON_DICT): Currently selected input format

### EvaluationResult

The outcome of applying a parsed schema to a parsed input record.

- **success** (bool): Whether evaluation completed without error
- **rows** (list of OutputRow, if success): Flattened output records
- **error** (str, if not success): Full traceback string

### OutputRow

A single row of flattened output.

- **fields** (list of OutputField): Ordered field values for this row

### OutputField

A single field within an output row.

- **name** (str): Field name from the schema
- **value** (any): Extracted value after applying the query
- **type** (str): Python type name of the value

## Relationships

```
SchemaInput + RecordInput → [evaluation] → EvaluationResult
EvaluationResult (success) → 1..* OutputRow → 1..* OutputField
EvaluationResult (failure) → error traceback string
```

## State Transitions

The TUI has a simple state model:

1. **Idle**: User is editing schema or input. No evaluation in progress.
2. **Evaluating**: User triggered evaluation. Schema and input are parsed and processed.
3. **Displaying Result**: Output pane shows either rows or error traceback.

Transitions:
- Idle → Evaluating: User presses Run (e.g., Ctrl+R)
- Evaluating → Displaying Result: Evaluation completes (success or error)
- Displaying Result → Idle: User modifies schema or input text

## Validation Rules

- Schema text in YAML mode must parse as valid YAML matching `SchemaConfig` structure
- Schema text in Python mode must be valid Python containing exactly one `BaseModel` subclass with `Query`/`Explode` annotations
- Input text in JSON mode must parse as valid JSON producing a dict
- Input text in Python dict mode must parse via `ast.literal_eval` as a dict
- Empty schema or input text produces a descriptive message (not a cryptic error)
