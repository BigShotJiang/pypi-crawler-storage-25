# Implementation Plan: TUI Schema Debugger

**Branch**: `004-tui-schema-debugger` | **Date**: 2026-04-05 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/004-tui-schema-debugger/spec.md`

## Summary

Add an optional TUI (built with Textual) for interactively testing and debugging maketab schema definitions. The TUI provides a three-pane layout: schema editor (left, full height), input record editor (top-right), and output/error display (bottom-right). Users can toggle between YAML and Pydantic/Python schema formats and between JSON and Python dict input formats, with evaluation results updating on demand.

## Technical Context

**Language/Version**: Python 3.10+  
**Primary Dependencies**: textual (new, optional extra), pydantic >=2.0.0, jmespath >=1.0.0, pyyaml >=6.0.0  
**Storage**: N/A (in-memory only, no persistence)  
**Testing**: pytest  
**Target Platform**: Terminal (macOS, Linux, Windows via compatible terminals)  
**Project Type**: Library with optional TUI feature  
**Performance Goals**: N/A (interactive single-user tool)  
**Constraints**: Textual must be an optional dependency; core maketab must not import or depend on it  
**Scale/Scope**: Single-user local debugging tool

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Library-First | **PASS** | TUI is an optional extra, not required for core API. The core library remains unchanged. New dependency (textual) is justified: it provides the TUI capability which cannot be addressed with existing deps or stdlib. |
| II. Type Safety and Schema-Driven Design | **PASS** | No changes to Query/Explode annotations or public schema interfaces. TUI consumes existing APIs. |
| III. Correctness Through Testing | **PASS** | TUI logic (parsing, evaluation bridging) will have pytest tests. UI rendering tests can use Textual's built-in testing support. |
| IV. Simplicity | **PASS** | Single new module (`tui.py`) with straightforward pane layout. No new abstractions beyond what Textual requires. |
| API Design Constraints | **PASS** | No changes to `__all__` exports. TUI is a separate entry point, not a public API addition to the library. |

No violations. Gate passes.

## Project Structure

### Documentation (this feature)

```text
specs/004-tui-schema-debugger/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
└── tasks.md             # Phase 2 output (created by /speckit.tasks)
```

### Source Code (repository root)

```text
src/
└── maketab/
    ├── __init__.py      # Unchanged — no new public exports
    ├── core.py          # Unchanged
    ├── config.py        # Unchanged
    ├── parquet.py        # Unchanged
    └── tui.py           # NEW — Textual app, all TUI logic in one module

tests/
├── test_tui_parsing.py  # NEW — unit tests for schema/input parsing logic
└── test_tui_app.py      # NEW — Textual app rendering/interaction tests
```

**Structure Decision**: Single new module `tui.py` in the existing `src/maketab/` package. The TUI is self-contained and does not modify any existing modules. Tests follow the existing flat test file convention.
