# Quickstart: TUI Schema Debugger

**Feature**: 004-tui-schema-debugger  
**Date**: 2026-04-05

## Installation

```bash
pip install maketab[tui]
```

## Launch

```bash
maketab-tui
```

Or:

```bash
python -m maketab.tui
```

## Usage

1. **Write a schema** in the left pane. Toggle between YAML and Python format using the pane header toggle.

2. **Provide input data** in the top-right pane. Toggle between JSON and Python dict format.

3. **Press Ctrl+R** to evaluate. Results appear in the bottom-right pane.

4. **On success**: the output pane shows a table of field name, value, and type for each flattened field. Multiple rows are shown if the schema uses explode fields.

5. **On error**: the output pane shows the full Python traceback. Scroll to see the complete trace.

## Example: YAML Schema + JSON Input

**Schema (YAML)**:
```yaml
fields:
  - name: user_name
    type: str
    query: user.name
  - name: email
    type: str
    query: user.email
```

**Input (JSON)**:
```json
{"user": {"name": "Alice", "email": "alice@example.com"}}
```

**Output**:
```
Field Name  | Value             | Type
------------|-------------------|-----
user_name   | Alice             | str
email       | alice@example.com | str
```

## Example: Python Schema + Python Dict Input

**Schema (Python)**:
```python
class UserSchema(BaseModel):
    user_name: Annotated[str, Query("user.name")]
    email: Annotated[str, Query("user.email")]
```

**Input (Python Dict)**:
```python
{"user": {"name": "Alice", "email": "alice@example.com"}}
```

## Key Bindings

| Key     | Action                    |
|---------|---------------------------|
| Ctrl+R  | Run evaluation            |
| Ctrl+Q  | Quit                      |
| Tab     | Move focus between panes  |
