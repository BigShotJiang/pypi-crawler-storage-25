# Feature Specification: TUI Schema Debugger

**Feature Branch**: `004-tui-schema-debugger`  
**Created**: 2026-04-05  
**Status**: Draft  
**Input**: User description: "We want to add an optional feature to this library to allow locally testing and debugging schema definitions using a TUI (using textualize). The TUI can be a single window with three panes: on the left a full height pane where you can design the output schema/queries (with a toggle for either pydantic/python or yaml def). On the right there should be two half height panes, the one at the top where you can edit an input record (toggle for python dict or json def) and then finally the bottom right half-pane as the output showing field name, value and type (after applying the output def to the input record). If there is an error this should be displayed in the bottom right pane, instead of output data, full traceback should be visibile and all panes should be scrollable if the content overflows."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Edit Schema and See Live Output (Priority: P1)

A user is developing a maketab schema definition to flatten nested data. They launch the TUI, paste or type their schema definition in the left pane (in either YAML or Pydantic/Python format), provide a sample input record in the top-right pane, and immediately see the resulting flattened output in the bottom-right pane showing each field's name, extracted value, and resolved type.

**Why this priority**: This is the core value proposition — a live feedback loop for schema development that eliminates the write-run-check cycle.

**Independent Test**: Can be fully tested by launching the TUI, entering a valid schema and a valid input record, and verifying the output pane displays correct field names, values, and types.

**Acceptance Scenarios**:

1. **Given** the TUI is open with a valid YAML schema in the left pane and a valid JSON input record in the top-right pane, **When** the user triggers evaluation, **Then** the bottom-right pane displays a table of field name, value, and type for each output field.
2. **Given** the TUI is open with a valid Pydantic/Python schema in the left pane and a valid Python dict input in the top-right pane, **When** the user triggers evaluation, **Then** the bottom-right pane displays the same structured output.
3. **Given** the user modifies the schema definition, **When** the evaluation is triggered again, **Then** the output updates to reflect the new schema.

---

### User Story 2 - Debug Schema Errors (Priority: P1)

A user has written a schema definition that contains an error (e.g., invalid JMESPath expression, type mismatch, malformed YAML/Python). When they evaluate, the bottom-right pane displays a full error traceback instead of output data, allowing them to diagnose and fix the issue.

**Why this priority**: Error visibility is essential for a debugging tool — without it, users cannot iterate on broken schemas.

**Independent Test**: Can be tested by entering an intentionally broken schema, triggering evaluation, and verifying the full traceback is displayed in the output pane.

**Acceptance Scenarios**:

1. **Given** the left pane contains a schema with an invalid JMESPath expression and the top-right pane has a valid input, **When** the user triggers evaluation, **Then** the bottom-right pane displays the full Python traceback instead of output data.
2. **Given** the left pane contains malformed YAML, **When** the user triggers evaluation, **Then** the bottom-right pane displays a parse error traceback.
3. **Given** the top-right pane contains malformed JSON or invalid Python dict syntax, **When** the user triggers evaluation, **Then** the bottom-right pane displays the relevant parse error traceback.

---

### User Story 3 - Toggle Input/Output Formats (Priority: P2)

A user prefers working with YAML for schema definitions but wants to provide input data as JSON (or vice versa with Pydantic/Python and Python dicts). They use toggle controls on the schema pane and input pane to switch between supported formats without losing their work.

**Why this priority**: Format flexibility is important for usability but the core feedback loop works with any single format combination.

**Independent Test**: Can be tested by entering content in one format, toggling to the other format, and verifying the pane adapts its parsing accordingly.

**Acceptance Scenarios**:

1. **Given** the schema pane is in YAML mode, **When** the user toggles to Pydantic/Python mode, **Then** the pane label updates and subsequent evaluation parses the content as Python.
2. **Given** the input pane is in JSON mode, **When** the user toggles to Python dict mode, **Then** the pane label updates and subsequent evaluation parses the content as a Python dict.

---

### User Story 4 - Scroll Overflowing Content (Priority: P2)

A user is working with a large schema, a deeply nested input record, or a verbose error traceback. The content overflows the visible pane area. The user scrolls within each pane independently to view all content.

**Why this priority**: Scrolling is necessary for real-world use cases with non-trivial data, but the core functionality works without it for small examples.

**Independent Test**: Can be tested by entering content that exceeds the pane height and verifying scroll behaviour within each pane.

**Acceptance Scenarios**:

1. **Given** the schema pane contains more lines than the visible height, **When** the user scrolls within the schema pane, **Then** additional content becomes visible without affecting other panes.
2. **Given** an error traceback in the output pane is longer than the visible height, **When** the user scrolls within the output pane, **Then** the full traceback is accessible.

---

### Edge Cases

- What happens when both panes are empty and evaluation is triggered? The output pane should display a clear message indicating that schema and/or input are required.
- What happens when the input record is valid but contains no data matching the schema queries? The output pane should display the field names with empty/null values and their expected types.
- What happens when the schema produces multiple output rows (via explode fields)? All rows should be displayed in the output pane.
- What happens when the terminal window is very small? The layout should degrade gracefully, with panes maintaining minimum usable sizes or the TUI framework handling resize.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The TUI MUST display three panes: a full-height left pane for schema editing, a top-right pane for input record editing, and a bottom-right pane for output display.
- **FR-002**: The schema pane MUST support toggling between YAML and Pydantic/Python definition formats.
- **FR-003**: The input pane MUST support toggling between JSON and Python dict formats.
- **FR-004**: The output pane MUST display flattened results as a structured view showing field name, value, and type for each output field.
- **FR-005**: When evaluation produces an error, the output pane MUST display the full Python traceback instead of output data.
- **FR-006**: All three panes MUST be independently scrollable when content overflows the visible area.
- **FR-007**: The TUI MUST be an optional dependency of the library, not required for core functionality.
- **FR-008**: The TUI MUST provide a clear way for users to trigger evaluation of the schema against the input record.
- **FR-009**: When evaluation produces multiple output rows (e.g., from explode fields), all rows MUST be displayed in the output pane.

### Key Entities

- **Schema Definition**: The output schema describing how to flatten input data. Can be expressed as YAML config or Pydantic/Python model definition.
- **Input Record**: A sample data record to test the schema against. Can be expressed as JSON or Python dict.
- **Output Result**: The flattened output after applying the schema to the input, consisting of field names, extracted values, and resolved types.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Users can enter a schema definition and input record and see flattened output within the TUI in a single session, without needing to write and run a separate script.
- **SC-002**: When an error occurs during evaluation, 100% of the traceback is visible (scrollable) in the output pane.
- **SC-003**: Users can switch between schema formats (YAML / Pydantic) and input formats (JSON / Python dict) without restarting the TUI.
- **SC-004**: The TUI launches successfully from a single command and is usable without documentation beyond the visible controls.

## Assumptions

- The TUI is an optional feature — the Textual library (textualize) will be an optional/extras dependency, not required for core maketab usage.
- The TUI targets local development use only; it does not need to support remote or headless operation.
- The Pydantic/Python schema format in the TUI refers to writing Python code that defines maketab Query/Explode models, which will be evaluated to produce the schema.
- The Python dict format for input records will be evaluated as a Python literal (using safe evaluation) rather than arbitrary code execution.
- The TUI does not need to persist state between sessions (no save/load functionality required for v1).
- Terminal colour support and Unicode rendering are assumed to be available (standard for Textual apps).
