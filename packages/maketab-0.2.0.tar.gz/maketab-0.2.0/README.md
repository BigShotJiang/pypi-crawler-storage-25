# maketab

Make nested data tabular using jmespath queries with Pydantic models.