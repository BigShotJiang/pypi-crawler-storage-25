# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Store-backed command wrapper adapter."""

from __future__ import annotations

import dataclasses
import datetime as dt
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, BinaryIO, Callable, TextIO

from motus.kernel import Store

ADAPTER_NAME = "motus-wrap"
ADAPTER_VERSION = "1"
DEFAULT_MAX_OUTPUT_BYTES = 16_384
MAX_ARGV_DISPLAY_BYTES = 4_096
REDACTED = "[REDACTED]"

_SECRET_ARG_NAMES = {
    "--api-key",
    "--apikey",
    "--auth",
    "--authorization",
    "--bearer",
    "--client-secret",
    "--key",
    "--password",
    "--private-key",
    "--secret",
    "--token",
}

_Replacement = str | Callable[[re.Match[str]], str]

_TEXT_PATTERNS: tuple[tuple[str, re.Pattern[str], _Replacement], ...] = (
    (
        "bearer_token",
        re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]{8,}"),
        f"Bearer {REDACTED}",
    ),
    (
        "authorization_header",
        re.compile(r"(?im)^\s*authorization\s*:\s*[^\r\n]+"),
        f"Authorization: {REDACTED}",
    ),
    (
        "cookie_header",
        re.compile(r"(?im)^\s*(?:set-cookie|cookie)\s*:\s*[^\r\n]+"),
        lambda match: f"{match.group(0).split(':', 1)[0]}: {REDACTED}",
    ),
    (
        "github_token",
        re.compile(r"\b(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{8,}\b"),
        REDACTED,
    ),
    ("openai_api_key", re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"), REDACTED),
    ("aws_access_key", re.compile(r"\bA(?:KIA|SIA)[A-Z0-9]{12,}\b"), REDACTED),
    ("pypi_token", re.compile(r"\bpypi-[A-Za-z0-9_-]{12,}\b"), REDACTED),
    (
        "pem_private_key",
        re.compile(
            r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----",
            re.DOTALL,
        ),
        REDACTED,
    ),
    (
        "generic_secret_assignment",
        re.compile(
            r"(?i)\b(token|password|passwd|secret|api[_-]?key|private[_-]?key)\s*[:=]\s*[^ \t\r\n]+"
        ),
        lambda match: f"{match.group(1)}={REDACTED}",  # type: ignore[arg-type]
    ),
)


@dataclasses.dataclass(frozen=True)
class RedactedText:
    value: str
    applied: bool
    reason_codes: tuple[str, ...]


@dataclasses.dataclass(frozen=True)
class StreamCapture:
    text: str
    byte_count: int
    line_count: int
    truncated: bool


@dataclasses.dataclass(frozen=True)
class WrapResult:
    exit_code: int
    run_id: str | None
    store_path: Path | None
    outcome: str | None
    timed_out: bool


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def _sha256_identifier(prefix: str, value: str) -> str:
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
    return f"{prefix}-sha256-{digest}"


def _safe_store_identifier(
    value: str,
    *,
    prefix: str,
    force_hash: bool,
) -> tuple[str, tuple[str, ...]]:
    text = redact_text(value)
    if force_hash or text.applied:
        reasons = ["store_metadata_identifier_hashed", *text.reason_codes]
        return _sha256_identifier(prefix, value), tuple(dict.fromkeys(reasons))
    return text.value, tuple(text.reason_codes)


def _safe_intent(intent: str | None, default: str) -> tuple[str, tuple[str, ...]]:
    if intent is None:
        return default, ()
    text = redact_text(intent)
    reasons = ["explicit_intent_hashed", *text.reason_codes]
    return _sha256_identifier("intent", intent), tuple(dict.fromkeys(reasons))


def _default_store_path() -> Path:
    override = os.environ.get("MOTUS_KERNEL_STORE_PATH") or os.environ.get("MOTUS_STORE_PATH")
    if override:
        return Path(override).expanduser()
    return Path.cwd() / ".motus" / "kernel-store.db"


def _new_idempotency_key(prefix: str) -> str:
    return f"{prefix}-{time.time_ns()}-{os.getpid()}"


def redact_text(value: str) -> RedactedText:
    """Redact secret-like text before it can become Store payload."""

    result = value
    reasons: list[str] = []
    for reason, pattern, replacement in _TEXT_PATTERNS:
        updated, count = pattern.subn(replacement, result)
        if count:
            reasons.append(reason)
            result = updated
    return RedactedText(result, bool(reasons), tuple(dict.fromkeys(reasons)))


def redact_argv(argv: list[str]) -> tuple[list[str], tuple[str, ...]]:
    """Redact secret-like argv values and secret-flag payloads."""

    redacted: list[str] = []
    reasons: list[str] = []
    redact_next = False

    for arg in argv:
        if redact_next:
            redacted.append(REDACTED)
            reasons.append("secret_like_argv_flag")
            redact_next = False
            continue

        flag, sep, _value = arg.partition("=")
        lower_flag = flag.lower()
        if lower_flag in _SECRET_ARG_NAMES:
            reasons.append("secret_like_argv_flag")
            if sep:
                redacted.append(f"{flag}={REDACTED}")
            else:
                redacted.append(arg)
                redact_next = True
            continue

        text = redact_text(arg)
        if text.applied:
            reasons.extend(text.reason_codes)
        redacted.append(text.value)

    return redacted, tuple(dict.fromkeys(reasons))


def summarize_argv(argv: list[str]) -> tuple[list[str], tuple[str, ...]]:
    """Return a non-content argv summary safe for Store payloads."""

    _redacted, reasons = redact_argv(argv)
    executable = Path(argv[0]).name if argv else ""
    executable_text = redact_text(executable)
    all_reasons = [*reasons, *executable_text.reason_codes]
    summary = [executable_text.value or "[COMMAND]"]
    if len(argv) > 1:
        summary.append(f"[ARGUMENTS_OMITTED:{len(argv) - 1}]")
    if all_reasons:
        summary.append(REDACTED)
    return summary, tuple(dict.fromkeys(all_reasons))


def _command_display(argv: list[str]) -> str:
    display = " ".join(shlex.quote(part) for part in argv)
    if len(display.encode("utf-8")) <= MAX_ARGV_DISPLAY_BYTES:
        return display
    encoded = display.encode("utf-8")[:MAX_ARGV_DISPLAY_BYTES]
    return encoded.decode("utf-8", errors="ignore") + "...[truncated]"


def _git_value(args: list[str], cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def _git_sha(cwd: Path) -> str | None:
    return _git_value(["rev-parse", "HEAD"], cwd)


def _git_dirty(cwd: Path) -> bool | None:
    value = _git_value(["status", "--porcelain"], cwd)
    if value is None:
        return None
    return bool(value)


def _write_bytes(target: TextIO, chunk: bytes) -> None:
    buffer = getattr(target, "buffer", None)
    if buffer is not None:
        buffer.write(chunk)
        buffer.flush()
        return
    target.write(chunk.decode("utf-8", errors="replace"))
    target.flush()


def _reader(
    stream: BinaryIO,
    target: TextIO,
    *,
    max_bytes: int,
    result: dict[str, StreamCapture],
    key: str,
) -> None:
    byte_count = 0
    newline_count = 0
    last_byte: bytes | None = None
    truncated = False

    while True:
        chunk = stream.read(8192)
        if not chunk:
            break
        _write_bytes(target, chunk)
        byte_count += len(chunk)
        newline_count += chunk.count(b"\n")
        last_byte = chunk[-1:]
        if byte_count > max_bytes:
            truncated = True

    line_count = newline_count + (1 if byte_count and last_byte != b"\n" else 0)
    result[key] = StreamCapture(
        text="",
        byte_count=byte_count,
        line_count=line_count,
        truncated=truncated,
    )


def _schema(required: list[str], properties: dict[str, dict[str, Any]]) -> dict[str, Any]:
    return {"type": "object", "required": required, "properties": properties}


def register_wrap_kinds(store: Store) -> dict[str, str]:
    """Register the adapter event schemas and return their hashes."""

    return {
        "adapter.wrap.start": store.register_kind(
            "adapter.wrap.start",
            _schema(
                [
                    "run_id",
                    "producer_id",
                    "idempotency_key",
                    "cwd",
                    "git_sha",
                    "argv_summary",
                    "started_at",
                ],
                {
                    "run_id": {"type": "string"},
                    "producer_id": {"type": "string"},
                    "idempotency_key": {"type": "string"},
                    "cwd": {"type": "string"},
                    "git_sha": {"type": ["string", "null"]},
                    "argv_summary": {"type": "array"},
                    "started_at": {"type": "string"},
                    "command_display": {"type": "string"},
                    "working_tree_dirty": {"type": ["boolean", "null"]},
                    "adapter_version": {"type": "string"},
                },
            ),
        ),
        "adapter.wrap.output_summary": store.register_kind(
            "adapter.wrap.output_summary",
            _schema(
                [
                    "run_id",
                    "producer_id",
                    "idempotency_key",
                    "stream",
                    "summary",
                    "truncated",
                    "redaction_applied",
                    "payload_hash",
                ],
                {
                    "run_id": {"type": "string"},
                    "producer_id": {"type": "string"},
                    "idempotency_key": {"type": "string"},
                    "stream": {"type": "string", "enum": ["stdout", "stderr"]},
                    "summary": {"type": "string"},
                    "truncated": {"type": "boolean"},
                    "redaction_applied": {"type": "boolean"},
                    "payload_hash": {"type": "string"},
                    "line_count": {"type": "integer"},
                    "byte_count": {"type": "integer"},
                    "redaction_reason_codes": {"type": "array"},
                    "content_omitted": {"type": "boolean"},
                    "output_capture_policy": {"type": "string"},
                },
            ),
        ),
        "adapter.wrap.end": store.register_kind(
            "adapter.wrap.end",
            _schema(
                [
                    "run_id",
                    "producer_id",
                    "idempotency_key",
                    "exit_code",
                    "outcome",
                    "duration_ms",
                    "ended_at",
                ],
                {
                    "run_id": {"type": "string"},
                    "producer_id": {"type": "string"},
                    "idempotency_key": {"type": "string"},
                    "exit_code": {"type": "integer"},
                    "outcome": {"type": "string", "enum": ["success", "failure", "aborted"]},
                    "duration_ms": {"type": "integer"},
                    "ended_at": {"type": "string"},
                    "timed_out": {"type": "boolean"},
                    "redaction_applied": {"type": "boolean"},
                    "redaction_reason_codes": {"type": "array"},
                },
            ),
        ),
    }


def _output_payload(
    *,
    run_id: str,
    producer_id: str,
    idempotency_key: str,
    stream: str,
    capture: StreamCapture,
) -> tuple[dict[str, Any], RedactedText]:
    redacted = redact_text(capture.text)
    summary = (
        f"{stream}: content omitted by motus wrap policy "
        f"({capture.byte_count} bytes, {capture.line_count} lines)"
    )
    payload = {
        "run_id": run_id,
        "producer_id": producer_id,
        "idempotency_key": idempotency_key,
        "stream": stream,
        "summary": summary,
        "truncated": capture.truncated,
        "redaction_applied": redacted.applied,
        "payload_hash": _sha256_text(summary),
        "line_count": capture.line_count,
        "byte_count": capture.byte_count,
        "redaction_reason_codes": list(redacted.reason_codes),
        "content_omitted": True,
        "output_capture_policy": "metadata_only",
    }
    return payload, redacted


def run_wrap(
    command: list[str],
    *,
    db_path: Path | None = None,
    intent: str | None = None,
    source: str = ADAPTER_NAME,
    producer_id: str | None = None,
    idempotency_key: str | None = None,
    max_output_bytes: int = DEFAULT_MAX_OUTPUT_BYTES,
    timeout_seconds: float | None = None,
    no_record: bool = False,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> WrapResult:
    """Run a command and optionally record a metadata-only Store timeline."""

    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    command = [part for part in command if part]
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        stderr.write("motus wrap requires a command after --\n")
        return WrapResult(2, None, None, None, False)
    if max_output_bytes <= 0:
        stderr.write("--max-output-bytes must be positive\n")
        return WrapResult(2, None, None, None, False)

    if no_record:
        return _run_child_only(command, timeout_seconds, stdout, stderr)

    store_path = (db_path or _default_store_path()).expanduser()
    store_path.parent.mkdir(parents=True, exist_ok=True)
    store = Store(store_path)
    schema_hashes = register_wrap_kinds(store)
    cwd = Path.cwd()
    producer_input = producer_id or os.environ.get("MOTUS_PRODUCER_ID")
    producer, producer_reasons = _safe_store_identifier(
        producer_input or f"motus-wrap:{os.getpid()}",
        prefix="producer",
        force_hash=producer_input is not None,
    )
    start_key, idempotency_reasons = (
        _safe_store_identifier(idempotency_key, prefix="idempotency", force_hash=True)
        if idempotency_key
        else (_new_idempotency_key("wrap-start"), ())
    )
    safe_source, source_reasons = _safe_store_identifier(source, prefix="source", force_hash=False)
    git_sha = _git_sha(cwd)
    argv_summary, argv_reasons = summarize_argv(command)
    command_display = _command_display(argv_summary)
    safe_intent, intent_reasons = _safe_intent(intent, command_display)
    run = store.start_run(
        source=safe_source,
        intent=safe_intent,
        cwd=str(cwd),
        git_sha=git_sha,
        idempotency_key=start_key,
        producer_id=producer,
    )
    if run.ended_at is not None:
        exit_code = _closed_run_exit_code(store, run.id)
        stderr.write(f"motus run: {run.id}\n")
        stderr.write(f"motus store: {store_path}\n")
        return WrapResult(exit_code, run.id, store_path, run.outcome, False)

    start_event_key = f"{start_key}:start"
    start_payload = {
        "run_id": run.id,
        "producer_id": producer,
        "idempotency_key": start_event_key,
        "cwd": str(cwd),
        "git_sha": git_sha,
        "argv_summary": argv_summary,
        "started_at": run.started_at,
        "command_display": command_display,
        "working_tree_dirty": _git_dirty(cwd),
        "adapter_version": ADAPTER_VERSION,
    }
    store.log_event(
        run_id=run.id,
        schema_kind="adapter.wrap.start",
        schema_hash=schema_hashes["adapter.wrap.start"],
        payload=start_payload,
        idempotency_key=start_event_key,
        producer_id=producer,
    )

    started = time.monotonic()
    child = _run_child(command, timeout_seconds, max_output_bytes, stdout, stderr)
    duration_ms = max(0, int((time.monotonic() - started) * 1000))

    output_redactions: list[str] = []
    for stream_name, capture in (("stdout", child["stdout"]), ("stderr", child["stderr"])):
        payload, redacted = _output_payload(
            run_id=run.id,
            producer_id=producer,
            idempotency_key=f"{start_key}:output:{stream_name}",
            stream=stream_name,
            capture=capture,
        )
        output_redactions.extend(redacted.reason_codes)
        store.log_event(
            run_id=run.id,
            schema_kind="adapter.wrap.output_summary",
            schema_hash=schema_hashes["adapter.wrap.output_summary"],
            payload=payload,
            idempotency_key=payload["idempotency_key"],
            producer_id=producer,
        )

    exit_code = int(child["exit_code"])
    timed_out = bool(child["timed_out"])
    outcome = "aborted" if timed_out else "success" if exit_code == 0 else "failure"
    reason_codes = tuple(
        dict.fromkeys(
            [
                *producer_reasons,
                *idempotency_reasons,
                *source_reasons,
                *intent_reasons,
                *argv_reasons,
                *output_redactions,
            ]
        )
    )
    end_event_key = f"{start_key}:end"
    end_payload = {
        "run_id": run.id,
        "producer_id": producer,
        "idempotency_key": end_event_key,
        "exit_code": exit_code,
        "outcome": outcome,
        "duration_ms": duration_ms,
        "ended_at": _utc_now(),
        "timed_out": timed_out,
        "redaction_applied": bool(reason_codes),
        "redaction_reason_codes": list(reason_codes),
    }
    store.log_event(
        run_id=run.id,
        schema_kind="adapter.wrap.end",
        schema_hash=schema_hashes["adapter.wrap.end"],
        payload=end_payload,
        idempotency_key=end_event_key,
        producer_id=producer,
    )
    store.end_run(
        run_id=run.id,
        outcome=outcome,
        outcome_note=f"motus wrap exited {exit_code}",
        idempotency_key=f"{start_key}:close",
        producer_id=producer,
    )
    stderr.write(f"motus run: {run.id}\n")
    stderr.write(f"motus store: {store_path}\n")
    return WrapResult(exit_code, run.id, store_path, outcome, timed_out)


def _closed_run_exit_code(store: Store, run_id: str) -> int:
    snapshot = store.snapshot(run_id)
    for event in reversed(snapshot["events"]):
        if event["schema_kind"] != "adapter.wrap.end":
            continue
        payload = event["payload"] if "payload" in event else None
        if payload is None:
            payload = json.loads(event["payload_json"])
        exit_code = payload.get("exit_code")
        if isinstance(exit_code, int):
            return exit_code
    outcome = snapshot["run"]["outcome"]
    return 0 if outcome == "success" else 1


def _run_child_only(
    command: list[str],
    timeout_seconds: float | None,
    stdout: TextIO,
    stderr: TextIO,
) -> WrapResult:
    result = _run_child(command, timeout_seconds, DEFAULT_MAX_OUTPUT_BYTES, stdout, stderr)
    return WrapResult(int(result["exit_code"]), None, None, None, bool(result["timed_out"]))


def _run_child(
    command: list[str],
    timeout_seconds: float | None,
    max_output_bytes: int,
    stdout: TextIO,
    stderr: TextIO,
) -> dict[str, Any]:
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
    except OSError as exc:
        message = f"motus wrap failed to start command: {exc}\n"
        stderr.write(message)
        return {
            "exit_code": 127,
            "timed_out": False,
            "stdout": StreamCapture("", 0, 0, False),
            "stderr": StreamCapture(message, len(message.encode("utf-8")), 1, False),
        }
    captures: dict[str, StreamCapture] = {}
    threads = [
        threading.Thread(
            target=_reader,
            args=(process.stdout, stdout),  # type: ignore[arg-type]
            kwargs={"max_bytes": max_output_bytes, "result": captures, "key": "stdout"},
            daemon=True,
        ),
        threading.Thread(
            target=_reader,
            args=(process.stderr, stderr),  # type: ignore[arg-type]
            kwargs={"max_bytes": max_output_bytes, "result": captures, "key": "stderr"},
            daemon=True,
        ),
    ]
    for thread in threads:
        thread.start()

    timed_out = False
    try:
        exit_code = process.wait(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        process.wait()
        exit_code = 124

    for thread in threads:
        thread.join(timeout=5)
    captures.setdefault("stdout", StreamCapture("", 0, 0, False))
    captures.setdefault("stderr", StreamCapture("", 0, 0, False))
    return {
        "exit_code": exit_code,
        "timed_out": timed_out,
        "stdout": captures["stdout"],
        "stderr": captures["stderr"],
    }


def wrap_command(args: Any) -> int:
    result = run_wrap(
        list(getattr(args, "wrapped_command", []) or []),
        db_path=Path(args.db).expanduser() if getattr(args, "db", None) else None,
        max_output_bytes=getattr(args, "max_output_bytes", DEFAULT_MAX_OUTPUT_BYTES),
        timeout_seconds=getattr(args, "timeout", None),
        no_record=getattr(args, "no_record", False),
    )
    return result.exit_code
