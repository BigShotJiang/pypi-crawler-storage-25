# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Work command handlers.

Implements CLI access to work transactions and supporting lease utilities.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Literal

from rich.console import Console

from ..api import WorkCompiler
from ..coordination.schemas import ClaimedResource as Resource
from ..core.database_connection import get_db_manager
from ..logging import get_logger

logger = get_logger(__name__)
console = Console()


def _get_agent_id() -> str:
    """Get agent ID from env or default."""
    return os.environ.get("MC_AGENT_ID", "default")


def _get_work_compiler() -> WorkCompiler:
    """Get singleton WorkCompiler instance."""
    return WorkCompiler()


def _kernel_snapshot(run_id: str) -> dict[str, Any] | None:
    store_path = os.environ.get("MOTUS_KERNEL_STORE_PATH", "").strip()
    if not store_path:
        return None
    if not Path(store_path).is_file():
        return None
    try:
        from motus.kernel import Store

        return Store(store_path, migrate=False, readonly=True).snapshot(run_id)
    except (KeyError, OSError, RuntimeError, ValueError):
        return None


def _kernel_work_packet(run_id: str) -> dict[str, Any] | None:
    snapshot = _kernel_snapshot(run_id)
    if snapshot is None:
        return None
    from motus.kernel import project_work_packet

    return project_work_packet(snapshot)


def _kernel_receipt(run_id: str) -> dict[str, Any] | None:
    snapshot = _kernel_snapshot(run_id)
    if snapshot is None:
        return None
    from motus.kernel import project_receipt

    return project_receipt(snapshot)


def _parse_resource(spec: str) -> Resource:
    """Parse TYPE:PATH resource spec into Resource."""
    if ":" not in spec:
        # Default to file type
        return Resource(type="file", path=spec)
    type_part, path_part = spec.split(":", 1)
    return Resource(type=type_part, path=path_part)


def cmd_work_claim(args: Any) -> int:
    """Handle: motus work claim <task_id>"""
    wc = _get_work_compiler()
    agent_id = getattr(args, "agent", None) or _get_agent_id()
    as_json = getattr(args, "json", False)

    # Parse resources
    resource_specs = getattr(args, "resources", None) or []
    resources = [_parse_resource(r) for r in resource_specs]

    # If no resources specified, use task_id as placeholder
    if not resources:
        resources = [Resource(type="task", path=args.task_id)]

    intent = getattr(args, "intent", None) or f"Work on {args.task_id}"
    ttl_s = getattr(args, "ttl", 3600)

    result = wc.claim_work(
        task_id=args.task_id,
        resources=resources,
        intent=intent,
        agent_id=agent_id,
        ttl_s=ttl_s,
    )

    if as_json:
        output = {
            "decision": result.decision.decision,
            "reason_code": result.decision.reason_code,
            "lease_id": result.lease.lease_id if result.lease else None,
            "message": result.decision.human_message,
        }
        console.print_json(json.dumps(output))
        return 0 if result.decision.decision == "GRANTED" else 1

    if result.decision.decision == "GRANTED":
        console.print(f"[green]Claimed: {args.task_id}[/green]")
        console.print(f"[cyan]Lease ID: {result.lease.lease_id}[/cyan]")
        console.print(f"[dim]Expires: {result.lease.expires_at.isoformat()}[/dim]")
        console.print(
            f"\n[dim]Next: motus work evidence {result.lease.lease_id} test_result --passed 1 --failed 0[/dim]"
        )
        console.print(f"[dim]Optional: motus work context {result.lease.lease_id}[/dim]")
    else:
        console.print(f"[red]{result.decision.human_message}[/red]")
        if result.decision.owner:
            console.print(f"[yellow]Held by: {result.decision.owner.agent_id}[/yellow]")

    return 0 if result.decision.decision == "GRANTED" else 1


def cmd_work_context(args: Any) -> int:
    """Handle: motus work context <lease_id>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)
    intent = getattr(args, "intent", None)

    result = wc.get_context(args.lease_id, intent=intent)

    if as_json:
        output = {
            "decision": result.decision.decision,
            "reason_code": result.decision.reason_code,
            "lens": result.lens,
            "lease_status": result.lease.status if result.lease else None,
        }
        console.print_json(json.dumps(output, default=str))
        return 0 if result.decision.decision == "GRANTED" else 1

    if result.decision.decision == "GRANTED":
        console.print("[green]Context assembled[/green]")
        console.print(f"[dim]Lens version: {result.lens.get('lens_version', 'unknown')}[/dim]")
        console.print(f"[dim]Policy version: {result.lens.get('policy_version', 'unknown')}[/dim]")

        # Show resource specs count
        resource_specs = result.lens.get("resource_specs", [])
        policy_snippets = result.lens.get("policy_snippets", [])
        console.print(f"\nResources: {len(resource_specs)}")
        console.print(f"Policy snippets: {len(policy_snippets)}")

        # Show warnings if any
        warnings = result.lens.get("warnings", [])
        if warnings:
            console.print("\n[yellow]Warnings:[/yellow]")
            for w in warnings:
                console.print(f"  - {w.get('message', str(w))}")
    else:
        console.print(f"[red]{result.decision.human_message}[/red]")

    return 0 if result.decision.decision == "GRANTED" else 1


def cmd_work_outcome(args: Any) -> int:
    """Handle: motus work outcome <lease_id> <type>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    result = wc.put_outcome(
        args.lease_id,
        args.outcome_type,
        path=getattr(args, "path", None),
        description=getattr(args, "description", None),
    )

    if as_json:
        output = {
            "accepted": result.accepted,
            "outcome_id": result.outcome_id,
            "message": result.message,
        }
        console.print_json(json.dumps(output))
        return 0 if result.accepted else 1

    if result.accepted:
        console.print(f"[green]Outcome registered: {result.outcome_id}[/green]")
        console.print(f"[dim]Type: {args.outcome_type}[/dim]")
    else:
        console.print(f"[red]{result.message}[/red]")

    return 0 if result.accepted else 1


def cmd_work_evidence(args: Any) -> int:
    """Handle: motus work evidence <lease_id> <type>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    # Build test results if provided
    test_results = None
    if any([getattr(args, "passed", None), getattr(args, "failed", None), getattr(args, "skipped", None)]):
        test_results = {
            "passed": getattr(args, "passed", 0) or 0,
            "failed": getattr(args, "failed", 0) or 0,
            "skipped": getattr(args, "skipped", 0) or 0,
        }

    result = wc.record_evidence(
        args.lease_id,
        args.evidence_type,
        test_results=test_results,
        diff_summary=getattr(args, "diff", None),
        log_excerpt=getattr(args, "log", None),
    )

    if as_json:
        output = {
            "accepted": result.accepted,
            "evidence_id": result.evidence_id,
            "message": result.message,
        }
        console.print_json(json.dumps(output))
        return 0 if result.accepted else 1

    if result.accepted:
        console.print(f"[green]Evidence recorded: {result.evidence_id}[/green]")
        console.print(f"[dim]Type: {args.evidence_type}[/dim]")
    else:
        console.print(f"[red]{result.message}[/red]")

    return 0 if result.accepted else 1


def cmd_work_decision(args: Any) -> int:
    """Handle: motus work decision <lease_id> <text>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    result = wc.record_decision(
        args.lease_id,
        args.decision_text,
        rationale=getattr(args, "rationale", None),
        alternatives_considered=getattr(args, "alternatives", None),
    )

    if as_json:
        output = {
            "accepted": result.accepted,
            "decision_id": result.decision_id,
            "message": result.message,
        }
        console.print_json(json.dumps(output))
        return 0 if result.accepted else 1

    if result.accepted:
        console.print(f"[green]Decision logged: {result.decision_id}[/green]")
    else:
        console.print(f"[red]{result.message}[/red]")

    return 0 if result.accepted else 1


def cmd_work_release(args: Any) -> int:
    """Handle: motus work release <lease_id> <outcome>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)
    rollback: Literal["auto", "skip"] = "skip" if getattr(args, "no_rollback", False) else "auto"

    result = wc.release_work(
        args.lease_id,
        args.outcome,
        rollback=rollback,
    )
    receipt = wc.get_receipt(args.lease_id)

    if as_json:
        output = {
            "decision": result.decision.decision,
            "reason_code": result.decision.reason_code,
            "message": result.decision.human_message,
            "lease_status": result.lease.status if result.lease else None,
            "receipt_id": receipt.receipt_id if receipt else None,
            "next_action": receipt.next_action if receipt else None,
        }
        console.print_json(json.dumps(output, default=str))
        return 0 if result.decision.decision == "GRANTED" else 1

    if result.decision.decision == "GRANTED":
        console.print(f"[green]Released: {result.decision.reason_code}[/green]")
        if result.lease:
            console.print(f"[dim]Final status: {result.lease.status}[/dim]")
        if receipt:
            console.print(f"[cyan]Receipt ID: {receipt.receipt_id}[/cyan]")
            console.print(f"[dim]Inspect: motus work receipt {args.lease_id}[/dim]")
    else:
        console.print(f"[red]{result.decision.human_message}[/red]")

    return 0 if result.decision.decision == "GRANTED" else 1


def cmd_work_status(args: Any) -> int:
    """Handle: motus work status <lease_id>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    # Keep status truthful if the lease expired between CLI invocations.
    wc.cleanup_leases()
    lease = wc.get_lease(args.lease_id)
    outcomes = wc.get_outcomes(args.lease_id)
    evidence = wc.get_evidence(args.lease_id)
    decisions = wc.get_decisions(args.lease_id)

    if as_json:
        kernel_packet = _kernel_work_packet(args.lease_id) if lease is None else None
        if kernel_packet is not None:
            output = {
                "lease_id": args.lease_id,
                "status": kernel_packet["status"],
                "lease_status": kernel_packet["status"],
                "kernel_run": True,
                "work_packet": kernel_packet,
                "packet": kernel_packet,
            }
            console.print_json(json.dumps(output, default=str))
            return 0
        output = {
            "lease_id": args.lease_id,
            "lease_status": lease.status if lease else "not_found",
            "outcomes": outcomes,
            "evidence": evidence,
            "decisions": decisions,
        }
        console.print_json(json.dumps(output, default=str))
        return 0

    if lease is None:
        kernel_packet = _kernel_work_packet(args.lease_id)
        if kernel_packet is not None:
            console.print(f"[bold]Run: {args.lease_id}[/bold]")
            console.print(f"Status: {kernel_packet['status']}")
            console.print(f"Intent: {kernel_packet['intent']}")
            console.print(f"Events: {len(kernel_packet['events'])}")
            if kernel_packet["receipt_id"]:
                console.print(f"Receipt: {kernel_packet['receipt_id']}")
            return 0
        console.print(f"[red]Lease not found: {args.lease_id}[/red]")
        return 1

    console.print(f"[bold]Lease: {args.lease_id}[/bold]")
    console.print(f"Status: {lease.status}")
    console.print(f"Agent: {lease.owner_agent_id}")
    console.print(f"Expires: {lease.expires_at.isoformat()}")

    if outcomes:
        console.print(f"\n[cyan]Outcomes ({len(outcomes)}):[/cyan]")
        for o in outcomes:
            console.print(f"  - {o['outcome_type']}: {o.get('path', o.get('description', 'N/A'))}")

    if evidence:
        console.print(f"\n[cyan]Evidence ({len(evidence)}):[/cyan]")
        for e in evidence:
            console.print(f"  - {e['evidence_type']}: {e['evidence_id']}")

    if decisions:
        console.print(f"\n[cyan]Decisions ({len(decisions)}):[/cyan]")
        for d in decisions:
            console.print(f"  - {d['decision']}")

    return 0


def cmd_work_receipt(args: Any) -> int:
    """Handle: motus work receipt <lease_id>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    wc.cleanup_leases()
    receipt = wc.get_receipt(args.lease_id)

    if receipt is None:
        kernel_receipt = _kernel_receipt(args.lease_id)
        if kernel_receipt is not None:
            if as_json:
                output = {
                    "lease_id": args.lease_id,
                    "kernel_run": True,
                    "receipt": kernel_receipt,
                }
                console.print_json(json.dumps(output, default=str))
                return 0
            console.print(f"[bold]Receipt: {kernel_receipt['receipt_id']}[/bold]")
            console.print(f"Run: {kernel_receipt['run_id']}")
            console.print(f"Status: {kernel_receipt['status']}")
            console.print(f"Outcome: {kernel_receipt['outcome']}")
            console.print(f"Recorded: {kernel_receipt['recorded_at']}")
            console.print(f"Accepted close: {'yes' if kernel_receipt['accepted_close'] else 'no'}")
            console.print(f"\nSummary: {kernel_receipt['summary']}")
            console.print(f"\nNext: {kernel_receipt['next_action']}")
            return 0
        kernel_packet = _kernel_work_packet(args.lease_id)
        lease = wc.get_lease(args.lease_id)
        if as_json:
            output = {
                "lease_id": args.lease_id,
                "found": False,
                "kernel_run": kernel_packet is not None,
                "message": (
                    "Receipt is not available until the work reaches a terminal state."
                    if lease is not None or kernel_packet is not None
                    else "Lease not found."
                ),
            }
            console.print_json(json.dumps(output))
        else:
            if lease is None and kernel_packet is None:
                console.print(f"[red]Lease not found: {args.lease_id}[/red]")
            else:
                console.print(
                    "[yellow]Receipt is not available until the work reaches a terminal state.[/yellow]"
                )
        return 1

    if as_json:
        console.print_json(json.dumps(receipt.__dict__, default=str))
        return 0

    console.print(f"[bold]Receipt: {receipt.receipt_id}[/bold]")
    console.print(f"Lease: {receipt.lease_id}")
    if receipt.work_id:
        console.print(f"Work: {receipt.work_id}")
    console.print(f"Status: {receipt.status}")
    if receipt.outcome:
        console.print(f"Outcome: {receipt.outcome}")
    if receipt.recorded_at:
        console.print(f"Recorded: {receipt.recorded_at}")
    console.print(f"Accepted close: {'yes' if receipt.accepted_close else 'no'}")
    console.print(f"\nSummary: {receipt.summary}")

    if receipt.outcomes:
        console.print(f"\n[cyan]Outcomes ({len(receipt.outcomes)}):[/cyan]")
        for item in receipt.outcomes:
            target = item.get("path") or item.get("description") or "N/A"
            console.print(f"  - {item['outcome_type']}: {target}")

    if receipt.evidence_ids:
        console.print(f"\n[cyan]Evidence ({len(receipt.evidence_ids)}):[/cyan]")
        for evidence_id in receipt.evidence_ids:
            console.print(f"  - {evidence_id}")

    if receipt.decision_summaries:
        console.print(f"\n[cyan]Decisions ({len(receipt.decision_summaries)}):[/cyan]")
        for summary in receipt.decision_summaries:
            console.print(f"  - {summary}")

    console.print(f"\nNext: {receipt.next_action}")
    return 0


def cmd_work_cleanup(args: Any) -> int:
    """Handle: motus work cleanup"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    expired_count = wc.cleanup_leases()

    if as_json:
        output = {
            "expired_count": expired_count,
        }
        console.print_json(json.dumps(output))
        return 0

    console.print(f"[green]Expired leases: {expired_count}[/green]")
    return 0


def cmd_work_list(args: Any) -> int:
    """Handle: motus work list"""
    db = get_db_manager()
    as_json = getattr(args, "json", False)
    include_all = getattr(args, "all", False)

    with db.readonly_connection() as conn:
        table = conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'coordination_leases'"
        ).fetchone()
        if table is None:
            if as_json:
                console.print_json(json.dumps({"items": [], "count": 0}))
            else:
                console.print("[yellow]No leases found.[/yellow]")
            return 0

        if include_all:
            query = """
                SELECT lease_id, owner_agent_id, work_id, issued_at, expires_at, status
                FROM coordination_leases
                ORDER BY issued_at DESC
            """
            params: tuple[Any, ...] = ()
        else:
            query = """
                SELECT lease_id, owner_agent_id, work_id, issued_at, expires_at, status
                FROM coordination_leases
                WHERE status = 'active'
                AND expires_at > mc_now_iso()
                AND heartbeat_deadline > mc_now_iso()
                ORDER BY issued_at DESC
            """
            params = ()

        rows = conn.execute(query, params).fetchall()

    items = [
        {
            "lease_id": r["lease_id"],
            "task_id": r["work_id"],
            "agent_id": r["owner_agent_id"],
            "claimed_at": r["issued_at"],
            "expires_at": r["expires_at"],
            "status": r["status"],
        }
        for r in rows
    ]

    if as_json:
        console.print_json(json.dumps({"items": items, "count": len(items)}))
        return 0

    if not items:
        console.print("[yellow]No leases found.[/yellow]")
        return 0

    from rich.table import Table

    table = Table(title="Active Leases" if not include_all else "Leases")
    table.add_column("Lease ID", style="dim")
    table.add_column("Task ID")
    table.add_column("Agent")
    table.add_column("Claimed")
    table.add_column("Expires")
    table.add_column("Status", style="dim")

    for item in items:
        table.add_row(
            item["lease_id"],
            item["task_id"] or "-",
            item["agent_id"],
            item["claimed_at"],
            item["expires_at"],
            item["status"],
        )

    console.print(table)
    return 0


def handle_work_command(args: Any) -> int:
    """Dispatch work subcommand."""
    subcommand = getattr(args, "work_command", None)

    if subcommand == "claim":
        return cmd_work_claim(args)
    elif subcommand == "context":
        return cmd_work_context(args)
    elif subcommand == "outcome":
        return cmd_work_outcome(args)
    elif subcommand == "evidence":
        return cmd_work_evidence(args)
    elif subcommand == "decision":
        return cmd_work_decision(args)
    elif subcommand == "release":
        return cmd_work_release(args)
    elif subcommand == "status":
        return cmd_work_status(args)
    elif subcommand == "receipt":
        return cmd_work_receipt(args)
    elif subcommand == "cleanup":
        return cmd_work_cleanup(args)
    elif subcommand == "list":
        return cmd_work_list(args)
    else:
        console.print(
            "[yellow]Usage: motus work <claim|context|outcome|evidence|decision|release|status|receipt|cleanup|list>[/yellow]"
        )
        console.print("\nQuickstart loop:")
        console.print("  1. motus work claim <task_id>     - Claim work and get a lease")
        console.print("  2. motus work evidence <lease_id> - Attach proof while work happens")
        console.print("  3. motus work release <lease_id>  - Close with a terminal outcome")
        console.print("  4. motus work receipt <lease_id>  - Inspect the durable close record")
        console.print("\nOptional supporting commands:")
        console.print("  - motus work context <lease_id>   - Refresh bounded context")
        console.print("  - motus work outcome <lease_id>   - Register primary deliverable")
        console.print("  - motus work decision <lease_id>  - Log a decision rationale")
        return 0
