# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Motus API module.

This module provides:
1. The 6-Call Work Compiler API (facade.py)
2. Reference/shadow contract types used by the local MotusSupra adapter
3. External API resilience helpers (resilience.py)

The installed `motus.api` surface keeps compatibility exports for historical
callers. The normative task-execution surface remains `WorkCompiler`; the
MotusSupra-derived types are reference/shadow contracts rather than the public
Store kernel or a hosted control-plane API.

The Work Compiler is the primary interface for task execution:

    from motus.api import WorkCompiler

    wc = WorkCompiler()
    result = wc.claim_work(task_id="PA-047", ...)
    if result.decision.decision == "GRANTED":
        wc.get_context(result.lease.lease_id)
        wc.put_outcome(...)
        wc.record_evidence(...)
        wc.record_decision(...)
        wc.release_work(result.lease.lease_id, outcome="success")
"""

from __future__ import annotations

from motus.api.facade import (
    DecisionResponse,
    DraftDecisionResponse,
    EvidenceResponse,
    OutcomeResponse,
    WorkCompiler,
)
from motus.api.motussupra import (
    DecisionRecord,
    DecisionProjection,
    Evidence,
    ExecutionProjection,
    Lease,
    OperatorProjection,
    Receipt,
    ResourceRef,
    RouteNode,
    SuccessorSpec,
    WorkContract,
    WorkItem,
    Workflow,
)
from motus.api.resilience import (
    RateLimitState,
    call_with_backoff,
    handle_rate_limit_headers,
    should_preemptive_throttle,
)

__all__ = [
    # 6-Call Work Compiler API
    "WorkCompiler",
    "OutcomeResponse",
    "EvidenceResponse",
    "DecisionResponse",
    "DraftDecisionResponse",
    # Reference/shadow contract types retained for compatibility
    "ResourceRef",
    "RouteNode",
    "Workflow",
    "WorkContract",
    "WorkItem",
    "Lease",
    "DecisionRecord",
    "Evidence",
    "Receipt",
    "ExecutionProjection",
    "OperatorProjection",
    "DecisionProjection",
    "SuccessorSpec",
    # Resilience helpers
    "RateLimitState",
    "call_with_backoff",
    "handle_rate_limit_headers",
    "should_preemptive_throttle",
]
