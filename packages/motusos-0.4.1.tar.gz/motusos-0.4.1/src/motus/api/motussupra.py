# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Local MotusSupra reference adapter.

This module provides a narrow adapter over the existing local WorkCompiler so
the MotusSupra contract types can be exercised without a server cutover. The
slice is intentionally local-first: it models reference contract surfaces,
drives bounded terminal flows, and renders execution/operator/decision
projections from the same state. It is not the public Store kernel.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4

from motus.api.facade import WorkCompiler
from motus.coordination.api.types import Lease as CoordinationLease
from motus.coordination.schemas import ClaimedResource as Resource

WorkItemStatus = Literal["draft", "bound", "in_progress", "completed", "failed", "cancelled"]
ConfidencePosture = Literal["explore", "balanced", "conservative"]
DecisionBoundary = Literal["execute", "review", "terminal"]
SuccessorCardinality = Literal["none", "single", "set"]
RouteOutcome = Literal["terminal", "successor_single", "successor_set"]
CompletionOutcome = Literal["success", "failure", "partial", "aborted"]
DecisionKind = Literal["note", "approval", "cancellation"]


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _mint_id(prefix: str) -> str:
    return f"{prefix}-{uuid4().hex[:12]}"


class MotusSupraError(RuntimeError):
    """Base error for the local MotusSupra adapter."""


class MotusSupraValidationError(MotusSupraError):
    """Raised when kernel validation fails before a mutation may proceed."""


class MotusSupraStateError(MotusSupraError):
    """Raised when the current work state does not allow the requested action."""


@dataclass(frozen=True)
class ResourceRef:
    type: str
    path: str

    def to_claimed_resource(self) -> Resource:
        return Resource(type=self.type, path=self.path)


@dataclass(frozen=True)
class RouteNode:
    node_id: str
    allowed_successor_ids: tuple[str, ...] = ()
    decision_boundary: DecisionBoundary = "terminal"
    successor_cardinality: SuccessorCardinality = "none"


@dataclass(frozen=True)
class Workflow:
    workflow_id: str
    start_node_id: str
    route_graph: dict[str, RouteNode]


@dataclass(frozen=True)
class WorkContract:
    work_contract_id: str
    objective: str
    required_evidence_kinds: tuple[str, ...] = ()
    success_criteria: tuple[str, ...] = ()
    approval_required: bool = False
    confidence_posture: ConfidencePosture = "balanced"
    allow_runtime_downgrade_when_confident: bool = False
    allow_successor_autobind_when_confident: bool = False


@dataclass(frozen=True)
class WorkItem:
    work_item_id: str
    title: str
    intent: str
    resources: tuple[ResourceRef, ...]
    status: WorkItemStatus = "draft"
    workflow_id: str | None = None
    work_contract_id: str | None = None
    current_node_id: str | None = None
    active_lease_id: str | None = None
    created_at: datetime = field(default_factory=_utcnow)
    updated_at: datetime = field(default_factory=_utcnow)


@dataclass(frozen=True)
class Lease:
    lease_id: str
    owner_agent_id: str
    mode: str
    resources: tuple[ResourceRef, ...]
    issued_at: datetime
    expires_at: datetime
    heartbeat_deadline: datetime
    snapshot_id: str
    policy_version: str
    lens_digest: str
    work_id: str | None = None
    attempt_id: str | None = None
    status: str = "active"
    outcome: str | None = None

    @classmethod
    def from_coordination_lease(
        cls,
        lease: CoordinationLease,
        *,
        resources: tuple[ResourceRef, ...],
    ) -> "Lease":
        return cls(
            lease_id=lease.lease_id,
            owner_agent_id=lease.owner_agent_id,
            mode=lease.mode,
            resources=resources,
            issued_at=lease.issued_at,
            expires_at=lease.expires_at,
            heartbeat_deadline=lease.heartbeat_deadline,
            snapshot_id=lease.snapshot_id,
            policy_version=lease.policy_version,
            lens_digest=lease.lens_digest,
            work_id=lease.work_id,
            attempt_id=lease.attempt_id,
            status=lease.status,
            outcome=lease.outcome,
        )


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    work_item_id: str
    lease_id: str
    kind: str
    artifacts: dict[str, Any] = field(default_factory=dict)
    test_results: dict[str, Any] | None = None
    diff_summary: str | None = None
    log_excerpt: str | None = None
    created_at: datetime = field(default_factory=_utcnow)


@dataclass(frozen=True)
class DecisionRecord:
    decision_id: str
    work_item_id: str
    lease_id: str
    kind: DecisionKind
    summary: str
    rationale: str | None = None
    alternatives_considered: tuple[str, ...] = ()
    constraints: tuple[str, ...] = ()
    recorded_at: datetime = field(default_factory=_utcnow)


@dataclass(frozen=True)
class SuccessorSpec:
    work_item_id: str
    title: str
    intent: str
    resources: tuple[ResourceRef, ...]
    workflow_id: str | None = None
    work_contract_id: str | None = None
    next_node_id: str | None = None


@dataclass(frozen=True)
class Receipt:
    receipt_id: str
    work_item_id: str
    lease_id: str
    status: WorkItemStatus
    outcome: CompletionOutcome
    route_outcome: RouteOutcome
    evidence_ids: tuple[str, ...]
    decision_summaries: tuple[str, ...]
    summary: str
    successor_work_item_ids: tuple[str, ...] = ()
    completed_at: datetime = field(default_factory=_utcnow)


@dataclass(frozen=True)
class ExecutionProjection:
    work_item_id: str
    status: WorkItemStatus
    active_lease_id: str | None
    resources: tuple[ResourceRef, ...]
    required_evidence_kinds: tuple[str, ...]
    recorded_evidence_kinds: tuple[str, ...]


@dataclass(frozen=True)
class OperatorProjection:
    work_item_id: str
    title: str
    status: WorkItemStatus
    approval_required: bool
    active_lease_id: str | None
    receipt_id: str | None
    next_action: str


@dataclass(frozen=True)
class DecisionProjection:
    work_item_id: str
    confidence_posture: ConfidencePosture
    approval_required: bool
    approval_recorded: bool
    allow_runtime_downgrade_when_confident: bool
    allow_successor_autobind_when_confident: bool
    decision_summaries: tuple[str, ...]


@dataclass(frozen=True)
class _PreparedSuccessor:
    work_item: WorkItem


class LocalMotusSupra:
    """Local reference adapter for MotusSupra contract experiments."""

    def __init__(self, compiler: WorkCompiler | None = None) -> None:
        self._compiler = compiler or WorkCompiler()
        self._work_items: dict[str, WorkItem] = {}
        self._workflows: dict[str, Workflow] = {}
        self._work_contracts: dict[str, WorkContract] = {}
        self._evidence_by_lease: dict[str, list[Evidence]] = {}
        self._decisions_by_lease: dict[str, list[DecisionRecord]] = {}
        self._receipts_by_work_item: dict[str, Receipt] = {}
        self._lease_to_work_item: dict[str, str] = {}

    def create_or_update_work_item(self, work_item: WorkItem) -> WorkItem:
        existing = self._work_items.get(work_item.work_item_id)
        now = _utcnow()
        normalized = replace(
            work_item,
            created_at=existing.created_at if existing else work_item.created_at,
            updated_at=now,
        )
        self._work_items[normalized.work_item_id] = normalized
        return normalized

    def bind_work(
        self,
        work_item_id: str,
        workflow: Workflow,
        work_contract: WorkContract,
    ) -> WorkItem:
        work_item = self._require_work_item(work_item_id)
        self._validate_workflow(workflow)
        self._workflows[workflow.workflow_id] = workflow
        self._work_contracts[work_contract.work_contract_id] = work_contract
        bound = replace(
            work_item,
            status="bound",
            workflow_id=workflow.workflow_id,
            work_contract_id=work_contract.work_contract_id,
            current_node_id=workflow.start_node_id,
            updated_at=_utcnow(),
        )
        self._work_items[work_item_id] = bound
        return bound

    def claim_lease(
        self,
        work_item_id: str,
        *,
        agent_id: str,
        ttl_s: int = 3600,
    ) -> Lease:
        work_item = self._require_work_item(work_item_id)
        if work_item.workflow_id is None or work_item.work_contract_id is None:
            raise MotusSupraStateError("work item must be bound before claiming a lease")
        claim = self._compiler.claim_work(
            task_id=work_item.work_item_id,
            resources=[resource.to_claimed_resource() for resource in work_item.resources],
            intent=work_item.intent,
            agent_id=agent_id,
            ttl_s=ttl_s,
        )
        if claim.decision.decision != "GRANTED" or claim.lease is None:
            raise MotusSupraStateError(
                f"lease claim failed: {claim.decision.reason_code}"
            )
        self._lease_to_work_item[claim.lease.lease_id] = work_item_id
        self._work_items[work_item_id] = replace(
            work_item,
            status="in_progress",
            active_lease_id=claim.lease.lease_id,
            updated_at=_utcnow(),
        )
        return Lease.from_coordination_lease(
            claim.lease,
            resources=work_item.resources,
        )

    def recover_lease(
        self,
        work_item_id: str,
        *,
        agent_id: str,
        ttl_s: int = 3600,
    ) -> Lease:
        work_item = self._require_work_item(work_item_id)
        if work_item.workflow_id is None or work_item.work_contract_id is None:
            raise MotusSupraStateError("work item must be bound before recovering a lease")

        active_lease_id = work_item.active_lease_id
        if active_lease_id is not None:
            lease = self._compiler.get_lease(active_lease_id)
            if lease is not None and lease.status == "active":
                raise MotusSupraStateError(
                    "cannot recover a lease that is still active; recover is only for stale work"
                )

        return self.claim_lease(work_item_id, agent_id=agent_id, ttl_s=ttl_s)

    def append_evidence(
        self,
        lease_id: str,
        kind: str,
        *,
        artifacts: dict[str, Any] | None = None,
        test_results: dict[str, Any] | None = None,
        diff_summary: str | None = None,
        log_excerpt: str | None = None,
    ) -> Evidence:
        work_item_id = self._require_work_item_id_for_lease(lease_id)
        response = self._compiler.record_evidence(
            lease_id,
            evidence_type=kind,
            artifacts=artifacts,
            test_results=test_results,
            diff_summary=diff_summary,
            log_excerpt=log_excerpt,
        )
        if not response.accepted or response.evidence_id is None:
            raise MotusSupraStateError(response.message or "evidence append failed")
        evidence = Evidence(
            evidence_id=response.evidence_id,
            work_item_id=work_item_id,
            lease_id=lease_id,
            kind=kind,
            artifacts=artifacts or {},
            test_results=test_results,
            diff_summary=diff_summary,
            log_excerpt=log_excerpt,
        )
        self._evidence_by_lease.setdefault(lease_id, []).append(evidence)
        return evidence

    def record_decision(
        self,
        lease_id: str,
        decision: str,
        *,
        rationale: str | None = None,
        alternatives_considered: tuple[str, ...] = (),
        constraints: tuple[str, ...] = (),
        kind: DecisionKind = "note",
    ) -> DecisionRecord:
        work_item_id = self._require_work_item_id_for_lease(lease_id)
        response = self._compiler.record_decision(
            lease_id,
            decision,
            rationale=rationale,
            alternatives_considered=list(alternatives_considered),
            constraints=list(constraints),
        )
        if not response.accepted or response.decision_id is None:
            raise MotusSupraStateError(response.message or "decision record failed")
        record = DecisionRecord(
            decision_id=response.decision_id,
            work_item_id=work_item_id,
            lease_id=lease_id,
            kind=kind,
            summary=decision,
            rationale=rationale,
            alternatives_considered=alternatives_considered,
            constraints=constraints,
        )
        self._decisions_by_lease.setdefault(lease_id, []).append(record)
        return record

    def complete_work(
        self,
        lease_id: str,
        *,
        outcome: CompletionOutcome = "success",
        summary: str = "",
        successors: tuple[SuccessorSpec, ...] = (),
    ) -> Receipt:
        return self._finalize_work(
            lease_id,
            outcome=outcome,
            summary=summary,
            require_required_evidence=True,
            require_approval_for_success=True,
            successors=successors,
        )

    def cancel_work(
        self,
        lease_id: str,
        *,
        summary: str = "",
        rationale: str | None = None,
    ) -> Receipt:
        cancellation_summary = summary or "work cancelled by operator"
        self.record_decision(
            lease_id,
            "Cancelled work",
            rationale=rationale or cancellation_summary,
            kind="cancellation",
        )
        return self._finalize_work(
            lease_id,
            outcome="aborted",
            summary=cancellation_summary,
            require_required_evidence=False,
            require_approval_for_success=False,
        )

    def execution_projection(self, work_item_id: str) -> ExecutionProjection:
        work_item = self._require_work_item(work_item_id)
        work_contract = self._require_work_contract_for_work_item(work_item)
        receipt = self._receipts_by_work_item.get(work_item_id)
        projection_lease_id = work_item.active_lease_id or (receipt.lease_id if receipt else None)
        recorded_kinds = tuple(
            evidence.kind
            for evidence in self._evidence_records_for_lease(projection_lease_id)
        )
        return ExecutionProjection(
            work_item_id=work_item_id,
            status=work_item.status,
            active_lease_id=work_item.active_lease_id,
            resources=work_item.resources,
            required_evidence_kinds=work_contract.required_evidence_kinds,
            recorded_evidence_kinds=recorded_kinds,
        )

    def operator_projection(self, work_item_id: str) -> OperatorProjection:
        work_item = self._require_work_item(work_item_id)
        work_contract = self._require_work_contract_for_work_item(work_item)
        receipt = self._receipts_by_work_item.get(work_item_id)
        next_action = "inspect receipt" if receipt else "complete local terminal flow"
        if work_item.status == "bound":
            next_action = "claim lease"
        elif work_item.status == "in_progress":
            missing_required_evidence = self._missing_required_evidence_kinds(
                work_item.active_lease_id or "",
                work_contract,
            )
            if missing_required_evidence:
                next_action = "attach required evidence"
            elif work_contract.approval_required and not self._approval_recorded(
                work_item.active_lease_id or ""
            ):
                next_action = "record approval decision"
            else:
                next_action = "complete work"
        return OperatorProjection(
            work_item_id=work_item_id,
            title=work_item.title,
            status=work_item.status,
            approval_required=work_contract.approval_required,
            active_lease_id=work_item.active_lease_id,
            receipt_id=receipt.receipt_id if receipt else None,
            next_action=next_action,
        )

    def decision_projection(self, work_item_id: str) -> DecisionProjection:
        work_item = self._require_work_item(work_item_id)
        work_contract = self._require_work_contract_for_work_item(work_item)
        projection_lease_id = work_item.active_lease_id
        if projection_lease_id is None and (receipt := self._receipts_by_work_item.get(work_item_id)):
            projection_lease_id = receipt.lease_id
        decision_records = self._decision_records_for_lease(projection_lease_id)
        decision_summaries = tuple(record.summary for record in decision_records)
        return DecisionProjection(
            work_item_id=work_item_id,
            confidence_posture=work_contract.confidence_posture,
            approval_required=work_contract.approval_required,
            approval_recorded=self._approval_recorded(projection_lease_id),
            allow_runtime_downgrade_when_confident=work_contract.allow_runtime_downgrade_when_confident,
            allow_successor_autobind_when_confident=work_contract.allow_successor_autobind_when_confident,
            decision_summaries=decision_summaries,
        )

    def _require_work_item(self, work_item_id: str) -> WorkItem:
        work_item = self._work_items.get(work_item_id)
        if work_item is None:
            raise MotusSupraStateError(f"unknown work item: {work_item_id}")
        return work_item

    def _require_work_item_id_for_lease(self, lease_id: str) -> str:
        work_item_id = self._lease_to_work_item.get(lease_id)
        if work_item_id is None:
            raise MotusSupraStateError(f"unknown lease: {lease_id}")
        return work_item_id

    def _require_work_contract_for_work_item(self, work_item: WorkItem) -> WorkContract:
        if work_item.work_contract_id is None:
            raise MotusSupraStateError(
                f"work item {work_item.work_item_id} is not bound to a work contract"
            )
        work_contract = self._work_contracts.get(work_item.work_contract_id)
        if work_contract is None:
            raise MotusSupraStateError(
                f"unknown work contract: {work_item.work_contract_id}"
            )
        return work_contract

    def _require_workflow_for_work_item(self, work_item: WorkItem) -> Workflow:
        if work_item.workflow_id is None:
            raise MotusSupraStateError(
                f"work item {work_item.work_item_id} is not bound to a workflow"
            )
        workflow = self._workflows.get(work_item.workflow_id)
        if workflow is None:
            raise MotusSupraStateError(f"unknown workflow: {work_item.workflow_id}")
        return workflow

    def _validate_workflow(self, workflow: Workflow) -> None:
        if workflow.start_node_id not in workflow.route_graph:
            raise MotusSupraValidationError(
                f"workflow start node missing from route graph: {workflow.start_node_id}"
            )
        node_ids = set(workflow.route_graph)
        for node in workflow.route_graph.values():
            missing = set(node.allowed_successor_ids) - node_ids
            if missing:
                raise MotusSupraValidationError(
                    f"workflow node {node.node_id} references missing successors: {sorted(missing)}"
                )

    def _validate_required_evidence(
        self,
        lease_id: str,
        work_contract: WorkContract,
    ) -> None:
        missing = self._missing_required_evidence_kinds(lease_id, work_contract)
        if missing:
            raise MotusSupraValidationError(
                f"missing required evidence kinds: {', '.join(missing)}"
            )

    def _missing_required_evidence_kinds(
        self,
        lease_id: str,
        work_contract: WorkContract,
    ) -> tuple[str, ...]:
        recorded_kinds = {
            evidence.kind for evidence in self._evidence_records_for_lease(lease_id)
        }
        return tuple(sorted(set(work_contract.required_evidence_kinds) - recorded_kinds))

    def _approval_recorded(self, lease_id: str | None) -> bool:
        if lease_id is None:
            return False
        return any(
            record.kind == "approval"
            for record in self._decision_records_for_lease(lease_id)
        )

    def _decision_records_for_lease(self, lease_id: str | None) -> tuple[DecisionRecord, ...]:
        if lease_id is None:
            return ()
        local_records = self._decisions_by_lease.get(lease_id)
        if local_records:
            return tuple(local_records)
        return tuple(
            DecisionRecord(
                decision_id=str(decision.get("decision_id", _mint_id("decision"))),
                work_item_id=self._require_work_item_id_for_lease(lease_id),
                lease_id=lease_id,
                kind="note",
                summary=str(decision.get("decision", "")),
                rationale=decision.get("rationale"),
                alternatives_considered=tuple(decision.get("alternatives_considered", [])),
                constraints=tuple(decision.get("constraints", [])),
                recorded_at=_parse_recorded_at(decision.get("recorded_at")),
            )
            for decision in self._compiler.get_decisions(lease_id)
        )

    def _evidence_records_for_lease(self, lease_id: str | None) -> tuple[Evidence, ...]:
        if lease_id is None:
            return ()
        local_records = self._evidence_by_lease.get(lease_id)
        if local_records:
            return tuple(local_records)
        return tuple(
            Evidence(
                evidence_id=str(evidence.get("evidence_id", _mint_id("evidence"))),
                work_item_id=self._require_work_item_id_for_lease(lease_id),
                lease_id=lease_id,
                kind=str(evidence.get("evidence_type", "other")),
                artifacts=dict(evidence.get("artifacts", {})),
                test_results=evidence.get("test_results"),
                diff_summary=evidence.get("diff_summary"),
                log_excerpt=evidence.get("log_excerpt"),
                created_at=_parse_recorded_at(evidence.get("recorded_at")),
            )
            for evidence in self._compiler.get_evidence(lease_id)
        )

    def _finalize_work(
        self,
        lease_id: str,
        *,
        outcome: CompletionOutcome,
        summary: str,
        require_required_evidence: bool,
        require_approval_for_success: bool,
        successors: tuple[SuccessorSpec, ...] = (),
    ) -> Receipt:
        work_item_id = self._require_work_item_id_for_lease(lease_id)
        work_item = self._require_work_item(work_item_id)
        work_contract = self._require_work_contract_for_work_item(work_item)
        prepared_successors = self._prepare_successors(work_item, successors)
        if require_required_evidence:
            self._validate_required_evidence(lease_id, work_contract)
        if (
            require_approval_for_success
            and outcome == "success"
            and work_contract.approval_required
            and not self._approval_recorded(lease_id)
        ):
            raise MotusSupraValidationError(
                "approval decision required before successful completion"
            )

        release = self._compiler.release_work(lease_id, outcome=outcome)
        if release.decision.decision != "GRANTED":
            raise MotusSupraStateError(
                f"completion failed: {release.decision.reason_code}"
            )

        decision_summaries = tuple(
            record.summary for record in self._decision_records_for_lease(lease_id)
        )
        evidence_ids = tuple(
            evidence.evidence_id for evidence in self._evidence_records_for_lease(lease_id)
        )
        status = _status_for_outcome(outcome)
        route_outcome = _route_outcome_for_successors(prepared_successors)
        successor_work_item_ids = tuple(
            successor.work_item.work_item_id for successor in prepared_successors
        )
        receipt = Receipt(
            receipt_id=_mint_id("receipt"),
            work_item_id=work_item_id,
            lease_id=lease_id,
            status=status,
            outcome=outcome,
            route_outcome=route_outcome,
            evidence_ids=evidence_ids,
            decision_summaries=decision_summaries,
            successor_work_item_ids=successor_work_item_ids,
            summary=summary or f"{work_item.title} {status}",
        )
        self._receipts_by_work_item[work_item_id] = receipt
        self._work_items[work_item_id] = replace(
            work_item,
            status=status,
            active_lease_id=None,
            updated_at=_utcnow(),
        )
        self._materialize_successors(prepared_successors)
        return receipt

    def _prepare_successors(
        self,
        work_item: WorkItem,
        successors: tuple[SuccessorSpec, ...],
    ) -> tuple[_PreparedSuccessor, ...]:
        if not successors:
            return ()

        workflow = self._require_workflow_for_work_item(work_item)
        work_contract = self._require_work_contract_for_work_item(work_item)
        if work_item.current_node_id is None:
            raise MotusSupraStateError(
                f"work item {work_item.work_item_id} has no current workflow node"
            )
        current_node = workflow.route_graph.get(work_item.current_node_id)
        if current_node is None:
            raise MotusSupraStateError(
                f"unknown workflow node: {work_item.current_node_id}"
            )

        if current_node.successor_cardinality == "none":
            raise MotusSupraValidationError(
                f"workflow node {current_node.node_id} does not allow successors"
            )
        if current_node.successor_cardinality == "single" and len(successors) != 1:
            raise MotusSupraValidationError(
                f"workflow node {current_node.node_id} requires exactly one successor"
            )

        prepared: list[_PreparedSuccessor] = []
        seen_work_item_ids: set[str] = set()
        for spec in successors:
            if spec.work_item_id in seen_work_item_ids or spec.work_item_id in self._work_items:
                raise MotusSupraValidationError(
                    f"successor work item already exists: {spec.work_item_id}"
                )
            seen_work_item_ids.add(spec.work_item_id)

            target_workflow = self._workflows.get(spec.workflow_id or workflow.workflow_id)
            if target_workflow is None:
                raise MotusSupraValidationError(
                    f"unknown successor workflow: {spec.workflow_id or workflow.workflow_id}"
                )
            target_work_contract = self._work_contracts.get(
                spec.work_contract_id or work_contract.work_contract_id
            )
            if target_work_contract is None:
                raise MotusSupraValidationError(
                    "unknown successor work contract: "
                    f"{spec.work_contract_id or work_contract.work_contract_id}"
                )

            target_node_id = spec.next_node_id
            if target_node_id is None:
                if target_workflow.workflow_id == workflow.workflow_id:
                    if len(current_node.allowed_successor_ids) == 1:
                        target_node_id = current_node.allowed_successor_ids[0]
                    else:
                        raise MotusSupraValidationError(
                            "successor next_node_id required when multiple same-workflow "
                            "successors are allowed"
                        )
                else:
                    target_node_id = target_workflow.start_node_id

            if target_node_id not in target_workflow.route_graph:
                raise MotusSupraValidationError(
                    f"unknown successor node: {target_node_id}"
                )
            if (
                target_workflow.workflow_id == workflow.workflow_id
                and current_node.allowed_successor_ids
                and target_node_id not in current_node.allowed_successor_ids
            ):
                raise MotusSupraValidationError(
                    f"workflow node {current_node.node_id} does not allow successor "
                    f"{target_node_id}"
                )

            prepared.append(
                _PreparedSuccessor(
                    work_item=WorkItem(
                        work_item_id=spec.work_item_id,
                        title=spec.title,
                        intent=spec.intent,
                        resources=spec.resources,
                        status="bound",
                        workflow_id=target_workflow.workflow_id,
                        work_contract_id=target_work_contract.work_contract_id,
                        current_node_id=target_node_id,
                    )
                )
            )

        return tuple(prepared)

    def _materialize_successors(
        self,
        successors: tuple[_PreparedSuccessor, ...],
    ) -> None:
        for successor in successors:
            self._work_items[successor.work_item.work_item_id] = replace(
                successor.work_item,
                created_at=_utcnow(),
                updated_at=_utcnow(),
            )


def _status_for_outcome(outcome: CompletionOutcome) -> WorkItemStatus:
    if outcome == "success":
        return "completed"
    if outcome == "aborted":
        return "cancelled"
    return "failed"


def _route_outcome_for_successors(
    successors: tuple[_PreparedSuccessor, ...],
) -> RouteOutcome:
    if not successors:
        return "terminal"
    if len(successors) == 1:
        return "successor_single"
    return "successor_set"


def _parse_recorded_at(raw: Any) -> datetime:
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            return _utcnow()
    return _utcnow()


__all__ = [
    "DecisionProjection",
    "Evidence",
    "ExecutionProjection",
    "LocalMotusSupra",
    "MotusSupraError",
    "MotusSupraStateError",
    "MotusSupraValidationError",
    "OperatorProjection",
    "Receipt",
    "ResourceRef",
    "RouteNode",
    "WorkContract",
    "Workflow",
    "WorkItem",
]
