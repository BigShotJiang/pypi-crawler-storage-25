# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Argparse registration for the Store-backed wrap adapter."""

from __future__ import annotations

import argparse

from motus.wrap import DEFAULT_MAX_OUTPUT_BYTES


def register_wrap_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser(
        "wrap",
        help="Run a command and record a metadata-only Store timeline",
        description=(
            "Run a local command while Motus records a Store run with start, "
            "metadata-only output, and terminal outcome events."
        ),
    )
    parser.add_argument("--db", help="Store database path; default: .motus/kernel-store.db")
    parser.add_argument(
        "--max-output-bytes",
        type=int,
        default=DEFAULT_MAX_OUTPUT_BYTES,
        help="Maximum bytes tracked per stdout/stderr stream before marking metadata truncated",
    )
    parser.add_argument("--timeout", type=float, help="Kill the child command after N seconds")
    parser.add_argument(
        "--no-record",
        action="store_true",
        help="Run the command without creating or writing a Store run",
    )
    parser.add_argument(
        "wrapped_command",
        nargs=argparse.REMAINDER,
        help="Command to run after --",
    )
    return parser
