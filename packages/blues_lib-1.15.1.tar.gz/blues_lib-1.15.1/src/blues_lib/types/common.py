from typing import TypeAlias,TypedDict,Literal

# --- SQL ---
SQLPagination: TypeAlias = TypedDict("SQLPagination", {
  "no": int,
  "size": int,
})

SQLCondition: TypeAlias = TypedDict("SQLCondition", {
  "operator": str,
  "field": str,
  "comparator": str,
  "value": str|int|float|bool|None,
  "value_type": str, # function
})

SQLOrder: TypeAlias = TypedDict("SQLOrder", {
  "field": str,
  "sort": str,
})

SQLFilter: TypeAlias = TypedDict("SQLFilter", {
  "inc_fields": list[str],
  "inc_pattern": str,
  "dec_fields": list[str],
  "dec_pattern": str,
})

SQLOpts: TypeAlias = TypedDict("SQLOpts", {
  "table": str,
  "conditions": list[SQLCondition],
  
  # for update
  "entity": dict,
  
  # for insert
  "entities": list[dict],
  "filter": SQLFilter,
  "constants":dict,
  
  # for query
  "orders": list[SQLOrder],
  "fields": list[str],
  "page": SQLPagination,
})

# -- cleaner ---
CleanOpts: TypeAlias = TypedDict("CleanOpts", {
  "validity_days": int,
  "tables": list[str], # delete the db table
  "dirs": list[str], # delete the directory files
})

# -- message -- 
EmailPara: TypeAlias = TypedDict("EmailPara", {
  "type": Literal["text","image","link","remark"],
  "value": str,
})

EmailTpl: TypeAlias = Literal["default","publish"]

EmailOpts: TypeAlias = TypedDict("EmailOpts", {
  "template": EmailTpl,
  "addressee": list[str]|str,
  "addressee_name": str,
  "subject": str,
  "paras": list[EmailPara],
})

DingMsgType: TypeAlias = Literal["text","markdown","link","actioncard","feedcard"]
DingOpts: TypeAlias = TypedDict("DingOpts", {
  "msgtype": DingMsgType,
  "title": str,
  "text": str,
  "message_url": str,
  "pic_url": str,
  "content": str,
  "is_at_all": bool,
})



# --- Jinja2 ---
VAR_LEVEL: TypeAlias = Literal[
  "global", # 初始化全局替换
  "task", # 任务初始化替换
  "loop", # 循环体内替换
  "hook", # hook替换 - 占位符为 [( var )]
  "atom", # atom替换 - 占位符为 [[]]
]

# --- apscheduler ---
APSCron: TypeAlias = TypedDict("APSCron", {
  # 时间字段（支持 int 或 str，str 支持范围如 "1-5"、列表如 "1,3,5"）
  "year": int | str,          # 年，示例: 2024, "2024-2030"
  "month": int | str,         # 月 (1-12)，示例: 6, "1-6"
  "day": int | str,           # 日 (1-31)，示例: 15, "1,15"
  "week": int | str,          # 周 (1-53)，示例: 10, "1-5"
  "day_of_week": int | str,   # 星期几 (0-6 或 'mon','tue','wed','thu','fri','sat','sun')，示例: 1, "mon-fri", "1-5"
  "hour": int | str,          # 小时 (0-23)，支持单个值、范围、列表、步进
                               # 示例: 8（每天8点）, "9-18"（9点到18点每小时执行一次）, 
                               #       "0-23/2"（每隔2小时执行）, "9,12,15"（9点、12点、15点）
  "minute": int | str,        # 分钟 (0-59)，示例: 30, "0,30"
  "second": int | str,        # 秒 (0-59)，示例: 0, "0/10"
  
  # 日期范围
  "start_date": str,          # 开始日期，格式: "2024-01-01 08:00:00"
  "end_date": str,            # 结束日期，格式: "2024-12-31 23:59:59"
  
  # 其他配置
  "timezone": str,            # 时区，示例: "Asia/Shanghai", "UTC"
  "jitter": int | float,      # 抖动时间（秒），避免任务同时执行，示例: 60
  
  # 完整 cron 表达式（与上面字段互斥）
  "cron": str,                # 完整 cron 表达式，格式: "秒 分 时 日 月 周"，示例: "0 0 8 * * *"（每天8点）
})
APSExec: TypeAlias = TypedDict("APSExec", {
  "cwd": str, # 任务运行目录
  "command": str, # 任务运行命令
})

APSJob: TypeAlias = TypedDict("APSJob", {
  "name": str, # 任务名称（用于标识任务）
  "exec": APSExec, # 任务执行配置
  "cron": APSCron, # cron表达式
})