from typing import TypeAlias,TypedDict,Any,Literal,NotRequired

AttemptDelay: TypeAlias = int|float|list[int|float]

AbilityStep: TypeAlias = TypedDict("AbilityStep", {
  "value":float|int,
  "max_attempts":int,
  "interval":float|int,
})

ToolExpectMethod: TypeAlias = Literal[
  "to_be", # use == to compare the string/number/boolean value
  "to_equal", # compare the array/object value
  "to_be_null", # check the value is None
  "to_be_truthy","to_be_falsy", # check the value is truthy or falsy
  "to_be_greater_than","to_be_less_than","to_be_greater_than_or_equal","to_be_less_than_or_equal", # compare the number value
  "to_contain", # string or array contain the substring or element
  "to_match", # string match the regex pattern
  "to_have_length", # array have the length
  "to_have_length_greater_than", # array have the length greater than the value
  "to_have_property", # object has the property
  "not_to_be", # use != to compare the string/number/boolean value
  "not_to_equal", # compare the array/object value not equal
  "not_to_be_null", # check the value is not None
  "not_to_be_truthy","not_to_be_falsy", # check the value is not truthy or not falsy
  "not_to_be_greater_than","not_to_be_less_than","not_to_be_greater_than_or_equal","not_to_be_less_than_or_equal", # compare the number value
  "not_to_contain", # string or array not contain the substring or element
  "not_to_match", # string not match the regex pattern
  "not_to_have_length", # array not have the length
  "not_to_have_length_greater_than", # array not have the length greater than the value
  "not_to_have_property", # object not have the property
]
ToolExpectException: TypeAlias = Literal[
  "AbilityExecError", # Catch the Ability
  "SkipLoopWarning", # Catch by the Sequence and continue the seq loop,don't execute the error tools
  "SkipLoopError", # Catch by the Sequence and continue the seq loop
  "SkipSeqError", # Catch by the Task and continue the task
  "BlockSeqError", # Catch by the Flow and continue the flow loop
]
ToolExpect: TypeAlias = TypedDict("ToolExpect", {
  "method": ToolExpectMethod,
  "value": Any, # the value to compare
  "result": Any, # the result of the ability
  "exception": ToolExpectException, # the exception to throw if the expect is not met
})

class ToolDef(TypedDict):
  name: str
  description: NotRequired[str]
  options: dict

# --- seq level ---
# standard is the default type, and don't need by_value
ParaType: TypeAlias = Literal["text","image"]
Para: TypeAlias = TypedDict("Para", {
  "type":ParaType,
  "value":str,
})

# --- plan level ---
DriverStartupOpts: TypeAlias = TypedDict("DriverStartupOpts", {
  "features": list[str],
  "caps": dict[str,Any],
  "arguments": list[str],
  "exp_options": dict[str,Any],
  "extensions": list[str],
  "cdp_cmds": dict[str,Any],
})

# cft: chrome for testing; udc: undetected chrome; udcft: undetected chrome for testing
DriverMode: TypeAlias =  Literal["remote" , "chrome" , "cft" , "udc" , "udcft","context"]

DriverLocOpts: TypeAlias = TypedDict("DriverLocOpts", {
  # for remote
  "command_executor": str,
  # for chrome and udc
  "executable_path": str,
  "binary_location": str,
})

LoginMode: TypeAlias =  Literal["account","sms","qrcode"]
 
DriverDef: TypeAlias = TypedDict("DriverDef", {
  "mode": DriverMode,
  "ephemeral": bool, # whether quit the driver after task finished
  "startup": DriverStartupOpts,
  "location": DriverLocOpts,
  "login": str, # login definition uri
})
