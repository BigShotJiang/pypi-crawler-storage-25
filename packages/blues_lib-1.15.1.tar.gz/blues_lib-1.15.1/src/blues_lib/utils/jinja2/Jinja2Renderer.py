from jinja2 import Environment
from blues_lib.types import VAR_LEVEL
from blues_lib.utils.jinja2.Jinja2Globals import Jinja2Globals
import json

class Jinja2Renderer:
  '''
  提供直接的Jinja2渲染功能，只处理直接字符串模板
  '''

  @classmethod
  def _render_str(cls, template:str, data:dict, env:Environment, level:VAR_LEVEL = 'global')->any:
    '''
    渲染Jinja2模板字符串
    Args:
      template {str} : Jinja2模板字符串
      data {dict} : 渲染数据
      env {any} : Jinja2环境实例
      level {VAR_LEVEL} : 变量替换级别
        - global : 初始化全局替换 - 占位符为 {{ var }}
        - task : 任务初始化替换 {( var )}
        - loop : 循环体内替换 {[ var ]}
    Returns:
      any: 渲染后的结果，尝试转换为原始类型
    '''
    tpl = env.from_string(template)
    rendered_value = tpl.render(data)

    return cls._convert_to_primitive(rendered_value)

  @classmethod
  def render(cls, template:any, data:dict, level:VAR_LEVEL = 'global', excludes:list[str]|None = None)->any:
    '''
    渲染任意类型的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      level {VAR_LEVEL} : 变量替换级别
        - global : 初始化全局替换 - 占位符为 {{ var }}
        - task : 任务初始化替换 {( var )}
        - loop : 循环体内替换 {[ var ]}
        - hook : hook替换 - 占位符为 [( var )]
        - atom : atom替换 - 占位符为 [[]]
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    Note:
      当模板是字典或列表时，会返回一个新的字典或列表，而不会修改原始值
    '''
    env = cls._get_environment(level)
    Jinja2Globals.set_globals(env)

    excludes = excludes or []

    def _render_recursive(item:any, key:str = None)->any:
      if key and key in excludes:
        return item
      if isinstance(item, str):
        return cls._render_str(item, data, env, level)
      elif isinstance(item, dict):
        return {k: _render_recursive(v, k) for k, v in item.items()}
      elif isinstance(item, list):
        return [_render_recursive(element) for element in item]
      else:
        return item

    return _render_recursive(template)

  @classmethod
  def render_global(cls, template:any, data:dict, excludes:list[str]|None = None)->any:
    '''
    渲染global level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    return cls.render(template, data, level='global', excludes=excludes)

  @classmethod
  def render_task(cls, template:any, data:dict, excludes:list[str]|None = None)->any:
    '''
    渲染task level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    return cls.render(template, data, level='task', excludes=excludes)

  @classmethod
  def render_loop(cls, template:any, data:dict, excludes:list[str]|None = None)->any:
    '''
    渲染loop level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    default_excludes = ["tools", "type_tools"]
    excludes = (excludes or []) + default_excludes
    return cls.render(template, data, level='loop', excludes=excludes)

  @classmethod
  def render_hook(cls, template:any, data:dict, excludes:list[str]|None = None)->any:
    '''
    渲染hook level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    default_excludes = ["prev_tools", "post_tools"]
    excludes = (excludes or []) + default_excludes
    return cls.render(template, data, level='hook', excludes=excludes)

  @classmethod
  def render_atom(cls, template:any, data:dict, excludes:list[str]|None = None)->any:
    '''
    渲染atom level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    default_excludes = ["tools", "type_tools"]
    excludes = (excludes or []) + default_excludes
    atom_data = {
      **data,
      "_result":data, # pass as a result
    }
    return cls.render(template, atom_data, level='atom', excludes=excludes)

  @classmethod
  def render_by_self(cls, template:any, level:VAR_LEVEL = 'global', excludes:list[str] = None)->any:
    '''
    渲染模板数据，使用模板本身作为数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      level {VAR_LEVEL} : 变量替换级别
        - global : 初始化全局替换 - 占位符为 {{ var }}
        - task : 任务初始化替换 {( var )}
        - loop : 循环体内替换 {[ var ]}
        - hook : hook替换 - 占位符为 [( var )]
        - atom : atom替换 - 占位符为 [[]]
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    Note:
      当模板是字典或列表时，会返回一个新的字典或列表，而不会修改原始值
    '''
    return cls.render(template, template, level, excludes)

  @classmethod
  def _convert_to_primitive(cls, value:str)->any:
    '''
    将字符串转换为原始类型
    Args:
      value {str} : 要转换的字符串
    Returns:
      any: 转换后的原始类型
    '''
    if value.lower() == 'none' or value.strip() == 'null':
      return None

    if value.lower() == 'true':
      return True
    if value.lower() == 'false':
      return False

    try:
      if '.' in value:
        return float(value)
      else:
        return int(value)
    except ValueError:
      pass

    stripped_value = value.strip()
    if ((stripped_value.startswith('[') and stripped_value.endswith(']'))) or \
       ((stripped_value.startswith('{') and stripped_value.endswith('}'))):
      try:
        return json.loads(value)
      except json.JSONDecodeError:
        try:
          import ast
          return ast.literal_eval(value)
        except (SyntaxError, ValueError):
          pass

    return value

  @classmethod
  def _get_environment(cls, level:VAR_LEVEL)->Environment:
    '''
    根据level获取对应的Environment实例
    Args:
      level {VAR_LEVEL} : 变量替换级别
    Returns:
      Environment: 配置好的Environment实例
    '''
    if level == 'task':
      return Environment(
        variable_start_string='{(',
        variable_end_string=')}'
      )
    elif level == 'loop':
      return Environment(
        variable_start_string='{[',
        variable_end_string=']}'
      )
    elif level == 'hook':
      return Environment(
        variable_start_string='[(',
        variable_end_string=')]'
      )
    elif level == 'atom':
      return Environment(
        variable_start_string='[[',
        variable_end_string=']]'
      )
    else:
      return Environment()
