"""
patch_maya_metrics.py
Fixes two issues in maya_metrics_repo:
  1. D★ criterion uses partial_r not raw Vairagya-pruning r
  2. Cross-substrate uses step-ordered domain grouping
"""

import os

BASE = r"C:\Users\venky\PycharmProjects\Maya\maya_metrics_repo"

# ── Fix 1: cross_dimensional.py ───────────────────────────────────────────────
cd_path = os.path.join(BASE, "maya_metrics", "cross_dimensional.py")
with open(cd_path, "r", encoding="utf-8") as f:
    src = f.read()

src = src.replace(
    '"d_star_confirmed": r_vp < -0.3 and r_kp > 0.5,',
    '"d_star_confirmed": partial_r_val < -0.5 and r_kp > 0.5,'
)
src = src.replace(
    "f\"D\u2605 interaction {'CONFIRMED' if r_vp < -0.3 and r_kp > 0.5 else 'NOT detected'}. \"",
    "f\"D\u2605 interaction {'CONFIRMED' if partial_r_val < -0.5 and r_kp > 0.5 else 'NOT detected'}. \""
)
src = src.replace(
    "f\"Vairagya moderates it (r={r_vp:.3f}, partial_r={partial_r_val:.3f}).\"",
    "f\"Vairagya moderates it (partial_r={partial_r_val:.3f} after controlling for Karma).\""
)

with open(cd_path, "w", encoding="utf-8") as f:
    f.write(src)
print(f"✓ Patched: {cd_path}")

# ── Fix 2: cross_substrate.py ─────────────────────────────────────────────────
cs_path = os.path.join(BASE, "maya_metrics", "cross_substrate.py")
with open(cs_path, "r", encoding="utf-8") as f:
    src = f.read()

OLD = '''        # LLM Buddhi
        llm_col = "buddhi_score" if "buddhi_score" in self.llm_df.columns else "buddhi"
        if llm_col not in self.llm_df.columns:
            return {"error": f"Column '{llm_col}' not found in LLM DataFrame."}

        llm_group_col = self.llm_task_col if self.llm_task_col in self.llm_df.columns else "step"
        llm_task_means = self.llm_df.groupby(llm_group_col)[llm_col].mean()
        llm_buddhi = llm_task_means.values.astype(float)'''

NEW = '''        # LLM Buddhi — preserve sequential domain order via step, not alphabetical
        llm_col = "buddhi_score" if "buddhi_score" in self.llm_df.columns else "buddhi"
        if llm_col not in self.llm_df.columns:
            return {"error": f"Column '{llm_col}' not found in LLM DataFrame."}

        llm_sorted = self.llm_df.sort_values("step") if "step" in self.llm_df.columns else self.llm_df
        llm_group_col = self.llm_task_col if self.llm_task_col in llm_sorted.columns else "step"
        if llm_group_col in llm_sorted.columns and llm_group_col != "step":
            domain_order = llm_sorted[llm_group_col].unique()
            llm_task_means = llm_sorted.groupby(llm_group_col)[llm_col].mean().reindex(domain_order)
        else:
            llm_task_means = llm_sorted.groupby(llm_group_col)[llm_col].mean()
        llm_buddhi = llm_task_means.values.astype(float)'''

if OLD in src:
    src = src.replace(OLD, NEW)
    with open(cs_path, "w", encoding="utf-8") as f:
        f.write(src)
    print(f"✓ Patched: {cs_path}")
else:
    print(f"⚠ Could not find target block in {cs_path} — may already be patched")

print("\nDone. Restart the dashboard.")
