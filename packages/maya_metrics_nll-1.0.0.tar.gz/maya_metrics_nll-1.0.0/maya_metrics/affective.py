"""
affective.py — Time-series metrics for affective/neuromodulatory dimensions.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
ORCID: 0000-0002-3315-7907

Validated against Maya Research Series P3–P9 (Swaminathan, 2026).
Series constants confirmed:
  - Bhaya Quiescence Law: bhaya == 0.000 under replay, Tasks 1–9, every paper
  - Buddhi S-curve Determinism: identical sigmoid P4–P9, all conditions
"""

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.stats import pearsonr
from typing import Optional


def _sigmoid(x, L, k, x0, b):
    """Logistic sigmoid used for Buddhi S-curve fitting."""
    return L / (1 + np.exp(-k * (x - x0))) + b


class AffectiveMetrics:
    """
    Stateless evaluator for affective dimension time-series in Maya batch logs.

    Parameters
    ----------
    df : pd.DataFrame
        Maya batch log with columns: task, epoch, bhaya, vairagya, buddhi, etc.
    task_col : str
        Column name for task index (default: 'task').

    Examples
    --------
    >>> am = AffectiveMetrics(df)
    >>> am.bhaya_quiescence_score()
    >>> am.buddhi_scurve_fit()
    >>> am.summary()
    """

    def __init__(self, df: pd.DataFrame, task_col: str = "task"):
        self.df = df.copy()
        self.task_col = task_col
        self._task_means = df.groupby(task_col).mean(numeric_only=True)
        self.n_tasks = int(df[task_col].nunique())

    # ── Bhaya ──────────────────────────────────────────────────────────────────

    def bhaya_quiescence_score(self, replay_start_task: int = 1,
                                tolerance: float = 1e-4) -> dict:
        """
        Measure the Bhaya Quiescence Law.

        Under replay (Tasks >= replay_start_task), Bhaya should converge to 0.
        Confirmed across all 9 Maya papers, every seed.

        Returns
        -------
        dict with keys:
          law_confirmed  : bool — True if mean Bhaya < tolerance from replay_start_task
          task0_bhaya    : float — Bhaya during first task (pre-replay, should be > 0)
          replay_mean    : float — Mean Bhaya from replay_start_task onwards
          replay_max     : float — Max Bhaya from replay_start_task onwards
          violation_tasks: list  — Tasks where Bhaya > tolerance (should be empty)
          quiescence_rate: float — Fraction of replay tasks with Bhaya < tolerance
        """
        if "bhaya" not in self.df.columns:
            return {"error": "Column 'bhaya' not found."}

        task_bhaya = self._task_means["bhaya"]
        task0 = float(task_bhaya.iloc[0])
        replay = task_bhaya.iloc[replay_start_task:]
        replay_mean = float(replay.mean())
        replay_max  = float(replay.max())
        violations  = [int(t) for t, v in replay.items() if v > tolerance]
        qrate       = float((replay < tolerance).mean())

        return {
            "law_confirmed": replay_max < tolerance,
            "task0_bhaya": task0,
            "replay_mean": replay_mean,
            "replay_max": replay_max,
            "violation_tasks": violations,
            "quiescence_rate": qrate,
            "tolerance": tolerance,
            "interpretation": (
                "Bhaya Quiescence Law CONFIRMED — pain signal fully suppressed under replay."
                if replay_max < tolerance else
                f"WARNING: Bhaya fired on tasks {violations} under replay. "
                "Check replay buffer integrity — this signals catastrophic forgetting."
            ),
        }

    def bhaya_timeseries(self) -> pd.Series:
        """Per-task mean Bhaya values."""
        return self._task_means["bhaya"] if "bhaya" in self.df.columns else None

    # ── Buddhi ─────────────────────────────────────────────────────────────────

    def buddhi_scurve_fit(self) -> dict:
        """
        Fit a sigmoid to the Buddhi consolidation gate trajectory.

        Buddhi S-curve determinism is a confirmed series constant (P4–P9):
        identical sigmoid regardless of ablation condition or other dimensions.

        Returns
        -------
        dict with keys:
          r_squared    : float — Goodness of fit (> 0.95 confirms S-curve)
          params       : dict  — Fitted sigmoid parameters (L, k, x0, b)
          inflection   : float — Task at which Buddhi reaches 50% of max range
          ceiling_task : int   — First task where Buddhi > 0.99
          deterministic: bool  — True if r_squared > 0.95
          per_task     : list  — Per-task mean Buddhi values
        """
        if "buddhi" not in self.df.columns:
            return {"error": "Column 'buddhi' not found."}

        task_buddhi = self._task_means["buddhi"].values
        x = np.arange(len(task_buddhi), dtype=float)

        try:
            popt, _ = curve_fit(
                _sigmoid, x, task_buddhi,
                p0=[1.0, 2.0, 2.0, 0.0],
                maxfev=10000,
                bounds=([0, 0, -1, -0.1], [1.5, 20, 15, 0.5]),
            )
            fitted = _sigmoid(x, *popt)
            ss_res = np.sum((task_buddhi - fitted) ** 2)
            ss_tot = np.sum((task_buddhi - task_buddhi.mean()) ** 2)
            r2 = float(1 - ss_res / ss_tot) if ss_tot > 0 else 1.0
            L, k, x0, b = popt
            inflection = float(x0)
        except Exception:
            r2, L, k, x0, b = 0.0, 1.0, 1.0, 1.0, 0.0
            inflection = float("nan")

        ceiling_task = next(
            (int(i) for i, v in enumerate(task_buddhi) if v > 0.99), -1
        )

        return {
            "r_squared": round(r2, 4),
            "params": {"L": round(float(L), 4), "k": round(float(k), 4),
                       "x0": round(float(x0), 4), "b": round(float(b), 4)},
            "inflection_task": round(inflection, 2),
            "ceiling_task": ceiling_task,
            "deterministic": r2 > 0.95,
            "per_task": [round(float(v), 4) for v in task_buddhi],
            "interpretation": (
                f"Buddhi S-curve CONFIRMED (R²={r2:.4f}). "
                f"Inflection at task {inflection:.1f}, ceiling at task {ceiling_task}."
                if r2 > 0.95 else
                f"Buddhi trajectory does not fit sigmoid (R²={r2:.4f}). "
                "Verify experiment integrity."
            ),
        }

    # ── Vairagya ───────────────────────────────────────────────────────────────

    def vairagya_saturation_fraction(self,
                                      protection_col: str = "vairagya_protection_fc1",
                                      threshold: float = 0.3) -> dict:
        """
        Measure the fraction of the network under Vairagya protection per task.

        Vairagya (heterosynaptic decay) accumulates earned protection.
        Above threshold, gradients are blocked — synapse is 'protected'.

        Returns
        -------
        dict with per-task saturation fractions and growth trend.
        """
        col = protection_col if protection_col in self.df.columns else "vairagya"
        if col not in self.df.columns:
            return {"error": f"Neither '{protection_col}' nor 'vairagya' found."}

        task_vals = self._task_means[col].values
        saturated = (task_vals >= threshold).astype(float)
        r, p = pearsonr(np.arange(len(task_vals)), task_vals)

        return {
            "per_task_protection": [round(float(v), 4) for v in task_vals],
            "saturation_threshold": threshold,
            "final_protection": round(float(task_vals[-1]), 4),
            "peak_protection": round(float(task_vals.max()), 4),
            "peak_task": int(task_vals.argmax()),
            "monotonic_growth": bool(r > 0.5 and p < 0.05),
            "pearson_r": round(float(r), 4),
            "interpretation": (
                f"Vairagya protection peaked at {task_vals.max():.3f} (task {task_vals.argmax()}). "
                f"{'Monotonic growth confirmed.' if r > 0.5 else 'Non-monotonic — check ablation condition.'}"
            ),
        }

    # ── Prana ──────────────────────────────────────────────────────────────────

    def prana_depletion_profile(self) -> dict:
        """
        Analyse Prana (metabolic plasticity budget) depletion and recovery.

        Prana grounds the Astrocyte-Neuron Lactate Shuttle biological analogy:
        plasticity slows when the metabolic budget is depleted.

        Returns
        -------
        dict with depletion trajectory, recovery events, effective_lr correlation.
        """
        if "prana_value" not in self.df.columns:
            return {"error": "Column 'prana_value' not found."}

        prana = self._task_means["prana_value"].values
        min_prana = float(prana.min())
        depletion_tasks = [int(i) for i, v in enumerate(prana) if v < 0.95]

        lr_corr = None
        if "effective_lr" in self.df.columns:
            lr = self._task_means["effective_lr"].values
            r, p = pearsonr(prana, lr)
            lr_corr = {"pearson_r": round(float(r), 4), "p_value": round(float(p), 4)}

        return {
            "per_task_prana": [round(float(v), 4) for v in prana],
            "min_prana": round(min_prana, 4),
            "depletion_tasks": depletion_tasks,
            "full_budget_maintained": min_prana >= 0.95,
            "lr_correlation": lr_corr,
            "interpretation": (
                "Prana maintained full budget — metabolic constraint not active in this run."
                if min_prana >= 0.95 else
                f"Prana depleted to {min_prana:.3f} on tasks {depletion_tasks}. "
                "Metabolic constraint actively throttled plasticity."
            ),
        }

    # ── Karma ──────────────────────────────────────────────────────────────────

    def karma_accumulation_profile(self) -> dict:
        """
        Measure Karma accumulation — second-order plasticity history.

        Karma = absolute integral of weight trajectory changes across tasks.
        KARMA_DECAY_RATE = 0.002315 (ORCID magic number, embedded P6+).

        Returns
        -------
        dict with per-task Karma, growth rate, threshold crossings.
        """
        if "karma_mean" not in self.df.columns:
            return {"error": "Column 'karma_mean' not found."}

        karma = self._task_means["karma_mean"].values
        diffs = np.diff(karma)
        mean_growth = float(diffs.mean()) if len(diffs) > 0 else 0.0
        r, p = pearsonr(np.arange(len(karma)), karma)

        return {
            "per_task_karma": [round(float(v), 6) for v in karma],
            "final_karma": round(float(karma[-1]), 6),
            "mean_growth_per_task": round(mean_growth, 6),
            "monotonic": bool(r > 0.8 and p < 0.01),
            "pearson_r": round(float(r), 4),
            "karma_decay_rate": 0.002315,
            "interpretation": (
                f"Karma accumulated monotonically to {karma[-1]:.4f} "
                f"(growth rate {mean_growth:.4f}/task). "
                "Historical plasticity burden building correctly."
                if r > 0.8 else
                "Karma trajectory non-monotonic — check KARMA_DECAY_RATE setting."
            ),
        }

    # ── Chitta ─────────────────────────────────────────────────────────────────

    def chitta_retrograde_rate(self) -> dict:
        """
        Measure Chitta retrograde gradient gate activity.

        Chitta implements endocannabinoid-analogous retrograde correction.
        retrograde_fired counts gate activations per batch.
        """
        if "retrograde_fired" not in self.df.columns:
            return {"error": "Column 'retrograde_fired' not found."}

        retro = self._task_means["retrograde_fired"].values
        samskara = (self._task_means["samskara_mean"].values
                    if "samskara_mean" in self.df.columns else None)

        return {
            "per_task_retrograde_rate": [round(float(v), 4) for v in retro],
            "mean_retrograde_rate": round(float(retro.mean()), 4),
            "peak_task": int(retro.argmax()),
            "per_task_samskara": (
                [round(float(v), 4) for v in samskara]
                if samskara is not None else None
            ),
            "interpretation": (
                f"Retrograde gate active — mean rate {retro.mean():.3f}/batch, "
                f"peak at task {retro.argmax()}."
            ),
        }

    # ── Manas ──────────────────────────────────────────────────────────────────

    def manas_oscillatory_efficacy(self) -> dict:
        """
        Measure Manas thalamo-cortical oscillatory gate efficacy.

        Manas implements a half-cycle cosine LIF threshold (Vikalpa→Sankalpa).
        manas_peak_fraction = fraction of spikes during Sankalpa (receptive) phase.
        """
        if "manas" not in self.df.columns:
            return {"error": "Column 'manas' not found."}

        manas = self._task_means["manas"].values
        peak_frac = (self._task_means["manas_peak_fraction"].values
                     if "manas_peak_fraction" in self.df.columns else None)

        return {
            "per_task_manas": [round(float(v), 4) for v in manas],
            "mean_gate_value": round(float(manas.mean()), 4),
            "per_task_sankalpa_fraction": (
                [round(float(v), 4) for v in peak_frac]
                if peak_frac is not None else None
            ),
            "mean_sankalpa_fraction": (
                round(float(peak_frac.mean()), 4)
                if peak_frac is not None else None
            ),
            "interpretation": (
                f"Manas gate active — mean value {manas.mean():.3f}. "
                + (f"Sankalpa (receptive) phase fraction: {peak_frac.mean():.3f}."
                   if peak_frac is not None else "")
            ),
        }

    # ── Summary ────────────────────────────────────────────────────────────────

    def summary(self) -> dict:
        """Run all available affective metrics and return unified report."""
        out = {
            "n_tasks": self.n_tasks,
            "n_rows": len(self.df),
            "bhaya_quiescence": self.bhaya_quiescence_score(),
            "buddhi_scurve": self.buddhi_scurve_fit(),
            "vairagya_saturation": self.vairagya_saturation_fraction(),
            "prana_profile": self.prana_depletion_profile(),
            "karma_profile": self.karma_accumulation_profile(),
        }
        if "retrograde_fired" in self.df.columns:
            out["chitta_retrograde"] = self.chitta_retrograde_rate()
        if "manas" in self.df.columns:
            out["manas_oscillatory"] = self.manas_oscillatory_efficacy()
        return out
