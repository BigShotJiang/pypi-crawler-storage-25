"""
maturation.py — Neural network developmental maturation metrics.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
ORCID: 0000-0002-3315-7907

The Maya series explicitly tracks developmental age:
  P1–P7 = Maya age 5 (reactive, plastic, Buddhi nascent)
  P8    = Mechanistic maturation begins
  P9    = Maya age 21 (full Antahkarana, consolidated)

No standard ML metric quantifies structural age independently of accuracy.
This module closes that gap (Gap #2 from Gemini literature sweep).
"""

import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from typing import Optional


class MaturationIndex:
    """
    Structural age and developmental maturation metrics.

    Parameters
    ----------
    df : pd.DataFrame
        Maya batch log DataFrame with affective dimension columns.
    """

    def __init__(self, df: pd.DataFrame, task_col: str = "task"):
        self.df = df.copy()
        self.task_col = task_col
        self._task_means = df.groupby(task_col).mean(numeric_only=True)
        self.n_tasks = int(df[task_col].nunique())

    def structural_age(self) -> dict:
        """
        Compute a composite Structural Age Index (SAI) per task.

        SAI combines:
          - Buddhi consolidation level (maturity of discriminative gate)
          - Vairagya protection fraction (earned synaptic stability)
          - Inverse pruned_fraction (structural completeness)
          - Inverse lability_mean (synaptic stability)

        SAI = 0 → fully plastic (infant)
        SAI = 1 → fully consolidated (mature)

        Returns
        -------
        dict with per-task SAI, developmental stage labels, transition task.
        """
        tm = self._task_means
        components = {}
        weights = {}

        if "buddhi" in tm.columns:
            components["buddhi"] = tm["buddhi"].values
            weights["buddhi"] = 0.4

        if "vairagya" in tm.columns:
            v = tm["vairagya"].values
            components["vairagya"] = v / v.max() if v.max() > 0 else v
            weights["vairagya"] = 0.3

        if "pruned_fraction" in tm.columns:
            # Inverse: more pruning = more structural definition
            components["pruning"] = tm["pruned_fraction"].values
            weights["pruning"] = 0.2

        if "lability_mean" in tm.columns:
            lab = tm["lability_mean"].values
            lab_norm = 1 - (lab / lab.max()) if lab.max() > 0 else lab
            components["stability"] = lab_norm
            weights["stability"] = 0.1

        if not components:
            return {"error": "No maturation components found in DataFrame."}

        # Normalise weights
        total_w = sum(weights.values())
        sai = np.zeros(self.n_tasks)
        for name, vals in components.items():
            w = weights[name] / total_w
            sai += w * vals[:self.n_tasks]

        # Developmental stage labels
        def _stage(v):
            if v < 0.3: return "Infant (age 5)"
            if v < 0.7: return "Adolescent"
            if v < 0.9: return "Maturing"
            return "Adult (age 21)"

        stages = [_stage(float(v)) for v in sai]

        # Transition task: first task where SAI > 0.7
        transition = next((int(i) for i, v in enumerate(sai) if v > 0.7), -1)

        return {
            "per_task_sai": [round(float(v), 4) for v in sai],
            "final_sai": round(float(sai[-1]), 4),
            "developmental_stages": stages,
            "maturation_transition_task": transition,
            "components_used": list(components.keys()),
            "interpretation": (
                f"Structural Age Index reached {sai[-1]:.3f} at final task "
                f"(stage: {stages[-1]}). "
                f"Maturation transition at task {transition}."
            ),
        }

    def plasticity_transition_rate(self) -> dict:
        """
        Measure the rate at which the network transitions from
        exploratory (plastic) to exploitative (stable) states.

        Uses first derivative of effective_lr as proxy for
        externally-imposed plasticity, and Buddhi as internal gate.
        """
        if "buddhi" not in self.df.columns:
            return {"error": "Column 'buddhi' required."}

        buddhi = self._task_means["buddhi"].values
        d_buddhi = np.diff(buddhi)
        peak_transition = int(np.argmax(np.abs(d_buddhi)))

        lr_rate = None
        if "effective_lr" in self.df.columns:
            lr = self._task_means["effective_lr"].values
            d_lr = np.diff(lr)
            lr_rate = [round(float(v), 6) for v in d_lr]

        return {
            "buddhi_derivative": [round(float(v), 4) for v in d_buddhi],
            "peak_transition_task": peak_transition,
            "lr_derivative": lr_rate,
            "interpretation": (
                f"Fastest plasticity transition between tasks "
                f"{peak_transition} and {peak_transition+1} "
                f"(Buddhi delta = {d_buddhi[peak_transition]:.4f})."
            ),
        }

    def senescence_score(self) -> dict:
        """
        Estimate network 'senescence' — structural ossification from
        accumulated Karma burden.

        Senescence = high Karma + high pruning + high Buddhi (ceiling) +
                     declining Vairagya protection.

        This is a forward-looking metric: detects when a lifelong learning
        system is approaching topological rigidity.
        """
        if "karma_mean" not in self.df.columns:
            return {"error": "Column 'karma_mean' required for senescence score."}

        tm = self._task_means
        karma = tm["karma_mean"].values

        # Rising Karma = accumulating burden
        karma_norm = karma / karma.max() if karma.max() > 0 else karma

        # Pruning load
        prune_norm = np.zeros(self.n_tasks)
        if "pruned_fraction" in tm.columns:
            pf = tm["pruned_fraction"].values
            prune_norm = pf / pf.max() if pf.max() > 0 else pf

        # Vairagya decline (late-stage protection collapse = senescence risk)
        vairagya_decline = np.zeros(self.n_tasks)
        if "vairagya" in tm.columns:
            v = tm["vairagya"].values
            v_norm = v / v.max() if v.max() > 0 else v
            # Decline from peak
            peak = v_norm.max()
            vairagya_decline = np.clip(peak - v_norm, 0, 1)

        senescence = 0.4 * karma_norm + 0.4 * prune_norm + 0.2 * vairagya_decline

        return {
            "per_task_senescence": [round(float(v), 4) for v in senescence],
            "final_senescence": round(float(senescence[-1]), 4),
            "senescence_risk": "HIGH" if senescence[-1] > 0.7
                               else "MODERATE" if senescence[-1] > 0.4
                               else "LOW",
            "interpretation": (
                f"Network senescence score: {senescence[-1]:.3f} "
                f"({'HIGH — structural ossification risk' if senescence[-1] > 0.7 else 'LOW — plasticity reserve healthy'})."
            ),
        }

    def summary(self) -> dict:
        return {
            "structural_age": self.structural_age(),
            "plasticity_transition": self.plasticity_transition_rate(),
            "senescence": self.senescence_score(),
        }
