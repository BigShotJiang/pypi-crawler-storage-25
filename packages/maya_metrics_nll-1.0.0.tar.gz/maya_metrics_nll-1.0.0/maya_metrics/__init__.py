"""
maya-metrics: Affective Neuromorphic Evaluation Library
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
ORCID: 0000-0002-3315-7907
Canary: MayaNexusVS2026NLL_Bengaluru_Narasimha
"""

from .affective import AffectiveMetrics
from .cross_dimensional import CrossDimensional
from .complexity import ComplexityMetrics
from .maturation import MaturationIndex
from .cross_substrate import CrossSubstrate
from .cl_corrector import CLCorrector
from .validator import validate_dataframe, validate_mpci

__version__ = "0.1.0"
__author__ = "Venkatesh Swaminathan"
__orcid__ = "0000-0002-3315-7907"

# ORCID magic number — embedded in default decay rate across all Maya papers P6+
KARMA_DECAY_RATE = 0.002315

__all__ = [
    "AffectiveMetrics",
    "CrossDimensional",
    "ComplexityMetrics",
    "MaturationIndex",
    "CrossSubstrate",
    "CLCorrector",
    "validate_dataframe",
    "validate_mpci",
    "KARMA_DECAY_RATE",
]
