"""
cl_corrector.py — Standardised CIL metric corrections.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
ORCID: 0000-0002-3315-7907

Re-exports cl-metrics (Swaminathan, 2026, DOI: 10.5281/zenodo.19388144)
and adds oracle-enforced Intransigence and strict FWT definition splitting.

Gap #10 from Gemini sweep: FWT has two mutually incompatible definitions.
Intransigence without oracle reference collapses to zero and is invalid.
"""

import numpy as np
from typing import Optional


class CLCorrector:
    """
    Stateless CIL metric corrections enforcing canonical formulations.

    Parameters
    ----------
    R : np.ndarray
        N×N accuracy matrix where R[i,j] = accuracy on task j after task i.
    spike_rates : np.ndarray, optional
        1D array of per-task mean spike firing rates (for SNN metrics).
    """

    def __init__(self, R: np.ndarray, spike_rates: Optional[np.ndarray] = None):
        self.R = np.array(R, dtype=float)
        self.N = R.shape[0]
        self.spike_rates = np.array(spike_rates) if spike_rates is not None else None
        assert R.shape[0] == R.shape[1], "R must be a square N×N matrix."

    def average_accuracy(self, weighted: bool = False,
                          class_counts: Optional[np.ndarray] = None) -> float:
        """
        AA = (1/N) Σ R[N-1, j]   (macro, default)
        or weighted by class_counts (micro).

        Gap: undisclosed weight vectors invalidate cross-paper comparisons.
        Always report which formulation was used.
        """
        terminal = self.R[-1, :]
        if weighted and class_counts is not None:
            w = np.array(class_counts, dtype=float)
            return float(np.average(terminal, weights=w))
        return float(terminal.mean())

    def backward_transfer(self) -> float:
        """BWT = (1/N-1) Σ [R[N-1,j] - R[j,j]], j=0..N-2"""
        if self.N < 2:
            return 0.0
        diffs = [self.R[-1, j] - self.R[j, j] for j in range(self.N - 1)]
        return float(np.mean(diffs))

    def forward_transfer_zeroshot(self) -> float:
        """
        FWT (zero-shot definition — Díaz-Rodríguez et al. 2018):
        FWT = (1/N-1) Σ R[j-1, j], j=1..N-1
        Accuracy on task j BEFORE seeing any data from task j.
        """
        if self.N < 2:
            return 0.0
        vals = [self.R[j - 1, j] for j in range(1, self.N)]
        return float(np.mean(vals))

    def forward_transfer_acceleration(self,
                                       baseline_diagonal: Optional[np.ndarray] = None) -> Optional[float]:
        """
        FWT (curriculum acceleration definition):
        Speed gain on task j from having learned prior tasks,
        relative to learning task j in isolation (requires baseline diagonal).
        Returns None if baseline_diagonal not provided — NEVER approximates.
        """
        if baseline_diagonal is None:
            return None
        b = np.array(baseline_diagonal, dtype=float)
        vals = [self.R[j, j] - b[j] for j in range(self.N)]
        return float(np.mean(vals))

    def intransigence(self, oracle_reference: Optional[np.ndarray] = None) -> Optional[float]:
        """
        I = (1/N) Σ [alpha_j - R[j,j]]

        STRICT: Returns None if oracle_reference not provided.
        The field routinely approximates oracle as 0, rendering I invalid.
        This function REFUSES computation without the oracle.
        """
        if oracle_reference is None:
            return None
        alpha = np.array(oracle_reference, dtype=float)
        return float(np.mean(alpha - np.diag(self.R)))

    def forgetting_measure(self) -> float:
        """F = (1/N-1) Σ max_l [R[l,j] - R[N-1,j]], l=j..N-2"""
        if self.N < 2:
            return 0.0
        vals = []
        for j in range(self.N - 1):
            max_acc = max(self.R[l, j] for l in range(j, self.N - 1))
            vals.append(max_acc - self.R[-1, j])
        return float(np.mean(vals))

    def summary(self, oracle_reference: Optional[np.ndarray] = None,
                 class_counts: Optional[np.ndarray] = None) -> dict:
        return {
            "AA_macro": round(self.average_accuracy(), 4),
            "AA_weighted": (
                round(self.average_accuracy(weighted=True, class_counts=class_counts), 4)
                if class_counts is not None else None
            ),
            "BWT": round(self.backward_transfer(), 4),
            "FWT_zeroshot": round(self.forward_transfer_zeroshot(), 4),
            "FWT_acceleration": (
                round(self.forward_transfer_acceleration(), 4)
                if oracle_reference is not None else None
            ),
            "Intransigence": (
                round(self.intransigence(oracle_reference), 4)
                if oracle_reference is not None else
                "NOT COMPUTED — oracle_reference required (never approximate as 0)"
            ),
            "Forgetting": round(self.forgetting_measure(), 4),
        }
