"""
validator.py — Pre-computation checks for maya-metrics inputs.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
"""

import pandas as pd
import numpy as np


REQUIRED_BASE = {"task", "epoch", "bhaya", "vairagya"}
BUDDHI_COLS   = {"buddhi"}
FULL_COLS     = {
    "bhaya", "vairagya", "buddhi", "chitta", "manas",
    "karma_mean", "prana_value", "pruned_fraction", "effective_lr",
    "samskara_mean", "retrograde_fired", "manas_peak_fraction",
    "shunyata_events", "pain_fired", "confidence",
}


def validate_dataframe(df: pd.DataFrame, require_cols: set = None) -> dict:
    """
    Validate a Maya batch log DataFrame.
    Returns dict with keys: valid (bool), warnings (list), errors (list).
    """
    errors, warnings = [], []
    cols = set(df.columns)

    required = require_cols if require_cols else REQUIRED_BASE
    missing = required - cols
    if missing:
        errors.append(f"Missing required columns: {missing}")

    if "task" in cols:
        tasks = sorted(df["task"].unique())
        if tasks != list(range(len(tasks))):
            warnings.append(f"Tasks are not zero-indexed contiguous: {tasks}")

    if "bhaya" in cols:
        if df["bhaya"].min() < 0 or df["bhaya"].max() > 1:
            errors.append("bhaya values outside [0, 1]")

    if "buddhi" in cols:
        if df["buddhi"].min() < 0 or df["buddhi"].max() > 1:
            errors.append("buddhi values outside [0, 1]")

    if "prana_value" in cols:
        if df["prana_value"].min() < 0 or df["prana_value"].max() > 1:
            warnings.append("prana_value contains values outside [0, 1]")

    available = FULL_COLS & cols
    missing_optional = FULL_COLS - cols
    if missing_optional:
        warnings.append(
            f"Optional columns absent (some metrics unavailable): {missing_optional}"
        )

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "available_columns": sorted(available),
        "n_tasks": len(df["task"].unique()) if "task" in cols else None,
        "n_rows": len(df),
    }


def validate_mpci(df: pd.DataFrame) -> dict:
    """Validate an mPCI summary DataFrame."""
    errors, warnings = [], []
    required = {"phase", "mpci_mean", "delta_vs_phase1"}
    missing = required - set(df.columns)
    if missing:
        errors.append(f"Missing mPCI columns: {missing}")
    if len(df) < 2:
        errors.append("mPCI summary must have at least 2 phases.")
    return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings}
