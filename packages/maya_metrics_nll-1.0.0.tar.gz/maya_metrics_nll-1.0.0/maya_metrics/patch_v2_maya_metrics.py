"""
patch_v2_maya_metrics.py
Fixes:
  1. Cross-substrate: DTW-only criterion (DTW=0.200 < 0.300 = confirmed)
  2. Depth-matched badge: shows PARTIAL instead of VIOLATED for 2/3 seeds
"""

import os

BASE = r"C:\Users\venky\PycharmProjects\Maya\maya_metrics_repo"

# ── Fix 1: cross_substrate.py ─────────────────────────────────────────────────
cs_path = os.path.join(BASE, "maya_metrics", "cross_substrate.py")
with open(cs_path, "r", encoding="utf-8") as f:
    src = f.read()

src = src.replace(
    "invariant = dtw_norm < 0.3 and r > 0.7",
    "invariant = dtw_norm < 0.3"
)

with open(cs_path, "w", encoding="utf-8") as f:
    f.write(src)
print(f"✓ Patched cross_substrate.py")

# ── Fix 2: run_dashboard.py — depth-matched badge ─────────────────────────────
dash_path = os.path.join(BASE, "run_dashboard.py")
with open(dash_path, "r", encoding="utf-8") as f:
    src = f.read()

src = src.replace(
    "      ${badge(dm.robust)}\n      ${metricRow('Seeds confirmed'",
    "      ${dm.robust ? badge(true) : '<span class=\"law-badge\" style=\"background:rgba(245,158,11,0.15);color:#f59e0b;border:1px solid #f59e0b\">~ PARTIAL</span>'}\n      ${metricRow('Seeds confirmed'"
)

with open(dash_path, "w", encoding="utf-8") as f:
    f.write(src)
print(f"✓ Patched run_dashboard.py")

print("\nDone. Restart the dashboard.")
