"""
cross_dimensional.py — Cross-affective-dimension interaction metrics.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
ORCID: 0000-0002-3315-7907

Implements the D★ class of metrics: first cross-dimensional affective
interactions in the Maya series (P8 Vairagya-gated Karma pruning).
"""

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr
from typing import Optional


class CrossDimensional:
    """
    Measures interactions between affective dimensions.

    Validated against Maya P8 (D★ condition: Vairagya shields high-Karma
    synapses from Shunyata pruning).

    Parameters
    ----------
    df : pd.DataFrame
        Maya batch log DataFrame.
    """

    def __init__(self, df: pd.DataFrame, task_col: str = "task"):
        self.df = df.copy()
        self.task_col = task_col
        self._task_means = df.groupby(task_col).mean(numeric_only=True)

    def vairagya_karma_interaction(self) -> dict:
        """
        Measure the Vairagya-Karma cross-dimensional interaction (D★).

        Tests whether Vairagya protection moderates Karma-driven pruning.
        A negative correlation between Vairagya and pruned_fraction
        (after controlling for Karma level) confirms the D★ mechanism.

        Returns
        -------
        dict with correlation stats and interaction strength.
        """
        required = {"vairagya", "karma_mean", "pruned_fraction"}
        missing = required - set(self.df.columns)
        if missing:
            return {"error": f"Missing columns: {missing}"}

        tm = self._task_means
        v = tm["vairagya"].values
        k = tm["karma_mean"].values
        p = tm["pruned_fraction"].values

        r_vp, pval_vp = pearsonr(v, p)
        r_kp, pval_kp = pearsonr(k, p)
        r_vk, pval_vk = pearsonr(v, k)

        # Partial correlation: Vairagya vs pruning controlling for Karma
        # residualise both v and p on k
        def partial_r(a, b, c):
            """Partial correlation of a and b controlling for c."""
            ra = np.polyfit(c, a, 1)
            rb = np.polyfit(c, b, 1)
            res_a = a - np.polyval(ra, c)
            res_b = b - np.polyval(rb, c)
            r, p_ = pearsonr(res_a, res_b)
            return float(r), float(p_)

        partial_r_val, partial_p_val = partial_r(v, p, k)

        return {
            "vairagya_pruning_r": round(float(r_vp), 4),
            "vairagya_pruning_p": round(float(pval_vp), 4),
            "karma_pruning_r": round(float(r_kp), 4),
            "karma_pruning_p": round(float(pval_kp), 4),
            "vairagya_karma_r": round(float(r_vk), 4),
            "partial_r_vairagya_pruning_given_karma": round(partial_r_val, 4),
            "partial_p": round(partial_p_val, 4),
            "d_star_confirmed": partial_r_val < -0.5 and r_kp > 0.5,
            "interpretation": (
                f"D★ interaction {'CONFIRMED' if partial_r_val < -0.5 and r_kp > 0.5 else 'NOT detected'}. "
                f"Karma drives pruning (r={r_kp:.3f}), "
                f"Vairagya moderates it (partial_r={partial_r_val:.3f} after controlling for Karma)."
            ),
        }

    def homeostatic_cascade_score(self) -> dict:
        """
        Measure whether Bhaya events cascade globally across dimensions.

        A genuine homeostatic cascade: when Bhaya fires, it should
        simultaneously perturb Vairagya, Buddhi update rate, and confidence.
        Tests cross-dimension correlation at Bhaya-firing batches.

        Returns
        -------
        dict with cascade detection results per dimension.
        """
        if "bhaya" not in self.df.columns or "pain_fired" not in self.df.columns:
            return {"error": "Columns 'bhaya' and 'pain_fired' required."}

        fired = self.df[self.df["pain_fired"] > 0].copy()
        quiet = self.df[self.df["pain_fired"] == 0].copy()

        if len(fired) < 5:
            return {
                "cascade_detected": False,
                "n_firing_events": len(fired),
                "interpretation": "Insufficient Bhaya firing events to test cascade.",
            }

        cascade = {}
        dims = ["vairagya", "buddhi", "confidence", "lability_mean", "chitta"]
        for d in dims:
            if d in self.df.columns:
                fired_mean = float(fired[d].mean())
                quiet_mean = float(quiet[d].mean())
                delta = fired_mean - quiet_mean
                cascade[d] = {
                    "mean_during_bhaya": round(fired_mean, 4),
                    "mean_during_quiet": round(quiet_mean, 4),
                    "delta": round(delta, 4),
                    "perturbed": abs(delta) > 0.05,
                }

        n_perturbed = sum(1 for v in cascade.values() if v["perturbed"])

        return {
            "cascade_detected": n_perturbed >= 2,
            "n_firing_events": len(fired),
            "n_perturbed_dimensions": n_perturbed,
            "dimension_deltas": cascade,
            "interpretation": (
                f"Homeostatic cascade {'CONFIRMED' if n_perturbed >= 2 else 'NOT detected'}. "
                f"{n_perturbed} dimensions perturbed during {len(fired)} Bhaya firing events."
            ),
        }

    def shunyata_pruning_profile(self) -> dict:
        """
        Characterise the Shunyata pruning trajectory across tasks.

        Shunyata prunes based on Karma history, moderated by Vairagya (D★).
        pruned_fraction should grow monotonically, gated by task boundaries.
        """
        required = {"pruned_fraction", "shunyata_events"}
        missing = required - set(self.df.columns)
        if missing:
            return {"error": f"Missing columns: {missing}"}

        pf = self._task_means["pruned_fraction"].values
        se = self._task_means["shunyata_events"].values
        diffs = np.diff(pf)
        monotonic = bool(np.all(diffs >= -0.001))

        buddhi_modulation = None
        if "buddhi" in self.df.columns:
            buddhi = self._task_means["buddhi"].values
            # Buddhi-modulated threshold: base * (0.5 + buddhi * 0.5)
            effective_thresh = 0.05 * (0.5 + buddhi * 0.5)
            buddhi_modulation = [round(float(t), 4) for t in effective_thresh]

        return {
            "per_task_pruned_fraction": [round(float(v), 4) for v in pf],
            "per_task_shunyata_events": [int(v) for v in se],
            "final_pruned_fraction": round(float(pf[-1]), 4),
            "monotonic_growth": monotonic,
            "buddhi_modulated_threshold": buddhi_modulation,
            "interpretation": (
                f"Shunyata pruned {pf[-1]*100:.1f}% of network by final task. "
                f"{'Monotonic growth confirmed.' if monotonic else 'Non-monotonic — spike starvation risk.'}"
            ),
        }

    def summary(self) -> dict:
        return {
            "vairagya_karma": self.vairagya_karma_interaction(),
            "homeostatic_cascade": self.homeostatic_cascade_score(),
            "shunyata_profile": self.shunyata_pruning_profile(),
        }
