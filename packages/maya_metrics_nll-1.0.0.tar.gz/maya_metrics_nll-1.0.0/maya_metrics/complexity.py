"""
complexity.py — mPCI and LZC-based complexity metrics.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
ORCID: 0000-0002-3315-7907

Implements the depth-matched mPCI decoupler — the critical methodological
contribution of Maya-mPCI (Swaminathan, 2026, DOI: 10.5281/zenodo.19482794).

The core problem: training depth naturally hardens weights, reducing LZC
complexity independently of affective state integration. A naive mPCI
comparison conflates structural convergence with genuine affective complexity.
The decoupler subtracts the depth-matched SGD baseline curve.
"""

import numpy as np
import pandas as pd
from typing import Optional


class ComplexityMetrics:
    """
    mPCI-based complexity evaluation for affective SNN states.

    Parameters
    ----------
    mpci_df : pd.DataFrame
        mPCI summary with columns: phase, mpci_mean, mpci_std,
        delta_vs_phase1, genuine_state_signal.
    controls_df : pd.DataFrame, optional
        mPCI controls summary with columns: control, seed, metric, value.
    """

    def __init__(self, mpci_df: pd.DataFrame,
                 controls_df: Optional[pd.DataFrame] = None):
        self.mpci_df  = mpci_df.copy()
        self.controls = controls_df.copy() if controls_df is not None else None

    def phase_delta_summary(self) -> dict:
        """
        Summarise mPCI phase deltas from the three-phase protocol.

        Phase 1: Reactive baseline (affective dims off)
        Phase 2: Full Antahkarana (all 14 dims active)
        Phase 3: Bhaya Quiescence (mature stabilised state)

        The genuine affective delta = Phase1 mPCI - Phase3 mPCI.
        Significance criterion: delta > 2× std of Phase 1.
        """
        df = self.mpci_df.set_index("phase") if "phase" in self.mpci_df.columns else self.mpci_df

        phases = {}
        for _, row in self.mpci_df.iterrows():
            phases[row["phase"]] = {
                "mpci_mean": float(row["mpci_mean"]),
                "mpci_std":  float(row.get("mpci_std", 0)),
                "delta_vs_phase1": float(row.get("delta_vs_phase1", 0)),
            }

        p1 = phases.get("Phase1_Reactive", {})
        p3 = phases.get("Phase3_Quiescence", {})

        aggregate_delta = abs(p3.get("delta_vs_phase1", 0)) if p3 else None
        threshold = 2 * p1.get("mpci_std", 0.02) if p1 else 0.04
        significant = aggregate_delta > threshold if aggregate_delta else False

        genuine_signal = any(
            str(row.get("genuine_state_signal", "")).upper() == "TRUE"
            for _, row in self.mpci_df.iterrows()
        )

        return {
            "phases": phases,
            "aggregate_delta": round(aggregate_delta, 4) if aggregate_delta else None,
            "significance_threshold": round(threshold, 4),
            "significant": significant,
            "genuine_state_signal": genuine_signal,
            "interpretation": (
                f"mPCI delta = {aggregate_delta:.4f}, threshold = {threshold:.4f}. "
                f"Genuine affective state signal: {'CONFIRMED' if significant else 'NOT confirmed'}."
            ) if aggregate_delta else "Insufficient phase data.",
        }

    def depth_matched_decoupler(self) -> dict:
        """
        Isolate genuine affective complexity from training-depth hardening.

        Training depth naturally reduces mPCI as weights converge.
        Control 1 (depth-matched baseline) captures this confound.
        The decoupled signal = affective model mPCI - depth-matched baseline mPCI.

        Returns
        -------
        dict with per-seed decoupled deltas and whether affective signal
        survives after removing the convergence confound.
        """
        if self.controls is None:
            return {"error": "No controls DataFrame provided."}

        dm = self.controls[self.controls["control"] == "depth_matched"]
        if dm.empty:
            return {"error": "No depth_matched control rows found."}

        # Get affective model Phase3 mPCI
        p3_rows = self.mpci_df[self.mpci_df["phase"] == "Phase3_Quiescence"]
        if p3_rows.empty:
            return {"error": "Phase3_Quiescence not found in mpci_df."}
        affective_mpci = float(p3_rows.iloc[0]["mpci_mean"])

        seeds = dm["seed"].unique()
        results = {}
        for seed in seeds:
            seed_rows = dm[dm["seed"] == seed]
            mean_row = seed_rows[seed_rows["metric"] == "mpci_mean"]
            if mean_row.empty:
                continue
            baseline_mpci = float(mean_row.iloc[0]["value"])
            decoupled = affective_mpci - baseline_mpci
            results[int(seed)] = {
                "affective_mpci": round(affective_mpci, 4),
                "depth_matched_mpci": round(baseline_mpci, 4),
                "decoupled_delta": round(decoupled, 4),
                "affective_below_baseline": decoupled < 0,
            }

        n_confirmed = sum(1 for v in results.values() if v["affective_below_baseline"])

        return {
            "per_seed": results,
            "n_seeds_confirmed": n_confirmed,
            "n_seeds_total": len(results),
            "robust": n_confirmed == len(results),
            "interpretation": (
                f"Depth-matched decoupling: affective mPCI below baseline in "
                f"{n_confirmed}/{len(results)} seeds. "
                f"{'Genuine affective integration confirmed.' if n_confirmed == len(results) else 'Partial confirmation — check seed variance.'}"
            ),
        }

    def perturbation_scale_robustness(self) -> dict:
        """
        Assess whether the mPCI signal survives across perturbation scales.

        Control 2: delta_0.02 (high noise) should collapse;
                   delta_0.05 (moderate) should survive;
                   delta_0.1  (low)      should survive.
        This confirms the signal is structural, not noise-driven.
        """
        if self.controls is None:
            return {"error": "No controls DataFrame provided."}

        sr = self.controls[self.controls["control"] == "scale_robustness"]
        if sr.empty:
            return {"error": "No scale_robustness rows found."}

        seeds = sr["seed"].unique()
        results = {}
        for seed in seeds:
            seed_rows = sr[sr["seed"] == seed]
            seed_res = {}
            for _, row in seed_rows.iterrows():
                metric = row["metric"]
                seed_res[metric] = round(float(row["value"]), 4)
            results[int(seed)] = seed_res

        # Expected pattern: |delta_0.02| >> |delta_0.05| > |delta_0.1|
        pattern_confirmed = []
        for seed, res in results.items():
            d02 = abs(res.get("delta_0.02", 0))
            d05 = abs(res.get("delta_0.05", 0))
            d10 = abs(res.get("delta_0.1",  0))
            pattern_confirmed.append(d02 > d05 > d10)

        return {
            "per_seed": results,
            "decay_pattern_confirmed": all(pattern_confirmed),
            "interpretation": (
                "Scale robustness pattern CONFIRMED — large noise collapses signal, "
                "moderate noise preserves it. Signal is structural, not noise-driven."
                if all(pattern_confirmed) else
                "Scale robustness pattern not fully confirmed across all seeds."
            ),
        }

    def shuffle_control(self) -> dict:
        """
        Confirm that temporal structure (not firing rate) drives LZC shift.

        Control 3: shuffling the spike sequence should abolish the mPCI delta.
        original_delta < shuffle_delta confirms temporal structure matters.
        """
        if self.controls is None:
            return {"error": "No controls DataFrame provided."}

        shuf = self.controls[self.controls["control"] == "shuffle"]
        if shuf.empty:
            return {"error": "No shuffle rows found."}

        seeds = shuf["seed"].unique()
        results = {}
        for seed in seeds:
            seed_rows = shuf[shuf["seed"] == seed]
            orig = seed_rows[seed_rows["metric"] == "original_delta"]
            shuf_row = seed_rows[seed_rows["metric"] == "shuffle_delta"]
            if orig.empty or shuf_row.empty:
                continue
            orig_val = float(orig.iloc[0]["value"])
            shuf_val = float(shuf_row.iloc[0]["value"])
            results[int(seed)] = {
                "original_delta": round(orig_val, 4),
                "shuffle_delta":  round(shuf_val, 4),
                "temporal_structure_confirmed": orig_val < shuf_val,
            }

        n_confirmed = sum(1 for v in results.values()
                          if v["temporal_structure_confirmed"])

        return {
            "per_seed": results,
            "n_seeds_confirmed": n_confirmed,
            "robust": n_confirmed == len(results),
            "interpretation": (
                f"Shuffle control: temporal structure drives LZC in "
                f"{n_confirmed}/{len(results)} seeds. "
                f"{'Temporal structure CONFIRMED as mechanism.' if n_confirmed == len(results) else 'Partial — investigate seed 123 separately.'}"
            ),
        }

    def summary(self) -> dict:
        out = {"phase_delta": self.phase_delta_summary()}
        if self.controls is not None:
            out["depth_matched"] = self.depth_matched_decoupler()
            out["scale_robustness"] = self.perturbation_scale_robustness()
            out["shuffle_control"] = self.shuffle_control()
        return out
