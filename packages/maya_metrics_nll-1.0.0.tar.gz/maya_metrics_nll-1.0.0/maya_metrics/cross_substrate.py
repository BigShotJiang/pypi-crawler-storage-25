"""
cross_substrate.py — Cross-substrate mechanism invariance testing.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
ORCID: 0000-0002-3315-7907

Maya-LLM (Swaminathan, 2026, DOI: 10.5281/zenodo.19522348) confirmed
Buddhi S-curve invariance across SNN (SpikingJelly) and LLM (Phi-2/LoRA).
This module formalises that test using Dynamic Time Warping and CKA-inspired
trajectory comparison (Kornblith et al., 2019, arXiv:1905.00414).
"""

import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from typing import Optional


def _dtw_distance(a: np.ndarray, b: np.ndarray) -> float:
    """Simple O(n²) DTW distance between two 1D sequences."""
    n, m = len(a), len(b)
    dtw = np.full((n + 1, m + 1), np.inf)
    dtw[0, 0] = 0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost = abs(a[i - 1] - b[j - 1])
            dtw[i, j] = cost + min(dtw[i-1, j], dtw[i, j-1], dtw[i-1, j-1])
    return float(dtw[n, m])


class CrossSubstrate:
    """
    Test whether an affective mechanism is substrate-invariant.

    Validated against Buddhi cross-substrate invariance:
    SNN (Maya P4–P9) vs LLM (Maya-LLM, Phi-2/LoRA, TRACE benchmark).

    Parameters
    ----------
    snn_df : pd.DataFrame
        SNN batch log with 'task', 'buddhi' columns.
    llm_df : pd.DataFrame
        LLM batch log with 'step'/'domain', 'buddhi_score' columns.
    """

    def __init__(self, snn_df: pd.DataFrame, llm_df: pd.DataFrame,
                 snn_task_col: str = "task",
                 llm_task_col: str = "domain"):
        self.snn_df = snn_df.copy()
        self.llm_df = llm_df.copy()
        self.snn_task_col = snn_task_col
        self.llm_task_col = llm_task_col

    def buddhi_substrate_invariance(self) -> dict:
        """
        Test Buddhi S-curve invariance between SNN and LLM substrates.

        Method:
          1. Extract per-task Buddhi trajectory from each substrate.
          2. Normalise both to [0, 1] range (removes scale differences).
          3. Apply Dynamic Time Warping to compare trajectory shapes.
          4. DTW distance < 0.3 (normalised) = mechanism invariant.

        Returns
        -------
        dict with DTW distance, trajectory correlation, invariance verdict.
        """
        # SNN Buddhi
        if "buddhi" not in self.snn_df.columns:
            return {"error": "Column 'buddhi' not found in SNN DataFrame."}

        snn_task_means = self.snn_df.groupby(self.snn_task_col)["buddhi"].mean()
        snn_buddhi = snn_task_means.values.astype(float)

        # LLM Buddhi
        # LLM Buddhi — preserve sequential domain order via step
        llm_col = "buddhi_score" if "buddhi_score" in self.llm_df.columns else "buddhi"
        if llm_col not in self.llm_df.columns:
            return {"error": f"Column '{llm_col}' not found in LLM DataFrame."}

        llm_sorted = self.llm_df.sort_values("step") if "step" in self.llm_df.columns else self.llm_df
        llm_group_col = self.llm_task_col if self.llm_task_col in llm_sorted.columns else "step"
        if llm_group_col in llm_sorted.columns and llm_group_col != "step":
            domain_order = llm_sorted[llm_group_col].unique()
            llm_task_means = llm_sorted.groupby(llm_group_col)[llm_col].mean().reindex(domain_order)
        else:
            llm_task_means = llm_sorted.groupby(llm_group_col)[llm_col].mean()
        llm_buddhi = llm_task_means.values.astype(float)

        # Normalise to [0, 1]
        def _norm(arr):
            mn, mx = arr.min(), arr.max()
            return (arr - mn) / (mx - mn) if mx > mn else arr

        snn_norm = _norm(snn_buddhi)
        llm_norm = _norm(llm_buddhi)

        dtw_dist = _dtw_distance(snn_norm, llm_norm)
        dtw_norm = dtw_dist / max(len(snn_norm), len(llm_norm))

        # Pearson on common length
        min_len = min(len(snn_norm), len(llm_norm))
        r, p = pearsonr(snn_norm[:min_len], llm_norm[:min_len])

        invariant = dtw_norm < 0.3

        return {
            "snn_buddhi_per_task": [round(float(v), 4) for v in snn_buddhi],
            "llm_buddhi_per_domain": [round(float(v), 4) for v in llm_buddhi],
            "snn_buddhi_normalised": [round(float(v), 4) for v in snn_norm],
            "llm_buddhi_normalised": [round(float(v), 4) for v in llm_norm],
            "dtw_distance_raw": round(dtw_dist, 4),
            "dtw_distance_normalised": round(dtw_norm, 4),
            "pearson_r": round(float(r), 4),
            "pearson_p": round(float(p), 4),
            "substrate_invariant": invariant,
            "interpretation": (
                f"Buddhi cross-substrate invariance {'CONFIRMED' if invariant else 'NOT confirmed'} "
                f"(DTW_norm={dtw_norm:.3f}, r={r:.3f}). "
                + ("S-curve mechanism transcends substrate boundaries — "
                   "architectural universal confirmed."
                   if invariant else
                   "Mechanism shows substrate-dependent variation.")
            ),
        }

    def bhaya_domain_firing(self) -> dict:
        """
        Identify which LLM domains trigger Bhaya (stress-reactive domains).

        In Maya-LLM, Bhaya fired on Py150, ScienceQA, and NumGLUE-ds —
        domains with high distributional shift. This identifies the
        'threat landscape' of a continual learning deployment.
        """
        if "bhaya_firing_rate" not in self.llm_df.columns:
            bhaya_col = "bhaya_fired" if "bhaya_fired" in self.llm_df.columns else None
            if bhaya_col is None:
                return {"error": "No Bhaya column found in LLM DataFrame."}
        else:
            bhaya_col = "bhaya_firing_rate"

        group_col = self.llm_task_col if self.llm_task_col in self.llm_df.columns else "step"
        domain_bhaya = self.llm_df.groupby(group_col)[bhaya_col].mean()

        threshold = float(domain_bhaya.mean()) + float(domain_bhaya.std())
        stress_domains = [str(d) for d, v in domain_bhaya.items() if v > threshold]

        return {
            "domain_bhaya_rates": {str(k): round(float(v), 4)
                                    for k, v in domain_bhaya.items()},
            "stress_threshold": round(threshold, 4),
            "stress_reactive_domains": stress_domains,
            "n_stress_domains": len(stress_domains),
            "interpretation": (
                f"{len(stress_domains)} stress-reactive domains identified: {stress_domains}. "
                "These represent high distributional shift in the deployment stream."
                if stress_domains else
                "No domains exceed stress threshold — stable deployment stream."
            ),
        }

    def summary(self) -> dict:
        return {
            "buddhi_invariance": self.buddhi_substrate_invariance(),
            "bhaya_domain_firing": self.bhaya_domain_firing(),
        }
