"""
Tests for AffectiveMetrics — validated against Maya P9 canonical run.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
"""

import pytest
import numpy as np
import pandas as pd
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from maya_metrics import AffectiveMetrics


@pytest.fixture
def p9_df():
    """Synthetic P9-like DataFrame matching Maya series constants."""
    np.random.seed(42)
    rows = []
    for task in range(10):
        for epoch in range(20):
            for batch in range(40):
                bhaya = np.random.uniform(0.3, 0.8) if task == 0 and epoch < 3 else 0.0
                buddhi = min(1.0, 1 / (1 + np.exp(-3 * (task - 1.0))))
                vairagya = min(0.58, 0.17 + task * 0.04 + np.random.normal(0, 0.01))
                rows.append({
                    "task": task, "epoch": epoch, "batch": batch,
                    "bhaya": max(0, bhaya + np.random.normal(0, 0.01)) if task == 0 else 0.0,
                    "buddhi": max(0, min(1, buddhi + np.random.normal(0, 0.005))),
                    "vairagya": max(0, vairagya),
                    "vairagya_protection_fc1": max(0, vairagya),
                    "pain_fired": 1 if bhaya > 0.1 else 0,
                    "karma_mean": task * 0.005 + np.random.uniform(0, 0.002),
                    "prana_value": 1.0,
                    "pruned_fraction": min(0.84, max(0, (task - 4) * 0.15)),
                    "effective_lr": 0.01,
                    "confidence": np.random.uniform(0.1, 0.9),
                    "lability_mean": max(0.5, 1.2 - task * 0.07),
                    "chitta": min(0.95, max(0, task * 0.1)),
                    "manas": 0.99,
                    "manas_peak_fraction": np.random.uniform(0.35, 0.42),
                    "samskara_mean": task * 0.001,
                    "retrograde_fired": np.random.randint(0, 3),
                    "moha_fraction": 0.0,
                })
    return pd.DataFrame(rows)


def test_bhaya_quiescence_law(p9_df):
    """Bhaya must be 0 from Task 1 onwards — the series constant."""
    am = AffectiveMetrics(p9_df)
    result = am.bhaya_quiescence_score()
    assert result["law_confirmed"], (
        f"Bhaya Quiescence Law VIOLATED. replay_max={result['replay_max']}, "
        f"violation_tasks={result['violation_tasks']}"
    )
    assert result["task0_bhaya"] > 0.01, "Task 0 Bhaya should be > 0 (pre-replay)"
    assert result["quiescence_rate"] == 1.0


def test_buddhi_scurve_fit(p9_df):
    """Buddhi must fit a sigmoid with R² > 0.95."""
    am = AffectiveMetrics(p9_df)
    result = am.buddhi_scurve_fit()
    assert result["deterministic"], (
        f"Buddhi S-curve NOT confirmed. R²={result['r_squared']}"
    )
    assert result["r_squared"] > 0.95
    assert result["ceiling_task"] <= 3, "Buddhi should reach ceiling by task 3"


def test_vairagya_growth(p9_df):
    """Vairagya protection should grow across tasks."""
    am = AffectiveMetrics(p9_df)
    result = am.vairagya_saturation_fraction()
    assert result["final_protection"] > result["per_task_protection"][0]
    assert "error" not in result


def test_karma_monotonic(p9_df):
    """Karma should accumulate monotonically."""
    am = AffectiveMetrics(p9_df)
    result = am.karma_accumulation_profile()
    assert result["monotonic"], "Karma should increase monotonically"
    assert result["final_karma"] > 0


def test_prana_profile(p9_df):
    """Prana should return valid profile."""
    am = AffectiveMetrics(p9_df)
    result = am.prana_depletion_profile()
    assert "error" not in result
    assert len(result["per_task_prana"]) == 10


def test_summary_keys(p9_df):
    """Summary should contain all core keys."""
    am = AffectiveMetrics(p9_df)
    s = am.summary()
    assert "bhaya_quiescence" in s
    assert "buddhi_scurve" in s
    assert "vairagya_saturation" in s
    assert "karma_profile" in s
