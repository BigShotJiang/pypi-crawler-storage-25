"""
Tests for ComplexityMetrics — validated against Maya-mPCI data.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
"""

import pytest
import pandas as pd
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from maya_metrics import ComplexityMetrics


@pytest.fixture
def mpci_df():
    return pd.DataFrame([
        {"phase": "Phase1_Reactive",      "mpci_mean": 0.3091, "mpci_std": 0.0107,
         "baseline_lzc": 0.7474, "delta_vs_phase1": 0,       "genuine_state_signal": ""},
        {"phase": "Phase2_FullAntahkarana","mpci_mean": 0.2696, "mpci_std": 0.0074,
         "baseline_lzc": 0.7823, "delta_vs_phase1": -0.0395, "genuine_state_signal": ""},
        {"phase": "Phase3_Quiescence",    "mpci_mean": 0.2664, "mpci_std": 0.0112,
         "baseline_lzc": 0.8046, "delta_vs_phase1": -0.0427, "genuine_state_signal": "TRUE"},
    ])


@pytest.fixture
def controls_df():
    rows = []
    for seed in [42, 123, 7]:
        rows += [
            {"control": "depth_matched",    "seed": seed, "metric": "mpci_mean", "value": 0.276 + seed * 0.0001},
            {"control": "depth_matched",    "seed": seed, "metric": "mpci_std",  "value": 0.013},
            {"control": "scale_robustness", "seed": seed, "metric": "delta_0.02","value": -0.22},
            {"control": "scale_robustness", "seed": seed, "metric": "delta_0.05","value": -0.047},
            {"control": "scale_robustness", "seed": seed, "metric": "delta_0.1", "value": -0.007},
            {"control": "shuffle",          "seed": seed, "metric": "original_delta", "value": 0.065},
            {"control": "shuffle",          "seed": seed, "metric": "shuffle_delta",  "value": 0.110},
        ]
    return pd.DataFrame(rows)


def test_phase_delta_significant(mpci_df):
    cm = ComplexityMetrics(mpci_df)
    result = cm.phase_delta_summary()
    assert result["significant"], f"mPCI delta not significant: {result}"
    assert result["genuine_state_signal"] is True


def test_depth_matched_decoupler(mpci_df, controls_df):
    cm = ComplexityMetrics(mpci_df, controls_df)
    result = cm.depth_matched_decoupler()
    assert result["robust"], "Affective mPCI should be below depth-matched baseline"


def test_scale_robustness(mpci_df, controls_df):
    cm = ComplexityMetrics(mpci_df, controls_df)
    result = cm.perturbation_scale_robustness()
    assert result["decay_pattern_confirmed"]


def test_shuffle_control(mpci_df, controls_df):
    cm = ComplexityMetrics(mpci_df, controls_df)
    result = cm.shuffle_control()
    assert result["robust"], "Temporal structure should drive LZC, not firing rate"
