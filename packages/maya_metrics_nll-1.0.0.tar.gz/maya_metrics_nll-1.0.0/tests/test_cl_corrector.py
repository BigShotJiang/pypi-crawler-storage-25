"""
Tests for CLCorrector — canonical CIL metric formulations.
Nexus Learning Labs, Bengaluru — Venkatesh Swaminathan, 2026
"""

import pytest
import numpy as np
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from maya_metrics import CLCorrector


@pytest.fixture
def R():
    return np.array([
        [0.90, 0.00, 0.00],
        [0.72, 0.85, 0.00],
        [0.65, 0.78, 0.88],
    ])


def test_aa(R):
    clc = CLCorrector(R)
    aa = clc.average_accuracy()
    expected = (0.65 + 0.78 + 0.88) / 3
    assert abs(aa - expected) < 1e-6


def test_bwt(R):
    clc = CLCorrector(R)
    bwt = clc.backward_transfer()
    expected = ((0.65 - 0.90) + (0.78 - 0.85)) / 2
    assert abs(bwt - expected) < 1e-6


def test_intransigence_requires_oracle(R):
    """Intransigence MUST return None without oracle — never approximate."""
    clc = CLCorrector(R)
    assert clc.intransigence() is None, "Must refuse computation without oracle"


def test_intransigence_with_oracle(R):
    clc = CLCorrector(R)
    oracle = np.array([0.95, 0.92, 0.91])
    I = clc.intransigence(oracle)
    expected = np.mean(oracle - np.diag(R))
    assert abs(I - expected) < 1e-6


def test_fwt_zeroshot(R):
    clc = CLCorrector(R)
    fwt = clc.forward_transfer_zeroshot()
    expected = (R[0, 1] + R[1, 2]) / 2
    assert abs(fwt - expected) < 1e-6


def test_summary_structure(R):
    clc = CLCorrector(R)
    s = clc.summary()
    assert "AA_macro" in s
    assert "BWT" in s
    assert s["Intransigence"] is not None  # should be the refusal string
