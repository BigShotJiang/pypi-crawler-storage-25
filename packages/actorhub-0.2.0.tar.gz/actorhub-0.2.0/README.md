# ActorHub Python SDK

Official Python SDK for [ActorHub.ai](https://actorhub.ai) — Verify AI-generated content against protected identities.

## Installation

```bash
pip install actorhub
```

## Quick Start

```python
from actorhub import ActorHub

client = ActorHub(api_key="your-api-key")

# Check consent before AI generation
result = client.check_consent(
    platform="sora",
    intended_use="video",
    image_url="https://example.com/face.jpg",
)

if result.protected:
    face = result.faces[0]
    print(f"Protected: {face.display_name}")
    print(f"Consent: {face.consent.video_generation}")
    
    # Check if active consent token exists
    if face.token and face.token.valid:
        print(f"Active token: {face.token.source}")
    
    # Verify trust signature
    if result.trust:
        print(f"Signed: {result.trust.algorithm}")
```

## With Consent Token

```python
result = client.check_consent(
    platform="sora",
    intended_use="video",
    image_url="https://example.com/face.jpg",
    consent_token="ACT-XXXX",  # Token from identity owner
)
```

## Async Support

```python
from actorhub import AsyncActorHub

async with AsyncActorHub(api_key="your-api-key") as client:
    result = await client.check_consent(
        platform="runway",
        intended_use="video",
        image_url="https://example.com/face.jpg",
    )
```

## Links

- [Documentation](https://actorhub.ai/developers)
- [API Reference](https://api.actorhub.ai/docs)
- [Website](https://actorhub.ai)
