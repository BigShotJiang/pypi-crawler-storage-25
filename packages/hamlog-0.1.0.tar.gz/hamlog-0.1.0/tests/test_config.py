import tomllib
from pathlib import Path

from hamlog import config


def test_generate_default_config_creates_file(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    result = config.generate_default_config()
    assert result == config_path
    assert config_path.exists()
    content = config_path.read_text()
    assert "[database]" in content
    assert "[station]" in content
    assert "[tui]" in content


def test_generate_default_config_overwrites_existing(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text('[database]\npath = "old.db"')
    result = config.generate_default_config()
    assert result == config_path
    content = config_path.read_text()
    assert "old.db" not in content
    assert 'path = "hamlog.db"' in content


def test_load_settings_returns_defaults_when_missing(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    assert not config_path.exists()
    s = config.load_settings()
    assert isinstance(s, config.Settings)
    assert s.database.path == "hamlog.db"
    assert s.station.callsign == ""
    assert s.station.gridsquare == ""
    assert s.tui.zebra_stripes is True
    assert s.tui.default_frequency == ""
    assert s.tui.default_mode == ""
    assert s.tui.default_qth == ""
    assert s.tui.theme == "textual-dark"
    assert s.tui.fast_exit is False


def test_load_settings_creates_default_when_missing(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    assert not config_path.exists()
    config.load_settings()
    assert config_path.exists()


def test_load_settings_parses_valid_toml(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text("""[database]
path = "test.db"

[station]
callsign = "W1AW"
gridsquare = "FN42"

[tui]
default_frequency = "14.074"
default_mode = "FT8"
default_qth = "Boston"
theme = "nord"
fast_exit = true
zebra_stripes = false
""")
    s = config.load_settings()
    assert s.database.path == "test.db"
    assert s.station.callsign == "W1AW"
    assert s.station.gridsquare == "FN42"
    assert s.tui.zebra_stripes is False
    assert s.tui.default_frequency == "14.074"
    assert s.tui.default_mode == "FT8"
    assert s.tui.default_qth == "Boston"
    assert s.tui.theme == "nord"
    assert s.tui.fast_exit is True


def test_load_settings_invalid_toml_returns_defaults(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text("this is not valid toml {{{")
    s = config.load_settings()
    assert isinstance(s, config.Settings)
    assert s.database.path == "hamlog.db"


def test_load_settings_empty_config_returns_defaults(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text("")
    s = config.load_settings()
    assert isinstance(s, config.Settings)
    assert s.database.path == "hamlog.db"


def test_load_settings_partial_config_uses_defaults(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text("""[database]
path = "custom.db"
""")
    s = config.load_settings()
    assert s.database.path == "custom.db"
    assert s.station.callsign == ""
    assert s.tui.theme == "textual-dark"


def test_write_settings_round_trip(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    original = config.Settings(
        database={"path": "custom.db"},
        station={"callsign": "K1ABC", "gridsquare": "FN42"},
        tui={
            "default_frequency": "7.074",
            "default_mode": "CW",
            "default_qth": "Maine",
            "theme": "dracula",
            "fast_exit": True,
        },
    )
    config.write_settings(original)
    assert config_path.exists()
    data = tomllib.loads(config_path.read_text())
    assert data["database"]["path"] == "custom.db"
    assert data["station"]["callsign"] == "K1ABC"
    assert data["station"]["gridsquare"] == "FN42"
    assert data["tui"]["zebra_stripes"] is True
    assert data["tui"]["default_frequency"] == "7.074"
    assert data["tui"]["default_mode"] == "CW"
    assert data["tui"]["default_qth"] == "Maine"
    assert data["tui"]["theme"] == "dracula"
    assert data["tui"]["fast_exit"] is True


def test_write_settings_creates_parent_dir(monkeypatch, tmp_path):
    nested = tmp_path / "nested" / "subdir" / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", nested)
    assert not nested.parent.exists()
    s = config.Settings()
    config.write_settings(s)
    assert nested.exists()


def test_write_settings_then_read_back(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    original = config.Settings(
        database={"path": "roundtrip.db"},
        station={"callsign": "N0ONE", "gridsquare": "EM00"},
        tui={"theme": "catppuccin-mocha", "fast_exit": True, "zebra_stripes": False},
    )
    config.write_settings(original)
    loaded = config.load_settings()
    assert loaded.database.path == "roundtrip.db"
    assert loaded.station.callsign == "N0ONE"
    assert loaded.station.gridsquare == "EM00"
    assert loaded.tui.zebra_stripes is False
    assert loaded.tui.theme == "catppuccin-mocha"
    assert loaded.tui.fast_exit is True


def test_reload_settings_updates_global(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    old = config.settings
    try:
        config_path.write_text('[database]\npath = "first.db"')
        config.reload_settings()
        assert config.settings.database.path == "first.db"
        config_path.write_text('[database]\npath = "second.db"')
        config.reload_settings()
        assert config.settings.database.path == "second.db"
    finally:
        config.settings = old


def test_settings_default_values():
    s = config.Settings()
    assert s.database.path == "hamlog.db"
    assert s.station.callsign == ""
    assert s.station.gridsquare == ""
    assert s.tui.zebra_stripes is True
    assert s.tui.default_frequency == ""
    assert s.tui.default_mode == ""
    assert s.tui.default_qth == ""
    assert s.tui.theme == "textual-dark"
    assert s.tui.fast_exit is False


def test_settings_extra_fields_ignored():
    s = config.Settings(**{"database": {"path": "x.db"}, "unknown_section": {"a": 1}})
    assert s.database.path == "x.db"


def test_settings_fast_exit_toml_bool_parsing(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text("[tui]\nfast_exit = true\n")
    s = config.load_settings()
    assert s.tui.fast_exit is True

    config_path.write_text("[tui]\nfast_exit = false\n")
    s = config.load_settings()
    assert s.tui.fast_exit is False


def test_settings_fast_exit_written_as_toml_bool(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    s = config.Settings(tui={"fast_exit": True})
    config.write_settings(s)
    raw = config_path.read_text()
    assert "fast_exit = true" in raw
    s2 = config.Settings(tui={"fast_exit": False})
    config.write_settings(s2)
    raw = config_path.read_text()
    assert "fast_exit = false" in raw


def test_settings_zebra_stripes_defaults():
    s = config.Settings()
    assert s.tui.zebra_stripes is True


def test_settings_zebra_stripes_toml_bool_parsing(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text("[tui]\nzebra_stripes = true\n")
    s = config.load_settings()
    assert s.tui.zebra_stripes is True

    config_path.write_text("[tui]\nzebra_stripes = false\n")
    s = config.load_settings()
    assert s.tui.zebra_stripes is False


def test_settings_zebra_stripes_written_as_toml_bool(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    s = config.Settings(tui={"zebra_stripes": True})
    config.write_settings(s)
    raw = config_path.read_text()
    assert "zebra_stripes = true" in raw
    s2 = config.Settings(tui={"zebra_stripes": False})
    config.write_settings(s2)
    raw = config_path.read_text()
    assert "zebra_stripes = false" in raw


def test_zebra_stripes_in_default_config(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config.generate_default_config()
    content = config_path.read_text()
    assert "zebra_stripes = true" in content


def test_load_settings_parses_zebra_stripes_in_tui(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(config, "CONFIG_PATH", config_path)
    config_path.write_text("[tui]\nzebra_stripes = false\n")
    s = config.load_settings()
    assert s.tui.zebra_stripes is False


def test_concrete_path_is_a_path(tmp_path):
    assert isinstance(config.CONFIG_PATH, Path)


def test_concrete_path_is_absolute(tmp_path):
    assert config.CONFIG_PATH.is_absolute()
