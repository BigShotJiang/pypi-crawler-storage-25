import os
import tempfile
from decimal import Decimal
import pytest
from sqlalchemy import select, func
from hamlog.band import load_bands, lookup_band, auto_load_bands
import hamlog.db
from hamlog.models import Band


SAMPLE_CSV = """\
"Enumeration Name","Band","Lower Freq (MHz)","Upper Freq (MHz)","Import-only","Comments","ADIF Version","ADIF Status"
"Band","2190m",".1357",".1378","","","3.1.7","Released"
"Band","160m","1.8","2.0","","","3.1.7","Released"
"Band","80m","3.5","4.0","","","3.1.7","Released"
"Band","40m","7.0","7.3","","","3.1.7","Released"
"Band","20m","14.0","14.35","","","3.1.7","Released"
"Band","10m","28.0","29.7","","","3.1.7","Released"
"Band","2m","144","148","","","3.1.7","Released"
"Band","70cm","420","450","","","3.1.7","Released"
"Band","importonly","1.0","2.0","Y","","3.1.7","Released"
"""


def _write_csv(content: str) -> str:
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(content)
        return f.name


@pytest.mark.asyncio
async def test_load_bands(temp_db):
    path = _write_csv(SAMPLE_CSV)
    try:
        count = await load_bands(path)
        assert count == 8
        async with hamlog.db.async_session_maker() as db:
            result = await db.execute(select(Band).order_by(Band.lower_freq))
            bands = result.scalars().all()
        assert len(bands) == 8
        assert bands[0].name == "2190m"
        assert bands[0].lower_freq == Decimal("0.1357")
        assert bands[0].upper_freq == Decimal("0.1378")
        assert bands[4].name == "20m"
        assert bands[4].lower_freq == Decimal("14.0")
        assert bands[4].upper_freq == Decimal("14.35")
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_load_bands_empty_csv(temp_db):
    csv_content = '"Enumeration Name","Band","Lower Freq (MHz)","Upper Freq (MHz)","Import-only","Comments","ADIF Version","ADIF Status"\n'
    path = _write_csv(csv_content)
    try:
        count = await load_bands(path)
        assert count == 0
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_lookup_band_matches(temp_db):
    path = _write_csv(SAMPLE_CSV)
    try:
        await load_bands(path)

        assert await lookup_band(14.074) == "20m"
        assert await lookup_band(14.0) == "20m"
        assert await lookup_band(14.35) == "20m"
        assert await lookup_band(3.5) == "80m"
        assert await lookup_band(4.0) == "80m"
        assert await lookup_band(145.0) == "2m"
        assert await lookup_band(0.1357) == "2190m"
        assert await lookup_band(0.1378) == "2190m"
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_lookup_band_no_match(temp_db):
    path = _write_csv(SAMPLE_CSV)
    try:
        await load_bands(path)
        assert await lookup_band(100.0) is None
        assert await lookup_band(0.001) is None
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_load_bands_idempotent(temp_db):
    path = _write_csv(SAMPLE_CSV)
    try:
        count1 = await load_bands(path)
        assert count1 == 8
        count2 = await load_bands(path)
        assert count2 == 8
        async with hamlog.db.async_session_maker() as db:
            result = await db.execute(select(func.count()).select_from(Band))
            count = result.scalar()
        assert count == 8
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_auto_load_bands_empty(temp_db):
    count = await auto_load_bands()
    assert count == 0


@pytest.mark.asyncio
async def test_auto_load_bands_skips_when_loaded(temp_db):
    path = _write_csv(SAMPLE_CSV)
    try:
        await load_bands(path)
        count = await auto_load_bands()
        assert count == 0
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_lookup_band_no_match_real_data(temp_db):
    assert await lookup_band(100.0) is None
