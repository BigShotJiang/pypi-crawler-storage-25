from decimal import Decimal
import pytest
from hamlog.logbook import (
    add_qso,
    clear_all_qsos,
    count_qsos,
    get_all_qsos,
    get_qsos_paginated,
    get_qso_statistics,
    search_qsos,
)
from hamlog.models import QSO


@pytest.mark.asyncio
async def test_add_qso(temp_db):
    """Test adding a QSO to the database."""
    qso = QSO(
        callsign="W1ABC",
        frequency=14.074,
        mode="FT8",
        start_date="2023-10-15",
        start_time="14:30:00",
        rst_sent="599",
        rst_received="599",
        notes="Test contact",
    )

    await add_qso(qso)

    qsos = await get_all_qsos()
    assert len(qsos) == 1

    retrieved = qsos[0]
    assert retrieved.callsign == "W1ABC"
    assert retrieved.frequency == Decimal("14.074")
    assert retrieved.mode == "FT8"
    assert retrieved.start_date == "2023-10-15"
    assert retrieved.start_time == "14:30:00"
    assert retrieved.rst_sent == "599"
    assert retrieved.rst_received == "599"
    assert retrieved.notes == "Test contact"
    assert retrieved.id == 1


@pytest.mark.asyncio
async def test_add_qso_with_defaults(temp_db):
    """Test adding a QSO with minimal fields (default date/time)."""
    qso = QSO(callsign="K2DEF")

    await add_qso(qso)

    qsos = await get_all_qsos()
    assert len(qsos) == 1

    retrieved = qsos[0]
    assert retrieved.callsign == "K2DEF"
    assert retrieved.frequency is None
    assert retrieved.mode is None
    assert retrieved.start_date is not None
    assert retrieved.start_time is not None
    assert retrieved.rst_sent is None
    assert retrieved.rst_received is None
    assert retrieved.notes is None
    assert retrieved.id == 1


@pytest.mark.asyncio
async def test_get_all_qsos_empty(temp_db):
    """Test getting all QSOs from empty database."""
    qsos = await get_all_qsos()
    assert qsos == []
    assert len(qsos) == 0


@pytest.mark.asyncio
async def test_get_all_qsos_multiple(temp_db):
    """Test getting all QSOs with multiple entries."""
    qso1 = QSO(callsign="W1ABC", frequency=7.074, mode="CW")
    qso2 = QSO(callsign="K2DEF", frequency=14.074, mode="FT8")
    qso3 = QSO(callsign="N3GHI", frequency=21.074, mode="SSB")

    await add_qso(qso1)
    await add_qso(qso2)
    await add_qso(qso3)

    qsos = await get_all_qsos()
    assert len(qsos) == 3

    callsigns = [qso.callsign for qso in qsos]
    assert "W1ABC" in callsigns
    assert "K2DEF" in callsigns
    assert "N3GHI" in callsigns

    ids = [qso.id for qso in qsos]
    assert ids == [3, 2, 1]


@pytest.mark.asyncio
async def test_search_qsos(temp_db):
    """Test searching QSOs by callsign pattern."""
    qso1 = QSO(callsign="W1ABC", frequency=7.074)
    qso2 = QSO(callsign="W1DEF", frequency=14.074)
    qso3 = QSO(callsign="K2ABC", frequency=21.074)
    qso4 = QSO(callsign="K2DEF", frequency=28.074)

    await add_qso(qso1)
    await add_qso(qso2)
    await add_qso(qso3)
    await add_qso(qso4)

    results = await search_qsos("W1")
    assert len(results) == 2
    callsigns = [q.callsign for q in results]
    assert "W1ABC" in callsigns
    assert "W1DEF" in callsigns
    assert "K2ABC" not in callsigns
    assert "K2DEF" not in callsigns

    results = await search_qsos("ABC")
    assert len(results) == 2
    callsigns = [q.callsign for q in results]
    assert "W1ABC" in callsigns
    assert "K2ABC" in callsigns
    assert "W1DEF" not in callsigns
    assert "K2DEF" not in callsigns

    results = await search_qsos("W1ABC")
    assert len(results) == 1
    assert results[0].callsign == "W1ABC"

    results = await search_qsos("ZZZ")
    assert len(results) == 0


@pytest.mark.asyncio
async def test_initialize_database(temp_db):
    """Test that initialize_database creates the table."""
    qso = QSO(callsign="TEST")
    await add_qso(qso)

    qsos = await get_all_qsos()
    assert len(qsos) == 1
    assert qsos[0].callsign == "TEST"


@pytest.mark.asyncio
async def test_clear_all_qsos(temp_db):
    """Test clearing all QSOs from the database."""
    qso1 = QSO(callsign="W1ABC")
    qso2 = QSO(callsign="K2DEF")
    await add_qso(qso1)
    await add_qso(qso2)

    assert len(await get_all_qsos()) == 2

    await clear_all_qsos()

    assert len(await get_all_qsos()) == 0


@pytest.mark.asyncio
async def test_get_qso_statistics_empty(temp_db):
    """Test get_qso_statistics with an empty database."""
    stats = await get_qso_statistics()
    assert stats["total_qsos"] == 0
    assert stats["unique_callsigns"] == 0
    assert stats["first_qso_date"] is None
    assert stats["last_qso_date"] is None
    assert stats["most_frequent_mode"] is None
    assert stats["most_frequent_mode_count"] == 0
    assert stats["most_frequent_frequency"] is None
    assert stats["most_frequent_frequency_count"] == 0


@pytest.mark.asyncio
async def test_get_qso_statistics_with_data(temp_db):
    """Test get_qso_statistics with various QSO data."""
    await add_qso(
        QSO(callsign="W1ABC", frequency=7.074, mode="FT8", start_date="2023-01-01")
    )
    await add_qso(
        QSO(callsign="W1ABC", frequency=7.074, mode="FT8", start_date="2023-01-02")
    )
    await add_qso(
        QSO(callsign="K2DEF", frequency=14.074, mode="SSB", start_date="2023-01-03")
    )
    await add_qso(
        QSO(callsign="N3GHI", frequency=7.074, mode="CW", start_date="2023-01-04")
    )

    stats = await get_qso_statistics()
    assert stats["total_qsos"] == 4
    assert stats["unique_callsigns"] == 3
    assert stats["first_qso_date"] == "2023-01-01"
    assert stats["last_qso_date"] == "2023-01-04"
    assert stats["most_frequent_mode"] == "FT8"
    assert stats["most_frequent_mode_count"] == 2
    assert stats["most_frequent_frequency"] == Decimal("7.074")
    assert stats["most_frequent_frequency_count"] == 3


@pytest.mark.asyncio
async def test_count_qsos_empty(temp_db):
    assert await count_qsos() == 0


@pytest.mark.asyncio
async def test_count_qsos_with_data(temp_db):
    await add_qso(QSO(callsign="W1ABC"))
    await add_qso(QSO(callsign="K2DEF"))
    assert await count_qsos() == 2


@pytest.mark.asyncio
async def test_get_qsos_paginated_returns_first_page(temp_db):
    for i in range(5):
        await add_qso(QSO(callsign=f"TEST{i}"))
    page = await get_qsos_paginated(offset=0, limit=3)
    assert len(page) == 3


@pytest.mark.asyncio
async def test_get_qsos_paginated_offset(temp_db):
    for i in range(5):
        await add_qso(QSO(callsign=f"TEST{i}"))
    page2 = await get_qsos_paginated(offset=3, limit=3)
    assert len(page2) == 2


@pytest.mark.asyncio
async def test_get_qsos_paginated_empty(temp_db):
    page = await get_qsos_paginated(offset=0, limit=10)
    assert page == []


@pytest.mark.asyncio
async def test_get_qsos_paginated_ordering(temp_db):
    await add_qso(QSO(callsign="C", start_date="2023-01-03"))
    await add_qso(QSO(callsign="B", start_date="2023-01-02"))
    await add_qso(QSO(callsign="A", start_date="2023-01-01"))
    page = await get_qsos_paginated(offset=0, limit=10)
    assert [q.callsign for q in page] == ["C", "B", "A"]
