import os
import tempfile
from decimal import Decimal

import pytest
from hamlog.adif import (
    parse_adif_content,
    adif_to_qso,
    qso_to_adif,
    export_adif,
    import_adif_async,
)
from hamlog.models import QSO
from hamlog.logbook import add_qso, clear_all_qsos, get_all_qsos


SAMPLE_ADIF = """ADIF Export from HamLog
<EOH>
<CALL:5>W1ABC <FREQ:6>14.074 <MODE:3>FT8 <QSO_DATE:8>20231015 <TIME_ON:6>143000 <RST_SENT:3>599 <RST_RCVD:3>599 <COMMENT:12>Test contact <EOR>
<CALL:5>K2DEF <FREQ:6>7.074 <MODE:2>CW <QSO_DATE:8>20231016 <TIME_ON:6>150000 <EOR>
"""


def test_parse_adif():
    records = parse_adif_content(SAMPLE_ADIF)
    assert len(records) == 2

    assert records[0]["CALL"] == "W1ABC"
    assert records[0]["FREQ"] == "14.074"
    assert records[0]["MODE"] == "FT8"
    assert records[0]["QSO_DATE"] == "20231015"
    assert records[0]["TIME_ON"] == "143000"
    assert records[0]["RST_SENT"] == "599"
    assert records[0]["RST_RCVD"] == "599"
    assert records[0]["COMMENT"] == "Test contact"

    assert records[1]["CALL"] == "K2DEF"
    assert records[1]["FREQ"] == "7.074"
    assert records[1]["MODE"] == "CW"
    assert records[1]["QSO_DATE"] == "20231016"
    assert records[1]["TIME_ON"] == "150000"


def test_parse_adif_empty():
    records = parse_adif_content("")
    assert records == []


def test_parse_adif_no_eor():
    records = parse_adif_content("<CALL:5>W1ABC ")
    assert records == []


def test_adif_to_qso():
    data = {
        "CALL": "W1ABC",
        "FREQ": "14.074",
        "MODE": "FT8",
        "QTH": "New York",
        "QSO_DATE": "20231015",
        "TIME_ON": "143000",
        "RST_SENT": "599",
        "RST_RCVD": "599",
        "COMMENT": "Test contact",
    }
    qso = adif_to_qso(data)
    assert qso.callsign == "W1ABC"
    assert qso.frequency == Decimal("14.074")
    assert qso.mode == "FT8"
    assert qso.qth == "New York"
    assert qso.start_date == "2023-10-15"
    assert qso.start_time == "14:30:00"
    assert qso.rst_sent == "599"
    assert qso.rst_received == "599"
    assert qso.comment == "Test contact"


def test_adif_to_qso_minimal():
    data = {"CALL": "K2DEF"}
    qso = adif_to_qso(data)
    assert qso.callsign == "K2DEF"
    assert qso.frequency is None
    assert qso.mode is None
    assert qso.qth is None
    assert qso.start_date is None
    assert qso.start_time is None


def test_adif_to_qso_invalid_frequency():
    data = {"CALL": "W1ABC", "FREQ": "notanumber"}
    qso = adif_to_qso(data)
    assert qso.callsign == "W1ABC"
    assert qso.frequency is None


def test_adif_to_qso_no_callsign():
    data = {"MODE": "FT8"}
    qso = adif_to_qso(data)
    assert qso.callsign is None


def test_qso_to_adif():
    qso = QSO(
        callsign="W1ABC",
        frequency=14.074,
        mode="FT8",
        qth="New York",
        start_date="2023-10-15",
        start_time="14:30:00",
        rst_sent="599",
        rst_received="599",
        notes="Test contact",
    )
    result = qso_to_adif(qso)
    assert "<CALL:5>W1ABC" in result
    assert "<FREQ:6>14.074" in result
    assert "<MODE:3>FT8" in result
    assert "<QTH:8>New York" in result
    assert "<QSO_DATE:8>20231015" in result
    assert "<TIME_ON:6>143000" in result
    assert "<RST_SENT:3>599" in result
    assert "<RST_RCVD:3>599" in result
    assert "<NOTES:12>Test contact" in result
    assert result.endswith("<EOR>")


def test_qso_to_adif_minimal():
    qso = QSO(callsign="K2DEF")
    result = qso_to_adif(qso)
    assert "<CALL:5>K2DEF" in result
    assert result.endswith("<EOR>")


def test_export_adif():
    qsos = [
        QSO(callsign="W1ABC", frequency=14.074, mode="FT8"),
        QSO(callsign="K2DEF", frequency=7.074, mode="CW"),
    ]
    result = export_adif(qsos)
    assert result.startswith("ADIF Export from HamLog")
    assert "<EOH>" in result
    assert "<CALL:5>W1ABC" in result
    assert "<CALL:5>K2DEF" in result
    assert "<EOR>" in result


def test_export_adif_empty():
    result = export_adif([])
    assert result.startswith("ADIF Export from HamLog")
    assert "<EOH>" in result


def test_round_trip():
    original = QSO(
        callsign="W1ABC",
        frequency=Decimal("14.074"),
        mode="FT8",
        qth="New York",
        start_date="2023-10-15",
        start_time="14:30:00",
        rst_sent="599",
        rst_received="599",
        notes="Test contact",
    )
    adif_str = qso_to_adif(original)
    records = parse_adif_content(adif_str)
    assert len(records) == 1
    parsed = adif_to_qso(records[0])
    assert parsed.callsign == original.callsign
    assert parsed.frequency == original.frequency
    assert parsed.mode == original.mode
    assert parsed.qth == original.qth
    assert parsed.start_date == original.start_date
    assert parsed.start_time == original.start_time
    assert parsed.rst_sent == original.rst_sent
    assert parsed.rst_received == original.rst_received
    assert parsed.notes == original.notes


def test_round_trip_big_frequency():
    """Test ADIF round-trip of a high-precision frequency value."""
    freq = Decimal("3733506.051187")
    original = QSO(callsign="W1ABC", frequency=freq)
    adif_str = qso_to_adif(original)
    records = parse_adif_content(adif_str)
    assert len(records) == 1
    parsed = adif_to_qso(records[0])
    assert parsed.frequency == freq


@pytest.mark.asyncio
async def test_import_adif(temp_db):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".adi", delete=False) as f:
        f.write(SAMPLE_ADIF)
        f.flush()
        path = f.name

    try:
        r = await import_adif_async(path)
        assert r["total"] == 2
        qsos = await get_all_qsos()
        assert len(qsos) == 2
        callsigns = {qso.callsign for qso in qsos}
        assert "W1ABC" in callsigns
        assert "K2DEF" in callsigns
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_import_adif_empty_file(temp_db):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".adi", delete=False) as f:
        f.write("<EOH>\n<EOR>\n")
        f.flush()
        path = f.name

    try:
        r = await import_adif_async(path)
        assert r["total"] == 0
    finally:
        os.unlink(path)


def test_eoh_not_in_records():
    adif = "<EOH>\n<CALL:5>W1ABC <EOR>\n"
    records = parse_adif_content(adif)
    assert len(records) == 1
    assert "EOH" not in records[0]
    assert records[0]["CALL"] == "W1ABC"


def test_parse_adif_real_file():
    with open("log202605.adi") as f:
        content = f.read()
    records = parse_adif_content(content)
    assert len(records) == 13
    assert "EOH" not in records[0]
    for record in records:
        assert "CALL" in record
        assert "MODE" in record
        assert "QSO_DATE" in record


def test_adif_to_qso_with_new_fields():
    data = {
        "CALL": "W1ABC",
        "FREQ": "14.074",
        "MODE": "FT8",
        "GRIDSQUARE": "FN42",
        "BAND": "20m",
        "QSO_DATE": "20231015",
        "TIME_ON": "143000",
        "QSO_DATE_OFF": "20231015",
        "TIME_OFF": "143500",
        "STATION_CALLSIGN": "W1XYZ",
        "MY_GRIDSQUARE": "FN31",
        "RST_SENT": "-11",
        "RST_RCVD": "0",
        "COMMENT": "Test QSO",
    }
    qso = adif_to_qso(data)
    assert qso.callsign == "W1ABC"
    assert qso.frequency == Decimal("14.074")
    assert qso.mode == "FT8"
    assert qso.gridsquare == "FN42"
    assert qso.band == "20m"
    assert qso.start_date == "2023-10-15"
    assert qso.start_time == "14:30:00"
    assert qso.qso_date_off == "2023-10-15"
    assert qso.time_off == "14:35:00"
    assert qso.station_callsign == "W1XYZ"
    assert qso.my_gridsquare == "FN31"
    assert qso.rst_sent == "-11"
    assert qso.rst_received == "0"
    assert qso.comment == "Test QSO"


def test_adif_to_qso_empty_gridsquare():
    data = {"CALL": "W1ABC", "GRIDSQUARE": ""}
    qso = adif_to_qso(data)
    assert qso.callsign == "W1ABC"
    assert qso.gridsquare == ""


def test_round_trip_with_new_fields():
    original = QSO(
        callsign="W1ABC",
        frequency=Decimal("14.074"),
        mode="FT8",
        gridsquare="FN42",
        band="20m",
        start_date="2023-10-15",
        start_time="14:30:00",
        qso_date_off="2023-10-15",
        time_off="14:35:00",
        station_callsign="W1XYZ",
        my_gridsquare="FN31",
        rst_sent="-11",
        rst_received="0",
        notes="Test QSO",
    )
    adif_str = qso_to_adif(original)
    records = parse_adif_content(adif_str)
    assert len(records) == 1
    parsed = adif_to_qso(records[0])
    assert parsed.callsign == original.callsign
    assert parsed.frequency == original.frequency
    assert parsed.mode == original.mode
    assert parsed.gridsquare == original.gridsquare
    assert parsed.band == original.band
    assert parsed.start_date == original.start_date
    assert parsed.start_time == original.start_time
    assert parsed.qso_date_off == original.qso_date_off
    assert parsed.time_off == original.time_off
    assert parsed.station_callsign == original.station_callsign
    assert parsed.my_gridsquare == original.my_gridsquare
    assert parsed.rst_sent == original.rst_sent
    assert parsed.rst_received == original.rst_received
    assert parsed.notes == original.notes


@pytest.mark.asyncio
async def test_import_real_adif_file(temp_db):
    r = await import_adif_async("log202605.adi")
    assert r["total"] == 13
    qsos = await get_all_qsos()
    assert len(qsos) == 13
    callsigns = {qso.callsign for qso in qsos}
    assert "RP81SIE" in callsigns
    assert "W1YY" in callsigns

    w1yy = next(q for q in qsos if q.callsign == "W1YY")
    assert w1yy.gridsquare == "CN87"
    assert w1yy.band == "20m"
    assert w1yy.station_callsign == "R8ADR/P"
    assert w1yy.my_gridsquare == "MO05"
    assert w1yy.rst_sent == "-6"
    assert w1yy.rst_received == "-16"


@pytest.mark.asyncio
async def test_export_adif_with_data(temp_db):
    await add_qso(QSO(callsign="W1ABC", frequency=14.074, mode="FT8"))
    await add_qso(QSO(callsign="K2DEF", frequency=7.074, mode="CW"))
    qsos = await get_all_qsos()
    content = export_adif(qsos)
    assert "<CALL:5>W1ABC" in content
    assert "<CALL:5>K2DEF" in content


@pytest.mark.asyncio
async def test_export_adif_empty_db(temp_db):
    qsos = await get_all_qsos()
    content = export_adif(qsos)
    assert content.startswith("ADIF Export from HamLog")
    assert "<EOH>" in content


@pytest.mark.asyncio
async def test_export_then_import_roundtrip(temp_db):
    await import_adif_async("log202605.adi")

    qsos = await get_all_qsos()
    content = export_adif(qsos)

    await clear_all_qsos()

    records = parse_adif_content(content)
    assert len(records) == 13

    for record in records:
        qso = adif_to_qso(record)
        if qso.callsign:
            await add_qso(qso)

    qsos = await get_all_qsos()
    assert len(qsos) == 13


@pytest.mark.asyncio
async def test_import_real_file_reimport_roundtrip(temp_db):
    await import_adif_async("log202605.adi")
    qsos = await get_all_qsos()
    content = export_adif(qsos)
    await clear_all_qsos()
    records = parse_adif_content(content)
    for record in records:
        qso = adif_to_qso(record)
        if qso.callsign:
            await add_qso(qso)
    qsos = await get_all_qsos()
    assert len(qsos) == 13


def test_adif_to_qso_name_column():
    data = {"CALL": "W1ABC", "NAME": "John"}
    qso = adif_to_qso(data)
    assert qso.name == "John"


def test_adif_to_qso_all_new_dedicated_columns():
    data = {
        "CALL": "W1ABC",
        "QSL_RCVD": "Y",
        "QSL_SENT": "Y",
        "QSL_RDATE": "20231015",
        "QSL_SDATE": "20231016",
        "LOTW_QSL_RCVD": "Y",
        "LOTW_QSL_SENT": "N",
        "LOTW_QSL_RDATE": "20231017",
        "LOTW_QSL_SDATE": "20231018",
        "EQSL_QSL_RCVD": "V",
        "EQSL_QSL_SENT": "I",
        "TX_PWR": "100",
        "RX_PWR": "5",
        "SUBMODE": "USB",
        "PROP_MODE": "F2",
        "SOTA_REF": "W6/NC-123",
        "MY_SOTA_REF": "G/SC-001",
        "POTA_REF": "US-1234",
        "MY_POTA_REF": "US-5678",
        "DXCC": "291",
        "CQZ": "5",
        "ITUZ": "8",
        "CONT": "NA",
        "COUNTRY": "United States",
        "STATE": "CA",
        "CONTEST_ID": "ARRL-FIELD-DAY",
        "STX": "1A",
        "SRX": "2B",
        "RIG": "IC-7300",
    }
    qso = adif_to_qso(data)
    assert qso.callsign == "W1ABC"
    assert qso.qsl_rcvd == "Y"
    assert qso.qsl_sent == "Y"
    assert qso.qsl_rdate == "2023-10-15"
    assert qso.qsl_sdate == "2023-10-16"
    assert qso.lotw_qsl_rcvd == "Y"
    assert qso.lotw_qsl_sent == "N"
    assert qso.lotw_qsl_rdate == "2023-10-17"
    assert qso.lotw_qsl_sdate == "2023-10-18"
    assert qso.eqsl_qsl_rcvd == "V"
    assert qso.eqsl_qsl_sent == "I"
    assert qso.tx_pwr == 100.0
    assert qso.rx_pwr == 5.0
    assert qso.submode == "USB"
    assert qso.prop_mode == "F2"
    assert qso.sota_ref == "W6/NC-123"
    assert qso.my_sota_ref == "G/SC-001"
    assert qso.pota_ref == "US-1234"
    assert qso.my_pota_ref == "US-5678"
    assert qso.dxcc == 291
    assert qso.cqz == 5
    assert qso.ituz == 8
    assert qso.cont == "NA"
    assert qso.country == "United States"
    assert qso.state == "CA"
    assert qso.contest_id == "ARRL-FIELD-DAY"
    assert qso.stx == "1A"
    assert qso.srx == "2B"
    assert qso.rig == "IC-7300"


def test_round_trip_with_dedicated_columns():
    original = QSO(
        callsign="W1ABC",
        frequency=Decimal("14.074"),
        mode="FT8",
        qsl_rcvd="Y",
        qsl_sent="Y",
        qsl_rdate="2023-10-15",
        qsl_sdate="2023-10-16",
        tx_pwr=Decimal("100.0"),
        submode="USB",
        sota_ref="W6/NC-123",
        dxcc=291,
        cqz=5,
        cont="NA",
        contest_id="ARRL-FIELD-DAY",
        stx="1A",
        srx="2B",
        name="John",
        rig="IC-7300",
    )
    adif_str = qso_to_adif(original)
    records = parse_adif_content(adif_str)
    assert len(records) == 1
    parsed = adif_to_qso(records[0])
    assert parsed.callsign == original.callsign
    assert parsed.frequency == original.frequency
    assert parsed.mode == original.mode
    assert parsed.qsl_rcvd == original.qsl_rcvd
    assert parsed.qsl_sent == original.qsl_sent
    assert parsed.qsl_rdate == original.qsl_rdate
    assert parsed.qsl_sdate == original.qsl_sdate
    assert parsed.tx_pwr == original.tx_pwr
    assert parsed.submode == original.submode
    assert parsed.sota_ref == original.sota_ref
    assert parsed.dxcc == original.dxcc
    assert parsed.cqz == original.cqz
    assert parsed.cont == original.cont
    assert parsed.contest_id == original.contest_id
    assert parsed.stx == original.stx
    assert parsed.srx == original.srx
    assert parsed.name == original.name
    assert parsed.rig == original.rig


def test_round_trip_with_adif_data_json():
    adif_input = "<CALL:5>W1ABC <FREQ:6>14.074 <MODE:3>FT8 <MY_ANTENNA:6>dipole <QSL_VIA:4>buro <EOR>"
    records = parse_adif_content(adif_input)
    assert len(records) == 1
    qso = adif_to_qso(records[0])
    assert qso.callsign == "W1ABC"
    assert qso.frequency == Decimal("14.074")
    assert qso.mode == "FT8"
    assert qso.adif_data is not None

    adif_output = qso_to_adif(qso)
    records2 = parse_adif_content(adif_output)
    assert len(records2) == 1
    parsed = adif_to_qso(records2[0])
    assert parsed.callsign == qso.callsign
    assert parsed.frequency == qso.frequency
    assert parsed.mode == qso.mode
    assert parsed.adif_data is not None

    import json

    extra = json.loads(parsed.adif_data)
    assert extra.get("MY_ANTENNA") == "dipole"
    assert extra.get("QSL_VIA") == "buro"


def test_round_trip_mixed_dedicated_and_json():
    adif_input = (
        "<CALL:5>W1ABC <FREQ:6>14.074 <MODE:3>FT8 "
        "<NAME:4>John <QSL_RCVD:1>Y <MY_ANTENNA:6>dipole "
        "<QSL_VIA:4>buro <EOR>"
    )
    records = parse_adif_content(adif_input)
    assert len(records) == 1
    qso = adif_to_qso(records[0])
    assert qso.name == "John"
    assert qso.qsl_rcvd == "Y"

    adif_output = qso_to_adif(qso)
    assert "<NAME:4>John" in adif_output
    assert "<QSL_RCVD:1>Y" in adif_output
    assert "<MY_ANTENNA:6>dipole" in adif_output
    assert "<QSL_VIA:4>buro" in adif_output
