import asyncio
import os
import tempfile

import pytest
from click.testing import CliRunner
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy.pool import NullPool

import hamlog.config
import hamlog.db
from hamlog.cli import cli


@pytest.fixture
def runner():
    """Provide a Click CLI runner."""
    return CliRunner()


@pytest.fixture
def temp_db_file():
    """Create a temporary database file for CLI testing.

    Uses async engine internally but fixtures runs synchronously
    via asyncio.run(). CLI commands use asyncio.run() internally
    so this is compatible.
    """
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        temp_db_path = f.name

    original_db_name = hamlog.db.DATABASE_NAME
    original_url = hamlog.db.DATABASE_URL
    original_engine = hamlog.db.engine
    original_session_maker = hamlog.db.async_session_maker

    hamlog.db.DATABASE_NAME = temp_db_path
    hamlog.db.DATABASE_URL = f"sqlite+aiosqlite:///{temp_db_path}"

    engine = create_async_engine(hamlog.db.DATABASE_URL, echo=False, poolclass=NullPool)
    hamlog.db.engine = engine
    hamlog.db.async_session_maker = async_sessionmaker(engine, expire_on_commit=False)

    from hamlog.logbook import initialize_database

    asyncio.run(initialize_database())

    yield temp_db_path

    asyncio.run(engine.dispose())
    hamlog.db.DATABASE_NAME = original_db_name
    hamlog.db.DATABASE_URL = original_url
    hamlog.db.engine = original_engine
    hamlog.db.async_session_maker = original_session_maker
    try:
        os.unlink(temp_db_path)
    except OSError:
        pass


def test_cli_help(runner):
    """Test CLI help command."""
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "Run the HamLog application" in result.output
    assert "Commands:" in result.output
    assert "initdb" in result.output
    assert "loadbands" in result.output
    assert "add" in result.output
    assert "list" in result.output
    assert "search" in result.output


def test_cli_help_subcommand(runner):
    """Test that 'hamlog help' works like 'hamlog --help'."""
    result = runner.invoke(cli, ["help"])
    assert result.exit_code == 0
    assert "Run the HamLog application" in result.output
    assert "Commands:" in result.output
    assert "loadbands" in result.output


def test_cli_initconfig_creates_file(runner, monkeypatch, tmp_path):
    """Test initconfig command creates a default config file."""
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(hamlog.config, "CONFIG_PATH", config_path)
    assert not config_path.exists()
    result = runner.invoke(cli, ["initconfig"])
    assert result.exit_code == 0
    assert "Config created at" in result.output
    assert config_path.exists()
    content = config_path.read_text()
    assert "[database]" in content
    assert "[station]" in content
    assert "[tui]" in content


def test_cli_initconfig_output_shows_path(runner, monkeypatch, tmp_path):
    """Test initconfig output includes the config file path."""
    config_path = tmp_path / "config.toml"
    monkeypatch.setattr(hamlog.config, "CONFIG_PATH", config_path)
    result = runner.invoke(cli, ["initconfig"])
    assert result.exit_code == 0
    assert str(config_path) in result.output


def test_cli_initdb(runner, temp_db_file):
    """Test initdb command."""
    result = runner.invoke(cli, ["initdb"])
    assert result.exit_code == 0
    assert "Database initialized." in result.output


def test_cli_add_qso(runner, temp_db_file):
    """Test add command with all options."""
    result = runner.invoke(
        cli,
        [
            "add",
            "--callsign",
            "W1ABC",
            "--frequency",
            "14.074",
            "--mode",
            "FT8",
            "--qth",
            "New York",
            "--date",
            "2023-10-15",
            "--time",
            "14:30:00",
            "--rst-sent",
            "599",
            "--rst-received",
            "599",
            "--notes",
            "Test contact",
        ],
    )

    assert result.exit_code == 0
    assert "QSO with W1ABC added." in result.output


def test_cli_add_qso_with_qth(runner, temp_db_file):
    """Test add command specifically with QTH option."""
    result = runner.invoke(cli, ["add", "--callsign", "K2DEF", "--qth", "California"])
    assert result.exit_code == 0
    assert "QSO with K2DEF added." in result.output


def test_cli_list_with_qth(runner, temp_db_file):
    """Test list command displays QTH."""
    runner.invoke(cli, ["add", "--callsign", "W1ABC", "--qth", "New York"])
    result = runner.invoke(cli, ["list"])
    assert result.exit_code == 0
    assert "QTH: New York" in result.output


def test_cli_add_qso_minimal(runner, temp_db_file):
    """Test add command with only required callsign."""
    result = runner.invoke(cli, ["add", "--callsign", "K2DEF"])

    assert result.exit_code == 0
    assert "QSO with K2DEF added." in result.output


def test_cli_add_qso_missing_callsign(runner, temp_db_file):
    """Test add command fails without required callsign."""
    result = runner.invoke(cli, ["add"])
    assert result.exit_code != 0
    assert "Error" in result.output
    assert "callsign" in result.output.lower()


def test_cli_list_empty(runner, temp_db_file):
    """Test list command with empty database."""
    result = runner.invoke(cli, ["list"])
    assert result.exit_code == 0
    assert "No QSOs in the log yet." in result.output


def test_cli_list_with_qsos(runner, temp_db_file):
    """Test list command with QSOs in database."""
    runner.invoke(
        cli,
        [
            "add",
            "--callsign",
            "W1ABC",
            "--frequency",
            "14.074",
            "--mode",
            "FT8",
            "--date",
            "2023-10-15",
            "--time",
            "14:30:00",
        ],
    )

    result = runner.invoke(cli, ["list"])
    assert result.exit_code == 0
    assert "--- HamLog QSOs ---" in result.output
    assert "W1ABC" in result.output
    assert "14.074" in result.output
    assert "FT8" in result.output
    assert "2023-10-15" in result.output
    assert "14:30:00" in result.output


def test_cli_search_found(runner, temp_db_file):
    """Test search command that finds QSOs."""
    runner.invoke(cli, ["add", "--callsign", "W1ABC"])
    runner.invoke(cli, ["add", "--callsign", "W1DEF"])
    runner.invoke(cli, ["add", "--callsign", "K2ABC"])

    result = runner.invoke(cli, ["search", "--callsign", "W1"])
    assert result.exit_code == 0
    assert '--- HamLog QSOs matching "W1" ---' in result.output
    assert "W1ABC" in result.output
    assert "W1DEF" in result.output
    assert "K2ABC" not in result.output


def test_cli_search_not_found(runner, temp_db_file):
    """Test search command that finds no QSOs."""
    runner.invoke(cli, ["add", "--callsign", "W1ABC"])

    result = runner.invoke(cli, ["search", "--callsign", "ZZZ"])
    assert result.exit_code == 0
    assert 'No QSOs found matching "ZZZ".' in result.output


def test_cli_search_missing_callsign(runner, temp_db_file):
    """Test search command fails without required callsign."""
    result = runner.invoke(cli, ["search"])
    assert result.exit_code != 0
    assert "Error" in result.output
    assert "callsign" in result.output.lower()


def test_cli_clean(runner, temp_db_file):
    """Test clean command with confirmation."""
    runner.invoke(cli, ["add", "--callsign", "W1ABC"])

    result = runner.invoke(cli, ["clean"], input="y\n")
    assert result.exit_code == 0
    assert "All QSOs have been cleared." in result.output

    result = runner.invoke(cli, ["list"])
    assert "No QSOs in the log yet." in result.output


def test_cli_clean_aborted(runner, temp_db_file):
    """Test clean command when confirmation is declined."""
    runner.invoke(cli, ["add", "--callsign", "W1ABC"])

    result = runner.invoke(cli, ["clean"], input="n\n")
    assert result.exit_code != 0
    assert "Aborted!" in result.output

    result = runner.invoke(cli, ["list"])
    assert "W1ABC" in result.output


def test_cli_stats_empty(runner, temp_db_file):
    """Test stats command with an empty database."""
    result = runner.invoke(cli, ["stats"])
    assert result.exit_code == 0
    assert "--- QSO Statistics ---" in result.output
    assert "Total QSOs: 0" in result.output
    assert "Unique Callsigns: 0" in result.output
    assert "First QSO Date: N/A" in result.output
    assert "Last QSO Date: N/A" in result.output
    assert "Most Frequent Mode: N/A" in result.output
    assert "Most Frequent Frequency: N/A" in result.output


def test_cli_stats_with_data(runner, temp_db_file):
    """Test stats command with data in the database."""
    runner.invoke(
        cli,
        [
            "add",
            "--callsign",
            "W1ABC",
            "--frequency",
            "7.074",
            "--mode",
            "FT8",
            "--date",
            "2023-01-01",
        ],
    )
    runner.invoke(
        cli,
        [
            "add",
            "--callsign",
            "W1ABC",
            "--frequency",
            "7.074",
            "--mode",
            "FT8",
            "--date",
            "2023-01-02",
        ],
    )
    runner.invoke(
        cli,
        [
            "add",
            "--callsign",
            "K2DEF",
            "--frequency",
            "14.074",
            "--mode",
            "SSB",
            "--date",
            "2023-01-03",
        ],
    )
    runner.invoke(
        cli,
        [
            "add",
            "--callsign",
            "N3GHI",
            "--frequency",
            "7.074",
            "--mode",
            "CW",
            "--date",
            "2023-01-04",
        ],
    )

    result = runner.invoke(cli, ["stats"])
    assert result.exit_code == 0
    assert "--- QSO Statistics ---" in result.output
    assert "Total QSOs: 4" in result.output
    assert "Unique Callsigns: 3" in result.output
    assert "First QSO Date: 2023-01-01" in result.output
    assert "Last QSO Date: 2023-01-04" in result.output
    assert "Most Frequent Mode: FT8 (2 QSOs)" in result.output
    assert "Most Frequent Frequency: 7.074MHz (3 QSOs)" in result.output
