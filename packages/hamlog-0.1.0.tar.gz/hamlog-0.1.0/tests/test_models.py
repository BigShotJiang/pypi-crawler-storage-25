from decimal import Decimal
import pytest
from hamlog.logbook import add_qso, get_all_qsos
from hamlog.models import QSO


def test_qso_creation():
    """Test basic QSO object creation."""
    qso = QSO(
        callsign="W1ABC",
        frequency=14.074,
        mode="FT8",
        start_date="2023-10-15",
        start_time="14:30:00",
        rst_sent="599",
        rst_received="599",
        notes="Test contact",
        id=1,
    )

    assert qso.callsign == "W1ABC"
    assert qso.frequency == 14.074
    assert qso.mode == "FT8"
    assert qso.start_date == "2023-10-15"
    assert qso.start_time == "14:30:00"
    assert qso.rst_sent == "599"
    assert qso.rst_received == "599"
    assert qso.notes == "Test contact"
    assert qso.id == 1


def test_qso_creation_minimal():
    """Test QSO creation with minimal fields."""
    qso = QSO(callsign="K2DEF")

    assert qso.callsign == "K2DEF"
    assert qso.frequency is None
    assert qso.mode is None
    assert qso.start_date is None
    assert qso.start_time is None
    assert qso.rst_sent is None
    assert qso.rst_received is None
    assert qso.notes is None
    assert qso.id is None


def test_qso_repr():
    """Test QSO string representation."""
    qso = QSO(callsign="W1ABC")
    assert repr(qso) == "<QSO W1ABC>"


@pytest.mark.asyncio
async def test_qso_big_frequency_roundtrip(temp_db):
    """Test storing and retrieving a QSO with a high-precision frequency."""
    freq = Decimal("3733506.051187")
    qso = QSO(callsign="W1ABC", frequency=freq)
    await add_qso(qso)
    qsos = await get_all_qsos()
    assert len(qsos) == 1
    assert qsos[0].frequency == freq
