import pytest
from sqlalchemy import inspect
import hamlog.db


@pytest.mark.asyncio
async def test_init_db_creates_table(temp_db):
    """Test that init_db creates the qsos table."""

    def _inspect(conn):
        inspector = inspect(conn)
        tables = inspector.get_table_names()
        assert "qsos" in tables
        assert "bands" in tables
        columns = [col["name"] for col in inspector.get_columns("qsos")]
        expected_columns = [
            "id",
            "callsign",
            "frequency",
            "mode",
            "qth",
            "start_date",
            "start_time",
            "rst_sent",
            "rst_received",
            "notes",
            "comment",
            "gridsquare",
            "qso_date_off",
            "time_off",
            "band",
            "station_callsign",
            "my_gridsquare",
            "qsl_rcvd",
            "qsl_sent",
            "qsl_rdate",
            "qsl_sdate",
            "lotw_qsl_rcvd",
            "lotw_qsl_sent",
            "lotw_qsl_rdate",
            "lotw_qsl_sdate",
            "eqsl_qsl_rcvd",
            "eqsl_qsl_sent",
            "eqsl_qsl_rdate",
            "eqsl_qsl_sdate",
            "tx_pwr",
            "rx_pwr",
            "submode",
            "prop_mode",
            "sota_ref",
            "my_sota_ref",
            "pota_ref",
            "my_pota_ref",
            "dxcc",
            "cqz",
            "ituz",
            "cont",
            "country",
            "state",
            "contest_id",
            "stx",
            "srx",
            "name",
            "rig",
            "adif_data",
        ]
        for col in expected_columns:
            assert col in columns

    async with hamlog.db.engine.connect() as conn:
        await conn.run_sync(_inspect)
