import pytest
from textual.widgets import DataTable, Input
from textual_autocomplete import AutoComplete
from hamlog.config import CONFIG_PATH, settings
from hamlog.tui import (
    AddQsoModal,
    ConfirmExitModal,
    EditQsoModal,
    HamLogApp,
    SettingsModal,
)
from hamlog.tui.app import PAGE_SIZE
import hamlog.db
from hamlog.logbook import add_qso
from hamlog.models import QSO


async def _bulk_add_qsos(count: int) -> list[QSO]:
    """Insert QSO rows efficiently using bulk INSERT."""
    qsos = [QSO(callsign=f"BULK{i:04d}") for i in range(count)]
    async with hamlog.db.async_session_maker() as db:
        for qso in qsos:
            db.add(qso)
        await db.commit()
    return qsos


@pytest.mark.asyncio
async def test_app_mount(temp_db):
    """Test that the app mounts and the table is present."""
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert app.query_one(DataTable) is not None
        assert app.query_one(DataTable).row_count == 0


@pytest.mark.asyncio
async def test_add_qso_flow(temp_db):
    """Test the flow of adding a QSO via the modal."""
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        # Press 'a' to open the Add QSO modal
        await pilot.press("a")

        # Check if modal is present
        assert isinstance(app.screen, AddQsoModal)

        # Fill in the callsign via AutoComplete
        await pilot.click("#autocomplete-input")
        await pilot.press(*"K1ABC")

        # Fill in other fields (clear first in case settings pre-filled them)
        modal = app.screen
        modal.query_one("#frequency", Input).value = ""
        await pilot.click("#frequency")
        await pilot.press(*"14.074")
        await pilot.pause()
        modal.query_one("#mode", Input).value = ""
        await pilot.click("#mode")
        await pilot.press(*"FT8")
        await pilot.pause()
        modal.query_one("#qth", Input).value = ""
        await pilot.click("#qth")
        await pilot.press(*"New York")
        await pilot.pause()

        # Press the 'Add' button
        await pilot.click("#add_btn")

        # Modal should be dismissed and table updated
        await pilot.pause()
        assert not isinstance(app.screen, AddQsoModal)
        table = app.query_one(DataTable)
        assert table.row_count == 1

        # Check if the data is correct in the table
        row_data = table.get_row_at(0)
        assert "K1ABC" in [str(cell) for cell in row_data]
        assert "14.074" in [str(cell) for cell in row_data]
        assert "FT8" in [str(cell) for cell in row_data]
        assert "New York" in [str(cell) for cell in row_data]


@pytest.mark.asyncio
async def test_add_qso_shortcut_flow(temp_db):
    """Test a new QSO can be added using Ctrl+S shortcut."""
    app = HamLogApp()
    async with app.run_test() as pilot:
        # Open Add QSO modal
        await pilot.press("a")

        # Fill in the callsign
        await pilot.click("#autocomplete-input")
        await pilot.press(*"K1HOT")

        # Press Ctrl+S to save
        await pilot.press("ctrl+s")
        await pilot.pause()

        # Modal should be dismissed and table updated
        assert not isinstance(app.screen, AddQsoModal)
        table = app.query_one(DataTable)
        assert table.row_count == 1

        row_data = table.get_row_at(0)
        assert "K1HOT" in [str(cell) for cell in row_data]


@pytest.mark.asyncio
async def test_edit_qso_flow(temp_db):
    """Test the flow of editing a QSO via the table."""
    # Seed the database
    await add_qso(QSO(callsign="K1ABC", frequency=14.074, mode="FT8"))

    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        # Ensure table is loaded
        await pilot.pause()
        table = app.query_one(DataTable)

        # Select the first row
        await pilot.click(table)
        await pilot.press("enter")
        await pilot.pause()

        # Check if Edit modal is present
        assert isinstance(app.screen, EditQsoModal)
        modal = app.screen

        # Change callsign and frequency
        input_widget = modal.query_one("#autocomplete-input", Input)
        input_widget.value = ""
        await pilot.click("#autocomplete-input")
        await pilot.press(*"W1AW")

        freq_widget = modal.query_one("#frequency", Input)
        freq_widget.value = ""
        await pilot.click("#frequency")
        await pilot.press(*"21.000")

        await pilot.pause()
        await pilot.click("#save_btn")
        await pilot.pause()

        # Should return to main screen and table should be updated
        assert not isinstance(app.screen, EditQsoModal)
        row_data = table.get_row_at(0)
        assert "W1AW" in [str(cell) for cell in row_data]
        assert "21" in [str(cell) for cell in row_data]


@pytest.mark.asyncio
async def test_edit_qso_cursor_position(temp_db):
    """Test that the cursor remains on the edited row after saving."""
    # Seed the database with multiple QSOs
    await add_qso(QSO(callsign="K1AAA", frequency=14.000, mode="SSB"))
    await add_qso(QSO(callsign="K2BBB", frequency=21.000, mode="CW"))
    await add_qso(QSO(callsign="K3CCC", frequency=28.000, mode="FT8"))

    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)

        # Select the second row (index 1)
        await pilot.click(table)
        # Move cursor to second row if necessary (pilot.click might not be enough for cursor)
        table.cursor_coordinate = (1, 0)
        await pilot.press("enter")
        await pilot.pause()

        # Edit the QSO
        await pilot.click("#save_btn")
        await pilot.pause()
        await pilot.pause()

        # Verify cursor is still on the second row
        # In some Textual test versions, maybe we need more pauses or a different check
        # But we expect table.cursor_row to be 1
        assert table.cursor_row == 1


@pytest.mark.asyncio
async def test_ctrl_q_opens_confirm_modal(temp_db):
    """Test that Ctrl+Q opens the confirm exit modal."""
    settings.tui.fast_exit = False
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.press("ctrl+q")
        assert isinstance(app.screen, ConfirmExitModal)


@pytest.mark.asyncio
async def test_ctrl_q_yes_exits(temp_db):
    """Test that clicking Yes in the confirm modal exits the app."""
    settings.tui.fast_exit = False
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.press("ctrl+q")
        assert isinstance(app.screen, ConfirmExitModal)
        await pilot.click("#yes_btn")
        await pilot.pause()
        assert not app._running


@pytest.mark.asyncio
async def test_ctrl_q_no_dismisses(temp_db):
    """Test that clicking No in the confirm modal returns to main screen."""
    settings.tui.fast_exit = False
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.press("ctrl+q")
        assert isinstance(app.screen, ConfirmExitModal)
        await pilot.click("#no_btn")
        await pilot.pause()
        assert not isinstance(app.screen, ConfirmExitModal)


@pytest.mark.asyncio
async def test_ctrl_q_escape_dismisses(temp_db):
    """Test that pressing Escape in the confirm modal returns to main screen."""
    settings.tui.fast_exit = False
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.press("ctrl+q")
        assert isinstance(app.screen, ConfirmExitModal)
        await pilot.press("escape")
        await pilot.pause()
        assert not isinstance(app.screen, ConfirmExitModal)


@pytest.mark.asyncio
async def test_ctrl_q_fast_exit_skips_modal(temp_db):
    """Test that with fast_exit=True, Ctrl+Q exits immediately."""
    settings.tui.fast_exit = True
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.press("ctrl+q")
        await pilot.pause()
        assert not app._running
    settings.tui.fast_exit = False


@pytest.mark.asyncio
async def test_default_theme_is_textual_dark(temp_db):
    """Test that the default theme is textual-dark."""
    old_theme = settings.tui.theme
    settings.tui.theme = "textual-dark"
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert app.theme == "textual-dark"
    settings.tui.theme = old_theme


@pytest.mark.asyncio
async def test_set_theme_dracula(temp_db):
    """Test that setting theme to dracula applies correctly."""
    old_theme = settings.tui.theme
    settings.tui.theme = "dracula"
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert app.theme == "dracula"
    settings.tui.theme = old_theme


@pytest.mark.asyncio
async def test_theme_backward_compat_dark(temp_db):
    """Test that old 'dark' value maps to 'textual-dark'."""
    old_theme = settings.tui.theme
    settings.tui.theme = "dark"
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert app.theme == "textual-dark"
    settings.tui.theme = old_theme


@pytest.mark.asyncio
async def test_theme_backward_compat_light(temp_db):
    """Test that old 'light' value maps to 'textual-light'."""
    old_theme = settings.tui.theme
    settings.tui.theme = "light"
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert app.theme == "textual-light"
    settings.tui.theme = old_theme


@pytest.mark.asyncio
async def test_o_opens_settings_modal(temp_db):
    """Test that pressing 'o' opens the settings modal."""
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.press("o")
        assert isinstance(app.screen, SettingsModal)


@pytest.mark.asyncio
async def test_settings_escape_dismisses(temp_db):
    """Test that Escape in settings modal returns to main screen."""
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.press("o")
        assert isinstance(app.screen, SettingsModal)
        await pilot.press("escape")
        await pilot.pause()
        assert not isinstance(app.screen, SettingsModal)


@pytest.mark.asyncio
async def test_settings_cancel_dismisses(temp_db):
    """Test that Cancel button dismisses settings modal."""
    app = HamLogApp()
    async with app.run_test(size=(80, 60)) as pilot:
        await pilot.press("o")
        assert isinstance(app.screen, SettingsModal)
        await pilot.click("#cancel_btn")
        await pilot.pause()
        assert not isinstance(app.screen, SettingsModal)


@pytest.mark.asyncio
async def test_settings_save_writes_config(temp_db):
    """Test that saving settings writes to the config file."""
    old_path = settings.database.path
    old_callsign = settings.station.callsign
    old_theme = settings.tui.theme
    old_fast_exit = settings.tui.fast_exit
    try:
        settings.database.path = "from_modal.db"
        settings.tui.theme = "nord"
        settings.tui.fast_exit = True
        app = HamLogApp()
        async with app.run_test(size=(80, 60)) as pilot:
            await pilot.press("o")
            assert isinstance(app.screen, SettingsModal)
            await pilot.press("ctrl+s")
            await pilot.pause()
            assert not isinstance(app.screen, SettingsModal)
            content = CONFIG_PATH.read_text()
            assert "path = 'from_modal.db'" in content
            assert "theme = 'nord'" in content
            assert "fast_exit = true" in content
    finally:
        settings.database.path = old_path
        settings.station.callsign = old_callsign
        settings.tui.theme = old_theme
        settings.tui.fast_exit = old_fast_exit


@pytest.mark.asyncio
async def test_settings_ctrl_s_saves(temp_db):
    """Test that Ctrl+S saves changed settings."""
    old_callsign = settings.station.callsign
    try:
        settings.station.callsign = "K1ABC"
        app = HamLogApp()
        async with app.run_test(size=(80, 40)) as pilot:
            await pilot.press("o")
            assert isinstance(app.screen, SettingsModal)
            modal = app.screen
            modal.query_one("#station_callsign", Input).value = "W2XYZ"
            await pilot.press("ctrl+s")
            await pilot.pause()
            assert not isinstance(app.screen, SettingsModal)
            assert "callsign = 'W2XYZ'" in CONFIG_PATH.read_text()
    finally:
        settings.station.callsign = old_callsign


async def _seed_ac_data():
    """Seed QSOs so AutoComplete has callsigns to match."""
    await add_qso(QSO(callsign="K1ABC", frequency=14.074, mode="FT8"))
    await add_qso(QSO(callsign="K1XYZ", frequency=7.074, mode="CW"))
    await add_qso(QSO(callsign="W1AW", frequency=3.550, mode="SSB"))


@pytest.mark.asyncio
async def test_autocomplete_hides_on_blur(temp_db):
    """Test dropdown hides when the input loses focus."""
    await _seed_ac_data()
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.press("a")
        assert isinstance(app.screen, AddQsoModal)
        modal = app.screen
        await pilot.click("#autocomplete-input")
        await pilot.press(*"K1")
        await pilot.pause()
        ac = modal.query_one(AutoComplete)
        assert ac.styles.display == "block"
        await pilot.click("#frequency")
        await pilot.pause()
        assert ac.styles.display == "none"


@pytest.mark.asyncio
async def test_autocomplete_down_selects_second(temp_db):
    """Test pressing down + Enter selects the second item (wrapping from None)."""
    await _seed_ac_data()
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.press("a")
        assert isinstance(app.screen, AddQsoModal)
        modal = app.screen
        await pilot.click("#autocomplete-input")
        await pilot.press(*"K1")
        await pilot.pause()
        ac = modal.query_one(AutoComplete)
        assert ac.styles.display == "block"
        await pilot.press("down")
        await pilot.pause()
        await pilot.press("enter")
        await pilot.pause()
        input_val = modal.query_one("#autocomplete-input", Input).value
        assert input_val == "K1XYZ"


@pytest.mark.asyncio
async def test_autocomplete_down_twice_wraps_to_first(temp_db):
    """Test pressing down twice wraps to the first item."""
    await _seed_ac_data()
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.press("a")
        assert isinstance(app.screen, AddQsoModal)
        modal = app.screen
        await pilot.click("#autocomplete-input")
        await pilot.press(*"K1")
        await pilot.pause()
        await pilot.press("down")
        await pilot.pause()
        await pilot.press("down")
        await pilot.pause()
        await pilot.press("enter")
        await pilot.pause()
        input_val = modal.query_one("#autocomplete-input", Input).value
        assert input_val == "K1ABC"


@pytest.mark.asyncio
async def test_autocomplete_up_down_round_trip(temp_db):
    """Test up from first wraps to last, down from last wraps to first."""
    await _seed_ac_data()
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.press("a")
        assert isinstance(app.screen, AddQsoModal)
        modal = app.screen
        await pilot.click("#autocomplete-input")
        await pilot.press(*"K1")
        await pilot.pause()
        await pilot.press("up")
        await pilot.pause()
        await pilot.press("enter")
        await pilot.pause()
        input_val = modal.query_one("#autocomplete-input", Input).value
        assert input_val == "K1XYZ"


@pytest.mark.asyncio
async def test_autocomplete_down_does_nothing_when_hidden(temp_db):
    """Test pressing down when dropdown is hidden does nothing."""
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.press("a")
        assert isinstance(app.screen, AddQsoModal)
        modal = app.screen
        await pilot.click("#autocomplete-input")
        await pilot.press("down")
        await pilot.pause()
        ac = modal.query_one(AutoComplete)
        assert ac.styles.display == "none"


@pytest.mark.asyncio
async def test_load_data_under_page_size(temp_db):
    """All QSOs load immediately when fewer than PAGE_SIZE."""
    await _bulk_add_qsos(5)
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        assert table.row_count == 5
        assert len(app._qsos_cache) == 5


@pytest.mark.asyncio
async def test_load_data_over_page_size_loads_all(temp_db):
    """All rows eventually load even when total exceeds PAGE_SIZE."""
    total = PAGE_SIZE + 10
    await _bulk_add_qsos(total)
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        assert table.row_count == total


@pytest.mark.asyncio
async def test_qsos_cache_eventually_complete_after_pagination(temp_db):
    """_qsos_cache contains all QSOs after loading finishes."""
    total = PAGE_SIZE + 10
    await _bulk_add_qsos(total)
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert len(app._qsos_cache) == total


@pytest.mark.asyncio
async def test_edit_qso_from_cache_when_fully_loaded(temp_db):
    """Editing works via cache when QSO is already loaded."""
    await _bulk_add_qsos(3)
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        table.cursor_coordinate = (0, 0)
        await pilot.press("enter")
        await pilot.pause()
        assert isinstance(app.screen, EditQsoModal)


@pytest.mark.asyncio
async def test_tab_moves_to_next_column(temp_db):
    """Pressing Tab moves cursor to the next column."""
    await _bulk_add_qsos(1)
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        table.cursor_coordinate = (0, 0)
        await pilot.press("tab")
        assert table.cursor_column == 1


@pytest.mark.asyncio
async def test_tab_on_last_col_advances_to_next_row(temp_db):
    """Pressing Tab on the last column advances to the first column of the next row."""
    await _bulk_add_qsos(2)
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        last_col = len(table.columns) - 1
        table.cursor_coordinate = (0, last_col)
        await pilot.press("tab")
        assert table.cursor_coordinate == (1, 0)


@pytest.mark.asyncio
async def test_tab_last_col_last_row_stays(temp_db):
    """Pressing Tab on the last column of the last row does nothing."""
    await _bulk_add_qsos(1)
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        last_col = len(table.columns) - 1
        table.cursor_coordinate = (0, last_col)
        await pilot.press("tab")
        assert table.cursor_coordinate == (0, last_col)


@pytest.mark.asyncio
async def test_shift_tab_moves_to_previous_column(temp_db):
    """Pressing Shift+Tab moves cursor to the previous column."""
    await _bulk_add_qsos(1)
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        table.cursor_coordinate = (0, 3)
        await pilot.press("shift+tab")
        assert table.cursor_column == 2


@pytest.mark.asyncio
async def test_shift_tab_on_first_col_goes_to_prev_row(temp_db):
    """Pressing Shift+Tab on the first column goes to the last column of the previous row."""
    await _bulk_add_qsos(2)
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        last_col = len(table.columns) - 1
        table.cursor_coordinate = (1, 0)
        await pilot.press("shift+tab")
        assert table.cursor_coordinate == (0, last_col)


@pytest.mark.asyncio
async def test_shift_tab_first_col_first_row_stays(temp_db):
    """Pressing Shift+Tab on the first column of the first row does nothing."""
    await _bulk_add_qsos(1)
    app = HamLogApp()
    async with app.run_test(size=(80, 40)) as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        table.cursor_coordinate = (0, 0)
        await pilot.press("shift+tab")
        assert table.cursor_coordinate == (0, 0)


@pytest.mark.asyncio
async def test_tab_empty_table_does_nothing(temp_db):
    """Pressing Tab on an empty table does nothing."""
    app = HamLogApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(DataTable)
        before = table.cursor_coordinate
        await pilot.press("tab")
        assert table.cursor_coordinate == before
