import sys
from hamlog.cli import cli
from hamlog.tui import HamLogApp

if len(sys.argv) == 1:
    HamLogApp().run()
else:
    cli()
