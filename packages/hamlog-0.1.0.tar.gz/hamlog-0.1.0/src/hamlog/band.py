import csv
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select, func, delete
import hamlog.db
from hamlog.models import Band

DEFAULT_CSV = Path(__file__).parent.parent.parent / "data" / "enumerations_band.csv"


async def load_bands(filepath: str | None = None) -> int:
    path = Path(filepath) if filepath else DEFAULT_CSV
    with open(path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        bands = []
        for row in reader:
            if row.get("Import-only", "").strip():
                continue
            bands.append(
                Band(
                    name=row["Band"].strip(),
                    lower_freq=Decimal(row["Lower Freq (MHz)"].strip()),
                    upper_freq=Decimal(row["Upper Freq (MHz)"].strip()),
                )
            )
    async with hamlog.db.async_session_maker() as db:
        await db.execute(delete(Band))
        for band in bands:
            db.add(band)
        await db.commit()
    return len(bands)


async def lookup_band(frequency: Decimal) -> str | None:
    async with hamlog.db.async_session_maker() as db:
        stmt = (
            select(Band)
            .where(Band.lower_freq <= frequency, Band.upper_freq >= frequency)
            .order_by(Band.lower_freq)
            .limit(1)
        )
        result = await db.execute(stmt)
        band = result.scalar_one_or_none()
        return band.name if band else None


async def auto_load_bands() -> int:
    async with hamlog.db.async_session_maker() as db:
        result = await db.execute(select(func.count()).select_from(Band))
        count = result.scalar()
    if count > 0:
        return 0
    try:
        return await load_bands()
    except FileNotFoundError:
        return 0
