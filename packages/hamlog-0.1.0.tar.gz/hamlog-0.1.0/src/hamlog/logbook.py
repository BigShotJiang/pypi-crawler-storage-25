from sqlalchemy import func, select, update, delete
import hamlog.db
from hamlog.models import QSO
from datetime import datetime


async def add_qso(qso):
    async with hamlog.db.async_session_maker() as db:
        qso.callsign = qso.callsign.upper()
        now = datetime.now()
        qso.start_date = qso.start_date or now.strftime("%Y-%m-%d")
        qso.start_time = qso.start_time or now.strftime("%H:%M:%S")
        db.add(qso)
        await db.commit()


async def get_all_qsos():
    async with hamlog.db.async_session_maker() as db:
        stmt = select(QSO).order_by(QSO.start_date.desc(), QSO.start_time.desc())
        result = await db.execute(stmt)
        return result.scalars().all()


async def count_qsos() -> int:
    async with hamlog.db.async_session_maker() as db:
        result = await db.execute(select(func.count(QSO.id)))
        return result.scalar()


async def get_qsos_paginated(offset: int = 0, limit: int = 50) -> list[QSO]:
    async with hamlog.db.async_session_maker() as db:
        stmt = (
            select(QSO)
            .order_by(QSO.start_date.desc(), QSO.start_time.desc())
            .offset(offset)
            .limit(limit)
        )
        result = await db.execute(stmt)
        return result.scalars().all()


async def get_unique_callsigns():
    async with hamlog.db.async_session_maker() as db:
        stmt = select(QSO.callsign).distinct().order_by(QSO.callsign.asc())
        result = await db.execute(stmt)
        return result.scalars().all()


async def clear_all_qsos():
    async with hamlog.db.async_session_maker() as db:
        stmt = delete(QSO)
        await db.execute(stmt)
        await db.commit()


async def get_qso_statistics():
    async with hamlog.db.async_session_maker() as db:
        total_qsos = (await db.execute(select(func.count(QSO.id)))).scalar()
        unique_callsigns = (
            await db.execute(select(func.count(func.distinct(QSO.callsign))))
        ).scalar()
        dates = (
            await db.execute(select(func.min(QSO.start_date), func.max(QSO.start_date)))
        ).fetchone()
        first_qso_date, last_qso_date = dates
        mode_stmt = (
            select(QSO.mode, func.count(QSO.id).label("count"))
            .where(QSO.mode.is_not(None))
            .group_by(QSO.mode)
            .order_by(func.count(QSO.id).desc())
            .limit(1)
        )
        mode_row = (await db.execute(mode_stmt)).fetchone()
        most_frequent_mode = mode_row[0] if mode_row else None
        most_frequent_mode_count = mode_row[1] if mode_row else 0
        freq_stmt = (
            select(QSO.frequency, func.count(QSO.id).label("count"))
            .where(QSO.frequency.is_not(None))
            .group_by(QSO.frequency)
            .order_by(func.count(QSO.id).desc())
            .limit(1)
        )
        freq_row = (await db.execute(freq_stmt)).fetchone()
        most_frequent_frequency = freq_row[0] if freq_row else None
        most_frequent_frequency_count = freq_row[1] if freq_row else 0
        return {
            "total_qsos": total_qsos,
            "unique_callsigns": unique_callsigns,
            "first_qso_date": first_qso_date,
            "last_qso_date": last_qso_date,
            "most_frequent_mode": most_frequent_mode,
            "most_frequent_mode_count": most_frequent_mode_count,
            "most_frequent_frequency": most_frequent_frequency,
            "most_frequent_frequency_count": most_frequent_frequency_count,
        }


async def search_qsos(callsign_pattern):
    async with hamlog.db.async_session_maker() as db:
        stmt = select(QSO).where(QSO.callsign.like(f"%{callsign_pattern}%"))
        result = await db.execute(stmt)
        return result.scalars().all()


async def update_qso(qso_id, **kwargs):
    async with hamlog.db.async_session_maker() as db:
        if "callsign" in kwargs:
            kwargs["callsign"] = kwargs["callsign"].upper()
        stmt = update(QSO).where(QSO.id == qso_id).values(**kwargs)
        await db.execute(stmt)
        await db.commit()


async def initialize_database():
    await hamlog.db.init_db()
    from hamlog.band import auto_load_bands

    await auto_load_bands()
