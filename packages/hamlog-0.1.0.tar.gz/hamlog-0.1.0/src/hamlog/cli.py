import asyncio

import click
from hamlog.adif import export_adif, import_adif
from hamlog.config import generate_default_config
from hamlog.logbook import (
    add_qso,
    clear_all_qsos,
    get_all_qsos,
    get_qso_statistics,
    initialize_database,
    search_qsos,
)
from hamlog.models import QSO


def _run(coro):
    return asyncio.run(coro)


@click.group()
def cli():
    """Run the HamLog application."""
    pass


@cli.command()
@click.pass_context
def help(ctx):
    """Show this help message and exit."""
    click.echo(ctx.parent.get_help())


@cli.command()
def initconfig():
    """Generate default config file."""
    path = generate_default_config()
    click.echo(f"Config created at {path}")


@cli.command()
def initdb():
    """Initialize the database"""
    _run(initialize_database())
    click.echo("Database initialized.")


@cli.command()
@click.option(
    "--file",
    default=None,
    type=click.Path(exists=True, readable=True),
    help="Path to band CSV file (default: data/enumerations_band.csv)",
)
def loadbands(file):
    """Load band definitions from CSV into the database."""
    from hamlog.band import load_bands

    count = _run(load_bands(file))
    click.echo(f"Loaded {count} band(s).")


@cli.command()
@click.option("--callsign", required=True, help="Callsign of the station contacted.")
@click.option("--frequency", type=float, help="Frequency in MHz.")
@click.option("--mode", help="Operating mode (e.g., SSB, CW, FT8).")
@click.option("--qth", help="QTH of the station contacted.")
@click.option("--date", help="Date of the contact (YYYY-MM-DD). Defaults to today.")
@click.option(
    "--time", help="Time of the contact (HH:MM:SS). Defaults to current time."
)
@click.option("--rst-sent", help="RST sent.")
@click.option("--rst-received", help="RST received.")
@click.option("--notes", help="Any additional notes.")
@click.option("--gridsquare", help="Gridsquare of the station contacted.")
@click.option("--band", help="Band (e.g., 20m, 40m).")
@click.option("--tx-pwr", type=float, help="Transmit power in watts.")
@click.option("--name", help="Operator name.")
@click.option("--qsl-sent", help="QSL sent status.")
@click.option("--qsl-rcvd", help="QSL received status.")
@click.option("--contest-id", help="Contest identifier.")
@click.option("--sota-ref", help="SOTA reference.")
@click.option("--pota-ref", help="POTA reference.")
def add(
    callsign,
    frequency,
    mode,
    qth,
    date,
    time,
    rst_sent,
    rst_received,
    notes,
    gridsquare,
    band,
    tx_pwr,
    name,
    qsl_sent,
    qsl_rcvd,
    contest_id,
    sota_ref,
    pota_ref,
):
    """Add a new QSO to the log."""
    qso = QSO(
        callsign=callsign,
        frequency=frequency,
        mode=mode,
        qth=qth,
        start_date=date,
        start_time=time,
        rst_sent=rst_sent,
        rst_received=rst_received,
        notes=notes,
        gridsquare=gridsquare,
        band=band,
        tx_pwr=tx_pwr,
        name=name,
        qsl_sent=qsl_sent,
        qsl_rcvd=qsl_rcvd,
        contest_id=contest_id,
        sota_ref=sota_ref,
        pota_ref=pota_ref,
    )
    _run(add_qso(qso))
    click.echo(f"QSO with {callsign} added.")


@cli.command()
def list():
    """List all QSOs in the log."""
    qsos = _run(get_all_qsos())
    if not qsos:
        click.echo("No QSOs in the log yet.")
        return

    click.echo("--- HamLog QSOs ---")
    for qso in qsos:
        parts = [
            f"ID: {qso.id}",
            f"Callsign: {qso.callsign}",
            f"Freq: {str(qso.frequency).rstrip('0').rstrip('.')}MHz"
            if qso.frequency
            else "",
            f"Mode: {qso.mode}" if qso.mode else "",
            f"QTH: {qso.qth or 'N/A'}",
            f"Date: {qso.start_date}",
            f"Time: {qso.start_time}",
        ]
        extras = []
        if qso.band:
            extras.append(f"Band: {qso.band}")
        if qso.gridsquare:
            extras.append(f"Grid: {qso.gridsquare}")
        if qso.tx_pwr:
            extras.append(f"TX: {str(qso.tx_pwr).rstrip('0').rstrip('.')}W")
        if qso.name:
            extras.append(f"Name: {qso.name}")
        if qso.qsl_rcvd:
            extras.append(f"QSL_R: {qso.qsl_rcvd}")
        if qso.qsl_sent:
            extras.append(f"QSL_S: {qso.qsl_sent}")
        if qso.contest_id:
            extras.append(f"Contest: {qso.contest_id}")
        line = ", ".join(p for p in parts if p)
        if extras:
            line += " | " + ", ".join(extras)
        click.echo(line)
        if qso.notes:
            click.echo(f"  Notes: {qso.notes}")
    click.echo("------------------")


@cli.command()
@click.confirmation_option(prompt="Are you sure you want to clear all QSOs?")
def clean():
    """Clear all QSOs from the database."""
    _run(clear_all_qsos())
    click.echo("All QSOs have been cleared.")


@cli.command()
def stats():
    """Display statistics about the QSOs."""
    statistics = _run(get_qso_statistics())

    click.echo("--- QSO Statistics ---")
    click.echo(f"Total QSOs: {statistics['total_qsos']}")
    click.echo(f"Unique Callsigns: {statistics['unique_callsigns']}")
    click.echo(f"First QSO Date: {statistics['first_qso_date'] or 'N/A'}")
    click.echo(f"Last QSO Date: {statistics['last_qso_date'] or 'N/A'}")

    if statistics["most_frequent_mode"]:
        click.echo(
            f"Most Frequent Mode: {statistics['most_frequent_mode']} ({statistics['most_frequent_mode_count']} QSOs)"
        )
    else:
        click.echo("Most Frequent Mode: N/A")

    if statistics["most_frequent_frequency"]:
        freq_str = str(statistics["most_frequent_frequency"]).rstrip("0").rstrip(".")
        click.echo(
            f"Most Frequent Frequency: {freq_str}MHz ({statistics['most_frequent_frequency_count']} QSOs)"
        )
    else:
        click.echo("Most Frequent Frequency: N/A")
    click.echo("----------------------")


@cli.command()
@click.argument("callsign")
def find(callsign):
    """Search for QSOs by callsign."""
    qsos = _run(search_qsos(callsign))
    if not qsos:
        click.echo(f'No QSOs found matching "{callsign}".')
        return

    click.echo(f'--- HamLog QSOs matching "{callsign}" ---')
    for qso in qsos:
        parts = [
            f"ID: {qso.id}",
            f"Callsign: {qso.callsign}",
            f"Freq: {str(qso.frequency).rstrip('0').rstrip('.')}MHz"
            if qso.frequency
            else "",
            f"Mode: {qso.mode}" if qso.mode else "",
            f"QTH: {qso.qth or 'N/A'}",
            f"Date: {qso.start_date}",
            f"Time: {qso.start_time}",
        ]
        extras = []
        if qso.band:
            extras.append(f"Band: {qso.band}")
        if qso.gridsquare:
            extras.append(f"Grid: {qso.gridsquare}")
        if qso.tx_pwr:
            extras.append(f"TX: {str(qso.tx_pwr).rstrip('0').rstrip('.')}W")
        if qso.name:
            extras.append(f"Name: {qso.name}")
        if qso.qsl_rcvd:
            extras.append(f"QSL_R: {qso.qsl_rcvd}")
        if qso.qsl_sent:
            extras.append(f"QSL_S: {qso.qsl_sent}")
        if qso.contest_id:
            extras.append(f"Contest: {qso.contest_id}")
        line = ", ".join(p for p in parts if p)
        if extras:
            line += " | " + ", ".join(extras)
        click.echo(line)
        if qso.notes:
            click.echo(f"  Notes: {qso.notes}")
    click.echo("-------------------------------------")


@cli.command("import")
@click.argument("file", type=click.Path(exists=True, readable=True))
def import_(file):
    """Import QSOs from an ADIF file."""
    try:
        r = import_adif(file)
        click.echo(f"Imported {r['total']} QSO(s) from {file}.")
        click.echo(f"Calls created: {r['unique_calls']}")
        click.echo(f"Repeating calls: {r['repeating_calls']}")
        click.echo(f"Total repeated calls: {r['total_repeated']}")
    except Exception as e:
        click.echo(f"Error importing {file}: {e}", err=True)


@cli.command()
@click.argument("file", type=click.Path(writable=True))
def export(file):
    """Export all QSOs to an ADIF file."""
    qsos = _run(get_all_qsos())
    if not qsos:
        click.echo("No QSOs to export.")
        return
    content = export_adif(qsos)
    with open(file, "w") as f:
        f.write(content)
    click.echo(f"Exported {len(qsos)} QSO(s) to {file}.")


@cli.command()
@click.option("--callsign", required=True, help="Callsign pattern to search for.")
def search(callsign):
    """Search for QSOs by callsign."""
    qsos = _run(search_qsos(callsign))
    if not qsos:
        click.echo(f'No QSOs found matching "{callsign}".')
        return

    click.echo(f'--- HamLog QSOs matching "{callsign}" ---')
    for qso in qsos:
        parts = [
            f"ID: {qso.id}",
            f"Callsign: {qso.callsign}",
            f"Freq: {str(qso.frequency).rstrip('0').rstrip('.')}MHz"
            if qso.frequency
            else "",
            f"Mode: {qso.mode}" if qso.mode else "",
            f"QTH: {qso.qth or 'N/A'}",
            f"Date: {qso.start_date}",
            f"Time: {qso.start_time}",
        ]
        extras = []
        if qso.band:
            extras.append(f"Band: {qso.band}")
        if qso.gridsquare:
            extras.append(f"Grid: {qso.gridsquare}")
        if qso.tx_pwr:
            extras.append(f"TX: {str(qso.tx_pwr).rstrip('0').rstrip('.')}W")
        if qso.name:
            extras.append(f"Name: {qso.name}")
        if qso.qsl_rcvd:
            extras.append(f"QSL_R: {qso.qsl_rcvd}")
        if qso.qsl_sent:
            extras.append(f"QSL_S: {qso.qsl_sent}")
        if qso.contest_id:
            extras.append(f"Contest: {qso.contest_id}")
        line = ", ".join(p for p in parts if p)
        if extras:
            line += " | " + ", ".join(extras)
        click.echo(line)
        if qso.notes:
            click.echo(f"  Notes: {qso.notes}")
    click.echo("-------------------------------------")
