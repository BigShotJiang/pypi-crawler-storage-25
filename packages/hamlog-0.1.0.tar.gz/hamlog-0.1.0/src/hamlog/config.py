import tomllib
from pathlib import Path
from platformdirs import PlatformDirs
from pydantic import BaseModel, Field

CONFIG_PATH = PlatformDirs("hamlog", "R8ADR").user_config_path / "config.toml"

DEFAULT_CONFIG = """\
# HamLog Configuration
# Edit this file to customize your settings.

[database]
# Path to the SQLite database file (can be relative or absolute)
path = "hamlog.db"

[station]
# Your station callsign (used in ADIF export)
callsign = ""
# Your gridsquare locator (used in ADIF export)
gridsquare = ""

[tui]
# Default frequency pre-filled when adding a new QSO
default_frequency = ""
# Default mode pre-filled when adding a new QSO
default_mode = ""
# Default QTH pre-filled when adding a new QSO
default_qth = ""
# TUI theme. Built-in options: textual-dark, textual-light, nord, dracula,
# gruvbox, catppuccin-mocha, tokyo-night, monokai, solarized-light,
# solarized-dark, rose-pine, rose-pine-moon, rose-pine-dawn, atom-one-dark,
# atom-one-light, ansi-dark, ansi-light, flexoki, catppuccin-latte,
# catppuccin-frappe, catppuccin-macchiato
theme = "textual-dark"
# Skip exit confirmation dialog (Ctrl+Q exits immediately)
fast_exit = false
# Enable alternating row colors in the QSO table
zebra_stripes = true
"""


class DatabaseConfig(BaseModel):
    path: str = "hamlog.db"


class StationConfig(BaseModel):
    callsign: str = ""
    gridsquare: str = ""


class TuiConfig(BaseModel):
    default_frequency: str = ""
    default_mode: str = ""
    default_qth: str = ""
    theme: str = "textual-dark"
    fast_exit: bool = False
    zebra_stripes: bool = True


class Settings(BaseModel):
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    station: StationConfig = Field(default_factory=StationConfig)
    tui: TuiConfig = Field(default_factory=TuiConfig)


def generate_default_config() -> Path:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(DEFAULT_CONFIG)
    return CONFIG_PATH


def load_settings() -> Settings:
    if not CONFIG_PATH.exists():
        generate_default_config()
    try:
        data = tomllib.loads(CONFIG_PATH.read_text())
        return Settings(**data)
    except Exception:
        return Settings()


def reload_settings() -> None:
    global settings
    settings = load_settings()


def write_settings(s: Settings) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        f"""[database]
path = {s.database.path!r}

[station]
callsign = {s.station.callsign!r}
gridsquare = {s.station.gridsquare!r}

[tui]
default_frequency = {s.tui.default_frequency!r}
default_mode = {s.tui.default_mode!r}
default_qth = {s.tui.default_qth!r}
theme = {s.tui.theme!r}
fast_exit = {str(s.tui.fast_exit).lower()}
zebra_stripes = {str(s.tui.zebra_stripes).lower()}
"""
    )


settings = load_settings()
