from decimal import Decimal, InvalidOperation
from textual import work
from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label
from hamlog.band import lookup_band
from hamlog.config import Settings, settings, write_settings
from hamlog.logbook import (
    add_qso,
    get_qso_statistics,
    get_unique_callsigns,
    update_qso,
)
from hamlog.models import QSO
from textual_autocomplete import AutoComplete, DropdownItem

COLUMN_TO_WIDGET = {
    3: "#autocomplete-input",
    4: "#frequency",
    5: "#mode",
    8: "#qth",
    9: "#band",
    10: "#gridsquare",
    11: "#name",
}


class AddQsoModal(ModalScreen):
    """Modal screen to add a new QSO."""

    BINDINGS = [
        ("escape", "dismiss_modal", "Close"),
        ("ctrl+s", "save_qso", "Save"),
    ]

    def compose(self) -> ComposeResult:
        with Container(classes="modal-box") as container:
            container.border_title = "Add New QSO"
            text_input = Input(placeholder="Callsign", id="autocomplete-input")
            yield text_input
            yield AutoComplete(
                target=text_input,
                candidates=[],
                prevent_default_tab=False,
            )
            yield Input(placeholder="Frequency", id="frequency")
            yield Input(placeholder="Mode", id="mode")
            with Horizontal(classes="rst-row"):
                yield Input(placeholder="RST/S", id="rst_sent")
                yield Input(placeholder="RST/R", id="rst_received")
            yield Input(placeholder="QTH", id="qth")
            yield Input(placeholder="Gridsquare", id="gridsquare")
            yield Input(placeholder="Band", id="band")
            yield Input(placeholder="TX Power (W)", id="tx_pwr")
            yield Input(placeholder="Name", id="name")
            with Horizontal(id="button-container"):
                yield Button("Add", id="add_btn")
                yield Button("Cancel", id="cancel_btn")

    def on_mount(self) -> None:
        if settings.tui.default_frequency:
            self.query_one("#frequency", Input).value = settings.tui.default_frequency
        if settings.tui.default_mode:
            self.query_one("#mode", Input).value = settings.tui.default_mode
        if settings.tui.default_qth:
            self.query_one("#qth", Input).value = settings.tui.default_qth
        self.query_one("#autocomplete-input", Input).focus()
        self._load_candidates()

    @work
    async def _load_candidates(self) -> None:
        callsigns = await get_unique_callsigns()
        ac = self.query_one(AutoComplete)
        ac.candidates = [DropdownItem(main=c) for c in callsigns]

    async def _auto_fill_band(self) -> None:
        freq_raw = self.query_one("#frequency", Input).value
        try:
            freq = Decimal(freq_raw)
        except InvalidOperation:
            return
        band_name = await lookup_band(freq)
        if band_name:
            self.query_one("#band", Input).value = band_name

    async def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "frequency":
            await self._auto_fill_band()

    def action_dismiss_modal(self) -> None:
        self.dismiss(False)

    def action_save_qso(self) -> None:
        self.query_one("#add_btn").press()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "add_btn":
            callsign = self.query_one("#autocomplete-input", Input).value
            freq = self.query_one("#frequency", Input).value
            mode = self.query_one("#mode", Input).value
            qth = self.query_one("#qth", Input).value
            if callsign:
                try:
                    frequency_val = Decimal(freq) if freq else None
                except ValueError:
                    frequency_val = None
                try:
                    tx_pwr_val = (
                        Decimal(self.query_one("#tx_pwr", Input).value)
                        if self.query_one("#tx_pwr", Input).value
                        else None
                    )
                except ValueError:
                    tx_pwr_val = None
                await add_qso(
                    QSO(
                        callsign=callsign,
                        frequency=frequency_val,
                        mode=mode,
                        rst_sent=self.query_one("#rst_sent", Input).value or None,
                        rst_received=self.query_one("#rst_received", Input).value
                        or None,
                        qth=qth,
                        gridsquare=self.query_one("#gridsquare", Input).value or None,
                        band=self.query_one("#band", Input).value or None,
                        tx_pwr=tx_pwr_val,
                        name=self.query_one("#name", Input).value or None,
                    )
                )
                self.dismiss(True)
        else:
            self.dismiss(False)


class EditQsoModal(ModalScreen):
    """Modal screen to edit an existing QSO."""

    BINDINGS = [
        ("escape", "dismiss_modal", "Close"),
        ("ctrl+s", "save_qso", "Save"),
    ]

    def __init__(self, qso: QSO, focus_column: int = 1) -> None:
        super().__init__()
        self.qso = qso
        self.focus_column = focus_column

    def compose(self) -> ComposeResult:
        with Container(classes="modal-box") as container:
            container.border_title = f"Edit QSO ID: {self.qso.id}"
            text_input = Input(placeholder="Callsign", id="autocomplete-input")
            yield text_input
            yield AutoComplete(
                target=text_input,
                candidates=[],
                prevent_default_tab=False,
            )
            yield Input(placeholder="Frequency", id="frequency")
            yield Input(placeholder="Mode", id="mode")
            with Horizontal(classes="rst-row"):
                yield Input(placeholder="RST/S", id="rst_sent")
                yield Input(placeholder="RST/R", id="rst_received")
            yield Input(placeholder="QTH", id="qth")
            yield Input(placeholder="Gridsquare", id="gridsquare")
            yield Input(placeholder="Band", id="band")
            yield Input(placeholder="TX Power (W)", id="tx_pwr")
            yield Input(placeholder="Name", id="name")
            with Horizontal(id="button-container"):
                yield Button("Save", id="save_btn")
                yield Button("Cancel", id="cancel_btn")

    def on_mount(self) -> None:
        self.query_one("#autocomplete-input", Input).value = self.qso.callsign
        self.query_one("#frequency", Input).value = (
            str(self.qso.frequency) if self.qso.frequency else ""
        )
        self.query_one("#mode", Input).value = self.qso.mode or ""
        self.query_one("#rst_sent", Input).value = self.qso.rst_sent or ""
        self.query_one("#rst_received", Input).value = self.qso.rst_received or ""
        self.query_one("#qth", Input).value = self.qso.qth or ""
        self.query_one("#gridsquare", Input).value = self.qso.gridsquare or ""
        self.query_one("#band", Input).value = self.qso.band or ""
        self.query_one("#tx_pwr", Input).value = (
            str(self.qso.tx_pwr) if self.qso.tx_pwr else ""
        )
        self.query_one("#name", Input).value = self.qso.name or ""
        widget_id = COLUMN_TO_WIDGET.get(self.focus_column, "#autocomplete-input")
        self.query_one(widget_id, Input).focus()
        self._load_candidates()

    @work
    async def _load_candidates(self) -> None:
        callsigns = await get_unique_callsigns()
        ac = self.query_one(AutoComplete)
        ac.candidates = [DropdownItem(main=c) for c in callsigns]

    async def _auto_fill_band(self) -> None:
        freq_raw = self.query_one("#frequency", Input).value
        try:
            freq = Decimal(freq_raw)
        except InvalidOperation:
            return
        band_name = await lookup_band(freq)
        if band_name:
            self.query_one("#band", Input).value = band_name

    async def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "frequency":
            await self._auto_fill_band()

    def action_save_qso(self) -> None:
        self.query_one("#save_btn").press()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "save_btn":
            callsign = self.query_one("#autocomplete-input", Input).value
            freq = self.query_one("#frequency", Input).value
            mode = self.query_one("#mode", Input).value
            qth = self.query_one("#qth", Input).value
            if callsign:
                try:
                    frequency_val = Decimal(freq) if freq else None
                except ValueError:
                    frequency_val = None
                try:
                    tx_pwr_val = (
                        Decimal(self.query_one("#tx_pwr", Input).value)
                        if self.query_one("#tx_pwr", Input).value
                        else None
                    )
                except ValueError:
                    tx_pwr_val = None
                await update_qso(
                    self.qso.id,
                    callsign=callsign,
                    frequency=frequency_val,
                    mode=mode,
                    rst_sent=self.query_one("#rst_sent", Input).value or None,
                    rst_received=self.query_one("#rst_received", Input).value or None,
                    qth=qth,
                    gridsquare=self.query_one("#gridsquare", Input).value or None,
                    band=self.query_one("#band", Input).value or None,
                    tx_pwr=tx_pwr_val,
                    name=self.query_one("#name", Input).value or None,
                )
                self.dismiss(True)
        else:
            self.dismiss(False)

    def action_dismiss_modal(self) -> None:
        self.dismiss(False)


class StatsModal(ModalScreen):
    """Modal screen to display QSO statistics."""

    BINDINGS = [("escape", "dismiss_modal", "Close")]

    def compose(self) -> ComposeResult:
        with Container(classes="modal-box") as container:
            container.border_title = "QSO Statistics"
            yield Label(id="stat-total")
            yield Label(id="stat-unique")
            yield Label(id="stat-first")
            yield Label(id="stat-last")
            yield Label(id="stat-mode")
            yield Label(id="stat-freq")
            with Horizontal(id="button-container"):
                yield Button("Close", id="close_btn")

    def on_mount(self) -> None:
        self._load_stats()

    @work
    async def _load_stats(self) -> None:
        stats = await get_qso_statistics()
        self.query_one("#stat-total", Label).update(
            f"Total QSOs: {stats['total_qsos']}"
        )
        self.query_one("#stat-unique", Label).update(
            f"Unique Callsigns: {stats['unique_callsigns']}"
        )
        self.query_one("#stat-first", Label).update(
            f"First QSO: {stats['first_qso_date'] or 'N/A'}"
        )
        self.query_one("#stat-last", Label).update(
            f"Last QSO: {stats['last_qso_date'] or 'N/A'}"
        )
        if stats["most_frequent_mode"]:
            self.query_one("#stat-mode", Label).update(
                f"Top Mode: {stats['most_frequent_mode']} ({stats['most_frequent_mode_count']})"
            )
        else:
            self.query_one("#stat-mode", Label).update("Top Mode: N/A")
        if stats["most_frequent_frequency"]:
            freq_str = str(stats["most_frequent_frequency"]).rstrip("0").rstrip(".")
            self.query_one("#stat-freq", Label).update(
                f"Top Freq: {freq_str}MHz ({stats['most_frequent_frequency_count']})"
            )
        else:
            self.query_one("#stat-freq", Label).update("Top Freq: N/A")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close_btn":
            self.dismiss(None)

    def action_dismiss_modal(self) -> None:
        self.dismiss(None)


class ConfirmExitModal(ModalScreen[bool]):
    """Modal screen to confirm exiting the app."""

    AUTO_FOCUS = "#no_btn"
    BINDINGS = [("escape", "dismiss_cancel", "Cancel")]

    def compose(self) -> ComposeResult:
        with Container(classes="modal-box") as container:
            container.border_title = "Confirm Exit"
            yield Label("Are you sure to exit?")
            with Horizontal(id="button-container"):
                yield Button("Yes", id="yes_btn")
                yield Button("No", id="no_btn")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "yes_btn":
            self.dismiss(True)
        else:
            self.dismiss(False)

    def action_dismiss_cancel(self) -> None:
        self.dismiss(False)


class SearchModal(ModalScreen):
    """Modal screen to search for QSOs."""

    BINDINGS = [("escape", "dismiss_modal", "Close")]

    def compose(self) -> ComposeResult:
        with Container(classes="modal-box") as container:
            container.border_title = "Search QSOs"
            yield Input(placeholder="Search pattern...", id="search_input")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self.dismiss(event.value)

    def action_dismiss_modal(self) -> None:
        self.dismiss(None)


class SettingsModal(ModalScreen[bool]):
    """Modal screen to edit application settings."""

    BINDINGS = [
        ("escape", "dismiss_modal", "Close"),
        ("ctrl+s", "save_settings", "Save"),
    ]

    def compose(self) -> ComposeResult:
        s = settings
        with Container(classes="modal-box") as container:
            container.border_title = "Settings"
            yield Label("[bold]Database[/]", classes="section-header")
            yield Label("Database path", classes="field-label")
            yield Input(
                placeholder="Database path",
                id="db_path",
                value=s.database.path,
            )
            yield Label("[bold]Station[/]", classes="section-header")
            yield Label("Callsign", classes="field-label")
            yield Input(
                placeholder="Callsign",
                id="station_callsign",
                value=s.station.callsign,
            )
            yield Label("Gridsquare", classes="field-label")
            yield Input(
                placeholder="Gridsquare",
                id="station_gridsquare",
                value=s.station.gridsquare,
            )
            yield Label("[bold]TUI[/]", classes="section-header")
            yield Label("Default frequency", classes="field-label")
            yield Input(
                placeholder="Default frequency",
                id="default_frequency",
                value=s.tui.default_frequency,
            )
            yield Label("Default mode", classes="field-label")
            yield Input(
                placeholder="Default mode",
                id="default_mode",
                value=s.tui.default_mode,
            )
            yield Label("Default QTH", classes="field-label")
            yield Input(
                placeholder="Default QTH",
                id="default_qth",
                value=s.tui.default_qth,
            )
            yield Label("Theme", classes="field-label")
            yield Input(
                placeholder="Theme (e.g. textual-dark)",
                id="theme",
                value=s.tui.theme,
            )
            yield Label("Fast exit", classes="field-label")
            yield Input(
                placeholder="Fast exit (true/false)",
                id="fast_exit",
                value=str(s.tui.fast_exit).lower(),
            )
            yield Label("Zebra stripes", classes="field-label")
            yield Input(
                placeholder="Zebra stripes (true/false)",
                id="zebra_stripes",
                value=str(s.tui.zebra_stripes).lower(),
            )
            with Horizontal(id="button-container"):
                yield Button("Save", id="save_btn")
                yield Button("Cancel", id="cancel_btn")

    def action_save_settings(self) -> None:
        self.query_one("#save_btn").press()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "save_btn":
            try:
                new_settings = Settings(
                    database={"path": self.query_one("#db_path", Input).value},
                    station={
                        "callsign": self.query_one("#station_callsign", Input).value,
                        "gridsquare": self.query_one(
                            "#station_gridsquare", Input
                        ).value,
                    },
                    tui={
                        "default_frequency": self.query_one(
                            "#default_frequency", Input
                        ).value,
                        "default_mode": self.query_one("#default_mode", Input).value,
                        "default_qth": self.query_one("#default_qth", Input).value,
                        "theme": self.query_one("#theme", Input).value,
                        "fast_exit": self.query_one("#fast_exit", Input).value.lower()
                        == "true",
                        "zebra_stripes": self.query_one(
                            "#zebra_stripes", Input
                        ).value.lower()
                        == "true",
                    },
                )
                write_settings(new_settings)
                self.dismiss(True)
            except Exception:
                self.dismiss(False)
        else:
            self.dismiss(False)

    def action_dismiss_modal(self) -> None:
        self.dismiss(False)
