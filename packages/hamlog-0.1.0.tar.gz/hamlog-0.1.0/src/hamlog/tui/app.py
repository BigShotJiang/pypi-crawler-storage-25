from decimal import Decimal
from textual.app import App, ComposeResult
from textual.widgets import DataTable, Footer, Header
from textual import work
import textual
from hamlog.config import reload_settings, settings
from hamlog.logbook import (
    count_qsos,
    get_qsos_paginated,
    search_qsos,
)
from hamlog.models import QSO
from hamlog.tui.modals import (
    AddQsoModal,
    ConfirmExitModal,
    EditQsoModal,
    SearchModal,
    SettingsModal,
    StatsModal,
)


PAGE_SIZE = 50


class HamLogApp(App):
    """A Textual app for HamLog."""

    CSS = """
    ModalScreen {
        align: center middle;
    }
    .modal-box {
        width: 50;
        height: auto;
        max-height: 90%;
        overflow-y: auto;
        border: outer $primary;
        border-title-color: white;
        border-title-background: $primary;
        border-title-style: bold;
        background: $surface;
        padding: 1 2;
    }
    #button-container {
        layout: horizontal;
        align: center middle;
        height: auto;
        margin-top: 1;
    }
    #button-container > Button {
        margin: 0 1;
    }
    .section-header {
        margin-top: 1;
        text-style: bold;
    }
    .field-label {
        margin-top: 1;
    }
    .rst-row {
        layout: horizontal;
        height: auto;
        margin-top: 1;
    }
    .rst-row > Label {
        width: auto;
        padding: 0 1 0 0;
        content-align: left middle;
    }
    .rst-row > Input {
        width: 1fr;
    }
    """

    BINDINGS = [
        ("^q", "quit", "Quit"),
        ("a", "add_qso", "Add QSO"),
        ("?", "search_qso", "Search QSO"),
        ("s", "show_stats", "Statistics"),
        ("o", "show_settings", "Settings"),
        ("left", "move_left", ""),
        ("right", "move_right", ""),
    ]

    def __init__(self):
        super().__init__()
        self._qsos_cache = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield DataTable()
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one(DataTable)
        table.zebra_stripes = settings.tui.zebra_stripes
        table.add_columns(
            "ID",
            "Date",
            "Time",
            "Callsign",
            "Freq (MHz)",
            "Mode",
            "RST/S",
            "RST/R",
            "QTH",
            "Band",
            "Grid",
            "Name",
            "Notes",
        )
        theme = settings.tui.theme
        if theme == "dark":
            theme = "textual-dark"
        elif theme == "light":
            theme = "textual-light"
        self.theme = theme
        table.loading = True
        self.load_data(table)

    @work
    async def load_data(self, table: DataTable) -> None:
        table.clear()
        self._qsos_cache = []
        first_page = await get_qsos_paginated(offset=0, limit=PAGE_SIZE)
        self._qsos_cache = list(first_page)
        for qso in first_page:
            table.add_row(
                str(qso.id),
                qso.start_date or "",
                qso.start_time or "",
                qso.callsign,
                str(qso.frequency).rstrip("0").rstrip(".") if qso.frequency else "",
                qso.mode or "",
                qso.rst_sent or "",
                qso.rst_received or "",
                qso.qth or "",
                qso.band or "",
                qso.gridsquare or "",
                qso.name or "",
                qso.notes or "",
                key=str(qso.id),
            )
        total = await count_qsos()
        table.loading = False
        if total > PAGE_SIZE:
            self._load_remaining(PAGE_SIZE, table)

    @work
    async def _load_remaining(self, offset: int, table: DataTable) -> None:
        page = await get_qsos_paginated(offset=offset, limit=PAGE_SIZE)
        self._qsos_cache.extend(page)
        for qso in page:
            table.add_row(
                str(qso.id),
                qso.start_date or "",
                qso.start_time or "",
                qso.callsign,
                str(qso.frequency).rstrip("0").rstrip(".") if qso.frequency else "",
                qso.mode or "",
                qso.rst_sent or "",
                qso.rst_received or "",
                qso.qth or "",
                qso.band or "",
                qso.gridsquare or "",
                qso.name or "",
                qso.notes or "",
                key=str(qso.id),
            )
        if len(page) == PAGE_SIZE:
            self._load_remaining(offset + PAGE_SIZE, table)

    def _qso_from_row(self, row_key: str) -> QSO | None:
        qso = next((q for q in self._qsos_cache if str(q.id) == row_key), None)
        if qso is not None:
            return qso
        try:
            table = self.query_one(DataTable)
            row_index = table.get_row_index(row_key)
            if row_index is None:
                return None
            row = table.get_row_at(row_index)
            if not row or str(row[0]) != row_key:
                return None
            freq_raw = row[4]
            try:
                freq = Decimal(freq_raw) if freq_raw else None
            except Exception:
                freq = None
            return QSO(
                id=int(row[0]),
                start_date=row[1] or None,
                start_time=row[2] or None,
                callsign=row[3],
                frequency=freq,
                mode=row[5] or None,
                rst_sent=row[6] or None,
                rst_received=row[7] or None,
                qth=row[8] or None,
                band=row[9] or None,
                gridsquare=row[10] or None,
                name=row[11] or None,
                notes=row[12] or None,
            )
        except Exception:
            return None

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        row_id = event.row_key
        try:
            qso = self._qso_from_row(row_id)
            if qso:

                def callback(updated: bool):
                    if updated:
                        self.refresh_table(cursor_key=row_id)

                col = event.cursor_column or 1
                self.push_screen(EditQsoModal(qso, focus_column=col), callback)
        except Exception:
            pass

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        pass

    def on_key(self, event: textual.events.Key) -> None:
        if event.key == "enter":
            if len(self.screen_stack) > 1:
                return
            table = self.query_one(DataTable)
            cursor_row = table.cursor_row
            if cursor_row is not None:
                row_key = (
                    table.get_row_at(cursor_row)[0]
                    if hasattr(table, "get_row_at")
                    else None
                )
                if row_key is None:
                    try:
                        row_data = table.get_row(cursor_row)
                        row_key = row_data[0]
                    except Exception:
                        row_key = None
                qso = self._qso_from_row(str(row_key)) if row_key else None
                if qso:

                    def callback(updated: bool):
                        if updated:
                            self.refresh_table(cursor_key=row_key)

                    col = table.cursor_column or 1
                    self.push_screen(EditQsoModal(qso, focus_column=col), callback)
        elif event.key == "tab":
            event.stop()
            table = self.query_one(DataTable)
            if table.row_count == 0:
                return
            col_count = len(table.columns)
            row = table.cursor_row if table.cursor_row is not None else 0
            col = table.cursor_column if table.cursor_column is not None else 0
            if col == col_count - 1 and row < table.row_count - 1:
                table.cursor_coordinate = (row + 1, 0)
            elif col < col_count - 1:
                table.cursor_coordinate = (row, col + 1)
        elif event.key == "shift+tab":
            event.stop()
            table = self.query_one(DataTable)
            if table.row_count == 0:
                return
            col_count = len(table.columns)
            row = table.cursor_row if table.cursor_row is not None else 0
            col = table.cursor_column if table.cursor_column is not None else 0
            if col == 0 and row > 0:
                table.cursor_coordinate = (row - 1, col_count - 1)
            elif col > 0:
                table.cursor_coordinate = (row, col - 1)

    @work
    async def refresh_table(self, qsos=None, cursor_key=None) -> None:
        table = self.query_one(DataTable)
        table.zebra_stripes = settings.tui.zebra_stripes
        table.clear()
        self._qsos_cache = []
        if qsos is not None:
            self._qsos_cache = list(qsos)
            for qso in qsos:
                table.add_row(
                    str(qso.id),
                    qso.start_date or "",
                    qso.start_time or "",
                    qso.callsign,
                    str(qso.frequency).rstrip("0").rstrip(".") if qso.frequency else "",
                    qso.mode or "",
                    qso.rst_sent or "",
                    qso.rst_received or "",
                    qso.qth or "",
                    qso.band or "",
                    qso.gridsquare or "",
                    qso.name or "",
                    qso.notes or "",
                    key=str(qso.id),
                )
            if cursor_key is not None:
                row_index = table.get_row_index(cursor_key)
                if row_index is not None:
                    table.cursor_coordinate = (row_index, 0)
            return
        first_page = await get_qsos_paginated(offset=0, limit=PAGE_SIZE)
        self._qsos_cache = list(first_page)
        for qso in first_page:
            table.add_row(
                str(qso.id),
                qso.start_date or "",
                qso.start_time or "",
                qso.callsign,
                str(qso.frequency).rstrip("0").rstrip(".") if qso.frequency else "",
                qso.mode or "",
                qso.rst_sent or "",
                qso.rst_received or "",
                qso.qth or "",
                qso.band or "",
                qso.gridsquare or "",
                qso.name or "",
                qso.notes or "",
                key=str(qso.id),
            )
        total = await count_qsos()
        if cursor_key is not None and table.get_row_index(cursor_key) is not None:
            row_index = table.get_row_index(cursor_key)
            table.cursor_coordinate = (row_index, 0)
        if total > PAGE_SIZE:
            self._load_remaining(PAGE_SIZE, table)

    def action_add_qso(self) -> None:
        def callback(added: bool):
            if added:
                self.refresh_table()

        self.push_screen(AddQsoModal(), callback)

    def action_search_qso(self) -> None:
        def callback(pattern: str | None):
            if pattern is not None:
                self._search_and_refresh(pattern)

        self.push_screen(SearchModal(), callback)

    @work
    async def _search_and_refresh(self, pattern: str) -> None:
        results = await search_qsos(pattern)
        self.refresh_table(results)

    def action_show_stats(self) -> None:
        self.push_screen(StatsModal())

    def action_show_settings(self) -> None:
        def callback(saved: bool):
            if saved:
                reload_settings()
                self.refresh_table()

        self.push_screen(SettingsModal(), callback)

    def action_move_left(self) -> None:
        table = self.query_one(DataTable)
        if table.row_count == 0:
            return
        row = table.cursor_row if table.cursor_row is not None else 0
        col = table.cursor_column if table.cursor_column is not None else 0
        if col > 0:
            table.cursor_coordinate = (row, col - 1)

    def action_move_right(self) -> None:
        table = self.query_one(DataTable)
        if table.row_count == 0:
            return
        col_count = len(table.columns)
        row = table.cursor_row if table.cursor_row is not None else 0
        col = table.cursor_column if table.cursor_column is not None else 0
        if col < col_count - 1:
            table.cursor_coordinate = (row, col + 1)

    def action_quit(self) -> None:
        if settings.tui.fast_exit:
            self.exit()
        else:
            self.push_screen(ConfirmExitModal(), self._on_exit_confirmed)

    def _on_exit_confirmed(self, confirmed: bool) -> None:
        if confirmed:
            self.exit()
