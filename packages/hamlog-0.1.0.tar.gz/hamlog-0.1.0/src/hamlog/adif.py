import json
import re
from collections import Counter
from decimal import Decimal, InvalidOperation

from hamlog.logbook import add_qso
from hamlog.models import QSO

ADIF_FIELD_RE = re.compile(r"<(\w+)(?::(\d+)(?::(\w+))?)?>([^<]*)")

ADIF_TO_QSO = {
    # Basic
    "CALL": "callsign",
    "FREQ": "frequency",
    "MODE": "mode",
    "QTH": "qth",
    "QSO_DATE": "start_date",
    "TIME_ON": "start_time",
    "RST_SENT": "rst_sent",
    "RST_RCVD": "rst_received",
    "COMMENT": "comment",
    "NOTES": "notes",
    "NAME": "name",
    "GRIDSQUARE": "gridsquare",
    "BAND": "band",
    "QSO_DATE_OFF": "qso_date_off",
    "TIME_OFF": "time_off",
    "STATION_CALLSIGN": "station_callsign",
    "MY_GRIDSQUARE": "my_gridsquare",
    # QSL
    "QSL_RCVD": "qsl_rcvd",
    "QSL_SENT": "qsl_sent",
    "QSL_RDATE": "qsl_rdate",
    "QSL_SDATE": "qsl_sdate",
    "LOTW_QSL_RCVD": "lotw_qsl_rcvd",
    "LOTW_QSL_SENT": "lotw_qsl_sent",
    "LOTW_QSL_RDATE": "lotw_qsl_rdate",
    "LOTW_QSL_SDATE": "lotw_qsl_sdate",
    "EQSL_QSL_RCVD": "eqsl_qsl_rcvd",
    "EQSL_QSL_SENT": "eqsl_qsl_sent",
    "EQSL_QSL_RDATE": "eqsl_qsl_rdate",
    "EQSL_QSL_SDATE": "eqsl_qsl_sdate",
    # Operator
    "TX_PWR": "tx_pwr",
    "RX_PWR": "rx_pwr",
    "SUBMODE": "submode",
    "PROP_MODE": "prop_mode",
    # Awards
    "SOTA_REF": "sota_ref",
    "MY_SOTA_REF": "my_sota_ref",
    "POTA_REF": "pota_ref",
    "MY_POTA_REF": "my_pota_ref",
    # Entity
    "DXCC": "dxcc",
    "CQZ": "cqz",
    "ITUZ": "ituz",
    "CONT": "cont",
    "COUNTRY": "country",
    "STATE": "state",
    # Contest
    "CONTEST_ID": "contest_id",
    "STX": "stx",
    "SRX": "srx",
    # Other
    "RIG": "rig",
}

QSO_TO_ADIF = {v: k for k, v in ADIF_TO_QSO.items()}

DATE_FIELDS = {
    "start_date",
    "qso_date_off",
    "qsl_rdate",
    "qsl_sdate",
    "lotw_qsl_rdate",
    "lotw_qsl_sdate",
    "eqsl_qsl_rdate",
    "eqsl_qsl_sdate",
}

TIME_FIELDS = {"start_time", "time_off"}
FLOAT_FIELDS = {"frequency", "tx_pwr", "rx_pwr"}
INT_FIELDS = {"dxcc", "cqz", "ituz"}


def parse_adif_content(content: str) -> list[dict[str, str]]:
    records = []
    current_record: dict[str, str] = {}
    pos = 0
    while pos < len(content):
        match = ADIF_FIELD_RE.search(content, pos)
        if match is None:
            break
        name = match.group(1).upper()
        length_str = match.group(2)
        if length_str is None:
            data = ""
            end = match.end()
        else:
            length = int(length_str)
            data_start = match.start(4)
            data = content[data_start : data_start + length].strip()
            end = data_start + length
        if name == "EOH":
            current_record = {}
        elif name == "EOR":
            if current_record:
                records.append(current_record)
                current_record = {}
        else:
            current_record[name] = data
        pos = end
    return records


def adif_to_qso(data: dict[str, str]) -> QSO:
    kwargs = {}
    adif_data = {}
    for adif_key, raw in data.items():
        qso_attr = ADIF_TO_QSO.get(adif_key)
        if qso_attr is not None:
            if qso_attr in FLOAT_FIELDS:
                try:
                    kwargs[qso_attr] = Decimal(raw)
                except InvalidOperation:
                    pass
            elif qso_attr in INT_FIELDS:
                try:
                    kwargs[qso_attr] = int(raw)
                except ValueError:
                    pass
            elif qso_attr in DATE_FIELDS:
                kwargs[qso_attr] = _adif_date_to_db(raw)
            elif qso_attr in TIME_FIELDS:
                kwargs[qso_attr] = _adif_time_to_db(raw)
            else:
                kwargs[qso_attr] = raw
        else:
            adif_data[adif_key] = raw
    qso = QSO(**kwargs)
    if adif_data:
        qso.adif_data = json.dumps(adif_data)
    return qso


def _adif_date_to_db(adif_date: str) -> str:
    d = adif_date.strip()
    if len(d) == 8 and d.isdigit():
        return f"{d[:4]}-{d[4:6]}-{d[6:8]}"
    return d


def _adif_time_to_db(adif_time: str) -> str:
    t = adif_time.strip()
    if len(t) == 6 and t.isdigit():
        return f"{t[:2]}:{t[2:4]}:{t[4:6]}"
    return t


def _db_date_to_adif(db_date: str | None) -> str:
    if not db_date:
        return ""
    d = db_date.strip().replace("-", "")
    if d.isdigit():
        return d
    return db_date


def _db_time_to_adif(db_time: str | None) -> str:
    if not db_time:
        return ""
    t = db_time.strip().replace(":", "")
    if t.isdigit():
        return t
    return db_time


def _format_adif_field(name: str, value: str | None) -> str:
    if not value:
        return ""
    return f"<{name}:{len(value)}>{value} "


def _qso_to_adif_dict(qso: QSO) -> dict[str, str]:
    result = {}
    for qso_attr, adif_key in QSO_TO_ADIF.items():
        value = getattr(qso, qso_attr, None)
        if value is None:
            continue
        if qso_attr in DATE_FIELDS:
            result[adif_key] = _db_date_to_adif(value)
        elif qso_attr in TIME_FIELDS:
            result[adif_key] = _db_time_to_adif(value)
        elif qso_attr in FLOAT_FIELDS:
            result[adif_key] = str(value)
        elif qso_attr in INT_FIELDS:
            result[adif_key] = str(value)
        else:
            result[adif_key] = value
    if qso.adif_data:
        try:
            extra = json.loads(qso.adif_data)
            for k, v in extra.items():
                if k not in result:
                    result[k] = v
        except (json.JSONDecodeError, TypeError):
            pass
    return result


def qso_to_adif(qso: QSO) -> str:
    parts = []
    for adif_key, value in _qso_to_adif_dict(qso).items():
        parts.append(_format_adif_field(adif_key, value))
    parts.append("<EOR>")
    return "".join(parts)


def export_adif(qsos: list[QSO]) -> str:
    lines = [
        "ADIF Export from HamLog",
        "<EOH>",
    ]
    for qso in qsos:
        lines.append(qso_to_adif(qso))
    return "\n".join(lines)


async def _import_adif_async(records: list[dict[str, str]]) -> None:

    for record in records:
        qso = adif_to_qso(record)
        if qso.callsign:
            await add_qso(qso)


async def import_adif_async(file_path: str) -> dict:
    with open(file_path) as f:
        content = f.read()
    records = parse_adif_content(content)
    callsigns = []
    for record in records:
        qso = adif_to_qso(record)
        if qso.callsign:
            callsigns.append(qso.callsign)

    await _import_adif_async(records)

    total = len(callsigns)
    counts = Counter(callsigns)
    unique_calls = len(counts)
    repeating_calls = sum(1 for c in counts.values() if c > 1)
    total_repeated = sum(c - 1 for c in counts.values() if c > 1)
    return {
        "total": total,
        "unique_calls": unique_calls,
        "repeating_calls": repeating_calls,
        "total_repeated": total_repeated,
    }


def import_adif(file_path: str) -> dict:
    import asyncio

    return asyncio.run(import_adif_async(file_path))
