from sqlalchemy import Column, Integer, String, Numeric, Text
from hamlog.db import Base


class QSO(Base):
    __tablename__ = "qsos"

    id = Column(Integer, primary_key=True, autoincrement=True)
    callsign = Column(String, nullable=False, index=True)
    frequency = Column(Numeric(precision=13, scale=6, asdecimal=True))
    mode = Column(String)
    qth = Column(String)
    start_date = Column(String, index=True)
    start_time = Column(String, index=True)
    rst_sent = Column(String)
    rst_received = Column(String)
    notes = Column(String)
    comment = Column(String)
    gridsquare = Column(String)
    qso_date_off = Column(String)
    time_off = Column(String)
    band = Column(String)
    station_callsign = Column(String)
    my_gridsquare = Column(String)

    # QSL fields
    qsl_rcvd = Column(String)
    qsl_sent = Column(String)
    qsl_rdate = Column(String)
    qsl_sdate = Column(String)
    lotw_qsl_rcvd = Column(String)
    lotw_qsl_sent = Column(String)
    lotw_qsl_rdate = Column(String)
    lotw_qsl_sdate = Column(String)
    eqsl_qsl_rcvd = Column(String)
    eqsl_qsl_sent = Column(String)
    eqsl_qsl_rdate = Column(String)
    eqsl_qsl_sdate = Column(String)

    # Operator params
    tx_pwr = Column(Numeric)
    rx_pwr = Column(Numeric)
    submode = Column(String)
    prop_mode = Column(String)

    # Awards
    sota_ref = Column(String)
    my_sota_ref = Column(String)
    pota_ref = Column(String)
    my_pota_ref = Column(String)

    # Entity
    dxcc = Column(Integer)
    cqz = Column(Integer)
    ituz = Column(Integer)
    cont = Column(String)
    country = Column(String)
    state = Column(String)

    # Contest
    contest_id = Column(String)
    stx = Column(String)
    srx = Column(String)

    # Other
    name = Column(String)
    rig = Column(String)

    # JSON catch-all for unmapped ADIF fields
    adif_data = Column(Text)

    def __repr__(self) -> str:
        return f"<QSO {self.callsign}>"


class Band(Base):
    __tablename__ = "bands"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False, unique=True)
    lower_freq = Column(Numeric(precision=7, scale=4, asdecimal=True), nullable=False)
    upper_freq = Column(Numeric(precision=7, scale=4, asdecimal=True), nullable=False)

    def __repr__(self) -> str:
        return f"<Band {self.name}>"
