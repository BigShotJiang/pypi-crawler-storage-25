"""Phoenix TUI Application -- Textual-based.

Layout:
    ┌─ HeaderBar    (dock top, 2 lines: Phoenix vX · model · cwd)
    ├─ #chat        (scrollable; stream layout; message widgets)
    ├─ ChatInputBar (dock bottom; prompt + multiline TextArea)
    └─ StatusBar    (dock bottom; 1 line: mode · bg · topic · tokens · turn)
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from dataclasses import dataclass, field
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.worker import Worker, WorkerState

from phoenix.tui.messages import (
    ChatInputSubmitted,
    NotificationMessage,
    StatusMessage,
    StreamChunk,
    StreamEnd,
    StreamStart,
    ToolCallEvent,
    ToolResultEvent,
    TurnDone,
    TurnError,
    TurnUsage,
    WorkingEnd,
    WorkingStart,
)
from phoenix.tui.widgets import (
    AssistantMessageW,
    ChatInputBar,
    ChatTextArea,
    ErrorLineW,
    HeaderBar,
    NotifyLineW,
    StatusBar,
    StatusLineW,
    ToolCallMessageW,
    ToolResultMessageW,
    UsageLineW,
    UserMessageW,
    WelcomeW,
    WorkingLineW,
)

log = logging.getLogger(__name__)


@dataclass
class AppState:
    turn_count: int = 0
    usage_input: int = 0
    usage_output: int = 0
    history_commands: list[str] = field(default_factory=list)
    pending_inputs: list[str] = field(default_factory=list)
    stream_phase: str = "idle"  # idle | thinking | streaming | tool
    active_tool: str = ""

    @property
    def queued(self) -> int:
        return len(self.pending_inputs)


def _cwd_label() -> str:
    cwd = Path.cwd()
    home = Path.home()
    if cwd == home:
        return "~"
    try:
        return f"~/{cwd.relative_to(home)}"
    except ValueError:
        return str(cwd)


class PhoenixApp(App):
    CSS_PATH = "app.tcss"
    THEME = "tokyo-night"

    BINDINGS = [
        Binding("ctrl+d", "force_quit", show=False, priority=True),
        Binding("ctrl+c", "cancel_or_quit", show=False, priority=True),
        Binding("escape", "interrupt", show=False, priority=True),
        Binding("ctrl+l", "clear_log", show=False, priority=True),
        Binding("shift+tab", "cycle_mode", show=False, priority=True),
    ]

    def __init__(
        self,
        engine,
        session,
        history: list | None = None,
        ambient=None,
        hook_runner=None,
        voice_queue=None,
        voice_daemon=None,
    ) -> None:
        super().__init__()
        self.engine = engine
        self.session = session
        self.ambient = ambient
        self.hook_runner = hook_runner
        self.voice_queue = voice_queue
        self.voice_daemon = voice_daemon
        self._voice_poll_task: asyncio.Task | None = None
        self._exiting: bool = False
        self.active_history: list = history or []
        self.state = AppState()
        self._active_assistant: AssistantMessageW | None = None
        self._turn_worker = None  # Textual Worker handle
        self._turn_cancel: asyncio.Event | None = None
        self._working_widget: WorkingLineW | None = None
        # Live tool widgets keyed by pydantic-ai tool_call_id so
        # FunctionToolResultEvent can update the matching call in place.
        self._tool_widgets: dict[str, ToolCallMessageW] = {}
        self._welcome_widget: WelcomeW | None = None

    # ------------------------------------------------------------- compose

    def compose(self) -> ComposeResult:
        yield HeaderBar()
        yield VerticalScroll(id="chat")
        yield StatusBar(engine=self.engine, state=self.state)
        yield ChatInputBar(history=self.state.history_commands)

    def on_mount(self) -> None:
        with contextlib.suppress(Exception):
            self.theme = "tokyo-night"

        # Install Textual-aware approval backend so approval prompts use modals
        # instead of stdin input() (which would freeze the UI).
        from phoenix.core.interceptor import (
            AutoApprovalBackend,
            get_approval_backend,
            set_approval_backend,
        )
        from phoenix.tui.approval import TUIApprovalBackend

        current = get_approval_backend()
        if not isinstance(current, (AutoApprovalBackend, TUIApprovalBackend)):
            set_approval_backend(TUIApprovalBackend(self))

        self._chat = self.query_one("#chat", VerticalScroll)

        # Welcome block
        from phoenix import __version__
        from phoenix.config.settings import get_model

        n_ab = len(self.engine.registry.list_abilities())
        n_ag = len(self.engine.registry.list_agents())
        # Memory count is fetched in a background task; the async stats()
        # can't be awaited from sync on_mount. We start the welcome with 0
        # and patch it after the first poll returns (near-instant since
        # warm_up already connected the DB).
        self._welcome_widget = WelcomeW(
            version=__version__,
            model=get_model(),
            cwd=_cwd_label(),
            abilities=n_ab,
            agents=n_ag,
            memories=0,
        )
        self._append(self._welcome_widget)
        if getattr(self.engine, "_memory", None):
            asyncio.create_task(self._poll_welcome_stats())

        if self.active_history:
            self._append(StatusLineW(f"restored session {self.session.session_id}"))

        # Focus input after layout settles
        self.call_after_refresh(self._focus_input)

        # Start notification poller
        self._poll_task = asyncio.create_task(self._poll_notifications())

        # Voice input poller (reads from voice_daemon.voice_queue, posts as chat input)
        if self.voice_queue is not None:
            self._voice_poll_task = asyncio.create_task(self._poll_voice())
            self._append(StatusLineW("voice input active -- say 'Phoenix' to wake"))

    def on_unmount(self) -> None:
        with contextlib.suppress(Exception):
            self._poll_task.cancel()
        if self._voice_poll_task is not None:
            with contextlib.suppress(Exception):
                self._voice_poll_task.cancel()

    def _focus_input(self) -> None:
        with contextlib.suppress(Exception):
            self.query_one(ChatInputBar).focus_input()

    def _append(self, widget):
        """Mount a chat message. Returns AwaitMount so callers can await the
        paint tick when the ordering matters (e.g. user's own message before
        kicking off a heavy worker). Safe to ignore the return value."""
        awaitable = self._chat.mount(widget)
        self._chat.scroll_end(animate=False)
        return awaitable

    # ------------------------------------------------------------- input

    async def on_chat_input_submitted(self, event: ChatInputSubmitted) -> None:
        text = event.text.strip()
        if not text:
            return
        # Await the mount so Textual's compositor paints the user's message
        # BEFORE we start the turn worker. Without the await, the sync handler
        # holds the main thread through _run_turn setup and the paint is
        # deferred by 1-2s (mistral-vibe pattern: see temp/mistral-vibe/.../app.py:904).
        await self._append(UserMessageW(text))
        self.call_after_refresh(self._focus_input)

        if self.ambient:
            with contextlib.suppress(Exception):
                self.ambient.record_input()

        # Slash command -- runs inline, no queueing
        if await self._handle_slash(text):
            return

        # If a turn is already running, queue this message (type-ahead)
        if self.is_turn_running:
            self.state.pending_inputs.append(text)
            self._append(
                StatusLineW(f"queued (#{self.state.queued}) -- press esc to interrupt current")
            )
            return

        self._run_turn(text)

    @property
    def is_turn_running(self) -> bool:
        """Derived source of truth: is a turn worker actually running?"""
        w = self._turn_worker
        if w is None:
            return False
        try:
            st = getattr(w, "state", None)
            name = getattr(st, "name", "") if st is not None else ""
            return name == "RUNNING"
        except Exception:
            return False

    def _drain_queue(self) -> None:
        """If turn queue has pending messages, start the next one."""
        if self.is_turn_running:
            return
        if not self.state.pending_inputs:
            return
        next_msg = self.state.pending_inputs.pop(0)
        self._run_turn(next_msg)

    # ------------------------------------------------------------- slash commands

    async def _handle_slash(self, user_input: str) -> bool:
        stripped = user_input.strip()
        if not (stripped.startswith("/") or stripped in ("quit", "exit", "clear", "history")):
            return False

        from phoenix.shell.commands import CommandContext, handle_command

        ctx = CommandContext(
            history=self.active_history,
            turn_count=self.state.turn_count,
            usage_total={
                "input": self.state.usage_input,
                "output": self.state.usage_output,
            },
            save_fn=self.session.save,
            engine=self.engine,
        )
        result = await handle_command(user_input, ctx)
        if result is None:
            return False

        if result == "__EXIT__":
            self._graceful_exit()
            return True

        # /report-bug sentinel -- run the network POST as a Textual worker
        # so the UI stays responsive during the (potentially slow) submit.
        if isinstance(result, str) and result.startswith("__REPORT_BUG__:"):
            description = result[len("__REPORT_BUG__:") :]
            self._append(StatusLineW("Filing bug report -- scrubbing + submitting..."))
            self.run_worker(
                self._submit_bug_report(description),
                group="bug-report",
                exclusive=False,
                description="bug report",
            )
            return True

        # Echo command output
        self._append(StatusLineW(self._strip_ansi(str(result))))
        self.active_history = ctx.history
        self.state.turn_count = ctx.turn_count
        return True

    async def _submit_bug_report(self, description: str) -> None:
        """Background worker body -- runs in the event loop but off the
        slash-dispatch path, so the input bar stays interactive."""
        try:
            from phoenix.report import build_bundle, submit

            bundle = build_bundle(description)
            result = await submit(bundle)
        except Exception as e:
            from phoenix.tui.messages import BugReportDone

            class _Err:
                ok = False
                issue_url = ""
                issue_number = 0
                local_path = None
                error = f"{type(e).__name__}: {e}"
                retry_after_seconds = 0

            self.post_message(BugReportDone(_Err()))
            return

        from phoenix.tui.messages import BugReportDone

        self.post_message(BugReportDone(result))

    def on_bug_report_done(self, event) -> None:
        from phoenix.shell.commands import format_report_result

        text = self._strip_ansi(format_report_result(event.result))
        self._append(StatusLineW(text))

    @staticmethod
    def _strip_ansi(s: str) -> str:
        """Remove ANSI escape sequences (our command handlers use them for color)."""
        import re

        return re.sub(r"\x1b\[[0-9;]*m", "", s)

    # ------------------------------------------------------------- turn

    def _run_turn(self, user_input: str) -> None:
        self._active_assistant = None
        self._turn_cancel = asyncio.Event()
        self.state.stream_phase = "thinking"
        self._turn_worker = self.run_worker(
            self._turn_worker_fn(user_input),
            exclusive=True,
            group="turn",
            description="agent turn",
        )

    async def _turn_worker_fn(self, user_input: str) -> None:
        """Worker body: runs engine.run_stream, posts messages."""
        import time as _time

        last_chunk_time = [_time.monotonic()]
        heartbeat_done = asyncio.Event()

        async def _heartbeat():
            """Post WorkingStart when the stream pauses (tool in flight)."""
            working_emitted = False
            try:
                while not heartbeat_done.is_set():
                    await asyncio.sleep(0.3)
                    if heartbeat_done.is_set():
                        break
                    gap = _time.monotonic() - last_chunk_time[0]
                    if gap > 0.7 and not working_emitted:
                        self.post_message(WorkingStart())
                        working_emitted = True
                        self.state.stream_phase = "working"
                    elif gap < 0.2 and working_emitted:
                        self.post_message(WorkingEnd())
                        working_emitted = False
                        self.state.stream_phase = "streaming"
            except asyncio.CancelledError:
                pass
            finally:
                if working_emitted:
                    self.post_message(WorkingEnd())

        heartbeat_task = asyncio.create_task(_heartbeat())

        try:
            # Pre-turn hook
            if self.hook_runner and self.hook_runner.has_hooks:
                try:
                    from phoenix.hooks.runner import HookContext, HookEvent

                    hr = await self.hook_runner.run(
                        HookEvent.PRE_TURN,
                        HookContext(
                            event=HookEvent.PRE_TURN,
                            user_input=user_input,
                            turn_count=self.state.turn_count,
                        ),
                    )
                    if hr.feedback:
                        self.post_message(StatusMessage(hr.feedback.strip()))
                    if not hr.allow:
                        self.post_message(StatusMessage("(blocked by hook)"))
                        self.post_message(TurnDone())
                        return
                except Exception as e:
                    log.warning("pre-turn hook failed: %s", e)

            self.post_message(StreamStart())
            chunks: list[str] = []
            try:
                async for event in self.engine.run_stream(user_input, self.active_history):
                    if self._turn_cancel and self._turn_cancel.is_set():
                        break
                    last_chunk_time[0] = _time.monotonic()
                    kind = event[0]
                    if kind == "text":
                        delta = event[1]
                        chunks.append(delta)
                        self.post_message(StreamChunk(delta))
                    elif kind == "tool_call":
                        _, tcid, name, args = event
                        self.post_message(ToolCallEvent(name=name, args=args, tool_call_id=tcid))
                    elif kind == "tool_result":
                        _, tcid, content, is_error = event
                        # Live results -- widget correlates by tool_call_id.
                        self.post_message(
                            ToolResultEvent(
                                name="",
                                result=content,
                                tool_call_id=tcid,
                                is_error=is_error,
                            )
                        )
            finally:
                # Stream chunks are done. Stop the heartbeat BEFORE post-stream
                # work so a second "working" spinner does not appear while
                # memory consolidation / topic tracking run.
                heartbeat_done.set()
                self.post_message(WorkingEnd())

                full = "".join(chunks)
                self.post_message(StreamEnd(full))

            # Usage + history sync happen INSIDE the worker because they're
            # cheap and need to be visible on `self` before the next turn can
            # start. Memory / topic / voice / hook / save are spawned as a
            # separate task so the worker (and thus `is_turn_running`) can
            # return immediately -- otherwise the user's follow-up message
            # sits in "queued" for the 2-5s it takes to consolidate memory.
            usage = self.engine.last_usage
            if usage:
                inp = getattr(usage, "request_tokens", 0) or 0
                out = getattr(usage, "response_tokens", 0) or 0
                if inp or out:
                    self.post_message(TurnUsage(inp, out))

            self.active_history = self.engine.last_history

            asyncio.create_task(self._run_post_stream_bookkeeping(user_input, full))

        except asyncio.CancelledError:
            self.post_message(StatusMessage("(cancelled)"))
        except Exception as e:
            log.exception("turn failed")
            detail = str(e).strip() or repr(e).strip() or "(no detail)"
            # Distinctive edge-400 HTML pattern from Google's front door --
            # always indicates a malformed API key (CRLF / half-pasted).
            # Rewrite the error to tell the user how to fix it instead of
            # leaving them staring at a `<html><title>...!!1</title></html>`
            # blob. See issue #2.
            if "Error 400 (Bad Request)!!1" in detail or "<title>Error 400" in detail:
                # This specific HTML blob is Google's EDGE-routing error, not
                # an API-level auth error. A well-formed Gemini key with the
                # right model + enabled API returns structured JSON, never
                # this HTML. Common causes, in rough order of frequency:
                #   1. Model name not routable for the key/account (e.g.
                #      `gemini-2.0-flash` on an older google-genai client
                #      that only knows `gemini-1.5-flash`)
                #   2. "Generative Language API" not enabled in the Google
                #      Cloud project the key belongs to
                #   3. Key is for a DIFFERENT Google product (Maps, Places,
                #      YouTube) -- they also start with `AIza`
                #   4. Key has an HTTP referrer / IP / app restriction that
                #      blocks non-browser callers
                #   5. CRLF / whitespace in the key (already scrubbed at
                #      load in v0.3.8, so unlikely on current builds)
                detail = (
                    "Google rejected the request at its edge. This is not a "
                    "Phoenix bug -- the URL path or API key is not accepted by "
                    "Google. Most likely causes: (a) try a stabler model -- "
                    "`/model google-gla:gemini-1.5-flash` -- `gemini-2.0-flash` "
                    "may not be routable on older google-genai installs; "
                    "(b) enable 'Generative Language API' in your Google Cloud "
                    "project; (c) make sure the key is a 'Gemini API key', not "
                    "a Maps/Places/YouTube key (all share the `AIza` prefix); "
                    "(d) re-run `phoenix --setup` and re-paste the key. "
                    "See https://github.com/harshalmore31/phoenix-os/issues/3 "
                    "for the full diagnostic checklist."
                )
            self.post_message(TurnError(f"{type(e).__name__}: {detail}"))
        finally:
            heartbeat_done.set()
            with contextlib.suppress(Exception):
                heartbeat_task.cancel()
            self.post_message(TurnDone())

    async def _run_post_stream_bookkeeping(self, user_input: str, full: str) -> None:
        """Memory consolidation + topic tracker + voice + post-turn hook + save.

        Runs as a detached asyncio.Task (NOT a Textual worker) so:
          - It survives the turn worker's exit -> `is_turn_running` flips to
            False as soon as the stream ends, unblocking the next user message.
          - It's NOT bound to the `exclusive=True, group='turn'` worker group,
            so a new turn starting does not cancel in-flight memory writes.
        Failures are logged and swallowed; none of this work is user-facing.
        """
        try:
            try:
                await self.engine.run_after_stream()
            except Exception as e:
                log.warning("run_after_stream failed: %s", e)

            # run_after_stream may have trimmed history on topic shift -- re-sync.
            self.active_history = self.engine.last_history

            if self.voice_daemon is not None and full.strip():
                try:
                    await self.voice_daemon.on_response(full)
                except Exception as e:
                    log.warning("voice on_response failed: %s", e)

            if self.hook_runner and self.hook_runner.has_hooks:
                try:
                    from phoenix.hooks.runner import HookContext, HookEvent

                    hr = await self.hook_runner.run(
                        HookEvent.POST_TURN,
                        HookContext(
                            event=HookEvent.POST_TURN,
                            user_input=user_input,
                            turn_count=self.state.turn_count,
                        ),
                    )
                    if hr.feedback:
                        self.post_message(StatusMessage(hr.feedback.strip()))
                except Exception as e:
                    log.warning("post-turn hook failed: %s", e)

            with contextlib.suppress(Exception):
                self.session.save(self.active_history)
        except Exception as e:
            log.warning("post-stream bookkeeping failed: %s", e)

    # ------------------------------------------------------------- message handlers

    def on_stream_start(self, _: StreamStart) -> None:
        # Do NOT pre-mount AssistantMessageW here. With live tool events, a
        # turn may call a tool BEFORE emitting any text; pre-mounting made the
        # empty assistant widget sit above where the tool widget later
        # appeared. on_stream_chunk lazy-mounts on first text delta, which
        # respects the actual chronological event order.
        self.state.stream_phase = "streaming"
        self._active_assistant = None

    async def on_stream_chunk(self, ev: StreamChunk) -> None:
        self.state.stream_phase = "streaming"
        # If a working indicator was showing, remove it now -- content is flowing
        if self._working_widget is not None:
            with contextlib.suppress(Exception):
                self._working_widget.remove()
            self._working_widget = None
        if self._active_assistant is None:
            self._active_assistant = AssistantMessageW()
            self._append(self._active_assistant)
        await self._active_assistant.append_content(ev.text)
        self._chat.scroll_end(animate=False)

    def on_working_start(self, _: WorkingStart) -> None:
        if self._working_widget is not None:
            return
        self._working_widget = WorkingLineW("working")
        self._append(self._working_widget)

    def on_working_end(self, _: WorkingEnd) -> None:
        if self._working_widget is not None:
            with contextlib.suppress(Exception):
                self._working_widget.remove()
            self._working_widget = None

    async def on_stream_end(self, ev: StreamEnd) -> None:
        if self._active_assistant is not None:
            await self._active_assistant.finalize(ev.full_text)
        self._chat.scroll_end(animate=False)

    def on_tool_call_event(self, ev: ToolCallEvent) -> None:
        self.state.stream_phase = "tool"
        self.state.active_tool = ev.name
        widget = ToolCallMessageW(ev.name, ev.args, tool_call_id=ev.tool_call_id)
        if ev.tool_call_id:
            self._tool_widgets[ev.tool_call_id] = widget
        if self._working_widget is not None:
            with contextlib.suppress(Exception):
                self._working_widget.remove()
            self._working_widget = None
        # Close the current assistant widget so any text that resumes AFTER
        # this tool opens a fresh widget BELOW the tool -- preserves the
        # chronological "preamble text -> tool call -> tool result -> follow-
        # up text" ordering instead of stuffing all text into one widget.
        self._active_assistant = None
        self._append(widget)

    def on_tool_result_event(self, ev: ToolResultEvent) -> None:
        widget = self._tool_widgets.pop(ev.tool_call_id, None) if ev.tool_call_id else None
        if widget is not None:
            with contextlib.suppress(Exception):
                widget.set_result(ev.result, is_error=ev.is_error)
        else:
            # Fallback when correlation fails (older history replay, or a
            # tool_call_id mismatch from the provider). Render inline so the
            # user still sees the result; uses the compat shim.
            self._append(ToolResultMessageW(ev.name, ev.result))
        self.state.active_tool = ""

    def on_turn_usage(self, ev: TurnUsage) -> None:
        self.state.usage_input += ev.input
        self.state.usage_output += ev.output
        self._append(UsageLineW(ev.input, ev.output))

    def on_turn_error(self, ev: TurnError) -> None:
        self._append(ErrorLineW(ev.text))

    def on_turn_done(self, _: TurnDone) -> None:
        self.state.turn_count += 1
        self.state.stream_phase = "idle"
        self.state.active_tool = ""
        self._active_assistant = None
        self._turn_worker = None
        if self._working_widget is not None:
            with contextlib.suppress(Exception):
                self._working_widget.remove()
            self._working_widget = None
        # Any tool widgets still in "pending" state at turn end (e.g. the
        # turn was cancelled before the result arrived) mark as errored so
        # their spinner stops. Then drop references -- the widgets stay
        # mounted, their state just freezes.
        for widget in self._tool_widgets.values():
            if widget._state == "pending":
                with contextlib.suppress(Exception):
                    widget.set_result("(cancelled before completion)", is_error=True)
        self._tool_widgets.clear()
        self.call_after_refresh(self._focus_input)
        self._drain_queue()

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        """Clear turn state when the turn worker transitions to a terminal state."""
        if event.worker is not self._turn_worker:
            return
        if event.state in (WorkerState.SUCCESS, WorkerState.ERROR, WorkerState.CANCELLED):
            # Terminal -- ensure state resets even if TurnDone message was missed.
            self._active_assistant = None
            self._turn_worker = None
            self.state.stream_phase = "idle"
            self.state.active_tool = ""
            self.call_after_refresh(self._focus_input)
            self._drain_queue()

    def on_status_message(self, ev: StatusMessage) -> None:
        self._append(StatusLineW(ev.text))

    def on_notification_message(self, ev: NotificationMessage) -> None:
        self._append(NotifyLineW(ev.text))

    # ------------------------------------------------------------- notifications poller

    async def _poll_welcome_stats(self) -> None:
        """Fetch memory count async and patch the welcome banner."""
        try:
            stats = await self.engine._memory.stats()
            n = stats.get("total", 0)
            if self._welcome_widget is not None and n > 0:
                with contextlib.suppress(Exception):
                    self._welcome_widget.update_memories(n)
        except Exception as e:
            log.debug("welcome stats fetch failed: %s", e)

    async def _poll_notifications(self) -> None:
        try:
            while True:
                try:
                    if self.ambient:
                        for note in self.ambient.get_notifications():
                            self.post_message(NotificationMessage(note))
                except Exception as e:
                    log.warning("notification poll error: %s", e)
                await asyncio.sleep(0.5)
        except asyncio.CancelledError:
            pass

    async def _poll_voice(self) -> None:
        """Read transcribed speech from the voice daemon and submit as chat input."""
        try:
            while True:
                try:
                    text = await self.voice_queue.get()
                    if text and isinstance(text, str) and text.strip():
                        self.post_message(ChatInputSubmitted(text.strip()))
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    log.warning("voice poll error: %s", e)
                    await asyncio.sleep(0.5)
        except asyncio.CancelledError:
            pass

    # ------------------------------------------------------------- actions

    def action_force_quit(self) -> None:
        self._graceful_exit()

    def action_cancel_or_quit(self) -> None:
        # If input has text, clear it. Else if queue/turn, clear/cancel. Else quit.
        input_area = self.query_one(ChatTextArea)
        if input_area.value:
            input_area.value = ""
            return
        if self.state.pending_inputs:
            n = self.state.queued
            self.state.pending_inputs.clear()
            self._append(StatusLineW(f"cleared {n} queued message{'s' if n != 1 else ''}"))
            return
        if self.is_turn_running:
            self._cancel_current_turn()
            return
        self._graceful_exit()

    def action_interrupt(self) -> None:
        if self.is_turn_running:
            self._cancel_current_turn()

    def _cancel_current_turn(self) -> None:
        if self._turn_worker is not None:
            with contextlib.suppress(Exception):
                self._turn_worker.cancel()
        if self._turn_cancel:
            self._turn_cancel.set()

    def action_clear_log(self) -> None:
        # Remove all mounted messages
        for w in list(self._chat.children):
            w.remove()
        self._append(StatusLineW("cleared"))

    def action_cycle_mode(self) -> None:
        from phoenix.core.interceptor import (
            AutoApprovalBackend,
            CLIApprovalBackend,
            get_approval_backend,
            set_approval_backend,
        )

        backend = get_approval_backend()
        current = "safe"
        if isinstance(backend, AutoApprovalBackend):
            current = backend.mode
        order = ["safe", "auto", "yolo"]
        nxt = order[(order.index(current) + 1) % len(order)]
        if nxt == "safe":
            set_approval_backend(CLIApprovalBackend())
        else:
            set_approval_backend(AutoApprovalBackend(nxt))
        self._append(StatusLineW(f"mode: {nxt}"))

    def _graceful_exit(self) -> None:
        # Fire-and-forget cleanup, then exit. Guard against repeat presses.
        if self._exiting:
            return
        self._exiting = True

        async def _cleanup():
            try:
                self.session.save(self.active_history)
                with contextlib.suppress(TimeoutError, asyncio.CancelledError):
                    await asyncio.wait_for(self.engine.create_session_summary(), timeout=10.0)
            except Exception:
                pass
            self.exit()

        asyncio.create_task(_cleanup())


async def run_tui(
    engine,
    session,
    history: list | None = None,
    ambient=None,
    voice_queue=None,
    voice_daemon=None,
    hook_runner=None,
):
    """Public entry point matching run_loop signature."""
    app = PhoenixApp(
        engine=engine,
        session=session,
        history=history,
        ambient=ambient,
        hook_runner=hook_runner,
        voice_queue=voice_queue,
        voice_daemon=voice_daemon,
    )
    await app.run_async()
