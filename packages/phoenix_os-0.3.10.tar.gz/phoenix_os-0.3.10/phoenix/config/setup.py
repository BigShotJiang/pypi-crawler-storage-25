"""First-run setup wizard -- model selection and API key configuration."""

import getpass
import os
import sys
from pathlib import Path

from phoenix.config.secrets import get_secret, store_secret

_PHOENIX_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix"))
_CONFIG_FILE = _PHOENIX_DIR / "config.yaml"

# Colors
DIM = "\033[2m"
BOLD = "\033[1m"
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
BRIGHT_BLACK = "\033[90m"
RESET = "\033[0m"

BOX_H = "\u2500"
BOX_V = "\u2502"
BOX_TL = "\u256d"
BOX_TR = "\u256e"
BOX_BL = "\u2570"
BOX_BR = "\u256f"
ICON_DOT = "\u2022"
ICON_OK = "\u2713"
ICON_KEY = "\u2756"

PROVIDERS = [
    {
        "name": "Anthropic",
        "desc": "Claude Sonnet, Opus, Haiku",
        "key": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "models": [
            ("anthropic:claude-sonnet-4-20250514", "Sonnet 4 -- balanced"),
            ("anthropic:claude-opus-4-20250514", "Opus 4 -- strongest"),
            ("anthropic:claude-haiku-4-20250514", "Haiku 4 -- fastest"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://console.anthropic.com/settings/keys",
    },
    {
        "name": "OpenAI",
        "desc": "GPT-4o, o3-mini",
        "key": "openai",
        "env_var": "OPENAI_API_KEY",
        "models": [
            ("openai:gpt-4o", "GPT-4o -- flagship"),
            ("openai:gpt-4o-mini", "GPT-4o mini -- fast"),
            ("openai:o3-mini", "o3-mini -- reasoning"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://platform.openai.com/api-keys",
    },
    {
        "name": "Google Gemini",
        "desc": "Gemini Flash, Pro",
        "key": "google",
        "env_var": "GEMINI_API_KEY",
        "models": [
            ("google-gla:gemini-2.0-flash", "Flash -- fast"),
            ("google-gla:gemini-2.5-pro-preview-06-05", "Pro -- advanced"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://aistudio.google.com/apikey",
    },
    {
        "name": "Groq",
        "desc": "Fast inference, free tier",
        "key": "groq",
        "env_var": "GROQ_API_KEY",
        "models": [
            ("groq:llama-3.3-70b-versatile", "Llama 3.3 70B"),
            ("groq:llama-3.1-8b-instant", "Llama 3.1 8B -- instant"),
            ("groq:mixtral-8x7b-32768", "Mixtral 8x7B"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://console.groq.com/keys",
    },
    {
        "name": "Ollama",
        "desc": "Local, free, no API key",
        "key": "ollama",
        "env_var": None,
        "models": [
            ("ollama:llama3:8b", "Llama 3 8B"),
            ("ollama:mistral:7b", "Mistral 7B"),
            ("ollama:codellama:13b", "Code Llama 13B"),
        ],
        "default": 0,
        "needs_key": False,
        "key_url": None,
    },
    {
        "name": "Mistral",
        "desc": "Mistral Large, Small",
        "key": "mistral",
        "env_var": "MISTRAL_API_KEY",
        "models": [
            ("mistral:mistral-large-latest", "Large -- flagship"),
            ("mistral:mistral-small-latest", "Small -- efficient"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://console.mistral.ai/api-keys",
    },
    {
        "name": "DeepSeek",
        "desc": "DeepSeek Chat, Reasoner",
        "key": "deepseek",
        "env_var": "DEEPSEEK_API_KEY",
        "models": [
            ("deepseek:deepseek-chat", "Chat"),
            ("deepseek:deepseek-reasoner", "Reasoner"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://platform.deepseek.com/api_keys",
    },
]


EMBEDDING_CHOICES = [
    {
        "key": "gemma",
        "label": "EmbeddingGemma-300M",
        "desc": "~600MB, multilingual (100+ langs incl. Hindi), highest quality",
        "recommended": True,
    },
    {
        "key": "fastembed",
        "label": "MiniLM via FastEmbed",
        "desc": "~90MB, English only, faster, lower memory",
        "recommended": False,
    },
]


def _read_key() -> str:
    """Single keypress reader. Returns 'up', 'down', 'enter', 'esc', or raw char.

    Cross-platform: termios on POSIX (macOS/Linux), msvcrt on Windows.
    """
    if sys.platform == "win32":
        import msvcrt

        ch = msvcrt.getch()
        if ch in (b"\x00", b"\xe0"):  # extended key prefix
            ch2 = msvcrt.getch()
            if ch2 == b"H":
                return "up"
            if ch2 == b"P":
                return "down"
            return ""
        if ch in (b"\r", b"\n"):
            return "enter"
        if ch == b"\x1b":
            return "esc"
        if ch == b"\x03":
            raise KeyboardInterrupt
        try:
            return ch.decode("utf-8", errors="ignore")
        except Exception:
            return ""

    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        if ch == "\x1b":
            # Escape sequence -- arrow or plain ESC
            ch2 = sys.stdin.read(1)
            if ch2 != "[":
                return "esc"
            ch3 = sys.stdin.read(1)
            if ch3 == "A":
                return "up"
            if ch3 == "B":
                return "down"
            return ""
        if ch in ("\r", "\n"):
            return "enter"
        if ch == "\x03":
            raise KeyboardInterrupt
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _select_with_arrows(choices: list[dict], default: int = 0) -> int | None:
    """Arrow-key navigation over choices. Returns selected index, or None if cancelled."""
    idx = default
    n = len(choices)

    def _render():
        for i, c in enumerate(choices):
            marker = f"{GREEN}{BOLD}>{RESET}" if i == idx else " "
            rec = f" {GREEN}(recommended){RESET}" if c.get("recommended") else ""
            label = f"{BOLD}{c['label']}{RESET}" if i == idx else c["label"]
            print(f"  {marker} {label}{rec}")
            print(f"     {BRIGHT_BLACK}{c['desc']}{RESET}")

    print(
        f"  {BRIGHT_BLACK}Use {BOLD}{UP_KEY}/{DOWN_KEY}{RESET}{BRIGHT_BLACK} arrows, Enter to confirm.{RESET}"
    )
    print()
    _render()

    # Number of lines rendered per option (label + description = 2 lines)
    lines_per_option = 2
    total_lines = n * lines_per_option

    while True:
        try:
            key = _read_key()
        except KeyboardInterrupt:
            print()
            return None

        prev_idx = idx
        if key == "up":
            idx = max(0, idx - 1)
        elif key == "down":
            idx = min(n - 1, idx + 1)
        elif key == "enter":
            return idx
        elif key == "esc":
            return None
        else:
            continue

        if idx == prev_idx:
            continue

        # Move up total_lines and clear from here to end of screen
        print(f"\033[{total_lines}A", end="")
        print("\033[J", end="")
        _render()


# Arrow key glyphs for the help text.
UP_KEY = "\u2191"
DOWN_KEY = "\u2193"


def needs_setup() -> bool:
    """Check if first-run setup is needed.

    Looks for a configured LLM model, not just a config file. Otherwise an
    `--embedder fastembed` invocation on a fresh install would create a
    config.yaml with only embedding_backend set, making needs_setup() return
    False and booting an engine with no model.
    """
    if os.environ.get("PHOENIX_MODEL"):
        return False
    if load_config().get("model"):
        return False
    return all(not (p["env_var"] and os.environ.get(p["env_var"])) for p in PROVIDERS)


def _prompt(msg: str) -> str:
    """Styled input prompt."""
    try:
        return input(f"  {GREEN}{BOLD}>{RESET} {msg}").strip()
    except (KeyboardInterrupt, EOFError):
        return ""


def _step_header(step: int, total: int, title: str):
    print()
    print(f"  {BRIGHT_BLACK}[{step}/{total}]{RESET} {BOLD}{title}{RESET}")
    print()


def run_setup() -> dict | None:
    """Run interactive setup wizard."""
    w = 60
    bar = BOX_H * w

    print()
    print(f"  {DIM}{BOX_TL}{bar}{BOX_TR}{RESET}")
    print(f"  {DIM}{BOX_V}{RESET} {BOLD}Phoenix Setup{RESET}")
    print(f"  {DIM}{BOX_V}{RESET}")
    print(
        f"  {DIM}{BOX_V}{RESET} {BRIGHT_BLACK}First-time configuration. API keys are stored{RESET}"
    )
    print(f"  {DIM}{BOX_V}{RESET} {BRIGHT_BLACK}securely in your OS keychain.{RESET}")
    print(f"  {DIM}{BOX_BL}{bar}{BOX_BR}{RESET}")

    # -- Step 1: Provider --
    _step_header(1, 4, "Choose an LLM provider")

    for i, p in enumerate(PROVIDERS, 1):
        name = p["name"]
        desc = p["desc"]
        badge = f" {GREEN}free{RESET}" if not p["needs_key"] else ""
        print(f"    {CYAN}{i}{RESET}  {name}{badge}  {BRIGHT_BLACK}{desc}{RESET}")
    print()

    provider = None
    while provider is None:
        choice = _prompt(f"Provider (1-{len(PROVIDERS)}): ")
        if not choice:
            print(f"\n  {DIM}Setup cancelled.{RESET}\n")
            return None
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(PROVIDERS):
                provider = PROVIDERS[idx]
        except ValueError:
            pass
        if provider is None:
            print(f"    {RED}Invalid choice.{RESET}")

    print(f"    {ICON_OK} {provider['name']}")

    # -- Step 2: Model --
    _step_header(2, 4, "Choose a model")

    models = provider["models"]
    for i, (model_id, desc) in enumerate(models, 1):
        default = f" {GREEN}(default){RESET}" if i == 1 else ""
        print(f"    {CYAN}{i}{RESET}  {model_id}  {BRIGHT_BLACK}{desc}{RESET}{default}")
    print()

    model = None
    while model is None:
        choice = _prompt(f"Model (1-{len(models)}) or Enter for default: ")
        if not choice:
            model = models[provider["default"]][0]
            break
        if choice == "":
            print(f"\n  {DIM}Setup cancelled.{RESET}\n")
            return None
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                model = models[idx][0]
        except ValueError:
            pass
        if model is None:
            print(f"    {RED}Invalid choice.{RESET}")

    print(f"    {ICON_OK} {model}")

    # -- Step 3: API key --
    api_key = None
    if provider["needs_key"]:
        _step_header(3, 4, "API key")

        env_var = provider["env_var"]
        existing = get_secret(env_var)

        if existing:
            masked = existing[:6] + "..." + existing[-4:]
            print(f"    {BRIGHT_BLACK}Existing key: {masked}{RESET}")
            keep = _prompt("Keep this key? (Y/n): ")
            if keep.lower() not in ("n", "no"):
                # Verify the existing key before accepting. Catches the case
                # where a user stored a broken key on an older Phoenix (before
                # the verifier shipped) and now expects it to work.
                from phoenix.config.setup_verify import verify_api_key

                print(f"    {BRIGHT_BLACK}Verifying stored key with {provider['name']}...{RESET}")
                result = verify_api_key(provider["key"], existing)
                if result.ok:
                    api_key = existing
                else:
                    print(f"    {RED}Stored key failed verification: {result.message}{RESET}")
                    print(f"    {YELLOW}Please paste a fresh key.{RESET}")
                    # Fall through to the paste branch below.

        # Verify BEFORE storing. Paste + verify + retry up to 3 times. Mirrors
        # the HF `whoami` guarantee in setup_embeddings: if setup says
        # "verified", runtime never sees a surprise edge-400 from a wrong
        # product/scope/revoked key.
        if api_key is None:
            from phoenix.config.setup_verify import verify_api_key

            if provider.get("key_url"):
                print(f"    {BRIGHT_BLACK}Get your key: {provider['key_url']}{RESET}")
                print()

            attempts = 3
            while attempts > 0:
                try:
                    pasted = getpass.getpass(
                        f"  {GREEN}{BOLD}>{RESET} Paste {provider['name']} API key: "
                    )
                except (KeyboardInterrupt, EOFError):
                    print(f"\n  {DIM}Setup cancelled.{RESET}\n")
                    return None

                pasted = pasted.strip()
                if not pasted:
                    print(f"    {RED}No key entered.{RESET}\n")
                    return None

                print(f"    {BRIGHT_BLACK}Verifying key with {provider['name']}...{RESET}")
                result = verify_api_key(provider["key"], pasted)
                if result.ok:
                    api_key = pasted
                    break

                attempts -= 1
                print(f"    {RED}{result.message}{RESET}")
                if attempts == 0:
                    print(
                        f"    {YELLOW}Giving up after 3 attempts. "
                        f"Skipping verification and storing anyway "
                        f"-- you can retry via `phoenix --setup`.{RESET}"
                    )
                    api_key = pasted
                    break
                skip = _prompt(f"Try again? ({attempts} left) [Y/n/skip]: ")
                if skip.lower() in ("n", "no"):
                    print(f"\n  {DIM}Setup cancelled.{RESET}\n")
                    return None
                if skip.lower() == "skip":
                    print(f"    {YELLOW}Storing unverified key. May fail at runtime.{RESET}")
                    api_key = pasted
                    break

        if api_key is None:
            return None

        store_secret(env_var, api_key)
        os.environ[env_var] = api_key
        print(f"    {GREEN}{ICON_OK} Key stored in OS keychain{RESET}")
    else:
        print()
        print(f"  {BRIGHT_BLACK}[3/4]{RESET} {BOLD}API key{RESET}  {GREEN}not needed{RESET}")

    # -- Step 4: Embedding model --
    _step_header(4, 4, "Choose an embedding model (memory quality)")

    embedding_idx = _select_with_arrows(EMBEDDING_CHOICES, default=0)
    if embedding_idx is None:
        print(f"\n  {DIM}Setup cancelled.{RESET}\n")
        return None

    embedding_choice = EMBEDDING_CHOICES[embedding_idx]
    embedding_backend = embedding_choice["key"]
    print()
    print(f"    {ICON_OK} {embedding_choice['label']}")

    # Save config before HF auth -- the LLM config is valid even if HF fails,
    # so the user can retry embeddings via `phoenix --setup` or fall back via
    # `phoenix --embedder fastembed` without re-entering their API key.
    config = {
        "model": model,
        "provider": provider["key"],
        "embedding_backend": embedding_backend,
    }
    _save_config(config)

    if embedding_backend == "gemma":
        from phoenix.config.setup_embeddings import HFSetupError, setup_gemma_auth

        try:
            setup_gemma_auth()
        except HFSetupError:
            sys.exit(1)

    print()
    print(f"  {DIM}{BOX_TL}{bar}{BOX_TR}{RESET}")
    print(
        f"  {DIM}{BOX_V}{RESET} {GREEN}{BOLD}"
        f"Ready.{RESET} {BRIGHT_BLACK}"
        f"Exit and run 'phoenix' to start.{RESET}"
    )
    print(f"  {DIM}{BOX_BL}{bar}{BOX_BR}{RESET}")
    print()

    return config


def load_config() -> dict:
    """Load saved config."""
    if not _CONFIG_FILE.exists():
        return {}
    try:
        import yaml

        return yaml.safe_load(_CONFIG_FILE.read_text()) or {}
    except Exception:
        return {}


def _save_config(config: dict):
    _PHOENIX_DIR.mkdir(parents=True, exist_ok=True)
    try:
        import yaml

        _CONFIG_FILE.write_text(yaml.dump(config, default_flow_style=False))
    except ImportError:
        lines = [f"{k}: {v}" for k, v in config.items()]
        _CONFIG_FILE.write_text("\n".join(lines) + "\n")


def apply_config():
    """Load saved config and apply. Called at startup."""
    config = load_config()
    if not config:
        return

    model = config.get("model")
    if model and not os.environ.get("PHOENIX_MODEL"):
        os.environ["PHOENIX_MODEL"] = model
        from phoenix.config.settings import set_model

        set_model(model)

    backend = config.get("embedding_backend")
    if backend and not os.environ.get("PHOENIX_EMBEDDING_BACKEND"):
        os.environ["PHOENIX_EMBEDDING_BACKEND"] = backend


def set_embedder(backend: str) -> None:
    """One-shot: rewrite embedding_backend in config.yaml and print a confirmation.

    Invoked via `phoenix --embedder {gemma,fastembed}`. Used as the escape
    hatch when Hugging Face auth for Gemma fails -- lets the user switch to
    FastEmbed without re-running full setup.
    """
    if backend not in ("gemma", "fastembed"):
        print(f"  {RED}Unknown backend: {backend}.{RESET} Valid: gemma, fastembed.")
        return

    config = load_config()
    config["embedding_backend"] = backend
    _save_config(config)

    print()
    print(f"  {GREEN}{ICON_OK}{RESET} Embedding backend set to {BOLD}{backend}{RESET}")
    if backend == "gemma":
        print(
            f"  {BRIGHT_BLACK}Run 'phoenix --setup' to complete Hugging Face auth "
            f"if you have not already.{RESET}"
        )
    else:
        print(f"  {BRIGHT_BLACK}FastEmbed / MiniLM is English-only. Run 'phoenix' to start.{RESET}")
    print()
