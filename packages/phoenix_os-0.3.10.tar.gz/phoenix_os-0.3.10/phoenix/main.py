"""Phoenix main -- async entry point."""

import argparse
import asyncio

from phoenix.config.settings import get_model, set_model, setup_logging
from phoenix.core.engine import PhoenixEngine
from phoenix.shell.session import SessionManager


def parse_args():
    parser = argparse.ArgumentParser(description="Phoenix -- AI agent OS")
    parser.add_argument("--model", metavar="MODEL", help="Model override (e.g. openai:gpt-4o)")
    parser.add_argument("--yolo", action="store_true", help="Auto-approve all tool calls")
    parser.add_argument("--auto", action="store_true", help="Auto-approve file edits, ask for bash")
    parser.add_argument("--sessions", action="store_true", help="List saved sessions")
    parser.add_argument(
        "--continue",
        dest="continue_session",
        action="store_true",
        help="Resume the most recent session",
    )
    parser.add_argument("--resume", metavar="SESSION_ID", help="Resume a specific session")
    parser.add_argument("--voice", action="store_true", help="Enable voice I/O (say 'Phoenix')")
    parser.add_argument("--setup", action="store_true", help="Run setup wizard")
    parser.add_argument(
        "--embedder",
        choices=["gemma", "fastembed"],
        metavar="{gemma,fastembed}",
        help="Set embedding backend in ~/.phoenix/config.yaml and exit "
        "(escape hatch when Hugging Face auth fails)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable DEBUG-level file logging to ~/.phoenix/logs/phoenix.log",
    )
    parser.add_argument(
        "--logs",
        action="store_true",
        help="Print the log directory path + recent lines, then exit",
    )
    parser.add_argument(
        "--skip-key-check",
        action="store_true",
        help="Skip the one-time API-key verification at startup "
        "(use when offline or when the provider's /models endpoint is flaky)",
    )
    return parser.parse_args()


async def main():
    setup_logging()
    args = parse_args()

    # File-based logging -- must happen before Textual hijacks stdio.
    from phoenix.logging_setup import LOG_FILE, configure_logging, tail

    configure_logging(verbose=args.verbose)

    if args.logs:
        print(f"Log file: {LOG_FILE}")
        print(f"Log directory: {LOG_FILE.parent}")
        print()
        print("Recent entries:")
        print("-" * 60)
        print(tail(30))
        return

    # Load secrets from OS keychain into env vars
    from phoenix.config.secrets import load_secrets_to_env

    load_secrets_to_env()

    # Apply saved config (model from ~/.phoenix/config.yaml)
    from phoenix.config.setup import apply_config, needs_setup, run_setup, set_embedder

    # --embedder is a one-shot escape hatch: rewrite config.yaml and exit.
    # Used when Hugging Face auth for Gemma fails and the user wants to
    # fall back to FastEmbed (English-only) without re-running full setup.
    if args.embedder:
        set_embedder(args.embedder)
        return

    # Run setup wizard if --setup flag or first run
    if args.setup or needs_setup():
        result = run_setup()
        if result is None:
            return
        if args.setup:
            return

    apply_config()

    if args.model:
        set_model(args.model)

    # Pre-flight: verify the active model's API key BEFORE the TUI boots.
    # Prevents the "I already upgraded but still hit edge-400" trap where a
    # stale broken key is sitting in the keychain from before v0.3.9's setup
    # verifier shipped. Users only hit this once per bad-key rotation; a
    # working key skips the check after ~2 seconds of real latency.
    if not args.skip_key_check and not args.sessions:
        _verify_active_provider_key()

    if args.sessions:
        sessions = SessionManager.list_sessions()
        if not sessions:
            print("No saved sessions.")
        else:
            print(f"{'ID':<14} {'Messages':>8}  {'Last Active':<20}  {'Directory'}")
            print("-" * 80)
            for s in sessions:
                print(
                    f"{s.get('session_id', '?'):<14} "
                    f"{s.get('message_count', 0):>8}  "
                    f"{s.get('last_active', '?')[:19]:<20}  "
                    f"{s.get('working_dir', '?')}"
                )
        return

    if args.yolo or args.auto:
        from phoenix.core.interceptor import AutoApprovalBackend, set_approval_backend

        mode = "yolo" if args.yolo else "auto"
        set_approval_backend(AutoApprovalBackend(mode))

    session = None
    history = None

    if args.resume:
        session = SessionManager(args.resume)
        history = session.load()
        if not history:
            print(f"Session '{args.resume}' not found or empty.")
            return
        print(f"Resuming session: {args.resume}")
    elif args.continue_session:
        sid = SessionManager.get_latest_session_id()
        if sid:
            session = SessionManager(sid)
            history = session.load()
            print(f"Resuming session: {sid}")
        else:
            print("No previous session found. Starting new session.")

    if session is None:
        session = SessionManager()

    # Load hooks
    from phoenix.hooks.loader import load_hooks_config

    hook_runner = load_hooks_config()

    # Initialize memory
    from phoenix.memory import MemorySystem

    memory = MemorySystem()

    # Warm up the embedder BEFORE Textual hijacks stdio. SentenceTransformer
    # spawns subprocesses on first load that inherit stdout/stderr filenos;
    # Textual replaces those with wrappers whose fileno() returns an invalid
    # FD, so fork_exec rejects them with `bad value(s) in fds_to_keep`. We
    # cannot async-defer this (v0.3.1 hotfix). Side benefits: classifier
    # build (52 Gemma anchor encodes, ~2-4s) is done before the first turn,
    # so first pre_turn / post_turn is warm.
    print("Loading embedding model...", flush=True)
    try:
        await memory.warm_up()
    except Exception as e:
        print(f"Embedding warm-up failed: {type(e).__name__}: {e}", flush=True)
        print(flush=True)
        print("Memory cannot initialize. Fix with one of:", flush=True)
        print(
            "  phoenix --setup              retry Hugging Face auth for Gemma",
            flush=True,
        )
        print(
            "  phoenix --embedder fastembed  switch to MiniLM (English-only, no HF auth)",
            flush=True,
        )
        await memory.close()
        return

    # Boot engine with session context
    engine = PhoenixEngine()
    await engine.boot(
        memory=memory,
        hook_runner=hook_runner,
        session_id=session.session_id,
    )

    # Start ambient daemon
    from phoenix.ambient.daemon import AmbientDaemon

    ambient = AmbientDaemon(model=get_model(), memory=memory)
    ambient_task = asyncio.create_task(ambient.run())

    # Start voice daemon (optional)
    voice_task = None
    voice_queue = None
    voice_daemon = None
    if args.voice:
        try:
            from phoenix.voice.config import VoiceConfig
            from phoenix.voice.daemon import VoiceDaemon

            voice_daemon = VoiceDaemon(config=VoiceConfig())
            voice_queue = voice_daemon.voice_queue
            voice_task = asyncio.create_task(voice_daemon.run())
        except ImportError:
            print("Voice dependencies not installed. Run: pip install phoenix-os[voice]")

    try:
        from phoenix.tui import run_tui

        await run_tui(
            engine=engine,
            session=session,
            history=history,
            ambient=ambient,
            voice_queue=voice_queue,
            voice_daemon=voice_daemon,
            hook_runner=hook_runner,
        )
    finally:
        ambient.stop()
        ambient_task.cancel()
        if voice_task:
            voice_daemon.stop()
            voice_task.cancel()
        try:
            await ambient_task
            if voice_task:
                await voice_task
        except asyncio.CancelledError:
            pass
        await memory.close()


_PROVIDER_ENV_MAP = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "google-gla": "GEMINI_API_KEY",
    "groq": "GROQ_API_KEY",
    "mistral": "MISTRAL_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}

_PROVIDER_TO_VERIFIER_KEY = {
    "anthropic": "anthropic",
    "openai": "openai",
    "google-gla": "google",
    "groq": "groq",
    "mistral": "mistral",
    "deepseek": "deepseek",
    "openrouter": "openrouter",
}


def _verify_active_provider_key() -> None:
    """One-shot pre-flight: ping the active provider's /models endpoint and
    abort with an actionable message if the stored key is rejected.

    Only checks the CURRENT model's provider -- not all keys in the keychain.
    A typical launch adds ~1-2s of latency; a broken key saves the user from
    hitting the opaque Google edge-400 (or similar) mid-turn.

    Silent no-op when:
      - Provider doesn't need a key (Ollama)
      - Provider isn't in our verifier map (forward-compat for new providers)
      - The key is missing from env entirely (let the setup wizard handle it)
    """
    import os as _os
    import sys as _sys

    from phoenix.config.settings import get_model

    model = get_model()
    provider = model.split(":", 1)[0] if ":" in model else ""
    env_var = _PROVIDER_ENV_MAP.get(provider)
    verifier_key = _PROVIDER_TO_VERIFIER_KEY.get(provider)
    if not env_var or not verifier_key:
        return  # Ollama or unknown provider -- skip

    api_key = _os.environ.get(env_var, "")
    if not api_key:
        print(f"  {env_var} is not set. Run `phoenix --setup`.")
        _sys.exit(1)

    from phoenix.config.setup_verify import verify_api_key

    print(f"  Verifying {provider} key...", flush=True)
    result = verify_api_key(verifier_key, api_key)
    if result.ok:
        return

    # Fail loudly with exactly what Mandar needs to know. Exit before the TUI
    # boots so the error lands on the real terminal, not in a Textual line.
    print()
    print(f"  ERROR: {provider} rejected the stored API key.")
    print(f"    {result.message}")
    print()
    print("  To fix:")
    if provider == "google-gla":
        print("    1. Get a fresh key from https://aistudio.google.com/apikey")
        print("       (AI Studio keys automatically have Generative Language API enabled;")
        print("        Cloud Console keys must have that API enabled manually)")
        print("    2. Run `phoenix --setup` and paste the new key")
    else:
        print(f"    1. Check your {provider} account dashboard for key status")
        print("    2. Run `phoenix --setup` and paste a fresh key")
    print()
    print("  Or bypass this check with `phoenix --skip-key-check` if you need to launch anyway.")
    print()
    _sys.exit(1)


def run():
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBye, Boss.")


if __name__ == "__main__":
    run()
