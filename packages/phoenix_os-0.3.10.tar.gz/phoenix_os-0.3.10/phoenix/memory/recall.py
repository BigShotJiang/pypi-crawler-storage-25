"""Recall engine -- semantic + strength + recency + graph + context + tension."""

import asyncio
import logging
import math
import time
from datetime import datetime

import numpy as np

from .config import CATEGORY_IMPORTANCE, MemoryParams
from .embeddings import EmbeddingService
from .extractor import sigmoid
from .store import MemoryStore

log = logging.getLogger(__name__)

# Queries below this length, or equal to a common stopword, cannot carry
# enough signal to be worth an embed + full pipeline. They short-circuit
# at the top of recall() to an empty result. Mirrors the bridge-level gate
# in phoenix-mcp-bridge/tools.py so in-process callers (pre_turn,
# recall_for_agent) get the same protection.
_MIN_QUERY_LEN = 3
_COMMON_STOPWORDS = frozenset(
    {
        "the",
        "a",
        "an",
        "is",
        "are",
        "i",
        "me",
        "my",
        "and",
        "or",
        "but",
        "it",
        "this",
        "that",
        "of",
        "to",
    }
)


class RecallEngine:
    """Retrieves and ranks memories using composite scoring."""

    def __init__(self, config: MemoryParams, embedder: EmbeddingService, store: MemoryStore):
        self.config = config
        self.embedder = embedder
        self.store = store
        self._context_vector: np.ndarray | None = None
        self._last_recalled: list[dict] = []
        # Per-candidate breakdown from the most recent recall. Drives
        # /memory why. Includes candidates rejected pre-scoring so every
        # memory is accounted for. Reset at the top of every recall.
        self._last_breakdown: list[dict] = []
        self._last_query: str = ""
        # Serialises access to _last_breakdown / _last_recalled / _last_query.
        # Without this, a /memory trace fired while pre_turn is mid-flight
        # would clobber the breakdown in-progress.
        self._recall_lock = asyncio.Lock()
        self._adaptive_importance: dict[str, float] = {}

    def update_context(self, user_input: str):
        """Update EMA context vector from user input."""
        emb = self.embedder.embed_query(user_input)
        lam = self.config.context_lambda
        if self._context_vector is None:
            self._context_vector = emb.copy()
        else:
            vec = lam * self._context_vector + (1 - lam) * emb
            norm = float(np.linalg.norm(vec))
            if norm > 1e-9:
                vec = vec / norm
            self._context_vector = vec

    async def recall(
        self,
        query: str,
        namespace: str = "global",
        top_k: int | None = None,
        record_access: bool = True,
    ) -> list[dict]:
        """Full recall pipeline.

        `record_access=False` skips `store.increment_access(...)` so /memory
        trace can inspect the pipeline without polluting hit counts.
        """
        async with self._recall_lock:
            return await self._recall_inner(query, namespace, top_k, record_access)

    async def _recall_inner(
        self,
        query: str,
        namespace: str,
        top_k: int | None,
        record_access: bool,
    ) -> list[dict]:
        start = time.monotonic()
        top_k = top_k or self.config.top_k
        log.debug("recall.start: ns=%s top_k=%d q=%r", namespace, top_k, query[:80])

        # Reset breakdown at the top of every call. /memory why only ever
        # shows the most recent.
        self._last_query = query

        # Query-quality gate. Short or stopword-only queries do not carry
        # enough signal; returning empty here skips the embed + pipeline cost
        # and avoids surfacing weak matches to a trivial input.
        stripped = query.strip()
        if len(stripped) < _MIN_QUERY_LEN or stripped.lower() in _COMMON_STOPWORDS:
            self._last_recalled = []
            self._last_breakdown = [
                {
                    "id": "<query-gate>",
                    "sem_score": 0.0,
                    "composite_score": 0.0,
                    "direct_relevance": None,
                    "pinned": False,
                    "passed_gate": False,
                    "gate_reason": "query_rejected_degenerate",
                    "content": f"(query {query!r} rejected: too short or stopword-only)",
                    "category": "-",
                    "strength": 0.0,
                }
            ]
            log.debug("recall.rejected: degenerate query %r", query[:40])
            return []

        query_emb = self.embedder.embed_query(query)
        ids, matrix, rows = await self.store.get_all_embeddings(namespace)
        if len(ids) == 0:
            self._last_recalled = []
            self._last_breakdown = []
            log.debug("recall.empty: ns=%s has no memories", namespace)
            return []

        # Context blending
        effective_query = self._get_effective_query(query_emb, matrix)

        # Semantic similarities
        sims = EmbeddingService.cosine_similarity_matrix(effective_query, matrix)

        # Composite scoring -- seed breakdown for ALL candidates so rejections
        # are visible, not just survivors.
        now = time.time()
        scores = np.zeros(len(ids))
        id_to_meta: dict[str, dict] = {}
        breakdown: dict[str, dict] = {}

        for i, mid in enumerate(ids):
            sem = float(sims[i])
            mem_row = rows[i]
            breakdown[mid] = {
                "id": mid,
                "sem_score": round(sem, 3),
                "composite_score": 0.0,
                "direct_relevance": None,
                "pinned": bool(mem_row.get("pinned")),
                "passed_gate": False,
                "gate_reason": "below_min_relevance_pre_score",
                "content": (mem_row.get("content") or "")[:200],
                "category": mem_row.get("category", "?"),
                "strength": round(float(mem_row.get("strength", 0.0)), 3),
            }
            if sem < self.config.min_relevance:
                continue

            mem = mem_row

            # Strength compression (BM25-style)
            strength = mem.get("strength", 1.0)
            compressed = strength**self.config.strength_compression
            access_bonus = 1.0 + 0.1 * math.log1p(mem.get("access_count", 0))

            # Recency
            age = max(now - (mem.get("created_at", now)), 1.0)
            recency = math.exp(-age * math.log(2) / self.config.recency_halflife)

            # Adaptive importance
            cat = mem.get("category", "fact")
            importance = self._adaptive_importance.get(cat, CATEGORY_IMPORTANCE.get(cat, 1.0))

            score = sem * compressed * access_bonus * importance
            score = score * (1 - self.config.recency_weight + self.config.recency_weight * recency)
            if mem.get("pinned"):
                score *= self.config.pinned_boost
                mem["pinned"] = True
            scores[i] = score
            id_to_meta[mid] = mem
            b = breakdown[mid]
            b["composite_score"] = round(float(score), 3)
            b["gate_reason"] = "reached_scoring"

        # Spreading activation (multi-hop BFS)
        scores = await self._spread_activation(ids, scores)
        # Post-spread scores can differ. Update breakdown entries that
        # survived to scoring (others keep their pre-score reject reason).
        for i, mid in enumerate(ids):
            if breakdown[mid]["gate_reason"] == "reached_scoring":
                breakdown[mid]["composite_score"] = round(float(scores[i]), 3)

        # Rank
        ranked_indices = np.argsort(-scores)
        results = []
        seen = set()
        index_of: dict[str, int] = {mid: i for i, mid in enumerate(ids)}

        for pos, idx in enumerate(ranked_indices):
            if scores[idx] < self.config.min_relevance:
                # Mark all remaining (lower-scored) candidates.
                for rem_idx in ranked_indices[pos:]:
                    mid_rem = ids[rem_idx]
                    if breakdown[mid_rem]["gate_reason"] == "reached_scoring":
                        breakdown[mid_rem]["gate_reason"] = "below_min_relevance_post_spread"
                break
            mid = ids[idx]
            if mid in seen:
                breakdown[mid]["gate_reason"] = "duplicate_skipped"
                continue
            seen.add(mid)
            mem = id_to_meta.get(mid) or rows[index_of[mid]]
            if not mem:
                breakdown[mid]["gate_reason"] = "store_lookup_failed"
                continue
            mem["relevance"] = round(float(scores[idx]), 3)
            breakdown[mid]["composite_score"] = mem["relevance"]
            results.append(mem)
            if record_access:
                await self.store.increment_access(mid)
            if len(results) >= top_k * 3:
                for rem_idx in ranked_indices[pos + 1 :]:
                    mid_rem = ids[rem_idx]
                    if breakdown[mid_rem]["gate_reason"] == "reached_scoring":
                        breakdown[mid_rem]["gate_reason"] = "topk_cap_exceeded"
                break

        # Tension detection
        self._detect_tensions(results)

        # Relevance gate (direct query-to-content).
        # Pinned memories pass through the same gate as everything else so
        # they don't surface on unrelated queries. Their boost in the scoring
        # loop gives them the tie-break advantage they deserve.
        gated = []
        for mem in results:
            mid = mem.get("id", "")
            if mem.get("embedding") is not None:
                direct = EmbeddingService.cosine_similarity(query_emb, mem["embedding"])
                if mid in breakdown:
                    breakdown[mid]["direct_relevance"] = round(direct, 3)
                if direct >= self.config.relevance_gate_threshold:
                    mem["direct_relevance"] = round(direct, 3)
                    gated.append(mem)
                    if mid in breakdown:
                        breakdown[mid]["passed_gate"] = True
                        breakdown[mid]["gate_reason"] = "passed"
                else:
                    if mid in breakdown:
                        breakdown[mid]["gate_reason"] = "below_direct_relevance_gate"
            else:
                # No embedding -- rare, but avoid leaving the entry in the
                # non-terminal "reached_scoring" state.
                if mid in breakdown:
                    breakdown[mid]["gate_reason"] = "no_embedding_skipped"

        # Sort by relevance and limit
        gated.sort(key=lambda m: m.get("relevance", 0), reverse=True)

        # Single-result edge rule (see the comment on the original
        # implementation above for context). If fires, mark the single
        # survivor as suppressed in the breakdown so /memory why explains
        # why nothing was returned.
        if len(gated) == 1 and len(ids) >= 10:
            top = gated[0]
            direct = top["direct_relevance"]
            if direct < self.config.relevance_gate_threshold * 1.15:
                self._last_recalled = []
                tmid = top.get("id", "")
                if tmid in breakdown:
                    breakdown[tmid]["passed_gate"] = False
                    breakdown[tmid]["gate_reason"] = "suppressed_single_weak"
                self._last_breakdown = sorted(
                    breakdown.values(), key=lambda b: b["composite_score"], reverse=True
                )
                log.debug(
                    "recall.single_weak: suppressed direct=%.3f < %.3f",
                    direct,
                    self.config.relevance_gate_threshold * 1.15,
                )
                return []

        self._last_recalled = gated[:top_k]
        self._last_breakdown = sorted(
            breakdown.values(), key=lambda b: b["composite_score"], reverse=True
        )
        elapsed = time.monotonic() - start
        log.info(
            "recall.done: ns=%s candidates=%d scored=%d gated=%d returned=%d dur=%.3fs",
            namespace,
            len(ids),
            len(results),
            len(gated),
            len(self._last_recalled),
            elapsed,
        )
        return self._last_recalled

    async def trace(
        self, query: str, namespace: str = "global", top_k: int | None = None
    ) -> list[dict]:
        """Like recall() but does not mutate hit counters. For /memory trace.

        Holds `_recall_lock` across BOTH `_recall_inner` and the final
        breakdown copy so a concurrent recall (e.g. ambient daemon) can't
        overwrite `_last_breakdown` between our unlock and our read. Mirrors
        the lock discipline the public `recall()` uses -- we call
        `_recall_inner` directly to avoid the non-reentrant `asyncio.Lock`
        re-acquire that would deadlock.
        """
        async with self._recall_lock:
            await self._recall_inner(query, namespace, top_k, record_access=False)
            return list(self._last_breakdown)

    async def recall_objective(
        self,
        query: str,
        namespace: str = "global",
        top_k: int | None = None,
    ) -> list[dict]:
        """Recall without preferences or emotional intents. For anti-sycophancy."""
        results = await self.recall(query, namespace, top_k=(top_k or self.config.top_k) * 2)
        return [
            m
            for m in results
            if m.get("category") not in ("preference",)
            and m.get("intent") not in ("venting", "excited")
        ][: top_k or self.config.top_k]

    async def feedback(self, ai_output: str) -> dict:
        """Strengthen memories the AI actually used in its response."""
        if not self._last_recalled or not ai_output:
            return {"strengthened": 0}

        ai_emb = self.embedder.embed_document(ai_output[:500])
        strengthened = 0
        co_used = []

        for mem in self._last_recalled:
            if mem.get("embedding") is None:
                continue
            alignment = EmbeddingService.cosine_similarity(ai_emb, mem["embedding"])
            if alignment >= self.config.feedback_align_threshold:
                current = mem.get("strength", 1.0)
                new_strength = min(
                    current + self.config.feedback_strengthen_rate,
                    self.config.strength_cap,
                )
                await self.store.update_strength(mem["id"], new_strength)
                await self.store.increment_access(mem["id"])
                strengthened += 1
                co_used.append(mem["id"])

                # Update adaptive weights
                cat = mem.get("category", "fact")
                old = self._adaptive_importance.get(cat, CATEGORY_IMPORTANCE.get(cat, 1.0))
                self._adaptive_importance[cat] = (
                    self.config.adaptive_ema * old + (1 - self.config.adaptive_ema) * alignment
                )

        # Boost edges between co-used memories
        edges_boosted = 0
        for i in range(len(co_used)):
            for j in range(i + 1, len(co_used)):
                await self.store.add_edge(
                    co_used[i],
                    co_used[j],
                    weight=self.config.feedback_edge_boost,
                    reinforce_amount=self.config.feedback_edge_boost,
                )
                edges_boosted += 1

        return {"strengthened": strengthened, "edges_boosted": edges_boosted}

    def format_for_prompt(self, memories: list[dict], max_tokens: int | None = None) -> str:
        """Format recalled memories for system prompt injection."""
        max_tokens = max_tokens or self.config.max_inject_tokens
        if not memories:
            return ""

        char_budget = max_tokens * 4
        now = time.time()
        lines = [f"[Memory Context -- {len(memories)} entries from previous sessions]"]
        lines.append(f"Current time: {datetime.now().strftime('%A, %B %d, %Y at %I:%M %p')}")
        chars_used = sum(len(line) for line in lines)

        for mem in memories:
            content = mem.get("content", "")[:200]
            category = mem.get("category", "fact")
            strength = mem.get("strength", 1.0)
            access = mem.get("access_count", 0)
            created = mem.get("created_at", now)
            age = now - created

            if age < 3600:
                age_str = f"{int(age / 60)}m ago"
            elif age < 86400:
                age_str = f"{int(age / 3600)}h ago"
            else:
                age_str = f"{int(age / 86400)}d ago"

            flags = []
            if mem.get("pinned"):
                flags.append("PINNED")
            # NOTE: tension_with is computed internally but intentionally NOT surfaced
            # to the LLM. The hardcoded 0.5-0.85 range in `_detect_tensions` produces
            # false positives in Gemma's tighter embedding space -- related (not
            # contradictory) memories get flagged, and LLMs read `[CONFLICTING]` as a
            # cue to distrust the memory entirely. See cdocs/followups.md FU-2.
            if mem.get("intent"):
                flags.append(f"intent:{mem['intent']}")

            flag_str = f" [{', '.join(flags)}]" if flags else ""
            prior = ""
            if mem.get("prior_value"):
                prior_age = ""
                if mem.get("prior_date"):
                    pd = now - mem["prior_date"]
                    prior_age = f" {int(pd / 86400)}d ago" if pd > 86400 else ""
                prior = f" (was: '{mem['prior_value'][:60]}'{prior_age})"

            line = (
                f"- {content} ({age_str}, str:{strength:.2f}, "
                f"used:{access}x, type:{category}{flag_str}){prior}"
            )

            if chars_used + len(line) > char_budget:
                break
            lines.append(line)
            chars_used += len(line)

        lines.append("[End Memory Context]")
        return "\n".join(lines)

    # -- Internal --

    def _get_effective_query(self, query_emb: np.ndarray, matrix: np.ndarray) -> np.ndarray:
        """Blend query with context vector based on self-sufficiency."""
        if self._context_vector is None or matrix.shape[0] == 0:
            return query_emb

        sims = EmbeddingService.cosine_similarity_matrix(query_emb, matrix)
        sigma_self = float(np.max(sims)) if len(sims) > 0 else 0.0

        blend = self.config.context_blend_beta * (sigma_self - self.config.context_blend_theta)
        alpha = sigmoid(blend)
        q_eff = alpha * query_emb + (1.0 - alpha) * self._context_vector
        norm = float(np.linalg.norm(q_eff))
        if norm > 1e-9:
            q_eff = q_eff / norm
        return q_eff

    async def _spread_activation(self, ids: list[str], scores: np.ndarray) -> np.ndarray:
        """Multi-hop BFS through memory graph.

        Previously: one `get_neighbors(id)` SQL call per node dequeued inside
        each seed's BFS -- up to ~400 round-trips per recall in the worst
        case. Now: one batched `get_neighbors_many(frontier_ids)` per BFS
        level per seed -- `n_hops` queries per seed regardless of fan-out.

        Boost formula is unchanged; the traversal order within a seed is
        preserved (neighbors still sorted weight-desc per node before
        branching). `paths_found` and `visited` remain per-seed so
        per-memory boost behaviour is byte-identical to the old loop.
        """
        if self.config.n_hops == 0:
            return scores

        id_to_idx = {mid: i for i, mid in enumerate(ids)}
        seeds = [(i, scores[i]) for i in range(len(ids)) if scores[i] >= self.config.min_relevance]
        seeds.sort(key=lambda x: x[1], reverse=True)
        seeds = seeds[: self.config.top_k * 2]

        boosted = scores.copy()

        for seed_idx, seed_score in seeds:
            seed_id = ids[seed_idx]
            # Level-by-level BFS: process each depth as a single SQL call.
            frontier: list[tuple[str, float]] = [(seed_id, 1.0)]  # (id, coherence)
            visited: set[str] = {seed_id}
            paths_found = 0

            for depth in range(self.config.n_hops):
                if not frontier or paths_found >= self.config.bfs_max_paths:
                    break
                frontier_ids = [fid for fid, _ in frontier]
                neighbors_by_id = await self.store.get_neighbors_many(frontier_ids)

                next_frontier: list[tuple[str, float]] = []
                for current_id, coherence in frontier:
                    if paths_found >= self.config.bfs_max_paths:
                        break
                    neighbors = neighbors_by_id.get(current_id, [])
                    neighbors.sort(key=lambda x: x[1], reverse=True)

                    for neighbor_id, weight in neighbors[: self.config.bfs_max_branch]:
                        if neighbor_id in visited:
                            continue
                        path_coherence = coherence * weight
                        if path_coherence < self.config.path_coherence_min:
                            continue

                        visited.add(neighbor_id)
                        paths_found += 1

                        if neighbor_id in id_to_idx:
                            target_idx = id_to_idx[neighbor_id]
                            n_neighbors = max(len(neighbors), 1)
                            boost = (
                                seed_score
                                * path_coherence
                                * (self.config.spread_factor ** (depth + 1))
                                / n_neighbors
                            )
                            boosted[target_idx] = max(
                                boosted[target_idx], boosted[target_idx] + boost
                            )

                        next_frontier.append((neighbor_id, path_coherence))
                        if paths_found >= self.config.bfs_max_paths:
                            break

                frontier = next_frontier

        return boosted

    def _detect_tensions(self, memories: list[dict]):
        """Find contradicting pairs among recalled memories."""
        for i in range(len(memories)):
            for j in range(i + 1, len(memories)):
                a = memories[i]
                b = memories[j]
                if a.get("category") != b.get("category"):
                    continue
                if a.get("embedding") is None or b.get("embedding") is None:
                    continue
                sim = EmbeddingService.cosine_similarity(a["embedding"], b["embedding"])
                if 0.5 < sim < 0.85:
                    if "tension_with" not in a:
                        a["tension_with"] = []
                    if "tension_with" not in b:
                        b["tension_with"] = []
                    a["tension_with"].append(b["id"])
                    b["tension_with"].append(a["id"])
