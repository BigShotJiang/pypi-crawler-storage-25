"""Phoenix Memory System -- persistent episodic memory.

MemorySystem is the main orchestrator. It hooks into the conversation loop
via pre_turn() and post_turn(), managing extraction, gating, storage,
recall, feedback, decay, and consolidation automatically.
"""

import asyncio
import hashlib
import logging
import time

from .classifier import build_classifiers
from .config import CATEGORY_IMPORTANCE, MemoryParams
from .consolidation import ConsolidationEngine
from .embeddings import EmbeddingService
from .extractor import extract_facts
from .gate import NoveltyGate
from .recall import RecallEngine
from .store import MemoryStore

log = logging.getLogger(__name__)


class MemorySystem:
    """Orchestrates the full memory pipeline. Injected into engine, not a global."""

    def __init__(self, config: MemoryParams | None = None):
        self.config = config or MemoryParams.from_env()
        self.embedder = EmbeddingService(self.config)
        self.store = MemoryStore(self.config)
        self._gate: NoveltyGate | None = None
        self._recall: RecallEngine | None = None
        self._consolidation: ConsolidationEngine | None = None
        self._cat_clf = None
        self._dim_clf = None
        self._intent_clf = None
        self._turn_count = 0
        self._last_fingerprint: str = ""
        self._last_fingerprint_time: float = 0.0
        # Guards _ensure_initialized against concurrent callers. With
        # aiosqlite the store itself is single-threaded internally, but
        # _ensure_initialized still runs the ~2-4s classifier build (52
        # anchor embeds via sentence-transformers) and we don't want two
        # coroutines to both pass the `self._cat_clf is not None` guard.
        self._init_lock = asyncio.Lock()

    async def _ensure_initialized(self):
        """Lazy-init classifiers, engines, and DB connection on first use."""
        if self._cat_clf is not None:
            return
        async with self._init_lock:
            if self._cat_clf is not None:  # re-check after acquiring lock
                return
            # Open the DB + apply migrations before anything that queries it.
            await self.store.connect()
            cat_clf, dim_clf, intent_clf = build_classifiers(
                self.config, self.embedder.embed_document
            )
            gate = NoveltyGate(self.config, self.embedder, self.store)
            recall = RecallEngine(self.config, self.embedder, self.store)
            consolidation = ConsolidationEngine(self.config, self.embedder, self.store)
            # Publish sentinel (_cat_clf) last so the outer guard only
            # returns when everything else is set.
            self._gate = gate
            self._recall = recall
            self._consolidation = consolidation
            self._dim_clf = dim_clf
            self._intent_clf = intent_clf
            self._cat_clf = cat_clf
            log.info("Memory system initialized (db: %s)", self.config.db_path)

    async def warm_up(self) -> None:
        """Force-load the embedder + classifiers + DB before the TUI hijacks
        stdio. SentenceTransformer and huggingface_hub spawn subprocesses on
        first load that inherit stdout/stderr filenos; under Textual those
        are wrappers whose fileno() returns an invalid FD, so fork_exec
        rejects them. Calling this from main.py before run_tui lets the
        subprocesses inherit real FDs."""
        await self._ensure_initialized()

    async def pre_turn(self, user_input: str, namespace: str = "global") -> str:
        """Called before the AI responds. Recalls relevant memories."""
        # Short inputs skip recall -- check BEFORE _ensure_initialized so
        # "hi"-style turns don't pay the classifier cold-start cost.
        if len(user_input.strip()) < 10:
            return ""

        await self._ensure_initialized()

        assert self._recall is not None
        self._recall.update_context(user_input)
        memories = await self._recall.recall(user_input, namespace=namespace)

        if not memories:
            return ""

        return self._recall.format_for_prompt(memories)

    async def post_turn(
        self,
        user_input: str,
        ai_output: str,
        session_id: str = "",
        namespace: str = "global",
    ):
        """Called after the AI responds. Extracts, gates, stores, and learns."""
        await self._ensure_initialized()
        self._turn_count += 1

        # Fingerprint dedup
        fingerprint = hashlib.sha256(f"{user_input}:{ai_output}".encode()).hexdigest()[:16]
        now = time.time()
        if (
            fingerprint == self._last_fingerprint
            and now - self._last_fingerprint_time < self.config.dedup_window_seconds
        ):
            return
        self._last_fingerprint = fingerprint
        self._last_fingerprint_time = now

        # Episode logging
        await self.store.add_episode(
            user_input=user_input,
            ai_output=ai_output,
            namespace=namespace,
            session_id=session_id,
            turn_number=self._turn_count,
        )

        # Fact extraction (classifiers guaranteed non-None after _ensure_initialized)
        assert self._cat_clf is not None
        assert self._dim_clf is not None
        assert self._gate is not None
        assert self._recall is not None
        assert self._consolidation is not None
        facts = extract_facts(
            user_input=user_input,
            ai_output=ai_output,
            embedder=self.embedder,
            classifier=self._cat_clf,
            intent_classifier=self._intent_clf,
        )

        stored = 0
        contradicted = 0
        strengthened = 0

        for fact in facts:
            embedding = fact["embedding"]
            category = fact["category"]
            intent = fact.get("intent")

            # Dimension classification
            dimension, _ = self._dim_clf.classify(embedding)

            # Novelty gate
            result = await self._gate.evaluate(
                content=fact["content"],
                embedding=embedding,
                namespace=namespace,
                ai_output_text=ai_output,
            )

            action = result["action"]

            if action == "contradict":
                await self._gate.handle_contradiction(
                    old_id=result["old_id"],
                    new_content=fact["content"],
                    embedding=embedding,
                    category=category,
                    namespace=namespace,
                    intent=intent,
                    dimension=dimension,
                )
                contradicted += 1

            elif action == "store":
                importance = CATEGORY_IMPORTANCE.get(category, 1.0)
                strength = self.config.initial_strength * importance * result.get("gate", 1.0)

                mid = await self.store.add(
                    content=fact["content"],
                    category=category,
                    namespace=namespace,
                    embedding=embedding,
                    strength=strength,
                    source_session=session_id,
                    intent=intent,
                    dimension=dimension,
                )

                await self._build_edges(mid, embedding, namespace)
                stored += 1

            elif action == "strengthen":
                strengthened += 1

        # Response-alignment feedback
        feedback = await self._recall.feedback(ai_output)

        # Edge decay
        await self.store.decay_edges(self.config.edge_decay_rate, self.config.edge_weight_min)

        # Periodic consolidation
        if self._turn_count % self.config.consolidate_every == 0:
            clusters = await self._consolidation.consolidate(namespace)
            if clusters:
                log.info("Consolidated %d clusters", len(clusters))

        if stored or contradicted:
            log.debug(
                "Memory post_turn: stored=%d contradicted=%d strengthened=%d feedback=%s",
                stored,
                contradicted,
                strengthened,
                feedback,
            )

    async def recall_for_agent(self, task: str, agent_name: str) -> str:
        """Scoped recall for delegation context."""
        await self._ensure_initialized()
        assert self._recall is not None
        memories = await self._recall.recall(task, namespace=agent_name)
        return self._recall.format_for_prompt(memories)

    @property
    def last_breakdown(self) -> list[dict]:
        """Per-candidate breakdown from the most recent recall. Drives
        /memory why. Empty until the first recall fires."""
        if self._recall is None:
            return []
        return list(self._recall._last_breakdown)

    @property
    def last_query(self) -> str:
        if self._recall is None:
            return ""
        return self._recall._last_query

    async def trace(
        self, query: str, namespace: str = "global", top_k: int | None = None
    ) -> list[dict]:
        """Run the recall pipeline for `query` and return the breakdown
        WITHOUT mutating hit counts. For /memory trace."""
        await self._ensure_initialized()
        assert self._recall is not None
        return await self._recall.trace(query, namespace=namespace, top_k=top_k)

    async def stats(self, namespace: str | None = None) -> dict:
        # stats() queries the DB; ensure it's connected. If warm_up hasn't
        # run yet (e.g. TUI on_mount firing before first turn), connect first.
        if self.store._db is None:
            await self.store.connect()
        return await self.store.stats(namespace)

    async def close(self):
        await self.store.close()

    async def _build_edges(self, memory_id: str, embedding, namespace: str):
        """Connect new memory to similar existing ones."""
        ids, matrix, _ = await self.store.get_all_embeddings(namespace)
        if len(ids) == 0:
            return
        sims = EmbeddingService.cosine_similarity_matrix(embedding, matrix)
        for i, sim in enumerate(sims):
            if sim >= self.config.edge_threshold and ids[i] != memory_id:
                await self.store.add_edge(memory_id, ids[i], float(sim))
