"""Memory management -- search, update, forget, pin memories.

Gives Phoenix the ability to manage its own memory system.
The brain can search for memories, update them, mark them as
completed/resolved, pin important ones, or forget outdated info.
"""

import logging

from phoenix.abilities import PhoenixContext, ability

log = logging.getLogger(__name__)


@ability(
    name="memory_manage",
    description="Search, update, forget, or pin memories",
)
async def memory_manage(
    ctx: PhoenixContext,
    action: str,
    query: str = "",
    content: str = "",
) -> str:
    """Manage Phoenix's persistent memory.

    Args:
        action: One of: search, update, forget, pin, unpin, store, stats
        query: Search query or memory content to find (for search/update/forget/pin/unpin)
        content: New content for update, or fact to store (for update/store)
    """
    if not ctx.memory:
        log.warning("memory_manage: called but ctx.memory is None")
        return "Memory system not available."

    memory = ctx.memory
    action = action.strip().lower()
    log.info(
        "memory_manage: action=%s query=%r content=%r",
        action,
        query[:80],
        content[:80],
    )

    if action == "search":
        return await _search(memory, query)
    elif action == "update":
        return await _update(memory, query, content)
    elif action == "forget":
        return await _forget(memory, query)
    elif action == "pin":
        return await _pin(memory, query, pinned=True)
    elif action == "unpin":
        return await _pin(memory, query, pinned=False)
    elif action == "store":
        return await _store(memory, content or query)
    elif action == "stats":
        return await _stats(memory)
    else:
        return f"Unknown action: {action}. Use: search, update, forget, pin, unpin, store, stats"


async def _search(memory, query: str) -> str:
    """Search memories by content."""
    if not query:
        return "Provide a search query."

    await memory._ensure_initialized()
    results = await memory.store.search_text(query, limit=10)

    if not results:
        return f"No memories found matching '{query}'."

    lines = [f"Found {len(results)} memories:"]
    for mem in results:
        mid = mem["id"]
        content = mem["content"][:120]
        cat = mem.get("category", "?")
        strength = mem.get("strength", 0)
        pinned = " [PINNED]" if mem.get("pinned") else ""
        superseded = " [SUPERSEDED]" if mem.get("superseded_by") else ""
        lines.append(f"  [{mid}] ({cat}, str:{strength:.2f}{pinned}{superseded}) {content}")
    return "\n".join(lines)


async def _update(memory, query: str, new_content: str) -> str:
    """Find a memory by query and update its content."""
    if not query:
        return "Provide a search query to find the memory to update."
    if not new_content:
        return "Provide new content for the memory."

    await memory._ensure_initialized()
    results = await memory.store.search_text(query, limit=5)

    if not results:
        return f"No memories found matching '{query}'. Nothing to update."

    # Update the best match
    best = results[0]
    old_content = best["content"]
    mid = best["id"]

    # Store new memory that supersedes the old one
    embedding = memory.embedder.embed_document(new_content)
    new_id = await memory.store.add(
        content=new_content,
        category=best.get("category", "fact"),
        namespace=best.get("namespace", "global"),
        embedding=embedding,
        strength=best.get("strength", 1.0),
        prior_value=old_content,
        prior_date=best.get("created_at"),
    )
    await memory.store.supersede(mid, new_id)

    return (
        f"Updated memory [{mid}]:\n"
        f"  Was: {old_content[:100]}\n"
        f"  Now: {new_content[:100]}\n"
        f"  New ID: [{new_id}]"
    )


async def _forget(memory, query: str) -> str:
    """Find and remove a memory."""
    if not query:
        return "Provide a search query to find the memory to forget."

    await memory._ensure_initialized()
    results = await memory.store.search_text(query, limit=5)

    if not results:
        return f"No memories found matching '{query}'."

    # Delete the best match
    best = results[0]
    mid = best["id"]
    content = best["content"][:100]
    await memory.store.delete(mid)

    return f"Forgotten: [{mid}] {content}"


_PIN_MIN_STRENGTH = 1.5
_PIN_MIN_ACCESS = 3
_PIN_BLOCKED_INTENTS = frozenset({"venting", "excited"})


async def _pin(memory, query: str, pinned: bool) -> str:
    """Pin or unpin a memory.

    Unpin is unrestricted. Pin requires the target to be an established,
    used, non-emotional fact -- strength >= 1.5, access_count >= 3, and
    intent not in {'venting', 'excited'}. Without these guards, an LLM
    can (and has) pinned emotional confessions as "highest authority
    identity" and surface them in every profile load.
    """
    if not query:
        return "Provide a search query to find the memory."

    await memory._ensure_initialized()
    results = await memory.store.search_text(query, limit=5)

    if not results:
        return f"No memories found matching '{query}'."

    best = results[0]
    mid = best["id"]
    content = best["content"][:100]

    if pinned:
        strength = float(best.get("strength", 0.0))
        access_count = int(best.get("access_count", 0))
        intent = best.get("intent")
        missing = []
        if strength < _PIN_MIN_STRENGTH:
            missing.append(f"strength {strength:.2f} < {_PIN_MIN_STRENGTH}")
        if access_count < _PIN_MIN_ACCESS:
            missing.append(f"access_count {access_count} < {_PIN_MIN_ACCESS}")
        if intent in _PIN_BLOCKED_INTENTS:
            missing.append(f"intent={intent!r} is emotional")
        if missing:
            return (
                f"Refusing to pin [{mid}]: {'; '.join(missing)}. "
                f"Pin is reserved for established, used, non-emotional facts. "
                f"Let the memory strengthen through reinforcement first."
            )

    await memory.store.set_pinned(mid, pinned)
    action_word = "Pinned" if pinned else "Unpinned"
    return f"{action_word}: [{mid}] {content}"


async def _store(memory, content: str) -> str:
    """Explicitly store a new memory fact. Runs through novelty gate."""
    if not content:
        return "Provide content to store."

    await memory._ensure_initialized()
    embedding = memory.embedder.embed_document(content)
    category, _ = memory._cat_clf.classify(embedding)

    # Run through novelty gate (same as automatic pipeline)
    gate_result = await memory._gate.evaluate(
        content=content,
        embedding=embedding,
        namespace="global",
    )

    action = gate_result["action"]

    if action == "contradict":
        # Contradiction detected -- supersede the old memory
        await memory._gate.handle_contradiction(
            old_id=gate_result["old_id"],
            new_content=content,
            embedding=embedding,
            category=category,
            namespace="global",
        )
        old_content = gate_result.get("old_content", "?")[:80]
        return (
            f"Contradiction detected. Updated:\n"
            f"  Was: {old_content}\n"
            f"  Now: {content[:100]}\n"
            f"  Old memory superseded."
        )

    if action == "strengthen":
        # Near-duplicate exists -- strengthened instead of storing
        existing_id = gate_result.get("existing_id", "?")
        return (
            f"Similar memory already exists [{existing_id}]. Strengthened instead of duplicating."
        )

    if action == "filter":
        # Not novel enough
        reason = gate_result.get("reason", "not novel")
        return f"Not stored: {reason}. Memory already covers this."

    # Passed gate -- store
    from phoenix.memory.config import CATEGORY_IMPORTANCE

    importance = CATEGORY_IMPORTANCE.get(category, 1.0)
    strength = 1.0 * importance * gate_result.get("gate", 1.0)

    mid = await memory.store.add(
        content=content,
        category=category,
        namespace="global",
        embedding=embedding,
        strength=strength,
    )

    # Build graph edges
    await memory._build_edges(mid, embedding, "global")

    return f"Stored: [{mid}] ({category}) {content[:100]}"


async def _stats(memory) -> str:
    """Show memory statistics."""
    stats = await memory.stats()
    lines = [
        f"Total memories: {stats['total']}",
        f"Pinned: {stats.get('pinned', 0)}",
        f"Clusters: {stats.get('clusters', 0)}",
        f"Graph edges: {stats.get('edge_count', 0)}",
        f"Episodes: {stats.get('episodes', 0)}",
        f"Avg strength: {stats.get('avg_strength', 0)}",
    ]
    if stats.get("by_category"):
        cats = ", ".join(f"{k}:{v}" for k, v in stats["by_category"].items())
        lines.append(f"Categories: {cats}")
    return "\n".join(lines)
