"""Tests for memory system -- extraction, gating, recall."""

import os
import tempfile

import numpy as np
import pytest

# Use temp DB for all tests
_TEMP_DB = tempfile.mktemp(suffix=".db")
os.environ["PHOENIX_MEMORY_DB"] = _TEMP_DB


import contextlib

from phoenix.memory import MemorySystem  # noqa: E402
from phoenix.memory.classifier import AnchorClassifier, build_classifiers  # noqa: E402
from phoenix.memory.config import CATEGORY_ANCHORS, MINILM_PRESET, MemoryParams  # noqa: E402
from phoenix.memory.embeddings import EmbeddingService  # noqa: E402
from phoenix.memory.extractor import _declarative_signal, extract_facts, sigmoid  # noqa: E402
from phoenix.memory.gate import NoveltyGate  # noqa: E402
from phoenix.memory.store import MemoryStore  # noqa: E402

# -- Helpers --


# Tests use MINILM_PRESET (FastEmbed backend) for fast, deterministic inference.
# Avoids the ~100s Gemma cold-start + license gate in CI.
_TEST_PARAMS = MemoryParams(**MINILM_PRESET)


def _get_embedder():
    return EmbeddingService(_TEST_PARAMS)


def _get_store():
    return MemoryStore(_TEST_PARAMS)


# -- Embedding tests --


class TestEmbeddings:
    def test_embed_returns_vector(self):
        emb = _get_embedder()
        vec = emb.embed("hello world")
        assert isinstance(vec, np.ndarray)
        # Dim is backend-dependent; read from config so test doesn't hardcode.
        assert vec.shape == (emb.config.embedding_dim,)

    def test_embed_is_normalized(self):
        emb = _get_embedder()
        vec = emb.embed("test sentence")
        norm = float(np.linalg.norm(vec))
        assert abs(norm - 1.0) < 0.01

    def test_similar_texts_higher_than_different(self):
        emb = _get_embedder()
        a = emb.embed("I prefer dark mode")
        b = emb.embed("I like dark theme")
        c = emb.embed("The database runs on PostgreSQL")
        sim_similar = EmbeddingService.cosine_similarity(a, b)
        sim_different = EmbeddingService.cosine_similarity(a, c)
        assert sim_similar > sim_different

    def test_different_texts_low_similarity(self):
        emb = _get_embedder()
        a = emb.embed("I prefer dark mode")
        b = emb.embed("The database runs on PostgreSQL")
        sim = EmbeddingService.cosine_similarity(a, b)
        assert sim < 0.5

    def test_cosine_similarity_matrix(self):
        emb = _get_embedder()
        q = emb.embed("dark mode")
        keys = np.stack([emb.embed("I like dark theme"), emb.embed("PostgreSQL database")])
        sims = EmbeddingService.cosine_similarity_matrix(q, keys)
        assert len(sims) == 2
        assert sims[0] > sims[1]


# -- Extractor tests --


class TestExtractor:
    def test_sigmoid(self):
        assert abs(sigmoid(0) - 0.5) < 0.01
        assert sigmoid(10) > 0.99
        assert sigmoid(-10) < 0.01

    def test_declarative_signal_first_person(self):
        score = _declarative_signal("I prefer using Neovim")
        assert score > 0.5

    def test_declarative_signal_question(self):
        score = _declarative_signal("What is Python?")
        assert score < 0.3

    def test_extract_facts_from_declaration(self):
        emb = _get_embedder()
        clf = AnchorClassifier(CATEGORY_ANCHORS)
        clf.initialize(emb.embed)
        facts = extract_facts("I prefer Python over Java.", "", emb, clf)
        assert len(facts) >= 1
        assert any("Python" in f["content"] for f in facts)

    def test_extract_facts_skips_questions(self):
        emb = _get_embedder()
        clf = AnchorClassifier(CATEGORY_ANCHORS)
        clf.initialize(emb.embed)
        facts = extract_facts("What language should I use?", "", emb, clf)
        assert len(facts) == 0


# -- Gate tests --


class TestGate:
    async def test_first_fact_always_stores(self):
        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        gate = NoveltyGate(_TEST_PARAMS, emb, store)
        vec = emb.embed("I prefer Python")
        result = await gate.evaluate("I prefer Python", vec, namespace="test_gate")
        assert result["action"] == "store"
        await store.close()


# -- Store tests --


class TestStore:
    async def test_add_and_get(self):
        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        vec = emb.embed("test memory")
        mid = await store.add("test memory", category="fact", embedding=vec, namespace="test_store")
        mem = await store.get(mid)
        assert mem is not None
        assert mem["content"] == "test memory"
        assert mem["category"] == "fact"
        await store.close()

    async def test_stats(self):
        store = _get_store()
        await store.connect()
        stats = await store.stats()
        assert "total" in stats
        assert "by_category" in stats
        assert "edge_count" in stats
        await store.close()

    async def test_add_edge(self):
        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        v1 = emb.embed("fact one")
        v2 = emb.embed("fact two")
        id1 = await store.add("fact one", embedding=v1, namespace="test_edges")
        id2 = await store.add("fact two", embedding=v2, namespace="test_edges")
        await store.add_edge(id1, id2, 0.8)
        neighbors = await store.get_neighbors(id1)
        assert len(neighbors) >= 1
        assert any(n[0] == id2 for n in neighbors)
        await store.close()


# -- Classifier tests --


class TestClassifier:
    def test_build_classifiers(self):
        emb = _get_embedder()
        cat, dim, intent = build_classifiers(_TEST_PARAMS, emb.embed)
        assert len(cat.categories) == 5
        assert len(dim.categories) == 5
        assert len(intent.categories) == 5

    def test_classify_preference(self):
        emb = _get_embedder()
        clf = AnchorClassifier(CATEGORY_ANCHORS)
        clf.initialize(emb.embed)
        vec = emb.embed("I prefer dark mode in all my editors")
        category, confidence = clf.classify(vec)
        assert category == "preference"
        assert confidence > 0


# -- MemorySystem integration --


class TestMemorySystem:
    async def test_post_turn_stores_facts(self):
        # Use MINILM_PRESET to avoid pulling Gemma in CI (no HF auth, no 600MB weights).
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("My name is Harshal. I prefer Python.", "Noted.", session_id="test")
        stats = await mem.stats()
        assert stats["total"] >= 1
        await mem.close()

    async def test_pre_turn_recalls(self):
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I switched from VS Code to Neovim.", "Got it.", session_id="test")
        await mem.post_turn("I prefer Python over Java for backend.", "Noted.", session_id="test")
        ctx = await mem.pre_turn("what programming language do I prefer")
        assert isinstance(ctx, str)
        await mem.close()


class TestRecallBreakdown:
    """Drives /memory why. Must include every scored candidate with a terminal
    gate_reason, whether it passed or was rejected."""

    async def test_breakdown_populated_after_recall(self):
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I prefer Python.", "Noted.", session_id="t")
        await mem.post_turn("I use Neovim for editing.", "Got it.", session_id="t")
        await mem.post_turn("The weather in Bengaluru is hot.", "Ok.", session_id="t")
        await mem.pre_turn("what programming language do I prefer")

        breakdown = mem.last_breakdown
        assert isinstance(breakdown, list)
        assert len(breakdown) >= 1

        required = {
            "id",
            "sem_score",
            "composite_score",
            "direct_relevance",
            "pinned",
            "passed_gate",
            "gate_reason",
            "content",
            "category",
            "strength",
        }
        for b in breakdown:
            assert required.issubset(b.keys()), f"missing keys: {required - b.keys()}"

        # No entry may end with the non-terminal "reached_scoring" reason.
        reasons = {b["gate_reason"] for b in breakdown}
        assert "reached_scoring" not in reasons
        await mem.close()

    async def test_trace_does_not_mutate_access_count(self):
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I prefer Python.", "Noted.", session_id="t")

        # Query directly: post_turn() may have already touched access_count
        # via its own pipeline (feedback / spreading activation). Snapshot the
        # baseline BEFORE trace() and compare against the post-trace value.
        await mem.store.connect()
        async with mem.store._db.execute("SELECT access_count FROM memories LIMIT 1") as cur:
            row_before = await cur.fetchone()
        baseline = row_before[0] if row_before else 0

        breakdown = await mem.trace("what language do I like")
        assert isinstance(breakdown, list)

        async with mem.store._db.execute("SELECT access_count FROM memories LIMIT 1") as cur:
            row_after = await cur.fetchone()
        after = row_after[0] if row_after else 0

        assert after == baseline, (
            f"trace() must not increment access_count; baseline={baseline}, after={after}"
        )
        await mem.close()

    async def test_pinned_irrelevant_memory_fails_gate(self):
        """Pinned boost must NOT bypass the direct-relevance gate. An
        identity-pinned memory must not leak into results for an off-topic
        query (the TVS-Raider-on-cryptocurrency bug that motivated the
        relevance gate).

        Fillers are semantically distinct so the NoveltyGate's 0.85
        near-duplicate threshold doesn't fold them into one row -- we need
        >=10 actual rows in the namespace for the single-weak OOD rule's
        size guard to pass, otherwise a one-memory-in-the-store fallback
        would make every off-topic query return the only candidate."""
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("My name is Harshal.", "Noted.", session_id="t")
        fillers = [
            "Apples grow on trees.",
            "Submarines operate deep underwater.",
            "Tax season begins in April.",
            "Whales are mammals, not fish.",
            "Helsinki is the capital of Finland.",
            "Lava cools into basalt.",
            "Bassoons are double-reed woodwinds.",
            "Coconuts contain potassium.",
            "Thunder follows lightning.",
            "Eiffel Tower was built for the 1889 Exposition.",
            "Saffron is harvested from crocus flowers.",
            "Albatrosses can fly for months without landing.",
        ]
        for f in fillers:
            await mem.post_turn(f, "Ok.", session_id="t")

        await mem.store.connect()
        async with mem.store._db.execute(
            "SELECT id FROM memories WHERE content LIKE '%Harshal%' LIMIT 1"
        ) as cur:
            row = await cur.fetchone()
        assert row is not None, "expected the identity memory to be stored"
        await mem.store._db.execute("UPDATE memories SET pinned=1 WHERE id=?", (row[0],))
        await mem.store._db.commit()

        # Verify we actually have >=10 rows (the OOD rule's size guard).
        async with mem.store._db.execute("SELECT COUNT(*) FROM memories") as cur:
            count_row = await cur.fetchone()
        assert count_row is not None and count_row[0] >= 10, (
            f"need >=10 distinct rows to exercise the single-weak-rule size guard; "
            f"got {count_row[0] if count_row else 0}. Fillers may be near-duplicating."
        )

        breakdown = await mem.trace("what is the price of bitcoin today")
        pinned_rows = [b for b in breakdown if b["pinned"]]
        assert pinned_rows, "pinned memory should appear in breakdown even when rejected"
        for pr in pinned_rows:
            assert not pr["passed_gate"], (
                f"pinned memory {pr['id'][:8]} passed the gate on an unrelated query "
                f"(reason={pr['gate_reason']}, direct={pr['direct_relevance']})"
            )
        await mem.close()

    async def test_breakdown_resets_on_second_recall(self):
        """Second recall() fully replaces _last_breakdown -- no stale entries
        leak across calls."""
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I prefer Python.", "Noted.", session_id="t")
        await mem.post_turn("I use Neovim.", "Got it.", session_id="t")

        await mem.pre_turn("what programming language do I prefer")
        first_query = mem.last_query
        first_ids = {b["id"] for b in mem.last_breakdown}
        assert first_ids

        await mem.pre_turn("what editor do I use")
        assert mem.last_query != first_query
        # Same DB so candidate set is identical, but every entry must have
        # been freshly scored for the new query.
        assert {b["id"] for b in mem.last_breakdown} == first_ids
        for b in mem.last_breakdown:
            assert isinstance(b["composite_score"], float)
        await mem.close()


# -- Concurrent lifecycle: verify the store.connect() lock prevents the
# TOCTOU race where two coroutines both pass the `self._db is not None`
# fast-check and both try to open + migrate the DB. --


class TestStoreConcurrency:
    async def test_concurrent_connect_is_serialised(self):
        """Ten coroutines hitting an unconnected store must not duplicate
        connect/migrate work. Before the _connect_lock fix, this raised
        IntegrityError on the second _migrations INSERT."""
        import asyncio

        store = _get_store()
        # Fan out ten concurrent connects; the lock should serialise them
        # so only the first actually opens + migrates.
        await asyncio.gather(*[store.connect() for _ in range(10)])
        # One connection, migrations recorded exactly once.
        cursor = await store._db.execute(
            "SELECT COUNT(*) FROM _migrations WHERE name = '001_initial.sql'"
        )
        count = (await cursor.fetchone())[0]
        await cursor.close()
        assert count == 1, f"expected 1 migration row, got {count}"
        await store.close()

    async def test_concurrent_stats_and_pre_turn(self):
        """Races stats() against pre_turn() / post_turn() -- all three go
        through _ensure_initialized or stats()'s lazy connect. No
        IntegrityError, no RuntimeError, no silent coroutine drops."""
        import asyncio

        mem = MemorySystem(_TEST_PARAMS)
        results = await asyncio.gather(
            mem.post_turn("I use pytest for all my testing.", "Noted.", session_id="t"),
            mem.stats(),
            mem.pre_turn("what testing framework do I use"),
            mem.stats(),
            return_exceptions=True,
        )
        for r in results:
            assert not isinstance(r, Exception), f"concurrent call raised: {r!r}"
        await mem.close()


# -- v0.3.7 polish tests --


class TestPolishV037:
    """Behaviour introduced in v0.3.7: query gate, pin guards, strength cap,
    OOD single-result rule."""

    def test_strength_cap_default_is_three(self):
        assert MemoryParams().strength_cap == 3.0

    async def test_feedback_respects_strength_cap(self):
        """Runtime: feedback() must clamp at strength_cap, not at the old 2.0."""
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I prefer tabs over spaces.", "Noted.", session_id="t")
        results = await mem.store.search_text("tabs", limit=1)
        assert results, "expected the memory to be stored"
        mid = results[0]["id"]
        # Seed strength very close to the cap; one feedback-aligned response
        # at +0.08 would exceed the old 2.0 ceiling. Must land at exactly
        # strength_cap, not higher.
        await mem.store.update_strength(mid, 2.95)
        mem._recall._last_recalled = [await mem.store.get(mid)]
        # Feedback alignment needs the AI output to resemble the memory.
        await mem._recall.feedback("User prefers tabs rather than spaces.")
        refreshed = await mem.store.get(mid)
        assert refreshed["strength"] == mem.config.strength_cap, (
            f"expected exact cap {mem.config.strength_cap}, got {refreshed['strength']}"
        )
        assert refreshed["strength"] > 2.0, "cap raise above 2.0 not effective"
        await mem.close()

    async def test_query_gate_rejects_short_and_stopword(self):
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I use pytest for testing backend services.", "Noted.", session_id="t")
        await mem._ensure_initialized()
        # Prime _last_recalled so we can verify the rejection path clears it.
        mem._recall._last_recalled = [{"id": "stale", "content": "stale"}]
        # Short query
        assert await mem._recall.recall("ab") == []
        assert mem._recall._last_recalled == [], "stale _last_recalled not cleared"
        # Stopword-only
        mem._recall._last_recalled = [{"id": "stale", "content": "stale"}]
        assert await mem._recall.recall("the") == []
        assert mem._recall._last_recalled == []
        # Whitespace-only
        mem._recall._last_recalled = [{"id": "stale", "content": "stale"}]
        assert await mem._recall.recall("   ") == []
        assert mem._recall._last_recalled == []
        # Normal query still works (might be empty if no match, but shouldn't
        # be the degenerate-query path; just assert it's a list)
        assert isinstance(await mem._recall.recall("pytest testing"), list)
        await mem.close()

    async def test_pin_refuses_weak_memory(self):
        from phoenix.abilities.memory_manage import _pin

        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I sometimes use a debugger.", "OK.", session_id="t")
        # The stored memory is fresh (strength ~ 1.0, access_count 0) so pin
        # should refuse. Search for it first to confirm it exists.
        results = await mem.store.search_text("debugger", limit=1)
        assert results, "expected the memory to be stored"
        msg = await _pin(mem, "debugger", pinned=True)
        assert "Refusing to pin" in msg, f"expected refusal, got: {msg}"
        # Unpin path has no guards and should always succeed (no-op here).
        msg2 = await _pin(mem, "debugger", pinned=False)
        assert "Unpinned" in msg2
        await mem.close()

    async def test_pin_accepts_strong_well_used_memory(self):
        from phoenix.abilities.memory_manage import _pin

        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I live in Mumbai.", "OK.", session_id="t")
        results = await mem.store.search_text("Mumbai", limit=1)
        assert results
        mid = results[0]["id"]
        # Bump strength above 1.5 and access_count above 3 directly
        await mem.store.update_strength(mid, 1.8)
        for _ in range(4):
            await mem.store.increment_access(mid)
        msg = await _pin(mem, "Mumbai", pinned=True)
        assert "Pinned" in msg and "Refusing" not in msg
        await mem.close()


# -- Spreading-activation BFS regression: v0.3.7 rewrote the BFS to batch
# `get_neighbors_many` per depth level instead of calling `get_neighbors`
# per node. The traversal order, boost formula, paths_found limit, and
# visited set are all supposed to be semantically identical to the old
# implementation. This test pins the observable behaviour on a small hand-
# crafted graph: any refactor that changes score propagation will break it.
# --


class TestSpreadActivationBFS:
    """Direct tests on `_spread_activation` -- skip the embedding / similarity
    front-half of recall and drive the BFS with explicit scores so the seed
    set is deterministic. Any refactor that changes score propagation on a
    known graph will fail at least one of these."""

    async def test_single_seed_boosts_direct_neighbor(self):
        """Exactly one seed (scores[0]=1, scores[1]=0). A graph edge from
        seed to B should boost B by `seed_score * path_coherence *
        spread_factor / n_neighbors`."""
        from phoenix.memory.recall import RecallEngine

        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        ns = "bfs_direct"
        va = emb.embed("seed")
        vb = emb.embed("neighbor")
        id_a = await store.add("seed", embedding=va, namespace=ns)
        id_b = await store.add("neighbor", embedding=vb, namespace=ns)
        await store.add_edge(id_a, id_b, weight=0.8)

        recall = RecallEngine(_TEST_PARAMS, emb, store)
        ids, _matrix, _rows = await store.get_all_embeddings(ns)
        idx_a = ids.index(id_a)
        idx_b = ids.index(id_b)
        # scores[b] stays 0 so b is NOT a seed and can't spread back to a.
        scores = np.zeros(len(ids))
        scores[idx_a] = 1.0

        boosted = await recall._spread_activation(ids, scores)
        # Expected boost on B: 1.0 * (1.0 * 0.8) * 0.3 / 1 = 0.24
        expected_boost = 1.0 * 0.8 * _TEST_PARAMS.spread_factor / 1
        actual_boost = boosted[idx_b] - scores[idx_b]
        assert abs(actual_boost - expected_boost) < 1e-6, (
            f"expected boost {expected_boost}, got {actual_boost}"
        )
        # Seed should not be boosted (B isn't a seed so can't send activation back).
        assert boosted[idx_a] == scores[idx_a], (
            f"seed boosted unexpectedly: {boosted[idx_a]} vs {scores[idx_a]}"
        )
        await store.close()

    async def test_bfs_respects_n_hops(self):
        """A 3-hop chain: seed -> h1 -> h2 -> h3. With n_hops=2, h1 and h2
        get boosted; h3 does not. Only the seed has a non-zero score."""
        from phoenix.memory.recall import RecallEngine

        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        ns = "bfs_hops"

        seed_id = await store.add("seed", embedding=emb.embed("seed"), namespace=ns)
        h1_id = await store.add("h1", embedding=emb.embed("h1"), namespace=ns)
        h2_id = await store.add("h2", embedding=emb.embed("h2"), namespace=ns)
        h3_id = await store.add("h3", embedding=emb.embed("h3"), namespace=ns)
        await store.add_edge(seed_id, h1_id, weight=0.95)
        await store.add_edge(h1_id, h2_id, weight=0.95)
        await store.add_edge(h2_id, h3_id, weight=0.95)

        recall = RecallEngine(_TEST_PARAMS, emb, store)
        ids, _matrix, _rows = await store.get_all_embeddings(ns)
        scores = np.zeros(len(ids))
        scores[ids.index(seed_id)] = 1.0  # single seed only

        boosted = await recall._spread_activation(ids, scores)
        id_to_idx = {mid: i for i, mid in enumerate(ids)}
        assert boosted[id_to_idx[h1_id]] > 0, "hop1 must be boosted"
        assert boosted[id_to_idx[h2_id]] > 0, "hop2 must be boosted"
        assert boosted[id_to_idx[h3_id]] == 0, (
            f"hop3 must NOT be boosted with n_hops=2, got {boosted[id_to_idx[h3_id]]}"
        )
        await store.close()

    async def test_bfs_empty_graph_noop(self):
        """No edges in the test namespace -> the two memories we added don't
        get boosted. Other tests may leave memories in 'global' (which this
        namespace unions with), so we build scores the same length as ids
        and only set non-zero scores on the ones we care about."""
        from phoenix.memory.recall import RecallEngine

        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        ns = "bfs_noedges"
        id_a = await store.add("a", embedding=emb.embed("a"), namespace=ns)
        id_b = await store.add("b", embedding=emb.embed("b"), namespace=ns)
        # No edges added FOR these two ids.

        recall = RecallEngine(_TEST_PARAMS, emb, store)
        ids, _matrix, _rows = await store.get_all_embeddings(ns)
        scores = np.zeros(len(ids), dtype=np.float64)
        idx_a, idx_b = ids.index(id_a), ids.index(id_b)
        scores[idx_a] = 0.5
        scores[idx_b] = 0.3

        boosted = await recall._spread_activation(ids, scores)
        # Our two memories have no edges between them, but global-namespace
        # memories from other tests might have edges to each other. We only
        # assert our two targets weren't boosted by spreading.
        assert boosted[idx_a] == scores[idx_a], (
            f"a had no out-edges, should not be boosted: {boosted[idx_a]} vs {scores[idx_a]}"
        )
        assert boosted[idx_b] == scores[idx_b], (
            f"b had no out-edges, should not be boosted: {boosted[idx_b]} vs {scores[idx_b]}"
        )
        await store.close()


# Cleanup
@pytest.fixture(autouse=True, scope="session")
def cleanup():
    yield
    with contextlib.suppress(FileNotFoundError):
        os.unlink(_TEMP_DB)
