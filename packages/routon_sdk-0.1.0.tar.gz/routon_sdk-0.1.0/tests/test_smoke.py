"""Smoke tests for routon-sdk."""

from __future__ import annotations

import json

import httpx
import pytest

from routon import (
    CHAIN_IDS,
    ROUTON_STANDARD_VERSION,
    RoutonAgent,
    RoutonAgentConfig,
    RoutonApiException,
    __version__,
)


def test_routon_standard_version_pinned() -> None:
    assert ROUTON_STANDARD_VERSION == "0.1"


def test_chain_ids_exposed() -> None:
    assert CHAIN_IDS["base"] == 8453
    assert CHAIN_IDS["arbitrum"] == 42_161


def test_sdk_version_pinned() -> None:
    assert __version__ == "0.1.0"


def test_agent_constructs_with_defaults() -> None:
    agent = RoutonAgent()
    assert agent.config.default_chain == "base"
    assert agent.config.brain_url == "https://brain.routon.xyz"


def test_agent_accepts_config() -> None:
    cfg = RoutonAgentConfig(default_chain="arbitrum")
    agent = RoutonAgent(cfg)
    assert agent.config.default_chain == "arbitrum"


def test_agent_rejects_bad_builder_code() -> None:
    """builder_code must be bytes32 hex (66 chars including 0x)."""
    with pytest.raises(ValueError):
        RoutonAgentConfig(builder_code="not-hex")


@pytest.mark.asyncio
async def test_agent_health_returns_envelope() -> None:
    """httpx.MockTransport drives a deterministic health response."""

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/health"
        return httpx.Response(
            200,
            json={"status": "ok", "version": "0.1.0"},
        )

    transport = httpx.MockTransport(handler)
    async with RoutonAgent(transport=transport) as agent:
        result = await agent.health()
    assert result.status.value == "ok"
    assert result.version == "0.1.0"


@pytest.mark.asyncio
async def test_agent_sends_builder_code_header() -> None:
    builder_code = "0x" + "ab" * 32
    seen_headers: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen_headers.update(request.headers)
        return httpx.Response(200, json={"status": "ok", "version": "0.1.0"})

    transport = httpx.MockTransport(handler)
    cfg = RoutonAgentConfig(builder_code=builder_code)
    async with RoutonAgent(cfg, transport=transport) as agent:
        await agent.health()
    assert seen_headers.get("x-builder-code") == builder_code


@pytest.mark.asyncio
async def test_agent_raises_on_non_2xx_with_typed_envelope() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            401,
            content=json.dumps(
                {
                    "code": "R-AUTH-001",
                    "message": "builder code not registered",
                    "traceId": "0x" + "11" * 32,
                }
            ),
            headers={"Content-Type": "application/json"},
        )

    transport = httpx.MockTransport(handler)
    async with RoutonAgent(transport=transport) as agent:
        with pytest.raises(RoutonApiException) as excinfo:
            await agent.health()
    err = excinfo.value
    assert err.status == 401
    assert err.error is not None
    assert err.error.code == "R-AUTH-001"
