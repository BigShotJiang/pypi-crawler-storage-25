"""EIP-712 typehash parity — RoutonValidationRegistry.

Pinned cross-language regression gate. Mirrors
``agent-brain/tests/test_risker_unit.py::TestEIP712Parity`` and
``sdk/ts/src/parity/eip712.test.ts``.
"""

from __future__ import annotations

from routon.parity import (
    ATTESTATION_TYPEHASH_STRING,
    EIP712_DOMAIN_NAME,
    EIP712_DOMAIN_VERSION,
    compute_attestation_struct_hash,
    compute_attestation_typehash,
)


class TestEIP712Parity:
    def test_typehash_string_matches_contract(self) -> None:
        """Must match contracts/src/ValidationRegistry.sol line 60-61 exactly."""
        assert ATTESTATION_TYPEHASH_STRING == (
            "Attestation(address attestor,bytes32 strategyId,uint16 score,"
            "bytes32 factorsHash,uint64 deadline,uint64 nonce)"
        )

    def test_domain_matches_contract(self) -> None:
        """Must match contracts/src/ValidationRegistry.sol line 266."""
        assert EIP712_DOMAIN_NAME == "RoutonValidationRegistry"
        assert EIP712_DOMAIN_VERSION == "1"

    def test_typehash_deterministic_and_bytes32(self) -> None:
        a = compute_attestation_typehash()
        b = compute_attestation_typehash()
        assert a == b
        assert a.startswith("0x")
        assert len(a) == 66

    def test_pinned_typehash_matches_known_keccak_vector(self) -> None:
        """PINNED HEX VECTOR — cross-language parity gate (audit-grade).

        Verified externally:
        ``cast keccak "Attestation(address attestor,bytes32 strategyId,
        uint16 score,bytes32 factorsHash,uint64 deadline,uint64 nonce)"
        = 0xa053eabe2f3aa0e2285ffb34153a8263eed6a92603472b749d887154d4a0119a``.

        Pinned IDENTICAL value in:
        - agent-brain/tests/test_risker_unit.py::test_typehash_matches_known_keccak_vector
        - sdk/ts/src/parity/eip712.test.ts (PINNED HEX VECTOR test)

        Drift here breaks postAttestation() acceptance + cross-language
        consumer parity. HALT and surface as HIGH.
        """
        expected = "0xa053eabe2f3aa0e2285ffb34153a8263eed6a92603472b749d887154d4a0119a"
        assert compute_attestation_typehash() == expected

    def test_struct_hash_deterministic(self) -> None:
        attestor = "0x" + "11" * 20
        strategy_id = "0x" + "22" * 32
        factors_hash = "0x" + "33" * 32
        a = compute_attestation_struct_hash(
            attestor=attestor,
            strategy_id=strategy_id,
            score_uint16=42,
            factors_hash=factors_hash,
            deadline=1714867200,
            nonce=0,
        )
        b = compute_attestation_struct_hash(
            attestor=attestor,
            strategy_id=strategy_id,
            score_uint16=42,
            factors_hash=factors_hash,
            deadline=1714867200,
            nonce=0,
        )
        assert a == b

    def test_struct_hash_distinguishes_score(self) -> None:
        attestor = "0x" + "11" * 20
        strategy_id = "0x" + "22" * 32
        factors_hash = "0x" + "33" * 32
        a = compute_attestation_struct_hash(
            attestor=attestor,
            strategy_id=strategy_id,
            score_uint16=12,
            factors_hash=factors_hash,
            deadline=1714867200,
            nonce=0,
        )
        b = compute_attestation_struct_hash(
            attestor=attestor,
            strategy_id=strategy_id,
            score_uint16=13,
            factors_hash=factors_hash,
            deadline=1714867200,
            nonce=0,
        )
        assert a != b

    def test_struct_hash_distinguishes_nonce(self) -> None:
        """Replay-protection: nonce changes flip the hash."""
        kwargs = {
            "attestor": "0x" + "11" * 20,
            "strategy_id": "0x" + "22" * 32,
            "score_uint16": 42,
            "factors_hash": "0x" + "33" * 32,
            "deadline": 1714867200,
        }
        a = compute_attestation_struct_hash(**kwargs, nonce=0)  # type: ignore[arg-type]
        b = compute_attestation_struct_hash(**kwargs, nonce=1)  # type: ignore[arg-type]
        assert a != b
