"""9-field ExecuteParams parity — money-safety boundary.

Pinned cross-language regression gate. Mirrors
``agent-brain/tests/test_router_unit.py::TestCalldataByteParity`` and
``sdk/ts/src/parity/executeParams.test.ts``.
"""

from __future__ import annotations

from typing import Any, ClassVar

from routon.parity import (
    EXECUTE_BATCH_SELECTOR,
    EXECUTE_PARAMS_ABI_TYPE,
    EXECUTE_SELECTOR,
    encode_execute_batch_calldata,
    encode_execute_calldata,
    encode_execute_params,
)


class TestCalldataByteParity:
    """The money-safety boundary. Encoder output MUST match ``cast
    abi-encode`` verbatim — any drift breaks PE.execute() acceptance.

    KNOWN_INPUT + KNOWN_HEX vectors are byte-IDENTICAL to:
    - ``agent-brain/tests/test_router_unit.py::TestCalldataByteParity``
    - ``sdk/ts/src/parity/executeParams.test.ts``
    """

    KNOWN_INPUT: ClassVar[dict[str, Any]] = {
        "strategy_id": "0x" + "11" * 32,
        "amount": 1_000_000_000,  # 1000 USDC
        "user": "0x" + "aa" * 20,
        "builder_code": "0x" + "22" * 32,
        "min_out": 990_000_000,
        "slippage_waived": False,
        "max_risk_score": 60,
        "deadline": 1_714_867_200,
        "data": "0x",
    }

    KNOWN_HEX: ClassVar[str] = (
        "0x"
        "0000000000000000000000000000000000000000000000000000000000000020"
        "1111111111111111111111111111111111111111111111111111111111111111"
        "000000000000000000000000000000000000000000000000000000003b9aca00"
        "000000000000000000000000aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        "2222222222222222222222222222222222222222222222222222222222222222"
        "000000000000000000000000000000000000000000000000000000003b023380"
        "0000000000000000000000000000000000000000000000000000000000000000"
        "000000000000000000000000000000000000000000000000000000000000003c"
        "000000000000000000000000000000000000000000000000000000006636cc00"
        "0000000000000000000000000000000000000000000000000000000000000120"
        "0000000000000000000000000000000000000000000000000000000000000000"
    )

    def test_abi_type_is_9_field_canon_align(self) -> None:
        """Spec § Calldata building — 9 fields per Wave 2 PR-D in-place
        amendment matching PE Solidity struct line 36-46."""
        assert EXECUTE_PARAMS_ABI_TYPE == (
            "(bytes32,uint256,address,bytes32,uint256,bool,uint16,uint64,bytes)"
        )

    def test_pinned_hex_matches_cast_abi_encode_reference(self) -> None:
        """PINNED HEX VECTOR — money-safety boundary."""
        actual = encode_execute_params(**self.KNOWN_INPUT)
        assert actual == self.KNOWN_HEX

    def test_execute_selector_matches_cast(self) -> None:
        """``cast sig 'execute((...))'`` = ``0x918fafc5``."""
        assert EXECUTE_SELECTOR == "0x918fafc5"

    def test_execute_batch_selector_matches_cast(self) -> None:
        """``cast sig 'executeBatch((...)[])'`` = ``0x062f75e9``."""
        assert EXECUTE_BATCH_SELECTOR == "0x062f75e9"

    def test_full_calldata_prepends_selector(self) -> None:
        calldata = encode_execute_calldata(**self.KNOWN_INPUT)
        assert calldata.startswith(EXECUTE_SELECTOR)
        assert calldata == EXECUTE_SELECTOR + self.KNOWN_HEX[2:]

    def test_encode_execute_params_deterministic(self) -> None:
        a = encode_execute_params(**self.KNOWN_INPUT)
        b = encode_execute_params(**self.KNOWN_INPUT)
        assert a == b

    def test_encode_execute_params_distinguishes_amount(self) -> None:
        a = encode_execute_params(**{**self.KNOWN_INPUT, "amount": 100})
        b = encode_execute_params(**{**self.KNOWN_INPUT, "amount": 200})
        assert a != b

    def test_encode_batch_two_steps_starts_with_batch_selector(self) -> None:
        step1 = dict(self.KNOWN_INPUT)
        step2 = {**self.KNOWN_INPUT, "amount": 200}
        calldata = encode_execute_batch_calldata([step1, step2])
        assert calldata.startswith(EXECUTE_BATCH_SELECTOR)
