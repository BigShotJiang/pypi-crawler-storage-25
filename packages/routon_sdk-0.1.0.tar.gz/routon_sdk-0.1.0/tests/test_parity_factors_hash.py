"""factorsHash parity — RFC 8785 JCS via jcs library.

Pinned cross-language regression gate. Mirrors
``agent-brain/tests/test_risker_unit.py::TestCanonicalFactorsHash`` and
``sdk/ts/src/parity/factorsHash.test.ts``.
"""

from __future__ import annotations

import jcs

from routon.parity import canonical_factors_hash


class TestCanonicalFactorsHash:
    def test_returns_bytes32_hex(self) -> None:
        factors = [{"name": "x", "value": 0.0, "source": "y", "subscore": 0.5}]
        h = canonical_factors_hash(factors)
        assert h.startswith("0x")
        assert len(h) == 66

    def test_deterministic(self) -> None:
        factors = [
            {"name": "audit_history", "value": 1.0, "source": "audits.md", "subscore": 1.0},
            {"name": "tvl_size", "value": 1_000_000.0, "source": "defillama", "subscore": 0.0},
        ]
        h1 = canonical_factors_hash(factors)
        h2 = canonical_factors_hash(factors)
        assert h1 == h2

    def test_invariant_under_intra_object_key_reorder(self) -> None:
        """JCS sorts object keys → reordering keys yields identical hash."""
        f1 = [{"name": "a", "value": 1, "source": "s", "subscore": 0.1}]
        f2 = [{"subscore": 0.1, "value": 1, "name": "a", "source": "s"}]
        assert canonical_factors_hash(f1) == canonical_factors_hash(f2)

    def test_pinned_jcs_vector_matches_cross_language(self) -> None:
        """PINNED HEX VECTOR — cross-language parity gate (audit-grade).

        Verified externally (jcs library):
        ``jcs.canonicalize([{"name":"audit_history","source":"docs/AUDITS.md",
        "subscore":1.0,"value":1.0}])``
        ``= b'[{"name":"audit_history","source":"docs/AUDITS.md","subscore":1,"value":1}]'``
        — note ``"subscore":1`` and ``"value":1`` (NOT 1.0) per ECMA-262
        ``Number.prototype.toString`` shortest round-trip.
        ``keccak256(canonical) = 0xdbc48e25...3a8a62``.

        Pinned IDENTICAL value in:
        - agent-brain/tests/test_risker_unit.py::test_factors_hash_matches_known_jcs_vector
        - sdk/ts/src/parity/factorsHash.test.ts (PINNED HEX VECTOR test)

        Drift here = cross-language consumer breakage. Surface as HIGH.
        """
        factors = [
            {
                "name": "audit_history",
                "source": "docs/AUDITS.md",
                "subscore": 1.0,
                "value": 1.0,
            }
        ]
        expected = "0xdbc48e25c7c80fc02fb1ccc56aa160d5265518d9cba788996c885207723a8a62"
        assert canonical_factors_hash(factors) == expected

    def test_pinned_invariant_under_key_reorder(self) -> None:
        factors_reordered = [
            {
                "value": 1.0,
                "subscore": 1.0,
                "source": "docs/AUDITS.md",
                "name": "audit_history",
            }
        ]
        expected = "0xdbc48e25c7c80fc02fb1ccc56aa160d5265518d9cba788996c885207723a8a62"
        assert canonical_factors_hash(factors_reordered) == expected

    def test_ecma_262_float_canonicalization(self) -> None:
        """Load-bearing RFC 8785 rule: float ``1.0`` serializes to ``"1"``.

        Failure here = jcs library version drift OR canonical impl
        regression. Same regression gate as
        ``agent-brain/tests/test_risker_unit.py::test_factors_hash_jcs_float_canonicalization``
        + ``sdk/ts/src/parity/factorsHash.test.ts`` ECMA-262 test.
        """
        canonical = jcs.canonicalize({"value": 1.0})
        assert canonical == b'{"value":1}'

        factors_with_float = [
            {"name": "x", "source": "y", "subscore": 0.25, "value": 1.0}
        ]
        h = canonical_factors_hash(factors_with_float)
        assert h.startswith("0x") and len(h) == 66
        assert canonical_factors_hash(factors_with_float) == h
