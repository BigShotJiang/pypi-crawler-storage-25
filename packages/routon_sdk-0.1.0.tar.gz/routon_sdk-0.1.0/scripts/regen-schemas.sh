#!/usr/bin/env bash
# Regenerate sdk/python/routon/_generated/schemas.py from agent-brain/openapi.json.
#
# Wave 3 PR-W3-B: Pydantic v2 models regenerated mechanically from the
# frozen OpenAPI 3.1 source-of-truth (agent-brain/openapi.json, PR #85)
# via datamodel-codegen. The generated output is COMMITTED (not regen-
# on-build) so diff stability is enforced by CI — drift between the
# openapi.json and the committed schemas triggers loud failure, same
# pattern as the 4 audit-grade hex parity pins.
#
# Mirrors sdk/ts/scripts/regen-schemas.sh (Wave 3 PR-W3-A).
#
# Usage (from sdk/python/):
#   bash scripts/regen-schemas.sh
#
# CI enforcement: .github/workflows/sdk-python.yml runs this script,
# then `git diff --exit-code routon/_generated/schemas.py` to detect drift.

set -euo pipefail

SDK_PY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OPENAPI="$SDK_PY_DIR/../../agent-brain/openapi.json"
OUTPUT="$SDK_PY_DIR/routon/_generated/schemas.py"
BIN="$SDK_PY_DIR/.venv/bin/datamodel-codegen"

if [[ ! -f "$OPENAPI" ]]; then
  echo "ERROR: openapi.json not found at $OPENAPI" >&2
  exit 1
fi
if [[ ! -x "$BIN" ]]; then
  echo "ERROR: datamodel-codegen not installed; run 'uv sync --extra dev' from sdk/python/" >&2
  exit 1
fi

mkdir -p "$(dirname "$OUTPUT")"

# Wave 1 Bug D pattern: pydantic v2 syntax + use_annotated for cleaner
# Field defaults. --target-python-version 3.12 matches mypy strict env.
"$BIN" \
  --input "$OPENAPI" \
  --input-file-type openapi \
  --output "$OUTPUT" \
  --output-model-type pydantic_v2.BaseModel \
  --target-python-version 3.12 \
  --use-annotated \
  --use-double-quotes \
  --strict-nullable \
  --use-schema-description \
  --collapse-root-models \
  --field-constraints \
  --disable-timestamp

# Prepend auto-gen header — datamodel-codegen emits its own timestamp-
# free header but we standardize the regen instructions.
HEADER='"""AUTO-GENERATED — do not edit by hand.

Source-of-truth: agent-brain/openapi.json (OpenAPI 3.1 spec, frozen
baseline per PR #85). Regenerate with:

    bash sdk/python/scripts/regen-schemas.sh

CI enforces stability via "git diff --exit-code routon/_generated/".
Mirrors sdk/ts/src/_generated/schemas.ts (openapi-zod-client).
"""

'

# Atomic prepend (POSIX-safe).
TMP="$(mktemp)"
{ printf '%s' "$HEADER"; cat "$OUTPUT"; } > "$TMP"
mv "$TMP" "$OUTPUT"

# Make the package directory a real Python package.
INIT="$(dirname "$OUTPUT")/__init__.py"
if [[ ! -f "$INIT" ]]; then
  printf '"""Generated schemas — see schemas.py for the auto-generated content."""\n' > "$INIT"
fi

echo "Regenerated $OUTPUT"
