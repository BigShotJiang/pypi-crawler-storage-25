"""Public type surface for ``routon-sdk``.

Wave 3 PR-W3-B: schema types regenerated from
``agent-brain/openapi.json`` via ``datamodel-codegen`` and re-exported
from ``routon._generated.schemas``. The hand-authored ergonomic types
below sit on top of the generated schemas and provide the SDK consumer
surface.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

# ─── Generated schemas (re-exported) ──────────────────────────────────
from routon._generated.schemas import (
    AuditRef,
    BuildResult,
    Bundle,
    BundleStep,
    ChainId,
    ChainName,
    CompositionResult,
    ConfidenceLevel,
    EligibilityReport,
    EmittedEvent,
    ExecutionTemplate,
    ExpectedApy,
    HealthResponse,
    Intent,
    Position,
    RebateBalance,
    RiskFactor,
    RiskScore,
    RoutonStrategy,
    SimulationResult,
    SlippageCurvePoint,
    UnsignedTransaction,
)
from routon._generated.schemas import (
    Error as RoutonApiError,
)

# ─── SDK ergonomic config ─────────────────────────────────────────────

RoutonChain = Literal["base", "arbitrum", "base-sepolia", "arbitrum-sepolia"]
RiskTolerance = Literal["conservative", "balanced", "aggressive"]


class RoutonAgentConfig(BaseModel):
    """Top-level config for :class:`RoutonAgent`.

    Pure-config object; HTTP client construction happens in
    :class:`RoutonAgent.__init__`.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    brain_url: str = Field(default="https://brain.routon.xyz")
    builder_code: str | None = Field(
        default=None, pattern=r"^0x[0-9a-fA-F]{64}$"
    )
    default_chain: RoutonChain = "base"
    timeout_seconds: float = Field(default=30.0, gt=0)


class ListCandidatesQuery(BaseModel):
    """Query params for ``GET /v1/strategies/candidates``."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    chain: ChainName
    asset: str | None = Field(default=None, pattern=r"^0x[0-9a-fA-F]{40}$")
    min_apy: float | None = Field(default=None, ge=0)
    max_risk_score: int | None = Field(default=None, ge=0, le=100)
    limit: int | None = Field(default=None, ge=1, le=200)


class ListCandidatesResult(BaseModel):
    """Response shape of ``GET /v1/strategies/candidates``."""

    candidates: list[RoutonStrategy]
    total: int = Field(ge=0)


class PositionsResult(BaseModel):
    """Response shape of ``GET /v1/positions/{userAddress}``."""

    positions: list[Position]


__all__ = [
    "AuditRef",
    "BuildResult",
    "Bundle",
    "BundleStep",
    "ChainId",
    "ChainName",
    "CompositionResult",
    "ConfidenceLevel",
    "EligibilityReport",
    "EmittedEvent",
    "ExecutionTemplate",
    "ExpectedApy",
    "HealthResponse",
    "Intent",
    "ListCandidatesQuery",
    "ListCandidatesResult",
    "Position",
    "PositionsResult",
    "RebateBalance",
    "RiskFactor",
    "RiskScore",
    "RiskTolerance",
    "RoutonAgentConfig",
    "RoutonApiError",
    "RoutonChain",
    "RoutonStrategy",
    "SimulationResult",
    "SlippageCurvePoint",
    "UnsignedTransaction",
]
