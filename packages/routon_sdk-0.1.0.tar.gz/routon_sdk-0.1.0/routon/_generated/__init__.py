"""Generated schemas — see schemas.py for the auto-generated content."""
