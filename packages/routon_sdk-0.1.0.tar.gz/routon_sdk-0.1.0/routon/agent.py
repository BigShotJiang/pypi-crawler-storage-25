"""RoutonAgent — async httpx-based client for the Routon Brain API.

Wave 3 PR-W3-B: real impl over ``agent-brain/openapi.json`` endpoints.
Cross-cutting headers: ``X-Builder-Code`` (when configured),
``Content-Type: application/json``, ``Accept: application/json``.

Live integration tests against deployed brain are deferred to PR-A.5+
(brain not yet deployed in Phase 2 Wave 2 close). Unit tests use
``httpx.MockTransport`` for hermetic in-process testing.
"""

from __future__ import annotations

import contextlib
from typing import Any

import httpx

from routon._generated.schemas import Bundle
from routon.types import (
    BuildResult,
    CompositionResult,
    EligibilityReport,
    HealthResponse,
    Intent,
    ListCandidatesQuery,
    ListCandidatesResult,
    Position,
    PositionsResult,
    RebateBalance,
    RiskScore,
    RoutonAgentConfig,
    RoutonApiError,
    RoutonStrategy,
    SimulationResult,
)


class RoutonApiException(Exception):  # noqa: N818 — mirrors sdk/ts RoutonApiException; cross-language symmetry trumps Python naming convention here
    """Raised for any non-2xx response. Carries the typed error envelope."""

    def __init__(self, status: int, message: str, error: RoutonApiError | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.error = error


class RoutonAgent:
    """Async client for the Routon Brain API + parity helpers.

    Parameters
    ----------
    config:
        Optional :class:`RoutonAgentConfig`. Defaults to production
        ``brain.routon.xyz`` with a 30 s timeout and no builder code.
    transport:
        Optional ``httpx`` transport for testing — pass an
        ``httpx.MockTransport`` to drive deterministic responses.
    """

    config: RoutonAgentConfig
    _client: httpx.AsyncClient

    def __init__(
        self,
        config: RoutonAgentConfig | None = None,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.config = config if config is not None else RoutonAgentConfig()
        headers: dict[str, str] = {"Accept": "application/json"}
        if self.config.builder_code:
            headers["X-Builder-Code"] = self.config.builder_code
        self._client = httpx.AsyncClient(
            base_url=self.config.brain_url,
            timeout=self.config.timeout_seconds,
            headers=headers,
            transport=transport,
        )

    async def __aenter__(self) -> RoutonAgent:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._client.aclose()

    # ─── HTTP plumbing ─────────────────────────────────────────────────

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
    ) -> Any:
        response = await self._client.request(method, path, params=params, json=json)
        if response.status_code >= 400:
            envelope: RoutonApiError | None = None
            with contextlib.suppress(Exception):
                # Body may not be JSON or may not match the envelope shape;
                # in that case leave envelope=None and surface the raw status.
                envelope = RoutonApiError.model_validate(response.json())
            raise RoutonApiException(
                status=response.status_code,
                message=envelope.message if envelope else f"HTTP {response.status_code} on {path}",
                error=envelope,
            )
        return response.json()

    # ─── Health ────────────────────────────────────────────────────────

    async def health(self) -> HealthResponse:
        """Liveness probe — ``GET /health``."""
        return HealthResponse.model_validate(await self._request("GET", "/health"))

    # ─── Strategies ────────────────────────────────────────────────────

    async def list_candidates(
        self, query: ListCandidatesQuery
    ) -> ListCandidatesResult:
        """``GET /v1/strategies/candidates`` — list eligible candidates."""
        params: dict[str, Any] = {"chain": query.chain.value}
        if query.asset is not None:
            params["asset"] = query.asset
        if query.min_apy is not None:
            params["min_apy"] = query.min_apy
        if query.max_risk_score is not None:
            params["max_risk_score"] = query.max_risk_score
        if query.limit is not None:
            params["limit"] = query.limit
        return ListCandidatesResult.model_validate(
            await self._request("GET", "/v1/strategies/candidates", params=params)
        )

    async def get_candidate(self, strategy_id: str) -> RoutonStrategy:
        """``GET /v1/strategies/candidates/{strategyId}``."""
        return RoutonStrategy.model_validate(
            await self._request("GET", f"/v1/strategies/candidates/{strategy_id}")
        )

    async def get_candidate_eligibility(self, strategy_id: str) -> EligibilityReport:
        """``GET /v1/strategies/candidates/{strategyId}/eligibility``."""
        return EligibilityReport.model_validate(
            await self._request(
                "GET", f"/v1/strategies/candidates/{strategy_id}/eligibility"
            )
        )

    async def find_best(self, intent: Intent) -> RoutonStrategy:
        """``POST /v1/strategies/find-best`` — best-strategy convenience."""
        return RoutonStrategy.model_validate(
            await self._request(
                "POST", "/v1/strategies/find-best", json=intent.model_dump(mode="json")
            )
        )

    # ─── Risk ──────────────────────────────────────────────────────────

    async def compute_risk_score(
        self, strategy_id: str, factor_overrides: dict[str, float] | None = None
    ) -> RiskScore:
        """``POST /v1/risk/score`` — compute fresh risk score."""
        body: dict[str, Any] = {"strategyId": strategy_id}
        if factor_overrides is not None:
            body["factorOverrides"] = factor_overrides
        return RiskScore.model_validate(
            await self._request("POST", "/v1/risk/score", json=body)
        )

    async def get_cached_risk_score(self, strategy_id: str) -> RiskScore:
        """``GET /v1/risk/score/{strategyId}`` — cached score read."""
        return RiskScore.model_validate(
            await self._request("GET", f"/v1/risk/score/{strategy_id}")
        )

    # ─── Composition ───────────────────────────────────────────────────

    async def compose_bundle(
        self, intent: Intent, candidates: list[str] | None = None
    ) -> CompositionResult:
        """``POST /v1/compose`` — multi-primitive bundle for an intent."""
        body: dict[str, Any] = {"intent": intent.model_dump(mode="json")}
        if candidates is not None:
            body["candidates"] = candidates
        return CompositionResult.model_validate(
            await self._request("POST", "/v1/compose", json=body)
        )

    # ─── Execution ─────────────────────────────────────────────────────

    async def simulate(self, intent: Intent, bundle: Bundle) -> SimulationResult:
        """``POST /v1/execute/build/preflight`` — sim-only, cheaper than build."""
        body = {
            "intent": intent.model_dump(mode="json"),
            "bundle": bundle.model_dump(mode="json"),
        }
        return SimulationResult.model_validate(
            await self._request("POST", "/v1/execute/build/preflight", json=body)
        )

    async def build_calldata(self, intent: Intent, bundle: Bundle) -> BuildResult:
        """``POST /v1/execute/build`` — final calldata + pre-flight simulation."""
        body = {
            "intent": intent.model_dump(mode="json"),
            "bundle": bundle.model_dump(mode="json"),
        }
        return BuildResult.model_validate(
            await self._request("POST", "/v1/execute/build", json=body)
        )

    # ─── Cross-cutting reads ───────────────────────────────────────────

    async def get_positions(self, user_address: str) -> list[Position]:
        """``GET /v1/positions/{userAddress}``."""
        result = PositionsResult.model_validate(
            await self._request("GET", f"/v1/positions/{user_address}")
        )
        return result.positions

    async def get_rebate_balance(self, builder_code: str) -> RebateBalance:
        """``GET /v1/rebates/{builderCode}``."""
        return RebateBalance.model_validate(
            await self._request("GET", f"/v1/rebates/{builder_code}")
        )
