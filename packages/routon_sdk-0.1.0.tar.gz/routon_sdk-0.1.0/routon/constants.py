"""Routon SDK constants."""

from typing import Final

ROUTON_STANDARD_VERSION: Final[str] = "0.1"
DEFAULT_BRAIN_URL: Final[str] = "https://brain.routon.xyz"

CHAIN_IDS: Final[dict[str, int]] = {
    "base": 8453,
    "arbitrum": 42_161,
    "base-sepolia": 84_532,
    "arbitrum-sepolia": 421_614,
}
