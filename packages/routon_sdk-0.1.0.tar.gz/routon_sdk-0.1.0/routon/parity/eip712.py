"""EIP-712 Attestation primitives — RoutonValidationRegistry.

Mirrors ``contracts/src/ValidationRegistry.sol`` lines 58-61 + 266 +
295-302. Off-chain signing of attestations consumed by
``ValidationRegistry.postAttestation()`` requires both the typehash
and the inner struct hash to match the on-chain values exactly — any
drift breaks attestation acceptance.

Cross-language parity:
- TypeScript: ``sdk/ts/src/parity/eip712.ts``
- Solidity: ``ValidationRegistry.sol:60-61`` (typehash) + ``:266`` (domain)
- agent-brain reference: ``agent-brain/src/risker/eip712.py``

Pinned cross-language regression-gate hex:
``keccak256(ATTESTATION_TYPEHASH_STRING) =
0xa053eabe2f3aa0e2285ffb34153a8263eed6a92603472b749d887154d4a0119a``.
"""

from __future__ import annotations

from typing import Final

from eth_abi import encode  # type: ignore[attr-defined]
from eth_utils import keccak  # type: ignore[attr-defined]

# ─── Domain (matches ValidationRegistry constructor line 266) ──────────

EIP712_DOMAIN_NAME: Final[str] = "RoutonValidationRegistry"
EIP712_DOMAIN_VERSION: Final[str] = "1"

# ─── Typehash (matches ValidationRegistry line 60-61 verbatim) ─────────

ATTESTATION_TYPEHASH_STRING: Final[str] = (
    "Attestation(address attestor,bytes32 strategyId,uint16 score,"
    "bytes32 factorsHash,uint64 deadline,uint64 nonce)"
)


def compute_attestation_typehash() -> str:
    """``keccak256(ATTESTATION_TYPEHASH_STRING)`` as 0x-prefixed bytes32 hex."""
    return "0x" + keccak(text=ATTESTATION_TYPEHASH_STRING).hex()


def compute_attestation_struct_hash(
    *,
    attestor: str,
    strategy_id: str,
    score_uint16: int,
    factors_hash: str,
    deadline: int,
    nonce: int,
) -> str:
    """Inner struct hash — matches ``ValidationRegistry`` line 299-301:

    ``keccak256(abi.encode(ATTESTATION_TYPEHASH, attestor, strategyId,
    score, factorsHash, deadline, nonce))``.

    The full EIP-712 digest is obtained by wrapping this with the domain
    separator via ``_hashTypedDataV4``; the ``risk-attestor`` agent
    consumes this inner hash + adds the domain separator at signing time.
    """
    typehash = bytes.fromhex(compute_attestation_typehash()[2:])
    encoded = encode(
        ["bytes32", "address", "bytes32", "uint16", "bytes32", "uint64", "uint64"],
        [
            typehash,
            attestor,
            bytes.fromhex(strategy_id[2:]),
            score_uint16,
            bytes.fromhex(factors_hash[2:]),
            deadline,
            nonce,
        ],
    )
    return "0x" + keccak(encoded).hex()
