"""9-field ExecuteParams encoder — Wave 2 PR-D money-safety boundary.

Mirrors ``contracts/src/PrimitiveExecutor.sol`` lines 36-46 + line 509
(``execute(ExecuteParams calldata p)``) byte-for-byte::

    struct ExecuteParams {
        bytes32 strategyId;
        uint256 amount;
        address user;
        bytes32 builderCode;
        uint256 minOut;
        bool    slippageWaived;
        uint16  maxRiskScore;
        uint64  deadline;
        bytes   data;
    }

Encoder output is byte-equivalent to ``cast abi-encode`` for any input —
verified externally and pinned via the same ``KNOWN_HEX`` vector that
``agent-brain/tests/test_router_unit.py::TestCalldataByteParity`` pins.

Cross-language parity:
- TypeScript: ``sdk/ts/src/parity/executeParams.ts``
- Solidity: ``PrimitiveExecutor.sol:36-46`` + ``:509``
- cast: ``cast abi-encode "f((bytes32,uint256,...))"``
- agent-brain reference: ``agent-brain/src/router/encoder.py``

Function selectors verified externally::

    cast sig "execute((bytes32,uint256,address,bytes32,uint256,bool,uint16,uint64,bytes))"
        -> 0x918fafc5

    cast sig "executeBatch((bytes32,uint256,address,bytes32,uint256,bool,uint16,uint64,bytes)[])"
        -> 0x062f75e9
"""

from __future__ import annotations

from typing import Any, Final

from eth_abi import encode  # type: ignore[attr-defined]

EXECUTE_PARAMS_ABI_TYPE: Final[str] = (
    "(bytes32,uint256,address,bytes32,uint256,bool,uint16,uint64,bytes)"
)

EXECUTE_SELECTOR: Final[str] = "0x918fafc5"
EXECUTE_BATCH_SELECTOR: Final[str] = "0x062f75e9"


def _hex_to_bytes(hex_str: str) -> bytes:
    s = hex_str[2:] if hex_str.startswith("0x") else hex_str
    return bytes.fromhex(s)


def encode_execute_params(
    *,
    strategy_id: str,
    amount: int,
    user: str,
    builder_code: str,
    min_out: int,
    slippage_waived: bool,
    max_risk_score: int,
    deadline: int,
    data: str,
) -> str:
    """Encode 9-field ExecuteParams as ``cast abi-encode`` would.

    Returns 0x-prefixed hex of the abi-encoded struct (with leading head
    offset for the dynamic-``bytes``-tail tuple). ``data`` is a
    0x-prefixed hex string; empty bytes = ``"0x"``.
    """
    values = (
        _hex_to_bytes(strategy_id),
        int(amount),
        user,
        _hex_to_bytes(builder_code),
        int(min_out),
        bool(slippage_waived),
        int(max_risk_score),
        int(deadline),
        _hex_to_bytes(data),
    )
    encoded = encode([EXECUTE_PARAMS_ABI_TYPE], [values])
    return "0x" + encoded.hex()


def encode_execute_calldata(
    *,
    strategy_id: str,
    amount: int,
    user: str,
    builder_code: str,
    min_out: int,
    slippage_waived: bool,
    max_risk_score: int,
    deadline: int,
    data: str,
) -> str:
    """Full tx calldata: ``EXECUTE_SELECTOR || abi.encode(p)``."""
    body = encode_execute_params(
        strategy_id=strategy_id,
        amount=amount,
        user=user,
        builder_code=builder_code,
        min_out=min_out,
        slippage_waived=slippage_waived,
        max_risk_score=max_risk_score,
        deadline=deadline,
        data=data,
    )
    return EXECUTE_SELECTOR + body[2:]


def encode_execute_batch_calldata(steps: list[dict[str, Any]]) -> str:
    """Full tx calldata: ``EXECUTE_BATCH_SELECTOR || abi.encode(p[])``."""
    array_type = f"{EXECUTE_PARAMS_ABI_TYPE}[]"
    tuple_values = [
        (
            _hex_to_bytes(s["strategy_id"]),
            int(s["amount"]),
            s["user"],
            _hex_to_bytes(s["builder_code"]),
            int(s["min_out"]),
            bool(s["slippage_waived"]),
            int(s["max_risk_score"]),
            int(s["deadline"]),
            _hex_to_bytes(s["data"]),
        )
        for s in steps
    ]
    encoded = encode([array_type], [tuple_values])
    return EXECUTE_BATCH_SELECTOR + encoded.hex()
