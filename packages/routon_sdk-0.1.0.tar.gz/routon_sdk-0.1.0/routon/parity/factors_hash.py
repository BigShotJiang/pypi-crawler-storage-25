"""Canonical factorsHash — RFC 8785 JCS keccak256.

Wave 2.5 cross-language unblock: ``jcs.canonicalize(factors)`` produces
RFC 8785-conformant UTF-8 bytes (ECMA-262 number formatter, sorted keys,
preserved array order); keccak256 over those bytes produces the on-chain
commitment posted via ``ValidationRegistry.postAttestation()``.

ECMA-262 number formatter ensures float ``1.0`` serializes as ``"1"``
(shortest round-trip), NOT ``"1.0"`` — the divergence that broke
cross-language parity in v1 (PR-B HIGH #1) and that PR-W2.5 cleanup
resolved on the agent-brain side.

Cross-language parity:
- TypeScript: ``sdk/ts/src/parity/factorsHash.ts`` (canonicalize@~2.0)
- Solidity (future): ECMA-262-conformant string serializer + keccak
- agent-brain reference: ``agent-brain/src/risker/scorer.py::canonical_factors_hash``

Pinned cross-language regression-gate hex (1-factor canonical input):
``0xdbc48e25c7c80fc02fb1ccc56aa160d5265518d9cba788996c885207723a8a62``.
"""

from __future__ import annotations

from typing import Any

import jcs
from eth_utils import keccak  # type: ignore[attr-defined]


def canonical_factors_hash(factors: list[dict[str, Any]]) -> str:
    """RFC 8785 JCS keccak256 of the factors array → 0x-prefixed bytes32 hex.

    Cross-language consumers (TypeScript via ``canonicalize@2``, Solidity
    reimpls via ECMA-262-conformant string serializer) MUST produce
    byte-identical canonical bytes for the same input. Drift = HIGH.
    """
    canonical: bytes = jcs.canonicalize(factors)
    return "0x" + keccak(canonical).hex()
