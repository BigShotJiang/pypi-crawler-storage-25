"""Parity helpers — audit-grade cross-language byte-equivalence.

Four anchors mirror the on-chain + agent-brain implementations
byte-for-byte (verified via pinned hex regression-gate tests):

1. 5-tuple keccak strategy id (StrategyRegistry.sol:334)
2. EIP-712 Attestation typehash (ValidationRegistry.sol:60-61)
3. RFC 8785 JCS factorsHash (Wave 2.5 unblock)
4. 9-field ExecuteParams encoder (PrimitiveExecutor.sol:36-46)

Re-implemented SDK-consumer-side per Wave 3 PR-W3-B founder direction
("both SDKs ship standalone; no agent-brain imports"). Drift on any
anchor = HIGH severity HALT.
"""

from routon.parity.eip712 import (
    ATTESTATION_TYPEHASH_STRING,
    EIP712_DOMAIN_NAME,
    EIP712_DOMAIN_VERSION,
    compute_attestation_struct_hash,
    compute_attestation_typehash,
)
from routon.parity.execute_params import (
    EXECUTE_BATCH_SELECTOR,
    EXECUTE_PARAMS_ABI_TYPE,
    EXECUTE_SELECTOR,
    encode_execute_batch_calldata,
    encode_execute_calldata,
    encode_execute_params,
)
from routon.parity.factors_hash import canonical_factors_hash
from routon.parity.strategy_id import compute_strategy_id, str_to_bytes32

__all__ = [
    "ATTESTATION_TYPEHASH_STRING",
    "EIP712_DOMAIN_NAME",
    "EIP712_DOMAIN_VERSION",
    "EXECUTE_BATCH_SELECTOR",
    "EXECUTE_PARAMS_ABI_TYPE",
    "EXECUTE_SELECTOR",
    "canonical_factors_hash",
    "compute_attestation_struct_hash",
    "compute_attestation_typehash",
    "compute_strategy_id",
    "encode_execute_batch_calldata",
    "encode_execute_calldata",
    "encode_execute_params",
    "str_to_bytes32",
]
