"""5-tuple keccak strategy id — Q-SD-6.

Mirrors the on-chain formula in ``contracts/src/StrategyRegistry.sol:334``:
``keccak256(abi.encode(uint16 chainId, bytes32 protocol, address asset,
address outputAsset, bytes32 strategyVersion))``.

Cross-language parity:
- TypeScript: ``sdk/ts/src/parity/strategyId.ts``
- Solidity: ``StrategyRegistry.sol:334``
- agent-brain reference: ``agent-brain/src/discoverer/ids.py``

Re-implemented SDK-consumer-side per Wave 3 PR-W3-B founder direction
("not vendored from agent-brain"). Same algorithm, same pinned outputs.
"""

from __future__ import annotations

from eth_abi import encode  # type: ignore[attr-defined]
from eth_utils import keccak  # type: ignore[attr-defined]


def str_to_bytes32(s: str) -> bytes:
    """Right-pad ASCII string to 32 bytes (matches Solidity ``bytes32("...")``).

    Raises ValueError if the string exceeds 32 ASCII bytes.
    """
    raw = s.encode("ascii")
    if len(raw) > 32:
        raise ValueError(f"string too long for bytes32: {s!r} ({len(raw)} bytes)")
    return raw.ljust(32, b"\x00")


def compute_strategy_id(
    chain_id: int,
    protocol: str,
    asset: str,
    output_asset: str,
    strategy_version: str,
) -> str:
    """Compute the 5-tuple keccak strategy id.

    Args:
        chain_id: EIP-155 chain id (uint16 on-chain — Base 8453, Arbitrum 42161,
            Sepolias 84532 / 421614).
        protocol: ASCII protocol slug (≤32 bytes), e.g. ``"aave-v3"``.
        asset: Input ERC-20 address (0x-prefixed; case-insensitive).
        output_asset: Output ERC-20 / LP / vault-share address.
        strategy_version: ASCII version slug (≤32 bytes), e.g. ``"0.1"``.

    Returns:
        0x-prefixed 64-hex-char string (Bytes32) matching the on-chain id.
    """
    encoded = encode(
        ["uint16", "bytes32", "address", "address", "bytes32"],
        [
            chain_id,
            str_to_bytes32(protocol),
            asset,
            output_asset,
            str_to_bytes32(strategy_version),
        ],
    )
    return "0x" + keccak(encoded).hex()
