"""``mitoribopy all`` subcommand - align -> rpf -> (optional) rnaseq.

Phase 6 of the v0.3.0 refactor. Runs the three per-stage subcommands in
sequence with a single shared config file and writes a composed
``run_manifest.json`` at the run root that records every parameter,
tool version, and input/output hash so a reviewer can reproduce the
full pipeline from the manifest alone.

Invocation pattern::

    mitoribopy all --config pipeline_config.yaml --output results/

The YAML (or JSON / TOML) config has three optional sections::

    align:   { kit_preset: truseq_smallrna, fastq_dir: fastqs/, ... }
    rpf:     { strain: h, rpf: [29, 34], ... }
    rnaseq:  { de_table: de.tsv, gene_id_convention: hgnc, ... }

Each section's keys correspond to the CLI flag names of the matching
subcommand with dashes replaced by underscores. ``mitoribopy all``
reconstructs a flag list from the section and calls the subcommand's
``run()`` entry point.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Iterable

from .. import __version__
from ..cli.common import load_config_file
from . import common


ALL_SUBCOMMAND_HELP = (
    "End-to-end orchestrator: align + rpf, plus rnaseq when the config "
    "carries an 'rnaseq' section with --de-table. Writes a composed "
    "run_manifest.json with tool versions, parameters, and input/output "
    "hashes across all three stages."
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mitoribopy all",
        description=ALL_SUBCOMMAND_HELP,
        epilog=(
            "This subcommand owns only the orchestrator flags. Stage-specific options live\n"
            "inside the config file sections whose keys match the subcommand flags\n"
            "(with dashes replaced by underscores, e.g. '--kit-preset' -> 'kit_preset').\n"
            "  align:  keys for 'mitoribopy align --help'\n"
            "  rpf:    keys for 'mitoribopy rpf --help'\n"
            "  rnaseq: keys for 'mitoribopy rnaseq --help'\n"
            "\n"
            "Start a new project:\n"
            "  mitoribopy all --print-config-template > pipeline_config.yaml\n"
            "  # edit the file to point at your FASTQs / indexes, then:\n"
            "  mitoribopy all --config pipeline_config.yaml --output results/\n"
            "\n"
            "Inspect a stage's full flag list:\n"
            "  mitoribopy all --show-stage-help align\n"
            "  mitoribopy all --show-stage-help rpf\n"
            "  mitoribopy all --show-stage-help rnaseq"
        ),
        formatter_class=common.MitoRiboPyHelpFormatter,
    )
    common.add_common_arguments(parser)
    parser.add_argument(
        "--output",
        required=False,
        metavar="DIR",
        help=(
            "Run root directory. Each stage writes under "
            "<output>/align/, <output>/rpf/, and <output>/rnaseq/ when "
            "the stage is active."
        ),
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        default=False,
        help=(
            "Skip stages whose expected output already exists: align "
            "is skipped when <output>/align/read_counts.tsv is present; "
            "rpf when <output>/rpf/rpf_counts.tsv is present; rnaseq "
            "when <output>/rnaseq/delta_te.tsv is present."
        ),
    )
    parser.add_argument(
        "--skip-align",
        action="store_true",
        default=False,
        help="Skip the align stage even when an [align] section exists.",
    )
    parser.add_argument(
        "--skip-rpf",
        action="store_true",
        default=False,
        help="Skip the rpf stage.",
    )
    parser.add_argument(
        "--skip-rnaseq",
        action="store_true",
        default=False,
        help="Skip the rnaseq stage even when an [rnaseq] section exists.",
    )
    parser.add_argument(
        "--manifest",
        default="run_manifest.json",
        metavar="PATH",
        help="Manifest filename (relative to --output).",
    )
    parser.add_argument(
        "--show-stage-help",
        choices=["align", "rpf", "rnaseq"],
        default=None,
        metavar="STAGE",
        help=(
            "Print the full help for one stage and exit. Useful because "
            "'mitoribopy all --help' only shows orchestrator-level flags."
        ),
    )
    parser.add_argument(
        "--print-config-template",
        action="store_true",
        default=False,
        help=(
            "Print a commented YAML config template covering every stage "
            "(align / rpf / rnaseq) with sensible defaults, then exit. "
            "Pipe this into a file to start a new project: "
            "'mitoribopy all --print-config-template > pipeline_config.yaml'."
        ),
    )
    return parser


# ---------------------------------------------------------------------------
# argv reconstruction from a config section
# ---------------------------------------------------------------------------


def _dict_to_argv(section: dict, *, flag_style: str = "hyphen") -> list[str]:
    """Serialize a section dict into a CLI-style argv list.

    Rules:

    * ``flag_style="hyphen"`` (default, for ``align`` and ``rnaseq``):
      keys with underscores become ``--dashed-form`` flags.
    * ``flag_style="underscore"`` (for ``rpf``, whose argparse declares
      its flags with underscores like ``--offset_type``): keys are
      emitted verbatim with a ``--`` prefix.
    * Boolean ``True`` emits just the flag; ``False`` emits nothing.
    * Lists / tuples are emitted as ``--flag v1 v2 v3`` (nargs="+" style).
    * ``None`` values are skipped.

    The per-stage ``flag_style`` is necessary because the ``rpf`` stage
    parser (``pipeline.runner``) declares its flags in the legacy
    underscore form (``--offset_type``, ``--min_5_offset``, ...), so
    emitting hyphenated flags would be rejected with
    ``unrecognized arguments``.
    """
    if flag_style not in {"hyphen", "underscore"}:
        raise ValueError(
            f"flag_style must be 'hyphen' or 'underscore', got {flag_style!r}."
        )

    argv: list[str] = []
    for key, value in section.items():
        if flag_style == "underscore":
            flag = f"--{key.replace('-', '_')}"
        else:
            flag = f"--{key.replace('_', '-')}"
        if value is None:
            continue
        if isinstance(value, bool):
            if value:
                argv.append(flag)
            continue
        if isinstance(value, (list, tuple)):
            argv.append(flag)
            argv.extend(str(v) for v in value)
            continue
        argv.extend([flag, str(value)])
    return argv


# Per-stage config-template comment, also used by --print-config-template.
_CONFIG_TEMPLATE = """\
# mitoribopy all --config pipeline_config.yaml --output results/
#
# Every key below corresponds one-to-one to the matching subcommand's
# CLI flag (dashes replaced by underscores). Unset keys fall back to
# that subcommand's documented default. Omit a whole section to skip
# that stage; 'mitoribopy all' will record it as skipped in the manifest.
#
# Use 'mitoribopy all --show-stage-help {align,rpf,rnaseq}' for the
# full flag list with defaults.

# ---- align -----------------------------------------------------------------
align:
  # Library chemistry
  kit_preset: custom              # truseq_smallrna | nebnext_smallrna |
                                  # nebnext_ultra_umi | qiaseq_mirna | custom
  adapter: null                   # required when kit_preset=custom, else optional
  adapter_detection: auto         # auto | off | strict
  umi_length: null                # overrides kit preset
  umi_position: null              # 5p | 3p

  # Inputs / reference indexes (bowtie2 prefixes built by bowtie2-build)
  fastq_dir: null
  # OR explicit list:
  # fastq:
  #   - /path/to/sample_A.fq.gz
  #   - /path/to/sample_B.fq.gz
  contam_index: null              # REQUIRED: rRNA/tRNA bowtie2 index prefix
  mt_index: null                  # REQUIRED: mt-transcriptome bowtie2 index prefix

  # Strandedness / length window / MAPQ / dedup
  library_strandedness: forward   # forward | reverse | unstranded
  min_length: 15
  max_length: 45
  quality: 20
  mapq: 10
  seed: 42
  dedup_strategy: auto            # auto | umi-tools | skip | mark-duplicates

# ---- rpf -------------------------------------------------------------------
rpf:
  # Organism + RPF length window
  strain: h                       # h | y | vm | ym | custom
  rpf: [29, 34]                   # min and max RPF length
  fasta: null                     # reference FASTA (mt-transcriptome)
  directory: null                 # BED input dir (auto-wired from align/bed/)

  # Offset anchor + selection bounds
  align: stop                     # start | stop
  offset_type: "5"                # "5" | "3"  (report offsets from the 5' or 3' end)
  offset_site: p                  # p | a      (P-site vs A-site)
  offset_pick_reference: p_site
  min_5_offset: 10
  max_5_offset: 22
  min_3_offset: 10
  max_3_offset: 22
  offset_mask_nt: 5

  # Output / plotting
  plot_format: svg                # png | pdf | svg
  merge_density: true
  structure_density: false

  # Optional downstream modules
  cor_plot: false
  base_sample: null

# ---- rnaseq (optional) -----------------------------------------------------
# Uncomment + populate de_table to enable the translation-efficiency stage.
# rnaseq:
#   de_table: /path/to/de_table.tsv
#   gene_id_convention: hgnc       # hgnc | ensembl | refseq | entrez
#   reference_gtf: /path/to/reference.fa  # must match align's --mt-index source
#   condition_map: /path/to/conditions.tsv
#   condition_a: control
#   condition_b: knockdown
"""


def _print_config_template() -> None:
    """Write the commented config template to stdout."""
    sys.stdout.write(_CONFIG_TEMPLATE)


def _sha256_of(path: Path) -> str | None:
    try:
        digest = hashlib.sha256()
        with Path(path).open("rb") as handle:
            for chunk in iter(lambda: handle.read(65536), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except OSError:
        return None


def _read_stage_settings(stage_dir: Path) -> dict | None:
    path = stage_dir / "run_settings.json"
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _write_manifest(
    output_dir: Path,
    manifest_name: str,
    *,
    stages_run: list[str],
    stages_skipped: list[str],
    align_settings: dict | None,
    rpf_settings: dict | None,
    rnaseq_settings: dict | None,
) -> Path:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "subcommand": "all",
        "mitoribopy_version": __version__,
        "stages_run": stages_run,
        "stages_skipped": stages_skipped,
        "align": align_settings,
        "rpf": rpf_settings,
        "rnaseq": rnaseq_settings,
    }

    # Promote rpf's reference_checksum so future rnaseq invocations
    # reading this manifest directly can find it without drilling into
    # the rpf section.
    if rpf_settings and rpf_settings.get("reference_checksum"):
        manifest["reference_checksum"] = rpf_settings["reference_checksum"]

    path = output_dir / manifest_name
    path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8"
    )
    return path


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


def _auto_wire_paths(
    config: dict,
    *,
    run_root: Path,
    has_align: bool,
    has_rpf: bool,
    has_rnaseq: bool,
    has_de_table: bool,
) -> None:
    """Set stage-specific --output defaults and cross-stage wiring.

    After this call:
    * ``config['align']['output']``  defaults to ``<run_root>/align``.
    * ``config['rpf']['output']``    defaults to ``<run_root>/rpf``.
    * ``config['rpf']['directory']`` defaults to the align BED dir.
    * ``config['rnaseq']['output']`` defaults to ``<run_root>/rnaseq``.
    * ``config['rnaseq']['ribo_dir']`` defaults to the rpf output.
    """
    align_cfg = config.setdefault("align", {}) if has_align else {}
    rpf_cfg = config.setdefault("rpf", {}) if has_rpf else {}
    rnaseq_cfg = config.setdefault("rnaseq", {}) if has_rnaseq else {}

    if has_align:
        align_cfg.setdefault("output", str(run_root / "align"))

    if has_rpf:
        rpf_cfg.setdefault("output", str(run_root / "rpf"))
        # When align ran, its BED6 outputs live at <align>/bed/.
        if has_align:
            rpf_cfg.setdefault("directory", str(run_root / "align" / "bed"))
            rpf_cfg.setdefault(
                "read_counts_file", str(run_root / "align" / "read_counts.tsv")
            )

    if has_rnaseq and has_de_table:
        rnaseq_cfg.setdefault("output", str(run_root / "rnaseq"))
        if has_rpf:
            rnaseq_cfg.setdefault("ribo-dir", str(run_root / "rpf"))


def _should_skip_align(output: Path) -> bool:
    return (output / "align" / "read_counts.tsv").is_file()


def _should_skip_rpf(output: Path) -> bool:
    return (output / "rpf" / "rpf_counts.tsv").is_file()


def _should_skip_rnaseq(output: Path) -> bool:
    return (output / "rnaseq" / "delta_te.tsv").is_file()


def run(argv: Iterable[str]) -> int:
    """Entry point for ``mitoribopy all <args>``."""
    parser = build_parser()
    args = parser.parse_args(list(argv))
    common.apply_common_arguments(args)

    if args.print_config_template:
        _print_config_template()
        return 0

    if args.show_stage_help:
        from . import align as align_cli
        from . import rnaseq as rnaseq_cli
        from ..config import DEFAULT_CONFIG
        from ..pipeline import runner as pipeline_runner

        stage_parsers = {
            "align": align_cli.build_parser,
            "rpf": lambda: pipeline_runner.build_parser(dict(DEFAULT_CONFIG)),
            "rnaseq": rnaseq_cli.build_parser,
        }
        stage_parsers[args.show_stage_help]().print_help()
        return 0

    if not args.config:
        if args.dry_run:
            return common.emit_dry_run(
                "all",
                [
                    "load --config YAML/JSON/TOML with align: / rpf: / rnaseq: sections",
                    "auto-wire stage --output and cross-stage --directory / --ribo-dir",
                    "run align -> rpf -> (optional) rnaseq, honoring --resume / --skip-*",
                    "write run_manifest.json with tool versions and reference_checksum",
                ],
            )
        print(
            "[mitoribopy all] ERROR: --config <path> is required; it holds "
            "the align / rpf / rnaseq sections.",
            file=sys.stderr,
        )
        return 2

    if not args.output and not args.dry_run:
        print(
            "[mitoribopy all] ERROR: --output <dir> is required (the run "
            "root for align/, rpf/, rnaseq/).",
            file=sys.stderr,
        )
        return 2

    try:
        config = load_config_file(args.config)
    except (FileNotFoundError, RuntimeError, ValueError) as exc:
        print(f"[mitoribopy all] ERROR: {exc}", file=sys.stderr)
        return 2

    run_root = Path(args.output) if args.output else Path(".")
    has_align = bool(config.get("align")) and not args.skip_align
    has_rpf = bool(config.get("rpf")) and not args.skip_rpf
    has_rnaseq = bool(config.get("rnaseq")) and not args.skip_rnaseq
    has_de_table = has_rnaseq and bool(config.get("rnaseq", {}).get("de_table")
                                       or config.get("rnaseq", {}).get("de-table"))

    _auto_wire_paths(
        config,
        run_root=run_root,
        has_align=has_align,
        has_rpf=has_rpf,
        has_rnaseq=has_rnaseq,
        has_de_table=has_de_table,
    )

    if args.dry_run:
        plan: list[str] = []
        if has_align:
            plan.append(
                "align: "
                + " ".join(_dict_to_argv(config.get("align", {}), flag_style="hyphen"))
            )
        if has_rpf:
            plan.append(
                "rpf: "
                + " ".join(
                    _dict_to_argv(config.get("rpf", {}), flag_style="underscore")
                )
            )
        if has_rnaseq and has_de_table:
            plan.append(
                "rnaseq: "
                + " ".join(_dict_to_argv(config.get("rnaseq", {}), flag_style="hyphen"))
            )
        if not plan:
            plan.append("(no stages selected after --skip-*/config evaluation)")
        plan.append(f"write manifest to {run_root / args.manifest}")
        return common.emit_dry_run("all", plan)

    stages_run: list[str] = []
    stages_skipped: list[str] = []

    # Import subcommand entry points here to avoid a circular import at
    # module load time.
    from . import align as align_cli
    from . import rnaseq as rnaseq_cli
    from . import rpf as rpf_cli

    # --- align ----------------------------------------------------------
    if has_align:
        if args.resume and _should_skip_align(run_root):
            stages_skipped.append("align")
        else:
            align_argv = _dict_to_argv(config["align"], flag_style="hyphen")
            rc = align_cli.run(align_argv)
            if rc != 0:
                print(
                    f"[mitoribopy all] align stage failed with exit code {rc}.",
                    file=sys.stderr,
                )
                return rc
            stages_run.append("align")
    else:
        stages_skipped.append("align")

    # --- rpf ------------------------------------------------------------
    if has_rpf:
        if args.resume and _should_skip_rpf(run_root):
            stages_skipped.append("rpf")
        else:
            rpf_argv = _dict_to_argv(config["rpf"], flag_style="underscore")
            rc = rpf_cli.run(rpf_argv)
            if rc != 0:
                print(
                    f"[mitoribopy all] rpf stage failed with exit code {rc}.",
                    file=sys.stderr,
                )
                return rc
            stages_run.append("rpf")
    else:
        stages_skipped.append("rpf")

    # --- rnaseq (optional) ---------------------------------------------
    if has_rnaseq and has_de_table:
        if args.resume and _should_skip_rnaseq(run_root):
            stages_skipped.append("rnaseq")
        else:
            rnaseq_argv = _dict_to_argv(config["rnaseq"], flag_style="hyphen")
            rc = rnaseq_cli.run(rnaseq_argv)
            if rc != 0:
                print(
                    f"[mitoribopy all] rnaseq stage failed with exit code {rc}.",
                    file=sys.stderr,
                )
                return rc
            stages_run.append("rnaseq")
    else:
        stages_skipped.append("rnaseq")

    # --- manifest -------------------------------------------------------
    _write_manifest(
        output_dir=run_root,
        manifest_name=args.manifest,
        stages_run=stages_run,
        stages_skipped=stages_skipped,
        align_settings=_read_stage_settings(run_root / "align"),
        rpf_settings=_read_stage_settings(run_root / "rpf"),
        rnaseq_settings=_read_stage_settings(run_root / "rnaseq"),
    )
    return 0
