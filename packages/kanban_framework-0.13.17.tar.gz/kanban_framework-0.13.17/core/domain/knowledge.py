"""Knowledge management backed by SQLite (stdlib, zero deps).

Single .db file replaces entries/*.json, index.json, usage-log.json, domains.json.
FTS5 provides full-text search with BM25 ranking.
"""
from __future__ import annotations
import json
import sqlite3
from datetime import datetime, timezone, timedelta

DEFAULT_DOMAINS = {
    "cli": {"label": "CLI 命令", "keywords": ["argparse", "dispatch", "subcommand", "cli"]},
    "agent": {"label": "Agent 定义", "keywords": ["agent", "prompt", "role", "model"]},
    "testing": {"label": "测试", "keywords": ["pytest", "assert", "mock", "coverage", "test"]},
    "infra": {"label": "基础设施", "keywords": ["filesystem", "git", "config", "worktree", "path"]},
    "workflow": {"label": "工作流", "keywords": ["FSM", "state", "transition", "iteration", "phase"]},
    "dashboard": {"label": "看板仪表盘", "keywords": ["dashboard", "frontend", "js", "css"]},
    "git": {"label": "版本控制", "keywords": ["commit", "branch", "merge", "push", "remote"]},
}

STALE_DAYS = 30


class KnowledgeManager:
    def __init__(self, fs):
        self._fs = fs
        db_dir = fs.kanban_dir / "knowledge"
        fs.ensure_dir(db_dir)
        self._db_path = db_dir / "knowledge.db"
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._ensure_schema()
        self._ensure_domains()

    # -- schema --

    def _ensure_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS entries (
                id TEXT PRIMARY KEY,
                domain TEXT NOT NULL,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                code_example TEXT DEFAULT '',
                tags TEXT DEFAULT '[]',
                source TEXT DEFAULT '{}',
                severity TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'active',
                created_at TEXT NOT NULL,
                updated_at TEXT,
                stale_at TEXT,
                referenced_count INTEGER DEFAULT 0,
                last_referenced_at TEXT,
                last_referenced_by TEXT
            );
            CREATE VIRTUAL TABLE IF NOT EXISTS entries_fts USING fts5(
                title, content, code_example, tags, content=entries, content_rowid=rowid
            );
            CREATE TRIGGER IF NOT EXISTS entries_ai AFTER INSERT ON entries BEGIN
                INSERT INTO entries_fts(rowid, title, content, code_example, tags)
                VALUES (new.rowid, new.title, new.content, new.code_example, new.tags);
            END;
            CREATE TRIGGER IF NOT EXISTS entries_ad AFTER DELETE ON entries BEGIN
                INSERT INTO entries_fts(entries_fts, rowid, title, content, code_example, tags)
                VALUES ('delete', old.rowid, old.title, old.content, old.code_example, old.tags);
            END;
            CREATE TRIGGER IF NOT EXISTS entries_au AFTER UPDATE ON entries BEGIN
                INSERT INTO entries_fts(entries_fts, rowid, title, content, code_example, tags)
                VALUES ('delete', old.rowid, old.title, old.content, old.code_example, old.tags);
                INSERT INTO entries_fts(rowid, title, content, code_example, tags)
                VALUES (new.rowid, new.title, new.content, new.code_example, new.tags);
            END;
            CREATE TABLE IF NOT EXISTS usage_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_id TEXT NOT NULL,
                task_id TEXT NOT NULL,
                timestamp TEXT NOT NULL
            );
        """)

    def _ensure_domains(self):
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS domains (name TEXT PRIMARY KEY, label TEXT, keywords TEXT)"
        )
        existing = {r[0] for r in self._conn.execute("SELECT name FROM domains")}
        for name, info in DEFAULT_DOMAINS.items():
            if name not in existing:
                self._conn.execute(
                    "INSERT INTO domains(name, label, keywords) VALUES(?,?,?)",
                    (name, info["label"], json.dumps(info["keywords"])),
                )

    # -- public API --

    def add_entry(self, *, domain, category, title, content,
                  tags=None, severity="medium", source=None, code_example="",
                  status="active"):
        tags = tags or []
        source = source or {}
        eid = self._next_id()
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """INSERT INTO entries(id, domain, category, title, content, code_example,
               tags, source, severity, status, created_at, updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, domain, category, title, content, code_example,
             json.dumps(tags), json.dumps(source), severity, status, now, now),
        )
        self._conn.commit()
        return self.get_entry(eid)

    def get_entry(self, entry_id):
        row = self._conn.execute("SELECT * FROM entries WHERE id=?", (entry_id,)).fetchone()
        return self._row_to_dict(row) if row else None

    def search(self, keyword, domain=None, limit=20):
        if not keyword:
            return []
        query = """SELECT e.*, rank FROM entries_fts f
                   JOIN entries e ON e.rowid = f.rowid
                   WHERE entries_fts MATCH ? ORDER BY rank LIMIT ?"""
        params = [keyword, limit]
        rows = self._conn.execute(query, params).fetchall()
        results = [self._row_to_dict(r) for r in rows]
        if domain:
            results = [r for r in results if r["domain"] == domain]
        return results

    def search_by_domain(self, domain, severity=None, status="active", limit=20):
        rows = self._conn.execute(
            """SELECT * FROM entries WHERE domain=? AND status=?
               {} ORDER BY referenced_count DESC LIMIT ?""".format(
                "AND severity=?" if severity else ""),
            (domain, status, *([severity] if severity else []), limit),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_by_tag(self, tag):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE tags LIKE ?", (f'%"{tag}"%',)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_by_task(self, task_id):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE source LIKE ?", (f'%"{task_id}"%',)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def record_usage(self, entry_id, task_id):
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            "UPDATE entries SET referenced_count=referenced_count+1,"
            " last_referenced_at=?, last_referenced_by=?, stale_at=NULL,"
            " status='active' WHERE id=?",
            (now, task_id, entry_id),
        )
        self._conn.execute(
            "INSERT INTO usage_log(entry_id, task_id, timestamp) VALUES(?,?,?)",
            (entry_id, task_id, now),
        )
        self._conn.commit()

    def mark_stale_entries(self):
        threshold = (datetime.now(timezone.utc) - timedelta(days=STALE_DAYS)).isoformat()
        rows = self._conn.execute(
            """SELECT id FROM entries WHERE status='active'
               AND COALESCE(last_referenced_at, created_at) < ?""",
            (threshold,),
        ).fetchall()
        stale_ids = [r[0] for r in rows]
        if stale_ids:
            now = datetime.now(timezone.utc).isoformat()
            placeholders = ",".join("?" * len(stale_ids))
            self._conn.execute(
                f"UPDATE entries SET status='stale', stale_at=? WHERE id IN ({placeholders})",
                [now] + stale_ids,
            )
            self._conn.commit()
        return stale_ids

    def get_domains(self):
        rows = self._conn.execute("SELECT name, label, keywords FROM domains").fetchall()
        domains = {}
        for r in rows:
            domains[r[0]] = {"label": r[1], "keywords": json.loads(r[2])}
        return {"domains": domains or DEFAULT_DOMAINS}

    def match_domain(self, text):
        domains = self.get_domains()
        text_lower = text.lower()
        scores = {}
        for name, info in domains.get("domains", DEFAULT_DOMAINS).items():
            for kw in info.get("keywords", []):
                if kw.lower() in text_lower:
                    scores[name] = scores.get(name, 0) + 1
        return sorted(scores, key=scores.get, reverse=True)

    def find_similar_pitfalls(self, tags, min_tag_overlap=2):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE category='踩坑' AND status='active'"
        ).fetchall()
        tags_set = set(tags)
        results = []
        for r in rows:
            entry = self._row_to_dict(r)
            overlap = len(tags_set & set(entry.get("tags", [])))
            if overlap >= min_tag_overlap:
                results.append({**entry, "tag_overlap": overlap})
        results.sort(key=lambda x: x["tag_overlap"], reverse=True)
        return results

    def find_conflicting_solutions(self, task_id=""):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE category!='踩坑' AND status='active'"
        ).fetchall()
        entries = [self._row_to_dict(r) for r in rows]
        by_domain = {}
        for e in entries:
            by_domain.setdefault(e["domain"], []).append(e)
        conflicts = []
        for domain, ents in by_domain.items():
            n = len(ents)
            for i in range(n):
                for j in range(i + 1, n):
                    a, b = ents[i], ents[j]
                    tags_a = set(a.get("tags", []))
                    tags_b = set(b.get("tags", []))
                    overlap = len(tags_a & tags_b)
                    if overlap < 2:
                        continue
                    if a.get("category") != "架构" and b.get("category") != "架构":
                        continue
                    conflicts.append({
                        "entry_a": a["id"], "entry_b": b["id"],
                        "title_a": a["title"], "title_b": b["title"],
                        "domain": domain,
                        "shared_tags": sorted(tags_a & tags_b),
                        "tag_overlap": overlap,
                        "content_a": a["content"][:200],
                        "content_b": b["content"][:200],
                    })
        return conflicts

    def get_knowledge_gap_report(self):
        rows = self._conn.execute("SELECT domain, category FROM entries WHERE status='active'").fetchall()
        domain_counts = {}
        domain_pitfalls = {}
        for r in rows:
            d, c = r[0], r[1]
            domain_counts[d] = domain_counts.get(d, 0) + 1
            if c == "踩坑":
                domain_pitfalls[d] = domain_pitfalls.get(d, 0) + 1
        gaps = {}
        for d, pitfall_count in domain_pitfalls.items():
            if domain_counts.get(d, 1) < pitfall_count * 2:
                gaps[d] = {"total_entries": domain_counts.get(d, 0), "pitfalls": pitfall_count}
        return gaps

    def migrate_legacy_log(self):
        """Migrate old knowledge-log.md to SQLite entries. Returns count."""
        import re
        log_path = self._fs.kanban_dir / "knowledge-log.md"
        if not self._fs.file_exists(log_path):
            return 0
        pattern = re.compile(r'###\s+(\S+):\s*(.+?)\n\s*\n(.*?)(?=\n###|\Z)', re.DOTALL)
        text = log_path.read_text(encoding="utf-8")
        count = 0
        for m in pattern.finditer(text):
            category = m.group(1)
            title = m.group(2).strip()
            content = m.group(3).strip()
            self.add_entry(
                domain=self.match_domain(f"{title} {content}")[0] if self.match_domain(title) else "infra",
                category=category, title=title, content=content,
                tags=[category], source={"migrated_from": "knowledge-log.md"},
            )
            count += 1
        log_path.rename(log_path.with_suffix(".md.bak"))
        return count

    # -- helpers --

    def _next_id(self):
        row = self._conn.execute(
            "SELECT id FROM entries ORDER BY CAST(SUBSTR(id, 2) AS INTEGER) DESC LIMIT 1"
        ).fetchone()
        if not row:
            return "K001"
        try:
            return f"K{int(row[0][1:]) + 1:03d}"
        except ValueError:
            return "K001"

    def _row_to_dict(self, row):
        d = dict(row)
        for field in ("tags", "source"):
            if field in d and isinstance(d[field], str):
                try:
                    d[field] = json.loads(d[field])
                except (json.JSONDecodeError, TypeError):
                    d[field] = [] if field == "tags" else {}
        return d

    def _all_entry_ids(self):
        return [r[0] for r in self._conn.execute("SELECT id FROM entries ORDER BY id")]

    def close(self):
        self._conn.close()
