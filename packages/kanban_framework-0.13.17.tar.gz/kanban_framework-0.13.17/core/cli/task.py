from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from core.infra.filesystem import Filesystem
from core.infra.config import Config
from core.domain.task import TaskManager, TaskNotFoundError
from core.domain.scanner import scan_project, ScanReport, generate_default_test_profile
from core.infra.scheduler import Scheduler


def _resolve() -> tuple[Filesystem, Config, TaskManager]:
    root = Filesystem.find_project_root()
    fs = Filesystem(root=root)
    cfg = Config(fs)
    return fs, cfg, TaskManager(fs, cfg)


def _serialize_report(report: ScanReport) -> dict:
    return {
        "project_root": report.project_root,
        "language": report.language,
        "has_kanban": report.has_kanban,
        "agent_conflicts": [
            {
                "role": c.role,
                "kanban_agent": c.kanban_agent,
                "project_file": c.project_agent_file,
                "action": c.action,
                "description": c.description,
            }
            for c in report.agent_conflicts
        ],
        "existing_skills": report.existing_skills,
        "infrastructure_gaps": [
            {
                "category": g.category,
                "tool": g.tool,
                "detected": g.detected,
                "suggestion": g.suggestion,
            }
            for g in report.infrastructure_gaps
        ],
        "skill_gaps": [
            {
                "skill_name": g.skill_name,
                "required_by": g.required_by,
                "suggestion": g.suggestion,
            }
            for g in report.skill_gaps
        ],
        "recommendations": report.recommendations,
    }


def cmd_init(args: list[str]) -> dict:
    fs, _, _ = _resolve()
    root = Filesystem.find_project_root()

    # Ensure .kanban/ directory structure exists (fix #80)
    required_dirs = [
        fs.kanban_dir,
        fs.kanban_dir / "tasks",
        fs.kanban_dir / "archive",
        fs.kanban_dir / "inbox",
        fs.kanban_dir / "reports",
        fs.kanban_dir / "dashboard",
        fs.kanban_dir / "skills" / "evolved",
    ]
    created = []
    for d in required_dirs:
        if not d.exists():
            d.mkdir(parents=True)
            created.append(str(d.relative_to(root)))

    # Ensure config.json exists
    config_file = fs.config_file()
    if not fs.file_exists(config_file):
        import sys
        python_bin = sys.executable
        fs.write_json(config_file, {
            "output_dir": "src",
            "max_iterations": 6,
            "pass_threshold": 8.0,
            "python_bin": python_bin,
        })
        created.append(str(config_file.relative_to(root)))

    # Ensure workflow.json exists (use embedded default, no file dependency)
    workflow_file = fs.workflow_file()
    if not fs.file_exists(workflow_file):
        from core.infra.consts import DEFAULT_WORKFLOW
        template = json.loads(DEFAULT_WORKFLOW)
        fs.write_json(workflow_file, template)
        created.append(str(workflow_file.relative_to(root)))

    # Generate test_profile.md if not exists
    test_profile_path = fs.kanban_dir / "test_profile.md"
    if not fs.file_exists(test_profile_path):
        lang = "python"  # default before scan
        cfg = fs.read_json(config_file) if fs.file_exists(config_file) else {}
        out_dir = cfg.get("output_dir", "src")
        content = generate_default_test_profile(lang, out_dir, root)
        test_profile_path.write_text(content, encoding="utf-8")
        created.append(str(test_profile_path.relative_to(root)))

    report = None
    scan_error = None
    try:
        report = scan_project(root)
    except Exception as e:
        scan_error = str(e)

    # Read output_dir from config (may have just been created)
    config = {}
    if fs.file_exists(config_file):
        config = fs.read_json(config_file)
    output_dir = config.get("output_dir", "src")

    result = {
        "message": "kanban env ready",
        "kanban_dir": str(fs.kanban_dir),
        "created": created,
    }

    # Check if output_dir is in .gitignore
    gitignore_path = os.path.join(str(root), ".gitignore")
    if os.path.exists(gitignore_path):
        with open(gitignore_path, encoding="utf-8") as f:
            gitignore_content = f.read()
        for line in gitignore_content.splitlines():
            line = line.strip()
            if line in (f"{output_dir}/", output_dir, f"/{output_dir}/", f"/{output_dir}"):
                result["gitignore_warning"] = (
                    f"output_dir '{output_dir}' is in .gitignore. "
                    f"Use 'git add -f' to add files in that directory."
                )
                break

    if report is not None:
        result["scan"] = _serialize_report(report)
    else:
        result["scan"] = {
            "error": scan_error or "scan failed",
            "recommendations": [],
        }

    return result


def cmd_scan(args: list[str]) -> dict:
    """Explicit scan command for debugging/testing."""
    root = Filesystem.find_project_root()
    report = scan_project(root)
    return _serialize_report(report)


def cmd_create(args: list[str]) -> dict:
    from core.types import AutoMode

    parser = argparse.ArgumentParser(prog="kanban create", add_help=False)
    parser.add_argument("title", nargs="*", default=[], help="Task title")
    parser.add_argument("--desc", nargs="*", default=[], help="Task description")
    parser.add_argument("--auto-mode", nargs="*", default=[], dest="auto_mode",
                        help="Auto-mode flags: all, brainstorm, iteration, lightweight, archive, worktree")
    parser.add_argument("--priority", type=int, default=5, dest="priority",
                        help="Task priority (0-10, default 5)")
    parser.add_argument("--draft", action="store_true", default=False,
                        help="Create as draft placeholder task")

    parsed = parser.parse_args(args)
    title = " ".join(parsed.title) if parsed.title else "Untitled"
    desc = " ".join(parsed.desc) if parsed.desc else ""
    auto_mode_flags = parsed.auto_mode

    # Parse auto_mode flags
    auto_mode = AutoMode()
    if auto_mode_flags:
        if "all" in auto_mode_flags:
            auto_mode = AutoMode(
                auto_brainstorm=True,
                auto_iteration=True,
                auto_lightweight=True,
                auto_archive=True,
                auto_worktree=True,
            )
        else:
            for flag in auto_mode_flags:
                if flag == "brainstorm":
                    auto_mode.auto_brainstorm = True
                elif flag == "iteration":
                    auto_mode.auto_iteration = True
                elif flag == "lightweight":
                    auto_mode.auto_lightweight = True
                elif flag == "archive":
                    auto_mode.auto_archive = True
                elif flag == "worktree":
                    auto_mode.auto_worktree = True

    _, _, tm = _resolve()
    priority = max(0, min(10, parsed.priority))

    # Recommend worktree based on task characteristics
    recommendation = _recommend_worktree(title, desc)

    if parsed.draft:
        task = tm.create(title, desc, draft=True)
        tm.update(task.id, priority=priority)
        return {
            "id": task.id,
            "title": task.title,
            "phase": None,
            "status": "draft",
            "auto_mode": None,
            "recommendation": {
                "use_worktree": False,
                "use_lightweight": True,
                "reason": "draft 任务暂不需要隔离工作区，promote 时重新评估",
            },
            "message": f"Draft task {task.id} created. Add requirements via inbox, then promote when ready.",
        }

    # Non-draft: existing logic
    task = tm.create(title, desc)
    tm.update(task.id, phase="plan", status="in_progress", auto_mode=auto_mode, priority=priority)
    return {
        "id": task.id,
        "title": task.title,
        "phase": "plan",
        "status": "in_progress",
        "auto_mode": {
            "auto_brainstorm": auto_mode.auto_brainstorm,
            "auto_iteration": auto_mode.auto_iteration,
            "auto_lightweight": auto_mode.auto_lightweight,
            "auto_archive": auto_mode.auto_archive,
            "auto_worktree": auto_mode.auto_worktree,
        },
        "recommendation": recommendation,
        "mode_options": {
            "available": ["full", "lightweight", "custom"],
            "recommended": "lightweight" if recommendation["use_lightweight"] else "full",
            "custom_phases": [p.value for p in Scheduler.PHASE_ORDER],
            "custom_evaluate_agents": Scheduler.eval_roles(),
        },
        "message": f"Task {task.id} created. Select mode (full/lightweight/custom) before running.",
    }


def _recommend_worktree(title: str, desc: str) -> dict:
    """Recommend whether to use git worktree based on task characteristics."""
    text = f"{title} {desc}".lower()

    # Heavy indicators → recommend worktree
    heavy_kw = ["游戏", "game", "web", "dashboard", "前端", "后端", "数据库", "database",
                "重构", "refactor", "迁移", "migration", "多模块", "multi-module",
                "完整项目", "full project", "系统", "system"]
    # Light indicators → recommend lightweight
    light_kw = ["脚本", "script", "工具函数", "utility", "单文件", "single file",
                "修复", "fix", "补丁", "patch", "文档", "doc", "配置", "config"]

    heavy_score = sum(1 for kw in heavy_kw if kw in text)
    light_score = sum(1 for kw in light_kw if kw in text)

    if heavy_score > light_score:
        return {
            "use_worktree": True,
            "use_lightweight": False,
            "reason": f"检测到复杂任务特征（{'/'.join(kw for kw in heavy_kw if kw in text)[:60]}），建议使用 git worktree 隔离开发环境",
        }
    elif light_score > heavy_score:
        return {
            "use_worktree": False,
            "use_lightweight": True,
            "reason": f"检测到简单任务特征（{'/'.join(kw for kw in light_kw if kw in text)[:60]}），轻量模式即可，无需 worktree",
        }
    return {
        "use_worktree": False,
        "use_lightweight": False,
        "reason": "无法自动判断复杂度，建议手动选择是否使用 worktree",
    }


def cmd_status(args: list[str]) -> dict:
    _, _, tm = _resolve()
    return tm.status()


def cmd_show(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    _, _, tm = _resolve()
    task = tm.show(args[0])
    return {
        "id": task.id, "title": task.title,
        "description": task.description,
        "status": task.status.value, "phase": task.phase.value,
        "iteration": task.iteration, "priority": task.priority,
    }


def cmd_clean(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id or --all required"}
    fs, _, tm = _resolve()

    if "--all" in args:
        cleaned = []
        for f in sorted(fs.kanban_dir.glob("archive/TASK-*.json")):
            task_id = f.stem
            f.unlink()
            cleaned.append(task_id)
        return {"cleaned": cleaned, "count": len(cleaned)}

    task_id = args[0]
    tm.delete(task_id)
    return {"message": f"cleaned {task_id}"}


def cmd_promote(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    _, _, tm = _resolve()
    task_id = args[0]
    task = tm.show(task_id)
    if task.status.value != "draft":
        return {"error": f"Task {task_id} is not in draft status"}

    # Read analysis for suggested phase
    import json
    task_dir = tm._fs.task_dir(task_id)
    analysis_path = task_dir / "inbox_analysis.json"
    suggested_phase = "plan"
    if analysis_path.is_file():
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        suggested_phase = analysis.get("suggested_phase", "plan")

    tm.update(task_id, status="pending", phase=suggested_phase)
    tm.update(task_id, status="in_progress")
    return {
        "task_id": task_id,
        "promoted": True,
        "phase": suggested_phase,
        "message": f"Task {task_id} promoted from draft to {suggested_phase} phase",
    }
