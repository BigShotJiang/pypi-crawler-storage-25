"""
Configuration and result dataclasses for the profiling phase — Phase 1 redesign.

ProfileConfig controls the structural profiler's behaviour.
Stats dataclasses hold per-column and dataset-level profiling results.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Optional, Union

from ..config import SemanticType, Modality
from ._missingness_config import (
    ColumnMissingnessProfile,
)
from ._correlation_config import (
    CorrelationProfileResult,
)
from ._categorical_config import (
    CategoricalStats,
)
from ._numeric_config import (
    NumericStats,
)
from ._datetime_config import (
    DatetimeStats,
)
from ._boolean_config import BooleanStats
from ._text_config import TextStats
from ._target_config import TargetProfileResult

# ---------------------------------------------------------------------------
# Type-detection enums — kept for TypeDetector compatibility
# ---------------------------------------------------------------------------


class NumericKind(StrEnum):
    Continuous = "continuous"
    Discrete = "discrete"


class TypeFlag(StrEnum):
    NumericCoerced = "numeric_coerced"
    DatetimeCoerced = "datetime_coerced"
    BooleanCandidate = "boolean_candidate"
    EncodedCategory = "encoded_category"
    IdentifierColumn = "identifier_column"
    SequentialIndex = "sequential_index"
    FloatSequentialIndex = "float_sequential_index"
    FreeTextCandidate = "free_text_candidate"
    UserOverride = "user_override"


# ---------------------------------------------------------------------------
# Column and dataset result containers
# ---------------------------------------------------------------------------

AnyStats = Union[NumericStats, CategoricalStats, DatetimeStats, BooleanStats, TextStats]


@dataclass
class ColumnProfile:
    name: str = ""
    semantic_type: Optional[SemanticType] = None
    type_flags: list[TypeFlag] = field(default_factory=list)
    original_dtype: str = ""
    inferred_dtype: str = ""
    missingness: Optional[ColumnMissingnessProfile] = None
    is_target: bool = False
    stats: Optional[AnyStats] = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "semantic_type": str(self.semantic_type) if self.semantic_type else None,
            "type_flags": [str(f) for f in self.type_flags],
            "original_dtype": self.original_dtype,
            "inferred_dtype": self.inferred_dtype,
            "missingness": self.missingness.to_dict() if self.missingness else None,
            "is_target": self.is_target,
            "stats": self.stats.to_dict() if self.stats else None,
        }


@dataclass
class RowMissingnessDistribution:
    """
    Dataset-level summary of per-row missing-value counts.
    Computed by StructuralProfiler over the full active column set.
    """

    pct_zero_missing: float = 0.0
    pct_one_to_two: float = 0.0
    pct_three_to_five: float = 0.0
    pct_over_five: float = 0.0
    pct_over_half_missing: float = 0.0
    drop_candidate_row_count: int = 0

    def to_dict(self) -> dict:
        return {
            "pct_zero_missing": self.pct_zero_missing,
            "pct_one_to_two": self.pct_one_to_two,
            "pct_three_to_five": self.pct_three_to_five,
            "pct_over_five": self.pct_over_five,
            "pct_over_half_missing": self.pct_over_half_missing,
            "drop_candidate_row_count": self.drop_candidate_row_count,
        }


@dataclass
class MemoryBreakdown:
    column_bytes: dict[str, int] = field(default_factory=dict)

    @property
    def sorted_by_usage(self) -> list[tuple[str, int]]:
        return sorted(self.column_bytes.items(), key=lambda x: x[1], reverse=True)

    def top_consumers(self, n: int = 10) -> list[tuple[str, int]]:
        return self.sorted_by_usage[:n]

    def to_dict(self) -> dict:
        return {"column_bytes": dict(self.column_bytes)}


@dataclass
class DatasetStats:
    modality: Modality = Modality.Tabular
    row_count: int = 0
    column_count: int = 0
    memory_bytes: int = 0
    memory_breakdown: Optional[MemoryBreakdown] = None
    duplicate_count: int = 0
    duplicate_ratio: float = 0.0
    overall_sparsity: float = 0.0
    was_chunked: bool = False
    missingness_matrix: Optional[dict[str, dict[str, float]]] = None
    row_distribution: RowMissingnessDistribution = field(
        default_factory=RowMissingnessDistribution
    )

    feature_correlation: Optional[CorrelationProfileResult] = None

    target_correlations: dict[str, CorrelationProfileResult] = field(
        default_factory=dict,
    )

    def to_dict(self) -> dict:
        return {
            "modality": str(self.modality),
            "row_count": self.row_count,
            "column_count": self.column_count,
            "memory_bytes": self.memory_bytes,
            "memory_breakdown": self.memory_breakdown.to_dict() if self.memory_breakdown else None,
            "duplicate_count": self.duplicate_count,
            "duplicate_ratio": self.duplicate_ratio,
            "overall_sparsity": self.overall_sparsity,
            "was_chunked": self.was_chunked,
            "missingness_matrix": self.missingness_matrix,
            "row_distribution": self.row_distribution.to_dict(),
            "feature_correlation": self.feature_correlation.to_dict() if self.feature_correlation else None,
            "target_correlations": {k: v.to_dict() for k, v in self.target_correlations.items()},
        }


@dataclass
class StructuralProfileResult:
    columns: dict[str, ColumnProfile] = field(default_factory=dict)
    dataset: DatasetStats = field(default_factory=DatasetStats)
    targets: dict[str, TargetProfileResult] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "columns": {k: v.to_dict() for k, v in self.columns.items()},
            "dataset": self.dataset.to_dict(),
            "targets": {k: v.to_dict() for k, v in self.targets.items()},
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


# ---------------------------------------------------------------------------
# ProfileConfig — clean break from per-profiler column lists
# ---------------------------------------------------------------------------


@dataclass
class ProfileConfig:
    """
    Controls the structural profiler's behaviour.

    Parameters
    ----------
    modality : Modality
        Data modality. Currently only Tabular is implemented.
    target_column : Optional[str]
        Name of the label/target column, if any.
    compute_correlation : bool
        Whether to compute the feature-feature correlation matrix.
    correlation_target_column : Optional[str]
        Column used for feature-target correlation metrics.
    memory_threshold_mb : float
        Memory (MB) above which chunked processing activates.
    chunk_size : int
        Rows per chunk when chunked processing is active.
    """

    modality: Modality = Modality.Tabular
    target_columns: list[str] = field(default_factory=list)
    compute_correlation: bool = False
    correlation_target_column: Optional[str] = None
    memory_threshold_mb: float = 500.0
    chunk_size: int = 100_000


    def to_dict(self) -> dict:
        return {
            "modality": str(self.modality),
            "target_columns": list(self.target_columns),
            "compute_correlation": self.compute_correlation,
            "correlation_target_column": self.correlation_target_column,
            "memory_threshold_mb": self.memory_threshold_mb,
            "chunk_size": self.chunk_size,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ProfileConfig:
        return cls(
            modality=Modality(data.get("modality", Modality.Tabular)),
            target_columns=list(data.get("target_columns", [])),
            compute_correlation=bool(data.get("compute_correlation", False)),
            correlation_target_column=data.get("correlation_target_column"),
            memory_threshold_mb=float(data.get("memory_threshold_mb", 500.0)),
            chunk_size=int(data.get("chunk_size", 100_000)),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> ProfileConfig:
        return cls.from_dict(json.loads(json_str))


@dataclass
class ColumnTypeInfo:
    column: str
    original_dtype: str
    inferred_dtype: str
    numeric_kind: Optional[NumericKind] = None
    flags: list[TypeFlag] = field(default_factory=list)
    semantic_type: Optional[SemanticType] = None

    def has_flag(self, flag: TypeFlag) -> bool:
        return flag in self.flags
