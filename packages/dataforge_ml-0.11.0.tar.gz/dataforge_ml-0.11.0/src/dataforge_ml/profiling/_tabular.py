"""
TabularProfiler  –  Phase 1: Structural Profiling for tabular datasets.

All DataFrame operations use Polars (no pandas dependency).

A pipeline-agnostic data-catalog tool: receives the full raw DataFrame and
computes dataset-level stats over every column — no exclusion logic, no
config dependency.

Computes:
  • row / column count                (full dataset)
  • memory usage + per-column breakdown when threshold exceeded
  • duplicate row count & ratio       (all columns)
  • overall sparsity                  (all columns)

Chunked processing is activated automatically when the DataFrame's
estimated memory exceeds _MEMORY_THRESHOLD_MB.
"""

from __future__ import annotations

import math

import polars as pl

from ._base import ModalityProfiler
from .config import (
    MemoryBreakdown,
    DatasetStats,
)

# ---------------------------------------------------------------------------
# Module-level constants (previously sourced from ProfileConfig)
# ---------------------------------------------------------------------------

_MEMORY_THRESHOLD_MB: float = 500.0
_CHUNK_SIZE: int = 100_000


class TabularProfiler(ModalityProfiler):
    """
    Structural profiler for Polars DataFrames.

    Pipeline-agnostic: accepts no constructor arguments and applies no column
    filtering. Computes dataset-level stats (row count, column count, memory,
    duplicate ratio, overall sparsity) over the complete DataFrame it receives.

    Usage
    -----
    >>> profiler = TabularProfiler()
    >>> result = profiler.profile(df)
    >>> print(result)
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def profile(self, data: pl.DataFrame, **kwargs) -> DatasetStats:
        return self._run(data)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _run(self, df: pl.DataFrame) -> DatasetStats:
        result = DatasetStats()

        # 1. Shape — always computed on the full frame
        result.row_count = df.height
        result.column_count = df.width

        # 2. Memory
        self._analyse_memory(df, result)

        # Decide processing mode AFTER memory analysis
        use_chunks = (result.memory_breakdown is not None) and result.row_count > 0
        result.was_chunked = use_chunks

        if result.row_count == 0:
            return result

        # 3. Operate on all columns — no exclusion logic
        all_cols: list[str] = df.columns

        if use_chunks:
            self._chunked_metrics(df, all_cols, all_cols, result)
        else:
            self._full_metrics(df, all_cols, all_cols, result)

        return result

    @staticmethod
    def _build_missingness_exprs(df: pl.DataFrame, cols: list[str]) -> list[pl.Expr]:
        exprs = []
        for col_name in cols:
            dtype = df[col_name].dtype
            std_expr = pl.col(col_name).is_null()

            if dtype in (pl.Utf8, pl.String):
                eff_expr = (
                    std_expr
                    | (pl.col(col_name).str.strip_chars() == "")
                    | pl.col(col_name)
                    .str.to_uppercase()
                    .is_in(["NA", "NAN", "NULL", "NONE", "?"])
                )
            elif dtype in (pl.Float32, pl.Float64):
                eff_expr = (
                    std_expr
                    | pl.col(col_name).is_nan()
                    | pl.col(col_name).is_infinite()
                )
            else:
                eff_expr = std_expr

            exprs.append(std_expr.sum().alias(f"{col_name}_std"))
            exprs.append(eff_expr.sum().alias(f"{col_name}_eff"))

        return exprs

    # ------------------------------------------------------------------
    # Memory analysis
    # ------------------------------------------------------------------

    def _analyse_memory(self, df: pl.DataFrame, result: DatasetStats) -> None:
        """
        Populate memory fields on *result*.

        Polars exposes estimated_size() per Series for heap allocation.
        """
        col_bytes: dict[str, int] = {
            col: df[col].estimated_size() for col in df.columns
        }
        total_bytes = sum(col_bytes.values())

        result.memory_bytes = total_bytes
        threshold_bytes = _MEMORY_THRESHOLD_MB * 1024 * 1024

        if total_bytes > threshold_bytes:
            result.memory_breakdown = MemoryBreakdown(column_bytes=col_bytes)

    # ------------------------------------------------------------------
    # Full-frame metrics
    # ------------------------------------------------------------------

    def _full_metrics(
        self,
        df: pl.DataFrame,
        dup_cols: list[str],
        missing_cols: list[str],
        result: DatasetStats,
    ) -> None:
        result.duplicate_count = self._count_duplicates(df, dup_cols)
        result.duplicate_ratio = (
            result.duplicate_count / result.row_count if result.row_count else 0.0
        )

        if missing_cols:
            exprs = self._build_missingness_exprs(df, missing_cols)
            row = df.select(exprs).row(0)

            total_eff_cells = 0
            for i, _ in enumerate(missing_cols):
                eff_nulls = row[i * 2 + 1]
                total_eff_cells += eff_nulls

            total_cells = result.row_count * len(missing_cols)
            result.overall_sparsity = (
                total_eff_cells / total_cells if total_cells else 0.0
            )

    # ------------------------------------------------------------------
    # Chunked metrics
    # ------------------------------------------------------------------

    def _chunked_metrics(
        self,
        df: pl.DataFrame,
        dup_cols: list[str],
        sparsity_cols: list[str],
        result: DatasetStats,
    ) -> None:
        """
        Stream through the DataFrame in row-chunks to keep peak memory low.

        Duplicate detection: hash the dup_cols subset row-by-row and track
        seen hashes — semantics match keep='first'.
        Sparsity is accumulated as (missing_cells, total_cells).
        """
        chunk_size = _CHUNK_SIZE
        n_chunks = math.ceil(result.row_count / chunk_size)

        seen_hashes: set[int] = set()
        dup_count = 0
        missing_cells = 0
        total_cells = 0

        for i in range(n_chunks):
            start = i * chunk_size
            end = min(start + chunk_size, result.row_count)
            chunk: pl.DataFrame = df.slice(start, end - start)

            if dup_cols:
            # --- duplicates ---
                sub = chunk.select(dup_cols) if dup_cols else chunk
                for row_tuple in sub.iter_rows():
                    h = hash(row_tuple)
                    if h in seen_hashes:
                        dup_count += 1
                    else:
                        seen_hashes.add(h)

            if sparsity_cols:
            # --- sparsity ---
                exprs = self._build_missingness_exprs(chunk, sparsity_cols)
                row = chunk.select(exprs).row(0)
                for j in range(len(sparsity_cols)):
                    missing_cells += row[j * 2 + 1]
                total_cells += chunk.height * len(sparsity_cols)

        result.duplicate_count = dup_count
        result.duplicate_ratio = (
            dup_count / result.row_count if result.row_count else 0.0
        )
        result.overall_sparsity = missing_cells / total_cells if total_cells else 0.0

    # ------------------------------------------------------------------
    # Type detection
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Stateless helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _count_duplicates(df: pl.DataFrame, cols: list[str]) -> int:
        """
        Count rows that are duplicates (keeping first occurrence).

        Equivalent to pandas duplicated(subset=cols, keep='first').sum().
        """
        sub = df.select(cols) if cols else df
        # is_duplicated() marks ALL occurrences of a duplicate group.
        # We want only the non-first occurrences, so we subtract the
        # number of unique rows.
        n_unique = sub.unique().height
        return df.height - n_unique
