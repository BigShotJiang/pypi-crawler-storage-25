#!/usr/bin/env bash

set -euo pipefail

cd "$(dirname "$0")"

usage() {
  cat <<'EOF'
Usage: ./build.sh [--patch|--minor|--major]

Version bump:
  --patch   Increment patch version (default)
  --minor   Increment minor version and reset patch to 0
  --major   Increment major version and reset minor and patch to 0
EOF
}

bump="patch"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --patch)
      bump="patch"
      ;;
    --minor)
      bump="minor"
      ;;
    --major)
      bump="major"
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      usage >&2
      exit 2
      ;;
  esac
  shift
done

python3 - "$bump" <<'PY'
import re
import sys
from pathlib import Path

bump = sys.argv[1]
path = Path("pyproject.toml")
text = path.read_text()
match = re.search(r'(?m)^version = "((\d+)\.(\d+)\.(\d+))"$', text)
if not match:
    raise SystemExit("Could not find simple MAJOR.MINOR.PATCH version in pyproject.toml")

major, minor, patch = map(int, match.groups()[1:])
if bump == "major":
    major += 1
    minor = 0
    patch = 0
elif bump == "minor":
    minor += 1
    patch = 0
else:
    patch += 1

new_version = f'{major}.{minor}.{patch}'
path.write_text(
    text[: match.start(1)] + new_version + text[match.end(1) :]
)
print(f"Bumped version to {new_version}")
PY

if [[ -f .env ]]; then
  set -a
  . .env
  set +a
fi

: "${PYPI_TOKEN:?PYPI_TOKEN not set - export it or put it in mcp/.env}"

rm -rf dist
uv build
uv publish --username __token__ --password "$PYPI_TOKEN"
