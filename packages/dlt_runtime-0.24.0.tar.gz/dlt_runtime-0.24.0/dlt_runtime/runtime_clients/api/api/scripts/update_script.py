from http import HTTPStatus
from typing import Any, Optional, Union
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response_400 import ErrorResponse400
from ...models.error_response_401 import ErrorResponse401
from ...models.error_response_403 import ErrorResponse403
from ...models.error_response_404 import ErrorResponse404
from ...models.script_response import ScriptResponse
from ...models.update_script_request import UpdateScriptRequest
from ...types import Response


def _get_kwargs(
    workspace_id: UUID,
    script_id_or_name: str,
    *,
    body: UpdateScriptRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/workspaces/{workspace_id}/scripts/{script_id_or_name}".format(
            workspace_id=workspace_id,
            script_id_or_name=script_id_or_name,
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[
    Union[
        ErrorResponse400,
        ErrorResponse401,
        ErrorResponse403,
        ErrorResponse404,
        ScriptResponse,
    ]
]:
    if response.status_code == 200:
        response_200 = ScriptResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse401.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorResponse403.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorResponse404.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[
    Union[
        ErrorResponse400,
        ErrorResponse401,
        ErrorResponse403,
        ErrorResponse404,
        ScriptResponse,
    ]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace_id: UUID,
    script_id_or_name: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateScriptRequest,
) -> Response[
    Union[
        ErrorResponse400,
        ErrorResponse401,
        ErrorResponse403,
        ErrorResponse404,
        ScriptResponse,
    ]
]:
    """UpdateScript


    Partially updates a script. Only provided fields will be updated.
    Fields not included in the request body will retain their current values.
    Fields explicitly set to null will be set to null (e.g., schedule: null removes the schedule).
    Creates a new script version when any field is updated.

    Requires WRITE permission on the organization level.

    Args:
        workspace_id (UUID):
        script_id_or_name (str):
        body (UpdateScriptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse400, ErrorResponse401, ErrorResponse403, ErrorResponse404, ScriptResponse]]
    """

    kwargs = _get_kwargs(
        workspace_id=workspace_id,
        script_id_or_name=script_id_or_name,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace_id: UUID,
    script_id_or_name: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateScriptRequest,
) -> Optional[
    Union[
        ErrorResponse400,
        ErrorResponse401,
        ErrorResponse403,
        ErrorResponse404,
        ScriptResponse,
    ]
]:
    """UpdateScript


    Partially updates a script. Only provided fields will be updated.
    Fields not included in the request body will retain their current values.
    Fields explicitly set to null will be set to null (e.g., schedule: null removes the schedule).
    Creates a new script version when any field is updated.

    Requires WRITE permission on the organization level.

    Args:
        workspace_id (UUID):
        script_id_or_name (str):
        body (UpdateScriptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse400, ErrorResponse401, ErrorResponse403, ErrorResponse404, ScriptResponse]
    """

    return sync_detailed(
        workspace_id=workspace_id,
        script_id_or_name=script_id_or_name,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace_id: UUID,
    script_id_or_name: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateScriptRequest,
) -> Response[
    Union[
        ErrorResponse400,
        ErrorResponse401,
        ErrorResponse403,
        ErrorResponse404,
        ScriptResponse,
    ]
]:
    """UpdateScript


    Partially updates a script. Only provided fields will be updated.
    Fields not included in the request body will retain their current values.
    Fields explicitly set to null will be set to null (e.g., schedule: null removes the schedule).
    Creates a new script version when any field is updated.

    Requires WRITE permission on the organization level.

    Args:
        workspace_id (UUID):
        script_id_or_name (str):
        body (UpdateScriptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse400, ErrorResponse401, ErrorResponse403, ErrorResponse404, ScriptResponse]]
    """

    kwargs = _get_kwargs(
        workspace_id=workspace_id,
        script_id_or_name=script_id_or_name,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace_id: UUID,
    script_id_or_name: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateScriptRequest,
) -> Optional[
    Union[
        ErrorResponse400,
        ErrorResponse401,
        ErrorResponse403,
        ErrorResponse404,
        ScriptResponse,
    ]
]:
    """UpdateScript


    Partially updates a script. Only provided fields will be updated.
    Fields not included in the request body will retain their current values.
    Fields explicitly set to null will be set to null (e.g., schedule: null removes the schedule).
    Creates a new script version when any field is updated.

    Requires WRITE permission on the organization level.

    Args:
        workspace_id (UUID):
        script_id_or_name (str):
        body (UpdateScriptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse400, ErrorResponse401, ErrorResponse403, ErrorResponse404, ScriptResponse]
    """

    return (
        await asyncio_detailed(
            workspace_id=workspace_id,
            script_id_or_name=script_id_or_name,
            client=client,
            body=body,
        )
    ).parsed
