from catchlib.core.Catcher import Catcher
from catchlib.tests import tests
