"""Lattice sub-client — workflow DAGs, graph traversal, and cross-workflow edges."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from sbn._http import HttpTransport

PREFIX = "/internal/lattice"

# ---------------------------------------------------------------------------
# Field normalization — accept common aliases from pgdag / sonic-pay
# ---------------------------------------------------------------------------

# Canonical top-level fields accepted by the backend NodeSchema / EdgeSchema
_NODE_FIELDS = {
    "step_id",
    "name",
    "skill",
    "dept",
    "description",
    "estimated_seconds",
    "step_type",
    "metadata",
    "meta",
}
_EDGE_FIELDS = {"source_id", "target_id", "edge_type", "weight", "meta"}

# Short-form aliases used by pgdag and consumer DAG definitions
_NODE_ALIASES: dict[str, str] = {"id": "step_id", "label": "name"}
_EDGE_ALIASES: dict[str, str] = {"source": "source_id", "target": "target_id", "type": "edge_type"}


def _normalize_node(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Map common node aliases to canonical field names.

    Unknown fields are folded into the legacy ``meta`` sub-dict so they
    survive the round-trip without breaking older backends.
    """
    node: dict[str, Any] = {}
    extras: dict[str, Any] = {}
    for k, v in raw.items():
        canonical = _NODE_ALIASES.get(k, k)
        if canonical in _NODE_FIELDS:
            node[canonical] = v
        else:
            extras[k] = v
    if extras:
        merged = dict(node.get("meta") or {})
        merged.update(extras)
        node["meta"] = merged
    return node


def _normalize_edge(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Map common edge aliases to canonical field names."""
    edge: dict[str, Any] = {}
    extras: dict[str, Any] = {}
    for k, v in raw.items():
        canonical = _EDGE_ALIASES.get(k, k)
        if canonical in _EDGE_FIELDS:
            edge[canonical] = v
        else:
            extras[k] = v
    if extras:
        merged = dict(edge.get("meta") or {})
        merged.update(extras)
        edge["meta"] = merged
    return edge


def _to_pgdag_template(
    data: Mapping[str, Any],
    *,
    workflow_id: str | None = None,
):
    """Convert a Lattice workflow payload or export envelope into a pgDAG template."""
    from pgdag import DAGEdge, DAGNode, DAGTemplate

    workflow_payload = data.get("workflow", data)
    if not isinstance(workflow_payload, Mapping):
        raise ValueError("Expected workflow payload to be a mapping")

    provenance = data.get("provenance")
    meta = dict(workflow_payload.get("meta") or {})
    resolved_workflow_id = (
        workflow_id
        or workflow_payload.get("id")
        or data.get("id")
        or (
            provenance.get("source_id")
            if isinstance(provenance, Mapping)
            else None
        )
    )
    if resolved_workflow_id and not meta.get("workflow_id"):
        meta["workflow_id"] = str(resolved_workflow_id)

    if isinstance(provenance, Mapping):
        lattice_meta = dict(meta.get("lattice") or {})
        if provenance.get("source_id") and not lattice_meta.get("workflow_id"):
            lattice_meta["workflow_id"] = str(provenance["source_id"])
        if provenance.get("source_project_id") and not lattice_meta.get("project_id"):
            lattice_meta["project_id"] = str(provenance["source_project_id"])
        if provenance.get("snapchore_hash") and not lattice_meta.get("snapchore_hash"):
            lattice_meta["snapchore_hash"] = str(provenance["snapchore_hash"])
        if provenance.get("state") and not lattice_meta.get("state"):
            lattice_meta["state"] = str(provenance["state"])
        if lattice_meta:
            meta["lattice"] = lattice_meta

    nodes = []
    for raw_node in workflow_payload.get("nodes", []) or []:
        node = _normalize_node(raw_node)
        node_meta = dict(node.get("metadata") or node.get("meta") or {})
        nodes.append(
            DAGNode(
                id=str(node.get("step_id") or ""),
                label=str(node.get("name") or node.get("step_id") or ""),
                step_type=str(node.get("step_type") or node_meta.get("step_type") or ""),
                metadata=node_meta,
            )
        )

    edges = []
    for raw_edge in workflow_payload.get("edges", []) or []:
        edge = _normalize_edge(raw_edge)
        edge_meta = dict(edge.get("meta") or {})
        edges.append(
            DAGEdge(
                source=str(edge.get("source_id") or ""),
                target=str(edge.get("target_id") or ""),
                edge_type=str(edge.get("edge_type") or edge_meta.get("type") or "sequence"),
            )
        )

    return DAGTemplate(
        name=str(workflow_payload.get("name") or ""),
        version=str(workflow_payload.get("version") or "1.0"),
        nodes=nodes,
        edges=edges,
        domain=str(workflow_payload.get("domain") or "general"),
        metadata=meta,
    )


class LatticeClient:
    """Workflow DAG registration, step orchestration, and graph queries."""

    def __init__(self, transport: HttpTransport) -> None:
        self._t = transport

    # ── Workflows ──────────────────────────────────────────────────────

    def create_workflow(
        self,
        *,
        domain: str,
        name: str,
        nodes: Sequence[Mapping[str, Any]],
        edges: Sequence[Mapping[str, Any]] | None = None,
        topology: str = "series",
        gec_frontier: Mapping[str, Any] | None = None,
        meta: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "domain": domain,
            "name": name,
            "nodes": [_normalize_node(n) for n in nodes],
            "edges": [_normalize_edge(e) for e in edges] if edges else [],
            "topology": topology,
        }
        if gec_frontier:
            body["gec_frontier"] = dict(gec_frontier)
        if meta:
            body["meta"] = dict(meta)
        return self._t.post(f"{PREFIX}/workflows", json=body).json()

    def list_workflows(
        self,
        *,
        domain: str | None = None,
        state: str | None = None,
        scopes: Sequence[str] | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List workflows with optional scope filtering.

        Parameters
        ----------
        scopes:
            Glob-style patterns like ``["finance.*", "treasury.*"]``.
        """
        params: dict[str, Any] = {"limit": limit}
        if domain:
            params["domain"] = domain
        if state:
            params["state"] = state
        if scopes:
            params["scopes"] = ",".join(scopes)
        data = self._t.get(f"{PREFIX}/workflows", params=params).json()
        return data.get("workflows", [])

    def discover_workflows(
        self,
        scopes: Sequence[str],
        *,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Discover active workflows from other projects matching scope patterns.

        Returns sanitized metadata (no full node/edge details).
        """
        params: dict[str, Any] = {
            "scopes": ",".join(scopes),
            "limit": limit,
        }
        data = self._t.get(f"{PREFIX}/workflows/discover", params=params).json()
        return data.get("workflows", [])

    def get_workflow(
        self,
        workflow_id: str,
        *,
        include_runtime: bool = True,
    ) -> dict[str, Any]:
        params = {"include_runtime": "true" if include_runtime else "false"}
        return self._t.get(f"{PREFIX}/workflows/{workflow_id}", params=params).json()

    def list_workflow_runs(
        self,
        workflow_id: str,
        *,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """List recent grouped run ledgers for a workflow."""
        data = self._t.get(
            f"{PREFIX}/workflows/{workflow_id}/runs",
            params={"limit": limit},
        ).json()
        return data.get("runs", [])

    def get_workflow_run_evidence_packet(
        self,
        workflow_id: str,
        run_id: str,
    ) -> dict[str, Any]:
        """Fetch a server-signed evidence packet for a workflow run."""
        return self._t.get(
            f"{PREFIX}/workflows/{workflow_id}/runs/{run_id}/evidence-packet",
        ).json()

    def verify_evidence_packet(
        self,
        data: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Verify a signed evidence packet envelope."""
        return self._t.post(
            f"{PREFIX}/evidence-packets/verify",
            json={"data": dict(data)},
        ).json()

    def build_pgdag_template(self, workflow_id: str):
        """Fetch a workflow and return it as a pgDAG template with workflow identity embedded."""
        data = self.get_workflow(workflow_id, include_runtime=False)
        return _to_pgdag_template(data, workflow_id=workflow_id)

    def activate_workflow(self, workflow_id: str) -> dict[str, Any]:
        return self._t.post(f"{PREFIX}/workflows/{workflow_id}/activate", json={}).json()

    def clone_workflow(
        self,
        workflow_id: str,
        target_project_id: str,
    ) -> dict[str, Any]:
        return self._t.post(
            f"{PREFIX}/workflows/{workflow_id}/clone",
            json={"target_project_id": target_project_id},
        ).json()

    # ── Export / Import ─────────────────────────────────────────────────

    def export_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Export a workflow to a portable JSON dict."""
        return self._t.get(f"{PREFIX}/workflows/{workflow_id}/export").json()

    def build_pgdag_template_from_export(self, data: Mapping[str, Any]):
        """Convert an exported Lattice workflow envelope into a pgDAG template."""
        return _to_pgdag_template(data)

    def export_workflows(
        self,
        *,
        workflow_ids: Sequence[str] | None = None,
        domain: str | None = None,
    ) -> dict[str, Any]:
        """Export multiple workflows as a portable bundle."""
        body: dict[str, Any] = {}
        if workflow_ids:
            body["workflow_ids"] = list(workflow_ids)
        if domain:
            body["domain"] = domain
        return self._t.post(f"{PREFIX}/workflows/export", json=body).json()

    def import_workflow(
        self,
        data: Mapping[str, Any],
        *,
        activate: bool = False,
    ) -> dict[str, Any]:
        """Import a workflow from a portable export dict."""
        payload = dict(data)
        # Normalise nodes/edges inside the workflow envelope if present
        wf = payload.get("workflow", payload)
        if "nodes" in wf:
            wf["nodes"] = [_normalize_node(n) for n in wf["nodes"]]
        if "edges" in wf:
            wf["edges"] = [_normalize_edge(e) for e in wf["edges"]]
        return self._t.post(
            f"{PREFIX}/workflows/import",
            json={"data": payload, "activate": activate},
        ).json()

    def import_workflows(
        self,
        data: Mapping[str, Any],
        *,
        activate: bool = False,
    ) -> dict[str, Any]:
        """Import a bundle of workflows from a bulk export."""
        payload = dict(data)
        for wf_entry in payload.get("workflows", []):
            wf = wf_entry.get("workflow", wf_entry)
            if "nodes" in wf:
                wf["nodes"] = [_normalize_node(n) for n in wf["nodes"]]
            if "edges" in wf:
                wf["edges"] = [_normalize_edge(e) for e in wf["edges"]]
        return self._t.post(
            f"{PREFIX}/workflows/import-bulk",
            json={"data": payload, "activate": activate},
        ).json()

    # ── Graph traversal ────────────────────────────────────────────────

    def get_execution_order(self, workflow_id: str) -> dict[str, Any]:
        """Get topological execution order and ready steps."""
        return self._t.get(f"{PREFIX}/workflows/{workflow_id}/order").json()

    def get_ready_steps(
        self,
        workflow_id: str,
        completed: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Get steps ready for execution given completed set."""
        params: dict[str, str] = {}
        if completed:
            params["completed"] = ",".join(completed)
        data = self._t.get(
            f"{PREFIX}/workflows/{workflow_id}/ready-steps", params=params
        ).json()
        return data.get("data", {}).get("ready_steps", data.get("ready_steps", []))

    # ── Cross-workflow edges ───────────────────────────────────────────

    def create_edge(
        self,
        *,
        source_id: str,
        target_id: str,
        edge_type: str,
        weight: float = 1.0,
        meta: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "source_id": source_id,
            "target_id": target_id,
            "edge_type": edge_type,
            "weight": weight,
        }
        if meta:
            body["meta"] = dict(meta)
        return self._t.post(f"{PREFIX}/edges", json=body).json()

    def list_edges(
        self,
        *,
        source_id: str | None = None,
        target_id: str | None = None,
        edge_type: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if source_id:
            params["source_id"] = source_id
        if target_id:
            params["target_id"] = target_id
        if edge_type:
            params["edge_type"] = edge_type
        data = self._t.get(f"{PREFIX}/edges", params=params).json()
        return data.get("edges", [])

    # ── Step outcomes & analytics ──────────────────────────────────────

    def record_step_outcome(
        self,
        workflow_id: str,
        step_id: str,
        *,
        agent_id: str | None = None,
        outcome: str = "completed",
        duration_seconds: float | None = None,
        error_message: str | None = None,
        proof_hash: str | None = None,
        proof_stage: str | None = None,
        block_ref: str | None = None,
        signal_hash: str | None = None,
        anchor_hash: str | None = None,
        anchor_type: str | None = None,
        receipt_id: str | None = None,
        degraded: bool | None = None,
        meta: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Record step execution outcome."""
        body: dict[str, Any] = {"outcome": outcome}
        if agent_id:
            body["agent_id"] = agent_id
        if duration_seconds is not None:
            body["duration_seconds"] = duration_seconds
        if error_message:
            body["error_message"] = error_message
        if proof_hash:
            body["proof_hash"] = proof_hash
        if proof_stage:
            body["proof_stage"] = proof_stage
        if block_ref:
            body["block_ref"] = block_ref
        if signal_hash:
            body["signal_hash"] = signal_hash
        if anchor_hash:
            body["anchor_hash"] = anchor_hash
        if anchor_type:
            body["anchor_type"] = anchor_type
        if receipt_id:
            body["receipt_id"] = receipt_id
        if degraded is not None:
            body["degraded"] = degraded
        if meta:
            body["meta"] = dict(meta)
        return self._t.post(
            f"{PREFIX}/workflows/{workflow_id}/steps/{step_id}/outcome",
            json=body,
        ).json()

    def mark_workflow_complete(self, workflow_id: str) -> dict[str, Any]:
        """Mark workflow run as complete."""
        return self._t.post(
            f"{PREFIX}/workflows/{workflow_id}/complete", json={},
        ).json()

    def get_workflow_analytics(self, workflow_id: str) -> dict[str, Any]:
        """Get aggregated analytics for workflow execution."""
        return self._t.get(f"{PREFIX}/workflows/{workflow_id}/analytics").json()

    def get_workflow_benchmarks(self, workflow_id: str) -> dict[str, Any]:
        """Get cross-project benchmark data for workflow execution."""
        return self._t.get(f"{PREFIX}/workflows/{workflow_id}/benchmarks").json()
