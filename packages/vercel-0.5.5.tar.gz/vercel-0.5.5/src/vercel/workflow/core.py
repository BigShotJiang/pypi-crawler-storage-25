import datetime
from collections.abc import Callable, Coroutine
from typing import Any, Generic, ParamSpec, TypeVar

P = ParamSpec("P")
T = TypeVar("T")
_workflows: dict[str, "Workflow[Any, Any]"] = {}
_steps: dict[str, "Step[Any, Any]"] = {}


class Workflow(Generic[P, T]):
    def __init__(self, func: Callable[P, Coroutine[Any, Any, T]]):
        self.func = func
        module = getattr(func, "__module__", "<unknown module>")
        self.workflow_id = f"workflow//{module}//{func.__qualname__}"
        assert self.workflow_id not in _workflows, f"Duplicate workflow ID: {self.workflow_id}"
        _workflows[self.workflow_id] = self


def workflow(func: Callable[P, Coroutine[Any, Any, T]]) -> Workflow[P, T]:
    return Workflow(func)


def get_workflow(workflow_id: str) -> Workflow[Any, Any]:
    return _workflows[workflow_id]


class Step(Generic[P, T]):
    max_retries: int = 3

    def __init__(self, func: Callable[P, Coroutine[Any, Any, T]]):
        self.func = func
        module = getattr(func, "__module__", "<unknown module>")
        self.name = f"step//{module}//{func.__qualname__}"
        assert self.name not in _steps, f"Duplicate step name: {self.name}"
        _steps[self.name] = self

    async def __call__(self, *args: P.args, **kwargs: P.kwargs) -> T:
        from . import runtime

        try:
            ctx = runtime.WorkflowOrchestratorContext.current()
        except LookupError:
            raise RuntimeError(
                "cannot call step outside workflow; use a wrapper function instead"
            ) from None

        return await ctx.run_step(self, *args, **kwargs)


def step(func: Callable[P, Coroutine[Any, Any, T]]) -> Step[P, T]:
    return Step(func)


def get_step(step_name: str) -> Step[Any, Any]:
    return _steps[step_name]


async def sleep(param: int | float | datetime.datetime | str) -> None:
    from . import runtime

    try:
        ctx = runtime.WorkflowOrchestratorContext.current()
    except LookupError:
        raise RuntimeError("cannot call sleep outside workflow") from None

    await ctx.run_wait(param)
