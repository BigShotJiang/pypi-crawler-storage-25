"""nauro-core: shared pure-Python logic for the Nauro ecosystem.

Re-export facade — public API symbols from all modules.
"""

from importlib.metadata import version

from nauro_core import operations as operations
from nauro_core.constants import (
    DECISION_HASHES_FILE as DECISION_HASHES_FILE,
)
from nauro_core.constants import (
    DECISION_TYPES as DECISION_TYPES,
)
from nauro_core.constants import (
    DECISIONS_DIR as DECISIONS_DIR,
)
from nauro_core.constants import (
    EXPIRY_MINUTES as EXPIRY_MINUTES,
)
from nauro_core.constants import (
    L0_DECISIONS_SUMMARY_LIMIT as L0_DECISIONS_SUMMARY_LIMIT,
)
from nauro_core.constants import (
    L0_QUESTIONS_LIMIT as L0_QUESTIONS_LIMIT,
)
from nauro_core.constants import (
    L1_DECISIONS_LIMIT as L1_DECISIONS_LIMIT,
)
from nauro_core.constants import (
    L1_DECISIONS_SUMMARY_LIMIT as L1_DECISIONS_SUMMARY_LIMIT,
)
from nauro_core.constants import (
    MAX_APPROACH_LENGTH as MAX_APPROACH_LENGTH,
)
from nauro_core.constants import (
    MAX_CONTEXT_LENGTH as MAX_CONTEXT_LENGTH,
)
from nauro_core.constants import (
    MAX_DELTA_LENGTH as MAX_DELTA_LENGTH,
)
from nauro_core.constants import (
    MAX_QUESTION_LENGTH as MAX_QUESTION_LENGTH,
)
from nauro_core.constants import (
    MAX_RATIONALE_LENGTH as MAX_RATIONALE_LENGTH,
)
from nauro_core.constants import (
    MAX_TITLE_LENGTH as MAX_TITLE_LENGTH,
)
from nauro_core.constants import (
    MCP_INSTRUCTIONS as MCP_INSTRUCTIONS,
)
from nauro_core.constants import (
    MCP_INSTRUCTIONS_STATIC as MCP_INSTRUCTIONS_STATIC,
)
from nauro_core.constants import (
    MIN_RATIONALE_LENGTH as MIN_RATIONALE_LENGTH,
)
from nauro_core.constants import (
    NO_DECISIONS_TO_CHECK as NO_DECISIONS_TO_CHECK,
)
from nauro_core.constants import (
    OPEN_QUESTIONS_MD as OPEN_QUESTIONS_MD,
)
from nauro_core.constants import (
    PROJECT_MD as PROJECT_MD,
)
from nauro_core.constants import (
    REVERSIBILITY_LEVELS as REVERSIBILITY_LEVELS,
)
from nauro_core.constants import (
    SNAPSHOTS_DIR as SNAPSHOTS_DIR,
)
from nauro_core.constants import (
    STACK_EMPTY_MARKER as STACK_EMPTY_MARKER,
)
from nauro_core.constants import (
    STACK_MD as STACK_MD,
)
from nauro_core.constants import (
    STATE_CURRENT_FILENAME as STATE_CURRENT_FILENAME,
)
from nauro_core.constants import (
    STATE_HISTORY_FILENAME as STATE_HISTORY_FILENAME,
)
from nauro_core.constants import (
    STATE_LEGACY_FILENAME as STATE_LEGACY_FILENAME,
)
from nauro_core.constants import (
    STATE_MD as STATE_MD,
)
from nauro_core.constants import (
    VALID_CONFIDENCES as VALID_CONFIDENCES,
)
from nauro_core.context import (
    build_l0 as build_l0,
)
from nauro_core.context import (
    build_l1 as build_l1,
)
from nauro_core.context import (
    build_l2 as build_l2,
)
from nauro_core.decision_model import (
    Decision as Decision,
)
from nauro_core.decision_model import (
    DecisionConfidence as DecisionConfidence,
)
from nauro_core.decision_model import (
    DecisionSource as DecisionSource,
)
from nauro_core.decision_model import (
    DecisionStatus as DecisionStatus,
)
from nauro_core.decision_model import (
    DecisionType as DecisionType,
)
from nauro_core.decision_model import (
    RejectedAlternative as RejectedAlternative,
)
from nauro_core.decision_model import (
    Reversibility as Reversibility,
)
from nauro_core.decision_model import (
    format_decision as format_decision,
)
from nauro_core.decision_model import (
    parse_decision as parse_decision,
)
from nauro_core.instructions import (
    MAX_INLINE_PROJECTS as MAX_INLINE_PROJECTS,
)
from nauro_core.instructions import (
    WELCOME_NO_PROJECT as WELCOME_NO_PROJECT,
)
from nauro_core.instructions import (
    build_remote_instructions as build_remote_instructions,
)
from nauro_core.mcp_tools import (
    ALL_TOOLS as ALL_TOOLS,
)
from nauro_core.mcp_tools import (
    ToolSpec as ToolSpec,
)
from nauro_core.mcp_tools import (
    get_tool_spec as get_tool_spec,
)
from nauro_core.parsing import (
    decisions_summary_lines as decisions_summary_lines,
)
from nauro_core.parsing import (
    extract_current_state as extract_current_state,
)
from nauro_core.parsing import (
    extract_decision_number as extract_decision_number,
)
from nauro_core.parsing import (
    extract_relevance_snippet as extract_relevance_snippet,
)
from nauro_core.parsing import (
    extract_stack_oneliner as extract_stack_oneliner,
)
from nauro_core.parsing import (
    extract_stack_summary as extract_stack_summary,
)
from nauro_core.parsing import (
    parse_questions as parse_questions,
)
from nauro_core.pending import (
    PendingStore as PendingStore,
)
from nauro_core.protocol import (
    CANONICAL_FRAGMENTS as CANONICAL_FRAGMENTS,
)
from nauro_core.protocol import (
    CHECK_DECISION_RETURNS as CHECK_DECISION_RETURNS,
)
from nauro_core.protocol import (
    GET_DECISION_BEFORE_PROPOSING as GET_DECISION_BEFORE_PROPOSING,
)
from nauro_core.protocol import (
    NO_INVENT_RATIONALE as NO_INVENT_RATIONALE,
)
from nauro_core.protocol import (
    PROPOSE_DECISION_OPERATIONS as PROPOSE_DECISION_OPERATIONS,
)
from nauro_core.protocol import (
    RESOLVES_OPEN_QUESTIONS as RESOLVES_OPEN_QUESTIONS,
)
from nauro_core.protocol import (
    UPDATE_SUPERSEDE_CARE as UPDATE_SUPERSEDE_CARE,
)
from nauro_core.protocol import (
    protocol_tokens_in as protocol_tokens_in,
)
from nauro_core.protocol import (
    substitute_protocol_fragments as substitute_protocol_fragments,
)
from nauro_core.questions import (
    Block as Block,
)
from nauro_core.questions import (
    EntryBlock as EntryBlock,
)
from nauro_core.questions import (
    HeaderBlock as HeaderBlock,
)
from nauro_core.questions import (
    OpenQuestionsFile as OpenQuestionsFile,
)
from nauro_core.questions import (
    ProseBlock as ProseBlock,
)
from nauro_core.questions import (
    QuestionEntry as QuestionEntry,
)
from nauro_core.questions import (
    ResolvedRef as ResolvedRef,
)
from nauro_core.questions import (
    ResolveResult as ResolveResult,
)
from nauro_core.questions import (
    TripleHashBlock as TripleHashBlock,
)
from nauro_core.questions import (
    UnparsableBlock as UnparsableBlock,
)
from nauro_core.search import (
    bm25_retrieve as bm25_retrieve,
)
from nauro_core.search import (
    bm25_search as bm25_search,
)
from nauro_core.state import (
    StateUpdateResult as StateUpdateResult,
)
from nauro_core.state import (
    assemble_state_for_context as assemble_state_for_context,
)
from nauro_core.state import (
    migrate_legacy_state as migrate_legacy_state,
)
from nauro_core.state import (
    prepare_state_update as prepare_state_update,
)
from nauro_core.validation import (
    TIER2_STOPWORDS as TIER2_STOPWORDS,
)
from nauro_core.validation import (
    TIER2_TOP_K as TIER2_TOP_K,
)
from nauro_core.validation import (
    check_bm25_similarity as check_bm25_similarity,
)
from nauro_core.validation import (
    check_content_length as check_content_length,
)
from nauro_core.validation import (
    compute_hash as compute_hash,
)
from nauro_core.validation import (
    screen_structural as screen_structural,
)

__version__ = version("nauro-core")
