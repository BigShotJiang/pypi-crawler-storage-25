import functools
import requests
import time
import random

class SATPAgent:
    """
    The official SATP v1.0 Python SDK with Self-Healing Logic.
    Provides cryptographically gated access with institutional resilience.
    """
    
    @staticmethod
    def guard(max_retries=3, base_delay=1):
        """
        1-line wrapper to enforce SATP-Identity Gating with Self-Healing.
        Includes Exponential Backoff + Jitter for high-reliability sync.
        """
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                did = "did:satp:genesis:7782"
                
                # Self-Healing Retry Loop
                for attempt in range(max_retries + 1):
                    try:
                        # 1. Identity Preparation
                        print(f"[SATP] Syncing Heartbeat (Attempt {attempt + 1})...")
                        
                        # 2. Registration Sync
                        response = requests.post("http://127.0.0.1:5001/register", json={"did": did}, timeout=2)
                        
                        if response.status_code == 200 or response.status_code == 201:
                            print(f"[SUCCESS] [SATP] Identity Anchored: {did}")
                            break
                        else:
                            raise Exception(f"Server Error: {response.status_code}")
                            
                    except Exception as e:
                        if attempt == max_retries:
                            print(f"[FAILURE] [SATP] Critical Sync Failure: {e}")
                            break
                        
                        # Exponential Backoff + Jitter
                        delay = (base_delay * (2 ** attempt)) + (random.random() * 0.5)
                        print(f"[RETRYING] [SATP] Retrying in {delay:.2f}s... (Error: {e})")
                        time.sleep(delay)
                
                # 3. Inject Headers
                if 'headers' not in kwargs or kwargs['headers'] is None:
                    kwargs['headers'] = {}
                kwargs['headers']['X-SATP-DID'] = did
                
                return func(*args, **kwargs)
            return wrapper
        return decorator
