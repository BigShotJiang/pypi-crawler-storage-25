# Project: SATP v1.0 SDK
# License: SATP Source-Available License (SSAL) v1.0
# Copyright (c) 2026 SATP v1.0.
try:
    from .satp_agent.core import SATPAgent
except ImportError:
    from satp_agent.core import SATPAgent

# Convenience export for the SATP Python SDK
# Follows the SATP-Client naming standard
SATPClient = SATPAgent

