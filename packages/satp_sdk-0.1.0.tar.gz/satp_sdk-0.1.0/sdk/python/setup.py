from setuptools import setup, find_packages

setup(
    name="satp-sdk",
    version="1.0.0",
    description="Official SATP v1.0 Python SDK - Transparent Proxy Wrapper for AI Agents.",
    author="SATP v1.0",
    author_email="dev@satp.org",
    url="https://github.com/satp-org/satp-python-sdk",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "cryptography>=41.0.0",
        "pydantic[dotenv]>=2.0.0",
    ],
    entry_points={
        "console_scripts": [
            "satp = satp_agent.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3.11",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
        "Topic :: Security :: Cryptography",
    ],
    license="SATP Source-Available License v1.0",
    python_requires=">=3.8",
)
