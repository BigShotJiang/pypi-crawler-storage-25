# Style 1 — Dark Cinematic

A clean, product-forward aesthetic. Dark backgrounds, a single accent color, tight typography, and minimal ornamentation. Think Apple keynote meets SaaS product demo.

## Visual Theme

Dark canvas with high-contrast text. Single accent color used sparingly for emphasis — buttons, highlights, underlines. Large negative space. Content breathes. Nothing competes for attention. Every element earns its place.

## Color Palette

| Role | Hex | Usage |
|------|-----|-------|
| Canvas | `#0A0A0A` | Background fill for the entire frame |
| Surface | `#1A1A1A` | Cards, panels, subtle elevation |
| Text Primary | `#FFFFFF` | Headlines, key labels |
| Text Secondary | `#A0A0A0` | Body text, descriptions, metadata |
| Accent | `#3B82F6` | CTAs, highlights, underlines, focus rings |
| Accent Soft | `#3B82F620` | Accent backgrounds, pills, badges (12% opacity) |
| Danger | `#EF4444` | Errors, destructive actions |
| Success | `#22C55E` | Confirmations, positive states |

## Typography

| Role | Font | Size | Weight | Letter Spacing | Notes |
|------|------|------|--------|----------------|-------|
| Hero Title | SF Pro Display | 72 | Bold | -1.5% | One per frame maximum |
| Title | SF Pro Display | 48 | Semibold | -1.0% | Section headings |
| Subtitle | SF Pro Display | 32 | Medium | -0.5% | Supporting headings |
| Body | SF Pro Text | 24 | Regular | 0% | Readable at any scale |
| Label | SF Pro Text | 16 | Medium | 2% | Uppercase for category tags |
| Caption | SF Mono | 14 | Regular | 0% | Code, timestamps, metadata |

## Shape Language

- **Corner radius:** 12px for cards/panels, 999px (pill) for buttons and badges
- **Stroke:** 1px `#333333` for subtle borders. Never heavy outlines.
- **Shadows:** Subtle, dark. `offsetY: 4, blur: 16, color: #00000040`
- **Shapes:** Rectangles and pills only. No circles, triangles, or decorative shapes.

## Layout Principles

- **Canvas:** 1920×1080 (16:9)
- **Safe zone:** 160px margin on all sides (keep text within 1600×760 center area)
- **Grid:** 8px base unit. All spacing multiples of 8.
- **Alignment:** Left-aligned text by default. Center only for single hero lines.
- **Layer stacking:** Background → content card → text → accent elements (top)

## Animation & Timing

| Animation | Duration | Easing | Notes |
|-----------|----------|--------|-------|
| Text entrance | 0.6s | easeOut | fadeUpWords preferred |
| Text exit | 0.4s | easeIn | Quick, no lingering |
| Layer fade in | 0.5s | easeInOut | For content panels |
| Layer fade out | 0.3s | easeIn | Faster than entrance |
| Position moves | 0.8s | springSmooth | For layout transitions |
| Scale pops | 0.4s | springSnappy | For emphasis moments |

### Keyframe Conventions

- Always set **two keyframes minimum** for any animation (start + end state)
- Stagger text animations by 0.1s between elements for a cascading feel
- Use `easeOut` for entrances, `easeIn` for exits, `easeInOut` for transitions between states

## Transitions

- **Between segments:** `fade` (0.5s) or `dipToBlack` (0.8s)
- **Never:** `dipToWhite` (clashes with dark theme)

## Do's and Don'ts

### Do
- Use the accent color for exactly one focal element per frame
- Keep text large — if it's hard to read at 50% zoom, it's too small
- Use `SF Mono` for anything technical (code, stats, timestamps)
- Leave at least 40% of the frame as negative space
- Use pills/badges for category labels (`Accent Soft` background + `Accent` text)

### Don't
- Don't use more than 2 font weights per frame
- Don't mix warm and cool accent colors
- Don't put text over video without a dark overlay or surface card behind it
- Don't use decorative shapes — every element should be functional
- Don't animate more than 2 layers simultaneously

## Layout Recipes

Pixel-precise templates for common slide layouts. Use `set_canvas_background()` first, then build layers bottom-to-top.

### Recipe 1 — Hero Title (oversized type fills frame)

```
set_canvas_background(color="#0A0A0A")
```
- Title text: x=-30, y=200, font="SF Pro Display", size=160, weight="Heavy", color="#FFFFFF", letter_spacing=-3
- Subtitle: x=60, y=750, font="SF Pro Text", size=24, weight="Regular", color="#A0A0A0"
- Accent line (rectangle): x=60, y=730, width=200, height=3, fill="#3B82F6"

### Recipe 2 — Asymmetric Split (content left, accent right)

```
set_canvas_background(color="#0A0A0A")
```
- Accent rectangle: x=1200, y=0, width=720, height=1080, fill="#3B82F620", corner_radius=0
- Title: x=60, y=200, font="SF Pro Display", size=64, weight="Bold", color="#FFFFFF"
- Body: x=60, y=340, font="SF Pro Text", size=22, weight="Regular", color="#A0A0A0"
- Metadata: x=60, y=980, font="SF Pro Text", size=13, weight="Medium", color="#A0A0A0", uppercase, letter_spacing=4

### Recipe 3 — Center Stage (single statement)

```
set_canvas_background(color="#0A0A0A")
```
- Display text: x=0, y=0 (centered), font="SF Pro Display", size=96, weight="Bold", color="#FFFFFF", horizontal_align="center"
- Accent underline: centered below text, width=300, height=3, fill="#3B82F6"

### Recipe 4 — Sidebar + Main (editorial)

```
set_canvas_background(color="#0A0A0A")
```
- Left sidebar rect: x=-760, y=0, width=400, height=1080, fill="#1A1A1A"
- Sidebar text: x=-720, y=-480, font="SF Pro Text", size=14, weight="Medium", color="#A0A0A0", uppercase, letter_spacing=4
- Divider line: x=-560, y=0, width=2, height=960, fill="#333333"
- Main title: x=100, y=-100, font="SF Pro Display", size=72, weight="Bold", color="#FFFFFF"
- Main body: x=100, y=60, font="SF Pro Text", size=22, weight="Regular", color="#A0A0A0"

### Recipe 5 — Full Bleed + Overlay (for video segments)

Video layer at full canvas, then:
- Dark overlay rectangle: x=0, y=350, width=1920, height=380, fill="#000000", opacity=0.7
- Title: x=-900, y=300, font="SF Pro Display", size=48, weight="Bold", color="#FFFFFF"
- Subtitle: x=-900, y=370, font="SF Pro Text", size=20, weight="Regular", color="#A0A0A0"

### Recipe 6 — Pill Badge Layout (product feature)

```
set_canvas_background(color="#0A0A0A")
```
- Badge pill: x=-700, y=-350, width=160, height=36, fill="#3B82F620", corner_radius=999
- Badge text: x=-700, y=-350, font="SF Pro Text", size=14, weight="Medium", color="#3B82F6", uppercase
- Title: x=-660, y=-250, font="SF Pro Display", size=64, weight="Bold", color="#FFFFFF"
- Body: x=-660, y=-140, font="SF Pro Text", size=22, weight="Regular", color="#A0A0A0"
