# Style 2 — Bold Saturated

Energetic, color-forward, unapologetically bold. Saturated color blocks, condensed display type, rounded shapes, and high visual energy. Think tech startup social media meets editorial YouTube.

## Visual Theme

Dark canvas with punchy, saturated accent colors used as large blocks — not just accents. Bold condensed headlines that demand attention. Rounded corners everywhere. Uppercase labels in monospace. High contrast, high energy, zero subtlety.

## Color Palette

| Role | Hex | Usage |
|------|-----|-------|
| Canvas | `#111111` | Base dark background |
| Surface | `#1E1E1E` | Cards, content areas |
| Surface Elevated | `#2A2A2A` | Hover states, raised panels |
| Text Primary | `#FFFFFF` | All headings and key text |
| Text Secondary | `#B0B0B0` | Descriptions, metadata |
| Accent Magenta | `#FF2D87` | Primary accent — CTAs, highlights |
| Accent Cyan | `#00E5FF` | Secondary accent — tags, links, data |
| Accent Yellow | `#FFE100` | Tertiary — warnings, callouts, stars |
| Block Fill | `#FF2D8720` | Accent background blocks (12% opacity) |

### Color Block Usage
Use accent colors as **solid background fills** for callout cards and highlight panels:
- Magenta block: `fill: #FF2D87`, text: `#FFFFFF`
- Cyan block: `fill: #00E5FF`, text: `#111111`
- Yellow block: `fill: #FFE100`, text: `#111111`

## Typography

| Role | Font | Size | Weight | Letter Spacing | Notes |
|------|------|------|--------|----------------|-------|
| Hero Title | SF Pro Display | 80 | Heavy | -2% | Condensed feel, max impact |
| Title | SF Pro Display | 56 | Bold | -1.5% | Section headings |
| Subtitle | SF Pro Display | 36 | Semibold | -0.5% | Supporting text |
| Body | SF Pro Text | 22 | Regular | 0% | Readable body copy |
| Label | SF Mono | 14 | Bold | 8% | UPPERCASE, always. Category tags, metadata |
| Stat Number | SF Pro Display | 96 | Heavy | -3% | Hero statistics, counters |

## Shape Language

- **Corner radius:** 16px for cards, 24px for large panels, 999px for pills/buttons
- **Stroke:** 2px accent color for bordered elements. Bold, visible.
- **Shadows:** None by default. Use color blocks for depth instead.
- **Shapes:** Rounded rectangles and pills. Ellipses for avatars only.

## Layout Principles

- **Canvas:** 1920×1080 (16:9) or 1080×1920 (9:16 for social)
- **Safe zone:** 120px margin on all sides
- **Grid:** 8px base. Content blocks snap to 16px grid.
- **Alignment:** Center-aligned for hero content. Left-aligned for detail sections.
- **Layer stacking:** Canvas → color block → content card → text → accent highlights

### Color Block Layout
Use large color-filled rectangles (40-60% of frame width) as background panels for content groups. Offset text within these blocks with 32px padding.

## Animation & Timing

| Animation | Duration | Easing | Notes |
|-----------|----------|--------|-------|
| Text entrance | 0.5s | springSnappy | scaleUp or slideIn preferred |
| Text exit | 0.3s | easeIn | Fast snap out |
| Color block entrance | 0.6s | springBouncy | Scale from 0.8 → 1.0 |
| Number counter | 1.2s | easeOut | For stat reveals |
| Position moves | 0.5s | springSnappy | Quick, responsive |
| Label entrance | 0.3s | easeOut | trackingIn for uppercase labels |

### Keyframe Conventions

- **Entrances:** Start scaled at 0.9 and opacity 0, animate to 1.0/1.0
- **Bold moves:** Use `springBouncy` for playful, energetic motion
- **Stagger:** 0.08s between elements for fast cascade
- **Numbers:** Animate from 0 to final value over 1.2s with `easeOut`

## Transitions

- **Between segments:** `blurDissolve` (0.4s) for energy, `fade` (0.3s) for speed
- **Section breaks:** `dipToBlack` (0.6s)
- **Never:** `dipToWhite` — too soft for this style

## Do's and Don'ts

### Do
- Use at least one saturated color block per frame
- Make headlines LARGE — 56px minimum for titles
- Use uppercase monospace labels for categories and tags
- Pair contrasting accent colors (magenta + cyan, cyan + yellow)
- Use rounded corners on everything — consistency is the brand

### Don't
- Don't use pastel or muted colors — saturation is the point
- Don't use serif fonts — this style is all sans-serif and monospace
- Don't use thin font weights — Medium is the minimum
- Don't leave frames "quiet" — every frame should have visual energy
- Don't use square corners — they feel cold and corporate here
- Don't use more than 3 accent colors per frame

## Layout Recipes

Pixel-precise templates for common slide layouts. Use `set_canvas_background()` first. Bold, saturated, high-energy.

### Recipe 1 — Hero Title (oversized impact)

```
set_canvas_background(color="#111111")
```
- Title text: x=-30, y=150, font="SF Pro Display", size=160, weight="Heavy", color="#FFFFFF", letter_spacing=-4
- Accent block: x=-30, y=750, width=400, height=80, fill="#FF2D87", corner_radius=16
- Label inside block: x=-30, y=750, font="SF Mono", size=14, weight="Bold", color="#FFFFFF", uppercase, letter_spacing=8

### Recipe 2 — Color Block Split (content left, saturated right)

```
set_canvas_background(color="#111111")
```
- Accent block: x=600, y=0, width=720, height=1080, fill="#FF2D87", corner_radius=24
- Title: x=-600, y=-200, font="SF Pro Display", size=64, weight="Bold", color="#FFFFFF"
- Body: x=-600, y=-40, font="SF Pro Text", size=22, weight="Regular", color="#B0B0B0"
- Mono label: x=-600, y=440, font="SF Mono", size=14, weight="Bold", color="#00E5FF", uppercase, letter_spacing=8

### Recipe 3 — Stat Hero (big number + context)

```
set_canvas_background(color="#111111")
```
- Stat number: x=0, y=-100, font="SF Pro Display", size=160, weight="Heavy", color="#FFE100", horizontal_align="center"
- Unit label: x=0, y=80, font="SF Mono", size=14, weight="Bold", color="#B0B0B0", uppercase, letter_spacing=8, horizontal_align="center"
- Accent underline: x=0, y=140, width=200, height=4, fill="#FF2D87"

### Recipe 4 — Grid Cards (2×2 color blocks)

```
set_canvas_background(color="#111111")
```
- Card 1: x=-450, y=-250, width=830, height=420, fill="#1E1E1E", corner_radius=24
- Card 2: x=450, y=-250, width=830, height=420, fill="#FF2D8720", corner_radius=24
- Card 3: x=-450, y=250, width=830, height=420, fill="#00E5FF20", corner_radius=24
- Card 4: x=450, y=250, width=830, height=420, fill="#1E1E1E", corner_radius=24
- Each card: title at 28px Bold, body at 16px Regular, 32px internal padding

### Recipe 5 — Full Bleed + Overlay (video with energy)

Video layer at full canvas, then:
- Accent stripe: x=0, y=450, width=1920, height=6, fill="#FF2D87"
- Dark overlay: x=0, y=400, width=1920, height=280, fill="#111111", opacity=0.85
- Title: x=-850, y=350, font="SF Pro Display", size=56, weight="Bold", color="#FFFFFF"
- Mono label: x=-850, y=420, font="SF Mono", size=14, weight="Bold", color="#00E5FF", uppercase, letter_spacing=8

### Recipe 6 — Dual Accent (two competing blocks)

```
set_canvas_background(color="#111111")
```
- Left block: x=-500, y=0, width=800, height=600, fill="#FF2D87", corner_radius=24
- Right block: x=500, y=0, width=800, height=600, fill="#00E5FF", corner_radius=24
- Left text: x=-500, y=-80, font="SF Pro Display", size=48, weight="Bold", color="#FFFFFF"
- Right text: x=500, y=-80, font="SF Pro Display", size=48, weight="Bold", color="#111111"
- Center label: x=0, y=380, font="SF Mono", size=14, weight="Bold", color="#B0B0B0", uppercase
