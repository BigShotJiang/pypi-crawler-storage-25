# Style 3 — Editorial Serif

Refined, minimal, black-and-white. Inspired by print magazine design — tall serif display headlines, humanist body text, generous whitespace, and razor-sharp typographic hierarchy. Think documentary title cards meets long-form journalism.

## Visual Theme

White canvas. Black ink. No accent colors unless absolutely necessary — and even then, a single muted tone. The typography IS the design. Large display serifs command attention. Body text invites reading. Every pixel of whitespace is deliberate. This is confidence through restraint.

## Color Palette

| Role | Hex | Usage |
|------|-----|-------|
| Canvas | `#FFFFFF` | Clean white background |
| Canvas Soft | `#F5F5F5` | Subtle panel backgrounds, pull quotes |
| Ink | `#000000` | Headlines, primary text |
| Ink Soft | `#1A1A1A` | Body text (softer than pure black for readability) |
| Body Gray | `#757575` | Secondary text, metadata, timestamps |
| Hairline | `#E0E0E0` | Dividers, borders, subtle separators |
| Accent | `#057DBC` | Links, rare highlights (use very sparingly) |

### Color Rules
- **Primary palette is grayscale only.** Black, white, and grays.
- Accent blue is reserved for interactive elements or a single highlight per frame.
- If the frame doesn't need color, don't add any.

## Typography

| Role | Font | Size | Weight | Letter Spacing | Notes |
|------|------|------|--------|----------------|-------|
| Display Hero | New York | 72 | Regular | -1.0% | Tall, elegant, one per frame |
| Display Large | New York | 48 | Regular | -0.8% | Section titles |
| Display Medium | New York | 36 | Regular | -0.5% | Subheadings |
| Body | Georgia | 22 | Regular | 0% | Long-form readable text |
| Body Small | Georgia | 18 | Regular | 0% | Secondary paragraphs |
| Metadata | SF Pro Text | 13 | Medium | 4% | UPPERCASE. Dates, categories, credits |
| Caption | SF Pro Text | 14 | Regular | 0% | Image captions, footnotes |

### Typography Rules
- Display headlines use serif (`New York` or `Georgia`)
- Metadata and captions use sans-serif (`SF Pro Text`)
- **Never** mix serif and sans-serif at the same hierarchy level
- Body text line height: 150% of font size

## Shape Language

- **Corner radius:** 0px. Square corners only. No rounded shapes.
- **Stroke:** 1px `#E0E0E0` hairlines for dividers. Horizontal rules, not boxes.
- **Shadows:** None. Flat design. Use hairlines or whitespace for separation.
- **Shapes:** Horizontal rules only. No rectangles, circles, or decorative elements.

## Layout Principles

- **Canvas:** 1920×1080 (16:9)
- **Safe zone:** 200px horizontal margins, 120px vertical (generous margins are the brand)
- **Content width:** Max 1520px centered. Text blocks max 960px for readability.
- **Grid:** 8px base. But emphasis on generous spacing — 48px between major sections.
- **Alignment:** Left-aligned text always. Center alignment only for single-line credits.
- **Layer stacking:** Canvas → hairline dividers → text (hierarchy does all the work)

### Editorial Layout Patterns
1. **Hero card:** Full-width display headline, left-aligned, with metadata label above
2. **Quote card:** Centered italic body text on `Canvas Soft` background, attribution below
3. **Stat card:** Large display number + small metadata label below
4. **Credits:** Small metadata text, right-aligned, bottom of frame

## Animation & Timing

| Animation | Duration | Easing | Notes |
|-----------|----------|--------|-------|
| Text entrance | 0.8s | easeOut | fadeUpWords — slow, deliberate |
| Text exit | 0.5s | easeIn | Gentle fade |
| Hairline draw | 0.6s | easeInOut | Width animation from 0 to full |
| Section fade | 0.8s | easeInOut | Slow, contemplative |
| Position moves | 1.0s | easeInOut | Unhurried, confident |
| Metadata entrance | 0.4s | easeOut | trackingIn for uppercase labels |

### Keyframe Conventions

- **Timing is slower** than other styles — let content breathe
- Minimum 0.15s stagger between elements
- **Text animations:** `fadeUpWords` for headlines, `typewriter` for quotes
- **No spring easings** — this style uses classic easeIn/easeOut only
- **No scale animations** — everything fades or slides. No bouncing.

## Transitions

- **Between segments:** `fade` (0.8s) — slow, cinematic dissolve
- **Section breaks:** `dipToWhite` (1.0s) — matches the white canvas
- **Never:** `blurDissolve` or `dipToBlack` — too aggressive for this style

## Do's and Don'ts

### Do
- Let typography be the hero — a well-set headline is the entire design
- Use generous whitespace — 40% minimum negative space per frame
- Use hairline dividers (1px `#E0E0E0`) to separate content sections
- Use uppercase sans-serif metadata sparingly (dates, credits, categories)
- Make display headlines at least 48px — presence matters

### Don't
- Don't use colors beyond the grayscale palette (accent blue is an exception, rarely)
- Don't use bold weights for body text — Regular only
- Don't use rounded corners on anything — square is the language
- Don't use shadows or elevation — this is flat, print-inspired design
- Don't use decorative shapes (rectangles, circles, stars) — only horizontal rules
- Don't rush animations — this style is unhurried and confident
- Don't use more than one animation per layer entrance

## Layout Recipes

Pixel-precise templates for common slide layouts. Use `set_canvas_background()` first. Typography is the hero — no decoration.

### Recipe 1 — Hero Title (editorial serif, full width)

```
set_canvas_background(color="#FFFFFF")
```
- Metadata: x=-660, y=-350, font="SF Pro Text", size=13, weight="Medium", color="#757575", uppercase, letter_spacing=4
- Hairline: x=-660, y=-310, width=200, height=1, fill="#E0E0E0"
- Title text: x=-660, y=-150, font="New York", size=120, weight="Regular", color="#000000", letter_spacing=-2
- Subtitle: x=-660, y=100, font="Georgia", size=22, weight="Regular", color="#1A1A1A"

### Recipe 2 — Asymmetric Split (sidebar + main)

```
set_canvas_background(color="#FFFFFF")
```
- Left column metadata: x=-760, y=-480, font="SF Pro Text", size=13, weight="Medium", color="#757575", uppercase, letter_spacing=4
- Vertical hairline: x=-560, y=0, width=1, height=960, fill="#E0E0E0"
- Main title: x=-300, y=-200, font="New York", size=72, weight="Regular", color="#000000"
- Main body: x=-300, y=-40, font="Georgia", size=22, weight="Regular", color="#1A1A1A"
- Credits: x=700, y=480, font="SF Pro Text", size=13, weight="Medium", color="#757575"

### Recipe 3 — Pull Quote (centered statement)

```
set_canvas_background(color="#F5F5F5")
```
- Opening quote mark: x=-400, y=-250, font="New York", size=200, weight="Regular", color="#E0E0E0"
- Quote text: x=0, y=0, font="Georgia", size=36, weight="Regular", color="#1A1A1A", horizontal_align="center"
- Attribution: x=0, y=120, font="SF Pro Text", size=14, weight="Medium", color="#757575", horizontal_align="center"
- Top hairline: x=0, y=-300, width=100, height=1, fill="#E0E0E0"
- Bottom hairline: x=0, y=250, width=100, height=1, fill="#E0E0E0"

### Recipe 4 — Stat Card (large number + context)

```
set_canvas_background(color="#FFFFFF")
```
- Metadata label: x=-660, y=-300, font="SF Pro Text", size=13, weight="Medium", color="#757575", uppercase, letter_spacing=4
- Large number: x=-660, y=-100, font="New York", size=120, weight="Regular", color="#000000"
- Context line: x=-660, y=80, font="Georgia", size=22, weight="Regular", color="#1A1A1A"
- Hairline below: x=-660, y=140, width=400, height=1, fill="#E0E0E0"

### Recipe 5 — Full Bleed + Overlay (documentary video)

Video layer at full canvas, then:
- White overlay: x=0, y=350, width=1920, height=380, fill="#FFFFFF", opacity=0.9
- Title: x=-850, y=300, font="New York", size=48, weight="Regular", color="#000000"
- Subtitle: x=-850, y=380, font="Georgia", size=18, weight="Regular", color="#757575"

### Recipe 6 — Credits (end card)

```
set_canvas_background(color="#FFFFFF")
```
- Top hairline: x=0, y=-400, width=1600, height=1, fill="#E0E0E0"
- Title: x=0, y=-200, font="New York", size=48, weight="Regular", color="#000000", horizontal_align="center"
- Credit line 1: x=0, y=-80, font="SF Pro Text", size=16, weight="Medium", color="#757575", horizontal_align="center"
- Credit line 2: x=0, y=-40, font="SF Pro Text", size=16, weight="Regular", color="#757575", horizontal_align="center"
- Bottom hairline: x=0, y=400, width=1600, height=1, fill="#E0E0E0"
