"""Knooth MCP Server — natural language video editing."""

__version__ = "0.1.0"
