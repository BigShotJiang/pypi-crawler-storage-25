"""HTTP client for communicating with Knooth's embedded Swift server."""

from __future__ import annotations

import json
from pathlib import Path

import httpx

TOKEN_FILE = Path.home() / ".config" / "knooth" / "mcp_token.json"


def _load_token() -> tuple[str, int]:
    if not TOKEN_FILE.exists():
        raise RuntimeError(
            "Knooth is not running or MCP token file not found. "
            "Make sure Knooth is open with a project loaded. "
            f"Expected token at: {TOKEN_FILE}"
        )
    data = json.loads(TOKEN_FILE.read_text())
    return data["token"], data["port"]


class KnoothClient:
    def __init__(self) -> None:
        self._client = httpx.Client(timeout=300.0)
        self._refresh_token()

    def _refresh_token(self) -> None:
        token, port = _load_token()
        self._base = f"http://127.0.0.1:{port}"
        self._headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, body: dict | None = None) -> dict:
        kwargs: dict = {"headers": self._headers}
        if method != "GET":
            kwargs["json"] = body if body is not None else {}

        resp = self._client.request(method, f"{self._base}{path}", **kwargs)

        if resp.status_code == 401:
            self._refresh_token()
            kwargs["headers"] = self._headers
            resp = self._client.request(method, f"{self._base}{path}", **kwargs)

        return resp.json()

    def get(self, path: str) -> dict:
        return self._request("GET", path)

    def post(self, path: str, body: dict | None = None) -> dict:
        return self._request("POST", path, body)

    def delete(self, path: str, body: dict | None = None) -> dict:
        return self._request("DELETE", path, body)

    def close(self) -> None:
        self._client.close()
