# knooth-mcp

MCP server for [Knooth](https://knooth.com) video editor — natural language video editing.

Edit videos by talking to your AI tool. Add titles, trim clips, apply transitions, generate captions, remove filler words, and more — all through natural language.

## Prerequisites

- **Knooth** running with a project open
- **Python 3.10+**
- **uv** — fast Python package manager

### Install uv

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Homebrew
brew install uv
```

After installing, `uvx` is available automatically — no extra steps.

## Client Setup

### Claude Desktop

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "knooth": {
      "command": "uvx",
      "args": ["knooth-mcp"]
    }
  }
}
```

Restart Claude Desktop. The hammer icon appears — click it to see Knooth tools.

### Claude Code

```bash
claude mcp add knooth -- uvx knooth-mcp
```

Add `--scope user` to make it available across all projects. Verify with `/mcp`.

### Cursor

Edit `~/.cursor/mcp.json` (global) or `.cursor/mcp.json` (per-project):

```json
{
  "mcpServers": {
    "knooth": {
      "command": "uvx",
      "args": ["knooth-mcp"]
    }
  }
}
```

Open Cursor Settings → MCP → confirm Knooth shows as connected.

### VS Code (Copilot)

Edit `.vscode/mcp.json` in your workspace (or use Command Palette → `MCP: Add Server`):

```json
{
  "servers": {
    "knooth": {
      "command": "uvx",
      "args": ["knooth-mcp"]
    }
  }
}
```

Click "Start" next to the server entry.

> **Note:** VS Code uses `"servers"`, not `"mcpServers"`.

### Codex

```bash
codex mcp add knooth -- uvx knooth-mcp
```

Or edit `~/.codex/config.toml`:

```toml
[mcp_servers.knooth]
command = "uvx"
args = ["knooth-mcp"]
```

Verify with `/mcp` in the Codex TUI.

## What You Can Do

| Category | Examples |
|----------|---------|
| **Read** | Get project state, layer details, canvas screenshot |
| **Timeline** | Trim, split, move, delete, reorder layers |
| **Add Content** | Add text layers, shape layers |
| **Style** | Set fonts, colors, fills, strokes, shadows, corner radius |
| **Animation** | Add keyframes, set text animations, transitions |
| **Audio** | Adjust volume, noise reduction, audio enhancement |
| **AI Features** | Generate captions, transcribe audio, remove filler words, remove background |
| **Playback** | Seek, play/pause, export |
| **Design** | 3 built-in design presets, or bring your own `DESIGN.md` |

## Design Presets

Ask your AI tool to "use style-1" (or style-2, style-3) before adding visual elements:

| Preset | Vibe | Best For |
|--------|------|----------|
| `style-1` | Dark cinematic, single accent | Tech demos, SaaS walkthroughs |
| `style-2` | Bold saturated, color blocks | Energetic content, social media |
| `style-3` | B&W editorial serif | Documentaries, journalism |

Place a custom `DESIGN.md` in your Knooth project folder to use your own brand guidelines instead.
