import os, sys, tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from NX_5.encoder import encode_text
from NX_5.decoder import decode_svg

# Use system temp directory
TMP = tempfile.gettempdir()

def test_roundtrip_lowercase():
    f = os.path.join(TMP, 'test_hello.svg')
    encode_text("hello", f)
    assert decode_svg(f) == "hello", f"Expected 'hello'"

def test_roundtrip_mixed_case():
    f = os.path.join(TMP, 'test_hw.svg')
    encode_text("Hello World", f)
    assert decode_svg(f) == "Hello World"

def test_roundtrip_numbers():
    f = os.path.join(TMP, 'test_nums.svg')
    encode_text("abc 123", f)
    assert decode_svg(f) == "abc 123"

def test_roundtrip_symbols():
    f = os.path.join(TMP, 'test_sym.svg')
    encode_text("Hi (there)", f)
    assert decode_svg(f) == "Hi (there)"

if __name__ == '__main__':
    tests = [
        test_roundtrip_lowercase,
        test_roundtrip_mixed_case,
        test_roundtrip_numbers,
        test_roundtrip_symbols,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"  successfully tested: {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  test failed: {t.__name__}: {e}")
        except Exception as e:
            print(f"  test failed: {t.__name__}: unexpected error: {e}")
    print(f"\n  {passed}/{len(tests)} passed")