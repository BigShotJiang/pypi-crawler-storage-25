"""
NX-5 - Encoder
Converts text into nested-square SVG (optionally PNG) output
"""

from .constants import (
    ALL_CODES, INNER_W, INNER_H, LAYER_GAP, NOTCH_DEPTH,
    SEGMENTS, PADDING, WORD_GAP, BG_PAD, STROKE_WIDTH,
)


# Path builders
def _build_path(x, y, w, h, side, code):
    """Return SVG path `d` string for a square with notches on one side"""
    seg_h = h / SEGMENTS
    seg_w = w / SEGMENTS

    if side == 'right':
        rx = x + w
        d  = f'M {x:.1f},{y:.1f} L {rx:.1f},{y:.1f} '
        for s in range(SEGMENTS):
            y1 = y + s * seg_h;  y2 = y + (s+1) * seg_h
            if code[s] == '1':
                d += (
                        f'L {rx:.1f},{y1:.1f} L {rx+NOTCH_DEPTH:.1f},{y1:.1f} '
                        f'L {rx+NOTCH_DEPTH:.1f},{y2:.1f} L {rx:.1f},{y2:.1f} '
                    )
            else:
                d += f'L {rx:.1f},{y2:.1f} '
        d += f'L {x:.1f},{y+h:.1f} Z'

    elif side == 'left':
        lx = x
        d  = (
                f'M {lx:.1f},{y:.1f} L {lx+w:.1f},{y:.1f} '
                f'L {lx+w:.1f},{y+h:.1f} L {lx:.1f},{y+h:.1f} '
            )
        for s in range(SEGMENTS-1, -1, -1):
            y1 = y + s * seg_h;  y2 = y + (s+1) * seg_h
            if code[s] == '1':
                d += (
                        f'L {lx:.1f},{y2:.1f} L {lx-NOTCH_DEPTH:.1f},{y2:.1f} '
                        f'L {lx-NOTCH_DEPTH:.1f},{y1:.1f} L {lx:.1f},{y1:.1f} '
                    )
            else:
                d += f'L {lx:.1f},{y1:.1f} '
        d += 'Z'

    elif side == 'top':
        ty = y
        d  = (
                f'M {x:.1f},{ty:.1f} L {x:.1f},{y+h:.1f} '
                f'L {x+w:.1f},{y+h:.1f} L {x+w:.1f},{ty:.1f} '
            )
        for s in range(SEGMENTS-1, -1, -1):
            x1 = x + s * seg_w;  x2 = x + (s+1) * seg_w
            if code[s] == '1':
                d += (
                        f'L {x2:.1f},{ty:.1f} L {x2:.1f},{ty-NOTCH_DEPTH:.1f} '
                        f'L {x1:.1f},{ty-NOTCH_DEPTH:.1f} L {x1:.1f},{ty:.1f} '
                    )
            else:
                d += f'L {x1:.1f},{ty:.1f} '
        d += 'Z'

    return d


def _build_pillow_pts(x, y, w, h, side, code):
    """Same geometry as _build_path but returns a point list for Pillow"""
    seg_h = h / SEGMENTS
    seg_w = w / SEGMENTS
    pts   = []

    if side == 'right':
        rx = x + w
        pts += [(x, y), (rx, y)]
        for s in range(SEGMENTS):
            y1 = y + s * seg_h;  y2 = y + (s+1) * seg_h
            if code[s] == '1':
                pts += [(rx, y1), (rx+NOTCH_DEPTH, y1),
                        (rx+NOTCH_DEPTH, y2), (rx, y2)]
            else:
                pts.append((rx, y2))
        pts.append((x, y+h))

    elif side == 'left':
        lx = x
        pts += [(lx, y), (lx+w, y), (lx+w, y+h), (lx, y+h)]
        for s in range(SEGMENTS-1, -1, -1):
            y1 = y + s * seg_h;  y2 = y + (s+1) * seg_h
            if code[s] == '1':
                pts += [(lx, y2), (lx-NOTCH_DEPTH, y2),
                        (lx-NOTCH_DEPTH, y1), (lx, y1)]
            else:
                pts.append((lx, y1))

    elif side == 'top':
        ty = y
        pts += [(x, ty), (x, y+h), (x+w, y+h), (x+w, ty)]
        for s in range(SEGMENTS-1, -1, -1):
            x1 = x + s * seg_w;  x2 = x + (s+1) * seg_w
            if code[s] == '1':
                pts += [(x2, ty), (x2, ty-NOTCH_DEPTH),
                        (x1, ty-NOTCH_DEPTH), (x1, ty)]
            else:
                pts.append((x1, ty))

    return [(int(px), int(py)) for px, py in pts]


# Word encoder
def _encode_word(word):
    chars = [c for c in word if c in ALL_CODES]
    n     = len(chars)
    if not n:
        return None

    total_w = INNER_W + 2*(n-1)*LAYER_GAP + 2*PADDING + NOTCH_DEPTH + 4
    total_h = INNER_H + 2*(n-1)*LAYER_GAP + 2*PADDING + NOTCH_DEPTH
    cx      = total_w / 2
    cy      = total_h / 2 + NOTCH_DEPTH / 2

    paths = []
    for i, ch in enumerate(chars):
        side, code, color = ALL_CODES[ch]
        w = INNER_W + 2*i*LAYER_GAP
        h = INNER_H + 2*i*LAYER_GAP
        x = cx - w/2
        y = cy - h/2
        d = _build_path(x, y, w, h, side, code)
        paths.append(
            f'  <path d="{d}" fill="none" stroke="{color}" '
            f'stroke-width="{STROKE_WIDTH}" stroke-linejoin="round"/>'
        )

    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{total_w:.0f}" height="{total_h:.0f}" '
        f'viewBox="0 0 {total_w:.1f} {total_h:.1f}">\n'
        f'  <rect width="100%" height="100%" fill="#0f0f0f"/>\n'
        + '\n'.join(paths) + '\n</svg>'
    )
    return svg, total_w, total_h


# PNG renderer
def _hex_to_rgb(hex_color):
    h = hex_color.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


def _render_png(word_data, total_w, total_h, png_file):
    from PIL import Image, ImageDraw
    img  = Image.new('RGB', (int(total_w), int(total_h)), (15, 15, 15))
    draw = ImageDraw.Draw(img)
    lw   = max(2, STROKE_WIDTH)

    cursor_x = BG_PAD
    max_h    = max(h for _, (_, _, h) in word_data)

    for word, (_, w, h) in word_data:
        chars    = [c for c in word if c in ALL_CODES]
        n        = len(chars)
        vert_off = BG_PAD + (max_h - h) / 2

        inner_total_w = INNER_W + 2*(n-1)*LAYER_GAP + 2*PADDING + NOTCH_DEPTH + 4
        inner_total_h = INNER_H + 2*(n-1)*LAYER_GAP + 2*PADDING + NOTCH_DEPTH
        cx = cursor_x + inner_total_w / 2
        cy = vert_off  + inner_total_h / 2 + NOTCH_DEPTH / 2

        for i, ch in enumerate(chars):
            side, code, hex_color = ALL_CODES[ch]
            color = _hex_to_rgb(hex_color)
            sq_w  = INNER_W + 2*i*LAYER_GAP
            sq_h  = INNER_H + 2*i*LAYER_GAP
            x     = cx - sq_w/2
            y     = cy - sq_h/2
            pts   = _build_pillow_pts(x, y, sq_w, sq_h, side, code)
            draw.line(pts + [pts[0]], fill=color, width=lw, joint='curve')

        cursor_x += w + WORD_GAP

    img.save(png_file)
    print(f" PNG: {png_file}")



def encode_text(text: str, output_file: str = 'output.svg', export_png: bool = False):
    words     = [w for w in text.split(' ') if w]
    word_data = [(w, _encode_word(w)) for w in words]
    word_data = [(w, r) for w, r in word_data if r]

    if not word_data:
        print("No valid characters to encode")
        return

    max_h   = max(h for _, (_, _, h) in word_data)
    total_w = (sum(w for _, (_, w, _) in word_data)
               + WORD_GAP * (len(word_data)-1) + 2*BG_PAD)
    total_h = max_h + 2*BG_PAD

    parts    = []
    cursor_x = BG_PAD

    for word, (svg_str, w, h) in word_data:
        lines       = svg_str.strip().split('\n')
        inner_lines = [l for l in lines[1:-1] if '<rect' not in l]
        vert_off    = BG_PAD + (max_h - h) / 2

        parts.append(f'  <g transform="translate({cursor_x:.1f},{vert_off:.1f})">')
        parts.extend(inner_lines)
        parts.append('  </g>')

        cursor_x += w + WORD_GAP

    final_svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{total_w:.0f}" height="{total_h:.0f}" '
        f'viewBox="0 0 {total_w:.1f} {total_h:.1f}">\n'
        f'  <rect width="100%" height="100%" fill="#0f0f0f"/>\n'
        + '\n'.join(parts) + '\n</svg>'
    )

    with open(output_file, 'w') as f:
        f.write(final_svg)

    if export_png:
        png_file = output_file.replace('.svg', '.png')
        _render_png(word_data, total_w, total_h, png_file)

    print(f"Encoded '{text}' → {output_file}")
    print(f"Words : {len(word_data)}")
    print(f"Canvas: {total_w:.0f} × {total_h:.0f} px")
    for word, (_, w, h) in word_data:
        chars = [c for c in word if c in ALL_CODES]
        info  = [f"{repr(c)}={ALL_CODES[c][0][0].upper()}:{ALL_CODES[c][1]}" for c in chars]
        print(f"  '{word}': {' | '.join(info)}")


# CLI
def main():
    import sys
    args     = [a for a in sys.argv[1:] if a != '--png']
    want_png = '--png' in sys.argv[1:]

    if args:
        text = ' '.join(args)
        encode_text(text, text.replace(' ', '_') + '.svg', export_png=want_png)
        sys.exit(0)

    print("""
        ||============================================||
                        NX-5 Encoder v1.0            
            left=CAP - right=lower - top=0-9+symbols  
        ||============================================||
        """)
    
    print("  Type 'quit' or 'exit' to stop\n")

    while True:
        try:
            text = input("Enter text to encode: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!"); break
        if not text: print("Enter some text\n"); continue
        if text.lower() in ('quit', 'exit'): print("Bye!"); break
        bad = [c for c in text if c != ' ' and c not in ALL_CODES]
        if bad:
            print(f"Unsupported: {set(bad)}")
            print("A-Z a-z 0-9 ( ) [ ] {{ }} < > ! @ # $ % / & * ' \" - _ = +\n")
            continue
        want_png = input(" export PNG? (y/N): ").strip().lower() == 'y'
        encode_text(text, text.replace(' ', '_') + '.svg', export_png=want_png)
        print()


if __name__ == '__main__':
    main()