# Mappings
LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
LETTER_CODES = {}
for i, letter in enumerate(LETTERS):
    code = format(i + 1, '05b')
    LETTER_CODES[letter]         = code
    LETTER_CODES[letter.lower()] = code

_TOP_CHARS = (
    '0','1','2','3','4','5','6','7','8','9',
    '(',')', '[',']', '{','}', '<','>',
    '!','@','#','$','%','/','&','*',
    "'",'"', '-','_','=','+',
)
TOP_CODES = {ch: format(i, '05b') for i, ch in enumerate(_TOP_CHARS)}

_DIGITS = set('0123456789')

ALL_CODES = {}
for ch, code in LETTER_CODES.items():
    color = '#2a6db5' if ch.isupper() else '#c0392b'
    side  = 'left'   if ch.isupper() else 'right'
    ALL_CODES[ch] = (side, code, color)
for ch, code in TOP_CODES.items():
    color = '#27ae60' if ch in _DIGITS else '#9b59b6'
    ALL_CODES[ch] = ('top', code, color)

# Reverse lookups for decoder
LEFT_LOOKUP  = {format(i+1,'05b'): letter        for i,letter in enumerate(LETTERS)}
RIGHT_LOOKUP = {format(i+1,'05b'): letter.lower() for i,letter in enumerate(LETTERS)}
TOP_LOOKUP   = {format(i,'05b'): ch for i,ch in enumerate(_TOP_CHARS)}

COLOR_SIDE = {
    '#2a6db5': 'left',
    '#c0392b': 'right',
    '#27ae60': 'top',
    '#9b59b6': 'top',
}

# Layout defaults
INNER_W      = 160
INNER_H      = 160
LAYER_GAP    = 150
NOTCH_DEPTH  = 40
SEGMENTS     = 5
PADDING      = 50
WORD_GAP     = 50
BG_PAD       = 80
STROKE_WIDTH = 7