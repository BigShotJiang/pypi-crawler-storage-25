from .encoder import encode_text
from .decoder import decode_svg

__version__ = "1.0.2"
__author__  = "mrcloud"
__all__     = ["encode_text", "decode_svg"]