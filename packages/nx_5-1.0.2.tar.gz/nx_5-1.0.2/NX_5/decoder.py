"""
NX-5 - Decoder
Reconstructs text from a Notch-encoded SVG using pure geometry.
"""

import xml.etree.ElementTree as ET
import re
import os

from .constants import (
    COLOR_SIDE, LEFT_LOOKUP, RIGHT_LOOKUP, TOP_LOOKUP, NOTCH_DEPTH,
)


# Coordinate parser 
def _parse_coords(d: str):
    """Extract all (x, y) pairs from an SVG path `d` attribute string"""
    tokens = re.findall(r'[-+]?[0-9]*\.?[0-9]+', d)
    nums   = [float(t) for t in tokens]
    return [(nums[i], nums[i+1]) for i in range(0, len(nums)-1, 2)]


# Notch detectors
def _detect_right(pts, depth=NOTCH_DEPTH):
    active = set()
    rx    = max(px for px, py in pts)
    sq_y  = min(py for px, py in pts if abs(px - (rx-depth)) > 1)
    sq_h  = max(py for px, py in pts if abs(px - (rx-depth)) > 1) - sq_y
    seg_h = sq_h / 5
    for i in range(len(pts)-1):
        px1, py1 = pts[i];  px2, py2 = pts[i+1]
        if px2 > px1 and abs(px2-px1-depth) < 1.0:
            seg = round((py1 - sq_y) / seg_h)
            if 0 <= seg < 5:
                active.add(seg)
    return ''.join('1' if s in active else '0' for s in range(5))


def _detect_left(pts, depth=NOTCH_DEPTH):
    active = set()
    lx    = min(px for px, py in pts)
    sq_y  = min(py for px, py in pts if abs(px - (lx+depth)) > 1)
    sq_h  = max(py for px, py in pts if abs(px - (lx+depth)) > 1) - sq_y
    seg_h = sq_h / 5
    for i in range(len(pts)-1):
        px1, py1 = pts[i];  px2, py2 = pts[i+1]
        if px1 > px2 and abs(px1-px2-depth) < 1.0:
            seg = round((py1 - sq_y) / seg_h) - 1
            if 0 <= seg < 5:
                active.add(seg)
    return ''.join('1' if s in active else '0' for s in range(5))


def _detect_top(pts, depth=NOTCH_DEPTH):
    active = set()
    ty    = min(py for px, py in pts)
    sq_x  = min(px for px, py in pts if abs(py - (ty+depth)) > 1)
    sq_w  = max(px for px, py in pts if abs(py - (ty+depth)) > 1) - sq_x
    seg_w = sq_w / 5
    for i in range(len(pts)-1):
        px1, py1 = pts[i];  px2, py2 = pts[i+1]
        if py1 > py2 and abs(py1-py2-depth) < 1.0:
            seg = round((px1 - sq_x) / seg_w) - 1
            if 0 <= seg < 5:
                active.add(seg)
    return ''.join('1' if s in active else '0' for s in range(5))


# Single path decoder
def _decode_path(path_el):
    """Decode one <path> element => (character, bounding_area) or None"""
    stroke = path_el.get('stroke', '').lower().strip()
    side   = COLOR_SIDE.get(stroke)
    if side is None:
        return None

    d   = path_el.get('d', '')
    pts = _parse_coords(d)
    if not pts:
        return None

    if side == 'right':
        code   = _detect_right(pts)
        lookup = RIGHT_LOOKUP
    elif side == 'left':
        code   = _detect_left(pts)
        lookup = LEFT_LOOKUP
    else:
        code   = _detect_top(pts)
        lookup = TOP_LOOKUP

    ch = lookup.get(code)
    if ch is None:
        return None

    xs   = [px for px, py in pts]
    ys   = [py for px, py in pts]
    area = (max(xs)-min(xs)) * (max(ys)-min(ys))
    return ch, area



def decode_svg(input_file: str) -> str:
    if not os.path.exists(input_file):
        raise FileNotFoundError(f"File not found: {input_file}")

    tree = ET.parse(input_file)
    root = tree.getroot()

    for el in root.iter():
        el.tag = el.tag.split('}')[-1]  

    groups = [el for el in root if el.tag == 'g']
    if not groups:
        raise ValueError("No word groups found, is this a NX-5 encoded SVG?")

    decoded_words = []

    for g_idx, group in enumerate(groups):
        paths = group.findall('.//path')
        if not paths:
            continue

        chars = []
        for path_el in paths:
            result = _decode_path(path_el)
            if result:
                chars.append(result)

        if not chars:
            continue

        chars.sort(key=lambda x: x[1])  
        word = ''.join(ch for ch, _ in chars)
        decoded_words.append(word)

        print(f"  Word {g_idx+1}: '{word}'")
        for ch, area in chars:
            print(f"    {repr(ch):4}  area={area:.0f}")

    return ' '.join(decoded_words)


# CLI
def main():
    import sys

    if len(sys.argv) > 1:
        print(f"\nDecoding: {sys.argv[1]}\n")
        try:
            result = decode_svg(sys.argv[1])
            print(f"\n Decoded: '{result}'\n")
        except (FileNotFoundError, ValueError) as e:
            print(f"  X {e}")
        sys.exit(0)

    print("""
        ||============================================||
                        NX-5 Decoder v1.0            
                reads svg files from the encoder      
        ||============================================||
        """)
    print("  Type 'quit' or 'exit' to stop\n")

    while True:
        try:
            svg_file = input("SVG file to decode: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!"); break
        if not svg_file: continue
        if svg_file.lower() in ('quit', 'exit'): print("Bye!"); break
        print()
        try:
            result = decode_svg(svg_file)
            print(f"\nDecoded: '{result}'\n")
        except (FileNotFoundError, ValueError) as e:
            print(f"  X {e}\n")


if __name__ == '__main__':
    main()