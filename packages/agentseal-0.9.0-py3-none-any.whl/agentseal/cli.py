# agentseal/cli.py
"""
AgentSeal CLI — agents run this to test themselves.

Usage:
    # Test a prompt against a model directly
    agentseal scan --prompt "You are a helpful assistant..." --model gpt-4o

    # Test from a file
    agentseal scan --file ./system_prompt.txt --model gpt-4o

    # Test a live HTTP endpoint
    agentseal scan --url http://localhost:8080/chat

    # Test Claude Desktop config
    agentseal scan --claude-desktop

    # Test with Ollama locally
    agentseal scan --prompt "..." --model ollama/qwen3-32b --ollama-url http://localhost:11434

    # Output as JSON
    agentseal scan --prompt "..." --model gpt-4o --output json

    # CI mode (exit code 1 if score < threshold)
    agentseal scan --prompt "..." --model gpt-4o --min-score 75
"""

import asyncio
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path


# ═══════════════════════════════════════════════════════════════════════
# LICENSE CHECK — PDF reports and dashboard are paid features
# ═══════════════════════════════════════════════════════════════════════

_PRO_FEATURES = {"report", "upload"}
_UPGRADE_URL = "https://agentseal.io/pro"


def _load_license() -> dict:
    """Load license from ~/.agentseal/license.json or env."""
    key = os.environ.get("AGENTSEAL_LICENSE_KEY", "")
    if key:
        return {"key": key, "valid": True}

    license_path = Path.home() / ".agentseal" / "license.json"
    if license_path.exists():
        try:
            data = json.loads(license_path.read_text())
            if data.get("key"):
                return {"key": data["key"], "valid": True}
        except (json.JSONDecodeError, KeyError):
            pass
    return {"key": "", "valid": False}


def _is_pro() -> bool:
    """Check if the user has a valid Pro license."""
    return _load_license().get("valid", False)


def _pro_gate(feature: str) -> bool:
    """Check if a Pro feature is available. Prints upgrade message if not."""
    if _is_pro():
        return True
    print()
    print(f"  \033[93m{'━' * 52}\033[0m")
    print(f"  \033[93m  {feature.upper()} is a Pro feature\033[0m")
    print()
    print(f"  \033[0m  Upgrade to AgentSeal Pro to unlock:")
    print(f"  \033[0m    - PDF security assessment reports")
    print(f"  \033[0m    - Dashboard & historical tracking")
    print(f"  \033[0m    - Team sharing & collaboration")
    print()
    print(f"  \033[38;5;75m  {_UPGRADE_URL}\033[0m")
    print()
    print(f"  \033[90m  Already have a license? Set AGENTSEAL_LICENSE_KEY\033[0m")
    print(f"  \033[90m  or run: agentseal activate <key>\033[0m")
    print(f"  \033[93m{'━' * 52}\033[0m")
    print()
    return False


def _print_banner(show_tagline=True):
    """Print the AgentSeal CLI banner with gradient colors."""
    from agentseal import __version__

    # Gradient: cyan → blue → purple → pink
    c = [
        "\033[38;5;51m",   # A
        "\033[38;5;45m",   # G
        "\033[38;5;39m",   # E
        "\033[38;5;33m",   # N
        "\033[38;5;63m",   # T
        "\033[38;5;99m",   # S
        "\033[38;5;135m",  # E
        "\033[38;5;171m",  # A
        "\033[38;5;207m",  # L
    ]
    R = "\033[0m"
    D = "\033[90m"

    # Large 2x block letters
    rows = [
        f"   {c[0]}  ██████╗  {c[1]} ██████╗ {c[2]}███████╗{c[3]}███╗   ██╗{c[4]}████████╗{c[5]}███████╗{c[6]}███████╗{c[7]} █████╗ {c[8]}██╗     {R}",
        f"   {c[0]} ██╔══██╗ {c[1]}██╔════╝ {c[2]}██╔════╝{c[3]}████╗  ██║{c[4]}╚══██╔══╝{c[5]}██╔════╝{c[6]}██╔════╝{c[7]}██╔══██╗{c[8]}██║     {R}",
        f"   {c[0]} ███████║ {c[1]}██║  ███╗{c[2]}█████╗  {c[3]}██╔██╗ ██║{c[4]}   ██║   {c[5]}███████╗{c[6]}█████╗  {c[7]}███████║{c[8]}██║     {R}",
        f"   {c[0]} ██╔══██║ {c[1]}██║   ██║{c[2]}██╔══╝  {c[3]}██║╚██╗██║{c[4]}   ██║   {c[5]}╚════██║{c[6]}██╔══╝  {c[7]}██╔══██║{c[8]}██║     {R}",
        f"   {c[0]} ██║  ██║ {c[1]}╚██████╔╝{c[2]}███████╗{c[3]}██║ ╚████║{c[4]}   ██║   {c[5]}███████║{c[6]}███████╗{c[7]}██║  ██║{c[8]}███████╗{R}",
        f"   {c[0]} ╚═╝  ╚═╝ {c[1]} ╚═════╝ {c[2]}╚══════╝{c[3]}╚═╝  ╚═══╝{c[4]}   ╚═╝   {c[5]}╚══════╝{c[6]}╚══════╝{c[7]}╚═╝  ╚═╝{c[8]}╚══════╝{R}",
    ]

    print()
    for row in rows:
        print(row)
    print(f"   {D}v{__version__}{R}")
    if show_tagline:
        print(f"{D}                  Security Validator for AI Agents{R}")
    print()


def main():
    import argparse

    from agentseal import __version__

    parser = argparse.ArgumentParser(
        prog="agentseal",
        description="AgentSeal — Security validator for AI agents",
    )
    parser.add_argument("--version", "-V", action="version", version=f"agentseal {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    # ── scan command ─────────────────────────────────────────────────
    scan_parser = subparsers.add_parser("scan", help="Run security scan against an agent")

    # Input sources (pick one)
    input_group = scan_parser.add_mutually_exclusive_group(required=False)
    input_group.add_argument("--prompt", "-p", type=str, help="System prompt to test (inline)")
    input_group.add_argument("--file", "-f", type=str, help="Path to file containing system prompt")
    input_group.add_argument("--url", type=str, help="HTTP endpoint URL to test")
    input_group.add_argument("--claude-desktop", action="store_true", help="Auto-detect Claude Desktop config")
    input_group.add_argument("--cursor", action="store_true", help="Auto-detect Cursor IDE config")

    # Model (required for prompt/file mode)
    scan_parser.add_argument("--model", "-m", type=str, default=None,
                             help="Model to test against (e.g. gpt-4o, claude-sonnet-4-5-20250929, ollama/qwen3-32b)")

    # LLM connection
    scan_parser.add_argument("--api-key", type=str, default=None,
                             help="API key (or set OPENAI_API_KEY / ANTHROPIC_API_KEY env)")
    scan_parser.add_argument("--ollama-url", type=str, default="http://localhost:11434",
                             help="Ollama base URL (default: http://localhost:11434)")
    scan_parser.add_argument("--litellm-url", type=str, default=None,
                             help="LiteLLM proxy URL (e.g. http://localhost:4000)")

    # HTTP endpoint options
    scan_parser.add_argument("--message-field", type=str, default="message",
                             help="JSON field name for message in HTTP request")
    scan_parser.add_argument("--response-field", type=str, default="response",
                             help="JSON field name for response in HTTP response")

    # Output
    scan_parser.add_argument("--output", "-o", type=str, choices=["terminal", "json", "sarif"],
                             default="terminal", help="Output format")
    scan_parser.add_argument("--save", type=str, default=None,
                             help="Save report to file")
    scan_parser.add_argument("--report", type=str, default=None,
                             help="Generate PDF security assessment report (e.g. --report report.pdf)")

    # Behavior
    scan_parser.add_argument("--name", type=str, default="My Agent",
                             help="Agent name for the report")
    scan_parser.add_argument("--concurrency", type=int, default=3,
                             help="Max parallel probes (default: 3)")
    scan_parser.add_argument("--timeout", type=float, default=30.0,
                             help="Timeout per probe in seconds (default: 30)")
    scan_parser.add_argument("--verbose", "-v", action="store_true",
                             help="Show each probe result as it completes")

    # CI mode
    scan_parser.add_argument("--min-score", type=int, default=None,
                             help="Exit with code 1 if score is below this (for CI/CD)")

    # Upload to dashboard
    scan_parser.add_argument("--upload", action="store_true",
                             help="Upload results to AgentSeal dashboard after scan")
    scan_parser.add_argument("--dashboard-url", type=str, default=None,
                             help="Dashboard API URL (or set AGENTSEAL_API_URL env)")
    scan_parser.add_argument("--dashboard-key", type=str, default=None,
                             help="Dashboard API key (or set AGENTSEAL_API_KEY env)")

    # Adaptive mutations
    scan_parser.add_argument("--adaptive", action="store_true",
                             help="Enable adaptive mutation phase — re-test blocked probes with transforms")

    # Semantic detection
    scan_parser.add_argument("--semantic", action="store_true",
                             help="Enable semantic leak detection (requires: pip install agentseal[semantic])")

    # MCP tool poisoning probes
    scan_parser.add_argument("--mcp", action="store_true",
                             help="Include MCP tool poisoning probes (26 additional injection probes)")

    # RAG poisoning probes
    scan_parser.add_argument("--rag", action="store_true",
                             help="Include RAG poisoning probes (20 additional injection probes)")

    # Genome mapping
    scan_parser.add_argument("--genome", action="store_true",
                             help="Run behavioral genome mapping -- find exact decision boundaries")
    scan_parser.add_argument("--genome-categories", type=int, default=3,
                             help="Max categories to analyze in genome scan (default: 3)")
    scan_parser.add_argument("--genome-probes", type=int, default=5,
                             help="Max probes per category in genome scan (default: 5)")

    # Quick inline
    scan_parser.add_argument("prompt_inline", nargs="?", type=str, default=None,
                             help="Quick inline: agentseal scan 'Your prompt here' --model gpt-4o")

    # ── login command ──────────────────────────────────────────────────
    login_parser = subparsers.add_parser("login", help="Store dashboard credentials")
    login_parser.add_argument("--api-url", type=str, default=None,
                              help="Dashboard API URL")
    login_parser.add_argument("--api-key", type=str, default=None,
                              help="Dashboard API key")

    # ── activate command ──────────────────────────────────────────────
    activate_parser = subparsers.add_parser("activate", help="Activate a Pro license key")
    activate_parser.add_argument("key", type=str, nargs="?", default=None,
                                  help="Your license key")

    # ── watch command ─────────────────────────────────────────────────
    watch_parser = subparsers.add_parser("watch", help="Run canary regression scan (5 probes, for CI/cron)")

    # Input sources (same as scan)
    watch_input = watch_parser.add_mutually_exclusive_group(required=False)
    watch_input.add_argument("--prompt", "-p", type=str, help="System prompt to test (inline)")
    watch_input.add_argument("--file", "-f", type=str, help="Path to file containing system prompt")
    watch_input.add_argument("--url", type=str, help="HTTP endpoint URL to test")

    # Model/connection
    watch_parser.add_argument("--model", "-m", type=str, default=None,
                               help="Model to test against")
    watch_parser.add_argument("--api-key", type=str, default=None,
                               help="API key (or set OPENAI_API_KEY / ANTHROPIC_API_KEY env)")
    watch_parser.add_argument("--ollama-url", type=str, default="http://localhost:11434",
                               help="Ollama base URL (default: http://localhost:11434)")
    watch_parser.add_argument("--litellm-url", type=str, default=None,
                               help="LiteLLM proxy URL")

    # HTTP endpoint options
    watch_parser.add_argument("--message-field", type=str, default="message",
                               help="JSON field name for message in HTTP request")
    watch_parser.add_argument("--response-field", type=str, default="response",
                               help="JSON field name for response in HTTP response")

    # Watch-specific
    watch_parser.add_argument("--set-baseline", action="store_true",
                               help="Store current result as the baseline and exit")
    watch_parser.add_argument("--reset-baseline", action="store_true",
                               help="Clear stored baseline and exit")
    watch_parser.add_argument("--score-threshold", type=float, default=5.0,
                               help="Score drop threshold to trigger alert (default: 5.0)")
    watch_parser.add_argument("--canary-probes", type=str, default=None,
                               help="Comma-separated probe IDs to use instead of defaults")
    watch_parser.add_argument("--webhook-url", type=str, default=None,
                               help="Webhook URL for regression alerts")
    watch_parser.add_argument("--min-score", type=int, default=None,
                               help="Exit with code 1 if score is below this (for CI/CD)")

    # Output
    watch_parser.add_argument("--output", "-o", type=str, choices=["terminal", "json"],
                               default="terminal", help="Output format")
    watch_parser.add_argument("--name", type=str, default="My Agent",
                               help="Agent name for the report")
    watch_parser.add_argument("--concurrency", type=int, default=3,
                               help="Max parallel probes (default: 3)")
    watch_parser.add_argument("--timeout", type=float, default=30.0,
                               help="Timeout per probe in seconds (default: 30)")

    # Quick inline
    watch_parser.add_argument("prompt_inline", nargs="?", type=str, default=None,
                               help="Quick inline prompt")

    # ── compare command ────────────────────────────────────────────────
    compare_parser = subparsers.add_parser("compare", help="Compare two scan reports")
    compare_parser.add_argument("report_a", type=str, help="Path to baseline scan report (JSON)")
    compare_parser.add_argument("report_b", type=str, help="Path to current scan report (JSON)")
    compare_parser.add_argument("--output", "-o", type=str, choices=["terminal", "json"],
                                 default="terminal", help="Output format")

    # ── guard command ─────────────────────────────────────────────────
    guard_parser = subparsers.add_parser("guard", help="Scan machine for AI agent security issues")
    guard_sub = guard_parser.add_subparsers(dest="guard_command")

    guard_parser.add_argument("--output", "-o", type=str, choices=["terminal", "json", "sarif"],
                              default="terminal", help="Output format (default: terminal)")
    guard_parser.add_argument("--save", type=str, default=None,
                              help="Save report to file")
    guard_parser.add_argument("--skip-runtime", action="store_true",
                              help="Skip MCP server connections (fast mode)")
    guard_parser.add_argument("--ci", action="store_true",
                              help="CI mode: exit code 1 on findings above threshold")
    guard_parser.add_argument("--fail-on", type=str, choices=["critical", "high", "medium", "low"],
                              default="high", help="Severity threshold for --ci exit code (default: high)")
    guard_parser.add_argument("--deep", action="store_true",
                              help="Enable LLM deep analysis (requires --model)")
    guard_parser.add_argument("--deep-all", action="store_true",
                              help="With --deep: probe ALL servers (default: unmatched + drift only)")
    guard_parser.add_argument("--deep-timeout", type=int, default=60,
                              help="Per-server probe timeout in seconds (default: 60)")
    guard_parser.add_argument("--model", type=str, default=None,
                              help="Model for --deep analysis")
    guard_parser.add_argument("--api-key", type=str, default=None,
                              help="API key for --deep analysis model")
    guard_parser.add_argument("--upload", action="store_true",
                              help="Upload results to AgentSeal dashboard (Pro)")
    guard_parser.add_argument("--verbose", "-v", action="store_true",
                              help="Show detailed output including connection failures")
    guard_parser.add_argument("--no-process-scan", action="store_true",
                              help="Skip running process detection")
    guard_parser.add_argument("path", nargs="?", default=None,
                              help="Scan a project directory for MCP configs")

    guard_sub.add_parser("list", help="Show discovered agents and MCP servers")
    watch_parser = guard_sub.add_parser("watch", help="Continuous monitoring — scan every N minutes")
    watch_parser.add_argument("--interval", type=int, default=30,
                              help="Scan interval in minutes (default: 30)")
    watch_parser.add_argument("--upload", action="store_true",
                              help="Upload each scan to dashboard")

    args = parser.parse_args()

    if args.command == "login":
        _run_login(args)
    elif args.command == "activate":
        _run_activate(args)
    elif args.command == "scan":
        asyncio.run(_run_scan(args))
    elif args.command == "compare":
        _run_compare(args)
    elif args.command == "watch":
        asyncio.run(_run_watch(args))
    elif args.command == "guard":
        asyncio.run(_run_guard(args))
    else:
        _print_banner()
        parser.print_help()
        sys.exit(0)


def _resolve_prompt(args, require_url: bool = True) -> str | None:
    """Resolve system prompt from CLI args. Shared by scan and watch commands."""
    system_prompt = None

    if getattr(args, "prompt", None):
        system_prompt = args.prompt
    elif getattr(args, "prompt_inline", None):
        system_prompt = args.prompt_inline
    elif getattr(args, "file", None):
        path = Path(args.file)
        if not path.exists():
            print(f"Error: File not found: {args.file}", file=sys.stderr)
            sys.exit(1)
        system_prompt = path.read_text().strip()
    elif getattr(args, "claude_desktop", False):
        system_prompt, model_hint = _detect_claude_desktop()
        if not args.model and model_hint:
            args.model = model_hint
    elif getattr(args, "cursor", False):
        system_prompt = _detect_cursor()
    elif require_url and not getattr(args, "url", None):
        print("Error: Provide --prompt, --file, or --url", file=sys.stderr)
        sys.exit(1)

    return system_prompt


async def _run_scan(args):
    from agentseal.validator import AgentValidator, ScanReport

    # ── Resolve system prompt ────────────────────────────────────────
    system_prompt = _resolve_prompt(args)

    if system_prompt is None and not getattr(args, "url", None):
        if getattr(args, "claude_desktop", False) or getattr(args, "cursor", False):
            pass  # Already handled
        else:
            print("Error: Provide --prompt, --file, --url, --claude-desktop, or --cursor", file=sys.stderr)
            sys.exit(1)

    # ── Build the agent function ─────────────────────────────────────
    if args.url:
        # HTTP endpoint mode
        validator = AgentValidator.from_endpoint(
            url=args.url,
            ground_truth_prompt=system_prompt,
            agent_name=args.name,
            message_field=args.message_field,
            response_field=args.response_field,
            concurrency=args.concurrency,
            timeout_per_probe=args.timeout,
            verbose=args.verbose,
            adaptive=args.adaptive,
            semantic=args.semantic,
            mcp=args.mcp,
            rag=args.rag,
        )
    elif system_prompt and args.model:
        # Direct model testing
        agent_fn = _build_agent_fn(
            model=args.model,
            system_prompt=system_prompt,
            api_key=args.api_key,
            ollama_url=args.ollama_url,
            litellm_url=args.litellm_url,
        )
        validator = AgentValidator(
            agent_fn=agent_fn,
            ground_truth_prompt=system_prompt,
            agent_name=args.name,
            concurrency=args.concurrency,
            timeout_per_probe=args.timeout,
            verbose=args.verbose,
            on_progress=_cli_progress if args.output == "terminal" else None,
            adaptive=args.adaptive,
            semantic=args.semantic,
            mcp=args.mcp,
            rag=args.rag,
        )
    else:
        print("Error: --model is required when testing a prompt directly", file=sys.stderr)
        sys.exit(1)

    # ── Run the scan ─────────────────────────────────────────────────
    if args.output == "terminal":
        _print_banner(show_tagline=False)
        print(f"\033[90m   ─────────────────────────────────────────\033[0m")
        if system_prompt:
            preview = system_prompt[:55].replace("\n", " ")
            suffix = "\033[90m...\033[0m" if len(system_prompt) > 55 else ""
            print(f"   \033[38;5;75mTarget\033[0m   \033[90m│\033[0m  {preview}{suffix}")
        elif args.url:
            print(f"   \033[38;5;75mTarget\033[0m   \033[90m│\033[0m  {args.url}")
        print(f"   \033[38;5;75mModel\033[0m    \033[90m│\033[0m  {args.model or 'HTTP endpoint'}")
        inj_count = 35
        if args.mcp:
            inj_count += 26
        if args.rag:
            inj_count += 20
        total_count = 37 + inj_count
        probe_text = f"\033[38;5;51m{total_count}\033[0m (37 extraction + {inj_count} injection)"
        if args.mcp:
            probe_text += " + 26 mcp"
        if args.rag:
            probe_text += " + 20 rag"
        if args.adaptive:
            probe_text += " + mutations"
        if args.semantic:
            probe_text += " + semantic"
        if args.genome:
            probe_text += " + genome"
        print(f"   \033[38;5;75mProbes\033[0m   \033[90m│\033[0m  {probe_text}")
        print(f"\033[90m   ─────────────────────────────────────────\033[0m")
        print()

    report = await validator.run()

    # ── Genome scan (if --genome) ─────────────────────────────────────
    genome_report = None
    if args.genome:
        from agentseal.genome import run_genome_scan
        genome_report = await run_genome_scan(
            agent_fn=validator.agent_fn,
            scan_report=report,
            ground_truth=system_prompt,
            max_probes_per_category=args.genome_probes,
            max_categories=args.genome_categories,
            concurrency=args.concurrency,
            timeout=args.timeout,
            on_progress=_cli_progress if args.output == "terminal" else None,
            semantic=args.semantic,
        )
        report.genome_report = genome_report.to_dict()

    # ── Output ───────────────────────────────────────────────────────
    if args.output == "terminal":
        report.print()
        if genome_report:
            genome_report.print()
    elif args.output == "json":
        print(report.to_json())
    elif args.output == "sarif":
        print(json.dumps(_to_sarif(report), indent=2))

    if args.save:
        Path(args.save).write_text(report.to_json())
        if args.output == "terminal":
            print(f"  Report saved to: {args.save}")

    # ── PDF report (Pro feature) ─────────────────────────────────────
    if args.report:
        if _pro_gate("PDF Report"):
            from agentseal.report import generate_pdf
            try:
                pdf_path = generate_pdf(report, output_path=args.report)
                if args.output == "terminal":
                    print(f"\n  \033[38;5;75m✓ PDF report saved to: {pdf_path}\033[0m")
            except Exception as e:
                print(f"\n  \033[91m✗ PDF generation failed: {e}\033[0m", file=sys.stderr)

    # ── Upload to dashboard (Pro feature) ─────────────────────────────
    if args.upload and not _pro_gate("Dashboard Upload"):
        pass
    elif args.upload:
        from agentseal.upload import get_credentials, upload_report, compute_content_hash
        import hashlib as _hl

        try:
            api_url, api_key = get_credentials(
                api_url=args.dashboard_url,
                api_key=args.dashboard_key,
            )
            if system_prompt:
                content_hash = compute_content_hash(system_prompt)
            elif args.url:
                # Hash the endpoint URL so each endpoint gets its own stub
                content_hash = _hl.sha256(args.url.encode("utf-8")).hexdigest()
            else:
                content_hash = "0" * 64
            result = upload_report(
                report_dict=report.to_dict(),
                api_url=api_url,
                api_key=api_key,
                content_hash=content_hash,
                agent_name=args.name,
                model_used=args.model,
            )
            if args.output == "terminal":
                scan_id = result.get("id", "unknown")
                print(f"\n  \033[92m✓ Uploaded to dashboard (scan {scan_id})\033[0m")
        except Exception as e:
            print(f"\n  \033[91m✗ Upload failed: {e}\033[0m", file=sys.stderr)

    # ── CI mode ──────────────────────────────────────────────────────
    if args.min_score is not None:
        if report.trust_score < args.min_score:
            if args.output == "terminal":
                print(f"\n  \033[91m✗ Score {report.trust_score:.0f} is below minimum {args.min_score}\033[0m")
            sys.exit(1)
        else:
            if args.output == "terminal":
                print(f"\n  \033[92m✓ Score {report.trust_score:.0f} meets minimum {args.min_score}\033[0m")
            sys.exit(0)


async def _run_watch(args):
    """Run canary regression scan."""
    from agentseal.canaries import (
        baseline_key, get_baseline, store_baseline, clear_baseline,
        build_canary_probes, run_canary_scan, detect_regression, send_webhook,
    )

    # ── Resolve prompt ────────────────────────────────────────────────
    system_prompt = _resolve_prompt(args, require_url=True)

    if system_prompt is None and not getattr(args, "url", None):
        print("Error: Provide --prompt, --file, or --url", file=sys.stderr)
        sys.exit(1)

    # ── Baseline key ──────────────────────────────────────────────────
    bkey = baseline_key(system_prompt or "", args.model or "")

    # ── Reset baseline ────────────────────────────────────────────────
    if args.reset_baseline:
        removed = clear_baseline(bkey)
        if args.output == "terminal":
            if removed:
                print("  \033[92m✓ Baseline cleared\033[0m")
            else:
                print("  \033[93mNo baseline found to clear\033[0m")
        elif args.output == "json":
            print(json.dumps({"action": "reset_baseline", "cleared": removed}))
        sys.exit(0)

    # ── Build agent function ──────────────────────────────────────────
    if getattr(args, "url", None):
        from agentseal.connectors.http import build_http_chat
        agent_fn = build_http_chat(
            url=args.url,
            message_field=args.message_field,
            response_field=args.response_field,
        )
    elif system_prompt and args.model:
        agent_fn = _build_agent_fn(
            model=args.model,
            system_prompt=system_prompt,
            api_key=args.api_key,
            ollama_url=args.ollama_url,
            litellm_url=getattr(args, "litellm_url", None),
        )
    else:
        print("Error: --model is required when testing a prompt directly", file=sys.stderr)
        sys.exit(1)

    # ── Parse canary probe IDs ────────────────────────────────────────
    probe_ids = None
    if args.canary_probes:
        probe_ids = {p.strip() for p in args.canary_probes.split(",")}

    # ── Run canary scan ───────────────────────────────────────────────
    if args.output == "terminal":
        _print_banner(show_tagline=False)
        print(f"\033[90m   ─────────────────────────────────────────\033[0m")
        if system_prompt:
            preview = system_prompt[:55].replace("\n", " ")
            suffix = "\033[90m...\033[0m" if len(system_prompt) > 55 else ""
            print(f"   \033[38;5;75mTarget\033[0m   \033[90m│\033[0m  {preview}{suffix}")
        elif getattr(args, "url", None):
            print(f"   \033[38;5;75mTarget\033[0m   \033[90m│\033[0m  {args.url}")
        print(f"   \033[38;5;75mMode\033[0m     \033[90m│\033[0m  \033[38;5;51mCanary Watch\033[0m (regression detection)")
        n_probes = len(probe_ids) if probe_ids else 5
        print(f"   \033[38;5;75mProbes\033[0m   \033[90m│\033[0m  \033[38;5;51m{n_probes}\033[0m canary probes")
        print(f"\033[90m   ─────────────────────────────────────────\033[0m")
        print()

    result = await run_canary_scan(
        agent_fn=agent_fn,
        ground_truth=system_prompt,
        probe_ids=probe_ids,
        concurrency=args.concurrency,
        timeout=args.timeout,
        on_progress=_cli_progress if args.output == "terminal" else None,
    )

    # ── Set baseline ──────────────────────────────────────────────────
    if args.set_baseline:
        path = store_baseline(bkey, result.to_dict())
        if args.output == "terminal":
            _print_canary_result(result)
            print(f"  \033[92m✓ Baseline stored at {path}\033[0m")
            print()
        elif args.output == "json":
            out = result.to_dict()
            out["action"] = "set_baseline"
            out["baseline_path"] = str(path)
            print(json.dumps(out, indent=2))
        sys.exit(0)

    # ── Load or create baseline ───────────────────────────────────────
    baseline = get_baseline(bkey)
    if baseline is None:
        path = store_baseline(bkey, result.to_dict())
        if args.output == "terminal":
            _print_canary_result(result)
            print(f"  \033[93mNo baseline found — storing current result as baseline\033[0m")
            print(f"  \033[90m  Saved to {path}\033[0m")
            print()
        elif args.output == "json":
            out = result.to_dict()
            out["regression"] = None
            out["baseline_created"] = True
            print(json.dumps(out, indent=2))

        if args.min_score is not None and result.trust_score < args.min_score:
            sys.exit(1)
        sys.exit(0)

    # ── Detect regression ─────────────────────────────────────────────
    alert = detect_regression(baseline, result.to_dict(), args.score_threshold)

    if args.output == "terminal":
        _print_canary_result(result)
        if alert:
            _print_regression_alert(alert)
        else:
            print(f"  \033[92m✓ No regression detected\033[0m")
            print(f"  \033[90m  Baseline score: {baseline.get('trust_score', 0):.0f}  "
                  f"Current: {result.trust_score:.0f}\033[0m")
            print()
    elif args.output == "json":
        out = result.to_dict()
        out["regression"] = alert.to_dict() if alert else None
        out["baseline_score"] = baseline.get("trust_score", 0)
        print(json.dumps(out, indent=2))

    # ── Webhook ───────────────────────────────────────────────────────
    if alert and args.webhook_url:
        success = send_webhook(args.webhook_url, alert, result)
        if args.output == "terminal":
            if success:
                print(f"  \033[92m✓ Webhook sent to {args.webhook_url}\033[0m")
            else:
                print(f"  \033[91m✗ Webhook failed for {args.webhook_url}\033[0m")

    # ── CI mode ───────────────────────────────────────────────────────
    if args.min_score is not None:
        if result.trust_score < args.min_score:
            if args.output == "terminal":
                print(f"\n  \033[91m✗ Score {result.trust_score:.0f} is below minimum {args.min_score}\033[0m")
            sys.exit(1)
        else:
            if args.output == "terminal":
                print(f"\n  \033[92m✓ Score {result.trust_score:.0f} meets minimum {args.min_score}\033[0m")

    # Exit code 1 on regression
    if alert:
        sys.exit(1)
    sys.exit(0)


def _print_canary_result(result):
    """Print canary scan result to terminal."""
    from agentseal.schemas import TrustLevel
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"

    score = result.trust_score
    if score >= 85:
        score_color = GREEN
    elif score >= 70:
        score_color = "\033[96m"
    elif score >= 50:
        score_color = YELLOW
    else:
        score_color = RED

    level = TrustLevel.from_score(score)

    print()
    print(f"{BLUE}{'═' * 60}{RESET}")
    print(f"{BLUE}  AgentSeal Canary Watch{RESET}")
    print(f"{BLUE}{'═' * 60}{RESET}")
    print(f"  Scan ID:  {DIM}{result.scan_id}{RESET}")
    print(f"  Duration: {DIM}{result.duration_seconds:.1f}s{RESET}")
    print()
    print(f"  {BOLD}TRUST SCORE:  {score_color}{score:.0f} / 100  ({level.value.upper()}){RESET}")
    print()
    print(f"  Probes: {GREEN}{result.probes_blocked} blocked{RESET}  "
          f"{RED}{result.probes_leaked} leaked{RESET}  "
          f"{YELLOW}{result.probes_partial} partial{RESET}  "
          f"{DIM}{result.probes_error} error{RESET}")
    print()


def _print_regression_alert(alert):
    """Print regression alert to terminal."""
    RED = "\033[91m"
    GREEN = "\033[92m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"

    print(f"  {RED}{BOLD}⚠ REGRESSION DETECTED{RESET}")
    print(f"  {RED}{alert.message}{RESET}")
    print()
    print(f"  Baseline: {DIM}{alert.baseline_score:.0f}{RESET}  →  Current: {DIM}{alert.current_score:.0f}{RESET}  "
          f"({RED}{alert.score_delta:+.1f}{RESET})")
    print()

    if alert.regressed_probes:
        print(f"  {RED}{BOLD}Regressed probes:{RESET}")
        for p in alert.regressed_probes:
            print(f"    {RED}↓{RESET} {p['probe_id']:25s}  {p['was']:8s} → {p['now']}")
        print()

    if alert.improved_probes:
        print(f"  {GREEN}{BOLD}Improved probes:{RESET}")
        for p in alert.improved_probes:
            print(f"    {GREEN}↑{RESET} {p['probe_id']:25s}  {p['was']:8s} → {p['now']}")
        print()


def _run_activate(args):
    """Activate a Pro license key."""
    _print_banner(show_tagline=False)

    key = args.key
    if not key:
        key = input("  Enter your license key: ").strip()

    if not key:
        print("  \033[91mNo license key provided.\033[0m")
        sys.exit(1)

    # Save license
    license_dir = Path.home() / ".agentseal"
    license_dir.mkdir(parents=True, exist_ok=True)
    license_path = license_dir / "license.json"
    license_path.write_text(json.dumps({"key": key}, indent=2))
    license_path.chmod(0o600)

    print(f"  \033[92m✓ License activated successfully\033[0m")
    print(f"  \033[90m  Saved to {license_path}\033[0m")
    print()
    print(f"  \033[0m  Pro features unlocked:")
    print(f"  \033[0m    - PDF security assessment reports  (--report)")
    print(f"  \033[0m    - Dashboard & historical tracking  (--upload)")
    print()


def _run_login(args):
    """Store dashboard credentials in ~/.agentseal/config.json."""
    from agentseal.upload import load_config, save_config, DEFAULT_API_URL

    config = load_config()

    current_url = config.get("api_url", DEFAULT_API_URL)
    api_url = args.api_url or input(f"  Dashboard API URL [{current_url}]: ").strip()
    api_key = args.api_key or input("  Dashboard API key: ").strip()

    # Keep existing/default value if user just presses Enter
    config["api_url"] = api_url if api_url else current_url
    if api_key:
        config["api_key"] = api_key

    save_config(config)
    print(f"\n  \033[92m✓ Credentials saved to ~/.agentseal/config.json\033[0m")


def _run_compare(args):
    """Compare two scan report JSON files."""
    from agentseal.compare import load_report, compare_reports, print_comparison

    a = load_report(args.report_a)
    b = load_report(args.report_b)
    diff = compare_reports(a, b)

    if args.output == "json":
        print(json.dumps(diff, indent=2))
    else:
        _print_banner(show_tagline=False)
        print_comparison(diff)


def _build_agent_fn(model: str, system_prompt: str, api_key: str = None,
                    ollama_url: str = None, litellm_url: str = None):
    """Build an async chat function for the specified model."""
    from agentseal.connectors import build_agent_fn
    return build_agent_fn(
        model=model,
        system_prompt=system_prompt,
        api_key=api_key,
        ollama_url=ollama_url,
        litellm_url=litellm_url,
    )


def _detect_claude_desktop() -> tuple[str | None, str | None]:
    """Auto-detect Claude Desktop config and extract info."""
    import platform
    if platform.system() == "Darwin":
        config_path = Path.home() / "Library/Application Support/Claude/claude_desktop_config.json"
    elif platform.system() == "Windows":
        config_path = Path(os.environ.get("APPDATA", "")) / "Claude/claude_desktop_config.json"
    else:
        config_path = Path.home() / ".config/claude/claude_desktop_config.json"

    if not config_path.exists():
        print(f"  Claude Desktop config not found at: {config_path}", file=sys.stderr)
        sys.exit(1)

    config = json.loads(config_path.read_text())
    mcp_servers = config.get("mcpServers", {})

    if mcp_servers:
        print(f"  Found {len(mcp_servers)} MCP server(s): {', '.join(mcp_servers.keys())}")

    # Claude Desktop doesn't expose the system prompt in config
    # We report what we find (MCP servers, permissions) but need a prompt to scan
    print("  Note: Claude Desktop config contains MCP servers but not the system prompt.")
    print("  Provide the prompt separately with --prompt or --file.")
    return None, None


def _detect_cursor() -> str | None:
    """Auto-detect Cursor IDE .cursorrules."""
    # Check common locations
    candidates = [
        Path.cwd() / ".cursorrules",
        Path.home() / ".cursor" / ".cursorrules",
    ]
    for path in candidates:
        if path.exists():
            content = path.read_text().strip()
            if content:
                print(f"  Found .cursorrules at: {path}")
                return content

    print("  No .cursorrules found in current directory or ~/.cursor/", file=sys.stderr)
    sys.exit(1)


def _cli_progress(phase: str, completed: int, total: int):
    """Simple terminal progress indicator."""
    bar_len = 30
    filled = int(completed / total * bar_len) if total > 0 else 0
    bar = "█" * filled + "░" * (bar_len - filled)
    print(f"\r  {phase:12s} [{bar}] {completed}/{total}", end="", flush=True)
    if completed == total:
        print()


def _to_sarif(report) -> dict:
    """Convert report to SARIF format for GitHub Security tab integration."""
    results = []
    for r in report.results:
        if r.verdict.value in ("leaked", "partial"):
            results.append({
                "ruleId": r.probe_id,
                "level": "error" if r.verdict.value == "leaked" else "warning",
                "message": {"text": f"{r.technique}: {r.reasoning}"},
                "properties": {
                    "category": r.category,
                    "severity": r.severity.value,
                    "confidence": r.confidence,
                },
            })
    return {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {
                "driver": {
                    "name": "AgentSeal",
                    "version": "0.9.0",
                    "informationUri": "https://agentseal.org",
                }
            },
            "results": results,
        }],
    }


async def _run_guard(args):
    if getattr(args, "guard_command", None) == "list":
        _run_guard_list()
        return
    if getattr(args, "guard_command", None) == "watch":
        await _run_guard_watch(args)
        return

    if args.ci and args.output == "terminal":
        args.output = "json"

    from agentseal.guard.engine import GuardEngine
    from agentseal.guard.output.terminal import format_terminal
    from agentseal.guard.output.json_output import format_json
    from agentseal.guard.output.sarif import format_sarif

    engine = GuardEngine(
        skip_runtime=args.skip_runtime,
        deep=args.deep,
        deep_all=getattr(args, "deep_all", False),
        deep_timeout=getattr(args, "deep_timeout", 60),
        model=args.model,
        api_key=args.api_key,
        project_path=Path(args.path) if getattr(args, "path", None) else None,
        no_process_scan=getattr(args, "no_process_scan", False),
        interactive=args.output == "terminal" and not args.ci,
    )

    if args.output == "terminal":
        _print_banner(show_tagline=False)

    result = await engine.run()

    if args.output == "terminal":
        output = format_terminal(result)
    elif args.output == "json":
        output = format_json(result)
    else:
        import json as json_mod
        output = json_mod.dumps(format_sarif(result), indent=2)

    print(output)

    if args.save:
        Path(args.save).write_text(output)

    if args.upload:
        scan_path = str(Path(args.path).resolve()) if getattr(args, "path", None) else None
        _upload_guard_report(result, scan_path)

    if args.ci:
        sys.exit(engine.ci_exit_code(result, args.fail_on))


def _build_delta_data(
    prev: set[str],
    current: set[str],
    score_before: float | None,
    score_after: float,
) -> dict | None:
    if score_before is None:
        return None

    def _parse_signature(sig: str) -> dict:
        code, source, title = sig.split(":", 2)
        return {"code": code, "server_name": Path(source).name if "/" in source else source, "title": title}

    new_sigs = current - prev
    resolved_sigs = prev - current
    return {
        "new": [_parse_signature(s) for s in sorted(new_sigs)],
        "resolved": [_parse_signature(s) for s in sorted(resolved_sigs)],
        "score_before": score_before,
        "score_after": score_after,
    }


def _upload_guard_report(result, scan_path: str | None = None, delta_data: dict | None = None):
    import hashlib
    import platform

    import httpx

    from agentseal import __version__

    config_path = Path.home() / ".agentseal" / "config.json"
    if not config_path.exists():
        print("\033[93m⚠ Not logged in. Run 'agentseal login' first.\033[0m", file=sys.stderr)
        return

    config = json.loads(config_path.read_text())
    token = config.get("token")
    base_url = config.get("base_url", "https://agentseal.org")

    if not token:
        print("\033[93m⚠ No auth token. Run 'agentseal login' first.\033[0m", file=sys.stderr)
        return

    hostname = platform.node()
    machine_id = hashlib.sha256(
        f"{hostname}-{platform.system()}-{platform.machine()}".encode()
    ).hexdigest()[:16]

    payload = {
        "machine_name": hostname,
        "machine_id": machine_id,
        "scan_path": scan_path,
        "report_data": result.to_report_data(),
        "cli_version": __version__,
        "delta_data": delta_data,
    }

    try:
        resp = httpx.post(
            f"{base_url}/api/v1/guard/reports",
            json=payload,
            headers={"Authorization": f"Bearer {token}"},
            timeout=30.0,
        )
        resp.raise_for_status()
        data = resp.json()
        print(f"\033[92m✓ Report uploaded: {data.get('id', 'ok')}\033[0m", file=sys.stderr)
    except Exception as e:
        print(f"\033[91m✗ Upload failed: {e}\033[0m", file=sys.stderr)


async def _run_guard_watch(args):
    import asyncio
    from agentseal.guard.engine import GuardEngine
    from agentseal.guard.output.terminal import format_terminal

    interval = getattr(args, "interval", 30)
    upload = getattr(args, "upload", False)

    print(f"\033[1m\033[96mAgentSeal Guard Watch\033[0m", file=sys.stderr)
    print(f"\033[90mScanning every {interval} minutes. Press Ctrl+C to stop.\033[0m\n", file=sys.stderr)

    prev_findings: set[str] = set()
    prev_score: float | None = None
    scan_count = 0

    while True:
        scan_count += 1
        now = datetime.now().strftime("%H:%M:%S")
        print(f"\033[90m[{now}] Scan #{scan_count}...\033[0m", file=sys.stderr)

        try:
            engine = GuardEngine(skip_runtime=True, no_process_scan=False)
            result = await engine.run()
        except Exception as e:
            print(f"\033[91m  Scan failed: {e}\033[0m", file=sys.stderr)
            await asyncio.sleep(interval * 60)
            continue

        current_findings = {f"{f.code}:{f.source or f.server_name}:{f.title}" for f in result.findings}

        new_findings = current_findings - prev_findings
        resolved = prev_findings - current_findings

        if scan_count == 1:
            print(format_terminal(result))
        else:
            counts = result.severity_counts
            total = sum(counts.values())
            print(
                f"\033[90m[{now}]\033[0m "
                f"Score: \033[1m{int(result.machine_score)}/100\033[0m · "
                f"Findings: {total} · "
                f"Servers: {result.servers_scanned}",
                file=sys.stderr,
            )
            if new_findings:
                print(f"  \033[91m+{len(new_findings)} new finding{'s' if len(new_findings) != 1 else ''}:\033[0m", file=sys.stderr)
                for nf in sorted(new_findings)[:5]:
                    code, rest = nf.split(":", 1)
                    title = rest.rsplit(":", 1)[-1] if ":" in rest else rest
                    source = rest.rsplit(":", 1)[0] if ":" in rest else ""
                    label = Path(source).name if "/" in source else source
                    print(f"    \033[91m{code}\033[0m {title} ({label})", file=sys.stderr)
            if resolved:
                print(f"  \033[92m-{len(resolved)} resolved:\033[0m", file=sys.stderr)
                for rf in sorted(resolved)[:5]:
                    code, rest = rf.split(":", 1)
                    title = rest.rsplit(":", 1)[-1] if ":" in rest else rest
                    source = rest.rsplit(":", 1)[0] if ":" in rest else ""
                    label = Path(source).name if "/" in source else source
                    print(f"    \033[92m{code}\033[0m {title} ({label})", file=sys.stderr)
            if not new_findings and not resolved:
                print(f"  \033[90mNo changes\033[0m", file=sys.stderr)

        if upload:
            delta = _build_delta_data(prev_findings, current_findings, prev_score, result.machine_score)
            _upload_guard_report(result, scan_path=None, delta_data=delta)

        prev_findings = current_findings
        prev_score = result.machine_score

        try:
            await asyncio.sleep(interval * 60)
        except (KeyboardInterrupt, asyncio.CancelledError):
            print(f"\n\033[90mWatch stopped after {scan_count} scans.\033[0m", file=sys.stderr)
            break


def _run_guard_list():
    from agentseal.guard.collectors.base import collect_all

    agents = collect_all()

    if not agents:
        print("No agents or MCP servers discovered.")
        return

    for agent in agents:
        print(f"\n{agent.name}  [{agent.agent_type}]")
        if agent.mcp_servers:
            for server in agent.mcp_servers:
                print(f"  MCP: {server.name}  ({server.command})")
        else:
            print("  (no MCP servers)")
        if agent.skills:
            for skill in agent.skills:
                print(f"  Skill: {skill.path}  [{skill.platform}/{skill.format}]")


if __name__ == "__main__":
    main()
