"""Tests for history row writes on save (RFC-0008 Step 6.1)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.domain.mixins import SubmittableMixin, VersionedMixin
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData, func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine


class Invoice(BaseDocType, VersionedMixin, SubmittableMixin):
    """Versioned DocType used to verify history writes on save."""

    title: str = Field(description="Invoice title")


class Todo(BaseDocType):
    """Non-versioned DocType for regression checks."""

    title: str = Field(description="Task title")


@pytest.fixture
async def versioned_repo_with_history(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> tuple[GenericRepository[Invoice], object, object]:
    """Create versioned main + history tables and repository."""
    mapper = SchemaMapper()
    tables = mapper.create_versioned_tables(
        Invoice,
        clean_tables,
        {"compliance": {"versioning_enabled": True}},
    )
    main_table, history_table = tables[0], tables[1]

    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    return GenericRepository(Invoice, main_table), main_table, history_table


@pytest.fixture
async def plain_repo(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> tuple[GenericRepository[Todo], object]:
    """Create repository for non-versioned DocType."""
    mapper = SchemaMapper()
    main_table = mapper.create_table(Todo, clean_tables)

    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    return GenericRepository(Todo, main_table), main_table


async def _history_versions(
    session: AsyncSession, history_table: object, doc_id: object
) -> list[int]:
    """Return ordered version numbers for a document."""
    result = await session.execute(
        select(history_table)
        .where(history_table.c.id == doc_id)
        .order_by(history_table.c._version_no.asc())
    )
    return [row._mapping["_version_no"] for row in result.fetchall()]


class TestRepositoryVersioningWrites:
    """Versioned save behavior for main + history tables."""

    @pytest.mark.asyncio
    async def test_insert_writes_main_and_first_history_version(
        self,
        versioned_repo_with_history: tuple[GenericRepository[Invoice], object, object],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, main_table, history_table = versioned_repo_with_history
        invoice = Invoice(title="first")

        await repo.save(db_session, invoice)

        main_count = await db_session.scalar(
            select(func.count()).select_from(main_table)
        )
        assert main_count == 1

        versions = await _history_versions(db_session, history_table, invoice.id)
        assert versions == [1]

    @pytest.mark.asyncio
    async def test_update_writes_second_history_version(
        self,
        versioned_repo_with_history: tuple[GenericRepository[Invoice], object, object],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, _main_table, history_table = versioned_repo_with_history
        invoice = Invoice(title="v1")
        await repo.save(db_session, invoice)

        invoice.title = "v2"
        await repo.save(db_session, invoice)

        versions = await _history_versions(db_session, history_table, invoice.id)
        assert versions == [1, 2]

    @pytest.mark.asyncio
    async def test_three_saves_increment_history_versions_monotonically(
        self,
        versioned_repo_with_history: tuple[GenericRepository[Invoice], object, object],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, _main_table, history_table = versioned_repo_with_history
        invoice = Invoice(title="v1")

        await repo.save(db_session, invoice)
        invoice.title = "v2"
        await repo.save(db_session, invoice)
        invoice.title = "v3"
        await repo.save(db_session, invoice)

        versions = await _history_versions(db_session, history_table, invoice.id)
        assert versions == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_valid_window_updates_previous_row_valid_to(
        self,
        versioned_repo_with_history: tuple[GenericRepository[Invoice], object, object],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, _main_table, history_table = versioned_repo_with_history
        invoice = Invoice(title="v1")

        await repo.save(db_session, invoice)
        invoice.title = "v2"
        await repo.save(db_session, invoice)

        result = await db_session.execute(
            select(history_table)
            .where(history_table.c.id == invoice.id)
            .order_by(history_table.c._version_no.asc())
        )
        rows = result.fetchall()
        assert len(rows) == 2

        first = rows[0]._mapping
        second = rows[1]._mapping

        assert first["_valid_from"] is not None
        assert first["_valid_to"] is not None
        assert second["_valid_from"] is not None
        assert second["_valid_to"] is None
        assert first["_valid_to"] == second["_valid_from"]

    @pytest.mark.asyncio
    async def test_non_versioned_doctype_writes_only_main_table(
        self,
        plain_repo: tuple[GenericRepository[Todo], object],
        db_session: AsyncSession,
        clean_tables: MetaData,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, main_table = plain_repo
        todo = Todo(title="plain")

        await repo.save(db_session, todo)

        main_count = await db_session.scalar(
            select(func.count()).select_from(main_table)
        )
        assert main_count == 1
        assert "todo_history" not in clean_tables.tables

    @pytest.mark.asyncio
    async def test_versioning_disabled_writes_only_main_table(
        self,
        versioned_repo_with_history: tuple[GenericRepository[Invoice], object, object],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "false")

        repo, main_table, history_table = versioned_repo_with_history
        invoice = Invoice(title="disabled")

        await repo.save(db_session, invoice)

        main_count = await db_session.scalar(
            select(func.count()).select_from(main_table)
        )
        history_count = await db_session.scalar(
            select(func.count()).select_from(history_table)
        )

        assert main_count == 1
        assert history_count == 0

    @pytest.mark.asyncio
    async def test_history_write_failure_rolls_back_main_insert(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        main_db = tmp_path / "atomicity_step_6_1.db"
        main_url = f"sqlite+aiosqlite:///{main_db}"
        engine = create_async_engine(main_url, echo=False)

        try:
            metadata = MetaData()
            mapper = SchemaMapper()
            tables = mapper.create_versioned_tables(
                Invoice,
                metadata,
                {"compliance": {"versioning_enabled": True}},
            )
            main_table = tables[0]

            async with engine.begin() as conn:
                await conn.run_sync(metadata.create_all)

            session_maker = async_sessionmaker(
                engine,
                class_=AsyncSession,
                expire_on_commit=False,
            )

            async with session_maker() as session:
                await session.begin()
                repo = GenericRepository(Invoice, main_table)
                repo._write_history_snapshot_on_save = AsyncMock(
                    side_effect=RuntimeError("simulated history write failure")
                )

                with pytest.raises(RuntimeError):
                    await repo.save(session, Invoice(title="atomic"))

                await session.rollback()

            async with session_maker() as verify_session:
                main_count = await verify_session.scalar(
                    select(func.count()).select_from(main_table)
                )
                assert main_count == 0
        finally:
            await engine.dispose()

    @pytest.mark.asyncio
    async def test_history_write_uses_audit_db_when_configured(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        main_db = tmp_path / "main_step_6_1.db"
        audit_db = tmp_path / "audit_step_6_1.db"

        main_url = f"sqlite+aiosqlite:///{main_db}"
        audit_url = f"sqlite+aiosqlite:///{audit_db}"

        main_engine = create_async_engine(main_url, echo=False)
        audit_engine = create_async_engine(audit_url, echo=False)

        try:
            metadata = MetaData()
            mapper = SchemaMapper()
            tables = mapper.create_versioned_tables(
                Invoice,
                metadata,
                {
                    "compliance": {
                        "versioning_enabled": True,
                        "audit_db_url": audit_url,
                    }
                },
            )
            main_table, history_table = tables[0], tables[1]

            async with main_engine.begin() as conn:
                await conn.run_sync(metadata.create_all)
            async with audit_engine.begin() as conn:
                await conn.run_sync(metadata.create_all)

            session_maker = async_sessionmaker(
                main_engine,
                class_=AsyncSession,
                expire_on_commit=False,
            )

            async with session_maker() as session, session.begin():
                repo = GenericRepository(Invoice, main_table)
                await repo.save(session, Invoice(title="route to audit db"))

            async with main_engine.connect() as conn:
                main_count = (
                    await conn.execute(select(func.count()).select_from(main_table))
                ).scalar_one()
                main_history_count = (
                    await conn.execute(select(func.count()).select_from(history_table))
                ).scalar_one()

            async with audit_engine.connect() as conn:
                audit_history_count = (
                    await conn.execute(select(func.count()).select_from(history_table))
                ).scalar_one()

            assert main_count == 1
            assert main_history_count == 0
            assert audit_history_count == 1
        finally:
            await main_engine.dispose()
            await audit_engine.dispose()
