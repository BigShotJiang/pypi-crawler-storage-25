"""Advanced tests for GenericRepository.

Covers edge cases, error handling branches, and bulk operations.
"""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.exceptions import (
    DatabaseError,
    DuplicateNameError,
    IntegrityError,
    RepositoryError,
)
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from sqlalchemy import Column, MetaData, String, Table
from sqlalchemy.exc import IntegrityError as SAIntegrityError
from sqlalchemy.exc import OperationalError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession


class AdvancedTodo(BaseDocType):
    """Test DocType for advanced repository tests."""

    title: str = Field(description="Task title")


@pytest.fixture
def advanced_table() -> Table:
    """Create AdvancedTodo table for testing."""
    metadata = MetaData()
    return Table(
        "tab_advanced_todo",
        metadata,
        Column("id", String, primary_key=True),
        Column("name", String, unique=True),
        Column("title", String),
        Column("owner", String),
        Column("modified_by", String),
        Column("deleted_at", String, nullable=True),
        Column("_version", String, nullable=True),
    )


@pytest.fixture
def repo(advanced_table: Table) -> GenericRepository[AdvancedTodo]:
    """Create repository instance."""
    return GenericRepository(model=AdvancedTodo, table=advanced_table)


@pytest.fixture
def mock_session() -> AsyncMock:
    """Create a mock AsyncSession."""
    session = AsyncMock(spec=AsyncSession)
    session.execute = AsyncMock()
    session.flush = AsyncMock()
    return session


class TestBulkOperations:
    """Tests for bulk_save and _bulk_insert."""

    @pytest.mark.asyncio
    async def test_bulk_save_empty(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """bulk_save should return empty list when given empty list."""
        assert await repo.bulk_save(mock_session, []) == []

    @pytest.mark.asyncio
    async def test_bulk_save_mixed_entities(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """bulk_save should separate new and existing entities."""
        new_doc = AdvancedTodo(title="New")
        existing_doc = AdvancedTodo(title="Existing", name="EX-1")

        # Mock _entity_exists: first returns False (new), second returns True (existing)
        with (
            patch.object(repo, "_entity_exists", side_effect=[False, True]),
            patch.object(
                repo, "_bulk_insert", new_callable=AsyncMock
            ) as mock_bulk_insert,
            patch.object(repo, "save", new_callable=AsyncMock) as mock_save,
        ):
            mock_bulk_insert.return_value = [new_doc]
            mock_save.return_value = existing_doc

            result = await repo.bulk_save(mock_session, [new_doc, existing_doc])

            assert len(result) == 2
            mock_bulk_insert.assert_called_once_with(mock_session, [new_doc])
            mock_save.assert_called_once_with(mock_session, existing_doc)


class TestInsertErrorHandling:
    """Tests for exception translation during _insert."""

    @pytest.mark.asyncio
    async def test_insert_integrity_error_other(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate non-unique SAIntegrityError to domain IntegrityError."""
        doc = AdvancedTodo(title="Test")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=False)),  # exists check
            SAIntegrityError(
                "INSERT", {}, Exception("Foreign key violation")
            ),  # insert
        ]
        with pytest.raises(IntegrityError):
            await repo.save(mock_session, doc)

    @pytest.mark.asyncio
    async def test_insert_operational_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate OperationalError to DatabaseError."""
        doc = AdvancedTodo(title="Test")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=False)),
            OperationalError("INSERT", {}, Exception("DB Down")),
        ]
        with pytest.raises(DatabaseError):
            await repo.save(mock_session, doc)

    @pytest.mark.asyncio
    async def test_insert_sqlalchemy_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate generic SQLAlchemyError to RepositoryError."""
        doc = AdvancedTodo(title="Test")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=False)),
            SQLAlchemyError("Unknown DB error"),
        ]
        with pytest.raises(RepositoryError):
            await repo.save(mock_session, doc)


class TestBulkInsertErrorHandling:
    """Tests for exception translation during _bulk_insert."""

    @pytest.mark.asyncio
    async def test_bulk_insert_duplicate_name(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate UNIQUE constraint error to DuplicateNameError."""
        docs = [AdvancedTodo(title="Test 1", name="DOC-1")]
        mock_session.execute.side_effect = SAIntegrityError(
            "INSERT", {}, Exception("UNIQUE constraint failed")
        )
        with pytest.raises(DuplicateNameError):
            await repo._bulk_insert(mock_session, docs)

    @pytest.mark.asyncio
    async def test_bulk_insert_integrity_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate other integrity errors to domain IntegrityError."""
        docs = [AdvancedTodo(title="Test 1", name="DOC-1")]
        mock_session.execute.side_effect = SAIntegrityError(
            "INSERT", {}, Exception("FK violation")
        )
        with pytest.raises(IntegrityError):
            await repo._bulk_insert(mock_session, docs)

    @pytest.mark.asyncio
    async def test_bulk_insert_sqlalchemy_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate generic SQLAlchemyError to RepositoryError."""
        docs = [AdvancedTodo(title="Test 1", name="DOC-1")]
        mock_session.execute.side_effect = SQLAlchemyError("DB error")
        with pytest.raises(RepositoryError):
            await repo._bulk_insert(mock_session, docs)


class TestEmitEventFallbacks:
    """Tests for _emit_event fallback logic and exception swallowing."""

    @pytest.mark.asyncio
    async def test_emit_event_custom_type(
        self, repo: GenericRepository[AdvancedTodo]
    ) -> None:
        """Should emit a generic Event for unrecognized event types."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_bus = AsyncMock()
        repo._event_bus = mock_bus

        await repo._emit_event("custom_action", doc)

        mock_bus.publish.assert_called_once()
        args, _ = mock_bus.publish.call_args
        topic, event = args
        assert topic == "doc.custom_action"
        assert event.type == "AdvancedTodo.custom_action"

    @pytest.mark.asyncio
    async def test_emit_event_swallows_exception(
        self, repo: GenericRepository[AdvancedTodo]
    ) -> None:
        """Should log warning and not raise if event bus publish fails."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_bus = AsyncMock()
        mock_bus.publish.side_effect = Exception("Message bus down")
        repo._event_bus = mock_bus

        # Should safely complete without raising
        await repo._emit_event("create", doc)
        mock_bus.publish.assert_called_once()
