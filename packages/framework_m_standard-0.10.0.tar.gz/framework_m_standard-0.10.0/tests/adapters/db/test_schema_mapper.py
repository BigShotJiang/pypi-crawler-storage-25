"""Tests for SchemaMapper - Pydantic model to SQLAlchemy table conversion.

TDD: Tests written first, implementation to follow.
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Any
from uuid import UUID

import pytest
from framework_m import DocType, Field
from sqlalchemy import Boolean, DateTime, Float, Integer, MetaData, Numeric, String
from sqlalchemy.types import JSON
from sqlalchemy.types import UUID as SA_UUID

# =============================================================================
# Test DocTypes
# =============================================================================


class Priority(Enum):
    """Priority enum for testing."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class SimpleTodo(DocType):
    """Simple DocType for basic tests."""

    title: str = Field(description="Task title")
    is_completed: bool = False
    priority: int = 1


class FullFeaturedDoc(DocType):
    """DocType with all supported field types."""

    text_field: str
    int_field: int
    float_field: float
    bool_field: bool
    datetime_field: datetime
    decimal_field: Decimal
    uuid_field: UUID
    optional_field: str | None = None
    json_field: dict[str, Any] = Field(default_factory=dict)
    list_field: list[str] = Field(default_factory=list)


class DocWithOptionalFields(DocType):
    """DocType with optional fields for nullable tests."""

    required_field: str
    optional_str: str | None = None
    optional_int: int | None = None


class OptimisticDoc(DocType):
    """DocType with optimistic concurrency control."""

    title: str

    class Meta:
        concurrency = "optimistic"


class DocWithForeignKey(DocType):
    """DocType with foreign key reference."""

    customer_id: str = Field(
        description="Reference to Customer", json_schema_extra={"link": "Customer"}
    )


class Customer(DocType):
    """Target DocType for foreign key."""

    customer_name: str


class DocWithEnum(DocType):
    """DocType with enum field."""

    priority: Priority = Priority.MEDIUM


class DocWithUnique(DocType):
    """DocType with unique constraint on a field."""

    email: str = Field(json_schema_extra={"unique": True})


# =============================================================================
# Tests
# =============================================================================


class TestSchemaMapperImports:
    """Tests for SchemaMapper imports."""

    def test_import_schema_mapper(self) -> None:
        """SchemaMapper should be importable."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        assert SchemaMapper is not None

    def test_import_from_adapters_db(self) -> None:
        """SchemaMapper should be exported from adapters.db."""
        from framework_m_standard.adapters.db import SchemaMapper

        assert SchemaMapper is not None


class TestSchemaMapperBasics:
    """Tests for basic SchemaMapper functionality."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_init_with_field_registry(self) -> None:
        """SchemaMapper should accept custom FieldRegistry."""
        from framework_m_standard.adapters.db.field_registry import FieldRegistry

        custom_registry = FieldRegistry()
        mapper = self.mapper.__class__(field_registry=custom_registry)
        assert mapper._field_registry is custom_registry

    def test_unknown_type_fallback(self) -> None:
        """Unknown Python types should fall back to String."""
        from pydantic import ConfigDict

        class UnknownType:
            pass

        class DocWithUnknown(DocType):
            model_config = ConfigDict(arbitrary_types_allowed=True)
            field: UnknownType = Field(default=None)  # type: ignore

        result = self.mapper.create_table(DocWithUnknown, self.metadata)
        assert isinstance(result.columns["field"].type, String)

    def test_create_table_returns_table(self) -> None:
        """create_table should return a SQLAlchemy Table."""
        from sqlalchemy import Table

        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert isinstance(result, Table)

    def test_table_name_is_lowercase_class_name(self) -> None:
        """Table name should be lowercase class name."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert result.name == "simpletodo"

    def test_table_name_with_explicit_tablename(self) -> None:
        """Table name should use __tablename__ if defined."""

        class CustomNameDoc(DocType):
            __tablename__ = "custom_table"

        result = self.mapper.create_table(CustomNameDoc, self.metadata)
        assert result.name == "custom_table"

    def test_table_has_id_column_as_primary_key(self) -> None:
        """Table should have 'id' column as primary key (UUID)."""
        from sqlalchemy.types import UUID as SA_UUID

        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert "id" in result.columns
        assert result.columns["id"].primary_key
        assert isinstance(result.columns["id"].type, SA_UUID)

    def test_table_has_name_column_as_unique(self) -> None:
        """Table should have 'name' column with unique constraint."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert "name" in result.columns
        assert result.columns["name"].unique is True
        assert result.columns["name"].primary_key is False

    def test_table_includes_standard_doctype_fields(self) -> None:
        """Table should include standard BaseDocType fields."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        # Standard fields from BaseDocType
        assert "id" in result.columns  # PK
        assert "name" in result.columns  # Unique
        assert "owner" in result.columns
        assert "modified" in result.columns
        assert "modified_by" in result.columns

    def test_table_has_automatic_indexes(self) -> None:
        """Table should have automatic indexes for owner, creation, and modified."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        index_names = [idx.name for idx in result.indexes]
        assert f"ix_{result.name}_owner" in index_names
        assert f"ix_{result.name}_creation" in index_names
        assert f"ix_{result.name}_modified" in index_names

        # Composite indexes
        assert f"ix_{result.name}_owner_modified" in index_names
        assert f"ix_{result.name}_owner_creation" in index_names


class TestSchemaMapperFieldTypes:
    """Tests for field type mapping."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_str_field_maps_to_string(self) -> None:
        """str field should map to String column."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert isinstance(result.columns["title"].type, String)

    def test_int_field_maps_to_integer(self) -> None:
        """int field should map to Integer column."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert isinstance(result.columns["priority"].type, Integer)

    def test_bool_field_maps_to_boolean(self) -> None:
        """bool field should map to Boolean column."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert isinstance(result.columns["is_completed"].type, Boolean)

    def test_full_featured_doc_maps_all_types(self) -> None:
        """All field types should be mapped correctly."""
        result = self.mapper.create_table(FullFeaturedDoc, self.metadata)

        assert isinstance(result.columns["text_field"].type, String)
        assert isinstance(result.columns["int_field"].type, Integer)
        assert isinstance(result.columns["float_field"].type, Float)
        assert isinstance(result.columns["bool_field"].type, Boolean)
        assert isinstance(result.columns["datetime_field"].type, DateTime)
        assert isinstance(result.columns["decimal_field"].type, Numeric)
        assert isinstance(result.columns["uuid_field"].type, SA_UUID)
        assert isinstance(result.columns["json_field"].type, JSON)
        assert isinstance(result.columns["list_field"].type, JSON)


class TestSchemaMapperNullableFields:
    """Tests for optional/nullable field handling."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_required_field_is_not_nullable(self) -> None:
        """Required fields should not be nullable."""
        result = self.mapper.create_table(DocWithOptionalFields, self.metadata)

        assert result.columns["required_field"].nullable is False

    def test_optional_field_is_nullable(self) -> None:
        """Optional fields (T | None) should be nullable."""
        result = self.mapper.create_table(DocWithOptionalFields, self.metadata)

        assert result.columns["optional_str"].nullable is True
        assert result.columns["optional_int"].nullable is True


class TestSchemaMapperOptimisticConcurrency:
    """Tests for optimistic concurrency control."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_occ_doc_has_version_column(self) -> None:
        """DocType with concurrency='optimistic' should have _version column."""
        result = self.mapper.create_table(OptimisticDoc, self.metadata)

        assert "_version" in result.columns
        assert isinstance(result.columns["_version"].type, Integer)

    def test_regular_doc_has_no_version_column(self) -> None:
        """Regular DocType should not have _version column."""
        result = self.mapper.create_table(SimpleTodo, self.metadata)

        assert "_version" not in result.columns


class TestSchemaMapperForeignKeys:
    """Tests for foreign key detection."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_field_with_link_is_foreign_key_and_indexed(self) -> None:
        """Fields with 'link' metadata should be foreign keys and automatically indexed."""
        # Create target table first so ForeignKey can be created
        self.mapper.create_table(Customer, self.metadata)

        result = self.mapper.create_table(DocWithForeignKey, self.metadata)

        # The column should exist
        assert "customer_id" in result.columns

        # Should have a foreign key
        assert len(result.columns["customer_id"].foreign_keys) > 0

        # Should have an automatic index
        index_names = [idx.name for idx in result.indexes]
        assert f"ix_{result.name}_customer_id" in index_names

    def test_invalid_and_missing_links(self) -> None:
        """Invalid or missing link targets should not create foreign keys."""

        class DocWithInvalidLink(DocType):
            invalid_link: str = Field(json_schema_extra={"link": 123})  # type: ignore
            missing_link: str = Field(json_schema_extra={"link": "MissingDoc"})

        result = self.mapper.create_table(DocWithInvalidLink, self.metadata)
        assert not result.columns["invalid_link"].foreign_keys
        assert not result.columns["missing_link"].foreign_keys


class TestSchemaMapperEnums:
    """Tests for enum field handling."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_enum_field_is_stored_as_string(self) -> None:
        """Enum fields should be stored as String (database agnostic)."""
        result = self.mapper.create_table(DocWithEnum, self.metadata)

        # Store as String for database agnosticism
        assert isinstance(result.columns["priority"].type, String)


class DocWithCustomIndexes(DocType):
    field1: str
    field2: str
    field3: str
    field4: str

    class Meta:
        indexes = [
            "field1",
            ("field1", "field2"),
            ["field3"],
            {"fields": ["field4"]},
            {"fields": "missing_field"},
            "missing_field_str",
            {"other": "data"},  # No fields key
            "id",  # Will hit standard column but shouldn't fail
        ]


class TestSchemaMapperUnique:
    """Tests for unique constraint mapping."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_unique_field_maps_to_unique_constraint(self) -> None:
        """Field with json_schema_extra={'unique': True} should have unique constraint."""
        result = self.mapper.create_table(DocWithUnique, self.metadata)

        assert "email" in result.columns
        assert result.columns["email"].unique is True

    def test_custom_indexes(self) -> None:
        """Custom indexes from Meta should be created properly."""
        result = self.mapper.create_table(DocWithCustomIndexes, self.metadata)
        index_names = [idx.name for idx in result.indexes]
        assert f"ix_{result.name}_field1" in index_names
        assert f"ix_{result.name}_field1_field2" in index_names
        assert f"ix_{result.name}_field3" in index_names
        assert f"ix_{result.name}_field4" in index_names


# =============================================================================
# Child DocType Tests
# =============================================================================


class InvoiceItem(DocType):
    """Child DocType for testing - represents an invoice line item."""

    description: str
    quantity: int = 1
    unit_price: float = 0.0
    # Parent reference - will be auto-added by SchemaMapper
    # parent: str - auto-added as foreign key
    # parentfield: str - auto-added to identify which field
    # parenttype: str - auto-added to identify parent DocType


class Invoice(DocType):
    """Parent DocType with child table."""

    customer_name: str
    items: list[InvoiceItem] = Field(default_factory=list)
    total: float = 0.0


class TestSchemaMapperChildDocTypes:
    """Tests for Child DocType handling with relational tables."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_child_doctype_field_creates_separate_table(self) -> None:
        """list[DocType] should create a separate child table."""
        tables = self.mapper.create_tables(Invoice, self.metadata)

        # Should return multiple tables: parent and child
        assert len(tables) >= 2
        table_names = [t.name for t in tables]
        assert "invoice" in table_names
        assert "invoiceitem" in table_names

    def test_child_table_has_parent_foreign_key(self) -> None:
        """Child table should have parent foreign key column."""
        tables = self.mapper.create_tables(Invoice, self.metadata)

        child_table = next(t for t in tables if t.name == "invoiceitem")

        assert "parent" in child_table.columns
        assert isinstance(child_table.columns["parent"].type, String)

    def test_child_table_has_parentfield_column(self) -> None:
        """Child table should have parentfield column to identify the field."""
        tables = self.mapper.create_tables(Invoice, self.metadata)

        child_table = next(t for t in tables if t.name == "invoiceitem")

        assert "parentfield" in child_table.columns
        assert isinstance(child_table.columns["parentfield"].type, String)

    def test_child_table_has_parenttype_column(self) -> None:
        """Child table should have parenttype column to identify parent DocType."""
        tables = self.mapper.create_tables(Invoice, self.metadata)

        child_table = next(t for t in tables if t.name == "invoiceitem")

        assert "parenttype" in child_table.columns
        assert isinstance(child_table.columns["parenttype"].type, String)

    def test_child_table_has_idx_column(self) -> None:
        """Child table should have idx column for ordering."""
        tables = self.mapper.create_tables(Invoice, self.metadata)

        child_table = next(t for t in tables if t.name == "invoiceitem")

        assert "idx" in child_table.columns
        assert isinstance(child_table.columns["idx"].type, Integer)

    def test_parent_table_excludes_child_field(self) -> None:
        """Parent table should not have column for list[DocType] field."""
        tables = self.mapper.create_tables(Invoice, self.metadata)

        parent_table = next(t for t in tables if t.name == "invoice")

        # items field should NOT be a column - it's a child table reference
        assert "items" not in parent_table.columns

    def test_create_table_for_child_doc(self) -> None:
        """create_table on a child DocType directly should include parent fields."""

        class StandaloneChild(DocType):
            class Meta:
                is_child = True

        result = self.mapper.create_table(StandaloneChild, self.metadata)
        assert "parent" in result.columns
        assert "parenttype" in result.columns
        assert "idx" in result.columns


# =============================================================================
# Schema Evolution / Alter Table Tests
# =============================================================================


class BaseUser(DocType):
    email: str
    age: int | None = None


class ExtendedUser(BaseUser):
    department: str
    age: float | None = None  # Modified type
    role: Priority = Priority.LOW  # Enum for branch coverage


class InvalidUser(DocType):
    pass  # Missing base fields


class TestSchemaMapperEvolution:
    """Tests for schema evolution and DDL generation."""

    def setup_method(self) -> None:
        """Create mapper for each test."""
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_is_child_table(self) -> None:
        class NormalDoc(DocType):
            pass

        class ChildDoc(DocType):
            class Meta:
                is_child = True

        assert self.mapper.is_child_table(NormalDoc) is False
        assert self.mapper.is_child_table(ChildDoc) is True

    def test_get_merged_fields(self) -> None:
        fields = self.mapper.get_merged_fields(ExtendedUser)
        assert "email" in fields
        assert "department" in fields
        assert "id" in fields  # Inherited from BaseDocType

    def test_validate_override_schema_success(self) -> None:
        self.mapper.validate_override_schema(BaseUser, ExtendedUser)

    def test_validate_override_schema_fails_when_missing_fields(self) -> None:
        with pytest.raises(ValueError, match="is missing base fields"):
            self.mapper.validate_override_schema(BaseUser, InvalidUser)

    def test_detect_schema_changes(self) -> None:
        changes = self.mapper.detect_schema_changes(BaseUser, ExtendedUser)

        added = changes["added_fields"]
        assert "department" in added
        assert "role" in added
        assert added["role"]["sa_type"] == String

        modified = changes["modified_fields"]
        assert "age" in modified

        removed = changes["removed_fields"]
        assert len(removed) == 0

    def test_detect_schema_changes_removed_fields(self) -> None:
        changes = self.mapper.detect_schema_changes(BaseUser, InvalidUser)
        assert "email" in changes["removed_fields"]

    def test_generate_alter_table_statements(self) -> None:
        changes = self.mapper.detect_schema_changes(BaseUser, ExtendedUser)
        stmts = self.mapper.generate_alter_table_statements(
            "extendeduser", changes, self.metadata
        )
        assert len(stmts) == 2
        # Depending on Dialect, DDL statements compile differently. Check .text directly.
        ddls = [getattr(stmt, "text", str(stmt)) for stmt in stmts]
        assert any("department" in ddl for ddl in ddls)
        assert any("role" in ddl for ddl in ddls)

    def test_generate_alter_table_empty(self) -> None:
        changes = self.mapper.detect_schema_changes(BaseUser, BaseUser)
        stmts = self.mapper.generate_alter_table_statements(
            "baseuser", changes, self.metadata
        )
        assert len(stmts) == 0
