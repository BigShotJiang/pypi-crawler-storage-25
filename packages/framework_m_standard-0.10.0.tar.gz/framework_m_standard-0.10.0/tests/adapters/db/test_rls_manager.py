"""Tests for RLSManager.

TDD tests for extracting RLS and Bulk Operations logic out of GenericRepository.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.exceptions import PermissionDeniedError
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_standard.adapters.db.rls_manager import RLSManager
from sqlalchemy import Column, MetaData, String, Table

# =============================================================================
# Test Models
# =============================================================================


class RLSMockDoc(BaseDocType):
    """Test DocType for RLS."""

    title: str = Field(default="Test")


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_repo() -> MagicMock:
    repo = MagicMock()
    repo.model = RLSMockDoc
    # Provide a real SQLAlchemy Table so delete() and update() statements can be built
    metadata = MetaData()
    repo.table = Table(
        "rls_mock_table",
        metadata,
        Column("id", String, primary_key=True),
    )
    repo.list_entities = AsyncMock()
    repo.get = AsyncMock()
    # Mock _apply_filters to return statement directly for easy testing
    repo._apply_filters = MagicMock(side_effect=lambda stmt, filters: stmt)
    return repo


@pytest.fixture
def mock_session() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def mock_user() -> UserContext:
    return UserContext(id="user-123", email="user@test.com", roles=["User"])


# =============================================================================
# Tests
# =============================================================================


class TestRLSManager:
    """Tests for RLSManager."""

    @pytest.mark.asyncio
    @patch("framework_m_core.rls.apply_rls_filters")
    async def test_list_for_user(
        self,
        mock_apply_rls: AsyncMock,
        mock_repo: MagicMock,
        mock_session: AsyncMock,
        mock_user: UserContext,
    ) -> None:
        """Should apply RLS filters and delegate to list_entities."""
        mock_apply_rls.return_value = []
        mock_repo.list_entities.return_value = "paginated_result"

        manager = RLSManager(mock_repo)
        result = await manager.list_for_user(mock_session, mock_user, limit=10)

        assert result == "paginated_result"
        mock_apply_rls.assert_called_once()
        mock_repo.list_entities.assert_called_once_with(
            session=mock_session,
            filters=mock_apply_rls.return_value,
            order_by=None,
            limit=10,
            offset=0,
        )

    @pytest.mark.asyncio
    @patch("framework_m_core.permissions.has_permission_for_doc")
    async def test_get_for_user_success(
        self,
        mock_has_perm: AsyncMock,
        mock_repo: MagicMock,
        mock_session: AsyncMock,
        mock_user: UserContext,
    ) -> None:
        """Should return entity if user has permission."""
        doc_id = uuid4()
        mock_doc = RLSMockDoc(id=doc_id)
        mock_repo.get.return_value = mock_doc
        mock_has_perm.return_value = True

        manager = RLSManager(mock_repo)
        result = await manager.get_for_user(mock_session, mock_user, doc_id)

        assert result == mock_doc
        mock_has_perm.assert_called_once_with(mock_user, mock_doc, "read")

    @pytest.mark.asyncio
    @patch("framework_m_core.permissions.has_permission_for_doc")
    async def test_get_for_user_denied(
        self,
        mock_has_perm: AsyncMock,
        mock_repo: MagicMock,
        mock_session: AsyncMock,
        mock_user: UserContext,
    ) -> None:
        """Should raise PermissionDeniedError if user lacks permission."""
        doc_id = uuid4()
        mock_doc = RLSMockDoc(id=doc_id)
        mock_repo.get.return_value = mock_doc
        mock_has_perm.return_value = False

        manager = RLSManager(mock_repo)

        with pytest.raises(PermissionDeniedError):
            await manager.get_for_user(mock_session, mock_user, doc_id)

    @pytest.mark.asyncio
    @patch("framework_m_core.rls.apply_rls_filters")
    async def test_delete_many_for_user(
        self,
        mock_apply_rls: AsyncMock,
        mock_repo: MagicMock,
        mock_session: AsyncMock,
        mock_user: UserContext,
    ) -> None:
        """Should apply RLS filters and execute delete."""
        mock_apply_rls.return_value = []

        mock_result = MagicMock()
        mock_result.rowcount = 5
        mock_session.execute.return_value = mock_result

        manager = RLSManager(mock_repo)
        result = await manager.delete_many_for_user(mock_session, mock_user, hard=True)

        assert result == 5
        mock_session.execute.assert_called_once()

        # Should use the repository's internal filter builder
        mock_repo._apply_filters.assert_called_once()
