"""Tests for Application Lifespan.

TDD tests for the application lifecycle hooks extracted from app.py.
"""

import pytest
from framework_m_standard.adapters.web.app import create_app


class TestAppLifecycle:
    """Test application lifecycle hooks."""

    @pytest.mark.asyncio
    async def test_lifespan_context_manager(self) -> None:
        """App should properly handle startup and shutdown."""
        app = create_app()
        assert app is not None
