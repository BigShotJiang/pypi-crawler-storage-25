"""Tests for OAuth2 Routes.

TDD: This test file is created BEFORE the implementation.

Tests cover:
- GET /api/v1/auth/oauth/{provider}/start - Redirect to provider
- GET /api/v1/auth/oauth/{provider}/callback - Handle OAuth callback
- OAuth2Protocol interface
- Configuration helpers
- Route handlers
"""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from litestar import Litestar
from litestar.testing import TestClient

# =============================================================================
# Test: OAuth2Protocol Import
# =============================================================================


class TestOAuth2ProtocolImport:
    """Tests for OAuth2Protocol interface import."""

    def test_import_oauth2_protocol(self) -> None:
        """OAuth2Protocol should be importable."""
        from framework_m_core.interfaces.oauth import OAuth2Protocol

        assert OAuth2Protocol is not None


# =============================================================================
# Test: OAuth Routes Import
# =============================================================================


class TestOAuthRoutesImport:
    """Tests for OAuth routes import."""

    def test_import_oauth_routes_router(self) -> None:
        """oauth_routes_router should be importable."""
        from framework_m_standard.adapters.web.oauth_routes import oauth_routes_router

        assert oauth_routes_router is not None

    def test_import_oauth_start(self) -> None:
        """oauth_start handler should be importable."""
        from framework_m_standard.adapters.web.oauth_routes import oauth_start

        assert oauth_start is not None

    def test_import_oauth_callback(self) -> None:
        """oauth_callback handler should be importable."""
        from framework_m_standard.adapters.web.oauth_routes import oauth_callback

        assert oauth_callback is not None


# =============================================================================
# Test: OAuth Provider Config
# =============================================================================


class TestOAuthProviderConfig:
    """Tests for OAuth provider configuration."""

    def test_import_get_oauth_config(self) -> None:
        """get_oauth_config should be importable."""
        from framework_m_standard.adapters.web.oauth_routes import get_oauth_config

        assert get_oauth_config is not None

    def test_get_oauth_config_from_toml(self) -> None:
        """get_oauth_config should read from framework_config.toml."""
        from framework_m_standard.adapters.web.oauth_routes import get_oauth_config

        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["google", "github"],
                    "google": {
                        "client_id": "google-client-id",
                        "client_secret": "google-secret",
                    },
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            oauth_config = get_oauth_config()

        assert oauth_config["enabled"] is True
        assert "google" in oauth_config["providers"]

    def test_get_oauth_config_disabled(self) -> None:
        """get_oauth_config should return disabled when not configured."""
        from framework_m_standard.adapters.web.oauth_routes import get_oauth_config

        config = {"auth": {}}

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            oauth_config = get_oauth_config()

        assert oauth_config["enabled"] is False

    def test_get_provider_config(self) -> None:
        """get_provider_config should return provider settings."""
        from framework_m_standard.adapters.web.oauth_routes import get_provider_config

        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["google"],
                    "google": {
                        "client_id": "test-id",
                        "client_secret": "test-secret",
                    },
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            provider = get_provider_config("google")

        assert provider is not None
        assert provider["client_id"] == "test-id"

    def test_get_provider_config_not_found(self) -> None:
        """get_provider_config should return None for unknown provider."""
        from framework_m_standard.adapters.web.oauth_routes import get_provider_config

        config = {"auth": {"oauth": {"enabled": True, "providers": []}}}

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            provider = get_provider_config("unknown")

        assert provider is None

    def test_get_post_login_redirect_uses_state_fallback(self) -> None:
        """Configured redirect should be optional; state fallback should be used."""
        from framework_m_standard.adapters.web.oauth_routes import (
            get_post_login_redirect,
        )

        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["google"],
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            target = get_post_login_redirect("http://localhost:5173/desk")

        assert target == "http://localhost:5173/desk"

    def test_get_post_login_redirect_prefers_config_over_state(self) -> None:
        """Explicit config post_login_redirect should override inferred state redirect."""
        from framework_m_standard.adapters.web.oauth_routes import (
            get_post_login_redirect,
        )

        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["google"],
                    "post_login_redirect": "http://localhost:8888/desk",
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            target = get_post_login_redirect("http://localhost:5173/desk")

        assert target == "http://localhost:8888/desk"


# =============================================================================
# Test: OAuth Router Configuration
# =============================================================================


class TestOAuthRouterConfig:
    """Tests for OAuth router configuration."""

    def test_router_has_correct_path(self) -> None:
        """OAuth router should be mounted at /api/v1/auth/oauth."""
        from framework_m_standard.adapters.web.oauth_routes import oauth_routes_router

        assert oauth_routes_router.path == "/api/v1/auth/oauth"

    def test_router_has_auth_tag(self) -> None:
        """OAuth router should have 'auth' tag."""
        from framework_m_standard.adapters.web.oauth_routes import oauth_routes_router

        assert "auth" in oauth_routes_router.tags


# =============================================================================
# Test: Generic OIDC Support
# =============================================================================


class TestGenericOIDCImport:
    """Tests for Generic OIDC helper functions."""

    def test_import_get_oidc_well_known(self) -> None:
        """get_oidc_well_known should be importable."""
        from framework_m_standard.adapters.web.oauth_routes import get_oidc_well_known

        assert get_oidc_well_known is not None

    def test_import_is_generic_oidc_provider(self) -> None:
        """is_generic_oidc_provider should be importable."""
        from framework_m_standard.adapters.web.oauth_routes import (
            is_generic_oidc_provider,
        )

        assert is_generic_oidc_provider is not None


class TestGenericOIDCConfig:
    """Tests for Generic OIDC configuration."""

    def test_well_known_providers_not_generic(self) -> None:
        """Well-known providers should not be detected as generic OIDC."""
        from framework_m_standard.adapters.web.oauth_routes import (
            is_generic_oidc_provider,
        )

        assert is_generic_oidc_provider("google") is False
        assert is_generic_oidc_provider("github") is False
        assert is_generic_oidc_provider("microsoft") is False

    def test_custom_provider_is_generic(self) -> None:
        """Custom provider should be detected as generic OIDC."""
        from framework_m_standard.adapters.web.oauth_routes import (
            is_generic_oidc_provider,
        )

        assert is_generic_oidc_provider("keycloak") is True
        assert is_generic_oidc_provider("auth0") is True
        assert is_generic_oidc_provider("my-company-sso") is True

    def test_get_oidc_well_known_with_full_config(self) -> None:
        """get_oidc_well_known should return config when fully specified."""
        from framework_m_standard.adapters.web.oauth_routes import get_oidc_well_known

        provider_cfg = {
            "authorization_url": "https://auth.example.com/authorize",
            "token_url": "https://auth.example.com/token",
            "userinfo_url": "https://auth.example.com/userinfo",
            "scope": "openid email custom",
        }

        result = get_oidc_well_known(provider_cfg)

        assert result is not None
        assert result["authorization_url"] == "https://auth.example.com/authorize"
        assert result["token_url"] == "https://auth.example.com/token"
        assert result["scope"] == "openid email custom"

    def test_get_oidc_well_known_with_minimal_config(self) -> None:
        """get_oidc_well_known should work with just auth and token URLs."""
        from framework_m_standard.adapters.web.oauth_routes import get_oidc_well_known

        provider_cfg = {
            "authorization_url": "https://auth.example.com/authorize",
            "token_url": "https://auth.example.com/token",
        }

        result = get_oidc_well_known(provider_cfg)

        assert result is not None
        assert result["scope"] == "openid email profile"  # Default

    def test_get_oidc_well_known_missing_config(self) -> None:
        """get_oidc_well_known should return None for incomplete config."""
        from framework_m_standard.adapters.web.oauth_routes import get_oidc_well_known

        # Missing token_url
        provider_cfg = {
            "authorization_url": "https://auth.example.com/authorize",
        }

        result = get_oidc_well_known(provider_cfg)

        assert result is None


# =============================================================================
# Test: OAuth Route Handler Integration Tests with TestClient
# =============================================================================


class TestOAuthRouteIntegration:
    """Integration tests for OAuth routes using Litestar TestClient."""

    @pytest.fixture
    def app(self) -> "Litestar":
        """Create test app with OAuth routes."""
        from framework_m_standard.adapters.web.oauth_routes import oauth_routes_router
        from litestar import Litestar

        return Litestar(route_handlers=[oauth_routes_router])

    @pytest.fixture
    def client(self, app: "Litestar") -> "TestClient":
        """Create test client."""
        from litestar.testing import TestClient

        return TestClient(app)

    def test_oauth_start_google_redirects(self, client: "TestClient") -> None:
        """oauth_start should redirect to Google auth URL."""
        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["google"],
                    "google": {
                        "client_id": "test-client-id",
                        "client_secret": "test-secret",
                    },
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            response = client.get(
                "/api/v1/auth/oauth/google/start", follow_redirects=False
            )

        assert response.status_code in (302, 307)
        location = response.headers.get("location", "")
        assert "accounts.google.com" in location
        assert "client_id=test-client-id" in location

    def test_oauth_start_github_redirects(self, client: "TestClient") -> None:
        """oauth_start should redirect to GitHub auth URL."""
        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["github"],
                    "github": {
                        "client_id": "github-client",
                        "client_secret": "github-secret",
                    },
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            response = client.get(
                "/api/v1/auth/oauth/github/start", follow_redirects=False
            )

        assert response.status_code in (302, 307)
        location = response.headers.get("location", "")
        assert "github.com" in location

    def test_oauth_start_unknown_provider_returns_404(
        self, client: "TestClient"
    ) -> None:
        """oauth_start should return 404 for unknown provider."""
        config = {"auth": {"oauth": {"enabled": True, "providers": []}}}

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            response = client.get("/api/v1/auth/oauth/unknown/start")

        assert response.status_code == 404

    def test_oauth_start_includes_state_parameter(self, client: "TestClient") -> None:
        """oauth_start should include state parameter for CSRF protection."""
        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["google"],
                    "google": {
                        "client_id": "test-client-id",
                        "client_secret": "test-secret",
                    },
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            response = client.get(
                "/api/v1/auth/oauth/google/start", follow_redirects=False
            )

        location = response.headers.get("location", "")
        assert "state=" in location

    def test_oauth_start_uses_configured_response_type(
        self, client: "TestClient"
    ) -> None:
        """oauth_start should honor provider response_type override for generic OIDC."""
        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["rauth"],
                    "rauth": {
                        "client_id": "rauth-client-id",
                        "client_secret": "rauth-secret",
                        "discovery_url": "https://auth.castlecraft.in/.well-known/openid-configuration",
                        "response_type": "code id_token",
                        "response_mode": "query",
                    },
                }
            }
        }

        with (
            patch(
                "framework_m_standard.adapters.web.oauth_routes.load_config",
                return_value=config,
            ),
            patch(
                "framework_m_standard.adapters.web.oauth_routes._fetch_oidc_discovery",
                new=AsyncMock(
                    return_value={
                        "authorization_url": "https://auth.castlecraft.in/api/oauth2/confirmation",
                        "token_url": "https://auth.castlecraft.in/api/oauth2/token",
                        "userinfo_url": "https://auth.castlecraft.in/api/oauth2/profile",
                    }
                ),
            ),
        ):
            response = client.get(
                "/api/v1/auth/oauth/rauth/start", follow_redirects=False
            )

        assert response.status_code in (302, 307)
        location = response.headers.get("location", "")
        assert "response_type=code+id_token" in location
        assert "nonce=" in location
        assert "response_mode=query" in location

    def test_oauth_callback_with_error_returns_401(self, client: "TestClient") -> None:
        """oauth_callback should return 401 when error parameter present."""
        response = client.get("/api/v1/auth/oauth/google/callback?error=access_denied")

        assert response.status_code == 401

    def test_oauth_callback_missing_code_returns_401(self, client: TestClient) -> None:
        """oauth_callback should return 401 when code is missing."""
        response = client.get(
            "/api/v1/auth/oauth/google/callback?oauth_state=some-state"
        )

        assert response.status_code == 401

    def test_oauth_start_microsoft_redirects(self, client: "TestClient") -> None:
        """oauth_start should redirect to Microsoft auth URL."""
        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["microsoft"],
                    "microsoft": {
                        "client_id": "ms-client",
                        "client_secret": "ms-secret",
                    },
                }
            }
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            response = client.get(
                "/api/v1/auth/oauth/microsoft/start", follow_redirects=False
            )

        assert response.status_code in (302, 307)
        location = response.headers.get("location", "")
        assert "login.microsoftonline.com" in location


class TestPhaseBProviderResolution:
    """Tests for provider endpoint resolution priority (built-in -> discovery -> explicit)."""

    @pytest.mark.asyncio
    async def test_resolve_provider_endpoints_uses_discovery_url_for_generic_provider(
        self,
    ) -> None:
        """Generic provider with discovery_url should resolve endpoints from discovery."""
        from framework_m_standard.adapters.web.oauth_routes import (
            _resolve_provider_endpoints,
        )

        provider_cfg = {
            "client_id": "client-123",
            "client_secret": "secret-123",
            "discovery_url": "https://tenant.example.com/.well-known/openid-configuration",
            "scope": "openid profile email",
        }

        with patch(
            "framework_m_standard.adapters.web.oauth_routes._fetch_oidc_discovery",
            new=AsyncMock(
                return_value={
                    "authorization_url": "https://tenant.example.com/oauth2/authorize",
                    "token_url": "https://tenant.example.com/oauth2/token",
                    "userinfo_url": "https://tenant.example.com/oauth2/userinfo",
                }
            ),
        ):
            resolved = await _resolve_provider_endpoints("auth0", provider_cfg)

        assert (
            resolved["authorization_url"]
            == "https://tenant.example.com/oauth2/authorize"
        )
        assert resolved["token_url"] == "https://tenant.example.com/oauth2/token"
        assert resolved["userinfo_url"] == "https://tenant.example.com/oauth2/userinfo"

    @pytest.mark.asyncio
    async def test_resolve_provider_endpoints_uses_explicit_fallback_for_generic_provider(
        self,
    ) -> None:
        """Generic provider without discovery should use explicit endpoint config."""
        from framework_m_standard.adapters.web.oauth_routes import (
            _resolve_provider_endpoints,
        )

        provider_cfg = {
            "client_id": "client-explicit",
            "client_secret": "secret-explicit",
            "authorization_url": "https://sso.example.com/oauth2/authorize",
            "token_url": "https://sso.example.com/oauth2/token",
            "userinfo_url": "https://sso.example.com/oauth2/userinfo",
            "scope": "openid email profile",
        }

        resolved = await _resolve_provider_endpoints("company-sso", provider_cfg)

        assert (
            resolved["authorization_url"] == "https://sso.example.com/oauth2/authorize"
        )
        assert resolved["token_url"] == "https://sso.example.com/oauth2/token"
        assert resolved["userinfo_url"] == "https://sso.example.com/oauth2/userinfo"


class TestPhaseBStateValidation:
    """Tests for persisted state validation and one-time invalidation."""

    @pytest.mark.asyncio
    async def test_oauth_callback_rejects_unknown_state(self) -> None:
        """Callback should reject states not found in session store."""
        import framework_m_standard.adapters.web.oauth_routes as oauth_module
        from litestar.exceptions import NotAuthorizedException

        original_session_store = oauth_module._session_store
        original_oauth_service = oauth_module._oauth_service
        try:
            mock_store = AsyncMock()
            mock_store.list_for_user.return_value = []
            oauth_module._session_store = mock_store
            oauth_module._oauth_service = AsyncMock()

            with (
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
                    return_value={
                        "client_id": "cid",
                        "client_secret": "csecret",
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
                    new=AsyncMock(
                        return_value={
                            "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
                            "token_url": "https://oauth2.googleapis.com/token",
                            "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
                            "scope": "openid email profile",
                        }
                    ),
                ),
                pytest.raises(NotAuthorizedException),
            ):
                await oauth_module.oauth_callback.fn(
                    provider="google",
                    request=MagicMock(query_params={}),
                    code="auth-code-1",
                    oauth_state="invalid-state",
                    error=None,
                )
        finally:
            oauth_module._session_store = original_session_store
            oauth_module._oauth_service = original_oauth_service

    @pytest.mark.asyncio
    async def test_oauth_callback_accepts_standard_state_query_parameter(self) -> None:
        """Callback should accept provider-standard `state` query param fallback."""
        import framework_m_standard.adapters.web.oauth_routes as oauth_module

        original_session_store = oauth_module._session_store
        original_oauth_service = oauth_module._oauth_service
        try:
            state_session = MagicMock()
            state_session.session_id = "sess_state_qp"
            state_session.created_at = datetime.now(UTC)

            user_session = MagicMock()
            user_session.session_id = "sess_user_qp"

            mock_store = AsyncMock()
            mock_store.list_for_user.return_value = [state_session]
            mock_store.create.return_value = user_session

            mock_oauth_service = AsyncMock()
            linked_user = MagicMock()
            linked_user.id = "user-qp-001"
            mock_oauth_service.auto_link_user.return_value = linked_user

            oauth_module._session_store = mock_store
            oauth_module._oauth_service = mock_oauth_service

            with (
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
                    return_value={
                        "client_id": "cid",
                        "client_secret": "csecret",
                        "redirect_uri": "https://app.example.com/callback",
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
                    new=AsyncMock(
                        return_value={
                            "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
                            "token_url": "https://oauth2.googleapis.com/token",
                            "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
                            "scope": "openid email profile",
                        }
                    ),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
                    new=AsyncMock(return_value={"access_token": "token-qp"}),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._fetch_userinfo",
                    new=AsyncMock(
                        return_value={
                            "sub": "google-sub-qp",
                            "email": "qp@example.com",
                            "email_verified": True,
                            "name": "Query Param User",
                        }
                    ),
                ),
            ):
                response = await oauth_module.oauth_callback.fn(
                    provider="google",
                    request=MagicMock(query_params={"state": "query-state-123"}),
                    code="auth-code-qp",
                    oauth_state=None,
                    error=None,
                )

            assert response.status_code == 302
            mock_store.list_for_user.assert_called_once_with(
                "oauth_state:query-state-123"
            )
        finally:
            oauth_module._session_store = original_session_store
            oauth_module._oauth_service = original_oauth_service

    @pytest.mark.asyncio
    async def test_oauth_callback_invalidates_used_state(self) -> None:
        """Callback should invalidate persisted oauth_state after successful validation."""
        import framework_m_standard.adapters.web.oauth_routes as oauth_module

        original_session_store = oauth_module._session_store
        original_oauth_service = oauth_module._oauth_service
        try:
            state_session = MagicMock()
            state_session.session_id = "sess_state_123"
            state_session.created_at = datetime.now(UTC)

            user_session = MagicMock()
            user_session.session_id = "sess_user_456"

            mock_store = AsyncMock()
            mock_store.list_for_user.return_value = [state_session]
            mock_store.create.return_value = user_session

            mock_oauth_service = AsyncMock()
            linked_user = MagicMock()
            linked_user.id = "user-001"
            mock_oauth_service.auto_link_user.return_value = linked_user

            oauth_module._session_store = mock_store
            oauth_module._oauth_service = mock_oauth_service

            with (
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
                    return_value={
                        "client_id": "cid",
                        "client_secret": "csecret",
                        "redirect_uri": "https://app.example.com/callback",
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
                    new=AsyncMock(
                        return_value={
                            "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
                            "token_url": "https://oauth2.googleapis.com/token",
                            "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
                            "scope": "openid email profile",
                        }
                    ),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
                    new=AsyncMock(return_value={"access_token": "token-abc"}),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._fetch_userinfo",
                    new=AsyncMock(
                        return_value={
                            "sub": "google-sub-123",
                            "email": "user@example.com",
                            "email_verified": True,
                            "name": "Test User",
                        }
                    ),
                ),
            ):
                response = await oauth_module.oauth_callback.fn(
                    provider="google",
                    request=MagicMock(query_params={}),
                    code="auth-code-2",
                    oauth_state="valid-state",
                    error=None,
                )

            assert response.status_code == 302
            mock_store.delete.assert_any_call("sess_state_123")
        finally:
            oauth_module._session_store = original_session_store
            oauth_module._oauth_service = original_oauth_service

    @pytest.mark.asyncio
    async def test_oauth_callback_uses_configured_post_login_redirect(self) -> None:
        """Callback should redirect to auth.oauth.post_login_redirect when configured."""
        import framework_m_standard.adapters.web.oauth_routes as oauth_module

        original_session_store = oauth_module._session_store
        original_oauth_service = oauth_module._oauth_service
        try:
            state_session = MagicMock()
            state_session.session_id = "sess_state_cfg"
            state_session.created_at = datetime.now(UTC)

            user_session = MagicMock()
            user_session.session_id = "sess_user_cfg"

            mock_store = AsyncMock()
            mock_store.list_for_user.return_value = [state_session]
            mock_store.create.return_value = user_session

            mock_oauth_service = AsyncMock()
            linked_user = MagicMock()
            linked_user.id = "user-redirect-001"
            mock_oauth_service.auto_link_user.return_value = linked_user

            oauth_module._session_store = mock_store
            oauth_module._oauth_service = mock_oauth_service

            with (
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
                    return_value={
                        "client_id": "cid",
                        "client_secret": "csecret",
                        "redirect_uri": "https://app.example.com/callback",
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_oauth_config",
                    return_value={
                        "enabled": True,
                        "providers": ["google"],
                        "post_login_redirect": "http://localhost:5173/desk/",
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
                    new=AsyncMock(
                        return_value={
                            "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
                            "token_url": "https://oauth2.googleapis.com/token",
                            "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
                            "scope": "openid email profile",
                        }
                    ),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
                    new=AsyncMock(return_value={"access_token": "token-cfg"}),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._fetch_userinfo",
                    new=AsyncMock(
                        return_value={
                            "sub": "google-sub-cfg",
                            "email": "cfg@example.com",
                            "email_verified": True,
                            "name": "Config Redirect User",
                        }
                    ),
                ),
            ):
                response = await oauth_module.oauth_callback.fn(
                    provider="google",
                    request=MagicMock(query_params={}),
                    code="auth-code-cfg",
                    oauth_state="state-cfg",
                    error=None,
                )

            assert response.status_code == 302
            assert response.headers.get("location") == "http://localhost:5173/desk/"
        finally:
            oauth_module._session_store = original_session_store
            oauth_module._oauth_service = original_oauth_service

    @pytest.mark.asyncio
    async def test_oauth_callback_uses_state_derived_frontend_redirect(self) -> None:
        """Callback should redirect to inferred frontend origin when state carries it."""
        import framework_m_standard.adapters.web.oauth_routes as oauth_module

        original_session_store = oauth_module._session_store
        original_oauth_service = oauth_module._oauth_service
        try:
            state_session = MagicMock()
            state_session.session_id = "sess_state_dev"
            state_session.created_at = datetime.now(UTC)
            state_session.user_agent = "post_login_redirect:http://localhost:5173/desk"

            user_session = MagicMock()
            user_session.session_id = "sess_user_dev"

            mock_store = AsyncMock()
            mock_store.list_for_user.return_value = [state_session]
            mock_store.create.return_value = user_session

            mock_oauth_service = AsyncMock()
            linked_user = MagicMock()
            linked_user.id = "user-dev-001"
            mock_oauth_service.auto_link_user.return_value = linked_user

            oauth_module._session_store = mock_store
            oauth_module._oauth_service = mock_oauth_service

            with (
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
                    return_value={
                        "client_id": "cid",
                        "client_secret": "csecret",
                        "redirect_uri": "https://app.example.com/callback",
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_oauth_config",
                    return_value={
                        "enabled": True,
                        "providers": ["google"],
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
                    new=AsyncMock(
                        return_value={
                            "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
                            "token_url": "https://oauth2.googleapis.com/token",
                            "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
                            "scope": "openid email profile",
                        }
                    ),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
                    new=AsyncMock(return_value={"access_token": "token-dev"}),
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._fetch_userinfo",
                    new=AsyncMock(
                        return_value={
                            "sub": "google-sub-dev",
                            "email": "dev@example.com",
                            "email_verified": True,
                            "name": "Dev Redirect User",
                        }
                    ),
                ),
            ):
                response = await oauth_module.oauth_callback.fn(
                    provider="google",
                    request=MagicMock(query_params={}),
                    code="auth-code-dev",
                    oauth_state="state-dev",
                    error=None,
                )

            assert response.status_code == 302
            assert response.headers.get("location") == "http://localhost:5173/desk"
        finally:
            oauth_module._session_store = original_session_store
            oauth_module._oauth_service = original_oauth_service

    @pytest.mark.asyncio
    async def test_oauth_callback_rejects_expired_state(self) -> None:
        """Callback should reject oauth_state older than allowed TTL window."""
        import framework_m_standard.adapters.web.oauth_routes as oauth_module
        from litestar.exceptions import NotAuthorizedException

        original_session_store = oauth_module._session_store
        original_oauth_service = oauth_module._oauth_service
        try:
            expired_state = MagicMock()
            expired_state.session_id = "sess_state_expired"
            expired_state.created_at = datetime.now(UTC) - timedelta(minutes=30)

            mock_store = AsyncMock()
            mock_store.list_for_user.return_value = [expired_state]

            oauth_module._session_store = mock_store
            oauth_module._oauth_service = AsyncMock()

            with (
                patch(
                    "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
                    return_value={
                        "client_id": "cid",
                        "client_secret": "csecret",
                    },
                ),
                patch(
                    "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
                    new=AsyncMock(
                        return_value={
                            "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
                            "token_url": "https://oauth2.googleapis.com/token",
                            "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
                            "scope": "openid email profile",
                        }
                    ),
                ),
                pytest.raises(NotAuthorizedException),
            ):
                await oauth_module.oauth_callback.fn(
                    provider="google",
                    request=MagicMock(query_params={}),
                    code="auth-code-3",
                    oauth_state="expired-state",
                    error=None,
                )

            mock_store.delete.assert_any_call("sess_state_expired")
        finally:
            oauth_module._session_store = original_session_store
            oauth_module._oauth_service = original_oauth_service


class TestPhaseBEmailVerification:
    """Tests for trusted email-verification handling in callback flow."""

    def test_is_email_verified_uses_standard_claim(self) -> None:
        """Standard OIDC email_verified=true should be trusted."""
        from framework_m_standard.adapters.web.oauth_routes import _is_email_verified

        assert _is_email_verified("auth0", {"email_verified": True}) is True
        assert _is_email_verified("auth0", {"email_verified": False}) is False


class TestPhaseDSecurityAndOperability:
    """Tests for Phase-D security hardening and diagnostics endpoint."""

    @pytest.mark.asyncio
    async def test_oauth_callback_logs_warning_for_provider_error(self) -> None:
        """oauth_callback should write structured warning log for provider errors."""
        import framework_m_standard.adapters.web.oauth_routes as oauth_module
        from litestar.exceptions import NotAuthorizedException

        with (
            patch.object(oauth_module, "logger") as mock_logger,
            pytest.raises(NotAuthorizedException),
        ):
            await oauth_module.oauth_callback.fn(
                provider="google",
                request=MagicMock(query_params={}),
                code=None,
                oauth_state=None,
                error="access_denied",
            )

        assert mock_logger.warning.called

    @pytest.mark.asyncio
    async def test_provider_diagnostics_requires_admin(self) -> None:
        """Diagnostics endpoint should reject non-admin access."""
        from framework_m_standard.adapters.web.oauth_routes import provider_diagnostics
        from litestar.exceptions import NotAuthorizedException

        request = MagicMock()
        request.headers = {}
        request.state.user = None

        with pytest.raises(NotAuthorizedException):
            await provider_diagnostics.fn(provider="google", request=request)

    @pytest.mark.asyncio
    async def test_provider_diagnostics_returns_endpoints_for_admin(self) -> None:
        """Diagnostics endpoint should return resolved endpoints for admin users."""
        from framework_m_standard.adapters.web.oauth_routes import provider_diagnostics

        request = MagicMock()
        request.headers = {"x-roles": "Admin"}
        request.state.user = None

        result = await provider_diagnostics.fn(provider="google", request=request)

        assert result["provider"] == "google"
        assert result["configured"] is True
        assert result["resolution"] == "built-in"
        assert "authorization_url" in result
        assert "token_url" in result


# =============================================================================
# Additional Coverage Tests
# =============================================================================


class TestOAuthAdditionalCoverage:
    """Additional coverage for specific edge cases in OAuth routes."""

    @pytest.mark.asyncio
    async def test_oauth_providers_route(self) -> None:
        """oauth_providers endpoint should return normalized provider list."""
        from framework_m_standard.adapters.web.oauth_routes import oauth_providers

        config = {
            "auth": {
                "oauth": {
                    "enabled": True,
                    "providers": ["google", "github"],
                }
            }
        }
        with patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ):
            result = await oauth_providers.fn()
            assert result["enabled"] is True
            assert "google" in result["providers"]
            assert "github" in result["providers"]

    @pytest.mark.asyncio
    async def test_fetch_oidc_discovery_network_error(self) -> None:
        """_fetch_oidc_discovery should raise NotAuthorizedException on network errors."""
        import httpx
        from framework_m_standard.adapters.web.oauth_routes import _fetch_oidc_discovery
        from litestar.exceptions import NotAuthorizedException

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.get.side_effect = httpx.ConnectError("Network down")
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            with pytest.raises(
                NotAuthorizedException, match="OIDC discovery network error"
            ):
                await _fetch_oidc_discovery("https://broken.com/.well-known")

    @pytest.mark.asyncio
    async def test_fetch_oidc_discovery_missing_endpoints(self) -> None:
        """_fetch_oidc_discovery should raise if required endpoints are missing."""
        from framework_m_standard.adapters.web.oauth_routes import _fetch_oidc_discovery
        from litestar.exceptions import NotAuthorizedException

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_response = MagicMock()
            mock_response.status_code = 200
            # Return JSON without authorization_endpoint
            mock_response.json.return_value = {"token_endpoint": "http://t"}
            mock_client.get.return_value = mock_response
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            with pytest.raises(
                NotAuthorizedException, match="missing required endpoints"
            ):
                await _fetch_oidc_discovery("https://valid.com/.well-known")

    @pytest.mark.asyncio
    async def test_fetch_userinfo_github_fallback(self) -> None:
        """_fetch_userinfo should fetch emails separately for github if missing."""
        from framework_m_standard.adapters.web.oauth_routes import _fetch_userinfo

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()

            # First call to /user, second call to /user/emails
            user_resp = MagicMock(status_code=200)
            user_resp.json.return_value = {"login": "octocat", "id": 1}

            emails_resp = MagicMock(status_code=200)
            emails_resp.json.return_value = [
                {"email": "octo@github.com", "primary": True, "verified": True}
            ]

            mock_client.get.side_effect = [user_resp, emails_resp]
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            userinfo = await _fetch_userinfo("github", "token", "url", "emails_url")

            assert userinfo["email"] == "octo@github.com"
            assert userinfo["email_verified"] is True
            assert mock_client.get.call_count == 2

    def test_extract_email_microsoft_fallback(self) -> None:
        """_extract_email should check userPrincipalName for microsoft."""
        from framework_m_standard.adapters.web.oauth_routes import _extract_email

        userinfo = {"userPrincipalName": "ms@domain.com"}
        assert _extract_email("microsoft", userinfo) == "ms@domain.com"
