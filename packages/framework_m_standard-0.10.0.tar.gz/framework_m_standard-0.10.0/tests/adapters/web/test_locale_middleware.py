from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from framework_m_standard.adapters.web.middleware.locale import (
    LocaleResolutionMiddleware,
)


@pytest.mark.asyncio
async def test_locale_resolution_middleware():
    app = AsyncMock()
    middleware = LocaleResolutionMiddleware(app)

    # 1. Test from Accept-Language header
    scope = {
        "type": "http",
        "headers": [(b"accept-language", b"es-ES,es;q=0.9,en;q=0.8")],
        "state": {},
    }
    receive = AsyncMock()
    send = AsyncMock()

    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "es"

    # 2. Test from query parameter
    scope = {"type": "http", "headers": [], "query_string": b"lang=fr", "state": {}}
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "fr"

    # 3. Test from cookie
    scope = {"type": "http", "headers": [(b"cookie", b"locale=de")], "state": {}}
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "de"

    # 4. Test priority: Query > Cookie > Header
    scope = {
        "type": "http",
        "headers": [(b"cookie", b"locale=de"), (b"accept-language", b"en")],
        "query_string": b"lang=fr",
        "state": {},
    }
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "fr"

    # 5. Test default fallback
    scope = {"type": "http", "headers": [], "state": {}}
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "en"  # assuming "en" is default in core/config
