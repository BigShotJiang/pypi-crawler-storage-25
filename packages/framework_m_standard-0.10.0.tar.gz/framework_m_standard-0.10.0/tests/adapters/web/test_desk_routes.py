"""Tests for Desk UI Serving Routes.

TDD tests for extracting Desk & SPA routes out of app.py.
"""

from framework_m_standard.adapters.web.app import create_app
from litestar.testing import TestClient


class TestRootRedirect:
    """Test the root redirect to /desk/."""

    def test_root_redirects_to_desk(self) -> None:
        """GET / should redirect to /desk/."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/", follow_redirects=False)
            assert response.status_code in [301, 302, 307, 308]
            assert "/desk/" in response.headers.get("location", "")


class TestDeskServing:
    """Test the Desk UI serving routes."""

    def test_desk_root_returns_html(self) -> None:
        """GET /desk/ should return HTML content."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/")
            assert response.status_code in [200, 404]

    def test_desk_without_trailing_slash(self) -> None:
        """GET /desk should also work."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk")
            assert response.status_code in [200, 301, 302, 307, 308, 404]

    def test_desk_spa_navigation_route(self) -> None:
        """GET /desk/doctypes/Invoice should serve index.html for SPA routing."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/doctypes/Invoice")
            assert response.status_code in [200, 404]

    def test_desk_spa_static_file_returns_correct_mime(self) -> None:
        """GET /desk/assets/something.js should NOT return text/html."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/assets/nonexistent.js")
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")
                assert "text/html" not in content_type
            else:
                assert response.status_code == 404

    def test_desk_spa_css_file_not_served_as_html(self) -> None:
        """GET /desk/assets/something.css should NOT return text/html."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/assets/nonexistent.css")
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")
                assert "text/html" not in content_type
            else:
                assert response.status_code == 404

    def test_desk_favicon_not_served_as_html(self) -> None:
        """GET /desk/favicon.ico should NOT return text/html."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/favicon.ico")
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")
                assert "text/html" not in content_type
            else:
                assert response.status_code == 404

    def test_desk_deep_spa_route(self) -> None:
        """GET /desk/settings/general should serve SPA HTML."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/settings/general")
            assert response.status_code in [200, 404]

    def test_root_favicon_returns_clean_404_or_icon(self) -> None:
        """GET /favicon.ico should not crash and should return icon or clean 404."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/favicon.ico")
            assert response.status_code in [200, 404]


class TestFaviconResponse:
    """Tests for favicon response helper."""

    def test_prefers_explicit_frontend_dist_favicon(
        self, tmp_path, monkeypatch
    ) -> None:
        """Should serve favicon from FRAMEWORK_M_FRONTEND_DIST when available."""
        from framework_m_standard.adapters.web.desk_routes import _get_favicon_response

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        expected = b"ico-data"
        (dist / "favicon.ico").write_bytes(expected)

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_favicon_response()

        assert response.status_code in (None, 200)
        assert response.content == expected


class TestDeskHtmlResponse:
    """Test the _get_desk_html_response helper."""

    def test_returns_response(self) -> None:
        """Function should return a Response object."""
        from framework_m_standard.adapters.web.desk_routes import (
            _get_desk_html_response,
        )
        from litestar import Response

        response = _get_desk_html_response()
        assert isinstance(response, Response)

    def test_response_has_content(self) -> None:
        """Response should have content (either HTML or error message)."""
        from framework_m_standard.adapters.web.desk_routes import (
            _get_desk_html_response,
        )

        response = _get_desk_html_response()
        assert response.content is not None

    def test_prefers_explicit_frontend_dist_index(self, tmp_path, monkeypatch) -> None:
        """When explicit frontend dist is set, should serve its index.html first."""
        from framework_m_standard.adapters.web.desk_routes import (
            _get_desk_html_response,
        )

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        expected_html = b"<html><body>custom-ui</body></html>"
        (dist / "index.html").write_bytes(expected_html)

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_desk_html_response()
        assert response.status_code in (None, 200)
        assert response.content == expected_html

    def test_rewrites_root_asset_urls_for_desk(self, tmp_path, monkeypatch) -> None:
        """Root absolute asset URLs should be rewritten to /desk/* in served HTML."""
        from framework_m_standard.adapters.web.desk_routes import (
            _get_desk_html_response,
        )

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        (dist / "index.html").write_text(
            '<html><head><link href="/index-abc.css"></head><body><script src="/index-abc.js"></script></body></html>',
            encoding="utf-8",
        )

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_desk_html_response()

        html = response.content.decode("utf-8")
        assert 'href="/desk/index-abc.css"' in html
        assert 'src="/desk/index-abc.js"' in html

    def test_rewrites_relative_asset_urls_for_desk(self, tmp_path, monkeypatch) -> None:
        """Relative asset URLs should also be rewritten to /desk/* in served HTML."""
        from framework_m_standard.adapters.web.desk_routes import (
            _get_desk_html_response,
        )

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        (dist / "index.html").write_text(
            '<html><head><link href="index-abc.css"></head><body><script src="./index-abc.js"></script></body></html>',
            encoding="utf-8",
        )

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_desk_html_response()

        html = response.content.decode("utf-8")
        assert 'href="/desk/index-abc.css"' in html
        assert 'src="/desk/index-abc.js"' in html


class TestRootAssetCompat:
    """Tests for root index-* asset compatibility route."""

    def test_serves_root_index_asset_from_dist_assets(
        self, tmp_path, monkeypatch
    ) -> None:
        """GET /index-*.js should resolve to dist/assets when available."""
        dist = tmp_path / "frontend" / "dist" / "assets"
        dist.mkdir(parents=True)
        (dist / "index-abc.js").write_text("console.log('ok')", encoding="utf-8")

        monkeypatch.setenv(
            "FRAMEWORK_M_FRONTEND_DIST", str(tmp_path / "frontend" / "dist")
        )
        app = create_app(serve_static=True)

        with TestClient(app) as client:
            response = client.get("/index-abc.js")

        assert response.status_code == 200
        assert "javascript" in response.headers.get("content-type", "")

    def test_rejects_non_index_asset_paths(self) -> None:
        """Route should not serve arbitrary root files."""
        app = create_app(serve_static=True)

        with TestClient(app) as client:
            response = client.get("/not-an-asset.js")

        assert response.status_code in (401, 404)


class TestBundledStaticPath:
    """Test the _get_bundled_static_path function."""

    def test_returns_path_or_none(self) -> None:
        """Should return a Path or None."""
        from pathlib import Path

        from framework_m_standard.adapters.web.desk_routes import (
            _get_bundled_static_path,
        )

        result = _get_bundled_static_path()
        assert result is None or isinstance(result, Path)

    def test_static_path_is_directory_if_exists(self) -> None:
        """If path is returned, it should be a directory."""
        from framework_m_standard.adapters.web.desk_routes import (
            _get_bundled_static_path,
        )

        result = _get_bundled_static_path()
        if result is not None:
            assert result.is_dir()


class TestStaticFilesConfig:
    """Test the create_static_files_config function."""

    def test_returns_list(self) -> None:
        """Should return a list of Router objects."""
        from framework_m_standard.adapters.web.desk_routes import (
            create_static_files_config,
        )

        configs = create_static_files_config()
        assert isinstance(configs, list)

    def test_bundled_config_has_desk_assets_path(self) -> None:
        """If bundled static with assets/ exists, config should have /desk/assets path."""
        from framework_m_standard.adapters.web.desk_routes import (
            _get_bundled_static_path,
            create_static_files_config,
        )

        configs = create_static_files_config()
        bundled = _get_bundled_static_path()
        if bundled is not None and (bundled / "assets").exists():
            paths = [c.path for c in configs]
            assert "/desk/assets" in paths

    def test_fallback_config_when_no_directories_found(self, monkeypatch) -> None:
        """Should always return a fallback config even if no dist exists."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.desk_routes import (
            create_static_files_config,
        )

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", "/tmp/nonexistent/dist")  # nosec B108
        with (
            patch(
                "framework_m_standard.adapters.web.desk_routes._get_bundled_static_path",
                return_value=None,
            ),
            patch("pathlib.Path.exists", return_value=False),
        ):
            configs = create_static_files_config()

            assert len(configs) == 1
            assert configs[0].path == "/desk/assets"


class TestGetAssetUrl:
    """Test the get_asset_url function."""

    def test_returns_local_url_without_cdn(self) -> None:
        """Without CDN config, should return local /assets/ path."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.desk_routes import get_asset_url

        with patch(
            "framework_m_standard.adapters.web.desk_routes.load_config",
            return_value={},
        ):
            url = get_asset_url("js/main.js")
            assert url == "/assets/js/main.js"

    def test_returns_cdn_url_with_cdn_config(self) -> None:
        """With CDN config, should return CDN URL."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.desk_routes import get_asset_url

        with patch(
            "framework_m_standard.adapters.web.desk_routes.load_config",
            return_value={"frontend": {"cdn_url": "https://cdn.example.com"}},
        ):
            url = get_asset_url("js/main.js")
            assert url == "https://cdn.example.com/js/main.js"
