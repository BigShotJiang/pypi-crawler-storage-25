"""Phase-E OAuth end-to-end integration tests.

Coverage:
- start -> callback -> session cookie -> /auth/me for:
  - Google-style built-in provider
  - Azure-style discovery provider
  - Auth0 discovery provider
  - Custom explicit OIDC provider
- Negative tests for token exchange errors, missing provider identity, and
  unverified-email linking behavior.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from unittest.mock import AsyncMock, patch
from urllib.parse import parse_qs, urlparse

import pytest
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_standard.adapters.web.app import create_app
from litestar.testing import TestClient


@dataclass
class _SessionRecord:
    session_id: str
    user_id: str
    created_at: datetime


class _InMemoryOAuthSessionStore:
    """Minimal in-memory store for OAuth flow tests."""

    def __init__(self) -> None:
        self._records_by_user: dict[str, list[_SessionRecord]] = defaultdict(list)
        self._counter = 0

    async def create(
        self,
        user_id: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> _SessionRecord:
        _ = ip_address
        _ = user_agent
        self._counter += 1
        session_id = f"sess_oauth_{self._counter}"
        record = _SessionRecord(
            session_id=session_id,
            user_id=user_id,
            created_at=datetime.now(UTC),
        )
        self._records_by_user[user_id].append(record)
        return record

    async def list_for_user(self, user_id: str) -> list[_SessionRecord]:
        return list(self._records_by_user.get(user_id, []))

    async def delete(self, session_id: str) -> bool:
        for user_id, records in self._records_by_user.items():
            remaining = [
                record for record in records if record.session_id != session_id
            ]
            if len(remaining) != len(records):
                self._records_by_user[user_id] = remaining
                return True
        return False


def _extract_oauth_state_from_redirect(location: str) -> str:
    parsed = urlparse(location)
    state = parse_qs(parsed.query).get("state", [None])[0]
    assert state is not None
    return state


def _extract_session_cookie_value(set_cookie_header: str) -> str:
    parts = [part.strip() for part in set_cookie_header.split(";") if part.strip()]
    session_kv = next(part for part in parts if part.startswith("session_id="))
    return session_kv.split("=", 1)[1]


@pytest.mark.parametrize(
    ("provider", "oauth_config", "expected_auth_host", "expected_resolution"),
    [
        (
            "google",
            {
                "enabled": True,
                "providers": ["google"],
                "google": {
                    "client_id": "google-client-id",
                    "client_secret": "google-secret",
                    "redirect_uri": "https://app.example.com/api/v1/auth/oauth/google/callback",
                },
            },
            "accounts.google.com",
            "built-in",
        ),
        (
            "azure",
            {
                "enabled": True,
                "providers": ["azure"],
                "azure": {
                    "client_id": "azure-client-id",
                    "client_secret": "azure-secret",
                    "discovery_url": "https://login.microsoftonline.com/tenant/v2.0/.well-known/openid-configuration",
                    "scope": "openid profile email",
                    "redirect_uri": "https://app.example.com/api/v1/auth/oauth/azure/callback",
                },
            },
            "login.microsoftonline.com",
            "discovery",
        ),
        (
            "auth0",
            {
                "enabled": True,
                "providers": ["auth0"],
                "auth0": {
                    "client_id": "auth0-client-id",
                    "client_secret": "auth0-secret",
                    "discovery_url": "https://tenant.auth0.com/.well-known/openid-configuration",
                    "scope": "openid profile email",
                    "redirect_uri": "https://app.example.com/api/v1/auth/oauth/auth0/callback",
                },
            },
            "tenant.auth0.com",
            "discovery",
        ),
        (
            "company-sso",
            {
                "enabled": True,
                "providers": ["company-sso"],
                "company-sso": {
                    "client_id": "sso-client-id",
                    "client_secret": "sso-secret",
                    "authorization_url": "https://sso.example.com/oauth2/authorize",
                    "token_url": "https://sso.example.com/oauth2/token",
                    "userinfo_url": "https://sso.example.com/oauth2/userinfo",
                    "scope": "openid profile email",
                    "redirect_uri": "https://app.example.com/api/v1/auth/oauth/company-sso/callback",
                },
            },
            "sso.example.com",
            "explicit",
        ),
    ],
)
def test_oauth_end_to_end_provider_matrix(
    provider: str,
    oauth_config: dict[str, Any],
    expected_auth_host: str,
    expected_resolution: str,
) -> None:
    """Phase-E matrix: start -> callback -> session cookie -> /auth/me."""
    import framework_m_standard.adapters.web.oauth_routes as oauth_module
    from framework_m_standard.adapters.auth.strategies import AuthChain

    app = create_app(serve_static=False)
    session_store = _InMemoryOAuthSessionStore()
    oauth_service = AsyncMock()
    oauth_service.auto_link_user.return_value = type(
        "User",
        (),
        {"id": "user-social-001"},
    )()

    config = {"auth": {"oauth": oauth_config}}

    async def fake_fetch_discovery(discovery_url: str) -> dict[str, str]:
        if "microsoftonline" in discovery_url:
            return {
                "authorization_url": "https://login.microsoftonline.com/tenant/oauth2/v2.0/authorize",
                "token_url": "https://login.microsoftonline.com/tenant/oauth2/v2.0/token",
                "userinfo_url": "https://graph.microsoft.com/oidc/userinfo",
            }
        return {
            "authorization_url": "https://tenant.auth0.com/authorize",
            "token_url": "https://tenant.auth0.com/oauth/token",
            "userinfo_url": "https://tenant.auth0.com/userinfo",
        }

    with (
        TestClient(app) as client,
        patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._fetch_oidc_discovery",
            new=AsyncMock(side_effect=fake_fetch_discovery),
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
            new=AsyncMock(return_value={"access_token": "access-token-123"}),
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._fetch_userinfo",
            new=AsyncMock(
                return_value={
                    "sub": f"{provider}-sub-123",
                    "email": f"{provider}@example.com",
                    "email_verified": True,
                    "name": f"{provider.title()} User",
                }
            ),
        ),
    ):
        oauth_module.configure_oauth_routes(session_store, oauth_service)

        start_response = client.get(
            f"/api/v1/auth/oauth/{provider}/start",
            follow_redirects=False,
        )
        assert start_response.status_code in (302, 307)
        start_location = start_response.headers.get("location", "")
        assert expected_auth_host in start_location
        oauth_state = _extract_oauth_state_from_redirect(start_location)

        callback_response = client.get(
            f"/api/v1/auth/oauth/{provider}/callback",
            params={"code": "auth-code-1", "oauth_state": oauth_state},
            follow_redirects=False,
        )
        assert callback_response.status_code == 302
        assert callback_response.headers.get("location") == "/desk"

        set_cookie = callback_response.headers.get("set-cookie", "")
        assert "session_id=" in set_cookie
        session_id = _extract_session_cookie_value(set_cookie)

        diagnostics_request = type(
            "DiagnosticsRequest",
            (),
            {
                "headers": {"x-roles": "admin"},
                "state": type("State", (), {"user": None})(),
            },
        )()
        diagnostics = oauth_module.provider_diagnostics.fn

        import asyncio

        diagnostics_result = asyncio.run(
            diagnostics(provider=provider, request=diagnostics_request)
        )
        assert diagnostics_result["resolution"] == expected_resolution

        expected_user = UserContext(
            id="user-social-001",
            email=f"{provider}@example.com",
            name=f"{provider.title()} User",
            roles=["User"],
            tenants=[],
        )

        async def authenticate_from_cookie(
            headers: dict[str, str],
        ) -> UserContext | None:
            cookie_header = headers.get("cookie", "")
            if f"session_id={session_id}" in cookie_header:
                return expected_user
            return None

        with patch.object(
            AuthChain, "authenticate", side_effect=authenticate_from_cookie
        ):
            me_response = client.get(
                "/api/v1/auth/me",
                cookies={"session_id": session_id},
            )

        assert me_response.status_code == 200
        me_payload = me_response.json()
        assert me_payload["authenticated"] is True
        assert me_payload["id"] == "user-social-001"


def test_oauth_callback_token_exchange_error_returns_401() -> None:
    """Phase-E negative: token exchange failures are surfaced as unauthorized."""
    import framework_m_standard.adapters.web.oauth_routes as oauth_module
    from litestar.exceptions import NotAuthorizedException

    app = create_app(serve_static=False)
    session_store = _InMemoryOAuthSessionStore()
    oauth_service = AsyncMock()
    oauth_service.auto_link_user.return_value = type("User", (), {"id": "user-1"})()

    config = {
        "auth": {
            "oauth": {
                "enabled": True,
                "providers": ["google"],
                "google": {
                    "client_id": "google-client-id",
                    "client_secret": "google-secret",
                },
            }
        }
    }

    with (
        TestClient(app) as client,
        patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
            new=AsyncMock(
                side_effect=NotAuthorizedException(detail="token-exchange-failed")
            ),
        ),
    ):
        oauth_module.configure_oauth_routes(session_store, oauth_service)
        start_response = client.get(
            "/api/v1/auth/oauth/google/start",
            follow_redirects=False,
        )
        oauth_state = _extract_oauth_state_from_redirect(
            start_response.headers.get("location", "")
        )

        callback_response = client.get(
            "/api/v1/auth/oauth/google/callback",
            params={"code": "auth-code-err", "oauth_state": oauth_state},
            follow_redirects=False,
        )

        assert callback_response.status_code == 401


def test_oauth_callback_missing_provider_identity_returns_401() -> None:
    """Phase-E negative: userinfo without sub/id is rejected."""
    import framework_m_standard.adapters.web.oauth_routes as oauth_module

    app = create_app(serve_static=False)
    session_store = _InMemoryOAuthSessionStore()
    oauth_service = AsyncMock()
    oauth_service.auto_link_user.return_value = type("User", (), {"id": "user-1"})()

    config = {
        "auth": {
            "oauth": {
                "enabled": True,
                "providers": ["google"],
                "google": {
                    "client_id": "google-client-id",
                    "client_secret": "google-secret",
                },
            }
        }
    }

    with (
        TestClient(app) as client,
        patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
            new=AsyncMock(return_value={"access_token": "access-token-123"}),
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._fetch_userinfo",
            new=AsyncMock(
                return_value={
                    "email": "missing-id@example.com",
                    "email_verified": True,
                }
            ),
        ),
    ):
        oauth_module.configure_oauth_routes(session_store, oauth_service)
        start_response = client.get(
            "/api/v1/auth/oauth/google/start",
            follow_redirects=False,
        )
        oauth_state = _extract_oauth_state_from_redirect(
            start_response.headers.get("location", "")
        )

        callback_response = client.get(
            "/api/v1/auth/oauth/google/callback",
            params={"code": "auth-code-missing-id", "oauth_state": oauth_state},
            follow_redirects=False,
        )

        assert callback_response.status_code == 401


def test_oauth_callback_passes_unverified_email_to_auto_linking_service() -> None:
    """Phase-E negative: callback should preserve unverified email signal."""
    import framework_m_standard.adapters.web.oauth_routes as oauth_module

    app = create_app(serve_static=False)
    session_store = _InMemoryOAuthSessionStore()
    oauth_service = AsyncMock()
    oauth_service.auto_link_user.return_value = type("User", (), {"id": "user-2"})()

    config = {
        "auth": {
            "oauth": {
                "enabled": True,
                "providers": ["google"],
                "google": {
                    "client_id": "google-client-id",
                    "client_secret": "google-secret",
                },
            }
        }
    }

    with (
        TestClient(app) as client,
        patch(
            "framework_m_standard.adapters.web.oauth_routes.load_config",
            return_value=config,
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
            new=AsyncMock(return_value={"access_token": "access-token-123"}),
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._fetch_userinfo",
            new=AsyncMock(
                return_value={
                    "sub": "google-sub-unverified",
                    "email": "unverified@example.com",
                    "email_verified": False,
                    "name": "Unverified User",
                }
            ),
        ),
    ):
        oauth_module.configure_oauth_routes(session_store, oauth_service)
        start_response = client.get(
            "/api/v1/auth/oauth/google/start",
            follow_redirects=False,
        )
        oauth_state = _extract_oauth_state_from_redirect(
            start_response.headers.get("location", "")
        )

        callback_response = client.get(
            "/api/v1/auth/oauth/google/callback",
            params={"code": "auth-code-unverified", "oauth_state": oauth_state},
            follow_redirects=False,
        )

        assert callback_response.status_code == 302
        oauth_service.auto_link_user.assert_called_once()
        assert oauth_service.auto_link_user.call_args.kwargs["email_verified"] is False
