"""Extended tests for OAuth routes to maximize coverage of error branches."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.adapters.web.oauth_routes import (
    _exchange_code_for_tokens,
    _fetch_oidc_discovery,
    get_provider_config,
    oauth_providers,
    oauth_routes_router,
)
from litestar import Litestar
from litestar.exceptions import NotAuthorizedException
from litestar.testing import TestClient


@pytest.fixture
def app():
    """Test Litestar app with OAuth router."""
    return Litestar(route_handlers=[oauth_routes_router])


@pytest.fixture
def client(app):
    """Litestar test client."""
    return TestClient(app)


@pytest.mark.asyncio
async def test_oauth_providers_dict():
    """oauth_providers should handle dictionary configurations."""
    config = {
        "auth": {
            "oauth": {
                "enabled": True,
                "providers": {"custom_idp": {"client_id": "123"}},
            }
        }
    }
    with patch(
        "framework_m_standard.adapters.web.oauth_routes.load_config",
        return_value=config,
    ):
        res = await oauth_providers.fn()
        assert "custom_idp" in res["providers"]


def test_get_provider_config_dict():
    """get_provider_config should extract values from dict format."""
    config = {
        "auth": {
            "oauth": {
                "enabled": True,
                "providers": {"custom_idp": {"client_id": "123"}},
            }
        }
    }
    with patch(
        "framework_m_standard.adapters.web.oauth_routes.load_config",
        return_value=config,
    ):
        cfg = get_provider_config("custom_idp")
        assert cfg is not None
        assert cfg["client_id"] == "123"


def test_extract_provider_user_id_github():
    """_extract_provider_user_id should fallback through github attributes."""
    from framework_m_standard.adapters.web.oauth_routes import _extract_provider_user_id

    assert _extract_provider_user_id("github", {"id": "123"}) == "123"
    assert _extract_provider_user_id("github", {"node_id": "abc"}) == "abc"
    assert _extract_provider_user_id("google", {"sub": "456"}) == "456"


@pytest.mark.asyncio
async def test_oauth_start_id_token_generates_nonce(client):
    """oauth_start should include nonce when response_type requests an id_token."""
    config = {
        "auth": {
            "oauth": {
                "enabled": True,
                "providers": ["google"],
                "google": {
                    "client_id": "123",
                    "response_type": "code id_token",
                    "response_mode": "fragment",
                },
            }
        }
    }
    with patch(
        "framework_m_standard.adapters.web.oauth_routes.load_config",
        return_value=config,
    ):
        response = client.get("/api/v1/auth/oauth/google/start", follow_redirects=False)
        location = response.headers.get("location", "")
        assert "nonce=" in location
        assert "response_mode=fragment" in location


@pytest.mark.asyncio
async def test_fetch_oidc_discovery_import_error():
    """_fetch_oidc_discovery should raise if httpx is missing."""
    with (
        patch.dict("sys.modules", {"httpx": None}),
        pytest.raises(NotAuthorizedException, match="httpx is required"),
    ):
        await _fetch_oidc_discovery("http://test")


@pytest.mark.asyncio
async def test_fetch_oidc_discovery_http_error():
    """_fetch_oidc_discovery should handle network errors cleanly."""
    import httpx

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.HTTPError("Network")
        mock_client.__aenter__.return_value = mock_client
        mock_client_cls.return_value = mock_client

        with pytest.raises(NotAuthorizedException, match="network error"):
            await _fetch_oidc_discovery("http://test")


@pytest.mark.asyncio
async def test_exchange_code_error():
    """_exchange_code_for_tokens should raise NotAuthorizedException on authlib failure."""
    with patch(
        "framework_m_standard.adapters.web.oauth_routes.OAuthAdapter"
    ) as mock_adapter_cls:
        mock_adapter = MagicMock()
        mock_adapter.exchange_code = AsyncMock(
            side_effect=Exception("Failed internally")
        )
        mock_adapter_cls.return_value = mock_adapter

        with pytest.raises(NotAuthorizedException, match="Token exchange failed"):
            await _exchange_code_for_tokens("code", "http://token", {})


@pytest.mark.asyncio
async def test_oauth_callback_chain_errors(client):
    """Test the failure waterfall in oauth_callback."""

    # 1. Provider not found
    with patch(
        "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
        return_value=None,
    ):
        res = client.get("/api/v1/auth/oauth/unknown/callback?code=123")
        assert res.status_code == 404

    # 2. Missing State (CSRF prevention)
    with (
        patch(
            "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
            return_value={"client_id": "1"},
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
            AsyncMock(
                return_value={"token_url": "t", "authorization_url": "a", "scope": "s"}
            ),
        ),
    ):
        res = client.get("/api/v1/auth/oauth/google/callback?code=123")
        assert res.status_code == 401
        assert "Missing state parameter" in res.text

    # 3. Missing Access Token returned from provider
    with (
        patch(
            "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
            return_value={"client_id": "1"},
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._resolve_provider_endpoints",
            AsyncMock(
                return_value={"token_url": "t", "authorization_url": "a", "scope": "s"}
            ),
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._validate_and_consume_oauth_state",
            AsyncMock(return_value=None),
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes._exchange_code_for_tokens",
            AsyncMock(return_value={}),
        ),
    ):
        res = client.get("/api/v1/auth/oauth/google/callback?code=123&state=abc")
        assert res.status_code == 401
        assert "Failed to get access token" in res.text
