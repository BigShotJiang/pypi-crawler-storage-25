"""Tests for Metadata and Permission Caching Expansions."""

import asyncio
from unittest.mock import MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.permission import (
    PermissionAction,
    PolicyEvaluateRequest,
)
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.auth.rbac_permission import RbacPermissionAdapter
from framework_m_standard.adapters.cache.memory_cache import MemoryCacheAdapter
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.web.meta_routes import get_doctype_metadata


# Use a name that doesn't start with "Test" to avoid pytest collection warnings
class DocForTesting(BaseDocType):
    class Meta:
        permissions = {"read": ["Employee"]}


@pytest.fixture(autouse=True)
def setup_registry():
    registry = MetaRegistry.get_instance()
    registry.clear()
    registry.register_doctype(DocForTesting)


@pytest.mark.asyncio
async def test_rbac_permission_caching():
    """Verify that RbacPermissionAdapter caches evaluation results."""
    cache = MemoryCacheAdapter()

    # Patch get_cache in the factory module since it's imported locally in functions
    with patch("framework_m_standard.adapters.factory.get_cache", return_value=cache):
        adapter = RbacPermissionAdapter()
        request = PolicyEvaluateRequest(
            principal="user-1",
            action=PermissionAction.READ,
            resource="DocForTesting",
            principal_attributes={"roles": ["Employee"]},
        )

        # First call: Cache MISS
        result1 = await adapter.evaluate(request)
        assert result1.authorized is True
        assert "(cached)" not in result1.reason

        # Verify it's in cache
        assert await cache.exists("perm:user-1:DocForTesting:read")

        # Second call: Cache HIT
        result2 = await adapter.evaluate(request)
        assert result2.authorized is True
        assert "(cached)" in result2.reason


@pytest.mark.asyncio
async def test_meta_routes_caching():
    """Verify that get_doctype_metadata route caches its output."""
    cache = MemoryCacheAdapter()
    mock_request = MagicMock()
    mock_request.state.tenant = None
    mock_request.state.db_session = MagicMock()  # Mock session to trigger i18n

    # Mock TableRegistry to return dummy tables
    with patch(
        "framework_m_standard.adapters.db.table_registry.TableRegistry"
    ) as mock_tr:
        mock_tr.return_value.get_table.return_value = MagicMock()

        with patch(
            "framework_m_standard.adapters.factory.get_cache", return_value=cache
        ):
            expected_cache_key = "meta:DocForTesting:en:default:default"

            # First call: Initial generation
            result1 = await get_doctype_metadata.fn("DocForTesting", mock_request, "en")
            assert result1["doctype"] == "DocForTesting"

            # Verify it's in cache
            assert await cache.exists(expected_cache_key)

            # Modify cache to verify hit
            await cache.set(expected_cache_key, {"cached": True})

            # Second call: Should return cached value
            result2 = await get_doctype_metadata.fn("DocForTesting", mock_request, "en")
            assert result2 == {"cached": True}


@pytest.mark.asyncio
async def test_global_invalidation_hooks():
    """Verify that GenericRepository triggers pattern invalidations for special models."""
    cache = MagicMock(spec=MemoryCacheAdapter)
    cache.delete = MagicMock(return_value=asyncio.Future())
    cache.delete.return_value.set_result(None)
    cache.delete_pattern = MagicMock(return_value=asyncio.Future())
    cache.delete_pattern.return_value.set_result(1)

    mock_table = MagicMock()

    # 1. Test LocalUser invalidation
    from framework_m_core.doctypes.user import LocalUser

    user_repo = GenericRepository(LocalUser, mock_table)
    user_repo._cache = cache

    user_id = uuid4()
    await user_repo._invalidate_cache(None, id_to_invalidate=user_id)

    # Should call delete_pattern for perm:user_id:*
    cache.delete_pattern.assert_any_call(f"perm:{user_id}:*")

    # 2. Test CustomPermission invalidation
    from framework_m_core.doctypes.custom_permission import CustomPermission

    perm_repo = GenericRepository(CustomPermission, mock_table)
    perm_repo._cache = cache

    await perm_repo._invalidate_cache(None, id_to_invalidate=uuid4())
    cache.delete_pattern.assert_any_call("perm:*")

    # 3. Test Translation invalidation
    from framework_m_core.doctypes.translation import Translation

    trans_repo = GenericRepository(Translation, mock_table)
    trans_repo._cache = cache

    await trans_repo._invalidate_cache(None, id_to_invalidate=uuid4())
    cache.delete_pattern.assert_any_call("meta:*")
