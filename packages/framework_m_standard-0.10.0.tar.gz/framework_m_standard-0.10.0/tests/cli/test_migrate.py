from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.cli.migrate import get_manager


def test_get_manager(tmp_path):
    with patch("framework_m_standard.cli.migrate.MigrationManager") as mock_mgr:
        path = tmp_path / "fake_app"
        # 1. Test success with alembic dir existing
        with patch.object(Path, "exists", return_value=True):
            get_manager(path, database_url="sqlite+aiosqlite:///test.db")
            mock_mgr.assert_called_once_with(
                base_path=path, database_url="sqlite+aiosqlite:///test.db"
            )

        # 2. Test failure with missing alembic dir
        mock_mgr.reset_mock()
        with (
            patch.object(Path, "exists", return_value=False),
            pytest.raises(SystemExit),
        ):
            get_manager(path)

        # 3. Test failure with invalid async sqlite URL
        with patch.object(Path, "exists", return_value=True), pytest.raises(SystemExit):
            get_manager(path, database_url="sqlite:///test.db")


def test_migrate_run_command():
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        # Test basic run
        from framework_m_standard.cli.migrate import migrate

        migrate(path=Path("/app"), database_url="sqlite+aiosqlite:///db")
        mock_mgr.upgrade.assert_called_once_with("head")

        # Test with apps env var
        migrate(path=Path("/app"), apps="app1,app2")
        import os

        assert os.environ["INSTALLED_APPS"] == "app1,app2"

        # Test failure (SystemExit with code 1)
        mock_mgr.upgrade.side_effect = Exception("error")
        with pytest.raises(SystemExit) as exc:
            migrate(path=Path("/app"))
        assert exc.value.code == 1


def test_migrate_create_command():
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        from framework_m_standard.cli.migrate import create

        create(message="new migration", path=Path("/app"))
        mock_mgr.revision.assert_called_once_with(
            "new migration", autogenerate=True, version_path=None
        )

        # Test with --app
        mock_mgr.reset_mock()
        mock_spec = MagicMock()
        mock_spec.origin = "/path/to/app/__init__.py"
        with (
            patch("importlib.util.find_spec", return_value=mock_spec),
            patch("pathlib.Path.mkdir"),
            patch("pathlib.Path.exists", return_value=False),
        ):
            create(message="app migration", path=Path("/app"), app="myapp")
            # Should have called revision with version_path
            assert mock_mgr.revision.called

        # Test create failure
        mock_mgr.revision.side_effect = Exception("error")
        with pytest.raises(SystemExit):
            create(message="fail", path=Path("/app"))


def test_migrate_rollback_command():
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        from framework_m_standard.cli.migrate import rollback

        rollback(path=Path("/app"), steps=2)
        mock_mgr.downgrade.assert_called_once_with("-2")


def test_migrate_status_history_init():
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        from framework_m_standard.cli.migrate import history, init_alembic, status

        status(path=Path("/app"))
        mock_mgr.current.assert_called_once()

        history(path=Path("/app"))
        mock_mgr.history.assert_called_once()

        init_alembic(path=Path("/app"))
        mock_get_mgr.assert_called_with(Path("/app"), None, skip_alembic_check=True)
        mock_mgr.init.assert_called_once()

        # Test init failure
        mock_mgr.init.side_effect = Exception("error")
        with pytest.raises(SystemExit):
            init_alembic(path=Path("/app"))


def test_migrate_sync_command():
    with (
        patch("framework_m_standard.cli.migrate.get_manager"),
        patch("framework_m_standard.cli.migrate.MetaRegistry", create=True) as mock_reg,
        patch("framework_m_standard.cli.migrate.SchemaMapper", create=True),
        patch("framework_m_standard.cli.migrate.MetaData", create=True),
        patch("framework_m_standard.cli.migrate.create_engine", create=True),
    ):
        mock_reg.get_instance.return_value.list_doctypes.return_value = ["User"]
        mock_reg.get_instance.return_value.get_doctype.return_value = MagicMock()

        from framework_m_standard.cli.migrate import sync_command

        sync_command(path=Path("/app"), apps="app1")
        assert os.environ["INSTALLED_APPS"] == "app1"


def test_migrate_all_command():
    with (
        patch("framework_m_standard.cli.migrate.migrate") as mock_migrate,
        patch("framework_m_standard.cli.migrate.sync_command") as mock_sync,
    ):
        from framework_m_standard.cli.migrate import all_command

        all_command(path=Path("/app"))
        mock_migrate.assert_called_once()
        mock_sync.assert_called_once()

        # Test failure in migrate (SystemExit 1)
        mock_migrate.side_effect = SystemExit(1)
        with pytest.raises(SystemExit):
            all_command(path=Path("/app"))
