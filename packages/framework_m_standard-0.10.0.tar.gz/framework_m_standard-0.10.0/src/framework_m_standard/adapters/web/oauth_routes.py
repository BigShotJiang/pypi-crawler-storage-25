"""OAuth Routes - OAuth2/OIDC authentication endpoints.

This module provides REST endpoints for OAuth2 social login:
- GET /api/v1/auth/oauth/{provider}/start - Redirect to OAuth provider
- GET /api/v1/auth/oauth/{provider}/callback - Handle OAuth callback

Strategy A (BFF Cookie Mode):
- /start redirects to provider, stores CSRF state in session store (10-min TTL)
- /callback exchanges code, fetches userinfo, calls OAuthService.auto_link_user(),
  creates a server-side session, and redirects to /desk/ with Set-Cookie

Configuration in framework_config.toml:
    [auth.oauth]
    enabled = true
    providers = ["google", "github"]
    # Optional: override default post-login redirect (/desk/)
    # post_login_redirect = "https://your-frontend-host/desk/"

    [auth.oauth.google]
    client_id = "${GOOGLE_CLIENT_ID}"
    client_secret = "${GOOGLE_CLIENT_SECRET}"
    redirect_uri = "https://yourdomain.com/api/v1/auth/oauth/google/callback"

Example:
    from litestar import Litestar
    from framework_m_standard.adapters.web.oauth_routes import oauth_routes_router

    app = Litestar(route_handlers=[oauth_routes_router])
"""

from __future__ import annotations

import logging
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import urlencode, urlparse

from framework_m_core.config import load_config
from litestar import Router, get
from litestar.connection import Request
from litestar.exceptions import NotAuthorizedException, NotFoundException
from litestar.response import Redirect

from framework_m_standard.adapters.auth.oauth import OAuthAdapter

logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================


def get_oauth_config() -> dict[str, Any]:
    """Get OAuth configuration from framework_config.toml.

    Returns:
        OAuth configuration dict with enabled, providers, and provider configs
    """
    config = load_config()
    auth_config = config.get("auth", {})
    oauth_config = auth_config.get("oauth", {})

    return {
        "enabled": oauth_config.get("enabled", False),
        "providers": oauth_config.get("providers", []),
        **{k: v for k, v in oauth_config.items() if k not in ("enabled", "providers")},
    }


def get_provider_config(provider: str) -> dict[str, Any] | None:
    """Get configuration for a specific OAuth provider.

    Args:
        provider: Provider name (google, github, etc.)

    Returns:
        Provider config dict or None if not configured
    """
    oauth_config = get_oauth_config()
    providers = oauth_config.get("providers", [])

    if isinstance(providers, dict):
        provider_cfg = providers.get(provider)
        return provider_cfg if isinstance(provider_cfg, dict) else None

    if provider not in providers:
        return None

    result: dict[str, Any] | None = oauth_config.get(provider, {})
    return result if result else None


def get_post_login_redirect(state_redirect: str | None = None) -> str:
    """Get post-login redirect URL for OAuth callback success.

    Returns:
        Redirect target after successful OAuth login.
        Defaults to ``/desk`` for bundled-frontend deployments.
    """
    oauth_config = get_oauth_config()
    redirect_target = oauth_config.get("post_login_redirect")
    if isinstance(redirect_target, str) and redirect_target.strip():
        return redirect_target.strip()

    if state_redirect:
        return state_redirect

    return "/desk"


# =============================================================================
# OAuth2 Provider Registry
# =============================================================================

_DEFAULT_OIDC_SCOPE = "openid email profile"

# Well-known OAuth2 provider configurations
PROVIDER_CONFIGS: dict[str, dict[str, str]] = {
    "google": {
        "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
        "scope": _DEFAULT_OIDC_SCOPE,
    },
    "github": {
        "authorization_url": "https://github.com/login/oauth/authorize",
        "token_url": "https://github.com/login/oauth/access_token",
        "userinfo_url": "https://api.github.com/user",
        "emails_url": "https://api.github.com/user/emails",
        "scope": "read:user user:email",
    },
    "microsoft": {
        "authorization_url": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token_url": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "userinfo_url": "https://graph.microsoft.com/v1.0/me",
        "scope": _DEFAULT_OIDC_SCOPE,
    },
}


def get_oidc_well_known(provider_cfg: dict[str, Any]) -> dict[str, str] | None:
    """Get OIDC well-known config for generic OIDC provider.

    Args:
        provider_cfg: Provider configuration from framework_config.toml

    Returns:
        Dict with authorization_url, token_url, userinfo_url, scope
    """
    if "authorization_url" in provider_cfg and "token_url" in provider_cfg:
        return {
            "authorization_url": provider_cfg["authorization_url"],
            "token_url": provider_cfg["token_url"],
            "userinfo_url": provider_cfg.get("userinfo_url", ""),
            "scope": provider_cfg.get("scope", _DEFAULT_OIDC_SCOPE),
        }
    return None


def is_generic_oidc_provider(provider: str) -> bool:
    """Check if provider is a generic OIDC provider (not in well-known list)."""
    return provider not in PROVIDER_CONFIGS


# =============================================================================
# Module-level singletons (set via configure_* at startup)
# =============================================================================
_session_store: Any | None = None
_oauth_service: Any | None = None
_OAUTH_STATE_TTL_SECONDS = 600
_STATE_REDIRECT_PREFIX = "post_login_redirect:"


def configure_oauth_routes(
    session_store: Any, oauth_service: Any | None = None
) -> None:
    """Configure OAuth routes with session store and optional OAuth service.

    Call this during app startup. Session store is used for CSRF state storage.

    Args:
        session_store: Session store for OAuth state (short-lived 10-min sessions)
        oauth_service: OAuthService instance for auto_link_user(). Optional;
                       if None, OAuth callback will return an error.
    """
    global _session_store, _oauth_service
    _session_store = session_store
    _oauth_service = oauth_service


# =============================================================================
# Route Handlers
# =============================================================================


@get("/{provider:str}/start")
async def oauth_start(provider: str, request: Request[Any, Any, Any]) -> Redirect:
    """Start OAuth2 flow - redirect to provider.

    Generates a CSRF state parameter and redirects to the provider's auth page.
    Stores the state in the session store (10-min TTL) for later validation.

    Args:
        provider: OAuth provider name (google, github, microsoft, or custom)

    Returns:
        Redirect response to provider's auth URL

    Raises:
        NotFoundException: If provider not configured or not supported
    """
    provider_cfg = get_provider_config(provider)
    if provider_cfg is None:
        logger.warning(
            "oauth_start_provider_not_configured",
            extra={"provider": provider},
        )
        raise NotFoundException(detail=f"OAuth provider '{provider}' not configured")

    resolved = await _resolve_provider_endpoints(provider, provider_cfg)

    # Generate CSRF state
    state = secrets.token_urlsafe(32)
    inferred_redirect = _infer_state_post_login_redirect(request)

    # Store state in session store for validation in /callback.
    if _session_store is not None:
        await _session_store.create(
            user_id=f"oauth_state:{state}",  # Sentinel user_id for state tracking
            ip_address=None,
            user_agent=(
                f"{_STATE_REDIRECT_PREFIX}{inferred_redirect}"
                if inferred_redirect
                else None
            ),
        )

    # Build authorization URL
    client_id = provider_cfg.get("client_id", "")
    redirect_uri = provider_cfg.get(
        "redirect_uri", f"/api/v1/auth/oauth/{provider}/callback"
    )
    scope = resolved["scope"]
    response_type = str(provider_cfg.get("response_type", "code"))

    auth_query: dict[str, str] = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": response_type,
        "scope": scope,
        "state": state,
    }
    response_mode = provider_cfg.get("response_mode")
    if isinstance(response_mode, str) and response_mode.strip():
        auth_query["response_mode"] = response_mode.strip()

    response_type_tokens = {token.strip() for token in response_type.split() if token}
    if "id_token" in response_type_tokens:
        auth_query["nonce"] = secrets.token_urlsafe(24)

    query = urlencode(auth_query)
    auth_url = f"{resolved['authorization_url']}?{query}"

    return Redirect(path=auth_url)


@get("/providers")
async def oauth_providers() -> dict[str, Any]:
    """Return configured OAuth provider names for frontend runtime rendering."""
    oauth_config = get_oauth_config()
    providers_raw = oauth_config.get("providers", [])

    providers: list[str] = []
    if isinstance(providers_raw, list):
        providers = [p for p in providers_raw if isinstance(p, str)]
    elif isinstance(providers_raw, dict):
        providers = [str(k) for k in providers_raw]

    return {
        "enabled": bool(oauth_config.get("enabled", False)),
        "providers": providers,
    }


@get("/{provider:str}/callback")
async def oauth_callback(
    provider: str,
    request: Request[Any, Any, Any],
    code: str | None = None,
    oauth_state: str | None = None,
    error: str | None = None,
) -> Redirect:
    """Handle OAuth2 callback from provider.

    Full implementation of OAuth2 code exchange flow:
    1. Validate state against session store (CSRF protection)
    2. Exchange code for access_token via httpx call to provider's token_url
    3. Fetch userinfo from provider's userinfo_url
    4. Call OAuthService.auto_link_user() to find or create LocalUser
    5. Create server-side session
    6. Redirect to /desk/ with Set-Cookie: session_id=...

    Args:
        provider: OAuth provider name
        code: Authorization code from provider
        oauth_state: CSRF state parameter for validation (renamed from 'state' to
                     avoid Litestar's internal 'state' parameter conflict)
        error: Error from provider if authorization failed

    Returns:
        Redirect to /desk/ with session cookie set

    Raises:
        NotAuthorizedException: If OAuth flow fails (bad state, bad code, etc.)
    """
    if error:
        logger.warning(
            "oauth_callback_provider_error",
            extra={"provider": provider, "oauth_error": error},
        )
        raise NotAuthorizedException(detail=f"OAuth error: {error}")

    if code is None:
        logger.warning(
            "oauth_callback_missing_code",
            extra={"provider": provider},
        )
        raise NotAuthorizedException(detail="No authorization code received")

    provider_cfg = get_provider_config(provider)
    if provider_cfg is None:
        logger.warning(
            "oauth_callback_provider_not_configured",
            extra={"provider": provider},
        )
        raise NotFoundException(detail=f"OAuth provider '{provider}' not configured")

    resolved = await _resolve_provider_endpoints(provider, provider_cfg)

    callback_state = oauth_state or request.query_params.get("state")

    # Step 1: State validation (CSRF protection)
    if callback_state is None:
        logger.warning(
            "oauth_callback_missing_state",
            extra={"provider": provider},
        )
        raise NotAuthorizedException(detail="Missing state parameter (CSRF protection)")

    state_redirect = await _validate_and_consume_oauth_state(callback_state)

    # Step 2: Exchange code for tokens
    token_data = await _exchange_code_for_tokens(
        code=code,
        token_url=resolved["token_url"],
        provider_cfg=provider_cfg,
    )

    access_token: str | None = token_data.get("access_token")
    if not access_token:
        raise NotAuthorizedException(detail="Failed to get access token from provider")

    # Step 3: Fetch userinfo from provider
    userinfo = await _fetch_userinfo(
        provider=provider,
        access_token=access_token,
        userinfo_url=resolved.get("userinfo_url", ""),
        emails_url=resolved.get("emails_url"),
    )

    provider_user_id = _extract_provider_user_id(provider, userinfo)
    if not provider_user_id:
        raise NotAuthorizedException(
            detail="Could not determine user identity from provider"
        )

    email: str | None = _extract_email(provider, userinfo)
    email_verified = _is_email_verified(provider, userinfo)
    display_name: str = (
        userinfo.get("name")
        or userinfo.get("login")  # GitHub
        or userinfo.get("preferred_username")
        or email
        or provider_user_id
    )

    # Step 4: Find or create local user
    if _oauth_service is None:
        raise NotAuthorizedException(
            detail="OAuth service not configured. Run 'm create-admin' to set up."
        )

    user = await _oauth_service.auto_link_user(
        provider=provider,
        provider_user_id=provider_user_id,
        email=email,
        email_verified=email_verified,
        display_name=display_name,
    )

    # Step 5: Create server-side session
    if _session_store is None:
        raise NotAuthorizedException(detail="Session store not configured")

    session_data = await _session_store.create(
        user_id=str(user.id),
        ip_address=None,
        user_agent=None,
    )
    session_id = session_data.session_id

    # Step 6: Redirect to /desk/ with Set-Cookie
    # NOTE: Litestar Redirect doesn't support setting headers directly.
    # The cookie is included in the redirect response by using a Response object.
    # We return a Redirect and rely on after-response middleware to set the cookie,
    # OR we set a custom response with both redirect + cookie.
    # For simplicity, we use a Response with 302 status and Set-Cookie header.
    from litestar.response import Response

    cookie_value = f"{session_id}; HttpOnly; SameSite=Lax; Path=/; Max-Age=1209600"
    redirect_target = get_post_login_redirect(state_redirect)
    return Response(  # type: ignore[return-value]
        content=b"",
        status_code=302,
        headers={
            "location": redirect_target,
            "set-cookie": f"session_id={cookie_value}",
        },
    )


def _is_admin_request(request: Request[Any, Any, Any]) -> bool:
    """Check whether request is admin-authorized for diagnostics routes."""
    user = getattr(request.state, "user", None)
    roles = getattr(user, "roles", None)
    if isinstance(roles, list) and any(str(role).lower() == "admin" for role in roles):
        return True

    header_roles = request.headers.get("x-roles", "") if request.headers else ""
    return any(role.strip().lower() == "admin" for role in header_roles.split(","))


@get("/{provider:str}/diagnostics")
async def provider_diagnostics(
    provider: str,
    request: Request[Any, Any, Any],
) -> dict[str, Any]:
    """Admin-only diagnostics for OAuth provider endpoint resolution."""
    if not _is_admin_request(request):
        logger.warning(
            "oauth_diagnostics_forbidden",
            extra={"provider": provider},
        )
        raise NotAuthorizedException(detail="Admin role required")

    provider_cfg = get_provider_config(provider)
    if provider_cfg is None and provider not in PROVIDER_CONFIGS:
        return {
            "provider": provider,
            "configured": False,
            "resolution": "unconfigured",
        }

    effective_provider_cfg = provider_cfg or {}
    resolved = await _resolve_provider_endpoints(provider, effective_provider_cfg)

    resolution = "explicit"
    if provider in PROVIDER_CONFIGS:
        resolution = "built-in"
    elif effective_provider_cfg.get("discovery_url"):
        resolution = "discovery"

    return {
        "provider": provider,
        "configured": True,
        "resolution": resolution,
        "authorization_url": resolved.get("authorization_url"),
        "token_url": resolved.get("token_url"),
        "userinfo_url": resolved.get("userinfo_url"),
        "scope": resolved.get("scope"),
    }


# =============================================================================
# Internal helpers
# =============================================================================


async def _exchange_code_for_tokens(
    code: str,
    token_url: str,
    provider_cfg: dict[str, Any],
) -> dict[str, Any]:
    """Exchange OAuth2 authorization code for tokens.

    Args:
        code: Authorization code from /start redirect
        token_url: Provider's token endpoint URL
        provider_cfg: Provider config (has client_id, client_secret, redirect_uri)

    Returns:
        Token response dict (access_token, token_type, scope, etc.)

    Raises:
        NotAuthorizedException: If token exchange fails
    """
    try:
        adapter = OAuthAdapter(
            provider_name=str(provider_cfg.get("provider", "oidc")),
            client_id=str(provider_cfg.get("client_id", "")),
            client_secret=str(provider_cfg.get("client_secret", "")),
            authorization_url=str(provider_cfg.get("authorization_url", "")),
            token_url=token_url,
            userinfo_url=str(provider_cfg.get("userinfo_url", "")),
            scope=str(provider_cfg.get("scope", _DEFAULT_OIDC_SCOPE)),
            token_endpoint_auth_method=str(
                provider_cfg.get("token_endpoint_auth_method", "client_secret_basic")
            ),
        )
        token = await adapter.exchange_code(
            code=code,
            redirect_uri=str(provider_cfg.get("redirect_uri", "")),
        )
    except Exception as e:
        raise NotAuthorizedException(detail=f"Token exchange failed: {e}") from e

    return {
        "access_token": token.access_token,
        "token_type": token.token_type,
        "expires_in": token.expires_in,
        "refresh_token": token.refresh_token,
        "scope": token.scope,
    }


async def _fetch_oidc_discovery(discovery_url: str) -> dict[str, str]:
    """Fetch and normalize OIDC discovery metadata endpoints."""
    try:
        import httpx
    except ImportError as e:
        raise NotAuthorizedException(
            detail="httpx is required for OIDC discovery"
        ) from e

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(discovery_url, timeout=10.0)
            if response.status_code != 200:
                raise NotAuthorizedException(
                    detail=f"OIDC discovery failed: {response.status_code}"
                )
            payload = response.json()
    except httpx.HTTPError as e:
        raise NotAuthorizedException(detail=f"OIDC discovery network error: {e}") from e

    authorization_url = payload.get("authorization_endpoint")
    token_url = payload.get("token_endpoint")
    userinfo_url = payload.get("userinfo_endpoint", "")

    if not authorization_url or not token_url:
        raise NotAuthorizedException(
            detail="OIDC discovery payload missing required endpoints"
        )

    return {
        "authorization_url": str(authorization_url),
        "token_url": str(token_url),
        "userinfo_url": str(userinfo_url),
    }


async def _resolve_provider_endpoints(
    provider: str,
    provider_cfg: dict[str, Any],
) -> dict[str, str]:
    """Resolve provider endpoints in priority order.

    Priority:
    1. Built-in provider registry
    2. discovery_url from provider config
    3. Explicit authorization_url/token_url config
    """
    built_in = PROVIDER_CONFIGS.get(provider)
    if built_in is not None:
        resolved = dict(built_in)
        if provider_cfg.get("scope"):
            resolved["scope"] = str(provider_cfg["scope"])
        return resolved

    discovery_url = provider_cfg.get("discovery_url")
    if isinstance(discovery_url, str) and discovery_url:
        discovered = await _fetch_oidc_discovery(discovery_url)
        discovered["scope"] = str(provider_cfg.get("scope", _DEFAULT_OIDC_SCOPE))
        if provider_cfg.get("emails_url"):
            discovered["emails_url"] = str(provider_cfg["emails_url"])
        return discovered

    explicit = get_oidc_well_known(provider_cfg)
    if explicit is None:
        raise NotFoundException(
            detail=(
                f"OAuth provider '{provider}' requires discovery_url or "
                "authorization_url and token_url"
            )
        )
    return explicit


async def _validate_and_consume_oauth_state(oauth_state: str) -> str | None:
    """Validate persisted OAuth state and invalidate it after verification."""
    if _session_store is None:
        raise NotAuthorizedException(detail="Session store not configured")

    state_user_id = f"oauth_state:{oauth_state}"
    state_sessions = await _session_store.list_for_user(state_user_id)
    if not state_sessions:
        raise NotAuthorizedException(detail="Invalid or expired OAuth state")

    now = datetime.now(UTC)
    is_valid = False
    state_redirect: str | None = None

    for state_session in state_sessions:
        if state_redirect is None:
            state_redirect = _extract_state_redirect(
                getattr(state_session, "user_agent", None)
            )

        created_at = getattr(state_session, "created_at", None)
        if created_at is None:
            is_valid = True
            continue

        if created_at.tzinfo is None or created_at.tzinfo.utcoffset(created_at) is None:
            created_at = created_at.replace(tzinfo=UTC)

        if now - created_at <= timedelta(seconds=_OAUTH_STATE_TTL_SECONDS):
            is_valid = True

    for state_session in state_sessions:
        state_session_id = getattr(state_session, "session_id", None)
        if state_session_id:
            await _session_store.delete(state_session_id)

    if not is_valid:
        raise NotAuthorizedException(detail="Invalid or expired OAuth state")

    return state_redirect


def _extract_state_redirect(value: Any) -> str | None:
    """Extract validated post-login redirect marker from state session metadata."""
    if not isinstance(value, str) or not value.startswith(_STATE_REDIRECT_PREFIX):
        return None

    candidate = value[len(_STATE_REDIRECT_PREFIX) :].strip()
    if _is_allowed_state_redirect(candidate):
        return candidate
    return None


def _is_allowed_state_redirect(value: str) -> bool:
    """Allow only local frontend dev redirect targets for state-derived redirects."""
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"}:
        return False

    allowed_netlocs = {"localhost:5173", "127.0.0.1:5173"}
    if parsed.netloc not in allowed_netlocs:
        return False

    return parsed.path == "/desk" or parsed.path == "/desk/"


def _infer_state_post_login_redirect(request: Request[Any, Any, Any]) -> str | None:
    """Infer frontend dev redirect from request origin/referrer when applicable."""
    headers = getattr(request, "headers", None)
    if headers is None:
        return None

    origin_header = headers.get("origin")
    if isinstance(origin_header, str) and origin_header:
        parsed_origin = urlparse(origin_header)
        origin = f"{parsed_origin.scheme}://{parsed_origin.netloc}"
        if _is_allowed_state_redirect(f"{origin}/desk"):
            return f"{origin}/desk"

    referer_header = headers.get("referer")
    if isinstance(referer_header, str) and referer_header:
        parsed_ref = urlparse(referer_header)
        if parsed_ref.scheme and parsed_ref.netloc:
            origin = f"{parsed_ref.scheme}://{parsed_ref.netloc}"
            if _is_allowed_state_redirect(f"{origin}/desk"):
                return f"{origin}/desk"

    return None


async def _fetch_userinfo(
    provider: str,
    access_token: str,
    userinfo_url: str,
    emails_url: str | None = None,
) -> dict[str, Any]:
    """Fetch user info from provider's userinfo endpoint.

    Handles GitHub's special case where email must be fetched separately.

    Args:
        provider: Provider name
        access_token: Access token from code exchange
        userinfo_url: Provider's userinfo endpoint URL
        emails_url: Optional alternative email endpoint (GitHub)

    Returns:
        Userinfo dict with id/sub, email, name, email_verified
    """
    try:
        import httpx
    except ImportError as e:
        raise NotAuthorizedException(
            detail="httpx is required for OAuth userinfo fetch"
        ) from e

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(userinfo_url, headers=headers, timeout=10.0)
            if resp.status_code != 200:
                raise NotAuthorizedException(
                    detail=f"Failed to fetch userinfo: {resp.status_code}"
                )
            userinfo: dict[str, Any] = resp.json()

            # GitHub doesn't always include email in /user — fetch from /user/emails
            if provider == "github" and not userinfo.get("email") and emails_url:
                emails_resp = await client.get(
                    emails_url, headers=headers, timeout=10.0
                )
                if emails_resp.status_code == 200:
                    emails = emails_resp.json()
                    # Find the primary verified email
                    primary = next(
                        (e for e in emails if e.get("primary") and e.get("verified")),
                        None,
                    )
                    if primary:
                        userinfo["email"] = primary["email"]
                        userinfo["email_verified"] = True

            return userinfo
    except httpx.HTTPError as e:
        raise NotAuthorizedException(
            detail=f"Network error fetching userinfo: {e}"
        ) from e


def _extract_email(provider: str, userinfo: dict[str, Any]) -> str | None:
    """Extract email from provider userinfo dict.

    Different providers use different field names for email.

    Args:
        provider: Provider name
        userinfo: Userinfo dict from provider

    Returns:
        Email string or None
    """
    # Standard OIDC field
    email = userinfo.get("email")
    if email:
        return str(email)

    # Microsoft Graph uses different field
    if provider == "microsoft":
        mail = userinfo.get("mail") or userinfo.get("userPrincipalName")
        if mail:
            return str(mail)

    return None


def _extract_provider_user_id(provider: str, userinfo: dict[str, Any]) -> str:
    """Extract canonical provider user id from userinfo payload."""
    if provider == "github":
        github_id = userinfo.get("id") or userinfo.get("node_id") or userinfo.get("sub")
        return str(github_id or "")

    oidc_id = userinfo.get("sub") or userinfo.get("id")
    return str(oidc_id or "")


def _is_email_verified(provider: str, userinfo: dict[str, Any]) -> bool:
    """Determine whether provider email is verified and trusted for auto-link."""
    email_verified = userinfo.get("email_verified")
    if isinstance(email_verified, bool):
        return email_verified

    if isinstance(email_verified, str):
        return email_verified.lower() == "true"

    if provider == "github" and userinfo.get("email"):
        return bool(userinfo.get("email_verified", False))

    return False


# =============================================================================
# Router
# =============================================================================


oauth_routes_router = Router(
    path="/api/v1/auth/oauth",
    route_handlers=[oauth_start, oauth_providers, oauth_callback, provider_diagnostics],
    tags=["auth"],
)


__all__ = [
    "configure_oauth_routes",
    "get_oauth_config",
    "get_provider_config",
    "oauth_callback",
    "provider_diagnostics",
    "oauth_routes_router",
    "oauth_start",
]
