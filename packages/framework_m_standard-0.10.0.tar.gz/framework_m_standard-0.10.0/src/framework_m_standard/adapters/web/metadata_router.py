"""Metadata API Routes.

This module provides metadata discovery endpoints:
- GET /api/meta/doctypes - List all registered DocTypes
- GET /api/meta/{doctype} - Get DocType schema (in meta_router.py)

These endpoints enable the frontend to dynamically discover
available DocTypes and build UI from schema.

Per ARCHITECTURE.md:
- Code-first Pydantic models
- MetaRegistry singleton holds all DocTypes
- Opt-in API exposure via api_resource=True
"""

from __future__ import annotations

from typing import Any

from framework_m_core.registry import MetaRegistry
from litestar import Request, Router, get
from pydantic import BaseModel


def _normalize_nullable_property(property_schema: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(property_schema)

    type_value = normalized.get("type")
    if isinstance(type_value, list):
        non_null_types = [t for t in type_value if isinstance(t, str) and t != "null"]
        if len(non_null_types) == 1:
            normalized["type"] = non_null_types[0]

    any_of = normalized.get("anyOf")
    if isinstance(any_of, list):
        non_null = [
            item
            for item in any_of
            if isinstance(item, dict) and item.get("type") != "null"
        ]
        if len(non_null) == 1:
            merged = {**non_null[0], **normalized}
            merged["type"] = non_null[0].get("type", normalized.get("type"))
            merged.pop("anyOf", None)
            return merged

    return normalized


def _normalize_schema(schema: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(schema)
    properties = normalized.get("properties")
    if not isinstance(properties, dict):
        return normalized

    normalized["properties"] = {
        key: _normalize_nullable_property(value) if isinstance(value, dict) else value
        for key, value in properties.items()
    }
    return normalized


class DocTypeInfo(BaseModel):
    """Brief DocType info for listing."""

    name: str
    module: str | None = None
    label: str | None = None
    metadata: dict[str, bool | str | int | float] = {}


class DocTypeListResponse(BaseModel):
    """Response structure for listing DocTypes."""

    doctypes: list[DocTypeInfo]
    count: int


@get("/doctypes", tags=["Metadata"])
async def list_doctypes(request: Request[Any, Any, Any]) -> DocTypeListResponse:
    """List registered DocTypes with metadata discovery.

    Returns summary info for each DocType and its whitelisted
    metadata flags. Supports dynamic filtering via query parameters.

    Example:
        GET /api/meta/doctypes?show_in_desk=true

    Returns:
        List of whitelisted DocType info objects
    """
    registry = MetaRegistry.get_instance()
    whitelisted_keys = registry.get_whitelisted_meta_keys()
    doctype_names = registry.list_doctypes()

    # Extract all whitelisted filters from query params
    # and implement strict boolean casting
    filters: dict[str, Any] = {}
    for key, value in request.query_params.items():
        if key in whitelisted_keys:
            if value.lower() == "true":
                filters[key] = True
            elif value.lower() == "false":
                filters[key] = False
            else:
                filters[key] = value

    doctypes_info: list[DocTypeInfo] = []
    for name in doctype_names:
        try:
            doctype_class = registry.get_doctype(name)
            meta_flags = doctype_class.get_meta_flags()

            # Filter DocTypes based on whitelisted query params
            match = True
            for f_key, f_val in filters.items():
                if meta_flags.get(f_key) != f_val:
                    match = False
                    break

            if not match:
                continue

            # Only return whitelisted metadata flags
            response_metadata = {
                k: v for k, v in meta_flags.items() if k in whitelisted_keys
            }

            # Finalize metadata labeling
            raw_label = response_metadata.get("label")
            label = str(raw_label) if isinstance(raw_label, str) else name

            doctypes_info.append(
                DocTypeInfo(
                    name=name,
                    module=str(getattr(doctype_class, "__module__", "")),
                    label=label,
                    metadata=response_metadata,
                )
            )
        except (KeyError, AttributeError):
            continue

    return DocTypeListResponse(
        doctypes=doctypes_info,
        count=len(doctypes_info),
    )


@get("/{doctype_name:str}", tags=["Metadata"])
async def get_doctype_schema(doctype_name: str) -> dict[str, Any]:
    """Get schema for a specific DocType.

    Returns the full JSON Schema, layout, and permissions for the DocType.

    Args:
        doctype_name: Name of the DocType

    Returns:
        DocType schema including fields, layout, permissions

    Raises:
        NotFoundException: If DocType is not registered
    """
    from litestar.exceptions import NotFoundException

    registry = MetaRegistry.get_instance()

    try:
        doctype_class = registry.get_doctype(doctype_name)
    except KeyError as e:
        raise NotFoundException(f"DocType '{doctype_name}' not found") from e

    # Generate JSON Schema from Pydantic model
    schema = _normalize_schema(doctype_class.model_json_schema())

    # Extract metadata from Meta class
    meta = getattr(doctype_class, "Meta", None)

    return {
        "doctype": doctype_name,
        "module": getattr(doctype_class, "__module__", None),
        "schema": schema,
        "layout": getattr(meta, "layout", None) if meta else None,
        "permissions": getattr(meta, "permissions", {}) if meta else {},
        "metadata": {
            "label": getattr(meta, "label", doctype_name) if meta else doctype_name,
            "is_child_table": getattr(meta, "is_child_table", False) if meta else False,
            "api_resource": getattr(meta, "api_resource", False) if meta else False,
            "requires_auth": getattr(meta, "requires_auth", True) if meta else True,
            "apply_rls": getattr(meta, "apply_rls", True) if meta else True,
        },
    }


# Create router with /api/meta prefix
metadata_router = Router(
    path="/api/meta",
    route_handlers=[list_doctypes, get_doctype_schema],
    tags=["Metadata"],
)


__all__ = ["get_doctype_schema", "list_doctypes", "metadata_router"]
