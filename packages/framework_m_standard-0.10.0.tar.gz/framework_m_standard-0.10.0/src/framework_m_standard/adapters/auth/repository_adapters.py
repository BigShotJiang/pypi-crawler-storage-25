"""Auth Repository Adapters.

These session-aware adapters expose specific repository methods required by
authentication services, bridging the generic repository with the auth domain.
"""

from typing import Any, cast
from uuid import UUID

from framework_m_core.doctypes.session import Session
from framework_m_core.doctypes.social_account import SocialAccount
from framework_m_core.doctypes.user import LocalUser
from framework_m_core.interfaces.repository import FilterOperator, FilterSpec

from framework_m_standard.adapters.db.repository_factory import RepositoryFactory
from framework_m_standard.adapters.db.session import SessionFactory


class LocalUserRepositoryAdapter:
    """Session-aware adapter exposing LocalUser repository methods required by auth."""

    def __init__(
        self, repo_factory: RepositoryFactory, session_factory: SessionFactory
    ) -> None:
        self._repo_factory = repo_factory
        self._session_factory = session_factory

    async def get(self, user_id: str) -> LocalUser | None:
        repo = self._repo_factory.get_repository(LocalUser)
        if repo is None:
            return None
        try:
            parsed_id = UUID(str(user_id))
        except (ValueError, TypeError):
            return None

        async with self._session_factory.get_session() as session:
            result = await repo.get(session, parsed_id)
        return result

    async def get_by_email(self, email: str) -> LocalUser | None:
        repo = self._repo_factory.get_repository(LocalUser)
        if repo is None:
            return None

        async with self._session_factory.get_session() as session:
            result = await repo.list_entities(
                session=session,
                filters=[
                    FilterSpec(
                        field="email",
                        operator=FilterOperator.EQ,
                        value=email,
                    )
                ],
                limit=1,
                offset=0,
            )
            return result.items[0] if result.items else None

    async def find_by_email(self, email: str) -> LocalUser | None:
        """Find a user by email for OAuth auto-linking."""
        return await self.get_by_email(email)

    async def save(self, user: LocalUser) -> LocalUser:
        repo = self._repo_factory.get_repository(LocalUser)
        if repo is None:
            raise RuntimeError("LocalUser repository is not available")

        async with self._session_factory.get_session() as session:
            saved = await repo.save(session, user)
        return cast(LocalUser, saved)

    async def create(
        self,
        email: str,
        password: str,
        full_name: str | None = None,
        roles: list[str] | None = None,
    ) -> LocalUser:
        """Create and persist a LocalUser for OAuth first-login provisioning."""
        from framework_m_core.security import hash_password

        user = LocalUser(
            email=email,
            password_hash=hash_password(password),
            full_name=full_name,
            is_active=True,
            roles=list(roles) if roles else ["User"],
        )
        return await self.save(user)


class SocialAccountRepositoryAdapter:
    """Session-aware adapter exposing SocialAccount methods used by OAuthService."""

    def __init__(
        self, repo_factory: RepositoryFactory, session_factory: SessionFactory
    ) -> None:
        self._repo_factory = repo_factory
        self._session_factory = session_factory

    async def find_by_provider(
        self,
        provider: str,
        provider_user_id: str,
    ) -> SocialAccount | None:
        """Find SocialAccount by provider + provider_user_id."""
        repo = self._repo_factory.get_repository(SocialAccount)
        if repo is None:
            return None

        async with self._session_factory.get_session() as session:
            result = await repo.list_entities(
                session=session,
                filters=[
                    FilterSpec(
                        field="provider",
                        operator=FilterOperator.EQ,
                        value=provider,
                    ),
                    FilterSpec(
                        field="provider_user_id",
                        operator=FilterOperator.EQ,
                        value=provider_user_id,
                    ),
                ],
                limit=1,
                offset=0,
            )
            return result.items[0] if result.items else None

    async def create(
        self,
        provider: str,
        provider_user_id: str,
        user_id: str | UUID,
        display_name: str,
        email: str | None,
        last_login_at: Any,
    ) -> SocialAccount:
        """Create and persist a SocialAccount record."""
        repo = self._repo_factory.get_repository(SocialAccount)
        if repo is None:
            raise RuntimeError("SocialAccount repository is not available")

        account = SocialAccount(
            provider=provider,
            provider_user_id=provider_user_id,
            user_id=str(user_id),
            display_name=display_name,
            email=email,
            last_login_at=last_login_at,
        )

        async with self._session_factory.get_session() as session:
            saved = await repo.save(session, account)
        return cast(SocialAccount, saved)

    async def update(self, account: SocialAccount, **updates: Any) -> SocialAccount:
        """Update and persist a SocialAccount record."""
        repo = self._repo_factory.get_repository(SocialAccount)
        if repo is None:
            raise RuntimeError("SocialAccount repository is not available")

        for key, value in updates.items():
            setattr(account, key, value)

        async with self._session_factory.get_session() as session:
            saved = await repo.save(session, account)
        return cast(SocialAccount, saved)


class SessionRepositoryAdapter:
    """Session-aware adapter exposing Session repository methods used by session store."""

    def __init__(
        self, repo_factory: RepositoryFactory, session_factory: SessionFactory
    ) -> None:
        self._repo_factory = repo_factory
        self._session_factory = session_factory

    async def save(self, session_model: Session) -> Session:
        repo = self._repo_factory.get_repository(Session)
        if repo is None:
            raise RuntimeError("Session repository is not available")

        async with self._session_factory.get_session() as session:
            saved = await repo.save(session, session_model)
        return cast(Session, saved)

    async def get_by_id(self, session_id: str) -> Session | None:
        repo = self._repo_factory.get_repository(Session)
        if repo is None:
            return None

        async with self._session_factory.get_session() as session:
            result = await repo.list_entities(
                session=session,
                filters=[
                    FilterSpec(
                        field="session_id",
                        operator=FilterOperator.EQ,
                        value=session_id,
                    )
                ],
                limit=1,
                offset=0,
            )
            return result.items[0] if result.items else None

    async def delete(self, session_id: str) -> bool:
        repo = self._repo_factory.get_repository(Session)
        if repo is None:
            return False

        session_model = await self.get_by_id(session_id)
        if session_model is None:
            return False

        async with self._session_factory.get_session() as session:
            await repo.delete(session, session_model.id)
        return True

    async def find_by(self, **kwargs: Any) -> list[Session]:
        user_id = kwargs.get("user_id")
        if user_id is None:
            return []

        repo = self._repo_factory.get_repository(Session)
        if repo is None:
            return []

        async with self._session_factory.get_session() as session:
            result = await repo.list_entities(
                session=session,
                filters=[
                    FilterSpec(
                        field="user_id",
                        operator=FilterOperator.EQ,
                        value=user_id,
                    )
                ],
                limit=1000,
                offset=0,
            )
            return list(result.items)
