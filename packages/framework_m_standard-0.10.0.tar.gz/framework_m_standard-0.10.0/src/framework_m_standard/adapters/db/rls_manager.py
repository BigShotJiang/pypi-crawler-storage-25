"""RLS Manager - Handles Row-Level Security and Bulk Operations."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.exceptions import EntityNotFoundError, PermissionDeniedError
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.repository import (
    FilterSpec,
    OrderSpec,
    PaginatedResult,
)
from sqlalchemy import delete, update
from sqlalchemy.ext.asyncio import AsyncSession

if TYPE_CHECKING:
    from framework_m_standard.adapters.db.generic_repository import GenericRepository


class RLSManager[T: BaseDocType]:
    """Manager for Row-Level Security and Bulk Operations.

    Provides permission-checked retrieval and bulk update/delete operations.
    """

    def __init__(self, repository: GenericRepository[T]) -> None:
        """Initialize the RLS manager.

        Args:
            repository: The parent repository instance
        """
        self._repo = repository

    async def list_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> PaginatedResult[T]:
        """List entities with RLS filtering applied."""
        from framework_m_core.rls import apply_rls_filters

        doctype_name = self._repo.model.get_doctype_name()
        merged_filters = await apply_rls_filters(user, doctype_name, filters)

        return await self._repo.list_entities(
            session=session,
            filters=merged_filters,
            order_by=order_by,
            limit=limit,
            offset=offset,
        )

    async def get_for_user(
        self,
        session: AsyncSession,
        user: UserContext,
        id: UUID,
        action: str = "read",
        include_deleted: bool = False,
    ) -> T:
        """Retrieve an entity with permission checking."""
        from framework_m_core.permissions import has_permission_for_doc

        # First load the entity
        entity = await self._repo.get(session, id, include_deleted)

        if entity is None:
            raise EntityNotFoundError(self._repo.model.__name__, str(id))

        # Check permission
        has_perm = await has_permission_for_doc(user, entity, action)
        if not has_perm:
            raise PermissionDeniedError(
                f"User '{user.id}' does not have '{action}' permission for "
                f"{self._repo.model.__name__} '{id}'"
            )

        return entity

    async def delete_many_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        hard: bool = False,
    ) -> int:
        """Delete multiple entities with RLS filtering."""
        from framework_m_core.rls import apply_rls_filters

        rls_filters = await apply_rls_filters(
            user, self._repo.model.get_doctype_name(), filters
        )

        if hard:
            delete_stmt = delete(self._repo.table)
            delete_stmt = self._repo._apply_filters(delete_stmt, rls_filters)
            result = await session.execute(delete_stmt)
            return int(getattr(result, "rowcount", 0) or 0)
        else:
            update_stmt = update(self._repo.table).values(deleted_at=datetime.now(UTC))
            update_stmt = self._repo._apply_filters(update_stmt, rls_filters)
            result = await session.execute(update_stmt)
            return int(getattr(result, "rowcount", 0) or 0)

    async def update_many_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        data: dict[str, Any] | None = None,
    ) -> int:
        """Update multiple entities with RLS filtering."""
        if not data:
            return 0

        from framework_m_core.rls import apply_rls_filters

        rls_filters = await apply_rls_filters(
            user, self._repo.model.get_doctype_name(), filters
        )

        update_data = {**data, "modified": datetime.now(UTC)}
        update_stmt = update(self._repo.table).values(**update_data)
        update_stmt = self._repo._apply_filters(update_stmt, rls_filters)
        result = await session.execute(update_stmt)
        return int(getattr(result, "rowcount", 0) or 0)
