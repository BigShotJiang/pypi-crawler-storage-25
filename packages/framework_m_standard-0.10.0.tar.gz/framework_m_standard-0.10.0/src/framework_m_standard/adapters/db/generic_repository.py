"""Generic Repository - SQLAlchemy implementation of RepositoryProtocol.

This module provides the GenericRepository class that implements standard
CRUD operations for DocTypes using SQLAlchemy async sessions.

Features:
- Automatic soft delete (deleted_at)
- Controller lifecycle hooks
- Optimistic Concurrency Control (OCC) support
- Name auto-generation
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.exceptions import (
    DatabaseError,
    DuplicateNameError,
    IntegrityError,
    RepositoryError,
    TemporalQueryNotSupportedError,
)
from framework_m_core.interfaces.repository import (
    FilterOperator,
    FilterSpec,
    OrderDirection,
    OrderSpec,
    PaginatedResult,
)
from sqlalchemy import Table, func, select, update
from sqlalchemy import delete as sql_delete
from sqlalchemy.exc import IntegrityError as SAIntegrityError
from sqlalchemy.exc import OperationalError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from framework_m_standard.adapters.db.child_table import ChildTableManager
from framework_m_standard.adapters.db.link_fetching import LinkFetchingService
from framework_m_standard.adapters.db.naming import DocumentNamingService
from framework_m_standard.adapters.db.rls_manager import RLSManager
from framework_m_standard.adapters.db.versioning_config import is_versioning_enabled

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from framework_m_core.domain.base_controller import BaseController
    from framework_m_core.interfaces.auth_context import UserContext
    from framework_m_core.interfaces.cache import CacheProtocol
    from framework_m_core.interfaces.event_bus import EventBusProtocol


class VersionConflictError(Exception):
    """Raised when optimistic concurrency control detects a conflict."""

    def __init__(self, entity_id: UUID, expected_version: int) -> None:
        """Initialize with conflict details.

        Args:
            entity_id: The ID of the entity with version conflict
            expected_version: The version that was expected
        """
        self.entity_id = entity_id
        self.expected_version = expected_version
        super().__init__(
            f"Version conflict for entity {entity_id}. "
            f"Expected version {expected_version}."
        )


class GenericRepository[T: BaseDocType]:
    """Generic SQLAlchemy repository implementing RepositoryProtocol.

    Provides standard CRUD operations for DocTypes using async SQLAlchemy.
    Supports controller lifecycle hooks and optimistic concurrency control.

    Note:
        This repository does NOT store sessions. All CRUD methods accept
        session as the first parameter. The caller owns the session via
        UnitOfWork context manager.

    Example:
        >>> repo = GenericRepository(
        ...     model=Todo,
        ...     table=todo_table,
        ...     controller_class=TodoController,
        ...     event_bus=InMemoryEventBus(),
        ... )
        >>> async with uow_factory() as uow:
        ...     todo = await repo.save(uow.session, entity)
    """

    def __init__(
        self,
        model: type[T],
        table: Table,
        controller_class: type[BaseController[T]] | None = None,
        event_bus: EventBusProtocol | None = None,
        cache: CacheProtocol | None = None,
    ) -> None:
        """Initialize the repository.

        Args:
            model: The DocType model class
            table: SQLAlchemy Table object
            controller_class: Optional controller for lifecycle hooks
            event_bus: Optional event bus for publishing domain events
            cache: Optional cache for query result caching
        """
        self._model = model
        self._table = table
        self._controller_class = controller_class
        self._event_bus = event_bus
        self._cache = cache
        self._naming_service = DocumentNamingService(model, table)
        self._child_table_manager = ChildTableManager(model)
        self._link_fetching_service = LinkFetchingService(model)
        self._rls_manager = RLSManager(self)

    @property
    def model(self) -> type[T]:
        """Get the DocType model class."""
        return self._model

    @property
    def table(self) -> Table:
        """Get the SQLAlchemy table."""
        return self._table

    @property
    def controller_class(self) -> type[BaseController[T]] | None:
        """Get the controller class if set."""
        return self._controller_class

    @property
    def event_bus(self) -> EventBusProtocol | None:
        """Get the event bus if set."""
        return self._event_bus

    @property
    def cache(self) -> CacheProtocol | None:
        """Get the cache if set."""
        return self._cache

    def _cache_key(self, id: UUID) -> str:
        """Generate cache key for an entity by ID."""
        return f"{self._model.__name__}:id:{id}"

    def _cache_key_by_name(self, name: str) -> str:
        """Generate cache key for an entity by Name."""
        return f"{self._model.__name__}:name:{name}"

    async def _invalidate_cache(
        self, entity: T | None, id_to_invalidate: UUID | None = None
    ) -> None:
        """Invalidate cache entries for an entity.

        Parallelizes ID and Name key deletions using asyncio.gather.

        Args:
            entity: The entity instance (to get id and name)
            id_to_invalidate: Explicit ID to invalidate (if entity not available)
        """
        if not self._cache:
            return

        tasks = []
        if id_to_invalidate:
            tasks.append(self._cache.delete(self._cache_key(id_to_invalidate)))
        elif entity and entity.id:
            tasks.append(self._cache.delete(self._cache_key(entity.id)))

        name = getattr(entity, "name", None) if entity else None
        if isinstance(name, str):
            tasks.append(self._cache.delete(self._cache_key_by_name(name)))

        if tasks:
            await asyncio.gather(*tasks)

        # 3. Global Invalidation Triggers
        model_name = self._model.__name__
        global_tasks = []

        # Permission Invalidation
        if model_name in ("User", "LocalUser"):
            # If user roles changed, invalidate their permission cache
            user_id = entity.id if entity else id_to_invalidate
            if user_id:
                global_tasks.append(self._cache.delete_pattern(f"perm:{user_id}:*"))

        elif model_name == "CustomPermission":
            # Any custom rule change invalidates all permission caches
            # For finer grain, we could use perm:*:doctype:* but patterns are simple
            global_tasks.append(self._cache.delete_pattern("perm:*"))

        # Metadata/I18n Invalidation
        elif model_name in ("Translation", "TenantTranslation"):
            # Translations affect cached DocType metadata
            global_tasks.append(self._cache.delete_pattern("meta:*"))

        if global_tasks:
            await asyncio.gather(*global_tasks)

    async def get(
        self,
        session: AsyncSession,
        id: UUID,
        include_deleted: bool = False,
        as_of: datetime | None = None,
    ) -> T | None:
        """Retrieve an entity by its unique identifier.

        Args:
            session: SQLAlchemy async session
            id: The UUID of the entity
            include_deleted: If True, include soft-deleted entities

        Returns:
            The entity if found, None otherwise
        """
        if as_of is not None:
            return await self._get_as_of(session, id, include_deleted, as_of)

        # Check cache first (only for non-deleted queries)
        if self._cache and not include_deleted:
            cache_key = self._cache_key(id)
            cached = await self._cache.get(cache_key)
            if cached:
                logger.debug("CACHE HIT %s[%s]", self._model.__name__, id)
                return self._model.model_validate(cached)

        stmt = select(self._table).where(self._table.c.id == id)

        # Filter soft-deleted by default
        if not include_deleted and hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        logger.debug(
            "GET %s[%s] (include_deleted=%s)",
            self._model.__name__,
            id,
            include_deleted,
        )

        result = await session.execute(stmt)
        row = result.first()

        if row is None:
            return None

        entity = self._row_to_entity(row)

        # Load child tables
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields and entity:
            await self._child_table_manager.load_child_tables(
                session, entity, child_fields
            )

        # Cache the result
        if self._cache and entity and not include_deleted:
            cache_key = self._cache_key(id)
            await self._cache.set(cache_key, entity.model_dump(mode="json"), ttl=300)
            logger.debug("CACHE SET %s[%s]", self._model.__name__, id)

        return entity

    async def get_by_name(
        self, session: AsyncSession, name: str, include_deleted: bool = False
    ) -> T | None:
        """Retrieve an entity by its human-readable name.

        Args:
            session: SQLAlchemy async session
            name: The name of the entity
            include_deleted: If True, include soft-deleted entities

        Returns:
            The entity if found, None otherwise
        """
        # Check cache first (only for non-deleted queries)
        if self._cache and not include_deleted:
            cache_key = self._cache_key_by_name(name)
            cached = await self._cache.get(cache_key)
            if cached:
                logger.debug("CACHE HIT %s[name=%s]", self._model.__name__, name)
                return self._model.model_validate(cached)

        stmt = select(self._table).where(self._table.c.name == name)

        if not include_deleted and hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        result = await session.execute(stmt)
        row = result.first()

        if row is None:
            return None

        entity = self._row_to_entity(row)

        # Cache result
        if self._cache and entity and not include_deleted:
            cache_key = self._cache_key_by_name(name)
            # Store in cache for 5 minutes
            await self._cache.set(cache_key, entity.model_dump(mode="json"), ttl=300)
            # Also cache by ID if we have it
            await self._cache.set(
                self._cache_key(entity.id), entity.model_dump(mode="json"), ttl=300
            )

        return entity

    async def save(
        self, session: AsyncSession, entity: T, version: int | None = None
    ) -> T:
        """Persist an entity (insert or update).

        Args:
            session: SQLAlchemy async session
            entity: The entity to save
            version: Expected version for OCC (optional)

        Returns:
            The saved entity with updated fields

        Raises:
            VersionConflictError: If version doesn't match (OCC)
            DuplicateNameError: If name collision persists after retries
        """
        # Track if we auto-generated the name (for retry logic)
        auto_generated_name = entity.name is None

        # Generate name if not set
        if auto_generated_name:
            entity.name = await self._naming_service.generate_name(session, entity)

        # Check if entity exists
        is_new = not await self._entity_exists(session, entity)

        # Get controller instance if available
        controller = self._get_controller(entity)

        if is_new:
            saved_entity = await self._insert_with_retry(
                session, entity, controller, auto_generated_name
            )
            await self._call_hook(controller, "after_naming")
            return saved_entity
        else:
            return await self._update(session, entity, controller, version)

    async def delete(self, session: AsyncSession, id: UUID, hard: bool = False) -> None:
        """Delete an entity by its unique identifier.

        By default performs soft-delete (sets deleted_at). Use hard=True
        for physical deletion.

        Args:
            session: SQLAlchemy async session
            id: The UUID of the entity to delete
            hard: If True, physically delete; otherwise soft-delete
        """
        # Get entity for lifecycle hooks and event emission
        entity = await self.get(session, id)
        controller = None
        if entity and self._controller_class is not None:
            controller = self._get_controller(entity)

        # Lifecycle: before_delete
        if controller:
            await controller.before_delete()

        # Delete child tables first (cascade)
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields:
            await self._child_table_manager.delete_child_tables(
                session, id, child_fields
            )

        if hard:
            # Physical delete
            delete_stmt = sql_delete(self._table).where(self._table.c.id == id)
            await session.execute(delete_stmt)
        else:
            # Soft delete
            update_stmt = (
                update(self._table)
                .where(self._table.c.id == id)
                .values(deleted_at=datetime.now(UTC))
            )
            await session.execute(update_stmt)

        # Lifecycle: after_delete
        if controller:
            await controller.after_delete()

        # Emit delete event
        if entity:
            await self._emit_event("delete", entity)

        # Invalidate cache
        await self._invalidate_cache(entity, id_to_invalidate=id)
        logger.debug("CACHE INVALIDATE %s[%s]", self._model.__name__, id)

    async def exists(self, session: AsyncSession, id: UUID) -> bool:
        """Check if an entity exists by its identifier.

        Args:
            session: SQLAlchemy async session
            id: The UUID to check

        Returns:
            True if entity exists and is not soft-deleted
        """
        stmt = (
            select(func.count()).select_from(self._table).where(self._table.c.id == id)
        )
        if hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        result = await session.execute(stmt)
        count = result.scalar()
        return count is not None and count > 0

    async def count(
        self, session: AsyncSession, filters: list[FilterSpec] | None = None
    ) -> int:
        """Count entities matching the given filters.

        Args:
            session: SQLAlchemy async session
            filters: Optional list of filter conditions

        Returns:
            Total count of matching entities
        """
        stmt = select(func.count()).select_from(self._table)

        # Exclude soft-deleted
        if hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        if filters:
            stmt = self._apply_filters(stmt, filters)

        result = await session.execute(stmt)
        return result.scalar() or 0

    async def list_entities(
        self,
        session: AsyncSession,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
        as_of: datetime | None = None,
    ) -> PaginatedResult[T]:
        """List entities with filtering, sorting, and pagination.

        Args:
            session: SQLAlchemy async session
            filters: Filter conditions
            order_by: Sort specifications
            limit: Maximum number of items (default 20, max 1000)
            offset: Number of items to skip

        Returns:
            PaginatedResult containing items and metadata
        """
        if as_of is not None:
            return await self._list_entities_as_of(
                session=session,
                as_of=as_of,
                filters=filters,
                order_by=order_by,
                limit=limit,
                offset=offset,
            )

        # Enforce max limit
        effective_limit = min(limit, 1000)

        # Build base query
        stmt = select(self._table)

        # Exclude soft-deleted
        if hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        if filters is not None:
            stmt = self._apply_filters(stmt, filters)

        # Get total count
        total = await self.count(session, filters)

        # Apply ordering
        if order_by is not None:
            stmt = self._apply_ordering(stmt, order_by)

        # Apply pagination
        stmt = stmt.limit(effective_limit).offset(offset)

        logger.debug(
            "LIST %s (filters=%d, order_by=%d, limit=%d, offset=%d)",
            self._model.__name__,
            len(filters) if filters else 0,
            len(order_by) if order_by else 0,
            effective_limit,
            offset,
        )

        result = await session.execute(stmt)
        rows = result.fetchall()

        items = [self._row_to_entity(row) for row in rows]

        # Load child tables efficiently (select_in_loading)
        if items:
            child_fields = self._child_table_manager.get_child_table_fields()
            if child_fields:
                parent_ids = [item.id for item in items]
                for field_name, child_model in child_fields.items():
                    from framework_m_standard.adapters.db.table_registry import (
                        TableRegistry,
                    )

                    table_registry = TableRegistry()
                    child_table = table_registry.get_table(child_model.__name__)
                    if child_table is not None:
                        children_by_parent = (
                            await self._child_table_manager.load_children_for_parents(
                                session,
                                parent_ids,
                                child_table,
                                child_model,
                            )
                        )
                        for item in items:
                            item_id_str = str(item.id)
                            setattr(
                                item,
                                field_name,
                                children_by_parent.get(item_id_str, []),
                            )

        return PaginatedResult(
            items=items,
            total=total,
            limit=effective_limit,
            offset=offset,
        )

    def _get_history_table(self) -> Table:
        """Return the configured history table for this repository's model."""
        history_table_name = f"{self._table.name}_history"
        history_table = self._table.metadata.tables.get(history_table_name)
        if history_table is None:
            raise DatabaseError(
                "temporal_query",
                f"History table '{history_table_name}' not found",
            )
        return history_table

    def _ensure_temporal_query_supported(self) -> None:
        """Ensure temporal as_of query is valid for model/config."""
        if not getattr(self._model, "_versioning_enabled", False):
            raise TemporalQueryNotSupportedError(self._model.__name__)

        if not is_versioning_enabled():
            raise TemporalQueryNotSupportedError(self._model.__name__)

    async def _get_as_of(
        self,
        session: AsyncSession,
        id: UUID,
        include_deleted: bool,
        as_of: datetime,
    ) -> T | None:
        """Retrieve historical state from history table at a specific point in time."""
        self._ensure_temporal_query_supported()
        history_table = self._get_history_table()

        stmt = (
            select(history_table)
            .where(history_table.c.id == id)
            .where(history_table.c.modified <= as_of)
            .order_by(history_table.c._version_no.desc())
            .limit(1)
        )

        if not include_deleted and hasattr(history_table.c, "deleted_at"):
            stmt = stmt.where(history_table.c.deleted_at.is_(None))

        result = await session.execute(stmt)
        row = result.first()

        if row is None:
            return None

        entity = self._row_to_entity(row)

        # Load child tables using current child-table mechanism.
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields and entity:
            await self._child_table_manager.load_child_tables(
                session, entity, child_fields
            )

        return entity

    async def _list_entities_as_of(
        self,
        session: AsyncSession,
        as_of: datetime,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> PaginatedResult[T]:
        """List historical states from history table at a point in time."""
        self._ensure_temporal_query_supported()
        history_table = self._get_history_table()

        effective_limit = min(limit, 1000)

        latest_versions = (
            select(
                history_table.c.id.label("entity_id"),
                func.max(history_table.c._version_no).label("max_version"),
            )
            .where(history_table.c.modified <= as_of)
            .group_by(history_table.c.id)
            .subquery()
        )

        stmt = select(history_table).join(
            latest_versions,
            (history_table.c.id == latest_versions.c.entity_id)
            & (history_table.c._version_no == latest_versions.c.max_version),
        )

        if hasattr(history_table.c, "deleted_at"):
            stmt = stmt.where(history_table.c.deleted_at.is_(None))

        if filters is not None:
            stmt = self._apply_filters(stmt, filters, table=history_table)

        total_stmt = select(func.count()).select_from(stmt.subquery())
        total_result = await session.execute(total_stmt)
        total = total_result.scalar() or 0

        if order_by is not None:
            stmt = self._apply_ordering(stmt, order_by, table=history_table)

        stmt = stmt.limit(effective_limit).offset(offset)
        result = await session.execute(stmt)
        rows = result.fetchall()
        items = [self._row_to_entity(row) for row in rows]

        # Load child tables efficiently (select_in_loading)
        if items:
            child_fields = self._child_table_manager.get_child_table_fields()
            if child_fields:
                parent_ids = [item.id for item in items]
                for field_name, child_model in child_fields.items():
                    from framework_m_standard.adapters.db.table_registry import (
                        TableRegistry,
                    )

                    table_registry = TableRegistry()
                    child_table = table_registry.get_table(child_model.__name__)
                    if child_table is not None:
                        children_by_parent = (
                            await self._child_table_manager.load_children_for_parents(
                                session,
                                parent_ids,
                                child_table,
                                child_model,
                            )
                        )
                        for item in items:
                            item_id_str = str(item.id)
                            setattr(
                                item,
                                field_name,
                                children_by_parent.get(item_id_str, []),
                            )

        return PaginatedResult(
            items=items,
            total=total,
            limit=effective_limit,
            offset=offset,
        )

    async def list_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> PaginatedResult[T]:
        """List entities with RLS filtering applied.

        This method automatically applies Row-Level Security filters
        based on the user's permissions and the DocType's RLS settings.

        Args:
            session: SQLAlchemy async session
            user: Current user context (None for public access)
            filters: Additional filter conditions
            order_by: Sort specifications
            limit: Maximum number of items (default 20, max 1000)
            offset: Number of items to skip

        Returns:
            PaginatedResult containing only items the user can access
        """
        return await self._rls_manager.list_for_user(
            session=session,
            user=user,
            filters=filters,
            order_by=order_by,
            limit=limit,
            offset=offset,
        )

    async def get_for_user(
        self,
        session: AsyncSession,
        user: UserContext,
        id: UUID,
        action: str = "read",
        include_deleted: bool = False,
    ) -> T:
        """Retrieve an entity with permission checking.

        Loads the entity and verifies the user has permission to access it.
        Raises PermissionDeniedError if access is denied.

        Args:
            session: SQLAlchemy async session
            user: Current user context
            id: The UUID of the entity
            action: The action to check (default: "read")
            include_deleted: If True, include soft-deleted entities

        Returns:
            The entity if found and accessible

        Raises:
            EntityNotFoundError: If entity does not exist
            PermissionDeniedError: If user lacks permission
        """
        return await self._rls_manager.get_for_user(
            session=session,
            user=user,
            id=id,
            action=action,
            include_deleted=include_deleted,
        )

    async def bulk_save(self, session: AsyncSession, entities: list[T]) -> list[T]:
        """Save multiple entities in a single operation.

        Uses SQLAlchemy bulk insert for new entities for better performance.
        For updates, falls back to individual saves due to version handling.

        Args:
            session: SQLAlchemy async session
            entities: List of entities to save

        Returns:
            List of saved entities with updated fields
        """
        if not entities:
            return []

        # Separate new and existing entities
        new_entities: list[T] = []
        existing_entities: list[T] = []

        for entity in entities:
            if await self._entity_exists(session, entity):
                existing_entities.append(entity)
            else:
                new_entities.append(entity)

        results: list[T] = []

        # Bulk insert new entities
        if new_entities:
            inserted = await self._bulk_insert(session, new_entities)
            results.extend(inserted)

        # Update existing entities individually (for version handling)
        for entity in existing_entities:
            saved = await self.save(session, entity)
            results.append(saved)

        return results

    async def _bulk_insert(self, session: AsyncSession, entities: list[T]) -> list[T]:
        """Bulk insert multiple new entities.

        Uses SQLAlchemy's bulk insert for better performance.

        Args:
            session: SQLAlchemy async session
            entities: List of new entities to insert

        Returns:
            List of inserted entities
        """
        if not entities:
            return []

        exclude_fields = self._get_excluded_fields()

        # Prepare all entity data
        values_list = []
        for entity in entities:
            # Generate name if not set
            if entity.name is None:
                entity.name = await self._naming_service.generate_name(session, entity)

            data = self._entity_to_db_payload(entity, exclude_fields)
            data["modified"] = datetime.now(UTC)
            values_list.append(data)

        # Execute bulk insert with error handling
        try:
            stmt = self._table.insert().values(values_list)
            await session.execute(stmt)
            logger.debug(
                "Bulk inserted %d %s entities",
                len(entities),
                self._model.__name__,
            )
        except SAIntegrityError as e:
            error_msg = str(e.orig) if e.orig else str(e)
            logger.error(
                "Bulk insert failed for %s: %s",
                self._model.__name__,
                error_msg,
                extra={"doctype": self._model.__name__, "count": len(entities)},
            )
            if "UNIQUE constraint" in error_msg or "duplicate key" in error_msg.lower():
                raise DuplicateNameError(self._model.__name__, "bulk") from e
            raise IntegrityError(error_msg) from e
        except SQLAlchemyError as e:
            logger.error(
                "Bulk insert database error for %s: %s",
                self._model.__name__,
                str(e),
                extra={"doctype": self._model.__name__, "operation": "bulk_insert"},
            )
            raise RepositoryError(f"Bulk insert failed: {e}") from e

        return entities

    # =========================================================================
    # Private Methods
    # =========================================================================

    def _row_to_entity(self, row: Any) -> T:
        """Convert a database row to an entity.

        Args:
            row: SQLAlchemy row result

        Returns:
            Entity instance
        """
        data = dict(row._mapping)

        # Get model field names to filter out db-only columns
        model_fields = set(self._model.model_fields.keys())

        # Filter data to only include model fields
        filtered_data: dict[str, Any] = {}
        for key, value in data.items():
            if key in model_fields:
                # Convert string booleans if needed
                if value == "true":
                    filtered_data[key] = True
                elif value == "false":
                    filtered_data[key] = False
                else:
                    filtered_data[key] = value

        return self._model.model_validate(filtered_data)

    async def _entity_exists(self, session: AsyncSession, entity: T) -> bool:
        """Check if an entity already exists in the database.

        Args:
            session: SQLAlchemy async session
            entity: The entity to check

        Returns:
            True if entity exists
        """
        entity_id = getattr(entity, "id", None)

        if entity_id is not None:
            stmt = (
                select(func.count())
                .select_from(self._table)
                .where(self._table.c.id == entity_id)
            )
            result = await session.execute(stmt)
            count = result.scalar()
            return count is not None and count > 0

        if entity.name is None:
            return False

        stmt = (
            select(func.count())
            .select_from(self._table)
            .where(self._table.c.name == entity.name)
        )
        result = await session.execute(stmt)
        count = result.scalar()
        return count is not None and count > 0

    def _get_controller(self, entity: T) -> BaseController[T] | None:
        """Get a controller instance for the entity.

        Args:
            entity: The entity

        Returns:
            Controller instance or None
        """
        if self._controller_class is None:
            return None
        return self._controller_class(entity)

    async def _call_hook(
        self,
        controller: BaseController[T] | None,
        hook_name: str,
        context: object = None,
    ) -> None:
        """Call a lifecycle hook on the controller if it exists.

        This helper method checks if the controller exists, if the hook method
        exists on the controller, and calls it with optional context.

        Args:
            controller: Optional controller instance
            hook_name: Name of the hook method to call (e.g., 'validate', 'before_save')
            context: Optional context to pass to the hook

        Raises:
            Any exception raised by the hook method is propagated to the caller
        """
        if controller is None:
            return

        hook_method = getattr(controller, hook_name, None)
        if hook_method is None:
            return

        if callable(hook_method):
            await hook_method(context)

    async def _emit_event(
        self,
        event_type: str,
        entity: T,
        changed_fields: list[str] | None = None,
    ) -> None:
        """Emit a domain event if event_bus is configured.

        Args:
            event_type: Event type suffix (e.g., "create", "update", "delete")
            entity: The entity that triggered the event
            changed_fields: List of changed field names (for updates)
        """
        if self._event_bus is None:
            return

        # Import here to avoid circular imports at module level
        from framework_m_core.events import DocCreated, DocDeleted, DocUpdated
        from framework_m_core.interfaces.event_bus import Event

        doctype_name = self._model.__name__
        doc_name = str(entity.name) if entity.name else str(entity.id)

        # Create appropriate event type
        event: Event
        if event_type == "create":
            event = DocCreated(
                doctype=doctype_name,
                doc_name=doc_name,
            )
        elif event_type == "update":
            event = DocUpdated(
                doctype=doctype_name,
                doc_name=doc_name,
                changed_fields=changed_fields or [],
            )
        elif event_type == "delete":
            event = DocDeleted(
                doctype=doctype_name,
                doc_name=doc_name,
            )
        else:
            # Fallback to generic event
            event = Event(
                id=str(uuid4()),
                type=f"{doctype_name}.{event_type}",
                source="framework_m",
                subject=f"{doctype_name}:{doc_name}",
                data={
                    "id": str(entity.id),
                    "name": entity.name,
                    "doctype": doctype_name,
                },
            )

        try:
            topic = f"doc.{event_type}"
            await self._event_bus.publish(topic, event)
            logger.debug(
                "Emitted event %s for %s",
                event.type,
                doc_name,
                extra={"doctype": doctype_name, "event_type": event_type},
            )
        except Exception as e:
            # Log but don't fail the operation if event emission fails
            logger.warning(
                "Failed to emit event %s: %s",
                event.type,
                str(e),
                extra={"doctype": doctype_name, "event_type": event_type},
            )

    async def _insert_with_retry(
        self,
        session: AsyncSession,
        entity: T,
        controller: BaseController[T] | None,
        auto_generated_name: bool,
        max_retries: int = 3,
    ) -> T:
        """Insert a new entity with retry on name collision.

        For auto-generated names, retries with a new name if DuplicateNameError
        occurs (e.g., from concurrent inserts with same counter value).
        For manually provided names, does not retry.

        Args:
            session: SQLAlchemy async session
            entity: The entity to insert
            controller: Optional controller for lifecycle hooks
            auto_generated_name: Whether name was auto-generated (enables retry)
            max_retries: Maximum number of retry attempts (default 3)

        Returns:
            The inserted entity

        Raises:
            DuplicateNameError: If collision persists after max retries (or manual name)
        """
        for attempt in range(max_retries + 1):
            try:
                return await self._insert(session, entity, controller)
            except DuplicateNameError:
                if not auto_generated_name or attempt >= max_retries:
                    # Manual name or max retries exceeded - propagate error
                    raise
                # Retry with new generated name
                logger.debug(
                    "Name collision on %s attempt %d, regenerating",
                    entity.name,
                    attempt + 1,
                )
                entity.name = await self._naming_service.generate_name(session, entity)

        # Should not reach here, but satisfy type checker
        return await self._insert(session, entity, controller)

    async def _insert(
        self, session: AsyncSession, entity: T, controller: BaseController[T] | None
    ) -> T:
        """Insert a new entity.

        Args:
            session: SQLAlchemy async session
            entity: The entity to insert
            controller: Optional controller for lifecycle hooks

        Returns:
            The inserted entity
        """
        # Fetch values from linked documents
        await self._link_fetching_service.fetch_link_values(session, entity)

        # Lifecycle hooks: validate, before_insert, before_save
        await self._call_hook(controller, "validate")
        await self._call_hook(controller, "before_insert")
        await self._call_hook(controller, "before_save")

        # Prepare data (exclude child/computed fields, include DB columns)
        exclude_fields = self._get_excluded_fields()
        data = self._entity_to_db_payload(entity, exclude_fields)
        modified_at = datetime.now(UTC)
        data["modified"] = modified_at

        # Execute insert with error handling
        try:
            stmt = self._table.insert().values(**data)
            await session.execute(stmt)
            await session.flush()  # Ensure INSERT is written to DB
            await self._write_history_snapshot_on_save(
                session=session,
                entity=entity,
                valid_from=modified_at,
            )
        except SAIntegrityError as e:
            error_msg = str(e.orig) if e.orig else str(e)
            logger.error(
                "Insert failed for %s: %s",
                self._model.__name__,
                error_msg,
                extra={"doctype": self._model.__name__, "entity_name": entity.name},
            )
            # Check for duplicate name error
            if "UNIQUE constraint" in error_msg or "duplicate key" in error_msg.lower():
                raise DuplicateNameError(self._model.__name__, entity.name or "") from e
            raise IntegrityError(error_msg) from e
        except OperationalError as e:
            logger.error(
                "Database operation failed for %s: %s",
                self._model.__name__,
                str(e),
                extra={"doctype": self._model.__name__, "operation": "insert"},
            )
            raise DatabaseError("insert", str(e)) from e
        except SQLAlchemyError as e:
            logger.error(
                "Unexpected database error for %s: %s",
                self._model.__name__,
                str(e),
                extra={"doctype": self._model.__name__, "operation": "insert"},
            )
            raise RepositoryError(f"Insert failed: {e}") from e

        # Lifecycle hooks: after_save, after_insert
        await self._call_hook(controller, "after_save")
        await self._call_hook(controller, "after_insert")

        # Save child tables
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields:
            await self._child_table_manager.save_child_tables(
                session, entity, child_fields
            )

        # Emit create event
        await self._emit_event("create", entity)

        return entity

    async def _update(
        self,
        session: AsyncSession,
        entity: T,
        controller: BaseController[T] | None,
        version: int | None = None,
    ) -> T:
        """Update an existing entity.

        Args:
            session: SQLAlchemy async session
            entity: The entity to update
            controller: Optional controller for lifecycle hooks
            version: Expected version for OCC

        Returns:
            The updated entity

        Raises:
            VersionConflictError: If version doesn't match
        """
        existing_entity: T | None = None
        previous_docstatus: object | None = None
        requires_docstatus_checks = hasattr(entity, "docstatus")
        requires_audit_snapshot = (
            controller is not None
            and getattr(controller, "_audit_adapter", None) is not None
        )
        should_load_existing = controller is not None and (
            requires_docstatus_checks or requires_audit_snapshot
        )

        if should_load_existing:
            entity_id = getattr(entity, "id", None)
            if entity_id is not None:
                existing_stmt = select(self._table).where(self._table.c.id == entity_id)
            else:
                existing_stmt = select(self._table).where(
                    self._table.c.name == entity.name
                )

            existing_result = await session.execute(existing_stmt)
            existing_row = existing_result.first()
            if existing_row is not None:
                row_mapping = getattr(existing_row, "_mapping", None)
                if isinstance(row_mapping, Mapping):
                    try:
                        existing_entity = self._row_to_entity(existing_row)
                    except Exception:
                        # Non-standard row payloads (common in unit-test mocks) should
                        # not block normal update semantics.
                        existing_entity = None

        if existing_entity is not None:
            previous_docstatus = getattr(existing_entity, "docstatus", None)

            if (
                controller is not None
                and getattr(controller, "_pre_save_snapshot", None) is None
            ):
                controller._pre_save_snapshot = existing_entity.model_dump()

            if controller is not None and requires_docstatus_checks:
                await controller._validate_submitted_changes(entity, existing_entity)

        # Fetch values from linked documents
        await self._link_fetching_service.fetch_link_values(session, entity)

        # Lifecycle hooks: validate, before_save
        await self._call_hook(controller, "validate")
        await self._call_hook(controller, "before_save")

        # Prepare data (exclude child/computed fields, include DB columns)
        exclude_fields = self._get_excluded_fields()
        data = self._entity_to_db_payload(entity, exclude_fields)
        modified_at = datetime.now(UTC)
        data["modified"] = modified_at

        # Build update statement
        entity_id = getattr(entity, "id", None)
        if entity_id is not None:
            stmt = update(self._table).where(self._table.c.id == entity_id)
        else:
            stmt = update(self._table).where(self._table.c.name == entity.name)

        # OCC: Add version check if provided
        if version is not None:
            stmt = stmt.where(self._table.c._version == version)
            data["_version"] = version + 1

        stmt = stmt.values(**data)
        result = await session.execute(stmt)

        # OCC: Check if update succeeded
        # Access rowcount via getattr for type safety with async results
        rowcount: int = getattr(result, "rowcount", 0)
        if version is not None and rowcount == 0:
            raise VersionConflictError(
                entity_id=entity.name if entity.name else "unknown",  # type: ignore[arg-type]
                expected_version=version,
            )

        await session.flush()
        await self._write_history_snapshot_on_save(
            session=session,
            entity=entity,
            valid_from=modified_at,
        )

        # Invalidate cache
        await self._invalidate_cache(entity)

        # Lifecycle hook: after_save
        await self._call_hook(controller, "after_save")

        # Lifecycle hooks: on_submit / on_cancel for docstatus transitions
        if controller is not None and previous_docstatus is not None:
            from framework_m_core.domain.mixins import DocStatus

            current_docstatus = getattr(entity, "docstatus", None)
            if (
                previous_docstatus != DocStatus.SUBMITTED
                and current_docstatus == DocStatus.SUBMITTED
            ):
                await self._call_hook(controller, "on_submit")
            elif (
                previous_docstatus != DocStatus.CANCELLED
                and current_docstatus == DocStatus.CANCELLED
            ):
                await self._call_hook(controller, "on_cancel")

        # Update child tables (delete old, insert new)
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields and entity.id:
            # Delete old children
            await self._child_table_manager.delete_child_tables(
                session, entity.id, child_fields
            )
            # Save new children
            await self._child_table_manager.save_child_tables(
                session, entity, child_fields
            )

        # Emit update event
        await self._emit_event("update", entity)

        # Invalidate cache after update
        await self._invalidate_cache(entity)
        if entity.id:
            logger.debug("CACHE INVALIDATE %s[%s]", self._model.__name__, entity.id)

        return entity

    def _apply_filters(
        self,
        stmt: Any,
        filters: list[FilterSpec],
        table: Table | None = None,
    ) -> Any:
        """Apply filter conditions to a query.

        Args:
            stmt: SQLAlchemy statement
            filters: List of filter specs

        Returns:
            Modified statement
        """
        source_table = table or self._table
        for f in filters:
            column = getattr(source_table.c, f.field)

            match f.operator:
                case FilterOperator.EQ:
                    stmt = stmt.where(column == f.value)
                case FilterOperator.NE:
                    stmt = stmt.where(column != f.value)
                case FilterOperator.LT:
                    stmt = stmt.where(column < f.value)
                case FilterOperator.LTE:
                    stmt = stmt.where(column <= f.value)
                case FilterOperator.GT:
                    stmt = stmt.where(column > f.value)
                case FilterOperator.GTE:
                    stmt = stmt.where(column >= f.value)
                case FilterOperator.IN:
                    stmt = stmt.where(column.in_(f.value))
                case FilterOperator.NOT_IN:
                    stmt = stmt.where(~column.in_(f.value))
                case FilterOperator.LIKE:
                    stmt = stmt.where(column.like(f.value))
                case FilterOperator.IS_NULL:
                    if f.value:
                        stmt = stmt.where(column.is_(None))
                    else:
                        stmt = stmt.where(column.is_not(None))

        return stmt

    def _apply_ordering(
        self,
        stmt: Any,
        order_by: list[OrderSpec],
        table: Table | None = None,
    ) -> Any:
        """Apply ordering to a query.

        Args:
            stmt: SQLAlchemy statement
            order_by: List of order specs

        Returns:
            Modified statement
        """
        source_table = table or self._table
        for spec in order_by:
            if hasattr(source_table.c, spec.field):
                column = getattr(source_table.c, spec.field)
                if spec.direction == OrderDirection.DESC:
                    stmt = stmt.order_by(column.desc())
                else:
                    stmt = stmt.order_by(column.asc())
            else:
                logger.warning(
                    "Invalid sort field '%s' for model %s (ignored)",
                    spec.field,
                    self._model.__name__,
                )

        return stmt

    # ==========================================
    # Bulk Operations with RLS
    # ==========================================

    async def delete_many_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        hard: bool = False,
    ) -> int:
        """Delete multiple entities with RLS filtering.

        IMPORTANT: RLS is applied so users can only delete their own documents.
        Admin/System users bypass RLS and can delete all matching documents.
        If user is None, no RLS is applied (for public DocTypes).

        Args:
            session: SQLAlchemy async session
            user: Current user context (None bypasses RLS for public access)
            filters: Additional filter conditions
            hard: If True, physically delete; otherwise soft-delete

        Returns:
            Number of documents deleted
        """
        return await self._rls_manager.delete_many_for_user(
            session=session, user=user, filters=filters, hard=hard
        )

    async def update_many_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        data: dict[str, Any] | None = None,
    ) -> int:
        """Update multiple entities with RLS filtering.

        IMPORTANT: RLS is applied so users can only update their own documents.
        Admin/System users bypass RLS and can update all matching documents.
        If user is None, no RLS is applied (for public DocTypes).

        Args:
            session: SQLAlchemy async session
            user: Current user context (None bypasses RLS for public access)
            filters: Additional filter conditions
            data: Fields to update

        Returns:
            Number of documents updated
        """
        return await self._rls_manager.update_many_for_user(
            session=session, user=user, filters=filters, data=data
        )

    # ==========================================
    # Field Exclusion Helpers
    # ==========================================

    def _get_excluded_fields(self) -> set[str]:
        """Get fields that should be excluded from database operations.

        This includes:
        - Child table fields (list[ChildDocType])
        - Computed fields (@computed_field properties)

        Returns:
            Set of field names to exclude from INSERT/UPDATE.
        """
        excluded: set[str] = set()

        # Exclude child table fields
        child_fields = self._child_table_manager.get_child_table_fields()
        excluded.update(child_fields.keys())

        # Exclude computed fields (Pydantic's model_computed_fields)
        computed_fields = getattr(self._model, "model_computed_fields", {})
        excluded.update(computed_fields.keys())

        return excluded

    def _entity_to_db_payload(
        self, entity: T, exclude_fields: set[str]
    ) -> dict[str, Any]:
        """Build DB payload from entity attributes.

        Uses model attributes directly rather than ``model_dump()`` so fields marked
        with ``exclude=True`` (for API serialization safety) are still persisted when
        they map to real table columns, e.g. ``LocalUser.password_hash``.

        Args:
            entity: Entity to serialize for DB write
            exclude_fields: Model fields to exclude (child/computed)

        Returns:
            Dict of column name to value for INSERT/UPDATE
        """
        table_columns = {column.name for column in self._table.columns}
        payload: dict[str, Any] = {}

        for field_name in self._model.model_fields:
            if field_name in exclude_fields or field_name not in table_columns:
                continue
            payload[field_name] = getattr(entity, field_name, None)

        return payload

    async def _write_history_snapshot_on_save(
        self,
        session: AsyncSession,
        entity: T,
        valid_from: datetime,
    ) -> None:
        """Write a version snapshot row after successful insert/update."""
        if not getattr(self._model, "_versioning_enabled", False):
            return

        if not is_versioning_enabled():
            return

        history_table_name = f"{self._table.name}_history"
        history_table = self._table.metadata.tables.get(history_table_name)
        if history_table is None:
            logger.debug(
                "Skipping history write for %s because table '%s' is not provisioned",
                self._model.__name__,
                history_table_name,
            )
            return

        row_data = await self._get_persisted_row_data(session, entity)
        entity_id = row_data.get("id")

        if entity_id is None:
            raise DatabaseError(
                "versioning",
                f"Cannot write history snapshot for {self._model.__name__}: missing id",
            )

        audit_db_url = history_table.info.get("audit_db_url")
        current_db_url = self._get_session_db_url(session)

        if (
            isinstance(audit_db_url, str)
            and audit_db_url
            and current_db_url != audit_db_url
        ):
            audit_engine = create_async_engine(audit_db_url, pool_pre_ping=True)
            try:
                async with audit_engine.begin() as conn:
                    await self._write_history_row(
                        execute=conn.execute,
                        history_table=history_table,
                        row_data=row_data,
                        entity_id=entity_id,
                        valid_from=valid_from,
                    )
            finally:
                await audit_engine.dispose()
            return

        await self._write_history_row(
            execute=session.execute,
            history_table=history_table,
            row_data=row_data,
            entity_id=entity_id,
            valid_from=valid_from,
        )

    async def _get_persisted_row_data(
        self,
        session: AsyncSession,
        entity: T,
    ) -> dict[str, Any]:
        """Read the latest persisted main-table row for the entity."""
        entity_id = getattr(entity, "id", None)

        if entity_id is not None:
            stmt = select(self._table).where(self._table.c.id == entity_id)
        else:
            stmt = select(self._table).where(self._table.c.name == entity.name)

        result = await session.execute(stmt)
        row = result.first()
        if row is None:
            raise DatabaseError(
                "versioning",
                f"Cannot fetch persisted row for {self._model.__name__}",
            )

        return dict(row._mapping)

    def _get_session_db_url(self, session: AsyncSession) -> str | None:
        """Return DB URL string for the current session bind."""
        bind = session.get_bind()
        bind_url = getattr(bind, "url", None)
        return str(bind_url) if bind_url is not None else None

    async def _write_history_row(
        self,
        execute: Any,
        history_table: Table,
        row_data: dict[str, Any],
        entity_id: Any,
        valid_from: datetime,
    ) -> None:
        """Insert a history snapshot and close prior valid window."""
        max_version_result = await execute(
            select(func.max(history_table.c._version_no)).where(
                history_table.c.id == entity_id
            )
        )
        max_version = max_version_result.scalar()
        next_version = (int(max_version) if max_version is not None else 0) + 1

        await execute(
            update(history_table)
            .where(history_table.c.id == entity_id)
            .where(history_table.c._valid_to.is_(None))
            .values(_valid_to=valid_from)
        )

        history_payload = dict(row_data)
        history_payload["_version_no"] = next_version
        history_payload["_valid_from"] = valid_from
        history_payload["_valid_to"] = None

        await execute(history_table.insert().values(**history_payload))


__all__ = ["GenericRepository", "VersionConflictError"]
