"""
Power method for 2-norm condition number estimation.

Estimates kappa_2(A) = σ_max / σ_min using power iteration.
"""

import cupy as cp
import cupyx.scipy.sparse as sp
from typing import Dict, Any
from ..utils import print_iteration, check_convergence


def power_method_cond(
    A: sp.spmatrix,
    max_iter: int = 100,
    tol: float = 1e-6,
    verbose: bool = False,
    **kwargs
) -> Dict[str, Any]:
    """
    Estimate 2-norm condition number using power method.
    
    kappa_2(A) = σ_max / σ_min where σ are singular values.
    
    Parameters
    ----------
    A : sparse matrix
        Input matrix (n x n)
    max_iter : int, default=100
        Maximum iterations
    tol : float, default=1e-6
        Convergence tolerance
    verbose : bool, default=False
        Print iteration information
    
    Returns
    -------
    result : dict
        - 'condition_number': estimated kappa_2(A)
        - 'sigma_max': largest singular value
        - 'sigma_min': smallest singular value
        - 'iterations': number of iterations
        - 'converged': convergence status
    
    Algorithm
    ---------
    1. Compute σ_max using power iteration on A^T A
    2. Compute σ_min using inverse power iteration on A^T A
    3. kappa_2(A) = σ_max / σ_min
    
    Complexity: O(k · nnz(A)) per iteration
    """
    if verbose:
        print("Power Method for 2-norm condition number")
        print(f"Matrix size: {A.shape[0]} x {A.shape[1]}")
    
    shift = kwargs.get('shift', None)

    # Compute largest singular value
    sigma_max, iter_max, conv_max = compute_sigma_max(A, max_iter, tol, verbose)
    
    # Compute smallest singular value
    if shift is not None:
        sigma_min, iter_min, conv_min = compute_sigma_min_shift_invert(A, max_iter, tol, verbose, shift=shift)
    else:
        sigma_min, iter_min, conv_min = compute_sigma_min(A, max_iter, tol, verbose)
    
    # Condition number
    if sigma_min < 1e-14:
        cond = float('inf')
    else:
        cond = sigma_max / sigma_min
    
    if verbose:
        print(f"\nσ_max = {sigma_max:.6e}")
        print(f"σ_min = {sigma_min:.6e}")
        print(f"kappa_2(A) = {cond:.6e}")
    
    return {
        'condition_number': float(cond),
        'sigma_max': float(sigma_max),
        'sigma_min': float(sigma_min),
        'iterations': iter_max + iter_min,
        'converged': conv_max and conv_min,
    }


def compute_sigma_max(
    A: sp.spmatrix,
    max_iter: int,
    tol: float,
    verbose: bool
) -> tuple:
    """
    Compute largest singular value using power iteration.
    
    Algorithm:
        v_new = A^T A v
        σ² = v^T v_new
        σ_max = sqrt(σ²)
    
    Returns
    -------
    sigma_max : float
        Largest singular value
    iterations : int
        Number of iterations
    converged : bool
        Convergence status
    """
    n = A.shape[1]
    
    # Random initial vector
    v = cp.random.randn(n).astype(A.dtype)
    v /= cp.linalg.norm(v)
    
    sigma_estimates = []
    
    for it in range(max_iter):
        # v_new = A^T A v
        Av = A @ v
        v_new = A.T @ Av
        
        # Rayleigh quotient
        sigma_sq = float(cp.dot(v, v_new))
        sigma = cp.sqrt(cp.abs(sigma_sq))
        
        # Normalize
        norm_v_new = cp.linalg.norm(v_new)
        if norm_v_new < 1e-14:
            # Converged to zero vector (matrix is zero)
            return 0.0, it + 1, True
        
        v_new /= norm_v_new
        
        sigma_estimates.append(float(sigma))
        
        if verbose and (it + 1) % 10 == 0:
            print_iteration(it + 1, float(sigma), extra="σ_max")
        
        # Check convergence
        if check_convergence(cp.array(sigma_estimates), tol):
            return float(sigma), it + 1, True
        
        v = v_new
    
    return float(sigma), max_iter, False


def compute_sigma_min(
    A: sp.spmatrix,
    max_iter: int,
    tol: float,
    verbose: bool
) -> tuple:
    """
    Compute smallest singular value using inverse power iteration.
    
    Correct implementation:
        Solve (A^T A) w = v
        λ = v^T (A^T A w) / (v^T w) 
        σ_min = sqrt(λ)
        v = w / ||w||
    
    Returns
    -------
    sigma_min : float
        Smallest singular value
    iterations : int
        Number of iterations
    converged : bool
        Convergence status
    """
    from cupyx.scipy.sparse.linalg import lsmr
    
    n = A.shape[1]
    
    # Random initial vector
    v = cp.random.randn(n).astype(A.dtype)
    v /= cp.linalg.norm(v)
    
    sigma_estimates = []
    
    for it in range(max_iter):
        # Solve (A^T A) w = v for w
        # This is the KEY step - we're solving for w, not computing A^T A v
        w, istop, itn, normr, normar, norma, conda, normx = lsmr(
            A.T @ A, v, 
            atol=1e-6, btol=1e-6, 
            maxiter=min(50, n)
        )
        
        # Check if solve succeeded
        if istop == 0:
            # Did not converge, try with relaxed tolerance
            w, istop, itn, normr, normar, norma, conda, normx = lsmr(
                A.T @ A, v,
                atol=1e-3, btol=1e-3,
                maxiter=min(100, n)
            )
        
        # Compute A^T A w
        Aw = A @ w
        ATA_w = A.T @ Aw
        
        # Rayleigh quotient: λ = (v^T (A^T A w)) / (v^T w)
        numerator = float(cp.dot(v, ATA_w))
        denominator = float(cp.dot(v, w))
        
        if abs(denominator) < 1e-14:
            # w ≈ 0, matrix is nearly singular
            return 0.0, it + 1, True
        
        lambda_val = numerator / denominator
        
        # σ = sqrt(λ) where λ is eigenvalue of A^T A
        if lambda_val < 0:
            # Should not happen, but handle numerical issues
            lambda_val = abs(lambda_val)
        
        sigma = cp.sqrt(lambda_val)
        
        # Normalize w for next iteration
        norm_w = cp.linalg.norm(w)
        if norm_w < 1e-14:
            return 0.0, it + 1, True
        
        w /= norm_w
        
        sigma_estimates.append(float(sigma))
        
        if verbose and (it + 1) % 10 == 0:
            print_iteration(it + 1, float(sigma), extra="σ_min")
        
        # Check convergence
        if check_convergence(cp.array(sigma_estimates), tol):
            return float(sigma), it + 1, True
        
        v = w
    
    return float(sigma), max_iter, False


def compute_sigma_min_shift_invert(
    A: sp.spmatrix,
    max_iter: int,
    tol: float,
    verbose: bool,
    shift: float = None
) -> tuple:
    """
    Compute smallest singular value using shift-invert power iteration.
    
    More stable than plain inverse iteration.
    
    Algorithm:
        If shift = 0 (default):
            Solve (A^T A) w = v
        Else:
            Solve (A^T A - shift·I) w = v
        
        λ = (v^T (A^T A w)) / (v^T w) + shift
        σ_min = sqrt(λ)
    
    Returns
    -------
    sigma_min : float
        Smallest singular value
    iterations : int
        Number of iterations
    converged : bool
        Convergence status
    """
    from cupyx.scipy.sparse.linalg import lsmr
    from cupyx.scipy.sparse import eye
    
    n = A.shape[1]
    
    # Estimate shift if not provided
    if shift is None:
        shift = 0.0
    
    # Build operator (A^T A - shift·I)
    ATA = A.T @ A
    if shift != 0:
        ATA = ATA - shift * eye(n, dtype=A.dtype)
    
    # Random initial vector
    v = cp.random.randn(n).astype(A.dtype)
    v /= cp.linalg.norm(v)
    
    sigma_estimates = []
    
    for it in range(max_iter):
        # Solve (A^T A - shift·I) w = v
        w, istop, itn, normr, normar, norma, conda, normx = lsmr(
            ATA, v,
            atol=1e-6, btol=1e-6,
            maxiter=min(50, n)
        )
        
        # Compute actual A^T A w (without shift)
        Aw = A @ w
        ATA_w = A.T @ Aw
        
        # Rayleigh quotient
        numerator = float(cp.dot(v, ATA_w))
        denominator = float(cp.dot(v, w))
        
        if abs(denominator) < 1e-14:
            return 0.0, it + 1, True
        
        # Eigenvalue of A^T A (accounting for shift)
        lambda_val = numerator / denominator
        
        if lambda_val < 0:
            lambda_val = abs(lambda_val)
        
        sigma = cp.sqrt(lambda_val)
        
        # Normalize
        norm_w = cp.linalg.norm(w)
        if norm_w < 1e-14:
            return 0.0, it + 1, True
        
        w /= norm_w
        
        sigma_estimates.append(float(sigma))
        
        if verbose and (it + 1) % 10 == 0:
            print_iteration(it + 1, float(sigma), extra="σ_min (shift-invert)")
        
        if check_convergence(cp.array(sigma_estimates), tol):
            return float(sigma), it + 1, True
        
        v = w
    
    return float(sigma), max_iter, False