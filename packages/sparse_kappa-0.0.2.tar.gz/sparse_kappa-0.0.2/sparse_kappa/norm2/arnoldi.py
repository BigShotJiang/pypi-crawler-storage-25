"""
Arnoldi method for 2-norm condition number estimation.

Generalization of Lanczos for non-symmetric matrices.
"""

import cupy as cp
import cupyx.scipy.sparse as sp
from typing import Dict, Any
from ..utils import print_iteration


def arnoldi_cond(
    A: sp.spmatrix,
    max_iter: int = 50,
    tol: float = 1e-6,
    verbose: bool = False,
    restart: int = 20,
    **kwargs
) -> Dict[str, Any]:
    """
    Estimate 2-norm condition number using Arnoldi iteration.
    
    Applies Arnoldi to A^T A to compute extreme eigenvalues.
    
    Parameters
    ----------
    A : sparse matrix
        Input matrix
    max_iter : int, default=50
        Maximum iterations
    tol : float, default=1e-6
        Convergence tolerance
    verbose : bool, default=False
        Print information
    restart : int, default=20
        Restart parameter for Arnoldi
    
    Returns
    -------
    result : dict
        - 'condition_number': estimated kappa_2(A)
        - 'sigma_max': largest singular value
        - 'sigma_min': smallest singular value
        - 'iterations': number of iterations
        - 'converged': convergence status
    
    Algorithm
    ---------
    Arnoldi iteration builds orthonormal basis for Krylov subspace.
    Projection onto this basis gives Hessenberg matrix H.
    Eigenvalues of H approximate eigenvalues of A^T A.
    
    Complexity: O(k² · nnz(A)) for k Arnoldi iterations
    """
    if verbose:
        print("Arnoldi method for 2-norm condition number")
        print(f"Matrix size: {A.shape[0]} x {A.shape[1]}")
    
    # Use implicitly restarted Arnoldi (via eigsh/eigs)
    from cupyx.scipy.sparse.linalg import eigs
    
    n = A.shape[1]
    
    # Form linear operator for A^T A
    def matvec(v):
        return A.T @ (A @ v)
    
    from cupyx.scipy.sparse.linalg import LinearOperator
    ATA = LinearOperator((n, n), matvec=matvec, dtype=A.dtype)
    
    try:
        # Compute largest eigenvalues
        k = min(6, n - 2)
        eigvals_large, _ = eigs(ATA, k=k, which='LM', maxiter=max_iter, tol=tol)
        eigvals_large = cp.real(eigvals_large)
        
        # Compute smallest eigenvalues
        eigvals_small, _ = eigs(ATA, k=k, which='SM', maxiter=max_iter, tol=tol)
        eigvals_small = cp.real(eigvals_small)
        
        sigma_max = float(cp.sqrt(cp.max(cp.abs(eigvals_large))))
        sigma_min = float(cp.sqrt(cp.min(cp.abs(eigvals_small))))
        
        converged = True
        iterations = max_iter
        
    except Exception as e:
        if verbose:
            print(f"Warning: Arnoldi failed: {e}, using fallback")
        
        # Fallback: simple power method
        from .power_method import compute_sigma_max, compute_sigma_min
        sigma_max, iter1, conv1 = compute_sigma_max(A, max_iter, tol, False)
        sigma_min, iter2, conv2 = compute_sigma_min(A, max_iter, tol, False)
        converged = conv1 and conv2
        iterations = iter1 + iter2
    
    cond = sigma_max / sigma_min
    
    if verbose:
        print(f"\nσ_max = {sigma_max:.6e}")
        print(f"σ_min = {sigma_min:.6e}")
        print(f"kappa_2(A) = {cond:.6e}")
    
    return {
        'condition_number': float(cond),
        'sigma_max': sigma_max,
        'sigma_min': sigma_min,
        'iterations': iterations,
        'converged': converged,
    }