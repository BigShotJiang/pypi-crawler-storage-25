"""
Block Higham-Tisseur 1-norm estimator for kappa_1(A).

Estimates ||A^{-1}||_1 implicitly using a block 1-norm estimator
applied to the linear operator B = A^{-1}, then returns

    kappa_1(A) ~= ||A||_1 * est(||A^{-1}||_1)

Reference
---------
Higham, N. J., & Tisseur, F. (2000).
A block algorithm for matrix 1-norm estimation,
with an application to 1-norm pseudospectra.
SIAM J. Matrix Anal. Appl., 21(4), 1185-1201.
"""

import cupy as cp
import cupyx.scipy.sparse as sp
from typing import Dict, Any, Tuple, List, Set
from ..utils import print_iteration, sparse_matrix_norm
from ..solvers import create_solver


def block_higham_tisseur_norm1(
    A: sp.spmatrix,
    block_size: int = 2,
    max_iter: int = 5,
    verbose: bool = False,
    solver: str = "lu",
    solver_kwargs: Dict[str, Any] = None,
    random_state: int = 1234,
    parallel_tol: float = 0.9,
    **kwargs,
) -> Dict[str, Any]:
    """
    Estimate kappa_1(A) = ||A||_1 * ||A^{-1}||_1 using a block
    Higham-Tisseur style 1-norm estimator applied to B = A^{-1}.

    Parameters
    ----------
    A : sparse matrix
        Real square sparse matrix.
    block_size : int, default=2
        Number of block columns (t in the paper). Typical useful values are 2..5.
    max_iter : int, default=5
        Maximum block iterations.
    verbose : bool, default=False
        Print progress.
    solver : str, default='lu'
        Linear solver used for solves with A and A^T.
    solver_kwargs : dict, optional
        Extra keyword arguments forwarded to create_solver().
    random_state : int, default=1234
        Seed for random sign initialization / resampling.
    parallel_tol : float, default=0.9
        Cosine similarity threshold used to detect nearly parallel sign columns.

    Returns
    -------
    result : dict
        - 'condition_number'
        - 'norm_A'
        - 'norm_Ainv'
        - 'iterations'
        - 'converged'
        - 'solver_info'
    """
    if A.shape[0] != A.shape[1]:
        raise ValueError("Block 1-norm condition estimation requires a square matrix.")

    n = A.shape[0]
    if n == 0:
        raise ValueError("Matrix must be nonempty.")

    if cp.iscomplexobj(A.data):
        raise ValueError(
            "This implementation currently supports real matrices only."
        )

    if block_size < 1:
        raise ValueError("block_size must be >= 1.")

    t = min(block_size, n)

    if solver_kwargs is None:
        solver_kwargs = {}

    norm_A = sparse_matrix_norm(A, ord=1)

    if verbose:
        print("Block Higham-Tisseur 1-norm condition estimation")
        print(f"Matrix size: {n} x {n}, NNZ: {A.nnz}")
        print(f"Block size: {t}")
        print(f"Solver: {solver}")
        print(f"||A||_1 = {norm_A:.6e}")
        print("Estimating ||A^{-1}||_1 ...")

    solver_A = create_solver(A, solver, **solver_kwargs)
    solver_AT = create_solver(A.T, solver, **solver_kwargs)

    norm_Ainv, iterations, converged = _block_inverse_onenorm_estimate(
        solver_A=solver_A,
        solver_AT=solver_AT,
        n=n,
        t=t,
        max_iter=max_iter,
        random_state=random_state,
        parallel_tol=parallel_tol,
        verbose=verbose,
    )

    cond = norm_A * norm_Ainv

    if verbose:
        print(f"\nEstimated ||A^(-1)||_1 = {norm_Ainv:.6e}")
        print(f"Estimated kappa_1(A) = {cond:.6e}")
        print(f"Converged: {converged} after {iterations} iterations")

        if hasattr(solver_A, "solve_count") and hasattr(solver_AT, "solve_count"):
            print(f"Total solves: A={solver_A.solve_count}, A^T={solver_AT.solve_count}")

    return {
        "condition_number": float(cond),
        "norm_A": float(norm_A),
        "norm_Ainv": float(norm_Ainv),
        "iterations": int(iterations),
        "converged": bool(converged),
        "solver_info": {
            "solver_type": solver,
            "solver_A": solver_A.info(),
            "solver_AT": solver_AT.info(),
        },
    }


def _block_inverse_onenorm_estimate(
    solver_A,
    solver_AT,
    n: int,
    t: int,
    max_iter: int,
    random_state: int = 1234,
    parallel_tol: float = 0.9,
    verbose: bool = False,
) -> Tuple[float, int, bool]:
    """
    Estimate ||A^{-1}||_1 by applying a block 1-norm estimator
    to the implicit operator B = A^{-1}.

    The operator actions are:
        Y = B X      via solving A Y = X
        Z = B^T S    via solving A^T Z = S

    Returns
    -------
    est : float
        Estimated ||A^{-1}||_1 (a lower bound in the usual estimator sense).
    iterations : int
        Number of block iterations.
    converged : bool
        Whether the iteration terminated by a discrete stop rule.
    """
    rng = cp.random.RandomState(random_state)
    dtype = solver_A.A.dtype

    # Initial block X:
    # first column = uniform positive vector, others = random ±1 / n
    X = cp.empty((n, t), dtype=dtype)
    X[:, 0] = cp.ones(n, dtype=dtype) / n

    for j in range(1, t):
        col = rng.choice(cp.array([-1.0, 1.0], dtype=dtype), size=n)
        X[:, j] = col / n

    X = _resample_parallel_columns(X, rng, parallel_tol, normalize_one_norm=False)

    est = 0.0
    est_old = -1.0
    best_j = 0
    best_col = None
    converged = False
    ind_hist: Set[int] = set()
    iterations = 0

    for k in range(max_iter):
        iterations = k + 1

        # Y = B X = A^{-1} X, solved columnwise
        Y = cp.empty_like(X)
        for j in range(t):
            Y[:, j] = solver_A.solve(X[:, j])

        # Column 1-norms determine the estimate
        col_norms = cp.sum(cp.abs(Y), axis=0)
        est = float(cp.max(col_norms))
        best_j = int(cp.argmax(col_norms))
        best_col = Y[:, best_j].copy()

        if verbose:
            print_iteration(iterations, est)

        # Stop if estimate no longer increases
        if est <= est_old:
            converged = True
            est = max(est, est_old)
            break
        est_old = est

        # S = sign(Y), with zeros mapped to +1
        S = cp.sign(Y)
        S[S == 0] = 1.0

        # Replace nearly parallel sign columns with fresh random sign columns
        S = _resample_parallel_columns(S, rng, parallel_tol, normalize_one_norm=False)

        # Z = B^T S = A^{-T} S, solved columnwise
        Z = cp.empty_like(S)
        for j in range(t):
            Z[:, j] = solver_AT.solve(S[:, j])

        # Row scores h_i = max_j |Z_{i,j}|
        H = cp.max(cp.abs(Z), axis=1)

        # Candidate indices: largest rows of H first
        order = cp.asnumpy(cp.argsort(-H))  # descending, on host for set logic

        # Choose up to t new indices, preferring unseen ones
        new_inds: List[int] = []
        for idx in order.tolist():
            if idx not in ind_hist:
                new_inds.append(idx)
            if len(new_inds) == t:
                break

        # If not enough unseen indices remain, fill from top rows
        if len(new_inds) < t:
            for idx in order.tolist():
                if idx not in new_inds:
                    new_inds.append(idx)
                if len(new_inds) == t:
                    break

        # If the top candidates are all already known, we are effectively stagnating
        if all(idx in ind_hist for idx in new_inds):
            converged = True
            break

        # Update index history
        for idx in new_inds:
            ind_hist.add(idx)

        # New X consists of selected standard basis vectors
        X_new = cp.zeros((n, t), dtype=dtype)
        for j, idx in enumerate(new_inds):
            X_new[idx, j] = 1.0

        X = X_new

    # Final guard: if nothing was produced, fail clearly
    if est < 0:
        raise RuntimeError("Block estimator failed to produce an estimate.")

    return float(est), iterations, converged


def _resample_parallel_columns(
    M: cp.ndarray,
    rng,
    parallel_tol: float = 0.9,
    normalize_one_norm: bool = False,
) -> cp.ndarray:
    """
    Replace columns that are identical or nearly parallel to earlier columns.

    For block sign matrices, this helps preserve diversity across the block,
    which is an important practical ingredient in block 1-norm estimation.
    """
    M = M.copy()
    n, t = M.shape

    for j in range(t):
        mj = M[:, j]
        mj_norm = cp.linalg.norm(mj)
        if mj_norm == 0:
            mj = rng.choice(cp.array([-1.0, 1.0], dtype=M.dtype), size=n)
            M[:, j] = mj
            mj_norm = cp.linalg.norm(mj)

        for i in range(j):
            mi = M[:, i]
            mi_norm = cp.linalg.norm(mi)
            if mi_norm == 0:
                continue

            cosang = float(cp.abs(cp.dot(mi, mj)) / (mi_norm * mj_norm + 1e-30))
            if cosang >= parallel_tol:
                new_col = rng.choice(cp.array([-1.0, 1.0], dtype=M.dtype), size=n)
                M[:, j] = new_col
                mj = M[:, j]
                mj_norm = cp.linalg.norm(mj)

    if normalize_one_norm:
        for j in range(t):
            nj = cp.linalg.norm(M[:, j], ord=1)
            if nj > 0:
                M[:, j] /= nj

    return M