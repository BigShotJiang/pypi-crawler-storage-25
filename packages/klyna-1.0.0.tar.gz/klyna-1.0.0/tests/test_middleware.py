"""pytest tests for APIMonitorMiddleware."""

from __future__ import annotations

import asyncio
import json
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI
from httpx import AsyncClient, Response
from starlette.testclient import TestClient

from apimonitor import APIMonitorMiddleware


# ── Fixtures ──────────────────────────────────────────────────────────────────


def make_app(api_key: str = "test-key", **kwargs) -> FastAPI:
    app = FastAPI()
    app.add_middleware(APIMonitorMiddleware, api_key=api_key, **kwargs)

    @app.get("/hello")
    async def hello():
        return {"message": "hello"}

    @app.post("/data")
    async def create_data():
        return {"created": True}

    @app.get("/healthz")
    async def healthz():
        return {"status": "ok"}

    return app


# ── Unit tests ────────────────────────────────────────────────────────────────


def test_raises_if_api_key_missing():
    from fastapi import FastAPI as FA

    with pytest.raises(ValueError, match="api_key is required"):
        FA().add_middleware(APIMonitorMiddleware, api_key="")

    with pytest.raises(ValueError, match="api_key is required"):
        FA().add_middleware(APIMonitorMiddleware, api_key=None)  # type: ignore[arg-type]


def test_does_not_block_requests():
    """Middleware must pass requests through without altering the response."""
    app = make_app(
        ingest_url="http://noop.invalid",
        flush_interval=60,
    )
    client = TestClient(app, raise_server_exceptions=True)
    resp = client.get("/hello")
    assert resp.status_code == 200
    assert resp.json() == {"message": "hello"}


def test_excluded_path_not_collected():
    """Requests to /healthz must not produce any metrics."""
    collected: List[dict] = []

    app = make_app(
        ingest_url="http://noop.invalid",
        flush_interval=60,
    )

    # Monkey-patch _queue.put to intercept metrics
    middleware = _get_middleware(app)
    original_put = middleware._queue.put

    async def spy_put(metric):
        collected.append(metric)
        return await original_put(metric)

    middleware._queue.put = spy_put

    client = TestClient(app)
    client.get("/healthz")

    assert collected == [], "Excluded path /healthz must not produce metrics"


def test_tracked_path_produces_metric():
    """Requests to /hello must produce exactly one metric with correct fields."""
    collected: List[dict] = []

    app = make_app(
        ingest_url="http://noop.invalid",
        flush_interval=60,
    )
    middleware = _get_middleware(app)

    async def spy_put(metric):
        collected.append(metric)

    middleware._queue.put = spy_put

    client = TestClient(app)
    client.get("/hello")

    assert len(collected) == 1
    m = collected[0]
    assert m["endpoint"] == "/hello"
    assert m["method"] == "GET"
    assert m["status_code"] == 200
    assert isinstance(m["response_time"], int)
    assert m["response_time"] >= 0
    assert m["timestamp"].endswith("Z")


def test_custom_exclude_paths():
    """Custom exclude paths must suppress metric collection."""
    collected: List[dict] = []

    app = make_app(
        ingest_url="http://noop.invalid",
        flush_interval=60,
        exclude_paths=["/hello"],
    )
    middleware = _get_middleware(app)

    async def spy_put(metric):
        collected.append(metric)

    middleware._queue.put = spy_put

    client = TestClient(app)
    client.get("/hello")  # excluded
    client.post("/data")  # not excluded

    assert len(collected) == 1
    assert collected[0]["endpoint"] == "/data"


@pytest.mark.asyncio
async def test_batch_flush_sends_correct_payload():
    """_send() must POST to the ingest endpoint with correct headers and payload."""
    sent_payloads: List[dict] = []
    sent_headers: List[dict] = []

    mock_response = MagicMock(spec=Response)
    mock_response.status_code = 200

    async def mock_post(url, **kwargs):
        sent_payloads.append(kwargs.get("json", {}))
        sent_headers.append(kwargs.get("headers", {}))
        return mock_response

    app = make_app(
        api_key="ak_testkey",
        ingest_url="http://ingest.test",
        batch_size=50,
        flush_interval=60,
    )
    middleware = _get_middleware(app)
    middleware._client = MagicMock()
    middleware._client.post = mock_post

    metrics = [
        {
            "endpoint": "/api/test",
            "method": "GET",
            "status_code": 200,
            "response_time": 42,
            "request_size": 0,
            "response_size": 128,
            "timestamp": "2024-01-01T00:00:00Z",
        }
    ]

    await middleware._send(metrics)

    assert len(sent_payloads) == 1
    assert sent_payloads[0]["metrics"] == metrics
    assert sent_headers[0]["X-API-Key"] == "ak_testkey"


@pytest.mark.asyncio
async def test_drain_empties_queue():
    """_drain() must consume all items from the queue and send them."""
    app = make_app(
        ingest_url="http://ingest.test",
        flush_interval=60,
    )
    middleware = _get_middleware(app)
    middleware._client = MagicMock()

    sent: List[List] = []

    async def mock_send(metrics):
        sent.append(metrics)

    middleware._send = mock_send

    # Populate the queue
    for i in range(5):
        await middleware._queue.put({"index": i})

    await middleware._drain()

    assert middleware._queue.empty()
    assert len(sent) == 1
    assert len(sent[0]) == 5


@pytest.mark.asyncio
async def test_immediate_flush_on_batch_size():
    """When queue reaches batch_size, _drain() is triggered immediately."""
    drained: List[bool] = []

    app = make_app(
        ingest_url="http://noop.invalid",
        batch_size=2,
        flush_interval=60,
    )
    middleware = _get_middleware(app)

    original_drain = middleware._drain

    async def spy_drain():
        drained.append(True)
        await original_drain()

    middleware._drain = spy_drain

    # Manually add 2 items to trigger the batch-size flush path
    await middleware._queue.put({"metric": 1})
    await middleware._queue.put({"metric": 2})

    # Simulate the queue-size check logic from dispatch()
    if middleware._queue.qsize() >= middleware._batch_size:
        asyncio.ensure_future(middleware._drain())

    await asyncio.sleep(0.05)
    assert len(drained) >= 1


# ── Helpers ────────────────────────────────────────────────────────────────────


def _get_middleware(app: FastAPI) -> APIMonitorMiddleware:
    """Extract the APIMonitorMiddleware instance from the app's middleware stack."""
    for layer in app.middleware_stack.__dict__.get("app", app).__class__.__mro__:
        pass  # type traversal not needed
    # Walk the middleware stack to find our middleware
    node = app.middleware_stack
    while node is not None:
        if isinstance(node, APIMonitorMiddleware):
            return node
        node = getattr(node, "app", None)
    raise RuntimeError("APIMonitorMiddleware not found in middleware stack")
