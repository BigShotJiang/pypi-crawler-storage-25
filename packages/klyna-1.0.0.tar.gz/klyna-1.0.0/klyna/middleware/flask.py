"""
Flask extension for Klyna API monitoring.

Usage:
    from klyna import KlynaConfig
    from klyna.middleware.flask import KlynaFlask

    config = KlynaConfig(api_key='sk_live_...')

    # Option 1: pass app at construction time
    klyna = KlynaFlask(app, config)

    # Option 2: application factory pattern
    klyna = KlynaFlask()
    klyna.init_app(app, config)
"""
import sys
import time

from ..client import KlynaClient
from ..types import KlynaConfig, MetricPayload


class KlynaFlask:
    def __init__(self, app=None, config: KlynaConfig = None) -> None:
        self.client: KlynaClient = None
        if app is not None and config is not None:
            self.init_app(app, config)

    def init_app(self, app, config: KlynaConfig) -> None:
        self.client = KlynaClient(config)
        app.before_request(self._before_request)
        app.after_request(self._after_request)

    def _before_request(self):
        try:
            from flask import g
            g._klyna_start = time.monotonic()
        except Exception as e:
            if self.client and self.client.config.debug:
                print(f'[Klyna] before_request error: {e}', file=sys.stderr)

    def _after_request(self, response):
        try:
            from flask import g, request
            start = getattr(g, '_klyna_start', time.monotonic())
            latency_ms = int((time.monotonic() - start) * 1000)
            path = request.path or '/'

            if not self.client.is_ignored(path) and self.client.should_sample():
                request_size = 0
                try:
                    cl = request.headers.get('Content-Length', '0')
                    request_size = int(cl) if cl else 0
                except (ValueError, TypeError):
                    pass

                response_size = 0
                try:
                    cl = response.headers.get('Content-Length', '0')
                    response_size = int(cl) if cl else 0
                except (ValueError, TypeError):
                    pass

                self.client.enqueue(MetricPayload(
                    endpoint=path,
                    method=request.method,
                    status_code=response.status_code,
                    latency_ms=latency_ms,
                    request_size=request_size,
                    response_size=response_size,
                    user_agent=request.headers.get('User-Agent', ''),
                    ip_address=request.headers.get('X-Forwarded-For', '') or request.remote_addr or '',
                ))
        except Exception as e:
            if self.client and self.client.config.debug:
                print(f'[Klyna] after_request error: {e}', file=sys.stderr)

        return response
