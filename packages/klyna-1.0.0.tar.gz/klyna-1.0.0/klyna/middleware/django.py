"""
Django WSGI middleware for Klyna API monitoring.

Usage (settings.py):
    MIDDLEWARE = [
        'klyna.middleware.django.KlynaDjangoMiddleware',
        # ... your other middleware
    ]

    KLYNA_API_KEY = 'sk_live_...'

Or configure programmatically in your wsgi.py / asgi.py:
    from klyna import KlynaConfig
    from klyna.middleware.django import KlynaDjangoMiddleware

    application = KlynaDjangoMiddleware(
        application,
        KlynaConfig(api_key='sk_live_...')
    )
"""
import sys
import time

from ..client import KlynaClient
from ..types import KlynaConfig, MetricPayload


class KlynaDjangoMiddleware:
    """
    Django WSGI middleware compatible with the MIDDLEWARE setting.
    When used via MIDDLEWARE, it reads KLYNA_API_KEY (and optionally
    KLYNA_BASE_URL, KLYNA_SAMPLE_RATE) from Django settings.
    Can also be instantiated directly with a KlynaConfig.
    """

    def __init__(self, get_response, config: KlynaConfig = None) -> None:
        self.get_response = get_response

        if config is None:
            config = self._config_from_django_settings()

        self.client = KlynaClient(config)

    def __call__(self, request):
        start = time.monotonic()
        response = self.get_response(request)

        try:
            latency_ms = int((time.monotonic() - start) * 1000)
            path = request.path or '/'

            if not self.client.is_ignored(path) and self.client.should_sample():
                request_size = 0
                try:
                    cl = request.META.get('CONTENT_LENGTH', '0')
                    request_size = int(cl) if cl else 0
                except (ValueError, TypeError):
                    pass

                response_size = 0
                try:
                    cl = response.get('Content-Length', '0')
                    response_size = int(cl) if cl else 0
                except (ValueError, TypeError):
                    pass

                forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR', '')
                remote_addr = forwarded_for.split(',')[0].strip() if forwarded_for else request.META.get('REMOTE_ADDR', '')

                self.client.enqueue(MetricPayload(
                    endpoint=path,
                    method=request.method,
                    status_code=response.status_code,
                    latency_ms=latency_ms,
                    request_size=request_size,
                    response_size=response_size,
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    ip_address=remote_addr,
                ))
        except Exception as e:
            if self.client.config.debug:
                print(f'[Klyna] Django middleware error: {e}', file=sys.stderr)

        return response

    @staticmethod
    def _config_from_django_settings() -> KlynaConfig:
        try:
            from django.conf import settings
            api_key = getattr(settings, 'KLYNA_API_KEY', '')
            base_url = getattr(settings, 'KLYNA_BASE_URL', 'https://app.klyna.io')
            sample_rate = getattr(settings, 'KLYNA_SAMPLE_RATE', 1.0)
            batch_size = getattr(settings, 'KLYNA_BATCH_SIZE', 50)
            debug = getattr(settings, 'KLYNA_DEBUG', False)
            return KlynaConfig(
                api_key=api_key,
                base_url=base_url,
                sample_rate=sample_rate,
                batch_size=batch_size,
                debug=debug,
            )
        except ImportError:
            return KlynaConfig(api_key='')
