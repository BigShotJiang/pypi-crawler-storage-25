"""
Pure ASGI middleware compatible with FastAPI, Starlette, and Django ASGI.

Usage with FastAPI:
    from klyna import KlynaASGIMiddleware, KlynaConfig

    config = KlynaConfig(api_key='sk_live_...')
    app = KlynaASGIMiddleware(app, config)

Usage with Starlette:
    from starlette.applications import Starlette
    from klyna import KlynaASGIMiddleware, KlynaConfig

    app = Starlette(...)
    app = KlynaASGIMiddleware(app, KlynaConfig(api_key='sk_live_...'))
"""
import sys
import time

from ..client import KlynaClient
from ..types import KlynaConfig, MetricPayload


class KlynaASGIMiddleware:
    def __init__(self, app, config: KlynaConfig) -> None:
        self.app = app
        self.client = KlynaClient(config)

    async def __call__(self, scope: dict, receive, send) -> None:
        if scope.get('type') != 'http':
            await self.app(scope, receive, send)
            return

        start = time.monotonic()
        status_code = 200
        response_size = 0

        async def send_wrapper(message: dict) -> None:
            nonlocal status_code, response_size
            if message.get('type') == 'http.response.start':
                status_code = message.get('status', 200)
            elif message.get('type') == 'http.response.body':
                body = message.get('body', b'')
                if body:
                    response_size += len(body)
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            try:
                latency_ms = int((time.monotonic() - start) * 1000)
                path = scope.get('path', '/')
                method = scope.get('method', 'GET')

                # headers is a list of (name_bytes, value_bytes) tuples
                raw_headers = scope.get('headers', [])
                headers: dict = {}
                for k, v in raw_headers:
                    key = k.decode('latin-1').lower() if isinstance(k, bytes) else k.lower()
                    headers[key] = v.decode('utf-8', errors='ignore') if isinstance(v, bytes) else v

                if not self.client.is_ignored(path) and self.client.should_sample():
                    client_info = scope.get('client')
                    remote_addr = client_info[0] if client_info else ''

                    request_size = 0
                    try:
                        cl = headers.get('content-length', '0')
                        request_size = int(cl) if cl else 0
                    except (ValueError, TypeError):
                        pass

                    self.client.enqueue(MetricPayload(
                        endpoint=path,
                        method=method,
                        status_code=status_code,
                        latency_ms=latency_ms,
                        request_size=request_size,
                        response_size=response_size,
                        user_agent=headers.get('user-agent', ''),
                        ip_address=headers.get('x-forwarded-for', '') or remote_addr,
                    ))
            except Exception as e:
                if self.client.config.debug:
                    print(f'[Klyna] ASGI middleware error: {e}', file=sys.stderr)
