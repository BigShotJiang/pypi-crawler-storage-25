from dataclasses import dataclass, field
from typing import List


@dataclass
class KlynaConfig:
    api_key: str
    base_url: str = 'https://app.klyna.io'
    batch_size: int = 50
    flush_interval: float = 5.0  # seconds
    sample_rate: float = 1.0
    ignored_paths: List[str] = field(
        default_factory=lambda: ['/health', '/healthz', '/readyz', '/metrics', '/favicon.ico']
    )
    timeout: float = 10.0  # seconds
    debug: bool = False


@dataclass
class MetricPayload:
    endpoint: str
    method: str
    status_code: int
    latency_ms: int
    request_size: int = 0
    response_size: int = 0
    error_message: str = ''
    user_agent: str = ''
    ip_address: str = ''

    def to_dict(self) -> dict:
        return {
            'endpoint': self.endpoint,
            'method': self.method,
            'status_code': self.status_code,
            'latency_ms': self.latency_ms,
            'request_size': self.request_size,
            'response_size': self.response_size,
            'error_message': self.error_message,
            'user_agent': self.user_agent,
            'ip_address': self.ip_address,
        }
