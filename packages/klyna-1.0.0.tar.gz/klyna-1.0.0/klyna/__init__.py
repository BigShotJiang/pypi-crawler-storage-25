"""
klyna — Official Klyna SDK for Python.

Zero external dependencies. Works with Flask, FastAPI, Starlette, Django, and
any ASGI or WSGI framework.
"""
from .client import KlynaClient
from .types import KlynaConfig, MetricPayload
from .middleware.flask import KlynaFlask
from .middleware.asgi import KlynaASGIMiddleware
from .middleware.django import KlynaDjangoMiddleware

__all__ = [
    'KlynaClient',
    'KlynaConfig',
    'MetricPayload',
    'KlynaFlask',
    'KlynaASGIMiddleware',
    'KlynaDjangoMiddleware',
]

__version__ = '1.0.0'
