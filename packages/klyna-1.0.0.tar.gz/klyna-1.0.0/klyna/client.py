import atexit
import json
import random
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from typing import Deque, List

from .types import KlynaConfig, MetricPayload


class KlynaClient:
    """
    Thread-safe Klyna metrics client. Buffers MetricPayload objects in memory
    and flushes them to the Klyna batch ingest endpoint in the background.
    Zero external dependencies — uses Python stdlib only.
    """

    def __init__(self, config: KlynaConfig) -> None:
        if not config.api_key:
            raise ValueError('KlynaClient: api_key is required')

        self.config = config
        self._queue: Deque[MetricPayload] = deque(maxlen=10_000)
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._flush_lock = threading.Lock()

        self._thread = threading.Thread(
            target=self._flush_loop,
            name='klyna-flush',
            daemon=True,
        )
        self._thread.start()

        atexit.register(self.shutdown)

    # ── Public API ─────────────────────────────────────────────────────────

    def enqueue(self, metric: MetricPayload) -> None:
        """Add a metric to the queue. Triggers immediate flush if queue is full."""
        metric = MetricPayload(
            endpoint=(metric.endpoint or '')[:2048],
            method=metric.method,
            status_code=metric.status_code,
            latency_ms=metric.latency_ms,
            request_size=metric.request_size,
            response_size=metric.response_size,
            error_message=(metric.error_message or '')[:512],
            user_agent=(metric.user_agent or '')[:512],
            ip_address=(metric.ip_address or '')[:64],
        )
        with self._lock:
            self._queue.append(metric)
            should_flush = len(self._queue) >= self.config.batch_size

        if should_flush:
            self._flush()

    def is_ignored(self, path: str) -> bool:
        for p in self.config.ignored_paths:
            if path == p or path.startswith(p + '/'):
                return True
        return False

    def should_sample(self) -> bool:
        if self.config.sample_rate >= 1.0:
            return True
        if self.config.sample_rate <= 0.0:
            return False
        return random.random() < self.config.sample_rate

    def shutdown(self) -> None:
        """Stop background thread and flush remaining metrics."""
        if self._stop_event.is_set():
            return
        self._stop_event.set()
        self._thread.join(timeout=15.0)
        self._flush()

    # ── Internal ──────────────────────────────────────────────────────────

    def _flush_loop(self) -> None:
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=self.config.flush_interval)
            if not self._stop_event.is_set():
                try:
                    self._flush()
                except Exception as e:
                    if self.config.debug:
                        print(f'[Klyna] flush loop error: {e}', file=sys.stderr)

    def _flush(self) -> None:
        """Drain the queue in batches and send each batch."""
        with self._flush_lock:
            while True:
                with self._lock:
                    if not self._queue:
                        break
                    batch: List[MetricPayload] = []
                    for _ in range(min(self.config.batch_size, len(self._queue))):
                        batch.append(self._queue.popleft())

                try:
                    self._send_batch(batch)
                except Exception as e:
                    if self.config.debug:
                        print(f'[Klyna] send error: {e}', file=sys.stderr)

    def _send_batch(self, metrics: List[MetricPayload]) -> None:
        """Send a batch with exponential backoff retry. Uses urllib (stdlib)."""
        self._send_with_retry(metrics, attempt=0)

    def _send_with_retry(self, metrics: List[MetricPayload], attempt: int) -> None:
        max_attempts = 3
        backoff_seconds = [1.0, 2.0, 4.0]

        base = self.config.base_url.rstrip('/')
        url = f'{base}/api/v1/ingest/batch'
        payload = json.dumps({'metrics': [m.to_dict() for m in metrics]}).encode('utf-8')

        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'X-API-Key': self.config.api_key,
            },
            method='POST',
        )

        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                status = resp.status
                if status == 202:
                    return
                # Unexpected 2xx — treat as success
                if 200 <= status < 300:
                    return
                raise _HttpError(status, f'Unexpected status {status}')

        except urllib.error.HTTPError as e:
            status = e.code

            if status == 429:
                retry_after = min(float(e.headers.get('Retry-After', '60')), 300.0)
                if self.config.debug:
                    print(f'[Klyna] rate limited, retrying after {retry_after}s', file=sys.stderr)
                time.sleep(retry_after)
                if attempt < max_attempts - 1:
                    self._send_with_retry(metrics, attempt + 1)
                return

            # Do not retry other 4xx errors
            if 400 <= status < 500:
                if self.config.debug:
                    print(f'[Klyna] 4xx error ({status}), not retrying', file=sys.stderr)
                return

            # 5xx — retry with backoff
            if attempt < max_attempts - 1:
                wait = backoff_seconds[attempt]
                if self.config.debug:
                    print(f'[Klyna] HTTP {status}, retrying in {wait}s (attempt {attempt + 1})', file=sys.stderr)
                time.sleep(wait)
                self._send_with_retry(metrics, attempt + 1)
                return

            if self.config.debug:
                print(f'[Klyna] HTTP {status} after {max_attempts} attempts', file=sys.stderr)

        except Exception as e:
            if attempt < max_attempts - 1:
                wait = backoff_seconds[attempt]
                if self.config.debug:
                    print(f'[Klyna] send error: {e}, retrying in {wait}s', file=sys.stderr)
                time.sleep(wait)
                self._send_with_retry(metrics, attempt + 1)
                return

            if self.config.debug:
                print(f'[Klyna] send failed after {max_attempts} attempts: {e}', file=sys.stderr)


class _HttpError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
