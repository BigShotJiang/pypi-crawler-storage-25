from enum import Enum

from h2o_engine_manager.gen.model.sandbox_engine_pending_reason import (
    SandboxEnginePendingReason as V1SandboxEnginePendingReason,
)


class SandboxEnginePendingReason(Enum):
    """SandboxEngine pending reason - indicates why engine is in a pending state."""

    # No pending reason - engine is in a stable state (RUNNING, TERMINATED, FAILED).
    PENDING_REASON_UNSPECIFIED = "PENDING_REASON_UNSPECIFIED"
    # Kubernetes resources (Pod, Service) are being created.
    PENDING_REASON_CREATING_RESOURCES = "PENDING_REASON_CREATING_RESOURCES"
    # Pod is waiting to be scheduled to a node.
    PENDING_REASON_SCHEDULING = "PENDING_REASON_SCHEDULING"
    # Node is pulling the container image.
    PENDING_REASON_PULLING_IMAGE = "PENDING_REASON_PULLING_IMAGE"
    # Container is being created (init containers, volumes, network setup).
    PENDING_REASON_CONTAINER_CREATING = "PENDING_REASON_CONTAINER_CREATING"
    # Container is running but application is not ready yet.
    PENDING_REASON_WAITING_READINESS = "PENDING_REASON_WAITING_READINESS"
    # Kubernetes resources are being cleaned up.
    PENDING_REASON_DELETING_RESOURCES = "PENDING_REASON_DELETING_RESOURCES"

    def to_api_object(self) -> V1SandboxEnginePendingReason:
        return V1SandboxEnginePendingReason(self.value)


def sandbox_engine_pending_reason_from_api_object(
    api_object: V1SandboxEnginePendingReason,
) -> SandboxEnginePendingReason:
    return SandboxEnginePendingReason(api_object.value)