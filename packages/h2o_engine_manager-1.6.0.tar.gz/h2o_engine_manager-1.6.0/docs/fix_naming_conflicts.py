#!/usr/bin/env python3
"""
Post-process pdoc3 output to fix issues with Docusaurus/MDX compatibility.

Fixes applied:
1. Naming conflicts: When a module file has the same name as its parent package
   (e.g., port/port.py), pdoc3 generates both port/index.md and port/port.md.
   This causes Docusaurus routing conflicts. Fix: rename to port/port_module.md.

2. MDX list parsing: MDX interprets lines starting with '- ' as Markdown list
   items, even inside HTML tags like <dd> and <p>. This breaks MDX compilation.
   Fix: convert such lists to proper <ul><li> HTML elements.
"""
import re
from pathlib import Path


def fix_naming_conflicts(docs_root: Path):
    """Find and fix naming conflicts where module name == package name."""
    fixed_count = 0

    for index_file in docs_root.rglob("index.md"):
        package_dir = index_file.parent
        package_name = package_dir.name

        # Check if there's a conflicting module file
        module_file = package_dir / f"{package_name}.md"
        if module_file.exists():
            # Rename to avoid conflict
            new_name = package_dir / f"{package_name}_module.md"
            rel_path = module_file.relative_to(docs_root)
            print(f"Fixing conflict: {rel_path} -> {new_name.name}")

            # Read content
            content = module_file.read_text()

            # Write to new location and remove old file
            new_name.write_text(content)
            module_file.unlink()

            # Update index.md to point to the renamed file
            index_content = index_file.read_text()
            # Update markdown links [text](package_name) -> [text](package_name_module)
            index_content = re.sub(
                rf'\[([^\]]+)\]\({package_name}\)',
                rf'[\1]({package_name}_module)',
                index_content
            )
            # Update href attributes href="package_name" -> href="package_name_module"
            index_content = re.sub(
                rf'href="{package_name}"',
                rf'href="{package_name}_module"',
                index_content
            )
            index_file.write_text(index_content)

            fixed_count += 1

    if fixed_count > 0:
        print(f"\nFixed {fixed_count} naming conflict(s)")
    else:
        print("No naming conflicts found")


def fix_mdx_lists(docs_root: Path):
    """Convert markdown-style lists inside HTML tags to HTML lists.

    MDX interprets lines starting with '- ' as Markdown list items, even when
    they appear inside HTML tags like <dd> and <p>. This breaks MDX compilation
    with errors like "Expected a closing tag for <dd> before the end of paragraph".

    This function finds such lists and converts them to <ul><li> HTML elements.
    """
    fixed_count = 0

    for md_file in docs_root.rglob("*.md"):
        content = md_file.read_text()
        new_content = _convert_html_inline_lists(content)
        if new_content != content:
            md_file.write_text(new_content)
            print(f"Fixed MDX lists: {md_file.relative_to(docs_root)}")
            fixed_count += 1

    if fixed_count > 0:
        print(f"\nFixed MDX lists in {fixed_count} file(s)")
    else:
        print("No MDX list issues found")


def _convert_html_inline_lists(content: str) -> str:
    """Replace markdown list items inside <dd> and <p> tags with inline bullets.

    MDX treats '- ' at the start of a line as a Markdown list (block element),
    which breaks the paragraph context of <dd> and <p> tags. Replacing the dash
    with an HTML bullet entity keeps the content inline.
    """
    # Process multi-line <dd>...</dd> blocks
    content = re.sub(
        r'(<dd>)(.*?)(</dd>)',
        lambda m: m.group(1) + _escape_md_lists(m.group(2)) + m.group(3),
        content,
        flags=re.DOTALL,
    )
    # Process multi-line <p>...</p> blocks
    content = re.sub(
        r'(<p>)(.*?)(</p>)',
        lambda m: m.group(1) + _escape_md_lists(m.group(2)) + m.group(3),
        content,
        flags=re.DOTALL,
    )
    return content


def _escape_md_lists(text: str) -> str:
    """Replace '- ' at the start of lines with a bullet entity to prevent MD parsing."""
    if '\n- ' not in text and '\n    - ' not in text:
        return text
    # Replace lines starting with optional whitespace + "- " with "&#8226; "
    return re.sub(r'^(\s*)- ', r'\1&#8226; ', text, flags=re.MULTILINE)


if __name__ == "__main__":
    # Navigate from py/h2o-engine-manager/docs/ to docs/docs/py/
    script_dir = Path(__file__).parent
    docs_root = script_dir.parent.parent.parent / "docs" / "docs" / "py"

    if not docs_root.exists():
        print(f"Error: Documentation root not found at {docs_root}")
        exit(1)

    print(f"Scanning for issues in {docs_root}")
    fix_naming_conflicts(docs_root)
    print()
    fix_mdx_lists(docs_root)
