import pytest

import spendwall.modes as m


def test_resolve_default_is_observe(monkeypatch):
    monkeypatch.delenv("SPENDWALL_MODE", raising=False)
    assert m.resolve() == "observe"


def test_resolve_env_var_wins_over_default(monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "enforce")
    assert m.resolve() == "enforce"


def test_resolve_configured_wins_over_env(monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    assert m.resolve(configured="advisory") == "advisory"


def test_resolve_per_call_wins_over_configured(monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    assert m.resolve(per_call="enforce", configured="advisory") == "enforce"


def test_resolve_rejects_invalid_mode():
    with pytest.raises(ValueError):
        m.resolve(per_call="block")
