"""Tests for spendwall.errors — class hierarchy and message construction."""

import pytest

from spendwall.errors import (
    ApprovalRequiredError,
    BlockedError,
    SpendwallError,
    SpendwallVersionMismatch,
)


def test_blocked_error_inherits_from_spendwall_error():
    assert issubclass(BlockedError, SpendwallError)
    assert issubclass(SpendwallError, Exception)


def test_approval_required_error_inherits_from_spendwall_error():
    assert issubclass(ApprovalRequiredError, SpendwallError)


def test_version_mismatch_inherits_from_spendwall_error():
    assert issubclass(SpendwallVersionMismatch, SpendwallError)


def test_blocked_error_stores_attrs_and_formats_message():
    err = BlockedError(cap_id="daily-cap", projected_cents=200, limit_cents=100)
    assert err.cap_id == "daily-cap"
    assert err.projected_cents == 200
    assert err.limit_cents == 100
    msg = str(err)
    assert "daily-cap" in msg
    assert "200" in msg
    assert "100" in msg


def test_approval_required_error_stores_caps_and_reason():
    err = ApprovalRequiredError(approval_caps=["c1", "c2"])
    assert err.approval_caps == ["c1", "c2"]
    assert err.reason == "denied"
    assert "c1" in str(err)


def test_approval_required_error_custom_reason():
    err = ApprovalRequiredError(approval_caps=["c1"], reason="timeout")
    assert err.reason == "timeout"
    assert "timeout" in str(err)


def test_blocked_error_can_be_caught_as_spendwall_error():
    with pytest.raises(SpendwallError):
        raise BlockedError(cap_id="x", projected_cents=1, limit_cents=0)


def test_approval_required_error_can_be_caught_as_spendwall_error():
    with pytest.raises(SpendwallError):
        raise ApprovalRequiredError(approval_caps=["x"])
