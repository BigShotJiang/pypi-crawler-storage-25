"""Tests for spendwall.anthropic.wrap()."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from spendwall.errors import BlockedError


@pytest.fixture
def fake_anthropic_client():
    client = MagicMock(name="anthropic.Anthropic")
    msg = MagicMock(name="Message")
    msg.id = "msg_test"
    msg.model = "claude-3-5-sonnet-20241022"
    msg.usage = MagicMock(input_tokens=10, output_tokens=5)
    client.messages.create.return_value = msg
    return client


def test_wrap_observe_passes_through_and_observes(
    fake_anthropic_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.anthropic import wrap

    sw = MagicMock()
    wrapped = wrap(fake_anthropic_client, sw_client=sw, agent_id="a")
    out = wrapped.messages.create(
        model="claude-3-5-sonnet-20241022",
        messages=[{"role": "user", "content": "hi"}],
    )
    assert out.id == "msg_test"
    sw.policy_check_strict.assert_not_called()
    sw.policy_check.assert_not_called()
    sw.observe.assert_called_once()
    payload = sw.observe.call_args.args[0]
    assert payload["provider"] == "anthropic"
    assert payload["source"] == "sdk_python"
    assert payload["input_tokens"] == 10
    assert payload["output_tokens"] == 5
    assert payload["outcome"] == "success"


def test_wrap_enforce_calls_policy_check_strict_then_observe(
    fake_anthropic_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "enforce")
    from spendwall.anthropic import wrap

    sw = MagicMock()
    sw.policy_check_strict.return_value = {"decision": "allowed"}
    wrapped = wrap(fake_anthropic_client, sw_client=sw, agent_id="a")
    wrapped.messages.create(
        model="claude-3-5-sonnet-20241022",
        messages=[{"role": "user", "content": "hi"}],
    )
    sw.policy_check_strict.assert_called_once()
    pcs_kwargs = sw.policy_check_strict.call_args.kwargs
    assert pcs_kwargs["provider"] == "anthropic"
    assert pcs_kwargs["model"] == "claude-3-5-sonnet-20241022"
    sw.observe.assert_called_once()


def test_wrap_advisory_calls_non_strict_policy_check(
    fake_anthropic_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "advisory")
    from spendwall.anthropic import wrap

    sw = MagicMock()
    sw.policy_check.return_value = {"decision": "allowed"}
    wrapped = wrap(fake_anthropic_client, sw_client=sw, agent_id="a")
    wrapped.messages.create(
        model="claude-3-5-sonnet-20241022",
        messages=[{"role": "user", "content": "hi"}],
    )
    sw.policy_check.assert_called_once()
    sw.policy_check_strict.assert_not_called()
    sw.observe.assert_called_once()


def test_wrap_enforce_blocked_raises_BlockedError_and_skips_upstream(
    fake_anthropic_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "enforce")
    from spendwall.anthropic import wrap

    original_create = fake_anthropic_client.messages.create
    sw = MagicMock()
    sw.policy_check_strict.side_effect = BlockedError("cap-y", 99, 1)
    wrapped = wrap(fake_anthropic_client, sw_client=sw, agent_id="a")
    with pytest.raises(BlockedError):
        wrapped.messages.create(
            model="claude-3-5-sonnet-20241022",
            messages=[{"role": "user", "content": "hi"}],
        )
    original_create.assert_not_called()
    sw.observe.assert_not_called()


def test_wrap_observes_upstream_error(fake_anthropic_client, monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.anthropic import wrap

    fake_anthropic_client.messages.create.side_effect = RuntimeError("boom")
    sw = MagicMock()
    wrapped = wrap(fake_anthropic_client, sw_client=sw, agent_id="a")
    with pytest.raises(RuntimeError):
        wrapped.messages.create(
            model="claude-3-5-sonnet-20241022",
            messages=[{"role": "user", "content": "hi"}],
        )
    sw.observe.assert_called_once()
    payload = sw.observe.call_args.args[0]
    assert payload["outcome"] == "upstream_error"


def test_wrap_per_call_mode_overrides_env(fake_anthropic_client, monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.anthropic import wrap

    sw = MagicMock()
    sw.policy_check_strict.return_value = {"decision": "allowed"}
    wrapped = wrap(
        fake_anthropic_client, sw_client=sw, agent_id="a", mode="enforce"
    )
    wrapped.messages.create(
        model="claude-3-5-sonnet-20241022",
        messages=[{"role": "user", "content": "hi"}],
    )
    sw.policy_check_strict.assert_called_once()


def test_wrap_returns_same_client_instance(fake_anthropic_client):
    from spendwall.anthropic import wrap

    sw = MagicMock()
    out = wrap(fake_anthropic_client, sw_client=sw, agent_id="a")
    assert out is fake_anthropic_client


def test_wrap_propagates_tags_into_observe(fake_anthropic_client, monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.anthropic import wrap

    sw = MagicMock()
    wrapped = wrap(
        fake_anthropic_client, sw_client=sw, agent_id="a",
        tags={"env": "prod"},
    )
    wrapped.messages.create(
        model="claude-3-5-sonnet-20241022",
        messages=[{"role": "user", "content": "hi"}],
    )
    payload = sw.observe.call_args.args[0]
    assert payload["tags"] == {"env": "prod"}
