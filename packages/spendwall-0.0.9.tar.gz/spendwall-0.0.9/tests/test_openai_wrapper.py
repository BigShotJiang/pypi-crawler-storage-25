"""Tests for spendwall.openai.wrap()."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from spendwall.errors import BlockedError


@pytest.fixture
def fake_openai_client():
    client = MagicMock(name="openai.OpenAI")
    completion = MagicMock(name="ChatCompletion")
    completion.model = "gpt-4o"
    completion.usage = MagicMock(prompt_tokens=10, completion_tokens=5)
    completion.id = "chatcmpl_test"
    client.chat.completions.create.return_value = completion

    response = MagicMock(name="Response")
    response.id = "resp_test"
    response.usage = MagicMock(prompt_tokens=7, completion_tokens=3)
    client.responses.create.return_value = response
    return client


def test_wrap_observe_mode_skips_policy_check_and_passes_through(
    fake_openai_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.openai import wrap

    sw_client = MagicMock(name="SpendwallClient")
    wrapped = wrap(fake_openai_client, sw_client=sw_client, agent_id="a-test")
    out = wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    assert out.id == "chatcmpl_test"
    sw_client.policy_check_strict.assert_not_called()
    sw_client.policy_check.assert_not_called()
    sw_client.observe.assert_called_once()
    # Observe should carry post-flight token usage.
    payload = sw_client.observe.call_args.args[0]
    assert payload["agent_id"] == "a-test"
    assert payload["provider"] == "openai"
    assert payload["source"] == "sdk_python"
    assert payload["input_tokens"] == 10
    assert payload["output_tokens"] == 5
    assert payload["outcome"] == "success"


def test_wrap_enforce_mode_calls_policy_check_strict_then_observe(
    fake_openai_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "enforce")
    from spendwall.openai import wrap

    sw_client = MagicMock(name="SpendwallClient")
    sw_client.policy_check_strict.return_value = {
        "decision": "allowed", "alert_caps": [],
    }
    wrapped = wrap(fake_openai_client, sw_client=sw_client, agent_id="a-test")
    out = wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    assert out.id == "chatcmpl_test"
    sw_client.policy_check_strict.assert_called_once()
    pcs_kwargs = sw_client.policy_check_strict.call_args.kwargs
    assert pcs_kwargs["agent_id"] == "a-test"
    assert pcs_kwargs["provider"] == "openai"
    assert pcs_kwargs["model"] == "gpt-4o"
    sw_client.observe.assert_called_once()


def test_wrap_advisory_mode_calls_policy_check_non_strict(
    fake_openai_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "advisory")
    from spendwall.openai import wrap

    sw_client = MagicMock(name="SpendwallClient")
    sw_client.policy_check.return_value = {"decision": "allowed", "alert_caps": []}
    wrapped = wrap(fake_openai_client, sw_client=sw_client, agent_id="a-test")
    wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    sw_client.policy_check.assert_called_once()
    sw_client.policy_check_strict.assert_not_called()
    sw_client.observe.assert_called_once()


def test_wrap_enforce_blocked_raises_BlockedError_and_skips_upstream(
    fake_openai_client, monkeypatch
):
    monkeypatch.setenv("SPENDWALL_MODE", "enforce")
    from spendwall.openai import wrap

    # Snapshot the original create-method mock before wrap() replaces it.
    original_create = fake_openai_client.chat.completions.create

    sw_client = MagicMock(name="SpendwallClient")
    sw_client.policy_check_strict.side_effect = BlockedError("cap-x", 200, 100)
    wrapped = wrap(fake_openai_client, sw_client=sw_client, agent_id="a-test")
    with pytest.raises(BlockedError):
        wrapped.chat.completions.create(
            model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
        )
    original_create.assert_not_called()
    sw_client.observe.assert_not_called()


def test_wrap_observes_upstream_error(fake_openai_client, monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.openai import wrap

    fake_openai_client.chat.completions.create.side_effect = RuntimeError("boom")
    sw_client = MagicMock(name="SpendwallClient")
    wrapped = wrap(fake_openai_client, sw_client=sw_client, agent_id="a-test")
    with pytest.raises(RuntimeError):
        wrapped.chat.completions.create(
            model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
        )
    sw_client.observe.assert_called_once()
    payload = sw_client.observe.call_args.args[0]
    assert payload["outcome"] == "upstream_error"


def test_wrap_per_call_mode_overrides_configured(fake_openai_client, monkeypatch):
    """Configured mode should override env default."""
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.openai import wrap

    sw_client = MagicMock(name="SpendwallClient")
    sw_client.policy_check_strict.return_value = {"decision": "allowed"}
    # configured=enforce overrides env=observe.
    wrapped = wrap(
        fake_openai_client, sw_client=sw_client, agent_id="a", mode="enforce",
    )
    wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    sw_client.policy_check_strict.assert_called_once()


def test_wrap_patches_responses_create_too(fake_openai_client, monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.openai import wrap

    sw_client = MagicMock(name="SpendwallClient")
    wrapped = wrap(fake_openai_client, sw_client=sw_client, agent_id="a")
    out = wrapped.responses.create(model="gpt-4o", input="hi")
    assert out.id == "resp_test"
    sw_client.observe.assert_called_once()


def test_wrap_returns_same_client_instance(fake_openai_client):
    from spendwall.openai import wrap

    sw_client = MagicMock(name="SpendwallClient")
    out = wrap(fake_openai_client, sw_client=sw_client, agent_id="a")
    assert out is fake_openai_client


def test_wrap_propagates_tags_into_observe(fake_openai_client, monkeypatch):
    monkeypatch.setenv("SPENDWALL_MODE", "observe")
    from spendwall.openai import wrap

    sw_client = MagicMock(name="SpendwallClient")
    wrapped = wrap(
        fake_openai_client, sw_client=sw_client, agent_id="a",
        tags={"env": "test", "team": "ai"},
    )
    wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    payload = sw_client.observe.call_args.args[0]
    assert payload["tags"] == {"env": "test", "team": "ai"}
