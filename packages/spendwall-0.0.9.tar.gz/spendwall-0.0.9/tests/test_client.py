"""Tests for SpendwallClient — uses a stub UDS HTTP server.

The socket path lives under ``/tmp`` rather than pytest's ``tmp_path`` because
macOS limits AF_UNIX paths to ~104 characters and ``tmp_path`` exceeds that.
"""

from __future__ import annotations

import os
import shutil
import socket
import tempfile
import threading
from contextlib import contextmanager
from typing import Iterator

import pytest

from spendwall.client import SpendwallClient
from spendwall.errors import ApprovalRequiredError, BlockedError


@pytest.fixture
def short_tmp_path() -> Iterator[str]:
    """Return a short directory path safe for AF_UNIX sockets on macOS."""
    d = tempfile.mkdtemp(prefix="sw_", dir="/tmp")
    try:
        yield d
    finally:
        shutil.rmtree(d, ignore_errors=True)


@contextmanager
def fake_uds_server(socket_path: str, responses: list[tuple[int, bytes]]) -> Iterator[list[bytes]]:
    """Tiny HTTP/1.1 server bound to a UDS path. ``responses`` is a list of
    (status_code, body) tuples — popped one per accepted connection. Returns
    a mutable list of raw request payloads received, for assertions."""
    if os.path.exists(socket_path):
        os.unlink(socket_path)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind(socket_path)
    sock.listen(8)
    received: list[bytes] = []
    stop_event = threading.Event()

    def serve() -> None:
        sock.settimeout(0.1)
        while not stop_event.is_set() and responses:
            try:
                conn, _ = sock.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            data = b""
            conn.settimeout(1.0)
            try:
                while b"\r\n\r\n" not in data:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                hdr_end = data.find(b"\r\n\r\n") + 4
                hdrs = data[:hdr_end].decode(errors="ignore")
                body_len = 0
                for line in hdrs.split("\r\n"):
                    if line.lower().startswith("content-length:"):
                        body_len = int(line.split(":", 1)[1].strip())
                while len(data) - hdr_end < body_len:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                received.append(data)
                if not responses:
                    conn.close()
                    continue
                status, body = responses.pop(0)
                reason = "OK" if status < 400 else "ERR"
                if status == 204:
                    conn.send(
                        f"HTTP/1.1 {status} No Content\r\n"
                        f"Content-Length: 0\r\n\r\n".encode()
                    )
                else:
                    conn.send(
                        f"HTTP/1.1 {status} {reason}\r\n"
                        f"Content-Length: {len(body)}\r\n"
                        f"Content-Type: application/json\r\n\r\n".encode()
                        + body
                    )
            finally:
                conn.close()

    t = threading.Thread(target=serve, daemon=True)
    t.start()
    try:
        yield received
    finally:
        stop_event.set()
        try:
            sock.close()
        except OSError:
            pass
        t.join(timeout=1.0)


def test_policy_check_returns_decision_dict(short_tmp_path):
    sp = os.path.join(short_tmp_path, "t.sock")
    body = b'{"decision":"allowed","alert_caps":[]}'
    with fake_uds_server(sp, [(200, body)]):
        c = SpendwallClient(socket_path=sp, bearer="swk_test")
        d = c.policy_check(
            agent_id="a1", provider="openai", model="gpt-4o",
            estimated_cost_cents=1,
        )
        assert d["decision"] == "allowed"


def test_policy_check_strict_raises_blocked(short_tmp_path):
    sp = os.path.join(short_tmp_path, "t.sock")
    body = (
        b'{"decision":"blocked","cap_id":"daily","projected_cents":100,'
        b'"limit_cents":50,"alert_caps":[]}'
    )
    with fake_uds_server(sp, [(200, body)]):
        c = SpendwallClient(socket_path=sp, bearer="swk_test")
        with pytest.raises(BlockedError) as exc_info:
            c.policy_check_strict(
                agent_id="a1", provider="openai", model="gpt-4o",
                estimated_cost_cents=1,
            )
        assert exc_info.value.cap_id == "daily"
        assert exc_info.value.projected_cents == 100
        assert exc_info.value.limit_cents == 50


def test_policy_check_strict_raises_approval_required(short_tmp_path):
    sp = os.path.join(short_tmp_path, "t.sock")
    body = (
        b'{"decision":"approval_required","approval_caps":["cap-x"],'
        b'"alert_caps":[]}'
    )
    with fake_uds_server(sp, [(200, body)]):
        c = SpendwallClient(socket_path=sp, bearer="swk_test")
        with pytest.raises(ApprovalRequiredError) as exc_info:
            c.policy_check_strict(
                agent_id="a1", provider="openai", model="gpt-4o",
                estimated_cost_cents=1,
            )
        assert exc_info.value.approval_caps == ["cap-x"]


def test_observe_204_does_not_raise(short_tmp_path):
    sp = os.path.join(short_tmp_path, "t.sock")
    with fake_uds_server(sp, [(204, b"")]):
        c = SpendwallClient(socket_path=sp, bearer="swk_test")
        c.observe({
            "agent_id": "a1", "provider": "openai", "model": "gpt-4o",
            "source": "sdk_python", "estimated_cost_cents": 1,
            "decision_str": "allowed", "outcome": "success",
        })


def test_observe_swallows_connection_error_when_fail_open(short_tmp_path):
    sp = os.path.join(short_tmp_path, "no.sock")
    c = SpendwallClient(socket_path=sp, bearer="swk_test", fail_open=True)
    # Should NOT raise.
    c.observe({
        "agent_id": "a1", "provider": "openai", "model": "gpt-4o",
        "source": "sdk_python", "estimated_cost_cents": 1,
        "decision_str": "allowed", "outcome": "success",
    })


def test_observe_raises_when_fail_open_disabled(short_tmp_path):
    sp = os.path.join(short_tmp_path, "no.sock")
    c = SpendwallClient(socket_path=sp, bearer="swk_test", fail_open=False)
    import requests as _requests
    with pytest.raises(_requests.RequestException):
        c.observe({"agent_id": "a1"})


def test_policy_check_fail_open_returns_allowed_when_daemon_down(short_tmp_path):
    sp = os.path.join(short_tmp_path, "no.sock")
    c = SpendwallClient(socket_path=sp, bearer="swk_test", fail_open=True)
    d = c.policy_check(
        agent_id="a1", provider="openai", model="gpt-4o",
        estimated_cost_cents=1,
    )
    assert d["decision"] == "allowed"
    assert d["alert_caps"] == []


def test_policy_check_raises_when_fail_open_disabled(short_tmp_path):
    sp = os.path.join(short_tmp_path, "no.sock")
    c = SpendwallClient(socket_path=sp, bearer="swk_test", fail_open=False)
    import requests as _requests
    with pytest.raises(_requests.RequestException):
        c.policy_check(
            agent_id="a1", provider="openai", model="gpt-4o",
            estimated_cost_cents=1,
        )


def test_bearer_token_sent_on_every_request(short_tmp_path):
    sp = os.path.join(short_tmp_path, "t.sock")
    with fake_uds_server(sp, [
        (200, b'{"decision":"allowed","alert_caps":[]}'),
        (204, b""),
    ]) as received:
        c = SpendwallClient(socket_path=sp, bearer="swk_my_token_xyz")
        c.policy_check(
            agent_id="a1", provider="openai", model="gpt-4o",
            estimated_cost_cents=1,
        )
        c.observe({"agent_id": "a1", "outcome": "success"})

    # Both requests should have the bearer header.
    assert len(received) == 2
    for req in received:
        lower = req.lower()
        assert b"authorization: bearer swk_my_token_xyz" in lower


def test_about_returns_daemon_metadata(short_tmp_path):
    sp = os.path.join(short_tmp_path, "t.sock")
    body = b'{"daemon_version":"0.1.0","api_versions_supported":["v1"]}'
    with fake_uds_server(sp, [(200, body)]):
        c = SpendwallClient(socket_path=sp, bearer="swk_test")
        meta = c.about()
        assert meta["daemon_version"] == "0.1.0"
        assert meta["api_versions_supported"] == ["v1"]


def test_policy_check_sends_request_body(short_tmp_path):
    sp = os.path.join(short_tmp_path, "t.sock")
    body = b'{"decision":"allowed","alert_caps":[]}'
    with fake_uds_server(sp, [(200, body)]) as received:
        c = SpendwallClient(socket_path=sp, bearer="swk_t")
        c.policy_check(
            agent_id="agent-x", provider="anthropic",
            model="claude-3-5-sonnet-20241022",
            estimated_cost_cents=42,
            tags={"env": "test"},
        )
    assert len(received) == 1
    payload = received[0]
    assert b"agent-x" in payload
    assert b"anthropic" in payload
    assert b"claude-3-5-sonnet-20241022" in payload
    assert b"42" in payload
    assert b"env" in payload
