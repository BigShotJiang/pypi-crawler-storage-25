"""Mode resolution — observe, advisory, enforce."""

from __future__ import annotations

import os
from typing import Literal, Optional

Mode = Literal["observe", "advisory", "enforce"]
_VALID = ("observe", "advisory", "enforce")
_ENV_VAR = "SPENDWALL_MODE"


def resolve(per_call: Optional[str] = None, configured: Optional[str] = None) -> Mode:
    """Precedence (most specific wins):
    1. `per_call` kwarg passed by user code at the call site
    2. `configured` value from `wrap(..., mode=...)`
    3. `SPENDWALL_MODE` env var
    4. Default: `observe`
    """
    for v in (per_call, configured, os.environ.get(_ENV_VAR)):
        if v is None:
            continue
        if v not in _VALID:
            raise ValueError(f"invalid spendwall mode: {v!r}; expected one of {_VALID}")
        return v  # type: ignore[return-value]
    return "observe"
