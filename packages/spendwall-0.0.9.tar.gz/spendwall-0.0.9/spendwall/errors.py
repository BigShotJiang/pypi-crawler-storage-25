"""Spendwall SDK exceptions."""

from __future__ import annotations


class SpendwallError(Exception):
    """Base for all spendwall-raised exceptions."""


class BlockedError(SpendwallError):
    """Raised in `enforce` mode when policy returned Blocked."""

    def __init__(self, cap_id: str, projected_cents: int, limit_cents: int):
        self.cap_id = cap_id
        self.projected_cents = projected_cents
        self.limit_cents = limit_cents
        super().__init__(
            f"Spendwall blocked by cap '{cap_id}': "
            f"projected {projected_cents}c > limit {limit_cents}c"
        )


class ApprovalRequiredError(SpendwallError):
    """Raised in `enforce` mode when policy returned ApprovalRequired and the
    approval was denied or timed out."""

    def __init__(self, approval_caps: list[str], reason: str = "denied"):
        self.approval_caps = approval_caps
        self.reason = reason
        super().__init__(
            f"Spendwall approval {reason} for caps={approval_caps}"
        )


class SpendwallVersionMismatch(SpendwallError):
    """Raised once when the daemon's API version does not match the SDK's.
    SDK falls back to fail-open `observe` mode for the rest of the process."""
