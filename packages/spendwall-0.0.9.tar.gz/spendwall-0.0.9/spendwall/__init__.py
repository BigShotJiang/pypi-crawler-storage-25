"""Spendwall — local-first agent spending firewall."""
__version__ = "0.0.2"

from spendwall.client import SpendwallClient  # noqa: F401
from spendwall.errors import (  # noqa: F401
    ApprovalRequiredError,
    BlockedError,
    SpendwallError,
    SpendwallVersionMismatch,
)
from spendwall.modes import Mode  # noqa: F401
