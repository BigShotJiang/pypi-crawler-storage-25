"""Wrapper for ``openai.OpenAI`` clients.

Patches ``client.chat.completions.create`` and ``client.responses.create``
in-place so every upstream call is observed by spendwalld. In ``enforce``
mode, the wrapper consults policy *before* dispatching to the upstream and
raises ``BlockedError``/``ApprovalRequiredError`` when the daemon refuses.
"""

from __future__ import annotations

import json as _json
from typing import Any, Optional

from spendwall.client import SpendwallClient
from spendwall.modes import Mode, resolve as resolve_mode


def _estimate_tokens(messages_or_input: Any) -> int:
    """Cheap byte-based estimate; daemon reconciles cost post-flight."""
    try:
        return max(1, len(_json.dumps(messages_or_input)) // 4)
    except (TypeError, ValueError):
        return 1


def wrap(
    openai_client: Any,
    *,
    sw_client: Optional[SpendwallClient] = None,
    agent_id: str = "anonymous",
    mode: Optional[Mode] = None,
    tags: Optional[dict[str, str]] = None,
) -> Any:
    """Patch ``openai_client.chat.completions.create`` (and ``.responses.create``)
    to call into spendwall before/after the upstream request.

    Mutates the supplied client in-place AND returns it for ergonomic chaining:

        client = wrap(openai.OpenAI(...), agent_id="x")
    """
    sw = sw_client or SpendwallClient()
    configured_mode = mode

    def _patch(parent: Any, name: str) -> None:
        original = getattr(parent, name)

        def patched(*args: Any, **kwargs: Any) -> Any:
            call_mode = resolve_mode(configured=configured_mode)
            model = kwargs.get("model", "unknown")
            est_input_tokens = _estimate_tokens(
                kwargs.get("messages") or kwargs.get("input")
            )
            # Daemon does pricing lookup; SDK sends estimated_cost_cents=0
            # to defer cost estimation to the daemon side.
            if call_mode == "enforce":
                sw.policy_check_strict(
                    agent_id=agent_id, provider="openai", model=model,
                    estimated_cost_cents=0, tags=tags or {},
                )
            elif call_mode == "advisory":
                sw.policy_check(
                    agent_id=agent_id, provider="openai", model=model,
                    estimated_cost_cents=0, tags=tags or {},
                )
            # observe-mode skips policy_check entirely (zero added latency).
            try:
                result = original(*args, **kwargs)
            except Exception:
                sw.observe({
                    "agent_id": agent_id, "provider": "openai", "model": model,
                    "source": "sdk_python", "input_tokens": est_input_tokens,
                    "output_tokens": None, "estimated_cost_cents": 0,
                    "actual_cost_cents": None, "decision_str": "allowed",
                    "binding_caps": [], "tags": tags or {},
                    "outcome": "upstream_error",
                })
                raise

            usage = getattr(result, "usage", None)
            input_tokens = getattr(usage, "prompt_tokens", None) if usage else None
            output_tokens = getattr(usage, "completion_tokens", None) if usage else None
            sw.observe({
                "agent_id": agent_id, "provider": "openai", "model": model,
                "source": "sdk_python", "input_tokens": input_tokens,
                "output_tokens": output_tokens, "estimated_cost_cents": 0,
                "actual_cost_cents": None, "decision_str": "allowed",
                "binding_caps": [], "tags": tags or {},
                "outcome": "success",
            })
            return result

        setattr(parent, name, patched)

    if hasattr(openai_client, "chat") and hasattr(openai_client.chat, "completions"):
        _patch(openai_client.chat.completions, "create")
    if hasattr(openai_client, "responses"):
        _patch(openai_client.responses, "create")
    return openai_client
