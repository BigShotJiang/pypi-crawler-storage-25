"""UDS HTTP client for spendwalld."""

from __future__ import annotations

import os
from typing import Any, Optional
from urllib.parse import quote

import requests
import requests_unixsocket

from spendwall.errors import ApprovalRequiredError, BlockedError


def _default_socket_path() -> str:
    return os.environ.get(
        "SPENDWALL_SOCKET",
        os.path.expanduser("~/.spendwall/spendwall.sock"),
    )


def _default_bearer() -> Optional[str]:
    return os.environ.get("SPENDWALL_TOKEN")


class SpendwallClient:
    """Talks to the spendwall daemon over its UDS HTTP API.

    Fail-open: when ``fail_open=True`` and the socket is unreachable, ``observe()``
    is silently dropped and ``policy_check()`` returns a synthetic "allowed"
    decision. Default is ``fail_open=True`` because a spending firewall MUST NOT
    bring down user agents when the daemon is down.
    """

    def __init__(
        self,
        socket_path: Optional[str] = None,
        bearer: Optional[str] = None,
        timeout_seconds: float = 2.0,
        fail_open: bool = True,
    ):
        self.socket_path = socket_path or _default_socket_path()
        self.bearer = bearer or _default_bearer()
        self.timeout_seconds = timeout_seconds
        self.fail_open = fail_open
        self._session = requests_unixsocket.Session()
        self._base = f"http+unix://{quote(self.socket_path, safe='')}"

    def _headers(self) -> dict[str, str]:
        h = {"content-type": "application/json"}
        if self.bearer:
            h["authorization"] = f"Bearer {self.bearer}"
        return h

    def policy_check(
        self,
        *,
        agent_id: str,
        provider: str,
        model: str,
        estimated_cost_cents: int,
        tags: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        body = {
            "agent_id": agent_id,
            "provider": provider,
            "model": model,
            "estimated_cost_cents": estimated_cost_cents,
            "tags": tags or {},
        }
        try:
            r = self._session.post(
                f"{self._base}/v1/policy/check",
                json=body,
                headers=self._headers(),
                timeout=self.timeout_seconds,
            )
            r.raise_for_status()
            return r.json()
        except (requests.RequestException, ValueError):
            if self.fail_open:
                return {"decision": "allowed", "alert_caps": []}
            raise

    def policy_check_strict(self, **kwargs: Any) -> dict[str, Any]:
        """Like ``policy_check`` but raises ``BlockedError`` /
        ``ApprovalRequiredError`` on non-allowed decisions."""
        d = self.policy_check(**kwargs)
        if d.get("decision") == "blocked":
            raise BlockedError(
                cap_id=d.get("cap_id", "?"),
                projected_cents=d.get("projected_cents", 0),
                limit_cents=d.get("limit_cents", 0),
            )
        if d.get("decision") == "approval_required":
            raise ApprovalRequiredError(approval_caps=d.get("approval_caps", []))
        return d

    def observe(self, event: dict[str, Any]) -> None:
        try:
            self._session.post(
                f"{self._base}/v1/spend/observe",
                json=event,
                headers=self._headers(),
                timeout=self.timeout_seconds,
            )
        except requests.RequestException:
            if not self.fail_open:
                raise
            # Fail-open: drop on the floor.

    def about(self) -> dict[str, Any]:
        r = self._session.get(
            f"{self._base}/v1/about",
            timeout=self.timeout_seconds,
        )
        r.raise_for_status()
        return r.json()
