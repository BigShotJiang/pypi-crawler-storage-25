"""Wrapper for ``anthropic.Anthropic`` clients.

Patches ``client.messages.create`` in-place so every upstream call is
observed by spendwalld. In ``enforce`` mode, the wrapper consults policy
*before* dispatching to the upstream and raises
``BlockedError``/``ApprovalRequiredError`` when the daemon refuses.
"""

from __future__ import annotations

import json as _json
from typing import Any, Optional

from spendwall.client import SpendwallClient
from spendwall.modes import Mode, resolve as resolve_mode


def _estimate_tokens(messages_or_input: Any) -> int:
    try:
        return max(1, len(_json.dumps(messages_or_input)) // 4)
    except (TypeError, ValueError):
        return 1


def wrap(
    anthropic_client: Any,
    *,
    sw_client: Optional[SpendwallClient] = None,
    agent_id: str = "anonymous",
    mode: Optional[Mode] = None,
    tags: Optional[dict[str, str]] = None,
) -> Any:
    """Patch ``anthropic_client.messages.create`` to call into spendwall
    before/after the upstream request.

    Mutates the supplied client in-place AND returns it for ergonomic chaining:

        client = wrap(anthropic.Anthropic(...), agent_id="x")
    """
    sw = sw_client or SpendwallClient()
    configured_mode = mode

    original = anthropic_client.messages.create

    def patched(*args: Any, **kwargs: Any) -> Any:
        call_mode = resolve_mode(configured=configured_mode)
        model = kwargs.get("model", "unknown")
        est_input_tokens = _estimate_tokens(kwargs.get("messages"))

        if call_mode == "enforce":
            sw.policy_check_strict(
                agent_id=agent_id, provider="anthropic", model=model,
                estimated_cost_cents=0, tags=tags or {},
            )
        elif call_mode == "advisory":
            sw.policy_check(
                agent_id=agent_id, provider="anthropic", model=model,
                estimated_cost_cents=0, tags=tags or {},
            )
        # observe-mode skips policy_check entirely.
        try:
            result = original(*args, **kwargs)
        except Exception:
            sw.observe({
                "agent_id": agent_id, "provider": "anthropic", "model": model,
                "source": "sdk_python", "input_tokens": est_input_tokens,
                "output_tokens": None, "estimated_cost_cents": 0,
                "actual_cost_cents": None, "decision_str": "allowed",
                "binding_caps": [], "tags": tags or {},
                "outcome": "upstream_error",
            })
            raise

        usage = getattr(result, "usage", None)
        input_tokens = getattr(usage, "input_tokens", None) if usage else None
        output_tokens = getattr(usage, "output_tokens", None) if usage else None
        sw.observe({
            "agent_id": agent_id, "provider": "anthropic", "model": model,
            "source": "sdk_python", "input_tokens": input_tokens,
            "output_tokens": output_tokens, "estimated_cost_cents": 0,
            "actual_cost_cents": None, "decision_str": "allowed",
            "binding_caps": [], "tags": tags or {},
            "outcome": "success",
        })
        return result

    anthropic_client.messages.create = patched
    return anthropic_client
