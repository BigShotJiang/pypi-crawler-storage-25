# spendwall (Python)

```python
import openai
import spendwall.openai as sw

client = openai.OpenAI(api_key="sk-...")
client = sw.wrap(client, mode="enforce")

# Now every client.chat.completions.create(...) is observed by spendwalld.
```
