# zOS/core/engine.py
# ═══════════════════════════════════════════════════════════════════════════════
"""
zCLI Core Engine - Top-Level Orchestrator

4-Layer Architecture (bottom-up):
    Layer 0: Foundation       → zConfig, zComm, zLoader
    Layer 1: Core (8)         → zParser, zDisplay, zAuth, zDispatch,
                                zNavigation, zFunc, zDialog, zOpen
    Layer 2: Abstraction (3)  → zWizard, zData, zShell
    Layer 3: Orchestration    → zWalker

Thread-safe via contextvars.ContextVar. Supports zCLI and zBifrost (WebSocket) modes.
Graceful shutdown via SIGINT/SIGTERM handlers (reverse initialization order).
"""

# ═══════════════════════════════════════════════════════════════════════════════
# IMPORTS (Centralized from __init__.py per IMPORT_CENTRALIZATION_RULES.md)
# ═══════════════════════════════════════════════════════════════════════════════

from . import Any, Dict, Optional, contextvars, logging
from zSys.shutdown import (  # pylint: disable=import-error,wrong-import-order
    perform_shutdown,
    register_signal_handlers,
)

# ═══════════════════════════════════════════════════════════════════════════════
# MODULE CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────────────────────
# Session Keys (4) - Used in session dict
# ─────────────────────────────────────────────────────────────────────────────
SESSION_KEY_ZS_ID: str = "zS_id"
SESSION_KEY_ZMODE: str = "zMode"
SESSION_KEY_ZMACHINE: str = "zMachine"
SESSION_KEY_ZSPARK: str = "zSpark_obj"

# ─────────────────────────────────────────────────────────────────────────────
# Mode Constants (3) - zMode values
# ─────────────────────────────────────────────────────────────────────────────
MODE_ZCLI: str = "zCLI"
MODE_ZBIFROST: str = "zBifrost"
MODE_WALKER: str = "Walker"

# ─────────────────────────────────────────────────────────────────────────────
# Logger Messages - Info (10)
# ─────────────────────────────────────────────────────────────────────────────
LOG_INIT_COMPLETE: str = "zCLI Core initialized - Mode: %s"
LOG_MODE_ZCLI: str = "Starting zCLI in zCLI mode..."
LOG_MODE_ZBIFROST: str = "Starting zCLI in zBifrost mode via zWalker..."
LOG_HTTP_START: str = "HTTP server auto-started at %s"
LOG_SESSION_INIT: str = "Session initialized:"
LOG_SESSION_ID_PREFIX: str = "  zS_id: %s"
LOG_SESSION_MODE_PREFIX: str = "  zMode: %s"
LOG_SESSION_MACHINE_PREFIX: str = "  zMachine hostname: %s"

# ─────────────────────────────────────────────────────────────────────────────
# Logger Messages - Warning (5)
# ─────────────────────────────────────────────────────────────────────────────
LOG_WARN_PLUGIN_FAIL: str = "Failed to load plugins: %s"

# ─────────────────────────────────────────────────────────────────────────────
# Logger Messages - Debug (9)
# ─────────────────────────────────────────────────────────────────────────────
LOG_DEBUG_SESSION_ID: str = "  zS_id: %s"
LOG_DEBUG_SESSION_MODE: str = "  zMode: %s"
LOG_DEBUG_SESSION_MACHINE: str = "  zMachine hostname: %s"

# ─────────────────────────────────────────────────────────────────────────────
# Layer Names (4) - For architecture documentation
# ─────────────────────────────────────────────────────────────────────────────
LAYER_0_FOUNDATION: str = "Layer 0: Foundation"
LAYER_1_CORE: str = "Layer 1: Core Subsystems"
LAYER_2_ABSTRACTION: str = "Layer 2: Core Abstraction"
LAYER_3_ORCHESTRATION: str = "Layer 3: Orchestration"

# ─────────────────────────────────────────────────────────────────────────────
# Plugin Config Keys (1)
# ─────────────────────────────────────────────────────────────────────────────
ZSPARK_PLUGINS_KEY: str = "plugins"

# ─────────────────────────────────────────────────────────────────────────────
# Context Variable Name (1)
# ─────────────────────────────────────────────────────────────────────────────
CONTEXT_VAR_NAME: str = "current_zcli"

# Global context variable for current zCLI instance (thread-safe, async-safe)
# Follows Django/Flask/FastAPI pattern for request/application context
_current_zos: contextvars.ContextVar = contextvars.ContextVar(CONTEXT_VAR_NAME, default=None)


# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC API - Context Access
# ═══════════════════════════════════════════════════════════════════════════════

def get_current_zos() -> Optional["zOS"]:
    """
    Get current zCLI instance from thread-local context.

    Thread-safe access following Django/Flask/FastAPI patterns. Used by zExceptions
    for auto-registration. Returns None if not in a zCLI context.
    """
    return _current_zos.get()


# ═══════════════════════════════════════════════════════════════════════════════
# CORE CLASS - zCLI
# ═══════════════════════════════════════════════════════════════════════════════

class zOS:  # pylint: disable=invalid-name
    """
    Core zCLI Engine - orchestrates 16 subsystems across 4 layers.

    Attributes (Public):
        config, comm, display, auth, dispatch, navigation, zparser, loader, zfunc,
        dialog, open, wizard, data, shell, walker, server (optional)

        logger, session, zTraceback (set by zConfig)

    Key Methods:
        run()          → Start zCLI or zBifrost mode
        run_shell()    → Explicit zCLI mode (REPL)
        run_command()  → Execute single command
        shutdown()     → Graceful cleanup (reverse init order)

    Thread-safe via contextvars. Supports context manager protocol.
    Signal handlers (SIGINT/SIGTERM) registered automatically.
    """

    # ─────────────────────────────────────────────────────────────────────────
    # Type Hints for Attributes Set by Subsystems
    # ─────────────────────────────────────────────────────────────────────────
    logger: logging.Logger          # Set by zConfig
    session: Dict[str, Any]         # Set by zConfig
    zTraceback: Any                 # Set by zConfig (zTraceback instance)

    def __init__(self, zSpark_obj: Optional[Dict[str, Any]] = None, verbose: bool = False) -> None:  # pylint: disable=invalid-name
        """
        Initialize zCLI with all 17 subsystems in dependency order.

        Parameters
        ----------
        zSpark_obj : Optional[Dict[str, Any]]
            Config dict. Common keys: zMode ("zCLI"|"zBifrost"), plugins (List[str]),
            log_level, database, port. Defaults: zCLI mode, INFO logging.
        verbose : bool
            If True, show initialization output (default: False for silent mode)

        Side Effects: Registers in thread context, sets SIGINT/SIGTERM handlers,
        may auto-start HTTP server, creates session dict.
        """

        # Initialize zSpark_obj config dict
        self.zspark_obj = zSpark_obj or {}

        # Shutdown coordination
        self._shutdown_requested = False
        self._shutdown_in_progress = False
        # zRaven is initialised as a subsystem below; this legacy attr is kept for
        # shutdown compat until old _auto_run_zraven code is fully removed.
        self._raven_proc = None

        # Register this instance as current context (thread-safe)
        # Enables automatic exception registration for zExceptions
        _current_zos.set(self)

        # ─────────────────────────────────────────────────────────────
        # Layer 0: Foundation
        # ─────────────────────────────────────────────────────────────
        # Initialize zConfig FIRST (machine config, environment config, session)
        # Logger and traceback are also initialized here.
        # After this call, self.session, self.logger, and self.zTraceback are ready to use
        from .L1_Foundation.a_zConfig import zConfig  # pylint: disable=import-outside-toplevel
        self.config = zConfig(zos=self, zSpark_obj=zSpark_obj, verbose=verbose)

        # Initialize zComm (Communication infrastructure for zBifrost and zData)
        from .L1_Foundation.b_zComm import zComm  # pylint: disable=import-outside-toplevel
        self.comm = zComm(self)

        # Initialize display subsystem (needed by zLoader for visual feedback)
        from .L2_Handling.e_zDisplay import zDisplay  # pylint: disable=import-outside-toplevel
        self.display = zDisplay(self)
        self.mycolor = "MAIN"

        # Initialize loader subsystem (foundation - file I/O)
        from .L1_Foundation.c_zLoader import zLoader  # pylint: disable=import-outside-toplevel
        self.loader = zLoader(self)
        
        # Load plugins from zSpark immediately after zLoader (migrated from zUtils v1.7.0)
        self._load_plugins()

        # ─────────────────────────────────────────────────────────────
        # Layer 1: Core Subsystems
        # ─────────────────────────────────────────────────────────────
        # Initialize parser subsystem (transformation - content parsing)
        from .L2_Handling.d_zParser import zParser  # pylint: disable=import-outside-toplevel
        self.zparser = zParser(self)

        # Initialize authentication subsystem
        from .L2_Handling.f_zAuth import zAuth  # pylint: disable=import-outside-toplevel
        self.auth = zAuth(self)

        # Initialize dispatch subsystem
        from .L2_Handling.g_zDispatch import zDispatch  # pylint: disable=import-outside-toplevel
        self.dispatch = zDispatch(self)

        # Initialize navigation subsystem
        from .L2_Handling.h_zNavigation import zNavigation  # pylint: disable=import-outside-toplevel
        self.navigation = zNavigation(self)

        # Initialize function subsystem
        from .L2_Handling.i_zFunc import zFunc  # pylint: disable=import-outside-toplevel
        self.zfunc = zFunc(self)

        # Initialize dialog subsystem
        from .L2_Handling.j_zDialog import zDialog  # pylint: disable=import-outside-toplevel
        self.dialog = zDialog(self)

        # Initialize open subsystem
        from .L2_Handling.k_zOpen import zOpen  # pylint: disable=import-outside-toplevel
        self.open = zOpen(self)


        # ─────────────────────────────────────────────────────────────
        # Layer 2: Core Abstraction
        # ─────────────────────────────────────────────────────────────
        # Initialize wizard subsystem (loop engine - no upper dependencies)
        from .L3_Abstraction.l_zWizard import zWizard  # pylint: disable=import-outside-toplevel
        self.wizard = zWizard(self)

        # Initialize data subsystem (may use zWizard for interactive operations)
        from .L3_Abstraction.m_zData import zData  # pylint: disable=import-outside-toplevel
        self.data = zData(self)

        # Initialize zBifrost WebSocket bridge orchestrator (Layer 2)
        # Coordinates zCLI↔Web communication using z.comm infrastructure
        from .L3_Abstraction.n_zBifrost import zBifrost  # pylint: disable=import-outside-toplevel
        self.bifrost = zBifrost(self)

        # Initialize shell and command executor (depends on zWizard, zData)
        from .L3_Abstraction.o_zShell import zShell  # pylint: disable=import-outside-toplevel
        self.shell = zShell(self)

        # Layer 3: Orchestration
        # Initialize walker subsystem
        from .L4_Orchestration.p_zWalker import zWalker  # pylint: disable=import-outside-toplevel
        # Modern walker with unified navigation (can use plugins immediately)
        self.walker = zWalker(self)

        # Initialize zServer (HTTP/WSGI server subsystem) - Layer 1
        # v1.5.8: Independent subsystem (was factory method in zComm)
        from .L4_Orchestration.q_zServer import zServer  # pylint: disable=import-outside-toplevel
        self.server = zServer(
            logger=self.logger,
            zos=self,
            config=self.config.http_server if hasattr(self.config, "http_server") else None
        )

        # Auto-start if enabled in config
        if hasattr(self.config, "http_server") and self.config.http_server.enabled:
            self.server.start()
            # Server ready message is logged by dev_server_manager - no need for duplicate

            # v1.5.8: Auto-wait if configured (declarative lifecycle management)
            # Must happen AFTER signal handlers are registered but BEFORE returning to user code
            # Note: We defer the actual wait() call until after __init__ completes

        # Initialize zRaven test subsystem (Layer 4r) — after zServer + zBifrost are ready
        from .L4_Orchestration.r_zRaven import zRaven as _zRaven  # pylint: disable=import-outside-toplevel
        self.raven = _zRaven(zos=self)

        # Initialize session (sets zMode from zSpark_obj or defaults to zCLI)
        self._init_session()

        # Register signal handlers for graceful shutdown
        self._register_signal_handlers()

        # Note: Constructor returns immediately. Call z.run() to start execution.
        # Note: zAuth database is workspace-relative (@), ensuring each zCLI instance
        # is fully isolated. Auth DB lazy-loads on first save_session() or grant_permission().
        # This preserves the "no global state" principle - the secret sauce of zCLI architecture.

        self.logger.framework.debug(LOG_INIT_COMPLETE, self.session.get(SESSION_KEY_ZMODE))

    def _load_plugins(self) -> None:
        """
        Load plugins from zSpark_obj["plugins"] via zLoader.

        Migrated from zUtils v1.7.0 - plugin loading now centralized in zLoader.
        Supports single string or list. Failures logged as warnings, don't halt init.
        Plugins can use get_current_zos() to access subsystems.
        """
        try:
            plugin_paths = self.zspark_obj.get(ZSPARK_PLUGINS_KEY) or []
            if isinstance(plugin_paths, (list, tuple)):
                self.loader.load_plugins(plugin_paths)
            elif isinstance(plugin_paths, str):
                self.loader.load_plugins([plugin_paths])
        except (ImportError, AttributeError, TypeError) as e:
            self.logger.warning(LOG_WARN_PLUGIN_FAIL, e)

    def _init_session(self) -> None:
        """
        Set session[zS_id] and log config. zMode already set by zConfig.
        """
        # Set session ID - always required
        self.session[SESSION_KEY_ZS_ID] = self.config.session.generate_id("zS")

        # zMode was already set by zConfig.session.detect_zMode() during session creation
        # It checks zSpark_obj.get("zMode") and defaults to "zCLI"
        # No need to override it here

        self.logger.framework.debug(LOG_SESSION_INIT)
        self.logger.framework.debug(LOG_DEBUG_SESSION_ID, self.session[SESSION_KEY_ZS_ID])
        self.logger.framework.debug(LOG_DEBUG_SESSION_MODE, self.session[SESSION_KEY_ZMODE])
        self.logger.framework.debug(
            LOG_DEBUG_SESSION_MACHINE,
            self.session[SESSION_KEY_ZMACHINE].get("hostname"),
        )

    # ═══════════════════════════════════════════════════════════════════════
    # PUBLIC API METHODS
    # ═══════════════════════════════════════════════════════════════════════

    def run_command(self, command: str) -> Any:
        """
        Execute single command string via zShell.

        Returns command result (type varies). Output typically via zDisplay.
        """
        return self.shell.execute_command(command)

    def run_shell(self) -> None:
        """
        Start zCLI mode (interactive REPL). Blocks until exit.
        """
        return self.shell.run_shell()

    def run(self) -> Any:
        """
        Main entry point - centralized execution for all zCLI modes.

        Decision Priority:
        1. zServer running + zShell → REPL with HTTP in background
        2. zServer running (silent) → Block on server.wait()
        3. zVaFile specified → zWalker (handles zCLI/zBifrost internally)
        4. zMode: zBifrost → zWalker (WebSocket mode)
        5. zMode: zCLI (default) → zShell REPL

        Returns:
            Any: Result from the executed subsystem (walker, shell, or server)
        """
        # Priority 1 & 2: zServer lifecycle management
        if self.server and self.server.is_running():
            if hasattr(self.config, "http_server") and self.config.http_server.zShell:
                # Interactive mode: REPL with HTTP server in background
                print("\n" + "="*70)
                print(f"  Server: http://{self.server.config_manager.host}:{self.server.config_manager.port}")
                print("  Entering zShell REPL (type 'exit' to stop server)")
                print("="*70 + "\n")
                return self.run_shell()
            else:
                # Silent blocking mode: Just wait for Ctrl+C
                self.logger.framework.debug("[zCLI] Blocking on zServer (silent mode)")
                self.raven.start()   # no-op if not enabled
                if self.zspark_obj.get("zDesktop"):
                    return self._run_zdesktop_main()
                return self.server.wait()

        # Priority 3: zVaFile specified → zRaven drives (CLI mode) or walker runs
        if self.session.get("zVaFile"):
            if self.raven.is_enabled:
                # zRaven CLI mode: spawn app subprocess, drive via stdin/stdout
                self.logger.info("[zCLI] zRaven enabled — handing off to CLIRunner")
                self.raven.start()
                self.raven.wait()
                return
            self.logger.info("[zCLI] Launching zWalker (zVaFile detected)")
            return self.walker.run()

        # Priority 4 & 5: Mode detection for walker vs shell
        zmode = self.session.get(SESSION_KEY_ZMODE, MODE_ZCLI)

        if zmode == MODE_ZBIFROST:
            self.logger.info(LOG_MODE_ZBIFROST)
            return self.walker.run()

        self.logger.info(LOG_MODE_ZCLI)
        return self.run_shell()

    # ═══════════════════════════════════════════════════════════════════════
    # ZRAVEN AUTO-TEST RUNNER
    # ═══════════════════════════════════════════════════════════════════════

    # _auto_run_zraven removed — replaced by self.raven (r_zRaven subsystem, L4)

    # ═══════════════════════════════════════════════════════════════════════
    # ZDESKTOP NATIVE WINDOW LAUNCHER
    # ═══════════════════════════════════════════════════════════════════════

    def _run_zdesktop_main(self) -> None:
        """
        zDesktop mode: pywebview MUST run on the main thread.

        Parks server.wait() in a background daemon thread, then calls
        launch_desktop_window() blocking on the main thread. When the
        window is closed, shutdown() is called and the server thread exits.
        """
        import threading as _threading  # pylint: disable=import-outside-toplevel
        from .zDesktop import launch_desktop_window  # pylint: disable=import-outside-toplevel

        server_thread = _threading.Thread(
            target=self.server.wait,
            daemon=True,
            name="zServer-wait",
        )
        server_thread.start()

        launch_desktop_window(self)  # blocks main thread until window closes

    # ═══════════════════════════════════════════════════════════════════════
    # SIGNAL HANDLERS & GRACEFUL SHUTDOWN
    # ═══════════════════════════════════════════════════════════════════════

    def _register_signal_handlers(self) -> None:
        """
        Register SIGINT/SIGTERM handlers for graceful shutdown.

        Prevents duplicate attempts via _shutdown_in_progress flag.
        Exit codes: 0 (clean) | 1 (error).
        """
        register_signal_handlers(self)

    def request_shutdown(self, source: str = "unknown") -> None:
        """Request graceful shutdown (non-blocking, safe to call from threads)."""
        import os as _os, signal as _signal  # pylint: disable=import-outside-toplevel
        self.logger.info(f"[zOS] Shutdown requested by {source}")
        _os.kill(_os.getpid(), _signal.SIGINT)

    def shutdown(self) -> Optional[Dict[str, bool]]:
        """
        Gracefully shutdown all subsystems in reverse init order.

        Cleanup: zRaven → WebSocket → HTTP → Database → Logger. Each wrapped in ExceptionContext
        (failures don't halt shutdown). Idempotent via _shutdown_in_progress flag.

        Returns Dict[str, bool] with component status, or None if already in progress.
        """
        # Shut down zRaven first so Playwright releases its WS connection
        # before the WS/HTTP servers stop — prevents port-not-clearing on restart.
        if hasattr(self, "raven"):
            self.raven.shutdown()
        return perform_shutdown(self)

    def __enter__(self) -> "zOS":
        """Context manager entry - register in thread context."""
        _current_zos.set(self)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        """
        Context manager exit - clear thread context.

        Does NOT call shutdown() automatically. Returns False (exceptions propagate).
        """
        _current_zos.set(None)
        return False  # Don't suppress exceptions
