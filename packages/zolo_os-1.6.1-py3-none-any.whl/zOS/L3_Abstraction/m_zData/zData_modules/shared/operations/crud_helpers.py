# zOS/core/L3_Abstraction/n_zData/zData_modules/shared/operations/crud_helpers.py
"""
Shared RETURNING helper for INSERT … RETURNING and UPDATE … RETURNING.

Extracted here so both crud_insert.py and crud_update.py import one copy
(SSOT), avoiding any drift between the two implementations.
"""

from zOS import Any


def _display_returning(table: str, row_ids: list, returning, ops: Any) -> None:
    """
    Fetch rows by their IDs and display as a zTable.

    Used by both INSERT … RETURNING and UPDATE … RETURNING.

    `returning` can be:
      - True / "true" / "*"  → all columns
      - list[str]            → specific columns only

    Uses per-row dict WHERE queries to avoid the string-WHERE limitation
    in the CSV adapter. Results are concatenated into one table.
    """
    if not row_ids:
        return

    table_schema = ops.schema.get(table, {})
    auto_id_field = 'id'
    for field_name, field_def in table_schema.items():
        if isinstance(field_def, dict) and field_def.get('auto_increment'):
            auto_id_field = field_name
            break

    rows = []
    for rid in row_ids:
        try:
            fetched = ops.select(table, where={auto_id_field: rid})
            if fetched:
                rows.extend(fetched)
        except Exception as e:  # pylint: disable=broad-except
            ops.logger.warning(f"[zData] RETURNING fetch failed for id {rid}: {e}")

    if not rows:
        ops.logger.warning(f"[zData] RETURNING: no rows fetched for {table} ids={row_ids}")
        return

    if isinstance(returning, list):
        rows = [{k: v for k, v in row.items() if k in returning} for row in rows]

    columns = list(rows[0].keys()) if rows else []
    ops.logger.info(f"[zData] RETURNING {len(rows)} row(s) from {table}")

    ops.zos.session['_is_live_read'] = True
    try:
        ops.display.zTable(table, columns, rows)
    finally:
        ops.zos.session.pop('_is_live_read', None)
