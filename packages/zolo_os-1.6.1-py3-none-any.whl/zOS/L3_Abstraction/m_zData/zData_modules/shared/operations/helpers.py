# zOS/core/L3_Abstraction/n_zData/zData_modules/shared/operations/helpers.py
"""
Shared Helper Utilities for zData Operations.

This module provides DRY (Don't Repeat Yourself) helper utilities used by ALL
zData operations (both CRUD and DDL). These functions eliminate code duplication
and ensure consistent behavior across operations for common tasks like table
extraction, WHERE clause parsing, field/value extraction, and validation error
display.

═══════════════════════════════════════════════════════════════════════════════
HELPER FUNCTIONS OVERVIEW
═══════════════════════════════════════════════════════════════════════════════

1. extract_table_from_request()
   - Extracts and validates table name from request
   - 3-tier fallback logic: tables → table → model
   - Optional table existence check
   - Raises DatabaseNotInitializedError if table doesn't exist

2. extract_where_clause()
   - Extracts and parses WHERE clause from request
   - Dual-source extraction: top-level (YAML) + options (shell)
   - Quote stripping for command-line parsing artifacts
   - Optional warning if WHERE clause is missing (dangerous for UPDATE/DELETE)

3. extract_field_values()
   - Extracts field/value pairs from request options
   - Filters out reserved options (model, limit, where, order, offset, tables, joins)
   - Type conversion using parse_value() for values
   - Returns (fields: List[str], values: List[Any])

4. display_validation_errors()
   - Displays validation errors with actionable hints
   - Uses ValidationError exception for context-aware hints
   - zDisplay integration for user-friendly output
   - Logger integration for debug/error messages

═══════════════════════════════════════════════════════════════════════════════
3-TIER TABLE EXTRACTION LOGIC
═══════════════════════════════════════════════════════════════════════════════

The table extraction uses a 3-tier fallback to support multiple request formats:

1. Check "tables" key (list of table names - preferred)
2. Check "table" key (single table name or list)
3. Fallback to "model" key (extract last segment: "schema.table" → "table")

This flexibility ensures compatibility with:
- YAML-based requests (declarative operations)
- Shell command requests (command-line operations)
- Legacy model-based requests (backward compatibility)

═══════════════════════════════════════════════════════════════════════════════
DUAL-SOURCE WHERE EXTRACTION
═══════════════════════════════════════════════════════════════════════════════

WHERE clause extraction checks two locations:

1. Top-level "where" key (YAML-based requests)
   Example: {action: "read", where: "id > 5", ...}

2. Options "where" key (shell command requests)
   Example: {action: "read", options: {where: "id > 5"}, ...}

This dual-source approach supports both declarative (YAML) and imperative (shell)
operation modes. Quote stripping handles command-line parsing artifacts where
the shell passes WHERE strings with surrounding quotes.

═══════════════════════════════════════════════════════════════════════════════
RESERVED OPTIONS FILTERING
═══════════════════════════════════════════════════════════════════════════════

Reserved options are filtered out when extracting field/value pairs to prevent
conflicts with table field names:

Reserved: {model, limit, where, order, offset, tables, joins}

This ensures that options like "--limit 10" are not interpreted as setting a
"limit" field in the table, but rather as operation control parameters.

═══════════════════════════════════════════════════════════════════════════════
EXCEPTION INTEGRATION
═══════════════════════════════════════════════════════════════════════════════

Helpers raise actionable exceptions with context-aware hints:

1. DatabaseNotInitializedError
   - Raised when table doesn't exist (extract_table_from_request)
   - Includes operation name, table name, schema name
   - Hint: "Please run 'Setup Database' first to create tables"

2. ValidationError
   - Raised for field validation failures (display_validation_errors)
   - Includes field, value, constraint, schema_name
   - Context-aware hints based on constraint type

═══════════════════════════════════════════════════════════════════════════════
INTEGRATION WITH OTHER SUBSYSTEMS
═══════════════════════════════════════════════════════════════════════════════

- zDisplay: User-friendly error messages (mode-agnostic)
- zLogger: Debug/error/warning messages for operations
- Parsers: WHERE clause parsing (parse_where_clause) and value type conversion (parse_value)
- Exceptions: DatabaseNotInitializedError, ValidationError with actionable hints

═══════════════════════════════════════════════════════════════════════════════
USAGE EXAMPLES
═══════════════════════════════════════════════════════════════════════════════

Example 1: Extract table with existence check
    table = extract_table_from_request(request, "INSERT", ops, check_exists=True)
    if not table:
        return False

Example 2: Extract WHERE clause with warning
    where = extract_where_clause(request, ops, warn_if_missing=True)

Example 3: Extract field/value pairs
    fields, values = extract_field_values(request, "UPDATE", ops)
    if not fields:
        return False

Example 4: Display validation errors
    if errors:
        display_validation_errors(table, errors, ops)
        return False

"""

from zSys.errors import DatabaseNotInitializedError
from typing import Set
from zOS import Any, Dict, List, Optional, Tuple
from ..parsers import parse_where_clause, parse_value
from ..validators.constants import (
    SCHEMA_KEY_UNIQUE, ERR_UNIQUE_VIOLATION, SESSION_KEY_ZDATA_ERRORS,
    SCHEMA_KEY_PK, SCHEMA_KEY_FK, SCHEMA_KEY_ON_DELETE, SCHEMA_KEY_DEFAULT,
    ON_DELETE_RESTRICT, ON_DELETE_CASCADE, ON_DELETE_SET_NULL, ON_DELETE_SET_DEFAULT,
    ERR_FK_RESTRICT,
    LOG_ON_DELETE_CASCADE, LOG_ON_DELETE_SET_NULL, LOG_ON_DELETE_SET_DEFAULT,
    LOG_ON_DELETE_RESTRICT, LOG_ON_DELETE_SCAN, LOG_ON_DELETE_SKIP,
)

# ═══════════════════════════════════════════════════════════════════════════════
# MODULE CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

# ────────────────────────────────────────────────────────────────────────────
# Request Keys
# ────────────────────────────────────────────────────────────────────────────
_KEY_TABLES = "tables"
_KEY_TABLE = "table"
_KEY_MODEL = "model"
_KEY_WHERE = "where"
_KEY_OPTIONS = "options"
_KEY_LIMIT = "limit"
_KEY_ORDER = "order"
_KEY_OFFSET = "offset"
_KEY_JOINS = "joins"
_KEY_META = "zMeta"
_KEY_SCHEMA_NAME = "Schema_Name"

# ────────────────────────────────────────────────────────────────────────────
# Reserved Options (Filtered from Field Extraction)
# ────────────────────────────────────────────────────────────────────────────
_RESERVED_MODEL = "model"
_RESERVED_LIMIT = "limit"
_RESERVED_WHERE = "where"
_RESERVED_ORDER = "order"
_RESERVED_OFFSET = "offset"
_RESERVED_TABLES = "tables"
_RESERVED_JOINS = "joins"

# ────────────────────────────────────────────────────────────────────────────
# Error Messages
# ────────────────────────────────────────────────────────────────────────────
_ERR_NO_TABLE = "No table specified for %s"
_ERR_TABLE_NOT_EXISTS = "Table '%s' does not exist. Please run 'Setup Database' first to create tables."
_ERR_TABLE_NOT_EXISTS_LOG = "[FAIL] Table '%s' does not exist"
_ERR_NO_FIELDS = "No fields provided for %s. Use --field_name value syntax"
_ERR_VALIDATION_FAILED_LOG = "[FAIL] Validation failed for table '%s' with %d error(s)"

# ────────────────────────────────────────────────────────────────────────────
# Log Messages
# ────────────────────────────────────────────────────────────────────────────
_LOG_WARN_NO_WHERE = "[WARN] No WHERE clause - operation will affect ALL rows!"
_LOG_VALIDATION_SUMMARY = "[FAIL] Validation summary: %d field(s) failed for table '%s'"

# ────────────────────────────────────────────────────────────────────────────
# Special Values
# ────────────────────────────────────────────────────────────────────────────
_VALUE_PLACEHOLDER = "<provided value>"  # Placeholder for ValidationError when actual value unavailable

# ────────────────────────────────────────────────────────────────────────────
# Success Messages
# ────────────────────────────────────────────────────────────────────────────
_MSG_SUCCESS = "[ok] %s"  # Generic success message template

# ────────────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────────────
__all__ = [
    "extract_table_from_request",
    "extract_where_clause",
    "extract_field_values",
    "display_validation_errors",
    "execute_hook_if_defined",
    "display_success_message",
    "check_unique_constraints",
    "check_row_constraints",
    "surface_errors_to_session",
    "apply_transforms",
    "handle_on_delete",
]


def extract_table_from_request(
    request: Dict[str, Any],
    operation_name: str,
    ops: Any,
    check_exists: bool = True
) -> Optional[str]:
    """
    Extract and validate table name from request using 3-tier fallback logic.
    
    This function extracts the table name from a request dictionary using a
    3-tier fallback strategy to support multiple request formats (YAML-based,
    shell command-based, and legacy model-based requests).
    
    3-Tier Fallback Logic:
        1. Check "tables" key (list of table names - preferred format)
        2. Check "table" key (single table name or list - alternate format)
        3. Fallback to "model" key — resolves via schema's Data_Label, or path tail as last resort
    
    Table Existence Check:
        If check_exists=True, validates that the table exists in the database.
        If table doesn't exist, displays user-friendly error and raises
        DatabaseNotInitializedError with actionable hints.
    
    Args:
        request: Request dictionary containing table information in one of 3 formats:
                 - {"tables": ["table_name"]}
                 - {"table": "table_name"}
                 - {"model": "schema.table_name"}
        operation_name: Name of the operation (INSERT, READ, UPDATE, etc.) for error messages
        ops: Operations context with adapter, logger, display, schema
        check_exists: If True, validate that table exists in database (default: True)
    
    Returns:
        str: Extracted table name (first table if multiple)
        None: If no table could be extracted
    
    Raises:
        DatabaseNotInitializedError: If check_exists=True and table doesn't exist
    
    Examples:
        # Extract table with existence check
        table = extract_table_from_request(
            {"tables": ["users"]}, "INSERT", ops, check_exists=True
        )
        
        # Extract table without existence check (for CREATE TABLE)
        table = extract_table_from_request(
            {"table": "users"}, "CREATE TABLE", ops, check_exists=False
        )
        
        # Extract from model path (legacy format)
        table = extract_table_from_request(
            {"model": "auth.users"}, "READ", ops
        )  # Returns "users"
    
    Notes:
        - Returns first table if multiple tables provided (tables[0])
        - Supports both string and list formats for "table" key
        - Model path extraction uses last segment (split by '.')
        - Logs error if no table specified (returns None)
        - Displays user-friendly error before raising exception
    """
    # ─────────────────────────────────────────────────────────────────────────
    # Phase 1: 3-Tier Fallback - Extract table from request
    # ─────────────────────────────────────────────────────────────────────────

    # Tier 1: Check "tables" key (list of table names - preferred)
    tables = request.get(_KEY_TABLES, [])

    # Tier 2: Check singular "table" parameter (alternate format)
    if not tables:
        table_param = request.get(_KEY_TABLE)
        if table_param:
            if isinstance(table_param, str):
                tables = [table_param]
            elif isinstance(table_param, list):
                tables = table_param

    # Tier 3: Derive table from model path tail as a last resort.
    # Extended paths (e.g. @.models.Demos.zSchema.basic.demo_basic) are resolved
    # upstream — the block is extracted by parse_schema_model_path() and injected
    # as an explicit "table" key (handled by Tier 2 above).
    # If we reach here without a table, the caller used a short model path without
    # an explicit table field — use path tail, which will fail the existence check
    # and surface a clear "Table 'X' does not exist" error.
    if not tables:
        model = request.get(_KEY_MODEL)
        if isinstance(model, str):
            tables = [model.split(".")[-1]]

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 2: Validation - Ensure table was extracted
    # ─────────────────────────────────────────────────────────────────────────
    if not tables:
        ops.logger.error(_ERR_NO_TABLE, operation_name)
        return None

    table = tables[0]  # Use first table if multiple provided

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 3: Existence Check - Verify table exists in database (if requested)
    # ─────────────────────────────────────────────────────────────────────────
    if check_exists and not ops.adapter.table_exists(table):
        ops.logger.error(_ERR_TABLE_NOT_EXISTS_LOG, table)

        # Display user-friendly error first (mode-agnostic via zDisplay)
        ops.display.error(_ERR_TABLE_NOT_EXISTS % table)

        # Then raise actionable exception with hints
        raise DatabaseNotInitializedError(operation=operation_name, table=table)

    return table

def extract_where_clause(
    request: Dict[str, Any],
    ops: Any,
    warn_if_missing: bool = False
) -> Optional[Dict[str, Any]]:
    """
    Extract and parse WHERE clause from request using dual-source extraction.
    
    This function extracts the WHERE clause from a request dictionary using a
    dual-source strategy to support both YAML-based (declarative) and shell
    command-based (imperative) request formats. It also strips surrounding
    quotes that are artifacts of command-line parsing.
    
    Dual-Source Extraction Logic:
        1. Check top-level "where" key (YAML-based requests - preferred)
           Example: {action: "read", where: "id > 5", ...}
        
        2. Check options "where" key (shell command requests - fallback)
           Example: {action: "read", options: {where: "id > 5"}, ...}
    
    Quote Stripping:
        Removes surrounding quotes (single or double) from WHERE strings.
        This handles shell command-line parsing artifacts where the shell
        passes WHERE strings with surrounding quotes.
        
        Example: '"id > 5"' → 'id > 5'
    
    Optional Warning:
        If warn_if_missing=True, logs a warning when WHERE clause is missing.
        This is useful for UPDATE/DELETE operations where missing WHERE clause
        means the operation will affect ALL rows (potentially dangerous).
    
    Args:
        request: Request dictionary with WHERE clause in one of 2 formats:
                 - {"where": "id > 5"}  (YAML-based)
                 - {"options": {"where": "id > 5"}}  (shell-based)
        ops: Operations context with logger
        warn_if_missing: If True, log warning when WHERE clause is missing (default: False)
    
    Returns:
        Dict[str, Any]: Parsed WHERE clause dictionary (from parse_where_clause)
                        Example: {"id": {"$gt": 5}}
        None: If no WHERE clause found
    
    Examples:
        # Extract WHERE from YAML-based request
        where = extract_where_clause(
            {"where": "id > 5"}, ops
        )  # Returns {"id": {"$gt": 5}}
        
        # Extract WHERE from shell command request
        where = extract_where_clause(
            {"options": {"where": '"id > 5"'}}, ops
        )  # Returns {"id": {"$gt": 5}} (quotes stripped)
        
        # Extract with warning for dangerous operations
        where = extract_where_clause(
            {"options": {}}, ops, warn_if_missing=True
        )  # Logs: "[WARN] No WHERE clause - operation will affect ALL rows!"
    
    Notes:
        - Top-level "where" takes precedence over options "where"
        - Quote stripping handles both single (') and double (") quotes
        - Uses parse_where_clause() for WHERE string parsing
        - Warning is logged to ops.logger (not displayed to user)
    """
    # ─────────────────────────────────────────────────────────────────────────
    # Phase 1: Dual-Source Extraction - Get WHERE string from request
    # ─────────────────────────────────────────────────────────────────────────

    # Source 1: Check top-level "where" key (YAML-based requests - preferred)
    where_str = request.get(_KEY_WHERE)

    # Source 2: Check options "where" key (shell command requests - fallback)
    if not where_str:
        options = request.get(_KEY_OPTIONS, {})
        where_str = options.get(_KEY_WHERE)

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 2: Dict Passthrough - If already a dict, skip string processing
    # ─────────────────────────────────────────────────────────────────────────
    if where_str and isinstance(where_str, dict):
        # WHERE clause is already in dict format (e.g., from auto-query)
        where = where_str
    else:
        # ─────────────────────────────────────────────────────────────────────────
        # Phase 3: Quote Stripping - Remove surrounding quotes (shell artifact)
        # ─────────────────────────────────────────────────────────────────────────
        if where_str:
            where_str = where_str.strip()
            # Strip surrounding quotes (single or double)
            if (where_str.startswith('"') and where_str.endswith('"')) or \
               (where_str.startswith("'") and where_str.endswith("'")):
                where_str = where_str[1:-1]

        # ─────────────────────────────────────────────────────────────────────────
        # Phase 4: Parsing - Convert WHERE string to dictionary
        # ─────────────────────────────────────────────────────────────────────────
        where = parse_where_clause(where_str) if where_str else None

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 4: Optional Warning - Alert if WHERE clause is missing
    # ─────────────────────────────────────────────────────────────────────────
    if warn_if_missing and not where:
        ops.logger.warning(_LOG_WARN_NO_WHERE)

    return where

def extract_field_values(
    request: Dict[str, Any],
    operation_name: str,
    ops: Any
) -> Tuple[Optional[list], Optional[list]]:
    """
    Extract field/value pairs from request options with reserved options filtering.
    
    This function extracts field/value pairs from the request's options dictionary,
    filtering out reserved option names that control operation behavior rather than
    representing table fields. Values are parsed using parse_value() for automatic
    type conversion (int, float, bool, str, None).
    
    Reserved Options Filtering:
        The following option names are reserved for operation control and are NOT
        interpreted as table field names:
        
        - model: Table/model path specification
        - limit: Result limit for READ operations
        - where: WHERE clause filter
        - order: Sort order for READ operations
        - offset: Pagination offset for READ operations
        - tables: Table name(s) specification
        - joins: JOIN specifications for READ operations
    
    Type Conversion:
        Values are converted from strings to appropriate Python types using
        parse_value():
        - "123" → 123 (int)
        - "3.14" → 3.14 (float)
        - "true" → True (bool)
        - "None" → None
        - "text" → "text" (str)
    
    Args:
        request: Request dictionary with options containing field/value pairs
                 Example: {"options": {"name": "Alice", "age": "30", "limit": "10"}}
        operation_name: Name of the operation (INSERT, UPDATE, etc.) for error messages
        ops: Operations context with logger
    
    Returns:
        Tuple[list, list]: (fields, values) where:
            - fields: List of field names (strings)
            - values: List of parsed values (typed)
        Tuple[None, None]: If no fields provided (logs error)
    
    Examples:
        # Extract field/value pairs with reserved options filtering
        fields, values = extract_field_values(
            {"options": {"name": "Alice", "age": "30", "limit": "10"}},
            "INSERT",
            ops
        )
        # Returns: (["name", "age"], ["Alice", 30])
        # Note: "limit" is filtered out as reserved option
        
        # No fields provided (only reserved options)
        fields, values = extract_field_values(
            {"options": {"limit": "10", "where": "id > 5"}},
            "UPDATE",
            ops
        )
        # Returns: (None, None)
        # Logs: "No fields provided for UPDATE. Use --field_name value syntax"
    
    Notes:
        - Reserved options are filtered to prevent field name conflicts
        - Values are converted to Python types (not kept as strings)
        - Returns (None, None) if no field/value pairs after filtering
        - Error is logged but no exception is raised
    """
    # ─────────────────────────────────────────────────────────────────────────
    # Phase 1: Extract Options - Get options dictionary from request
    # ─────────────────────────────────────────────────────────────────────────
    options = request.get(_KEY_OPTIONS, {})

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 2: Reserved Options Filtering - Build reserved options set
    # ─────────────────────────────────────────────────────────────────────────
    reserved_options = {
        _RESERVED_MODEL,
        _RESERVED_LIMIT,
        _RESERVED_WHERE,
        _RESERVED_ORDER,
        _RESERVED_OFFSET,
        _RESERVED_TABLES,
        _RESERVED_JOINS
    }

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 3: Field/Value Extraction - Filter out reserved options
    # ─────────────────────────────────────────────────────────────────────────
    fields_dict = {k: v for k, v in options.items() if k not in reserved_options}

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 4: Validation - Ensure at least one field provided
    # ─────────────────────────────────────────────────────────────────────────
    if not fields_dict:
        ops.logger.error(_ERR_NO_FIELDS, operation_name)
        return None, None

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 5: Type Conversion - Parse values to Python types
    # ─────────────────────────────────────────────────────────────────────────
    fields = list(fields_dict.keys())
    values = [parse_value(str(v)) for v in fields_dict.values()]

    return fields, values

def display_validation_errors(
    table: str,
    errors: Dict[str, str],
    ops: Any
) -> None:
    """
    Display validation errors with actionable hints using ValidationError exception.
    
    This function displays field validation errors to the user with context-aware
    actionable hints by leveraging the ValidationError exception. Each error is
    raised and caught to generate formatted error messages with hints, then
    displayed using zDisplay for mode-agnostic output.
    
    ValidationError Integration:
        Each field error is raised as a ValidationError exception to generate:
        - Formatted error message with field, value, and constraint
        - Context-aware actionable hint based on constraint type
        - Schema name for context
    
    Display Integration:
        Errors are displayed using ops.display.write_line() for mode-agnostic
        output (works in Terminal, Walker, and Bifrost modes). Each error is
        displayed with blank lines for readability.
    
    Logger Integration:
        - Error level: Summary of total errors
        - Debug level: Detailed validation summary
    
    Args:
        table: Table name where validation failed (used for schema_name context)
        errors: Dictionary mapping field names to error messages
                Example: {"email": "Pattern mismatch", "age": "Value out of range"}
        ops: Operations context with logger and display
    
    Returns:
        None: Displays errors and logs summary (no return value)
    
    Examples:
        # Display validation errors for multiple fields
        errors = {
            "email": "Pattern mismatch: must match email format",
            "age": "Value out of range: must be >= 18"
        }
        display_validation_errors("users", errors, ops)
        
        # Logs:
        # [FAIL] Validation failed for table 'users' with 2 error(s)
        # [FAIL] Validation summary: 2 field(s) failed for table 'users'
        
        # Displays:
        # 
        # [ValidationError] Field 'email' validation failed: Pattern mismatch
        # Hint: Check the field format requirements in the schema
        # 
        # 
        # [ValidationError] Field 'age' validation failed: Value out of range
        # Hint: Check the numeric range constraints in the schema
        # 
    
    Notes:
        - Uses ValidationError exception for formatted error messages
        - Value placeholder "<provided value>" used (actual value not available)
        - Each error displayed with blank lines for readability
        - Logger used for error/debug messages (not displayed to user)
        - zDisplay integration ensures mode-agnostic output
    """
    # ─────────────────────────────────────────────────────────────────────────
    # Phase 1: Import - Get ValidationError exception
    # ─────────────────────────────────────────────────────────────────────────
    from zSys.errors import ValidationError

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 2: Log Summary - Record validation failure
    # ─────────────────────────────────────────────────────────────────────────
    ops.logger.error(_ERR_VALIDATION_FAILED_LOG, table, len(errors))

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 3: Display Errors - Show each error with actionable hints
    # ─────────────────────────────────────────────────────────────────────────
    for field, message in errors.items():
        try:
            # Raise ValidationError to get actionable hints
            raise ValidationError(
                field=field,
                value=_VALUE_PLACEHOLDER,  # Actual value not available here
                constraint=message,
                schema_name=table
            )
        except ValidationError as e:
            # Display the formatted error with hint (mode-agnostic via zDisplay)
            ops.display.write_line("")
            ops.display.write_line(str(e))
            ops.display.write_line("")

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 4: Log Details - Record validation summary for debugging
    # ─────────────────────────────────────────────────────────────────────────
    ops.logger.debug(_LOG_VALIDATION_SUMMARY, len(errors), table)

def execute_hook_if_defined(
    adapter: Any,
    hook_name: str,
    *args,
    **kwargs
) -> None:
    """
    Execute adapter hook method if it exists (DRY helper).
    
    Eliminates 4 occurrences of "if hasattr(adapter, hook_name)" checks across
    CRUD operations by providing a centralized hook execution pattern.
    
    Args:
        adapter: Backend adapter instance
        hook_name: Name of the hook method to execute (e.g., "after_insert")
        *args: Positional arguments to pass to the hook
        **kwargs: Keyword arguments to pass to the hook
    
    Examples:
        >>> # Instead of:
        >>> if hasattr(adapter, "after_insert"):
        >>>     adapter.after_insert(table, row_id)
        >>> 
        >>> # Use:
        >>> execute_hook_if_defined(adapter, "after_insert", table, row_id)
    
    Notes:
        - No-op if hook doesn't exist (safe to call)
        - Uses getattr with hasattr for safe method lookup
        - Supports both args and kwargs forwarding
    """
    if hasattr(adapter, hook_name):
        hook = getattr(adapter, hook_name)
        hook(*args, **kwargs)

def check_unique_constraints(
    table: str,
    data: Dict[str, Any],
    table_schema: Dict[str, Any],
    ops: Any,
    exclude_where: Optional[Dict[str, Any]] = None
) -> Dict[str, str]:
    """
    Check unique constraints for fields marked ``unique: true`` in the schema,
    and composite unique constraints declared in ``zConstraints``.

    This is shared by INSERT and UPDATE operations.  For UPDATE, pass
    ``exclude_where`` (the operation's WHERE clause, e.g. ``{"id": 1}``) so that
    the row being updated is excluded from the existence check — preventing a
    false violation when a field is updated to the value it already holds.

    Args:
        table: Table name.
        data: Field/value dict being written.
        table_schema: Schema dict for this table (pre-filtered, no zMeta).
        ops: DataOperations facade (provides ``ops.select`` and ``ops.logger``).
        exclude_where: Optional simple WHERE dict identifying the current row
                       (UPDATE only).  Rows whose fields match ALL keys in this
                       dict are excluded from the conflict check.

    Returns:
        Dict of ``{field_name: error_message}`` for each unique violation,
        empty dict when all constraints are satisfied.
    """
    errors: Dict[str, str] = {}

    # ── Phase 1: single-column unique: true ──────────────────────────────────
    for field_name, value in data.items():
        field_def = table_schema.get(field_name, {})
        if not isinstance(field_def, dict):
            continue
        if not field_def.get(SCHEMA_KEY_UNIQUE, False):
            continue
        try:
            existing: List[Any] = ops.select(table, where={field_name: value})
            if existing and exclude_where:
                existing = [
                    row for row in existing
                    if not _row_matches_where(row, exclude_where)
                ]
            if existing:
                errors[field_name] = ERR_UNIQUE_VIOLATION.format(
                    field_name=field_name, value=value
                )
        except Exception as exc:  # pylint: disable=broad-except
            ops.logger.warning(
                "[zData] Unique check failed for '%s.%s': %s (skipping)",
                table, field_name, exc
            )

    # ── Phase 2: composite unique via zConstraints ───────────────────────────
    # zConstraints is a list of constraint dicts at the table level, e.g.:
    #   zConstraints:
    #     - unique: [username, role]
    _z_constraints = table_schema.get('zConstraints', [])
    seen_composites: set = set()
    for constraint in _z_constraints:
        group = []
        if isinstance(constraint, dict):
            group = constraint.get('unique', [])
        elif isinstance(constraint, str):
            # zolo parser may yield "unique: [name, role]" as a plain string
            # Parse it into a list of field names
            if constraint.strip().startswith('unique:'):
                raw = constraint.split(':', 1)[1].strip()
                raw = raw.strip('[]')
                group = [f.strip() for f in raw.split(',') if f.strip()]
        if not isinstance(group, list) or len(group) < 2:
            continue
        group_key = frozenset(group)
        if group_key in seen_composites:
            continue  # deduplicate if declared on multiple fields
        seen_composites.add(group_key)

        # Only check if ALL fields in the group are present in the payload
        combo_where = {f: data[f] for f in group if f in data}
        if len(combo_where) < len(group):
            continue

        try:
            existing = ops.select(table, where=combo_where)
            if existing and exclude_where:
                existing = [
                    row for row in existing
                    if not _row_matches_where(row, exclude_where)
                ]
            if existing:
                error_key = '+'.join(group)
                errors[error_key] = (
                    f"The combination of {', '.join(group)} must be unique — "
                    f"({', '.join(str(combo_where[f]) for f in group)}) already exists"
                )
        except Exception as exc:  # pylint: disable=broad-except
            ops.logger.warning(
                "[zData] Composite unique check failed for '%s' %s: %s (skipping)",
                table, group, exc
            )

    return errors


def check_row_constraints(
    table: str,
    data: Dict[str, Any],
    table_schema: Dict[str, Any],
    ops: Any,
    current_row: Optional[Dict[str, Any]] = None,
) -> Dict[str, str]:
    """Evaluate ``zConstraints: check:`` cross-field rules against a merged row.

    Each ``check:`` entry in ``zConstraints`` is a zFilters-style expression
    where the RHS of a comparison can be either a literal **or a field name** in
    the row.  The expression is parsed by ``parse_where_clause`` and then
    evaluated in-memory against the merged row dict (``current_row`` overlaid
    with the incoming ``data``).

    For INSERT ``current_row`` is None (only payload fields are available).
    For UPDATE ``current_row`` contains the existing DB row so that fields not
    present in the payload still participate in cross-field checks.

    Returns:
        Dict mapping a synthetic error key to an error message (empty → no errors).
    """
    errors: Dict[str, str] = {}
    _z_constraints = table_schema.get('zConstraints', [])
    if not _z_constraints:
        return errors

    # Merge current row (if any) with incoming data so cross-field checks have
    # access to all column values even if only a subset was submitted.
    merged: Dict[str, Any] = {}
    if isinstance(current_row, dict):
        merged.update(current_row)
    merged.update(data)

    for constraint in _z_constraints:
        check_expr = None
        error_msg = None

        if isinstance(constraint, dict):
            check_expr = constraint.get('check')
            error_msg = constraint.get('error_message')
        elif isinstance(constraint, str) and constraint.strip().startswith('check:'):
            raw = constraint.split(':', 1)[1].strip()
            # zolo parser may concat a trailing " error_message: <msg>" into the string
            if ' error_message:' in raw:
                raw, em = raw.split(' error_message:', 1)
                check_expr = raw.strip()
                error_msg = em.strip()
            else:
                check_expr = raw

        if not check_expr:
            continue

        try:
            ir = parse_where_clause(str(check_expr))
            if ir is None:
                ops.logger.warning(
                    "[zData] check constraint unparseable for '%s': %r (skipping)",
                    table, check_expr
                )
                continue

            # Resolve field references in the IR before evaluation.
            # In a standard zFilters query the RHS is always a literal.
            # Here the RHS may be a field name — substitute its value from the row.
            resolved_ir = _resolve_field_refs(ir, merged)

            if not _evaluate_ir(resolved_ir, merged):
                key = f"check:{check_expr[:40]}"
                errors[key] = error_msg or (
                    f"Row constraint violated: {check_expr}"
                )
        except Exception as exc:  # pylint: disable=broad-except
            ops.logger.warning(
                "[zData] check constraint evaluation failed for '%s' %r: %s (skipping)",
                table, check_expr, exc
            )

    return errors


def _resolve_field_refs(ir: Any, row: Dict[str, Any]) -> Any:
    """Recursively substitute field-name references in an IR dict.

    If the RHS of any comparison is a string that exactly matches a key in
    ``row``, replace it with the row value so the subsequent ``_evaluate_ir``
    sees concrete values.
    """
    if not isinstance(ir, dict):
        return ir

    out: Dict[str, Any] = {}
    for key, val in ir.items():
        if key.startswith('$'):
            # Operator node — recurse into list or dict values
            if isinstance(val, list):
                out[key] = [_resolve_field_refs(v, row) for v in val]
            elif isinstance(val, dict):
                out[key] = _resolve_field_refs(val, row)
            else:
                # Scalar operator value — check if it names a field
                out[key] = row[val] if (isinstance(val, str) and val in row) else val
        else:
            # Field node — val is either a literal, operator dict, or list (IN)
            if isinstance(val, dict):
                out[key] = _resolve_field_refs(val, row)
            elif isinstance(val, list):
                out[key] = val  # IN list — leave as-is
            else:
                # Direct equality — val could be a field ref
                out[key] = row[val] if (isinstance(val, str) and val in row) else val
    return out


def _evaluate_ir(ir: Any, row: Dict[str, Any]) -> bool:
    """Evaluate a parsed where-clause IR dict against a row dict.

    Returns True when the row satisfies all conditions (i.e. the constraint
    PASSES).  Returns False when any condition is violated.
    """
    if not isinstance(ir, dict):
        return True

    for key, condition in ir.items():
        # ── Logical operators ──────────────────────────────────────────────
        if key == '$and':
            if isinstance(condition, list):
                if not all(_evaluate_ir(c, row) for c in condition):
                    return False
            continue
        if key == '$or':
            if isinstance(condition, list):
                if not any(_evaluate_ir(c, row) for c in condition):
                    return False
            continue

        # ── Field comparison ───────────────────────────────────────────────
        raw = row.get(key)

        # Coerce raw value to numeric when possible for comparison operators
        def _num(v: Any) -> Any:
            try:
                return float(v) if '.' in str(v) else int(v)
            except (TypeError, ValueError):
                return v

        if condition is None:
            if raw is not None and raw != '':
                return False
        elif isinstance(condition, dict):
            raw_cmp = _num(raw)
            for op, rhs in condition.items():
                rhs_cmp = _num(rhs) if op in ('$gt', '$gte', '$lt', '$lte') else rhs
                if op == '$gt':
                    if not (raw_cmp > rhs_cmp):
                        return False
                elif op == '$gte':
                    if not (raw_cmp >= rhs_cmp):
                        return False
                elif op == '$lt':
                    if not (raw_cmp < rhs_cmp):
                        return False
                elif op == '$lte':
                    if not (raw_cmp <= rhs_cmp):
                        return False
                elif op == '$ne':
                    if not (str(raw) != str(rhs)):
                        return False
                elif op == '$notnull':
                    if raw is None or raw == '':
                        return False
                elif op == '$like':
                    import re as _re
                    pat = str(rhs).replace('%', '.*').replace('_', '.')
                    if not _re.fullmatch(pat, str(raw), _re.IGNORECASE):
                        return False
                elif op == '$gte' and '$lte' in condition:
                    pass  # handled by individual $gte/$lte iterations
        elif isinstance(condition, list):
            if str(raw) not in [str(v) for v in condition]:
                return False
        else:
            if str(raw) != str(condition):
                return False

    return True


def _row_matches_where(row: Any, where: Dict[str, Any]) -> bool:
    """Return True when *row* satisfies all equality conditions in *where*.

    Only handles simple ``{field: value}`` dicts (as produced by
    ``parse_where_clause`` for plain equality expressions such as ``id = 1``).
    Complex IR operators are ignored — the check degrades to "no match" so
    we err on the side of allowing the write rather than blocking it.
    """
    if not isinstance(row, dict) or not where:
        return False
    for field, condition in where.items():
        if isinstance(condition, dict):
            continue  # IR operator — skip (conservative: do not exclude)
        if str(row.get(field, "")) != str(condition):
            return False
    return True


def apply_transforms(
    table: str,
    data: Dict[str, Any],
    table_schema: Dict[str, Any],
    ops: Any,
) -> Dict[str, Any]:
    """
    Apply field-level ``transform:`` directives to ``data`` **before** validation.

    Transforms normalise raw user input so both the validator and the DB writer
    see the same cleaned value.  Supported built-in aliases (pipe-chainable):

        lowercase   → value.lower()
        uppercase   → value.upper()
        trim        → value.strip()
        trim_lower  → value.strip().lower()  (convenience shorthand)
        slug        → lower + collapse whitespace/underscores to '-'
        capitalize  → value.capitalize()

    Pipe-chaining applies transforms left-to-right, e.g.::

        transform: trim|lowercase

    Returns a *new* dict with transformed values; ``data`` is not mutated.
    Non-string values are skipped silently (transform only applies to str).
    """
    _BUILT_INS: Dict[str, Any] = {
        "lowercase":  lambda v: v.lower(),
        "uppercase":  lambda v: v.upper(),
        "trim":       lambda v: v.strip(),
        "trim_lower": lambda v: v.strip().lower(),
        "capitalize": lambda v: v.capitalize(),
        "slug": lambda v: (
            __import__("re").sub(r"[-\s_]+", "-", v.strip().lower())
        ),
    }

    result = dict(data)
    for field_name, raw_value in data.items():
        field_def = table_schema.get(field_name)
        if not isinstance(field_def, dict):
            continue
        transform_spec = field_def.get("transform")
        if not transform_spec:
            continue
        if not isinstance(raw_value, str):
            continue

        steps = [s.strip() for s in str(transform_spec).split("|") if s.strip()]
        value = raw_value
        for step in steps:
            fn = _BUILT_INS.get(step)
            if fn:
                value = fn(value)
            else:
                ops.logger.warning(
                    "[zData] Unknown transform '%s' on field '%s' of table '%s' (skipping)",
                    step, field_name, table,
                )
        if value != raw_value:
            ops.logger.info(
                "[zData] transform '%s' on '%s': %r → %r",
                transform_spec, field_name, raw_value, value,
            )
        result[field_name] = value
    return result


def surface_errors_to_session(errors: Dict[str, str], ops: Any) -> None:
    """
    Persist validation / unique-constraint errors into the zOS session so the
    Bifrost WebSocket handler can surface them to the frontend after dispatch
    returns False.

    Key: ``SESSION_KEY_ZDATA_ERRORS`` (``"_zdata_errors"``)
    Lifetime: consumed once by ``message_walker_support.handle_form_submit``.

    No-op when a session is not available (e.g. pure zCLI context).
    """
    if not (ops.zos and hasattr(ops.zos, "session") and isinstance(ops.zos.session, dict)):
        return
    ops.zos.session[SESSION_KEY_ZDATA_ERRORS] = [
        f"{field}: {msg}" for field, msg in errors.items()
    ]


# ── Private helpers for multi-hop FK cascade ─────────────────────────────────

def _get_pk_field(table: str, schema_tables: Dict[str, Any]) -> Optional[str]:
    """Return the PK field name for *table* from *schema_tables*, or None."""
    for field_name, field_def in schema_tables.get(table, {}).items():
        if isinstance(field_def, dict) and field_def.get(SCHEMA_KEY_PK):
            return field_name
    return None


def _build_fk_action_plan(
    parent_table: str,
    pk_values: List[Any],
    schema_tables: Dict[str, Any],
    ops: Any,
) -> List[Any]:
    """
    Collect all direct FK children of *parent_table* that have rows matching
    any value in *pk_values*.

    Returns a list of tuples:
        (on_delete, child_table, fk_field_name, fk_ref, pk_val, child_rows, fk_field_def)
    """
    plan: List[Any] = []
    for child_table, child_schema in schema_tables.items():
        if child_table == parent_table or not isinstance(child_schema, dict):
            continue
        for fk_field_name, fk_field_def in child_schema.items():
            if not isinstance(fk_field_def, dict):
                continue
            fk_ref = fk_field_def.get(SCHEMA_KEY_FK)
            if not fk_ref or "." not in str(fk_ref):
                continue
            ref_table, _ = str(fk_ref).split(".", 1)
            if ref_table != parent_table:
                continue
            on_delete = fk_field_def.get(SCHEMA_KEY_ON_DELETE, ON_DELETE_RESTRICT)
            for pk_val in pk_values:
                try:
                    child_rows = ops.select(child_table, where={fk_field_name: pk_val})
                except Exception as exc:  # pylint: disable=broad-except
                    ops.logger.warning(
                        "[on_delete] Could not query child table '%s': %s", child_table, exc
                    )
                    continue
                if not child_rows:
                    continue
                ops.logger.debug(LOG_ON_DELETE_SCAN, child_table, fk_field_name, fk_ref)
                plan.append(
                    (on_delete, child_table, fk_field_name, fk_ref,
                     pk_val, child_rows, fk_field_def)
                )
    return plan


def _check_fk_restrict_recursive(
    parent_table: str,
    pk_values: List[Any],
    schema_tables: Dict[str, Any],
    ops: Any,
    visited: Set[str],
) -> Optional[str]:
    """
    Read-only recursive restrict scan across the entire FK subtree.

    Walks parent_table → its FK children → their FK children, etc.
    Returns the first restrict-violation error string found at any depth,
    or ``None`` if the entire subtree is clear.

    Only cascade children are traversed recursively; set_null / set_default
    branches do not propagate deletes, so their subtrees are not checked.
    """
    if parent_table in visited:
        return None  # cycle guard
    visited = set(visited)
    visited.add(parent_table)

    plan = _build_fk_action_plan(parent_table, pk_values, schema_tables, ops)
    if not plan:
        return None

    for on_delete, child_table, fk_field_name, fk_ref, _pk_val, child_rows, _ in plan:
        if on_delete == ON_DELETE_RESTRICT:
            ops.logger.warning(LOG_ON_DELETE_RESTRICT, len(child_rows), child_table, fk_field_name)
            return ERR_FK_RESTRICT.format(
                count=len(child_rows),
                child_table=child_table,
                fk_field=f"{fk_field_name} → {fk_ref}",
            )

    for on_delete, child_table, _fk_field, _fk_ref, _pk_val, child_rows, _ in plan:
        if on_delete != ON_DELETE_CASCADE:
            continue
        child_pk_field = _get_pk_field(child_table, schema_tables)
        if not child_pk_field:
            continue
        grandchild_pks = [r[child_pk_field] for r in child_rows if child_pk_field in r]
        if grandchild_pks:
            error = _check_fk_restrict_recursive(
                child_table, grandchild_pks, schema_tables, ops, visited
            )
            if error:
                return error

    return None


def _execute_fk_actions_recursive(
    parent_table: str,
    pk_values: List[Any],
    schema_tables: Dict[str, Any],
    ops: Any,
    visited: Set[str],
) -> None:
    """
    Recursively execute FK actions (cascade / set_null / set_default) bottom-up.

    For cascade children, recurses into the child's own subtree *before* deleting
    the child rows — ensuring the deepest level is cleaned up first
    (grandchildren → children → parent).

    Called only after _check_fk_restrict_recursive has confirmed no restrict
    violations exist at any depth.
    """
    if parent_table in visited:
        return  # cycle guard
    visited = set(visited)
    visited.add(parent_table)

    plan = _build_fk_action_plan(parent_table, pk_values, schema_tables, ops)
    if not plan:
        return

    for on_delete, child_table, fk_field_name, _fk_ref, pk_val, child_rows, fk_field_def in plan:
        if on_delete == ON_DELETE_CASCADE:
            child_pk_field = _get_pk_field(child_table, schema_tables)
            if child_pk_field:
                grandchild_pks = [r[child_pk_field] for r in child_rows if child_pk_field in r]
                if grandchild_pks:
                    _execute_fk_actions_recursive(
                        child_table, grandchild_pks, schema_tables, ops, visited
                    )
            ops.logger.info(LOG_ON_DELETE_CASCADE, len(child_rows), child_table, fk_field_name)
            try:
                ops.delete(child_table, {fk_field_name: pk_val})
            except Exception as exc:  # pylint: disable=broad-except
                ops.logger.error(
                    "[on_delete: cascade] Failed to delete child rows in '%s': %s",
                    child_table, exc,
                )

        elif on_delete == ON_DELETE_SET_NULL:
            ops.logger.info(LOG_ON_DELETE_SET_NULL, len(child_rows), child_table, fk_field_name)
            try:
                ops.update(child_table, [fk_field_name], [None], {fk_field_name: pk_val})
            except Exception as exc:  # pylint: disable=broad-except
                ops.logger.error(
                    "[on_delete: set_null] Failed to null FK in '%s': %s",
                    child_table, exc,
                )

        elif on_delete == ON_DELETE_SET_DEFAULT:
            default_val = fk_field_def.get(SCHEMA_KEY_DEFAULT)
            ops.logger.info(
                LOG_ON_DELETE_SET_DEFAULT, len(child_rows), child_table, fk_field_name, default_val
            )
            try:
                ops.update(
                    child_table, [fk_field_name], [default_val], {fk_field_name: pk_val}
                )
            except Exception as exc:  # pylint: disable=broad-except
                ops.logger.error(
                    "[on_delete: set_default] Failed to reset FK in '%s': %s",
                    child_table, exc,
                )


def handle_on_delete(
    parent_table: str,
    where: Any,
    ops: Any,
    request: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """
    Enforce referential integrity before a DELETE executes.

    Scans ``ops.schema`` for any table that declares a field with
    ``fk: <parent_table>.<pk_field>``.  For each matched child field the
    declared ``on_delete`` behaviour is applied:

    - ``restrict``    — block the delete and return an error string.
    - ``cascade``     — delete matching child rows first.
    - ``set_null``    — set the FK field to ``None`` on matching child rows.
    - ``set_default`` — set the FK field to its declared ``default`` value
                        (or ``None`` if no default is declared).

    Default behaviour when ``on_delete`` is absent: ``restrict``.

    Args:
        parent_table: Name of the table being deleted from.
        where:        Parsed WHERE dict (from ``extract_where_clause``).
                      ``None`` means "all rows".
        ops:          ``DataOperations`` instance.

    Returns:
        ``None``  — no restriction; delete can proceed (FK children handled).
        ``str``   — human-readable error message; caller MUST abort the delete.
    """
    _META_KEY = "zMeta"

    # ── Phase 1: find parent rows that will be deleted ────────────────────────
    try:
        parent_rows = ops.select(parent_table, where=where) if where else ops.select(parent_table)
    except Exception as exc:  # pylint: disable=broad-except
        ops.logger.warning("[on_delete] Could not fetch parent rows for FK check: %s", exc)
        return None

    if not parent_rows:
        ops.logger.debug(LOG_ON_DELETE_SKIP)
        return None

    # ── Phase 2: resolve full schema for FK scanning ─────────────────────────
    # When the model path includes a table suffix (e.g. @.models.X.zSchema.basic.demo_delete),
    # the loaded ops.schema is scoped to one table.  We must reload the full schema
    # file to discover FK references in sibling tables.
    schema_tables = {k: v for k, v in ops.schema.items() if k != _META_KEY}

    if len(schema_tables) <= 1 and request:
        model_path = (
            request.get("model")
            or request.get("options", {}).get("model", "")
        )
        if model_path and "zSchema." in str(model_path):
            parts = str(model_path).split(".")
            for i, part in enumerate(parts):
                if part == "zSchema" and i + 1 < len(parts):
                    full_path = ".".join(parts[: i + 2])
                    if full_path != model_path:
                        try:
                            full_schema = ops.zos.loader.handle(full_path)
                            if full_schema and full_schema != "error":
                                schema_tables = {
                                    k: v for k, v in full_schema.items()
                                    if k != _META_KEY and isinstance(v, dict)
                                }
                                ops.logger.debug(
                                    "[on_delete] Loaded full schema '%s' (%d tables) for FK scan",
                                    full_path, len(schema_tables),
                                )
                        except Exception as exc:  # pylint: disable=broad-except
                            ops.logger.warning(
                                "[on_delete] Could not load full schema for FK scan: %s", exc
                            )
                    break
    parent_schema = schema_tables.get(parent_table, {})
    pk_field: Optional[str] = None
    for field_name, field_def in parent_schema.items():
        if isinstance(field_def, dict) and field_def.get(SCHEMA_KEY_PK):
            pk_field = field_name
            break

    if not pk_field:
        ops.logger.debug("[on_delete] No PK found in '%s' — skipping FK checks", parent_table)
        return None

    pk_values = [row[pk_field] for row in parent_rows if pk_field in row]
    if not pk_values:
        return None

    # ── Phase 3: Multi-hop FK enforcement ────────────────────────────────────
    # Pass 1 (read-only): recursively scan the ENTIRE FK subtree at every depth
    # for restrict violations before touching any data.
    # Pass 2 (mutate): execute cascade / set_null / set_default bottom-up.
    fk_error = _check_fk_restrict_recursive(parent_table, pk_values, schema_tables, ops, set())
    if fk_error:
        return fk_error

    _execute_fk_actions_recursive(parent_table, pk_values, schema_tables, ops, set())
    return None  # All FK constraints satisfied — delete may proceed


def display_success_message(
    message: str,
    ops: Any
) -> None:
    """
    Display success message in mode-agnostic way (DRY helper).
    
    Eliminates 11 occurrences of "ops.display.success()" checks across CRUD
    operations by providing a centralized success display pattern.
    
    Args:
        message: Success message to display
        ops: Operations context with display
    
    Examples:
        >>> # Instead of:
        >>> ops.display.success(f"[ok] Inserted row into {table} with ID: {row_id}")
        >>> 
        >>> # Use:
        >>> display_success_message(f"Inserted row into {table} with ID: {row_id}", ops)
    
    Notes:
        - Uses ops.display.success() for mode-agnostic output
        - Automatically prefixes message with checkmark ([ok]) if not present
        - Works in Terminal, Walker, and Bifrost modes
    """
    # Add checkmark prefix if not present
    if not message.startswith("[ok]"):
        message = _MSG_SUCCESS % message
    ops.display.success(message)
