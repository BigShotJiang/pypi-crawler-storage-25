# zOS/core/L3_Abstraction/n_zData/zData_modules/shared/operations/agg_window.py
"""
WINDOW operation handler — analytic functions over ordered/partitioned row sets.

Supported functions
-------------------
ranking:
    row_number    — unique sequential integer per partition, ties broken by sort order
    rank          — rank with gaps (1, 1, 3 …)
    dense_rank    — rank without gaps (1, 1, 2 …)

offset:
    lag           — value of `field` from n rows before in the partition (default n=1)
    lead          — value of `field` from n rows after  in the partition (default n=1)

Request structure
-----------------
    zData:
        action:       window
        model:        @.models...
        function:     row_number          # required
        field:        score               # required for lag/lead; ignored for ranking
        offset:       1                   # row offset for lag/lead (default 1)
        partition_by: country             # optional column to group within
        order_by:     score DESC          # sort within partition
        alias:        rank                # name for the computed column (default: function name)
        where:        score > 80          # optional pre-filter on source rows
        fields:       [name, country, score, rank]   # output projection incl. alias
        limit:        20

All source rows are kept (no collapsing). The computed column is appended to
each row dict, then optional field projection is applied.
"""

from typing import Any, Dict, List, Optional

# ─── module constants ──────────────────────────────────────────────────────────
_LOG_WINDOW  = "[zData] window %s() PARTITION BY %s ORDER BY %s → %d rows"
_LOG_CTE     = "[zData] window reading from CTE '%s' (%d rows)"
_ERR_NO_FUNC = "window: `function:` is required (row_number|rank|dense_rank|lag|lead)"
_ERR_NO_FLD  = "window: function '%s' requires a `field:` key"
_ERR_UNKNOWN = "window: unknown function '%s'. Supported: row_number, rank, dense_rank, lag, lead"

_RANKING_FUNCS = {"row_number", "rank", "dense_rank"}
_OFFSET_FUNCS  = {"lag", "lead"}
_ALL_FUNCS     = _RANKING_FUNCS | _OFFSET_FUNCS


# ──────────────────────────────────────────────────────────────────────────────
# Core computation
# ──────────────────────────────────────────────────────────────────────────────

def _apply_window(
    rows: List[Dict],
    function: str,
    field: Optional[str],
    offset: int,
    partition_by: Optional[str],
    order_col: Optional[str],
    order_desc: bool,
    alias: str,
) -> List[Dict]:
    """Pure-Python window computation. Mutates copies of rows (does not modify originals)."""
    if not rows:
        return rows

    # Build partition index → list of original positions
    if partition_by:
        partitions: Dict[Any, List[int]] = {}
        for idx, row in enumerate(rows):
            partitions.setdefault(row.get(partition_by), []).append(idx)
    else:
        partitions = {None: list(range(len(rows)))}

    result = [dict(r) for r in rows]

    for _, idxs in partitions.items():
        if order_col:
            idxs = sorted(
                idxs,
                key=lambda i: (rows[i].get(order_col) is None,
                               rows[i].get(order_col, '')),
                reverse=order_desc,
            )

        n = len(idxs)

        if function == "row_number":
            for rn, i in enumerate(idxs, start=1):
                result[i][alias] = rn

        elif function == "rank":
            prev_val = object()
            prev_rank = 0
            for pos, i in enumerate(idxs, start=1):
                cur = rows[i].get(order_col) if order_col else None
                if cur != prev_val:
                    prev_rank, prev_val = pos, cur
                result[i][alias] = prev_rank

        elif function == "dense_rank":
            prev_val = object()
            dense = 0
            for i in idxs:
                cur = rows[i].get(order_col) if order_col else None
                if cur != prev_val:
                    dense += 1
                    prev_val = cur
                result[i][alias] = dense

        elif function == "lag":
            for pos, i in enumerate(idxs):
                src = pos - offset
                result[i][alias] = rows[idxs[src]].get(field) if src >= 0 else None

        elif function == "lead":
            for pos, i in enumerate(idxs):
                src = pos + offset
                result[i][alias] = rows[idxs[src]].get(field) if src < n else None

    return result


# ──────────────────────────────────────────────────────────────────────────────
# Public handler
# ──────────────────────────────────────────────────────────────────────────────

def handle_window(request: Dict[str, Any], ops: Any) -> Any:
    """
    Execute a WINDOW operation: fetch rows, append a computed analytic column,
    and display the result as a zTable.

    In _chunk_mode (Bifrost page load) the zTable push is handled identically
    to handle_read — via display.zTable with _is_live_read set, so
    _resolve_zdata_reads aligns the buffer correctly.
    """
    # ── 0. Optional CTE source ─────────────────────────────────────────────────
    from .crud_read import _execute_with_block, _apply_cte_filters

    cte_rows: Optional[List[Dict]] = None
    with_block = request.get('with')
    cte_from   = request.get('from')

    if isinstance(with_block, dict):
        cte_context = _execute_with_block(with_block, ops)
        if cte_from and cte_from in cte_context:
            cte_rows = list(cte_context[cte_from])
            ops.logger.info(_LOG_CTE, cte_from, len(cte_rows))

    # ── 1. Resolve function & parameters ───────────────────────────────────────
    function = str(request.get('function', '')).lower().strip()
    if not function:
        ops.logger.error(_ERR_NO_FUNC)
        return False

    # Support inline arg notation: "lag(score, 2)"
    field_arg: Optional[str] = None
    offset_arg: int = 1
    if '(' in function:
        fname, rest = function.split('(', 1)
        function = fname.strip()
        args = [a.strip().rstrip(')') for a in rest.split(',')]
        if args:
            field_arg = args[0] or None
        if len(args) > 1:
            try:
                offset_arg = int(args[1])
            except ValueError:
                pass

    if function not in _ALL_FUNCS:
        ops.logger.error(_ERR_UNKNOWN, function)
        return False

    field      = field_arg or request.get('field')
    row_offset = int(request.get('offset', offset_arg))
    alias      = request.get('alias') or function
    partition  = request.get('partition_by')
    order_raw  = request.get('order_by') or request.get('order')
    fields_out = request.get('fields')
    limit_raw  = request.get('limit')
    silent     = request.get('silent', False)

    if function in _OFFSET_FUNCS and not field:
        ops.logger.error(_ERR_NO_FLD, function)
        return False

    order_col, order_desc = None, False
    if order_raw:
        parts = str(order_raw).strip().split()
        order_col = parts[0]
        order_desc = len(parts) > 1 and parts[1].upper() == 'DESC'

    # ── 2. Fetch rows ───────────────────────────────────────────────────────────
    if cte_rows is not None:
        # CTE rows: apply any where filter in-memory
        where_raw = request.get('where')
        if where_raw:
            rows = _apply_cte_filters(
                cte_rows, where_raw=where_raw,
                fields=None, order=None, limit=None, offset=0, distinct=False,
            )
        else:
            rows = list(cte_rows)
    else:
        # Adapter read — pass through all relevant keys, strip window-specific ones
        _WINDOW_KEYS = {'function', 'field', 'offset', 'alias',
                        'partition_by', 'action', 'with', 'from'}
        inner = {k: v for k, v in request.items() if k not in _WINDOW_KEYS}
        from .crud_read import handle_read
        rows = handle_read({**inner, 'silent': True}, ops) or []

    if not isinstance(rows, list):
        rows = []

    # ── 3. Compute window ───────────────────────────────────────────────────────
    rows = _apply_window(rows, function, field, row_offset,
                         partition, order_col, order_desc, alias)

    # ── 4. Post-processing ──────────────────────────────────────────────────────
    if fields_out:
        if isinstance(fields_out, str):
            fields_out = [f.strip() for f in fields_out.split(',')]
        rows = [{k: r.get(k) for k in fields_out} for r in rows]

    if limit_raw:
        rows = rows[:int(limit_raw)]

    ops.logger.info(_LOG_WINDOW, function, partition or '*', order_raw or '-', len(rows))

    # ── 5. Return early for sub-calls ──────────────────────────────────────────
    if silent:
        return rows

    # ── 6. Display as zTable (mirrors crud_read Phase 6 exactly) ───────────────
    table_label = (cte_from or request.get('table') or
                   str(request.get('model', '')).split('.')[-1])
    columns = list(rows[0].keys()) if rows else []

    ops.zos.session['_is_live_read'] = True
    try:
        if rows:
            ops.display.zTable(table_label, columns, rows)
        else:
            ops.logger.info("[zData] window %s() → 0 rows", function)
            if ops.zos.session.get('_chunk_mode'):
                ops.display.zTable(table_label, [], [])
    finally:
        ops.zos.session.pop('_is_live_read', None)

    return rows
