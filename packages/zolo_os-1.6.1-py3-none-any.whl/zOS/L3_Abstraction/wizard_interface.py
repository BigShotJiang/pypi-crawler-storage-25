# zOS/core/L3_Abstraction/wizard_interface.py

"""
WizardInterface — Abstract boundary for the zWizard subsystem.

Defines the public contract that zWalker, zShell, and engine.py depend on.
zWizard implements this interface; callers type-hint against it.

This is the swap point: replace l_zWizard with a binary wheel and nothing
outside this boundary needs to change.
"""

from abc import ABC, abstractmethod
from zOS import Any, Dict, Optional


class WizardInterface(ABC):
    """
    Abstract base class defining the public API of the zWizard subsystem.

    Callers outside l_zWizard/ MUST only depend on this interface,
    never on zWizard internals directly.
    """

    @abstractmethod
    def execute_loop(
        self,
        items_dict: Dict[str, Any],
        dispatch_fn: Optional[Any] = None,
        navigation_callbacks: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        start_key: Optional[str] = None,
        ws_callback: Optional[Any] = None,
        block_name: Optional[str] = None,
    ) -> Any:
        """
        Core loop engine: iterate steps, dispatch actions, handle navigation signals.

        Returns a navigation signal string (zBack / exit / stop / error)
        or None for normal completion.
        """

    @abstractmethod
    def handle(self, zWizard_obj: Dict[str, Any]) -> Optional[Any]:
        """
        High-level YAML-wizard entry point with WizardHat accumulation,
        interpolation, and transaction management.

        Returns a WizardHat object containing all step results.
        """
