# zOS/core/L4_Orchestration/r_zRaven/zRaven_modules/runner.py
"""
ZRavenRunner — orchestrates a single zRaven test file against a live zOS session.

Design:
  - WS/walker primitives (zBoot, zSubmit, zPick, zAssert) → sent over the
    existing Bifrost WebSocket connection (same as before, but owned by zOS)
  - Browser primitives (zShot, zClick, zType, zDrag) → delegated to the
    standalone `zraven.py` subprocess which manages Playwright

This keeps Playwright as an optional dependency while giving zOS first-class
ownership of the test lifecycle.
"""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from zOS.core.L1_Foundation.a_zConfig.zConfig_modules.network.config_raven import zRavenConfig

_LOG_PREFIX = "[zRaven]"


class ZRavenRunner:
    """
    Runs a single zRaven test file inside a live zOS session.

    Lifecycle:
        runner = ZRavenRunner(zos, config)
        runner.start()          # non-blocking, runs in daemon thread
        runner.wait(timeout=120)
        runner.passed / runner.failed
    """

    def __init__(self, zos: Any, config: "zRavenConfig") -> None:
        self._zos     = zos
        self._config  = config
        self._logger  = zos.logger
        self._proc: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._exit_code: int | None = None

        self.passed = 0
        self.failed = 0

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Spawn test run in a daemon thread (non-blocking)."""
        self._thread = threading.Thread(
            target=self._run,
            daemon=True,
            name="zRaven",
        )
        self._thread.start()

    def wait(self, timeout: float | None = None) -> bool:
        """Block until test run completes. Returns True if all passed."""
        if self._thread:
            self._thread.join(timeout=timeout)
        return self._exit_code == 0

    def shutdown(self) -> None:
        """Terminate any running subprocess."""
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        self._proc = None

    # ── Internal ──────────────────────────────────────────────────────────────

    def _resolve_raven_file(self) -> Path | None:
        """Resolve zRaven/<name>.zolo relative to cwd."""
        name = self._config.name
        path = Path.cwd() / "zRaven" / f"zRaven.{name}.zolo"
        if not path.exists():
            self._logger.warning(
                f"{_LOG_PREFIX} File not found: {path} — skipping"
            )
            return None
        return path

    def _resolve_ws_url(self) -> str:
        try:
            health = self._zos.bifrost.health_check()
            if health.get("running"):
                return f"ws://{health.get('host', '127.0.0.1')}:{health.get('port', 8765)}"
        except Exception:  # pylint: disable=broad-except
            pass
        return "ws://127.0.0.1:8765"

    def _resolve_http_url(self) -> str:
        try:
            return self._zos.server.get_url()
        except Exception:  # pylint: disable=broad-except
            pass
        try:
            http = self._zos.config.http_server
            protocol = "https" if getattr(http, "ssl_enabled", False) else "http"
            return f"{protocol}://{http.host}:{http.port}"
        except Exception:  # pylint: disable=broad-except
            from zOS.core.L1_Foundation.a_zConfig.zConfig_modules.network.config_http_server import (
                DEFAULT_PORT as _DEFAULT_HTTP_PORT,
            )
            return f"http://127.0.0.1:{_DEFAULT_HTTP_PORT}"

    def _is_cli_mode(self) -> bool:
        """True when the app is zCLI-only (no Bifrost/WS server)."""
        zmode = self._zos.zspark_obj.get("zMode", "zCLI")
        return str(zmode).lower() in ("zcli", "cli")

    def _find_spark_name(self) -> str | None:
        """Scan cwd for zSpark.*.zolo and return the * part."""
        import glob as _glob  # pylint: disable=import-outside-toplevel
        matches = _glob.glob(str(Path.cwd() / "zSpark.*.zolo"))
        if matches:
            stem = Path(matches[0]).stem        # e.g. "zSpark.crm"
            parts = stem.split(".", 1)
            return parts[1] if len(parts) == 2 else None
        return None

    def _spark_boot_args(self) -> list[str]:
        args: list[str] = []
        spark = self._zos.zspark_obj
        for flag, key in (("--vaFolder", "zVaFolder"), ("--vaFile", "zVaFile"), ("--block", "zBlock")):
            val = spark.get(key, "")
            if val:
                args += [flag, val]
        return args

    def _ensure_playwright(self) -> None:
        try:
            subprocess.check_call(
                [sys.executable, "-m", "playwright", "install", "chromium", "--with-deps"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:  # pylint: disable=broad-except
            pass

    def _run(self) -> None:
        """Main test execution — runs in daemon thread."""
        # CLI mode: no WS server — drive the app via stdin/stdout
        if self._is_cli_mode():
            self._run_cli()
            return

        # WS mode: brief pause so Bifrost accepts connections before we connect
        time.sleep(1.5)

        raven_file = self._resolve_raven_file()
        if not raven_file:
            self._exit_code = 1
            return

        ws_url   = self._resolve_ws_url()
        http_url = self._resolve_http_url()

        self._ensure_playwright()

        cmd = (
            ["zraven", str(raven_file), "--ws", ws_url, "--http", http_url]
            + self._spark_boot_args()
        )

        env = {**os.environ, "PYTHONUNBUFFERED": "1"}
        self._logger.info(f"{_LOG_PREFIX} Running tests: {raven_file.name}")

        try:
            self._proc = subprocess.Popen(cmd, cwd=str(Path.cwd()), env=env)
            try:
                self._proc.wait(timeout=self._config.timeout)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                self._logger.error(
                    f"{_LOG_PREFIX} Runner timed out after {self._config.timeout}s"
                )
                self._exit_code = 1
                return

            self._exit_code = self._proc.returncode
            if self._exit_code == 0:
                self._logger.info(f"{_LOG_PREFIX} All tests passed ✓")
            else:
                self._logger.warning(
                    f"{_LOG_PREFIX} Some tests failed (exit {self._exit_code})"
                )

        except Exception as exc:  # pylint: disable=broad-except
            self._logger.error(f"{_LOG_PREFIX} Runner error: {exc}")
            self._exit_code = 1
        finally:
            self._proc = None
            self._zos.request_shutdown(source="zRaven")

    def _run_cli(self) -> None:
        """CLI mode — drive app via zraven --mode cli subprocess."""
        raven_file = self._resolve_raven_file()
        if not raven_file:
            self._exit_code = 1
            self._zos.request_shutdown(source="zRaven")
            return

        spark_name = self._find_spark_name()
        if not spark_name:
            self._logger.error(f"{_LOG_PREFIX} Could not find zSpark.*.zolo in {Path.cwd()}")
            self._exit_code = 1
            self._zos.request_shutdown(source="zRaven")
            return

        cmd = [
            "zraven", str(raven_file),
            "--mode", "cli",
            "--spark", spark_name,
            "--appdir", str(Path.cwd()),
        ]
        env = {**os.environ, "PYTHONUNBUFFERED": "1"}
        self._logger.info(f"{_LOG_PREFIX} Running CLI tests: {raven_file.name} (spark: {spark_name})")

        try:
            self._proc = subprocess.Popen(cmd, cwd=str(Path.cwd()), env=env)
            try:
                self._proc.wait(timeout=self._config.timeout)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                self._logger.error(f"{_LOG_PREFIX} CLI runner timed out after {self._config.timeout}s")
                self._exit_code = 1
                return

            self._exit_code = self._proc.returncode
            if self._exit_code == 0:
                self._logger.info(f"{_LOG_PREFIX} All CLI tests passed ✓")
            else:
                self._logger.warning(f"{_LOG_PREFIX} Some CLI tests failed (exit {self._exit_code})")

        except Exception as exc:  # pylint: disable=broad-except
            self._logger.error(f"{_LOG_PREFIX} CLI runner error: {exc}")
            self._exit_code = 1
        finally:
            self._proc = None
            self._zos.request_shutdown(source="zRaven")
