# zOS/core/L4_Orchestration/r_zServer/zServer_modules/zserver_constants.py

"""
zServer Constants - Centralized configuration values

All magic strings, folder names, URL prefixes, and file patterns used
throughout zServer subsystem. Modify here to change conventions globally.
"""

# ============================================================================
# Folder Conventions
# ============================================================================

FOLDER_STATIC = "static"
"""Default folder for static files (CSS, JS, images)."""

FOLDER_TEMPLATES = "templates"
"""Default folder for Jinja2 templates."""

FOLDER_UI = "UI"
"""Default folder for zUI zVaF files."""

FOLDER_MODELS = "models"
"""Default folder for zSchema files (auto-initialized on startup)."""

FOLDER_ROUTES = "routes"
"""Default subfolder for modular route blueprints."""

FOLDER_PLUGINS = "plugins"
"""Default folder for JavaScript plugins."""

FOLDER_BIFROST = "bifrost"
"""Default folder name for bifrost client files."""

# ============================================================================
# URL Mount Prefixes
# ============================================================================

MOUNT_BIFROST = "/bifrost/"
"""URL prefix for bifrost client files."""

MOUNT_PLUGINS = "/plugins/"
"""URL prefix for JavaScript plugins."""

MOUNT_ZTHEME = "/ztheme/"
"""URL prefix for zTheme CSS framework."""

# ============================================================================
# File Patterns (glob-style)
# ============================================================================

PATTERN_ROUTE_FILES = ["zServer.*.zolo", "zServer.*.yaml", "zServer.*.json"]
"""File patterns for auto-detected route files. Supports .zolo, .yaml, .json formats (priority order)."""

PATTERN_SCHEMA_FILES = ["**/zSchema.*.zolo", "**/zSchema.*.yaml", "**/zSchema.*.json"]
"""File patterns for auto-detected schema files. Supports .zolo, .yaml, .json formats (priority order). Recurses into subdirectories."""

# ============================================================================
# Deployment Modes
# ============================================================================

MODE_DEVELOPMENT = "Development"
"""Development mode - uses http.server in background thread."""

MODE_TESTING = "Testing"
"""Testing mode - same as Development but with test-specific config."""

MODE_PRODUCTION = "Production"
"""Production mode - uses Gunicorn subprocess."""

# ============================================================================
# Network Defaults
# ============================================================================

DEFAULT_HOST = "127.0.0.1"
"""Default host address for local development."""

# SSOT: config_http_server.DEFAULT_PORT — keep in sync manually; avoid re-importing here
# to prevent circular init (this module loads early in the zOS boot chain).
DEFAULT_PORT = 8080
"""Default HTTP port — must match config_http_server.DEFAULT_PORT."""

# ============================================================================
# WSGI Configuration
# ============================================================================

WSGI_TEMP_MODULE = "_zserver_wsgi_temp.py"
"""Temporary WSGI module filename for Gunicorn."""

WSGI_TEMP_COMPILED = "_zserver_wsgi_temp.pyc"
"""Compiled WSGI module filename."""

# ============================================================================
# Bifrost Configuration (Manual Only - No Auto-Mounting)
# ============================================================================

# Note: Bifrost auto-mounting removed. Configure via ZSERVER_MOUNTS in zEnv:
#   Development: ZSERVER_MOUNTS: {"/bifrost/": "/path/to/zOS/bifrost/"}
#   Production: Use CDN in templates
#
# BIFROST_SEARCH_PATHS = [
#     "{zos_root}/bifrost",  # Standard location: zOS/bifrost/
#     "{cwd}/bifrost"        # Fallback location: {cwd}/bifrost
# ]

# ============================================================================
# Plugin Auto-Mount Locations (in priority order)
# ============================================================================

PLUGIN_SEARCH_PATHS = [
    "{serve_path}/plugins",   # Project-specific plugins
    "{cwd}/zCloud/plugins",   # zCloud plugins
    "{cwd}/plugins"           # Root plugins
]
"""Search paths for plugins folder (relative path templates)."""
