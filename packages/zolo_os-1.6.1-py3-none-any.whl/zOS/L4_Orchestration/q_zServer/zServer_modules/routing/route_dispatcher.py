# zOS/core/L4_Orchestration/r_zServer/zServer_modules/handler/route_dispatcher.py

"""
Route Dispatcher - HTTP route handling and processing

Handles:
- Route matching and RBAC enforcement
- Type-specific route processing (static, content, template, walker, form, json, zfunc, dynamic)
- Request/response flow for each route type
"""

from zOS import os
import mimetypes
from urllib.parse import urlparse

from .utils import HandlerUtils
from ..utils import http_cache_utils


def _build_nav_html_safe(navbar_items, brand, logger=None):
    """3A: Build navbar HTML string from RBAC-filtered items. Returns None on any failure."""
    if not navbar_items:
        return None
    try:
        from .nav_html_builder import build_nav_html
        return build_nav_html(navbar_items, brand=brand)
    except Exception as exc:
        if logger:
            logger.debug(f'[RouteDispatcher] nav_html build skipped: {exc}')
        return None


class RouteDispatcher:
    """Handles HTTP route matching, RBAC, and type-specific processing."""

    def __init__(self, handler):
        """
        Initialize route dispatcher.
        
        Args:
            handler: Parent HTTP request handler instance
        """
        self.handler = handler
        self.logger = getattr(handler, 'logger', None)
        self.router = getattr(handler, 'router', None)

    def _handle_route_config_request(self):
        """
        2B: Return walker config (zBlock, zVaFile, zVaFolder) for a given path.

        Client calls GET /api/route-config?path=/zProducts/zOS to get the three
        parameters it needs for execute_walker, instead of parsing paths locally.
        """
        import json
        from urllib.parse import parse_qs
        query = parse_qs(urlparse(self.handler.path).query)
        path = query.get('path', [''])[0]

        if not path:
            body = json.dumps({'error': 'Missing ?path= parameter'}).encode('utf-8')
            self.handler.send_response(400)
        else:
            route = self.router.match_route(path)
            if not route or route.get('type') != 'zWalker':
                body = json.dumps({'error': f'No zWalker route for {path}'}).encode('utf-8')
                self.handler.send_response(404)
            else:
                payload = {
                    'zBlock':     route.get('zBlock'),
                    'zVaFile':    route.get('zVaFile'),
                    'zVaFolder':  route.get('zVaFolder'),
                }
                body = json.dumps(payload).encode('utf-8')
                self.handler.send_response(200)

        self.handler.send_header('Content-Type', 'application/json')
        self.handler.send_header('Content-Length', len(body))
        self.handler.send_header('Cache-Control', 'no-store')
        self.handler.end_headers()
        self.handler.wfile.write(body)

    def handle_routed_request(self):
        """
        Handle request using HTTPRouter with RBAC enforcement.
        
        Flow:
            1. Match route (without query params)
            2. Check RBAC
            3. Dispatch to type-specific handler
        """
        # Strip query parameters for route matching
        clean_path = urlparse(self.handler.path).path

        # 2B: Route-config API — served before RBAC/router to avoid needing a yaml entry
        if clean_path == '/api/route-config':
            return self._handle_route_config_request()

        # DEBUG: Log route matching attempt
        if self.logger:
            self.logger.info(f"[RouteDispatcher] Attempting to match route: {clean_path}")
            self.logger.info(f"[RouteDispatcher] Router has {len(self.router.auto_discovered_routes)} auto-discovered routes")

        # Match route (without query parameters)
        route = self.router.match_route(clean_path)
        if not route:
            # No route found - 404
            if self.logger:
                self.logger.warning(f"[RouteDispatcher] No route match found for: {self.handler.path}")
            return self.handler.send_error(404, "Route not found")

        # Check RBAC
        has_access, error_page = self.router.check_access(route)
        if not has_access:
            # Access denied - log security event with details
            if self.logger:
                required_roles = route.get('roles', [])
                self.logger.warning(f"[SECURITY] Access denied to {clean_path} - Required roles: {required_roles}")
            return self.handler.send_error(403, "Access Denied")

        # Access granted - log with route details
        route_type = route.get("type", "static")
        if self.logger:
            self.logger.info(f"[RouteDispatcher] Access granted - Route: {clean_path}, Type: {route_type}")

        if route_type == "static":
            return self._handle_static_route(route)
        elif route_type == "content":
            return self._handle_content_route(route)
        elif route_type == "template":
            return self._handle_template_route(route)
        elif route_type == "zWalker":
            return self._handle_zwalker_route(route)
        elif route_type == "form":
            return self._handle_form_route(route)
        elif route_type == "json":
            return self._handle_json_route(route)
        elif route_type == "dynamic":
            return self._handle_dynamic_route(route)
        elif route_type == "zFunc":
            return self._handle_zfunc_route(route)

        # Unknown route type
        return self.handler.send_error(501, f"Route type '{route_type}' not supported")

    def _handle_static_route(self, route: dict):
        """Handle static file route."""
        # Serve static file directly
        file_path = self.router.resolve_file_path(route)

        # Check if file exists
        if not os.path.exists(file_path):
            return self.handler.send_error(404, f"File not found: {file_path}")

        # Check if it's a directory (not allowed for static routes)
        if os.path.isdir(file_path):
            return self.handler.send_error(403, "Directory listing is disabled")

        # Serve the file directly
        try:
            with open(file_path, 'rb') as f:
                content = f.read()

            # Determine content type
            content_type, _ = mimetypes.guess_type(file_path)
            if not content_type:
                content_type = 'application/octet-stream'

            self.handler.send_response(200)
            self.handler.send_header("Content-type", content_type)
            self.handler.send_header("Content-length", len(content))
            self.handler.end_headers()
            self.handler.wfile.write(content)

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] Error serving static file: {e}")
            return self.handler.send_error(500, f"Error serving file: {str(e)}")

    def _handle_content_route(self, route: dict):
        """
        Handle content route - serve inline HTML string (like Flask return "<h1>...</h1>").
        
        Args:
            route: Route definition with "content" field
        """
        try:
            # Extract HTML content from route
            html_content = route.get("content", "")

            if not html_content:
                return self.handler.send_error(500, "Content route missing 'content' field")

            # Send HTML response
            self.handler.send_response(200)
            self.handler.send_header("Content-type", "text/html")
            self.handler.send_header("Content-length", len(html_content.encode('utf-8')))
            self.handler.end_headers()
            self.handler.wfile.write(html_content.encode('utf-8'))

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] Content route error: {e}")
            return self.handler.send_error(500, f"Content serving failed: {str(e)}")

    def _handle_template_route(self, route: dict):
        """
        Handle template route - render Jinja2 template (like Flask render_template()).
        
        Now zWalker-aware: If route has zVaFile, it will be converted to URL and injected
        into template context for client-side loading (mixed mode support).
        
        Args:
            route: Route definition with "template" field and optional "context" dict
        """
        try:
            template_name = route.get("template", "")
            if not template_name:
                return self.handler.send_error(500, "Template route missing 'template' field")

            # Get context data (variables to pass to template)
            context = route.get("context", {})

            # Get zos instance from router
            if not hasattr(self.router, 'zos'):
                return self.handler.send_error(500, "zOS instance not available")

            # Auto-inject zSession values (zVaFile, zVaFolder, zBlock) into context
            # so templates can render them without manual Jinja plumbing
            zos = self.router.zos
            if hasattr(zos, 'session') and zos.session:
                # Check if this is the root route "/" - if so, use zSpark defaults (not session)
                clean_path = urlparse(self.handler.path).path
                is_root_route = (clean_path == "/" or clean_path == "")

                # Only inject if not already present in route context
                if "zVaFile" not in context:
                    if is_root_route and hasattr(zos, 'spark') and zos.spark:
                        # Root route: Use zSpark default (declarative, not stateful)
                        context["zVaFile"] = zos.spark.get("zVaFile")
                    else:
                        # Other routes: Use session state (allows navigation memory)
                        context["zVaFile"] = zos.session.get("zVaFile")

                if "zVaFolder" not in context:
                    if is_root_route and hasattr(zos, 'spark') and zos.spark:
                        context["zVaFolder"] = zos.spark.get("zVaFolder")
                    else:
                        context["zVaFolder"] = zos.session.get("zVaFolder")

                if "zBlock" not in context:
                    if is_root_route and hasattr(zos, 'spark') and zos.spark:
                        # Root route: Use zSpark default block (prevents session bleed)
                        context["zBlock"] = zos.spark.get("zBlock")
                    else:
                        # Other routes: Use session state
                        context["zBlock"] = zos.session.get("zBlock")

                # Debug: log what we got and from where
                if self.logger:
                    source = "zSpark (root route)" if is_root_route else "zSession"
                    self.logger.info(f"[RouteDispatcher] Auto-injected from {source}: zVaFile={context.get('zVaFile')}, zVaFolder={context.get('zVaFolder')}, zBlock={context.get('zBlock')}")

            # Route-level overrides (opt-in): Explicit route config takes precedence
            # This allows routes to override zSpark/session defaults
            zVaFile = route.get("zVaFile")
            if zVaFile:
                ui_folder_name = self.handler.mount_manager.get_folder_name("UI")
                ui_file_path = HandlerUtils.convert_zpath_to_url(zVaFile, ui_folder_name)
                context["zVaFile"] = ui_file_path
                if self.logger:
                    self.logger.debug(f"[RouteDispatcher] Route override: zVaFile={ui_file_path}")

            zBlock = route.get("zBlock")
            if zBlock:
                context["zBlock"] = zBlock
                if self.logger:
                    self.logger.debug(f"[RouteDispatcher] Route override: zBlock={zBlock}")

            # Get templates directory using MountManager
            from jinja2 import Environment, FileSystemLoader, TemplateNotFound

            templates_dir = self.handler.mount_manager.get_folder_path("templates")

            # Create Jinja2 environment
            env = Environment(loader=FileSystemLoader(templates_dir))

            # Add cache-busting timestamp
            import time
            context['timestamp'] = int(time.time() * 1000)

            # Render template
            template = env.get_template(template_name)
            html_content = template.render(**context)

            # Resolve navbar with route metadata fallback (same as zWalker routes)
            resolved_navbar = None
            if hasattr(zos, 'navigation'):
                # Load the zVaFile to check its meta.zNavBar (if provided in context)
                zVaFile = context.get("zVaFile")
                zVaFolder = context.get("zVaFolder")
                try:
                    # Construct zPath from zVaFolder/zVaFile (e.g., "@.UI" + "zUI.zAbout" → "@.UI.zUI.zAbout")
                    if zVaFile and zVaFolder:
                        # Remove @ prefix and leading dots from folder
                        folder_parts = zVaFolder.lstrip('@.').split('.')
                        file_parts = zVaFile.split('.')
                        # Construct full zPath
                        zPath = '@.' + '.'.join(folder_parts + file_parts)
                        raw_zFile = zos.loader.handle(zPath=zPath)

                        # Extract zMeta section from YAML for client-side features (v1.5.13: _zScripts support)
                        if raw_zFile and isinstance(raw_zFile, dict):
                            meta_section = raw_zFile.get("zMeta", {})
                            if isinstance(meta_section, dict):
                                context["zVaFile_meta"] = meta_section
                                if self.logger:
                                    self.logger.info(f"[RouteDispatcher] Extracted YAML zMeta for client: {list(meta_section.keys())}")
                            else:
                                context["zVaFile_meta"] = {}
                        else:
                            context["zVaFile_meta"] = {}
                    else:
                        raw_zFile = None

                    # Get router meta for fallback
                    route_meta = self.router.meta if self.router and hasattr(self.router, 'meta') else {}
                    # Resolve navbar with priority chain (returns raw navbar with RBAC metadata)
                    resolved_navbar = zos.navigation.resolve_navbar(raw_zFile, route_meta=route_meta) if raw_zFile else None

                    # 🔒 RBAC Filter: Apply dynamic RBAC filtering for Bifrost (same as Terminal)
                    # This filters out items the current user can't access before injecting into HTML
                    if resolved_navbar:
                        resolved_navbar = zos.navigation._filter_navbar_byzRBAC(resolved_navbar)
                        if self.logger:
                            self.logger.debug(f"[RouteDispatcher] RBAC-filtered navbar for Bifrost: {resolved_navbar}")
                except Exception:
                    resolved_navbar = None

            # Extract page title from YAML metadata (zTitle field in zMeta)
            # Get app brand (always from zSpark for navbar consistency)
            zVaFile_meta = context.get("zVaFile_meta", {})
            app_brand = zos.config.zSpark.get("title") if hasattr(zos, 'config') and hasattr(zos.config, 'zSpark') and zos.config.zSpark else None
            page_ztitle = zVaFile_meta.get("zTitle") if zVaFile_meta else None
            
            # Construct full page title:
            # - If zTitle exists: "zSpark.title - zTitle" (e.g., "zCloud - zOS")
            # - Otherwise: just "zSpark.title" (e.g., "zCloud")
            if page_ztitle and app_brand:
                page_title = f"{app_brand} - {page_ztitle}"
            elif page_ztitle:
                page_title = page_ztitle
            else:
                page_title = app_brand
            
            # Set title in template context for Jinja {{ title }}
            if page_title:
                context["title"] = page_title

            # Auto-inject zUI config script before </head> (if zSession values present)
            # This makes zBifrost/zSession integration automatic for HTML authors
            nav_html = _build_nav_html_safe(resolved_navbar, app_brand, self.logger)

            zui_config_values = {
                "zVaFile": context.get("zVaFile"),
                "zVaFolder": context.get("zVaFolder"),
                "zBlock": context.get("zBlock"),
                "title": page_title,  # Per-page title (for document.title)
                "brand": app_brand,  # App brand (for navbar, always zSpark)
                "zNavBar": resolved_navbar,  # Use RBAC-filtered navbar (clean strings only)
                "nav_html": nav_html,  # 3A: Pre-built HTML — client injects directly
                "zMeta": zVaFile_meta  # v1.5.13: Include YAML metadata for client features (_zScripts, etc)
            }
            # Only inject if at least one value is present (not all None)
            if any(v is not None for v in zui_config_values.values()):
                import json
                zui_config_json = json.dumps(zui_config_values, indent=4)
                zui_config_script = f'\n<!-- zUI Config (auto-injected from zSession) -->\n<script id="zui-config" type="application/json">\n{zui_config_json}\n</script>\n</head>'
                html_content = html_content.replace('</head>', zui_config_script, 1)
                if self.logger:
                    self.logger.info(f"[RouteDispatcher] Auto-injected <script id='zui-config'> into HTML head")
            else:
                if self.logger:
                    self.logger.debug(f"[RouteDispatcher] Skipped zui-config injection (all values None)")

            # Send HTML response with cache headers
            html_bytes = html_content.encode('utf-8')
            
            self.handler.send_response(200)
            self.handler.send_header("Content-type", "text/html; charset=utf-8")
            self.handler.send_header("Content-length", len(html_bytes))
            self.handler.cache_manager.add_cache_headers(
                self.handler, 
                file_path=None,
                file_type="template",
                content=html_bytes
            )
            self.handler.end_headers()
            self.handler.wfile.write(html_bytes)

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] Template rendering error: {e}")
            return self.handler.send_error(500, f"Template rendering failed: {str(e)}")

    def _handle_zwalker_route(self, route: dict):
        """
        Handle zWalker route - Execute zVaF blocks server-side using zVaF.html template.
        
        Supports hierarchical fallbacks: route → session
        - zVaFolder: route value OR session default
        - zVaFile: route value OR session default
        - zBlock: route value OR session default
        
        Args:
            route: Route definition with optional "context" dict
        """
        try:
            # Import needed modules
            from jinja2 import Environment, FileSystemLoader, TemplateNotFound

            # Get zos instance for session access
            zos = self.router.zos if hasattr(self.router, 'zos') else None

            # zWalker routes always use zVaF.html (full declarative mode)
            template_name = "zVaF.html"

            # Get context data (variables to pass to template)
            context = route.get("context", {})

            # NEW v1.5.12: Resolve _data queries at route level (Flask pattern)
            # This executes database queries BEFORE rendering, storing results in context
            if "_data" in route and zos:
                resolved_data = HandlerUtils.resolve_route_data(route["_data"], zos, self.logger)
                if resolved_data:
                    context["_resolved_data"] = resolved_data
                    if self.logger:
                        self.logger.info(f"[RouteDispatcher] Resolved {len(resolved_data)} data queries for route")

            # Apply hierarchical fallbacks: route → zSpark (root) / session (other)
            # Route-level values override defaults
            if zos:
                # Check if this is the root route "/" - if so, use zSpark defaults (not session)
                clean_path = urlparse(self.handler.path).path
                is_root_route = (clean_path == "/" or clean_path == "")

                # Priority: route → zSpark (root) / session (other)
                if is_root_route and hasattr(zos, 'spark') and zos.spark:
                    # Root route: Use zSpark defaults (declarative, not stateful)
                    zVaFolder = route.get("zVaFolder") or zos.spark.get("zVaFolder")
                    zVaFile = route.get("zVaFile") or zos.spark.get("zVaFile")
                    zBlock = route.get("zBlock") or zos.spark.get("zBlock")
                else:
                    # Other routes: Use session state (allows navigation memory)
                    zVaFolder = route.get("zVaFolder") or zos.session.get("zVaFolder")
                    zVaFile = route.get("zVaFile") or zos.session.get("zVaFile")
                    zBlock = route.get("zBlock") or zos.session.get("zBlock")

                if self.logger:
                    source = "zSpark (root)" if is_root_route else "zSession"
                    self.logger.debug(f"[RouteDispatcher] zWalker resolved from {source} - Folder: {zVaFolder}, File: {zVaFile}, Block: {zBlock}")
            else:
                # No session available - use route values only
                zVaFolder = route.get("zVaFolder")
                zVaFile = route.get("zVaFile")
                zBlock = route.get("zBlock")

            # Store resolved values in context for template/future use
            if zVaFolder:
                context["zVaFolder"] = zVaFolder
            if zVaFile:
                context["zVaFile"] = zVaFile
            if zBlock:
                context["zBlock"] = zBlock

            # Store route metadata in session for zWalker access (navbar fallback)
            # This allows zWalker to check route-level meta.zNavBar as fallback
            if zos and hasattr(zos, 'session'):
                # Get router's route metadata (if exists)
                if self.router and hasattr(self.router, 'route_map'):
                    # Try to get route metadata from router
                    matched_route = self.router.route_map.get(self.handler.path)
                    if not matched_route:
                        # Try auto-discovered routes
                        matched_route = self.router.auto_discovered_routes.get(self.handler.path)

                    if matched_route:
                        # Store route metadata for walker access
                        zos.session['_route_meta'] = matched_route

                # Also inject router meta (global route config) as fallback
                if self.router and hasattr(self.router, 'meta'):
                    zos.session['_router_meta'] = self.router.meta

            # Get templates directory using MountManager
            templates_dir = self.handler.mount_manager.get_folder_path("templates")

            # Create Jinja2 environment
            env = Environment(loader=FileSystemLoader(templates_dir))

            # Add cache-busting timestamp
            import time
            context['timestamp'] = int(time.time() * 1000)

            # Render template with context (Jinja2 support)
            template = env.get_template(template_name)
            html_content = template.render(**context)

            # Resolve navbar with route metadata fallback
            resolved_navbar = None
            if zos and hasattr(zos, 'navigation'):
                # Load the zVaFile to check its meta.zNavBar
                try:
                    # Construct zPath from zVaFolder/zVaFile (e.g., "@.UI" + "zUI.zAbout" → "@.UI.zUI.zAbout")
                    if zVaFile and zVaFolder:
                        # Remove @ prefix and leading dots from folder
                        folder_parts = zVaFolder.lstrip('@.').split('.')
                        file_parts = zVaFile.split('.')
                        # Construct full zPath
                        zPath = '@.' + '.'.join(folder_parts + file_parts)
                        raw_zFile = zos.loader.handle(zPath=zPath)

                        # Extract zMeta section from YAML for client-side features (v1.5.13: _zScripts support)
                        if raw_zFile and isinstance(raw_zFile, dict):
                            meta_section = raw_zFile.get("zMeta", {})
                            if isinstance(meta_section, dict):
                                context["zVaFile_meta"] = meta_section
                                if self.logger:
                                    self.logger.info(f"[RouteDispatcher] Extracted YAML zMeta for client: {list(meta_section.keys())}")
                            else:
                                context["zVaFile_meta"] = {}
                        else:
                            context["zVaFile_meta"] = {}
                    else:
                        raw_zFile = None

                    # Get router meta for fallback
                    route_meta = self.router.meta if self.router and hasattr(self.router, 'meta') else {}
                    # Resolve navbar with priority chain (returns raw navbar with RBAC metadata)
                    resolved_navbar = zos.navigation.resolve_navbar(raw_zFile, route_meta=route_meta) if raw_zFile else None

                    # 🔒 RBAC Filter: Apply dynamic RBAC filtering for Bifrost (same as Terminal)
                    # This filters out items the current user can't access before injecting into HTML
                    if resolved_navbar:
                        resolved_navbar = zos.navigation._filter_navbar_byzRBAC(resolved_navbar)
                        if self.logger:
                            self.logger.debug(f"[RouteDispatcher] RBAC-filtered navbar for zWalker route: {resolved_navbar}")
                except Exception as e:
                    if self.logger:
                        self.logger.warning(f"[RouteDispatcher] Could not resolve navbar: {e}")
                    resolved_navbar = None

            # Extract page title from YAML metadata (zTitle field in zMeta)
            # Get app brand (always from zSpark for navbar consistency)
            zVaFile_meta = context.get("zVaFile_meta", {})
            app_brand = zos.config.zSpark.get("title") if zos and hasattr(zos, 'config') and hasattr(zos.config, 'zSpark') and zos.config.zSpark else None
            page_ztitle = zVaFile_meta.get("zTitle") if zVaFile_meta else None
            
            # Construct full page title:
            # - If zTitle exists: "zSpark.title - zTitle" (e.g., "zCloud - zOS")
            # - Otherwise: just "zSpark.title" (e.g., "zCloud")
            if page_ztitle and app_brand:
                page_title = f"{app_brand} - {page_ztitle}"
            elif page_ztitle:
                page_title = page_ztitle
            else:
                page_title = app_brand
            
            # Set title in template context for Jinja {{ title }}
            if page_title:
                context["title"] = page_title
            
            # Auto-inject zUI config script before </head> (same as template routes)
            nav_html = _build_nav_html_safe(resolved_navbar, app_brand, self.logger)

            zui_config_values = {
                "zVaFile": context.get("zVaFile"),
                "zVaFolder": context.get("zVaFolder"),
                "zBlock": context.get("zBlock"),
                "title": page_title,  # Per-page title (for document.title)
                "brand": app_brand,  # App brand (for navbar, always zSpark)
                "zNavBar": resolved_navbar,  # Use RBAC-filtered navbar (clean strings only)
                "nav_html": nav_html,  # 3A: Pre-built HTML — client injects directly
                "zMeta": zVaFile_meta,  # v1.5.13: Include YAML metadata for client features (_zScripts, etc)
                "websocket": {
                    "ssl_enabled": zos.config.websocket.ssl_enabled if zos and hasattr(zos, 'config') and hasattr(zos.config, 'websocket') else False,
                    "host": zos.config.websocket.host if zos and hasattr(zos, 'config') and hasattr(zos.config, 'websocket') else "127.0.0.1",
                    "port": zos.config.websocket.port if zos and hasattr(zos, 'config') and hasattr(zos.config, 'websocket') else 8765
                }
            }
            if any(v is not None for v in zui_config_values.values()):
                import json
                zui_config_json = json.dumps(zui_config_values, indent=4)
                zui_config_script = f'\n<!-- zUI Config (auto-injected from zSession) -->\n<script id="zui-config" type="application/json">\n{zui_config_json}\n</script>\n</head>'
                html_content = html_content.replace('</head>', zui_config_script, 1)
                if self.logger:
                    self.logger.info(f"[RouteDispatcher] zWalker route - Auto-injected zui-config: {zui_config_values}")

            # Send HTML response with cache headers
            html_bytes = html_content.encode('utf-8')
            
            self.handler.send_response(200)
            self.handler.send_header("Content-type", "text/html; charset=utf-8")
            self.handler.send_header("Content-length", len(html_bytes))
            self.handler.cache_manager.add_cache_headers(
                self.handler, 
                file_path=None,
                file_type="ui",
                content=html_bytes
            )
            self.handler.end_headers()
            self.handler.wfile.write(html_bytes)

            if self.logger:
                self.logger.debug(f"[RouteDispatcher] Served zWalker route: {self.handler.path}")

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] zWalker rendering error: {e}")
            return self.handler.send_error(500, f"zWalker rendering failed: {str(e)}")

    def _handle_dynamic_route(self, route: dict):
        """
        Handle dynamic route - render zUI to HTML.
        
        Args:
            route: Route definition with zVaFile and zBlock
        """
        try:
            # Extract zVaF file and block from route
            zVaFile = route.get("zVaFile", "")
            zBlock = route.get("zBlock", "zVaF")

            if not zVaFile:
                return self.handler.send_error(500, "Dynamic route missing zVaFile")

            # Get zos instance from router
            if not hasattr(self.router, 'zos'):
                return self.handler.send_error(500, "zOS instance not available")

            # Import and create page renderer with routes for dual-mode navigation
            from ..rendering.page_renderer import PageRenderer
            routes = self.router.routes.get('routes', {}) if hasattr(self.router, 'routes') else {}
            renderer = PageRenderer(self.router.zos, routes=routes)

            # Render zUI to HTML
            html_content = renderer.render_page(zVaFile, zBlock)

            # Send HTML response
            self.handler.send_response(200)
            self.handler.send_header("Content-type", "text/html")
            self.handler.send_header("Content-length", len(html_content.encode('utf-8')))
            self.handler.end_headers()
            self.handler.wfile.write(html_content.encode('utf-8'))

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] Dynamic route error: {e}")
            return self.handler.send_error(500, f"Dynamic rendering failed: {str(e)}")

    def _handle_form_route(self, route: dict):
        """
        Handle form route - declarative web form processing (zDialog pattern).
        
        Args:
            route: Route definition with model, fields, onSubmit, etc.
        """
        try:
            # Only accept POST for forms
            if self.handler.command != 'POST':
                return self.handler.send_error(405, "Form routes only accept POST")

            # Get zos instance from router
            if not hasattr(self.router, 'zos'):
                return self.handler.send_error(500, "zOS instance not available")

            # Read POST body
            content_length = int(self.handler.headers.get('Content-Length', 0))
            body = self.handler.rfile.read(content_length)
            content_type = self.handler.headers.get('Content-Type', '')

            # Parse form data
            from ..rendering.form_utils import parse_form_data, process_form_submission

            form_data = parse_form_data(body, content_type, self.logger)

            # Process form submission
            success, redirect_url, error_message = process_form_submission(
                route, form_data, self.router.zos, self.logger
            )

            if success and redirect_url:
                # Redirect to success page
                self.handler.send_response(303)  # See Other (POST-redirect-GET pattern)
                self.handler.send_header("Location", redirect_url)
                self.handler.end_headers()
            elif not success and redirect_url:
                # Redirect to error page with error message in query param
                error_url = f"{redirect_url}?error={error_message}" if error_message else redirect_url
                self.handler.send_response(303)
                self.handler.send_header("Location", error_url)
                self.handler.end_headers()
            elif success:
                # No redirect specified - send success message
                self.handler.send_response(200)
                self.handler.send_header("Content-type", "text/html")
                response_html = "<h1>Form submitted successfully</h1>"
                self.handler.send_header("Content-length", len(response_html.encode('utf-8')))
                self.handler.end_headers()
                self.handler.wfile.write(response_html.encode('utf-8'))
            else:
                # No redirect specified - send error message
                self.handler.send_response(400)
                self.handler.send_header("Content-type", "text/html")
                response_html = f"<h1>Form submission failed</h1><p>{error_message}</p>"
                self.handler.send_header("Content-length", len(response_html.encode('utf-8')))
                self.handler.end_headers()
                self.handler.wfile.write(response_html.encode('utf-8'))

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] Form route error: {e}")
            return self.handler.send_error(500, f"Form processing failed: {str(e)}")

    def _handle_json_route(self, route: dict):
        """
        Handle JSON route - declarative JSON response with HTTP caching.
        
        Args:
            route: Route definition with data field
        """
        try:
            # Get zos instance from router
            if not hasattr(self.router, 'zos'):
                return self.handler.send_error(500, "zOS instance not available")

            zos = self.router.zos
            
            # Try to get cache metadata from zLoader for ETag generation
            # This works if the JSON route uses {zNavBar} placeholder which loads UI file
            etag = None
            last_modified = None
            
            # Check if this route loads a UI file (e.g., /api/zui/config)
            # We can derive this from session context
            if hasattr(zos, 'session'):
                zVaFile = zos.session.get('zVaFile')
                zVaFolder = zos.session.get('zVaFolder')
                
                if zVaFile and zVaFolder:
                    # Construct zPath to check cache
                    folder_parts = zVaFolder.lstrip('@.').split('.')
                    file_parts = zVaFile.split('.')
                    zPath = '@.' + '.'.join(folder_parts + file_parts)
                    
                    # Get cache key (SystemCache uses "parsed:{absolute_path}" format)
                    # We need to resolve zPath to absolute path
                    try:
                        # Get metadata from SystemCache without triggering hit counter
                        cache_key = f"parsed:{zos.loader.resolve_path(zPath)}"
                        metadata = zos.loader.cache.system_cache.get_metadata(cache_key)
                        
                        if metadata and 'mtime' in metadata:
                            last_modified = metadata['mtime']
                            
                            # Check cache and serve 304 if valid
                            should_serve, sent = self.handler.cache_manager.check_and_serve_cached(
                                self.handler, 
                                file_path=None,
                                file_type="api",
                                mtime=last_modified
                            )
                            if sent:
                                return  # 304 already sent
                    except Exception:
                        # If cache lookup fails, proceed without cache check
                        pass

            # Extract query parameters for placeholder resolution
            from ..rendering.form_utils import extract_query_params
            query_params = extract_query_params(self.handler.path)

            # Render JSON response
            from ..utils.json_utils import render_json_response

            body, status_code, headers = render_json_response(
                route, self.router.zos, self.logger, query_params
            )
            
            # Send response with cache headers
            self.handler.send_response(status_code)
            for header_name, header_value in headers.items():
                self.handler.send_header(header_name, header_value)
            
            # Add cache headers (use mtime from cache if available, otherwise content-based ETag)
            self.handler.cache_manager.add_cache_headers(
                self.handler,
                file_path=None, 
                file_type="api",
                content=body,
                mtime=last_modified if last_modified else None
            )
            
            self.handler.end_headers()
            self.handler.wfile.write(body)

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] JSON route error: {e}")
            return self.handler.send_error(500, f"JSON rendering failed: {str(e)}")

    def _handle_zfunc_route(self, route: dict):
        """
        Handle zFunc route - call plugin function directly (for file uploads, API endpoints).
        
        Args:
            route: Route definition with handler field (&plugin.function)
        """
        if self.logger:
            self.logger.info(f"[RouteDispatcher] _handle_zfunc_route called for: {route.get('handler', 'UNKNOWN')}")

        try:
            # Get zos instance from router
            if not hasattr(self.router, 'zos'):
                if self.logger:
                    self.logger.error("[RouteDispatcher] No zos instance on router")
                return self.handler.send_error(500, "zOS instance not available")

            # Get handler reference
            handler = route.get("handler", "")
            if self.logger:
                self.logger.info(f"[RouteDispatcher] Got handler: {handler}")

            if not handler or not handler.startswith("&"):
                if self.logger:
                    self.logger.error(f"[RouteDispatcher] Invalid handler: {handler}")
                return self.handler.send_error(500, "Invalid handler reference - must start with &")

            # Parse handler reference: &plugin.function
            handler_parts = handler[1:].split(".")
            if len(handler_parts) != 2:
                if self.logger:
                    self.logger.error(f"[RouteDispatcher] Invalid handler parts: {handler_parts}")
                return self.handler.send_error(500, "Invalid handler format - expected &plugin.function")

            plugin_name, function_name = handler_parts
            if self.logger:
                self.logger.info(f"[RouteDispatcher] Loading plugin: {plugin_name}, function: {function_name}")

            # Get plugin from loader's plugin cache
            zos = self.router.zos
            if self.logger:
                self.logger.info(f"[RouteDispatcher] Got zos from router")

            if not hasattr(zos, 'loader') or not hasattr(zos.loader, 'cache'):
                if self.logger:
                    self.logger.error("[RouteDispatcher] Loader subsystem not available")
                return self.handler.send_error(500, "Loader subsystem not available")

            # Try to get plugin from cache
            if self.logger:
                self.logger.info(f"[RouteDispatcher] Loading plugin: {plugin_name}")

            plugin = zos.loader.get_python_module(plugin_name)

            if not plugin:
                # Plugin not in cache, try to load it
                # Plugins are relative to the current working directory
                plugin_path = os.path.join(os.getcwd(), 'plugins', f'{plugin_name}.py')

                if self.logger:
                    self.logger.info(f"[RouteDispatcher] Looking for plugin at: {plugin_path}")

                if not os.path.exists(plugin_path):
                    if self.logger:
                        self.logger.error(f"[RouteDispatcher] Plugin file not found: {plugin_path}")
                    return self.handler.send_error(500, f"Plugin '{plugin_name}' not found")

                try:
                    plugin = zos.loader.load_python_module(plugin_path, plugin_name)
                    if self.logger:
                        self.logger.info(f"[RouteDispatcher] Plugin loaded from file: {plugin_name}")
                except Exception as load_err:
                    if self.logger:
                        self.logger.error(f"[RouteDispatcher] Failed to load plugin: {load_err}", exc_info=True)
                    return self.handler.send_error(500, f"Failed to load plugin '{plugin_name}': {str(load_err)}")

            if not plugin:
                if self.logger:
                    self.logger.error(f"[RouteDispatcher] Plugin '{plugin_name}' returned None")
                return self.handler.send_error(500, f"Plugin '{plugin_name}' not found")

            if self.logger:
                self.logger.info(f"[RouteDispatcher] Plugin loaded successfully: {plugin_name}")

            # Get function from plugin
            if not hasattr(plugin, function_name):
                if self.logger:
                    self.logger.error(f"[RouteDispatcher] Function '{function_name}' not found in plugin '{plugin_name}'")
                return self.handler.send_error(500, f"Function '{function_name}' not found in plugin '{plugin_name}'")

            func = getattr(plugin, function_name)

            # Resolve schema (route-level 'model' overrides meta-level 'schema')
            schema_ref = route.get('model') or self.router.meta.get('schema')
            schema_context = None

            if schema_ref and schema_ref.startswith('@'):
                # Load schema from zData
                try:
                    # Schema reference format: @.zSchema.users
                    schema_name = schema_ref.split('.')[-1] if '.' in schema_ref else schema_ref[1:]

                    # Try to get loaded schema from zServer's schema cache
                    if hasattr(self.router, 'zos') and hasattr(self.router.zos, 'data'):
                        # Get schema metadata
                        schema_context = {
                            'schema_name': schema_name,
                            'schema_ref': schema_ref,
                            'table_name': schema_name  # By convention
                        }

                        if self.logger:
                            self.logger.debug(f"[RouteDispatcher] Resolved schema for route: {schema_ref}")
                except Exception as e:
                    if self.logger:
                        self.logger.warning(f"[RouteDispatcher] Failed to load schema {schema_ref}: {e}")

            # Build request context
            request_context = {
                'method': self.handler.command,
                'path': self.handler.path,
                'headers': dict(self.handler.headers),
                'route': route,
                'route_params': route.get('_route_params', {}),
                'schema': schema_context  # Inject schema context
            }

            # Read request body for POST/PUT
            if self.handler.command in ['POST', 'PUT', 'PATCH']:
                content_length = int(self.handler.headers.get('Content-Length', 0))
                if content_length > 0:
                    request_context['body'] = self.handler.rfile.read(content_length)
                    request_context['content_type'] = self.handler.headers.get('Content-Type', '')

            # Call function with zos + request context as kwargs
            # Plugin signature: def my_function(zos, **kwargs)
            if self.logger:
                self.logger.info(f"[RouteDispatcher] Calling {plugin_name}.{function_name} with context keys: {list(request_context.keys())}")
            result = func(zos, **request_context)

            # Handle response based on result type
            if isinstance(result, dict):
                # Check if binary response (Phase 3.2 - media delivery)
                if '_binary' in result:
                    # Binary response (images, files, etc.)
                    binary_data = result['_binary']
                    mimetype = result.get('_mimetype', 'application/octet-stream')
                    status_code = result.get('status_code', 200)

                    self.handler.send_response(status_code)
                    self.handler.send_header('Content-Type', mimetype)
                    self.handler.send_header('Content-Length', len(binary_data))
                    self.handler.end_headers()
                    self.handler.wfile.write(binary_data)
                else:
                    # JSON response
                    import json
                    body = json.dumps(result).encode('utf-8')
                    self.handler.send_response(result.get('status_code', 200))
                    self.handler.send_header('Content-Type', 'application/json')
                    self.handler.send_header('Content-Length', len(body))
                    self.handler.end_headers()
                    self.handler.wfile.write(body)
            elif isinstance(result, str):
                # Plain text response
                body = result.encode('utf-8')
                self.handler.send_response(200)
                self.handler.send_header('Content-Type', 'text/plain')
                self.handler.send_header('Content-Length', len(body))
                self.handler.end_headers()
                self.handler.wfile.write(body)
            elif isinstance(result, bytes):
                # Binary response
                self.handler.send_response(200)
                self.handler.send_header('Content-Type', 'application/octet-stream')
                self.handler.send_header('Content-Length', len(result))
                self.handler.end_headers()
                self.handler.wfile.write(result)
            else:
                # Assume success with no body
                self.handler.send_response(204)
                self.handler.end_headers()

        except Exception as e:
            if self.logger:
                self.logger.error(f"[RouteDispatcher] zFunc route error: {e}", exc_info=True)
            return self.handler.send_error(500, f"Function execution failed: {str(e)}")
