# zOS/core/L3_Abstraction/n_zBifrost/zBifrost_modules/nav_html_builder.py

"""
NavHTMLBuilder — server-side navbar HTML generation (Phase 3A).

Python owns the navbar structure. The client receives ready-to-inject HTML with
data-nav-* attributes; a small JS event delegator wires the interactions.

This removes NavigationRenderer.renderNavBar() as the source-of-truth for
the meta navbar and eliminates 150+ lines of client-side construction logic.
"""

import re
import uuid


def build_nav_html(
    items: list,
    brand: str = None,
    theme: str = 'light',
    css_class: str = 'zcli-navbar-meta',
) -> str:
    """
    Build Bootstrap-compatible navbar HTML from a RBAC-filtered items list.

    Args:
        items:     List of navbar items (strings or dicts with zSub/zRBAC).
        brand:     Brand text shown as the leftmost link (e.g. "zCloud").
        theme:     zTheme variant — 'light' or 'dark'.
        css_class: Extra CSS class on the <nav> element.

    Returns:
        HTML string ready for innerHTML injection.
    """
    collapse_id = f'navbar-collapse-{uuid.uuid4().hex[:9]}'

    parts = [
        f'<nav class="zNavbar zNavbar-{theme} {css_class}" role="navigation">'
    ]

    if brand:
        parts.append(f'<a href="/" class="zNavbar-brand">{_esc(brand)}</a>')

    parts.append(
        f'<button class="zNavbar-toggler"'
        f' data-nav-action="hamburger"'
        f' data-nav-target="{collapse_id}"'
        f' aria-controls="{collapse_id}"'
        f' aria-expanded="false"'
        f' aria-label="Toggle navigation">'
        f'<i class="bi bi-list" style="font-size:1.5rem;"></i>'
        f'</button>'
    )

    parts.append(f'<div class="zNavbar-collapse" id="{collapse_id}">')
    parts.append('<ul class="zNavbar-nav">')

    for item in items:
        parts.extend(_render_item(item))

    parts.append('</ul>')
    parts.append('</div>')
    parts.append('</nav>')

    return ''.join(parts)


# ─── helpers ──────────────────────────────────────────────────────────────────

def _render_item(item) -> list:
    """Render one navbar item (simple string or hierarchical dict)."""
    if isinstance(item, dict):
        # {itemName: {zSub: [...], ...}} — hierarchical dropdown
        item_name = next(iter(item))
        item_data = item[item_name] if isinstance(item[item_name], dict) else {}
        sub_items = item_data.get('zSub', [])

        if sub_items:
            return _render_dropdown(item_name, sub_items)

        # Dict without zSub — treat as plain link
        label = _strip(item_name)
        href = _to_href(item_name)
        return [_simple_li(label, href)]

    if isinstance(item, str):
        label = _strip(item)
        href = _to_href(item)
        return [_simple_li(label, href)]

    return []


def _render_dropdown(parent_name: str, sub_items: list) -> list:
    parent_label = _strip(parent_name)
    parent_href = _to_href(parent_name)

    parts = ['<li class="zNav-item zDropdown">']
    parts.append(
        f'<a href="{parent_href}" class="zNav-link zDropdown-toggle"'
        f' data-nav-action="dropdown-toggle"'
        f' aria-haspopup="true" aria-expanded="false">'
        f'{_esc(parent_label)}</a>'
    )
    parts.append('<div class="zDropdown-menu">')

    for sub in sub_items:
        if isinstance(sub, str):
            sub_label = _strip(sub)
            sub_href = f'{parent_href}/{sub}'
            parts.append(
                f'<a href="{sub_href}" class="zDropdown-item"'
                f' data-nav-action="navigate" data-nav-href="{sub_href}">'
                f'{_esc(sub_label)}</a>'
            )

    parts.append('</div>')
    parts.append('</li>')
    return parts


def _simple_li(label: str, href: str) -> str:
    return (
        f'<li class="zNav-item">'
        f'<a href="{href}" class="zNav-link"'
        f' data-nav-action="navigate" data-nav-href="{href}">'
        f'{_esc(label)}</a>'
        f'</li>'
    )


def _strip(item: str) -> str:
    """Remove zOS navigation modifiers ($, ^, ~) from the start of a string."""
    return re.sub(r'^[$^~]+', '', item)


def _to_href(item: str) -> str:
    clean = _strip(item)
    return f'/{clean}'


def _esc(text: str) -> str:
    return (
        text.replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
    )
