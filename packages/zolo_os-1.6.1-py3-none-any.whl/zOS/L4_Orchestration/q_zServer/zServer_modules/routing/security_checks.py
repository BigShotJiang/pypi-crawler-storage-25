# zOS/core/L4_Orchestration/r_zServer/zServer_modules/handler/security_checks.py

"""
Security Checks - Path validation and access control

Handles:
- Blocked path validation (models/, .zEnv, etc.)
- Directory traversal prevention
- Sensitive file access prevention
"""


class SecurityChecker:
    """Security validation for HTTP requests."""

    # Blocked paths (folders and files that should never be accessible via HTTP)
    BLOCKED_PATHS = [
        '/models/',      # Database schemas (may contain connection info)
        '/zConfigs/',    # Configuration files
        '/.zEnv',        # Environment variables (database credentials!)
        '/.env',         # Alternative env file naming
        '/.git/',        # Version control
        '/routes/',      # Server route definitions
        '/__pycache__/', # Python cache
        '/zCLI/',        # Framework internals (legacy zCLI name - kept for backward compatibility)
        '/zOS/',         # Framework internals
    ]

    @staticmethod
    def is_path_blocked(request_path: str) -> bool:
        """
        Check if request path is blocked for security reasons.
        
        Args:
            request_path: HTTP request path
        
        Returns:
            True if path is blocked, False if allowed
        """
        for blocked in SecurityChecker.BLOCKED_PATHS:
            # Only check startswith to avoid false positives (e.g., /zProducts/zOS/ should not be blocked)
            if request_path.startswith(blocked):
                return True
        return False

    @staticmethod
    def is_path_safe(file_path: str, allowed_root: str) -> bool:
        """
        Prevent directory traversal attacks.
        
        Args:
            file_path: Absolute file path to validate
            allowed_root: Allowed root directory
        
        Returns:
            True if path is safe (within allowed_root), False otherwise
        """
        import os
        file_path = os.path.abspath(file_path)
        allowed_root = os.path.abspath(allowed_root)
        return file_path.startswith(allowed_root)
