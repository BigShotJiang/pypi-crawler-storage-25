# zOS/core/L4_Orchestration/r_zServer/zServer_modules/handler.py

"""
Custom HTTP request handler with logging integration (Facade Pattern)

This module acts as a facade, delegating to specialized handler modules:
- SecurityChecker: Path validation and access control
- StaticFileHandler: Static file serving
- RouteDispatcher: Route matching and type-specific handling

The facade keeps the HTTP protocol integration while delegating business logic.
"""

from http.server import SimpleHTTPRequestHandler


class LoggingHTTPRequestHandler(SimpleHTTPRequestHandler):
    """HTTP request handler with zOS logger integration + routing (Facade Pattern)"""

    def __init__(self, *args, logger=None, router=None, mount_manager=None, cache_manager=None, **kwargs):
        """
        Initialize HTTP request handler.
        
        Args:
            logger: Logger instance
            router: HTTPRouter instance (optional)
            mount_manager: MountManager instance for file serving
            cache_manager: CacheManager instance for HTTP caching
        """
        self.logger = logger
        self.router = router
        self.mount_manager = mount_manager
        self.cache_manager = cache_manager
        
        # Backward compatibility properties (delegate to MountManager)
        self.serve_path = mount_manager.serve_path if mount_manager else "."
        self.static_mounts = mount_manager.get_all_mounts() if mount_manager else {}

        # Initialize modular handlers (lazy imports to avoid circular dependencies)
        from .security_checks import SecurityChecker
        from ..rendering.static_file_handler import StaticFileHandler
        from .route_dispatcher import RouteDispatcher
        self.security = SecurityChecker()
        self.static_handler = StaticFileHandler(self)
        self.route_dispatcher = RouteDispatcher(self) if router else None

        super().__init__(*args, **kwargs)

    # =========================================================================
    # HTTP Protocol Methods (Core)
    # =========================================================================

    def log_message(self, format, *args):
        """Override to use zOS logger instead of stderr"""
        if self.logger:
            self.logger.info(f"[zServer] {self.address_string()} - {format % args}")
        else:
            # Fallback to default behavior if no logger
            super().log_message(format, *args)

    def end_headers(self):
        """Add CORS headers for local development"""
        # Allow local development access
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        """Handle OPTIONS requests for CORS preflight"""
        self.send_response(200)
        self.end_headers()

    def list_directory(self, path):
        """Disable directory listing for security"""
        self.send_error(403, "Directory listing is disabled")
        return None

    def send_error(self, code, message=None, explain=None):
        """
        Override send_error to serve custom zTheme error pages.
        
        Looks for templates/{code}.html first, falls back to built-in pages.
        """
        try:
            # Try to serve custom error page from templates/
            import os
            template_folder = self.mount_manager.get_folder_path("templates")
            error_page_path = os.path.join(template_folder, f"{code}.html")

            if os.path.exists(error_page_path):
                # Serve custom error page
                with open(error_page_path, 'rb') as f:
                    content = f.read()

                self.send_response(code)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.send_header("Content-length", len(content))
                self.end_headers()
                self.wfile.write(content)
                return
        except Exception as e:
            if self.logger:
                self.logger.error(f"[Handler] Error serving custom error page: {e}")

        # Fallback to built-in error pages
        from ..rendering.error_pages import get_error_page, has_error_page

        if has_error_page(code):
            html = get_error_page(code, message)
            content = html.encode('utf-8')

            self.send_response(code)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.send_header("Content-length", len(content))
            self.end_headers()
            self.wfile.write(content)
        else:
            # Ultimate fallback to Python's default
            super().send_error(code, message, explain)

    def do_GET(self):
        """
        Handle GET requests with Flask-like conventions (v1.5.12 - SECURITY ENHANCED).
        
        Flow:
            0. SECURITY: Block access to sensitive paths (models/, .zEnv, etc.)
            1. Check for favicon.ico and serve default if not found
            2. Check for /static/* and auto-serve from static_folder
            3. Check for /UI/* and auto-serve from ui_folder (zVaF files)
            4. If router exists: Use declarative routing
            5. Otherwise: Fallback to static file serving (current behavior)
        """
        # SECURITY v1.5.12: Block access to sensitive folders and files
        if self.security.is_path_blocked(self.path):
            if self.logger:
                self.logger.warning(f"[SECURITY] Blocked access attempt to: {self.path}")
            self.send_error(403, "Access Forbidden")
            return

        # Handle favicon.ico with default zolo favicon
        if self.path == '/favicon.ico':
            return self.static_handler.serve_default_favicon()

        # Check all mounts (unified handling via MountManager)
        mount_info = self.mount_manager.get_mount_for_path(self.path)
        if mount_info:
            url_prefix, fs_path = mount_info
            # Determine mount type for specialized handling
            if url_prefix == '/UI/':
                # Case-insensitive UI file serving
                return self.static_handler.serve_ui_file()
            elif url_prefix == '/static/':
                return self.static_handler.serve_static_file()
            else:
                # Custom mount (plugins, etc.)
                return self.static_handler.serve_mounted_file(url_prefix, fs_path)

        # Check if router exists (declarative routing mode)
        if self.router:
            return self.route_dispatcher.handle_routed_request()

        # No router - fallback to static file serving
        if self.logger:
            self.logger.warning(f"[Handler] No router - falling back to static file serving for: {self.path}")
        return super().do_GET()

    def do_POST(self):
        """
        Handle POST requests for forms and APIs (v1.5.7 Phase 1.2).
        
        Flow:
            1. If router exists: Use declarative routing
            2. Otherwise: Return 405 Method Not Allowed
        """
        # Check if router exists (declarative routing mode)
        if self.router:
            return self.route_dispatcher.handle_routed_request()

        # No router - POST not supported
        return self.send_error(405, "POST not supported without routing")
