# zOS/core/L4_Orchestration/r_zServer/zServer_modules/handler/static_file_handler.py

"""
Static File Handler - File serving operations

Handles:
- Default favicon serving
- /static/* files (Flask convention)
- Custom mount points (/bifrost/, /plugins/, etc.)
- /UI/* files (zVaF files)
"""

from zOS import os
import mimetypes
from urllib.parse import unquote

# Import HTTP cache utilities
from ..utils import http_cache_utils


class StaticFileHandler:
    """Static file serving for HTTP requests."""

    def __init__(self, handler):
        """
        Initialize static file handler.
        
        Args:
            handler: Parent HTTP request handler instance
        """
        self.handler = handler
        self.logger = getattr(handler, 'logger', None)

    def serve_default_favicon(self):
        """Serve default zolo favicon from zServer static folder."""
        # Path to default favicon in zServer static folder
        zserver_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        favicon_path = os.path.join(zserver_dir, 'static', 'favicon.ico')

        if not os.path.exists(favicon_path):
            # No default favicon, return 404
            return self.handler.send_error(404, "Favicon not found")

        try:
            # Check cache and serve 304 if valid
            should_serve, sent = self.handler.cache_manager.check_and_serve_cached(
                self.handler, favicon_path, "favicon"
            )
            if sent:
                return  # 304 already sent
            
            # Serve full response
            with open(favicon_path, 'rb') as f:
                favicon_data = f.read()

            mtime = os.path.getmtime(favicon_path)
            
            self.handler.send_response(200)
            self.handler.send_header("Content-type", "image/x-icon")
            self.handler.send_header("Content-length", len(favicon_data))
            self.handler.cache_manager.add_cache_headers(self.handler, favicon_path, "favicon", mtime=mtime)
            self.handler.end_headers()
            self.handler.wfile.write(favicon_data)

        except Exception as e:
            if self.logger:
                self.logger.error(f"[StaticFileHandler] Error serving favicon: {e}")
            return self.handler.send_error(500, f"Error serving favicon: {str(e)}")

    def serve_static_file(self):
        """
        Auto-serve files from /static/* (Flask convention).
        
        Maps /static/js/hello.js → {serve_path}/static/js/hello.js
        """
        # Remove /static/ prefix to get relative path
        relative_path = self.handler.path[8:]  # Remove '/static/'

        # Decode URL encoding (e.g., %20 → space)
        relative_path = unquote(relative_path)

        # Build absolute path using MountManager
        static_folder_path = self.handler.mount_manager.get_folder_path("static")
        file_path = os.path.join(static_folder_path, relative_path)

        # Security: Prevent directory traversal
        file_path = os.path.abspath(file_path)
        static_root = os.path.abspath(static_folder_path)

        if not file_path.startswith(static_root):
            return self.handler.send_error(403, "Access denied")

        # Check if file exists
        if not os.path.exists(file_path):
            return self.handler.send_error(404, f"File not found: {self.handler.path}")

        # Check if it's a directory (not allowed)
        if os.path.isdir(file_path):
            return self.handler.send_error(403, "Directory listing is disabled")

        # Serve the file
        try:
            # Check cache and serve 304 if valid
            should_serve, sent = self.handler.cache_manager.check_and_serve_cached(
                self.handler, file_path, "static"
            )
            if sent:
                return  # 304 already sent
            
            # Serve full response
            with open(file_path, 'rb') as f:
                content = f.read()

            mtime = os.path.getmtime(file_path)
            
            # Determine content type
            content_type, _ = mimetypes.guess_type(file_path)
            if not content_type:
                content_type = 'application/octet-stream'

            self.handler.send_response(200)
            self.handler.send_header("Content-type", content_type)
            self.handler.send_header("Content-length", len(content))
            self.handler.cache_manager.add_cache_headers(self.handler, file_path, "static", mtime=mtime)
            self.handler.end_headers()
            self.handler.wfile.write(content)

            if self.logger:
                self.logger.debug(f"[StaticFileHandler] Served static file: {self.handler.path}")

        except Exception as e:
            if self.logger:
                self.logger.error(f"[StaticFileHandler] Error serving static file: {e}")
            return self.handler.send_error(500, f"Error serving file: {str(e)}")

    def serve_mounted_file(self, url_prefix: str, fs_root: str):
        """
        Serve file from a custom mount point.
        
        Generic mount handler that serves files from any configured filesystem location.
        Each mount has its own security boundary (directory traversal protection).
        
        Args:
            url_prefix: URL prefix (e.g., "/bifrost/", "/shared/")
            fs_root: Filesystem root path (absolute)
        
        Example:
            url_prefix="/bifrost/", fs_root="/Users/gal/bifrost/"
            Request: /bifrost/src/client.js
            Serves: /Users/gal/bifrost/src/client.js
        
        Security:
            - Directory traversal protection per mount
            - No directory listing
            - Validates file exists and is readable
        """
        # Remove URL prefix to get relative path within mount
        relative_path = self.handler.path[len(url_prefix):]

        # Decode URL encoding (e.g., %20 → space)
        relative_path = unquote(relative_path)

        # Build absolute path within mount
        file_path = os.path.join(fs_root, relative_path)

        # Security: Prevent directory traversal attacks
        file_path = os.path.abspath(file_path)
        mount_root = os.path.abspath(fs_root)

        if not file_path.startswith(mount_root):
            if self.logger:
                self.logger.warning(f"[StaticFileHandler] Directory traversal attempt blocked: {self.handler.path}")
            return self.handler.send_error(403, "Access denied")

        # Check if file exists
        if not os.path.exists(file_path):
            return self.handler.send_error(404, f"File not found: {self.handler.path}")

        # Check if it's a directory (not allowed)
        if os.path.isdir(file_path):
            return self.handler.send_error(403, "Directory listing is disabled")

        # Serve the file
        try:
            # Get file modification time for ETag
            mtime = os.path.getmtime(file_path)
            etag = http_cache_utils.generate_etag(mtime=mtime)
            
            # Get deployment environment for Cache-Control
            environment = "Development"
            if hasattr(self.handler, 'router') and hasattr(self.handler.router, 'zos'):
                zos = self.handler.router.zos
                if hasattr(zos, 'config'):
                    environment = zos.config.get_environment("deployment", "Development")
            
            # Check cache and serve 304 if valid
            should_serve, sent = self.handler.cache_manager.check_and_serve_cached(
                self.handler, file_path, "static"
            )
            if sent:
                return  # 304 already sent
            
            # Serve full response
            with open(file_path, 'rb') as f:
                content = f.read()

            mtime = os.path.getmtime(file_path)
            
            # Guess MIME type
            content_type, _ = mimetypes.guess_type(file_path)
            if not content_type:
                content_type = 'application/octet-stream'

            # Send response
            self.handler.send_response(200)
            self.handler.send_header("Content-type", content_type)
            self.handler.send_header("Content-length", len(content))
            self.handler.cache_manager.add_cache_headers(self.handler, file_path, "static", mtime=mtime)
            self.handler.end_headers()
            self.handler.wfile.write(content)

            if self.logger:
                self.logger.debug(f"[StaticFileHandler] Served from mount {url_prefix}: {self.handler.path}")

        except Exception as e:
            if self.logger:
                self.logger.error(f"[StaticFileHandler] Error serving mounted file {self.handler.path}: {e}")
            return self.handler.send_error(500, f"Error serving file: {str(e)}")

    def serve_ui_file(self):
        """
        Auto-serve zVaFiles from /UI/* (zUI convention).
        
        Maps /UI/zUI.index.zolo → {serve_path}/UI/zUI.index.zolo
        Supports .zolo, .yaml, .json formats.
        """
        # Remove /UI/ prefix to get relative path (case-insensitive match)
        ui_folder_name = self.handler.mount_manager.get_folder_name("UI")
        ui_prefix = f'/{ui_folder_name}/'
        ui_prefix_len = len(ui_prefix)

        # Handle both exact case and lowercase URLs
        if self.handler.path.startswith(ui_prefix):
            relative_path = self.handler.path[ui_prefix_len:]
        else:
            # Case-insensitive fallback
            relative_path = self.handler.path[ui_prefix_len:]

        # Decode URL encoding (e.g., %20 → space)
        relative_path = unquote(relative_path)

        # Build absolute path using MountManager
        ui_folder_path = self.handler.mount_manager.get_folder_path("UI")
        file_path = os.path.join(ui_folder_path, relative_path)

        # Security: Prevent directory traversal
        file_path = os.path.abspath(file_path)
        ui_root = os.path.abspath(ui_folder_path)

        if not file_path.startswith(ui_root):
            return self.handler.send_error(403, "Access denied")

        # Check if file exists
        if not os.path.exists(file_path):
            return self.handler.send_error(404, f"UI file not found: {self.handler.path}")

        # Check if it's a directory (not allowed)
        if os.path.isdir(file_path):
            return self.handler.send_error(403, "Directory listing is disabled")

        # Serve the zVaFile
        try:
            # Check cache and serve 304 if valid
            should_serve, sent = self.handler.cache_manager.check_and_serve_cached(
                self.handler, file_path, "ui"
            )
            if sent:
                return  # 304 already sent
            
            # Serve full response
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            mtime = os.path.getmtime(file_path)
            content_bytes = content.encode('utf-8')
            
            # Determine content type based on extension
            if file_path.endswith('.json'):
                content_type = 'application/json'
            elif file_path.endswith('.zolo'):
                content_type = 'application/x-yaml'  # .zolo uses YAML syntax
            else:
                content_type = 'application/x-yaml'  # Legacy .yaml files

            self.handler.send_response(200)
            self.handler.send_header("Content-type", content_type)
            self.handler.send_header("Content-length", len(content_bytes))
            self.handler.cache_manager.add_cache_headers(self.handler, file_path, "ui", mtime=mtime)
            self.handler.end_headers()
            self.handler.wfile.write(content_bytes)

            if self.logger:
                self.logger.debug(f"[StaticFileHandler] Served UI file: {self.handler.path}")

        except Exception as e:
            if self.logger:
                self.logger.error(f"[StaticFileHandler] Error serving UI file: {e}")
            return self.handler.send_error(500, f"Error serving UI file: {str(e)}")
