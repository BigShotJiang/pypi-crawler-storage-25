# zOS/core/L4_Orchestration/r_zServer/zServer_modules/mount_manager.py

"""
MountManager - Unified mount management for zServer

Handles ALL file serving mounts (default and custom):
- Default mounts: /static/, /templates/, /UI/
- Custom mounts: /plugins/, user-defined mounts
- Single source of truth for URL → filesystem path mapping

Note: Bifrost client mounting removed - use manual ZSERVER_MOUNTS in zEnv
      for Development, or CDN for Production.
"""

from zOS import os, Path, Dict, Optional, Tuple

from ..utils.zserver_constants import (
    MOUNT_PLUGINS,
    FOLDER_PLUGINS,
    FOLDER_STATIC,
    FOLDER_TEMPLATES,
    FOLDER_UI
)


class MountManager:
    """
    Manages all file serving mounts for zServer (SSOT for mount logic).
    
    Consolidates default mounts (static, templates, UI) and custom mounts
    into a unified registry with consistent query interface.
    """

    def __init__(self, serve_path, static_mounts, logger):
        """
        Initialize MountManager with default and custom mounts.
        
        Args:
            serve_path: Directory being served
            static_mounts: Initial custom mounts dict from config
            logger: zOS logger instance
        """
        self.serve_path = serve_path
        self.logger = logger
        
        # Initialize unified mount registry with default mounts
        self.mounts = {}
        
        # Add default mounts (URL prefix → filesystem path)
        self._add_default_mount("/static/", FOLDER_STATIC)
        self._add_default_mount("/templates/", FOLDER_TEMPLATES)
        self._add_default_mount("/UI/", FOLDER_UI)
        
        # Merge custom mounts from config
        if static_mounts:
            for url_prefix, fs_path in static_mounts.items():
                self.mounts[url_prefix] = fs_path
                self.logger.debug(f"[MountManager] Custom mount: {url_prefix} → {fs_path}")
    
    def _add_default_mount(self, url_prefix: str, folder_name: str):
        """
        Add a default mount (relative to serve_path).
        
        Args:
            url_prefix: URL prefix (e.g., "/static/")
            folder_name: Folder name relative to serve_path (e.g., "static")
        """
        fs_path = os.path.join(self.serve_path, folder_name)
        self.mounts[url_prefix] = fs_path
        self.logger.debug(f"[MountManager] Default mount: {url_prefix} → {fs_path}")

    def auto_mount_plugins(self):
        """
        Auto-mount plugins folder for JavaScript plugin access.
        
        This enables _zScripts metadata to reference plugins via /plugins/plugin_name.js
        
        Tries common locations:
        - {serve_path}/plugins
        - zCloud/plugins
        - {cwd}/plugins
        """
        if MOUNT_PLUGINS in self.mounts:
            return  # Already mounted

        # Try common locations: {serve_path}/plugins, zCloud/plugins, {cwd}/plugins
        potential_plugin_paths = [
            os.path.join(self.serve_path, FOLDER_PLUGINS),
            os.path.join(str(Path.cwd()), "zCloud", FOLDER_PLUGINS),
            os.path.join(str(Path.cwd()), FOLDER_PLUGINS)
        ]

        for plugin_path in potential_plugin_paths:
            if os.path.isdir(plugin_path):
                self.mounts[MOUNT_PLUGINS] = plugin_path
                self.logger.info(f"[MountManager] Auto-mounted plugins: {MOUNT_PLUGINS} → {plugin_path}")
                break

    def get_mount_for_path(self, url_path: str) -> Optional[Tuple[str, str]]:
        """
        Get mount information for a URL path.
        
        Args:
            url_path: URL path to check (e.g., "/static/style.css")
        
        Returns:
            Tuple of (url_prefix, fs_path) if mounted, None otherwise
            Example: ("/static/", "/path/to/serve/static")
        """
        for url_prefix, fs_path in self.mounts.items():
            if url_path.startswith(url_prefix):
                return (url_prefix, fs_path)
        return None
    
    def get_folder_path(self, mount_type: str) -> str:
        """
        Get filesystem path for a mount type (for template rendering, etc.).
        
        Args:
            mount_type: Mount type ("static", "templates", "UI")
        
        Returns:
            str: Full filesystem path
        
        Raises:
            KeyError: If mount type not found
        """
        url_prefix = f"/{mount_type}/"
        if url_prefix in self.mounts:
            return self.mounts[url_prefix]
        raise KeyError(f"Mount type '{mount_type}' not found in registry")
    
    def get_folder_name(self, mount_type: str) -> str:
        """
        Get folder name for a mount type (for backward compatibility).
        
        Args:
            mount_type: Mount type ("static", "templates", "UI")
        
        Returns:
            str: Folder name (e.g., "static", "templates", "UI")
        """
        # Map mount types to folder names
        folder_map = {
            "static": FOLDER_STATIC,
            "templates": FOLDER_TEMPLATES,
            "UI": FOLDER_UI
        }
        return folder_map.get(mount_type, mount_type)
    
    def get_all_mounts(self) -> Dict[str, str]:
        """
        Get complete mount registry.
        
        Returns:
            dict: Complete mounts mapping (URL prefix -> filesystem path)
        """
        return self.mounts.copy()
    
    def get_static_mounts(self) -> dict:
        """
        Get static mounts registry (backward compatibility).
        
        Returns:
            dict: Static mounts mapping (URL prefix -> filesystem path)
        """
        return self.mounts
