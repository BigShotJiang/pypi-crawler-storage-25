# zOS/core/L4_Orchestration/r_zServer/zServer_modules/route_manager.py

"""
RouteManager - Route detection and loading for zServer

Handles:
- Auto-detection of zServer route files (.zolo, .yaml, .json)
- Route loading and merging (blueprint pattern)
- Router initialization
"""

from zOS import os
import glob

from ..utils.zserver_constants import PATTERN_ROUTE_FILES, FOLDER_ROUTES


class RouteManager:
    """
    Manages route detection, loading, and router initialization.
    
    Supports Flask-style blueprints: multiple route files are merged
    into a single router. Auto-detects zServer route files (zVaFiles) 
    in serve_path and routes/ subfolder.
    """

    def __init__(self, serve_path, zos, logger):
        """
        Initialize RouteManager.
        
        Args:
            serve_path: Directory to serve files from
            zos: zOS instance (for auth, data integration)
            logger: zOS logger instance
        """
        self.serve_path = serve_path
        self.zos = zos
        self.logger = logger
        self.router = None
        self.routes_files = []

    def auto_detect_routes_files(self):
        """
        Auto-detect ALL zServer routing files in serve_path.
        
        Scans BOTH root folder AND routes/ subfolder for zServer route files,
        following Flask blueprint-style modular routing.
        
        Convention:
            - Root folder: Primary routes (e.g., zServer.routes.zolo)
            - routes/ folder: Modular blueprints (e.g., zServer.api.zolo, zServer.themes.yaml)
        
        Returns:
            list: List of detected routes files (paths relative to serve_path)
        """
        found_files = []

        try:
            # 1. Look for zServer route files in ROOT folder (.zolo, .yaml, .json)
            for pattern in PATTERN_ROUTE_FILES:
                root_pattern = os.path.join(self.serve_path, pattern)
                root_matches = glob.glob(root_pattern)

                for match in root_matches:
                    # Store relative path from serve_path
                    rel_path = os.path.basename(match)
                    if rel_path not in found_files:  # Avoid duplicates
                        found_files.append(rel_path)
                        self.logger.framework.debug(f"[zServer] Found routes file (root): {rel_path}")

            # 2. Look for zServer route files in ROUTES/ subfolder (.zolo, .yaml, .json)
            routes_dir = os.path.join(self.serve_path, FOLDER_ROUTES)
            if os.path.isdir(routes_dir):
                for pattern in PATTERN_ROUTE_FILES:
                    routes_pattern = os.path.join(routes_dir, pattern)
                    routes_matches = glob.glob(routes_pattern)

                    for match in routes_matches:
                        # Store relative path from serve_path (includes "routes/" prefix)
                        rel_path = os.path.relpath(match, self.serve_path)
                        if rel_path not in found_files:  # Avoid duplicates
                            found_files.append(rel_path)
                            self.logger.framework.debug(f"[zServer] Found routes file (routes/): {rel_path}")

            if found_files:
                self.logger.info(f"[zServer] Detected {len(found_files)} route files")
                self.logger.debug(f"[zServer] Route files: {found_files}")
            else:
                self.logger.framework.debug("[zServer] No zServer route files found - static serving only")

            self.routes_files = found_files
            return found_files

        except Exception as e:
            self.logger.framework.debug(f"[zServer] Auto-detection failed: {e}")
            self.routes_files = []
            return []

    def load_and_merge_routes(self, routes_files):
        """
        Load routing configuration from zServer route files (zVaFiles).
        
        Supports Flask-style blueprints: multiple route files are merged into a single router.
        Last-loaded file wins for conflicting routes.
        
        Uses zLoader's handle_absolute_path() to maintain SSOT/DRY principles.
        zLoader delegates to zParser for format detection (.zolo/.yaml/.json) and parsing.
        
        Args:
            routes_files: List of route file paths (relative to serve_path)
        """
        if not routes_files or len(routes_files) == 0:
            self.logger.framework.debug("[zServer] No routes files to load - static serving only")
            return

        try:
            # Log start of route loading (INFO level summary)
            self.logger.info(f"[zServer] Loading routes from {len(routes_files)} files...")
            
            # Merged routes structure (blueprint pattern)
            merged_data = {
                "type": "server",
                "meta": {},
                "routes": {}
            }

            # Load and merge all route files
            for routes_file in routes_files:
                try:
                    # Build full path (routes_file is relative to serve_path)
                    full_path = os.path.join(self.serve_path, routes_file)
                    
                    # Log individual file loading at DEBUG level
                    self.logger.debug(f"[zServer] Loading: {routes_file}")

                    # Use zLoader's absolute path method (maintains SSOT)
                    # zLoader delegates to zParser for format detection and parsing
                    routes_data = self.zos.loader.handle_absolute_path(full_path)

                    if routes_data and routes_data.get("type") == "server":
                        # Merge meta (later files override earlier files)
                        if "meta" in routes_data:
                            merged_data["meta"].update(routes_data["meta"])

                        # Merge routes (later files override earlier files)
                        if "routes" in routes_data:
                            route_count = len(routes_data["routes"])
                            merged_data["routes"].update(routes_data["routes"])
                            self.logger.debug(f"[zServer] Loaded {route_count} routes from: {routes_file}")
                    else:
                        self.logger.warning(f"[zServer] Invalid routes file: {routes_file}")

                except Exception as e:
                    self.logger.error(f"[zServer] Failed to load routes from {routes_file}: {e}")
                    # Continue loading other files

            # Create router with merged routes
            total_routes = len(merged_data["routes"])
            if total_routes > 0:
                from ..routing.router import HTTPRouter
                self.router = HTTPRouter(merged_data, self.zos, self.logger, serve_path=self.serve_path)
                # Log final summary at INFO level
                self.logger.info(f"[zServer] Loaded {total_routes} routes from {len(routes_files)} files")
            else:
                self.logger.warning("[zServer] No valid routes found - static serving only")

        except Exception as e:
            self.logger.error(f"[zServer] Failed to load routes: {e}")
            # Continue without router (fallback to static serving)

    def get_router(self):
        """
        Get the initialized HTTPRouter instance.
        
        Returns:
            HTTPRouter or None: The router instance if routes were loaded
        """
        return self.router
