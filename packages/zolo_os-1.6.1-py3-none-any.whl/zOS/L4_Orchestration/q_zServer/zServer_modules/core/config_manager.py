# zOS/core/L4_Orchestration/r_zServer/zServer_modules/config_manager.py

"""
ConfigManager - Server configuration management for zServer

Handles:
- Configuration extraction from HttpServerConfig
- Path resolution (serve_path)
- Deployment mode detection
- SSL configuration

Note: Mount management (static, templates, UI folders) moved to MountManager.
"""

from zOS import Path

from ..utils.zserver_constants import MODE_DEVELOPMENT


class ConfigManager:
    """
    Manages zServer configuration (server settings only).
    
    Extracts and validates configuration from HttpServerConfig object.
    Mount management delegated to MountManager for SSOT.
    """

    def __init__(self, config, zos, logger):
        """
        Initialize ConfigManager.
        
        Args:
            config: HttpServerConfig instance from zConfig
            zos: zOS instance (for deployment mode detection)
            logger: zOS logger instance
        """
        self.config = config
        self.zos = zos
        self.logger = logger

        # Extract configuration from config object
        self.enabled = config.enabled
        self.port = config.port
        self.host = config.host
        self.routes_file = config.routes_file

        # SSL Configuration
        self.ssl_enabled = config.ssl_enabled
        self.ssl_cert = config.ssl_cert
        self.ssl_key = config.ssl_key

        # Static Mounts (passed to MountManager)
        self.static_mounts = config.static_mounts.copy() if config.static_mounts else {}

        # Resolve serve_path
        self.serve_path = self._resolve_serve_path(config.serve_path)

    def _resolve_serve_path(self, serve_path):
        """
        Resolve serve_path to absolute path.
        
        Handles cases where path may not exist yet or cwd deleted.
        
        Args:
            serve_path: Path to serve files from
            
        Returns:
            str: Resolved absolute path
        """
        if not serve_path:
            return str(Path.cwd())

        try:
            return str(Path(serve_path).resolve())
        except (FileNotFoundError, OSError):
            # Path doesn't exist or cwd deleted - use path as-is
            return str(Path(serve_path))

    def get_deployment_mode(self) -> str:
        """
        Get deployment mode from zOS config.
        
        Returns:
            str: Deployment mode ("Development", "Testing", or "Production")
        """
        if not self.zos or not hasattr(self.zos, 'config'):
            return MODE_DEVELOPMENT
        return self.zos.config.get_environment("deployment", MODE_DEVELOPMENT)
