# zOS/core/L4_Orchestration/r_zServer/zServer_modules/lifecycle_manager.py

"""
LifecycleManager - Server lifecycle orchestration

Handles:
- Deployment mode routing (Development vs Production)
- Server start/stop coordination
- WSGI module generation for Gunicorn
- Wait/blocking behavior
"""

from zOS import os, json, time

from ..utils.zserver_constants import (
    MODE_PRODUCTION,
    WSGI_TEMP_MODULE,
    WSGI_TEMP_COMPILED
)


class LifecycleManager:
    """
    Orchestrates server lifecycle across deployment modes.
    
    Routes to DevServerManager (Development/Testing) or GunicornManager (Production)
    based on deployment configuration. Handles WSGI module generation for Production.
    """

    def __init__(self, config_manager, route_manager, dev_manager, mount_manager, cache_manager, logger):
        """
        Initialize LifecycleManager.
        
        Args:
            config_manager: ConfigManager instance
            route_manager: RouteManager instance (for WSGI generation)
            dev_manager: DevServerManager instance
            mount_manager: MountManager instance
            cache_manager: CacheManager instance
            logger: zOS logger instance
        """
        self.config = config_manager
        self.route_manager = route_manager
        self.dev_manager = dev_manager
        self.mount_manager = mount_manager
        self.cache_manager = cache_manager
        self.logger = logger
        self.gunicorn_manager = None

    def start(self):
        """
        Start HTTP server (deployment-aware).
        
        Behavior based on deployment mode:
        - "Development"/"Testing" → http.server (background thread)
        - "Production" → Gunicorn (subprocess)
        
        Raises:
            RuntimeError: If server is already running
            OSError: If port is already in use or Gunicorn not installed
        """
        if self.is_running():
            self.logger.warning("[zServer] Server is already running")
            return

        # Check deployment mode and route to correct server type
        deployment = self.config.get_deployment_mode().lower()

        if deployment == MODE_PRODUCTION.lower():
            self._start_production()
        else:
            self.dev_manager.start()

    def _start_production(self):
        """
        Start Gunicorn subprocess (Production mode).
        
        Creates a WSGI module and starts Gunicorn to serve it.
        """
        from .gunicorn_manager import GunicornManager

        # Create temporary WSGI module for Gunicorn
        self._create_wsgi_module()

        # Start Gunicorn
        self.gunicorn_manager = GunicornManager(
            app_module="_zserver_wsgi_temp:app",
            host=self.config.host,
            port=self.config.port,
            workers=4,
            logger=self.logger
        )

        try:
            self.gunicorn_manager.start()
        except Exception as e:
            self.logger.error(f"[zServer] Failed to start Gunicorn: {e}")
            self.gunicorn_manager = None
            raise

    def stop(self):
        """
        Stop HTTP server (works in all modes).
        
        Delegates to appropriate manager based on deployment mode.
        """
        deployment = self.config.get_deployment_mode().lower()

        if deployment == MODE_PRODUCTION.lower():
            # Stop Gunicorn
            if self.gunicorn_manager:
                self.gunicorn_manager.stop()
                self.gunicorn_manager = None

            # Clean up WSGI module
            try:
                if os.path.exists(WSGI_TEMP_MODULE):
                    os.remove(WSGI_TEMP_MODULE)
                if os.path.exists(WSGI_TEMP_COMPILED):
                    os.remove(WSGI_TEMP_COMPILED)
            except Exception as e:
                self.logger.warning(f"[zServer] Could not remove WSGI temp file: {e}")

            self.logger.info("[zServer] Production server stopped")
        else:
            # Stop http.server
            self.dev_manager.stop()

    def wait(self):
        """
        Block until server is interrupted.
        
        Keeps the process alive while the server runs. Signal handlers (SIGINT/SIGTERM)
        registered by zOS will automatically call shutdown, which stops the server.
        
        This eliminates boilerplate try/except/KeyboardInterrupt blocks in applications.
        
        Note:
            - Signal handlers (Ctrl+C, SIGTERM) already registered by zOS
            - zOS.shutdown() automatically calls server.stop()
            - This method just keeps the process alive
        """
        if not self.is_running():
            self.logger.debug("[zServer] Server is not running, nothing to wait for")
            return

        try:
            while self.is_running():
                time.sleep(1)
        except KeyboardInterrupt:
            # Signal handler will call shutdown, which calls stop()
            # Just exit gracefully
            pass

    def is_running(self) -> bool:
        """
        Check if server is running (works in all modes).
        
        Returns:
            bool: True if server is running
        """
        if self.gunicorn_manager:
            return self.gunicorn_manager.is_running()
        return self.dev_manager.is_running()

    def _create_wsgi_module(self):
        """
        Create temporary WSGI module for Gunicorn to import.
        
        Generates a self-contained Python file that Gunicorn workers can import
        and use to create the WSGI app with proper routing and configuration.
        """
        # Serialize configuration for the WSGI module
        config = {
            'serve_path': self.config.serve_path,
            'mounts': self.mount_manager.get_all_mounts(),
            'routes_files': self.route_manager.routes_files,
            'cache_policies': self.cache_manager.policies,
        }

        wsgi_content = f'''# Auto-generated WSGI module for zServer Production mode
# DO NOT EDIT - Generated by zOS

import sys
import os

# Configuration from zServer
CONFIG = {json.dumps(config, indent=4)}

# Set working directory to serve_path
serve_path = CONFIG['serve_path']
if os.path.exists(serve_path):
    os.chdir(serve_path)

# Create WSGI app using zServer's WSGI adapter
from zOS.L4_Orchestration.q_zServer.zServer_modules.wsgi_app import zServerWSGIApp

# Create a minimal zServer-like object with the configuration
class WSGIServerConfig:
    def __init__(self, config):
        self.serve_path = config['serve_path']
        self.routes_files = config.get('routes_files', [])
        self.router = None
        self.logger = None
        
        # Create MountManager from serialized mounts
        from zOS.L4_Orchestration.q_zServer.zServer_modules.mount_manager import MountManager
        
        # Reconstruct mount_manager (mounts already include defaults + custom)
        class SimpleMountManager:
            def __init__(self, serve_path, mounts):
                self.serve_path = serve_path
                self.mounts = mounts
            
            def get_folder_path(self, mount_type):
                url_prefix = "/" + mount_type + "/"
                if url_prefix in self.mounts:
                    return self.mounts[url_prefix]
                raise KeyError("Mount type '" + mount_type + "' not found")
            
            def get_all_mounts(self):
                return self.mounts.copy()
        
        self.mount_manager = SimpleMountManager(self.serve_path, config.get('mounts', {{}}))
        
        # Create CacheManager from serialized policies
        from zOS.L4_Orchestration.q_zServer.zServer_modules.cache_manager import CacheManager
        
        # Reconstruct cache_manager with policies
        class SimpleCacheManager:
            def __init__(self, policies):
                self.policies = policies
                
            def get_deployment_mode(self):
                return "Production"  # WSGI always runs in Production
        
        # Create minimal config manager for CacheManager
        class SimpleConfigManager:
            def get_deployment_mode(self):
                return "Production"
        
        from zSys.logger import ConsoleLogger
        simple_logger = ConsoleLogger()
        self.cache_manager = CacheManager(SimpleConfigManager(), simple_logger)
        self.cache_manager.policies = config.get('cache_policies', CacheManager.DEFAULT_POLICIES)
        
        # Load routes if any routes_files are provided
        if self.routes_files:
            self._load_routes()
    
    def _load_routes(self):
        """Load and merge routes from route files (blueprint pattern)."""
        try:
            from zOS.L4_Orchestration.q_zServer.zServer_modules.routing.router import HTTPRouter
            from zSys.logger import ConsoleLogger
            from zOS.L2_Handling.d_zParser.parser_modules import parse_file_content, identify_zFile
            from zOS.L1_Foundation.c_zLoader.loader_modules import load_file_raw
            
            # Create minimal logger for WSGI
            self.logger = ConsoleLogger()
            
            # Merged routes structure (blueprint pattern)
            merged_data = {{
                "type": "server",
                "meta": {{}},
                "routes": {{}}
            }}

            # Load and merge all route files
            for routes_file in self.routes_files:
                try:
                    # Build full path (routes_file is relative to serve_path)
                    full_path = os.path.join(self.serve_path, routes_file)

                    # Use zParser for format detection and parsing (maintains SSOT)
                    # Detect extension (.zolo/.yaml/.json)
                    filename = os.path.basename(full_path)
                    base_path = os.path.splitext(full_path)[0] if os.path.splitext(full_path)[1] else full_path
                    file_path, extension = identify_zFile(filename, base_path, self.logger)
                    
                    # Load and parse with detected format
                    raw_content = load_file_raw(file_path, self.logger)
                    routes_data = parse_file_content(raw_content, self.logger, extension, file_path)

                    if routes_data and routes_data.get("type") == "server":
                        # Merge meta (later files override earlier files)
                        if "meta" in routes_data:
                            merged_data["meta"].update(routes_data["meta"])

                        # Merge routes (later files override earlier files)
                        if "routes" in routes_data:
                            merged_data["routes"].update(routes_data["routes"])
                            print(f"[WSGI] Loaded routes from: {{routes_file}}")
                except Exception as e:
                    print(f"[WSGI] Failed to load routes from {{routes_file}}: {{e}}")
            
            # Create router with merged routes (zos=None since we don't need auth in this minimal setup)
            if merged_data["routes"]:
                self.router = HTTPRouter(merged_data, zos=None, logger=self.logger)
                print(f"[WSGI] Router initialized with {{len(merged_data['routes'])}} total routes")
            
        except Exception as e:
            print(f"[WSGI] Failed to load routes: {{e}}")
            import traceback
            traceback.print_exc()

# Create server config and WSGI app
server_config = WSGIServerConfig(CONFIG)
app = zServerWSGIApp(server_config)
'''

        # Write WSGI module
        with open(WSGI_TEMP_MODULE, "w", encoding="utf-8") as f:
            f.write(wsgi_content)

        self.logger.debug(f"[zServer] Created WSGI module: {WSGI_TEMP_MODULE}")
