---
generated: true
tags:
  - '#roadmap'
date: '2026-04-21'
related:
  - '[[2026-02-17-audit-summary-audit]]'
  - '[[2026-02-17-competitive-landscape-audit]]'
  - '[[2026-02-17-marketing-ux-audit]]'
  - '[[2026-02-17-roadmap-plan]]'
  - '[[2026-02-17-tech-audit-audit]]'
  - '[[2026-02-17-test-verification-audit]]'
  - '[[2026-02-17-ux-simulation-audit]]'
  - '[[2026-03-23-roadmap-adr]]'
  - '[[2026-03-23-roadmap-research]]'
---

# `roadmap` feature index

Auto-generated index of all documents tagged with `#roadmap`.

## Documents

### adr

- `2026-03-23-roadmap-adr` - `roadmap` adr: `roadmap` | (**status:** `{accepted|rejected|deprecated}`)

### audit

- `2026-02-17-audit-summary-audit` - vaultspec Comprehensive Audit: Executive Summary
- `2026-02-17-competitive-landscape-audit` - Competitive Landscape Analysis
- `2026-02-17-marketing-ux-audit` - Documentation UX Audit
- `2026-02-17-tech-audit-audit` - Technical Audit: vaultspec Codebase
- `2026-02-17-test-verification-audit` - Test Verification Report
- `2026-02-17-ux-simulation-audit` - UX Simulation Report: First-Time User Experience

### plan

- `2026-02-17-roadmap-plan` - vaultspec Roadmap: Wave-Based Rollout Plan

### research

- `2026-03-23-roadmap-research` - `roadmap` research: `roadmap`
