"""Vault document kernel: models, parsing, scanning, and hydration.

Re-exports from six internal modules: :mod:`.models`
(:class:`~vaultspec_core.vaultcore.models.DocType`,
:class:`~vaultspec_core.vaultcore.models.DocumentMetadata`,
:class:`~vaultspec_core.vaultcore.models.VaultConstants`),
:mod:`.parser`
(:func:`~vaultspec_core.vaultcore.parser.parse_frontmatter`,
:func:`~vaultspec_core.vaultcore.parser.parse_vault_metadata`),
:mod:`.links`, :mod:`.scanner`, :mod:`.query`, and
:mod:`.hydration`.  Consumed by :mod:`vaultspec_core.metrics`,
:mod:`vaultspec_core.graph`, and :mod:`vaultspec_core.mcp_server`.
"""

from .hydration import create_vault_doc as create_vault_doc
from .hydration import get_template_path as get_template_path
from .hydration import hydrate_template as hydrate_template
from .links import extract_related_links as extract_related_links
from .links import extract_wiki_links as extract_wiki_links
from .models import DocType as DocType
from .models import DocumentMetadata as DocumentMetadata
from .models import VaultConstants as VaultConstants
from .parser import parse_frontmatter as parse_frontmatter
from .parser import parse_vault_metadata as parse_vault_metadata
from .query import VaultDocument as VaultDocument
from .query import archive_feature as archive_feature
from .query import get_stats as get_stats
from .query import list_documents as list_documents
from .query import list_feature_details as list_feature_details
from .scanner import get_doc_type as get_doc_type
from .scanner import list_features as list_features
from .scanner import scan_vault as scan_vault
