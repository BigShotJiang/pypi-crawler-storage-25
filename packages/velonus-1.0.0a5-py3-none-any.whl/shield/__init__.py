"""Velonus CLI package."""
