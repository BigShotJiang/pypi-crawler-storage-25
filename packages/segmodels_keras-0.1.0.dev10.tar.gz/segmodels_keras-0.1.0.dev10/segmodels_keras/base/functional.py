from typing import Any

import keras

from segmodels_keras._compat import KERAS_GTE_3

if KERAS_GTE_3:
    from keras import ops
else:
    from keras import backend as ops

SMOOTH: float = 1e-5


# ----------------------------------------------------------------
#   Helpers
# ----------------------------------------------------------------


def _gather_channels(x: Any, indexes: Any, **kwargs: Any) -> Any:
    backend = kwargs["backend"]

    """Slice tensor along channels axis by given indexes"""
    if backend.image_data_format() == "channels_last":
        x = ops.permute_dimensions(x, (3, 0, 1, 2))
        x = ops.gather(x, indexes)
        x = ops.permute_dimensions(x, (1, 2, 3, 0))
    else:
        x = ops.permute_dimensions(x, (1, 0, 2, 3))
        x = ops.gather(x, indexes)
        x = ops.permute_dimensions(x, (1, 0, 2, 3))
    return x


def get_reduce_axes(per_image: bool, **kwargs: Any) -> list[int]:
    backend = kwargs["backend"]

    axes = [1, 2] if backend.image_data_format() == "channels_last" else [2, 3]
    if not per_image:
        axes.insert(0, 0)
    return axes


def gather_channels(
    *xs: Any, indexes: int | list[int] | None = None, **kwargs: Any
) -> tuple[Any, ...] | tuple[Any]:
    """Slice tensors along channels axis by given indexes"""
    if indexes is None:
        return xs
    elif isinstance(indexes, (int)):
        indexes = [indexes]
    xs = tuple(_gather_channels(x, indexes=indexes, **kwargs) for x in xs)
    return xs


def round_if_needed(x, threshold, **kwargs):
    if threshold is not None:
        x = ops.greater(x, threshold)
        if not KERAS_GTE_3:
            floatx = kwargs["backend"].floatx()
        else:
            floatx = keras.config.floatx()
        x = ops.cast(x, floatx)
    return x


def average(x, per_image=False, class_weights=None, **kwargs):  # noqa: ARG001
    if per_image:
        x = ops.mean(x, axis=0)
    if class_weights is not None:
        x = x * class_weights
    return ops.mean(x)


# ----------------------------------------------------------------
#   Metric Functions
# ----------------------------------------------------------------


def iou_score(
    gt,
    pr,
    class_weights=1.0,
    class_indexes=None,
    smooth=SMOOTH,
    per_image=False,
    threshold=None,
    **kwargs,
):
    r"""The `Jaccard index`_, also known as Intersection over Union and the Jaccard
    similarity coefficient (originally coined coefficient de communauté by Paul
    Jaccard), is a statistic used for comparing the similarity and diversity of sample
    sets. The Jaccard coefficient measures similarity between finite sample sets,
    and is defined as the size of the intersection divided by the size of the union of
    the sample sets:

    .. math:: J(A, B) = \frac{A \cap B}{A \cup B}

    Args:
        gt: ground truth 4D keras tensor (B, H, W, C) or (B, C, H, W)
        pr: prediction 4D keras tensor (B, H, W, C) or (B, C, H, W)
        class_weights: 1. or list of class weights, len(weights) = C
        class_indexes: Optional integer or list of integers, classes to consider, if
            ``None`` all classes are used.
        smooth: value to avoid division by zero
        per_image: if ``True``, metric is calculated as mean over images in batch (B),
            else over whole batch
        threshold: value to round predictions (use ``>`` comparison), if ``None``
            prediction will not be round

    Returns:
        IoU/Jaccard score in range [0, 1]

    .. _`Jaccard index`: https://en.wikipedia.org/wiki/Jaccard_index

    """
    gt, pr = gather_channels(gt, pr, indexes=class_indexes, **kwargs)
    pr = round_if_needed(pr, threshold, **kwargs)
    axes = get_reduce_axes(per_image, **kwargs)

    # score calculation
    intersection = ops.sum(gt * pr, axis=axes)
    union = ops.sum(gt + pr, axis=axes) - intersection

    score = (intersection + smooth) / (union + smooth)
    score = average(score, per_image, class_weights, **kwargs)

    return score


def f_score(
    gt,
    pr,
    beta=1,
    class_weights=1,
    class_indexes=None,
    smooth=SMOOTH,
    per_image=False,
    threshold=None,
    **kwargs,
):
    r"""The F-score (Dice coefficient) can be interpreted as a weighted average of the
    precision and recall, where an F-score reaches its best value at 1 and worst score
    at 0.
    The relative contribution of ``precision`` and ``recall`` to the F1-score are equal.

    The formula for the F score is:

    .. math:: F_\beta(precision, recall) = (1 + \beta^2) \frac{precision \cdot recall}
        {\beta^2 \cdot precision + recall}

    The formula in terms of *Type I* and *Type II* errors:

    .. math:: F_\beta(A, B) = \frac{(1 + \beta^2) TP} {(1 + \beta^2) TP + \beta^2 FN + FP}


    where:
        TP - true positive;
        FP - false positive;
        FN - false negative;

    Args:
        gt: ground truth 4D keras tensor (B, H, W, C) or (B, C, H, W)
        pr: prediction 4D keras tensor (B, H, W, C) or (B, C, H, W)
        class_weights: 1. or list of class weights, len(weights) = C
        class_indexes: Optional integer or list of integers, classes to consider, if
            ``None`` all classes are used.
        beta: f-score coefficient
        smooth: value to avoid division by zero
        per_image: if ``True``, metric is calculated as mean over images in batch (B),
            else over whole batch
        threshold: value to round predictions (use ``>`` comparison), if ``None``
            prediction will not be round

    Returns:
        F-score in range [0, 1]

    """  # noqa: E501
    gt, pr = gather_channels(gt, pr, indexes=class_indexes, **kwargs)
    pr = round_if_needed(pr, threshold, **kwargs)
    axes = get_reduce_axes(per_image, **kwargs)

    # calculate score
    tp = ops.sum(gt * pr, axis=axes)
    fp = ops.sum(pr, axis=axes) - tp
    fn = ops.sum(gt, axis=axes) - tp

    score = ((1 + beta**2) * tp + smooth) / (
        (1 + beta**2) * tp + beta**2 * fn + fp + smooth
    )
    score = average(score, per_image, class_weights, **kwargs)

    return score


def precision(
    gt,
    pr,
    class_weights=1,
    class_indexes=None,
    smooth=SMOOTH,
    per_image=False,
    threshold=None,
    **kwargs,
):
    r"""Calculate precision between the ground truth (gt) and the prediction (pr).

    .. math:: F_\beta(tp, fp) = \frac{tp} {(tp + fp)}

    where:
         - tp - true positives;
         - fp - false positives;

    Args:
        gt: ground truth 4D keras tensor (B, H, W, C) or (B, C, H, W)
        pr: prediction 4D keras tensor (B, H, W, C) or (B, C, H, W)
        class_weights: 1. or ``np.array`` of class weights
            (``len(weights) = num_classes``)
        class_indexes: Optional integer or list of integers, classes to consider, if
            ``None`` all classes are used.
        smooth: Float value to avoid division by zero.
        per_image: If ``True``, metric is calculated as mean over images in batch (B),
            else over whole batch.
        threshold: Float value to round predictions (use ``>`` comparison), if ``None``
            prediction will not be round.
        name: Optional string, if ``None`` default ``precision`` name is used.

    Returns:
        float: precision score
    """
    gt, pr = gather_channels(gt, pr, indexes=class_indexes, **kwargs)
    pr = round_if_needed(pr, threshold, **kwargs)
    axes = get_reduce_axes(per_image, **kwargs)

    # score calculation
    tp = ops.sum(gt * pr, axis=axes)
    fp = ops.sum(pr, axis=axes) - tp

    score = (tp + smooth) / (tp + fp + smooth)
    score = average(score, per_image, class_weights, **kwargs)

    return score


def recall(
    gt,
    pr,
    class_weights=1,
    class_indexes=None,
    smooth=SMOOTH,
    per_image=False,
    threshold=None,
    **kwargs,
):
    r"""Calculate recall between the ground truth (gt) and the prediction (pr).

    .. math:: F_\beta(tp, fn) = \frac{tp} {(tp + fn)}

    where:
         - tp - true positives;
         - fp - false positives;

    Args:
        gt: ground truth 4D keras tensor (B, H, W, C) or (B, C, H, W)
        pr: prediction 4D keras tensor (B, H, W, C) or (B, C, H, W)
        class_weights: 1. or ``np.array`` of class weights
            (``len(weights) = num_classes``)
        class_indexes: Optional integer or list of integers, classes to consider, if
            ``None`` all classes are used.
        smooth: Float value to avoid division by zero.
        per_image: If ``True``, metric is calculated as mean over images in batch (B),
            else over whole batch.
        threshold: Float value to round predictions (use ``>`` comparison), if ``None``
            prediction will not be round.
        name: Optional string, if ``None`` default ``precision`` name is used.

    Returns:
        float: recall score
    """
    gt, pr = gather_channels(gt, pr, indexes=class_indexes, **kwargs)
    pr = round_if_needed(pr, threshold, **kwargs)
    axes = get_reduce_axes(per_image, **kwargs)

    tp = ops.sum(gt * pr, axis=axes)
    fn = ops.sum(gt, axis=axes) - tp

    score = (tp + smooth) / (tp + fn + smooth)
    score = average(score, per_image, class_weights, **kwargs)

    return score


# ----------------------------------------------------------------
#   Loss Functions
# ----------------------------------------------------------------


def categorical_crossentropy(gt, pr, class_weights=1.0, class_indexes=None, **kwargs):
    backend = kwargs["backend"]

    gt, pr = gather_channels(gt, pr, indexes=class_indexes, **kwargs)

    # scale predictions so that the class probas of each sample sum to 1
    axis = 3 if backend.image_data_format() == "channels_last" else 1
    pr /= ops.sum(pr, axis=axis, keepdims=True)

    # clip to prevent NaN's and Inf's
    pr = ops.clip(pr, ops.epsilon(), 1 - ops.epsilon())

    # calculate loss
    output = gt * ops.log(pr) * class_weights
    return -ops.mean(output)


def binary_crossentropy(gt, pr, **kwargs):  # noqa: ARG001
    return ops.mean(ops.binary_crossentropy(gt, pr))


def categorical_focal_loss(gt, pr, gamma=2.0, alpha=0.25, class_indexes=None, **kwargs):
    r"""Implementation of Focal Loss from the paper in multiclass classification

    Formula:
        loss = - gt * alpha * ((1 - pr)^gamma) * log(pr)

    Args:
        gt: ground truth 4D keras tensor (B, H, W, C) or (B, C, H, W)
        pr: prediction 4D keras tensor (B, H, W, C) or (B, C, H, W)
        alpha: the same as weighting factor in balanced cross entropy, default 0.25
        gamma: focusing parameter for modulating factor (1-p), default 2.0
        class_indexes: Optional integer or list of integers, classes to consider, if
            ``None`` all classes are used.

    """
    gt, pr = gather_channels(gt, pr, indexes=class_indexes, **kwargs)

    # clip to prevent NaN's and Inf's
    pr = ops.clip(pr, ops.epsilon(), 1.0 - ops.epsilon())

    # Calculate focal loss
    loss = -gt * (alpha * ops.pow((1 - pr), gamma) * ops.log(pr))

    return ops.mean(loss)


def binary_focal_loss(gt, pr, gamma=2.0, alpha=0.25, **kwargs):  # noqa: ARG001
    r"""Implementation of Focal Loss from the paper in binary classification

    Formula:
        loss = - gt * alpha * ((1 - pr)^gamma) * log(pr) \
               - (1 - gt) * alpha * (pr^gamma) * log(1 - pr)

    Args:
        gt: ground truth 4D keras tensor (B, H, W, C) or (B, C, H, W)
        pr: prediction 4D keras tensor (B, H, W, C) or (B, C, H, W)
        alpha: the same as weighting factor in balanced cross entropy, default 0.25
        gamma: focusing parameter for modulating factor (1-p), default 2.0

    """
    # clip to prevent NaN's and Inf's
    pr = ops.clip(pr, ops.epsilon(), 1.0 - ops.epsilon())

    loss_1 = -gt * (alpha * ops.pow((1 - pr), gamma) * ops.log(pr))
    loss_0 = -(1 - gt) * ((1 - alpha) * ops.pow((pr), gamma) * ops.log(1 - pr))
    loss = ops.mean(loss_0 + loss_1)
    return loss
