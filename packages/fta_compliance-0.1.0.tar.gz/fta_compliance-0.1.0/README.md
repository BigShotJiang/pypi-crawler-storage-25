# FTA Compliance SaaS

**Local-first FTA compliance automation for transit agencies**

> ✅ Parse documents (DOCX, PDF, TXT)  
> ✅ Check compliance against 23 FTA areas  
> ✅ Generate 10 editable templates  
> ✅ Create compliance calendars (21+ deadlines)  
> ✅ **100% local processing — no data leaves your system**

---

## 🚀 Quick Start

### Installation

```bash
# CLI only
pip install fta-compliance

# With GUI (recommended for most users)
pip install fta-compliance[gui]
```

### Basic Usage

```bash
# CLI commands (for developers)
fta-parse policy.docx
fta-check policy.docx
fta-template title_vi_policy --var agency_name="Charleston Transit"
fta-calendar tier_ii 2026

# GUI (recommended for most users)
fta-gui
# Opens browser at http://localhost:8501
```

---

## 📦 What's Included

### 1. Document Parser

Parse DOCX, PDF, and TXT files to extract text and metadata.

```bash
fta-parse policy.docx --json
```

**Output:**
```json
{
  "success": true,
  "metadata": {
    "file_name": "policy.docx",
    "file_type": "docx",
    "file_size": 12345,
    "character_count": 5678
  },
  "text": "Full document text..."
}
```

---

### 2. Compliance Checker

Check documents against 23 FTA triennial review areas:

- Drug & Alcohol Testing (49 CFR Part 655)
- Title VI (49 CFR Part 21 + Circular 4702.1B)
- ADA (49 CFR Parts 27, 37, 38)
- Procurement (2 CFR Part 200 + Circular 4220.1F)
- Planning (49 USC Chapter 53)
- Financial Management (Circular 5010.1E)
- Safety (PTASP)
- Asset Management (49 CFR Part 625)
- EEO (49 CFR Part 60)
- And 14 more areas...

```bash
fta-check policy.docx
```

**Output:**
```
✅ Compliance Check: policy.docx
   Score: 73.5%
   Compliant: 17/23
   Non-Compliant: 4
   Partial: 2

⚠️  Areas needing attention (6):
   [HIGH] Random testing rate meets minimum requirements
      → Add content addressing: random, testing, rate
   [MEDIUM] Public participation plan includes LEP outreach
      → Add content addressing: lep, limited english
```

---

### 3. Template Generator

Generate 10 editable FTA compliance templates:

| Template | Citation |
|----------|----------|
| `title_vi_policy` | 49 CFR Part 21 + Circular 4702.1B |
| `ada_policy` | 49 CFR Parts 27, 37, 38 |
| `drug_alcohol_policy` | 49 CFR Part 655 |
| `procurement_policy` | 2 CFR Part 200 + Circular 4220.1F |
| `public_participation_plan` | 49 USC Chapter 53 |
| `emergency_plan` | 49 USC Chapter 53 + FTA guidance |
| `safety_plan` | PTASP (49 USC 5329) |
| `asset_management_plan` | 49 CFR Part 625 |
| `financial_plan` | 2 CFR Part 200 + Circular 5010.1E |
| `eeo_plan` | 49 CFR Part 60 |

**List all templates:**
```bash
fta-template list
```

**Generate a template:**
```bash
fta-template title_vi_policy \
  --var agency_name="Charleston Transit" \
  --var address="123 Main St, Charleston, WV" \
  --var phone="(304) 555-1234" \
  --var output="title_vi_policy.md"
```

---

### 4. Compliance Calendar

Generate compliance deadline calendars for Tier I or Tier II agencies.

```bash
# Full calendar for 2026
fta-calendar tier_ii 2026

# Upcoming deadlines (next 30 days)
fta-calendar --upcoming 30

# JSON output
fta-calendar tier_ii 2026 --json
```

**Output:**
```
📅 FTA Compliance Calendar
   Tier: tier_ii
   Year: 2026
   Total Deadlines: 21

📊 Quarterly Summary:
   Q1: 6 deadlines
   Q2: 5 deadlines
   Q3: 4 deadlines
   Q4: 6 deadlines

⚠️  HIGH PRIORITY (Next 30 Days): 3
   2026-01-31 — Random Testing Rate Report
   2026-01-31 — ADA Complaint Log Summary
   2026-01-15 — FMIS Update
```

---

## 🖥️ GUI Interface

**Recommended for most users!** The graphical interface makes it easy to:

- 📄 **Drag & drop** documents to parse
- ✅ **Click buttons** to check compliance
- 📋 **Fill forms** to generate templates
- 📅 **View calendars** with interactive filters

### Launch the GUI:

```bash
# Install with GUI support
pip install fta-compliance[gui]

# Run the GUI
fta-gui

# Opens in your browser at http://localhost:8501
```

### Features:

| Tab | What It Does |
|-----|-------------|
| **📄 Parse Document** | Upload DOCX/PDF/TXT → Extract text + metadata |
| **✅ Check Compliance** | Analyze against 23 FTA areas → Score + recommendations |
| **📋 Generate Template** | Select template → Fill form → Download editable document |
| **📅 Compliance Calendar** | View deadlines by quarter → Export to CSV/Markdown |

**All processing happens locally** — no data leaves your machine.

---

## 🔒 Privacy & Security

**100% Local Processing**

- ✅ No data leaves your machine
- ✅ No cloud API calls
- ✅ No telemetry or analytics
- ✅ Works offline
- ✅ Government-friendly (no security review required)

All parsing, compliance checking, and template generation happens locally on your machine. Your documents never leave your system.

---

## 📋 System Requirements

- Python 3.10, 3.11, or 3.12
- pip (Python package manager)
- 50 MB disk space

**Optional dependencies** (installed automatically):
- `python-docx` (for DOCX files)
- `pypdf` (for PDF files)
- `lxml` (for XML parsing)

---

## 🧪 Examples

### Example 1: Check Existing Policy

```bash
# Parse and check your existing Title VI policy
fta-check title_vi_policy.docx

# Output shows compliance score and gaps
# Use recommendations to update policy
```

### Example 2: Generate New Policy

```bash
# Generate a Title VI policy template
fta-template title_vi_policy \
  --var agency_name="Mountain Area Transit" \
  --var address="456 Oak Ave, Beckley, WV 25801" \
  --var phone="(304) 555-6789" \
  --var email="compliance@mountaintransit.org" \
  --output="title_vi_policy.md"

# Edit the generated template to match your agency
# Then check compliance
fta-check title_vi_policy.md
```

### Example 3: Plan Your Year

```bash
# Generate 2026 compliance calendar
fta-calendar tier_ii 2026 --output="compliance_calendar_2026.md"

# Check upcoming deadlines every Monday
fta-calendar --upcoming 30
```

---

## 🎯 Pricing

| Tier | Price | Features |
|------|-------|----------|
| **Free** | $0 | Document parser + basic compliance check |
| **Pro** | $97/mo | All 4 tools + full template library |
| **Enterprise** | $497/mo | Custom rules + priority support |

**Start with Free:**
```bash
pip install fta-compliance
```

**Upgrade to Pro:**
Visit https://solutionsbyvance.com/fta-compliance

---

## 🛠️ Development

### Install from source

```bash
git clone https://github.com/solutionsbyvance/fta-compliance.git
cd fta-compliance/package
pip install -e .
```

### Run tests

```bash
pip install -e ".[dev]"
pytest
```

### Build package

```bash
pip install build
python -m build
```

### Publish to PyPI

```bash
pip install twine
twine upload dist/*
```

---

## 📚 Documentation

Full documentation: https://github.com/solutionsbyvance/fta-compliance

### API Reference

```python
from fta_compliance import parse_document, check_compliance, generate_template, generate_calendar

# Parse a document
result = parse_document("policy.docx")
print(result["text"])

# Check compliance
result = check_compliance("policy.docx")
print(f"Compliance score: {result['score']}%")

# Generate template
template = generate_template("title_vi_policy", {"agency_name": "My Transit"})
print(template["content"])

# Generate calendar
calendar = generate_calendar(tier="tier_ii", year=2026)
print(f"{calendar['total_deadlines']} deadlines in 2026")
```

---

## 🤝 Support

**Documentation:** https://github.com/solutionsbyvance/fta-compliance  
**Issues:** https://github.com/solutionsbyvance/fta-compliance/issues  
**Email:** neal@solutionsbyvance.com  
**Website:** https://solutionsbyvance.com

---

## 📄 License

MIT License — see [LICENSE](LICENSE) file for details.

---

## 🏢 About

**Solutions by Vance, LLC** builds transparent, privacy-first AI tools for government and small business.

> "You get AI productivity without AI risk."

**Other projects:**
- [Transparent Code Standard](https://github.com/solutionsbyvance/Transparent-code-skill)
- FTA Compliance Ebook (https://nealvance.gumroad.com/l/pmrrg)

---

## 🚀 Changelog

### v0.1.0 (2026-04-16)
- Initial release
- Document parser (DOCX, PDF, TXT)
- Compliance checker (23 FTA areas)
- Template generator (10 templates)
- Compliance calendar (21+ deadlines)
- CLI interface
