#!/usr/bin/env python3
"""
FTA Compliance CLI

Command-line interface for FTA compliance tools.

Usage:
    fta-parse <file>              Parse a document
    fta-check <file>              Check compliance
    fta-template <name>           Generate template
    fta-calendar [tier] [year]    Generate calendar
"""

import sys
import json
import argparse
from pathlib import Path

from .parser import parse_document
from .rules import check_compliance
from .templates import generate_template, list_templates
from .deadlines import generate_calendar, get_upcoming_deadlines


def parse_command():
    """CLI command: fta-parse <file>"""
    parser = argparse.ArgumentParser(description="Parse FTA compliance documents")
    parser.add_argument("file", help="Document file to parse (.docx, .pdf, .txt)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()
    
    result = parse_document(args.file)
    
    if args.json:
        print(json.dumps(result, indent=2))
    elif result.get("success"):
        print(f"\n✅ Parsed: {result['metadata']['file_name']}")
        print(f"   Format: {result['format']}")
        print(f"   Size: {result['metadata']['file_size']} bytes")
        print(f"   Characters: {result['metadata']['character_count']}")
        print(f"\n📄 Preview (first 500 chars):\n{result['text'][:500]}...")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)


def check_command():
    """CLI command: fta-check <file>"""
    parser = argparse.ArgumentParser(description="Check FTA compliance")
    parser.add_argument("file", help="Document file to check")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--area", help="Check specific area only")
    args = parser.parse_args()
    
    result = check_compliance(args.file)
    
    if args.json:
        print(json.dumps(result, indent=2))
    elif result.get("success"):
        print(f"\n✅ Compliance Check: {result['document']}")
        print(f"   Score: {result['score']}%")
        print(f"   Compliant: {result['summary']['compliant']}/{result['summary']['total']}")
        print(f"   Non-Compliant: {result['summary']['non_compliant']}")
        print(f"   Partial: {result['summary']['partial']}")
        
        # Show non-compliant items
        non_compliant = [c for c in result["checks"] if c["status"] != "compliant"]
        if non_compliant:
            print(f"\n⚠️  Areas needing attention ({len(non_compliant)}):")
            for check in non_compliant[:10]:
                severity = check['severity'].upper()
                print(f"   [{severity}] {check['description']}")
                if check.get('recommendation'):
                    print(f"      → {check['recommendation']}")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)


def template_command():
    """CLI command: fta-template <name>"""
    parser = argparse.ArgumentParser(description="Generate FTA compliance templates")
    parser.add_argument("template", help="Template name (or 'list' to show all)")
    parser.add_argument("--var", action="append", help="Variable substitution (key=value)")
    parser.add_argument("--output", help="Output file path")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--list", action="store_true", help="List all templates")
    args = parser.parse_args()
    
    if args.list or args.template == "list":
        result = list_templates()
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"\n📋 Available FTA Templates ({result['count']}):\n")
            for i, t in enumerate(result["templates"], 1):
                print(f"{i}. {t['display_name']}")
                print(f"   {t['description']}")
                print(f"   Citation: {t['citation']}")
                print()
        return
    
    # Parse variables
    variables = {}
    if args.var:
        for v in args.var:
            if "=" in v:
                key, value = v.split("=", 1)
                variables[key.strip()] = value.strip()
    
    result = generate_template(args.template, variables)
    
    if args.json:
        print(json.dumps(result, indent=2))
    elif result.get("success"):
        if args.output:
            with open(args.output, 'w') as f:
                f.write(result["content"])
            print(f"\n✅ Template saved to: {args.output}")
        else:
            print(f"\n✅ Template: {result['display_name']}")
            print(f"   Description: {result['description']}")
            print(f"   Citation: {result['citation']}")
            print(f"   Word count: {result['word_count']}")
            print(f"\n📄 Content:\n{result['content']}")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)


def calendar_command():
    """CLI command: fta-calendar [tier] [year]"""
    parser = argparse.ArgumentParser(description="Generate FTA compliance calendar")
    parser.add_argument("tier", nargs="?", default="tier_ii", help="Agency tier (tier_i, tier_ii)")
    parser.add_argument("year", nargs="?", type=int, default=None, help="Calendar year")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--upcoming", type=int, help="Show deadlines due within N days")
    args = parser.parse_args()
    
    if args.upcoming:
        result = get_upcoming_deadlines(tier=args.tier, days_ahead=args.upcoming)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"\n📅 Upcoming Deadlines (Next {args.upcoming} Days)")
            print(f"   Tier: {args.tier}")
            print(f"   Count: {result['count']}\n")
            for d in result["deadlines"]:
                print(f"   {d['due_date']} — {d['name']}")
                print(f"      → {d['submission_to']}")
    else:
        result = generate_calendar(tier=args.tier, year=args.year)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"\n📅 FTA Compliance Calendar")
            print(f"   Tier: {result['agency_tier']}")
            print(f"   Year: {result['year']}")
            print(f"   Total Deadlines: {result['total_deadlines']}")
            print(f"\n📊 Quarterly Summary:")
            for quarter, count in result["quarterly_summary"].items():
                print(f"   {quarter}: {count} deadlines")
            
            print(f"\n📋 All Deadlines:")
            for d in result["deadlines"]:
                print(f"   {d['due_date']} — {d['name']}")
                print(f"      → {d['submission_to']} ({d['frequency']})")
            
            if result["high_priority"]:
                print(f"\n⚠️  HIGH PRIORITY (Next 30 Days): {len(result['high_priority'])}")
                for d in result["high_priority"]:
                    print(f"   {d['due_date']} — {d['name']}")


def main():
    """Main CLI entry point."""
    if len(sys.argv) < 2:
        print("\n🔧 FTA Compliance Tools")
        print("\nUsage:")
        print("  fta-parse <file>              Parse a document (.docx, .pdf, .txt)")
        print("  fta-check <file>              Check document compliance")
        print("  fta-template <name>           Generate template")
        print("  fta-calendar [tier] [year]    Generate compliance calendar")
        print("\nExamples:")
        print("  fta-parse policy.docx")
        print("  fta-check policy.docx")
        print("  fta-template title_vi_policy --var agency_name='My Transit'")
        print("  fta-calendar tier_ii 2026")
        print("  fta-calendar --upcoming 30")
        print("\nRun 'fta-template list' to see all available templates.")
        sys.exit(0)
    
    command = sys.argv[1]
    
    if command == "parse":
        sys.argv = [sys.argv[0]] + sys.argv[2:]
        parse_command()
    elif command == "check":
        sys.argv = [sys.argv[0]] + sys.argv[2:]
        check_command()
    elif command == "template":
        sys.argv = [sys.argv[0]] + sys.argv[2:]
        template_command()
    elif command == "calendar":
        sys.argv = [sys.argv[0]] + sys.argv[2:]
        calendar_command()
    else:
        print(f"❌ Unknown command: {command}")
        print("Run 'fta-compliance' without arguments for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
