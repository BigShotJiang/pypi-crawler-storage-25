#!/usr/bin/env python3
"""
FTA Compliance GUI

Streamlit-based graphical interface for FTA compliance tools.

Usage:
    pip install fta-compliance[gui]
    fta-gui

Opens browser at http://localhost:8501
"""

import streamlit as st
from pathlib import Path
import tempfile
import json

from .parser import parse_document
from .rules import check_compliance
from .templates import generate_template, list_templates
from .deadlines import generate_calendar, get_upcoming_deadlines


# ============================================================================
# Page Configuration
# ============================================================================

st.set_page_config(
    page_title="FTA Compliance Tools",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #666;
        margin-bottom: 2rem;
    }
    .success-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d4edda;
        border-left: 4px solid #28a745;
        margin: 1rem 0;
    }
    .warning-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #fff3cd;
        border-left: 4px solid #ffc107;
        margin: 1rem 0;
    }
    .info-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d1ecf1;
        border-left: 4px solid #17a2b8;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)


# ============================================================================
# Sidebar
# ============================================================================

with st.sidebar:
    st.markdown("### 🏛️ FTA Compliance Tools")
    st.markdown("**Solutions by Vance, LLC**")
    st.markdown("---")
    
    # Agency Info (for template pre-fill)
    st.markdown("### ⚙️ Agency Info")
    st.markdown("*Optional: Pre-fill templates*")
    
    agency_name = st.text_input("Agency Name", placeholder="e.g., Charleston Transit")
    agency_address = st.text_input("Address", placeholder="e.g., 123 Main St")
    agency_phone = st.text_input("Phone", placeholder="e.g., (304) 555-1234")
    agency_email = st.text_input("Email", placeholder="e.g., compliance@agency.org")
    
    st.markdown("---")
    
    # Quick Links
    st.markdown("### 📚 Resources")
    st.markdown("- [Documentation](https://github.com/solutionsbyvance/fta-compliance)")
    st.markdown("- [Report Issue](https://github.com/solutionsbyvance/fta-compliance/issues)")
    st.markdown("- [Solutions by Vance](https://solutionsbyvance.com)")
    
    st.markdown("---")
    st.markdown("*Version 0.1.0*")
    st.markdown("*100% Local Processing*")
    st.markdown("*No data leaves your system*")


# ============================================================================
# Main App
# ============================================================================

def main():
    """Main Streamlit application."""
    
    # Header
    st.markdown('<p class="main-header">🏛️ FTA Compliance Tools</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Local-first compliance automation for transit agencies</p>', unsafe_allow_html=True)
    
    # Tab Navigation
    tab1, tab2, tab3, tab4 = st.tabs([
        "📄 Parse Document",
        "✅ Check Compliance",
        "📋 Generate Template",
        "📅 Compliance Calendar"
    ])
    
    with tab1:
        render_parse_tab()
    
    with tab2:
        render_compliance_tab()
    
    with tab3:
        render_templates_tab()
    
    with tab4:
        render_calendar_tab()


# ============================================================================
# Tab 1: Parse Document
# ============================================================================

def render_parse_tab():
    """Render document parser tab."""
    st.markdown("### 📄 Parse Document")
    st.markdown("Upload a document (DOCX, PDF, or TXT) to extract text and metadata.")
    
    # File uploader
    uploaded_file = st.file_uploader(
        "Choose a file",
        type=["docx", "pdf", "txt", "md"],
        help="Supported formats: .docx, .pdf, .txt, .md"
    )
    
    if uploaded_file is not None:
        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix=Path(uploaded_file.name).suffix) as tmp:
            tmp.write(uploaded_file.getvalue())
            tmp_path = tmp.name
        
        try:
            # Parse document
            with st.spinner("Parsing document..."):
                result = parse_document(tmp_path)
            
            if result.get("success"):
                # Display results
                st.success(f"✅ Parsed: {result['metadata']['file_name']}")
                
                # Metadata
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Format", result['format'].upper())
                with col2:
                    st.metric("File Size", f"{result['metadata']['file_size']:,} bytes")
                with col3:
                    st.metric("Characters", f"{result['metadata']['character_count']:,}")
                
                # Text preview
                st.markdown("#### 📄 Text Preview")
                st.text_area(
                    "Document content",
                    value=result['text'][:2000],
                    height=300,
                    label_visibility="collapsed"
                )
                
                # Download options
                st.markdown("#### 📥 Download")
                col1, col2 = st.columns(2)
                with col1:
                    st.download_button(
                        label="Download JSON",
                        data=json.dumps(result, indent=2),
                        file_name=f"{Path(uploaded_file.name).stem}_parsed.json",
                        mime="application/json"
                    )
                with col2:
                    st.download_button(
                        label="Download Text",
                        data=result['text'],
                        file_name=f"{Path(uploaded_file.name).stem}.txt",
                        mime="text/plain"
                    )
                
                # Next step suggestion
                st.info("💡 **Next step:** Use the 'Check Compliance' tab to analyze this document against FTA rules.")
                
            else:
                st.error(f"❌ Error: {result.get('error', 'Unknown error')}")
                
        finally:
            # Clean up temp file
            Path(tmp_path).unlink(missing_ok=True)


# ============================================================================
# Tab 2: Check Compliance
# ============================================================================

def render_compliance_tab():
    """Render compliance checker tab."""
    st.markdown("### ✅ Check Compliance")
    st.markdown("Analyze a document against 23 FTA triennial review areas.")
    
    # File uploader
    uploaded_file = st.file_uploader(
        "Choose a document",
        type=["docx", "pdf", "txt", "md"],
        help="Upload a policy, procedure, or compliance document"
    )
    
    if uploaded_file is not None:
        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix=Path(uploaded_file.name).suffix) as tmp:
            tmp.write(uploaded_file.getvalue())
            tmp_path = tmp.name
        
        try:
            # Check compliance
            with st.spinner("Checking compliance..."):
                result = check_compliance(tmp_path)
            
            if result.get("success"):
                # Score display
                score = result['score']
                
                # Color-coded score
                if score >= 80:
                    st.success(f"✅ Compliance Score: **{score}%**")
                elif score >= 60:
                    st.warning(f"⚠️ Compliance Score: **{score}%**")
                else:
                    st.error(f"❌ Compliance Score: **{score}%**")
                
                # Summary metrics
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Total Checks", result['summary']['total'])
                with col2:
                    st.metric("✅ Compliant", result['summary']['compliant'])
                with col3:
                    st.metric("❌ Non-Compliant", result['summary']['non_compliant'])
                with col4:
                    st.metric("⚠️ Partial", result['summary']['partial'])
                
                # Progress bar
                st.progress(score / 100)
                
                # Detailed results
                st.markdown("#### 📋 Detailed Results")
                
                # Filter options
                filter_status = st.multiselect(
                    "Filter by status",
                    options=["compliant", "non_compliant", "partial"],
                    default=["non_compliant", "partial"],
                    help="Show only selected statuses"
                )
                
                # Display checks
                for check in result['checks']:
                    if filter_status and check['status'] not in filter_status:
                        continue
                    
                    # Icon based on status
                    if check['status'] == "compliant":
                        icon = "✅"
                        color = "green"
                    elif check['status'] == "non_compliant":
                        icon = "❌"
                        color = "red"
                    else:
                        icon = "⚠️"
                        color = "orange"
                    
                    with st.expander(f"{icon} [{check['severity'].upper()}] {check['description']}"):
                        st.markdown(f"**Area:** {check['area']}")
                        st.markdown(f"**Citation:** {check['citation']}")
                        st.markdown(f"**Findings:** {check['findings']}")
                        if check.get('recommendation'):
                            st.info(f"💡 **Recommendation:** {check['recommendation']}")
                
                # Download report
                st.markdown("#### 📥 Download Report")
                st.download_button(
                    label="Download JSON Report",
                    data=json.dumps(result, indent=2),
                    file_name=f"compliance_report_{Path(uploaded_file.name).stem}.json",
                    mime="application/json"
                )
                
            else:
                st.error(f"❌ Error: {result.get('error', 'Unknown error')}")
                
        finally:
            # Clean up temp file
            Path(tmp_path).unlink(missing_ok=True)
    
    # Info box
    st.info("""
    **📚 What gets checked?**
    
    This tool analyzes your document against 23 FTA compliance areas:
    - Drug & Alcohol Testing (49 CFR Part 655)
    - Title VI (Non-Discrimination)
    - ADA (Americans with Disabilities Act)
    - Procurement (2 CFR Part 200)
    - Planning, Financial Management, Safety, Asset Management, EEO, and more...
    """)


# ============================================================================
# Tab 3: Generate Templates
# ============================================================================

def render_templates_tab():
    """Render template generator tab."""
    st.markdown("### 📋 Generate Template")
    st.markdown("Select a template, fill in your agency info, and download.")
    
    # Get template list
    templates_result = list_templates()
    template_options = {t['display_name']: t['name'] for t in templates_result['templates']}
    
    # Template selector
    selected_display = st.selectbox(
        "Choose a template",
        options=list(template_options.keys()),
        help="Select the type of document you want to generate"
    )
    
    template_name = template_options[selected_display]
    
    # Show template info
    template_info = next(t for t in templates_result['templates'] if t['name'] == template_name)
    st.info(f"**Citation:** {template_info['citation']}")
    
    # Agency info form
    st.markdown("#### 📝 Template Details")
    
    col1, col2 = st.columns(2)
    with col1:
        agency_name_input = st.text_input(
            "Agency Name",
            value=st.session_state.get('agency_name', ''),
            placeholder="e.g., Charleston Transit"
        )
        agency_phone_input = st.text_input(
            "Phone",
            value=st.session_state.get('agency_phone', ''),
            placeholder="e.g., (304) 555-1234"
        )
    with col2:
        agency_address_input = st.text_input(
            "Address",
            value=st.session_state.get('agency_address', ''),
            placeholder="e.g., 123 Main St"
        )
        agency_email_input = st.text_input(
            "Email",
            value=st.session_state.get('agency_email', ''),
            placeholder="e.g., compliance@agency.org"
        )
    
    # Generate button
    if st.button("🚀 Generate Template", type="primary"):
        # Prepare variables
        variables = {}
        if agency_name_input:
            variables['agency_name'] = agency_name_input
        if agency_address_input:
            variables['address'] = agency_address_input
        if agency_phone_input:
            variables['phone'] = agency_phone_input
        if agency_email_input:
            variables['email'] = agency_email_input
        
        # Generate template
        with st.spinner("Generating template..."):
            result = generate_template(template_name, variables)
        
        if result.get("success"):
            st.success(f"✅ Template generated: {result['display_name']}")
            
            # Display template
            st.markdown("#### 📄 Preview")
            st.text_area(
                "Template content",
                value=result['content'],
                height=500,
                label_visibility="collapsed"
            )
            
            # Download
            st.markdown("#### 📥 Download")
            st.download_button(
                label="Download Markdown",
                data=result['content'],
                file_name=f"{template_name}.md",
                mime="text/markdown"
            )
            
            # Word count
            st.info(f"📊 **Word count:** {result['word_count']} words")
        else:
            st.error(f"❌ Error: {result.get('error', 'Unknown error')}")
    
    # Template descriptions
    with st.expander("📚 See all available templates"):
        for t in templates_result['templates']:
            st.markdown(f"- **{t['display_name']}**: {t['description']}")
            st.markdown(f"  - *Citation: {t['citation']}*")


# ============================================================================
# Tab 4: Compliance Calendar
# ============================================================================

def render_calendar_tab():
    """Render compliance calendar tab."""
    st.markdown("### 📅 Compliance Calendar")
    st.markdown("Generate a compliance deadline calendar for your agency.")
    
    # Options
    col1, col2, col3 = st.columns(3)
    with col1:
        tier = st.selectbox(
            "Agency Tier",
            options=["tier_ii", "tier_i"],
            help="Select your agency tier"
        )
    with col2:
        year = st.number_input(
            "Year",
            min_value=2024,
            max_value=2030,
            value=2026,
            help="Calendar year"
        )
    with col3:
        upcoming_days = st.number_input(
            "Upcoming (days)",
            min_value=7,
            max_value=365,
            value=30,
            help="Show deadlines due within this many days"
        )
    
    # Generate button
    if st.button("🚀 Generate Calendar", type="primary"):
        with st.spinner("Generating calendar..."):
            calendar_result = generate_calendar(tier=tier, year=year)
            upcoming_result = get_upcoming_deadlines(tier=tier, days_ahead=upcoming_days)
        
        if calendar_result.get("success"):
            # Summary
            st.success(f"✅ Generated calendar for {year} ({tier.replace('_', ' ').title()})")
            
            # Metrics
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Deadlines", calendar_result['total_deadlines'])
            with col2:
                st.metric("Q1", calendar_result['quarterly_summary']['Q1'])
            with col3:
                st.metric("Q2", calendar_result['quarterly_summary']['Q2'])
            with col4:
                st.metric("Q3", calendar_result['quarterly_summary']['Q3'])
            
            # Quarterly breakdown
            st.markdown("#### 📊 Quarterly Breakdown")
            quarter_data = {
                'Quarter': ['Q1', 'Q2', 'Q3', 'Q4'],
                'Deadlines': list(calendar_result['quarterly_summary'].values())
            }
            st.bar_chart(quarter_data, x='Quarter', y='Deadlines')
            
            # Upcoming deadlines
            st.markdown(f"#### ⚠️ Upcoming Deadlines (Next {upcoming_days} Days)")
            if upcoming_result['deadlines']:
                for d in upcoming_result['deadlines']:
                    st.warning(f"**{d['due_date']}** — {d['name']}\n\n→ {d['submission_to']}")
            else:
                st.info("No deadlines due in the next 30 days. 🎉")
            
            # All deadlines
            st.markdown("#### 📋 All Deadlines")
            for d in calendar_result['deadlines']:
                with st.expander(f"**{d['due_date']}** — {d['name']}"):
                    st.markdown(f"**Citation:** {d['citation']}")
                    st.markdown(f"**Submit to:** {d['submission_to']}")
                    st.markdown(f"**Frequency:** {d['frequency']}")
                    st.markdown(f"**Tier:** {d['tier']}")
                    st.markdown(f"**Description:** {d['description']}")
                    if d.get('notes'):
                        st.info(f"💡 **Note:** {d['notes']}")
            
            # Download
            st.markdown("#### 📥 Download")
            col1, col2 = st.columns(2)
            with col1:
                st.download_button(
                    label="Download JSON",
                    data=json.dumps(calendar_result, indent=2),
                    file_name=f"compliance_calendar_{tier}_{year}.json",
                    mime="application/json"
                )
            with col2:
                # Markdown format
                md_content = f"# FTA Compliance Calendar {year}\n\n"
                md_content += f"**Tier:** {tier}\n\n"
                md_content += f"**Total Deadlines:** {calendar_result['total_deadlines']}\n\n"
                for d in calendar_result['deadlines']:
                    md_content += f"- **{d['due_date']}**: {d['name']} ({d['frequency']})\n"
                    md_content += f"  - Submit to: {d['submission_to']}\n"
                
                st.download_button(
                    label="Download Markdown",
                    data=md_content,
                    file_name=f"compliance_calendar_{tier}_{year}.md",
                    mime="text/markdown"
                )
        else:
            st.error(f"❌ Error: {calendar_result.get('error', 'Unknown error')}")
    
    # Info box
    st.info("""
    **📚 Agency Tiers:**
    
    - **Tier I**: Large agencies (100+ vehicles, urbanized areas >200K population)
    - **Tier II**: Small/rural agencies (<100 vehicles, smaller urbanized areas)
    
    Most small transit agencies are Tier II.
    """)


# ============================================================================
# Entry Point
# ============================================================================

if __name__ == "__main__":
    main()
