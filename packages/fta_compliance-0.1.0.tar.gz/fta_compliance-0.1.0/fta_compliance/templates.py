#!/usr/bin/env python3
"""
FTA Compliance Template Generator

Generates editable templates for common FTA compliance documents.
10 templates covering major triennial review areas.

Usage: from fta_compliance import generate_template
       template = generate_template("title_vi_policy", {"agency_name": "My Transit"})
"""

from typing import Dict, Optional
from datetime import datetime
from pathlib import Path


# ============================================================================
# Template Library
# ============================================================================

TEMPLATES = {
    "title_vi_policy": {
        "name": "Title VI Policy",
        "description": "Non-discrimination policy for public transit agencies",
        "citation": "49 CFR Part 21 + FTA Circular 4702.1B",
        "template": """# Title VI Policy
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Policy Statement

{agency_name} is committed to complying with Title VI of the Civil Rights Act of 1964, as amended, and all related federal and state regulations. It is the policy of {agency_name} to ensure that no person shall, on the grounds of race, color, or national origin, be excluded from participation in, be denied the benefits of, or be otherwise subjected to discrimination under any of its programs, services, or activities.

## Title VI Assurances

{agency_name} will:

1. Ensure that no person shall, on the grounds of race, color, or national origin, be denied participation in any program or service
2. Provide meaningful access to Limited English Proficient (LEP) individuals
3. Conduct service equity analyses to ensure fair distribution of benefits
4. Maintain a public participation plan that includes outreach to minority communities
5. Designate a Title VI Coordinator to oversee compliance efforts

## Complaint Procedures

Any person who believes they have been discriminated against may file a complaint with:

**Title VI Coordinator**
{agency_name}
{address}
{phone}
{email}

Complaints must be filed within 180 days of the alleged discriminatory act.

## Public Notification

This policy will be:
- Posted on the agency website
- Displayed at all agency facilities
- Included in employee handbooks
- Made available upon request in alternative formats

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "ada_policy": {
        "name": "ADA Policy",
        "description": "Americans with Disabilities Act compliance policy",
        "citation": "49 CFR Parts 27, 37, 38",
        "template": """# Americans with Disabilities Act (ADA) Policy
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Policy Statement

{agency_name} is committed to providing equal access to all individuals with disabilities in accordance with the Americans with Disabilities Act of 1990 (ADA), as amended. No qualified individual with a disability shall be excluded from participation in or be denied the benefits of the services, programs, or activities of {agency_name}.

## ADA Requirements

{agency_name} will:

1. **Vehicle Accessibility**: Ensure all vehicles meet ADA accessibility standards (49 CFR Part 38)
2. **Paratransit Service**: Provide complementary paratransit service to eligible individuals
3. **Facility Accessibility**: Maintain accessible stations, stops, and facilities
4. **Effective Communication**: Provide auxiliary aids and services when necessary
5. **Reasonable Modifications**: Make reasonable modifications to policies, practices, and procedures

## Paratransit Eligibility

Individuals unable to use fixed-route service due to a disability may apply for paratransit services. Eligibility determinations will be made in accordance with 49 CFR Part 37.

## Grievance Procedures

Any person who believes they have been discriminated against may file a grievance with:

**ADA Coordinator**
{agency_name}
{address}
{phone}
{email}

Grievances must be filed within 180 days of the alleged discriminatory act.

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "drug_alcohol_policy": {
        "name": "Drug & Alcohol Testing Policy",
        "description": "Controlled substances and alcohol misuse prevention",
        "citation": "49 CFR Part 655",
        "template": """# Drug & Alcohol Testing Policy
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Policy Statement

{agency_name} is committed to maintaining a drug-free and alcohol-free workplace in compliance with 49 CFR Part 655. This policy applies to all employees performing safety-sensitive functions.

## Testing Requirements

### Random Testing
- **Drug Testing Rate:** 50% of safety-sensitive employees annually
- **Alcohol Testing Rate:** 10% of safety-sensitive employees annually

### Testing Scenarios

1. **Pre-Employment**: Required for all safety-sensitive positions
2. **Random**: Conducted throughout the year using scientifically valid selection methods
3. **Post-Accident**: Required after accidents meeting specific criteria
4. **Reasonable Suspicion**: When trained supervisors observe signs of drug/alcohol use
5. **Return-to-Duty**: Required after violation before returning to safety-sensitive functions
6. **Follow-Up**: Unannounced testing after return-to-duty (minimum 6 tests in first year)

## Prohibited Conduct

Employees performing safety-sensitive functions are prohibited from:

- Using controlled substances (except as authorized by prescription)
- Using alcohol while performing safety-sensitive functions
- Reporting for duty within 4 hours of alcohol use
- Reporting for duty while under the influence of alcohol
- Refusing to submit to required testing

## Testing Windows

- **Alcohol**: 8-hour window for post-accident testing
- **Drugs**: 32-hour window for post-accident testing

## Consequences

Violations of this policy will result in:
- Immediate removal from safety-sensitive functions
- Evaluation by a Substance Abuse Professional (SAP)
- Completion of return-to-duty process
- Potential disciplinary action up to and including termination

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "procurement_policy": {
        "name": "Procurement Policy",
        "description": "Procurement standards and procedures",
        "citation": "2 CFR Part 200 + FTA Circular 4220.1F",
        "template": """# Procurement Policy
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Policy Statement

{agency_name} will conduct all procurement transactions in compliance with 2 CFR Part 200 and FTA Circular 4220.1F, ensuring full and open competition, best value, and compliance with federal requirements.

## Procurement Methods

### 1. Micro-Purchases (Under $10,000)
- No quotes required
- Price and reasonableness determination documented
- Distributed among small and minority businesses when possible

### 2. Small Purchases ($10,000 - $250,000)
- Minimum of 3 written quotes required
- Documentation of price comparison
- Award to lowest responsive and responsible bidder

### 3. Sealed Bids (Over $250,000)
- Public advertisement
- Sealed submissions
- Award to lowest responsive and responsible bidder

### 4. Competitive Proposals
- Request for Proposals (RFP) process
- Technical and price evaluation
- Award to offeror providing best value

## Buy America Requirements

All iron, steel, and manufactured products purchased with federal funds must be produced in the United States unless a waiver is granted. Documentation of compliance must be maintained.

## Disadvantaged Business Enterprise (DBE)

{agency_name} will:
- Establish annual DBE participation goals
- Provide opportunities for DBE participation
- Maintain records of DBE participation
- Report DBE participation to FTA

## Contract Administration

All contracts will include:
- Scope of work
- Deliverables and timeline
- Payment terms
- Termination clauses
- Compliance with federal requirements
- Audit and inspection rights

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "public_participation_plan": {
        "name": "Public Participation Plan",
        "description": "Plan for engaging the public in transit decisions",
        "citation": "49 USC Chapter 53",
        "template": """# Public Participation Plan
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Purpose

This plan establishes procedures for meaningful public participation in {agency_name}'s planning, programming, and decision-making processes.

## Public Participation Goals

1. Provide timely access to information
2. Offer opportunities for public comment
3. Ensure representation of diverse communities
4. Incorporate public input into decisions
5. Provide feedback on how input was used

## Engagement Methods

### Public Meetings
- Minimum of 2 public meetings per year
- Held at accessible locations and times
- Virtual participation options available
- Interpretation services for LEP individuals

### Public Comment Periods
- Minimum 30-day comment periods for major documents
- Comments accepted via mail, email, and online
- All comments documented and responded to

### Advisory Committees
- Citizen Advisory Committee meets quarterly
- Includes representation from diverse communities
- Provides input on service changes and planning

### Outreach to Underserved Communities
- Targeted outreach to minority and LEP populations
- Partnerships with community-based organizations
- Materials available in multiple languages
- Meetings held in underserved communities

## Limited English Proficient (LEP) Outreach

{agency_name} will:
- Identify LEP populations in service area
- Translate vital documents
- Provide interpretation at public meetings
- Train staff on LEP requirements

## Documentation

All public participation activities will be documented, including:
- Meeting notices and agendas
- Attendance records
- Comments received
- Responses to comments
- How input influenced decisions

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "emergency_plan": {
        "name": "Emergency Preparedness Plan",
        "description": "Emergency response and continuity of operations",
        "citation": "49 USC Chapter 53 + FTA guidance",
        "template": """# Emergency Preparedness Plan
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Purpose

This plan establishes procedures for responding to emergencies and maintaining essential services during disruptions.

## Emergency Types

1. **Natural Disasters**: Earthquakes, floods, severe weather
2. **Human-Caused Incidents**: Accidents, security threats, cyber attacks
3. **Public Health Emergencies**: Pandemics, disease outbreaks
4. **Service Disruptions**: Mechanical failures, fuel shortages, labor strikes

## Emergency Response Structure

### Incident Command System (ICS)
- Incident Commander: {position}
- Operations Section: {position}
- Planning Section: {position}
- Logistics Section: {position}
- Finance/Admin Section: {position}

### Communication Protocols
- Primary: {communication_method}
- Backup: {backup_method}
- Emergency contact list maintained and updated quarterly

## Continuity of Operations

### Essential Functions
1. Emergency medical transport
2. Evacuation support
3. Critical worker transport
4. Public information dissemination

### Staffing Plans
- Essential personnel identified
- Cross-training completed
- Succession planning documented

## Coordination with Partners

- Local Emergency Management Agency
- Law Enforcement
- Fire/EMS
- Hospitals
- Other transit agencies

## Training and Exercises

- Annual emergency response training
- Tabletop exercises twice per year
- Full-scale exercises every 3 years
- After-action reviews and improvement plans

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "safety_plan": {
        "name": "Safety Management Plan",
        "description": "Comprehensive safety management system",
        "citation": "PTASP (Public Transportation Agency Safety Plan)",
        "template": """# Safety Management Plan
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Safety Policy

{agency_name} is committed to providing safe public transportation services. This Safety Management Plan establishes our safety management system in accordance with PTASP requirements.

## Safety Goals

1. Zero fatalities
2. Reduce preventable accidents by 10% annually
3. Achieve 95% safety training completion
4. Maintain safety culture survey scores above 80%

## Safety Risk Management

### Hazard Identification
- Employee reporting system
- Safety audits and inspections
- Accident/incident investigations
- Data analysis and trend monitoring

### Risk Assessment
- Evaluate likelihood and severity
- Prioritize based on risk level
- Document mitigation strategies

### Risk Mitigation
- Implement controls
- Monitor effectiveness
- Adjust as needed

## Safety Assurance

### Performance Monitoring
- Track safety performance indicators
- Compare against targets
- Report to Board quarterly

### Audits and Assessments
- Annual internal audits
- External audits every 3 years
- Corrective action tracking

### Continuous Improvement
- Lessons learned documentation
- Best practice sharing
- Plan updates as needed

## Safety Promotion

### Training
- New employee safety orientation
- Annual refresher training
- Position-specific safety training
- Supervisor safety leadership training

### Communication
- Safety bulletins and alerts
- Safety committee meetings
- Employee safety recognition program

---

**Safety Accountability:**

- **Accountable Executive:** {name}
- **Safety Manager:** {name}
- **Board Safety Committee Chair:** {name}

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "asset_management_plan": {
        "name": "Asset Management Plan (TAM)",
        "description": "Transit Asset Management plan",
        "citation": "49 CFR Part 625",
        "template": """# Transit Asset Management (TAM) Plan
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Purpose

This plan establishes {agency_name}'s approach to managing transit assets in accordance with 49 CFR Part 625 (Transit Asset Management rule).

## Asset Inventory

### Rolling Stock
- Revenue vehicles: {count}
- Non-revenue vehicles: {count}
- Average age: {age} years
- Replacement cycle: {cycle} years

### Facilities
- Maintenance facilities: {count}
- Administrative offices: {count}
- Storage yards: {count}

### Infrastructure
- Routes: {count}
- Stops/Stations: {count}
- Shelters: {count}

### Equipment
- Maintenance equipment: {count}
- IT systems: {count}
- Fare collection: {count}

## Condition Assessment

### Rating Scale
- **5 (Excellent)**: Like new condition
- **4 (Good)**: Minor wear, fully functional
- **3 (Adequate)**: Some deterioration, functional
- **2 (Marginal)**: Significant deterioration, needs repair
- **1 (Poor)**: Major deterioration, needs replacement

### Current Condition
- Rolling Stock: {rating}
- Facilities: {rating}
- Infrastructure: {rating}
- Equipment: {rating}

## Performance Targets

- **Vehicle Useful Life**: {target} years
- **Facility Condition**: Maintain average rating of {rating} or higher
- **Preventive Maintenance**: Complete 95% of scheduled PM
- **Asset Availability**: Maintain 90% fleet availability

## Investment Priorities

1. Safety-critical replacements
2. Regulatory compliance
3. State of good repair
4. Service improvements

## Decision-Making Process

Asset investment decisions will consider:
- Condition assessment
- Remaining useful life
- Cost-benefit analysis
- Safety impact
- Service impact
- Funding availability

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "financial_plan": {
        "name": "Financial Management Plan",
        "description": "Financial policies and procedures",
        "citation": "2 CFR Part 200 + FTA Circular 5010.1E",
        "template": """# Financial Management Plan
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## Financial Policies

{agency_name} will maintain financial management systems that comply with 2 CFR Part 200 and FTA Circular 5010.1E, ensuring proper stewardship of public funds.

## Budget Process

### Annual Budget Development
- Department heads submit budget requests by {date}
- Finance reviews and consolidates by {date}
- CEO presents recommended budget to Board by {date}
- Board adopts budget by {date}

### Budget Monitoring
- Monthly budget-to-actual reports
- Variance analysis for items >10%
- Quarterly Board financial reports
- Annual audit

## Internal Controls

### Segregation of Duties
- Authorization, custody, and recording separated
- Dual signatures required for checks over ${amount}
- Bank reconciliations by non-check-signer

### Authorization Limits
- Department heads: Up to ${amount}
- CEO: Up to ${amount}
- Board approval required: Over ${amount}

## Grant Management

### Federal Grant Requirements
- Separate tracking of federal funds
- Compliance with grant terms
- Timely drawdown of funds
- Required reporting (FMIS, FFR)

### Cost Allocation
- Direct costs charged to specific grants
- Indirect costs allocated using approved methodology
- Documentation maintained for all costs

## Records Retention

Financial records will be retained for minimum of:
- Federal grant records: 3 years after final expenditure report
- Audit reports: Permanently
- Budget documents: 7 years
- Payment records: 7 years

## Audit Requirements

- Annual single audit (if expending $750K+ federal funds)
- Annual financial statement audit
- Grant-specific audits as required
- Management letter responses tracked to completion

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    },
    
    "eeo_plan": {
        "name": "EEO Affirmative Action Plan",
        "description": "Equal Employment Opportunity plan",
        "citation": "49 CFR Part 60 + FTA guidance",
        "template": """# Equal Employment Opportunity Affirmative Action Plan
## {agency_name}

**Effective Date:** {effective_date}
**Last Updated:** {current_date}

---

## EEO Policy Statement

{agency_name} is an Equal Opportunity Employer committed to providing employment opportunities without regard to race, color, religion, sex, national origin, age, disability, veteran status, or any other protected characteristic.

## Workforce Analysis

### Current Workforce Demographics

| Category | Total | % Minority | % Female |
|----------|-------|------------|----------|
| Officials/Managers | {count} | {pct}% | {pct}% |
| Professionals | {count} | {pct}% | {pct}% |
| Technicians | {count} | {pct}% | {pct}% |
| Service Workers | {count} | {pct}% | {pct}% |

### Availability Analysis

Relevant labor market demographics for {service_area}:
- Minority availability: {pct}%
- Female availability: {pct}%

## Utilization Analysis

Compare workforce demographics to availability:
- Identify areas of underutilization
- Set placement goals where underutilization exists
- Develop action-oriented programs

## Affirmative Action Programs

### Recruitment and Outreach
- Partner with minority-serving institutions
- Attend job fairs in diverse communities
- Advertise in minority and women-focused media
- Employee referral program

### Training and Development
- Leadership development programs
- Mentoring programs
- Tuition reimbursement
- Internal promotion opportunities

### Retention
- Competitive compensation and benefits
- Work-life balance programs
- Grievance procedures
- Exit interviews to identify issues

## Complaint Procedures

Employees who believe they have experienced discrimination may file a complaint with:

**EEO Officer**
{agency_name}
{address}
{phone}
{email}

Complaints will be investigated promptly and confidentially.

## Reporting

- Annual EEO-1 report filed with EEOC
- Annual report to Board on EEO efforts
- Workforce analysis updated annually

---

**Adopted by:** {agency_name} Board of Directors
**Date:** {current_date}
"""
    }
}


# ============================================================================
# Template Generator
# ============================================================================

def generate_template(template_name: str, variables: Optional[Dict] = None) -> Dict:
    """
    Generate an FTA compliance template.
    
    Args:
        template_name: Name of template (e.g., "title_vi_policy")
        variables: Dict of variable substitutions
        
    Returns:
        Dict with template content and metadata
        
    Example:
        >>> template = generate_template("title_vi_policy", {
        ...     "agency_name": "Charleston Transit",
        ...     "address": "123 Main St"
        ... })
        >>> print(template["content"][:200])
    """
    if template_name not in TEMPLATES:
        return {
            "success": False,
            "error": f"Template not found: {template_name}",
            "available_templates": list(TEMPLATES.keys())
        }
    
    template = TEMPLATES[template_name]
    
    # Default variables
    defaults = {
        "agency_name": "[Agency Name]",
        "address": "[Agency Address]",
        "phone": "[Phone Number]",
        "email": "[Email Address]",
        "effective_date": "[Effective Date]",
        "current_date": datetime.now().strftime("%B %d, %Y"),
    }
    
    # Merge with provided variables
    if variables:
        defaults.update(variables)
    
    # Substitute variables
    content = template["template"]
    for key, value in defaults.items():
        content = content.replace("{" + key + "}", str(value))
    
    return {
        "success": True,
        "template_name": template_name,
        "display_name": template["name"],
        "description": template["description"],
        "citation": template["citation"],
        "content": content,
        "word_count": len(content.split()),
        "generated_at": datetime.now().isoformat()
    }


def list_templates() -> Dict:
    """
    List all available templates.
    
    Returns:
        Dict with list of templates
        
    Example:
        >>> templates = list_templates()
        >>> for t in templates["templates"]:
        ...     print(f"{t['name']}: {t['description']}")
    """
    return {
        "success": True,
        "count": len(TEMPLATES),
        "templates": [
            {
                "name": key,
                "display_name": t["name"],
                "description": t["description"],
                "citation": t["citation"]
            }
            for key, t in TEMPLATES.items()
        ]
    }


# CLI interface
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("\n📋 Available FTA Templates:\n")
        result = list_templates()
        for i, t in enumerate(result["templates"], 1):
            print(f"{i}. {t['display_name']}")
            print(f"   {t['description']}")
            print(f"   Citation: {t['citation']}")
            print()
        sys.exit(0)
    
    template_name = sys.argv[1]
    result = generate_template(template_name)
    
    if result["success"]:
        print(f"\n✅ Template: {result['display_name']}")
        print(f"   Description: {result['description']}")
        print(f"   Citation: {result['citation']}")
        print(f"   Word count: {result['word_count']}")
        print(f"\n📄 Content:\n{result['content'][:500]}...")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)
