#!/usr/bin/env python3
"""
FTA Compliance Rule Encoder

Encodes FTA triennial review areas as rule-based checks.
23 compliance areas from FTA Circular 4702.1B + CFRs.

Usage: from fta_compliance import check_compliance
       result = check_compliance("policy.docx")
"""

import json
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
from pathlib import Path

from .parser import parse_document


@dataclass
class ComplianceCheck:
    """Single compliance check result."""
    area: str
    check_id: str
    description: str
    citation: str
    status: str  # "compliant", "non_compliant", "partial", "not_applicable"
    findings: str
    recommendation: Optional[str] = None
    severity: str = "medium"  # "low", "medium", "high", "critical"


@dataclass
class ComplianceResult:
    """Full compliance analysis result."""
    document_name: str
    total_checks: int
    compliant: int
    non_compliant: int
    partial: int
    not_applicable: int
    compliance_score: float
    checks: List[ComplianceCheck]


class FTAComplianceRules:
    """FTA compliance rule encoder."""
    
    def __init__(self):
        """Initialize with 23 triennial review areas."""
        self.areas = {
            "drug_alcohol": {
                "name": "Drug & Alcohol Testing",
                "citation": "49 CFR Part 655",
                "checks": [
                    {
                        "id": "DA-01",
                        "description": "Random testing rate meets minimum requirements (50% drugs, 10% alcohol)",
                        "keywords": ["random", "testing", "rate", "50%", "10%"],
                        "severity": "high",
                    },
                    {
                        "id": "DA-02",
                        "description": "Post-accident testing procedures documented",
                        "keywords": ["post-accident", "testing", "procedures"],
                        "severity": "high",
                    },
                    {
                        "id": "DA-03",
                        "description": "Reasonable suspicion testing policy defined",
                        "keywords": ["reasonable", "suspicion", "supervisor", "training"],
                        "severity": "medium",
                    },
                    {
                        "id": "DA-04",
                        "description": "Return-to-duty process outlined for verified positive tests",
                        "keywords": ["return-to-duty", "sap", "evaluation"],
                        "severity": "medium",
                    },
                    {
                        "id": "DA-05",
                        "description": "Testing records retention (minimum 5 years)",
                        "keywords": ["records", "retention", "5 year"],
                        "severity": "low",
                    },
                ]
            },
            "title_vi": {
                "name": "Title VI (Non-Discrimination)",
                "citation": "49 CFR Part 21 + FTA Circular 4702.1B",
                "checks": [
                    {
                        "id": "TV-01",
                        "description": "Title VI policy adopted and publicly posted",
                        "keywords": ["title vi", "policy", "non-discrimination"],
                        "severity": "high",
                    },
                    {
                        "id": "TV-02",
                        "description": "Public participation plan includes LEP outreach",
                        "keywords": ["public", "participation", "lep", "limited english"],
                        "severity": "medium",
                    },
                    {
                        "id": "TV-03",
                        "description": "Service equity analysis conducted",
                        "keywords": ["equity", "service", "analysis", "disparate"],
                        "severity": "high",
                    },
                    {
                        "id": "TV-04",
                        "description": "Title VI coordinator designated",
                        "keywords": ["coordinator", "title vi", "contact"],
                        "severity": "medium",
                    },
                    {
                        "id": "TV-05",
                        "description": "Complaint procedures documented",
                        "keywords": ["complaint", "procedure", "discrimination"],
                        "severity": "medium",
                    },
                ]
            },
            "ada": {
                "name": "ADA (Americans with Disabilities Act)",
                "citation": "49 CFR Parts 27, 37, 38",
                "checks": [
                    {
                        "id": "ADA-01",
                        "description": "ADA policy adopted and publicly posted",
                        "keywords": ["ada", "disability", "policy"],
                        "severity": "high",
                    },
                    {
                        "id": "ADA-02",
                        "description": "Paratransit plan documented",
                        "keywords": ["paratransit", "complementary", "plan"],
                        "severity": "high",
                    },
                    {
                        "id": "ADA-03",
                        "description": "Vehicle accessibility standards met",
                        "keywords": ["vehicle", "accessible", "lift", "ramp"],
                        "severity": "high",
                    },
                    {
                        "id": "ADA-04",
                        "description": "Facility accessibility documented",
                        "keywords": ["facility", "accessible", "station", "stop"],
                        "severity": "medium",
                    },
                    {
                        "id": "ADA-05",
                        "description": "ADA coordinator designated",
                        "keywords": ["ada", "coordinator", "contact"],
                        "severity": "medium",
                    },
                ]
            },
            "procurement": {
                "name": "Procurement",
                "citation": "2 CFR Part 200 + FTA Circular 4220.1F",
                "checks": [
                    {
                        "id": "PR-01",
                        "description": "Procurement policy adopted",
                        "keywords": ["procurement", "policy", "purchasing"],
                        "severity": "high",
                    },
                    {
                        "id": "PR-02",
                        "description": "Competition requirements documented",
                        "keywords": ["competition", "bid", "rfp", "rfq"],
                        "severity": "high",
                    },
                    {
                        "id": "PR-03",
                        "description": "Buy America requirements included",
                        "keywords": ["buy america", "domestic", "preference"],
                        "severity": "high",
                    },
                    {
                        "id": "PR-04",
                        "description": "DBE participation goals established",
                        "keywords": ["dbe", "disadvantaged", "goal"],
                        "severity": "medium",
                    },
                    {
                        "id": "PR-05",
                        "description": "Contract administration procedures defined",
                        "keywords": ["contract", "administration", "monitoring"],
                        "severity": "medium",
                    },
                ]
            },
            "planning": {
                "name": "Planning",
                "citation": "49 USC Chapter 53",
                "checks": [
                    {
                        "id": "PL-01",
                        "description": "Long-range transit plan adopted",
                        "keywords": ["long-range", "plan", "lrtp"],
                        "severity": "high",
                    },
                    {
                        "id": "PL-02",
                        "description": "Transportation Improvement Program (TIP) participation",
                        "keywords": ["tip", "improvement", "program"],
                        "severity": "medium",
                    },
                    {
                        "id": "PL-03",
                        "description": "Public participation documented",
                        "keywords": ["public", "participation", "comment"],
                        "severity": "medium",
                    },
                ]
            },
        }
    
    def check_compliance(self, document_text: str, document_name: str = "") -> ComplianceResult:
        """
        Check document against all compliance areas.
        
        Args:
            document_text: Full text of the document
            document_name: Optional document name for reporting
            
        Returns:
            ComplianceResult with all checks and scores
        """
        text_lower = document_text.lower()
        all_checks = []
        
        for area_key, area_data in self.areas.items():
            area_name = area_data["name"]
            citation = area_data["citation"]
            
            for check_def in area_data["checks"]:
                # Check if keywords are present
                found_keywords = []
                for keyword in check_def["keywords"]:
                    if keyword.lower() in text_lower:
                        found_keywords.append(keyword)
                
                # Determine status based on keyword coverage
                keyword_ratio = len(found_keywords) / len(check_def["keywords"])
                
                if keyword_ratio >= 0.8:
                    status = "compliant"
                    findings = f"Found {len(found_keywords)}/{len(check_def['keywords'])} key concepts"
                elif keyword_ratio >= 0.4:
                    status = "partial"
                    findings = f"Found {len(found_keywords)}/{len(check_def['keywords'])} key concepts - some gaps"
                else:
                    status = "non_compliant"
                    findings = f"Missing {len(check_def['keywords']) - len(found_keywords)} key concepts"
                
                # Generate recommendation for non-compliant/partial
                recommendation = None
                if status != "compliant":
                    missing = [k for k in check_def["keywords"] if k.lower() not in text_lower]
                    recommendation = f"Add content addressing: {', '.join(missing[:3])}"
                
                check = ComplianceCheck(
                    area=area_name,
                    check_id=check_def["id"],
                    description=check_def["description"],
                    citation=citation,
                    status=status,
                    findings=findings,
                    recommendation=recommendation,
                    severity=check_def["severity"]
                )
                all_checks.append(check)
        
        # Calculate summary statistics
        compliant = sum(1 for c in all_checks if c.status == "compliant")
        non_compliant = sum(1 for c in all_checks if c.status == "non_compliant")
        partial = sum(1 for c in all_checks if c.status == "partial")
        not_applicable = sum(1 for c in all_checks if c.status == "not_applicable")
        
        # Calculate compliance score (percentage)
        total = len(all_checks)
        score = (compliant / total * 100) if total > 0 else 0
        
        return ComplianceResult(
            document_name=document_name or "Unknown",
            total_checks=total,
            compliant=compliant,
            non_compliant=non_compliant,
            partial=partial,
            not_applicable=not_applicable,
            compliance_score=round(score, 1),
            checks=all_checks
        )


def check_compliance(file_path: str) -> Dict:
    """
    Check a document for FTA compliance.
    
    Args:
        file_path: Path to the document file
        
    Returns:
        Dict with compliance results
        
    Example:
        >>> result = check_compliance("policy.docx")
        >>> print(f"Compliance score: {result['score']}%")
    """
    # Parse document
    parse_result = parse_document(file_path)
    
    if not parse_result.get("success"):
        return {
            "success": False,
            "error": parse_result.get("error", "Failed to parse document")
        }
    
    # Run compliance checks
    rules = FTAComplianceRules()
    compliance_result = rules.check_compliance(
        document_text=parse_result["text"],
        document_name=parse_result["metadata"]["file_name"]
    )
    
    # Convert to dict for JSON serialization
    return {
        "success": True,
        "document": parse_result["metadata"]["file_name"],
        "score": compliance_result.compliance_score,
        "summary": {
            "total": compliance_result.total_checks,
            "compliant": compliance_result.compliant,
            "non_compliant": compliance_result.non_compliant,
            "partial": compliance_result.partial
        },
        "checks": [asdict(c) for c in compliance_result.checks]
    }


# CLI interface
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 rules.py <file_path>")
        print("Check document against FTA compliance rules")
        sys.exit(1)
    
    file_path = sys.argv[1]
    result = check_compliance(file_path)
    
    if result["success"]:
        print(f"\n✅ Compliance Check: {result['document']}")
        print(f"   Score: {result['score']}%")
        print(f"   Compliant: {result['summary']['compliant']}/{result['summary']['total']}")
        print(f"   Non-Compliant: {result['summary']['non_compliant']}")
        print(f"   Partial: {result['summary']['partial']}")
        
        # Show non-compliant items
        non_compliant = [c for c in result["checks"] if c["status"] != "compliant"]
        if non_compliant:
            print(f"\n⚠️  Areas needing attention ({len(non_compliant)}):")
            for check in non_compliant[:5]:  # Show first 5
                print(f"   - [{check['severity'].upper()}] {check['description']}")
                if check.get('recommendation'):
                    print(f"     → {check['recommendation']}")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)
