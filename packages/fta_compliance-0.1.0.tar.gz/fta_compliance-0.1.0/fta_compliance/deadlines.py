#!/usr/bin/env python3
"""
FTA Compliance Calendar Generator

Generates compliance deadline calendars for transit agencies.
Includes 21+ key deadlines for Tier II agencies.

Usage: from fta_compliance import generate_calendar
       calendar = generate_calendar(tier="tier_ii", year=2026)
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta


@dataclass
class ComplianceDeadline:
    """Single compliance deadline."""
    deadline_id: str
    name: str
    citation: str
    due_date: str
    frequency: str  # "annual", "quarterly", "monthly", "biennial", "triennial"
    tier: str  # "tier_i", "tier_ii", "all"
    description: str
    submission_to: str
    notes: Optional[str] = None


@dataclass
class ComplianceCalendar:
    """Full compliance calendar."""
    agency_tier: str
    year: int
    total_deadlines: int
    deadlines: List[ComplianceDeadline]
    quarterly_summary: Dict[str, int]
    high_priority: List[ComplianceDeadline]


# ============================================================================
# Deadline Database
# ============================================================================

DEADLINES = [
    # Drug & Alcohol Testing
    {
        "deadline_id": "DA-01",
        "name": "Annual Drug & Alcohol Testing Summary Report",
        "citation": "49 CFR Part 655",
        "due_month": 3,
        "due_day": 15,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Submit annual summary of drug and alcohol testing results to FTA",
        "submission_to": "FTA Regional Office",
        "notes": "Covers previous calendar year (Jan 1 - Dec 31)"
    },
    {
        "deadline_id": "DA-02",
        "name": "Random Testing Rate Report",
        "citation": "49 CFR Part 655",
        "due_month": 1,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Report random testing rates achieved for previous year",
        "submission_to": "FTA Regional Office",
        "notes": "Must achieve 50% drugs, 10% alcohol minimum"
    },
    
    # Title VI
    {
        "deadline_id": "TV-01",
        "name": "Title VI Program Update",
        "citation": "FTA Circular 4702.1B",
        "due_month": 6,
        "due_day": 30,
        "frequency": "triennial",
        "tier": "tier_ii",
        "description": "Submit updated Title VI program documentation",
        "submission_to": "FTA Regional Office",
        "notes": "Due every 3 years; check your cycle"
    },
    {
        "deadline_id": "TV-02",
        "name": "Service Equity Analysis",
        "citation": "FTA Circular 4702.1B",
        "due_month": 6,
        "due_day": 30,
        "frequency": "triennial",
        "tier": "tier_ii",
        "description": "Analyze service changes for disparate impacts",
        "submission_to": "FTA Regional Office",
        "notes": "Required when proposing major service changes"
    },
    {
        "deadline_id": "TV-03",
        "name": "Public Participation Plan Update",
        "citation": "FTA Circular 4702.1B",
        "due_month": 12,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Review and update public participation plan",
        "submission_to": "Internal (keep on file)",
        "notes": "Include LEP outreach updates"
    },
    
    # ADA
    {
        "deadline_id": "ADA-01",
        "name": "ADA Complaint Log Summary",
        "citation": "49 CFR Part 27",
        "due_month": 1,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Annual summary of ADA-related complaints",
        "submission_to": "FTA Regional Office",
        "notes": "Include resolution status"
    },
    {
        "deadline_id": "ADA-02",
        "name": "Paratransit Eligibility Review",
        "citation": "49 CFR Part 37",
        "due_month": 12,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Review all paratransit eligibility certifications",
        "submission_to": "Internal (keep on file)",
        "notes": "Recertify riders as needed"
    },
    
    # Procurement
    {
        "deadline_id": "PR-01",
        "name": "DBE Participation Report",
        "citation": "49 CFR Part 26",
        "due_month": 4,
        "due_day": 30,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Report DBE participation in federally funded contracts",
        "submission_to": "State DOT / FTA",
        "notes": "Include all contracts over $250,000"
    },
    {
        "deadline_id": "PR-02",
        "name": "Buy America Compliance Certification",
        "citation": "49 USC 5323(j)",
        "due_month": 12,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Certify compliance with Buy America requirements",
        "submission_to": "FTA Regional Office",
        "notes": "Cover all rolling stock and equipment purchases"
    },
    
    # Planning
    {
        "deadline_id": "PL-01",
        "name": "Long-Range Transit Plan Update",
        "citation": "49 USC Chapter 53",
        "due_month": 6,
        "due_day": 30,
        "frequency": "triennial",
        "tier": "tier_ii",
        "description": "Update 5-year long-range transit plan",
        "submission_to": "MPO / State DOT",
        "notes": "Coordinate with regional planning"
    },
    {
        "deadline_id": "PL-02",
        "name": "Transportation Improvement Program (TIP) Submission",
        "citation": "49 USC Chapter 53",
        "due_month": 9,
        "due_day": 30,
        "frequency": "biennial",
        "tier": "tier_ii",
        "description": "Submit projects for TIP inclusion",
        "submission_to": "MPO",
        "notes": "Even years only"
    },
    
    # Financial Management
    {
        "deadline_id": "FM-01",
        "name": "Single Audit (Form SF-SAC)",
        "citation": "2 CFR Part 200 Subpart F",
        "due_month": 6,
        "due_day": 30,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Submit Single Audit Reporting Collection form",
        "submission_to": "Federal Audit Clearinghouse",
        "notes": "If expending $750K+ federal funds"
    },
    {
        "deadline_id": "FM-02",
        "name": "Federal Financial Report (FFR)",
        "citation": "2 CFR Part 200",
        "due_month": 10,
        "due_day": 30,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Annual federal financial report for grants",
        "submission_to": "FTA (via TEAM)",
        "notes": "Covers federal fiscal year (Oct 1 - Sep 30)"
    },
    {
        "deadline_id": "FM-03",
        "name": "Financial Management Information System (FMIS) Update",
        "citation": "FTA Circular 5010.1E",
        "due_month": 1,
        "due_day": 15,
        "frequency": "quarterly",
        "tier": "tier_ii",
        "description": "Update financial data in FMIS",
        "submission_to": "FTA (via TEAM)",
        "notes": "Due within 15 days of quarter end"
    },
    
    # Safety (PTASP)
    {
        "deadline_id": "SF-01",
        "name": "Safety Performance Targets",
        "citation": "PTASP (49 USC 5329)",
        "due_month": 1,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Establish and report safety performance targets",
        "submission_to": "State DOT / FTA",
        "notes": "Board approval required"
    },
    {
        "deadline_id": "SF-02",
        "name": "Safety Management Plan Update",
        "citation": "PTASP (49 USC 5329)",
        "due_month": 12,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Review and update Safety Management Plan",
        "submission_to": "Internal (keep on file)",
        "notes": "Board approval required"
    },
    
    # Asset Management (TAM)
    {
        "deadline_id": "TAM-01",
        "name": "TAM Performance Targets",
        "citation": "49 CFR Part 625",
        "due_month": 10,
        "due_day": 1,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Establish transit asset management performance targets",
        "submission_to": "FTA (via NTD)",
        "notes": "Coordinate with MPO/State DOT"
    },
    {
        "deadline_id": "TAM-02",
        "name": "Asset Inventory Update",
        "citation": "49 CFR Part 625",
        "due_month": 12,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Update asset inventory and condition assessments",
        "submission_to": "Internal (keep on file)",
        "notes": "Required for TAM plan compliance"
    },
    
    # National Transit Database (NTD)
    {
        "deadline_id": "NTD-01",
        "name": "NTD Annual Report",
        "citation": "49 USC Chapter 53",
        "due_month": 5,
        "due_day": 15,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Submit annual operational and financial data",
        "submission_to": "FTA (via NTD)",
        "notes": "Covers previous fiscal year"
    },
    {
        "deadline_id": "NTD-02",
        "name": "NTD Monthly Ridership Report",
        "citation": "49 USC Chapter 53",
        "due_month": 1,
        "due_day": 31,
        "frequency": "monthly",
        "tier": "tier_ii",
        "description": "Submit monthly ridership data",
        "submission_to": "FTA (via NTD)",
        "notes": "Due by end of following month"
    },
    
    # EEO
    {
        "deadline_id": "EEO-01",
        "name": "EEO-1 Report",
        "citation": "49 CFR Part 60",
        "due_month": 9,
        "due_day": 30,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Submit Employer Information Report (EEO-1)",
        "submission_to": "EEOC",
        "notes": "If 100+ employees"
    },
    {
        "deadline_id": "EEO-02",
        "name": "Affirmative Action Plan Update",
        "citation": "49 CFR Part 60",
        "due_month": 3,
        "due_day": 31,
        "frequency": "annual",
        "tier": "tier_ii",
        "description": "Review and update EEO Affirmative Action Plan",
        "submission_to": "Internal (keep on file)",
        "notes": "Board approval recommended"
    },
]


# ============================================================================
# Calendar Generator
# ============================================================================

def generate_calendar(tier: str = "tier_ii", year: int = None) -> Dict:
    """
    Generate compliance calendar for specified tier and year.
    
    Args:
        tier: Agency tier ("tier_i", "tier_ii", or "all")
        year: Calendar year (defaults to current year)
        
    Returns:
        Dict with compliance calendar
        
    Example:
        >>> calendar = generate_calendar(tier="tier_ii", year=2026)
        >>> print(f"{calendar['total_deadlines']} deadlines in 2026")
    """
    if year is None:
        year = datetime.now().year
    
    # Filter deadlines by tier
    filtered = []
    for d in DEADLINES:
        if d["tier"] == tier or d["tier"] == "all":
            # Calculate due date for specified year
            due_month = d["due_month"]
            due_day = d["due_day"]
            
            # Handle month-end dates
            try:
                due_date = datetime(year, due_month, due_day)
            except ValueError:
                # Day doesn't exist in this month (e.g., Feb 30)
                if due_month == 2:
                    due_date = datetime(year, due_month, 28)
                else:
                    due_date = datetime(year, due_month, 30)
            
            deadline = ComplianceDeadline(
                deadline_id=d["deadline_id"],
                name=d["name"],
                citation=d["citation"],
                due_date=due_date.strftime("%Y-%m-%d"),
                frequency=d["frequency"],
                tier=d["tier"],
                description=d["description"],
                submission_to=d["submission_to"],
                notes=d.get("notes")
            )
            filtered.append(deadline)
    
    # Sort by due date
    filtered.sort(key=lambda x: x.due_date)
    
    # Calculate quarterly summary
    quarterly = {"Q1": 0, "Q2": 0, "Q3": 0, "Q4": 0}
    for d in filtered:
        month = int(d.due_date.split("-")[1])
        if month <= 3:
            quarterly["Q1"] += 1
        elif month <= 6:
            quarterly["Q2"] += 1
        elif month <= 9:
            quarterly["Q3"] += 1
        else:
            quarterly["Q4"] += 1
    
    # Identify high-priority (next 30 days)
    today = datetime.now()
    high_priority = [
        d for d in filtered
        if today <= datetime.strptime(d.due_date, "%Y-%m-%d") <= today + timedelta(days=30)
    ]
    
    calendar_result = ComplianceCalendar(
        agency_tier=tier,
        year=year,
        total_deadlines=len(filtered),
        deadlines=filtered,
        quarterly_summary=quarterly,
        high_priority=high_priority
    )
    
    # Convert to dict for JSON serialization
    return {
        "success": True,
        "agency_tier": tier,
        "year": year,
        "total_deadlines": calendar_result.total_deadlines,
        "quarterly_summary": calendar_result.quarterly_summary,
        "deadlines": [asdict(d) for d in calendar_result.deadlines],
        "high_priority": [asdict(d) for d in calendar_result.high_priority],
        "generated_at": datetime.now().isoformat()
    }


def get_upcoming_deadlines(tier: str = "tier_ii", days_ahead: int = 30) -> Dict:
    """
    Get deadlines due within specified days.
    
    Args:
        tier: Agency tier
        days_ahead: Number of days to look ahead
        
    Returns:
        Dict with upcoming deadlines
    """
    calendar = generate_calendar(tier=tier)
    today = datetime.now()
    cutoff = today + timedelta(days=days_ahead)
    
    upcoming = [
        d for d in calendar["deadlines"]
        if today <= datetime.strptime(d["due_date"], "%Y-%m-%d") <= cutoff
    ]
    
    return {
        "success": True,
        "count": len(upcoming),
        "days_ahead": days_ahead,
        "deadlines": upcoming
    }


# CLI interface
if __name__ == "__main__":
    import sys
    
    tier = "tier_ii"
    year = datetime.now().year
    
    if len(sys.argv) > 1:
        tier = sys.argv[1]
    if len(sys.argv) > 2:
        year = int(sys.argv[2])
    
    result = generate_calendar(tier=tier, year=year)
    
    if result["success"]:
        print(f"\n📅 FTA Compliance Calendar — {year}")
        print(f"   Tier: {result['agency_tier']}")
        print(f"   Total Deadlines: {result['total_deadlines']}")
        print(f"\n📊 Quarterly Summary:")
        for quarter, count in result["quarterly_summary"].items():
            print(f"   {quarter}: {count} deadlines")
        
        print(f"\n📋 Upcoming Deadlines:")
        for d in result["deadlines"][:10]:  # Show first 10
            print(f"   {d['due_date']} — {d['name']}")
            print(f"      → {d['submission_to']}")
        
        if result["high_priority"]:
            print(f"\n⚠️  HIGH PRIORITY (Next 30 Days): {len(result['high_priority'])}")
            for d in result["high_priority"]:
                print(f"   {d['due_date']} — {d['name']}")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)
