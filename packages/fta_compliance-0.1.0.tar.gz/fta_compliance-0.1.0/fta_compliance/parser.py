#!/usr/bin/env python3
"""
FTA Compliance Document Parser

Parses DOCX, PDF, and TXT files to extract text and metadata.
Used for compliance gap analysis.

Usage: from fta_compliance import parse_document
       result = parse_document("policy.docx")
"""

import os
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

# Try to import optional dependencies
try:
    from docx import Document
    DOCX_SUPPORT = True
except ImportError:
    DOCX_SUPPORT = False

try:
    from pypdf import PdfReader
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False


def parse_docx(file_path: str) -> Dict:
    """Parse DOCX file and extract text + metadata."""
    if not DOCX_SUPPORT:
        return {"error": "python-docx not installed. Run: pip install python-docx"}
    
    try:
        doc = Document(file_path)
        
        # Extract text
        paragraphs = []
        for para in doc.paragraphs:
            if para.text.strip():
                paragraphs.append(para.text)
        
        full_text = "\n\n".join(paragraphs)
        
        # Extract metadata
        metadata = {
            "file_path": str(file_path),
            "file_name": os.path.basename(file_path),
            "file_type": "docx",
            "file_size": os.path.getsize(file_path),
            "paragraph_count": len(paragraphs),
            "character_count": len(full_text),
            "parsed_at": datetime.now().isoformat()
        }
        
        return {
            "success": True,
            "metadata": metadata,
            "text": full_text,
            "format": "docx"
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "file_path": str(file_path)
        }


def parse_pdf(file_path: str) -> Dict:
    """Parse PDF file and extract text + metadata."""
    if not PDF_SUPPORT:
        return {"error": "pypdf not installed. Run: pip install pypdf"}
    
    try:
        reader = PdfReader(file_path)
        
        # Extract text from all pages
        pages = []
        for i, page in enumerate(reader.pages):
            text = page.extract_text()
            if text.strip():
                pages.append(f"[Page {i+1}]\n{text}")
        
        full_text = "\n\n".join(pages)
        
        # Extract metadata
        metadata = {
            "file_path": str(file_path),
            "file_name": os.path.basename(file_path),
            "file_type": "pdf",
            "file_size": os.path.getsize(file_path),
            "page_count": len(reader.pages),
            "character_count": len(full_text),
            "parsed_at": datetime.now().isoformat()
        }
        
        # Try to extract PDF metadata
        if reader.metadata:
            metadata["pdf_metadata"] = {
                "title": reader.metadata.get("/Title", ""),
                "author": reader.metadata.get("/Author", ""),
                "subject": reader.metadata.get("/Subject", ""),
                "creator": reader.metadata.get("/Creator", ""),
            }
        
        return {
            "success": True,
            "metadata": metadata,
            "text": full_text,
            "format": "pdf"
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "file_path": str(file_path)
        }


def parse_txt(file_path: str) -> Dict:
    """Parse TXT file and extract text + metadata."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            full_text = f.read()
        
        # Extract metadata
        metadata = {
            "file_path": str(file_path),
            "file_name": os.path.basename(file_path),
            "file_type": "txt",
            "file_size": os.path.getsize(file_path),
            "line_count": len(full_text.splitlines()),
            "character_count": len(full_text),
            "parsed_at": datetime.now().isoformat()
        }
        
        return {
            "success": True,
            "metadata": metadata,
            "text": full_text,
            "format": "txt"
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "file_path": str(file_path)
        }


def parse_document(file_path: str) -> Dict:
    """
    Parse a document (DOCX, PDF, or TXT) and extract text + metadata.
    
    Args:
        file_path: Path to the document file
        
    Returns:
        Dict with success status, metadata, and extracted text
        
    Example:
        >>> result = parse_document("policy.docx")
        >>> if result["success"]:
        ...     print(f"Parsed {result['metadata']['character_count']} characters")
        ...     print(result["text"][:200])  # First 200 chars
    """
    path = Path(file_path)
    
    if not path.exists():
        return {
            "success": False,
            "error": f"File not found: {file_path}"
        }
    
    # Determine file type and parse accordingly
    suffix = path.suffix.lower()
    
    if suffix == ".docx":
        return parse_docx(str(path))
    elif suffix == ".pdf":
        return parse_pdf(str(path))
    elif suffix in [".txt", ".md", ".text"]:
        return parse_txt(str(path))
    else:
        return {
            "success": False,
            "error": f"Unsupported file format: {suffix}. Supported: .docx, .pdf, .txt"
        }


# CLI interface
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 parser.py <file_path>")
        print("Supported formats: .docx, .pdf, .txt")
        sys.exit(1)
    
    file_path = sys.argv[1]
    result = parse_document(file_path)
    
    if result["success"]:
        print(f"✅ Parsed: {result['metadata']['file_name']}")
        print(f"   Format: {result['format']}")
        print(f"   Size: {result['metadata']['file_size']} bytes")
        print(f"   Characters: {result['metadata']['character_count']}")
        print(f"\n📄 First 500 characters:\n{result['text'][:500]}...")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)
