"""
FTA Compliance SaaS - Local-First Compliance Tools for Transit Agencies

A suite of tools for FTA compliance automation:
- Document parsing (DOCX, PDF, TXT)
- Compliance rule checking (23 FTA areas)
- Template generation (10 editable templates)
- Deadline calendar generation

All processing happens locally - no data leaves your system.

Author: Solutions by Vance, LLC
License: MIT
Version: 0.1.0
"""

__version__ = "0.1.0"
__author__ = "Solutions by Vance, LLC"

from .parser import parse_document
from .rules import check_compliance
from .templates import generate_template, list_templates
from .deadlines import generate_calendar, get_upcoming_deadlines

__all__ = [
    "parse_document",
    "check_compliance",
    "generate_template",
    "list_templates",
    "generate_calendar",
    "get_upcoming_deadlines",
]
