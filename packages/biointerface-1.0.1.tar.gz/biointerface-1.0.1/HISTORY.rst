=======
History
=======

1.0.0 (2026-04-03)
------------------

* ``InterfaceBuilder`` class builds everything, do not let ``Interface`` build anything anymore:
    * It extracts contacts and assign them to ``Interface``
    * It also builds binding domain, bound nucleic acids and bound double stranded nucleic acids
* Coherency with ``PDBNucleicAcids`` package: a single argument in a method for standard nucleotides


0.5.1 (2026-02-27)
------------------

* Forgot about documentation

0.5.0 (2026-02-27)
------------------

* Get nucleic acid binding domain from protein. With tests
* Fixed number of atoms features is defunct for now

0.4.0 (2025-04-16)
------------------

* Fixed number of atoms, either protein or DNA.


0.3.2 (2025-03-10)
------------------

* Fix: for getting bound double-strands, if one DSNA empties during trimming it raised error


0.3.1 (2025-03-05)
------------------

* Proper tests


0.3.0 (2025-03-05)
------------------

* Feature: get all continous protein-bound double-strand nucleic acids;


0.2.3 (2025-03-05)
------------------

* fix: bump-my-version was updating pdbnucleicacids version too

* fix: import classes instead of modules

* chore: remove old tox environments


0.2.2 (2025-03-04)
------------------

* Interface getter methods to get residues

* Interface raise error condition in case of no protein in the structure

* Coverage badge on README

* Full documentation


0.2.1 (2025-03-1)
------------------

* Gitlab CI


0.2.0 (2025-02-28)
------------------

* Features: Interface class, with getter methods for atoms, dataframes etc


0.1.0 (2025-02-08)
------------------

* First release on PyPI.

* Feature: interface as pandas dataframe
