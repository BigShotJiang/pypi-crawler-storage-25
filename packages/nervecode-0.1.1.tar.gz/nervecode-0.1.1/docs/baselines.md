# OOD Baselines

Nervecode benchmark outputs use one score convention: **higher score = more
OOD-like**. All result rows should also record `higher_is_ood=true`.

## MSP

- Method name: `msp`
- Formula: `score = 1 - max(softmax(logits))`
- Fit split: none
- Defaults: no temperature scaling
- Interpretation: low maximum softmax confidence gives a higher OOD score.

## Energy

- Method name: `energy`
- Formula: `score = -T * logsumexp(logits / T)`
- Fit split: none
- Defaults: `T=1.0`
- Interpretation: larger or less-negative energy is treated as more OOD-like.

## MaxLogit

- Method name: `maxlogit`
- Formula: `score = -logits.max(dim=-1).values`
- Fit split: none
- Defaults: no temperature scaling
- Interpretation: a lower winning logit gives a higher OOD score.

## GEN

- Method name: `gen`
- Formula: for sorted probabilities `p_(1) >= ... >= p_(C)`,
  `score = sum(p_(m)^gamma * (1 - p_(m))^gamma)` over the configured top-M set.
- Fit split: none
- Defaults: `gamma=0.1`, `top_m=None` for all classes
- Interpretation: near-uniform predictive distributions score higher than
  near-one-hot distributions. This is the OOD-oriented positive uncertainty
  form; do not apply the paper's ID-oriented negative sign in result tables.

## ODIN

- Method name: `odin`
- Formula: run a temperature-scaled forward pass, perturb the input by the sign
  of the confidence gradient, then score as `1 - max(softmax(logits2 / T))`.
- Fit split: none in this benchmark
- Defaults: `temperature=1000.0`, `eps=0.0014`
- Perturbation direction: `x_pert = x - eps * sign(grad_x(-log confidence))`
- Notes: ODIN parameters are fixed defaults here, not tuned on OOD data.

## Mahalanobis

- Method name: `mahalanobis`
- Formula: minimum squared Mahalanobis distance to any ID class mean.
- Fit split: ID train
- Feature layer: penultimate ResNet feature after global average pooling.
- Defaults: shared covariance, shrinkage `0.01`, pseudo-inverse solve.
- Requirements: ID train labels are required to fit class means.

## KNN-OOD

- Method name: `knn`
- Formula: distance to the kth nearest ID-train feature.
- Fit split: ID train
- Feature layer: penultimate ResNet feature after global average pooling.
- Defaults: L2-normalized features, `k=50`, query chunk size `4096`
- Notes: scoring is chunked so large test-by-train distance matrices are not
  allocated in one piece.

## Residual/ViM-Lite

- Method name: `residual_vim_lite`
- Formula: residual norm after projecting penultimate features onto the fitted
  ID principal subspace.
- Fit split: ID train
- Feature layer: penultimate ResNet feature after global average pooling.
- Defaults: top `100` principal axes, centered by the ID-train feature mean.
- Notes: this is not standard ViM because it reports only the residual norm and
  does not combine the residual with logits through the full ViM formulation.

## Nervecode

- Method names: `nervecode_mean`, `nervecode_max`
- Formula: aggregate per-layer Nervecode surprise with the selected aggregation.
- Fit split: model/codebooks on ID train; percentile calibration on ID
  calibration
- Defaults in the CIFAR CLI demo/full presets: `layers=last_block`, `agg=max`,
  `K=16`, `coding_dim=8`, `beta_length=1.0`, `beta_entropy=1.0`,
  `beta_distance=1.0`, assignment `temperature=1.0`. The `all_conv` selection
  remains available for smoke or overhead exploration, not as the default claim
  path.
