# Combo Ablation

This document defines the P4 `combo_id_zscore_equal` benchmark claim path.

Current checked-in release-grade CIFAR combo runs analyzed: **0**.

Honest conclusion: the ID-only combo ablation is implemented and auditable, but
there is not yet a checked-in scientific result showing that `E+M+N` improves
over the best two-component combo.

## Method

Components:

- `E`: Energy score.
- `M`: Mahalanobis feature-distance score.
- `N`: Nervecode aggregated surprise.

For every non-empty subset of `{E, M, N}`, the benchmark fits mean and standard
deviation on ID calibration scores only, converts each component to a z-score,
and averages the selected z-scores with fixed equal weights. Higher remains more
OOD-like. OOD samples are not used for normalization or weighting.

The full `{E, M, N}` row is named `combo_id_zscore_equal`. Proper subsets are
named with their component label, for example `combo_id_zscore_equal_E+M`.

## Current Numbers

| Method | Rows | AUROC mean | AUROC std | AUPR-OUT mean | FPR@95 mean |
|---|---:|---:|---:|---:|---:|
| `combo_id_zscore_equal_E` | 0 | n/a | n/a | n/a | n/a |
| `combo_id_zscore_equal_M` | 0 | n/a | n/a | n/a | n/a |
| `combo_id_zscore_equal_N` | 0 | n/a | n/a | n/a | n/a |
| `combo_id_zscore_equal_E+M` | 0 | n/a | n/a | n/a | n/a |
| `combo_id_zscore_equal_E+N` | 0 | n/a | n/a | n/a | n/a |
| `combo_id_zscore_equal_M+N` | 0 | n/a | n/a | n/a | n/a |
| `combo_id_zscore_equal` | 0 | n/a | n/a | n/a | n/a |

## Interpretation

- E+M+N vs best two-component combo: not measured in checked-in release-grade
  results.
- CIFAR-100-like near-OOD: not measured in checked-in release-grade results.
- Seed consistency: not measured. With 3 seeds, report mean, std, and per-seed
  deltas only. With 5 or more seeds, add the paired bootstrap interval emitted
  by `scripts/combo_report.py`.
- Nervecode value as standalone vs complementary signal: not measured in
  checked-in release-grade results.

Generate this report from a completed benchmark run with:

```bash
python3 scripts/combo_report.py runs/<run_id>/results.csv --output docs/combo.md
```

## Oracle Appendix

Rows named `oracle_ood_calibrated_combo_*` are not headline detector results.
They use evaluated OOD samples for fitting combiner weights and belong only in
appendix tables with provenance metadata. The README and release notes must not
headline oracle-combo numbers.
