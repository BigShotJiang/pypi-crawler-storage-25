# Diagnostics and Interpretation Guide

This guide explains the core diagnostics Nervecode exposes and how to read them
when instrumenting layers and calibrating out-of-distribution (OOD) behavior.

The signals fall into two groups:
- Per-layer, latest-trace diagnostics computed by wrappers (observe-only).
- Per-sample, aggregated surprise with empirical percentile calibration and
  threshold-based OOD flags.


## Per-layer diagnostics (latest trace)

Wrappers cache the most recent `CodingTrace` and expose convenience helpers via
`BaseCodingWrapper`:

- `utilization() -> float | None`
  - Fraction of codebook entries that were selected at least once in the latest
    trace. Computed as the number of unique best indices divided by `K`.
  - Interpretation:
    - Close to 1.0: many codes are active for the current batch/shape.
    - Close to 0.0: few codes are chosen; may indicate collapse, a too-cold
      temperature, an oversized codebook, or a degenerate reducer.
    - Batch- and data-dependent: low utilization on a tiny batch can be normal.

- `mean_entropy() -> float | None`
  - Mean assignment entropy of the soft code across all positions in the latest
    trace. Entropy is computed as `-sum_k p_k log(p_k + eps)` and reported in
    nats.
  - Interpretation:
    - Low entropy (≈ 0): sharp, confident assignments to a single code.
    - Higher entropy: diffuse assignments across codes; can be desirable early
      in training or when modeling ambiguity, but persistent high entropy with a
      large codebook can hurt separability.
    - Temperature directly affects entropy: higher temperature → higher entropy.

- `mean_code_length() -> float | None`
  - Mean best-code codelength in nats, defined as `-log(p_best + eps)` where
    `p_best` is the probability of the chosen (minimum-distance) code per
    position.
  - Interpretation:
    - Lower is better (more confident). `0.0` corresponds to `p_best=1.0`.
    - Roughly tracks the negative log-likelihood of the top assignment.
    - Convert to bits by dividing by `ln(2)` if you prefer base‑2 units.

- `mean_commitment_distance() -> float | None`
  - Mean nearest-center squared Euclidean distance per position. This measures
    how far activations sit from their closest codebook center (lower is
    better). It is the same scalar used by the optional commitment term in the
    training loss.
  - Interpretation:
    - Large values: activations are far from the learned centers; can indicate
      under-trained codebooks, a poor reducer, or a mismatch between
      `coding_dim` and the underlying layer width.
    - Scale depends on activation magnitude; compare relatively across steps or
      layers rather than in absolute terms.

Notes
- All helpers return `None` when no valid latest trace is available (fail‑open).
- Diagnostics summarize only the most recent forward pass; for robust logging
  in concurrent settings, request explicit traces and compute summaries on
  those objects.


## Aggregated surprise and calibration

Across wrapped layers, Nervecode aggregates per-position surprise into a
per-sample vector (mean or max aggregation) and exposes simple, empirical
calibration utilities.

- Aggregated surprise
  - Produced by `nervecode.scoring.mean_surprise(...)` or
    `nervecode.scoring.max_surprise(...)` or
    `WrappedModel.surprise()` as an `AggregatedSurprise` object with a
    per‑sample `surprise` tensor.
  - Per-position surprise combines up to three components:
    - best-code codelength L = -log(p_best + eps)
    - assignment entropy H = -∑ p_k log(p_k + eps)
    - optional distance term D ≈ log1p(nearest-center squared distance)
  - The combined surprise is S = βL·L + βH·H + βD·D. Set βD > 0 to penalize
    “far but confident” activations. The sample-level score is typically the
    mean across participating layers (with a max alternative available).

- Empirical percentiles
  - `EmpiricalPercentileCalibrator.fit(scores)` stores a sorted in‑distribution
    surprise vector and configured threshold quantiles.
  - `percentiles(x)` maps any score `x` to its empirical CDF value in `[0, 1]`
    via `# {v <= x} / n` against the stored distribution; shapes are preserved.
  - Interpretation:
    - Values near 0.5 fall around the in‑distribution median.
    - Values near 0.9–0.99 indicate unusually high surprise relative to
      calibration data and are common thresholds for OOD decisions.

- Threshold-based OOD flags
  - `is_ood(x, quantile=q)` returns a boolean mask using the rule
    `percentile(x) >= q`. When a single `q` was configured at fit time, it can
    be omitted in calls.
  - Choosing `q`:
    - Target OOD rate on in‑distribution data is approximately `1 - q` by
      construction (e.g., `q=0.95` → ~5% flagged). Validate this holds with a
      held‑out in‑distribution split.
    - Higher `q` reduces false positives but may increase false negatives on
      shifted data; select based on your tolerance and monitoring goals.

Practical tips
- Always calibrate on a representative, held‑out in‑distribution set; mixing in
  shifted data biases percentiles and thresholds.
- Track both raw scores and percentiles during development; percentiles make
  runs comparable across models and training checkpoints.
- When investigating OOD decisions, inspect per-layer contributions and
  layer‑level diagnostics alongside the aggregated score.
 - If percentile thresholding looks degenerate (ID/OOD medians near zero but
   AUROC is high), enable the distance term by setting βD in your harness
   (e.g., 0.2–1.0). This lifts OOD scores above ID across the bulk, improving
   threshold behavior. A mild temperature increase (e.g., 1.5–2.0) can also
   help by raising entropy.
