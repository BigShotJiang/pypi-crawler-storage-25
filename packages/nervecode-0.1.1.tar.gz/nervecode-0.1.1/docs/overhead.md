# Pooled Conv2d Coding Overhead

This note summarizes the expected compute and memory overhead of the pooled
convolutional coding path used by `CodingConv2d`. It combines deterministic
estimates with a simple timing harness you can run locally. For the design
rationale behind choosing pooled coding as the first Conv2d mode, see
`docs/architecture.md`.

Summary
- Compute: The pooled‑coding path adds a small constant‑factor cost on top of a
  Conv2d forward. For typical 3×3 convolutions, the MAC ratio
  `(coding / conv)` is usually well under 10% and often in the low single
  digits for realistic spatial sizes.
- Memory: Parameter overhead is `K * D` for codebook centers plus an optional
  `C_out * D` projection when `D < C_out`. Transient activation overhead per
  batch is `(B * D + B * K)` float elements (pooled vector and soft code).

Deterministic estimates
- See `nervecode.utils.overhead.estimate_pooled_conv_overhead`.
- Inputs: batch size `B`, spatial size, conv hyper‑params, coding dimension
  `D` (defaults to `C_out`), and codebook size `K`.
- Outputs: baseline Conv2d MACs, coding MACs (broken down), parameter and
  activation overhead, and the compute‑overhead ratio.

Example (32×32 RGB, 3×3 conv 3→8, B=32, D=8, K=16):
- Baseline conv MACs ≈ 7.1M
- Coding MACs ≈ 0.27M (pool 0.26M, codebook ≈ 0.008M, softmax ~negligible)
- Ratio ≈ 3.8%
- Params: codebook = 16×8 = 128
- Activations per batch: `(B*D + B*K) = 32*(8 + 16) = 768` floats

Timing harness
- `benchmarks/overhead/conv_overhead.py` runs a tiny CNN with and without
  pooled coding and reports per‑iteration timings. On CUDA it also prints a
  rough GPU memory delta after instrumentation.

Operating limits (practical guidance)
- Favor `D ≤ C_out` and modest `K` (e.g., 16–64). Both compute and memory
  scale linearly in `D` and `K`.
- Spatial size indirectly affects cost via the global‑average pool — still a
  low‑order term compared to the convolution itself for common kernels.
- Batch size scales transient activation memory linearly via `(B * (D + K))`.
  If memory is tight, reduce batch or `K` first; lowering `D` also helps,
  especially when a projection is used.
- Very small convolutions (e.g., 1×1 with tiny channels) can make the coding
  ratio appear larger because the baseline conv work is small; the absolute
  cost remains modest.

Reproducibility notes
- Estimates are device‑independent and deterministic by design.
- Timings depend on hardware, BLAS/cuDNN kernels, and cache effects; prefer
  ratios over raw milliseconds when comparing configurations.
