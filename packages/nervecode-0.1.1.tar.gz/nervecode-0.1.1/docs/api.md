# Public API Reference (MVP)

This page documents the first public surface of Nervecode's MVP. The focus is a
small, predictable set of entry points you can rely on when integrating the
library into an existing PyTorch codebase.

The API is intentionally observe‑only: wrappers never change a model’s returned
values. Surprise scoring and calibration run side‑by‑side and expose results via
explicit objects and a couple of convenience helpers.


## wrap(...)

- Location: `nervecode.wrap` (convenience alias)
- Underlying helper: `nervecode.layers.wrap.wrap`

Instrument a PyTorch `nn.Module` in‑place by wrapping selected layers with
coding modules.

Signature:

```python
import nervecode as nvc
nvc.wrap(model, *, layers: str | Iterable[str] = "all_linear") -> nvc.WrappedModel
```

Behavior and selection:
- `layers="all_linear"`: instrument every `nn.Linear` with `CodingLinear`.
- `layers="all_conv"`: instrument every `nn.Conv2d` with `CodingConv2d`.
- `layers=["dotted.name", ...]`: instrument explicit submodules by their dotted
  names (as returned by `model.named_modules()`), skipping unknown names.
- Unsupported layer types are left as‑is (fail‑open).
- Returns the same model instance for convenience.

Example:

```python
model = MyModel()
wrapped = nvc.wrap(model, layers="all_linear")  # in-place instrumentation + container
```


## WrappedModel

- Location: `nervecode.WrappedModel`

A thin container that keeps the original model API intact while tracking coding
wrappers and providing convenience helpers for training and inference‑time
scoring.

Key methods (MVP):
- `forward(*args, **kwargs) -> Any`
  - Delegates to the wrapped model’s forward and updates internal caches with
    the latest per‑layer traces when coding is active.
- `coding_loss() -> torch.Tensor`
  - Computes a scalar auxiliary loss from the latest per‑layer traces using
    `nervecode.training.CodingLoss`. Raises a helpful error when no usable
    traces are present.
- `surprise() -> AggregatedSurprise | None`
  - Aggregates the most recent per‑layer surprise signals into a per‑sample
    vector using mean aggregation. Returns `None` when no valid signals are
    present.
- `enable_coding() / disable_coding()`
  - Toggle coding across all discovered wrapped layers. Disabling coding also
    clears any cached per‑layer traces immediately so that model‑level helpers
    (e.g., `surprise()`) reflect the disabled state without requiring another
    forward pass.
- `bypass()`
  - Context manager that temporarily bypasses coding across all wrapped layers.

Example:

```python
import torch
from torch import nn
import nervecode as nvc

model = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 2))
wrapped = nvc.wrap(model, layers="all_linear")

x = torch.randn(8, 2)
logits = wrapped(x)
loss = task_loss(logits, y) + 0.1 * wrapped.coding_loss()
agg = wrapped.surprise()  # per-sample aggregated surprise
if agg is not None:
    scores = agg.surprise
```


## CodingLinear

- Location: `nervecode.layers.linear.CodingLinear`
- Wraps: `torch.nn.Linear`

Observe‑only wrapper that computes a coding trace over the layer’s output and
stores it internally for later aggregation and loss. The visible forward output
is identical to the underlying `nn.Linear`.

Constructor (selected args):
- `layer`: the `nn.Linear` to wrap.
- `K`: codebook size (default: 16).
- `coding_dim`: coding‑space dimension. Defaults to `out_features`; if set to a
  smaller value, a learned projection reducer is used internally for coding
  while preserving the visible output.
- `temperature`, `eps`: soft‑assignment parameters.

Methods:
- `forward(x) -> y`: returns the original layer output; updates the cached trace
  when coding is active.
- `forward_with_trace(x) -> (y, CodingTrace | None)`: explicit output + trace.
- `enable_coding() / disable_coding() / bypass()`: shared wrapper controls. When
  disabled, any cached latest trace is cleared immediately.

Assignment weights:
- Each `CodingLinear` has an `assignment` module controlling soft assignment and
  the combined surprise formula. You can adjust weights at runtime:

```python
m.assignment.beta_length = 1.0     # weight on best-code codelength (default 1.0)
m.assignment.beta_entropy = 0.0    # weight on entropy (default 1.0)
m.assignment.beta_distance = 0.0   # weight on distance term (default 0.0)
```

The combined per-position surprise is `S = βL·L + βH·H + βD·D` where `D ≈
log1p(nearest-center squared distance)`. Enable a non-zero `βD` to penalize
"far but confident" activations and improve percentile thresholding on some
OOD tasks.


## CodingLoss

- Location: `nervecode.training.CodingLoss`

Training‑time auxiliary loss that reads existing `CodingTrace`/`SoftCode`
objects (or per‑sample tensors) and returns a scalar. It avoids recomputation by
consuming the per‑position surprise already stored on the `SoftCode`.

Constructor:
- `CodingLoss(assign_weight=1.0, commit_weight=0.0)`
  - `assign_weight`: weight for the assignment/sharpness term derived from
    per‑position surprise (aggregated via mean across layers and samples).
  - `commit_weight`: optional weight for the mean nearest‑center distance term
    derived from `CodingTrace.commitment_distances`.

Call:
- `__call__(traces) -> torch.Tensor`
  - Accepts a single trace/object, an iterable, or a mapping of layer names.
  - Reduces per-layer signals to a per-sample view, averages across layers, then
  averages across the batch.


## Experimental Updaters

- Location: `nervecode.training.EmaCodebookUpdater`

Optional, off-by-default helper to update codebook centers using an exponential
moving average of batch-weighted means computed from a `CodingTrace`. The default
and recommended baseline remains standard gradient-based training via `CodingLoss`.

Constructor:
- `EmaCodebookUpdater(codebook, decay=0.99, assignment="soft", eps=1e-12)`
  - `codebook`: the `Codebook` instance to update in place.
  - `decay`: EMA decay in `[0, 1)`. `0` uses the current batch only.
  - `assignment`: `"soft"` to use soft probabilities or `"hard"` for one‑hot
    argmax assignments.

Methods:
- `update_from_trace(trace) -> None`
  - Consumes a `CodingTrace` produced by the same codebook and updates centers
    under `torch.no_grad()`; plays well with gradient updates for hybrid usage.


## Aggregated Surprise

- Type: `nervecode.scoring.AggregatedSurprise`
- Produced by: `nervecode.scoring.mean_surprise(...)`, `nervecode.scoring.max_surprise(...)`, and `WrappedModel.surprise()`

Result object for per‑sample surprise aggregated across wrapped layers.

Fields:
- `surprise`: per‑sample aggregated signal (typically a `torch.Tensor` with
  shape `(B,)` or similar).
- `method`: aggregation method identifier (e.g., `"mean"`, `"max"`).
- `num_layers`: number of layer signals included in the aggregation.
- `details`: optional method‑specific extras.

Helpers:
- `mean_surprise(traces) -> AggregatedSurprise | None`
  - Accepts a mapping/iterable of `CodingTrace`, `SoftCode`, or per‑sample
    tensors. Reduces each to a sample‑level view and averages across layers.
- `max_surprise(traces) -> AggregatedSurprise | None`
  - Same inputs and reduction, but combines layer signals using a max across
    layers instead of a mean.
- `weighted_surprise(traces, *, weights, normalize=True) -> AggregatedSurprise | None`
  - Fixed weighted aggregation across layers. Accepts a mapping of layer names
    to weights when `traces` is a mapping, or an iterable of weights aligned to
    the sequence order. By default, divides by the sum of included weights
    (`normalize=True`). This function does not learn weights.


## Calibrator

- Class: `nervecode.scoring.EmpiricalPercentileCalibrator`
- State: `nervecode.scoring.CalibrationState`

Collects an empirical distribution of aggregated surprise on in‑distribution
samples and provides percentile lookups and threshold decisions.

Constructor:
- `EmpiricalPercentileCalibrator(threshold_quantiles: Sequence[float] = (0.95,))`

Key methods:
- `fit(scores, *, aggregation: str | None = None) -> CalibrationState`
  - Accepts a per‑sample tensor, an object with a `surprise` tensor attribute,
    or an iterable of numbers. Stores the sorted distribution and threshold(s).
- `threshold_for(quantile: float | None = None) -> torch.Tensor`
  - Returns the threshold value at a configured quantile. When only one
    quantile was configured, `quantile` may be omitted.
- `percentiles(scores) -> torch.Tensor`
  - Maps scores to empirical percentiles in `[0, 1]` using the stored
    distribution; shape matches the input.
- `is_ood(scores, *, quantile: float | None = None) -> torch.Tensor`
  - Returns a boolean mask where inputs are flagged OOD (percentile ≥ quantile).

Persistence:
- `state_dict() -> dict`: returns a versioned dictionary with configured quantiles and fitted state.
- `load_state_dict(d: dict) -> None`: restores configuration and state.
- `save(path: str) -> None` / `load(path: str) -> EmpiricalPercentileCalibrator`: convenience disk I/O helpers using `torch.save`/`torch.load`.

Example:

```python
from nervecode.scoring import EmpiricalPercentileCalibrator, mean_surprise

# Aggregate per-batch surprise vectors across calibration data
scores = []
for xb, _ in calib_loader:
    _ = wrapped.forward(xb)
    agg = wrapped.surprise() or mean_surprise(wrapped._last_layer_traces)
    if agg is not None:
        scores.append(agg.surprise.detach().cpu())

calib = EmpiricalPercentileCalibrator(threshold_quantiles=(0.95,))
state = calib.fit(torch.cat(scores), aggregation="mean")
thr = calib.threshold_for()  # single configured quantile
p = calib.percentiles(state.sorted_surprise[-5:])
```


## Notes and Gotchas

- Observe‑only contract: wrappers never alter model outputs. Use explicit trace
  objects for programmatic integrations when you need deterministic data flow.
- Mutable caches: `WrappedModel.surprise()` reflects the last forward pass only.
  For concurrent or interleaved usage, prefer explicit trace returns and
  `mean_surprise(...)` on those traces.
- Advanced instrumentation: `nervecode.layers.wrap.wrap(...)` is the underlying
  in-place helper used by `nervecode.wrap(...)`. Most users should prefer the
  top-level API because it also returns a `WrappedModel` container.


## Diagnostics Logging (CSV/JSONL)

- Types: `nervecode.training.DiagnosticsCollector`, `CsvDiagnosticsLogger`, `JsonlDiagnosticsLogger`
- Purpose: Turn the latest per-layer `CodingTrace` objects into simple rows and append them to CSV or JSONL. Useful during training/calibration for quick inspection and lightweight logging.

Example:

```python
from nervecode.training import DiagnosticsCollector, CsvDiagnosticsLogger

collector = DiagnosticsCollector()
csv = CsvDiagnosticsLogger("runs/diagnostics.csv")

# inside your training loop, after a forward
rows = collector.collect(getattr(wrapped, "_last_layer_traces", {}))
if rows:
    csv.log(rows)
```


## Combined Surprise Weights

The internal assignment engine computes a weighted combined surprise per position:

`S = beta_length * best_code_length + beta_entropy * entropy`

Defaults use `beta_length = 1.0`, `beta_entropy = 1.0` for a simple balanced signal. Advanced users may construct `nervecode.core.assignment.SoftAssignment(…, beta_length=…, beta_entropy=…)` directly (e.g., for custom wrappers or research) to adjust the mix. Library wrappers use reasonable defaults.
