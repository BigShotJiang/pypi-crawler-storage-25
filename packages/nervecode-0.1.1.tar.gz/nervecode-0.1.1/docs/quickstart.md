# Quickstart

This guide walks you through the intended first‑run experience with Nervecode:

- Wrap a tiny PyTorch model with observe‑only coding layers.
- Train with your normal task loss plus a small coding loss.
- Calibrate an empirical percentile threshold on held‑out in‑distribution data.
- Run inference and read both raw surprise and calibrated percentiles.

If you prefer to just run something end‑to‑end, execute the example script:

```
python examples/quickstart_mlp.py
```

Tip: set `NERVECODE_QUICKSTART_FAST=1` to encourage faster example settings if supported.


## Prerequisites
- Python 3.10+
- PyTorch 2.0+ (CPU is fine; install from pytorch.org for your platform)
- Install Nervecode from a checkout: `pip install -e .`
- For development and docs/tests: `pip install -e '.[dev]'`
- For source-checkout benchmark scripts: `pip install -e '.[benchmark,viz]'`


## Step 1 — Build and instrument a tiny model
Use the top-level `nervecode.wrap(...)` helper to instrument selected layers
in-place and return a thin `WrappedModel` container for training and inference.

```python
import torch
from torch import nn
import nervecode as nvc

model = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 2))
wrapped = nvc.wrap(model, layers="all_linear")  # observe-only wrappers + container
```

The wrappers do not change the model’s returned outputs. They only compute and
cache coding traces alongside the normal forward pass when coding is enabled.


## Step 2 — Train with task loss + coding loss
Add the scalar coding loss to your usual objective. It is computed from the
latest per‑layer traces to avoid extra recomputation.

```python
x = torch.randn(64, 2)
y = torch.randint(0, 2, (64,))
logits = wrapped(x)
loss = nn.CrossEntropyLoss()(logits, y) + 0.1 * wrapped.coding_loss()
loss.backward()
```

You can continue to use your existing optimizer and training loop structure.


## Step 3 — Calibrate empirical percentiles (in‑distribution)
Collect aggregated surprise on a held‑out split of in‑distribution samples, then
fit an empirical calibrator that provides percentiles and threshold lookups.

```python
from nervecode.scoring import EmpiricalPercentileCalibrator, mean_surprise

with torch.no_grad():
    _ = wrapped(torch.randn(64, 2))
    agg = wrapped.surprise() or mean_surprise(getattr(wrapped, "_last_layer_traces", {}))
scores = agg.surprise  # per-sample vector (B,)

calib = EmpiricalPercentileCalibrator(threshold_quantiles=(0.95,))
state = calib.fit(scores, aggregation="mean")
thr = calib.threshold_for()  # threshold at 95th percentile

# Optional: persist the calibrator for reuse later
calib.save("runs/quickstart_calibrator.pt")
# ... later or in a separate process
calib2 = EmpiricalPercentileCalibrator.load("runs/quickstart_calibrator.pt")
```

Store `state` (and your model weights) to reproduce decisions later.


## Step 4 — Inference: read surprise, percentiles, and OOD flags
At inference time, run a forward pass, grab the latest aggregated surprise, then
map it to percentiles and thresholded OOD flags.

```python
with torch.no_grad():
    _ = wrapped(x_test)
    agg = wrapped.surprise()
    if agg is not None:
        s = agg.surprise                  # raw per-sample surprise
        p = calib.percentiles(s)          # [0, 1] percentiles
        ood = calib.is_ood(s)             # boolean mask at configured quantile
```


## What the example script prints
`examples/quickstart_mlp.py` runs this full flow on a tiny synthetic dataset. You
should see:
- Training progress with an average loss per epoch.
- A one‑line calibration summary with the chosen quantile(s) and threshold value.
- A few test samples showing raw surprise, percentile, and whether they were
  flagged as OOD under the configured threshold.


## Next steps
- CNN variant: see `examples/quickstart_cnn.py` where pooled Conv2d coding feeds
  the aggregated surprise signal.
- Minimal training harness: `scripts/train_minimal.py` for a dataset‑agnostic,
  CPU‑friendly smoke run of training + calibration.
- OOD benchmark: `benchmarks/ood/simple.py` for a minimal AUROC sanity check on
  an MLP with synthetic OOD.
- API reference: `docs/api.md` for the public entry points (`wrap`,
  `WrappedModel`, `CodingLoss`, the calibrator, and the aggregated surprise helpers).
- Interpreting signals: `docs/diagnostics.md` for code utilization, entropy,
  code length, commitment distance, empirical percentiles, and threshold flags.

Benchmark scripts are source-checkout research tools rather than installed
wheel API. Use `python -m benchmarks.ood.cifar_resnet18 --preset demo` from a
checkout for a short smoke run, and use the JSON configs in `configs/v0_1_1/`
for v0.1.1 benchmark reproduction.

## Recommended OOD settings
- Selection: `layers=first_linear`
- Aggregation: `agg=max`
- Coding: `coding_dim D=8`, `K=16`
- Assignment weights: `βL=1.0`, `βE=1.0`, `βD=1.0`
- Calibration: `quantile q=0.90` (or `0.95` for stricter ID control)

Example CLI on the toy MLP:

```
python -m benchmarks.ood.simple --epochs 20 --device cpu \
  --agg max --layers first_linear --K 16 --coding-dim 8 \
  --beta-length 1.0 --beta-entropy 1.0 --beta-distance 1.0 \
  --quantile 0.90 --json
```

To iterate quickly, use the matrix script FAST profile:

```
FAST=1 bash scripts/run_ood_matrix.sh
```


## Troubleshooting
- Import or install errors: ensure PyTorch is installed for your platform and
  that you are running inside the environment where you installed Nervecode.
- GPU not required: everything here runs on CPU by default.
- No surprise returned: if `wrapped.surprise()` is `None`, ensure coding is
  enabled and that a wrapped forward pass has happened; you can also aggregate
  explicitly via `mean_surprise(wrapped._last_layer_traces)`.

Tip: You can log per-layer diagnostics (utilization, entropy, etc.) to CSV with
`DiagnosticsCollector` and `CsvDiagnosticsLogger`. See `docs/api.md` for a short snippet.
