# Architecture Guardrails

This note states the non‑negotiable design rules for Nervecode’s MVP. These are
hard constraints that shape every API and implementation choice.

- Observe‑only wrappers
  - Wrappers must not change numerical outputs of the base model. They may observe,
    reduce, or record activations, but forward() returns must be identical to the
    unwrapped model for the same inputs and state.
- Fail‑open behavior
  - Any instrumentation failure (unsupported layer, disabled context, missing optional
    deps) must gracefully bypass coding and return base outputs rather than raising in
    user flows.
- Selected‑layer instrumentation
  - Only explicitly selected layers are instrumented (e.g., all linear for MVP).
    No implicit global hooks. Selection must be opt‑in and predictable.
- Explicit trace support
  - Provide an explicit trace‑returning path (e.g., forward_with_trace) that yields
    machine‑readable per‑layer traces and summary stats for robust integrations.
  - Model‑level convenience caches (e.g., ``WrappedModel.surprise()``) reflect
    last‑forward state only. Prefer explicit traces in concurrent‑looking or
    interleaved usage patterns to avoid reading mutable state out of order.
- MVP‑first scope control
  - Keep scope tight: squared‑Euclidean assignment, pooled reductions where needed,
    minimal dependencies, and baseline calibration. Defer non‑essentials until after
    validation of the core surprise signal.

These guardrails ensure integrations remain safe, debuggable, and incremental while the
coding primitives and calibration stabilize.

## Why Pooled Conv2d First

The first convolutional wrapper (`CodingConv2d`) deliberately uses a pooled
representation (global average over H×W by default) rather than coding each
spatial position. This choice aligns with the MVP guardrails:

- Simplicity and safety
  - Preserve the observe-only contract with a stable, sample-level view that
    mirrors the linear wrapper: `(B, C_out) → (B, D)` for coding while the
    visible conv output remains unchanged.
- Uniform aggregation and calibration
  - The scoring pipeline and calibrator operate on per-sample signals. A pooled
    representation plugs into the existing mean aggregation and empirical-percentile
    calibration without introducing per-position bookkeeping or new failure modes.
- Bounded overhead
  - Coding each spatial location would multiply assignment work and transient
    memory by ~`H*W`. Pooled coding adds a small, predictable constant-factor
    on top of the conv (see `docs/overhead.md`).
- Clear limitations
  - Global pooling discards spatial layout. It will miss purely local anomalies
    that cancel out in the average, but provides a robust, low-variance signal
    suitable for an initial end-to-end slice.

Deferring richer spatial modes
- Richer spatial coding (per-patch, strided windows, multi-scale maps) is
  attractive, but it expands the design space (which dims to reduce, how to
  aggregate across positions, how to calibrate maps) and can inflate compute and
  memory substantially. We will add these once the core surprise signal and
  integration surfaces are validated, with explicit aggregation modes and
  operating limits.
