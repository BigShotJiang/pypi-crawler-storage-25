# CIFAR-10 OOD Benchmark (ResNet-18)

## Summary
- Question: Does Nervecode provide a competitive single-pass OOD signal on CNN image classifiers with interpretable layerwise surprise and modest overhead?
- Hypothesis: On CNN image classifiers, Nervecode provides a competitive single-pass OOD signal with interpretable layerwise surprise and modest overhead.
- Result: <fill with AUROC/FPR95 snapshot>
- Links: scripts/run_cifar_ood.sh, benchmarks/ood/cifar_resnet18.py

## Context & Commit
- Commit: <git sha>
- Environment: OS=, Python=, PyTorch=, CUDA=, Device=
- Hardware: CPU/GPU details

## Data
- ID: CIFAR-10 train/test (calibration from train split)
- OOD: SVHN, DTD, CIFAR-100; optional LSUN/iSUN if present
- Transforms: standard CIFAR-10 normalization and light train aug

## Model & Instrumentation
- Base: ResNet-18 adapted for CIFAR (3x3 conv1, stride=1, no maxpool)
- Nervecode: layers=all_conv|first_conv, K=16, D∈{8,16}, agg∈{mean,max}, βL=1.0, βE=1.0, βD∈{0.0,1.0}

## Procedure
- Demo smoke command:
  `python -m benchmarks.ood.cifar_resnet18 --preset demo --limit-eval 512`
- Full claim-candidate command:
  `python -m benchmarks.ood.cifar_resnet18 --preset full_cifar10_resnet18 --device cuda`
- Seeds: record the exact list; default CLI presets use seed 123 unless
  `--seeds` is supplied.
- Layer presets: last_block, last_two_blocks, all_blocks; all_conv only for
  smoke/overhead exploration.
- Full mode: 200 default epochs, SGD + momentum, cosine schedule, no eval
  sample limit unless explicitly set.
- Accuracy gate: CIFAR-10 ID test accuracy must be >= 0.93 before OOD tables
  are treated as claim-candidate results.

## Metrics
- AUROC, FPR@95% TPR, ID accuracy, latency (ms/sample; includes forward)

## Results
- Aggregate table by method and OOD; highlight Nervecode rows.
- Best config snapshot.

## Layerwise Analysis
- Per-layer mean surprise (ID vs OOD) figure from saved artifacts:
  `python -m nervecode.viz.layerwise runs/<run_id> --seed 123 --ood dtd,cifar100,svhn`.
- Artifact inputs: `layerwise/seed_<seed>/id_test.npz` and
  `layerwise/seed_<seed>/ood_<name>.npz`.

## Notes
- `demo` rows are smoke diagnostics, not paper-comparable results.
- Full runs save checkpoints locally by default and record SHA-256 values in
  `meta.json`.
- ODIN is slower due to gradient-based input perturbation; limit_eval reduces runtime.
- LSUN/iSUN are optional; script skips gracefully if not present.
