# Benchmark Protocol And Report Template

This document defines the v0.1.1 benchmark protocol and a lightweight,
repeatable format for reporting experiments in Nervecode. Use it to avoid
one-off notebooks and to keep results comparable over time.

Recommended filename: `docs/benchmarks/<slug>-<yyyymmdd>.md` for long‑lived
write‑ups. For quick runs, place raw CSV/JSONL outputs under `runs/` and link
them here.

---

## 0) Summary

- Question: one sentence on what you measured and why.
- Claim: the single most important takeaway.
- Result: one metric snapshot with units (e.g., AUROC 0.87 @ 95% TPR).
- Link(s): script/CLI used, run artifacts (CSV/JSONL, plots).
  - For a minimal OOD sanity check, see `benchmarks/ood/simple.py` which trains a
    tiny MLP, calibrates empirical percentiles, and reports AUROC between held-out
    in-distribution and a synthetic OOD split.

## 1) Context & Commit

- Commit: `<git sha>` (and tag if any); list changed areas if not main.
- Environment: OS, Python, PyTorch, CUDA/cuDNN, Nervecode version.
- Hardware: CPU model, GPU model(s), RAM/VRAM, storage notes if relevant.

## 2) Data

- Dataset(s): name and version; ID vs OOD splits where relevant.
- Preprocessing: normalization, resize/crop, tokenization; augmentation policy.
- Splits: train/val/test sizes and selection method (random/stratified/fixed).

### OOD Split Contract

All benchmark tables use the score convention **higher score = more OOD-like**.
Use the split discipline below for any release claim:

| Split | Allowed use |
|---|---|
| ID train | Train classifier; fit Mahalanobis/KNN/feature statistics. |
| ID calibration | Fit score normalization, thresholds, and Nervecode percentile calibration. |
| ID test | Metric evaluation only. |
| OOD test | Metric evaluation only. |

No OOD samples may be used to choose headline combo weights, and no OOD test
statistics may be used for score normalization. If a supervised or
OOD-calibrated combiner is shown, label it `oracle_ood_calibrated_combo` and do
not present it as the main detector.

### Layerwise Artifact Contract

Benchmark runs that evaluate Nervecode should persist the per-sample,
per-layer surprise matrix observed during that run. The CIFAR OOD script writes
these artifacts under `runs/<run_id>/layerwise/seed_<seed>/`:

| File | Contents |
|---|---|
| `id_calibration.npz` | ID calibration surprise, when collected. |
| `id_test.npz` | ID test surprise used for reported metrics. |
| `ood_<name>.npz` | OOD test surprise for each evaluated OOD set. |

Each artifact contains `layer_names` and `surprise` with shape
`[num_samples, num_layers]`; it may also include `labels`, `sample_ids`,
`reduction_meta_json`, and `metadata_json`. Plots must be generated from these
saved artifacts, not from a newly built model:

```bash
python -m nervecode.viz.layerwise runs/<run_id> \
  --seed 123 \
  --ood dtd,cifar100,svhn \
  --output runs/<run_id>/plots/layerwise.png
```

### CIFAR ResNet-18 Preset Contract

`benchmarks/ood/cifar_resnet18.py` is an existing source-checkout benchmark
runner. It has two explicit modes:

| Preset | Use | Claim status |
|---|---|---|
| `demo` | Short smoke/debug run, usually with `--limit-eval`. | Not a scientific benchmark claim. |
| `full_cifar10_resnet18` | From-scratch CIFAR-10 ResNet-18 with standard CIFAR augmentation, SGD + momentum, cosine schedule, and a 93% default ID accuracy gate. | Claim candidate only if the gate passes. |

Demo output must be labeled as demo output. Full-mode OOD tables must not be
reported when the CIFAR-10 ID test accuracy is below the configured
`--accuracy-gate` unless the report explicitly says `--allow-low-accuracy` was
used and treats the rows as failed-gate diagnostics.

Full runs save local per-seed checkpoints by default under
`runs/<run_id>/checkpoints/` and record checkpoint SHA-256 values in
`checkpoint_manifest.json` and `meta.json`. If a checkpoint is hosted outside
git, record its URI and SHA-256 with `--checkpoint-uri` and
`--checkpoint-sha256`.

The supported ResNet-18 layer-selection presets for Nervecode claims are
`last_block`, `last_two_blocks`, and `all_blocks`. `all_conv` remains available
for smoke and overhead exploration, but should not be the default claim path
without an explicit overhead/AUROC tradeoff table.

No ImageNet-pretrained path is enabled in the v0.1.1 runner. If one is added,
label it `transfer_resnet18` and document whether CIFAR images are resized to
the pretrained regime or the architecture was adapted.

### v0.1.1 Configs And Archiving

The release configs live under `configs/v0_1_1/` and are JSON-only to avoid a
PyYAML dependency:

| Config | Purpose |
|---|---|
| `smoke.json` | Fast source-checkout smoke run. |
| `cpu_cnn_suite.json` | CPU-friendly diagnostic CNN suite. |
| `cifar_resnet18_demo.json` | Short ResNet-18 demo mode. |
| `cifar_resnet18_full.json` | Full from-scratch ResNet-18 claim candidate. |
| `combo_ablation.json` | ID-only Combo(E, M, N) ablation path. |

Each config records seeds, hardware expectation, dataset root, backbone, layer
selection, baseline list, score orientation, split policy, output directory
rule, and runtime caveat. The CIFAR runner accepts these directly:

```bash
python -m benchmarks.ood.cifar_resnet18 --config configs/v0_1_1/cifar_resnet18_demo.json
python -m benchmarks.ood.cifar_resnet18 --config configs/v0_1_1/combo_ablation.json
```

Archive release run artifacts with:

```bash
python scripts/archive_benchmark_artifacts.py runs/<run_id>
```

Attach the resulting `*-benchmark-artifacts.tar.gz` to the GitLab release only
when the run was produced from the release commit, the accuracy gate status is
documented, and `meta.json` includes the dataset, checkpoint, score-orientation,
split, and combo provenance metadata.

## 3) Model & Instrumentation

- Base model: architecture, key sizes (widths, channels), params.
- Instrumentation: wrapped layers, `coding_dim D`, codebook size `K`, reducers
  (pooled Conv2d vs alternatives), temperature, aggregation mode (mean/max/
  weighted) and weights if fixed.
- Calibration: dataset, percentile thresholds, stored state location.

## 4) Procedure

- Commands: exact CLI/script invocations with flags and seeds.
- Training: epochs/steps, batch size, optimizer/lr, loss mix if using
  `CodingLoss` with task loss.
- Evaluation: datasets, batch size, number of repeats; any caching warm‑ups.

## 5) Metrics

- Quality: accuracy/F1/AUROC/AUPRC as appropriate; add calibration metrics if
  relevant (ECE, percentile error).
- OOD: AUROC/AUPRC/TNR@TPR; threshold selection rule.
- Overhead: per‑iteration wall‑time, parameter deltas, activation footprint;
  include both absolute numbers and ratios vs baseline.
- Baselines: see `docs/baselines.md` for score definitions, defaults, and fit
  splits.
- Combo ablations: see `docs/combo.md` for the ID-only z-score equal-weight
  method, subset names, and interpretation rules.

## 6) Results

Provide a concise table and short narrative.

| Config | ID Metric | OOD Metric | Overhead | Notes |
|:--|:--|:--|:--|:--|
| baseline | acc 0.91 | AUROC – | 1.00× | no coding |
| D=64, K=32 | acc 0.90 | AUROC 0.87 | 1.06× | pooled conv |

Observations
- What improved, what regressed, and by how much.
- Any sensitivity to D/K, selection, or temperature.

## 7) Reproducibility

- Seeds: values and how set (`NERVECODE_SEED`, manual, framework defaults).
- Artifacts: path(s) to CSV/JSONL outputs, checkpoints, calibration state.
- Determinism: known nondeterministic kernels; steps taken to control variance.
- Score orientation: record `higher_is_ood=true`.
- Fitted objects: record which split was used for every fitted scorer,
  normalizer, threshold, and combo.

## 8) Limitations & Next Steps

- Caveats: dataset biases, small sample sizes, missing baselines.
- Follow‑ups: the smallest next change to validate the claim.

---

### Copy‑Paste Template

```
# <short slugged title>

## Summary
- Question:
- Claim:
- Result:
- Links:

## Context & Commit
- Commit:
- Environment: OS=, Python=, PyTorch=, CUDA/cuDNN=, Nervecode=
- Hardware: CPU=, GPU=, RAM=, VRAM=

## Data
- Dataset(s):
- Preprocessing:
- Splits:

## Model & Instrumentation
- Base model:
- Instrumentation: selection=, D=, K=, reducer=, temperature=, aggregation=
- Calibration:

## Procedure
- Commands:
- Training:
- Evaluation:

## Metrics
- Quality:
- OOD:
- Overhead:

## Results
| Config | ID Metric | OOD Metric | Overhead | Notes |
|:--|:--|:--|:--|:--|
| baseline |  |  |  |  |

Observations:

## Reproducibility
- Seeds:
- Artifacts:
- Determinism:
- Score orientation: higher_is_ood=true
- Fitted objects:
  - classifier: ID train
  - feature statistics: ID train
  - score normalization: ID calibration
  - thresholds: ID calibration
  - combo: ID calibration only unless explicitly labeled oracle_ood_calibrated_combo

## Limitations & Next Steps
- Caveats:
- Follow‑ups:
```

---

## Running Benchmark Tests

Fast correctness tests run by default. Tests that exercise benchmarking harnesses are
tagged with the `benchmark` marker and are deselected unless explicitly requested.

- Run only fast tests (default): `pytest`
- Include benchmark tests: `pytest -m benchmark`
- Include both slow and benchmark tests: `pytest -m 'slow or benchmark'`

CI runs only fast tests to keep the pipeline reliable and quick.

## Matrix Script Profiles

The OOD matrix script supports a FAST profile that narrows the grid to a promising slice to accelerate iteration.

- Full sweep (default): `bash scripts/run_ood_matrix.sh`
- Fast slice (first_linear, K=16, D=8, βE=1.0, βD∈{0.5,1.0}, q∈{0.90,0.95}):
  `FAST=1 bash scripts/run_ood_matrix.sh`

You can override any array via env (e.g., `BETA_D="0.5" QUANTILES="0.90"`). The summary banner in `runs/<stamp>/summary.txt` shows the active profile and sweep values.
