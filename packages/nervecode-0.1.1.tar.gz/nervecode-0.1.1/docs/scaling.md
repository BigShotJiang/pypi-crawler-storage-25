# Scaling Guidance: Selection, Coding Space, Tradeoffs

This guide explains how to scale Nervecode safely by choosing which layers to
instrument, how to reduce coding-space dimensionality, and how to balance
expressivity against compute/memory overhead.

See also: `docs/architecture.md` (guardrails), `docs/overhead.md` (Conv2d
overhead and operating limits), and `docs/api.md` (selection and constructors).

## Selected-Layer Instrumentation

Nervecode is opt-in by design: only explicitly selected layers are wrapped.
This keeps behavior predictable and lets you budget overhead.

- Selection modes
  - `layers="all_linear"`: wrap every `nn.Linear` with `CodingLinear`.
  - `layers="all_conv"`: wrap every `nn.Conv2d` with `CodingConv2d`.
  - `layers=["path.to.submodule", ...]`: wrap exact dotted module names as
    returned by `model.named_modules()`; unknown names are ignored (fail-open).
- Safety
  - Wrappers are observe‑only and fail‑open; model outputs are unchanged.
  - Explicit selection avoids accidental global hooks.
- Practical advice
  - Start small: instrument one block or “bottleneck” layer per stage.
  - Expand outward only if the surprise signal is too weak or too myopic.
  - Prefer wider layers first — they tend to carry more information and yield
    more stable coding statistics.

## Reduced Coding Spaces (D < width)

Wrappers can project wide activations to a lower‑dimensional coding space
(`coding_dim=D`) while preserving the base layer’s visible output.

- Linear layers
  - `CodingLinear(layer, coding_dim=D)` with `1 ≤ D ≤ out_features`.
  - When `D < out_features`, a learned linear projection is used for coding
    only; the returned `forward(x)` equals the base layer output.
- Conv2d (pooled)
  - `CodingConv2d` reduces spatially (global average by default) to `(B, C_out)`
    and can then optionally project to `(B, D)` for coding.
- Why reduce?
  - Overhead drops linearly with `D` (compute and transient activations) and
    parameter cost remains predictable (see `docs/overhead.md`).
  - Smaller `D` can denoise redundant channels and improve code utilization.
- Risks
  - Too small `D` may underfit the activation manifold and blur useful
    variations, reducing separability in the surprise signal.
  - Use diagnostics (code utilization, entropy, commitment distance) to detect
    collapse or under‑representation.

Heuristics
- Start with `D = min(64, width)` for Linear and `D = min(64, C_out)` for
  pooled Conv2d if you need overhead headroom; increase if diagnostics suggest
  under‑utilization or poor separability.
- Keep codebook size modest (e.g., `K ∈ [16, 64]`) and scale `K` only after
  tuning `D` and selection.

## Expressivity vs. Overhead: Practical Tradeoffs

Dimensions of control
- Layer selection (how many and which layers)
- Coding dimension `D` (per wrapped layer)
- Codebook size `K`
- Spatial reduction mode (Conv2d: pooled vs. richer reducers)

Typical operating points
- Low overhead / broad coverage
  - Instrument only a few wide layers per stage; use pooled Conv2d; pick
    `D ≤ 64`, `K ≈ 16–32`.
- Balanced
  - Instrument most Linear layers and key Conv2d blocks; `D ≈ 64–128`,
    `K ≈ 32–64`.
- High expressivity (heavier)
  - Instrument many layers; increase `D` and/or `K`; consider richer spatial
    reducers for convs. Expect higher compute and transient memory.

Tradeoff checklist
- If memory/time is tight: reduce `D` first, then `K`, then the number of
  instrumented layers.
- If the signal is weak: instrument slightly more informative layers before
  inflating `K`; raise `D` in small steps and re‑check diagnostics.
- Prefer pooled Conv2d until benchmarks justify token‑like spatial coding.

Measuring and attributing overhead
- Use the deterministic estimator and guidance in `docs/overhead.md`.
- Attribute cost per decision: a single wrapped layer adds a small constant
  factor; many wrapped layers add up.
- Track activation overhead: transient elements scale with batch size via
  `(B * (D + K))` for pooled Conv2d.

## Putting It Together: Suggested Workflow

1) Pick initial layers (a few wide ones) and modest `D, K`.
2) Verify observe‑only behavior and run a small calibration.
3) Inspect diagnostics for code utilization, entropy, and commitment distance.
4) Adjust `D` and selection; only increase `K` if codes are saturated but still
   insufficiently expressive.
5) Re‑measure overhead and quality; document the chosen operating point.

