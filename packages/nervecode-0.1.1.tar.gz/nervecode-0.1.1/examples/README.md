# Examples

This directory hosts example scripts demonstrating how to use Nervecode.

- `quickstart_mlp.py`: tiny MLP end-to-end (training, calibration, inference).
- `quickstart_cnn.py`: small CNN showing pooled Conv2d coding feeding aggregated surprise.
