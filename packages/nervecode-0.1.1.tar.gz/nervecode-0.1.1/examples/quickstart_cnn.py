# mypy: ignore-errors
"""Quickstart: pooled Conv2d coding contributes to aggregated surprise.

This example builds a tiny CNN for 8x8 RGB inputs, instruments its
``nn.Conv2d`` layers with pooled-coding wrappers, runs a forward pass, and
retrieves an aggregated per-sample surprise vector. The pooled convolutional
traces (global average pooling over HxW) feed into the default mean aggregator.

It is intentionally lightweight and CPU-friendly.
"""

from __future__ import annotations

from typing import Any

import nervecode as nvc
import torch
from nervecode.layers.wrap import wrap as wrap_layers
from torch import nn


class TinyCNN(nn.Module):
    """Two small conv blocks followed by global pooling and a classifier."""

    def __init__(self, n_classes: int = 2) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(3, 8, kernel_size=3, padding=1)
        self.act1 = nn.ReLU()
        self.conv2 = nn.Conv2d(8, 8, kernel_size=3, padding=1)
        self.act2 = nn.ReLU()
        self.out = nn.Linear(8, n_classes)

    def forward(self, x: Any) -> Any:
        h = self.act1(self.conv1(x))
        h = self.act2(self.conv2(h))
        # Global average pool (B, C, H, W) -> (B, C)
        h = h.mean(dim=(-1, -2))
        return self.out(h)


def main() -> None:  # pragma: no cover - example script
    device = torch.device("cpu")
    model = TinyCNN().to(device).eval()

    # Instrument Conv2d layers in-place with pooled-coding wrappers
    wrap_layers(model, layers="all_conv")

    # Container for convenience helpers (coding loss, aggregated surprise)
    wrapped = nvc.WrappedModel(model)

    # One synthetic batch of 8x8 RGB images
    x = torch.randn(16, 3, 8, 8, device=device)

    with torch.no_grad():
        _ = wrapped.forward(x)  # runs through wrappers and updates pooled traces
        agg = wrapped.surprise()

    if agg is None:
        print("No aggregated surprise produced (no traces found).")
        return

    s = agg.surprise  # per-sample vector (B,)
    print(
        f"aggregator={getattr(agg, 'method', 'unknown')} "
        f"layers_contributed={getattr(agg, 'num_layers', 0)} "
        f"surprise_shape={tuple(int(t) for t in getattr(s, 'shape', []))}"
    )
    # Show first few samples to demonstrate non-zero pooled-conv contribution
    head = min(3, int(s.shape[0]))
    vals = ", ".join(f"{float(s[i].item()):.4f}" for i in range(head))
    print(f"surprise_head=[{vals}] ...")


if __name__ == "__main__":  # pragma: no cover
    main()
