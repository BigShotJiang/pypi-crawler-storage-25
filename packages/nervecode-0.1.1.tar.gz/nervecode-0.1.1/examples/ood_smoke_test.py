# mypy: ignore-errors
"""OOD smoke test using empirical percentiles.

This example creates a clearly separated in-distribution and out-of-distribution
set of synthetic surprise scores, calibrates an empirical percentile calibrator
on the in-distribution scores, and then prints both raw scores and their
calibrated percentiles for a few samples from each set. It also reports mean
percentiles and simple OOD rates at a chosen quantile.

The goal is a quick, dependency-light sanity check that behaves obviously:
the out-of-distribution scores should map to much higher percentiles and a
larger OOD rate than the in-distribution scores.
"""

from __future__ import annotations

import importlib
import random
import sys
from collections.abc import Iterable
from pathlib import Path


def _to_tensor(xs: Iterable[float]):  # return type is torch.Tensor when torch is available
    import importlib

    torch = importlib.import_module("torch")
    return torch.tensor(list(xs), dtype=getattr(torch, "float32", None) or None)


def main() -> None:  # pragma: no cover - exercised by smoke test
    # Ensure repository root is on sys.path when executed as a script
    repo_root = str(Path(__file__).resolve().parents[1])
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

    # Import after adjusting sys.path so running the script works from source
    from nervecode.scoring import EmpiricalPercentileCalibrator

    # Handle environments without a functional torch installation
    try:
        torch_mod = importlib.import_module("torch")
    except Exception:
        print("torch not available; skipping OOD smoke test")
        return
    if not hasattr(torch_mod, "tensor"):
        print("torch not available; skipping OOD smoke test")
        return

    # Reproducible synthetic scores: in-dist ~ N(0,1), out-of-dist ~ N(0,1) + shift
    random.seed(12345)
    n = 1000
    shift = 2.0
    in_scores = _to_tensor(random.gauss(0.0, 1.0) for _ in range(n))
    out_scores = in_scores + shift

    calib = EmpiricalPercentileCalibrator(threshold_quantiles=(0.9,))
    calib.fit(in_scores, aggregation="mean")

    # Percentiles and simple OOD mask at the configured quantile
    p_in = calib.percentiles(in_scores)
    p_out = calib.percentiles(out_scores)
    ood_in = calib.is_ood(in_scores)
    ood_out = calib.is_ood(out_scores)

    print(
        f"In-distribution: mean_score={float(in_scores.mean()):.3f} "
        f"mean_percentile={float(p_in.mean()):.3f} ood_rate={float(ood_in.float().mean()):.3f}"
    )
    for i in range(3):
        s = float(in_scores[i].item())
        p = float(p_in[i].item())
        o = bool(ood_in[i].item())
        print(f"  sample[{i}]: score={s:.3f} percentile={p:.3f} ood={o}")

    print(
        f"Out-of-distribution: mean_score={float(out_scores.mean()):.3f} "
        f"mean_percentile={float(p_out.mean()):.3f} ood_rate={float(ood_out.float().mean()):.3f}"
    )
    for i in range(3):
        s = float(out_scores[i].item())
        p = float(p_out[i].item())
        o = bool(ood_out[i].item())
        print(f"  sample[{i}]: score={s:.3f} percentile={p:.3f} ood={o}")


if __name__ == "__main__":  # pragma: no cover
    main()
