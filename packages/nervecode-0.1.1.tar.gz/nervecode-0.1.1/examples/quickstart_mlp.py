# mypy: ignore-errors
"""Quickstart: wrap a tiny MLP, train with coding loss, calibrate, infer.

This example demonstrates a minimal end-to-end workflow using Nervecode:

- Build a tiny 2D classifier (MLP).
- Instrument its linear layers with coding wrappers.
- Train on a synthetic dataset with task loss + coding loss.
- Calibrate an empirical percentile threshold on held-out in-distribution data.
- Run inference and read both raw surprise and calibrated percentiles.

The script is intentionally lightweight and self-contained. It avoids external
datasets and runs quickly on CPU by default. Use it as a reference for how to
integrate Nervecode into an existing PyTorch training loop.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from nervecode.layers.wrap import wrap as wrap_layers
from nervecode.scoring import EmpiricalPercentileCalibrator
from nervecode.training import CsvDiagnosticsLogger, DiagnosticsCollector
from torch import nn
from torch.utils.data import DataLoader, Dataset, random_split


class ToyGaussianDataset(Dataset[tuple[torch.Tensor, torch.Tensor]]):
    """Two-class 2D Gaussian mixture for quick CPU training.

    - Class 0: centered at (-1.0, -1.0)
    - Class 1: centered at (+1.0, +1.0)
    """

    def __init__(self, n: int, *, seed: int = 42) -> None:
        g = torch.Generator(device="cpu").manual_seed(int(seed))
        x0 = torch.randn(n // 2, 2, generator=g) * 0.6 + torch.tensor([-1.0, -1.0])
        x1 = torch.randn(n - n // 2, 2, generator=g) * 0.6 + torch.tensor([+1.0, +1.0])
        y0 = torch.zeros(x0.shape[0], dtype=torch.long)
        y1 = torch.ones(x1.shape[0], dtype=torch.long)
        self.x = torch.cat([x0, x1], dim=0)
        self.y = torch.cat([y0, y1], dim=0)

        # Shuffle once to mix classes
        perm = torch.randperm(self.x.shape[0], generator=g)
        self.x = self.x[perm]
        self.y = self.y[perm]

    def __len__(self) -> int:
        return int(self.x.shape[0])

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self.x[idx], self.y[idx]


class TinyMLP(nn.Module):
    def __init__(self, in_dim: int = 2, hidden: int = 32, out_dim: int = 2) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


@dataclass
class Config:
    device: str = "cpu"
    batch_size: int = 64
    epochs: int = 5
    lr: float = 1e-2
    coding_loss_weight: float = 0.1
    threshold_quantiles: tuple[float, ...] = (0.95,)
    dataset_size: int = 1024
    calib_fraction: float = 0.25  # fraction of dataset reserved for calibration


def make_loaders(cfg: Config) -> tuple[DataLoader[Any], DataLoader[Any], DataLoader[Any]]:
    ds = ToyGaussianDataset(cfg.dataset_size, seed=123)
    calib_len = int(len(ds) * cfg.calib_fraction)
    test_len = calib_len
    train_len = len(ds) - calib_len - test_len
    train, calib, test = random_split(ds, [train_len, calib_len, test_len])

    def _mk(dl_ds: Dataset[Any]) -> DataLoader[Any]:
        return DataLoader(dl_ds, batch_size=cfg.batch_size, shuffle=True)

    return _mk(train), _mk(calib), _mk(test)


def train_with_coding_loss(cfg: Config) -> tuple[nn.Module, EmpiricalPercentileCalibrator]:
    device = torch.device(cfg.device)

    # Build and instrument the model
    model = TinyMLP().to(device)
    wrap_layers(model, layers="all_linear")  # instrument Linear layers in-place

    # Use the WrappedModel container for convenience loss/aggregation helpers
    import nervecode as nvc

    wrapped = nvc.WrappedModel(model)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    ce = nn.CrossEntropyLoss()

    train_loader, calib_loader, _ = make_loaders(cfg)

    # Set up out-of-the-box CSV diagnostics under runs/
    diag_csv = CsvDiagnosticsLogger("runs/quickstart_diagnostics.csv")
    diag_collector = DiagnosticsCollector()

    model.train()
    for epoch in range(cfg.epochs):
        total_loss = 0.0
        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            logits = wrapped.forward(xb)  # run through wrappers and update traces
            loss = ce(logits, yb)
            # Add coding loss from latest per-layer traces
            loss = loss + cfg.coding_loss_weight * wrapped.coding_loss()
            loss.backward()
            opt.step()
            total_loss += float(loss.detach().item())
            # Log latest per-layer diagnostics to CSV
            rows = diag_collector.collect(getattr(wrapped, "_last_layer_traces", {}))
            if rows:
                diag_csv.log(rows)
        print(f"epoch={epoch + 1} train_loss={total_loss / max(1, len(train_loader)):.4f}")

    # Calibrate on held-out in-distribution data using aggregated surprise
    from nervecode.scoring import mean_surprise

    wrapped.disable_coding()  # optional: ensure coding state is explicit for eval
    wrapped.enable_coding()
    model.eval()

    scores: list[torch.Tensor] = []
    with torch.no_grad():
        for xb, _ in calib_loader:
            xb = xb.to(device)
            _ = wrapped.forward(xb)
            agg = wrapped.surprise()
            if agg is None:
                # Fall back to explicit aggregation over per-layer traces
                traces = getattr(wrapped, "_last_layer_traces", {})
                agg = mean_surprise(traces)
            if agg is not None and isinstance(agg.surprise, torch.Tensor):
                scores.append(agg.surprise.detach().to("cpu"))

    if not scores:
        raise RuntimeError("No surprise scores collected during calibration")
    vec = torch.cat(scores, dim=0)
    calib = EmpiricalPercentileCalibrator(threshold_quantiles=cfg.threshold_quantiles)
    state = calib.fit(vec, aggregation="mean")
    thr = calib.threshold()
    print(
        f"calibrated: n={int(state.metadata.get('num_scores', len(vec)))} "
        f"quantiles={state.threshold_quantiles} threshold={thr.item():.4f}"
    )

    return wrapped, calib


def run_inference(
    wrapped: Any,
    calib: EmpiricalPercentileCalibrator,
    cfg: Config,
) -> None:
    device = torch.device(cfg.device)
    _, _, test_loader = make_loaders(cfg)

    wrapped.disable_coding()
    wrapped.enable_coding()
    with torch.no_grad():
        for xb, yb in test_loader:
            xb = xb.to(device)
            _ = wrapped.forward(xb)
            agg = wrapped.surprise()
            if agg is None:
                continue
            s = agg.surprise  # per-sample surprise (tensor)
            p = calib.percentiles(s)
            ood = calib.is_ood(s)
            print(
                f"batch: surprise_mean={float(s.mean()):.4f} "
                f"pct_mean={float(p.mean()):.3f} ood_rate={float(ood.float().mean()):.3f}"
            )
            # Show a couple of examples
            for i in range(min(3, s.shape[0])):
                s_i = float(s[i].item())
                p_i = float(p[i].item())
                ood_i = bool(ood[i].item())
                print(f"  sample[{i}]: y={int(yb[i].item())} s={s_i:.4f} p={p_i:.3f} ood={ood_i}")
            break  # keep output concise


def main() -> None:  # pragma: no cover - example script
    cfg = Config()
    wrapped, calib = train_with_coding_loss(cfg)
    run_inference(wrapped, calib, cfg)


if __name__ == "__main__":  # pragma: no cover
    main()
