#!/usr/bin/env bash

# CPU-only evaluation suite for Nervecode (CIFAR-10 vs OOD + optional MNIST).
#
# What it does (defaults chosen for CPU demo runs, not paper-comparable claims):
# - CIFAR-10 ResNet-18 demo run: layers=last_block, agg=mean, no ODIN,
#   learn 3-feature oracle combiner for appendix-only inspection.
# - Optional small ablation grid (disabled by default; enable with DO_ABL=1).
# - Optional MNIST easy track (runs if datasets are cached locally; otherwise warns).
# - Produces compact summary CSVs for quick reporting.
#
# Environment overrides (examples):
#   DEVICE=cpu EPOCHS_STRONG=20 EPOCHS_ABL=15 BATCH=256 LIMIT_STRONG=10000 LIMIT_ABL=5000 \
#   SEED=123 STRONG_AGG="mean max" STRONG_KS="16 32" STRONG_DIMS="8 16" \
#   DO_ABL=0 AGG_ABL="mean max" K_ABL="16 32" DIMS_ABL="8 16" \
#   SKIP_MNIST=1 FAST=1
#
# Quick smoke run: FAST=1 DO_ABL=0 SKIP_MNIST=1 bash scripts/run_cpu_suite.sh

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
cd "$REPO_ROOT"

PY="${PYTHON:-python3}"
DEVICE="${DEVICE:-cpu}"
CIFAR_PRESET="${CIFAR_PRESET:-demo}"
BATCH="${BATCH:-256}"

# Strong run defaults
EPOCHS_STRONG="${EPOCHS_STRONG:-20}"
LIMIT_STRONG="${LIMIT_STRONG:-10000}"
SEED="${SEED:-123}"
LAYERS_STRONG="${LAYERS_STRONG:-last_block}"
STRONG_AGG_ARR=( ${STRONG_AGG:-mean} )
STRONG_K_ARR=( ${STRONG_KS:-16} )
STRONG_D_ARR=( ${STRONG_DIMS:-8} )

# Nervecode params
BEVAL="${BEVAL:-0.2}"
BDVAL="${BDVAL:-1.0}"
TEMP="${TEMP:-1.5}"

# Ablation defaults (disabled by default; enable with DO_ABL=1)
DO_ABL="${DO_ABL:-0}"
EPOCHS_ABL="${EPOCHS_ABL:-15}"
LIMIT_ABL="${LIMIT_ABL:-5000}"
AGG_ABL_ARR=( ${AGG_ABL:-mean max} )
K_ABL_ARR=( ${K_ABL:-16 32} )
DIMS_ABL_ARR=( ${DIMS_ABL:-8 16} )

STAMP="$(date +%Y%m%d-%H%M%S)"
OUTROOT="${OUTROOT:-runs/cpu-suite-$STAMP}"
mkdir -p "$OUTROOT"

# FAST profile to shrink runtime
if [[ "${FAST:-0}" -eq 1 ]]; then
  echo "FAST profile active: reducing epochs/limits" | tee "$OUTROOT/summary.txt"
  EPOCHS_STRONG="${EPOCHS_STRONG_FAST:-5}"
  LIMIT_STRONG="${LIMIT_STRONG_FAST:-2000}"
  EPOCHS_ABL="${EPOCHS_ABL_FAST:-3}"
  LIMIT_ABL="${LIMIT_ABL_FAST:-1000}"
else
  echo "Profile=FULL" | tee "$OUTROOT/summary.txt"
fi

echo "PY=$PY DEVICE=$DEVICE CIFAR_PRESET=$CIFAR_PRESET BATCH=$BATCH SEED=$SEED OUTROOT=$OUTROOT" | tee -a "$OUTROOT/summary.txt"

###############################################################################
# 1) Strong CIFAR-10 run(s)
###############################################################################
for agg in "${STRONG_AGG_ARR[@]}"; do
  for K in "${STRONG_K_ARR[@]}"; do
    for D in "${STRONG_D_ARR[@]}"; do
      RUN_DIR="$OUTROOT/cifar-ood/strong_${agg}_K${K}_D${D}"
      mkdir -p "$RUN_DIR"
      echo "== Strong run: layers=$LAYERS_STRONG agg=$agg K=$K D=$D EPOCHS=$EPOCHS_STRONG ==" | tee -a "$OUTROOT/summary.txt"
      set +e
      "$PY" -m benchmarks.ood.cifar_resnet18 \
        --preset "$CIFAR_PRESET" \
        --device "$DEVICE" \
        --batch-size "$BATCH" \
        --epochs "$EPOCHS_STRONG" \
        --seeds "$SEED" \
        --layers "$LAYERS_STRONG" \
        --agg "$agg" \
        --K "$K" \
        --coding-dim "$D" \
        --beta-length 1.0 \
        --beta-entropy "$BEVAL" \
        --beta-distance "$BDVAL" \
        --temperature "$TEMP" \
        --limit-eval "$LIMIT_STRONG" \
        --no-odin \
        --learn-ood-calibrated-combo3 \
        --save-combiner \
        --outdir "$RUN_DIR" \
        --verbose 2>&1 | tee "$RUN_DIR/run.log"
      RET=$?
      set -e
      if [ $RET -ne 0 ] || [ ! -f "$RUN_DIR/results.csv" ]; then
        echo "WARN: strong run failed; see $RUN_DIR/run.log" | tee -a "$OUTROOT/summary.txt"
      else
        # Compact summary for methods of interest
        set +e
        "$PY" - "$RUN_DIR/results.csv" "$RUN_DIR/summary_methods.csv" << 'PY'
import csv, sys, os
path=sys.argv[1]; out=sys.argv[2]
rows=list(csv.DictReader(open(path)))
keep={
    'msp',
    'energy',
    'maxlogit',
    'gen',
    'knn',
    'residual_vim_lite',
    'nervecode_mean',
    'nervecode_max',
    'oracle_ood_calibrated_combo_lr3',
    'combo_loaded_unverified',
}
with open(out,'w',encoding='utf-8') as f:
    f.write('ood,method,auroc,aupr_out,fpr95,latency_ms\n')
    for r in rows:
        method = str(r.get('method', ''))
        if method in keep or method.startswith('combo_id_zscore_equal'):
            f.write(
                f"{r['ood']},{r['method']},{r['auroc']},{r.get('aupr_out', '')},"
                f"{r['fpr95']},{r['latency_ms']}\n"
            )
print(f"Wrote summary CSV -> {out}")
PY
        set -e
      fi
    done
  done
done

###############################################################################
# 2) Optional ablation grid (disabled by default)
###############################################################################
if [[ "$DO_ABL" == "1" ]]; then
  ABL_ROOT="$OUTROOT/cifar-ood-abl"
  mkdir -p "$ABL_ROOT"
  echo "== Ablation: agg=[${AGG_ABL_ARR[*]}] K=[${K_ABL_ARR[*]}] D=[${DIMS_ABL_ARR[*]}] EPOCHS=$EPOCHS_ABL ==" | tee -a "$OUTROOT/summary.txt"
  CSV_AGG="$ABL_ROOT/results.csv"
  echo "layers,agg,K,coding_dim,beta_entropy,beta_distance,temperature,seed,ood,method,auroc,aupr_out,fpr95,id_acc,latency_ms" > "$CSV_AGG"
  for agg in "${AGG_ABL_ARR[@]}"; do
    for K in "${K_ABL_ARR[@]}"; do
      for D in "${DIMS_ABL_ARR[@]}"; do
        RUN_DIR="$ABL_ROOT/run_${agg}_K${K}_D${D}"
        mkdir -p "$RUN_DIR"
        set +e
        "$PY" -m benchmarks.ood.cifar_resnet18 \
          --preset "$CIFAR_PRESET" \
          --device "$DEVICE" \
          --batch-size "$BATCH" \
          --epochs "$EPOCHS_ABL" \
          --seeds "$SEED" \
          --layers "$LAYERS_STRONG" \
          --agg "$agg" \
          --K "$K" \
          --coding-dim "$D" \
          --beta-length 1.0 \
          --beta-entropy "$BEVAL" \
          --beta-distance "$BDVAL" \
          --temperature "$TEMP" \
          --limit-eval "$LIMIT_ABL" \
          --no-odin \
          --learn-ood-calibrated-combo3 \
          --outdir "$RUN_DIR" \
          2>&1 | tee "$RUN_DIR/run.log"
        RET=$?
        set -e
        if [ $RET -ne 0 ] || [ ! -f "$RUN_DIR/results.csv" ]; then
          echo "WARN: ablation run failed; see $RUN_DIR/run.log" | tee -a "$OUTROOT/summary.txt"
          continue
        fi
        python3 - "$RUN_DIR/results.csv" "$CSV_AGG" "$LAYERS_STRONG" "$agg" "$K" "$D" "$BEVAL" "$BDVAL" "$TEMP" << 'PY'
import csv
import sys

src, dst, layers, agg, k_val, dim, beta_entropy, beta_distance, temp = sys.argv[1:]
with open(src, newline="", encoding="utf-8") as f_in, open(
    dst, "a", newline="", encoding="utf-8"
) as f_out:
    writer = csv.writer(f_out)
    for row in csv.DictReader(f_in):
        writer.writerow(
            [
                layers,
                agg,
                k_val,
                dim,
                beta_entropy,
                beta_distance,
                temp,
                row.get("seed", ""),
                row.get("ood", ""),
                row.get("method", ""),
                row.get("auroc", ""),
                row.get("aupr_out", ""),
                row.get("fpr95", ""),
                row.get("id_acc", ""),
                row.get("latency_ms", ""),
            ]
        )
PY
      done
    done
  done
fi

###############################################################################
# 3) Optional MNIST easy track (skips OODs not cached)
###############################################################################
echo "== MNIST OOD (optional) ==" | tee -a "$OUTROOT/summary.txt"
if [[ "${SKIP_MNIST:-0}" == "1" ]]; then
  echo "(Skipping MNIST — SKIP_MNIST=1)" | tee -a "$OUTROOT/summary.txt"
else
  M_OUT="$OUTROOT/mnist-ood"
  mkdir -p "$M_OUT"
  set +e
  "$PY" -m benchmarks.ood.mnist_cnn \
    --device "$DEVICE" \
    --epochs "${MNIST_EPOCHS:-5}" \
    --seed "$SEED" \
    --layers "${MNIST_LAYERS:-last_conv}" \
    --agg "${MNIST_AGG:-max}" \
    --K "${MNIST_K:-16}" \
    --coding-dim "${MNIST_D:-8}" \
    --temperature "${MNIST_TEMP:-2.0}" \
    --limit-eval "${MNIST_LIMIT:-1000}" \
    --outdir "$M_OUT" \
    2>&1 | tee "$M_OUT/run.log"
  RET_M=$?
  set -e
  if [ $RET_M -ne 0 ] || [ ! -f "$M_OUT/results.csv" ]; then
    echo "WARN: MNIST run failed or datasets unavailable; see $M_OUT/run.log" | tee -a "$OUTROOT/summary.txt"
  fi
fi

echo "Done. Suite outputs under $OUTROOT" | tee -a "$OUTROOT/summary.txt"
