#!/usr/bin/env bash

# CIFAR-10 OOD experiment driver with ResNet-18, baselines, and Nervecode.
#
# Sweeps 4 core ablations x 5 seeds and aggregates results to CSV/JSONL under a
# timestamped OUTDIR. Uses the benchmarks/ood/cifar_resnet18.py runner which
# computes MSP, Energy, MaxLogit, GEN, ODIN, Mahalanobis, KNN-OOD,
# Residual/ViM-lite, and Nervecode scores per OOD set.
#
# Environment overrides:
#   PRESET=demo|full_cifar10_resnet18
#   DEVICE=cpu|cuda   EPOCHS=<preset default>   BATCH=128   LIMIT_EVAL=<preset default>
#   SEEDS="123 456 789 321 654"
#   AGG="mean max"   LAYERS="last_block last_two_blocks all_blocks"   DIMS="8 16"
#   BD="0.0 1.0"
#   FAST=1 to enable a narrower, quicker slice (see below).

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
cd "$REPO_ROOT"

PY="${PYTHON:-python3}"
PRESET="${PRESET:-demo}"
DEVICE="${DEVICE:-cpu}"
BATCH="${BATCH:-128}"
if [[ -z "${EPOCHS:-}" ]]; then
  if [[ "$PRESET" == "full_cifar10_resnet18" ]]; then
    EPOCHS="200"
  else
    EPOCHS="1"
  fi
fi
if [[ -z "${LIMIT_EVAL:-}" ]]; then
  if [[ "$PRESET" == "full_cifar10_resnet18" ]]; then
    LIMIT_EVAL=""
  else
    LIMIT_EVAL="512"
  fi
fi
SEEDS="${SEEDS:-123 456 789 321 654}"

AGG_ARR=( ${AGG:-mean max} )
LAYERS_ARR=( ${LAYERS:-last_block last_two_blocks all_blocks} )
DIMS_ARR=( ${DIMS:-8 16} )
BD_ARR=( ${BD:-0.0 1.0} )
KVAL="${KVAL:-16}"
BEVAL="${BEVAL:-1.0}"

STAMP="$(date +%Y%m%d-%H%M%S)"
OUTDIR="${OUTDIR:-runs/cifar-ood-matrix-$STAMP}"
mkdir -p "$OUTDIR"

# FAST profile: reduce seeds/limit/ablations for quicker iteration
if [[ "${FAST:-0}" -eq 1 ]]; then
  echo "FAST profile active: narrowing seeds and limits"
  # Aim ~50% faster than previous FAST: cut seeds to 1 and halve eval samples
  SEEDS="${SEEDS_FAST:-123}"
  EPOCHS="${EPOCHS_FAST:-1}"
  LIMIT_EVAL="${LIMIT_EVAL_FAST:-1000}"
  AGG_ARR=( ${AGG_FAST:-max} )
  LAYERS_ARR=( ${LAYERS_FAST:-last_block} )
  DIMS_ARR=( ${DIMS_FAST:-8} )
  BD_ARR=( ${BD_FAST:-0.5 1.0} )
fi
LIMIT_ARGS=()
if [[ -n "$LIMIT_EVAL" ]]; then
  LIMIT_ARGS=(--limit-eval "$LIMIT_EVAL")
fi

echo "Profile=$([[ ${FAST:-0} -eq 1 ]] && echo FAST || echo FULL) PRESET=$PRESET Using PY=$PY DEVICE=$DEVICE BATCH=$BATCH EPOCHS=$EPOCHS LIMIT_EVAL=${LIMIT_EVAL:-none} SEEDS=[$SEEDS]" | tee "$OUTDIR/summary.txt"
echo "Sweep: agg=[${AGG_ARR[*]}] layers=[${LAYERS_ARR[*]}] D=[${DIMS_ARR[*]}] betaD=[${BD_ARR[*]}] K=$KVAL betaE=$BEVAL" | tee -a "$OUTDIR/summary.txt"

JSONL="$OUTDIR/results.jsonl"
CSV="$OUTDIR/results.csv"
echo "agg,layers,K,coding_dim,beta_entropy,beta_distance,seed,ood,method,auroc,aupr_out,fpr95,id_acc,latency_ms" > "$CSV"

# Iterate ablations; use internal runner to loop seeds per combo
for agg in "${AGG_ARR[@]}"; do
  for layers in "${LAYERS_ARR[@]}"; do
    for dim in "${DIMS_ARR[@]}"; do
      for bd in "${BD_ARR[@]}"; do
        RUN_DIR="$OUTDIR/run_${agg}_${layers}_D${dim}_bd${bd}"
        mkdir -p "$RUN_DIR"
        echo "== agg=$agg layers=$layers K=$KVAL D=$dim betaE=$BEVAL betaD=$bd seeds=[$SEEDS] ==" | tee -a "$OUTDIR/summary.txt"
        set +e
        "$PY" -m benchmarks.ood.cifar_resnet18 \
          --preset "$PRESET" \
          --device "$DEVICE" \
          --batch-size "$BATCH" \
          --epochs "$EPOCHS" \
          --seeds $SEEDS \
          --layers "$layers" \
          --agg "$agg" \
          --K "$KVAL" \
          --coding-dim "$dim" \
          --beta-length 1.0 \
          --beta-entropy "$BEVAL" \
          --beta-distance "$bd" \
          --outdir "$RUN_DIR" \
          "${LIMIT_ARGS[@]}" \
          2>&1 | tee "$RUN_DIR/run.log"
        RET=$?
        set -e
        if [ $RET -ne 0 ] || [ ! -f "$RUN_DIR/results.csv" ]; then
          echo "WARN: run failed for combo; see $RUN_DIR/run.log" | tee -a "$OUTDIR/summary.txt"
          continue
        fi
        # Append rows to aggregate CSV/JSONL with annotations. Read by column
        # name so extra audit columns in results.csv do not corrupt latency.
        python3 - "$RUN_DIR/results.csv" "$CSV" "$agg" "$layers" "$KVAL" "$dim" "$BEVAL" "$bd" << 'PY'
import csv
import sys

src, dst, agg, layers, k_val, dim, beta_entropy, beta_distance = sys.argv[1:]
with open(src, newline="", encoding="utf-8") as f_in, open(
    dst, "a", newline="", encoding="utf-8"
) as f_out:
    writer = csv.writer(f_out)
    for row in csv.DictReader(f_in):
        writer.writerow(
            [
                agg,
                layers,
                k_val,
                dim,
                beta_entropy,
                beta_distance,
                row.get("seed", ""),
                row.get("ood", ""),
                row.get("method", ""),
                row.get("auroc", ""),
                row.get("aupr_out", ""),
                row.get("fpr95", ""),
                row.get("id_acc", ""),
                row.get("latency_ms", ""),
            ]
        )
PY
        if [ -f "$RUN_DIR/results.jsonl" ]; then
          cat "$RUN_DIR/results.jsonl" >> "$JSONL"
        fi
      done
    done
  done
done

# Quick summary: best Nervecode combo by mean AUROC across OOD + seeds
if [ "$(wc -l < "$CSV")" -le 1 ]; then
  echo "No results collected (all combos failed)." | tee -a "$OUTDIR/summary.txt"
else
  OUT_SUMM=$(python3 - "$CSV" << 'PY'
import csv, statistics as st, sys
path=sys.argv[1]
rows=list(csv.DictReader(open(path)))
if not rows:
    print('No results collected.')
    raise SystemExit(0)
nc=[r for r in rows if r.get('method','').startswith('nervecode_')]
if not nc:
    print('No Nervecode rows present.')
    raise SystemExit(0)
G={}
for r in nc:
    key=(r['agg'], r['layers'], r['K'], r['coding_dim'], r['beta_distance'])
    G.setdefault(key, []).append(float(r['auroc']))
best=None; bm=-1.0
for k,v in G.items():
    m=st.mean(v)
    if m>bm: bm=m; best=k
print('Best Nervecode mean AUROC:', round(bm,3), 'for', best)
PY
  )
  echo "$OUT_SUMM" | tee -a "$OUTDIR/summary.txt"
fi

echo "Done. Results written to $OUTDIR" | tee -a "$OUTDIR/summary.txt"
