"""Helper scripts for local workflows and CI.

This package hosts small, self-contained utilities like `train_minimal.py` that are
useful during development and continuous integration. Making this a real package
avoids mypy's duplicate module detection when running `mypy .` from the repo root.
"""
