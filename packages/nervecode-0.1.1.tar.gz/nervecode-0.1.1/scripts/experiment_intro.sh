#!/usr/bin/env bash

# Intro experiment driver: Toy MLP (slam-dunk) + CNN (CIFAR-10 vs OOD)
# - Runs a strong toy MLP config and captures AUROC/FPR-like stats
# - Runs a CPU-friendly CNN config with learned 3-feature combiner (Energy+MSP+Nervecode)
# - Emits a lightweight Markdown report under docs/benchmarks/

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
cd "$REPO_ROOT"

PY="${PYTHON:-python3}"

STAMP="$(date +%Y%m%d-%H%M%S)"
OUTROOT="runs/intro-exp-$STAMP"
DOC_OUT="docs/benchmarks/intro-$STAMP.md"
mkdir -p "$OUTROOT" "$(dirname "$DOC_OUT")"

echo "Intro experiment (CPU-friendly) — outputs -> $OUTROOT" | tee "$OUTROOT/summary.txt"

###############################################################################
# 1) Toy MLP (benchmarks/ood/simple.py)
###############################################################################
echo "== Toy MLP (Gaussians) ==" | tee -a "$OUTROOT/summary.txt"

TOY_LOG="$OUTROOT/toy.log"
set +e
"$PY" -m benchmarks.ood.simple \
  --epochs "${TOY_EPOCHS:-20}" \
  --device "${DEVICE:-cpu}" \
  --seed "${SEED:-123}" \
  --agg "${TOY_AGG:-max}" \
  --layers "${TOY_LAYERS:-all_linear}" \
  --K "${TOY_K:-16}" \
  --coding-dim "${TOY_D:-8}" \
  --beta-length 1.0 \
  --beta-entropy "${TOY_BE:-0.0}" \
  --json 2>&1 | tee "$TOY_LOG"
RET=$?
set -e
TOY_JSON=$(grep -E '^\{.*\}$' "$TOY_LOG" | tail -n 1 || true)
if [ -z "$TOY_JSON" ]; then
  echo "WARN: Toy run produced no JSON; see $TOY_LOG" | tee -a "$OUTROOT/summary.txt"
else
  echo "$TOY_JSON" > "$OUTROOT/toy_result.json"
fi

###############################################################################
# 2) CNN (CIFAR-10 vs DTD, CIFAR-100) with learned combiner (no ODIN)
###############################################################################
echo "== CNN (CIFAR-10 vs OOD) ==" | tee -a "$OUTROOT/summary.txt"

EPOCHS="${EPOCHS:-10}"
SEED="${SEED:-123}"
DEVICE="${DEVICE:-cpu}"
PRESET="${PRESET:-demo}"
LIMIT_EVAL="${LIMIT_EVAL:-1000}"
LAYERS="${LAYERS:-last_block}"
AGG="${AGG:-max}"
KVAL="${KVAL:-16}"
CDIM="${CDIM:-8}"
BE="${BE:-0.0}"
BD="${BD:-1.0}"
TEMP="${TEMP:-2.0}"

CNN_OUTDIR="$OUTROOT/cifar-ood"
mkdir -p "$CNN_OUTDIR"

set +e
"$PY" -m benchmarks.ood.cifar_resnet18 \
  --preset "$PRESET" \
  --device "$DEVICE" \
  --epochs "$EPOCHS" \
  --seeds "$SEED" \
  --layers "$LAYERS" \
  --agg "$AGG" \
  --K "$KVAL" \
  --coding-dim "$CDIM" \
  --beta-length 1.0 \
  --beta-entropy "$BE" \
  --beta-distance "$BD" \
  --temperature "$TEMP" \
  --limit-eval "$LIMIT_EVAL" \
  --no-odin \
  --learn-ood-calibrated-combo3 \
  --save-combiner \
  --outdir "$CNN_OUTDIR" \
  --verbose 2>&1 | tee "$CNN_OUTDIR/run.log"
RET_CNN=$?
set -e
if [ $RET_CNN -ne 0 ] || [ ! -f "$CNN_OUTDIR/results.csv" ]; then
  echo "WARN: CNN run failed; see $CNN_OUTDIR/run.log" | tee -a "$OUTROOT/summary.txt"
fi

# Summarize a compact table for methods of interest
if [ -f "$CNN_OUTDIR/results.csv" ]; then
  # Run summary in non-errexit mode to avoid aborting the whole script
  set +e
  "$PY" - "$CNN_OUTDIR/results.csv" "$CNN_OUTDIR/summary_methods.csv" << 'PY'
import csv, sys, os

def main(argv):
    try:
        if len(argv) < 3:
            raise ValueError("missing args: <results.csv> <out.csv>")
        path = argv[1]
        out = argv[2]
        if not path or not isinstance(path, str):
            raise TypeError("results path is not a string")
        if not out or not isinstance(out, str):
            raise TypeError("output path is not a string")
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        with open(path, 'r', encoding='utf-8') as f:
            rows = list(csv.DictReader(f))
        methods = {
            'msp',
            'energy',
            'maxlogit',
            'gen',
            'knn',
            'residual_vim_lite',
            'nervecode_max',
            'oracle_ood_calibrated_combo_lr3',
            'combo_loaded_unverified',
        }
        keep = [
            r for r in rows
            if r.get('method') in methods
            or str(r.get('method', '')).startswith('combo_id_zscore_equal')
        ]
        with open(out, 'w', encoding='utf-8') as f:
            f.write('ood,method,auroc,aupr_out,fpr95,latency_ms\n')
            for r in keep:
                try:
                    f.write(
                        f"{r['ood']},{r['method']},{r['auroc']},"
                        f"{r.get('aupr_out', '')},{r['fpr95']},{r['latency_ms']}\n"
                    )
                except Exception:
                    # Skip malformed rows
                    continue
        print(f"Wrote summary CSV -> {out}")
    except Exception as e:
        print(f"[WARN] Summary generation skipped: {e}", file=sys.stderr)

if __name__ == '__main__':
    main(sys.argv)
PY
  SUM_RET=$?
  set -e
  if [ $SUM_RET -ne 0 ]; then
    echo "WARN: summary table generation failed (non-fatal)." | tee -a "$OUTROOT/summary.txt"
  fi
fi

###############################################################################
# 3) Easier CNN OOD (MNIST → FashionMNIST/KMNIST)
###############################################################################
echo "== MNIST OOD (FashionMNIST, KMNIST) ==" | tee -a "$OUTROOT/summary.txt"
if [ "${SKIP_MNIST:-0}" = "1" ]; then
  echo "(Skipping MNIST step — SKIP_MNIST=1)" | tee -a "$OUTROOT/summary.txt"
  MNIST_OUTDIR="$OUTROOT/mnist-ood"
else
  MNIST_OUTDIR="$OUTROOT/mnist-ood"
  mkdir -p "$MNIST_OUTDIR"
  set +e
  "$PY" -m benchmarks.ood.mnist_cnn \
    --device "$DEVICE" \
    --epochs "${MNIST_EPOCHS:-5}" \
    --seed "$SEED" \
    --layers "${MNIST_LAYERS:-last_conv}" \
    --agg "${MNIST_AGG:-max}" \
    --K "${MNIST_K:-16}" \
    --coding-dim "${MNIST_D:-8}" \
    --temperature "${MNIST_TEMP:-2.0}" \
    --limit-eval "${MNIST_LIMIT:-1000}" \
    --outdir "$MNIST_OUTDIR" \
    2>&1 | tee "$MNIST_OUTDIR/run.log"
  RET_M=$?
  set -e
  if [ $RET_M -ne 0 ] || [ ! -f "$MNIST_OUTDIR/results.csv" ]; then
    echo "WARN: MNIST run failed; see $MNIST_OUTDIR/run.log" | tee -a "$OUTROOT/summary.txt"
  fi
fi

###############################################################################
# 4) Emit Markdown report
###############################################################################
{
  echo "# Nervecode Intro Experiment ($STAMP)"
  echo
  echo "## Summary"
  echo "- CPU-friendly end-to-end validation: Toy MLP (slam-dunk) + CIFAR-10 vs OOD (DTD, CIFAR-100)."
  echo "- Nervecode: single-pass, observe-only layer wrappers; learned 3-feature combiner (Energy+MSP+NC)."
  echo "- Artifacts live under $OUTROOT."
  echo
  echo "## Commands"
  echo "### Toy MLP"
  echo '```'
  echo "$PY -m benchmarks.ood.simple --epochs ${TOY_EPOCHS:-20} --device $DEVICE --seed $SEED --agg ${TOY_AGG:-max} --layers ${TOY_LAYERS:-all_linear} --K ${TOY_K:-16} --coding-dim ${TOY_D:-8} --beta-entropy ${TOY_BE:-0.0} --json"
  echo '```'
  echo
  echo "### CNN (CIFAR-10 vs OOD; no ODIN)"
  echo '```'
  echo "$PY -m benchmarks.ood.cifar_resnet18 --preset $PRESET --device $DEVICE --epochs $EPOCHS --seeds $SEED --layers $LAYERS --agg $AGG --K $KVAL --coding-dim $CDIM --beta-entropy $BE --beta-distance $BD --temperature $TEMP --limit-eval $LIMIT_EVAL --no-odin --learn-ood-calibrated-combo3 --save-combiner"
  echo '```'
  echo
  echo "## Toy MLP Result"
  if [ -s "$OUTROOT/toy_result.json" ]; then
    echo "Toy JSON:"
    echo
    echo '\`\`\`json'
    cat "$OUTROOT/toy_result.json"
    echo
    echo '\`\`\`'
  else
    echo "(Toy result JSON unavailable — see $TOY_LOG)"
  fi
  echo
  echo "## CNN Results (selected methods)"
  if [ -f "$CNN_OUTDIR/summary_methods.csv" ]; then
    echo "CSV: $CNN_OUTDIR/summary_methods.csv"
    echo
    echo '\`\`\`'
    cat "$CNN_OUTDIR/summary_methods.csv"
    echo '\`\`\`'
  else
    echo "(CNN results unavailable — see $CNN_OUTDIR/run.log)"
  fi
  echo
  echo "## Layerwise Analysis"
  LAYER_FIG="$(ls -1 "$CNN_OUTDIR"/layerwise_*.png 2>/dev/null | head -n 1 || true)"
  if [ -n "$LAYER_FIG" ]; then
    echo "Figure saved: $LAYER_FIG"
  else
    echo "(Layerwise figure not generated)"
  fi
  echo
  echo "## Notes"
  echo "- Latency excludes ODIN; combos sum constituent latencies."
  echo "- For GPU runs, increase epochs/aug and consider ODIN in an appendix."
  echo
  echo "## Easier CNN OOD (MNIST → FashionMNIST/KMNIST)"
  if [ -f "$MNIST_OUTDIR/results.csv" ]; then
    echo "CSV: $MNIST_OUTDIR/results.csv"
    echo
    echo '\`\`\`'
    sed -n '1,40p' "$MNIST_OUTDIR/results.csv"
    echo '\`\`\`'
  else
    echo "(MNIST results unavailable — see $MNIST_OUTDIR/run.log)"
  fi
} > "$DOC_OUT"

echo "Report written: $DOC_OUT" | tee -a "$OUTROOT/summary.txt"

echo "Done."
