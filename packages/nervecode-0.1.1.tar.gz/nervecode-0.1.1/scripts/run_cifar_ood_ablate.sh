#!/usr/bin/env bash

# Compact CIFAR-10 OOD demo ablation driver (no ODIN) to sweep:
# {layers ∈ [last_block, last_two_blocks]} × {agg ∈ [max, mean]} ×
# {D ∈ [8,16]} × {K ∈ [16,32]} × {betaD ∈ [0.5,1.0]}.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
cd "$REPO_ROOT"

PY="${PYTHON:-python3}"
PRESET="${PRESET:-demo}"
DEVICE="${DEVICE:-cpu}"
SEED="${SEED:-123}"
EPOCHS="${EPOCHS:-10}"
BATCH="${BATCH:-256}"
LIMIT_EVAL="${LIMIT_EVAL:-1000}"
TEMP="${TEMP:-1.0}"
# Combination alpha: single value (ALPHA) or sweep (ALPHAS)
ALPHA="${ALPHA:-}"
ALPHAS_ARR=( ${ALPHAS:-} )

LAYERS_ARR=( ${LAYERS:-last_block last_two_blocks} )
AGG_ARR=( ${AGG:-max mean} )
DIMS_ARR=( ${DIMS:-8 16} )
K_ARR=( ${KVALS:-16 32} )
BD_ARR=( ${BD:-0.5 1.0} )
BEVAL="${BEVAL:-1.0}"

STAMP="$(date +%Y%m%d-%H%M%S)"
OUTDIR="${OUTDIR:-runs/cifar-ood-ablate-$STAMP}"
mkdir -p "$OUTDIR"

if [ ${#ALPHAS_ARR[@]} -gt 0 ]; then
  echo "Ablation (no ODIN): PRESET=$PRESET DEVICE=$DEVICE EPOCHS=$EPOCHS SEED=$SEED LIMIT_EVAL=$LIMIT_EVAL TEMP=$TEMP ALPHAS=[${ALPHAS_ARR[*]}]" | tee "$OUTDIR/summary.txt"
else
  echo "Ablation (no ODIN): PRESET=$PRESET DEVICE=$DEVICE EPOCHS=$EPOCHS SEED=$SEED LIMIT_EVAL=$LIMIT_EVAL TEMP=$TEMP ALPHA=${ALPHA:-none}" | tee "$OUTDIR/summary.txt"
fi
echo "layers=[${LAYERS_ARR[*]}] agg=[${AGG_ARR[*]}] D=[${DIMS_ARR[*]}] K=[${K_ARR[*]}] betaD=[${BD_ARR[*]}]" | tee -a "$OUTDIR/summary.txt"

CSV="$OUTDIR/results.csv"
JSONL="$OUTDIR/results.jsonl"
# Include temperature and alpha explicitly in the aggregate CSV
echo "layers,agg,K,coding_dim,beta_distance,temperature,alpha,seed,ood,method,auroc,aupr_out,fpr95,id_acc,latency_ms" > "$CSV"

append_results_csv() {
  local src="$1"
  local alpha="$2"
  python3 - "$src" "$CSV" "$layers" "$agg" "$K" "$dim" "$bd" "$TEMP" "$alpha" << 'PY'
import csv
import sys

src, dst, layers, agg, k_val, dim, beta_distance, temp, alpha = sys.argv[1:]
with open(src, newline="", encoding="utf-8") as f_in, open(
    dst, "a", newline="", encoding="utf-8"
) as f_out:
    writer = csv.writer(f_out)
    for row in csv.DictReader(f_in):
        writer.writerow(
            [
                layers,
                agg,
                k_val,
                dim,
                beta_distance,
                temp,
                alpha,
                row.get("seed", ""),
                row.get("ood", ""),
                row.get("method", ""),
                row.get("auroc", ""),
                row.get("aupr_out", ""),
                row.get("fpr95", ""),
                row.get("id_acc", ""),
                row.get("latency_ms", ""),
            ]
        )
PY
}

for layers in "${LAYERS_ARR[@]}"; do
  for agg in "${AGG_ARR[@]}"; do
    for dim in "${DIMS_ARR[@]}"; do
      for K in "${K_ARR[@]}"; do
        for bd in "${BD_ARR[@]}"; do
          if [ ${#ALPHAS_ARR[@]} -gt 0 ]; then
            for A in "${ALPHAS_ARR[@]}"; do
              RUN_DIR="$OUTDIR/run_${layers}_${agg}_K${K}_D${dim}_bd${bd}_a${A}"
              mkdir -p "$RUN_DIR"
              echo "== layers=$layers agg=$agg K=$K D=$dim betaD=$bd alpha=$A ==" | tee -a "$OUTDIR/summary.txt"
              set +e
              "$PY" -m benchmarks.ood.cifar_resnet18 \
                --preset "$PRESET" \
                --device "$DEVICE" --epochs "$EPOCHS" --seeds "$SEED" \
                --batch-size "$BATCH" --limit-eval "$LIMIT_EVAL" \
                --layers "$layers" --agg "$agg" \
                --K "$K" --coding-dim "$dim" \
                --beta-length 1.0 --beta-entropy "$BEVAL" --beta-distance "$bd" \
                --temperature "$TEMP" \
                --comb-alpha "$A" \
                --no-odin \
                --outdir "$RUN_DIR" \
                2>&1 | tee "$RUN_DIR/run.log"
              RET=$?
              set -e
              if [ $RET -ne 0 ] || [ ! -f "$RUN_DIR/results.csv" ]; then
                echo "WARN: run failed for combo; see $RUN_DIR/run.log" | tee -a "$OUTDIR/summary.txt"
                continue
              fi
              append_results_csv "$RUN_DIR/results.csv" "$A"
              if [ -f "$RUN_DIR/results.jsonl" ]; then
                cat "$RUN_DIR/results.jsonl" >> "$JSONL"
              fi
            done
          else
            RUN_DIR="$OUTDIR/run_${layers}_${agg}_K${K}_D${dim}_bd${bd}"
            mkdir -p "$RUN_DIR"
            echo "== layers=$layers agg=$agg K=$K D=$dim betaD=$bd ==" | tee -a "$OUTDIR/summary.txt"
            set +e
            "$PY" -m benchmarks.ood.cifar_resnet18 \
              --preset "$PRESET" \
              --device "$DEVICE" --epochs "$EPOCHS" --seeds "$SEED" \
              --batch-size "$BATCH" --limit-eval "$LIMIT_EVAL" \
              --layers "$layers" --agg "$agg" \
              --K "$K" --coding-dim "$dim" \
              --beta-length 1.0 --beta-entropy "$BEVAL" --beta-distance "$bd" \
              --temperature "$TEMP" \
              ${ALPHA:+--comb-alpha "$ALPHA"} \
              --no-odin \
              --outdir "$RUN_DIR" \
              2>&1 | tee "$RUN_DIR/run.log"
            RET=$?
            set -e
            if [ $RET -ne 0 ] || [ ! -f "$RUN_DIR/results.csv" ]; then
              echo "WARN: run failed for combo; see $RUN_DIR/run.log" | tee -a "$OUTDIR/summary.txt"
              continue
            fi
            append_results_csv "$RUN_DIR/results.csv" "${ALPHA:-}"
            if [ -f "$RUN_DIR/results.jsonl" ]; then
              cat "$RUN_DIR/results.jsonl" >> "$JSONL"
            fi
          fi
        done
      done
    done
  done
done

echo "Done. Results written to $OUTDIR" | tee -a "$OUTDIR/summary.txt"
