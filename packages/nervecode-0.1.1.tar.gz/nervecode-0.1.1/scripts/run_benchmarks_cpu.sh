#!/usr/bin/env bash

# Orchestrate Nervecode CPU benchmarks within ~2.5 hours on a mid‑range laptop.
#
# Includes:
#  - Overhead benchmark (base vs instrumented)
#  - Scaling study (width × coding_dim × num_layers grid)
#  - Minimal OOD harness (AUROC)
#  - Ablation sweep (K, D, T, layer strategy)
#
# Tunables via environment variables:
#  DEVICE=cpu|cuda (default: cpu)
#  THREADS=8 (OMP/MKL threads)
#  OUTDIR=runs/benchmarks-$(date +%Y%m%d-%H%M%S)
#
# You can also override per‑task knobs, e.g.:
#  OVERHEAD_ITERS=60 OVERHEAD_WARMUP=5
#  SCALING_WIDTHS="256,512,768" SCALING_CDIMS="auto,64" SCALING_LAYERS="0,1,2" SCALING_ITERS=25 SCALING_WARMUP=3
#  OOD_EPOCHS=2
#  ABLATE_K="8,16" ABLATE_DIMS="auto,8" ABLATE_TEMPS="0.7,1.0" ABLATE_LAYERS="first_linear,all_linear"

set -euo pipefail

# Resolve repo root relative to this script
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
cd "$REPO_ROOT"

# Python executable
PY="${PYTHON:-python}"

# Device and threads
DEVICE="${DEVICE:-cpu}"
THREADS="${THREADS:-8}"
export OMP_NUM_THREADS="$THREADS"
export MKL_NUM_THREADS="$THREADS"

# Output directory
STAMP="$(date +%Y%m%d-%H%M%S)"
OUTDIR="${OUTDIR:-runs/benchmarks-$STAMP}"
mkdir -p "$OUTDIR"

echo "Using PY=$PY DEVICE=$DEVICE THREADS=$THREADS OUTDIR=$OUTDIR"

# Quick sanity: torch import
if ! "$PY" -c "import torch" >/dev/null 2>&1; then
  echo "error: PyTorch is not importable in this environment" >&2
  exit 1
fi

time_cmd() {
  /usr/bin/time -p "$@"
}

log_section() {
  local name="$1"; shift
  echo "==== $name ====" | tee -a "$OUTDIR/summary.txt"
}

# -------------------------- Time budgets (minutes) ---------------------------
TOTAL_BUDGET_MIN="${TOTAL_BUDGET_MIN:-150}"
OVERHEAD_BUDGET_MIN="${OVERHEAD_BUDGET_MIN:-10}"
SCALING_BUDGET_MIN="${SCALING_BUDGET_MIN:-90}"
OOD_BUDGET_MIN="${OOD_BUDGET_MIN:-20}"
ABLATED_BUDGET_MIN="${ABLATED_BUDGET_MIN:-30}"

# -------------------------- Overhead benchmark -------------------------------
OVERHEAD_WARMUP="${OVERHEAD_WARMUP:-5}"
OVERHEAD_BS="${OVERHEAD_BS:-128}"
OVERHEAD_IN="${OVERHEAD_IN:-512}"
OVERHEAD_HID="${OVERHEAD_HID:-1024}"
OVERHEAD_OUT="${OVERHEAD_OUT:-10}"

log_section "Overhead benchmark"
# Pilot to estimate per-iter ms
PILOT_ITERS=${OVERHEAD_PILOT_ITERS:-50}
OV_JSON=$(
  "$PY" -m benchmarks.overhead.overhead \
    --iters "$PILOT_ITERS" \
    --warmup "$OVERHEAD_WARMUP" \
    --batch-size "$OVERHEAD_BS" \
    --in-dim "$OVERHEAD_IN" \
    --hidden-dim "$OVERHEAD_HID" \
    --out-dim "$OVERHEAD_OUT" \
    --device "$DEVICE" \
    --json 2>/dev/null | tail -n 1)
SUM_MS=$(
  "$PY" - <<'PY'
import json,sys
try:
    d=json.loads(sys.stdin.read())
    base=float(d['per_iter_ms']['base'])
    inst=float(d['per_iter_ms']['instrumented'])
    print(base+inst)
except Exception:
    print(8.0)
PY
<<< "$OV_JSON")
OVERHEAD_ITERS=$(
  "$PY" - <<PY
sum_ms=${SUM_MS:-8.0}
budget_min=${OVERHEAD_BUDGET_MIN:-10}
iters=int((budget_min*60*1000)/max(1e-6,float(sum_ms)))
print(max(200, min(iters, 500000)))
PY
)
echo "Calibrated OVERHEAD_ITERS=$OVERHEAD_ITERS (sum_ms=${SUM_MS})" | tee -a "$OUTDIR/summary.txt"
set +e
time_cmd "$PY" -m benchmarks.overhead.overhead \
  --iters "$OVERHEAD_ITERS" \
  --warmup "$OVERHEAD_WARMUP" \
  --batch-size "$OVERHEAD_BS" \
  --in-dim "$OVERHEAD_IN" \
  --hidden-dim "$OVERHEAD_HID" \
  --out-dim "$OVERHEAD_OUT" \
  --device "$DEVICE" \
  --json \
  2>&1 | tee "$OUTDIR/overhead.log"
RET=$?
set -e
if [ $RET -ne 0 ]; then echo "Overhead benchmark failed" | tee -a "$OUTDIR/summary.txt"; fi

# ---------------------------- Scaling study ----------------------------------
SCALING_WIDTHS="${SCALING_WIDTHS:-256,512,768}"
SCALING_CDIMS="${SCALING_CDIMS:-auto,64}"
SCALING_LAYERS="${SCALING_LAYERS:-0,1,2}"
SCALING_DEPTH="${SCALING_DEPTH:-3}"
SCALING_K="${SCALING_K:-16}"
SCALING_ITERS="${SCALING_ITERS:-25}"
SCALING_WARMUP="${SCALING_WARMUP:-3}"
SCALING_BS="${SCALING_BS:-128}"
SCALING_IN="${SCALING_IN:-512}"
SCALING_OUT="${SCALING_OUT:-10}"

log_section "Scaling study"
# Pilot to estimate instrumented per-iter ms (take first JSON row)
SCALING_PILOT_ITERS=${SCALING_PILOT_ITERS:-25}
set +e
SC_JSON=$(
  "$PY" -m benchmarks.scaling.study \
    --widths "$SCALING_WIDTHS" \
    --coding-dims "$SCALING_CDIMS" \
    --layers "$SCALING_LAYERS" \
    --depth "$SCALING_DEPTH" \
    --K "$SCALING_K" \
    --iters "$SCALING_PILOT_ITERS" \
    --batch-size "$SCALING_BS" \
    --in-dim "$SCALING_IN" \
    --out-dim "$SCALING_OUT" \
    --device "$DEVICE" \
    --warmup "$SCALING_WARMUP" \
    --json 2>/dev/null | tail -n 1)
RET=$?
set -e
[ $RET -ne 0 ] && SC_JSON=""
SC_INST_MS=$(
  "$PY" - <<'PY'
import json,sys
try:
    d=json.loads(sys.stdin.read())
    print(float(d['per_iter_ms']['instrumented']))
except Exception:
    print(2.0)
PY
<<< "$SC_JSON")
NUM_CONFIGS=$(
  "$PY" - <<PY
widths=len("$SCALING_WIDTHS".split(','))
cdims=len("$SCALING_CDIMS".split(','))
layers=len("$SCALING_LAYERS".split(','))
print(int(widths*cdims*layers))
PY
)
SCALING_ITERS=$(
  "$PY" - <<PY
inst_ms=${SC_INST_MS:-2.0}
budget_min=${SCALING_BUDGET_MIN:-90}
configs=${NUM_CONFIGS:-21}
iters=int((budget_min*60*1000)/max(1e-6,float(inst_ms))*1.0/configs)
print(max(50, min(iters, 200000)))
PY
)
echo "Calibrated SCALING_ITERS=$SCALING_ITERS (inst_ms=${SC_INST_MS} over ${NUM_CONFIGS} configs)" | tee -a "$OUTDIR/summary.txt"
set +e
time_cmd "$PY" -m benchmarks.scaling.study \
  --widths "$SCALING_WIDTHS" \
  --coding-dims "$SCALING_CDIMS" \
  --layers "$SCALING_LAYERS" \
  --depth "$SCALING_DEPTH" \
  --K "$SCALING_K" \
  --iters "$SCALING_ITERS" \
  --batch-size "$SCALING_BS" \
  --in-dim "$SCALING_IN" \
  --out-dim "$SCALING_OUT" \
  --device "$DEVICE" \
  --warmup "$SCALING_WARMUP" \
  --json \
  2>&1 | tee "$OUTDIR/scaling.log"
RET=$?
set -e
if [ $RET -ne 0 ]; then echo "Scaling study failed" | tee -a "$OUTDIR/summary.txt"; fi

# ----------------------------- OOD harness -----------------------------------
OOD_EPOCHS="${OOD_EPOCHS:-2}"
OOD_SEEDS="${OOD_SEEDS:-123}"

log_section "OOD harness (calibrated epochs)"
# Pilot to estimate epoch time
OOD_PILOT_EPOCHS=${OOD_PILOT_EPOCHS:-1}
start_ts=$(date +%s)
set +e
time_cmd "$PY" -m benchmarks.ood.simple --epochs "$OOD_PILOT_EPOCHS" --device "$DEVICE" --seed 123 --json \
  2>&1 | tee "$OUTDIR/ood_pilot.log"
set -e
end_ts=$(date +%s)
pilot_real=$(( end_ts - start_ts ))
[ $pilot_real -lt 1 ] && pilot_real=1
OOD_EPOCHS=$(
  "$PY" - <<PY
budget_min=${OOD_BUDGET_MIN:-20}
pilot=${pilot_real:-5}
epochs=int((budget_min*60)/max(1,int(pilot)))
print(max(1, min(epochs, 200)))
PY
)
echo "Calibrated OOD_EPOCHS=$OOD_EPOCHS (pilot ${pilot_real}s)" | tee -a "$OUTDIR/summary.txt"
set +e
time_cmd "$PY" -m benchmarks.ood.simple --epochs "$OOD_EPOCHS" --device "$DEVICE" --seed 123 --json \
  2>&1 | tee "$OUTDIR/ood_main.log"
RET=$?
set -e
if [ $RET -ne 0 ]; then echo "OOD harness failed" | tee -a "$OUTDIR/summary.txt"; fi

# ----------------------------- Ablation sweep --------------------------------
ABLATED_OUT="$OUTDIR/ablation.csv"
ABLATED_DS="${ABLATED_DS:-512}"
ABLATED_BS="${ABLATED_BS:-128}"
ABLATED_EPOCHS="${ABLATED_EPOCHS:-1}"
ABLATED_K="${ABLATED_K:-8,16}"
ABLATED_DIMS="${ABLATED_DIMS:-auto,8}"
ABLATED_TEMPS="${ABLATED_TEMPS:-0.7,1.0}"
ABLATED_LAYERS="${ABLATED_LAYERS:-first_linear,all_linear}"

log_section "Ablation sweep (calibrated epochs)"
# Pilot ablation with epochs=1
start_ts=$(date +%s)
set +e
time_cmd "$PY" scripts/ablate_grid.py \
  --K "$ABLATED_K" \
  --coding-dims "$ABLATED_DIMS" \
  --temperatures "$ABLATED_TEMPS" \
  --layers "$ABLATED_LAYERS" \
  --epochs 1 \
  --dataset-size "$ABLATED_DS" \
  --batch-size "$ABLATED_BS" \
  --out "$ABLATED_OUT" \
  2>&1 | tee "$OUTDIR/ablation_pilot.log"
set -e
end_ts=$(date +%s)
pilot_real=$(( end_ts - start_ts ))
[ $pilot_real -lt 1 ] && pilot_real=1
ABLATED_EPOCHS=$(
  "$PY" - <<PY
budget_min=${ABLATED_BUDGET_MIN:-30}
pilot=${pilot_real:-10}
epochs=int((budget_min*60)/max(1,int(pilot)))
print(max(1, min(epochs, 50)))
PY
)
echo "Calibrated ABLATED_EPOCHS=$ABLATED_EPOCHS (pilot ${pilot_real}s)" | tee -a "$OUTDIR/summary.txt"
set +e
time_cmd "$PY" scripts/ablate_grid.py \
  --K "$ABLATED_K" \
  --coding-dims "$ABLATED_DIMS" \
  --temperatures "$ABLATED_TEMPS" \
  --layers "$ABLATED_LAYERS" \
  --epochs "$ABLATED_EPOCHS" \
  --dataset-size "$ABLATED_DS" \
  --batch-size "$ABLATED_BS" \
  --out "$ABLATED_OUT" \
  2>&1 | tee "$OUTDIR/ablation.log"
RET=$?
set -e
if [ $RET -ne 0 ]; then echo "Ablation sweep failed" | tee -a "$OUTDIR/summary.txt"; fi

echo "Done. Outputs in $OUTDIR" | tee -a "$OUTDIR/summary.txt"
