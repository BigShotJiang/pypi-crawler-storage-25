"""Ablation sweep over codebook/coding params and layer selection.

This lightweight script runs a tiny, dataset-agnostic training loop (reusing
``scripts/train_minimal.py``) across a small grid varying:
- codebook size ``K``
- coding dimension ``D`` (with safe clamping per layer)
- assignment temperature ``T``
- layer selection strategy (e.g., "all_linear", "first_linear")

For each configuration it records a minimal quality metric (test accuracy on a
toy 2-D Gaussian classification task) and rough overhead proxies calculated
from the inserted wrappers (parameter overhead and a simple MACs estimate per
sample for the coding path). Results are written to CSV and also returned from
``run_ablation_grid`` for testability.

Usage examples:
- Default quick sweep (CPU, tiny grid):
  python scripts/ablate_grid.py --out runs/ablation.csv

- Custom grid:
  python scripts/ablate_grid.py \
    --K 8,16 --coding-dims auto,2 --temperatures 0.5,1.0 \
    --layers all_linear,first_linear --epochs 1 --dataset-size 256

Notes
- The script is guarded to skip gracefully when PyTorch is unavailable.
- Overhead metrics are closed-form approximations intended for relative
  comparison, not exact profiling (see ``benchmarks/overhead`` for timings).
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, TypedDict, cast


def _repo_bootstrap() -> None:
    # Ensure repository root is importable when running from source.
    root = str(Path(__file__).resolve().parent.parent)
    if root not in sys.path:
        sys.path.insert(0, root)


def _torch_ok() -> bool:
    try:
        import torch as _t  # type: ignore[import-not-found]
    except Exception:
        return False
    return hasattr(_t, "tensor") and hasattr(_t, "no_grad")


LayerStrategy = Literal[
    "all_linear",
    "all_conv",
    "first_linear",
    "last_linear",
]


class OverheadSummary(TypedDict):
    num_wrapped_layers: int
    param_overhead: int
    macs_overhead_per_sample: int
    activation_overhead_bytes_per_sample: int


@dataclass
class AblationConfig:
    Ks: list[int]
    coding_dims: list[str]  # entries: "auto" or integer string
    temperatures: list[float]
    layers: list[LayerStrategy]
    # Minimal training knobs
    device: str = "cpu"
    batch_size: int = 64
    epochs: int = 1
    lr: float = 1e-2
    dataset_size: int = 512
    calib_fraction: float = 0.25


@dataclass
class AblationResult:
    K: int
    coding_dim_request: str  # "auto" or integer string
    temperature: float
    layers: LayerStrategy
    test_accuracy: float
    seconds: float
    overhead: OverheadSummary


def _select_module_names(model: Any, strategy: LayerStrategy) -> list[str]:
    """Return dotted submodule names selected by the strategy.

    Supports a minimal set used for ablations; mirrors ``layers.wrap`` behavior
    for "all_linear"/"all_conv" and adds simple first/last variants for MLPs.
    """

    try:
        import torch.nn as nn  # type: ignore[import-not-found]
    except Exception:
        return []

    # Collect names matching a predicate
    names_linear = [n for n, m in model.named_modules() if isinstance(m, nn.Linear)]
    names_conv = [n for n, m in model.named_modules() if isinstance(m, nn.Conv2d)]

    if strategy == "all_linear":
        return [n for n in names_linear if n]  # exclude top-level ""
    if strategy == "all_conv":
        return [n for n in names_conv if n]
    if strategy == "first_linear":
        for n in names_linear:
            if n:
                return [n]
        return []
    if strategy == "last_linear":
        for n in reversed(names_linear):
            if n:
                return [n]
        return []
    return []


def _instrument_with_params(
    model: Any,
    *,
    K: int,
    coding_dim_req: str,  # "auto" or integer string
    temperature: float,
    strategy: LayerStrategy,
) -> Any:
    """In-place instrumentation mirroring ``layers.wrap`` with param overrides.

    The ``coding_dim_req`` is applied per layer with safe clamping:
    effective ``code_dim = min(requested, layer_out)`` when requested is an int;
    when ``"auto"``, the wrapper default is used (layer width / pooled channels).
    """

    try:
        import torch.nn as nn
    except Exception:
        return model

    from nervecode.layers.conv import CodingConv2d
    from nervecode.layers.linear import CodingLinear

    names = _select_module_names(model, strategy)
    for name in names:
        if not name:
            continue
        try:
            sub = model.get_submodule(name)
        except Exception:
            continue

        wrapper: Any | None = None
        if isinstance(sub, nn.Linear):
            code_dim: int | None
            if coding_dim_req == "auto":
                code_dim = None
            else:
                try:
                    req = int(coding_dim_req)
                except Exception:
                    req = sub.out_features  # fallback to safe default
                # Clamp to layer width to satisfy wrapper contract
                code_dim = min(int(sub.out_features), max(1, int(req)))
            wrapper = CodingLinear(
                sub, K=int(K), coding_dim=code_dim, temperature=float(temperature)
            )
        elif isinstance(sub, nn.Conv2d):
            code_dim_c: int | None
            if coding_dim_req == "auto":
                code_dim_c = None
            else:
                try:
                    req = int(coding_dim_req)
                except Exception:
                    req = sub.out_channels
                code_dim_c = min(int(sub.out_channels), max(1, int(req)))
            wrapper = CodingConv2d(
                sub, K=int(K), coding_dim=code_dim_c, temperature=float(temperature)
            )

        if wrapper is None:
            continue

        parent_path, leaf = [*name.rsplit(".", 1), ""][:2] if "." in name else ("", name)
        try:
            parent = model.get_submodule(parent_path) if parent_path else model
        except Exception:
            continue
        if hasattr(parent, leaf):
            setattr(parent, leaf, wrapper)
        else:
            # Sequential/ModuleDict indices
            parent._modules[leaf] = wrapper

    return model


def _compute_overhead(model: Any) -> OverheadSummary:
    """Return rough overhead proxies from present wrappers.

    The estimates are per-forward and summed over wrappers:
    - param_overhead: K*D plus optional projection params when present
    - macs_overhead_per_sample: approx projection MACs + 2*K*D + K (softmax)
    - activation_overhead_bytes_per_sample: float bytes for (D + K)
    """

    try:
        from nervecode.layers.base import BaseCodingWrapper
    except Exception:
        # No wrappers present or package unavailable
        return {
            "num_wrapped_layers": 0,
            "param_overhead": 0,
            "macs_overhead_per_sample": 0,
            "activation_overhead_bytes_per_sample": 0,
        }

    total_params = 0
    total_macs = 0
    total_act_bytes = 0
    count = 0

    # Walk modules and aggregate per-wrapper stats
    for _name, m in getattr(model, "named_modules", lambda: [])():
        if not isinstance(m, BaseCodingWrapper):
            continue
        count += 1
        codebook = getattr(m, "codebook", None)
        assignment = getattr(m, "assignment", None)
        if codebook is None or assignment is None:
            continue
        K = int(getattr(codebook, "K", 0))
        D = int(getattr(codebook, "code_dim", 0))

        # Parameter overhead: codebook centers + optional projection
        proj_params = 0
        proj = getattr(m, "_projection", None)
        if proj is not None and hasattr(proj, "weight"):
            try:
                w = cast(Any, proj.weight)
                proj_params = int(w.numel())
            except Exception:
                proj_params = 0
        total_params += K * D + proj_params

        # MACs per sample: projection + distances + softmax (approx.)
        if proj is not None and hasattr(proj, "weight"):
            try:
                w = cast(Any, proj.weight)
                out_f, code_d = int(w.shape[0]), int(w.shape[1])
                total_macs += out_f * code_d
            except Exception:
                pass
        total_macs += 2 * K * D  # distances approx.
        total_macs += K  # softmax/logsumexp small cost

        # Activations: pooled/reduced vector (D) + soft code (K)
        total_act_bytes += (D + K) * 4  # assume float32

    return {
        "num_wrapped_layers": int(count),
        "param_overhead": int(total_params),
        "macs_overhead_per_sample": int(total_macs),
        "activation_overhead_bytes_per_sample": int(total_act_bytes),
    }


def _evaluate_accuracy(wrapped: Any, test_loader: Iterable[tuple[Any, Any]], device: str) -> float:
    try:
        import torch
    except Exception:
        return 0.0

    correct = 0
    total = 0
    dev = torch.device(device)
    with torch.no_grad():
        for xb, yb in test_loader:
            if hasattr(xb, "to"):
                xb = xb.to(dev)
            if hasattr(yb, "to"):
                yb = yb.to(dev)
            logits = wrapped.forward(xb)
            preds = getattr(logits, "argmax", lambda dim=1: None)(dim=1)
            if preds is None:
                continue
            correct += int((preds == yb).sum().item())
            total += int(yb.shape[0])
            # keep test tiny and fast
            if total >= 256:
                break
    return float(correct) / float(total) if total > 0 else 0.0


def run_ablation_grid(cfg: AblationConfig) -> list[AblationResult]:
    """Run the ablation grid and return structured results.

    Uses the built-in toy dataset and model from ``scripts/train_minimal.py``
    to keep runs fast. Each configuration performs a short training run
    and a tiny test pass for a coarse accuracy estimate.
    """

    if not _torch_ok():  # pragma: no cover - environment guard
        return []

    # Local imports after repo bootstrap
    from scripts.train_minimal import (  # noqa: I001
        _builtin_make_loaders,
        _builtin_make_model,
        Config as TrainCfg,
        train_and_calibrate,
    )

    results: list[AblationResult] = []

    for K in cfg.Ks:
        for cd_req in cfg.coding_dims:
            for T in cfg.temperatures:
                for strategy in cfg.layers:
                    # Build + instrument model with requested params
                    base_model = _builtin_make_model(TrainCfg())
                    model = _instrument_with_params(
                        base_model,
                        K=int(K),
                        coding_dim_req=str(cd_req),
                        temperature=float(T),
                        strategy=strategy,
                    )

                    def _model_fn(_cfg: TrainCfg, m: Any = model) -> Any:
                        return m

                    # Prepare loaders and run a short train+calib
                    train_cfg = TrainCfg(
                        device=str(cfg.device),
                        batch_size=int(cfg.batch_size),
                        epochs=int(cfg.epochs),
                        lr=float(cfg.lr),
                        coding_loss_weight=0.1,
                        dataset_size=int(cfg.dataset_size),
                        calib_fraction=float(cfg.calib_fraction),
                        wrap="none",  # prevent extra instrumentation inside train
                    )

                    t0 = time.perf_counter()
                    wrapped, _calib = train_and_calibrate(
                        train_cfg, dataloaders_fn=None, model_fn=_model_fn
                    )
                    t1 = time.perf_counter()
                    if wrapped is None:
                        continue

                    # Evaluate quick test accuracy
                    _train, _calib_dl, test_loader = _builtin_make_loaders(train_cfg)
                    acc = _evaluate_accuracy(wrapped, test_loader, device=train_cfg.device)

                    # Overhead proxies from wrappers
                    ov = _compute_overhead(
                        wrapped._model if hasattr(wrapped, "_model") else wrapped
                    )

                    results.append(
                        AblationResult(
                            K=int(K),
                            coding_dim_request=str(cd_req),
                            temperature=float(T),
                            layers=strategy,
                            test_accuracy=float(acc),
                            seconds=float(t1 - t0),
                            overhead=ov,
                        )
                    )

    return results


def _parse_csv_list(s: str) -> list[str]:
    return [p.strip() for p in s.split(",") if p.strip()]


def _main(argv: list[str] | None = None) -> int:
    _repo_bootstrap()
    p = argparse.ArgumentParser(description="Ablation sweep over coding params and layer selection")
    p.add_argument("--K", dest="Ks", default="8,16", help="Comma-separated codebook sizes")
    p.add_argument(
        "--coding-dims",
        default="auto",
        help="Comma-separated coding dims: integers or 'auto' for layer default",
    )
    p.add_argument(
        "--temperatures",
        default="1.0",
        help="Comma-separated temperatures for soft assignment",
    )
    p.add_argument(
        "--layers",
        default="all_linear",
        help=("Comma-separated layer strategies: all_linear,first_linear,last_linear,all_conv"),
    )
    p.add_argument("--device", default="cpu")
    p.add_argument("--epochs", type=int, default=1)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--lr", type=float, default=1e-2)
    p.add_argument("--dataset-size", type=int, default=512)
    p.add_argument("--calib-fraction", type=float, default=0.25)
    p.add_argument("--out", type=str, default="", help="Optional CSV output path")
    args = p.parse_args(argv)

    if not _torch_ok():
        print("torch not available; skipping ablation sweep")
        return 0

    cfg = AblationConfig(
        Ks=[int(x) for x in _parse_csv_list(str(args.Ks))],
        coding_dims=_parse_csv_list(str(args.coding_dims)),
        temperatures=[float(x) for x in _parse_csv_list(str(args.temperatures))],
        layers=[cast(LayerStrategy, s) for s in _parse_csv_list(str(args.layers))],
        device=str(args.device),
        batch_size=int(args.batch_size),
        epochs=int(args.epochs),
        lr=float(args.lr),
        dataset_size=int(args.dataset_size),
        calib_fraction=float(args.calib_fraction),
    )

    res = run_ablation_grid(cfg)
    if not res:
        print("no results (environment limitations)")
        return 0

    # Optional CSV write
    out_path = str(args.out).strip()
    if out_path:
        out = Path(out_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        # Flatten dicts for easy CSV
        fieldnames = [
            "K",
            "coding_dim_request",
            "temperature",
            "layers",
            "test_accuracy",
            "seconds",
            "num_wrapped_layers",
            "param_overhead",
            "macs_overhead_per_sample",
            "activation_overhead_bytes_per_sample",
        ]
        with out.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for r in res:
                row = {
                    "K": r.K,
                    "coding_dim_request": r.coding_dim_request,
                    "temperature": r.temperature,
                    "layers": r.layers,
                    "test_accuracy": f"{r.test_accuracy:.6f}",
                    "seconds": f"{r.seconds:.6f}",
                    **r.overhead,
                }
                w.writerow(row)
        print(f"wrote {len(res)} rows to {out}")

    # Human summary
    for r in res:
        print(
            f"K={r.K} D={r.coding_dim_request} T={r.temperature} layers={r.layers} "
            f"acc={r.test_accuracy:.3f} wrapped={r.overhead['num_wrapped_layers']} "
            f"params+={r.overhead['param_overhead']} macs+={r.overhead['macs_overhead_per_sample']}"
        )
    return 0


if __name__ == "__main__":  # pragma: no cover
    _repo_bootstrap()
    raise SystemExit(_main(sys.argv[1:]))
