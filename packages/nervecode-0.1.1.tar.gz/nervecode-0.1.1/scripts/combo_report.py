"""Render a P4 combo ablation report from benchmark ``results.csv``."""

from __future__ import annotations

import argparse
import csv
import random
import statistics as st
from collections.abc import Iterable
from pathlib import Path

FULL_METHOD = "combo_id_zscore_equal"
TWO_COMPONENT_METHODS = (
    "combo_id_zscore_equal_E+M",
    "combo_id_zscore_equal_E+N",
    "combo_id_zscore_equal_M+N",
)
N_ONLY_METHOD = "combo_id_zscore_equal_N"
EM_METHOD = "combo_id_zscore_equal_E+M"


def read_results(path: str | Path) -> list[dict[str, str]]:
    """Load benchmark result rows."""

    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _float(row: dict[str, str], key: str) -> float | None:
    try:
        return float(row.get(key, ""))
    except (TypeError, ValueError):
        return None


def _combo_rows(rows: Iterable[dict[str, str]]) -> list[dict[str, str]]:
    return [row for row in rows if str(row.get("method", "")).startswith("combo_id_zscore_equal")]


def _method_mean(rows: Iterable[dict[str, str]], method: str, metric: str) -> float | None:
    vals = [_float(row, metric) for row in rows if row.get("method") == method]
    finite = [val for val in vals if val is not None]
    return st.mean(finite) if finite else None


def _method_summary(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    methods = sorted({str(row.get("method", "")) for row in _combo_rows(rows)})
    for method in methods:
        method_rows = [row for row in rows if row.get("method") == method]
        aurocs = [val for row in method_rows if (val := _float(row, "auroc")) is not None]
        auprs = [val for row in method_rows if (val := _float(row, "aupr_out")) is not None]
        fprs = [val for row in method_rows if (val := _float(row, "fpr95")) is not None]
        if not aurocs:
            continue
        out.append(
            {
                "method": method,
                "n": str(len(aurocs)),
                "auroc_mean": f"{st.mean(aurocs):.4f}",
                "auroc_std": f"{st.stdev(aurocs):.4f}" if len(aurocs) > 1 else "0.0000",
                "aupr_out_mean": f"{st.mean(auprs):.4f}" if auprs else "n/a",
                "fpr95_mean": f"{st.mean(fprs):.4f}" if fprs else "n/a",
            }
        )
    return out


def paired_deltas(
    rows: list[dict[str, str]],
    left_method: str,
    right_method: str,
    *,
    metric: str = "auroc",
    ood_contains: str | None = None,
) -> list[float]:
    """Return paired ``left - right`` metric deltas over matching seed/OOD rows."""

    left: dict[tuple[str, str], float] = {}
    right: dict[tuple[str, str], float] = {}
    for row in rows:
        ood = str(row.get("ood", ""))
        if ood_contains and ood_contains.lower() not in ood.lower():
            continue
        key = (str(row.get("seed", "")), ood)
        val = _float(row, metric)
        if val is None:
            continue
        if row.get("method") == left_method:
            left[key] = val
        elif row.get("method") == right_method:
            right[key] = val
    return [left[key] - right[key] for key in sorted(left.keys() & right.keys())]


def paired_bootstrap_ci(
    deltas: list[float],
    *,
    resamples: int = 2000,
    seed: int = 12345,
) -> tuple[float, float] | None:
    """Return a simple paired bootstrap 95% interval for mean deltas."""

    if not deltas:
        return None
    rng = random.Random(int(seed))
    means: list[float] = []
    for _ in range(int(resamples)):
        sample = [deltas[rng.randrange(len(deltas))] for _ in deltas]
        means.append(st.mean(sample))
    means.sort()
    lo = means[int(0.025 * (len(means) - 1))]
    hi = means[int(0.975 * (len(means) - 1))]
    return lo, hi


def _best_two_component_method(rows: list[dict[str, str]]) -> tuple[str, float] | None:
    scored = [
        (method, mean)
        for method in TWO_COMPONENT_METHODS
        if (mean := _method_mean(rows, method, "auroc")) is not None
    ]
    if not scored:
        return None
    return max(scored, key=lambda item: item[1])


def _format_answer(rows: list[dict[str, str]]) -> list[str]:
    full = _method_mean(rows, FULL_METHOD, "auroc")
    best_two = _best_two_component_method(rows)
    answers: list[str] = []
    if full is None or best_two is None:
        answers.append("- E+M+N vs best two-component combo: insufficient completed rows.")
    else:
        delta = full - best_two[1]
        verdict = "yes" if delta > 0 else "no"
        answers.append(
            f"- E+M+N beats the best two-component combo: {verdict}; "
            f"mean AUROC delta vs `{best_two[0]}` is {delta:+.4f}."
        )
        deltas = paired_deltas(rows, FULL_METHOD, best_two[0])
        if deltas:
            positives = sum(1 for val in deltas if val > 0)
            note = (
                f"- Seed/OOD consistency: {positives}/{len(deltas)} paired deltas are positive; "
                f"mean paired AUROC delta is {st.mean(deltas):+.4f}."
            )
            seeds = {row.get("seed", "") for row in rows if row.get("method") == FULL_METHOD}
            if len(seeds) >= 5:
                ci = paired_bootstrap_ci(deltas)
                if ci is not None:
                    note += f" Paired bootstrap 95% CI: [{ci[0]:+.4f}, {ci[1]:+.4f}]."
            else:
                note += " With fewer than 5 seeds, treat this as descriptive only."
            answers.append(note)

    cifar_deltas = paired_deltas(rows, FULL_METHOD, EM_METHOD, ood_contains="cifar100")
    if cifar_deltas:
        answers.append(
            "- CIFAR-100-like near-OOD: adding N to E+M gives mean paired AUROC "
            f"delta {st.mean(cifar_deltas):+.4f} over {len(cifar_deltas)} rows."
        )
    else:
        answers.append("- CIFAR-100-like near-OOD: insufficient E+M and E+M+N paired rows.")

    full_mean = _method_mean(rows, FULL_METHOD, "auroc")
    n_mean = _method_mean(rows, N_ONLY_METHOD, "auroc")
    em_mean = _method_mean(rows, EM_METHOD, "auroc")
    if full_mean is not None and n_mean is not None and em_mean is not None:
        answers.append(
            "- Nervecode value: standalone N mean AUROC is "
            f"{n_mean:.4f}; adding N to E+M changes mean AUROC by "
            f"{full_mean - em_mean:+.4f}."
        )
    else:
        answers.append("- Nervecode value: insufficient N-only/full/E+M rows.")
    return answers


def render_markdown(rows: list[dict[str, str]], *, source: str) -> str:
    """Render a Markdown combo report."""

    summaries = _method_summary(rows)
    lines = [
        "# Combo Ablation",
        "",
        f"Source: `{source}`",
        "",
        "All combo rows use `combo_id_zscore_equal`: component scores are normalized with "
        "ID-calibration mean/std only, then averaged with fixed equal weights. OOD samples "
        "are never used for normalization or weighting.",
        "",
        "## Results",
        "",
        "| Method | Rows | AUROC mean | AUROC std | AUPR-OUT mean | FPR@95 mean |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    if summaries:
        for row in summaries:
            lines.append(
                f"| `{row['method']}` | {row['n']} | {row['auroc_mean']} | "
                f"{row['auroc_std']} | {row['aupr_out_mean']} | {row['fpr95_mean']} |"
            )
    else:
        lines.append("| n/a | 0 | n/a | n/a | n/a | n/a |")

    lines.extend(["", "## Interpretation", ""])
    lines.extend(_format_answer(rows) if summaries else ["- No completed combo rows were found."])

    oracle_rows = [row for row in rows if str(row.get("method", "")).startswith("oracle_")]
    lines.extend(
        [
            "",
            "## Oracle Appendix",
            "",
            "OOD-calibrated learned combiners are not headline detector results. They may be "
            "shown only as oracle appendix rows because their weights use evaluated OOD samples.",
            "",
            f"Oracle rows in source: {len(oracle_rows)}.",
            "",
        ]
    )
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results_csv", help="Benchmark results.csv")
    parser.add_argument("--output", default="docs/combo.md", help="Markdown output path")
    args = parser.parse_args(argv)

    rows = read_results(args.results_csv)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render_markdown(rows, source=str(args.results_csv)), encoding="utf-8")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
