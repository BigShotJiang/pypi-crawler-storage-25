#!/usr/bin/env bash

# Run an OOD experiment matrix under ~3 hours by sweeping
# aggregators, layer selection, codebook/coding dims, and combined-surprise weights.
# Results are saved as JSONL + CSV under a timestamped OUTDIR.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
cd "$REPO_ROOT"

PY="${PYTHON:-python}"
DEVICE="${DEVICE:-cpu}"
THREADS="${THREADS:-8}"
export OMP_NUM_THREADS="$THREADS"
export MKL_NUM_THREADS="$THREADS"

STAMP="$(date +%Y%m%d-%H%M%S)"
OUTDIR="${OUTDIR:-runs/ood-matrix-$STAMP}"
mkdir -p "$OUTDIR"

EPOCHS="${EPOCHS:-20}"
SEEDS="${SEEDS:-123 456 789}"
# Quantile sweep for OOD threshold sensitivity
QUANTILES=( ${QUANTILES:-0.80 0.90 0.95} )

AGGS=(mean max)
LAYERS_SET=(first_linear all_linear)
KS=(8 16)
CDIMS=(auto 8)
BETA_E=(0.0 1.0)
# Distance weight sweep for distance-augmented surprise
BETA_D=( ${BETA_D:-0.0 0.5 1.0} )

# Optional FAST profile: narrow to the most promising slice to accelerate sweeps.
# Enable via FAST=1 or MATRIX_PROFILE=fast. You can still override any array via env.
if [[ "${FAST:-0}" -eq 1 || "${MATRIX_PROFILE:-}" == "fast" ]]; then
  echo "FAST profile active: narrowing matrices to a promising slice"
  AGGS=( ${AGGS_FAST:-max} )
  LAYERS_SET=( ${LAYERS_FAST:-first_linear} )
  KS=( ${KS_FAST:-16} )
  CDIMS=( ${CDIMS_FAST:-8} )
  BETA_E=( ${BETA_E_FAST:-1.0} )
  BETA_D=( ${BETA_D_FAST:-0.5 1.0} )
  QUANTILES=( ${QUANTILES_FAST:-0.90 0.95} )
  # Default to a single seed unless overridden
  SEEDS="${SEEDS_FAST:-${SEEDS:-123}}"
fi

JSONL="$OUTDIR/results.jsonl"
CSV="$OUTDIR/results.csv"
echo "agg,layers,K,coding_dim,beta_entropy,beta_distance,quantile,seed,epochs,auroc,id_mean,ood_mean,id_p50,ood_p50,id_p95,ood_p95,id_ood_rate,ood_ood_rate" > "$CSV"

PROFILE_LABEL="$( [[ "${FAST:-0}" -eq 1 || "${MATRIX_PROFILE:-}" == "fast" ]] && echo "FAST" || echo "FULL" )"
echo "Profile=$PROFILE_LABEL Using PY=$PY DEVICE=$DEVICE THREADS=$THREADS OUTDIR=$OUTDIR EPOCHS=$EPOCHS SEEDS=[$SEEDS] Qs=[${QUANTILES[*]}] BD=[${BETA_D[*]}]" | tee "$OUTDIR/summary.txt"
if [[ "$PROFILE_LABEL" == "FAST" ]]; then
  echo "FAST recommended defaults: agg=max layers=first_linear K=16 D=8 betaE=1.0 betaD=1.0 q in {0.90,0.95}" | tee -a "$OUTDIR/summary.txt"
fi

for agg in "${AGGS[@]}"; do
  for layers in "${LAYERS_SET[@]}"; do
    for K in "${KS[@]}"; do
      for dim in "${CDIMS[@]}"; do
        for be in "${BETA_E[@]}"; do
          for bd in "${BETA_D[@]}"; do
            for q in "${QUANTILES[@]}"; do
              for s in $SEEDS; do
                echo "== agg=$agg layers=$layers K=$K D=$dim betaE=$be betaD=$bd q=$q seed=$s ==" | tee -a "$OUTDIR/summary.txt"
              # We rely on the last line being JSON when --json is passed.
                LOG="$OUTDIR/run_${agg}_${layers}_K${K}_D${dim}_be${be}_bd${bd}_q${q}_seed${s}.log"
                set +e
                "$PY" -m benchmarks.ood.simple \
                  --epochs "$EPOCHS" \
                  --device "$DEVICE" \
                  --seed "$s" \
                  --agg "$agg" \
                  --layers "$layers" \
                  --K "$K" \
                  --coding-dim "$dim" \
                  --beta-length 1.0 \
                  --beta-entropy "$be" \
                  --beta-distance "$bd" \
                  --quantile "$q" \
                  --json \
                  2>&1 | tee "$LOG"
                RET=$?
                set -e
                OUT=$(grep -E '^\{.*\}$' "$LOG" | tail -n 1 || true)
                if [ $RET -ne 0 ] || [ -z "$OUT" ]; then
                  echo "WARN: run failed for combo; see $LOG" | tee -a "$OUTDIR/summary.txt"
                  continue
                fi
                echo "$OUT" >> "$JSONL"
                # Extract fields with Python for robustness (pass JSON via env to avoid stdin conflicts)
                LINE=$(OUT_JSON="$OUT" AGG="$agg" LAYERS="$layers" KVAL="$K" DIM="$dim" BE="$be" BD="$bd" QVAL="$q" SEED="$s" EPOCHS="$EPOCHS" \
                  "$PY" -c 'import os,json
out=os.environ["OUT_JSON"]
d=json.loads(out)
vals=[
  os.environ["AGG"], os.environ["LAYERS"], int(os.environ["KVAL"]), os.environ["DIM"], float(os.environ["BE"]), float(os.environ["BD"]), float(os.environ["QVAL"]), int(os.environ["SEED"]), int(os.environ["EPOCHS"]),
  d.get("auroc"), d.get("id_mean"), d.get("ood_mean"), d.get("id_p50"), d.get("ood_p50"), d.get("id_p95"), d.get("ood_p95"), d.get("id_ood_rate_at_q"), d.get("ood_ood_rate_at_q")
]
print(",".join(str(x) for x in vals))')
                echo "$LINE" >> "$CSV"
              done
            done
          done
        done
      done
    done
  done
done

echo "Done. Results written to $OUTDIR" | tee -a "$OUTDIR/summary.txt"

# Identify the best combo by mean AUROC across seeds (per agg,layers,K,D,be,bd,q)
BEST=$(python3 - "$CSV" << 'PY'
import csv, statistics as st
from collections import defaultdict
import sys
csv_path=sys.argv[1]
rows=[]
with open(csv_path) as f:
    r=csv.DictReader(f)
    for row in r:
        row['auroc']=float(row['auroc'])
        rows.append(row)
groups=defaultdict(list)
for row in rows:
    key=(row['agg'],row['layers'],row['K'],row['coding_dim'],row['beta_entropy'],row['beta_distance'],row['quantile'])
    groups[key].append(row['auroc'])
best=None
best_mean=-1.0
for k,v in groups.items():
    m=st.mean(v)
    if m>best_mean:
        best_mean=m; best=k
print(best_mean, *best)
PY
)
BEST_MEAN=$(echo "$BEST" | awk '{print $1}')
BEST_AGG=$(echo "$BEST" | awk '{print $2}')
BEST_LAYERS=$(echo "$BEST" | awk '{print $3}')
BEST_K=$(echo "$BEST" | awk '{print $4}')
BEST_DIM=$(echo "$BEST" | awk '{print $5}')
BEST_BE=$(echo "$BEST" | awk '{print $6}')
BEST_BD=$(echo "$BEST" | awk '{print $7}')
BEST_Q=$(echo "$BEST" | awk '{print $8}')

echo "Best config by AUROC: mean=$BEST_MEAN agg=$BEST_AGG layers=$BEST_LAYERS K=$BEST_K D=$BEST_DIM be=$BEST_BE bd=$BEST_BD q=$BEST_Q" | tee -a "$OUTDIR/summary.txt"

# Re-run a single seed for distribution stats (JSON includes mean/median/p95)
DBG_LOG="$OUTDIR/best_debug_${BEST_AGG}_${BEST_LAYERS}_K${BEST_K}_D${BEST_DIM}_be${BEST_BE}_q${BEST_Q}_seed123.log"
set +e
"$PY" -m benchmarks.ood.simple \
  --epochs "$EPOCHS" \
  --device "$DEVICE" \
  --seed 123 \
  --agg "$BEST_AGG" \
  --layers "$BEST_LAYERS" \
  --K "$BEST_K" \
  --coding-dim "$BEST_DIM" \
  --beta-length 1.0 \
  --beta-entropy "$BEST_BE" \
  --beta-distance "$BEST_BD" \
  --quantile "$BEST_Q" \
  --json | tee "$DBG_LOG"
set -e
DBG_LAST=$(grep -E '^\{.*\}$' "$DBG_LOG" | tail -n 1)
ID_MEAN=$(python3 - "$DBG_LAST" << 'PY'
import sys,json
print(json.loads(sys.argv[1]).get('id_mean'))
PY
)
OOD_MEAN=$(python3 - "$DBG_LAST" << 'PY'
import sys,json
print(json.loads(sys.argv[1]).get('ood_mean'))
PY
)
ID_P50=$(python3 - "$DBG_LAST" << 'PY'
import sys,json
print(json.loads(sys.argv[1]).get('id_p50'))
PY
)
OOD_P50=$(python3 - "$DBG_LAST" << 'PY'
import sys,json
print(json.loads(sys.argv[1]).get('ood_p50'))
PY
)
ID_P95=$(python3 - "$DBG_LAST" << 'PY'
import sys,json
print(json.loads(sys.argv[1]).get('id_p95'))
PY
)
OOD_P95=$(python3 - "$DBG_LAST" << 'PY'
import sys,json
print(json.loads(sys.argv[1]).get('ood_p95'))
PY
)

echo "Best config stats (seed=123): ID_mean=$ID_MEAN ID_p50=$ID_P50 ID_p95=$ID_P95 | OOD_mean=$OOD_MEAN OOD_p50=$OOD_P50 OOD_p95=$OOD_P95" | tee -a "$OUTDIR/summary.txt"

# Minimal write-up under docs/benchmarks
DOC_PATH="docs/benchmarks/ood-synthetic-$STAMP.md"
mkdir -p "$(dirname "$DOC_PATH")"
{
  echo "# Synthetic OOD Sweep ($STAMP)"
  echo
  echo "- Script: scripts/run_ood_matrix.sh"
  echo "- Artifacts: $OUTDIR (CSV/JSONL, logs)"
  echo
  echo "## Summary"
  echo "- Best config (mean AUROC across seeds):"
  echo "  - agg=$BEST_AGG, layers=$BEST_LAYERS, K=$BEST_K, D=$BEST_DIM, betaE=$BEST_BE, betaD=$BEST_BD, q=$BEST_Q"
  echo "  - mean AUROC across seeds: $BEST_MEAN"
  echo "- Debug distribution stats (seed=123):"
  echo "  - ID mean/median/p95: $ID_MEAN / $ID_P50 / $ID_P95"
  echo "  - OOD mean/median/p95: $OOD_MEAN / $OOD_P50 / $OOD_P95"
  echo
  echo "## Notes"
  echo "- Median and 95th percentile help confirm score orientation (OOD > ID)."
  echo "- See docs/benchmarks.md for the full reporting template."
} > "$DOC_PATH"
