"""Developer smoke script for local wiring checks.

This script imports the `nervecode` package, instantiates placeholder objects,
and ensures that core subpackages are importable. It is intentionally minimal
and fast; use it to quickly validate a fresh checkout or environment.
"""

from __future__ import annotations

import importlib
import sys
from collections.abc import Iterable
from pathlib import Path
from types import ModuleType


def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def _import(name: str) -> ModuleType:
    return importlib.import_module(name)


def main(argv: list[str] | None = None) -> int:
    _ = argv  # unused; reserved for future flags

    # Ensure repository root is on sys.path when executed as a script
    repo_root = str(Path(__file__).resolve().parent.parent)
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

    # 1) Import top-level package
    pkg = _import("nervecode")
    _require(pkg.__name__ == "nervecode", "Failed to import nervecode package")

    # 2) Verify public API surface exists
    public: Iterable[str] = getattr(pkg, "__all__", [])
    for name in ("wrap", "WrappedModel"):
        _require(name in public, f"Missing public API export: {name}")

    # 3) Instantiate placeholder wrapper to ensure class is usable
    import nervecode as nc  # typed import for attribute access

    wm = nc.WrappedModel(object())
    _require(getattr(wm, "_model", None) is not None, "WrappedModel did not keep model ref")

    # 4) Subpackages should be importable
    for sub in ("core", "layers", "scoring", "training", "integration", "utils"):
        _ = _import(f"nervecode.{sub}")

    print("OK: nervecode import and placeholder instantiation succeeded")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
