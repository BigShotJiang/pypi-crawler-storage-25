"""Installed-package smoke test for the public Nervecode API."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Any


def _ensure_nervecode_importable() -> None:
    try:
        import nervecode  # noqa: F401

        return
    except ModuleNotFoundError:
        repo_root = Path(__file__).resolve().parents[1]
        sys.path.insert(0, str(repo_root))


def run_smoke(*, expected_version: str | None = None) -> None:
    _ensure_nervecode_importable()

    import nervecode
    import torch
    from torch import nn

    version = getattr(nervecode, "__version__", None)
    if not isinstance(version, str) or not version:
        raise AssertionError("nervecode.__version__ must be a non-empty string")
    if expected_version is not None and version != expected_version:
        raise AssertionError(f"expected nervecode {expected_version}, got {version}")

    # Missing-trace behavior is deterministic before any forward pass.
    uncalled = nervecode.wrap(nn.Sequential(nn.Linear(2, 4), nn.ReLU(), nn.Linear(4, 2)))
    try:
        _ = uncalled.coding_loss()
    except RuntimeError as exc:
        if "No per-layer traces are available" not in str(exc):
            raise AssertionError(f"unexpected missing-trace error: {exc}") from exc
    else:  # pragma: no cover - defensive
        raise AssertionError("coding_loss() should fail before a forward populates traces")

    model = nn.Sequential(nn.Linear(2, 8), nn.ReLU(), nn.Linear(8, 2))
    wrapped = nervecode.wrap(model, layers="all_linear")

    x = torch.randn(6, 2)
    out = wrapped(x)
    if tuple(out.shape) != (6, 2):
        raise AssertionError(f"wrapped forward changed output shape: {tuple(out.shape)}")

    coding_loss = wrapped.coding_loss()
    if int(getattr(coding_loss, "ndim", -1)) != 0:
        raise AssertionError("coding_loss() should return a scalar tensor after forward")

    agg = wrapped.surprise()
    if agg is not None:
        scores = getattr(agg, "surprise", None)
        if not isinstance(scores, torch.Tensor):
            raise AssertionError("surprise().surprise must be a tensor when present")
        if tuple(scores.shape) != (6,):
            raise AssertionError(f"unexpected surprise shape: {tuple(scores.shape)}")
        if not torch.isfinite(scores).all().item():
            raise AssertionError("surprise scores must be finite")

    loader: list[Any] = [
        (torch.randn(4, 2), torch.zeros(4, dtype=torch.long)),
        (torch.randn(4, 2), torch.zeros(4, dtype=torch.long)),
    ]
    wrapped.calibrate(loader)
    calibrator = getattr(wrapped, "_calibrator", None)
    state = getattr(calibrator, "state", None)
    if state is None:
        raise AssertionError("calibrate() should attach a fitted calibrator")
    if int(state.metadata.get("num_scores", 0)) != 8:
        raise AssertionError(f"unexpected calibration score count: {state.metadata}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--expected-version",
        default=os.environ.get("NERVECODE_EXPECT_VERSION"),
        help="Exact version expected for release-commit smoke runs.",
    )
    args = parser.parse_args()
    run_smoke(expected_version=args.expected_version)
    print("release smoke passed")


if __name__ == "__main__":
    main()
