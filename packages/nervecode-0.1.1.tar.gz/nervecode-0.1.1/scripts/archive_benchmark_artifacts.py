"""Create a tar.gz archive for a completed benchmark run directory."""

from __future__ import annotations

import argparse
import os
import tarfile
from pathlib import Path


def archive_run(
    run_dir: str | os.PathLike[str],
    output: str | os.PathLike[str] | None = None,
) -> Path:
    source = Path(run_dir)
    if not source.is_dir():
        raise FileNotFoundError(f"benchmark run directory not found: {source}")
    out = Path(output) if output else source.parent / f"{source.name}-benchmark-artifacts.tar.gz"
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, "w:gz") as tar:
        tar.add(source, arcname=source.name)
    return out


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", help="Completed runs/<run_id> directory to archive")
    parser.add_argument("--output", default=None, help="Output .tar.gz path")
    args = parser.parse_args(argv)
    out = archive_run(args.run_dir, args.output)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
