"""Minimal, dataset-agnostic training script for quick validation.

This script trains a tiny model with a task loss plus Nervecode's coding loss
on a lightweight synthetic dataset, then calibrates an empirical percentile
calibrator on held-out in-distribution data. It is designed for fast local
checks and CI smoke runs and can optionally use user-provided factories for the
model and dataloaders via dotted import paths.

Usage examples:
- Default quick run on CPU:
  python scripts/train_minimal.py --epochs 1 --dataset-size 256

- Use a custom dataloader factory:
  python scripts/train_minimal.py \
    --dataloader-fn mypkg.data:make_loaders

The dataloader factory should return a tuple (train, calib, test) of three
iterables yielding (inputs, targets) batches.
"""

from __future__ import annotations

import argparse
import importlib
import sys
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast


def _repo_bootstrap() -> None:
    """Ensure repository root is importable when running from source.

    Adds the repository root to sys.path so `import nervecode` resolves when
    the package isn't installed. Safe to call multiple times.
    """

    root = str(Path(__file__).resolve().parent.parent)
    if root not in sys.path:
        sys.path.insert(0, root)


def _torch_ok() -> bool:
    """Return True when a minimal set of torch features is available."""

    # Relies on the optional top-level imports below
    try:
        import torch as _t  # type: ignore[import-not-found]
    except Exception:
        return False
    return hasattr(_t, "tensor") and hasattr(_t, "no_grad")


def _resolve_callable(path: str) -> Callable[..., Any]:
    """Import and return a callable referenced by ``module:attr`` or ``module.attr``.

    Raises ImportError or AttributeError on failure.
    """

    mod_path: str
    attr: str
    if ":" in path:
        mod_path, attr = path.split(":", 1)
    else:
        parts = path.rsplit(".", 1)
        if len(parts) != 2:
            raise ImportError(
                f"Expected 'module:attr' or 'module.attr' for callable path, got: {path}"
            )
        mod_path, attr = parts[0], parts[1]
    mod = importlib.import_module(mod_path)
    fn = getattr(mod, attr)
    if not callable(fn):
        raise TypeError(f"Resolved object is not callable: {path}")
    return cast(Callable[..., Any], fn)


# --- Built-in tiny dataset and model for quick local validation ---------------


try:  # Optional: keep import errors handled by _torch_ok() gate
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, Dataset, random_split  # type: ignore[import-not-found]
except Exception:  # pragma: no cover - guarded by _torch_ok()
    torch = cast(Any, None)
    nn = cast(Any, None)
    DataLoader = cast(Any, None)
    Dataset = cast(Any, object)
    random_split = cast(Any, None)


class _ToyGaussianDataset(Dataset):  # type: ignore[misc]
    """Two-class 2D Gaussian mixture built using Python's random.gauss.

    Avoids reliance on torch.randn to work in environments with limited torch
    builds used in some CI settings.
    """

    def __init__(self, n: int, *, seed: int = 42) -> None:  # pragma: no cover - simple data
        import random

        g = random.Random(int(seed))
        n0 = n // 2
        n1 = n - n0
        x0 = [[g.gauss(-1.0, 0.6), g.gauss(-1.0, 0.6)] for _ in range(n0)]
        x1 = [[g.gauss(+1.0, 0.6), g.gauss(+1.0, 0.6)] for _ in range(n1)]
        y0 = [0 for _ in range(n0)]
        y1 = [1 for _ in range(n1)]
        xs = x0 + x1
        ys = y0 + y1
        # Single shuffle to mix classes deterministically
        idx = list(range(n))
        g.shuffle(idx)
        self._x = torch.tensor([xs[i] for i in idx], dtype=torch.float32)
        self._y = torch.tensor([ys[i] for i in idx], dtype=torch.long)

    def __len__(self) -> int:
        return int(self._x.shape[0])

    def __getitem__(self, i: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self._x[i], self._y[i]


if nn is not None:  # define a real model only when torch.nn is available

    class _TinyMLP(nn.Module):  # type: ignore[misc]  # pragma: no cover - exercised via script
        def __init__(self, in_dim: int = 2, hidden: int = 32, out_dim: int = 2) -> None:
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(in_dim, hidden),
                nn.ReLU(),
                nn.Linear(hidden, out_dim),
            )

        def forward(self, x: Any) -> Any:  # torch.Tensor in torch-enabled envs
            return self.net(x)
else:  # pragma: no cover - environment without torch.nn

    class _TinyMLPStub:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass  # not used when torch is unavailable


@dataclass
class Config:
    device: str = "cpu"
    batch_size: int = 64
    epochs: int = 1
    lr: float = 1e-2
    coding_loss_weight: float = 0.1
    dataset_size: int = 512
    calib_fraction: float = 0.25
    wrap: str = "all_linear"
    threshold_quantiles: tuple[float, ...] = (0.95,)


def _builtin_make_loaders(cfg: Config) -> tuple[Any, Any, Any]:  # DataLoader[Any]
    ds = _ToyGaussianDataset(cfg.dataset_size, seed=123)
    assert random_split is not None  # for mypy
    calib_len = int(len(ds) * cfg.calib_fraction)
    test_len = calib_len
    train_len = len(ds) - calib_len - test_len
    train, calib, test = random_split(ds, [train_len, calib_len, test_len])

    def _mk(dl_ds: Dataset) -> DataLoader:
        assert DataLoader is not None  # for mypy
        return DataLoader(dl_ds, batch_size=cfg.batch_size, shuffle=True)

    return _mk(train), _mk(calib), _mk(test)


def _builtin_make_model(cfg: Config) -> Any:
    model = _TinyMLP()
    return model


def train_and_calibrate(
    cfg: Config,
    *,
    dataloaders_fn: Callable[[Config], tuple[Iterable[Any], Iterable[Any], Iterable[Any]]]
    | None = None,
    model_fn: Callable[[Config], Any] | None = None,
) -> tuple[Any, Any]:
    """Train a model with coding loss and calibrate a percentile threshold.

    Returns (wrapped_model, calibrator).
    """

    if not _torch_ok():  # pragma: no cover - environment guard
        print("torch not available; skipping minimal training")
        return None, None

    assert torch is not None  # for mypy
    assert nn is not None  # for mypy

    # Deferred import after repo bootstrap so local package resolves
    import nervecode as nvc
    from nervecode.layers.wrap import wrap as wrap_layers
    from nervecode.scoring import EmpiricalPercentileCalibrator
    from nervecode.training import (
        CsvDiagnosticsLogger,
        DiagnosticsCollector,
        JsonlDiagnosticsLogger,
    )

    device = torch.device(cfg.device)
    model = (model_fn or _builtin_make_model)(cfg).to(device)
    wrap_layers(model, layers=cfg.wrap)

    wrapped = nvc.WrappedModel(model)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    ce = nn.CrossEntropyLoss()

    make_loaders = dataloaders_fn or _builtin_make_loaders
    train_loader, calib_loader, _ = make_loaders(cfg)

    # Optional diagnostics setup
    diag_collector = DiagnosticsCollector()
    csv_logger: CsvDiagnosticsLogger | None = None
    jsonl_logger: JsonlDiagnosticsLogger | None = None
    # Infer optional paths from environment-style config via args in main()
    csv_path = getattr(cfg, "_diag_csv", None)
    jsonl_path = getattr(cfg, "_diag_jsonl", None)
    if isinstance(csv_path, (str, Path)) and str(csv_path):
        csv_logger = CsvDiagnosticsLogger(str(csv_path))
    if isinstance(jsonl_path, (str, Path)) and str(jsonl_path):
        jsonl_logger = JsonlDiagnosticsLogger(str(jsonl_path))

    model.train()
    for _epoch in range(cfg.epochs):
        total = 0.0
        for xb, yb in train_loader:
            xb_t = xb.to(device) if hasattr(xb, "to") else torch.tensor(xb, dtype=torch.float32)
            yb_t = yb.to(device) if hasattr(yb, "to") else torch.tensor(yb, dtype=torch.long)
            opt.zero_grad(set_to_none=True)
            logits = wrapped.forward(xb_t)
            loss = ce(logits, yb_t)
            # Add coding loss from latest per-layer traces
            coding_loss_t = cast("torch.Tensor", wrapped.coding_loss())
            loss = loss + cfg.coding_loss_weight * coding_loss_t
            loss.backward()
            opt.step()
            total += float(loss.detach().item())

            # Diagnostics: log latest per-layer stats if requested
            if csv_logger or jsonl_logger:
                traces = getattr(wrapped, "_last_layer_traces", {}) or {}
                rows = diag_collector.collect(traces)
                if rows:
                    if csv_logger:
                        csv_logger.log(rows)
                    if jsonl_logger:
                        jsonl_logger.log(rows)

    # Calibrate on held-out in-distribution data
    calib = EmpiricalPercentileCalibrator(threshold_quantiles=cfg.threshold_quantiles)
    wrapped.disable_coding()
    wrapped.enable_coding()
    with torch.no_grad():
        for xb, _yb in calib_loader:
            xb_t = xb.to(device) if hasattr(xb, "to") else torch.tensor(xb, dtype=torch.float32)
            _ = wrapped.forward(xb_t)
            from nervecode.scoring.types import AggregatedSurprise

            agg = wrapped.surprise()
            if agg is None:
                continue
            agg_t = cast(AggregatedSurprise, agg)
            calib.fit(agg_t.surprise, aggregation="mean")
            break  # minimal calibration for speed

    return wrapped, calib


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Minimal dataset-agnostic trainer")
    p.add_argument("--device", default="cpu")
    p.add_argument("--epochs", type=int, default=1)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--lr", type=float, default=1e-2)
    p.add_argument("--coding-loss-weight", type=float, default=0.1)
    p.add_argument("--dataset-size", type=int, default=512)
    p.add_argument("--calib-fraction", type=float, default=0.25)
    p.add_argument("--wrap", default="all_linear")
    p.add_argument(
        "--dataloader-fn",
        default=None,
        help="Optional callable (module:attr) returning (train, calib, test) dataloaders",
    )
    p.add_argument(
        "--model-fn",
        default=None,
        help="Optional callable (module:attr) returning an nn.Module",
    )
    p.add_argument(
        "--diag-csv",
        default="",
        help="Optional path to append CSV diagnostics (per batch)",
    )
    p.add_argument(
        "--diag-jsonl",
        default="",
        help="Optional path to append JSONL diagnostics (per batch)",
    )
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    _repo_bootstrap()
    args = _parse_args(argv)

    cfg = Config(
        device=str(args.device),
        batch_size=int(args.batch_size),
        epochs=int(args.epochs),
        lr=float(args.lr),
        coding_loss_weight=float(args.coding_loss_weight),
        dataset_size=int(args.dataset_size),
        calib_fraction=float(args.calib_fraction),
        wrap=str(args.wrap),
    )
    # Attach diagnostics paths in a lightweight way without expanding the public dataclass
    cfg._diag_csv = args.diag_csv
    cfg._diag_jsonl = args.diag_jsonl

    # Optional dynamic factories
    dl_fn = _resolve_callable(args.dataloader_fn) if args.dataloader_fn else None
    mdl_fn = _resolve_callable(args.model_fn) if args.model_fn else None

    wrapped, calib = train_and_calibrate(cfg, dataloaders_fn=dl_fn, model_fn=mdl_fn)
    if wrapped is None or calib is None:  # environment without torch
        return 0

    # One tiny inference batch for a concise summary
    assert torch is not None
    device = torch.device(cfg.device)
    train_loader, _, _ = _builtin_make_loaders(cfg)  # reuse built-in for quick summary
    with torch.no_grad():
        for xb, _yb in train_loader:
            _ = wrapped.forward(xb.to(device))
            agg = wrapped.surprise()
            if agg is not None:
                s = agg.surprise
                print(
                    f"OK: train_minimal finished — loss_weight={cfg.coding_loss_weight} "
                    f"surprise_mean={float(s.mean()):.4f}"
                )
            break

    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main(sys.argv[1:]))
