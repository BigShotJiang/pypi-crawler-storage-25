"""Package version for Nervecode.

The version is the single source of truth for both runtime access via
``nervecode.__version__`` and build-time metadata via Hatch's version plugin.
"""

__all__ = ["__version__"]

# Follow PEP 440; bump as releases evolve.
__version__ = "0.1.1"
