"""Coding wrapper for ``torch.nn.Conv2d`` with pooled coding.

This module provides ``CodingConv2d`` — an observe-only wrapper around
``nn.Conv2d`` that computes coding statistics over a pooled representation of
the layer output. The visible forward value remains identical to the underlying
convolution; coding runs side-by-side and updates an internal trace cache.

Design constraints for the first convolutional wrapper:
- Observe-only contract for forwards (fail-open behavior).
- Coding over a pooled representation (global average pooling over H and W).
- Default sample-level reducer corresponds to global average pooling semantics.
"""

from __future__ import annotations

from typing import Any

from .base import BaseCodingWrapper, ReducerFn

# Import torch lazily but tolerate environments without it at import time.
try:  # pragma: no cover - exercised in torch-enabled environments
    import torch
    from torch import nn
except Exception:  # pragma: no cover - allow import without torch
    from typing import Any
    from typing import cast as _cast

    torch = _cast(Any, None)
    nn = _cast(Any, None)

from nervecode.core import CodingTrace
from nervecode.core.assignment import SoftAssignment
from nervecode.core.codebook import Codebook

__all__ = ["CodingConv2d"]


class CodingConv2d(nn.Module, BaseCodingWrapper):
    """Observe-only wrapper around ``nn.Conv2d`` with pooled coding.

    The wrapper delegates computation to the underlying ``nn.Conv2d`` and,
    when coding is active, computes a ``CodingTrace`` over a globally pooled
    representation of the visible activation. The visible forward output is
    never altered.

    Parameters
    - layer: The ``nn.Conv2d`` module to wrap.
    - K: Number of codebook centers. Defaults to 16.
    - coding_dim: Target coding dimension ``D``. When ``None`` (default), uses
      ``layer.out_channels``. If provided, must satisfy ``1 <= coding_dim <=
      layer.out_channels``; when smaller than ``out_channels``, a learned linear
      projection is applied after global average pooling, affecting only the
      coding path (observe-only contract preserved).
    - reducer: Optional reducer callable. Overrides the default global-average
      pooling behavior when provided.
    - temperature: Soft-assignment temperature. Higher is softer.
    - eps: Numerical epsilon to clamp divisions and logs.
    """

    def __init__(
        self,
        layer: Any,  # use Any to avoid a hard torch dependency in type hints
        *,
        K: int = 16,
        coding_dim: int | None = None,
        reducer: ReducerFn | None = None,
        temperature: float = 1.0,
        eps: float = 1e-12,
    ) -> None:
        if torch is None:  # pragma: no cover - defensive
            raise RuntimeError("CodingConv2d requires PyTorch to be installed")

        nn.Module.__init__(self)
        BaseCodingWrapper.__init__(self, reducer=reducer)

        if not isinstance(layer, nn.Conv2d):
            raise TypeError("layer must be an instance of torch.nn.Conv2d")

        self.layer: Any = layer

        out_channels = int(self.layer.out_channels)
        if coding_dim is None:
            code_dim = out_channels
        else:
            code_dim = int(coding_dim)
            if code_dim <= 0:
                raise ValueError("coding_dim must be >= 1")
            if code_dim > out_channels:
                raise ValueError("coding_dim must be <= layer.out_channels for reduction")

        # Optional learned projection after pooling when reducing channels.
        self._projection: Any | None = None
        if reducer is None and code_dim < out_channels:
            # Use a linear projection over the pooled channel vector (B, C) -> (B, D).
            self._projection = nn.Linear(out_channels, code_dim, bias=False)

            def _pool_then_project(x: Any) -> tuple[Any, dict[str, Any]]:
                # Global average pooling over spatial dims (H, W)
                pooled = x.mean(dim=(-1, -2))  # (B, C)
                y_proj = self._projection(pooled)  # type: ignore[misc]
                meta = {
                    "method": "global_avg_pool2d+linear_projection",
                    "in": out_channels,
                    "out": code_dim,
                    # Record that coding view comes from spatial reduction
                    "spatial_reduction": True,
                    "reduction_axes": [-2, -1],  # H, W in NCHW
                }
                return y_proj, meta

            self.set_reducer(_pool_then_project)
        elif reducer is None:
            # Default: global average pooling over spatial dims to (B, C)
            def _global_avg_pool2d(x: Any) -> tuple[Any, dict[str, Any]]:
                reduced = x.mean(dim=(-1, -2))  # (B, C)
                return reduced, {
                    "method": "global_avg_pool2d",
                    "spatial_reduction": True,
                    "reduction_axes": [-2, -1],  # H, W in NCHW
                }

            self.set_reducer(_global_avg_pool2d)
        # else: keep user-provided reducer

        # Codebook over final feature dimension D=code_dim
        self.codebook = Codebook(K=int(K), code_dim=code_dim)
        self.assignment = SoftAssignment(temperature=float(temperature), eps=float(eps))

    def forward(self, x: Any) -> Any:  # torch.Tensor in torch-enabled envs
        """Return the wrapped layer's output and update the cached trace.

        Preserves the observe-only contract: the visible value is the
        underlying layer output. For programmatic use, prefer
        ``forward_with_trace`` to retrieve the explicit ``CodingTrace``
        alongside the output.
        """

        y, _ = self.forward_with_trace(x)
        return y

    def forward_with_trace(self, x: Any) -> tuple[Any, CodingTrace | None]:
        """Return the wrapped output and, when active, the explicit trace."""

        y = self.layer(x)

        if not self.is_coding_active:
            self.clear_last_trace()
            return y, None

        # Apply configured reducer (default: global average pooling over H, W).
        reduced, reduction_meta = self.maybe_reduce(y)

        # Compute assignments over the pooled representation.
        soft, inter = self.assignment(reduced, self.codebook)

        trace = CodingTrace(
            reduced=reduced,
            reduction_meta=reduction_meta,
            nearest_center_distances=inter["nearest_center_distances"],
            chosen_center_indices=inter["chosen_center_indices"],
            commitment_distances=inter["commitment_distances"],
            soft_code=soft,
        )
        self.update_last_trace(trace)
        return y, trace

    def extra_repr(self) -> str:  # pragma: no cover - cosmetic
        status = "on" if self.coding_enabled else "off"
        return (
            f"layer=Conv2d(out_channels={int(self.layer.out_channels)}), "
            f"code_dim={int(self.codebook.code_dim)}, "
            f"K={int(self.codebook.K)}, reducer={self.get_reducer().__name__}, "
            f"coding={status}"
        )
