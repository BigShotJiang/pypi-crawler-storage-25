"""Common wrapper base: bypass, trace cache, reduction, diagnostics hooks.

This module defines a small, torch-agnostic base class and companion typing to
standardize behavior shared by coding wrappers:

- Bypass and fail-open controls (enable_coding(), disable_coding(), and the
  bypass() context manager) with correct nesting semantics.
- Latest per-layer trace caching (last_trace) with explicit update/clear.
- A light reduction callable type compatible with identity or learned reducers.
- Diagnostics hook registration that runs safely on trace updates.

Wrappers built on top of this class remain observe-only: the base makes no
assumptions about forward semantics beyond providing helpers that wrappers can
use after computing the original layer output.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import contextmanager, suppress
from typing import Any

try:  # Optional torch import for typing only; keep runtime torch-agnostic.
    from nervecode.core import CodingTrace  # re-exported type
except Exception:  # pragma: no cover - available in normal package use
    CodingTrace = Any  # type: ignore[misc,assignment]

__all__ = ["BaseCodingWrapper", "ReducerFn", "identity_reduction"]


ReducerFn = Callable[[Any], tuple[Any, dict[str, Any]]]
"""Callable that reduces an activation and returns metadata.

Accepts a single activation-like object (typically a tensor with shape
``(..., D_out)``) and returns ``(reduced, reduction_meta)`` where ``reduced``
has shape ``(..., D)`` and ``reduction_meta`` is a JSON-serializable dict that
identifies the applied reduction (e.g., {"method": "identity"}).
"""


def identity_reduction(x: Any) -> tuple[Any, dict[str, Any]]:
    """Return input unchanged with minimal metadata."""

    return x, {"method": "identity"}


class BaseCodingWrapper:
    """Torch-agnostic base for coding wrappers.

    Responsibilities
    - Maintain an enable/disable switch and a nestable bypass context to
      implement fail-open behavior consistently across wrappers.
    - Cache the most recent per-layer trace and run registered diagnostics
      hooks safely when it updates.
    - Provide a reducer slot with an identity default so wrappers can apply
      a dimension reduction before coding without duplicating boilerplate.
    """

    def __init__(self, *, reducer: ReducerFn | None = None) -> None:
        self._coding_enabled: bool = True
        self._bypass_depth: int = 0
        self._last_trace: CodingTrace | None = None
        # Default to identity reduction when none is provided
        self._reducer: ReducerFn = reducer or identity_reduction
        self._diagnostic_hooks: list[Callable[[CodingTrace], None]] = []

    # --- Bypass and enable/disable -------------------------------------------------
    @property
    def coding_enabled(self) -> bool:
        """Return whether coding is globally enabled for this wrapper."""

        return self._coding_enabled

    @property
    def is_coding_active(self) -> bool:
        """True when coding is enabled and not currently bypassed."""

        return self._coding_enabled and self._bypass_depth == 0

    def enable_coding(self) -> None:
        """Enable coding instrumentation for subsequent forwards."""

        self._coding_enabled = True

    def disable_coding(self) -> None:
        """Disable coding instrumentation (fail-open) and clear caches.

        Disabling coding should restore base-model behavior immediately. To
        avoid stale reads from convenience accessors, drop any cached latest
        trace at the time of disabling rather than waiting for the next
        forward pass.
        """

        self._coding_enabled = False
        # Clear any previously cached trace so that model-level aggregations
        # observe the disabled state immediately.
        self.clear_last_trace()

    @contextmanager
    def bypass(self) -> Iterator[None]:
        """Temporarily bypass coding instrumentation.

        The context is nestable; coding is considered bypassed when the bypass
        depth is greater than zero.
        """

        self._bypass_depth += 1
        try:
            yield
        finally:
            self._bypass_depth -= 1
            if self._bypass_depth < 0:  # pragma: no cover - defensive
                self._bypass_depth = 0

    # --- Reduction ----------------------------------------------------------------
    def set_reducer(self, reducer: ReducerFn) -> None:
        """Set the reducer callable used by ``maybe_reduce``."""

        self._reducer = reducer

    def get_reducer(self) -> ReducerFn:
        """Return the current reducer callable."""

        return self._reducer

    def maybe_reduce(self, activation: Any) -> tuple[Any, dict[str, Any]]:
        """Apply the configured reducer when coding is active.

        When coding is not active (disabled or bypassed), return the input
        unchanged with a metadata dictionary indicating bypass. This function
        never raises; wrappers should keep observe-only semantics.
        """

        if not self.is_coding_active:
            return activation, {"method": "bypass"}
        try:
            return self._reducer(activation)
        except Exception:  # Fail-open on reducer errors
            # Leave a recognizable marker to help downstream logging while
            # guaranteeing observe-only behavior.
            return activation, {"method": "bypass", "reason": "reduction_error"}

    # --- Trace cache and diagnostics ----------------------------------------------
    @property
    def last_trace(self) -> CodingTrace | None:
        """Return the most recently cached trace, if any."""

        return self._last_trace

    def clear_last_trace(self) -> None:
        """Drop the cached trace."""

        self._last_trace = None

    def update_last_trace(self, trace: CodingTrace) -> None:
        """Cache the latest trace and run diagnostics hooks safely."""

        self._last_trace = trace
        self._run_diagnostic_hooks(trace)

    def add_diagnostics_hook(self, hook: Callable[[CodingTrace], None]) -> None:
        """Register a hook invoked on every trace update.

        Hooks must be side-effect safe; exceptions are suppressed to preserve
        fail-open behavior.
        """

        self._diagnostic_hooks.append(hook)

    def remove_diagnostics_hook(self, hook: Callable[[CodingTrace], None]) -> None:
        """Remove a previously registered diagnostics hook, if present."""

        with suppress(ValueError):
            self._diagnostic_hooks.remove(hook)

    def _run_diagnostic_hooks(self, trace: CodingTrace) -> None:
        for hook in tuple(self._diagnostic_hooks):  # work on a snapshot
            try:
                hook(trace)
            except Exception:
                # Suppress hook exceptions to preserve user forwards; wrappers
                # are observe-only. Hooks are best-effort diagnostics.
                continue

    # --- Layer-level diagnostics (latest-trace) ---------------------------------
    def utilization(self) -> float | None:
        """Fraction of codes used in the latest trace.

        Returns the number of unique chosen indices divided by ``K`` from the
        most recent trace, or ``None`` when unavailable. The result is a
        Python ``float`` in ``[0, 1]``.
        """

        trace = self.last_trace
        if trace is None:  # no trace cached
            return None
        try:
            K = int(trace.soft_code.code_dim)
            if K <= 0:
                return None
            # Prefer SoftCode.best_indices when present; otherwise fall back to
            # the hard choice stored on the trace.
            best = trace.soft_code.best_indices
            if best is None:
                best = trace.chosen_center_indices
            values = self._flatten_to_list(best)
            if values is None or K == 0:
                return None
            used = len({int(v) for v in values})
            return float(used) / float(K)
        except Exception:
            return None

    def mean_entropy(self) -> float | None:
        """Mean assignment entropy from the latest trace, or ``None``.

        Returns ``soft_code.entropy.mean()`` as a Python ``float`` when a
        cached trace is available and contains entropy; otherwise ``None``.
        """

        trace = self.last_trace
        if trace is None:
            return None
        entropy = trace.soft_code.entropy
        if entropy is None:
            return None
        return self._mean_as_float(entropy)

    def mean_code_length(self) -> float | None:
        """Mean best-code length from the latest trace, or ``None``.

        Returns ``soft_code.best_length.mean()`` as a Python ``float`` when a
        cached trace is available and contains best-code lengths; otherwise
        ``None``.
        """

        trace = self.last_trace
        if trace is None:
            return None
        best_len = trace.soft_code.best_length
        if best_len is None:
            return None
        return self._mean_as_float(best_len)

    def mean_commitment_distance(self) -> float | None:
        """Mean commitment distance from the latest trace, or ``None``.

        Uses the per-position ``commitment_distances`` stored on the trace.
        Returns a Python ``float`` when available, else ``None``.
        """

        trace = self.last_trace
        if trace is None:
            return None
        d = trace.commitment_distances
        if d is None:
            return None
        return self._mean_as_float(d)

    @staticmethod
    def _flatten_to_list(x: Any) -> list[float] | None:
        """Best-effort flatten to a Python list of numbers.

        Supports torch-like objects exposing ``reshape``/``view`` and ``tolist``,
        as well as nested Python sequences.
        """

        # Torch-like path
        try:
            if hasattr(x, "reshape") and hasattr(x, "tolist"):
                return list(x.reshape(-1).tolist())
            if hasattr(x, "view") and hasattr(x, "tolist"):
                return list(x.view(-1).tolist())
            if hasattr(x, "tolist"):
                out = x.tolist()
                if isinstance(out, list):
                    # Shallow list; attempt to flatten one level if needed
                    def _flatten(v: Any) -> list[float]:
                        if isinstance(v, list):
                            res: list[float] = []
                            for item in v:
                                res.extend(_flatten(item))
                            return res
                        try:
                            return [float(v)]
                        except Exception:
                            return []

                    return _flatten(out)
        except Exception:
            pass

        # Python sequence fallback
        if isinstance(x, (list, tuple)):
            res2: list[float] = []
            for item in x:
                sub = BaseCodingWrapper._flatten_to_list(item)
                if sub is not None:
                    res2.extend(sub)
            return res2
        # Scalar fallback
        try:
            return [float(x)]
        except Exception:
            return None

    @staticmethod
    def _mean_as_float(x: Any) -> float | None:
        """Return mean(x) as a float for torch-like or Python sequences.

        - If ``x`` has a ``mean()`` method, call it and extract ``item()`` if
          available.
        - Otherwise, attempt to flatten to a list and compute an arithmetic
          mean.
        """

        # Torch-like: x.mean().item()
        try:
            if hasattr(x, "mean"):
                m = x.mean()
                if hasattr(m, "item"):
                    return float(m.item())
                return float(m)
        except Exception:
            pass

        values = BaseCodingWrapper._flatten_to_list(x)
        if not values:
            return None
        try:
            return float(sum(values) / float(len(values)))
        except Exception:
            return None
