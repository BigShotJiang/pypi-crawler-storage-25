"""Layer wrappers and instrumentation shims.

This subpackage will contain observe-only wrappers around selected PyTorch
layers and utilities to apply them to user models.
"""

from __future__ import annotations

from .base import BaseCodingWrapper, ReducerFn, identity_reduction

__all__: list[str] = [
    "BaseCodingWrapper",
    "ReducerFn",
    "identity_reduction",
]
