"""Experimental reducers for convolutional wrappers.

This module provides optional, opt-in reducers that can be passed to
``CodingConv2d`` (or any wrapper built on ``BaseCodingWrapper``) to prototype
alternative spatial reductions beyond the default global average pooling.

The helpers return callables that match ``ReducerFn`` so they can be supplied
via the existing ``reducer=...`` parameter without changing stable defaults.

Notes
- These reducers are experimental and off by default. They preserve the
  observe-only contract: reductions are applied only on the coding path.
"""

from __future__ import annotations

from typing import Any

from .base import ReducerFn

__all__ = [
    "global_max_pool2d",
    "spatial_tokens_identity_channels",
]


def global_max_pool2d() -> ReducerFn:
    """Return a reducer that applies global max pooling over H and W.

    Expects a 4D tensor with NCHW layout (``(B, C, H, W)``) and returns a
    pooled tensor of shape ``(B, C)``. Metadata records the reduction method
    and axes.
    """

    def _reduce(x: Any) -> tuple[Any, dict[str, Any]]:
        # Require a 4D tensor-like object with an `amax` reduction
        if getattr(x, "ndim", 0) != 4 or not hasattr(x, "amax"):
            raise ValueError("global_max_pool2d expects a 4D NCHW tensor from Conv2d (B, C, H, W)")
        # Max over spatial dims (H, W) -> (B, C)
        reduced = x.amax(dim=(-1, -2))
        meta = {
            "method": "global_max_pool2d",
            "spatial_reduction": True,
            "reduction_axes": [-2, -1],  # H, W in NCHW
        }
        return reduced, meta

    # Return the callable reducer
    return _reduce


def spatial_tokens_identity_channels() -> ReducerFn:
    """Return a reducer that exposes per-spatial-position tokens with C last.

    Transforms a standard Conv2d output ``(B, C, H, W)`` into a token-like
    layout ``(B, H, W, C)`` without reducing channels. This allows computing
    assignments per spatial position while keeping observe-only semantics.

    The metadata clarifies that the view is token-like (no spatial reduction).
    """

    def _reduce(x: Any) -> tuple[Any, dict[str, Any]]:
        # Require a 4D tensor-like object with `permute` and `contiguous`
        if getattr(x, "ndim", 0) != 4 or not hasattr(x, "permute"):
            raise ValueError(
                "spatial_tokens_identity_channels expects a 4D NCHW tensor (B, C, H, W)"
            )
        # Permute to BHWC so that the feature dimension is last for coding.
        reduced = x.permute(0, 2, 3, 1).contiguous()
        meta = {
            "method": "spatial_tokens_identity",
            "token_like": True,
            "channels_last": True,
            "spatial_reduction": False,
            "source_layout": "NCHW",
            "target_layout": "NHWC",
        }
        return reduced, meta

    return _reduce
