"""Model instrumentation helpers for coding wrappers.

This module provides a small `wrap()` function that can instrument a PyTorch
`nn.Module` in-place based on either:

- explicit dotted module names (e.g., ["encoder.fc", "head.1"]), or
- supported selection shortcuts (MVP: "all_linear").

Only supported layer types are wrapped; others are left unchanged to preserve
fail-open behavior. The function returns the same model instance for
convenience.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

try:  # Keep runtime import optional for environments without torch
    import torch
    from torch import nn
except Exception:  # pragma: no cover - import-time optionality
    from typing import Any
    from typing import cast as _cast

    torch = _cast(Any, None)
    nn = _cast(Any, None)

from .conv import CodingConv2d
from .linear import CodingLinear

__all__ = ["wrap"]


def wrap(
    model: Any,
    *,
    layers: str | Iterable[str] = "all_linear",
    K: int | None = None,
    coding_dim: int | None = None,
    temperature: float = 1.0,
    eps: float = 1e-12,
) -> Any:
    """Instrument ``model`` in-place with coding wrappers.

    Parameters
    - model: A PyTorch ``nn.Module`` to instrument. The function modifies the
      module tree in-place and returns the same instance for convenience.
    - layers: Either a selection shortcut string (MVP supports only
      ``"all_linear"``) or an iterable of explicit dotted module names to
      wrap. Names must match those returned by ``model.named_modules()``.

    Behavior
    - Only supported layer types are wrapped. Currently this includes
      ``nn.Linear`` via ``CodingLinear``. Unsupported selections are ignored to
      preserve fail-open behavior.
    - Missing names are ignored.
    - On environments without PyTorch, the function is a no-op and returns the
      model unchanged.
    """

    if nn is None:  # pragma: no cover - defensive; torch is a dependency in tests
        return model

    # Validate basic interface; fall back to no-op when model is not an nn.Module
    if not isinstance(model, nn.Module):
        return model

    # Resolve target names to instrument
    if isinstance(layers, str):
        target_names = _select_by_shortcut(model, layers)
    else:
        # Deduplicate while preserving order
        seen: set[str] = set()
        target_names = []
        for name in layers:
            if not isinstance(name, str):
                continue
            if name not in seen:
                seen.add(name)
                target_names.append(name)

    # Map types to wrapper factories; extend as new wrappers are added.
    def _wrap_module(m: nn.Module) -> nn.Module | None:
        if isinstance(m, nn.Linear):
            kwargs: dict[str, Any] = {
                "temperature": float(temperature),
                "eps": float(eps),
            }
            if K is not None:
                kwargs["K"] = int(K)
            if coding_dim is not None:
                # Clamp coding_dim per layer to avoid invalid configuration
                try:
                    cd_req = int(coding_dim)
                    cd_eff = max(1, min(int(m.out_features), cd_req))
                except Exception:
                    cd_eff = int(m.out_features)
                kwargs["coding_dim"] = cd_eff
            # Defensive: if downstream validation still rejects coding_dim,
            # fall back to using the layer's out_features to avoid crashes.
            try:
                return CodingLinear(m, **kwargs)
            except Exception as exc:
                msg = str(exc)
                if "coding_dim must be <= layer.out_features" in msg:
                    safe_kwargs = dict(kwargs)
                    safe_kwargs["coding_dim"] = int(getattr(m, "out_features", 1) or 1)
                    return CodingLinear(m, **safe_kwargs)
                raise
        if isinstance(m, nn.Conv2d):
            kwargs_c: dict[str, Any] = {
                "temperature": float(temperature),
                "eps": float(eps),
            }
            if K is not None:
                kwargs_c["K"] = int(K)
            if coding_dim is not None:
                try:
                    cd_req = int(coding_dim)
                    cd_eff = max(1, min(int(m.out_channels), cd_req))
                except Exception:
                    cd_eff = int(m.out_channels)
                kwargs_c["coding_dim"] = cd_eff
            try:
                return CodingConv2d(m, **kwargs_c)
            except Exception as exc:
                msg = str(exc)
                if "coding_dim must be <=" in msg:
                    safe_kwargs_c = dict(kwargs_c)
                    safe_kwargs_c["coding_dim"] = int(getattr(m, "out_channels", 1) or 1)
                    return CodingConv2d(m, **safe_kwargs_c)
                raise
        return None

    # Instrument selected modules by replacing them on their parent.
    for name in target_names:
        try:
            # Skip the top-level module itself
            if name == "":
                continue
            # get_submodule raises on unknown names; ignore gracefully
            sub = model.get_submodule(name)
        except Exception:
            continue
        wrapped = _wrap_module(sub)
        if wrapped is None:
            continue  # unsupported type
        parent_path, leaf = _split_parent(name)
        try:
            parent = model.get_submodule(parent_path) if parent_path else model
        except Exception:
            continue
        # Replace on the parent; handle non-identifier names (e.g., Sequential indices)
        if leaf.isidentifier():
            setattr(parent, leaf, wrapped)
        else:
            # Fall back to the internal registry for names like "1" in Sequential
            parent._modules[leaf] = wrapped

    return model


def _split_parent(path: str) -> tuple[str, str]:
    """Return (parent_path, leaf) for a dotted module path.

    Examples
    - "fc1" -> ("", "fc1")
    - "block.1" -> ("block", "1")
    - "encoder.layer.0.attn" -> ("encoder.layer.0", "attn")
    """

    if "." not in path:
        return "", path
    parent, leaf = path.rsplit(".", 1)
    return parent, leaf


def _select_by_shortcut(model: nn.Module, key: str) -> list[str]:
    """Return module names selected by a supported shortcut key.

    Supported keys (MVP):
    - "all_linear": select every ``nn.Linear`` in ``model``.
    - "all_conv": select every ``nn.Conv2d`` in ``model``.
    - "last_block", "last_two_blocks", and "all_blocks": select ResNet-style
      Conv2d blocks named ``layer4``, ``layer3``/``layer4``, or ``layer1``-``layer4``.
    Unrecognized keys select nothing (fail-open).
    """

    key_norm = key.strip().lower()

    # all_* shortcuts: filter across named_modules
    if key_norm == "all_linear":
        return [name for name, m in model.named_modules() if isinstance(m, nn.Linear)]
    if key_norm == "all_conv":
        return [name for name, m in model.named_modules() if isinstance(m, nn.Conv2d)]
    if key_norm == "last_block":
        return _select_resnet_block_convs(model, {"layer4"})
    if key_norm == "last_two_blocks":
        return _select_resnet_block_convs(model, {"layer3", "layer4"})
    if key_norm == "all_blocks":
        return _select_resnet_block_convs(model, {"layer1", "layer2", "layer3", "layer4"})

    # first/last convenience: select a single Linear
    if key_norm == "first_linear":
        for name, m in model.named_modules():
            if isinstance(m, nn.Linear) and name:
                return [name]
        return []
    if key_norm == "last_linear":
        last: str | None = None
        for name, m in model.named_modules():
            if isinstance(m, nn.Linear) and name:
                last = name
        return [last] if last else []

    # first/last convenience for Conv2d
    if key_norm == "first_conv":
        for name, m in model.named_modules():
            if isinstance(m, nn.Conv2d) and name:
                return [name]
        return []
    if key_norm == "last_conv":
        last_c: str | None = None
        for name, m in model.named_modules():
            if isinstance(m, nn.Conv2d) and name:
                last_c = name
        return [last_c] if last_c else []

    # Unknown shortcut -> empty selection (fail-open)
    return []


def _select_resnet_block_convs(model: nn.Module, blocks: set[str]) -> list[str]:
    """Select Conv2d modules in ResNet-style stage blocks."""

    out: list[str] = []
    for name, module in model.named_modules():
        if not name or not isinstance(module, nn.Conv2d):
            continue
        top = name.split(".", 1)[0]
        if top in blocks:
            out.append(name)
    return out
