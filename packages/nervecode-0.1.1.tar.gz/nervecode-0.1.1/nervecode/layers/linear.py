"""Coding wrapper for ``torch.nn.Linear``.

This module provides ``CodingLinear`` — the first production wrapper that
observes a linear layer's output, reduces it (identity in the MVP), and
computes a coding trace via a learnable codebook and a soft assignment engine.

Observe-only contract: the wrapper never modifies the value returned to the
caller; coding runs side-by-side and updates an internal trace cache.
"""

from __future__ import annotations

from typing import Any

from .base import BaseCodingWrapper, ReducerFn

# Import torch lazily but with typing support. Keep runtime import optional so the
# package remains importable in environments without torch (tests will skip).
try:  # pragma: no cover - exercised in torch-enabled environments
    import torch
    from torch import nn
except Exception:  # pragma: no cover - allow import without torch
    from typing import Any
    from typing import cast as _cast

    torch = _cast(Any, None)
    nn = _cast(Any, None)

# Local core imports guarded by torch availability at use sites.
from nervecode.core import CodingTrace
from nervecode.core.assignment import SoftAssignment
from nervecode.core.codebook import Codebook

__all__ = ["CodingLinear"]


class CodingLinear(nn.Module, BaseCodingWrapper):
    """Observe-only wrapper around ``nn.Linear``.

    The wrapper delegates computation to the underlying ``nn.Linear`` and, when
    coding is active, computes a ``CodingTrace`` over the visible activation.
    The visible forward output is never altered.

    Parameters
    - layer: The ``nn.Linear`` module to wrap.
    - K: Number of codebook centers. Defaults to 16.
    - coding_dim: Target coding dimension ``D``. When ``None`` (default),
      uses ``layer.out_features``. If provided, must satisfy
      ``1 <= coding_dim <= layer.out_features``. A learned linear projection
      reducer is created automatically when ``layer.out_features > coding_dim``;
      otherwise the identity reduction is used.
    - reducer: Optional reducer callable. Overrides ``coding_dim`` behavior
      when provided. Defaults to identity (no reduction).
    - temperature: Soft-assignment temperature. Higher is softer.
    - eps: Numerical epsilon to clamp divisions and logs.

    Notes
    - MVP uses identity reduction; when a lower coding dimension is desired, a
      learned projection reducer will be added in a follow-up task.
    - ``repr(wrapper)`` includes ``code_dim``, codebook size ``K``, reducer type,
      and whether coding is enabled to make printed models self-descriptive.
    """

    def __init__(
        self,
        layer: Any,  # use Any to avoid a hard torch dependency in type hints
        *,
        K: int = 16,
        coding_dim: int | None = None,
        reducer: ReducerFn | None = None,
        temperature: float = 1.0,
        eps: float = 1e-12,
    ) -> None:
        if torch is None:  # pragma: no cover - defensive
            raise RuntimeError("CodingLinear requires PyTorch to be installed")

        nn.Module.__init__(self)
        BaseCodingWrapper.__init__(self, reducer=reducer)

        if not isinstance(layer, nn.Linear):
            raise TypeError("layer must be an instance of torch.nn.Linear")

        self.layer: Any = layer

        # Decide coding dimension and set up reducer if not provided.
        out_features = int(self.layer.out_features)
        if coding_dim is None:
            code_dim = out_features
        else:
            code_dim = int(coding_dim)
            if code_dim <= 0:
                raise ValueError("coding_dim must be >= 1")
            if code_dim > out_features:
                raise ValueError("coding_dim must be <= layer.out_features for reduction")

        # Optional learned projection reducer when output width exceeds coding dim.
        self._projection: Any | None = None
        if reducer is None and code_dim < out_features:
            # Register a submodule to learn the reduction; keep observe-only semantics
            # by applying it only for coding. Bias is unnecessary for dimension change.
            self._projection = nn.Linear(out_features, code_dim, bias=False)

            def _project_reducer(x: Any) -> tuple[Any, dict[str, Any]]:
                y_proj = self._projection(x)  # type: ignore[misc]
                meta = {"method": "linear_projection", "in": out_features, "out": code_dim}
                return y_proj, meta

            self.set_reducer(_project_reducer)
        # else: keep provided reducer or identity_reduction

        # Codebook operates over the last (feature) dimension using the decided code_dim.
        self.codebook = Codebook(K=int(K), code_dim=code_dim)
        self.assignment = SoftAssignment(temperature=float(temperature), eps=float(eps))

    def forward(self, x: Any) -> Any:  # torch.Tensor in torch-enabled envs
        """Return the wrapped layer's output and update the cached trace.

        This method preserves the observe-only contract: the visible value is
        the underlying layer output. For robust programmatic use that avoids
        reading from mutable state, use ``forward_with_trace`` to retrieve the
        explicit ``CodingTrace`` alongside the output.
        """

        y, _ = self.forward_with_trace(x)
        return y

    def forward_with_trace(self, x: Any) -> tuple[Any, CodingTrace | None]:
        """Return the wrapped output and, when active, the explicit trace.

        When coding is disabled or bypassed, returns ``(y, None)`` while
        clearing any previously cached trace to avoid confusion. When active,
        computes a fresh ``CodingTrace``, updates the internal cache, and
        returns ``(y, trace)``.
        """

        y = self.layer(x)

        # Fast path: skip all coding work when disabled or bypassed.
        if not self.is_coding_active:
            # Clear stale trace to avoid confusion when toggling modes.
            self.clear_last_trace()
            return y, None

        # Apply the configured reducer (identity by default in MVP).
        reduced, reduction_meta = self.maybe_reduce(y)

        # Compute soft assignments and gather intermediates for the trace.
        soft, inter = self.assignment(reduced, self.codebook)

        trace = CodingTrace(
            reduced=reduced,
            reduction_meta=reduction_meta,
            nearest_center_distances=inter["nearest_center_distances"],
            chosen_center_indices=inter["chosen_center_indices"],
            commitment_distances=inter["commitment_distances"],
            soft_code=soft,
        )
        self.update_last_trace(trace)
        return y, trace

    def extra_repr(self) -> str:  # pragma: no cover - cosmetic
        """Human-friendly summary shown inside ``nn.Module.__repr__``.

        Includes the coding-space dimension (``code_dim``), codebook size
        (``K``), the configured reducer type, and whether coding is currently
        enabled. Also echoes the wrapped linear layer's ``out_features`` for
        quick visual alignment.
        """

        status = "on" if self.coding_enabled else "off"
        return (
            f"layer=Linear(out_features={int(self.layer.out_features)}), "
            f"code_dim={int(self.codebook.code_dim)}, "
            f"K={int(self.codebook.K)}, reducer={self.get_reducer().__name__}, "
            f"coding={status}"
        )
