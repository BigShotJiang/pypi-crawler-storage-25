"""Integration points and adapters.

This subpackage will provide adapters and convenience utilities for integrating
Nervecode into applications, scripts, and logging pipelines.
"""

from __future__ import annotations

__all__: list[str] = []
