"""Shape helpers for coding engines.

This module provides utilities to flatten and unflatten the leading dimensions
of tensors that follow the common Nervecode convention of a feature or code
dimension as the final axis. This allows assignment and distance computations to
operate uniformly on shapes like:

- batch-only: ``(B, D)`` or probabilities ``(B, K)``,
- token-like: ``(B, T, D)`` or ``(B, T, K)``,
- pooled convolution: ``(B, H, W, D)`` or ``(B, H, W, K)``.

By flattening the leading dimensions, engines can work over a simple 2D view
``(N, D)`` or ``(N, K)`` where ``N = prod(leading_shape)``. The corresponding
unflatten operation restores the original leading layout.
"""

from __future__ import annotations

import torch

__all__ = [
    "flatten_leading",
    "leading_shape",
    "unflatten_leading",
]


def leading_shape(x: torch.Tensor) -> tuple[int, ...]:
    """Return the tuple of leading dimensions before the final axis.

    Given a tensor ``x`` with shape ``(..., D)``, this returns ``...``.

    Parameters
    - x: Tensor with at least one dimension.

    Returns
    - Tuple of ints representing the leading shape.
    """

    if x.ndim < 1:
        raise ValueError("x must have at least one dimension (..., D)")
    # Explicit int cast to avoid mypy complaints about torch.Size contents.
    return tuple(int(s) for s in x.shape[:-1])


def flatten_leading(x: torch.Tensor) -> tuple[torch.Tensor, tuple[int, ...]]:
    """Flatten all leading dims into a single dimension.

    For an input with shape ``(..., D)``, returns ``x_flat`` with shape
    ``(N, D)`` where ``N = prod(...)`` along with the original leading shape.

    This is a light wrapper around ``reshape`` that preserves non-contiguity
    safety.

    Parameters
    - x: Tensor of shape ``(..., D)``.

    Returns
    - x_flat: Tensor of shape ``(N, D)`` where ``N = prod(leading_shape)``.
    - lead: The original leading shape as a tuple of ints.
    """

    if x.ndim < 1:
        raise ValueError("x must have at least one dimension (..., D)")
    lead = leading_shape(x)
    d = int(x.shape[-1])
    # Compute N = prod(lead) safely even when lead is empty.
    n = 1
    for s in lead:
        n *= int(s)
    # Use reshape to handle non-contiguous inputs robustly.
    x_flat = x.reshape(n, d)
    return x_flat, lead


def unflatten_leading(y: torch.Tensor, lead: tuple[int, ...]) -> torch.Tensor:
    """Restore a flattened first dimension back to ``lead``.

    If ``y`` has shape ``(N, ...)`` where ``N = prod(lead)``, the returned
    tensor has shape ``(*lead, ...)``. This works for scalar-like per-position
    tensors (``(N,)``), probability tensors (``(N, K)``), and vector-valued
    tensors (``(N, D)``).

    Parameters
    - y: Tensor whose first dimension flattens a known set of leading dims.
    - lead: Tuple of leading sizes that were previously flattened.

    Returns
    - Tensor reshaped to ``(*lead, *y.shape[1:])``.
    """

    # Validate that y has at least one dimension representing the flattened N.
    if y.ndim < 1:
        raise ValueError("y must have at least one dimension (N, ...)")

    # Compute expected N and verify it matches when eager shapes are available.
    n = 1
    for s in lead:
        n *= int(s)
    if int(y.shape[0]) != n:
        raise ValueError(f"first dimension {int(y.shape[0])} does not match prod(lead)={n}")

    # Reshape back to the original leading layout, preserving trailing dims.
    if y.ndim == 1:
        # Special case: scalar-like values (N,) -> (*lead,)
        return y.reshape(*lead)
    return y.reshape(*lead, *y.shape[1:])
