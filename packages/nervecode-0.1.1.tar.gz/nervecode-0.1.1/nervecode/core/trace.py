"""Trace data structures for coding.

This module defines lightweight, immutable containers that carry the rich
per-layer record produced during coding. Traces support arbitrary leading
dimensions so they can represent batch-only, token-like, or pooled layouts.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .types import SoftCode

__all__ = ["CodingTrace"]


@dataclass(frozen=True)
class CodingTrace:
    """Per-layer coding trace.

    Carries the reduced activation, reduction metadata, nearest-center and
    commitment distances, chosen indices, and the corresponding ``SoftCode``.

    Fields
    - ``reduced`` (Tensor): reduced activation with shape ``(..., D)``.
    - ``reduction_meta`` (dict): metadata describing the applied reduction
      (e.g., method, parameters). May be empty when no reduction is applied.
    - ``nearest_center_distances`` (Tensor): distance to the selected center
      per position with shape matching the leading dimensions ``...``.
    - ``chosen_center_indices`` (Tensor): index of the selected/nearest center
      per position with shape matching the leading dimensions ``...``.
    - ``commitment_distances`` (Tensor): commitment distance per position with
      shape matching the leading dimensions ``...``.
    - ``soft_code`` (SoftCode): soft assignment statistics over ``K`` codes
      with probabilities of shape ``(..., K)``.

    All scalar-like fields must match the leading shape of ``soft_code.probs``
    exactly (i.e., ``tensor.shape == soft_code.probs.shape[:-1]``).
    """

    reduced: Any
    reduction_meta: dict[str, Any]
    nearest_center_distances: Any
    chosen_center_indices: Any
    commitment_distances: Any
    soft_code: SoftCode

    def __post_init__(self) -> None:
        # Import torch lazily to keep import-time dependencies lightweight.
        from typing import Any
        from typing import cast as _cast

        try:
            import torch
        except Exception:  # pragma: no cover - torch may be absent in some envs
            torch = _cast(Any, None)

        # Basic validation of required components
        if not isinstance(self.soft_code, SoftCode):  # pragma: no cover - defensive
            raise TypeError("soft_code must be a SoftCode instance")

        # Validate reduced tensor shape
        if torch is not None and not isinstance(
            self.reduced, torch.Tensor
        ):  # pragma: no cover - defensive
            raise TypeError("reduced must be a torch.Tensor")
        if getattr(self.reduced, "ndim", None) is None or self.reduced.ndim < 1:
            raise ValueError("reduced must have at least one dimension (..., D)")
        if int(self.reduced.shape[-1]) <= 0:
            raise ValueError("final reduced dimension D must be >= 1")

        # If torch isn't available, skip dtype/shape validations that require it.
        if torch is None:  # pragma: no cover
            return

        lead_shape = tuple(int(s) for s in self.soft_code.leading_shape)
        reduced_lead = tuple(int(s) for s in self.reduced.shape[:-1])
        if reduced_lead != lead_shape:
            raise ValueError(
                f"reduced.leading_shape {reduced_lead} must match "
                f"soft_code.leading_shape {lead_shape}"
            )

        def _check_scalar_tensor(name: str, value: Any, *, require_integer: bool = False) -> None:
            if not isinstance(value, torch.Tensor):
                raise TypeError(f"{name} must be a torch.Tensor")
            if tuple(int(s) for s in value.shape) != lead_shape:
                raise ValueError(
                    f"{name} must have shape {lead_shape} to match soft_code.leading_shape"
                )
            if require_integer:
                if torch.is_floating_point(value) or value.dtype == torch.bool:
                    raise TypeError(f"{name} must use an integer dtype")
            else:
                if value.dtype == torch.bool:
                    raise TypeError(f"{name} must be numeric, not bool")

        _check_scalar_tensor("nearest_center_distances", self.nearest_center_distances)
        _check_scalar_tensor(
            "chosen_center_indices", self.chosen_center_indices, require_integer=True
        )
        _check_scalar_tensor("commitment_distances", self.commitment_distances)

    @property
    def leading_shape(self) -> tuple[int, ...]:
        """Leading shape shared by all per-position fields."""

        return tuple(int(s) for s in self.soft_code.leading_shape)

    @property
    def reduced_dim(self) -> int:
        """Size of the final reduced dimension ``D``."""

        return int(self.reduced.shape[-1])

    # --- Sample-level reduction views -------------------------------------------
    def sample_reduced_surprise(self, *, reduction: str = "mean") -> Any:
        """Return a per-sample surprise tensor by reducing extra leading dims.

        Many wrappers operate over activations with multiple leading dimensions
        (e.g., batch and sequence). Aggregation across layers requires a common
        per-sample view. This helper reduces the per-position surprise stored on
        the associated ``SoftCode`` to a vector over samples by collapsing all
        leading dimensions after the first (typically sequence/time) using the
        specified reduction.

        Parameters
        - reduction: Current supported value is ``"mean"``. Additional
          reductions may be added later.

        Returns
        - A tensor with shape ``(B,)`` where ``B`` is the size of the first
          leading dimension. In environments without torch or when an
          interpretable surprise is unavailable, this may return ``None`` at
          runtime; the return type is ``Any`` to remain flexible during import
          without a hard torch dependency.
        """

        # Import torch lazily to avoid hard dependency at import time.
        try:
            import torch
        except Exception:  # pragma: no cover - environments without torch
            return None

        # Prefer a combined surprise when present; otherwise use best_length.
        cand = self.soft_code.combined_surprise
        if cand is None:
            cand = self.soft_code.best_length
        if not isinstance(cand, torch.Tensor):
            return None

        # Scalar-like can't be mapped to samples reliably; skip.
        if cand.ndim == 0:  # pragma: no cover - uncommon layout
            return None

        if cand.ndim == 1:
            return cand

        # Reduce all leading dims after the first to obtain a per-sample vector.
        if reduction == "mean":
            dims = tuple(range(1, int(cand.ndim)))
            return cand.mean(dim=dims)
        # Fallback: default to mean for unknown identifiers to remain fail-open.
        dims = tuple(range(1, int(cand.ndim)))
        return cand.mean(dim=dims)
