"""Temperature schedules for coding and training.

This module provides a minimal interface and two concrete schedules for the
MVP: a fixed temperature and a cosine schedule. The interface is designed so
that a future learnable temperature (e.g., an ``nn.Parameter`` inside an
``nn.Module``) can conform to the same calling convention.

Design goals
- Keep evaluation cheap and dependency-light.
- Accept either explicit progress (``0..1``) or step-based inputs.
- Provide a tensor-producing helper for easy integration in Torch graphs.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, Protocol, TypeAlias, cast, runtime_checkable

# Optional PyTorch typing without a hard runtime dependency.
if TYPE_CHECKING:  # pragma: no cover - typing-only branch
    import torch as _torch
    from torch import Tensor as _Tensor

    TensorT: TypeAlias = _Tensor
    DeviceT: TypeAlias = _torch.device
    DTypeT: TypeAlias = _torch.dtype
else:  # Fallbacks keep the module importable without torch installed.
    TensorT: TypeAlias = Any
    DeviceT: TypeAlias = Any
    DTypeT: TypeAlias = Any

__all__ = ["CosineTemperature", "FixedTemperature", "TemperatureSchedule"]


def _require_torch() -> Any:
    """Import torch on-demand with a helpful error if missing.

    This keeps the module importable when PyTorch is not installed while still
    supporting ``as_tensor`` helpers for users who have it.
    """
    try:
        import torch
    except Exception as exc:  # pragma: no cover - exercised in envs without torch
        raise RuntimeError(
            "as_tensor requires PyTorch; install 'torch' to use this method."
        ) from exc
    return torch


@runtime_checkable
class TemperatureSchedule(Protocol):
    """Callable interface for temperature schedules.

    Implementations should return a positive scalar temperature when invoked.
    Schedules may accept either normalized progress in ``[0, 1]`` via the
    ``progress`` keyword, or a ``step`` index with an associated total number
    of steps ``total``. When both are supplied, ``progress`` takes precedence.
    """

    def __call__(
        self,
        step: int | None = None,
        *,
        total: int | None = None,
        progress: float | None = None,
    ) -> float:  # pragma: no cover - interface only
        ...

    def as_tensor(
        self,
        step: int | None = None,
        *,
        total: int | None = None,
        progress: float | None = None,
        device: DeviceT | None = None,
        dtype: DTypeT | None = None,
    ) -> TensorT:  # pragma: no cover - interface only
        ...


class FixedTemperature:
    """Constant temperature independent of step or progress."""

    def __init__(self, temperature: float) -> None:
        t = float(temperature)
        if not math.isfinite(t) or t <= 0.0:
            raise ValueError("temperature must be a positive finite float")
        self._t: float = t

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"FixedTemperature(temperature={self._t})"

    def __call__(
        self,
        step: int | None = None,
        *,
        total: int | None = None,
        progress: float | None = None,
    ) -> float:
        # Parameters are accepted for interface uniformity; they do not affect
        # a fixed schedule.
        _ = step, total, progress
        return self._t

    def as_tensor(
        self,
        step: int | None = None,
        *,
        total: int | None = None,
        progress: float | None = None,
        device: DeviceT | None = None,
        dtype: DTypeT | None = None,
    ) -> TensorT:
        _ = step, total, progress
        torch = _require_torch()
        return cast("TensorT", torch.tensor(self._t, device=device, dtype=dtype))


class CosineTemperature:
    """Cosine schedule between ``start`` and ``end`` with optional warmup.

    The temperature follows the closed-form cosine schedule

    ``T(p) = end + (start - end) * 0.5 * (1 + cos(pi * p))``

    where ``p`` is normalized progress in ``[0, 1]``. Progress can be supplied
    directly, or derived from ``step``/``total`` while honoring
    ``warmup_steps``. During warmup, the temperature stays at ``start``.

    Parameters
    - start: Temperature at the beginning (``p = 0``). Must be ``> 0``.
    - end: Temperature at the end (``p = 1``). Must be ``> 0``.
    - total_steps: Default total steps for the schedule. Can be overridden per
      call using the ``total=`` kwarg.
    - warmup_steps: Number of initial steps to hold at ``start`` before
      annealing begins. Must be ``>= 0``.
    """

    def __init__(
        self,
        start: float,
        end: float,
        *,
        total_steps: int | None = None,
        warmup_steps: int = 0,
    ) -> None:
        s = float(start)
        e = float(end)
        if not math.isfinite(s) or s <= 0.0:
            raise ValueError("start must be a positive finite float")
        if not math.isfinite(e) or e <= 0.0:
            raise ValueError("end must be a positive finite float")
        if total_steps is not None and int(total_steps) <= 0:
            raise ValueError("total_steps must be >= 1 when provided")
        if int(warmup_steps) < 0:
            raise ValueError("warmup_steps must be >= 0")

        self.start: float = s
        self.end: float = e
        self.total_steps: int | None = int(total_steps) if total_steps is not None else None
        self.warmup_steps: int = int(warmup_steps)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return (
            "CosineTemperature("
            f"start={self.start}, end={self.end}, "
            f"total_steps={self.total_steps}, warmup_steps={self.warmup_steps})"
        )

    def _progress_from_step(self, step: int, total: int) -> float:
        # Compute normalized progress in [0, 1] after warmup.
        s = max(0, int(step))
        t = max(1, int(total))
        w = max(0, self.warmup_steps)
        if s <= w:
            return 0.0
        # Remaining steps after warmup; guard against division by zero.
        remain = max(1, t - w)
        p = (s - w) / float(remain)
        # Clamp to [0, 1] to be robust against overrun.
        if p < 0.0:
            return 0.0
        if p > 1.0:
            return 1.0
        return p

    @staticmethod
    def _cosine_mix(start: float, end: float, p01: float) -> float:
        # Clamp progress defensively.
        p = 0.0 if p01 < 0.0 else (1.0 if p01 > 1.0 else p01)
        return end + (start - end) * 0.5 * (1.0 + math.cos(math.pi * p))

    def __call__(
        self,
        step: int | None = None,
        *,
        total: int | None = None,
        progress: float | None = None,
    ) -> float:
        if progress is not None:
            return self._cosine_mix(self.start, self.end, float(progress))

        # Derive progress from steps; prefer call-time total over default.
        resolved_total = int(total) if total is not None else self.total_steps
        if resolved_total is None or step is None:
            raise ValueError(
                "CosineTemperature requires either progress in [0,1] or both step and total"
            )

        p = self._progress_from_step(int(step), int(resolved_total))
        # During warmup (_progress_from_step returns 0), hold at start when step <= warmup
        if int(step) <= self.warmup_steps:
            return float(self.start)
        return self._cosine_mix(self.start, self.end, p)

    def as_tensor(
        self,
        step: int | None = None,
        *,
        total: int | None = None,
        progress: float | None = None,
        device: DeviceT | None = None,
        dtype: DTypeT | None = None,
    ) -> TensorT:
        val = self(step, total=total, progress=progress)
        torch = _require_torch()
        return cast("TensorT", torch.tensor(val, device=device, dtype=dtype))
