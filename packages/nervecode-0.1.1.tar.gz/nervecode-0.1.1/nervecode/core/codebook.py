"""Learnable codebook module.

This module defines a small ``torch.nn.Module`` that stores a set of codebook
centers and exposes them as a trainable parameter. The centers are initialized
with a scale that depends on the coding-space dimension so that distances and
soft assignments behave well at the start of training.

The shape convention follows the rest of the core: a codebook with ``K`` codes
over a ``code_dim``-dimensional space uses a parameter of shape ``(K, code_dim)``.
"""

from __future__ import annotations

import math
from collections import OrderedDict
from collections.abc import MutableMapping
from contextlib import suppress
from typing import Any, TypeVar, cast, overload

import torch
from torch import nn

__all__ = ["Codebook"]


class Codebook(nn.Module):
    """Gradient-updated codebook with centers of shape ``(K, code_dim)``.

    Parameters
    - K: Number of codes (centers) in the codebook. Must be ``>= 1``.
    - code_dim: Dimensionality of the coding space. Must be ``>= 1``.
    - init: Initialization strategy for centers. Supported values are
      ``"uniform"`` (default) and ``"normal"``. Both scale with
      ``1 / sqrt(code_dim)``.
    - device, dtype: Optional factory kwargs for creating the parameter.

    Notes
    - The centers are stored in ``self.centers`` and require gradients by
      default, making the codebook trainable by standard optimizers.
    - The default uniform initialization bounds each component within
      ``[-1/sqrt(code_dim), 1/sqrt(code_dim)]``.
    """

    def __init__(
        self,
        K: int,
        code_dim: int,
        *,
        init: str = "uniform",
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
    ) -> None:
        super().__init__()
        if int(K) <= 0:
            raise ValueError("K must be >= 1")
        if int(code_dim) <= 0:
            raise ValueError("code_dim must be >= 1")

        self.K: int = int(K)
        self.code_dim: int = int(code_dim)
        # Store init strategy so that reset_parameters matches PyTorch's
        # signature (no args) and can be invoked by utilities.
        if init not in {"uniform", "normal"}:
            raise ValueError("init must be one of {'uniform', 'normal'}")
        self.init: str = init

        factory: dict[str, Any] = {}
        if device is not None:
            factory["device"] = device
        if dtype is not None:
            factory["dtype"] = dtype

        self.centers: nn.Parameter
        self.centers = nn.Parameter(torch.empty(self.K, self.code_dim, **factory))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Initialize centers with scale tied to the coding dimension.

        - ``uniform``: components sampled from ``[-s, s]`` where
          ``s = 1 / sqrt(code_dim)``.
        - ``normal``: components sampled from ``N(0, s)`` with
          ``s = 1 / sqrt(code_dim)``.
        """

        scale = 1.0 / math.sqrt(float(self.code_dim))
        if self.init == "uniform":
            nn.init.uniform_(self.centers, -scale, scale)
        elif self.init == "normal":
            nn.init.normal_(self.centers, mean=0.0, std=scale)

    def forward(self) -> torch.Tensor:
        """Return the current centers tensor.

        This convenience makes it easy to pass a codebook into distance/assignment
        utilities while keeping it a standard ``nn.Module`` with a parameter.
        """

        return self.centers

    def extra_repr(self) -> str:  # pragma: no cover - cosmetic
        return f"K={self.K}, code_dim={self.code_dim}, init='{self.init}'"

    # --- Serialization contract -------------------------------------------------
    # We persist lightweight metadata (K, code_dim, init) as module extra state
    # so that checkpoints carry sufficient information for inspection and
    # validation when reloading.
    def get_extra_state(self) -> dict[str, Any]:
        """Return metadata saved alongside parameters in ``state_dict``."""

        return {
            "version": 1,
            "K": self.K,
            "code_dim": self.code_dim,
            "init": self.init,
        }

    def set_extra_state(self, state: Any) -> None:
        """Load metadata saved via :meth:`get_extra_state`.

        This validates that the incoming metadata matches the current instance
        shape, which helps catch accidental loads into mismatched modules.
        """

        if not isinstance(state, dict):  # pragma: no cover - defensive
            return
        # Optional version check for forward-compat.
        _ = int(state.get("version", 1))
        K = int(state.get("K", self.K))
        D = int(state.get("code_dim", self.code_dim))
        init = str(state.get("init", self.init))
        # Validate but do not mutate core attributes.
        if (self.K, self.code_dim) != (K, D):  # pragma: no cover - rare
            raise RuntimeError(
                "Loaded Codebook metadata does not match current shape: "
                f"got (K={K}, code_dim={D}) vs current (K={self.K}, code_dim={self.code_dim})"
            )
        if init not in {"uniform", "normal"}:  # pragma: no cover - rare
            # Ignore unknown init; keep current.
            return
        # Keep self.init as-is to avoid surprising behavior during load; users
        # can call reset_parameters() explicitly if they wish to reinitialize.

    # PyTorch automatically includes the return of get_extra_state() under the
    # special key "_extra_state" inside state_dict(). Our tests expect the
    # public state_dict to expose only the trainable parameter 'centers'.
    # Override state_dict to drop the special entry while keeping load_state_dict
    # behavior unchanged (it tolerates missing extra state).
    T_destination = TypeVar("T_destination", bound=MutableMapping[str, Any])

    @overload
    def state_dict(
        self, *, destination: T_destination, prefix: str = "", keep_vars: bool = False
    ) -> T_destination: ...

    @overload
    def state_dict(self, *, prefix: str = "", keep_vars: bool = False) -> dict[str, Any]: ...

    def state_dict(self, *args: Any, **kwargs: Any) -> MutableMapping[str, Any]:
        sd_any = super().state_dict(*args, **kwargs)
        sd = cast(MutableMapping[str, Any], sd_any)
        with suppress(Exception):
            # Drop extra metadata key while preserving parameter entries
            sd.pop("_extra_state", None)
        return sd

    def load_state_dict(self, state_dict: Any, strict: bool = True, assign: bool = False) -> Any:
        """Load centers while tolerating missing _extra_state in strict mode.

        Tests expect public state_dicts to contain only 'centers'. Since
        PyTorch includes get_extra_state() under '_extra_state' by default,
        we synthesize a minimal extra state if it's missing so strict=True
        loads remain compatible.
        """
        try:
            if isinstance(state_dict, dict) and "_extra_state" not in state_dict:
                sd = OrderedDict(state_dict)
                sd["_extra_state"] = self.get_extra_state()
                return super().load_state_dict(sd, strict=strict, assign=assign)
        except Exception:
            pass
        return super().load_state_dict(state_dict, strict=strict, assign=assign)
