"""Core type definitions.

This module defines lightweight dataclasses used across the core coding
pipeline. Shapes follow the convention that probability-like tensors carry
arbitrary leading dimensions with a final code dimension of size ``K``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["SoftCode"]


@dataclass(frozen=True)
class SoftCode:
    """Soft assignment over a codebook.

    The ``probs`` tensor encodes probabilities over ``K`` codes for each
    position in the (possibly batched) input. It supports arbitrary leading
    dimensions followed by a final code dimension of shape ``(..., K)``.

    Fields
    - `probs` (Tensor): probabilities over codes with shape ``(..., K)``.
    - `best_length` (Tensor, optional): best-code codelength per position
      with shape matching the leading dimensions ``...``.
    - `entropy` (Tensor, optional): assignment entropy per position with
      shape matching the leading dimensions ``...``.
    - `best_indices` (Tensor, optional): argmax code indices per position with
      shape matching the leading dimensions ``...``.
    - `combined_surprise` (Tensor, optional): a scalar-like per-position
      surprise that may combine multiple terms; shape matches ``...``.

    All optional scalar-like fields must match the leading dimensions of
    ``probs`` exactly (i.e., ``tensor.shape == probs.shape[:-1]``). When the
    leading shape is empty, scalar-like fields must be 0-dim tensors.
    """

    probs: Any
    best_length: Any | None = None
    entropy: Any | None = None
    best_indices: Any | None = None
    combined_surprise: Any | None = None

    def __post_init__(self) -> None:
        from typing import Any
        from typing import cast as _cast

        try:
            import torch  # runtime import; typing deferred
        except Exception:  # pragma: no cover - torch absent in some test envs
            torch = _cast(Any, None)

        # Validate probs tensor
        if torch is not None and not isinstance(
            self.probs, torch.Tensor
        ):  # pragma: no cover - defensive
            raise TypeError("probs must be a torch.Tensor")
        if getattr(self.probs, "ndim", None) is None or self.probs.ndim < 1:
            raise ValueError("probs must have at least one dimension (..., K)")
        k = int(self.probs.shape[-1])
        if k <= 0:
            raise ValueError("final code dimension K must be >= 1")

        # Optional fields shape validation (only when torch is available)
        if torch is None:  # pragma: no cover - validation relies on torch
            return

        lead_shape = tuple(int(s) for s in self.probs.shape[:-1])

        def _check_shape(name: str, value: Any) -> None:
            if not isinstance(value, torch.Tensor):
                raise TypeError(f"{name} must be a torch.Tensor if provided")
            if tuple(int(s) for s in value.shape) != lead_shape:
                raise ValueError(
                    f"{name} must have shape {lead_shape} to match probs.leading_shape"
                )

        if self.best_length is not None:
            _check_shape("best_length", self.best_length)
            # float-like recommended; do not hard-enforce dtype beyond non-bool
            if self.best_length.dtype == torch.bool:  # pragma: no cover - defensive
                raise TypeError("best_length must be numeric, not bool")

        if self.entropy is not None:
            _check_shape("entropy", self.entropy)
            if self.entropy.dtype == torch.bool:  # pragma: no cover - defensive
                raise TypeError("entropy must be numeric, not bool")

        if self.combined_surprise is not None:
            _check_shape("combined_surprise", self.combined_surprise)
            if self.combined_surprise.dtype == torch.bool:  # pragma: no cover - defensive
                raise TypeError("combined_surprise must be numeric, not bool")

        if self.best_indices is not None:
            _check_shape("best_indices", self.best_indices)
            # Require integer dtype for indices
            if torch.is_floating_point(self.best_indices) or self.best_indices.dtype == torch.bool:
                raise TypeError("best_indices must use an integer dtype")

    @property
    def leading_shape(self) -> tuple[int, ...]:
        """Return leading shape before the final code dimension.

        For ``probs`` with shape ``(..., K)``, this returns ``...`` as a tuple.
        """

        # mypy struggles with torch.Size as a tuple of ints; cast explicitly.
        return tuple(int(s) for s in self.probs.shape[:-1])

    @property
    def code_dim(self) -> int:
        """Size of the final code dimension ``K``."""

        return int(self.probs.shape[-1])
