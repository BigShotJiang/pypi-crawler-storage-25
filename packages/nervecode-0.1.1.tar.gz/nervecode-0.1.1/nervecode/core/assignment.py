"""Soft assignment engine.

This module computes squared Euclidean distances from reduced activations to a
codebook, converts them into soft assignments over codes, and returns both a
``SoftCode`` object and the intermediate tensors needed to construct a
``CodingTrace`` without recomputing distances.

Shapes follow the core convention:
- Inputs have shape ``(..., D)`` where ``...`` are arbitrary leading dims.
- Probabilities have shape ``(..., K)`` where ``K`` is the number of codes.
- Per-position scalar values have shape matching the leading dims ``...``.
"""

from __future__ import annotations

import torch
from torch import nn

from .codebook import Codebook
from .shapes import flatten_leading, unflatten_leading
from .types import SoftCode

__all__ = ["SoftAssignment"]


class SoftAssignment(nn.Module):
    """Compute soft assignments and return trace-ready intermediates.

    Parameters
    - temperature: Positive scalar controlling assignment sharpness. Larger
      values produce softer assignments. This parameter is not learnable; use a
      schedule or an external tensor if you need dynamic temperature.
    - eps: Small positive constant used to clamp divisions and logarithms to
      keep values finite.
    """

    def __init__(
        self,
        *,
        temperature: float = 1.0,
        eps: float = 1e-12,
        beta_length: float = 1.0,
        beta_entropy: float = 1.0,
        beta_distance: float = 0.0,
    ) -> None:
        super().__init__()
        t = float(temperature)
        if not torch.isfinite(torch.tensor(t)) or t <= 0.0:
            raise ValueError("temperature must be a positive finite float")
        e = float(eps)
        if not torch.isfinite(torch.tensor(e)) or e <= 0.0:
            raise ValueError("eps must be a positive finite float")
        # Explicit attribute annotation helps static type checkers understand
        # the buffer's type (avoids Tensor|Module unions on .to/.clamp paths).
        self._temperature: torch.Tensor
        self.register_buffer("_temperature", torch.tensor(t), persistent=False)
        self.eps: float = e
        # Weights for the combined surprise signal S = bL * L + bH * H + bD * D_norm
        self.beta_length: float = float(beta_length)
        self.beta_entropy: float = float(beta_entropy)
        self.beta_distance: float = float(beta_distance)

    @property
    def temperature(self) -> float:
        return float(self._temperature.item())

    def forward(
        self,
        reduced: torch.Tensor,
        codebook: Codebook | torch.Tensor,
    ) -> tuple[SoftCode, dict[str, torch.Tensor]]:
        """Return soft code and intermediates for ``CodingTrace``.

        Inputs
        - reduced: Tensor of shape ``(..., D)`` representing reduced activations.
        - codebook: ``Codebook`` module or a centers tensor of shape
          ``(K, D)``.

        Returns
        - soft_code: ``SoftCode`` with probabilities ``(..., K)`` and basic
          scalar statistics (best length, entropy, best indices, combined surprise).
        - intermediates: dict with keys
            - ``nearest_center_distances``: ``(...,)``
            - ``chosen_center_indices``: integer ``(...,)``
            - ``commitment_distances``: ``(...,)``
          which are sufficient to construct a ``CodingTrace`` without
          recomputation.
        """

        centers = codebook() if isinstance(codebook, Codebook) else codebook

        if centers.ndim != 2:
            raise ValueError("centers must have shape (K, D)")

        x = reduced
        if x.ndim < 1:
            raise ValueError("reduced must have at least one dimension (..., D)")

        x_flat, lead = flatten_leading(x)  # (N, D)
        d = int(centers.shape[1])
        if int(x_flat.shape[1]) != d:
            raise ValueError(f"reduced last dim {int(x_flat.shape[1])} must match centers D={d}")

        # Compute squared Euclidean distances using the expansion
        # ||x - c||^2 = ||x||^2 + ||c||^2 - 2 x·c
        x_norm = (x_flat * x_flat).sum(dim=1, keepdim=True)  # (N, 1)
        c_norm = (centers * centers).sum(dim=1).unsqueeze(0)  # (1, K)
        # x @ centers^T yields (N, K)
        dot = x_flat @ centers.t()  # (N, K)
        distances = x_norm + c_norm - 2.0 * dot  # (N, K)
        # For numerical safety, clamp at zero from below (squared distances).
        distances = distances.clamp_min(0.0)

        # Convert distances into softmax probabilities over codes using
        # negative distances as logits, scaled by temperature.
        t = self._temperature.to(dtype=distances.dtype, device=distances.device)
        logits = -distances / torch.clamp(t, min=self.eps)
        probs_flat = torch.softmax(logits, dim=-1)

        # Best indices from min distance (equivalently max probability).
        best_idx_flat = torch.argmin(distances, dim=-1)  # (N,)
        # Nearest-center distances and commitment distances per position.
        nearest_flat = distances.gather(-1, best_idx_flat.unsqueeze(-1)).squeeze(-1)  # (N,)
        commitment_flat = nearest_flat  # identical for squared Euclidean

        # Information-theoretic scalars
        eps_t = torch.tensor(self.eps, dtype=probs_flat.dtype, device=probs_flat.device)
        best_prob_flat = probs_flat.gather(-1, best_idx_flat.unsqueeze(-1)).squeeze(-1)
        best_length_flat = -(best_prob_flat + eps_t).log()
        entropy_flat = -(probs_flat * (probs_flat + eps_t).log()).sum(dim=-1)
        # Distance-based component: use a stable, monotonically increasing
        # transform of the nearest-center squared Euclidean distance. ``log1p``
        # reduces dynamic range without erasing separation. Avoid per-forward
        # normalization to preserve absolute contrast between ID and OOD.
        d_comp_flat = torch.log1p(nearest_flat)
        # Weighted combination including optional distance contribution
        combined_surprise_flat = (
            self.beta_length * best_length_flat
            + self.beta_entropy * entropy_flat
            + self.beta_distance * d_comp_flat
        )

        # Restore original leading layout
        probs = unflatten_leading(probs_flat, lead)  # (..., K)
        best_idx = unflatten_leading(best_idx_flat, lead)  # (...,)
        nearest = unflatten_leading(nearest_flat, lead)  # (...,)
        commitment = unflatten_leading(commitment_flat, lead)  # (...,)
        best_length = unflatten_leading(best_length_flat, lead)  # (...,)
        entropy = unflatten_leading(entropy_flat, lead)  # (...,)
        combined_surprise = unflatten_leading(combined_surprise_flat, lead)  # (...,)

        soft = SoftCode(
            probs=probs,
            best_length=best_length,
            entropy=entropy,
            best_indices=best_idx,
            combined_surprise=combined_surprise,
        )

        intermediates: dict[str, torch.Tensor] = {
            "nearest_center_distances": nearest,
            "chosen_center_indices": best_idx,
            "commitment_distances": commitment,
        }
        return soft, intermediates
