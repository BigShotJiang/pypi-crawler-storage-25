"""Core data model, primitives, and engines.

This subpackage will host the core types, codebook modules, assignment
algorithms, and trace representations used across Nervecode.
"""

from __future__ import annotations

from .temperature import CosineTemperature, FixedTemperature, TemperatureSchedule
from .trace import CodingTrace
from .types import SoftCode

__all__: list[str] = [
    "CodingTrace",
    "CosineTemperature",
    "FixedTemperature",
    "SoftCode",
    "TemperatureSchedule",
]
