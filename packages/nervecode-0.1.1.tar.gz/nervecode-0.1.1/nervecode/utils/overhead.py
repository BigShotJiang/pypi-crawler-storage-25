"""Overhead estimators for pooled Conv2d coding.

This module provides lightweight, deterministic estimators for the compute and
memory overhead of the pooled-convolutional coding path used by
``nervecode.layers.conv.CodingConv2d``. The estimates are torch-agnostic and
intended for documentation, sanity checks, and unit tests — not for replacing
runtime profiling.

Conventions
- We report multiply-accumulate operations (MACs) rather than FLOPs. A single
  multiply followed by an add counts as one MAC. The baseline Conv2d MACs use
  the common approximation: ``B * H_out * W_out * C_out * (C_in * kH * kW)``.
- Coding overhead counts are broken down into: global-average pooling over
  spatial dimensions, optional linear projection (when ``coding_dim < C_out``),
  and codebook distance + soft-assignment operations of size ``(B, D, K)``.
- Memory estimates cover transient activations in the coding path (e.g., the
  pooled vector ``(B, D)`` and soft-code ``(B, K)``) and parameter overhead
  introduced by the wrapper (codebook centers and optional projection matrix).

These estimates aim to be simple and stable across environments. Real kernels
and library implementations may differ by constant factors, fusions, and cache
effects; treat the results as order-of-magnitude guidance.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PooledConvConfig:
    """Configuration for a 2D convolution with pooled coding.

    All dimensions are positive integers. ``kernel_size``, ``stride``,
    ``padding``, and ``dilation`` accept symmetric pairs as ``(h, w)``.

    Fields
    - batch: batch size ``B``
    - in_channels: input channels ``C_in``
    - out_channels: output channels ``C_out``
    - in_size: input spatial size ``(H_in, W_in)``
    - kernel_size: kernel size ``(kH, kW)``
    - stride: stride ``(sH, sW)``
    - padding: padding ``(pH, pW)``
    - dilation: dilation ``(dH, dW)``
    - coding_dim: pooled coding dimension ``D``; defaults to ``C_out``
    - K: codebook size
    - dtype_bytes: bytes per float element for activation estimates (default: 4)
    """

    batch: int
    in_channels: int
    out_channels: int
    in_size: tuple[int, int]
    kernel_size: tuple[int, int] = (3, 3)
    stride: tuple[int, int] = (1, 1)
    padding: tuple[int, int] = (0, 0)
    dilation: tuple[int, int] = (1, 1)
    coding_dim: int | None = None
    K: int = 16
    dtype_bytes: int = 4

    def output_size(self) -> tuple[int, int]:
        """Compute the output spatial size (H_out, W_out) for the conv2d.

        Uses the standard convolution formula with floor division.
        """

        H_in, W_in = self.in_size
        kH, kW = self.kernel_size
        sH, sW = self.stride
        pH, pW = self.padding
        dH, dW = self.dilation

        H_out = (H_in + 2 * pH - dH * (kH - 1) - 1) // sH + 1
        W_out = (W_in + 2 * pW - dW * (kW - 1) - 1) // sW + 1
        return int(H_out), int(W_out)

    def resolved_coding_dim(self) -> int:
        """Return effective coding dimension ``D`` (defaults to ``C_out``)."""

        return int(self.out_channels if self.coding_dim is None else self.coding_dim)


@dataclass(frozen=True)
class OverheadEstimate:
    """Deterministic estimate of compute and memory costs for pooled coding.

    Fields
    - conv_macs: baseline Conv2d MACs per forward pass.
    - coding_macs_total: total MACs added by pooled coding.
    - coding_macs_breakdown: dict with keys ``pool``, ``projection``,
      ``codebook`` (distance + assignment), and ``softmax`` (small terms).
    - param_overhead: number of parameters introduced by the wrapper
      (codebook centers + optional projection).
    - activation_overhead_bytes: estimated transient activation bytes in the
      coding path (pooled vector and soft-code; float elements only).
    - overhead_ratio: ``coding_macs_total / conv_macs`` when ``conv_macs > 0``
      else ``None``.
    """

    conv_macs: int
    coding_macs_total: int
    coding_macs_breakdown: dict[str, int]
    param_overhead: int
    activation_overhead_bytes: int
    overhead_ratio: float | None


def estimate_pooled_conv_overhead(cfg: PooledConvConfig) -> OverheadEstimate:
    """Estimate compute and memory overhead for pooled Conv2d coding.

    The estimator uses simple closed-form counts for MACs and activation sizes
    that match the pooled-coding path in ``CodingConv2d``. See module docstring
    for conventions and caveats.
    """

    B = int(cfg.batch)
    Cin = int(cfg.in_channels)
    Cout = int(cfg.out_channels)
    kH, kW = (int(cfg.kernel_size[0]), int(cfg.kernel_size[1]))
    H_out, W_out = cfg.output_size()
    D = int(cfg.resolved_coding_dim())
    K = int(cfg.K)
    bytes_per = max(1, int(cfg.dtype_bytes))

    # Baseline conv MACs (multiply-accumulate count)
    conv_macs = B * H_out * W_out * Cout * (Cin * kH * kW)

    # Coding computations
    # 1) Global average pool over spatial dims: sum H*W then divide (per channel)
    pool_macs = B * Cout * H_out * W_out

    # 2) Optional linear projection when D < Cout
    proj_macs = 0
    proj_params = 0
    if Cout > D:
        # Matrix-vector multiply per sample: (Cout x D) @ (B x Cout)
        proj_macs = B * Cout * D
        proj_params = Cout * D

    # 3) Codebook distances and soft assignment on (B, D) against K centers
    #    Approximate as ~ 2 * B * K * D MACs (diff + square + sum)
    codebook_macs = 2 * B * K * D
    # Small softmax/logsumexp overhead per sample; keep it simple
    softmax_macs = B * K

    coding_macs_total = pool_macs + proj_macs + codebook_macs + softmax_macs

    # Parameter overhead: K * D codebook centers + optional projection
    param_overhead = K * D + proj_params

    # Transient activation bytes (float elements): pooled (B, D) + soft (B, K)
    activation_overhead_bytes = (B * D + B * K) * bytes_per

    overhead_ratio = float(coding_macs_total) / float(conv_macs) if conv_macs > 0 else None

    return OverheadEstimate(
        conv_macs=int(conv_macs),
        coding_macs_total=int(coding_macs_total),
        coding_macs_breakdown={
            "pool": int(pool_macs),
            "projection": int(proj_macs),
            "codebook": int(codebook_macs),
            "softmax": int(softmax_macs),
        },
        param_overhead=int(param_overhead),
        activation_overhead_bytes=int(activation_overhead_bytes),
        overhead_ratio=None if overhead_ratio is None else float(overhead_ratio),
    )


__all__ = [
    "OverheadEstimate",
    "PooledConvConfig",
    "estimate_pooled_conv_overhead",
]
