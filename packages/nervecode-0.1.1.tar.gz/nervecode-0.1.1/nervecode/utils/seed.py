"""Seeding helpers to make runs reproducible across local and CI.

These utilities intentionally keep a small surface and no hard dependency on
NumPy. If NumPy is available, its global RNG is also seeded and restored.
"""

from __future__ import annotations

import contextlib
import importlib
import os
import random
import types
import typing


def _maybe_import_numpy() -> typing.Any | None:
    """Return NumPy module if available, else None."""
    try:
        return importlib.import_module("numpy")
    except Exception:  # pragma: no cover - optional dependency
        return None


def _maybe_import_torch() -> typing.Any | None:
    """Return a torch-like module if available with required attributes, else None."""
    try:
        t = importlib.import_module("torch")
    except Exception:  # pragma: no cover - torch missing
        return None
    required = all(hasattr(t, name) for name in ("manual_seed", "get_rng_state", "set_rng_state"))
    return t if required else None


def seed_from_env(
    env_var: str = "NERVECODE_SEED",
    default: int = 1234,
    *,
    set_env_if_missing: bool = False,
) -> int:
    """Return an integer seed sourced from an environment variable.

    - If ``env_var`` is set and parseable as an int, return its value.
    - Otherwise, return ``default``. If ``set_env_if_missing`` is True, also set
      ``os.environ[env_var]`` to the default value for downstream tools.
    """
    raw = os.environ.get(env_var)
    if raw is not None:
        try:
            return int(raw)
        except ValueError:  # Fall back to default on malformed input
            pass
    if set_env_if_missing:
        os.environ[env_var] = str(default)
    return default


def seed_everything(seed: int, *, deterministic: bool = True) -> None:
    """Seed Python, optional NumPy, and PyTorch RNGs.

    Also toggles PyTorch deterministic settings when ``deterministic`` is True to
    minimize nondeterministic kernels. On CUDA setups, call this as early as
    possible in process startup for best effect.
    """
    # Hash-based ops reproducibility (effective at interpreter start;
    # set anyway for child processes invoked by test runners)
    os.environ["PYTHONHASHSEED"] = str(seed)

    random.seed(seed)

    np = _maybe_import_numpy()
    if np is not None:  # pragma: no branch - trivial branch
        np.random.seed(seed)

    t = _maybe_import_torch()
    if t is not None:
        t.manual_seed(seed)
        if hasattr(t, "cuda") and t.cuda.is_available():  # pragma: no cover
            t.cuda.manual_seed_all(seed)

    # Configure PyTorch deterministic behavior as far as feasible.
    t = _maybe_import_torch()
    if t is not None and hasattr(t, "use_deterministic_algorithms"):
        # warn_only=True avoids raising on ops without deterministic kernels
        with contextlib.suppress(Exception):  # pragma: no cover - older/newer API differences
            t.use_deterministic_algorithms(bool(deterministic), warn_only=True)

    # cuDNN knobs (safe on CPU-only builds; no-ops)
    # cuDNN knobs (safe on CPU-only builds; no-ops)
    try:
        cudnn = importlib.import_module("torch.backends.cudnn")
    except Exception:  # pragma: no cover - backend not available
        cudnn = None
    if cudnn is not None:  # pragma: no branch
        cudnn_mod: typing.Any = cudnn
        try:
            cudnn_mod.deterministic = bool(deterministic)
            cudnn_mod.benchmark = not bool(deterministic)
        except Exception:  # pragma: no cover - attributes may be missing
            pass


class temp_seed(contextlib.AbstractContextManager[None]):
    """Temporarily set RNG seeds and restore previous states on exit.

    This context manager saves Python's ``random`` state, optional NumPy's global
    RNG state, and PyTorch CPU/CUDA RNG states. It then calls ``seed_everything``
    with the provided seed and restores the saved states when leaving the context.
    """

    def __init__(self, seed: int, *, deterministic: bool = True) -> None:
        self._seed = int(seed)
        self._deterministic = bool(deterministic)

        self._py_state: tuple[typing.Any, ...] | None = None
        self._np_state: typing.Any | None = None
        self._torch_cpu_state: typing.Any | None = None
        self._torch_cuda_states: typing.Any | None = None

    def __enter__(self) -> None:
        # Save current states
        self._py_state = random.getstate()
        np = _maybe_import_numpy()
        if np is not None:  # pragma: no branch
            self._np_state = np.random.get_state()
        t = _maybe_import_torch()
        if t is not None:
            self._torch_cpu_state = t.get_rng_state()
            if hasattr(t, "cuda") and t.cuda.is_available():  # pragma: no cover
                self._torch_cuda_states = t.cuda.get_rng_state_all()
        # Apply temporary seed
        seed_everything(self._seed, deterministic=self._deterministic)
        return None

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: types.TracebackType | None,
    ) -> None:
        # Restore saved states
        if self._py_state is not None:
            random.setstate(self._py_state)
        np = _maybe_import_numpy()
        if np is not None and self._np_state is not None:  # pragma: no branch
            np.random.set_state(self._np_state)
        t = _maybe_import_torch()
        if t is not None and self._torch_cpu_state is not None:
            t.set_rng_state(self._torch_cpu_state)
            if (
                hasattr(t, "cuda") and self._torch_cuda_states is not None and t.cuda.is_available()
            ):  # pragma: no cover
                t.cuda.set_rng_state_all(self._torch_cuda_states)
        return None


__all__ = [
    "seed_everything",
    "seed_from_env",
    "temp_seed",
]
