"""Scoring/aggregation result types.

This module defines lightweight dataclasses used by the scoring/aggregation
APIs. Keep imports torch-agnostic so the package remains importable in minimal
environments; fields that are typically ``torch.Tensor`` are typed as ``Any``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["AggregatedSurprise"]


@dataclass(frozen=True)
class AggregatedSurprise:
    """Result of aggregating per-layer surprise signals.

    Fields
    - ``surprise``: per-sample aggregated surprise signal (e.g., shape ``(B,)``
      or ``(...,)``). Typically a ``torch.Tensor``.
    - ``method``: aggregation method identifier such as ``"mean"``. Future
      values may include ``"max"`` and ``"weighted"`` without changing the
      public result type.
    - ``num_layers``: number of layer signals included in the aggregation.
    - ``details``: optional aggregation-specific details (e.g., weights).
    """

    surprise: Any
    method: str
    num_layers: int
    details: dict[str, Any] | None = None
