"""Scoring, aggregation, and calibration.

Scoring functions turn per-layer codes and traces into useful signals such as
surprise estimates. Calibration utilities live here as well.
"""

from __future__ import annotations

from .aggregator import max_surprise, mean_surprise, weighted_surprise
from .calibrator import CalibrationState, EmpiricalPercentileCalibrator
from .types import AggregatedSurprise

__all__: list[str] = [
    "AggregatedSurprise",
    "CalibrationState",
    "EmpiricalPercentileCalibrator",
    "max_surprise",
    "mean_surprise",
    "weighted_surprise",
]
