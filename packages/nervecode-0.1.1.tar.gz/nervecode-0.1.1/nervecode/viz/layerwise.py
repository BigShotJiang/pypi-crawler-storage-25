"""Plot layerwise surprise artifacts from completed benchmark runs."""

from __future__ import annotations

import argparse
import importlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class LayerwiseArtifact:
    """Loaded layerwise surprise artifact."""

    path: Path
    layer_names: list[str]
    surprise: Any
    labels: Any | None
    sample_ids: Any | None
    reduction_meta: list[dict[str, Any]]
    metadata: dict[str, Any]


def _require_optional_module(module: str) -> Any:
    try:
        return importlib.import_module(module)
    except ModuleNotFoundError as exc:
        missing = exc.name or module
        root = module.split(".", 1)[0]
        if missing == root or module == missing or module.startswith(f"{missing}."):
            raise RuntimeError(
                f"{module} is required for layerwise visualization; "
                "install nervecode with the 'viz' extra"
            ) from exc
        raise


def _to_numpy(value: Any) -> Any:
    try:
        import torch

        if isinstance(value, torch.Tensor):
            return value.detach().to(device="cpu").numpy()
    except Exception:
        pass
    return value


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if isinstance(value, dict):
        return {str(key): _jsonable(val) for key, val in value.items()}
    if isinstance(value, list | tuple):
        return [_jsonable(item) for item in value]
    return str(value)


def _json_from_np(value: Any, *, default: Any) -> Any:
    try:
        raw = value.item() if hasattr(value, "item") else value
        return json.loads(str(raw))
    except Exception:
        return default


def extract_layerwise_surprise(
    traces: dict[str, Any],
) -> tuple[list[str], Any, list[dict[str, Any]]] | None:
    """Extract a batch matrix ``[num_samples, num_layers]`` from CodingTrace values."""

    try:
        import torch
    except Exception:  # pragma: no cover - optional torch dependency
        return None

    layer_names: list[str] = []
    columns: list[Any] = []
    reduction_meta: list[dict[str, Any]] = []
    expected_len: int | None = None
    for name, trace in traces.items():
        sample_view = getattr(trace, "sample_reduced_surprise", None)
        vec = sample_view() if callable(sample_view) else None
        if vec is None:
            soft_code = getattr(trace, "soft_code", None)
            vec = getattr(soft_code, "combined_surprise", None)
            if vec is None:
                vec = getattr(soft_code, "best_length", None)
        if not isinstance(vec, torch.Tensor) or int(vec.ndim) == 0:
            continue
        if int(vec.ndim) > 1:
            dims = tuple(range(1, int(vec.ndim)))
            vec = vec.mean(dim=dims)
        vec = vec.detach().to(device="cpu", dtype=torch.float32).reshape(-1)
        if expected_len is None:
            expected_len = int(vec.numel())
        elif int(vec.numel()) != expected_len:
            continue
        layer_names.append(str(name))
        columns.append(vec)
        meta = getattr(trace, "reduction_meta", {}) or {}
        reduction_meta.append(_jsonable(meta))

    if not columns:
        return None
    return layer_names, torch.stack(columns, dim=1), reduction_meta


def save_layerwise_artifact(
    path: str | os.PathLike[str],
    *,
    layer_names: list[str],
    surprise: Any,
    labels: Any | None = None,
    sample_ids: Any | None = None,
    reduction_meta: list[dict[str, Any]] | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Save a layerwise artifact as compressed ``.npz``."""

    np = _require_optional_module("numpy")

    surprise_np = np.asarray(_to_numpy(surprise), dtype=np.float32)
    if surprise_np.ndim != 2:
        raise ValueError("surprise must have shape [num_samples, num_layers]")
    if surprise_np.shape[1] != len(layer_names):
        raise ValueError("surprise width must match layer_names")

    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    arrays: dict[str, Any] = {
        "layer_names": np.asarray([str(name) for name in layer_names], dtype=str),
        "surprise": surprise_np,
        "reduction_meta_json": json.dumps(_jsonable(reduction_meta or []), sort_keys=True),
        "metadata_json": json.dumps(_jsonable(metadata or {}), sort_keys=True),
    }
    if labels is not None:
        arrays["labels"] = np.asarray(_to_numpy(labels))
    if sample_ids is not None:
        arrays["sample_ids"] = np.asarray(_to_numpy(sample_ids))
    np.savez_compressed(out_path, **arrays)


def load_layerwise_artifact(path: str | os.PathLike[str]) -> LayerwiseArtifact:
    """Load and validate a layerwise surprise artifact."""

    np = _require_optional_module("numpy")

    artifact_path = Path(path)
    with np.load(artifact_path, allow_pickle=False) as data:
        if "layer_names" not in data.files or "surprise" not in data.files:
            raise ValueError(f"{artifact_path} is missing layer_names or surprise")
        layer_names = [str(name) for name in data["layer_names"].tolist()]
        surprise = np.asarray(data["surprise"], dtype=np.float32)
        if surprise.ndim != 2:
            raise ValueError(f"{artifact_path} surprise must be 2D")
        if surprise.shape[0] == 0 or surprise.shape[1] == 0:
            raise ValueError(f"{artifact_path} surprise must not be empty")
        if surprise.shape[1] != len(layer_names):
            raise ValueError(f"{artifact_path} surprise width does not match layer_names")
        labels = np.asarray(data["labels"]) if "labels" in data.files else None
        sample_ids = np.asarray(data["sample_ids"]) if "sample_ids" in data.files else None
        reduction_meta_raw = (
            data["reduction_meta_json"] if "reduction_meta_json" in data.files else "[]"
        )
        metadata_raw = data["metadata_json"] if "metadata_json" in data.files else "{}"
        reduction_meta = _json_from_np(reduction_meta_raw, default=[])
        metadata = _json_from_np(metadata_raw, default={})
    if not isinstance(reduction_meta, list):
        reduction_meta = []
    if not isinstance(metadata, dict):
        metadata = {}
    return LayerwiseArtifact(
        path=artifact_path,
        layer_names=layer_names,
        surprise=surprise,
        labels=labels,
        sample_ids=sample_ids,
        reduction_meta=reduction_meta,
        metadata=metadata,
    )


def _artifact_path(run_dir: str | os.PathLike[str], *, seed: int, split: str) -> Path:
    return Path(run_dir) / "layerwise" / f"seed_{int(seed)}" / f"{split}.npz"


def _parse_ood_names(value: str) -> list[str]:
    return [part.strip() for part in str(value).split(",") if part.strip()]


def _select_layers(
    artifact: LayerwiseArtifact,
    selected: list[str] | None,
) -> tuple[list[str], Any]:
    np = _require_optional_module("numpy")

    if not selected:
        return artifact.layer_names, artifact.surprise
    index = {name: i for i, name in enumerate(artifact.layer_names)}
    missing = [name for name in selected if name not in index]
    if missing:
        raise ValueError(f"{artifact.path} is missing requested layer(s): {', '.join(missing)}")
    cols = [index[name] for name in selected]
    return selected, np.asarray(artifact.surprise)[:, cols]


def _aligned_ood_artifacts(
    id_artifact: LayerwiseArtifact,
    ood_artifacts: list[LayerwiseArtifact],
    *,
    selected_layers: list[str] | None,
) -> tuple[list[str], Any, list[tuple[str, Any]]]:
    id_names, id_surprise = _select_layers(id_artifact, selected_layers)
    out: list[tuple[str, Any]] = []
    for artifact in ood_artifacts:
        if artifact.layer_names != id_artifact.layer_names:
            raise ValueError(f"{artifact.path} layer_names do not match {id_artifact.path}")
        _, surprise = _select_layers(artifact, selected_layers)
        name = str(artifact.metadata.get("ood") or artifact.path.stem.removeprefix("ood_"))
        out.append((name, surprise))
    return id_names, id_surprise, out


def plot_layerwise_artifacts(
    run_dir: str | os.PathLike[str],
    *,
    seed: int,
    ood_names: list[str],
    output_path: str | os.PathLike[str],
    mode: str = "mean",
    layers: list[str] | None = None,
) -> None:
    """Plot saved layerwise artifacts from a completed run."""

    matplotlib = _require_optional_module("matplotlib")

    matplotlib.use("Agg", force=True)
    plt = _require_optional_module("matplotlib.pyplot")
    np = _require_optional_module("numpy")

    if not ood_names:
        raise ValueError("at least one OOD name is required")
    id_artifact = load_layerwise_artifact(_artifact_path(run_dir, seed=seed, split="id_test"))
    ood_artifacts = [
        load_layerwise_artifact(_artifact_path(run_dir, seed=seed, split=f"ood_{ood_name}"))
        for ood_name in ood_names
    ]
    layer_names, id_surprise, aligned_oods = _aligned_ood_artifacts(
        id_artifact,
        ood_artifacts,
        selected_layers=layers,
    )

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    x = np.arange(len(layer_names))

    if mode == "mean":
        fig, ax = plt.subplots(figsize=(max(6.0, len(layer_names) * 0.55), 4.5))
        ax.plot(x, id_surprise.mean(axis=0), marker="o", linewidth=2.0, label="ID test")
        for ood_name, surprise in aligned_oods:
            ax.plot(x, surprise.mean(axis=0), marker="o", linewidth=1.6, label=f"OOD {ood_name}")
        ax.set_ylabel("Mean surprise")
        ax.set_title("Layerwise Nervecode Surprise")
        ax.set_xticks(x)
        ax.set_xticklabels(layer_names, rotation=55, ha="right")
        ax.legend()
        ax.grid(axis="y", alpha=0.25)
    elif mode == "delta":
        fig, ax = plt.subplots(figsize=(max(6.0, len(layer_names) * 0.55), 4.5))
        id_mean = id_surprise.mean(axis=0)
        width = 0.8 / max(1, len(aligned_oods))
        for i, (ood_name, surprise) in enumerate(aligned_oods):
            offset = (i - (len(aligned_oods) - 1) / 2.0) * width
            ax.bar(x + offset, surprise.mean(axis=0) - id_mean, width=width, label=ood_name)
        ax.axhline(0.0, color="black", linewidth=1.0)
        ax.set_ylabel("Mean surprise delta vs ID")
        ax.set_title("Layerwise OOD - ID Surprise")
        ax.set_xticks(x)
        ax.set_xticklabels(layer_names, rotation=55, ha="right")
        ax.legend()
        ax.grid(axis="y", alpha=0.25)
    elif mode == "hist":
        max_layers = min(4, len(layer_names))
        fig, axes = plt.subplots(max_layers, 1, figsize=(7.0, max(3.0, max_layers * 2.3)))
        axes_list = np.atleast_1d(axes)
        for idx in range(max_layers):
            ax = axes_list[idx]
            ax.hist(id_surprise[:, idx], bins=24, alpha=0.55, label="ID test")
            for ood_name, surprise in aligned_oods:
                ax.hist(surprise[:, idx], bins=24, alpha=0.45, label=f"OOD {ood_name}")
            ax.set_title(layer_names[idx])
            ax.set_ylabel("Count")
            if idx == 0:
                ax.legend()
        axes_list[-1].set_xlabel("Surprise")
    else:
        raise ValueError(f"unsupported mode: {mode}")

    fig.tight_layout()
    fig.savefig(output)
    plt.close(fig)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", help="Completed benchmark run directory")
    parser.add_argument("--seed", type=int, required=True, help="Seed artifact to plot")
    parser.add_argument("--ood", required=True, help="Comma-separated OOD names, e.g. dtd,cifar100")
    parser.add_argument(
        "--output",
        default=None,
        help="Output PNG path; defaults to <run_dir>/plots/layerwise.png",
    )
    parser.add_argument(
        "--mode",
        choices=["mean", "delta", "hist"],
        default="mean",
        help="Plot mode",
    )
    parser.add_argument(
        "--layers",
        default=None,
        help="Optional comma-separated layer subset in artifact layer-name order",
    )
    args = parser.parse_args(argv)

    run_dir = Path(args.run_dir)
    output = Path(args.output) if args.output else run_dir / "plots" / "layerwise.png"
    plot_layerwise_artifacts(
        run_dir,
        seed=int(args.seed),
        ood_names=_parse_ood_names(args.ood),
        output_path=output,
        mode=str(args.mode),
        layers=_parse_ood_names(args.layers) if args.layers else None,
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
