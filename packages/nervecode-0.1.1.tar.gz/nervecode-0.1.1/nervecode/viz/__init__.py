"""Visualization helpers for Nervecode artifacts."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .layerwise import (
        LayerwiseArtifact,
        extract_layerwise_surprise,
        load_layerwise_artifact,
        plot_layerwise_artifacts,
        save_layerwise_artifact,
    )

__all__ = [
    "LayerwiseArtifact",
    "extract_layerwise_surprise",
    "load_layerwise_artifact",
    "plot_layerwise_artifacts",
    "save_layerwise_artifact",
]


def __getattr__(name: str) -> Any:
    if name in __all__:
        from . import layerwise

        return getattr(layerwise, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
