"""Experimental codebook update helpers (EMA / hybrid).

These helpers are optional, off-by-default training utilities that update
codebook centers using exponential moving averages driven by the latest
coding trace. They are provided for exploration only — the default and
recommended baseline remains standard gradient-based optimization via
``CodingLoss`` and your optimizer.

Design goals
- Observe-only wrappers and existing training code remain unchanged unless an
  updater is explicitly instantiated and called by the user.
- Safe numerics: clamp divisors, support empty usages gracefully.
- Torch-first: implemented as small ``nn.Module``s with buffers so they move
  with devices and can be checkpointed when needed.
"""

from __future__ import annotations

from typing import Any, Literal, cast

try:  # Keep import-time failure tolerant when torch isn't installed
    import torch
    from torch import nn
except Exception:  # pragma: no cover - torch is a project dependency in tests
    torch = cast(Any, None)
    nn = cast(Any, None)

try:
    from nervecode.core import CodingTrace
    from nervecode.core.codebook import Codebook
except Exception:  # pragma: no cover - available during normal package use
    CodingTrace = object  # type: ignore[misc,assignment]
    Codebook = object  # type: ignore[misc,assignment]

__all__ = ["EmaCodebookUpdater"]


class _StubModule:  # pragma: no cover - used only when torch is unavailable
    pass


_Base = nn.Module if nn is not None else _StubModule


class EmaCodebookUpdater(_Base):  # type: ignore[misc,valid-type]
    """Update codebook centers using an EMA of batch-weighted means.

    This updater maintains per-code EMA counts and summed activations and sets
    centers to ``ema_sum / (ema_count + eps)`` after each update call. The batch
    statistics are computed from a ``CodingTrace`` using either soft
    probabilities or hard assignments.

    Parameters
    - codebook: The ``Codebook`` whose centers are updated in-place.
    - decay: Exponential decay factor in ``[0, 1)``. Higher means slower update
      toward the batch statistics. ``decay=0`` uses the current batch only.
    - assignment: ``"soft"`` (default) to use soft probabilities, or ``"hard"``
      to use one-hot assignments based on argmax indices.
    - eps: Small positive constant to avoid division by zero.

    Notes
    - Updates run under ``torch.no_grad()`` and preserve ``requires_grad`` on
      ``codebook.centers`` so gradient-based training can continue to operate
      (hybrid usage).
    - The updater holds its own buffers (ema_count, ema_sum) sized from the
      attached codebook at construction time. If the codebook is reinitialized
      with a different shape, construct a new updater.
    """

    def __init__(
        self,
        codebook: Codebook,
        *,
        decay: float = 0.99,
        assignment: Literal["soft", "hard"] = "soft",
        eps: float = 1e-12,
    ) -> None:
        if torch is None:  # pragma: no cover - defensive
            raise RuntimeError("EmaCodebookUpdater requires PyTorch to be installed")
        super().__init__()

        if decay < 0.0 or decay >= 1.0 or not float(decay) == decay:
            raise ValueError("decay must be a float in [0, 1)")
        if assignment not in ("soft", "hard"):
            raise ValueError("assignment must be 'soft' or 'hard'")
        if eps <= 0.0:
            raise ValueError("eps must be positive")

        self.codebook = codebook
        self.decay: float = float(decay)
        self.assignment: Literal["soft", "hard"] = assignment
        self.eps: float = float(eps)

        K = int(codebook.K)
        D = int(codebook.code_dim)
        # EMA state mirrors codebook shape: counts per code and sums per code x dim
        self._ema_count: torch.Tensor
        self._ema_sum: torch.Tensor
        self.register_buffer("_ema_count", torch.zeros(K), persistent=True)
        self.register_buffer("_ema_sum", torch.zeros(K, D), persistent=True)

    def reset_state(self) -> None:
        """Reset EMA state to zeros (no prior influence)."""
        if torch is None:  # pragma: no cover - defensive
            return
        with torch.no_grad():
            self._ema_count.zero_()
            self._ema_sum.zero_()

    def update_from_trace(self, trace: CodingTrace) -> None:
        """Update EMA statistics and set codebook centers for a batch.

        Expects a ``CodingTrace`` produced by the same codebook. The reduced
        activations and the ``SoftCode`` probabilities/indices are used to
        compute per-code batch counts and sums.
        """

        # Validate shape alignment in a torch-first way
        probs = trace.soft_code.probs
        x = trace.reduced

        if not isinstance(probs, torch.Tensor) or not isinstance(x, torch.Tensor):
            raise TypeError("trace must carry torch.Tensor probabilities and reduced activations")
        if probs.ndim < 1 or x.ndim < 1:
            raise ValueError("trace tensors must have at least one dimension")
        if int(probs.shape[-1]) != int(self.codebook.K):
            raise ValueError("trace code dimension K must match attached codebook")
        if int(x.shape[-1]) != int(self.codebook.code_dim):
            raise ValueError("trace reduced dim D must match attached codebook")

        with torch.no_grad():
            # Flatten leading dims to (N, ...)
            N = int(x.numel() // x.shape[-1])
            x_flat = x.reshape(N, -1)  # (N, D)
            p_flat = probs.reshape(N, -1)  # (N, K)

            if self.assignment == "hard":
                # One-hot from argmax indices
                idx = torch.argmax(p_flat, dim=-1)  # (N,)
                w = torch.zeros_like(p_flat)
                w.scatter_(1, idx.unsqueeze(-1), 1.0)
            else:
                # Soft probabilities (already sum to 1 across codes)
                w = p_flat

            # Per-code batch counts and sums
            batch_count = w.sum(dim=0)  # (K,)
            batch_sum = w.t() @ x_flat  # (K, D)

            # Align EMA state to the same device/dtype as incoming batch
            device = x_flat.device
            dtype = x_flat.dtype
            if self._ema_count.device != device or self._ema_count.dtype != dtype:
                self._ema_count = self._ema_count.to(device=device, dtype=dtype)
            if self._ema_sum.device != device or self._ema_sum.dtype != dtype:
                self._ema_sum = self._ema_sum.to(device=device, dtype=dtype)

            d = self.decay
            one_minus = 1.0 - d
            self._ema_count.mul_(d).add_(batch_count.to(dtype=dtype), alpha=one_minus)
            self._ema_sum.mul_(d).add_(batch_sum.to(dtype=dtype), alpha=one_minus)

            # Update centers: ema_sum / (ema_count + eps)
            denom = (self._ema_count + self.eps).unsqueeze(-1)  # (K, 1)
            new_centers = self._ema_sum / denom

            # In-place update preserves requires_grad on the parameter
            self.codebook.centers.detach().copy_(new_centers)
