"""Auxiliary coding loss that consumes CodingTrace objects.

This module implements a lightweight training-time loss that reads existing
``CodingTrace`` objects produced by wrapped layers. It avoids recomputing
distances or other intermediates from raw activations by relying on the
per-position surprise already stored on the associated ``SoftCode`` inside each
trace. When multiple layers are provided, their per-sample surprise signals are
aggregated using the default mean strategy from ``nervecode.scoring`` and then
reduced across the batch to yield a scalar loss.

The loss intentionally remains minimal in the MVP: it performs a mean reduction
over samples. Follow-up tasks extend it with configurable term weights and
clear per-layer breakdowns.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any, cast

try:  # Keep import-time behavior tolerant in environments without torch
    import torch
    from torch import nn
except Exception:  # pragma: no cover - torch is a project dependency in tests
    torch = cast(Any, None)
    nn = cast(Any, None)

try:
    from nervecode.core import CodingTrace, SoftCode  # re-exported types
except Exception:  # pragma: no cover - available during normal package use
    CodingTrace = object  # type: ignore[misc,assignment]
    SoftCode = object  # type: ignore[misc,assignment]

from nervecode.scoring import mean_surprise

__all__ = ["CodingLoss"]


class _StubModule:  # pragma: no cover - used only when torch is unavailable
    pass


_Base = nn.Module if nn is not None else _StubModule


class CodingLoss(_Base):  # type: ignore[misc,valid-type]
    """Compute a scalar coding loss from traces without recomputation.

    Inputs may be a single ``CodingTrace`` (or ``SoftCode``/tensor), an
    iterable of such objects, or a mapping from layer names to objects.

    The loss has two conceptual parts:
    - an assignment/sharpness term derived from the per-position surprise
      on ``SoftCode`` (aggregated via ``mean_surprise``), and
    - an optional commitment term that uses the nearest-center distance
      already stored on each ``CodingTrace``.

    Both terms are reduced to a per-sample view and averaged across layers;
    the final scalar is a weighted sum with ``assign_weight`` and
    ``commit_weight``. By default the commitment term weight is zero to keep
    backward compatibility with earlier behavior.
    """

    def __init__(self, *, assign_weight: float = 1.0, commit_weight: float = 0.0) -> None:
        if torch is None:  # pragma: no cover - defensive
            raise RuntimeError("CodingLoss requires PyTorch to be installed")
        super().__init__()
        self.assign_weight: float = float(assign_weight)
        self.commit_weight: float = float(commit_weight)

    def forward(self, traces: Any) -> torch.Tensor:
        """Return weighted mean-aggregated coding loss across samples.

        Parameters
        - traces: A ``CodingTrace`` object (or ``SoftCode``/tensor), an
          iterable of such objects, or a mapping from layer names to objects.

        Returns
        - A scalar ``torch.Tensor`` equal to the weighted sum of the per-sample
          aggregated assignment term and, when enabled, the aggregated
          commitment term.
        """

        if torch is None:  # pragma: no cover - defensive
            raise RuntimeError("CodingLoss requires PyTorch to be installed")

        # Normalize input to what mean_surprise and our commitment aggregator expect
        payload: Iterable[Any] | Mapping[str, Any]
        if isinstance(traces, Mapping) or (
            isinstance(traces, Iterable)
            and not isinstance(traces, (torch.Tensor, SoftCode, CodingTrace))
        ):
            payload = traces
        else:
            # Single object: wrap into a list for aggregation
            payload = [traces]

        # Assignment/sharpness component via mean_surprise (SoftCode-based)
        agg = mean_surprise(payload)
        if agg is None or not hasattr(agg, "surprise"):
            raise ValueError("No valid surprise signals found in provided traces")
        s = cast(torch.Tensor, agg.surprise)
        assign_term = s.mean()

        # Commitment component via nearest-center distances stored on traces
        commit_vec: torch.Tensor | None = _mean_commitment_across_layers(payload)

        if self.commit_weight != 0.0 and commit_vec is not None:
            commit_mean = commit_vec.mean()
            return (
                assign_term.to(dtype=commit_mean.dtype, device=commit_mean.device)
                * self.assign_weight
                + commit_mean * self.commit_weight
            )
        # Default: only assignment term
        return assign_term * self.assign_weight


def _mean_commitment_across_layers(
    traces: Iterable[Any] | Mapping[str, Any],
) -> torch.Tensor | None:
    """Return per-sample mean-aggregated commitment distance across layers.

    This helper scans the provided collection for ``CodingTrace`` objects,
    extracts their per-position ``commitment_distances``, reduces them to a
    per-sample vector by averaging extra leading dimensions, and averages
    across layers. When no layer provides commitment distances, returns
    ``None``.
    """

    if torch is None:  # pragma: no cover - defensive
        return None

    values: Iterable[Any] = traces.values() if isinstance(traces, Mapping) else traces

    signals: list[torch.Tensor] = []
    ref_shape: tuple[int, ...] | None = None

    for obj in values:
        # Only CodingTrace carries commitment distances in the MVP
        if not isinstance(obj, CodingTrace):
            continue
        d = getattr(obj, "commitment_distances", None)
        if not isinstance(d, torch.Tensor):
            continue
        t = _reduce_to_sample(d)
        shape = tuple(int(s) for s in t.shape)
        if ref_shape is None:
            ref_shape = shape
            signals.append(t)
        else:
            if shape != ref_shape:
                # Skip mismatched sample shapes to preserve fail-open behavior
                continue
            signals.append(t)

    if not signals:
        return None

    # Align dtype/device to the first signal for stable aggregation
    first = signals[0]
    device = getattr(first, "device", None)
    dtype = first.dtype if hasattr(first, "dtype") else None
    aligned: list[torch.Tensor] = []
    for s in signals:
        s2 = s
        if dtype is not None and getattr(s2, "dtype", None) is not dtype:
            s2 = s2.to(dtype=dtype)
        if device is not None and getattr(s2, "device", None) != device:
            s2 = s2.to(device=device)
        aligned.append(s2)

    stacked = torch.stack(aligned, dim=0)
    # Mean over layers yields a per-sample vector
    return stacked.mean(dim=0)


def _reduce_to_sample(t: torch.Tensor) -> torch.Tensor:
    """Reduce a tensor to a per-sample vector by averaging extra leading dims.

    Mirrors the reduction used by the scoring aggregator so that both
    assignment and commitment terms are combined consistently across layers.
    """

    if getattr(t, "ndim", 0) <= 1:
        return t
    dims = tuple(range(1, int(t.ndim)))
    return t.mean(dim=dims)
