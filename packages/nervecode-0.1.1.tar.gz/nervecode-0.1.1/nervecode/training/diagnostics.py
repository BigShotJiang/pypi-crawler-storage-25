"""Lightweight diagnostics collection and logging backends.

This module provides utilities to summarize per-layer CodingTrace objects into
simple, machine-readable rows and to write those rows to CSV or JSONL without
bringing extra dependencies. It complements wrapper-level convenience metrics
by producing explicit records during training, calibration, or evaluation.

Design goals
- Minimal surface; importable without heavy dependencies.
- Fail-open behavior: best-effort extraction; skip rows on missing tensors.
- CSV and JSONL outputs for easy downstream processing.
"""

from __future__ import annotations

import csv
import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path

try:  # optional torch for numeric reductions
    import torch
except Exception:  # pragma: no cover - environments without torch
    from typing import Any
    from typing import cast as _cast

    torch = _cast(Any, None)

try:
    from nervecode.core import CodingTrace
except Exception:  # pragma: no cover - available during normal package use
    CodingTrace = object  # type: ignore[misc,assignment]

__all__ = [
    "CsvDiagnosticsLogger",
    "DiagnosticsCollector",
    "DiagnosticsRow",
    "JsonlDiagnosticsLogger",
]


@dataclass(frozen=True)
class DiagnosticsRow:
    """Single row of layer-level diagnostics derived from a CodingTrace."""

    step: int | None
    layer: str
    K: int | None
    code_dim: int | None
    utilization: float | None
    dead_code_frac: float | None
    mean_entropy: float | None
    mean_best_length: float | None
    mean_commitment: float | None
    reduction: str | None


class DiagnosticsCollector:
    """Summarize per-layer traces into DiagnosticsRow entries."""

    def summarize_trace(
        self, layer_name: str, trace: CodingTrace, *, step: int | None = None
    ) -> DiagnosticsRow:
        # Default values
        K: int | None = None
        code_dim: int | None = None
        utilization: float | None = None
        dead_frac: float | None = None
        mean_entropy: float | None = None
        mean_best_len: float | None = None
        mean_commit: float | None = None
        reduction: str | None = None

        # Resolve K and D from the trace's SoftCode and reduced vectors
        try:
            _k = getattr(trace.soft_code, "code_dim", 0)
            K = int(_k) if isinstance(_k, (int,)) else None
        except Exception:
            K = None
        try:
            _d = getattr(trace, "reduced_dim", 0)
            code_dim = int(_d) if isinstance(_d, (int,)) else None
        except Exception:
            code_dim = None

        # Utilization and dead-code fraction
        if torch is not None and hasattr(trace.soft_code, "best_indices"):
            try:
                best = trace.soft_code.best_indices
                if not isinstance(best, torch.Tensor):
                    best = getattr(trace, "chosen_center_indices", None)
                if isinstance(best, torch.Tensor) and K and K > 0:
                    used = len(torch.unique(best.reshape(-1)).tolist())
                    utilization = float(used) / float(K)
                    dead_frac = max(0.0, 1.0 - utilization)
            except Exception:
                pass

        # Entropy, best-length, and commitment distance means
        if torch is not None:
            try:
                ent = getattr(trace.soft_code, "entropy", None)
                if isinstance(ent, torch.Tensor):
                    mean_entropy = float(ent.mean().item())
            except Exception:
                pass
            try:
                bl = getattr(trace.soft_code, "best_length", None)
                if isinstance(bl, torch.Tensor):
                    mean_best_len = float(bl.mean().item())
            except Exception:
                pass
            try:
                cm = getattr(trace, "commitment_distances", None)
                if isinstance(cm, torch.Tensor):
                    mean_commit = float(cm.mean().item())
            except Exception:
                pass

        # Reduction metadata
        try:
            meta = getattr(trace, "reduction_meta", {}) or {}
            reduction = str(meta.get("method")) if isinstance(meta, Mapping) else None
        except Exception:
            reduction = None

        return DiagnosticsRow(
            step=step,
            layer=layer_name,
            K=K,
            code_dim=code_dim,
            utilization=utilization,
            dead_code_frac=dead_frac,
            mean_entropy=mean_entropy,
            mean_best_length=mean_best_len,
            mean_commitment=mean_commit,
            reduction=reduction,
        )

    def collect(
        self, traces: Mapping[str, CodingTrace], *, step: int | None = None
    ) -> list[DiagnosticsRow]:
        rows: list[DiagnosticsRow] = []
        for name, trace in traces.items():
            try:
                rows.append(self.summarize_trace(str(name), trace, step=step))
            except Exception:
                continue
        return rows


class CsvDiagnosticsLogger:
    """Append diagnostics rows to a CSV file with a fixed header."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._header_written = False
        self._fieldnames = [
            "step",
            "layer",
            "K",
            "code_dim",
            "utilization",
            "dead_code_frac",
            "mean_entropy",
            "mean_best_length",
            "mean_commitment",
            "reduction",
        ]

    def log(self, rows: Iterable[DiagnosticsRow]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with self._path.open("a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self._fieldnames)
            if not self._header_written and self._path.stat().st_size == 0:
                writer.writeheader()
                self._header_written = True
            for r in rows:
                writer.writerow({k: getattr(r, k) for k in self._fieldnames})


class JsonlDiagnosticsLogger:
    """Append diagnostics rows as JSONL objects (one per line)."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)

    def log(self, rows: Iterable[DiagnosticsRow]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with self._path.open("a", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r.__dict__))
                f.write("\n")
