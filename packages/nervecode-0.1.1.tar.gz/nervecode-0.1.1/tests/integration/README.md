This directory is reserved for integration tests that exercise multiple
components together or run heavier validations. Intentionally left empty for now.

