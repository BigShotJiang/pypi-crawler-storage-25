from __future__ import annotations

from pathlib import Path


def test_benchmarks_doc_exists_and_has_core_sections() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    doc = repo_root / "docs" / "benchmarks.md"
    assert doc.exists(), "docs/benchmarks.md should exist"
    text = doc.read_text(encoding="utf-8").lower()
    # Core sections of the report template
    for keyword in (
        "summary",
        "context",
        "commit",
        "data",
        "model",
        "instrumentation",
        "procedure",
        "metrics",
        "results",
        "reproducibility",
        "limitations",
        "next steps",
        "higher score = more ood-like",
        "id calibration",
        "oracle_ood_calibrated_combo",
        "docs/combo.md",
        "layerwise artifact contract",
        "python -m nervecode.viz.layerwise",
        "cifar resnet-18 preset contract",
        "full_cifar10_resnet18",
        "accuracy-gate",
        "checkpoint-sha256",
        "transfer_resnet18",
        "configs/v0_1_1",
        "archive_benchmark_artifacts.py",
    ):
        assert keyword in text
