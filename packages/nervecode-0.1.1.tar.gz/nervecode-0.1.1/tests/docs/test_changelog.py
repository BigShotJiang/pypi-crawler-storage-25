from __future__ import annotations

from pathlib import Path


def test_changelog_has_structured_v0_1_1_entry() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    text = (repo_root / "CHANGELOG.md").read_text(encoding="utf-8")

    assert "## [0.1.1] - 2026-05-03" in text
    for heading in ("### Fixed", "### Changed", "### Added", "### Documentation"):
        assert heading in text
    for keyword in (
        "PyPI 0.1.0",
        "benchmark",
        "MaxLogit",
        "Combo(E, M, N)",
        "layerwise",
        "configs/v0_1_1",
    ):
        assert keyword in text
