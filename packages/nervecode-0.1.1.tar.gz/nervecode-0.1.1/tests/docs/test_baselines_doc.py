from __future__ import annotations

from pathlib import Path


def test_baselines_doc_defines_p3_methods_and_signs() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    doc = repo_root / "docs" / "baselines.md"
    assert doc.exists(), "docs/baselines.md should exist"
    text = doc.read_text(encoding="utf-8").lower()
    compact = text.replace(" ", "")
    for keyword in (
        "msp",
        "energy",
        "maxlogit",
        "gen",
        "odin",
        "mahalanobis",
        "knn",
        "residual_vim_lite",
    ):
        assert keyword in text
    for keyword in (
        "higher score = more",
        "residual/vim-lite",
        "not standard vim",
    ):
        assert keyword.replace(" ", "") in compact
