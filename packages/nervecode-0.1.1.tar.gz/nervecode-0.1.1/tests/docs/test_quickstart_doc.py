from __future__ import annotations

from pathlib import Path


def test_quickstart_doc_exists_and_mentions_example() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    doc = repo_root / "docs" / "quickstart.md"
    assert doc.exists(), "docs/quickstart.md should exist"
    text = doc.read_text(encoding="utf-8")
    assert "Quickstart" in text
    assert "examples/quickstart_mlp.py" in text
