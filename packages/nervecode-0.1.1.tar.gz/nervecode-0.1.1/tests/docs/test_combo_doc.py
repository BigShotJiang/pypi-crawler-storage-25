from __future__ import annotations

from pathlib import Path


def test_combo_doc_defines_id_only_ablation_and_oracle_boundary() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    doc = repo_root / "docs" / "combo.md"
    assert doc.exists(), "docs/combo.md should exist"
    text = doc.read_text(encoding="utf-8").lower()
    compact = " ".join(text.split())

    for keyword in (
        "combo_id_zscore_equal",
        "id calibration",
        "energy",
        "mahalanobis",
        "nervecode",
        "aupr-out",
        "honest conclusion",
        "oracle appendix",
    ):
        assert keyword in text
    assert "must not headline" in compact
