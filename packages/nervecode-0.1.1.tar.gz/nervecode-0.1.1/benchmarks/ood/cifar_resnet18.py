"""CIFAR-10 vs OOD benchmark with ResNet-18 and baselines.

This script trains (or evaluates) a CIFAR-10 ResNet-18, computes OOD scores for
multiple baselines and for Nervecode's coding-based surprise, and reports AUROC,
AUPR-OUT, FPR@95TPR, ID accuracy, and latency. Datasets include CIFAR-10 (ID)
and common OOD sets (SVHN, DTD, LSUN, iSUN, CIFAR-100) when available via
torchvision.

The goal is to validate the hypothesis:
"On CNN image classifiers, Nervecode provides a competitive single-pass OOD
 signal with interpretable layerwise surprise and modest overhead."

Notes
- Datasets must be available via torchvision downloads; unavailable datasets are
  skipped gracefully.
- Baselines implemented here: MSP, Energy, MaxLogit, GEN, ODIN (simplified),
  Mahalanobis (shared covariance, penultimate features), KNN-OOD, and
  Residual/ViM-lite (principal-subspace residual norm; not full ViM).
- Latency is measured on the configured device by timing scoring over a subset
  of samples including the model forward.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import sys
import time
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from typing import Any

PRESET_DEMO = "demo"
PRESET_FULL_CIFAR10_RESNET18 = "full_cifar10_resnet18"
PRESET_CHOICES = (PRESET_DEMO, PRESET_FULL_CIFAR10_RESNET18)
FULL_CIFAR10_RESNET18_ACCURACY_GATE = 0.93


def _device_of(x: Any) -> Any:
    try:
        import torch

        return x.device if isinstance(x, torch.Tensor) else torch.device("cpu")
    except Exception:
        return None


def _set_seed(seed: int) -> None:
    try:
        import random

        import numpy as np
        import torch

        random.seed(int(seed))
        np.random.seed(int(seed))
        torch.manual_seed(int(seed))
        torch.cuda.manual_seed_all(int(seed))
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass


def _sha256_file(path: str | os.PathLike[str], *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(int(chunk_size))
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _write_json_file(path: str | os.PathLike[str], data: dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(os.fspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
        f.write("\n")


def _read_json_file(path: str | os.PathLike[str]) -> dict[str, Any]:
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _auroc(scores: Any, labels: Any) -> float:
    """Compute AUROC for higher-is-more-OOD scores vs {0=id,1=ood} labels."""
    from benchmarks.ood.metrics import auroc

    return auroc(scores, labels)


def _fpr_at_tpr(scores_id: Any, scores_ood: Any, *, target_tpr: float = 0.95) -> float:
    """Return FPR when TPR (on OOD) reaches target_tpr.

    Assumes higher scores indicate more OOD.
    """
    from benchmarks.ood.metrics import fpr_at_tpr

    return fpr_at_tpr(scores_id, scores_ood, target_tpr=target_tpr)


def _build_cifar_resnet18(num_classes: int = 10) -> Any:
    from torch import nn
    from torchvision.models import resnet18

    m = resnet18(weights=None)
    # Adapt for CIFAR (32x32): 3x3 conv, stride 1, no maxpool
    m.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    m.maxpool = nn.Identity()
    m.fc = nn.Linear(512, num_classes)
    return m


def _get_datasets_cifar10_ood(
    root: str, *, download: bool = True
) -> tuple[Any, Any, dict[str, Any]]:
    from torchvision import datasets, transforms

    # Standard CIFAR-10 normalization
    mean = (0.4914, 0.4822, 0.4465)
    std = (0.2470, 0.2435, 0.2616)
    tf_train = transforms.Compose(
        [
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean, std),
        ]
    )
    # Ensure all ID and OOD images are resized to 32x32 so batches stack
    # cleanly across heterogeneous datasets (e.g., DTD, iSUN, LSUN).
    try:
        from torchvision.transforms import InterpolationMode

        _bilinear = InterpolationMode.BILINEAR
    except Exception:
        _bilinear = None  # fallback; Resize will pick a default
    tf_test = transforms.Compose(
        [
            transforms.Resize((32, 32), interpolation=_bilinear)
            if _bilinear is not None
            else transforms.Resize((32, 32)),
            transforms.ToTensor(),
            transforms.Normalize(mean, std),
        ]
    )

    id_train = datasets.CIFAR10(root=root, train=True, transform=tf_train, download=download)
    id_test = datasets.CIFAR10(root=root, train=False, transform=tf_test, download=download)

    # OOD: attempt safe, skip on failure
    ood_loaders: dict[str, Any] = {}

    def _safe(name: str, fn: Any) -> Any:
        try:
            ds = fn()
            return ds
        except Exception:
            return None

    # SVHN (test split); transform to CIFAR norm
    def _svhn() -> Any:
        return datasets.SVHN(root=root, split="test", transform=tf_test, download=download)

    # DTD (Describable Textures Dataset): use test split
    def _dtd() -> Any:
        return datasets.DTD(root=root, split="test", transform=tf_test, download=download)

    # CIFAR-100 (test split)
    def _cifar100() -> Any:
        return datasets.CIFAR100(root=root, train=False, transform=tf_test, download=download)

    # LSUN (test set not standard in torchvision).
    # Use subset like LSUN Class for OOD; skip if unavailable
    def _lsun() -> Any:
        return datasets.LSUN(root=root, classes=["test"], transform=tf_test)

    # iSUN not in torchvision. Attempt to use TinyImageNet val if present as proxy; skip otherwise
    def _isun_proxy() -> Any:
        return datasets.ImageFolder(root=os.path.join(root, "iSUN"), transform=tf_test)

    ood_candidates = {
        "svhn": _svhn,
        "dtd": _dtd,
        "cifar100": _cifar100,
        "lsun": _lsun,
        "isun": _isun_proxy,
    }
    for k, mk in ood_candidates.items():
        ds = _safe(k, mk)
        if ds is not None:
            ood_loaders[k] = ds

    return id_train, id_test, ood_loaders


def _train(
    model: Any,
    train_loader: Any,
    *,
    device: str = "cpu",
    epochs: int = 1,
    wrapped: Any | None = None,
    coding_loss_w: float = 0.0,
) -> None:
    import torch
    from torch import nn

    model.to(device)
    opt = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(1, epochs))
    ce = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            logits = wrapped.forward(xb) if wrapped is not None else model(xb)
            loss = ce(logits, yb)
            if wrapped is not None and coding_loss_w and coding_loss_w > 0.0:
                with contextlib.suppress(Exception):
                    from typing import cast

                    loss = loss + float(coding_loss_w) * cast(torch.Tensor, wrapped.coding_loss())
            loss.backward()
            opt.step()
        with contextlib.suppress(Exception):
            sched.step()


def _accuracy(model: Any, loader: Any, *, device: str = "cpu") -> float:
    import torch

    model.eval()
    n = 0
    c = 0
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            logits = model(xb)
            pred = logits.argmax(dim=-1)
            c += int((pred == yb).sum().item())
            n += int(yb.numel())
    return float(c) / max(1, n)


def _collect_logits_features(
    model: Any, loader: Any, *, device: str = "cpu", max_samples: int | None = None
) -> tuple[Any, Any]:
    import torch

    feats: list[Any] = []
    logits_all: list[Any] = []

    # Hook penultimate features after global pooling (layer before fc)
    penultimate: dict[str, Any] = {}

    def _hook(_m: Any, _i: Any, o: Any) -> None:
        penultimate["x"] = o.reshape(o.shape[0], -1).detach()

    handle = None
    for name, m in model.named_modules():
        if name.endswith("avgpool"):
            handle = m.register_forward_hook(_hook)
            break

    model.eval()
    with torch.no_grad():
        seen = 0
        for xb, _ in loader:
            xb = xb.to(device)
            logits = model(xb)
            x = penultimate.get("x")
            if x is None:
                # If avgpool hook not triggered, try to infer penultimate by
                # taking features before fc
                try:
                    x = model.avgpool
                except Exception:
                    x = logits.detach()
            feats.append(x)
            logits_all.append(logits.detach())
            seen += int(xb.shape[0])
            if max_samples is not None and seen >= int(max_samples):
                break

    if handle is not None:
        handle.remove()

    # Concatenate without unnecessary tensor.new_tensor copies
    return torch.cat(logits_all, dim=0), torch.cat(feats, dim=0)


def _scores_msp(logits: Any) -> Any:
    from benchmarks.ood.scores import msp_score

    return msp_score(logits)


def _scores_energy(logits: Any, *, temperature: float = 1.0) -> Any:
    from benchmarks.ood.scores import energy_score

    return energy_score(logits, temperature=temperature)


def _scores_maxlogit(logits: Any) -> Any:
    from benchmarks.ood.scores import maxlogit_score

    return maxlogit_score(logits)


def _scores_gen(logits: Any, *, gamma: float = 0.1, top_m: int | None = None) -> Any:
    from benchmarks.ood.scores import gen_score

    return gen_score(logits, gamma=gamma, top_m=top_m)


def _scores_odin(
    model: Any,
    loader: Any,
    *,
    device: str = "cpu",
    temperature: float = 1000.0,
    eps: float = 0.0014,
    max_samples: int | None = None,
    report_every: int | None = None,
    tag: str | None = None,
) -> Any:
    import torch
    from torch.nn import functional as F

    from benchmarks.ood.score_contract import validate_ood_scores

    model.eval()
    scores: list[Any] = []
    seen = 0
    for xb, _ in loader:
        xb = xb.to(device)
        xb.requires_grad_(True)
        logits = model(xb)
        z = logits / float(temperature)
        probs = F.softmax(z, dim=-1)
        conf, _yhat = probs.max(dim=-1)
        loss = -torch.log(conf + 1e-12).mean()
        model.zero_grad(set_to_none=True)
        # Use typed autograd entry point to satisfy mypy
        torch.autograd.backward((loss,))
        # Input perturbation in sign of gradient
        grad_sign = torch.sign(xb.grad.detach())
        xb_pert = xb - float(eps) * grad_sign
        xb_pert = torch.clamp(xb_pert, -10.0, 10.0)  # after normalization this is safe bound
        with torch.no_grad():
            logits2 = model(xb_pert)
            probs2 = F.softmax(logits2 / float(temperature), dim=-1)
            conf2, _ = probs2.max(dim=-1)
            scores.append(1.0 - conf2)
        seen += int(xb.shape[0])
        if report_every is not None and seen % int(report_every) == 0:
            msg = f"[ODIN] {tag or ''} processed {seen} samples"
            with contextlib.suppress(Exception):
                print(msg, flush=True)
        if max_samples is not None and seen >= int(max_samples):
            break
    return validate_ood_scores(torch.cat(scores, dim=0), name="odin")


def _fit_mahalanobis(feats: Any, labels: Any, *, shrink: float = 0.01) -> tuple[Any, Any, Any]:
    from benchmarks.ood.scores import fit_mahalanobis

    return fit_mahalanobis(feats, labels, shrink=shrink)


def _scores_mahalanobis(feats: Any, mu: Any, inv_cov: Any) -> Any:
    from benchmarks.ood.scores import mahalanobis_score

    return mahalanobis_score(feats, mu, inv_cov)


def _scores_knn(train_feats: Any, query_feats: Any, *, k: int = 50, chunk_size: int = 4096) -> Any:
    from benchmarks.ood.scores import knn_ood_score

    return knn_ood_score(train_feats, query_feats, k=k, chunk_size=chunk_size, normalize=True)


def _fit_residual_vim_lite(feats: Any, *, topk: int = 100) -> tuple[Any, Any]:
    """Fit a principal subspace for Residual/ViM-lite scoring.

    Returns (eigvecs, proj_mean) where eigvecs are top principal axes and
    proj_mean is the feature mean.
    """
    import torch

    x = feats.detach().to("cpu")
    mu = x.mean(dim=0, keepdim=True)
    Xc = x - mu
    # SVD for top components
    _U, _S, Vh = torch.linalg.svd(Xc, full_matrices=False)
    k = min(int(topk), int(Vh.shape[0]))
    P = Vh[:k].T  # (D, k)
    return P, mu


def _scores_residual_vim_lite(feats: Any, P: Any, mu: Any) -> Any:
    """Residual norm in the ID principal-subspace complement (higher is more OOD)."""

    from benchmarks.ood.score_contract import validate_ood_scores

    x = feats.detach().to("cpu")
    Xc = x - mu
    proj = Xc @ P @ P.T
    resid = Xc - proj
    s = resid.norm(dim=-1)
    return validate_ood_scores(s, name="residual_vim_lite")


@dataclass
class ResultRow:
    seed: int
    ood_name: str
    method: str
    auroc: float
    aupr_out: float
    fpr95: float
    id_acc: float
    latency_ms_per_sample: float
    higher_is_ood: bool = True
    fitted_on: str = "none"
    provenance: str = "direct_score"
    components: str = ""


def run(
    *,
    data_root: str = "./data",
    device: str = "cpu",
    seeds: Iterable[int] = (123, 456, 789, 321, 654),
    batch_size: int = 256,
    epochs: int = 2,
    # Nervecode settings
    layers: str = "all_conv",
    agg: str = "max",
    K: int = 16,
    coding_dim: int = 8,
    beta_length: float = 1.0,
    beta_entropy: float = 1.0,
    beta_distance: float = 1.0,
    temperature: float = 1.0,
    limit_eval: int | None = None,
    verbose: bool = False,
    no_msp: bool = False,
    no_energy: bool = False,
    no_maxlogit: bool = False,
    no_gen: bool = False,
    gen_gamma: float = 0.1,
    gen_top_m: int | None = None,
    no_odin: bool = False,
    no_mahalanobis: bool = False,
    no_knn: bool = False,
    knn_k: int = 50,
    knn_chunk_size: int = 4096,
    no_residual_vim_lite: bool = False,
    no_vim: bool = False,
    no_nervecode: bool = False,
    combo: str = "id_zscore_equal",
    learn_combo: bool = False,
    learn_combo3: bool = False,
    learn_ood_calibrated_combo: bool = False,
    learn_ood_calibrated_combo3: bool = False,
    comb_alpha: float | None = None,
    combiner_save_path: str | None = None,
    combiner_load_path: str | None = None,
    score_cache_dir: str | None = None,
    layerwise_dir: str | None = None,
    dataset_manifest_path: str | None = None,
    preset: str = PRESET_DEMO,
    accuracy_gate: float | None = None,
    allow_low_accuracy: bool = False,
    checkpoint_dir: str | None = None,
    checkpoint_manifest_path: str | None = None,
) -> list[ResultRow]:
    import torch
    from nervecode import WrappedModel
    from nervecode.layers.wrap import wrap as wrap_layers
    from nervecode.scoring import EmpiricalPercentileCalibrator, max_surprise, mean_surprise
    from torch.utils.data import DataLoader, random_split

    from benchmarks.ood.combo import DEFAULT_COMBO_COMPONENTS, compute_id_zscore_combo_ablation
    from benchmarks.ood.runmeta import combo_provenance

    id_train, id_test, ood_sets = _get_datasets_cifar10_ood(data_root, download=True)
    if dataset_manifest_path:
        all_ood_names = ["svhn", "dtd", "cifar100", "lsun", "isun"]
        available = sorted(str(name) for name in ood_sets)
        _write_json_file(
            dataset_manifest_path,
            {
                "schema": {"kind": "nervecode_dataset_manifest", "version": 1},
                "dataset_root": data_root,
                "id": {
                    "train": "cifar10",
                    "test": "cifar10",
                    "train_size": len(id_train),
                    "test_size": len(id_test),
                },
                "ood_available": available,
                "ood_skipped": [name for name in all_ood_names if name not in set(available)],
            },
        )

    # Backward-compatible aliases. The public CLI now labels these as oracle
    # because they use OOD samples from the evaluated OOD split.
    learn_ood_calibrated_combo = bool(learn_ood_calibrated_combo or learn_combo)
    learn_ood_calibrated_combo3 = bool(learn_ood_calibrated_combo3 or learn_combo3)
    skip_residual_vim_lite = bool(no_residual_vim_lite or no_vim)
    checkpoint_records: list[dict[str, Any]] = []
    accuracy_gate_records: list[dict[str, Any]] = []

    def _write_checkpoint_manifest() -> None:
        if not checkpoint_manifest_path:
            return
        _write_json_file(
            checkpoint_manifest_path,
            {
                "schema": {"kind": "nervecode_checkpoint_manifest", "version": 1},
                "preset": str(preset),
                "checkpoint_dir": checkpoint_dir,
                "accuracy_gate": accuracy_gate,
                "allow_low_accuracy": bool(allow_low_accuracy),
                "checkpoints": checkpoint_records,
                "accuracy_gate_results": accuracy_gate_records,
            },
        )

    def _save_seed_checkpoint(_model: Any, *, _seed: int, _acc: float) -> None:
        if not checkpoint_dir:
            return
        record: dict[str, Any] = {
            "seed": int(_seed),
            "id_acc": float(_acc),
            "preset": str(preset),
            "path": os.path.join(checkpoint_dir, f"seed_{int(_seed)}.pt"),
            "saved": False,
        }
        try:
            os.makedirs(checkpoint_dir, exist_ok=True)
            torch.save(
                {
                    "schema": {"kind": "nervecode_cifar_resnet18_checkpoint", "version": 1},
                    "seed": int(_seed),
                    "id_acc": float(_acc),
                    "preset": str(preset),
                    "model_state_dict": _model.state_dict(),
                    "config": {
                        "layers": str(layers),
                        "agg": str(agg),
                        "K": int(K),
                        "coding_dim": int(coding_dim),
                        "beta_length": float(beta_length),
                        "beta_entropy": float(beta_entropy),
                        "beta_distance": float(beta_distance),
                        "temperature": float(temperature),
                    },
                },
                record["path"],
            )
            record["sha256"] = _sha256_file(record["path"])
            record["bytes"] = int(os.path.getsize(record["path"]))
            record["saved"] = True
        except Exception as exc:
            record["error"] = str(exc)
        checkpoint_records.append(record)
        _write_checkpoint_manifest()

    # Combiner persistence helpers
    def _save_combiner(path: str, store: dict[str, dict[str, Any]]) -> None:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(store, f)
        except Exception:
            pass

    def _load_combiner(path: str) -> dict[str, dict[str, Any]]:
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    combiner_store: dict[str, dict[str, Any]] = {}
    combiner_pre: dict[str, dict[str, Any]] = (
        _load_combiner(combiner_load_path) if combiner_load_path else {}
    )
    # Create calibration split from training (10% of train)
    calib_len = max(1000, int(0.1 * len(id_train)))
    train_len = len(id_train) - calib_len
    id_train_split, id_calib_split = random_split(id_train, [train_len, calib_len])

    def _mk_loader(ds: Any, shuffle: bool = False) -> Any:
        return DataLoader(
            ds, batch_size=batch_size, shuffle=shuffle, num_workers=2, pin_memory=False
        )

    dl_train = _mk_loader(id_train_split, shuffle=True)
    dl_calib = _mk_loader(id_calib_split)
    dl_test = _mk_loader(id_test)

    out_rows: list[ResultRow] = []

    for seed in list(seeds):
        _set_seed(int(seed))

        # Build, wrap, and train model (light epochs by default)
        if verbose:
            print(
                f"[seed {seed}] Building + wrapping model; training for {epochs} epoch(s)...",
                flush=True,
            )
        model = _build_cifar_resnet18(num_classes=10)
        # Instrument model before training so codebooks learn with coding loss
        wrap_layers(model, layers=layers, K=int(K), coding_dim=int(coding_dim))
        wrapped = WrappedModel(model)
        # Apply assignment weights across wrapped layers
        for m in model.modules():
            try:
                from nervecode.layers.conv import CodingConv2d
                from nervecode.layers.linear import CodingLinear

                if isinstance(m, (CodingLinear, CodingConv2d)):
                    m.assignment.beta_length = float(beta_length)
                    m.assignment.beta_entropy = float(beta_entropy)
                    if hasattr(m.assignment, "beta_distance"):
                        m.assignment.beta_distance = float(beta_distance)
                    # Optional temperature adjustment
                    try:
                        import torch as _torch

                        m.assignment._temperature = _torch.tensor(float(temperature))
                    except Exception:
                        pass
            except Exception:
                pass
        t0_train = time.perf_counter()
        _train(
            model, dl_train, device=device, epochs=int(epochs), wrapped=wrapped, coding_loss_w=0.1
        )
        acc = _accuracy(model, dl_test, device=device)
        if verbose:
            dt = time.perf_counter() - t0_train
            print(f"[seed {seed}] Training done in {dt:.1f}s; ID acc={acc:.3f}", flush=True)
        _save_seed_checkpoint(model, _seed=int(seed), _acc=float(acc))
        gate_record = {
            "seed": int(seed),
            "id_acc": float(acc),
            "required_id_acc": accuracy_gate,
            "passed": bool(accuracy_gate is None or float(acc) >= float(accuracy_gate)),
        }
        accuracy_gate_records.append(gate_record)
        _write_checkpoint_manifest()
        if accuracy_gate is not None and float(acc) < float(accuracy_gate):
            msg = (
                f"Accuracy gate failed for seed {int(seed)}: ID accuracy {float(acc):.4f} "
                f"is below required {float(accuracy_gate):.4f}. OOD reporting is blocked "
                "unless --allow-low-accuracy is set."
            )
            if not allow_low_accuracy:
                raise RuntimeError(msg)
            print(f"WARNING: {msg}", file=sys.stderr, flush=True)

        # Baseline common data: logits and features for ID test and each OOD
        if verbose:
            print(f"[seed {seed}] Collecting ID features (limit={limit_eval})...", flush=True)
        logits_id, feats_id = _collect_logits_features(
            model.to(device), dl_test, device=device, max_samples=limit_eval
        )

        # Fit feature-statistic baselines on ID train.
        # Build a loader for train subset to fit statistics
        dl_fit = _mk_loader(id_train_split)
        # Collect features and labels to fit
        model.eval()
        feats_fit: list[Any] = []
        labels_fit: list[Any] = []

        with torch.no_grad():
            seen_fit = 0
            for xb, yb in dl_fit:
                xb = xb.to(device)
                _logits_b, feats_b = _collect_logits_features(model, [(xb, yb)], device=device)
                feats_fit.append(feats_b.cpu())
                labels_fit.append(yb.cpu())
                seen_fit += int(xb.shape[0])
                if limit_eval is not None and seen_fit >= int(limit_eval):
                    break
        feats_fit_t = torch.cat(feats_fit, dim=0)
        labels_fit_t = torch.cat(labels_fit, dim=0)
        if verbose:
            print(
                f"[seed {seed}] Fitting Mahalanobis/KNN/Residual-ViM-lite on train split...",
                flush=True,
            )
        mu_m, inv_cov_m, _cov_m = _fit_mahalanobis(feats_fit_t, labels_fit_t, shrink=0.01)
        P_resid, mu_resid = _fit_residual_vim_lite(feats_fit_t, topk=100)

        # Reuse the wrapped model for scoring
        def _labels_for_components(components: dict[str, Any], label: int) -> Any:
            first = next(iter(components.values()))
            n = int(torch.as_tensor(first).reshape(-1).numel())
            return torch.full((n,), int(label), dtype=torch.long)

        def _save_component_cache(
            split_name: str,
            components: dict[str, Any],
            *,
            label: int,
            metadata: dict[str, Any],
            _seed: int = int(seed),
        ) -> None:
            if not score_cache_dir or not components:
                return
            try:
                from benchmarks.ood.cache import save_component_score_vectors

                safe_split = str(split_name).replace("/", "_").replace(os.sep, "_")
                path = os.path.join(
                    score_cache_dir,
                    f"seed_{int(_seed)}",
                    f"{safe_split}_components.npz",
                )
                save_component_score_vectors(
                    path,
                    components=components,
                    labels=_labels_for_components(components, label),
                    metadata=metadata,
                )
            except Exception:
                pass

        def _new_layerwise_store() -> dict[str, Any]:
            return {
                "layer_names": None,
                "reduction_meta": None,
                "surprise": [],
                "labels": [],
                "sample_ids": [],
                "count": 0,
            }

        def _append_layerwise(
            store: dict[str, Any],
            traces: dict[str, Any],
            labels: Any | None = None,
        ) -> None:
            if not layerwise_dir:
                return
            try:
                from nervecode.viz.layerwise import extract_layerwise_surprise

                extracted = extract_layerwise_surprise(traces)
                if extracted is None:
                    return
                names, surprise, reduction_meta = extracted
                if store["layer_names"] is None:
                    store["layer_names"] = names
                    store["reduction_meta"] = reduction_meta
                elif list(store["layer_names"]) != list(names):
                    return
                n = int(surprise.shape[0])
                store["surprise"].append(surprise)
                start = int(store["count"])
                store["sample_ids"].append(torch.arange(start, start + n, dtype=torch.long))
                store["count"] = start + n
                if labels is not None:
                    lab = torch.as_tensor(labels).detach().to(device="cpu").reshape(-1)
                    if int(lab.numel()) == n:
                        store["labels"].append(lab)
            except Exception:
                pass

        def _save_layerwise(
            split_name: str,
            store: dict[str, Any],
            *,
            metadata: dict[str, Any],
            _seed: int = int(seed),
        ) -> None:
            if not layerwise_dir or not store.get("surprise"):
                return
            try:
                from nervecode.viz.layerwise import save_layerwise_artifact

                safe_split = str(split_name).replace("/", "_").replace(os.sep, "_")
                path = os.path.join(
                    layerwise_dir,
                    f"seed_{int(_seed)}",
                    f"{safe_split}.npz",
                )
                labels_t = torch.cat(store["labels"], dim=0) if store["labels"] else None
                sample_ids_t = (
                    torch.cat(store["sample_ids"], dim=0) if store["sample_ids"] else None
                )
                save_layerwise_artifact(
                    path,
                    layer_names=list(store["layer_names"]),
                    surprise=torch.cat(store["surprise"], dim=0),
                    labels=labels_t,
                    sample_ids=sample_ids_t,
                    reduction_meta=list(store["reduction_meta"] or []),
                    metadata={
                        "seed": int(_seed),
                        "aggregation": str(agg),
                        **metadata,
                    },
                )
            except Exception:
                pass

        # Collect calibration logits/features once for ID-only combo statistics.
        _logits_calib, feats_calib = _collect_logits_features(
            model, dl_calib, device=device, max_samples=limit_eval
        )
        s_maha_calib = (
            _scores_mahalanobis(feats_calib, mu_m, inv_cov_m) if not no_mahalanobis else None
        )

        # Calibrate Nervecode on calibration split and collect Energy/MSP on calib.
        scores_calib: list[Any] = []
        energy_calib: list[Any] = []
        msp_calib: list[Any] = []
        layerwise_calib = _new_layerwise_store()
        with torch.no_grad():
            seen_cal = 0
            for xb, yb in dl_calib:
                logits_c = wrapped.forward(xb.to(device))
                traces = getattr(wrapped, "_last_layer_traces", {})
                _append_layerwise(layerwise_calib, traces, labels=yb)
                agg_obj = (
                    max_surprise(traces) if str(agg).lower() == "max" else mean_surprise(traces)
                )
                if agg_obj is not None:
                    scores_calib.append(agg_obj.surprise.detach().to("cpu").reshape(-1))
                # Energy on calibration logits
                e_c = _scores_energy(logits_c, temperature=1.0)
                energy_calib.append(e_c.detach().to("cpu").reshape(-1))
                # MSP on calibration logits
                p_c = _scores_msp(logits_c)
                msp_calib.append(p_c.detach().to("cpu").reshape(-1))
                seen_cal += int(xb.shape[0])
                if limit_eval is not None and seen_cal >= int(limit_eval):
                    break
        _save_layerwise(
            "id_calibration",
            layerwise_calib,
            metadata={"split": "id_calibration"},
        )
        s_calib = torch.cat(scores_calib, dim=0) if scores_calib else None
        if s_calib is not None:
            calibrator = EmpiricalPercentileCalibrator(threshold_quantiles=(0.95,))
            calibrator.fit(s_calib, aggregation=str(agg))
        else:
            calibrator = EmpiricalPercentileCalibrator(threshold_quantiles=(0.95,))
        e_calib = torch.cat(energy_calib, dim=0) if energy_calib else None
        msp_calib_t = torch.cat(msp_calib, dim=0) if msp_calib else None
        combo_calibration_components: dict[str, Any] = {}
        if (not no_energy) and e_calib is not None:
            combo_calibration_components["energy"] = e_calib
        if (not no_mahalanobis) and s_maha_calib is not None:
            combo_calibration_components["mahalanobis"] = s_maha_calib
        if (not no_nervecode) and s_calib is not None:
            combo_calibration_components["nervecode"] = s_calib
        _save_component_cache(
            "id_calibration",
            combo_calibration_components,
            label=0,
            metadata={
                "split": "id_calibration",
                "fitted_on": "id_calibration",
                "components": list(combo_calibration_components),
                "purpose": "combo_id_zscore_equal_normalization",
            },
        )

        # Measure rough per-sample latency for each method on ID (first ~1024 samples)
        lat_by_method: dict[str, float] = {}

        def _measure_latency_msp(
            _model: Any = model, _dl: Any = dl_test, _device: Any = device
        ) -> float:
            import torch

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    xb = xb.to(_device)
                    z = _model(xb)
                    _ = _scores_msp(z)
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_energy(
            _model: Any = model, _dl: Any = dl_test, _device: Any = device
        ) -> float:
            import torch

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    xb = xb.to(_device)
                    z = _model(xb)
                    _ = _scores_energy(z, temperature=1.0)
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_maxlogit(
            _model: Any = model, _dl: Any = dl_test, _device: Any = device
        ) -> float:
            import torch

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    xb = xb.to(_device)
                    z = _model(xb)
                    _ = _scores_maxlogit(z)
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_gen(
            _model: Any = model, _dl: Any = dl_test, _device: Any = device
        ) -> float:
            import torch

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    xb = xb.to(_device)
                    z = _model(xb)
                    _ = _scores_gen(z, gamma=float(gen_gamma), top_m=gen_top_m)
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_odin(
            _model: Any = model, _dl: Any = dl_test, _device: Any = device
        ) -> float:
            n, t0 = 0, time.perf_counter()
            _ = _scores_odin(_model, _dl, device=_device)
            for _xb, _ in _dl:
                n += int(_xb.shape[0])
                if n >= 1024:
                    break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_maha(
            _model: Any = model,
            _dl: Any = dl_test,
            _device: Any = device,
            _mu_m: Any = mu_m,
            _inv_cov_m: Any = inv_cov_m,
        ) -> float:
            import torch

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    xb = xb.to(_device)
                    _z, f = _collect_logits_features(
                        _model, [(xb, torch.empty(xb.shape[0], dtype=torch.long))], device=_device
                    )
                    _ = _scores_mahalanobis(f, _mu_m, _inv_cov_m)
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_knn(
            _model: Any = model,
            _dl: Any = dl_test,
            _device: Any = device,
            _train_feats: Any = feats_fit_t,
        ) -> float:
            import torch

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    xb = xb.to(_device)
                    _z, f = _collect_logits_features(
                        _model, [(xb, torch.empty(xb.shape[0], dtype=torch.long))], device=_device
                    )
                    _ = _scores_knn(
                        _train_feats,
                        f,
                        k=int(knn_k),
                        chunk_size=int(knn_chunk_size),
                    )
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_residual_vim_lite(
            _model: Any = model,
            _dl: Any = dl_test,
            _device: Any = device,
            _P_resid: Any = P_resid,
            _mu_resid: Any = mu_resid,
        ) -> float:
            import torch

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    xb = xb.to(_device)
                    _z, f = _collect_logits_features(
                        _model, [(xb, torch.empty(xb.shape[0], dtype=torch.long))], device=_device
                    )
                    _ = _scores_residual_vim_lite(f, _P_resid, _mu_resid)
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        def _measure_latency_nervecode(
            _wrapped: Any = wrapped,
            _dl: Any = dl_test,
            _device: Any = device,
            _agg: Any = agg,
        ) -> float:
            import torch
            from nervecode.scoring import max_surprise, mean_surprise

            n, t0 = 0, time.perf_counter()
            with torch.no_grad():
                for xb, _ in _dl:
                    _ = _wrapped.forward(xb.to(_device))
                    traces = getattr(_wrapped, "_last_layer_traces", {})
                    _ = (
                        max_surprise(traces)
                        if str(_agg).lower() == "max"
                        else mean_surprise(traces)
                    )
                    n += int(xb.shape[0])
                    if n >= 1024:
                        break
            return (time.perf_counter() - t0) * 1000.0 / max(1, n)

        if not no_msp:
            lat_by_method["msp"] = _measure_latency_msp()
        if not no_energy:
            lat_by_method["energy"] = _measure_latency_energy()
        if not no_maxlogit:
            lat_by_method["maxlogit"] = _measure_latency_maxlogit()
        if not no_gen:
            lat_by_method["gen"] = _measure_latency_gen()
        if not no_odin:
            lat_by_method["odin"] = _measure_latency_odin()
        if not no_mahalanobis:
            lat_by_method["mahalanobis"] = _measure_latency_maha()
        if not no_knn:
            lat_by_method["knn"] = _measure_latency_knn()
        if not skip_residual_vim_lite:
            lat_by_method["residual_vim_lite"] = _measure_latency_residual_vim_lite()
        if not no_nervecode:
            lat_by_method[f"nervecode_{agg}"] = _measure_latency_nervecode()

        # Collect ID-test Nervecode scores and layerwise artifacts once; reuse
        # them for each OOD comparison.
        s_nc_id: list[Any] = []
        layerwise_id_test = _new_layerwise_store()
        if not no_nervecode:
            with torch.no_grad():
                seen_id = 0
                for xb, yb in dl_test:
                    _ = wrapped.forward(xb.to(device))
                    traces = getattr(wrapped, "_last_layer_traces", {})
                    _append_layerwise(layerwise_id_test, traces, labels=yb)
                    agg_obj = (
                        max_surprise(traces) if str(agg).lower() == "max" else mean_surprise(traces)
                    )
                    if agg_obj is not None:
                        s_nc_id.append(agg_obj.surprise.detach().to("cpu").reshape(-1))
                    seen_id += int(xb.shape[0])
                    if limit_eval is not None and seen_id >= int(limit_eval):
                        break
        s_nc_id_t = torch.cat(s_nc_id, dim=0) if s_nc_id else torch.empty(0)
        _save_layerwise(
            "id_test",
            layerwise_id_test,
            metadata={"split": "id_test"},
        )

        # Evaluate per OOD set
        saved_id_test_component_cache = False
        for ood_name, ood_ds in ood_sets.items():
            if verbose:
                print(
                    f"[seed {seed}] OOD={ood_name}: scoring baselines and Nervecode...", flush=True
                )
            dl_ood = _mk_loader(ood_ds)

            # Baseline scores and latency
            # MSP / Energy from ID/ OOD logits
            logits_ood, feats_ood = _collect_logits_features(
                model, dl_ood, device=device, max_samples=limit_eval
            )
            if not no_msp:
                s_msp_id = _scores_msp(logits_id)
                s_msp_ood = _scores_msp(logits_ood)
            if not no_energy:
                s_energy_id = _scores_energy(logits_id, temperature=1.0)
                s_energy_ood = _scores_energy(logits_ood, temperature=1.0)
            if not no_maxlogit:
                s_maxlogit_id = _scores_maxlogit(logits_id)
                s_maxlogit_ood = _scores_maxlogit(logits_ood)
            if not no_gen:
                s_gen_id = _scores_gen(logits_id, gamma=float(gen_gamma), top_m=gen_top_m)
                s_gen_ood = _scores_gen(logits_ood, gamma=float(gen_gamma), top_m=gen_top_m)
            if not no_odin:
                s_odin_id = _scores_odin(
                    model,
                    dl_test,
                    device=device,
                    max_samples=limit_eval,
                    report_every=256,
                    tag="ID",
                )
                s_odin_ood = _scores_odin(
                    model,
                    dl_ood,
                    device=device,
                    max_samples=limit_eval,
                    report_every=256,
                    tag=ood_name,
                )
            if not no_mahalanobis:
                s_maha_id = _scores_mahalanobis(feats_id, mu_m, inv_cov_m)
                s_maha_ood = _scores_mahalanobis(feats_ood, mu_m, inv_cov_m)
            if not no_knn:
                s_knn_id = _scores_knn(
                    feats_fit_t,
                    feats_id,
                    k=int(knn_k),
                    chunk_size=int(knn_chunk_size),
                )
                s_knn_ood = _scores_knn(
                    feats_fit_t,
                    feats_ood,
                    k=int(knn_k),
                    chunk_size=int(knn_chunk_size),
                )
            if not skip_residual_vim_lite:
                s_resid_id = _scores_residual_vim_lite(feats_id, P_resid, mu_resid)
                s_resid_ood = _scores_residual_vim_lite(feats_ood, P_resid, mu_resid)

            # Nervecode scores and layerwise artifact for OOD.
            s_nc_ood: list[Any] = []
            layerwise_ood = _new_layerwise_store()
            if not no_nervecode:
                with torch.no_grad():
                    seen_ood = 0
                    for xb, yb in dl_ood:
                        _ = wrapped.forward(xb.to(device))
                        traces = getattr(wrapped, "_last_layer_traces", {})
                        _append_layerwise(layerwise_ood, traces, labels=yb)
                        agg_obj = (
                            max_surprise(traces)
                            if str(agg).lower() == "max"
                            else mean_surprise(traces)
                        )
                        if agg_obj is not None:
                            s_nc_ood.append(agg_obj.surprise.detach().to("cpu").reshape(-1))
                        seen_ood += int(xb.shape[0])
                        if limit_eval is not None and seen_ood >= int(limit_eval):
                            break
            s_nc_ood_t = torch.cat(s_nc_ood, dim=0) if s_nc_ood else torch.empty(0)
            _save_layerwise(
                f"ood_{ood_name}",
                layerwise_ood,
                metadata={"split": "ood_test", "ood": str(ood_name)},
            )

            # Metrics
            def _metrics(
                id_s: Any,
                ood_s: Any,
                method_name: str,
                *,
                fitted_on: str = "none",
                provenance: str = "direct_score",
                components: Iterable[str] = (),
                _lat: dict[str, float] = lat_by_method,
                _seed: int = seed,
                _ood: str = ood_name,
                _acc: float = acc,
            ) -> ResultRow:
                from benchmarks.ood.metrics import aupr_out
                from benchmarks.ood.score_contract import validate_ood_scores

                id_vec = validate_ood_scores(id_s, name=f"{method_name}_id")
                ood_vec = validate_ood_scores(ood_s, name=f"{method_name}_ood")
                s = torch.cat([id_vec, ood_vec], dim=0)
                y = torch.cat(
                    [
                        torch.zeros_like(id_vec, dtype=torch.long),
                        torch.ones_like(ood_vec, dtype=torch.long),
                    ]
                )
                auc = _auroc(s, y)
                aupr = aupr_out(s, y)
                fpr = _fpr_at_tpr(id_s, ood_s, target_tpr=0.95)
                lat = float(_lat.get(method_name, float("nan")))
                return ResultRow(
                    seed=int(_seed),
                    ood_name=str(_ood),
                    method=method_name,
                    auroc=float(auc),
                    aupr_out=float(aupr),
                    fpr95=float(fpr),
                    id_acc=float(_acc),
                    latency_ms_per_sample=float(lat),
                    higher_is_ood=True,
                    fitted_on=str(fitted_on),
                    provenance=str(provenance),
                    components="+".join(str(c) for c in components),
                )

            if not no_msp:
                out_rows.append(_metrics(s_msp_id, s_msp_ood, "msp"))
            if not no_energy:
                out_rows.append(_metrics(s_energy_id, s_energy_ood, "energy"))
            if not no_maxlogit:
                out_rows.append(_metrics(s_maxlogit_id, s_maxlogit_ood, "maxlogit"))
            if not no_gen:
                out_rows.append(
                    _metrics(
                        s_gen_id,
                        s_gen_ood,
                        "gen",
                        provenance=f"gen_gamma={float(gen_gamma):g}_top_m={gen_top_m}",
                    )
                )
            if not no_odin:
                out_rows.append(_metrics(s_odin_id, s_odin_ood, "odin"))
            if not no_mahalanobis:
                out_rows.append(
                    _metrics(
                        s_maha_id,
                        s_maha_ood,
                        "mahalanobis",
                        fitted_on="id_train",
                        provenance="class_means_shared_covariance",
                        components=("features",),
                    )
                )
            if not no_knn:
                out_rows.append(
                    _metrics(
                        s_knn_id,
                        s_knn_ood,
                        "knn",
                        fitted_on="id_train",
                        provenance=f"l2_normalized_kth_neighbor_distance_k={int(knn_k)}",
                        components=("features",),
                    )
                )
            if not skip_residual_vim_lite:
                out_rows.append(
                    _metrics(
                        s_resid_id,
                        s_resid_ood,
                        "residual_vim_lite",
                        fitted_on="id_train",
                        provenance="principal_subspace_residual_norm",
                        components=("features",),
                    )
                )
            if not no_nervecode:
                out_rows.append(
                    _metrics(
                        s_nc_id_t,
                        s_nc_ood_t,
                        f"nervecode_{agg}",
                        fitted_on="id_train+id_calibration",
                        provenance="raw_surprise_with_id_calibration_state",
                        components=("nervecode",),
                    )
                )

            combo_id_components: dict[str, Any] = {}
            combo_ood_components: dict[str, Any] = {}
            if not no_energy:
                combo_id_components["energy"] = s_energy_id
                combo_ood_components["energy"] = s_energy_ood
            if not no_mahalanobis:
                combo_id_components["mahalanobis"] = s_maha_id
                combo_ood_components["mahalanobis"] = s_maha_ood
            if not no_nervecode:
                combo_id_components["nervecode"] = s_nc_id_t
                combo_ood_components["nervecode"] = s_nc_ood_t
            if not saved_id_test_component_cache:
                _save_component_cache(
                    "id_test",
                    combo_id_components,
                    label=0,
                    metadata={
                        "split": "id_test",
                        "components": list(combo_id_components),
                        "purpose": "combo_id_zscore_equal_offline_ablation",
                    },
                )
                saved_id_test_component_cache = True
            _save_component_cache(
                f"ood_{ood_name}",
                combo_ood_components,
                label=1,
                metadata={
                    "split": "ood_test",
                    "ood": str(ood_name),
                    "components": list(combo_ood_components),
                    "purpose": "combo_id_zscore_equal_offline_ablation",
                },
            )

            if str(combo).lower() == "id_zscore_equal":
                try:
                    component_latencies = {
                        "energy": float(lat_by_method.get("energy", float("nan"))),
                        "mahalanobis": float(lat_by_method.get("mahalanobis", float("nan"))),
                        "nervecode": float(lat_by_method.get(f"nervecode_{agg}", float("nan"))),
                    }
                    for combo_scores in compute_id_zscore_combo_ablation(
                        calibration_components=combo_calibration_components,
                        id_components=combo_id_components,
                        ood_components=combo_ood_components,
                        component_order=DEFAULT_COMBO_COMPONENTS,
                    ):
                        lat_by_method[combo_scores.method] = sum(
                            component_latencies.get(name, 0.0) for name in combo_scores.components
                        )
                        out_rows.append(
                            _metrics(
                                combo_scores.id_scores,
                                combo_scores.ood_scores,
                                combo_scores.method,
                                fitted_on="id_calibration",
                                provenance=str(
                                    combo_scores.metadata.get(
                                        "provenance", "id_only_zscore_equal_weight"
                                    )
                                ),
                                components=combo_scores.components,
                            )
                        )
                except Exception:
                    pass

            # Simple score combiner: Energy + alpha * Nervecode
            if (comb_alpha is not None) and (not no_energy) and (not no_nervecode):
                try:
                    alpha = float(comb_alpha)
                    s_comb_id = s_energy_id + alpha * s_nc_id_t
                    s_comb_ood = s_energy_ood + alpha * s_nc_ood_t
                    # Latency is additive as we compute both signals
                    method = f"combo_fixed_energy+nervecode_alpha{alpha:g}"
                    lat_by_method[method] = float(
                        lat_by_method.get("energy", float("nan"))
                    ) + float(lat_by_method.get(f"nervecode_{agg}", float("nan")))
                    out_rows.append(
                        _metrics(
                            s_comb_id,
                            s_comb_ood,
                            method,
                            fitted_on="external_alpha",
                            provenance="fixed_alpha_must_be_chosen_without_ood_test",
                            components=("energy", "nervecode"),
                        )
                    )
                except Exception:
                    pass

            # Loaded combiner (JSON) if available
            if combiner_load_path:
                try:
                    # Load once outside the loop; reuse here
                    cfg_all = combiner_pre if "combiner_pre" in locals() else {}
                    cfg = cfg_all.get(ood_name, {})
                    feats = cfg.get("features", [])
                    wv = cfg.get("w", [])
                    b0 = float(cfg.get("b", 0.0))
                    if feats and wv:
                        feat_map = {"nervecode": (s_nc_id_t.view(-1), s_nc_ood_t.view(-1))}
                        if not no_energy:
                            feat_map["energy"] = (s_energy_id.view(-1), s_energy_ood.view(-1))
                        if not no_msp:
                            feat_map["msp"] = (s_msp_id.view(-1), s_msp_ood.view(-1))
                        if not no_maxlogit:
                            feat_map["maxlogit"] = (
                                s_maxlogit_id.view(-1),
                                s_maxlogit_ood.view(-1),
                            )
                        if not no_gen:
                            feat_map["gen"] = (s_gen_id.view(-1), s_gen_ood.view(-1))
                        if not no_knn:
                            feat_map["knn"] = (s_knn_id.view(-1), s_knn_ood.view(-1))
                        sid: Any | None = None
                        sod: Any | None = None
                        for j, name in enumerate(feats):
                            vi_id, vi_ood = feat_map.get(str(name), (None, None))
                            if vi_id is None or vi_ood is None:
                                continue
                            wi = float(wv[j]) if j < len(wv) else 0.0
                            id_term = wi * vi_id
                            ood_term = wi * vi_ood
                            sid = id_term if sid is None else sid + id_term
                            sod = ood_term if sod is None else sod + ood_term
                        if sid is None or sod is None:
                            continue
                        sid = sid + b0
                        sod = sod + b0
                        lsum = 0.0
                        if "energy" in feats:
                            lsum += float(lat_by_method.get("energy", 0.0))
                        if "msp" in feats:
                            lsum += float(lat_by_method.get("msp", 0.0))
                        if "maxlogit" in feats:
                            lsum += float(lat_by_method.get("maxlogit", 0.0))
                        if "gen" in feats:
                            lsum += float(lat_by_method.get("gen", 0.0))
                        if "knn" in feats:
                            lsum += float(lat_by_method.get("knn", 0.0))
                        if "nervecode" in feats:
                            lsum += float(lat_by_method.get(f"nervecode_{agg}", 0.0))
                        method = str(cfg.get("label", "combo_loaded_unverified"))
                        lat_by_method[method] = lsum
                        out_rows.append(
                            _metrics(
                                sid,
                                sod,
                                method,
                                fitted_on=str(cfg.get("fitted_on", "unknown")),
                                provenance=str(cfg.get("provenance", "loaded_unverified")),
                                components=tuple(str(f) for f in feats),
                            )
                        )
                except Exception:
                    pass

            # Oracle OOD-calibrated 3-feature combiner: Energy, MSP, Nervecode.
            # This uses samples from the evaluated OOD split and is not valid
            # for headline detector comparisons.
            if (
                learn_ood_calibrated_combo3
                and (not no_energy)
                and (not no_msp)
                and (not no_nervecode)
                and (s_calib is not None)
                and (e_calib is not None)
                and (msp_calib_t is not None)
            ):
                try:
                    feats_nc_cal_ood3: list[Any] = []
                    feats_en_cal_ood3: list[Any] = []
                    feats_msp_cal_ood3: list[Any] = []
                    seen_o = 0
                    limit_cal = int(min(500, int(limit_eval or 1000)))
                    with torch.no_grad():
                        for xb, _ in dl_ood:
                            logits_o = model(xb.to(device))
                            e_o = (
                                _scores_energy(logits_o, temperature=1.0)
                                .detach()
                                .to("cpu")
                                .reshape(-1)
                            )
                            p_o = _scores_msp(logits_o).detach().to("cpu").reshape(-1)
                            _ = wrapped.forward(xb.to(device))
                            traces_o = getattr(wrapped, "_last_layer_traces", {})
                            agg_o = (
                                max_surprise(traces_o)
                                if str(agg).lower() == "max"
                                else mean_surprise(traces_o)
                            )
                            if agg_o is not None:
                                feats_nc_cal_ood3.append(
                                    agg_o.surprise.detach().to("cpu").reshape(-1)
                                )
                                feats_en_cal_ood3.append(e_o)
                                feats_msp_cal_ood3.append(p_o)
                            seen_o += int(xb.shape[0])
                            if seen_o >= limit_cal:
                                break
                    if feats_nc_cal_ood3 and feats_en_cal_ood3 and feats_msp_cal_ood3:
                        nc_id = s_calib
                        en_id = e_calib
                        ms_id = msp_calib_t
                        nc_ood = torch.cat(feats_nc_cal_ood3, dim=0)
                        en_ood = torch.cat(feats_en_cal_ood3, dim=0)
                        ms_ood = torch.cat(feats_msp_cal_ood3, dim=0)
                        X3 = torch.stack(
                            [
                                torch.cat([en_id, en_ood], dim=0),
                                torch.cat([ms_id, ms_ood], dim=0),
                                torch.cat([nc_id, nc_ood], dim=0),
                            ],
                            dim=1,
                        )
                        y3 = torch.cat(
                            [
                                torch.zeros_like(en_id, dtype=torch.float32),
                                torch.ones_like(en_ood, dtype=torch.float32),
                            ],
                            dim=0,
                        )
                        w3 = torch.zeros(3, dtype=torch.float32, requires_grad=True)
                        b3 = torch.zeros(1, dtype=torch.float32, requires_grad=True)
                        opt3 = torch.optim.SGD([w3, b3], lr=0.1)
                        loss_fn = torch.nn.BCEWithLogitsLoss()
                        for _ in range(200):
                            opt3.zero_grad(set_to_none=True)
                            logits_lr3 = X3 @ w3 + b3
                            loss3 = loss_fn(logits_lr3.view(-1), y3)
                            loss3.backward()
                            opt3.step()
                        s_lr3_id = (
                            s_energy_id.view(-1) * w3[0]
                            + s_msp_id.view(-1) * w3[1]
                            + s_nc_id_t.view(-1) * w3[2]
                            + b3.item()
                        )
                        s_lr3_ood = (
                            s_energy_ood.view(-1) * w3[0]
                            + s_msp_ood.view(-1) * w3[1]
                            + s_nc_ood_t.view(-1) * w3[2]
                            + b3.item()
                        )
                        method = "oracle_ood_calibrated_combo_lr3"
                        lat_by_method[method] = (
                            float(lat_by_method.get("energy", float("nan")))
                            + float(lat_by_method.get("msp", float("nan")))
                            + float(lat_by_method.get(f"nervecode_{agg}", float("nan")))
                        )
                        out_rows.append(
                            _metrics(
                                s_lr3_id,
                                s_lr3_ood,
                                method,
                                fitted_on="id_calibration+evaluated_ood_test_subset",
                                provenance="oracle_ood_calibrated_logistic_regression",
                                components=("energy", "msp", "nervecode"),
                            )
                        )
                        if combiner_save_path:
                            with contextlib.suppress(Exception):
                                prov = combo_provenance(
                                    "ood_calibrated", components=["energy", "msp", "nervecode"]
                                )
                                combiner_store[ood_name] = {
                                    "label": method,
                                    "fitted_on": "id_calibration+evaluated_ood_test_subset",
                                    "provenance": "oracle_ood_calibrated_logistic_regression",
                                    "allowed_headline_use": bool(prov["allowed_headline_use"]),
                                    "uses_ood_samples_for_fit": True,
                                    "features": ["energy", "msp", "nervecode"],
                                    "w": [
                                        float(w3[0].item()),
                                        float(w3[1].item()),
                                        float(w3[2].item()),
                                    ],
                                    "b": float(b3.item()),
                                }
                except Exception:
                    pass
            # Oracle OOD-calibrated combiner: logistic regression on ID
            # calibration plus a small subset of the evaluated OOD split.
            if (
                learn_ood_calibrated_combo
                and (not no_energy)
                and (not no_nervecode)
                and (s_calib is not None)
                and (e_calib is not None)
            ):
                try:
                    # Prepare small OOD calibration subset scores
                    feats_nc_cal_ood: list[Any] = []
                    feats_en_cal_ood: list[Any] = []
                    seen_o = 0
                    limit_cal = int(min(500, int(limit_eval or 1000)))
                    with torch.no_grad():
                        for xb, _ in dl_ood:
                            logits_o = model(xb.to(device))
                            e_o = (
                                _scores_energy(logits_o, temperature=1.0)
                                .detach()
                                .to("cpu")
                                .reshape(-1)
                            )
                            _ = wrapped.forward(xb.to(device))
                            traces_o = getattr(wrapped, "_last_layer_traces", {})
                            agg_o = (
                                max_surprise(traces_o)
                                if str(agg).lower() == "max"
                                else mean_surprise(traces_o)
                            )
                            if agg_o is not None:
                                feats_nc_cal_ood.append(
                                    agg_o.surprise.detach().to("cpu").reshape(-1)
                                )
                                feats_en_cal_ood.append(e_o)
                            seen_o += int(xb.shape[0])
                            if seen_o >= limit_cal:
                                break
                    if feats_nc_cal_ood and feats_en_cal_ood:
                        nc_id = s_calib
                        en_id = e_calib
                        nc_ood = torch.cat(feats_nc_cal_ood, dim=0)
                        en_ood = torch.cat(feats_en_cal_ood, dim=0)
                        # Build features and labels
                        X = torch.stack(
                            [torch.cat([en_id, en_ood], dim=0), torch.cat([nc_id, nc_ood], dim=0)],
                            dim=1,
                        )
                        y = torch.cat(
                            [
                                torch.zeros_like(en_id, dtype=torch.float32),
                                torch.ones_like(en_ood, dtype=torch.float32),
                            ],
                            dim=0,
                        )
                        # Fit a tiny logistic regression on CPU
                        w = torch.zeros(2, dtype=torch.float32, requires_grad=True)
                        b = torch.zeros(1, dtype=torch.float32, requires_grad=True)
                        opt = torch.optim.SGD([w, b], lr=0.1)
                        loss_fn = torch.nn.BCEWithLogitsLoss()
                        for _ in range(200):
                            opt.zero_grad(set_to_none=True)
                            logits_lr = X @ w + b
                            loss = loss_fn(logits_lr.view(-1), y)
                            loss.backward()
                            opt.step()
                        # Apply to test ID/OOD
                        s_lr_id = s_energy_id.view(-1) * w[0] + s_nc_id_t.view(-1) * w[1] + b.item()
                        s_lr_ood = (
                            s_energy_ood.view(-1) * w[0] + s_nc_ood_t.view(-1) * w[1] + b.item()
                        )
                        method = "oracle_ood_calibrated_combo_lr"
                        lat_by_method[method] = float(
                            lat_by_method.get("energy", float("nan"))
                        ) + float(lat_by_method.get(f"nervecode_{agg}", float("nan")))
                        out_rows.append(
                            _metrics(
                                s_lr_id,
                                s_lr_ood,
                                method,
                                fitted_on="id_calibration+evaluated_ood_test_subset",
                                provenance="oracle_ood_calibrated_logistic_regression",
                                components=("energy", "nervecode"),
                            )
                        )
                        if combiner_save_path:
                            with contextlib.suppress(Exception):
                                prov = combo_provenance(
                                    "ood_calibrated", components=["energy", "nervecode"]
                                )
                                combiner_store[ood_name] = {
                                    "label": method,
                                    "fitted_on": "id_calibration+evaluated_ood_test_subset",
                                    "provenance": "oracle_ood_calibrated_logistic_regression",
                                    "allowed_headline_use": bool(prov["allowed_headline_use"]),
                                    "uses_ood_samples_for_fit": True,
                                    "features": ["energy", "nervecode"],
                                    "w": [float(w[0].item()), float(w[1].item())],
                                    "b": float(b.item()),
                                }
                except Exception:
                    pass

    # Save combiner weights if requested
    if combiner_save_path and combiner_store:
        _save_combiner(combiner_save_path, combiner_store)
    _write_checkpoint_manifest()
    return out_rows


def _write_results(rows: list[ResultRow], outdir: str) -> None:
    os.makedirs(outdir, exist_ok=True)
    csv_path = os.path.join(outdir, "results.csv")
    json_path = os.path.join(outdir, "results.json")
    jsonl = os.path.join(outdir, "results.jsonl")
    if rows:
        with open(csv_path, "w", encoding="utf-8") as f:
            f.write(
                "seed,ood,method,auroc,aupr_out,fpr95,id_acc,latency_ms,higher_is_ood,"
                "fitted_on,provenance,components\n"
            )
            for r in rows:
                f.write(
                    f"{r.seed},{r.ood_name},{r.method},{r.auroc},{r.aupr_out},{r.fpr95},"
                    f"{r.id_acc},{r.latency_ms_per_sample},{str(r.higher_is_ood).lower()},"
                    f"{r.fitted_on},{r.provenance},{r.components}\n"
                )
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump([asdict(r) for r in rows], f, indent=2, sort_keys=True)
            f.write("\n")
        with open(jsonl, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(asdict(r)) + "\n")


def _cli_option_was_provided(argv: list[str], option: str) -> bool:
    return any(arg == option or arg.startswith(f"{option}=") for arg in argv)


def _apply_preset_defaults(
    args: argparse.Namespace,
    argv: list[str],
    *,
    explicit_attrs: set[str] | None = None,
) -> None:
    """Apply benchmark preset defaults without overriding explicit CLI flags."""

    explicit_attrs = explicit_attrs or set()
    preset = str(args.preset)
    if preset == PRESET_DEMO:
        defaults: dict[str, Any] = {
            "seeds": [123],
            "batch_size": 128,
            "epochs": 1,
            "limit_eval": 512,
            "layers": "last_block",
            "accuracy_gate": None,
        }
        default_no_odin = True
    elif preset == PRESET_FULL_CIFAR10_RESNET18:
        defaults = {
            "seeds": [123],
            "batch_size": 128,
            "epochs": 200,
            "limit_eval": None,
            "layers": "last_block",
            "accuracy_gate": FULL_CIFAR10_RESNET18_ACCURACY_GATE,
        }
        default_no_odin = False
    else:  # pragma: no cover - argparse choices should prevent this
        raise ValueError(f"unsupported preset: {preset}")

    option_by_attr = {
        "seeds": "--seeds",
        "batch_size": "--batch-size",
        "epochs": "--epochs",
        "limit_eval": "--limit-eval",
        "layers": "--layers",
        "accuracy_gate": "--accuracy-gate",
    }
    for attr, default in defaults.items():
        if attr not in explicit_attrs and not _cli_option_was_provided(argv, option_by_attr[attr]):
            setattr(args, attr, default)

    if bool(getattr(args, "with_odin", False)):
        args.no_odin = False
    elif "no_odin" not in explicit_attrs and not _cli_option_was_provided(argv, "--no-odin"):
        args.no_odin = default_no_odin


def _load_json_config(path: str | os.PathLike[str] | None) -> dict[str, Any]:
    if not path:
        return {}
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return data


def _config_cli_defaults(config: dict[str, Any]) -> tuple[dict[str, Any], set[str]]:
    """Return argparse defaults from a benchmark JSON config."""

    raw_cli = config.get("cli", {})
    if not isinstance(raw_cli, dict):
        raise ValueError("config field 'cli' must be an object when present")
    defaults: dict[str, Any] = {}
    for key, value in raw_cli.items():
        if not isinstance(key, str):
            continue
        attr = key.strip().replace("-", "_")
        defaults[attr] = value
    return defaults, set(defaults)


def _preparse_config_path(argv: list[str]) -> str | None:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--config", default=None)
    known, _ = parser.parse_known_args(argv)
    config = getattr(known, "config", None)
    return config if isinstance(config, str) else None


def _benchmark_policy_metadata(args: argparse.Namespace) -> dict[str, Any]:
    is_demo = str(args.preset) == PRESET_DEMO
    is_full = str(args.preset) == PRESET_FULL_CIFAR10_RESNET18
    return {
        "preset": str(args.preset),
        "backbone": str(args.backbone),
        "claim_status": "demo_only" if is_demo else "claim_candidate",
        "demo_only": is_demo,
        "full_cifar10_resnet18": is_full,
        "accuracy_gate": args.accuracy_gate,
        "allow_low_accuracy": bool(args.allow_low_accuracy),
        "checkpoint_policy": {
            "local_checkpoint_dir": args.checkpoint_dir,
            "external_uri": args.checkpoint_uri,
            "external_sha256": args.checkpoint_sha256,
            "saved_by_default": bool(is_full and not args.no_save_checkpoint),
        },
        "layer_selection_policy": {
            "selected": str(args.layers),
            "recommended_for_claims": ["last_block", "last_two_blocks", "all_blocks"],
            "smoke_or_overhead_only": ["all_conv"],
        },
        "pretrained_policy": {
            "imagenet_pretrained_enabled": False,
            "transfer_label_if_added": "transfer_resnet18",
        },
    }


def _write_demo_warning(outdir: str) -> None:
    msg = (
        "WARNING: --preset demo is for source-checkout smoke runs only. "
        "It uses short training/evaluation defaults and its OOD tables are not "
        "paper-comparable benchmark claims."
    )
    print(msg, file=sys.stderr, flush=True)
    with contextlib.suppress(Exception):
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, "DEMO_MODE.txt"), "w", encoding="utf-8") as f:
            f.write(msg + "\n")


def _augment_meta(path: str, **updates: Any) -> None:
    meta = _read_json_file(path)
    meta.update(updates)
    _write_json_file(path, meta)


def _main(argv: list[str] | None = None) -> None:  # pragma: no cover - manual use
    argv = list(sys.argv[1:] if argv is None else argv)
    config_path = _preparse_config_path(argv)
    config = _load_json_config(config_path)
    config_defaults, config_attrs = _config_cli_defaults(config)

    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--config",
        type=str,
        default=config_path,
        help="JSON benchmark config; CLI flags override values under config['cli']",
    )
    p.add_argument(
        "--preset",
        type=str,
        choices=PRESET_CHOICES,
        default=PRESET_DEMO,
        help=(
            "Run preset: demo is a short smoke path with non-claim defaults; "
            "full_cifar10_resnet18 uses long from-scratch CIFAR-10 defaults "
            "and an accuracy gate"
        ),
    )
    p.add_argument(
        "--backbone",
        type=str,
        choices=["cifar_resnet18_from_scratch"],
        default="cifar_resnet18_from_scratch",
        help="Backbone policy label; ImageNet transfer is intentionally not enabled here",
    )
    p.add_argument(
        "--data-root", type=str, default="./data", help="Dataset root for torchvision downloads"
    )
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--seeds", type=int, nargs="*", default=None)
    p.add_argument("--batch-size", type=int, default=None)
    p.add_argument("--epochs", type=int, default=None, help="Training epochs")
    p.add_argument(
        "--outdir", type=str, default=None, help="Output directory (default under runs/) "
    )
    p.add_argument(
        "--layers",
        type=str,
        default=None,
        help=(
            "Layer selection for Nervecode (e.g., last_block, last_two_blocks, "
            "all_blocks, all_conv, first_conv)"
        ),
    )
    p.add_argument(
        "--agg",
        type=str,
        default="max",
        choices=["mean", "max"],
        help="Layer aggregator for Nervecode",
    )
    p.add_argument("--K", type=int, default=16)
    p.add_argument("--coding-dim", type=int, default=8)
    p.add_argument("--beta-length", type=float, default=1.0)
    p.add_argument("--beta-entropy", type=float, default=1.0)
    p.add_argument("--beta-distance", type=float, default=1.0)
    p.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="Assignment temperature for CodingConv2d/Linear",
    )
    p.add_argument(
        "--limit-eval",
        type=int,
        default=None,
        help="Limit number of samples per split for evaluation (to speed up runs)",
    )
    p.add_argument(
        "--accuracy-gate",
        type=float,
        default=None,
        help=(
            "Minimum CIFAR-10 ID test accuracy required before OOD reporting; "
            "full_cifar10_resnet18 defaults to 0.93"
        ),
    )
    p.add_argument(
        "--allow-low-accuracy",
        action="store_true",
        help="Continue and label outputs even when the accuracy gate fails",
    )
    p.add_argument(
        "--verbose", action="store_true", help="Print progress while training and scoring"
    )
    # Baseline toggles
    p.add_argument("--no-msp", action="store_true", help="Skip MSP baseline")
    p.add_argument("--no-energy", action="store_true", help="Skip Energy baseline")
    p.add_argument("--no-maxlogit", action="store_true", help="Skip MaxLogit baseline")
    p.add_argument("--no-gen", action="store_true", help="Skip GEN baseline")
    p.add_argument("--gen-gamma", type=float, default=0.1, help="GEN gamma exponent")
    p.add_argument("--gen-top-m", type=int, default=None, help="Use top-M probabilities for GEN")
    p.add_argument("--no-odin", action="store_true", help="Skip ODIN baseline")
    p.add_argument(
        "--with-odin",
        action="store_true",
        help="Enable ODIN when a preset would otherwise skip it",
    )
    p.add_argument("--no-mahalanobis", action="store_true", help="Skip Mahalanobis baseline")
    p.add_argument("--no-knn", action="store_true", help="Skip KNN-OOD baseline")
    p.add_argument("--knn-k", type=int, default=50, help="KNN-OOD kth neighbor")
    p.add_argument(
        "--knn-chunk-size",
        type=int,
        default=4096,
        help="Query chunk size for KNN-OOD distance computation",
    )
    p.add_argument(
        "--no-residual-vim-lite",
        action="store_true",
        help="Skip Residual/ViM-lite baseline",
    )
    p.add_argument("--no-vim", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--no-nervecode", action="store_true", help="Skip Nervecode scoring")
    p.add_argument(
        "--comb-alpha",
        type=float,
        default=None,
        help=(
            "If set, add fixed energy + alpha * nervecode score; alpha must be "
            "chosen without OOD test data for headline use"
        ),
    )
    p.add_argument(
        "--combo",
        type=str,
        default="id_zscore_equal",
        choices=["none", "id_zscore_equal"],
        help="Headline-safe combo mode fitted only on ID calibration scores",
    )
    p.add_argument(
        "--learn-ood-calibrated-combo",
        action="store_true",
        help=(
            "Learn oracle Energy+Nervecode combiner using evaluated OOD samples; "
            "not valid for headline detector comparisons"
        ),
    )
    p.add_argument(
        "--learn-ood-calibrated-combo3",
        action="store_true",
        help=(
            "Learn oracle Energy+MSP+Nervecode combiner using evaluated OOD samples; "
            "not valid for headline detector comparisons"
        ),
    )
    p.add_argument(
        "--learn-combo",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    p.add_argument(
        "--learn-combo3",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    # Combiner persistence
    p.add_argument(
        "--save-combiner",
        action="store_true",
        help="Persist learned combiner weights to outdir/combiner.json or --combiner-out",
    )
    p.add_argument(
        "--combiner-out", type=str, default=None, help="Explicit path to save learned combiner JSON"
    )
    p.add_argument(
        "--load-combiner",
        type=str,
        default=None,
        help="Load combiner JSON and apply without refitting",
    )
    p.add_argument(
        "--checkpoint-dir",
        type=str,
        default=None,
        help="Directory for local per-seed checkpoints; full preset defaults under outdir",
    )
    p.add_argument(
        "--no-save-checkpoint",
        action="store_true",
        help="Do not save local checkpoints for full_cifar10_resnet18 runs",
    )
    p.add_argument(
        "--checkpoint-uri",
        type=str,
        default=None,
        help="External checkpoint URI to record in run metadata, if used",
    )
    p.add_argument(
        "--checkpoint-sha256",
        type=str,
        default=None,
        help="External checkpoint SHA-256 to record in run metadata, if used",
    )
    if config_defaults:
        p.set_defaults(**config_defaults)
    args = p.parse_args(argv)
    _apply_preset_defaults(args, argv, explicit_attrs=config_attrs)

    stamp = time.strftime("%Y%m%d-%H%M%S")
    outdir = args.outdir or os.path.join("runs", f"cifar-ood-{stamp}")
    if (
        args.checkpoint_dir is None
        and args.preset == PRESET_FULL_CIFAR10_RESNET18
        and not args.no_save_checkpoint
    ):
        args.checkpoint_dir = os.path.join(outdir, "checkpoints")
    for rel_dir in ("scores", "layerwise", "plots"):
        os.makedirs(os.path.join(outdir, rel_dir), exist_ok=True)
    if args.preset == PRESET_DEMO:
        _write_demo_warning(outdir)
    # Choose default combiner save path under outdir if requested
    combiner_save_path = (
        args.combiner_out
        if args.combiner_out
        else (os.path.join(outdir, "combiner.json") if args.save_combiner else None)
    )
    resolved_config = vars(args).copy()
    resolved_config["outdir"] = outdir
    resolved_config["config_path"] = config_path
    resolved_config["config"] = config
    resolved_config["combiner_save_path"] = combiner_save_path
    resolved_config["score_cache_dir"] = os.path.join(outdir, "scores")
    resolved_config["layerwise_dir"] = os.path.join(outdir, "layerwise")
    resolved_config["checkpoint_manifest_path"] = os.path.join(outdir, "checkpoint_manifest.json")
    resolved_config["dataset_manifest_path"] = os.path.join(outdir, "dataset_manifest.json")
    benchmark_meta = _benchmark_policy_metadata(args)
    if config:
        benchmark_meta["config"] = {key: value for key, value in config.items() if key != "cli"}
    combo_meta: dict[str, Any] = {}
    meta_path = os.path.join(outdir, "meta.json")
    try:
        from benchmarks.ood.runmeta import build_run_metadata, combo_provenance, write_json

        if args.combo == "id_zscore_equal":
            combo_meta["default"] = combo_provenance(
                "id_zscore_equal", components=["energy", "mahalanobis", "nervecode"]
            )
        if args.learn_ood_calibrated_combo or args.learn_combo:
            combo_meta["oracle_lr"] = combo_provenance(
                "ood_calibrated", components=["energy", "nervecode"]
            )
        if args.learn_ood_calibrated_combo3 or args.learn_combo3:
            combo_meta["oracle_lr3"] = combo_provenance(
                "ood_calibrated", components=["energy", "msp", "nervecode"]
            )
        write_json(os.path.join(outdir, "resolved_config.json"), resolved_config)
        write_json(
            meta_path,
            build_run_metadata(
                command=[sys.argv[0], *argv],
                resolved_config=resolved_config,
                dataset_root=args.data_root,
                combo=combo_meta,
                benchmark=benchmark_meta,
            ),
        )
    except Exception:
        pass

    checkpoint_manifest_path = os.path.join(outdir, "checkpoint_manifest.json")
    dataset_manifest_path = os.path.join(outdir, "dataset_manifest.json")
    try:
        rows = run(
            data_root=args.data_root,
            device=args.device,
            seeds=args.seeds,
            batch_size=args.batch_size,
            epochs=args.epochs,
            layers=args.layers,
            agg=args.agg,
            K=args.K,
            coding_dim=args.coding_dim,
            beta_length=args.beta_length,
            beta_entropy=args.beta_entropy,
            beta_distance=args.beta_distance,
            temperature=args.temperature,
            limit_eval=args.limit_eval,
            verbose=bool(args.verbose),
            no_msp=bool(args.no_msp),
            no_energy=bool(args.no_energy),
            no_maxlogit=bool(args.no_maxlogit),
            no_gen=bool(args.no_gen),
            gen_gamma=float(args.gen_gamma),
            gen_top_m=args.gen_top_m,
            no_odin=bool(args.no_odin),
            no_mahalanobis=bool(args.no_mahalanobis),
            no_knn=bool(args.no_knn),
            knn_k=int(args.knn_k),
            knn_chunk_size=int(args.knn_chunk_size),
            no_residual_vim_lite=bool(args.no_residual_vim_lite),
            no_vim=bool(args.no_vim),
            no_nervecode=bool(args.no_nervecode),
            combo=args.combo,
            learn_combo=bool(args.learn_combo),
            learn_combo3=bool(args.learn_combo3),
            learn_ood_calibrated_combo=bool(args.learn_ood_calibrated_combo),
            learn_ood_calibrated_combo3=bool(args.learn_ood_calibrated_combo3),
            comb_alpha=args.comb_alpha,
            combiner_save_path=combiner_save_path,
            combiner_load_path=args.load_combiner,
            score_cache_dir=os.path.join(outdir, "scores"),
            layerwise_dir=os.path.join(outdir, "layerwise"),
            dataset_manifest_path=dataset_manifest_path,
            preset=str(args.preset),
            accuracy_gate=args.accuracy_gate,
            allow_low_accuracy=bool(args.allow_low_accuracy),
            checkpoint_dir=args.checkpoint_dir,
            checkpoint_manifest_path=checkpoint_manifest_path,
        )
    except Exception:
        _augment_meta(
            meta_path,
            checkpoint_manifest=_read_json_file(checkpoint_manifest_path),
            dataset_manifest=_read_json_file(dataset_manifest_path),
        )
        raise
    _write_results(rows, outdir)
    _augment_meta(
        meta_path,
        checkpoint_manifest=_read_json_file(checkpoint_manifest_path),
        dataset_manifest=_read_json_file(dataset_manifest_path),
    )
    # Plot real layerwise artifacts saved during this benchmark run.
    try:
        from nervecode.viz.layerwise import plot_layerwise_artifacts

        ood_names = sorted({row.ood_name for row in rows})
        if ood_names and args.seeds:
            plot_layerwise_artifacts(
                outdir,
                seed=int(args.seeds[0]),
                ood_names=ood_names[:3],
                output_path=os.path.join(outdir, "plots", "layerwise.png"),
            )
    except Exception:
        pass


if __name__ == "__main__":  # pragma: no cover - manual use
    _main()
