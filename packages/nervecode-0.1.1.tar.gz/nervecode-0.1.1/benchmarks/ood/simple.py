"""Minimal OOD benchmark: MLP on 2D Gaussians with synthetic OOD.

Trains a tiny MLP, instruments it with Nervecode wrappers, calibrates
empirical percentiles on in-distribution samples, and evaluates aggregated
surprise separation between held-out in-distribution and shifted OOD samples.

Outputs AUROC and a concise text summary; optionally emits JSON via --json.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class OodResult:
    auroc: float
    id_mean: float
    ood_mean: float
    id_p50: float
    ood_p50: float
    id_p95: float
    ood_p95: float
    id_ood_rate_at_q: float
    ood_ood_rate_at_q: float
    quantile: float


def _make_datasets(n_total: int = 2048, *, seed: int = 123) -> tuple[Any, Any, Any, Any]:
    import torch
    from torch.utils.data import DataLoader, Dataset, random_split

    class ToyGaussianDataset(Dataset[tuple[Any, Any]]):
        def __init__(self, n: int, *, seed: int, mean: float = 1.0) -> None:
            g = torch.Generator(device="cpu").manual_seed(int(seed))
            x0 = torch.randn(n // 2, 2, generator=g) * 0.6 + torch.tensor([-mean, -mean])
            x1 = torch.randn(n - n // 2, 2, generator=g) * 0.6 + torch.tensor([+mean, +mean])
            y0 = torch.zeros(x0.shape[0], dtype=torch.long)
            y1 = torch.ones(x1.shape[0], dtype=torch.long)
            self.x = torch.cat([x0, x1], dim=0)
            self.y = torch.cat([y0, y1], dim=0)
            perm = torch.randperm(self.x.shape[0], generator=g)
            self.x = self.x[perm]
            self.y = self.y[perm]

        def __len__(self) -> int:
            return int(self.x.shape[0])

        def __getitem__(self, idx: int) -> tuple[Any, Any]:
            return self.x[idx], self.y[idx]

    # In-distribution
    ds = ToyGaussianDataset(n_total, seed=seed, mean=1.0)
    calib_len = n_total // 4
    test_len = n_total // 4
    train_len = len(ds) - calib_len - test_len
    train, calib, test = random_split(ds, [train_len, calib_len, test_len])

    # Simple OOD: larger separation (mean=2.5) to push surprise higher
    ood = ToyGaussianDataset(test_len, seed=seed + 999, mean=2.5)

    def _mk(d: Any) -> Any:
        return DataLoader(d, batch_size=128, shuffle=True)

    return _mk(train), _mk(calib), _mk(test), _mk(ood)


def _build_model() -> Any:
    from torch import nn

    class TinyMLP(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(2, 32),
                nn.ReLU(),
                nn.Linear(32, 2),
            )

        def forward(self, x: Any) -> Any:
            return self.net(x)

    return TinyMLP()


def _auroc(scores: Any, labels: Any) -> float:
    """Compute AUROC for higher-is-more-OOD scores vs {0=id,1=ood} labels."""
    import torch

    s = scores.detach().to(device="cpu", dtype=torch.float32).reshape(-1)
    y = labels.detach().to(device="cpu", dtype=torch.long).reshape(-1)
    # Sort scores descending; compute TPR/FPR by sweeping unique thresholds
    order = torch.argsort(s, descending=True)
    y_sorted = y[order]
    P = float((y_sorted == 1).sum().item())
    N = float((y_sorted == 0).sum().item())
    if P == 0.0 or N == 0.0:
        return float("nan")

    # Cumulative positives/negatives as threshold moves
    tps = torch.cumsum((y_sorted == 1).to(torch.float32), dim=0)
    fps = torch.cumsum((y_sorted == 0).to(torch.float32), dim=0)
    tpr = tps / P
    fpr = fps / N
    # Add (0,0) and (1,1) endpoints for trapezoid integration
    z = torch.zeros(1, dtype=torch.float32)
    o = torch.ones(1, dtype=torch.float32)
    fpr_full = torch.cat([z, fpr, o])
    tpr_full = torch.cat([z, tpr, o])
    # Trapezoidal area under ROC curve
    dfpr = fpr_full[1:] - fpr_full[:-1]
    tpr_mid = 0.5 * (tpr_full[1:] + tpr_full[:-1])
    auc = float((dfpr * tpr_mid).sum().item())
    return auc


def run(
    seed: int = 123,
    epochs: int = 3,
    quantile: float = 0.95,
    device: str = "cpu",
    *,
    agg_method: str = "mean",
    layers: str = "all_linear",
    K: int = 16,
    coding_dim: str = "auto",
    beta_length: float = 1.0,
    beta_entropy: float = 1.0,
    beta_distance: float = 0.0,
    temperature: float | None = None,
    invert_score: bool = False,
) -> OodResult:
    import torch
    from nervecode import WrappedModel
    from nervecode.layers.linear import CodingLinear
    from nervecode.layers.wrap import wrap as wrap_layers
    from nervecode.scoring import EmpiricalPercentileCalibrator, max_surprise, mean_surprise
    from torch import nn

    train, calib, test, ood = _make_datasets(2048, seed=seed)
    model = _build_model().to(device)
    # Instrument model with configured parameters
    kd: int | None
    if str(coding_dim).lower() == "auto":
        kd = None
    else:
        try:
            kd = int(coding_dim)
        except Exception:
            kd = None
    wrap_layers(
        model,
        layers=layers,
        K=int(K),
        coding_dim=kd,
        temperature=float(temperature) if temperature is not None else 1.0,
    )
    wrapped = WrappedModel(model)

    opt = torch.optim.Adam(model.parameters(), lr=1e-2)
    ce = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        for xb, yb in train:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            logits = wrapped.forward(xb)
            from typing import cast

            loss = ce(logits, yb) + 0.1 * cast(torch.Tensor, wrapped.coding_loss())
            loss.backward()
            opt.step()

    # Optionally tweak assignment weights on wrapped layers
    for m in model.modules():
        if isinstance(m, CodingLinear):
            try:
                m.assignment.beta_length = float(beta_length)
                m.assignment.beta_entropy = float(beta_entropy)
                # Optional distance component in combined surprise
                if hasattr(m.assignment, "beta_distance"):
                    m.assignment.beta_distance = float(beta_distance)
                if temperature is not None:
                    # update temperature buffer in-place
                    m.assignment._temperature = torch.tensor(float(temperature))
            except Exception:
                pass

    # Calibrate on in-distribution
    calib_scores = []
    with torch.no_grad():
        for xb, _ in calib:
            xb = xb.to(device)
            _ = wrapped.forward(xb)
            traces = getattr(wrapped, "_last_layer_traces", {})
            method = str(agg_method).lower()
            agg_obj = max_surprise(traces) if method == "max" else mean_surprise(traces)
            if agg_obj is not None:
                s = agg_obj.surprise.detach().to("cpu").reshape(-1)
                if invert_score:
                    s = -s
                calib_scores.append(s)
    s_calib = torch.cat(calib_scores, dim=0)
    calibrator = EmpiricalPercentileCalibrator(threshold_quantiles=(quantile,))
    calibrator.fit(s_calib, aggregation="mean")

    # Evaluate on held-out ID and OOD
    def _collect(dl: Any) -> Any:
        vals = []
        with torch.no_grad():
            for xb, _ in dl:
                xb = xb.to(device)
                _ = wrapped.forward(xb)
                traces = getattr(wrapped, "_last_layer_traces", {})
                method = str(agg_method).lower()
                agg_obj = max_surprise(traces) if method == "max" else mean_surprise(traces)
                if agg_obj is not None:
                    s = agg_obj.surprise.detach().to("cpu").reshape(-1)
                    if invert_score:
                        s = -s
                    vals.append(s)
        return torch.cat(vals, dim=0)

    s_id = _collect(test)
    s_ood = _collect(ood)

    # AUROC where higher surprise indicates OOD
    labels = torch.cat(
        [torch.zeros_like(s_id, dtype=torch.long), torch.ones_like(s_ood, dtype=torch.long)], dim=0
    )
    scores = torch.cat([s_id, s_ood], dim=0)
    auc = _auroc(scores, labels)

    # Distribution diagnostics to confirm score orientation
    def _q(x: Any, q: float) -> float:
        try:
            return float(torch.quantile(x, torch.tensor(float(q))).item())
        except Exception:
            # Fallback for older torch without quantile
            m = torch.kthvalue(x.reshape(-1), max(1, round((x.numel() - 1) * float(q)) + 1)).values
            return float(m.item())

    id_mean_v = float(s_id.mean().item())
    ood_mean_v = float(s_ood.mean().item())
    id_p50_v = float(torch.median(s_id).item())
    ood_p50_v = float(torch.median(s_ood).item())
    id_p95_v = _q(s_id, 0.95)
    ood_p95_v = _q(s_ood, 0.95)

    mask_id = calibrator.is_ood(s_id)
    mask_ood = calibrator.is_ood(s_ood)
    res = OodResult(
        auroc=float(auc),
        id_mean=id_mean_v,
        ood_mean=ood_mean_v,
        id_p50=id_p50_v,
        ood_p50=ood_p50_v,
        id_p95=id_p95_v,
        ood_p95=ood_p95_v,
        id_ood_rate_at_q=float(mask_id.float().mean().item()),
        ood_ood_rate_at_q=float(mask_ood.float().mean().item()),
        quantile=float(quantile),
    )
    return res


def _main() -> None:  # pragma: no cover - manual use
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--epochs", type=int, default=3, help="Training epochs")
    p.add_argument("--seed", type=int, default=123, help="Random seed")
    p.add_argument("--quantile", type=float, default=0.95, help="Calibration quantile")
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    p.add_argument(
        "--agg", type=str, default="mean", choices=["mean", "max"], help="Layer aggregator"
    )
    p.add_argument(
        "--layers",
        type=str,
        default="all_linear",
        help="Layer selection (e.g., all_linear, first_linear)",
    )
    p.add_argument("--K", type=int, default=16, help="Codebook size K")
    p.add_argument("--coding-dim", type=str, default="auto", help="Coding dimension D or 'auto'")
    p.add_argument(
        "--beta-length",
        type=float,
        default=1.0,
        help="Weight for best-code length in combined surprise",
    )
    p.add_argument(
        "--beta-entropy", type=float, default=1.0, help="Weight for entropy in combined surprise"
    )
    p.add_argument(
        "--beta-distance", type=float, default=0.0, help="Weight for distance in combined surprise"
    )
    p.add_argument("--temperature", type=float, default=None, help="Assignment temperature")
    p.add_argument(
        "--invert-score", action="store_true", help="Negate surprise before AUROC/threshold"
    )
    p.add_argument("--json", action="store_true", help="Emit JSON summary as well")
    args = p.parse_args()

    res = run(
        seed=args.seed,
        epochs=args.epochs,
        quantile=args.quantile,
        device=args.device,
        agg_method=args.agg,
        layers=args.layers,
        K=args.K,
        coding_dim=args.coding_dim,
        beta_length=args.beta_length,
        beta_entropy=args.beta_entropy,
        beta_distance=args.beta_distance,
        temperature=args.temperature,
        invert_score=bool(args.invert_score),
    )
    print(
        f"AUROC={res.auroc:.3f} ID_mean={res.id_mean:.4f} OOD_mean={res.ood_mean:.4f} "
        f"ID@q={res.id_ood_rate_at_q:.3f} OOD@q={res.ood_ood_rate_at_q:.3f} q={res.quantile:.2f}"
    )
    if args.json:
        print(json.dumps(asdict(res)))


if __name__ == "__main__":  # pragma: no cover - manual use
    _main()
