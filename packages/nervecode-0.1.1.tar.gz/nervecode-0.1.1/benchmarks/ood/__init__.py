"""Simple OOD benchmark harness.

This package contains a minimal, dependency-light benchmark that trains a small
model, calibrates aggregated surprise on in-distribution data, and measures
separation between in-distribution and out-of-distribution samples via AUROC.
"""

__all__: list[str] = []
