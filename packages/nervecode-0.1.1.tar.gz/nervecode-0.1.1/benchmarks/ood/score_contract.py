"""Score-orientation contract for OOD benchmark outputs.

Every benchmark score emitted by this package follows one convention:

    higher score = more OOD-like

The helpers here keep that convention explicit in validation metadata and make
shape or NaN/Inf mistakes fail before metrics are computed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

HIGHER_IS_OOD = True


@dataclass(frozen=True)
class ScoreMetadata:
    """Small metadata record attached to score vectors and run outputs."""

    name: str
    higher_is_ood: bool = HIGHER_IS_OOD
    split: str | None = None
    fitted_on: str | None = None
    provenance: str | None = None

    def as_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "name": self.name,
            "higher_is_ood": bool(self.higher_is_ood),
        }
        if self.split is not None:
            out["split"] = self.split
        if self.fitted_on is not None:
            out["fitted_on"] = self.fitted_on
        if self.provenance is not None:
            out["provenance"] = self.provenance
        return out


def orientation_metadata() -> dict[str, bool]:
    """Return the benchmark-wide score orientation metadata."""

    return {"higher_is_ood": HIGHER_IS_OOD}


def validate_ood_scores(
    scores: Any,
    *,
    name: str = "score",
    expected_len: int | None = None,
    allow_empty: bool = False,
) -> Any:
    """Validate and return a 1D CPU float tensor of OOD-oriented scores.

    Parameters
    - scores: tensor-like score vector.
    - name: human-readable score name used in error messages.
    - expected_len: optional exact vector length.
    - allow_empty: allow a zero-length vector when a split is legitimately empty.
    """

    try:
        import torch
    except Exception as exc:  # pragma: no cover - benchmark dependency
        raise RuntimeError("score validation requires PyTorch") from exc

    vec = torch.as_tensor(scores).detach()
    if vec.ndim != 1:
        raise ValueError(f"{name} scores must be a 1D vector, got shape {tuple(vec.shape)}")
    if vec.numel() == 0 and not allow_empty:
        raise ValueError(f"{name} scores must not be empty")
    if expected_len is not None and int(vec.numel()) != int(expected_len):
        raise ValueError(
            f"{name} scores must have length {int(expected_len)}, got {int(vec.numel())}"
        )

    vec = vec.to(device="cpu", dtype=torch.float32).contiguous()
    if vec.numel() and not torch.isfinite(vec).all().item():
        raise ValueError(f"{name} scores contain NaN or Inf")
    return vec


def score_metadata(
    name: str,
    *,
    split: str | None = None,
    fitted_on: str | None = None,
    provenance: str | None = None,
) -> dict[str, Any]:
    """Build JSON-serializable metadata for an OOD-oriented score vector."""

    return ScoreMetadata(
        name=str(name),
        higher_is_ood=HIGHER_IS_OOD,
        split=split,
        fitted_on=fitted_on,
        provenance=provenance,
    ).as_dict()
