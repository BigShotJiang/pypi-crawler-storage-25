"""OOD baseline scorers under the benchmark score contract."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .score_contract import score_metadata, validate_ood_scores


def _as_2d_float(x: Any, *, name: str) -> Any:
    import torch

    t = torch.as_tensor(x).detach().to(device="cpu", dtype=torch.float32)
    if t.ndim != 2:
        raise ValueError(f"{name} must be a 2D tensor, got shape {tuple(t.shape)}")
    if not torch.isfinite(t).all().item():
        raise ValueError(f"{name} contains NaN or Inf")
    return t


def msp_score(logits: Any) -> Any:
    """Maximum softmax probability baseline, OOD-oriented as ``1 - confidence``."""

    import torch

    z = _as_2d_float(logits, name="logits")
    confidence = torch.softmax(z, dim=-1).max(dim=-1).values
    return validate_ood_scores(1.0 - confidence, name="msp")


def energy_score(logits: Any, *, temperature: float = 1.0) -> Any:
    """Energy score where larger/less-negative values are more OOD-like."""

    import torch

    temp = float(temperature)
    if temp <= 0.0:
        raise ValueError("temperature must be > 0")
    z = _as_2d_float(logits, name="logits") / temp
    score = -temp * torch.logsumexp(z, dim=-1)
    return validate_ood_scores(score, name="energy")


def maxlogit_score(logits: Any) -> Any:
    """MaxLogit baseline under higher-is-OOD orientation."""

    z = _as_2d_float(logits, name="logits")
    return validate_ood_scores(-z.max(dim=-1).values, name="maxlogit")


def gen_score(logits: Any, *, gamma: float = 0.1, top_m: int | None = None) -> Any:
    """GEN uncertainty score, using the positive OOD-oriented uncertainty form."""

    import torch

    g = float(gamma)
    if g <= 0.0:
        raise ValueError("gamma must be > 0")
    probs = torch.softmax(_as_2d_float(logits, name="logits"), dim=-1)
    sorted_probs = torch.sort(probs, dim=-1, descending=True).values
    if top_m is not None:
        m = max(1, min(int(top_m), int(sorted_probs.shape[-1])))
        sorted_probs = sorted_probs[:, :m]
    score = (sorted_probs.pow(g) * (1.0 - sorted_probs).pow(g)).sum(dim=-1)
    return validate_ood_scores(score, name="gen")


def fit_mahalanobis(feats: Any, labels: Any, *, shrink: float = 0.01) -> tuple[Any, Any, Any]:
    """Fit class means and shared inverse covariance on ID-train features."""

    import torch

    x = _as_2d_float(feats, name="features")
    y = torch.as_tensor(labels).detach().to(device="cpu", dtype=torch.long).reshape(-1)
    if int(y.numel()) != int(x.shape[0]):
        raise ValueError("labels length must match feature rows")
    classes = torch.unique(y, sorted=True)
    if int(classes.numel()) == 0:
        raise ValueError("at least one class is required")

    means: list[Any] = []
    centered_chunks: list[Any] = []
    for c in classes:
        xc = x[y == c]
        if int(xc.shape[0]) == 0:
            continue
        mu_c = xc.mean(dim=0, keepdim=True)
        means.append(mu_c)
        centered_chunks.append(xc - mu_c)
    if not means:
        raise ValueError("no class features available")

    mu = torch.cat(means, dim=0)
    centered = torch.cat(centered_chunks, dim=0)
    denom = max(1, int(centered.shape[0]) - 1)
    cov = (centered.T @ centered) / float(denom)
    cov = cov + float(shrink) * torch.eye(cov.shape[0], dtype=cov.dtype)
    inv = torch.linalg.pinv(cov)
    return mu, inv, cov


def mahalanobis_score(feats: Any, class_means: Any, inv_cov: Any) -> Any:
    """Minimum class Mahalanobis distance, OOD-oriented as larger distance."""

    import torch

    x = _as_2d_float(feats, name="features")
    mu = _as_2d_float(class_means, name="class_means")
    inv = _as_2d_float(inv_cov, name="inv_cov")
    diffs = x.unsqueeze(1) - mu.unsqueeze(0)
    left = torch.einsum("ncd,dd->ncd", diffs, inv)
    d2 = (left * diffs).sum(dim=-1).min(dim=1).values
    return validate_ood_scores(d2, name="mahalanobis")


def knn_ood_score(
    train_features: Any,
    query_features: Any,
    *,
    k: int = 50,
    chunk_size: int = 4096,
    normalize: bool = True,
) -> Any:
    """KNN-OOD score: distance to the kth nearest ID-train feature."""

    import torch
    from torch.nn import functional as F

    train = _as_2d_float(train_features, name="train_features")
    query = _as_2d_float(query_features, name="query_features")
    if normalize:
        train = F.normalize(train, p=2, dim=-1)
        query = F.normalize(query, p=2, dim=-1)
    kth = max(1, min(int(k), int(train.shape[0])))
    chunk = max(1, int(chunk_size))
    out: list[Any] = []
    for start in range(0, int(query.shape[0]), chunk):
        q = query[start : start + chunk]
        distances = torch.cdist(q, train, p=2)
        vals = torch.topk(distances, k=kth, dim=-1, largest=False).values[:, -1]
        out.append(vals)
    score = torch.cat(out, dim=0) if out else torch.empty(0, dtype=torch.float32)
    return validate_ood_scores(score, name="knn")


def nervecode_surprise_score(traces: Any, *, aggregation: str = "mean") -> Any:
    """Extract a Nervecode aggregated surprise vector and validate orientation."""

    method = str(aggregation).lower()
    from nervecode.scoring import max_surprise, mean_surprise

    agg = max_surprise(traces) if method == "max" else mean_surprise(traces)
    if agg is None:
        raise ValueError("no valid Nervecode surprise scores were produced")
    return validate_ood_scores(agg.surprise, name=f"nervecode_{method}")


def fit_id_zscore_stats(
    calibration_components: Mapping[str, Any],
    *,
    eps: float = 1e-6,
) -> dict[str, dict[str, float]]:
    """Fit per-component z-score stats on ID calibration scores only."""

    stats: dict[str, dict[str, float]] = {}
    for name, values in calibration_components.items():
        vec = validate_ood_scores(values, name=f"{name}_id_calibration")
        std = float(vec.std(unbiased=False).item())
        stats[str(name)] = {
            "mean": float(vec.mean().item()),
            "std": max(std, float(eps)),
        }
    if not stats:
        raise ValueError("at least one calibration component is required")
    return stats


def apply_id_zscore_equal_combo(
    score_components: Mapping[str, Any],
    stats: Mapping[str, Mapping[str, float]],
    *,
    name: str = "combo_id_zscore_equal",
) -> tuple[Any, dict[str, Any]]:
    """Apply ID-calibration z-scores and average components with equal weights."""

    import torch

    z_parts: list[Any] = []
    used: list[str] = []
    expected_len: int | None = None
    for component, st in stats.items():
        if component not in score_components:
            raise KeyError(f"missing score component {component!r}")
        vec = validate_ood_scores(score_components[component], name=str(component))
        if expected_len is None:
            expected_len = int(vec.numel())
        elif int(vec.numel()) != expected_len:
            raise ValueError("all combo score components must have the same length")
        mean = float(st["mean"])
        std = float(st["std"])
        if std <= 0.0:
            raise ValueError(f"component {component!r} has non-positive std")
        z_parts.append((vec - mean) / std)
        used.append(str(component))

    if not z_parts:
        raise ValueError("at least one score component is required")
    combo = torch.stack(z_parts, dim=0).mean(dim=0)
    meta = score_metadata(
        name,
        fitted_on="id_calibration",
        provenance="id_only_zscore_equal_weight",
    )
    meta["components"] = used
    return validate_ood_scores(combo, name=name), meta


def id_zscore_equal_combo(
    calibration_components: Mapping[str, Any],
    score_components: Mapping[str, Any],
    *,
    eps: float = 1e-6,
    name: str = "combo_id_zscore_equal",
) -> tuple[Any, dict[str, Any]]:
    """Fit on ID calibration components and apply an equal-weight combo."""

    stats = fit_id_zscore_stats(calibration_components, eps=eps)
    score, meta = apply_id_zscore_equal_combo(score_components, stats, name=name)
    meta["stats"] = stats
    return score, meta
