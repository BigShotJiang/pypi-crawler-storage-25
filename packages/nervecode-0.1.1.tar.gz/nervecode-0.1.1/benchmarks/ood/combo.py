"""ID-only combo ablations for OOD score vectors."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from itertools import combinations
from typing import Any

from .scores import apply_id_zscore_equal_combo, fit_id_zscore_stats

DEFAULT_COMBO_COMPONENTS: tuple[str, ...] = ("energy", "mahalanobis", "nervecode")
COMPONENT_ABBREVIATIONS: dict[str, str] = {
    "energy": "E",
    "mahalanobis": "M",
    "nervecode": "N",
}


@dataclass(frozen=True)
class ComboScores:
    """Computed ID/OOD score vectors for one combo subset."""

    method: str
    components: tuple[str, ...]
    component_label: str
    id_scores: Any
    ood_scores: Any
    metadata: dict[str, Any]


def component_label(components: Sequence[str]) -> str:
    """Return a compact label such as ``E+M+N`` for component names."""

    return "+".join(COMPONENT_ABBREVIATIONS.get(str(name), str(name)) for name in components)


def combo_method_name(
    components: Sequence[str],
    *,
    full_components: Sequence[str] = DEFAULT_COMBO_COMPONENTS,
) -> str:
    """Return the public method name for a combo subset.

    The full selected component set is the headline-safe default and keeps the
    short method name ``combo_id_zscore_equal``. Proper subsets encode their
    component label for ablation tables.
    """

    subset = tuple(str(name) for name in components)
    full = tuple(str(name) for name in full_components)
    if subset == full:
        return "combo_id_zscore_equal"
    return f"combo_id_zscore_equal_{component_label(subset)}"


def nonempty_component_subsets(
    components: Sequence[str] = DEFAULT_COMBO_COMPONENTS,
) -> tuple[tuple[str, ...], ...]:
    """Return all non-empty component subsets in stable ablation order."""

    ordered = tuple(str(name) for name in components)
    out: list[tuple[str, ...]] = []
    for size in range(1, len(ordered) + 1):
        out.extend(tuple(group) for group in combinations(ordered, size))
    return tuple(out)


def compute_id_zscore_combo_ablation(
    *,
    calibration_components: Mapping[str, Any],
    id_components: Mapping[str, Any],
    ood_components: Mapping[str, Any],
    component_order: Sequence[str] = DEFAULT_COMBO_COMPONENTS,
) -> list[ComboScores]:
    """Compute every available ID-only z-score equal-weight combo subset.

    Normalization statistics are fitted only on ``calibration_components``. OOD
    scores are never used for normalization or weighting.
    """

    available = tuple(
        name
        for name in component_order
        if name in calibration_components and name in id_components and name in ood_components
    )
    rows: list[ComboScores] = []
    for subset in nonempty_component_subsets(available):
        stats = fit_id_zscore_stats({name: calibration_components[name] for name in subset})
        method = combo_method_name(subset, full_components=available)
        id_score, meta = apply_id_zscore_equal_combo(
            {name: id_components[name] for name in subset},
            stats,
            name=method,
        )
        ood_score, _ = apply_id_zscore_equal_combo(
            {name: ood_components[name] for name in subset},
            stats,
            name=method,
        )
        label = component_label(subset)
        meta.update(
            {
                "component_label": label,
                "components": list(subset),
                "fit_splits": {"normalization": "id_calibration", "weights": "fixed_equal"},
                "uses_ood_samples_for_fit": False,
                "allowed_headline_use": True,
            }
        )
        rows.append(
            ComboScores(
                method=method,
                components=tuple(subset),
                component_label=label,
                id_scores=id_score,
                ood_scores=ood_score,
                metadata=meta,
            )
        )
    return rows
