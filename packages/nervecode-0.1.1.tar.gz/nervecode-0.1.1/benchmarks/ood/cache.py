"""Save and load benchmark score-vector artifacts."""

from __future__ import annotations

import json
import os
from typing import Any


def _to_numpy(value: Any) -> Any:
    try:
        import torch

        if isinstance(value, torch.Tensor):
            return value.detach().to(device="cpu").numpy()
    except Exception:
        pass
    return value


def save_score_vectors(
    path: str,
    *,
    scores: Any,
    labels: Any | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Write scores, optional labels, and JSON metadata to an ``.npz`` file."""

    import numpy as np

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    arrays: dict[str, Any] = {"scores": _to_numpy(scores)}
    if labels is not None:
        arrays["labels"] = _to_numpy(labels)
    arrays["metadata_json"] = json.dumps(metadata or {}, sort_keys=True)
    np.savez_compressed(path, **arrays)


def save_component_score_vectors(
    path: str,
    *,
    components: dict[str, Any],
    labels: Any | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Write named score-vector components and JSON metadata to an ``.npz`` file."""

    import numpy as np

    if not components:
        raise ValueError("at least one score component is required")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    arrays: dict[str, Any] = {str(name): _to_numpy(value) for name, value in components.items()}
    if labels is not None:
        arrays["labels"] = _to_numpy(labels)
    arrays["metadata_json"] = json.dumps(metadata or {}, sort_keys=True)
    np.savez_compressed(path, **arrays)


def load_score_vectors(path: str) -> dict[str, Any]:
    """Load a score-vector artifact written by ``save_score_vectors``."""

    import numpy as np

    with np.load(path, allow_pickle=False) as data:
        out: dict[str, Any] = {key: data[key] for key in data.files if key != "metadata_json"}
        raw_meta = str(data["metadata_json"]) if "metadata_json" in data.files else "{}"
        try:
            out["metadata"] = json.loads(raw_meta)
        except json.JSONDecodeError:
            out["metadata"] = {}
        return out
