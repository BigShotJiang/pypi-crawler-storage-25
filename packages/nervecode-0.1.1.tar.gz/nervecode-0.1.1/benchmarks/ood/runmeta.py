"""Run metadata helpers for auditable OOD benchmark outputs."""

from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
from typing import Any

from .score_contract import orientation_metadata


def default_split_usage() -> dict[str, str]:
    """Return the split discipline used for benchmark claims."""

    return {
        "id_train": "ID train: train classifier; fit Mahalanobis/KNN/feature statistics",
        "id_calibration": (
            "ID calibration: fit score normalization, thresholds, and Nervecode calibration"
        ),
        "id_test": "ID test: metric evaluation only",
        "ood_test": "OOD test: metric evaluation only",
    }


def combo_provenance(kind: str, *, components: list[str] | None = None) -> dict[str, Any]:
    """Return metadata describing whether a combo is headline-safe."""

    if kind == "id_zscore_equal":
        return {
            "label": "combo_id_zscore_equal",
            "allowed_headline_use": True,
            "fit_splits": {"normalization": "id_calibration", "weights": "fixed_equal"},
            "uses_ood_samples_for_fit": False,
            "components": components or [],
        }
    if kind == "ood_calibrated":
        return {
            "label": "oracle_ood_calibrated_combo",
            "allowed_headline_use": False,
            "fit_splits": {"weights": "id_calibration + evaluated_ood_test_subset"},
            "uses_ood_samples_for_fit": True,
            "components": components or [],
        }
    return {
        "label": str(kind),
        "allowed_headline_use": False,
        "fit_splits": {},
        "uses_ood_samples_for_fit": None,
        "components": components or [],
    }


def git_metadata() -> dict[str, Any]:
    """Best-effort git commit and dirty-state metadata."""

    def _run(args: list[str]) -> str | None:
        try:
            proc = subprocess.run(args, capture_output=True, text=True, check=False)
        except Exception:
            return None
        if proc.returncode != 0:
            return None
        return proc.stdout.strip()

    commit = _run(["git", "rev-parse", "HEAD"])
    status = _run(["git", "status", "--short"])
    return {
        "commit": commit,
        "dirty": bool(status),
    }


def environment_metadata() -> dict[str, Any]:
    """Best-effort Python/library/platform metadata."""

    versions: dict[str, Any] = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
    }
    for module_name in ("torch", "torchvision", "numpy"):
        try:
            mod = __import__(module_name)
            versions[module_name] = getattr(mod, "__version__", "unknown")
        except Exception:
            versions[module_name] = None

    try:
        import nervecode

        versions["nervecode"] = getattr(nervecode, "__version__", None)
    except Exception:
        versions["nervecode"] = None

    try:
        import torch

        versions["cuda_available"] = bool(torch.cuda.is_available())
        versions["cuda_version"] = getattr(torch.version, "cuda", None)
        if torch.cuda.is_available():
            versions["gpu"] = torch.cuda.get_device_name(0)
    except Exception:
        versions["cuda_available"] = None

    return versions


def build_run_metadata(
    *,
    command: list[str] | None = None,
    resolved_config: dict[str, Any] | None = None,
    dataset_root: str | None = None,
    combo: dict[str, Any] | None = None,
    benchmark: dict[str, Any] | None = None,
    checkpoint_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a JSON-serializable metadata document for an OOD run."""

    metadata = {
        "schema": {"kind": "nervecode_ood_run", "version": 1},
        "git": git_metadata(),
        "environment": environment_metadata(),
        "command": command or sys.argv,
        "resolved_config": resolved_config or {},
        "dataset_root": dataset_root,
        "score_orientation": orientation_metadata(),
        "split_usage": default_split_usage(),
        "combo_provenance": combo or {},
    }
    if benchmark is not None:
        metadata["benchmark"] = benchmark
    if checkpoint_manifest is not None:
        metadata["checkpoint_manifest"] = checkpoint_manifest
    return metadata


def write_json(path: str, data: dict[str, Any]) -> None:
    """Write deterministic pretty JSON."""

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
        f.write("\n")
