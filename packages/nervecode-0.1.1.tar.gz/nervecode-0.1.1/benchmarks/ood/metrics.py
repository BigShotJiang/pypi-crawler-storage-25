"""OOD metrics under the benchmark score contract."""

from __future__ import annotations

from typing import Any

from .score_contract import validate_ood_scores


def binary_labels_for_scores(id_scores: Any, ood_scores: Any) -> Any:
    """Return labels where 0 = ID and 1 = OOD."""

    import torch

    id_vec = validate_ood_scores(id_scores, name="id")
    ood_vec = validate_ood_scores(ood_scores, name="ood")
    return torch.cat(
        [
            torch.zeros(id_vec.numel(), dtype=torch.long),
            torch.ones(ood_vec.numel(), dtype=torch.long),
        ],
        dim=0,
    )


def auroc(scores: Any, labels: Any) -> float:
    """Compute AUROC for higher-is-more-OOD scores and {0=id, 1=ood} labels."""

    import torch

    s = validate_ood_scores(scores, name="auroc")
    y = torch.as_tensor(labels).detach().to(device="cpu", dtype=torch.long).reshape(-1)
    if int(y.numel()) != int(s.numel()):
        raise ValueError(
            f"labels length {int(y.numel())} does not match scores length {int(s.numel())}"
        )

    order = torch.argsort(s, descending=True)
    y_sorted = y[order]
    positives = float((y_sorted == 1).sum().item())
    negatives = float((y_sorted == 0).sum().item())
    if positives == 0.0 or negatives == 0.0:
        return float("nan")

    tps = torch.cumsum((y_sorted == 1).to(torch.float32), dim=0)
    fps = torch.cumsum((y_sorted == 0).to(torch.float32), dim=0)
    tpr = tps / positives
    fpr = fps / negatives

    zero = torch.zeros(1, dtype=torch.float32)
    one = torch.ones(1, dtype=torch.float32)
    fpr_full = torch.cat([zero, fpr, one])
    tpr_full = torch.cat([zero, tpr, one])
    dfpr = fpr_full[1:] - fpr_full[:-1]
    tpr_mid = 0.5 * (tpr_full[1:] + tpr_full[:-1])
    return float((dfpr * tpr_mid).sum().item())


def aupr_out(scores: Any, labels: Any) -> float:
    """Compute area under the precision-recall curve treating OOD as positive."""

    import torch

    s = validate_ood_scores(scores, name="aupr_out")
    y = torch.as_tensor(labels).detach().to(device="cpu", dtype=torch.long).reshape(-1)
    if int(y.numel()) != int(s.numel()):
        raise ValueError(
            f"labels length {int(y.numel())} does not match scores length {int(s.numel())}"
        )

    order = torch.argsort(s, descending=True)
    y_sorted = y[order]
    positives = float((y_sorted == 1).sum().item())
    if positives == 0.0:
        return float("nan")

    tp = torch.cumsum((y_sorted == 1).to(torch.float32), dim=0)
    fp = torch.cumsum((y_sorted == 0).to(torch.float32), dim=0)
    recall = tp / positives
    precision = tp / torch.clamp(tp + fp, min=1.0)

    zero = torch.zeros(1, dtype=torch.float32)
    one = torch.ones(1, dtype=torch.float32)
    recall_full = torch.cat([zero, recall, one])
    precision_full = torch.cat([one, precision, precision[-1:].clone()])
    drecall = recall_full[1:] - recall_full[:-1]
    precision_mid = 0.5 * (precision_full[1:] + precision_full[:-1])
    return float((drecall * precision_mid).sum().item())


def fpr_at_tpr(id_scores: Any, ood_scores: Any, *, target_tpr: float = 0.95) -> float:
    """Return ID false-positive rate when OOD TPR reaches ``target_tpr``."""

    import torch

    id_vec = validate_ood_scores(id_scores, name="id")
    ood_vec = validate_ood_scores(ood_scores, name="ood")
    target = float(target_tpr)
    if not (0.0 < target <= 1.0):
        raise ValueError("target_tpr must be in (0, 1]")

    q = 1.0 - target
    threshold = torch.quantile(ood_vec, torch.tensor(q, dtype=torch.float32))
    return float((id_vec > threshold).to(torch.float32).mean().item())
