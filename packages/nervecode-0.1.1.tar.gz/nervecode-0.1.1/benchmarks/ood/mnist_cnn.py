"""MNIST OOD benchmark with a small CNN (CPU-friendly).

ID: MNIST. OOD: FashionMNIST, KMNIST. Baselines: MSP, Energy. Nervecode: last_conv/all_conv.
Reports AUROC, FPR@95TPR, ID accuracy, and latency (ms/sample, includes forward).
"""

from __future__ import annotations

import argparse
import contextlib
import json
import os
import time
from dataclasses import asdict, dataclass
from typing import Any


def _set_seed(seed: int) -> None:
    try:
        import random

        import numpy as np
        import torch

        random.seed(int(seed))
        np.random.seed(int(seed))
        torch.manual_seed(int(seed))
        torch.cuda.manual_seed_all(int(seed))
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass


def _auroc(scores: Any, labels: Any) -> float:
    import torch

    s = scores.detach().to(device="cpu", dtype=torch.float32).reshape(-1)
    y = labels.detach().to(device="cpu", dtype=torch.long).reshape(-1)
    order = torch.argsort(s, descending=True)
    s[order]
    y_sorted = y[order]
    P = float((y_sorted == 1).sum().item())
    N = float((y_sorted == 0).sum().item())
    if P == 0.0 or N == 0.0:
        return float("nan")
    tps = torch.cumsum((y_sorted == 1).to(torch.float32), dim=0)
    fps = torch.cumsum((y_sorted == 0).to(torch.float32), dim=0)
    tpr = tps / P
    fpr = fps / N
    z = torch.zeros(1)
    o = torch.ones(1)
    fpr_full = torch.cat([z, fpr, o])
    tpr_full = torch.cat([z, tpr, o])
    dfpr = fpr_full[1:] - fpr_full[:-1]
    tpr_mid = 0.5 * (tpr_full[1:] + tpr_full[:-1])
    return float((dfpr * tpr_mid).sum().item())


def _fpr_at_tpr(scores_id: Any, scores_ood: Any, *, target_tpr: float = 0.95) -> float:
    import torch

    x_id = torch.as_tensor(scores_id).detach().to("cpu").reshape(-1)
    x_ood = torch.as_tensor(scores_ood).detach().to("cpu").reshape(-1)
    q = 1.0 - float(target_tpr)
    thr = torch.quantile(x_ood, torch.tensor(q, dtype=torch.float32))
    return float((x_id > thr).to(torch.float32).mean().item())


def _build_cnn() -> Any:
    from torch import nn

    class Net(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.features = nn.Sequential(
                nn.Conv2d(1, 32, 3, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, 64, 3, padding=1),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(2),  # 14x14
            )
            self.classifier = nn.Sequential(
                nn.Flatten(),
                nn.Linear(64 * 14 * 14, 128),
                nn.ReLU(inplace=True),
                nn.Linear(128, 10),
            )

        def forward(self, x: Any) -> Any:
            x = self.features(x)
            return self.classifier(x)

    return Net()


def _get_loaders(root: str, *, batch: int = 256) -> tuple[Any, Any, dict[str, Any]]:
    """Return ID loaders and an OOD loader map, skipping OODs that are unavailable.

    Tries local cache first for OOD sets to avoid network; falls back to download
    if possible. Any dataset that still fails is skipped gracefully.
    """
    from torchvision import datasets, transforms

    tf = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])

    # ID (MNIST): allow download so the benchmark can run even if not cached
    id_train = datasets.MNIST(root=root, train=True, transform=tf, download=True)
    id_test = datasets.MNIST(root=root, train=False, transform=tf, download=True)

    def _try(make: Any) -> Any:
        try:
            return make()
        except Exception:
            return None

    # OODs: prefer cache (download=False); if missing, attempt download, else skip
    fmnist = _try(
        lambda: datasets.FashionMNIST(root=root, train=False, transform=tf, download=False)
    )
    if fmnist is None:
        fmnist = _try(
            lambda: datasets.FashionMNIST(root=root, train=False, transform=tf, download=True)
        )
    kmnist = _try(lambda: datasets.KMNIST(root=root, train=False, transform=tf, download=False))
    if kmnist is None:
        kmnist = _try(lambda: datasets.KMNIST(root=root, train=False, transform=tf, download=True))

    from torch.utils.data import DataLoader

    def mk(ds: Any) -> Any:
        return DataLoader(ds, batch_size=batch, shuffle=True)

    ood_map: dict[str, Any] = {}
    if fmnist is not None:
        ood_map["fashionmnist"] = mk(fmnist)
    if kmnist is not None:
        ood_map["kmnist"] = mk(kmnist)
    return mk(id_train), mk(id_test), ood_map


def _train(
    model: Any, loader: Any, *, device: str, epochs: int, wrapped: Any | None, coding_w: float
) -> None:
    import torch
    from torch import nn

    model.to(device)
    opt = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9)
    ce = nn.CrossEntropyLoss()
    model.train()
    for _ in range(int(epochs)):
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            logits = wrapped.forward(xb) if wrapped is not None else model(xb)
            loss = ce(logits, yb)
            if wrapped is not None and coding_w > 0.0:
                with contextlib.suppress(Exception):
                    loss = loss + float(coding_w) * wrapped.coding_loss()
            loss.backward()
            opt.step()


def _accuracy(model: Any, loader: Any, *, device: str) -> float:
    import torch

    model.eval()
    c = 0
    n = 0
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            logits = model(xb)
            c += int((logits.argmax(dim=-1) == yb).sum().item())
            n += int(yb.numel())
    return float(c) / max(1, n)


def _msp(logits: Any) -> Any:
    import torch

    p = torch.softmax(logits, dim=-1)
    conf, _ = p.max(dim=-1)
    return 1.0 - conf


def _energy(logits: Any, *, temperature: float = 1.0) -> Any:
    import torch

    z = logits / float(temperature)
    return -float(temperature) * torch.logsumexp(z, dim=-1)


@dataclass
class ResultRow:
    seed: int
    ood: str
    method: str
    auroc: float
    fpr95: float
    id_acc: float
    latency_ms: float


def run(
    *,
    data_root: str = "./data",
    device: str = "cpu",
    seed: int = 123,
    batch_size: int = 256,
    epochs: int = 5,
    layers: str = "last_conv",
    agg: str = "max",
    K: int = 16,
    coding_dim: int = 8,
    beta_length: float = 1.0,
    beta_entropy: float = 0.0,
    beta_distance: float = 1.0,
    temperature: float = 2.0,
    limit_eval: int | None = 1000,
) -> list[ResultRow]:
    import torch
    from nervecode import WrappedModel
    from nervecode.layers.wrap import wrap as wrap_layers
    from nervecode.scoring import EmpiricalPercentileCalibrator, max_surprise, mean_surprise

    _set_seed(int(seed))
    dl_train, dl_test, ood_map = _get_loaders(data_root, batch=batch_size)

    model = _build_cnn()
    # Instrument
    wrap_layers(model, layers=layers, K=int(K), coding_dim=int(coding_dim))
    wrapped = WrappedModel(model)
    # Apply assignment params
    for m in model.modules():
        try:
            from nervecode.layers.conv import CodingConv2d
            from nervecode.layers.linear import CodingLinear

            if isinstance(m, (CodingConv2d, CodingLinear)):
                m.assignment.beta_length = float(beta_length)
                m.assignment.beta_entropy = float(beta_entropy)
                if hasattr(m.assignment, "beta_distance"):
                    m.assignment.beta_distance = float(beta_distance)
                # temp
                import torch as _torch

                m.assignment._temperature = _torch.tensor(float(temperature))
        except Exception:
            pass

    _train(model, dl_train, device=device, epochs=int(epochs), wrapped=wrapped, coding_w=0.1)
    acc = _accuracy(model, dl_test, device=device)

    # Calibrate NC on ID
    scores_cal = []
    with torch.no_grad():
        seen = 0
        for xb, _ in dl_test:
            _ = wrapped.forward(xb.to(device))
            traces = getattr(wrapped, "_last_layer_traces", {})
            agg_obj = max_surprise(traces) if str(agg).lower() == "max" else mean_surprise(traces)
            if agg_obj is not None:
                scores_cal.append(agg_obj.surprise.detach().to("cpu").reshape(-1))
            seen += int(xb.shape[0])
            if limit_eval and seen >= int(limit_eval):
                break
    import torch

    cal = torch.cat(scores_cal, dim=0) if scores_cal else torch.empty(0)
    calib = EmpiricalPercentileCalibrator(threshold_quantiles=(0.95,))
    calib.fit(cal, aggregation=str(agg))

    out: list[ResultRow] = []

    # Helper: measure latency on ~1000 ID samples
    def _lat(func: Any) -> float:
        n = 0
        t0 = time.perf_counter()
        with torch.no_grad():
            for xb, _ in dl_test:
                _ = func(xb.to(device))
                n += int(xb.shape[0])
                if n >= 1024:
                    break
        return (time.perf_counter() - t0) * 1000.0 / max(1, n)

    lat_msp = _lat(lambda x: _msp(model(x)))
    lat_energy = _lat(lambda x: _energy(model(x)))
    lat_nc = _lat(
        lambda x: (
            max_surprise(getattr(WrappedModel(model), "_last_layer_traces", {})) if False else 0
        )
    )  # placeholder

    # Evaluate per OOD
    def _score_id(method: str) -> Any:
        vals = []
        with torch.no_grad():
            seen = 0
            for xb, _ in dl_test:
                logits = model(xb.to(device))
                if method == "msp":
                    s = _msp(logits)
                elif method == "energy":
                    s = _energy(logits)
                else:
                    _ = wrapped.forward(xb.to(device))
                    traces = getattr(wrapped, "_last_layer_traces", {})
                    agg_obj = (
                        max_surprise(traces) if str(agg).lower() == "max" else mean_surprise(traces)
                    )
                    s = agg_obj.surprise if agg_obj is not None else torch.empty(0)
                vals.append(s.detach().to("cpu").reshape(-1))
                seen += int(xb.shape[0])
                if limit_eval and seen >= int(limit_eval):
                    break
        return torch.cat(vals, dim=0)

    id_msp = _score_id("msp")
    id_energy = _score_id("energy")
    id_nc = _score_id("nc")

    for name, loader in ood_map.items():
        # OOD scores
        def _score_ood(method: str, _loader: Any = loader) -> Any:
            vals = []
            with torch.no_grad():
                seen = 0
                for xb, _ in _loader:
                    logits = model(xb.to(device))
                    if method == "msp":
                        s = _msp(logits)
                    elif method == "energy":
                        s = _energy(logits)
                    else:
                        _ = wrapped.forward(xb.to(device))
                        traces = getattr(wrapped, "_last_layer_traces", {})
                        agg_obj = (
                            max_surprise(traces)
                            if str(agg).lower() == "max"
                            else mean_surprise(traces)
                        )
                        s = agg_obj.surprise if agg_obj is not None else torch.empty(0)
                    vals.append(s.detach().to("cpu").reshape(-1))
                    seen += int(xb.shape[0])
                    if limit_eval and seen >= int(limit_eval):
                        break
            return torch.cat(vals, dim=0)

        ood_msp = _score_ood("msp")
        ood_energy = _score_ood("energy")
        ood_nc = _score_ood("nc")
        # Labels and metrics
        y = torch.cat(
            [
                torch.zeros_like(id_msp, dtype=torch.long),
                torch.ones_like(ood_msp, dtype=torch.long),
            ],
            dim=0,
        )
        out.extend(
            [
                ResultRow(
                    seed=int(seed),
                    ood=str(name),
                    method="msp",
                    auroc=_auroc(torch.cat([id_msp, ood_msp]), y),
                    fpr95=_fpr_at_tpr(id_msp, ood_msp),
                    id_acc=float(acc),
                    latency_ms=float(lat_msp),
                ),
                ResultRow(
                    seed=int(seed),
                    ood=str(name),
                    method="energy",
                    auroc=_auroc(torch.cat([id_energy, ood_energy]), y),
                    fpr95=_fpr_at_tpr(id_energy, ood_energy),
                    id_acc=float(acc),
                    latency_ms=float(lat_energy),
                ),
                ResultRow(
                    seed=int(seed),
                    ood=str(name),
                    method=f"nervecode_{agg}",
                    auroc=_auroc(torch.cat([id_nc, ood_nc]), y),
                    fpr95=_fpr_at_tpr(id_nc, ood_nc),
                    id_acc=float(acc),
                    latency_ms=float(lat_nc) if isinstance(lat_nc, float) else float("nan"),
                ),
            ]
        )

    return out


def _write_results(rows: list[ResultRow], outdir: str) -> None:
    os.makedirs(outdir, exist_ok=True)
    csv_path = os.path.join(outdir, "results.csv")
    jsonl = os.path.join(outdir, "results.jsonl")
    if rows:
        with open(csv_path, "w", encoding="utf-8") as f:
            f.write("seed,ood,method,auroc,fpr95,id_acc,latency_ms\n")
            for r in rows:
                f.write(
                    f"{r.seed},{r.ood},{r.method},{r.auroc},{r.fpr95},{r.id_acc},{r.latency_ms}\n"
                )
        with open(jsonl, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(asdict(r)) + "\n")


def _main() -> None:  # pragma: no cover
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data-root", type=str, default="./data")
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--seed", type=int, default=123)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--layers", type=str, default="last_conv")
    p.add_argument("--agg", type=str, default="max", choices=["mean", "max"])
    p.add_argument("--K", type=int, default=16)
    p.add_argument("--coding-dim", type=int, default=8)
    p.add_argument("--beta-length", type=float, default=1.0)
    p.add_argument("--beta-entropy", type=float, default=0.0)
    p.add_argument("--beta-distance", type=float, default=1.0)
    p.add_argument("--temperature", type=float, default=2.0)
    p.add_argument("--limit-eval", type=int, default=1000)
    p.add_argument("--outdir", type=str, default=None)
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args()

    outdir = args.outdir or os.path.join("runs", f"mnist-ood-{time.strftime('%Y%m%d-%H%M%S')}")
    rows = run(
        data_root=args.data_root,
        device=args.device,
        seed=args.seed,
        batch_size=args.batch_size,
        epochs=args.epochs,
        layers=args.layers,
        agg=args.agg,
        K=args.K,
        coding_dim=args.coding_dim,
        beta_length=args.beta_length,
        beta_entropy=args.beta_entropy,
        beta_distance=args.beta_distance,
        temperature=args.temperature,
        limit_eval=args.limit_eval,
    )
    _write_results(rows, outdir)
    print(f"Wrote results to {outdir}")


if __name__ == "__main__":  # pragma: no cover
    _main()
