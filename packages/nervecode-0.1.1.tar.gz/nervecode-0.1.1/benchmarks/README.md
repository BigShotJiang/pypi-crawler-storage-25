# Benchmarks

This directory contains performance benchmarks and profiling harnesses.

- Overhead: `benchmarks/overhead/overhead.py` compares a base MLP against the
  instrumented version on a fixed workload and reports per‑iteration timings.
  Usage:
  - `python -m benchmarks.overhead.overhead --iters 100 --device cpu`
  - `python benchmarks/overhead/overhead.py --json`

- Conv Overhead: `benchmarks/overhead/conv_overhead.py` runs a tiny CNN with
  and without pooled Conv2d coding and reports per‑iteration timings. On CUDA
  it also prints a rough GPU memory delta after instrumentation. Usage:
  - `python -m benchmarks.overhead.conv_overhead --iters 100 --device cpu`
  - `python benchmarks/overhead/conv_overhead.py --json`

Benchmarks are not part of strict CI and are intended for manual runs.
