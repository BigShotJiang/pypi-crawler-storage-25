"""Benchmarks and profiling harnesses for Nervecode.

Not part of strict CI; intended for manual runs.
"""
