"""Overhead benchmark for pooled Conv2d coding.

Measures the per-iteration wall-clock time of a tiny CNN when run as a base
PyTorch model and when instrumented with pooled-coding wrappers on all Conv2d
layers. Optionally reports GPU memory deltas when CUDA is available.

Usage
- As a module: `python -m benchmarks.overhead.conv_overhead --help`
- As a script: `python benchmarks/overhead/conv_overhead.py --iters 50 --device cpu`

For deterministic, environment-independent guidance, see the library-level
estimator in `nervecode.utils.overhead` and the accompanying docs.
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass
from typing import Any, TypedDict


class _PerIterMs(TypedDict):
    base: float
    instrumented: float
    delta: float


@dataclass
class ConvOverheadResult:
    device: str
    iterations: int
    batch_size: int
    img_hw: int
    channels: int
    conv_channels: int
    base_seconds: float
    instrumented_seconds: float
    overhead_ratio: float | None
    per_iter_ms: _PerIterMs
    cuda_mem_bytes: dict[str, int] | None


def _resolve_device(requested: str) -> str:
    try:
        import importlib

        torch = importlib.import_module("torch")
    except Exception:
        return "cpu"

    if requested.lower() == "cuda" and getattr(torch.cuda, "is_available", lambda: False)():
        return "cuda"
    return "cpu"


def _tiny_cnn(ch: int, conv_ch: int) -> Any:
    import importlib

    nn = importlib.import_module("torch.nn")

    class TinyCNN(nn.Module):  # type: ignore[misc,name-defined]
        def __init__(self) -> None:
            super().__init__()
            self.conv1 = nn.Conv2d(ch, conv_ch, kernel_size=3, padding=1)
            self.act1 = nn.ReLU()
            self.conv2 = nn.Conv2d(conv_ch, conv_ch, kernel_size=3, padding=1)
            self.act2 = nn.ReLU()
            self.out = nn.Linear(conv_ch, 2)

        def forward(self, x: Any) -> Any:
            h = self.act1(self.conv1(x))
            h = self.act2(self.conv2(h))
            h = h.mean(dim=(-1, -2))
            return self.out(h)

    return TinyCNN()


def _time_loop(model: Any, x: Any, iters: int, device: str) -> float:
    import importlib

    torch = importlib.import_module("torch")

    if hasattr(model, "eval"):
        model.eval()
    sync = getattr(torch.cuda, "synchronize", None)
    do_sync = callable(sync) and device == "cuda"

    if do_sync:
        sync()  # type: ignore[misc]
    t0 = time.perf_counter()
    with torch.no_grad():
        for _ in range(int(iters)):
            _ = model(x)
    if do_sync:
        sync()  # type: ignore[misc]
    t1 = time.perf_counter()
    return float(t1 - t0)


def _cuda_mem_snapshot(device: str) -> int | None:
    try:
        import importlib

        torch = importlib.import_module("torch")
    except Exception:
        return None
    if device != "cuda":
        return None
    try:
        return int(torch.cuda.memory_allocated())
    except Exception:
        return None


def run_conv_overhead_benchmark(
    *,
    iters: int = 50,
    batch_size: int = 64,
    img_hw: int = 32,
    channels: int = 3,
    conv_channels: int = 8,
    device: str = "cpu",
    warmup: int = 5,
) -> ConvOverheadResult:
    """Run the Conv2d overhead benchmark and return structured results."""

    try:
        import importlib

        torch = importlib.import_module("torch")
    except Exception as exc:  # pragma: no cover - environment dependent
        raise RuntimeError("PyTorch is required for the conv overhead benchmark") from exc

    dev = _resolve_device(device)
    torch.manual_seed(0)

    base = _tiny_cnn(channels, conv_channels)
    inst = _tiny_cnn(channels, conv_channels)
    inst.load_state_dict(base.state_dict())

    H = W = int(img_hw)
    x = torch.randn(batch_size, channels, H, W)
    if dev == "cuda":
        base = base.to("cuda")
        inst = inst.to("cuda")
        x = x.to("cuda")

    # Warm-up and measure base
    _ = _time_loop(base, x, max(0, int(warmup)), dev)
    t_base = _time_loop(base, x, int(iters), dev)

    # Instrument convs
    from nervecode.layers.wrap import wrap as wrap_layers

    wrap_layers(inst, layers="all_conv")

    # Warm-up and measure instrumented
    _ = _time_loop(inst, x, max(0, int(warmup)), dev)
    t_inst = _time_loop(inst, x, int(iters), dev)

    per_iter_base = (t_base / float(iters)) * 1000.0 if iters > 0 else 0.0
    per_iter_inst = (t_inst / float(iters)) * 1000.0 if iters > 0 else 0.0
    overhead_ratio = (t_inst / t_base) if t_base > 0.0 else None

    mem = None
    if dev == "cuda":  # best-effort delta memory snapshot on CUDA
        try:
            # Rough delta: allocated right after wrapping minus before
            before = _cuda_mem_snapshot(dev) or 0
            # Trigger a forward to materialize buffers
            _ = inst(x)
            after = _cuda_mem_snapshot(dev) or 0
            mem = {"delta_allocated": int(max(0, after - before)), "after": int(after)}
        except Exception:
            mem = None

    return ConvOverheadResult(
        device=dev,
        iterations=int(iters),
        batch_size=int(batch_size),
        img_hw=int(img_hw),
        channels=int(channels),
        conv_channels=int(conv_channels),
        base_seconds=float(t_base),
        instrumented_seconds=float(t_inst),
        overhead_ratio=None if overhead_ratio is None else float(overhead_ratio),
        per_iter_ms={
            "base": float(per_iter_base),
            "instrumented": float(per_iter_inst),
            "delta": float(per_iter_inst - per_iter_base),
        },
        cuda_mem_bytes=mem,
    )


def _main() -> None:  # pragma: no cover - manual runs
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--iters", type=int, default=50, help="Number of measured iterations")
    p.add_argument("--batch-size", type=int, default=64, help="Batch size")
    p.add_argument("--img-hw", type=int, default=32, help="Square image H=W size")
    p.add_argument("--channels", type=int, default=3, help="Input channels")
    p.add_argument("--conv-channels", type=int, default=8, help="Conv feature channels")
    p.add_argument(
        "--device",
        type=str,
        default="cpu",
        choices=["cpu", "cuda"],
        help="Preferred device (cuda only if available)",
    )
    p.add_argument("--warmup", type=int, default=5, help="Warm-up iterations before timing")
    p.add_argument("--json", action="store_true", help="Emit JSON as well as text summary")
    args = p.parse_args()

    try:
        res = run_conv_overhead_benchmark(
            iters=args.iters,
            batch_size=args.batch_size,
            img_hw=args.img_hw,
            channels=args.channels,
            conv_channels=args.conv_channels,
            device=args.device,
            warmup=args.warmup,
        )
    except RuntimeError as exc:
        print(f"error: {exc}")
        return

    # Human-friendly summary
    header = (
        f"device={res.device} iters={res.iterations} batch={res.batch_size} "
        f"img={res.img_hw}x{res.img_hw} ch={res.channels} conv_ch={res.conv_channels}"
    )
    print(header)
    print(f"base       : {res.per_iter_ms['base']:.3f} ms/iter ({res.base_seconds:.3f} s total)")
    print(
        f"instrumented: {res.per_iter_ms['instrumented']:.3f} ms/iter "
        f"({res.instrumented_seconds:.3f} s total)"
    )
    print(
        f"delta      : {res.per_iter_ms['delta']:.3f} ms/iter, overhead x{res.overhead_ratio:.3f}"
    )
    if res.cuda_mem_bytes is not None:
        delta = res.cuda_mem_bytes["delta_allocated"]
        after = res.cuda_mem_bytes["after"]
        print(f"cuda mem   : +{delta} B (after={after} B)")

    if args.json:
        print(json.dumps(asdict(res)))


if __name__ == "__main__":
    _main()
