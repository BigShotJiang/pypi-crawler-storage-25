"""Simple overhead benchmark: base vs instrumented model on a fixed workload.

This script measures per-iteration wall-clock time of a small MLP run as a
base PyTorch model and as an instrumented model (via `nervecode.layers.wrap`)
on the same fixed workload. It aims to provide a quick, reproducible sense of
the coding overhead for the MVP wrappers.

Usage
- As a module: `python -m benchmarks.overhead.overhead --help`
- As a script: `python benchmarks/overhead/overhead.py --iters 50 --device cpu`

The benchmark prints a concise human-readable summary and can also emit JSON
via `--json` for easy logging.
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass
from typing import Any, TypedDict


class _PerIterMs(TypedDict):
    base: float
    instrumented: float
    delta: float


@dataclass
class OverheadResult:
    device: str
    iterations: int
    batch_size: int
    in_dim: int
    hidden_dim: int
    out_dim: int
    base_seconds: float
    instrumented_seconds: float
    overhead_ratio: float | None
    per_iter_ms: _PerIterMs


def _resolve_device(requested: str) -> str:
    try:
        import importlib

        torch = importlib.import_module("torch")
    except Exception:
        return "cpu"

    if requested.lower() == "cuda" and getattr(torch.cuda, "is_available", lambda: False)():
        return "cuda"
    return "cpu"


def _build_mlp(in_dim: int, hidden_dim: int, out_dim: int) -> Any:
    import importlib

    nn = importlib.import_module("torch.nn")
    # Return a simple Sequential MLP without a custom subclass to keep typing simple
    return nn.Sequential(
        nn.Linear(in_dim, hidden_dim),
        nn.ReLU(),
        nn.Linear(hidden_dim, hidden_dim),
        nn.ReLU(),
        nn.Linear(hidden_dim, out_dim),
    )


def _time_loop(model: Any, x: Any, iters: int, device: str) -> float:
    import importlib

    torch = importlib.import_module("torch")

    # Ensure evaluation mode and inference context
    if hasattr(model, "eval"):
        model.eval()
    sync = getattr(torch.cuda, "synchronize", None)
    do_sync = callable(sync) and device == "cuda"

    if do_sync:
        sync()  # type: ignore[misc]
    t0 = time.perf_counter()
    with torch.no_grad():
        for _ in range(int(iters)):
            _ = model(x)
    if do_sync:
        sync()  # type: ignore[misc]
    t1 = time.perf_counter()
    return float(t1 - t0)


def run_overhead_benchmark(
    *,
    iters: int = 50,
    batch_size: int = 64,
    in_dim: int = 512,
    hidden_dim: int = 1024,
    out_dim: int = 10,
    device: str = "cpu",
    warmup: int = 5,
    layers: str = "all_linear",
) -> OverheadResult:
    """Run the overhead benchmark and return structured results.

    The function is importable for testability; the CLI below prints a summary
    and optional JSON.
    """

    # Optional dependency guard: if torch is unavailable, return a trivial result
    try:
        import importlib

        torch = importlib.import_module("torch")
    except Exception as exc:  # pragma: no cover - environment dependent
        raise RuntimeError("PyTorch is required for the overhead benchmark") from exc

    dev = _resolve_device(device)

    torch.manual_seed(0)
    model_base = _build_mlp(in_dim, hidden_dim, out_dim)
    model_inst = _build_mlp(in_dim, hidden_dim, out_dim)
    # Align parameters for a fair comparison
    model_inst.load_state_dict(model_base.state_dict())

    x = torch.randn(batch_size, in_dim)
    if dev == "cuda":  # device transfer if available
        model_base = model_base.to("cuda")
        model_inst = model_inst.to("cuda")
        x = x.to("cuda")

    # Warm-up to avoid one-time setup skew
    _ = _time_loop(model_base, x, max(0, int(warmup)), dev)

    # Measure base model
    t_base = _time_loop(model_base, x, int(iters), dev)

    # Instrument a copy in-place
    try:
        from nervecode.layers.wrap import wrap as wrap_layers
    except Exception as exc:  # pragma: no cover - defensive
        raise RuntimeError("nervecode.layers.wrap is unavailable in this environment") from exc

    wrap_layers(model_inst, layers=layers)

    # Warm-up instrumented path and then measure
    _ = _time_loop(model_inst, x, max(0, int(warmup)), dev)
    t_inst = _time_loop(model_inst, x, int(iters), dev)

    per_iter_base = (t_base / float(iters)) * 1000.0 if iters > 0 else 0.0
    per_iter_inst = (t_inst / float(iters)) * 1000.0 if iters > 0 else 0.0
    overhead_ratio = (t_inst / t_base) if t_base > 0.0 else None

    return OverheadResult(
        device=dev,
        iterations=int(iters),
        batch_size=int(batch_size),
        in_dim=int(in_dim),
        hidden_dim=int(hidden_dim),
        out_dim=int(out_dim),
        base_seconds=float(t_base),
        instrumented_seconds=float(t_inst),
        overhead_ratio=None if overhead_ratio is None else float(overhead_ratio),
        per_iter_ms={
            "base": float(per_iter_base),
            "instrumented": float(per_iter_inst),
            "delta": float(per_iter_inst - per_iter_base),
        },
    )


def _main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--iters", type=int, default=50, help="Number of measured iterations")
    p.add_argument("--batch-size", type=int, default=64, help="Batch size")
    p.add_argument("--in-dim", type=int, default=512, help="Input feature dimension")
    p.add_argument("--hidden-dim", type=int, default=1024, help="Hidden feature dimension")
    p.add_argument("--out-dim", type=int, default=10, help="Output feature dimension")
    p.add_argument(
        "--device",
        type=str,
        default="cpu",
        choices=["cpu", "cuda"],
        help="Preferred device (cuda only if available)",
    )
    p.add_argument("--warmup", type=int, default=5, help="Warm-up iterations before timing")
    p.add_argument(
        "--layers",
        type=str,
        default="all_linear",
        help="Layer selection shortcut for instrumentation",
    )
    p.add_argument("--json", action="store_true", help="Emit JSON as well as text summary")
    args = p.parse_args()

    try:
        res = run_overhead_benchmark(
            iters=args.iters,
            batch_size=args.batch_size,
            in_dim=args.in_dim,
            hidden_dim=args.hidden_dim,
            out_dim=args.out_dim,
            device=args.device,
            warmup=args.warmup,
            layers=args.layers,
        )
    except RuntimeError as exc:
        print(f"error: {exc}")
        return

    # Human-friendly summary
    header = (
        f"device={res.device} iters={res.iterations} batch={res.batch_size} "
        f"dims=({res.in_dim}->{res.hidden_dim}->{res.hidden_dim}->{res.out_dim})"
    )
    print(header)
    print(f"base       : {res.per_iter_ms['base']:.3f} ms/iter ({res.base_seconds:.3f} s total)")
    print(
        f"instrumented: {res.per_iter_ms['instrumented']:.3f} ms/iter "
        f"({res.instrumented_seconds:.3f} s total)"
    )
    print(
        f"delta      : {res.per_iter_ms['delta']:.3f} ms/iter, overhead x{res.overhead_ratio:.3f}"
    )

    if args.json:
        print(json.dumps(asdict(res)))


if __name__ == "__main__":  # pragma: no cover - exercised by manual runs
    _main()
