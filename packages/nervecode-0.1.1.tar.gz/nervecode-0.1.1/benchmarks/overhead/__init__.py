"""Overhead microbenchmarks.

Contains a simple timing script comparing base vs instrumented models.
"""
