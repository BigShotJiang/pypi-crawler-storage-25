"""Scaling study: compute/memory vs width, coding dim, and instrumented layers.

This module provides an importable ``run_scaling_study`` function and a small
CLI to sweep over:
- layer width (hidden dimension for a tiny MLP),
- coding dimension request ("auto" or integer), and
- number of instrumented linear layers in the model.

For each configuration, it measures per-iteration wall-clock time on a fixed
inference workload for the base and instrumented models, and records lightweight
memory proxies derived from the inserted wrappers (parameter overhead and
approximate transient activation bytes per sample for the coding path).

Usage:
  python -m benchmarks.scaling.study --help
"""

from __future__ import annotations

import argparse
import json
import time
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from typing import Any, TypedDict, cast


class _PerIterMs(TypedDict):
    base: float
    instrumented: float
    delta: float


class OverheadSummary(TypedDict):
    num_wrapped_layers: int
    param_overhead: int
    macs_overhead_per_sample: int
    activation_overhead_bytes_per_sample: int


@dataclass
class ScalingResult:
    # Sweep settings
    width: int
    code_dim_request: str  # "auto" or integer string
    instrumented_layers: int
    depth: int
    K: int
    # Workload and platform
    device: str
    iterations: int
    batch_size: int
    # Measurements
    per_iter_ms: _PerIterMs
    overhead_ratio: float | None
    overhead: OverheadSummary


def _resolve_device(requested: str) -> str:
    try:
        import importlib

        torch = importlib.import_module("torch")
    except Exception:
        return "cpu"

    if requested.lower() == "cuda" and getattr(torch.cuda, "is_available", lambda: False)():
        return "cuda"
    return "cpu"


def _build_mlp(in_dim: int, hidden_dim: int, out_dim: int, depth: int) -> Any:
    """Return a simple feed-forward MLP as ``nn.Sequential``.

    The model alternates Linear/ReLU blocks `depth-1` times and ends with a
    final Linear to `out_dim`. For example, depth=3 builds:
    in_dim -> hidden -> hidden -> out_dim
    """

    import importlib

    nn = importlib.import_module("torch.nn")

    layers: list[Any] = []
    last = in_dim
    for _ in range(max(1, int(depth) - 1)):
        layers.append(nn.Linear(last, hidden_dim))
        layers.append(nn.ReLU())
        last = hidden_dim
    layers.append(nn.Linear(last, out_dim))
    return nn.Sequential(*layers)


def _select_first_n_linear(model: Any, n: int) -> list[str]:
    """Return dotted names of the first ``n`` Linear submodules in ``model``.

    Skips the top-level module name (empty string). Returns fewer names if the
    model has fewer than ``n`` linear layers.
    """

    try:
        import importlib

        nn = importlib.import_module("torch.nn")
    except Exception:
        return []

    names = [name for name, m in model.named_modules() if isinstance(m, nn.Linear) and name]
    return names[: max(0, int(n))]


def _instrument_first_n_linear(
    model: Any,
    *,
    K: int,
    coding_dim_req: str,  # "auto" or integer string
    n_layers: int,
) -> Any:
    """Wrap the first ``n_layers`` Linear modules with CodingLinear.

    When ``coding_dim_req == 'auto'``, the wrapper default is used; otherwise
    the requested dimension is clamped to ``[1, layer.out_features]``.
    """

    try:
        import importlib

        nn = importlib.import_module("torch.nn")
    except Exception:
        return model

    from nervecode.layers.linear import CodingLinear

    targets = _select_first_n_linear(model, n_layers)
    for name in targets:
        try:
            sub = model.get_submodule(name)
        except Exception:
            continue

        if not isinstance(sub, nn.Linear):
            continue

        if coding_dim_req == "auto":
            code_dim: int | None = None
        else:
            try:
                req = int(coding_dim_req)
            except Exception:
                req = sub.out_features
            code_dim = min(int(sub.out_features), max(1, int(req)))

        wrapper = CodingLinear(sub, K=int(K), coding_dim=code_dim)

        parent_path, leaf = name.rsplit(".", 1) if "." in name else ("", name)
        try:
            parent = model.get_submodule(parent_path) if parent_path else model
        except Exception:
            continue
        if hasattr(parent, leaf):
            setattr(parent, leaf, wrapper)
        else:
            parent._modules[leaf] = wrapper

    return model


def _compute_overhead(model: Any) -> OverheadSummary:
    """Aggregate simple overhead proxies from present wrappers.

    The estimates are per-sample (forward) and summed over wrappers:
    - param_overhead: K*D plus optional projection params when present
    - macs_overhead_per_sample: approx projection MACs + 2*K*D + K (softmax)
    - activation_overhead_bytes_per_sample: float bytes for (D + K)
    """

    try:
        from nervecode.layers.base import BaseCodingWrapper
    except Exception:
        return {
            "num_wrapped_layers": 0,
            "param_overhead": 0,
            "macs_overhead_per_sample": 0,
            "activation_overhead_bytes_per_sample": 0,
        }

    total_params = 0
    total_macs = 0
    total_act_bytes = 0
    count = 0

    for _name, m in getattr(model, "named_modules", lambda: [])():
        if not isinstance(m, BaseCodingWrapper):
            continue
        count += 1
        codebook = getattr(m, "codebook", None)
        if codebook is None:
            continue
        K = int(getattr(codebook, "K", 0))
        D = int(getattr(codebook, "code_dim", 0))

        proj_params = 0
        proj = getattr(m, "_projection", None)
        if proj is not None and hasattr(proj, "weight"):
            try:
                w = cast(Any, proj.weight)
                proj_params = int(w.numel())
                # Projection MACs per sample: out_features * in_features
                out_f, in_f = int(w.shape[0]), int(w.shape[1])
                total_macs += out_f * in_f
            except Exception:
                pass
        total_params += K * D + proj_params

        # Distances and softmax (approx.)
        total_macs += 2 * K * D
        total_macs += K

        # Activations: reduced vector (D) + soft code (K)
        total_act_bytes += (D + K) * 4  # float32

    return {
        "num_wrapped_layers": int(count),
        "param_overhead": int(total_params),
        "macs_overhead_per_sample": int(total_macs),
        "activation_overhead_bytes_per_sample": int(total_act_bytes),
    }


def _time_loop(model: Any, x: Any, iters: int, device: str) -> float:
    import importlib

    torch = importlib.import_module("torch")
    if hasattr(model, "eval"):
        model.eval()
    sync = getattr(torch.cuda, "synchronize", None)
    do_sync = callable(sync) and device == "cuda"

    if do_sync:
        sync()  # type: ignore[misc]
    t0 = time.perf_counter()
    with torch.no_grad():
        for _ in range(int(iters)):
            _ = model(x)
    if do_sync:
        sync()  # type: ignore[misc]
    t1 = time.perf_counter()
    return float(t1 - t0)


def run_scaling_study(
    *,
    widths: Iterable[int],
    coding_dims: Iterable[str],  # entries: "auto" or integer string
    num_instrumented_layers: Iterable[int],
    depth: int = 3,
    K: int = 16,
    iters: int = 20,
    batch_size: int = 64,
    in_dim: int = 512,
    out_dim: int = 10,
    device: str = "cpu",
    warmup: int = 5,
) -> list[ScalingResult]:
    """Run the scaling study and return structured results.

    Notes
    - Requires PyTorch; raises a RuntimeError otherwise.
    - Uses inference-only timing on a synthetic input.
    """

    try:
        import importlib

        torch = importlib.import_module("torch")
    except Exception as exc:  # pragma: no cover - environment dependent
        raise RuntimeError("PyTorch is required for the scaling study") from exc

    dev = _resolve_device(device)
    torch.manual_seed(0)

    results: list[ScalingResult] = []

    for w in (int(x) for x in widths):
        # Build base/instrumented models per width to keep parameter shapes aligned
        model_base = _build_mlp(in_dim, w, out_dim, depth=int(depth))
        model_inst_template = _build_mlp(in_dim, w, out_dim, depth=int(depth))
        model_inst_template.load_state_dict(model_base.state_dict())

        x = torch.randn(batch_size, in_dim)
        if dev == "cuda":
            model_base = model_base.to("cuda")
            model_inst_template = model_inst_template.to("cuda")
            x = x.to("cuda")

        # Warm-up base
        _ = _time_loop(model_base, x, max(0, int(warmup)), dev)
        t_base = _time_loop(model_base, x, int(iters), dev)
        per_iter_base = (t_base / float(iters)) * 1000.0 if iters > 0 else 0.0

        for cd_req in coding_dims:
            cd_req_s = str(cd_req).strip()
            for n in (int(v) for v in num_instrumented_layers):
                # Fresh copy to avoid accumulating wrappers across configs
                # Note: move state via CPU tensors for simplicity
                model_inst = _build_mlp(in_dim, w, out_dim, depth=int(depth))
                model_inst.load_state_dict(model_base.cpu().state_dict())
                if dev == "cuda":
                    model_inst = model_inst.to("cuda")

                model_inst = _instrument_first_n_linear(
                    model_inst, K=int(K), coding_dim_req=cd_req_s, n_layers=int(n)
                )

                # Warm-up instrumented path and measure
                _ = _time_loop(model_inst, x, max(0, int(warmup)), dev)
                t_inst = _time_loop(model_inst, x, int(iters), dev)
                per_iter_inst = (t_inst / float(iters)) * 1000.0 if iters > 0 else 0.0
                overhead_ratio = (t_inst / t_base) if t_base > 0.0 else None

                # Overhead proxies
                # If a WrappedModel was returned elsewhere we'd unwrap; here we have raw model
                ov = _compute_overhead(model_inst)

                results.append(
                    ScalingResult(
                        width=int(w),
                        code_dim_request=cd_req_s,
                        instrumented_layers=int(n),
                        depth=int(depth),
                        K=int(K),
                        device=dev,
                        iterations=int(iters),
                        batch_size=int(batch_size),
                        per_iter_ms={
                            "base": float(per_iter_base),
                            "instrumented": float(per_iter_inst),
                            "delta": float(per_iter_inst - per_iter_base),
                        },
                        overhead_ratio=None if overhead_ratio is None else float(overhead_ratio),
                        overhead=ov,
                    )
                )

    return results


def _parse_csv_list(s: str) -> list[str]:
    return [p.strip() for p in s.split(",") if p.strip()]


def _main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--widths", default="256,512,1024", help="Comma-separated hidden widths")
    p.add_argument(
        "--coding-dims",
        default="auto,64,128",
        help="Comma-separated coding dims: integers or 'auto'",
    )
    p.add_argument(
        "--layers",
        dest="layers_str",
        default="0,1,2,3",
        help="Comma-separated counts of instrumented linear layers",
    )
    p.add_argument("--depth", type=int, default=3, help="Linear layer depth (>=2)")
    p.add_argument("--K", type=int, default=16, help="Codebook size")
    p.add_argument("--iters", type=int, default=20, help="Measured iterations")
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--in-dim", type=int, default=512)
    p.add_argument("--out-dim", type=int, default=10)
    p.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    p.add_argument("--warmup", type=int, default=5)
    p.add_argument("--json", action="store_true", help="Emit JSON for each row")
    args = p.parse_args()

    try:
        widths = [int(x) for x in _parse_csv_list(str(args.widths))]
        cds = _parse_csv_list(str(args.coding_dims))
        n_layers = [int(x) for x in _parse_csv_list(str(args.layers_str))]
    except Exception as exc:
        print(f"error: invalid list arguments: {exc}")
        return

    try:
        rows = run_scaling_study(
            widths=widths,
            coding_dims=cds,
            num_instrumented_layers=n_layers,
            depth=int(args.depth),
            K=int(args.K),
            iters=int(args.iters),
            batch_size=int(args.batch_size),
            in_dim=int(args.in_dim),
            out_dim=int(args.out_dim),
            device=str(args.device),
            warmup=int(args.warmup),
        )
    except RuntimeError as exc:
        print(f"error: {exc}")
        return

    for r in rows:
        # Human-friendly line per configuration
        ovx = f"{r.overhead_ratio:.3f}" if r.overhead_ratio is not None else "nan"
        print(
            f"width={r.width} D={r.code_dim_request} n={r.instrumented_layers} depth={r.depth} "
            f"K={r.K} device={r.device} "
            f"base={r.per_iter_ms['base']:.3f}ms inst={r.per_iter_ms['instrumented']:.3f}ms "
            f"delta={r.per_iter_ms['delta']:.3f}ms overhead_x={ovx} "
            f"params+={r.overhead['param_overhead']} macs+={r.overhead['macs_overhead_per_sample']}"
        )
        if args.json:
            print(json.dumps(asdict(r)))


if __name__ == "__main__":  # pragma: no cover - manual runs
    _main()
