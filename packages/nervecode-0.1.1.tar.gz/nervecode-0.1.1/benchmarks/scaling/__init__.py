"""Scaling studies for compute/memory vs instrumentation settings.

This package provides small, importable helpers to measure how overhead scales
with layer width, coding dimension, and the number of instrumented layers.

See `benchmarks.scaling.study` for the main entry point.
"""

from __future__ import annotations

__all__ = [
    "__doc__",
]
