# Changelog

## Unreleased

## [0.1.1] - 2026-05-03

### Fixed

- Fixed the top-level quickstart path that caused the initial PyPI 0.1.0 upload
  to be removed: `wrapped(x); wrapped.coding_loss()` now refreshes traces
  through `WrappedModel.__call__`.
- Fixed package long-description metadata to use the canonical root
  `README.md`.

### Changed

- Cleaned release packaging and metadata, including tag-only manual PyPI
  publishing in GitLab CI.
- Removed generated Python bytecode from the tracked release surface and added
  release checks to prevent recurrence.
- Clarified benchmark score orientation, train/calibration/test split policy,
  and combo calibration provenance.
- Reframed CIFAR ResNet-18 benchmarks as source-checkout research scripts with
  explicit `demo` and `full_cifar10_resnet18` presets and a full-mode accuracy
  gate.

### Added

- Release smoke test for the installed public API.
- Optional `benchmark` and `viz` dependency extras.
- MaxLogit, GEN, KNN-OOD, and Residual/ViM-lite baseline documentation and
  score-contract tests.
- ID-only Combo(E, M, N) ablation with cached component score vectors,
  AUPR-OUT reporting, and `scripts/combo_report.py`.
- Layerwise artifact persistence and the `python -m nervecode.viz.layerwise`
  plotting CLI.
- v0.1.1 JSON configs under `configs/v0_1_1/`, source-checkout Makefile
  targets, run metadata, dataset/checkpoint manifests, and benchmark artifact
  archiving.

### Documentation

- Added baseline definitions, combo policy, benchmark protocol, and release
  rationale in the changelog.
- Added honest README framing: Nervecode is an intrinsic layerwise surprise
  signal, not a guaranteed standalone replacement for strong logit baselines
  such as Energy on every CIFAR shift.

## v0.1.0 — 2026-04-07

- Initial preview release. Establishes PyTorch-native coding wrappers (Linear/Conv2d),
  layerwise surprise aggregation (mean/max/weighted), calibration utilities,
  a `WrappedModel` container, training utilities, benchmarks (CIFAR-10 OOD, MNIST OOD),
  and a CPU-friendly experiment suite and scripts. Includes CI (lint/typecheck/tests),
  docs scaffolding, and example scripts.

- Wrappers and model container: Disabling coding now clears any cached
  per-layer traces immediately (fail-open) so that model-level behavior (e.g.,
  `WrappedModel.surprise()`) reflects the disabled state without requiring an
  extra forward pass.

- API stability: Locked the minimal public surface via explicit __all__ in
  packages and added tests (including star-import check) to prevent accidental
  API creep until the MVP is validated on real examples/benchmarks.

- Tests: Separated fast correctness tests from heavy runs by introducing
  `benchmark` and `slow` markers and deselecting them by default; CI runs only
  the fast suite to keep pipelines reliable and quick. See CONTRIBUTING and
  `docs/benchmarks.md` for how to include them locally.

- Docs: Added `docs/benchmarks.md` template for experiment/benchmark reports to
  standardize documentation and avoid one‑off notebooks.

- Docs: Added `docs/scaling.md` covering selected-layer instrumentation, reduced
  coding spaces, and practical tradeoffs between expressivity and overhead.

- Layers: Added experimental convolutional reducers in `nervecode.layers.reducers`.
  Includes a token-like spatial view (BHWC) for Conv2d outputs and a global
  max-pooling reducer. These are opt-in via the existing `reducer=` parameter on
  `CodingConv2d` and do not change defaults. Added a unit test exercising the
  token-like path.

- Training: Added experimental `EmaCodebookUpdater` (off by default) to update
  codebook centers via EMA of batch-weighted means from a `CodingTrace`. Keeps
  gradient-updated baseline unchanged; enables hybrid exploration when needed.

- Docs: Added `docs/quickstart.md` explaining the end-to-end user flow and
  mirroring the `examples/quickstart_mlp.py` script.

- Benchmarks: Added `benchmarks/scaling/study.py` with `run_scaling_study` and a CLI
  to measure compute (per-iteration time) and memory proxies (parameter and
  activation overhead) as a function of layer width, coding dimension, and the
  number of instrumented layers. Includes a unit test.

- Scripts: Added `scripts/ablate_grid.py` to run ablations varying codebook size (K),
  coding dimension (D), temperature (T), and layer selection strategy. Records
  minimal quality (test accuracy) and approximate overhead proxies, and can write
  results to CSV for quick analysis.

- Tests: Added deterministic, explainability-focused unit tests for richer
  aggregation modes (fixed weighted and max) on hand-constructed examples to
  ensure stable outputs and clear aggregation metadata.

- Tests: Added checkpoint-compatibility tests covering two common flows —
  loading base-model weights before instrumentation and loading wrapped-model
  checkpoints together with calibrator state after calibration.

- Scoring: Implemented `weighted_surprise(...)` for fixed weighted aggregation
  across layers with a simple configuration interface (layer-name or index-aligned
  weights; optional normalization). Learnable aggregation is intentionally
  deferred pending evidence of real-world benefit.

- Scoring: Added `max_surprise(...)` as a supported alternative to
  `mean_surprise(...)`, returning the same `AggregatedSurprise` result type and
  plugging into existing calibrator flows.

- Docs: Added rationale explaining why the first Conv2d wrapper uses pooled
  coding and why richer spatial modes are deferred (see `docs/architecture.md`).

- Wrap: `nervecode.layers.wrap.wrap` can now instrument convolutional layers explicitly
  and via the shortcut `layers="all_conv"` (currently wraps `nn.Conv2d` with
  `CodingConv2d`).

- Examples: Added `examples/quickstart_cnn.py` demonstrating a small CNN where
  pooled Conv2d traces contribute to the aggregated per-sample surprise.

- Tests: Added unit tests verifying that `CodingConv2d` preserves the exact
  forward output while producing valid pooled traces with correct metadata.

- Integration: Added end-to-end tests exercising a small CNN with pooled
  convolutional coding — covering training with a joint objective, surprise
  retrieval via `WrappedModel.surprise()`, and empirical-percentile calibration
  with basic ID/OOD separation.

- Conv2d pooled coding metadata: pooled representations now record explicit
  spatial-reduction metadata in ``reduction_meta`` (e.g., ``spatial_reduction``
  and ``reduction_axes``) to make it clear that the coding view comes from a
  spatial reduction rather than the raw activation tensor.

- Layers: Added `CodingConv2d` with observe-only pooled coding (global average pooling over H×W by default) and set pooled coding as the default sample-level reducer for the first convolutional wrapper.

- Layers: Convolutional wrappers now reuse the shared reduction and trace pipeline, so their pooled outputs feed the same assignment, loss, and calibration code paths as linear wrappers.

- Docs: Added `CONTRIBUTING.md` and linked the changelog from README to prepare the repo for early external use.

- Integration tests: added tests that execute README and API docs example code paths to ensure they remain valid.

- Docs: corrected calibrator usage to `threshold_for(...)` in README and API reference examples.

- Overhead (Conv2d pooled coding): added a deterministic estimator
  (`nervecode.utils.overhead.estimate_pooled_conv_overhead`) and a timing
  harness (`benchmarks/overhead/conv_overhead.py`). Documented expected
  operating limits and typical compute/memory overhead in `docs/overhead.md`.

- README: added installation instructions, an MVP quickstart example, and an explicit scope note (what Nervecode does/does not do).

- Added a release smoke test that builds the package, installs the built wheel into a clean venv, and runs the quickstart example (opt-in via RUN_RELEASE_SMOKE=1).

- Added `docs/api.md` documenting `wrap()`, `WrappedModel`, `CodingLinear`,
  `CodingLoss`, the calibrator, and the aggregated surprise result.

- Added `docs/diagnostics.md` explaining code utilization, entropy, code length,
  commitment distance, empirical percentiles, and threshold-based OOD flags.

- Repository structure scaffolded (`nervecode/`, `tests/`, `examples/`, `benchmarks/`, `docs/`, `scripts/`) and package importable from a clean checkout.
 - CodingLoss: add commitment term that reads per-trace nearest-center distances (no recomputation); default weight 0.0 to preserve behavior and tests.
- Added `pyproject.toml` with core metadata, Python 3.10 requirement, PyTorch dependency, and extras for `dev`, `docs`, `viz`, and `logging`.
- Configured `ruff`, `mypy`, and `pytest` with a strict-enough baseline to catch shape, typing, and API regressions early.
- Added `pre-commit` hooks for formatting, linting, type-checking, and a fast smoke test suite.
- Added a minimal `README.md` explaining the product boundary, first public API shape, and MVP scope.
- Added top-level API stubs in `nervecode/__init__.py` exposing `wrap` and `WrappedModel`.
 - Created package layout mirroring conceptual architecture: `nervecode/core/`, `nervecode/layers/`, `nervecode/scoring/`, `nervecode/training/`, `nervecode/integration/`, and `nervecode/utils/`.
 - Split tests into `tests/unit/`, `tests/integration/`, and `tests/smoke/`; added a minimal unit test and updated docs.
- Added CI workflow to run install, ruff lint, mypy type-checks, and fast tests (unit + smoke) on push and pull requests.
- Added `scripts/dev_smoke.py` to quickly verify imports and placeholder instantiation locally.
- Added `scripts/train_minimal.py`: a dataset-agnostic training script for quick local validation and CI smoke runs.
 - Added `benchmarks/overhead/overhead.py`: a simple timing benchmark that compares a base MLP against the instrumented model on a fixed workload.
 - Added `docs/architecture.md` summarizing non-negotiable design rules (observe-only wrappers, fail-open, selected-layer instrumentation, explicit trace support, MVP-first scope).
 - Added deterministic utilities: `nervecode.utils.seed` with `seed_everything`, `temp_seed`, and a per-test auto-seeding fixture honoring `NERVECODE_SEED` for reproducible runs.
 - Implemented `nervecode/core/types.py` with a `SoftCode` dataclass whose `probs` tensor supports arbitrary leading dimensions with a final code dimension `(..., K)`.
 - Extended `SoftCode` with optional fields `best_length`, `entropy`, `best_indices`, and `combined_surprise`, and added validation that all scalar-like fields match the leading shape of `probs`.
 - Added `nervecode/core/trace.py` with a `CodingTrace` dataclass carrying reduced activations, reduction metadata, nearest-center distances, chosen center indices, commitment distances, and the associated `SoftCode`.
 - Added `nervecode/core/shapes.py` with `flatten_leading`/`unflatten_leading` helpers to work uniformly across batch-only, token-like, and pooled-convolution layouts.
 - Implemented `nervecode/core/codebook.py` providing a gradient-updated `Codebook` module with centers of shape `(K, code_dim)` and initialization scaled by the coding-space dimension.
 - Codebook now follows PyTorch conventions: `reset_parameters()` without args using stored init strategy, improved `extra_repr()`, and a serialization contract via `get_extra_state`/`set_extra_state`.
 - Packaging: added dynamic versioning via Hatch (single-source `nervecode/_version.py`) and build targets for wheel and sdist with appropriate includes.
 - Marked Phase 1 TODO "Clamp all log and division operations" as NE locally pending the assignment engine implementation in `nervecode/core/`.
 - Added `nervecode/core/temperature.py` with `FixedTemperature` and `CosineTemperature` schedules and a small `TemperatureSchedule` interface, and exported them via `nervecode.core`.
 - Implemented `nervecode/core/assignment.py` with a `SoftAssignment` engine that returns a `SoftCode` and trace-ready intermediates (nearest distances, chosen indices, commitment distances) to avoid recomputing distances in loss.
 - Added unit tests for `SoftCode`, `CodingTrace`, shape helpers, temperature schedules, and the CPU assignment engine; adjusted typing in `temperature.py` to satisfy mypy without a hard torch dependency.
 - Added unit tests that verify gradient flow from the surprise signal back to reduced activations and codebook centers.
- Added edge-case unit tests for the soft assignment engine covering exact center matches, ties between centers, uniform assignments, large input magnitudes, and autocast mixed precision where supported.
- Added a synthetic convergence integration test that trains a codebook on a simple 2D Gaussian mixture and verifies it learns at least the expected number of active regions.
 - Implemented `nervecode/layers/base.py` with a shared base class and protocol that standardize bypass behavior, trace caching, reduction setup, and diagnostics hooks.
 - Added `nervecode/layers/linear.py` with `CodingLinear`, the first production wrapper around `nn.Linear` implementing observe-only semantics and trace caching (identity reduction in MVP).
 - CodingLinear now accepts an optional `coding_dim` and uses identity reduction when `out_features == coding_dim`, or a learned linear projection reducer when `out_features > coding_dim`.
- CodingLinear now exposes an explicit `forward_with_trace(x)` method returning `(y, trace)` while caching the latest `CodingTrace` for convenience via `last_trace`.
- Verified `CodingLinear` across training/eval modes, mixed precision (autocast + GradScaler), and CPU/CUDA; added targeted unit tests.
- CodingLinear preserves the original layer output bit-for-bit when coding is disabled or bypassed; added unit tests asserting `torch.equal` under disabled and bypass contexts.
 - Added layer-level diagnostics helpers on wrappers (utilization, mean entropy, mean code length, mean commitment distance) derived from the latest cached trace; added a unit test for None-on-unavailable behavior.
- Improved `CodingLinear` representation: `extra_repr()` now shows `code_dim`, codebook size `K`, reducer type, and coding enabled state; added unit tests for the printed summary.
- Added unit test comparing an unwrapped `nn.Linear` and a wrapped twin with identical parameters to verify that the visible forward output is unchanged.
 - Added unit tests verifying trace caching after plain forwards and that the explicit trace-return path is independent of hidden mutable state for `CodingLinear`.
- Added multi-batch toggle tests for `CodingLinear`: verify disabling before forward yields no trace, re-enabling restores tracing, and cache updates across batches.
- Added integration tests for a tiny model containing a `CodingLinear`, verifying device transfers, state_dict serialization round-trip, and optimizer integration.
- Added a synthetic training integration test that uses `CodingLinear` inside a toy classifier and verifies that task loss and a coding-derived loss can be optimized together.
- Added `nervecode/layers/wrap.py` with a `wrap()` helper to instrument models by explicit module names or via the `layers="all_linear"` shortcut; added unit tests for selection and output preservation.
 - Refined layer selection in `wrap()`: introduced a tiny, extensible selector registry. MVP supports `layers="all_linear"` and explicit module-name lists; unrecognized shortcuts fail open.
- Implemented a thin `WrappedModel` container that preserves the wrapped model's API (attribute access and `__call__`) while tracking inserted coding layers for later aggregation; added a unit test.
- Implemented `WrappedModel.forward()` to delegate to the wrapped model's normal call and populate convenience caches with the latest per-layer traces when coding is enabled; added unit tests.
 - Added model-level fail-open controls on `WrappedModel`: `enable_coding()`, `disable_coding()`, and a nestable `bypass()` context manager that delegate to all wrapped layers; added unit tests.
 - Added `nervecode/scoring/aggregator.py` with a `mean_surprise(...)` function that computes per-sample mean aggregation across layer surprise signals; added unit tests.
 - Structured the aggregator API to return an `AggregatedSurprise` result object, enabling future `max` and `weighted` strategies without changing the user-facing result type; updated unit tests accordingly.
- Aggregator now supports mixing wrappers with different leading dimensions by reducing each per-layer surprise to a per-sample view before combining. Added `CodingTrace.sample_reduced_surprise()` to expose the sample-level reduction for layers.
- Implemented `WrappedModel.surprise()` to return the latest mean-aggregated surprise across wrapped layers after a standard forward pass; added a unit test.
 - Added integration test verifying that an explicit layer `forward_with_trace(...)` and model-level `WrappedModel.surprise()` agree on the same batch when called in a consistent order.
- Added integration tests clarifying that explicit traces should be preferred in concurrent-looking usage and that the model-level convenience cache reflects last-forward state; updated docs to state this explicitly.
 - Added `nervecode/training/loss.py` with a `CodingLoss` module that consumes `CodingTrace` objects (or `SoftCode`/tensors) and computes a scalar loss by aggregating per-layer surprise via `mean_surprise` and averaging over samples; avoids recomputing distances from raw outputs. 
- Implemented `WrappedModel.coding_loss()` to compute loss from the latest per-layer traces and raise a helpful error when traces are unavailable; added unit tests.
 - Added `nervecode/scoring/calibrator.py` with an empirical percentile calibrator that stores the sorted surprise distribution, chosen threshold quantiles, and minimal metadata to reproduce calibration; exported via `nervecode.scoring` and added a unit test for stored state.
 - Implemented percentile lookup, threshold comparison, and boolean OOD decisions for scalar and batched surprise values in the calibrator; added unit tests.
- Added synthetic calibration tests validating percentile ordering and threshold behavior on in-distribution vs shifted distributions.
- Added end-to-end diagnostics tests ensuring finiteness and correct shapes across training, evaluation, and calibration passes.
- Added bypass-consistency tests verifying that, under a temporary coding bypass, surprise aggregation returns None, `CodingLoss` raises on missing signals, and the calibrator rejects None inputs.
 - Added `examples/quickstart_mlp.py` demonstrating a tiny MLP wrapped with coding layers, training with `CodingLoss`, calibrating empirical percentiles on held-out in-distribution data, and reading surprise + percentiles at inference.
 - Added `examples/ood_smoke_test.py` demonstrating an obvious in-distribution vs out-of-distribution comparison and printing both raw scores and calibrated percentiles.
