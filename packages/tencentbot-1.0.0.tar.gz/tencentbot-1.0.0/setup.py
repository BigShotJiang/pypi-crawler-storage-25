from setuptools import setup, find_packages

setup(
    name="Tencentbot",
    version="1.0.0",
    packages=find_packages(),
    package_data={
        'Tencentbot': ['bot_core.js'],
    },
    include_package_data=True,
    description="Minecraft sunucularına çoklu bot sokma ve PVP kütüphanesi (Tencent Sürümü)",
    author="Tencent",
)