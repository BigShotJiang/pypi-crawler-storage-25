import os
import subprocess
import sys

bot = "normal"
version = "all"
botsayi = "1"
ip = "127.0.0.1"
botname = "Tencent"

def terminalpvp_end():
    global bot
    bot = "pvp"

def start(mode_type):
    global version, botsayi, ip, botname
    
    current_dir = os.path.dirname(__file__)
    js_path = os.path.join(current_dir, "bot_core.js")
    
    print(f"[Tencentbot] Motor başlatılıyor... Mod: {mode_type} | Sürüm: {version} | Bot Sayısı: {botsayi}")
    print("[Tencentbot] Sunucuya bağlanılıyor, lütfen bekleyin...")
    
    if not os.path.exists(os.path.join(current_dir, "node_modules")):
        print("[!] İlk çalıştırma için Node.js bağımlılıkları yükleniyor...")
        subprocess.run("npm install mineflayer mineflayer-pathfinder mineflayer-pvp", shell=True, cwd=current_dir)

    try:
        process = subprocess.Popen(
            ["node", js_path, mode_type, str(version), str(ip), str(botname), str(botsayi)],
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=sys.stderr
        )
        process.wait()
    except KeyboardInterrupt:
        print("\n[X] Botlar kapatıldı.")