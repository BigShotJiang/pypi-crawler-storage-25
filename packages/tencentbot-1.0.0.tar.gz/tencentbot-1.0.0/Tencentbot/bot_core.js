const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const pvp = require('mineflayer-pvp').plugin;
const readline = require('readline');

const args = process.argv.slice(2);
const botMode = args[0];       
const version = args[1];        
const ipStr = args[2];          
const botNameInput = args[3];   
const botCount = parseInt(args[4]) || 1;

const [host, port] = ipStr.split(':');

for (let i = 0; i < botCount; i++) {
    setTimeout(() => {
        createBot(i);
    }, i * 2000); 
}

function createBot(index) {
    const bot = mineflayer.createBot({
        host: host,
        port: port ? parseInt(port) : 25565,
        username: `${botNameInput}_${index}`,
        version: version === "all" ? false : version 
    });

    bot.loadPlugin(pathfinder);
    bot.loadPlugin(pvp);

    bot.on('spawn', () => {
        console.log(`[+] ${bot.username} sunucuya başarıyla katıldı!`);
        if (botMode === "pvp") {
            if (index === 0) startPvpTerminal(bot);
        }
    });

    bot.on('physicsTick', () => {
        if (botMode === "pvp" && global.targetPlayer) {
            const target = bot.nearestEntity(entity => entity.username === global.targetPlayer);
            if (target) {
                bot.lookAt(target.position.offset(0, target.height, 0)); 
                if (bot.entity.onGround) {
                    bot.setControlState('jump', true);
                } else {
                    bot.setControlState('jump', false);
                    bot.pvp.attack(target);
                }
            }
        }
    });

    bot.on('kicked', (reason) => console.log(`[-] Bot atıldı: ${reason}`));
    bot.on('error', (err) => console.log(`[!] Hata oluştu: ${err.message}`));
}

function startPvpTerminal(bot) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question('\n[🎯] Saldırılacak oyuncunun adını yazın: ', (answer) => {
        console.log(`[⚔️] Tüm botlar ${answer} isimli oyuncuya kilitlendi!`);
        global.targetPlayer = answer;
        rl.close();
    });
}