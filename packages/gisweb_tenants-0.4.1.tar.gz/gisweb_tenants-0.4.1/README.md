# gisweb-tenants

Libreria Python per gestire configurazione multitenant in applicazioni FastAPI.
- https://chatgpt.com/c/69be4f40-1070-832a-ad71-6889e885bef3

## Obiettivo

Separare:

- configurazione pubblica per tenant
- configurazione sensibile per tenant (Docker secrets)

e restituire un unico oggetto validato e tipizzato.

## Convenzioni

### Config pubblica
Directory configurabile, ad esempio:

`./config/tenant_rapallo.json`



# Example Package

This is a simple example package. You can use
to write your content.

poetry update
poetry build
poetry publish

casini venv
per attivare quello giusto:
source $(poetry env info --path)/bin/activate

poetry env info -p
rm -rf `poetry env info -p`
poetry env use python



Esempio:

```json
{
  "tenant": "rapallo",
  "comune": {
    "nome": "Comune di Rapallo"
  },
  "db": {},
  "keycloak": {
    "realm": "rapallo",
    "client_id": "backend"
  },
  "paths": {
    "upload_dir": "/data/rapallo/uploads",
    "template_dir": "/data/rapallo/templates"
  }
}
