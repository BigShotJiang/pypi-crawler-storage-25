from fastapi import APIRouter, Depends, HTTPException
from typing import Callable, Sequence
from enum import Enum
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from .response_schema import (
    IDeleteResponseBase,
    IGetResponseBase,
    IPostResponseBase,
    IPutResponseBase,
    IResponseList,
    create_list_response,
    create_response,
)


def create_crud_router(
    *,
    crud,
    read_schema: type,
    create_schema: type | None = None,
    update_schema: type | None = None,
    prefix: str = "",
    tags: Sequence[str | Enum] | None = None,
    open_db_dependency: Callable | None = None,
    enable_list: bool = True,
    enable_get: bool = True,
    enable_create: bool = True,
    enable_update: bool = True,
    enable_delete: bool = True,
    enable_soft_delete: bool = False,
) -> APIRouter:
    """
    Factory per generare router CRUD standardizzati.

    Parametri:
    - crud: istanza di CRUDBase
    - read_schema: schema Pydantic per la lettura (obbligatorio)
    - create_schema: schema Pydantic per la creazione (richiesto se enable_create=True)
    - update_schema: schema Pydantic per l'aggiornamento (richiesto se enable_update=True)
    - open_db_dependency: dependency FastAPI che apre la sessione DB
    - enable_*: flag per abilitare/disabilitare singole operazioni
    """

    if enable_create and create_schema is None:
        raise ValueError("create_schema è obbligatorio quando enable_create=True")

    if enable_update and update_schema is None:
        raise ValueError("update_schema è obbligatorio quando enable_update=True")

    router = APIRouter(prefix=prefix, tags=tags or [])

    db_dep = open_db_dependency or (lambda: None)

    # -------------------------
    # LIST
    # -------------------------
    if enable_list:
        @router.get("/", response_model=IResponseList[read_schema])
        async def list_items(_: None = Depends(db_dep)):
            items = await crud.get_multi()
            return create_list_response(items)

    # -------------------------
    # GET
    # -------------------------
    if enable_get:
        @router.get("/{id}", response_model=IGetResponseBase[read_schema])
        async def get_item(
            id: UUID | str | int,
            _: None = Depends(db_dep),
        ):
            obj = await crud.get(id=id)
            if not obj:
                raise HTTPException(status_code=404, detail="Not found")
            return create_response(obj)

    # -------------------------
    # CREATE
    # -------------------------
    if enable_create:
        @router.post("/", response_model=IPostResponseBase[read_schema])
        async def create_item(
            payload: create_schema,
            _: None = Depends(db_dep),
        ):
            obj = await crud.create(obj_in=payload)
            return create_response(obj)

    # -------------------------
    # UPDATE
    # -------------------------
    if enable_update:
        @router.put("/{id}", response_model=IPutResponseBase[read_schema])
        async def update_item(
            id: UUID | str | int,
            payload: update_schema,
            _: None = Depends(db_dep),
        ):
            obj = await crud.get_required(id=id)
            obj = await crud.update(db_obj=obj, obj_in=payload)
            return create_response(obj)

    # -------------------------
    # DELETE
    # -------------------------
    if enable_delete:
        @router.delete("/{id}", response_model=IDeleteResponseBase[None])
        async def delete_item(
            id: UUID | str | int,
            _: None = Depends(db_dep),
        ):
            deleted = await crud.delete(id=id)
            if not deleted:
                raise HTTPException(status_code=404, detail="Not found")
            return create_response(None)

    # -------------------------
    # SOFT DELETE
    # -------------------------
    if enable_soft_delete:
        @router.delete("/soft/{id}", response_model=IDeleteResponseBase[None])
        async def soft_delete_item(
            id: UUID | str | int,
            _: None = Depends(db_dep),
        ):
            deleted = await crud.soft_delete(id=id)
            if not deleted:
                raise HTTPException(status_code=404, detail="Not found")
            return create_response(None)

    return router