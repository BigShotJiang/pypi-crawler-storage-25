#resolvers.py
from __future__ import annotations

from pathlib import Path

from pydantic import SecretStr
from typing import Literal

from .models import (
    EmailConfig,
    KeycloakAdminConfig,
    OidcBffConfig,
    PagopaConfig,
    ProtocolloConfig,
    TenantConfig,
    UiConfig,
)


def _read_secret_file(path: str | None) -> str | None:
    if not path:
        return None

    value = Path(path).read_text(encoding="utf-8").strip()
    return value or None


def _tenant_label(tenant_cfg: TenantConfig) -> str:
    return tenant_cfg.name or "<unknown>"


def _pick_model_or_settings(
    model,
    field_name: str,
    settings,
    settings_attr: str,
):
    if field_name in model.model_fields_set:
        return getattr(model, field_name)
    return getattr(settings, settings_attr, None)


def _pick_secret_or_settings(
    model,
    field_name: str,
    settings,
    settings_attr: str,
    settings_file_attr: str | None = None,
) -> str | None:
    if field_name in model.model_fields_set:
        secret = getattr(model, field_name)
        if secret is None:
            return None
        return secret.get_secret_value()

    value = getattr(settings, settings_attr, None)
    if value is not None:
        return value

    if settings_file_attr is not None:
        return _read_secret_file(getattr(settings, settings_file_attr, None))

    return None

def resolve_oidc_config(
    tenant_cfg: TenantConfig,
    settings,
) -> OidcBffConfig:
    kc = tenant_cfg.keycloak
    tenant_label = _tenant_label(tenant_cfg)

    base_url = _pick_model_or_settings(kc, "base_url", settings, "keycloak_base_url")
    if base_url is None:
        raise ValueError(
            f"Configurazione OIDC incompleta per tenant '{tenant_label}': "
            "base_url non disponibile"
        )
    base_url = base_url.rstrip("/")

    realm = _pick_model_or_settings(kc, "realm", settings, "keycloak_realm")
    if realm is None:
        raise ValueError(
            f"Configurazione OIDC incompleta per tenant '{tenant_label}': "
            "realm non disponibile"
        )

    public_base_url = _pick_model_or_settings(
        kc,
        "public_base_url",
        settings,
        "public_base_url",
    )
    if public_base_url is None:
        raise ValueError(
            f"Configurazione OIDC incompleta per tenant '{tenant_label}': "
            "public_base_url non disponibile"
        )
    public_base_url = public_base_url.rstrip("/")

    oidc_client_id = _pick_model_or_settings(
        kc,
        "oidc_client_id",
        settings,
        "oidc_client_id",
    )
    if oidc_client_id is None:
        raise ValueError(
            f"Configurazione OIDC incompleta per tenant '{tenant_label}': "
            "oidc_client_id non disponibile"
        )

    oidc_scope = _pick_model_or_settings(
        kc,
        "oidc_scope",
        settings,
        "oidc_scope",
    )
    if oidc_scope is None:
        raise ValueError(
            f"Configurazione OIDC incompleta per tenant '{tenant_label}': "
            "oidc_scope non disponibile"
        )

    oidc_redirect_path = _pick_model_or_settings(
        kc,
        "oidc_redirect_path",
        settings,
        "oidc_redirect_path",
    )
    if oidc_redirect_path is None:
        raise ValueError(
            f"Configurazione OIDC incompleta per tenant '{tenant_label}': "
            "oidc_redirect_path non disponibile"
        )

    oidc_validate_leeway = _pick_model_or_settings(
        kc,
        "oidc_validate_leeway",
        settings,
        "oidc_validate_leeway",
    )
    if oidc_validate_leeway is None:
        oidc_validate_leeway = 60

    verify_tls = _pick_model_or_settings(
        kc,
        "verify_tls",
        settings,
        "verify_tls",
    )
    if verify_tls is None:
        verify_tls = True

    issuer = f"{base_url}/realms/{realm}"
    redirect_uri = f"{public_base_url}{oidc_redirect_path}"

    return OidcBffConfig(
        realm=realm,
        issuer=issuer,
        client_id=oidc_client_id,
        redirect_uri=redirect_uri,
        post_logout_redirect_uri=public_base_url,
        scope=oidc_scope,
        validate_leeway=oidc_validate_leeway,
        verify_tls=verify_tls,
    )

def resolve_admin_config(
    tenant_cfg: TenantConfig,
    settings,
) -> KeycloakAdminConfig:
    kc = tenant_cfg.keycloak
    tenant_label = _tenant_label(tenant_cfg)

    base_url = _pick_model_or_settings(kc, "base_url", settings, "keycloak_base_url")
    if base_url is None:
        raise ValueError(
            f"Configurazione keycloak admin incompleta per tenant '{tenant_label}': "
            "base_url non disponibile"
        )
    server_url = base_url.rstrip("/") + "/"

    realm = _pick_model_or_settings(kc, "realm", settings, "keycloak_realm")
    if realm is None:
        raise ValueError(
            f"Configurazione keycloak admin incompleta per tenant '{tenant_label}': "
            "realm non disponibile"
        )

    admin_client_id = _pick_model_or_settings(
        kc,
        "admin_client_id",
        settings,
        "admin_client_id",
    )
    if admin_client_id is None:
        raise ValueError(
            f"Configurazione keycloak admin incompleta per tenant '{tenant_label}': "
            "admin_client_id non disponibile"
        )

    client_secret = _pick_secret_or_settings(
        kc,
        "admin_client_secret",
        settings,
        "admin_client_secret",
        "admin_client_secret_file",
    )
    if client_secret is None:
        raise ValueError(
            f"Configurazione keycloak admin incompleta per tenant '{tenant_label}': "
            "admin_client_secret non disponibile"
        )

    verify_tls = _pick_model_or_settings(
        kc,
        "verify_tls",
        settings,
        "verify_tls",
    )
    if verify_tls is None:
        verify_tls = True

    return KeycloakAdminConfig(
        server_url=server_url,
        realm_name=realm,
        client_id=admin_client_id,
        client_secret_key=SecretStr(client_secret),
        verify_tls=verify_tls,
    )




def resolve_email_config(
    tenant_cfg: TenantConfig,
    settings,
    channel: Literal["email", "pec"] = "email",
) -> EmailConfig:
    tenant_label = _tenant_label(tenant_cfg)

    if channel == "email":
        tenant_email = tenant_cfg.email
        host_attr = "smtp_host"
        port_attr = "smtp_port"
        username_attr = "smtp_username"
        password_attr = "smtp_password"
        password_file_attr = "smtp_password_file"
        use_tls_attr = "smtp_use_tls"
        from_address_attr = "smtp_from_address"
        channel_label = "email"
    else:
        tenant_email = tenant_cfg.pec
        host_attr = "pec_host"
        port_attr = "pec_port"
        username_attr = "pec_username"
        password_attr = "pec_password"
        password_file_attr = "pec_password_file"
        use_tls_attr = "pec_use_tls"
        from_address_attr = "pec_from_address"
        channel_label = "pec"

    if tenant_email is None:
        class _EmptyConfig:
            model_fields_set: set[str] = set()
            smtp_host = None
            smtp_port = None
            username = None
            password = None
            use_tls = None
            from_address = None

        tenant_email = _EmptyConfig()

    smtp_host = _pick_model_or_settings(
        tenant_email,
        "smtp_host",
        settings,
        host_attr,
    )
    if smtp_host is None:
        raise ValueError(
            f"Configurazione {channel_label} incompleta per tenant '{tenant_label}': "
            "smtp_host non disponibile"
        )

    smtp_port = _pick_model_or_settings(
        tenant_email,
        "smtp_port",
        settings,
        port_attr,
    )
    if smtp_port is None:
        raise ValueError(
            f"Configurazione {channel_label} incompleta per tenant '{tenant_label}': "
            "smtp_port non disponibile"
        )

    username = _pick_model_or_settings(
        tenant_email,
        "username",
        settings,
        username_attr,
    )
    if username is None:
        raise ValueError(
            f"Configurazione {channel_label} incompleta per tenant '{tenant_label}': "
            "username non disponibile"
        )

    password = _pick_secret_or_settings(
        tenant_email,
        "password",
        settings,
        password_attr,
        password_file_attr,
    )
    if password is None:
        raise ValueError(
            f"Configurazione {channel_label} incompleta per tenant '{tenant_label}': "
            "password non disponibile"
        )

    use_tls = _pick_model_or_settings(
        tenant_email,
        "use_tls",
        settings,
        use_tls_attr,
    )
    if use_tls is None:
        use_tls = True

    from_address = _pick_model_or_settings(
        tenant_email,
        "from_address",
        settings,
        from_address_attr,
    )
    if from_address is None:
        raise ValueError(
            f"Configurazione {channel_label} incompleta per tenant '{tenant_label}': "
            "from_address non disponibile"
        )

    return EmailConfig(
        smtp_host=smtp_host,
        smtp_port=smtp_port,
        username=username,
        password=SecretStr(password),
        use_tls=use_tls,
        from_address=from_address,
    )


def resolve_pagopa_config(
    tenant_cfg: TenantConfig,
    settings,
) -> PagopaConfig:
    tenant_pagopa = tenant_cfg.pagopa
    tenant_label = _tenant_label(tenant_cfg)

    if tenant_pagopa is None:
        class _EmptyConfig:
            model_fields_set: set[str] = set()
            username = None
            password = None
            print_username = None
            print_password = None
            service_url = None
            codipa = None

        tenant_pagopa = _EmptyConfig()

    username = _pick_model_or_settings(
        tenant_pagopa,
        "username",
        settings,
        "pagopa_username",
    )
    if username is None:
        raise ValueError(
            f"Configurazione PagoPA incompleta per tenant '{tenant_label}': "
            "username non disponibile"
        )

    password = _pick_secret_or_settings(
        tenant_pagopa,
        "password",
        settings,
        "pagopa_password",
        "pagopa_password_file",
    )
    if password is None:
        raise ValueError(
            f"Configurazione PagoPA incompleta per tenant '{tenant_label}': "
            "password non disponibile"
        )

    print_username = _pick_model_or_settings(
        tenant_pagopa,
        "print_username",
        settings,
        "pagopa_print_username",
    )
    if print_username is None:
        raise ValueError(
            f"Configurazione PagoPA incompleta per tenant '{tenant_label}': "
            "print_username non disponibile"
        )

    print_password = _pick_secret_or_settings(
        tenant_pagopa,
        "print_password",
        settings,
        "pagopa_print_password",
        "pagopa_print_password_file",
    )
    if print_password is None:
        raise ValueError(
            f"Configurazione PagoPA incompleta per tenant '{tenant_label}': "
            "print_password non disponibile"
        )

    service_url = _pick_model_or_settings(
        tenant_pagopa,
        "service_url",
        settings,
        "pagopa_service_url",
    )
    if service_url is None:
        raise ValueError(
            f"Configurazione PagoPA incompleta per tenant '{tenant_label}': "
            "service_url non disponibile"
        )

    codipa = _pick_model_or_settings(
        tenant_pagopa,
        "codipa",
        settings,
        "pagopa_codipa",
    )
    if codipa is None:
        raise ValueError(
            f"Configurazione PagoPA incompleta per tenant '{tenant_label}': "
            "codipa non disponibile"
        )

    return PagopaConfig(
        username=username,
        password=SecretStr(password),
        print_username=print_username,
        print_password=SecretStr(print_password),
        service_url=service_url,
        codipa=codipa,
    )


def resolve_protocollo_config(
    tenant_cfg: TenantConfig,
    settings,
) -> ProtocolloConfig:
    tenant_protocollo = tenant_cfg.protocollo
    tenant_label = _tenant_label(tenant_cfg)

    if tenant_protocollo is None:
        class _EmptyConfig:
            model_fields_set: set[str] = set()
            base_url = None
            username = None
            password = None

        tenant_protocollo = _EmptyConfig()

    base_url = _pick_model_or_settings(
        tenant_protocollo,
        "base_url",
        settings,
        "protocollo_base_url",
    )
    if base_url is None:
        raise ValueError(
            f"Configurazione protocollo incompleta per tenant '{tenant_label}': "
            "base_url non disponibile"
        )

    username = _pick_model_or_settings(
        tenant_protocollo,
        "username",
        settings,
        "protocollo_username",
    )
    if username is None:
        raise ValueError(
            f"Configurazione protocollo incompleta per tenant '{tenant_label}': "
            "username non disponibile"
        )

    password = _pick_secret_or_settings(
        tenant_protocollo,
        "password",
        settings,
        "protocollo_password",
        "protocollo_password_file",
    )
    if password is None:
        raise ValueError(
            f"Configurazione protocollo incompleta per tenant '{tenant_label}': "
            "password non disponibile"
        )

    return ProtocolloConfig(
        base_url=base_url,
        username=username,
        password=SecretStr(password),
    )
    
# in resolvers.py

DEFAULT_UI = UiConfig(theme='theme-default', scheme='light')

def resolve_ui_config(tenant_cfg: TenantConfig) -> UiConfig:
    return tenant_cfg.ui or DEFAULT_UI