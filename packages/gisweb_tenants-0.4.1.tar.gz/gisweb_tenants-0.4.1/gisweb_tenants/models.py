from __future__ import annotations
from typing import Literal

from pydantic import AnyUrl, BaseModel, ConfigDict, SecretStr, field_validator


class ComuneConfig(BaseModel):
    nome: str

    model_config = ConfigDict(extra="forbid")

    @field_validator("nome")
    @classmethod
    def validate_nome(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("comune.nome vuoto")
        return value


class DbConfig(BaseModel):
    url: SecretStr

    model_config = ConfigDict(extra="forbid")

    @field_validator("url")
    @classmethod
    def validate_url(cls, value: SecretStr) -> SecretStr:
        url = value.get_secret_value().strip()
        if not url.startswith("postgresql"):
            raise ValueError("db.url deve essere PostgreSQL")
        return SecretStr(url)


class KeycloakConfig(BaseModel):
    base_url: str | None = None
    realm: str | None = None
    public_base_url: str | None = None

    oidc_client_id: str | None = None
    oidc_scope: str | None = None
    oidc_redirect_path: str | None = None
    oidc_validate_leeway: int | None = None

    admin_client_id: str | None = None
    admin_client_secret: SecretStr | None = None

    verify_tls: bool | None = None

    model_config = ConfigDict(extra="forbid")

    @field_validator(
        "base_url",
        "realm",
        "public_base_url",
        "oidc_client_id",
        "oidc_scope",
        "oidc_redirect_path",
        "admin_client_id",
    )
    @classmethod
    def validate_non_empty(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        if not value:
            raise ValueError("campo keycloak vuoto")
        return value


class EmailConfig(BaseModel):
    smtp_host: str | None = None
    smtp_port: int = 587
    username: str | None = None
    password: SecretStr | None = None
    use_tls: bool = True
    from_address: str | None = None

    model_config = ConfigDict(extra="forbid")

class PagopaConfig(BaseModel):
    username: str
    password: SecretStr
    print_username: str
    print_password: SecretStr
    service_url: AnyUrl | None = None
    codipa: str | None = None

    model_config = ConfigDict(extra="forbid")

class ProtocolloConfig(BaseModel):
    base_url: AnyUrl
    username: str
    password: SecretStr

    model_config = ConfigDict(extra="forbid")


class UiConfig(BaseModel):
    theme: str
    scheme: Literal['light', 'dark'] = 'light'

    model_config = ConfigDict(extra="forbid")


class TenantConfig(BaseModel):
    name: str | None = None

    comune: ComuneConfig | None = None
    db: DbConfig
    keycloak: KeycloakConfig
    ui: UiConfig | None = None

    pagopa: PagopaConfig | None = None
    email: EmailConfig | None = None
    pec: EmailConfig | None = None

    protocollo: ProtocolloConfig | None = None

    model_config = ConfigDict(extra="forbid")
    
    


#################
# Config runtime
#################

class OidcBffConfig(BaseModel):
    realm: str
    issuer: str
    client_id: str
    redirect_uri: str
    post_logout_redirect_uri: str
    scope: str
    validate_leeway: int = 60
    verify_tls: bool = True

    model_config = ConfigDict(extra="forbid")


class KeycloakAdminConfig(BaseModel):
    server_url: str
    realm_name: str
    client_id: str
    client_secret_key: SecretStr
    verify_tls: bool = True

    model_config = ConfigDict(extra="forbid")