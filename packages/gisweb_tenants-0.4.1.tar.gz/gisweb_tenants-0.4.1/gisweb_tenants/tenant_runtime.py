from .models import EmailConfig, KeycloakAdminConfig, OidcBffConfig, PagopaConfig, ProtocolloConfig, UiConfig
from .service import TenantRuntimeConfigService
from .tenant_context import TenantContextConfig


class TenantRuntimeConfig(TenantContextConfig):
    def __init__(
        self,
        tenants_source: str,
        *,
        settings,
        tenant_header: str = "X-Tenant",
        user_id_header: str = "X-UserId",
        request_id_header: str = "X-Request-Id",
        default_tenant: str | None = None,
        default_user_id: str | None = None,
        allowed_tenants: set[str] | None = None,
        strict_whitelist: bool = False,
    ):
        super().__init__(
            tenants_source=tenants_source,
            tenant_header=tenant_header,
            user_id_header=user_id_header,
            request_id_header=request_id_header,
            default_tenant=default_tenant,
            default_user_id=default_user_id,
            allowed_tenants=allowed_tenants,
            strict_whitelist=strict_whitelist,
        )

        self.settings = settings

        # self.service è già creato dal parent TenantContextConfig
        # lo riusiamo direttamente per evitare una seconda istanza con cache separata
        self.runtime = TenantRuntimeConfigService(
            self.service,
            settings,
        )

    # =========================
    # API pubblica
    # =========================
    
    def get_ui(self, tenant: str) -> UiConfig:
        return self.runtime.get_ui(tenant)
    
    def get_oidc(self, tenant: str) -> OidcBffConfig:
        return self.runtime.get_oidc(tenant)

    def get_keycloak_admin(self, tenant: str) -> KeycloakAdminConfig:
        return self.runtime.get_keycloak_admin(tenant)

    def get_email(self, tenant: str) -> EmailConfig:
        return self.runtime.get_email(tenant, channel="email")

    def get_pec(self, tenant: str) -> EmailConfig:
        return self.runtime.get_email(tenant, channel="pec")

    def get_pagopa(self, tenant: str) -> PagopaConfig:
        return self.runtime.get_pagopa(tenant)

    def get_protocollo(self, tenant: str) -> ProtocolloConfig:
        return self.runtime.get_protocollo(tenant)

    # =========================
    # Utility
    # =========================

    def list_tenants(self) -> list[str]:
        return self.service.list_tenants()

    def invalidate(self, tenant: str | None = None) -> None:
        self.runtime.invalidate(tenant)