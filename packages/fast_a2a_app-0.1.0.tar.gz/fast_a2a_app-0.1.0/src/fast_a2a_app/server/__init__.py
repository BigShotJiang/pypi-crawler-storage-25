"""fast_a2a_app.server — A2A protocol adapter."""
from .route import (
    build_a2a_app,
    build_invoke,
    build_stream_invoke,
    build_conversation_prefix,
    ensure_context_marker,
    ConfigurableAgentExecutor,
    ContextAwareRequestContextBuilder,
)
from .task_store import A2ATaskStore, RedisTaskStore
from .utils import report_progress

__all__ = [
    # App factory
    "build_a2a_app",
    # Invoke wrappers
    "build_invoke",
    "build_stream_invoke",
    # Prompt helpers
    "build_conversation_prefix",
    "ensure_context_marker",
    # Low-level
    "ConfigurableAgentExecutor",
    "ContextAwareRequestContextBuilder",
    "A2ATaskStore",
    "RedisTaskStore",
    "report_progress",
]
