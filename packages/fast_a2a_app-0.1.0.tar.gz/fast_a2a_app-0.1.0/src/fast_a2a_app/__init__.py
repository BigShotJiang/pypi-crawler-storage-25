"""
fast_a2a_app — Drop-in A2A server and chat UI for any FastAPI application.

fast_a2a_app is framework-agnostic: it works with pydantic-ai, LangChain,
LlamaIndex, plain Anthropic/OpenAI API calls, or any custom logic that
can expose an ``async (str) -> str`` function or an async generator.

Typical usage::

    from fastapi import FastAPI
    from fast_a2a_app import a2a_ui, build_a2a_app, build_invoke, build_stream_invoke

    app = FastAPI()

    app.mount("/a2a", build_a2a_app(
        invoke=build_invoke(my_agent_fn),
        stream_invoke=build_stream_invoke(my_streaming_agent_fn),
        agent_name="My Agent",
        agent_description="Does cool things",
        agent_version="1.0.0",
        agent_url="http://localhost:8000/a2a/",
    ))

    app.mount("/", a2a_ui)

Call ``report_progress("step 2/5…")`` from anywhere inside your agent
(including tools) to push live status updates to the chat UI.
"""
from .server import (
    A2ATaskStore,
    ConfigurableAgentExecutor,
    ContextAwareRequestContextBuilder,
    RedisTaskStore,
    build_a2a_app,
    build_invoke,
    build_stream_invoke,
    build_conversation_prefix,
    ensure_context_marker,
    report_progress,
)
from .ui import a2a_ui

__version__ = "0.1.0"

__all__ = [
    # Server
    "build_a2a_app",
    "build_invoke",
    "build_stream_invoke",
    "build_conversation_prefix",
    "ensure_context_marker",
    "ConfigurableAgentExecutor",
    "ContextAwareRequestContextBuilder",
    "A2ATaskStore",
    "RedisTaskStore",
    "report_progress",
    # UI
    "a2a_ui",
    # Meta
    "__version__",
]
