# Changelog

## 0.1.0 — 2026-05-05

Initial release.

### Added

- `fast_a2a_app.server` — A2A protocol adapter extracted and cleaned from ppt-agent
  - `build_a2a_app()` factory assembling a Starlette ASGI app
  - `build_agent_invoke()` / `build_agent_stream_invoke()` wrappers for pydantic-ai
  - `report_progress()` for live tool status updates via ContextVar
  - `RedisTaskStore` with context-id indexing and cross-instance cancel signals
  - `ConfigurableAgentExecutor` with `on_task_start` / `on_task_cancel` hooks
  - `ContextAwareRequestContextBuilder` for multi-turn history injection
  - `debug` parameter for controlling error verbosity
  - `redis_url` parameter replacing hard-coded config import
- `fast_a2a_app.ui` — Self-contained browser chat UI (no build step, no npm)
  - Streaming SSE with real-time progress indicator
  - localStorage persistence (context ID, transcript, active task)
  - Page-reload recovery via `tasks/resubscribe` and `tasks/get` fallback
  - Markdown rendering with DOMPurify sanitisation
  - Collapsible agent card panel
- `examples/holiday_planner/` — Full example application
  - Holiday planning agent with 4 tools: destinations, itinerary, budget, essentials
  - FastAPI app wiring agent + fast_a2a_app server + fast_a2a_app UI
