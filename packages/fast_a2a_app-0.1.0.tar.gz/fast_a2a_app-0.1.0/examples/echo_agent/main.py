"""
main.py — Echo Agent

Run with:
    uvicorn main:app --reload --port 8000

Open http://localhost:8000/ — no API key required.
Requires a Redis server for conversation history (see examples/.env.example).
"""
from __future__ import annotations

import os

from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from fast_a2a_app import a2a_ui, build_a2a_app, build_invoke, build_stream_invoke
from agent import invoke, stream_invoke

load_dotenv()

APP_BASE_URL = os.getenv("APP_BASE_URL", "http://localhost:8000")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

app = FastAPI(title="Echo Agent", version="0.1.0")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}


agent_card = AgentCard(
    name="Echo Agent",
    description="Reflects your message back, word by word.",
    version="0.1.0",
    url=f"{APP_BASE_URL}/a2a/",
    capabilities=AgentCapabilities(streaming=True),
    default_input_modes=["text"],
    default_output_modes=["text"],
    skills=[
        AgentSkill(
            id="echo",
            name="Echo",
            description="Streams your message back to you word by word.",
        ),
    ],
)

app.mount(
    "/a2a",
    build_a2a_app(
        agent_card=agent_card,
        invoke=build_invoke(invoke),
        stream_invoke=build_stream_invoke(stream_invoke),
        redis_url=REDIS_URL,
    ),
)

app.mount("/", a2a_ui)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
