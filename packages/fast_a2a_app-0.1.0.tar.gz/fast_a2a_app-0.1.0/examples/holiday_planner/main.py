"""
main.py — Holiday Planner FastAPI application

fast_a2a_app is framework-agnostic: build_invoke / build_stream_invoke accept any
``async (str) -> str`` function or ``async (str) -> AsyncIterable[str]`` generator.
The thin adapter below bridges pydantic-ai's agent.run() interface to that contract.

Because build_stream_invoke sets up the report_progress() ContextVar before calling
the generator, report_progress() calls from agent tools still reach the chat UI as
live working-status SSE events — no framework-specific plumbing needed.

Run with:
    uvicorn main:app --reload --port 8000
"""
from __future__ import annotations

import os
from collections.abc import AsyncIterable
from contextlib import asynccontextmanager

from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from fast_a2a_app import a2a_ui, build_a2a_app, build_invoke, build_stream_invoke

load_dotenv()

APP_BASE_URL = os.getenv("APP_BASE_URL", "http://localhost:8000")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
DEBUG = os.getenv("DEBUG", "true").lower() in ("1", "true", "yes")

# Import after dotenv so ANTHROPIC_API_KEY is set before the anthropic client
# is instantiated inside agent.py.
from agent import holiday_agent  # noqa: E402


# ── pydantic-ai → fast_a2a_app adapter ─────────────────────────────────────────────

async def _invoke(prompt: str) -> str:
    result = await holiday_agent.run(prompt)
    return str(result.output).strip()


async def _stream_invoke(prompt: str) -> AsyncIterable[str]:
    # pydantic-ai's run_stream() stops at the first text output, skipping any
    # tool calls that follow. run() executes the full tool-call chain first.
    # build_stream_invoke has already set up _progress_cb so report_progress()
    # calls from tools flow to the SSE layer as non-final working-status events.
    result = await holiday_agent.run(prompt)
    text = str(result.output).strip()
    if text:
        yield text


# ── App ────────────────────────────────────────────────────────────────────────


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield


app = FastAPI(
    title="Holiday Planner Agent",
    description="AI-powered holiday planning via the A2A protocol",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["ops"])
async def health() -> dict:
    return {"status": "ok"}


@app.get("/ready", tags=["ops"])
async def ready() -> dict:
    return {"status": "ready"}


agent_card = AgentCard(
    name="Holiday Planner",
    description=(
        "AI-powered travel assistant that crafts personalised holiday itineraries, "
        "destination recommendations, budget estimates, and travel essentials."
    ),
    version="0.1.0",
    url=f"{APP_BASE_URL}/a2a/",
    capabilities=AgentCapabilities(streaming=True),
    default_input_modes=["text"],
    default_output_modes=["text"],
    skills=[
        AgentSkill(
            id="recommend_destinations",
            name="Recommend destinations",
            description="Suggests 2-3 tailored holiday destinations with pros, cons, and highlights.",
        ),
        AgentSkill(
            id="create_itinerary",
            name="Create itinerary",
            description="Builds a day-by-day plan with restaurant picks and local tips.",
        ),
        AgentSkill(
            id="estimate_budget",
            name="Estimate budget",
            description="Provides a cost breakdown table per person per day.",
        ),
        AgentSkill(
            id="travel_essentials",
            name="Travel essentials",
            description="Covers visa requirements, health advice, weather, and packing tips.",
        ),
    ],
)

app.mount(
    "/a2a",
    build_a2a_app(
        agent_card=agent_card,
        invoke=build_invoke(_invoke),
        stream_invoke=build_stream_invoke(_stream_invoke),
        redis_url=REDIS_URL,
        debug=DEBUG,
    ),
)

app.mount("/", a2a_ui)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
