"""
agent.py — Holiday planning agent

A pydantic-ai agent that helps users plan their perfect holiday.
The agent gathers preferences through conversation and uses its tools to
build destination recommendations, day-by-day itineraries, and budget estimates.

All tools call ``report_progress()`` so the A2A chat UI shows a live status
indicator while the agent is working through each step.

Authentication:
  - Set AZURE_AI_KEY for API-key auth.
  - Leave AZURE_AI_KEY empty to use AzureCliCredential (managed identity,
    CLI login, environment credentials — whatever is available in the environment).
"""
from __future__ import annotations

import json
import os

from openai import AsyncOpenAI
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIModel

from fast_a2a_app.server import report_progress

# ── Azure OpenAI config ───────────────────────────────────────────────────────

AZURE_AI_ENDPOINT = os.environ.get("AZURE_AI_ENDPOINT", "")
AZURE_AI_DEPLOYMENT = os.environ.get("AZURE_AI_DEPLOYMENT", "gpt-4o")
AZURE_AI_KEY = os.environ.get("AZURE_AI_KEY", "")
# Set AZURE_AI_BASE_URL explicitly to override; otherwise AZURE_AI_ENDPOINT
# is used as-is (the full OpenAI-compatible path including any /openai/v1/).
AZURE_AI_BASE_URL = os.environ.get(
    "AZURE_AI_BASE_URL",
    f"{AZURE_AI_ENDPOINT.rstrip('/')}/" if AZURE_AI_ENDPOINT else "",
)


def _build_client() -> AsyncOpenAI:
    if AZURE_AI_KEY:
        api_key = AZURE_AI_KEY
    else:
        from azure.identity import AzureCliCredential, get_bearer_token_provider
        api_key = get_bearer_token_provider(
            AzureCliCredential(), "https://ai.azure.com/.default"
        )
    return AsyncOpenAI(
        base_url=AZURE_AI_BASE_URL,
        api_key=api_key,
    )


_client = _build_client()
_model = OpenAIModel(AZURE_AI_DEPLOYMENT, openai_client=_client)

# ── Agent definition ──────────────────────────────────────────────────────────

holiday_agent = Agent(
    model=_model,
    system_prompt="""You are an expert holiday planning assistant with deep knowledge
of travel destinations worldwide. You help users plan their perfect holiday by
understanding their preferences and creating personalised itineraries.

Your workflow:
1. Greet the user warmly and ask about their holiday vision — destination ideas,
   travel dates, duration, budget range, number of travellers, and interests
   (culture, nature, food, adventure, relaxation, etc.).
2. Once you have enough information, use recommend_destinations to suggest 2-3
   destinations that match their preferences, with pros and cons for each.
3. When the user picks a destination, use create_itinerary to build a
   day-by-day plan tailored to their interests and duration.
4. Use estimate_budget to give them a realistic cost breakdown.
5. Answer follow-up questions about visas, packing, local tips, etc.

Be enthusiastic, specific, and practical. Include local gems, not just tourist traps.
If the user changes their mind or asks for alternatives, adapt gracefully.""",
    end_strategy="exhaustive",
)


# ── Tools ─────────────────────────────────────────────────────────────────────


@holiday_agent.tool_plain
async def recommend_destinations(
    interests: str,
    duration_days: int,
    budget_level: str,
    travel_month: str,
) -> str:
    """Generate 2-3 tailored destination recommendations.

    Args:
        interests: Comma-separated list of interests (culture, food, beach, hiking, etc.)
        duration_days: Total trip length in days
        budget_level: 'budget', 'moderate', or 'luxury'
        travel_month: Month of travel (e.g. 'July', 'December')
    """
    report_progress(f"Finding destinations for {duration_days}-day {budget_level} trip in {travel_month}…")

    prompt = f"""Generate exactly 2-3 holiday destination recommendations as a JSON array.

Context:
- Interests: {interests}
- Duration: {duration_days} days
- Budget level: {budget_level}
- Travel month: {travel_month}

For each destination return:
{{
  "name": "City, Country",
  "tagline": "One-line hook",
  "why_it_fits": "2-3 sentences matching their interests/budget/season",
  "highlight": "The single must-do experience",
  "consideration": "One honest trade-off or challenge",
  "best_for": "Type of traveller this suits most"
}}

Return ONLY the JSON array, no markdown."""

    response = await _client.chat.completions.create(
        model=AZURE_AI_DEPLOYMENT,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    raw = (response.choices[0].message.content or "").strip()

    try:
        destinations = json.loads(raw)
        lines = [f"**Destination Recommendations for a {duration_days}-day {budget_level} trip:**\n"]
        for i, d in enumerate(destinations, 1):
            lines.append(f"### {i}. {d['name']}")
            lines.append(f"*{d['tagline']}*\n")
            lines.append(f"**Why it fits:** {d['why_it_fits']}")
            lines.append(f"**Must-do:** {d['highlight']}")
            lines.append(f"**Consider:** {d['consideration']}")
            lines.append(f"**Best for:** {d['best_for']}\n")
        return "\n".join(lines)
    except (json.JSONDecodeError, KeyError):
        return raw


@holiday_agent.tool_plain
async def create_itinerary(
    destination: str,
    duration_days: int,
    interests: str,
    pace: str = "moderate",
) -> str:
    """Build a detailed day-by-day itinerary for the chosen destination.

    Args:
        destination: City and country (e.g. 'Lisbon, Portugal')
        duration_days: Number of days at this destination
        interests: Comma-separated interests to prioritise
        pace: 'relaxed', 'moderate', or 'packed'
    """
    report_progress(f"Building {duration_days}-day itinerary for {destination}…")

    prompt = f"""Create a {duration_days}-day holiday itinerary for {destination}.

Traveller interests: {interests}
Pace preference: {pace}

Format as markdown with:
- A brief intro paragraph (2 sentences)
- One section per day: "## Day N: [Theme]"
  - Morning, Afternoon, Evening subsections
  - 2-3 specific activities per time slot with vivid 1-line descriptions
  - One restaurant recommendation per day with a dish to try
  - One local tip per day (something most tourists miss)
- A "Getting Around" tip at the end

Be specific — use real place names, real restaurants, real neighbourhoods.
Keep it exciting and practical."""

    response = await _client.chat.completions.create(
        model=AZURE_AI_DEPLOYMENT,
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    )
    return (response.choices[0].message.content or "").strip()


@holiday_agent.tool_plain
async def estimate_budget(
    destination: str,
    duration_days: int,
    travellers: int,
    budget_level: str,
) -> str:
    """Provide a realistic cost breakdown for the trip.

    Args:
        destination: City and country
        duration_days: Length of stay
        travellers: Number of people travelling
        budget_level: 'budget', 'moderate', or 'luxury'
    """
    report_progress(f"Calculating budget for {travellers} traveller(s) in {destination}…")

    prompt = f"""Create a realistic budget estimate for:
- Destination: {destination}
- Duration: {duration_days} days
- Travellers: {travellers} person(s)
- Budget style: {budget_level}

Return a markdown table with these categories and per-person daily costs:
| Category | Per Person / Day | {duration_days}-Day Total (per person) | Notes |
|----------|-----------------|----------------------------------------|-------|
| Accommodation | | | |
| Food & drink | | | |
| Local transport | | | |
| Activities & entrance fees | | | |
| Miscellaneous | | | |
| **TOTAL** | | | |

After the table, add:
- A "Money-saving tip" specific to this destination
- A "Splurge on this" recommendation worth the extra cost
- Currency and current exchange rate note

Use realistic local prices, not tourist-trap prices."""

    response = await _client.chat.completions.create(
        model=AZURE_AI_DEPLOYMENT,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    return (response.choices[0].message.content or "").strip()


@holiday_agent.tool_plain
async def get_travel_essentials(
    destination: str,
    nationality: str,
    travel_month: str,
) -> str:
    """Return visa, health, weather, and packing essentials for the destination.

    Args:
        destination: City and country
        nationality: Traveller's passport nationality (e.g. 'German', 'British')
        travel_month: Month of travel
    """
    report_progress(f"Looking up travel essentials for {destination}…")

    prompt = f"""Provide practical travel essentials for a {nationality} citizen visiting {destination} in {travel_month}.

Format as markdown with these sections:

## Visa & Entry
- Visa requirement for {nationality} citizens
- How to apply (if needed), cost, processing time

## Health & Safety
- Recommended vaccinations
- Any health precautions
- Emergency number

## Weather in {travel_month}
- Typical temperature range
- What to expect (rain, sun, humidity)
- Any weather warnings

## Packing Essentials
- 5 items specific to this destination and season
- What NOT to bring (local customs or restrictions)

## Practical Tips
- Local currency and payment habits
- Tipping culture
- One cultural do and one cultural don't

Keep it concise and actionable."""

    response = await _client.chat.completions.create(
        model=AZURE_AI_DEPLOYMENT,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    return (response.choices[0].message.content or "").strip()
