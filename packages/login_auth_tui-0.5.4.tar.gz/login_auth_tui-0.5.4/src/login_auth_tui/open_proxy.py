import json
import os
import sys


def open_proxy() -> None:
    if "OPEN_PROXY_OUTPUT" in os.environ:
        with open(os.environ["OPEN_PROXY_OUTPUT"], "w") as f:
            json.dump(sys.argv[1:], f)
    else:
        args = ["open"] + sys.argv[1:]
        os.execl("/usr/bin/open", *args)  # noqa S606
