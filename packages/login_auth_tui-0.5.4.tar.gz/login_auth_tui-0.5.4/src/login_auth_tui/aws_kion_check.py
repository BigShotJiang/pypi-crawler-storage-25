import logging
import subprocess

logger = logging.getLogger("aws-kion-check")


def aws_kion_check(profile: str) -> None:
    logger.info(f"Checking kion credentials for {profile}")
    output = subprocess.check_output(["aws", "--profile", profile, "s3", "ls"])  # noqa S603,S607
    logger.debug("Output from aws s3 ls")
    logger.debug(output)
