"""End-to-end tests for parts2jitx.

Split into local tests (no network) and network tests (hit LCSC/EasyEDA).
Run with: python tests/test_end_to_end.py [--local-only]
"""

import json
import subprocess
import sys
import tempfile
from pathlib import Path


def run(cmd: list[str], **kwargs) -> subprocess.CompletedProcess:
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    return result


# ---------------------------------------------------------------------------
# Local tests (no network required)
# ---------------------------------------------------------------------------

def test_kicad_stdin():
    """Convert a minimal KiCad footprint from stdin."""
    print("--- Test: KiCad conversion from stdin ---")
    minimal_fp = '(footprint "TestPart" (pad "1" smd rect (at -1.0 0.0) (size 0.6 1.0) (layers "F.Cu" "F.Paste" "F.Mask")) (pad "2" smd rect (at 1.0 0.0) (size 0.6 1.0) (layers "F.Cu" "F.Paste" "F.Mask")))'

    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "TestPart"],
        input=minimal_fp,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"
    assert "class TestPart" in result.stdout, "Class not in output"
    assert "Port()" in result.stdout, "No ports"
    assert "jitx.Component" in result.stdout, "Missing jitx.Component"
    assert "BoxSymbol" in result.stdout, "Missing BoxSymbol"

    print(f"  Generated {len(result.stdout)} bytes")
    print("  PASS\n")


def test_kicad_dump_pads():
    """Parse pads from a minimal footprint via --dump-pads."""
    print("--- Test: KiCad --dump-pads ---")
    minimal_fp = '(footprint "TestPart" (pad "1" smd rect (at -1.0 0.0) (size 0.6 1.0) (layers "F.Cu")) (pad "2" smd rect (at 1.0 0.0) (size 0.6 1.0) (layers "F.Cu")))'

    result = run(
        ["parts2jitx-kicad", "--stdin", "--dump-pads"],
        input=minimal_fp,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"

    data = json.loads(result.stdout)
    pads = data["pads"]
    assert len(pads) == 2, f"Expected 2 pads, got {len(pads)}"
    assert pads[0]["name"] == "1"
    assert pads[1]["name"] == "2"
    assert pads[0]["shape"] == "rect"
    assert pads[0]["x"] == -1.0
    assert pads[1]["x"] == 1.0

    print(f"  Parsed {len(pads)} pads correctly")
    print("  PASS\n")


def test_kicad_file_roundtrip():
    """Write a .kicad_mod to disk, convert to .py, verify output."""
    print("--- Test: KiCad file → JITX file ---")
    fp_content = """(footprint "SOT23_3"
        (pad "1" smd rect (at -0.95 -1.0) (size 0.6 0.7) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "2" smd rect (at 0.95 -1.0) (size 0.6 0.7) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "3" smd rect (at 0.0 1.0) (size 0.6 0.7) (layers "F.Cu" "F.Paste" "F.Mask"))
    )"""

    with tempfile.TemporaryDirectory() as tmpdir:
        fp_path = Path(tmpdir) / "sot23.kicad_mod"
        out_path = Path(tmpdir) / "sot23.py"
        fp_path.write_text(fp_content)

        result = run([
            "parts2jitx-kicad", str(fp_path),
            "--class-name", "MyTransistor",
            "--manufacturer", "Nexperia",
            "--mpn", "BC847B",
            "--ref-prefix", "Q",
            "-o", str(out_path),
        ])
        assert result.returncode == 0, f"Failed: {result.stderr}"
        assert out_path.exists(), "Output file not created"

        code = out_path.read_text()
        assert "class MyTransistor(jitx.Component)" in code
        assert 'manufacturer = "Nexperia"' in code
        assert 'mpn = "BC847B"' in code
        assert 'reference_designator_prefix = "Q"' in code
        assert code.count("Port()") == 3, f"Expected 3 ports, got {code.count('Port()')}"

        print(f"  Output: {len(code)} bytes, 3 ports, class MyTransistor")
        print("  PASS\n")


def test_kicad_complex_footprint():
    """Convert a more complex footprint with thermal pad and through-hole."""
    print("--- Test: Complex footprint (thermal pad + thru-hole) ---")
    fp_content = """(footprint "QFN_Example"
        (pad "1" smd rect (at -1.5 -0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "2" smd rect (at -1.5 -0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "3" smd rect (at -1.5 0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "4" smd rect (at -1.5 0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "5" smd rect (at -0.75 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "6" smd rect (at -0.25 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "7" smd rect (at 0.25 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "8" smd rect (at 0.75 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "9" smd rect (at 1.5 0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "10" smd rect (at 1.5 0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "11" smd rect (at 1.5 -0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "12" smd rect (at 1.5 -0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "13" smd rect (at 0.75 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "14" smd rect (at 0.25 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "15" smd rect (at -0.25 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "16" smd rect (at -0.75 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "17" smd rect (at 0.0 0.0) (size 1.7 1.7) (layers "F.Cu" "F.Paste" "F.Mask"))
    )"""

    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "QFN16_EP"],
        input=fp_content,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"
    code = result.stdout
    assert "class QFN16_EP" in code
    assert code.count("Port()") == 17, f"Expected 17 ports, got {code.count('Port()')}"

    print(f"  Generated {len(code)} bytes, 17 ports (16 signal + 1 thermal)")
    print("  PASS\n")


def test_python_import():
    """Verify the package imports correctly."""
    print("--- Test: Python import ---")
    from parts2jitx import __version__
    from parts2jitx.lcsc_lookup import lcsc_stock, get_footprint, get_pinout
    from parts2jitx.kicad_to_jitx import parse_kicad_mod, extract_pads

    assert __version__ == "0.1.0"
    assert callable(lcsc_stock)
    assert callable(get_footprint)
    assert callable(get_pinout)
    assert callable(parse_kicad_mod)
    assert callable(extract_pads)

    print(f"  Version: {__version__}")
    print("  All public functions importable")
    print("  PASS\n")


# ---------------------------------------------------------------------------
# Network tests (require LCSC API access)
# ---------------------------------------------------------------------------

def test_lcsc_stock_lookup():
    """LCSC stock/pricing lookup."""
    print("--- Test: LCSC stock lookup (C165948) ---")
    result = run(["parts2jitx-lcsc", "C165948", "--json"])
    assert result.returncode == 0, f"Failed: {result.stderr}"

    data = json.loads(result.stdout)
    stock = data["stock"]

    assert stock["lcsc"] == "C165948"
    assert stock["mpn"], "Missing MPN"
    assert stock["manufacturer"], "Missing manufacturer"
    assert isinstance(stock["stock"], (int, float))
    assert len(stock["prices"]) > 0, "No pricing data"

    print(f"  Part: {stock['mpn']} ({stock['manufacturer']})")
    print(f"  Stock: {stock['stock']:,}")
    print(f"  Price: ${stock['prices'][0]['price_usd']:.4f}")
    print("  PASS\n")


def test_lcsc_footprint_download():
    """KiCad footprint download from LCSC/EasyEDA."""
    print("--- Test: LCSC footprint download (C165948) ---")
    with tempfile.TemporaryDirectory() as tmpdir:
        outpath = Path(tmpdir) / "test.kicad_mod"
        result = run(["parts2jitx-lcsc", "C165948", "--footprint", "-o", str(outpath)])
        assert result.returncode == 0, f"Failed: {result.stderr}"
        assert outpath.exists(), "Footprint file not created"

        content = outpath.read_text()
        assert "(pad " in content, "No pads found in footprint"

        print(f"  File: {len(content)} bytes, {content.count('(pad ')} pads")
        print("  PASS\n")


def test_full_pipeline():
    """Full pipeline: LCSC download → KiCad → JITX conversion."""
    print("--- Test: Full pipeline (C165948) ---")
    with tempfile.TemporaryDirectory() as tmpdir:
        fp_path = Path(tmpdir) / "usb_c.kicad_mod"
        result = run(["parts2jitx-lcsc", "C165948", "--footprint", "-o", str(fp_path)])
        assert result.returncode == 0, f"Download failed: {result.stderr}"
        assert fp_path.exists(), "Footprint not created"

        out_path = Path(tmpdir) / "usb_c.py"
        result = run([
            "parts2jitx-kicad", str(fp_path),
            "--class-name", "USB_C_16P",
            "--manufacturer", "Korean Hroparts Elec",
            "--mpn", "TYPE-C-31-M-12",
            "-o", str(out_path),
        ])
        assert result.returncode == 0, f"Conversion failed: {result.stderr}"

        code = out_path.read_text()
        assert "class USB_C_16P" in code
        assert "jitx.Component" in code
        assert "Port()" in code
        assert 'mpn = "TYPE-C-31-M-12"' in code

        print(f"  Output: {len(code)} bytes, {code.count('Port()')} ports")
        print("  PASS\n")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    local_only = "--local-only" in sys.argv

    local_tests = [
        test_python_import,
        test_kicad_stdin,
        test_kicad_dump_pads,
        test_kicad_file_roundtrip,
        test_kicad_complex_footprint,
    ]

    network_tests = [
        test_lcsc_stock_lookup,
        test_lcsc_footprint_download,
        test_full_pipeline,
    ]

    tests = local_tests if local_only else local_tests + network_tests

    if local_only:
        print("Running local tests only (no network)\n")
    else:
        print("Running all tests (local + network)\n")

    passed = 0
    failed = 0
    skipped_network = 0

    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            err = str(e)
            # If a network test fails due to connectivity, mark as skip not fail
            if test in network_tests and ("403" in err or "timeout" in err.lower()
                    or "connection" in err.lower() or "not created" in err.lower()
                    or "No pins" in err):
                print(f"  SKIP (network unavailable): {e}\n")
                skipped_network += 1
            else:
                print(f"  FAIL: {e}\n")
                failed += 1

    print(f"{'='*40}")
    parts = [f"{passed} passed"]
    if failed:
        parts.append(f"{failed} failed")
    if skipped_network:
        parts.append(f"{skipped_network} skipped (network)")
    print(f"Results: {', '.join(parts)}")

    if failed:
        sys.exit(1)
    print("All tests passed!" if not skipped_network else "All reachable tests passed!")
