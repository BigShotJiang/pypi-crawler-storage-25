"""parts2jitx — Import electronic part data and convert to JITX component code."""

__version__ = "0.1.0"
