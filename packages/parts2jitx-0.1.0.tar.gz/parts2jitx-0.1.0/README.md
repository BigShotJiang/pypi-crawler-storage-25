# parts2jitx

Import electronic part data and convert it to [JITX](https://www.jitx.com) Python component code.

Supports LCSC/EasyEDA part lookup and KiCad footprint conversion.

## Install

```bash
pip install parts2jitx
```

## CLI Tools

### parts2jitx-lcsc

Look up LCSC/JLCPCB parts: real-time stock, pricing, datasheet URLs, and KiCad footprint download via EasyEDA.

```bash
# Check stock and pricing
parts2jitx-lcsc C165948

# Download KiCad footprint
parts2jitx-lcsc C165948 --footprint -o usb_c.kicad_mod

# Get pinout data
parts2jitx-lcsc C165948 --pinout

# Everything at once (JSON output)
parts2jitx-lcsc C165948 --all -o usb_c.kicad_mod --json
```

### parts2jitx-kicad

Convert KiCad `.kicad_mod` footprint files to JITX Python component code. Works with any `.kicad_mod` file — not just ones from LCSC/EasyEDA.

```bash
# Basic conversion
parts2jitx-kicad footprint.kicad_mod

# With metadata
parts2jitx-kicad footprint.kicad_mod \
    --class-name USB_C_16P \
    --manufacturer "Molex" \
    --mpn "2012670005" \
    -o components/connectors/molex_2012670005.py

# From stdin
echo '(footprint ...)' | parts2jitx-kicad --stdin

# Debug: dump parsed pad data as JSON
parts2jitx-kicad footprint.kicad_mod --dump-pads
```

### Full pipeline example

```bash
# 1. Download footprint from LCSC
parts2jitx-lcsc C165948 --footprint -o kicad_footprints/usb_c.kicad_mod

# 2. Convert to JITX component
parts2jitx-kicad kicad_footprints/usb_c.kicad_mod \
    --class-name USB_C_16P \
    --manufacturer "Korean Hroparts Elec" \
    --mpn "TYPE-C-31-M-12" \
    -o src/components/connectors/usb_c_16p.py
```

## Python API

```python
from parts2jitx.lcsc_lookup import lcsc_stock, get_footprint, get_pinout

# Stock and pricing
info = lcsc_stock("C165948")
print(info["mpn"], info["stock"], info["prices"])

# Download footprint
kicad_content = get_footprint("C165948", output_path="usb_c.kicad_mod")

# Get pinout
pins = get_pinout("C165948")
for pin in pins:
    print(pin["number"], pin["name"])
```

## License

MIT
