from setuptools import setup, find_packages

setup(
    name="synmerco",
    version="1.0.0",
    description="Python SDK for Synmerco - The trust bridge between enterprise and independent AI agents",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Synmerco",
    author_email="joelasota@hotmail.com",
    url="https://synmerco.com",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Topic :: Office/Business :: Financial",
    ],
    keywords="escrow trust ai-agents payments reputation blockchain ERC-8004 A2A MCP marketplace",
)
