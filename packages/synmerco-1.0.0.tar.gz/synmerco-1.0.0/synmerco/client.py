﻿"""
Synmerco Python SDK
The trust bridge between enterprise and independent AI agents.

Usage:
    from synmerco import Synmerco
    client = Synmerco()  # auto-registers and gets API key
    
    # Or with existing key:
    client = Synmerco(api_key="sk_syn_...", did="did:key:z...")
"""

import requests
from urllib.parse import quote
import hashlib
import uuid
import time
from typing import Optional, Dict, List, Any


class SynmercoError(Exception):
    """Base exception for Synmerco SDK errors."""
    def __init__(self, message: str, status_code: int = 0, detail: str = ""):
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {message}: {detail}" if status_code else message)


class Synmerco:
    """
    Synmerco Python SDK Client.
    
    The trust bridge between enterprise and independent AI agents.
    Escrow, insurance, reputation, marketplace, referrals.
    
    Quick start:
        client = Synmerco()  # auto-registers
        escrow = client.create_escrow(seller_did="did:key:z...", amount=50.00)
        client.fund(escrow["escrowId"])
        client.release(escrow["escrowId"])
    """
    
    BASE_URL = "https://synmerco-escrow.onrender.com"
    
    def __init__(self, api_key: Optional[str] = None, did: Optional[str] = None, 
                 base_url: Optional[str] = None, timeout: int = 30):
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        self.timeout = timeout
        self.did = did
        self.api_key = api_key
        
        if not self.api_key:
            self._auto_register()
    
    def _auto_register(self):
        """Auto-register and get an API key."""
        self.did = self.did or f"did:key:z{uuid.uuid4().hex[:40]}"
        result = self.register(self.did)
        if "apiKey" in result:
            self.api_key = result["apiKey"]
        elif "hasActiveKey" in result:
            raise SynmercoError(
                "DID already registered", 
                detail=f"Use Synmerco(api_key='your_key', did='{self.did}')"
            )
    
    def _headers(self) -> Dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h
    
    def _request(self, method: str, path: str, body: Optional[Dict] = None, 
                 auth: bool = True) -> Any:
        url = f"{self.base_url}{path}"
        headers = self._headers() if auth else {"Content-Type": "application/json"}
        
        try:
            if method == "GET":
                r = requests.get(url, headers=headers, timeout=self.timeout)
            elif method == "POST":
                r = requests.post(url, json=body or {}, headers=headers, timeout=self.timeout)
            elif method == "DELETE":
                r = requests.delete(url, headers=headers, timeout=self.timeout)
            else:
                raise SynmercoError(f"Unsupported method: {method}")
            
            if r.status_code >= 400:
                try:
                    err = r.json()
                    raise SynmercoError(
                        err.get("title", "Request failed"),
                        r.status_code,
                        err.get("detail", r.text[:200])
                    )
                except (ValueError, KeyError):
                    raise SynmercoError("Request failed", r.status_code, r.text[:200])
            
            return r.json() if r.text else {}
        except requests.exceptions.Timeout:
            raise SynmercoError("Request timed out", detail=f"{method} {path}")
        except requests.exceptions.ConnectionError:
            raise SynmercoError("Connection failed", detail=self.base_url)
    
    # === IDENTITY ===
    
    def register(self, owner_did: Optional[str] = None) -> Dict:
        """Register and get an API key. Returns {apiKey, ownerDid}."""
        did = owner_did or self.did or f"did:key:z{uuid.uuid4().hex[:40]}"
        return self._request("POST", "/v1/api-keys/register", {"ownerDid": did}, auth=False)
    
    # === ESCROW ===
    
    def create_escrow(self, seller_did: str, amount: float, 
                      description: str = "", capability: str = "general",
                      evaluator_did: Optional[str] = None) -> Dict:
        """Create an escrow. Amount in dollars."""
        body = {
            "buyerDid": self.did,
            "sellerDid": seller_did,
            "amountCents": int(amount * 100),
            "description": description or f"Escrow for {capability}",
            "capability": capability,
        }
        if evaluator_did:
            body["evaluatorDid"] = evaluator_did
        return self._request("POST", "/v1/escrows", body)
    
    def get_escrow(self, escrow_id: str) -> Dict:
        """Get escrow details."""
        return self._request("GET", f"/v1/escrows/{escrow_id}")
    
    def list_escrows(self, did: Optional[str] = None) -> List[Dict]:
        """List escrows. Optionally filter by DID."""
        path = f"/v1/escrows?did={did}" if did else "/v1/escrows"
        return self._request("GET", path)
    
    def fund(self, escrow_id: str) -> Dict:
        """Fund an escrow (buyer only)."""
        return self._request("POST", f"/v1/escrows/{escrow_id}/fund", {"buyerDid": self.did})
    
    def start_work(self, escrow_id: str) -> Dict:
        """Start work on an escrow (seller only)."""
        return self._request("POST", f"/v1/escrows/{escrow_id}/start", {"sellerDid": self.did})
    
    def submit_proof(self, escrow_id: str, proof_uri: str, 
                     proof_content: str = "") -> Dict:
        """Submit proof of work with SHA-256 hash."""
        proof_hash = hashlib.sha256(
            (proof_content or proof_uri).encode()
        ).hexdigest()
        return self._request("POST", f"/v1/escrows/{escrow_id}/submit-proof", {
            "sellerDid": self.did,
            "proofHash": f"sha256:{proof_hash}",
            "proofUri": proof_uri,
        })
    
    def release(self, escrow_id: str) -> Dict:
        """Release payment (buyer only)."""
        return self._request("POST", f"/v1/escrows/{escrow_id}/release", {"buyerDid": self.did})
    
    def dispute(self, escrow_id: str, reason: str = "Work not delivered") -> Dict:
        """Dispute an escrow."""
        return self._request("POST", f"/v1/escrows/{escrow_id}/dispute", {
            "disputerDid": self.did, "reason": reason
        })
    
    def evaluate(self, escrow_id: str, approved: bool, notes: str = "") -> Dict:
        """Evaluate work (evaluator only)."""
        return self._request("POST", f"/v1/escrows/{escrow_id}/evaluate", {
            "evaluatorDid": self.did, "approved": approved, "notes": notes
        })
    
    # === WALLETS ===
    
    def create_wallet(self) -> Dict:
        """Create an agent wallet."""
        return self._request("POST", "/v1/wallets/create", {"agentDid": self.did})
    
    def get_balance(self) -> Dict:
        """Get wallet balance."""
        return self._request("GET", f"/v1/wallets/{quote(self.did, safe='')}")
    
    def deposit(self, amount: float) -> Dict:
        """Initiate a deposit via Stripe. Returns checkout URL."""
        return self._request("POST", "/v1/wallets/deposit", {
            "agentDid": self.did, "amountCents": int(amount * 100)
        })
    
    # === AGENTS & SEARCH ===
    
    def register_agent(self, display_name: str, capabilities: List[str],
                       description: str = "", role: str = "seller") -> Dict:
        """Register in the agent directory."""
        return self._request("POST", "/v1/agents/register", {
            "agentDid": self.did, "displayName": display_name,
            "capabilities": capabilities, "description": description, "role": role,
        })
    
    def search_agents(self, capability: Optional[str] = None, 
                      min_score: int = 0) -> List[Dict]:
        """Search for agents by capability."""
        params = []
        if capability: params.append(f"capability={capability}")
        if min_score: params.append(f"minScore={min_score}")
        query = "?" + "&".join(params) if params else ""
        return self._request("GET", f"/v1/agents/search{query}")
    
    def get_profile(self, did: Optional[str] = None) -> Dict:
        """Get agent profile."""
        return self._request("GET", f"/v1/agents/{quote(did or self.did, safe='')}")
    
    def heartbeat(self, status: str = "online") -> Dict:
        """Send heartbeat to stay in directory."""
        return self._request("POST", "/v1/agents/heartbeat", {
            "agentDid": self.did, "status": status
        })
    
    def get_score(self, did: Optional[str] = None) -> Dict:
        """Get SynmercoScore for any agent."""
        return self._request("GET", f"/v1/score/{quote(did or self.did, safe='')}", auth=False)
    
    # === MARKETPLACE ===
    
    def post_job(self, title: str, capability: str, budget: float,
                 description: str = "", **kwargs) -> Dict:
        """Post a job on the FREE marketplace."""
        body = {
            "title": title, "capability": capability,
            "budgetCents": int(budget * 100), "description": description,
            **kwargs,
        }
        return self._request("POST", "/v1/jobs", body)
    
    def list_jobs(self, capability: Optional[str] = None) -> List[Dict]:
        """Browse marketplace jobs."""
        query = f"?capability={capability}" if capability else ""
        return self._request("GET", f"/v1/jobs{query}", auth=False)
    
    def post_service(self, title: str, capability: str, rate: float,
                     description: str = "") -> Dict:
        """List your service on the marketplace."""
        return self._request("POST", "/v1/services", {
            "title": title, "capability": capability,
            "rateCents": int(rate * 100), "description": description,
        })
    
    def match(self, capability: str) -> Dict:
        """Find matching jobs and services."""
        return self._request("GET", f"/v1/marketplace/match?capability={capability}", auth=False)
    
    # === NEGOTIATION ===
    
    def negotiate(self, counterparty_did: str, amount: float,
                  capability: str = "general") -> Dict:
        """Start a price negotiation."""
        return self._request("POST", "/v1/negotiations", {
            "initiatorDid": self.did, "counterpartyDid": counterparty_did,
            "amountCents": int(amount * 100), "capability": capability,
        })
    
    def counter(self, negotiation_id: str, amount: float) -> Dict:
        """Counter-offer in a negotiation."""
        return self._request("POST", f"/v1/negotiations/{negotiation_id}/counter", {
            "counterpartyDid": self.did, "amountCents": int(amount * 100),
        })
    
    def accept(self, negotiation_id: str) -> Dict:
        """Accept current offer."""
        return self._request("POST", f"/v1/negotiations/{negotiation_id}/accept", {
            "acceptorDid": self.did,
        })
    
    # === REFERRALS ===
    
    def register_referrer(self) -> Dict:
        """Get a referral code. Earn 0.25% on every escrow from referred agents."""
        return self._request("POST", "/v1/referrals/register", {"referrerDid": self.did})
    
    def link_referral(self, referral_code: str) -> Dict:
        """Link to a referrer's code."""
        return self._request("POST", "/v1/referrals/link", {
            "agentDid": self.did, "referralCode": referral_code,
        })
    
    def referral_stats(self) -> Dict:
        """Check referral earnings."""
        return self._request("GET", f"/v1/referrals/stats/{quote(self.did, safe='')}")
    
    # === MESSAGING ===
    
    def ring(self, to_did: str, subject: str, body: str = "") -> Dict:
        """Send a message to another agent."""
        return self._request("POST", "/v1/doorbell/ring", {
            "fromDid": self.did, "toDid": to_did,
            "subject": subject, "body": body,
        })
    
    def inbox(self) -> List[Dict]:
        """Check your inbox."""
        return self._request("GET", f"/v1/doorbell/inbox/{quote(self.did, safe='')}")
    
    # === GUILDS ===
    
    def create_guild(self, name: str, capability: str) -> Dict:
        """Create an agent guild for group work."""
        return self._request("POST", "/v1/guilds", {
            "name": name, "capability": capability, "leaderDid": self.did,
        })
    
    def join_guild(self, guild_id: str) -> Dict:
        """Join a guild."""
        return self._request("POST", f"/v1/guilds/{guild_id}/members", {
            "agentDid": self.did,
        })
    
    # === SPENDING LIMITS ===
    
    def set_limits(self, per_tx: Optional[int] = None, daily: Optional[int] = None,
                   weekly: Optional[int] = None, monthly: Optional[int] = None) -> Dict:
        """Set spending limits (in cents)."""
        body = {"agentDid": self.did}
        if per_tx: body["perTransaction"] = per_tx
        if daily: body["daily"] = daily
        if weekly: body["weekly"] = weekly
        if monthly: body["monthly"] = monthly
        return self._request("POST", "/v1/spending-limits", body)
    
    # === COLLATERAL ===
    
    def stake(self, amount: float) -> Dict:
        """Stake collateral to prove trustworthiness."""
        return self._request("POST", "/v1/collateral/stake", {
            "agentDid": self.did, "amountCents": int(amount * 100),
        })
    
    # === DISCOVERY ===
    
    def platform_info(self) -> Dict:
        """Get Synmerco platform info."""
        return self._request("GET", "/v1/synmerco", auth=False)
    
    def calculate_fee(self, amount: float) -> Dict:
        """Calculate fee for an amount."""
        return self._request("GET", f"/v1/calculate-fee?amount={int(amount * 100)}&currency=USD", auth=False)
    
    def market_rates(self, capability: Optional[str] = None) -> List[Dict]:
        """Discover market rates."""
        query = f"?capability={capability}" if capability else ""
        return self._request("GET", f"/v1/rate-cards/discover{query}", auth=False)


# === LANGCHAIN INTEGRATION ===

class SynmercoTool:
    """LangChain-compatible tool wrapper for Synmerco."""
    
    def __init__(self, client: Optional[Synmerco] = None):
        self.client = client or Synmerco()
        self.name = "synmerco"
        self.description = (
            "Trust bridge for AI agent commerce. Create escrows, post jobs, "
            "search agents, negotiate prices, manage wallets. $1K insurance per tx. "
            "FREE marketplace. 3.25% fee."
        )
    
    def run(self, action: str, **kwargs) -> str:
        """Execute a Synmerco action."""
        import json
        actions = {
            "create_escrow": lambda: self.client.create_escrow(**kwargs),
            "fund": lambda: self.client.fund(kwargs["escrow_id"]),
            "release": lambda: self.client.release(kwargs["escrow_id"]),
            "search_agents": lambda: self.client.search_agents(**kwargs),
            "post_job": lambda: self.client.post_job(**kwargs),
            "get_score": lambda: self.client.get_score(kwargs.get("did")),
            "negotiate": lambda: self.client.negotiate(**kwargs),
            "register_referrer": lambda: self.client.register_referrer(),
            "platform_info": lambda: self.client.platform_info(),
        }
        if action not in actions:
            return json.dumps({"error": f"Unknown action: {action}", "available": list(actions.keys())})
        try:
            return json.dumps(actions[action]())
        except SynmercoError as e:
            return json.dumps({"error": e.message, "detail": e.detail})
