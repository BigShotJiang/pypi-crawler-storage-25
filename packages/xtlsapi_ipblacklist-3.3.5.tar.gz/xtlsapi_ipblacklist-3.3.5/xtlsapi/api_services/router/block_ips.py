import json
import grpc

from xtlsapi.api_services._base import BaseService
from xtlsapi.xray_api.app.router.command import command_pb2
from xtlsapi.xray_api.common.serial import typed_message_pb2


class RouterBlockIps(BaseService):

    def block_ips(
        self,
        ips: list[str],
        inbound_tag: str,
        rule_tag: str = "sourceIpBlock",
        outbound_tag: str = "blocked",
    ):
        try:
            # remove existing rule
            self.routing_stub.RemoveRule(
                command_pb2.RemoveRuleRequest(ruleTag=rule_tag)
            )

            if not ips:
                return None

            config_json = json.dumps({
                "routing": {
                    "rules": [
                        {
                            "ruleTag": rule_tag,
                            "inboundTag": [inbound_tag] if inbound_tag else [],
                            "outboundTag": outbound_tag,
                            "source": ips
                        }
                    ]
                }
            })

            typed_msg = typed_message_pb2.TypedMessage(
                type="xray.app.router.Config",
                value=config_json.encode()
            )

            return self.routing_stub.AddRule(
                command_pb2.AddRuleRequest(
                    config=typed_msg,
                    shouldAppend=True,
                )
            )

        except grpc.RpcError as e:
            raise e