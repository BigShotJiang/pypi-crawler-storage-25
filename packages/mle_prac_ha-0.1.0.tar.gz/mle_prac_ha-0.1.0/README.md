# Machine Learning Engineering Practice

This repository contains various scripts and analyses related to machine learning.

## Installation

```bash
pip install mle-prac-ha
```
