from __future__ import annotations

import logging
import subprocess

from simppl.simple_pipeline import SimplePipeline
from ugbio_core.logger import logger


def print_and_execute(
    command: str,
    output_file: str | None = None,
    simple_pipeline: SimplePipeline | None = None,
    module_name: str | None = None,
    *,
    shell: bool = True,
    log_level: int = logging.INFO,
):
    """
    Print and execute command through simple_pipeline or subprocess

    Parameters
    ----------
    command: str
        shell command as a string
    output_file: str, optional
        output_file to save stdout to
    simple_pipeline: SimplePipeline, optional
        optional simple pipeline object to use as execution engine
    module_name: str, optional
        optional module name to use for simple pipeline
    shell: bool, optional
        whether to use shell for subprocess execution, default True, only relevant if simple_pipeline is None
    log_level: int, optional
        logging level for the command message, default logging.INFO

    raises:
    - subprocess.CalledProcessError: if the command fails
    """
    if simple_pipeline is None:
        logger.log(log_level, command)
        cmd = command if shell else [x.strip() for x in command.strip().split(" ") if x]
        if output_file is not None:
            with open(output_file, "w", encoding="utf-8") as f:
                subprocess.check_call(cmd, stdout=f, shell=shell)
        else:
            subprocess.check_call(cmd, shell=shell)
    elif output_file is not None:
        simple_pipeline.print_and_run(command, out=output_file, module_name=module_name)
    else:
        simple_pipeline.print_and_run(command, module_name=module_name)
