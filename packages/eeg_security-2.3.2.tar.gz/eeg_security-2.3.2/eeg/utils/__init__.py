"""EEG Utility Modules."""
