# FiscalPY

Fiscal utilities in python

## Installation

```bash
pip install fiscalpy
```