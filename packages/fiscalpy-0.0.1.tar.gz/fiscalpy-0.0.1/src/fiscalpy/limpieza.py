import pandas as pd
import numpy as np


def columnas_ingresos_territoriales(df):
    lista_impuestos_muns = ['SOBRETASA AMBIENTAL', 'IMPUESTO PREDIAL UNIFICADO',
        'SOBRETASA A LA GASOLINA', 'IMPUESTO DE INDUSTRIA Y COMERCIO',
        'IMPUESTO COMPLEMENTARIO DE AVISOS Y TABLEROS',
        'IMPUESTO DE DELINEACION', 'SOBRETASA BOMBERIL','IMPUESTO DE ALUMBRADO PUBLICO',
        'TASA PRODEPORTE Y RECREACION', 'ESTAMPILLAS',
        'IMPUESTO DE TRANSPORTE POR OLEODUCTOS Y GASODUCTOS',
        'IMPUESTO SOBRE VEHICULOS AUTOMOTORES']

    lista_impuestos_deptos = ['IMPUESTO SOBRE VEHICULOS AUTOMOTORES',
        'IMPUESTO DE REGISTRO', 
        'IMPUESTO AL CONSUMO DE LICORES, VINOS, APERITIVOS Y SIMILARES',
        'IMPUESTO AL CONSUMO DE CERVEZAS, SIFONES, REFAJOS Y MEZCLAS',
        'IMPUESTO AL CONSUMO DE CIGARRILLOS Y TABACO',
        'SOBRETASA A LA GASOLINA', 'TASA PRODEPORTE Y RECREACION',
        'ESTAMPILLAS',
        'SOBRETASA BOMBERIL'] 

    lista_nt_muns = ['SISTEMA GENERAL DE PARTICIPACIONES', 'RECURSOS DEL SISTEMA DE SEGURIDAD SOCIAL INTEGRAL']
    lista_nt_deptos = ['SISTEMA GENERAL DE PARTICIPACIONES','PARTICIPACION Y DERECHOS POR MONOPOLIO']

    lista_cap_muns = ['RECURSOS DEL BALANCE','EXCEDENTES FINANCIEROS',
        'DIVIDENDOS Y UTILIDADES POR OTRAS INVERSIONES DE CAPITAL']
    lista_cap_deptos = ['RECURSOS DEL BALANCE', 'EXCEDENTES FINANCIEROS',
        'DIVIDENDOS Y UTILIDADES POR OTRAS INVERSIONES DE CAPITAL']

    def funcion_ofpuj1(row):
        col_2 = row['col_2']
        col_3 = row['col_3']
        col_4 = row['col_4']
        col_5 = row['col_5']
        col_6 = row['col_6']
        tipo_entidad = row['Tipo de Entidad']



        if tipo_entidad == 'Municipio':
            if col_3 == 'INGRESOS TRIBUTARIOS':
                if col_5 in lista_impuestos_muns:
                    return col_5.capitalize()
                else:
                    return "Otros ingresos tributarios"
            elif col_3 == 'INGRESOS NO TRIBUTARIOS':
                if col_5 in lista_nt_muns:
                    return col_5.capitalize()
                elif col_4 in lista_nt_muns:
                    return col_4.capitalize()
                else:
                    return "Otros ingresos no tributarios"
            else:
                if "RECURSOS DE CREDITO" in col_3:
                    return "Recursos de crédito"
                elif col_3 in lista_cap_muns:
                    return col_3.capitalize()
                else:
                    return "Otros recursos de capital"

        else:
            if col_3 == 'INGRESOS TRIBUTARIOS':
                if col_5 in lista_impuestos_deptos:
                    return col_5.capitalize()
                else:
                    return "Otros ingresos tributarios"
            elif col_3 == 'INGRESOS NO TRIBUTARIOS':
                if col_5 in lista_nt_deptos:
                    return col_5.capitalize()
                elif col_4 in lista_nt_deptos:
                    return col_4.capitalize()
                else:
                    return "Otros ingresos no tributarios"
            else:
                if "RECURSOS DE CREDITO" in col_3:
                    return "Recursos de crédito"
                elif col_3 in lista_cap_deptos:
                    return col_3.capitalize()
                else:
                    return "Otros recursos de capital"
                
    lista_impuestos_muns = ['SOBRETASA AMBIENTAL', 
                            'IMPUESTO PREDIAL UNIFICADO',
                            'SOBRETASA A LA GASOLINA', 
                            'IMPUESTO DE INDUSTRIA Y COMERCIO',
                            'IMPUESTO COMPLEMENTARIO DE AVISOS Y TABLEROS',
                            'IMPUESTO DE DELINEACION', 
                            'SOBRETASA BOMBERIL',
                            'IMPUESTO DE ALUMBRADO PUBLICO',
                            'TASA PRODEPORTE Y RECREACION', 
                            'ESTAMPILLAS',
                            'IMPUESTO DE TRANSPORTE POR OLEODUCTOS Y GASODUCTOS',
                            'IMPUESTO SOBRE VEHICULOS AUTOMOTORES', 
                            'IMPUESTO AL CONSUMO DE LICORES, VINOS, APERITIVOS Y SIMILARES',
                            'IMPUESTO AL CONSUMO DE CERVEZAS, SIFONES, REFAJOS Y MEZCLAS',
                            'IMPUESTO AL CONSUMO DE CIGARRILLOS Y TABACO',
                            'AVISOS Y TABLEROS',
                            'IMPUESTO AL CONSUMO CERVEZA',
                            'IMPUESTO DE DELINEACIÓN']

    lista_impuestos_deptos = ['IMPUESTO SOBRE VEHICULOS AUTOMOTORES',
                            'IMPUESTO DE ALUMBRADO PUBLICO',
                            'IMPUESTO DE REGISTRO', 
                            'IMPUESTO AL CONSUMO DE LICORES, VINOS, APERITIVOS Y SIMILARES',
                            'IMPUESTO AL CONSUMO DE CERVEZAS, SIFONES, REFAJOS Y MEZCLAS',
                            'IMPUESTO AL CONSUMO DE CIGARRILLOS Y TABACO',
                            'SOBRETASA A LA GASOLINA', 
                            'TASA PRODEPORTE Y RECREACION',
                            'ESTAMPILLAS',
                            'SOBRETASA BOMBERIL',
                            'IMPUESTO PREDIAL UNIFICADO',
                            'IMPUESTO DE INDUSTRIA Y COMERCIO', 
                            'IMPUESTO COMPLEMENTARIO DE AVISOS Y TABLEROS',] 

    taxes = list(set(lista_impuestos_deptos + lista_impuestos_muns))

    lista_nt_muns = ['SISTEMA GENERAL DE PARTICIPACIONES', 'RECURSOS DEL SISTEMA DE SEGURIDAD SOCIAL INTEGRAL']
    lista_nt_deptos = ['SISTEMA GENERAL DE PARTICIPACIONES','PARTICIPACION Y DERECHOS POR MONOPOLIO']

    lista_cap_muns = ['RECURSOS DEL BALANCE',
                    'EXCEDENTES FINANCIEROS',
                    'DIVIDENDOS Y UTILIDADES POR OTRAS INVERSIONES DE CAPITAL', 
                    'UTILIDADES Y EXCEDENTES FINANCIEROS (EMPRESAS INDUSTRIALES, COMERCIALES Y ESTABLECIMIENTOS PÚBLICOS)']

    lista_rec = ['RECURSOS DEL CRÉDITO',
                    'RECURSOS DE CREDITO INTERNO',
                    'RECURSOS DE CREDITO EXTERNO']
    SGP = ['SGP: LIBRE DESTINACIÓN DE PARTICIPACIÓN DE PROPÓSITO GENERAL MUNICIPIOS CATEGORÍAS 4, 5 Y 6',
        'SISTEMA GENERAL DE PARTICIPACIONES',
        ]

    def funcion_ofpuj2(row):
        col2 = row['col_2']
        col3 = row['col_3']
        col4 = row['col_4']
        col5 = row['col_5']
        col7 = row['col_7']

        if col3 == 'INGRESOS TRIBUTARIOS':
            if col5 in taxes:
                return col5.capitalize()
            else:
                return "Otros ingresos tributarios"
        elif col3 == 'INGRESOS NO TRIBUTARIOS':
            if col4 in ['TRANSFERENCIAS', 'TRANSFERENCIAS CORRIENTES']:
                if col7 in SGP:
                    return "Sistema general de participaciones"
                elif col7 == 'FONDO DE SOLIDARIDAD Y GARANTÍAS -FOSYGA-':
                    return "FOSYGA"
                elif col5 in ['SISTEMA GENERAL DE PARTICIPACIONES', 'RECURSOS DEL SISTEMA DE SEGURIDAD SOCIAL INTEGRAL']:
                    return col5.capitalize()
                else:
                    return "Otras transferencias"
            elif col4 in ['PARTICIPACION Y DERECHOS POR MONOPOLIO', 'PARTICIPACIÓN Y DERECHOS POR MONOPOLIO']:
                return "Participación y derechos por monopolio"
            else:
                return "Tasas, multas y contribuciones"
        elif col2 == 'RECURSOS DE CAPITAL':
            if col3 in lista_rec:
                return "Recursos de crédito"
            elif col3 in lista_cap_muns:
                return col3.capitalize()
            else:
                return "Otros recursos de capital"
        else:
            return "Error en clasificación"
        

    def funcion_clas_gen1(row):
        col_2 = row['col_2']
        col_3 = row['col_3']
        col_5 = row['col_5']

        if col_2 == 'RECURSOS DE CAPITAL':
            return col_2.capitalize()
        elif col_3 == 'INGRESOS TRIBUTARIOS':
            return col_3.capitalize()
        elif col_5 == 'SISTEMA GENERAL DE PARTICIPACIONES':
            return col_5.capitalize()
        return "INGRESOS NO TRIBUTARIOS".capitalize()

    def funcion_clas_gen2(row):
        col2 = row['col_2']
        col3 = row['col_3']
        col4 = row['col_4']
        if col2 == 'RECURSOS DE CAPITAL':
            return col2.capitalize()
        elif col3 == 'INGRESOS TRIBUTARIOS':
            return "Recursos propios"
        elif col4 in ['TRANSFERENCIAS', 'TRANSFERENCIAS CORRIENTES']:
            return "Transferencias"
        else:
            return "Recursos propios"
    df['clas_ofpuj'] = df.apply(funcion_ofpuj2, axis=1)
    df['clas_gen1'] = df.apply(funcion_clas_gen1, axis=1)
    df['clas_gen2'] = df.apply(funcion_clas_gen2, axis=1)
    return df

def limpieza_ingresos_territoriales(df):
        df2 = df.copy()
        df2 = df2.rename(columns={'CodigoConcepto':'Código Concepto',
                                'Nombre': 'Concepto'})

        df2['Código Concepto'] = df2['Código Concepto'].astype(str).str.strip()
        df2['Concepto'] = df2['Concepto'].str.strip()
        dictio_con = dict(df2[['Código Concepto', 'Concepto']].set_index('Código Concepto').to_records())

        max_cols = df2['Código Concepto'].str.split('.').map(len).max()

        for i in range(1, max_cols + 1):
                df2[f'col_{i}'] = np.nan

            # crear una columna con splits del código de concepto (lista de números)
        df2['split'] = df2['Código Concepto'].str.split('.')


        for idx, row in df2.iterrows():
            split = row['split']
            n = len(split)
            for i in range(1, n + 1):
                df2.loc[idx, f'col_{i}'] = dictio_con['.'.join(split[:i])]


        df2["lists_tuple"] = df2["split"].apply(tuple)

        sorted_tuples = sorted(df2["lists_tuple"].unique(), key=lambda x: (len(x), x))

        relation = {}

        for i, current_tuple in enumerate(sorted_tuples):
            is_father = False
            for other_tuple in sorted_tuples[i + 1:]:

                if len(other_tuple) <= len(current_tuple) or not other_tuple[:len(current_tuple)] == current_tuple:
                    continue

                is_father = True
                break

            relation[current_tuple] = "father" if is_father else "son"

        def funcion2(row):
            return relation[row['lists_tuple']]
        df2['example'] = df2.apply(funcion2, axis=1)
        sons = df2[df2['example'] == 'son']
        sons = sons.drop(columns=['split', 'lists_tuple', 'example']).reset_index(drop=True)
        sons[[f"col_{i}" for i in range(1, max_cols + 1)]] = sons[[f"col_{i}" for i in range(1, max_cols + 1)]].ffill(axis=1)
        data_ready = sons.groupby(['Año Vigencia',
               'Código DANE', 'Entidad', 'Tipo de Entidad',
               'Departamento', 'col_1', 'col_2', 'col_3', 'col_4', 'col_5',
               'col_6','col_7', 'col_8', 'col_9', 'col_10'])['Total Recaudo'].sum().reset_index()
        return data_ready

def limpieza_gastos_territoriales(df):
    df2 = df.copy()

    df2['Código Concepto'] = df2['Código Concepto'].astype(str).str.strip()
    df2['Concepto'] = df2['Concepto'].str.strip()
    dictio_con = dict(df2[['Código Concepto', 'Concepto']].set_index('Código Concepto').to_records())

    max_cols = df2['Código Concepto'].str.split('.').map(len).max()

    for i in range(1, max_cols + 1):
            df2[f'col_{i}'] = np.nan

        # crear una columna con splits del código de concepto (lista de números)
    df2['split'] = df2['Código Concepto'].str.split('.')


    for idx, row in df2.iterrows():
            split = row['split']
            n = len(split)
            for i in range(1, n + 1):
                df2.loc[idx, f'col_{i}'] = dictio_con['.'.join(split[:i])]


    df2["lists_tuple"] = df2["split"].apply(tuple)

    sorted_tuples = sorted(df2["lists_tuple"].unique(), key=lambda x: (len(x), x))

    relation = {}
    for i, current_tuple in enumerate(sorted_tuples):
            is_father = False
            for other_tuple in sorted_tuples[i + 1:]:

                if len(other_tuple) <= len(current_tuple) or not other_tuple[:len(current_tuple)] == current_tuple:
                    continue

                is_father = True
                break

            relation[current_tuple] = "father" if is_father else "son"

    def funcion2(row):
            return relation[row['lists_tuple']]
    df2['example'] = df2.apply(funcion2, axis=1)
    sons = df2[df2['example'] == 'son']

    sons[['col_1', 'col_2', 'col_3', 'col_4', 'col_5', 'col_6',
        'col_7', 'col_8', 'col_9', 'col_10']] = sons[['col_1', 'col_2', 'col_3', 'col_4', 'col_5', 'col_6',
        'col_7', 'col_8', 'col_9', 'col_10']].ffill(axis=1)
    sons.drop(columns=['split', 'lists_tuple', 'example'], inplace=True)
    sons.reset_index(drop=True, inplace=True)

    sons = sons.groupby(['Año Vigencia', 'Código DANE', 'Entidad', 'Tipo de Entidad',
        'Departamento', 'Region', 'Código Concepto', 'Concepto',
        'Código Vigencia del Gasto', 'Vigencia del Gasto',
        'Código Sección Presupuestal', 'Sección Presupuestal', 'col_1', 'col_2', 'col_3', 'col_4', 'col_5',
        'col_6', 'col_7', 'col_8', 'col_9', 'col_10'])[['Compromisos', 'Obligaciones', 'Pagos']].sum().reset_index()
    
    return sons