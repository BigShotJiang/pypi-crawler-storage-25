# fiveclaw-agent

Local MCP agent for [FiveClaw](https://fiveclaw.com) — AI-powered FiveM development tools.

## What it does

`fiveclaw-agent` runs on your machine alongside your FiveM server. It handles local operations (file search, logs, MySQL, txAdmin, SSH deploy) and relays AI analysis requests to the FiveClaw platform using your API key.

**Local tools** (run on your machine):
- Resource map generation and querying
- File search across Lua/JS resources
- Lua syntax checking
- Log reading
- MySQL query execution
- txAdmin server control (start/stop/restart resources, send console commands)
- SSH deployment to remote servers
- Persistent context memory

**Cloud tools** (powered by FiveClaw, gated by your plan):
- Resource validation and health checks
- Anti-pattern and duplicate code detection
- Export/event flow tracing
- AI code review and test generation
- FiveM native docs search
- Pattern library (scaffold new resources/features)

## Requirements

- Python 3.10+
- A [FiveClaw](https://fiveclaw.com) account with an active subscription
- A FiveClaw API key (generate one at [fiveclaw.com/dashboard/keys](https://fiveclaw.com/dashboard/keys))

## Installation

```bash
pip install fiveclaw-agent

# With SSH deployment support
pip install fiveclaw-agent[ssh]
```

## Setup

1. **Create a `.env` file** in your FiveM project root:

```env
FIVECLAW_API_KEY=fc_live_your_key_here

# Optional — auto-detected if not set
# FIVEM_PROJECT_ROOT=/path/to/your/server

# Optional SSH deployment
# FIVEM_SSH_HOST=1.2.3.4
# FIVEM_SSH_USER=root
# FIVEM_SSH_KEY_PATH=~/.ssh/id_rsa
# FIVEM_REMOTE_RESOURCES=/server-data/resources
```

2. **Add to your Claude config** (`claude_desktop_config.json` or `.mcp.json`):

```json
{
  "mcpServers": {
    "fiveclaw": {
      "url": "http://localhost:5200/mcp"
    }
  }
}
```

3. **Start the agent** in your project directory:

```bash
fiveclaw
```

The agent runs on `http://localhost:5200/mcp` and stays running while you work. Restart it anytime without restarting Claude.

4. **Verify** by asking Claude: *"Run mcp_health to check my FiveClaw connection."*

## Configuration

SSH, txAdmin, and MySQL settings can also be configured on the [FiveClaw dashboard](https://fiveclaw.com/dashboard/server) — the agent fetches them automatically using your API key, so you don't need to duplicate them in `.env`.

## Links

- [FiveClaw Dashboard](https://fiveclaw.com/dashboard)
- [Setup Guide](https://fiveclaw.com/dashboard/download)
- [Pricing](https://fiveclaw.com/pricing)
