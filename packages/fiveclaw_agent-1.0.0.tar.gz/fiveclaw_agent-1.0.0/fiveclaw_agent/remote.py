"""HTTP client — sends tool calls to the FiveClaw VPS for processing."""

import json
import urllib.request
import urllib.error
from typing import Any


class RemoteClient:
    """Authenticated relay to the FiveClaw VPS intelligence API."""

    def __init__(self, api_key: str, api_url: str):
        self.api_key = api_key
        self.api_url = api_url

    def call(self, tool: str, params: dict, files: dict[str, str] | None = None) -> str:
        """
        POST to /api/mcp/tools with the tool name, params, and optional file content.
        Returns the raw JSON string result.
        """
        payload = {
            "tool":   tool,
            "params": params,
            "files":  files or {},
        }

        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            f"{self.api_url}/api/mcp/tools",
            data=data,
            headers={
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                return resp.read().decode()
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            try:
                err = json.loads(body)
            except Exception:
                err = {"error": body}

            if e.code == 401:
                return json.dumps({"error": "Invalid or expired API key. Check your FIVECLAW_API_KEY."})
            if e.code == 402:
                return json.dumps({"error": "Subscription required. Visit https://fiveclaw.gg/pricing"})
            if e.code == 403:
                return json.dumps({"error": err.get("error", "Access denied — your plan may not include this tool.")})
            return json.dumps({"error": f"API error {e.code}: {err.get('error', body[:200])}"})
        except Exception as e:
            return json.dumps({"error": f"Could not reach FiveClaw API: {str(e)}"})
