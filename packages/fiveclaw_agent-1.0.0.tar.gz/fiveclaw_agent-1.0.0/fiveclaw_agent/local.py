"""
Local tool implementations — file I/O, SSH, MySQL, txAdmin.
These run entirely on the user's machine. No source logic is sent to the VPS.
"""

import json
import os
import re
import subprocess
import time
from pathlib import Path
from typing import Optional

from .config import Config


# ─── File collection helpers ──────────────────────────────────────────────────

def collect_resource_files(resources_dir: Path, resource_name: Optional[str] = None) -> dict[str, str]:
    """
    Collect Lua (and JS/TS) source files from one or all resources.
    Returns {relative_path: content} — content capped at 50 KB per file.
    """
    MAX_FILE = 50_000
    files: dict[str, str] = {}

    dirs = (
        [resources_dir / resource_name]
        if resource_name
        else [d for d in resources_dir.iterdir() if d.is_dir()]
    )

    for rdir in dirs:
        if not rdir.exists():
            continue
        for ext in ("*.lua", "*.js", "*.ts"):
            for f in rdir.rglob(ext):
                try:
                    content = f.read_text(errors="ignore")
                    if len(content) > MAX_FILE:
                        content = content[:MAX_FILE] + "\n-- [truncated]"
                    rel = str(f.relative_to(resources_dir.parent))
                    files[rel] = content
                except Exception:
                    pass

    return files


# ─── RepoMap ──────────────────────────────────────────────────────────────────

class RepoMapTool:
    def __init__(self, config: Config):
        self.config = config
        self._cache_file = config.context_dir / "repomap.json"

    async def generate(self) -> str:
        if not self.config.resources_dir.exists():
            return json.dumps({"error": f"Resources directory not found: {self.config.resources_dir}"})

        resources = {}
        for rdir in self.config.resources_dir.iterdir():
            if not rdir.is_dir():
                continue
            info: dict = {"name": rdir.name, "files": [], "exports": [], "events": []}
            for f in rdir.rglob("*.lua"):
                info["files"].append(str(f.relative_to(rdir)))
                try:
                    text = f.read_text(errors="ignore")
                    info["exports"] += re.findall(r'exports\[[\'"](.*?)[\'"]\]', text)
                    info["events"]  += re.findall(r'RegisterNetEvent\([\'"]([^\'"]+)[\'"]', text)
                except Exception:
                    pass
            resources[rdir.name] = info

        result = {"resources": resources, "count": len(resources)}
        self._cache_file.parent.mkdir(parents=True, exist_ok=True)
        self._cache_file.write_text(json.dumps(result, indent=2))
        return json.dumps({"success": True, "resources_count": len(resources)})

    async def query(self, query_type: str, filter: Optional[str] = None) -> str:
        if not self._cache_file.exists():
            return json.dumps({"error": "Run repomap_generate first."})
        data = json.loads(self._cache_file.read_text())
        resources = data.get("resources", {})

        if filter:
            resources = {k: v for k, v in resources.items() if filter.lower() in k.lower()}

        if query_type == "exports":
            out = {k: v.get("exports", []) for k, v in resources.items()}
        elif query_type == "events":
            out = {k: v.get("events", []) for k, v in resources.items()}
        elif query_type == "files":
            out = {k: v.get("files", []) for k, v in resources.items()}
        else:
            out = resources

        return json.dumps(out, indent=2)

    async def show(self) -> str:
        if not self._cache_file.exists():
            return json.dumps({"error": "Run repomap_generate first."})
        return self._cache_file.read_text()


# ─── Search / File info ───────────────────────────────────────────────────────

class FileTool:
    def __init__(self, config: Config):
        self.config = config

    async def search(self, pattern: str, path: Optional[str] = None) -> str:
        search_path = Path(path) if path else self.config.resources_dir
        if not search_path.exists():
            return json.dumps({"error": f"Path not found: {search_path}"})

        matches = []
        for ext in ("*.lua", "*.js", "*.ts", "*.json"):
            for f in search_path.rglob(ext):
                try:
                    for i, line in enumerate(f.read_text(errors="ignore").splitlines(), 1):
                        if re.search(pattern, line, re.IGNORECASE):
                            matches.append({
                                "file": str(f.relative_to(search_path)),
                                "line": i,
                                "content": line.strip()[:200],
                            })
                            if len(matches) >= 100:
                                return json.dumps({"matches": matches, "truncated": True})
                except Exception:
                    pass

        return json.dumps({"matches": matches, "count": len(matches)})

    async def file_info(self, file_path: str) -> str:
        p = Path(file_path)
        if not p.exists():
            p = self.config.project_root / file_path
        if not p.exists():
            return json.dumps({"error": f"File not found: {file_path}"})

        stat = p.stat()
        try:
            lines = len(p.read_text(errors="ignore").splitlines())
        except Exception:
            lines = None

        return json.dumps({
            "path": str(p),
            "size_bytes": stat.st_size,
            "lines": lines,
            "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
        })

    async def syntax_check(self, file_path: str) -> str:
        p = Path(file_path)
        if not p.exists():
            p = self.config.resources_dir / file_path
        if not p.exists():
            return json.dumps({"error": f"File not found: {file_path}"})

        result = subprocess.run(["luac", "-p", str(p)], capture_output=True, text=True)
        if result.returncode == 0:
            return json.dumps({"valid": True, "file": str(p)})
        return json.dumps({"valid": False, "error": result.stderr.strip()})

    async def read_logs(self, lines: int = 100, pattern: Optional[str] = None) -> str:
        if not self.config.logs_dir.exists():
            return json.dumps({"error": f"Logs directory not found: {self.config.logs_dir}"})

        log_files = sorted(self.config.logs_dir.glob("*.log"), key=lambda f: f.stat().st_mtime, reverse=True)
        if not log_files:
            return json.dumps({"error": "No log files found."})

        latest = log_files[0]
        all_lines = latest.read_text(errors="ignore").splitlines()[-lines:]
        if pattern:
            all_lines = [l for l in all_lines if re.search(pattern, l, re.IGNORECASE)]

        return json.dumps({"file": latest.name, "lines": all_lines, "count": len(all_lines)})


# ─── MySQL ────────────────────────────────────────────────────────────────────

class MySQLTool:
    def __init__(self, config: Config):
        self.config = config

    async def query(self, query: str) -> str:
        if not self.config.has_mysql():
            return json.dumps({
                "error": "MySQL not configured.",
                "setup": "Set MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE in your .env",
            })

        result = subprocess.run(["which", "mysql"], capture_output=True)
        if result.returncode != 0:
            return json.dumps({"error": "mysql client not installed."})

        db = self.config.mysql
        cmd = [
            "mysql",
            "-h", db["host"],
            "-P", str(db["port"]),
            "-u", db["user"],
            f"-p{db['password']}",
            "-N", "-e", query, db["database"],
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            return json.dumps({"error": result.stderr.strip()})

        rows = [line.split("\t") for line in result.stdout.strip().splitlines() if line]
        return json.dumps({"success": True, "rows": rows, "count": len(rows), "database": db["database"]})


# ─── txAdmin ──────────────────────────────────────────────────────────────────

class TxAdminTool:
    def __init__(self, config: Config):
        self.config = config

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.config.txadmin_token:
            h["X-TxAdmin-Token"] = self.config.txadmin_token
        return h

    async def server_status(self) -> str:
        import urllib.request, urllib.error
        try:
            req = urllib.request.Request(
                f"{self.config.txadmin_url}/api/server/status",
                headers=self._headers(),
            )
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.read().decode()
        except Exception as e:
            return json.dumps({"error": str(e), "hint": f"Is txAdmin running at {self.config.txadmin_url}?"})

    async def resource_control(self, action: str, resource_name: str) -> str:
        import urllib.request
        payload = json.dumps({"action": action, "resource": resource_name}).encode()
        req = urllib.request.Request(
            f"{self.config.txadmin_url}/api/server-control/command",
            data=payload,
            headers=self._headers(),
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.read().decode()
        except Exception as e:
            return json.dumps({"error": str(e)})

    async def server_console(self, command: str) -> str:
        import urllib.request
        payload = json.dumps({"command": command}).encode()
        req = urllib.request.Request(
            f"{self.config.txadmin_url}/api/server-control/command",
            data=payload,
            headers=self._headers(),
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.read().decode()
        except Exception as e:
            return json.dumps({"error": str(e)})


# ─── Deploy ───────────────────────────────────────────────────────────────────

class DeployTool:
    def __init__(self, config: Config):
        self.config = config

    async def deploy(self, resource_name: str, target: str = "production") -> str:
        source = self.config.resources_dir / resource_name
        if not source.exists():
            return json.dumps({"error": f"Resource not found: {resource_name}"})

        if self.config.has_ssh():
            return await self._deploy_ssh(resource_name, source)

        # Local copy
        remote_res = os.getenv("FIVEM_REMOTE_RESOURCES_DIR", str(self.config.resources_dir))
        target_path = (
            Path(remote_res) / resource_name
            if target in ("production", "txdata")
            else Path(target) / resource_name
        )

        import shutil
        backup_dir = self.config.project_root / "backups" / "deploy"
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_path = backup_dir / f"{resource_name}_{time.strftime('%Y%m%d_%H%M%S')}"

        if target_path.exists():
            shutil.copytree(target_path, backup_path)
            shutil.rmtree(target_path)

        shutil.copytree(source, target_path)
        return json.dumps({
            "success": True, "resource": resource_name,
            "target": str(target_path), "method": "local",
        })

    async def _deploy_ssh(self, resource_name: str, source: Path) -> str:
        try:
            import paramiko
        except ImportError:
            return json.dumps({"error": "paramiko not installed. Run: pip install fiveclaw-agent[ssh]"})

        remote_res = os.getenv("FIVEM_REMOTE_RESOURCES_DIR", "")
        if not remote_res:
            return json.dumps({"error": "FIVEM_REMOTE_RESOURCES_DIR not set."})

        ssh_cfg = self.config.ssh
        remote_target = f"{remote_res.rstrip('/')}/{resource_name}"

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            kw: dict = {"hostname": ssh_cfg["host"], "port": ssh_cfg["port"], "username": ssh_cfg["user"]}
            if ssh_cfg.get("key_path"):
                kw["key_filename"] = ssh_cfg["key_path"]
            client.connect(**kw, timeout=15)
            sftp = client.open_sftp()

            def _upload(local: Path, remote: str):
                try: sftp.mkdir(remote)
                except OSError: pass
                for item in local.iterdir():
                    r = f"{remote}/{item.name}"
                    if item.is_dir(): _upload(item, r)
                    else: sftp.put(str(item), r)

            client.exec_command(f"rm -rf '{remote_target}'")[1].channel.recv_exit_status()
            _upload(source, remote_target)
            sftp.close(); client.close()
            return json.dumps({"success": True, "resource": resource_name, "target": remote_target,
                               "host": ssh_cfg["host"], "method": "ssh"})
        except Exception as e:
            return json.dumps({"error": f"SSH deploy failed: {e}"})

    async def backup(self, resource_name: str) -> str:
        source = self.config.resources_dir / resource_name
        if not source.exists():
            return json.dumps({"error": f"Resource not found: {resource_name}"})

        import shutil
        backup_dir = self.config.project_root / "backups" / "resources"
        backup_dir.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%Y%m%d_%H%M%S")
        dest = backup_dir / f"{resource_name}_{ts}"
        shutil.copytree(source, dest)
        return json.dumps({"success": True, "backup": str(dest), "timestamp": ts})


# ─── Context memory ───────────────────────────────────────────────────────────

class ContextTool:
    def __init__(self, config: Config):
        self._file = config.context_dir / "knowledge.json"
        self._ensure()

    def _ensure(self):
        self._file.parent.mkdir(parents=True, exist_ok=True)
        if not self._file.exists():
            self._file.write_text(json.dumps({"facts": {}, "history": []}))

    def _load(self) -> dict:
        return json.loads(self._file.read_text())

    def _save(self, data: dict):
        self._file.write_text(json.dumps(data, indent=2))

    async def remember(self, key: str, value: str, category: str = "general") -> str:
        data = self._load()
        data["facts"][key] = {"value": value, "category": category, "ts": time.strftime("%Y-%m-%d %H:%M:%S")}
        self._save(data)
        return json.dumps({"saved": key})

    async def recall(self, key: Optional[str] = None) -> str:
        data = self._load()
        if key:
            return json.dumps(data["facts"].get(key, {"error": "Not found"}))
        return json.dumps(data["facts"], indent=2)

    async def search(self, query: str) -> str:
        data = self._load()
        q = query.lower()
        hits = {k: v for k, v in data["facts"].items()
                if q in k.lower() or q in str(v.get("value", "")).lower()}
        return json.dumps(hits, indent=2)

    async def forget(self, key: str) -> str:
        data = self._load()
        if key in data["facts"]:
            del data["facts"][key]
            self._save(data)
            return json.dumps({"deleted": key})
        return json.dumps({"error": f"Key not found: {key}"})

    async def record(self, summary: str, tags: str) -> str:
        data = self._load()
        data.setdefault("history", []).append({
            "summary": summary, "tags": tags.split(","),
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        data["history"] = data["history"][-200:]
        self._save(data)
        return json.dumps({"recorded": True})

    async def history(self, limit: int = 10) -> str:
        data = self._load()
        return json.dumps(data.get("history", [])[-limit:], indent=2)

    async def show(self) -> str:
        return self._file.read_text()
