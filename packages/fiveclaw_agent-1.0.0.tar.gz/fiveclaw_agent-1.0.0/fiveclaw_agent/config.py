"""Configuration for the FiveClaw Agent."""

import os
import json
from pathlib import Path


def load_env_file():
    for candidate in [Path.cwd() / ".env", Path(__file__).parent.parent / ".env"]:
        if candidate.exists():
            with open(candidate) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, value = line.split("=", 1)
                        if key not in os.environ:
                            os.environ[key] = value
            break


class Config:
    def __init__(self):
        load_env_file()

        self.api_key = os.getenv("FIVECLAW_API_KEY", "")
        self.api_url = os.getenv("FIVECLAW_API_URL", "https://fiveclaw.gg").rstrip("/")

        if not self.api_key:
            raise RuntimeError(
                "FIVECLAW_API_KEY is not set.\n"
                "Add it to your .env file: FIVECLAW_API_KEY=fc_live_...\n"
                "Get your key at https://fiveclaw.gg/dashboard/keys"
            )

        # Local project root (auto-detected or explicit)
        env_root = os.getenv("FIVEM_PROJECT_ROOT", "")
        if env_root and Path(env_root).exists():
            self.project_root = Path(env_root)
        else:
            self.project_root = self._detect_project_root()

        resources_override = os.getenv("FIVEM_RESOURCES_DIR", "")
        self.resources_dir = (
            Path(resources_override)
            if resources_override
            else self.project_root / "resources"
        )

        self.logs_dir = self.project_root / "logs"
        self.context_dir = self.project_root / ".fiveclaw" / "context"
        self.context_dir.mkdir(parents=True, exist_ok=True)

        # SSH (for deploy_resource)
        self.ssh = {
            "host":     os.getenv("FIVEM_SSH_HOST", ""),
            "port":     int(os.getenv("FIVEM_SSH_PORT", "22")),
            "user":     os.getenv("FIVEM_SSH_USER", ""),
            "key_path": os.getenv("FIVEM_SSH_KEY", ""),
        }

        # MySQL (direct local connection)
        self.mysql = {
            "host":     os.getenv("MYSQL_HOST",     "127.0.0.1"),
            "port":     int(os.getenv("MYSQL_PORT", "3306")),
            "user":     os.getenv("MYSQL_USER",     ""),
            "password": os.getenv("MYSQL_PASSWORD", ""),
            "database": os.getenv("MYSQL_DATABASE", ""),
        }

        # txAdmin
        self.txadmin_url   = os.getenv("TXADMIN_URL",   "http://localhost:40120")
        self.txadmin_token = os.getenv("TXADMIN_TOKEN", "")

    def has_ssh(self) -> bool:
        return bool(self.ssh["host"] and self.ssh["user"])

    def has_mysql(self) -> bool:
        return bool(self.mysql["user"] and self.mysql["database"])

    def _detect_project_root(self) -> Path:
        check = Path.cwd()
        for _ in range(10):
            if (check / "resources").is_dir() and list((check / "resources").glob("*/fxmanifest.lua")):
                return check
            parent = check.parent
            if parent == check:
                break
            check = parent
        return Path.cwd()
