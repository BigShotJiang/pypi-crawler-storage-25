"""
FiveClaw Agent — local MCP server.

Users run this on their machine and add it to their Claude Desktop config:
  { "fiveclaw": { "url": "http://localhost:5200/mcp" } }

Local tools (file I/O, SSH, MySQL, txAdmin) run on the user's machine.
Intelligence tools (analysis, AI review, docs, patterns) relay to the FiveClaw VPS.
The VPS logic is never distributed — only results come back.
"""

import os
from typing import Optional
from fastmcp import FastMCP

from .config import Config
from .local import RepoMapTool, FileTool, MySQLTool, TxAdminTool, DeployTool, ContextTool, collect_resource_files
from .remote import RemoteClient

# ─── Boot ─────────────────────────────────────────────────────────────────────

try:
    config = Config()
except RuntimeError as e:
    import sys
    print(f"[FiveClaw Agent] Configuration error:\n{e}", file=sys.stderr)
    sys.exit(1)

remote  = RemoteClient(config.api_key, config.api_url)
repomap = RepoMapTool(config)
files   = FileTool(config)
mysql   = MySQLTool(config)
txadmin = TxAdminTool(config)
deploy  = DeployTool(config)
context = ContextTool(config)

server = FastMCP("fiveclaw-agent")

# ─── Helpers ──────────────────────────────────────────────────────────────────

def _resource_files(resource: Optional[str] = None) -> dict:
    """Collect local source files to send to the VPS for analysis."""
    return collect_resource_files(config.resources_dir, resource)

# =============================================================================
# LOCAL TOOLS — run on the user's machine
# =============================================================================

@server.tool()
async def repomap_generate() -> str:
    """Scan your FiveM resources directory and build a map of all resources,
    their files, exports, and event handlers. Run this first."""
    return await repomap.generate()

@server.tool()
async def repomap_query(query_type: str, filter: Optional[str] = None) -> str:
    """Query the resource map. query_type: 'exports', 'events', 'files', or 'all'."""
    return await repomap.query(query_type, filter)

@server.tool()
async def repomap_show() -> str:
    """Show the full resource map JSON."""
    return await repomap.show()

@server.tool()
async def tool_search(pattern: str, path: Optional[str] = None) -> str:
    """Search for a regex pattern across all Lua/JS files in your resources."""
    return await files.search(pattern, path)

@server.tool()
async def tool_file_info(file_path: str) -> str:
    """Get file size, line count, and last modified time."""
    return await files.file_info(file_path)

@server.tool()
async def tool_syntax_check(file_path: str) -> str:
    """Check Lua syntax using luac. Requires luac installed locally."""
    return await files.syntax_check(file_path)

@server.tool()
async def read_latest_logs(lines: int = 100, pattern: Optional[str] = None) -> str:
    """Read the latest FiveM server log file."""
    return await files.read_logs(lines, pattern)

@server.tool()
async def tool_mysql_query(query: str) -> str:
    """Execute a SQL query against your locally configured MySQL database."""
    return await mysql.query(query)

@server.tool()
async def tool_server_status() -> str:
    """Check FiveM server status via your txAdmin panel."""
    return await txadmin.server_status()

@server.tool()
async def tool_resource_control(action: str, resource_name: str) -> str:
    """Start, stop, or restart a resource via txAdmin. action: 'start'|'stop'|'restart'."""
    return await txadmin.resource_control(action, resource_name)

@server.tool()
async def tool_server_console(command: str) -> str:
    """Send a raw command to the FiveM server console via txAdmin."""
    return await txadmin.server_console(command)

@server.tool()
async def deploy_resource(resource_name: str, target: str = "production") -> str:
    """Deploy a resource to your FiveM server.
    Uses SSH if FIVEM_SSH_HOST is configured, otherwise local file copy.
    target: 'production' or an absolute path."""
    return await deploy.deploy(resource_name, target)

@server.tool()
async def backup_resource(resource_name: str) -> str:
    """Create a timestamped backup of a resource in your project's backups/ folder."""
    return await deploy.backup(resource_name)

# Context memory
@server.tool()
async def context_remember(key: str, value: str, category: str = "general") -> str:
    """Save a fact to persistent local memory."""
    return await context.remember(key, value, category)

@server.tool()
async def context_recall(key: Optional[str] = None) -> str:
    """Recall a saved fact, or list all facts if no key given."""
    return await context.recall(key)

@server.tool()
async def context_search(query: str) -> str:
    """Search your saved facts."""
    return await context.search(query)

@server.tool()
async def context_forget(key: str) -> str:
    """Delete a saved fact."""
    return await context.forget(key)

@server.tool()
async def context_record(summary: str, tags: str) -> str:
    """Record a session note (comma-separated tags)."""
    return await context.record(summary, tags)

@server.tool()
async def context_history(limit: int = 10) -> str:
    """Show recent session history."""
    return await context.history(limit)

# =============================================================================
# REMOTE TOOLS — relay to FiveClaw VPS (your logic stays server-side)
# =============================================================================

@server.tool()
async def tool_validate_resource(resource_name: str) -> str:
    """Validate a FiveM resource — checks manifest, syntax, structure, and best practices."""
    return remote.call("validate_resource", {"resource_name": resource_name},
                       files=_resource_files(resource_name))

@server.tool()
async def resource_health_check(resource_name: str) -> str:
    """Comprehensive health check: manifest, syntax, NUI build, TODOs, dependencies."""
    return remote.call("resource_health_check", {"resource_name": resource_name},
                       files=_resource_files(resource_name))

@server.tool()
async def detect_anti_patterns(resource: Optional[str] = None) -> str:
    """Detect common FiveM anti-patterns: busy waits, missing locals, performance issues."""
    return remote.call("detect_anti_patterns", {"resource": resource},
                       files=_resource_files(resource))

@server.tool()
async def detect_duplicate_code(min_lines: int = 10, resource: Optional[str] = None) -> str:
    """Find duplicate or copy-pasted code blocks across your resources."""
    return remote.call("detect_duplicate_code", {"min_lines": min_lines, "resource": resource},
                       files=_resource_files(resource))

@server.tool()
async def find_exports(export_name: Optional[str] = None, resource: Optional[str] = None) -> str:
    """Find where exports are defined and called across your resources."""
    return remote.call("find_exports", {"export_name": export_name, "resource": resource},
                       files=_resource_files(resource))

@server.tool()
async def find_event_handlers(event_name: Optional[str] = None, resource: Optional[str] = None) -> str:
    """Find RegisterNetEvent and AddEventHandler calls."""
    return remote.call("find_event_handlers", {"event_name": event_name, "resource": resource},
                       files=_resource_files(resource))

@server.tool()
async def find_triggers(pattern: Optional[str] = None, resource: Optional[str] = None) -> str:
    """Find TriggerServerEvent and TriggerClientEvent calls."""
    return remote.call("find_triggers", {"pattern": pattern, "resource": resource},
                       files=_resource_files(resource))

@server.tool()
async def nui_build_check(resource_name: str) -> str:
    """Check if a NUI resource needs to be rebuilt."""
    return remote.call("nui_build_check", {"resource_name": resource_name},
                       files=_resource_files(resource_name))

@server.tool()
async def test_resource(resource_name: str, mode: str = "auto") -> str:
    """Test a FiveM resource using the FiveClaw test engine. mode: 'auto' or 'analyze'."""
    return remote.call("test_resource", {"resource_name": resource_name, "mode": mode},
                       files=_resource_files(resource_name))

@server.tool()
async def test_generate(resource_name: str) -> str:
    """Generate test cases for a resource without running them."""
    return remote.call("test_generate", {"resource_name": resource_name},
                       files=_resource_files(resource_name))

@server.tool()
async def trace_event_flow(event_name: str, max_depth: int = 3) -> str:
    """Trace how an event flows through your resources."""
    return remote.call("trace_event_flow", {"event_name": event_name, "max_depth": max_depth},
                       files=_resource_files())

@server.tool()
async def analyze_export_usage(caller: str, target: str, export_name: Optional[str] = None) -> str:
    """Analyze how a resource uses another resource's exports."""
    return remote.call("analyze_export_usage",
                       {"caller": caller, "target": target, "export_name": export_name},
                       files=_resource_files())

@server.tool()
async def mysql_visualize_schema() -> str:
    """Visualize your database schema as an ASCII diagram."""
    return remote.call("mysql_visualize_schema", {})

@server.tool()
async def pattern_list() -> str:
    """List all available FiveM code patterns in the FiveClaw pattern library."""
    return remote.call("pattern_list", {})

@server.tool()
async def pattern_show(pattern_name: str) -> str:
    """Show the full code for a pattern from the FiveClaw library."""
    return remote.call("pattern_show", {"pattern_name": pattern_name})

@server.tool()
async def pattern_apply(pattern_name: str, variables_json: str,
                        output_dir: Optional[str] = None, dry_run: bool = False) -> str:
    """Apply a FiveClaw code pattern to scaffold a new resource or feature."""
    return remote.call("pattern_apply",
                       {"pattern_name": pattern_name, "variables_json": variables_json,
                        "output_dir": output_dir, "dry_run": dry_run})

@server.tool()
async def fivem_docs(query: str) -> str:
    """Search the FiveM native documentation, scripting guides, and framework references."""
    return remote.call("fivem_docs", {"query": query})

@server.tool()
async def fivem_native(native_name: str) -> str:
    """Get detailed information about a FiveM native function."""
    return remote.call("fivem_native", {"native_name": native_name})

@server.tool()
async def mcp_health() -> str:
    """Check agent status and verify your FiveClaw API key is valid."""
    import json as _json
    result = remote.call("mcp_health", {})
    try:
        data = _json.loads(result)
        data["agent_version"] = "1.0.0"
        data["project_root"] = str(config.project_root)
        data["resources_dir"] = str(config.resources_dir)
        data["ssh_configured"] = config.has_ssh()
        data["mysql_configured"] = config.has_mysql()
        return _json.dumps(data, indent=2)
    except Exception:
        return result

# =============================================================================
# Entry point
# =============================================================================

def main():
    import signal, sys

    def _stop(sig, frame):
        print("\n[FiveClaw Agent] Shutting down.", file=sys.stderr)
        sys.exit(0)

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    transport = os.getenv("TRANSPORT", "streamable-http")
    host = os.getenv("HOST", "127.0.0.1")   # localhost only by default
    port = int(os.getenv("PORT", "5200"))

    print(f"[FiveClaw Agent] Starting on {transport}://{host}:{port}/mcp", file=sys.stderr)
    print(f"[FiveClaw Agent] Project root: {config.project_root}", file=sys.stderr)

    if transport == "streamable-http":
        server.run(transport="streamable-http", host=host, port=port)
    else:
        server.run(transport="stdio")


if __name__ == "__main__":
    main()
