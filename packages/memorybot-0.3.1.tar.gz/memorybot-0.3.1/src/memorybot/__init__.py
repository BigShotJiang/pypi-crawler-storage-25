"""MemoryBot CLI."""

__version__ = "0.3.1"
