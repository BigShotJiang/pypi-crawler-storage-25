#!/usr/bin/env python3
"""
Cross-Session Continuity Benchmark: Does knowledge accumulate across sessions?

Simulates 3 sessions where each builds on prior knowledge. Tests whether
the AI assistant can answer questions that REQUIRE combining facts from
multiple sessions.

Session 1: Architecture decisions (10 KOs)
Session 2: Research findings that REFERENCE session 1 decisions (10 KOs)
Session 3: New constraints that CONFLICT with session 1/2 if not updated (10 KOs)

Key test: Can the assistant handle Session 3 overrides correctly?
e.g., "We decided X in session 1, but changed to Y in session 3 because..."

Usage:
    export ANTHROPIC_API_KEY=sk-ant-xxx
    python benchmark_continuity.py
"""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("BENCHMARK_MODEL", "claude-sonnet-4-20250514")

# --- Fictional Domain: "Aether" IoT fleet management platform ---
# Three sessions where knowledge evolves and overrides itself

SESSION_1 = {
    "label": "Week 1: Initial architecture",
    "kos": [
        {"subject": "Aether database", "predicate": "decided as", "value": "MongoDB 7.0 with 3 replica sets. Chosen for flexible schema since IoT device schemas vary wildly across manufacturers.", "pinned": True},
        {"subject": "Aether protocol", "predicate": "decided as", "value": "MQTT v5 via EMQX broker. QoS 1 for telemetry, QoS 2 for commands. Topic structure: {org}/{fleet}/{device_id}/{metric}.", "pinned": True},
        {"subject": "Aether ingestion rate", "predicate": "capacity is", "value": "Target: 500,000 messages/second. Current: 340,000. Bottleneck identified as JSON parsing in the ingestion service.", "tags": ["architecture"]},
        {"subject": "Aether retention", "predicate": "policy is", "value": "Raw telemetry: 90 days. Aggregated (1-min): 1 year. Aggregated (1-hour): 5 years. Device metadata: indefinite.", "tags": ["architecture"]},
        {"subject": "Aether fleet size", "predicate": "current is", "value": "47,000 devices across 12 customers. Largest fleet: MegaCorp with 18,000 devices. Growth target: 200,000 devices by Q4 2026.", "tags": ["data"]},
        {"subject": "Aether alert engine", "predicate": "architecture is", "value": "Rule-based with Drools engine. 2,340 active rules. Evaluation latency: 12ms P50, 89ms P99. Alert delivery via PagerDuty webhook.", "tags": ["architecture"]},
        {"subject": "Aether API", "predicate": "spec is", "value": "REST with OpenAPI 3.0. Rate limit: 1,000 req/min per API key. Pagination: cursor-based, max 100 items per page.", "tags": ["architecture"]},
        {"subject": "Aether team", "predicate": "members are", "value": "CTO: Alex Rivera. Backend: Sam Chen, Fatima Al-Rashid. Frontend: Diego Morales. DevOps: Yuki Tanaka. Data: Dr. Lisa Park.", "tags": ["team"]},
        {"subject": "Aether compute", "predicate": "infrastructure is", "value": "AWS EKS in us-east-1. 24 m5.4xlarge nodes. Monthly cost: $28,000. Autoscaling: 16-32 nodes based on message throughput.", "tags": ["infrastructure"]},
        {"subject": "Aether SLA", "predicate": "terms are", "value": "99.9% uptime for enterprise tier. 99.5% for standard. Penalty: 10% credit per 0.1% below SLA. Current uptime: 99.94%.", "tags": ["business"]},
    ],
}

SESSION_2 = {
    "label": "Week 3: Performance findings (references session 1 decisions)",
    "kos": [
        {"subject": "MongoDB performance", "predicate": "finding is", "value": "Write amplification 4.7x at current load. WiredTiger cache misses at 23% during peak hours. Sharding by device_id improved query latency from 340ms to 45ms.", "tags": ["research"]},
        {"subject": "MQTT broker scaling", "predicate": "finding is", "value": "EMQX hits connection limit at 52,000 concurrent devices. With connection pooling (10 devices/connection), theoretical max is 520,000 devices. Sufficient for Q4 target.", "tags": ["research"]},
        {"subject": "JSON parsing bottleneck", "predicate": "resolved as", "value": "Replaced jackson with simdjson-java. Ingestion throughput: 340,000 -> 710,000 msg/s. JSON parsing dropped from 67% to 12% of CPU time.", "tags": ["research", "optimization"]},
        {"subject": "alert false positive rate", "predicate": "problem is", "value": "23.4% false positive rate on temperature alerts. Root cause: Drools rules don't account for seasonal baselines. Proposed fix: add rolling 30-day mean as context.", "tags": ["research", "bug"]},
        {"subject": "data compression", "predicate": "finding is", "value": "ZSTD level 3 reduces storage by 78% with 2.1ms compression overhead per batch. LZ4 is 1.3x faster but only 61% compression. Chose ZSTD for cost savings ($6,200/month).", "tags": ["research", "optimization"]},
        {"subject": "MegaCorp integration", "predicate": "issue is", "value": "MegaCorp devices send malformed timestamps (Unix epoch in milliseconds, not seconds). Causes 12% data loss in aggregation pipeline. Temporary fix: auto-detect and convert.", "tags": ["bug"]},
        {"subject": "edge computing", "predicate": "evaluation is", "value": "Tested AWS Greengrass for edge preprocessing. Reduces ingestion load by 40% but adds $1.20/device/month. Break-even at 15,000+ devices per customer. Only MegaCorp qualifies.", "tags": ["research"]},
        {"subject": "time-series query", "predicate": "optimization is", "value": "Created materialized views for common dashboard queries (last 24h, last 7d, last 30d). Dashboard load time: 4.2s -> 380ms. Refresh interval: 5 minutes.", "tags": ["optimization"]},
        {"subject": "device provisioning", "predicate": "bottleneck is", "value": "Certificate generation takes 2.3s per device. Bulk provisioning 1,000 devices: 38 minutes. Need to pre-generate certificates in batches of 5,000.", "tags": ["bug"]},
        {"subject": "geographic distribution", "predicate": "finding is", "value": "78% of devices are in North America, 15% Europe, 7% APAC. Single us-east-1 region adds 180ms latency for APAC. Multi-region deployment recommended for > 100k devices.", "tags": ["research"]},
    ],
}

SESSION_3 = {
    "label": "Week 6: Strategic changes (OVERRIDES some session 1/2 decisions)",
    "kos": [
        {"subject": "Aether database", "predicate": "CHANGED to", "value": "Migrating from MongoDB to TimescaleDB. Reason: time-series queries are 80% of workload, and MongoDB's aggregation pipeline can't keep up. Migration deadline: August 15, 2026. MongoDB stays as secondary for device metadata only.", "pinned": True},
        {"subject": "Aether alert engine", "predicate": "CHANGED to", "value": "Replacing Drools with Flink CEP (Complex Event Processing). Drools' 23.4% false positive rate was unacceptable. Flink allows sliding window aggregations and seasonal baseline comparison. Migration starts July 1.", "pinned": True},
        {"subject": "Aether compute", "predicate": "CHANGED to", "value": "Moving from AWS EKS to Hetzner bare metal. Monthly cost drops from $28,000 to $8,400. Approved by board after MegaCorp data residency requirement made us-east-1 insufficient anyway.", "pinned": True},
        {"subject": "multi-region deployment", "predicate": "decided as", "value": "Three regions: Hetzner Falkenstein (EU), Hetzner Ashburn (US), Equinix Tokyo (APAC). Each region runs full stack. Data replication via CockroachDB-style raft consensus.", "tags": ["architecture"]},
        {"subject": "Aether retention", "predicate": "UPDATED to", "value": "Raw telemetry: 30 days (was 90). Aggregated 1-min: 6 months (was 1 year). Change driven by storage costs at projected 200k device scale. Customers can pay for extended retention.", "pinned": True},
        {"subject": "Aether API", "predicate": "CHANGED to", "value": "Adding gRPC alongside REST. gRPC mandatory for device-to-cloud (3x less bandwidth). REST remains for dashboards and partner integrations. Deadline: September 2026.", "tags": ["architecture"]},
        {"subject": "new customer onboarded", "predicate": "details are", "value": "Meridian Logistics: 32,000 GPS trackers. Contract: $180,000/year. Requirement: sub-second location updates. This pushed total fleet to 79,000 devices.", "tags": ["business"]},
        {"subject": "hiring plan", "predicate": "approved as", "value": "2 senior backend engineers (TimescaleDB experience), 1 SRE (multi-region), 1 ML engineer (anomaly detection to replace rules). Budget: $720,000/year. Start date: July 2026.", "tags": ["team"]},
        {"subject": "Aether SLA", "predicate": "UPDATED to", "value": "Enterprise tier raised to 99.95% (was 99.9%). Required by Meridian Logistics contract. Penalty doubled to 20% credit per 0.1% below. Current architecture cannot meet this -- multi-region is prerequisite.", "tags": ["business"]},
        {"subject": "Sam Chen departure", "predicate": "status is", "value": "Sam Chen leaving July 15. Handoff plan: document all MongoDB internals (critical for migration), transition device provisioning ownership to Fatima. Knowledge transfer sessions Mon/Wed through July.", "tags": ["team"]},
    ],
}

ALL_SESSION_KOS = SESSION_1["kos"] + SESSION_2["kos"] + SESSION_3["kos"]

# --- Questions that require cross-session knowledge ---

CONTINUITY_QUESTIONS = [
    # === Cross-session fact recall (8 questions) ===
    {"id": 1, "category": "cross_session_fact",
     "question": "What database is Aether migrating to and why?",
     "expected_keywords": ["timescaledb", "mongodb", "time-series", "80%", "aggregation"],
     "min_keywords": 3},
    {"id": 2, "category": "cross_session_fact",
     "question": "What is the current total fleet size including the newest customer?",
     "expected_keywords": ["79,000", "79000", "meridian"],
     "min_keywords": 1},
    {"id": 3, "category": "cross_session_fact",
     "question": "What was the alert engine false positive rate and what's replacing Drools?",
     "expected_keywords": ["23.4", "flink", "cep", "drools"],
     "min_keywords": 3},
    {"id": 4, "category": "cross_session_fact",
     "question": "How much will the infrastructure cost change with the move to Hetzner?",
     "expected_keywords": ["28,000", "28000", "8,400", "8400", "hetzner"],
     "min_keywords": 2},
    {"id": 5, "category": "cross_session_fact",
     "question": "What is the current ingestion throughput after the JSON parsing fix?",
     "expected_keywords": ["710,000", "710000", "simdjson"],
     "min_keywords": 1},
    {"id": 6, "category": "cross_session_fact",
     "question": "What are the three deployment regions?",
     "expected_keywords": ["falkenstein", "ashburn", "tokyo"],
     "min_keywords": 3},
    {"id": 7, "category": "cross_session_fact",
     "question": "What is Sam Chen's departure date and who takes over device provisioning?",
     "expected_keywords": ["july 15", "fatima"],
     "min_keywords": 2},
    {"id": 8, "category": "cross_session_fact",
     "question": "What data compression was chosen and how much does it save monthly?",
     "expected_keywords": ["zstd", "78%", "6,200", "6200"],
     "min_keywords": 2},

    # === Override detection (7 questions -- must use LATEST info) ===
    {"id": 9, "category": "override_detection",
     "question": "What database does Aether use?",
     "expected_keywords": ["timescaledb", "migrating"],
     "min_keywords": 1,
     "anti_keywords": ["mongodb is our database", "we use mongodb"]},
    {"id": 10, "category": "override_detection",
     "question": "How long do we retain raw telemetry data?",
     "expected_keywords": ["30 day", "30-day"],
     "min_keywords": 1,
     "anti_keywords": ["we retain raw telemetry for 90", "retention is 90"]},
    {"id": 11, "category": "override_detection",
     "question": "What alert engine does Aether use?",
     "expected_keywords": ["flink", "cep", "replacing", "migrating"],
     "min_keywords": 1,
     "anti_keywords": ["drools is our alert engine", "we use drools for alerts"]},
    {"id": 12, "category": "override_detection",
     "question": "What cloud provider does Aether run on?",
     "expected_keywords": ["hetzner", "moving", "migrating"],
     "min_keywords": 1,
     "anti_keywords": ["we run on aws", "aws is our provider"]},
    {"id": 13, "category": "override_detection",
     "question": "What is the enterprise SLA uptime target?",
     "expected_keywords": ["99.95"],
     "min_keywords": 1,
     "anti_keywords": ["the target is 99.9%", "sla is 99.9%"]},
    {"id": 14, "category": "override_detection",
     "question": "How many devices are in the fleet?",
     "expected_keywords": ["79,000", "79000"],
     "min_keywords": 1,
     "anti_keywords": ["fleet is 47,000", "we have 47,000 devices"]},
    {"id": 15, "category": "override_detection",
     "question": "Does Aether need multi-region deployment?",
     "expected_keywords": ["yes", "three region", "falkenstein", "ashburn", "tokyo", "decided"],
     "min_keywords": 2},

    # === Synthesis (5 questions -- must combine facts from multiple sessions) ===
    {"id": 16, "category": "synthesis",
     "question": "Given Sam's departure and the MongoDB to TimescaleDB migration, what's the risk?",
     "expected_keywords": ["sam", "mongodb", "knowledge", "migration", "handoff", "document"],
     "min_keywords": 3},
    {"id": 17, "category": "synthesis",
     "question": "Can we meet the new 99.95% SLA target with the current single-region architecture?",
     "expected_keywords": ["no", "multi-region", "prerequisite", "cannot"],
     "min_keywords": 2},
    {"id": 18, "category": "synthesis",
     "question": "With the move to Hetzner and 79,000 devices, do we need edge computing?",
     "expected_keywords": ["megacorp", "15,000", "meridian", "32,000"],
     "min_keywords": 2},
    {"id": 19, "category": "synthesis",
     "question": "What should the new ML engineer focus on first, given the alert engine migration?",
     "expected_keywords": ["anomaly", "false positive", "23.4", "flink", "drools", "seasonal"],
     "min_keywords": 3},
    {"id": 20, "category": "synthesis",
     "question": "With retention reduced to 30 days and a new customer needing sub-second updates, what storage challenges remain?",
     "expected_keywords": ["meridian", "30 day", "gps", "sub-second", "storage"],
     "min_keywords": 2},
]


# --- Context Builders ---

def build_no_memory_prompt() -> str:
    return (
        "You are an AI assistant working on Aether, an IoT fleet management platform. "
        "This is a new session. You have no memory of previous conversations. "
        "Answer honestly. If you don't know something, say so."
    )


def build_md_memory_prompt() -> str:
    lines = [
        "# Project Memory -- Aether",
        "",
        "## Architecture",
        "- Database: migrating from MongoDB to TimescaleDB",
        "- Protocol: MQTT v5 via EMQX",
        "- Alert engine: migrating from Drools to Flink CEP",
        "- Infrastructure: moving from AWS to Hetzner bare metal",
        "- API: REST + adding gRPC",
        "- Three regions: EU, US, APAC",
        "",
        "## Current State",
        "- ~79,000 devices across multiple customers",
        "- Ingestion: ~710k msg/s after optimization",
        "- Enterprise SLA: 99.95% uptime",
        "- Monthly cost dropping from $28K to $8.4K",
        "",
        "## Key Issues",
        "- Sam Chen leaving July 15, knowledge transfer needed",
        "- Alert false positive rate was 23.4%",
        "- Hiring 4 new engineers starting July",
        "",
        "## Process",
        "- Team lead: Alex Rivera (CTO)",
        "- Main customers: MegaCorp, Meridian Logistics",
    ]
    memory_text = "\n".join(lines)
    return (
        "You are an AI assistant working on Aether, an IoT fleet management platform. "
        "You have a memory file from previous sessions:\n\n"
        f"```\n{memory_text}\n```\n\n"
        "Use this memory to answer questions. If details aren't in the memory, "
        "say you don't recall the specifics."
    )


def build_ko_memory_prompt() -> str:
    # Apply subject-level dedup: if multiple KOs share the same subject,
    # keep only the most recent one (latest session). This mirrors the
    # server-side dedup fix shipped in PR #19.
    all_kos_ordered = SESSION_1["kos"] + SESSION_2["kos"] + SESSION_3["kos"]
    seen_subjects: dict[str, dict] = {}
    for ko in all_kos_ordered:
        seen_subjects[ko["subject"]] = ko  # Later sessions overwrite earlier
    deduped = list(seen_subjects.values())

    pinned = [ko for ko in deduped if ko.get("pinned")]
    unpinned = [ko for ko in deduped if not ko.get("pinned")]

    lines = ["# Session Context (from CoreTx Connect)\n"]

    if pinned:
        lines.append(f"## Pinned ({len(pinned)} critical)\n")
        for ko in pinned:
            lines.append(f"- **{ko['subject']}** ({ko['predicate']}): {ko['value']}")
        lines.append("")

    if unpinned:
        lines.append(f"## Recent & Semantic\n")
        for ko in unpinned:
            lines.append(f"- **{ko['subject']}** ({ko['predicate']}): {ko['value']}")
        lines.append("")

    lines.append(f"---\n{len(deduped)} KOs loaded (deduped by subject).")
    ko_text = "\n".join(lines)

    return (
        "You are an AI assistant working on Aether, an IoT fleet management platform. "
        "You have persistent knowledge from previous sessions via CoreTx Connect:\n\n"
        f"{ko_text}\n\n"
        "Use this knowledge to answer questions. When information has been updated "
        "(e.g., 'CHANGED to'), use the latest version. Enforce constraints firmly."
    )


# --- Scoring ---

def score_answer(answer: str, question: dict) -> dict:
    answer_lower = answer.lower()
    found = [kw for kw in question["expected_keywords"] if kw.lower() in answer_lower]
    missed = [kw for kw in question["expected_keywords"] if kw.lower() not in answer_lower]
    passed = len(found) >= question["min_keywords"]

    # Anti-keyword check (for override detection)
    anti_keywords = question.get("anti_keywords", [])
    anti_found = [ak for ak in anti_keywords if ak.lower() in answer_lower]
    if anti_found:
        passed = False  # Failed override detection

    return {
        "question_id": question["id"],
        "category": question["category"],
        "passed": passed,
        "keywords_found": found,
        "keywords_missed": missed,
        "anti_keywords_found": anti_found,
        "hit_count": len(found),
        "min_needed": question["min_keywords"],
    }


# --- Run ---

def call_claude(system_prompt: str, user_message: str) -> str:
    if not ANTHROPIC_API_KEY:
        return "[ERROR: ANTHROPIC_API_KEY not set]"
    body = json.dumps({
        "model": MODEL,
        "max_tokens": 500,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_message}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode())
            return result["content"][0]["text"]
    except urllib.error.HTTPError as e:
        body_text = e.read().decode() if e.fp else ""
        return f"[API ERROR {e.code}: {body_text[:200]}]"
    except Exception as e:
        return f"[ERROR: {e}]"


@dataclass
class ContinuityResult:
    condition: str
    accuracy: float = 0.0
    passed: int = 0
    total: int = 0
    by_category: dict = field(default_factory=dict)
    results: list = field(default_factory=list)
    duration_s: float = 0.0


def run_condition(condition: str) -> ContinuityResult:
    builders = {
        "none": build_no_memory_prompt,
        "md": build_md_memory_prompt,
        "ko": build_ko_memory_prompt,
    }
    system_prompt = builders[condition]()
    result = ContinuityResult(condition=condition)
    start = time.time()

    print(f"\n{'='*60}")
    print(f"Condition: {condition.upper()}")
    print(f"{'='*60}")

    for q in CONTINUITY_QUESTIONS:
        answer = call_claude(system_prompt, q["question"])
        scored = score_answer(answer, q)
        scored["answer"] = answer
        result.results.append(scored)
        status = "PASS" if scored["passed"] else "FAIL"
        anti = f" (STALE: {scored['anti_keywords_found']})" if scored.get("anti_keywords_found") else ""
        print(f"  [{status}] Q{q['id']:2d} ({q['category']:22s}): {scored['hit_count']}/{len(q['expected_keywords'])} kw{anti}")
        time.sleep(1.5)

    result.duration_s = time.time() - start
    result.total = len(CONTINUITY_QUESTIONS)
    result.passed = sum(1 for r in result.results if r["passed"])
    result.accuracy = result.passed / result.total

    cats = {}
    for r in result.results:
        cat = r["category"]
        if cat not in cats:
            cats[cat] = {"total": 0, "passed": 0}
        cats[cat]["total"] += 1
        if r["passed"]:
            cats[cat]["passed"] += 1
    for cat, data in cats.items():
        data["accuracy"] = data["passed"] / data["total"] if data["total"] > 0 else 0
    result.by_category = cats

    return result


def main():
    if not ANTHROPIC_API_KEY:
        print("ERROR: ANTHROPIC_API_KEY not set.")
        sys.exit(1)

    print(f"Cross-Session Continuity Benchmark")
    print(f"Model: {MODEL}")
    print(f"Domain: Aether (fictional IoT fleet management -- zero prior knowledge)")
    print(f"Sessions: 3 (architecture -> research -> strategic changes)")
    print(f"Questions: {len(CONTINUITY_QUESTIONS)} (8 cross-session + 7 override + 5 synthesis)")

    conditions = ["none", "md", "ko"]
    all_results = []

    for cond in conditions:
        result = run_condition(cond)
        all_results.append(result)
        print(f"\n  -> {cond.upper()}: {result.accuracy:.0%} ({result.passed}/{result.total})")

    # Summary
    print(f"\n{'='*60}")
    print("RESULTS SUMMARY")
    print(f"{'='*60}\n")

    print(f"{'Condition':<8} {'Accuracy':>10} {'Cross-Sess':>12} {'Override':>10} {'Synthesis':>10}")
    print("-" * 54)
    for r in all_results:
        cs = r.by_category.get("cross_session_fact", {}).get("accuracy", 0)
        ov = r.by_category.get("override_detection", {}).get("accuracy", 0)
        sy = r.by_category.get("synthesis", {}).get("accuracy", 0)
        print(f"{r.condition:<8} {r.accuracy:>9.0%} {cs:>11.0%} {ov:>9.0%} {sy:>9.0%}")

    # Save
    output = {
        "model": MODEL,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "test": "cross_session_continuity",
        "domain": "Aether (fictional IoT fleet management)",
        "sessions": 3,
        "questions": len(CONTINUITY_QUESTIONS),
        "kos": len(ALL_SESSION_KOS),
        "results": [{
            "condition": r.condition,
            "accuracy": r.accuracy,
            "passed": r.passed,
            "total": r.total,
            "by_category": r.by_category,
            "duration_s": r.duration_s,
            "details": r.results,
        } for r in all_results],
    }

    with open("benchmark_continuity_results.json", "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nResults saved to benchmark_continuity_results.json")


if __name__ == "__main__":
    main()
