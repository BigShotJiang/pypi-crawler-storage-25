#!/usr/bin/env python3
"""
Sharing Benchmark: Tests whether KOs shared from Account A to Account B
produce useful knowledge in Account B's sessions.

Uses the same 25 questions from benchmark.py but adds a 4th condition:
  - shared_ko: Account B's real ko_context output (from shared KOs)

This measures the real-world value of KO sharing — not idealized KOs
written specifically for the test, but actual KOs created during work
sessions and shared between accounts.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-xxx
    python benchmark_sharing.py
"""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.request
import urllib.error

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("BENCHMARK_MODEL", "claude-sonnet-4-20250514")

# Import questions and scoring from main benchmark
from benchmark import QUESTIONS, score_answer, build_no_memory_prompt, build_md_memory_prompt, build_ko_memory_prompt, BenchmarkRun


def call_claude(system_prompt: str, user_message: str) -> str:
    if not ANTHROPIC_API_KEY:
        return "[ERROR: ANTHROPIC_API_KEY not set]"
    body = json.dumps({
        "model": MODEL,
        "max_tokens": 500,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_message}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode())
            return result["content"][0]["text"]
    except urllib.error.HTTPError as e:
        body_text = e.read().decode() if e.fp else ""
        return f"[API ERROR {e.code}: {body_text[:200]}]"
    except Exception as e:
        return f"[ERROR: {e}]"


def build_shared_ko_prompt() -> str:
    """Use Account B's real ko_context output from shared KOs."""
    context_file = "/tmp/shared_ko_context.txt"
    if not os.path.exists(context_file):
        print(f"ERROR: {context_file} not found. Run the sharing step first.")
        sys.exit(1)

    with open(context_file) as f:
        ko_text = f.read()

    return (
        "You are an AI assistant working on a software project called CoreTx / NanoPub. "
        "A colleague has shared their knowledge with you via CoreTx Connect. "
        "Here is the shared context:\n\n"
        f"{ko_text}\n\n"
        "Use this shared knowledge to answer questions accurately. "
        "If a question involves a constraint or rule, enforce it. "
        "If you don't have enough information to answer precisely, say so."
    )


def run_condition(condition: str, prompt_fn, seed: int = 0) -> BenchmarkRun:
    system_prompt = prompt_fn()
    run = BenchmarkRun(condition=condition, seed=seed)
    start = time.time()

    print(f"\n{'='*60}")
    print(f"Condition: {condition.upper()} (seed {seed})")
    print(f"{'='*60}")

    for q in QUESTIONS:
        answer = call_claude(system_prompt, q["question"])
        result = score_answer(answer, q)
        result["answer"] = answer
        run.results.append(result)
        status = "PASS" if result["passed"] else "FAIL"
        print(f"  [{status}] Q{q['id']:2d} ({q['category']:20s}): {result['hit_count']}/{len(q['expected_keywords'])} keywords")
        time.sleep(0.3)

    run.duration_s = time.time() - start
    run.total_questions = len(QUESTIONS)
    run.passed = sum(1 for r in run.results if r["passed"])
    run.accuracy = run.passed / run.total_questions if run.total_questions > 0 else 0

    categories = {}
    for r in run.results:
        cat = r["category"]
        if cat not in categories:
            categories[cat] = {"total": 0, "passed": 0, "scores": []}
        categories[cat]["total"] += 1
        if r["passed"]:
            categories[cat]["passed"] += 1
        categories[cat]["scores"].append(r["score"])

    for cat, data in categories.items():
        data["accuracy"] = data["passed"] / data["total"] if data["total"] > 0 else 0
        data["mean_score"] = sum(data["scores"]) / len(data["scores"]) if data["scores"] else 0
        del data["scores"]
    run.by_category = categories

    return run


def main():
    if not ANTHROPIC_API_KEY:
        print("ERROR: ANTHROPIC_API_KEY not set.")
        sys.exit(1)

    conditions = [
        ("none", build_no_memory_prompt),
        ("md", build_md_memory_prompt),
        ("shared_ko", build_shared_ko_prompt),
        ("ko", build_ko_memory_prompt),
    ]

    runs = []
    for cond_name, prompt_fn in conditions:
        run = run_condition(cond_name, prompt_fn)
        runs.append(run)
        print(f"\n  -> {cond_name.upper()}: {run.accuracy:.0%} ({run.passed}/{run.total_questions})")

    # Summary
    print(f"\n{'='*60}")
    print("RESULTS SUMMARY")
    print(f"{'='*60}\n")

    print(f"{'Condition':<14} {'Accuracy':>10} {'Passed':>8} {'Time':>8}")
    print("-" * 44)
    for run in runs:
        print(f"{run.condition:<14} {run.accuracy:>9.0%} {run.passed:>5}/{run.total_questions:<3} {run.duration_s:>6.1f}s")

    cats = ["fact_retention", "decision_recall", "constraint"]
    print(f"\n{'Category':<22}", end="")
    for run in runs:
        print(f" {run.condition:>12}", end="")
    print()
    print("-" * (22 + 13 * len(runs)))
    for cat in cats:
        print(f"{cat:<22}", end="")
        for run in runs:
            data = run.by_category.get(cat, {})
            acc = data.get("accuracy", 0)
            print(f" {acc:>11.0%}", end="")
        print()

    # Highlight the sharing result
    shared_run = next(r for r in runs if r.condition == "shared_ko")
    ko_run = next(r for r in runs if r.condition == "ko")
    md_run = next(r for r in runs if r.condition == "md")

    print(f"\n--- Sharing Analysis ---")
    print(f"Shared KOs accuracy:     {shared_run.accuracy:.0%}")
    print(f"Ideal KO accuracy:       {ko_run.accuracy:.0%}")
    print(f".md memory accuracy:     {md_run.accuracy:.0%}")
    print(f"Sharing vs .md gain:     +{shared_run.accuracy - md_run.accuracy:.0%}")
    print(f"Sharing vs ideal gap:    -{ko_run.accuracy - shared_run.accuracy:.0%}")

    # Save results
    output = {
        "model": MODEL,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "test": "sharing_benchmark",
        "description": "Tests real shared KOs (Account A -> Account B) against synthetic conditions",
        "runs": [],
    }
    for run in runs:
        output["runs"].append({
            "condition": run.condition,
            "accuracy": run.accuracy,
            "passed": run.passed,
            "total": run.total_questions,
            "by_category": run.by_category,
            "duration_s": run.duration_s,
            "results": run.results,
        })

    with open("benchmark_sharing_results.json", "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nResults saved to benchmark_sharing_results.json")


if __name__ == "__main__":
    main()
