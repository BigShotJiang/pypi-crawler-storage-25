#!/usr/bin/env python3
"""
CoreTx Connect — thin MCP server that stores KOs via the CoreTx API.

No local database. No embeddings. No dependencies beyond stdlib.
All persistent state lives at api.coretx.ai.

Install:
    pip install coretx-connect
    claude mcp add --transport stdio ko-memory -- coretx-connect

Setup:
    1. Sign in at praxis.coretx.ai
    2. Go to Profile > API Keys > Create
    3. Set CORETX_API_KEY=npub_sk_xxx in your environment
"""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Any

from coretx import __version__

import contextvars

def _load_config_value(key: str, default: str = "") -> str:
    """Read a value from ~/.coretx/config.json. Returns default if missing."""
    config_path = os.path.join(os.path.expanduser("~"), ".coretx", "config.json")
    try:
        with open(config_path) as f:
            config = json.load(f)
        return config.get(key, default)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default

API_URL = os.environ.get("CORETX_API_URL", "") or _load_config_value("api_url", "https://api.coretx.ai")
API_KEY = os.environ.get("CORETX_API_KEY", "") or _load_config_value("api_key", "")

# ─── Account Tiers ──────────────────────────────────────────────

VALID_VISIBILITIES = ("private", "matchable", "public")

TIERS: dict[str, dict[str, Any]] = {
    "free": {"ko_limit": 500, "visibility_options": ["private"], "matching": False, "extraction": False, "cloud_sync": False},
    "pro": {"ko_limit": 10000, "visibility_options": ["private", "public"], "matching": False, "extraction": True, "cloud_sync": True},
    "network": {"ko_limit": -1, "visibility_options": ["private", "matchable", "public"], "matching": True, "extraction": True, "cloud_sync": True},
    "institutional": {"ko_limit": -1, "visibility_options": ["private", "matchable", "public"], "matching": True, "extraction": True, "cloud_sync": True, "team_matching": True},
}

_tier: str = os.environ.get("CORETX_TIER", "network")  # Beta: all features free

def _get_tier_config() -> dict[str, Any]:
    return TIERS.get(_tier, TIERS["network"])

def _check_tier_feature(feature: str) -> str | None:
    config = _get_tier_config()
    if feature == "matching" and not config.get("matching"):
        return f"Research network matching requires the Network tier. Currently on: {_tier}."
    if feature == "extraction" and not config.get("extraction"):
        return f"LLM extraction requires the Pro tier or above. Currently on: {_tier}."
    return None

def _check_visibility(visibility: str) -> str | None:
    if visibility not in VALID_VISIBILITIES:
        return f"Invalid visibility: {visibility}. Must be one of: {', '.join(VALID_VISIBILITIES)}"
    config = _get_tier_config()
    if visibility not in config.get("visibility_options", ["private"]):
        return f"Visibility '{visibility}' not available on {_tier} tier. Options: {', '.join(config['visibility_options'])}."
    return None

# Per-request API key override (for multi-user remote server)
# When set, _headers() uses this instead of the global API_KEY.
_request_api_key: contextvars.ContextVar[str] = contextvars.ContextVar('_request_api_key', default="")

# ─── Signing (optional — degrades gracefully) ─────────────────

_signing_key = None  # Ed25519PrivateKey or None
_signing_pub_b64 = ""  # base64-encoded public key
_signing_key_registered = False

try:
    from coretx.signing import (
        load_or_create_key,
        get_public_key_b64,
        sign_ko,
        canonicalize_ko,
    )
    _signing_key = load_or_create_key()
    _signing_pub_b64 = get_public_key_b64(_signing_key)
except Exception as e:
    # Signing unavailable — continue without it
    print(f"[coretx-connect] Signing unavailable: {e}", file=sys.stderr)

# ─── In-Memory State (ephemeral, session-scoped) ────────────────

_working_memory: dict[str, dict] = {}
_todos: list[dict] = []
_todo_counter = 0
_context: dict[str, str] = {"project": "", "goal": "", "cwd": ""}
_tool_call_count = 0


def _infer_project() -> str:
    """Infer project name from context when not explicitly provided."""
    if _context.get("project"):
        return _context["project"]
    cwd = _context.get("cwd", "")
    if cwd:
        parts = cwd.rstrip("/").split("/")
        if parts:
            return parts[-1]
    return ""
_last_ko_write_at = 0  # tool call count when last ko_write happened
_session_kos_written: list[dict] = []  # Track KOs written this session
_is_first_ko: bool | None = None  # None = unknown, True/False after first write

DASHBOARD_URL = "https://praxis.coretx.ai/dashboard"

# ─── HTTP Client ─────────────────────────────────────────────────

def _api_get(action: str, params: dict | None = None) -> dict:
    """GET /api/kos?action=...&key=value."""
    qs = f"action={action}"
    if params:
        for k, v in params.items():
            if v is not None and v != "":
                qs += f"&{k}={urllib.request.quote(str(v))}"
    url = f"{API_URL}/api/kos?{qs}"
    req = urllib.request.Request(url, headers=_headers(), method="GET")
    return _do_request(req)


def _api_post(body: dict) -> dict:
    """POST /api/kos with JSON body."""
    data = json.dumps(body).encode()
    req = urllib.request.Request(
        f"{API_URL}/api/kos",
        data=data,
        headers={**_headers(), "Content-Type": "application/json"},
        method="POST",
    )
    return _do_request(req)


def _api_delete(params: dict) -> dict:
    """DELETE /api/kos?subject=...&predicate=..."""
    qs = "&".join(f"{k}={urllib.request.quote(str(v))}" for k, v in params.items() if v)
    url = f"{API_URL}/api/kos?{qs}"
    req = urllib.request.Request(url, headers=_headers(), method="DELETE")
    return _do_request(req)


def _register_signing_key() -> bool:
    """Register our Ed25519 public key with the server. Returns True on success."""
    global _signing_key_registered
    if _signing_key_registered or not _signing_pub_b64:
        return _signing_key_registered
    try:
        data = json.dumps({"public_key": _signing_pub_b64, "algorithm": "ed25519", "label": "coretx-connect"}).encode()
        req = urllib.request.Request(
            f"{API_URL}/api/signing-key",
            data=data,
            headers={**_headers(), "Content-Type": "application/json"},
            method="POST",
        )
        result = _do_request(req)
        if "error" not in result:
            _signing_key_registered = True
    except Exception as e:
        print(f"[coretx-connect] Key registration failed: {e}", file=sys.stderr)
    return _signing_key_registered


def _sign_body(body: dict) -> dict:
    """Add Ed25519 signature fields to a KO write body. Returns body unchanged if signing unavailable."""
    if not _signing_key or not _signing_pub_b64:
        return body
    try:
        _register_signing_key()
        now = datetime.now(timezone.utc)
        ts = now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"
        canonical = canonicalize_ko(
            subject=body.get("subject", ""),
            object_value=body.get("object_value", ""),
            ko_type=body.get("ko_type", "insight"),
            timestamp=ts,
            visibility=body.get("visibility", "private"),
        )
        body["signature"] = sign_ko(_signing_key, canonical)
        body["signer_public_key"] = _signing_pub_b64
        body["timestamp"] = ts
    except Exception as e:
        print(f"[coretx-connect] Signing failed: {e}", file=sys.stderr)
    return body


def _headers() -> dict:
    h = {}
    # Per-request key (from OAuth Bearer token) takes priority over env var
    key = _request_api_key.get() or API_KEY
    if key:
        h["Authorization"] = f"Bearer {key}"
    return h


def _do_request(req: urllib.request.Request) -> dict:
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        try:
            return json.loads(body)
        except Exception:
            return {"error": f"HTTP {e.code}: {body[:200]}"}
    except Exception as e:
        return {"error": str(e)}


# ─── Cloud Tool Implementations ─────────────────────────────────

def ko_write(args: dict) -> str:
    global _is_first_ko

    # Validate visibility against current tier
    visibility = args.get("visibility", "private")
    vis_error = _check_visibility(visibility)
    if vis_error:
        return vis_error

    # Check if this is the user's first-ever KO
    if _is_first_ko is None:
        stats = _api_get("stats")
        _is_first_ko = stats.get("total_kos", 0) == 0

    body: dict[str, Any] = {
        "action": "write",
        "subject": args["subject"],
        "predicate": args["predicate"],
        "object_value": args["object_value"],
        "visibility": visibility,
        "provenance": args.get("provenance", ""),
        "pinned": args.get("pinned", False),
        "project": args.get("project") or _infer_project(),
        "memory_type": args.get("memory_type", "episodic"),
        "ko_type": args.get("ko_type", "insight"),
        "tags": args.get("tags", []),
    }
    if args.get("confidence") is not None:
        body["confidence"] = args["confidence"]
    body = _sign_body(body)
    result = _api_post(body)
    if "error" in result:
        return f"Write failed: {result['error']}"

    # Handle write gating — server may reject low-quality KOs
    if result.get("gated") or result.get("action") == "gated":
        reason = result.get("gate_reason", "below quality threshold")
        return f"Filtered: {args['subject']} — {reason}. Try being more specific or detailed."

    # Warn if signature was rejected by server
    if result.get("signature_rejected"):
        print(f"[coretx-connect] WARNING: Signature rejected by server: {result['signature_rejected']}", file=sys.stderr)

    # Track for session summary
    _session_kos_written.append({
        "subject": args["subject"],
        "ko_type": args.get("ko_type", "insight"),
        "time": time.time(),
        "gate_score": result.get("gate_score"),
    })

    msg = f"Stored: {args['subject']} ({args['predicate']})"

    # Surface contradiction warnings from server
    contradictions = result.get("contradictions", [])
    if contradictions:
        msg += "\n\n⚠️ Potential conflict detected:"
        for c in contradictions[:2]:
            ctype = c.get("type", "tension")
            existing = c.get("existing_subject", "?")
            explanation = c.get("explanation", "")
            if ctype == "contradiction":
                msg += f"\n  🔴 CONTRADICTS: '{existing}' — {explanation}"
            elif ctype == "tension":
                msg += f"\n  🟡 TENSION with: '{existing}' — {explanation}"
            else:
                msg += f"\n  🔵 Updates: '{existing}' — {explanation}"
        msg += "\nReview in Praxis to resolve."

    # First KO celebration
    if _is_first_ko:
        _is_first_ko = False
        msg += (
            f"\n\n🎉 This is your first knowledge object! Your memory network has begun."
            f"\nView your knowledge graph: {DASHBOARD_URL}"
        )

    return msg


def ko_read(args: dict) -> str:
    result = _api_get("read", {
        "subject": args["subject"],
        "predicate": args["predicate"],
    })
    if "error" in result:
        return f"Not found: {args['subject']} / {args['predicate']}"
    return json.dumps(result, indent=2)


def ko_search(args: dict) -> str:
    result = _api_get("search", {
        "q": args["query"],
        "limit": args.get("limit", 10),
        "project": args.get("project", ""),
    })
    if "error" in result:
        return f"Search failed: {result['error']}"
    results = result.get("results", [])
    if not results:
        return "No results found."
    lines = []
    for ko in results:
        vis = ko.get('visibility', 'private')
        vis_tag = f" [{vis}]" if vis != 'private' else ""
        lines.append(f"- **{ko.get('subject', '?')}** ({ko.get('predicate', '?')}){vis_tag}: {ko.get('object_value', '')[:200]}")
    return "\n".join(lines)


def ko_list(args: dict) -> str:
    result = _api_get("list", {
        "limit": args.get("limit", 50),
        "project": args.get("project", ""),
    })
    if "error" in result:
        return f"List failed: {result['error']}"
    results = result.get("kos", result.get("results", []))
    if not results:
        return "No KOs stored yet."
    lines = [f"**{len(results)} KOs**\n"]
    for ko in results[:20]:
        vis = ko.get('visibility', 'private')
        vis_tag = f" [{vis}]" if vis != 'private' else ""
        lines.append(f"- **{ko.get('subject', '?')}** ({ko.get('predicate', '?')}){vis_tag}: {ko.get('object_value', '')[:100]}")
    if len(results) > 20:
        lines.append(f"... and {len(results) - 20} more")
    return "\n".join(lines)


def ko_delete(args: dict) -> str:
    result = _api_delete({
        "subject": args["subject"],
        "predicate": args["predicate"],
    })
    if "error" in result:
        return f"Delete failed: {result['error']}"
    return f"Deleted: {args['subject']} / {args['predicate']}"


def ko_context(args: dict) -> str:
    # Use inferred project if not explicitly provided
    project = args.get("project") or _infer_project()

    result = _api_get("context", {
        "project": project,
        "limit": args.get("limit", 15),
    })
    if "error" in result:
        return f"Context failed: {result['error']}"
    context = result.get("context", "No context available.")

    # Build session narrative from recent KOs
    narrative = _build_session_narrative(project)

    # Add project-aware continuity header
    project_note = f" for project **{project}**" if project else ""
    header = (
        f"Memory loaded from previous sessions{project_note}. "
        "When a retrieved memory directly answers a question or informs a decision, "
        "say so explicitly — e.g. \"From your earlier session: [fact].\"\n\n"
    )

    if narrative:
        header += f"**Last session summary:**\n{narrative}\n\n"

    context = header + context
    context += f"\n\nView your knowledge graph: {DASHBOARD_URL}"
    return context


def _build_session_narrative(project: str) -> str:
    """Build a brief narrative of the most recent session's activity."""
    # Fetch recent KOs to build the narrative
    result = _api_get("list", {"limit": 20, "project": project})
    kos = result.get("kos", result.get("results", []))
    if not kos:
        return ""

    # Group by type
    decisions = []
    problems = []
    insights = []
    for ko in kos[:15]:
        ko_type = ko.get("ko_type", "insight")
        subject = ko.get("subject", ko.get("title", "?"))
        if ko_type == "problem":
            problems.append(subject)
        elif ko.get("predicate", "").startswith("decided"):
            decisions.append(subject)
        else:
            insights.append(subject)

    parts = []
    if decisions:
        parts.append(f"Decided: {', '.join(decisions[:3])}")
    if problems:
        parts.append(f"Open problems: {', '.join(problems[:3])}")
    if insights and not decisions and not problems:
        parts.append(f"Recent work: {', '.join(insights[:3])}")

    return ". ".join(parts) + "." if parts else ""


def ko_stats(args: dict) -> str:
    result = _api_get("stats")
    if "error" in result:
        return f"Stats failed: {result['error']}"

    total = result.get("total_kos", 0)
    pinned = result.get("pinned", 0)
    semantic = result.get("semantic", 0)
    projects = result.get("projects", {})

    lines = [
        f"**Knowledge Store**",
        f"- Total KOs: {total}",
        f"- Pinned: {pinned}",
        f"- Semantic (long-term): {semantic}",
        f"- Projects: {', '.join(projects.keys()) if projects else 'none'}",
    ]

    # Session activity
    if _session_kos_written:
        type_counts: dict[str, int] = {}
        for ko in _session_kos_written:
            t = ko["ko_type"]
            type_counts[t] = type_counts.get(t, 0) + 1
        parts = [f"{count} {t}{'s' if count > 1 else ''}" for t, count in type_counts.items()]
        lines.append(f"- This session: {len(_session_kos_written)} KOs captured ({', '.join(parts)})")

    lines.append(f"\nView your knowledge graph: {DASHBOARD_URL}")
    return "\n".join(lines)


def ko_share(args: dict) -> str:
    kos = args.get("ko_hashes", [])
    if not kos:
        # Share recent KOs filtered by project
        list_result = _api_get("list", {
            "limit": 50,
            "project": args.get("project", ""),
        })
        if "error" in list_result:
            return f"Share failed: {list_result['error']}"
        kos_to_share = list_result.get("kos", list_result.get("results", []))
    else:
        kos_to_share = [{"hash": h} for h in kos]

    if not kos_to_share:
        return "No KOs to share."

    result = _api_post({
        "action": "share",
        "recipient": args["recipient"],
        "kos": kos_to_share,
    })
    if "error" in result:
        return f"Share failed: {result['error']}"
    return f"Shared {result.get('kos_shared', 0)} KOs with {args['recipient']}"


def ko_session_summary(args: dict) -> str:
    """Summarize KOs captured in this session."""
    if not _session_kos_written:
        return "No KOs were captured in this session."

    type_counts: dict[str, int] = {}
    for ko in _session_kos_written:
        t = ko["ko_type"]
        type_counts[t] = type_counts.get(t, 0) + 1

    lines = [
        f"**Session Summary — {len(_session_kos_written)} KOs captured**\n",
    ]

    for ko_type, count in sorted(type_counts.items(), key=lambda x: -x[1]):
        lines.append(f"- {count} {ko_type}{'s' if count > 1 else ''}")

    lines.append(f"\nKOs captured:")
    for ko in _session_kos_written:
        lines.append(f"  • {ko['subject']} ({ko['ko_type']})")

    lines.append(f"\nAll memories persist across sessions. View your knowledge graph: {DASHBOARD_URL}")
    return "\n".join(lines)


def ko_set_visibility(args: dict) -> str:
    """Change the visibility of an existing KO."""
    ko_id = args.get("ko_id", "")
    visibility = args.get("visibility", "private")

    if not ko_id:
        return "Error: ko_id is required."

    vis_error = _check_visibility(visibility)
    if vis_error:
        return vis_error

    result = _api_post({
        "action": "set_visibility",
        "ko_id": ko_id,
        "visibility": visibility,
    })
    if "error" in result:
        return f"Failed to update visibility: {result['error']}"
    return f"Visibility updated to '{visibility}' for KO {ko_id}."


# ─── Local Tool Implementations (in-memory, session-scoped) ─────

def ko_set_context(args: dict) -> str:
    if args.get("project"):
        _context["project"] = args["project"]
    if args.get("goal"):
        _context["goal"] = args["goal"]
    if args.get("cwd"):
        _context["cwd"] = args["cwd"]
    parts = []
    if _context["project"]:
        parts.append(f"project={_context['project']}")
    if _context["goal"]:
        parts.append(f"goal={_context['goal']}")
    if _context["cwd"]:
        parts.append(f"cwd={_context['cwd']}")
    return f"Context set: {', '.join(parts)}" if parts else "Context cleared."


def ko_working_memory(args: dict) -> str:
    action = args.get("action", "list")
    key = args.get("key", "")
    now = time.time()

    # Expire old entries
    expired = [k for k, v in _working_memory.items()
               if now - v["created_at"] > v.get("ttl_seconds", 3600)]
    for k in expired:
        del _working_memory[k]

    if action == "set":
        if not key:
            return "Error: key is required for set action"
        _working_memory[key] = {
            "value": args.get("value", ""),
            "priority": args.get("priority", "normal"),
            "tags": args.get("tags", []),
            "ttl_seconds": args.get("ttl_seconds", 3600),
            "created_at": now,
        }
        return f"Working memory set: {key}"

    elif action == "get":
        if key not in _working_memory:
            return f"Not found: {key}"
        entry = _working_memory[key]
        return f"**{key}**: {entry['value']} (priority={entry['priority']})"

    elif action == "remove":
        if key in _working_memory:
            del _working_memory[key]
            return f"Removed: {key}"
        return f"Not found: {key}"

    elif action == "clear":
        _working_memory.clear()
        return "Working memory cleared."

    else:  # list
        if not _working_memory:
            return "Working memory is empty."
        lines = [f"**Working Memory** ({len(_working_memory)} entries)\n"]
        for k, v in _working_memory.items():
            remaining = max(0, int(v.get("ttl_seconds", 3600) - (now - v["created_at"])))
            lines.append(f"- **{k}**: {v['value'][:100]} ({remaining}s remaining)")
        return "\n".join(lines)


def ko_todos(args: dict) -> str:
    global _todo_counter
    action = args.get("action", "list")

    if action == "add":
        text = args.get("text", "")
        if not text:
            return "Error: text is required for add action"
        _todo_counter += 1
        _todos.append({
            "id": _todo_counter,
            "text": text,
            "status": "open",
            "priority": args.get("priority", "normal"),
            "category": args.get("category", "code"),
            "project": args.get("project", _context.get("project", "")),
            "created_at": time.time(),
        })
        return f"Todo #{_todo_counter} added: {text}"

    elif action == "complete":
        todo_id = args.get("id")
        if todo_id is None:
            return "Error: id is required for complete action"
        for t in _todos:
            if t["id"] == todo_id:
                t["status"] = "done"
                return f"Todo #{todo_id} completed: {t['text']}"
        return f"Todo #{todo_id} not found"

    elif action == "delete":
        todo_id = args.get("id")
        if todo_id is None:
            return "Error: id is required for delete action"
        _todos[:] = [t for t in _todos if t["id"] != todo_id]
        return f"Todo #{todo_id} deleted"

    else:  # list
        status_filter = args.get("status", "open")
        filtered = [t for t in _todos if status_filter == "all" or t["status"] == status_filter]
        if not filtered:
            return f"No {status_filter} todos."
        lines = [f"**Todos** ({len(filtered)} {status_filter})\n"]
        for t in filtered:
            marker = "x" if t["status"] == "done" else " "
            lines.append(f"- [{marker}] #{t['id']} [{t['priority']}] {t['text']}")
        return "\n".join(lines)


# ─── Tool Definitions ───────────────────────────────────────────

TOOLS = [
    {
        "name": "ko_write",
        "description": (
            "Store a knowledge object (fact, decision, finding) in the CoreTx network. "
            "If a KO with the same subject+predicate exists, it will be updated.\n\n"
            "IMPORTANT: Call this PROACTIVELY and IMMEDIATELY when you detect decisions, "
            "facts, preferences, problems, insights, or commitments in the conversation. "
            "Do NOT wait for the user to ask you to remember something. "
            "Do NOT batch writes — capture each piece of knowledge as it emerges.\n\n"
            "WHEN TO CALL THIS (do not batch, capture in real-time):\n"
            "- A DECISION is made ('let's go with X', 'we should', 'the plan is')\n"
            "- A FACT is established ('the API is at', 'the database uses')\n"
            "- A PREFERENCE is stated ('I prefer', 'always use', 'never do')\n"
            "- An INSIGHT surfaces (a non-obvious connection, a realization)\n"
            "- A PROBLEM is identified (a bug, a gap, a risk, a blocker)\n"
            "- A COMMITMENT is made ('next step is', 'action item')\n\n"
            "Write KOs as you go, interleaved with your other work. "
            "A good session captures 5-15 KOs. If you've gone 10+ messages without "
            "writing a KO, you're probably missing something."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "subject": {"type": "string", "description": "The entity or topic (e.g., 'SESSION_SECRET', 'project architecture')"},
                "predicate": {"type": "string", "description": "The relationship (e.g., 'decided as', 'value is', 'located at')"},
                "object_value": {"type": "string", "description": "A clear, human-readable description of the knowledge. Write as if explaining to a colleague who wasn't in the session. State the what and why, not implementation details. Avoid code dumps, file listings, or raw technical notes."},
                "provenance": {"type": "string", "description": "Source (e.g., 'user decision', 'code analysis')"},
                "pinned": {"type": "boolean", "description": "If true, always appears in ko_context. Use for critical constraints.", "default": False},
                "project": {"type": "string", "description": "Project scope. Empty = cross-project.", "default": ""},
                "ko_type": {"type": "string", "description": "Knowledge type.", "default": "insight",
                            "enum": ["hypothesis", "method", "negative_result", "connection", "replication", "insight", "problem", "analogy_hint"]},
                "memory_type": {"type": "string", "description": "Use 'episodic' for session-specific facts (default). Use 'semantic' for durable knowledge that should persist long-term (conventions, architecture decisions, preferences).", "default": "episodic",
                                "enum": ["episodic", "semantic"]},
                "confidence": {"type": "number", "description": "Confidence 0-1.", "minimum": 0, "maximum": 1},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "Tags for categorization."},
                "visibility": {"type": "string", "description": "Privacy level. 'private' (default): only you. 'matchable': anonymous matching, content hidden. 'public': visible to the network.", "default": "private",
                               "enum": ["private", "matchable", "public"]},
            },
            "required": ["subject", "predicate", "object_value"],
        },
    },
    {
        "name": "ko_read",
        "description": "Retrieve a specific knowledge object by subject and predicate.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "subject": {"type": "string", "description": "The entity or topic"},
                "predicate": {"type": "string", "description": "The relationship or attribute"},
            },
            "required": ["subject", "predicate"],
        },
    },
    {
        "name": "ko_search",
        "description": "Search knowledge objects by keyword. Use when you need to find relevant context before making decisions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query (natural language or keywords)"},
                "limit": {"type": "number", "description": "Max results (default 10)", "default": 10},
                "project": {"type": "string", "description": "Filter to project. Empty = all.", "default": ""},
            },
            "required": ["query"],
        },
    },
    {
        "name": "ko_list",
        "description": "List recent knowledge objects, optionally filtered by project.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "number", "description": "Max results (default 50)", "default": 50},
                "project": {"type": "string", "description": "Filter to project. Empty = all.", "default": ""},
            },
        },
    },
    {
        "name": "ko_delete",
        "description": "Delete a knowledge object by subject and predicate.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "subject": {"type": "string", "description": "The entity or topic"},
                "predicate": {"type": "string", "description": "The relationship or attribute"},
            },
            "required": ["subject", "predicate"],
        },
    },
    {
        "name": "ko_context",
        "description": (
            "Get a session-start context summary. Call at the beginning of a session to load persistent knowledge. "
            "Returns pinned + semantic + recent KOs as formatted text."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Project name to boost relevant KOs"},
                "limit": {"type": "number", "description": "Max KOs to include (default 15)", "default": 15},
            },
        },
    },
    {
        "name": "ko_stats",
        "description": "Get statistics about the knowledge store: total KOs, pinned count, semantic count, projects.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ko_share",
        "description": "Share KOs with another CoreTx user by email or ORCID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "recipient": {"type": "string", "description": "Email or ORCID of the recipient"},
                "ko_hashes": {"type": "array", "items": {"type": "string"}, "description": "Specific KO hashes to share (omit to share recent)"},
                "project": {"type": "string", "description": "Filter by project when sharing recent KOs", "default": ""},
            },
            "required": ["recipient"],
        },
    },
    {
        "name": "ko_session_summary",
        "description": (
            "Get a summary of KOs captured in this session. Call at the end of a session "
            "or when the user asks what was remembered. Shows count by type and list of subjects."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ko_set_visibility",
        "description": (
            "Change a KO's visibility level. "
            "'private': only you can see it. "
            "'matchable': anonymous matching against the network (content hidden, identity hidden until mutual opt-in). "
            "'public': visible to anyone in the network."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "ko_id": {"type": "string", "description": "The ID of the KO to update"},
                "visibility": {"type": "string", "description": "New visibility level", "enum": ["private", "matchable", "public"]},
            },
            "required": ["ko_id", "visibility"],
        },
    },
    {
        "name": "ko_set_context",
        "description": "Set the current session context for smarter retrieval. Call at session start or when switching tasks.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Project name (e.g., 'nanopub', 'DREAMS')"},
                "goal": {"type": "string", "description": "What you're working on right now"},
                "cwd": {"type": "string", "description": "Current working directory path"},
            },
        },
    },
    {
        "name": "ko_working_memory",
        "description": (
            "Manage short-lived working memory entries. Working memory is ephemeral (session-scoped, auto-expires). "
            "Use for tracking current task state, intermediate results, and scratch context. "
            "Actions: set, get, remove, list, clear."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["set", "get", "remove", "list", "clear"], "default": "list"},
                "key": {"type": "string", "description": "Key name (for set/get/remove)"},
                "value": {"type": "string", "description": "Value to store (for set)"},
                "priority": {"type": "string", "enum": ["high", "normal", "low"], "default": "normal"},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "Tags for categorization"},
                "ttl_seconds": {"type": "number", "description": "Time-to-live in seconds (default 3600)", "default": 3600},
            },
        },
    },
    {
        "name": "ko_todos",
        "description": (
            "Manage todo items. Use action='add' to create, 'list' to view, 'complete' to mark done, 'delete' to remove. "
            "Detect todos naturally when the user says 'need to', 'should', 'TODO', etc."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["add", "list", "complete", "delete"], "default": "list"},
                "text": {"type": "string", "description": "Todo text (for 'add')"},
                "id": {"type": "number", "description": "Todo ID (for 'complete' or 'delete')"},
                "priority": {"type": "string", "enum": ["high", "normal", "low"]},
                "category": {"type": "string", "description": "Category (code/research/ops/design/comms/content)"},
                "project": {"type": "string", "description": "Project scope", "default": ""},
                "status": {"type": "string", "enum": ["open", "done", "all"], "default": "open"},
            },
        },
    },
]

TOOL_HANDLERS = {
    "ko_write": ko_write,
    "ko_read": ko_read,
    "ko_search": ko_search,
    "ko_list": ko_list,
    "ko_delete": ko_delete,
    "ko_context": ko_context,
    "ko_stats": ko_stats,
    "ko_share": ko_share,
    "ko_session_summary": ko_session_summary,
    "ko_set_visibility": ko_set_visibility,
    "ko_set_context": ko_set_context,
    "ko_working_memory": ko_working_memory,
    "ko_todos": ko_todos,
}

# ─── MCP Protocol Handler ───────────────────────────────────────

SERVER_INSTRUCTIONS = (
    "You have CoreTx Connect — persistent memory across all sessions and devices.\n\n"

    "SESSION START:\n"
    "1. Call ko_set_context with your current working directory as cwd.\n"
    "2. Call ko_context to load knowledge from previous sessions.\n"
    "Do both BEFORE answering the user's first question.\n\n"

    "CAPTURE IN REAL-TIME (do not batch, do not wait):\n"
    "- Decisions ('let's go with', 'we should', 'the plan is') -> ko_write immediately\n"
    "- Facts (URLs, versions, architecture, configs) -> ko_write immediately\n"
    "- Preferences ('I prefer', 'always', 'never') -> ko_write with pinned=True\n"
    "- Problems (bugs, blockers, things that don't work) -> ko_write with ko_type='problem'\n"
    "After writing, briefly confirm: 'Noted: [subject]' so the user knows it was captured.\n"
    "If the system returns 'Filtered:', the KO was below quality threshold. "
    "This is normal — try capturing with more detail next time.\n\n"

    "TOPIC SHIFTS:\n"
    "If the user switches projects or topics, call ko_set_context to update the project. "
    "This ensures subsequent writes are categorized correctly.\n\n"

    "BEFORE PROPOSING SOLUTIONS: Call ko_search to check if this was already decided.\n\n"

    "WHEN CITING MEMORY: Say 'From your earlier session: [fact]' so the user sees the value.\n\n"

    "GUIDELINES:\n"
    "- Subject: short, specific ('auth system', not 'the thing we discussed')\n"
    "- Object_value: write for a HUMAN reader, not just AI recall. "
    "State the decision, insight, or fact clearly. "
    "A colleague reading this in 3 months should understand it without context. "
    "BAD: 'TopBar (sticky, search), Summary Stats (4 cards - clickable filters: null/pinned/semantic/projects)'\n"
    "GOOD: 'The dashboard has a sticky top bar with search, and 4 stat cards that double as filters for pinned, semantic, and project views.'\n"
    "- Pin critical constraints (pinned=True)\n"
    "- Use memory_type='semantic' for long-term knowledge\n"
    "- Visibility: 'private' (default), 'matchable' (anonymous network matching), 'public' (visible to all)\n"
    "- Use ko_set_visibility to change a KO's privacy level after creation\n"
    "- NEVER store passwords, API keys, tokens, or secrets"
)


def handle_request(request: dict) -> dict | None:
    """Handle a single MCP JSON-RPC request."""
    method = request.get("method", "")
    req_id = request.get("id")
    params = request.get("params", {})

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "ko-memory", "version": __version__},
                "instructions": SERVER_INSTRUCTIONS,
            },
        }

    elif method == "notifications/initialized":
        return None

    elif method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"tools": TOOLS},
        }

    elif method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        handler = TOOL_HANDLERS.get(tool_name)

        if not handler:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Unknown tool: {tool_name}"}],
                    "isError": True,
                },
            }

        # Local tools don't need API key
        local_tools = {"ko_set_context", "ko_working_memory", "ko_todos", "ko_session_summary"}
        if tool_name not in local_tools and not API_KEY:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": (
                        "CORETX_API_KEY not set. To connect:\n"
                        "1. Sign in at praxis.coretx.ai\n"
                        "2. Go to Profile > API Keys > Create\n"
                        "3. Set CORETX_API_KEY=npub_sk_xxx in your environment"
                    )}],
                    "isError": True,
                },
            }

        try:
            global _tool_call_count, _last_ko_write_at
            _tool_call_count += 1

            result_text = handler(tool_args)

            # Track ko_write calls for reminder logic
            if tool_name == "ko_write":
                _last_ko_write_at = _tool_call_count

            # Add reminder if many tool calls have passed without a ko_write
            calls_since_write = _tool_call_count - _last_ko_write_at
            if tool_name != "ko_write" and calls_since_write >= 15:
                result_text += (
                    "\n\n[Reminder: You haven't written a KO in a while. "
                    "Have any decisions, facts, problems, or insights emerged "
                    "that should be captured?]"
                )

            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": result_text}],
                },
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Error: {e}"}],
                    "isError": True,
                },
            }

    elif method == "ping":
        return {"jsonrpc": "2.0", "id": req_id, "result": {}}

    # Unknown method
    if req_id is not None:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": -32601, "message": f"Method not found: {method}"},
        }
    return None


# ─── stdio transport ────────────────────────────────────────────

def _get_config_path() -> str:
    """Return the Claude Desktop config file path for the current platform."""
    if sys.platform == "darwin":
        return os.path.expanduser(
            "~/Library/Application Support/Claude/claude_desktop_config.json"
        )
    elif sys.platform == "win32":
        return os.path.join(os.environ.get("APPDATA", ""), "Claude", "claude_desktop_config.json")
    else:
        return os.path.expanduser("~/.config/Claude/claude_desktop_config.json")


def setup(api_key: str | None = None) -> None:
    """Configure ko-memory MCP server for both Claude Desktop and Claude Code."""
    # Fall back to config.json if no key provided
    if not api_key:
        api_key = _load_config_value("api_key", "")
    python_path = sys.executable
    configured = []

    # ── Claude Desktop ──
    config_path = _get_config_path()
    try:
        config: dict[str, Any] = {}
        if os.path.exists(config_path):
            try:
                with open(config_path) as f:
                    config = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass

        config.setdefault("mcpServers", {})
        server_config: dict[str, Any] = {
            "command": python_path,
            "args": ["-m", "coretx.server"],
        }
        if api_key:
            server_config["env"] = {"CORETX_API_KEY": api_key}
        config["mcpServers"]["ko-memory"] = server_config

        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
            f.write("\n")
        configured.append(f"Claude Desktop ({config_path})")
    except Exception as e:
        print(f"  Warning: Could not configure Claude Desktop: {e}", file=sys.stderr)

    # ── Claude Code (via claude mcp add) ──
    try:
        import subprocess
        claude_path = subprocess.run(
            ["which", "claude"], capture_output=True, text=True
        ).stdout.strip()

        if claude_path:
            cmd = ["claude", "mcp", "add", "ko-memory"]
            if api_key:
                cmd.extend(["-e", f"CORETX_API_KEY={api_key}"])
            cmd.extend(["--", python_path, "-m", "coretx.server"])

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                configured.append("Claude Code")
            else:
                # May fail if already exists -- try remove then add
                subprocess.run(
                    ["claude", "mcp", "remove", "ko-memory"],
                    capture_output=True, text=True, timeout=10
                )
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    configured.append("Claude Code")
                else:
                    print(f"  Warning: Could not configure Claude Code: {result.stderr.strip()}", file=sys.stderr)
    except FileNotFoundError:
        pass  # claude CLI not installed
    except Exception as e:
        print(f"  Warning: Could not configure Claude Code: {e}", file=sys.stderr)

    # ── Summary ──
    print(f"\nConfigured ko-memory for: {', '.join(configured) if configured else 'none'}")
    print(f"  Python: {python_path}")
    if api_key:
        print(f"  API key: {api_key[:12]}...")
    else:
        print("  No API key set -- cloud tools will be disabled.")
        print("  Re-run: coretx setup <your-api-key>")
    if configured:
        print("\nRestart Claude to pick up the change.")


def _run_test():
    """Verify connectivity to the CoreTx API. Run with: coretx-connect --test"""
    print(f"CoreTx Connect v{__version__}")
    print(f"API: {API_URL}")

    if not API_KEY:
        print("\nFAIL: CORETX_API_KEY not set.")
        print("  Run 'coretx init' to create an account and API key,")
        print("  or set it manually: export CORETX_API_KEY=npub_sk_xxx")
        sys.exit(1)

    print(f"Key: {API_KEY[:12]}...")

    print("\n[1/3] Testing read (ko_stats)...", end=" ")
    result = _api_get("stats")
    if "error" in result:
        print(f"FAIL: {result['error']}")
        sys.exit(1)
    total = result.get("total_kos", 0)
    pinned = result.get("pinned", 0)
    projects = result.get("projects", {})
    print(f"OK ({total} KOs, {pinned} pinned, {len(projects)} projects)")

    print("[2/3] Testing write/read round-trip...", end=" ")
    test_subject = "__coretx_test__"
    test_predicate = "status is"
    test_value = f"verified at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}"
    write_result = _api_post({
        "action": "write",
        "subject": test_subject,
        "predicate": test_predicate,
        "object_value": test_value,
        "project": "",
        "memory_type": "episodic",
        "ko_type": "insight",
        "tags": ["test"],
    })
    if "error" in write_result:
        print(f"FAIL (write): {write_result['error']}")
        sys.exit(1)
    read_result = _api_get("read", {"subject": test_subject, "predicate": test_predicate})
    if "error" in read_result:
        print(f"FAIL (read): {read_result['error']}")
        sys.exit(1)
    _api_delete({"subject": test_subject, "predicate": test_predicate})
    print("OK (write, read, delete)")

    print("[3/3] Testing search...", end=" ")
    search_result = _api_get("search", {"q": "test", "limit": 1})
    if "error" in search_result:
        print(f"FAIL: {search_result['error']}")
        sys.exit(1)
    print("OK")

    print(f"\nAll tests passed. {total} KOs across {len(projects)} projects.")
    print("Your AI assistant can now use CoreTx Connect.")


def main():
    """CLI entry point: run as MCP server (default), setup config, or test."""
    if len(sys.argv) >= 2 and sys.argv[1] == "setup":
        api_key = sys.argv[2] if len(sys.argv) >= 3 else None
        setup(api_key)
        return

    if "--test" in sys.argv or "test" in sys.argv[1:2]:
        _run_test()
        return

    if "--version" in sys.argv:
        print(f"coretx-connect {__version__}")
        return
    if not API_KEY:
        print(
            "Warning: CORETX_API_KEY not set. Cloud KO operations will fail.\n"
            "Set it: export CORETX_API_KEY=npub_sk_xxx\n"
            "Local tools (working_memory, todos, set_context) will still work.",
            file=sys.stderr,
        )

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except json.JSONDecodeError:
            continue

        response = handle_request(request)
        if response is not None:
            sys.stdout.write(json.dumps(response) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
