#!/usr/bin/env python3
"""
Controlled Sharing Benchmark: Measures the value of KO sharing at different levels.

Creates a fictional project domain ("Project Helios") with 40 invented facts
that Claude cannot know. Simulates sharing subsets (0%, 10%, 25%, 50%, 75%, 100%)
and measures accuracy at each level.

All facts are fictional -- zero prior knowledge baseline is guaranteed.
No API keys needed -- context is built directly from KO data.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-xxx
    python benchmark_sharing_controlled.py
    python benchmark_sharing_controlled.py --seeds 42,123,456
"""

from __future__ import annotations

import json
import os
import sys
import time
import random
import urllib.request
import urllib.error
from dataclasses import dataclass, field

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("BENCHMARK_MODEL", "claude-sonnet-4-20250514")

# --- Fictional Domain: Project Helios ---
#
# A quantum calibration platform for satellite constellations.
# Every fact is invented. Claude has zero prior knowledge of this.

HELIOS_KOS = [
    # === Architecture (10 KOs) ===
    {"subject": "Helios database", "predicate": "decided as", "value": "CockroachDB 24.1 on 3 nodes in us-east-1, eu-west-2, ap-south-1. Replication factor 5.", "tags": ["architecture"], "pinned": True, "group": "architecture"},
    {"subject": "Helios auth system", "predicate": "implemented as", "value": "Ed25519 signed JWTs with 4-hour expiry. Refresh tokens stored in Redis with 30-day TTL. Key rotation every 72 hours via HashiCorp Vault.", "tags": ["architecture", "security"], "pinned": True, "group": "architecture"},
    {"subject": "Helios message bus", "predicate": "decided as", "value": "NATS JetStream with 3 streams: calibration.events (1TB retention), telemetry.raw (6h retention), commands.validated (72h retention).", "tags": ["architecture"], "group": "architecture"},
    {"subject": "Helios calibration service", "predicate": "written in", "value": "Rust (calibration-core crate v0.14.2), compiled to WASM for edge deployment on satellite ground stations. P99 latency: 2.3ms.", "tags": ["architecture"], "group": "architecture"},
    {"subject": "Helios API gateway", "predicate": "spec is", "value": "Envoy proxy with rate limiting at 10,000 req/s per tenant. gRPC internally, REST externally. OpenAPI 3.1 spec at /v2/openapi.json.", "tags": ["architecture"], "group": "architecture"},
    {"subject": "Helios storage", "predicate": "tiered as", "value": "Hot: Redis (last 6h telemetry). Warm: CockroachDB (30 days). Cold: S3-compatible MinIO (7 year regulatory retention). Total: 847TB across tiers.", "tags": ["architecture"], "group": "architecture"},
    {"subject": "Helios deployment", "predicate": "runs on", "value": "Kubernetes 1.31 on bare metal (not cloud). 3 datacenters: Ashburn VA, Frankfurt DE, Mumbai IN. GitOps via ArgoCD with 12-minute max deploy time.", "tags": ["architecture", "infrastructure"], "group": "architecture"},
    {"subject": "Helios monitoring", "predicate": "stack is", "value": "VictoriaMetrics for metrics (14-day hot, 2-year cold), Loki for logs, Tempo for traces. Alert routing via PagerDuty with 3 severity tiers.", "tags": ["architecture"], "group": "architecture"},
    {"subject": "Helios schema migrations", "predicate": "tool is", "value": "golang-migrate with sequential numbering. Current: migration 089. All migrations must be backward-compatible (no DROP COLUMN without 2-release deprecation).", "tags": ["architecture"], "group": "architecture"},
    {"subject": "Helios service mesh", "predicate": "implemented as", "value": "Linkerd 2.16 with mTLS between all services. 47 microservices total. Circuit breaker threshold: 50% error rate over 30s window.", "tags": ["architecture"], "group": "architecture"},

    # === Calibration Science (10 KOs) ===
    {"subject": "calibration drift threshold", "predicate": "value is", "value": "0.0037 rad/s. Anything above triggers automatic recalibration. Derived from Kalman filter residuals over 10,000 satellite passes.", "tags": ["calibration", "science"], "pinned": True, "group": "science"},
    {"subject": "phase noise floor", "predicate": "measured at", "value": "-147 dBc/Hz at 1kHz offset. This limits minimum detectable angular rate to 0.00012 rad/s.", "tags": ["calibration", "science"], "group": "science"},
    {"subject": "ionospheric correction model", "predicate": "uses", "value": "Modified Klobuchar with 8 coefficients (not the standard 4). Coefficients updated every 15 minutes from GNSS reference stations. Accuracy: 0.3 TECU RMS.", "tags": ["calibration", "science"], "group": "science"},
    {"subject": "thermal compensation", "predicate": "formula is", "value": "delta_f = -0.034 * (T - 25) + 0.00018 * (T - 25)^2 ppm, where T is in Celsius. Valid from -40C to +85C.", "tags": ["calibration", "science"], "pinned": True, "group": "science"},
    {"subject": "Allan deviation target", "predicate": "specification is", "value": "1.2e-12 at tau=1s, 3.8e-13 at tau=100s, 8.1e-14 at tau=10000s. Currently meeting spec at all integration times except tau=1s (actual: 1.4e-12).", "tags": ["calibration", "science"], "group": "science"},
    {"subject": "satellite constellation", "predicate": "configuration is", "value": "36 satellites in 3 orbital planes at 1,200 km altitude, 55-degree inclination. Constellation name: Meridian-3. Operator: Axiom Orbital.", "tags": ["science"], "group": "science"},
    {"subject": "ground station network", "predicate": "consists of", "value": "12 stations: Svalbard, Kiruna, Fairbanks, McMurdo, Santiago, Perth, Bangalore, Singapore, Hartebeesthoek, Libreville, Tahiti, Guam.", "tags": ["science", "infrastructure"], "group": "science"},
    {"subject": "clock ensemble", "predicate": "composition is", "value": "Each satellite carries 2 Rb clocks (primary/backup) and 1 H-maser (reference). Ground segment uses Cs fountain at PTB Braunschweig for UTC traceability.", "tags": ["science"], "group": "science"},
    {"subject": "multipath mitigation", "predicate": "method is", "value": "Choke ring antenna + MEDLL correlator (Multipath Estimating Delay Lock Loop). Residual multipath error: < 0.15m for elevation > 15 degrees.", "tags": ["science"], "group": "science"},
    {"subject": "tropospheric model", "predicate": "decided as", "value": "VMF3 (Vienna Mapping Function 3) with GPT3 pressure/temperature. Updated hourly. Zenith delay accuracy: 3.2mm RMS dry + 8.7mm RMS wet.", "tags": ["science"], "group": "science"},

    # === Team & Process (10 KOs) ===
    {"subject": "Helios team", "predicate": "members are", "value": "Lead: Dr. Kenji Otsuka (calibration). Backend: Priya Chandrasekaran, Lars Eriksson. Frontend: Mei-Lin Zhou. DevOps: Carlos Restrepo. PM: Sarah Okonkwo. Science advisor: Prof. Yuri Galkin (PTB).", "tags": ["team"], "group": "team"},
    {"subject": "sprint cadence", "predicate": "decided as", "value": "2-week sprints, Tuesday to Monday. Planning on Tuesday 09:00 UTC. Retro on alternating Mondays. No meetings on Wednesdays (deep work day).", "tags": ["process"], "group": "team"},
    {"subject": "code review policy", "predicate": "rule is", "value": "2 approvals required for calibration-core changes. 1 approval for all other services. Dr. Otsuka must approve any change to drift threshold or compensation formulas.", "tags": ["process", "security"], "pinned": True, "group": "team"},
    {"subject": "incident severity", "predicate": "defined as", "value": "SEV1: Calibration accuracy degraded >10x. SEV2: Single ground station offline >2h. SEV3: API error rate >1% for >15min. SEV1 requires all-hands in 30 min.", "tags": ["process"], "group": "team"},
    {"subject": "data classification", "predicate": "policy is", "value": "Tier A (restricted): Raw satellite telemetry, orbital elements, calibration keys. Tier B (internal): Processed measurements, performance metrics. Tier C (public): Aggregate accuracy reports, uptime stats.", "tags": ["security"], "pinned": True, "group": "team"},
    {"subject": "vendor relationship", "predicate": "status is", "value": "Axiom Orbital: 3-year contract (2025-2028), $4.2M/year. Includes exclusive calibration rights for Meridian-3. Renewal discussion starts Q3 2027.", "tags": ["business"], "group": "team"},
    {"subject": "compliance requirements", "predicate": "mandated by", "value": "ITU Radio Regulations (spectrum), ITAR (satellite components), SOC 2 Type II (data handling). Annual audit by Deloitte, next: November 2026.", "tags": ["compliance"], "group": "team"},
    {"subject": "budget constraint", "predicate": "limit is", "value": "Cloud/infra spend capped at $38,000/month. Currently at $31,400. Any new service requiring >$2,000/month needs VP approval from David Chen.", "tags": ["business", "constraint"], "pinned": True, "group": "team"},
    {"subject": "on-call rotation", "predicate": "schedule is", "value": "Weekly rotation: Carlos -> Priya -> Lars -> Mei-Lin. Kenji is permanent secondary for SEV1. Compensation: $500/week flat + $200/incident.", "tags": ["process"], "group": "team"},
    {"subject": "documentation standard", "predicate": "rule is", "value": "All calibration algorithms must have a technical note in /docs/technotes/ with derivation, assumptions, validation data, and author. Format: LaTeX, compiled to PDF by CI.", "tags": ["process"], "group": "team"},

    # === Bugs & Constraints (10 KOs) ===
    {"subject": "NATS reconnection bug", "predicate": "issue is", "value": "After network partition >3 minutes, calibration.events consumers lose exactly the last 127 messages due to JetStream ack window overflow. Workaround: manual replay from sequence ID. Fix in NATS 2.11 (ETA: Q2 2026).", "tags": ["bug"], "group": "constraints"},
    {"subject": "Redis memory limit", "predicate": "constraint is", "value": "Max 64GB per node. At current telemetry rate (23,000 events/sec), this gives exactly 5.7 hours of hot storage. If rate exceeds 28,000/sec, eviction starts and latency degrades.", "tags": ["constraint"], "pinned": True, "group": "constraints"},
    {"subject": "CockroachDB range split", "predicate": "gotcha is", "value": "Tables with >512MB ranges auto-split, causing 200ms latency spikes. The calibration_results table hits this every 18 days. Mitigation: pre-split on satellite_id prefix.", "tags": ["bug", "gotcha"], "group": "constraints"},
    {"subject": "WASM memory ceiling", "predicate": "limitation is", "value": "Edge WASM runtime limited to 256MB. The FFT buffer for multipath analysis consumes 180MB alone. Leaves only 76MB for all other calibration state. Cannot increase without hardware upgrade at ground stations.", "tags": ["constraint"], "group": "constraints"},
    {"subject": "timezone handling", "predicate": "rule is", "value": "All internal timestamps in TAI (International Atomic Time), NOT UTC. TAI = UTC + 37 seconds (as of 2025). Leap second handling is explicitly forbidden in calibration code. Any UTC conversion happens only at API boundary.", "tags": ["constraint", "gotcha"], "pinned": True, "group": "constraints"},
    {"subject": "API versioning", "predicate": "policy is", "value": "URL-based versioning (/v1/, /v2/). v1 deprecated since March 2026, sunset date: September 30, 2026. Currently 23% of traffic still on v1 (mostly Axiom's legacy integration).", "tags": ["constraint"], "group": "constraints"},
    {"subject": "satellite firmware OTA", "predicate": "constraint is", "value": "Firmware updates can only be sent during ascending node passes over Svalbard or Kiruna (visibility window: 8-12 minutes). Max 3 satellites per pass. Full constellation update takes 14 days minimum.", "tags": ["constraint"], "group": "constraints"},
    {"subject": "encryption requirement", "predicate": "mandate is", "value": "All satellite-to-ground links use AES-256-GCM with per-session keys derived via X25519. Key exchange happens in the first 400ms of each pass. If handshake fails, the entire pass is lost.", "tags": ["security", "constraint"], "group": "constraints"},
    {"subject": "precision arithmetic", "predicate": "rule is", "value": "All calibration computations use 128-bit floating point (f128 in Rust). Standard f64 introduces errors at the 14th decimal place which propagate to 0.3mm position error after 24h. This was the root cause of the March 2025 incident.", "tags": ["constraint", "gotcha"], "pinned": True, "group": "constraints"},
    {"subject": "ground station downtime", "predicate": "known issue is", "value": "Perth station has intermittent GPS disciplined oscillator failures (averaging 2.3 outages/month, 45min each). Root cause: faulty Trimble Thunderbolt-E unit, replacement backordered until August 2026.", "tags": ["bug"], "group": "constraints"},
]

# --- Test Questions (30 questions, grouped by difficulty) ---

HELIOS_QUESTIONS = [
    # === Factual Recall -- exact numbers (12 questions) ===
    {"id": 1, "category": "factual", "group": "architecture",
     "question": "What database does Helios use and how many nodes?",
     "expected_keywords": ["cockroachdb", "24.1", "3 nodes"],
     "min_keywords": 2},
    {"id": 2, "category": "factual", "group": "science",
     "question": "What is the calibration drift threshold?",
     "expected_keywords": ["0.0037", "rad/s"],
     "min_keywords": 2},
    {"id": 3, "category": "factual", "group": "science",
     "question": "What is the thermal compensation formula?",
     "expected_keywords": ["-0.034", "0.00018", "ppm"],
     "min_keywords": 2},
    {"id": 4, "category": "factual", "group": "architecture",
     "question": "What are the NATS JetStream stream names and their retention periods?",
     "expected_keywords": ["calibration.events", "1tb", "telemetry.raw", "6h", "commands.validated", "72h"],
     "min_keywords": 4},
    {"id": 5, "category": "factual", "group": "team",
     "question": "Who is the Helios team lead and what's their specialty?",
     "expected_keywords": ["kenji", "otsuka", "calibration"],
     "min_keywords": 2},
    {"id": 6, "category": "factual", "group": "science",
     "question": "How many satellites are in the constellation and at what altitude?",
     "expected_keywords": ["36", "1,200", "1200"],
     "min_keywords": 2},
    {"id": 7, "category": "factual", "group": "team",
     "question": "What is the monthly infrastructure budget cap?",
     "expected_keywords": ["38,000", "38000"],
     "min_keywords": 1},
    {"id": 8, "category": "factual", "group": "constraints",
     "question": "How much memory does the edge WASM runtime allow, and how much does the FFT buffer use?",
     "expected_keywords": ["256mb", "256", "180mb", "180"],
     "min_keywords": 2},
    {"id": 9, "category": "factual", "group": "science",
     "question": "What Allan deviation values are specified at tau=1s and tau=10000s?",
     "expected_keywords": ["1.2e-12", "8.1e-14"],
     "min_keywords": 2},
    {"id": 10, "category": "factual", "group": "architecture",
     "question": "What is the P99 latency of the calibration service?",
     "expected_keywords": ["2.3ms", "2.3"],
     "min_keywords": 1},
    {"id": 11, "category": "factual", "group": "constraints",
     "question": "How many messages are lost during the NATS reconnection bug?",
     "expected_keywords": ["127"],
     "min_keywords": 1},
    {"id": 12, "category": "factual", "group": "team",
     "question": "When is the next compliance audit and by whom?",
     "expected_keywords": ["november", "2026", "deloitte"],
     "min_keywords": 2},

    # === Decision Recall -- must explain WHY (8 questions) ===
    {"id": 13, "category": "decision", "group": "constraints",
     "question": "Why does Helios use TAI instead of UTC for internal timestamps?",
     "expected_keywords": ["leap second", "forbidden", "calibration"],
     "min_keywords": 2},
    {"id": 14, "category": "decision", "group": "constraints",
     "question": "Why does Helios require 128-bit floating point for calibration?",
     "expected_keywords": ["f64", "14th", "0.3mm", "march 2025"],
     "min_keywords": 2},
    {"id": 15, "category": "decision", "group": "architecture",
     "question": "Why is the calibration service written in Rust and compiled to WASM?",
     "expected_keywords": ["edge", "ground station"],
     "min_keywords": 2},
    {"id": 16, "category": "decision", "group": "architecture",
     "question": "Why does Helios run on bare metal Kubernetes instead of cloud?",
     "expected_keywords": ["bare metal", "not cloud"],
     "min_keywords": 1},
    {"id": 17, "category": "decision", "group": "science",
     "question": "Why does Helios use a modified Klobuchar model with 8 coefficients instead of the standard 4?",
     "expected_keywords": ["8", "0.3", "tecu"],
     "min_keywords": 2},
    {"id": 18, "category": "decision", "group": "team",
     "question": "Why must Dr. Otsuka approve changes to drift thresholds?",
     "expected_keywords": ["calibration", "otsuka", "approve"],
     "min_keywords": 2},
    {"id": 19, "category": "decision", "group": "architecture",
     "question": "Why is the CockroachDB calibration_results table pre-split on satellite_id?",
     "expected_keywords": ["512mb", "512", "latency", "spike", "18 day"],
     "min_keywords": 2},
    {"id": 20, "category": "decision", "group": "constraints",
     "question": "Why can a full constellation firmware update take 14 days?",
     "expected_keywords": ["svalbard", "kiruna", "3 satellite", "8", "12", "minute"],
     "min_keywords": 3},

    # === Constraint Enforcement -- must push back (10 questions) ===
    {"id": 21, "category": "constraint", "group": "constraints",
     "question": "I'm going to use standard f64 doubles for this new calibration routine. Should be fine for our precision needs.",
     "expected_keywords": ["no", "128", "f128", "error", "0.3mm", "march 2025"],
     "min_keywords": 2},
    {"id": 22, "category": "constraint", "group": "constraints",
     "question": "Let's store timestamps in UTC to keep things simple.",
     "expected_keywords": ["no", "tai", "leap second"],
     "min_keywords": 2},
    {"id": 23, "category": "constraint", "group": "team",
     "question": "I want to add a new monitoring service that costs $3,500/month.",
     "expected_keywords": ["38,000", "38000", "31,400", "31400", "david chen", "vp", "approval", "$2,000", "2000"],
     "min_keywords": 2},
    {"id": 24, "category": "constraint", "group": "team",
     "question": "I'll push this calibration formula change directly after one review.",
     "expected_keywords": ["2", "two", "approval", "otsuka", "kenji"],
     "min_keywords": 2},
    {"id": 25, "category": "constraint", "group": "constraints",
     "question": "We should increase the telemetry rate to 35,000 events/sec to improve resolution.",
     "expected_keywords": ["28,000", "28000", "64gb", "eviction", "5.7"],
     "min_keywords": 2},
    {"id": 26, "category": "constraint", "group": "team",
     "question": "I'll include the raw satellite telemetry data in the quarterly public report.",
     "expected_keywords": ["no", "tier a", "restricted", "public", "aggregate"],
     "min_keywords": 2},
    {"id": 27, "category": "constraint", "group": "architecture",
     "question": "Let's drop the old user_preferences column in this migration.",
     "expected_keywords": ["no", "backward", "compatible", "2-release", "deprecation", "drop column"],
     "min_keywords": 2},
    {"id": 28, "category": "constraint", "group": "constraints",
     "question": "Can we send the firmware update to all 36 satellites this afternoon?",
     "expected_keywords": ["no", "14 day", "3 satellite", "svalbard", "kiruna"],
     "min_keywords": 2},
    {"id": 29, "category": "constraint", "group": "team",
     "question": "Let's schedule this design review for Wednesday at 2pm.",
     "expected_keywords": ["no", "wednesday", "deep work", "no meeting"],
     "min_keywords": 2},
    {"id": 30, "category": "constraint", "group": "science",
     "question": "I'll add leap second handling to the calibration pipeline for correctness.",
     "expected_keywords": ["no", "forbidden", "tai", "api boundary"],
     "min_keywords": 2},
]


# --- Context Builder ---

def build_ko_context(kos: list[dict]) -> str:
    """Build a context string from KOs, matching CoreTx Connect ko_context format."""
    if not kos:
        return "No shared knowledge available."

    pinned = [ko for ko in kos if ko.get("pinned")]
    unpinned = [ko for ko in kos if not ko.get("pinned")]

    lines = ["# Session Context (Shared Knowledge)\n"]

    if pinned:
        lines.append("## Pinned")
        for ko in pinned:
            lines.append(f"- **{ko['subject']}** ({ko['predicate']}): {ko['value']}")
        lines.append("")

    if unpinned:
        lines.append("## Recent")
        for ko in unpinned:
            lines.append(f"- **{ko['subject']}** ({ko['predicate']}): {ko['value']}")
        lines.append("")

    lines.append(f"---\n{len(kos)} KOs loaded.")
    return "\n".join(lines)


# --- Claude Client ---

def call_claude(system_prompt: str, user_message: str) -> str:
    if not ANTHROPIC_API_KEY:
        return "[ERROR: ANTHROPIC_API_KEY not set]"
    body = json.dumps({
        "model": MODEL,
        "max_tokens": 500,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_message}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode())
            return result["content"][0]["text"]
    except urllib.error.HTTPError as e:
        body_text = e.read().decode() if e.fp else ""
        return f"[API ERROR {e.code}: {body_text[:200]}]"
    except Exception as e:
        return f"[ERROR: {e}]"


# --- Scoring ---

def score_answer(answer: str, question: dict) -> dict:
    answer_lower = answer.lower()
    found = [kw for kw in question["expected_keywords"] if kw.lower() in answer_lower]
    missed = [kw for kw in question["expected_keywords"] if kw.lower() not in answer_lower]
    passed = len(found) >= question["min_keywords"]
    return {
        "question_id": question["id"],
        "category": question["category"],
        "group": question["group"],
        "passed": passed,
        "keywords_found": found,
        "keywords_missed": missed,
        "hit_count": len(found),
        "min_needed": question["min_keywords"],
    }


# --- Run Benchmark ---

@dataclass
class ShareLevelResult:
    share_pct: int
    kos_shared: int
    groups_covered: set = field(default_factory=set)
    total_questions: int = 0
    passed: int = 0
    accuracy: float = 0.0
    by_category: dict = field(default_factory=dict)
    results: list = field(default_factory=list)
    duration_s: float = 0.0


def select_subset(all_kos: list[dict], pct: int, rng: random.Random) -> list[dict]:
    """Select a subset of KOs, prioritizing pinned ones."""
    n_share = max(1, int(len(all_kos) * pct / 100))
    pinned = [ko for ko in all_kos if ko.get("pinned")]
    unpinned = [ko for ko in all_kos if not ko.get("pinned")]
    shuffled_unpinned = list(unpinned)
    rng.shuffle(shuffled_unpinned)

    if n_share <= len(pinned):
        return pinned[:n_share]
    else:
        return pinned + shuffled_unpinned[:n_share - len(pinned)]


def run_share_level(share_pct: int, shared_context: str, label: str) -> ShareLevelResult:
    """Run all questions with the given shared context."""
    system_prompt = (
        "You are an AI assistant helping a new team member on Project Helios, "
        "a quantum calibration platform for satellite constellations. "
        "A colleague has shared their project knowledge with you:\n\n"
        f"{shared_context}\n\n"
        "Use this knowledge to answer questions accurately. "
        "If a question involves a constraint or rule, enforce it firmly. "
        "If you don't have the information, say you don't know."
    )

    run = ShareLevelResult(share_pct=share_pct, kos_shared=0)
    start = time.time()

    print(f"\n{'='*60}")
    print(f"Share Level: {label}")
    print(f"{'='*60}")

    for q in HELIOS_QUESTIONS:
        answer = call_claude(system_prompt, q["question"])
        result = score_answer(answer, q)
        result["answer"] = answer
        run.results.append(result)
        status = "PASS" if result["passed"] else "FAIL"
        print(f"  [{status}] Q{q['id']:2d} ({q['category']:12s} / {q['group']:14s}): {result['hit_count']}/{len(q['expected_keywords'])} keywords")
        time.sleep(0.3)

    run.duration_s = time.time() - start
    run.total_questions = len(HELIOS_QUESTIONS)
    run.passed = sum(1 for r in run.results if r["passed"])
    run.accuracy = run.passed / run.total_questions if run.total_questions > 0 else 0

    # Category breakdown
    cats = {}
    for r in run.results:
        cat = r["category"]
        if cat not in cats:
            cats[cat] = {"total": 0, "passed": 0}
        cats[cat]["total"] += 1
        if r["passed"]:
            cats[cat]["passed"] += 1
    for cat, data in cats.items():
        data["accuracy"] = data["passed"] / data["total"] if data["total"] > 0 else 0
    run.by_category = cats

    return run


def run_single_seed(seed: int, share_levels: list[int]) -> list[ShareLevelResult]:
    """Run all share levels for a single seed."""
    rng = random.Random(seed)
    all_runs = []

    print(f"\n{'#'*60}")
    print(f"SEED {seed}")
    print(f"{'#'*60}")

    for pct in share_levels:
        if pct == 0:
            context = "No shared knowledge available."
            label = f"0% (no sharing)"
            n_share = 0
            groups = set()
        elif pct == 100:
            subset = list(HELIOS_KOS)
            context = build_ko_context(subset)
            label = f"100% ({len(subset)} KOs)"
            n_share = len(subset)
            groups = set(ko["group"] for ko in subset)
        else:
            subset = select_subset(HELIOS_KOS, pct, rng)
            context = build_ko_context(subset)
            n_share = len(subset)
            label = f"{pct}% ({n_share} KOs)"
            groups = set(ko["group"] for ko in subset)

        run = run_share_level(pct, context, label)
        run.kos_shared = n_share
        run.groups_covered = groups
        all_runs.append(run)
        print(f"\n  -> {pct}%: {run.accuracy:.0%} ({run.passed}/{run.total_questions})")

    return all_runs


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Controlled Sharing Benchmark")
    parser.add_argument("--seeds", default="42", help="Comma-separated seeds (default: 42)")
    parser.add_argument("--share-levels", default="0,10,25,50,75,100", help="Comma-separated share percentages")
    parser.add_argument("--output", default="benchmark_sharing_controlled_results.json")
    args = parser.parse_args()

    if not ANTHROPIC_API_KEY:
        print("ERROR: ANTHROPIC_API_KEY not set.")
        sys.exit(1)

    seeds = [int(x) for x in args.seeds.split(",")]
    share_levels = [int(x) for x in args.share_levels.split(",")]

    print(f"Sharing Value Benchmark")
    print(f"Model: {MODEL}")
    print(f"Seeds: {seeds}")
    print(f"Share levels: {share_levels}")
    print(f"KOs: {len(HELIOS_KOS)}, Questions: {len(HELIOS_QUESTIONS)}")
    print(f"Domain: Project Helios (fictional -- zero prior knowledge)")

    # Run all seeds
    all_seed_runs = {}
    for seed in seeds:
        all_seed_runs[seed] = run_single_seed(seed, share_levels)

    # Aggregate across seeds
    print(f"\n{'='*70}")
    print("SHARING VALUE CURVE" + (f" ({len(seeds)}-seed mean)" if len(seeds) > 1 else ""))
    print(f"{'='*70}\n")

    print(f"{'Share %':<10} {'KOs':>6} {'Accuracy':>10} {'Factual':>10} {'Decision':>10} {'Constraint':>12}")
    print("-" * 62)

    summary_by_level = {}
    for i, pct in enumerate(share_levels):
        accuracies = []
        fact_accs = []
        dec_accs = []
        con_accs = []
        n_kos = 0

        for seed in seeds:
            run = all_seed_runs[seed][i]
            accuracies.append(run.accuracy)
            fact_accs.append(run.by_category.get("factual", {}).get("accuracy", 0))
            dec_accs.append(run.by_category.get("decision", {}).get("accuracy", 0))
            con_accs.append(run.by_category.get("constraint", {}).get("accuracy", 0))
            n_kos = run.kos_shared

        mean_acc = sum(accuracies) / len(accuracies)
        mean_fact = sum(fact_accs) / len(fact_accs)
        mean_dec = sum(dec_accs) / len(dec_accs)
        mean_con = sum(con_accs) / len(con_accs)

        if len(seeds) > 1:
            import statistics
            std = statistics.stdev(accuracies) if len(accuracies) > 1 else 0
            print(f"{pct:>5}% {n_kos:>6} {mean_acc:>8.0%}+-{std:.0%} {mean_fact:>9.0%} {mean_dec:>9.0%} {mean_con:>11.0%}")
        else:
            print(f"{pct:>5}% {n_kos:>6} {mean_acc:>9.0%} {mean_fact:>9.0%} {mean_dec:>9.0%} {mean_con:>11.0%}")

        summary_by_level[pct] = {
            "mean_accuracy": mean_acc,
            "accuracies": accuracies,
            "mean_factual": mean_fact,
            "mean_decision": mean_dec,
            "mean_constraint": mean_con,
            "kos_shared": n_kos,
        }

    # Save results
    output = {
        "model": MODEL,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "test": "controlled_sharing_benchmark",
        "domain": "Project Helios (fictional quantum calibration platform)",
        "total_kos": len(HELIOS_KOS),
        "total_questions": len(HELIOS_QUESTIONS),
        "share_levels": share_levels,
        "seeds": seeds,
        "summary": summary_by_level,
        "runs_by_seed": {},
    }
    for seed in seeds:
        output["runs_by_seed"][str(seed)] = []
        for run in all_seed_runs[seed]:
            output["runs_by_seed"][str(seed)].append({
                "share_pct": run.share_pct,
                "kos_shared": run.kos_shared,
                "accuracy": run.accuracy,
                "passed": run.passed,
                "total": run.total_questions,
                "by_category": run.by_category,
                "groups_covered": list(run.groups_covered) if run.groups_covered else [],
                "duration_s": run.duration_s,
                "results": run.results,
            })

    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nResults saved to {args.output}")


if __name__ == "__main__":
    main()
