#!/usr/bin/env python3
"""
Scaling Curve Benchmark: Does KO retrieval degrade as the store grows?

Tests accuracy when the KO store contains increasing numbers of KOs:
50, 100, 250, 500, 1000. At each level, the 50 "real" KOs from the Nexus
project are present, plus N-50 distractor KOs from unrelated domains.

The question set is the same 25 questions as the main benchmark.
If KO memory scales, accuracy should remain high even at 1000 KOs.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-xxx
    python benchmark_scaling.py
    python benchmark_scaling.py --sizes 50,100,250,500,1000
"""

from __future__ import annotations

import json
import os
import sys
import time
import random
import urllib.request
import urllib.error
from dataclasses import dataclass, field

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("BENCHMARK_MODEL", "claude-sonnet-4-20250514")

# Import the real Nexus facts and questions from the main benchmark
from benchmark import ALL_FACTS, QUESTIONS, call_claude, score_answer

# --- Distractor KO Generator ---
# Generates plausible-looking KOs from unrelated domains to dilute the context

DISTRACTOR_DOMAINS = [
    {
        "prefix": "QuantumNet",
        "subjects": [
            "qubit topology", "error correction", "gate fidelity", "decoherence time",
            "cryostat temperature", "readout circuit", "calibration frequency",
            "transpiler optimization", "noise model", "entanglement protocol",
            "surface code", "magic state distillation", "quantum volume",
            "crosstalk mitigation", "flux tuning", "Josephson junction",
        ],
        "predicates": ["decided as", "value is", "constraint is", "method is", "finding is"],
    },
    {
        "prefix": "TerraWatch",
        "subjects": [
            "satellite revisit time", "spectral band", "cloud masking", "DEM resolution",
            "atmospheric correction", "land use classifier", "NDVI threshold",
            "tile processing", "orbit propagator", "ground station", "SAR calibration",
            "radiometric correction", "pansharpening", "change detection", "data cube",
            "sentinel integration", "thermal anomaly", "coastline extraction",
        ],
        "predicates": ["decided as", "specification is", "rule is", "finding is", "limit is"],
    },
    {
        "prefix": "FinLedger",
        "subjects": [
            "settlement window", "margin calculation", "FIX protocol", "order routing",
            "risk engine", "position limit", "regulatory report", "trade reconciliation",
            "market data feed", "latency budget", "failover protocol", "audit trail",
            "compliance check", "basket execution", "dark pool routing",
            "smart order router", "post-trade processing", "clearing obligation",
        ],
        "predicates": ["decided as", "rule is", "constraint is", "value is", "policy is"],
    },
    {
        "prefix": "EduPath",
        "subjects": [
            "learning objective", "assessment rubric", "curriculum alignment",
            "student progress", "adaptive difficulty", "content sequencing",
            "engagement metric", "mastery threshold", "spaced repetition",
            "peer review protocol", "accessibility standard", "LTI integration",
            "grade weighting", "plagiarism detection", "rubric calibration",
            "cohort analysis", "intervention trigger", "credential verification",
        ],
        "predicates": ["decided as", "rule is", "policy is", "threshold is", "finding is"],
    },
    {
        "prefix": "AgriSense",
        "subjects": [
            "soil moisture", "irrigation schedule", "pest detection", "yield model",
            "fertilizer rate", "drone flight path", "weather integration",
            "crop rotation", "harvest timing", "seed variety", "field boundary",
            "nutrient analysis", "canopy coverage", "frost warning", "drainage map",
            "soil pH", "pollinator monitoring", "greenhouse controller",
        ],
        "predicates": ["decided as", "measured at", "threshold is", "rule is", "finding is"],
    },
]


def generate_distractor_ko(domain: dict, rng: random.Random, idx: int) -> dict:
    """Generate a single plausible-looking distractor KO."""
    subject = rng.choice(domain["subjects"])
    predicate = rng.choice(domain["predicates"])
    # Generate a plausible value with specific numbers
    templates = [
        f"Configured at {rng.uniform(0.1, 99.9):.1f} with {rng.randint(2, 50)} nodes in {rng.choice(['us-east-1', 'eu-west-2', 'ap-southeast-1'])}. Replication factor {rng.randint(2, 7)}.",
        f"Threshold set to {rng.uniform(0.001, 0.999):.3f} based on {rng.randint(100, 10000)} sample evaluation. Reviewed quarterly by {rng.choice(['Dr. Kim', 'Dr. Patel', 'Dr. Schmidt', 'Dr. Torres'])}.",
        f"Maximum {rng.randint(10, 5000)} per {rng.choice(['day', 'hour', 'batch', 'epoch'])}. Current utilization: {rng.randint(20, 95)}%. Budget: ${rng.randint(500, 50000)}/month.",
        f"Version {rng.randint(1, 12)}.{rng.randint(0, 9)} deployed on {rng.choice(['Kubernetes', 'Nomad', 'ECS', 'bare metal'])}. Latency P99: {rng.uniform(1, 500):.1f}ms. SLA: {rng.uniform(99.0, 99.99):.2f}%.",
        f"Pipeline stage {rng.randint(1, 8)} of {rng.randint(8, 15)}. Processing time: {rng.uniform(0.5, 120):.1f}s mean. Error rate: {rng.uniform(0.01, 5.0):.2f}%. Retry limit: {rng.randint(1, 5)}.",
    ]
    value = rng.choice(templates)
    return {
        "subject": f"{domain['prefix']} {subject}",
        "predicate": predicate,
        "value": value,
        "tags": [domain["prefix"].lower()],
        "pinned": rng.random() < 0.1,  # 10% pinned
    }


def generate_distractors(n: int, seed: int = 42) -> list[dict]:
    """Generate n distractor KOs from random domains."""
    rng = random.Random(seed)
    distractors = []
    for i in range(n):
        domain = rng.choice(DISTRACTOR_DOMAINS)
        distractors.append(generate_distractor_ko(domain, rng, i))
    return distractors


def build_scaled_context(real_facts: list[dict], distractors: list[dict], rng: random.Random) -> str:
    """Build a KO context with real facts mixed in among distractors."""
    # Combine and shuffle
    all_kos = []
    for f in real_facts:
        all_kos.append({
            "subject": f["subject"],
            "predicate": f["predicate"],
            "value": f["value"],
            "pinned": f.get("pinned", False),
        })
    for d in distractors:
        all_kos.append(d)

    # Separate pinned from unpinned, shuffle unpinned
    pinned = [ko for ko in all_kos if ko.get("pinned")]
    unpinned = [ko for ko in all_kos if not ko.get("pinned")]
    rng.shuffle(unpinned)

    lines = ["# Session Context (from CoreTx Connect)\n"]
    if pinned:
        lines.append(f"## Pinned ({len(pinned)} critical)\n")
        for ko in pinned:
            lines.append(f"- **{ko['subject']}** ({ko['predicate']}): {ko['value']}")
        lines.append("")

    lines.append(f"## Recent & Semantic ({len(unpinned)} KOs)\n")
    for ko in unpinned:
        lines.append(f"- **{ko['subject']}** ({ko['predicate']}): {ko['value']}")
    lines.append("")
    lines.append(f"---\n{len(all_kos)} KOs loaded.")

    return "\n".join(lines)


# --- Run Benchmark ---

@dataclass
class ScalingResult:
    total_kos: int
    real_kos: int
    distractor_kos: int
    accuracy: float = 0.0
    passed: int = 0
    total_questions: int = 0
    by_category: dict = field(default_factory=dict)
    results: list = field(default_factory=list)
    duration_s: float = 0.0
    context_chars: int = 0


def run_at_scale(total_kos: int, seed: int = 42) -> ScalingResult:
    """Run the benchmark with a specific number of total KOs."""
    rng = random.Random(seed)
    n_distractors = max(0, total_kos - len(ALL_FACTS))
    distractors = generate_distractors(n_distractors, seed=seed)

    context = build_scaled_context(ALL_FACTS, distractors, rng)

    system_prompt = (
        "You are an AI assistant working on Nexus, a distributed bioinformatics "
        "pipeline for protein folding ensemble analysis. "
        "You have persistent knowledge from previous sessions via CoreTx Connect:\n\n"
        f"{context}\n\n"
        "Use this knowledge to answer questions accurately. "
        "If a question involves a constraint or rule, enforce it firmly. "
        "Focus on information relevant to Nexus when answering."
    )

    result = ScalingResult(
        total_kos=total_kos,
        real_kos=len(ALL_FACTS),
        distractor_kos=n_distractors,
        context_chars=len(context),
    )
    start = time.time()

    print(f"\n{'='*60}")
    print(f"Scale: {total_kos} KOs ({len(ALL_FACTS)} real + {n_distractors} distractors)")
    print(f"Context size: {len(context):,} chars")
    print(f"{'='*60}")

    for q in QUESTIONS:
        answer = call_claude(system_prompt, q["question"])
        scored = score_answer(answer, q)
        scored["answer"] = answer
        result.results.append(scored)
        status = "PASS" if scored["passed"] else "FAIL"
        print(f"  [{status}] Q{q['id']:2d} ({q['category']:20s}): {scored['hit_count']}/{len(q['expected_keywords'])} keywords")
        time.sleep(1.5)

    result.duration_s = time.time() - start
    result.total_questions = len(QUESTIONS)
    result.passed = sum(1 for r in result.results if r["passed"])
    result.accuracy = result.passed / result.total_questions

    # Category breakdown
    cats = {}
    for r in result.results:
        cat = r["category"]
        if cat not in cats:
            cats[cat] = {"total": 0, "passed": 0}
        cats[cat]["total"] += 1
        if r["passed"]:
            cats[cat]["passed"] += 1
    for cat, data in cats.items():
        data["accuracy"] = data["passed"] / data["total"] if data["total"] > 0 else 0
    result.by_category = cats

    return result


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Scaling Curve Benchmark")
    parser.add_argument("--sizes", default="50,100,250,500,1000",
                        help="Comma-separated KO store sizes to test")
    parser.add_argument("--seeds", type=int, default=1)
    parser.add_argument("--output", default="benchmark_scaling_results.json")
    args = parser.parse_args()

    if not ANTHROPIC_API_KEY:
        print("ERROR: ANTHROPIC_API_KEY not set.")
        sys.exit(1)

    sizes = [int(x) for x in args.sizes.split(",")]
    seed_list = [42, 123, 456, 789, 1337]

    print(f"Scaling Curve Benchmark")
    print(f"Model: {MODEL}")
    print(f"Sizes: {sizes}")
    print(f"Seeds: {args.seeds}")
    print(f"Real KOs: {len(ALL_FACTS)}, Questions: {len(QUESTIONS)}")

    all_results = {}
    for seed_idx in range(args.seeds):
        seed = seed_list[seed_idx % 5]
        print(f"\n{'#'*60}")
        print(f"SEED {seed}")
        print(f"{'#'*60}")

        for size in sizes:
            result = run_at_scale(size, seed=seed)
            all_results.setdefault(size, []).append(result)
            print(f"\n  -> {size} KOs: {result.accuracy:.0%} ({result.passed}/{result.total_questions})")

    # Summary
    print(f"\n{'='*70}")
    print(f"SCALING CURVE" + (f" ({args.seeds}-seed mean)" if args.seeds > 1 else ""))
    print(f"{'='*70}\n")

    print(f"{'KOs':>6} {'Distractors':>12} {'Accuracy':>10} {'Factual':>10} {'Decision':>10} {'Constraint':>12} {'Context':>10}")
    print("-" * 78)

    summary = {}
    for size in sizes:
        results = all_results[size]
        accs = [r.accuracy for r in results]
        mean_acc = sum(accs) / len(accs)
        fact_accs = [r.by_category.get("fact_retention", {}).get("accuracy", 0) for r in results]
        dec_accs = [r.by_category.get("decision_recall", {}).get("accuracy", 0) for r in results]
        con_accs = [r.by_category.get("constraint", {}).get("accuracy", 0) for r in results]
        mean_ctx = sum(r.context_chars for r in results) / len(results)

        mean_fact = sum(fact_accs) / len(fact_accs)
        mean_dec = sum(dec_accs) / len(dec_accs)
        mean_con = sum(con_accs) / len(con_accs)

        n_dist = size - len(ALL_FACTS)
        print(f"{size:>6} {n_dist:>12} {mean_acc:>9.0%} {mean_fact:>9.0%} {mean_dec:>9.0%} {mean_con:>11.0%} {mean_ctx:>9,.0f}")

        summary[size] = {
            "mean_accuracy": mean_acc,
            "accuracies": accs,
            "mean_factual": mean_fact,
            "mean_decision": mean_dec,
            "mean_constraint": mean_con,
            "mean_context_chars": mean_ctx,
            "distractors": n_dist,
        }

    # Save
    output = {
        "model": MODEL,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "test": "scaling_curve",
        "domain": "Nexus (fictional bioinformatics pipeline)",
        "real_kos": len(ALL_FACTS),
        "questions": len(QUESTIONS),
        "sizes": sizes,
        "seeds": args.seeds,
        "summary": summary,
        "runs": {},
    }
    for size, results in all_results.items():
        output["runs"][str(size)] = [{
            "total_kos": r.total_kos,
            "accuracy": r.accuracy,
            "passed": r.passed,
            "total": r.total_questions,
            "by_category": r.by_category,
            "context_chars": r.context_chars,
            "duration_s": r.duration_s,
            "results": r.results,
        } for r in results]

    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nResults saved to {args.output}")


if __name__ == "__main__":
    main()
