#!/usr/bin/env python3
"""
CoreTx Connect Benchmark: KO Memory vs Default Session Memory

Measures how well an AI assistant retains knowledge across simulated session
boundaries, comparing:
  1. No memory    -- fresh context each session (baseline)
  2. .md memory   -- MEMORY.md file loaded into context (Claude Code default)
  3. KO memory    -- CoreTx Connect ko_context loaded at session start

All data uses a fictional project domain ("Nexus" -- a distributed
bioinformatics pipeline for protein folding ensemble analysis). Every fact
is invented. Claude has zero prior knowledge of this project.

Tests three dimensions:
  - Fact retention: Can the assistant recall specific facts from earlier sessions?
  - Decision recall: Does it remember WHY a decision was made?
  - Constraint preservation: Does it respect constraints established earlier?

Usage:
    export ANTHROPIC_API_KEY=sk-ant-xxx
    python benchmark.py                   # run all conditions, 1 seed
    python benchmark.py --condition ko    # run one condition
    python benchmark.py --seeds 5         # multi-seed for significance
"""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import dataclass, field
import urllib.request
import urllib.error

# --- Configuration ---

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("BENCHMARK_MODEL", "claude-sonnet-4-20250514")

# --- Fictional Project: Nexus ---
#
# A distributed bioinformatics pipeline for protein folding ensemble analysis.
# Every fact is invented. Claude has zero prior knowledge of this.
# Domain chosen to be specific enough that no real project matches.

SESSIONS = [
    {
        "id": 1,
        "description": "Project kickoff: architecture decisions",
        "facts": [
            {"subject": "Nexus database", "predicate": "decided as", "value": "ScyllaDB 5.4 on 5 nodes, us-west-2 region. Replication factor 3. Chosen over Cassandra for lower tail latency on ensemble queries.", "tags": ["architecture"], "pinned": True},
            {"subject": "Nexus auth system", "predicate": "decided as", "value": "mTLS client certificates with SPIFFE IDs. No passwords, no API keys. Certificate rotation every 48 hours via Vault PKI engine.", "tags": ["architecture", "security"], "pinned": True},
            {"subject": "Nexus compute backend", "predicate": "decided as", "value": "Ray 2.9 cluster on 8 GPU nodes (A100 80GB). Job scheduler: custom priority queue based on protein family urgency. Max 12 concurrent folding jobs.", "tags": ["architecture"]},
            {"subject": "Nexus message queue", "predicate": "decided as", "value": "Apache Pulsar with 4 topics: fold.requests (7-day retention), fold.results (30-day), ensemble.events (90-day), alerts.critical (1-year).", "tags": ["architecture"]},
            {"subject": "Nexus API", "predicate": "spec is", "value": "GraphQL via Apollo Server 4. REST fallback at /api/v2/. Rate limit: 500 req/s authenticated, 50 req/s anonymous. Schema at /graphql/schema.", "tags": ["architecture"]},
            {"subject": "Nexus storage", "predicate": "tiered as", "value": "Hot: NVMe (last 48h results). Warm: Ceph (6 months). Cold: Backblaze B2 (indefinite, $6/TB/month). Total: 2.3 PB across tiers.", "tags": ["architecture"]},
            {"subject": "Nexus deployment", "predicate": "runs on", "value": "Nomad 1.7 on bare metal at SDSC (San Diego Supercomputer Center). Not Kubernetes. GitOps via Atlantis with 8-minute max deploy.", "tags": ["architecture", "infrastructure"]},
            {"subject": "Nexus monitoring", "predicate": "stack is", "value": "Mimir for metrics (30-day hot, 1-year cold), Grafana Loki for logs, Jaeger for traces. On-call via Opsgenie with 4 severity tiers.", "tags": ["architecture"]},
            {"subject": "Nexus cost constraint", "predicate": "limit is", "value": "GPU compute budget capped at $47,000/month. Currently at $38,200. Any new experiment requiring >$3,000/month needs PI approval from Dr. Vasquez.", "tags": ["constraint"], "pinned": True},
            {"subject": "Nexus email notifications", "predicate": "provider is", "value": "Postmark, from address pipeline@nexus-bio.org. Transactional only, no marketing. Daily digest at 06:00 UTC for completed folds.", "tags": ["infrastructure"]},
        ],
    },
    {
        "id": 2,
        "description": "Building the ensemble analysis engine",
        "facts": [
            {"subject": "ensemble engine", "predicate": "architecture is", "value": "Four-stage pipeline: candidate generation (ESMFold) -> refinement (OpenMM) -> clustering (HDBSCAN epsilon=0.3) -> consensus scoring. AlphaFold only for validation, never production.", "tags": ["architecture"], "pinned": True},
            {"subject": "confidence threshold", "predicate": "value is", "value": "pLDDT >= 72.5 for inclusion in ensemble. Below 72.5, the structure is flagged but not discarded (goes to manual review queue).", "tags": ["science"], "pinned": True},
            {"subject": "RMSD convergence", "predicate": "criterion is", "value": "Ensemble converges when pairwise RMSD standard deviation < 0.8 Angstroms across top 5 models. Currently achieving 0.62A mean.", "tags": ["science"]},
            {"subject": "memory leak bug", "predicate": "issue is", "value": "OpenMM refinement leaks 340MB per 1000 residues due to Context objects not being garbage collected. Workaround: subprocess isolation with 4GB memory cap per fold.", "tags": ["bug"]},
            {"subject": "GPU utilization", "predicate": "optimization is", "value": "Batch folding increased GPU utilization from 34% to 78%. Key insight: group proteins by sequence length within 10% bins to minimize padding waste.", "tags": ["optimization"]},
            {"subject": "clustering parameter", "predicate": "decided as", "value": "HDBSCAN min_cluster_size=5, min_samples=3, metric='precomputed' with TM-score distance matrix. Tested 47 parameter combinations.", "tags": ["science"]},
            {"subject": "consensus scoring", "predicate": "formula is", "value": "Score = 0.40*mean_pLDDT + 0.25*cluster_density + 0.20*structural_agreement + 0.15*energy_favorability. Weights derived from 2,300 benchmark structures.", "tags": ["science"], "pinned": True},
            {"subject": "disulfide bond handling", "predicate": "rule is", "value": "Cysteine pairs within 2.8A are automatically bonded. Pairs between 2.8-3.5A are flagged for manual review. Above 3.5A, no bond. Incorrect SS bonds caused the February 2026 retraction.", "tags": ["science", "constraint"]},
            {"subject": "max sequence length", "predicate": "limit is", "value": "2,048 residues per chain. Longer sequences must be split at domain boundaries using InterPro annotations. The A100 80GB OOMs at 2,200+ residues.", "tags": ["constraint"]},
            {"subject": "validation dataset", "predicate": "composition is", "value": "CASP15 targets (n=87) plus 412 manually curated structures from PDB (resolution < 2.0A). Total: 499 validation structures.", "tags": ["data"]},
        ],
    },
    {
        "id": 3,
        "description": "Data governance and compliance",
        "facts": [
            {"subject": "data classification", "predicate": "policy is", "value": "Level 1 (public): Published PDB structures. Level 2 (internal): Predicted ensembles. Level 3 (restricted): Patient-derived sequences, pharma partner data. Level 3 requires encryption at rest with per-tenant keys.", "tags": ["security"], "pinned": True},
            {"subject": "HIPAA compliance", "predicate": "status is", "value": "BAA signed with AWS (for Backblaze gateway). Audit by Coalfire, next: August 2026. All patient sequences must be de-identified before entering the pipeline.", "tags": ["compliance"]},
            {"subject": "data retention", "predicate": "rule is", "value": "Level 1: indefinite. Level 2: 2 years then archive. Level 3: 7 years per HIPAA, then cryptographic deletion. No exceptions without legal review.", "tags": ["compliance", "constraint"], "pinned": True},
            {"subject": "access control", "predicate": "model is", "value": "RBAC with 4 roles: viewer (read results), analyst (submit jobs), admin (manage users), PI (approve budget). Each pharma partner gets an isolated namespace.", "tags": ["security"]},
            {"subject": "export restrictions", "predicate": "rule is", "value": "Predicted structures for sequences from OFAC-sanctioned countries must not be shared externally. Pipeline checks origin metadata before releasing results.", "tags": ["compliance", "constraint"]},
            {"subject": "audit logging", "predicate": "requirement is", "value": "Every data access logged to immutable append-only table. Fields: who, what, when, IP, action, resource_id. Retained 3 years. Used Loki initially but moved to dedicated audit_log table after Loki's retention proved unreliable.", "tags": ["security"]},
            {"subject": "pharma partner SLA", "predicate": "terms are", "value": "99.5% uptime for fold submissions. Results within 4 hours for sequences < 500 residues. Penalty: $2,000/hour of downtime beyond SLA. Current partners: Roche (2025-2028), Takeda (2026-2027).", "tags": ["business"]},
            {"subject": "code review policy", "predicate": "rule is", "value": "2 approvals for pipeline-core changes. 1 approval for web UI. Dr. Vasquez must approve any change to consensus scoring weights or confidence thresholds. All PRs require CI green.", "tags": ["process"], "pinned": True},
            {"subject": "deployment rule", "predicate": "constraint is", "value": "Never deploy on Fridays or during active pharma partner fold batches. Deployment window: Tuesday-Thursday 10:00-16:00 Pacific only.", "tags": ["constraint"], "pinned": True},
            {"subject": "incident response", "predicate": "plan is", "value": "SEV1 (data breach or pipeline corruption): all-hands in 15 min, notify legal within 1 hour, partner notification within 4 hours. SEV2 (single node failure): on-call responds within 30 min.", "tags": ["process"]},
        ],
    },
    {
        "id": 4,
        "description": "Research findings and benchmarks",
        "facts": [
            {"subject": "ESMFold vs AlphaFold", "predicate": "finding is", "value": "ESMFold is 14x faster but 3.2% lower GDT-TS on CASP15 targets. For ensemble generation, speed matters more -- we generate 50 candidates per target.", "tags": ["research"]},
            {"subject": "ensemble size", "predicate": "optimal is", "value": "Diminishing returns after 50 models. At 50: 94.2% GDT-TS. At 100: 94.8%. At 200: 95.0%. The 0.6% improvement from 50->100 costs 2x compute.", "tags": ["research"]},
            {"subject": "temperature scaling", "predicate": "finding is", "value": "Sampling temperature 0.7 produces optimal diversity-quality tradeoff. Below 0.5: too similar (mean pairwise RMSD < 0.3A). Above 1.0: too many garbage conformations.", "tags": ["research"]},
            {"subject": "disorder prediction", "predicate": "accuracy is", "value": "IUPred3 integration detects intrinsically disordered regions with 89.4% sensitivity and 91.2% specificity on DisProt benchmark (n=673). These regions are excluded from RMSD calculations.", "tags": ["research"]},
            {"subject": "membrane protein handling", "predicate": "finding is", "value": "Standard pipeline fails on membrane proteins (GDT-TS drops to 61.3%). Fixed by adding implicit membrane model in OpenMM with POPC lipid bilayer. Post-fix: 82.7% GDT-TS on OPM benchmark (n=156).", "tags": ["research"]},
            {"subject": "multimer prediction", "predicate": "status is", "value": "Experimental. Homodimers: 78.4% DockQ > 0.23. Heterodimers: 52.1%. Trimers: 34.7%. Not production-ready. Current workaround: predict monomers separately, dock with HDOCK.", "tags": ["research"]},
            {"subject": "runtime benchmarks", "predicate": "values are", "value": "Mean fold time: 47s for <300 residues, 3.2min for 300-1000, 18.7min for 1000-2048. P99: 2.1x mean. GPU memory: 11.3GB mean, 67.4GB peak (near OOM on A100 80GB).", "tags": ["research"]},
            {"subject": "structural alignment", "predicate": "tool is", "value": "US-align (not TM-align) for all structural comparisons. US-align handles multi-domain proteins better. TM-score threshold for 'similar': 0.5 (standard cutoff).", "tags": ["research"]},
            {"subject": "energy minimization", "predicate": "finding is", "value": "Amber ff19SB force field with OPC water model. 500 steps steepest descent + 200 steps L-BFGS. Longer minimization (>1000 steps) distorts loop regions without improving backbone.", "tags": ["research"]},
            {"subject": "batch throughput", "predicate": "current capacity is", "value": "3,847 folds/day at current cluster size. Pharma partners submit ~800/day combined. Academic queue: ~2,200/day. Buffer: ~850 folds/day for burst capacity.", "tags": ["data"]},
        ],
    },
    {
        "id": 5,
        "description": "Team, preferences, and working conventions",
        "facts": [
            {"subject": "Nexus team", "predicate": "members are", "value": "PI: Dr. Elena Vasquez (structural biology). Lead eng: Marcus Chen. ML: Priya Subramaniam, Tomasz Kowalski. DevOps: Jin-Soo Park. QA: Amara Okafor. Postdoc: Dr. Lena Johansson (membrane proteins).", "tags": ["team"]},
            {"subject": "sprint cadence", "predicate": "decided as", "value": "2-week sprints, Monday to Friday. Standup Mon/Wed/Fri 09:30 Pacific. No meetings Tuesday or Thursday (deep work days). Sprint review every other Friday.", "tags": ["process"]},
            {"subject": "documentation standard", "predicate": "rule is", "value": "All pipeline algorithms must have a methods page in /docs/methods/ with mathematical derivation, parameter justification, and validation results. Format: Jupyter notebooks converted to HTML.", "tags": ["process"]},
            {"subject": "naming convention", "predicate": "rule is", "value": "Protein families use UniProt naming (e.g., P53_HUMAN). Pipeline stages use verb-noun (e.g., fold-candidate, refine-structure). Config files: TOML only, no YAML.", "tags": ["convention"]},
            {"subject": "communication preference", "predicate": "rule is", "value": "Technical discussions on GitHub issues, not Slack. Slack is for logistics only. All architectural decisions must have an ADR in /docs/decisions/ numbered sequentially (current: ADR-034).", "tags": ["convention"], "pinned": True},
            {"subject": "output format", "predicate": "preference is", "value": "Results as PDB files with B-factor column repurposed for pLDDT scores. Ensemble summaries as TSV (not CSV). Visualization: PyMOL scripts auto-generated, not ChimeraX.", "tags": ["convention"]},
            {"subject": "version pinning", "predicate": "rule is", "value": "All ML model weights must be pinned to exact checkpoint hashes. ESMFold: checkpoint esm2_t36_3B_UR50D (hash a4b3c2d). Never use 'latest'. Reproducibility is non-negotiable.", "tags": ["constraint"], "pinned": True},
            {"subject": "GPU allocation fairness", "predicate": "policy is", "value": "Pharma partners get 60% of GPU hours (contractual). Academic jobs get 30%. Internal R&D gets 10%. If partner queue is empty, academic jobs can use partner allocation. Never the reverse.", "tags": ["constraint"], "pinned": True},
            {"subject": "error budget", "predicate": "policy is", "value": "Monthly error budget: 0.5% (99.5% uptime). If budget is exhausted, all non-critical deployments freeze until next month. Currently at 0.12% used this month.", "tags": ["constraint"]},
            {"subject": "data labeling", "predicate": "guideline is", "value": "All training labels must be from experimentally resolved structures (X-ray < 2.5A or cryo-EM < 3.5A). No predicted structures as ground truth. This rule exists because v0.3 trained on AlphaFold predictions and learned to mimic its biases.", "tags": ["constraint"]},
        ],
    },
]

# Flatten all facts
ALL_FACTS = []
for session in SESSIONS:
    for f in session["facts"]:
        f["session_id"] = session["id"]
        f["session_desc"] = session["description"]
        ALL_FACTS.append(f)

# --- Test Questions (25 questions across 3 categories) ---

QUESTIONS = [
    # === Fact Retention (10 questions) ===
    {"id": 1, "category": "fact_retention", "session_ref": 1,
     "question": "What database does Nexus use and how many nodes?",
     "expected_keywords": ["scylladb", "5.4", "5 nodes"],
     "min_keywords": 2},
    {"id": 2, "category": "fact_retention", "session_ref": 2,
     "question": "What is the pLDDT confidence threshold for ensemble inclusion?",
     "expected_keywords": ["72.5"],
     "min_keywords": 1},
    {"id": 3, "category": "fact_retention", "session_ref": 2,
     "question": "What are the consensus scoring formula weights?",
     "expected_keywords": ["0.40", "0.25", "0.20", "0.15"],
     "min_keywords": 3},
    {"id": 4, "category": "fact_retention", "session_ref": 4,
     "question": "What is the optimal ensemble size and the GDT-TS at that size?",
     "expected_keywords": ["50", "94.2"],
     "min_keywords": 2},
    {"id": 5, "category": "fact_retention", "session_ref": 4,
     "question": "What is the mean fold time for proteins under 300 residues?",
     "expected_keywords": ["47s", "47"],
     "min_keywords": 1},
    {"id": 6, "category": "fact_retention", "session_ref": 2,
     "question": "What caused the memory leak in the pipeline and what's the workaround?",
     "expected_keywords": ["openmm", "340mb", "context", "subprocess", "4gb"],
     "min_keywords": 3},
    {"id": 7, "category": "fact_retention", "session_ref": 1,
     "question": "What is the monthly GPU compute budget cap?",
     "expected_keywords": ["47,000", "47000"],
     "min_keywords": 1},
    {"id": 8, "category": "fact_retention", "session_ref": 3,
     "question": "Which pharma partners does Nexus have and what are the contract dates?",
     "expected_keywords": ["roche", "takeda", "2025", "2028"],
     "min_keywords": 3},
    {"id": 9, "category": "fact_retention", "session_ref": 4,
     "question": "What is the current daily fold throughput capacity?",
     "expected_keywords": ["3,847", "3847"],
     "min_keywords": 1},
    {"id": 10, "category": "fact_retention", "session_ref": 5,
     "question": "Who is the PI and what are the deep work days?",
     "expected_keywords": ["vasquez", "tuesday", "thursday"],
     "min_keywords": 2},

    # === Decision Recall (8 questions -- must explain WHY) ===
    {"id": 11, "category": "decision_recall", "session_ref": 1,
     "question": "Why did Nexus choose ScyllaDB over Cassandra?",
     "expected_keywords": ["tail latency", "ensemble"],
     "min_keywords": 2},
    {"id": 12, "category": "decision_recall", "session_ref": 2,
     "question": "Why does Nexus use ESMFold instead of AlphaFold for production?",
     "expected_keywords": ["14x", "faster", "speed", "50 candidates"],
     "min_keywords": 2},
    {"id": 13, "category": "decision_recall", "session_ref": 4,
     "question": "Why was the implicit membrane model added to the pipeline?",
     "expected_keywords": ["membrane", "61.3", "82.7", "fails"],
     "min_keywords": 2},
    {"id": 14, "category": "decision_recall", "session_ref": 5,
     "question": "Why must all training labels come from experimental structures only?",
     "expected_keywords": ["v0.3", "alphafold", "biases", "predicted"],
     "min_keywords": 2},
    {"id": 15, "category": "decision_recall", "session_ref": 3,
     "question": "Why did audit logging move from Loki to a dedicated table?",
     "expected_keywords": ["loki", "retention", "unreliable"],
     "min_keywords": 2},
    {"id": 16, "category": "decision_recall", "session_ref": 2,
     "question": "Why was the disulfide bond handling rule established?",
     "expected_keywords": ["february", "2026", "retraction", "cysteine"],
     "min_keywords": 2},
    {"id": 17, "category": "decision_recall", "session_ref": 4,
     "question": "Why does Nexus use US-align instead of TM-align?",
     "expected_keywords": ["multi-domain", "us-align"],
     "min_keywords": 2},
    {"id": 18, "category": "decision_recall", "session_ref": 2,
     "question": "How was GPU utilization improved from 34% to 78%?",
     "expected_keywords": ["batch", "sequence length", "10%", "bins", "padding"],
     "min_keywords": 2},

    # === Constraint Preservation (7 questions -- must enforce the rule) ===
    {"id": 19, "category": "constraint", "session_ref": 3,
     "question": "I want to deploy this pipeline fix right now. It's Friday afternoon but it's critical.",
     "expected_keywords": ["no", "friday", "tuesday", "thursday", "window", "10:00", "16:00"],
     "min_keywords": 2},
    {"id": 20, "category": "constraint", "session_ref": 5,
     "question": "Let's use the latest ESMFold checkpoint for better accuracy.",
     "expected_keywords": ["no", "pinned", "exact", "hash", "a4b3c2d", "reproducibility", "never"],
     "min_keywords": 2},
    {"id": 21, "category": "constraint", "session_ref": 5,
     "question": "The academic queue is backed up. Let's borrow some GPU hours from the pharma partner allocation since their queue is light.",
     "expected_keywords": ["no", "never", "reverse", "60%", "contractual"],
     "min_keywords": 2},
    {"id": 22, "category": "constraint", "session_ref": 1,
     "question": "I want to run a new experiment that will cost $4,500/month in GPU time.",
     "expected_keywords": ["47,000", "47000", "vasquez", "pi", "approval", "3,000", "3000"],
     "min_keywords": 2},
    {"id": 23, "category": "constraint", "session_ref": 2,
     "question": "This protein is 2,500 residues. Can I just run it through the pipeline as-is?",
     "expected_keywords": ["no", "2,048", "2048", "split", "domain", "interpro", "oom"],
     "min_keywords": 2},
    {"id": 24, "category": "constraint", "session_ref": 3,
     "question": "I want to update the consensus scoring weights based on my analysis. I'll get one team member to approve.",
     "expected_keywords": ["no", "2", "two", "vasquez", "approval", "approve"],
     "min_keywords": 2},
    {"id": 25, "category": "constraint", "session_ref": 5,
     "question": "I trained the new model version using AlphaFold-predicted structures as ground truth labels since they're higher quality than some old X-ray structures.",
     "expected_keywords": ["no", "experimental", "predicted", "v0.3", "biases", "x-ray", "cryo"],
     "min_keywords": 2},
]


# --- Context Builders ---

def build_no_memory_prompt() -> str:
    """Baseline: no memory from previous sessions."""
    return (
        "You are an AI assistant working on Nexus, a distributed bioinformatics "
        "pipeline for protein folding ensemble analysis. "
        "This is a new session. You have no memory of previous conversations. "
        "Answer questions honestly. If you don't know something, say so."
    )


def build_md_memory_prompt() -> str:
    """Simulate Claude Code's MEMORY.md approach: a condensed summary file."""
    # Deliberately lossy -- like real compaction. Keeps structure but drops numbers.
    lines = [
        "# Project Memory -- Nexus",
        "",
        "## Architecture",
        "- Database: ScyllaDB cluster, multi-node",
        "- Auth: mTLS with SPIFFE IDs via Vault",
        "- Compute: Ray cluster with A100 GPUs",
        "- Message queue: Apache Pulsar with multiple topics",
        "- API: GraphQL (Apollo Server) with REST fallback",
        "- Storage: tiered hot/warm/cold",
        "- Deployment: Nomad on bare metal at SDSC",
        "",
        "## Pipeline",
        "- Four-stage: candidate generation -> refinement -> clustering -> consensus",
        "- ESMFold for production, AlphaFold for validation only",
        "- HDBSCAN clustering with precomputed distance matrix",
        "- Consensus scoring based on pLDDT, cluster density, structural agreement, energy",
        "",
        "## Compliance",
        "- HIPAA compliant, BAA with AWS",
        "- Three-level data classification",
        "- Pharma partner SLAs with uptime requirements",
        "- RBAC with viewer/analyst/admin/PI roles",
        "",
        "## Research",
        "- Ensemble size optimization done",
        "- Membrane protein handling improved with implicit membrane model",
        "- Multimer prediction experimental, not production-ready",
        "",
        "## Team & Process",
        "- PI: Dr. Vasquez. 2-week sprints, deep work days",
        "- ADRs for architectural decisions",
        "- PDB format output with pLDDT in B-factor column",
        "- Version pinning for ML model weights",
    ]
    memory_text = "\n".join(lines)

    return (
        "You are an AI assistant working on Nexus, a distributed bioinformatics "
        "pipeline for protein folding ensemble analysis. "
        "You have a memory file from previous sessions:\n\n"
        f"```\n{memory_text}\n```\n\n"
        "Use this memory to answer questions. If details aren't in the memory, "
        "say you don't recall the specifics."
    )


def build_ko_memory_prompt() -> str:
    """Simulate CoreTx Connect: structured KOs with full detail."""
    ko_lines = ["# Session Context (from CoreTx Connect)\n"]

    # Pinned items first
    pinned = [f for f in ALL_FACTS if f.get("pinned")]
    if pinned:
        ko_lines.append(f"## Pinned ({len(pinned)} critical)\n")
        for f in pinned:
            ko_lines.append(f"- **{f['subject']}** ({f['predicate']}): {f['value']}")
        ko_lines.append("")

    # Recent session
    ko_lines.append(f"## Recent (session 5: {SESSIONS[4]['description']})\n")
    for f in SESSIONS[4]["facts"]:
        if not f.get("pinned"):
            ko_lines.append(f"- **{f['subject']}** ({f['predicate']}): {f['value']}")
    ko_lines.append("")

    # Semantic (everything else not pinned, not session 5)
    ko_lines.append("## Semantic\n")
    for session in SESSIONS[:4]:
        for f in session["facts"]:
            if not f.get("pinned"):
                ko_lines.append(f"- **{f['subject']}** ({f['predicate']}): {f['value']}")
    ko_lines.append("")

    ko_lines.append(f"---\n{len(ALL_FACTS)} KOs loaded.")
    ko_text = "\n".join(ko_lines)

    return (
        "You are an AI assistant working on Nexus, a distributed bioinformatics "
        "pipeline for protein folding ensemble analysis. "
        "You have persistent knowledge from previous sessions via CoreTx Connect:\n\n"
        f"{ko_text}\n\n"
        "Use this knowledge to answer questions accurately. "
        "If a question involves a constraint or rule, enforce it firmly."
    )


# --- Claude API Client ---

def call_claude(system_prompt: str, user_message: str) -> str:
    if not ANTHROPIC_API_KEY:
        return "[ERROR: ANTHROPIC_API_KEY not set]"
    body = json.dumps({
        "model": MODEL,
        "max_tokens": 500,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_message}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode())
            return result["content"][0]["text"]
    except urllib.error.HTTPError as e:
        body_text = e.read().decode() if e.fp else ""
        return f"[API ERROR {e.code}: {body_text[:200]}]"
    except Exception as e:
        return f"[ERROR: {e}]"


# --- Scoring ---

def score_answer(answer: str, question: dict) -> dict:
    answer_lower = answer.lower()
    found = [kw for kw in question["expected_keywords"] if kw.lower() in answer_lower]
    missed = [kw for kw in question["expected_keywords"] if kw.lower() not in answer_lower]
    passed = len(found) >= question["min_keywords"]
    return {
        "question_id": question["id"],
        "category": question["category"],
        "passed": passed,
        "keywords_found": found,
        "keywords_missed": missed,
        "hit_count": len(found),
        "min_needed": question["min_keywords"],
        "score": min(len(found) / max(len(question["expected_keywords"]), 1), 1.0),
    }


# --- Run Benchmark ---

@dataclass
class BenchmarkRun:
    condition: str
    seed: int
    results: list = field(default_factory=list)
    total_questions: int = 0
    passed: int = 0
    accuracy: float = 0.0
    by_category: dict = field(default_factory=dict)
    duration_s: float = 0.0


def run_condition(condition: str, seed: int = 42) -> BenchmarkRun:
    prompt_builders = {
        "none": build_no_memory_prompt,
        "md": build_md_memory_prompt,
        "ko": build_ko_memory_prompt,
    }

    if condition not in prompt_builders:
        print(f"Unknown condition: {condition}")
        sys.exit(1)

    system_prompt = prompt_builders[condition]()
    run = BenchmarkRun(condition=condition, seed=seed)
    start = time.time()

    print(f"\n{'='*60}")
    print(f"Condition: {condition.upper()} (seed {seed})")
    print(f"{'='*60}")

    for q in QUESTIONS:
        answer = call_claude(system_prompt, q["question"])
        result = score_answer(answer, q)
        result["answer"] = answer
        run.results.append(result)
        status = "PASS" if result["passed"] else "FAIL"
        print(f"  [{status}] Q{q['id']:2d} ({q['category']:20s}): {result['hit_count']}/{len(q['expected_keywords'])} keywords")
        time.sleep(4.0)  # ~15 req/min to stay under 30K tok/min rate limit

    run.duration_s = time.time() - start
    run.total_questions = len(QUESTIONS)
    run.passed = sum(1 for r in run.results if r["passed"])
    run.accuracy = run.passed / run.total_questions if run.total_questions > 0 else 0

    # Category breakdown
    cats = {}
    for r in run.results:
        cat = r["category"]
        if cat not in cats:
            cats[cat] = {"total": 0, "passed": 0}
        cats[cat]["total"] += 1
        if r["passed"]:
            cats[cat]["passed"] += 1
    for cat, data in cats.items():
        data["accuracy"] = data["passed"] / data["total"] if data["total"] > 0 else 0
    run.by_category = cats

    return run


def print_summary(runs: list[BenchmarkRun]):
    print(f"\n{'='*60}")
    print("RESULTS SUMMARY")
    print(f"{'='*60}\n")

    print(f"{'Condition':<12} {'Accuracy':>10} {'Passed':>8} {'Time':>8}")
    print("-" * 42)
    for run in runs:
        print(f"{run.condition:<12} {run.accuracy:>9.1%} {run.passed:>5}/{run.total_questions:<3} {run.duration_s:>6.1f}s")

    categories = ["fact_retention", "decision_recall", "constraint"]
    print(f"\n{'Category':<22}", end="")
    for run in runs:
        print(f" {run.condition:>10}", end="")
    print()
    print("-" * (22 + 11 * len(runs)))
    for cat in categories:
        print(f"{cat:<22}", end="")
        for run in runs:
            data = run.by_category.get(cat, {})
            acc = data.get("accuracy", 0)
            print(f" {acc:>9.0%}", end="")
        print()

    if len(runs) >= 2:
        best = max(runs, key=lambda r: r.accuracy)
        worst = min(runs, key=lambda r: r.accuracy)
        delta = best.accuracy - worst.accuracy
        print(f"\nKey finding: {best.condition.upper()} outperforms {worst.condition.upper()} by {delta:.0%} overall accuracy")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="CoreTx Connect Benchmark")
    parser.add_argument("--condition", choices=["none", "md", "ko", "all"], default="all")
    parser.add_argument("--seeds", type=int, default=1)
    parser.add_argument("--output", type=str, default="benchmark_results.json")
    args = parser.parse_args()

    if not ANTHROPIC_API_KEY:
        print("ERROR: ANTHROPIC_API_KEY not set.")
        sys.exit(1)

    conditions = ["none", "md", "ko"] if args.condition == "all" else [args.condition]

    print(f"CoreTx Connect Benchmark")
    print(f"Model: {MODEL}")
    print(f"Domain: Nexus (fictional bioinformatics pipeline -- zero prior knowledge)")
    print(f"Facts: {len(ALL_FACTS)}, Questions: {len(QUESTIONS)}")
    print(f"Seeds: {args.seeds}")

    all_runs = []
    for seed_idx in range(args.seeds):
        seed = [42, 123, 456, 789, 1337][seed_idx % 5]
        for cond in conditions:
            run = run_condition(cond, seed=seed)
            all_runs.append(run)
            print(f"\n  -> {cond.upper()}: {run.accuracy:.0%} ({run.passed}/{run.total_questions})")

    # Group by condition
    by_condition: dict[str, list[BenchmarkRun]] = {}
    for run in all_runs:
        by_condition.setdefault(run.condition, []).append(run)

    # Per-seed summaries
    for seed_idx in range(args.seeds):
        seed = [42, 123, 456, 789, 1337][seed_idx % 5]
        seed_runs = [r for r in all_runs if r.seed == seed]
        if len(seed_runs) > 1:
            print_summary(seed_runs)

    # Multi-seed aggregate
    if args.seeds > 1:
        print(f"\n{'='*60}")
        print(f"AGGREGATE ({args.seeds} seeds)")
        print(f"{'='*60}\n")
        print(f"{'Condition':<12} {'Mean Acc':>10} {'Std':>8} {'Min':>8} {'Max':>8}")
        print("-" * 50)
        for cond in conditions:
            runs = by_condition[cond]
            accs = [r.accuracy for r in runs]
            mean_acc = sum(accs) / len(accs)
            std_acc = (sum((a - mean_acc) ** 2 for a in accs) / len(accs)) ** 0.5
            print(f"{cond:<12} {mean_acc:>9.1%} {std_acc:>7.1%} {min(accs):>7.1%} {max(accs):>7.1%}")

    # Save results
    output = {
        "model": MODEL,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "test": "main_benchmark",
        "domain": "Nexus (fictional bioinformatics pipeline)",
        "seeds": args.seeds,
        "questions": len(QUESTIONS),
        "facts": len(ALL_FACTS),
        "runs": [],
    }
    for run in all_runs:
        output["runs"].append({
            "condition": run.condition,
            "seed": run.seed,
            "accuracy": run.accuracy,
            "passed": run.passed,
            "total": run.total_questions,
            "by_category": run.by_category,
            "duration_s": run.duration_s,
            "results": run.results,
        })

    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nResults saved to {args.output}")


if __name__ == "__main__":
    main()
