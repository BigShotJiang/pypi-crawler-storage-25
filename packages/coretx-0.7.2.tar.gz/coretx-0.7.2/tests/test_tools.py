"""Unit tests for coretx tool functions.

Tests mock the HTTP layer (_do_request) so we validate response parsing
without hitting the real API. This catches key mismatches like "kos" vs
"results" that caused ko_list to silently return empty.
"""

from __future__ import annotations

import json
import unittest
from unittest.mock import patch

# Import the module so we can patch its internals
from coretx import server


def _patch_get(return_value: dict):
    """Patch _api_get to return a fixed dict."""
    return patch.object(server, "_api_get", return_value=return_value)


def _patch_post(return_value: dict):
    """Patch _api_post to return a fixed dict."""
    return patch.object(server, "_api_post", return_value=return_value)


def _patch_delete(return_value: dict):
    """Patch _api_delete to return a fixed dict."""
    return patch.object(server, "_api_delete", return_value=return_value)


SAMPLE_KO = {
    "subject": "database",
    "predicate": "decided as",
    "object_value": "PostgreSQL on Supabase",
    "ko_type": "insight",
    "hash": "abc123",
}

SAMPLE_KO_2 = {
    "subject": "auth",
    "predicate": "architecture is",
    "object_value": "HMAC-signed HttpOnly cookies",
    "ko_type": "insight",
    "hash": "def456",
}


class TestKoList(unittest.TestCase):
    """ko_list must handle both 'kos' and 'results' response keys."""

    def test_reads_kos_key(self):
        """API returns data under 'kos' (current production behavior)."""
        with _patch_get({"kos": [SAMPLE_KO], "source": "supabase"}):
            result = server.ko_list({})
        self.assertIn("1 KOs", result)
        self.assertIn("database", result)

    def test_reads_results_key_fallback(self):
        """Falls back to 'results' if 'kos' is absent."""
        with _patch_get({"results": [SAMPLE_KO]}):
            result = server.ko_list({})
        self.assertIn("1 KOs", result)
        self.assertIn("database", result)

    def test_empty_kos(self):
        with _patch_get({"kos": []}):
            result = server.ko_list({})
        self.assertEqual(result, "No KOs stored yet.")

    def test_empty_response(self):
        with _patch_get({}):
            result = server.ko_list({})
        self.assertEqual(result, "No KOs stored yet.")

    def test_error_response(self):
        with _patch_get({"error": "Unauthorized"}):
            result = server.ko_list({})
        self.assertIn("List failed", result)

    def test_truncates_at_20(self):
        kos = [{**SAMPLE_KO, "subject": f"item-{i}"} for i in range(25)]
        with _patch_get({"kos": kos}):
            result = server.ko_list({})
        self.assertIn("25 KOs", result)
        self.assertIn("... and 5 more", result)
        self.assertNotIn("item-24", result)

    def test_passes_limit_and_project(self):
        with patch.object(server, "_api_get", return_value={"kos": []}) as mock:
            server.ko_list({"limit": 10, "project": "nanopub"})
            mock.assert_called_once_with("list", {"limit": 10, "project": "nanopub"})


class TestKoSearch(unittest.TestCase):
    """ko_search reads from 'results' key (search endpoint behavior)."""

    def test_reads_results_key(self):
        with _patch_get({"results": [SAMPLE_KO], "count": 1}):
            result = server.ko_search({"query": "database"})
        self.assertIn("database", result)

    def test_empty_results(self):
        with _patch_get({"results": []}):
            result = server.ko_search({"query": "nonexistent"})
        self.assertEqual(result, "No results found.")

    def test_error_response(self):
        with _patch_get({"error": "Bad request"}):
            result = server.ko_search({"query": "test"})
        self.assertIn("Search failed", result)

    def test_shows_visibility_for_public_kos(self):
        public_ko = {**SAMPLE_KO, "visibility": "public"}
        with _patch_get({"results": [public_ko], "count": 1}):
            result = server.ko_search({"query": "database"})
        self.assertIn("[public]", result)

    def test_shows_visibility_for_network_kos(self):
        network_ko = {**SAMPLE_KO, "visibility": "network"}
        with _patch_get({"results": [network_ko], "count": 1}):
            result = server.ko_search({"query": "database"})
        self.assertIn("[network]", result)

    def test_hides_visibility_for_private_kos(self):
        private_ko = {**SAMPLE_KO, "visibility": "private"}
        with _patch_get({"results": [private_ko], "count": 1}):
            result = server.ko_search({"query": "database"})
        self.assertNotIn("[private]", result)
        self.assertNotIn("[]", result)


class TestKoListVisibility(unittest.TestCase):
    """ko_list includes visibility tags for non-private KOs."""

    def test_shows_visibility_for_public_kos(self):
        public_ko = {**SAMPLE_KO, "visibility": "public"}
        with _patch_get({"kos": [public_ko]}):
            result = server.ko_list({})
        self.assertIn("[public]", result)

    def test_hides_visibility_for_private_kos(self):
        private_ko = {**SAMPLE_KO, "visibility": "private"}
        with _patch_get({"kos": [private_ko]}):
            result = server.ko_list({})
        self.assertNotIn("[private]", result)


class TestKoShare(unittest.TestCase):
    """ko_share uses list action internally, must handle 'kos' key."""

    def test_reads_kos_key_from_list(self):
        with patch.object(server, "_api_get", return_value={"kos": [SAMPLE_KO]}) as mock_get, \
             _patch_post({"shared": 1}):
            result = server.ko_share({"recipient": "user@example.com"})
        # Should have called list action
        mock_get.assert_called_once()
        self.assertNotIn("No KOs to share", result)

    def test_empty_list_returns_no_kos(self):
        with _patch_get({"kos": []}):
            result = server.ko_share({"recipient": "user@example.com"})
        self.assertEqual(result, "No KOs to share.")

    def test_explicit_hashes_skips_list(self):
        with _patch_post({"shared": 1}):
            result = server.ko_share({
                "recipient": "user@example.com",
                "ko_hashes": ["abc123"],
            })
        self.assertNotIn("No KOs to share", result)


class TestKoStats(unittest.TestCase):
    def test_parses_stats(self):
        with _patch_get({
            "total_kos": 42,
            "pinned": 5,
            "semantic": 10,
            "projects": {"nanopub": 30, "other": 12},
        }):
            result = server.ko_stats({})
        self.assertIn("Total KOs: 42", result)
        self.assertIn("Pinned: 5", result)
        self.assertIn("Semantic (long-term): 10", result)
        self.assertIn("nanopub", result)

    def test_error_response(self):
        with _patch_get({"error": "timeout"}):
            result = server.ko_stats({})
        self.assertIn("Stats failed", result)

    def test_zero_stats(self):
        with _patch_get({"total_kos": 0, "pinned": 0, "semantic": 0, "projects": {}}):
            result = server.ko_stats({})
        self.assertIn("Total KOs: 0", result)
        self.assertIn("Projects: none", result)


class TestKoContext(unittest.TestCase):
    def test_returns_context_string(self):
        with _patch_get({"context": "Previous session: decided on PostgreSQL"}):
            result = server.ko_context({})
        self.assertIn("decided on PostgreSQL", result)
        self.assertIn("Memory loaded", result)

    def test_no_context_available(self):
        with _patch_get({}):
            result = server.ko_context({})
        self.assertIn("No context available", result)

    def test_error_response(self):
        with _patch_get({"error": "Unauthorized"}):
            result = server.ko_context({})
        self.assertIn("Context failed", result)


class TestKoWrite(unittest.TestCase):
    def setUp(self):
        # Reset global state
        server._is_first_ko = None
        server._session_kos_written.clear()

    def test_successful_write(self):
        with patch.object(server, "_api_get", return_value={"total_kos": 5}), \
             _patch_post({"id": "abc123"}):
            result = server.ko_write({
                "subject": "database",
                "predicate": "decided as",
                "object_value": "PostgreSQL",
            })
        self.assertIn("Stored: database", result)
        self.assertEqual(len(server._session_kos_written), 1)

    def test_write_error(self):
        with patch.object(server, "_api_get", return_value={"total_kos": 5}), \
             _patch_post({"error": "Validation failed"}):
            result = server.ko_write({
                "subject": "test",
                "predicate": "is",
                "object_value": "broken",
            })
        self.assertIn("Write failed", result)

    def test_first_ko_celebration(self):
        with patch.object(server, "_api_get", return_value={"total_kos": 0}), \
             _patch_post({"id": "first"}):
            result = server.ko_write({
                "subject": "hello",
                "predicate": "is",
                "object_value": "world",
            })
        self.assertIn("first knowledge object", result)
        self.assertIn("knowledge graph", result)


class TestProjectInference(unittest.TestCase):
    """Smart project inference from context."""

    def setUp(self):
        self._orig_context = server._context.copy()

    def tearDown(self):
        server._context.update(self._orig_context)

    def test_infer_from_explicit_project(self):
        server._context["project"] = "nanopub"
        server._context["cwd"] = ""
        self.assertEqual(server._infer_project(), "nanopub")

    def test_infer_from_cwd(self):
        server._context["project"] = ""
        server._context["cwd"] = "/Users/anthony/Code/coretx/nanopub"
        self.assertEqual(server._infer_project(), "nanopub")

    def test_explicit_project_overrides_cwd(self):
        server._context["project"] = "coretx"
        server._context["cwd"] = "/Users/anthony/Code/other/project"
        self.assertEqual(server._infer_project(), "coretx")

    def test_empty_context_returns_empty(self):
        server._context["project"] = ""
        server._context["cwd"] = ""
        self.assertEqual(server._infer_project(), "")

    def test_ko_write_uses_inferred_project(self):
        server._context["project"] = ""
        server._context["cwd"] = "/Users/anthony/Code/coretx/nanopub"
        server._is_first_ko = False
        with _patch_post({"id": "abc123"}) as mock_post:
            server.ko_write({
                "subject": "test",
                "predicate": "is",
                "object_value": "inferred",
            })
            body = mock_post.call_args[0][0]
            self.assertEqual(body["project"], "nanopub")

    def test_ko_write_explicit_project_wins(self):
        server._context["cwd"] = "/Users/anthony/Code/coretx/nanopub"
        server._is_first_ko = False
        with _patch_post({"id": "abc123"}) as mock_post:
            server.ko_write({
                "subject": "test",
                "predicate": "is",
                "object_value": "explicit",
                "project": "custom-project",
            })
            body = mock_post.call_args[0][0]
            self.assertEqual(body["project"], "custom-project")


class TestKoRead(unittest.TestCase):
    def test_successful_read(self):
        with _patch_get(SAMPLE_KO):
            result = server.ko_read({
                "subject": "database",
                "predicate": "decided as",
            })
        parsed = json.loads(result)
        self.assertEqual(parsed["subject"], "database")

    def test_not_found(self):
        with _patch_get({"error": "Not found"}):
            result = server.ko_read({
                "subject": "nonexistent",
                "predicate": "is",
            })
        self.assertIn("Not found", result)


class TestKoDelete(unittest.TestCase):
    def test_successful_delete(self):
        with _patch_delete({"deleted": True}):
            result = server.ko_delete({
                "subject": "old",
                "predicate": "is",
            })
        self.assertIn("Deleted: old", result)

    def test_delete_error(self):
        with _patch_delete({"error": "Not found"}):
            result = server.ko_delete({
                "subject": "nonexistent",
                "predicate": "is",
            })
        self.assertIn("Delete failed", result)


if __name__ == "__main__":
    unittest.main()
