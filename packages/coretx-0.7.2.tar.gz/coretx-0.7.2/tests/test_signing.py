"""Tests for Ed25519 cryptographic signing."""

import base64
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from coretx.signing import (
    canonicalize_ko,
    get_public_key_b64,
    load_or_create_key,
    sign_ko,
    verify_signature,
)


class TestCanonicalization(unittest.TestCase):
    """Canonicalization must produce identical output to the TypeScript implementation."""

    def test_basic_ko(self):
        result = canonicalize_ko("database", "PostgreSQL on Supabase", "insight", "2026-01-01T00:00:00.000Z")
        expected = '{"content":"PostgreSQL on Supabase","ko_type":"insight","subject":"database","timestamp":"2026-01-01T00:00:00.000Z","visibility":"private"}'
        self.assertEqual(result, expected)

    def test_sorted_keys(self):
        """Keys must be alphabetical: content < ko_type < subject < timestamp."""
        result = canonicalize_ko("z-subject", "a-content", "method", "2026-01-01T00:00:00.000Z")
        parsed = json.loads(result)
        keys = list(parsed.keys())
        self.assertEqual(keys, sorted(keys))

    def test_empty_fields_default(self):
        result = canonicalize_ko("", "", "", "2024-01-01T00:00:00.000Z")
        expected = '{"content":"","ko_type":"insight","subject":"","timestamp":"2024-01-01T00:00:00.000Z","visibility":"private"}'
        self.assertEqual(result, expected)

    def test_ko_type_defaults_to_insight(self):
        result = canonicalize_ko("test", "test", "", "2024-01-01T00:00:00.000Z")
        self.assertIn('"ko_type":"insight"', result)

    def test_unicode_matches_js(self):
        """JS JSON.stringify preserves unicode; Python must too (ensure_ascii=False)."""
        result = canonicalize_ko("Schrödinger", "ψ function collapse", "hypothesis", "2024-06-15T12:00:00.000Z")
        expected = '{"content":"ψ function collapse","ko_type":"hypothesis","subject":"Schrödinger","timestamp":"2024-06-15T12:00:00.000Z","visibility":"private"}'
        self.assertEqual(result, expected)

    def test_compact_separators(self):
        """No whitespace after : or , — matches JSON.stringify default."""
        result = canonicalize_ko("a", "b", "c", "t")
        self.assertNotIn(": ", result)
        self.assertNotIn(", ", result)

    def test_json_special_chars(self):
        """Quotes and backslashes must be escaped consistently."""
        result = canonicalize_ko('say "hello"', "path\\to\\file", "insight", "t")
        parsed = json.loads(result)
        self.assertEqual(parsed["subject"], 'say "hello"')
        self.assertEqual(parsed["content"], "path\\to\\file")

    # ─── Cross-platform test vectors (shared with TypeScript) ──

    def test_cross_platform_vector_1(self):
        """SPO-style KO — must match signing.test.ts output."""
        result = canonicalize_ko(
            "Quantum entanglement",
            "Non-local correlations persist",
            "hypothesis",
            "2024-01-15T10:30:00.000Z",
        )
        expected = '{"content":"Non-local correlations persist","ko_type":"hypothesis","subject":"Quantum entanglement","timestamp":"2024-01-15T10:30:00.000Z","visibility":"private"}'
        self.assertEqual(result, expected)


class TestKeyManagement(unittest.TestCase):

    def test_create_new_key(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "signing.key"
            key = load_or_create_key(path)
            self.assertTrue(path.exists())
            # Check file permissions (Unix only)
            if os.name != "nt":
                self.assertEqual(oct(path.stat().st_mode & 0o777), oct(0o600))

    def test_load_existing_key(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "signing.key"
            key1 = load_or_create_key(path)
            key2 = load_or_create_key(path)
            # Same key loaded both times
            pub1 = get_public_key_b64(key1)
            pub2 = get_public_key_b64(key2)
            self.assertEqual(pub1, pub2)

    def test_public_key_is_32_bytes_base64(self):
        with tempfile.TemporaryDirectory() as td:
            key = load_or_create_key(Path(td) / "signing.key")
            pub = get_public_key_b64(key)
            pub_bytes = base64.b64decode(pub)
            self.assertEqual(len(pub_bytes), 32)

    def test_unique_keys(self):
        with tempfile.TemporaryDirectory() as td:
            key1 = load_or_create_key(Path(td) / "key1.key")
            key2 = load_or_create_key(Path(td) / "key2.key")
            self.assertNotEqual(get_public_key_b64(key1), get_public_key_b64(key2))


class TestSignVerify(unittest.TestCase):

    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.key = load_or_create_key(Path(self._td.name) / "signing.key")
        self.pub = get_public_key_b64(self.key)

    def tearDown(self):
        self._td.cleanup()

    def test_sign_verify_roundtrip(self):
        canonical = canonicalize_ko("test", "value", "insight", "2026-01-01T00:00:00.000Z")
        sig = sign_ko(self.key, canonical)
        self.assertTrue(verify_signature(self.pub, sig, canonical))

    def test_signature_is_64_bytes_base64(self):
        canonical = canonicalize_ko("test", "value", "insight", "2026-01-01T00:00:00.000Z")
        sig = sign_ko(self.key, canonical)
        sig_bytes = base64.b64decode(sig)
        self.assertEqual(len(sig_bytes), 64)

    def test_tampered_content_fails(self):
        canonical = canonicalize_ko("test", "value", "insight", "2026-01-01T00:00:00.000Z")
        sig = sign_ko(self.key, canonical)
        tampered = canonicalize_ko("test", "CHANGED", "insight", "2026-01-01T00:00:00.000Z")
        self.assertFalse(verify_signature(self.pub, sig, tampered))

    def test_tampered_timestamp_fails(self):
        canonical = canonicalize_ko("test", "value", "insight", "2026-01-01T00:00:00.000Z")
        sig = sign_ko(self.key, canonical)
        tampered = canonicalize_ko("test", "value", "insight", "2099-01-01T00:00:00.000Z")
        self.assertFalse(verify_signature(self.pub, sig, tampered))

    def test_wrong_key_fails(self):
        with tempfile.TemporaryDirectory() as td:
            other_key = load_or_create_key(Path(td) / "other.key")
            other_pub = get_public_key_b64(other_key)
        canonical = canonicalize_ko("test", "value", "insight", "2026-01-01T00:00:00.000Z")
        sig = sign_ko(self.key, canonical)
        self.assertFalse(verify_signature(other_pub, sig, canonical))

    def test_garbage_input_returns_false(self):
        self.assertFalse(verify_signature("not-valid", "not-valid", "not-valid"))

    def test_empty_signature_returns_false(self):
        self.assertFalse(verify_signature(self.pub, "", "content"))


class TestKoWriteIntegration(unittest.TestCase):
    """Verify that ko_write sends signature fields to the API."""

    @patch("coretx.server._api_get", return_value={"total_kos": 5})
    @patch("coretx.server._api_post")
    @patch("coretx.server._register_signing_key", return_value=True)
    def test_ko_write_includes_signature(self, mock_reg, mock_post, mock_get):
        mock_post.return_value = {"id": "abc123"}

        from coretx import server
        # Ensure signing key is set
        if server._signing_key is None:
            self.skipTest("Signing key not available")

        result = server.ko_write({
            "subject": "test",
            "predicate": "is",
            "object_value": "signed",
        })

        # Verify the POST body includes signature fields
        call_args = mock_post.call_args[0][0]
        self.assertIn("signature", call_args)
        self.assertIn("signer_public_key", call_args)
        self.assertIn("timestamp", call_args)
        self.assertTrue(len(call_args["signature"]) > 0)
        self.assertTrue(len(call_args["signer_public_key"]) > 0)


if __name__ == "__main__":
    unittest.main()
