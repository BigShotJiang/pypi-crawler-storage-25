from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .api import DottieClient
from .auth import current_employee_id


FOLLOW_UP_INDEX = 0
LEADER_FEEDBACK_INDEX = 16


def _parse_dt(value: str | None) -> datetime:
    if not value:
        return datetime.min
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _find_employee(employees: list[dict[str, Any]], needle: str) -> dict[str, Any]:
    lowered = needle.strip().lower()
    if not lowered:
        raise ValueError("Employee query cannot be empty.")

    exact = [employee for employee in employees if str(employee.get("name", "")).lower() == lowered]
    if len(exact) == 1:
        return exact[0]

    partial = [employee for employee in employees if lowered in str(employee.get("name", "")).lower()]
    if len(partial) == 1:
        return partial[0]
    if not partial:
        raise ValueError(f"No employee matched {needle!r}.")
    names = ", ".join(str(item.get("name", "?")) for item in partial[:8])
    raise ValueError(f"Employee query {needle!r} is ambiguous: {names}")


@dataclass
class SyncPreview:
    employee: dict[str, Any]
    current_meeting: dict[str, Any]
    previous_meeting: dict[str, Any]
    patches: list[dict[str, Any]]


@dataclass
class AnswerPreview:
    employee: dict[str, Any]
    current_meeting: dict[str, Any]
    patches: list[dict[str, Any]]
    skipped: list[dict[str, Any]]


ALLOWED_ANSWER_PROPERTIES = ("answer", "privateNote")


def compose_answer_value(new_text: str, existing: str | None, footer: str | None) -> str:
    stripped_text = (new_text or "").rstrip()
    footer_text = (footer or "").strip()
    if not footer_text:
        return stripped_text
    if footer_text in stripped_text:
        return stripped_text
    if stripped_text:
        return f"{stripped_text}\n\n{footer_text}"
    return footer_text


class DottieService:
    def __init__(self, client: DottieClient):
        self.client = client

    def my_employee_id(self) -> int:
        return current_employee_id(self.client.token_bundle)

    def employees(self) -> list[dict[str, Any]]:
        return self.client.get("/Employee") or []

    def _team_via_recurring_meetings(self) -> list[dict[str, Any]]:
        meetings = self.client.get("/RecurringMeeting", query={"ResponsibleEmployeeId": self.my_employee_id()}) or []
        employee_ids = sorted({item.get("employeeId") for item in meetings if item.get("employeeId")})
        if not employee_ids:
            return []
        return self.client.get("/Employee", query={"EmployeeId": employee_ids}) or []

    def team(self, include_self: bool = False) -> list[dict[str, Any]]:
        my_id = self.my_employee_id()
        team = self.client.get("/Employee", query={"LeaderId": my_id}) or []
        if not team:
            team = self._team_via_recurring_meetings()
        if include_self:
            me = self.client.get(f"/Employee/{my_id}")
            if me:
                team = [me, *team]
        unique_team = {item["id"]: item for item in team if item.get("id") is not None}
        return sorted(unique_team.values(), key=lambda item: str(item.get("name", "")))

    def equipment_overview(self, include_self: bool = False) -> list[dict[str, Any]]:
        team = self.team(include_self=include_self)
        employees_by_id = {employee["id"]: employee for employee in team}
        leases = self.client.get("/EquipmentLease") or []
        relevant_leases = [lease for lease in leases if lease.get("employeeId") in employees_by_id]
        equipment_ids = sorted({lease.get("equipmentId") for lease in relevant_leases if lease.get("equipmentId")})
        equipment = self.client.get("/Equipment", query={"Id": equipment_ids}) if equipment_ids else []
        equipment_by_id = {item["id"]: item for item in equipment or []}

        rows: list[dict[str, Any]] = []
        for lease in relevant_leases:
            employee = employees_by_id.get(lease["employeeId"], {})
            item = equipment_by_id.get(lease["equipmentId"], {})
            rows.append(
                {
                    "employeeId": lease.get("employeeId"),
                    "employeeName": employee.get("name", f"#{lease.get('employeeId')}"),
                    "equipmentId": lease.get("equipmentId"),
                    "equipmentName": item.get("name", f"#{lease.get('equipmentId')}"),
                    "equipmentTypeName": item.get("equipmentTypeName", ""),
                    "identifier": item.get("identifier", ""),
                    "dateStart": lease.get("dateStart"),
                    "dateEnd": lease.get("dateEnd"),
                    "commentStart": lease.get("commentStart", ""),
                    "commentEnd": lease.get("commentEnd", ""),
                    "status": item.get("status"),
                }
            )
        return sorted(rows, key=lambda item: (item["employeeName"], item["equipmentName"]))

    def absence_overview(self, *, from_date: str | None, to_date: str | None, include_self: bool = True) -> list[dict[str, Any]]:
        team = self.team(include_self=include_self)
        employee_ids = [employee["id"] for employee in team]
        intervals = self.client.post(
            "/LeaveInterval/Query",
            body={
                "employeeId": employee_ids,
                "from": from_date,
                "to": to_date,
            },
        ) or []
        return sorted(intervals, key=lambda item: (item.get("dateStart", ""), item.get("employeeName", "")))

    def recurring_meetings_for(self, employee_id: int) -> list[dict[str, Any]]:
        meetings = self.client.get(
            "/RecurringMeeting",
            query={
                "ResponsibleEmployeeId": self.my_employee_id(),
                "EmployeeId": [employee_id],
            },
        ) or []
        return sorted(meetings, key=lambda item: _parse_dt(item.get("date")))

    def _employee_for_query(self, employee_query: str | None, *, self_only: bool = False) -> dict[str, Any]:
        if self_only:
            my_id = self.my_employee_id()
            me = self.client.get(f"/Employee/{my_id}")
            if not me:
                raise ValueError(f"Could not load current employee #{my_id}.")
            return me

        employees = self.employees()
        if employee_query is None:
            raise ValueError("Employee query cannot be empty.")
        return _find_employee(employees, employee_query)

    def _visible_recurring_meetings_for(self, employee_id: int) -> list[dict[str, Any]]:
        meetings = self.recurring_meetings_for(employee_id)
        if meetings or employee_id != self.my_employee_id():
            return meetings

        meetings = self.client.get(
            "/RecurringMeeting",
            query={"EmployeeId": [employee_id]},
        ) or []
        return sorted(meetings, key=lambda item: _parse_dt(item.get("date")))

    def conversation_history(self, employee_query: str | None, *, self_only: bool = False) -> tuple[dict[str, Any], list[dict[str, Any]], dict[int, list[dict[str, Any]]]]:
        employee = self._employee_for_query(employee_query, self_only=self_only)
        meetings = self._visible_recurring_meetings_for(employee["id"])
        answers_by_meeting: dict[int, list[dict[str, Any]]] = {}
        for meeting in meetings:
            answers_by_meeting[meeting["id"]] = self.client.get("/RecurringMeetingAnswer", query={"RecurringMeetingId": meeting["id"]}) or []
        return employee, meetings, answers_by_meeting

    def upcoming_conversation(self, employee_query: str | None, *, self_only: bool = False) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
        employee = self._employee_for_query(employee_query, self_only=self_only)
        meetings = self._visible_recurring_meetings_for(employee["id"])
        upcoming = [meeting for meeting in meetings if int(meeting.get("status", -1)) == 0]
        if not upcoming:
            raise ValueError(f"No upcoming recurring meeting found for {employee['name']}.")
        meeting = upcoming[0]
        answers = self.client.get("/RecurringMeetingAnswer", query={"RecurringMeetingId": meeting["id"]}) or []
        return employee, meeting, answers

    def prepare_note_sync(self, employee_query: str, leader_feedback: str | None = None) -> SyncPreview:
        employee = self._employee_for_query(employee_query)
        meetings = self.recurring_meetings_for(employee["id"])

        previous = [meeting for meeting in meetings if int(meeting.get("status", -1)) == 1]
        upcoming = [meeting for meeting in meetings if int(meeting.get("status", -1)) == 0]
        if not previous:
            raise ValueError(f"No completed recurring meeting found for {employee['name']}.")
        if not upcoming:
            raise ValueError(f"No upcoming recurring meeting found for {employee['name']}.")

        previous_meeting = previous[-1]
        current_meeting = upcoming[0]
        previous_answers = self.client.get("/RecurringMeetingAnswer", query={"RecurringMeetingId": previous_meeting["id"]}) or []
        current_answers = self.client.get("/RecurringMeetingAnswer", query={"RecurringMeetingId": current_meeting["id"]}) or []

        previous_by_index = {item["index"]: item for item in previous_answers}
        patches: list[dict[str, Any]] = []
        for current in current_answers:
            index = current.get("index")
            previous_item = previous_by_index.get(index)
            if previous_item is None:
                continue

            generated_text = build_generated_private_note(
                current_index=index,
                current_question=current.get("question"),
                previous_answer=previous_item.get("answer"),
                previous_answers=previous_answers,
                previous_meeting=previous_meeting,
            )
            if not generated_text:
                continue

            merged = merge_private_note(current.get("privateNote"), generated_text)
            if merged != (current.get("privateNote") or ""):
                patches.append(
                    {
                        "id": current["id"],
                        "property": "privateNote",
                        "value": merged,
                        "entityId": current["id"],
                        "replacesVersion": current.get("version"),
                        "question": current.get("question"),
                        "index": index,
                    }
                )

        normalized_feedback = (leader_feedback or "").strip()
        if normalized_feedback:
            feedback_candidates = [item for item in current_answers if item.get("index") == LEADER_FEEDBACK_INDEX]
            if feedback_candidates:
                feedback_target = feedback_candidates[0]
                patches.append(
                    {
                        "id": feedback_target["id"],
                        "property": "answer",
                        "value": normalized_feedback,
                        "entityId": feedback_target["id"],
                        "replacesVersion": feedback_target.get("version"),
                        "question": feedback_target.get("question"),
                        "index": feedback_target.get("index"),
                    }
                )

        return SyncPreview(
            employee=employee,
            current_meeting=current_meeting,
            previous_meeting=previous_meeting,
            patches=patches,
        )

    def prepare_answer_updates(
        self,
        employee_query: str | None,
        *,
        self_only: bool = False,
        updates: list[dict[str, Any]],
        footer: str | None = None,
    ) -> AnswerPreview:
        if not updates:
            raise ValueError("At least one answer update is required.")

        employee = self._employee_for_query(employee_query, self_only=self_only)
        meetings = self._visible_recurring_meetings_for(employee["id"])
        upcoming = [meeting for meeting in meetings if int(meeting.get("status", -1)) == 0]
        if not upcoming:
            raise ValueError(f"No upcoming recurring meeting found for {employee['name']}.")
        meeting = upcoming[0]
        answers = self.client.get("/RecurringMeetingAnswer", query={"RecurringMeetingId": meeting["id"]}) or []
        by_index = {item.get("index"): item for item in answers}

        patches: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        for update in updates:
            index = update.get("index")
            if type(index) is not int:
                raise ValueError("Answer update requires an integer 'index'.")
            text = update.get("text", "")
            if not isinstance(text, str):
                raise ValueError("Answer update requires 'text' to be a string.")
            prop = (update.get("property") or "answer")
            if not isinstance(prop, str):
                raise ValueError("Answer update requires 'property' to be a string.")
            if prop not in ALLOWED_ANSWER_PROPERTIES:
                raise ValueError(f"Unsupported property {prop!r}; must be one of {ALLOWED_ANSWER_PROPERTIES}.")
            target = by_index.get(index)
            if target is None:
                raise ValueError(f"Upcoming meeting has no answer row at index {index}.")

            existing = target.get(prop)
            new_value = compose_answer_value(text, existing, footer)
            current_value = (existing or "")
            if new_value == current_value:
                skipped.append(
                    {
                        "id": target["id"],
                        "index": index,
                        "question": target.get("question"),
                        "property": prop,
                        "value": new_value,
                        "reason": "value-unchanged",
                    }
                )
                continue

            patches.append(
                {
                    "id": target["id"],
                    "index": index,
                    "question": target.get("question"),
                    "property": prop,
                    "value": new_value,
                    "entityId": target["id"],
                    "replacesVersion": target.get("version"),
                    "previousValue": current_value,
                }
            )

        return AnswerPreview(
            employee=employee,
            current_meeting=meeting,
            patches=patches,
            skipped=skipped,
        )

    def apply_answer_updates(self, preview: AnswerPreview) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for patch in preview.patches:
            payload = {
                "property": patch["property"],
                "value": patch["value"],
                "entityId": patch["entityId"],
                "replacesVersion": patch.get("replacesVersion"),
            }
            result = self.client.patch(f"/RecurringMeetingAnswer/{patch['id']}", body=payload)
            results.append(result or payload)
        return results

    def apply_sync(self, preview: SyncPreview) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for patch in preview.patches:
            payload = {
                "property": patch["property"],
                "value": patch["value"],
                "entityId": patch["entityId"],
                "replacesVersion": patch.get("replacesVersion"),
            }
            result = self.client.patch(f"/RecurringMeetingAnswer/{patch['id']}", body=payload)
            results.append(result or payload)
        return results


def build_generated_private_note(
    *,
    current_index: int,
    current_question: str | None,
    previous_answer: str | None,
    previous_answers: list[dict[str, Any]],
    previous_meeting: dict[str, Any],
) -> str:
    previous_date = str(previous_meeting.get("date", ""))[:10]
    if current_index == FOLLOW_UP_INDEX:
        bullets: list[str] = []
        for item in sorted(previous_answers, key=lambda answer: answer.get("index", 0)):
            answer_text = (item.get("answer") or "").strip()
            question_text = (item.get("question") or "").strip()
            if not answer_text:
                continue
            bullets.append(f"- {question_text}: {answer_text}")
        if not bullets:
            return ""
        return (
            f"Oppsummering fra forrige samtale ({previous_date})\n"
            f"[dottie-cli recurring-meeting:{previous_meeting.get('id')} index:{current_index}]\n\n"
            + "\n\n".join(bullets)
        )

    answer_text = (previous_answer or "").strip()
    if not answer_text:
        return ""
    question_label = (current_question or "Sporsmal").strip()
    return (
        f"Notat fra forrige samtale ({previous_date})\n"
        f"[dottie-cli recurring-meeting:{previous_meeting.get('id')} index:{current_index}]\n\n"
        f"{question_label}\n{answer_text}"
    )


def merge_private_note(existing: str | None, generated: str) -> str:
    existing_text = (existing or "").strip()
    generated_text = generated.strip()
    if not existing_text:
        return generated_text
    marker = _generated_note_marker(generated_text)
    if marker and marker in existing_text:
        return existing_text
    if generated_text in existing_text:
        return existing_text
    return f"{existing_text}\n\n{generated_text}"


def _generated_note_marker(generated_text: str) -> str | None:
    for line in generated_text.splitlines():
        marker = line.strip()
        if marker.startswith("[dottie-cli recurring-meeting:") and " index:" in marker and marker.endswith("]"):
            return marker
    return None


def summarize_team_by_org(team: list[dict[str, Any]]) -> list[dict[str, Any]]:
    buckets: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for employee in team:
        buckets[str(employee.get("organizationUnitId") or "unassigned")].append(employee)
    summary = []
    for org_unit_id, members in sorted(buckets.items(), key=lambda item: item[0]):
        summary.append({"organizationUnitId": org_unit_id, "members": len(members)})
    return summary
