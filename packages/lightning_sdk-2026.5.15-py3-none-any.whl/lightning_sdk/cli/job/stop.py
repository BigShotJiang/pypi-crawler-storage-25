"""Job stop command."""

from typing import Optional

import click
from rich.console import Console

from lightning_sdk.cli.legacy.job_and_mmt_action import _JobAndMMTAction


@click.command("stop")
@click.argument("name")
@click.option(
    "--teamspace",
    default=None,
    help=(
        "the name of the teamspace the job lives in. "
        "Should be specified as {teamspace_owner}/{teamspace_name} (e.g my-org/my-teamspace). "
        "If not specified can be selected interactively."
    ),
)
def stop_job(name: str, teamspace: Optional[str] = None) -> None:
    """Stop a job."""
    menu = _JobAndMMTAction()
    job = menu.job(name=name, teamspace=teamspace)
    job.stop()
    Console().print(f"Successfully stopped {job.name}!")
