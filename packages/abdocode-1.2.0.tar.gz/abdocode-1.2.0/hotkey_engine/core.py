from tkinter import messagebox, simpledialog
import tkinter as tk
import numpy as np
import sounddevice as sd
import os
import platform
import re
import string
import threading
import time
import json
import math
import statistics
import random
import datetime
import urllib.request
import urllib.parse
import urllib.error
import subprocess
import shutil
import logging
from pathlib import Path
from collections import defaultdict, deque

_used_shortcuts = {}
_enabled = True
_clipboard_history = []
_timer_registry = {}


# =========================
# CORE SAFETY FUNCTION
# =========================

def _safe_event(root, event):
    widget = root.focus_get()
    if widget:
        try:
            widget.event_generate(event)
        except:
            pass


# =========================
# BASIC SHORTCUT SYSTEM
# =========================

def add_shortcut(root, key, event):
    if key in _used_shortcuts:
        messagebox.showwarning(
            "Hotkey Warning",
            f"{key} already used for { _used_shortcuts[key] }"
        )
        return False

    def handler(e):
        if not _enabled:
            return
        _safe_event(root, event)

    root.bind_all(key, handler)
    _used_shortcuts[key] = event
    return True


def remove_shortcut(root, key):
    if key in _used_shortcuts:
        root.unbind_all(key)
        del _used_shortcuts[key]
        return True
    return False


def disable_all():
    global _enabled
    _enabled = False


def enable_all():
    global _enabled
    _enabled = True


def reset_all(root):
    for key in list(_used_shortcuts.keys()):
        root.unbind_all(key)
    _used_shortcuts.clear()


def list_shortcuts():
    return _used_shortcuts.copy()
def copy(root): add_shortcut(root, "<Control-c>", "<<Copy>>")
def paste(root): add_shortcut(root, "<Control-v>", "<<Paste>>")
def cut(root): add_shortcut(root, "<Control-x>", "<<Cut>>")
def select_all(root): add_shortcut(root, "<Control-a>", "<<SelectAll>>")
def undo(root): add_shortcut(root, "<Control-z>", "<<Undo>>")
def redo(root): add_shortcut(root, "<Control-y>", "<<Redo>>")
def find(root): add_shortcut(root, "<Control-f>", "<<Find>>")
def replace(root): add_shortcut(root, "<Control-h>", "<<Replace>>")
def goto(root): add_shortcut(root, "<Control-g>", "<<Goto>>")
def duplicate(root): add_shortcut(root, "<Control-d>", "<<Duplicate>>")
def select_line(root): add_shortcut(root, "<Control-l>", "<<SelectLine>>")
def delete_word(root): add_shortcut(root, "<Control-BackSpace>", "<<DeleteWord>>")
def delete_line(root): add_shortcut(root, "<Control-Delete>", "<<DeleteLine>>")
def cut_alt(root): add_shortcut(root, "<Shift-Delete>", "<<Cut>>")
def home(root): add_shortcut(root, "<Home>", "<<Home>>")
def end(root): add_shortcut(root, "<End>", "<<End>>")
def word_left(root): add_shortcut(root, "<Control-Left>", "<<WordLeft>>")
def word_right(root): add_shortcut(root, "<Control-Right>", "<<WordRight>>")
def page_up(root): add_shortcut(root, "<Control-Up>", "<<PageUp>>")
def page_down(root): add_shortcut(root, "<Control-Down>", "<<PageDown>>")
def select_left(root): add_shortcut(root, "<Shift-Left>", "<<SelectLeft>>")
def select_right(root): add_shortcut(root, "<Shift-Right>", "<<SelectRight>>")
def select_up(root): add_shortcut(root, "<Shift-Up>", "<<SelectUp>>")
def select_down(root): add_shortcut(root, "<Shift-Down>", "<<SelectDown>>")
def select_word_left(root): add_shortcut(root, "<Control-Shift-Left>", "<<SelectWordLeft>>")
def select_word_right(root): add_shortcut(root, "<Control-Shift-Right>", "<<SelectWordRight>>")
def save(root): add_shortcut(root, "<Control-s>", "<<Save>>")
def open_file(root): add_shortcut(root, "<Control-o>", "<<Open>>")
def new_file(root): add_shortcut(root, "<Control-n>", "<<New>>")
def print_file(root): add_shortcut(root, "<Control-p>", "<<Print>>")
def refresh(root): add_shortcut(root, "<F5>", "<<Refresh>>")
def use_all(root):
    copy(root)
    paste(root)
    cut(root)
    select_all(root)
    undo(root)
    redo(root)
    find(root)
    replace(root)
    goto(root)
    duplicate(root)
    select_line(root)
    delete_word(root)
    delete_line(root)
    cut_alt(root)
    home(root)
    end(root)
    word_left(root)
    word_right(root)
    page_up(root)
    page_down(root)
    select_left(root)
    select_right(root)
    select_up(root)
    select_down(root)
    select_word_left(root)
    select_word_right(root)
    save(root)
    open_file(root)
    new_file(root)
    print_file(root)
    refresh(root)
def show_all_shortcuts():
    shortcuts = list_shortcuts()
    if not shortcuts:
        messagebox.showinfo("Hotkeys", "No shortcuts defined.")
        return

    msg = "Current Shortcuts:\n\n"
    for key, event in shortcuts.items():
        msg += f"{key} -> {event}\n"

    messagebox.showinfo("Hotkeys", msg)
def shortcuts_popup_list(root):
    shortcuts = list_shortcuts()
    if not shortcuts:
        messagebox.showinfo("Hotkeys", "No shortcuts defined.")
        return

    msg = "Current Shortcuts:\n\n"
    for key, event in shortcuts.items():
        msg += f"{key} -> {event}\n"

    
    shortcuts_list = tk.Listbox(root)


    for key, event in shortcuts.items():
        shortcuts_list.insert(tk.END, f"{key} -> {event}")
    root.bind_all("<Button-3>", lambda e: shortcuts_list.tk_popup(e.x_root, e.y_root))


# =========================
# CLIPBOARD UTILITIES
# =========================

def _add_clipboard_history(text):
    text = str(text)
    if text and (_clipboard_history == [] or _clipboard_history[-1] != text):
        _clipboard_history.append(text)


def write_clipboard(root, text):
    try:
        root.clipboard_clear()
        root.clipboard_append(str(text))
        root.update()
        _add_clipboard_history(text)
        return True
    except Exception:
        return False


def read_clipboard(root):
    try:
        return root.clipboard_get()
    except Exception:
        return ""


def clear_clipboard(root):
    try:
        root.clipboard_clear()
        root.update()
        return True
    except Exception:
        return False


def get_clipboard_history():
    return list(_clipboard_history)


def paste_clipboard_history_item(root, index):
    try:
        text = _clipboard_history[index]
        return write_clipboard(root, text)
    except Exception:
        return False


# =========================
# FILE UTILITIES
# =========================

def read_text_file(path, encoding='utf-8'):
    path_obj = Path(path)
    with path_obj.open('r', encoding=encoding) as file:
        return file.read()


def write_text_file(path, text, encoding='utf-8'):
    path_obj = Path(path)
    path_obj.parent.mkdir(parents=True, exist_ok=True)
    with path_obj.open('w', encoding=encoding) as file:
        file.write(str(text))


def append_text_file(path, text, encoding='utf-8'):
    path_obj = Path(path)
    path_obj.parent.mkdir(parents=True, exist_ok=True)
    with path_obj.open('a', encoding=encoding) as file:
        file.write(str(text))


def list_files(folder, extension=None, recursive=False):
    base = Path(folder)
    if recursive:
        items = base.rglob('*')
    else:
        items = base.glob('*')
    files = [str(p) for p in items if p.is_file()]
    if extension:
        return [f for f in files if f.lower().endswith(extension.lower())]
    return files


def find_files(folder, pattern, recursive=True, extension=None):
    base = Path(folder)
    matcher = re.compile(pattern)
    paths = base.rglob('*') if recursive else base.glob('*')
    matches = []
    for p in paths:
        if p.is_file():
            if matcher.search(str(p)):
                if extension is None or str(p).lower().endswith(extension.lower()):
                    matches.append(str(p))
    return matches


# =========================
# TEXT UTILITIES
# =========================

def normalize_whitespace(text):
    return re.sub(r'\s+', ' ', str(text)).strip()


def count_words(text):
    return len(normalize_whitespace(text).split(' ')) if normalize_whitespace(text) else 0


def to_title_case(text):
    return str(text).title()


def snake_to_camel(text):
    parts = str(text).split('_')
    return parts[0].lower() + ''.join(word.capitalize() for word in parts[1:])


def camel_to_snake(text):
    s = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', str(text))
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s).lower()


def remove_punctuation(text):
    return str(text).translate(str.maketrans('', '', string.punctuation))


# =========================
# TIMER & SCHEDULER UTILITIES
# =========================

def set_timeout(callback, delay, *args, **kwargs):
    timer = threading.Timer(delay, callback, args=args, kwargs=kwargs)
    timer.daemon = True
    timer.start()
    timer_id = id(timer)
    _timer_registry[timer_id] = timer
    return timer_id


def _interval_runner(timer_id, callback, interval, args, kwargs):
    if timer_id not in _timer_registry:
        return
    callback(*args, **kwargs)
    timer = threading.Timer(interval, _interval_runner, args=(timer_id, callback, interval, args, kwargs))
    timer.daemon = True
    _timer_registry[timer_id] = timer
    timer.start()


def set_interval(callback, interval, *args, **kwargs):
    timer_id = int(time.time() * 1000000)
    timer = threading.Timer(interval, _interval_runner, args=(timer_id, callback, interval, args, kwargs))
    timer.daemon = True
    _timer_registry[timer_id] = timer
    timer.start()
    return timer_id


def cancel_timer(timer_id):
    timer = _timer_registry.pop(timer_id, None)
    if timer:
        timer.cancel()
        return True
    return False


def active_timers():
    return list(_timer_registry.keys())


# =========================
# SYSTEM UTILITIES
# =========================

def get_system_info():
    try:
        user = os.getlogin()
    except Exception:
        user = None
    return {
        'platform': platform.system(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'python_version': platform.python_version(),
        'cwd': os.getcwd(),
        'user': user,
    }


def get_environment_variables():
    return dict(os.environ)


def open_folder(path):
    path_obj = Path(path)
    if not path_obj.exists():
        return False
    try:
        if platform.system() == 'Windows':
            os.startfile(str(path_obj))
        elif platform.system() == 'Darwin':
            os.system(f'open "{path_obj}"')
        else:
            os.system(f'xdg-open "{path_obj}"')
        return True
    except Exception:
        return False


def get_file_size(path):
    path_obj = Path(path)
    return path_obj.stat().st_size if path_obj.exists() else 0


# =========================
# UI CONVENIENCE SHORTCUTS
# =========================

def show_info(title, message):
    messagebox.showinfo(title, str(message))


def show_warning(title, message):
    messagebox.showwarning(title, str(message))


def show_error(title, message):
    messagebox.showerror(title, str(message))


def ask_yes_no(title, message):
    return messagebox.askyesno(title, str(message))


def ask_input(title, prompt, default=''):
    return simpledialog.askstring(title, prompt, initialvalue=default)


def simple_popup(root, title, message):
    popup = tk.Toplevel(root)
    popup.title(title)
    label = tk.Label(popup, text=str(message), padx=10, pady=10)
    label.pack()
    btn = tk.Button(popup, text='OK', command=popup.destroy, padx=8, pady=4)
    btn.pack(pady=10)
    popup.transient(root)
    popup.grab_set()
    root.wait_window(popup)


def note_to_frequency(note):
    note = note.strip()
    if note.upper() == "REST":
        return 0.0

    octave = int(note[-1])
    name = note[:-1]
    if len(name) > 1 and name[-1] in "#b":
        base_name = name
    else:
        base_name = name

    semitone_map = {
        'C': 0,  'C#': 1, 'Db': 1,
        'D': 2,  'D#': 3, 'Eb': 3,
        'E': 4,  'F': 5,  'F#': 6,
        'Gb': 6, 'G': 7,  'G#': 8,
        'Ab': 8, 'A': 9,  'A#': 10,
        'Bb': 10, 'B': 11,
    }

    semitone = semitone_map.get(base_name, 0) + (octave + 1) * 12
    return 440.0 * 2 ** ((semitone - 69) / 12.0)


def play_tone(note, duration=0.2, volume=0.5, waveform='sine'):
    freq = note_to_frequency(note) if isinstance(note, str) else note
    if freq == 0:
        sd.sleep(int(duration * 1000))
        return

    fs = 44100
    t = np.linspace(0, duration, int(fs * duration), endpoint=False)

    if waveform == 'square':
        wave = np.sign(np.sin(2 * np.pi * freq * t))
    elif waveform == 'triangle':
        wave = 2 * np.abs(2 * ((freq * t) % 1) - 1) - 1
    else:
        wave = np.sin(2 * np.pi * freq * t)

    envelope = np.ones_like(wave)
    attack = min(0.02, duration * 0.2)
    release = min(0.03, duration * 0.2)
    attack_len = int(fs * attack)
    release_len = int(fs * release)
    if attack_len > 0:
        envelope[:attack_len] = np.linspace(0.0, 1.0, attack_len)
    if release_len > 0:
        envelope[-release_len:] = np.linspace(1.0, 0.0, release_len)

    wave = volume * envelope * wave
    sd.play(wave.astype(np.float32), fs)
    sd.wait()


def play_notes(sequence, tempo=120, volume=0.4, waveform='sine'):
    beat = 60.0 / tempo
    for note, length in sequence:
        play_tone(note, duration=length * beat, volume=volume, waveform=waveform)


sound_map = {}

sound_map["Victory"] = lambda: play_notes([('C4', 0.25), ('E4', 0.25), ('G4', 0.5), ('C5', 0.3)], tempo=140)
sound_map["Defeat"] = lambda: play_notes([('E4', 0.3), ('C4', 0.3), ('A3', 0.4)], tempo=90)
sound_map["Win"] = lambda: play_notes([('G4', 0.2), ('B4', 0.2), ('D5', 0.3)], tempo=150)
sound_map["Lose"] = lambda: play_notes([('D4', 0.2), ('C4', 0.3), ('A3', 0.4)], tempo=100)
sound_map["Click"] = lambda: play_notes([('C5', 0.1)], tempo=180)
sound_map["Hover"] = lambda: play_notes([('E5', 0.08), ('D5', 0.08)], tempo=200)
sound_map["Select"] = lambda: play_notes([('G4', 0.1), ('B4', 0.1)], tempo=180)
sound_map["Cancel"] = lambda: play_notes([('D4', 0.2)], tempo=120)
sound_map["Start"] = lambda: play_notes([('E4', 0.15), ('G4', 0.15), ('C5', 0.25)], tempo=150)
sound_map["Finish"] = lambda: play_notes([('C5', 0.2), ('E5', 0.2), ('G5', 0.3)], tempo=130)
sound_map["LevelUp"] = lambda: play_notes([('C4', 0.15), ('E4', 0.15), ('G4', 0.2), ('C5', 0.25)], tempo=170)
sound_map["LevelDown"] = lambda: play_notes([('G4', 0.2), ('E4', 0.2), ('C4', 0.3)], tempo=100)
sound_map["Coin"] = lambda: play_notes([('C6', 0.1), ('E6', 0.1)], tempo=180)
sound_map["Score"] = lambda: play_notes([('G5', 0.15), ('A5', 0.15), ('C6', 0.2)], tempo=160)
sound_map["Bonus"] = lambda: play_notes([('A4', 0.12), ('C5', 0.12), ('E5', 0.2)], tempo=170)
sound_map["Combo"] = lambda: play_notes([('B4', 0.1), ('D5', 0.1), ('F#5', 0.2)], tempo=180)
sound_map["UltraWin"] = lambda: play_notes([('C5', 0.15), ('E5', 0.15), ('G5', 0.15), ('B5', 0.3)], tempo=160)
sound_map["GameOver"] = lambda: play_notes([('A3', 0.4), ('F3', 0.4)], tempo=70)
sound_map["Restart"] = lambda: play_notes([('D4', 0.2), ('F#4', 0.2)], tempo=130)
sound_map["Pause"] = lambda: play_notes([('E4', 0.3), ('D4', 0.3)], tempo=90)
sound_map["Resume"] = lambda: play_notes([('G4', 0.2), ('A4', 0.2)], tempo=140)
sound_map["Unlock"] = lambda: play_notes([('C5', 0.2), ('D5', 0.2), ('E5', 0.2)], tempo=140)
sound_map["Lock"] = lambda: play_notes([('C4', 0.3), ('A3', 0.3)], tempo=80)
sound_map["Achievement"] = lambda: play_notes([('G4', 0.18), ('B4', 0.18), ('D5', 0.24)], tempo=150)
sound_map["Boss"] = lambda: play_notes([('C2', 0.4), ('G2', 0.4)], tempo=60, waveform='triangle')
sound_map["Alert"] = lambda: play_notes([('G5', 0.15), ('E5', 0.15)], tempo=160)
sound_map["Notification"] = lambda: play_notes([('E5', 0.2), ('G5', 0.2)], tempo=150)
sound_map["Message"] = lambda: play_notes([('F5', 0.15), ('E5', 0.15)], tempo=170)
sound_map["IncomingCall"] = lambda: play_notes([('A5', 0.25), ('C6', 0.25)], tempo=120)
sound_map["OutgoingCall"] = lambda: play_notes([('G5', 0.25), ('B5', 0.25)], tempo=120)
sound_map["Email"] = lambda: play_notes([('F5', 0.2), ('A5', 0.2)], tempo=140)
sound_map["Success"] = lambda: play_notes([('C5', 0.2), ('E5', 0.2), ('G5', 0.2)], tempo=150)
sound_map["Fail"] = lambda: play_notes([('D4', 0.25), ('C4', 0.25)], tempo=90)
sound_map["Error"] = lambda: play_notes([('F4', 0.25), ('D4', 0.25)], tempo=90)
sound_map["Warning"] = lambda: play_notes([('B4', 0.2), ('G4', 0.2)], tempo=110)
sound_map["Connect"] = lambda: play_notes([('E5', 0.2), ('G5', 0.2)], tempo=150)
sound_map["Disconnect"] = lambda: play_notes([('B4', 0.2), ('A4', 0.2)], tempo=110)
sound_map["Loading"] = lambda: play_notes([('C5', 0.12), ('D5', 0.12), ('E5', 0.12)], tempo=220)
sound_map["Done"] = lambda: play_notes([('G5', 0.2), ('C6', 0.2)], tempo=140)
sound_map["Save"] = lambda: play_notes([('E5', 0.18), ('C5', 0.18)], tempo=140)
sound_map["Delete"] = lambda: play_notes([('C4', 0.2), ('E4', 0.2)], tempo=110)
sound_map["Copy"] = lambda: play_notes([('G4', 0.15), ('B4', 0.15)], tempo=180)
sound_map["Paste"] = lambda: play_notes([('A4', 0.15), ('C5', 0.15)], tempo=180)
sound_map["Cut"] = lambda: play_notes([('F4', 0.15), ('D4', 0.15)], tempo=170)
sound_map["Refresh"] = lambda: play_notes([('C5', 0.12), ('D5', 0.12), ('C5', 0.12)], tempo=220)
sound_map["Sync"] = lambda: play_notes([('E4', 0.12), ('G4', 0.12), ('B4', 0.12)], tempo=200)
sound_map["Update"] = lambda: play_notes([('A4', 0.2), ('B4', 0.2)], tempo=140)
sound_map["Install"] = lambda: play_notes([('C4', 0.12), ('E4', 0.12), ('G4', 0.2)], tempo=170)
sound_map["Boot"] = lambda: play_notes([('C5', 0.25), ('E5', 0.25)], tempo=120)
sound_map["Shutdown"] = lambda: play_notes([('A3', 0.4), ('F3', 0.4)], tempo=65, waveform='triangle')
sound_map["Tap"] = lambda: play_notes([('D5', 0.08)], tempo=220)
sound_map["Pop"] = lambda: play_notes([('F5', 0.1)], tempo=200)
sound_map["Beep"] = lambda: play_notes([('G4', 0.1)], tempo=220)
sound_map["Ding"] = lambda: play_notes([('E5', 0.18)], tempo=190)
sound_map["ClickSoft"] = lambda: play_notes([('F4', 0.1)], tempo=210)
sound_map["ClickHard"] = lambda: play_notes([('C4', 0.1)], tempo=200)
sound_map["Swipe"] = lambda: play_notes([('G5', 0.1), ('A5', 0.1)], tempo=180)
sound_map["Slide"] = lambda: play_notes([('A4', 0.1), ('G4', 0.1)], tempo=180)
sound_map["Open"] = lambda: play_notes([('E5', 0.2), ('G5', 0.2)], tempo=150)
sound_map["Close"] = lambda: play_notes([('D4', 0.2), ('C4', 0.2)], tempo=110)
sound_map["MenuOpen"] = lambda: play_notes([('G4', 0.12), ('A4', 0.12)], tempo=200)
sound_map["MenuClose"] = lambda: play_notes([('E4', 0.12), ('D4', 0.12)], tempo=190)
sound_map["TabSwitch"] = lambda: play_notes([('F4', 0.12), ('A4', 0.12)], tempo=190)
sound_map["Drag"] = lambda: play_notes([('C4', 0.12), ('D4', 0.12)], tempo=180)
sound_map["Drop"] = lambda: play_notes([('E4', 0.18), ('C4', 0.18)], tempo=140)
sound_map["Focus"] = lambda: play_notes([('A5', 0.1), ('G5', 0.1)], tempo=200)
sound_map["Unfocus"] = lambda: play_notes([('D4', 0.1), ('C4', 0.1)], tempo=180)
sound_map["SelectItem"] = lambda: play_notes([('B4', 0.15), ('D5', 0.15)], tempo=170)
sound_map["Deselect"] = lambda: play_notes([('C4', 0.15), ('Bb3', 0.15)], tempo=160)
sound_map["Confirm"] = lambda: play_notes([('C5', 0.2), ('G5', 0.2)], tempo=150)
sound_map["Back"] = lambda: play_notes([('D4', 0.2), ('C4', 0.2)], tempo=120)
sound_map["Forward"] = lambda: play_notes([('G4', 0.2), ('A4', 0.2)], tempo=140)
sound_map["Scroll"] = lambda: play_notes([('E5', 0.08), ('F5', 0.08), ('G5', 0.08)], tempo=240)
sound_map["ZoomIn"] = lambda: play_notes([('C5', 0.2), ('E5', 0.2)], tempo=160)
sound_map["ZoomOut"] = lambda: play_notes([('G4', 0.2), ('E4', 0.2)], tempo=120)
sound_map["Laser"] = lambda: play_notes([('A5', 0.1), ('C6', 0.1), ('E6', 0.15)], tempo=220, waveform='square')
sound_map["Plasma"] = lambda: play_notes([('F5', 0.15), ('G5', 0.15), ('A5', 0.2)], tempo=200, waveform='triangle')
sound_map["Warp"] = lambda: play_notes([('C4', 0.1), ('C5', 0.3)], tempo=130, waveform='triangle')
sound_map["Robot"] = lambda: play_notes([('G3', 0.2), ('D4', 0.2), ('G4', 0.2)], tempo=110, waveform='square')
sound_map["AI"] = lambda: play_notes([('F4', 0.15), ('A4', 0.15), ('C5', 0.2)], tempo=140, waveform='sine')
sound_map["Drone"] = lambda: play_notes([('D3', 0.4), ('F3', 0.4)], tempo=70, waveform='triangle')
sound_map["Scan"] = lambda: play_notes([('E4', 0.12), ('F4', 0.12), ('G4', 0.12)], tempo=210)
sound_map["Hack"] = lambda: play_notes([('D4', 0.1), ('F4', 0.1), ('A4', 0.2)], tempo=180, waveform='square')
sound_map["Glitch"] = lambda: play_notes([('G5', 0.05), ('C5', 0.05), ('E5', 0.05)], tempo=260, waveform='square')
sound_map["Signal"] = lambda: play_notes([('A4', 0.2), ('C5', 0.2)], tempo=160)

# Add 100 musical-style sound names with melodic variations.
base_sequences = [
    [('C4', 0.2), ('E4', 0.2), ('G4', 0.2), ('C5', 0.3)],
    [('D4', 0.18), ('F#4', 0.18), ('A4', 0.18), ('D5', 0.3)],
    [('E4', 0.15), ('G#4', 0.15), ('B4', 0.15), ('E5', 0.3)],
    [('F4', 0.2), ('A4', 0.2), ('C5', 0.2), ('F5', 0.3)],
    [('G4', 0.15), ('B4', 0.15), ('D5', 0.15), ('G5', 0.3)],
    [('A4', 0.18), ('C#5', 0.18), ('E5', 0.18), ('A5', 0.3)],
    [('B4', 0.15), ('D5', 0.15), ('F#5', 0.15), ('B5', 0.3)],
]
for i in range(1, 101):
    pattern = base_sequences[(i - 1) % len(base_sequences)]
    tempo = 100 + ((i - 1) % 5) * 10
    waveform = 'triangle' if i % 7 == 0 else 'square' if i % 11 == 0 else 'sine'
    sound_map[f"Melody{i:03d}"] = lambda p=pattern, t=tempo, w=waveform: play_notes(p, tempo=t, waveform=w)

# Add 300 extra musical-style sound names with richer, more varied melodic textures.
extra_sequences = [
    [('C4', 0.15), ('D4', 0.15), ('E4', 0.15), ('G4', 0.25)],
    [('E4', 0.18), ('G4', 0.18), ('B4', 0.18), ('E5', 0.3)],
    [('G3', 0.2), ('B3', 0.2), ('D4', 0.2), ('G4', 0.3)],
    [('A3', 0.16), ('C4', 0.16), ('E4', 0.16), ('A4', 0.28)],
    [('F4', 0.14), ('A4', 0.14), ('C5', 0.14), ('F5', 0.28)],
    [('D4', 0.2), ('F#4', 0.15), ('A4', 0.15), ('D5', 0.3)],
    [('B3', 0.2), ('D4', 0.2), ('F#4', 0.2), ('B4', 0.3)],
    [('C5', 0.12), ('E5', 0.12), ('G5', 0.12), ('C6', 0.24)],
    [('A4', 0.15), ('B4', 0.15), ('C#5', 0.15), ('E5', 0.3)],
    [('G4', 0.18), ('A4', 0.18), ('B4', 0.18), ('D5', 0.3)],
    [('F#4', 0.14), ('A4', 0.14), ('C#5', 0.14), ('F#5', 0.3)],
    [('E4', 0.16), ('F#4', 0.16), ('G#4', 0.16), ('B4', 0.3)],
    [('D5', 0.15), ('C5', 0.15), ('A4', 0.15), ('F4', 0.25)],
    [('C4', 0.2), ('B3', 0.2), ('A3', 0.2), ('G3', 0.3)],
    [('E5', 0.1), ('D5', 0.1), ('C5', 0.1), ('B4', 0.1), ('A4', 0.2)],
]
for i in range(101, 401):
    pattern = extra_sequences[(i - 101) % len(extra_sequences)]
    tempo = 90 + ((i - 101) % 10) * 7
    waveform = 'square' if i % 13 == 0 else 'triangle' if i % 7 == 0 else 'sine'
    volume = 0.35 + ((i - 101) % 4) * 0.05
    sound_map[f"Melody{i:03d}"] = lambda p=pattern, t=tempo, w=waveform, v=volume: play_notes(p, tempo=t, volume=v, waveform=w)

# General utilities added to make the library competitive.

# =========================
# VALIDATION UTILITIES
# =========================

def is_integer(value):
    return isinstance(value, int) and not isinstance(value, bool)


def is_float(value):
    return isinstance(value, float)


def is_string(value):
    return isinstance(value, str)


def is_list(value):
    return isinstance(value, list)


def is_dict(value):
    return isinstance(value, dict)


def is_boolean(value):
    return isinstance(value, bool)


def validate_schema(data, schema, path=''):
    errors = []
    if not isinstance(schema, dict):
        return False, ['schema must be a dict']

    if 'type' in schema:
        expected = schema['type']
        if expected == 'string' and not isinstance(data, str):
            errors.append(f'{path or "root"}: expected string')
        elif expected == 'integer' and not is_integer(data):
            errors.append(f'{path or "root"}: expected integer')
        elif expected == 'number' and not isinstance(data, (int, float)):
            errors.append(f'{path or "root"}: expected number')
        elif expected == 'boolean' and not isinstance(data, bool):
            errors.append(f'{path or "root"}: expected boolean')
        elif expected == 'object' and not isinstance(data, dict):
            errors.append(f'{path or "root"}: expected object')
        elif expected == 'array' and not isinstance(data, list):
            errors.append(f'{path or "root"}: expected array')

    if isinstance(data, dict) and 'properties' in schema:
        for key, subschema in schema['properties'].items():
            if key in data:
                valid, sub_errors = validate_schema(data[key], subschema, f'{path}.{key}' if path else key)
                errors.extend(sub_errors)
            elif subschema.get('required', False):
                errors.append(f'{path}.{key}' if path else key + ': required field missing')

    if isinstance(data, list) and 'items' in schema:
        for index, item in enumerate(data):
            valid, sub_errors = validate_schema(item, schema['items'], f'{path}[{index}]')
            errors.extend(sub_errors)

    return len(errors) == 0, errors


def ensure_schema(data, schema):
    valid, errors = validate_schema(data, schema)
    if not valid:
        raise ValueError('Validation failed: ' + '; '.join(errors))
    return True


def has_keys(obj, keys):
    return all(k in obj for k in keys)


def assert_type(value, expected_type):
    return isinstance(value, expected_type)


def is_truthy(value):
    return bool(value)


def is_blank(text):
    return not str(text).strip()


# =========================
# JSON & CONFIG UTILITIES
# =========================

def load_json(path, encoding='utf-8'):
    with open(path, 'r', encoding=encoding) as file:
        return json.load(file)


def save_json(path, data, encoding='utf-8', indent=4):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding=encoding) as file:
        json.dump(data, file, ensure_ascii=False, indent=indent)


def merge_dicts(*dicts, deep=True):
    result = {}
    for d in dicts:
        if not isinstance(d, dict):
            continue
        for key, value in d.items():
            if deep and key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = merge_dicts(result[key], value, deep=True)
            else:
                result[key] = value
    return result


def deep_get(data, path, default=None, separator='.'):
    if data is None:
        return default
    if separator in path:
        parts = path.split(separator)
    else:
        parts = [path]
    current = data
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return default
    return current


def deep_set(data, path, value, separator='.'):
    if not isinstance(data, dict):
        raise ValueError('deep_set target must be a dict')
    keys = path.split(separator)
    current = data
    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]
    current[keys[-1]] = value
    return data


def load_json_url(url, headers=None, timeout=10):
    request = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode('utf-8'))


# =========================
# HTTP UTILITIES
# =========================

def http_get(url, headers=None, timeout=10):
    request = urllib.request.Request(url, headers=headers or {}, method='GET')
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read(), response.getcode(), dict(response.headers)


def http_post(url, data=None, json_data=None, headers=None, timeout=10):
    request_headers = headers.copy() if headers else {}
    body = None
    if json_data is not None:
        body = json.dumps(json_data).encode('utf-8')
        request_headers['Content-Type'] = 'application/json'
    elif data is not None:
        if isinstance(data, dict):
            body = urllib.parse.urlencode(data).encode('utf-8')
        else:
            body = str(data).encode('utf-8')
    request = urllib.request.Request(url, data=body, headers=request_headers, method='POST')
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read(), response.getcode(), dict(response.headers)


def fetch_json(url, headers=None, timeout=10):
    body, code, headers = http_get(url, headers=headers, timeout=timeout)
    return json.loads(body.decode('utf-8'))


def check_url(url, timeout=5):
    try:
        _, code, _ = http_get(url, timeout=timeout)
        return 200 <= code < 400
    except Exception:
        return False


def download_file(url, dest, chunk_size=8192, timeout=10):
    Path(dest).parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        with open(dest, 'wb') as out_file:
            while True:
                chunk = response.read(chunk_size)
                if not chunk:
                    break
                out_file.write(chunk)
    return dest


# =========================
# DATE / TIME UTILITIES
# =========================

def current_timestamp():
    return datetime.datetime.now().timestamp()


def format_datetime(value=None, fmt='%Y-%m-%d %H:%M:%S'):
    if value is None:
        value = datetime.datetime.now()
    if isinstance(value, (int, float)):
        value = datetime.datetime.fromtimestamp(value)
    return value.strftime(fmt)


def parse_datetime(text, fmt='%Y-%m-%d %H:%M:%S'):
    return datetime.datetime.strptime(str(text), fmt)


def relative_time(value, now=None):
    if now is None:
        now = datetime.datetime.now()
    if isinstance(value, (int, float)):
        value = datetime.datetime.fromtimestamp(value)
    delta = now - value
    seconds = int(delta.total_seconds())
    if seconds < 0:
        return 'in the future'
    if seconds < 60:
        return f'{seconds}s ago'
    if seconds < 3600:
        return f'{seconds // 60}m ago'
    if seconds < 86400:
        return f'{seconds // 3600}h ago'
    return f'{seconds // 86400}d ago'


def countdown(seconds, callback=None, interval=1):
    start = time.time()
    remaining = seconds
    while remaining > 0:
        time.sleep(min(interval, remaining))
        remaining = seconds - (time.time() - start)
        if callback:
            callback(max(0, int(remaining)))
    return 0


def is_weekend(value=None):
    if value is None:
        value = datetime.datetime.now()
    if isinstance(value, (int, float)):
        value = datetime.datetime.fromtimestamp(value)
    return value.weekday() >= 5


def add_business_days(value, days):
    if isinstance(value, (int, float)):
        value = datetime.datetime.fromtimestamp(value)
    result = value
    while days > 0:
        result += datetime.timedelta(days=1)
        if result.weekday() < 5:
            days -= 1
    return result


# =========================
# MATH / STATISTICS UTILITIES
# =========================

def clamp(value, minimum, maximum):
    return max(minimum, min(maximum, value))


def lerp(start, end, fraction):
    return start + (end - start) * fraction


def remap(value, old_min, old_max, new_min, new_max):
    if old_max == old_min:
        raise ValueError('old_min and old_max cannot be equal')
    ratio = (value - old_min) / (old_max - old_min)
    return new_min + ratio * (new_max - new_min)


def mean_values(values):
    return statistics.mean(values)


def median_values(values):
    return statistics.median(values)


def mode_values(values):
    try:
        return statistics.mode(values)
    except statistics.StatisticsError:
        return None


def variance(values, sample=False):
    return statistics.pvariance(values) if not sample else statistics.variance(values)


def stddev(values, sample=False):
    return math.sqrt(variance(values, sample=sample))


def percent_change(original, new):
    if original == 0:
        return float('inf') if new else 0.0
    return ((new - original) / abs(original)) * 100.0


def safe_divide(a, b, default=0.0):
    try:
        return a / b
    except Exception:
        return default


def random_choice_weighted(choices):
    total = sum(weight for item, weight in choices)
    if total <= 0:
        return None
    r = random.uniform(0, total)
    upto = 0
    for item, weight in choices:
        if upto + weight >= r:
            return item
        upto += weight
    return None


# =========================
# PROCESS & COMMAND UTILITIES
# =========================

def run_command(command, shell=False, cwd=None, env=None, timeout=None):
    if isinstance(command, str) and not shell:
        command = command.split()
    result = subprocess.run(command, shell=shell, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    return {
        'returncode': result.returncode,
        'stdout': result.stdout,
        'stderr': result.stderr,
    }


def run_command_async(command, callback=None, shell=False, cwd=None, env=None, timeout=None):
    def worker():
        result = run_command(command, shell=shell, cwd=cwd, env=env, timeout=timeout)
        if callback:
            callback(result)
    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    return thread


def which(program):
    return shutil.which(program)


def is_process_running(name):
    if platform.system() == 'Windows':
        tasklist = subprocess.run(['tasklist'], capture_output=True, text=True)
        return name.lower() in tasklist.stdout.lower()
    else:
        ps = subprocess.run(['ps', 'ax'], capture_output=True, text=True)
        return name.lower() in ps.stdout.lower()


def kill_process(pid):
    try:
        os.kill(pid, 9)
        return True
    except Exception:
        return False


def copy_file(src, dst):
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return dst


def move_file(src, dst):
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    shutil.move(src, dst)
    return dst


def delete_file(path):
    try:
        Path(path).unlink()
        return True
    except Exception:
        return False


# =========================
# DATA STRUCTURE UTILITIES
# =========================

def chunk_list(sequence, chunk_size):
    if chunk_size <= 0:
        raise ValueError('chunk_size must be positive')
    return [sequence[i:i + chunk_size] for i in range(0, len(sequence), chunk_size)]


def flatten_list(nested_list):
    result = []
    for item in nested_list:
        if isinstance(item, list):
            result.extend(flatten_list(item))
        else:
            result.append(item)
    return result


def unique_preserve(sequence):
    seen = set()
    result = []
    for item in sequence:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def group_by(sequence, key_function):
    groups = defaultdict(list)
    for item in sequence:
        groups[key_function(item)].append(item)
    return dict(groups)


def coalesce(*values):
    for value in values:
        if value is not None:
            return value
    return None


def dict_merge(*dicts):
    merged = {}
    for d in dicts:
        if isinstance(d, dict):
            merged.update(d)
    return merged


# =========================
# SETTINGS & STORAGE UTILITIES
# =========================

def load_settings(path, default=None, encoding='utf-8'):
    if not Path(path).exists():
        return default if default is not None else {}
    return load_json(path, encoding=encoding)


def save_settings(path, settings, encoding='utf-8', indent=4):
    return save_json(path, settings, encoding=encoding, indent=indent)


def get_setting(settings, key, default=None):
    if isinstance(settings, dict):
        return deep_get(settings, key, default=default)
    return default


def set_setting(settings, key, value):
    if not isinstance(settings, dict):
        raise ValueError('settings must be a dict')
    return deep_set(settings, key, value)


def update_settings(settings, updates):
    if not isinstance(settings, dict) or not isinstance(updates, dict):
        raise ValueError('update_settings requires dicts')
    return merge_dicts(settings, updates)


def flatten_settings(settings, separator='.'):
    result = {}
    def _flatten(source, parent_key=''):
        for key, value in source.items():
            full_key = f'{parent_key}{separator}{key}' if parent_key else key
            if isinstance(value, dict):
                _flatten(value, full_key)
            else:
                result[full_key] = value
    _flatten(settings)
    return result


# =========================
# EVENT BUS / PUBLISH-SUBSCRIBE
# =========================

class EventBus:
    def __init__(self):
        self._listeners = defaultdict(list)

    def subscribe(self, event_name, listener):
        if callable(listener):
            self._listeners[event_name].append(listener)
            return True
        return False

    def unsubscribe(self, event_name, listener=None):
        if event_name not in self._listeners:
            return False
        if listener is None:
            self._listeners.pop(event_name, None)
            return True
        try:
            self._listeners[event_name].remove(listener)
            return True
        except ValueError:
            return False

    def emit(self, event_name, *args, **kwargs):
        for listener in list(self._listeners.get(event_name, [])):
            try:
                listener(*args, **kwargs)
            except Exception:
                pass

    def clear(self):
        self._listeners.clear()


# =========================
# LOGGING UTILITIES
# =========================

_log_file = None


def set_log_file(path, level=logging.INFO, mode='a'):
    global _log_file
    logger = logging.getLogger(__name__)
    logger.setLevel(level)
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
    file_handler = logging.FileHandler(path, mode=mode, encoding='utf-8')
    file_handler.setFormatter(formatter)
    logger.handlers = [file_handler]
    _log_file = path
    return path


def log_info(message):
    logging.getLogger(__name__).info(str(message))


def log_warning(message):
    logging.getLogger(__name__).warning(str(message))


def log_error(message):
    logging.getLogger(__name__).error(str(message))


def log_debug(message):
    logging.getLogger(__name__).debug(str(message))


def get_log_file():
    return _log_file


def configure_logging(level=logging.INFO, fmt='[%(levelname)s] %(message)s'):
    logging.basicConfig(level=level, format=fmt)
    return logging.getLogger(__name__)


# =========================
# CLI / OUTPUT UTILITIES
# =========================

def print_table(rows, headers=None, padding=2):
    if headers:
        rows = [headers] + rows
    widths = [max(len(str(value)) for value in column) for column in zip(*rows)]
    lines = []
    for row in rows:
        line = '  '.join(str(value).ljust(widths[index] + padding) for index, value in enumerate(row))
        lines.append(line)
    print('\n'.join(lines))


def progress_bar(iterable, prefix='', size=40, fill='█'):
    total = len(iterable)
    for index, item in enumerate(iterable, start=1):
        filled = int(size * index / total)
        bar = fill * filled + '-' * (size - filled)
        print(f'\r{prefix} |{bar}| {index}/{total}', end='')
        yield item
    print()


def prompt_choices(root, title, options, default_index=0):
    if not options:
        return None
    choice = simpledialog.askstring(title, 'Choose: ' + ', '.join(str(i+1) + ':' + str(opt) for i, opt in enumerate(options)), initialvalue=str(default_index+1), parent=root)
    try:
        idx = int(choice) - 1
        return options[idx] if 0 <= idx < len(options) else None
    except Exception:
        return None


def clear_console():
    if platform.system() == 'Windows':
        os.system('cls')
    else:
        os.system('clear')


def confirm_action(message='Proceed?', default=True):
    return messagebox.askyesno('Confirm', message, icon='question')


def show_progress(title, current, total):
    percent = int((current / total) * 100) if total else 0
    return f'{title}: {percent}% ({current}/{total})'


def play(name):
    if name in sound_map:
        sound_map[name]()
    else:
        print(f"Sound '{name}' not found in sound_map.")


def add_sound(name, func):
    sound_map[name] = lambda: func()

# =========================
# MAJOR ARCHITECTURE EXPANSION
# =========================

class PluginManager:
    """Manages plugins and extension lifecycle."""

    def __init__(self):
        self.plugins = {}

    def register(self, name, plugin):
        self.plugins[name] = plugin
        return True

    def unregister(self, name):
        if name in self.plugins:
            del self.plugins[name]
            return True
        return False

    def get_plugin(self, name, default=None):
        return self.plugins.get(name, default)

    def list_plugins(self):
        return list(self.plugins.keys())


class WorkflowEngine:
    """Orchestrates workflow stages with dependencies."""

    def __init__(self):
        self.stages = {}
        self.dependencies = {}

    def add_stage(self, name, callback, depends_on=None):
        self.stages[name] = callback
        self.dependencies[name] = depends_on or []
        return self

    def run_stage(self, name, context=None):
        if name not in self.stages:
            raise KeyError(f'Stage {name} is not registered')
        context = context or {}
        for dependency in self.dependencies.get(name, []):
            self.run_stage(dependency, context)
        return self.stages[name](context)

    def run_all(self, context=None):
        context = context or {}
        for name in list(self.stages.keys()):
            self.run_stage(name, context)
        return context


class ResourceRegistry:
    """Tracks named resources across application layers."""

    def __init__(self):
        self.resources = {}

    def register_resource(self, name, resource):
        self.resources[name] = resource
        return self

    def get_resource(self, name, default=None):
        return self.resources.get(name, default)

    def list_resources(self):
        return list(self.resources.keys())


class DistributedJobScheduler:
    """Schedules jobs using a simple distributed work queue."""

    def __init__(self):
        self.jobs = []
        self.results = {}

    def schedule(self, job_id, callback, *args, **kwargs):
        self.jobs.append((job_id, callback, args, kwargs))
        return self

    def run_next(self):
        if not self.jobs:
            return None
        job_id, callback, args, kwargs = self.jobs.pop(0)
        result = callback(*args, **kwargs)
        self.results[job_id] = result
        return result

    def run_all(self):
        while self.jobs:
            self.run_next()
        return self.results


class SecurityPolicyManager:
    """Manages security policies and validation rules."""

    def __init__(self):
        self.policies = {}

    def add_policy(self, name, callback):
        self.policies[name] = callback
        return self

    def validate(self, name, context=None):
        if name not in self.policies:
            raise KeyError(f'Policy {name} not found')
        return bool(self.policies[name](context or {}))

    def list_policies(self):
        return list(self.policies.keys())


class AuditTrail:
    """Records immutable audit events."""

    def __init__(self):
        self.events = []

    def record_event(self, event_type, details=None):
        self.events.append({
            'type': event_type,
            'details': details,
            'timestamp': current_timestamp(),
        })
        return self

    def query(self, event_type=None):
        if event_type is None:
            return list(self.events)
        return [item for item in self.events if item['type'] == event_type]


class ModelRegistry:
    """Stores models and their metadata."""

    def __init__(self):
        self.models = {}

    def register_model(self, name, model, metadata=None):
        self.models[name] = {
            'model': model,
            'metadata': metadata or {},
        }
        return self

    def get_model(self, name):
        return self.models.get(name)

    def list_models(self):
        return list(self.models.keys())


class AnalyticsEngine:
    """Processes metrics and analytics streams."""

    def __init__(self):
        self.events = []

    def track_event(self, name, properties=None):
        self.events.append({'name': name, 'properties': properties or {}, 'time': current_timestamp()})
        return self

    def summarize(self):
        return {
            'total_events': len(self.events),
            'event_names': list({event['name'] for event in self.events}),
        }


plugin_manager = PluginManager()
workflow_engine = WorkflowEngine()
resource_registry = ResourceRegistry()
job_scheduler = DistributedJobScheduler()
security_policy_manager = SecurityPolicyManager()
audit_trail = AuditTrail()
model_registry = ModelRegistry()
analytics_engine = AnalyticsEngine()
