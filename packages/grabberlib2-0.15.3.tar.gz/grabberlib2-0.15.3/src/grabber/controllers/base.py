import asyncio
import time
from pathlib import Path
from typing import ClassVar

import nest_asyncio
from cement import Controller, ex
from telegraph import Telegraph

from grabber.core.bot.infrastructure.telegram_sender import TelegramSenderAdapter
from grabber.core.bot.usecases.contracts import SendMessageRequest
from grabber.core.bot.usecases.message_sender import MessageSenderUseCase
from grabber.core.extractor.constants import QUERY_MAPPING
from grabber.core.extractor.infrastructure.helpers import get_entity
from grabber.core.extractor.infrastructure.publishing.telegraph import upload_folders_to_telegraph
from grabber.core.extractor.sources.registry import SourceDispatcher
from grabber.core.extractor.usecases import SourceRunRequest
from grabber.core.settings import TELEGRAPH_TOKEN
from grabber.core.sources.bypass import bypass_link, bypass_ouo
from grabber.core.sources.ouo import ouo_bypass
from grabber.core.sources.paster import retrieve_paster_contents

from ..core.version import get_version

VERSION_BANNER = f"""
A beautiful CLI utility to download images from the web! {get_version()}
"""

SOURCE_DISPATCHER = SourceDispatcher()


class Base(Controller):
    class Meta:
        label = "base"

        # text displayed at the top of --help output
        description = "A beautiful CLI utility to download images from the web"

        # text displayed at the bottom of --help output
        epilog = "Usage: grabber --entity 4khd --folder 4khd --publish --sources <list of links>"

        # controller level arguments. ex: 'test --version'
        arguments: ClassVar = [
            ### add a version banner
            (
                ["-s", "--sources"],
                {
                    "dest": "sources",
                    "type": str,
                    "help": "List of links",
                    "nargs": "+",
                },
            ),
            (
                ["-f", "--folder"],
                {
                    "dest": "folder",
                    "default": "",
                    "type": str,
                    "help": "Folder where to save",
                },
            ),
            (
                ["-l", "--limit"],
                {
                    "dest": "limit",
                    "type": int,
                    "help": "Limit the amount of posts retrieved (used altogether with --tag)",
                    "default": 0,
                },
            ),
            (
                ["-p", "--publish"],
                {
                    "dest": "publish",
                    "action": "store_true",
                    "help": "Publish page to telegraph",
                },
            ),
            (
                ["-u", "--upload"],
                {
                    "dest": "upload",
                    "action": "store_true",
                    "help": "Upload and publish folders to telegraph",
                },
            ),
            (
                ["-t", "--tag"],
                {
                    "dest": "is_tag",
                    "action": "store_true",
                    "help": "Indicates that the link(s) passed is a tag in which the posts are paginated",
                },
            ),
            (
                ["-b", "--bot"],
                {
                    "dest": "bot",
                    "action": "store_true",
                    "help": "Should the newly post be sent to telegram?",
                },
            ),
            (
                ["-v", "--version"],
                {
                    "action": "store_true",
                    "dest": "version",
                    "help": "Version of the lib",
                },
            ),
            (
                ["-a", "--show-all-entities"],
                {
                    "action": "store_true",
                    "dest": "show_all_entities",
                    "help": "Show all the websites supported",
                },
            ),
            (
                ["-bl", "--bypass-link"],
                {
                    "dest": "bypass_link",
                    "type": str,
                    "help": "Bypass a link and returns the final URL",
                    "default": "",
                    "nargs": "+",
                },
            ),
            (
                ["-vd", "--video-enabled"],
                {
                    "dest": "is_video_enabled",
                    "action": "store_true",
                    "help": "Indicates that should also try to grab videos",
                },
            ),
            (
                ["-c", "--channel"],
                {
                    "dest": "channel",
                    "type": str,
                    "help": "Optional channel to where posts will be sent to",
                },
            ),
            (
                ["-ti", "--thread-id"],
                {
                    "dest": "thread_id",
                    "type": int,
                    "help": (
                        "Optional Telegram thread id: message_thread_id for topics, "
                        "or channel post id for linked-discussion comments"
                    ),
                    "default": None,
                },
            ),
            (
                ["-x", "--text"],
                {
                    "dest": "text",
                    "type": str,
                    "help": "Send an arbitrary text message to a channel and exit",
                    "default": "",
                },
            ),
            (
                ["-mp", "--max-pages"],
                {
                    "dest": "max_pages",
                    "type": int,
                    "help": "Limit the amount of pages when there's too much",
                    "default": 50,
                },
            ),
        ]

    @ex(hide=True)
    def _default(self) -> None:
        """Default action if no sub-command is passed."""
        nest_asyncio.apply()

        sources: list[str] = self.app.pargs.sources
        folder = self.app.pargs.folder

        final_dest = Path(folder) if folder else folder
        publish = self.app.pargs.publish
        # publish = True
        upload = self.app.pargs.upload
        is_tag = self.app.pargs.is_tag
        limit = self.app.pargs.limit
        version = self.app.pargs.version
        send_to_telegram = self.app.pargs.bot
        send_to_telegram = True
        telegraph_client = Telegraph(access_token=TELEGRAPH_TOKEN)
        show_all_entities = self.app.pargs.show_all_entities
        links_to_bypass: list[str] = self.app.pargs.bypass_link
        is_video_enabled = self.app.pargs.is_video_enabled
        channel = self.app.pargs.channel
        thread_id = self.app.pargs.thread_id
        text = self.app.pargs.text
        max_pages = self.app.pargs.max_pages
        SLEEP_TIME = 5

        if links_to_bypass:
            entity = get_entity(links_to_bypass)
            if entity == "ouo":
                asyncio.run(ouo_bypass(links_to_bypass))
            elif entity == "paster.so":
                paster_ids: list[str] = []
                for paster_link in links_to_bypass:
                    paster_id = paster_link.split("/")[-1]
                    paster_ids.append(paster_id)
                paster_contents = retrieve_paster_contents(paster_ids)

                for content in paster_contents:
                    print(f"{content}\n\n\n")
                return
            else:
                for link in links_to_bypass:
                    try:
                        final_url = bypass_link(link)
                    except Exception:
                        final_url = None

                    if final_url is None:
                        final_url = bypass_ouo(link)

                    print(f"{final_url}")
                return

        if show_all_entities:
            websites = "All websites supported:\n"
            entities = sorted(QUERY_MAPPING.keys())
            for entity in entities:
                websites += f"\t- {entity}\n"

            print(websites)
            return

        if text:
            if sources:
                print("--text mode cannot be combined with --sources.")
                return

            sender = MessageSenderUseCase(TelegramSenderAdapter())
            result = asyncio.run(
                sender.run(
                    SendMessageRequest(
                        post_text=text,
                        channel=channel,
                        thread_id=thread_id,
                    )
                )
            )
            if not result.was_successful:
                print(f"Failed to send text to {channel or '@fans_posting'}")
                return

            print(f"Text sent to {channel or '@fans_posting'}")
            if thread_id is None:
                if result.resolved_thread_ids and result.resolved_thread_ids[0] is not None:
                    print(f"Resolved thread id for reuse: --thread-id {result.resolved_thread_ids[0]}")
                else:
                    print("No thread id was resolved from this send.")
            return

        if version:
            print(VERSION_BANNER)
            return

        if upload:
            asyncio.run(
                upload_folders_to_telegraph(
                    folder_name=final_dest,
                    limit=limit,
                    send_to_channel=send_to_telegram,
                    telegraph_client=telegraph_client,
                )
            )
        else:
            for source_url in sources:
                try:
                    source_entity: str = get_entity([source_url])
                    asyncio.run(
                        SOURCE_DISPATCHER.dispatch(
                            SourceRunRequest(
                                sources=[source_url],
                                entity=source_entity,
                                telegraph_client=telegraph_client,
                                final_dest=final_dest,
                                save_to_telegraph=publish,
                                is_tag=is_tag,
                                limit=limit,
                                is_video_enabled=is_video_enabled,
                                channel=channel,
                                max_pages=max_pages,
                            )
                        )
                    )
                    time.sleep(SLEEP_TIME)
                except Exception as exc:
                    print(f"Failed for source: {source_url}\n\nError: {exc}")
                    continue
