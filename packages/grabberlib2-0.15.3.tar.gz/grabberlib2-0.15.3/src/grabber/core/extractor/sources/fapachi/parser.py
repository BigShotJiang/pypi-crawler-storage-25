import pathlib
from typing import Any, cast
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from unidecode import unidecode

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    base_url = "https://fapachi.com/{model_slug}/page/{page_number}"
    parsed_url = urlparse(url)
    pagination_query = "div.col-12.my-3 a.next-page-btn"
    model_slug = parsed_url.path.replace("/", "")
    page_number = 1
    first_page_url = base_url.format(model_slug=model_slug, page_number=page_number)
    first_page_response = httpx.get(url=first_page_url, headers=headers)
    page_content = first_page_response.content.decode("utf-8")
    soup = BeautifulSoup(page_content, features="lxml")
    has_pagination = soup.select(pagination_query)
    page_urls = [first_page_url]

    if not has_pagination:
        return page_urls

    while has_pagination:
        page_number += 1
        target_url = base_url.format(model_slug=model_slug, page_number=page_number)
        page_urls.append(target_url)
        page_response = httpx.get(url=target_url, headers=headers)
        page_content = page_response.content.decode("utf-8")
        soup = BeautifulSoup(page_content, features="lxml")
        has_pagination = soup.select(pagination_query)

    return page_urls


def get_page_title(soup: BeautifulSoup) -> str:
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
    page_title = page_title.split("nude")[0].replace("https:", "").strip().rstrip()
    return unidecode(
        " ".join(
            f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")
        )
    )


async def get_sources_for_fapachi(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    is_tag: bool | None = False,
    limit: int | None = None,
    **kwargs: Any,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        image_entity=entity,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        is_tag=is_tag,
        limit=limit,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
