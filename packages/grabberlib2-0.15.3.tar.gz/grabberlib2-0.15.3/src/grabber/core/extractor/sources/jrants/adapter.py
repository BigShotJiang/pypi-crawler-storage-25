from typing import Any

from .parser import get_sources_for_jrant


class JrantsAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_jrant(**kwargs)


__all__ = ["JrantsAdapter"]
