import pathlib
from typing import cast

from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    source_urls = [url]
    soup = await get_soup(url, headers=headers)
    count = 2

    while True:
        pagination = soup.select(f":-soup-contains-own('Page {count}')")
        if not pagination:
            break
        next_page = pagination[0]
        target_url = next_page.attrs["href"]
        if target_url in source_urls:
            break
        source_urls.append(target_url)
        soup = await get_soup(target_url, headers=headers)
        count += 1

    return source_urls


def get_page_title(soup: BeautifulSoup) -> str:
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
    page_title = page_title.split("| MasterFap.net")[0].split("Free Onlyfans")[0].replace("https:", "")
    page_title = " ".join(
        list(
            {f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")}
        )
    )
    return f"{page_title} - www.masterfap.net"


async def get_sources_for_masterfap(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
