from typing import Any

from .parser import get_sources_for_cosxuxi


class CosxuxiAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_cosxuxi(**kwargs)


__all__ = ["CosxuxiAdapter"]
