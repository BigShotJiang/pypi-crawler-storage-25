import pathlib
from typing import Any, cast

import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from tqdm import tqdm
from unidecode import unidecode

from grabber.core.extractor.constants import headers_mapping, query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls
from grabber.core.extractor.infrastructure.publishing.telegraph import send_post_to_telegram
from grabber.core.extractor.infrastructure.storage.downloader import run_downloader


async def get_pages_from_pagination(
    url: str,
    headers: dict[str, str],
    query: str = "",
) -> list[Tag]:
    first_page_response = httpx.get(url=url, headers=headers)
    page_content = first_page_response.content.decode("utf-8")
    raw_images = IndexedSet()

    soup = BeautifulSoup(page_content, features="html.parser")
    image_tags = soup.select(query)
    raw_images.update(*[tag for tag in image_tags if ".svg" not in tag.attrs["href"]])

    return list(raw_images)


async def get_sources_for_erome_tv(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: Any,
) -> None:
    tqdm_sources_iterable = tqdm(
        sources,
        total=len(sources),
        desc="Retrieving URLs...",
    )
    query, src_attr = query_mapping[entity]
    headers = headers_mapping[entity] if entity in headers_mapping else headers_mapping["common"]
    page_title = ""
    title_folder_mapping = {}
    posts_sent_counter = 0
    titles = IndexedSet()
    ordered_unique_img_urls = None
    ordered_unique_video_urls = None
    all_sources: list[str] = []
    original_folder_path = final_dest
    channel = kwargs.get("channel", "")

    for source_url in tqdm_sources_iterable:
        final_dest = pathlib.Path(str(original_folder_path)) if final_dest else ""
        all_sources.append(source_url)
        soup = await get_soup(
            target_url=source_url,
            headers=headers,
        )

        image_tags: list[Tag] = await get_pages_from_pagination(
            url=source_url,
            headers=headers,
            query=query,
        )
        print(f"Found {len(image_tags)} images on {source_url}")
        tqdm_sources_iterable.set_description(f"Retrieved {len(image_tags)} images from {source_url}")

        page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
        page_title = (
            page_title.split("new hot")[0]
            .split("Nude")[0]
            .replace("Cosplay", "")
            .replace("Onlyfans", "")
            .replace("Nude", "")
            .strip()
            .rstrip()
        )
        page_title = " ".join(
            f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")
        )
        titles.add(page_title)

        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)
        tqdm_sources_iterable.set_description(f"Finished retrieving images for {page_title}")

        if final_dest:
            final_dest = pathlib.Path(final_dest) / unidecode(f"{page_title} - {entity}")
            if not final_dest.exists():
                final_dest.mkdir(parents=True, exist_ok=True)

            title_folder_mapping[page_title] = (ordered_unique_img_urls, final_dest)

        if save_to_telegraph:
            _ = await send_post_to_telegram(
                ordered_unique_img_urls=ordered_unique_img_urls,
                ordered_unique_video_urls=ordered_unique_video_urls,
                page_title=page_title,
                telegraph_client=telegraph_client,
                posts_sent_counter=posts_sent_counter,
                tqdm_sources_iterable=tqdm_sources_iterable,
                all_sources=all_sources,
                source_url=source_url,
                entity=entity,
                channel=channel,
            )
            page_title = ""

    if final_dest and ordered_unique_img_urls:
        await run_downloader(
            final_dest=final_dest,
            page_title=page_title,
            unique_img_urls=ordered_unique_img_urls,
            titles=titles,
            title_folder_mapping=title_folder_mapping,
            headers=headers,
        )
