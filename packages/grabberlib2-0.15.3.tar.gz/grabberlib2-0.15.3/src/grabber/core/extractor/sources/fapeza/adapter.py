import hashlib
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup


class FapezaAdapter:
    pagination_base_url = "https://fapeza.com/ajax/model/{model_slug}/page-{page_number}/"
    media_item_selector = "div.image-row div.flex-1 a img"

    def __init__(self) -> None:
        self._max_pages: int | None = None

    def configure_max_pages(self, max_pages: int | None) -> None:
        if max_pages is None:
            self._max_pages = None
            return

        self._max_pages = max(1, max_pages)

    def _extract_page_media_keys(self, page_content: str) -> list[str]:
        soup = BeautifulSoup(page_content, features="lxml")
        media_keys: list[str] = []
        for img_tag in soup.select(self.media_item_selector):
            parent_link = img_tag.find_parent("a")
            href = ""
            if parent_link is not None:
                href = str(parent_link.attrs.get("href", "")).strip()
            src = str(img_tag.attrs.get("src", "") or img_tag.attrs.get("data-src", "")).strip()
            media_key = href or src
            if not media_key:
                continue
            media_keys.append(media_key)
        return media_keys

    async def get_pages_from_pagination(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> list[str]:
        parsed_url = urlparse(url)
        model_slug = parsed_url.path.strip("/").split("/")[0]
        if not model_slug:
            return []

        page_number = 1
        source_urls: list[str] = []
        seen_page_fingerprints: set[str] = set()

        while True:
            if self._max_pages is not None and len(source_urls) >= self._max_pages:
                break

            target_url = self.pagination_base_url.format(model_slug=model_slug, page_number=page_number)
            response = httpx.get(url=target_url, headers=headers, timeout=30)
            if response.status_code >= 400:
                break

            page_content = response.text
            if not page_content.strip():
                break

            media_keys = self._extract_page_media_keys(page_content)
            if not media_keys:
                break

            page_fingerprint = hashlib.sha1("\n".join(media_keys).encode("utf-8")).hexdigest()
            if page_fingerprint in seen_page_fingerprints:
                break
            seen_page_fingerprints.add(page_fingerprint)

            source_urls.append(target_url)
            page_number += 1

        return source_urls
