from typing import Any

from .parser import get_sources_for_kemono


class KemonoAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_kemono(**kwargs)


__all__ = ["KemonoAdapter"]
