from __future__ import annotations

import asyncio
from typing import Any

import httpx
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint
from grabber.core.extractor.infrastructure.checkpoints.url_normalizer import hash_media_url
from grabber.core.settings import CHECKPOINT_CONSECUTIVE_SEEN_STOP, LADYSONE_HTTP_PROXY, LADYSONE_HTTPS_PROXY

from .parser import LadysoneParser


class LadysoneAdapter:
    CLOUDFLARE_MARKERS = (
        "Attention Required! | Cloudflare",
        "Sorry, you have been blocked",
        "cf-error-details",
    )

    def build_request_headers(self, profile_url: str, headers: dict[str, str] | None = None) -> dict[str, str]:
        request_headers = dict(headers or {})
        request_headers["Accept"] = "application/json, text/plain, */*"
        request_headers["User-Agent"] = (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
        )
        request_headers["Referer"] = profile_url
        return request_headers

    def build_client_kwargs(self, url: str) -> dict[str, Any]:
        proxy_url = ""
        if url.startswith("https://"):
            proxy_url = LADYSONE_HTTPS_PROXY or LADYSONE_HTTP_PROXY
        elif url.startswith("http://"):
            proxy_url = LADYSONE_HTTP_PROXY

        client_kwargs: dict[str, Any] = {
            "follow_redirects": True,
            "http2": False,
            "timeout": 30.0,
        }
        if proxy_url:
            client_kwargs["proxy"] = proxy_url
        return client_kwargs

    def get_browser_proxy_url(self) -> str:
        return LADYSONE_HTTPS_PROXY or LADYSONE_HTTP_PROXY

    async def get_webdriver(self) -> webdriver.Chrome:
        options = webdriver.ChromeOptions()
        options.add_argument("start-maximized")
        options.add_argument("--headless")
        options.add_argument("--remote-debugging-port=9222")
        options.add_argument(
            "user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
        )
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)

        proxy_url = self.get_browser_proxy_url()
        if proxy_url:
            options.add_argument(f"--proxy-server={proxy_url}")

        executable_path = ChromeDriverManager().install()
        chrome_executable: Service = ChromeService(executable_path=executable_path)
        return webdriver.Chrome(options=options, service=chrome_executable)

    def is_cloudflare_blocked(self, status_code: int, body: str) -> bool:
        if status_code != 403:
            return False
        return any(marker in body for marker in self.CLOUDFLARE_MARKERS)

    def build_cookie_header(self, cookies: list[dict[str, Any]]) -> str:
        parts: list[str] = []
        for cookie in cookies:
            name = str(cookie.get("name", "")).strip()
            value = str(cookie.get("value", "")).strip()
            if name:
                parts.append(f"{name}={value}")
        return "; ".join(parts)

    async def fetch_browser_session(self, profile_url: str) -> tuple[str, str]:
        driver = await self.get_webdriver()
        try:
            driver.get(profile_url)
            await asyncio.sleep(5)
            page_source = driver.page_source
            cookies = driver.get_cookies()
        finally:
            driver.quit()
        return page_source, self.build_cookie_header(cookies)

    def fetch_profile_html(self, source_url: str, headers: dict[str, str] | None = None) -> str:
        with httpx.Client(headers=headers, **self.build_client_kwargs(source_url)) as client:
            response = client.get(source_url)
            response.raise_for_status()
            return str(response.text)

    def fetch_adverts_page(self, endpoint: str, headers: dict[str, str] | None = None) -> dict[str, Any]:
        with httpx.Client(headers=headers, **self.build_client_kwargs(endpoint)) as client:
            response = client.get(endpoint)
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, dict):
                raise TypeError("ladys.one payload must be a JSON object")
            return payload

    async def collect_result(
        self,
        source_url: str,
        headers: dict[str, str] | None,
        max_pages: int,
        parser: LadysoneParser,
        checkpoint_hint: SourceCheckpointHint | None = None,
    ) -> ExtractorResult | None:
        target_ref = parser.parse_target_reference(source_url)
        profile_url = parser.build_profile_page_url(target_ref)
        request_headers = self.build_request_headers(profile_url=profile_url, headers=headers)
        html = ""
        try:
            html = self.fetch_profile_html(source_url=profile_url, headers=request_headers)
        except httpx.HTTPError:
            html = ""

        all_adverts: list[dict[str, Any]] = []
        consecutive_seen = 0
        browser_fallback_used = False

        for page in range(1, max(1, max_pages) + 1):
            endpoint = parser.build_api_endpoint(target_ref, page)
            try:
                payload = self.fetch_adverts_page(endpoint=endpoint, headers=request_headers)
            except httpx.HTTPStatusError as exc:
                response_text = exc.response.text if exc.response is not None else ""
                status_code = exc.response.status_code if exc.response is not None else 0
                if not browser_fallback_used and self.is_cloudflare_blocked(status_code, response_text):
                    browser_html, cookie_header = await self.fetch_browser_session(profile_url=profile_url)
                    browser_fallback_used = True
                    if browser_html:
                        html = browser_html
                    if cookie_header:
                        request_headers["Cookie"] = cookie_header
                    payload = self.fetch_adverts_page(endpoint=endpoint, headers=request_headers)
                else:
                    raise
            page_adverts = parser.extract_advert_list(payload)
            if not page_adverts:
                break

            all_adverts.extend(page_adverts)

            if checkpoint_hint is not None:
                page_image_urls, page_video_urls, _ = parser.extract_media_from_adverts(page_adverts)
                page_media_urls = [*page_image_urls, *page_video_urls]
                if page_media_urls:
                    new_seen_run = 0
                    for media_url in page_media_urls:
                        media_hash = hash_media_url(media_url)
                        if media_hash in checkpoint_hint.seen_hashes:
                            new_seen_run += 1
                            consecutive_seen += 1
                            if consecutive_seen >= CHECKPOINT_CONSECUTIVE_SEEN_STOP:
                                break
                        else:
                            consecutive_seen = 0
                    if consecutive_seen >= CHECKPOINT_CONSECUTIVE_SEEN_STOP:
                        break
                    if new_seen_run == len(page_media_urls):
                        continue

        image_urls, video_urls, author_name = parser.extract_media_from_adverts(all_adverts)
        title = parser.extract_profile_title(
            html=html,
            fallback_slug=target_ref.slug,
            fallback_author=author_name,
        )
        return parser.build_extractor_result(title=title, image_urls=image_urls, video_urls=video_urls)


__all__ = ["LadysoneAdapter"]
