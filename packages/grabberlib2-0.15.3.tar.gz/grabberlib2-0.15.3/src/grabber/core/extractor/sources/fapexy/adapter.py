from typing import Any

from .parser import get_sources_for_fapexy


class FapexyAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fapexy(**kwargs)


__all__ = ["FapexyAdapter"]
