from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup

from grabber.core.extractor import ExtractorResult


@dataclass(frozen=True, slots=True)
class CoomerTargetRef:
    service: str
    creator_id: str
    post_id: str | None = None
    tags: tuple[str, ...] = ()

    @property
    def is_post_target(self) -> bool:
        return self.post_id is not None


class CoomerParser:
    IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".avif")
    VIDEO_EXTENSIONS = (".mp4", ".m4v", ".mov", ".webm", ".mkv", ".avi", ".wmv", ".m3u8")
    PAGE_SIZE = 50
    MEDIA_BASE_URL = "https://n1.coomer.st/data"

    def parse_target_reference(self, source_url: str) -> CoomerTargetRef:
        parsed = urlparse(source_url)
        path_parts = [part for part in parsed.path.split("/") if part]
        if len(path_parts) < 3 or path_parts[1] != "user" or not path_parts[2]:
            raise ValueError(f"Unsupported coomer source URL: {source_url}")

        service = path_parts[0]
        creator_id = path_parts[2]
        post_id: str | None = None
        if len(path_parts) >= 5 and path_parts[3] == "post" and path_parts[4]:
            post_id = path_parts[4]

        parsed_query = parse_qs(parsed.query)
        tags = tuple(tag.strip() for tag in parsed_query.get("tag", []) if str(tag).strip())
        return CoomerTargetRef(service=service, creator_id=creator_id, post_id=post_id, tags=tags)

    def parse_user_reference(self, source_url: str) -> CoomerTargetRef:
        return self.parse_target_reference(source_url)

    def build_posts_endpoint(self, target_ref: CoomerTargetRef, offset: int = 0) -> str:
        endpoint = f"https://coomer.st/api/v1/{target_ref.service}/user/{target_ref.creator_id}/posts"
        query_params: list[tuple[str, str | int]] = [("tag", tag) for tag in target_ref.tags]
        if offset > 0:
            query_params.append(("o", offset))
        if not query_params:
            return endpoint
        return f"{endpoint}?{urlencode(query_params, doseq=True)}"

    def build_post_endpoint(self, target_ref: CoomerTargetRef) -> str:
        if not target_ref.post_id:
            raise ValueError("Direct post endpoint requires a post target")
        return (
            f"https://coomer.st/api/v1/{target_ref.service}/user/{target_ref.creator_id}/post/{target_ref.post_id}"
        )

    def build_profile_endpoint(self, target_ref: CoomerTargetRef) -> str:
        return f"https://coomer.st/api/v1/{target_ref.service}/user/{target_ref.creator_id}/profile"

    def normalize_media_url(self, raw_path: str) -> str | None:
        candidate = str(raw_path).strip()
        if not candidate:
            return None
        if candidate.startswith(("http://", "https://")):
            return candidate
        if candidate.startswith("//"):
            return f"https:{candidate}"
        if candidate.startswith("/"):
            return f"{self.MEDIA_BASE_URL}{candidate}"
        if candidate.startswith("data/"):
            return f"https://n1.coomer.st/{candidate}"
        if candidate.startswith("n1.coomer.st/"):
            return f"https://{candidate}"
        return None

    def normalize_creator_posts_payload(
        self,
        payload: Any,
    ) -> tuple[list[dict[str, Any]], int | None, int | None]:
        if isinstance(payload, list):
            normalized_posts = [post for post in payload if isinstance(post, dict)]
            return normalized_posts, None, None

        if not isinstance(payload, dict):
            return [], None, None

        raw_results = payload.get("results", [])
        results = [post for post in raw_results if isinstance(post, dict)]
        raw_result_attachments = payload.get("result_attachments", [])
        raw_result_previews = payload.get("result_previews", [])
        raw_result_videos = payload.get("videos", [])
        props = payload.get("props", {})
        count = props.get("count") if isinstance(props, dict) else None
        limit = props.get("limit") if isinstance(props, dict) else None

        normalized_posts: list[dict[str, Any]] = []
        for index, post in enumerate(results):
            normalized_post = dict(post)
            normalized_post["wrapped_attachments"] = self._normalize_payload_array(raw_result_attachments, index)
            normalized_post["wrapped_previews"] = self._normalize_payload_array(raw_result_previews, index)
            normalized_post["wrapped_videos"] = self._normalize_payload_array(raw_result_videos, index)
            normalized_posts.append(normalized_post)

        return normalized_posts, self._to_int(count), self._to_int(limit)

    def normalize_direct_post_payload(self, payload: Any) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        if not isinstance(payload, dict):
            return [], None

        post = payload.get("post")
        if not isinstance(post, dict):
            return [], None

        normalized_post = dict(post)
        normalized_post["wrapped_attachments"] = self._coerce_list(payload.get("attachments"))
        normalized_post["wrapped_previews"] = self._coerce_list(payload.get("previews"))
        normalized_post["wrapped_videos"] = self._coerce_list(payload.get("videos"))
        return [normalized_post], normalized_post

    def extract_media_urls(self, posts: list[dict[str, Any]]) -> tuple[list[str], list[str]]:
        image_urls: list[str] = []
        video_urls: list[str] = []
        seen_urls: set[str] = set()

        for post in posts:
            for media_url in self._iter_post_media_urls(post):
                if media_url in seen_urls:
                    continue
                seen_urls.add(media_url)
                if self._is_video_url(media_url):
                    video_urls.append(media_url)
                elif self._is_image_url(media_url):
                    image_urls.append(media_url)

        return image_urls, video_urls

    def build_page_title(
        self,
        source_url: str,
        posts: list[dict[str, Any]],
        profile: dict[str, Any] | None = None,
        direct_post: dict[str, Any] | None = None,
    ) -> str:
        target_ref = self.parse_target_reference(source_url)
        creator_title = self._build_creator_title(profile=profile, target_ref=target_ref)
        if not target_ref.is_post_target:
            return creator_title

        post_title = self._build_direct_post_title(direct_post=direct_post, posts=posts)
        if not post_title:
            return creator_title
        return f"{post_title} {creator_title}".strip()

    def build_extractor_result(
        self,
        source_url: str,
        posts: list[dict[str, Any]],
        profile: dict[str, Any] | None = None,
        direct_post: dict[str, Any] | None = None,
    ) -> ExtractorResult | None:
        image_urls, video_urls = self.extract_media_urls(posts)
        if not image_urls and not video_urls:
            return None

        image_records = IndexedSet(
            (self._build_filename(index, image_url), image_url) for index, image_url in enumerate(image_urls, start=1)
        )
        video_records = IndexedSet(
            (self._build_filename(index, video_url), "", video_url)
            for index, video_url in enumerate(video_urls, start=1)
        )

        return ExtractorResult(
            page_title=self.build_page_title(
                source_url=source_url,
                posts=posts,
                profile=profile,
                direct_post=direct_post,
            ),
            ordered_unique_img_urls=image_records,
            ordered_unique_video_urls=video_records if video_records else None,
        )

    def _iter_post_media_urls(self, post: dict[str, Any]):
        top_level_file = post.get("file")
        if isinstance(top_level_file, dict):
            media_url = self.normalize_media_url(str(top_level_file.get("path", "")))
            if media_url is not None:
                yield media_url

        for list_key in (
            "attachments",
            "wrapped_attachments",
            "wrapped_previews",
            "wrapped_videos",
            "previews",
            "videos",
        ):
            for media_item in self._coerce_list(post.get(list_key)):
                if not isinstance(media_item, dict):
                    continue
                media_url = self.normalize_media_url(str(media_item.get("path", "")))
                if media_url is not None:
                    yield media_url

    def _build_filename(self, index: int, media_url: str) -> str:
        filename = media_url.split("/")[-1].split("?", 1)[0]
        if not filename:
            filename = f"media-{index}"
        return f"{index:04d}-{filename}"

    def _is_image_url(self, media_url: str) -> bool:
        cleaned = media_url.split("?", 1)[0].split("#", 1)[0].lower()
        return cleaned.endswith(self.IMAGE_EXTENSIONS)

    def _is_video_url(self, media_url: str) -> bool:
        cleaned = media_url.split("?", 1)[0].split("#", 1)[0].lower()
        return cleaned.endswith(self.VIDEO_EXTENSIONS)

    def _build_hashtags_from_name(self, profile_name: str) -> str:
        normalized_parts = [
            part.strip().replace(" ", "").replace(".", "_").replace("-", "_")
            for part in profile_name.replace(",", "/").split("/")
            if part.strip()
        ]
        if not normalized_parts:
            return "#coomer"
        return " ".join(f"#{part}" for part in normalized_parts)

    def _build_creator_title(self, profile: dict[str, Any] | None, target_ref: CoomerTargetRef) -> str:
        if isinstance(profile, dict):
            profile_name = str(profile.get("name", "")).strip()
            if profile_name:
                return self._build_hashtags_from_name(profile_name)
        return f"#coomer #{target_ref.service} #user_{target_ref.creator_id}"

    def _build_direct_post_title(
        self,
        direct_post: dict[str, Any] | None,
        posts: list[dict[str, Any]],
    ) -> str:
        post = direct_post or (posts[0] if posts else None)
        if not isinstance(post, dict):
            return ""

        explicit_title = str(post.get("title", "")).strip()
        if explicit_title:
            return explicit_title

        fallback_text = str(post.get("substring", "")).strip()
        if not fallback_text:
            fallback_text = self._strip_html(str(post.get("content", ""))).strip()
        if not fallback_text:
            return ""

        truncated = " ".join(fallback_text.split())
        return truncated[:80].rstrip()

    def _strip_html(self, value: str) -> str:
        if not value:
            return ""
        return BeautifulSoup(value, features="lxml").get_text(" ", strip=True)

    def _normalize_payload_array(self, value: Any, index: int) -> list[dict[str, Any]]:
        items = self._coerce_list(value)
        if not items:
            return []

        if index < len(items):
            indexed_item = items[index]
            if isinstance(indexed_item, list):
                return [item for item in indexed_item if isinstance(item, dict)]
            if isinstance(indexed_item, dict):
                return [indexed_item]

        return []

    def _coerce_list(self, value: Any) -> list[Any]:
        return value if isinstance(value, list) else []

    def _to_int(self, value: Any) -> int | None:
        try:
            return int(value)
        except (TypeError, ValueError):
            return None


__all__ = ["CoomerParser", "CoomerTargetRef"]
