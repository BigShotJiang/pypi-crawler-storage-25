from typing import Any

from .parser import get_sources_for_asiaontop


class AsiaontopAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_asiaontop(**kwargs)


__all__ = ["AsiaontopAdapter"]
