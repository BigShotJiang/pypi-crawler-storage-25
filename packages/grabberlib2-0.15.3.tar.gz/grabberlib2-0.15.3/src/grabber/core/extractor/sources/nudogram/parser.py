from typing import cast

from bs4 import BeautifulSoup, Tag
from unidecode import unidecode

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls


class NudogramParser:
    @staticmethod
    def get_page_title(soup: BeautifulSoup) -> str:
        page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
        page_title = page_title.split("- Nudogram")[0].split("Nude")[0].replace("https:", "")
        return unidecode(
            " ".join(
                f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}"
                for part in page_title.split("/")
            )
        )

    async def parse_result(
        self,
        image_tags: list[Tag],
        soup: BeautifulSoup,
        src_attr: str,
    ) -> ExtractorResult | None:
        if not image_tags:
            return None

        # Preserve website/DOM order so Telegraph chunks match source chronology.
        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)
        if not ordered_unique_img_urls:
            return None

        return ExtractorResult(
            page_title=self.get_page_title(soup),
            ordered_unique_img_urls=ordered_unique_img_urls,
        )
