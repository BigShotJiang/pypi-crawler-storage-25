from typing import Any

from .parser import get_sources_for_nsfw24


class Nsfw247Adapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_nsfw24(**kwargs)


__all__ = ["Nsfw247Adapter"]
