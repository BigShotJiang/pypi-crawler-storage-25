import pathlib
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from lxml import etree
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping, query_pagination_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(
    url: str,
    headers: dict[str, str] | None = None,
) -> list[str]:
    pagination_params = query_pagination_mapping["buondua.com"]
    source_urls = [url]
    soup = await get_soup(url, headers=headers)
    dom = etree.HTML(str(soup))

    for a_tag in dom.xpath(pagination_params.posts_query_xpath):
        page_link = a_tag.attrib["href"]
        source_urls.append(urljoin(url.rsplit("/", 1)[0], page_link))

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-buondua.com"
    return title_tag.get_text(strip=True).split("- Page")[0]


async def get_sources_for_buondua(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        image_entity=entity,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
