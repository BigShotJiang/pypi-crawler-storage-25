from typing import Any

from .parser import get_sources_for_leakedzone


class LeakedzoneAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_leakedzone(**kwargs)


__all__ = ["LeakedzoneAdapter"]
