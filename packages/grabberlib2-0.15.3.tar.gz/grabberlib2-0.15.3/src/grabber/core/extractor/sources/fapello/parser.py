from bs4 import BeautifulSoup, Tag

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls, build_unique_video_urls
from grabber.core.extractor.infrastructure.parsing.title import get_page_title


class FapelloParser:
    @staticmethod
    def build_page_title(soup: BeautifulSoup) -> str:
        return get_page_title(soup=soup, strings_to_remove=["- Fapello", "Nude"])

    async def parse_result(
        self,
        soup: BeautifulSoup,
        image_tags: list[Tag],
        video_tags: list[Tag],
        src_attr: str,
    ) -> ExtractorResult | None:
        # Preserve website/DOM order so Telegraph chunks match source chronology.
        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)
        if not ordered_unique_img_urls:
            return None

        ordered_unique_video_urls = await build_unique_video_urls(video_tags, src_attr)
        return ExtractorResult(
            page_title=self.build_page_title(soup),
            ordered_unique_img_urls=ordered_unique_img_urls,
            ordered_unique_video_urls=ordered_unique_video_urls,
        )
