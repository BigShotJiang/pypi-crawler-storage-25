import pathlib
from urllib.parse import urljoin, urlparse

from boltons.setutils import IndexedSet
from bs4 import Tag
from telegraph import Telegraph

from grabber.core.extractor import DefaultExtractor, ExtractorConfig, ExtractorResult
from grabber.core.extractor.constants import headers_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup, get_tags
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls

SOUP_QUERIES: list[tuple[str, str]] = [
    ("figure.wp-block-image.size-large img", "src"),
    ("div.separator a", "href"),
    ("div.divone div.mainleft img", "src"),
    ("div.divone div.mainleft img", "data-original"),
]


async def get_pages_from_pagination(url: str) -> list[str]:
    parsed_url = urlparse(url)
    base_url = f"https://{parsed_url.netloc}"
    pagination_pages_query = "div.mainleft ul.page-numbers a.page-numbers"
    articles_from_pagination_query = "div.mainleft a"
    next_page_url_base = f"{url}/page/"
    source_urls = IndexedSet()

    first_page = await get_soup(url)
    articles = set(first_page.select(articles_from_pagination_query))
    pages = first_page.select(pagination_pages_query)

    if pages:
        pages_links = set()
        last_page = pages[-2]
        number_last_page = last_page.get_text(strip=True)
        for idx in range(2, int(number_last_page) + 1):
            pages_links.add(f"{next_page_url_base}{idx}")

        for link in pages_links:
            soup = await get_soup(link)
            articles.update(set(soup.select(articles_from_pagination_query)))

    for a_tag in articles:
        if a_tag is not None and a_tag.attrs["href"] not in source_urls:
            source_urls.add(urljoin(base_url, a_tag.attrs["href"]))

    return list(source_urls)


class EveriaExtractor(DefaultExtractor):
    async def extract_source(self, source_url: str) -> ExtractorResult | None:
        image_tags: list[Tag] = []
        soup = None
        src_attr = "src"

        for query, source_attr in SOUP_QUERIES:
            tags, current_soup = await get_tags(source_url, headers=self.headers, query=query)
            soup = current_soup
            if tags:
                image_tags = tags
                src_attr = source_attr
                if self.entity == "www.everiaclub.com":
                    src_attr = "data-original"
                break

        if not image_tags or soup is None:
            return None

        page_title = soup.find("title").get_text(strip=True).split("-")[0].split("– EVERIA.CLUB")[0].strip().rstrip()
        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)
        if not ordered_unique_img_urls:
            return None

        return ExtractorResult(
            page_title=page_title,
            ordered_unique_img_urls=ordered_unique_img_urls,
        )


async def get_sources_for_everia(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    is_tag = kwargs.get("is_tag", False)
    target_sources = list(await get_pages_from_pagination(sources[0])) if is_tag else sources

    config = ExtractorConfig(
        query=SOUP_QUERIES[0][0],
        src_attr=SOUP_QUERIES[0][1],
    )
    extractor = EveriaExtractor(
        sources=target_sources,
        entity=entity,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=bool(save_to_telegraph),
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
        telegraph_client=telegraph_client,
    )

    if entity not in headers_mapping:
        extractor.headers = headers_mapping["common"]

    await extractor.run()
