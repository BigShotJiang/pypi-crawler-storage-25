from typing import Any

from .parser import get_sources_for_ehentai


class EhentaiAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_ehentai(**kwargs)


__all__ = ["EhentaiAdapter"]
