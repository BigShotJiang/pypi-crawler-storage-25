from __future__ import annotations

import asyncio
from collections.abc import Sequence
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import cloudscraper
from tenacity import retry, wait_chain, wait_fixed

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint, hash_media_url, normalize_media_url
from grabber.core.settings import CHECKPOINT_CONSECUTIVE_SEEN_STOP

from .parser import PicazorAlbumParseError, PicazorParser


class PicazorAdapter:
    BASE_URL = "https://picazor.com"
    PROFILE_ENDPOINT = "https://picazor.com/api/files/{slug}/sfiles?page={page_number}"

    def __init__(self, sleep_between_pages: float = 0.5) -> None:
        self.sleep_between_pages = sleep_between_pages

    def fetch_page_text(self, url: str, headers: dict[str, str]) -> str:
        scraper = cloudscraper.create_scraper(interpreter="nodejs")
        response = scraper.get(url=url, headers=headers)
        response.raise_for_status()
        return str(response.text)

    async def fetch_profile_media_pages(
        self,
        slug: str,
        headers: dict[str, str],
        max_pages: int,
        checkpoint_hint: SourceCheckpointHint | None = None,
    ) -> list[dict[str, Any]]:
        all_rows: list[dict[str, Any]] = []
        request_headers = dict(headers)
        seen_hashes = checkpoint_hint.seen_hashes if checkpoint_hint is not None else set()
        consecutive_seen = 0

        for page_number in range(1, max_pages + 1):
            endpoint = self.PROFILE_ENDPOINT.format(slug=slug, page_number=page_number)
            request_headers["Referer"] = f"{self.BASE_URL}/en/{slug}"
            try:
                page_rows = self._fetch_json_page(endpoint, request_headers)
            except Exception:
                if page_number == 1:
                    raise
                break
            if not page_rows:
                break

            if seen_hashes:
                page_urls = [f"{self.BASE_URL}{row.get('path', '')!s}" for row in page_rows if row.get("path")]
                if page_urls and all(hash_media_url(normalize_media_url(url)) in seen_hashes for url in page_urls):
                    consecutive_seen += len(page_urls)
                    if consecutive_seen >= CHECKPOINT_CONSECUTIVE_SEEN_STOP:
                        break
                    continue
                consecutive_seen = 0

            all_rows.extend(page_rows)
            await asyncio.sleep(self.sleep_between_pages)

        return all_rows

    async def collect_result(
        self,
        source_url: str,
        headers: dict[str, str] | None,
        max_pages: int,
        parser: PicazorParser,
        checkpoint_hint: SourceCheckpointHint | None = None,
    ) -> ExtractorResult | None:
        request_headers = dict(headers or {})
        source_ref = parser.parse_source_ref(source_url)
        page_text = self.fetch_page_text(url=source_url, headers=request_headers)

        if source_ref.is_album:
            album_payload = page_text
            try:
                album_items, hinted_title = parser.extract_album_media_from_payload(album_payload)
            except PicazorAlbumParseError:
                rsc_payload = self._fetch_album_rsc_payload(source_url=source_url, headers=request_headers)
                if not rsc_payload:
                    raise
                album_payload = rsc_payload
                album_items, hinted_title = parser.extract_album_media_from_payload(album_payload)
            except Exception as exc:
                raise PicazorAlbumParseError(f"Failed parsing album payload for URL: {source_url}") from exc

            if not album_items:
                raise PicazorAlbumParseError(f"No album media found in payload for URL: {source_url}")

            title = parser.build_album_title(
                album_page_html=page_text,
                hinted_title=hinted_title,
                source_ref=source_ref,
                items=album_items,
            )
            result = parser.build_extractor_result(title=title, items=album_items)
            if result is None:
                raise PicazorAlbumParseError(f"No visible album media found for URL: {source_url}")
            return result

        profile_rows = await self.fetch_profile_media_pages(
            slug=source_ref.slug,
            headers=request_headers,
            max_pages=max_pages,
            checkpoint_hint=checkpoint_hint,
        )
        profile_items = parser.build_media_items_from_profile_rows(profile_rows)
        title = parser.extract_title(page_text, fallback_slug=source_ref.slug)
        return parser.build_extractor_result(title=title, items=profile_items)

    @retry(
        wait=wait_chain(
            *[wait_fixed(2) for _ in range(3)] + [wait_fixed(5) for _ in range(3)] + [wait_fixed(8)],
        ),
        reraise=True,
    )
    def _fetch_json_page(self, url: str, headers: dict[str, str]) -> list[dict[str, Any]]:
        scraper = cloudscraper.create_scraper(interpreter="nodejs")
        response = scraper.get(url=url, headers=headers)
        response.raise_for_status()

        payload = response.json()
        if not isinstance(payload, Sequence):
            raise ValueError(f"Expected list payload from {url}, got {type(payload).__name__}")

        rows: list[dict[str, Any]] = []
        for item in payload:
            if isinstance(item, dict):
                rows.append(item)

        return rows

    def _fetch_album_rsc_payload(self, source_url: str, headers: dict[str, str]) -> str | None:
        parsed = urlparse(source_url)
        query_items = [(key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True) if key != "_rsc"]
        query_items.append(("_rsc", "1"))
        rsc_url = urlunparse(parsed._replace(query=urlencode(query_items)))

        request_headers = dict(headers)
        request_headers.setdefault("RSC", "1")
        request_headers.setdefault("Accept", "text/x-component, */*;q=0.1")
        try:
            return self.fetch_page_text(url=rsc_url, headers=request_headers)
        except Exception:
            return None


__all__ = ["PicazorAdapter"]
