import asyncio
import logging
import pathlib
from typing import Any, cast

from boltons.setutils import IndexedSet
from bs4 import Tag
from telegraph import Telegraph
from tqdm import tqdm
from unidecode import unidecode

from grabber.core.extractor.constants import headers_mapping, query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_tags
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls, build_unique_video_urls
from grabber.core.extractor.infrastructure.publishing import send_videos_to_channel
from grabber.core.extractor.infrastructure.publishing.telegraph import send_post_to_telegram
from grabber.core.extractor.infrastructure.storage.downloader import run_downloader

logger = logging.getLogger(__name__)


async def get_for_telegraph(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: dict[str, Any],
) -> None:
    tqdm_sources_iterable = tqdm(
        sources,
        total=len(sources),
        desc="Retrieving URLs...",
    )
    query, src_attr = query_mapping[entity]
    headers = headers_mapping.get(entity, None)
    page_title = ""
    title_folder_mapping = {}
    posts_sent_counter = 0
    titles = IndexedSet()
    failed_sources: list[str] = []
    ordered_unique_img_urls = None
    all_sources: list[str] = []
    original_folder_path = final_dest
    channel = kwargs.get("channel", "")

    for source_url in tqdm_sources_iterable:
        final_dest = pathlib.Path(str(original_folder_path)) if final_dest else ""
        all_sources.append(source_url)

        image_tags, soup = await get_tags(
            source_url,
            headers=headers,
            query=query,
        )

        video_query = "video"
        video_tags, soup = await get_tags(
            source_url,
            headers=headers,
            query=video_query,
        )

        page_title = (
            cast(Tag, soup.find("title"))
            .get_text(strip=True)
            .split("– Telegraph")[0]
            .split("- Telegraph")[0]
            .strip()
            .rstrip()
        )
        page_title = " ".join(
            list(
                {
                    f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}"
                    for part in page_title.split("/")
                }
            )
        )
        titles.add(page_title)

        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)
        ordered_unique_video_urls = await build_unique_video_urls(video_tags, src_attr="src")
        tqdm_sources_iterable.set_description(f"Finished retrieving media for {page_title}")

        if ordered_unique_video_urls and channel:
            _ = await send_videos_to_channel(
                channel=channel,
                page_title=page_title,
                source_url=source_url,
                ordered_unique_video_urls=ordered_unique_video_urls,
                headers=headers,
                tqdm_iterable=tqdm_sources_iterable,
            )
        elif ordered_unique_video_urls and not channel:
            logger.warning(
                "telegra.ph page has videos but no --channel provided; skipping video send source=%s",
                source_url,
            )

        if final_dest:
            final_dest = pathlib.Path(final_dest) / unidecode(f"{page_title} - {entity}")
            if not final_dest.exists():
                final_dest.mkdir(parents=True, exist_ok=True)

            title_folder_mapping[page_title] = (ordered_unique_img_urls, final_dest)

        if save_to_telegraph:
            _ = await send_post_to_telegram(
                ordered_unique_img_urls=ordered_unique_img_urls,
                ordered_unique_video_urls=None,
                page_title=page_title,
                telegraph_client=telegraph_client,
                posts_sent_counter=posts_sent_counter,
                tqdm_sources_iterable=tqdm_sources_iterable,
                all_sources=all_sources,
                source_url=source_url,
                entity=entity,
                channel=channel,
            )
            await asyncio.sleep(5)
        page_title = ""

    if final_dest and ordered_unique_img_urls:
        await run_downloader(
            final_dest=final_dest,
            page_title=page_title,
            unique_img_urls=ordered_unique_img_urls,
            titles=titles,
            title_folder_mapping=title_folder_mapping,
            headers=headers,
        )

    if failed_sources:
        print("Failed sources:")
        for source in failed_sources:
            print(source)
