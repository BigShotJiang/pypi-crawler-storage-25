from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup

from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint, hash_media_url, normalize_media_url
from grabber.core.settings import CHECKPOINT_CONSECUTIVE_SEEN_STOP


class FaponicAdapter:
    pagination_base_url = "https://faponic.com/ajax/model/{model_slug}/page-{page_number}/"

    def __init__(self) -> None:
        self._checkpoint_hint: SourceCheckpointHint | None = None

    def configure_checkpoint_hint(self, checkpoint_hint: SourceCheckpointHint | None) -> None:
        self._checkpoint_hint = checkpoint_hint

    async def get_pages_from_pagination(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> list[str]:
        parsed_url = urlparse(url)
        model_slug = parsed_url.path.replace("/", "")
        page_number = 1
        source_urls: list[str] = []
        seen_hashes = self._checkpoint_hint.seen_hashes if self._checkpoint_hint is not None else set()
        consecutive_seen = 0

        while True:
            target_url = self.pagination_base_url.format(model_slug=model_slug, page_number=page_number)
            page_response = httpx.get(url=target_url, headers=headers)
            page_content = page_response.content.decode("utf-8")
            if not page_content.strip():
                break

            if seen_hashes:
                soup = BeautifulSoup(page_content, features="lxml")
                candidate_urls = []
                for image_tag in soup.select("img"):
                    img_src = image_tag.attrs.get("src") or image_tag.attrs.get("data-src")
                    if not img_src:
                        continue
                    if not img_src.startswith("http"):
                        img_src = f"https://faponic.com{img_src}"
                    candidate_urls.append(img_src)

                if candidate_urls and all(
                    hash_media_url(normalize_media_url(candidate_url)) in seen_hashes
                    for candidate_url in candidate_urls
                ):
                    consecutive_seen += len(candidate_urls)
                    if consecutive_seen >= CHECKPOINT_CONSECUTIVE_SEEN_STOP:
                        break
                    page_number += 1
                    continue
                consecutive_seen = 0

            source_urls.append(target_url)
            page_number += 1

        return source_urls
