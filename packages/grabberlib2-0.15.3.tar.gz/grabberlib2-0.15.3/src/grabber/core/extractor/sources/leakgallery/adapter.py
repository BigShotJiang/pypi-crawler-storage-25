from typing import Any

from .parser import get_sources_for_leakgallery


class LeakgalleryAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_leakgallery(**kwargs)


__all__ = ["LeakgalleryAdapter"]
