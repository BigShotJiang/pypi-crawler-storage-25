from typing import Any

from .parser import get_sources_for_hotgirl_china


class HotgirlChinaAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_hotgirl_china(**kwargs)


__all__ = ["HotgirlChinaAdapter"]
