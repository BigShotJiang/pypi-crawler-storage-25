import pathlib

from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_images_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "div#pagination ul.pagination li a"
    soup = await get_soup(url, headers=headers)
    source_urls = [url]
    pagination_set = soup.select(pagination_query)

    if not pagination_set:
        return source_urls

    first_page_number = int(pagination_set[0].get_text(strip=True))
    last_page_number = int(pagination_set[-1].get_text(strip=True))
    base_url, *_ = url.rsplit("?", 2)

    for index in range(first_page_number, last_page_number + 1):
        if index == 1:
            continue
        source_urls.append(f"{base_url}/?num={index}&stype=showall")

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-hotgirl.asia"
    return title_tag.get_text(separator=" ", strip=True).split("- Share")[0].rstrip()


async def get_sources_for_hotgirl_asia(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_images_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
