from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from unidecode import unidecode

from grabber.core.extractor import ExtractorResult


class WildskirtsParser:
    MEDIA_EXTENSIONS = (
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
        ".webp",
        ".bmp",
        ".avif",
        ".mp4",
        ".m4v",
        ".mov",
        ".webm",
        ".mkv",
        ".avi",
        ".wmv",
        ".m3u8",
    )
    CELEB_ID_PATTERN = re.compile(r'data-celeb\s*=\s*["\']?(\d+)["\']?')

    def extract_celeb_id(self, html: str) -> str:
        soup = BeautifulSoup(html, features="lxml")
        celeb_button = soup.select_one("button.like-btn[data-celeb]")
        if celeb_button is not None:
            celeb_id = str(celeb_button.attrs.get("data-celeb", "")).strip()
            if celeb_id.isdigit():
                return celeb_id

        regex_match = self.CELEB_ID_PATTERN.search(html)
        if regex_match:
            return regex_match.group(1)

        raise ValueError("Could not find data-celeb ID in Wildskirts page HTML")

    def extract_page_title(self, html: str, source_url: str) -> str:
        soup = BeautifulSoup(html, features="lxml")
        title_tag = soup.select_one("title")
        if title_tag is not None:
            raw_title = title_tag.get_text(strip=True)
        else:
            raw_title = urlparse(source_url).path.strip("/") or "wildskirts"

        for splitter in (" - Wildskirts", " - WildSkirts", "| Wildskirts", "| WildSkirts"):
            raw_title = raw_title.split(splitter)[0]

        normalized_title = unidecode(raw_title).strip()
        if not normalized_title:
            normalized_title = urlparse(source_url).path.strip("/") or "wildskirts"

        parts = [part.strip() for part in normalized_title.replace(",", "/").split("/") if part.strip()]
        hashtags = [f"#{part.replace(' ', '').replace('.', '_').replace('-', '_')}" for part in parts]
        if not hashtags:
            hashtags = ["#wildskirts"]
        return " ".join(hashtags)

    def extract_media_urls(self, payload: object, source_url: str = "https://wildskirts.com") -> list[str]:
        seen = set()
        media_urls: list[str] = []

        def visit(value: object) -> None:
            if isinstance(value, str):
                candidate = self._normalize_url(value, source_url=source_url)
                if candidate and self._is_media_url(candidate) and candidate not in seen:
                    seen.add(candidate)
                    media_urls.append(candidate)
                return

            if isinstance(value, list):
                for item in value:
                    visit(item)
                return

            if isinstance(value, dict):
                for item in value.values():
                    visit(item)

        visit(payload)
        return media_urls

    def build_extractor_result(self, page_title: str, media_urls: list[str]) -> ExtractorResult | None:
        image_records: IndexedSet = IndexedSet()
        video_records: IndexedSet = IndexedSet()

        for index, media_url in enumerate(media_urls, start=1):
            filename = self._build_filename(media_url, index)
            if self._is_video_url(media_url):
                video_records.add((filename, media_url))
            else:
                image_records.add((filename, media_url))

        if not image_records and not video_records:
            return None

        return ExtractorResult(
            page_title=page_title,
            ordered_unique_img_urls=image_records,
            ordered_unique_video_urls=video_records if video_records else None,
        )

    def _normalize_url(self, value: str, source_url: str) -> str | None:
        if value.startswith("http://") or value.startswith("https://"):
            return value
        if value.startswith("//"):
            return f"https:{value}"
        if value.startswith("/"):
            return urljoin(source_url, value)
        return None

    def _is_media_url(self, url: str) -> bool:
        cleaned_url = url.split("?", 1)[0].split("#", 1)[0].lower()
        return cleaned_url.endswith(self.MEDIA_EXTENSIONS)

    def _is_video_url(self, url: str) -> bool:
        cleaned_url = url.split("?", 1)[0].split("#", 1)[0].lower()
        return cleaned_url.endswith((".mp4", ".m4v", ".mov", ".webm", ".mkv", ".avi", ".wmv", ".m3u8"))

    def _build_filename(self, url: str, index: int) -> str:
        parsed = urlparse(url)
        name = parsed.path.rsplit("/", 1)[-1]
        if not name:
            name = f"media-{index}"
        return f"{index:04d}-{name}"
