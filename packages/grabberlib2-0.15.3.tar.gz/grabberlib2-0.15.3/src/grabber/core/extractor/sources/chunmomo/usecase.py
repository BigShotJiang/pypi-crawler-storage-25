import pathlib

from telegraph import Telegraph

from grabber.core.extractor.usecases import SourceRunRequest, SourceUseCase

from .adapter import ChunmomoAdapter


class ChunmomoUseCase(SourceUseCase):
    def __init__(
        self,
        adapter: ChunmomoAdapter | None = None,
    ) -> None:
        self.adapter = adapter or ChunmomoAdapter()

    async def run(self, request: SourceRunRequest) -> None:
        await self.adapter.run(**request.as_kwargs())


async def get_sources_for_chunmomo(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: object,
) -> None:
    usecase = ChunmomoUseCase()
    await usecase.run(
        SourceRunRequest(
            sources=sources,
            entity=entity,
            telegraph_client=telegraph_client,
            final_dest=final_dest,
            save_to_telegraph=bool(save_to_telegraph),
            is_tag=bool(kwargs.get("is_tag", False)),
            limit=kwargs.get("limit"),  # type: ignore[arg-type]
            is_video_enabled=bool(kwargs.get("is_video_enabled", False)),
            channel=str(kwargs.get("channel", "")),
            max_pages=int(kwargs.get("max_pages", 50)),
            checkpoint_hint=kwargs.get("checkpoint_hint"),  # type: ignore[arg-type]
        )
    )


__all__ = ["ChunmomoUseCase", "get_sources_for_chunmomo"]
