import pathlib

from telegraph import Telegraph

from grabber.core.extractor import DefaultExtractor, ExtractorConfig, ExtractorResult
from grabber.core.extractor.constants import QUERY_MAPPING
from grabber.core.extractor.infrastructure.fetching.scraper import get_tags
from grabber.core.extractor.usecases import SourceRunRequest, SourceUseCase

from .adapter import FapomaniaAdapter
from .parser import FapomaniaParser


class FapomaniaExtractor(DefaultExtractor):
    def __init__(
        self,
        *args,
        adapter: FapomaniaAdapter,
        parser: FapomaniaParser,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.adapter = adapter
        self.parser = parser

    async def extract_source(self, source_url: str) -> ExtractorResult | None:
        ordered_unique_img_urls = await self.adapter.get_all_images_tags(
            url=source_url,
            headers=self.headers,
            query=self.config.query,
        )
        if not ordered_unique_img_urls:
            return None

        _, soup = await get_tags(
            source_url,
            headers=self.headers,
            query=self.config.query,
        )
        return await self.parser.parse_result(
            soup=soup,
            ordered_unique_img_urls=ordered_unique_img_urls,
        )


class FapomaniaUseCase(SourceUseCase):
    def __init__(
        self,
        adapter: FapomaniaAdapter | None = None,
        parser: FapomaniaParser | None = None,
    ) -> None:
        self.adapter = adapter or FapomaniaAdapter()
        self.parser = parser or FapomaniaParser()

    async def run(self, request: SourceRunRequest) -> None:
        query, src_attr = QUERY_MAPPING[request.entity]
        config = ExtractorConfig(
            query=query,
            src_attr=src_attr,
        )
        extractor = FapomaniaExtractor(
            sources=request.sources,
            entity=request.entity,
            config=config,
            final_dest=request.final_dest,
            is_tag=False,
            limit=request.limit,
            save_to_telegraph=request.save_to_telegraph,
            channel=request.channel,
            max_pages=request.max_pages,
            telegraph_client=request.telegraph_client,
            checkpoint_hint=request.checkpoint_hint,
            adapter=self.adapter,
            parser=self.parser,
        )
        await extractor.run()


async def get_sources_for_fapomania(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: object,
) -> None:
    usecase = FapomaniaUseCase()
    await usecase.run(
        SourceRunRequest(
            sources=sources,
            entity=entity,
            telegraph_client=telegraph_client,
            final_dest=final_dest,
            save_to_telegraph=bool(save_to_telegraph),
            is_tag=bool(kwargs.get("is_tag", False)),
            limit=kwargs.get("limit"),  # type: ignore[arg-type]
            is_video_enabled=bool(kwargs.get("is_video_enabled", False)),
            channel=str(kwargs.get("channel", "")),
            max_pages=int(kwargs.get("max_pages", 50)),
            checkpoint_hint=kwargs.get("checkpoint_hint"),  # type: ignore[arg-type]
        )
    )


__all__ = ["FapomaniaAdapter", "FapomaniaParser", "FapomaniaUseCase", "get_sources_for_fapomania"]
