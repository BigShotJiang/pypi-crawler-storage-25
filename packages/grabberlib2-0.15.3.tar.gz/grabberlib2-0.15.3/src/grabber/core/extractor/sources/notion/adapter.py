from typing import Any

from .parser import get_sources_for_notion


class NotionAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_notion(**kwargs)


__all__ = ["NotionAdapter"]
