from typing import Any

from .parser import get_sources_for_spacemiss


class SpacemissAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_spacemiss(**kwargs)


__all__ = ["SpacemissAdapter"]
