import pathlib
import re
from typing import cast
from urllib.parse import urlparse

import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from unidecode import unidecode
from url_parser import parse_url

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.usecases import run_default_source

NUMBERS_PATTERN = r"\d+(?:,\d+)*"
THEFAPNET_IMAGE_CHECK_TIMEOUT_SECONDS = 12
THEFAPNET_ALLOWED_IMAGE_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".avif",
    ".bmp",
    ".gif",
}
THEFAPNET_IMAGE_CHECK_HEADERS = {
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Referer": "https://thefap.net/",
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    ),
}


def _extract_media_url(record: tuple[str, ...]) -> str | None:
    if not record:
        return None
    media_url = record[-1].strip()
    return media_url if media_url else None


def _is_supported_image_url(media_url: str) -> bool:
    parsed = urlparse(media_url)
    if parsed.scheme not in {"http", "https"}:
        return False
    if not parsed.netloc:
        return False
    path = parsed.path.strip().lower()
    if not path:
        return False
    return any(path.endswith(extension) for extension in THEFAPNET_ALLOWED_IMAGE_EXTENSIONS)


def _classify_content_type(content_type: str) -> bool | None:
    normalized = content_type.split(";")[0].strip().lower()
    if not normalized:
        return None
    if normalized.startswith("image/"):
        return True
    if normalized in {"text/html", "text/plain", "application/json", "application/javascript"}:
        return False
    return None


def _classify_with_head(client: httpx.Client, media_url: str) -> bool | None:
    response = client.head(media_url, headers=THEFAPNET_IMAGE_CHECK_HEADERS)
    if response.status_code >= 400:
        return False
    content_type = response.headers.get("Content-Type", "")
    classified = _classify_content_type(content_type)
    if classified is not None:
        return classified
    if response.status_code in {405, 501}:
        return None
    return None


def _classify_with_get(client: httpx.Client, media_url: str) -> bool | None:
    probe_headers = {**THEFAPNET_IMAGE_CHECK_HEADERS, "Range": "bytes=0-1024"}
    with client.stream("GET", media_url, headers=probe_headers) as response:
        if response.status_code >= 400:
            return False
        content_type = response.headers.get("Content-Type", "")
        classified = _classify_content_type(content_type)
        if classified is not None:
            return classified
        return None


def _is_usable_image_url(client: httpx.Client, media_url: str) -> bool | None:
    try:
        head_result = _classify_with_head(client, media_url)
    except Exception:
        head_result = None
    if head_result is not None:
        return head_result

    try:
        return _classify_with_get(client, media_url)
    except Exception:
        return None


def filter_unreachable_image_urls(ordered_unique_img_urls: IndexedSet) -> IndexedSet:
    if not ordered_unique_img_urls:
        return ordered_unique_img_urls

    filtered_urls = IndexedSet()
    with httpx.Client(timeout=THEFAPNET_IMAGE_CHECK_TIMEOUT_SECONDS, follow_redirects=True) as client:
        for media_record in ordered_unique_img_urls:
            media_url = _extract_media_url(media_record)
            if not media_url:
                continue
            if not _is_supported_image_url(media_url):
                continue
            is_usable = _is_usable_image_url(client, media_url)
            if is_usable is not True:
                continue
            filtered_urls.add(media_record)
    return filtered_urls


async def get_pages_from_pagination(
    url: str,
    headers: dict[str, str] | None = None,
) -> list[str]:
    query, _ = query_mapping["thefap.net"]
    parsed_url = parse_url(url)
    model_id = parsed_url["path"].replace("/", "").split("-")[-1]
    source_urls = []
    page_number = 1

    while True:
        target_url = f"https://thefap.net/ajax/model/{model_id}/page-{page_number}"
        page_response = httpx.get(url=target_url, headers=headers)
        page_content = page_response.content.decode("utf-8")
        if not page_content.strip():
            break
        soup = BeautifulSoup(page_content, features="html.parser")
        image_tags = [tag for tag in soup.select(query) if "icon" not in tag.attrs.get("src", "")]
        if not image_tags:
            break
        source_urls.append(target_url)
        page_number += 1

    return source_urls


def get_page_title(soup: BeautifulSoup) -> str:
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
    page_title = (
        page_title.split("Nude")[0].split("Leaks")[0].split("OnlyFans")[0].replace("https:", "").strip().rstrip()
    )
    page_title = re.sub(NUMBERS_PATTERN, "", page_title).strip()
    return unidecode(
        " ".join(
            f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")
        )
    )


async def get_sources_for_the_fap_net(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
        image_urls_post_processor=filter_unreachable_image_urls,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 500),
    )
