from __future__ import annotations

from typing import Any

import httpx

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint

from .parser import WildskirtsParser


class WildskirtsAdapter:
    MEDIA_ENDPOINT = "https://api.wildskirts.com/api/media/{celeb_id}"

    def fetch_page_html(self, source_url: str, headers: dict[str, str] | None = None) -> str:
        response = httpx.get(url=source_url, headers=headers, follow_redirects=True)
        response.raise_for_status()
        return str(response.text)

    def fetch_media_payload(self, celeb_id: str, headers: dict[str, str] | None = None) -> Any:
        media_url = self.MEDIA_ENDPOINT.format(celeb_id=celeb_id)
        request_headers = dict(headers or {})
        request_headers.setdefault("Accept", "application/json")
        response = httpx.get(url=media_url, headers=request_headers, follow_redirects=True)
        response.raise_for_status()
        return response.json()

    async def collect_result(
        self,
        source_url: str,
        headers: dict[str, str] | None,
        parser: WildskirtsParser,
        checkpoint_hint: SourceCheckpointHint | None = None,
    ) -> ExtractorResult | None:
        _ = checkpoint_hint
        page_html = self.fetch_page_html(source_url=source_url, headers=headers)
        celeb_id = parser.extract_celeb_id(page_html)
        media_payload = self.fetch_media_payload(celeb_id=celeb_id, headers=headers)
        media_urls = parser.extract_media_urls(media_payload, source_url=source_url)
        page_title = parser.extract_page_title(page_html, source_url=source_url)
        return parser.build_extractor_result(page_title=page_title, media_urls=media_urls)


__all__ = ["WildskirtsAdapter"]
