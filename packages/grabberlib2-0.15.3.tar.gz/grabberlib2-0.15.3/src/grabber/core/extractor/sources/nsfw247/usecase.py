import pathlib

from telegraph import Telegraph

from grabber.core.extractor.usecases import SourceRunRequest, SourceUseCase

from .adapter import Nsfw247Adapter


class Nsfw247UseCase(SourceUseCase):
    def __init__(
        self,
        adapter: Nsfw247Adapter | None = None,
    ) -> None:
        self.adapter = adapter or Nsfw247Adapter()

    async def run(self, request: SourceRunRequest) -> None:
        await self.adapter.run(**request.as_kwargs())


async def get_sources_for_nsfw24(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: object,
) -> None:
    usecase = Nsfw247UseCase()
    await usecase.run(
        SourceRunRequest(
            sources=sources,
            entity=entity,
            telegraph_client=telegraph_client,
            final_dest=final_dest,
            save_to_telegraph=bool(save_to_telegraph),
            is_tag=bool(kwargs.get("is_tag", False)),
            limit=kwargs.get("limit"),  # type: ignore[arg-type]
            is_video_enabled=bool(kwargs.get("is_video_enabled", False)),
            channel=str(kwargs.get("channel", "")),
            max_pages=int(kwargs.get("max_pages", 50)),
            checkpoint_hint=kwargs.get("checkpoint_hint"),  # type: ignore[arg-type]
        )
    )


__all__ = ["Nsfw247UseCase", "get_sources_for_nsfw24"]
