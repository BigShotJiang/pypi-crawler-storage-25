import pathlib

import telegraph

from grabber.core.extractor.usecases import run_default_source


async def get_sources_for_xiuren(
    sources: list[str],
    entity: str,
    telegraph_client: telegraph.Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    is_tag: bool | None = False,
    limit: int | None = None,
    **kwargs,
) -> None:
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        is_tag=is_tag,
        limit=limit,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
        tag_pagination_target="xiuren",
    )
