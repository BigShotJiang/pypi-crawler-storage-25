import pathlib

from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import QUERY_MAPPING
from grabber.core.extractor.usecases import (
    DefaultSourceRunner,
    DefaultSourceRunRequest,
    SourceRunRequest,
    SourceUseCase,
)

from .adapter import KupAdapter
from .parser import KupParser


class KupUseCase(SourceUseCase):
    def __init__(
        self,
        adapter: KupAdapter | None = None,
        parser: KupParser | None = None,
        runner: DefaultSourceRunner | None = None,
    ) -> None:
        self.adapter = adapter or KupAdapter()
        self.parser = parser or KupParser()
        self.runner = runner or DefaultSourceRunner()

    async def run(self, request: SourceRunRequest) -> None:
        query, src_attr = QUERY_MAPPING[request.entity]
        config = ExtractorConfig(
            query=query,
            src_attr=src_attr,
            pagination_fetcher=self.adapter.get_images_from_pagination,
            title_factory=self.parser.get_page_title,
        )
        await self.runner.run(
            DefaultSourceRunRequest(
                sources=request.sources,
                entity=request.entity,
                telegraph_client=request.telegraph_client,
                config=config,
                final_dest=request.final_dest,
                save_to_telegraph=request.save_to_telegraph,
                is_tag=request.is_tag,
                limit=request.limit,
                channel=request.channel,
                max_pages=request.max_pages,
                checkpoint_hint=request.checkpoint_hint,
            )
        )


async def get_sources_for_4kup(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: object,
) -> None:
    usecase = KupUseCase()
    await usecase.run(
        SourceRunRequest(
            sources=sources,
            entity=entity,
            telegraph_client=telegraph_client,
            final_dest=final_dest,
            save_to_telegraph=bool(save_to_telegraph),
            is_tag=bool(kwargs.get("is_tag", False)),
            limit=kwargs.get("limit"),  # type: ignore[arg-type]
            is_video_enabled=bool(kwargs.get("is_video_enabled", False)),
            channel=str(kwargs.get("channel", "")),
            max_pages=int(kwargs.get("max_pages", 50)),
            checkpoint_hint=kwargs.get("checkpoint_hint"),  # type: ignore[arg-type]
        )
    )


__all__ = ["KupAdapter", "KupParser", "KupUseCase", "get_sources_for_4kup"]
