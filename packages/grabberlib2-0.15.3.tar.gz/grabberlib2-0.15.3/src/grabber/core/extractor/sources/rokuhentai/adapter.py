from typing import Any

from .parser import get_sources_for_rokuhentai


class RokuhentaiAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_rokuhentai(**kwargs)


__all__ = ["RokuhentaiAdapter"]
