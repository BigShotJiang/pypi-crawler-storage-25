from typing import Any

from .parser import get_sources_for_nudostar


class NudostarAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_nudostar(**kwargs)


__all__ = ["NudostarAdapter"]
