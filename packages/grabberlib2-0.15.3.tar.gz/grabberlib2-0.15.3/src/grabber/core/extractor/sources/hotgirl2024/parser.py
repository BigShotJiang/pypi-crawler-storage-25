import pathlib

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_images_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "div.pagination.center span.pagination__count span.pagination__total"
    first_page_query = "div.pagination.center span.pagination__count span.pagination__item.pagination__item--active"

    source_urls = [url]
    soup = await get_soup(url, headers=headers)
    first_page_tag = soup.select_one(first_page_query)
    last_page_tag = soup.select_one(pagination_query)

    if first_page_tag is None or last_page_tag is None:
        return source_urls

    first_page_number = int(first_page_tag.get_text(strip=True))
    last_page_number = int(last_page_tag.get_text(strip=True))
    for index in range(first_page_number, last_page_number + 1):
        if index == 1:
            continue
        source_urls.append(f"{url}?page={index}")

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-www.hotgirl2024.com"
    return title_tag.get_text(strip=True).split("| Page")[0].strip().rstrip()


def with_hotgirl2024_prefix(ordered_unique_img_urls: IndexedSet) -> IndexedSet:
    prefixed_urls = IndexedSet()
    image_src_prefix = "https://www.hotgirl2024.com"
    for image_name, image_link in ordered_unique_img_urls:
        prefixed_urls.add((image_name, f"{image_src_prefix}{image_link}"))
    return prefixed_urls


async def get_sources_for_hotgirl2024(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_images_from_pagination,
        title_factory=get_page_title,
        image_urls_post_processor=with_hotgirl2024_prefix,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
