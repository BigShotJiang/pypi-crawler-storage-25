from typing import Any

from .parser import get_sources_for_ugirls


class UgirlsAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_ugirls(**kwargs)


__all__ = ["UgirlsAdapter"]
