from typing import Any

from .parser import get_sources_for_xmissy


class XmissyAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_xmissy(**kwargs)


__all__ = ["XmissyAdapter"]
