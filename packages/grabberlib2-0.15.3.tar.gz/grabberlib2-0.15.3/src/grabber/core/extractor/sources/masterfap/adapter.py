from typing import Any

from .parser import get_sources_for_masterfap


class MasterfapAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_masterfap(**kwargs)


__all__ = ["MasterfapAdapter"]
