from __future__ import annotations

import json
from typing import Any

import httpx

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint

from .parser import CoomerParser


class CoomerAdapter:
    def __init__(self, max_pages: int = 50) -> None:
        self.max_pages = max_pages

    def configure_max_pages(self, max_pages: int) -> None:
        self.max_pages = max(1, max_pages)

    def fetch_posts_page(self, endpoint: str, headers: dict[str, str] | None = None) -> Any:
        request_headers = dict(headers or {})
        request_headers["Accept"] = "text/css"
        response = httpx.get(url=endpoint, headers=request_headers, follow_redirects=True)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                return []
            raise
        return response.json()

    def fetch_post(self, endpoint: str, headers: dict[str, str] | None = None) -> dict[str, Any] | None:
        request_headers = dict(headers or {})
        request_headers["Accept"] = "text/css"
        response = httpx.get(url=endpoint, headers=request_headers, follow_redirects=True)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                return None
            raise
        payload = response.json()
        return payload if isinstance(payload, dict) else None

    def fetch_profile(self, endpoint: str, headers: dict[str, str] | None = None) -> dict[str, Any] | None:
        request_headers = dict(headers or {})
        request_headers["Accept"] = "text/css"
        response = httpx.get(url=endpoint, headers=request_headers, follow_redirects=True)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                return None
            raise
        payload = response.json()
        return payload if isinstance(payload, dict) else None

    async def collect_result(
        self,
        source_url: str,
        headers: dict[str, str] | None,
        parser: CoomerParser,
        max_pages: int | None = None,
        checkpoint_hint: SourceCheckpointHint | None = None,
    ) -> ExtractorResult | None:
        _ = checkpoint_hint
        effective_max_pages = max(1, max_pages if max_pages is not None else self.max_pages)
        target_ref = parser.parse_target_reference(source_url)

        profile = None
        try:
            profile = self.fetch_profile(endpoint=parser.build_profile_endpoint(target_ref), headers=headers)
        except httpx.HTTPError:
            profile = None

        if target_ref.is_post_target:
            direct_post_payload = self.fetch_post(endpoint=parser.build_post_endpoint(target_ref), headers=headers)
            if direct_post_payload is None:
                return None
            direct_posts, direct_post = parser.normalize_direct_post_payload(direct_post_payload)
            return parser.build_extractor_result(
                source_url=source_url,
                posts=direct_posts,
                profile=profile,
                direct_post=direct_post,
            )

        collected_posts: list[dict[str, Any]] = []
        seen_post_ids: set[str] = set()
        seen_page_fingerprints: set[str] = set()
        seen_media_urls: set[str] = set()

        for page_index in range(effective_max_pages):
            endpoint = parser.build_posts_endpoint(target_ref, offset=page_index * parser.PAGE_SIZE)
            payload = self.fetch_posts_page(endpoint=endpoint, headers=headers)
            if not payload:
                break

            page_fingerprint = json.dumps(payload, sort_keys=True, default=str)
            if page_fingerprint in seen_page_fingerprints:
                break
            seen_page_fingerprints.add(page_fingerprint)

            page_posts, total_count, page_limit = parser.normalize_creator_posts_payload(payload)
            if not page_posts:
                break

            filtered_page_posts: list[dict[str, Any]] = []
            for post in page_posts:
                post_id = str(post.get("id", ""))
                if post_id and post_id in seen_post_ids:
                    continue
                if post_id:
                    seen_post_ids.add(post_id)
                filtered_page_posts.append(post)

            if not filtered_page_posts:
                break

            page_image_urls, page_video_urls = parser.extract_media_urls(filtered_page_posts)
            if not page_image_urls and not page_video_urls:
                break

            page_media_urls = [*page_image_urls, *page_video_urls]
            new_media_urls = [media_url for media_url in page_media_urls if media_url not in seen_media_urls]
            if not new_media_urls:
                break

            seen_media_urls.update(new_media_urls)
            collected_posts.extend(filtered_page_posts)

            if total_count is not None and page_limit is not None:
                if (page_index + 1) * max(1, page_limit) >= total_count:
                    break

        return parser.build_extractor_result(source_url=source_url, posts=collected_posts, profile=profile)


__all__ = ["CoomerAdapter"]
