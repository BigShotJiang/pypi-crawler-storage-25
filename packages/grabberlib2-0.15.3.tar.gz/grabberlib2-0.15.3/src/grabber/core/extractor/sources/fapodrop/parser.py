import pathlib
from typing import cast
from urllib.parse import urljoin, urlparse

import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from url_parser import parse_url

from grabber.core.extractor import ExtractorConfig, ExtractorResult
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def collect_from_fapodrop(
    source_url: str,
    headers: dict[str, str] | None = None,
) -> ExtractorResult | None:
    query = "div.row div.one-pack a img"
    first_page_response = httpx.get(url=source_url, headers=headers)
    page_content = first_page_response.content.decode("utf-8")
    raw_images = IndexedSet()
    image_links = IndexedSet()
    parsed_url = urlparse(source_url)
    base_url = f"https://{parsed_url.netloc}"

    while page_content:
        soup = BeautifulSoup(page_content, features="html.parser")
        image_tags = soup.select(query)
        raw_images.update(*[tag for tag in image_tags if ".svg" not in tag.attrs["src"]])

        pagination = soup.select(":-soup-contains-own('Next page')")
        if not pagination:
            break

        next_page = pagination[0]
        target_url = urljoin(base_url, next_page.attrs["href"])
        try:
            page_response = httpx.get(url=target_url, headers=headers)
        except Exception as exc:
            print(f"Error when requesting {target_url}: {exc}")
            break
        page_content = page_response.content.decode("utf-8")

    for idx, image_tag in enumerate(raw_images):
        image_src = image_tag.attrs["src"]
        final_image_src = urljoin(base_url, image_src.replace("_thumbnail", "").replace("/thumbnails/", "/photo/"))
        parsed_image_url = parse_url(final_image_src)
        image_prefix = f"{idx + 1}".zfill(4)
        image_filename = parsed_image_url["file"]
        image_links.add((image_prefix, f"{image_prefix}-{image_filename}", f"{image_filename}", final_image_src))

    ordered_unique_img_urls = IndexedSet([a[1:] for a in image_links])
    if not ordered_unique_img_urls:
        return None

    source_soup = await get_soup(target_url=source_url, headers=headers)
    page_title = cast(Tag, source_soup.find("title")).get_text(strip=True).strip().rstrip()
    page_title = page_title.split("leaks from OnlyFans")[0].split("Nude")[0].replace("https:", "")
    page_title = " ".join(
        list(
            {f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")}
        )
    )

    return ExtractorResult(
        page_title=page_title,
        ordered_unique_img_urls=ordered_unique_img_urls,
    )


async def get_sources_for_fapodrop(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    config = ExtractorConfig(
        query="",
        src_attr="src",
        result_collector=collect_from_fapodrop,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
