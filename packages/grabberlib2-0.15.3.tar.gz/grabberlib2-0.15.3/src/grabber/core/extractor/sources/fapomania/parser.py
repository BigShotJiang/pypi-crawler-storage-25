from typing import cast

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from unidecode import unidecode

from grabber.core.extractor import ExtractorResult


class FapomaniaParser:
    @staticmethod
    def get_page_title(soup: BeautifulSoup) -> str:
        page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
        page_title = page_title.split("- Fapomania")[0].split("Nude")[0].replace("https:", "")
        return unidecode(
            " ".join(
                f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}"
                for part in page_title.split("/")
            )
        )

    async def parse_result(
        self,
        soup: BeautifulSoup,
        ordered_unique_img_urls: IndexedSet,
    ) -> ExtractorResult | None:
        if not ordered_unique_img_urls:
            return None
        return ExtractorResult(
            page_title=self.get_page_title(soup),
            ordered_unique_img_urls=ordered_unique_img_urls,
        )
