from typing import Any

from .parser import get_sources_for_celebcx


class CelebCxAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_celebcx(**kwargs)


__all__ = ["CelebCxAdapter"]
