from bs4 import Tag

from grabber.core.extractor.infrastructure.fetching.scraper import get_tags


class KupAdapter:
    page_nav_query = "div.page-link-box li a.page-numbers"

    async def get_images_from_pagination(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> list[str]:
        tags, _ = await get_tags(url, headers=headers, query=self.page_nav_query)
        return [tag.attrs["href"] for tag in tags if isinstance(tag, Tag)]
