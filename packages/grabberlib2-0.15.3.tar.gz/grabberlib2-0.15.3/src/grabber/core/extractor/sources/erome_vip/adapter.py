from typing import Any

from .parser import get_sources_for_erome_vip


class EromeVipAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_erome_vip(**kwargs)


__all__ = ["EromeVipAdapter"]
