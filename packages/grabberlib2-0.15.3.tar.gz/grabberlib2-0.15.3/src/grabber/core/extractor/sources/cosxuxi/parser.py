import pathlib
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from telegraph import Telegraph
from url_parser import get_base_url

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_images_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "div.pag ul.pagination-site li.page-numbers a.page-numbers"
    base_url = get_base_url(url)
    soup = await get_soup(url, headers=headers)
    source_urls = [url]

    for a_tag in soup.select(pagination_query):
        href = a_tag.attrs.get("href", "")
        if not href:
            continue
        target_url = href if href.startswith("http") else urljoin(base_url, href)
        source_urls.append(target_url)

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-cosxuxi.club"
    return title_tag.get_text(strip=True).split("| Page")[0].strip().rstrip()


async def get_sources_for_cosxuxi(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_images_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
