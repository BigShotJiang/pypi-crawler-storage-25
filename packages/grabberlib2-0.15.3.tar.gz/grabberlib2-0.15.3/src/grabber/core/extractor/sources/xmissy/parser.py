import pathlib
from typing import cast

from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.usecases import run_default_source


def get_page_title(soup: BeautifulSoup) -> str:
    return cast(Tag, soup.find("title")).get_text(strip=True).split("| xMissy")[0].strip().rstrip()


async def get_sources_for_xmissy(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    config = ExtractorConfig(
        query="div#gallery div.noclick-image img",
        src_attr="src",
        secondary_src_attr="data-src",
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
