import pathlib
import re
from typing import cast

from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from unidecode import unidecode

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source

NUMBERS_PATTERN = r"\d+(?:,\d+)*"


async def get_pages_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    source_urls = [url]
    next_page_url = url

    while True:
        soup = await get_soup(next_page_url, headers=headers)
        pagination = soup.select(":-soup-contains-own('Next Page')")
        if not pagination:
            break
        next_page_url = pagination[0].attrs["href"]
        if next_page_url in source_urls:
            break
        source_urls.append(next_page_url)

    return source_urls


def get_page_title(soup: BeautifulSoup) -> str:
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
    page_title = (
        page_title.split("Leaked Files")[0]
        .split("- Fapello.su")[0]
        .split("LeakedOnlyFansFiles")[0]
        .replace("https:", "")
    )
    page_title = re.sub(NUMBERS_PATTERN, "", page_title).strip()
    return unidecode(
        " ".join(
            f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")
        )
    )


async def get_sources_for_fapello_su(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=f"div#content div {query}",
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 500),
    )
