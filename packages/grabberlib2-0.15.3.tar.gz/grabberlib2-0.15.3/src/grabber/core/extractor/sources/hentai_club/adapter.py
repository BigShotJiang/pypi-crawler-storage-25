from typing import Any

from .parser import get_sources_for_hentai_club


class HentaiClubAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_hentai_club(**kwargs)


__all__ = ["HentaiClubAdapter"]
