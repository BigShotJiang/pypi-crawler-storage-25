from typing import Any

from .parser import get_sources_for_asianviralhub


class AsianviralhubAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_asianviralhub(**kwargs)


__all__ = ["AsianviralhubAdapter"]
