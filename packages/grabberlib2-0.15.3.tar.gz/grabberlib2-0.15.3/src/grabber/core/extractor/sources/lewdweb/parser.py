import pathlib

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_images_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "nav.pageNavWrapper.pageNavWrapper--mixed div.pageNav ul.pageNav-main li.pageNav-page a"
    first_page_query = (
        "nav.pageNavWrapper.pageNavWrapper--mixed div.pageNav ul.pageNav-main li.pageNav-page.pageNav-page--current a"
    )

    source_urls = [url]
    soup = await get_soup(url, headers=headers)
    pagination_set = soup.select(pagination_query)
    first_page = soup.select(first_page_query)

    if not pagination_set or not first_page:
        return source_urls

    first_page_number = int(first_page[0].get_text(strip=True))
    last_page_number = int(pagination_set[-1].get_text(strip=True))

    for index in range(first_page_number, last_page_number + 1):
        if index == 1:
            continue
        source_urls.append(f"{url}/page-{index}")

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-forum.lewdweb.net"
    return title_tag.get_text(strip=True).split("| LewdWeb Forum")[0].strip().rstrip()


def with_lewdweb_prefix(ordered_unique_img_urls: IndexedSet) -> IndexedSet:
    prefixed_urls = IndexedSet()
    for image_name, image_link in ordered_unique_img_urls:
        prefixed_urls.add((image_name, f"https://forum.lewdweb.net/{image_link}"))
    return prefixed_urls


async def get_sources_for_lewdweb(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_images_from_pagination,
        title_factory=get_page_title,
        image_urls_post_processor=with_lewdweb_prefix,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
