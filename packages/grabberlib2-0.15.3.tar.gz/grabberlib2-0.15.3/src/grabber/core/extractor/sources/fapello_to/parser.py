import pathlib
from typing import Any, cast

import httpx
from boltons.setutils import IndexedSet
from bs4 import Tag
from telegraph import Telegraph
from url_parser import parse_url

from grabber.core.extractor import ExtractorConfig, ExtractorResult
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def collect_from_fapello_to(
    source_url: str,
    headers: dict[str, str] | None = None,
) -> ExtractorResult | None:
    if headers is None:
        headers = {}

    request_headers = dict(headers)
    request_headers.update({"Referer": source_url})
    parsed_url = parse_url(source_url)
    model_id = parsed_url["file"]
    base_url = "https://fapello.to//api/media/{model_id}/{page_number}/1"

    page_number = 1
    images_tags = IndexedSet()
    while True:
        endpoint = base_url.format(model_id=model_id, page_number=page_number)
        response = httpx.get(url=endpoint, headers=request_headers)
        response_data: list[dict[str, Any]] = response.json()
        if not response_data:
            break
        for idx, data in enumerate(response_data):
            image_url = data["newUrl"]
            parsed_image_url = parse_url(image_url)
            image_prefix = f"{idx + 1}".zfill(4)
            image_filename = parsed_image_url["file"]
            images_tags.add((image_prefix, f"{image_prefix}-{image_filename}", f"{image_filename}", image_url))
        page_number += 1

    ordered_unique_img_urls = IndexedSet([a[1:] for a in images_tags])
    if not ordered_unique_img_urls:
        return None

    soup = await get_soup(target_url=source_url, headers=request_headers)
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
    page_title = page_title.split("- fapello")[0].split("Nude")[0].replace("https:", "")
    page_title = " ".join(
        list(
            {f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")}
        )
    )

    return ExtractorResult(
        page_title=page_title,
        ordered_unique_img_urls=ordered_unique_img_urls,
    )


async def get_sources_for_fapello_to(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    config = ExtractorConfig(
        query="",
        src_attr="src",
        result_collector=collect_from_fapello_to,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
