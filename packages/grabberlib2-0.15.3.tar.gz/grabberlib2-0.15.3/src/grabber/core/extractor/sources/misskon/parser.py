import pathlib
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "div.page-link a.post-page-numbers"
    first_page_query = "div.page-link span.post-page-numbers.current"

    source_urls = [url]
    soup = await get_soup(url, headers=headers)
    pagination_set = soup.select(pagination_query)

    if not pagination_set:
        return source_urls

    first_page_tag = soup.select_one(first_page_query)
    first_page_number = int(first_page_tag.get_text(strip=True)) if first_page_tag else 1

    pages: list[int] = []
    for a_tag in pagination_set:
        text = a_tag.get_text(strip=True)
        if text.isdigit():
            pages.append(int(text))
    last_page_number = max(pages) if pages else first_page_number

    for index in range(first_page_number, last_page_number + 1):
        if index == 1:
            continue
        source_urls.append(urljoin(url, f"{index}/"))

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-misskon.com"
    return title_tag.get_text(strip=True).split(" – MissKon.com")[0].split("– Page")[0].strip()


async def get_sources_for_misskon(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
