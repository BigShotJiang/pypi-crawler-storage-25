from typing import Any

from .parser import get_sources_for_xlust


class XlustAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_xlust(**kwargs)


__all__ = ["XlustAdapter"]
