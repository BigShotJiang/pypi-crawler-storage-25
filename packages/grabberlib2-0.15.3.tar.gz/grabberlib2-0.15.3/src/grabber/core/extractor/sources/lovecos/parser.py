import pathlib

from ada_url import replace_url
from bs4 import BeautifulSoup
from telegraph import Telegraph
from url_parser import get_base_url, get_url

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "div.page a"
    images_pages_query = "div.mimg div.mtp li a"
    parsed_url = get_url(url)
    base_url = get_base_url(url)

    source_urls = []
    soup = await get_soup(url, headers=headers)

    for image_tag in soup.select(images_pages_query):
        href = image_tag.attrs["href"]
        source_urls.append(replace_url(url, pathname=href))

    for a_tag in soup.select(pagination_query):
        href = a_tag.attrs.get("href", "")
        if not href:
            continue
        target_url = f"{base_url}{parsed_url.dir}{href}"
        page_soup = await get_soup(target_url, headers=headers)
        for image_tag in page_soup.select(images_pages_query):
            image_href = image_tag.attrs["href"]
            source_urls.append(replace_url(target_url, pathname=image_href))

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-www.lovecos.net"
    return (
        title_tag.get_text(strip=True)
        .split(",www.lovecos.net")[0]
        .split(",  www.lovecos.net")[0]
        .split(",")[0]
        .strip()
        .rstrip()
    )


async def get_sources_for_lovecos(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
