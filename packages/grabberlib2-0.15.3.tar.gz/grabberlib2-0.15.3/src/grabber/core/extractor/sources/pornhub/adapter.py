from __future__ import annotations

import html
import json
import pathlib
import re
import tempfile
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

import aiofiles
import httpx

TELEGRAM_UPLOAD_LIMIT_BYTES = 50 * 1024 * 1024
PORNHUB_HTTP_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    ),
}
VIDEO_URL_PATTERN = re.compile(r'"videoUrl"\s*:\s*"([^"]+)"', flags=re.IGNORECASE)
DIRECT_MP4_PATTERN = re.compile(r"https?:\\?/\\?/[^\"'\\s<>]+?\\.mp4(?:\\?[^\"'\\s<>]*)?", flags=re.IGNORECASE)
JSON_MEDIA_URL_PATTERN = re.compile(r"https?:\\?/\\?/[^\"'\\s<>]+?\\.json(?:\\?[^\"'\\s<>]*)?", flags=re.IGNORECASE)
TITLE_PATTERN = re.compile(r"<title[^>]*>(.*?)</title>", flags=re.IGNORECASE | re.DOTALL)
UPLOADER_PATTERN = re.compile(r'"author"\s*:\s*\{\s*"@type"\s*:\s*"Person"\s*,\s*"name"\s*:\s*"([^"]+)"')
VIEWKEY_PATTERN = re.compile(r"viewkey=([a-zA-Z0-9]+)")


@dataclass(slots=True)
class PornhubDownloadResult:
    source_url: str
    video_page_title: str
    uploader: str | None
    direct_url: str | None
    temp_file_path: pathlib.Path | None
    estimated_size_bytes: int | None
    viewkey: str
    should_fallback_to_link: bool


class PornhubAdapter:
    async def resolve_video(
        self,
        source_url: str,
        cookies_file_path: pathlib.Path,
        filename_prefix: str,
        viewkey: str,
    ) -> PornhubDownloadResult:
        metadata = self._extract_metadata(source_url=source_url, cookies_file_path=cookies_file_path)
        title = str(metadata.get("title", "")).strip() or "Pornhub video"
        uploader = self._extract_uploader(metadata)
        selected_format = self._select_format(metadata)
        if selected_format is None:
            raise RuntimeError("No downloadable video formats found for Pornhub URL")

        direct_url = self._extract_format_url(selected_format)
        estimated_size_bytes = self._extract_estimated_size_bytes(selected_format)
        if direct_url is None:
            raise RuntimeError("Selected Pornhub format does not include a direct URL")

        should_fallback_to_link = bool(
            estimated_size_bytes is not None and estimated_size_bytes > TELEGRAM_UPLOAD_LIMIT_BYTES
        )
        if should_fallback_to_link:
            return PornhubDownloadResult(
                source_url=source_url,
                video_page_title=title,
                uploader=uploader,
                direct_url=direct_url,
                temp_file_path=None,
                estimated_size_bytes=estimated_size_bytes,
                viewkey=viewkey,
                should_fallback_to_link=True,
            )

        temp_file_path = await self._download_format_to_temp_file(
            direct_url=direct_url,
            filename_prefix=filename_prefix,
        )
        downloaded_size = temp_file_path.stat().st_size if temp_file_path.exists() else estimated_size_bytes
        fallback_after_download = bool(downloaded_size is not None and downloaded_size > TELEGRAM_UPLOAD_LIMIT_BYTES)
        if fallback_after_download:
            try:
                temp_file_path.unlink(missing_ok=True)
                parent = temp_file_path.parent
                if parent.exists():
                    parent.rmdir()
            except Exception:
                pass
            temp_file_path = None

        return PornhubDownloadResult(
            source_url=source_url,
            video_page_title=title,
            uploader=uploader,
            direct_url=direct_url,
            temp_file_path=temp_file_path,
            estimated_size_bytes=downloaded_size,
            viewkey=viewkey,
            should_fallback_to_link=fallback_after_download,
        )

    def _extract_metadata(self, source_url: str, cookies_file_path: pathlib.Path) -> dict[str, Any]:
        ytdlp_error: Exception | None = None
        try:
            return self._extract_metadata_with_ytdlp(source_url=source_url, cookies_file_path=cookies_file_path)
        except Exception as exc:
            ytdlp_error = exc

        fallback_metadata = self._extract_metadata_from_html(source_url=source_url, cookies_file_path=cookies_file_path)
        if fallback_metadata is not None:
            return fallback_metadata

        viewkey = self._extract_viewkey(source_url)
        if viewkey:
            embed_metadata = self._extract_metadata_from_embed(
                viewkey=viewkey,
                source_url=source_url,
                cookies_file_path=cookies_file_path,
            )
            if embed_metadata is not None:
                return embed_metadata

        if ytdlp_error is not None:
            raise RuntimeError(f"yt_dlp failed and HTML fallbacks produced no media: {ytdlp_error}") from ytdlp_error
        raise RuntimeError("Could not extract Pornhub metadata")

    def _extract_viewkey(self, source_url: str) -> str | None:
        parsed = urlparse(source_url)
        query_values = parse_qs(parsed.query)
        viewkey = (query_values.get("viewkey") or [""])[0].strip()
        if viewkey:
            return viewkey

        match = VIEWKEY_PATTERN.search(source_url)
        if not match:
            return None
        return match.group(1).strip()

    def _extract_metadata_from_embed(
        self,
        viewkey: str,
        source_url: str,
        cookies_file_path: pathlib.Path,
    ) -> dict[str, Any] | None:
        embed_url = f"https://www.pornhub.com/embed/{viewkey}"
        html_text = self._fetch_url_text_with_cookies(
            target_url=embed_url,
            cookies_file_path=cookies_file_path,
            referer=source_url,
        )
        return self._build_metadata_from_html_payload(
            html_text=html_text,
            cookies_file_path=cookies_file_path,
            referer_url=embed_url,
            fallback_title=f"Pornhub video {viewkey}",
        )

    def _extract_metadata_with_ytdlp(self, source_url: str, cookies_file_path: pathlib.Path) -> dict[str, Any]:
        try:
            from yt_dlp import YoutubeDL
        except Exception as exc:
            raise RuntimeError("yt_dlp is required to process Pornhub sources") from exc

        options = {
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "skip_download": True,
            "cookiefile": cookies_file_path.as_posix(),
            "restrictfilenames": True,
        }
        with YoutubeDL(options) as ydl:
            metadata = ydl.extract_info(source_url, download=False)

        if metadata is None:
            raise RuntimeError("yt_dlp could not extract metadata for Pornhub URL")

        if isinstance(metadata, dict) and metadata.get("entries"):
            entries = metadata.get("entries") or []
            first = next((entry for entry in entries if isinstance(entry, dict)), None)
            if first is None:
                raise RuntimeError("Pornhub URL resolved to empty playlist/entries")
            metadata = first

        if not isinstance(metadata, dict):
            raise RuntimeError("Unexpected metadata payload from yt_dlp for Pornhub URL")
        return metadata

    def _extract_metadata_from_html(self, source_url: str, cookies_file_path: pathlib.Path) -> dict[str, Any] | None:
        html_text = self._fetch_source_page_html(source_url=source_url, cookies_file_path=cookies_file_path)
        return self._build_metadata_from_html_payload(
            html_text=html_text,
            cookies_file_path=cookies_file_path,
            referer_url=source_url,
            fallback_title="Pornhub video",
        )

    def _build_metadata_from_html_payload(
        self,
        html_text: str,
        cookies_file_path: pathlib.Path,
        referer_url: str,
        fallback_title: str,
    ) -> dict[str, Any] | None:
        if not html_text.strip():
            return None

        candidate_urls = self._extract_candidate_media_urls_from_html(html_text)
        media_urls = self._resolve_candidate_media_urls(
            candidate_urls=candidate_urls,
            cookies_file_path=cookies_file_path,
            referer_url=referer_url,
        )
        if not media_urls:
            return None

        page_title = self._extract_page_title(html_text) or fallback_title
        uploader = self._extract_uploader_from_html(html_text)
        formats = [
            {
                "format_id": f"html-{index}",
                "url": media_url,
                "height": self._extract_quality_from_url(media_url),
                "protocol": "https" if media_url.startswith("https://") else "http",
            }
            for index, media_url in enumerate(media_urls, start=1)
        ]
        return {
            "title": page_title,
            "uploader": uploader,
            "formats": formats,
        }

    def _fetch_source_page_html(self, source_url: str, cookies_file_path: pathlib.Path) -> str:
        return self._fetch_url_text_with_cookies(
            target_url=source_url,
            cookies_file_path=cookies_file_path,
            referer="https://www.pornhub.com/",
        )

    def _fetch_url_text_with_cookies(
        self,
        target_url: str,
        cookies_file_path: pathlib.Path,
        referer: str | None = None,
    ) -> str:
        cookies = self._load_pornhub_cookies(cookies_file_path)
        timeout = httpx.Timeout(connect=20, read=40, write=20, pool=20)
        headers = dict(PORNHUB_HTTP_HEADERS)
        if referer:
            headers["Referer"] = referer
        with httpx.Client(timeout=timeout, follow_redirects=True, headers=headers, cookies=cookies) as client:
            response = client.get(target_url)
            response.raise_for_status()
            return response.text

    def _load_pornhub_cookies(self, cookies_file_path: pathlib.Path) -> dict[str, str]:
        cookies: dict[str, str] = {}
        for raw_line in cookies_file_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = raw_line.split("\t")
            if len(parts) < 7:
                continue
            domain = parts[0].strip()
            cookie_name = parts[5].strip()
            cookie_value = parts[6].strip()
            if not cookie_name or not cookie_value:
                continue
            if "pornhub.com" not in domain:
                continue
            cookies[cookie_name] = cookie_value
        return cookies

    def _extract_candidate_media_urls_from_html(self, html_text: str) -> list[str]:
        raw_matches = list(VIDEO_URL_PATTERN.findall(html_text))
        raw_matches.extend(DIRECT_MP4_PATTERN.findall(html_text))
        raw_matches.extend(JSON_MEDIA_URL_PATTERN.findall(html_text))

        ordered_urls: list[str] = []
        seen_urls: set[str] = set()
        for raw_url in raw_matches:
            decoded_url = self._decode_embedded_url(raw_url)
            if not decoded_url:
                continue
            if decoded_url in seen_urls:
                continue
            seen_urls.add(decoded_url)
            ordered_urls.append(decoded_url)
        return ordered_urls

    def _resolve_candidate_media_urls(
        self,
        candidate_urls: list[str],
        cookies_file_path: pathlib.Path,
        referer_url: str,
    ) -> list[str]:
        resolved_urls: list[str] = []
        seen_mp4_urls: set[str] = set()
        pending_urls = list(candidate_urls)
        visited_json_urls: set[str] = set()

        while pending_urls:
            candidate_url = self._decode_embedded_url(pending_urls.pop(0))
            if not candidate_url:
                continue

            lowered = candidate_url.lower()
            if ".mp4" in lowered:
                if candidate_url in seen_mp4_urls:
                    continue
                seen_mp4_urls.add(candidate_url)
                resolved_urls.append(candidate_url)
                continue

            is_json_like = ".json" in lowered or "get_media" in lowered
            if not is_json_like or candidate_url in visited_json_urls:
                continue
            visited_json_urls.add(candidate_url)

            try:
                payload_text = self._fetch_url_text_with_cookies(
                    target_url=candidate_url,
                    cookies_file_path=cookies_file_path,
                    referer=referer_url,
                )
            except Exception:
                continue

            try:
                parsed_payload = json.loads(payload_text)
            except Exception:
                pending_urls.extend(self._extract_candidate_media_urls_from_html(payload_text))
                continue

            if isinstance(parsed_payload, list):
                for item in parsed_payload:
                    if not isinstance(item, dict):
                        continue
                    video_url = str(item.get("videoUrl", "")).strip()
                    if video_url:
                        pending_urls.append(video_url)
            elif isinstance(parsed_payload, dict):
                video_url = str(parsed_payload.get("videoUrl", "")).strip()
                if video_url:
                    pending_urls.append(video_url)

        return resolved_urls

    def _extract_media_urls_from_html(self, html_text: str) -> list[str]:
        candidate_urls = self._extract_candidate_media_urls_from_html(html_text)
        return [url for url in candidate_urls if ".mp4" in url.lower()]

    @staticmethod
    def _decode_embedded_url(raw_url: str) -> str:
        decoded = raw_url.strip().strip('"').strip("'")
        decoded = decoded.replace("\\/", "/").replace("\\u002F", "/").replace("\\u0026", "&")
        decoded = html.unescape(decoded)
        decoded = unquote(decoded)
        decoded = decoded.replace("\\", "")
        if decoded.startswith("//"):
            decoded = f"https:{decoded}"
        return decoded

    @staticmethod
    def _extract_page_title(html_text: str) -> str | None:
        match = TITLE_PATTERN.search(html_text)
        if not match:
            return None
        raw_title = html.unescape(match.group(1)).strip()
        if not raw_title:
            return None
        return raw_title.split("|")[0].strip()

    @staticmethod
    def _extract_uploader_from_html(html_text: str) -> str | None:
        match = UPLOADER_PATTERN.search(html_text)
        if not match:
            return None
        uploader = html.unescape(match.group(1)).strip()
        return uploader or None

    @staticmethod
    def _extract_quality_from_url(media_url: str) -> int:
        parsed = urlparse(media_url)
        query = parse_qs(parsed.query)
        query_quality = query.get("quality", [""])[0]
        if query_quality.isdigit():
            quality = int(query_quality)
            if 144 <= quality <= 4320:
                return quality

        candidates = re.findall(r"(?<!\d)(\d{3,4})(?:p|P)?(?!\d)", media_url)
        for candidate in reversed(candidates):
            value = int(candidate)
            if 144 <= value <= 4320:
                return value
        return 0

    @staticmethod
    def _extract_uploader(metadata: dict[str, Any]) -> str | None:
        for key in ("uploader", "channel", "creator"):
            value = metadata.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return None

    def _select_format(self, metadata: dict[str, Any]) -> dict[str, Any] | None:
        raw_formats = metadata.get("formats")
        if not isinstance(raw_formats, list):
            return None

        candidates: list[dict[str, Any]] = []
        for item in raw_formats:
            if not isinstance(item, dict):
                continue
            direct_url = self._extract_format_url(item)
            if not direct_url:
                continue
            if str(item.get("vcodec", "")).lower() == "none":
                continue
            protocol = str(item.get("protocol", "")).lower()
            if protocol and protocol not in {"http", "https"}:
                continue
            candidates.append(item)

        if not candidates:
            return None

        under_limit = [
            item
            for item in candidates
            if (size := self._extract_estimated_size_bytes(item)) is not None and size <= TELEGRAM_UPLOAD_LIMIT_BYTES
        ]
        if under_limit:
            return max(under_limit, key=self._quality_sort_key)

        unknown_size = [item for item in candidates if self._extract_estimated_size_bytes(item) is None]
        if unknown_size:
            return max(unknown_size, key=self._quality_sort_key)

        return max(candidates, key=self._quality_sort_key)

    @staticmethod
    def _quality_sort_key(item: dict[str, Any]) -> tuple[float, float, float]:
        height = float(item.get("height") or 0)
        tbr = float(item.get("tbr") or 0)
        fps = float(item.get("fps") or 0)
        return height, tbr, fps

    @staticmethod
    def _extract_estimated_size_bytes(item: dict[str, Any]) -> int | None:
        for key in ("filesize", "filesize_approx"):
            value = item.get(key)
            if isinstance(value, (int, float)) and value > 0:
                return int(value)
        return None

    @staticmethod
    def _extract_format_url(item: dict[str, Any]) -> str | None:
        for key in ("url",):
            value = item.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return None

    async def _download_format_to_temp_file(
        self,
        direct_url: str,
        filename_prefix: str,
    ) -> pathlib.Path:
        temp_dir = pathlib.Path(tempfile.mkdtemp(prefix="grabber-pornhub-"))
        target_path = temp_dir / filename_prefix
        timeout = httpx.Timeout(connect=30, read=120, write=60, pool=60)
        client = httpx.AsyncClient(timeout=timeout, follow_redirects=True)
        try:
            async with client.stream("GET", direct_url) as response:
                response.raise_for_status()
                async with aiofiles.open(target_path, "wb") as f:
                    async for chunk in response.aiter_bytes(chunk_size=1024 * 1024):
                        if chunk:
                            await f.write(chunk)
        finally:
            await client.aclose()

        return target_path


__all__ = ["TELEGRAM_UPLOAD_LIMIT_BYTES", "PornhubAdapter", "PornhubDownloadResult"]
