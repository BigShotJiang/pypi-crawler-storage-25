from typing import Any

from .parser import get_sources_for_hotgirl_asia


class HotgirlAsiaAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_hotgirl_asia(**kwargs)


__all__ = ["HotgirlAsiaAdapter"]
