from __future__ import annotations

import json
import pathlib
import threading
from collections import deque
from datetime import UTC, datetime

from .contracts import SourceCheckpointHint
from .url_normalizer import hash_media_url, normalize_media_url

try:
    import fcntl
except ImportError:  # pragma: no cover - non-POSIX fallback
    fcntl = None


class JsonlMediaCheckpointStore:
    def __init__(
        self,
        file_path: pathlib.Path,
        max_seen_per_source: int = 10_000,
        recent_window: int = 200,
    ) -> None:
        self.file_path = file_path
        self.max_seen_per_source = max_seen_per_source
        self.recent_window = recent_window

        self._loaded = False
        self._lock = threading.RLock()
        self._seen_by_source: dict[str, set[str]] = {}
        self._order_by_source: dict[str, deque[str]] = {}
        self._updated_at_by_source: dict[str, str] = {}

    def load_seen(self, source_key: str) -> set[str]:
        with self._lock:
            self._ensure_loaded()
            return set(self._seen_by_source.get(source_key, set()))

    def filter_new(self, source_key: str, media_urls: list[str]) -> list[str]:
        with self._lock:
            self._ensure_loaded()
            seen_hashes = self._seen_by_source.get(source_key, set())

            new_urls: list[str] = []
            for media_url in media_urls:
                media_hash = hash_media_url(normalize_media_url(media_url))
                if media_hash in seen_hashes:
                    continue
                new_urls.append(media_url)
            return new_urls

    def commit_seen(self, source_key: str, media_urls: list[str]) -> None:
        if not media_urls:
            return

        with self._lock:
            self._ensure_loaded()
            seen_set = self._seen_by_source.setdefault(source_key, set())
            seen_order = self._order_by_source.setdefault(source_key, deque())

            committed_hashes: list[str] = []
            for media_url in media_urls:
                media_hash = hash_media_url(normalize_media_url(media_url))
                if media_hash in seen_set:
                    continue

                seen_set.add(media_hash)
                seen_order.append(media_hash)
                committed_hashes.append(media_hash)

            if not committed_hashes:
                return

            while len(seen_order) > self.max_seen_per_source:
                old_hash = seen_order.popleft()
                seen_set.discard(old_hash)

            now_iso = datetime.now(tz=UTC).isoformat()
            self._updated_at_by_source[source_key] = now_iso
            self._append_event(source_key, now_iso, committed_hashes)

    def get_hint(self, source_key: str) -> SourceCheckpointHint:
        with self._lock:
            self._ensure_loaded()
            seen_hashes = self._seen_by_source.get(source_key, set())
            ordered = self._order_by_source.get(source_key, deque())
            if ordered:
                recent_hashes = set(list(ordered)[-self.recent_window :])
            else:
                recent_hashes = set()

            return SourceCheckpointHint(
                seen_hashes=set(seen_hashes),
                recent_hashes=recent_hashes,
                updated_at=self._updated_at_by_source.get(source_key),
            )

    def clear_source(self, source_key: str) -> None:
        with self._lock:
            self._ensure_loaded()
            self._seen_by_source.pop(source_key, None)
            self._order_by_source.pop(source_key, None)
            self._updated_at_by_source.pop(source_key, None)

            now_iso = datetime.now(tz=UTC).isoformat()
            event = {
                "source_key": source_key,
                "ts": now_iso,
                "hashes": [],
                "op": "clear",
            }
            self._append_raw_event(event)

    def inspect_source(self, source_key: str) -> dict[str, object]:
        hint = self.get_hint(source_key)
        return {
            "source_key": source_key,
            "seen_count": len(hint.seen_hashes),
            "recent_count": len(hint.recent_hashes),
            "updated_at": hint.updated_at,
        }

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return

        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.file_path.exists():
            self.file_path.touch(exist_ok=True)
            self._loaded = True
            return

        with self.file_path.open("r", encoding="utf-8") as fp:
            for line in fp:
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    event = json.loads(stripped)
                except json.JSONDecodeError:
                    continue

                source_key = event.get("source_key")
                if not isinstance(source_key, str):
                    continue

                op = event.get("op")
                if op == "clear":
                    self._seen_by_source.pop(source_key, None)
                    self._order_by_source.pop(source_key, None)
                    self._updated_at_by_source[source_key] = str(event.get("ts", ""))
                    continue

                hashes = event.get("hashes")
                if not isinstance(hashes, list):
                    continue

                seen_set = self._seen_by_source.setdefault(source_key, set())
                seen_order = self._order_by_source.setdefault(source_key, deque())

                for media_hash in hashes:
                    if not isinstance(media_hash, str):
                        continue
                    if media_hash in seen_set:
                        continue
                    seen_set.add(media_hash)
                    seen_order.append(media_hash)

                while len(seen_order) > self.max_seen_per_source:
                    old_hash = seen_order.popleft()
                    seen_set.discard(old_hash)

                ts = event.get("ts")
                if isinstance(ts, str) and ts:
                    self._updated_at_by_source[source_key] = ts

        self._loaded = True

    def _append_event(self, source_key: str, ts: str, hashes: list[str]) -> None:
        event = {
            "source_key": source_key,
            "ts": ts,
            "hashes": hashes,
        }
        self._append_raw_event(event)

    def _append_raw_event(self, event: dict[str, object]) -> None:
        payload = json.dumps(event, ensure_ascii=True)
        with self.file_path.open("a", encoding="utf-8") as fp:
            if fcntl is not None:
                fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
            try:
                fp.write(payload)
                fp.write("\n")
                fp.flush()
            finally:
                if fcntl is not None:
                    fcntl.flock(fp.fileno(), fcntl.LOCK_UN)
