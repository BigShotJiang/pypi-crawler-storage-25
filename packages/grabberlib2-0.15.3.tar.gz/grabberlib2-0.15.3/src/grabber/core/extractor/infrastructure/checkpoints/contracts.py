from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from boltons.setutils import IndexedSet


@dataclass(slots=True)
class SourceCheckpointHint:
    seen_hashes: set[str]
    recent_hashes: set[str]
    updated_at: str | None


@dataclass(slots=True)
class CheckpointDecision:
    new_images: IndexedSet
    new_videos: IndexedSet | None
    skipped_images_count: int
    skipped_videos_count: int


class MediaCheckpointStore(Protocol):
    def load_seen(self, source_key: str) -> set[str]:
        raise NotImplementedError

    def filter_new(self, source_key: str, media_urls: list[str]) -> list[str]:
        raise NotImplementedError

    def commit_seen(self, source_key: str, media_urls: list[str]) -> None:
        raise NotImplementedError

    def get_hint(self, source_key: str) -> SourceCheckpointHint:
        raise NotImplementedError
