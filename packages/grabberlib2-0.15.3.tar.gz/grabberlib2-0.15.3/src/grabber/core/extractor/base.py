import abc
import pathlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING
from urllib import parse

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from tqdm import tqdm
from unidecode import unidecode

from grabber.core.extractor.infrastructure.checkpoints.url_normalizer import hash_media_url
from grabber.core.extractor.infrastructure.fetching.scraper import get_tags
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls
from grabber.core.extractor.infrastructure.publishing.telegraph import send_post_to_telegram
from grabber.core.extractor.infrastructure.storage.downloader import run_downloader
from grabber.core.settings import CHECKPOINT_CONSECUTIVE_SEEN_STOP, TELEGRAPH_TOKEN

from .constants import HEADERS_MAPPING, PAGE_TITLE_SPLIT_MAPPING, QUERY_MAPPING

if TYPE_CHECKING:
    from grabber.core.extractor.infrastructure.checkpoints.contracts import SourceCheckpointHint


@dataclass(slots=True)
class ExtractorResult:
    page_title: str
    ordered_unique_img_urls: IndexedSet
    ordered_unique_video_urls: IndexedSet | None = None


@dataclass(slots=True)
class ExtractorConfig:
    query: str
    src_attr: str
    secondary_src_attr: str = ""
    title_splitters: list[str] = field(default_factory=list)
    uses_js: bool = False
    bypass_cloudflare: bool = False
    image_entity: str | None = None
    pagination_fetcher: Callable[[str, dict[str, str] | None], Awaitable[list[str]]] | None = None
    title_factory: Callable[[BeautifulSoup], str] | None = None
    image_urls_post_processor: Callable[[IndexedSet], IndexedSet] | None = None
    result_collector: Callable[[str, dict[str, str] | None], Awaitable["ExtractorResult | None"]] | None = None


class BaseExtractor(abc.ABC):
    def __init__(
        self,
        sources: list[str],
        *,
        entity: str | None = None,
        final_dest: str | pathlib.Path = "",
        is_tag: bool = False,
        limit: int | None = None,
        save_to_telegraph: bool = False,
        channel: str = "",
        max_pages: int = 50,
        telegraph_client: Telegraph | None = None,
        checkpoint_hint: "SourceCheckpointHint | None" = None,
    ) -> None:
        self.sources = sources
        self.entity = entity or self.get_entity(sources)
        self.final_dest = pathlib.Path(final_dest) if final_dest else None
        self.is_tag = is_tag
        self.limit = limit
        self.save_to_telegraph = save_to_telegraph
        self.channel = channel
        self.max_pages = max_pages
        self.telegraph_client = telegraph_client or Telegraph(access_token=TELEGRAPH_TOKEN)
        self.checkpoint_hint = checkpoint_hint

        self.headers = HEADERS_MAPPING.get(self.entity, HEADERS_MAPPING["common"])
        self.titles: IndexedSet = IndexedSet()
        self.title_folder_mapping: dict[str, tuple[IndexedSet, IndexedSet | None, pathlib.Path]] = {}
        self.posts_sent_counter = 0
        self.all_sources: list[str] = []

    @staticmethod
    def get_entity(sources: list[str]) -> str:
        parsed_url = parse.urlparse(sources[0])
        return parsed_url.netloc

    def get_page_title(self, soup: BeautifulSoup, splitters: list[str] | None = None) -> str:
        if splitters is None:
            splitters = PAGE_TITLE_SPLIT_MAPPING.get(self.entity, PAGE_TITLE_SPLIT_MAPPING["common"])

        title_tag = soup.select_one("title")
        if title_tag is None:
            return f"post-{self.entity}"

        page_title = title_tag.get_text(strip=True).strip().rstrip()

        for splitter in splitters:
            page_title = page_title.split(splitter)[0]

        page_title = page_title.replace("https:", "").strip().rstrip()
        return page_title

    def add_destination(
        self,
        page_title: str,
        ordered_unique_img_urls: IndexedSet,
        ordered_unique_video_urls: IndexedSet | None = None,
    ) -> pathlib.Path | None:
        if self.final_dest is None:
            return None

        folder_dest = self.final_dest / unidecode(f"{page_title} - {self.entity}")
        folder_dest.mkdir(parents=True, exist_ok=True)
        self.title_folder_mapping[page_title] = (ordered_unique_img_urls, ordered_unique_video_urls, folder_dest)
        return folder_dest

    @abc.abstractmethod
    async def extract_source(self, source_url: str) -> ExtractorResult | None:
        raise NotImplementedError

    async def run(self) -> None:
        progress = tqdm(
            self.sources,
            total=len(self.sources),
            desc="Retrieving URLs...",
        )
        latest_ordered_unique_img_urls: IndexedSet | None = None

        for source_url in progress:
            self.all_sources.append(source_url)
            result = await self.extract_source(source_url)
            if result is None:
                continue

            latest_ordered_unique_img_urls = result.ordered_unique_img_urls
            self.titles.add(result.page_title)
            progress.set_description(f"Finished retrieving images for {result.page_title}")
            self.add_destination(
                result.page_title,
                result.ordered_unique_img_urls,
                result.ordered_unique_video_urls,
            )

            if self.save_to_telegraph:
                await send_post_to_telegram(
                    ordered_unique_img_urls=result.ordered_unique_img_urls,
                    ordered_unique_video_urls=result.ordered_unique_video_urls,
                    page_title=result.page_title,
                    telegraph_client=self.telegraph_client,
                    posts_sent_counter=self.posts_sent_counter,
                    tqdm_sources_iterable=progress,
                    all_sources=self.all_sources,
                    source_url=source_url,
                    entity=self.entity,
                    channel=self.channel,
                )
                self.posts_sent_counter += 1

        if self.final_dest and self.title_folder_mapping:
            await run_downloader(
                final_dest=self.final_dest,
                page_title="",
                unique_img_urls=latest_ordered_unique_img_urls or IndexedSet(),
                titles=self.titles,
                title_folder_mapping=self.title_folder_mapping,
                headers=self.headers,
            )


class DefaultExtractor(BaseExtractor):
    def __init__(
        self,
        sources: list[str],
        *,
        entity: str | None = None,
        config: ExtractorConfig | None = None,
        final_dest: str | pathlib.Path = "",
        is_tag: bool = False,
        limit: int | None = None,
        save_to_telegraph: bool = False,
        channel: str = "",
        max_pages: int = 50,
        telegraph_client: Telegraph | None = None,
        checkpoint_hint: "SourceCheckpointHint | None" = None,
    ) -> None:
        super().__init__(
            sources=sources,
            entity=entity,
            final_dest=final_dest,
            is_tag=is_tag,
            limit=limit,
            save_to_telegraph=save_to_telegraph,
            channel=channel,
            max_pages=max_pages,
            telegraph_client=telegraph_client,
            checkpoint_hint=checkpoint_hint,
        )

        if config is None:
            query, src_attr = QUERY_MAPPING[self.entity]
            title_splitters = PAGE_TITLE_SPLIT_MAPPING.get(self.entity, PAGE_TITLE_SPLIT_MAPPING["common"])
            config = ExtractorConfig(
                query=query,
                src_attr=src_attr,
                title_splitters=list(title_splitters),
                image_entity=self.entity,
            )

        self.config = config

    async def resolve_source_urls(self, source_url: str) -> list[str]:
        if self.config.pagination_fetcher is None:
            return [source_url]

        paginated_urls = await self.config.pagination_fetcher(source_url, self.headers)
        if source_url in paginated_urls:
            return paginated_urls
        return [source_url, *paginated_urls]

    async def extract_source(self, source_url: str) -> ExtractorResult | None:
        if self.config.result_collector is not None:
            return await self.config.result_collector(source_url, self.headers)

        source_urls = await self.resolve_source_urls(source_url)
        image_tags: list[Tag] = []
        latest_soup: BeautifulSoup | None = None
        first_soup: BeautifulSoup | None = None
        seen_hashes = self.checkpoint_hint.seen_hashes if self.checkpoint_hint is not None else set()
        consecutive_seen = 0

        for target_url in source_urls:
            tags, soup = await get_tags(
                target_url,
                headers=self.headers,
                query=self.config.query,
                uses_js=self.config.uses_js,
                bypass_cloudflare=self.config.bypass_cloudflare,
            )
            image_tags.extend(tags or [])
            latest_soup = soup
            if first_soup is None:
                first_soup = soup
            if not seen_hashes or not tags:
                continue

            page_media_records = await build_unique_img_urls(
                image_tags=tags,
                src_attr=self.config.src_attr,
                secondary_src_attr=self.config.secondary_src_attr,
                entity=self.config.image_entity,
            )
            if not page_media_records:
                continue

            for media_record in page_media_records:
                media_url = media_record[-1]
                if hash_media_url(media_url) in seen_hashes:
                    consecutive_seen += 1
                else:
                    consecutive_seen = 0

            if consecutive_seen >= CHECKPOINT_CONSECUTIVE_SEEN_STOP:
                break

        if latest_soup is None or first_soup is None or not image_tags:
            return None

        if self.config.title_factory is not None:
            page_title = self.config.title_factory(first_soup)
        else:
            page_title = self.get_page_title(first_soup, splitters=self.config.title_splitters)

        ordered_unique_img_urls = await build_unique_img_urls(
            image_tags,
            self.config.src_attr,
            self.config.secondary_src_attr,
            self.config.image_entity,
        )
        if self.config.image_urls_post_processor is not None:
            ordered_unique_img_urls = self.config.image_urls_post_processor(ordered_unique_img_urls)
        if not ordered_unique_img_urls:
            return None

        return ExtractorResult(
            page_title=page_title,
            ordered_unique_img_urls=ordered_unique_img_urls,
        )
