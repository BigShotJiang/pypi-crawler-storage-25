from aiogram import Bot
from aiogram.types import URLInputFile
from aiogram.utils.media_group import MediaGroupBuilder

from grabber.core.settings import BOT_TOKEN


class TelegramSenderAdapter:
    def __init__(self, bot_token: str | None = None) -> None:
        self.bot_token = bot_token or BOT_TOKEN

    @staticmethod
    async def _send_channel_comment(
        bot: Bot,
        discussion_chat_id: int,
        channel_chat_id: int,
        post_text: str,
        thread_id: int,
        channel_label: str,
    ) -> int:
        comment_payload = {
            "chat_id": discussion_chat_id,
            "text": post_text,
            "reply_parameters": {
                "chat_id": channel_chat_id,
                "message_id": thread_id,
            },
        }
        try:
            await bot.send_message(**comment_payload)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to send comment into linked discussion for {channel_label}. "
                "Ensure the bot can post in the linked discussion group and that "
                f"--thread-id {thread_id} matches a valid channel post id."
            ) from exc

        return thread_id

    async def send_text(
        self,
        channels: list[str],
        post_text: str,
        thread_id: int | None = None,
    ) -> list[int | None]:
        bot = Bot(token=self.bot_token)
        resolved_thread_ids: list[int | None] = []
        async with bot.context():
            for channel in channels:
                payload = {"chat_id": channel, "text": post_text}
                if thread_id is None:
                    response = await bot.send_message(**payload)
                    resolved_thread_ids.append(
                        response.message_thread_id if response.message_thread_id is not None else response.message_id
                    )
                    continue

                destination = await bot.get_chat(channel)
                destination_type = str(getattr(destination, "type", ""))
                destination_chat_id = getattr(destination, "id", channel)
                linked_chat_id = getattr(destination, "linked_chat_id", None)

                if destination_type == "channel":
                    if linked_chat_id is None:
                        raise ValueError(
                            f"Channel {channel} has no linked discussion chat; cannot use --thread-id for comments."
                        )

                    resolved_thread_ids.append(
                        await self._send_channel_comment(
                            bot=bot,
                            discussion_chat_id=linked_chat_id,
                            channel_chat_id=destination_chat_id,
                            post_text=post_text,
                            thread_id=thread_id,
                            channel_label=channel,
                        )
                    )
                    continue

                if destination_type == "supergroup" and linked_chat_id is not None:
                    resolved_thread_ids.append(
                        await self._send_channel_comment(
                            bot=bot,
                            discussion_chat_id=destination_chat_id,
                            channel_chat_id=linked_chat_id,
                            post_text=post_text,
                            thread_id=thread_id,
                            channel_label=channel,
                        )
                    )
                    continue

                payload["message_thread_id"] = thread_id
                response = await bot.send_message(**payload)
                resolved_thread_ids.append(
                    response.message_thread_id if response.message_thread_id is not None else response.message_id
                )

        return resolved_thread_ids

    async def send_media_group(
        self,
        channels: list[str],
        post_text: str,
        media: list[URLInputFile],
    ) -> None:
        bot = Bot(token=self.bot_token)
        async with bot.context():
            for channel in channels:
                builder = MediaGroupBuilder(caption=post_text)
                for image in media:
                    builder.add_photo(media=image)
                await bot.send_media_group(chat_id=channel, media=builder.build())
