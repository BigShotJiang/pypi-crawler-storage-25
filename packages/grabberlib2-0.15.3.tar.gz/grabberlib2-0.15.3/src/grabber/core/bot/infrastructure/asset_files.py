from __future__ import annotations

import json
from pathlib import Path
from typing import ClassVar

from grabber.core.settings import APP_ROOT


class AssetFileService:
    FILE_TYPES: ClassVar[dict[str, str]] = {"txt": ".txt", "json": ".json"}

    def __init__(
        self,
        txt_root: Path | None = None,
        json_root: Path | None = None,
    ) -> None:
        self.roots: dict[str, Path] = {
            "txt": (txt_root or APP_ROOT / "assets" / "txt").resolve(),
            "json": (json_root or APP_ROOT / "assets" / "json").resolve(),
        }

    def list_files(self, file_type: str) -> list[Path]:
        normalized_type = self._normalize_file_type(file_type)
        root = self.roots[normalized_type]
        expected_suffix = self.FILE_TYPES[normalized_type]
        if not root.exists():
            return []

        files: list[Path] = []
        for path in root.iterdir():
            if not path.is_file():
                continue
            if path.suffix.lower() != expected_suffix:
                continue
            files.append(self._validate_under_type_root(normalized_type, path.resolve()))

        files.sort(key=lambda p: p.name.lower())
        return files

    def get_file_by_index(self, file_type: str, index: int) -> Path | None:
        files = self.list_files(file_type)
        if index < 0 or index >= len(files):
            return None
        return files[index]

    def read_text(self, path: Path) -> str:
        safe_path = self._validate_under_any_root(path.resolve())
        with safe_path.open("r", encoding="utf-8", errors="replace") as fp:
            return fp.read()

    def format_content(self, file_type: str, raw_text: str) -> str:
        normalized_type = self._normalize_file_type(file_type)
        if normalized_type == "txt":
            return raw_text

        try:
            parsed = json.loads(raw_text)
        except json.JSONDecodeError:
            return raw_text

        structured_output = self._format_title_url_records(parsed)
        if structured_output is not None:
            return structured_output

        return json.dumps(parsed, indent=2, ensure_ascii=False)

    @staticmethod
    def _format_title_url_records(payload: object) -> str | None:
        def format_record(record: object) -> str | None:
            if not isinstance(record, dict):
                return None
            title = record.get("title")
            url = record.get("url")
            if not isinstance(title, str) or not isinstance(url, str):
                return None
            return f"Title: {title}\nURL: {url}\n----------------"

        if isinstance(payload, dict):
            return format_record(payload)

        if isinstance(payload, list):
            formatted_records: list[str] = []
            for item in payload:
                formatted = format_record(item)
                if formatted is None:
                    return None
                formatted_records.append(formatted)
            return "\n".join(formatted_records)

        return None

    def _normalize_file_type(self, file_type: str) -> str:
        normalized = file_type.strip().lower()
        if normalized not in self.FILE_TYPES:
            raise ValueError(f"Unsupported asset file type: {file_type}")
        return normalized

    def _validate_under_type_root(self, file_type: str, path: Path) -> Path:
        root = self.roots[file_type]
        if path != root and root not in path.parents:
            raise ValueError(f"Path is outside asset root for {file_type}: {path}")
        return path

    def _validate_under_any_root(self, path: Path) -> Path:
        for root in self.roots.values():
            if path == root or root in path.parents:
                return path
        raise ValueError(f"Path is outside asset roots: {path}")
