from dataclasses import dataclass, field
from typing import Protocol

from aiogram.types import URLInputFile
from tqdm import tqdm


@dataclass(slots=True)
class SendMessageRequest:
    post_text: str
    image_urls: set[tuple[str, str]] | None = None
    channel: str | None = "@fans_posting"
    thread_id: int | None = None
    retry: bool = False
    posts_counter: int = 0
    retry_counter: int = 0
    sleep_time: int = 0
    tqdm_iterable: tqdm | None = None
    send_images: bool = False
    entity: str = ""


@dataclass(slots=True)
class SendMessageResult:
    was_successful: bool
    channels: list[str]
    resolved_thread_ids: list[int | None] = field(default_factory=list)


class TelegramSender(Protocol):
    async def send_text(
        self,
        channels: list[str],
        post_text: str,
        thread_id: int | None = None,
    ) -> list[int | None]:
        raise NotImplementedError

    async def send_media_group(
        self,
        channels: list[str],
        post_text: str,
        media: list[URLInputFile],
    ) -> None:
        raise NotImplementedError
