#!/usr/bin/env python3


import io

import cf_xarray  # noqa: F401 - Enable cf accessor
import morecantile
import numpy as np
import pandas as pd
import pytest
from hypothesis import example, given
from hypothesis import strategies as st
from morecantile import Tile
from PIL import Image
from pyproj import CRS
from pyproj.aoi import BBox

import xarray as xr
from src.xpublish_tiles.render.raster import nearest_on_uniform_grid_quadmesh
from tests import NUMERIC_DTYPES, create_query_params
from xarray.testing import assert_equal
from xpublish_tiles import config
from xpublish_tiles.lib import (
    AsyncLoadTimeoutError,
    IndexingError,
    MissingParameterError,
    VariableNotFoundError,
    check_transparent_pixels,
)
from xpublish_tiles.pipeline import (
    apply_query,
    bbox_overlap,
    pipeline,
)
from xpublish_tiles.testing.datasets import (
    CUBED_SPHERE,
    CURVILINEAR,
    FORECAST,
    GLOBAL_6KM,
    GLOBAL_6KM_360,
    GLOBAL_HEALPIX_L3,
    GLOBAL_NANS,
    HRRR,
    IFS,
    PARA,
    REDGAUSS_N320,
    REGIONAL_HEALPIX_NA,
    TRIPOLE_ANTIMERIDIAN,
    _create_global_healpix,
    create_global_dataset,
)
from xpublish_tiles.testing.lib import (
    as_pytestparams,
    assert_render_matches_snapshot,
    compare_image_buffers,
    compare_image_buffers_with_debug,
    visualize_tile,
)
from xpublish_tiles.testing.tiles import (
    CURVILINEAR_TILES,
    PARA_TILES,
    TILES,
    WEBMERC_TMS,
    WGS84_TMS,
    TileTestParam,
)
from xpublish_tiles.types import ImageFormat, OutputBBox, OutputCRS, QueryParams


@st.composite
def bboxes(draw):
    """Generate valid bounding boxes for testing."""
    # Generate latitude bounds (must be within -90 to 90)
    south = draw(st.floats(min_value=-89.9, max_value=89.9))
    north = draw(st.floats(min_value=south + 0.1, max_value=90.0))

    # Generate longitude bounds (can be any range, including wrapped)
    west = draw(st.floats(min_value=-720.0, max_value=720.0))
    east = draw(st.floats(min_value=west + 0.1, max_value=west + 360.0))

    return BBox(west=west, south=south, east=east, north=north)


@given(
    bbox=bboxes(),
    grid_config=st.sampled_from(
        [
            (BBox(west=0.0, south=-90.0, east=360.0, north=90.0), "0-360"),
            (BBox(west=-180.0, south=-90.0, east=180.0, north=90.0), "-180-180"),
        ]
    ),
)
@example(
    bbox=BBox(west=-200.0, south=20.0, east=-190.0, north=40.0),
    grid_config=(BBox(west=0.0, south=-90.0, east=360.0, north=90.0), "0-360"),
)
@example(
    bbox=BBox(west=400.0, south=20.0, east=420.0, north=40.0),
    grid_config=(BBox(west=-180.0, south=-90.0, east=180.0, north=90.0), "-180-180"),
)
@example(
    bbox=BBox(west=-1.0, south=0.0, east=0.0, north=1.0),
    grid_config=(BBox(west=0.0, south=-90.0, east=360.0, north=90.0), "0-360"),
)
def test_bbox_overlap_detection(bbox, grid_config):
    """Test the bbox overlap detection logic handles longitude wrapping correctly."""
    grid_bbox, grid_description = grid_config
    # All valid bboxes should overlap with global grids due to longitude wrapping
    assert bbox_overlap(bbox, grid_bbox, True), (
        f"Valid bbox {bbox} should overlap with global {grid_description} grid. "
        f"Longitude wrapping should handle any longitude values."
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("dtype", NUMERIC_DTYPES)
async def test_pipeline_dtypes(dtype, png_snapshot):
    """Test that the full rendering pipeline handles all numeric dtypes."""
    ds = create_global_dataset()
    rng = np.random.default_rng(42)
    shape = ds["foo"].shape
    if np.issubdtype(dtype, np.integer):
        info = np.iinfo(dtype)
        lo = max(info.min, -10000)
        hi = min(info.max, 10000)
        data = rng.integers(lo, hi, size=shape, dtype=dtype)
    else:
        data = rng.uniform(-1, 1, size=shape).astype(dtype)
    ds["foo"] = ds["foo"].copy(data=data)
    ds["foo"].attrs["valid_min"] = (
        int(data.min()) if np.issubdtype(dtype, np.integer) else float(data.min())
    )
    ds["foo"].attrs["valid_max"] = (
        int(data.max()) if np.issubdtype(dtype, np.integer) else float(data.max())
    )
    tile = Tile(x=2, y=1, z=2)
    query_params = create_query_params(tile, WEBMERC_TMS)
    with config.set(rectilinear_check_min_size=0):
        result = await pipeline(ds, query_params)
    assert_render_matches_snapshot(result, png_snapshot)


@pytest.mark.asyncio
@pytest.mark.parametrize("tile,tms", as_pytestparams(TILES))
async def test_pipeline_tiles(global_datasets, tile, tms, png_snapshot, pytestconfig):
    """Test pipeline with various tiles using their native TMS CRS."""
    ds = global_datasets
    query_params = create_query_params(tile, tms)
    with config.set(rectilinear_check_min_size=0):
        result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(
        result,
        png_snapshot,
        # we have small rasterization differences in CI
        perceptual_threshold=0.99
        if ds.attrs["name"] == "reduced_gaussian_n320"
        else None,
    )


POLYGON_EDGE_TILES = [
    TileTestParam(
        tile=Tile(x=t.tile.x * 2, y=t.tile.y * 2, z=t.tile.z + 1),
        tms=t.tms,
        name=t.name,
    )
    for t in TILES
    if 3 <= t.tile.z <= 5
    and any(
        k in t.name for k in ("antimeridian", "corner", "prime", "small_bbox", "zoom")
    )
]


@pytest.mark.asyncio
@pytest.mark.parametrize("tile,tms", as_pytestparams(POLYGON_EDGE_TILES))
async def test_pipeline_tiles_polygons(
    global_datasets, tile, tms, png_snapshot, pytestconfig
):
    """Test pipeline with polygons style rendering."""
    ds = global_datasets
    query_params = create_query_params(
        tile, tms, style="polygons", colorscalerange=(-0.5, 0.5)
    )
    with config.set(rectilinear_check_min_size=0):
        result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    is_global = ds.attrs["name"] == "reduced_gaussian_n320"
    assert_render_matches_snapshot(
        result,
        png_snapshot,
        skip_transparency_check=not is_global,
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("ds", [GLOBAL_6KM.create(), GLOBAL_6KM_360.create()])
@pytest.mark.parametrize(
    "tile",
    [
        Tile(x=0, y=1, z=2),
        Tile(x=1, y=1, z=2),
        Tile(x=0, y=2, z=2),
        Tile(x=0, y=3, z=3),
        Tile(x=0, y=6, z=4),
        Tile(x=0, y=788, z=11),
    ],
)
async def test_global_6km_regression(ds, tile, png_snapshot, pytestconfig):
    query_params = create_query_params(tile, WEBMERC_TMS)
    query_params.width = 512
    query_params.height = 512
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(result, png_snapshot)


async def test_pipeline_bad_bbox(global_datasets, png_snapshot, pytestconfig):
    """Test pipeline with various tiles using their native TMS CRS."""
    ds = global_datasets
    query = QueryParams(
        variables=["foo"],
        crs=OutputCRS(CRS.from_user_input(3857)),
        # This bbox will transform to west=179.999CXXX, east=-157.XXX
        bbox=OutputBBox(
            BBox(
                west=-20037508.3428,
                south=7514065.628550399,
                east=-17532819.799950078,
                north=10018754.17140032,
            )
        ),
        selectors={},
        style="raster",
        width=256,
        height=256,
        variant="viridis",
        colorscalerange=None,
        format=ImageFormat.PNG,
    )
    result = await pipeline(ds, query)
    assert_render_matches_snapshot(
        result,
        png_snapshot,
        # we have small rasterization differences in CI
        perceptual_threshold=0.99
        if ds.attrs["name"] == "reduced_gaussian_n320"
        else None,
    )


@pytest.mark.asyncio
async def test_high_zoom_tile_global_dataset(global_datasets, png_snapshot, pytestconfig):
    ds = global_datasets
    tms = WEBMERC_TMS
    tile = morecantile.Tile(x=524288 + 2916, y=262144, z=20)
    query_params = create_query_params(tile, tms, colorscalerange=(-1, 1))
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(result, png_snapshot)


async def test_projected_coordinate_data(
    projected_dataset_and_tile, png_snapshot, pytestconfig
):
    ds, tile, tms = projected_dataset_and_tile
    query_params = create_query_params(tile, tms)
    with config.set(rectilinear_check_min_size=0):
        result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(
        result, png_snapshot, tile=tile, tms=tms, dataset_bbox=ds.attrs["bbox"]
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("tile,tms", as_pytestparams(CURVILINEAR_TILES))
async def test_curvilinear_data(tile, tms, png_snapshot, pytestconfig):
    ds = CURVILINEAR.create()
    query_params = create_query_params(tile, tms)
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(result, png_snapshot, tile=tile, tms=tms)

    transposed = ds.assign_coords(lat=ds.lat.transpose(), lon=ds.lon.transpose())
    with config.set(transform_chunk_size=ds.foo.shape[-1] + 10):
        transposed_result = await pipeline(transposed, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)

    # Can't use a snapshot twice in a test sadly
    result.seek(0)
    transposed_result.seek(0)
    _, _ = compare_image_buffers_with_debug(
        result,  # Expected (original)
        transposed_result,  # Actual (transposed)
        test_name=f"test_curvilinear_data_transposed_vs_original[{tile.z}/{tile.x}/{tile.y}]",
        tile_info=(tile, tms),
        debug_visual=pytestconfig.getoption("--debug-visual"),
        debug_visual_save=pytestconfig.getoption("--debug-visual-save"),
    )


@pytest.mark.asyncio
async def test_radar_data(radar_dataset_and_tile, png_snapshot, pytestconfig):
    ds, tile, tms = radar_dataset_and_tile
    query_params = create_query_params(tile, tms)
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    # Radar polar data has transparent corners (circular coverage)
    assert_render_matches_snapshot(
        result, png_snapshot, tile=tile, tms=tms, skip_transparency_check=True
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "tile",
    [
        Tile(x=16, y=23, z=6),
        Tile(x=17, y=23, z=6),
        Tile(x=14, y=23, z=6),
        Tile(x=3, y=5, z=4),
        Tile(x=3, y=7, z=4),
        # edge-case where there is not data in the tile but the bbox overlaps
        Tile(x=4, y=7, z=4),
    ],
)
async def test_curvilinear_polygons(tile, png_snapshot, pytestconfig):
    ds = CURVILINEAR.create()
    query_params = create_query_params(tile, WEBMERC_TMS, style="polygons")
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(
        result, png_snapshot, tile=tile, tms=WEBMERC_TMS, skip_transparency_check=True
    )


@pytest.fixture(scope="module")
def n320_dataset():
    return REDGAUSS_N320.create()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "tile,colorscalerange",
    [
        # Near-polar tiles where the N320 reduced Gaussian grid has sparse
        # longitudinal coverage, so individual triangles are large enough
        # to be clearly visible in the rendered output.
        (Tile(x=0, y=0, z=5), (-0.5, 0.5)),
        (Tile(x=32, y=8, z=6), (0.6, 0.8)),
    ],
)
async def test_n320_polygons_triangles_visible(
    n320_dataset, tile, colorscalerange, png_snapshot, pytestconfig
):
    query_params = create_query_params(
        tile, WEBMERC_TMS, style="polygons", colorscalerange=colorscalerange
    )
    result = await pipeline(n320_dataset, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(result, png_snapshot, tile=tile, tms=WEBMERC_TMS)


@pytest.mark.parametrize("tile,tms", as_pytestparams(PARA_TILES))
async def test_categorical_data(tile, tms, png_snapshot, pytestconfig):
    ds = PARA.create().squeeze("time")
    query_params = create_query_params(tile, tms)
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(
        result, png_snapshot, tile=tile, tms=tms, dataset_bbox=ds.attrs["bbox"]
    )


async def test_categorical_data_with_custom_colormap(png_snapshot, pytestconfig):
    """Test categorical data with custom colormap renders correctly."""
    ds = PARA.create().squeeze("time")

    # PARA has 10 categories (flag_values: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    # Create a custom colormap with 10 distinct colors
    custom_colormap = {
        "0": "#ff0000",  # red
        "1": "#00ff00",  # green
        "2": "#0000ff",  # blue
        "3": "#ffff00",  # yellow
        "4": "#ff00ff",  # magenta
        "5": "#00ffff",  # cyan
        "6": "#800000",  # maroon
        "7": "#008000",  # dark green
        "8": "#000080",  # navy
        "9": "#808080",  # gray
    }

    tile = PARA_TILES[0].tile
    tms = PARA_TILES[0].tms
    query_params = create_query_params(
        tile, tms, style="raster", variant="custom", colormap=custom_colormap
    )
    result = await pipeline(ds, query_params)

    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(
        result, png_snapshot, tile=tile, tms=tms, dataset_bbox=ds.attrs["bbox"]
    )


@pytest.mark.asyncio
async def test_categorical_out_of_range_values_are_transparent(pytestconfig):
    """Test that categorical values outside flag_values render as transparent with custom colormap."""
    ds = PARA.create().squeeze("time")

    # PARA has 10 categories (flag_values: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    # Create a custom colormap with only the valid flag_values
    custom_colormap = {
        "0": "#ff0000",
        "1": "#00ff00",
        "2": "#0000ff",
        "3": "#ffff00",
        "4": "#ff00ff",
        "5": "#00ffff",
        "6": "#800000",
        "7": "#008000",
        "8": "#000080",
        "9": "#808080",
    }

    # Use the Belém tile (capital area) which should have good data coverage
    tile, tms = Tile(x=22, y=31, z=6), WEBMERC_TMS
    query_params = create_query_params(
        tile, tms, style="raster", variant="custom", colormap=custom_colormap
    )

    # Render unmodified data and get baseline transparency
    unmodified_result = await pipeline(ds, query_params)
    baseline_transparent_percent = check_transparent_pixels(unmodified_result.getvalue())

    # Replace all values > 2 with 99 (out of range)
    ds_modified = ds.compute()
    ds_modified["foo"].values[ds_modified["foo"].values > 2] = 99

    # Render modified data
    modified_result = await pipeline(ds_modified, query_params)
    modified_transparent_percent = check_transparent_pixels(modified_result.getvalue())

    # Assert that modified data has more transparent pixels than unmodified
    assert modified_transparent_percent > baseline_transparent_percent, (
        f"Expected transparency to increase with out-of-range values. "
        f"Baseline: {baseline_transparent_percent:.1f}%, Modified: {modified_transparent_percent:.1f}%"
    )

    if pytestconfig.getoption("--visualize"):
        visualize_tile(modified_result, tile)


@pytest.mark.asyncio
@pytest.mark.parametrize("style", ["raster", "polygons"])
@pytest.mark.parametrize(
    "abovemaxcolor,belowmincolor",
    [
        pytest.param("transparent", "transparent", id="transparent"),
        pytest.param("#ff0000", "#0000ff", id="red_blue"),
        pytest.param("extend", "extend", id="extend"),
    ],
)
async def test_continuous_data_with_range_colors(
    abovemaxcolor, belowmincolor, style, png_snapshot, pytestconfig
):
    """Test continuous data with abovemaxcolor/belowmincolor parameters.

    Note: This test verifies that the abovemaxcolor/belowmincolor parameters
    are passed through the pipeline correctly. The IFS dataset has data in
    the range [-0.92, 0.92], and we set colorscalerange=(-0.5, 0.5) so that
    ~25% of values are above max and ~25% are below min.
    """
    ds = IFS.create().isel(time=0, step=0)

    tile, tms = Tile(x=2, y=1, z=2), WGS84_TMS
    query_params = create_query_params(
        tile,
        tms,
        style=style,
        colorscalerange=(-0.5, 0.5),
        abovemaxcolor=abovemaxcolor,
        belowmincolor=belowmincolor,
    )
    result = await pipeline(ds, query_params)

    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(
        result,
        png_snapshot,
        tile=tile,
        tms=tms,
        skip_transparency_check=(
            abovemaxcolor == "transparent" or belowmincolor == "transparent"
        ),
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("tile,tms", as_pytestparams(GLOBAL_NANS.tiles))
async def test_global_nans_data(tile, tms, png_snapshot, pytestconfig):
    """Test pipeline with global dataset containing diagonal NaN patterns."""
    ds = GLOBAL_NANS.create()
    query_params = create_query_params(tile, tms)
    with config.set(rectilinear_check_min_size=0):
        result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)

    # Skip transparency validation for NaN data - just check the snapshot directly
    assert isinstance(result, io.BytesIO)
    result.seek(0)
    content = result.read()
    assert len(content) > 0
    assert content == png_snapshot


def test_apply_query_errors():
    ds = FORECAST.copy(deep=True)
    ds["foo2"] = ds["sst"] * 2

    with pytest.raises(VariableNotFoundError):
        apply_query(ds, variables=["foooooooo"], selectors={})
    with pytest.raises(IndexingError):
        apply_query(ds, variables=["sst"], selectors={"L": 123123123})

    hrrr = HRRR.create()

    with pytest.raises(IndexingError, match="Invalid selection method 'invalid'"):
        apply_query(
            hrrr, variables=["foo"], selectors={"time": "invalid::2018-01-01T01:00"}
        )

    with pytest.raises(IndexingError, match="Invalid selection method 'badmethod'"):
        apply_query(
            hrrr, variables=["foo"], selectors={"time": "badmethod::2018-01-01T01:00"}
        )


def test_apply_query_selectors():
    ds = FORECAST.copy(deep=True)
    ds["foo2"] = ds["sst"] * 2

    result = apply_query(ds, variables=["sst"], selectors={})
    assert result["sst"].da.dims == ("Y", "X")
    assert len(result) == 1

    result = apply_query(ds, variables=["sst", "foo2"], selectors={})
    assert len(result) == 2
    assert result["sst"].grid.equals(result["foo2"].grid)

    result = apply_query(
        ds,
        variables=["sst"],
        selectors={"L": 0, "S": "1960-02-01 00:00:00"},
    )
    assert_equal(
        result["sst"].da,
        FORECAST.sst.sel(L=0, S="1960-02-01 00:00:00").isel(M=-1, S=-1),
    )

    curvilinear_ds = CURVILINEAR.create()
    result = apply_query(curvilinear_ds, variables=["foo"], selectors={})
    assert_equal(result["foo"].da, curvilinear_ds.foo.sel(s_rho=0, method="nearest"))

    hrrr = HRRR.create()
    hrrr.time.attrs = {"standard_name": "time"}
    result = apply_query(hrrr, variables=["foo"], selectors={"time": "2018-01-01"})
    expected = hrrr.foo.isel(time=0, step=-1)
    assert_equal(result["foo"].da, expected)

    # second time coordinate with same CF-compliant attrs
    hrrr.coords["time2"] = hrrr.time.copy()
    result = apply_query(hrrr, variables=["foo"], selectors={"time": "2018-01-01"})
    assert_equal(result["foo"].da, expected.assign_coords(time2=hrrr.time.data.item()))

    # out of order Z coordinates
    ds = ds.isel(M=[1, 0, 2])
    ds["M"].attrs["axis"] = "Z"
    ds.attrs["_xpublish_id"] = "foo"
    with pytest.raises(MissingParameterError):
        apply_query(ds, variables=["sst"], selectors={})


def test_apply_query_selectors_method_nearest():
    hrrr = HRRR.create().reindex(
        time=pd.date_range("2018-01-01", "2018-01-02", freq="6h")
    )
    actual = apply_query(
        hrrr,
        variables=["foo"],
        selectors={
            "time": "nearest::2018-01-01T01:15",
        },
    )
    expected = hrrr.sel(time="2018-01-01T01:15", method="nearest").isel(step=-1)
    xr.testing.assert_equal(actual["foo"].da, expected["foo"])

    # Test with multiple selectors (using existing step dimension)
    actual_multi = apply_query(
        hrrr,
        variables=["foo"],
        selectors={
            "time": "nearest::2018-01-01T01:15",
            "step": "nearest::45min",
        },
    )
    expected_multi = hrrr.sel(time="2018-01-01T01:15", method="nearest").sel(
        step="45min", method="nearest"
    )
    xr.testing.assert_equal(actual_multi["foo"].da, expected_multi["foo"])

    # Test ffill
    target_time = "2018-01-01T04:00"  # Between first two timestamps
    actual_ffill = apply_query(
        hrrr, variables=["foo"], selectors={"time": f"ffill::{target_time}"}
    )
    expected_ffill = hrrr.sel(time=target_time, method="ffill").isel(step=-1)
    xr.testing.assert_equal(actual_ffill["foo"].da, expected_ffill["foo"])

    # Test bfill
    actual_bfill = apply_query(
        hrrr, variables=["foo"], selectors={"time": f"bfill::{target_time}"}
    )
    expected_bfill = hrrr.sel(time=target_time, method="bfill").isel(step=-1)
    xr.testing.assert_equal(actual_bfill["foo"].da, expected_bfill["foo"])

    # Test backfill (alias for bfill)
    actual_backfill = apply_query(
        hrrr, variables=["foo"], selectors={"time": f"backfill::{target_time}"}
    )
    expected_backfill = hrrr.sel(time=target_time, method="backfill").isel(step=-1)
    xr.testing.assert_equal(actual_backfill["foo"].da, expected_backfill["foo"])

    target_time = "2018-01-01T04:00"
    actual = apply_query(
        hrrr, variables=["foo"], selectors={"time": f"pad::{target_time}"}
    )
    expected = hrrr.sel(time=target_time, method="pad").isel(step=-1)
    xr.testing.assert_equal(actual["foo"].da, expected["foo"])


def test_apply_query_selectors_exact():
    """Test exact selection method (explicit and implicit)"""
    hrrr = HRRR.create().reindex(
        time=pd.date_range("2018-01-01", "2018-01-02", freq="6h")
    )

    # Implicit exact (no method prefix)
    actual_implicit = apply_query(
        hrrr, variables=["foo"], selectors={"time": "2018-01-01T00:00"}
    )
    expected = hrrr.sel(time="2018-01-01T00:00").isel(step=-1)
    xr.testing.assert_equal(actual_implicit["foo"].da, expected["foo"])

    # Explicit exact
    actual_explicit = apply_query(
        hrrr, variables=["foo"], selectors={"time": "exact::2018-01-01T00:00"}
    )
    xr.testing.assert_equal(actual_explicit["foo"].da, expected["foo"])


def test_apply_query_with_string_selectors():
    ds = xr.Dataset(
        data_vars={
            "foo": (
                ("band", "band2", "offset", "x", "y"),
                np.arange(3240).reshape(3, 3, 3, 30, 4),
            )
        },
        coords={
            "x": (["x"], np.arange(30), {"axis": "X", "standard_name": "longitude"}),
            "y": (["y"], np.arange(4), {"axis": "Y", "standard_name": "latitude"}),
            "offset": (
                ["offset"],
                np.array(
                    [
                        np.timedelta64(i, "ns")
                        for i in [0, 3_600_000_000_000, 3_600_000_000_000 * 2]
                    ]
                ),
                {"standard_name": "offset"},
            ),
            "band": (["band"], [1, 2, 3], {"standard_name": "wavelength"}),
            "band2": (["band2"], ["1", "2", "3"], {"standard_name": "wavelength"}),
        },
    )

    selectors = {"band": "1", "band2": 2, "offset": "1 hours"}
    result = apply_query(ds, variables=["foo"], selectors=selectors)
    assert_equal(result["foo"].da, ds.foo.sel(band=1, band2="2", offset="1 hours"))


def test_datashader_nearest_regridding():
    ds = xr.Dataset(
        {"foo": (("x", "y"), np.arange(120).reshape(30, 4))},
        coords={"x": np.arange(30), "y": np.arange(4)},
    ).drop_indexes(("x", "y"))
    res = nearest_on_uniform_grid_quadmesh(ds.foo, "x", "y")
    assert_equal(ds.foo, res.astype(ds.foo.dtype).transpose(*ds.foo.dims))


@pytest.mark.parametrize("data_type", ["discrete", "continuous"])
@pytest.mark.parametrize("size", [1, 2, 4, 8])
@pytest.mark.parametrize("kind", ["u", "i", "f"])
async def test_datashader_casting(data_type, size, kind, pytestconfig):
    """
    For all dtypes, we render a bbox that will contain NaNs.
    Ensure that output is identical to that of rendering a float64 input.
    """
    if kind == "f" and size == 1:
        pytest.skip()
    if data_type == "discrete":
        attrs = {
            "flag_values": [0, 1, 2, 3],
            "flag_meanings": "a b c d",
        }
    else:
        attrs = {"valid_min": 0, "valid_max": 3}
    ds = xr.Dataset(
        {
            "foo": (
                ("x", "y"),
                np.array([[1, 2, 3], [0, 1, 2]], dtype=f"{kind}{size}"),
                attrs,
            )
        },
        coords={
            "x": ("x", [1, 2], {"standard_name": "longitude"}),
            "y": ("y", [1, 2, 3], {"standard_name": "latitude"}),
        },
    )
    query = QueryParams(
        variables=["foo"],
        crs=OutputCRS(CRS.from_user_input(4326)),
        bbox=OutputBBox(BBox(west=-5, east=5, south=-5, north=5)),
        selectors={},
        style="raster",
        width=256,
        height=256,
        variant="viridis",
        colorscalerange=None,
        format=ImageFormat.PNG,
    )
    actual = await pipeline(ds, query)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(actual, morecantile.Tile(0, 0, 0))
    expected = await pipeline(ds.astype(np.float64), query)
    assert compare_image_buffers(expected, actual)


async def test_bad_latitude_coordinates(png_snapshot, pytestconfig):
    """
    Regression test for https://github.com/holoviz/datashader/issues/1431
    IMPORTANT: This only fails on linux with datshader < 0.18.2
    """
    lon = -179.875 + 0.25 * np.arange(1440)
    lat = 89.875 - 0.25 * np.arange(720)
    ds = xr.DataArray(
        np.ones(shape=(720, 1440), dtype="f4"),
        dims=("lat", "lon"),
        coords={
            "lon": ("lon", lon, {"standard_name": "longitude"}),
            "lat": ("lat", lat, {"standard_name": "latitude"}),
        },
        attrs={"valid_min": 0, "valid_max": 2},
        name="foo",
    ).to_dataset()
    tile = morecantile.Tile(x=8, y=8, z=4)
    query = create_query_params(tms=WEBMERC_TMS, tile=tile)
    render = await pipeline(ds, query)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(render, tile)
    assert_render_matches_snapshot(render, png_snapshot)


async def test_transparent_tile_no_coverage(pytestconfig):
    """Test that a fully transparent PNG is returned when there's no bbox coverage."""
    # Create dataset bounded between lon=0 to 90, lat=0 to 90
    lon = np.linspace(0, 90, 91)
    lat = np.linspace(0, 90, 91)
    ds = xr.DataArray(
        np.ones(shape=(91, 91), dtype="f4"),
        dims=("lat", "lon"),
        coords={
            "lon": ("lon", lon, {"standard_name": "longitude"}),
            "lat": ("lat", lat, {"standard_name": "latitude"}),
        },
        attrs={"valid_min": 0, "valid_max": 1},
        name="foo",
    ).to_dataset()

    # Request a tile in bbox (-180 to -10, -80 to -70) - no overlap with dataset
    query = QueryParams(
        variables=["foo"],
        crs=OutputCRS(CRS.from_user_input(4326)),
        bbox=OutputBBox(BBox(west=-180, south=-80, east=-10, north=-70)),
        selectors={},
        style="raster",
        width=256,
        height=256,
        variant="viridis",
        colorscalerange=None,
        format=ImageFormat.PNG,
    )

    result = await pipeline(ds, query)

    # Verify the tile is fully transparent
    result.seek(0)
    img = Image.open(result)
    img = img.convert("RGBA")

    # Check that all pixels are fully transparent (alpha = 0)
    alpha_channel = np.array(img)[:, :, 3]
    assert np.all(alpha_channel == 0), "All pixels should be fully transparent"

    # Also check image dimensions
    assert img.size == (256, 256), "Image should have correct dimensions"


@pytest.mark.asyncio
@pytest.mark.parametrize("tile,tms", as_pytestparams(HRRR.tiles))
async def test_hrrr_multiple_vs_hrrr_rendering(tile, tms, pytestconfig):
    """Test that HRRR_MULTIPLE renders identically to HRRR for the same tiles."""
    from xpublish_tiles.testing.datasets import HRRR_MULTIPLE

    # Create both datasets
    hrrr_ds = HRRR.create()
    hrrr_multiple_ds = HRRR_MULTIPLE.create()

    # Create query params for the tile
    query_params = create_query_params(tile, tms)

    # Render both datasets with the same parameters
    hrrr_result = await pipeline(hrrr_ds, query_params)
    hrrr_multiple_result = await pipeline(hrrr_multiple_ds, query_params)

    if pytestconfig.getoption("--visualize"):
        visualize_tile(hrrr_result, tile)
        visualize_tile(hrrr_multiple_result, tile)

    # Compare the rendered images
    images_similar, _ = compare_image_buffers_with_debug(
        hrrr_result,
        hrrr_multiple_result,
        test_name="hrrr_multiple",
        tile_info=(tile, tms),
        debug_visual=pytestconfig.getoption("--debug-visual", default=False),
        debug_visual_save=pytestconfig.getoption("--debug-visual-save", default=False),
        mode="perceptual",
        perceptual_threshold=0.99,
    )
    assert images_similar, (
        f"HRRR_MULTIPLE should render identically to HRRR for tile {tile} "
        f"but images differ"
    )


@pytest.mark.asyncio
async def test_async_load_timeout():
    """Test that async load timeout raises AsyncLoadTimeoutError."""
    import asyncio
    from unittest.mock import patch

    ds = GLOBAL_6KM.create()
    tile = Tile(x=0, y=0, z=1)
    tms = morecantile.tms.get("WebMercatorQuad")
    query_params = create_query_params(tile, tms)

    original_load_async = xr.Dataset.load_async

    async def slow_load_async(self, **kwargs):
        await asyncio.sleep(2)
        return await original_load_async(self, **kwargs)

    with (
        config.set(async_load_timeout_per_tile=0.5),
        patch.object(xr.Dataset, "load_async", slow_load_async),
    ):
        with pytest.raises(AsyncLoadTimeoutError, match=r"timed out after 0\.5s"):
            await pipeline(ds, query_params)


@pytest.mark.asyncio
@pytest.mark.parametrize("ds", [TRIPOLE_ANTIMERIDIAN.create()])
@pytest.mark.parametrize(
    "tile",
    [Tile(x=0, y=0, z=2), Tile(x=0, y=1, z=2), Tile(x=0, y=0, z=1), Tile(z=3, y=2, x=1)],
)
async def test_tripole(ds, tile, png_snapshot, pytestconfig):
    tms = WEBMERC_TMS
    query_params = create_query_params(tile, tms)
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    # this dataset does not have global coverage, so we must skip the transparency check
    assert_render_matches_snapshot(result, png_snapshot, skip_transparency_check=True)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "tile",
    [
        pytest.param(Tile(x=0, y=0, z=0), id="0/0/0"),  # full image
        pytest.param(Tile(x=3, y=0, z=2), id="2/0/3"),  # antimeridian, north
        pytest.param(Tile(x=1, y=2, z=2), id="2/2/1"),  # no overlap
        pytest.param(Tile(x=7, y=7, z=4), id="4/7/7"),  # no overlap
        pytest.param(Tile(x=8, y=12, z=5), id="5/8/12"),  # artifacts?
        pytest.param(Tile(x=7, y=12, z=5), id="5/7/12"),  # artifacts?
        # Antimeridian coverage (WebMercator wraps at 180°; x=0 and x=2^z-1 at the seam).
        pytest.param(Tile(x=0, y=15, z=5), id="5/0/15"),  # west side of antimeridian
        pytest.param(Tile(x=31, y=15, z=5), id="5/31/15"),  # east side of antimeridian
        pytest.param(
            Tile(x=148, y=134, z=9), id="9/134/148"
        ),  # fully zoomed in, one pixel
    ],
)
async def test_healpix_tile(tile, png_snapshot, pytestconfig):
    """Test rendering a global healpix dataset tile."""
    ds = GLOBAL_HEALPIX_L3.create().compute()
    query_params = create_query_params(tile, WEBMERC_TMS, style="polygons")
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    # Pole-touching Healpix cells project to y≈∞ in Mercator, leaving a
    # handful of sliver pixels (<0.01%) uncovered at the tile's top edge.
    # Only tiles abutting the top of the map (y=0) are affected.
    assert_render_matches_snapshot(
        result, png_snapshot, skip_transparency_check=tile.y == 0
    )


@pytest.mark.xfail(reason="HEALPix L1 polar base cell not covering tile at z=9")
@pytest.mark.asyncio
async def test_healpix_l1_polar_high_zoom(png_snapshot):
    """HEALPix L1 has only 48 global cells (~60° across). A high-zoom
    WebMercator tile sitting inside a polar base cell should still render the
    cell — the polygon must cover the tile even though pole vertices project
    to y≈∞ (clamped).

    Regression for fully-transparent Tile(1, 0, 9) at HEALPix L1.
    """
    ds = _create_global_healpix(level=1, dtype=np.float64)
    tile = Tile(x=1, y=0, z=9)
    query_params = create_query_params(tile, WEBMERC_TMS, style="polygons")
    result = await pipeline(ds, query_params)
    assert_render_matches_snapshot(result, png_snapshot)


@pytest.mark.asyncio
async def test_healpix_crs84_nonzero_lon_convention(png_snapshot):
    """HEALPix vertices come out in the 0–360° lon convention. The CRS84 target
    is geographic-but-not-exact-EPSG:4326, so pyproj preserves lon values
    as-is (no wrap). Without a general degree-geographic fastpath, every cell
    lands off a western-hemisphere canvas.

    Regression for fully-transparent Tile(1,1,2) at CRS84 / HEALPix L2.
    """
    import morecantile

    ds = _create_global_healpix(level=2, dtype=np.float64)
    tms = morecantile.tms.get("WorldCRS84Quad")
    tile = Tile(x=1, y=1, z=2)
    query_params = create_query_params(tile, tms, style="polygons")
    result = await pipeline(ds, query_params)
    assert_render_matches_snapshot(result, png_snapshot)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "tile",
    [
        pytest.param(Tile(x=0, y=0, z=0), id="0/0/0"),  # full globe, NA visible
        pytest.param(Tile(x=1, y=1, z=2), id="2/1/1"),  # NA tile
        pytest.param(Tile(x=5, y=6, z=4), id="4/5/6"),  # zoomed over NA
        pytest.param(Tile(x=0, y=0, z=2), id="2/0/0"),  # outside NA (Pacific)
    ],
)
async def test_healpix_regional_na(tile, png_snapshot, pytestconfig):
    """Test rendering a regional (North America) healpix subset."""
    ds = REGIONAL_HEALPIX_NA.create().compute()
    query_params = create_query_params(tile, WEBMERC_TMS, style="polygons")
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(result, png_snapshot, skip_transparency_check=True)


_WORLDCRS84_TMS = morecantile.tms.get("WorldCRS84Quad")


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("tile", "tms"),
    [
        pytest.param(Tile(x=0, y=0, z=0), WEBMERC_TMS, id="0/0/0"),  # full globe
        pytest.param(Tile(x=0, y=0, z=1), WEBMERC_TMS, id="1/0/0"),  # NW quadrant
        pytest.param(Tile(x=1, y=1, z=1), WEBMERC_TMS, id="1/1/1"),  # SE quadrant
        pytest.param(Tile(x=1, y=1, z=2), WEBMERC_TMS, id="2/1/1"),  # equatorial face 0
        pytest.param(Tile(x=0, y=0, z=2), WEBMERC_TMS, id="2/0/0"),  # north polar cap
        pytest.param(Tile(x=0, y=3, z=2), WEBMERC_TMS, id="2/0/3"),  # south polar cap
        pytest.param(Tile(x=0, y=1, z=2), WEBMERC_TMS, id="2/0/1"),  # antimeridian west
        pytest.param(Tile(x=3, y=1, z=2), WEBMERC_TMS, id="2/3/1"),  # antimeridian east
        pytest.param(
            Tile(x=2, y=3, z=2), WEBMERC_TMS, id="2/2/3"
        ),  # south polar, east hemisphere
        pytest.param(Tile(x=7, y=5, z=3), WEBMERC_TMS, id="3/7/5"),  # rendering artifact
        pytest.param(Tile(x=4, y=4, z=4), WEBMERC_TMS, id="4/4/4"),  # rendering artifact
        pytest.param(Tile(x=1, y=2, z=3), WEBMERC_TMS, id="3/1/2"),  # rendering artifact
        pytest.param(Tile(x=6158, y=25779, z=16), WEBMERC_TMS, id="16/6158/25779"),
        # High-zoom tile near the north pole that triggers the polar-cap
        # cube-edge-seam fallback in CurvilinearCellIndex.sel: the AND-combine
        # of lat & lon masks is empty, so without the OR-union fallback the
        # tile renders fully transparent. Found by hypothesis (PR #242 CI).
        pytest.param(Tile(x=30948, y=0, z=16), WEBMERC_TMS, id="16/30948/0"),
        # WorldCRS84Quad reaches lat=±90 so these exercise the polar pole-edge
        # split; the high-zoom WebMercator tile sits on a face-cell edge that
        # was previously dropped by the cell-center-based lon break.
        pytest.param(Tile(x=0, y=0, z=0), _WORLDCRS84_TMS, id="wcrs84-0/0/0"),
        pytest.param(Tile(x=1, y=0, z=0), _WORLDCRS84_TMS, id="wcrs84-0/1/0"),
    ],
)
async def test_cubed_sphere_tile(tile, tms, png_snapshot, pytestconfig):
    """Render cubed-sphere tiles via the polygons pipeline."""
    ds = CUBED_SPHERE.create().compute()
    query_params = create_query_params(tile, tms, style="polygons")
    result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    assert_render_matches_snapshot(result, png_snapshot)


async def test_pipeline_raster_style_not_supported():
    ds = CUBED_SPHERE.create()
    tms = morecantile.tms.get("WebMercatorQuad")
    tile = morecantile.Tile(x=0, y=0, z=0)
    query_params = create_query_params(tile, tms, style="raster")
    with pytest.raises(ValueError, match="polygons"):
        await pipeline(ds, query_params)
