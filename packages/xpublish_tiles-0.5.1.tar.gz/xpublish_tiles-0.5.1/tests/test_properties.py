import io
import math
import uuid

import hypothesis.strategies as st
import morecantile
import numpy as np
import numpy.testing as npt
import pytest
from hypothesis import (
    assume,
    given,
    reproduce_failure,  # noqa: F401
    settings,
)
from hypothesis.strategies import DrawFn
from morecantile import Tile, TileMatrixSet
from PIL import Image
from pyproj import CRS
from pyproj.aoi import BBox

import xarray as xr
from tests import create_query_params
from xpublish_tiles import config
from xpublish_tiles.grids import Rectilinear
from xpublish_tiles.lib import TileTooBigError, check_transparent_pixels
from xpublish_tiles.pipeline import pipeline
from xpublish_tiles.testing.datasets import (
    CUBED_SPHERE,
    EU3035_HIRES,
    HRRR,
    HRRR_MULTIPLE,
    REDGAUSS_N320,
    Dim,
    _create_global_healpix,
    uniform_grid,
)
from xpublish_tiles.testing.lib import (
    compare_image_buffers_with_debug,
    visualize_tile,
)
from xpublish_tiles.xpublish.tiles.metadata import allowed_styles


@st.composite
def global_rectilinear_datasets(
    draw: DrawFn,
    allow_decreasing_lat: bool = True,
    allow_categorical: bool = True,
    maxsize: int = 2000,
    perturb: bool = True,
) -> xr.Dataset:
    """Strategy that generates global rectilinear datasets using uniform_grid with random parameters.

    Parameters
    ----------
    allow_decreasing_lat: bool
    allow_categorical: bool
    maxsize: int
        Max size of either dimension
    perturb: bool
        Whether to add tiny perturbations to the bounds of each axis, for robustness testing
    """
    # Generate dimensions between 100 and 1000 to ensure sufficient coverage
    # Smaller datasets may have gaps when projected
    # Prioritize sizes that exercise coarsening
    size_st = st.one_of(
        st.sampled_from([i for i in [256, 512, 1024, 2048] if i < maxsize]),
        st.integers(min_value=100, max_value=maxsize),
    )
    nlat = draw(size_st)
    nlon = draw(size_st)

    # Generate latitude ordering
    lat_ascending = not allow_decreasing_lat or draw(st.booleans())
    delta_lat = 0 if not perturb else draw(st.floats(-1e-3, 1e-3))
    delta_lon = 0 if not perturb else draw(st.floats(-1e-3, 1e-3))
    lats = np.linspace(-90 - delta_lat, 90 + delta_lat, nlat)
    if not lat_ascending:
        lats = lats[::-1]

    # Generate longitude ordering
    lon_0_360 = draw(st.booleans())
    if lon_0_360:
        lons = np.linspace(0 - delta_lon, 360 + delta_lon, nlon, endpoint=False)
    else:
        lons = np.linspace(-180 - delta_lon, 180 + delta_lon, nlon, endpoint=False)

    # Use full size as chunk size (single chunk)
    dims = (
        Dim(
            name="latitude",
            size=nlat,
            chunk_size=nlat,
            data=lats,
            attrs={"units": "degrees_north", "axis": "Y"},
        ),
        Dim(
            name="longitude",
            size=nlon,
            chunk_size=nlon,
            data=lons,
            attrs={"units": "degrees_east", "axis": "X"},
        ),
    )

    is_categorical = allow_categorical and draw(st.booleans())

    if is_categorical:
        # Generate categorical data with flag_values
        num_categories = draw(st.integers(min_value=2, max_value=12))
        flag_values = list(range(num_categories))

        flag_meanings = " ".join([f"category_{i}" for i in flag_values])

        attrs = {
            "long_name": "Test categorical data",
            "flag_meanings": flag_meanings,
            "flag_values": flag_values,
        }
        dtype = np.uint8
    else:
        attrs = {
            "long_name": "Test continuous data",
            "valid_min": -1,
            "valid_max": 1,
        }
        dtype = np.float32

    ds = uniform_grid(dims=dims, dtype=dtype, attrs=attrs)
    return ds


@st.composite
def global_curvilinear_datasets(
    draw: DrawFn,
    allow_decreasing_lat: bool = True,
    allow_categorical: bool = True,
    maxsize: int = 2000,
    perturb: bool = True,
) -> xr.Dataset:
    """Strategy that generates global curvilinear datasets by broadcasting rectilinear coordinates."""
    rect = draw(
        global_rectilinear_datasets(
            allow_decreasing_lat=allow_decreasing_lat,
            allow_categorical=allow_categorical,
            maxsize=maxsize,
            perturb=perturb,
        )
    )

    curvi = rect.rename(latitude="nlat", longitude="nlon")
    newlat, newlon = np.meshgrid(curvi.nlat.data, curvi.nlon.data, indexing="ij")
    curvi = curvi.assign_coords(
        longitude=(("nlon", "nlat"), newlon.T, {"standard_name": "longitude"}),
        latitude=(("nlon", "nlat"), newlat.T, {"standard_name": "latitude"}),
    )
    curvi["foo"].attrs["coordinates"] = "longitude latitude"
    return curvi


@st.composite
def global_healpix_datasets(draw: DrawFn) -> xr.Dataset:
    """Strategy that returns a global HEALPix grid dataset at a sampled refinement level.

    TODO: include coarse levels 1 and 2 once the polygon rasterization covers
    whole-tile polar base cells (see test_healpix_l1_polar_high_zoom xfail).
    """
    level = draw(st.sampled_from([3, 4]))
    ds = _create_global_healpix(level=level, dtype=np.float64)
    ds.attrs["_xpublish_id"] = f"global_healpix_l{level}_proptest"
    return ds


@st.composite
def global_cubed_sphere_datasets(draw: DrawFn) -> xr.Dataset:
    """Strategy that returns a global cubed-sphere (Faceted) grid dataset."""
    ds = CUBED_SPHERE.create().copy(deep=True)
    ds.attrs["_xpublish_id"] = "cubed_sphere_proptest"
    return ds


@st.composite
def global_unstructured_datasets(draw: DrawFn) -> xr.Dataset:
    """Strategy that returns global unstructured grid datasets.

    Currently returns REDGAUSS_N320 (Reduced Gaussian Grid N320).
    """
    # copy to avoid interfering with other tests!!!
    ds = REDGAUSS_N320.create().copy(deep=True)

    # this is yuck; but things are too slow without caching the grid object
    attr = ds.attrs["_xpublish_id"] + "_proptest"

    # Rescale latitude to full -90 to 90 range, this means we can keep the present property test
    lat = ds.latitude.values
    lat_min, lat_max = lat.min(), lat.max()
    lat_scaled = -90 + (lat - lat_min) / (lat_max - lat_min) * 180
    # Occasionally reverse the latitude vector
    if draw(st.booleans()):
        lat_scaled = lat_scaled[::-1]
        attr += "_reversed_lat"

    ds = ds.assign_coords(latitude=("point", lat_scaled))

    # Occasionally convert longitude from 0-360 to -180-180 convention
    if draw(st.booleans()):
        lon = ds.longitude.values
        lon_converted = np.where(lon > 180, lon - 360, lon)
        ds = ds.assign_coords(longitude=("point", lon_converted))
        attr += "_converted_lon"

    ds.attrs["_xpublish_id"] = attr
    return ds


# Combine regular, unstructured, healpix, and cubed-sphere global datasets
all_global_datasets = st.one_of(
    global_rectilinear_datasets(allow_categorical=False),
    global_unstructured_datasets(),
    global_healpix_datasets(),
    global_cubed_sphere_datasets(),
)


@st.composite
def tile_matrix_sets(draw: DrawFn) -> str:
    """Strategy that returns standard TileMatrixSet names from morecantile."""
    tms_name = draw(st.sampled_from(["WebMercatorQuad", "WorldCRS84Quad"]))
    return tms_name


@st.composite
def tiles(
    draw: DrawFn,
    tile_matrix_sets: st.SearchStrategy[str] = tile_matrix_sets(),
) -> Tile:
    """Strategy that returns morecantile.Tile objects based on a TileMatrixSet."""
    tms_name: str = draw(tile_matrix_sets)
    tms: TileMatrixSet = morecantile.tms.get(tms_name)
    # Sample uniformly from available zoom levels
    zoom_levels = list(range(len(tms.tileMatrices)))
    zoom = draw(st.sampled_from(zoom_levels))
    minmax = tms.minmax(zoom)
    x = draw(st.integers(min_value=minmax["x"]["min"], max_value=minmax["x"]["max"]))
    y = draw(st.integers(min_value=minmax["y"]["min"], max_value=minmax["y"]["max"]))
    return Tile(x=x, y=y, z=zoom)


@st.composite
def tile_and_tms(
    draw: DrawFn,
    *,
    tile_matrix_sets: st.SearchStrategy[str] = tile_matrix_sets(),
    bbox=None,
) -> tuple[Tile, TileMatrixSet]:
    """Strategy that returns a tile and its corresponding TileMatrixSet.

    Args:
        tile_matrix_sets: Strategy for selecting TileMatrixSet names
        bbox: Optional bounding box to constrain tiles to overlap with this area
    """
    tms_name: str = draw(tile_matrix_sets)
    tms: TileMatrixSet = morecantile.tms.get(tms_name)
    # Sample uniformly from available zoom levels
    zoom_levels = list(range(len(tms.tileMatrices)))
    zoom = draw(st.sampled_from(zoom_levels))

    if bbox is not None:
        # Get the tiles at the four corners of the bounding box to define the range
        # This is much more efficient than listing all tiles at high zoom levels
        try:
            # Get tiles for the four corners
            sw_tile = tms.tile(bbox.west, bbox.south, zoom)  # Southwest corner
            se_tile = tms.tile(bbox.east, bbox.south, zoom)  # Southeast corner
            nw_tile = tms.tile(bbox.west, bbox.north, zoom)  # Northwest corner
            ne_tile = tms.tile(bbox.east, bbox.north, zoom)  # Northeast corner

            # Determine the x and y ranges from the corner tiles
            min_x = min(sw_tile.x, se_tile.x, nw_tile.x, ne_tile.x)
            max_x = max(sw_tile.x, se_tile.x, nw_tile.x, ne_tile.x)
            min_y = min(sw_tile.y, se_tile.y, nw_tile.y, ne_tile.y)
            max_y = max(sw_tile.y, se_tile.y, nw_tile.y, ne_tile.y)

            # Choose a random tile within the range
            x = draw(st.integers(min_value=min_x, max_value=max_x))
            y = draw(st.integers(min_value=min_y, max_value=max_y))
            tile = Tile(x=x, y=y, z=zoom)
        except Exception:
            # If we can't get tiles for the bbox (e.g., bbox outside TMS bounds),
            # fall back to any valid tile
            minmax = tms.minmax(zoom)
            x = draw(
                st.integers(min_value=minmax["x"]["min"], max_value=minmax["x"]["max"])
            )
            y = draw(
                st.integers(min_value=minmax["y"]["min"], max_value=minmax["y"]["max"])
            )
            tile = Tile(x=x, y=y, z=zoom)
    else:
        # Original behavior - any valid tile for this zoom level
        minmax = tms.minmax(zoom)
        x = draw(st.integers(min_value=minmax["x"]["min"], max_value=minmax["x"]["max"]))
        y = draw(st.integers(min_value=minmax["y"]["min"], max_value=minmax["y"]["max"]))
        tile = Tile(x=x, y=y, z=zoom)

    return tile, tms


@pytest.mark.asyncio
@settings(max_examples=500)
@given(
    tile_tms=tile_and_tms(),
    ds=all_global_datasets,
    data=st.data(),
)
async def test_property_global_render_no_transparent_tile(
    tile_tms: tuple[Tile, TileMatrixSet],
    ds: xr.Dataset,
    data: st.DataObject,
    pytestconfig,
):
    """Property test that global datasets should never produce transparent pixels."""
    tile, tms = tile_tms
    n_rows = 2**tile.z
    # HEALPix polar base cells don't reliably cover near-polar tiles (see
    # ``test_healpix_l1_polar_high_zoom`` xfail). L3's polar pixel centre is
    # at ~84.4° and the uncovered band widens (in tile-rows) with zoom; scale
    # the polar-row skip accordingly. At z=6: 3 rows; z=8: 4; z=10: 16; etc.
    is_healpix = ds.attrs.get("_xpublish_id", "").startswith("global_healpix")
    hp_margin = max(3, n_rows // 64)
    assume(not is_healpix or (hp_margin <= tile.y < n_rows - hp_margin))
    style = data.draw(st.sampled_from(allowed_styles(ds)))
    query_params = create_query_params(
        tile,
        tms,
        size=2 ** data.draw(st.sampled_from(list(range(6, 11)))),
        style=style,
    )
    with config.set(max_pixel_factor=2):
        result = await pipeline(ds, query_params)
    if pytestconfig.getoption("--visualize"):
        visualize_tile(result, tile)
    transparent_percent = check_transparent_pixels(result.getvalue())
    if is_healpix:
        # HEALPix polygon rendering still leaves seams along shared cell edges
        # that datashader doesn't fully close. Just assert the tile is not
        # fully transparent.
        assert transparent_percent < 100, (
            f"Tile {tile} is fully transparent for HEALPix dataset"
        )
    else:
        assert transparent_percent == 0, (
            f"Found {transparent_percent:.4f}% transparent pixels in tile {tile}"
        )


@pytest.mark.asyncio
@given(data=st.data(), rect=global_rectilinear_datasets(allow_categorical=False))
@settings(max_examples=50)
async def test_property_equivalent_grids_render_equivalently(
    rect: xr.Dataset, data: st.DataObject, pytestconfig
):
    """
    Result from
    1. rectilinear grid
    2. curvilinear grid constructed from broadcasting out rectilinear grid
    3. unstructured grid constructed from stacking rectilinear grid
    must be preceptually very very similar.

    Note that this test receives new datasets and repeatedly triangulating the grid is slow;
    so we run that comparison in a different test with fewer datasets, and more tiles per dataset.
    """

    curvi = rect.rename(latitude="nlat", longitude="nlon")
    newlat, newlon = np.meshgrid(curvi.nlat.data, curvi.nlon.data, indexing="ij")
    curvi = curvi.assign_coords(
        longitude=(("nlon", "nlat"), newlon.T, {"standard_name": "longitude"}),
        latitude=(("nlon", "nlat"), newlat.T, {"standard_name": "latitude"}),
    )
    curvi["foo"].attrs["coordinates"] = "longitude latitude"

    # rectilinear = guess_grid_system(ds, "foo")
    # curvilinear = guess_grid_system(ds, "foo")

    # Check that grid indexers are the same
    # TODO: this is a hard invariant to maintain!
    #       because of rounding errors determining the bounds :(
    # bounds = tms.bounds(tile)
    # bbox = round_bbox(
    #     BBox(west=bounds.left, east=bounds.right, south=bounds.bottom, north=bounds.top),
    # )
    # npt.assert_array_equal(
    #     rectilinear.sel(rect_ds.foo, bbox=bbox).data,
    #     curvilinear.sel(ds.foo, bbox=bbox).data,
    # )

    lon, lat = curvi.longitude, curvi.latitude
    transposed = curvi.assign_coords(
        longitude=lon.transpose() if data.draw(st.booleans()) else curvi.longitude,
        latitude=lat.transpose() if data.draw(st.booleans()) else curvi.latitude,
    )

    # Compare images with optional debug visualization using perceptual comparison
    compare = lambda buffer1, buffer2, tile, tms: compare_image_buffers_with_debug(
        buffer1,
        buffer2,
        test_name="grid_equivalency",
        tile_info=(tile, tms),
        debug_visual=pytestconfig.getoption("--debug-visual", default=False),
        debug_visual_save=pytestconfig.getoption("--debug-visual-save", default=False),
        mode="perceptual",
        perceptual_threshold=0.9,  # 90% similarity threshold
    )

    for _ in range(10):
        tile, tms = data.draw(tile_and_tms())
        query = create_query_params(tile, tms)

        with config.set(transform_chunk_size=256, detect_approx_rectilinear=False):
            rectilinear_result = await pipeline(rect, query)

            curvilinear_result = await pipeline(curvi, query)
            images_similar, ssim_score = compare(
                rectilinear_result, curvilinear_result, tile, tms
            )
            assert images_similar, (
                f"Rectilinear and curvilinear results differ for tile {tile} (SSIM: {ssim_score:.4f})"
            )

            transposed_result = await pipeline(transposed, query)
            images_similar, ssim_score = compare(
                rectilinear_result, transposed_result, tile, tms
            )
            assert images_similar, (
                f"Rectilinear and *transposed* curvilinear results differ for tile {tile} (SSIM: {ssim_score:.4f})"
            )


@pytest.mark.asyncio
@given(
    data=st.data(),
    # disable perturbing the edges because for the triangular grid
    # we treat these as cell vertices, not centers
    rect=global_rectilinear_datasets(allow_categorical=False, maxsize=720, perturb=False),
)
@settings(max_examples=20)
async def test_rectilinear_triangular_equivalency(data, rect, pytestconfig):
    stacked = rect.load().stack(point=("latitude", "longitude"), create_index=False)
    stacked.attrs["_xpublish_id"] = str(uuid.uuid4())

    for _ in range(20):
        tile, tms = data.draw(tile_and_tms())
        query = create_query_params(tile, tms)

        with config.set(transform_chunk_size=256, detect_approx_rectilinear=False):
            rectilinear_result = await pipeline(rect, query)

            triangular_result = await pipeline(stacked, query)
            images_similar, ssim_score = compare_image_buffers_with_debug(
                rectilinear_result,
                triangular_result,
                test_name="rectilinear_triangular_equivalency",
                tile_info=(tile, tms),
                debug_visual=pytestconfig.getoption("--debug-visual", default=False),
                debug_visual_save=pytestconfig.getoption(
                    "--debug-visual-save", default=False
                ),
                mode="perceptual",
                perceptual_threshold=0.89,  # 89% similarity threshold
            )
            assert images_similar, (
                f"Rectilinear and triangular results differ for tile {tile} (SSIM: {ssim_score:.4f})"
            )


@pytest.mark.asyncio
@given(dataset=st.sampled_from([HRRR_MULTIPLE, EU3035_HIRES, HRRR]), data=st.data())
async def test_projected_coordinate_succeeds(dataset, data, pytestconfig):
    """Test that projected coordinate datasets can successfully render tiles within their bbox."""
    ds = dataset.create()

    # Use the strategy to generate a tile and TMS that overlaps with dataset bbox
    bbox = ds.attrs["bbox"]
    tile, tms = data.draw(tile_and_tms(bbox=bbox))

    # Create query parameters and render the tile
    query_params = create_query_params(tile, tms)

    try:
        result = await pipeline(ds, query_params)
        # Basic validation - ensure we got a result
        assert result is not None
        result_bytes = result.getvalue()
        assert len(result_bytes) > 0

        # Verify it's a valid PNG
        # PNG files start with an 8-byte signature
        png_signature = b"\x89PNG\r\n\x1a\n"
        assert result_bytes[:8] == png_signature, (
            f"Result does not have valid PNG signature, got {result_bytes[:8]!r}"
        )

        if pytestconfig.getoption("--visualize"):
            visualize_tile(result, tile)
    except TileTooBigError:
        assume(False)


@pytest.mark.asyncio
@given(
    tile_tms=tile_and_tms(),
    ds=all_global_datasets,
    data=st.data(),
)
@settings(max_examples=50)
# @reproduce_failure('6.138.3', b'AXicc2R0ZECFDBoMUKBhH5Dke+njyj8MjqyO3I4MAI0xCBQ=')
async def test_zoom_in_doesnt_change_rendering(tile_tms, ds, data, pytestconfig) -> None:
    style = data.draw(st.sampled_from(allowed_styles(ds)))
    """Property test that zooming in doesn't change rendering.

    For a quadtree TMS, rendering a tile at a large size should produce the same
    result as rendering a sub-tile at a higher zoom level that covers the same sub-area.

    We render a parent tile at 2048x2048, then test 20 randomly generated sub-tiles
    at higher zoom levels (up to 6 levels deeper, which gives us 32x32 minimum tile size).

    Conceptual diagram (example with zoom delta = 2):

        Parent tile (x, y, z) @ 2048×2048:
        ┌──────────────────────────┐
        │▓▓▓▓▓▓│      │      │     │  Child tiles at zoom z+2
        │▓▓▓▓▓▓│      │      │     │  (4×4 grid, each 512×512)
        │▓▓▓▓▓▓│      │      │     │
        ├──────┼──────┼──────┼─────┤  Shaded tile (▓▓) is at
        │      │      │      │     │  top-left corner, aligned
        │      │      │      │     │  with parent boundary
        │      │      │      │     │
        ├──────┼──────┼──────┼─────┤
        │      │      │      │     │
        │      │      │      │     │
        │      │      │      │     │
        ├──────┼──────┼──────┼─────┤
        │      │      │      │     │
        │      │      │      │     │
        │      │      │      │     │
        └──────┴──────┴──────┴─────┘

        We render the child tile (▓▓) independently at 512×512,
        then compare it to the corresponding top-left 512×512
        region extracted from the parent rendering.

    In a quadtree, tile (x, y, z) contains 2^n × 2^n child tiles at zoom z+n:
        Child tile coordinates: (2^n·x + i, 2^n·y + j, z+n)
        where i, j ∈ [0, 2^n - 1]

    TODO:
    1. Support higher perceptual threshold, even without coarsening; This might require constructing appropriate datasets
       with shapes and spacings that match the parent tile properly.
    """
    tile, tms = tile_tms

    # Assert that TMS is a quadtree
    # WebMercatorQuad and WorldCRS84Quad are both quadtrees
    assert tms.id in [
        "WebMercatorQuad",
        "WorldCRS84Quad",
    ], f"TMS {tms.id} is not a known quadtree"

    # Render parent tile at 2048x2048
    parent_size = 2048
    parent_query = create_query_params(tile, tms, size=parent_size, style=style)

    with config.set(max_pixel_factor=20000):
        parent_result = await pipeline(ds, parent_query)

    # Convert parent PNG to numpy array
    parent_result.seek(0)
    parent_img = Image.open(parent_result)
    parent_array = np.array(parent_img)

    # Pick a child zoom level (absolute)
    # We choose minimum tile size of 32x32 (2048/2^6 = 32), so max delta is 6
    # We use 4, because at higher zoom levels, pixels can move around a bit.
    max_child_zoom = min(tile.z + 4, tms.maxzoom)
    assume(max_child_zoom > tile.z)  # Must be able to zoom in at least one level

    # Test 10 randomly generated child tiles
    for _ in range(10):
        child_zoom = data.draw(
            st.integers(min_value=tile.z + 1, max_value=max_child_zoom)
        )

        # Calculate the zoom delta between parent and child
        zoom_delta = child_zoom - tile.z

        # At zoom level child_zoom, the parent tile (x, y, tile.z) corresponds to
        # 2^delta × 2^delta child tiles with coordinates ranging from:
        # x: [2^delta * parent_x, 2^delta * parent_x + 2^delta - 1]
        # y: [2^delta * parent_y, 2^delta * parent_y + 2^delta - 1]
        num_tiles_per_side = 2**zoom_delta

        # Pick a random child tile within this range
        child_x_offset = data.draw(
            st.integers(min_value=0, max_value=num_tiles_per_side - 1)
        )
        child_y_offset = data.draw(
            st.integers(min_value=0, max_value=num_tiles_per_side - 1)
        )

        child_tile = Tile(
            x=num_tiles_per_side * tile.x + child_x_offset,
            y=num_tiles_per_side * tile.y + child_y_offset,
            z=child_zoom,
        )

        # Calculate the size to render the child tile
        # Since parent is 2048x2048 and covers 2^zoom_delta × 2^zoom_delta child tiles,
        # each child tile corresponds to (2048 / 2^zoom_delta)^2 pixels
        child_size = parent_size // num_tiles_per_side

        # Render the child tile
        child_query = create_query_params(child_tile, tms, size=child_size, style=style)
        child_result = await pipeline(ds, child_query)

        # Extract corresponding region from parent
        pixel_x_start = child_x_offset * child_size
        pixel_y_start = child_y_offset * child_size
        pixel_x_end = (child_x_offset + 1) * child_size
        pixel_y_end = (child_y_offset + 1) * child_size

        parent_region = parent_array[pixel_y_start:pixel_y_end, pixel_x_start:pixel_x_end]

        # Convert parent region to PNG buffer for comparison
        parent_region_buffer = io.BytesIO()
        Image.fromarray(parent_region).save(parent_region_buffer, format="PNG")
        parent_region_buffer.seek(0)
        child_result.seek(0)

        # Compare with perceptual similarity
        images_similar, ssim_score = compare_image_buffers_with_debug(
            buffer1=parent_region_buffer,  # expected (parent region)
            buffer2=child_result,  # actual (child tile)
            test_name=f"zoom_consistency_z{tile.z}_{tile.x}_{tile.y}_to_z{child_tile.z}_{child_tile.x}_{child_tile.y}",
            tile_info=(child_tile, tms),
            debug_visual=pytestconfig.getoption("--debug-visual", default=False),
            debug_visual_save=pytestconfig.getoption(
                "--debug-visual-save", default=False
            ),
            mode="perceptual",
            perceptual_threshold=0.95 if style == "polygons" else 0.98,
        )

        assert images_similar, (
            f"Child tile {child_tile} (zoom {child_zoom}, delta +{zoom_delta}) doesn't match parent tile {tile} (zoom {tile.z}) region (SSIM: {ssim_score:.4f})"
        )


@given(
    ds=st.one_of(
        global_rectilinear_datasets(allow_categorical=False, maxsize=300, perturb=False),
        global_curvilinear_datasets(allow_categorical=False, maxsize=300, perturb=False),
    ),
    roll_fraction=st.floats(min_value=0.1, max_value=0.9),
    data=st.data(),
)
@settings(max_examples=100)
def test_roll_invariance(
    ds: xr.Dataset,
    roll_fraction: float,
    data: st.DataObject,
):
    """
    Property test: selecting from original and rolled datasets should
    return equivalent data values.

    Rolling a dataset shifts the longitude coordinate system but doesn't
    change the physical data. A correct grid selection implementation
    should select the same physical data regardless of the coordinate offset.

    This tests our ability to handle discontinuities in the *middle* of the dataset,
    like tripolar grids used for global HYCOM and POP.
    """
    # Handle both rectilinear (longitude dim) and curvilinear (nlon dim) datasets
    lon_dim = "longitude" if "longitude" in ds.sizes else "nlon"
    nlon = ds.sizes[lon_dim]
    roll_amount = math.ceil(roll_fraction * nlon) % nlon

    # Roll the dataset
    ds_rolled = ds.roll({lon_dim: roll_amount}, roll_coords=True)
    ds_rolled.attrs["_xpublish_id"] = (
        ds.attrs.get("_xpublish_id", "") + f"_rolled_{roll_amount}"
    )

    # Determine coordinate names based on dataset type
    # Curvilinear: dims are nlat/nlon, 1D coords are nlat/nlon
    # Rectilinear: dims are latitude/longitude, coords are latitude/longitude
    is_curvilinear = "nlon" in ds.sizes
    x_coord = "nlon" if is_curvilinear else "longitude"
    y_coord = "nlat" if is_curvilinear else "latitude"

    # Create grids for both datasets
    grid_original = Rectilinear.from_dataset(ds, CRS.from_epsg(4326), x_coord, y_coord)
    grid_rolled = Rectilinear.from_dataset(
        ds_rolled, CRS.from_epsg(4326), x_coord, y_coord
    )

    # The detected bboxes should be identical for both grids
    assert grid_original.bbox == grid_rolled.bbox, (
        f"BBox mismatch: original {grid_original.bbox} vs rolled {grid_rolled.bbox}"
    )

    west, east = sorted(
        data.draw(
            st.lists(
                st.floats(
                    min_value=-180, max_value=180, allow_nan=False, allow_subnormal=False
                ),
                min_size=2,
                max_size=2,
            )
        )
    )
    south, north = sorted(
        data.draw(
            st.lists(
                st.floats(
                    min_value=-90, max_value=90, allow_nan=False, allow_subnormal=False
                ),
                min_size=2,
                max_size=2,
            )
        )
    )
    # Round to 12 decimal places to avoid float precision issues
    west, east = round(west, 12), round(east, 12)
    south, north = round(south, 12), round(north, 12)
    assume(east - west >= 0.0001)
    assume(north - south >= 0.0001)
    bbox = BBox(west=west, east=east, south=south, north=north)

    # Select from both grids
    slicers_original = grid_original.sel(bbox=bbox)
    slicers_rolled = grid_rolled.sel(bbox=bbox)

    # Apply slicers to get subsets
    def apply_slicers_simple(dataset, slicers, x_coord, y_coord):
        lon_slices = slicers.get(x_coord, [slice(None)])
        lat_slice = slicers.get(y_coord, [slice(None)])[0]

        parts = []
        for lon_slice in lon_slices:
            part = dataset.foo.isel({x_coord: lon_slice, y_coord: lat_slice})
            parts.append(part)

        if len(parts) == 1:
            return parts[0]
        return xr.concat(parts, dim=x_coord)

    subset_original = apply_slicers_simple(ds, slicers_original, x_coord, y_coord)
    subset_rolled = apply_slicers_simple(ds_rolled, slicers_rolled, x_coord, y_coord)

    # Get longitude coordinate values for debug output (handle both 1D and 2D coords)
    orig_lon = ds[x_coord] if is_curvilinear else ds.longitude
    rolled_lon = ds_rolled[x_coord] if is_curvilinear else ds_rolled.longitude

    # Check that we selected the same number of elements
    assert subset_original.shape == subset_rolled.shape, (
        f"Shape mismatch: original {subset_original.shape} vs rolled {subset_rolled.shape}\n"
        f"bbox={bbox}, roll_amount={roll_amount}\n"
        f"original coords: lon=[{float(orig_lon.min()):.1f}, {float(orig_lon.max()):.1f}]\n"
        f"rolled coords: lon=[{float(rolled_lon.min()):.1f}, {float(rolled_lon.max()):.1f}]\n"
        f"grid_original breaks: [{grid_original.left_break:.1f}, {grid_original.right_break:.1f}]\n"
        f"grid_rolled breaks: [{grid_rolled.left_break:.1f}, {grid_rolled.right_break:.1f}]\n"
        f"slicers_original: {slicers_original}\n"
        f"slicers_rolled: {slicers_rolled}"
    )

    # Compare data values sorted by their values (coordinate-independent comparison)
    # Since the same physical locations should be selected, the sorted data values should match
    original_flat = np.sort(subset_original.values.ravel())
    rolled_flat = np.sort(subset_rolled.values.ravel())

    npt.assert_array_almost_equal(
        original_flat,
        rolled_flat,
        err_msg=f"Data differs for bbox={bbox}, roll_amount={roll_amount}",
    )
