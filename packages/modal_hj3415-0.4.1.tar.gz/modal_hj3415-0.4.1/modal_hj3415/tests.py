from django.template import Context, Template
from django.test import TestCase

from .models import ModalLinkVideo, ModalSingleBG
from .templatetags.modal_tags import sanitize_modal_html, sanitize_modal_url


class ModalTemplateTagTests(TestCase):
    def test_sanitize_modal_html_allows_whitelisted_tags_only(self):
        value = '<strong>safe</strong><script>alert(1)</script><span onclick="x()">ok</span>'

        rendered = str(sanitize_modal_html(value))

        self.assertIn("<strong>safe</strong>", rendered)
        self.assertIn("<span>ok</span>", rendered)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", rendered)
        self.assertNotIn('onclick=', rendered)

    def test_sanitize_modal_url_blocks_javascript_scheme(self):
        self.assertEqual(sanitize_modal_url("javascript:alert(1)"), "")
        self.assertEqual(sanitize_modal_url("https://example.com"), "https://example.com")

    def test_show_modal_ignores_unknown_priority_keys(self):
        ModalSingleBG.objects.create(
            activate=True,
            h3="Headline",
            h1="Main",
            h2="Body",
        )

        rendered = Template(
            "{% load modal_tags %}{% show_modal priority=priority %}"
        ).render(Context({"priority": ("bad_key", "single_bg")}))

        self.assertIn("popupModal-ModalSingleBG-", rendered)
        self.assertIn("-content", rendered)

    def test_show_modal_uses_distinct_modal_and_content_ids(self):
        popup = ModalSingleBG.objects.create(
            activate=True,
            h3="Headline",
            h1="Main",
            h2="Body",
        )
        modal_id = f"popupModal-ModalSingleBG-{popup.pk}"

        rendered = Template(
            "{% load modal_tags %}{% show_modal %}"
        ).render(Context({}))

        self.assertIn(f'id="{modal_id}"', rendered)
        self.assertIn(f'id="{modal_id}-content"', rendered)

    def test_single_bg_template_sanitizes_text_and_url(self):
        popup = ModalSingleBG.objects.create(
            activate=True,
            h3='<strong>Title</strong><img src=x onerror=alert(1)>',
            h1='Main<script>alert(1)</script>',
            h2='Line1<br><span onclick="evil()">Line2</span>',
            link_url='javascript:alert(1)',
            link_text='<em>Open</em>',
        )

        rendered = Template(
            "{% load modal_tags %}{% include 'modal_hj3415/single_bg.html' with popup=popup section_id='modal-1' %}"
        ).render(Context({"popup": popup}))

        self.assertIn("<strong>Title</strong>", rendered)
        self.assertIn("&lt;img src=x onerror=alert(1)&gt;", rendered)
        self.assertIn("Main&lt;script&gt;alert(1)&lt;/script&gt;", rendered)
        self.assertIn("<span>Line2</span>", rendered)
        self.assertNotIn('href="javascript:alert(1)"', rendered)

    def test_link_video_template_sanitizes_video_link(self):
        popup = ModalLinkVideo.objects.create(
            activate=True,
            h2="Heading",
            p="Body",
            link_video_url="javascript:alert(1)",
        )

        rendered = Template(
            "{% load modal_tags %}{% include 'modal_hj3415/link_video.html' with popup=popup section_id='modal-2' %}"
        ).render(Context({"popup": popup}))

        self.assertNotIn("glightbox", rendered)
