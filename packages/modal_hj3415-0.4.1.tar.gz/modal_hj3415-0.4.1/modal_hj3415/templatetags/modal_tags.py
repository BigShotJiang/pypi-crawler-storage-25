#templatetags/modal_tags.py

from html import escape
from html.parser import HTMLParser
from urllib.parse import urlsplit

from django import template
from django.utils.safestring import mark_safe

from ..models import ModalImageOnly, ModalSingleBG, ModalLinkVideo, ModalRotateBG

register = template.Library()

ALLOWED_PRIORITY_KEYS = ("image_only", "single_bg", "link_video", "rotate_bg")
ALLOWED_HTML_TAGS = {"br", "strong", "span", "em", "b", "i", "u"}
ALLOWED_URL_SCHEMES = {"", "http", "https", "mailto", "tel"}

TEMPLATE_MAP = {
    ModalRotateBG: "modal_hj3415/rotate_bg.html",
    ModalLinkVideo: "modal_hj3415/link_video.html",
    ModalSingleBG: "modal_hj3415/single_bg.html",
    ModalImageOnly: "modal_hj3415/image_only.html",
}

MODEL_ORDER = {
    "image_only": ModalImageOnly,
    "single_bg": ModalSingleBG,
    "link_video": ModalLinkVideo,
    "rotate_bg": ModalRotateBG,
}


class AllowedHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag in ALLOWED_HTML_TAGS:
            if tag == "br":
                self.parts.append("<br>")
            else:
                self.parts.append(f"<{tag}>")
        else:
            self.parts.append(escape(self.get_starttag_text()))

    def handle_endtag(self, tag):
        if tag in ALLOWED_HTML_TAGS and tag != "br":
            self.parts.append(f"</{tag}>")
        elif tag not in ALLOWED_HTML_TAGS:
            self.parts.append(escape(f"</{tag}>"))

    def handle_startendtag(self, tag, attrs):
        if tag in ALLOWED_HTML_TAGS:
            self.parts.append("<br>" if tag == "br" else f"<{tag}></{tag}>")
        else:
            self.parts.append(escape(self.get_starttag_text()))

    def handle_data(self, data):
        self.parts.append(escape(data))

    def handle_entityref(self, name):
        self.parts.append(f"&{name};")

    def handle_charref(self, name):
        self.parts.append(f"&#{name};")

    def get_html(self):
        return "".join(self.parts)


def sanitize_html(value):
    parser = AllowedHTMLParser()
    parser.feed("" if value is None else str(value))
    parser.close()
    return mark_safe(parser.get_html())


def sanitize_url(value):
    if not value:
        return ""
    candidate = str(value).strip()
    parsed = urlsplit(candidate)
    if parsed.scheme.lower() not in ALLOWED_URL_SCHEMES:
        return ""
    return candidate


def normalize_priority(priority):
    return [key for key in priority if key in MODEL_ORDER]


@register.filter(name="sanitize_modal_html", is_safe=True)
def sanitize_modal_html(value):
    return sanitize_html(value)


@register.filter(name="sanitize_modal_url")
def sanitize_modal_url(value):
    return sanitize_url(value)

@register.inclusion_tag("modal_hj3415/_load.html")
def show_modal(auto_open=True, priority=ALLOWED_PRIORITY_KEYS):
    popup, model = None, None
    for key in normalize_priority(priority):
        M = MODEL_ORDER[key]
        popup = M.objects.filter(activate=True).order_by("-id").first()  # 가장 최신 것
        if popup:
            model = M
            break

    if not popup:
        return {"popup": None}  # 템플릿에서 {% if popup %}로 처리

    modal_id = f"popupModal-{model.__name__}-{popup.pk}"
    template_name = TEMPLATE_MAP[model]
    return {
        "dont_show_again": "다시보지않기",
        "popup": popup,
        "template_name": template_name,
        "modal_id": modal_id,
        "section_id": f"{modal_id}-content",
        "auto_open": auto_open,
    }

@register.inclusion_tag("modal_hj3415/_load_many.html")
def show_modals(
    auto_open=True,
    priority=ALLOWED_PRIORITY_KEYS,
    only_latest=False,
):
    """
    활성화된 모든 모달을 우선순위대로 수집해 순차적으로(큐) 표시.
    단일 태그와 동일한 규약(template_name/modal_id)으로 내려줍니다.
    """
    items = []
    for key in normalize_priority(priority):
        M = MODEL_ORDER[key]
        qs = M.objects.filter(activate=True).order_by("-id")
        if only_latest:
            qs = qs[:1]
        for popup in qs:
            items.append({
                "popup": popup,
                "template_name": TEMPLATE_MAP[M],
                "modal_id": f"popupModal-{M.__name__}-{popup.pk}",
                "section_id": f"popupModal-{M.__name__}-{popup.pk}-content",
                "title": getattr(popup, "modal_title", M.__name__),
            })

    return {
        "dont_show_again": "다시보지않기",
        "items": items,
        "auto_open": auto_open,
    }
