"""Host-side shared helpers."""
