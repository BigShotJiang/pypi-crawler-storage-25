# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""spectrax — a JAX-only neural-network library.

Top-level public API. The library combines a PyTorch-shaped eager
surface (subclass :class:`Module`, override :meth:`~Module.forward`,
call ``model(x)``) with an explicit graph/state seam
(:func:`export`, :func:`bind`, :class:`GraphDef`, :class:`State`,
:class:`Selector`) and module-aware JAX transforms
(:func:`eval_shape`, :func:`jit`, :func:`grad`,
:func:`value_and_grad`, :func:`vmap`, :func:`scan`, :func:`remat`).

Submodules imported here for qualified access:

* :mod:`spectrax.nn` — neural-network layers.
* :mod:`spectrax.functional` — stateless tensor ops.
* :mod:`spectrax.init` — parameter initializers.
* :mod:`spectrax.hooks` — forward and variable hooks.
* :mod:`spectrax.inspect` — introspection helpers.
* :mod:`spectrax.typing` — public type aliases.
* :mod:`spectrax.sharding` — logical axis rules, :class:`SpxMesh`
  construction, partition-spec helpers.
* :mod:`spectrax.runtime` — pipeline-parallel runtimes and schedules
  (:class:`GPipe`, :class:`Std1F1B`, :class:`ZeroBubbleH1`, …),
  :func:`sxcall` / :func:`sxjit`, :class:`MpMdMesh`,
  :class:`PipelineSequential`.
"""

from . import (
    functional,
    hooks,
    init,
    inspect,
    nn,
    runtime,
    sharding,
    typing,
)
from ._version import __version__
from .api import run
from .core import context
from .core.context import scope
from .core.errors import (
    CyclicGraphError,
    IllegalMutationError,
    LazyInitUnderTransformError,
    SelectorError,
    SpecTraxError,
)
from .core.graph import (
    GraphDef,
    bind,
    clone,
    export,
    find,
    iter_modules,
    iter_variables,
    live_variables,
    pop,
    tree_state,
    update,
)
from .core.lazy_init import lazy_init
from .core.module import Module, Opaque
from .core.policy import Policy
from .core.selector import (
    Everything,
    Nothing,
    Selector,
    all_of,
    any_of,
    as_selector,
    not_,
    of_type,
    path_contains,
    path_endswith,
    path_startswith,
    select,
)
from .core.sharding import AxisNames, Sharding
from .core.stage_assignment import assign_stage
from .core.state import State
from .core.static import Static
from .core.variable import (
    Buffer,
    DeferredBuffer,
    DeferredParameter,
    InitPlacementHook,
    Parameter,
    Variable,
    variable_init_placement,
)
from .lint import check_unintentional_sharing
from .rng import Rngs, RngStream, resolve_rngs, seed
from .runtime import sxstage_iter
from .sharding.mesh import SpxMesh, create_mesh
from .transforms import (
    StateAxes,
    associative_scan,
    cond,
    eval_shape,
    fori_loop,
    grad,
    jit,
    jvp,
    remat,
    remat_scan,
    scan,
    split_rngs,
    split_stream_keys,
    switch,
    value_and_grad,
    vjp,
    vmap,
    while_loop,
)

__all__ = [
    "AxisNames",
    "Buffer",
    "CyclicGraphError",
    "Everything",
    "GraphDef",
    "IllegalMutationError",
    "InitPlacementHook",
    "LazyInitUnderTransformError",
    "Module",
    "Nothing",
    "Opaque",
    "Parameter",
    "Policy",
    "RngStream",
    "Rngs",
    "Selector",
    "SelectorError",
    "Sharding",
    "SpecTraxError",
    "SpxMesh",
    "State",
    "StateAxes",
    "Static",
    "Variable",
    "__version__",
    "all_of",
    "any_of",
    "as_selector",
    "assign_stage",
    "associative_scan",
    "bind",
    "check_unintentional_sharing",
    "clone",
    "cond",
    "context",
    "create_mesh",
    "eval_shape",
    "export",
    "find",
    "fori_loop",
    "functional",
    "grad",
    "hooks",
    "init",
    "inspect",
    "iter_modules",
    "iter_variables",
    "jit",
    "jvp",
    "lazy_init",
    "live_variables",
    "nn",
    "not_",
    "of_type",
    "path_contains",
    "path_endswith",
    "path_startswith",
    "pop",
    "remat",
    "remat_scan",
    "resolve_rngs",
    "run",
    "runtime",
    "scan",
    "scope",
    "seed",
    "select",
    "sharding",
    "split_rngs",
    "split_stream_keys",
    "switch",
    "sxstage_iter",
    "tree_state",
    "typing",
    "update",
    "value_and_grad",
    "variable_init_placement",
    "vjp",
    "vmap",
    "while_loop",
]
