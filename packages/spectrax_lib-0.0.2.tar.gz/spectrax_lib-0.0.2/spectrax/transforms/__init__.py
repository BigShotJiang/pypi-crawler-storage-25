# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module-aware JAX transforms.

Every function here is a spectrax counterpart to a JAX transform:
:func:`eval_shape`, :func:`jit`, :func:`grad`, :func:`value_and_grad`,
:func:`vmap`, :func:`scan`, :func:`remat`. They share a split/merge
shim defined in :mod:`spectrax.transforms.split_merge` that locates
:class:`~spectrax.Module` arguments, converts them into
``(GraphDef, State)`` pairs on the way in, and writes any declared
mutations back on the way out. :func:`eval_shape` is the read-only
exception: it snapshots module inputs but never writes abstract updates
back to the live modules.
"""

from .control_flow import cond, fori_loop, remat_scan, switch, while_loop
from .eval_shape import eval_shape
from .grad import grad, jvp, value_and_grad, vjp
from .jit import jit
from .remat import remat
from .rng_axes import StateAxes, split_rngs, split_stream_keys
from .scan import associative_scan, scan
from .vmap import vmap

__all__ = [
    "StateAxes",
    "associative_scan",
    "cond",
    "eval_shape",
    "fori_loop",
    "grad",
    "jit",
    "jvp",
    "remat",
    "remat_scan",
    "scan",
    "split_rngs",
    "split_stream_keys",
    "switch",
    "value_and_grad",
    "vjp",
    "vmap",
    "while_loop",
]
