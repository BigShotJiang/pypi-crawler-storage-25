# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""GPipe schedule: all forwards then all backwards."""

from __future__ import annotations

from dataclasses import dataclass

from .base import Action, Phase, Schedule


@dataclass
class GPipe(Schedule):
    """GPipe schedule (Huang et al., 2019): all forwards then all backwards.

    Structure for ``n_stages`` stages and ``M`` microbatches::

        FWD:
          t=0: stage 0 on mb 0
          t=1: stage 0 on mb 1; stage 1 on mb 0
          …
          t=M+n-2: drain complete
        BWD:
          all microbatches' backwards, reverse of forward

    Pros:

    * Simplest schedule; easy to debug.
    * Natural activation-checkpointing pairing (each stage saves M
      activations, but the schedule is symmetric so `lax.remat` just
      works).

    Cons:

    * Peak activation memory scales as ``O(n_stages · M)`` — every
      stage holds every microbatch's activation until the backward
      pass starts.
    * ``2(n_stages - 1)`` idle slots at both ends of the schedule
      (the "bubble").
    """

    def build(self, n_stages: int) -> list[list[Action | None]]:
        """Emit the all-fwd / all-bwd grid.

        Forward phase: stage ``s`` runs microbatch ``t - s`` at time
        ``t`` while ``0 <= t - s < m``. Backward phase mirrors this
        with reversed stage order — stage ``s`` runs backward on
        microbatch ``t - (n - 1 - s)``.
        """
        n, m = n_stages, self.microbatches
        fwd_steps = m + n - 1
        bwd_steps = m + n - 1
        grid: list[list[Action | None]] = []

        for t in range(fwd_steps):
            row: list[Action | None] = [None] * n
            for s in range(n):
                mb = t - s
                if 0 <= mb < m:
                    row[s] = Action(Phase.FWD, mb)
            grid.append(row)

        for t in range(bwd_steps):
            row = [None] * n
            for s in range(n):
                mb = t - (n - 1 - s)
                if 0 <= mb < m:
                    row[s] = Action(Phase.BWD, mb)
            grid.append(row)

        return grid

    def peak_activations(self, n_stages: int) -> int:
        """Peak = ``microbatches`` per stage (all saved before any backward)."""
        return self.microbatches
