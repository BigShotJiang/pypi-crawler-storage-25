# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""SPMD pipeline runtime.

Single HLO program with ``shard_map`` / manual axis. Faster on TPU
but requires homogeneous stages.
"""

from __future__ import annotations

from .api import pipeline_call, pipeline_step
from .hybrid import hybrid_linear_run
from .runtime import spmd_run
from .shard_map import make_scheduled_body

__all__ = [
    "hybrid_linear_run",
    "make_scheduled_body",
    "pipeline_call",
    "pipeline_step",
    "spmd_run",
]
