# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""":func:`spectrax.pipeline.boundary`: inline stage-break marker.

Placing ``spx.pipeline.boundary(x)`` inside a module's ``forward``
declares a pipeline stage split at that point: every op before the
first boundary belongs to stage 0, between the first and second
boundary to stage 1, and so on.

Outside a pipeline context, :func:`boundary` is the identity function
— modules that use it still run correctly on a single device, which
makes it safe to litter your model with boundary hints before you've
decided how to parallelize.

Under :func:`spectrax.pipeline.pipeline`, the primary stage-break
contract is the explicit :class:`~spectrax.pipeline.PipelineSequential`
container: each element of its ``stages`` is a distinct pipeline stage.
The :func:`boundary` primitive is a convenience marker for models that
aren't structured as a flat sequence of modules; it's preserved in the
traced jaxpr so future versions (v2) can split mid-forward at boundary
calls. In the current release it lowers to an identity and is silently
ignored by the SPMD orchestrator.
"""

from __future__ import annotations

from typing import Any

import jax

__all__ = ["boundary"]


def boundary(x: Any) -> Any:
    """Mark a pipeline stage boundary inside a ``forward`` method.

    Outside a pipeline context this is a no-op identity function, so
    modules peppered with ``boundary`` calls still run unchanged on a
    single device. Inside :func:`spectrax.pipeline.pipeline`, a future
    jaxpr-splitting pass (v2) will cut the forward pass at each
    boundary and lower each piece onto a separate mesh shard; the
    current SPMD orchestrator uses
    :class:`~spectrax.pipeline.PipelineSequential` as the canonical
    source of stage structure and treats ``boundary`` as advisory.

    Args:
        x: Any JAX-compatible value. Passed through unchanged.

    Returns:
        ``x`` unmodified. The call is preserved in the jaxpr as an
        identity named op so it can be introspected by transforms.
    """

    @jax.custom_jvp
    def _boundary(x):
        """Identity primitive carrying the boundary annotation in the jaxpr."""
        return x

    @_boundary.defjvp
    def _boundary_jvp(primals, tangents):
        """JVP rule: forward both primal and tangent unchanged."""
        (x,) = primals
        (t,) = tangents
        return x, t

    return _boundary(x)
