# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Shared pipeline-parallel types."""

from __future__ import annotations

from .array import StagesArray, abstract_stages_array
from .mesh import MpMdMesh, resolve_mpmd_mesh
from .stage import PipelineStage, _is_empty_state

__all__ = [
    "MpMdMesh",
    "PipelineStage",
    "StagesArray",
    "_is_empty_state",
    "abstract_stages_array",
    "resolve_mpmd_mesh",
]
