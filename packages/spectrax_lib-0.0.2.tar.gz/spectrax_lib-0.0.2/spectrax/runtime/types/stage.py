# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""":class:`PipelineStage` dataclass and helpers."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

__all__ = ["PipelineStage", "_is_empty_state"]


def _is_empty_state(s: Any) -> bool:
    """Detect the "no state" sentinel.

    Treats ``()`` and ``None`` identically so users can pass either
    without tripping the runtime.
    """
    return s is None or s == ()


@dataclass
class PipelineStage:
    """A single rank's worth of pipeline work.

    ``fn(parameters, state, x) -> (y, new_state)``. Use ``()`` (or ``None``)
    for ``init_state`` on stateless stages.
    """

    fn: Callable[[Any, Any, Any], tuple[Any, Any]]
    parameters: Any
    init_state: Any = ()
