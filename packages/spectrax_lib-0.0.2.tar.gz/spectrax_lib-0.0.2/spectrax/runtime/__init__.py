# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Pipeline-parallel runtimes and schedules.

Subpackages
-----------
* :mod:`spectrax.runtime.mpmd` — True MPMD runtime (per-rank separate HLOs).
* :mod:`spectrax.runtime.spmd` — SPMD runtime (single HLO via ``shard_map``).
* :mod:`spectrax.runtime.schedules` — Pipeline schedules (GPipe, 1F1B, …).
* :mod:`spectrax.runtime.types` — Shared types (``MpMdMesh``, ``PipelineStage``, …).
* :mod:`spectrax.runtime.primitives` — Shared primitives (``boundary``, ``auto_split``).
"""

from __future__ import annotations

from .mpmd import (
    sxcall,
    sxenter_loop,
    sxexit_loop,
    sxgrad,
    sxjit,
    sxloop,
    sxstage_iter,
    sxvalue_and_grad,
)
from .schedules import (
    Action,
    DualPipeV,
    Eager1F1B,
    FusedTask,
    GPipe,
    Interleaved1F1BPlusOne,
    InterleavedGPipe,
    InterleavedH1,
    KimiK2,
    Phase,
    Schedule,
    Std1F1B,
    ZeroBubbleH1,
    dualpipev_tasks,
    fuse_1f1b_steady_state,
    fuse_zerobubble_bwd_pair,
)

__all__ = (
    "Action",
    "DualPipeV",
    "Eager1F1B",
    "FusedTask",
    "GPipe",
    "Interleaved1F1BPlusOne",
    "InterleavedGPipe",
    "InterleavedH1",
    "KimiK2",
    "Phase",
    "Schedule",
    "Std1F1B",
    "ZeroBubbleH1",
    "dualpipev_tasks",
    "fuse_1f1b_steady_state",
    "fuse_zerobubble_bwd_pair",
    "sxcall",
    "sxenter_loop",
    "sxexit_loop",
    "sxgrad",
    "sxjit",
    "sxloop",
    "sxstage_iter",
    "sxvalue_and_grad",
)
