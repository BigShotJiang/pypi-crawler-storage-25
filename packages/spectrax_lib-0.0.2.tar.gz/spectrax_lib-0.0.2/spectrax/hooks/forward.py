# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Forward pre-hook and post-hook helpers.

These are thin function wrappers around the
:meth:`~spectrax.Module.register_forward_pre_hook` and
:meth:`~spectrax.Module.register_forward_hook` methods, for users who
prefer a functional call site.
"""

from __future__ import annotations

from ..core._typing import ForwardHook, ForwardPreHook
from ..core.module import Module, _HookHandle

Handle = _HookHandle
"""Alias for the hook handle type returned by the register functions."""

__all__ = ["Handle", "register_forward_hook", "register_forward_pre_hook"]


def register_forward_pre_hook(module: Module, fn: ForwardPreHook) -> Handle:
    """Attach ``fn`` to ``module`` as a forward pre-hook.

    See :class:`spectrax.typing.ForwardPreHook` for the callable shape.
    The returned :class:`Handle` can be used to remove the hook.
    """
    return module.register_forward_pre_hook(fn)


def register_forward_hook(module: Module, fn: ForwardHook) -> Handle:
    """Attach ``fn`` to ``module`` as a forward post-hook.

    See :class:`spectrax.typing.ForwardHook` for the callable shape.
    The returned :class:`Handle` can be used to remove the hook.
    """
    return module.register_forward_hook(fn)
