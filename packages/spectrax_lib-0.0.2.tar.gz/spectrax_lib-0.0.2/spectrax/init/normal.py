# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Gaussian (normal / truncated normal) initializers."""

from __future__ import annotations

import jax
import jax.numpy as jnp

from ..core._typing import Array, DType, Initializer, PRNGKey, Shape


def normal(stddev: float = 1.0, mean: float = 0.0) -> Initializer:
    """Return an initializer drawing samples from ``N(mean, stddev**2)``."""

    def init(key: PRNGKey, shape: Shape, dtype: DType = jnp.float32) -> Array:
        """Draw ``jax.random.normal(key, shape) * stddev + mean``."""
        return jax.random.normal(key, shape, dtype=dtype) * stddev + mean

    return init


def truncated_normal(
    stddev: float = 1.0,
    lower: float = -2.0,
    upper: float = 2.0,
) -> Initializer:
    """Truncated-normal initializer.

    Samples from ``N(0, 1)`` truncated to ``[lower, upper]`` and scales
    by ``stddev``.
    """

    def init(key: PRNGKey, shape: Shape, dtype: DType = jnp.float32) -> Array:
        """Draw a truncated-normal sample and scale by ``stddev``."""
        return jax.random.truncated_normal(key, lower, upper, shape, dtype=dtype) * stddev

    return init
