# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Deterministic constant initializers."""

from __future__ import annotations

import jax.numpy as jnp

from ..core._typing import Array, DType, Initializer, PRNGKey, Shape


def constant(value: float | int) -> Initializer:
    """Return an initializer that fills with ``value``.

    Args:
        value: The fill value; broadcast to ``shape`` at call time.
    """

    def init(key: PRNGKey, shape: Shape, dtype: DType = jnp.float32) -> Array:
        """Return ``jnp.full(shape, value, dtype)`` — the PRNG key is ignored."""
        del key
        return jnp.full(shape, value, dtype=dtype)

    return init


def zeros(key: PRNGKey, shape: Shape, dtype: DType = jnp.float32) -> Array:
    """All-zeros initializer (PRNG key ignored)."""
    del key
    return jnp.zeros(shape, dtype=dtype)


def ones(key: PRNGKey, shape: Shape, dtype: DType = jnp.float32) -> Array:
    """All-ones initializer (PRNG key ignored)."""
    del key
    return jnp.ones(shape, dtype=dtype)
