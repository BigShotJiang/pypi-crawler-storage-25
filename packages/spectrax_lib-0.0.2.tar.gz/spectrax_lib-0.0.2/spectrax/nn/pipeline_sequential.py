# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""":class:`PipelineSequential`: explicit stage container.

The primary way to declare pipeline stages in spectrax. Each positional
argument to the constructor is a distinct stage — the modules run
sequentially in eager mode (identical to :class:`spectrax.nn.Sequential`),
and under :func:`spectrax.pipeline.pipeline` each stage is assigned to
a separate device along the mesh's pipeline axis.

Declaring stages explicitly at the container level (rather than inline
via :func:`spectrax.pipeline.boundary` calls) makes the split
introspectable: :func:`spectrax.export` records the stage boundaries in
the :class:`~spectrax.GraphDef`, and ``model.stages`` returns the live
per-stage :class:`~spectrax.Module` instances for per-stage inspection
or surgery.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from spectrax.core.module import Module
from spectrax.core.variable import Variable

__all__ = ["PipelineSequential"]


class PipelineSequential(Module):
    """Sequential container that also declares pipeline stage boundaries.

    Constructed with a positional list of sub-modules; each one is a
    stage. In eager mode and on a single device, acts identically to
    :class:`spectrax.nn.Sequential` — calls each stage in order,
    threading the output of stage *k* into the input of stage *k+1*.

    Under :func:`spectrax.pipeline.pipeline`, the container's stage
    count must match the mesh's pipeline-axis size; the decorator uses
    the container's stage list to shard the model across that axis.

    Args:
        *stages: One :class:`Module` per pipeline stage, in
            application order. At least one stage is required.

    Attributes:
        num_stages: Integer count of pipeline stages.

    Example::

        class Block(spx.Module):
            def __init__(self, d, *, rngs):
                super().__init__()
                self.fc = nn.Linear(d, d, rngs=rngs)
            def forward(self, x):
                return jax.nn.gelu(self.fc(x))


        model = spx.pipeline.PipelineSequential(
            Block(128, rngs=spx.Rngs(0)),
            Block(128, rngs=spx.Rngs(1)),
            Block(128, rngs=spx.Rngs(2)),
            Block(128, rngs=spx.Rngs(3)),
        )

        # Eager:
        y = model(x)

        # Under pipeline:
        @spx.pipeline.pipeline(mesh=mesh, schedule=spx.pipeline.GPipe(microbatches=8))
        def step(m, x, y): ...
    """

    _spx_container_kind = "list"

    def __init__(self, *stages: Module) -> None:
        """Construct a pipeline container with ``len(stages)`` stages.

        Args:
            *stages: Individual stage modules. Order is significant and
                becomes the forward-execution order.

        Raises:
            TypeError: If any argument is not a :class:`Module`.
            ValueError: If zero stages are passed.
        """
        super().__init__()
        if not stages:
            raise ValueError("PipelineSequential requires at least one stage.")
        for i, s in enumerate(stages):
            if not isinstance(s, Module):
                raise TypeError(f"PipelineSequential stage {i} must be a Module, got {type(s).__name__}.")
        object.__setattr__(self, "_spx_items", list(stages))

    @property
    def num_stages(self) -> int:
        """Number of pipeline stages."""
        return len(self._spx_items)

    @property
    def stages(self) -> list[Module]:
        """Live list of per-stage :class:`Module` instances."""
        return list(self._spx_items)

    def forward(self, x: Any) -> Any:
        """Apply every stage in order (eager / single-device path).

        Under :func:`spectrax.pipeline.pipeline`, the orchestrator calls
        each stage's ``forward`` on its assigned device instead of
        invoking this method directly.
        """
        for stage in self._spx_items:
            x = stage(x)
        return x

    def _spx_graph_children(self) -> Iterator[tuple[int, Module | Variable]]:
        """Yield ``(index, stage)`` pairs in stage order."""
        yield from enumerate(self._spx_items)

    def __len__(self) -> int:
        """Number of stages (same as :attr:`num_stages`)."""
        return len(self._spx_items)

    def __getitem__(self, idx: int) -> Module:
        """Get the stage at position ``idx``."""
        return self._spx_items[idx]

    def __iter__(self) -> Iterator[Module]:
        """Iterate over stages in order."""
        return iter(self._spx_items)
