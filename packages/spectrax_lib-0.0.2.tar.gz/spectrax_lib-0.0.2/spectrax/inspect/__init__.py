# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Introspection helpers: pretty ``repr``, parameter summaries,
state/shape enumeration.
"""

from .counting import format_parameters
from .display import display
from .repr import repr_module
from .summary import summary
from .tabulate import count_bytes, count_parameters, hlo_cost, tabulate
from .tree import tree_state

__all__ = [
    "count_bytes",
    "count_parameters",
    "display",
    "format_parameters",
    "hlo_cost",
    "repr_module",
    "summary",
    "tabulate",
    "tree_state",
]
