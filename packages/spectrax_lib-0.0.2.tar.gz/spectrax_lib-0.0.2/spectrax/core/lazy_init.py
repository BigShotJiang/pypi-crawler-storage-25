# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Explicit lazy-initialization controls."""

from __future__ import annotations

import contextlib
import threading
from collections.abc import Iterator

__all__ = ["lazy_init"]


_LAZY_STATE: threading.local = threading.local()


def _explicit_lazy_mode() -> bool:
    """Return ``True`` when construction happens under :func:`lazy_init`."""
    return bool(getattr(_LAZY_STATE, "explicit_lazy", False))


def _materialization_allowed() -> bool:
    """Return ``True`` when lazy modules may materialize on this thread."""
    return bool(getattr(_LAZY_STATE, "allow_materialization", False))


@contextlib.contextmanager
def lazy_init() -> Iterator[None]:
    """Build modules in explicit-lazy mode.

    Lazy-capable modules created under this context do not silently
    materialize on first forward. Call ``module.sequential_init(...)``
    (or ``module.init(...example_inputs...)``) to materialize them
    explicitly.
    """
    prev = _explicit_lazy_mode()
    _LAZY_STATE.explicit_lazy = True
    try:
        yield
    finally:
        _LAZY_STATE.explicit_lazy = prev


@contextlib.contextmanager
def _allow_materialization() -> Iterator[None]:
    """Temporarily allow lazy modules to materialize."""
    prev = _materialization_allowed()
    _LAZY_STATE.allow_materialization = True
    try:
        yield
    finally:
        _LAZY_STATE.allow_materialization = prev
