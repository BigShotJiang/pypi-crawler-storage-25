# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Small shared utilities for functional ops."""

from __future__ import annotations

import jax.numpy as jnp

from ..core._typing import Array, ArrayLike, DType

__all__ = ["promote_dtype"]


def promote_dtype(
    *arrays: ArrayLike,
    dtype: DType | None = None,
) -> tuple[Array, ...]:
    """Cast every array to a common dtype.

    If ``dtype`` is ``None``, the result uses
    :func:`jax.numpy.promote_types` across the inputs' dtypes.
    """
    arrs = [jnp.asarray(a) for a in arrays]
    if dtype is None:
        if not arrs:
            return ()
        out_dtype = arrs[0].dtype
        for a in arrs[1:]:
            out_dtype = jnp.promote_types(out_dtype, a.dtype)
    else:
        out_dtype = dtype
    return tuple(a.astype(out_dtype) for a in arrs)
