# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Scaled dot-product attention primitive."""

from __future__ import annotations

import math

import jax
import jax.numpy as jnp

from ..core._typing import Array, ArrayLike, PRNGKey


def scaled_dot_product_attention(
    q: ArrayLike,
    k: ArrayLike,
    v: ArrayLike,
    *,
    mask: ArrayLike | None = None,
    dropout_rate: float = 0.0,
    key: PRNGKey | None = None,
    is_causal: bool = False,
    scale: float | None = None,
) -> Array:
    """Compute multi-head scaled dot-product attention.

    Treats the trailing two axes of ``q`` / ``k`` / ``v`` as
    ``(seq, head_dim)``; all leading axes are batch axes that are
    broadcast and preserved in the output.

    Args:
        q: Query tensor, shape ``(..., seq_q, head_dim)``.
        k: Key tensor, shape ``(..., seq_k, head_dim)``.
        v: Value tensor, shape ``(..., seq_k, head_dim)``.
        mask: Optional mask broadcastable to ``(..., seq_q, seq_k)``.
            ``bool`` masks zero out disallowed positions; floating
            masks are added to the logits.
        dropout_rate: Attention-weight dropout probability.
        key: PRNG key for dropout, required when ``dropout_rate > 0``.
        is_causal: Apply a lower-triangular causal mask on top of
            ``mask``.
        scale: Logit scale (defaults to ``1 / sqrt(head_dim)``).

    Returns:
        Attention output of shape ``(..., seq_q, head_dim)``.
    """
    qa = jnp.asarray(q)
    ka = jnp.asarray(k)
    va = jnp.asarray(v)
    d = qa.shape[-1]
    s = scale if scale is not None else 1.0 / math.sqrt(d)
    logits = jnp.einsum("...qd,...kd->...qk", qa, ka) * s
    if is_causal:
        q_len = qa.shape[-2]
        k_len = ka.shape[-2]
        causal = jnp.tril(jnp.ones((q_len, k_len), dtype=jnp.bool_))
        logits = jnp.where(causal, logits, jnp.finfo(logits.dtype).min)
    if mask is not None:
        m = jnp.asarray(mask)
        if m.dtype == jnp.bool_:
            logits = jnp.where(m, logits, jnp.finfo(logits.dtype).min)
        else:
            logits = logits + m
    attn = jax.nn.softmax(logits, axis=-1)
    if dropout_rate > 0.0 and key is not None:
        keep_rate = 1.0 - dropout_rate
        drop_mask = jax.random.bernoulli(key, keep_rate, shape=attn.shape)
        attn = jnp.where(drop_mask, attn / keep_rate, 0.0)
    return jnp.einsum("...qk,...kd->...qd", attn, va)
