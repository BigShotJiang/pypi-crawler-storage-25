"""Filter span processor to suppress noisy infrastructure traces."""
from typing import Optional
from opentelemetry.sdk.trace import SpanProcessor, ReadableSpan
from opentelemetry.trace import SpanContext


class InfrastructureTraceFilter(SpanProcessor):
    """Drops infrastructure/health check spans to reduce noise in Langfuse."""
    
    # URL patterns to suppress
    SUPPRESSED_PATTERNS = [
        "/ensure",  # VectorDB ensure collection
        "/health",  # Health checks
        "/ready",   # Readiness probes
        "/alive",   # Liveness probes
        ".svc.cluster.local",  # Internal K8s calls
    ]
    
    # Span names to suppress
    SUPPRESSED_NAMES = [
        "ensure_collection",
        "health_check",
        "ping",
    ]
    
    def on_start(self, span: ReadableSpan, parent_context: Optional[SpanContext] = None) -> None:
        pass
    
    def on_end(self, span: ReadableSpan) -> None:
        """Check if span should be dropped before export."""
        # Check span name
        if any(name in span.name for name in self.SUPPRESSED_NAMES):
            span._attributes = {}  # Clear attributes to mark as dropped
            return
        
        # Check URL in attributes
        url = span.attributes.get("http.url") or span.attributes.get("url.full") or ""
        if any(pattern in str(url) for pattern in self.SUPPRESSED_PATTERNS):
            span._attributes = {}
            return
        
        # Check target
        target = span.attributes.get("http.target") or ""
        if any(pattern in str(target) for pattern in self.SUPPRESSED_PATTERNS):
            span._attributes = {}
            return
    
    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True
    
    def shutdown(self) -> None:
        pass
