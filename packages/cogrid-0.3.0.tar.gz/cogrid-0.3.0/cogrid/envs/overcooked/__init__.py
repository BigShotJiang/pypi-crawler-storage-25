"""Overcooked cooperative cooking environment."""
