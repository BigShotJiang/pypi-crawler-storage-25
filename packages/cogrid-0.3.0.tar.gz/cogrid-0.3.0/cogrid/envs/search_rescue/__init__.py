"""Search-and-rescue environment."""
