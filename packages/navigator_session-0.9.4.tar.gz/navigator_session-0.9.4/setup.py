#!/usr/bin/env python
"""Minimal setup.py shim."""

from setuptools import setup

if __name__ == "__main__":
    setup()
