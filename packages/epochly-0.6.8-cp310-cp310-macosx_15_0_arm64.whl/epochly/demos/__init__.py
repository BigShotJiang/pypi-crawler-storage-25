"""Backward-compatible demo module namespace."""

__all__ = ["benchmark"]
