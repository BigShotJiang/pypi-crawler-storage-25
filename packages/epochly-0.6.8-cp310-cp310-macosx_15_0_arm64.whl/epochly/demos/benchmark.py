"""Backward-compatible alias for the benchmark CLI.

The canonical invocation is ``python -m epochly.benchmark``. This module keeps
the historical ``python -m epochly.demos.benchmark`` path working for users who
copied older README examples.
"""

from epochly.benchmark.__main__ import main

__all__ = ["main"]


if __name__ == "__main__":
    raise SystemExit(main())
