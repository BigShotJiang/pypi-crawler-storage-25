"""
Automatic Emergency Detector for Epochly.

Monitors system health in a background thread and automatically triggers
emergency disable when degradation is detected. This ensures users don't
need to manually detect and respond to system failures.

Safety Requirement (R-SAFE-04): Epochly MUST automatically disable itself
if degradation is detected.

Trigger Conditions:
- Global error rate > 50% (ERROR_RATE_THRESHOLD)
- Memory allocation failures > threshold (MEMORY_FAILURE_THRESHOLD)
- Processing latency > max threshold (LATENCY_THRESHOLD_MS)

Integration:
- Uses EnhancementProgressionManager for error rate monitoring
- Owns emergency latch state and exposes accessors for consumers
- Calls emergency_disable_callback for cleanup

Author: Epochly Development Team
Date: January 2026
"""

import logging
import os
import threading
import time
import weakref
from typing import Any, Callable, Optional, Protocol

logger = logging.getLogger(__name__)

# Environment variable constant for emergency disable flag
EMERGENCY_DISABLE_ENV_VAR = "EPOCHLY_EMERGENCY_DISABLE"
_ACTIVE_DETECTOR_LOCK = threading.RLock()
_ACTIVE_DETECTOR_REF: Optional[weakref.ReferenceType["AutoEmergencyDetector"]] = None


def _set_active_detector(detector: "AutoEmergencyDetector") -> None:
    global _ACTIVE_DETECTOR_REF
    with _ACTIVE_DETECTOR_LOCK:
        _ACTIVE_DETECTOR_REF = weakref.ref(detector)


def _clear_active_detector(detector: "AutoEmergencyDetector") -> None:
    global _ACTIVE_DETECTOR_REF
    with _ACTIVE_DETECTOR_LOCK:
        active = _ACTIVE_DETECTOR_REF() if _ACTIVE_DETECTOR_REF is not None else None
        if active is detector:
            _ACTIVE_DETECTOR_REF = None


def _get_active_detector() -> Optional["AutoEmergencyDetector"]:
    with _ACTIVE_DETECTOR_LOCK:
        return _ACTIVE_DETECTOR_REF() if _ACTIVE_DETECTOR_REF is not None else None


def _is_environment_override_active() -> bool:
    value = os.environ.get(EMERGENCY_DISABLE_ENV_VAR)
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def is_emergency_active() -> bool:
    detector = _get_active_detector()
    if detector is not None and detector.is_emergency_active():
        return True
    return _is_environment_override_active()


def emergency_metadata() -> dict[str, Any]:
    detector = _get_active_detector()
    if detector is not None:
        metadata = detector.emergency_metadata()
        if metadata.get("active"):
            return metadata
    if _is_environment_override_active():
        return {
            "active": True,
            "latched": False,
            "reason": EMERGENCY_DISABLE_ENV_VAR,
            "source": "environment",
            "triggered_at": None,
        }
    if detector is not None:
        return detector.emergency_metadata()
    return {
        "active": False,
        "latched": False,
        "reason": None,
        "source": None,
        "triggered_at": None,
    }


class ErrorRateProvider(Protocol):
    """Protocol for objects that can provide global error rate."""

    def global_error_rate(self) -> float:
        """Return current global error rate (0.0 to 1.0)."""
        ...


class AutoEmergencyDetector:
    """
    Automatically detect system degradation and trigger emergency disable.

    Monitors:
    - Global error rate across all enhancement levels
    - Memory allocation failures
    - Processing latency exceeding thresholds

    Thread Safety: All public methods are thread-safe.
    """

    # Default thresholds (can be overridden via constructor)
    DEFAULT_ERROR_RATE_THRESHOLD = 0.50  # 50% error rate
    DEFAULT_MEMORY_FAILURE_THRESHOLD = 10  # 10 allocation failures
    DEFAULT_LATENCY_THRESHOLD_MS = 5000.0  # 5 seconds max latency
    DEFAULT_CHECK_INTERVAL = 5.0  # Check every 5 seconds

    def __init__(
        self,
        progression_manager: ErrorRateProvider,
        emergency_disable_callback: Callable[[], None],
        error_rate_threshold: float = DEFAULT_ERROR_RATE_THRESHOLD,
        memory_failure_threshold: int = DEFAULT_MEMORY_FAILURE_THRESHOLD,
        latency_threshold_ms: float = DEFAULT_LATENCY_THRESHOLD_MS,
        check_interval: float = DEFAULT_CHECK_INTERVAL,
    ):
        """
        Initialize the AutoEmergencyDetector.

        Args:
            progression_manager: Object providing global_error_rate() method
            emergency_disable_callback: Function to call when emergency triggered
            error_rate_threshold: Error rate threshold (0.0-1.0) to trigger emergency
            memory_failure_threshold: Number of memory failures to trigger emergency
            latency_threshold_ms: Max latency in ms before triggering emergency
            check_interval: Seconds between health checks
        """
        self._progression = progression_manager
        self._emergency_callback = emergency_disable_callback
        self._error_rate_threshold = error_rate_threshold
        self._memory_failure_threshold = memory_failure_threshold
        self._latency_threshold_ms = latency_threshold_ms
        self._check_interval = check_interval

        # State tracking
        self._memory_failures = 0
        self._max_latency_ms = 0.0
        self._overhead_violations_total = 0
        self._slowdown_events_total = 0
        self._emergency_latched = False
        self._emergency_state: dict[str, Any] = {
            "active": False,
            "latched": False,
            "reason": None,
            "source": None,
            "triggered_at": None,
        }
        self._lock = threading.RLock()

        # Thread management - use Event for fast wakeup on stop
        self._running = False
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        _set_active_detector(self)

    def start(self) -> None:
        """
        Start background monitoring thread.

        Idempotent: Safe to call multiple times.
        """
        with self._lock:
            if self._running:
                return  # Already running

            self._running = True
            self._stop_event.clear()
            self._thread = threading.Thread(
                target=self._monitor_loop,
                daemon=True,
                name="epochly-emergency-detector"
            )

        # Register outside lock to avoid lock-order inversion with _REGISTRY_LOCK
        try:
            from epochly.core.thread_registry import register_thread
            register_thread(
                self._thread,
                stop_callback=self._stop_event.set,
                name="epochly-emergency-detector",
            )
        except ImportError:
            pass
        self._thread.start()
        logger.info("AutoEmergencyDetector started")

    def stop(self) -> None:
        """
        Stop background monitoring.

        Blocks until thread terminates (with timeout).
        Thread-safe: Uses lock for _running flag.
        """
        with self._lock:
            self._running = False
        self._stop_event.set()  # Wake up sleeping thread immediately
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
            logger.info("AutoEmergencyDetector stopped")

    def shutdown(self) -> None:
        """Stop monitoring and clear cumulative detector state."""
        self.stop()
        self.reset()
        _clear_active_detector(self)

    def record_memory_failure(self) -> None:
        """
        Record a memory allocation failure.

        Thread-safe: Can be called from any thread.
        """
        with self._lock:
            self._memory_failures += 1
            self._slowdown_events_total += 1
            logger.debug(f"Memory failure recorded: {self._memory_failures} total")

    def record_latency(self, latency_ms: float) -> None:
        """
        Record processing latency.

        Args:
            latency_ms: Latency in milliseconds

        Thread-safe: Can be called from any thread.
        """
        with self._lock:
            self._max_latency_ms = max(self._max_latency_ms, latency_ms)
            if latency_ms > self._latency_threshold_ms:
                self._overhead_violations_total += 1

    def is_emergency_active(self) -> bool:
        """Return True when the detector has latched emergency state."""
        with self._lock:
            return self._emergency_latched

    def emergency_metadata(self) -> dict[str, Any]:
        """Return a defensive copy of the detector's emergency state."""
        with self._lock:
            metadata = dict(self._emergency_state)
            metadata["overhead_violations_total"] = self._overhead_violations_total
            metadata["slowdown_events_total"] = self._slowdown_events_total
            metadata["memory_failures"] = self._memory_failures
            metadata["max_latency_ms"] = self._max_latency_ms
            return metadata

    def trip(self, reason: str, **metadata: Any) -> bool:
        """Latch emergency state without mutating process environment."""
        with self._lock:
            if self._emergency_latched:
                return False
            trip_metadata = {
                "active": True,
                "latched": True,
                "reason": reason,
                "source": metadata.pop("source", "detector"),
                "triggered_at": time.time(),
            }
            trip_metadata.update(metadata)
            self._emergency_latched = True
            self._emergency_state = trip_metadata
            self._running = False
            self._stop_event.set()

        logger.critical("EMERGENCY: %s", reason)

        try:
            self._emergency_callback()
        except Exception as e:
            logger.error(f"Emergency callback failed: {e}", exc_info=True)
        return True

    def admin_clear(self, reason: str) -> None:
        """Clear a latched emergency state and emit an audit record."""
        previous_state = self.emergency_metadata()
        with self._lock:
            self._memory_failures = 0
            self._max_latency_ms = 0.0
            self._overhead_violations_total = 0
            self._slowdown_events_total = 0
            self._emergency_latched = False
            self._emergency_state = {
                "active": False,
                "latched": False,
                "reason": None,
                "source": None,
                "triggered_at": None,
            }
        logger.info(
            "AutoEmergencyDetector admin clear",
            extra={
                "audit_event": "auto_emergency_detector.admin_clear",
                "reason": reason,
                "previous_state": previous_state,
            },
        )

    def reset(self) -> None:
        """Reset cumulative counters and clear the in-memory emergency latch."""
        with self._lock:
            self._memory_failures = 0
            self._max_latency_ms = 0.0
            self._overhead_violations_total = 0
            self._slowdown_events_total = 0
            self._emergency_latched = False
            self._emergency_state = {
                "active": False,
                "latched": False,
                "reason": None,
                "source": None,
                "triggered_at": None,
            }

    def _monitor_loop(self) -> None:
        """
        Background monitoring loop.

        Checks health conditions periodically and triggers emergency
        disable if any threshold is exceeded.

        Thread-safe: Uses stop_event for authoritative signal.
        """
        logger.debug("AutoEmergencyDetector monitor loop started")

        while not self._stop_event.is_set():
            try:
                reason, metadata = self._check_emergency_condition()
                if reason is not None:
                    self._trigger_emergency_disable(reason, **metadata)
                    break  # Stop monitoring after emergency disable
            except Exception as e:
                # Never crash the monitoring thread
                logger.error(f"Error in emergency detector: {e}", exc_info=True)

            # Use event wait instead of sleep for fast wakeup on stop
            self._stop_event.wait(timeout=self._check_interval)

        logger.debug("AutoEmergencyDetector monitor loop ended")

    def _check_emergency_condition(self) -> tuple[Optional[str], dict[str, Any]]:
        """
        Check if emergency disable conditions are met.
        """
        # Check error rate
        try:
            error_rate = self._progression.global_error_rate()
            if error_rate > self._error_rate_threshold:
                with self._lock:
                    self._slowdown_events_total += 1
                logger.warning(
                    f"High error rate detected: {error_rate:.1%} > "
                    f"{self._error_rate_threshold:.1%}"
                )
                return (
                    "error rate threshold exceeded",
                    {
                        "source": "error_rate",
                        "observed_error_rate": error_rate,
                        "error_rate_threshold": self._error_rate_threshold,
                    },
                )
        except Exception as e:
            logger.debug(f"Could not get error rate: {e}")

        # Check memory failures
        with self._lock:
            if self._memory_failures > self._memory_failure_threshold:
                logger.warning(
                    f"Memory failure threshold exceeded: {self._memory_failures} > "
                    f"{self._memory_failure_threshold}"
                )
                return (
                    "memory failure threshold exceeded",
                    {
                        "source": "memory_failure",
                        "memory_failures": self._memory_failures,
                        "memory_failure_threshold": self._memory_failure_threshold,
                    },
                )

            # Check latency
            if self._max_latency_ms > self._latency_threshold_ms:
                logger.warning(
                    f"Latency threshold exceeded: {self._max_latency_ms:.0f}ms > "
                    f"{self._latency_threshold_ms:.0f}ms"
                )
                return (
                    "latency threshold exceeded",
                    {
                        "source": "latency",
                        "observed_latency_ms": self._max_latency_ms,
                        "latency_threshold_ms": self._latency_threshold_ms,
                    },
                )

        return None, {}

    def _trigger_emergency_disable(self, reason: str, **metadata: Any) -> None:
        """
        Trigger emergency disable.

        Latches in-memory state and calls callback.
        Catches all callback exceptions to ensure robustness.
        """
        self.trip(reason, **metadata)

    def get_stats(self) -> dict:
        """
        Get current detector statistics.

        Returns:
            Dictionary with current state
        """
        with self._lock:
            return {
                'running': self._running,
                'emergency_latched': self._emergency_latched,
                'memory_failures': self._memory_failures,
                'max_latency_ms': self._max_latency_ms,
                'overhead_violations_total': self._overhead_violations_total,
                'slowdown_events_total': self._slowdown_events_total,
                'error_rate_threshold': self._error_rate_threshold,
                'memory_failure_threshold': self._memory_failure_threshold,
                'latency_threshold_ms': self._latency_threshold_ms,
            }
