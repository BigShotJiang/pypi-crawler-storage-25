"""
Epochly Monitoring Package

Performance monitoring and metrics collection for the Epochly framework.
"""

from .performance_monitor import PerformanceMonitor
from .metrics_collector import MetricsCollector
from .system_monitor import SystemMonitor
from .prometheus_exporter import PrometheusExporter
from .auto_emergency_detector import (
    AutoEmergencyDetector,
    emergency_metadata,
    is_emergency_active,
)

# Benchmarking-specific feature metrics (Phase 1)
from .parallelism_metrics import ParallelismMetrics, ParallelismTracker
from .jit_metrics import JITMetrics, JITTracker
from .loop_transform_metrics import LoopType, LoopTransformMetrics, LoopTransformTracker
from .interception_metrics import InterceptionMetrics, InterceptionTracker

__all__ = [
    # General monitoring
    'PerformanceMonitor',
    'MetricsCollector',
    'SystemMonitor',
    'PrometheusExporter',
    'AutoEmergencyDetector',
    'is_emergency_active',
    'emergency_metadata',
    # Feature-specific benchmarking metrics
    'ParallelismMetrics',
    'ParallelismTracker',
    'JITMetrics',
    'JITTracker',
    'LoopType',
    'LoopTransformMetrics',
    'LoopTransformTracker',
    'InterceptionMetrics',
    'InterceptionTracker',
]