"""
Epochly Memory Foundation - mmap-Backed Allocator (Tier 2 Fallback)

This module provides a high-performance mmap-backed allocator for use when
the Cython fast allocator is unavailable. Designed to provide intermediate
performance between Cython (Tier 1) and pure Python (Tier 3).

Key features:
- mmap-based allocation for direct memory management
- First-fit allocation with automatic block coalescing
- Performance within 10% of CPython allocator throughput
- Used automatically when Cython extension unavailable

Author: Epochly Memory Foundation Team
Created: 2025-11-11 (MEM-4)
"""

import bisect
import logging
import mmap
import threading
from typing import Optional, Dict, List, Tuple, Any, Set

logger = logging.getLogger(__name__)


class MmapBackedAllocator:
    """
    mmap-based memory allocator for when Cython unavailable.

    This allocator provides intermediate performance (Tier 2) between
    Cython fast allocator (Tier 1) and pure Python fallback (Tier 3).

    Uses size-indexed free block lookup plus automatic coalescing for efficient
    memory reuse even when the free list is large.
    """

    def __init__(self, pool_size_mb: int = 64):
        """
        Initialize mmap-backed allocator.

        Args:
            pool_size_mb: Size of memory pool in megabytes
        """
        self._initialized = False
        self.mmap_pool = None

        self.pool_size = pool_size_mb * 1024 * 1024
        self._lock = threading.Lock()

        try:
            self.mmap_pool = mmap.mmap(-1, self.pool_size)
            logger.info(f"Initialized mmap allocator with {pool_size_mb}MB pool")
            self.allocations: Dict[int, int] = {}

            self._free_offsets: List[int] = []
            self._free_blocks_by_offset: Dict[int, int] = {}
            self._free_blocks_by_size: Dict[int, Set[int]] = {}
            self._sorted_free_sizes: List[int] = []
            self.free_blocks = [(0, self.pool_size)]

            self.total_allocations = 0
            self.total_deallocations = 0
            self._initialized = True
        except Exception as e:
            if self.mmap_pool is not None:
                try:
                    self.mmap_pool.close()
                except Exception:
                    pass
                self.mmap_pool = None
            logger.error(f"Failed to create mmap pool: {e}")
            raise

    @property
    def free_blocks(self) -> List[Tuple[int, int]]:
        return [(offset, self._free_blocks_by_offset[offset]) for offset in self._free_offsets]

    @free_blocks.setter
    def free_blocks(self, blocks: List[Tuple[int, int]]) -> None:
        self._free_offsets = []
        self._free_blocks_by_offset = {}
        self._free_blocks_by_size = {}
        self._sorted_free_sizes = []
        for offset, size in sorted(blocks, key=lambda item: item[0]):
            self._register_free_block(offset, size)

    def _register_free_block(self, offset: int, size: int) -> None:
        if size <= 0:
            return

        if offset in self._free_blocks_by_offset:
            self._unregister_free_block(offset)

        insert_at = bisect.bisect_left(self._free_offsets, offset)
        self._free_offsets.insert(insert_at, offset)
        self._free_blocks_by_offset[offset] = size

        offsets_for_size = self._free_blocks_by_size.get(size)
        if offsets_for_size is None:
            bisect.insort(self._sorted_free_sizes, size)
            offsets_for_size = set()
            self._free_blocks_by_size[size] = offsets_for_size
        offsets_for_size.add(offset)

    def _unregister_free_block(self, offset: int) -> Optional[Tuple[int, int]]:
        size = self._free_blocks_by_offset.pop(offset, None)
        if size is None:
            return None

        index = bisect.bisect_left(self._free_offsets, offset)
        if index < len(self._free_offsets) and self._free_offsets[index] == offset:
            self._free_offsets.pop(index)

        offsets_for_size = self._free_blocks_by_size.get(size)
        if offsets_for_size is not None:
            offsets_for_size.discard(offset)
            if not offsets_for_size:
                del self._free_blocks_by_size[size]
                size_index = bisect.bisect_left(self._sorted_free_sizes, size)
                if size_index < len(self._sorted_free_sizes) and self._sorted_free_sizes[size_index] == size:
                    self._sorted_free_sizes.pop(size_index)

        return offset, size

    def allocate(self, size: int, alignment: int = 8) -> Optional[int]:
        """
        Allocate memory from mmap pool.

        Args:
            size: Size to allocate in bytes
            alignment: Alignment requirement (power of 2)

        Returns:
            Offset of allocated block, or None if allocation failed
        """
        with self._lock:
            if size <= 0:
                return None

            if alignment <= 0 or (alignment & (alignment - 1)) != 0:
                logger.warning(f"Invalid alignment {alignment} (must be power of 2), using default 8")
                alignment = 8

            size_index = bisect.bisect_left(self._sorted_free_sizes, size)

            while size_index < len(self._sorted_free_sizes):
                block_size = self._sorted_free_sizes[size_index]
                offsets = self._free_blocks_by_size.get(block_size)
                if not offsets:
                    size_index += 1
                    continue

                rejected_offsets = []
                while offsets:
                    offset = next(iter(offsets))
                    self._unregister_free_block(offset)

                    aligned_offset = (offset + alignment - 1) & ~(alignment - 1)
                    padding = aligned_offset - offset
                    usable_size = block_size - padding
                    if usable_size < size:
                        rejected_offsets.append(offset)
                        continue

                    for rejected_offset in rejected_offsets:
                        self._register_free_block(rejected_offset, block_size)

                    if padding > 0:
                        self._register_free_block(offset, padding)

                    remainder = usable_size - size
                    if remainder > 0:
                        self._register_free_block(aligned_offset + size, remainder)

                    self.allocations[aligned_offset] = size
                    self.total_allocations += 1
                    return aligned_offset

                for rejected_offset in rejected_offsets:
                    self._register_free_block(rejected_offset, block_size)
                size_index += 1

            return None

    def deallocate(self, offset: int, size: int) -> None:
        """
        Deallocate memory block.

        Args:
            offset: Offset of block to deallocate
            size: Size of block (must match allocation)
        """
        with self._lock:
            if offset not in self.allocations:
                raise ValueError(f"Block at offset {offset} not allocated")

            alloc_size = self.allocations.pop(offset)
            if alloc_size != size:
                logger.warning(f"Deallocation size mismatch: expected {alloc_size}, got {size}")

            merged_offset = offset
            merged_size = alloc_size
            insert_at = bisect.bisect_left(self._free_offsets, offset)

            if insert_at > 0:
                prev_offset = self._free_offsets[insert_at - 1]
                prev_size = self._free_blocks_by_offset[prev_offset]
                if prev_offset + prev_size == merged_offset:
                    self._unregister_free_block(prev_offset)
                    merged_offset = prev_offset
                    merged_size += prev_size
                    insert_at -= 1

            if insert_at < len(self._free_offsets):
                next_offset = self._free_offsets[insert_at]
                next_size = self._free_blocks_by_offset[next_offset]
                if merged_offset + merged_size == next_offset:
                    self._unregister_free_block(next_offset)
                    merged_size += next_size

            self._register_free_block(merged_offset, merged_size)
            self.total_deallocations += 1

    def _coalesce_free_blocks(self) -> None:
        """Coalesce adjacent free blocks to reduce fragmentation."""
        if len(self._free_offsets) <= 1:
            return

        merged: List[Tuple[int, int]] = []
        current_offset = self._free_offsets[0]
        current_size = self._free_blocks_by_offset[current_offset]

        for offset in self._free_offsets[1:]:
            block_size = self._free_blocks_by_offset[offset]
            if current_offset + current_size == offset:
                current_size += block_size
            else:
                merged.append((current_offset, current_size))
                current_offset = offset
                current_size = block_size

        merged.append((current_offset, current_size))
        self.free_blocks = merged

    def get_statistics(self) -> Dict[str, Any]:
        """Get allocator statistics."""
        with self._lock:
            total_free = sum(self._free_blocks_by_offset.values())
            total_allocated = sum(self.allocations.values())
            free_block_count = len(self._free_offsets)

            return {
                'pool_size': self.pool_size,
                'allocated_bytes': total_allocated,
                'free_bytes': total_free,
                'allocations': len(self.allocations),
                'total_allocations': self.total_allocations,
                'total_deallocations': self.total_deallocations,
                'free_blocks': free_block_count,
                'fragmentation_ratio': free_block_count / max(1, len(self.allocations) + free_block_count),
            }

    def cleanup(self, *, _from_del: bool = False) -> None:
        """Clean up mmap resources.

        Args:
            _from_del: True when called from __del__. Uses non-blocking lock
                       acquire to avoid deadlocking the GC if another thread
                       holds the lock.
        """
        if _from_del:
            acquired = self._lock.acquire(blocking=False)
            if not acquired:
                return
        else:
            self._lock.acquire()

        try:
            if hasattr(self, 'mmap_pool') and self.mmap_pool:
                self.mmap_pool.close()
                self.mmap_pool = None

            if hasattr(self, 'allocations'):
                self.allocations.clear()
            self.free_blocks = []

            logger.info("Cleaned up mmap allocator")
        except Exception as e:
            logger.error(f"Error during mmap allocator cleanup: {e}")
        finally:
            self._lock.release()

    def __del__(self):
        """Ensure cleanup on deletion."""
        if hasattr(self, '_initialized') and self._initialized:
            self.cleanup(_from_del=True)
