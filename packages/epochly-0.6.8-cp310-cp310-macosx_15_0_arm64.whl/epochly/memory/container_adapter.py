"""
Container cgroup adapter helpers for memory components.

This module intentionally provides a narrow surface for memory-related
container resource inspection without pulling in the broader runtime
container adapter from ``epochly.containers.adapter``.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Optional


class ContainerAdapter:
    """Read container cgroup resource information with safe fallbacks."""

    def __init__(
        self,
        cgroup_root: os.PathLike[str] | str = "/sys/fs/cgroup",
        host_cpu_count: Optional[int] = None,
    ) -> None:
        self.cgroup_root = Path(cgroup_root)
        self.host_cpu_count = int(host_cpu_count or os.cpu_count() or 1)
        if self.host_cpu_count <= 0:
            self.host_cpu_count = 1

    def _read_text(self, relative_path: str) -> Optional[str]:
        target = self.cgroup_root / relative_path
        try:
            return target.read_text(encoding="utf-8").strip()
        except (FileNotFoundError, NotADirectoryError, OSError, UnicodeDecodeError):
            return None

    @staticmethod
    def _parse_int(raw_value: Optional[str]) -> Optional[int]:
        if raw_value is None or raw_value == "" or raw_value == "max":
            return None

        try:
            return int(raw_value)
        except (TypeError, ValueError):
            return None

    def _read_v2_info(self) -> Dict[str, Any]:
        memory_limit = self._parse_int(self._read_text("memory.max"))
        memory_usage = self._parse_int(self._read_text("memory.current"))

        cpu_quota = -1
        cpu_period = -1
        cpu_max = self._read_text("cpu.max")
        if cpu_max:
            parts = cpu_max.split()
            if len(parts) >= 2:
                quota = self._parse_int(parts[0])
                period = self._parse_int(parts[1])
                if quota is not None:
                    cpu_quota = quota
                if period is not None:
                    cpu_period = period

        cpu_cores: int | float = self.host_cpu_count
        if cpu_quota > 0 and cpu_period > 0:
            cpu_cores = cpu_quota / cpu_period

        info: Dict[str, Any] = {
            "cgroup_version": "v2",
            "memory_limit": memory_limit,
            "memory_usage": memory_usage,
            "cpu_quota": cpu_quota,
            "cpu_period": cpu_period,
            "cpu_cores": cpu_cores,
        }
        if memory_limit is not None and memory_usage is not None:
            info["memory_available"] = max(0, memory_limit - memory_usage)
        return info

    def _read_v1_info(self) -> Dict[str, Any]:
        memory_limit = self._parse_int(self._read_text("memory/memory.limit_in_bytes"))
        if memory_limit is not None and memory_limit >= (1 << 62):
            memory_limit = None

        memory_usage = self._parse_int(self._read_text("memory/memory.usage_in_bytes"))
        cpu_quota = self._parse_int(self._read_text("cpu/cpu.cfs_quota_us"))
        cpu_period = self._parse_int(self._read_text("cpu/cpu.cfs_period_us"))

        normalized_quota = cpu_quota if cpu_quota is not None and cpu_quota > 0 else -1
        normalized_period = cpu_period if cpu_period is not None and cpu_period > 0 else -1

        cpu_cores: int | float = self.host_cpu_count
        if normalized_quota > 0 and normalized_period > 0:
            cpu_cores = normalized_quota / normalized_period

        info: Dict[str, Any] = {
            "cgroup_version": "v1",
            "memory_limit": memory_limit,
            "memory_usage": memory_usage,
            "cpu_quota": normalized_quota,
            "cpu_period": normalized_period,
            "cpu_cores": cpu_cores,
        }
        if memory_limit is not None and memory_usage is not None:
            info["memory_available"] = max(0, memory_limit - memory_usage)
        return info

    def get_environment_info(self) -> Dict[str, Any]:
        """Return cgroup resource information with safe defaults."""
        base_info: Dict[str, Any] = {
            "cgroup_version": None,
            "memory_limit": None,
            "memory_usage": None,
            "memory_available": None,
            "cpu_quota": -1,
            "cpu_period": -1,
            "cpu_cores": self.host_cpu_count,
        }

        if (self.cgroup_root / 'cgroup.controllers').exists():
            base_info.update(self._read_v2_info())
            return base_info

        if (self.cgroup_root / 'memory' / 'memory.limit_in_bytes').exists() or (
            self.cgroup_root / 'cpu' / 'cpu.cfs_quota_us'
        ).exists():
            base_info.update(self._read_v1_info())

        return base_info
