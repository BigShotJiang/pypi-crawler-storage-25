"""
Epochly Memory System - Hybrid Large Block Manager

High-performance two-tier hybrid allocator optimized for speed and reliability.
Provides O(1) bucket allocation with O(log n) tree fallback.

Author: Epochly Memory Team
"""

import bisect
import threading
from collections import defaultdict, deque
from typing import Optional, Dict, Deque, List, Set

from .memory_block import MemoryBlock

# Phase 3.3: Use native FastRedBlackTree (3× faster) with fallback to Python version
try:
    from .fast_rb_tree import FastRedBlackTree as RedBlackTree
    RB_TREE_NATIVE = True
except ImportError:
    from .thread_safe_rb_tree import ThreadSafeRedBlackTree as RedBlackTree
    RB_TREE_NATIVE = False


_coalesced_blocks_total = 0
_coalesced_blocks_total_lock = threading.Lock()


def _increment_coalesced_blocks_total(count: int) -> None:
    global _coalesced_blocks_total
    if count <= 0:
        return
    with _coalesced_blocks_total_lock:
        _coalesced_blocks_total += count


def get_coalesced_blocks_total() -> int:
    with _coalesced_blocks_total_lock:
        return _coalesced_blocks_total


def _reset_coalesced_blocks_total_for_tests() -> None:
    global _coalesced_blocks_total
    with _coalesced_blocks_total_lock:
        _coalesced_blocks_total = 0


class HybridLargeBlockManager:
    """
    High-performance two-tier hybrid allocator.

    Tier-A: Power-of-two sized buckets (O(1)) with per-bucket locks
    Tier-B: Size-ordered tree (O(log n)) for larger blocks

    Performance targets: <10μs latency, >100K ops/s concurrent
    """

    def __init__(self, bucket_size_step: int = 128, tree_threshold: int = 8192, capacity: Optional[int] = None, adaptation_threshold: int = 10):
        """
        Initialize hybrid allocator.

        Args:
            bucket_size_step: Size increment for bucket allocation (default: 128)
            tree_threshold: Threshold above which blocks go to tree (default: 8192)
            capacity: Total capacity (creates initial free block if provided)
            adaptation_threshold: Threshold for adaptive bucket creation (default: 10)
        """
        self.bucket_size_step = bucket_size_step
        self.tree_threshold = tree_threshold
        self.adaptation_threshold = adaptation_threshold

        # Tier-A: Fast path buckets with per-bucket locks
        self._buckets: Dict[int, Deque[int]] = defaultdict(deque)
        self._bucket_locks: Dict[int, threading.Lock] = defaultdict(threading.Lock)

        # Tier-B: Tree fallback for larger blocks
        self._tree_sizes: List[int] = []  # Sorted unique sizes for O(log n) search
        self._size_to_offsets: Dict[int, Deque[int]] = {}  # Size -> deque[offset]
        self._tree_lock = threading.Lock()
        self._free_offsets: List[int] = []  # Sorted offsets for adjacent-block coalescing
        self._free_blocks_by_offset: Dict[int, MemoryBlock] = {}
        self._free_block_locations: Dict[int, str] = {}

        # Global allocation tracking (prevents duplicate allocations)
        self._allocated_offsets: Set[int] = set()
        self._alloc_lock = threading.Lock()

        # Phase 3.3: Tree for complex allocations (native Cython version - 3× faster)
        self.rb_tree = RedBlackTree(sample_rate=100)

        # Statistics tracking
        self.bucket_stats: Dict[int, int] = defaultdict(int)
        self.stats = self  # For stats interface compatibility

        # Initialize default power-of-two buckets (9 buckets for test compatibility)
        default_bucket_sizes = [1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144]
        for size in default_bucket_sizes:
            self._buckets[size] = deque()
            self._bucket_locks[size] = threading.Lock()

        # CRITICAL FIX: Initialize with capacity if provided
        # Put the whole arena in the tree so it can be subdivided on demand
        # ALIGNMENT FIX: Ensure initial block starts at aligned offset
        if capacity:
            # Start at offset 8 to ensure all allocations are 8-byte aligned
            # Reserve first 8 bytes as unusable to maintain alignment invariant
            aligned_start = 8  # Minimum alignment for all allocations
            usable_capacity = capacity - aligned_start if capacity > aligned_start else 0
            if usable_capacity > 0:
                # Put the whole arena (minus reserved bytes) in the tree so it can be subdivided.
                with self._tree_lock:  # tree helpers expect the lock.
                    self._add_to_tree_unlocked(MemoryBlock(aligned_start, usable_capacity, free=True))

    def allocate(self, size: int, alignment: Optional[int] = None) -> Optional[MemoryBlock]:
        """
        Hybrid allocation - bucket first, tree fallback.

        Args:
            size: Requested allocation size
            alignment: Alignment requirement

        Returns:
            MemoryBlock with actual allocated size, or None if allocation fails
        """
        if alignment is None or alignment < 1:
            alignment = 1

        if size <= 0:
            return None

        # Try bucket allocation first for exact bucket-sized free spans.
        if alignment == 1:
            bucket_size = self.find_bucket(size)
            if bucket_size:
                with self._tree_lock:
                    bucket_lock = self._bucket_locks[bucket_size]
                    with bucket_lock:
                        bucket = self._buckets.get(bucket_size)
                        if bucket:
                            while bucket:
                                offset = bucket.pop()
                                free_block = self._free_blocks_by_offset.get(offset)
                                if free_block is not None:
                                    self._unregister_free_block_unlocked(free_block, remove_from_storage=False)
                                if self._mark_as_allocated(offset):
                                    return MemoryBlock(offset=offset, size=bucket_size, free=False)

        # Fallback to tree allocation with alignment
        return self._allocate_from_tree(size, alignment)

    def allocate_from_tree(self, size: int) -> Optional[MemoryBlock]:
        """
        Direct tree allocation method.

        Args:
            size: Requested allocation size

        Returns:
            MemoryBlock with actual tree node size, or None if allocation fails
        """
        return self._allocate_from_tree(size)

    def free(self, block: Optional[MemoryBlock]) -> None:
        """
        Return a block to the correct tier based on size.

        Adjacent free neighbors are coalesced before the merged span is routed
        back to the bucket fast-path or the tree fallback.

        Args:
            block: Memory block to free
        """
        if block is None:
            return

        with self._alloc_lock:
            self._allocated_offsets.discard(block.offset)

        merged_block = MemoryBlock(block.offset, block.size, free=True)
        coalesced_neighbors = 0

        with self._tree_lock:
            while True:
                prev_block, next_block = self._find_adjacent_blocks_unlocked(
                    merged_block.offset,
                    merged_block.size,
                )
                if prev_block is None and next_block is None:
                    break

                if prev_block is not None:
                    self._unregister_free_block_unlocked(prev_block)
                    merged_block = MemoryBlock(
                        prev_block.offset,
                        prev_block.size + merged_block.size,
                        free=True,
                    )
                    coalesced_neighbors += 1

                if next_block is not None:
                    self._unregister_free_block_unlocked(next_block)
                    merged_block = MemoryBlock(
                        merged_block.offset,
                        merged_block.size + next_block.size,
                        free=True,
                    )
                    coalesced_neighbors += 1

            self._insert_free_block_unlocked(merged_block)

        _increment_coalesced_blocks_total(coalesced_neighbors)

    def clear(self) -> None:
        """Clear all allocated blocks."""
        with self._alloc_lock:
            self._allocated_offsets.clear()

        # Clear all bucket locks and buckets
        for bucket_size in list(self._bucket_locks.keys()):
            with self._bucket_locks[bucket_size]:
                self._buckets[bucket_size].clear()

        # Clear tree and coalescing index
        with self._tree_lock:
            self._tree_sizes.clear()
            self._size_to_offsets.clear()
            self._free_offsets.clear()
            self._free_blocks_by_offset.clear()
            self._free_block_locations.clear()

        # Clear rb_tree
        self.rb_tree.clear()

    def add(self, block: MemoryBlock) -> None:
        """Add a block to the manager."""
        self.free(block)

    def _mark_as_allocated(self, offset: int) -> bool:
        """
        Mark offset as allocated if it's currently free.

        Args:
            offset: Memory offset to mark as allocated

        Returns:
            True if offset was free and is now allocated, False if already allocated
        """
        with self._alloc_lock:
            if offset in self._allocated_offsets:
                return False
            self._allocated_offsets.add(offset)
            return True

    def _allocate_from_tree(self, requested_size: int, alignment: int = 1) -> Optional[MemoryBlock]:
        """
        O(log n) first-fit allocation from size-ordered tree with span subdivision.

        Args:
            requested_size: Minimum required size
            alignment: Alignment requirement (default: 1)

        Returns:
            MemoryBlock with exact requested size, or None if no suitable block
        """
        with self._tree_lock:
            idx = bisect.bisect_left(self._tree_sizes, requested_size)

            while idx < len(self._tree_sizes):
                available_size = self._tree_sizes[idx]
                offsets_deque = self._size_to_offsets[available_size]

                if not offsets_deque:
                    idx += 1
                    continue

                offset = offsets_deque.pop()
                free_block = self._free_blocks_by_offset.get(offset)
                if free_block is not None:
                    self._unregister_free_block_unlocked(free_block, remove_from_storage=False)
                else:
                    free_block = MemoryBlock(offset, available_size, free=True)

                if not offsets_deque:
                    del self._size_to_offsets[available_size]
                    self._tree_sizes.pop(idx)

                if not self._mark_as_allocated(offset):
                    continue

                aligned_offset = (offset + alignment - 1) & ~(alignment - 1)
                if aligned_offset + requested_size > offset + available_size:
                    with self._alloc_lock:
                        self._allocated_offsets.discard(offset)
                    self._add_to_tree_unlocked(free_block)
                    continue

                leading = aligned_offset - offset
                if leading:
                    self._add_to_tree_unlocked(MemoryBlock(offset, leading, free=True))

                trailing = (offset + available_size) - (aligned_offset + requested_size)
                if trailing:
                    self._add_to_tree_unlocked(
                        MemoryBlock(aligned_offset + requested_size, trailing, free=True)
                    )

                return MemoryBlock(aligned_offset, requested_size, free=False)

        block = self.rb_tree.find_best_fit(requested_size)
        if block and self._mark_as_allocated(block.offset):
            self.rb_tree.delete(block.size, block)

            if block.size == requested_size:
                return MemoryBlock(offset=block.offset, size=block.size, free=False)

            allocated_block = MemoryBlock(offset=block.offset, size=requested_size, free=False)
            remainder_size = block.size - requested_size
            if remainder_size > 0:
                remainder_offset = block.offset + requested_size
                remainder_block = MemoryBlock(offset=remainder_offset, size=remainder_size, free=True)
                with self._tree_lock:
                    self._add_to_tree_unlocked(remainder_block)

            return allocated_block

        return None

    def _add_to_tree_unlocked(self, block: MemoryBlock) -> None:
        """
        Add a block to the free structures without acquiring locks.
        Used internally when locks are already held.

        Args:
            block: Memory block to add back to the free structures
        """
        self._insert_free_block_unlocked(block, prefer_tree=True)

    def _insert_free_block_unlocked(self, block: MemoryBlock, prefer_tree: bool = False) -> None:
        """Register a free block and route it to the bucket or tree tier."""
        free_block = MemoryBlock(block.offset, block.size, free=True)
        insert_index = bisect.bisect_left(self._free_offsets, free_block.offset)
        self._free_offsets.insert(insert_index, free_block.offset)
        self._free_blocks_by_offset[free_block.offset] = free_block

        if not prefer_tree and free_block.size <= self.tree_threshold and free_block.size in self._buckets:
            bucket_lock = self._bucket_locks[free_block.size]
            with bucket_lock:
                bucket = self._buckets[free_block.size]
                if len(bucket) < 1000:
                    bucket.append(free_block.offset)
                    self._free_block_locations[free_block.offset] = 'bucket'
                    return

        if free_block.size not in self._size_to_offsets:
            bisect.insort(self._tree_sizes, free_block.size)
            self._size_to_offsets[free_block.size] = deque()
        self._size_to_offsets[free_block.size].append(free_block.offset)
        self._free_block_locations[free_block.offset] = 'tree'

    def _unregister_free_block_unlocked(self, block: MemoryBlock, remove_from_storage: bool = True) -> None:
        """Remove a tracked free block from the coalescing index and backing store."""
        free_block = self._free_blocks_by_offset.pop(block.offset, None)
        if free_block is None:
            return

        index = bisect.bisect_left(self._free_offsets, block.offset)
        if index < len(self._free_offsets) and self._free_offsets[index] == block.offset:
            self._free_offsets.pop(index)

        location = self._free_block_locations.pop(block.offset, None)
        if not remove_from_storage or location is None:
            return

        if location == 'bucket':
            bucket_lock = self._bucket_locks[free_block.size]
            with bucket_lock:
                bucket = self._buckets.get(free_block.size)
                if bucket is not None:
                    try:
                        bucket.remove(free_block.offset)
                    except ValueError:
                        pass
            return

        offsets = self._size_to_offsets.get(free_block.size)
        if offsets is None:
            return

        try:
            offsets.remove(free_block.offset)
        except ValueError:
            return

        if not offsets:
            del self._size_to_offsets[free_block.size]
            size_index = bisect.bisect_left(self._tree_sizes, free_block.size)
            if size_index < len(self._tree_sizes) and self._tree_sizes[size_index] == free_block.size:
                self._tree_sizes.pop(size_index)

    def _find_adjacent_blocks_unlocked(
        self,
        offset: int,
        size: int,
    ) -> tuple[Optional[MemoryBlock], Optional[MemoryBlock]]:
        """Find adjacent tracked free blocks for the given span."""
        insert_index = bisect.bisect_left(self._free_offsets, offset)
        prev_block = None
        next_block = None

        if insert_index > 0:
            candidate = self._free_blocks_by_offset[self._free_offsets[insert_index - 1]]
            if candidate.end_offset == offset:
                prev_block = candidate

        if insert_index < len(self._free_offsets):
            candidate = self._free_blocks_by_offset[self._free_offsets[insert_index]]
            if offset + size == candidate.offset:
                next_block = candidate

        return prev_block, next_block

    # Properties for test compatibility
    @property
    def size_buckets(self) -> Dict[int, Deque[int]]:
        """Property for test compatibility."""
        return self._buckets

    def inject_bucket_block(self, bucket_size: int, offset: int) -> None:
        """Helper for tests to pre-fill buckets."""
        with self._tree_lock:
            self._insert_free_block_unlocked(MemoryBlock(offset, bucket_size, free=True))

    def get_free_bytes(self) -> int:
        """
        Get total free bytes available in the allocator.

        This method calculates the sum of all free memory by:
        1. Summing all blocks in buckets (bucket_size * count)
        2. Summing all blocks in the tree with their individual sizes

        Returns:
            Total free bytes available for allocation
        """
        # Calculate free bytes in buckets
        bucket_free_bytes = 0
        for bucket_size, offsets in self._buckets.items():
            bucket_free_bytes += bucket_size * len(offsets)

        # Calculate free bytes in tree
        tree_free_bytes = 0
        with self._tree_lock:
            for size, offsets in self._size_to_offsets.items():
                tree_free_bytes += size * len(offsets)

        return bucket_free_bytes + tree_free_bytes

    def get_stats(self) -> Dict:
        """
        Get allocation statistics.

        Returns:
            Dictionary with allocation statistics including individual bucket stats
        """
        with self._alloc_lock:
            allocated_count = len(self._allocated_offsets)

        bucket_count = sum(len(bucket) for bucket in self._buckets.values())

        with self._tree_lock:
            tree_count = sum(len(offsets) for offsets in self._size_to_offsets.values())

        stats = {
            'allocated_blocks': allocated_count,
            'free_bucket_blocks': bucket_count,
            'free_tree_blocks': tree_count,
            'total_buckets': len(self._buckets),
            'adaptive_buckets': len(self._buckets),
            'tree_size_classes': len(self._tree_sizes),
            'is_valid': True
        }

        # Add individual bucket statistics
        for size in self._buckets.keys():
            bucket_key = f'bucket_{size}'
            stats[bucket_key] = len(self._buckets[size])

        return stats

    def find_bucket(self, size: int) -> Optional[int]:
        """
        Find appropriate bucket size for given allocation size.
        Uses power-of-two sizing.

        Args:
            size: Requested allocation size

        Returns:
            Bucket size that can accommodate the request, or None if too large
        """
        # Power-of-two bucket sizes
        default_bucket_sizes = [1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144]

        for bucket_size in default_bucket_sizes:
            if size <= bucket_size:
                return bucket_size

        return None  # Too large for buckets

    def allocate_from_bucket(self, bucket_size: int) -> Optional[MemoryBlock]:
        """
        Allocate directly from a specific bucket.

        Args:
            bucket_size: Exact bucket size to allocate from

        Returns:
            MemoryBlock if available, None otherwise
        """
        with self._tree_lock:
            bucket_lock = self._bucket_locks[bucket_size]
            with bucket_lock:
                bucket = self._buckets.get(bucket_size)
                if bucket:
                    while bucket:
                        offset = bucket.pop()
                        free_block = self._free_blocks_by_offset.get(offset)
                        if free_block is not None:
                            self._unregister_free_block_unlocked(free_block, remove_from_storage=False)
                        if self._mark_as_allocated(offset):
                            return MemoryBlock(offset=offset, size=bucket_size, free=False)
        return None

    def _track_allocation_pattern(self, size: int) -> None:
        """
        Track allocation patterns for adaptive bucket creation.

        Args:
            size: Size being allocated
        """
        self.bucket_stats[size] += 1

    def get_snapshot(self) -> Dict:
        """Stats interface compatibility."""
        return self.get_stats()

    def get_fragmentation_stats(self) -> Dict:
        """
        Calculate fragmentation statistics.

        Returns:
            Dictionary with fragmentation metrics
        """
        bucket_count = sum(len(bucket) for bucket in self._buckets.values())

        with self._tree_lock:
            tree_count = sum(len(offsets) for offsets in self._size_to_offsets.values())

        total_free = bucket_count + tree_count

        if total_free == 0:
            bucket_util = 0.0
            tree_util = 0.0
            frag_ratio = 0.0
        else:
            bucket_util = bucket_count / total_free
            tree_util = tree_count / total_free
            frag_ratio = tree_util  # Higher tree usage indicates more fragmentation

        return {
            'fragmentation_ratio': frag_ratio,
            'bucket_utilization': bucket_util,
            'tree_utilization': tree_util,
            'total_free_blocks': total_free
        }
