"""Shared-memory lifecycle helpers for Epochly memory subsystems."""

from .stale_cleanup import (
    cleanup_stale_shm,
    deregister_shm_segment,
    get_stale_ttl_seconds,
    register_shm_segment,
    should_reap_stale_shm_segment,
)

__all__ = [
    "cleanup_stale_shm",
    "deregister_shm_segment",
    "get_stale_ttl_seconds",
    "register_shm_segment",
    "should_reap_stale_shm_segment",
]
