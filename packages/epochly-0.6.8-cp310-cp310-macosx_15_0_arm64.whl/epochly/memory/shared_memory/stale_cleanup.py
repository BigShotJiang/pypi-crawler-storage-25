"""Stale shared-memory cleanup based on creator PID liveness plus TTL."""

from __future__ import annotations

import json
import logging
import os
import platform
import time
import threading
from pathlib import Path
from typing import Any, Callable, Optional

from multiprocessing import shared_memory


DEFAULT_SHM_STALE_TTL_SECONDS = 60
POSIX_SHM_REGISTRY_TEMPLATE = "/tmp/epochly_shm_registry_{uid}.json"
SHM_PREFIX = "epy_"
MAX_CLEANUP_ENTRIES = 20


_REGISTRY_LOCK = threading.Lock()


def get_stale_ttl_seconds() -> int:
    """Return the configured stale-segment TTL in seconds."""
    raw_value = os.environ.get("EPOCHLY_SHM_STALE_TTL_SECONDS", "").strip()
    if not raw_value:
        return DEFAULT_SHM_STALE_TTL_SECONDS

    try:
        ttl_seconds = int(float(raw_value))
    except ValueError:
        return DEFAULT_SHM_STALE_TTL_SECONDS

    return max(ttl_seconds, 0)


def should_reap_stale_shm_segment(
    creator_pid: Optional[int],
    segment_mtime: float,
    *,
    ttl_seconds: Optional[int] = None,
    now: Optional[float] = None,
    kill: Optional[Callable[[int, int], None]] = None,
) -> bool:
    """Return True only for dead creator PIDs whose segments are older than TTL."""
    if creator_pid is None:
        return False

    effective_now = time.time() if now is None else now
    effective_ttl = get_stale_ttl_seconds() if ttl_seconds is None else ttl_seconds
    if effective_now - segment_mtime <= effective_ttl:
        return False

    kill_fn = os.kill if kill is None else kill
    try:
        kill_fn(int(creator_pid), 0)
    except ProcessLookupError:
        return True
    except (PermissionError, OSError, TypeError, ValueError):
        return False

    return False


def register_shm_segment(
    shm_name: str,
    *,
    registry_path: Optional[Path | str] = None,
    system: Optional[str] = None,
    pid: Optional[int] = None,
    created: Optional[float] = None,
) -> None:
    """Record the creator PID and creation time for a POSIX SHM segment."""
    if (system or platform.system()) == "Windows":
        return

    path = _normalize_registry_path(registry_path)
    with _REGISTRY_LOCK:
        registry = _load_registry(path)
        registry[shm_name] = {
            "pid": os.getpid() if pid is None else pid,
            "created": time.time() if created is None else created,
        }
        _write_registry(path, registry)


def deregister_shm_segment(
    shm_name: str,
    *,
    registry_path: Optional[Path | str] = None,
    system: Optional[str] = None,
) -> None:
    """Remove a POSIX SHM segment from the creator registry."""
    if (system or platform.system()) == "Windows":
        return

    path = _normalize_registry_path(registry_path)
    with _REGISTRY_LOCK:
        registry = _load_registry(path)
        if shm_name not in registry:
            return

        registry.pop(shm_name, None)
        _write_registry(path, registry)


def cleanup_stale_shm(
    logger: logging.Logger,
    *,
    system: Optional[str] = None,
    shm_dir: Optional[Path | str] = None,
    registry_path: Optional[Path | str] = None,
    now: Optional[float] = None,
    open_existing_shared_memory: Callable[[str], shared_memory.SharedMemory],
    get_shared_memory_name: Callable[[shared_memory.SharedMemory], Optional[str]],
    unregister_from_resource_tracker: Callable[[str], None],
    raw_unlink_shared_memory: Callable[[str], None],
    supports_track: bool,
    kill: Optional[Callable[[int, int], None]] = None,
) -> int:
    """Remove stale Epochly SHM segments using PID liveness plus TTL."""
    if os.environ.get("EPOCHLY_SKIP_STALE_CLEANUP", "").strip() == "1":
        return 0

    active_system = system or platform.system()
    if active_system == "Linux":
        return _cleanup_stale_linux(
            logger,
            now=now,
            shm_dir=shm_dir,
            registry_path=registry_path,
            open_existing_shared_memory=open_existing_shared_memory,
            get_shared_memory_name=get_shared_memory_name,
            unregister_from_resource_tracker=unregister_from_resource_tracker,
            raw_unlink_shared_memory=raw_unlink_shared_memory,
            supports_track=supports_track,
            kill=kill,
        )

    if active_system == "Darwin":
        return _cleanup_stale_macos(
            logger,
            now=now,
            registry_path=registry_path,
            open_existing_shared_memory=open_existing_shared_memory,
            get_shared_memory_name=get_shared_memory_name,
            unregister_from_resource_tracker=unregister_from_resource_tracker,
            raw_unlink_shared_memory=raw_unlink_shared_memory,
            supports_track=supports_track,
            kill=kill,
        )

    return 0


def _cleanup_stale_linux(
    logger: logging.Logger,
    *,
    now: Optional[float],
    shm_dir: Optional[Path | str],
    registry_path: Optional[Path | str],
    open_existing_shared_memory: Callable[[str], shared_memory.SharedMemory],
    get_shared_memory_name: Callable[[shared_memory.SharedMemory], Optional[str]],
    unregister_from_resource_tracker: Callable[[str], None],
    raw_unlink_shared_memory: Callable[[str], None],
    supports_track: bool,
    kill: Optional[Callable[[int, int], None]],
) -> int:
    shm_root = Path("/dev/shm") if shm_dir is None else Path(shm_dir)
    if not shm_root.is_dir():
        return 0

    registry_file = _normalize_registry_path(registry_path)
    registry = _load_registry(registry_file)
    entries = sorted(
        (entry for entry in shm_root.iterdir() if entry.name.startswith(SHM_PREFIX)),
        key=lambda entry: _stat_mtime_or_none(entry) or 0.0,
    )
    if not entries:
        return 0

    if len(entries) > MAX_CLEANUP_ENTRIES:
        logger.info(
            "Found %d stale epy_* segments, cleaning oldest %d",
            len(entries),
            MAX_CLEANUP_ENTRIES,
        )
        entries = entries[:MAX_CLEANUP_ENTRIES]

    current_names = {entry.name for entry in entries}
    for stale_name in list(registry):
        if stale_name not in current_names:
            registry.pop(stale_name, None)

    cleaned = 0
    for entry in entries:
        creator_pid = _extract_registry_pid(registry.get(entry.name))
        segment_mtime = _stat_mtime_or_none(entry)
        if segment_mtime is None:
            registry.pop(entry.name, None)
            continue

        if not should_reap_stale_shm_segment(
            creator_pid,
            segment_mtime,
            now=now,
            kill=kill,
        ):
            continue

        if _reap_segment(
            entry.name,
            open_existing_shared_memory=open_existing_shared_memory,
            get_shared_memory_name=get_shared_memory_name,
            unregister_from_resource_tracker=unregister_from_resource_tracker,
            raw_unlink_shared_memory=raw_unlink_shared_memory,
            supports_track=supports_track,
        ):
            cleaned += 1
            registry.pop(entry.name, None)

    _write_registry(registry_file, registry)
    if cleaned:
        logger.info("Cleaned %d stale epy_* shared-memory segment(s) from /dev/shm", cleaned)

    return cleaned


def _stat_mtime_or_none(entry: Path) -> Optional[float]:
    try:
        return entry.stat().st_mtime
    except FileNotFoundError:
        return None


def _cleanup_stale_macos(
    logger: logging.Logger,
    *,
    now: Optional[float],
    registry_path: Optional[Path | str],
    open_existing_shared_memory: Callable[[str], shared_memory.SharedMemory],
    get_shared_memory_name: Callable[[shared_memory.SharedMemory], Optional[str]],
    unregister_from_resource_tracker: Callable[[str], None],
    raw_unlink_shared_memory: Callable[[str], None],
    supports_track: bool,
    kill: Optional[Callable[[int, int], None]],
) -> int:
    registry_file = _normalize_registry_path(registry_path)
    registry = _load_registry(registry_file)
    if not registry:
        return 0

    cleaned = 0
    for shm_name, info in list(registry.items()):
        creator_pid = _extract_registry_pid(info)
        segment_mtime = _extract_registry_created(info)
        if not should_reap_stale_shm_segment(
            creator_pid,
            segment_mtime,
            now=now,
            kill=kill,
        ):
            continue

        if _reap_segment(
            shm_name,
            open_existing_shared_memory=open_existing_shared_memory,
            get_shared_memory_name=get_shared_memory_name,
            unregister_from_resource_tracker=unregister_from_resource_tracker,
            raw_unlink_shared_memory=raw_unlink_shared_memory,
            supports_track=supports_track,
        ):
            cleaned += 1
            registry.pop(shm_name, None)

    _write_registry(registry_file, registry)
    if cleaned:
        logger.info("Cleaned %d stale epy_* shared-memory segment(s) on macOS", cleaned)

    return cleaned


def _reap_segment(
    segment_name: str,
    *,
    open_existing_shared_memory: Callable[[str], shared_memory.SharedMemory],
    get_shared_memory_name: Callable[[shared_memory.SharedMemory], Optional[str]],
    unregister_from_resource_tracker: Callable[[str], None],
    raw_unlink_shared_memory: Callable[[str], None],
    supports_track: bool,
) -> bool:
    try:
        shm = open_existing_shared_memory(segment_name)
    except FileNotFoundError:
        return True
    except Exception:
        return False

    tracker_name = get_shared_memory_name(shm) or segment_name
    try:
        try:
            shm.close()
        except Exception:
            pass

        if supports_track:
            shm.unlink()
        else:
            unregister_from_resource_tracker(tracker_name)
            raw_unlink_shared_memory(tracker_name)

        return True
    except FileNotFoundError:
        return True
    except Exception:
        if not supports_track:
            try:
                unregister_from_resource_tracker(tracker_name)
            except Exception:
                pass
        return False


def _normalize_registry_path(registry_path: Optional[Path | str]) -> Path:
    if registry_path is None:
        registry_path = POSIX_SHM_REGISTRY_TEMPLATE.format(uid=os.getuid())
    return Path(registry_path)


def _load_registry(registry_path: Path) -> dict[str, dict[str, Any]]:
    if not registry_path.exists():
        return {}

    try:
        registry = json.loads(registry_path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}

    if not isinstance(registry, dict):
        return {}

    return {
        str(name): info
        for name, info in registry.items()
        if isinstance(info, dict)
    }


def _write_registry(registry_path: Path, registry: dict[str, dict[str, Any]]) -> None:
    try:
        registry_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = registry_path.with_suffix(f"{registry_path.suffix}.tmp")
        tmp_path.write_text(json.dumps(registry))
        tmp_path.replace(registry_path)
    except OSError:
        pass


def _extract_registry_pid(info: Any) -> Optional[int]:
    if not isinstance(info, dict):
        return None

    pid = info.get("pid")
    if isinstance(pid, int):
        return pid

    if isinstance(pid, str) and pid.isdigit():
        return int(pid)

    return None


def _extract_registry_created(info: Any) -> float:
    if not isinstance(info, dict):
        return 0.0

    created = info.get("created")
    if isinstance(created, (int, float)):
        return float(created)

    return 0.0
