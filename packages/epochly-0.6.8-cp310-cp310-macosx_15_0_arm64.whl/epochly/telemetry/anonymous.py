"""
Pseudonymous community-tier telemetry for Epochly.

Sends a lightweight, pseudonymous session_start event on first import.
No PII is collected. No registration required. Fire-and-forget.

The machine_id is a random UUID v4 cached to disk (~/.epochly/machine_id).
It is stable per machine but NOT reversible to any hardware identifier.

Respects:
- EPOCHLY_DISABLE_TELEMETRY=1 to opt out
- EPOCHLY_TELEMETRY_OPT_OUT=1 to opt out
- Client-side rate limiting (max 1 report per hour)
- Fail silently on any error
"""

import json
import logging
import os
import platform
import secrets
import threading
import time
import uuid as _uuid_mod
from datetime import datetime, timezone
from pathlib import Path

from epochly.telemetry.privacy import TelemetryEmitter, scrub_telemetry_payload
from epochly.utils.atomic_io import atomic_write_bytes

logger = logging.getLogger(__name__)

try:
    from epochly.config.api_endpoints import get_api_endpoint

    TELEMETRY_ENDPOINT = get_api_endpoint("telemetry")
except Exception:
    TELEMETRY_ENDPOINT = (
        os.environ.get("EPOCHLY_API_URL", "https://api.epochly.com").rstrip("/")
        + "/telemetry/metrics"
    )
RATE_LIMIT_SECONDS = 3600
REQUEST_TIMEOUT = 5.0
EPOCHLY_DIR = Path.home() / ".epochly"
MACHINE_ID_FILE = EPOCHLY_DIR / "machine_id"
LAST_REPORT_FILE = EPOCHLY_DIR / "last_telemetry_report"

REQUIRED_FIELDS = frozenset(
    [
        "machine_id",
        "source",
        "os",
        "os_version",
        "python_version",
        "epochly_version",
        "cpu_count",
        "arch",
        "event_type",
        "timestamp",
    ]
)


class AnonymousTelemetryEmitter(TelemetryEmitter):
    def is_enabled(self) -> bool:
        return (
            super().is_enabled()
            and os.environ.get("EPOCHLY_TEST_MODE", "0") != "1"
            and os.environ.get("EPOCHLY_OFFLINE_MODE", "0") != "1"
        )

    def build_payload(self, event_type: str = "session_start") -> dict:
        return build_anonymous_payload(event_type)


def _generate_machine_id() -> str:
    return str(_uuid_mod.uuid4())


def _generate_telemetry_salt() -> str:
    return secrets.token_hex(16)


def _read_identity_record() -> dict:
    try:
        if not MACHINE_ID_FILE.exists():
            return {}
        stored = MACHINE_ID_FILE.read_text().strip()
    except OSError:
        return {}

    if not stored:
        return {}

    try:
        data = json.loads(stored)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    return {"machine_id": stored}


def _write_identity_record(record: dict) -> None:
    try:
        atomic_write_bytes(
            MACHINE_ID_FILE,
            json.dumps(record).encode("utf-8"),
            mode=0o600,
        )
    except OSError:
        pass


def _ensure_identity_record() -> dict:
    record = _read_identity_record()
    normalized = {
        "machine_id": record.get("machine_id") or _generate_machine_id(),
        "telemetry_salt": record.get("telemetry_salt") or _generate_telemetry_salt(),
    }
    if normalized != record:
        _write_identity_record(normalized)
    return normalized


def get_machine_id() -> str:
    return _ensure_identity_record()["machine_id"]


def get_telemetry_salt() -> str:
    return _ensure_identity_record()["telemetry_salt"]


def _is_rate_limited() -> bool:
    try:
        if LAST_REPORT_FILE.exists():
            ts = float(LAST_REPORT_FILE.read_text().strip())
            if time.time() - ts < RATE_LIMIT_SECONDS:
                return True
    except (OSError, ValueError):
        pass
    return False


def _record_report_time() -> None:
    try:
        atomic_write_bytes(
            LAST_REPORT_FILE,
            str(time.time()).encode("utf-8"),
            mode=0o600,
        )
    except OSError:
        pass


def _get_epochly_version() -> str:
    try:
        from importlib.metadata import version

        return version("epochly")
    except Exception:
        try:
            import epochly

            return getattr(epochly, "__version__", "unknown")
        except Exception:
            return "unknown"


def build_anonymous_payload(event_type: str = "session_start") -> dict:
    payload = {
        "machine_id": get_machine_id(),
        "source": "community",
        "os": platform.system(),
        "os_version": platform.release(),
        "python_version": platform.python_version(),
        "epochly_version": _get_epochly_version(),
        "cpu_count": os.cpu_count() or 0,
        "arch": platform.machine(),
        "event_type": event_type,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    return scrub_telemetry_payload(payload)


def _send_telemetry(payload: dict) -> bool:
    try:
        import urllib.request
        from epochly.config.api_endpoints import get_request_source

        source = get_request_source()
        header_source = source if source == "ci" else "community"
        sanitized_payload = scrub_telemetry_payload(payload)
        data = json.dumps(sanitized_payload).encode("utf-8")
        req = urllib.request.Request(
            TELEMETRY_ENDPOINT,
            data=data,
            headers={
                "Content-Type": "application/json",
                "X-Epochly-Source": header_source,
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return 200 <= resp.status < 300
    except Exception:
        return False


def _telemetry_worker() -> None:
    try:
        payload = build_anonymous_payload()
        _send_telemetry(payload)
        _record_report_time()
    except Exception:
        pass


def maybe_send_anonymous_telemetry() -> None:
    emitter = AnonymousTelemetryEmitter()
    if not emitter.is_enabled():
        return
    if _is_rate_limited():
        return

    t = threading.Thread(
        target=_telemetry_worker, daemon=True, name="epochly-TelemetryWorker"
    )
    _t_telemetry_stop = threading.Event()
    try:
        from epochly.core.thread_registry import register_thread

        register_thread(
            t, stop_callback=_t_telemetry_stop.set, name="epochly-TelemetryWorker"
        )
    except ImportError:
        pass
    t.start()
