"""Telemetry privacy helpers and shared enablement gates."""

from __future__ import annotations

import getpass
import os
import platform
import re
import socket
from pathlib import Path
from typing import Any

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_MAC_RE = re.compile(r"\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b")
_LINUX_HOME_RE = re.compile(r"/home/[^/\s]+(?:/[^\s]*)?")
_MACOS_HOME_RE = re.compile(r"/Users/[^/\s]+(?:/[^\s]*)?")
_WINDOWS_HOME_RE = re.compile(r"[A-Za-z]:\\Users\\[^\\/\s]+(?:\\[^\s]*)?")


def telemetry_opt_out_enabled() -> bool:
    return (
        os.environ.get("EPOCHLY_TELEMETRY_OPT_OUT", "0") == "1"
        or os.environ.get("EPOCHLY_DISABLE_TELEMETRY", "0") == "1"
    )


def telemetry_enabled_by_default() -> bool:
    return not telemetry_opt_out_enabled()


def lens_telemetry_enabled() -> bool:
    return (
        os.environ.get("EPOCHLY_TELEMETRY_OPT_IN", "0") == "1"
        and not telemetry_opt_out_enabled()
        and os.environ.get("EPOCHLY_DISABLE") != "1"
    )


class TelemetryEmitter:
    requires_opt_in = False

    def is_enabled(self) -> bool:
        if self.requires_opt_in:
            return lens_telemetry_enabled()
        return telemetry_enabled_by_default()

    def scrub_payload(self, payload: Any) -> Any:
        return scrub_telemetry_payload(payload)


def _runtime_tokens() -> list[str]:
    values = []
    for value in (
        socket.gethostname(),
        platform.node(),
        getpass.getuser(),
        str(Path.home()),
    ):
        if value and value not in values:
            values.append(value)
    return sorted(values, key=len, reverse=True)


def _scrub_string(value: str) -> str:
    scrubbed = value
    for token in _runtime_tokens():
        scrubbed = scrubbed.replace(token, "[redacted]")
    scrubbed = _EMAIL_RE.sub("[redacted-email]", scrubbed)
    scrubbed = _IPV4_RE.sub("[redacted-ip]", scrubbed)
    scrubbed = _MAC_RE.sub("[redacted-mac]", scrubbed)
    scrubbed = _LINUX_HOME_RE.sub("[redacted-home]", scrubbed)
    scrubbed = _MACOS_HOME_RE.sub("[redacted-home]", scrubbed)
    scrubbed = _WINDOWS_HOME_RE.sub("[redacted-home]", scrubbed)
    return scrubbed


def scrub_telemetry_payload(payload: Any) -> Any:
    if isinstance(payload, dict):
        return {key: scrub_telemetry_payload(value) for key, value in payload.items()}
    if isinstance(payload, list):
        return [scrub_telemetry_payload(value) for value in payload]
    if isinstance(payload, tuple):
        return tuple(scrub_telemetry_payload(value) for value in payload)
    if isinstance(payload, set):
        return {scrub_telemetry_payload(value) for value in payload}
    if isinstance(payload, str):
        return _scrub_string(payload)
    return payload
