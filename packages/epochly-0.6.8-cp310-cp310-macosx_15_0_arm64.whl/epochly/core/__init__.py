"""Core package exports for boot/config observability."""

from __future__ import annotations

from ..bootstrap import BootPhaseError, get_boot_phase

__all__ = ["BootPhaseError", "get_boot_phase"]
