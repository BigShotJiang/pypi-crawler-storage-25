"""Shared HALF_OPEN probe gate for circuit breaker concurrency control."""

from __future__ import annotations

import threading
from typing import Optional


class HalfOpenGateLease:
    """Represents one acquired HALF_OPEN admission permit."""

    def __init__(self, semaphore: threading.BoundedSemaphore):
        self._semaphore = semaphore
        self._lock = threading.Lock()
        self._released = False

    def release(self) -> None:
        """Release the permit once."""
        with self._lock:
            if self._released:
                return
            self._released = True

        self._semaphore.release()


class HalfOpenGate:
    """Non-blocking semaphore gate for bounded HALF_OPEN probe admission."""

    def __init__(self, max_concurrent_probes: int = 1):
        if (
            not isinstance(max_concurrent_probes, int)
            or isinstance(max_concurrent_probes, bool)
            or max_concurrent_probes < 1
        ):
            raise ValueError("max_concurrent_probes must be a positive integer")

        self.max_concurrent_probes = max_concurrent_probes
        self._lock = threading.Lock()
        self._semaphore = threading.BoundedSemaphore(value=max_concurrent_probes)

    def try_acquire(self) -> Optional[HalfOpenGateLease]:
        """Try to acquire a permit without blocking."""
        with self._lock:
            semaphore = self._semaphore

        if not semaphore.acquire(blocking=False):
            return None

        return HalfOpenGateLease(semaphore)

    def reset(self) -> None:
        """Reset the gate to a fully available state."""
        with self._lock:
            self._semaphore = threading.BoundedSemaphore(
                value=self.max_concurrent_probes
            )
