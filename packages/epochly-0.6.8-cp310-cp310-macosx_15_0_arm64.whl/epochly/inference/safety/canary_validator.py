"""
CanaryValidator - Workload-specific canary validation for inference optimizations.

Dispatches to semantically meaningful validators for each model type:
- EmbeddingValidator: cosine similarity
- ClassifierValidator: top-k agreement + logit delta
- RerankerValidator: Spearman rank correlation
- GenerationValidator: token agreement + length check
- EncoderValidator: pointwise tolerance (generic fallback)

When a ValidatorRegistry is provided, CanaryValidator delegates all validator
lookups to the registry, enabling custom workload validators.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Protocol, TYPE_CHECKING

# VAL-DEPS-003: optional
try:
    from scipy.stats import spearmanr as _scipy_spearmanr
except ImportError:
    _scipy_spearmanr = None

import numpy as np

from ..frameworks.base_adapter import InferenceAdapter
from .golden_store import GoldenSample

if TYPE_CHECKING:
    from .validator_registry import ValidatorRegistry

logger = logging.getLogger(__name__)


class CanaryValidationResult(Enum):
    """Result of canary validation."""

    PASS = "pass"
    FAIL = "fail"
    INSUFFICIENT = "insufficient"
    MARGINAL = "marginal"


@dataclass
class CanaryReport:
    """Detailed report from canary validation."""

    result: CanaryValidationResult
    optimization_name: str
    samples_tested: int
    workload_metrics: Dict[str, float]
    failed_samples: List[int]
    duration_ms: float
    timestamp: float


@dataclass
class CanaryConfig:
    """Configuration for canary validation thresholds."""

    min_samples: int = 50
    # Tolerance by precision
    tolerance_fp32: float = 1e-5
    tolerance_fp16: float = 1e-3
    tolerance_int8: float = 1e-2
    # Embedding
    embedding_min_cosine: float = 0.999
    embedding_nn_k: int = 10
    # Classifier
    classifier_top_k: int = 5
    classifier_max_logit_delta: float = 0.01
    # Reranker
    reranker_min_rank_corr: float = 0.99
    # Generation
    gen_min_token_agreement: float = 0.95
    gen_max_length_delta_pct: float = 0.10


class WorkloadValidator(Protocol):
    """Protocol for workload-specific validators."""

    def validate(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_model: Any,
        goldens: List[GoldenSample],
        tolerance: float,
    ) -> CanaryReport: ...

    def compute_comparison_metrics(
        self, adapter: InferenceAdapter, original: Any, optimized: Any
    ) -> Dict[str, float]: ...

    def check_drift_thresholds(
        self, ewma_scores: Dict[str, float]
    ) -> Optional[str]: ...


class EmbeddingValidator:
    """Validates embedding model optimizations via cosine similarity."""

    def __init__(self, config: CanaryConfig) -> None:
        self._min_cosine = config.embedding_min_cosine

    def validate(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_model: Any,
        goldens: List[GoldenSample],
        tolerance: float,
    ) -> CanaryReport:
        failed = []
        cosine_scores = []

        for i, golden in enumerate(goldens):
            opt_output = adapter.run_inference(optimized_model, golden.inputs)
            orig_emb = adapter.to_numpy(golden.outputs).flatten().astype(np.float64)
            opt_emb = adapter.to_numpy(opt_output).flatten().astype(np.float64)

            norm_orig = np.linalg.norm(orig_emb)
            norm_opt = np.linalg.norm(opt_emb)
            cosine = float(
                np.dot(orig_emb, opt_emb)
                / (norm_orig * norm_opt + 1e-10)
            )
            cosine_scores.append(cosine)

            if cosine < self._min_cosine:
                failed.append(i)

        result = CanaryValidationResult.FAIL if failed else CanaryValidationResult.PASS
        if not failed and cosine_scores and min(cosine_scores) < self._min_cosine * 1.001:
            result = CanaryValidationResult.MARGINAL

        return CanaryReport(
            result=result,
            optimization_name=optimization_name,
            samples_tested=len(goldens),
            workload_metrics={
                "min_cosine_similarity": min(cosine_scores) if cosine_scores else 0.0,
                "mean_cosine_similarity": float(np.mean(cosine_scores)) if cosine_scores else 0.0,
            },
            failed_samples=failed,
            duration_ms=0,
            timestamp=time.time(),
        )

    def compute_comparison_metrics(
        self, adapter: InferenceAdapter, original: Any, optimized: Any
    ) -> Dict[str, float]:
        orig_emb = adapter.to_numpy(original).flatten().astype(np.float64)
        opt_emb = adapter.to_numpy(optimized).flatten().astype(np.float64)
        cosine = float(
            np.dot(orig_emb, opt_emb)
            / (np.linalg.norm(orig_emb) * np.linalg.norm(opt_emb) + 1e-10)
        )
        return {"cosine_similarity": cosine}

    def check_drift_thresholds(self, ewma_scores: Dict[str, float]) -> Optional[str]:
        cs = ewma_scores.get("cosine_similarity", 1.0)
        if cs < self._min_cosine:
            return f"cosine_similarity EWMA {cs:.4f} < {self._min_cosine}"
        return None


class ClassifierValidator:
    """Validates classifier optimizations via top-k agreement + logit delta."""

    def __init__(self, config: CanaryConfig) -> None:
        self._top_k = config.classifier_top_k
        self._max_logit_delta = config.classifier_max_logit_delta

    def validate(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_model: Any,
        goldens: List[GoldenSample],
        tolerance: float,
    ) -> CanaryReport:
        failed = []
        logit_deltas = []
        top_k_agreements = []

        for i, golden in enumerate(goldens):
            opt_output = adapter.run_inference(optimized_model, golden.inputs)

            # Extract logits from structured outputs (e.g., HuggingFace ModelOutput)
            # Use golden's pre-extracted logits for original
            orig_raw = golden.output_logits if golden.output_logits is not None else golden.outputs

            # For optimized output: try extract_logits first (handles ModelOutput),
            # but only use if it returns a real array/tensor, not None
            opt_raw = opt_output
            try:
                extracted = adapter.extract_logits(opt_output)
                if extracted is not None and hasattr(extracted, "shape"):
                    opt_raw = extracted
            except Exception:
                pass

            orig_logits = adapter.to_numpy(orig_raw).flatten().astype(np.float64)
            opt_logits = adapter.to_numpy(opt_raw).flatten().astype(np.float64)

            # Shape mismatch -> immediate FAIL (e.g., quantization changed output dim)
            if orig_logits.shape != opt_logits.shape:
                failed.append(i)
                top_k_agreements.append(0.0)
                logit_deltas.append(float("inf"))
                continue

            # Top-k agreement
            k = min(self._top_k, len(orig_logits))
            orig_top_k = set(np.argsort(orig_logits)[-k:]) if k > 0 else set()
            opt_top_k = set(np.argsort(opt_logits)[-k:]) if k > 0 else set()
            agreement = len(orig_top_k & opt_top_k) / max(k, 1)
            top_k_agreements.append(agreement)

            # Logit delta
            delta = float(np.max(np.abs(orig_logits - opt_logits)))
            logit_deltas.append(delta)

            if agreement < 1.0 or delta > self._max_logit_delta:
                failed.append(i)

        result = CanaryValidationResult.FAIL if failed else CanaryValidationResult.PASS
        return CanaryReport(
            result=result,
            optimization_name=optimization_name,
            samples_tested=len(goldens),
            workload_metrics={
                "min_top_k_agreement": min(top_k_agreements) if top_k_agreements else 0.0,
                "max_logit_delta": max(logit_deltas) if logit_deltas else 0.0,
                "mean_logit_delta": float(np.mean(logit_deltas)) if logit_deltas else 0.0,
            },
            failed_samples=failed,
            duration_ms=0,
            timestamp=time.time(),
        )

    def compute_comparison_metrics(
        self, adapter: InferenceAdapter, original: Any, optimized: Any
    ) -> Dict[str, float]:
        # Extract logits from structured outputs (e.g., HuggingFace ModelOutput)
        orig_raw = adapter.extract_logits(original)
        orig_raw = orig_raw if orig_raw is not None and hasattr(orig_raw, "shape") else original
        opt_raw = adapter.extract_logits(optimized)
        opt_raw = opt_raw if opt_raw is not None and hasattr(opt_raw, "shape") else optimized
        orig_logits = adapter.to_numpy(orig_raw).flatten().astype(np.float64)
        opt_logits = adapter.to_numpy(opt_raw).flatten().astype(np.float64)
        k = min(self._top_k, len(orig_logits))
        orig_top_k = set(np.argsort(orig_logits)[-k:]) if k > 0 else set()
        opt_top_k = set(np.argsort(opt_logits)[-k:]) if k > 0 else set()
        return {
            "top_k_agreement": len(orig_top_k & opt_top_k) / max(k, 1),
            "max_logit_delta": float(np.max(np.abs(orig_logits - opt_logits))),
        }

    def check_drift_thresholds(self, ewma_scores: Dict[str, float]) -> Optional[str]:
        if ewma_scores.get("top_k_agreement", 1.0) < 1.0:
            return f"top_k_agreement EWMA {ewma_scores['top_k_agreement']:.3f} < 1.0"
        if ewma_scores.get("max_logit_delta", 0) > self._max_logit_delta:
            return f"max_logit_delta EWMA {ewma_scores['max_logit_delta']:.4f} > {self._max_logit_delta}"
        return None


class RerankerValidator:
    """Validates reranker optimizations via Spearman rank correlation."""

    def __init__(self, config: CanaryConfig) -> None:
        self._min_rank_corr = config.reranker_min_rank_corr

    def validate(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_model: Any,
        goldens: List[GoldenSample],
        tolerance: float,
    ) -> CanaryReport:
        failed = []
        rank_correlations = []

        for i, golden in enumerate(goldens):
            opt_output = adapter.run_inference(optimized_model, golden.inputs)
            orig_scores = adapter.to_numpy(golden.outputs).flatten().astype(np.float64)
            opt_scores = adapter.to_numpy(opt_output).flatten().astype(np.float64)

            # Spearman rank correlation
            if _scipy_spearmanr is not None:
                corr, _ = _scipy_spearmanr(orig_scores, opt_scores)
            else:
                corr = _manual_spearman(orig_scores, opt_scores)

            rank_correlations.append(float(corr))
            if corr < self._min_rank_corr:
                failed.append(i)

        result = CanaryValidationResult.FAIL if failed else CanaryValidationResult.PASS
        return CanaryReport(
            result=result,
            optimization_name=optimization_name,
            samples_tested=len(goldens),
            workload_metrics={
                "min_rank_correlation": min(rank_correlations) if rank_correlations else 0.0,
                "mean_rank_correlation": float(np.mean(rank_correlations)) if rank_correlations else 0.0,
            },
            failed_samples=failed,
            duration_ms=0,
            timestamp=time.time(),
        )

    def compute_comparison_metrics(
        self, adapter: InferenceAdapter, original: Any, optimized: Any
    ) -> Dict[str, float]:
        orig = adapter.to_numpy(original).flatten().astype(np.float64)
        opt = adapter.to_numpy(optimized).flatten().astype(np.float64)
        try:
            from scipy.stats import spearmanr
            corr, _ = spearmanr(orig, opt)
        except ImportError:
            corr = _manual_spearman(orig, opt)
        return {"rank_correlation": float(corr)}

    def check_drift_thresholds(self, ewma_scores: Dict[str, float]) -> Optional[str]:
        rc = ewma_scores.get("rank_correlation", 1.0)
        if rc < self._min_rank_corr:
            return f"rank_correlation EWMA {rc:.4f} < {self._min_rank_corr}"
        return None


class GenerationValidator:
    """Validates autoregressive generation optimizations via token agreement."""

    def __init__(self, config: CanaryConfig) -> None:
        self._deterministic_min_agreement = config.gen_min_token_agreement
        self._max_length_delta_pct = config.gen_max_length_delta_pct

    def validate(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_model: Any,
        goldens: List[GoldenSample],
        tolerance: float,
    ) -> CanaryReport:
        failed_set: set[int] = set()
        token_agreements = []

        for i, golden in enumerate(goldens):
            # Use run_generation for LLM models to validate the actual
            # generation path, not just forward-pass
            opt_output = adapter.run_generation(optimized_model, golden.inputs)
            orig_tokens = adapter.to_token_ids(golden.outputs)
            opt_tokens = adapter.to_token_ids(opt_output)

            min_len = min(len(orig_tokens), len(opt_tokens))
            if min_len > 0:
                matches = sum(
                    1 for a, b in zip(orig_tokens[:min_len], opt_tokens[:min_len]) if a == b
                )
                agreement = matches / min_len
            else:
                agreement = 0.0
            token_agreements.append(agreement)

            # Length check
            if len(orig_tokens) > 0:
                length_delta = abs(len(opt_tokens) - len(orig_tokens)) / len(orig_tokens)
                if length_delta > self._max_length_delta_pct:
                    failed_set.add(i)

            if agreement < self._deterministic_min_agreement:
                failed_set.add(i)

        failed = sorted(failed_set)
        result = CanaryValidationResult.FAIL if failed else CanaryValidationResult.PASS
        return CanaryReport(
            result=result,
            optimization_name=optimization_name,
            samples_tested=len(goldens),
            workload_metrics={
                "min_token_agreement": min(token_agreements) if token_agreements else 0.0,
                "mean_token_agreement": float(np.mean(token_agreements)) if token_agreements else 0.0,
            },
            failed_samples=failed,
            duration_ms=0,
            timestamp=time.time(),
        )

    def compute_comparison_metrics(
        self, adapter: InferenceAdapter, original: Any, optimized: Any
    ) -> Dict[str, float]:
        orig_tokens = adapter.to_token_ids(original)
        opt_tokens = adapter.to_token_ids(optimized)
        min_len = min(len(orig_tokens), len(opt_tokens))
        if min_len > 0:
            matches = sum(
                1 for a, b in zip(orig_tokens[:min_len], opt_tokens[:min_len]) if a == b
            )
            agreement = matches / min_len
        else:
            agreement = 0.0
        return {"token_agreement": agreement}

    def check_drift_thresholds(self, ewma_scores: Dict[str, float]) -> Optional[str]:
        ta = ewma_scores.get("token_agreement", 1.0)
        if ta < self._deterministic_min_agreement:
            return f"token_agreement EWMA {ta:.3f} < {self._deterministic_min_agreement}"
        return None


class EncoderValidator:
    """Generic fallback validator using pointwise tolerance."""

    def __init__(self, config: CanaryConfig) -> None:
        self._default_tolerance = config.tolerance_fp32

    def validate(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_model: Any,
        goldens: List[GoldenSample],
        tolerance: float,
    ) -> CanaryReport:
        failed = []
        max_errors = []

        for i, golden in enumerate(goldens):
            opt_output = adapter.run_inference(optimized_model, golden.inputs)
            abs_error = adapter.max_abs_error(golden.outputs, opt_output)
            max_errors.append(abs_error)
            if abs_error > tolerance:
                failed.append(i)

        result = CanaryValidationResult.FAIL if failed else CanaryValidationResult.PASS
        return CanaryReport(
            result=result,
            optimization_name=optimization_name,
            samples_tested=len(goldens),
            workload_metrics={
                "max_absolute_error": max(max_errors) if max_errors else 0.0,
                "mean_absolute_error": float(np.mean(max_errors)) if max_errors else 0.0,
            },
            failed_samples=failed,
            duration_ms=0,
            timestamp=time.time(),
        )

    def compute_comparison_metrics(
        self, adapter: InferenceAdapter, original: Any, optimized: Any
    ) -> Dict[str, float]:
        return {"max_abs_error": float(adapter.max_abs_error(original, optimized))}

    def check_drift_thresholds(self, ewma_scores: Dict[str, float]) -> Optional[str]:
        mae = ewma_scores.get("max_abs_error", 0.0)
        if mae > self._default_tolerance:
            return f"max_abs_error EWMA {mae:.6f} > {self._default_tolerance}"
        return None


class CanaryValidator:
    """Top-level canary validator dispatching to workload-specific validators.

    Accepts an optional ValidatorRegistry for custom validator dispatch.
    When no registry is provided, uses default built-in validators.
    When a registry is provided, all validator lookups go through the
    registry (which includes built-ins plus any custom overrides).
    """

    def __init__(
        self,
        config: Optional[CanaryConfig] = None,
        registry: Optional[ValidatorRegistry] = None,
    ) -> None:
        self._config = config or CanaryConfig()
        self._registry = registry

        # Fallback internal dict when no registry is provided
        self._validators: Dict[str, Any] = {
            "embedding": EmbeddingValidator(self._config),
            "classifier": ClassifierValidator(self._config),
            "reranker": RerankerValidator(self._config),
            "generation": GenerationValidator(self._config),
            "llm": GenerationValidator(self._config),
            "encoder": EncoderValidator(self._config),
        }

    def _resolve_validator(self, workload_type: str) -> Any:
        """Resolve validator for a workload type via registry or internal dict."""
        if self._registry is not None:
            validator = self._registry.get(workload_type)
            if validator is not None:
                return validator
            # Fall back to encoder from registry
            fallback = self._registry.get("encoder")
            if fallback is not None:
                return fallback
        return self._validators.get(workload_type, self._validators["encoder"])

    def validate(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_model: Any,
        goldens: List[GoldenSample],
        precision: str = "fp32",
    ) -> CanaryReport:
        """Run workload-specific canary validation."""
        start = time.perf_counter()

        if len(goldens) < self._config.min_samples:
            return CanaryReport(
                result=CanaryValidationResult.INSUFFICIENT,
                optimization_name=optimization_name,
                samples_tested=len(goldens),
                workload_metrics={},
                failed_samples=[],
                duration_ms=0,
                timestamp=time.time(),
            )

        workload_type = goldens[0].metadata.get("model_type", "encoder")
        validator = self._resolve_validator(workload_type)

        report = validator.validate(
            optimization_name,
            adapter,
            original_model,
            optimized_model,
            goldens,
            self._get_tolerance(precision),
        )

        report.duration_ms = (time.perf_counter() - start) * 1000
        return report

    def get_validator_for(self, workload_type: str) -> Any:
        """Get the workload-specific validator."""
        return self._resolve_validator(workload_type)

    def _get_tolerance(self, precision: str) -> float:
        return {
            "fp32": self._config.tolerance_fp32,
            "fp16": self._config.tolerance_fp16,
            "int8": self._config.tolerance_int8,
            "mixed": self._config.tolerance_fp16,
        }.get(precision, self._config.tolerance_fp32)


def _manual_spearman(a: np.ndarray, b: np.ndarray) -> float:
    """Manual Spearman rank correlation (fallback when scipy unavailable)."""
    n = len(a)
    if n < 2:
        return 1.0
    rank_a = np.argsort(np.argsort(a)).astype(float)
    rank_b = np.argsort(np.argsort(b)).astype(float)
    d = rank_a - rank_b
    return 1.0 - (6.0 * np.sum(d ** 2)) / (n * (n ** 2 - 1))
