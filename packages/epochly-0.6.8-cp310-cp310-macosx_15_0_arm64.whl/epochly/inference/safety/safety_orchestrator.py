"""
SafetyOrchestrator - Top-level coordinator for inference safety.

Wires together golden store, canary validator, circuit breakers,
and fallback chains. Gates every optimization through canary validation.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import deque
from typing import Any, Deque, Dict, Optional

import numpy as np

from ..frameworks.base_adapter import InferenceAdapter
from .canary_validator import CanaryConfig, CanaryValidationResult, CanaryValidator
from .circuit_breaker import CircuitBreaker, CircuitBreakerConfig, CircuitState
from .fallback_chain import FallbackChain, FallbackLevel
from .golden_store import GoldenOutputStore, GoldenStoreConfig

logger = logging.getLogger(__name__)


class SafetyOrchestrator:
    """Top-level safety coordinator for inference optimizations.

    Responsibilities:
    - Gate every optimization through canary validation before activation
    - Maintain per-optimization circuit breakers
    - Manage per-model fallback chains
    - Coordinate golden output capture during L0 profiling
    - Record all safety decisions for observability

    Thread-safe.
    """

    def __init__(
        self,
        golden_config: Optional[GoldenStoreConfig] = None,
        canary_config: Optional[CanaryConfig] = None,
        breaker_config: Optional[CircuitBreakerConfig] = None,
        redactor: Optional[Any] = None,
        audit_logger: Optional[Any] = None,
    ) -> None:
        self._golden_store = GoldenOutputStore(golden_config, redactor=redactor)
        self._canary_validator = CanaryValidator(canary_config)
        self._breaker_config = breaker_config or CircuitBreakerConfig()
        self._breakers: Dict[str, CircuitBreaker] = {}
        self._fallback_chains: Dict[int, FallbackChain] = {}
        self._audit_logger = audit_logger
        self._safety_log: Deque[dict] = deque(maxlen=1000)
        self._lock = threading.Lock()

    @property
    def golden_store(self) -> GoldenOutputStore:
        """Access the golden output store."""
        return self._golden_store

    @property
    def canary_validator(self) -> CanaryValidator:
        """Access the canary validator."""
        return self._canary_validator

    def get_circuit_breaker(self, optimization_name: str) -> CircuitBreaker:
        """Get or create circuit breaker for an optimization type."""
        with self._lock:
            if optimization_name not in self._breakers:
                self._breakers[optimization_name] = CircuitBreaker(
                    optimization_name, self._breaker_config
                )
            return self._breakers[optimization_name]

    def get_fallback_chain(self, model_id: int) -> FallbackChain:
        """Get or create fallback chain for a model."""
        with self._lock:
            if model_id not in self._fallback_chains:
                self._fallback_chains[model_id] = FallbackChain(model_id)
            return self._fallback_chains[model_id]

    def should_allow_optimization(self, optimization_name: str) -> bool:
        """Return whether an optimization may currently execute."""
        return self.get_circuit_breaker(optimization_name).should_allow()

    def gate_optimization(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_candidate: Any,
        model_id: int,
        precision: str = "fp32",
    ) -> bool:
        """Gate an optimization through the full safety pipeline.

        Steps:
        1. Check circuit breaker: is this optimization allowed to try?
        2. Get golden samples: enough data for validation?
        3. Run canary validation: does the optimization preserve correctness?
        4. Record result in circuit breaker
        5. Update fallback chain accordingly

        Returns True if optimization is approved for activation.

        If any internal exception occurs (validator crash, store failure),
        the optimization is REJECTED safely rather than letting the exception
        propagate into the serving path.
        """
        try:
            return self._gate_optimization_inner(
                optimization_name, adapter, original_model,
                optimized_candidate, model_id, precision,
            )
        except Exception as e:
            logger.error(
                "Safety gate exception for '%s' on model %d: %s",
                optimization_name, model_id, e,
            )
            self._log_decision(
                optimization_name, model_id, "REJECTED",
                f"Internal exception in safety gate: {e}",
            )
            return False

    def _gate_optimization_inner(
        self,
        optimization_name: str,
        adapter: InferenceAdapter,
        original_model: Any,
        optimized_candidate: Any,
        model_id: int,
        precision: str = "fp32",
    ) -> bool:
        """Inner implementation of gate_optimization (may raise)."""
        # Step 1: Circuit breaker check
        breaker = self.get_circuit_breaker(optimization_name)
        if not breaker.is_allowed():
            self._log_decision(
                optimization_name,
                model_id,
                "BLOCKED",
                f"Circuit breaker state: {breaker.state.value}",
            )
            return False

        # Step 2: Golden samples
        goldens = self._golden_store.get_canary_set(model_id)
        if goldens is None:
            sample_count = self._golden_store.get_sample_count(model_id)
            self._log_decision(
                optimization_name,
                model_id,
                "DEFERRED",
                f"Insufficient golden samples: {sample_count}",
            )
            return False

        # Step 3: Canary validation
        report = self._canary_validator.validate(
            optimization_name,
            adapter,
            original_model,
            optimized_candidate,
            goldens,
            precision,
        )

        # Step 4: Update circuit breaker
        if report.result == CanaryValidationResult.PASS:
            breaker.record_success()
            self._log_decision(
                optimization_name,
                model_id,
                "APPROVED",
                f"Canary validation passed ({report.samples_tested} samples, "
                f"{report.duration_ms:.1f}ms)",
            )
            return True

        if report.result == CanaryValidationResult.MARGINAL:
            breaker.record_success()  # Marginal is still passing
            self._log_decision(
                optimization_name,
                model_id,
                "APPROVED_MARGINAL",
                f"Canary validation marginal ({report.samples_tested} samples, "
                f"metrics: {report.workload_metrics})",
            )
            return True

        # FAIL or INSUFFICIENT
        breaker.record_failure()
        self._log_decision(
            optimization_name,
            model_id,
            "REJECTED",
            f"Canary validation {report.result.value} "
            f"(failed_samples: {report.failed_samples}, "
            f"metrics: {report.workload_metrics})",
        )

        # Step 5: Update fallback chain
        chain = self.get_fallback_chain(model_id)
        chain.record_failure(_optimization_to_fallback_level(optimization_name))

        return False

    def record_runtime_success(
        self, optimization_name: str, model_id: Optional[int] = None
    ) -> None:
        """Record a successful runtime execution of an optimization.

        If the circuit breaker recovers (HALF_OPEN -> CLOSED), re-enable
        the corresponding fallback level so the optimization can be used again.
        """
        breaker = self.get_circuit_breaker(optimization_name)
        recovered = breaker.record_success_and_check_recovery()

        # If breaker recovered (HALF_OPEN -> CLOSED), re-enable fallback
        if recovered and model_id is not None:
            chain = self.get_fallback_chain(model_id)
            level = _optimization_to_fallback_level(optimization_name)
            chain.enable_level(level)
            chain.restore_to_level(level)
            logger.info(
                "Re-enabled fallback level %s for model %d after "
                "circuit breaker recovery",
                level.value, model_id,
            )

    def record_runtime_result(
        self,
        optimization_name: str,
        model_id: int,
        outputs: Any,
        error: Optional[Exception] = None,
    ) -> bool:
        """Record a runtime outcome from model outputs.

        NaN/Inf values are treated as runtime failures and routed through the
        circuit breaker. Valid outputs count as runtime successes, allowing
        HALF_OPEN probe calls to recover the breaker.

        Returns True when the optimization remains allowed after recording the
        result, otherwise False.
        """
        invalid_reason = self._get_invalid_output_reason(outputs)
        if error is not None:
            invalid_reason = str(error)

        if invalid_reason is not None:
            runtime_error = error or RuntimeError(invalid_reason)
            self.record_runtime_failure(
                optimization_name,
                model_id,
                runtime_error,
            )
            self._log_decision(
                optimization_name,
                model_id,
                "RUNTIME_REJECTED",
                invalid_reason,
            )
            return False

        self.record_runtime_success(optimization_name, model_id)
        return self.should_allow_optimization(optimization_name)

    def record_runtime_failure(
        self, optimization_name: str, model_id: int, error: Optional[Exception] = None
    ) -> None:
        """Record a runtime failure of an optimization."""
        breaker = self.get_circuit_breaker(optimization_name)
        breaker.record_failure(error)

        # Check if circuit breaker tripped
        if breaker.state == CircuitState.OPEN:
            chain = self.get_fallback_chain(model_id)
            chain.disable_level(_optimization_to_fallback_level(optimization_name))
            logger.warning(
                "Optimization '%s' circuit breaker tripped for model %d. "
                "Fallback chain activated.",
                optimization_name,
                model_id,
            )

    def _get_invalid_output_reason(self, outputs: Any) -> Optional[str]:
        """Return a descriptive reason if runtime outputs contain invalid values."""
        for array_like in self._extract_numeric_arrays(outputs):
            try:
                array = np.asarray(array_like, dtype=float)
            except (TypeError, ValueError):
                continue

            if np.any(np.isnan(array)):
                return "NaN detected in output tensor"
            if np.any(np.isinf(array)):
                return "Inf detected in output tensor"
        return None

    def _extract_numeric_arrays(self, value: Any, depth: int = 0) -> list[Any]:
        """Recursively extract numeric array-like values from nested outputs."""
        if depth > 10:
            return []

        arrays: list[Any] = []
        if isinstance(value, np.ndarray):
            arrays.append(value)
        elif isinstance(value, dict):
            for nested in value.values():
                arrays.extend(self._extract_numeric_arrays(nested, depth + 1))
        elif isinstance(value, (list, tuple)):
            if value and all(isinstance(item, (int, float)) for item in value):
                arrays.append(value)
            else:
                for nested in value:
                    arrays.extend(self._extract_numeric_arrays(nested, depth + 1))
        elif hasattr(value, "detach") and hasattr(value, "cpu") and hasattr(value, "numpy"):
            try:
                arrays.append(value.detach().cpu().numpy())
            except Exception:
                pass
        elif isinstance(value, (int, float)):
            arrays.append([value])

        return arrays

    def capture_golden(
        self,
        model_id: int,
        adapter: InferenceAdapter,
        model: Any,
        inputs: Any,
        outputs: Any,
    ) -> None:
        """Capture a golden output sample during L0 profiling."""
        self._golden_store.capture(model_id, adapter, model, inputs, outputs)

    def get_diagnostics(self) -> dict:
        """Return comprehensive safety diagnostics."""
        with self._lock:
            return {
                "breakers": {
                    name: breaker.get_diagnostics()
                    for name, breaker in self._breakers.items()
                },
                "fallback_chains": {
                    mid: chain.get_diagnostics()
                    for mid, chain in self._fallback_chains.items()
                },
                "golden_samples": self._golden_store.get_all_sample_counts(),
                "recent_decisions": list(self._safety_log)[-20:],
            }

    def _log_decision(
        self, optimization_name: str, model_id: int, decision: str, reason: str
    ) -> None:
        """Log a safety decision for observability and audit."""
        entry = {
            "optimization": optimization_name,
            "model_id": model_id,
            "decision": decision,
            "reason": reason,
            "timestamp": time.time(),
        }
        with self._lock:
            self._safety_log.append(entry)

        # Also log to audit logger if configured
        if self._audit_logger is not None:
            try:
                self._audit_logger.log_event(
                    operation="gate_optimization",
                    model_id=model_id,
                    optimization_name=optimization_name,
                    result=decision,
                    details={"reason": reason},
                )
            except Exception:
                pass  # Audit failure should not block safety decisions

        logger.info(
            "Safety decision: %s for '%s' on model %d: %s",
            decision,
            optimization_name,
            model_id,
            reason,
        )


def _optimization_to_fallback_level(optimization_name: str) -> FallbackLevel:
    """Map optimization name to fallback level."""
    mapping = {
        "torch_compile": FallbackLevel.COMPILED,
        "dynamic_micro_batching": FallbackLevel.MICRO_BATCHED,
        "request_cache": FallbackLevel.CACHED,
        "prepost_parallel": FallbackLevel.PREPOST_OPTIMIZED,
    }
    return mapping.get(optimization_name, FallbackLevel.PROFILING_ONLY)
