"""
ModelCompiler - Background model compilation with safety gate.

Background torch.compile with pre-check via torch._dynamo.explain().
Golden validation before swap. Compile cache (PyTorch >= 2.4).

The compiler does NOT approve itself. The safety gate
(SafetyOrchestrator.gate_optimization) is the external authority.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import logging
import pickle
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from ..frameworks.base_adapter import GoldenOutput, InferenceAdapter

logger = logging.getLogger(__name__)

# Guard dynamo import: not all torch versions include torch._dynamo.
# When unavailable, _dynamo_explain is set to None and callers skip
# the explain-based pre-compile check.
_dynamo_explain: Optional[Callable] = None
# VAL-DEPS-003: optional
try:
    import torch._dynamo

    def _run_dynamo_explain(model: Any, *sample_input: Any) -> Any:
        """Run torch._dynamo.explain on a model with sample input.

        Returns an ExplainOutput with graph_break_count attribute.
        """
        return torch._dynamo.explain(model)(*sample_input)

    _dynamo_explain = _run_dynamo_explain
except (ImportError, AttributeError):
    pass


@dataclass
class CompilationConfig:
    """Configuration for model compilation."""

    enabled: bool = True
    backend: str = "inductor"
    mode: str = "reduce-overhead"
    cache_dir: str = "~/.epochly/inference_cache"
    warmup_requests: int = 3
    tolerance: float = 1e-5
    max_graph_breaks: int = 5


class ModelCompiler:
    """Background model compilation with safety gate.

    Follows existing JIT CompilationWorker pattern: model serves
    requests with original while compiled version prepares.

    Features:
    - torch._dynamo.explain() pre-check for graph break diagnosis
    - Compile cache artifact save/load for repeated compilations
    - torch.compile via adapter.compile() for compilation
    - Golden output smoke test before safety gate
    - SafetyOrchestrator.gate_optimization() as external authority

    Thread-safe.
    """

    def __init__(
        self,
        adapter: InferenceAdapter,
        config: Optional[CompilationConfig] = None,
    ) -> None:
        self._adapter = adapter
        self._config = config or CompilationConfig()
        self._compiled_models: Dict[int, Any] = {}
        self._golden_outputs: Dict[int, List[GoldenOutput]] = {}
        self._compilation_in_progress: Set[int] = set()
        self._lock = threading.Lock()

        cache_path = Path(self._config.cache_dir).expanduser()
        cache_path.mkdir(parents=True, exist_ok=True)
        self._cache_dir = cache_path

    def pre_compile_check(
        self, model: Any, sample_input: Tuple[Any, ...]
    ) -> Tuple[bool, Optional[str]]:
        """Pre-compile check via torch._dynamo.explain().

        Counts graph breaks in the model's forward pass. If the count
        exceeds config.max_graph_breaks, compilation is rejected because
        excessive graph breaks negate the performance benefit of torch.compile.

        Args:
            model: The model to check.
            sample_input: A tuple of sample inputs for the model.

        Returns:
            Tuple of (should_compile, reason). reason is None if approved,
            or a descriptive string if rejected.
        """
        if _dynamo_explain is None:
            logger.debug(
                "torch._dynamo.explain not available; skipping pre-compile check"
            )
            return True, None

        try:
            explanation = _dynamo_explain(model, *sample_input)
            graph_break_count = getattr(explanation, "graph_break_count", 0)

            if graph_break_count > self._config.max_graph_breaks:
                reason = (
                    f"Graph break count ({graph_break_count}) exceeds "
                    f"maximum ({self._config.max_graph_breaks}). "
                    f"torch.compile benefit is negated by frequent graph breaks."
                )
                logger.info("Pre-compile check rejected: %s", reason)
                return False, reason

            logger.debug(
                "Pre-compile check passed: %d graph breaks (max %d)",
                graph_break_count,
                self._config.max_graph_breaks,
            )
            return True, None

        except Exception as exc:
            logger.warning(
                "Pre-compile check failed with exception: %s. "
                "Allowing compilation to proceed.",
                exc,
            )
            return True, None

    def _save_to_cache(self, cache_key: str, compiled: Any) -> None:
        """Persist a compiled model artifact to disk.

        Uses pickle serialization for maximum compatibility with
        different compiled model types (traced, scripted, compiled).

        Args:
            cache_key: Unique key derived from model hash, shape signature,
                       and backend.
            compiled: The compiled model artifact.
        """
        cache_file = self._cache_dir / f"{cache_key}.pt"
        try:
            with open(cache_file, "wb") as f:
                pickle.dump(compiled, f, protocol=pickle.HIGHEST_PROTOCOL)
            logger.debug("Saved compiled artifact to cache: %s", cache_file)
        except Exception as exc:
            logger.warning("Failed to save compile cache: %s", exc)

    def _load_from_cache(self, cache_key: str) -> Optional[Any]:
        """Load a compiled model artifact from disk cache.

        Args:
            cache_key: Unique key to look up.

        Returns:
            The cached compiled artifact, or None if not found or corrupted.
        """
        cache_file = self._cache_dir / f"{cache_key}.pt"
        if not cache_file.exists():
            return None

        try:
            with open(cache_file, "rb") as f:
                artifact = pickle.load(f)  # noqa: S301
            logger.debug("Loaded compiled artifact from cache: %s", cache_file)
            return artifact
        except Exception as exc:
            logger.warning(
                "Failed to load compile cache %s: %s. Removing corrupt entry.",
                cache_file,
                exc,
            )
            try:
                cache_file.unlink(missing_ok=True)
            except OSError:
                pass
            return None

    async def compile_async(
        self, model: Any, safety_orchestrator: Any
    ) -> Optional[Any]:
        """Background compilation with explicit safety gate.

        Steps:
        1. Re-entry guard
        2. Check compile cache for existing artifact
        3. Capture golden outputs for smoke test
        4. Smoke test cached/compiled artifact
        5. Safety gate (external authority)
        6. Atomic swap (only after gate approves)

        Cache hits still go through smoke test and safety gate to
        ensure the cached artifact is valid for the current model state
        and passes safety requirements.
        """
        model_id = id(model)

        with self._lock:
            if model_id in self._compilation_in_progress:
                return None
            self._compilation_in_progress.add(model_id)

        try:
            cache_key = self._compute_cache_key(model)

            # Phase 1: Golden outputs (required for smoke test of both
            # cached and freshly compiled artifacts)
            goldens = self._adapter.capture_golden(model, n=3)
            with self._lock:
                self._golden_outputs[model_id] = goldens
                # Clean up old entries to prevent unbounded growth
                if len(self._golden_outputs) > 100:
                    oldest = next(iter(self._golden_outputs))
                    del self._golden_outputs[oldest]

            # Phase 1.5: Pre-compile check (graph break analysis)
            sample = goldens[0].inputs if goldens else None
            if sample is not None:
                sample_input = sample if isinstance(sample, tuple) else (sample,)
                should_compile, reject_reason = self.pre_compile_check(
                    model, sample_input
                )
                if not should_compile:
                    logger.info(
                        "Pre-compile check rejected model %d: %s",
                        model_id, reject_reason,
                    )
                    return None

            # Phase 2: Try compile cache first, else compile fresh
            cached = self._load_from_cache(cache_key)
            if cached is not None:
                logger.info("Compile cache hit for model %d", model_id)
                compiled = cached
            else:
                # Compile in background thread
                loop = asyncio.get_running_loop()
                compiled = await loop.run_in_executor(
                    None, self._compile_model, model
                )
                if compiled is None:
                    return None

            # Phase 3: Smoke test (required for ALL artifacts, cached or fresh)
            if not self._smoke_test(compiled, goldens):
                logger.warning("Smoke test failed for model %d", model_id)
                if cached is not None:
                    # Cached artifact is stale -- remove it
                    cache_file = self._cache_dir / f"{cache_key}.pt"
                    try:
                        cache_file.unlink(missing_ok=True)
                    except OSError:
                        pass
                return None

            # Phase 4: Safety gate (required for ALL artifacts, cached or fresh)
            if not safety_orchestrator.gate_optimization(
                "torch_compile", self._adapter, model, compiled, model_id
            ):
                logger.info("Safety gate rejected compilation for model %d", model_id)
                return None

            # Phase 5: Atomic swap + cache save (only AFTER safety gate approves)
            with self._lock:
                self._compiled_models[model_id] = compiled
            if cached is None:
                # Only save freshly compiled artifacts that passed safety
                self._save_to_cache(cache_key, compiled)
            return compiled

        except Exception as e:
            logger.error("Compilation failed for model %d: %s", model_id, e)
            return None
        finally:
            with self._lock:
                self._compilation_in_progress.discard(model_id)

    def _compile_model(self, model: Any) -> Optional[Any]:
        """Actual compilation -- runs in background thread."""
        try:
            return self._adapter.compile(model, self._config)
        except Exception as e:
            logger.error("torch.compile failed: %s", e)
            return None

    def _smoke_test(self, compiled: Any, goldens: List[GoldenOutput]) -> bool:
        """Compiler-internal smoke test.

        Necessary precondition, NOT a safety gate. Passing this does
        NOT authorize activation.
        """
        if not goldens:
            return False  # Cannot validate without golden outputs

        for golden in goldens:
            try:
                compiled_output = self._adapter.run_inference(compiled, golden.inputs)
                if not self._adapter.outputs_match(
                    golden.outputs, compiled_output, self._config.tolerance
                ):
                    return False
            except Exception:
                return False
        return True

    def _compute_cache_key(self, model: Any) -> str:
        """Hash of model weights + architecture + input signature."""
        model_hash = self._adapter.hash_model(model)
        shape_sig = self._adapter.get_input_shape_signature(model)
        return f"{model_hash}_{shape_sig}_{self._config.backend}"

    def get_compiled(self, model: Any) -> Optional[Any]:
        """Get compiled version if available, else None."""
        with self._lock:
            return self._compiled_models.get(id(model))
