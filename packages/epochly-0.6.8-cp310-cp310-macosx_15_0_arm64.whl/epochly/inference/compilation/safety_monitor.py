"""
TorchCompileSafetyMonitor - Safety monitoring for torch.compile.

Monitors graph break count (via explain), memory growth after compilation,
and NaN/Inf in output tensors. Provides pre-compile, health, and output
validity checks as independent safety signals.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# Guard dynamo import: not all torch versions include torch._dynamo.
_dynamo_explain: Optional[Callable] = None
# VAL-DEPS-003: optional
try:
    import torch._dynamo

    def _run_dynamo_explain(model: Any, *sample_input: Any) -> Any:
        """Run torch._dynamo.explain on a model with sample input."""
        return torch._dynamo.explain(model)(*sample_input)

    _dynamo_explain = _run_dynamo_explain
except (ImportError, AttributeError):
    pass


@dataclass
class PreCompileResult:
    """Result of pre-compile safety check."""

    approved: bool
    graph_break_count: int
    reason: Optional[str] = None


@dataclass
class HealthCheckResult:
    """Result of post-compile health check."""

    healthy: bool
    memory_growth_mb: float
    reason: Optional[str] = None


@dataclass
class OutputValidityResult:
    """Result of output validity check."""

    valid: bool
    reason: Optional[str] = None


class TorchCompileSafetyMonitor:
    """Safety monitor for torch.compile operations.

    Provides three independent safety checks:

    1. pre_compile_check: Analyzes model via torch._dynamo.explain()
       to count graph breaks. Rejects compilation if breaks exceed
       the configured threshold.

    2. check_health: Compares memory usage before and after compilation.
       Flags excessive memory growth that could indicate memory leaks
       or inefficient compiled graphs.

    3. check_output_validity: Scans output tensors for NaN and Inf
       values that indicate numerical instability in the compiled model.

    Thread-safe (stateless checks, no mutable instance state).
    """

    def __init__(
        self,
        max_graph_breaks: int = 5,
        memory_growth_threshold_mb: float = 500.0,
    ) -> None:
        self._max_graph_breaks = max_graph_breaks
        self._memory_growth_threshold_mb = memory_growth_threshold_mb

    def pre_compile_check(
        self, model: Any, sample_input: Tuple[Any, ...]
    ) -> PreCompileResult:
        """Analyze model via torch._dynamo.explain() for graph breaks.

        If torch._dynamo is not available (older PyTorch versions),
        the check approves by default since we cannot analyze.

        Args:
            model: The model to analyze.
            sample_input: Tuple of sample inputs for the model.

        Returns:
            PreCompileResult with approved status and graph break count.
        """
        if _dynamo_explain is None:
            logger.debug(
                "torch._dynamo.explain not available; "
                "approving pre-compile check by default"
            )
            return PreCompileResult(
                approved=True,
                graph_break_count=0,
                reason="dynamo unavailable, check skipped",
            )

        try:
            explanation = _dynamo_explain(model, *sample_input)
            graph_break_count = getattr(explanation, "graph_break_count", 0)

            if graph_break_count > self._max_graph_breaks:
                reason = (
                    f"Graph break count ({graph_break_count}) exceeds "
                    f"threshold ({self._max_graph_breaks})"
                )
                return PreCompileResult(
                    approved=False,
                    graph_break_count=graph_break_count,
                    reason=reason,
                )

            return PreCompileResult(
                approved=True,
                graph_break_count=graph_break_count,
            )

        except Exception as exc:
            logger.warning("dynamo explain failed: %s. Approving by default.", exc)
            return PreCompileResult(
                approved=True,
                graph_break_count=0,
                reason=f"explain failed: {exc}",
            )

    def check_health(
        self,
        pre_compile_memory_mb: float,
        post_compile_memory_mb: float,
    ) -> HealthCheckResult:
        """Check memory growth after compilation.

        Flags compilation if memory increased by more than the configured
        threshold. Large memory growth may indicate:
        - Inefficient compiled graph that duplicates buffers
        - Memory leak in the compilation process
        - Suboptimal fusion decisions

        Args:
            pre_compile_memory_mb: GPU/system memory before compilation (MB).
            post_compile_memory_mb: GPU/system memory after compilation (MB).

        Returns:
            HealthCheckResult with healthy status.
        """
        growth = post_compile_memory_mb - pre_compile_memory_mb

        if growth > self._memory_growth_threshold_mb:
            reason = (
                f"Memory growth ({growth:.1f} MB) exceeds threshold "
                f"({self._memory_growth_threshold_mb:.1f} MB)"
            )
            return HealthCheckResult(
                healthy=False,
                memory_growth_mb=growth,
                reason=reason,
            )

        return HealthCheckResult(
            healthy=True,
            memory_growth_mb=growth,
        )

    def check_output_validity(
        self, outputs: Any
    ) -> OutputValidityResult:
        """Check output tensors for NaN and Inf values.

        Scans all numeric arrays in the output for non-finite values.
        Handles numpy arrays, lists, dicts with array values, and
        nested structures.

        Args:
            outputs: Model output -- can be ndarray, list, dict, or scalar.

        Returns:
            OutputValidityResult with valid status.
        """
        arrays = self._extract_arrays(outputs)

        for arr in arrays:
            try:
                arr_np = np.asarray(arr, dtype=float)
            except (ValueError, TypeError):
                # Non-numeric data, skip validity check
                continue

            if np.any(np.isnan(arr_np)):
                return OutputValidityResult(
                    valid=False,
                    reason="NaN detected in output tensor",
                )
            if np.any(np.isinf(arr_np)):
                return OutputValidityResult(
                    valid=False,
                    reason="Inf detected in output tensor",
                )

        return OutputValidityResult(valid=True)

    def _extract_arrays(self, obj: Any, _depth: int = 0) -> List[Any]:
        """Recursively extract numeric arrays from nested structures.

        Handles: ndarray, list/tuple of numbers, dict with array values,
        and dataclass-like objects with numeric attributes.

        Bounded recursion depth prevents stack overflow on deeply
        nested structures.
        """
        if _depth > 10:
            return []

        arrays: List[Any] = []

        if isinstance(obj, np.ndarray):
            arrays.append(obj)
        elif isinstance(obj, dict):
            for val in obj.values():
                arrays.extend(self._extract_arrays(val, _depth + 1))
        elif isinstance(obj, (list, tuple)):
            # Check if it's a flat numeric list
            if obj and all(isinstance(x, (int, float)) for x in obj):
                arrays.append(obj)
            else:
                for item in obj:
                    arrays.extend(self._extract_arrays(item, _depth + 1))
        elif hasattr(obj, "numpy"):
            # PyTorch tensor-like: convert via .numpy()
            try:
                arrays.append(obj.detach().cpu().numpy())
            except Exception:
                pass
        elif isinstance(obj, (int, float)):
            arrays.append([obj])

        return arrays
