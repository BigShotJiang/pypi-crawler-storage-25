"""
InferenceProxy - Framework-agnostic serving boundary wrapper.

The proxy intercepts model inference calls for profiling and optimization
routing. It wraps a single model instance at the serving boundary.
The model class is never mutated.

Method interception design:
- __call__ routes through the invoke function (framework-native entry point)
- __getattr__ checks _intercepted_methods BEFORE delegating to the wrapped
  object, ensuring framework-native methods (generate(), run(), etc.) go
  through Epochly's profiling path
- Common serving entry points (encode, generate, predict, transform, embed)
  are auto-intercepted via _ALWAYS_INTERCEPT: when accessed and present on
  the wrapped model, they are registered for profiling on the fly
- Adapters declare framework-specific method names to intercept via
  intercepted_methods
- Methods not in that set delegate directly to the wrapped model
- hasattr(proxy, name) returns True ONLY when the wrapped model has name

Why NOT model.__class__.__call__:
- Mutating __call__ on the class changes ALL instances of that type
- On Python 3.12+, setting __call__ in Python clears vectorcall optimization
- PyTorch documents Module.__call__ is where hooks run

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional, TYPE_CHECKING, cast

if TYPE_CHECKING:
    from .base_adapter import InferenceAdapter

from ..context import get_request_context


class InferenceProxy:
    """Proxy object wrapping a model instance for inference interception.

    Framework-agnostic: works with any model type by intercepting the
    framework-native inference entry points:
    - torch.nn.Module:           __call__ (runs hooks + forward)
    - HF Pipeline:               __call__ (tokenize + forward + decode)
    - HF PreTrainedModel:        generate() (autoregressive generation)
    - ONNX InferenceSession:     run(), run_with_iobinding()
    """

    _ALWAYS_INTERCEPT: frozenset[str] = frozenset(
        {"encode", "generate", "predict", "transform", "embed"}
    )

    __slots__ = (
        "_model",
        "_invoke",
        "_intercepted_methods",
        "_intercepted_wrappers",
        "_optimizer",
        "_adapter",
        "_model_id",
        "_profiler",
        "_call_count",
        "_passthrough_when_no_optimizer",
    )

    def __init__(
        self,
        model: Any,
        invoke_fn: Callable,
        adapter: InferenceAdapter,
        intercepted_methods: Optional[Dict[str, Callable]] = None,
        optimizer: Any = None,
        profiler: Any = None,
        passthrough_when_no_optimizer: bool = False,
    ):
        object.__setattr__(self, "_model", model)
        object.__setattr__(self, "_invoke", invoke_fn)
        object.__setattr__(self, "_intercepted_methods", intercepted_methods or {})
        object.__setattr__(self, "_intercepted_wrappers", {})
        object.__setattr__(self, "_optimizer", optimizer)
        object.__setattr__(self, "_adapter", adapter)
        object.__setattr__(self, "_model_id", id(model))
        object.__setattr__(self, "_profiler", profiler)
        object.__setattr__(self, "_call_count", 0)
        object.__setattr__(
            self,
            "_passthrough_when_no_optimizer",
            passthrough_when_no_optimizer,
        )

    def _route(self, original_fn: Callable, *args: Any, **kwargs: Any) -> Any:
        """Common routing logic for all intercepted entry points.

        Execution order:
        1. If optimizer has active optimizations -> route through optimizer
           (optimizer handles its own profiling if needed)
        2. If profiler attached -> profile the original_fn call
        3. Otherwise -> direct passthrough to original_fn

        IMPORTANT: The model is executed EXACTLY ONCE per _route call.
        """
        model = object.__getattribute__(self, "_model")
        model_id = object.__getattribute__(self, "_model_id")
        adapter = object.__getattribute__(self, "_adapter")
        profiler = object.__getattribute__(self, "_profiler")
        optimizer = object.__getattribute__(self, "_optimizer")
        if (
            object.__getattribute__(self, "_passthrough_when_no_optimizer")
            and optimizer is None
        ):
            return original_fn(*args, **kwargs)

        # Update request context model call count
        ctx = get_request_context()
        if ctx is not None:
            ctx.model_calls += 1

        # Increment call count (advisory, race under concurrency is acceptable)
        call_count = object.__getattribute__(self, "_call_count")
        object.__setattr__(self, "_call_count", call_count + 1)

        # Optimization path: optimizer handles execution and its own profiling
        if optimizer is not None and optimizer.has_active_optimizations(model_id):
            return optimizer.execute_inference(
                model_id=model_id,
                adapter=adapter,
                model=model,
                original_fn=original_fn,
                args=args,
                kwargs=kwargs,
            )

        # Profiling path: only pay timing costs for warmup or sampled calls
        if profiler is not None:
            decision = profiler.plan_call(model_id)
            if not decision.should_profile:
                return original_fn(*args, **kwargs)

            timing_event = adapter.create_timing_event()
            call_start = time.perf_counter()
            result = original_fn(*args, **kwargs)
            call_end = time.perf_counter()
            gpu_elapsed = adapter.resolve_timing_event(timing_event)

            profiler.record_profile(
                model_id=model_id,
                adapter=adapter,
                call_time=call_end - call_start,
                gpu_time=gpu_elapsed,
                batch_size=adapter.infer_batch_size(args),
                model=model,
                inputs=args[0] if args else None,
                outputs=result,
                call_index=decision.call_index,
            )
            return result

        # Fast path: no optimizer, no profiler -> direct passthrough
        return original_fn(*args, **kwargs)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        invoke = object.__getattribute__(self, "_invoke")
        optimizer = object.__getattribute__(self, "_optimizer")
        if (
            object.__getattribute__(self, "_passthrough_when_no_optimizer")
            and optimizer is None
        ):
            return invoke(*args, **kwargs)
        return self._route(invoke, *args, **kwargs)

    def _resolve_intercept_target(self, name: str) -> Callable[..., Any]:
        """Return the callable target for a proxied method name."""
        intercepted = object.__getattribute__(self, "_intercepted_methods")
        original_fn = intercepted.get(name)
        if original_fn is not None:
            return cast(Callable[..., Any], original_fn)

        model = object.__getattribute__(self, "_model")
        candidate = getattr(model, name, None)
        if candidate is None or not callable(candidate):
            raise AttributeError(
                f"{type(model).__name__} object has no callable attribute {name!r}"
            )

        intercepted[name] = candidate
        return cast(Callable[..., Any], candidate)

    def _call_intercepted_method(
        self, name: str, *args: Any, **kwargs: Any
    ) -> Any:
        """Route a named model method through the common interception path."""
        return self._route(self._resolve_intercept_target(name), *args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        """Intercept framework-native methods BEFORE delegating to wrapped object.

        Resolution order:
        1. If ``name`` was pre-registered in *_intercepted_methods* by an
           adapter, return a cached wrapper routing through ``_route()``.
        2. If ``name`` is in *_ALWAYS_INTERCEPT* **and** the wrapped model
           owns a callable attribute with that name, auto-register it in
           *_intercepted_methods* and return the routing wrapper.  This
           ensures common serving entry-points (encode, generate, predict,
           transform, embed) are profiled without requiring adapters to
           declare them, while ``hasattr(proxy, name)`` still returns
           ``False`` when the model lacks the method.
        3. Otherwise delegate to the wrapped model (may raise
           ``AttributeError``).
        """
        intercepted = object.__getattribute__(self, "_intercepted_methods")
        if name in intercepted:
            if (
                object.__getattribute__(self, "_passthrough_when_no_optimizer")
                and object.__getattribute__(self, "_optimizer") is None
            ):
                return intercepted[name]
            # Cache the wrapper to avoid creating a new closure per access
            wrappers = object.__getattribute__(self, "_intercepted_wrappers")
            if name not in wrappers:
                original_fn = intercepted[name]

                def _intercepted_call(*args: Any, **kwargs: Any) -> Any:
                    return self._route(original_fn, *args, **kwargs)

                wrappers[name] = _intercepted_call
            return wrappers[name]

        # Auto-intercept common serving methods when present on the model
        if name in self._ALWAYS_INTERCEPT:
            model = object.__getattribute__(self, "_model")
            candidate = getattr(model, name, None)
            if candidate is not None and callable(candidate):
                intercepted[name] = candidate
                if (
                    object.__getattribute__(self, "_passthrough_when_no_optimizer")
                    and object.__getattribute__(self, "_optimizer") is None
                ):
                    return candidate
                wrappers = object.__getattribute__(self, "_intercepted_wrappers")

                def _auto_intercept(*args: Any, **kwargs: Any) -> Any:
                    return self._route(candidate, *args, **kwargs)

                wrappers[name] = _auto_intercept
                return _auto_intercept
            # Model does not have this method -- fall through to raise
            # AttributeError via the normal getattr delegation below.

        return getattr(object.__getattribute__(self, "_model"), name)

    def __setattr__(self, name: str, value: Any) -> None:
        """Delegate attribute writes to the wrapped model."""
        setattr(object.__getattribute__(self, "_model"), name, value)

    @property
    def unwrapped(self) -> Any:
        """Access the original model (e.g., for serialization, state_dict)."""
        return object.__getattribute__(self, "_model")

    @property
    def model_id(self) -> int:
        """The id() of the wrapped model, used for model registry lookups."""
        return cast(int, object.__getattribute__(self, "_model_id"))

    @property
    def call_count(self) -> int:
        """Number of inference calls routed through this proxy.

        Advisory: under concurrent serving, the count may be approximate
        due to non-atomic read-modify-write on the counter.
        """
        return cast(int, object.__getattribute__(self, "_call_count"))

    def metrics(self) -> Dict[str, Any]:
        """Return public per-model inference metrics for this proxy."""
        profiler = object.__getattribute__(self, "_profiler")
        if profiler is None:
            return {
                "model_id": self.model_id,
                "call_count": self.call_count,
                "profiled_calls": 0,
                "warmup_complete": False,
                "reported_speedup_x": 1.0,
                "measured_speedup_x": 1.0,
                "speedup_direction": "neutral",
                "baseline_call_time_ms": 0.0,
                "latest_call_time_ms": 0.0,
                "cache_tier": "none",
                "stability_score": 1.0,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
                "tokens_per_second": 0.0,
                "seconds_per_token": 0.0,
            }

        metrics = profiler.get_metrics(self.model_id)
        metrics["call_count"] = self.call_count
        metrics["warmup_complete"] = profiler.is_warmup_complete(self.model_id)
        return cast(Dict[str, Any], metrics)

    def __repr__(self) -> str:
        model = object.__getattribute__(self, "_model")
        return f"InferenceProxy({type(model).__name__}, calls={self.call_count})"
