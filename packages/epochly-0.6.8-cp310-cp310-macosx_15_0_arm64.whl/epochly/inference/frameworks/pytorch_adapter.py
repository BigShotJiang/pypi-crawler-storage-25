"""
PyTorchAdapter - PyTorch nn.Module inference interception.

Wraps torch.nn.Module for profiling and optimization via InferenceProxy.
The proxy is returned by wrap_forward() and used in place of the raw model
at the serving boundary. The model class is never mutated.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import functools
import hashlib
import logging
from typing import Any, List, Optional, Tuple

from .base_adapter import GoldenOutput, ModelInfo, ModelType
from .inference_proxy import InferenceProxy

logger = logging.getLogger(__name__)


# Architecture classification heuristics based on class names
_LLM_PATTERNS = {"GPT", "Llama", "Mistral", "Falcon", "OPT", "Bloom", "Phi"}
_VISION_PATTERNS = {"ViT", "ResNet", "ConvNet", "EfficientNet", "CLIP", "Swin"}
_DIFFUSION_PATTERNS = {"UNet", "Diffusion", "StableDiffusion", "DDPM"}
_EMBEDDING_PATTERNS = {"SentenceTransformer", "Embedding", "E5", "BGE"}
_ENCODER_PATTERNS = {"BERT", "RoBERTa", "DistilBERT", "ALBERT", "Electra", "DeBERTa"}


class PyTorchAdapter:
    """Adapter for PyTorch nn.Module models.

    Provides framework-specific implementations for detection, profiling,
    proxy creation, batching, GPU timing, and validation operations.
    """

    def __init__(self, torch_module: Any) -> None:
        self._torch = torch_module

    # -- Detection and classification --

    def detect(self, obj: Any) -> bool:
        """Returns True if obj is a torch.nn.Module."""
        nn = getattr(self._torch, "nn", None)
        if nn is None:
            return False
        return isinstance(obj, nn.Module)

    def get_model_classes(self) -> List[type]:
        """Return torch.nn.Module for isinstance detection."""
        nn = getattr(self._torch, "nn", None)
        if nn is None:
            return []
        return [nn.Module]

    def get_model_info(self, model: Any) -> ModelInfo:
        """Extract architecture, parameter count, dtype, device."""
        param_count = sum(p.numel() for p in model.parameters())
        # Get dtype from first parameter
        dtype = "unknown"
        device = "cpu"
        for p in model.parameters():
            dtype = str(p.dtype)
            device = str(p.device)
            break

        return ModelInfo(
            architecture=type(model).__name__,
            parameter_count=param_count,
            dtype=dtype,
            device=device,
            framework="pytorch",
            model_class=f"{type(model).__module__}.{type(model).__qualname__}",
        )

    def classify_model(self, model: Any) -> ModelType:
        """Classify model by architecture name heuristics."""
        name = type(model).__name__

        for pattern in _LLM_PATTERNS:
            if pattern.lower() in name.lower():
                return ModelType.LLM
        for pattern in _VISION_PATTERNS:
            if pattern.lower() in name.lower():
                return ModelType.VISION
        for pattern in _DIFFUSION_PATTERNS:
            if pattern.lower() in name.lower():
                return ModelType.DIFFUSION
        for pattern in _EMBEDDING_PATTERNS:
            if pattern.lower() in name.lower():
                return ModelType.EMBEDDING
        for pattern in _ENCODER_PATTERNS:
            if pattern.lower() in name.lower():
                return ModelType.ENCODER

        # Check output structure if possible
        return ModelType.UNKNOWN

    # -- Proxy and interception --

    def wrap_forward(self, model: Any, optimizer: Any = None,
                     profiler: Any = None,
                     passthrough_when_no_optimizer: bool = False) -> InferenceProxy:
        """Return a proxy that intercepts __call__ for this model instance.

        Called by epochly.wrap(). The proxy is used at the serving boundary:
            model = epochly.wrap(model)
            result = model(input_tensor)

        The original model is not mutated. Other instances of the same class
        are unaffected. Module.__call__ (hooks, forward) is preserved.
        """
        # invoke_fn: bind Module.__call__ to this instance
        # This preserves hooks + forward dispatch
        invoke_fn = functools.partial(model.__class__.__call__, model)

        # PyTorch: __call__ is the only inference entry point
        return InferenceProxy(
            model=model,
            invoke_fn=invoke_fn,
            adapter=self,
            optimizer=optimizer,
            profiler=profiler,
            passthrough_when_no_optimizer=passthrough_when_no_optimizer,
        )

    # -- Input introspection --

    def get_input_shape(self, inputs: Any) -> Tuple[int, ...]:
        """Extract input tensor shape."""
        if hasattr(inputs, "shape"):
            return tuple(inputs.shape)
        if isinstance(inputs, (list, tuple)) and len(inputs) > 0:
            first = inputs[0]
            if hasattr(first, "shape"):
                return tuple(first.shape)
        return (1,)

    def get_input_dtype(self, inputs: Any) -> str:
        """Extract input dtype string."""
        if hasattr(inputs, "dtype"):
            return str(inputs.dtype)
        if isinstance(inputs, (list, tuple)) and len(inputs) > 0:
            first = inputs[0]
            if hasattr(first, "dtype"):
                return str(first.dtype)
        return "unknown"

    def infer_batch_size(self, args: tuple) -> int:
        """Infer batch size from input arguments (first dim of first tensor).

        Handles tensor args, dict inputs, and list/tuple args.
        """
        if not args:
            return 1
        first_arg = args[0]
        if hasattr(first_arg, "shape") and len(first_arg.shape) > 0:
            return first_arg.shape[0]
        if isinstance(first_arg, dict):
            for v in first_arg.values():
                if hasattr(v, "shape") and len(v.shape) > 0:
                    return v.shape[0]
        if isinstance(first_arg, (list, tuple)):
            return len(first_arg)
        return 1

    # -- Inference execution --

    def run_inference(self, model: Any, inputs: Any) -> Any:
        """Run a single forward pass."""
        torch = self._torch
        with torch.no_grad():
            if isinstance(inputs, dict):
                return model(**inputs)
            return model(inputs)

    def run_generation(self, model: Any, inputs: Any) -> Any:
        """Run autoregressive generation if model supports it.

        Falls back to run_inference for non-generative models.
        """
        torch = self._torch
        if hasattr(model, "generate"):
            with torch.no_grad():
                if isinstance(inputs, dict):
                    return model.generate(**inputs)
                return model.generate(inputs)
        return self.run_inference(model, inputs)

    def forward_batch(self, model: Any, collated: Any) -> Any:
        """Run a batched forward pass."""
        torch = self._torch
        with torch.no_grad():
            return model(collated)

    def try_forward_with_batch(self, model: Any, batch_size: int) -> bool:
        """Attempt forward pass at given batch size. True if OOM-free.

        Uses model's first parameter shape to infer expected input dimensions.
        """
        torch = self._torch
        try:
            info = self.get_model_info(model)
            device = info.device

            # Infer input shape from model's first layer
            input_dim = 1
            for p in model.parameters():
                if len(p.shape) >= 2:
                    input_dim = p.shape[1]  # Second dim of first weight matrix
                    break

            dummy = torch.randn(batch_size, input_dim, device=device)
            with torch.no_grad():
                model(dummy)
            return True
        except RuntimeError:
            return False
        except Exception:
            return False

    # -- Batching --

    def collate_batch(self, inputs: List[Any]) -> Any:
        """Collate individual inputs into batched tensor via torch.stack."""
        torch = self._torch
        if not inputs:
            return inputs
        if hasattr(inputs[0], "shape"):
            return torch.stack(inputs)
        return inputs

    def split_batch(self, output: Any, batch_size: int) -> List[Any]:
        """Split batched output into individual results."""
        if hasattr(output, "shape") and len(output.shape) > 0:
            return [output[i] for i in range(min(batch_size, output.shape[0]))]
        return [output]

    # -- GPU timing and memory --

    def create_timing_event(self) -> Any:
        """Create a CUDA event pair for GPU timing."""
        torch = self._torch
        cuda = getattr(torch, "cuda", None)
        if cuda is None or not cuda.is_available():
            return None

        start_event = cuda.Event(enable_timing=True)
        end_event = cuda.Event(enable_timing=True)
        start_event.record()
        return (start_event, end_event)

    def resolve_timing_event(self, event: Any) -> float:
        """Resolve CUDA event pair to elapsed SECONDS.

        cuda.Event.elapsed_time() returns milliseconds; we divide by 1000.
        """
        if event is None:
            return 0.0

        start_event, end_event = event
        end_event.record()
        end_event.synchronize()
        # elapsed_time returns milliseconds, convert to seconds
        return start_event.elapsed_time(end_event) / 1000.0

    def get_gpu_utilization(self) -> float:
        """Current GPU compute utilization (0.0-1.0) via NVML."""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            pynvml.nvmlShutdown()
            return util.gpu / 100.0
        except Exception:
            return 0.0

    def get_gpu_memory_utilization(self) -> float:
        """Current GPU memory utilization (0.0-1.0) via NVML."""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            pynvml.nvmlShutdown()
            if mem_info.total == 0:
                return 0.0
            return mem_info.used / mem_info.total
        except Exception:
            return 0.0

    def estimate_model_memory(self, model: Any) -> int:
        """Estimate GPU memory consumed by model weights (bytes)."""
        total_bytes = 0
        for p in model.parameters():
            total_bytes += p.nelement() * p.element_size()
        for b in model.buffers():
            total_bytes += b.nelement() * b.element_size()
        return total_bytes

    def measure_per_sample_memory(self, model: Any) -> int:
        """Measure additional GPU memory per sample in a batch.

        Runs a single forward pass and measures the memory delta.
        """
        torch = self._torch
        cuda = getattr(torch, "cuda", None)
        if cuda is None or not cuda.is_available():
            return 0

        try:
            cuda.reset_peak_memory_stats()
            baseline = cuda.memory_allocated()
            dummy = torch.randn(1, 1, device="cuda")
            with torch.no_grad():
                model(dummy)
            peak = cuda.max_memory_allocated()
            return max(0, peak - baseline)
        except Exception:
            return 0

    # -- Pinned memory --

    def get_expected_input_shape(self, batch_size: int) -> Tuple[int, ...]:
        """Return expected input shape for a given batch size."""
        return (batch_size, 1)

    def pin_host_buffer(self, shape: Tuple[int, ...]) -> None:
        """Pre-allocate pinned host memory for CPU->GPU DMA transfer."""
        torch = self._torch
        try:
            torch.empty(shape, pin_memory=True)
        except Exception:
            pass

    # -- Golden capture and validation --

    def capture_golden(self, model: Any, n: int) -> List[GoldenOutput]:
        """Generate n reference outputs for validation using random inputs.

        Infers input dimensions from the model's first weight matrix.
        """
        torch = self._torch
        goldens = []
        info = self.get_model_info(model)
        device = info.device

        # Infer input shape from model parameters
        input_dim = 1
        for p in model.parameters():
            if len(p.shape) >= 2:
                input_dim = p.shape[1]
                break

        for _ in range(n):
            dummy_input = torch.randn(1, input_dim, device=device)
            try:
                with torch.no_grad():
                    output = model(dummy_input)
            except Exception:
                continue  # Skip if shape doesn't match
            goldens.append(
                GoldenOutput(
                    inputs=self.detach_to_cpu(dummy_input),
                    outputs=self.detach_to_cpu(output),
                    output_logits=self.extract_logits(output),
                    metadata={
                        "model_type": self.classify_model(model).value,
                        "dtype": info.dtype,
                    },
                )
            )
        return goldens

    def outputs_match(self, expected: Any, actual: Any, tolerance: float) -> bool:
        """Verify outputs within tolerance using torch.allclose."""
        torch = self._torch
        if hasattr(expected, "shape") and hasattr(actual, "shape"):
            return bool(torch.allclose(expected.float(), actual.float(),
                                       atol=tolerance, rtol=1e-3))
        return expected == actual

    def detach_to_cpu(self, tensor: Any) -> Any:
        """Detach tensor from GPU and move to CPU."""
        if hasattr(tensor, "detach"):
            return tensor.detach().cpu()
        return tensor

    def extract_logits(self, outputs: Any) -> Optional[Any]:
        """Extract logit tensor from model outputs."""
        # Handle HuggingFace-style outputs
        if hasattr(outputs, "logits"):
            return self.detach_to_cpu(outputs.logits)
        return None

    # -- Tensor conversion --

    def to_numpy(self, tensor: Any) -> Any:
        """Convert PyTorch tensor to numpy array."""
        if hasattr(tensor, "detach"):
            return tensor.detach().cpu().numpy()
        return tensor

    def to_token_ids(self, outputs: Any) -> List[int]:
        """Extract token IDs from generation outputs."""
        if hasattr(outputs, "sequences"):
            return outputs.sequences[0].tolist()
        if hasattr(outputs, "shape"):
            if outputs.dim() >= 2:
                return outputs[0].argmax(dim=-1).tolist()
            return outputs.tolist()
        return []

    def max_abs_error(self, expected: Any, actual: Any) -> float:
        """Compute maximum absolute error between two outputs."""
        torch = self._torch
        if hasattr(expected, "shape") and hasattr(actual, "shape"):
            return float(torch.max(torch.abs(expected.float() - actual.float())))
        return 0.0

    # -- Compilation (v1 beta) --

    def compile(self, model: Any, config: Any) -> Any:
        """Compile model using torch.compile."""
        torch = self._torch
        if not hasattr(torch, "compile"):
            return None
        backend = getattr(config, "backend", "inductor")
        mode = getattr(config, "mode", "reduce-overhead")
        return torch.compile(model, backend=backend, mode=mode)

    def hash_model(self, model: Any) -> str:
        """Compute hash of model state for compiler cache key."""
        h = hashlib.sha256()
        for name, param in model.named_parameters():
            h.update(name.encode())
            h.update(param.data.cpu().numpy().tobytes())
        return h.hexdigest()[:16]

    def get_input_shape_signature(self, model: Any) -> str:
        """Return shape signature string for compiler cache key."""
        info = self.get_model_info(model)
        return f"{info.architecture}_{info.dtype}_{info.parameter_count}"
