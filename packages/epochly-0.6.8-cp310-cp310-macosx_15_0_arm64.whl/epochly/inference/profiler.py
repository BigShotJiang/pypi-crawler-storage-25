"""
InferenceProfiler - Per-model inference profiling.

Measures model-call wall time, GPU timing, memory, utilization,
batch size, and workload classification during L0b profiling.

All internal timing is in SECONDS. Convert to milliseconds only
at the metrics/OTel export boundary.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import math
import random
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, Iterable, Optional

from .frameworks.base_adapter import InferenceAdapter, ModelType

logger = logging.getLogger(__name__)


@dataclass
class InferenceProfile:
    """Profile data for a single inference call."""

    model_id: int
    call_time: float  # Wall time of wrapped callable (seconds)
    gpu_time: float  # GPU kernel time (seconds)
    gpu_utilization: float  # 0.0-1.0
    gpu_memory_utilization: float  # 0.0-1.0
    batch_size: int
    model_type: ModelType
    cache_tier: str = "none"
    stability_score: float = 1.0
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    tokens_per_second: float = 0.0
    seconds_per_token: float = 0.0
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class CallProfileDecision:
    """Routing decision for a single inference call."""

    call_index: int
    should_profile: bool


@dataclass
class ModelProfileSummary:
    """Aggregated profiling data for a model over multiple calls."""

    model_id: int
    model_type: ModelType
    total_calls: int = 0
    total_call_time: float = 0.0  # seconds
    total_gpu_time: float = 0.0  # seconds
    min_call_time: float = float("inf")
    max_call_time: float = 0.0
    avg_call_time: float = 0.0  # seconds
    avg_gpu_time: float = 0.0  # seconds
    avg_batch_size: float = 0.0
    avg_gpu_utilization: float = 0.0
    avg_gpu_memory_utilization: float = 0.0
    optimal_batch_size: int = 1
    batch_sizes: Deque[int] = field(default_factory=lambda: deque(maxlen=1000))
    profiles: Deque[InferenceProfile] = field(default_factory=lambda: deque(maxlen=1000))

    @property
    def non_gpu_ratio(self) -> float:
        """Fraction of call time spent outside GPU compute."""
        if self.avg_call_time <= 0:
            return 0.0
        gpu_ratio = self.avg_gpu_time / max(self.avg_call_time, 1e-9)
        return 1.0 - gpu_ratio


class InferenceProfiler:
    """Per-model inference profiler.

    Profiles the first N calls (warmup_target) to establish baselines.
    Continues sampling periodically after warmup for drift detection.

    Thread-safe: all state protected by lock.
    """

    def __init__(self, warmup_target: int = 10, sample_rate: float = 0.01) -> None:
        self._warmup_target = warmup_target
        self._sample_rate = sample_rate  # After warmup, sample 1% of calls
        self._recent_profiles: Dict[int, Deque[InferenceProfile]] = {}
        self._summaries: Dict[int, ModelProfileSummary] = {}
        self._call_counts: Dict[int, int] = defaultdict(int)
        self._lock = threading.Lock()
        self._golden_callback: Optional[Any] = None

    def set_golden_callback(self, callback: Any) -> None:
        """Set callback for golden output capture during profiling."""
        with self._lock:
            self._golden_callback = callback

    def plan_call(self, model_id: int) -> CallProfileDecision:
        """Register a successful call and decide if it should be profiled.

        The decision is made before route-level timing work so unsampled
        steady-state calls can bypass timing-event creation, perf_counter,
        and summary bookkeeping.
        """
        with self._lock:
            self._call_counts[model_id] += 1
            count = self._call_counts[model_id]

        if count <= self._warmup_target:
            return CallProfileDecision(call_index=count, should_profile=True)

        return CallProfileDecision(
            call_index=count,
            should_profile=random.random() <= self._sample_rate,
        )

    def record_profile(
        self,
        model_id: int,
        adapter: InferenceAdapter,
        call_time: float,
        gpu_time: float,
        batch_size: int,
        model: Any,
        inputs: Any = None,
        outputs: Any = None,
        call_index: Optional[int] = None,
        cache_tier: str = "none",
        stability_score: Optional[float] = None,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
        total_tokens: Optional[int] = None,
        tokens_per_second: Optional[float] = None,
        seconds_per_token: Optional[float] = None,
    ) -> None:
        """Persist profiling data for a call already selected for sampling."""
        normalized_input_tokens = self._normalize_token_count(
            input_tokens,
            self._infer_input_tokens(inputs),
        )
        normalized_output_tokens = self._normalize_token_count(
            output_tokens,
            self._infer_output_tokens(adapter, outputs),
        )
        normalized_total_tokens = self._normalize_token_count(
            total_tokens,
            normalized_input_tokens + normalized_output_tokens,
        )
        normalized_tokens_per_second = self._normalize_rate(
            tokens_per_second,
            self._compute_tokens_per_second(normalized_total_tokens, call_time),
        )
        normalized_seconds_per_token = self._normalize_seconds_per_token(
            seconds_per_token,
            self._compute_seconds_per_token(normalized_total_tokens, call_time),
        )
        normalized_stability_score = self._normalize_stability_score(
            stability_score,
            self._estimate_stability_score(model_id, call_time),
        )

        profile = InferenceProfile(
            model_id=model_id,
            call_time=call_time,
            gpu_time=gpu_time,
            gpu_utilization=adapter.get_gpu_utilization(),
            gpu_memory_utilization=adapter.get_gpu_memory_utilization(),
            batch_size=batch_size,
            model_type=adapter.classify_model(model),
            cache_tier=cache_tier or "none",
            stability_score=normalized_stability_score,
            input_tokens=normalized_input_tokens,
            output_tokens=normalized_output_tokens,
            total_tokens=normalized_total_tokens,
            tokens_per_second=normalized_tokens_per_second,
            seconds_per_token=normalized_seconds_per_token,
        )

        with self._lock:
            count = call_index if call_index is not None else self._call_counts[model_id]

            if model_id not in self._recent_profiles:
                self._recent_profiles[model_id] = deque(maxlen=100)
            self._recent_profiles[model_id].append(profile)
            self._update_summary(model_id, profile)

            golden_callback = self._golden_callback

        # Golden output capture during warmup (exception-isolated)
        if (
            count <= self._warmup_target
            and golden_callback is not None
            and inputs is not None
            and outputs is not None
        ):
            try:
                golden_callback(model_id, adapter, model, inputs, outputs)
            except Exception as e:
                logger.warning(
                    "Golden capture failed for model %d: %s", model_id, e
                )

    def record_call(
        self,
        model_id: int,
        adapter: InferenceAdapter,
        call_time: float,
        gpu_time: float,
        batch_size: int,
        model: Any,
        inputs: Any = None,
        outputs: Any = None,
        cache_tier: str = "none",
        stability_score: Optional[float] = None,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
        total_tokens: Optional[int] = None,
        tokens_per_second: Optional[float] = None,
        seconds_per_token: Optional[float] = None,
    ) -> None:
        """Record a profiled inference call.

        Called by InferenceProxy._route() after timing measurements.
        """
        decision = self.plan_call(model_id)
        if not decision.should_profile:
            return

        self.record_profile(
            model_id=model_id,
            adapter=adapter,
            call_time=call_time,
            gpu_time=gpu_time,
            batch_size=batch_size,
            model=model,
            inputs=inputs,
            outputs=outputs,
            call_index=decision.call_index,
            cache_tier=cache_tier,
            stability_score=stability_score,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            tokens_per_second=tokens_per_second,
            seconds_per_token=seconds_per_token,
        )

    def _update_summary(self, model_id: int, profile: InferenceProfile) -> None:
        """Update rolling summary statistics."""
        if model_id not in self._summaries:
            self._summaries[model_id] = ModelProfileSummary(
                model_id=model_id,
                model_type=profile.model_type,
            )

        s = self._summaries[model_id]
        s.total_calls += 1
        s.total_call_time += profile.call_time
        s.total_gpu_time += profile.gpu_time
        s.min_call_time = min(s.min_call_time, profile.call_time)
        s.max_call_time = max(s.max_call_time, profile.call_time)
        s.avg_call_time = s.total_call_time / s.total_calls
        s.avg_gpu_time = s.total_gpu_time / s.total_calls
        s.batch_sizes.append(profile.batch_size)
        s.avg_batch_size = sum(s.batch_sizes) / len(s.batch_sizes)

        # Exponential moving average for utilization (fixed alpha for drift sensitivity)
        alpha = 0.05
        s.avg_gpu_utilization = (
            alpha * profile.gpu_utilization + (1 - alpha) * s.avg_gpu_utilization
        )
        s.avg_gpu_memory_utilization = (
            alpha * profile.gpu_memory_utilization
            + (1 - alpha) * s.avg_gpu_memory_utilization
        )
        s.profiles.append(profile)

    def get_summary(self, model_id: int) -> Optional[ModelProfileSummary]:
        """Get the profiling summary for a model."""
        with self._lock:
            return self._summaries.get(model_id)

    def is_warmup_complete(self, model_id: int) -> bool:
        """Check if warmup profiling is done for a model."""
        with self._lock:
            return self._call_counts.get(model_id, 0) >= self._warmup_target

    def get_call_count(self, model_id: int) -> int:
        """Get total call count for a model."""
        with self._lock:
            return self._call_counts.get(model_id, 0)

    def get_all_summaries(self) -> Dict[int, ModelProfileSummary]:
        """Get all model profiling summaries."""
        with self._lock:
            return dict(self._summaries)

    def get_metrics(self, model_id: int) -> Dict[str, Any]:
        """Build a user-facing metrics snapshot for a profiled model."""
        with self._lock:
            summary = self._summaries.get(model_id)
            call_count = self._call_counts.get(model_id, 0)
            if summary is None or not summary.profiles:
                return {
                    "model_id": model_id,
                    "call_count": call_count,
                    "profiled_calls": 0,
                    "warmup_complete": call_count >= self._warmup_target,
                    "reported_speedup_x": 1.0,
                    "measured_speedup_x": 1.0,
                    "speedup_direction": "neutral",
                    "baseline_call_time_ms": 0.0,
                    "latest_call_time_ms": 0.0,
                    "cache_tier": "none",
                    "stability_score": 1.0,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "tokens_per_second": 0.0,
                    "seconds_per_token": 0.0,
                }

            profiles = list(summary.profiles)

        latest = profiles[-1]
        baseline_call_time, latest_call_time = self._split_speedup_windows(profiles)
        measured_speedup = self._compute_speedup_ratio(
            baseline_call_time,
            latest_call_time,
        )
        reported_speedup = measured_speedup

        if measured_speedup > 1.0:
            speedup_direction = "faster"
        elif measured_speedup < 1.0:
            speedup_direction = "slower"
        else:
            speedup_direction = "neutral"

        return {
            "model_id": model_id,
            "model_type": latest.model_type.value,
            "call_count": self.get_call_count(model_id),
            "profiled_calls": len(profiles),
            "warmup_complete": self.is_warmup_complete(model_id),
            "avg_call_time_ms": summary.avg_call_time * 1000.0,
            "avg_gpu_time_ms": summary.avg_gpu_time * 1000.0,
            "avg_batch_size": summary.avg_batch_size,
            "avg_gpu_utilization": summary.avg_gpu_utilization,
            "avg_gpu_memory_utilization": summary.avg_gpu_memory_utilization,
            "cache_tier": latest.cache_tier,
            "stability_score": latest.stability_score,
            "input_tokens": latest.input_tokens,
            "output_tokens": latest.output_tokens,
            "total_tokens": latest.total_tokens,
            "tokens_per_second": latest.tokens_per_second,
            "seconds_per_token": latest.seconds_per_token,
            "baseline_call_time_ms": baseline_call_time * 1000.0,
            "latest_call_time_ms": latest_call_time * 1000.0,
            "measured_speedup_x": measured_speedup,
            "reported_speedup_x": reported_speedup,
            "speedup_direction": speedup_direction,
        }

    @staticmethod
    def _normalize_token_count(value: Optional[int], default: int) -> int:
        if value is None:
            return max(0, int(default))
        try:
            return max(0, int(value))
        except (TypeError, ValueError):
            return max(0, int(default))

    @staticmethod
    def _normalize_rate(value: Optional[float], default: float) -> float:
        candidate = default if value is None else value
        try:
            normalized = float(candidate)
        except (TypeError, ValueError):
            normalized = float(default)
        if not math.isfinite(normalized) or normalized < 0:
            return max(0.0, float(default))
        return normalized

    @staticmethod
    def _normalize_seconds_per_token(value: Optional[float], default: float) -> float:
        candidate = default if value is None else value
        try:
            normalized = float(candidate)
        except (TypeError, ValueError):
            normalized = float(default)
        if not math.isfinite(normalized) or normalized < 0:
            return max(0.0, float(default))
        return normalized

    @staticmethod
    def _normalize_stability_score(value: Optional[float], default: float) -> float:
        candidate = default if value is None else value
        try:
            normalized = float(candidate)
        except (TypeError, ValueError):
            normalized = float(default)
        if not math.isfinite(normalized):
            return max(0.0, min(1.0, float(default)))
        return max(0.0, min(1.0, normalized))

    @staticmethod
    def _compute_tokens_per_second(total_tokens: int, call_time: float) -> float:
        if total_tokens <= 0 or call_time <= 0:
            return 0.0
        return float(total_tokens) / call_time

    @staticmethod
    def _compute_seconds_per_token(total_tokens: int, call_time: float) -> float:
        if total_tokens <= 0 or call_time <= 0:
            return 0.0
        return call_time / float(total_tokens)

    @staticmethod
    def _compute_speedup_ratio(baseline_call_time: float, latest_call_time: float) -> float:
        if baseline_call_time <= 0 or latest_call_time <= 0:
            return 1.0
        ratio = baseline_call_time / latest_call_time
        if not math.isfinite(ratio) or ratio <= 0:
            return 1.0
        return ratio

    def _estimate_stability_score(self, model_id: int, call_time: float) -> float:
        history = self._recent_profiles.get(model_id)
        sample_times: list[float] = []
        if history:
            sample_times.extend(profile.call_time for profile in history)
        sample_times.append(call_time)

        if len(sample_times) < 2:
            return 1.0

        mean_time = sum(sample_times) / len(sample_times)
        if mean_time <= 0:
            return 0.0

        variance = sum((sample - mean_time) ** 2 for sample in sample_times) / len(sample_times)
        coefficient_of_variation = math.sqrt(variance) / mean_time
        return max(0.0, min(1.0, 1.0 - coefficient_of_variation))

    @staticmethod
    def _infer_input_tokens(inputs: Any) -> int:
        return InferenceProfiler._infer_token_count(inputs)

    @staticmethod
    def _infer_output_tokens(adapter: InferenceAdapter, outputs: Any) -> int:
        if outputs is None:
            return 0
        to_token_ids = getattr(adapter, "to_token_ids", None)
        if callable(to_token_ids):
            try:
                token_ids = to_token_ids(outputs)
                return InferenceProfiler._infer_token_count(token_ids)
            except Exception:
                pass
        return InferenceProfiler._infer_token_count(outputs)

    @staticmethod
    def _infer_token_count(value: Any) -> int:
        if value is None:
            return 0
        if isinstance(value, (bytes, bytearray)):
            return len(value)
        if isinstance(value, str):
            stripped = value.strip()
            return len(stripped.split()) if stripped else 0
        if isinstance(value, dict):
            if "input_ids" in value:
                return InferenceProfiler._infer_token_count(value["input_ids"])
            if "token_ids" in value:
                return InferenceProfiler._infer_token_count(value["token_ids"])
            for candidate in value.values():
                count = InferenceProfiler._infer_token_count(candidate)
                if count:
                    return count
            return 0
        if hasattr(value, "numel") and callable(value.numel):
            try:
                return max(0, int(value.numel()))
            except Exception:
                pass
        if hasattr(value, "shape"):
            shape = getattr(value, "shape", ())
            try:
                shape_sequence = tuple(shape)
                if len(shape_sequence) == 1:
                    return max(0, int(shape_sequence[0]))
                if len(shape_sequence) >= 2:
                    return max(0, int(shape_sequence[-1]))
            except Exception:
                pass
        if isinstance(value, (list, tuple, deque)):
            return len(value)
        try:
            return len(value)
        except Exception:
            return 0

    def _split_speedup_windows(
        self,
        profiles: Iterable[InferenceProfile],
    ) -> tuple[float, float]:
        snapshot = list(profiles)
        if not snapshot:
            return 0.0, 0.0
        if len(snapshot) == 1:
            return snapshot[0].call_time, snapshot[0].call_time

        pivot = max(1, len(snapshot) // 2)
        baseline_window = snapshot[:pivot]
        latest_window = snapshot[pivot:] or [snapshot[-1]]
        baseline_call_time = sum(p.call_time for p in baseline_window) / len(baseline_window)
        latest_call_time = sum(p.call_time for p in latest_window) / len(latest_window)
        return baseline_call_time, latest_call_time
