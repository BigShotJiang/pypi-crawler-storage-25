"""
EpochlyRayServeWrapper - Ray Serve deployment wrapper (v1 preview).

Provides per-deployment telemetry and request priority routing for
Ray Serve deployments. v1 preview: minimal, design-partner only.

Does NOT require Ray to be installed. When Ray is absent, the wrapper
provides telemetry-only mode (request timing, error tracking) without
the Ray Serve deployment features.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import functools
import logging
import threading
import time
from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Deque, Optional

logger = logging.getLogger(__name__)

# Guard Ray import
_ray_available = False
# VAL-DEPS-003: optional
try:
    import ray  # noqa: F401
    from ray import serve as _ray_serve  # noqa: F401

    _ray_available = True
except ImportError:
    logger.debug("Ray not available; Ray Serve wrapper operates in telemetry-only mode")


class RequestPriority(Enum):
    """Request priority levels for routing."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class RayServeConfig:
    """Configuration for the Ray Serve wrapper."""

    enable_telemetry: bool = True
    enable_priority_routing: bool = True
    max_latency_samples: int = 10_000


class _TelemetryCollector:
    """Thread-safe telemetry collector for per-deployment metrics.

    Tracks request count, latency distribution, error count,
    and priority routing statistics.
    """

    def __init__(self, max_samples: int = 10_000) -> None:
        self._request_count = 0
        self._error_count = 0
        self._total_latency_ms = 0.0
        self._latencies: Deque[float] = deque(maxlen=max_samples)
        self._priority_counts: dict = {p.value: 0 for p in RequestPriority}
        self._lock = threading.Lock()

    def record_request(
        self,
        latency_ms: float,
        priority: RequestPriority = RequestPriority.NORMAL,
        error: bool = False,
    ) -> None:
        """Record a completed request."""
        with self._lock:
            self._request_count += 1
            self._total_latency_ms += latency_ms
            self._latencies.append(latency_ms)
            self._priority_counts[priority.value] += 1
            if error:
                self._error_count += 1

    def get_stats(self) -> dict:
        """Return current telemetry snapshot."""
        with self._lock:
            avg = (
                self._total_latency_ms / self._request_count
                if self._request_count > 0
                else 0.0
            )
            return {
                "total_requests": self._request_count,
                "error_count": self._error_count,
                "avg_latency_ms": avg,
                "priority_distribution": dict(self._priority_counts),
            }


class EpochlyRayServeWrapper:
    """Ray Serve deployment wrapper with telemetry and priority routing.

    Wraps model inference functions to provide:
    1. Per-deployment request telemetry (latency, throughput, errors)
    2. Request priority routing (HIGH/NORMAL/LOW/CRITICAL)

    v1 preview: Minimal feature set for design-partner feedback.
    Full integration with Ray Serve deployment decorators planned for v2.

    Thread-safe.
    """

    def __init__(self, config: Optional[RayServeConfig] = None) -> None:
        self._config = config or RayServeConfig()
        self._telemetry = _TelemetryCollector(
            max_samples=self._config.max_latency_samples
        )

    def handle_request(
        self,
        model_fn: Callable,
        *args: Any,
        priority: RequestPriority = RequestPriority.NORMAL,
        **kwargs: Any,
    ) -> Any:
        """Execute a model inference request with telemetry.

        Wraps the model function call with timing, error tracking,
        and priority recording.

        Args:
            model_fn: The model inference function to call.
            *args: Positional arguments for the model function.
            priority: Request priority level.
            **kwargs: Keyword arguments for the model function.

        Returns:
            The model function's return value.

        Raises:
            Any exception raised by model_fn (re-raised after recording).
        """
        start = time.perf_counter()
        error_occurred = False

        try:
            result = model_fn(*args, **kwargs)
            return result
        except Exception:
            error_occurred = True
            raise
        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000
            if self._config.enable_telemetry:
                self._telemetry.record_request(
                    latency_ms=elapsed_ms,
                    priority=priority,
                    error=error_occurred,
                )

    def get_stats(self) -> dict:
        """Return deployment telemetry statistics."""
        return self._telemetry.get_stats()


def epochly_serve(
    func: Optional[Callable] = None,
    *,
    config: Optional[RayServeConfig] = None,
) -> Any:
    """Decorator for adding Epochly telemetry to inference functions.

    Can be used with or without arguments:

        @epochly_serve
        def predict(model, data):
            return model(data)

        @epochly_serve(config=RayServeConfig(enable_telemetry=True))
        def predict(model, data):
            return model(data)

    The decorated function gains telemetry tracking (latency, errors)
    transparently. The original function is accessible via .__wrapped__.

    Args:
        func: The function to decorate (when used without parentheses).
        config: Optional configuration for the wrapper.

    Returns:
        Decorated function with telemetry.
    """
    wrapper_instance = EpochlyRayServeWrapper(config=config)

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapped(*args: Any, **kwargs: Any) -> Any:
            return wrapper_instance.handle_request(fn, *args, **kwargs)

        wrapped.__wrapped__ = fn
        wrapped._epochly_wrapper = wrapper_instance
        return wrapped

    if func is not None:
        # Used without parentheses: @epochly_serve
        return decorator(func)

    # Used with parentheses: @epochly_serve(config=...)
    return decorator
