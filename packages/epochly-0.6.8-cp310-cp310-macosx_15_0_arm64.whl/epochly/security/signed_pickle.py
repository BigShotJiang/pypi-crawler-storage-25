"""
HMAC-signed pickle helpers for tamper-evident IPC payloads.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import pickle
import threading
from typing import Any, Final, Optional

_ENV_VAR: Final[str] = "EPOCHLY_SIGNED_PICKLE_KEY"
_HMAC_SIZE: Final[int] = hashlib.sha256().digest_size
_PICKLE_PROTOCOL: Final[int] = 4
_KEY_LOCK = threading.Lock()
_CACHED_KEY: Optional[bytes] = None


class IntegrityError(ValueError):
    """Raised when a signed pickle payload fails integrity verification."""


def _coerce_bytes(value: bytes | bytearray | memoryview, *, name: str) -> bytes:
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, memoryview):
        return value.tobytes()
    raise TypeError(f"{name} must be bytes-like")


def _sign(payload: bytes, key: bytes) -> bytes:
    return hmac.new(key, payload, hashlib.sha256).digest()


def _load_env_key() -> Optional[bytes]:
    raw_value = os.getenv(_ENV_VAR)
    if not raw_value:
        return None

    try:
        return bytes.fromhex(raw_value)
    except ValueError:
        return raw_value.encode("utf-8")


def get_or_create_key() -> bytes:
    """Return the process key from env or a lazily generated per-process value."""
    global _CACHED_KEY

    with _KEY_LOCK:
        if _CACHED_KEY is not None:
            return _CACHED_KEY

        _CACHED_KEY = _load_env_key() or os.urandom(32)
        return _CACHED_KEY


def dumps(obj: Any, key: bytes | bytearray | memoryview) -> bytes:
    """Serialize ``obj`` as ``hmac_tag || pickle_payload`` using protocol 4."""
    key_bytes = _coerce_bytes(key, name="key")
    payload = pickle.dumps(obj, protocol=_PICKLE_PROTOCOL)
    return _sign(payload, key_bytes) + payload


def loads(data: bytes | bytearray | memoryview, key: bytes | bytearray | memoryview) -> Any:
    """Verify a signed pickle payload before deserializing it."""
    key_bytes = _coerce_bytes(key, name="key")
    data_bytes = _coerce_bytes(data, name="data")

    if not data_bytes:
        raise IntegrityError("empty signed pickle payload")
    if len(data_bytes) <= _HMAC_SIZE:
        raise IntegrityError("short signed pickle payload")

    tag = data_bytes[:_HMAC_SIZE]
    payload = data_bytes[_HMAC_SIZE:]

    if not hmac.compare_digest(tag, _sign(payload, key_bytes)):
        raise IntegrityError("signed pickle integrity check failed")

    return pickle.loads(payload)


__all__ = ["IntegrityError", "dumps", "loads", "get_or_create_key"]
