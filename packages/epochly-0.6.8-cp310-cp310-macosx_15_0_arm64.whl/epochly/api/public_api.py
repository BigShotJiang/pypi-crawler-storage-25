"""
Epochly Public API

Main public interface for the Epochly framework.
"""

import functools
import inspect
from typing import Any, Callable, Dict, Optional, TypeVar, Union, cast

from ..core.epochly_core import (
    EpochlyCore,
    EnhancementLevel,
    get_epochly_core,
    _is_globally_disabled,
    _is_jit_trusted,
)
# v0.4.30: direct bool access for fast-path disable gate
from ..core import epochly_core as _core_module
from .decorators import optimize  # noqa: F401  # re-exported for public API consistency
from ..utils.logger import get_logger
from ..utils.exceptions import EpochlyError, EpochlyConfigurationError

logger = get_logger(__name__)

F = TypeVar('F', bound=Callable[..., Any])


# Use the singleton from epochly_core instead of creating our own
def _get_epochly_instance() -> EpochlyCore:
    """Get the global Epochly instance from epochly_core."""
    return get_epochly_core()


def epochly_run(
    func: Optional[F] = None,
    *,
    level: Union[EnhancementLevel, int, str] = EnhancementLevel.LEVEL_0_MONITOR,
    config: Optional[Dict[str, Any]] = None,
    auto_optimize: bool = True,
    monitor_performance: bool = True
) -> Union[F, Callable[[F], F]]:
    """
    Main Epochly decorator for optimizing functions.

    Args:
        func: Function to optimize (when used without parentheses)
        level: Enhancement level to apply
        config: Additional configuration options
        auto_optimize: Whether to automatically optimize based on performance
        monitor_performance: Whether to monitor performance metrics

    Returns:
        Decorated function or decorator

    Example:
        @epochly_run
        def my_function():
            pass

        @epochly_run(level=EnhancementLevel.JIT)
        def optimized_function():
            pass
    """
    def decorator(f: F) -> F:
        # Convert level to EnhancementLevel if needed
        if isinstance(level, (int, str)):
            try:
                enhancement_level = EnhancementLevel(level)
            except ValueError:
                raise EpochlyConfigurationError(f"Invalid enhancement level: {level}")
        else:
            enhancement_level = level

        # EP-81 FIX: Fast-path cache for optimized function.
        # After the first call resolves the optimization, subsequent calls
        # bypass all dispatch overhead (~9-13µs) and call the optimized
        # function directly via closure variable (~50ns overhead).
        #
        # Level 0 (MONITOR): optimized fn is always f itself — cache at decoration time.
        # Level 1 (THREADING): cached after first call through optimize_function.
        # Level 2 (JIT): cached after trust verification of compiled impl.
        # Level 3+ (FULL): cached after transformation resolution.
        _fast_fn = f if enhancement_level == EnhancementLevel.LEVEL_0_MONITOR else None
        # v0.4.30: Track which level _fast_fn was resolved at
        _cached_level: Optional[EnhancementLevel] = None

        # EP-81 R2 FIX: Cache core reference at decoration time for cheap
        # disable gate in hot path (~10ns attribute read, no function call).
        try:
            _core_ref = _get_epochly_instance()
        except Exception:
            _core_ref = None

        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            nonlocal _fast_fn, _cached_level, enhancement_level, _core_ref
            # Thread safety: CPython's GIL makes nonlocal assignment atomic
            # for _fast_fn, _cached_level, _core_ref. Concurrent first calls
            # may redundantly compute, but last-writer-wins is acceptable.

            # ═══════════════════════════════════════════════════════════
            # v0.4.30 FAST PATH: parity with api/decorators.py
            # ═══════════════════════════════════════════════════════════
            # Check disable gates AND level-change gate inside the fast
            # path, not just before it. This ensures:
            # 1. epochly.disable() / core.enabled=False bypasses cached fn
            # 2. Level promotion invalidates the cached resolution
            # 3. Same behavior as @epochly.optimize decorator surface
            cached = _fast_fn
            if cached is not None:
                # v0.4.30: Direct module-level bool read (~10ns) — same
                # pattern as api/decorators.py v0.4.29 fast path.
                if _core_module._globally_disabled:
                    return f(*args, **kwargs)
                # Disable gate: check core.enabled directly (~10ns attr read)
                _cr = _core_ref
                if _cr is not None and not _cr.enabled:
                    try:
                        refreshed_core = _get_epochly_instance()
                    except Exception:
                        refreshed_core = None
                    if refreshed_core is not None and refreshed_core is not _cr:
                        _core_ref = refreshed_core
                        _cr = refreshed_core
                    if _cr is not None and not _cr.enabled:
                        return f(*args, **kwargs)
                # Level-change gate: invalidate cache if system level changed
                if (
                    _cr is not None
                    and _cached_level is not None
                    and _cached_level != _cr._current_level
                ):
                    _fast_fn = None
                    _cached_level = None
                else:
                    return cached(*args, **kwargs)

            # ═══════════════════════════════════════════════════════════
            # SLOW PATH: First call, level change, or core not available
            # ═══════════════════════════════════════════════════════════
            _cr = _core_ref
            if _cr is None or not _cr.enabled:
                try:
                    _cr = _get_epochly_instance()
                    _core_ref = _cr
                except Exception:
                    return f(*args, **kwargs)
            if _is_globally_disabled():
                return f(*args, **kwargs)
            if not _cr.enabled:
                return f(*args, **kwargs)

            try:
                # PR #42 FIX: Guard ALL fast paths against disabled state
                # disable() sets _globally_disabled=True. This check MUST come before
                # Level 2/3 fast paths, which otherwise bypass core.enabled entirely.
                # Uses a module-level flag (not core.enabled) to avoid initializing core
                # just to check enabled state, and to support pre-init disable().
                if _is_globally_disabled():
                    return f(*args, **kwargs)

                # CRITICAL FIX: Fast path for Level 2 JIT (bypass optimizer after compilation)
                # After first successful JIT compilation, jump directly to compiled function
                # This eliminates ~130ms per-call overhead and enables 90× JIT speedup
                if enhancement_level == EnhancementLevel.LEVEL_2_JIT:
                    jit_impl = getattr(f, '_epochly_jit_impl', None)
                    if jit_impl is not None:
                        # EP-90 (round 2): Verify provenance via closure-private
                        # WeakSet registry — only trust impls registered by
                        # Epochly's JIT compiler. The old sentinel approach was
                        # broken because sentinels are publicly importable.
                        if _is_jit_trusted(jit_impl):
                            # EP-81: Cache verified impl for fast path
                            _fast_fn = jit_impl
                            _cached_level = (
                                _cr._current_level
                                if _cr is not None
                                else None
                            )
                            return jit_impl(*args, **kwargs)
                        # Not in registry — spoofed or corrupted
                        logger.warning(
                            "Ignoring untrusted _epochly_jit_impl on %s "
                            "(not in provenance registry)", f.__name__
                        )

                # EP-98: Direct GPU executor for explicit LEVEL_4_GPU
                # When user explicitly passes level=LEVEL_4_GPU, invoke GPU executor directly
                # without the multi-call profiling phase. This respects explicit user intent.
                # Uses the core's factory-initialized _level4_gpu_executor (which already handles
                # NVRTC discovery, GPUDetector init, and CuPy setup via _initialize_level4_gpu_system).
                #
                # Architecture note (Feb 2026 consilium):
                # - Direct path (here): for explicit @epochly_run(level=LEVEL_4_GPU) — first-call GPU
                # - Auto_profiler path (line ~4465): for progressive set_level() — multi-call warmup
                # - FORCE_GPU respects explicit intent; AUTO is for the profiler path
                # - Canary verification on first call guards against silent incorrect results
                # - Thread-safe lazy init via core._lock
                if enhancement_level == EnhancementLevel.LEVEL_4_GPU:
                    try:
                        core = _get_epochly_instance()
                        # Thread-safe lazy init: use the core's init lock to prevent
                        # TOCTOU race where thread B sees non-None but uninitialized executor.
                        if not hasattr(core, '_level4_gpu_executor') or core._level4_gpu_executor is None:
                            if hasattr(core, '_lock'):
                                with core._lock:
                                    # Double-check after acquiring lock
                                    if not hasattr(core, '_level4_gpu_executor') or core._level4_gpu_executor is None:
                                        core._initialize_level4_gpu_system()
                            else:
                                core._initialize_level4_gpu_system()
                        gpu_executor = core._level4_gpu_executor
                        # Verify executor is fully initialized AND enabled (not just non-None).
                        # Between construction and initialize() completion, _enabled is False.
                        if gpu_executor is not None and getattr(gpu_executor, '_enabled', False):
                            if getattr(core.current_level, 'value', 0) < EnhancementLevel.LEVEL_4_GPU.value:
                                core.current_level = EnhancementLevel.LEVEL_4_GPU
                            from ..plugins.executor.gpu_executor import GPUExecutionRequest, GPUExecutionMode
                            gpu_request = GPUExecutionRequest(
                                func=f,
                                args=args,
                                kwargs=kwargs,
                                # Explicit LEVEL_4 requests must route through FORCE_GPU.
                                # Benchmark and proof workloads use request-time GPU intent
                                # as the admission signal; falling back to PREFER_GPU makes
                                # the direct decorator path depend on heuristic offload
                                # classification instead of the caller's explicit level.
                                gpu_mode=GPUExecutionMode.FORCE_GPU
                            )
                            gpu_result = gpu_executor.execute_function(gpu_request)
                            # Check if GPU was actually used — silent CPU fallback violates
                            # explicit LEVEL_4_GPU intent (consilium finding)
                            if not getattr(gpu_result, 'executed_on_gpu', True):
                                core.current_level = EnhancementLevel.LEVEL_3_FULL
                                logger.warning(
                                    f"{f.__name__}: LEVEL_4_GPU requested but GPU execution "
                                    f"fell back to CPU (cpu_fallback={getattr(gpu_result, 'cpu_fallback_used', '?')})"
                                )
                                enhancement_level = EnhancementLevel.LEVEL_3_FULL
                            else:
                                result = gpu_result.result

                                # First-call canary: verify GPU result against CPU ground truth.
                                # Catches silent correctness bugs before they propagate.
                                # Cache decision per function — first call pays ~2x, rest are free.
                                # (EP-98 consilium: mandatory correctness verification)
                                _canary_key = id(f)
                                if not hasattr(f, '_epochly_gpu_canary_passed'):
                                    import numpy as np
                                    try:
                                        cpu_result = f(*args, **kwargs)
                                        # Compare with IEEE 754 tolerance
                                        if isinstance(result, np.ndarray) and isinstance(cpu_result, np.ndarray):
                                            if not np.allclose(result, cpu_result, rtol=1e-5, atol=1e-8, equal_nan=True):
                                                max_diff = float(np.max(np.abs(result - cpu_result)))
                                                logger.warning(
                                                    f"{f.__name__}: GPU canary FAILED — results diverge "
                                                    f"(max_diff={max_diff:.2e}). Disabling GPU for this function."
                                                )
                                                f._epochly_gpu_canary_passed = False
                                                core.current_level = EnhancementLevel.LEVEL_3_FULL
                                                # Return CPU result (known-correct) and fall through on next calls
                                                enhancement_level = EnhancementLevel.LEVEL_3_FULL
                                                return cpu_result
                                        f._epochly_gpu_canary_passed = True
                                    except Exception as canary_err:
                                        logger.debug(f"{f.__name__}: GPU canary check failed ({canary_err}), trusting GPU result")
                                        f._epochly_gpu_canary_passed = True
                                elif not f._epochly_gpu_canary_passed:
                                    # Previous canary failed — skip GPU, use Level 3
                                    logger.debug(f"{f.__name__}: GPU canary previously failed, routing to Level 3")
                                    enhancement_level = EnhancementLevel.LEVEL_3_FULL
                                    # Fall through to standard optimization path
                                else:
                                    pass  # Canary passed, return GPU result

                                if getattr(f, '_epochly_gpu_canary_passed', True):
                                    return result
                        else:
                            core.current_level = EnhancementLevel.LEVEL_3_FULL
                            logger.warning(
                                f"{f.__name__}: LEVEL_4_GPU requested but GPU executor "
                                f"not available (executor={gpu_executor is not None}, "
                                f"enabled={getattr(gpu_executor, '_enabled', False)}). "
                                f"Falling back to JIT."
                            )
                    except Exception as e:
                        # GPU compilation/execution failed — fall back to JIT via core
                        # WARNING level because user explicitly requested GPU (consilium finding)
                        core.current_level = EnhancementLevel.LEVEL_3_FULL
                        logger.warning(
                            f"{f.__name__}: Explicit LEVEL_4_GPU execution failed ({e}), "
                            f"falling back to CPU optimization."
                        )
                    # GPU unavailable or failed — fall through to Level 3 JIT.
                    # We explicitly downgrade to LEVEL_3_FULL so the standard path uses
                    # Numba CPU JIT (7-100x) instead of re-attempting GPU via _optimize_gpu
                    # (which would fail again and fall back to raw Python 1x).
                    # See Dec 2025 design doc: Numba JIT > CuPy wrapper fallback.
                    enhancement_level = EnhancementLevel.LEVEL_3_FULL

                # Get Epochly instance at execution time, not decoration time
                epochly = _get_epochly_instance()

                # Check if system is closed and reinitialize if needed
                if getattr(epochly, '_closed', False):
                    # Epochly was shutdown, reinitialize it
                    epochly._closed = False
                    epochly.initialize()

                # LEVEL 3 only: Try loop transformation for parallelizable loops
                # CRITICAL: LEVEL_4_GPU must NOT enter this branch — GPU routing happens
                # after this block. Using `== LEVEL_3_FULL` instead of `>= LEVEL_3_FULL`
                # so that LEVEL_4_GPU (value=4) is not caught here.
                # EP-98 fix: LEVEL_4_GPU was silently falling through to Numba JIT
                # because 4 >= 3 is True. GPU path is handled below.
                if enhancement_level == EnhancementLevel.LEVEL_3_FULL:
                    # ==========================================================================
                    # FAST PATTERN PRE-SCREENING (Architecture Requirement: Zero Overhead)
                    # ==========================================================================
                    # Per epochly-architecture-spec.md: "Unsuitable workloads must NOT be penalized"
                    # This section ensures patterns like inline arithmetic run at baseline speed.
                    # ==========================================================================
                    func_id = id(f)

                    # Check if already marked as non-transformable (fastest path)
                    if hasattr(epochly, '_non_transformable_functions') and func_id in epochly._non_transformable_functions:
                        # Known unsuitable pattern - cache and execute directly with ZERO overhead
                        _fast_fn = f  # EP-81: cache for subsequent calls
                        _cached_level = epochly._current_level
                        return f(*args, **kwargs)

                    # Initialize non-transformable cache if needed
                    if not hasattr(epochly, '_non_transformable_functions'):
                        epochly._non_transformable_functions = set()

                    # FAST HEURISTIC 1: Check function signature for known problematic patterns
                    # Functions with no parameters can't be chunked - reject immediately
                    try:
                        sig = inspect.signature(f)
                        if len(sig.parameters) == 0:
                            epochly._non_transformable_functions.add(func_id)
                            _fast_fn = f  # EP-81: cache for subsequent calls
                            _cached_level = epochly._current_level
                            return f(*args, **kwargs)
                    except Exception:
                        pass  # Can't get signature, proceed with analysis

                    # FAST HEURISTIC 2: Pattern Suitability Analysis (<1ms)
                    # Detect patterns where parallelization overhead exceeds benefit:
                    # - Inline arithmetic (r += i ** 2)
                    # - Light nested loops
                    # - Trivial operations
                    try:
                        from ..profiling.pattern_suitability_analyzer import is_pattern_suitable_for_parallelization

                        is_suitable, reason = is_pattern_suitable_for_parallelization(f)

                        if not is_suitable:
                            # Pattern not suitable - mark and execute directly with ZERO overhead
                            epochly._non_transformable_functions.add(func_id)
                            _fast_fn = f  # EP-81: cache for subsequent calls
                            _cached_level = epochly._current_level
                            logger.debug(f"{f.__name__} pattern unsuitable: {reason}")
                            return f(*args, **kwargs)

                    except ImportError:
                        # Analyzer not available - fall back to standard analysis
                        logger.debug("Pattern suitability analyzer not available")
                    except Exception as e:
                        # Analysis failed - proceed with standard path (conservative)
                        logger.debug(f"Pattern analysis exception: {e}")

                    # ==========================================================================
                    # STANDARD TRANSFORMATION PATH (only for suitable patterns)
                    # ==========================================================================
                    try:
                        from ..profiling.runtime_loop_transformer import RuntimeLoopTransformer

                        # Get or create cached transformer (reuse across calls to maintain batch_dispatcher)
                        if not hasattr(epochly, '_loop_transformer'):
                            # CRITICAL: min_iterations threshold filters tiny workloads where overhead > speedup
                            # Per MCP-Reflect RCA (2025-11-19): Tasks <1000 iterations often have overhead > compute
                            # Production default: 1000 (only substantial loops benefit from parallelization)
                            # For testing/development: Set to 50 via environment variable
                            import os
                            min_iters = int(
                                os.environ.get(
                                    'EPOCHLY_MIN_ITERATIONS', '1000',
                                )
                            )
                            epochly._loop_transformer = RuntimeLoopTransformer(executor=None, min_iterations=min_iters)

                        transformer = epochly._loop_transformer

                        # Check if we've already transformed this function
                        if func_id in transformer._transformed_functions:
                            cached = transformer._transformed_functions[func_id]

                            # If cached value is original function, it's non-transformable
                            if cached is f:
                                # Mark as non-transformable for faster path next time
                                epochly._non_transformable_functions.add(func_id)
                                _fast_fn = f  # EP-81: cache for subsequent calls
                                _cached_level = epochly._current_level
                                return f(*args, **kwargs)
                            else:
                                # Successfully transformed - use it
                                return cached(*args, **kwargs)

                        # First call for a suitable pattern - perform detailed analysis
                        analysis = transformer.analyze_function(f)

                        # If not suitable after detailed analysis, mark and execute directly
                        if not analysis or not analysis.get('should_transform', False):
                            epochly._non_transformable_functions.add(func_id)
                            _fast_fn = f  # EP-81: cache for subsequent calls
                            _cached_level = epochly._current_level
                            logger.debug(f"{f.__name__} not suitable for transformation, executing with zero overhead")
                            return f(*args, **kwargs)

                        # Attempt transformation
                        transformed = transformer.transform_function(f)

                        if transformed:
                            _fast_fn = transformed  # EP-81: cache for subsequent calls
                            _cached_level = epochly._current_level
                            logger.debug(f"Transformed {f.__name__} for loop parallelization")
                            return transformed(*args, **kwargs)
                        else:
                            # Transformation failed - mark as non-transformable
                            epochly._non_transformable_functions.add(func_id)
                            _fast_fn = f  # EP-81: cache for subsequent calls
                            _cached_level = epochly._current_level
                            logger.debug(f"Transformation failed for {f.__name__}, executing directly")
                            return f(*args, **kwargs)

                    except RuntimeError as e:
                        # LOUD-FAILURE FIX (Mar 2026): The
                        # transformed wrapper raised a RuntimeError
                        # because ProcessPool workers may still
                        # be running dispatched iterations.
                        # Do NOT fall back to f(*args, **kwargs)
                        # because that would replay the same
                        # work.  Propagate to the user as a loud
                        # failure per the architecture invariant.
                        if "unsafe batch replay" in str(e):
                            raise
                        # Non-unsafe RuntimeErrors: fall through
                        # to the normal fallback path.
                        logger.debug(
                            "Loop transformation exception for "
                            "%s: %s, executing directly",
                            f.__name__, e,
                        )
                        epochly._non_transformable_functions.add(
                            func_id,
                        )
                        _fast_fn = f
                        _cached_level = epochly._current_level
                        return f(*args, **kwargs)
                    except Exception as e:
                        logger.debug(
                            "Loop transformation exception for "
                            "%s: %s, executing directly",
                            f.__name__, e,
                        )
                        # Mark as non-transformable and execute
                        # directly.
                        epochly._non_transformable_functions.add(
                            func_id,
                        )
                        _fast_fn = f
                        _cached_level = epochly._current_level
                        return f(*args, **kwargs)

                # Standard Epochly optimization path
                # v0.4.22: Pass _user_level so optimize_function knows if the user
                # explicitly requested a level via @epochly_run(level=3) vs auto-detect.
                # level param default is LEVEL_0_MONITOR; if user changed it, it's explicit.
                _orig_level = (
                    level
                    if level != EnhancementLevel.LEVEL_0_MONITOR
                    else None
                )
                result = epochly.optimize_function(
                    f,
                    args,
                    kwargs,
                    level=enhancement_level,
                    _user_level=_orig_level,
                    config=config or {},
                    auto_optimize=auto_optimize,
                    monitor_performance=monitor_performance
                )

                # EP-81: Cache the resolved optimization for fast
                # path on subsequent calls.
                # Level 2 JIT uses trust-verified _epochly_jit_impl (handled above).
                # v0.4.30: Also track _cached_level for level-change invalidation.
                if _fast_fn is None and enhancement_level != EnhancementLevel.LEVEL_2_JIT:
                    _resolved = getattr(f, '_epochly_resolved_fn', None)
                    if _resolved is not None:
                        _fast_fn = _resolved
                        _cached_level = epochly._current_level

                return result
            except Exception as e:
                # UNSAFE-REPLAY GUARD (Mar 2026): The inner
                # Level 3 handler re-raises RuntimeError for
                # unsafe batch replay, but this outer catch-all
                # would swallow it and replay work via
                # f(*args, **kwargs).  Propagate it instead.
                if (
                    isinstance(e, RuntimeError)
                    and "unsafe batch replay" in str(e)
                ):
                    raise
                logger.error(f"Epochly optimization failed for {f.__name__}: {e}")
                # EP-81: Cache original function to avoid repeating failures
                _fast_fn = f
                _cached_level = _cr._current_level if _cr is not None else None
                return f(*args, **kwargs)

        # Preserve function metadata and add Epochly-specific attributes
        wrapper._epochly_enhanced = True  # type: ignore[attr-defined]
        wrapper._epochly_level = enhancement_level  # type: ignore[attr-defined]
        wrapper._epochly_original = f  # type: ignore[attr-defined]

        # Initialize JIT fast path attribute (will be set after first successful compilation)
        f._epochly_jit_impl = None  # type: ignore[attr-defined]

        # Preserve original function signature for introspection
        wrapper.__signature__ = inspect.signature(f)  # type: ignore[attr-defined]

        return cast(F, wrapper)

    if func is None:
        # Called with parentheses: @epochly_run(...)
        return decorator
    else:
        # Called without parentheses: @epochly_run
        return decorator(func)


def configure(
    enhancement_level: Union[EnhancementLevel, int, str, None] = None,
    force: bool = False,
    **kwargs
) -> None:
    """
    Configure global Epochly settings.

    Args:
        enhancement_level: Default enhancement level (0-4)
        force: If True, bypass progression validation (for CLI/explicit level setting)
        **kwargs: Configuration options matching CONFIG_SCHEMA keys:
            level (int): Alias for enhancement_level (convenience)
            mode (str): Execution mode (off/monitor/conservative/balanced/aggressive)
            max_workers (int): Maximum worker threads (1-256)
            telemetry (bool): Enable telemetry collection
            jit_enabled (bool): Enable JIT compilation
            cache_size (int): Cache size in MB (0-10240)
            log_level (str): Logging level (DEBUG/INFO/WARNING/ERROR/CRITICAL)
            auto_optimize (bool): Enable automatic optimization
            memory_limit (int): Memory limit in MB (100-102400)
            profile_enabled (bool): Enable profiling
            gpu_enabled (bool): Enable GPU acceleration

    Raises:
        EpochlyConfigurationError: If configuration fails
    """
    try:
        epochly = _get_epochly_instance()

        # Support 'level' as an alias for enhancement_level
        if 'level' in kwargs:
            if enhancement_level is None:
                enhancement_level = kwargs.pop('level')
            else:
                import warnings
                warnings.warn(
                    "Both 'enhancement_level' and 'level' provided to configure(); "
                    "'enhancement_level' takes precedence and 'level' is ignored.",
                    stacklevel=2,
                )
                kwargs.pop('level')  # enhancement_level takes precedence

        # Default to LEVEL_0_MONITOR if nothing specified
        if enhancement_level is None:
            enhancement_level = EnhancementLevel.LEVEL_0_MONITOR

        # Convert level if needed
        if isinstance(enhancement_level, (int, str)):
            enhancement_level = EnhancementLevel(enhancement_level)

        epochly.configure(enhancement_level=enhancement_level, force=force, **kwargs)
        logger.info(f"Epochly configured with level {enhancement_level}")

    except EpochlyConfigurationError:
        # Let config errors propagate directly with their original message
        raise
    except Exception as e:
        logger.error(f"Failed to configure Epochly: {e}")
        raise EpochlyConfigurationError(f"Configuration failed: {e}")


def get_status() -> Dict[str, Any]:
    """
    Get current Epochly status and statistics.

    Returns:
        Dictionary containing status information
    """
    try:
        epochly = _get_epochly_instance()
        return epochly.get_status()
    except Exception as e:
        logger.error(f"Failed to get Epochly status: {e}")
        return {
            "error": str(e),
            "active": False,
            "enhancement_level": "unknown"
        }


def enable_monitoring(enable: bool = True) -> None:
    """
    Enable or disable performance monitoring.

    Args:
        enable: Whether to enable monitoring
    """
    try:
        epochly = _get_epochly_instance()
        epochly.enable_monitoring(enable)
        logger.info(f"Epochly monitoring {'enabled' if enable else 'disabled'}")
    except Exception as e:
        logger.error(f"Failed to toggle monitoring: {e}")
        raise EpochlyError(f"Monitoring toggle failed: {e}")


def get_metrics() -> Dict[str, Any]:
    """
    Get performance metrics.

    Returns:
        Dictionary containing performance metrics
    """
    try:
        epochly = _get_epochly_instance()
        return epochly.get_metrics()
    except Exception as e:
        logger.error(f"Failed to get metrics: {e}")
        return {"error": str(e)}


def reset_metrics() -> None:
    """Reset all performance metrics."""
    try:
        epochly = _get_epochly_instance()
        epochly.reset_metrics()
        logger.info("Epochly metrics reset")
    except Exception as e:
        logger.error(f"Failed to reset metrics: {e}")
        raise EpochlyError(f"Metrics reset failed: {e}")


def is_function_enhanced(func: Callable) -> bool:
    """
    Check if a function is Epochly-enhanced.

    Args:
        func: Function to check

    Returns:
        True if function is Epochly-enhanced
    """
    return hasattr(func, '_epochly_enhanced') and func._epochly_enhanced


def get_function_level(func: Callable) -> Optional[EnhancementLevel]:
    """
    Get the enhancement level of a function.

    Args:
        func: Function to check

    Returns:
        Enhancement level or None if not enhanced
    """
    if is_function_enhanced(func):
        return getattr(func, '_epochly_level', None)
    return None


def get_original_function(func: Callable) -> Callable:
    """
    Get the original unenhanced function.

    Args:
        func: Enhanced function

    Returns:
        Original function or the same function if not enhanced
    """
    if is_function_enhanced(func):
        return getattr(func, '_epochly_original', func)
    return func


def shutdown() -> None:
    """Shutdown Epochly and cleanup resources."""
    try:
        epochly_instance = get_epochly_core()
        epochly_instance.shutdown()
        logger.info("Epochly shutdown complete")
    except Exception as e:
        logger.error(f"Error during Epochly shutdown: {e}")
        raise EpochlyError(f"Shutdown failed: {e}")


# Convenience alias
run = epochly_run      # Shorter alias
