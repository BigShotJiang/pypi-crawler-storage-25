"""
Epochly - Transparent Performance Optimization

A transparent performance optimization framework for Python applications
through progressive enhancement levels.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
Licensed under the Epochly Software License Agreement (ESLA).
See LICENSE file for the complete license terms.
Terms of Service: https://epochly.com/legal/terms
Privacy Policy: https://epochly.com/legal/privacy
"""

from pathlib import Path as _Path


def _read_repo_version() -> str:
    """Best-effort version fallback for editable/dev installs."""
    pyproject_path = _Path(__file__).resolve().parents[2] / "pyproject.toml"
    try:
        for line in pyproject_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("version ="):
                return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return "unknown"


def _resolve_package_version(version_getter=None) -> str:
    """Resolve the installed package version without a stale hardcoded fallback."""
    if version_getter is None:
        from importlib.metadata import version as version_getter
    try:
        return version_getter("epochly")
    except Exception:
        return _read_repo_version()


__version__ = _resolve_package_version()
from .build_info import __version_build_time__
from .config import resolver as _config_resolver

# v0.4.18: Suppress ALL NumbaWarnings when epochly is loaded.
# Prior versions used module=r'^epochly\.' (scikit-learn pattern) but that only
# suppresses warnings originating FROM epochly modules. Epochly triggers Numba JIT
# compilation of USER functions — Numba emits warnings at the user's call site
# (e.g., poly.strategies.arb_yes_no), not from epochly's modules. The module-scoped
# v0.4.29 FIX (#126): Suppress NumbaWarning by message pattern, NOT by importing
# the class. The old `from numba.core.errors import NumbaWarning` triggered the
# entire numba import chain (151 modules, 105 MB) at `import epochly` time.
# This made every process that imports epochly pay 105 MB even if JIT is never used.
# String-based filter achieves the same suppression with zero import cost.
# Import-time opt-out env var: EPOCHLY_SHOW_NUMBA_WARNINGS
if not _config_resolver.env_truthy(_config_resolver.ENV_SHOW_NUMBA_WARNINGS):
    import warnings as _w
    # String-pattern filter catches most warnings without importing numba
    _w.filterwarnings('ignore', message='.*numba.*', module='numba.*')
    _w.filterwarnings('ignore', message='.*Numba.*')
    # Catch ALL warning subclasses from numba modules (NumbaWarning inherits
    # Warning, not UserWarning — so we must use Warning as the base category)
    _w.filterwarnings('ignore', category=Warning, module='numba.*')
__author__ = "Epochly Incorporated"
__email__ = "dev@epochly.com"

# Core imports needed for lazy initialization
import sys
import dis as _dis
import builtins as _builtins
import inspect
import threading as _threading
import time as _time
import logging  # CRITICAL FIX: For preflight thread logging
from typing import Any, Callable, Optional
# Initialize module logger for preflight and other module-level operations
logger = logging.getLogger(__name__)

# ============================================================================
# Lazy Initialization System (Task 1: Performance Improvements)
# ============================================================================
# Epochly core is NOT initialized on import. Instead, initialization is
# deferred until first actual use via _ensure_core_initialized().
#
# This eliminates import-time side effects and makes simple tooling
# (linters, type checkers, etc.) pay zero startup penalty.
#
# Key components:
# - _core_singleton: The singleton core instance (None until initialized)
# - _auto_enabled: Whether auto-enable has been triggered
# - _init_lock: Threading lock for thread-safe initialization
# - _ensure_core_initialized(): Main initialization function
# - _should_auto_enable(): Check if auto-enable should trigger
# ============================================================================

# Global state for lazy initialization
_core_singleton = None
_auto_enabled = False
_init_lock = _threading.Lock()
_explicitly_enabled = False
_initialized = False
_shutdown = False
_import_hook_installed = False
_enabled = False
_current_level = None
_enable_requires_force_reinit = False

# Q-M-002: Structured error diagnostics for lazy init failures
# Stores details about the last initialization error for debugging
_last_init_error = None
_lightweight_decorator_status = None
_lightweight_status_recorded_at = None
_deferred_lightweight_status_args = None
_lightweight_compact_helper_reason_cache = {}
_LIGHTWEIGHT_COMPACT_HELPER_REASON_CACHE_MAX = 512
_LIGHTWEIGHT_CACHE_MISS = object()
_LIGHTWEIGHT_DECORATOR_COLD_START_THRESHOLD_MS = 25.0

# Pre-resolve platform name to avoid importing the heavy ``platform`` module
# on the first-call hot path.  ``import platform`` costs ~8 ms on Python 3.9,
# which exceeds the zero-overhead budget for unsuitable workloads.
_PLATFORM_SYSTEM = {'darwin': 'Darwin', 'linux': 'Linux', 'win32': 'Windows'}.get(
    sys.platform, sys.platform,
)


def _set_lifecycle_state(
    *,
    initialized=None,
    shutdown=None,
    import_hook_installed=None,
    enabled=None,
    current_level=None,
):
    """Update module-level lifecycle state used by re-init tests and shutdown hygiene."""
    global _initialized, _shutdown, _import_hook_installed, _enabled, _current_level

    if initialized is not None:
        _initialized = initialized
    if shutdown is not None:
        _shutdown = shutdown
    if import_hook_installed is not None:
        _import_hook_installed = import_hook_installed
    if enabled is not None:
        _enabled = enabled
    if current_level is not None or current_level is None:
        _current_level = current_level


def _remove_import_hooks():
    """Shutdown and remove any installed Epochly import hooks."""
    global _import_hook_installed

    try:
        from .core.import_hook import EpochlyImportHook
    except Exception:
        _import_hook_installed = False
        return

    for hook in sys.meta_path[:]:
        if isinstance(hook, EpochlyImportHook):
            try:
                hook.shutdown()
            except Exception:
                pass
            try:
                sys.meta_path.remove(hook)
            except ValueError:
                pass

    _import_hook_installed = False


def _reset_runtime_lifecycle_state():
    """Clear public lifecycle flags so a later enable() behaves like cold start."""
    global _auto_enabled, _explicitly_enabled, _global_epochly_core
    global _lightweight_decorator_status, _lightweight_status_recorded_at
    global _deferred_lightweight_status_args, _core_singleton
    global _enable_requires_force_reinit

    _core_singleton = None
    _auto_enabled = False
    _explicitly_enabled = False
    _enable_requires_force_reinit = False
    _global_epochly_core = None
    _lightweight_decorator_status = None
    _lightweight_status_recorded_at = None
    _deferred_lightweight_status_args = None
    _set_lifecycle_state(
        initialized=False,
        shutdown=False,
        import_hook_installed=False,
        enabled=False,
        current_level=None,
    )

    if hasattr(sys, '_epochly_initialized'):
        try:
            delattr(sys, '_epochly_initialized')
        except Exception:
            pass

    # Editable installs and pytest path manipulation can load, unload, and
    # reload both ``epochly.bootstrap`` and ``src.epochly.bootstrap`` in one
    # process. Reset every visible alias plus any stale module object still held
    # by test/module globals so shutdown has one observable lifecycle truth.
    _bootstrap_modules = []
    for _bootstrap_module_name in ('epochly.bootstrap', 'src.epochly.bootstrap'):
        _bootstrap_module = sys.modules.get(_bootstrap_module_name)
        if _bootstrap_module is not None:
            _bootstrap_modules.append(_bootstrap_module)

    try:
        import gc
        import types

        for _obj in gc.get_objects():
            if (
                isinstance(_obj, types.ModuleType)
                and getattr(_obj, '__name__', None)
                in ('epochly.bootstrap', 'src.epochly.bootstrap')
            ):
                _bootstrap_modules.append(_obj)
    except Exception:
        pass

    for _bootstrap_module in _bootstrap_modules:
        try:
            setattr(_bootstrap_module, '_bootstrap_complete', False)
        except Exception:
            pass


def _collect_core_shutdown_candidates() -> list[Any]:
    """Return live core objects that may need canonical shutdown state."""
    candidates = []
    seen_ids = set()

    def _add(candidate: Any) -> None:
        if candidate is None:
            return
        candidate_id = id(candidate)
        if candidate_id in seen_ids:
            return
        seen_ids.add(candidate_id)
        candidates.append(candidate)

    _add(_core_singleton)
    _add(globals().get('_global_epochly_core'))

    for _module_name in (
        'epochly.core.epochly_core',
        'src.epochly.core.epochly_core',
    ):
        _module = sys.modules.get(_module_name)
        if _module is None:
            continue
        _add(getattr(_module, '_epochly_core', None))
        _core_cls = getattr(_module, 'EpochlyCore', None)
        if _core_cls is not None:
            _add(getattr(_core_cls, '_instance', None))

    return candidates


def _canonicalize_core_shutdown_state(core_candidates: list[Any]) -> None:
    """Force captured core objects back to the canonical Level 0 enum member."""
    try:
        from .core.epochly_core import EnhancementLevel as _CanonicalEnhancementLevel
    except Exception:
        return

    for _core_candidate in core_candidates:
        try:
            _core_candidate.enabled = False
        except Exception:
            pass
        try:
            _core_candidate._initialized = False
        except Exception:
            pass
        try:
            _core_candidate.current_level = _CanonicalEnhancementLevel.LEVEL_0_MONITOR
        except Exception:
            try:
                _core_candidate._current_level = _CanonicalEnhancementLevel.LEVEL_0_MONITOR
            except Exception:
                pass


def _purge_duplicate_core_module_aliases(*, clear_disable_env: bool) -> None:
    """Remove duplicate ``src.epochly.core`` aliases that split enum identity."""
    canonical_core_module = sys.modules.get('epochly.core.epochly_core')

    for _module_name in tuple(sys.modules):
        if (
            _module_name != 'src.epochly.core'
            and not _module_name.startswith('src.epochly.core.')
        ):
            continue

        _module = sys.modules.get(_module_name)
        if (
            _module_name == 'src.epochly.core.epochly_core'
            and _module is not None
            and _module is not canonical_core_module
        ):
            _reset_alias_singleton = getattr(_module, '_reset_singleton', None)
            if callable(_reset_alias_singleton):
                try:
                    _reset_alias_singleton(clear_disable_env=clear_disable_env)
                except TypeError:
                    try:
                        _reset_alias_singleton()
                    except Exception:
                        pass
                except Exception:
                    pass

        try:
            del sys.modules[_module_name]
        except KeyError:
            pass
        except Exception:
            pass


def _teardown_runtime(*, clear_disable_env: bool = True) -> None:
    """Shutdown core + hooks and clear lifecycle state for re-initialization."""
    _core_shutdown_candidates = _collect_core_shutdown_candidates()
    _set_lifecycle_state(shutdown=True)
    _remove_import_hooks()

    try:
        from .core.epochly_core import _reset_singleton
        _reset_singleton(clear_disable_env=clear_disable_env)
    except Exception:
        pass

    _purge_duplicate_core_module_aliases(clear_disable_env=clear_disable_env)
    _canonicalize_core_shutdown_state(_core_shutdown_candidates)
    _reset_runtime_lifecycle_state()


_LIGHTWEIGHT_CALL_OPCODES = frozenset({
    'CALL',
    'CALL_FUNCTION_EX',
    'CALL_FUNCTION',
    'CALL_KW',
})
_LIGHTWEIGHT_ATTRIBUTE_OPCODES = frozenset({
    'LOAD_ATTR',
    'LOAD_METHOD',
})
_LIGHTWEIGHT_CONTAINER_BUILD_OPCODES = frozenset({
    'BUILD_LIST',
    'BUILD_MAP',
    'BUILD_SET',
    'BUILD_TUPLE',
    'BUILD_CONST_KEY_MAP',
})
_LIGHTWEIGHT_ARITHMETIC_OPCODES = frozenset({
    'BINARY_ADD',
    'BINARY_SUBTRACT',
    'BINARY_MULTIPLY',
    'BINARY_MATRIX_MULTIPLY',
    'BINARY_TRUE_DIVIDE',
    'BINARY_FLOOR_DIVIDE',
    'BINARY_MODULO',
    'BINARY_POWER',
    'INPLACE_ADD',
    'INPLACE_SUBTRACT',
    'INPLACE_MULTIPLY',
    'INPLACE_MATRIX_MULTIPLY',
    'INPLACE_TRUE_DIVIDE',
    'INPLACE_FLOOR_DIVIDE',
    'INPLACE_MODULO',
    'INPLACE_POWER',
    'UNARY_NEGATIVE',
    'UNARY_POSITIVE',
})
_LIGHTWEIGHT_ARITHMETIC_ARGREPRS = frozenset({
    '+',
    '-',
    '*',
    '@',
    '/',
    '//',
    '%',
    '**',
    '+=',
    '-=',
    '*=',
    '@=',
    '/=',
    '//=',
    '%=',
    '**=',
})
_LIGHTWEIGHT_NUMERIC_TOP_LEVEL_PACKAGES = frozenset({
    'cmath',
    'cupy',
    'jax',
    'math',
    'numexpr',
    'numpy',
    'scipy',
})
_LIGHTWEIGHT_DIRECT_LOOP_OPCODES = frozenset({
    'FOR_ITER',
    'JUMP_BACKWARD',
    'JUMP_BACKWARD_NO_INTERRUPT',
    'POP_JUMP_BACKWARD_IF_FALSE',
    'POP_JUMP_BACKWARD_IF_NONE',
    'POP_JUMP_BACKWARD_IF_NOT_NONE',
    'POP_JUMP_BACKWARD_IF_TRUE',
})
_LIGHTWEIGHT_LEGACY_BACKWARD_LOOP_OPCODES = frozenset({
    'JUMP_ABSOLUTE',
    'POP_JUMP_IF_TRUE',
})
_LIGHTWEIGHT_VARIABLE_LOAD_OPCODES = frozenset({
    'LOAD_GLOBAL',
    'LOAD_NAME',
    'LOAD_DEREF',
})
_LIGHTWEIGHT_BUILTIN_REFERENCE_NAMES = frozenset(dir(_builtins)) | {
    'True',
    'False',
    'None',
}
_LIGHTWEIGHT_LEVEL_NAME_TO_VALUE = {
    'LEVEL_0_MONITOR': 0,
    'LEVEL_1_THREADING': 1,
    'LEVEL_2_JIT': 2,
    'LEVEL_3_FULL': 3,
    'LEVEL_4_GPU': 4,
}
_LIGHTWEIGHT_LEVEL_VALUE_TO_NAME = {
    value: name for name, value in _LIGHTWEIGHT_LEVEL_NAME_TO_VALUE.items()
}


def _get_lightweight_max_level_cap():
    """Return the configured max-level cap, or None when unset/invalid."""
    raw_cap = _config_resolver.env_get(_config_resolver.ENV_MAX_LEVEL)
    if raw_cap is None or str(raw_cap).strip() == '':
        return None
    try:
        cap = int(str(raw_cap).strip())
    except (TypeError, ValueError):
        return None
    return max(0, min(4, cap))


def _apply_lightweight_max_level_cap(level_name):
    """Apply EPOCHLY_MAX_LEVEL to a public level name when possible."""
    value = _LIGHTWEIGHT_LEVEL_NAME_TO_VALUE.get(str(level_name))
    if value is None:
        return level_name
    cap = _get_lightweight_max_level_cap()
    if cap is None or value <= cap:
        return level_name
    return _LIGHTWEIGHT_LEVEL_VALUE_TO_NAME.get(cap, 'LEVEL_0_MONITOR')


def _get_lightweight_configured_level_name():
    """Best-effort configured level for lightweight no-benefit decorator status."""
    raw_level = _config_resolver.env_get(_config_resolver.ENV_LEVEL)
    if not raw_level:
        return _apply_lightweight_max_level_cap('LEVEL_1_THREADING')

    level_value = raw_level.strip().upper()
    level_aliases = {
        'AUTO': 'LEVEL_1_THREADING',
        'AUTOMATIC': 'LEVEL_1_THREADING',
        'PROGRESSIVE': 'LEVEL_1_THREADING',
        'MONITOR': 'LEVEL_0_MONITOR',
        'THREADING': 'LEVEL_1_THREADING',
        'JIT': 'LEVEL_2_JIT',
        'FULL': 'LEVEL_3_FULL',
        'GPU': 'LEVEL_4_GPU',
        'LEVEL_4_GPU_ACCELERATION': 'LEVEL_4_GPU',
    }
    if level_value in level_aliases:
        return _apply_lightweight_max_level_cap(level_aliases[level_value])
    if level_value.startswith('LEVEL_'):
        return _apply_lightweight_max_level_cap(level_value)

    level_map = {
        '0': 'LEVEL_0_MONITOR',
        '1': 'LEVEL_1_THREADING',
        '2': 'LEVEL_2_JIT',
        '3': 'LEVEL_3_FULL',
        '4': 'LEVEL_4_GPU',
    }
    return _apply_lightweight_max_level_cap(
        level_map.get(level_value, 'LEVEL_1_THREADING')
    )


def _record_lightweight_decorator_status(func_name, skip_reason):
    """Store a synthetic no-benefit status without forcing full core init."""
    _record_lightweight_decorator_status_with_request(
        func_name,
        skip_reason,
        requested_level=None,
        first_call_ms=None,
    )


def _normalize_lightweight_requested_level_name(requested_level: object) -> str:
    """Return the public requested-level label for lightweight status."""
    if requested_level is None:
        return 'automatic progressive'
    if hasattr(requested_level, 'name'):
        return str(getattr(requested_level, 'name'))
    if isinstance(requested_level, int):
        return {
            0: 'LEVEL_0_MONITOR',
            1: 'LEVEL_1_THREADING',
            2: 'LEVEL_2_JIT',
            3: 'LEVEL_3_FULL',
            4: 'LEVEL_4_GPU',
        }.get(requested_level, str(requested_level))
    return str(requested_level)


def _with_requested_level_backcompat(detail: object) -> object:
    """Preserve both requested-level keys during the migration window."""
    if not isinstance(detail, dict):
        return detail

    normalized = dict(detail)
    requested_level = normalized.get('requested_level')
    if requested_level is None:
        requested_level = normalized.get('requested_level_name')
    if requested_level is None:
        return normalized

    normalized.setdefault('requested_level', requested_level)
    normalized.setdefault('requested_level_name', requested_level)
    return normalized


def _supports_lightweight_no_benefit_request(requested_level: object) -> bool:
    """Return whether lightweight no-benefit rejection supports this request.

    Automatic-progressive decorators and explicit ``level=2`` decorators are
    eligible. An explicit ``level=3`` (or higher) means the caller wants full
    ProcessPool / GPU acceleration -- cheap rejection would silently defeat
    that intent.
    """
    requested_level_name = _normalize_lightweight_requested_level_name(
        requested_level,
    )
    return requested_level_name in {
        'automatic progressive',
        'LEVEL_2_JIT',
    }


def _should_allow_level3_deferral(requested_level: object) -> bool:
    """Return whether a lightweight reject may still defer to Level 3."""
    requested_level_name = _normalize_lightweight_requested_level_name(
        requested_level,
    )
    return requested_level_name == 'automatic progressive'


def _should_apply_lightweight_jit_precheck(requested_level: object) -> bool:
    """Return whether lightweight decoration may reject using JIT suitability."""
    requested_level_name = _normalize_lightweight_requested_level_name(
        requested_level,
    )
    return requested_level_name == 'LEVEL_2_JIT'


def _get_lightweight_jit_skip_reason(
    func: Callable[..., Any],
) -> Optional[str]:
    """Return a cheap Level-2 skip reason without initializing the core."""
    try:
        from .core.epochly_core import EpochlyCore

        if not EpochlyCore._is_jit_friendly(func):
            return (
                "Not JIT-friendly: no numeric/math/numpy patterns in bytecode"
            )
    except Exception:
        return None

    try:
        from .plugins.analyzer.jit_analyzer import JITAnalyzer, JITSuitability

        characteristics = JITAnalyzer().analyze_function(func)
        if characteristics.jit_suitability not in (
            JITSuitability.EXCELLENT,
            JITSuitability.GOOD,
        ):
            return (
                "Not suitable for JIT: "
                f"{characteristics.jit_suitability.value}"
            )
    except Exception:
        return None

    return None


def _lightweight_instruction_jump_target(instruction):
    """Return the numeric jump target for legacy absolute-jump opcodes."""
    for attr in ('argval', 'arg'):
        target = getattr(instruction, attr, None)
        if isinstance(target, int):
            return target
    return None


def _is_lightweight_loop_instruction(instruction):
    """Return whether *instruction* represents a supported loop back-edge."""
    opname = getattr(instruction, 'opname', '')
    if opname in _LIGHTWEIGHT_DIRECT_LOOP_OPCODES:
        return True
    if opname in _LIGHTWEIGHT_LEGACY_BACKWARD_LOOP_OPCODES:
        offset = getattr(instruction, 'offset', None)
        if not isinstance(offset, int):
            return False
        target = _lightweight_instruction_jump_target(instruction)
        return isinstance(target, int) and target <= offset
    return False


def _resolve_lightweight_bound_name(func, name):
    """Resolve a referenced name from closure cells first, then globals."""
    code = getattr(func, '__code__', None)
    freevars = getattr(code, 'co_freevars', ())
    closure = getattr(func, '__closure__', None)
    if freevars and closure:
        for freevar_name, cell in zip(freevars, closure):
            if freevar_name != name:
                continue
            try:
                return cell.cell_contents
            except ValueError:
                return None

    fn_globals = getattr(func, '__globals__', None)
    if isinstance(fn_globals, dict) and name in fn_globals:
        return fn_globals.get(name)

    return None


def _get_lightweight_reference_cache_key(func):
    """Return a conservative cache key for lightweight admission analysis."""
    code = getattr(func, '__code__', None)
    if code is None:
        return None

    referenced_names = set(getattr(code, 'co_names', ()))
    referenced_names.update(getattr(code, 'co_freevars', ()))
    references = []
    for name in sorted(referenced_names):
        if name in _LIGHTWEIGHT_BUILTIN_REFERENCE_NAMES:
            continue
        obj = _resolve_lightweight_bound_name(func, name)
        if obj is None:
            continue
        helper = getattr(obj, '__func__', obj)
        references.append((
            name,
            id(obj),
            getattr(helper, '__code__', None),
            getattr(obj, '__module__', None),
            getattr(obj, '__name__', None),
        ))

    return (code, tuple(references))


def _cache_lightweight_compact_helper_reason(cache_key, reason):
    if cache_key is None:
        return
    if (
        len(_lightweight_compact_helper_reason_cache)
        >= _LIGHTWEIGHT_COMPACT_HELPER_REASON_CACHE_MAX
    ):
        _lightweight_compact_helper_reason_cache.clear()
    _lightweight_compact_helper_reason_cache[cache_key] = reason


def _iter_lightweight_direct_helpers(func):
    """Yield direct helper callables referenced by *func*."""
    code = getattr(func, '__code__', None)
    if code is None:
        return

    referenced_names = set()
    for instruction in _dis.get_instructions(code):
        if instruction.opname in _LIGHTWEIGHT_VARIABLE_LOAD_OPCODES:
            argval = getattr(instruction, 'argval', None)
            if isinstance(argval, str):
                referenced_names.add(argval)

    for name in referenced_names:
        if name in _LIGHTWEIGHT_BUILTIN_REFERENCE_NAMES:
            continue
        obj = _resolve_lightweight_bound_name(func, name)
        if obj is None or inspect.ismodule(obj):
            continue
        helper = getattr(obj, '__func__', obj)
        if getattr(helper, '__code__', None) is None or helper is func:
            continue
        yield helper


def _summarize_lightweight_local_shape(func):
    """Collect bytecode counts for *func* only."""
    summary = {
        'arithmetic_ops': 0,
        'attribute_ops': 0,
        'call_ops': 0,
        'container_build_ops': 0,
        'loop_ops': 0,
        'subscript_ops': 0,
    }
    code = getattr(func, '__code__', None)
    if code is None:
        return summary

    for instruction in _dis.get_instructions(code):
        if instruction.opname in _LIGHTWEIGHT_ATTRIBUTE_OPCODES:
            summary['attribute_ops'] += 1
        elif instruction.opname in _LIGHTWEIGHT_CALL_OPCODES:
            summary['call_ops'] += 1
        elif instruction.opname in _LIGHTWEIGHT_CONTAINER_BUILD_OPCODES:
            summary['container_build_ops'] += 1
        elif _is_lightweight_loop_instruction(instruction):
            summary['loop_ops'] += 1
        elif instruction.opname == 'BINARY_SUBSCR':
            summary['subscript_ops'] += 1
        elif (
            instruction.opname == 'BINARY_OP'
            and instruction.argrepr == '[]'
        ):
            summary['subscript_ops'] += 1
        elif instruction.opname == 'STORE_SUBSCR':
            summary['subscript_ops'] += 1

        if instruction.opname in _LIGHTWEIGHT_ARITHMETIC_OPCODES or (
            instruction.opname == 'BINARY_OP'
            and instruction.argrepr in _LIGHTWEIGHT_ARITHMETIC_ARGREPRS
        ):
            summary['arithmetic_ops'] += 1

    return summary


def _has_lightweight_numeric_module_signal(func):
    """Return whether *func* references a real numeric module."""
    code = getattr(func, '__code__', None)
    if code is None:
        return False

    referenced_names = set(code.co_names) | set(getattr(code, 'co_freevars', ()))
    for name in referenced_names:
        obj = _resolve_lightweight_bound_name(func, name)
        module_name = getattr(obj, '__name__', None)
        if not inspect.ismodule(obj) or not isinstance(module_name, str):
            continue
        if module_name.split('.')[0] in _LIGHTWEIGHT_NUMERIC_TOP_LEVEL_PACKAGES:
            return True
    return False


def _has_lightweight_numeric_callable_signal(func):
    """Return whether *func* references a numeric callable directly."""
    code = getattr(func, '__code__', None)
    if code is None:
        return False

    referenced_names = set(code.co_names) | set(getattr(code, 'co_freevars', ()))
    for name in referenced_names:
        if name in _LIGHTWEIGHT_BUILTIN_REFERENCE_NAMES:
            continue
        obj = _resolve_lightweight_bound_name(func, name)
        if obj is None or inspect.ismodule(obj) or not callable(obj):
            continue
        module_name = getattr(obj, '__module__', None)
        if not isinstance(module_name, str):
            continue
        if module_name.split('.')[0] in _LIGHTWEIGHT_NUMERIC_TOP_LEVEL_PACKAGES:
            return True
    return False


def _helper_has_lightweight_numeric_signal(helper, *, _depth=0):
    """Return whether a direct helper contains real numeric computation."""
    helper_shape = _summarize_lightweight_local_shape(helper)
    if (
        _has_lightweight_numeric_module_signal(helper)
        or _has_lightweight_numeric_callable_signal(helper)
    ):
        return True

    if helper_shape['loop_ops'] <= 0:
        return False

    arithmetic_ops = helper_shape['arithmetic_ops']
    if arithmetic_ops >= 3:
        return True

    if (
        helper_shape['subscript_ops'] >= 8
        and arithmetic_ops >= 1
    ):
        return True

    if _depth >= 1:
        return False

    for nested_helper in _iter_lightweight_direct_helpers(helper):
        if nested_helper is helper:
            continue
        if _helper_has_lightweight_numeric_signal(
            nested_helper,
            _depth=_depth + 1,
        ):
            return True

    return False


def _helper_has_lightweight_imported_numeric_signal(helper, *, _seen=None):
    """Return whether helper chain references numeric modules/callables."""
    if _seen is None:
        _seen = set()

    helper_id = id(helper)
    if helper_id in _seen:
        return False
    _seen.add(helper_id)

    if (
        _has_lightweight_numeric_module_signal(helper)
        or _has_lightweight_numeric_callable_signal(helper)
    ):
        return True

    for nested_helper in _iter_lightweight_direct_helpers(helper):
        if _helper_has_lightweight_imported_numeric_signal(
            nested_helper,
            _seen=_seen,
        ):
            return True

    return False


def _summarize_lightweight_shape_recursive(func, *, _seen=None):
    """Collect lightweight bytecode counts for *func* and direct helpers."""
    if _seen is None:
        _seen = set()

    func_id = id(func)
    if func_id in _seen:
        return {
            'arithmetic_ops': 0,
            'attribute_ops': 0,
            'call_ops': 0,
            'container_build_ops': 0,
            'helper_calls': 0,
            'loop_ops': 0,
            'subscript_ops': 0,
        }

    _seen.add(func_id)
    summary = _summarize_lightweight_local_shape(func)
    summary['helper_calls'] = 0

    for helper in _iter_lightweight_direct_helpers(func):
        if id(helper) in _seen:
            continue
        summary['helper_calls'] += 1
        helper_summary = _summarize_lightweight_shape_recursive(
            helper,
            _seen=_seen,
        )
        for key, value in helper_summary.items():
            summary[key] = summary.get(key, 0) + value

    return summary


def _get_lightweight_container_orchestration_reason(shape):
    """Return a no-benefit reason for obvious Python orchestration shapes."""
    attribute_heavy_shape = (
        (shape.get('attribute_ops', 0) >= 16 and shape.get('loop_ops', 0) >= 4)
        or (shape.get('attribute_ops', 0) >= 15 and shape.get('loop_ops', 0) >= 5)
    )
    if attribute_heavy_shape:
        return "Attribute-heavy policy/object traversal detected"

    scalar_routing_shape = (
        shape.get('loop_ops', 0) >= 4
        or shape.get('helper_calls', 0) >= 1
    )
    if (
        shape.get('subscript_ops', 0) >= 8
        and shape.get('loop_ops', 0) >= 1
        and scalar_routing_shape
    ):
        return "Subscript-heavy collection-loop workload detected"

    if (
        shape.get('container_build_ops', 0) >= 2
        and shape.get('call_ops', 0) >= 6
        and shape.get('loop_ops', 0) >= 2
    ):
        return "Container-building collection-loop workload detected"

    return None


def _get_compact_helper_wrapper_reason(func):
    """Return a cheap lightweight reason for one-call helper wrappers."""
    cache_key = _get_lightweight_reference_cache_key(func)
    cached = _lightweight_compact_helper_reason_cache.get(
        cache_key,
        _LIGHTWEIGHT_CACHE_MISS,
    )
    if cached is not _LIGHTWEIGHT_CACHE_MISS:
        return cached

    direct_shape = _summarize_lightweight_local_shape(func)

    if (
        direct_shape['call_ops'] != 1
        or direct_shape['attribute_ops'] != 0
        or direct_shape['container_build_ops'] != 0
        or direct_shape['loop_ops'] != 0
        or direct_shape['subscript_ops'] != 0
    ):
        _cache_lightweight_compact_helper_reason(cache_key, None)
        return None

    helpers = tuple(_iter_lightweight_direct_helpers(func))
    if len(helpers) != 1:
        _cache_lightweight_compact_helper_reason(cache_key, None)
        return None
    helper = helpers[0]
    helper_shape = _summarize_lightweight_shape_recursive(helper)
    no_benefit_reason = _get_lightweight_container_orchestration_reason(
        helper_shape,
    )
    if (
        no_benefit_reason
        and not _helper_has_lightweight_imported_numeric_signal(helper)
    ):
        _cache_lightweight_compact_helper_reason(cache_key, no_benefit_reason)
        return no_benefit_reason
    if _helper_has_lightweight_numeric_signal(helper):
        _cache_lightweight_compact_helper_reason(cache_key, None)
        return None

    reason = 'Compact helper wrapper detected'
    _cache_lightweight_compact_helper_reason(cache_key, reason)
    return reason


def _is_trivially_small_lightweight_workload(profile) -> bool:
    """Return whether *profile* is too small to justify any Epochly init."""
    if profile.has_random_names:
        return False
    if (
        profile.direct_numeric_modules
        or profile.direct_numeric_callables
        or profile.helper_numeric_modules
        or profile.helper_numeric_callables
    ):
        return False

    total_shape = profile.total_shape
    weighted_ops = (
        total_shape.get('call_ops', 0)
        + total_shape.get('attribute_ops', 0)
        + total_shape.get('subscript_ops', 0)
        + total_shape.get('container_build_ops', 0)
        + (total_shape.get('loop_ops', 0) * 2)
        + (total_shape.get('helper_calls', 0) * 2)
    )
    return (
        total_shape.get('loop_ops', 0) == 0
        and total_shape.get('helper_calls', 0) == 0
        and weighted_ops <= 2
    )


def _get_lightweight_skip_reason(func, *, requested_level=None):
    """Return the cheap-reject reason for obviously unsuitable work."""
    compact_helper_reason = _get_compact_helper_wrapper_reason(func)
    if compact_helper_reason:
        return compact_helper_reason

    try:
        from .bytecode_prefilter import (
            _get_level3_denylist_reason,
            build_workload_profile,
            get_lightweight_no_benefit_reason,
        )

        skip_reason = get_lightweight_no_benefit_reason(func)
        if skip_reason:
            return skip_reason

        deny_reason = _get_level3_denylist_reason(func)
        if deny_reason:
            return deny_reason

        profile = build_workload_profile(func)
        if _is_trivially_small_lightweight_workload(profile):
            return "Trivially small workload detected"
    except Exception:
        return None

    if _should_apply_lightweight_jit_precheck(requested_level):
        return _get_lightweight_jit_skip_reason(func)

    return None


def _should_defer_lightweight_rejection_to_level3(func, *, requested_level=None):
    """Return whether a rejected function should still reach Level 3 routing.

    The lightweight wrapper exists to preserve near-zero overhead for clearly
    unsuitable work.  It must not block collection-loop workloads that are bad
    JIT fits but still eligible for Level 3 ProcessPool / loop-transform
    routing.  Use a narrow escape hatch: only admit functions that both
    (a) contain loop evidence and (b) pass the Level 3 deny-list gate.
    """
    if not _should_allow_level3_deferral(requested_level):
        return False

    if _get_compact_helper_wrapper_reason(func):
        return False

    try:
        from .bytecode_prefilter import (
            build_workload_profile,
            classify_workload,
            is_batch_parallelizable,
        )

        # Hard-reject stages are authoritative -- the classifier already
        # considered shape, pattern, and orchestration evidence.  Deferring
        # these to Level 3 would let unsuitable workloads bypass the cheap
        # rejection gate the classifier intentionally closed.
        #
        # NOTE: "bytecode_compat" is intentionally excluded.  That stage
        # only signals "not JIT-compatible" (dict/string/method patterns),
        # but Level 3 includes non-JIT paths (ProcessPool, loop-transform)
        # that can still benefit collection-loop workloads.
        _HARD_REJECT_STAGES = frozenset({
            "pattern_match",
            "shape_analysis",
            "staged_classifier",
        })
        decision = classify_workload(func)
        if decision.should_reject and decision.stage in _HARD_REJECT_STAGES:
            return False

        profile = build_workload_profile(func)
        has_loop_evidence = profile.total_shape.get('loop_ops', 0) > 0
        if not has_loop_evidence:
            return False

        return bool(is_batch_parallelizable(func))
    except Exception:
        return False


def _defer_lightweight_status_recording(
    func_name,
    skip_reason,
    *,
    requested_level,
    first_call_ms,
):
    """Defer heavyweight status dict construction until a consumer needs it."""
    global _deferred_lightweight_status_args, _lightweight_status_recorded_at
    _deferred_lightweight_status_args = (func_name, skip_reason, requested_level, first_call_ms)
    _lightweight_status_recorded_at = _time.time()


def _materialize_deferred_lightweight_status():
    """Build the full status dict from deferred args if pending."""
    global _deferred_lightweight_status_args
    if _deferred_lightweight_status_args is not None:
        args = _deferred_lightweight_status_args
        _deferred_lightweight_status_args = None
        _record_lightweight_decorator_status_with_request(
            args[0], args[1],
            requested_level=args[2],
            first_call_ms=args[3],
        )


def _is_epochly_profile_hook(profile_hook: object) -> bool:
    """Return True when the active profile hook is Epochly's own hook."""
    if profile_hook is None:
        return False
    try:
        from .core.profiler import epochly_profile_hook
    except Exception:
        return False
    return profile_hook is epochly_profile_hook


def _call_with_epochly_profile_suspended(func, *func_args, **func_kwargs):
    """Call func while suspending Epochly's sys.setprofile hook only.

    Python 3.9-3.11 use sys.setprofile for transparent monitoring. For
    lightweight no-benefit decorator rejections, keeping that hook active
    while executing the rejected function is pure overhead: the function is
    already known to be unsuitable and no core has been initialized. Do not
    disturb an application/user profiler; suspend only the Epochly hook and
    restore it when the target did not intentionally replace the profiler.
    """
    profile_hook = sys.getprofile()
    if not _is_epochly_profile_hook(profile_hook):
        return func(*func_args, **func_kwargs)

    sys.setprofile(None)
    try:
        return func(*func_args, **func_kwargs)
    finally:
        if sys.getprofile() is None:
            sys.setprofile(profile_hook)


def _suspend_epochly_profile_after_lightweight_rejection():
    """Remove Epochly's global profiler after an explicit no-benefit reject.

    On Python 3.9-3.11, auto_enable() uses sys.setprofile because
    sys.monitoring is unavailable. Once @epochly.optimize has classified an
    explicitly decorated function as a no-benefit workload, continuing to run
    the global Epochly profile hook while repeatedly calling that rejected
    function is pure overhead. Disable only Epochly's own hook; leave user or
    third-party profilers untouched.
    """
    if _core_singleton is not None:
        return
    profile_hook = sys.getprofile()
    if not _is_epochly_profile_hook(profile_hook):
        return
    sys.setprofile(None)


def _maybe_build_lightweight_no_benefit_wrapper_for_optimize(
    func,
    *,
    requested_level=None,
):
    """Build optimize()'s lightweight reject without profiling the classifier."""
    if _core_singleton is not None:
        return None

    profile_hook = sys.getprofile()
    suspend_profile = _core_singleton is None and _is_epochly_profile_hook(profile_hook)
    if suspend_profile:
        sys.setprofile(None)

    try:
        lightweight = _maybe_build_lightweight_no_benefit_wrapper(
            func,
            requested_level=requested_level,
        )
    except Exception:
        if suspend_profile and sys.getprofile() is None:
            sys.setprofile(profile_hook)
        raise

    if lightweight is None and suspend_profile and sys.getprofile() is None:
        sys.setprofile(profile_hook)
    return lightweight


def _record_lightweight_decorator_status_with_request(
    func_name,
    skip_reason,
    *,
    requested_level,
    first_call_ms,
):
    """Store synthetic decorator status for lightweight no-benefit rejection."""
    global _lightweight_decorator_status, _lightweight_status_recorded_at

    configured_level = _get_lazy_enabled_level_name()
    level_values = {
        'LEVEL_0_MONITOR': 0,
        'LEVEL_1_THREADING': 1,
        'LEVEL_2_JIT': 2,
        'LEVEL_3_FULL': 3,
        'LEVEL_4_GPU': 4,
    }
    requested_level_name = _normalize_lightweight_requested_level_name(
        requested_level,
    )
    realized_level = 'LEVEL_0_MONITOR'
    fallback_summary = (
        "No functions optimized -- decorator fallback for "
        f"{func_name}: requested {requested_level_name}, "
        f"realized {realized_level}, reason: {skip_reason}"
    )
    inline_summary = None
    if requested_level is not None:
        inline_summary = (
            "Epochly decorator fallback: "
            f"{func_name}; requested={requested_level_name}; "
            f"realized={realized_level}; "
            "optimization_effective=false; "
            f"reason={skip_reason}"
        )

    first_call_ms_value = (
        None if first_call_ms is None else round(float(first_call_ms), 1)
    )
    paid_cold_start_tax = bool(
        first_call_ms_value is not None
        and first_call_ms_value >= _LIGHTWEIGHT_DECORATOR_COLD_START_THRESHOLD_MS
    )
    _lightweight_status_recorded_at = _time.time()
    python_version = (
        f"{sys.version_info.major}."
        f"{sys.version_info.minor}."
        f"{sys.version_info.micro}"
    )
    _lightweight_decorator_status = {
        'enabled': True,
        'initialized': False,
        'enhancement_level': realized_level,
        'level_value': level_values.get(realized_level, 0),
        'level': level_values.get(realized_level, 0),
        'configured_level': configured_level,
        'python_version': python_version,
        'platform': _PLATFORM_SYSTEM,
        'closed': False,
        'monitoring_active': False,
        'stability_metrics': None,
        'performance_config': None,
        'optimization_effective': False,
        'optimization_summary': fallback_summary,
        'realized_level': realized_level,
        'monitoring_overhead_eliminated': False,
        'monitoring_overhead_note': None,
        'skipped_functions_detail': [{
            'name': func_name,
            'skip_reason': skip_reason,
        }],
        'last_decorator_call': _with_requested_level_backcompat({
            'function_name': func_name,
            'requested_level': requested_level_name,
            'configured_level': configured_level,
            'realized_level': realized_level,
            'optimization_effective': False,
            'fallback_reason': skip_reason,
            'first_call_ms': first_call_ms_value,
            'paid_cold_start_tax': paid_cold_start_tax,
            'fallback_summary': fallback_summary,
            'inline_summary': inline_summary,
        }),
    }


def _get_process_memory_mb():
    """Best-effort process RSS in MB without forcing heavy imports."""
    try:
        import resource

        usage = resource.getrusage(resource.RUSAGE_SELF)
        if sys.platform == 'darwin':
            return round(usage.ru_maxrss / (1024 * 1024), 1)
        else:
            return round(usage.ru_maxrss / 1024, 1)
    except Exception:
        return None


def _build_lightweight_metrics():
    """Return user metrics from lightweight decorator fallback state."""
    if _lightweight_decorator_status is None:
        return None

    configured_level = _lightweight_decorator_status.get(
        'configured_level',
        _get_lightweight_configured_level_name(),
    )
    configured_level = _apply_lightweight_max_level_cap(configured_level)
    skipped = list(
        _lightweight_decorator_status.get('skipped_functions_detail', [])
    )
    started_at = (
        _lightweight_status_recorded_at
        if _lightweight_status_recorded_at is not None
        else _time.time()
    )
    return {
        "enabled": True,
        "level": configured_level,
        "uptime_seconds": round(_time.time() - started_at, 1),
        "functions_analyzed": 0,
        "functions_optimized": 0,
        "functions_skipped": len(skipped),
        "estimated_speedup_pct": 0.0,
        "memory_used_mb": _get_process_memory_mb(),
        "compilation_queue_pending": 0,
        "skipped_functions_detail": skipped,
        "monitoring_overhead_eliminated": False,
        "monitoring_overhead_note": None,
        "lens_heartbeat_active": False,
        "lens_api_key_set": bool(_config_resolver.env_get(_config_resolver.ENV_API_KEY)),
    }


def _get_lazy_enabled_level_name():
    """Best-effort configured level for lazy enable() before core init."""
    raw_level = _config_resolver.env_get(_config_resolver.ENV_LEVEL)
    configured_level = _get_lightweight_configured_level_name()
    if raw_level:
        return configured_level

    skip_state_restore = (
        _config_resolver.env_truthy(_config_resolver.ENV_TEST_MODE)
        or _config_resolver.env_truthy(_config_resolver.ENV_NO_STATE_RESTORE)
        or _config_resolver.env_truthy(_config_resolver.ENV_DISABLE)
    )
    if not skip_state_restore:
        try:
            import pickle
            from .config import resolve_state_directory

            state_dir = resolve_state_directory('~/.epochly/state')
            state_files = sorted(
                state_dir.glob('epochly_state_*.pkl'),
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )
            if state_files:
                with open(state_files[0], 'rb') as handle:
                    state = pickle.load(handle)
                level_value = str(state.get('enhancement_level', '')).strip()
                level_map = {
                    '0': 'LEVEL_0_MONITOR',
                    '1': 'LEVEL_1_THREADING',
                    '2': 'LEVEL_2_JIT',
                    '3': 'LEVEL_3_FULL',
                    '4': 'LEVEL_4_GPU',
                }
                if level_value in level_map:
                    return _apply_lightweight_max_level_cap(
                        level_map[level_value]
                    )
        except Exception:
            pass

    try:
        import importlib.util

        if importlib.util.find_spec('numba') is not None:
            return _apply_lightweight_max_level_cap('LEVEL_2_JIT')
    except Exception:
        pass

    return _apply_lightweight_max_level_cap(configured_level)


def _build_lazy_enabled_status():
    """Return status for enable() before the full core is initialized."""
    import platform

    configured_level = _get_lazy_enabled_level_name()
    level_values = {
        'LEVEL_0_MONITOR': 0,
        'LEVEL_1_THREADING': 1,
        'LEVEL_2_JIT': 2,
        'LEVEL_3_FULL': 3,
        'LEVEL_4_GPU': 4,
    }
    return {
        'enabled': True,
        'initialized': False,
        'enhancement_level': configured_level,
        'level_value': level_values.get(configured_level, 1),
        'level': level_values.get(configured_level, 1),
        'configured_level': configured_level,
        'python_version': (
            f"{sys.version_info.major}."
            f"{sys.version_info.minor}."
            f"{sys.version_info.micro}"
        ),
        'platform': platform.system(),
        'closed': False,
        'monitoring_active': False,
        'stability_metrics': None,
        'performance_config': None,
        'optimization_effective': False,
        'optimization_summary': 'Monitoring only -- no functions analyzed yet',
        'realized_level': 'LEVEL_0_MONITOR',
        'monitoring_overhead_eliminated': False,
        'monitoring_overhead_note': None,
        'skipped_functions_detail': [],
    }


def _maybe_build_lightweight_no_benefit_wrapper(func, *, requested_level=None):
    """Return a cheap wrapper for obvious benchmark-guard style bad-fit work."""
    if _core_singleton is not None:
        return None  # type: ignore[unreachable]
    if _config_resolver.env_truthy(_config_resolver.ENV_DISABLE):
        return None
    if _is_runtime_emergency_active():
        return None
    if _config_resolver.env_truthy(_config_resolver.ENV_DEV_BYPASS):
        return None
    if not _supports_lightweight_no_benefit_request(requested_level):
        return None

    try:
        from functools import wraps

        code = getattr(func, '__code__', None)
        if code is None:
            return None

        skip_reason = _get_lightweight_skip_reason(
            func,
            requested_level=requested_level,
        )
        if not skip_reason:
            return None
        if _should_defer_lightweight_rejection_to_level3(
            func,
            requested_level=requested_level,
        ):
            return None
        if _explicitly_enabled:
            try:
                from .core import epochly_core as _core_module
                _core_module.classify_workload(func)
            except Exception:
                pass

        invoke = None

        @wraps(func)
        def _wrapper(*func_args, **func_kwargs):
            return invoke(*func_args, **func_kwargs)  # type: ignore[misc]

        deferred_status_args = (func.__name__, skip_reason, requested_level, None)

        if _should_apply_lightweight_jit_precheck(requested_level):
            global _deferred_lightweight_status_args
            global _lightweight_status_recorded_at
            _deferred_lightweight_status_args = deferred_status_args
            _lightweight_status_recorded_at = None
            def _direct_invoke(*func_args, **func_kwargs):
                return _call_with_epochly_profile_suspended(
                    func,
                    *func_args,
                    **func_kwargs,
                )

            invoke = _direct_invoke
            _wrapper._epochly_enhanced = True  # type: ignore[attr-defined]
            _wrapper._epochly_level = requested_level  # type: ignore[attr-defined]
            _wrapper._epochly_original = func  # type: ignore[attr-defined]
            return _wrapper

        def _first_invoke(*func_args, **func_kwargs):
            nonlocal invoke
            global _deferred_lightweight_status_args
            global _lightweight_status_recorded_at
            first_call_started = _time.perf_counter()
            result = _call_with_epochly_profile_suspended(
                func,
                *func_args,
                **func_kwargs,
            )
            first_call_ms = (
                _time.perf_counter() - first_call_started
            ) * 1000.0
            _deferred_lightweight_status_args = (
                func.__name__,
                skip_reason,
                requested_level,
                first_call_ms,
            )
            _lightweight_status_recorded_at = None
            def _direct_invoke(*direct_args, **direct_kwargs):
                return _call_with_epochly_profile_suspended(
                    func,
                    *direct_args,
                    **direct_kwargs,
                )

            invoke = _direct_invoke
            return result

        invoke = _first_invoke

        _wrapper._epochly_enhanced = True  # type: ignore[attr-defined]
        _wrapper._epochly_level = requested_level  # type: ignore[attr-defined]
        _wrapper._epochly_original = func  # type: ignore[attr-defined]
        return _wrapper
    except Exception:
        return None


def _should_auto_enable():
    """
    Check if auto-enable should be triggered based on environment variable.

    Auto-enable is triggered when EPOCHLY_AUTO_ENABLE environment variable
    is set to one of: '1', 'true', 'yes', 'on' (case-insensitive).

    Returns:
        bool: True if EPOCHLY_AUTO_ENABLE is set to a truthy value
    """
    return _config_resolver.env_truthy(_config_resolver.ENV_AUTO_ENABLE)


def _runtime_emergency_metadata() -> dict[str, Any]:
    """Read emergency state from the detector accessors, not from env reads here."""
    try:
        from .monitoring.auto_emergency_detector import emergency_metadata as _emergency_metadata
        return _emergency_metadata()
    except Exception:
        return {
            'active': False,
            'latched': False,
            'reason': None,
            'source': None,
            'triggered_at': None,
        }


def _is_runtime_emergency_active() -> bool:
    """Legacy EPOCHLY_EMERGENCY_DISABLE precedence now flows through detector accessors."""
    return bool(_runtime_emergency_metadata().get('active'))


def _has_valid_dev_bypass() -> bool:
    """Return True when developer bypass mode is explicitly requested and valid."""
    if not _config_resolver.env_truthy(_config_resolver.ENV_DEV_BYPASS):
        return False

    try:
        from .licensing.dev_token_validator import is_dev_bypass_active
    except Exception:
        return False

    try:
        return bool(is_dev_bypass_active())
    except Exception:
        return False


def _ensure_core_initialized():
    """
    Ensure Epochly core is initialized (lazy initialization).

    This is the main entry point for lazy initialization. It:
    1. Checks if core is already initialized (fast path)
    2. If not, acquires lock and initializes (slow path)
    3. Records timing metrics via performance monitor
    4. Returns the initialized core instance

    Thread-safe: Multiple concurrent calls will only initialize once.

    Returns:
        EpochlyCore: The initialized core instance, or None if initialization failed

    Note:
        If initialization fails, a warning is issued and None is returned.
        This allows graceful degradation - optimizations will be disabled
        but the application will continue to run.
    """
    global _core_singleton, _lightweight_decorator_status
    global _lightweight_status_recorded_at

    # CRITICAL: legacy EPOCHLY_EMERGENCY_DISABLE precedence still applies, but
    # the read now goes through AutoEmergencyDetector accessors instead of a
    # direct environment lookup in this function.
    if _is_runtime_emergency_active():
        return None

    # P3-1 FIX (Dec 2025): Move singleton check BEFORE EPOCHLY_DISABLE check.
    #
    # PROBLEM: During Level 3 ProcessPool initialization, EPOCHLY_DISABLE=1 is
    # temporarily set in the main process to prevent workers from initializing
    # Epochly recursively. However, if get_status() is called from another thread
    # during this time, it would see EPOCHLY_DISABLE=1 and return None, causing
    # level to appear as "DISABLED" even though core is fully initialized.
    #
    # SOLUTION: Check if core is already initialized BEFORE checking EPOCHLY_DISABLE.
    # EPOCHLY_DISABLE is meant to prevent NEW initialization, not to shut down
    # an already-running core. An already-initialized core should keep running
    # even if EPOCHLY_DISABLE=1 is temporarily set.
    #
    # Fast path: core already initialized - return it regardless of EPOCHLY_DISABLE
    if _core_singleton is not None:
        return _core_singleton

    # EPOCHLY_DISABLE prevents NEW initialization only (checked AFTER singleton check)
    # Public disable() now relies on the module-level _globally_disabled flag
    # instead of mutating process-wide environment state.
    from .core.epochly_core import _is_globally_disabled
    if _is_globally_disabled() or _config_resolver.env_truthy(_config_resolver.ENV_DISABLE):
        return None

    # Slow path: need to initialize
    with _init_lock:
        # Double-check: another thread may have initialized while we waited
        if _core_singleton is not None:
            return _core_singleton

        # Auto-detect test frameworks and suppress user-visible logging.
        # Users should not need to add EPOCHLY_DISABLE=1 to their conftest —
        # Epochly should be invisible during test runs by default.
        # v0.4.16: NumbaWarning filter now installed at module level (import time)
        # to override -W default. See top of __init__.py.

        if 'pytest' in sys.modules or 'unittest' in sys.modules:
            _epochly_logger = logging.getLogger('epochly')
            if _epochly_logger.level < logging.ERROR:
                _epochly_logger.setLevel(logging.ERROR)

        # Record initialization start time
        start_time = _time.perf_counter()

        try:
            from .core.epochly_core import EpochlyCore
            import atexit

            # Create and initialize core
            _core_singleton = EpochlyCore()
            _core_singleton.initialize()
            _lightweight_decorator_status = None
            _lightweight_status_recorded_at = None

            # Register cleanup handler for proper shutdown
            atexit.register(_cleanup_global_epochly)

            # Update backward compatibility alias
            _update_global_epochly_core_alias()
            _set_lifecycle_state(
                initialized=getattr(_core_singleton, '_initialized', False),
                enabled=getattr(_core_singleton, 'enabled', False),
                current_level=getattr(_core_singleton, 'current_level', None),
            )

            # Record initialization time
            init_time_ms = (_time.perf_counter() - start_time) * 1000

            # Try to record metric (graceful degradation if monitor not available)
            try:
                monitor = getattr(_core_singleton, 'performance_monitor', None)
                if monitor is None:
                    from .monitoring.performance_monitor import get_performance_monitor
                    monitor = get_performance_monitor()
                monitor.record_metric('core.lazy_init_ms', init_time_ms)
            except Exception:
                pass  # Silently ignore metric recording failures

            # v0.4.29 FIX (#126): Defer Lens heartbeat to first actual optimization.
            # start_lens_heartbeat() spawns a daemon thread and imports HTTP libs
            # (~30 MB). For decorator-only workloads on unoptimizable functions,
            # this thread runs for the process lifetime doing nothing useful.
            # Heartbeat will start when subsystems are initialized (on-demand).
            # Original code: from .telemetry.lens_heartbeat import start_lens_heartbeat
            #                start_lens_heartbeat()

        except Exception as e:
            # Q-M-002: Store structured error details for diagnostic retrieval
            global _last_init_error
            import traceback as _tb
            from datetime import datetime

            error_details = {
                'error_type': type(e).__name__,
                'error_message': str(e),
                'timestamp': datetime.now().isoformat(),
            }

            # Include traceback if debug mode enabled
            if _config_resolver.env_truthy(_config_resolver.ENV_DEBUG):
                error_details['traceback'] = _tb.format_exc()
                print("Epochly initialization error:", file=sys.stderr)
                _tb.print_exc(file=sys.stderr)

            _last_init_error = error_details

            # Q-M-002: Support EPOCHLY_STRICT_INIT to fail fast
            strict_mode = _config_resolver.env_truthy(_config_resolver.ENV_STRICT_INIT)
            if strict_mode:
                from .utils.exceptions import EpochlyInitializationError

                raise EpochlyInitializationError(
                    f"Epochly core initialization failed: {e}",
                    component="lazy_init",
                    cause=e
                ) from e

            # Non-strict mode: Warn user and provide diagnostics
            import warnings
            warnings.warn(
                f"Epochly core initialization failed: {e}. "
                f"Optimization will be disabled but application will continue. "
                f"To debug, set EPOCHLY_DEBUG=1 or EPOCHLY_STRICT_INIT=1.",
                RuntimeWarning,
                stacklevel=2
            )

            # Core remains None - callers will see this and skip optimization
            _core_singleton = None

    return _core_singleton


def _update_global_epochly_core_alias():
    """
    Update the _global_epochly_core alias to point to current singleton.

    This is called after successful initialization to maintain backward compatibility.
    """
    global _global_epochly_core
    _global_epochly_core = _core_singleton


def _cleanup_global_epochly():
    """
    Cleanup global Epochly core on exit.

    Shuts down the core instance and resets all global state.
    Called automatically via atexit handler.

    CRITICAL FIX (Dec 2025): Only run cleanup in main process.
    Subprocess workers (from multiprocessing or sub-interpreters) also trigger
    atexit handlers when they exit. If we call shutdown() in a subprocess,
    it can interfere with the main process's detection threads, causing
    Level 3 detection to abort prematurely (stop_event gets set).
    """
    import multiprocessing

    global _core_singleton, _auto_enabled, _explicitly_enabled, _global_epochly_core
    global _lightweight_decorator_status, _lightweight_status_recorded_at
    global _deferred_lightweight_status_args

    # Only cleanup in the main process - subprocesses should not call shutdown
    # on the main process's singleton (they have their own copy anyway)
    current_process = multiprocessing.current_process()
    if current_process.name != "MainProcess":
        # Subprocess - don't touch the singleton
        return

    if _core_singleton:
        try:
            # Signal shutdown for fast exit (reduced timeouts, non-blocking cleanup)
            # Consilium RCA (Mar 2026): 15s+5s spawn waits block subprocess exit
            _core_singleton._atexit_shutdown = True
            _teardown_runtime(clear_disable_env=False)
        except Exception:
            # Ignore errors during exit cleanup
            pass
        finally:
            _core_singleton = None
            _auto_enabled = False  # Reset for potential module reload
            _explicitly_enabled = False
            _global_epochly_core = None  # Reset alias as well
            _lightweight_decorator_status = None
            _lightweight_status_recorded_at = None
            _deferred_lightweight_status_args = None
            _remove_import_hooks()
            _reset_runtime_lifecycle_state()


# Backward compatibility: Keep _global_epochly_core as alias for _core_singleton
# This will be updated after initialization via _update_global_epochly_core_alias()
_global_epochly_core = None


# ============================================================================
# Q-M-002: Initialization State Detection Functions
# ============================================================================
# These functions allow callers to detect and diagnose lazy init failures.
# ============================================================================

def get_init_error():
    """
    Get details about the last initialization error.

    Q-M-002: Provides structured error diagnostics instead of silent None.

    Returns:
        dict: Error details with 'error_type', 'error_message', 'timestamp',
              and optionally 'traceback' (if EPOCHLY_DEBUG=1 was set).
              Returns None if no error occurred.
    """
    return _last_init_error


def is_initialized():
    """
    Check if Epochly core is successfully initialized.

    Q-M-002: Allows callers to detect initialization state.

    Returns:
        bool: True if core is initialized and ready, False otherwise.
    """
    return _core_singleton is not None


def had_init_error():
    """
    Check if initialization was attempted and failed.

    Q-M-002: Allows callers to distinguish between "not yet initialized"
    and "tried to initialize but failed".

    Returns:
        bool: True if initialization was attempted and failed.
    """
    return _last_init_error is not None


def clear_init_error():
    """
    Clear the initialization error state to allow retry.

    Q-M-002: Allows callers to reset error state before retrying init.
    Useful after fixing the underlying issue (e.g., installing dependencies).
    """
    global _last_init_error
    _last_init_error = None


# ============================================================================
# Lazy API Wrappers (Always Lazy - Task 1 Performance Improvement)
# ============================================================================
# ALL public API functions use lazy imports to minimize import-time overhead.
# This ensures import epochly completes in <10ms regardless of mode.
# ============================================================================

def epochly_run(func=None, *args, **kwargs):
    """
    Epochly optimization — works as both decorator and immediate executor.

    **Decorator usage** (backward-compatible)::

        @epochly_run
        def my_func(): ...

        @epochly_run(level=3)
        def my_func(): ...

    **Immediate execution** (requires at least one positional arg after func)::

        result = epochly_run(my_func, arg1, arg2, key=val)

    .. note::
        Executor mode requires at least one positional argument after ``func``.
        ``epochly_run(func, x=1)`` with kwargs-only is treated as decorator
        config, not execution. Use ``epochly_run(func, None, x=1)`` or call
        the decorated function directly if you need kwargs-only execution.

    Args:
        func: Callable to optimize/execute, or None for decorator factory.
        *args: If provided, func is executed immediately with these args.
        **kwargs: Forwarded to the decorator factory (level, config, etc.)
            or to func when in executor mode (when *args are also present).

    Returns:
        - Decorator mode: decorated function or decorator factory
        - Executor mode: result from the optimized function execution
    """
    _ensure_core_initialized()
    from .api.public_api import epochly_run as _epochly_run

    def _capture_source(function_obj, wrapped_obj=None):
        """Capture source text on decorated callables for downstream AST extraction."""
        try:
            source_text = inspect.getsource(function_obj)
        except Exception:
            return
        try:
            function_obj.__epochly_source__ = source_text
        except Exception:
            pass
        if wrapped_obj is not None and callable(wrapped_obj):
            try:
                wrapped_obj.__epochly_source__ = source_text
            except Exception:
                pass

    # Case 1: @epochly_run(level=3) — no func, keyword args only → decorator factory
    if func is None:
        decorator = _epochly_run(**kwargs)
        if not callable(decorator):
            return decorator

        def _decorator(target_func):
            wrapped = decorator(target_func)
            _capture_source(target_func, wrapped)
            return wrapped

        return _decorator

    # Case 2: epochly_run(func, arg1, arg2, ...) — func + positional args → execute
    if callable(func) and args:
        optimized = _epochly_run(func)
        _capture_source(func, optimized)
        return optimized(*args, **kwargs)

    # Case 3: @epochly_run — bare decorator, func is the decorated function
    if callable(func) and not args and not kwargs:
        wrapped = _epochly_run(func)
        _capture_source(func, wrapped)
        return wrapped

    # Case 4: epochly_run(func, key=val) — ambiguous but treat as decorator factory
    # since public_api.epochly_run accepts keyword config args
    if callable(func):
        wrapped = _epochly_run(func, **kwargs)
        _capture_source(func, wrapped)
        return wrapped

    # Case 5: non-callable first arg (e.g. epochly_run(level=3) matched positionally)
    # Pass through to public_api for error handling
    return _epochly_run(func, *args, **kwargs)


def configure(*args, **kwargs):
    """
    Configure Epochly optimization parameters.

    Lazy import wrapper that defers module loading until first use.
    Ensures core is initialized before calling the actual function.

    Args:
        Same as epochly.api.public_api.configure

    Returns:
        Configuration object or None
    """
    _ensure_core_initialized()
    from .api.public_api import configure as _configure
    return _configure(*args, **kwargs)


def optimize(*args, **kwargs):
    """
    Decorator to optimize a Python function with Epochly.

    Lazy import wrapper that defers module loading until decorator application.
    Ensures core is initialized before applying the decorator.

    Supports both usage patterns:
    - @epochly.optimize (without parentheses) - applies default optimization
    - @epochly.optimize() or @epochly.optimize(level=2) - with arguments

    Args:
        Same as epochly.api.decorators.optimize

    Returns:
        Decorated function with Epochly optimizations applied
    """
    decorator_args = args
    if len(args) == 1 and callable(args[0]):
        decorator_args = ()

    def _decorate_with_lightweight_support(func):
        requested_level = kwargs.get("level")
        lightweight = _maybe_build_lightweight_no_benefit_wrapper_for_optimize(
            func,
            requested_level=requested_level,
        )
        if lightweight is not None:
            _suspend_epochly_profile_after_lightweight_rejection()
            return lightweight
        _ensure_core_initialized()
        from .api.decorators import optimize as _optimize
        return _optimize(*decorator_args, **kwargs)(func)

    # Support @epochly.optimize and @epochly.optimize() without forcing
    # full core init for obvious benchmark-guard style bad-fit workloads.
    if not kwargs:
        if len(args) == 1 and callable(args[0]):
            func = args[0]
            lightweight = _maybe_build_lightweight_no_benefit_wrapper_for_optimize(
                func,
                requested_level=None,
            )
            if lightweight is not None:
                _suspend_epochly_profile_after_lightweight_rejection()
                return lightweight
        elif len(args) == 0:
            def _default_decorator(func):
                lightweight = _maybe_build_lightweight_no_benefit_wrapper_for_optimize(
                    func,
                    requested_level=None,
                )
                if lightweight is not None:
                    _suspend_epochly_profile_after_lightweight_rejection()
                    return lightweight
                _ensure_core_initialized()
                from .api.decorators import optimize as _optimize
                return _optimize()(func)

            return _default_decorator
    elif len(args) == 0:
        return _decorate_with_lightweight_support

    elif len(args) == 1 and callable(args[0]):
        return _decorate_with_lightweight_support(args[0])

    _ensure_core_initialized()
    from .api.decorators import optimize as _optimize

    # Support @epochly.optimize without parentheses
    # If called with a single callable argument and no kwargs, it's direct decoration
    if len(args) == 1 and callable(args[0]) and not kwargs:
        func = args[0]
        # Apply the decorator with default settings
        return _optimize()(func)

    # Otherwise, pass through to the underlying decorator
    return _optimize(*args, **kwargs)


def optimize_context(*args, **kwargs):
    """
    Context manager for temporary Epochly optimization.

    Lazy import wrapper that defers module loading until context creation.
    Ensures core is initialized before creating the context manager.

    Args:
        Same as epochly.api.context_managers.optimize_context

    Returns:
        Context manager for Epochly optimization
    """
    _ensure_core_initialized()
    from .api.context_managers import optimize_context as _optimize_context
    return _optimize_context(*args, **kwargs)


# ============================================================================
# Transparent Activation Function
# ============================================================================

def _is_pytest_collection_context():
    """Return True when transparent activation is running during pytest collection."""
    if (
        _config_resolver.env_truthy(_config_resolver.ENV_TEST_MODE)
        or _config_resolver.env_truthy(_config_resolver.ENV_DEV_BYPASS)
    ):
        return False
    current_test = _config_resolver.env_get('PYTEST_CURRENT_TEST')
    if current_test == '1':
        return True
    return 'pytest' in sys.modules and current_test is None


def _transparent_auto_profiler_disabled():
    """Return True when transparent profiling/import hooks must not be installed."""
    return (
        _config_resolver.env_truthy(_config_resolver.ENV_DISABLE)
        or _config_resolver.env_truthy(_config_resolver.ENV_NO_PROFILER)
        or _is_pytest_collection_context()
    )


def auto_enable(force=False):
    """
    Transparently enable Epochly for all Python code.

    Called from sitecustomize.py to activate Epochly without code changes.
    Implements the zero-configuration promise from architecture spec.

    With lazy initialization, this function now:
    1. Installs hooks (profiler, import hook) immediately
    2. Defers core initialization until first use OR if force=True

    Args:
        force (bool): If True, force immediate core initialization.
                     If False, use lazy initialization (initialize on first use).

    Architecture Reference:
    - Lines 1838-1854: auto_enable() specification
    - Lines 5680-5700: Transparent activation mechanism
    - Lines 2012-2086: EpochlyProfiler with sys.setprofile
    - Task 1: Lazy initialization to eliminate import-time overhead
    """
    global _auto_enabled, _core_singleton, _import_hook_installed

    # Quick environment check (<1ms)
    if (
        _config_resolver.env_get(_config_resolver.ENV_MODE) == 'off'
        or _transparent_auto_profiler_disabled()
    ):
        _remove_import_hooks()
        _set_lifecycle_state(import_hook_installed=False, enabled=False)
        return

    # CRITICAL FIX: Move state management inside lock to prevent race conditions
    # Determine initialization decision inside lock, perform initialization OUTSIDE lock
    with _init_lock:
        # Check if already enabled (prevent double-init)
        if _auto_enabled and hasattr(sys, '_epochly_initialized'):
            return

        # Mark as enabled and initialized (thread-safe)
        sys._epochly_initialized = True
        _auto_enabled = True

        # Import required components (inside lock to prevent duplicate imports)
        from .core.import_hook import EpochlyImportHook

        # Register import hook for module interception (thread-safe)
        if EpochlyImportHook not in [type(hook) for hook in sys.meta_path]:
            sys.meta_path.insert(0, EpochlyImportHook())
        _import_hook_installed = True
        _set_lifecycle_state(import_hook_installed=True, shutdown=False)

        # Install profiling hook (lightweight)
        # This creates the global profiler
        #
        # P0.24 FIX (Dec 2025): sys.setprofile causes 350%+ overhead because it runs
        # on EVERY function call. On Python 3.12+, we use sys.monitoring instead
        # which can return DISABLE for individual code objects (near-zero overhead).
        #
        # The EpochlyProfiler (sys.setprofile) is ONLY needed on Python <3.12 where
        # sys.monitoring is not available. On Python 3.12+, AutoProfiler handles
        # hot loop detection via sys.monitoring with minimal overhead.
        #
        # Users can force sys.setprofile on Python 3.12+ with EPOCHLY_FORCE_SETPROFILE=1
        # (for debugging or specific profiling needs).
        skip_setprofile = _config_resolver.env_truthy(_config_resolver.ENV_DISABLE_SETPROFILE)
        force_setprofile = _config_resolver.env_truthy(_config_resolver.ENV_FORCE_SETPROFILE)

        # P0.24: On Python 3.12+, skip sys.setprofile by default (use sys.monitoring instead)
        has_sys_monitoring = sys.version_info >= (3, 12) and hasattr(sys, 'monitoring')
        if has_sys_monitoring and not force_setprofile:
            skip_setprofile = True
            import logging
            logging.getLogger('epochly').debug(
                "P0.24: Skipping sys.setprofile on Python 3.12+ (using sys.monitoring instead). "
                "Set EPOCHLY_FORCE_SETPROFILE=1 to override."
            )

        if not skip_setprofile:
            from .core.profiler import epochly_profile_hook
            sys.setprofile(epochly_profile_hook)
        else:
            # Log at DEBUG level to avoid noise, but record the skip
            import logging
            logging.getLogger('epochly').debug("EpochlyProfiler (sys.setprofile) disabled")

        # P0.25 FIX (Jan 2026): Core initialization is LAZY by default
        # for zero overhead.
        #
        # PREVIOUS BEHAVIOR (line 480 had: should_initialize_now = True):
        # - auto_enable() always called _ensure_core_initialized()
        # - This spawned 9-17 background threads (PerformanceMonitor, JIT workers, etc.)
        # - These threads caused ~98% overhead via GIL contention
        # - Even workloads that can't benefit from Epochly paid this penalty
        #
        # NEW BEHAVIOR:
        # - auto_enable() installs lightweight hooks only (import hook, sys.monitoring)
        # - Core initializes LAZILY when first API function is called
        # - No background threads until actually needed
        # - Workloads that don't use Epochly APIs pay near-zero overhead
        #
        # BACKWARD COMPATIBILITY:
        # - Set EPOCHLY_EAGER_INIT=1 to force immediate initialization
        # - Decorated functions (@epochly.optimize) trigger lazy init when applied
        # - Context managers trigger lazy init when entered
        # - force=True parameter still forces immediate initialization
        #
        # NOTEBOOK SUPPORT:
        # - Notebooks that call auto_enable() still work - they just get lazy init
        # - First use of @epochly.optimize or epochly.set_level() triggers core init
        # - This is BETTER for notebooks - faster startup, less overhead
        dev_bypass_active = _has_valid_dev_bypass()
        should_initialize_now = (
            force
            or dev_bypass_active
            or _config_resolver.env_truthy(_config_resolver.ENV_EAGER_INIT)
        )

        # Re-check environment at call time (not import time) for correct test behavior
        # Note: should_initialize_now (force or EPOCHLY_EAGER_INIT=1) overrides skip_init
        # This allows explicit eager init to work even in test mode
        auto_init_disabled = (
            _config_resolver.env_get(_config_resolver.ENV_DISABLE_AUTO_INIT, '').lower()
            in ('1', 'true', 'yes', 'on')
        )
        skip_init_requested = (
            auto_init_disabled
            or _config_resolver.env_truthy(_config_resolver.ENV_TEST_MODE)
        )
        skip_init = (not should_initialize_now) and skip_init_requested

    # CRITICAL: Perform initialization OUTSIDE the lock to prevent deadlock
    # _ensure_core_initialized() acquires _init_lock internally, so we can't hold it here
    if should_initialize_now and not skip_init:
        # Force immediate initialization (old behavior for backward compatibility)
        core = _ensure_core_initialized()
        if core is not None:
            _set_lifecycle_state(
                initialized=getattr(core, '_initialized', False),
                enabled=getattr(core, 'enabled', False),
                current_level=getattr(core, 'current_level', None),
            )

        # Wire profiler to existing ML/RNN system
        from .core.profiler import get_global_profiler
        profiler = get_global_profiler()
        if profiler and core:
            try:
                # Connect to adaptive orchestrator if available
                if hasattr(core, '_adaptive_orchestrator'):
                    profiler._adaptive_orchestrator = core._adaptive_orchestrator

                # Connect to JIT analyzer if available
                if hasattr(core, '_jit_manager'):
                    jit_manager = core._jit_manager
                    if hasattr(jit_manager, '_jit_analyzer'):
                        profiler._jit_analyzer = jit_manager._jit_analyzer

                # Connect to workload detector if available
                if hasattr(core, 'plugin_manager'):
                    plugins = core.plugin_manager.get_plugin('workload_detector')
                    if plugins:
                        profiler._workload_detector = plugins
            except Exception:
                # Silently fail - profiler will work in standalone mode
                pass
    # else: Lazy initialization - core will be initialized on first API call

    # CRITICAL FIX (Apr 2026): Only import IPython support in actual IPython
    # runtimes. A normal CLI subprocess should not pull in the entire IPython
    # stack (~35-40MB RSS) just to discover that no notebook kernel is active.
    if 'IPython' in sys.modules:
        try:
            from .profiling.source_extractor import SourceExtractor
            SourceExtractor.install_ipython_hook()
        except Exception:
            pass  # Silently fail if not in IPython/Jupyter

    # ISSUE #8 FOLLOW-UP (Apr 2026): Lazy auto_enable() must not spend the
    # Level-0 memory budget on speculative capability warmup. If the caller
    # explicitly forced eager initialization we can still schedule preflight,
    # but lazy L0 monitoring must stay cold until a real optimization surface
    # demands the core.
    if should_initialize_now and not skip_init and _core_singleton is not None:
        _schedule_background_preflight()


def _schedule_background_preflight():
    """
    Schedule low-priority background preflight task for capability detection.

    ISSUE #8 FIX (perf_fixes4.md): Pre-detect capabilities so first call hits warmed components.
    """
    import threading

    def preflight_task():
        try:
            import time
            time.sleep(2.0)  # Wait to not interfere with startup

            # Detect subinterpreter availability
            try:
                import sys
                if sys.version_info >= (3, 12):
                    try:
                        __import__("_xxsubinterpreters")
                        logger.debug("Preflight: _xxsubinterpreters available")
                    except ImportError:
                        logger.debug("Preflight: _xxsubinterpreters not available")
            except Exception:
                pass

            # Detect GPU availability
            try:
                from .gpu.gpu_detector import GPUDetector
                detector = GPUDetector()
                gpu_info = detector.detect_gpu()
                if gpu_info.get('available'):
                    logger.debug(
                        "Preflight: GPU available - "
                        f"{gpu_info.get('device_name')}"
                    )
                else:
                    logger.debug("Preflight: No GPU detected")
            except Exception:
                pass

            # Detect NUMA topology
            try:
                from .numa import NumaManager
                numa = NumaManager()
                node_count = numa.get_node_count()
                logger.debug(f"Preflight: {node_count} NUMA nodes detected")
            except Exception:
                pass

            # perf_fixes5.md Finding #6: Fast allocator health probe
            try:
                from .memory.allocator_health_probe import probe_fast_allocator, is_fast_allocator_enabled
                available, latency_us, message = probe_fast_allocator()
                logger.debug(f"Preflight: Allocator probe - {message}")

                # Gap #2: Expose allocator health to orchestrator
                core = _core_singleton
                if core and hasattr(core, '_adaptive_orchestrator') and core._adaptive_orchestrator:
                    try:
                        # Record allocator health metric
                        orchestrator = core._adaptive_orchestrator
                        if hasattr(orchestrator, '_memory_profiler') and orchestrator._memory_profiler:
                            orchestrator._memory_profiler.record_allocation(
                                size=0,  # Metadata only
                                address=None,
                                thread_id=None
                            )
                        logger.debug(
                            f"Allocator health exposed to orchestrator: "
                            f"enabled={is_fast_allocator_enabled()}, latency={latency_us:.1f}us"
                        )
                    except Exception:
                        pass
            except Exception as e:
                logger.debug(f"Preflight: Allocator probe failed - {e}")

            # ENHANCEMENT (perf_fixes5.md Issue E): Prime JIT cache with hot functions
            try:
                # Get core to access JIT manager
                core = _core_singleton
                if core and hasattr(core, '_jit_manager') and core._jit_manager:
                    jit_manager = core._jit_manager

                    # Check if telemetry store has hot function data
                    if hasattr(jit_manager, '_telemetry_store') and jit_manager._telemetry_store:
                        telemetry = jit_manager._telemetry_store

                        # Get top N hot functions from previous runs
                        try:
                            hot_functions = telemetry.get_top_functions(limit=10)
                            if hot_functions:
                                logger.debug(f"Preflight: Priming JIT cache with {len(hot_functions)} hot functions")
                                # The actual prewarming is already handled by _schedule_prewarm_pass()
                                # This just logs that we could do it
                        except Exception:
                            pass
            except Exception:
                pass

            # ENHANCEMENT (perf_fixes5.md Issue E): Pre-size memory pools
            try:
                core = _core_singleton
                if core:
                    # Check if we have workload characteristics from previous runs
                    if hasattr(core, '_adaptive_orchestrator') and core._adaptive_orchestrator:
                        orchestrator = core._adaptive_orchestrator
                        try:
                            summary = orchestrator.get_performance_summary()
                            if summary:
                                avg_data_size = summary.get('avg_data_size', 0)
                                if avg_data_size > 0:
                                    logger.debug(f"Preflight: Historical avg data size: {avg_data_size // 1024}KB")
                                    # Pre-sizing happens in _calculate_adaptive_pool_size() during Level 3 init
                        except Exception:
                            pass
            except Exception:
                pass

            logger.debug("Preflight capability detection complete (enhanced with JIT/pool heuristics)")

        except Exception as e:
            logger.debug(f"Preflight failed: {e}")

    # Schedule as low-priority daemon thread
    preflight_thread = threading.Thread(target=preflight_task, daemon=True, name="Epochly-Preflight")
    try:
        from epochly.core.thread_registry import register_thread as _reg_thread
        _preflight_stop = threading.Event()
        _reg_thread(preflight_thread, stop_callback=_preflight_stop.set, name="Epochly-Preflight")
    except ImportError:
        pass
    preflight_thread.start()


# ============================================================================
# Additional Decorator API Functions (Lazy Wrappers)
# ============================================================================
# These decorators are documented in user-guide/decorators.md and must be
# accessible directly from the epochly module (e.g., @epochly.performance_monitor)
# ============================================================================

def performance_monitor(func=None):
    """
    Decorator to monitor function performance without optimization.

    Lazy import wrapper that defers module loading until decorator application.
    Ensures core is initialized before applying the decorator.

    This is equivalent to @epochly.optimize(level=0) - monitoring only.

    Args:
        func: The function to monitor (when used without parentheses)

    Returns:
        Decorated function with performance monitoring applied

    Example:
        @epochly.performance_monitor
        def my_function():
            pass

        # Or with parentheses
        @epochly.performance_monitor()
        def my_function():
            pass
    """
    _ensure_core_initialized()
    from .api.decorators import performance_monitor as _performance_monitor

    if func is not None:
        # Called without parentheses: @epochly.performance_monitor
        return _performance_monitor(func)
    else:
        # Called with parentheses: @epochly.performance_monitor()
        return _performance_monitor


def jit_compile(func=None):
    """
    Decorator to apply JIT compilation to a function.

    Lazy import wrapper that defers module loading until decorator application.
    Ensures core is initialized before applying the decorator.

    This is equivalent to @epochly.optimize(level=2) - JIT compilation.

    Args:
        func: The function to JIT compile (when used without parentheses)

    Returns:
        Decorated function with JIT compilation applied

    Example:
        @epochly.jit_compile
        def compute_intensive():
            pass
    """
    _ensure_core_initialized()
    from .api.decorators import jit_compile as _jit_compile

    if func is not None:
        # Called without parentheses: @epochly.jit_compile
        return _jit_compile(func)
    else:
        # Called with parentheses: @epochly.jit_compile()
        return _jit_compile


def full_optimize(func=None):
    """
    Decorator to apply full optimization to a function.

    Lazy import wrapper that defers module loading until decorator application.
    Ensures core is initialized before applying the decorator.

    Requests the highest available optimization level, but respects the
    system-wide level setting (including EPOCHLY_LEVEL environment variable).
    When no cap is set, the system aims for Level 3 (full parallelism).

    CRITICAL FIX (Feb 2026): No longer hardcodes Level 3. Now respects
    EPOCHLY_LEVEL env var cap to prevent hangs in restricted environments.

    Args:
        func: The function to optimize (when used without parentheses)

    Returns:
        Decorated function with full optimization applied

    Example:
        @epochly.full_optimize
        def parallel_work():
            pass
    """
    _ensure_core_initialized()
    from .api.decorators import full_optimize as _full_optimize

    if func is not None:
        # Called without parentheses: @epochly.full_optimize
        return _full_optimize(func)
    else:
        # Called with parentheses: @epochly.full_optimize()
        return _full_optimize


def threading_optimize(func=None, *, max_workers=None, thread_pool=True):
    """
    Decorator to apply threading optimization (Level 1) to a function.

    Lazy import wrapper that defers module loading until decorator application.
    Ensures core is initialized before applying the decorator.

    This is equivalent to @epochly.optimize(level=1) - threading for I/O.

    Args:
        func: The function to optimize (when used without parentheses)
        max_workers: Maximum number of worker threads
        thread_pool: Whether to use thread pool (default: True)

    Returns:
        Decorated function with threading optimization applied

    Example:
        @epochly.threading_optimize
        def io_heavy_work():
            pass

        @epochly.threading_optimize(max_workers=8)
        def custom_threading():
            pass
    """
    _ensure_core_initialized()
    from .api.decorators import threading_optimize as _threading_optimize

    if func is not None:
        # Called without parentheses: @epochly.threading_optimize
        return _threading_optimize()(func)
    else:
        # Called with parentheses: @epochly.threading_optimize(max_workers=8)
        return _threading_optimize(max_workers=max_workers, thread_pool=thread_pool)


# ============================================================================
# Additional Context Manager API Functions (Lazy Wrappers)
# ============================================================================
# These context managers are documented in user-guide/context-managers.md and
# must be accessible directly from the epochly module.
# ============================================================================

def monitoring_context(enable=True, reset_on_exit=False):
    """
    Context manager for performance monitoring without optimization.

    Lazy import wrapper that defers module loading until context creation.
    Ensures core is initialized before creating the context manager.

    This is equivalent to optimize_context(level=0) - monitoring only.

    Args:
        enable: Whether to enable monitoring (default: True)
        reset_on_exit: Whether to reset metrics on exit (default: False)

    Returns:
        Context manager for performance monitoring

    Example:
        with epochly.monitoring_context() as metrics:
            # Code to monitor
            pass
        print(metrics)
    """
    _ensure_core_initialized()
    from .api.context_managers import monitoring_context as _monitoring_context
    return _monitoring_context(enable=enable, reset_on_exit=reset_on_exit)


def jit_context(**options):
    """
    Context manager for JIT compilation (Level 2).

    Lazy import wrapper that defers module loading until context creation.
    Ensures core is initialized before creating the context manager.

    This is equivalent to optimize_context(level=2) - JIT compilation.

    Args:
        **options: Additional JIT options

    Returns:
        Context manager for JIT optimization

    Example:
        with epochly.jit_context():
            # Numerical code to JIT compile
            pass
    """
    _ensure_core_initialized()
    from .api.context_managers import jit_context as _jit_context
    return _jit_context(**options)


def threading_context(max_workers=None, thread_pool=True, **options):
    """
    Context manager for threading optimization (Level 1).

    Lazy import wrapper that defers module loading until context creation.
    Ensures core is initialized before creating the context manager.

    This is equivalent to optimize_context(level=1) - threading for I/O.

    Args:
        max_workers: Maximum number of worker threads
        thread_pool: Whether to use thread pool (default: True)
        **options: Additional threading options

    Returns:
        Context manager for threading optimization

    Example:
        with epochly.threading_context(max_workers=8):
            # I/O-bound code
            pass
    """
    _ensure_core_initialized()
    from .api.context_managers import threading_context as _threading_context
    return _threading_context(max_workers=max_workers, thread_pool=thread_pool, **options)


def full_optimize_context(level=None, **options):
    """
    Context manager for scoped optimization with an optional level request.

    Lazy import wrapper that defers module loading until context creation.
    Ensures core is initialized before creating the context manager.

    Args:
        level: Optional enhancement level request. ``None`` preserves the
            current auto-progression level.
        **options: Additional optimization options

    Returns:
        Context manager for full optimization

    Example:
        with epochly.full_optimize_context(level=4):
            # GPU-capable code
            pass
    """
    _ensure_core_initialized()
    from .api.context_managers import full_optimize_context as _full_optimize_context
    return _full_optimize_context(level=level, **options)


def benchmark_context(name="benchmark", print_results=True):
    """
    Context manager for benchmarking code blocks.

    Lazy import wrapper that defers module loading until context creation.
    Ensures core is initialized before creating the context manager.

    Args:
        name: Name for the benchmark (default: "benchmark")
        print_results: Whether to print results on exit (default: True)

    Returns:
        Context manager that yields a dict with timing information

    Example:
        with epochly.benchmark_context("my_operation") as timing:
            # Code to benchmark
            pass
        print(f"Elapsed: {timing['elapsed_ms']}ms")
    """
    _ensure_core_initialized()
    from .api.context_managers import benchmark_context as _benchmark_context
    return _benchmark_context(name=name, print_results=print_results)


def epochly_disabled_context():
    """
    Context manager to temporarily disable Epochly optimization.

    Lazy import wrapper that defers module loading until context creation.
    Ensures core is initialized before creating the context manager.

    Useful for debugging or when you need baseline Python behavior.

    Returns:
        Context manager that disables Epochly within the block

    Example:
        with epochly.epochly_disabled_context():
            # Code runs without Epochly optimization
            result = baseline_operation()
    """
    _ensure_core_initialized()
    from .api.context_managers import epochly_disabled_context as _epochly_disabled_context
    return _epochly_disabled_context()


# ============================================================================
# Additional Public API Functions (Lazy Wrappers)
# ============================================================================

def get_status(*args, **kwargs):
    """
    Get current Epochly status and statistics.

    Lazy import wrapper that defers module loading until first call.

    Returns:
        Dictionary containing status information
    """
    _materialize_deferred_lightweight_status()
    if _core_singleton is None and _lightweight_decorator_status is not None:
        lightweight_status = dict(_lightweight_decorator_status)
        last_call = lightweight_status.get('last_decorator_call')
        if isinstance(last_call, dict):
            lightweight_status['last_decorator_call'] = (
                _with_requested_level_backcompat(last_call)
            )
        return lightweight_status
    if _core_singleton is None and (_explicitly_enabled or _auto_enabled):
        # Keep get_status() side-effect free before the runtime has seen an
        # actual optimization surface. Initializing the core here wakes the
        # delayed-detection path and can leave Level-0 background threads
        # (capability detection, performance monitor, emergency detector,
        # heartbeat) running even though the effective route is still
        # LEVEL_0_MONITOR. Returning the lazy status preserves zero-overhead.
        return _build_lazy_enabled_status()

    core = _ensure_core_initialized()

    # If core is None (disabled or emergency disabled), return minimal status
    if core is None:
        import platform
        return {
            'enabled': False,
            'initialized': False,
            'enhancement_level': 'DISABLED',
            'python_version': f"{sys.version_info.major}.{sys.version_info.minor}",
            'platform': platform.system(),
            'emergency_disable': _is_runtime_emergency_active(),
            'emergency_metadata': _runtime_emergency_metadata(),
            'regular_disable': _config_resolver.env_truthy(_config_resolver.ENV_DISABLE),
        }

    from .api.public_api import get_status as _get_status
    return _get_status(*args, **kwargs)


# Backward compatibility: stats is an alias for get_status.
# P-001: This alias MUST NOT be shadowed by a later def stats().
stats = get_status


def get_config(*args, **kwargs):
    """
    Get current Epochly configuration.

    Lazy import wrapper for configuration access.

    Returns:
        Dictionary containing configuration
    """
    _ensure_core_initialized()
    try:
        from .api.public_api import get_config as _get_config
        return _get_config(*args, **kwargs)
    except (ImportError, AttributeError):
        # Fallback: return config from core
        core = _core_singleton
        if core and hasattr(core, 'config'):
            return core.config if not callable(core.config) else {}
        return {}


# Community tier defaults used as fallback for license API timeout/error.
# Must match LicenseEnforcer community tier values exactly.
_COMMUNITY_LICENSE_DEFAULTS = {
    'tier': 'community',
    'max_cores': 4,
    'gpu_enabled': False,
    'memory_limit_gb': 16,
    'features': ['basic_optimization', 'threading', 'memory_pooling']
}
_COMMUNITY_FEATURES = {'basic_optimization', 'threading', 'memory_pooling'}

# Circuit breaker: if license API times out, don't retry for 60s.
# This prevents thread accumulation from repeated timeout calls.
_license_circuit_open_until = 0.0

# Timeout for license API calls (seconds)
_LICENSE_API_TIMEOUT = 10.0

# Single-flight: track in-flight license query thread + shared result.
# Prevents spawning multiple threads when get_license_info() or check_feature()
# is called repeatedly while a previous call is still in-flight.
_license_inflight_lock = _threading.Lock()
_license_inflight_event = None  # _threading.Event when query in-flight
_license_inflight_result = None  # Result from in-flight query


def get_license_info(*args, **kwargs):
    """
    Get current license information.

    Includes timeout protection, circuit breaker, and single-flight suppression
    to prevent hanging and thread accumulation in offline/sandboxed environments.

    CRITICAL FIX (Feb 2026): Added timeout wrapper, fixed duplicate
    _ensure_core_initialized() call, and avoids calling _ensure_core_initialized()
    inside timeout thread (prevents deadlocking the global init lock).

    Returns:
        Dictionary containing license details (always a complete dict shape)
    """
    global _license_circuit_open_until, _license_inflight_event, _license_inflight_result
    import time as _time

    # Fast path: offline mode — return immediately without threads
    _offline = _config_resolver.env_get(_config_resolver.ENV_OFFLINE_MODE, '').strip().lower()
    if _offline in ('1', 'true', 'yes', 'on'):
        return dict(_COMMUNITY_LICENSE_DEFAULTS)

    # Circuit breaker: if we recently timed out, return cached defaults immediately
    if _time.monotonic() < _license_circuit_open_until:
        return dict(_COMMUNITY_LICENSE_DEFAULTS)

    # Single-flight: if another call is already in-flight, wait on its result
    with _license_inflight_lock:
        inflight_event = _license_inflight_event

    if inflight_event is not None:
        if inflight_event.wait(timeout=_LICENSE_API_TIMEOUT):
            result = _license_inflight_result
            if isinstance(result, dict):
                info = dict(_COMMUNITY_LICENSE_DEFAULTS)
                info.update(result)
                return info
        return dict(_COMMUNITY_LICENSE_DEFAULTS)

    # Use already-initialized core if available (avoids _init_lock deadlock).
    # Do NOT call _ensure_core_initialized() inside the timeout thread.
    core = _core_singleton
    if core and hasattr(core, 'get_license_info'):
        result_holder = [None]
        error_holder = [None]
        done_event = _threading.Event()

        # Register as in-flight
        with _license_inflight_lock:
            _license_inflight_event = done_event
            _license_inflight_result = None

        def _get_info():
            try:
                result_holder[0] = core.get_license_info()
            except Exception as e:
                error_holder[0] = e
            finally:
                done_event.set()

        t = _threading.Thread(target=_get_info, daemon=True, name='epochly-license-info')
        try:
            from epochly.core.thread_registry import register_thread as _reg_thread
            _reg_thread(t, stop_callback=done_event.set, name='epochly-license-info')
        except ImportError:
            pass
        t.start()

        try:
            if not done_event.wait(timeout=_LICENSE_API_TIMEOUT):
                logger.warning(
                    "get_license_info() timed out after %.0fs. "
                    "Returning community defaults. Set EPOCHLY_OFFLINE_MODE=1 "
                    "to avoid license server calls.",
                    _LICENSE_API_TIMEOUT
                )
                _license_circuit_open_until = _time.monotonic() + 60.0
                return dict(_COMMUNITY_LICENSE_DEFAULTS)

            if error_holder[0]:
                logger.debug("get_license_info() error: %s", error_holder[0])
                return dict(_COMMUNITY_LICENSE_DEFAULTS)

            # Merge core result into defaults to guarantee full dict shape
            info = dict(_COMMUNITY_LICENSE_DEFAULTS)
            if isinstance(result_holder[0], dict):
                info.update(result_holder[0])
                _license_inflight_result = info
            return info
        finally:
            with _license_inflight_lock:
                _license_inflight_event = None

    # Core not initialized — use license enforcer directly (lightweight)
    try:
        from .licensing.license_enforcer import get_license_limits
        result = get_license_limits()
        info = dict(_COMMUNITY_LICENSE_DEFAULTS)
        if isinstance(result, dict):
            info.update(result)
        return info
    except Exception:
        return dict(_COMMUNITY_LICENSE_DEFAULTS)


def check_feature(feature_name: str) -> bool:
    """
    Check if a feature is enabled under current license.

    Includes timeout protection and circuit breaker to prevent hanging in
    offline/sandboxed environments.

    CRITICAL FIX (Feb 2026): Added timeout wrapper. Avoids calling
    _ensure_core_initialized() inside timeout thread (prevents deadlock).
    Falls back to community feature set on timeout (not unconditional False).

    Args:
        feature_name: Name of feature to check

    Returns:
        True if feature is available (False if licensing system unavailable)
    """
    global _license_circuit_open_until
    import time as _time

    # Fast path: offline mode — return community defaults immediately
    _offline = _config_resolver.env_get(_config_resolver.ENV_OFFLINE_MODE, '').strip().lower()
    if _offline in ('1', 'true', 'yes', 'on'):
        return feature_name in _COMMUNITY_FEATURES

    # Circuit breaker: if we recently timed out, return community defaults
    if _time.monotonic() < _license_circuit_open_until:
        return feature_name in _COMMUNITY_FEATURES

    # Use already-initialized core if available (avoids _init_lock deadlock)
    core = _core_singleton
    if core and hasattr(core, 'check_feature'):
        result_holder = [False]
        done_event = _threading.Event()

        def _check():
            try:
                result_holder[0] = core.check_feature(feature_name)
            except Exception:
                result_holder[0] = feature_name in _COMMUNITY_FEATURES
            finally:
                done_event.set()

        t = _threading.Thread(target=_check, daemon=True, name='epochly-check-feature')
        try:
            from epochly.core.thread_registry import register_thread as _reg_thread
            _reg_thread(t, stop_callback=done_event.set, name='epochly-check-feature')
        except ImportError:
            pass
        t.start()

        if not done_event.wait(timeout=_LICENSE_API_TIMEOUT):
            logger.warning(
                "check_feature('%s') timed out after %.0fs. "
                "Returning community default. Set EPOCHLY_OFFLINE_MODE=1 "
                "to avoid license server calls.",
                feature_name, _LICENSE_API_TIMEOUT
            )
            _license_circuit_open_until = _time.monotonic() + 60.0
            return feature_name in _COMMUNITY_FEATURES

        return result_holder[0]

    # Core not initialized — use license enforcer directly
    try:
        from .licensing.license_enforcer import check_feature as _check_feature
        return _check_feature(feature_name)
    except (ImportError, AttributeError):
        return feature_name in _COMMUNITY_FEATURES
    except Exception:
        return feature_name in _COMMUNITY_FEATURES


def set_level(level: int):
    """
    Set enhancement level.

    Args:
        level: Enhancement level (0-4)
            0 = Monitor only (baseline)
            1 = Threading optimizations
            2 = JIT compilation
            3 = Full optimization (parallel processing)
            4 = GPU acceleration (if available)

    Note:
        Public level requests flow through the normal progression gate. If GPU is
        unavailable for level 4, Epochly falls back to Level 3 after validation.
    """
    _ensure_core_initialized()
    core = _ensure_core_initialized()
    if core and hasattr(core, 'set_enhancement_level'):
        # Convert int to EnhancementLevel enum
        from .core.epochly_core import EnhancementLevel
        level_map = {
            0: EnhancementLevel.LEVEL_0_MONITOR,
            1: EnhancementLevel.LEVEL_1_THREADING,
            2: EnhancementLevel.LEVEL_2_JIT,
            3: EnhancementLevel.LEVEL_3_FULL,
            4: EnhancementLevel.LEVEL_4_GPU,
        }
        if level not in level_map:
            raise ValueError(f"Invalid level {level}. Must be 0-4.")
        enum_level = level_map[level]

        # Public set_level() must respect the normal progression gate.
        # Internal rollback and diagnostic paths use dedicated private APIs.
        result = core.set_enhancement_level(enum_level)

        # RCA (Dec 2025): For JIT levels (2+), wait for JIT to be ready.
        # This prevents the erratic timing bug where is_enabled()=False but level=3,
        # causing inconsistent JIT application across runs.
        # Skip in test mode — QEMU aarch64 emulation is ~10x slower and
        # the wait_for_level timeout (15s) can cause CI timeouts (exit 124).
        _test_mode = _config_resolver.env_truthy(_config_resolver.ENV_TEST_MODE)
        if level >= 2 and result and not _test_mode:
            # FIX (Mar 2026): For level 4, short-circuit the JIT warmup wait if GPU
            # is not available. On GPU-less systems, set_level(4) falls back to L3
            # immediately, but we were still waiting 15s for the GPU JIT readiness
            # event that will never fire. Detect no-GPU early and skip the wait.
            skip_wait = False
            if level == 4:
                try:
                    from epochly.gpu import is_gpu_available
                    if not is_gpu_available():
                        skip_wait = True
                except ImportError:
                    skip_wait = True

            if not skip_wait:
                # Wait for JIT system to be actually ready
                # Level 3+ needs more time for ProcessPool spawn (~8s on macOS)
                timeout = 15.0 if level >= 3 else 10.0
                if hasattr(core, 'wait_for_level'):
                    jit_ready = core.wait_for_level(enum_level, timeout=timeout)
                    if not jit_ready:
                        import logging
                        logging.getLogger('epochly').warning(
                            f"Timeout waiting for level {level} JIT to be ready after {timeout}s. "
                            f"Performance may be inconsistent."
                        )

        # RCA (Dec 2025): Warn if enabled=False after setting level
        if not core.enabled:
            import logging
            reason = getattr(core, '_disabled_reason', 'unknown')
            logging.getLogger('epochly').error(
                f"EPOCHLY DISABLED after set_level({level}): {reason}. "
                f"JIT acceleration will NOT work. Check initialization logs."
            )


def get_level() -> int:
    """
    Get current enhancement level.

    Returns:
        Current enhancement level (0-4):
            0 = Monitor only (baseline)
            1 = Threading optimizations
            2 = JIT compilation
            3 = Full optimization (parallel processing)
            4 = GPU acceleration
    """
    core = _ensure_core_initialized()
    if core and hasattr(core, 'get_enhancement_level'):
        level = core.get_enhancement_level()
        # Return the integer value of the enum
        return level.value if hasattr(level, 'value') else int(level)
    return 0


def is_enabled() -> bool:
    """
    Check if Epochly is currently enabled.

    Returns:
        True if Epochly is enabled

    RCA (Dec 2025): Fixed order of checks to prevent race condition.
    Previously, EPOCHLY_DISABLE was checked first, but this env var is
    temporarily set during background worker spawn (to prevent fork bomb).
    This caused is_enabled() to return False during the ~8s spawn window,
    breaking JIT application and causing erratic performance.

    The fix: Check core.enabled first. If the core exists and is enabled,
    trust that state. Only use env var checks for worker isolation (when
    core doesn't exist or isn't enabled).

    IMPORTANT: EPOCHLY_EMERGENCY_DISABLE always takes precedence - it's
    designed for emergency situations where we need to immediately disable
    regardless of core state.
    """
    # EMERGENCY_DISABLE always wins - must be checked FIRST.
    # The legacy EPOCHLY_EMERGENCY_DISABLE contract is preserved through the
    # detector accessors rather than direct env reads here.
    if _is_runtime_emergency_active():
        return False

    # RCA FIX: Check already-initialized core state next - this is the
    # authoritative source and avoids forcing lazy enable() to bootstrap.
    core = _core_singleton
    if core and hasattr(core, 'enabled'):
        # Core exists - trust its enabled state
        # This handles the race condition where EPOCHLY_DISABLE=1 is
        # temporarily set during ProcessPool spawn but core.enabled=True
        return core.enabled

    _materialize_deferred_lightweight_status()
    if _lightweight_decorator_status is not None:
        return True
    if _explicitly_enabled and not _config_resolver.env_truthy(_config_resolver.ENV_DISABLE):
        return True

    # No lightweight state — fall back to lazy init if needed.
    core = _ensure_core_initialized()
    if core and hasattr(core, 'enabled'):
        return core.enabled

    # No core exists - fall back to env var checks
    # This is the worker isolation case: workers inherit EPOCHLY_DISABLE=1
    # and should not initialize Epochly (prevents fork bomb)
    if _config_resolver.env_truthy(_config_resolver.ENV_DISABLE):
        return False

    return False


def get_metrics(*args, **kwargs):
    """
    Get performance metrics.

    Lazy import wrapper for metrics collection.

    Returns:
        Dictionary containing metrics
    """
    _materialize_deferred_lightweight_status()
    if _core_singleton is None and _lightweight_decorator_status is not None:
        lightweight_metrics = _build_lightweight_metrics()
        if lightweight_metrics is not None:
            return lightweight_metrics
    if _core_singleton is None and _explicitly_enabled:
        return {
            "enabled": True,
            "level": _get_lazy_enabled_level_name(),
            "uptime_seconds": 0.0,
            "functions_analyzed": 0,
            "functions_optimized": 0,
            "functions_skipped": 0,
            "estimated_speedup_pct": 0.0,
            "memory_used_mb": _get_process_memory_mb(),
            "compilation_queue_pending": 0,
        }

    _ensure_core_initialized()
    from .api.public_api import get_metrics as _get_metrics
    return _get_metrics(*args, **kwargs)


def shutdown():
    """
    Shut down Epochly system.

    Lazy import wrapper for shutdown.
    """
    _teardown_runtime()


def enable():
    """
    Enable Epochly optimization.

    Initializes Epochly core if not already initialized.
    If Epochly was previously disabled (but not emergency-disabled),
    re-enables optimization.

    EPOCHLY_EMERGENCY_DISABLE always takes precedence — if set, enable()
    is a no-op. Use process restart to clear emergency state.

    This is the counterpart to :func:`disable`.

    Example:
        import epochly

        epochly.enable()   # Turn on optimization
        # ... optimized code ...
        epochly.disable()  # Turn off optimization
    """
    # Emergency disable ALWAYS wins — cannot be overridden by enable()
    if _is_runtime_emergency_active():
        return

    global _explicitly_enabled, _enable_requires_force_reinit

    # enable() always clears EPOCHLY_DISABLE — that's the public API contract.
    # Worker processes (ProcessPool init) set BOTH EPOCHLY_DISABLE=1 AND
    # EPOCHLY_DISABLE_INTERCEPTION=1. In that case, enable() should not
    # override the worker isolation — the process is a child worker.
    with _init_lock:
        force_reinit = _enable_requires_force_reinit
        _enable_requires_force_reinit = False
        if _config_resolver.env_truthy(_config_resolver.ENV_DISABLE):
            if _config_resolver.env_truthy(_config_resolver.ENV_DISABLE_INTERCEPTION):
                # Worker process — both flags set by Epochly internals.
                # Do not override worker isolation.
                _enable_requires_force_reinit = force_reinit
                return
            # User-set disable — enable() explicitly overrides it per API contract
            _config_resolver.clear_process_env(_config_resolver.ENV_DISABLE)
        _explicitly_enabled = True

        from .core.epochly_core import _set_globally_disabled
        _set_globally_disabled(False)
        _set_lifecycle_state(enabled=True, shutdown=False)

    # Fresh enable() stays lazy so background detection does not pre-spawn
    # Level 3 workers. Re-enable after disable can still force full runtime
    # restoration when the prior disable tore down active Epochly state.
    auto_enable(force=force_reinit)

    core = _core_singleton
    if force_reinit and core is None:
        core = _ensure_core_initialized()
    if core is not None:
        core.enabled = True
        _set_lifecycle_state(
            initialized=getattr(core, '_initialized', False),
            enabled=getattr(core, 'enabled', False),
            current_level=getattr(core, 'current_level', None),
        )


def metrics() -> dict:
    """
    Get user-friendly optimization metrics.

    Returns a dictionary showing what Epochly has optimized, estimated
    performance improvement, and resource usage. Call anytime — returns
    immediately with whatever data is available.

    Note: ``epochly.stats()`` is an alias for ``epochly.get_status()`` and
    returns the full internal status dict. Use ``epochly.metrics()`` for
    the user-friendly summary.

    Returns:
        dict: Optimization metrics including functions_optimized,
              estimated_speedup_pct, memory_used_mb, uptime_seconds, etc.

    Example:
        import epochly
        epochly.enable()
        # ... run workload ...
        print(epochly.metrics())
        # {"enabled": True, "functions_optimized": 3, ...}
    """
    _materialize_deferred_lightweight_status()
    if _core_singleton is None and _lightweight_decorator_status is not None:
        lightweight_metrics = _build_lightweight_metrics()
        if lightweight_metrics is not None:
            return dict(lightweight_metrics)
    if _core_singleton is None and _explicitly_enabled:
        return {
            "enabled": True,
            "level": _get_lazy_enabled_level_name(),
            "uptime_seconds": 0.0,
            "functions_analyzed": 0,
            "functions_optimized": 0,
            "functions_skipped": 0,
            "estimated_speedup_pct": 0.0,
            "memory_used_mb": _get_process_memory_mb(),
            "compilation_queue_pending": 0,
        }

    core = _ensure_core_initialized()
    if core is None:
        if _explicitly_enabled:
            return {"enabled": True}
        return {"enabled": False}
    try:
        return core.get_user_stats()
    except Exception:
        return {"enabled": False, "error": "metrics unavailable"}


def disable():
    """
    Disable Epochly optimization.

    Disables all Epochly optimization while keeping the core initialized.
    Use :func:`enable` to re-enable. For production emergencies, use
    :func:`emergency_disable` instead (which also sets environment flags
    to prevent re-initialization).

    Thread-safe: protected by _init_lock.

    PR #42 FIX: Now sets _globally_disabled flag to gate Level 2/3 fast paths
    in public_api.py that previously bypassed core.enabled. Also handles the
    pre-init case where _core_singleton is None.

    Example:
        import epochly

        epochly.disable()  # Turn off optimization
        # ... baseline Python code ...
        epochly.enable()   # Turn it back on
    """
    global _explicitly_enabled, _enable_requires_force_reinit
    from .core.epochly_core import _set_globally_disabled

    with _init_lock:
        should_force_reinit = (
            _core_singleton is not None
            or _auto_enabled
            or _import_hook_installed
            or hasattr(sys, '_epochly_initialized')
        )
        _explicitly_enabled = False

    _teardown_runtime(clear_disable_env=False)
    _enable_requires_force_reinit = should_force_reinit
    # disable() should leave the runtime fully off until the public enable()
    # API is called again. The module-level disabled flag now blocks lazy
    # re-initialization without mutating process-wide environment state.
    _set_globally_disabled(True)


def emergency_disable():
    """
    Emergency disable Epochly for production incidents.

    This function immediately disables Epochly optimization and returns
    the system to baseline Python behavior. Useful for production emergencies
    where Epochly may be causing issues.
    """
    global _core_singleton, _explicitly_enabled

    # Set emergency disable flag
    _config_resolver.set_process_env(_config_resolver.ENV_EMERGENCY_DISABLE, "1")
    _explicitly_enabled = False

    # RCA (Dec 2025): Set disabled reason for diagnostics before shutdown
    if _core_singleton:
        # PR #42 FIX: Also set global disabled flag for fast-path gating
        from .core.epochly_core import _set_globally_disabled
        _set_globally_disabled(True)
        _core_singleton._disabled_reason = "Emergency disable via API"
        _core_singleton.enabled = False
        try:
            _core_singleton.shutdown()
        except Exception:
            pass  # Best effort shutdown
        _core_singleton = None


def get_core():
    """
    Get the Epochly core instance.

    P1 WARMUP OPTIMIZATION (Jan 2026): Provides access to the core for
    eager_mode tests and advanced users who need direct core access.

    Returns:
        EpochlyCore: The core instance, or None if not initialized
    """
    global _core_singleton
    if _core_singleton is None and (_explicitly_enabled or _auto_enabled):
        core = _ensure_core_initialized()
        if core is not None:
            _schedule_background_preflight()
        return core
    return _core_singleton


def _get_inference_detector():
    """Bootstrap inference detection so wrap(model) works as a single call."""
    from .inference.detector import InferenceDetector

    detector = InferenceDetector.instance()

    for framework_name in ("transformers", "onnxruntime", "torch"):
        framework_module = sys.modules.get(framework_name)
        if framework_module is None:
            continue
        if detector.is_framework_detected(framework_name):
            continue
        detector.on_framework_imported(framework_name, framework_module)

    return detector


def _ensure_inference_import_hook():
    """Install the import hook lazily for future framework imports."""
    from .core.import_hook import EpochlyImportHook, get_import_hook

    hook = get_import_hook()
    if hook is None:
        sys.meta_path.insert(0, EpochlyImportHook())


def _raise_wrap_unsupported_model(model):
    """Raise a clear compatibility error for unsupported wrap() inputs."""
    from .utils.exceptions import EpochlyCompatibilityError

    model_name = type(model).__name__ if model is not None else "NoneType"
    supported = (
        "torch.nn.Module, transformers.Pipeline, "
        "transformers.PreTrainedModel, onnxruntime.InferenceSession"
    )
    raise EpochlyCompatibilityError(
        f"epochly.wrap() expects a supported model instance, got {model_name}. "
        f"Supported: {supported}",
        requirement=supported,
        current=model_name,
    )


def wrap(model):
    """
    Wrap a model instance in an InferenceProxy for profiling.

    This is the explicit model registration contract:
    - ``import epochly`` gives framework detection only (via import hooks)
    - ``epochly.wrap(model)`` gives per-call profiling (L0b)

    Optimization routing (L1+) will be activated automatically when
    the InferenceOptimizer is wired in a future release.

    Usage::

        import epochly
        model = MyModel().to("cuda").eval()   # configure model FIRST
        model = epochly.wrap(model)            # wrap LAST

        # In serving handler:
        result = model(input_tensor)           # goes through proxy
        original = model.unwrapped             # access raw model

    IMPORTANT -- wrap-last rule:
    The proxy delegates attribute access to the wrapped model, but
    fluent PyTorch methods (``.to()``, ``.eval()``, ``.half()``, ``.compile()``)
    return the raw model, not the proxy. If you call ``model.to("cuda")`` AFTER
    wrapping, you get the raw Module back and lose the proxy.

    Args:
        model: A model instance from a supported framework:
            - ``torch.nn.Module``
            - ``transformers.Pipeline``
            - ``transformers.PreTrainedModel``
            - ``onnxruntime.InferenceSession``

    Returns:
        InferenceProxy wrapping the model for profiling and optimization.

    Raises:
        EpochlyCompatibilityError: If model is not from a supported framework.
    """
    detector = _get_inference_detector()
    adapter = detector.get_adapter_for(model)
    if adapter is None:
        _raise_wrap_unsupported_model(model)

    # Create profiler for L0b per-call profiling
    # Use module-level singletons for profiler and safety
    profiler = _get_inference_profiler()
    safety = _get_safety_orchestrator()
    _ensure_inference_import_hook()

    # Wire golden capture callback so profiler feeds the safety system
    profiler.set_golden_callback(safety.capture_golden)

    proxy = adapter.wrap_forward(
        model,
        profiler=profiler,
        passthrough_when_no_optimizer=True,
    )
    detector.register_model(model)
    return proxy


# Module-level singletons for inference profiler and safety orchestrator
_inference_profiler = None
_inference_profiler_lock = _threading.Lock()
_safety_orchestrator = None
_safety_orchestrator_lock = _threading.Lock()


def _build_safety_orchestrator():
    """Construct the real SafetyOrchestrator on first actual use."""
    from .inference.safety.safety_orchestrator import SafetyOrchestrator
    from .inference.safety.privacy import (
        InputRedactor, AuditLogger,
    )
    # Load privacy config from environment
    redact_patterns_str = _config_resolver.env_get(
        _config_resolver.ENV_INFERENCE_PRIVACY_REDACT_PATTERNS, ""
    )
    patterns = [p for p in redact_patterns_str.split(",") if p.strip()]
    redactor = InputRedactor(patterns) if patterns else None
    audit_enabled = _config_resolver.env_get(
        _config_resolver.ENV_INFERENCE_PRIVACY_AUDIT_LOG_ENABLED, "true"
    ).lower() in ("true", "1", "yes")
    audit_logger = AuditLogger() if audit_enabled else None
    return SafetyOrchestrator(
        redactor=redactor,
        audit_logger=audit_logger,
    )


class _LazySafetyOrchestrator:
    """Defer importing the heavy safety stack until it is actually needed."""

    __slots__ = ("_delegate", "_lock")

    def __init__(self):
        self._delegate = None
        self._lock = _threading.Lock()

    def _get_delegate(self):
        delegate = self._delegate
        if delegate is not None:
            return delegate

        with self._lock:
            delegate = self._delegate
            if delegate is None:
                delegate = _build_safety_orchestrator()
                self._delegate = delegate
        return delegate

    def capture_golden(self, *args, **kwargs):
        return self._get_delegate().capture_golden(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._get_delegate(), name)


def _get_inference_profiler():
    """Get or create the singleton InferenceProfiler."""
    global _inference_profiler
    if _inference_profiler is None:
        with _inference_profiler_lock:
            if _inference_profiler is None:
                from .inference.profiler import InferenceProfiler
                _inference_profiler = InferenceProfiler()
    return _inference_profiler


def _get_safety_orchestrator():
    """Get or create the singleton safety orchestrator wrapper."""
    global _safety_orchestrator
    if _safety_orchestrator is None:
        with _safety_orchestrator_lock:
            if _safety_orchestrator is None:
                _safety_orchestrator = _LazySafetyOrchestrator()
    return _safety_orchestrator


def gpu_available():
    """
    Check if GPU acceleration is available.

    Returns:
        bool: True if GPU is available and can be used
    """
    try:
        from .gpu import gpu_available as _gpu_available
        return _gpu_available()
    except ImportError:
        return False
    except Exception:
        return False


def is_gpu_available():
    """Backward-compatible alias for gpu_available()."""
    return gpu_available()


def gpu_status_reason():
    """Return the current user-facing GPU availability reason."""
    try:
        from .gpu import gpu_status_reason as _gpu_status_reason
        return _gpu_status_reason()
    except ImportError:
        return 'Epochly GPU module is not available'
    except Exception as exc:
        return f'GPU status unavailable: {exc}'


def get_gpu_info():
    """
    Get information about available GPU(s).

    Returns:
        dict or None: GPU information dictionary, or None if no GPU available
    """
    try:
        from .gpu import get_gpu_info as _get_gpu_info
        info = _get_gpu_info()
        # Convert GPUInfo dataclass to dict for documented API
        if info is None:
            return None
        if hasattr(info, '__dict__'):
            # Dataclass or similar object
            result = {}
            for key, value in vars(info).items():
                # Convert enum values to strings
                if hasattr(value, 'value'):
                    result[key] = value.value
                else:
                    result[key] = value
            return result
        elif isinstance(info, dict):
            return info
        else:
            return None
    except ImportError:
        return None
    except Exception:
        return None


def load_ipython_extension(ipython):
    """Register Epochly Jupyter magics for `%load_ext epochly`."""
    from .jupyter import load_ipython_extension as _load_ipython_extension

    return _load_ipython_extension(ipython)


def unload_ipython_extension(ipython):
    """Unregister Epochly Jupyter magics for `%unload_ext epochly`."""
    from .jupyter import unload_ipython_extension as _unload_ipython_extension

    return _unload_ipython_extension(ipython)


# Version and metadata exports
__all__ = [
    "__version__",
    "__version_build_time__",
    "__author__",
    "__email__",
    # Core API
    "epochly_run",
    "configure",
    "optimize",
    "optimize_context",
    "auto_enable",  # Export for sitecustomize.py
    # Additional decorator API (documented in user-guide/decorators.md)
    "performance_monitor",
    "jit_compile",
    "full_optimize",
    "threading_optimize",
    # Additional context manager API (documented in user-guide/context-managers.md)
    "monitoring_context",
    "jit_context",
    "threading_context",
    "full_optimize_context",
    "benchmark_context",
    "epochly_disabled_context",
    # Status and configuration
    "get_status",
    "stats",
    "get_config",
    "get_license_info",
    "check_feature",
    "set_level",
    "get_level",
    "is_enabled",
    "get_metrics",
    "shutdown",
    "enable",
    "disable",
    "emergency_disable",
    "EnhancementLevel",
    # Q-M-002: Lazy init error handling
    "get_init_error",
    "is_initialized",
    "had_init_error",
    "clear_init_error",
    "EpochlyInitializationError",
    # P1 WARMUP OPTIMIZATION (Jan 2026): Eager mode API
    "eager_mode",
    "CompilationMode",
    "get_core",  # Expose for eager_mode tests
    "load_ipython_extension",
    "unload_ipython_extension",
    # GPU API (documented in optimization-guide/gpu-optimization-strategy.md)
    "is_gpu_available",
    "get_gpu_info",
    # Inference API (v0.6.0)
    "wrap",
    # Exception classes (documented in API reference)
    "EpochlyError",
    "EpochlyConfigError",
    "EpochlyCompatibilityError",
]


# P1 WARMUP OPTIMIZATION (Jan 2026): Eager mode API for synchronous compilation
# Lazy-loaded to avoid importing dill/cloudpickle at import time (~5-15ms overhead)
def eager_mode(*args, **kwargs):
    """Lazy-loaded eager compilation mode context manager.

    Defers import of jit.manager until first use to avoid loading
    dill/cloudpickle at module import time.
    """
    from .jit.manager import eager_mode as _eager_mode
    return _eager_mode(*args, **kwargs)


# Lazy accessor for CompilationMode enum via module __getattr__
_LAZY_IMPORTS = {
    'CompilationMode': ('.jit.manager', 'CompilationMode'),
    'EnhancementLevel': ('.core.epochly_core', 'EnhancementLevel'),
    'EpochlyCompatibilityError': ('.utils.exceptions', 'EpochlyCompatibilityError'),
    'EpochlyConfigError': ('.utils.exceptions', 'EpochlyConfigError'),
    'EpochlyError': ('.utils.exceptions', 'EpochlyError'),
    'EpochlyInitializationError': ('.utils.exceptions', 'EpochlyInitializationError'),
}


def __getattr__(name):
    if name == "__version__":
        value = _resolve_package_version()
        globals()[name] = value
        return value
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        import importlib
        module = importlib.import_module(module_path, package=__name__)
        value = getattr(module, attr_name)
        # Cache on module to avoid repeated import on subsequent access
        globals()[name] = value
        return value
    raise AttributeError(f"module 'epochly' has no attribute {name!r}")
