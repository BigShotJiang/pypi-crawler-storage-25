"""Build metadata exposed at runtime."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional


_BUILD_TIME_ENV_VAR = "EPOCHLY_VERSION_BUILD_TIME"


def _parse_build_time(raw_value: Optional[str]) -> Optional[int]:
    if raw_value is None:
        return None
    try:
        parsed = int(raw_value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _default_build_time() -> int:
    try:
        return int(Path(__file__).resolve().stat().st_mtime)
    except OSError:
        return int(time.time())


__version_build_time__ = _parse_build_time(os.environ.get(_BUILD_TIME_ENV_VAR)) or _default_build_time()
