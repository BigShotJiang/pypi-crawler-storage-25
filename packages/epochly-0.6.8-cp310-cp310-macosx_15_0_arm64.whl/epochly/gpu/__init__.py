"""
Epochly GPU Acceleration Module (Level 4 Enhancement)

This module provides optional GPU acceleration for Epochly through CuPy integration,
implementing the Level 4 progressive enhancement tier. GPU acceleration is
transparent to users and gracefully falls back to CPU when unavailable.

Key features:
- Automatic GPU availability detection
- Zero-code-change acceleration
- Dynamic NumPy/CuPy switching
- Intelligent workload offloading
- Unified memory management
- Performance monitoring

Author: Epochly Development Team
"""

from ..utils.exceptions import CudaVersionMismatchError, UnsupportedPythonError
from .cupy_manager import CuPyManager
from .gpu_detector import GPUDetector, GPUInfo
from .gpu_diagnostics import (
    GPUDiagnosticReport,
    GPUDiagnosticStatus,
    format_report,
    get_installation_guide,
    get_user_friendly_gpu_error,
    run_diagnostics,
)
from .gpu_memory_manager import GPUMemoryManager
from .offload_optimizer import GPUOffloadOptimizer

__all__ = [
    'CuPyManager',
    'GPUOffloadOptimizer',
    'GPUDetector',
    'GPUMemoryManager',
    'CudaVersionMismatchError',
    'UnsupportedPythonError',
    'detect',
    'gpu_status_reason',
    'get_gpu_info',
    'get_gpu_manager',
    'gpu_available',
    'is_gpu_available',
    'run_diagnostics',
    'format_report',
    'get_installation_guide',
    'get_user_friendly_gpu_error',
    'GPUDiagnosticReport',
    'GPUDiagnosticStatus',
]


def get_gpu_manager() -> CuPyManager:
    """Get the global GPU manager instance."""
    return CuPyManager.get_instance()  # noqa: removed-api


def detect() -> GPUInfo:
    """Return GPU information or raise a named compatibility error."""
    return GPUDetector.detect()


def is_gpu_available() -> bool:
    """Check if GPU acceleration is available."""
    return GPUDetector.is_available()


def gpu_available() -> bool:
    """Alias for is_gpu_available() using the mission contract naming."""
    return is_gpu_available()


def gpu_status_reason() -> str:
    """Return the most recent user-facing reason for GPU availability/unavailability."""
    reason = GPUDetector.get_status_reason()
    if isinstance(reason, str) and reason:
        return reason
    return "GPU not available or not initialized"


def get_gpu_info() -> GPUInfo:
    """Get information about available GPU resources."""
    return GPUDetector.get_gpu_info()
