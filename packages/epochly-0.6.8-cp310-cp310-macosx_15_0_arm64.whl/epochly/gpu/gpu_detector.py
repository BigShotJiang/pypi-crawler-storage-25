"""
GPU Detection and Capability Assessment

This module handles detection of GPU availability, CUDA capability assessment,
and hardware information gathering for GPU acceleration decisions.

Author: Epochly Development Team
"""

import logging
import re
import sys
import threading
from dataclasses import dataclass
from enum import Enum
from importlib import import_module
from importlib import metadata as importlib_metadata
from typing import Any, Dict, Optional

from ..utils.exceptions import CudaVersionMismatchError, UnsupportedPythonError


class GPUBackend(Enum):
    """Available GPU backends."""
    NONE = "none"
    CUPY = "cupy"
    CUDA = "cuda"
    OPENCL = "opencl"


@dataclass
class GPUInfo:
    """Information about available GPU resources."""
    backend: GPUBackend
    device_count: int
    memory_total: int  # in bytes
    memory_free: int   # in bytes
    compute_capability: Optional[str] = None
    device_name: Optional[str] = None
    cuda_version: Optional[str] = None
    driver_version: Optional[str] = None
    supports_unified_memory: bool = False


class GPUDetector:
    """
    Detector for GPU availability and capabilities.

    This class provides static methods for detecting GPU hardware
    and assessing suitability for acceleration.
    """

    _detection_cache: Optional[GPUInfo] = None
    _detection_error: Optional[Exception] = None
    _status_reason: str = "GPU detection has not run"
    _detection_lock = threading.Lock()
    _logger = logging.getLogger(__name__)
    _CUDA_DIST_PATTERN = re.compile(r"cupy-cuda(\d+)x")

    @classmethod
    def is_available(cls) -> bool:
        """
        Check if GPU acceleration is available.

        Returns:
            True if GPU acceleration is available
        """
        info = cls.get_gpu_info()
        return info.backend != GPUBackend.NONE and info.device_count > 0

    @classmethod
    def is_python_supported(cls) -> bool:
        """Return whether the current Python runtime is supported for CuPy-backed GPU use."""
        return cls._python_version_tuple() < (3, 13)

    @classmethod
    def detect(cls) -> GPUInfo:
        """Detect GPU availability and raise compatibility errors when the GPU path is unusable."""
        return cls._ensure_detection(raise_on_error=True)

    @classmethod
    def get_gpu_info(cls) -> GPUInfo:
        """
        Get comprehensive GPU information.

        Returns:
            GPUInfo object with hardware details
        """
        return cls._ensure_detection(raise_on_error=False)

    @classmethod
    def get_status_reason(cls) -> str:
        """Return the most recent human-readable GPU availability reason."""
        cls._ensure_detection(raise_on_error=False)
        return cls._status_reason

    @classmethod
    def clear_cache(cls) -> None:
        """Clear the detection cache to force re-detection."""
        with cls._detection_lock:
            cls._detection_cache = None
            cls._detection_error = None
            cls._status_reason = "GPU detection has not run"

    @classmethod
    def _ensure_detection(cls, *, raise_on_error: bool) -> GPUInfo:
        with cls._detection_lock:
            if cls._detection_cache is None:
                try:
                    cls._detection_cache = cls._detect_gpu_hardware()
                    cls._detection_error = None
                    if cls._detection_cache.backend == GPUBackend.NONE and cls._status_reason == "GPU detection has not run":
                        cls._status_reason = "No GPU acceleration backend detected"
                except (CudaVersionMismatchError, UnsupportedPythonError) as exc:
                    cls._detection_cache = cls._get_no_gpu_info()
                    cls._detection_error = exc
                    cls._status_reason = str(exc)
                except Exception as exc:  # pragma: no cover - defensive fallback
                    cls._detection_cache = cls._get_no_gpu_info()
                    cls._detection_error = None
                    cls._status_reason = f"GPU detection failed: {exc}"
                    cls._logger.debug("GPU detection failed", exc_info=True)

            if raise_on_error and cls._detection_error is not None:
                raise cls._detection_error

            return cls._detection_cache if cls._detection_cache is not None else cls._get_no_gpu_info()

    @classmethod
    def _detect_gpu_hardware(cls) -> GPUInfo:
        """Detect available GPU hardware and capabilities using compatibility-aware checks."""
        distribution = cls._get_installed_cupy_distribution()
        if distribution is not None:
            cupy_info = cls._detect_cupy()
            if cupy_info.backend != GPUBackend.NONE:
                cls._status_reason = (
                    f"GPU available via CuPy ({distribution['name']} {distribution['version']})"
                )
                return cupy_info
            return cls._get_no_gpu_info()

        pynvml_info = cls._detect_pynvml_fast()
        if pynvml_info.backend != GPUBackend.NONE:
            cls._status_reason = "GPU hardware detected via NVIDIA management library"
            return pynvml_info

        cuda_info = cls._detect_cuda_direct()
        if cuda_info.backend != GPUBackend.NONE:
            cls._status_reason = "GPU hardware detected via direct CUDA probing"
            return cuda_info

        cls._status_reason = "No GPU hardware detected"
        return cls._get_no_gpu_info()

    @classmethod
    def _detect_pynvml_fast(cls) -> GPUInfo:
        """Fast GPU detection using pynvml (nvidia-ml-py) - target <25ms."""
        try:
            import pynvml

            pynvml.nvmlInit()
            device_count = pynvml.nvmlDeviceGetCount()

            if device_count == 0:
                pynvml.nvmlShutdown()
                return cls._get_no_gpu_info()

            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            memory_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            device_name = pynvml.nvmlDeviceGetName(handle)
            major, minor = pynvml.nvmlDeviceGetCudaComputeCapability(handle)
            cuda_version = pynvml.nvmlSystemGetCudaDriverVersion()
            driver_version = pynvml.nvmlSystemGetDriverVersion()
            pynvml.nvmlShutdown()

            if isinstance(device_name, bytes):
                device_name = device_name.decode('utf-8')

            cls._logger.info(
                "Fast GPU detected via pynvml: %s, %s devices, %sGB total memory",
                device_name,
                device_count,
                memory_info.total // 1024**3,
            )

            return GPUInfo(
                backend=GPUBackend.CUPY,
                device_count=device_count,
                memory_total=memory_info.total,
                memory_free=memory_info.free,
                compute_capability=f"{major}.{minor}",
                device_name=device_name,
                cuda_version=str(cuda_version),
                driver_version=str(driver_version),
                supports_unified_memory=major >= 6,
            )

        except ImportError:
            cls._logger.debug("pynvml (nvidia-ml-py) not available for fast GPU detection")
            return cls._get_no_gpu_info()
        except Exception as exc:
            cls._logger.debug("Fast pynvml GPU detection failed: %s", exc)
            return cls._get_no_gpu_info()

    @classmethod
    def _detect_cupy(cls) -> GPUInfo:
        """Detect CuPy availability and GPU information."""
        distribution = cls._get_installed_cupy_distribution()
        if distribution is None:
            cls._status_reason = "CuPy is not installed"
            return cls._get_no_gpu_info()

        try:
            cp = cls._import_cupy_module()
        except ImportError as exc:
            if cls._python_version_tuple() >= (3, 13):
                raise cls._build_unsupported_python_error(distribution, exc) from exc
            cls._logger.debug("CuPy not available (%s)", exc)
            cls._status_reason = f"CuPy import failed: {exc}"
            return cls._get_no_gpu_info()
        except Exception as exc:
            if cls._python_version_tuple() >= (3, 13):
                raise cls._build_unsupported_python_error(distribution, exc) from exc
            cls._logger.debug("CuPy import failed", exc_info=True)
            cls._status_reason = f"CuPy initialization failed: {exc}"
            return cls._get_no_gpu_info()

        try:
            if not cp.cuda.is_available():
                cls._logger.debug("CUDA not available for CuPy")
                cls._status_reason = "CuPy is installed but CUDA is not available"
                return cls._get_no_gpu_info()

            runtime_version_raw = cp.cuda.runtime.runtimeGetVersion()
            runtime_version = cls._format_cuda_runtime_version(runtime_version_raw)
            cls._validate_runtime_version(distribution, runtime_version_raw, runtime_version)

            device_count = cp.cuda.runtime.getDeviceCount()
            if device_count == 0:
                cls._logger.debug("No CUDA devices found")
                cls._status_reason = "CuPy is installed but no CUDA devices were found"
                return cls._get_no_gpu_info()

            device_id = cp.cuda.Device().id
            memory_free, memory_total = cp.cuda.runtime.memGetInfo()
            props = cp.cuda.runtime.getDeviceProperties(device_id)
            device_name = props['name']
            if isinstance(device_name, bytes):
                device_name = device_name.decode('utf-8')
            compute_capability = f"{props['major']}.{props['minor']}"
            driver_version = cls._format_cuda_runtime_version(cp.cuda.runtime.driverGetVersion())
            supports_unified_memory = props['major'] >= 6

            cls._logger.info(
                "CuPy GPU detected: %s, %s devices, %sGB total memory",
                device_name,
                device_count,
                memory_total // (1024**3),
            )

            return GPUInfo(
                backend=GPUBackend.CUPY,
                device_count=device_count,
                memory_total=memory_total,
                memory_free=memory_free,
                compute_capability=compute_capability,
                device_name=device_name,
                cuda_version=runtime_version,
                driver_version=driver_version,
                supports_unified_memory=supports_unified_memory,
            )

        except CudaVersionMismatchError:
            raise
        except Exception as exc:
            if cls._python_version_tuple() >= (3, 13):
                raise cls._build_unsupported_python_error(distribution, exc) from exc
            cls._logger.debug("CuPy detection failed", exc_info=True)
            cls._status_reason = f"CuPy detection failed: {exc}"
            return cls._get_no_gpu_info()

    @classmethod
    def _detect_cuda_direct(cls) -> GPUInfo:
        """Direct CUDA detection without CuPy."""
        try:
            import pynvml

            pynvml.nvmlInit()
            device_count = pynvml.nvmlDeviceGetCount()

            if device_count == 0:
                return cls._get_no_gpu_info()

            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            memory_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            device_name = pynvml.nvmlDeviceGetName(handle).decode('utf-8')
            major, minor = pynvml.nvmlDeviceGetCudaComputeCapability(handle)
            compute_capability = f"{major}.{minor}"

            cls._logger.info("Direct CUDA GPU detected: %s, %s devices", device_name, device_count)

            return GPUInfo(
                backend=GPUBackend.CUDA,
                device_count=device_count,
                memory_total=memory_info.total,
                memory_free=memory_info.free,
                compute_capability=compute_capability,
                device_name=device_name,
                supports_unified_memory=(major >= 6),
            )

        except ImportError:
            cls._logger.debug("pynvml not available for direct CUDA detection")
            return cls._get_no_gpu_info()
        except Exception as exc:
            cls._logger.debug("Direct CUDA detection failed: %s", exc)
            return cls._get_no_gpu_info()

    @classmethod
    def _import_cupy_module(cls) -> Any:
        return import_module('cupy')

    @classmethod
    def _get_installed_cupy_distribution(cls) -> Optional[Dict[str, str]]:
        preferred_names = (
            'cupy-cuda13x',
            'cupy-cuda12x',
            'cupy-cuda11x',
            'cupy',
            'cupy-rocm',
        )
        for name in preferred_names:
            try:
                return {'name': name, 'version': importlib_metadata.version(name)}
            except importlib_metadata.PackageNotFoundError:
                continue

        for dist in importlib_metadata.distributions():
            raw_name = dist.metadata.get('Name')
            if raw_name and raw_name.lower().startswith('cupy'):
                return {'name': raw_name, 'version': dist.version}

        return None

    @classmethod
    def _python_version_tuple(cls) -> tuple[int, int]:
        version_info = sys.version_info
        return int(version_info[0]), int(version_info[1])

    @classmethod
    def _python_version_string(cls) -> str:
        version_info = sys.version_info
        return f"{version_info[0]}.{version_info[1]}"

    @classmethod
    def _format_cuda_runtime_version(cls, runtime_version: Any) -> str:
        try:
            version_int = int(runtime_version)
        except (TypeError, ValueError):
            return str(runtime_version)

        if version_int <= 0:
            return str(version_int)

        major = version_int // 1000
        minor = (version_int % 1000) // 10
        return f"{major}.{minor}"

    @classmethod
    def _expected_cuda_major(cls, distribution_name: str) -> Optional[int]:
        match = cls._CUDA_DIST_PATTERN.fullmatch(distribution_name)
        if match is None:
            return None
        return int(match.group(1))

    @classmethod
    def _validate_runtime_version(
        cls,
        distribution: Dict[str, str],
        runtime_version_raw: Any,
        runtime_version: str,
    ) -> None:
        expected_major = cls._expected_cuda_major(distribution['name'])
        if expected_major is None:
            return

        try:
            runtime_major = int(runtime_version_raw) // 1000
        except (TypeError, ValueError):
            return

        if runtime_major == expected_major:
            return

        raise CudaVersionMismatchError(
            (
                f"CUDA runtime {runtime_version} is incompatible with "
                f"{distribution['name']} {distribution['version']} "
                f"(expected CUDA {expected_major}.x)"
            ),
            installed_cupy=f"{distribution['name']} {distribution['version']}",
            runtime_version=runtime_version,
            expected_runtime=f"{expected_major}.x",
        )

    @classmethod
    def _build_unsupported_python_error(
        cls,
        distribution: Dict[str, str],
        exc: Exception,
    ) -> UnsupportedPythonError:
        python_version = cls._python_version_string()
        current = f"Python {python_version} with {distribution['name']} {distribution['version']}"
        minimum_supported = (
            f"Python 3.12 with {distribution['name']} {distribution['version']} "
            "or a CuPy build that explicitly supports Python 3.13"
        )
        return UnsupportedPythonError(
            (
                f"Python {python_version} is not compatible with the installed "
                f"{distribution['name']} {distribution['version']} GPU build. "
                f"Minimum supported combination: {minimum_supported}. "
                f"Original import error: {exc}"
            ),
            requirement=minimum_supported,
            current=current,
        )

    @classmethod
    def _get_no_gpu_info(cls) -> GPUInfo:
        """Return GPUInfo indicating no GPU available."""
        return GPUInfo(
            backend=GPUBackend.NONE,
            device_count=0,
            memory_total=0,
            memory_free=0,
        )

    @classmethod
    def get_recommended_memory_limit(cls) -> int:
        """
        Get recommended GPU memory limit (80% of total).

        Returns:
            Recommended memory limit in bytes
        """
        info = cls.get_gpu_info()
        if info.backend == GPUBackend.NONE:
            return 0
        return int(info.memory_total * 0.8)

    @classmethod
    def is_operation_suitable_for_gpu(cls, operation_type: str, data_size: int) -> bool:
        """
        Determine if an operation is suitable for GPU acceleration.

        Args:
            operation_type: Type of operation (e.g., 'matmul', 'fft', 'elementwise')
            data_size: Size of data in bytes

        Returns:
            True if operation should be accelerated on GPU
        """
        if not cls.is_available():
            return False

        info = cls.get_gpu_info()

        min_data_size = 10 * 1024 * 1024
        if data_size < min_data_size:
            return False

        if info.memory_free < data_size * 2:
            return False

        gpu_friendly_ops = {
            'matmul', 'dot', 'tensordot',
            'fft', 'ifft',
            'convolve', 'correlate',
            'sum', 'mean', 'std', 'var',
            'add', 'subtract', 'multiply',
            'divide', 'power', 'sqrt',
            'sin', 'cos', 'exp', 'log',
            'sort', 'argsort',
            'unique', 'where',
        }

        return operation_type.lower() in gpu_friendly_ops

    @classmethod
    def estimate_gpu_benefit(cls, operation_type: str, data_size: int) -> float:
        """
        Estimate potential speedup from GPU acceleration.

        Args:
            operation_type: Type of operation
            data_size: Size of data in bytes

        Returns:
            Estimated speedup ratio (1.0 = no benefit, 2.0 = 2x speedup)
        """
        if not cls.is_operation_suitable_for_gpu(operation_type, data_size):
            return 1.0

        base_speedups = {
            'matmul': 15.0,
            'dot': 12.0,
            'fft': 8.0,
            'convolve': 6.0,
            'sum': 4.0,
            'elementwise': 3.0,
        }

        op_category = cls._categorize_operation(operation_type)
        base_speedup = base_speedups.get(op_category, 2.0)
        size_mb = data_size / (1024 * 1024)
        if size_mb > 100:
            size_factor = 1.2
        elif size_mb > 50:
            size_factor = 1.1
        else:
            size_factor = 1.0

        return base_speedup * size_factor

    @classmethod
    def _categorize_operation(cls, operation_type: str) -> str:
        """Categorize operation type for speedup estimation."""
        op = operation_type.lower()

        if op in ['matmul', 'dot', 'tensordot']:
            return 'matmul'
        if op in ['fft', 'ifft']:
            return 'fft'
        if op in ['convolve', 'correlate']:
            return 'convolve'
        if op in ['sum', 'mean', 'std', 'var', 'min', 'max']:
            return 'sum'
        return 'elementwise'
