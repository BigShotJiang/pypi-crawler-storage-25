"""
JIT Compilation Persistent Cache

Persistent disk-based cache for compiled functions that survives process restarts.
Enables warm restarts by caching JIT-compiled artifacts across sessions.

Architecture:
- Disk-based cache in ~/.epochly/jit_cache/
- Hash-based invalidation (function code changes)
- Python version validation (cache invalid on Python upgrade)
- Thread-safe cache access
- LRU cleanup to prevent unbounded growth
- Supports multiple backends (Numba, Pyston, Native JIT)

Performance:
- Save: <10ms (serialize + write to disk)
- Load: <5ms (read from disk + deserialize)
- Cache hit eliminates 1-3s compilation time

Author: Epochly Development Team
"""

import inspect
import os
import sys
import time
import errno
import pickle
import hashlib
import threading
import logging
import types
from collections import OrderedDict
from pathlib import Path
from typing import Optional, Callable, Dict, Any, Union, cast
from dataclasses import dataclass, field
from enum import Enum

# Import signed and restricted pickle helpers for cache verification
from ..security import signed_pickle
from ..utils.safe_pickle import safe_loads as _safe_loads

logger = logging.getLogger(__name__)
JIT_CACHE_MAX_ENTRIES = 1024
_DEFAULT_MAX_DISK_CACHE_BYTES = 1_073_741_824
_MAX_DISK_CACHE_BYTES_ENV = "EPOCHLY_JIT_CACHE_MAX_BYTES"
_ARTIFACT_SERIALIZATION_PROTOCOL = 4
_SIGNING_KEY_ENV_VAR = 'EPOCHLY_SIGNED_PICKLE_KEY'
_SIGNING_KEY_FILE_NAME = '.signing_key'
_EXPECTED_SIGNING_KEY_SIZE = 32
_SIGNING_KEY_WAIT_SECONDS = 1.0
_SIGNING_KEY_WAIT_INTERVAL_SECONDS = 0.01
_LOCK_TYPES = (type(threading.Lock()), type(threading.RLock()))


def _coerce_signing_key(signing_key: Optional[Union[bytes, bytearray, memoryview]]) -> Optional[bytes]:
    if signing_key is None:
        return None
    if isinstance(signing_key, bytes):
        return signing_key
    if isinstance(signing_key, bytearray):
        return bytes(signing_key)
    if isinstance(signing_key, memoryview):
        return signing_key.tobytes()
    raise TypeError('signing_key must be bytes-like')


def _load_env_signing_key() -> Optional[bytes]:
    raw_value = os.getenv(_SIGNING_KEY_ENV_VAR)
    if not raw_value:
        return None

    try:
        return bytes.fromhex(raw_value)
    except ValueError:
        return raw_value.encode('utf-8')


def _is_not_writable_error(exc: OSError) -> bool:
    return isinstance(exc, PermissionError) or getattr(exc, 'errno', None) in {
        errno.EACCES,
        errno.EPERM,
        errno.EROFS,
    }


def _set_owner_only_mode(path: Path) -> None:
    if os.name != 'nt':
        os.chmod(path, 0o600)


def _resolve_max_entries(max_entries: Optional[int]) -> int:
    """Resolve the memory cache size from ctor override or environment."""
    if max_entries is None:
        configured = os.environ.get('EPOCHLY_JIT_CACHE_SIZE')
        if configured is None or configured.strip() == '':
            return JIT_CACHE_MAX_ENTRIES
        try:
            max_entries = int(configured)
        except ValueError:
            logger.warning(
                "Invalid EPOCHLY_JIT_CACHE_SIZE=%r; using default %d",
                configured,
                JIT_CACHE_MAX_ENTRIES,
            )
            return JIT_CACHE_MAX_ENTRIES

    if max_entries <= 0:
        raise ValueError('max_entries must be a positive integer')

    return max_entries


class _PickleSafeLockSentinel:
    """Pickle-safe lock replacement for rehydrated cached JIT drivers."""

    def __init__(self, reentrant: bool = False):
        self._reentrant = bool(reentrant)
        self._lock = self._new_lock()

    def _new_lock(self) -> Any:
        return threading.RLock() if self._reentrant else threading.Lock()

    def __getstate__(self) -> Dict[str, bool]:
        return {'reentrant': self._reentrant}

    def __setstate__(self, state: Dict[str, bool]) -> None:
        self._reentrant = bool(state.get('reentrant', False))
        self._lock = self._new_lock()

    def acquire(self, *args: Any, **kwargs: Any) -> bool:
        return bool(self._lock.acquire(*args, **kwargs))

    def release(self) -> None:
        self._lock.release()

    def locked(self) -> bool:
        locked = getattr(self._lock, 'locked', None)
        if callable(locked):
            return bool(locked())
        return False

    def __enter__(self) -> "_PickleSafeLockSentinel":
        self.acquire()
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> bool:
        self.release()
        return False


def _is_lock_like(value: Any) -> bool:
    return isinstance(value, _LOCK_TYPES)


def _is_reentrant_lock(value: Any) -> bool:
    return isinstance(value, type(threading.RLock()))


def _make_cell(value: Any) -> Any:
    def cell_factory() -> Any:
        return value

    return cell_factory.__closure__[0]


def _replace_lock_closure_cells(func: Any) -> Any:
    """Return a copy of ``func`` with non-picklable lock closure cells replaced."""
    if not isinstance(func, types.FunctionType) or func.__closure__ is None:
        return func

    replacement_cells = []
    replaced = False
    for cell in func.__closure__:
        try:
            cell_value = cell.cell_contents
        except ValueError:
            replacement_cells.append(cell)
            continue

        if _is_lock_like(cell_value):
            replacement_cells.append(
                _make_cell(_PickleSafeLockSentinel(reentrant=_is_reentrant_lock(cell_value)))
            )
            replaced = True
        else:
            replacement_cells.append(cell)

    if not replaced:
        return func

    rebuilt = types.FunctionType(
        func.__code__,
        func.__globals__,
        func.__name__,
        func.__defaults__,
        tuple(replacement_cells),
    )
    rebuilt.__kwdefaults__ = getattr(func, '__kwdefaults__', None)
    rebuilt.__annotations__ = dict(getattr(func, '__annotations__', {}))
    rebuilt.__dict__.update(getattr(func, '__dict__', {}))
    rebuilt.__module__ = getattr(func, '__module__', None)
    rebuilt.__doc__ = getattr(func, '__doc__', None)
    rebuilt.__qualname__ = getattr(func, '__qualname__', func.__name__)
    return rebuilt


# Import serialization libraries
try:
    import cloudpickle
    CLOUDPICKLE_AVAILABLE = True
except ImportError:
    cloudpickle = None
    CLOUDPICKLE_AVAILABLE = False

try:
    import dill
    DILL_AVAILABLE = True
except ImportError:
    dill = None
    DILL_AVAILABLE = False


class CacheBackend(Enum):
    """Serialization backend for cache."""
    CLOUDPICKLE = "cloudpickle"
    DILL = "dill"
    PICKLE = "pickle"


@dataclass
class CachedArtifact:
    """Cached compilation artifact with metadata."""

    function_name: str
    module_name: str
    backend: str  # 'numba', 'pyston', 'native'
    compiled_data: bytes  # Serialized compiled function
    source_hash: str
    python_version: tuple  # (major, minor)
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_valid(self, current_source_hash: Optional[str] = None) -> bool:
        """Check if cached artifact is still valid."""
        # Check Python version compatibility
        current_version = sys.version_info[:2]
        if self.python_version != current_version:
            logger.debug(f"Cache invalid for {self.function_name}: Python {self.python_version} != {current_version}")
            return False

        if current_source_hash is not None and self.source_hash != current_source_hash:
            logger.debug(
                f"Cache invalid for {self.function_name}: source hash {self.source_hash} != {current_source_hash}"
            )
            return False

        # Check age (invalidate after 7 days)
        age_days = (time.time() - self.timestamp) / (24 * 3600)
        if age_days > 7:
            logger.debug(f"Cache expired for {self.function_name}: {age_days:.1f} days old")
            return False

        return True


class JITArtifactCache:
    """
    Persistent disk-based cache for JIT-compiled functions.

    Provides warm restart capability by caching compiled artifacts to disk.
    Automatically invalidates on code changes, Python version upgrades, or age.

    Thread-safe for concurrent access.
    """

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        signing_key: Optional[Union[bytes, bytearray, memoryview]] = None,
        max_entries: Optional[int] = None,
    ):
        """
        Initialize JIT artifact cache.

        Args:
            cache_dir: Cache directory path (default: ~/.epochly/jit_cache)
        """
        # Determine cache directory
        if cache_dir is None:
            # Check environment variable first
            cache_dir = os.environ.get('EPOCHLY_JIT_CACHE_DIR')

        if cache_dir is None:
            # Default to ~/.epochly/jit_cache
            cache_dir = str(Path.home() / '.epochly' / 'jit_cache')

        self.cache_dir = Path(cache_dir).expanduser().resolve()
        self._cache_dir_warning_emitted = False
        self._cache_dir_writable = self._ensure_cache_dir()
        self._disk_cache_enabled = self._cache_dir_writable
        self.max_disk_cache_bytes = self._resolve_disk_cache_budget()

        # Thread safety
        self._lock = threading.RLock()
        self._signing_key = self._resolve_signing_key(signing_key)
        self.max_entries = _resolve_max_entries(max_entries)

        # In-memory cache for fast access
        self._memory_cache: OrderedDict[str, CachedArtifact] = OrderedDict()

        # Determine serialization backend
        self._serialization_backend = self._select_backend()

        # Statistics
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache_saves = 0
        self._cache_invalidations = 0
        self._disk_evictions = 0

        self._enforce_disk_cache_budget()

        logger.info(f"JIT cache initialized: {self.cache_dir} (backend: {self._serialization_backend.value})")

    def _ensure_cache_dir(self) -> bool:
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            if _is_not_writable_error(exc):
                return False
            raise
        return os.access(self.cache_dir, os.W_OK)

    def _signing_key_path(self) -> Path:
        return self.cache_dir / _SIGNING_KEY_FILE_NAME

    def _warn_cache_dir_not_writable(self) -> None:
        if self._cache_dir_warning_emitted:
            return
        logger.warning('cache directory is not writable; using per-process random signing key')
        self._cache_dir_warning_emitted = True

    def _resolve_signing_key(
        self,
        signing_key: Optional[Union[bytes, bytearray, memoryview]],
    ) -> bytes:
        explicit_key = _coerce_signing_key(signing_key)
        if explicit_key is not None:
            return explicit_key

        env_key = _load_env_signing_key()
        if env_key is not None:
            return env_key

        disk_key = self._load_or_create_disk_signing_key()
        if disk_key is not None:
            return disk_key

        self._warn_cache_dir_not_writable()
        return signed_pickle.get_or_create_key()

    def _load_or_create_disk_signing_key(self) -> Optional[bytes]:
        key_path = self._signing_key_path()
        if not self.cache_dir.exists() and not self._cache_dir_writable:
            return None
        if key_path.exists():
            key_bytes = self._wait_for_complete_signing_key(key_path)
            if key_bytes is not None:
                return key_bytes
            return self._replace_signing_key_file(key_path)

        return self._create_signing_key_file(key_path)

    def _wait_for_complete_signing_key(self, key_path: Path) -> Optional[bytes]:
        deadline = time.monotonic() + _SIGNING_KEY_WAIT_SECONDS

        while True:
            try:
                key_bytes = key_path.read_bytes()
            except FileNotFoundError:
                key_bytes = None
            except OSError as exc:
                if _is_not_writable_error(exc):
                    return None
                raise

            if key_bytes is not None and len(key_bytes) == _EXPECTED_SIGNING_KEY_SIZE:
                _set_owner_only_mode(key_path)
                return key_bytes

            if time.monotonic() >= deadline:
                return None

            time.sleep(_SIGNING_KEY_WAIT_INTERVAL_SECONDS)

    def _create_signing_key_file(self, key_path: Path) -> Optional[bytes]:
        key_bytes = os.urandom(_EXPECTED_SIGNING_KEY_SIZE)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, 'O_BINARY'):
            flags |= os.O_BINARY

        try:
            fd = os.open(os.fspath(key_path), flags, 0o600)
        except FileExistsError:
            existing_key = self._wait_for_complete_signing_key(key_path)
            if existing_key is not None:
                return existing_key
            return self._replace_signing_key_file(key_path)
        except OSError as exc:
            if _is_not_writable_error(exc):
                return None
            raise

        try:
            with os.fdopen(fd, 'wb') as handle:
                handle.write(key_bytes)
                handle.flush()
                try:
                    os.fsync(handle.fileno())
                except OSError:
                    pass
            _set_owner_only_mode(key_path)
            return key_bytes
        except Exception:
            key_path.unlink(missing_ok=True)
            raise

    def _replace_signing_key_file(self, key_path: Path) -> Optional[bytes]:
        key_bytes = os.urandom(_EXPECTED_SIGNING_KEY_SIZE)
        temp_path = key_path.with_name(f'.{key_path.name}.{os.getpid()}.{time.time_ns()}.tmp')

        try:
            with open(temp_path, 'xb') as handle:
                handle.write(key_bytes)
                handle.flush()
                try:
                    os.fsync(handle.fileno())
                except OSError:
                    pass
            _set_owner_only_mode(temp_path)
            os.replace(temp_path, key_path)
            _set_owner_only_mode(key_path)
            return key_bytes
        except OSError as exc:
            temp_path.unlink(missing_ok=True)
            if _is_not_writable_error(exc):
                return None
            raise

    def _resolve_disk_cache_budget(self) -> Optional[int]:
        """Resolve the maximum on-disk cache budget in bytes."""
        raw_budget = os.environ.get(_MAX_DISK_CACHE_BYTES_ENV)
        if raw_budget is None:
            return _DEFAULT_MAX_DISK_CACHE_BYTES

        try:
            budget = int(raw_budget)
        except ValueError:
            logger.warning(
                "Invalid %s=%r; using default JIT cache budget of %d bytes",
                _MAX_DISK_CACHE_BYTES_ENV,
                raw_budget,
                _DEFAULT_MAX_DISK_CACHE_BYTES,
            )
            return _DEFAULT_MAX_DISK_CACHE_BYTES

        if budget <= 0:
            logger.warning(
                "Invalid %s=%r; using default JIT cache budget of %d bytes",
                _MAX_DISK_CACHE_BYTES_ENV,
                raw_budget,
                _DEFAULT_MAX_DISK_CACHE_BYTES,
            )
            return _DEFAULT_MAX_DISK_CACHE_BYTES

        return budget

    def _select_backend(self) -> CacheBackend:
        """
        Select best available serialization backend.

        Returns:
            Selected cache backend
        """
        # Prefer cloudpickle (best for closures and lambdas)
        if CLOUDPICKLE_AVAILABLE:
            return CacheBackend.CLOUDPICKLE

        # Fallback to dill (also good for complex objects)
        if DILL_AVAILABLE:
            return CacheBackend.DILL

        # Last resort: standard pickle (limited support)
        return CacheBackend.PICKLE

    def cache_key(self, func: Callable, backend: str) -> str:
        """
        Generate stable cache key from function code and backend.

        Args:
            func: Function to cache
            backend: JIT backend name ('numba', 'pyston', 'native')

        Returns:
            Cache key string
        """
        func_name = getattr(func, '__name__', 'unknown')
        module_name = getattr(func, '__module__', 'unknown')

        # Hash function code for invalidation detection
        code_hash = self._compute_code_hash(func)

        # Include backend in key (same function may compile differently)
        return f"{module_name}.{func_name}_{code_hash[:16]}_{backend}"

    def _remember_artifact(self, cache_key: str, artifact: CachedArtifact) -> None:
        """Store a cache entry and promote it to most-recently-used."""
        self._memory_cache[cache_key] = artifact
        self._memory_cache.move_to_end(cache_key)
        self._enforce_memory_cache_limit()

    def _enforce_memory_cache_limit(self) -> None:
        """Evict least-recently-used entries until the memory cache is within cap."""
        while len(self._memory_cache) > self.max_entries:
            self._memory_cache.popitem(last=False)

    def _enforce_disk_cache_budget(self) -> int:
        """Evict oldest disk cache files until the cache directory is within budget."""
        budget = self.max_disk_cache_bytes
        if budget is None:
            return 0

        cache_files = []
        total_bytes = 0
        for cache_file in self.cache_dir.glob("*.cache"):
            try:
                stat = cache_file.stat()
            except OSError as exc:
                logger.warning(f"Failed to stat cache file {cache_file}: {exc}")
                continue

            cache_files.append((stat.st_mtime, cache_file, stat.st_size))
            total_bytes += stat.st_size

        if total_bytes <= budget:
            return 0

        removed = 0
        for _, cache_file, file_size in sorted(cache_files, key=lambda item: item[0]):
            if total_bytes <= budget:
                break
            try:
                cache_file.unlink(missing_ok=True)
                total_bytes -= file_size
                removed += 1
                self._memory_cache.pop(cache_file.stem, None)
                logger.debug(f"Evicted disk cache file over budget: {cache_file.name}")
            except OSError as exc:
                logger.warning(f"Failed to evict disk cache file {cache_file}: {exc}")

        if removed:
            self._disk_evictions += removed
            logger.info(
                "Evicted %d JIT cache file(s) to keep %s within %d bytes",
                removed,
                self.cache_dir,
                budget,
            )

        return removed

    def _compute_code_hash(self, func: Callable) -> str:
        """
        Compute hash of function code for cache invalidation.

        Args:
            func: Function to hash

        Returns:
            SHA-256 hash of function bytecode
        """
        target_func = inspect.unwrap(func)

        try:
            source = inspect.getsource(target_func)
        except (OSError, TypeError, IOError):
            source = None

        if source is not None:
            return hashlib.sha256(source.encode('utf-8')).hexdigest()

        code = getattr(target_func, '__code__', None)
        if code is None:
            return hashlib.sha256(str(target_func).encode('utf-8')).hexdigest()

        stable_fingerprint = (
            code.co_code,
            code.co_consts,
            code.co_names,
            code.co_varnames,
            code.co_cellvars,
            code.co_freevars,
            code.co_argcount,
            code.co_posonlyargcount,
            code.co_kwonlyargcount,
            code.co_nlocals,
            code.co_stacksize,
            code.co_flags,
            getattr(target_func, '__defaults__', None),
            getattr(target_func, '__kwdefaults__', None),
        )
        return hashlib.sha256(repr(stable_fingerprint).encode('utf-8')).hexdigest()

    def _cache_file_path(self, cache_key: str) -> Path:
        """
        Get file path for cache key.

        Args:
            cache_key: Cache key

        Returns:
            Path to cache file
        """
        return self.cache_dir / f"{cache_key}.cache"

    def save_compiled(
        self,
        func: Callable,
        compiled_func: Callable,
        backend: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Save compiled function to persistent cache.

        Args:
            func: Original function
            compiled_func: Compiled function to cache
            backend: Backend name ('numba', 'pyston', 'native')
            metadata: Optional metadata to store with artifact

        Returns:
            True if saved successfully, False otherwise
        """
        try:
            with self._lock:
                # Generate cache key
                key = self.cache_key(func, backend)

                # Serialize compiled function
                compiled_data = signed_pickle.dumps(self._serialize(compiled_func), self._signing_key)

                # Create artifact
                artifact = CachedArtifact(
                    function_name=getattr(func, '__name__', 'unknown'),
                    module_name=getattr(func, '__module__', 'unknown'),
                    backend=backend,
                    compiled_data=compiled_data,
                    source_hash=self._compute_code_hash(func),
                    python_version=sys.version_info[:2],
                    timestamp=time.time(),
                    metadata=metadata or {}
                )

                # Save to disk
                if self._disk_cache_enabled:
                    cache_file = self._cache_file_path(key)
                    self._write_artifact(cache_file, artifact)
                    self._enforce_disk_cache_budget()

                # Update memory cache
                self._remember_artifact(key, artifact)

                self._cache_saves += 1
                logger.debug(f"Saved {artifact.function_name} to cache (backend: {backend})")
                return True

        except Exception as e:
            logger.warning(f"Failed to save {func.__name__} to cache: {e}")
            return False

    def load_compiled(self, func: Callable, backend: str) -> Optional[Callable]:
        """
        Load compiled function from persistent cache.

        Args:
            func: Original function
            backend: Backend name ('numba', 'pyston', 'native')

        Returns:
            Compiled function if found and valid, None otherwise
        """
        try:
            with self._lock:
                # Generate cache key
                key = self.cache_key(func, backend)
                current_source_hash = self._compute_code_hash(func)

                # Check memory cache first (fast path)
                if key in self._memory_cache:
                    artifact = self._memory_cache[key]
                    if artifact.is_valid(current_source_hash=current_source_hash):
                        self._memory_cache.move_to_end(key)
                        self._cache_hits += 1
                        logger.debug(f"Cache hit (memory): {artifact.function_name}")
                        return cast(Callable, self._deserialize_compiled_data(artifact.compiled_data))
                    else:
                        # Invalidate stale cache entry
                        del self._memory_cache[key]
                        self._cache_invalidations += 1

                        # Also remove from disk to prevent reloading stale data
                        cache_file = self._cache_file_path(key)
                        if cache_file.exists():
                            cache_file.unlink(missing_ok=True)

                        # Return None - cache is invalid
                        self._cache_misses += 1
                        return None

                # Check disk cache (slow path)
                cache_file = self._cache_file_path(key)
                if cache_file.exists():
                    disk_artifact = self._read_artifact(cache_file)

                    if disk_artifact and disk_artifact.is_valid(current_source_hash=current_source_hash):
                        # Restore to memory cache
                        self._remember_artifact(key, disk_artifact)
                        self._cache_hits += 1
                        logger.debug(f"Cache hit (disk): {disk_artifact.function_name}")
                        return cast(Callable, self._deserialize_compiled_data(disk_artifact.compiled_data))
                    else:
                        # Remove invalid cache file
                        cache_file.unlink(missing_ok=True)
                        self._cache_invalidations += 1

                # Cache miss
                self._cache_misses += 1
                logger.debug(f"Cache miss: {func.__name__} (backend: {backend})")
                return None

        except signed_pickle.IntegrityError:
            with self._lock:
                self._memory_cache.pop(key, None)
                cache_file = self._cache_file_path(key)
                if cache_file.exists():
                    cache_file.unlink(missing_ok=True)
                self._cache_invalidations += 1
                self._cache_misses += 1
            raise
        except Exception as e:
            logger.warning(f"Failed to load {func.__name__} from cache: {e}")
            self._cache_misses += 1
            return None

    def _serialize(self, obj: Any) -> bytes:
        """
        Serialize object using selected backend.

        Args:
            obj: Object to serialize

        Returns:
            Serialized bytes
        """
        try:
            return self._serialize_with_backend(obj)
        except Exception as original_exc:
            sanitized_obj = _replace_lock_closure_cells(obj)
            if sanitized_obj is obj:
                raise

            try:
                serialized = self._serialize_with_backend(sanitized_obj)
            except Exception:
                raise original_exc

            logger.debug(
                "Serialized %s after replacing non-picklable lock closure cells",
                getattr(obj, '__name__', obj.__class__.__name__),
            )
            return serialized

    def _serialize_with_backend(self, obj: Any) -> bytes:
        """Serialize object using the configured backend without fallback rewriting."""
        if self._serialization_backend == CacheBackend.CLOUDPICKLE and CLOUDPICKLE_AVAILABLE:
            return cast(bytes, cloudpickle.dumps(obj))
        elif self._serialization_backend == CacheBackend.DILL and DILL_AVAILABLE:
            return cast(bytes, dill.dumps(obj))
        else:
            import pickle
            return pickle.dumps(obj)

    def _deserialize(self, data: bytes) -> Any:
        """
        Deserialize compiled function data using selected backend.

        This method is only reached after _deserialize_compiled_data() verifies
        the signed inner compiled-data envelope. The backend loads below are
        therefore restricted to verified bytes.

        Args:
            data: Serialized bytes

        Returns:
            Deserialized object
        """
        if self._serialization_backend == CacheBackend.CLOUDPICKLE and CLOUDPICKLE_AVAILABLE:
            # SECURITY: trusted-path: inner compiled_data passed signed_pickle.loads in _deserialize_compiled_data.
            return cloudpickle.loads(data)
        elif self._serialization_backend == CacheBackend.DILL and DILL_AVAILABLE:
            # SECURITY: trusted-path: inner compiled_data passed signed_pickle.loads in _deserialize_compiled_data.
            return dill.loads(data)
        else:
            # SECURITY: trusted-path: inner compiled_data passed signed_pickle.loads in _deserialize_compiled_data.
            return pickle.loads(data)

    def _deserialize_compiled_data(self, data: bytes) -> Any:
        """
        Verify the signed inner compiled-data payload before backend loads.

        Args:
            data: Signed inner payload produced by signed_pickle.dumps(bytes, key)

        Returns:
            Deserialized compiled callable/object
        """
        payload = signed_pickle.loads(data, self._signing_key)
        if isinstance(payload, memoryview):
            payload = payload.tobytes()
        elif isinstance(payload, bytearray):
            payload = bytes(payload)
        if not isinstance(payload, bytes):
            raise signed_pickle.IntegrityError('signed compiled payload must decode to bytes')
        return self._deserialize(payload)

    def _deserialize_artifact(self, data: bytes) -> Any:
        """
        Deserialize a CachedArtifact container using RestrictedUnpickler.

        Enforces allowlist to prevent arbitrary code execution from
        tampered cache files on disk. Only permits safe types and
        the CachedArtifact dataclass.

        Args:
            data: Serialized bytes of a CachedArtifact

        Returns:
            Deserialized CachedArtifact
        """
        return _safe_loads(data)

    def _serialize_artifact(self, artifact: CachedArtifact) -> bytes:
        """Serialize the outer artifact envelope as signed bytes."""
        artifact_payload = pickle.dumps(artifact, protocol=_ARTIFACT_SERIALIZATION_PROTOCOL)
        return signed_pickle.dumps(artifact_payload, self._signing_key)

    def _deserialize_signed_artifact(self, data: bytes) -> Any:
        """Verify the signed outer artifact envelope before restricted loads."""
        artifact_payload = signed_pickle.loads(data, self._signing_key)
        if isinstance(artifact_payload, memoryview):
            artifact_payload = artifact_payload.tobytes()
        elif isinstance(artifact_payload, bytearray):
            artifact_payload = bytes(artifact_payload)
        if not isinstance(artifact_payload, bytes):
            raise signed_pickle.IntegrityError('signed artifact payload must decode to bytes')
        return self._deserialize_artifact(artifact_payload)

    def _write_artifact(self, cache_file: Path, artifact: CachedArtifact) -> None:
        """
        Write artifact to disk.

        Args:
            cache_file: Path to cache file
            artifact: Artifact to write
        """
        # Write to temporary file first (atomic write)
        temp_file = cache_file.with_suffix('.tmp')

        try:
            with open(temp_file, 'wb') as f:
                artifact_data = self._serialize_artifact(artifact)
                f.write(artifact_data)

            # Atomic rename
            temp_file.replace(cache_file)

        except Exception as e:
            # Clean up temp file on error
            if temp_file.exists():
                temp_file.unlink(missing_ok=True)
            raise e

    def _read_artifact(self, cache_file: Path) -> Optional[CachedArtifact]:
        """
        Read artifact from disk.

        Args:
            cache_file: Path to cache file

        Returns:
            CachedArtifact if successful, None otherwise
        """
        try:
            with open(cache_file, 'rb') as f:
                artifact_data = f.read()
                artifact = self._deserialize_signed_artifact(artifact_data)

                # Validate artifact structure
                if not isinstance(artifact, CachedArtifact):
                    logger.warning(f"Invalid artifact in {cache_file}")
                    return None

                return artifact

        except signed_pickle.IntegrityError:
            raise
        except Exception as e:
            logger.warning(f"Failed to read cache file {cache_file}: {e}")
            return None

    def clear(self) -> int:
        """
        Clear all cached artifacts.

        Returns:
            Number of files removed
        """
        removed = 0

        with self._lock:
            # Clear memory cache
            self._memory_cache.clear()

            # Remove disk cache files
            for cache_file in self.cache_dir.glob('*.cache'):
                try:
                    cache_file.unlink(missing_ok=True)
                    removed += 1
                except Exception as e:
                    logger.warning(f"Failed to remove {cache_file}: {e}")

        logger.info(f"Cleared JIT cache: {removed} files removed")
        return removed

    def cleanup_stale(self, max_age_days: float = 7) -> int:
        """
        Remove stale cache entries (LRU cleanup).

        Args:
            max_age_days: Maximum age in days before cleanup

        Returns:
            Number of files removed
        """
        removed = 0
        current_time = time.time()
        max_age_seconds = max_age_days * 24 * 3600

        with self._lock:
            # Clean up disk cache
            for cache_file in self.cache_dir.glob('*.cache'):
                try:
                    # Check file age
                    file_age = current_time - cache_file.stat().st_mtime

                    if file_age > max_age_seconds:
                        cache_file.unlink(missing_ok=True)
                        removed += 1
                        logger.debug(f"Removed stale cache file: {cache_file.name}")

                except Exception as e:
                    logger.warning(f"Failed to check/remove {cache_file}: {e}")

            # Clean up memory cache
            stale_keys = []
            for key, artifact in self._memory_cache.items():
                if not artifact.is_valid():
                    stale_keys.append(key)

            for key in stale_keys:
                del self._memory_cache[key]
                removed += 1

        if removed > 0:
            logger.info(f"Cleaned up {removed} stale cache entries")

        return removed

    def get_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Dictionary with cache metrics
        """
        with self._lock:
            total_requests = self._cache_hits + self._cache_misses
            hit_rate = (self._cache_hits / total_requests * 100) if total_requests > 0 else 0.0

            # Count disk cache files
            disk_files = len(list(self.cache_dir.glob('*.cache')))

            return {
                'cache_dir': str(self.cache_dir),
                'serialization_backend': self._serialization_backend.value,
                'cache_hits': self._cache_hits,
                'cache_misses': self._cache_misses,
                'cache_saves': self._cache_saves,
                'cache_invalidations': self._cache_invalidations,
                'disk_evictions': self._disk_evictions,
                'max_disk_cache_bytes': self.max_disk_cache_bytes,
                'hit_rate': hit_rate,
                'memory_cache_size': len(self._memory_cache),
                'disk_cache_size': disk_files,
                'total_requests': total_requests
            }


# Global cache instance (singleton)
_global_cache: Optional[JITArtifactCache] = None
_cache_lock = threading.Lock()


def get_persistent_cache() -> JITArtifactCache:
    """
    Get global JIT persistent cache (singleton).

    Returns:
        JITArtifactCache instance
    """
    global _global_cache

    if _global_cache is None:
        with _cache_lock:
            if _global_cache is None:
                _global_cache = JITArtifactCache()

    return _global_cache
