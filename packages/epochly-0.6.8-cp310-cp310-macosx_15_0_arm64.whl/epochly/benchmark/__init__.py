"""
Epochly Benchmark Module.

Provides reproducible, self-contained benchmarks that demonstrate Epochly's
performance characteristics across JIT compilation, GPU acceleration, and
numerical computation.

Usage:
    python -m epochly.benchmark           # Run default benchmark suite
    python -m epochly.benchmark --quick   # Quick validation (3 iterations)
    python -m epochly.benchmark --json    # Machine-readable JSON output
    python -m epochly.benchmark --list    # List available workloads
"""

CANONICAL_BENCHMARK_CLI_MODULE = "epochly.benchmark"
LEGACY_BENCHMARK_CLI_MODULE = "epochly.demos.benchmark"
BENCHMARK_CLI_MODULES = (
    CANONICAL_BENCHMARK_CLI_MODULE,
    LEGACY_BENCHMARK_CLI_MODULE,
)

from epochly.benchmark.workloads import (
    WorkloadSpec,
    get_all_workloads,
    get_workloads_by_category,
)
from epochly.benchmark.runner import (
    BenchmarkConfig,
    BenchmarkResult,
    BenchmarkRunner,
    EpochlyConfig,
    StabilityStatus,
    compute_median,
)
from epochly.benchmark.system_info import (
    collect_system_info,
    format_system_line,
)

__all__ = [
    "CANONICAL_BENCHMARK_CLI_MODULE",
    "LEGACY_BENCHMARK_CLI_MODULE",
    "BENCHMARK_CLI_MODULES",
    "WorkloadSpec",
    "get_all_workloads",
    "get_workloads_by_category",
    "BenchmarkConfig",
    "BenchmarkResult",
    "BenchmarkRunner",
    "EpochlyConfig",
    "StabilityStatus",
    "compute_median",
    "collect_system_info",
    "format_system_line",
]
