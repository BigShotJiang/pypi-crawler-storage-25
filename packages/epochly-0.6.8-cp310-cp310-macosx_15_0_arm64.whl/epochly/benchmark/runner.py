"""
Epochly Benchmark Runner.

Measurement engine that times workloads in two modes:
  1. Baseline: Epochly at Level 0 (monitoring only, no optimizations)
  2. Enhanced: Epochly at whatever level the user's license supports

Activation:
  - Uses epochly.set_level() to switch between modes
  - No environment variable overrides -- respects the user's license
  - If licensed for all cores + GPU, benchmarks at Level 4
  - If on community tier (4 cores, no GPU), benchmarks at that configuration
  - The output reports precisely what level, cores, and features are active

Statistical approach:
  - Configurable warmup iterations (excluded from measurements)
  - Multiple measurement iterations
  - Median aggregation (robust to outliers)
  - Speedup computed as baseline_median / enhanced_median
"""

import logging
import multiprocessing
import os
import random
import statistics
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from epochly.gpu.gpu_detector import GPUDetector
from epochly.benchmark.workloads import WorkloadSpec, get_all_workloads

logger = logging.getLogger('epochly.benchmark')

LEVEL_NAMES = {
    0: 'Monitor Only',
    1: 'Threading',
    2: 'JIT Compilation',
    3: 'Full Optimization',
    4: 'GPU Acceleration',
}

# Timeout constants for benchmark initialization (seconds)
_BENCHMARK_SET_LEVEL_TIMEOUT = 45.0  # set_level(4) wait: 30s spawn + 15s buffer
_BENCHMARK_GET_LEVEL_TIMEOUT = 10.0  # get_level() wait after init


@dataclass
class EpochlyConfig:
    """Runtime configuration discovered from Epochly at benchmark time.

    Represents the actual state of the Epochly installation -- level,
    core count, GPU availability, and license tier.  No values are
    overridden or injected; everything is queried from the running system.
    """

    enabled: bool
    enhanced_level: int
    enhanced_level_name: str
    max_cores: Optional[int]
    gpu_enabled: bool
    tier: str
    requested_level: Optional[int] = None
    level_denial_reason: Optional[str] = None

    def __post_init__(self) -> None:
        if self.requested_level is None:
            self.requested_level = self.enhanced_level


class StabilityStatus(str, Enum):
    """Stability classification for a benchmark result."""

    STABLE = "stable"
    UNSTABLE = "unstable"


class SpeedupVerdict(str, Enum):
    """Confidence-interval verdict for a measured speedup."""

    IMPROVED = "improved"
    REGRESSED = "regressed"
    WITHIN_NOISE = "within_noise"


@dataclass
class BenchmarkConfig:
    """Runtime configuration for benchmark statistics and iteration counts."""

    iterations: int = 10
    warmup_iterations: int = 2
    mad_ratio_threshold: float = 0.15
    cv_threshold: float = 0.20
    ci_resamples: int = 1000
    ci_alpha: float = 0.05
    ci_random_seed: int = 0


@dataclass
class BenchmarkResult:
    """Result from a single workload benchmark run."""

    workload_name: str
    display_name: str
    baseline_median: float
    enhanced_median: float
    speedup: float
    enhanced_level: int
    requested_level: Optional[int] = None
    effective_level: Optional[int] = None
    skip_reason: Optional[str] = None
    baseline_times: List[float] = field(default_factory=list)
    enhanced_times: List[float] = field(default_factory=list)
    error: Optional[str] = None
    mad: float = 0.0
    cv: float = 0.0
    stability: StabilityStatus = StabilityStatus.STABLE
    speedup_ci_low: Optional[float] = None
    speedup_ci_high: Optional[float] = None
    speedup_verdict: Optional[SpeedupVerdict] = None

    def __post_init__(self) -> None:
        if self.effective_level is None:
            self.effective_level = self.enhanced_level
        if self.requested_level is None:
            self.requested_level = self.effective_level


def compute_median(times: Sequence[float]) -> float:
    """
    Compute the median of a list of timing values.

    Uses median (not mean) to be robust against outliers from GC pauses,
    OS scheduling, and other transient noise.
    """
    if not times:
        return 0.0
    sorted_times = sorted(times)
    n = len(sorted_times)
    mid = n // 2
    if n % 2 == 0:
        return (sorted_times[mid - 1] + sorted_times[mid]) / 2.0
    return sorted_times[mid]


def compute_mad_ratio(times: Sequence[float]) -> float:
    """Return normalized median absolute deviation for a timing sample."""
    if not times:
        return 0.0
    median = compute_median(times)
    if median <= 0:
        return 0.0
    deviations = [abs(value - median) for value in times]
    return compute_median(deviations) / median


def compute_cv(times: Sequence[float]) -> float:
    """Return coefficient of variation (stdev / mean) for a timing sample."""
    if len(times) < 2:
        return 0.0
    mean_value = statistics.mean(times)
    if mean_value <= 0:
        return 0.0
    return statistics.stdev(times) / mean_value


def _percentile(values: Sequence[float], quantile: float) -> float:
    """Return a linearly interpolated percentile from a sorted value list."""
    if not values:
        return 0.0
    if quantile <= 0:
        return values[0]
    if quantile >= 1:
        return values[-1]

    position = (len(values) - 1) * quantile
    lower_index = int(position)
    upper_index = min(lower_index + 1, len(values) - 1)
    weight = position - lower_index
    return (values[lower_index] * (1.0 - weight)) + (values[upper_index] * weight)


def compute_speedup_confidence_interval(
    baseline_times: Sequence[float],
    enhanced_times: Sequence[float],
    *,
    resamples: int,
    alpha: float,
    seed: int,
) -> Tuple[Optional[float], Optional[float]]:
    """Estimate a bootstrap confidence interval for the speedup ratio."""
    if not baseline_times or not enhanced_times:
        return None, None

    clean_baseline = [value for value in baseline_times if value > 0]
    clean_enhanced = [value for value in enhanced_times if value > 0]
    if not clean_baseline or not clean_enhanced:
        return None, None

    rng = random.Random(seed)
    sample_count = max(resamples, 1000)
    speedups: List[float] = []
    baseline_count = len(clean_baseline)
    enhanced_count = len(clean_enhanced)

    for _ in range(sample_count):
        baseline_sample = [clean_baseline[rng.randrange(baseline_count)] for _ in range(baseline_count)]
        enhanced_sample = [clean_enhanced[rng.randrange(enhanced_count)] for _ in range(enhanced_count)]
        baseline_median = compute_median(baseline_sample)
        enhanced_median = compute_median(enhanced_sample)
        if baseline_median <= 0 or enhanced_median <= 0:
            continue
        speedups.append(baseline_median / enhanced_median)

    if not speedups:
        return None, None

    speedups.sort()
    return (
        _percentile(speedups, alpha / 2.0),
        _percentile(speedups, 1.0 - (alpha / 2.0)),
    )


def derive_speedup_verdict(
    ci_low: Optional[float],
    ci_high: Optional[float],
) -> Optional[SpeedupVerdict]:
    """Derive the speedup verdict from confidence interval bounds."""
    if ci_low is None or ci_high is None:
        return None
    if ci_low > 1.0:
        return SpeedupVerdict.IMPROVED
    if ci_high < 1.0:
        return SpeedupVerdict.REGRESSED
    return SpeedupVerdict.WITHIN_NOISE


def _determine_requested_level() -> int:
    """Return the benchmark's requested enhancement level."""
    env_level = os.environ.get('EPOCHLY_LEVEL')
    if env_level is not None:
        try:
            return min(4, max(0, int(env_level)))
        except (TypeError, ValueError):
            return 4
    return 4


def _derive_level_denial_reason(
    requested_level: int,
    actual_level: int,
    license_info: Optional[dict] = None,
) -> Optional[str]:
    """Classify why the requested benchmark level was not granted."""
    if actual_level >= requested_level:
        return None

    env_cap = os.environ.get('EPOCHLY_MAX_LEVEL')
    if env_cap is not None:
        try:
            capped_level = min(4, max(0, int(env_cap)))
        except (TypeError, ValueError):
            capped_level = None
        if capped_level is not None and requested_level > capped_level and actual_level == capped_level:
            return f'level_{requested_level}_denied_by_env_cap'

    license_info = license_info or {}
    if requested_level >= 4:
        if license_info.get('gpu_enabled') is False:
            return 'level_4_denied_by_license'
        try:
            if not GPUDetector.is_available():
                return 'level_4_denied_by_hardware'
        except Exception:
            pass

    return f'level_{requested_level}_denied_by_gate'


def _request_level_with_normal_gate(epochly_module, requested_level: int) -> int:
    """Request a benchmark level without the public forced set_level path."""
    if requested_level < 0 or requested_level > 4:
        raise ValueError(f'Invalid level {requested_level}. Must be 0-4.')

    core = None
    get_core = getattr(epochly_module, 'get_core', None)
    if callable(get_core):
        core = get_core()

    if core is None:
        ensure_core_initialized = getattr(epochly_module, '_ensure_core_initialized', None)
        if callable(ensure_core_initialized):
            core = ensure_core_initialized()

    if core is None or not hasattr(core, 'set_enhancement_level'):
        raise RuntimeError('Epochly core is unavailable for benchmark level requests')

    level_enum = getattr(epochly_module, 'EnhancementLevel', None)
    if level_enum is None:
        from epochly.core.epochly_core import EnhancementLevel as level_enum

    level_map = {
        0: level_enum.LEVEL_0_MONITOR,
        1: level_enum.LEVEL_1_THREADING,
        2: level_enum.LEVEL_2_JIT,
        3: level_enum.LEVEL_3_FULL,
        4: level_enum.LEVEL_4_GPU,
    }

    core.set_enhancement_level(level_map[requested_level], force=False)
    actual_level = epochly_module.get_level()

    test_mode = os.environ.get('EPOCHLY_TEST_MODE') == '1'
    actual_enum = level_map.get(actual_level)
    if actual_level >= 2 and actual_enum is not None and not test_mode and hasattr(core, 'wait_for_level'):
        timeout = 15.0 if actual_level >= 3 else 10.0
        if not core.wait_for_level(actual_enum, timeout=timeout):
            logging.getLogger('epochly').warning(
                'Timeout waiting for benchmark level %s to be ready after %.1fs.',
                actual_level,
                timeout,
            )

    return actual_level


def _query_epochly_config() -> EpochlyConfig:
    """Query the running Epochly instance for its actual configuration.

    Imports epochly normally (triggering auto_enable with lazy init),
    requests the highest level through the normal core gate, then reads
    back the actual state that Epochly granted.

    CRITICAL FIX (Feb 2026): Check EPOCHLY_DISABLE before attempting init,
    and wrap set_level in a timeout to prevent hanging in restricted
    environments where Level 3 ProcessPool creation blocks forever.

    Returns:
        EpochlyConfig with discovered runtime values.
    """
    try:
        from epochly.monitoring.auto_emergency_detector import emergency_metadata, is_emergency_active
        if is_emergency_active():
            metadata = emergency_metadata()
            return EpochlyConfig(
                enabled=False,
                enhanced_level=0,
                enhanced_level_name='Emergency Disabled',
                max_cores=multiprocessing.cpu_count(),
                gpu_enabled=False,
                tier=f"emergency:{metadata.get('source') or 'detector'}",
            )
    except Exception:
        pass

    # Check if Epochly is explicitly disabled
    if os.environ.get('EPOCHLY_DISABLE', '0') == '1':
        logger.info("Epochly is disabled via EPOCHLY_DISABLE=1")
        return EpochlyConfig(
            enabled=False,
            enhanced_level=0,
            enhanced_level_name='Disabled',
            max_cores=multiprocessing.cpu_count(),
            gpu_enabled=False,
            tier='disabled',
        )

    try:
        import epochly

        # Request the highest level with timeout to prevent hang
        # in restricted environments where Level 3 ProcessPool creation blocks.
        # Timeout = 45s: 30s spawn timeout + 15s buffer for license checks.
        init_done = threading.Event()
        init_error: List[Optional[Exception]] = [None]
        requested_level = _determine_requested_level()

        def _init_with_timeout() -> None:
            try:
                _request_level_with_normal_gate(epochly, requested_level)
            except Exception as e:
                init_error[0] = e
            finally:
                init_done.set()

        t = threading.Thread(target=_init_with_timeout, daemon=True, name="epochly-BenchmarkInit")
        _t_stop_event = threading.Event()
        try:
            from epochly.core.thread_registry import register_thread
            register_thread(t, stop_callback=_t_stop_event.set, name="epochly-BenchmarkInit")
        except ImportError:
            pass
        t.start()
        timed_out = not init_done.wait(timeout=_BENCHMARK_SET_LEVEL_TIMEOUT)
        if timed_out:
            logger.warning(
                "Epochly initialization timed out after 45s. "
                "Running benchmark at current level."
            )
        elif init_error[0]:
            logger.warning("Epochly benchmark level request raised: %s", init_error[0])

        # Wrap get_level in a timeout too - if Epochly init is stuck,
        # get_level() could also hang accessing internal state.
        level_result: List[int] = [0]
        level_done = threading.Event()

        def _get_level() -> None:
            try:
                level_result[0] = epochly.get_level()
            except Exception:
                level_result[0] = 0
            finally:
                level_done.set()

        lt = threading.Thread(target=_get_level, daemon=True, name="epochly-BenchmarkLevel")
        _lt_stop_event = threading.Event()
        try:
            from epochly.core.thread_registry import register_thread
            register_thread(lt, stop_callback=_lt_stop_event.set, name="epochly-BenchmarkLevel")
        except ImportError:
            pass
        lt.start()
        if not level_done.wait(timeout=_BENCHMARK_GET_LEVEL_TIMEOUT):
            logger.warning("epochly.get_level() timed out - returning degraded config")
            return EpochlyConfig(
                enabled=False,
                enhanced_level=0,
                enhanced_level_name='Disabled',
                max_cores=multiprocessing.cpu_count(),
                gpu_enabled=False,
                tier='timeout',
            )

        actual_level = level_result[0]

        # Query license info for reporting
        license_info: dict = {}
        try:
            license_info = epochly.get_license_info()
        except Exception as lic_exc:
            logger.debug("Could not query license info: %s", lic_exc)

        max_cores = license_info.get('max_cores')
        if max_cores is None:
            max_cores = multiprocessing.cpu_count()

        gpu_enabled = license_info.get('gpu_enabled', False)
        tier = license_info.get('tier', 'unknown')
        level_name = LEVEL_NAMES.get(actual_level, f'Level {actual_level}')

        return EpochlyConfig(
            enabled=True,
            enhanced_level=actual_level,
            enhanced_level_name=level_name,
            max_cores=max_cores,
            gpu_enabled=gpu_enabled,
            tier=tier,
            requested_level=requested_level,
            level_denial_reason=_derive_level_denial_reason(
                requested_level,
                actual_level,
                license_info,
            ),
        )

    except Exception as exc:
        logger.warning("Epochly initialization failed: %s", exc)
        return EpochlyConfig(
            enabled=False,
            enhanced_level=0,
            enhanced_level_name='Disabled',
            max_cores=multiprocessing.cpu_count(),
            gpu_enabled=False,
            tier='unavailable',
            requested_level=0,
        )


class BenchmarkRunner:
    """
    Benchmark measurement engine.

    Runs each workload in baseline and enhanced modes, collecting timing
    data and computing speedup statistics.

    The runner uses Epochly exactly as an end user would -- no special
    environment variables, no license overrides, no security bypasses.

    Activation:
      Baseline (Level 0): Monitoring only, no optimizations.
      Enhanced: Whatever level the user's license and hardware support.

    The output reports the actual configuration so users know precisely
    what was measured.
    """

    BASELINE_LEVEL = 0

    def __init__(
        self,
        iterations: int = 10,
        warmup_iterations: int = 2,
        config: Optional[BenchmarkConfig] = None,
    ) -> None:
        self.config = config or BenchmarkConfig(
            iterations=iterations,
            warmup_iterations=warmup_iterations,
        )
        self.iterations = self.config.iterations
        self.warmup_iterations = self.config.warmup_iterations
        self._epochly_config: Optional[EpochlyConfig] = None

    def _ensure_epochly_ready(self) -> EpochlyConfig:
        """Initialize Epochly once and discover the runtime configuration.

        On first call, queries the running Epochly for its actual level,
        core count, GPU status, and license tier.  Subsequent calls return
        the cached configuration.
        """
        if self._epochly_config is not None:
            return self._epochly_config

        self._epochly_config = _query_epochly_config()
        if self._epochly_config.enabled:
            logger.info(
                "Epochly ready: Level %d (%s), %s cores, GPU %s, tier %s",
                self._epochly_config.enhanced_level,
                self._epochly_config.enhanced_level_name,
                self._epochly_config.max_cores or 'all',
                'enabled' if self._epochly_config.gpu_enabled else 'disabled',
                self._epochly_config.tier,
            )
        else:
            logger.warning("Epochly is not available -- benchmarks will run baseline only")

        return self._epochly_config

    def get_epochly_config(self) -> EpochlyConfig:
        """Return the discovered Epochly configuration.

        Initializes Epochly if not already done.
        """
        return self._ensure_epochly_ready()

    def get_applicable_workloads(self) -> Dict[str, WorkloadSpec]:
        """
        Return workloads applicable to the current system.

        GPU workloads are excluded when GPUDetector.is_available() is False.
        """
        all_workloads = get_all_workloads()

        gpu_available = False
        try:
            gpu_available = GPUDetector.is_available()
        except Exception:
            gpu_available = False

        if gpu_available:
            return all_workloads

        return {
            name: spec
            for name, spec in all_workloads.items()
            if spec.category != "gpu"
        }

    def run_single_workload(self, spec: WorkloadSpec) -> BenchmarkResult:
        """
        Run a single workload and return timing results.

        Executes the workload in two phases:
          1. Baseline: Epochly at Level 0 (monitoring only)
          2. Enhanced: Epochly at the user's licensed level

        Each phase includes warmup iterations (discarded) followed by
        measurement iterations (used for median computation).

        If the workload raises an exception, returns a BenchmarkResult
        with error information and zero timing values.
        """
        config = self._ensure_epochly_ready()
        try:
            return self._execute_workload(spec, config)
        except Exception as exc:
            return BenchmarkResult(
                workload_name=spec.code_name,
                display_name=spec.name,
                baseline_median=0.0,
                enhanced_median=0.0,
                speedup=0.0,
                enhanced_level=config.enhanced_level,
                requested_level=config.requested_level,
                effective_level=config.enhanced_level,
                baseline_times=[],
                enhanced_times=[],
                error=f"{type(exc).__name__}: {exc}",
                stability=StabilityStatus.UNSTABLE,
            )

    def _execute_workload(
        self, spec: WorkloadSpec, config: EpochlyConfig
    ) -> BenchmarkResult:
        """Execute a workload in baseline (Level 0) and enhanced modes.

        The enhanced phase wraps the workload function with an explicit
        ``@epochly_run`` decorator so that JIT compilation and other
        optimizations actually apply.  This matches the real user workflow
        of decorating the function you want to speed up.

        GPU workloads use a setup/compute split: ``spec.setup(size)``
        pre-allocates input arrays, and ``spec.execute(*args)`` runs the
        computation.  This mirrors how a real user writes Epochly code —
        set up your data, then call the decorated function in a loop:

            field = make_field(1000)
            for step in range(100):
                field = stencil_step(field, alpha)

        The pattern detector needs to see ndarray arguments (not a
        monolithic function that mixes allocation with computation) to
        successfully detect stencil / map / reduce patterns for GPU
        compilation.

        Without decoration, ``set_level()`` alone only enables the
        sys.monitoring auto-profiler which requires many more invocations
        and favourable conditions to detect and compile hot loops --
        producing misleading 1.0x results in a short benchmark run.

        See: planning/CRITICAL_RCA_BENCHMARK_CONTRADICTIONS.md
        See: planning/MULTICORE_BENCHMARK_STRATEGY_RESOLUTION.md
        """
        import epochly
        from epochly import epochly_run, EnhancementLevel

        _jit_workloads = ('jit_polynomial', 'jit_numerical', 'monte_carlo', 'nested_loop')
        _gpu_workloads = ('gpu_elementwise', 'gpu_reduction', 'gpu_convolution')

        setup_fn = spec.setup

        # --- Prepare arguments ---
        # GPU workloads with setup: call setup once to get pre-allocated arrays.
        # CPU workloads: pass size as the single argument (existing behavior).
        if setup_fn is not None:
            setup_args = setup_fn(spec.size)
        else:
            setup_args = (spec.size,)

        # --- Phase 1: Baseline (Level 0, no optimizations) ---
        epochly.set_level(self.BASELINE_LEVEL)
        baseline_times = self._time_iterations_args(spec.execute, setup_args)

        if spec.category == 'gpu' and config.enhanced_level < 4:
            baseline_median = compute_median(baseline_times)
            skip_reason = config.level_denial_reason or 'level_4_denied_by_gate'
            return BenchmarkResult(
                workload_name=spec.code_name,
                display_name=spec.name,
                baseline_median=baseline_median,
                enhanced_median=0.0,
                speedup=0.0,
                enhanced_level=config.enhanced_level,
                requested_level=config.requested_level,
                effective_level=config.enhanced_level,
                skip_reason=skip_reason,
                baseline_times=list(baseline_times),
                enhanced_times=[],
            )

        # --- Phase 2: Enhanced (decorated for JIT/GPU) ---
        epochly.set_level(config.enhanced_level)

        if config.enhanced_level >= 4 and spec.code_name in _gpu_workloads:
            enhanced_fn = epochly_run(level=EnhancementLevel.LEVEL_4_GPU)(spec.execute)
        elif config.enhanced_level >= 2 and spec.code_name in _jit_workloads:
            enhanced_fn = epochly_run(level=EnhancementLevel.LEVEL_2_JIT)(spec.execute)
        else:
            enhanced_fn = spec.execute

        # Warmup: JIT compilation and GPU kernel compilation happen on
        # first calls.  We need enough warmup to amortize compilation
        # overhead and allow the auto_profiler to promote to GPU.
        warmup_count = max(self.warmup_iterations, 5)
        for _ in range(warmup_count):
            enhanced_fn(*setup_args)

        # Measure using the decorated function
        enhanced_times = self._time_iterations_args(enhanced_fn, setup_args)

        # Restore to baseline level for next workload
        epochly.set_level(self.BASELINE_LEVEL)

        return self._build_result(
            spec,
            config,
            baseline_times,
            enhanced_times,
        )

    def _build_result(
        self,
        spec: WorkloadSpec,
        config: EpochlyConfig,
        baseline_times: Sequence[float],
        enhanced_times: Sequence[float],
    ) -> BenchmarkResult:
        """Build a BenchmarkResult with stability and confidence interval metadata."""
        baseline_median = compute_median(baseline_times)
        enhanced_median = compute_median(enhanced_times)

        if enhanced_median > 0 and baseline_median > 0:
            speedup = baseline_median / enhanced_median
        else:
            speedup = 0.0

        mad = max(
            compute_mad_ratio(baseline_times),
            compute_mad_ratio(enhanced_times),
        )
        cv = max(
            compute_cv(baseline_times),
            compute_cv(enhanced_times),
        )
        stability = StabilityStatus.STABLE
        if mad > self.config.mad_ratio_threshold or cv > self.config.cv_threshold:
            stability = StabilityStatus.UNSTABLE

        speedup_ci_low, speedup_ci_high = compute_speedup_confidence_interval(
            baseline_times,
            enhanced_times,
            resamples=self.config.ci_resamples,
            alpha=self.config.ci_alpha,
            seed=self.config.ci_random_seed,
        )
        speedup_verdict = None
        if stability is StabilityStatus.STABLE:
            speedup_verdict = derive_speedup_verdict(speedup_ci_low, speedup_ci_high)

        return BenchmarkResult(
            workload_name=spec.code_name,
            display_name=spec.name,
            baseline_median=baseline_median,
            enhanced_median=enhanced_median,
            speedup=speedup,
            enhanced_level=config.enhanced_level,
            requested_level=config.requested_level,
            effective_level=config.enhanced_level,
            baseline_times=list(baseline_times),
            enhanced_times=list(enhanced_times),
            mad=mad,
            cv=cv,
            stability=stability,
            speedup_ci_low=speedup_ci_low,
            speedup_ci_high=speedup_ci_high,
            speedup_verdict=speedup_verdict,
        )

    def _time_iterations_args(
        self, fn: Callable, args: tuple
    ) -> List[float]:
        """
        Time a callable with pre-built arguments.

        Runs ``fn(*args)`` for ``self.iterations`` iterations and returns
        the elapsed time in milliseconds for each.  The caller is
        responsible for any warmup before calling this method.

        This unified method handles both CPU workloads (args = (size,))
        and GPU workloads (args = (ndarray, ...)) with the same code path.
        """
        times: List[float] = []
        for _ in range(self.iterations):
            start = time.perf_counter()
            fn(*args)
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            times.append(elapsed_ms)

        return times
