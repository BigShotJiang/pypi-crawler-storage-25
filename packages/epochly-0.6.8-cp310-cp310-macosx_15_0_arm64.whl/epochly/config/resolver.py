"""Single-source-of-truth configuration resolver for Epochly boot/runtime config."""

from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Any, Callable, Mapping, Optional

import yaml  # type: ignore[import-untyped]

from .defaults import (
    DEFAULTS,
    DEFAULT_API_KEY,
    DEFAULT_DEBUG,
    DEFAULT_DISABLE,
    DEFAULT_DISABLE_AUTO_INIT,
    DEFAULT_DISABLE_INTERCEPTION,
    DEFAULT_DISABLE_SETPROFILE,
    DEFAULT_EAGER_INIT,
    DEFAULT_FORCE_LEVEL,
    DEFAULT_FORCE_LEVEL3,
    DEFAULT_FORCE_SETPROFILE,
    DEFAULT_GPU_ENABLED,
    DEFAULT_INFERENCE_PRIVACY_AUDIT_LOG_ENABLED,
    DEFAULT_INFERENCE_PRIVACY_REDACT_PATTERNS,
    DEFAULT_JIT_ENABLED,
    DEFAULT_LEVEL3_LOOP_TRANSFORM_MIN_MS,
    DEFAULT_LEVEL3_MIN_ITERATIONS,
    DEFAULT_LEVEL3_MIN_WORK_MS,
    DEFAULT_LEVEL3_STACKING_IPC_OVERHEAD_MS,
    DEFAULT_LEVEL3_USE_LOOP_TRANSFORMER,
    DEFAULT_MAX_LEVEL,
    DEFAULT_MAX_WORKERS,
    DEFAULT_MODE,
    DEFAULT_NO_STATE_RESTORE,
    DEFAULT_OFFLINE_MODE,
    DEFAULT_SHOW_NUMBA_WARNINGS,
    DEFAULT_SKIP_FORKSERVER_VIABILITY,
    DEFAULT_STATE_DIR,
    DEFAULT_STRICT_INIT,
    DEFAULT_TELEMETRY,
    DEFAULT_TEST_MODE,
)

ENV_LEVEL = "EPOCHLY_LEVEL"
ENV_ENHANCEMENT_LEVEL = "EPOCHLY_ENHANCEMENT_LEVEL"
ENV_MAX_LEVEL = "EPOCHLY_MAX_LEVEL"
ENV_MODE = "EPOCHLY_MODE"
ENV_DISABLE = "EPOCHLY_DISABLE"
ENV_NO_PROFILER = "EPOCHLY_NO_PROFILER"
ENV_FORCE_LEVEL = "EPOCHLY_FORCE_LEVEL"
ENV_FORCE_LEVEL3 = "EPOCHLY_FORCE_LEVEL3"
ENV_GPU_DISABLE = "EPOCHLY_GPU_DISABLE"
ENV_AUTO_ENABLE = "EPOCHLY_AUTO_ENABLE"
ENV_STRICT_INIT = "EPOCHLY_STRICT_INIT"
ENV_DEBUG = "EPOCHLY_DEBUG"
ENV_TEST_MODE = "EPOCHLY_TEST_MODE"
ENV_NO_STATE_RESTORE = "EPOCHLY_NO_STATE_RESTORE"
ENV_STATE_DIR = "EPOCHLY_STATE_DIR"
ENV_DEV_BYPASS = "EPOCHLY_DEV_BYPASS"
ENV_EAGER_INIT = "EPOCHLY_EAGER_INIT"
ENV_DISABLE_AUTO_INIT = "EPOCHLY_DISABLE_AUTO_INIT"
ENV_DISABLE_SETPROFILE = "EPOCHLY_DISABLE_SETPROFILE"
ENV_FORCE_SETPROFILE = "EPOCHLY_FORCE_SETPROFILE"
ENV_DISABLE_INTERCEPTION = "EPOCHLY_DISABLE_INTERCEPTION"
ENV_JIT_ENABLED = "EPOCHLY_JIT_ENABLED"
ENV_OFFLINE_MODE = "EPOCHLY_OFFLINE_MODE"
ENV_SKIP_FORKSERVER_VIABILITY = "EPOCHLY_SKIP_FORKSERVER_VIABILITY"
ENV_SHOW_NUMBA_WARNINGS = "EPOCHLY_SHOW_NUMBA_WARNINGS"
ENV_API_KEY = "EPOCHLY_API_KEY"
ENV_MAX_WORKERS = "EPOCHLY_MAX_WORKERS"
ENV_LEVEL3_USE_LOOP_TRANSFORMER = "EPOCHLY_LEVEL3_USE_LOOP_TRANSFORMER"
ENV_LEVEL3_MIN_WORK_MS = "EPOCHLY_LEVEL3_MIN_WORK_MS"
ENV_LEVEL3_MIN_ITERATIONS = "EPOCHLY_LEVEL3_MIN_ITERATIONS"
ENV_LEVEL3_LOOP_TRANSFORM_MIN_MS = "EPOCHLY_LEVEL3_LOOP_TRANSFORM_MIN_MS"
ENV_LEVEL3_STACKING_IPC_OVERHEAD_MS = "EPOCHLY_LEVEL3_STACKING_IPC_OVERHEAD_MS"
ENV_INFERENCE_PRIVACY_REDACT_PATTERNS = "EPOCHLY_INFERENCE_PRIVACY_REDACT_PATTERNS"
ENV_INFERENCE_PRIVACY_AUDIT_LOG_ENABLED = "EPOCHLY_INFERENCE_PRIVACY_AUDIT_LOG_ENABLED"
ENV_CONFIG_DIR = "EPOCHLY_CONFIG_DIR"
ENV_EMERGENCY_DISABLE = "EPOCHLY_EMERGENCY_DISABLE"

_TRUE_VALUES = {"1", "true", "yes", "on"}
_FALSE_VALUES = {"", "0", "false", "no", "off"}
_RUNTIME_LOCK = threading.Lock()
_RUNTIME_OVERRIDES: dict[str, Any] = {}


class ConfigValidationError(ValueError):
    """Raised when an invalid config combination is resolved."""


class _Spec:
    def __init__(
        self,
        default: Any,
        parser: Callable[[Any], Any],
        *,
        env_names: tuple[str, ...],
        file_keys: tuple[str, ...] = (),
    ) -> None:
        self.default = default
        self.parser = parser
        self.env_names = env_names
        self.file_keys = file_keys or ()


def _parse_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    normalized = str(value).strip().lower()
    if normalized in _TRUE_VALUES:
        return True
    if normalized in _FALSE_VALUES:
        return False
    raise ValueError(f"Invalid boolean value: {value!r}")


def _parse_optional_bool(value: Any) -> Optional[bool]:
    if value is None:
        return None
    return _parse_bool(value)


def _parse_int(value: Any) -> int:
    if isinstance(value, bool):
        raise ValueError(f"Invalid integer value: {value!r}")
    return int(str(value).strip())


def _parse_optional_int(value: Any) -> Optional[int]:
    if value in (None, ""):
        return None
    return _parse_int(value)


def _parse_float(value: Any) -> float:
    return float(str(value).strip())


def _parse_text(value: Any) -> str:
    return "" if value is None else str(value)


_SPECS: dict[str, _Spec] = {
    "mode": _Spec(DEFAULT_MODE, _parse_text, env_names=(ENV_MODE,), file_keys=("mode",)),
    "max_level": _Spec(DEFAULT_MAX_LEVEL, _parse_int, env_names=(ENV_MAX_LEVEL,), file_keys=("max_level",)),
    "enhancement_level": _Spec(None, _parse_optional_int, env_names=(ENV_LEVEL, ENV_ENHANCEMENT_LEVEL), file_keys=("enhancement_level", "level")),
    "disable": _Spec(DEFAULT_DISABLE, _parse_bool, env_names=(ENV_DISABLE,), file_keys=("disable",)),
    "force_level": _Spec(DEFAULT_FORCE_LEVEL, _parse_bool, env_names=(ENV_FORCE_LEVEL,), file_keys=("force_level",)),
    "force_level3": _Spec(DEFAULT_FORCE_LEVEL3, _parse_bool, env_names=(ENV_FORCE_LEVEL3,), file_keys=("force_level3",)),
    "gpu_enabled": _Spec(DEFAULT_GPU_ENABLED, _parse_bool, env_names=(), file_keys=("gpu_enabled",)),
    "auto_enable": _Spec(False, _parse_bool, env_names=(ENV_AUTO_ENABLE,), file_keys=("auto_enable",)),
    "strict_init": _Spec(DEFAULT_STRICT_INIT, _parse_bool, env_names=(ENV_STRICT_INIT,), file_keys=("strict_init",)),
    "debug": _Spec(DEFAULT_DEBUG, _parse_bool, env_names=(ENV_DEBUG,), file_keys=("debug",)),
    "test_mode": _Spec(DEFAULT_TEST_MODE, _parse_bool, env_names=(ENV_TEST_MODE,), file_keys=("test_mode",)),
    "no_state_restore": _Spec(DEFAULT_NO_STATE_RESTORE, _parse_bool, env_names=(ENV_NO_STATE_RESTORE,), file_keys=("no_state_restore",)),
    "state_dir": _Spec(DEFAULT_STATE_DIR, _parse_text, env_names=(ENV_STATE_DIR,), file_keys=("state_dir",)),
    "dev_bypass": _Spec(False, _parse_bool, env_names=(ENV_DEV_BYPASS,), file_keys=("dev_bypass",)),
    "eager_init": _Spec(DEFAULT_EAGER_INIT, _parse_bool, env_names=(ENV_EAGER_INIT,), file_keys=("eager_init",)),
    "disable_auto_init": _Spec(DEFAULT_DISABLE_AUTO_INIT, _parse_bool, env_names=(ENV_DISABLE_AUTO_INIT,), file_keys=("disable_auto_init",)),
    "disable_setprofile": _Spec(DEFAULT_DISABLE_SETPROFILE, _parse_bool, env_names=(ENV_DISABLE_SETPROFILE,), file_keys=("disable_setprofile",)),
    "force_setprofile": _Spec(DEFAULT_FORCE_SETPROFILE, _parse_bool, env_names=(ENV_FORCE_SETPROFILE,), file_keys=("force_setprofile",)),
    "disable_interception": _Spec(DEFAULT_DISABLE_INTERCEPTION, _parse_bool, env_names=(ENV_DISABLE_INTERCEPTION,), file_keys=("disable_interception",)),
    "jit_enabled": _Spec(DEFAULT_JIT_ENABLED, _parse_bool, env_names=(ENV_JIT_ENABLED,), file_keys=("jit_enabled",)),
    "offline_mode": _Spec(DEFAULT_OFFLINE_MODE, _parse_bool, env_names=(ENV_OFFLINE_MODE,), file_keys=("offline_mode",)),
    "skip_forkserver_viability": _Spec(DEFAULT_SKIP_FORKSERVER_VIABILITY, _parse_bool, env_names=(ENV_SKIP_FORKSERVER_VIABILITY,), file_keys=("skip_forkserver_viability",)),
    "show_numba_warnings": _Spec(DEFAULT_SHOW_NUMBA_WARNINGS, _parse_bool, env_names=(ENV_SHOW_NUMBA_WARNINGS,), file_keys=("show_numba_warnings",)),
    "api_key": _Spec(DEFAULT_API_KEY, _parse_text, env_names=(ENV_API_KEY,), file_keys=("api_key",)),
    "max_workers": _Spec(DEFAULT_MAX_WORKERS, _parse_optional_int, env_names=(ENV_MAX_WORKERS,), file_keys=("max_workers",)),
    "level3_use_loop_transformer": _Spec(DEFAULT_LEVEL3_USE_LOOP_TRANSFORMER, _parse_optional_bool, env_names=(ENV_LEVEL3_USE_LOOP_TRANSFORMER,), file_keys=("level3_use_loop_transformer",)),
    "level3_min_work_ms": _Spec(DEFAULT_LEVEL3_MIN_WORK_MS, _parse_float, env_names=(ENV_LEVEL3_MIN_WORK_MS,), file_keys=("level3_min_work_ms",)),
    "level3_min_iterations": _Spec(DEFAULT_LEVEL3_MIN_ITERATIONS, _parse_int, env_names=(ENV_LEVEL3_MIN_ITERATIONS,), file_keys=("level3_min_iterations",)),
    "level3_loop_transform_min_ms": _Spec(DEFAULT_LEVEL3_LOOP_TRANSFORM_MIN_MS, _parse_float, env_names=(ENV_LEVEL3_LOOP_TRANSFORM_MIN_MS,), file_keys=("level3_loop_transform_min_ms",)),
    "level3_stacking_ipc_overhead_ms": _Spec(DEFAULT_LEVEL3_STACKING_IPC_OVERHEAD_MS, _parse_float, env_names=(ENV_LEVEL3_STACKING_IPC_OVERHEAD_MS,), file_keys=("level3_stacking_ipc_overhead_ms",)),
    "inference_privacy_redact_patterns": _Spec(DEFAULT_INFERENCE_PRIVACY_REDACT_PATTERNS, _parse_text, env_names=(ENV_INFERENCE_PRIVACY_REDACT_PATTERNS,), file_keys=("inference_privacy_redact_patterns",)),
    "inference_privacy_audit_log_enabled": _Spec(DEFAULT_INFERENCE_PRIVACY_AUDIT_LOG_ENABLED, _parse_bool, env_names=(ENV_INFERENCE_PRIVACY_AUDIT_LOG_ENABLED,), file_keys=("inference_privacy_audit_log_enabled",)),
    "telemetry": _Spec(DEFAULT_TELEMETRY, _parse_bool, env_names=(), file_keys=("telemetry",)),
}


class ConfigResolver:
    """Resolve config with runtime > cli > env > file > defaults precedence."""

    def __init__(
        self,
        *,
        runtime_overrides: Optional[Mapping[str, Any]] = None,
        cli_overrides: Optional[Mapping[str, Any]] = None,
        env: Optional[Mapping[str, str]] = None,
        cwd: Optional[Path | str] = None,
    ) -> None:
        self.runtime_overrides = dict(runtime_overrides or {})
        self.cli_overrides = dict(cli_overrides or {})
        self.env = dict({} if env is None else env)
        self.cwd = Path(cwd) if cwd is not None else Path.cwd()
        self._resolved: Optional[dict[str, Any]] = None
        self._sources: dict[str, str] = {}

    def _file_candidates(self) -> list[Path]:
        candidates: list[Path] = []
        config_dir = self.env.get(ENV_CONFIG_DIR)
        if config_dir:
            candidates.append(Path(config_dir) / 'config.yaml')
            candidates.append(Path(config_dir) / 'config.yml')
        candidates.append(self.cwd / '.epochly' / 'config.yaml')
        candidates.append(self.cwd / '.epochly' / 'config.yml')
        return candidates

    def _load_file_config(self) -> dict[str, Any]:
        merged: dict[str, Any] = {}
        for path in self._file_candidates():
            if not path.exists() or not path.is_file():
                continue
            try:
                loaded = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
            except Exception:
                continue
            if not isinstance(loaded, dict):
                continue
            raw: dict[str, Any] = dict(loaded)
            epochly_section = raw.get('epochly')
            section: dict[str, Any] = dict(epochly_section) if isinstance(epochly_section, dict) else {}
            normalized: dict[str, Any] = dict(raw)
            normalized.update(section)
            merged.update(normalized)
        return merged

    def _apply_value(self, key: str, raw_value: Any, source: str) -> None:
        assert self._resolved is not None
        spec = _SPECS[key]
        if key == 'gpu_enabled' and source == 'env':
            parsed = not _parse_bool(raw_value)
        else:
            parsed = spec.parser(raw_value)
        self._resolved[key] = parsed
        self._sources[key] = source

    def resolve(self) -> dict[str, Any]:
        if self._resolved is not None:
            return dict(self._resolved)

        self._resolved = dict(DEFAULTS)
        self._sources = {key: 'default' for key in self._resolved}
        file_config = self._load_file_config()

        for key, spec in _SPECS.items():
            for file_key in spec.file_keys:
                if file_key in file_config:
                    self._apply_value(key, file_config[file_key], 'file')
                    break

        if ENV_GPU_DISABLE in self.env:
            self._apply_value('gpu_enabled', self.env[ENV_GPU_DISABLE], 'env')

        for key, spec in _SPECS.items():
            for env_name in spec.env_names:
                if env_name in self.env:
                    self._apply_value(key, self.env[env_name], 'env')
                    break

        for key, value in self.cli_overrides.items():
            if key in _SPECS:
                self._resolved[key] = value
                self._sources[key] = 'cli'

        with _RUNTIME_LOCK:
            merged_runtime = dict(_RUNTIME_OVERRIDES)
        merged_runtime.update(self.runtime_overrides)
        for key, value in merged_runtime.items():
            if key in _SPECS:
                self._resolved[key] = value
                self._sources[key] = 'runtime'

        return dict(self._resolved)

    def source_of(self, key: str) -> str:
        if self._resolved is None:
            self.resolve()
        return self._sources[key]

    def validate(self, resolved: Optional[Mapping[str, Any]] = None) -> dict[str, Any]:
        cfg = dict(self.resolve() if resolved is None else resolved)
        if cfg.get('disable') and cfg.get('force_level'):
            raise ConfigValidationError('disable and force_level cannot both be enabled')
        if cfg.get('disable') and cfg.get('force_level3'):
            raise ConfigValidationError('disable and force_level3 cannot both be enabled')
        if (cfg.get('enhancement_level') or 0) >= 4 and not cfg.get('gpu_enabled', True):
            raise ConfigValidationError('enhancement_level requires gpu_enabled when requesting level 4')
        return cfg


def set_runtime_override(key: str, value: Any) -> None:
    with _RUNTIME_LOCK:
        _RUNTIME_OVERRIDES[key] = value


def clear_runtime_overrides() -> None:
    with _RUNTIME_LOCK:
        _RUNTIME_OVERRIDES.clear()


def env_get(name: str, default: Any = None, *, env: Optional[Mapping[str, str]] = None) -> Any:
    source = os.environ if env is None else env
    return source.get(name, default)


def env_truthy(name: str, *, env: Optional[Mapping[str, str]] = None) -> bool:
    value = env_get(name, None, env=env)
    if value is None:
        return False
    try:
        return _parse_bool(value)
    except ValueError:
        return False


def clear_process_env(name: str) -> None:
    os.environ.pop(name, None)


def set_process_env(name: str, value: Any) -> None:
    os.environ[name] = str(value)


def resolve_current_config(*, cwd: Optional[Path | str] = None) -> dict[str, Any]:
    return ConfigResolver(env=os.environ, cwd=cwd).resolve()


def get_config_value(key: str, default: Any = None, *, cwd: Optional[Path | str] = None) -> Any:
    resolved = resolve_current_config(cwd=cwd)
    return resolved.get(key, default)


def validate_current_config(*, cwd: Optional[Path | str] = None) -> dict[str, Any]:
    resolver = ConfigResolver(env=os.environ, cwd=cwd)
    resolved = resolver.resolve()
    return resolver.validate(resolved)
