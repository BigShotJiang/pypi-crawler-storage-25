"""
Batch Dispatcher - Automatic Loop Parallelization

Detects loop patterns and automatically dispatches iterations to workers in batches.

Architecture:
1. Detect loop pattern (for i in range(N): ...)
2. Extract loop body as callable
3. Slice iterations into chunks
4. Dispatch chunks to Level 3 executor
5. Collect and merge results

Author: Epochly Development Team
Date: November 17, 2025
"""

import atexit
import sys
import dis
import types
import inspect
import logging
import os
import hashlib
import shutil
import tempfile
import threading
from typing import Callable, List, Any, Optional, Tuple, Dict
from concurrent.futures import Future
from dataclasses import dataclass

from ..utils.logger import get_logger
from .executor_adapter import ExecutorAdapter, UnifiedResult

logger = get_logger(__name__)

# Debug instrumentation control (conditional via environment variable)
# Enable with: export EPOCHLY_DEBUG_PARALLELIZATION=1
_DEBUG_PARALLELIZATION = os.environ.get('EPOCHLY_DEBUG_PARALLELIZATION', '').lower() in ('1', 'true', 'yes')
_TRACE_FILE = os.path.join(tempfile.gettempdir(), 'epochly_worker_trace.txt')

# Global persistent pool for batch dispatch (eliminates creation overhead)
# CRITICAL: Initialize lock at module level to prevent race condition
_global_pool = None
_global_pool_lock = threading.Lock()
_WORKER_JIT_CACHE: Dict[str, Any] = {}
_WORKER_REDUCED_JIT_CACHE: Dict[str, Any] = {}
_WORKER_JIT_FALLBACK = object()
_WORKER_JIT_OVERHEAD_MS_CACHE: Dict[str, float] = {}
_WORKER_RUNTIME_PID: Optional[int] = None
_WORKER_NUMBA_CACHE_DIR: Optional[str] = None
_WORKER_CACHE_CLEANUP_REGISTERED = False
_WORKER_CACHE_CLEANUP_PID: Optional[int] = None
_GLOBAL_POOL_CLEANUP_REGISTERED = False


class _UnsafeReplayError(Exception):
    """Internal signal: collection failed but some ProcessPool workers
    may still be running.  Sequential replay of their iterations would
    duplicate side effects.  Caught by the outer exception handler to
    return None without replaying."""
    pass


def _trace_worker_event(pid: int, message: str) -> None:
    """
    Write worker trace event with proper locking (debug mode only).

    Best-effort logging that never fails. Uses file locking on POSIX systems
    for thread-safe concurrent writes.

    Args:
        pid: Worker process ID
        message: Event message to log
    """
    if not _DEBUG_PARALLELIZATION:
        return

    try:
        with open(_TRACE_FILE, 'a') as f:
            # Add file locking on POSIX systems (not available on Windows)
            try:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                f.write(f"PID {pid}: {message}\n")
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            except (ImportError, AttributeError):
                # fcntl not available on Windows - write without locking
                f.write(f"PID {pid}: {message}\n")
    except (IOError, OSError):
        # File I/O failed - silently ignore (debug tracing is best-effort)
        pass


def _worker_jit_cache_key_from_payload(pickled_func: bytes) -> str:
    """Build a stable per-function cache key for worker-side JIT reuse."""
    return hashlib.sha1(pickled_func).hexdigest()


def _cleanup_numba_cache_dir(cache_dir: Optional[str]) -> None:
    """Best-effort cleanup for worker-local Numba cache directories."""
    if not cache_dir:
        return

    abs_cache_dir = os.path.abspath(cache_dir)
    temp_root = os.path.abspath(tempfile.gettempdir())
    if (
        os.path.basename(abs_cache_dir).startswith("epochly-numba-cache-")
        and abs_cache_dir.startswith(temp_root + os.sep)
    ):
        shutil.rmtree(abs_cache_dir, ignore_errors=True)


def _cleanup_worker_runtime_cache_dir() -> None:
    """Remove the current worker process cache directory on interpreter exit."""
    global _WORKER_RUNTIME_PID, _WORKER_NUMBA_CACHE_DIR

    _cleanup_numba_cache_dir(_WORKER_NUMBA_CACHE_DIR)
    _WORKER_NUMBA_CACHE_DIR = None
    _WORKER_RUNTIME_PID = None


def _register_worker_cache_cleanup(pid: int) -> None:
    """Register worker cache cleanup once per worker process."""
    global _WORKER_CACHE_CLEANUP_REGISTERED, _WORKER_CACHE_CLEANUP_PID

    if _WORKER_CACHE_CLEANUP_PID != pid:
        _WORKER_CACHE_CLEANUP_REGISTERED = False

    if _WORKER_CACHE_CLEANUP_REGISTERED:
        return

    atexit.register(_cleanup_worker_runtime_cache_dir)
    _WORKER_CACHE_CLEANUP_REGISTERED = True
    _WORKER_CACHE_CLEANUP_PID = pid


def _cleanup_pool_worker_numba_cache_dirs(worker_pids: List[int]) -> None:
    """Best-effort cleanup for cache directories belonging to pool workers."""
    for worker_pid in worker_pids:
        if worker_pid is None:
            continue
        _cleanup_numba_cache_dir(
            os.path.join(
                tempfile.gettempdir(),
                f"epochly-numba-cache-{worker_pid}",
            )
        )


def _get_pool_worker_pids(pool: Any) -> List[int]:
    """Return stable worker PIDs for a multiprocessing.Pool-like object."""
    worker_pids: List[int] = []
    for worker in getattr(pool, "_pool", []) or []:
        pid = getattr(worker, "pid", None)
        if pid is None:
            continue
        try:
            worker_pids.append(int(pid))
        except (TypeError, ValueError):
            continue
    return worker_pids


def _cleanup_global_pool() -> None:
    """Close the persistent pool and clean up any worker-local cache dirs."""
    global _global_pool

    pool = _global_pool
    if pool is None:
        return

    worker_pids = _get_pool_worker_pids(pool)
    _global_pool = None

    try:
        pool.close()
    except Exception:
        logger.debug("Persistent pool close failed; attempting terminate", exc_info=True)
        try:
            pool.terminate()
        except Exception:
            logger.debug("Persistent pool terminate failed", exc_info=True)
    finally:
        try:
            pool.join()
        except Exception:
            logger.debug("Persistent pool join failed", exc_info=True)
        _cleanup_pool_worker_numba_cache_dirs(worker_pids)


def _parent_jit_overhead_cache_key(loop_func: Callable) -> str:
    """Build a stable cache key for parent-side worker JIT warmup estimates."""
    code = getattr(loop_func, "__code__", None)
    if code is None:
        return f"{getattr(loop_func, '__module__', 'unknown')}:{getattr(loop_func, '__qualname__', repr(loop_func))}"

    digest = hashlib.sha1()
    digest.update(code.co_code)
    digest.update(repr(code.co_consts).encode("utf-8", errors="ignore"))
    digest.update(repr(getattr(loop_func, "__defaults__", None)).encode("utf-8", errors="ignore"))
    return (
        f"{getattr(loop_func, '__module__', 'unknown')}:"
        f"{getattr(loop_func, '__qualname__', getattr(loop_func, '__name__', 'unknown'))}:"
        f"{digest.hexdigest()}"
    )


def _compile_loop_func_for_worker(loop_func: Callable, cache_key: str) -> Any:
    """Compile a worker loop body with Numba once per worker process."""
    cached = _WORKER_JIT_CACHE.get(cache_key)
    if cached is not None:
        return cached

    candidate = getattr(loop_func, "py_func", loop_func)

    try:
        import numba

        compiled = numba.njit(cache=False)(candidate)
        _WORKER_JIT_CACHE[cache_key] = compiled
        return compiled
    except Exception as exc:
        logger.debug(
            "Worker-side JIT compilation unavailable for %s: %s",
            getattr(candidate, "__name__", repr(candidate)),
            exc,
        )
        _WORKER_JIT_CACHE[cache_key] = _WORKER_JIT_FALLBACK
        return _WORKER_JIT_FALLBACK


def _compile_reduced_loop_func_for_worker(
    loop_func: Callable,
    cache_key: str,
    sample_index: int,
) -> Any:
    """Compile a whole reduced chunk executor once per worker process."""
    cached = _WORKER_REDUCED_JIT_CACHE.get(cache_key)
    if cached is not None:
        return cached

    compiled_body = _compile_loop_func_for_worker(loop_func, cache_key)
    if compiled_body is _WORKER_JIT_FALLBACK:
        _WORKER_REDUCED_JIT_CACHE[cache_key] = _WORKER_JIT_FALLBACK
        return _WORKER_JIT_FALLBACK

    try:
        import numba

        sample_value = compiled_body(sample_index)
        if isinstance(sample_value, tuple):
            _WORKER_REDUCED_JIT_CACHE[cache_key] = _WORKER_JIT_FALLBACK
            return _WORKER_JIT_FALLBACK

        zero_seed = sample_value - sample_value

        @numba.njit(cache=False)
        def compiled_reducer(start: int, end: int, step: int, zero):
            total = zero
            for i in range(start, end, step):
                total += compiled_body(i)
            return total

        compiled_reducer(sample_index, sample_index + 1, 1, zero_seed)
        compiled_entry = (compiled_reducer, zero_seed)
        _WORKER_REDUCED_JIT_CACHE[cache_key] = compiled_entry
        return compiled_entry
    except Exception as exc:
        logger.debug(
            "Worker-side reduced JIT compilation unavailable for %s: %s",
            getattr(loop_func, "__name__", repr(loop_func)),
            exc,
        )
        _WORKER_REDUCED_JIT_CACHE[cache_key] = _WORKER_JIT_FALLBACK
        return _WORKER_JIT_FALLBACK


def _configure_worker_runtime() -> str:
    """Isolate per-worker Numba cache files by PID."""
    global _WORKER_RUNTIME_PID, _WORKER_NUMBA_CACHE_DIR

    pid = os.getpid()
    cache_dir = os.path.join(tempfile.gettempdir(), f"epochly-numba-cache-{pid}")
    if _WORKER_RUNTIME_PID != pid or _WORKER_NUMBA_CACHE_DIR != cache_dir:
        os.makedirs(cache_dir, exist_ok=True)
        _WORKER_RUNTIME_PID = pid
        _WORKER_NUMBA_CACHE_DIR = cache_dir

    _register_worker_cache_cleanup(pid)

    os.environ["NUMBA_CACHE_DIR"] = cache_dir

    numba_module = sys.modules.get("numba")
    if numba_module is not None:
        try:
            from numba import config as _numba_config

            if hasattr(_numba_config, "CACHE_DIR"):
                _numba_config.CACHE_DIR = cache_dir
            set_num_threads = getattr(numba_module, "set_num_threads", None)
            if callable(set_num_threads):
                set_num_threads(1)
        except Exception:
            logger.debug("Worker runtime config: unable to sync imported numba settings", exc_info=True)

    return cache_dir


@dataclass
class LoopPattern:
    """
    Detected loop pattern information.

    Attributes:
        code_object: Code object containing the loop
        loop_start_offset: Bytecode offset where loop starts
        loop_end_offset: Bytecode offset where loop ends
        iteration_variable: Name of loop variable (e.g., 'i')
        range_start: Start of range (if detectable)
        range_end: End of range (if detectable)
        range_step: Step of range (default 1)
        is_parallelizable: Whether loop can be safely parallelized
    """
    code_object: object
    loop_start_offset: int
    loop_end_offset: int
    iteration_variable: Optional[str] = None
    range_start: Optional[int] = None
    range_end: Optional[int] = None
    range_step: int = 1
    is_parallelizable: bool = False


class LoopPatternDetector:
    """
    Detects loop patterns in bytecode.

    Analyzes Python bytecode to find loops and determine if they can be parallelized.
    """

    def __init__(self):
        self.logger = logger

    def detect_loops(self, code_object) -> List[LoopPattern]:
        """
        Detect all loops in a code object.

        Args:
            code_object: Code object to analyze

        Returns:
            List of LoopPattern objects
        """
        loops = []

        try:
            # Disassemble bytecode
            instructions = list(dis.get_instructions(code_object))

            # Find FOR_ITER instructions (indicate loop start)
            for i, instr in enumerate(instructions):
                if instr.opname == 'FOR_ITER':
                    loop_pattern = self._analyze_for_loop(code_object, instructions, i)
                    if loop_pattern:
                        loops.append(loop_pattern)

            self.logger.debug(f"Detected {len(loops)} loops in {code_object.co_name}")

        except Exception as e:
            self.logger.debug(f"Loop detection failed: {e}")

        return loops

    def _analyze_for_loop(
        self,
        code_object,
        instructions: List,
        for_iter_index: int,
    ) -> Optional[LoopPattern]:
        """
        Analyze a for loop starting at FOR_ITER instruction.

        Args:
            instructions: List of bytecode instructions
            for_iter_index: Index of FOR_ITER instruction

        Returns:
            LoopPattern if loop is analyzable, None otherwise
        """
        try:
            for_iter = instructions[for_iter_index]

            # FOR_ITER target is the offset to jump to when loop ends
            loop_end_offset = for_iter.argval
            loop_start_offset = for_iter.offset

            # Check if this is a range() loop by looking backward
            # Pattern: LOAD_GLOBAL range -> CALL_FUNCTION -> GET_ITER -> FOR_ITER
            is_range_loop = False
            range_arg = None

            if for_iter_index >= 3:
                # Look back for range() call
                for j in range(max(0, for_iter_index - 10), for_iter_index):
                    instr = instructions[j]
                    if instr.opname in ('LOAD_GLOBAL', 'LOAD_NAME') and instr.argval == 'range':
                        is_range_loop = True
                        # Try to extract range argument (if it's a constant)
                        # This is simplified - full implementation would need stack simulation
                        break

            pattern = LoopPattern(
                code_object=code_object,
                loop_start_offset=loop_start_offset,
                loop_end_offset=loop_end_offset,
                is_parallelizable=is_range_loop  # Only range loops are easily parallelizable
            )

            return pattern

        except Exception as e:
            self.logger.debug(f"Loop analysis failed: {e}")
            return None


# ============================================================================
# CRITICAL BUG FIX (Nov 22, 2025): Module-level worker functions
# ============================================================================
# These MUST be at module scope to be picklable with spawn start method.
# @staticmethod inside class fails to pickle on macOS/Windows.

def _execute_chunk_worker(
    loop_func: Callable,
    start: int,
    end: int,
    step: int,
    jit_in_workers: bool = False,
    worker_jit_cache_key: Optional[str] = None,
    reduce_results: bool = False,
) -> Any:
    """
    Execute a chunk of loop iterations.

    MODULE-LEVEL: Picklable on all platforms.

    Args:
        loop_func: Loop body function
        start: Chunk start index
        end: Chunk end index
        step: Loop step

    Returns:
        List of results for this chunk
    """
    _configure_worker_runtime()

    def _combine_chunk_results(values: List[Any]) -> Any:
        if not reduce_results:
            return values
        if not values:
            return 0
        first = values[0]
        if isinstance(first, tuple):
            columns = list(zip(*values))
            return tuple(sum(column) for column in columns)
        return sum(values)

    if not jit_in_workers:
        results = []
        for i in range(start, end, step):
            results.append(loop_func(i))
        return _combine_chunk_results(results)

    cache_key = worker_jit_cache_key or _parent_jit_overhead_cache_key(loop_func)
    iterator = iter(range(start, end, step))
    try:
        first_index = next(iterator)
    except StopIteration:
        return 0 if reduce_results else []

    if reduce_results:
        reduced_compiled = _compile_reduced_loop_func_for_worker(
            loop_func,
            cache_key,
            first_index,
        )
        if reduced_compiled is not _WORKER_JIT_FALLBACK:
            compiled_reducer, zero_seed = reduced_compiled
            try:
                return compiled_reducer(start, end, step, zero_seed)
            except Exception as exc:
                logger.debug(
                    "Worker-side reduced JIT warmup failed for %s: %s; "
                    "falling back to per-iteration execution",
                    getattr(loop_func, "__name__", repr(loop_func)),
                    exc,
                )
                _WORKER_REDUCED_JIT_CACHE[cache_key] = _WORKER_JIT_FALLBACK

    compiled = _compile_loop_func_for_worker(loop_func, cache_key)
    if compiled is _WORKER_JIT_FALLBACK:
        results = [loop_func(first_index)]
        for i in iterator:
            results.append(loop_func(i))
        return _combine_chunk_results(results)

    try:
        first_result = compiled(first_index)
    except Exception as exc:
        logger.debug(
            "Worker-side JIT warmup failed for %s: %s; falling back to raw Python",
            getattr(loop_func, "__name__", repr(loop_func)),
            exc,
        )
        _WORKER_JIT_CACHE[cache_key] = _WORKER_JIT_FALLBACK
        return _combine_chunk_results([loop_func(i) for i in range(start, end, step)])

    results = [first_result]
    for i in iterator:
        results.append(compiled(i))
    return _combine_chunk_results(results)


def _execute_chunk_cloudpickle_worker(
    pickled_func: bytes,
    start: int,
    end: int,
    step: int,
    jit_in_workers: bool = False,
    reduce_results: bool = False,
) -> Any:
    """
    Execute chunk with cloudpickle-serialized function.

    MODULE-LEVEL: Picklable with spawn.

    Debug tracing enabled via EPOCHLY_DEBUG_PARALLELIZATION=1 environment variable.
    Trace file location: <tempdir>/epochly_worker_trace.txt

    Args:
        pickled_func: Cloudpickle-serialized loop function
        start: Chunk start index
        end: Chunk end index
        step: Loop step
        jit_in_workers: Whether the worker should attempt Numba JIT

    Returns:
        List of results for this chunk
    """
    _configure_worker_runtime()

    import cloudpickle

    # Conditional debug tracing (production: no overhead)
    if _DEBUG_PARALLELIZATION:
        pid = os.getpid()
        _trace_worker_event(pid, f"START chunk [{start}:{end}:{step}]")

    # Execute work
    loop_func = cloudpickle.loads(pickled_func)
    worker_jit_cache_key = (
        _worker_jit_cache_key_from_payload(pickled_func)
        if jit_in_workers else None
    )
    results = _execute_chunk_worker(
        loop_func,
        start,
        end,
        step,
        jit_in_workers=jit_in_workers,
        worker_jit_cache_key=worker_jit_cache_key,
        reduce_results=reduce_results,
    )

    # Conditional debug tracing (production: no overhead)
    if _DEBUG_PARALLELIZATION:
        result_count = len(results) if isinstance(results, list) else 1
        _trace_worker_event(pid, f"COMPLETE chunk, {result_count} results")

    return results


class BatchDispatcher:
    """
    Dispatches loop iterations in batches to parallel workers.

    Takes a detected loop pattern and:
    1. Slices iterations into chunks
    2. Dispatches chunks to workers
    3. Collects and merges results
    """

    def __init__(self, executor=None, performance_config=None):
        """
        Initialize batch dispatcher.

        Args:
            executor: Level 3 executor (SubInterpreterExecutor or ProcessPoolExecutor)
            performance_config: Optional PerformanceConfig for threshold lookups
        """
        # Wrap executor in adapter for unified API
        if executor and not isinstance(executor, ExecutorAdapter):
            self.executor = ExecutorAdapter(executor)
        else:
            self.executor = executor
        self.logger = logger
        raw_executor = (
            self.executor.executor
            if isinstance(self.executor, ExecutorAdapter)
            else self.executor
        )
        self._performance_config = performance_config or getattr(
            raw_executor,
            "_performance_config",
            None,
        )

    def _resolve_process_worker_count(self) -> int:
        """Resolve multiprocessing worker count from environment with sane bounds."""
        detected_cpus = os.cpu_count() or 4
        configured = (
            os.environ.get("EPOCHLY_POOL_WORKERS")
            or os.environ.get("EPOCHLY_MAX_WORKERS")
            or os.environ.get("EPOCHLY_WORKERS")
        )
        if configured is None:
            return detected_cpus
        try:
            requested = int(configured)
        except (TypeError, ValueError):
            return detected_cpus
        return max(1, min(detected_cpus, requested))

    def _get_level3_min_work_ms(self) -> float:
        """Return the whole-function Level 3 dispatch threshold in milliseconds."""
        from ..performance_config import resolve_process_pool_config_value

        return resolve_process_pool_config_value(
            config_attr="level3_min_work_ms",
            env_var="EPOCHLY_LEVEL3_MIN_WORK_MS",
            default=2000.0,
            performance_config=self._performance_config,
        )

    def _get_level3_stacking_ipc_overhead_ms(self) -> float:
        """Return the fixed IPC overhead estimate for JIT+ProcessPool stacking."""
        from ..performance_config import resolve_process_pool_config_value

        return resolve_process_pool_config_value(
            config_attr="level3_stacking_ipc_overhead_ms",
            env_var="EPOCHLY_LEVEL3_STACKING_IPC_OVERHEAD_MS",
            default=100.0,
            performance_config=self._performance_config,
        )

    def _estimate_worker_jit_compile_overhead_ms(self, loop_func: Callable) -> float:
        """
        Estimate first-call worker-side JIT warmup cost.

        The estimate is cached per loop body so repeated dispatches don't
        repeatedly benchmark Numba compilation in the parent process.
        """
        cache_key = _parent_jit_overhead_cache_key(loop_func)
        cached = _WORKER_JIT_OVERHEAD_MS_CACHE.get(cache_key)
        if cached is not None:
            return cached

        try:
            import time
            import numba

            candidate = getattr(loop_func, "py_func", loop_func)
            start = time.perf_counter()
            compiled_body = numba.njit(cache=False)(candidate)
            sample_value = compiled_body(0)
            if not isinstance(sample_value, tuple):
                zero_seed = sample_value - sample_value

                @numba.njit(cache=False)
                def compiled_reducer(
                    start_index: int,
                    end_index: int,
                    step_value: int,
                    zero,
                ):
                    total = zero
                    for index in range(start_index, end_index, step_value):
                        total += compiled_body(index)
                    return total

                compiled_reducer(0, 1, 1, zero_seed)
            elapsed_ms = (time.perf_counter() - start) * 1000.0
        except Exception:
            elapsed_ms = 0.0

        _WORKER_JIT_OVERHEAD_MS_CACHE[cache_key] = elapsed_ms
        return elapsed_ms

    def dispatch_loop(
        self,
        loop_func: Callable,
        start: int,
        end: int,
        step: int = 1,
        bound_locals: Optional[Dict[str, Any]] = None,
        jit_in_workers: bool = False,
        reduce_results: bool = False,
    ) -> Optional[List[Any]]:
        """
        Dispatch loop iterations in batches to parallel workers.

        Priority order:
        1. Level 3 pre-warmed ForkingProcessExecutor (best - no startup overhead)
        2. Persistent global Pool (good - reuses processes)
        3. Sequential execution (fallback)

        Args:
            loop_func: Loop body as callable function (takes iteration index)
            start: Loop start index
            end: Loop end index
            step: Loop step (default 1, must be positive for parallel execution)
            bound_locals: Optional dict of local variables to bind into loop_func's scope
            jit_in_workers: Whether ProcessPool workers should independently attempt
                Numba JIT compilation of the loop body before executing their chunk
            reduce_results: When True, each worker reduces its chunk locally and
                returns one aggregate value instead of one entry per iteration

        Returns:
            Ordered results from all iterations, or None when
            replay would be unsafe because already-dispatched
            worker chunks may still be running.
        """
        # Issue 4 fix: Bind locals ONCE at start so all paths work (including sequential fallback)
        if bound_locals:
            loop_func = self._bind_loop_context(loop_func, bound_locals)
            # Clear bound_locals so backends don't try to bind again
            bound_locals = None

        # CRITICAL: Validate step before parallel dispatch
        # Negative steps require complex chunk boundary handling and are not yet supported
        if step == 0:
            raise ValueError("step cannot be zero")

        if step < 0:
            # Negative step ranges not supported for parallel execution
            # Fallback to sequential execution to ensure correctness
            # Note: loop_func is already bound above, so this will work
            self.logger.debug(
                f"Negative step ({step}) not supported for parallel dispatch; "
                f"falling back to sequential execution"
            )
            return [loop_func(i) for i in range(start, end, step)]
        # PRIORITY 1: Try Level 3's pre-warmed executor (zero startup overhead)
        try:
            from ..core.epochly_core import get_epochly_core
            core = get_epochly_core()

            # Trigger lazy Level 3 initialization if deferred
            if hasattr(core, '_ensure_level3_initialized'):
                core._ensure_level3_initialized()

            if (
                core
                and hasattr(core, '_sub_interpreter_executor')
                and core._sub_interpreter_executor
            ):
                # Level 3 has pre-warmed workers - use them!
                result = self._dispatch_with_level3_executor(
                    core._sub_interpreter_executor,
                    loop_func,
                    start,
                    end,
                    step,
                    bound_locals,
                    jit_in_workers=jit_in_workers,
                    reduce_results=reduce_results,
                )
                if result is not None:
                    self.logger.info(
                        "Used Level 3 pre-warmed executor "
                        "(zero overhead)"
                    )
                    return result
        except _UnsafeReplayError:
            # SIDE-EFFECT SAFETY (Mar 2026): Level 3 dispatch
            # partially executed work (microbenchmark samples
            # and/or worker chunks) but some ProcessPool workers
            # may still be running.  Do NOT fall through to
            # sequential fallback because that would replay
            # iterations that workers are still executing,
            # duplicating side effects.
            #
            # PROPAGATION FIX (Mar 2026): Re-raise instead of
            # returning None so transformed-loop wrapper callers
            # (while_loop_transformer, runtime_loop_transformer)
            # can distinguish unsafe replay from a normal dispatch
            # miss and avoid falling back to func(*args, **kwargs).
            self.logger.debug(
                "dispatch_loop: loud failure — Level 3 workers "
                "may still be running dispatched iterations"
            )
            raise
        except Exception as e:
            self.logger.debug(f"Level 3 executor not available: {e}")

        # PRIORITY 2: Try custom executor if provided
        if self.executor and self.executor.is_available():
            result = self._dispatch_with_executor(
                loop_func,
                start,
                end,
                step,
                bound_locals,
                jit_in_workers=jit_in_workers,
                reduce_results=reduce_results,
            )
            if result is not None:
                return result

        # PRIORITY 3: Use persistent global Pool (eliminates creation overhead)
        result = self._dispatch_with_multiprocessing(
            loop_func,
            start,
            end,
            step,
            bound_locals,
            jit_in_workers=jit_in_workers,
            reduce_results=reduce_results,
        )
        if result is not None:
            return result

        # Final fallback: Sequential execution
        self.logger.debug("No executor available, running sequentially")
        return [loop_func(i) for i in range(start, end, step)]

    def _dispatch_with_level3_executor(
        self,
        level3_executor,
        loop_func: Callable,
        start: int,
        end: int,
        step: int,
        bound_locals: Optional[Dict[str, Any]] = None,
        jit_in_workers: bool = False,
        reduce_results: bool = False,
    ) -> Optional[List[Any]]:
        """
        Dispatch using Level 3's pre-warmed executor.

        Benefits:
        - Workers already running (zero startup overhead)
        - Shared memory already allocated
        - Process reuse across multiple dispatches

        CRITICAL (Dec 2025): Added minimum-work threshold to prevent catastrophic
        regressions on small workloads. ProcessPool IPC overhead (~50-200ms per
        dispatch) can be 20x worse than sequential for sub-100ms workloads.

        Returns:
            List of results or None if dispatch failed (triggers fallback)
        """
        # Track microbenchmark state so the outer except handler can
        # honour the exact-once invariant if dispatch/collection fails
        # after sampling has already executed iterations.
        sample_count = 0
        sample_results: List[Any] = []

        try:
            import math
            import os

            # Calculate total iterations FIRST (needed for threshold check)
            if step == 0:
                raise ValueError("step cannot be zero")
            total_iterations = math.ceil(abs(end - start) / abs(step))

            # =================================================================
            # CRITICAL FIX (Dec 2025): Minimum-work threshold for Level 3
            # =================================================================
            # ProcessPool dispatch has significant IPC/serialization overhead.
            # Dispatching small workloads causes catastrophic performance regressions:
            # - 89ms workload -> 1796ms with ProcessPool (20x slower!)
            # Solution: Only use Level 3 for substantial workloads.
            #
            # Get threshold from config or environment variable
            min_iterations = 100  # Default
            try:
                env_min_iters = os.environ.get('EPOCHLY_LEVEL3_MIN_ITERATIONS')
                if env_min_iters is not None:
                    min_iterations = int(env_min_iters)
                else:
                    from ..performance_config import DEFAULT_PERFORMANCE_CONFIG
                    min_iterations = DEFAULT_PERFORMANCE_CONFIG.process_pool.level3_min_iterations
            except Exception:
                pass  # Use default

            if total_iterations < min_iterations:
                self.logger.debug(
                    f"Skipping Level 3 ProcessPool dispatch: {total_iterations} iterations "
                    f"< {min_iterations} threshold (use EPOCHLY_LEVEL3_MIN_ITERATIONS to override)"
                )
                return None  # Trigger fallback to sequential or JIT-only

            # =================================================================
            # CRITICAL FIX (Dec 2025): Work-time threshold for Level 3
            # =================================================================
            # Even if iteration count passes, we must verify the WORK TIME
            # justifies ProcessPool overhead (~1700ms IPC cost).
            # Solution: Microbenchmark 1-3 iterations to estimate total work time.
            #
            # Get work-time threshold from config or environment variable
            min_work_ms = self._get_level3_min_work_ms()

            # Get worker count from executor before estimating whether
            # worker-side JIT warmup makes the parallel path worthwhile.
            if hasattr(level3_executor, '_pool'):
                pool = level3_executor._pool
                if hasattr(pool, '_max_workers'):
                    num_workers = pool._max_workers
                elif hasattr(pool, '_processes') and pool._processes:
                    num_workers = len(pool._processes)
                else:
                    num_workers = 4
            else:
                num_workers = 4

            # Estimate per-iteration work time via microbenchmark
            # Run 1-3 sample iterations to measure timing.
            #
            # EXACT-ONCE FIX (Mar 2026, VAL-RUNTIME-008): Capture the
            # sample results and advance the dispatch start so that
            # sampled iterations are NOT re-dispatched to workers.
            # Previously the samples were discarded and the full range
            # [start, end) was dispatched, causing iterations 0..2 to
            # run twice when the loop body had side effects.
            import time
            sample_count = min(3, total_iterations)
            sample_results = []
            sample_start_time = time.perf_counter()
            try:
                for sample_i in range(start, start + sample_count * step, step):
                    sample_results.append(loop_func(sample_i))
                sample_end_time = time.perf_counter()
                elapsed = sample_end_time - sample_start_time
                sample_duration_ms = elapsed * 1000.0
                if sample_count > 0:
                    per_iter_ms = sample_duration_ms / sample_count
                else:
                    per_iter_ms = 0.0
                estimated_work_ms = per_iter_ms * total_iterations

                if estimated_work_ms < min_work_ms:
                    self.logger.debug(
                        f"Skipping Level 3 ProcessPool dispatch: estimated work time "
                        f"{estimated_work_ms:.1f}ms < {min_work_ms:.1f}ms threshold "
                        f"(per-iter: {per_iter_ms:.3f}ms, iters: {total_iterations}, "
                        f"use EPOCHLY_LEVEL3_MIN_WORK_MS to override)"
                    )
                    # EXACT-ONCE FIX (Mar 2026): The microbenchmark
                    # already executed sample_count iterations.
                    # Returning None here would let dispatch_loop()
                    # replay those iterations through its sequential
                    # fallback.  Instead, complete the remaining
                    # iterations sequentially and return the full
                    # result so no iteration runs twice.
                    dispatch_start = start + sample_count * step
                    remaining = [
                        loop_func(i)
                        for i in range(dispatch_start, end, step)
                    ]
                    return list(sample_results) + remaining

                if jit_in_workers:
                    active_workers = max(1, min(num_workers, total_iterations))
                    worker_jit_overhead_ms = (
                        self._estimate_worker_jit_compile_overhead_ms(loop_func)
                        * active_workers
                    )
                    estimated_parallel_ms = (
                        estimated_work_ms / active_workers
                    ) + worker_jit_overhead_ms
                    if estimated_parallel_ms >= estimated_work_ms:
                        self.logger.debug(
                            "Skipping Level 3 ProcessPool dispatch: "
                            "worker-side JIT warmup estimate %.1fms makes "
                            "parallel path slower than serial %.1fms",
                            estimated_parallel_ms,
                            estimated_work_ms,
                        )
                        dispatch_start = start + sample_count * step
                        remaining = [
                            loop_func(i)
                            for i in range(dispatch_start, end, step)
                        ]
                        return list(sample_results) + remaining

                self.logger.debug(
                    f"Level 3 work-time check passed: {estimated_work_ms:.1f}ms >= {min_work_ms:.1f}ms "
                    f"(per-iter: {per_iter_ms:.3f}ms)"
                )
            except Exception as e:
                # If microbenchmark fails, log and proceed cautiously
                # (better to try Level 3 than silently fail)
                sample_results = []
                sample_count = 0
                self.logger.debug(
                    "Work-time estimation failed (%s), "
                    "proceeding with Level 3", e,
                )

            # Advance dispatch start past the sampled iterations so each
            # iteration index executes exactly once (exact-once invariant).
            dispatch_start = start + sample_count * step

            # Bind locals into function if needed
            if bound_locals:
                loop_func = self._bind_loop_context(loop_func, bound_locals)

            # Calculate chunks for the remaining iterations after the
            # microbenchmark samples (exact-once: dispatch_start > start
            # when samples were captured).
            remaining_iterations = math.ceil(
                abs(end - dispatch_start) / abs(step)
            ) if dispatch_start < end else 0
            num_chunks = self._calculate_optimal_chunks(
                num_workers, remaining_iterations
            ) if remaining_iterations > 0 else 0

            # Use ceil to ensure actual chunk count never exceeds desired num_chunks
            chunk_size = (
                math.ceil(remaining_iterations / num_chunks)
                if num_chunks > 0 else 1
            )

            self.logger.info(
                f"Dispatching {remaining_iterations} iterations "
                f"(+{sample_count} sampled) using Level 3 executor "
                f"({num_workers} workers, {num_chunks} chunks of "
                f"~{chunk_size})"
            )

            # Create chunks starting from dispatch_start (past samples).
            # Track chunk boundaries so the failure handler can
            # determine which iterations were already computed by
            # successful chunks and only complete the uncovered range.
            futures = []
            chunk_bounds: List[Tuple[int, int]] = []
            payload = None
            if jit_in_workers:
                import cloudpickle

                payload = cloudpickle.dumps(loop_func)
            for chunk_start in range(dispatch_start, end, chunk_size * step):
                chunk_end = min(chunk_start + chunk_size * step, end)

                # Submit via Level 3 executor
                # Note: execute() takes (func, *args)
                if jit_in_workers:
                    future = level3_executor.execute(
                        _execute_chunk_cloudpickle_worker,
                        payload,
                        chunk_start,
                        chunk_end,
                        step,
                        True,
                        reduce_results,
                    )
                else:
                    future = level3_executor.execute(
                        self._execute_chunk,
                        loop_func,
                        chunk_start,
                        chunk_end,
                        step,
                        reduce_results,
                    )
                futures.append(future)
                chunk_bounds.append((chunk_start, chunk_end))

            # ---------------------------------------------------------
            # Helper: on collection failure, preserve already-computed
            # chunk results (mixed-success exact-once fix, Mar 2026).
            #
            # When some chunks succeed and a later chunk fails, the
            # previous code fell back to
            #   sample_results + sequential(dispatch_start, end)
            # which re-ran iterations already completed by successful
            # chunks.  This helper instead:
            #  1. Flattens the ordered_results that were already
            #     collected before the failure.
            #  2. Determines the first uncovered iteration after the
            #     last successfully collected chunk.
            #  3. Runs only the uncovered iterations sequentially.
            # ---------------------------------------------------------
            def _complete_with_partial(
                ordered_results: list,
                chunk_bounds: List[Tuple[int, int]],
            ) -> Optional[List[Any]]:
                """Build the full result from samples + collected
                chunks + sequential remainder for uncovered iters.

                Walks every slot in *ordered_results* by chunk index
                so that later successful chunks harvested via
                as_completed() are preserved even when an earlier
                chunk failed.  Uncovered (None) slots are filled by
                running those iterations sequentially — but ONLY if
                the corresponding future is confirmed done (raised
                or returned).

                SIDE-EFFECT SAFETY (Mar 2026): If a chunk's future
                is not confirmed done (i.e. it was submitted to a
                spawn-backed ProcessPool worker, best-effort
                cancelled but the worker may still be running), we
                must NOT replay those iterations in-process because
                the worker may still be executing them.  Replaying
                would duplicate side effects.  For such slots, we
                return None (loud failure) instead of risking
                duplicate execution."""
                try:
                    collected = list(sample_results)
                    for ci, chunk_res in enumerate(ordered_results):
                        if chunk_res is not None:
                            if isinstance(chunk_res, list):
                                collected.extend(chunk_res)
                            else:
                                collected.append(chunk_res)
                        else:
                            # Check whether this chunk's future is
                            # confirmed done before replaying.  A
                            # future that is not done() — or that was
                            # submitted but cancel() returned False
                            # (already running in a ProcessPool
                            # worker) — may still be executing the
                            # chunk iterations.  Replaying those
                            # iterations would duplicate side effects.
                            chunk_future = (
                                futures[ci]
                                if ci < len(futures)
                                else None
                            )
                            if chunk_future is not None and (
                                not chunk_future.done()
                            ):
                                # Worker may still be running —
                                # loud failure instead of replay.
                                self.logger.debug(
                                    "Skipping replay for chunk %d "
                                    "(future not confirmed done — "
                                    "worker may still be running)",
                                    ci,
                                )
                                return None

                            # Future is confirmed done (raised or
                            # returned).  Safe to replay because the
                            # worker has finished.
                            cb_start, cb_end = chunk_bounds[ci]
                            rem = [
                                loop_func(i)
                                for i in range(cb_start, cb_end, step)
                            ]
                            collected.extend(rem)
                    # Any iterations beyond the last chunk boundary
                    # (possible if chunk_bounds doesn't fully cover
                    # [dispatch_start, end)) are completed here.
                    if chunk_bounds:
                        last_end = chunk_bounds[-1][1]
                    else:
                        last_end = dispatch_start
                    if last_end < end:
                        collected.extend([
                            loop_func(i)
                            for i in range(last_end, end, step)
                        ])
                    return collected
                except Exception:
                    return None

            def _has_unconfirmed_futures() -> bool:
                """Return True if any submitted future is not
                confirmed done.  Used by the failure path to decide
                whether sequential replay is safe."""
                return any(
                    not f.done() for f in futures
                )

            # Collect results using as_completed() for efficient
            # collection without head-of-line blocking.
            from concurrent.futures import Future as _CFFuture, as_completed

            num_futures = len(futures)
            ordered_results = [None] * num_futures

            # Use as_completed() only with real Future objects; fall
            # back to sequential collection for non-standard futures
            # (e.g., mock objects in tests) to avoid hangs in
            # as_completed()'s internal wait logic.
            use_as_completed = all(
                isinstance(f, _CFFuture) for f in futures
            )

            try:
                if use_as_completed and futures:
                    future_to_index = {
                        f: i for i, f in enumerate(futures)
                    }
                    for completed_future in as_completed(
                        future_to_index.keys()
                    ):
                        idx = future_to_index[completed_future]
                        try:
                            result = completed_future.result(
                                timeout=0
                            )
                        except Exception as chunk_err:
                            self.logger.debug(
                                f"Level 3 chunk {idx} failed: "
                                f"{chunk_err}"
                            )
                            # Harvest results from any other
                            # already-done futures before giving up.
                            for f, fi in future_to_index.items():
                                if (
                                    ordered_results[fi] is None
                                    and f is not completed_future
                                    and f.done()
                                    and not f.cancelled()
                                ):
                                    try:
                                        r = f.result(timeout=0)
                                        if hasattr(r, 'success') and not r.success:
                                            continue
                                        if hasattr(r, 'result'):
                                            ordered_results[fi] = (
                                                r.result
                                            )
                                        else:
                                            ordered_results[fi] = r
                                    except Exception:
                                        pass
                            for f in futures:
                                if not f.done():
                                    f.cancel()
                            # MIXED-SUCCESS EXACT-ONCE FIX
                            # (Mar 2026): preserve already-computed
                            # chunk results instead of re-running
                            # all dispatched iterations.
                            partial = _complete_with_partial(
                                ordered_results, chunk_bounds,
                            )
                            if partial is not None:
                                return partial
                            # SIDE-EFFECT SAFETY (Mar 2026):
                            # _complete_with_partial returned None
                            # because some futures are still
                            # running.  Raise instead of returning
                            # None so the outer handler does not
                            # blindly replay via sequential fallback.
                            raise _UnsafeReplayError(
                                "Cannot safely replay: workers "
                                "may still be running"
                            )

                        # RUNTIME-FIX (Mar 2026): When the executor
                        # wraps results in ExecutionResult, a failed
                        # chunk reports success=False instead of
                        # raising.  Treat ExecutionResult(success=False)
                        # as a chunk failure to prevent silent partial
                        # aggregation (VAL-RUNTIME-004, VAL-CROSS-005).
                        if hasattr(result, 'success') and not result.success:
                            self.logger.debug(
                                f"Level 3 chunk {idx} reported "
                                f"failure via ExecutionResult: "
                                f"{getattr(result, 'error', 'unknown')}"
                            )
                            # Harvest results from other done futures.
                            for f, fi in future_to_index.items():
                                if (
                                    ordered_results[fi] is None
                                    and f is not completed_future
                                    and f.done()
                                    and not f.cancelled()
                                ):
                                    try:
                                        r = f.result(timeout=0)
                                        if hasattr(r, 'success') and not r.success:
                                            continue
                                        if hasattr(r, 'result'):
                                            ordered_results[fi] = (
                                                r.result
                                            )
                                        else:
                                            ordered_results[fi] = r
                                    except Exception:
                                        pass
                            for f in futures:
                                if not f.done():
                                    f.cancel()
                            partial = _complete_with_partial(
                                ordered_results, chunk_bounds,
                            )
                            if partial is not None:
                                return partial
                            raise _UnsafeReplayError(
                                "Cannot safely replay: workers "
                                "may still be running"
                            )

                        if hasattr(result, 'result'):
                            chunk_results = result.result
                        else:
                            chunk_results = result
                        ordered_results[idx] = chunk_results
                else:
                    # Sequential collection (non-Future objects or
                    # empty)
                    for idx, future in enumerate(futures):
                        try:
                            result = future.result()
                        except Exception as chunk_err:
                            self.logger.debug(
                                "Level 3 chunk %d failed: %s",
                                idx, chunk_err,
                            )
                            # MIXED-SUCCESS EXACT-ONCE FIX
                            # (Mar 2026): preserve already-collected
                            # chunk results.
                            partial = _complete_with_partial(
                                ordered_results, chunk_bounds,
                            )
                            if partial is not None:
                                return partial
                            if _has_unconfirmed_futures():
                                raise _UnsafeReplayError(
                                    "Cannot safely replay: workers "
                                    "may still be running"
                                )
                            return None

                        # RUNTIME-FIX (Mar 2026): Treat
                        # ExecutionResult(success=False) as chunk
                        # failure in the sequential collection path.
                        if hasattr(result, 'success') and not result.success:
                            self.logger.debug(
                                "Level 3 chunk %d reported failure "
                                "via ExecutionResult: %s",
                                idx,
                                getattr(result, 'error', 'unknown'),
                            )
                            partial = _complete_with_partial(
                                ordered_results, chunk_bounds,
                            )
                            if partial is not None:
                                return partial
                            if _has_unconfirmed_futures():
                                raise _UnsafeReplayError(
                                    "Cannot safely replay: workers "
                                    "may still be running"
                                )
                            return None

                        if hasattr(result, 'result'):
                            chunk_results = result.result
                        else:
                            chunk_results = result
                        ordered_results[idx] = chunk_results
            except _UnsafeReplayError:
                # SIDE-EFFECT SAFETY (Mar 2026): Workers may
                # still be running — re-raise so the outer
                # handler returns None without sequential replay.
                raise
            except Exception as collect_err:
                self.logger.debug(
                    f"Level 3 collection failed: {collect_err}"
                )
                # Harvest results from any already-done futures that
                # were not yet stored in ordered_results (the
                # as_completed() loop may have been interrupted before
                # processing all completed futures).
                for fi, f in enumerate(futures):
                    if (
                        ordered_results[fi] is None
                        and f.done()
                        and not f.cancelled()
                    ):
                        try:
                            r = f.result(timeout=0)
                            if hasattr(r, 'success') and not r.success:
                                continue
                            if hasattr(r, 'result'):
                                ordered_results[fi] = r.result
                            else:
                                ordered_results[fi] = r
                        except Exception:
                            pass
                for f in futures:
                    if not f.done():
                        f.cancel()
                # MIXED-SUCCESS EXACT-ONCE FIX (Mar 2026): preserve
                # already-collected chunk results on outer collection
                # failure.
                partial = _complete_with_partial(
                    ordered_results, chunk_bounds,
                )
                if partial is not None:
                    return partial
                # SIDE-EFFECT SAFETY (Mar 2026): If
                # _complete_with_partial returned None because
                # workers are still running, raise to prevent
                # the outer handler from blindly replaying.
                if _has_unconfirmed_futures():
                    raise _UnsafeReplayError(
                        "Cannot safely replay: workers "
                        "may still be running"
                    )
                return None

            # Flatten ordered results, prepending the microbenchmark
            # sample results so the final list covers the original
            # [start, end) range in submission order (exact-once).
            all_results = list(sample_results)
            for chunk_results in ordered_results:
                if isinstance(chunk_results, list):
                    all_results.extend(chunk_results)
                elif chunk_results is not None:
                    all_results.append(chunk_results)

            self.logger.info(
                f"Level 3 dispatch: {len(all_results)} results "
                f"({sample_count} sampled + "
                f"{len(all_results) - sample_count} dispatched) "
                f"from {num_futures} chunks"
            )
            return all_results

        except _UnsafeReplayError:
            # SIDE-EFFECT SAFETY (Mar 2026): Workers may still be
            # running the dispatched chunk iterations.  Re-raise so
            # dispatch_loop() can catch it and avoid replaying via
            # sequential fallback.
            self.logger.debug(
                "Level 3 dispatch: unsafe replay avoided — "
                "workers may still be running dispatched chunks"
            )
            raise
        except Exception as e:
            self.logger.debug(f"Level 3 executor dispatch failed: {e}")
            # EXACT-ONCE FIX (Mar 2026): If the microbenchmark already
            # sampled iterations before the dispatch/collection failure,
            # returning None would let dispatch_loop() replay those
            # sampled iterations.  Complete the remaining work
            # sequentially to preserve the exact-once invariant.
            #
            # SIDE-EFFECT SAFETY (Mar 2026): Only replay if there
            # are no unconfirmed futures that may still be running.
            if sample_count > 0 and sample_results:
                # Guard: _has_unconfirmed_futures is only defined
                # after futures are created inside the try block.
                try:
                    has_running = _has_unconfirmed_futures()
                except NameError:
                    has_running = False
                if has_running:
                    # Workers may still be running — raise so
                    # dispatch_loop() avoids sequential replay.
                    self.logger.debug(
                        "Level 3 dispatch: unsafe replay avoided "
                        "after sampling — workers may still be "
                        "running dispatched chunks"
                    )
                    raise _UnsafeReplayError(
                        "Cannot safely replay: workers may "
                        "still be running"
                    )
                try:
                    ds = start + sample_count * step
                    remaining = [
                        loop_func(i)
                        for i in range(ds, end, step)
                    ]
                    return list(sample_results) + remaining
                except Exception:
                    pass  # Sequential also failed; let caller decide
            return None

    def _dispatch_with_executor(
        self,
        loop_func: Callable,
        start: int,
        end: int,
        step: int,
        bound_locals: Optional[Dict[str, Any]] = None,
        jit_in_workers: bool = False,
        reduce_results: bool = False,
    ) -> Optional[List[Any]]:
        """
        Dispatch using Epochly executor (SubInterpreterPool or ProcessPool).

        Returns:
            List of results or None if dispatch failed
        """
        try:
            import math

            # Bind locals into function if needed
            if bound_locals:
                loop_func = self._bind_loop_context(loop_func, bound_locals)

            # Calculate chunk size (use ceil to avoid truncating remainder)
            if step == 0:
                raise ValueError("step cannot be zero")
            total_iterations = math.ceil(abs(end - start) / abs(step))
            num_workers = self._get_worker_count()

            # Use adaptive chunking to minimize overhead
            num_chunks = self._calculate_optimal_chunks(num_workers, total_iterations)
            chunk_size = math.ceil(total_iterations / num_chunks)

            self.logger.debug(f"Dispatching {total_iterations} iterations in {num_chunks} chunks of ~{chunk_size}")

            # Create chunks and submit
            futures = []
            payload = None
            if jit_in_workers:
                import cloudpickle

                payload = cloudpickle.dumps(loop_func)
            for chunk_start in range(start, end, chunk_size * step):
                chunk_end = min(chunk_start + chunk_size * step, end)

                # Submit chunk via adapter (unified API)
                if jit_in_workers:
                    future = self.executor.submit(
                        _execute_chunk_cloudpickle_worker,
                        payload,
                        chunk_start,
                        chunk_end,
                        step,
                        True,
                        reduce_results,
                    )
                else:
                    future = self.executor.submit(
                        self._execute_chunk,
                        loop_func,
                        chunk_start,
                        chunk_end,
                        step,
                        reduce_results,
                    )
                futures.append(future)

            # Collect results via adapter's batch collection (as_completed)
            # On ANY failure, return None to trigger the fallback chain.
            if hasattr(self.executor, 'collect_batch'):
                batch_results = self.executor.collect_batch(futures)
                if batch_results is None:
                    self.logger.debug("Executor batch collection failed — triggering fallback")
                    return None

                all_results = []
                for unified_result in batch_results:
                    chunk_results = unified_result.value
                    if isinstance(chunk_results, list):
                        all_results.extend(chunk_results)
                    elif chunk_results is not None:
                        all_results.append(chunk_results)

                self.logger.debug(f"Collected {len(all_results)} results from {len(futures)} chunks")
                return all_results
            else:
                # Fallback to sequential collection if adapter lacks collect_batch
                all_results = []
                for i, future in enumerate(futures):
                    unified_result = self.executor.get_result(future)
                    if not unified_result.success:
                        self.logger.warning(f"Chunk {i} failed: {unified_result.error}")
                        # Cancel remaining and return None for fallback
                        for f in futures[i+1:]:
                            if not f.done():
                                f.cancel()
                        return None
                    chunk_results = unified_result.value
                    if isinstance(chunk_results, list):
                        all_results.extend(chunk_results)
                    else:
                        all_results.append(chunk_results)
                self.logger.debug(f"Collected {len(all_results)} results from {len(futures)} chunks")
                return all_results

        except Exception as e:
            self.logger.debug(f"Executor dispatch failed: {e}")
            return None  # Allow fallback to multiprocessing

    @staticmethod
    def _execute_chunk(
        loop_func: Callable,
        start: int,
        end: int,
        step: int,
        reduce_results: bool = False,
    ) -> Any:
        """
        Execute a chunk of loop iterations.

        Args:
            loop_func: Loop body function
            start: Chunk start index
            end: Chunk end index
            step: Loop step

        Returns:
            List of results for this chunk
        """
        results = []
        for i in range(start, end, step):
            results.append(loop_func(i))
        if not reduce_results:
            return results
        if not results:
            return 0
        first = results[0]
        if isinstance(first, tuple):
            columns = list(zip(*results))
            return tuple(sum(column) for column in columns)
        return sum(results)

    @staticmethod
    def _bind_loop_context(loop_func: Callable, bound_locals: Optional[Dict[str, Any]]) -> Callable:
        """Bind captured locals into function's globals for serialization."""
        if not bound_locals:
            return loop_func

        import types
        merged_globals = dict(loop_func.__globals__)
        merged_globals.update(bound_locals)

        return types.FunctionType(
            loop_func.__code__,
            merged_globals,
            loop_func.__name__,
            loop_func.__defaults__,
            loop_func.__closure__
        )

    def _get_worker_count(self) -> int:
        """Get number of available workers."""
        if hasattr(self.executor, 'get_worker_count'):
            return self.executor.get_worker_count()
        elif hasattr(self.executor, '_max_workers'):
            return self.executor._max_workers
        else:
            import os
            return os.cpu_count() or 4

    def _get_optimal_start_method(self) -> str:
        """
        Determine optimal multiprocessing start method for current platform.

        Per deep RCA (2025-11-19):
        - macOS spawn (default): 2.8× overhead + strict importability requirements
        - macOS fork (opt-in): Fast but requires vetted workloads
        - Linux fork (default): Best performance

        Strategy:
        - Linux: Use fork (default, best performance)
        - macOS: Use fork for compute-only workloads (bypasses spawn overhead)
        - Windows: Use spawn (only option)
        - Override: Respect EPOCHLY_MP_START environment variable

        Returns:
            Start method name ('fork', 'spawn', or 'forkserver')
        """
        import sys
        import os

        # Check for explicit override
        override = os.environ.get('EPOCHLY_MP_START', '').lower()
        if override in ('fork', 'spawn', 'forkserver'):
            self.logger.info(f"Using multiprocessing start method: {override} (from EPOCHLY_MP_START)")
            return override

        # Platform-specific defaults
        if sys.platform == 'darwin':
            # macOS: Default to spawn (safe) but allow fork opt-in for vetted workloads
            # Per RCA: spawn has 2.8× overhead but is safe with GUI/Cocoa frameworks
            # Fork eliminates overhead but risks deadlocks with multi-threaded code
            #
            # PRODUCTION DEFAULT: spawn (safe by default)
            # OPT-IN: Set EPOCHLY_MP_START=fork for pure compute workloads
            self.logger.info("Using multiprocessing start method: spawn (macOS safe default)")
            self.logger.info("TIP: Set EPOCHLY_MP_START=fork for faster compute-only workloads (avoids spawn overhead)")
            return 'spawn'
        elif sys.platform.startswith('linux'):
            # Linux: fork is default and best
            return 'fork'
        else:
            # Windows and others: spawn only
            return 'spawn'

    def _calculate_optimal_chunks(self, num_workers: int, total_iterations: int) -> int:
        """
        Calculate optimal chunk count to minimize overhead while maintaining load balance.

        Strategy based on MCP-Reflect RCA (2025-11-19):
        - PROBLEM: 32× oversubscription (512 chunks) creates 100% overhead for small tasks
        - SOLUTION: Use fewer, larger chunks to amortize IPC/pickle overhead
        - TARGET: Overhead <5% of total execution time

        Chunk sizing strategy:
        - Tiny workloads (<=1 iter): 1 chunk (no parallelization benefit)
        - Small workloads (<1000 iter): 4-8 chunks (large chunks, minimal overhead)
        - Medium workloads (1000-10000 iter): num_workers chunks (balance)
        - Large workloads (>10000 iter): num_workers * 2 chunks (better load balancing)

        Args:
            num_workers: Number of worker processes (auto-sanitized if 0/None)
            total_iterations: Total number of loop iterations

        Returns:
            Optimal number of chunks to minimize overhead (always <= total_iterations)
        """
        import math

        # Sanitize num_workers (handle 0/None from mis-configured adapters)
        if not num_workers or num_workers < 1:
            import os
            num_workers = os.cpu_count() or 4

        # Fast-path: No benefit to chunking tiny loops
        if total_iterations <= 1:
            return 1

        # Determine desired chunk count based on workload size
        if total_iterations < 100:
            # Very small: 2-4 chunks
            desired_chunks = min(4, max(2, num_workers // 4))
        elif total_iterations < 1000:
            # Small: 4-8 chunks (minimize overhead over perfect load balance)
            desired_chunks = min(8, max(4, num_workers // 2))
        elif total_iterations < 10000:
            # Medium: 1 chunk per worker (balance overhead and distribution)
            desired_chunks = num_workers
        else:
            # Large: 2× workers (moderate oversubscription for load balancing)
            desired_chunks = num_workers * 2

        # CRITICAL: Clamp chunk count to never exceed total_iterations
        # Without this, floor division in chunk_size causes over-chunking
        # E.g., 100 iters / 8 desired = 12 chunk_size → ceil(100/12) = 9 actual chunks
        return max(1, min(total_iterations, desired_chunks))

    def _dispatch_with_multiprocessing(
        self,
        loop_func: Callable,
        start: int,
        end: int,
        step: int,
        bound_locals: Optional[Dict[str, Any]] = None,
        jit_in_workers: bool = False,
        reduce_results: bool = False,
    ) -> Optional[List[Any]]:
        """
        Dispatch using stdlib multiprocessing.Pool as fallback.

        Uses a persistent global pool to eliminate process creation overhead (~40-80ms).
        CRITICAL: Uses cloudpickle to serialize dynamically-created loop functions.

        Returns:
            List of results or None if multiprocessing failed
        """
        try:
            from multiprocessing import get_context
            import math
            import cloudpickle
            import sys
            import os

            global _global_pool, _global_pool_lock

            num_workers = self._resolve_process_worker_count()

            # CRITICAL: Determine optimal start method for this platform
            # macOS spawn (default) has 2.8× overhead and strict importability requirements
            # Use fork when safe to eliminate overhead and enable dynamic function pickling
            start_method = self._get_optimal_start_method()

            # Calculate total iterations (use ceil to avoid truncating remainder)
            if step == 0:
                raise ValueError("step cannot be zero")
            total_iterations = math.ceil(abs(end - start) / abs(step))

            # Only use multiprocessing for substantial workloads
            if total_iterations < 100:
                return None  # Too small, use sequential

            # Calculate chunks with adaptive strategy
            num_chunks = self._calculate_optimal_chunks(num_workers, total_iterations)
            chunk_size = math.ceil(total_iterations / num_chunks)

            # CRITICAL FIX: Serialize both function and bound locals using cloudpickle
            # Standard pickle cannot handle dynamically-created functions from exec()
            # Bind locals into function BEFORE serialization
            if bound_locals:
                loop_func = self._bind_loop_context(loop_func, bound_locals)
            
            # This was causing silent worker crashes and sequential fallback
            payload = cloudpickle.dumps(loop_func)

            # Create chunks with pre-pickled function+locals
            chunks = []
            for chunk_start in range(start, end, chunk_size * step):
                chunk_end = min(chunk_start + chunk_size * step, end)
                chunks.append(
                    (
                        payload,
                        chunk_start,
                        chunk_end,
                        step,
                        jit_in_workers,
                        reduce_results,
                    )
                )

            # Get or create persistent pool using module-level lock
            with _global_pool_lock:
                existing_workers = getattr(_global_pool, "_processes", None) if _global_pool is not None else None
                if _global_pool is not None and existing_workers != num_workers:
                    _cleanup_global_pool()

                if _global_pool is None:
                    # Create persistent pool with optimal start method for platform
                    # CRITICAL: Use fork on macOS to bypass spawn overhead (2.8×) and pickling issues
                    ctx = get_context(start_method)
                    _global_pool = ctx.Pool(processes=num_workers)
                    self.logger.info(f"Created persistent multiprocessing.Pool with {num_workers} workers (method={start_method})")

                    # Register cleanup on exit
                    global _GLOBAL_POOL_CLEANUP_REGISTERED
                    if not _GLOBAL_POOL_CLEANUP_REGISTERED:
                        atexit.register(_cleanup_global_pool)
                        _GLOBAL_POOL_CLEANUP_REGISTERED = True

                pool = _global_pool

            self.logger.info(f"Using persistent multiprocessing.Pool for {len(chunks)} chunks")

            # Execute chunks in parallel using cloudpickle-serialized function
            # CRITICAL FIX: Use module-level function (picklable with spawn)

            # Conditional debug logging (production: no overhead)
            if _DEBUG_PARALLELIZATION or logger.isEnabledFor(logging.DEBUG):
                pool_state = getattr(pool, '_state', 'unknown')
                first_chunk_range = f"[{chunks[0][1]}:{chunks[0][2]}:{chunks[0][3]}]" if chunks else 'NO_CHUNKS'
                logger.debug(
                    f"pool.starmap dispatch: workers={num_workers}, chunks={len(chunks)}, "
                    f"first_chunk={first_chunk_range}, method={start_method}"
                )

            chunk_results = pool.starmap(_execute_chunk_cloudpickle_worker, chunks)

            # Conditional debug logging (production: no overhead)
            if _DEBUG_PARALLELIZATION or logger.isEnabledFor(logging.DEBUG):
                total_results = sum(len(c) if isinstance(c, list) else 1 for c in chunk_results)
                first_result = chunk_results[0] if chunk_results else None
                first_len = len(first_result) if isinstance(first_result, list) else 'N/A'
                logger.debug(
                    f"pool.starmap complete: {len(chunk_results)} chunks, "
                    f"{total_results} total results, first_chunk_len={first_len}"
                )

            # Flatten results
            all_results = []
            for chunk in chunk_results:
                if isinstance(chunk, list):
                    all_results.extend(chunk)
                else:
                    all_results.append(chunk)

            self.logger.info(f"Batch dispatch via multiprocessing.Pool: {len(all_results)} results")
            return all_results

        except Exception as e:
            # Log dispatch failures at WARNING (actionable operational errors)
            self.logger.warning(
                f"multiprocessing.Pool dispatch failed: {type(e).__name__}: {e}",
                exc_info=True  # Include traceback for debugging
            )
            return None

    @staticmethod
    def _execute_chunk_cloudpickle(pickled_func: bytes, start: int, end: int, step: int) -> List[Any]:
        """
        Execute chunk with cloudpickle-serialized function (already has locals bound).

        CRITICAL: This allows dynamically-created functions (from exec()) to be executed
        in worker processes on macOS where multiprocessing uses 'spawn' method.

        Args:
            pickled_func: Cloudpickle-serialized loop function (with captured locals already bound)
            start: Chunk start index
            end: Chunk end index
            step: Loop step

        Returns:
            List of results for this chunk
        """
        import cloudpickle

        # Unpickle function (locals already bound before serialization)
        loop_func = cloudpickle.loads(pickled_func)

        # Execute chunk
        results = []
        for i in range(start, end, step):
            results.append(loop_func(i))
        return results


def create_batch_dispatcher(executor=None, performance_config=None):
    """
    Create a batch dispatcher with the given executor.

    Args:
        executor: Level 3 executor or None for auto-detection
        performance_config: Optional PerformanceConfig for threshold lookups

    Returns:
        BatchDispatcher instance
    """
    if executor is None:
        # Try to get Level 3 executor from core
        try:
            from ..core.epochly_core import get_epochly_core
            core = get_epochly_core()

            # Trigger lazy Level 3 initialization if deferred
            if hasattr(core, '_ensure_level3_initialized'):
                core._ensure_level3_initialized()

            if core and hasattr(core, '_sub_interpreter_executor') and core._sub_interpreter_executor:
                executor = core._sub_interpreter_executor
                logger.debug("Using Level 3 executor for batch dispatch")
            if performance_config is None and core is not None:
                performance_config = getattr(core, 'performance_config', None)
        except Exception:
            pass

    return BatchDispatcher(
        executor=executor,
        performance_config=performance_config,
    )
