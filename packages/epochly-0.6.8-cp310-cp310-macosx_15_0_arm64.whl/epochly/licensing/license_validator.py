"""
Epochly License Validator

Provides license validation functionality for the Epochly system.
Implements validation logic, security checks, and license verification.
"""

import hashlib
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, cast

from ..utils.exceptions import EpochlyError
from .dev_token_validator import DevTokenValidator
from .errors import (
    LicenseFormatError,
    LicenseIntegrityError,
    LicenseSchemaError,
    MissingSigningKeyError,
    RevokedSigningKeyError,
    TokenRevokedError,
    UnknownSigningKeyError,
)
from .license_audit import LicenseAuditLogger
from . import license_crypto as license_crypto_module
from .license_crypto import LicenseCrypto
from .license_loader import LicenseLoader
from .revocation import RevocationStore


class ValidationError(EpochlyError):
    """License validation error."""


@dataclass
class LicenseValidationResult:
    valid: bool
    payload: Optional[Any] = None
    error: Optional[str] = None
    reason: str = 'valid'
    exception: Optional[Exception] = None
    revoked: bool = False
    expired: bool = False

    def __bool__(self) -> bool:
        return self.valid


class LicenseValidator:
    _MAX_VALIDATION_CACHE_ENTRIES = 1024

    def __init__(
        self,
        crypto: Optional[LicenseCrypto] = None,
        revocation_store: Optional[RevocationStore] = None,
        audit_logger: Optional[LicenseAuditLogger] = None,
        require_test_mode: bool = False,
    ):
        self.logger = logging.getLogger(__name__)
        self._validation_cache: Dict[str, Dict[str, Any]] = {}
        self._explicit_crypto = crypto
        self._crypto_handler = crypto or LicenseCrypto()
        self._revocation_store = revocation_store or RevocationStore()
        self._audit_logger = audit_logger or LicenseAuditLogger()
        self._loader = LicenseLoader(crypto=self._crypto_handler, audit_logger=self._audit_logger)
        self._dev_token_validator = DevTokenValidator(
            crypto=self._crypto_handler,
            require_test_mode=require_test_mode,
            revocation_store=self._revocation_store,
            audit_logger=self._audit_logger,
        )

    def validate_format(self, license_key: str) -> bool:
        if not license_key:
            return False
        if not license_key.startswith('Epochly-'):
            self.logger.error("License key must start with 'Epochly-'")
            return False
        try:
            if license_crypto_module.is_modern_key(license_key):
                return True
        except Exception:
            pass
        key_body = license_key[8:]
        if len(key_body) < 12:
            self.logger.error('License key too short')
            return False
        if not all(c.isalnum() or c == '-' for c in key_body):
            self.logger.error('License key contains invalid characters')
            return False
        return True

    def validate_signature(self, license_key: str) -> bool:
        try:
            if license_crypto_module.is_modern_key(license_key):
                return self._validated_modern_license_data(
                    license_key,
                    error_message='Ed25519 signature validation failed',
                ) is not None
        except Exception as e:
            self.logger.error(f'Ed25519 signature validation error: {e}')
            return False

        try:
            components = self._parse_license_key(license_key)
            if not components:
                return False
            expected_checksum = self._calculate_checksum(components)
            actual_checksum = components.get('checksum', '')
            if expected_checksum != actual_checksum:
                self.logger.error('License signature validation failed')
                return False
            return True
        except Exception as e:
            self.logger.error(f'Signature validation error: {e}')
            return False

    def validate_expiry(self, license_key: str) -> bool:
        try:
            try:
                if license_crypto_module.is_modern_key(license_key):
                    license_data = self._validated_modern_license_data(
                        license_key,
                        error_message='Ed25519 signature invalid for expiry validation',
                    )
                    if license_data is None:
                        return False
                    expiry_ts = license_data.get('expiry')
                    if expiry_ts is None:
                        return True
                    expiry_date = datetime.fromtimestamp(expiry_ts, tz=timezone.utc)
                    current_date = datetime.now(tz=timezone.utc)
                    if current_date > expiry_date:
                        self.logger.error(f"License expired on {expiry_date.strftime('%Y-%m-%d')}")
                        return False
                    days_until_expiry = (expiry_date - current_date).days
                    if days_until_expiry <= 30:
                        self.logger.warning(f'License expires in {days_until_expiry} days')
                    return True
            except Exception as e:
                self.logger.debug('Ed25519 expiry check failed, falling back to legacy: %s', e)

            components = self._parse_license_key(license_key)
            if not components:
                return False
            expiry_str = components.get('expiry')
            if not expiry_str:
                return True
            expiry_date = datetime.strptime(expiry_str, '%Y%m%d').replace(tzinfo=timezone.utc)
            expiry_deadline = expiry_date + timedelta(days=1)
            current_date = datetime.now(tz=timezone.utc)
            if current_date >= expiry_deadline:
                self.logger.error(f"License expired on {expiry_date.strftime('%Y-%m-%d')}")
                return False
            days_until_expiry = (expiry_deadline - current_date).days
            if days_until_expiry <= 30:
                self.logger.warning(f'License expires in {days_until_expiry} days')
            return True
        except Exception as e:
            self.logger.error(f'Expiry validation error: {e}')
            return False

    def validate_features(self, license_key: str, required_features: list) -> bool:
        try:
            try:
                if license_crypto_module.is_modern_key(license_key):
                    license_data = self._validated_modern_license_data(
                        license_key,
                        error_message='Ed25519 signature invalid for feature validation',
                    )
                    if license_data is None:
                        return False
                    licensed_features = license_data.get('features', [])
                    if 'pro' in licensed_features:
                        return True
                    for feature in required_features:
                        if feature not in licensed_features:
                            self.logger.error(f"Feature '{feature}' not licensed")
                            return False
                    return True
            except Exception as e:
                self.logger.debug('Ed25519 feature check failed, falling back to legacy: %s', e)

            components = self._parse_license_key(license_key)
            if not components:
                return False
            licensed_features = components.get('features', [])
            if 'pro' in licensed_features:
                return True
            for feature in required_features:
                if feature not in licensed_features:
                    self.logger.error(f"Feature '{feature}' not licensed")
                    return False
            return True
        except Exception as e:
            self.logger.error(f'Feature validation error: {e}')
            return False

    def get_license_info(self, license_key: str) -> Optional[Dict[str, Any]]:
        try:
            try:
                if license_crypto_module.is_modern_key(license_key):
                    license_data = self._validated_modern_license_data(
                        license_key,
                        error_message='Ed25519 signature invalid for license info extraction',
                    )
                    if license_data is None:
                        return None
                    expiry_ts = license_data.get('expiry')
                    expiry_str = (
                        datetime.fromtimestamp(expiry_ts, tz=timezone.utc).strftime('%Y%m%d')
                        if expiry_ts is not None
                        else None
                    )
                    return {
                        'license_type': license_data.get('type', 'standard'),
                        'expiry_date': expiry_str,
                        'features': license_data.get('features', []),
                        'user_limit': license_data.get('max_cores', 1),
                        'issued_date': None,
                        'version': '2.0',
                    }
            except Exception as e:
                self.logger.debug('Ed25519 info extraction failed, falling back to legacy: %s', e)

            components = self._parse_license_key(license_key)
            if not components:
                return None
            return {
                'license_type': components.get('type', 'standard'),
                'expiry_date': components.get('expiry'),
                'features': components.get('features', []),
                'user_limit': components.get('user_limit', 1),
                'issued_date': components.get('issued'),
                'version': components.get('version', '1.0'),
            }
        except Exception as e:
            self.logger.error(f'License info extraction error: {e}')
            return None

    def _resolve_modern_crypto_handler(self) -> Any:
        if self._explicit_crypto is not None:
            return self._explicit_crypto
        return license_crypto_module.LicenseCrypto()

    @staticmethod
    def _signature_gate_passed(signature_valid: Any) -> bool:
        return signature_valid is not False and signature_valid is not None

    def _validated_modern_license_data(
        self,
        license_key: str,
        *,
        error_message: str,
    ) -> Optional[Dict[str, Any]]:
        crypto_handler = self._resolve_modern_crypto_handler()
        license_data, signature = crypto_handler.parse_license_key(license_key)
        signature_valid = crypto_handler.validate_license_signature(license_data, signature)
        if not self._signature_gate_passed(signature_valid):
            self.logger.error(error_message)
            return None
        return cast(Dict[str, Any], license_data)

    def _parse_license_key(self, license_key: str) -> Optional[Dict[str, Any]]:
        if not self.validate_format(license_key):
            return None
        if license_key in self._validation_cache:
            return self._validation_cache[license_key]
        try:
            key_body = license_key[8:]
            parts = key_body.split('-')
            if len(parts) < 4:
                return None
            components = {
                'type': parts[0] if parts[0] else 'standard',
                'features': self._decode_features(parts[1]) if parts[1] else [],
                'expiry': parts[2] if parts[2] and parts[2] != 'NEVER' else None,
                'checksum': parts[3] if len(parts) > 3 else '',
                'issued': datetime.now(tz=timezone.utc).strftime('%Y%m%d'),
                'version': '1.0',
                'user_limit': 1,
            }
            if len(self._validation_cache) >= self._MAX_VALIDATION_CACHE_ENTRIES:
                self._validation_cache.clear()
            self._validation_cache[license_key] = components
            return components
        except Exception as e:
            self.logger.error(f'License parsing error: {e}')
            return None

    def _decode_features(self, features_str: str) -> list:
        if not features_str or features_str == 'ALL':
            return ['optimization', 'monitoring', 'deployment', 'analytics']
        feature_map = {
            'O': 'optimization',
            'M': 'monitoring',
            'D': 'deployment',
            'A': 'analytics',
        }
        features = []
        for char in features_str.upper():
            if char in feature_map:
                features.append(feature_map[char])
        return features

    def _calculate_checksum(self, components: Dict[str, Any]) -> str:
        checksum_data = f"{components.get('type', '')}{components.get('features', '')}{components.get('expiry', '')}"
        hash_obj = hashlib.sha256(checksum_data.encode())
        return hash_obj.hexdigest()[:8].upper()

    def validate_license(self, license_key: str) -> Dict[str, Any]:
        result: Dict[str, Any] = {'valid': False, 'license_key': license_key, 'errors': []}
        try:
            if not self.validate_format(license_key):
                result['errors'].append('Invalid license format')
                return result
            if not self.validate_signature(license_key):
                result['errors'].append('Invalid license signature')
                return result
            if not self.validate_expiry(license_key):
                result['errors'].append('License expired')
                return result
            result['valid'] = True
            license_info = self.get_license_info(license_key)
            if license_info:
                result.update(license_info)
            return result
        except Exception as e:
            result['errors'].append(f'Validation error: {e}')
            return result

    def validate_with_time_check(self, license_key: str) -> Dict[str, Any]:
        try:
            from .time_protection import get_time_detector
            time_detector = get_time_detector()
            time_result = time_detector.check_time_consistency()
            license_result = self.validate_license(license_key)
            result = license_result.copy()
            result['time_valid'] = time_result['consistent']
            result['time_sources'] = time_result.get('sources', {})
            return result
        except Exception as e:
            return {'valid': False, 'error': f'Time validation failed: {e}', 'time_valid': False}

    def validate(
        self,
        *,
        token_data: Optional[Dict[str, Any]] = None,
        license_path: Optional[str] = None,
        envelope: Optional[Dict[str, Any]] = None,
    ) -> LicenseValidationResult:
        if token_data is not None:
            token_result = self._dev_token_validator.validate(token_data=token_data)
            if token_result.valid:
                return LicenseValidationResult(valid=True, payload=token_result.payload, reason='valid')
            return LicenseValidationResult(
                valid=False,
                payload=token_result.payload,
                error=token_result.error,
                reason=token_result.reason.value,
                exception=token_result.exception,
                revoked=token_result.revoked,
                expired=token_result.expired,
            )

        if envelope is None and license_path is None:
            missing_error = LicenseFormatError('License source is required')
            return LicenseValidationResult(
                valid=False,
                error=str(missing_error),
                reason=missing_error.code,
                exception=missing_error,
            )

        subject_id = 'license-subject'
        source = envelope if envelope is not None else license_path
        assert source is not None
        try:
            payload = self._loader.load(source)
            subject_id = self._extract_subject_id(payload)
        except (
            LicenseFormatError,
            LicenseSchemaError,
            LicenseIntegrityError,
            MissingSigningKeyError,
            RevokedSigningKeyError,
            UnknownSigningKeyError,
        ) as exc:
            self._audit_logger.emit_transition('license_rejected', subject_id=subject_id)
            return LicenseValidationResult(
                valid=False,
                error=str(exc),
                reason=getattr(exc, 'code', 'license_rejected'),
                exception=exc,
            )

        try:
            with self._revocation_store.validation_session(subject_id):
                expires_at = payload.get('expires_at')
                if expires_at:
                    expiry = self._coerce_utc_datetime(expires_at)
                    if datetime.now(timezone.utc) >= expiry:
                        self._audit_logger.emit_transition('expired', subject_id=subject_id)
                        return LicenseValidationResult(
                            valid=False,
                            payload=payload,
                            error='license_expired: License expired',
                            reason='license_expired',
                            expired=True,
                        )
                self._audit_logger.emit_transition('validated', subject_id=subject_id)
                return LicenseValidationResult(valid=True, payload=payload, reason='valid')
        except TokenRevokedError as exc:
            self._audit_logger.emit_transition('revoked', subject_id=subject_id)
            return LicenseValidationResult(
                valid=False,
                error=str(exc),
                reason=exc.code,
                exception=exc,
                revoked=True,
            )

    @staticmethod
    def _extract_subject_id(payload: Dict[str, Any]) -> str:
        return str(
            payload.get('license_id')
            or payload.get('jti')
            or payload.get('subject')
            or 'license-subject'
        )

    @staticmethod
    def _coerce_utc_datetime(value: str) -> datetime:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
