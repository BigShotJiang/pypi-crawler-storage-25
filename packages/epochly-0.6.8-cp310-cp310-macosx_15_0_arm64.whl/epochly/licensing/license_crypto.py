"""
Epochly License Cryptography Module

Provides Ed25519 cryptographic signature generation and validation
for Epochly license keys. Implements offline-first license validation
with tamper-proof cryptographic signatures.

Architecture:
- Ed25519 for compact, secure signatures
- License format: Epochly-TYPE-FEATURES-EXPIRY-MAXCORES-SIGNATURE
- Offline validation (no server required)
- Public key embedded in client, private key server-side only

Author: Epochly Development Team
"""
from __future__ import annotations

import base64
import hmac
import json
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any, Dict, Mapping, NoReturn, Optional, Tuple

try:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519, padding, rsa
    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False

from .errors import (
    LicenseFormatError,
    LicenseIntegrityError,
    MissingSigningKeyError,
    RevokedSigningKeyError,
    UnknownSigningKeyError,
)


class LicenseCryptoError(Exception):
    """Raised when cryptographic operations fail"""
    pass


_LEGACY_PUBLIC_KEY_REMEDIATION = (
    "Legacy RSA _EPOCHLY_PUBLIC_KEY is deprecated. "
    "Use LicenseCrypto.EMBEDDED_PUBLIC_KEY_PEM or set "
    "EPOCHLY_LICENSE_PUBLIC_KEY_PEM to a PEM-encoded Ed25519 public key."
)


class LicenseKeyDeprecatedError(LicenseCryptoError, RuntimeError):
    """Raised when the deprecated legacy public-key fallback is accessed."""


class _DeprecatedPublicKey:
    """Typed sentinel for the removed legacy RSA public-key fallback."""

    __slots__ = ()

    def _raise(self) -> NoReturn:
        raise LicenseKeyDeprecatedError(_LEGACY_PUBLIC_KEY_REMEDIATION)

    def __bool__(self) -> bool:
        self._raise()

    def __bytes__(self) -> bytes:
        self._raise()

    def __str__(self) -> str:
        self._raise()

    def __getattr__(self, _name: str) -> NoReturn:
        self._raise()

    def __repr__(self) -> str:
        return "_DeprecatedPublicKey(<deprecated Epochly RSA public key>)"


_EPOCHLY_PUBLIC_KEY = _DeprecatedPublicKey()


def is_modern_key(license_key: str) -> bool:
    """Check if a license key is in modern Ed25519 format.

    Modern format: Epochly-TYPE-FEATURES-EXPIRY-MAXCORES-SIGNATURE (6+ parts)
    Legacy format: Epochly-TYPE-PLAN-EXPIRY-CHECKSUM (exactly 5 parts)

    Args:
        license_key: The license key string to check.

    Returns:
        True if the key is in modern Ed25519 format.
    """
    if not license_key or not isinstance(license_key, str):
        return False
    if not license_key.startswith('Epochly-'):
        return False
    parts = license_key.split('-')
    if len(parts) < 6:
        return False
    try:
        int(parts[3])
        int(parts[4])
        return True
    except (ValueError, IndexError):
        return False


class LicenseCrypto:
    """Handles cryptographic operations for license validation."""

    EMBEDDED_PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAzS1nrbdw4bZlFtyZTIvwG/ber4xziPKcc69E2Hgqi8c=
-----END PUBLIC KEY-----
"""
    ENVELOPE_MAGIC = 'EPOCHLY_LICENSE'
    ENVELOPE_VERSION = 1

    def __init__(
        self,
        public_key_pem: Optional[bytes] = None,
        *,
        public_keys_by_id: Optional[Mapping[str, bytes]] = None,
        revoked_key_ids: Optional[set[str]] = None,
        hmac_keys: Optional[Mapping[str, bytes]] = None,
    ):
        if not HAS_CRYPTOGRAPHY:
            raise LicenseCryptoError(
                "cryptography library not installed. Install with: pip install cryptography"
            )

        self.public_key_pem = public_key_pem or self.EMBEDDED_PUBLIC_KEY_PEM
        self._public_key: Optional[ed25519.Ed25519PublicKey | rsa.RSAPublicKey] = None
        self._public_key_ring: Dict[str, ed25519.Ed25519PublicKey | rsa.RSAPublicKey] = {}
        self._revoked_key_ids = set(revoked_key_ids or set())
        self._hmac_keys = {
            key_id: (value if isinstance(value, bytes) else bytes(value))
            for key_id, value in (hmac_keys or {}).items()
        }

        if public_keys_by_id:
            for key_id, key_data in public_keys_by_id.items():
                self._public_key_ring[key_id] = self._load_public_key_value(key_data, allow_rsa=True)

        if self.public_key_pem:
            self._public_key = self._load_public_key_value(self.public_key_pem, allow_rsa=False)
            if not self._public_key_ring:
                self._public_key_ring['embedded-ed25519'] = self._public_key

    def _load_public_key_value(
        self,
        key_data: bytes | str,
        *,
        allow_rsa: bool,
    ) -> ed25519.Ed25519PublicKey | rsa.RSAPublicKey:
        try:
            pem_bytes = key_data if isinstance(key_data, bytes) else key_data.encode('utf-8')
            public_key_obj = serialization.load_pem_public_key(pem_bytes)
            if isinstance(public_key_obj, ed25519.Ed25519PublicKey):
                return public_key_obj
            if allow_rsa and isinstance(public_key_obj, rsa.RSAPublicKey):
                return public_key_obj
            if allow_rsa:
                raise LicenseCryptoError('Public key must be Ed25519 or RSA')
            raise LicenseCryptoError('Public key must be Ed25519')
        except LicenseCryptoError:
            raise
        except Exception as e:  # pragma: no cover - defensive
            raise LicenseCryptoError(f'Failed to load public key: {e}')

    @staticmethod
    def canonicalize_payload(payload: Mapping[str, Any]) -> bytes:
        return json.dumps(payload, separators=(',', ':'), sort_keys=True).encode('utf-8')

    @staticmethod
    def _encode_signature(signature: bytes) -> str:
        return base64.urlsafe_b64encode(signature).decode('utf-8').rstrip('=')

    @staticmethod
    def _decode_signature(signature_b64: str) -> bytes:
        try:
            normalized = signature_b64.rstrip('=')
            decoded = base64.urlsafe_b64decode(normalized + '=' * (-len(normalized) % 4))
            if base64.urlsafe_b64encode(decoded).decode('utf-8').rstrip('=') != normalized:
                raise LicenseIntegrityError()
            return decoded
        except LicenseIntegrityError:
            raise
        except Exception as exc:  # pragma: no cover - defensive
            raise LicenseIntegrityError() from exc

    def validate_license_signature(self, license_data: Dict[str, Any], signature_b64: str) -> bool:
        if not self._public_key:
            raise LicenseCryptoError('No public key loaded for validation')

        try:
            license_bytes = self.canonicalize_payload(license_data)
            signature = self._decode_signature(signature_b64)

            if isinstance(self._public_key, ed25519.Ed25519PublicKey):
                self._public_key.verify(signature, license_bytes)
            elif isinstance(self._public_key, rsa.RSAPublicKey):
                self._public_key.verify(
                    signature,
                    license_bytes,
                    padding.PSS(
                        mgf=padding.MGF1(hashes.SHA256()),
                        salt_length=padding.PSS.MAX_LENGTH,
                    ),
                    hashes.SHA256(),
                )
            else:  # pragma: no cover - defensive
                raise LicenseCryptoError('Unsupported public key type')
            return True
        except Exception:
            return False

    def _sign_payload(self, payload_bytes: bytes, private_key: Any, algorithm: str) -> bytes:
        if algorithm == 'ed25519':
            if not isinstance(private_key, ed25519.Ed25519PrivateKey):
                raise LicenseCryptoError('Ed25519 envelope requires an Ed25519 private key')
            return private_key.sign(payload_bytes)
        if algorithm == 'rsa-pss':
            if not isinstance(private_key, rsa.RSAPrivateKey):
                raise LicenseCryptoError('RSA envelope requires an RSA private key')
            return private_key.sign(
                payload_bytes,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH,
                ),
                hashes.SHA256(),
            )
        raise LicenseCryptoError(f'Unsupported signature algorithm: {algorithm}')

    def create_signed_envelope(
        self,
        payload: Mapping[str, Any],
        *,
        private_key: Any,
        key_id: str,
        algorithm: str = 'ed25519',
    ) -> Dict[str, Any]:
        signature = self._sign_payload(self.canonicalize_payload(payload), private_key, algorithm)
        return {
            'magic': self.ENVELOPE_MAGIC,
            'version': self.ENVELOPE_VERSION,
            'algorithm': algorithm,
            'key_id': key_id,
            'payload': dict(payload),
            'signature': self._encode_signature(signature),
        }

    def create_hmac_envelope(
        self,
        payload: Mapping[str, Any],
        *,
        key_id: str,
        key: Optional[bytes] = None,
    ) -> Dict[str, Any]:
        hmac_key = key or self._hmac_keys.get(key_id)
        if hmac_key is None:
            raise UnknownSigningKeyError(key_id)
        signature = hmac.new(hmac_key, self.canonicalize_payload(payload), sha256).digest()
        return {
            'magic': self.ENVELOPE_MAGIC,
            'version': self.ENVELOPE_VERSION,
            'algorithm': 'hmac-sha256',
            'key_id': key_id,
            'payload': dict(payload),
            'signature': self._encode_signature(signature),
        }

    def validate_envelope(self, envelope: Mapping[str, Any]) -> Dict[str, Any]:
        key_id = envelope.get('key_id')
        if not isinstance(key_id, str) or not key_id:
            raise MissingSigningKeyError()
        if key_id in self._revoked_key_ids:
            raise RevokedSigningKeyError(key_id)

        algorithm = envelope.get('algorithm')
        payload = envelope.get('payload')
        signature_b64 = envelope.get('signature')
        if not isinstance(algorithm, str):
            raise LicenseFormatError('License algorithm is invalid')
        if not isinstance(payload, Mapping):
            raise LicenseFormatError('License payload is invalid')
        if not isinstance(signature_b64, str):
            raise LicenseIntegrityError()

        payload_bytes = self.canonicalize_payload(payload)
        signature = self._decode_signature(signature_b64)

        if algorithm == 'hmac-sha256':
            hmac_key = self._hmac_keys.get(key_id)
            if hmac_key is None:
                raise UnknownSigningKeyError(key_id)
            expected = hmac.new(hmac_key, payload_bytes, sha256).digest()
            if not hmac.compare_digest(expected, signature):
                raise LicenseIntegrityError()
            return dict(payload)

        public_key = self._public_key_ring.get(key_id)
        if public_key is None:
            raise UnknownSigningKeyError(key_id)

        try:
            if algorithm == 'ed25519':
                if not isinstance(public_key, ed25519.Ed25519PublicKey):
                    raise LicenseIntegrityError()
                public_key.verify(signature, payload_bytes)
            elif algorithm == 'rsa-pss':
                if not isinstance(public_key, rsa.RSAPublicKey):
                    raise LicenseIntegrityError()
                public_key.verify(
                    signature,
                    payload_bytes,
                    padding.PSS(
                        mgf=padding.MGF1(hashes.SHA256()),
                        salt_length=padding.PSS.MAX_LENGTH,
                    ),
                    hashes.SHA256(),
                )
            else:
                raise LicenseFormatError('License algorithm is invalid')
        except LicenseFormatError:
            raise
        except Exception as exc:
            raise LicenseIntegrityError() from exc

        return dict(payload)

    def parse_license_key(self, license_key: str) -> Tuple[Dict[str, Any], str]:
        parts = license_key.split('-')
        if len(parts) < 6:
            raise LicenseCryptoError(f'Invalid license key format: too few parts ({len(parts)})')

        prefix = parts[0]
        if prefix != 'Epochly':
            raise LicenseCryptoError(f'Invalid license key prefix: {prefix}')

        lic_type = parts[1]
        features = parts[2].split(',') if parts[2] else []

        try:
            expiry = int(parts[3])
        except ValueError as exc:
            raise LicenseCryptoError(f'Invalid expiry date: {parts[3]}') from exc

        try:
            max_cores = int(parts[4])
        except ValueError as exc:
            raise LicenseCryptoError(f'Invalid max_cores: {parts[4]}') from exc

        signature_b64 = '-'.join(parts[5:])
        license_data = {
            'epochly': prefix,
            'type': lic_type,
            'features': sorted(features),
            'expiry': expiry,
            'max_cores': max_cores,
        }
        return license_data, signature_b64

    def validate_license_key(self, license_key: str) -> Tuple[bool, Optional[Dict]]:
        try:
            license_data, signature_b64 = self.parse_license_key(license_key)
            if not self.validate_license_signature(license_data, signature_b64):
                return False, None

            current_timestamp = int(datetime.now(timezone.utc).timestamp())
            if license_data['expiry'] < current_timestamp:
                return False, {'error': 'License expired'}

            return True, license_data
        except LicenseCryptoError as e:
            return False, {'error': str(e)}
        except Exception as e:  # pragma: no cover - defensive
            return False, {'error': f'Validation failed: {e}'}


class LicenseKeyGenerator:
    """Server-side license key generation helper."""

    def __init__(self, private_key_pem: Optional[bytes] = None):
        if not HAS_CRYPTOGRAPHY:
            raise LicenseCryptoError(
                'cryptography library not installed. Install with: pip install cryptography'
            )

        if private_key_pem:
            self._private_key = self._load_private_key(private_key_pem)
        else:
            self._private_key = ed25519.Ed25519PrivateKey.generate()

    def _load_private_key(self, private_key_pem: bytes) -> ed25519.Ed25519PrivateKey:
        try:
            private_key = serialization.load_pem_private_key(private_key_pem, password=None)
            if not isinstance(private_key, ed25519.Ed25519PrivateKey):
                raise LicenseCryptoError('Private key must be Ed25519')
            return private_key
        except Exception as e:
            raise LicenseCryptoError(f'Failed to load private key: {e}')

    def get_public_key_pem(self) -> bytes:
        public_key = self._private_key.public_key()
        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def generate_license_key(
        self,
        license_type: str,
        features: list,
        expiry_timestamp: int,
        max_cores: int,
    ) -> str:
        license_data = {
            'epochly': 'Epochly',
            'type': license_type,
            'features': sorted(features),
            'expiry': expiry_timestamp,
            'max_cores': max_cores,
        }
        license_bytes = LicenseCrypto.canonicalize_payload(license_data)
        signature = self._private_key.sign(license_bytes)
        signature_b64 = base64.urlsafe_b64encode(signature).decode('utf-8').rstrip('=')
        features_str = ','.join(sorted(features))
        return (
            f'Epochly-{license_type}-{features_str}-'
            f'{expiry_timestamp}-{max_cores}-{signature_b64}'
        )

    @staticmethod
    def generate_key_pair() -> Tuple[bytes, bytes]:
        if not HAS_CRYPTOGRAPHY:
            raise LicenseCryptoError(
                'cryptography library not installed. Install with: pip install cryptography'
            )

        private_key = ed25519.Ed25519PrivateKey.generate()
        private_key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        public_key = private_key.public_key()
        public_key_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return private_key_pem, public_key_pem
