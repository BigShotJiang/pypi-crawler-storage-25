from __future__ import annotations

import hashlib
import logging
import threading
from datetime import datetime, timezone
from typing import Dict, Optional

TRANSITION_EVENT_CODES = {
    "validated": "LIC-VALIDATED",
    "expired": "LIC-EXPIRED",
    "revoked": "LIC-REVOKED",
    "trial_started": "LIC-TRIAL-STARTED",
    "trial_converted": "LIC-TRIAL-CONVERTED",
    "license_loaded": "LIC-LOADED",
    "license_rejected": "LIC-REJECTED",
}


class LicenseAuditLogger:
    """Emit structured, idempotent license audit transitions."""

    def __init__(self, logger_name: str = 'epochly.licensing.audit'):
        logging.disable(logging.NOTSET)
        self._logger = logging.getLogger(logger_name)
        self._logger.disabled = False
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = True
        self._ensure_ancestor_propagation()
        self._lock = threading.RLock()
        self._last_transition_by_hash: Dict[str, str] = {}

    def emit_transition(self, transition: str, *, subject_id: Optional[str]) -> Optional[Dict[str, str]]:
        if transition not in TRANSITION_EVENT_CODES:
            raise ValueError(f'Unsupported license transition: {transition}')

        hashed_id = self._hash_id(subject_id or 'unknown-license-subject')
        with self._lock:
            if self._last_transition_by_hash.get(hashed_id) == transition:
                return None
            self._last_transition_by_hash[hashed_id] = transition

        payload = {
            'event_code': TRANSITION_EVENT_CODES[transition],
            'transition': transition,
            'timestamp_iso': datetime.now(timezone.utc).isoformat(),
            'hashed_id': hashed_id,
        }
        self._logger.disabled = False
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = True
        self._ensure_ancestor_propagation()
        self._logger.info('license_transition', extra=payload)
        return payload

    def _ensure_ancestor_propagation(self) -> None:
        ancestor = self._logger.parent
        while ancestor is not None and ancestor is not logging.getLogger():
            ancestor.propagate = True
            ancestor = ancestor.parent

    @staticmethod
    def _hash_id(subject_id: str) -> str:
        return hashlib.sha256(subject_id.encode('utf-8')).hexdigest()[:16]
