from __future__ import annotations

import re
from typing import Optional

_MAX_MESSAGE_LENGTH = 120
_INVALID_CHARS_RE = re.compile(r"[^A-Za-z0-9 ,.'-]+")
_WHITESPACE_RE = re.compile(r"\s+")


def _sanitize_message(message: Optional[str], default_message: str) -> str:
    raw = (message or default_message).strip()
    cleaned = _INVALID_CHARS_RE.sub(" ", raw)
    cleaned = _WHITESPACE_RE.sub(" ", cleaned).strip()
    if not cleaned:
        cleaned = default_message
    bounded = cleaned[:_MAX_MESSAGE_LENGTH].rstrip(" ,.-")
    return bounded or default_message


class LicenseSurfaceError(Exception):
    """Base class for bounded, user-facing licensing errors."""

    code = "license_error"
    default_message = "License validation failed"

    def __init__(self, message: Optional[str] = None, *, detail: Optional[str] = None):
        self.detail = detail
        self.user_message = _sanitize_message(message, self.default_message)
        super().__init__(f"{self.code}: {self.user_message}")


class TokenRevokedError(LicenseSurfaceError):
    code = "token_revoked"
    default_message = "Token revoked"

    def __init__(
        self,
        subject_id: str,
        revoked_at: str,
        message: Optional[str] = None,
        *,
        detail: Optional[str] = None,
    ):
        self.subject_id = subject_id
        self.revoked_at = revoked_at
        super().__init__(message or self.default_message, detail=detail)


class LicenseIntegrityError(LicenseSurfaceError):
    code = "license_integrity_error"
    default_message = "License integrity verification failed"


class LicenseFormatError(LicenseSurfaceError):
    code = "license_format_error"
    default_message = "License file format is invalid"


class LicenseSchemaError(LicenseSurfaceError):
    code = "license_schema_error"
    default_message = "License schema is invalid"


class MissingSigningKeyError(LicenseSurfaceError):
    code = "missing_signing_key"
    default_message = "Signing key id is required"


class UnknownSigningKeyError(LicenseSurfaceError):
    code = "unknown_signing_key"
    default_message = "Signing key is not active"

    def __init__(self, key_id: str, message: Optional[str] = None, *, detail: Optional[str] = None):
        self.key_id = key_id
        super().__init__(message or self.default_message, detail=detail)


class RevokedSigningKeyError(LicenseSurfaceError):
    code = "revoked_signing_key"
    default_message = "Signing key has been revoked"

    def __init__(self, key_id: str, message: Optional[str] = None, *, detail: Optional[str] = None):
        self.key_id = key_id
        super().__init__(message or self.default_message, detail=detail)
