"""
API-based Trial System for Epochly

Replaces direct AWS/DynamoDB access with API calls to api.epochly.com.
This eliminates AWS credential requirements for users.

User-side functionality MUST go through api.epochly.com - no exceptions.
"""

import hashlib
import logging
import os
import platform
import ssl
import sys
import types
from typing import Any, Dict, Optional, cast

from epochly.licensing.dev_token_validator import is_dev_bypass_active

logger = logging.getLogger(__name__)

CANONICAL_TRIAL_API_ENDPOINT = "https://api.epochly.com"
TRIAL_ENDPOINT_ALLOWLIST = frozenset({CANONICAL_TRIAL_API_ENDPOINT})
TRIAL_TLS_VERIFY = True
_TRIAL_ENDPOINT_ENV_VARS = ("EPOCHLY_API_URL", "EPOCHLY_API_ENDPOINT")
_IMMUTABLE_TRIAL_CONSTANTS = frozenset(
    {
        "CANONICAL_TRIAL_API_ENDPOINT",
        "TRIAL_ENDPOINT_ALLOWLIST",
        "TRIAL_TLS_VERIFY",
    }
)

# Lightweight imports only - NO boto3
try:
    import requests  # type: ignore[import-untyped]
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    logger.warning("requests not available - trial system disabled")


class TrialEndpointPolicyError(ValueError):
    """Raised when a trial API endpoint falls outside the immutable allow-list."""


class TrialTLSConfigurationError(RuntimeError):
    """Raised when TLS verification has been weakened for trial API traffic."""


class _ImmutableTrialModule(types.ModuleType):
    """Prevents rebinding security-sensitive trial constants after import."""

    def __setattr__(self, name: str, value: Any) -> None:
        if name in _IMMUTABLE_TRIAL_CONSTANTS and hasattr(self, name):
            raise AttributeError(f"{name} is immutable")
        super().__setattr__(name, value)

    def __delattr__(self, name: str) -> None:
        if name in _IMMUTABLE_TRIAL_CONSTANTS:
            raise AttributeError(f"{name} is immutable")
        super().__delattr__(name)


module = sys.modules.get(__name__)
if module is not None and module.__class__ is not _ImmutableTrialModule:
    module.__class__ = _ImmutableTrialModule


def _normalize_trial_endpoint(endpoint: str) -> str:
    """Normalize trial API base URLs before allow-list comparison."""
    return endpoint.strip().rstrip("/")


def _resolve_trial_api_endpoint(explicit_endpoint: Optional[str]) -> str:
    """Resolve the trial API base URL while rejecting env/config tampering."""
    candidates = []
    if explicit_endpoint is not None:
        candidates.append(("constructor", explicit_endpoint))
    for env_name in _TRIAL_ENDPOINT_ENV_VARS:
        env_value = os.environ.get(env_name)
        if env_value:
            candidates.append((env_name, env_value))

    if not candidates:
        return CANONICAL_TRIAL_API_ENDPOINT

    source_name, endpoint = candidates[0]
    normalized = _normalize_trial_endpoint(endpoint)
    if normalized not in TRIAL_ENDPOINT_ALLOWLIST:
        raise TrialEndpointPolicyError(
            f"Trial API endpoint from {source_name} is not allow-listed: {normalized}"
        )
    return normalized


def _validate_trial_tls_configuration() -> None:
    """Fail fast if TLS verification or hostname validation has been weakened."""
    if TRIAL_TLS_VERIFY is not True:
        raise TrialTLSConfigurationError("Trial API TLS verification must remain enabled")
    if not getattr(ssl, "HAS_SNI", True):
        raise TrialTLSConfigurationError("Trial API requests require SNI support")

    context = ssl.create_default_context()
    if getattr(context, "verify_mode", None) != ssl.CERT_REQUIRED:
        raise TrialTLSConfigurationError("Trial API requests require CERT_REQUIRED")
    if not bool(getattr(context, "check_hostname", False)):
        raise TrialTLSConfigurationError("Trial API requests require hostname verification")


class APITrialSystem:
    """
    API-based trial system that eliminates AWS dependencies for users.

    All trial operations go through api.epochly.com instead of direct DynamoDB.
    """

    def __init__(self, api_endpoint: Optional[str] = None, timeout: int = 10):
        """
        Initialize API trial system.

        Args:
            api_endpoint: API endpoint (defaults to api.epochly.com)
            timeout: Request timeout in seconds
        """
        _validate_trial_tls_configuration()
        self.api_endpoint = _resolve_trial_api_endpoint(api_endpoint)
        self.timeout = timeout
        self.available = REQUESTS_AVAILABLE

        if not self.available:
            logger.warning("Trial system disabled - requests library not available")

    def _get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers for API requests."""
        from epochly.config.api_endpoints import get_request_source

        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'Epochly-Client/1.0.0',
            'X-Epochly-Source': get_request_source(),
        }

        # Add node authentication if available
        try:
            from epochly.compatibility.secure_node_auth import get_secure_auth
            node_auth = get_secure_auth()
            if node_auth:
                auth_data = node_auth.generate_auth_headers({})
                headers.update(auth_data)
        except ImportError:
            logger.debug("Secure node auth not available")
        except Exception as e:
            logger.debug(f"Error getting node auth headers: {e}")

        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_payload: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Issue a hardened HTTPS request to the pinned trial API endpoint."""
        request = getattr(requests, method)
        return request(
            f"{self.api_endpoint}{path}",
            json=json_payload,
            params=params,
            headers=self._get_auth_headers(),
            timeout=self.timeout,
            verify=TRIAL_TLS_VERIFY,
        )

    def get_machine_fingerprint(self) -> str:
        """Generate machine fingerprint for trial registration."""
        try:
            from epochly.compatibility.secure_node_auth import MachineFingerprint
            return cast(str, MachineFingerprint.generate_complete_fingerprint())
        except ImportError:
            # Fallback fingerprint generation
            system_info = f"{platform.system()}:{platform.machine()}:{platform.processor()}"
            return hashlib.sha256(system_info.encode()).hexdigest()

    def activate_trial(self, email: str, machine_fingerprint: Optional[str] = None) -> Dict[str, Any]:
        """
        Activate trial via API.

        When a valid dev token bypass is active, returns a synthetic success
        response WITHOUT hitting the production API.

        Args:
            email: User email address
            machine_fingerprint: Machine fingerprint (auto-generated if None)

        Returns:
            Activation result dictionary
        """
        if not self.available:
            return {'success': False, 'error': 'API not available'}

        # Short-circuit when a valid dev token bypass is active
        if is_dev_bypass_active():
            logger.info("Dev token bypass active -- skipping production trial activation API call")
            return {
                'success': True,
                'trial_activated': True,
                'source': 'dev_bypass',
                'message': 'Dev token bypass: trial activation short-circuited',
            }

        if not machine_fingerprint:
            machine_fingerprint = self.get_machine_fingerprint()

        data = {
            'email': email,
            'machine_fingerprint': machine_fingerprint,
            'platform': platform.system(),
            'python_version': f"{platform.python_version()}",
        }

        try:
            response = self._request('post', '/trial/activate', json_payload=data)

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            return {
                'success': False,
                'error': f'API error: {response.status_code}',
                'message': response.text,
            }

        except requests.exceptions.Timeout:
            return {'success': False, 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            return {'success': False, 'error': f'Network error: {e}'}
        except Exception as e:
            return {'success': False, 'error': f'Unexpected error: {e}'}

    def validate_license(self, license_key: str) -> Dict[str, Any]:
        """
        Validate license via API.

        When a valid dev token bypass is active, returns a synthetic valid
        response WITHOUT hitting the production API, preventing non-production
        traffic from reaching prod DynamoDB (EP-20/EP-27).

        Args:
            license_key: License key to validate

        Returns:
            Validation result dictionary
        """
        if not self.available:
            return {'valid': False, 'reason': 'api_unavailable'}

        # Short-circuit when a valid dev token bypass is active
        if is_dev_bypass_active():
            logger.info("Dev token bypass active -- skipping production license validation API call")
            return {
                'valid': True,
                'tier': 'community',
                'source': 'dev_bypass',
                'message': 'Dev token bypass: license validation short-circuited',
            }

        data = {
            'license_key': license_key,
            'machine_fingerprint': self.get_machine_fingerprint(),
        }

        try:
            response = self._request('post', '/validate-license', json_payload=data)

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            return {'valid': False, 'reason': f'api_error_{response.status_code}'}

        except Exception as e:
            logger.debug(f"License validation error: {e}")
            return {'valid': False, 'reason': 'network_error'}

    def confirm_trial(self, token: str) -> Dict[str, Any]:
        """
        Confirm trial activation using the token from the verification email.

        Calls GET /trial/confirm?token=<token> on the API endpoint.

        When a valid dev token bypass is active, returns a synthetic success
        response WITHOUT hitting the production API, preventing non-production
        traffic from reaching prod DynamoDB (EP-20/EP-27).

        Args:
            token: Verification token received by email.

        Returns:
            Confirmation result dictionary.
        """
        if not self.available:
            return {'success': False, 'error': 'API not available'}

        # Short-circuit when a valid dev token bypass is active
        if is_dev_bypass_active():
            logger.info("Dev token bypass active -- skipping production trial confirmation API call")
            from datetime import datetime, timedelta, timezone
            return {
                'success': True,
                'status': 'trial_activated',
                'expires_at': (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
                'days_remaining': 30,
                'source': 'dev_bypass',
                'message': 'Dev token bypass: trial confirmation short-circuited',
            }

        try:
            response = self._request('get', '/trial/confirm', params={'token': token})

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            return {
                'success': False,
                'error': f'API error: {response.status_code}',
                'message': response.text,
            }

        except requests.exceptions.Timeout:
            return {'success': False, 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            return {'success': False, 'error': f'Network error: {e}'}
        except Exception as e:
            return {'success': False, 'error': f'Unexpected error: {e}'}

    def check_trial_status(self, machine_fingerprint: Optional[str] = None) -> Dict[str, Any]:
        """
        Check trial status via API.

        When a valid dev token bypass is active, returns a synthetic
        community-tier response WITHOUT hitting the production API, preventing
        non-production traffic from reaching prod DynamoDB (EP-20/EP-27).

        Args:
            machine_fingerprint: Machine fingerprint (auto-generated if None)

        Returns:
            Trial status dictionary
        """
        if not self.available:
            return {'has_trial': False, 'error': 'api_unavailable'}

        # Short-circuit when a valid dev token bypass is active
        if is_dev_bypass_active():
            logger.info("Dev token bypass active -- skipping production trial status API call")
            return {
                'has_trial': False,
                'tier': 'community',
                'source': 'dev_bypass',
                'message': 'Dev token bypass: trial status check short-circuited',
            }

        if not machine_fingerprint:
            machine_fingerprint = self.get_machine_fingerprint()

        try:
            response = self._request(
                'get',
                '/trial/status',
                params={'machine_fingerprint': machine_fingerprint},
            )

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            return {'has_trial': False, 'error': f'api_error_{response.status_code}'}

        except Exception as e:
            logger.debug(f"Trial status check error: {e}")
            return {'has_trial': False, 'error': 'network_error'}


class TrialPolicy:
    """
    API-based trial policy enforcement.

    Replaces direct DynamoDB access with API calls for user-side operations.
    """

    def __init__(self, api_endpoint: Optional[str] = None):
        """Initialize trial policy with API backend."""
        self.api_trial_system = APITrialSystem(api_endpoint)

    def can_use_email(self, email: str) -> bool:
        """Check if email can be used for trial via API."""
        if not self.api_trial_system.available:
            return True  # Graceful fallback - allow trial attempts

        try:
            response = self.api_trial_system._request(
                'get',
                '/trial/check-email',
                params={'email': email},
            )

            if response.status_code == 200:
                return bool(response.json().get('available', True))
            return True  # Graceful fallback

        except Exception as e:
            logger.debug(f"Email availability check failed: {e}")
            return True  # Graceful fallback

    def can_use_machine(self, machine_fingerprint: str) -> bool:
        """Check if machine can use trial via API."""
        if not self.api_trial_system.available:
            return True  # Graceful fallback

        try:
            response = self.api_trial_system._request(
                'get',
                '/trial/check-machine',
                params={'machine_fingerprint': machine_fingerprint},
            )

            if response.status_code == 200:
                return bool(response.json().get('available', True))
            return True  # Graceful fallback

        except Exception as e:
            logger.debug(f"Machine availability check failed: {e}")
            return True  # Graceful fallback

    def check_eligibility(self, email: str, machine_fingerprint: str) -> Dict[str, Any]:
        """Check trial eligibility via API."""
        if not self.api_trial_system.available:
            return {
                'eligible': True,
                'reason': 'api_unavailable',
            }

        data = {
            'email': email,
            'machine_fingerprint': machine_fingerprint,
        }

        try:
            response = self.api_trial_system._request(
                'post',
                '/trial/check-eligibility',
                json_payload=data,
            )

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            return {
                'eligible': True,  # Graceful fallback
                'reason': f'api_error_{response.status_code}',
            }

        except Exception as e:
            logger.debug(f"Eligibility check failed: {e}")
            return {
                'eligible': True,  # Graceful fallback
                'reason': 'network_error',
            }

    def mark_email_used(self, email: str, machine_fingerprint: str) -> None:
        """No-op: the activation Lambda records usage server-side."""

    def mark_machine_used(self, machine_fingerprint: str, email: str) -> None:
        """No-op: the activation Lambda records usage server-side."""


# Factory function for backward compatibility
def create_trial_system() -> APITrialSystem:
    """Create API-based trial system instance."""
    return APITrialSystem()


def create_trial_policy() -> TrialPolicy:
    """Create API-based trial policy instance."""
    return TrialPolicy()
