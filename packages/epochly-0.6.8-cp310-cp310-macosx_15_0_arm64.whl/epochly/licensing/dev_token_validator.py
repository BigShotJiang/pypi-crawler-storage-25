"""
Epochly Developer Token Validation Module

Provides cryptographically secure developer token validation to replace
insecure environment variable bypasses (EPOCHLY_DISABLE_LICENSE_ENFORCEMENT).
"""

import json
import logging
import os
import stat
import time
from contextlib import AbstractContextManager, nullcontext
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple, cast

from epochly.build_info import __version_build_time__
from epochly.licensing.license_crypto import LicenseCrypto

from .errors import TokenRevokedError
from .license_audit import LicenseAuditLogger
from .revocation import RevocationStore

logger = logging.getLogger(__name__)


class ValidationReason(Enum):
    VALID = "valid"
    NOT_IN_TEST_MODE = "not_in_test_mode"
    TOKEN_NOT_FOUND = "token_not_found"
    TOKEN_INVALID_JSON = "token_invalid_json"
    TOKEN_INVALID_STRUCTURE = "token_invalid_structure"
    TOKEN_FILE_PERMISSIONS_UNSAFE = "token_file_permissions_unsafe"
    TOKEN_FILE_TOO_LARGE = "token_file_too_large"
    SIGNATURE_INVALID = "signature_invalid"
    PAYLOAD_INVALID = "payload_invalid"
    TOKEN_EXPIRED = "token_expired"
    TOKEN_NOT_YET_VALID = "token_not_yet_valid"
    TOKEN_LIFETIME_EXCEEDED = "token_lifetime_exceeded"
    TOKEN_EXPIRY_OUT_OF_RANGE = "token_expiry_out_of_range"
    TOKEN_REVOKED = "token_revoked"
    ISSUER_INVALID = "issuer_invalid"
    ENVIRONMENT_INVALID = "environment_invalid"


class DevTokenError(Exception):
    """Raised when dev token validation fails"""


class DevTokenExpiryOutOfRangeError(DevTokenError):
    """Raised when a dev token expiration exceeds the build-time horizon."""


@dataclass
class DevTokenPayload:
    subject: str
    issuer: str
    issued_at: int
    expires_at: int
    token_id: str
    tier: str
    features: List[str]
    environment: str
    hardware_fingerprint: Optional[str] = None


@dataclass
class DevTokenValidationResult:
    valid: bool
    payload: Optional[DevTokenPayload] = None
    error: Optional[str] = None
    reason: ValidationReason = ValidationReason.VALID
    revoked: bool = False
    expired: bool = False
    exception: Optional[Exception] = None

    def __bool__(self) -> bool:
        return self.valid


class DevTokenValidator:
    TOKEN_LOCATIONS = [
        Path.home() / '.epochly' / 'dev-token.json',
        Path('.epochly') / 'dev-token.json',
    ]
    REQUIRED_FIELDS = ['sub', 'iss', 'iat', 'exp', 'jti', 'tier', 'features', 'env']
    VALID_TIERS = ['developer', 'enterprise-dev', 'ci-cd']
    VALID_ENVIRONMENTS = ['development', 'testing', 'ci']
    REQUIRED_ISSUER = 'api.epochly.com'
    CLOCK_SKEW_TOLERANCE = 300
    MAX_TOKEN_FILE_SIZE = 65536
    MAX_TOKEN_LIFETIME = 90 * 24 * 60 * 60
    MAX_DEV_TOKEN_VALIDITY_SECONDS = 63_072_000
    MAX_TIMESTAMP = __version_build_time__ + MAX_DEV_TOKEN_VALIDITY_SECONDS
    SIGNATURE_DOMAIN = b"EPOCHLY_DEV_TOKEN_V1:"

    def __init__(
        self,
        crypto: Optional[LicenseCrypto] = None,
        revocation_endpoint: Optional[str] = None,
        require_test_mode: bool = True,
        revocation_store: Optional[RevocationStore] = None,
        audit_logger: Optional[LicenseAuditLogger] = None,
    ):
        self._crypto = crypto or LicenseCrypto()
        self._revocation_endpoint = revocation_endpoint or 'https://api.epochly.com/v1/revocation'
        self._require_test_mode = require_test_mode
        self._cached_token: Optional[Dict] = None
        self._cached_result: Optional[DevTokenValidationResult] = None
        self._cache_timestamp: float = 0.0
        self._cache_ttl = 60.0
        self._revocation_store = revocation_store or RevocationStore()
        self._audit_logger = audit_logger or LicenseAuditLogger()

    def find_token_file(self) -> Optional[Path]:
        for path in self.TOKEN_LOCATIONS:
            if path.exists() and path.is_file():
                logger.debug(f"Found dev token at: {path}")
                return path
        return None

    def _check_file_permissions(self, path: Path) -> Tuple[bool, Optional[str]]:
        if os.name != 'posix':
            return True, None

        try:
            resolved = path.resolve()
            file_stat = resolved.stat()
            if not stat.S_ISREG(file_stat.st_mode):
                return False, f"Token path is not a regular file: {resolved}"
            current_uid = os.getuid()
            if file_stat.st_uid != current_uid and file_stat.st_uid != 0:
                return False, f"Token file not owned by current user: {resolved}"
            unsafe_bits = stat.S_IWGRP | stat.S_IWOTH
            if file_stat.st_mode & unsafe_bits:
                return False, f"Token file has unsafe permissions (group/world writable): {resolved}"
            return True, None
        except OSError as e:
            return False, f"Failed to check file permissions: {e}"

    def _check_file_size(self, path: Path) -> Tuple[bool, Optional[str]]:
        try:
            file_size = path.stat().st_size
            if file_size > self.MAX_TOKEN_FILE_SIZE:
                return False, f"Token file too large ({file_size} bytes, max {self.MAX_TOKEN_FILE_SIZE})"
            return True, None
        except OSError as e:
            return False, f"Failed to check file size: {e}"

    def load_token_from_file(self, path: Optional[Path] = None) -> Tuple[Optional[Dict], ValidationReason]:
        token_path = path or self.find_token_file()
        if not token_path:
            logger.debug("No dev token file found")
            return None, ValidationReason.TOKEN_NOT_FOUND
        if path is not None and not path.exists():
            logger.debug(f"Specified token file does not exist: {path}")
            return None, ValidationReason.TOKEN_NOT_FOUND

        size_ok, size_error = self._check_file_size(token_path)
        if not size_ok:
            logger.warning(size_error)
            return None, ValidationReason.TOKEN_FILE_TOO_LARGE

        perms_ok, perms_error = self._check_file_permissions(token_path)
        if not perms_ok:
            logger.warning(perms_error)
            return None, ValidationReason.TOKEN_FILE_PERMISSIONS_UNSAFE

        try:
            with open(token_path, 'r', encoding='utf-8') as f:
                token_data = json.load(f)
            if not isinstance(token_data, dict):
                logger.warning(f"Invalid token structure in {token_path}")
                return None, ValidationReason.TOKEN_INVALID_STRUCTURE
            if 'payload' not in token_data or 'signature' not in token_data:
                logger.warning(f"Token missing required fields in {token_path}")
                return None, ValidationReason.TOKEN_INVALID_STRUCTURE
            return token_data, ValidationReason.VALID
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse token file {token_path}: {e}")
            return None, ValidationReason.TOKEN_INVALID_JSON
        except IOError as e:
            logger.warning(f"Failed to read token file {token_path}: {e}")
            return None, ValidationReason.TOKEN_NOT_FOUND

    def _validate_expiration_horizon(self, payload: Dict) -> None:
        exp = payload.get('exp')
        if isinstance(exp, int) and exp > self.MAX_TIMESTAMP:
            raise DevTokenExpiryOutOfRangeError(
                f"exp timestamp too large for build-time horizon (max {self.MAX_TIMESTAMP}, got {exp})"
            )

    def validate_signature(self, token_data: Dict) -> bool:
        try:
            payload = token_data.get('payload', {})
            signature_b64 = token_data.get('signature', '')
            if not payload or not signature_b64:
                return False
            return self._crypto.validate_license_signature(payload, signature_b64)
        except Exception as e:
            logger.debug(f"Signature validation failed: {e}")
            return False

    def validate_payload(self, payload: Dict) -> Tuple[bool, Optional[str], ValidationReason]:
        missing_fields = [f for f in self.REQUIRED_FIELDS if f not in payload]
        if missing_fields:
            return False, f"Missing required fields: {missing_fields}", ValidationReason.PAYLOAD_INVALID
        if payload.get('iss') != self.REQUIRED_ISSUER:
            return False, f"Invalid issuer: {payload.get('iss')}", ValidationReason.ISSUER_INVALID
        tier = payload.get('tier')
        if tier not in self.VALID_TIERS:
            return False, f"Invalid tier: {tier}", ValidationReason.PAYLOAD_INVALID
        env = payload.get('env')
        if env not in self.VALID_ENVIRONMENTS:
            return False, f"Invalid environment: {env}", ValidationReason.ENVIRONMENT_INVALID
        features = payload.get('features')
        if not isinstance(features, list):
            return False, 'features must be a list', ValidationReason.PAYLOAD_INVALID
        for field in ['iat', 'exp']:
            val = payload.get(field)
            if not isinstance(val, int):
                return False, f"{field} must be an integer timestamp", ValidationReason.PAYLOAD_INVALID

        iat = payload['iat']
        exp = payload['exp']
        current_time = int(time.time())
        try:
            self._validate_expiration_horizon(payload)
        except DevTokenExpiryOutOfRangeError as exc:
            return False, str(exc), ValidationReason.TOKEN_EXPIRY_OUT_OF_RANGE

        if iat > current_time + self.CLOCK_SKEW_TOLERANCE:
            return False, 'Token issued in the future (iat > now + skew)', ValidationReason.TOKEN_NOT_YET_VALID
        token_lifetime = exp - iat
        if token_lifetime > self.MAX_TOKEN_LIFETIME:
            return False, f"Token lifetime too long ({token_lifetime}s, max {self.MAX_TOKEN_LIFETIME}s)", ValidationReason.TOKEN_LIFETIME_EXCEEDED
        if token_lifetime < 0:
            return False, 'Token expiration before issued time', ValidationReason.PAYLOAD_INVALID
        return True, None, ValidationReason.VALID

    def check_expiration(self, payload: Dict) -> Tuple[bool, bool]:
        current_time = int(time.time())
        exp = payload.get('exp', 0)
        is_expired = current_time > (exp + self.CLOCK_SKEW_TOLERANCE)
        return not is_expired, is_expired

    def check_revocation(self, jti: str) -> bool:
        local_record = self._revocation_store.get(jti)
        if local_record is not None:
            return True
        try:
            import requests  # type: ignore[import-untyped]

            url = f"{self._revocation_endpoint}/{jti}"
            response = requests.get(url, timeout=5)
            if response.status_code == 404:
                self._revocation_store.revoke(jti)
                logger.warning(f"Token {jti[:8]}... is revoked")
                return True
            return False
        except ImportError:
            logger.debug("requests library not available, skipping revocation check")
            return False
        except Exception as e:
            logger.debug(f"Revocation check failed (failing open): {e}")
            return False

    def check_test_mode(self) -> bool:
        if not self._require_test_mode:
            return True
        return (
            os.environ.get('EPOCHLY_TEST_MODE') == '1'
            or os.environ.get('EPOCHLY_DEV_BYPASS') == '1'
        )

    def validate(self, token_data: Optional[Dict] = None, skip_revocation: bool = False) -> DevTokenValidationResult:
        if not self.check_test_mode():
            return DevTokenValidationResult(
                valid=False,
                error='EPOCHLY_TEST_MODE=1 or EPOCHLY_DEV_BYPASS=1 required for dev token bypass',
                reason=ValidationReason.NOT_IN_TEST_MODE,
            )

        if skip_revocation and self._use_cache(token_data):
            assert self._cached_result is not None
            return self._cached_result

        if token_data is None:
            token_data, load_reason = self.load_token_from_file()
            if token_data is None:
                return DevTokenValidationResult(
                    valid=False,
                    error=f"Failed to load token: {load_reason.value}",
                    reason=load_reason,
                )

        payload = token_data.get('payload', {})
        subject_id = payload.get('jti', '') if isinstance(payload, dict) else ''
        revocation_context = cast(
            AbstractContextManager[object],
            self._revocation_store.validation_session(subject_id)
            if not skip_revocation and subject_id
            else nullcontext(),
        )

        try:
            with revocation_context:
                try:
                    self._validate_expiration_horizon(payload)
                except DevTokenExpiryOutOfRangeError as exc:
                    return DevTokenValidationResult(
                        valid=False,
                        error=str(exc),
                        reason=ValidationReason.TOKEN_EXPIRY_OUT_OF_RANGE,
                        exception=exc,
                    )

                if not self.validate_signature(token_data):
                    return DevTokenValidationResult(
                        valid=False,
                        error='Invalid token signature',
                        reason=ValidationReason.SIGNATURE_INVALID,
                    )

                is_valid, error, reason = self.validate_payload(payload)
                if not is_valid:
                    return DevTokenValidationResult(valid=False, error=error, reason=reason)

                not_expired, is_expired = self.check_expiration(payload)
                if not not_expired:
                    if subject_id:
                        self._audit_logger.emit_transition('expired', subject_id=subject_id)
                    return DevTokenValidationResult(
                        valid=False,
                        error='Token expired',
                        reason=ValidationReason.TOKEN_EXPIRED,
                        expired=True,
                    )

                if not skip_revocation and subject_id and self.check_revocation(subject_id):
                    local_record = self._revocation_store.get(subject_id)
                    revoked_error = TokenRevokedError(
                        subject_id,
                        local_record.revoked_at if local_record is not None else '',
                    )
                    self._audit_logger.emit_transition('revoked', subject_id=subject_id)
                    return DevTokenValidationResult(
                        valid=False,
                        error=str(revoked_error),
                        reason=ValidationReason.TOKEN_REVOKED,
                        revoked=True,
                        exception=revoked_error,
                    )

                validated_payload = DevTokenPayload(
                    subject=payload['sub'],
                    issuer=payload['iss'],
                    issued_at=payload['iat'],
                    expires_at=payload['exp'],
                    token_id=payload['jti'],
                    tier=payload['tier'],
                    features=payload['features'],
                    environment=payload['env'],
                    hardware_fingerprint=payload.get('hwfp'),
                )
                result = DevTokenValidationResult(
                    valid=True,
                    payload=validated_payload,
                    reason=ValidationReason.VALID,
                )
                self._update_cache(token_data, result)
                self._audit_logger.emit_transition('validated', subject_id=validated_payload.token_id)
                jti_short = payload['jti'][:8] if payload.get('jti') else 'unknown'
                logger.info(f"Dev token validated: tier={validated_payload.tier}, jti={jti_short}...")
                return result
        except TokenRevokedError as exc:
            self._audit_logger.emit_transition('revoked', subject_id=subject_id or exc.subject_id)
            return DevTokenValidationResult(
                valid=False,
                error=str(exc),
                reason=ValidationReason.TOKEN_REVOKED,
                revoked=True,
                exception=exc,
            )

    def _use_cache(self, token_data: Optional[Dict]) -> bool:
        if self._cached_result is None:
            return False
        if time.time() - self._cache_timestamp > self._cache_ttl:
            return False
        if token_data is not None and token_data != self._cached_token:
            return False
        return True

    def _update_cache(self, token_data: Dict, result: DevTokenValidationResult) -> None:
        self._cached_token = token_data
        self._cached_result = result
        self._cache_timestamp = time.time()

    def clear_cache(self) -> None:
        self._cached_token = None
        self._cached_result = None
        self._cache_timestamp = 0.0

    def has_feature(self, feature: str) -> bool:
        result = self.validate()
        if not result.valid or not result.payload:
            return False
        return feature in result.payload.features


def get_dev_token_validator() -> DevTokenValidator:
    instance = getattr(get_dev_token_validator, '_instance', None)
    if instance is None:
        instance = DevTokenValidator()
        setattr(get_dev_token_validator, '_instance', instance)
    return instance


def is_dev_bypass_active() -> bool:
    try:
        validator = get_dev_token_validator()
        result = validator.validate(skip_revocation=True)
        return result.valid
    except Exception as e:
        logger.debug(f"Dev bypass check failed: {e}")
        return False


def get_dev_token_features() -> List[str]:
    try:
        validator = get_dev_token_validator()
        result = validator.validate(skip_revocation=True)
        if result.valid and result.payload:
            return result.payload.features
    except Exception:
        pass
    return []
