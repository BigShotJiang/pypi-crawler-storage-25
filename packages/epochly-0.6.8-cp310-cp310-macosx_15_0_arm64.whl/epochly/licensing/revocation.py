from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from tempfile import gettempdir
from typing import Dict, Literal, Optional

from .errors import TokenRevokedError


@dataclass(frozen=True)
class RevocationRecord:
    subject_id: str
    revoked_at: str
    kind: str = 'token'
    reason: str = 'revoked'


class _ValidationSession:
    def __init__(self, store: 'RevocationStore', subject_id: Optional[str]):
        self._store = store
        self._subject_id = subject_id

    def __enter__(self) -> '_ValidationSession':
        self._assert_not_revoked()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> Literal[False]:
        if exc_type is None:
            self._assert_not_revoked()
        return False

    def _assert_not_revoked(self) -> None:
        if not self._subject_id:
            return
        record = self._store.get(self._subject_id)
        if record is not None:
            raise TokenRevokedError(record.subject_id, record.revoked_at)


class RevocationStore:
    DEFAULT_CACHE_TTL = 60.0

    def __init__(self, file_path: Optional[Path] = None, cache_ttl: float = DEFAULT_CACHE_TTL):
        resolved_path = Path(file_path) if file_path is not None else self._default_file_path()
        self.file_path = resolved_path
        self.cache_ttl = min(float(cache_ttl), self.DEFAULT_CACHE_TTL)
        self._lock = threading.RLock()
        self._records: Dict[str, RevocationRecord] = {}
        self._last_load = 0.0
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        self._refresh_if_needed(bypass_cache=True)

    @staticmethod
    def _default_file_path() -> Path:
        override = os.environ.get('EPOCHLY_REVOCATION_STORE_PATH')
        if override:
            return Path(override)
        if os.environ.get('EPOCHLY_TEST_MODE') == '1':
            return Path(gettempdir()) / f"epochly-revocations-test-{os.getpid()}-{time.time_ns()}.json"
        return Path.home() / '.epochly' / 'revocations.json'

    def revoke(
        self,
        subject_id: str,
        *,
        revoked_at: Optional[str] = None,
        kind: str = 'token',
        reason: str = 'revoked',
    ) -> RevocationRecord:
        record = RevocationRecord(
            subject_id=subject_id,
            revoked_at=revoked_at or datetime.now(timezone.utc).isoformat(),
            kind=kind,
            reason=reason,
        )
        with self._lock:
            self._refresh_if_needed(bypass_cache=True)
            self._records[subject_id] = record
            self._persist_locked()
            self._last_load = time.monotonic()
        return record

    def get(self, subject_id: str) -> Optional[RevocationRecord]:
        with self._lock:
            self._refresh_if_needed()
            return self._records.get(subject_id)

    def is_revoked(self, subject_id: str) -> bool:
        return self.get(subject_id) is not None

    def validation_session(self, subject_id: Optional[str]) -> _ValidationSession:
        return _ValidationSession(self, subject_id)

    def _refresh_if_needed(self, *, bypass_cache: bool = False) -> None:
        now = time.monotonic()
        if not bypass_cache and now - self._last_load < self.cache_ttl:
            return

        if not self.file_path.exists():
            self._records = {}
            self._last_load = now
            return

        try:
            raw = self.file_path.read_text(encoding='utf-8')
            parsed = json.loads(raw) if raw.strip() else {}
        except (OSError, ValueError, TypeError):
            self._records = {}
            self._last_load = now
            return

        revoked_ids = parsed.get('revoked_ids', {})
        refreshed: Dict[str, RevocationRecord] = {}
        for subject_id, value in revoked_ids.items():
            refreshed[subject_id] = RevocationRecord(
                subject_id=subject_id,
                revoked_at=value.get('revoked_at', ''),
                kind=value.get('kind', 'token'),
                reason=value.get('reason', 'revoked'),
            )
        self._records = refreshed
        self._last_load = now

    def _persist_locked(self) -> None:
        payload = {
            'revoked_ids': {
                subject_id: {
                    'revoked_at': record.revoked_at,
                    'kind': record.kind,
                    'reason': record.reason,
                }
                for subject_id, record in sorted(self._records.items())
            }
        }
        temp_path = self.file_path.with_suffix('.tmp')
        temp_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding='utf-8')
        temp_path.replace(self.file_path)
