from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Union

from .errors import LicenseFormatError, LicenseSchemaError
from .license_audit import LicenseAuditLogger
from .license_crypto import LicenseCrypto

LicenseSource = Union[Path, str, bytes, Mapping[str, Any]]


class LicenseLoader:
    MAGIC = 'EPOCHLY_LICENSE'
    VERSION = 1
    MAX_LICENSE_FILE_BYTES = 65_536
    ALLOWED_TOP_LEVEL_KEYS = frozenset({'magic', 'version', 'algorithm', 'key_id', 'payload', 'signature'})

    def __init__(self, crypto: Optional[LicenseCrypto] = None, audit_logger: Optional[LicenseAuditLogger] = None):
        self._crypto = crypto or LicenseCrypto()
        self._audit_logger = audit_logger or LicenseAuditLogger()

    def load(self, source: LicenseSource) -> Dict[str, Any]:
        envelope = self._parse_envelope(source)
        payload = self._crypto.validate_envelope(envelope)
        subject_id = self._extract_subject_id(payload)
        self._audit_logger.emit_transition('license_loaded', subject_id=subject_id)
        return payload

    def _parse_envelope(self, source: LicenseSource) -> Dict[str, Any]:
        if isinstance(source, Mapping):
            envelope = dict(source)
            raw = json.dumps(envelope, separators=(',', ':'), sort_keys=True).encode('utf-8')
        else:
            raw = self._read_bytes(source)
            try:
                envelope = json.loads(raw.decode('utf-8'))
            except (UnicodeDecodeError, ValueError) as exc:
                raise LicenseFormatError('License file format is invalid') from exc

        if not isinstance(envelope, dict):
            raise LicenseSchemaError('License envelope must be an object')

        unknown_keys = set(envelope) - set(self.ALLOWED_TOP_LEVEL_KEYS)
        if unknown_keys:
            raise LicenseSchemaError('Unknown top level keys are not allowed')

        if envelope.get('magic') != self.MAGIC:
            raise LicenseFormatError('License file magic is invalid')
        if envelope.get('version') != self.VERSION:
            raise LicenseFormatError('License file version is invalid')
        if not isinstance(envelope.get('algorithm'), str):
            raise LicenseSchemaError('License algorithm must be a string')
        if not isinstance(envelope.get('payload'), dict):
            raise LicenseSchemaError('License payload must be an object')
        if not isinstance(envelope.get('signature'), str):
            raise LicenseSchemaError('License signature must be a string')

        return envelope

    def _read_bytes(self, source: Union[Path, str, bytes]) -> bytes:
        if isinstance(source, bytes):
            raw = source
        else:
            path = Path(source)
            raw = path.read_bytes()

        if len(raw) > self.MAX_LICENSE_FILE_BYTES:
            raise LicenseFormatError('License file exceeds the maximum supported size')
        return raw

    @staticmethod
    def _extract_subject_id(payload: Mapping[str, Any]) -> str:
        return str(
            payload.get('license_id')
            or payload.get('jti')
            or payload.get('subject')
            or 'license-subject'
        )
