"""Canonical Python version support metadata for Epochly."""

from __future__ import annotations

import sys
from typing import Optional, Sequence


SUPPORTED_PYTHON_VERSIONS: tuple[str, ...] = (
    "3.9",
    "3.10",
    "3.11",
    "3.12",
    "3.13",
    "3.14",
)

SUPPORTED_PYTHON_MIN: tuple[int, int] = (3, 9)
SUPPORTED_PYTHON_MAX: tuple[int, int] = (3, 14)


def supported_python_versions() -> tuple[str, ...]:
    """Return the supported Python minor-version list."""
    return SUPPORTED_PYTHON_VERSIONS


def supported_python_range() -> str:
    """Return the bounded supported Python version range."""
    return f"{SUPPORTED_PYTHON_VERSIONS[0]}-{SUPPORTED_PYTHON_VERSIONS[-1]}"


def supported_python_versions_text(versions: Optional[Sequence[str]] = None) -> str:
    """Return a human-readable supported Python version list."""
    values = tuple(versions or SUPPORTED_PYTHON_VERSIONS)
    return ", ".join(values)


def current_python_minor(version_info: sys.version_info = sys.version_info) -> str:
    """Return the current Python major.minor string."""
    return f"{version_info.major}.{version_info.minor}"


def is_supported_python(version_info: sys.version_info = sys.version_info) -> bool:
    """Return whether ``version_info`` is in the declared supported range."""
    current = (version_info.major, version_info.minor)
    return SUPPORTED_PYTHON_MIN <= current <= SUPPORTED_PYTHON_MAX


def is_below_supported_python(version_info: sys.version_info = sys.version_info) -> bool:
    """Return whether ``version_info`` is below the supported Python floor."""
    return (version_info.major, version_info.minor) < SUPPORTED_PYTHON_MIN
