"""SharedMemory allocation helpers for signed pickle key handoff."""

import os
from typing import Any, Tuple


_SIGNED_PICKLE_KEY_SIZE = 32
_SIGNED_PICKLE_SEGMENT_CREATE_ATTEMPTS = 5


def _new_segment_name() -> str:
    """Return an epk-prefixed SharedMemory segment name with a fresh hex suffix."""
    return f"epk_{os.getpid()}_{os.urandom(8).hex()}"


def create_signed_pickle_key_segment(shm_module: Any, key: bytes) -> Tuple[Any, str]:
    """Create a collision-safe SharedMemory segment for a signed pickle key.

    Windows can retain named shared-memory objects briefly after a previous test
    or worker exits. A single manually-generated name can collide with that stale
    object and raise FileExistsError. Retrying with a fresh suffix preserves the
    existing epk_<pid>_<hex> naming contract while making creation robust.
    """
    if len(key) != _SIGNED_PICKLE_KEY_SIZE:
        raise ValueError("signed pickle key must be exactly 32 bytes")

    last_collision = None
    for _ in range(_SIGNED_PICKLE_SEGMENT_CREATE_ATTEMPTS):
        segment_name = _new_segment_name()
        try:
            segment = shm_module.SharedMemory(
                create=True,
                size=_SIGNED_PICKLE_KEY_SIZE,
                name=segment_name,
            )
        except FileExistsError as exc:
            last_collision = exc
            continue

        try:
            segment.buf[:_SIGNED_PICKLE_KEY_SIZE] = key
        except Exception:
            try:
                segment.close()
            except Exception:
                pass
            try:
                segment.unlink()
            except Exception:
                pass
            raise

        return segment, segment_name

    raise FileExistsError(
        "Unable to create a unique Epochly signed pickle SharedMemory segment "
        f"after {_SIGNED_PICKLE_SEGMENT_CREATE_ATTEMPTS} attempts"
    ) from last_collision
