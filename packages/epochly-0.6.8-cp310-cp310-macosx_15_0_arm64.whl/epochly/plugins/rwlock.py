"""
Reader-Writer Lock (Task 5 Implementation)

Allows multiple concurrent readers while ensuring exclusive writer access.

Performance Improvements:
- 2× throughput for read-heavy workloads (target)
- Eliminates serialization of concurrent reads
- Maintains mutual exclusion for writes

Usage:
    from epochly.plugins.rwlock import RWLock

    lock = RWLock()

    # Multiple readers can acquire concurrently
    with lock.reader():
        data = read_shared_data()

    # Writers get exclusive access
    with lock.writer():
        modify_shared_data()
"""

import threading
import time
from contextlib import contextmanager
from typing import Generator, Optional

# Try to use proven library implementation
# VAL-DEPS-003: optional
try:
    from readerwriterlock import rwlock as _rwlock_lib
    _HAS_LIBRARY = True
except ImportError:
    _rwlock_lib = None
    _HAS_LIBRARY = False


class RWLock:
    """
    Reader-writer lock wrapper.

    Uses readerwriterlock library when available (proven implementation),
    falls back to SimplifiedRWLock otherwise.
    """

    def __init__(self):
        """Initialize RWLock with best available implementation."""
        if _HAS_LIBRARY:
            self._lock = _rwlock_lib.RWLockFair()
            self._using_library = True
        else:
            self._lock = SimplifiedRWLock()
            self._using_library = False

    @contextmanager
    def reader(self) -> Generator[None, None, None]:
        """Acquire read lock (multiple concurrent readers allowed)."""
        if self._using_library:
            lock_handle = self._lock.gen_rlock()
            lock_handle.acquire()
            try:
                yield
            finally:
                lock_handle.release()
        else:
            with self._lock.reader():
                yield

    @contextmanager
    def writer(self) -> Generator[None, None, None]:
        """Acquire write lock (exclusive access)."""
        if self._using_library:
            lock_handle = self._lock.gen_wlock()
            lock_handle.acquire()
            try:
                yield
            finally:
                lock_handle.release()
        else:
            with self._lock.writer():
                yield


class SimplifiedRWLock:
    """
    Simplified reader-writer lock fallback.

    Uses condition-variable based writer mutual exclusion so that
    writer death (thread exits while holding the lock) does not
    permanently deadlock subsequent writers.
    """

    def __init__(self):
        self._condition = threading.Condition()
        self._readers = 0
        self._writer = False
        self._writer_pending = False
        self._writer_owner: Optional[threading.Thread] = None
        self._pending_owner: Optional[threading.Thread] = None
        self._writer_timeout = 0.1
        self._reader_wait_timeout = 5.0

    @contextmanager
    def reader(self):
        """Acquire read lock. Multiple concurrent readers are allowed."""
        with self._condition:
            while self._writer or self._writer_pending:
                # FIX (H2): Detect dead active writer so readers don't deadlock forever
                if self._writer and self._writer_owner and not self._writer_owner.is_alive():
                    self._writer = False
                    self._writer_owner = None
                    self._condition.notify_all()
                    continue
                if self._writer_pending and self._pending_owner and not self._pending_owner.is_alive():
                    self._writer_pending = False
                    self._pending_owner = None
                    continue
                self._condition.wait(timeout=self._reader_wait_timeout)
            self._readers += 1

        try:
            yield
        finally:
            with self._condition:
                self._readers -= 1
                if self._readers == 0:
                    # notify(1): wake exactly one waiting writer when the last
                    # reader exits. Only one writer can acquire the lock, so
                    # notify_all() here would cause a thundering herd with all
                    # waiting writers contending unnecessarily. Writer release
                    # still uses notify_all() so all blocked readers wake at once.
                    self._condition.notify(1)

    def _is_writer_owner_alive(self) -> bool:
        """Check if the thread that holds the write lock is still alive."""
        owner = self._writer_owner
        if owner is None:
            return False
        return owner.is_alive()

    @contextmanager
    def writer(self):
        """Acquire write lock. Exclusive access; detects dead pending/active writers."""
        with self._condition:
            # Wait until no other writer is pending (or previous pending owner died)
            while self._writer_pending:
                if self._pending_owner and not self._pending_owner.is_alive():
                    self._writer_pending = False
                    self._pending_owner = None
                    break
                self._condition.wait(timeout=self._writer_timeout)
            self._writer_pending = True
            self._pending_owner = threading.current_thread()

            # FIX (M1): Wrap acquisition in try/except so that an exception
            # (including KeyboardInterrupt) cleans up _writer_pending state.
            # Without this, an exception leaves _writer_pending=True permanently,
            # blocking all future writers and readers.
            try:
                deadline = time.monotonic() + self._writer_timeout
                while self._writer or self._readers > 0:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        # Check if writer died while holding the lock
                        if self._writer and not self._is_writer_owner_alive():
                            self._writer = False
                            self._writer_owner = None
                            self._condition.notify_all()
                        else:
                            # Reset deadline and keep waiting
                            deadline = time.monotonic() + self._writer_timeout
                        continue
                    self._condition.wait(timeout=remaining)
            except BaseException:
                # Clean up pending state on any exception during acquisition
                self._writer_pending = False
                self._pending_owner = None
                self._condition.notify_all()
                raise

            self._writer_pending = False
            self._pending_owner = None
            self._writer = True
            self._writer_owner = threading.current_thread()
            # FIX (M2): Removed notify_all() here — notifying after writer
            # acquires causes thundering herd (all blocked readers/writers
            # wake up only to find the lock is still held).  Only notify
            # on writer RELEASE (below), where waiters can actually proceed.
        try:
            yield
        finally:
            with self._condition:
                self._writer = False
                self._writer_owner = None
                self._condition.notify_all()
