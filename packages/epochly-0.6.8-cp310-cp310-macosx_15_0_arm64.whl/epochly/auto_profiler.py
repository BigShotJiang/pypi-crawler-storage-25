"""Public compatibility surface for Epochly auto-profiler state."""

import sys
from typing import Any

from .core.import_hook import EpochlyImportHook
from .profiling.auto_profiler import (
    AutoProfiler,
    HotLoopInfo,
    OptimizationResult,
    get_auto_profiler,
    initialize_auto_profiler,
    is_auto_profiler_disabled_by_env,
    set_auto_profiler,
)


def _is_hook_installed() -> bool:
    """Return whether the transparent Epochly import hook is installed."""
    return any(isinstance(hook, EpochlyImportHook) for hook in sys.meta_path)


def __getattr__(name: str) -> Any:
    if name == "_hook_installed":
        return _is_hook_installed()
    raise AttributeError(name)


__all__ = [
    "AutoProfiler",
    "HotLoopInfo",
    "OptimizationResult",
    "get_auto_profiler",
    "initialize_auto_profiler",
    "is_auto_profiler_disabled_by_env",
    "set_auto_profiler",
]
