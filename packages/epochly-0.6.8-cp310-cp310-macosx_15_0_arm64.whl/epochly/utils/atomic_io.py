"""
Atomic file-write helpers for durable on-disk state.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Optional, Union


PathLike = Union[str, os.PathLike[str]]


def _write_all(fd: int, payload: bytes) -> None:
    view = memoryview(payload)
    total_written = 0
    while total_written < len(view):
        written = os.write(fd, view[total_written:])
        if written <= 0:
            raise OSError("short write while persisting atomic payload")
        total_written += written


def _fsync_directory(directory: Path) -> None:
    if os.name == "nt" or not hasattr(os, "O_DIRECTORY"):
        return

    dir_fd = os.open(str(directory), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def atomic_write_bytes(
    path: PathLike,
    payload: bytes,
    *,
    mode: Optional[int] = None,
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    temp_fd, temp_path = tempfile.mkstemp(
        dir=str(target.parent),
        prefix=f".{target.name}.",
        suffix=".tmp",
    )
    temp_path_obj = Path(temp_path)

    try:
        if mode is not None and hasattr(os, "fchmod"):
            os.fchmod(temp_fd, mode)

        _write_all(temp_fd, payload)
        os.fsync(temp_fd)
        os.close(temp_fd)
        temp_fd = -1

        if mode is not None and not hasattr(os, "fchmod"):
            os.chmod(temp_path, mode)

        os.replace(temp_path, str(target))
        _fsync_directory(target.parent)
        return target
    except Exception:
        if temp_fd >= 0:
            try:
                os.close(temp_fd)
            except OSError:
                pass
        try:
            os.unlink(temp_path_obj)
        except OSError:
            pass
        raise


def atomic_write_text(
    path: PathLike,
    content: str,
    *,
    encoding: str = "utf-8",
    mode: Optional[int] = None,
) -> Path:
    return atomic_write_bytes(path, content.encode(encoding), mode=mode)
