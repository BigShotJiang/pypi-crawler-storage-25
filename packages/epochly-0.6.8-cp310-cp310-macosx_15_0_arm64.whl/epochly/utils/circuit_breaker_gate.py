"""Backward-compatible aliases for the shared HALF_OPEN gate."""

from __future__ import annotations

from ..concurrency.half_open_gate import HalfOpenGate, HalfOpenGateLease

SemaphoreGate = HalfOpenGate
SemaphoreGateLease = HalfOpenGateLease

__all__ = [
    "SemaphoreGate",
    "SemaphoreGateLease",
    "HalfOpenGate",
    "HalfOpenGateLease",
]
