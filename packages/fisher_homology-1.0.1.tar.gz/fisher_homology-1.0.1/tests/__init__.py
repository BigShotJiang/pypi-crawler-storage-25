"""
tests/__init__.py
============================
Fisher Information Persistent Homology

Pure-Python implementation of topological data analysis (TDA) for probability
manifolds, using the Fisher information arc length as the filtration metric.

Public API:
    FisherHomology          — main analysis class
    PersistenceDiagram      — result container
    fisher_distance         — pairwise distance between probability vectors
    bottleneck_distance     — compare two persistence diagrams
    betti_curve             — Betti numbers at each epsilon scale
"""

from fisher_homology.core import FisherHomology, PersistenceDiagram
from fisher_homology.distances import fisher_arc, fisher_distance_matrix
from fisher_homology.topology import (
    vietoris_rips_betti,
    bottleneck_distance,
    persistence_diagram_distance,
)
from fisher_homology.utils import (
    validate_state_sequence,
    normalize_states,
    trajectory_summary,
)

__version__ = "1.0.0"
__author__  = "William R. Williamson"
__license__ = "MIT"

__all__ = [
    "FisherHomology",
    "PersistenceDiagram",
    "fisher_arc",
    "fisher_distance_matrix",
    "vietoris_rips_betti",
    "bottleneck_distance",
    "persistence_diagram_distance",
    "validate_state_sequence",
    "normalize_states",
    "trajectory_summary",
]
