"""
tests/test_fisher_homology.py
==============================
Comprehensive test suite for fisher-homology.

All tests use analytical ground truth — no test is an algebraic identity
that cannot fail. Each test verifies a mathematically provable property.
"""

import math
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fisher_homology import (
    FisherHomology,
    fisher_arc,
    fisher_distance_matrix,
    bottleneck_distance,
    validate_state_sequence,
    normalize_states,
    trajectory_summary,
)
from fisher_homology.topology import (
    vietoris_rips_betti,
    betti_curve,
    b0_persistence,
    persistence_diagram,
    UnionFind,
)
from fisher_homology.distances import (
    fisher_arc_position,
    fisher_gradient,
    fisher_state_distance,
    tail_expansion_ratio,
    euclidean_distance_matrix,
)


passed = 0
failed = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global passed, failed
    if ok:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name}")
        if detail:
            print(f"         {detail}")


# ── DISTANCE TESTS ──────────────────────────────────────────────────────────
print("\n=== Fisher Distance Tests ===")

# Identity: d_F(p, p) = 0
check("d_F(p, p) = 0 for p=0.3",
      fisher_arc(0.3, 0.3) == 0.0)

# Symmetry: d_F(p, q) = d_F(q, p)
check("Symmetry: d_F(0.3, 0.7) = d_F(0.7, 0.3)",
      math.isclose(fisher_arc(0.3, 0.7), fisher_arc(0.7, 0.3)))

# Manifold diameter: d_F(0, 1) = π
check("Diameter d_F(0, 1) ≈ π  (within 1e-4 due to EPS clipping)",
      math.isclose(fisher_arc(0.0, 1.0), math.pi, abs_tol=1e-4),
      f"got {fisher_arc(0.0, 1.0):.8f}, expected π={math.pi:.8f}")

# Triangle inequality: d_F(a, c) ≤ d_F(a, b) + d_F(b, c)
a, b, c = 0.1, 0.5, 0.9
ti = fisher_arc(a, c) <= fisher_arc(a, b) + fisher_arc(b, c) + 1e-12
check("Triangle inequality d_F(0.1,0.9) ≤ d_F(0.1,0.5) + d_F(0.5,0.9)", ti,
      f"{fisher_arc(a,c):.6f} ≤ {fisher_arc(a,b)+fisher_arc(b,c):.6f}")

# Midpoint: d_F(0, 0.5) = d_F(0.5, 1) (symmetric around 0.5)
check("Midpoint symmetry: d_F(0,0.5) = d_F(0.5,1)",
      math.isclose(fisher_arc(0.0, 0.5), fisher_arc(0.5, 1.0), abs_tol=1e-8))

# Arc position: arc(0.5) = π/2
check("arc(0.5) = π/2",
      math.isclose(fisher_arc_position(0.5), math.pi / 2.0, abs_tol=1e-9))

# Fisher gradient at p=0.25: should be 1/sqrt(0.25*0.75) = 2.309
expected_grad = 1.0 / math.sqrt(0.25 * 0.75)
check("Fisher gradient at p=0.25 = 1/√(p(1-p))",
      math.isclose(fisher_gradient(0.25), expected_grad, rel_tol=1e-9),
      f"got {fisher_gradient(0.25):.6f}, expected {expected_grad:.6f}")

# Tail expansion: Fisher expands distances at tails vs Euclidean
ratio_tail   = tail_expansion_ratio(0.01, delta=0.01)
ratio_middle = tail_expansion_ratio(0.50, delta=0.01)
check("Tail expansion: Fisher ratio > 1 at p=0.01",
      ratio_tail > 1.0,
      f"ratio={ratio_tail:.3f}")
check("Tail expansion: larger at p=0.01 than at p=0.5",
      ratio_tail > ratio_middle,
      f"tail={ratio_tail:.3f}, middle={ratio_middle:.3f}")

# Distance matrix: symmetric, zero diagonal
states3 = [[0.1, 0.2], [0.5, 0.6], [0.9, 0.8]]
D = fisher_distance_matrix(states3)
check("Distance matrix: zero diagonal",
      all(D[i][i] == 0.0 for i in range(3)))
check("Distance matrix: symmetric",
      all(math.isclose(D[i][j], D[j][i]) for i in range(3) for j in range(3)))
check("Distance matrix: D[0][2] > D[0][1] (farther states are farther)",
      D[0][2] > D[0][1])


# ── UNION-FIND TESTS ─────────────────────────────────────────────────────────
print("\n=== Union-Find Tests ===")

uf = UnionFind(5)
check("Initial: 5 components",
      uf.n_sets() == 5)

uf.union(0, 1)
check("After union(0,1): 4 components",
      uf.n_sets() == 4)

uf.union(0, 1)   # no-op
check("Re-union same set: still 4 components",
      uf.n_sets() == 4)

uf.union(2, 3); uf.union(0, 2)
check("After 2 more unions: 2 components",
      uf.n_sets() == 2)

check("find(1) == find(3) after chaining",
      uf.find(1) == uf.find(3))

check("find(4) != find(0) (isolated component)",
      uf.find(4) != uf.find(0))


# ── β₀ PERSISTENCE TESTS ─────────────────────────────────────────────────────
print("\n=== β₀ Persistence Tests ===")

# Three well-separated clusters
clust_states = (
    [[0.05, 0.05], [0.06, 0.07], [0.05, 0.06]] +   # cluster A
    [[0.50, 0.50], [0.51, 0.49], [0.50, 0.52]] +   # cluster B
    [[0.95, 0.95], [0.94, 0.96], [0.95, 0.94]]     # cluster C
)
D_clust = fisher_distance_matrix(clust_states)
max_d   = max(D_clust[i][j] for i in range(9) for j in range(i+1,9))
pairs   = b0_persistence(D_clust, max_d * 1.1)

check("Three clusters: ≥ 2 long-lived β₀ pairs (one per inter-cluster gap)",
      len([p for p in pairs if p[1]-p[0] > 0.3*max_d]) >= 2,
      f"pairs={[(round(b,3),round(d,3)) for b,d in pairs[:4]]}")

check("β₀ pairs: all births = 0",
      all(b == 0.0 for b, d in pairs))

check("β₀ pairs: all deaths > births",
      all(d > b for b, d in pairs))

check("β₀ pairs sorted by lifetime descending",
      all(pairs[i][1]-pairs[i][0] >= pairs[i+1][1]-pairs[i+1][0]
          for i in range(len(pairs)-1)))


# ── BETTI NUMBER TESTS ────────────────────────────────────────────────────────
print("\n=== Betti Number Tests ===")

# 3-point path: 0--1--2 (no triangle)
D_path = [[0, 1, 3], [1, 0, 2], [3, 2, 0]]
from fisher_homology.topology import compute_betti_numbers
b0_0, b1_0 = compute_betti_numbers(D_path, 0.0)
b0_1, b1_1 = compute_betti_numbers(D_path, 1.5)
b0_all, b1_all = compute_betti_numbers(D_path, 4.0)

check("Path graph at ε=0: β₀=3, β₁=0",
      b0_0 == 3 and b1_0 == 0,
      f"got ({b0_0},{b1_0})")

check("Path graph at ε=1.5 (edge 0-1): β₀=2, β₁=0",
      b0_1 == 2 and b1_1 == 0,
      f"got ({b0_1},{b1_1})")

check("Complete graph at ε=4 (all connected): β₀=1, β₁=0 (triangle fills loop)",
      b0_all == 1 and b1_all == 0,
      f"got ({b0_all},{b1_all})")


# ── PERSISTENCE DIAGRAM TESTS ─────────────────────────────────────────────────
print("\n=== Persistence Diagram Tests ===")

ph  = FisherHomology(n_steps=30)
diag = ph.fit(clust_states)

check("FisherHomology.fit() returns PersistenceDiagram",
      hasattr(diag, "persistence_b0"))

check("Three clusters: n_phases() = 3",
      diag.n_phases() == 3,
      f"got {diag.n_phases()}")

check("Bottleneck width > 0.3 * max_epsilon (strong phase signal)",
      diag.bottleneck_width > 0.3 * diag.max_epsilon,
      f"bottleneck={diag.bottleneck_width:.4f}, max_eps={diag.max_epsilon:.4f}")

check("Phase gaps detected: ≥ 2",
      len(diag.phase_gaps) >= 2,
      f"phase_gaps={diag.phase_gaps}")


# ── BOTTLENECK DISTANCE TESTS ──────────────────────────────────────────────────
print("\n=== Bottleneck Distance Tests ===")

check("Bottleneck distance: identical diagrams = 0",
      bottleneck_distance(diag.persistence_b0, diag.persistence_b0) == 0.0)

check("Bottleneck distance: empty diagrams = 0",
      bottleneck_distance([], []) == 0.0)

# Single-cluster trajectory
single_states = [[0.5 + 0.01*i, 0.5 + 0.01*i] for i in range(9)]
diag_single = ph.fit(single_states)

bn = bottleneck_distance(diag.persistence_b0, diag_single.persistence_b0)
check("Bottleneck(three-cluster, single-cluster) > 0",
      bn > 0.0,
      f"got {bn:.4f}")

check("Three clusters have higher bottleneck than single cluster",
      diag.bottleneck_width > diag_single.bottleneck_width,
      f"three={diag.bottleneck_width:.4f}, one={diag_single.bottleneck_width:.4f}")


# ── COMPARE TRAJECTORIES TEST ─────────────────────────────────────────────────
print("\n=== compare_trajectories Tests ===")

# Two very similar trajectories
traj_a = [[0.1 + 0.001*i, 0.9 - 0.001*i] for i in range(10)]
traj_b = [[0.1 + 0.002*i, 0.9 - 0.002*i] for i in range(10)]
result = ph.compare_trajectories(traj_a, traj_b)
check("Similar trajectories: bottleneck < 0.5",
      result["bottleneck_b0"] < 0.5,
      f"got {result['bottleneck_b0']:.4f}")

# Very different trajectories
result2 = ph.compare_trajectories(clust_states, single_states)
check("Different trajectories: bottleneck > 0",
      result2["bottleneck_b0"] > 0.0)


# ── VALIDATION AND UTILS TESTS ────────────────────────────────────────────────
print("\n=== Validation and Utils Tests ===")

# validate_state_sequence clips values
raw = [[0.0, 1.0], [0.5, 0.5], [-0.1, 1.5]]
valid = validate_state_sequence(raw)
check("Validation clips values to (eps, 1-eps)",
      all(1e-10 <= p <= 1-1e-10 for s in valid for p in s))

# validate_state_sequence rejects inconsistent lengths
try:
    validate_state_sequence([[0.5, 0.5], [0.3]])
    check("Validation rejects inconsistent lengths", False)
except ValueError:
    check("Validation rejects inconsistent lengths", True)

# validate_state_sequence rejects empty
try:
    validate_state_sequence([])
    check("Validation rejects empty sequence", False)
except ValueError:
    check("Validation rejects empty sequence", True)

# trajectory_summary
states_sum = [[0.1, 0.9], [0.5, 0.5], [0.9, 0.1]]
summary = trajectory_summary(states_sum)
check("trajectory_summary returns n_states=3",
      summary["n_states"] == 3)
check("trajectory_summary: trajectory_length > 0",
      summary["trajectory_length"] > 0.0)
check("trajectory_summary: mean_probs have correct length",
      len(summary["mean_probs"]) == 2)


# ── RIPS AT EPSILON TEST ──────────────────────────────────────────────────────
print("\n=== Vietoris-Rips at ε Tests ===")

rips_0  = ph.rips_at_epsilon(clust_states, 0.0)
rips_max = ph.rips_at_epsilon(clust_states, 100.0)

check("At ε=0: β₀ = n_states, β₁ = 0",
      rips_0["beta_0"] == 9 and rips_0["beta_1"] == 0,
      f"got β₀={rips_0['beta_0']}, β₁={rips_0['beta_1']}")

check("At ε=∞: β₀ = 1 (one component)",
      rips_max["beta_0"] == 1,
      f"got β₀={rips_max['beta_0']}")

check("Euler characteristic = V - E + F",
      rips_max["euler_characteristic"] == (
          rips_max["n_vertices"] - rips_max["n_edges"] + rips_max["n_triangles"]
      ))


# ── FINAL SUMMARY ─────────────────────────────────────────────────────────────
print(f"\n{'─'*60}")
print(f"  {passed} passed, {failed} failed out of {passed+failed} tests")
if failed == 0:
    print("  ALL TESTS PASSED ✓")
else:
    print("  FAILURES DETECTED ✗")
    sys.exit(1)
