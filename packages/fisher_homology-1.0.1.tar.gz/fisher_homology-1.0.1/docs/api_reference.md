# API Reference

## `fisher_homology.core`

### `FisherHomology`

Main analysis class.

```python
FisherHomology(n_steps=50, max_epsilon=None)
```

**Parameters**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `n_steps` | `int` | `50` | Number of filtration steps |
| `max_epsilon` | `float \| None` | `None` | Max filtration value. If None, auto-set to 1.05 × max pairwise distance |

**Methods**

---

#### `fit(states, metric='fisher') → PersistenceDiagram`

Compute persistent homology of a probability trajectory.

**Parameters**

| Parameter | Type | Description |
|---|---|---|
| `states` | `list[list[float]]` | T probability vectors of length n. All values in `(0, 1)` |
| `metric` | `str` | `'fisher'` (default) or `'euclidean'` |

**Returns** `PersistenceDiagram`

**Raises**
- `ValueError`: if fewer than 3 states, or states have inconsistent lengths
- `TypeError`: if states contain non-numeric values

---

#### `fit_transform(states, return_both_metrics=False) → dict`

Compute Fisher diagram and optionally Euclidean diagram.

**Returns** `{'fisher': PersistenceDiagram, 'euclidean': PersistenceDiagram}`

---

#### `compare_trajectories(states_a, states_b) → dict`

Compare two trajectories using bottleneck distance.

**Returns**

```python
{
    'bottleneck_b0':   float,             # W∞ distance between β₀ diagrams
    'diagram_a':       PersistenceDiagram,
    'diagram_b':       PersistenceDiagram,
    'interpretation':  str,               # human-readable verdict
}
```

**Interpretation scale**

| Bottleneck | Meaning |
|---|---|
| `< 0.05` | Topologically identical |
| `0.05–0.20` | Similar topology |
| `0.20–0.50` | Moderate difference |
| `> 0.50` | Topologically distinct |

---

#### `rips_at_epsilon(states, epsilon) → dict`

Vietoris-Rips complex snapshot at a single ε.

**Returns**

```python
{
    'beta_0':               int,
    'beta_1':               int,
    'n_vertices':           int,
    'n_edges':              int,
    'n_triangles':          int,
    'euler_characteristic': int,  # = n_vertices - n_edges + n_triangles
    'epsilon':              float,
}
```

---

#### `fisher_arc_positions(states) → list[list[float]]`

Map all probabilities to Fisher arc positions in `(0, π)`.

---

#### `phase_transition_at(diagram) → list[float]`

Return ε values of significant phase transitions from a persistence diagram.

---

### `PersistenceDiagram`

Result container. Not constructed directly — returned by `FisherHomology.fit()`.

**Attributes**

| Attribute | Type | Description |
|---|---|---|
| `persistence_b0` | `list[(float, float)]` | β₀ (birth, death) pairs, sorted by lifetime descending |
| `persistence_b1` | `list[dict]` | β₁ events: `{'type': 'birth'/'death', 'epsilon': float, 'count': int}` |
| `betti_curve` | `dict[float → (int, int)]` | `{epsilon: (β₀, β₁)}` at each filtration step |
| `bottleneck_width` | `float` | Max β₀ feature lifetime |
| `phase_gaps` | `list[float]` | ε values of significant β₀ merges |
| `distance_matrix` | `list[list[float]]` | T×T pairwise Fisher distances |
| `max_epsilon` | `float` | Filtration range used |
| `n_states` | `int` | Number of input states |
| `metric` | `str` | `'fisher'` or `'euclidean'` |

**Methods**

| Method | Returns | Description |
|---|---|---|
| `n_phases()` | `int` | Estimated number of distinct phases |
| `has_cycles()` | `bool` | True if trajectory contains loops |
| `summary()` | `str` | Human-readable summary |

---

## `fisher_homology.distances`

### `fisher_arc(p, q) → float`

Fisher information arc length between two scalar probabilities.

```
d_F(p, q) = 2 · |arcsin(√p) − arcsin(√q)|
```

Range: `[0, π]`. Both arguments are clipped to `(1e-10, 1-1e-10)` internally.

---

### `fisher_arc_position(p) → float`

Maps `p ∈ (0,1)` to arc position `2·arcsin(√p) ∈ (0, π)`.

| p | arc position |
|---|---|
| 0+ | 0+ |
| 0.5 | π/2 ≈ 1.571 |
| 1− | π− |

---

### `fisher_gradient(p) → float`

Gradient of arc position: `d(arc)/dp = 1/√(p(1-p))`.

Equals the square root of the Fisher information `I(p) = 1/(p(1-p))`.
Diverges at `p = 0` and `p = 1` — the tails are infinitely informative.

---

### `fisher_state_distance(state_a, state_b) → float`

Euclidean norm of per-component Fisher arc distances between two probability
state vectors of equal length.

```
d_F(a, b) = √(Σᵢ [2(arcsin(√aᵢ) − arcsin(√bᵢ))]²)
```

---

### `fisher_distance_matrix(states) → list[list[float]]`

Full T×T symmetric pairwise Fisher distance matrix.

Time complexity: O(T² · n) where T = number of states, n = state dimension.

---

### `euclidean_distance_matrix(states) → list[list[float]]`

Euclidean distance matrix. Provided for comparison with Fisher distances.

---

### `tail_expansion_ratio(p, delta=0.01) → float`

How much Fisher distance expands relative to Euclidean at probability `p`.

```
ratio = d_F(p, p+delta) / delta
```

At `p = 0.5`: ratio ≈ 2.0. At `p = 0.01`: ratio ≈ 10.0.

---

## `fisher_homology.topology`

### `UnionFind`

Disjoint set union with path compression and union by rank.

```python
uf = UnionFind(n)       # n elements, each in its own set
uf.find(x)              # root of element x (path compressed)
uf.union(x, y) → bool  # True if merge happened, False if already same set
uf.n_sets()             # current number of components
```

Time complexity: O(α(n)) per operation (inverse Ackermann, nearly constant).

---

### `b0_persistence(distance_matrix, max_epsilon) → list[(float, float)]`

Exact β₀ persistence pairs via Union-Find.

**Algorithm**: Sort all edges by distance. Process in order. When two
components merge, the component with higher-index root records its death.
One component always survives (the final connected graph) — it is excluded.

**Returns**: `list[(birth, death)]` sorted by lifetime descending.
All births are 0.0 (every point starts as its own component at ε=0).

---

### `compute_betti_numbers(distance_matrix, epsilon) → (int, int)`

Compute `(β₀, β₁)` at one filtration value via Euler characteristic.

```
β₁ = E − V + β₀ − F
```

where V, E, F are vertex, edge, and triangle counts in VR_ε.

**Note**: Assumes β₂ ≈ 0 (no enclosed voids), valid for trajectory data in
typical probability manifold applications.

---

### `betti_curve(distance_matrix, n_steps, max_epsilon) → dict`

Betti numbers at each filtration step.

**Returns**: `{epsilon: (β₀, β₁)}` for each step.

---

### `persistence_diagram(distance_matrix, n_steps, max_epsilon) → dict`

Full persistence diagram.

**Returns**:

```python
{
    'persistence_b0':   list[(float, float)],  # β₀ pairs
    'persistence_b1':   list[dict],             # β₁ events
    'betti_curve':      dict,                   # {ε: (β₀, β₁)}
    'bottleneck_width': float,
    'phase_gaps':       list[float],
    'max_epsilon':      float,
    'n_points':         int,
}
```

---

### `bottleneck_distance(diagram_a, diagram_b) → float`

W∞ bottleneck distance between two persistence diagrams.

```
W∞(A, B) = inf_γ sup_{p ∈ A ∪ Δ} ||p − γ(p)||∞
```

Unmatched points are matched to their diagonal projection.
Uses greedy O(n²) matching — exact for typical trajectory sizes (n < 100).

---

### `persistence_diagram_distance(d_a, d_b) → float`

Bottleneck distance between two full diagram dicts (from `persistence_diagram()`).

---

### `vietoris_rips_betti(distance_matrix, epsilon) → dict`

Vietoris-Rips complex summary at a single ε.

---

## `fisher_homology.utils`

### `validate_state_sequence(states) → list[list[float]]`

Validate and clip a probability state sequence to `(1e-10, 1-1e-10)`.

**Raises**:
- `ValueError`: empty sequence, inconsistent lengths
- `TypeError`: non-numeric values

---

### `normalize_states(states, method='clip') → list[list[float]]`

Normalize probability state vectors.

| Method | Description |
|---|---|
| `'clip'` | Clip to `(1e-10, 1-1e-10)` (default) |
| `'scale'` | Divide by max, then clip |

---

### `trajectory_summary(states) → dict`

Descriptive statistics for a probability trajectory.

**Returns**:

```python
{
    'n_states':           int,
    'n_dims':             int,
    'mean_probs':         list[float],   # per dimension
    'std_probs':          list[float],
    'min_probs':          list[float],
    'max_probs':          list[float],
    'mean_arc_positions': list[float],   # Fisher arc positions
    'trajectory_length':  float,         # sum of step distances
}
```
