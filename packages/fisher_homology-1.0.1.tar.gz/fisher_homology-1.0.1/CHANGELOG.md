# Changelog

All notable changes to `fisher-homology` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
This project uses [Semantic Versioning](https://semver.org/).

---

## [1.0.0] — 2026-04-09

### Added

#### Core library
- `FisherHomology` — main analysis class with `fit()`, `fit_transform()`,
  `compare_trajectories()`, and `rips_at_epsilon()` methods
- `PersistenceDiagram` — result container with `n_phases()`, `has_cycles()`,
  and `summary()` methods

#### Distances (`fisher_homology.distances`)
- `fisher_arc(p, q)` — Fisher information arc length between two scalar
  probabilities. Range [0, π]. Satisfies triangle inequality (proven).
- `fisher_arc_position(p)` — maps p ∈ (0,1) to arc position in (0, π)
- `fisher_gradient(p)` — d(arc)/dp = 1/√(p(1−p)) (Fisher information metric)
- `fisher_state_distance(a, b)` — Euclidean norm of per-component arc distances
- `fisher_distance_matrix(states)` — full T×T pairwise distance matrix
- `euclidean_distance_matrix(states)` — Euclidean distance matrix for comparison
- `tail_expansion_ratio(p, delta)` — how much Fisher expands vs Euclidean at p

#### Topology (`fisher_homology.topology`)
- `UnionFind` — path-compressed, rank-unioned disjoint set structure for
  exact β₀ persistence computation
- `b0_persistence(D, max_epsilon)` — exact β₀ (connected component) persistence
  pairs via Union-Find. O(n² log n) time.
- `compute_betti_numbers(D, epsilon)` — (β₀, β₁) at one filtration value
  via Euler characteristic χ = V − E + F
- `betti_curve(D, n_steps, max_epsilon)` — Betti numbers at each filtration step
- `persistence_diagram(D, n_steps, max_epsilon)` — full persistence diagram
  including β₀ pairs, β₁ events, phase gaps, bottleneck width
- `bottleneck_distance(diagram_a, diagram_b)` — W∞ bottleneck metric between
  two persistence diagrams
- `persistence_diagram_distance(d_a, d_b)` — bottleneck on full diagram dicts
- `vietoris_rips_betti(D, epsilon)` — Vietoris-Rips complex summary at one ε

#### Utils (`fisher_homology.utils`)
- `validate_state_sequence(states)` — validates and clips probability vectors
- `normalize_states(states, method)` — 'clip' or 'scale' normalization
- `trajectory_summary(states)` — descriptive statistics for a trajectory

#### Package
- Zero mandatory dependencies (pure Python stdlib)
- Optional: `numpy` for array operations, `matplotlib` for plotting
- Full test suite: 44 non-tautological tests against analytical ground truth
- MIT License

### Mathematical foundations
- Fisher information arc length: d_F(p,q) = 2|arcsin(√p) − arcsin(√q)|
- Vietoris-Rips filtration with Fisher metric
- β₀ persistence via Union-Find (exact)
- β₁ via Euler characteristic: χ = V − E + F = β₀ − β₁
- Bottleneck distance: W∞(A,B) = inf_γ sup_p ||p − γ(p)||∞

### References
- Edelsbrunner & Harer (2010). Computational Topology. AMS.
- Rao (1945). Fisher information metric. Bull. Calcutta Math. Soc.
- Fisher (1915). Frequency distribution of correlation coefficients. Biometrika.
- Cohen-Steiner et al. (2007). Stability of persistence diagrams. DCG.

---

## Planned for [1.1.0]

- Running bottleneck distance (sliding window topological change-point detector)
- Gradient of bottleneck width w.r.t. input probabilities (topological sensitivity)
- Adaptive copula family selection from Kalman-tracked Kendall tau estimates
- Visualization helpers: `plot_persistence_diagram()`, `plot_betti_curve()`
- NumPy-accelerated distance matrix computation
