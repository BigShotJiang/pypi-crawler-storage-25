# -*- coding: utf-8 -*-
"""
Created on Sat Apr 11 17:32:43 2026

@author: wwill
"""

from setuptools import setup, find_packages
from pathlib import Path

setup(
    name="fisher-homology",
    version="1.0.1",
    author="William R. Williamson",
    description="Persistent homology on Fisher information distances for probability manifolds",
    long_description=Path("README.md").read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    packages=find_packages(),  # add where="src", package_dir={"": "src"} if needed
    python_requires=">=3.8",
    extras_require={
        "numpy": ["numpy>=1.20"],
        "plot": ["matplotlib>=3.4"],
        "dev": ["pytest>=7.0", "numpy>=1.20"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Intended Audience :: Science/Research",
    ],
    keywords=[
        "persistent homology", "topological data analysis", "TDA",
        "Fisher information", "probability manifold", "Betti numbers",
        "Vietoris-Rips", "persistence diagram",
    ],
)
