"""
fisher_homology/core.py
========================
FisherHomology: Main Analysis Class
PersistenceDiagram: Result Container
"""

from __future__ import annotations
import math
from typing import Dict, List, Optional, Tuple

from fisher_homology.distances import (
    fisher_distance_matrix,
    euclidean_distance_matrix,
    fisher_arc_position,
)
from fisher_homology.topology import (
    persistence_diagram,
    betti_curve,
    bottleneck_distance,
    vietoris_rips_betti,
)
from fisher_homology.utils import validate_state_sequence, normalize_states


class PersistenceDiagram:
    """
    Result container for a persistent homology computation.

    Attributes
    ----------
    persistence_b0      : list of (birth, death) for β₀ (component) features
    persistence_b1      : list of event dicts for β₁ (loop) features
    betti_curve         : {epsilon: (b0, b1)} at each filtration scale
    bottleneck_width    : max β₀ feature lifetime (primary signal strength)
    phase_gaps          : epsilon values of significant β₀ merge events
    distance_matrix     : T×T Fisher distance matrix used
    max_epsilon         : filtration range
    n_states            : number of input states
    metric              : 'fisher' or 'euclidean'
    """

    def __init__(self, raw: Dict, metric: str = "fisher"):
        self.persistence_b0   : List[Tuple[float, float]] = raw["persistence_b0"]
        self.persistence_b1   : List[Dict]                = raw["persistence_b1"]
        self.betti_curve      : Dict[float, Tuple[int,int]] = raw["betti_curve"]
        self.bottleneck_width : float                     = raw["bottleneck_width"]
        self.phase_gaps       : List[float]               = raw["phase_gaps"]
        self.distance_matrix  : List[List[float]]         = raw.get("distance_matrix", [])
        self.max_epsilon      : float                     = raw["max_epsilon"]
        self.n_states         : int                       = raw["n_points"]
        self.metric           : str                       = metric

    def n_phases(self) -> int:
        """
        Estimated number of distinct phases in the trajectory.

        Counts the number of significant β₀ features (long-lived connected
        components), which correspond to distinct probability regimes visited
        by the trajectory.
        """
        threshold = 0.10 * self.max_epsilon
        return 1 + sum(
            1 for b, d in self.persistence_b0
            if (d - b) > threshold
        )

    def has_cycles(self) -> bool:
        """
        Returns True if the trajectory contains at least one persistent loop.

        A loop (β₁ feature) indicates the system visited a region of probability
        space, departed, and returned — suggesting cyclic dynamics or oscillation
        between two states.
        """
        births = [e for e in self.persistence_b1 if e["type"] == "birth"]
        return len(births) > 0

    def summary(self) -> str:
        """Human-readable summary of the persistence diagram."""
        lines = [
            f"Persistence Diagram ({self.metric} metric)",
            f"  States:            {self.n_states}",
            f"  Max epsilon:       {self.max_epsilon:.4f}",
            f"  β₀ features:       {len(self.persistence_b0)}",
            f"  Bottleneck width:  {self.bottleneck_width:.4f}",
            f"  Phase gaps at ε:   {[f'{g:.3f}' for g in self.phase_gaps]}",
            f"  Estimated phases:  {self.n_phases()}",
            f"  Has cycles (β₁):   {self.has_cycles()}",
        ]
        if self.persistence_b0:
            lines.append(f"  Top 3 β₀ lifetimes: " + ", ".join(
                f"({b:.3f},{d:.3f})={d-b:.3f}"
                for b, d in self.persistence_b0[:3]
            ))
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (f"PersistenceDiagram(n_states={self.n_states}, "
                f"n_phases={self.n_phases()}, "
                f"bottleneck={self.bottleneck_width:.4f})")


class FisherHomology:
    """
    Persistent homology analysis for probability manifold trajectories.

    Uses the Fisher information arc length as the filtration metric:

        d_F(p, q) = 2 |arcsin(√p) − arcsin(√q)|

    This correctly expands distances at the probability tails (p near 0 or 1),
    where critical events in fraud detection, medical diagnostics, physics
    experiments, and financial risk live.

    Parameters
    ----------
    n_steps      : number of filtration steps (default 50)
    max_epsilon  : override for maximum filtration value (default: auto)

    Examples
    --------
    >>> import numpy as np
    >>> from fisher_homology import FisherHomology
    >>>
    >>> # Three-phase trajectory: normal → stress → crisis
    >>> np.random.seed(42)
    >>> states = []
    >>> for t in range(15):
    ...     if t < 5:    p = [0.10, 0.12]
    ...     elif t < 10: p = [0.45, 0.50]
    ...     else:        p = [0.85, 0.88]
    ...     states.append([float(x + 0.01*np.random.randn()) for x in p])
    >>>
    >>> ph = FisherHomology()
    >>> result = ph.fit(states)
    >>> result.n_phases()
    3
    >>> result.bottleneck_width > 0.5
    True
    """

    def __init__(self,
                 n_steps: int = 50,
                 max_epsilon: Optional[float] = None):
        self.n_steps     = n_steps
        self.max_epsilon = max_epsilon

    def fit(self, states: List[List[float]],
            metric: str = "fisher") -> PersistenceDiagram:
        """
        Compute persistent homology of a probability trajectory.

        Parameters
        ----------
        states : list of T probability state vectors, each of length n.
                 All probabilities must be in (0, 1).
        metric : 'fisher' (default) or 'euclidean' (for comparison)

        Returns
        -------
        PersistenceDiagram

        Raises
        ------
        ValueError : if states is empty, has fewer than 3 elements, or
                     contains probabilities outside (0, 1)
        """
        states = validate_state_sequence(states)

        if len(states) < 3:
            raise ValueError(
                f"Need at least 3 states for persistence analysis, "
                f"got {len(states)}."
            )

        # Compute distance matrix
        if metric == "fisher":
            D = fisher_distance_matrix(states)
        elif metric == "euclidean":
            D = euclidean_distance_matrix(states)
        else:
            raise ValueError(f"Unknown metric: {metric}. Use 'fisher' or 'euclidean'.")

        # Compute persistence diagram
        raw = persistence_diagram(D, self.n_steps, self.max_epsilon)
        raw["distance_matrix"] = D

        return PersistenceDiagram(raw, metric=metric)

    def fit_transform(self, states: List[List[float]],
                      return_both_metrics: bool = False
                      ) -> Dict:
        """
        Compute persistence diagrams and compare Fisher vs. Euclidean metrics.

        Parameters
        ----------
        states              : trajectory of probability state vectors
        return_both_metrics : if True, also compute Euclidean diagram

        Returns
        -------
        dict with 'fisher' PersistenceDiagram and optionally 'euclidean'
        """
        result = {"fisher": self.fit(states, metric="fisher")}
        if return_both_metrics:
            result["euclidean"] = self.fit(states, metric="euclidean")
        return result

    def fisher_arc_positions(self, states: List[List[float]]
                             ) -> List[List[float]]:
        """
        Map all probability values to their Fisher arc positions.

        Returns a list of arc position vectors (same shape as states),
        where each value arc(p) = 2 * arcsin(√p) ∈ (0, π).

        Useful for visualizing how states are distributed on the manifold.
        """
        return [
            [fisher_arc_position(p) for p in state]
            for state in states
        ]

    def phase_transition_at(self, diagram: PersistenceDiagram) -> List[float]:
        """
        Return the epsilon values at which phase transitions occur.

        A phase transition is detected as a large gap in the birth times
        of β₀ features — equivalently, the death times of long-lived
        connected components.

        Parameters
        ----------
        diagram : PersistenceDiagram (from self.fit())

        Returns
        -------
        List of epsilon values where significant phase transitions occur,
        sorted in ascending order.
        """
        return sorted(diagram.phase_gaps)

    def compare_trajectories(self,
                              states_a: List[List[float]],
                              states_b: List[List[float]]) -> Dict:
        """
        Compare two trajectories using bottleneck distance.

        Returns the topological distance between the two trajectories'
        persistence diagrams. A small bottleneck distance means the two
        trajectories have similar topological structure (same number and
        shape of phases). A large distance means they differ structurally.

        Parameters
        ----------
        states_a, states_b : two probability trajectory sequences

        Returns
        -------
        dict with:
            bottleneck_b0     : bottleneck distance on β₀ diagrams
            diagram_a         : PersistenceDiagram for states_a
            diagram_b         : PersistenceDiagram for states_b
            interpretation    : human-readable comparison
        """
        diag_a = self.fit(states_a)
        diag_b = self.fit(states_b)

        bn = bottleneck_distance(diag_a.persistence_b0, diag_b.persistence_b0)

        if bn < 0.05:
            interp = "Topologically identical (same phase structure)"
        elif bn < 0.20:
            interp = "Similar topology (minor structural differences)"
        elif bn < 0.50:
            interp = "Moderate topological difference (different phase boundaries)"
        else:
            interp = "Topologically distinct (fundamentally different regime structure)"

        return {
            "bottleneck_b0"  : bn,
            "diagram_a"      : diag_a,
            "diagram_b"      : diag_b,
            "interpretation" : interp,
        }

    def rips_at_epsilon(self, states: List[List[float]],
                        epsilon: float) -> Dict:
        """
        Snapshot of the Vietoris-Rips complex at a specific ε.

        Parameters
        ----------
        states  : trajectory of probability state vectors
        epsilon : filtration value

        Returns
        -------
        dict with beta_0, beta_1, n_edges, n_triangles, euler_characteristic
        """
        states = validate_state_sequence(states)
        D = fisher_distance_matrix(states)
        return vietoris_rips_betti(D, epsilon)
