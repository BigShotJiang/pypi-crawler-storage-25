"""
fisher_homology/utils.py
========================
Validation, normalization, and trajectory summary utilities.
"""

from __future__ import annotations
import math
from typing import Dict, List, Optional


_EPS = 1e-10


def validate_state_sequence(states: List[List[float]]) -> List[List[float]]:
    """
    Validate and clip a probability state sequence.

    Parameters
    ----------
    states : list of probability state vectors

    Returns
    -------
    Validated and clipped state sequence (all values in (_EPS, 1-_EPS))

    Raises
    ------
    ValueError : if states is empty or vectors have inconsistent length
    TypeError  : if states contains non-numeric values
    """
    if not states:
        raise ValueError("State sequence cannot be empty.")

    n = len(states[0])
    if n == 0:
        raise ValueError("State vectors cannot be empty.")

    result = []
    for t, state in enumerate(states):
        if len(state) != n:
            raise ValueError(
                f"State at index {t} has length {len(state)}, "
                f"expected {n} (same as state 0)."
            )
        try:
            clipped = [float(max(_EPS, min(1.0 - _EPS, p))) for p in state]
        except (TypeError, ValueError) as e:
            raise TypeError(
                f"State at index {t} contains non-numeric value: {e}"
            ) from e
        result.append(clipped)

    return result


def normalize_states(states: List[List[float]],
                     method: str = "clip") -> List[List[float]]:
    """
    Normalize probability state vectors to ensure all values are in (0, 1).

    Parameters
    ----------
    states : list of state vectors
    method : 'clip' (default) — clip to (_EPS, 1-_EPS)
             'scale' — divide by max to get [0, 1], then clip

    Returns
    -------
    Normalized state list
    """
    if method == "clip":
        return [
            [max(_EPS, min(1.0 - _EPS, float(p))) for p in state]
            for state in states
        ]
    elif method == "scale":
        flat_max = max(float(p) for state in states for p in state)
        if flat_max == 0:
            raise ValueError("Cannot scale: all values are zero.")
        return [
            [max(_EPS, min(1.0 - _EPS, float(p) / flat_max)) for p in state]
            for state in states
        ]
    else:
        raise ValueError(f"Unknown normalization method: {method}. Use 'clip' or 'scale'.")


def trajectory_summary(states: List[List[float]]) -> Dict:
    """
    Compute descriptive statistics for a probability trajectory.

    Parameters
    ----------
    states : validated probability state sequence

    Returns
    -------
    dict with per-dimension and overall statistics:
        n_states, n_dims, mean_probs, std_probs, min_probs, max_probs,
        mean_arc_positions, trajectory_length (sum of step distances)
    """
    from fisher_homology.distances import fisher_state_distance, fisher_arc_position

    T = len(states)
    n = len(states[0])

    # Per-dimension stats
    mean_p = [sum(s[i] for s in states) / T for i in range(n)]
    var_p  = [
        sum((s[i] - mean_p[i])**2 for s in states) / T
        for i in range(n)
    ]
    std_p  = [math.sqrt(v) for v in var_p]
    min_p  = [min(s[i] for s in states) for i in range(n)]
    max_p  = [max(s[i] for s in states) for i in range(n)]
    arc_p  = [
        sum(fisher_arc_position(s[i]) for s in states) / T
        for i in range(n)
    ]

    # Total trajectory length in Fisher metric
    length = sum(
        fisher_state_distance(states[t], states[t+1])
        for t in range(T - 1)
    )

    return {
        "n_states"          : T,
        "n_dims"            : n,
        "mean_probs"        : mean_p,
        "std_probs"         : std_p,
        "min_probs"         : min_p,
        "max_probs"         : max_p,
        "mean_arc_positions": arc_p,
        "trajectory_length" : length,
    }
