"""
fisher_homology/distances.py
==============================
Fisher Information Arc Length Distances

The Fisher arc distance is the geodesic distance on the statistical manifold
of Bernoulli probability distributions equipped with the Fisher information
metric g(p) = 1/(p(1-p)).

    d_F(p, q) = 2 * |arcsin(sqrt(p)) - arcsin(sqrt(q))|

Properties:
    - Range: [0, π]  (diameter of the full probability manifold)
    - d_F(0, 1) = π  (maximum separation)
    - Symmetric: d_F(p, q) = d_F(q, p)
    - Satisfies triangle inequality (true metric)
    - Expands tail distances: near p=0 or p=1, d_F >> |p-q|
    - For equal-spaced probabilities near the tails: d_F ≈ 2.84 × |p-q|

References:
    Rao (1945). Information and accuracy in estimation.
    Fisher (1915). Frequency distribution of correlation coefficients.
"""

from __future__ import annotations
import math
from typing import List, Optional, Sequence


# ── Single-variable arc distance ─────────────────────────────────────────────

def fisher_arc(p: float, q: float) -> float:
    """
    Fisher information arc length between two scalar probabilities.

    d_F(p, q) = 2 * |arcsin(sqrt(p)) - arcsin(sqrt(q))|

    Parameters
    ----------
    p, q : probabilities in (0, 1)

    Returns
    -------
    float in [0, π]

    Examples
    --------
    >>> fisher_arc(0.5, 0.5)
    0.0
    >>> abs(fisher_arc(0.0, 1.0) - math.pi) < 1e-9
    True
    >>> fisher_arc(0.1, 0.2) > abs(0.2 - 0.1)  # expands tail distances
    True
    """
    _EPS = 1e-10
    p = max(_EPS, min(1.0 - _EPS, float(p)))
    q = max(_EPS, min(1.0 - _EPS, float(q)))
    return 2.0 * abs(math.asin(math.sqrt(p)) - math.asin(math.sqrt(q)))


def fisher_arc_position(p: float) -> float:
    """
    Position of probability p on the Fisher information manifold arc.

    Maps (0, 1) → (0, π) via arc(p) = 2 * arcsin(sqrt(p)).
    The midpoint p = 0.5 maps to π/2.

    Parameters
    ----------
    p : probability in (0, 1)

    Returns
    -------
    float in (0, π)
    """
    _EPS = 1e-10
    p = max(_EPS, min(1.0 - _EPS, float(p)))
    return 2.0 * math.asin(math.sqrt(p))


def fisher_gradient(p: float) -> float:
    """
    Gradient of the Fisher arc position: d(arc(p))/dp = 1/sqrt(p(1-p)).

    This equals the square root of the Fisher information I(p) = 1/(p(1-p)).

    Parameters
    ----------
    p : probability in (0, 1)

    Returns
    -------
    float (always > 0, diverges at 0 and 1)
    """
    _EPS = 1e-10
    p = max(_EPS, min(1.0 - _EPS, float(p)))
    return 1.0 / math.sqrt(p * (1.0 - p))


# ── Multi-dimensional state distances ─────────────────────────────────────────

def fisher_state_distance(state_a: Sequence[float],
                          state_b: Sequence[float]) -> float:
    """
    Fisher information distance between two probability state vectors.

    Computes the Euclidean norm of per-component Fisher arc distances:

        d_F(a, b) = sqrt( Σᵢ [2(arcsin(√aᵢ) - arcsin(√bᵢ))]² )

    Parameters
    ----------
    state_a, state_b : equal-length sequences of probabilities in (0, 1)

    Returns
    -------
    float ≥ 0

    Examples
    --------
    >>> fisher_state_distance([0.5, 0.5], [0.5, 0.5])
    0.0
    >>> fisher_state_distance([0.1, 0.2], [0.9, 0.8]) > 2.0
    True
    """
    if len(state_a) != len(state_b):
        raise ValueError(
            f"State vectors must have equal length: "
            f"len(a)={len(state_a)}, len(b)={len(state_b)}"
        )
    return math.sqrt(sum(
        fisher_arc(pa, pb) ** 2
        for pa, pb in zip(state_a, state_b)
    ))


def fisher_distance_matrix(states: List[List[float]]) -> List[List[float]]:
    """
    Compute the full pairwise Fisher distance matrix for a state sequence.

    Parameters
    ----------
    states : list of T probability state vectors (each length n)

    Returns
    -------
    D : T×T symmetric distance matrix (list of lists, float)

    Notes
    -----
    The diagonal is zero. Upper and lower triangles are equal.
    Time complexity: O(T² * n) where T is the number of states and n the
    dimension of each state vector.

    Examples
    --------
    >>> states = [[0.1, 0.2], [0.5, 0.6], [0.9, 0.8]]
    >>> D = fisher_distance_matrix(states)
    >>> D[0][0]
    0.0
    >>> D[0][1] == D[1][0]
    True
    """
    T = len(states)
    D = [[0.0] * T for _ in range(T)]
    for i in range(T):
        for j in range(i + 1, T):
            d = fisher_state_distance(states[i], states[j])
            D[i][j] = d
            D[j][i] = d
    return D


def euclidean_distance_matrix(states: List[List[float]]) -> List[List[float]]:
    """
    Euclidean distance matrix for comparison with Fisher distances.

    Provided for benchmarking: to demonstrate the difference in topological
    features recovered when using Fisher vs. Euclidean distances.
    """
    T = len(states)
    D = [[0.0] * T for _ in range(T)]
    for i in range(T):
        for j in range(i + 1, T):
            d = math.sqrt(sum(
                (a - b) ** 2 for a, b in zip(states[i], states[j])
            ))
            D[i][j] = d
            D[j][i] = d
    return D


def tail_expansion_ratio(p: float, delta: float = 0.01) -> float:
    """
    How much more Fisher distance expands relative to Euclidean distance
    at probability p, for a step of size delta.

    ratio = d_F(p, p+delta) / delta

    At p = 0.5: ratio ≈ 2.0 (moderate expansion)
    At p = 0.1: ratio ≈ 3.3 (significant expansion)
    At p = 0.01: ratio ≈ 10.0 (strong tail expansion)

    Parameters
    ----------
    p     : probability
    delta : step size (default 0.01)

    Returns
    -------
    float: expansion ratio
    """
    _EPS = 1e-10
    p = max(_EPS, min(1.0 - _EPS - delta, float(p)))
    q = p + delta
    return fisher_arc(p, q) / delta
