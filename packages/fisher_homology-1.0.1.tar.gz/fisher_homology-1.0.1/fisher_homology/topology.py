"""
fisher_homology/topology.py
============================
Topological Computations: Vietoris-Rips, Persistent Homology, Betti Numbers

Implements:
    - Union-Find (path compression + union by rank) for exact β₀ persistence
    - Euler characteristic for β₁ computation
    - Persistence diagram construction
    - Bottleneck distance between persistence diagrams
    - Phase gap detection (large β₀ merges = phase transitions)

Algorithm references:
    Edelsbrunner & Harer (2010). Computational Topology. AMS.
    Cormen et al. (2009). Introduction to Algorithms. MIT Press. (Union-Find)
"""

from __future__ import annotations
import math
from typing import Dict, List, Optional, Tuple


# ── Union-Find (Disjoint Set Union) ──────────────────────────────────────────

class UnionFind:
    """
    Union-Find with path compression and union by rank.

    Used for exact β₀ (connected component) persistence computation.
    Time complexity: O(α(n)) per operation (nearly constant, inverse Ackermann).
    """

    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank   = [0] * n
        self.n_components = n

    def find(self, x: int) -> int:
        """Find root with path compression."""
        root = x
        while self.parent[root] != root:
            root = self.parent[root]
        # Path compression: make every node on path point to root
        while self.parent[x] != root:
            next_x = self.parent[x]
            self.parent[x] = root
            x = next_x
        return root

    def union(self, x: int, y: int) -> bool:
        """
        Union by rank. Returns True if a merge happened (two components joined),
        False if x and y were already in the same component.
        """
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return False
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1
        self.n_components -= 1
        return True

    def n_sets(self) -> int:
        """Current number of connected components."""
        return self.n_components


# ── β₀ Persistence (exact, via Union-Find) ────────────────────────────────────

def b0_persistence(distance_matrix: List[List[float]],
                   max_epsilon: float) -> List[Tuple[float, float]]:
    """
    Compute exact β₀ persistence pairs via Union-Find.

    Each connected component is born at ε = 0 (all points start isolated).
    A component dies when it merges into a larger component at the edge
    connecting them. The component with the smaller-indexed root dies.

    One component always has death = ∞ (the final connected component),
    represented here as max_epsilon.

    Parameters
    ----------
    distance_matrix : T×T symmetric distance matrix
    max_epsilon     : filtration maximum (used as ∞ for the surviving component)

    Returns
    -------
    List of (birth, death) pairs, sorted by lifetime (death-birth) descending.
    The surviving component is NOT included (its death = ∞ is excluded).
    """
    T       = len(distance_matrix)
    births  = [0.0] * T
    deaths  = [max_epsilon] * T

    # Collect and sort all edges
    edges = []
    for i in range(T):
        for j in range(i + 1, T):
            edges.append((distance_matrix[i][j], i, j))
    edges.sort(key=lambda e: e[0])

    uf = UnionFind(T)

    for eps, i, j in edges:
        ri, rj = uf.find(i), uf.find(j)
        if ri == rj:
            continue
        # One component dies: the one whose root index is larger
        dying   = ri if ri > rj else rj
        deaths[dying] = float(eps)
        uf.union(i, j)

    # Return all pairs except the one surviving component (infinite bar)
    pairs = [
        (births[i], deaths[i])
        for i in range(T)
        if deaths[i] < max_epsilon
    ]
    pairs.sort(key=lambda p: p[1] - p[0], reverse=True)
    return pairs


# ── β₁ Computation via Euler Characteristic ───────────────────────────────────

def compute_betti_numbers(distance_matrix: List[List[float]],
                          epsilon: float) -> Tuple[int, int]:
    """
    Compute (β₀, β₁) at a given filtration value ε.

    Uses the Euler characteristic:
        χ = V - E + F = β₀ - β₁
    where V, E, F are the vertex, edge, and triangle counts in the
    Vietoris-Rips complex VR_ε.

    Solving: β₁ = E - V + β₀ - F

    Parameters
    ----------
    distance_matrix : T×T symmetric distance matrix
    epsilon         : current filtration value

    Returns
    -------
    (beta_0, beta_1) : Betti numbers at this epsilon
    """
    T = len(distance_matrix)
    V = T

    # Count edges (1-simplices)
    E = sum(
        1 for i in range(T)
          for j in range(i + 1, T)
          if distance_matrix[i][j] <= epsilon
    )

    # Count triangles (2-simplices)
    F = sum(
        1 for i in range(T)
          for j in range(i + 1, T)
          for k in range(j + 1, T)
          if (distance_matrix[i][j] <= epsilon and
              distance_matrix[i][k] <= epsilon and
              distance_matrix[j][k] <= epsilon)
    )

    # Compute β₀ using Union-Find at this epsilon
    uf = UnionFind(T)
    for i in range(T):
        for j in range(i + 1, T):
            if distance_matrix[i][j] <= epsilon:
                uf.union(i, j)
    b0 = uf.n_sets()

    # Euler characteristic: χ = V - E + F = β₀ - β₁ + β₂
    # For 2D complexes: β₂ ≈ 0 (no enclosed voids in trajectory data)
    # β₁ = E - V + β₀ - F  (from χ = β₀ - β₁ = V - E + F)
    b1 = max(0, E - V + b0 - F)

    return b0, b1


def betti_curve(distance_matrix: List[List[float]],
                n_steps: int = 50,
                max_epsilon: Optional[float] = None) -> Dict[float, Tuple[int, int]]:
    """
    Compute (β₀, β₁) at each step of the filtration.

    Parameters
    ----------
    distance_matrix : T×T symmetric distance matrix
    n_steps         : number of filtration steps
    max_epsilon     : maximum filtration value (default: max pairwise distance)

    Returns
    -------
    Dict mapping epsilon → (beta_0, beta_1)

    Examples
    --------
    >>> D = [[0, 1, 3], [1, 0, 2], [3, 2, 0]]
    >>> curve = betti_curve(D, n_steps=5)
    >>> curve[0.0]  # at epsilon=0, all points isolated
    (3, 0)
    """
    T       = len(distance_matrix)
    flat    = [distance_matrix[i][j]
               for i in range(T) for j in range(i+1, T)]
    if not flat:
        return {0.0: (T, 0)}

    max_d   = max(flat)
    if max_epsilon is None:
        max_epsilon = max_d * 1.05

    epsilons = [max_epsilon * k / n_steps for k in range(n_steps + 1)]
    result   : Dict[float, Tuple[int, int]] = {}

    for eps in epsilons:
        b0, b1 = compute_betti_numbers(distance_matrix, eps)
        result[float(eps)] = (b0, b1)

    return result


# ── Persistence Diagram and Features ─────────────────────────────────────────

def persistence_diagram(distance_matrix: List[List[float]],
                        n_steps: int = 50,
                        max_epsilon: Optional[float] = None
                        ) -> Dict:
    """
    Compute the full persistence diagram for a distance matrix.

    Returns β₀ and β₁ persistence pairs, phase gaps, and the bottleneck width.

    Parameters
    ----------
    distance_matrix : T×T symmetric distance matrix (Fisher or Euclidean)
    n_steps         : filtration resolution
    max_epsilon     : filtration maximum

    Returns
    -------
    dict with:
        persistence_b0  : list of (birth, death) — β₀ features
        persistence_b1  : list of event dicts — β₁ births and deaths
        betti_curve     : {epsilon: (b0, b1)} at each scale
        bottleneck_width: max lifetime among β₀ features (signal strength)
        phase_gaps      : epsilon values of large β₀ merge events
        max_epsilon     : filtration range used
        n_points        : number of input points
    """
    T     = len(distance_matrix)
    flat  = [distance_matrix[i][j]
             for i in range(T) for j in range(i+1, T)]

    if not flat:
        return {
            "persistence_b0"  : [],
            "persistence_b1"  : [],
            "betti_curve"     : {0.0: (T, 0)},
            "bottleneck_width": 0.0,
            "phase_gaps"      : [],
            "max_epsilon"     : 0.0,
            "n_points"        : T,
        }

    max_d = max(flat)
    if max_epsilon is None:
        max_epsilon = max_d * 1.05

    # β₀ persistence (exact)
    b0_pairs = b0_persistence(distance_matrix, max_epsilon)

    # β₁ via Euler characteristic over filtration
    bc = betti_curve(distance_matrix, n_steps, max_epsilon)

    # Track β₁ events (births and deaths)
    eps_sorted = sorted(bc.keys())
    b1_events  = []
    prev_b1    = 0
    for i in range(1, len(eps_sorted)):
        eps_now = eps_sorted[i]
        b1_now  = bc[eps_now][1]
        if b1_now > prev_b1:
            b1_events.append({"type": "birth", "epsilon": eps_now,
                               "count": b1_now - prev_b1})
        elif b1_now < prev_b1:
            b1_events.append({"type": "death", "epsilon": eps_now,
                               "count": prev_b1 - b1_now})
        prev_b1 = b1_now

    # Phase gaps: β₀ merge events with large lifetime
    # A phase gap occurs at the death of a long-lived β₀ feature
    threshold = 0.10 * max_epsilon   # features > 10% of range are significant
    phase_gaps = sorted([
        d for b, d in b0_pairs
        if (d - b) > threshold
    ])

    # Bottleneck width
    lifetimes = [d - b for b, d in b0_pairs]
    bottleneck = max(lifetimes) if lifetimes else 0.0

    return {
        "persistence_b0"  : b0_pairs,
        "persistence_b1"  : b1_events,
        "betti_curve"     : bc,
        "bottleneck_width": bottleneck,
        "phase_gaps"      : phase_gaps,
        "max_epsilon"     : float(max_epsilon),
        "n_points"        : T,
    }


# ── Bottleneck Distance Between Diagrams ──────────────────────────────────────

def bottleneck_distance(diagram_a: List[Tuple[float, float]],
                        diagram_b: List[Tuple[float, float]]) -> float:
    """
    Bottleneck distance between two persistence diagrams.

    The bottleneck distance is the minimum over all matchings of the maximum
    matched-pair distance, where unmatched points are matched to the diagonal
    (their closest point (birth+death)/2, (birth+death)/2).

    W_∞(A, B) = inf_γ sup_{p ∈ A ∪ Δ} ||p - γ(p)||_∞

    This is a standard topological stability measure: if the input data
    changes slightly, the bottleneck distance between the resulting diagrams
    is bounded by the perturbation magnitude (stability theorem, Cohen-Steiner
    et al. 2007).

    Parameters
    ----------
    diagram_a, diagram_b : lists of (birth, death) persistence pairs

    Returns
    -------
    float : bottleneck distance ≥ 0

    Notes
    -----
    This implementation uses a simplified O(n²) matching rather than the
    optimal O(n^{1.5} log n) algorithm. For trajectory analysis with typical
    n < 100 states, this is sufficient.
    """
    def l_inf(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
        return max(abs(p1[0] - p2[0]), abs(p1[1] - p2[1]))

    def diag_dist(p: Tuple[float, float]) -> float:
        # Distance from point to diagonal = (death - birth) / 2
        return (p[1] - p[0]) / 2.0

    if not diagram_a and not diagram_b:
        return 0.0
    if not diagram_a:
        return max(diag_dist(p) for p in diagram_b)
    if not diagram_b:
        return max(diag_dist(p) for p in diagram_a)

    # Augment both diagrams with diagonal projections
    def augment(pts):
        diag_pts = [((p[0]+p[1])/2, (p[0]+p[1])/2) for p in pts]
        return pts + diag_pts

    aug_a = augment(list(diagram_a))
    aug_b = augment(list(diagram_b))

    # Greedy matching: repeatedly match closest unmatched pairs
    # (approximation of true bottleneck, exact for typical trajectory sizes)
    n = max(len(aug_a), len(aug_b))
    # Pad shorter diagram with diagonal points
    while len(aug_a) < n:
        aug_a.append(aug_a[0])
    while len(aug_b) < n:
        aug_b.append(aug_b[0])

    used_b = [False] * len(aug_b)
    max_dist = 0.0

    for pa in aug_a:
        best_d = float('inf')
        best_j = 0
        for j, pb in enumerate(aug_b):
            if not used_b[j]:
                d = l_inf(pa, pb)
                if d < best_d:
                    best_d, best_j = d, j
        used_b[best_j] = True
        max_dist = max(max_dist, best_d)

    return float(max_dist)


def persistence_diagram_distance(diagram_a: Dict,
                                  diagram_b: Dict) -> float:
    """
    Bottleneck distance between two full persistence diagram dicts
    (as returned by persistence_diagram()).
    """
    return bottleneck_distance(
        diagram_a.get("persistence_b0", []),
        diagram_b.get("persistence_b0", []),
    )


# ── Vietoris-Rips summary ─────────────────────────────────────────────────────

def vietoris_rips_betti(distance_matrix: List[List[float]],
                        epsilon: float) -> Dict:
    """
    Summary of the Vietoris-Rips complex at a single ε value.

    Parameters
    ----------
    distance_matrix : T×T symmetric distance matrix
    epsilon         : filtration value

    Returns
    -------
    dict with b0, b1, n_edges, n_triangles, euler_characteristic
    """
    T  = len(distance_matrix)
    b0, b1 = compute_betti_numbers(distance_matrix, epsilon)

    E = sum(1 for i in range(T) for j in range(i+1,T)
            if distance_matrix[i][j] <= epsilon)
    F = sum(1 for i in range(T) for j in range(i+1,T) for k in range(j+1,T)
            if all(distance_matrix[a][b] <= epsilon
                   for a,b in [(i,j),(i,k),(j,k)]))

    return {
        "beta_0"              : b0,
        "beta_1"              : b1,
        "n_vertices"          : T,
        "n_edges"             : E,
        "n_triangles"         : F,
        "euler_characteristic": T - E + F,
        "epsilon"             : epsilon,
    }
