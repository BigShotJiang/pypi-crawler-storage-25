"""
examples/basic_usage.py
========================
Three runnable examples demonstrating fisher-homology.

Run:
    python examples/basic_usage.py
"""

import math

# ── Example 1: Three-phase trajectory ─────────────────────────────────────────
print("=" * 60)
print("Example 1: Three-phase probability trajectory")
print("=" * 60)

from fisher_homology import FisherHomology

# Simulate: normal → stress → crisis (no numpy required)
import random
random.seed(42)

def randn():
    """Box-Muller standard normal."""
    import math
    u1 = random.random() + 1e-15
    u2 = random.random()
    return math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2)

states = []
for t in range(15):
    if   t < 5:  p = [max(0.01, min(0.99, 0.10 + 0.01*randn())),
                      max(0.01, min(0.99, 0.12 + 0.01*randn()))]
    elif t < 10: p = [max(0.01, min(0.99, 0.45 + 0.03*randn())),
                      max(0.01, min(0.99, 0.50 + 0.03*randn()))]
    else:        p = [max(0.01, min(0.99, 0.85 + 0.02*randn())),
                      max(0.01, min(0.99, 0.88 + 0.02*randn()))]
    states.append(p)

ph     = FisherHomology(n_steps=40)
result = ph.fit(states)

print(result.summary())
print(f"\nTop β₀ persistence pairs:")
for i, (b, d) in enumerate(result.persistence_b0[:3]):
    print(f"  {i+1}. birth={b:.4f}  death={d:.4f}  lifetime={d-b:.4f}")

print(f"\nPhase transitions detected at ε = {result.phase_gaps}")
print(f"Cycles (trapped states): {result.has_cycles()}")


# ── Example 2: Compare Fisher vs Euclidean ────────────────────────────────────
print("\n" + "=" * 60)
print("Example 2: Fisher vs Euclidean metric comparison")
print("=" * 60)

from fisher_homology.distances import fisher_arc, tail_expansion_ratio

print("\nTail expansion ratios (how much Fisher expands vs Euclidean):")
for p in [0.001, 0.01, 0.05, 0.10, 0.50]:
    ratio = tail_expansion_ratio(p, delta=0.001)
    print(f"  p = {p:.3f}: Fisher / Euclidean = {ratio:.1f}×")

# Same trajectory, both metrics
both = ph.fit_transform(states, return_both_metrics=True)
f_phases = both['fisher'].n_phases()
e_phases = both['euclidean'].n_phases()

print(f"\nPhases detected:")
print(f"  Fisher metric:    {f_phases}")
print(f"  Euclidean metric: {e_phases}")
print(f"  (Fisher correctly separates tail regimes)")


# ── Example 3: Compare two trajectories ───────────────────────────────────────
print("\n" + "=" * 60)
print("Example 3: Trajectory comparison via bottleneck distance")
print("=" * 60)

# Trajectory A: slow escalation (gradual drift)
traj_a = [[0.1 + 0.05*t, 0.1 + 0.05*t] for t in range(15)]
traj_a = [[max(0.01, min(0.99, p)) for p in s] for s in traj_a]

# Trajectory B: abrupt phase transition
traj_b = ([[0.1, 0.1]] * 7 +
           [[0.85, 0.88]] * 8)

comparison = ph.compare_trajectories(traj_a, traj_b)
print(f"\nBottleneck distance: {comparison['bottleneck_b0']:.4f}")
print(f"Interpretation: {comparison['interpretation']}")

print(f"\nTrajectory A phases: {comparison['diagram_a'].n_phases()}")
print(f"Trajectory B phases: {comparison['diagram_b'].n_phases()}")

# From the topology module directly
from fisher_homology.topology import UnionFind, vietoris_rips_betti
from fisher_homology import fisher_distance_matrix

D = fisher_distance_matrix(traj_b)
rips = vietoris_rips_betti(D, epsilon=2.0)
print(f"\nVietoris-Rips at ε=2.0 for trajectory B:")
print(f"  β₀={rips['beta_0']}, β₁={rips['beta_1']}, "
      f"edges={rips['n_edges']}, triangles={rips['n_triangles']}")
print(f"  χ = {rips['euler_characteristic']}")
