import{d as V,x as t,bt as ir,V as b,U as _,ac as i,ay as sr,aA as cr,ak as G,aR as Re,ag as he,P as ne,aS as ur,a7 as dr,X as F,ar as Y,r as y,E as ve,m as fr,p as $,bu as hr,af as oe,aU as vr,F as pr,aY as gr,Y as br,Z as Be,bv as mr,bw as xr,av as wr,au as yr,aB as ye,o as Cr,a5 as zr,aJ as Ce,aa as Sr,aD as _r,a0 as fe,be as Ar,a1 as Rr,I as ze,az as Se,ap as C,aV as _e}from"./index-CPuF8FlG.js";import{u as Br}from"./Empty-CjZTve5D.js";const Fr=V({name:"ChevronDown",render(){return t("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M3.14645 5.64645C3.34171 5.45118 3.65829 5.45118 3.85355 5.64645L8 9.79289L12.1464 5.64645C12.3417 5.45118 12.6583 5.45118 12.8536 5.64645C13.0488 5.84171 13.0488 6.15829 12.8536 6.35355L8.35355 10.8536C8.15829 11.0488 7.84171 11.0488 7.64645 10.8536L3.14645 6.35355C2.95118 6.15829 2.95118 5.84171 3.14645 5.64645Z",fill:"currentColor"}))}}),Pr=ir("clear",()=>t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M8,2 C11.3137085,2 14,4.6862915 14,8 C14,11.3137085 11.3137085,14 8,14 C4.6862915,14 2,11.3137085 2,8 C2,4.6862915 4.6862915,2 8,2 Z M6.5343055,5.83859116 C6.33943736,5.70359511 6.07001296,5.72288026 5.89644661,5.89644661 L5.89644661,5.89644661 L5.83859116,5.9656945 C5.70359511,6.16056264 5.72288026,6.42998704 5.89644661,6.60355339 L5.89644661,6.60355339 L7.293,8 L5.89644661,9.39644661 L5.83859116,9.4656945 C5.70359511,9.66056264 5.72288026,9.92998704 5.89644661,10.1035534 L5.89644661,10.1035534 L5.9656945,10.1614088 C6.16056264,10.2964049 6.42998704,10.2771197 6.60355339,10.1035534 L6.60355339,10.1035534 L8,8.707 L9.39644661,10.1035534 L9.4656945,10.1614088 C9.66056264,10.2964049 9.92998704,10.2771197 10.1035534,10.1035534 L10.1035534,10.1035534 L10.1614088,10.0343055 C10.2964049,9.83943736 10.2771197,9.57001296 10.1035534,9.39644661 L10.1035534,9.39644661 L8.707,8 L10.1035534,6.60355339 L10.1614088,6.5343055 C10.2964049,6.33943736 10.2771197,6.07001296 10.1035534,5.89644661 L10.1035534,5.89644661 L10.0343055,5.83859116 C9.83943736,5.70359511 9.57001296,5.72288026 9.39644661,5.89644661 L9.39644661,5.89644661 L8,7.293 L6.60355339,5.89644661 Z"}))))),$r=V({name:"Eye",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M255.66 112c-77.94 0-157.89 45.11-220.83 135.33a16 16 0 0 0-.27 17.77C82.92 340.8 161.8 400 255.66 400c92.84 0 173.34-59.38 221.79-135.25a16.14 16.14 0 0 0 0-17.47C428.89 172.28 347.8 112 255.66 112z",fill:"none",stroke:"currentColor","stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"32"}),t("circle",{cx:"256",cy:"256",r:"80",fill:"none",stroke:"currentColor","stroke-miterlimit":"10","stroke-width":"32"}))}}),kr=V({name:"EyeOff",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M432 448a15.92 15.92 0 0 1-11.31-4.69l-352-352a16 16 0 0 1 22.62-22.62l352 352A16 16 0 0 1 432 448z",fill:"currentColor"}),t("path",{d:"M255.66 384c-41.49 0-81.5-12.28-118.92-36.5c-34.07-22-64.74-53.51-88.7-91v-.08c19.94-28.57 41.78-52.73 65.24-72.21a2 2 0 0 0 .14-2.94L93.5 161.38a2 2 0 0 0-2.71-.12c-24.92 21-48.05 46.76-69.08 76.92a31.92 31.92 0 0 0-.64 35.54c26.41 41.33 60.4 76.14 98.28 100.65C162 402 207.9 416 255.66 416a239.13 239.13 0 0 0 75.8-12.58a2 2 0 0 0 .77-3.31l-21.58-21.58a4 4 0 0 0-3.83-1a204.8 204.8 0 0 1-51.16 6.47z",fill:"currentColor"}),t("path",{d:"M490.84 238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349 110.55 302 96 255.66 96a227.34 227.34 0 0 0-74.89 12.83a2 2 0 0 0-.75 3.31l21.55 21.55a4 4 0 0 0 3.88 1a192.82 192.82 0 0 1 50.21-6.69c40.69 0 80.58 12.43 118.55 37c34.71 22.4 65.74 53.88 89.76 91a.13.13 0 0 1 0 .16a310.72 310.72 0 0 1-64.12 72.73a2 2 0 0 0-.15 2.95l19.9 19.89a2 2 0 0 0 2.7.13a343.49 343.49 0 0 0 68.64-78.48a32.2 32.2 0 0 0-.1-34.78z",fill:"currentColor"}),t("path",{d:"M256 160a95.88 95.88 0 0 0-21.37 2.4a2 2 0 0 0-1 3.38l112.59 112.56a2 2 0 0 0 3.38-1A96 96 0 0 0 256 160z",fill:"currentColor"}),t("path",{d:"M165.78 233.66a2 2 0 0 0-3.38 1a96 96 0 0 0 115 115a2 2 0 0 0 1-3.38z",fill:"currentColor"}))}}),Er=b("base-clear",`
 flex-shrink: 0;
 height: 1em;
 width: 1em;
 position: relative;
`,[_(">",[i("clear",`
 font-size: var(--n-clear-size);
 height: 1em;
 width: 1em;
 cursor: pointer;
 color: var(--n-clear-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 `,[_("&:hover",`
 color: var(--n-clear-color-hover)!important;
 `),_("&:active",`
 color: var(--n-clear-color-pressed)!important;
 `)]),i("placeholder",`
 display: flex;
 `),i("clear, placeholder",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[sr({originalTransform:"translateX(-50%) translateY(-50%)",left:"50%",top:"50%"})])])]),pe=V({name:"BaseClear",props:{clsPrefix:{type:String,required:!0},show:Boolean,onClear:Function},setup(r){return Re("-base-clear",Er,he(r,"clsPrefix")),{handleMouseDown(u){u.preventDefault()}}},render(){const{clsPrefix:r}=this;return t("div",{class:`${r}-base-clear`},t(cr,null,{default:()=>{var u,p;return this.show?t("div",{key:"dismiss",class:`${r}-base-clear__clear`,onClick:this.onClear,onMousedown:this.handleMouseDown,"data-clear":!0},G(this.$slots.icon,()=>[t(ne,{clsPrefix:r},{default:()=>t(Pr,null)})])):t("div",{key:"icon",class:`${r}-base-clear__placeholder`},(p=(u=this.$slots).placeholder)===null||p===void 0?void 0:p.call(u))}}))}}),Ir=V({name:"InternalSelectionSuffix",props:{clsPrefix:{type:String,required:!0},showArrow:{type:Boolean,default:void 0},showClear:{type:Boolean,default:void 0},loading:{type:Boolean,default:!1},onClear:Function},setup(r,{slots:u}){return()=>{const{clsPrefix:p}=r;return t(ur,{clsPrefix:p,class:`${p}-base-suffix`,strokeWidth:24,scale:.85,show:r.loading},{default:()=>r.showArrow?t(pe,{clsPrefix:p,show:r.showClear,onClear:r.onClear},{placeholder:()=>t(ne,{clsPrefix:p,class:`${p}-base-suffix__arrow`},{default:()=>G(u.default,()=>[t(Fr,null)])})}):null})}}}),Fe=dr("n-input"),Tr=b("input",`
 max-width: 100%;
 cursor: text;
 line-height: 1.5;
 z-index: auto;
 outline: none;
 box-sizing: border-box;
 position: relative;
 display: inline-flex;
 border-radius: var(--n-border-radius);
 background-color: var(--n-color);
 transition: background-color .3s var(--n-bezier);
 font-size: var(--n-font-size);
 font-weight: var(--n-font-weight);
 --n-padding-vertical: calc((var(--n-height) - 1.5 * var(--n-font-size)) / 2);
`,[i("input, textarea",`
 overflow: hidden;
 flex-grow: 1;
 position: relative;
 `),i("input-el, textarea-el, input-mirror, textarea-mirror, separator, placeholder",`
 box-sizing: border-box;
 font-size: inherit;
 line-height: 1.5;
 font-family: inherit;
 border: none;
 outline: none;
 background-color: #0000;
 text-align: inherit;
 transition:
 -webkit-text-fill-color .3s var(--n-bezier),
 caret-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier);
 `),i("input-el, textarea-el",`
 -webkit-appearance: none;
 scrollbar-width: none;
 width: 100%;
 min-width: 0;
 text-decoration-color: var(--n-text-decoration-color);
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 background-color: transparent;
 `,[_("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",`
 width: 0;
 height: 0;
 display: none;
 `),_("&::placeholder",`
 color: #0000;
 -webkit-text-fill-color: transparent !important;
 `),_("&:-webkit-autofill ~",[i("placeholder","display: none;")])]),F("round",[Y("textarea","border-radius: calc(var(--n-height) / 2);")]),i("placeholder",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 overflow: hidden;
 color: var(--n-placeholder-color);
 `,[_("span",`
 width: 100%;
 display: inline-block;
 `)]),F("textarea",[i("placeholder","overflow: visible;")]),Y("autosize","width: 100%;"),F("autosize",[i("textarea-el, input-el",`
 position: absolute;
 top: 0;
 left: 0;
 height: 100%;
 `)]),b("input-wrapper",`
 overflow: hidden;
 display: inline-flex;
 flex-grow: 1;
 position: relative;
 padding-left: var(--n-padding-left);
 padding-right: var(--n-padding-right);
 `),i("input-mirror",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre;
 pointer-events: none;
 `),i("input-el",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 `,[_("&[type=password]::-ms-reveal","display: none;"),_("+",[i("placeholder",`
 display: flex;
 align-items: center; 
 `)])]),Y("textarea",[i("placeholder","white-space: nowrap;")]),i("eye",`
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `),F("textarea","width: 100%;",[b("input-word-count",`
 position: absolute;
 right: var(--n-padding-right);
 bottom: var(--n-padding-vertical);
 `),F("resizable",[b("input-wrapper",`
 resize: vertical;
 min-height: var(--n-height);
 `)]),i("textarea-el, textarea-mirror, placeholder",`
 height: 100%;
 padding-left: 0;
 padding-right: 0;
 padding-top: var(--n-padding-vertical);
 padding-bottom: var(--n-padding-vertical);
 word-break: break-word;
 display: inline-block;
 vertical-align: bottom;
 box-sizing: border-box;
 line-height: var(--n-line-height-textarea);
 margin: 0;
 resize: none;
 white-space: pre-wrap;
 scroll-padding-block-end: var(--n-padding-vertical);
 `),i("textarea-mirror",`
 width: 100%;
 pointer-events: none;
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre-wrap;
 overflow-wrap: break-word;
 `)]),F("pair",[i("input-el, placeholder","text-align: center;"),i("separator",`
 display: flex;
 align-items: center;
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 white-space: nowrap;
 `,[b("icon",`
 color: var(--n-icon-color);
 `),b("base-icon",`
 color: var(--n-icon-color);
 `)])]),F("disabled",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[i("border","border: var(--n-border-disabled);"),i("input-el, textarea-el",`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 text-decoration-color: var(--n-text-color-disabled);
 `),i("placeholder","color: var(--n-placeholder-color-disabled);"),i("separator","color: var(--n-text-color-disabled);",[b("icon",`
 color: var(--n-icon-color-disabled);
 `),b("base-icon",`
 color: var(--n-icon-color-disabled);
 `)]),b("input-word-count",`
 color: var(--n-count-text-color-disabled);
 `),i("suffix, prefix","color: var(--n-text-color-disabled);",[b("icon",`
 color: var(--n-icon-color-disabled);
 `),b("internal-icon",`
 color: var(--n-icon-color-disabled);
 `)])]),Y("disabled",[i("eye",`
 color: var(--n-icon-color);
 cursor: pointer;
 `,[_("&:hover",`
 color: var(--n-icon-color-hover);
 `),_("&:active",`
 color: var(--n-icon-color-pressed);
 `)]),_("&:hover",[i("state-border","border: var(--n-border-hover);")]),F("focus","background-color: var(--n-color-focus);",[i("state-border",`
 border: var(--n-border-focus);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),i("border, state-border",`
 box-sizing: border-box;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: inherit;
 border: var(--n-border);
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),i("state-border",`
 border-color: #0000;
 z-index: 1;
 `),i("prefix","margin-right: 4px;"),i("suffix",`
 margin-left: 4px;
 `),i("suffix, prefix",`
 transition: color .3s var(--n-bezier);
 flex-wrap: nowrap;
 flex-shrink: 0;
 line-height: var(--n-height);
 white-space: nowrap;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 color: var(--n-suffix-text-color);
 `,[b("base-loading",`
 font-size: var(--n-icon-size);
 margin: 0 2px;
 color: var(--n-loading-color);
 `),b("base-clear",`
 font-size: var(--n-icon-size);
 `,[i("placeholder",[b("base-icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)])]),_(">",[b("icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)]),b("base-icon",`
 font-size: var(--n-icon-size);
 `)]),b("input-word-count",`
 pointer-events: none;
 line-height: 1.5;
 font-size: .85em;
 color: var(--n-count-text-color);
 transition: color .3s var(--n-bezier);
 margin-left: 4px;
 font-variant: tabular-nums;
 `),["warning","error"].map(r=>F(`${r}-status`,[Y("disabled",[b("base-loading",`
 color: var(--n-loading-color-${r})
 `),i("input-el, textarea-el",`
 caret-color: var(--n-caret-color-${r});
 `),i("state-border",`
 border: var(--n-border-${r});
 `),_("&:hover",[i("state-border",`
 border: var(--n-border-hover-${r});
 `)]),_("&:focus",`
 background-color: var(--n-color-focus-${r});
 `,[i("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)]),F("focus",`
 background-color: var(--n-color-focus-${r});
 `,[i("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)])])]))]),Mr=b("input",[F("disabled",[i("input-el, textarea-el",`
 -webkit-text-fill-color: var(--n-text-color-disabled);
 `)])]);function Vr(r){let u=0;for(const p of r)u++;return u}function re(r){return r===""||r==null}function Dr(r){const u=y(null);function p(){const{value:x}=r;if(!(x!=null&&x.focus)){A();return}const{selectionStart:d,selectionEnd:n,value:m}=x;if(d==null||n==null){A();return}u.value={start:d,end:n,beforeText:m.slice(0,d),afterText:m.slice(n)}}function P(){var x;const{value:d}=u,{value:n}=r;if(!d||!n)return;const{value:m}=n,{start:E,beforeText:h,afterText:z}=d;let S=m.length;if(m.endsWith(z))S=m.length-z.length;else if(m.startsWith(h))S=h.length;else{const g=h[E-1],l=m.indexOf(g,E-1);l!==-1&&(S=l+1)}(x=n.setSelectionRange)===null||x===void 0||x.call(n,S,S)}function A(){u.value=null}return ve(r,A),{recordCursor:p,restoreCursor:P}}const Ae=V({name:"InputWordCount",setup(r,{slots:u}){const{mergedValueRef:p,maxlengthRef:P,mergedClsPrefixRef:A,countGraphemesRef:x}=fr(Fe),d=$(()=>{const{value:n}=p;return n===null||Array.isArray(n)?0:(x.value||Vr)(n)});return()=>{const{value:n}=P,{value:m}=p;return t("span",{class:`${A.value}-input-word-count`},hr(u.default,{value:m===null||Array.isArray(m)?"":m},()=>[n===void 0?d.value:`${d.value} / ${n}`]))}}}),Lr=Object.assign(Object.assign({},Be.props),{bordered:{type:Boolean,default:void 0},type:{type:String,default:"text"},placeholder:[Array,String],defaultValue:{type:[String,Array],default:null},value:[String,Array],disabled:{type:Boolean,default:void 0},size:String,rows:{type:[Number,String],default:3},round:Boolean,minlength:[String,Number],maxlength:[String,Number],clearable:Boolean,autosize:{type:[Boolean,Object],default:!1},pair:Boolean,separator:String,readonly:{type:[String,Boolean],default:!1},passivelyActivated:Boolean,showPasswordOn:String,stateful:{type:Boolean,default:!0},autofocus:Boolean,inputProps:Object,resizable:{type:Boolean,default:!0},showCount:Boolean,loading:{type:Boolean,default:void 0},allowInput:Function,renderCount:Function,onMousedown:Function,onKeydown:Function,onKeyup:[Function,Array],onInput:[Function,Array],onFocus:[Function,Array],onBlur:[Function,Array],onClick:[Function,Array],onChange:[Function,Array],onClear:[Function,Array],countGraphemes:Function,status:String,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],textDecoration:[String,Array],attrSize:{type:Number,default:20},onInputBlur:[Function,Array],onInputFocus:[Function,Array],onDeactivate:[Function,Array],onActivate:[Function,Array],onWrapperFocus:[Function,Array],onWrapperBlur:[Function,Array],internalDeactivateOnEnter:Boolean,internalForceFocus:Boolean,internalLoadingBeforeSuffix:{type:Boolean,default:!0},showPasswordToggle:Boolean}),Nr=V({name:"Input",props:Lr,slots:Object,setup(r){const{mergedClsPrefixRef:u,mergedBorderedRef:p,inlineThemeDisabled:P,mergedRtlRef:A}=br(r),x=Be("Input","-input",Tr,mr,r,u);xr&&Re("-input-safari",Mr,u);const d=y(null),n=y(null),m=y(null),E=y(null),h=y(null),z=y(null),S=y(null),g=Dr(S),l=y(null),{localeRef:f}=Br("Input"),w=y(r.defaultValue),R=he(r,"value"),B=wr(R,w),O=yr(r),{mergedSizeRef:te,mergedDisabledRef:D,mergedStatusRef:Pe}=O,L=y(!1),N=y(!1),k=y(!1),H=y(!1);let ae=null;const le=$(()=>{const{placeholder:e,pair:o}=r;return o?Array.isArray(e)?e:e===void 0?["",""]:[e,e]:e===void 0?[f.value.placeholder]:[e]}),$e=$(()=>{const{value:e}=k,{value:o}=B,{value:a}=le;return!e&&(re(o)||Array.isArray(o)&&re(o[0]))&&a[0]}),ke=$(()=>{const{value:e}=k,{value:o}=B,{value:a}=le;return!e&&a[1]&&(re(o)||Array.isArray(o)&&re(o[1]))}),ie=ye(()=>r.internalForceFocus||L.value),Ee=ye(()=>{if(D.value||r.readonly||!r.clearable||!ie.value&&!N.value)return!1;const{value:e}=B,{value:o}=ie;return r.pair?!!(Array.isArray(e)&&(e[0]||e[1]))&&(N.value||o):!!e&&(N.value||o)}),se=$(()=>{const{showPasswordOn:e}=r;if(e)return e;if(r.showPasswordToggle)return"click"}),K=y(!1),Ie=$(()=>{const{textDecoration:e}=r;return e?Array.isArray(e)?e.map(o=>({textDecoration:o})):[{textDecoration:e}]:["",""]}),ge=y(void 0),Te=()=>{var e,o;if(r.type==="textarea"){const{autosize:a}=r;if(a&&(ge.value=(o=(e=l.value)===null||e===void 0?void 0:e.$el)===null||o===void 0?void 0:o.offsetWidth),!n.value||typeof a=="boolean")return;const{paddingTop:c,paddingBottom:v,lineHeight:s}=window.getComputedStyle(n.value),I=Number(c.slice(0,-2)),T=Number(v.slice(0,-2)),M=Number(s.slice(0,-2)),{value:U}=m;if(!U)return;if(a.minRows){const j=Math.max(a.minRows,1),de=`${I+T+M*j}px`;U.style.minHeight=de}if(a.maxRows){const j=`${I+T+M*a.maxRows}px`;U.style.maxHeight=j}}},Me=$(()=>{const{maxlength:e}=r;return e===void 0?void 0:Number(e)});Cr(()=>{const{value:e}=B;Array.isArray(e)||ue(e)});const Ve=zr().proxy;function X(e,o){const{onUpdateValue:a,"onUpdate:value":c,onInput:v}=r,{nTriggerFormInput:s}=O;a&&C(a,e,o),c&&C(c,e,o),v&&C(v,e,o),w.value=e,s()}function Z(e,o){const{onChange:a}=r,{nTriggerFormChange:c}=O;a&&C(a,e,o),w.value=e,c()}function De(e){const{onBlur:o}=r,{nTriggerFormBlur:a}=O;o&&C(o,e),a()}function Le(e){const{onFocus:o}=r,{nTriggerFormFocus:a}=O;o&&C(o,e),a()}function We(e){const{onClear:o}=r;o&&C(o,e)}function Oe(e){const{onInputBlur:o}=r;o&&C(o,e)}function Ne(e){const{onInputFocus:o}=r;o&&C(o,e)}function He(){const{onDeactivate:e}=r;e&&C(e)}function Ke(){const{onActivate:e}=r;e&&C(e)}function Ue(e){const{onClick:o}=r;o&&C(o,e)}function je(e){const{onWrapperFocus:o}=r;o&&C(o,e)}function Ye(e){const{onWrapperBlur:o}=r;o&&C(o,e)}function Ge(){k.value=!0}function Xe(e){k.value=!1,e.target===z.value?q(e,1):q(e,0)}function q(e,o=0,a="input"){const c=e.target.value;if(ue(c),e instanceof InputEvent&&!e.isComposing&&(k.value=!1),r.type==="textarea"){const{value:s}=l;s&&s.syncUnifiedContainer()}if(ae=c,k.value)return;g.recordCursor();const v=Ze(c);if(v)if(!r.pair)a==="input"?X(c,{source:o}):Z(c,{source:o});else{let{value:s}=B;Array.isArray(s)?s=[s[0],s[1]]:s=["",""],s[o]=c,a==="input"?X(s,{source:o}):Z(s,{source:o})}Ve.$forceUpdate(),v||ze(g.restoreCursor)}function Ze(e){const{countGraphemes:o,maxlength:a,minlength:c}=r;if(o){let s;if(a!==void 0&&(s===void 0&&(s=o(e)),s>Number(a))||c!==void 0&&(s===void 0&&(s=o(e)),s<Number(a)))return!1}const{allowInput:v}=r;return typeof v=="function"?v(e):!0}function qe(e){Oe(e),e.relatedTarget===d.value&&He(),e.relatedTarget!==null&&(e.relatedTarget===h.value||e.relatedTarget===z.value||e.relatedTarget===n.value)||(H.value=!1),J(e,"blur"),S.value=null}function Je(e,o){Ne(e),L.value=!0,H.value=!0,Ke(),J(e,"focus"),o===0?S.value=h.value:o===1?S.value=z.value:o===2&&(S.value=n.value)}function Qe(e){r.passivelyActivated&&(Ye(e),J(e,"blur"))}function eo(e){r.passivelyActivated&&(L.value=!0,je(e),J(e,"focus"))}function J(e,o){e.relatedTarget!==null&&(e.relatedTarget===h.value||e.relatedTarget===z.value||e.relatedTarget===n.value||e.relatedTarget===d.value)||(o==="focus"?(Le(e),L.value=!0):o==="blur"&&(De(e),L.value=!1))}function oo(e,o){q(e,o,"change")}function ro(e){Ue(e)}function no(e){We(e),be()}function be(){r.pair?(X(["",""],{source:"clear"}),Z(["",""],{source:"clear"})):(X("",{source:"clear"}),Z("",{source:"clear"}))}function to(e){const{onMousedown:o}=r;o&&o(e);const{tagName:a}=e.target;if(a!=="INPUT"&&a!=="TEXTAREA"){if(r.resizable){const{value:c}=d;if(c){const{left:v,top:s,width:I,height:T}=c.getBoundingClientRect(),M=14;if(v+I-M<e.clientX&&e.clientX<v+I&&s+T-M<e.clientY&&e.clientY<s+T)return}}e.preventDefault(),L.value||me()}}function ao(){var e;N.value=!0,r.type==="textarea"&&((e=l.value)===null||e===void 0||e.handleMouseEnterWrapper())}function lo(){var e;N.value=!1,r.type==="textarea"&&((e=l.value)===null||e===void 0||e.handleMouseLeaveWrapper())}function io(){D.value||se.value==="click"&&(K.value=!K.value)}function so(e){if(D.value)return;e.preventDefault();const o=c=>{c.preventDefault(),_e("mouseup",document,o)};if(Se("mouseup",document,o),se.value!=="mousedown")return;K.value=!0;const a=()=>{K.value=!1,_e("mouseup",document,a)};Se("mouseup",document,a)}function co(e){r.onKeyup&&C(r.onKeyup,e)}function uo(e){switch(r.onKeydown&&C(r.onKeydown,e),e.key){case"Escape":ce();break;case"Enter":fo(e);break}}function fo(e){var o,a;if(r.passivelyActivated){const{value:c}=H;if(c){r.internalDeactivateOnEnter&&ce();return}e.preventDefault(),r.type==="textarea"?(o=n.value)===null||o===void 0||o.focus():(a=h.value)===null||a===void 0||a.focus()}}function ce(){r.passivelyActivated&&(H.value=!1,ze(()=>{var e;(e=d.value)===null||e===void 0||e.focus()}))}function me(){var e,o,a;D.value||(r.passivelyActivated?(e=d.value)===null||e===void 0||e.focus():((o=n.value)===null||o===void 0||o.focus(),(a=h.value)===null||a===void 0||a.focus()))}function ho(){var e;!((e=d.value)===null||e===void 0)&&e.contains(document.activeElement)&&document.activeElement.blur()}function vo(){var e,o;(e=n.value)===null||e===void 0||e.select(),(o=h.value)===null||o===void 0||o.select()}function po(){D.value||(n.value?n.value.focus():h.value&&h.value.focus())}function go(){const{value:e}=d;e!=null&&e.contains(document.activeElement)&&e!==document.activeElement&&ce()}function bo(e){if(r.type==="textarea"){const{value:o}=n;o==null||o.scrollTo(e)}else{const{value:o}=h;o==null||o.scrollTo(e)}}function ue(e){const{type:o,pair:a,autosize:c}=r;if(!a&&c)if(o==="textarea"){const{value:v}=m;v&&(v.textContent=`${e??""}\r
`)}else{const{value:v}=E;v&&(e?v.textContent=e:v.innerHTML="&nbsp;")}}function mo(){Te()}const xe=y({top:"0"});function xo(e){var o;const{scrollTop:a}=e.target;xe.value.top=`${-a}px`,(o=l.value)===null||o===void 0||o.syncUnifiedContainer()}let Q=null;Ce(()=>{const{autosize:e,type:o}=r;e&&o==="textarea"?Q=ve(B,a=>{!Array.isArray(a)&&a!==ae&&ue(a)}):Q==null||Q()});let ee=null;Ce(()=>{r.type==="textarea"?ee=ve(B,e=>{var o;!Array.isArray(e)&&e!==ae&&((o=l.value)===null||o===void 0||o.syncUnifiedContainer())}):ee==null||ee()}),Sr(Fe,{mergedValueRef:B,maxlengthRef:Me,mergedClsPrefixRef:u,countGraphemesRef:he(r,"countGraphemes")});const wo={wrapperElRef:d,inputElRef:h,textareaElRef:n,isCompositing:k,clear:be,focus:me,blur:ho,select:vo,deactivate:go,activate:po,scrollTo:bo},yo=_r("Input",A,u),we=$(()=>{const{value:e}=te,{common:{cubicBezierEaseInOut:o},self:{color:a,borderRadius:c,textColor:v,caretColor:s,caretColorError:I,caretColorWarning:T,textDecorationColor:M,border:U,borderDisabled:j,borderHover:de,borderFocus:Co,placeholderColor:zo,placeholderColorDisabled:So,lineHeightTextarea:_o,colorDisabled:Ao,colorFocus:Ro,textColorDisabled:Bo,boxShadowFocus:Fo,iconSize:Po,colorFocusWarning:$o,boxShadowFocusWarning:ko,borderWarning:Eo,borderFocusWarning:Io,borderHoverWarning:To,colorFocusError:Mo,boxShadowFocusError:Vo,borderError:Do,borderFocusError:Lo,borderHoverError:Wo,clearSize:Oo,clearColor:No,clearColorHover:Ho,clearColorPressed:Ko,iconColor:Uo,iconColorDisabled:jo,suffixTextColor:Yo,countTextColor:Go,countTextColorDisabled:Xo,iconColorHover:Zo,iconColorPressed:qo,loadingColor:Jo,loadingColorError:Qo,loadingColorWarning:er,fontWeight:or,[fe("padding",e)]:rr,[fe("fontSize",e)]:nr,[fe("height",e)]:tr}}=x.value,{left:ar,right:lr}=Ar(rr);return{"--n-bezier":o,"--n-count-text-color":Go,"--n-count-text-color-disabled":Xo,"--n-color":a,"--n-font-size":nr,"--n-font-weight":or,"--n-border-radius":c,"--n-height":tr,"--n-padding-left":ar,"--n-padding-right":lr,"--n-text-color":v,"--n-caret-color":s,"--n-text-decoration-color":M,"--n-border":U,"--n-border-disabled":j,"--n-border-hover":de,"--n-border-focus":Co,"--n-placeholder-color":zo,"--n-placeholder-color-disabled":So,"--n-icon-size":Po,"--n-line-height-textarea":_o,"--n-color-disabled":Ao,"--n-color-focus":Ro,"--n-text-color-disabled":Bo,"--n-box-shadow-focus":Fo,"--n-loading-color":Jo,"--n-caret-color-warning":T,"--n-color-focus-warning":$o,"--n-box-shadow-focus-warning":ko,"--n-border-warning":Eo,"--n-border-focus-warning":Io,"--n-border-hover-warning":To,"--n-loading-color-warning":er,"--n-caret-color-error":I,"--n-color-focus-error":Mo,"--n-box-shadow-focus-error":Vo,"--n-border-error":Do,"--n-border-focus-error":Lo,"--n-border-hover-error":Wo,"--n-loading-color-error":Qo,"--n-clear-color":No,"--n-clear-size":Oo,"--n-clear-color-hover":Ho,"--n-clear-color-pressed":Ko,"--n-icon-color":Uo,"--n-icon-color-hover":Zo,"--n-icon-color-pressed":qo,"--n-icon-color-disabled":jo,"--n-suffix-text-color":Yo}}),W=P?Rr("input",$(()=>{const{value:e}=te;return e[0]}),we,r):void 0;return Object.assign(Object.assign({},wo),{wrapperElRef:d,inputElRef:h,inputMirrorElRef:E,inputEl2Ref:z,textareaElRef:n,textareaMirrorElRef:m,textareaScrollbarInstRef:l,rtlEnabled:yo,uncontrolledValue:w,mergedValue:B,passwordVisible:K,mergedPlaceholder:le,showPlaceholder1:$e,showPlaceholder2:ke,mergedFocus:ie,isComposing:k,activated:H,showClearButton:Ee,mergedSize:te,mergedDisabled:D,textDecorationStyle:Ie,mergedClsPrefix:u,mergedBordered:p,mergedShowPasswordOn:se,placeholderStyle:xe,mergedStatus:Pe,textAreaScrollContainerWidth:ge,handleTextAreaScroll:xo,handleCompositionStart:Ge,handleCompositionEnd:Xe,handleInput:q,handleInputBlur:qe,handleInputFocus:Je,handleWrapperBlur:Qe,handleWrapperFocus:eo,handleMouseEnter:ao,handleMouseLeave:lo,handleMouseDown:to,handleChange:oo,handleClick:ro,handleClear:no,handlePasswordToggleClick:io,handlePasswordToggleMousedown:so,handleWrapperKeydown:uo,handleWrapperKeyup:co,handleTextAreaMirrorResize:mo,getTextareaScrollContainer:()=>n.value,mergedTheme:x,cssVars:P?void 0:we,themeClass:W==null?void 0:W.themeClass,onRender:W==null?void 0:W.onRender})},render(){var r,u,p,P,A,x,d;const{mergedClsPrefix:n,mergedStatus:m,themeClass:E,type:h,countGraphemes:z,onRender:S}=this,g=this.$slots;return S==null||S(),t("div",{ref:"wrapperElRef",class:[`${n}-input`,E,m&&`${n}-input--${m}-status`,{[`${n}-input--rtl`]:this.rtlEnabled,[`${n}-input--disabled`]:this.mergedDisabled,[`${n}-input--textarea`]:h==="textarea",[`${n}-input--resizable`]:this.resizable&&!this.autosize,[`${n}-input--autosize`]:this.autosize,[`${n}-input--round`]:this.round&&h!=="textarea",[`${n}-input--pair`]:this.pair,[`${n}-input--focus`]:this.mergedFocus,[`${n}-input--stateful`]:this.stateful}],style:this.cssVars,tabindex:!this.mergedDisabled&&this.passivelyActivated&&!this.activated?0:void 0,onFocus:this.handleWrapperFocus,onBlur:this.handleWrapperBlur,onClick:this.handleClick,onMousedown:this.handleMouseDown,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd,onKeyup:this.handleWrapperKeyup,onKeydown:this.handleWrapperKeydown},t("div",{class:`${n}-input-wrapper`},oe(g.prefix,l=>l&&t("div",{class:`${n}-input__prefix`},l)),h==="textarea"?t(vr,{ref:"textareaScrollbarInstRef",class:`${n}-input__textarea`,container:this.getTextareaScrollContainer,theme:(u=(r=this.theme)===null||r===void 0?void 0:r.peers)===null||u===void 0?void 0:u.Scrollbar,themeOverrides:(P=(p=this.themeOverrides)===null||p===void 0?void 0:p.peers)===null||P===void 0?void 0:P.Scrollbar,triggerDisplayManually:!0,useUnifiedContainer:!0,internalHoistYRail:!0},{default:()=>{var l,f;const{textAreaScrollContainerWidth:w}=this,R={width:this.autosize&&w&&`${w}px`};return t(pr,null,t("textarea",Object.assign({},this.inputProps,{ref:"textareaElRef",class:[`${n}-input__textarea-el`,(l=this.inputProps)===null||l===void 0?void 0:l.class],autofocus:this.autofocus,rows:Number(this.rows),placeholder:this.placeholder,value:this.mergedValue,disabled:this.mergedDisabled,maxlength:z?void 0:this.maxlength,minlength:z?void 0:this.minlength,readonly:this.readonly,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,style:[this.textDecorationStyle[0],(f=this.inputProps)===null||f===void 0?void 0:f.style,R],onBlur:this.handleInputBlur,onFocus:B=>{this.handleInputFocus(B,2)},onInput:this.handleInput,onChange:this.handleChange,onScroll:this.handleTextAreaScroll})),this.showPlaceholder1?t("div",{class:`${n}-input__placeholder`,style:[this.placeholderStyle,R],key:"placeholder"},this.mergedPlaceholder[0]):null,this.autosize?t(gr,{onResize:this.handleTextAreaMirrorResize},{default:()=>t("div",{ref:"textareaMirrorElRef",class:`${n}-input__textarea-mirror`,key:"mirror"})}):null)}}):t("div",{class:`${n}-input__input`},t("input",Object.assign({type:h==="password"&&this.mergedShowPasswordOn&&this.passwordVisible?"text":h},this.inputProps,{ref:"inputElRef",class:[`${n}-input__input-el`,(A=this.inputProps)===null||A===void 0?void 0:A.class],style:[this.textDecorationStyle[0],(x=this.inputProps)===null||x===void 0?void 0:x.style],tabindex:this.passivelyActivated&&!this.activated?-1:(d=this.inputProps)===null||d===void 0?void 0:d.tabindex,placeholder:this.mergedPlaceholder[0],disabled:this.mergedDisabled,maxlength:z?void 0:this.maxlength,minlength:z?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[0]:this.mergedValue,readonly:this.readonly,autofocus:this.autofocus,size:this.attrSize,onBlur:this.handleInputBlur,onFocus:l=>{this.handleInputFocus(l,0)},onInput:l=>{this.handleInput(l,0)},onChange:l=>{this.handleChange(l,0)}})),this.showPlaceholder1?t("div",{class:`${n}-input__placeholder`},t("span",null,this.mergedPlaceholder[0])):null,this.autosize?t("div",{class:`${n}-input__input-mirror`,key:"mirror",ref:"inputMirrorElRef"}," "):null),!this.pair&&oe(g.suffix,l=>l||this.clearable||this.showCount||this.mergedShowPasswordOn||this.loading!==void 0?t("div",{class:`${n}-input__suffix`},[oe(g["clear-icon-placeholder"],f=>(this.clearable||f)&&t(pe,{clsPrefix:n,show:this.showClearButton,onClear:this.handleClear},{placeholder:()=>f,icon:()=>{var w,R;return(R=(w=this.$slots)["clear-icon"])===null||R===void 0?void 0:R.call(w)}})),this.internalLoadingBeforeSuffix?null:l,this.loading!==void 0?t(Ir,{clsPrefix:n,loading:this.loading,showArrow:!1,showClear:!1,style:this.cssVars}):null,this.internalLoadingBeforeSuffix?l:null,this.showCount&&this.type!=="textarea"?t(Ae,null,{default:f=>{var w;const{renderCount:R}=this;return R?R(f):(w=g.count)===null||w===void 0?void 0:w.call(g,f)}}):null,this.mergedShowPasswordOn&&this.type==="password"?t("div",{class:`${n}-input__eye`,onMousedown:this.handlePasswordToggleMousedown,onClick:this.handlePasswordToggleClick},this.passwordVisible?G(g["password-visible-icon"],()=>[t(ne,{clsPrefix:n},{default:()=>t($r,null)})]):G(g["password-invisible-icon"],()=>[t(ne,{clsPrefix:n},{default:()=>t(kr,null)})])):null]):null)),this.pair?t("span",{class:`${n}-input__separator`},G(g.separator,()=>[this.separator])):null,this.pair?t("div",{class:`${n}-input-wrapper`},t("div",{class:`${n}-input__input`},t("input",{ref:"inputEl2Ref",type:this.type,class:`${n}-input__input-el`,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[1],disabled:this.mergedDisabled,maxlength:z?void 0:this.maxlength,minlength:z?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[1]:void 0,readonly:this.readonly,style:this.textDecorationStyle[1],onBlur:this.handleInputBlur,onFocus:l=>{this.handleInputFocus(l,1)},onInput:l=>{this.handleInput(l,1)},onChange:l=>{this.handleChange(l,1)}}),this.showPlaceholder2?t("div",{class:`${n}-input__placeholder`},t("span",null,this.mergedPlaceholder[1])):null),oe(g.suffix,l=>(this.clearable||l)&&t("div",{class:`${n}-input__suffix`},[this.clearable&&t(pe,{clsPrefix:n,show:this.showClearButton,onClear:this.handleClear},{icon:()=>{var f;return(f=g["clear-icon"])===null||f===void 0?void 0:f.call(g)},placeholder:()=>{var f;return(f=g["clear-icon-placeholder"])===null||f===void 0?void 0:f.call(g)}}),l]))):null,this.mergedBordered?t("div",{class:`${n}-input__border`}):null,this.mergedBordered?t("div",{class:`${n}-input__state-border`}):null,this.showCount&&h==="textarea"?t(Ae,null,{default:l=>{var f;const{renderCount:w}=this;return w?w(l):(f=g.count)===null||f===void 0?void 0:f.call(g,l)}}):null)}});export{Fr as C,Nr as N,Ir as a};
