# -*- coding: utf-8 -*-
# ==============================================================================
# MIT License
#
# Copyright (c) 2021 Albert Moky
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ==============================================================================

import asyncio
from abc import ABC, abstractmethod
from threading import Thread
from typing import Coroutine

from ..types import Duration


class Processor(ABC):

    @abstractmethod
    async def process(self) -> bool:
        """
        Do the job

        :return: False on nothing to do
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.process()'
        )


class Handler(ABC):

    @abstractmethod
    async def setup(self):
        """ Prepare before Handling """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.setup()'
        )
    
    @abstractmethod
    async def handle(self):
        """ Run loop for handling """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.handle()'
        )

    @abstractmethod
    async def finish(self):
        """ Cleanup after handled """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.finish()'
        )


class Runnable(ABC):

    @abstractmethod
    async def run(self):
        """ Run in an async task """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.run()'
        )


# noinspection PyAbstractClass
class Runner(Runnable, Handler, Processor, ABC):
    """
        Runner
        ~~~~~~

        @abstract method:
            - process()
    """

    # Frames Per Second
    # ~~~~~~~~~~~~~~~~~
    # (1) The human eye can process 10-12 still images per second,
    #     and the dynamic compensation function can also deceive us.
    # (2) At a frame rate of 12fps or lower, we can quickly distinguish between
    #     a pile of still images and not animations.
    # (3) Once the playback rate (frames per second) of the images reaches 16-24 fps,
    #     our brain will assume that these images are a continuously moving scene
    #     and will appear like the effect of a movie.
    # (4) At 24fps, there is a feeling of 'motion blur',
    #     while at 60fps, the image is the smoothest and cleanest.
    INTERVAL_SLOW = 1.0/10
    INTERVAL_NORMAL = 1.0/25
    INTERVAL_FAST = 1.0/60

    def __init__(self, interval: Duration):
        super().__init__()
        assert interval > 0, 'interval error: %s' % interval
        self.__interval = interval
        self.__running = False

    @property
    def interval(self) -> Duration:
        return self.__interval

    @property
    def running(self) -> bool:
        return self.__running

    # async def start(self):
    #     self.__running = True

    async def stop(self):
        self.__running = False

    # Override
    async def run(self):
        await self.setup()
        try:
            await self.handle()
        finally:
            await self.finish()

    # Override
    async def setup(self):
        self.__running = True

    # Override
    async def finish(self):
        self.__running = False

    # Override
    async def handle(self):
        while self.running:
            if await self.process():
                # process() return true,
                # means this thread is busy,
                # so process next task immediately
                pass
            else:
                # nothing to do now,
                # have a rest ^_^
                await self._idle()

    # protected
    async def _idle(self):
        await self.sleep(seconds=self.interval)
        # time.sleep(self.interval)

    @classmethod
    async def sleep(cls, seconds: Duration):
        await asyncio.sleep(seconds)

    @classmethod
    def sync_run(cls, main: Coroutine):
        """ Run main coroutine until complete """
        return asyncio.run(main)

    @classmethod
    def async_task(cls, coro: Coroutine) -> asyncio.Task:
        """ Create an async task to run the coroutine """
        return asyncio.create_task(coro)

    @classmethod
    def async_thread(cls, coro: Coroutine, daemonic: bool = True) -> Thread:
        """ Create a daemon thread to run the coroutine """
        return Thread(target=cls.sync_run, args=(coro,), daemon=daemonic)
