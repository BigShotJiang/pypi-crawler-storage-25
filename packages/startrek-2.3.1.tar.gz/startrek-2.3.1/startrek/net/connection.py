# -*- coding: utf-8 -*-
#
#   Star Trek: Interstellar Transport
#
#                                Written in 2021 by Moky <albert.moky@gmail.com>
#
# ==============================================================================
# MIT License
#
# Copyright (c) 2021 Albert Moky
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ==============================================================================

from abc import ABC, abstractmethod
from typing import Optional

from ..types import SocketAddress, Timestamp
from ..skywalker import Ticker


class Connection(Ticker, ABC):

    #
    #   Flags
    #

    @property
    @abstractmethod
    def closed(self) -> bool:
        """ not is_open() """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.closed getter'
        )

    @property
    @abstractmethod
    def bound(self) -> bool:
        """ is_bound() """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.bound getter'
        )

    @property
    @abstractmethod
    def connected(self) -> bool:
        """ is_connected() """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.connected getter'
        )

    @property
    @abstractmethod
    def alive(self) -> bool:
        """ is_opened() and (is_connected() or is_bound()) """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.alive getter'
        )

    @property
    @abstractmethod
    def available(self) -> bool:
        """ ready for reading """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.available getter'
        )

    @property
    @abstractmethod
    def vacant(self) -> bool:
        """ ready for writing """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.vacant getter'
        )

    @property
    @abstractmethod
    def local_address(self) -> Optional[SocketAddress]:  # (str, int)
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.local_address getter'
        )

    @property
    @abstractmethod
    def remote_address(self) -> Optional[SocketAddress]:  # (str, int)
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.remote_address getter'
        )

    @property
    @abstractmethod
    def state(self):  # -> Optional[ConnectionState]:
        """ Get connection state """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.state getter'
        )

    @abstractmethod
    async def send_data(self, data: bytes) -> int:
        """
        Send data

        :param data: outgo data package
        :return: count of bytes sent, probably zero when it's non-blocking mode
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.send_data()'
        )

    @abstractmethod
    async def received_data(self, data: bytes):
        """
        Call on received data for processing

        :param data: received data
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.received_data()'
        )

    @abstractmethod
    async def close(self):
        """ Close the connection """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.close()'
        )


class TimedConnection(ABC):

    EXPIRES = 16  # seconds

    @property
    @abstractmethod
    def last_sent_time(self) -> Timestamp:
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.last_sent_time getter'
        )

    @property
    @abstractmethod
    def last_received_time(self) -> Timestamp:
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.last_received_time getter'
        )

    @abstractmethod
    def is_sent_recently(self, now: Timestamp) -> bool:
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.is_sent_recently()'
        )

    @abstractmethod
    def is_received_recently(self, now: Timestamp) -> bool:
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.is_received_recently()'
        )

    @abstractmethod
    def is_not_received_long_time_ago(self, now: Timestamp) -> bool:
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.is_not_received_long_time_ago()'
        )
