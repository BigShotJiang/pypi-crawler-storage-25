# -*- coding: utf-8 -*-
#
#   Star Trek: Interstellar Transport
#
#                                Written in 2021 by Moky <albert.moky@gmail.com>
#
# ==============================================================================
# MIT License
#
# Copyright (c) 2021 Albert Moky
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ==============================================================================

import socket
from abc import ABC, abstractmethod
from enum import IntEnum
from typing import Optional, Tuple

from ..types import SocketAddress


# protected
class ChannelStatus(IntEnum):
    """ Channel State Order """
    INIT = 0    # initializing
    OPEN = 1    # initialized
    ALIVE = 2   # (not closed) and (connected or bound)
    CLOSED = 3  # closed


class Channel(ABC):

    @property
    @abstractmethod
    def status(self) -> ChannelStatus:
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.status getter'
        )

    @property
    @abstractmethod
    def closed(self) -> bool:
        """ not is_open() """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.closed getter'
        )

    @property
    @abstractmethod
    def bound(self) -> bool:
        """ is_bound() """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.bound getter'
        )

    @property
    @abstractmethod
    def alive(self) -> bool:
        """ is_opened() and (is_connected() or is_bound()) """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.alive getter'
        )

    @property
    @abstractmethod
    def available(self) -> bool:
        """ ready for reading """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.available getter'
        )

    @property
    @abstractmethod
    def vacant(self) -> bool:
        """ ready for writing """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.vacant getter'
        )

    @abstractmethod
    async def close(self):
        """ Close the channel """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.close()'
        )

    #
    #   Byte Channel
    #

    @abstractmethod
    async def read(self, max_len: int) -> Optional[bytes]:
        """
        Reads a sequence of bytes from this channel into the given buffer.

        :param max_len: max buffer length
        :return: The number of bytes read, possibly zero,
                 or -1 if the channel has reached end-of-stream
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.read()'
        )

    @abstractmethod
    async def write(self, data: bytes) -> int:
        """
        Writes a sequence of bytes to this channel from the given buffer.

        :param data: outgo data
        :return: The number of bytes written, possibly zero
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.write()'
        )

    #
    #   Selectable Channel
    #

    @abstractmethod
    def configure_blocking(self, blocking: bool):
        """
        Adjusts this channel's blocking mode.

        :param blocking: If True then this channel will be placed in blocking mode;
                         if False then it will be placed non-blocking mode
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.configure_blocking()'
        )

    @property
    @abstractmethod
    def blocking(self) -> bool:
        """ is_blocking() """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.blocking getter'
        )

    #
    #   Network Channel
    #

    @abstractmethod
    def bind(self, address: Optional[SocketAddress] = None,
             host: Optional[str] = '0.0.0.0', port: Optional[int] = 0):
        """
        Binds the channel's socket to a local address (host, port).

        :param address: local address
        :param host:    local host
        :param port:    local port
        :return: bound socket
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.bind()'
        )

    @property
    @abstractmethod
    def local_address(self) -> Optional[SocketAddress]:  # (str, int)
        """
        Returns the socket address that this channel's socket is bound to.

        :return: The socket address that the socket is bound to,
                 or None if the channel's socket is not bound
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.local_address getter'
        )

    #
    #   Socket/Datagram Channel
    #

    @property
    @abstractmethod
    def connected(self) -> bool:
        """ is_connected() """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.connected getter'
        )

    @abstractmethod
    async def connect(self, address: Optional[SocketAddress] = None,
                      host: Optional[str] = '127.0.0.1', port: Optional[int] = 0) -> socket.socket:
        """
        Connects this channel's socket.

        :param address: remote address
        :param host:    remote host
        :param port:    remote port
        :return: connected socket
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.connect()'
        )

    @property
    @abstractmethod
    def remote_address(self) -> Optional[SocketAddress]:  # (str, int)
        """
        Returns the remote address to which this channel's socket is connected.

        :return: The remote address; None if the channel's socket is not connected
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.remote_address getter'
        )

    #
    #   Datagram Channel
    #

    @abstractmethod
    async def disconnect(self) -> Optional[socket.socket]:
        """
        Disconnects this channel's socket.

        :return: inner socket
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.disconnect()'
        )

    @abstractmethod
    async def receive(self, max_len: int) -> Tuple[Optional[bytes], Optional[SocketAddress]]:
        """
        Receives a data package via this channel.

        :param max_len: max buffer length
        :return: received data and remote address
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.receive()'
        )

    @abstractmethod
    async def send(self, data: bytes, target: SocketAddress) -> int:
        """
        Sends a data package via this channel.

        :param data:   outgo data package
        :param target: remote address
        :return: The number of bytes sent, which will be either the number
                 of bytes that were remaining in the source buffer when this
                 method was invoked or, if this channel is non-blocking, may be
                 zero if there was insufficient room for the datagram in the
                 underlying output buffer
        :raise: OSError
        """
        raise NotImplementedError(
            f'Not implemented: {type(self).__module__}.{type(self).__name__}.send()'
        )
