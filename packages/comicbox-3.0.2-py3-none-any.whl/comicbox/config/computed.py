"""Compute values for config before template load."""

from confuse import Subview
from loguru import logger

from comicbox.config.formats import _raw_or_empty, transform_keys_to_formats
from comicbox.config.paths import clean_paths
from comicbox.formats import MetadataFormats
from comicbox.print import PrintPhases
from comicbox.sources import MetadataSources
from comicbox.version import DEFAULT_TAGGER

_FORMATS_WITH_TAGS_WITHOUT_IDS = frozenset(
    {
        MetadataFormats.COMIC_BOOK_INFO,
        MetadataFormats.COMIC_INFO,
        MetadataFormats.COMICTAGGER,
        MetadataFormats.PDF,
        MetadataFormats.PDF_XML,
    }
)


def _ensure_cli_yaml(config: Subview) -> None:
    """Wrap all cli yaml in brackets if its bare."""
    mds = config["metadata_cli"].get()
    if not mds:
        return
    wrapped_md_list = [("{" + md + "}" if md[0] != "{" else md) for md in mds if md]

    config["metadata_cli"].set(tuple(wrapped_md_list))


def _deduplicate_delete_keys(config: Subview) -> None:
    """Transform delete keys to a set."""
    raw = _raw_or_empty(config["delete_keys"])
    delete_keys = frozenset(str(kp).removeprefix("comicbox.") for kp in raw)
    config["delete_keys"].set(delete_keys)


def _parse_print(config: Subview) -> None:
    raw = _raw_or_empty(config["print"])
    if not raw:
        config["print"].set(frozenset())
        return
    # Accept a string ("snmcp") or any iterable of strings (["s", "n", ...])
    # — concatenate into a single phase-char string.
    chars = raw if isinstance(raw, str) else "".join(str(p) for p in raw)
    enum_print_phases: set[PrintPhases] = set()
    for phase in chars.lower():
        try:
            enum_print_phases.add(PrintPhases(phase))
        except ValueError as exc:
            logger.warning(exc)
    config["print"].set(frozenset(enum_print_phases))


def _set_tagger(config: Subview) -> None:
    tagger = config["tagger"].get()
    if not tagger:
        config["tagger"].set(DEFAULT_TAGGER)


def _set_computed(config: Subview) -> None:
    write: frozenset = config["write"].get(frozenset)
    export: frozenset = config["export"].get(frozenset)
    all_write_fmts = frozenset(write | export)
    config["computed"]["all_write_formats"].set(all_write_fmts)
    read: frozenset = config["read"].get(frozenset)
    rfnf = frozenset(frozenset(MetadataSources.ARCHIVE_FILENAME.value.formats) & read)
    config["computed"]["read_filename_formats"].set(rfnf)
    rff = frozenset(frozenset(MetadataSources.ARCHIVE_FILE.value.formats) & read)
    config["computed"]["read_file_formats"].set(rff)
    rmlf = frozenset(fmt.value.filename.lower() for fmt in rff)
    config["computed"]["read_metadata_lower_filenames"].set(rmlf)
    irc = bool(
        frozenset(frozenset(MetadataSources.ARCHIVE_COMMENT.value.formats) & read)
    )
    config["computed"]["is_read_comments"].set(irc)
    iscft = not bool(_FORMATS_WITH_TAGS_WITHOUT_IDS & read)
    config["computed"]["is_skip_computed_from_tags"].set(iscft)


def compute_config(config_program: Subview) -> None:
    """Compute values for config before template load."""
    clean_paths(config_program)
    _ensure_cli_yaml(config_program)
    _deduplicate_delete_keys(config_program)
    transform_keys_to_formats(config_program)
    _parse_print(config_program)
    _set_tagger(config_program)
    _set_computed(config_program)
