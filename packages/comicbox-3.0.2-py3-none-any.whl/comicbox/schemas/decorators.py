"""Wrapped marshmallow decorators."""

from collections.abc import Callable
from functools import wraps
from typing import Any

from loguru import logger


def trap_error(decorator: Callable) -> Callable[[Callable], Callable]:
    """Wrap marshmallow decorators to trap exceptions and log them."""

    def wrapper(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapped(self, data: Any, **kwargs: Any) -> Any:
            try:
                return func(self, data, **kwargs)
            except Exception:
                logger.exception(getattr(func, "__name__", func))
                return data

        return decorator(wrapped)

    return wrapper
