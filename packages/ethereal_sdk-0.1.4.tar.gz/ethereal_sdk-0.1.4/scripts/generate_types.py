import os
import sys
import json
import copy
import argparse
import requests
import subprocess
from pathlib import Path
from typing import Any, Dict


# Mapping from spec alias to output filename
ALIAS_OUTPUT_FILES = {
    "primary": "rest.py",
    "archive": "archive.py",
    "tv": "tv.py",
}

# Network configuration mapping
NETWORK_CONFIGS = {
    "mainnet": {
        "openapi_urls": {
            "primary": "https://api.ethereal.trade/openapi.json",
            "archive": "https://archive.ethereal.trade/openapi.json",
            "tv": "https://tradingview.ethereal.trade/openapi.json",
        },
        "output_dir": "ethereal/models/mainnet",
    },
    "testnet": {
        "openapi_urls": {
            "primary": "https://api.etherealtest.net/openapi.json",
            "archive": "https://archive.etherealtest.net/openapi.json",
            "tv": "https://tradingview.etherealtest.net/openapi.json",
        },
        "output_dir": "ethereal/models/testnet",
    },
    "devnet": {
        "openapi_urls": {
            "primary": "https://api.etherealdev.net/openapi.json",
            "archive": "https://archive.etherealdev.net/openapi.json",
            "tv": "https://tradingview.etherealdev.net/openapi.json",
        },
        "output_dir": "ethereal/models/devnet",
    },
}

# Default fallback directory for models (used when network is not specified at runtime)
DEFAULT_OUTPUT_DIR = "ethereal/models"


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate Pydantic types from OpenAPI spec"
    )
    parser.add_argument(
        "--network",
        type=str,
        choices=list(NETWORK_CONFIGS.keys()),
        default="testnet",
        help="Network to generate types for (default: testnet)",
    )
    parser.add_argument(
        "--url", type=str, help="Custom OpenAPI spec URL (overrides network default)"
    )
    return parser.parse_args()


def get_config(args) -> Dict[str, Any]:
    """Get configuration based on arguments"""
    config = copy.deepcopy(NETWORK_CONFIGS[args.network])

    if args.url:
        config["openapi_urls"] = {"primary": args.url}

    # Generate network-specific output dir
    config["output_dir"] = f"ethereal/models/{args.network}"

    return config


def fetch_openapi_spec(url: str) -> Dict[str, Any]:
    """Fetch and parse an OpenAPI spec from the provided URL."""
    response = requests.get(url)
    response.raise_for_status()

    try:
        return response.json()
    except ValueError as exc:
        raise ValueError(f"Invalid JSON received from {url}") from exc


def _postprocess_generated_file(output_path: Path):
    """Apply post-processing to a generated file."""
    with open(output_path, "r") as f:
        content = f.read()

    # Replace all instances of '0', or "0", with Decimal("0"),
    content = content.replace("'0',", 'Decimal("0"),')
    content = content.replace('"0",', 'Decimal("0"),')

    with open(output_path, "w") as f:
        f.write(content)


def _generate_single_spec(
    alias: str, spec: Dict[str, Any], network: str, output_dir: Path
):
    """Generate types from a single OpenAPI spec."""
    output_file = ALIAS_OUTPUT_FILES.get(alias, f"{alias}.py")
    output_path = output_dir / output_file

    # Write spec to a temporary file
    temp_spec_file = f"openapi_{network}_{alias}.json"
    with open(temp_spec_file, "w") as f:
        json.dump(spec, f)

    # Run datamodel-codegen
    result = subprocess.run(
        [
            "uv",
            "run",
            "datamodel-codegen",
            "--input",
            temp_spec_file,
            "--output",
            str(output_path),
            "--input-file-type",
            "openapi",
            "--openapi-scopes",
            "paths",
            "schemas",
            "parameters",
            "--output-model-type",
            "pydantic_v2.BaseModel",
            "--snake-case-field",
        ],
        capture_output=True,
        text=True,
    )

    os.remove(temp_spec_file)

    if result.returncode != 0:
        print(f"Error generating {alias} types: {result.stderr}")
        sys.exit(1)

    # Post-process the generated file
    _postprocess_generated_file(output_path)
    print(f"  Generated {alias} types at: {output_path}")


def generate_types(network: str, config: Dict[str, Any]):
    """Generate types for a specific network from all configured specs."""
    print(f"Generating types for {network}...")

    urls = config.get("openapi_urls")
    if not urls:
        print("No OpenAPI URLs configured; nothing to generate.")
        sys.exit(1)

    # Create output directory if it doesn't exist
    output_dir = Path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    for alias, url in urls.items():
        print(f"Fetching {alias} OpenAPI spec from: {url}")
        try:
            spec = fetch_openapi_spec(url)
        except Exception as exc:
            print(f"Error fetching OpenAPI spec ({alias}): {exc}")
            sys.exit(1)

        _generate_single_spec(alias, spec, network, output_dir)

    # Also write to the default fallback directory
    default_dir = Path(DEFAULT_OUTPUT_DIR)
    if output_dir.resolve() != default_dir.resolve():
        print(f"Copying generated types to default fallback: {default_dir}")
        for alias, url in urls.items():
            output_file = ALIAS_OUTPUT_FILES.get(alias, f"{alias}.py")
            src = output_dir / output_file
            dst = default_dir / output_file
            if src.exists():
                import shutil

                shutil.copy2(src, dst)
                print(f"  Copied {output_file} to {dst}")


def main():
    args = parse_args()
    config = get_config(args)
    generate_types(args.network, config)


if __name__ == "__main__":
    main()
