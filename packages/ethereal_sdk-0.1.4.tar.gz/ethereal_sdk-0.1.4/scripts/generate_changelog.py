"""Generate docs/changelog.md from GitHub Releases.

Pulls release notes from the GitHub Releases API via the `gh` CLI,
so the changelog reflects the curated notes written for each release.

Run before mkdocs build to include release notes in the docs site.

Usage:
    python scripts/generate_changelog.py
    python scripts/generate_changelog.py --include-prereleases
    python scripts/generate_changelog.py --repo meridianxyz/ethereal-py-sdk
"""

import argparse
import json
import subprocess
import sys


def run(cmd: list[str]) -> str:
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error running {' '.join(cmd)}: {result.stderr}", file=sys.stderr)
        sys.exit(1)
    return result.stdout.strip()


def get_releases(repo: str, include_prereleases: bool = False) -> list[dict]:
    """Fetch releases from GitHub via gh CLI."""
    cmd = [
        "gh",
        "release",
        "list",
        "--repo",
        repo,
        "--limit",
        "50",
        "--json",
        "tagName,name,publishedAt,isPrerelease",
        "--order",
        "desc",
    ]
    raw = run(cmd)
    releases = json.loads(raw)

    if not include_prereleases:
        releases = [r for r in releases if not r["isPrerelease"]]

    return releases


def get_release_body(repo: str, tag: str) -> str:
    """Fetch the body/notes for a single release."""
    cmd = [
        "gh",
        "release",
        "view",
        tag,
        "--repo",
        repo,
        "--json",
        "body",
        "--jq",
        ".body",
    ]
    return run(cmd)


def generate_changelog(repo: str, include_prereleases: bool = False) -> str:
    releases = get_releases(repo, include_prereleases)

    if not releases:
        return "# Changelog\n\nNo releases yet.\n"

    lines = ["# Changelog\n"]

    for release in releases:
        tag = release["tagName"]
        date = release["publishedAt"][:10]
        name = release.get("name") or tag

        lines.append(f"## {name} ({date})\n")

        body = get_release_body(repo, tag)
        if body:
            lines.append(body)
        else:
            lines.append("*No release notes.*")

        lines.append("")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="Generate changelog from GitHub Releases"
    )
    parser.add_argument(
        "--include-prereleases",
        action="store_true",
        help="Include pre-release tags (rc, alpha, beta)",
    )
    parser.add_argument(
        "--repo",
        default="meridianxyz/ethereal-py-sdk",
        help="GitHub repo (default: meridianxyz/ethereal-py-sdk)",
    )
    parser.add_argument(
        "--output",
        default="docs/changelog.md",
        help="Output file path (default: docs/changelog.md)",
    )
    args = parser.parse_args()

    changelog = generate_changelog(args.repo, args.include_prereleases)

    with open(args.output, "w") as f:
        f.write(changelog)

    print(f"Generated {args.output}")


if __name__ == "__main__":
    main()
