# Ethereal SDK Test Suite

## Quick Start

### Required Setup

```bash
# Set your private key
export PRIVATE_KEY="your-private-key-here"

# Or set it in your .env file
```

### Running Tests

```bash
# Run all tests on testnet (default)
pytest

# Run all tests on devnet
pytest --network=devnet

# Run all tests on mainnet
pytest --network=mainnet

# Use environment variable instead of flag
NETWORK=devnet uv run pytest
```

### Running Specific Tests

```bash
# Run a single test file
pytest tests/rest/test_rest_orders.py --network=devnet

# Run a single test function
pytest tests/rest/test_rest_orders.py::test_rest_limit_order_floats_submit_cancel # defaults to testnet
```

## Network-Specific Testing

### Markers

Use markers to control which networks a test runs on:

```python
@pytest.mark.skip_mainnet
def test_aggressive_behavior():
    """This test will skip when running on mainnet"""
    pass

@pytest.mark.devnet_only
def test_devnet_feature():
    """This test only runs on devnet"""
    pass

@pytest.mark.testnet_only
def test_testnet_specific():
    """This test only runs on testnet"""
    pass
```
