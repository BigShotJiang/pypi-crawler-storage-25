"""Smoke test to validate package installation."""

import sys
from ethereal import RESTClient, AsyncRESTClient, WSClient, AsyncWSClient, __version__


def test_imports():
    """Test that all main imports work."""
    assert RESTClient is not None
    assert AsyncRESTClient is not None
    assert WSClient is not None
    assert AsyncWSClient is not None
    assert __version__ is not None
    print(f"All imports successful, version: {__version__}")


if __name__ == "__main__":
    test_imports()
    sys.exit(0)
