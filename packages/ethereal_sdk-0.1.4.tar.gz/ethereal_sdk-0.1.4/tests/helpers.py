"""Shared test helpers."""

import asyncio
import time

OPS_PER_SECOND = 0.5


def rate_limit(ops: int):
    """Rate limit helper - sleeps based on ops count."""
    time.sleep(ops / OPS_PER_SECOND)


def wait_for_order_sync(client, order_id, timeout=5.0, interval=0.5):
    """Poll for an order until it's available (sync).

    Retries on 404 Not Found up to timeout. Any other error raises immediately.
    """
    deadline = time.monotonic() + timeout
    last_exc = None
    while time.monotonic() < deadline:
        try:
            return client.get_order(order_id)
        except Exception as exc:
            if "404" not in str(exc) and "Not Found" not in str(exc):
                raise
            last_exc = exc
            time.sleep(interval)
    raise last_exc


async def wait_for_order(client, order_id, timeout=5.0, interval=0.5):
    """Poll for an order until it's available (async).

    Retries on 404 Not Found up to timeout. Any other error raises immediately.
    """
    deadline = time.monotonic() + timeout
    last_exc = None
    while time.monotonic() < deadline:
        try:
            return await client.get_order(order_id)
        except Exception as exc:
            if "404" not in str(exc) and "Not Found" not in str(exc):
                raise
            last_exc = exc
        await asyncio.sleep(interval)
    raise last_exc
