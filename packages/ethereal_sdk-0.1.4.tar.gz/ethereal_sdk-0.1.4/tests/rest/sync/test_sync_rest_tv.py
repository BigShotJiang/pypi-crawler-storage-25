"""Sync TradingView endpoint coverage."""

import time


# ---------------------------------------------------------------------------
# Last Price
# ---------------------------------------------------------------------------


def test_get_last_price_config(rc):
    config = rc.get_last_price_config()
    assert isinstance(config, rc._tv_models.ConfigDto)
    assert isinstance(config.supported_resolutions, list)
    assert len(config.supported_resolutions) > 0


def test_get_last_price_symbol(rc):
    symbol = rc.get_last_price_symbol(symbol="ETHUSD-Perp")
    assert isinstance(symbol, rc._tv_models.SymbolInfoDto)
    assert symbol.ticker == "ETHUSD-Perp"
    assert "ETH" in symbol.name


def test_search_last_price_symbols(rc):
    results = rc.search_last_price_symbols(query="ETH")
    assert isinstance(results, list)
    if results:
        assert isinstance(results[0], rc._tv_models.SymbolSearchResultDto)
        assert results[0].ticker is not None


def test_get_last_price_history(rc):
    now = int(time.time())
    history = rc.get_last_price_history(
        symbol="ETHUSD-Perp",
        resolution="1D",
        from_=now - 7 * 24 * 3600,
        to=now,
    )
    assert isinstance(history, rc._tv_models.HistoryResponseDto)
    assert history.s.value in ("ok", "no_data")
    if history.s.value == "ok":
        assert history.t is not None
        assert len(history.t) > 0


def test_get_last_price_time(rc):
    result = rc.get_last_price_time()
    assert isinstance(result, (int, float, dict))


# ---------------------------------------------------------------------------
# Oracle Price
# ---------------------------------------------------------------------------


def test_get_oracle_price_config(rc):
    config = rc.get_oracle_price_config()
    assert isinstance(config, rc._tv_models.ConfigDto)
    assert isinstance(config.supported_resolutions, list)


def test_get_oracle_price_symbol(rc):
    symbol = rc.get_oracle_price_symbol(symbol="ETHUSD-Perp")
    assert isinstance(symbol, rc._tv_models.SymbolInfoDto)
    assert symbol.ticker == "ETHUSD-Perp"


def test_search_oracle_price_symbols(rc):
    results = rc.search_oracle_price_symbols(query="ETH")
    assert isinstance(results, list)
    if results:
        assert isinstance(results[0], rc._tv_models.SymbolSearchResultDto)


def test_get_oracle_price_history(rc):
    now = int(time.time())
    history = rc.get_oracle_price_history(
        symbol="ETHUSD-Perp",
        resolution="1D",
        from_=now - 7 * 24 * 3600,
        to=now,
    )
    assert isinstance(history, rc._tv_models.HistoryResponseDto)
    assert history.s.value in ("ok", "no_data")


def test_get_oracle_price_time(rc):
    result = rc.get_oracle_price_time()
    assert isinstance(result, (int, float, dict))
