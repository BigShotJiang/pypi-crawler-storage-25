"""Async TradingView endpoint coverage."""

import time

import pytest


# ---------------------------------------------------------------------------
# Last Price
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_last_price_config(async_rc):
    config = await async_rc.get_last_price_config()
    assert isinstance(config, async_rc._tv_models.ConfigDto)
    assert isinstance(config.supported_resolutions, list)
    assert len(config.supported_resolutions) > 0


@pytest.mark.asyncio
async def test_get_last_price_symbol(async_rc):
    symbol = await async_rc.get_last_price_symbol(symbol="ETHUSD-Perp")
    assert isinstance(symbol, async_rc._tv_models.SymbolInfoDto)
    assert symbol.ticker == "ETHUSD-Perp"
    assert "ETH" in symbol.name


@pytest.mark.asyncio
async def test_search_last_price_symbols(async_rc):
    results = await async_rc.search_last_price_symbols(query="ETH")
    assert isinstance(results, list)
    if results:
        assert isinstance(results[0], async_rc._tv_models.SymbolSearchResultDto)
        assert results[0].ticker is not None


@pytest.mark.asyncio
async def test_get_last_price_history(async_rc):
    now = int(time.time())
    history = await async_rc.get_last_price_history(
        symbol="ETHUSD-Perp",
        resolution="1D",
        from_=now - 7 * 24 * 3600,
        to=now,
    )
    assert isinstance(history, async_rc._tv_models.HistoryResponseDto)
    assert history.s.value in ("ok", "no_data")
    if history.s.value == "ok":
        assert history.t is not None
        assert len(history.t) > 0


@pytest.mark.asyncio
async def test_get_last_price_time(async_rc):
    result = await async_rc.get_last_price_time()
    assert isinstance(result, (int, float, dict))


# ---------------------------------------------------------------------------
# Oracle Price
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_oracle_price_config(async_rc):
    config = await async_rc.get_oracle_price_config()
    assert isinstance(config, async_rc._tv_models.ConfigDto)
    assert isinstance(config.supported_resolutions, list)


@pytest.mark.asyncio
async def test_get_oracle_price_symbol(async_rc):
    symbol = await async_rc.get_oracle_price_symbol(symbol="ETHUSD-Perp")
    assert isinstance(symbol, async_rc._tv_models.SymbolInfoDto)
    assert symbol.ticker == "ETHUSD-Perp"


@pytest.mark.asyncio
async def test_search_oracle_price_symbols(async_rc):
    results = await async_rc.search_oracle_price_symbols(query="ETH")
    assert isinstance(results, list)
    if results:
        assert isinstance(results[0], async_rc._tv_models.SymbolSearchResultDto)


@pytest.mark.asyncio
async def test_get_oracle_price_history(async_rc):
    now = int(time.time())
    history = await async_rc.get_oracle_price_history(
        symbol="ETHUSD-Perp",
        resolution="1D",
        from_=now - 7 * 24 * 3600,
        to=now,
    )
    assert isinstance(history, async_rc._tv_models.HistoryResponseDto)
    assert history.s.value in ("ok", "no_data")


@pytest.mark.asyncio
async def test_get_oracle_price_time(async_rc):
    result = await async_rc.get_oracle_price_time()
    assert isinstance(result, (int, float, dict))
