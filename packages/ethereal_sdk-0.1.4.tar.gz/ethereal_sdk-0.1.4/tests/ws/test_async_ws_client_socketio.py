"""Tests for AsyncWSClient with Socket.IO transport."""

import pytest
import asyncio


@pytest.mark.asyncio
async def test_async_ws_socketio_open(async_ws):
    """Test opening an async Socket.IO websocket connection."""
    assert async_ws.connected


@pytest.mark.asyncio
async def test_async_ws_socketio_subscribe(async_ws):
    """Test subscribing to an async Socket.IO stream."""
    received = []
    async_ws.callbacks["BookDepth"] = [lambda d: received.append(d)]

    await async_ws.subscribe(
        stream_type="BookDepth",
        product_id="4368f737-eeed-40bc-bb1b-7b9bfd88a057",
    )
    assert async_ws.connected


@pytest.mark.asyncio
async def test_async_ws_socketio_receive_messages(async_ws):
    """Test receiving messages via async Socket.IO."""
    received = []
    async_ws.callbacks["BookDepth"] = [lambda d: received.append(d)]

    await async_ws.subscribe(
        stream_type="BookDepth",
        product_id="4368f737-eeed-40bc-bb1b-7b9bfd88a057",
    )

    await asyncio.sleep(3)
    assert len(received) >= 0
