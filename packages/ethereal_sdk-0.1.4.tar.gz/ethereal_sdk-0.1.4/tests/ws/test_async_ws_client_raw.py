"""Tests for AsyncWSClient with raw WebSocket transport."""

import pytest
import asyncio
from decimal import Decimal, ROUND_HALF_UP
import pytest_asyncio
import ethereal

pytestmark = pytest.mark.ws_raw


def safe_round_price(price, tick_size):
    """Round price to valid tick size."""
    if tick_size == 0:
        return float(price)
    price_decimal = Decimal(str(price))
    tick_size_decimal = Decimal(str(tick_size))
    return float(
        (price_decimal / tick_size_decimal).quantize(
            Decimal("1"), rounding=ROUND_HALF_UP
        )
        * tick_size_decimal
    )


@pytest_asyncio.fixture
async def async_ws_raw(network_config):
    """Async raw WebSocket client for testing."""
    if "ws_raw_url" not in network_config:
        pytest.skip("ws_raw_url not configured for this network")
    ws = ethereal.AsyncWSClient(
        {
            "base_url": network_config["ws_raw_url"],
            "transport": "websocket",
        }
    )
    await ws.open()
    try:
        yield ws
    finally:
        await ws.close()


# ---------------------------------------------------------------------------
# Connection basics
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_open(async_ws_raw):
    """Test opening an async raw websocket connection."""
    assert async_ws_raw.connected


@pytest.mark.asyncio
async def test_async_ws_raw_subscribe(async_ws_raw):
    """Test subscribing to a stream."""
    result = await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    assert result.get("ok") is True


@pytest.mark.asyncio
async def test_async_ws_raw_unsubscribe(async_ws_raw):
    """Test unsubscribing from a stream."""
    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    result = await async_ws_raw.unsubscribe(stream_type="Ticker", symbol="BTCUSD")
    assert result.get("ok") is True


# ---------------------------------------------------------------------------
# Ticker channel
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_receive_messages(async_ws_raw):
    """Test receiving messages after subscribing."""
    received = []
    async_ws_raw.callbacks["Ticker"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await asyncio.sleep(5)

    assert len(received) > 0
    assert "s" in received[0]
    assert received[0]["s"] == "BTCUSD"


@pytest.mark.asyncio
async def test_async_ws_raw_async_callback(async_ws_raw):
    """Test that async callbacks work correctly."""
    received = []

    async def async_handler(data):
        await asyncio.sleep(0.01)
        received.append(data)

    async_ws_raw.callbacks["Ticker"] = [async_handler]

    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await asyncio.sleep(5)

    assert len(received) > 0


@pytest.mark.asyncio
async def test_async_ws_raw_multiple_subscriptions(async_ws_raw):
    """Test multiple subscriptions route to correct callbacks."""
    btc_messages = []
    eth_messages = []

    async_ws_raw.callbacks["Ticker"] = [
        lambda d: btc_messages.append(d)
        if d.get("s") == "BTCUSD"
        else eth_messages.append(d)
    ]

    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="Ticker", symbol="ETHUSD")
    await asyncio.sleep(5)

    assert len(btc_messages) > 0
    assert len(eth_messages) > 0


@pytest.mark.asyncio
async def test_async_ws_raw_ticker_fields(async_ws_raw):
    """Test that Ticker messages contain the expected fields."""
    received = []
    async_ws_raw.callbacks["Ticker"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await asyncio.sleep(5)

    assert len(received) > 0
    msg = received[0]
    assert msg["e"] == "Ticker"
    assert msg["s"] == "BTCUSD"
    assert "t" in msg
    assert isinstance(msg["t"], (int, float))
    assert "bidPx" in msg or "askPx" in msg


@pytest.mark.asyncio
async def test_async_ws_raw_ticker_multiple_symbols(async_ws_raw):
    """Test Ticker for multiple symbols and validate each."""
    symbols = ["BTCUSD", "ETHUSD"]
    received = {s: [] for s in symbols}

    def handler(d):
        sym = d.get("s")
        if sym in received:
            received[sym].append(d)

    async_ws_raw.callbacks["Ticker"] = [handler]

    for sym in symbols:
        await async_ws_raw.subscribe(stream_type="Ticker", symbol=sym)
    await asyncio.sleep(6)

    for sym in symbols:
        assert len(received[sym]) > 0, f"No Ticker messages for {sym}"
        msg = received[sym][0]
        assert msg["e"] == "Ticker"
        assert msg["s"] == sym


@pytest.mark.asyncio
async def test_async_ws_raw_ticker_unsubscribe_stops_messages(async_ws_raw):
    """Test that unsubscribing stops further Ticker messages."""
    received = []
    async_ws_raw.callbacks["Ticker"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await asyncio.sleep(3)
    count_before = len(received)
    assert count_before > 0

    await async_ws_raw.unsubscribe(stream_type="Ticker", symbol="BTCUSD")
    await asyncio.sleep(3)
    count_after = len(received)

    assert count_after - count_before <= 1


# ---------------------------------------------------------------------------
# L2Book (orderbook) channel
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_subscribe(async_ws_raw):
    """Test subscribing to L2Book returns ok."""
    result = await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    assert result.get("ok") is True


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_message_structure(async_ws_raw):
    """Test L2Book message has correct structure with bids and asks."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(3)

    assert len(received) > 0
    msg = received[0]
    assert msg["e"] == "L2Book"
    assert msg["s"] == "BTCUSD"
    assert "t" in msg
    assert "a" in msg
    assert "b" in msg
    assert isinstance(msg["a"], list)
    assert isinstance(msg["b"], list)


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_price_levels(async_ws_raw):
    """Test L2Book initial snapshot contains valid price levels."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(3)

    assert len(received) > 0
    msg = received[0]

    if len(msg["a"]) > 0:
        ask = msg["a"][0]
        assert len(ask) == 2
        assert float(ask[0]) > 0
        assert float(ask[1]) >= 0

    if len(msg["b"]) > 0:
        bid = msg["b"][0]
        assert len(bid) == 2
        assert float(bid[0]) > 0
        assert float(bid[1]) >= 0


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_asks_above_bids(async_ws_raw):
    """Test that L2Book asks are priced above bids."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(3)

    assert len(received) > 0
    msg = received[0]

    if len(msg["a"]) > 0 and len(msg["b"]) > 0:
        best_ask = float(msg["a"][0][0])
        best_bid = float(msg["b"][0][0])
        assert best_ask >= best_bid, f"Best ask {best_ask} < best bid {best_bid}"


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_multiple_symbols(async_ws_raw):
    """Test subscribing to L2Book for multiple symbols simultaneously."""
    symbols = ["BTCUSD", "ETHUSD"]
    received = {s: [] for s in symbols}

    def handler(d):
        sym = d.get("s")
        if sym in received:
            received[sym].append(d)

    async_ws_raw.callbacks["L2Book"] = [handler]

    for sym in symbols:
        await async_ws_raw.subscribe(stream_type="L2Book", symbol=sym)
    await asyncio.sleep(5)

    for sym in symbols:
        assert len(received[sym]) > 0, f"No L2Book messages for {sym}"
        msg = received[sym][0]
        assert msg["e"] == "L2Book"
        assert msg["s"] == sym
        assert "a" in msg and "b" in msg


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_continuous_updates(async_ws_raw):
    """Test L2Book emits at least the initial snapshot plus any diffs."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(15)

    # At minimum we should get the initial snapshot
    assert len(received) >= 1, (
        f"Expected at least 1 L2Book message in 15s, got {len(received)}"
    )


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_timestamps_increase(async_ws_raw):
    """Test L2Book timestamps are monotonically increasing when multiple messages arrive."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(15)

    assert len(received) >= 1, f"Need at least 1 message, got {len(received)}"
    # If we got multiple messages, verify ordering
    for i in range(1, len(received)):
        assert received[i]["t"] >= received[i - 1]["t"]


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_unsubscribe_stops_messages(async_ws_raw):
    """Test that unsubscribing from L2Book stops messages."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(3)
    count_before = len(received)
    assert count_before > 0

    await async_ws_raw.unsubscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(3)
    count_after = len(received)

    assert count_after - count_before <= 1


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_resubscribe(async_ws_raw):
    """Test unsubscribing and resubscribing to L2Book works."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(2)
    assert len(received) > 0

    await async_ws_raw.unsubscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(2)
    received.clear()

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(2)
    assert len(received) > 0


# ---------------------------------------------------------------------------
# TradeFill channel
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_trade_fill_subscribe(async_ws_raw):
    """Test subscribing to TradeFill returns ok."""
    result = await async_ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    assert result.get("ok") is True


@pytest.mark.asyncio
async def test_async_ws_raw_trade_fill_unsubscribe(async_ws_raw):
    """Test unsubscribing from TradeFill returns ok."""
    await async_ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    result = await async_ws_raw.unsubscribe(stream_type="TradeFill", symbol="BTCUSD")
    assert result.get("ok") is True


@pytest.mark.asyncio
async def test_async_ws_raw_trade_fill_message_structure(async_ws_raw):
    """Test TradeFill messages have expected structure (if trades occur)."""
    received = []
    async_ws_raw.callbacks["TradeFill"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    await asyncio.sleep(5)

    if len(received) > 0:
        msg = received[0]
        assert msg["e"] == "TradeFill"
        assert "data" in msg
        assert "t" in msg
        assert isinstance(msg["data"], list)
        if len(msg["data"]) > 0:
            fill = msg["data"][0]
            assert "id" in fill
            assert "px" in fill
            assert "sz" in fill
            assert "sd" in fill


# ---------------------------------------------------------------------------
# OrderUpdate channel
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_order_update_subscribe(async_ws_raw, async_rc):
    """Test subscribing to OrderUpdate returns ok."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]
    result = await async_ws_raw.subscribe(
        stream_type="OrderUpdate", subaccountId=str(sub.id)
    )
    assert result.get("ok") is True


@pytest.mark.asyncio
async def test_async_ws_raw_order_update_unsubscribe(async_ws_raw, async_rc):
    """Test unsubscribing from OrderUpdate returns ok."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]
    sub_id = str(sub.id)
    await async_ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=sub_id)
    result = await async_ws_raw.unsubscribe(
        stream_type="OrderUpdate", subaccountId=sub_id
    )
    assert result.get("ok") is True


@pytest.mark.asyncio
async def test_async_ws_raw_order_update_on_new_order(async_ws_raw, async_rc):
    """Test that placing a limit order triggers an OrderUpdate message."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]

    received = []
    async_ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    await asyncio.sleep(1)

    pid = (await async_rc.list_products())[0].id
    tick_size = float((await async_rc.products_by_id())[pid].tick_size)
    prices = (await async_rc.list_market_prices(product_ids=[pid]))[0]
    best_bid = float(prices.best_bid_price)
    bid_price = safe_round_price(best_bid * 0.80, tick_size)

    order = await async_rc.create_order(
        order_type="LIMIT",
        product_id=pid,
        side=0,
        price=bid_price,
        quantity=0.001,
        time_in_force="GTD",
        post_only=False,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    assert order.id is not None

    await asyncio.sleep(5)

    assert len(received) > 0, "No OrderUpdate received after placing order"
    msg = received[0]
    assert msg["e"] == "OrderUpdate"
    assert "data" in msg
    assert isinstance(msg["data"], list)
    assert len(msg["data"]) > 0

    # Clean up
    await async_rc.cancel_orders(
        sender=async_rc.chain.address, subaccount=sub.name, order_ids=[order.id]
    )
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_async_ws_raw_order_update_on_cancel(async_ws_raw, async_rc):
    """Test that cancelling an order triggers an OrderUpdate with cancelled status."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]

    received = []
    async_ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    await asyncio.sleep(1)

    pid = (await async_rc.list_products())[0].id
    tick_size = float((await async_rc.products_by_id())[pid].tick_size)
    prices = (await async_rc.list_market_prices(product_ids=[pid]))[0]
    best_bid = float(prices.best_bid_price)
    bid_price = safe_round_price(best_bid * 0.80, tick_size)

    order = await async_rc.create_order(
        order_type="LIMIT",
        product_id=pid,
        side=0,
        price=bid_price,
        quantity=0.001,
        time_in_force="GTD",
        post_only=False,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    await asyncio.sleep(2)
    received.clear()

    await async_rc.cancel_orders(
        sender=async_rc.chain.address, subaccount=sub.name, order_ids=[order.id]
    )
    await asyncio.sleep(5)

    assert len(received) > 0, "No OrderUpdate received after cancelling order"
    cancel_updates = []
    for msg in received:
        if msg["e"] == "OrderUpdate":
            for entry in msg.get("data", []):
                if entry.get("status") == "CANCELED":
                    cancel_updates.append(entry)

    assert len(cancel_updates) > 0, "No CANCELED OrderUpdate found"


@pytest.mark.asyncio
async def test_async_ws_raw_order_update_multiple_orders(async_ws_raw, async_rc):
    """Test OrderUpdate receives updates for multiple orders."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]

    received = []
    async_ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    await asyncio.sleep(1)

    pid = (await async_rc.list_products())[0].id
    tick_size = float((await async_rc.products_by_id())[pid].tick_size)
    prices = (await async_rc.list_market_prices(product_ids=[pid]))[0]
    best_bid = float(prices.best_bid_price)

    order_ids = []
    for i in range(3):
        bid_price = safe_round_price(best_bid * (0.75 + i * 0.01), tick_size)
        o = await async_rc.create_order(
            order_type="LIMIT",
            product_id=pid,
            side=0,
            price=bid_price,
            quantity=0.001,
            time_in_force="GTD",
            post_only=False,
            sender=async_rc.chain.address,
            subaccount=sub.name,
        )
        order_ids.append(o.id)

    await asyncio.sleep(5)

    all_order_ids_in_updates = set()
    for msg in received:
        if msg["e"] == "OrderUpdate":
            for entry in msg.get("data", []):
                if "id" in entry:
                    all_order_ids_in_updates.add(entry["id"])

    for oid in order_ids:
        assert (
            str(oid) in all_order_ids_in_updates or oid in all_order_ids_in_updates
        ), f"Order {oid} not found in OrderUpdate messages"

    # Clean up
    await async_rc.cancel_orders(
        sender=async_rc.chain.address, subaccount=sub.name, order_ids=order_ids
    )
    await asyncio.sleep(2)


# ---------------------------------------------------------------------------
# TradeFill + order execution
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_trade_fill_on_market_order(async_ws_raw, async_rc):
    """Test that executing a market order produces a TradeFill message."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]

    received = []
    async_ws_raw.callbacks["TradeFill"] = [lambda d: received.append(d)]

    pid = (await async_rc.list_products())[0].id
    product = (await async_rc.products_by_id())[pid]
    symbol = product.ticker

    await async_ws_raw.subscribe(stream_type="TradeFill", symbol=symbol)
    await asyncio.sleep(1)

    order = await async_rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=0,
        quantity=0.001,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    assert order.id is not None
    await asyncio.sleep(5)

    assert len(received) > 0, "No TradeFill received after market order"
    msg = received[0]
    assert msg["e"] == "TradeFill"
    assert "data" in msg
    assert isinstance(msg["data"], list)
    assert len(msg["data"]) > 0

    fill = msg["data"][0]
    assert "px" in fill
    assert "sz" in fill
    assert float(fill["px"]) > 0
    assert float(fill["sz"]) > 0

    # Close position
    await async_rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=1,
        quantity=0,
        reduce_only=True,
        close=True,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_async_ws_raw_order_update_on_market_order_fill(async_ws_raw, async_rc):
    """Test that a market order triggers OrderUpdate with filled status."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]

    received = []
    async_ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    await asyncio.sleep(1)

    pid = (await async_rc.list_products())[0].id

    _order = await async_rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=0,
        quantity=0.001,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    await asyncio.sleep(5)

    assert len(received) > 0, "No OrderUpdate received after market order"

    filled_updates = []
    for msg in received:
        if msg["e"] == "OrderUpdate":
            for entry in msg.get("data", []):
                if entry.get("status") == "FILLED":
                    filled_updates.append(entry)

    assert len(filled_updates) > 0, "No FILLED OrderUpdate found after market order"

    # Close position
    await async_rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=1,
        quantity=0,
        reduce_only=True,
        close=True,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    await asyncio.sleep(1)


# ---------------------------------------------------------------------------
# Mixed channel subscriptions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_multiple_channel_types(async_ws_raw, async_rc):
    """Test subscribing to multiple channel types simultaneously."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]

    ticker_msgs = []
    book_msgs = []
    order_msgs = []

    async_ws_raw.callbacks["Ticker"] = [lambda d: ticker_msgs.append(d)]
    async_ws_raw.callbacks["L2Book"] = [lambda d: book_msgs.append(d)]
    async_ws_raw.callbacks["OrderUpdate"] = [lambda d: order_msgs.append(d)]

    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    await asyncio.sleep(5)

    assert len(ticker_msgs) > 0, "No Ticker messages received"
    assert len(book_msgs) > 0, "No L2Book messages received"


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_and_ticker_same_symbol(async_ws_raw):
    """Test L2Book and Ticker for same symbol don't interfere."""
    book_msgs = []
    price_msgs = []

    async_ws_raw.callbacks["L2Book"] = [lambda d: book_msgs.append(d)]
    async_ws_raw.callbacks["Ticker"] = [lambda d: price_msgs.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await asyncio.sleep(5)

    assert len(book_msgs) > 0
    assert len(price_msgs) > 0

    for msg in book_msgs:
        assert msg["e"] == "L2Book"
    for msg in price_msgs:
        assert msg["e"] == "Ticker"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_subscribe_invalid_symbol(async_ws_raw):
    """Test subscribing to an invalid symbol returns an error."""
    result = await async_ws_raw.subscribe(stream_type="Ticker", symbol="INVALIDUSD")
    assert result.get("ok") is False
    assert "code" in result


@pytest.mark.asyncio
async def test_async_ws_raw_subscribe_invalid_type(async_ws_raw):
    """Test subscribing to an invalid stream type returns an error."""
    result = await async_ws_raw.subscribe(
        stream_type="NonExistentType", symbol="BTCUSD"
    )
    assert result.get("ok") is False


# ---------------------------------------------------------------------------
# SubaccountLiquidation channel
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_subaccount_liquidation_subscribe(async_ws_raw, async_rc):
    """Test subscribing to SubaccountLiquidation returns ok."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]
    result = await async_ws_raw.subscribe(
        stream_type="SubaccountLiquidation", subaccountId=str(sub.id)
    )
    assert result.get("ok") is True


@pytest.mark.asyncio
async def test_async_ws_raw_subaccount_liquidation_unsubscribe(async_ws_raw, async_rc):
    """Test unsubscribing from SubaccountLiquidation returns ok."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub_id = str(subs[0].id)
    await async_ws_raw.subscribe(
        stream_type="SubaccountLiquidation", subaccountId=sub_id
    )
    result = await async_ws_raw.unsubscribe(
        stream_type="SubaccountLiquidation", subaccountId=sub_id
    )
    assert result.get("ok") is True


# ---------------------------------------------------------------------------
# Selective unsubscribe
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_unsubscribe_one_of_many(async_ws_raw):
    """Test unsubscribing from one symbol doesn't affect other subscriptions."""
    btc_msgs = []
    eth_msgs = []

    def handler(d):
        sym = d.get("s")
        if sym == "BTCUSD":
            btc_msgs.append(d)
        elif sym == "ETHUSD":
            eth_msgs.append(d)

    async_ws_raw.callbacks["L2Book"] = [handler]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="L2Book", symbol="ETHUSD")
    await asyncio.sleep(3)

    assert len(btc_msgs) > 0
    assert len(eth_msgs) > 0

    await async_ws_raw.unsubscribe(stream_type="L2Book", symbol="BTCUSD")
    btc_msgs.clear()
    eth_msgs.clear()
    await asyncio.sleep(3)

    assert len(eth_msgs) > 0, "ETH L2Book stopped after unsubscribing BTC"
    assert len(btc_msgs) <= 1, "BTC L2Book still flowing after unsubscribe"


# ---------------------------------------------------------------------------
# Async-specific: concurrent subscriptions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_concurrent_subscribes(async_ws_raw):
    """Test subscribing to multiple streams concurrently."""
    ticker_msgs = []
    book_msgs = []
    async_ws_raw.callbacks["Ticker"] = [lambda d: ticker_msgs.append(d)]
    async_ws_raw.callbacks["L2Book"] = [lambda d: book_msgs.append(d)]

    results = await asyncio.gather(
        async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD"),
        async_ws_raw.subscribe(stream_type="Ticker", symbol="ETHUSD"),
        async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD"),
    )

    for result in results:
        assert result.get("ok") is True

    await asyncio.sleep(5)

    assert len(ticker_msgs) > 0
    assert len(book_msgs) > 0


# ---------------------------------------------------------------------------
# Stress / duration tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_ws_raw_l2book_extended_listen(async_ws_raw):
    """Test L2Book subscription remains stable over 15 seconds."""
    received = []
    async_ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await asyncio.sleep(15)

    # L2Book sends diffs when the book changes; devnet can be very quiet
    assert len(received) >= 2, (
        f"Expected >= 2 L2Book messages in 15s, got {len(received)}"
    )

    for msg in received:
        assert msg["e"] == "L2Book"
        assert msg["s"] == "BTCUSD"
        assert "t" in msg
        assert "a" in msg
        assert "b" in msg


@pytest.mark.asyncio
async def test_async_ws_raw_multiple_orderbooks_extended(async_ws_raw):
    """Test subscribing to multiple orderbooks for an extended period."""
    symbols = ["BTCUSD", "ETHUSD"]
    received = {s: [] for s in symbols}

    def handler(d):
        sym = d.get("s")
        if sym in received:
            received[sym].append(d)

    async_ws_raw.callbacks["L2Book"] = [handler]

    for sym in symbols:
        await async_ws_raw.subscribe(stream_type="L2Book", symbol=sym)
    await asyncio.sleep(15)

    for sym in symbols:
        assert len(received[sym]) >= 3, (
            f"Expected >= 3 L2Book messages for {sym} in 15s, got {len(received[sym])}"
        )
        timestamps = [m["t"] for m in received[sym]]
        for i in range(1, len(timestamps)):
            assert timestamps[i] >= timestamps[i - 1]


@pytest.mark.asyncio
async def test_async_ws_raw_all_channels_simultaneously(async_ws_raw, async_rc):
    """Test subscribing to all available channel types at once."""
    subs = await async_rc.list_subaccounts(sender=async_rc.chain.address)
    sub = subs[0]

    ticker_msgs = []
    book_msgs = []
    trade_msgs = []
    order_msgs = []

    async_ws_raw.callbacks["Ticker"] = [lambda d: ticker_msgs.append(d)]
    async_ws_raw.callbacks["L2Book"] = [lambda d: book_msgs.append(d)]
    async_ws_raw.callbacks["TradeFill"] = [lambda d: trade_msgs.append(d)]
    async_ws_raw.callbacks["OrderUpdate"] = [lambda d: order_msgs.append(d)]

    await async_ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="Ticker", symbol="ETHUSD")
    await async_ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="L2Book", symbol="ETHUSD")
    await async_ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    await async_ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))

    pid = (await async_rc.list_products())[0].id

    _order = await async_rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=0,
        quantity=0.001,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    await asyncio.sleep(8)

    assert len(ticker_msgs) > 0, "No Ticker messages"
    assert len(book_msgs) > 0, "No L2Book messages"
    assert len(order_msgs) > 0, "No OrderUpdate messages after market order"

    for m in ticker_msgs:
        assert m["e"] == "Ticker"
    for m in book_msgs:
        assert m["e"] == "L2Book"
    for m in order_msgs:
        assert m["e"] == "OrderUpdate"

    # Close position
    await async_rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=1,
        quantity=0,
        reduce_only=True,
        close=True,
        sender=async_rc.chain.address,
        subaccount=sub.name,
    )
    await asyncio.sleep(1)
