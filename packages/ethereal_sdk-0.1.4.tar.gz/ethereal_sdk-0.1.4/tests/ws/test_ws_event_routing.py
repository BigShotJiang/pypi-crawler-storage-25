"""Tests for event routing via the 'e' field in WebSocket messages."""

from ethereal.ws.transports import AsyncWebSocketTransport, WebSocketTransport


def test_async_transport_event_routing_with_e_field():
    """Test that AsyncWebSocketTransport routes messages with 'e' field correctly."""
    transport = AsyncWebSocketTransport("ws://localhost:8000")

    ticker_messages = []
    book_depth_messages = []

    transport.callbacks["Ticker"] = [lambda d: ticker_messages.append(d)]
    transport.callbacks["L2Book"] = [lambda d: book_depth_messages.append(d)]

    test_messages = [
        {"e": "Ticker", "s": "BTCUSD", "p": "50000", "q": "1.5"},
        {"e": "L2Book", "s": "ETHUSD", "bids": [[3000, 10]], "asks": [[3001, 5]]},
        {"e": "Ticker", "s": "ETHUSD", "p": "3000", "q": "2.0"},
    ]

    for msg in test_messages:
        transport._dispatch_message(msg)

    assert len(ticker_messages) == 2
    assert len(book_depth_messages) == 1

    assert ticker_messages[0]["e"] == "Ticker"
    assert ticker_messages[0]["s"] == "BTCUSD"
    assert ticker_messages[1]["s"] == "ETHUSD"

    assert book_depth_messages[0]["e"] == "L2Book"
    assert book_depth_messages[0]["s"] == "ETHUSD"


def test_async_transport_ignores_messages_without_e_field():
    """Test that messages without 'e' field don't trigger callbacks."""
    transport = AsyncWebSocketTransport("ws://localhost:8000")

    received = []
    transport.callbacks["Ticker"] = [lambda d: received.append(d)]

    test_messages = [
        {"type": "Ticker", "s": "BTCUSD"},
        {"s": "ETHUSD", "p": "3000"},
        {"data": "some data"},
    ]

    for msg in test_messages:
        transport._dispatch_message(msg)

    assert len(received) == 0


def test_async_transport_ack_messages_not_dispatched():
    """Test that acknowledgment messages (with 'ok' field) are not dispatched to callbacks."""
    transport = AsyncWebSocketTransport("ws://localhost:8000")

    received = []
    transport.callbacks["Ticker"] = [lambda d: received.append(d)]

    ack_msg = {"ok": True, "subscribed": "Ticker"}
    transport._dispatch_message(ack_msg)

    assert len(received) == 0


def test_sync_ws_transport_event_routing():
    """Test that WebSocketTransport (sync wrapper) routes events via its async transport."""
    transport = WebSocketTransport("ws://localhost:8000")

    received = []
    transport.callbacks["Ticker"] = [lambda d: received.append(d)]

    msg = {"e": "Ticker", "s": "BTCUSD", "p": "50000"}
    transport._async._dispatch_message(msg)

    assert len(received) == 1
    assert received[0]["e"] == "Ticker"


def test_sync_ws_transport_ignores_messages_without_e_field():
    """Test that sync transport wrapper ignores messages without 'e' field."""
    transport = WebSocketTransport("ws://localhost:8000")

    received = []
    transport.callbacks["Ticker"] = [lambda d: received.append(d)]

    msg_no_e = {"type": "Ticker", "s": "BTCUSD"}
    transport._async._dispatch_message(msg_no_e)

    assert len(received) == 0


def test_multiple_callbacks_per_event():
    """Test that multiple callbacks for same event all get called."""
    transport = AsyncWebSocketTransport("ws://localhost:8000")

    received1 = []
    received2 = []

    transport.callbacks["Ticker"] = [
        lambda d: received1.append(d),
        lambda d: received2.append(d),
    ]

    msg = {"e": "Ticker", "s": "BTCUSD", "p": "50000"}
    transport._dispatch_message(msg)

    assert len(received1) == 1
    assert len(received2) == 1
    assert received1[0] == received2[0]


def test_event_field_case_sensitive():
    """Test that event routing is case-sensitive on 'e' field value."""
    transport = AsyncWebSocketTransport("ws://localhost:8000")

    ticker_messages = []
    ticker_lower_messages = []

    transport.callbacks["Ticker"] = [lambda d: ticker_messages.append(d)]
    transport.callbacks["ticker"] = [lambda d: ticker_lower_messages.append(d)]

    msg1 = {"e": "Ticker", "s": "BTCUSD"}
    msg2 = {"e": "ticker", "s": "ETHUSD"}

    transport._dispatch_message(msg1)
    transport._dispatch_message(msg2)

    assert len(ticker_messages) == 1
    assert len(ticker_lower_messages) == 1
    assert ticker_messages[0]["s"] == "BTCUSD"
    assert ticker_lower_messages[0]["s"] == "ETHUSD"
