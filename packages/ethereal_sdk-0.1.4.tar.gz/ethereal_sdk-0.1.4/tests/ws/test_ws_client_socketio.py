"""Tests for WSClient with Socket.IO transport."""

import pytest
import asyncio


def test_ws_socketio_open(ws):
    """Test opening a Socket.IO websocket connection."""
    assert ws.connected


def test_ws_socketio_subscribe(ws):
    """Test subscribing to a Socket.IO stream."""
    received = []
    ws.callbacks["BookDepth"] = [lambda d: received.append(d)]

    ws.subscribe(
        stream_type="BookDepth",
        product_id="4368f737-eeed-40bc-bb1b-7b9bfd88a057",
    )
    assert ws.connected


@pytest.mark.asyncio
async def test_ws_socketio_receive_messages(ws):
    """Test receiving messages via Socket.IO."""
    received = []
    ws.callbacks["BookDepth"] = [lambda d: received.append(d)]

    ws.subscribe(
        stream_type="BookDepth",
        product_id="4368f737-eeed-40bc-bb1b-7b9bfd88a057",
    )

    await asyncio.sleep(3)
    assert len(received) >= 0
