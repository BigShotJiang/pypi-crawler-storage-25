"""Tests for WSClient with raw WebSocket transport."""

import pytest
import time
from decimal import Decimal, ROUND_HALF_UP
from tests.helpers import rate_limit
import ethereal

pytestmark = pytest.mark.ws_raw


def safe_round_price(price, tick_size):
    """Round price to valid tick size."""
    if tick_size == 0:
        return float(price)
    price_decimal = Decimal(str(price))
    tick_size_decimal = Decimal(str(tick_size))
    return float(
        (price_decimal / tick_size_decimal).quantize(
            Decimal("1"), rounding=ROUND_HALF_UP
        )
        * tick_size_decimal
    )


@pytest.fixture
def ws_raw(network_config):
    """Raw WebSocket client for testing."""
    if "ws_raw_url" not in network_config:
        pytest.skip("ws_raw_url not configured for this network")
    ws = ethereal.WSClient(
        {
            "base_url": network_config["ws_raw_url"],
            "transport": "websocket",
        }
    )
    ws.open()
    try:
        yield ws
    finally:
        ws.close()


@pytest.fixture(scope="session")
def subaccount_info(rc):
    """Get the first subaccount's id and name."""
    subs = rc.list_subaccounts(sender=rc.chain.address)
    if not subs:
        pytest.fail("No subaccounts found for the connected address.")
    return subs[0]


# ---------------------------------------------------------------------------
# Connection basics
# ---------------------------------------------------------------------------


def test_ws_raw_open(ws_raw):
    """Test opening a raw websocket connection."""
    assert ws_raw.connected


def test_ws_raw_subscribe(ws_raw):
    """Test subscribing to a stream."""
    result = ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    assert result.get("ok") is True


def test_ws_raw_unsubscribe(ws_raw):
    """Test unsubscribing from a stream."""
    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    result = ws_raw.unsubscribe(stream_type="Ticker", symbol="BTCUSD")
    assert result.get("ok") is True


# ---------------------------------------------------------------------------
# Ticker channel
# ---------------------------------------------------------------------------


def test_ws_raw_receive_messages(ws_raw):
    """Test receiving messages after subscribing."""
    received = []
    ws_raw.callbacks["Ticker"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    time.sleep(5)

    assert len(received) > 0
    assert "s" in received[0]
    assert received[0]["s"] == "BTCUSD"


def test_ws_raw_multiple_subscriptions(ws_raw):
    """Test multiple subscriptions route to correct callbacks."""
    btc_messages = []
    eth_messages = []

    ws_raw.callbacks["Ticker"] = [
        lambda d: btc_messages.append(d)
        if d.get("s") == "BTCUSD"
        else eth_messages.append(d)
    ]

    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="Ticker", symbol="ETHUSD")
    time.sleep(5)

    assert len(btc_messages) > 0
    assert len(eth_messages) > 0


def test_ws_raw_ticker_fields(ws_raw):
    """Test that Ticker messages contain the expected fields."""
    received = []
    ws_raw.callbacks["Ticker"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    time.sleep(5)

    assert len(received) > 0
    msg = received[0]
    assert msg["e"] == "Ticker"
    assert msg["s"] == "BTCUSD"
    assert "t" in msg
    assert isinstance(msg["t"], (int, float))
    # At least one of bidPx or askPx should be present
    assert "bidPx" in msg or "askPx" in msg


def test_ws_raw_ticker_multiple_symbols(ws_raw):
    """Test Ticker for multiple symbols and validate each."""
    symbols = ["BTCUSD", "ETHUSD"]
    received = {s: [] for s in symbols}

    def handler(d):
        sym = d.get("s")
        if sym in received:
            received[sym].append(d)

    ws_raw.callbacks["Ticker"] = [handler]

    for sym in symbols:
        ws_raw.subscribe(stream_type="Ticker", symbol=sym)
    time.sleep(6)

    for sym in symbols:
        assert len(received[sym]) > 0, f"No Ticker messages for {sym}"
        msg = received[sym][0]
        assert msg["e"] == "Ticker"
        assert msg["s"] == sym


def test_ws_raw_ticker_unsubscribe_stops_messages(ws_raw):
    """Test that unsubscribing stops further Ticker messages."""
    received = []
    ws_raw.callbacks["Ticker"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    time.sleep(3)
    count_before = len(received)
    assert count_before > 0

    ws_raw.unsubscribe(stream_type="Ticker", symbol="BTCUSD")
    time.sleep(3)
    count_after = len(received)

    # Should have stopped (allow at most 1 straggler)
    assert count_after - count_before <= 1


# ---------------------------------------------------------------------------
# L2Book (orderbook) channel
# ---------------------------------------------------------------------------


def test_ws_raw_l2book_subscribe(ws_raw):
    """Test subscribing to L2Book returns ok."""
    result = ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    assert result.get("ok") is True


def test_ws_raw_l2book_message_structure(ws_raw):
    """Test L2Book message has correct structure with bids and asks."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(3)

    assert len(received) > 0
    msg = received[0]
    assert msg["e"] == "L2Book"
    assert msg["s"] == "BTCUSD"
    assert "t" in msg
    assert "a" in msg  # asks
    assert "b" in msg  # bids
    assert isinstance(msg["a"], list)
    assert isinstance(msg["b"], list)


def test_ws_raw_l2book_price_levels(ws_raw):
    """Test L2Book initial snapshot contains price levels with valid data."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(3)

    assert len(received) > 0
    msg = received[0]

    # Initial snapshot should have price levels
    if len(msg["a"]) > 0:
        ask = msg["a"][0]
        assert len(ask) == 2  # [price, quantity]
        assert float(ask[0]) > 0  # price is positive
        assert float(ask[1]) >= 0  # quantity is non-negative

    if len(msg["b"]) > 0:
        bid = msg["b"][0]
        assert len(bid) == 2
        assert float(bid[0]) > 0
        assert float(bid[1]) >= 0


def test_ws_raw_l2book_asks_above_bids(ws_raw):
    """Test that L2Book asks are priced above bids."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(3)

    assert len(received) > 0
    msg = received[0]

    if len(msg["a"]) > 0 and len(msg["b"]) > 0:
        best_ask = float(msg["a"][0][0])
        best_bid = float(msg["b"][0][0])
        assert best_ask >= best_bid, f"Best ask {best_ask} < best bid {best_bid}"


def test_ws_raw_l2book_multiple_symbols(ws_raw):
    """Test subscribing to L2Book for multiple symbols simultaneously."""
    symbols = ["BTCUSD", "ETHUSD"]
    received = {s: [] for s in symbols}

    def handler(d):
        sym = d.get("s")
        if sym in received:
            received[sym].append(d)

    ws_raw.callbacks["L2Book"] = [handler]

    for sym in symbols:
        ws_raw.subscribe(stream_type="L2Book", symbol=sym)
    time.sleep(5)

    for sym in symbols:
        assert len(received[sym]) > 0, f"No L2Book messages for {sym}"
        msg = received[sym][0]
        assert msg["e"] == "L2Book"
        assert msg["s"] == sym
        assert "a" in msg and "b" in msg


def test_ws_raw_l2book_continuous_updates(ws_raw):
    """Test L2Book emits at least the initial snapshot plus any diffs."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(15)

    # At minimum we should get the initial snapshot
    assert len(received) >= 1, (
        f"Expected at least 1 L2Book message in 15s, got {len(received)}"
    )


def test_ws_raw_l2book_timestamps_increase(ws_raw):
    """Test L2Book timestamps are monotonically increasing when multiple messages arrive."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(15)

    assert len(received) >= 1, f"Need at least 1 message, got {len(received)}"
    # If we got multiple messages, verify ordering
    for i in range(1, len(received)):
        assert received[i]["t"] >= received[i - 1]["t"], (
            f"Timestamp went backwards: {received[i]['t']} < {received[i - 1]['t']}"
        )


def test_ws_raw_l2book_unsubscribe_stops_messages(ws_raw):
    """Test that unsubscribing from L2Book stops further messages."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(3)
    count_before = len(received)
    assert count_before > 0

    ws_raw.unsubscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(3)
    count_after = len(received)

    assert count_after - count_before <= 1


def test_ws_raw_l2book_resubscribe(ws_raw):
    """Test unsubscribing and resubscribing to L2Book works."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(2)
    assert len(received) > 0

    ws_raw.unsubscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(2)
    received.clear()

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(2)
    assert len(received) > 0


# ---------------------------------------------------------------------------
# TradeFill channel
# ---------------------------------------------------------------------------


def test_ws_raw_trade_fill_subscribe(ws_raw):
    """Test subscribing to TradeFill returns ok."""
    result = ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    assert result.get("ok") is True


def test_ws_raw_trade_fill_unsubscribe(ws_raw):
    """Test unsubscribing from TradeFill returns ok."""
    ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    result = ws_raw.unsubscribe(stream_type="TradeFill", symbol="BTCUSD")
    assert result.get("ok") is True


def test_ws_raw_trade_fill_message_structure(ws_raw):
    """Test TradeFill messages have the expected structure (if any trades occur)."""
    received = []
    ws_raw.callbacks["TradeFill"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    # Trades may not happen in the window, so just verify subscription works
    time.sleep(5)

    if len(received) > 0:
        msg = received[0]
        assert msg["e"] == "TradeFill"
        assert "data" in msg
        assert "t" in msg
        assert isinstance(msg["data"], list)
        if len(msg["data"]) > 0:
            fill = msg["data"][0]
            assert "id" in fill
            assert "px" in fill  # price
            assert "sz" in fill  # size
            assert "sd" in fill  # side (0=buy, 1=sell)


# ---------------------------------------------------------------------------
# OrderUpdate channel
# ---------------------------------------------------------------------------


def test_ws_raw_order_update_subscribe(ws_raw, rc, subaccount_info):
    """Test subscribing to OrderUpdate returns ok."""
    result = ws_raw.subscribe(
        stream_type="OrderUpdate", subaccountId=str(subaccount_info.id)
    )
    assert result.get("ok") is True


def test_ws_raw_order_update_unsubscribe(ws_raw, rc, subaccount_info):
    """Test unsubscribing from OrderUpdate returns ok."""
    sub_id = str(subaccount_info.id)
    ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=sub_id)
    result = ws_raw.unsubscribe(stream_type="OrderUpdate", subaccountId=sub_id)
    assert result.get("ok") is True


def test_ws_raw_order_update_on_new_order(ws_raw, rc, subaccount_info):
    """Test that placing a limit order triggers an OrderUpdate message."""
    sub = subaccount_info
    received = []
    ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    time.sleep(1)

    pid = rc.list_products()[0].id
    tick_size = float(rc.products_by_id[pid].tick_size)
    prices = rc.list_market_prices(product_ids=[pid])[0]
    best_bid = float(prices.best_bid_price)
    bid_price = safe_round_price(best_bid * 0.80, tick_size)

    order = rc.create_order(
        order_type="LIMIT",
        product_id=pid,
        side=0,
        price=bid_price,
        quantity=0.001,
        time_in_force="GTD",
        post_only=False,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    assert order.id is not None

    # Wait for OrderUpdate
    time.sleep(5)

    assert len(received) > 0, "No OrderUpdate received after placing order"
    msg = received[0]
    assert msg["e"] == "OrderUpdate"
    assert "data" in msg
    assert isinstance(msg["data"], list)
    assert len(msg["data"]) > 0

    # Clean up
    rc.cancel_orders(sender=rc.chain.address, subaccount=sub.name, order_ids=[order.id])
    rate_limit(2)


def test_ws_raw_order_update_on_cancel(ws_raw, rc, subaccount_info):
    """Test that cancelling an order triggers an OrderUpdate with cancelled status."""
    sub = subaccount_info
    received = []
    ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    time.sleep(1)

    pid = rc.list_products()[0].id
    tick_size = float(rc.products_by_id[pid].tick_size)
    prices = rc.list_market_prices(product_ids=[pid])[0]
    best_bid = float(prices.best_bid_price)
    bid_price = safe_round_price(best_bid * 0.80, tick_size)

    order = rc.create_order(
        order_type="LIMIT",
        product_id=pid,
        side=0,
        price=bid_price,
        quantity=0.001,
        time_in_force="GTD",
        post_only=False,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    time.sleep(2)
    received.clear()

    # Cancel the order
    rc.cancel_orders(sender=rc.chain.address, subaccount=sub.name, order_ids=[order.id])
    time.sleep(5)

    assert len(received) > 0, "No OrderUpdate received after cancelling order"
    # Find the cancel update
    cancel_updates = []
    for msg in received:
        if msg["e"] == "OrderUpdate":
            for entry in msg.get("data", []):
                if entry.get("status") == "CANCELED":
                    cancel_updates.append(entry)

    assert len(cancel_updates) > 0, "No CANCELED OrderUpdate found"
    rate_limit(2)


def test_ws_raw_order_update_multiple_orders(ws_raw, rc, subaccount_info):
    """Test OrderUpdate receives updates for multiple orders placed in sequence."""
    sub = subaccount_info
    received = []
    ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    time.sleep(1)

    pid = rc.list_products()[0].id
    tick_size = float(rc.products_by_id[pid].tick_size)
    prices = rc.list_market_prices(product_ids=[pid])[0]
    best_bid = float(prices.best_bid_price)

    order_ids = []
    for i in range(3):
        bid_price = safe_round_price(best_bid * (0.75 + i * 0.01), tick_size)
        o = rc.create_order(
            order_type="LIMIT",
            product_id=pid,
            side=0,
            price=bid_price,
            quantity=0.001,
            time_in_force="GTD",
            post_only=False,
            sender=rc.chain.address,
            subaccount=sub.name,
        )
        order_ids.append(o.id)

    time.sleep(5)

    # Should have received updates for all 3 orders
    all_order_ids_in_updates = set()
    for msg in received:
        if msg["e"] == "OrderUpdate":
            for entry in msg.get("data", []):
                if "id" in entry:
                    all_order_ids_in_updates.add(entry["id"])

    for oid in order_ids:
        assert (
            str(oid) in all_order_ids_in_updates or oid in all_order_ids_in_updates
        ), f"Order {oid} not found in OrderUpdate messages"

    # Clean up
    rc.cancel_orders(sender=rc.chain.address, subaccount=sub.name, order_ids=order_ids)
    rate_limit(4)


# ---------------------------------------------------------------------------
# TradeFill + order execution
# ---------------------------------------------------------------------------


def test_ws_raw_trade_fill_on_market_order(ws_raw, rc, subaccount_info):
    """Test that executing a market order produces a TradeFill message."""
    sub = subaccount_info
    received = []
    ws_raw.callbacks["TradeFill"] = [lambda d: received.append(d)]

    pid = rc.list_products()[0].id
    product = rc.products_by_id[pid]
    symbol = product.ticker

    ws_raw.subscribe(stream_type="TradeFill", symbol=symbol)
    time.sleep(1)

    # Submit a small market buy
    order = rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=0,
        quantity=0.001,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    assert order.id is not None
    time.sleep(5)

    assert len(received) > 0, "No TradeFill received after market order"
    msg = received[0]
    assert msg["e"] == "TradeFill"
    assert "data" in msg
    assert isinstance(msg["data"], list)
    assert len(msg["data"]) > 0

    fill = msg["data"][0]
    assert "px" in fill
    assert "sz" in fill
    assert float(fill["px"]) > 0
    assert float(fill["sz"]) > 0

    # Close position
    rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=1,
        quantity=0,
        reduce_only=True,
        close=True,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    rate_limit(2)


def test_ws_raw_order_update_on_market_order_fill(ws_raw, rc, subaccount_info):
    """Test that a market order triggers OrderUpdate with filled status."""
    sub = subaccount_info
    received = []
    ws_raw.callbacks["OrderUpdate"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    time.sleep(1)

    pid = rc.list_products()[0].id

    _order = rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=0,
        quantity=0.001,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    time.sleep(5)

    assert len(received) > 0, "No OrderUpdate received after market order"

    # Look for a FILLED status
    filled_updates = []
    for msg in received:
        if msg["e"] == "OrderUpdate":
            for entry in msg.get("data", []):
                if entry.get("status") == "FILLED":
                    filled_updates.append(entry)

    assert len(filled_updates) > 0, "No FILLED OrderUpdate found after market order"

    # Close position
    rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=1,
        quantity=0,
        reduce_only=True,
        close=True,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    rate_limit(2)


# ---------------------------------------------------------------------------
# Mixed channel subscriptions
# ---------------------------------------------------------------------------


def test_ws_raw_multiple_channel_types(ws_raw, rc, subaccount_info):
    """Test subscribing to multiple channel types simultaneously."""
    sub = subaccount_info
    ticker_msgs = []
    book_msgs = []
    order_msgs = []

    ws_raw.callbacks["Ticker"] = [lambda d: ticker_msgs.append(d)]
    ws_raw.callbacks["L2Book"] = [lambda d: book_msgs.append(d)]
    ws_raw.callbacks["OrderUpdate"] = [lambda d: order_msgs.append(d)]

    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))
    time.sleep(5)

    assert len(ticker_msgs) > 0, "No Ticker messages received"
    assert len(book_msgs) > 0, "No L2Book messages received"
    # OrderUpdate may have no messages if no orders placed, that's ok


def test_ws_raw_l2book_and_ticker_same_symbol(ws_raw):
    """Test L2Book and Ticker for same symbol don't interfere."""
    book_msgs = []
    price_msgs = []

    ws_raw.callbacks["L2Book"] = [lambda d: book_msgs.append(d)]
    ws_raw.callbacks["Ticker"] = [lambda d: price_msgs.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    time.sleep(5)

    assert len(book_msgs) > 0
    assert len(price_msgs) > 0

    # Verify no cross-contamination
    for msg in book_msgs:
        assert msg["e"] == "L2Book"
    for msg in price_msgs:
        assert msg["e"] == "Ticker"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


def test_ws_raw_subscribe_invalid_symbol(ws_raw):
    """Test subscribing to an invalid symbol returns an error."""
    result = ws_raw.subscribe(stream_type="Ticker", symbol="INVALIDUSD")
    assert result.get("ok") is False
    assert "code" in result


def test_ws_raw_subscribe_invalid_type(ws_raw):
    """Test subscribing to an invalid stream type returns an error."""
    result = ws_raw.subscribe(stream_type="NonExistentType", symbol="BTCUSD")
    assert result.get("ok") is False


# ---------------------------------------------------------------------------
# SubaccountLiquidation channel
# ---------------------------------------------------------------------------


def test_ws_raw_subaccount_liquidation_subscribe(ws_raw, rc, subaccount_info):
    """Test subscribing to SubaccountLiquidation returns ok."""
    result = ws_raw.subscribe(
        stream_type="SubaccountLiquidation", subaccountId=str(subaccount_info.id)
    )
    assert result.get("ok") is True


def test_ws_raw_subaccount_liquidation_unsubscribe(ws_raw, rc, subaccount_info):
    """Test unsubscribing from SubaccountLiquidation returns ok."""
    sub_id = str(subaccount_info.id)
    ws_raw.subscribe(stream_type="SubaccountLiquidation", subaccountId=sub_id)
    result = ws_raw.unsubscribe(
        stream_type="SubaccountLiquidation", subaccountId=sub_id
    )
    assert result.get("ok") is True


# ---------------------------------------------------------------------------
# Selective unsubscribe
# ---------------------------------------------------------------------------


def test_ws_raw_unsubscribe_one_of_many(ws_raw):
    """Test unsubscribing from one symbol doesn't affect other subscriptions."""
    btc_msgs = []
    eth_msgs = []

    def handler(d):
        sym = d.get("s")
        if sym == "BTCUSD":
            btc_msgs.append(d)
        elif sym == "ETHUSD":
            eth_msgs.append(d)

    ws_raw.callbacks["L2Book"] = [handler]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="L2Book", symbol="ETHUSD")
    time.sleep(3)

    assert len(btc_msgs) > 0
    assert len(eth_msgs) > 0

    # Unsubscribe only BTC
    ws_raw.unsubscribe(stream_type="L2Book", symbol="BTCUSD")
    btc_msgs.clear()
    eth_msgs.clear()
    time.sleep(3)

    # ETH should still flow, BTC should stop
    assert len(eth_msgs) > 0, "ETH L2Book stopped after unsubscribing BTC"
    assert len(btc_msgs) <= 1, "BTC L2Book still flowing after unsubscribe"


# ---------------------------------------------------------------------------
# Stress / duration tests
# ---------------------------------------------------------------------------


def test_ws_raw_l2book_extended_listen(ws_raw):
    """Test L2Book subscription remains stable over 15 seconds."""
    received = []
    ws_raw.callbacks["L2Book"] = [lambda d: received.append(d)]

    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    time.sleep(15)

    # L2Book sends diffs when the book changes; devnet can be very quiet
    assert len(received) >= 2, (
        f"Expected >= 2 L2Book messages in 15s, got {len(received)}"
    )

    # Verify all messages are well-formed
    for msg in received:
        assert msg["e"] == "L2Book"
        assert msg["s"] == "BTCUSD"
        assert "t" in msg
        assert "a" in msg
        assert "b" in msg


def test_ws_raw_multiple_orderbooks_extended(ws_raw):
    """Test subscribing to multiple orderbooks for an extended period."""
    symbols = ["BTCUSD", "ETHUSD"]
    received = {s: [] for s in symbols}

    def handler(d):
        sym = d.get("s")
        if sym in received:
            received[sym].append(d)

    ws_raw.callbacks["L2Book"] = [handler]

    for sym in symbols:
        ws_raw.subscribe(stream_type="L2Book", symbol=sym)
    time.sleep(15)

    for sym in symbols:
        assert len(received[sym]) >= 3, (
            f"Expected >= 3 L2Book messages for {sym} in 15s, got {len(received[sym])}"
        )
        # Verify timestamps are increasing per symbol
        timestamps = [m["t"] for m in received[sym]]
        for i in range(1, len(timestamps)):
            assert timestamps[i] >= timestamps[i - 1]


def test_ws_raw_all_channels_simultaneously(ws_raw, rc, subaccount_info):
    """Test subscribing to all available channel types at once."""
    sub = subaccount_info
    ticker_msgs = []
    book_msgs = []
    trade_msgs = []
    order_msgs = []

    ws_raw.callbacks["Ticker"] = [lambda d: ticker_msgs.append(d)]
    ws_raw.callbacks["L2Book"] = [lambda d: book_msgs.append(d)]
    ws_raw.callbacks["TradeFill"] = [lambda d: trade_msgs.append(d)]
    ws_raw.callbacks["OrderUpdate"] = [lambda d: order_msgs.append(d)]

    ws_raw.subscribe(stream_type="Ticker", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="Ticker", symbol="ETHUSD")
    ws_raw.subscribe(stream_type="L2Book", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="L2Book", symbol="ETHUSD")
    ws_raw.subscribe(stream_type="TradeFill", symbol="BTCUSD")
    ws_raw.subscribe(stream_type="OrderUpdate", subaccountId=str(sub.id))

    # Place a market order to trigger TradeFill and OrderUpdate
    pid = rc.list_products()[0].id

    _order = rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=0,
        quantity=0.001,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    time.sleep(8)

    assert len(ticker_msgs) > 0, "No Ticker messages"
    assert len(book_msgs) > 0, "No L2Book messages"
    assert len(order_msgs) > 0, "No OrderUpdate messages after market order"
    # TradeFill might or might not come depending on timing

    # Verify message type isolation
    for m in ticker_msgs:
        assert m["e"] == "Ticker"
    for m in book_msgs:
        assert m["e"] == "L2Book"
    for m in order_msgs:
        assert m["e"] == "OrderUpdate"

    # Close position
    rc.create_order(
        order_type="MARKET",
        product_id=pid,
        side=1,
        quantity=0,
        reduce_only=True,
        close=True,
        sender=rc.chain.address,
        subaccount=sub.name,
    )
    rate_limit(2)
