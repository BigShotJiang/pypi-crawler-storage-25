"""WebSocket utilities."""

from typing import Any, Dict
from uuid import UUID


def snake_to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def prepare_params(**kwargs: Any) -> Dict[str, Any]:
    """Convert kwargs from snake_case to camelCase, filtering None values."""
    result = {}
    for key, value in kwargs.items():
        if value is None:
            continue
        if isinstance(value, UUID):
            value = str(value)
        result[snake_to_camel(key)] = value
    return result
