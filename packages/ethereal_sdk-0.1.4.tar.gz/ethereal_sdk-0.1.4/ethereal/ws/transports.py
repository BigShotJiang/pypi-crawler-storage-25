"""WebSocket transport implementations.

This module provides pluggable transport backends for WebSocket connections:
- SocketIOTransport: Socket.IO protocol
- WebSocketTransport: Raw WebSocket protocol
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional
import asyncio
import json
import logging
import threading

import socketio
import websockets
from websockets.asyncio.client import ClientConnection

try:
    import uvloop

    uvloop_enabled = True
except Exception:
    uvloop_enabled = False


def _create_event_loop() -> asyncio.AbstractEventLoop:
    if uvloop_enabled:
        try:
            asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        except Exception:
            pass
    return asyncio.new_event_loop()


class Transport(ABC):
    """Abstract base class for WebSocket transports."""

    def __init__(self, base_url: str, verbose: bool = False):
        self.base_url = base_url
        self.verbose = verbose
        self.logger = logging.getLogger(self.__class__.__name__)
        self.callbacks: Dict[str, List[Callable]] = {}

    @property
    @abstractmethod
    def connected(self) -> bool:
        """Check if transport is connected."""
        pass

    @abstractmethod
    def open(self, namespaces: Optional[List[str]] = None) -> None:
        """Open the connection."""
        pass

    @abstractmethod
    def close(self) -> None:
        """Close the connection."""
        pass

    @abstractmethod
    def send(self, event: str, data: Dict[str, Any], **kwargs: Any) -> Dict[str, Any]:
        """Send an event with data and return the response."""
        pass

    def _dispatch(self, stream_type: str, message: Dict[str, Any]) -> None:
        """Dispatch a message to registered callbacks."""
        if stream_type in self.callbacks:
            for cb in self.callbacks[stream_type]:
                try:
                    cb(message)
                except Exception as e:
                    self.logger.error(f"Callback error for {stream_type}: {e}")


class AsyncTransport(ABC):
    """Abstract base class for async WebSocket transports."""

    def __init__(self, base_url: str, verbose: bool = False):
        self.base_url = base_url
        self.verbose = verbose
        self.logger = logging.getLogger(self.__class__.__name__)
        self.callbacks: Dict[str, List[Callable]] = {}

    @property
    @abstractmethod
    def connected(self) -> bool:
        pass

    @abstractmethod
    async def open(self, namespaces: Optional[List[str]] = None) -> None:
        pass

    @abstractmethod
    async def close(self) -> None:
        pass

    @abstractmethod
    async def send(
        self, event: str, data: Dict[str, Any], **kwargs: Any
    ) -> Dict[str, Any]:
        pass

    async def wait(self) -> None:
        """Wait for the connection to close."""
        pass

    def _dispatch(self, stream_type: str, message: Dict[str, Any]) -> None:
        """Dispatch a message to registered callbacks."""
        if stream_type in self.callbacks:
            for cb in self.callbacks[stream_type]:
                try:
                    if asyncio.iscoroutinefunction(cb):
                        asyncio.create_task(cb(message))
                    else:
                        cb(message)
                except Exception as e:
                    self.logger.error(f"Callback error for {stream_type}: {e}")


class SocketIOTransport(Transport):
    """Socket.IO based WebSocket transport."""

    def __init__(self, base_url: str, verbose: bool = False):
        super().__init__(base_url, verbose)
        self.sio: Optional[socketio.AsyncClient] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.thread: Optional[threading.Thread] = None
        self._loop_ready = threading.Event()

    @property
    def connected(self) -> bool:
        return self.sio is not None and self.sio.connected

    def _run_loop(self) -> None:
        assert self.loop is not None
        asyncio.set_event_loop(self.loop)
        self.sio = socketio.AsyncClient(
            logger=self.verbose, engineio_logger=self.verbose
        )

        @self.sio.event
        async def connect():
            self.logger.info("Connected to server")

        @self.sio.event
        async def disconnect():
            self.logger.info("Disconnected from server")

        @self.sio.on("*", namespace="*")
        async def catch_all(event, namespace, data):
            self.logger.debug(f"Received: {event} in {namespace}")
            self._dispatch(event, data)

        self._loop_ready.set()
        self.loop.run_forever()

    def open(self, namespaces: Optional[List[str]] = None) -> None:
        if not self.loop or self.loop.is_closed():
            self._loop_ready.clear()
            self.loop = _create_event_loop()
            self.thread = threading.Thread(target=self._run_loop, daemon=True)
            self.thread.start()
            self._loop_ready.wait()

        assert self.sio is not None
        future = asyncio.run_coroutine_threadsafe(
            self.sio.connect(
                self.base_url,
                transports=["websocket"],
                namespaces=namespaces,
            ),
            self.loop,
        )
        future.result()

    def close(self) -> None:
        if self.thread and self.loop and not self.loop.is_closed():
            assert self.sio is not None
            asyncio.run_coroutine_threadsafe(self.sio.disconnect(), self.loop).result()
            self.loop.call_soon_threadsafe(self.loop.stop)
            self.thread.join()
            self.loop.close()
            self.loop = None
            self.thread = None
            self.sio = None

    def send(self, event: str, data: Dict[str, Any], **kwargs: Any) -> Dict[str, Any]:
        if not self.loop or self.loop.is_closed() or not self.sio:
            raise RuntimeError("WebSocket is not connected")
        namespace = kwargs.get("namespace")
        future = asyncio.run_coroutine_threadsafe(
            self.sio.emit(event, data, callback=True, namespace=namespace), self.loop
        )
        return future.result()


class AsyncSocketIOTransport(AsyncTransport):
    """Async Socket.IO based WebSocket transport."""

    def __init__(self, base_url: str, verbose: bool = False):
        super().__init__(base_url, verbose)
        self.sio: Optional[socketio.AsyncClient] = None

    @property
    def connected(self) -> bool:
        return self.sio is not None and self.sio.connected

    async def open(self, namespaces: Optional[List[str]] = None) -> None:
        if self.sio is None:
            self.sio = socketio.AsyncClient(
                logger=self.verbose, engineio_logger=self.verbose
            )

            @self.sio.event
            async def connect():
                self.logger.info("Connected to server")

            @self.sio.event
            async def disconnect():
                self.logger.info("Disconnected from server")

            @self.sio.on("*", namespace="*")
            async def catch_all(event, namespace, data):
                self.logger.debug(f"Received: {event} in {namespace}")
                self._dispatch(event, data)

        await self.sio.connect(
            self.base_url,
            transports=["websocket"],
            namespaces=namespaces,
        )

    async def close(self) -> None:
        if self.sio is not None:
            await self.sio.disconnect()

    async def wait(self) -> None:
        if self.sio is not None:
            await self.sio.wait()

    async def send(
        self, event: str, data: Dict[str, Any], **kwargs: Any
    ) -> Dict[str, Any]:
        if self.sio is None:
            raise RuntimeError("WebSocket is not connected")
        namespace = kwargs.get("namespace")
        return await self.sio.emit(event, data, callback=True, namespace=namespace)


WS_PATH = "/v1/stream"


class AsyncWebSocketTransport(AsyncTransport):
    """Async raw WebSocket transport."""

    def __init__(self, base_url: str, verbose: bool = False):
        super().__init__(base_url, verbose)
        self._ws: Optional[ClientConnection] = None
        self._listen_task: Optional[asyncio.Task] = None
        self._pending_acks: Dict[int, asyncio.Future] = {}
        self._message_id = 0

    @property
    def connected(self) -> bool:
        return self._ws is not None and self._ws.state.name == "OPEN"

    async def open(self, namespaces: Optional[List[str]] = None) -> None:
        if self.connected:
            return
        url = f"{self.base_url.rstrip('/')}{WS_PATH}"
        self._ws = await websockets.connect(url)
        self._listen_task = asyncio.create_task(self._listen())
        self.logger.info(f"Connected to {url}")

    async def _listen(self) -> None:
        assert self._ws is not None
        try:
            async for raw in self._ws:
                try:
                    msg = json.loads(raw.decode() if isinstance(raw, bytes) else raw)
                    if "ok" in msg:
                        self._resolve_ack(msg)
                    else:
                        self._dispatch_message(msg)
                except json.JSONDecodeError:
                    self.logger.warning(f"Invalid JSON: {str(raw)[:100]}")
        except websockets.ConnectionClosed as e:
            self.logger.info(f"Connection closed: {e.code} {e.reason}")
        except asyncio.CancelledError:
            pass

    def _resolve_ack(self, ack: Dict[str, Any]) -> None:
        if not self._pending_acks:
            return
        msg_id = min(self._pending_acks.keys())
        future = self._pending_acks.pop(msg_id)
        future.set_result(ack)

    def _dispatch_message(self, message: Dict[str, Any]) -> None:
        event = message.get("e")
        if event:
            self._dispatch(event, message)

    async def close(self) -> None:
        if self._listen_task:
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass
            self._listen_task = None
        if self._ws:
            await self._ws.close()
            self._ws = None
        for future in self._pending_acks.values():
            if not future.done():
                future.cancel()
        self._pending_acks.clear()
        self.logger.info("Disconnected")

    async def wait(self) -> None:
        if self._listen_task:
            await self._listen_task

    async def send(self, event: str, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        if not self._ws:
            raise RuntimeError("WebSocket is not connected")

        timeout = kwargs.get("timeout", 10.0)
        self._message_id += 1
        future: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending_acks[self._message_id] = future
        await self._ws.send(json.dumps({"event": event, "data": data}))
        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            self._pending_acks.pop(self._message_id, None)
            raise


class WebSocketTransport(Transport):
    """Sync wrapper around AsyncWebSocketTransport."""

    def __init__(self, base_url: str, verbose: bool = False):
        self._async = AsyncWebSocketTransport(base_url, verbose)
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._loop_ready = threading.Event()
        self.base_url = base_url
        self.verbose = verbose
        self.logger = logging.getLogger(self.__class__.__name__)

    @property
    def connected(self) -> bool:
        return self._async.connected

    @property
    def callbacks(self) -> Dict[str, List[Callable]]:
        return self._async.callbacks

    @callbacks.setter
    def callbacks(self, value: Dict[str, List[Callable]]) -> None:
        self._async.callbacks = value

    def _ensure_loop(self) -> None:
        if self._loop and not self._loop.is_closed():
            return
        self._loop_ready.clear()
        self._loop = _create_event_loop()

        def run_loop():
            asyncio.set_event_loop(self._loop)
            self._loop_ready.set()
            self._loop.run_forever()

        self._thread = threading.Thread(target=run_loop, daemon=True)
        self._thread.start()
        self._loop_ready.wait()

    def open(self, namespaces: Optional[List[str]] = None) -> None:
        if self.connected:
            return
        self._ensure_loop()
        assert self._loop is not None
        asyncio.run_coroutine_threadsafe(
            self._async.open(namespaces), self._loop
        ).result()

    def close(self) -> None:
        if not self._loop or self._loop.is_closed():
            return
        asyncio.run_coroutine_threadsafe(self._async.close(), self._loop).result(
            timeout=5
        )
        self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=5)
        self._loop.close()
        self._loop = None
        self._thread = None

    def send(self, event: str, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        if not self._loop or self._loop.is_closed():
            raise RuntimeError("WebSocket is not connected")
        return asyncio.run_coroutine_threadsafe(
            self._async.send(event, data, **kwargs), self._loop
        ).result()
