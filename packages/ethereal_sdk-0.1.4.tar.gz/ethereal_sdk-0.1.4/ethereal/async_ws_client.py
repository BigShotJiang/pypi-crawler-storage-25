"""Ethereal async WebSocket client."""

from typing import Any, Callable, Dict, List, Optional, Union

from ethereal.base_client import BaseClient
from ethereal.models.config import WSConfig
from ethereal.ws.transports import (
    AsyncTransport,
    AsyncSocketIOTransport,
    AsyncWebSocketTransport,
)
from ethereal.ws.utils import prepare_params


class AsyncWSClient(BaseClient):
    """Ethereal async WebSocket client.

    Supports both Socket.IO and raw WebSocket transports via pluggable backends.

    Args:
        config: Configuration dictionary or WSConfig object.
            - base_url (str): Base URL for websocket requests
            - verbose (bool): Enables debug logging (default: False)
            - transport (str): 'socketio' or 'websocket' (default: 'socketio')
    """

    config: WSConfig

    def __init__(self, config: Union[Dict[str, Any], WSConfig]):
        super().__init__(config)
        self.config = WSConfig.model_validate(config)
        self._transport = self._create_transport()

    def _create_transport(self) -> AsyncTransport:
        """Create the appropriate transport based on config."""
        base_url = str(self.config.base_url)
        verbose = self.config.verbose

        if self.config.transport == "socketio":
            return AsyncSocketIOTransport(base_url, verbose)
        else:
            return AsyncWebSocketTransport(base_url, verbose)

    @property
    def connected(self) -> bool:
        """Check if the WebSocket is connected."""
        return self._transport.connected

    @property
    def callbacks(self) -> Dict[str, List[Callable]]:
        """Access callbacks on the transport."""
        return self._transport.callbacks

    @callbacks.setter
    def callbacks(self, value: Dict[str, List[Callable]]) -> None:
        self._transport.callbacks = value

    async def open(self, namespaces: Optional[List[str]] = None) -> None:
        """Open the WebSocket connection.

        Args:
            namespaces: Socket.IO namespaces to connect to (socketio transport only)
        """
        await self._transport.open(namespaces)

    async def close(self) -> None:
        """Close the WebSocket connection."""
        await self._transport.close()

    async def wait(self) -> None:
        """Wait for the connection to close."""
        await self._transport.wait()

    async def subscribe(
        self,
        stream_type: str,
        *,
        namespace: str = "/v1/stream",
        **params,
    ) -> Dict[str, Any]:
        """Subscribe to a stream.

        Args:
            stream_type: Type of stream (e.g., "L2Book", "Ticker", "OrderFill")
            namespace: Socket.IO namespace (socketio transport only)
            **params: Subscription parameters (snake_case converted to camelCase)
                - symbol: Product symbol (e.g., "BTCUSD")
                - subaccount_id: Subaccount ID for account-specific streams
                - product_id: Product ID
        """
        data = {"type": stream_type, **prepare_params(**params)}
        return await self._transport.send("subscribe", data, namespace=namespace)

    async def unsubscribe(
        self,
        stream_type: str,
        *,
        namespace: str = "/v1/stream",
        **params,
    ) -> Dict[str, Any]:
        """Unsubscribe from a stream.

        Args:
            stream_type: Type of stream
            namespace: Socket.IO namespace (socketio transport only)
            **params: Unsubscription parameters (snake_case converted to camelCase)
        """
        data = {"type": stream_type, **prepare_params(**params)}
        return await self._transport.send("unsubscribe", data, namespace=namespace)
