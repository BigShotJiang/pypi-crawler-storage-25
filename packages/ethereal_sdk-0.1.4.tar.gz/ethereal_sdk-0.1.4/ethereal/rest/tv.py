from typing import TYPE_CHECKING, Dict, Any, List

from ethereal.constants import API_PREFIX

if TYPE_CHECKING:
    from ethereal.models.tv import (
        ConfigDto,
        HistoryResponseDto,
        SymbolInfoDto,
        SymbolSearchResultDto,
    )


# ---------------------------------------------------------------------------
# Last Price endpoints
# ---------------------------------------------------------------------------


async def get_last_price_config(self, **kwargs) -> "ConfigDto":
    """Gets the TradingView UDF configuration for last-price data.

    Returns:
        ConfigDto: UDF configuration including supported resolutions and symbol types.
    """
    res = await self.get(
        f"{API_PREFIX}/last-price/config",
        base_url_override=self._tv_base_url,
        **kwargs,
    )
    return self._tv_models.ConfigDto(**res)


async def get_last_price_symbol(self, **kwargs) -> "SymbolInfoDto":
    """Resolves symbol information by ticker for last-price data.

    Args:
        symbol (str): Symbol ticker in the format {ticker}-{type} (e.g. 'ETHUSD-Perp'). Required.

    Returns:
        SymbolInfoDto: Detailed symbol information.
    """
    res = await self.get_validated(
        url_path=f"{API_PREFIX}/last-price/symbols",
        request_model=self._tv_models.V1LastPriceSymbolsGetParametersQuery,
        response_model=self._tv_models.SymbolInfoDto,
        base_url_override=self._tv_base_url,
        **kwargs,
    )
    return res


async def search_last_price_symbols(self, **kwargs) -> List["SymbolSearchResultDto"]:
    """Searches for symbols in the last-price data feed.

    Args:
        query (str): Search query string to match against symbol tickers. Required.

    Other Parameters:
        type (str, optional): Filter results by symbol type ('Perp' or 'Spot'). Defaults to 'Perp'.
        limit (int, optional): Maximum number of results (1-50). Optional.

    Returns:
        List[SymbolSearchResultDto]: Matching symbol search results.
    """
    validated_params = (
        self._tv_models.V1LastPriceSearchGetParametersQuery.model_validate(
            kwargs, by_name=True
        )
    )
    params = validated_params.model_dump(mode="json", exclude_none=True, by_alias=True)
    if "limit" in params:
        params["limit"] = int(params["limit"])
    res = await self.get(
        f"{API_PREFIX}/last-price/search",
        params=params,
        base_url_override=self._tv_base_url,
    )
    return [self._tv_models.SymbolSearchResultDto(**item) for item in res]


async def get_last_price_history(self, **kwargs) -> "HistoryResponseDto":
    """Gets OHLCV bar history for a symbol using last-price data.

    Args:
        symbol (str): Symbol ticker in the format {ticker}-{type} (e.g. 'ETHUSD-Perp'). Required.
        resolution (str): Bar resolution (e.g. '1', '5', '15', '60', '1D'). Required.
        from_ (float): Start of time range in seconds since Unix epoch. Required.
        to (float): End of time range in seconds since Unix epoch. Required.

    Other Parameters:
        countback (int, optional): Maximum number of bars to return (1-4000). Optional.

    Returns:
        HistoryResponseDto: OHLCV bar data with status.
    """
    res = await self.get_validated(
        url_path=f"{API_PREFIX}/last-price/history",
        request_model=self._tv_models.V1LastPriceHistoryGetParametersQuery,
        response_model=self._tv_models.HistoryResponseDto,
        base_url_override=self._tv_base_url,
        **kwargs,
    )
    return res


async def get_last_price_time(self, **kwargs) -> Dict[str, Any]:
    """Gets the current server time from the last-price data feed.

    Returns:
        dict: Server time response.
    """
    return await self.get(
        f"{API_PREFIX}/last-price/time",
        base_url_override=self._tv_base_url,
        **kwargs,
    )


# ---------------------------------------------------------------------------
# Oracle Price endpoints
# ---------------------------------------------------------------------------


async def get_oracle_price_config(self, **kwargs) -> "ConfigDto":
    """Gets the TradingView UDF configuration for oracle-price data.

    Returns:
        ConfigDto: UDF configuration including supported resolutions and symbol types.
    """
    res = await self.get(
        f"{API_PREFIX}/oracle-price/config",
        base_url_override=self._tv_base_url,
        **kwargs,
    )
    return self._tv_models.ConfigDto(**res)


async def get_oracle_price_symbol(self, **kwargs) -> "SymbolInfoDto":
    """Resolves symbol information by ticker for oracle-price data.

    Args:
        symbol (str): Symbol ticker in the format {ticker}-{type} (e.g. 'ETHUSD-Perp'). Required.

    Returns:
        SymbolInfoDto: Detailed symbol information.
    """
    res = await self.get_validated(
        url_path=f"{API_PREFIX}/oracle-price/symbols",
        request_model=self._tv_models.V1OraclePriceSymbolsGetParametersQuery,
        response_model=self._tv_models.SymbolInfoDto,
        base_url_override=self._tv_base_url,
        **kwargs,
    )
    return res


async def search_oracle_price_symbols(self, **kwargs) -> List["SymbolSearchResultDto"]:
    """Searches for symbols in the oracle-price data feed.

    Args:
        query (str): Search query string to match against symbol tickers. Required.

    Other Parameters:
        type (str, optional): Filter results by symbol type ('Perp' or 'Spot'). Defaults to 'Perp'.
        limit (int, optional): Maximum number of results (1-50). Optional.

    Returns:
        List[SymbolSearchResultDto]: Matching symbol search results.
    """
    validated_params = (
        self._tv_models.V1OraclePriceSearchGetParametersQuery.model_validate(
            kwargs, by_name=True
        )
    )
    params = validated_params.model_dump(mode="json", exclude_none=True, by_alias=True)
    if "limit" in params:
        params["limit"] = int(params["limit"])
    res = await self.get(
        f"{API_PREFIX}/oracle-price/search",
        params=params,
        base_url_override=self._tv_base_url,
    )
    return [self._tv_models.SymbolSearchResultDto(**item) for item in res]


async def get_oracle_price_history(self, **kwargs) -> "HistoryResponseDto":
    """Gets OHLCV bar history for a symbol using oracle-price data.

    Args:
        symbol (str): Symbol ticker in the format {ticker}-{type} (e.g. 'ETHUSD-Perp'). Required.
        resolution (str): Bar resolution (e.g. '1', '5', '15', '60', '1D'). Required.
        from_ (float): Start of time range in seconds since Unix epoch. Required.
        to (float): End of time range in seconds since Unix epoch. Required.

    Other Parameters:
        countback (int, optional): Maximum number of bars to return (1-4000). Optional.

    Returns:
        HistoryResponseDto: OHLCV bar data with status.
    """
    res = await self.get_validated(
        url_path=f"{API_PREFIX}/oracle-price/history",
        request_model=self._tv_models.V1OraclePriceHistoryGetParametersQuery,
        response_model=self._tv_models.HistoryResponseDto,
        base_url_override=self._tv_base_url,
        **kwargs,
    )
    return res


async def get_oracle_price_time(self, **kwargs) -> Dict[str, Any]:
    """Gets the current server time from the oracle-price data feed.

    Returns:
        dict: Server time response.
    """
    return await self.get(
        f"{API_PREFIX}/oracle-price/time",
        base_url_override=self._tv_base_url,
        **kwargs,
    )
