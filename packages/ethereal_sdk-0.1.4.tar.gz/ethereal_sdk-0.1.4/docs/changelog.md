# Changelog

## Ethereal SDK v0.1.3 (2026-03-19)

### Types
- Synced all Pydantic models with the latest OpenAPI spec from the exchange

## Ethereal SDK v0.1.2 (2026-03-10)

### WebSocket Transport
- Added a new raw WebSocket transport using the `websockets` library, connecting to `ws2.ethereal.trade`. To enable this, specify `transport: "websocket"` in your WS client config
- The existing Socket.IO transport (`ws.ethereal.trade`) remains the default

### Other
- Synced all Pydantic models with the latest OpenAPI spec from the exchange
- Bug: Product cache now properly invalidates cached lookups (`products_by_ticker`, `products_by_id`) when `refresh=True` is specified

## Ethereal SDK v0.1.1 (2026-03-03)

### Types
- Synced Pydantic models with the latest OpenAPI spec from the exchange

## Ethereal SDK v0.1.0 (2026-01-20)

### REST Client
- Sync and async REST clients with full coverage of the Ethereal exchange API (orders, positions, products, funding, etc.) See the [API Docs](https://api.ethereal.trade/docs) for more information
- Order support including market/limit orders, stop orders, OCO/OTO, replace, cancel, and order dry runs
- Product cache with products_by_ticker and products_by_id lookups
- Archive endpoint support for historical balance and PnL data
- Multi-network support: mainnet, testnet, and devnet

### WebSocket Client
- Sync and async WebSocket clients using Socket.IO (`ws.ethereal.trade`)
- Subscribe to real-time BookDepth and OrderFill streams

### Chain Client
- Onchain operations on Ethereal: deposit USDe, finalize withdrawals, link/revoke/refresh signers
- EIP-712 typed data signing for orders, withdrawals, and signer operations

### Other
- Pydantic models generated from the exchange OpenAPI spec
- `uvloop` support on Unix platforms
