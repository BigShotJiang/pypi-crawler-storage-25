# WebSockets

Real-time market data and order updates via WebSocket streams.

The SDK supports two transports:

| | WebSocket (default) | Socket.IO |
|---|---|---|
| Config | `transport: "websocket"` | `transport: "socketio"` |
| `open()` | No arguments needed | Requires `namespaces=["/", "/v1/stream"]` |
| URLs | `wss://ws2.ethereal.trade` | `wss://ws.ethereal.trade` |

All code samples use `AsyncWSClient`. A synchronous `WSClient` is also available with the same API.

For available stream types, parameters, and message formats, see the [official documentation](https://docs.ethereal.trade/developer-guides/trading-api/websocket-gateway).

## WebSocket transport

```python
import asyncio
from ethereal import AsyncWSClient

async def main():
    ws = AsyncWSClient({
        "base_url": "wss://ws2.ethereal.trade",
        "transport": "websocket",
    })
    await ws.open()

    async def on_ticker(data):
        print(f"Ticker: {data}")

    ws.callbacks["Ticker"] = [on_ticker]
    await ws.subscribe(stream_type="Ticker", symbol="BTCUSD")

    # Keep the connection open until disconnected
    await ws.wait()

asyncio.run(main())
```

## Subscribe to multiple streams

```python
async def setup_streams(ws):
    ws.callbacks["Ticker"] = [lambda d: print(f"Ticker: {d}")]
    ws.callbacks["L2Book"] = [lambda d: print(f"Book: {d}")]

    await ws.subscribe(stream_type="Ticker", symbol="BTCUSD")
    await ws.subscribe(stream_type="L2Book", symbol="BTCUSD")
```

## Account-specific streams

!!! warn "Account Required"
    Requires at least one subaccount. See [Creating Accounts](../examples/account_management.md#creating-accounts) if needed.

```python
from ethereal import AsyncWSClient, AsyncRESTClient

async def main():
    rest = await AsyncRESTClient.create({
        "base_url": "https://api.ethereal.trade",
        "chain_config": {
            "rpc_url": "https://rpc.ethereal.trade",
            "private_key": "your_private_key",
        }
    })
    subaccounts = await rest.subaccounts()
    subaccount_id = str(subaccounts[0].id)
    await rest.close()

    ws = AsyncWSClient({
        "base_url": "wss://ws2.ethereal.trade",
        "transport": "websocket",
    })
    await ws.open()

    ws.callbacks["OrderUpdate"] = [lambda d: print(f"Order: {d}")]
    await ws.subscribe(stream_type="OrderUpdate", subaccountId=subaccount_id)

    await ws.wait()
```

## Connection management

```python
await ws.close()     # Close the connection
await ws.open()      # Reconnect
```

## Socket.IO transport

The Socket.IO transport uses different stream names and subscription parameters — see the [official docs](https://docs.ethereal.trade/developer-guides/trading-api/websocket-gateway) for details.

```python
ws = AsyncWSClient({
    "base_url": "wss://ws.ethereal.trade",
    "transport": "socketio",
})
await ws.open(namespaces=["/", "/v1/stream"])

# Socket.IO uses different stream names (e.g. "BookDepth" instead of "L2Book")
# and product_id (UUID) instead of symbol (ticker)
ws.callbacks["BookDepth"] = [lambda d: print(d)]
await ws.subscribe(stream_type="BookDepth", product_id=btc_product_id)

await ws.close()
```
