# Link Signers

Link a delegate signer that can submit orders on behalf of your account (per subaccount). See the Ethereal docs for more information about linked signers.

## Simple method

```python
from ethereal import AsyncRESTClient
from eth_account import Account

client = await AsyncRESTClient.create(config)  # config must include a private key
sub = await client.get_subaccount(id=subaccount_id)
signer = Account.create()  # example only; if you lose this key you lose the signer

linked = await client.link_signer(
    signer=signer.address,
    subaccount_id=sub.id,
    subaccount=sub.name,
    signer_private_key=signer.key,
)
```

## Sign the message yourself

You can build the message and sign it with any tool you like. The payload to sign is `link.data`.

```python
link = await client.prepare_linked_signer(
    sender=client.chain.address,
    signer=signer.address,
    subaccount=sub.name,
    subaccount_id=sub.id,
)

# Update link.signature or link.signer_signature by signing link.data
```

## Full manual flow

```python
link = await client.prepare_linked_signer(
    sender=client.chain.address,
    signer=signer.address,
    subaccount=sub.name,
    subaccount_id=sub.id,
)
link = await client.sign_linked_signer(link)  # owner signature
link = await client.sign_linked_signer(link, signer_private_key=signer.key)  # signer signature
result = await client.link_linked_signer(link)
```

To remove a delegate, call `revoke_linked_signer` (or use the UI): prepare -> sign -> revoke.

## Control signing and submission

You can skip automatic signing and submission, edit the signatures yourself, then send it.

```python
# Build the payload but do not sign or submit
link = await client.link_signer(
    signer=signer.address,
    subaccount_id=sub.id,
    subaccount=sub.name,
    sign_sender=False,
    sign_signer=False,
    submit=False,
)

# Add signatures (either with SDK helpers or any signer you have)
link = await client.sign_linked_signer(link)  # owner signature from client key
link.signer_signature = your_signer_signature  # set manually if you signed elsewhere

# Submit when ready
result = await client.link_linked_signer(link)
```

To remove a delegate with the helper, call `client.revoke_signer(...)` (supports `sign` and `submit` flags just like `link_signer`). Example:

```python
revoke = await client.revoke_signer(
    signer=signer.address,
    subaccount_id=sub.id,
    subaccount=sub.name,
    submit=False,  # inspect or adjust before sending
)
revoke = await client.sign_revoke_linked_signer(revoke)  # if you skipped signing
await client.revoke_linked_signer(revoke)
```
