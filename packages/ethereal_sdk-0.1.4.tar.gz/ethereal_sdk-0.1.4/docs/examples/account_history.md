# Account History Examples

Examples of querying historical account data from the Ethereal archive API. For the full list of available endpoints and parameters, see the [Archive API documentation](https://archive.ethereal.trade/docs).

All examples assume you have an initialized `AsyncRESTClient` with a private key. See the [Quickstart](../guides/quickstart.md) if you need help setting one up.

## Balance history

```python
import time

subaccounts = await client.subaccounts()
subaccount_id = subaccounts[0].id

now = time.time() * 1000              # Archive API uses milliseconds
one_week_ago = now - 7 * 86400 * 1000

history = await client.get_subaccount_balance_history(
    subaccount_id=subaccount_id,
    start_time=one_week_ago,
    end_time=now,
    resolution="hour1",
)

for record in history:
    print(record.model_dump())
```

## Funding history

```python
funding = await client.get_subaccount_funding_history(
    subaccount_id=subaccount_id,
    start_time=one_week_ago,
)

for record in funding:
    print(f"{record.product_ticker}: {record.funding_charge}")
```

You can filter funding history by specific products or positions:

```python
funding = await client.get_subaccount_funding_history(
    subaccount_id=subaccount_id,
    start_time=one_week_ago,
    product_ids=[btc_product_id],    # Filter by product
)
```

## Total volume

```python
total = await client.get_subaccount_total_volume(subaccount_id=subaccount_id)
print(f"Total volume: ${total.volume_usd}")
```
