# Market Data Examples

This page provides examples of accessing market data with the Ethereal Python SDK.

## Setup

All examples on this page use the `AsyncRESTClient`. Here's the basic pattern:

```python
import asyncio
from ethereal import AsyncRESTClient

async def main():
    # Initialize client (no private key needed for market data)
    client = await AsyncRESTClient.create({
        "base_url": "https://api.ethereal.trade",
    })

    # Your code here

    await client.close()

asyncio.run(main())
```

The examples below show the code that goes in the "Your code here" section. For a complete standalone example, see [List all products](#list-all-products).

## List all products

This complete example shows the full pattern including imports, initialization, and cleanup:

```python
import asyncio
from ethereal import AsyncRESTClient

async def list_products():
    client = await AsyncRESTClient.create({
        "base_url": "https://api.ethereal.trade",
    })

    # Get all available products
    products = await client.list_products()

    for product in products:
        print(product.model_dump())

    await client.close()

asyncio.run(list_products())
```

## Get market prices

```python
products = await client.products()
product_ids = [product.id for product in products]
prices = await client.list_market_prices(product_ids=product_ids)

for price in prices:
    print(price.model_dump())
```

## Access order book data

```python
# Get market liquidity (order book data)
products_by_ticker = await client.products_by_ticker()
btc_id = products_by_ticker['BTCUSD'].id
liquidity = await client.get_market_liquidity(product_id=btc_id)

# Display top 5 bids
print("Top bids:")
for level in liquidity.bids[:5]:
    print(f"Price: {level[0]}, Size: {level[1]}")

# Display top 5 asks
print("Top asks:")
for level in liquidity.asks[:5]:
    print(f"Price: {level[0]}, Size: {level[1]}")
```

## Calculate market metrics

```python
# Calculate mid price
def calculate_mid_price(liquidity):
    if not liquidity.bids or not liquidity.asks:
        return None
    best_bid = float(liquidity.bids[0][0])
    best_ask = float(liquidity.asks[0][0])
    return (best_bid + best_ask) / 2

# Calculate spread
def calculate_spread(liquidity):
    if not liquidity.bids or not liquidity.asks:
        return None
    best_bid = float(liquidity.bids[0][0])
    best_ask = float(liquidity.asks[0][0])
    return best_ask - best_bid

# Get liquidity for BTC-USD
products_by_ticker = await client.products_by_ticker()
btc_id = products_by_ticker['BTCUSD'].id
liquidity = await client.get_market_liquidity(product_id=btc_id)

# Calculate metrics
mid_price = calculate_mid_price(liquidity)
spread = calculate_spread(liquidity)

print(f"Mid price: {mid_price}")
print(f"Spread: {spread}")
```
