# TradingView Data Examples

Examples of accessing TradingView-compatible price data. The TradingView API exposes two data feeds: **last price** (most recent trade price) and **oracle price** (oracle-derived price), both following the TradingView UDF protocol. For the full list of available endpoints and parameters, see the [TradingView API documentation](https://tradingview.ethereal.trade/docs).

All examples assume you have an initialized `AsyncRESTClient`. See the [Quickstart](../guides/quickstart.md) if you need help setting one up.

## Search for symbols

```python
# Search for ETH-related symbols
results = await client.search_last_price_symbols(query="ETH")

for result in results:
    print(result.model_dump())
```

You can filter results by type and limit the number of results:

```python
results = await client.search_last_price_symbols(
    query="BTC",
    type="Perp",   # 'Perp' or 'Spot'
    limit=5,       # Max results (1-50)
)

for result in results:
    print(f"{result.ticker}: {result.description}")
```

## Resolve symbol information

```python
symbol_info = await client.get_last_price_symbol(symbol="ETHUSD-Perp")

print(f"Name: {symbol_info.name}")
print(f"Ticker: {symbol_info.ticker}")
print(f"Description: {symbol_info.description}")
print(f"Price scale: {symbol_info.pricescale}")
print(f"Intraday multipliers: {symbol_info.intraday_multipliers}")
```

## Get OHLCV bar history

```python
import time

now = time.time()
one_day_ago = now - 86400  # 24 hours in seconds

# Fetch 1-hour bars for the last 24 hours
history = await client.get_last_price_history(
    symbol="ETHUSD-Perp",
    resolution="60",         # Bar size in minutes (or '1D', '1W', '1M')
    from_=one_day_ago,       # Start time (seconds since Unix epoch)
    to=now,                  # End time (seconds since Unix epoch)
)

if history.s == "ok" and history.t:
    for i in range(len(history.t)):
        print(
            f"Time: {history.t[i]}, "
            f"O: {history.o[i]}, H: {history.h[i]}, "
            f"L: {history.l[i]}, C: {history.c[i]}, "
            f"V: {history.v[i]}"
        )
```

You can also use `countback` to request a specific number of bars:

```python
# Get the last 100 daily bars
history = await client.get_last_price_history(
    symbol="BTCUSD-Perp",
    resolution="1D",
    from_=0,
    to=time.time(),
    countback=100,           # Max bars to return (1-4000)
)
```

### Supported resolutions

| Minutes | Daily | Weekly/Monthly |
|---------|-------|----------------|
| `1`, `5`, `15`, `30`, `60`, `120`, `240`, `480`, `720` | `1D`, `3D` | `1W`, `1M` |

## Oracle price data

All of the examples above use the **last price** feed. The SDK provides matching methods for the **oracle price** feed, which reflects oracle-derived pricing:

```python
config = await client.get_oracle_price_config()
symbol_info = await client.get_oracle_price_symbol(symbol="ETHUSD-Perp")
results = await client.search_oracle_price_symbols(query="ETH")
history = await client.get_oracle_price_history(
    symbol="ETHUSD-Perp",
    resolution="60",
    from_=one_day_ago,
    to=now,
)
```

## Get feed configuration

```python
config = await client.get_last_price_config()

print(f"Supported resolutions: {config.supported_resolutions}")
print(f"Symbol types: {[st.name for st in config.symbol_types]}")
print(f"Supports search: {config.supports_search}")
```

## Get server time

```python
server_time = await client.get_last_price_time()
print(server_time)
```
