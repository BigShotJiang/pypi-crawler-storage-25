# Parallect Client

```bash
pip install -e ./parallect-client
parallect login --api-url http://localhost:3000
parallect start --once
```

The client detects the local machine, registers a worker, claims one shard at a
time, processes it, submits proof, and repeats.

