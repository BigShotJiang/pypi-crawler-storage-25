from __future__ import annotations

import base64
import gzip
import hashlib
import importlib
import json
import subprocess
import sys
from dataclasses import dataclass
from io import BytesIO
from typing import Any


@dataclass(frozen=True)
class TinyTransformerConfig:
    vocab_size: int = 256
    block_size: int = 256
    n_layer: int = 4
    n_head: int = 4
    n_embd: int = 256
    dropout: float = 0.0
    seed: int = 1337


def train_bytes(data: bytes, seed: int = 1337) -> dict[str, Any]:
    torch = ensure_torch_installed()
    model = create_random_model(torch, TinyTransformerConfig(seed=seed))
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4)
    tokens = torch.tensor(list(data[: model.config.block_size + 1]), dtype=torch.long, device=device)
    if tokens.numel() < 2:
        tokens = torch.tensor([0, 1], dtype=torch.long, device=device)

    x = tokens[:-1].unsqueeze(0)
    y = tokens[1:].unsqueeze(0)

    model.train()
    with torch.no_grad():
        _, before = model(x, y)
    optimizer.zero_grad(set_to_none=True)
    _, loss = model(x, y)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    optimizer.step()
    with torch.no_grad():
        _, after = model(x, y)

    state_bytes = serialize_state_dict(torch, model.state_dict())
    return {
        "tokens_processed": int(tokens.numel()),
        "loss_before": float(before.detach().cpu()),
        "loss_after": float(after.detach().cpu()),
        "update_hash": "sha256:" + hashlib.sha256(state_bytes).hexdigest(),
        "proof_hash": "sha256:" + hashlib.sha256(data + state_bytes[:1024]).hexdigest(),
        "artifacts": {
            "state_format": "torch_state_dict_gzip_base64",
            "state_dict_gzip_base64": base64.b64encode(gzip.compress(state_bytes)).decode("ascii"),
            "seed": seed,
            "model_config": {
                "vocab_size": model.config.vocab_size,
                "block_size": model.config.block_size,
                "n_layer": model.config.n_layer,
                "n_head": model.config.n_head,
                "n_embd": model.config.n_embd,
                "dropout": model.config.dropout,
                "seed": model.config.seed,
            },
        },
    }


def ensure_torch_installed():
    try:
        return importlib.import_module("torch")
    except ImportError:
        print("training mode selected; installing torch runtime for this machine...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "torch>=2.2"])
        return importlib.import_module("torch")


def serialize_state_dict(torch, state_dict) -> bytes:
    buffer = BytesIO()
    cpu_state = {name: tensor.detach().cpu() for name, tensor in state_dict.items()}
    torch.save(cpu_state, buffer)
    return buffer.getvalue()


def create_random_model(torch, config: TinyTransformerConfig):
    from torch import nn
    from torch.nn import functional as F

    class CausalSelfAttention(nn.Module):
        def __init__(self, inner_config: TinyTransformerConfig):
            super().__init__()
            assert inner_config.n_embd % inner_config.n_head == 0
            self.n_head = inner_config.n_head
            self.head_dim = inner_config.n_embd // inner_config.n_head
            self.c_attn = nn.Linear(inner_config.n_embd, 3 * inner_config.n_embd)
            self.c_proj = nn.Linear(inner_config.n_embd, inner_config.n_embd)
            self.dropout = nn.Dropout(inner_config.dropout)
            self.register_buffer(
                "bias",
                torch.tril(torch.ones(inner_config.block_size, inner_config.block_size)).view(
                    1, 1, inner_config.block_size, inner_config.block_size
                ),
                persistent=False,
            )

        def forward(self, x):
            batch, tokens, channels = x.size()
            q, k, v = self.c_attn(x).split(channels, dim=2)
            q = q.view(batch, tokens, self.n_head, self.head_dim).transpose(1, 2)
            k = k.view(batch, tokens, self.n_head, self.head_dim).transpose(1, 2)
            v = v.view(batch, tokens, self.n_head, self.head_dim).transpose(1, 2)
            att = (q @ k.transpose(-2, -1)) * (1.0 / (k.size(-1) ** 0.5))
            att = att.masked_fill(self.bias[:, :, :tokens, :tokens] == 0, float("-inf"))
            att = F.softmax(att, dim=-1)
            att = self.dropout(att)
            y = att @ v
            y = y.transpose(1, 2).contiguous().view(batch, tokens, channels)
            return self.c_proj(y)

    class Block(nn.Module):
        def __init__(self, inner_config: TinyTransformerConfig):
            super().__init__()
            self.ln_1 = nn.LayerNorm(inner_config.n_embd)
            self.attn = CausalSelfAttention(inner_config)
            self.ln_2 = nn.LayerNorm(inner_config.n_embd)
            self.mlp = nn.Sequential(
                nn.Linear(inner_config.n_embd, 4 * inner_config.n_embd),
                nn.GELU(),
                nn.Linear(4 * inner_config.n_embd, inner_config.n_embd),
                nn.Dropout(inner_config.dropout),
            )

        def forward(self, x):
            x = x + self.attn(self.ln_1(x))
            return x + self.mlp(self.ln_2(x))

    class TinyTransformer(nn.Module):
        def __init__(self, inner_config: TinyTransformerConfig):
            super().__init__()
            self.config = inner_config
            self.token_embedding = nn.Embedding(inner_config.vocab_size, inner_config.n_embd)
            self.position_embedding = nn.Embedding(inner_config.block_size, inner_config.n_embd)
            self.blocks = nn.ModuleList(Block(inner_config) for _ in range(inner_config.n_layer))
            self.ln_f = nn.LayerNorm(inner_config.n_embd)
            self.lm_head = nn.Linear(inner_config.n_embd, inner_config.vocab_size, bias=False)
            self.token_embedding.weight = self.lm_head.weight
            self.apply(self._init_weights)

        def _init_weights(self, module):
            if isinstance(module, nn.Linear):
                torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
                if module.bias is not None:
                    torch.nn.init.zeros_(module.bias)
            elif isinstance(module, nn.Embedding):
                torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

        def forward(self, idx, targets=None):
            _, tokens = idx.size()
            if tokens > self.config.block_size:
                raise ValueError("sequence length exceeds block size")
            pos = torch.arange(0, tokens, dtype=torch.long, device=idx.device)
            x = self.token_embedding(idx) + self.position_embedding(pos)
            for block in self.blocks:
                x = block(x)
            logits = self.lm_head(self.ln_f(x))
            loss = None
            if targets is not None:
                loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))
            return logits, loss

    torch.manual_seed(config.seed)
    return TinyTransformer(config)
