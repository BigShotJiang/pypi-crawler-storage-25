from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path


CONFIG_DIR = Path.home() / ".parallect"
CONFIG_PATH = CONFIG_DIR / "config.json"


@dataclass
class ClientConfig:
    api_url: str
    token: str


def load_config() -> ClientConfig:
    if not CONFIG_PATH.exists():
        raise SystemExit("Not logged in. Run `parallect login` first.")

    data = json.loads(CONFIG_PATH.read_text())
    return ClientConfig(api_url=data["api_url"], token=data["token"])


def save_config(config: ClientConfig) -> None:
    CONFIG_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(asdict(config), indent=2))
    CONFIG_PATH.chmod(0o600)

