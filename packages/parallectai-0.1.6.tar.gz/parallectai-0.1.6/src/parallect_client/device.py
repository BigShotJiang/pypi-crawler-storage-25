from __future__ import annotations

import os
import platform
import shutil
import subprocess


def detect_device() -> dict:
    gpu_name = None
    gpu_count = 0
    vram_bytes = 0

    if shutil.which("nvidia-smi"):
        try:
            output = subprocess.check_output(
                [
                    "nvidia-smi",
                    "--query-gpu=name,memory.total",
                    "--format=csv,noheader,nounits",
                ],
                text=True,
                timeout=5,
            )
            rows = [line.strip() for line in output.splitlines() if line.strip()]
            gpu_count = len(rows)
            if rows:
                name, memory_mib = [part.strip() for part in rows[0].split(",", 1)]
                gpu_name = name
                vram_bytes = int(memory_mib) * 1024 * 1024
        except Exception:
            gpu_name = None
            gpu_count = 0
            vram_bytes = 0

    return {
        "os_name": platform.system().lower(),
        "python_version": platform.python_version(),
        "cpu_count": os.cpu_count() or 1,
        "ram_bytes": _ram_bytes(),
        "disk_limit_bytes": 256 * 1024 * 1024,
        "gpu_count": gpu_count,
        "gpu_name": gpu_name,
        "vram_bytes": vram_bytes,
        "apple_silicon": platform.system() == "Darwin" and platform.machine() in {"arm64", "aarch64"},
    }


def _ram_bytes() -> int:
    if hasattr(os, "sysconf"):
        try:
            return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"))
        except Exception:
            return 0
    return 0

