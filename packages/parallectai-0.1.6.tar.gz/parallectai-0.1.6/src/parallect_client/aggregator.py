from __future__ import annotations

import base64
import gzip
import hashlib
import json
import os
import tempfile
import time
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen

from . import __version__
from .http import ApiClient


MERGE_LIMIT = 16


@dataclass
class TrainingRun:
    id: str
    run_key: str
    current_step: int
    current_checkpoint: str | None
    hf_repo_id: str
    hf_updates_repo_id: str | None
    random_seed: int
    model_config: dict[str, Any]
    tokenizer_config: dict[str, Any]


def run_aggregator(api: ApiClient, once: bool) -> None:
    database_url = os.environ.get("DATABASE_URL")
    hf_token = os.environ.get("HF_TOKEN")
    if not database_url:
        raise RuntimeError("Aggregator mode requires DATABASE_URL")
    if not hf_token:
        raise RuntimeError("Aggregator mode requires HF_TOKEN")

    while True:
        merged = aggregate_once(database_url, hf_token)
        if merged:
            print(
                f"published checkpoint={merged['checkpoint_key']} "
                f"contributions={merged['contribution_count']} revision={merged['hf_revision']}"
            )
        else:
            print("no eligible train contributions to merge")

        if once:
            return
        time.sleep(30)


def aggregate_once(database_url: str, hf_token: str) -> dict[str, Any] | None:
    import psycopg

    with psycopg.connect(database_url) as conn:
        with conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
            cur.execute(
                "select pg_try_advisory_lock(hashtext('parallect_aggregate_loop')) as locked"
            )
            lock_row = cur.fetchone()
            if not lock_row or not lock_row["locked"]:
                return None

            try:
                run = load_active_run(cur)
                if run is None:
                    return None

                contributions = load_mergeable_contributions(cur, run.id)
                if not contributions:
                    return None

                merged_state = merge_state_dicts(contributions)
                checkpoint_key = f"step_{run.current_step + 1:08d}"
                parent_checkpoint = run.current_checkpoint or "init"
                revision = publish_checkpoint(
                    run=run,
                    checkpoint_key=checkpoint_key,
                    parent_checkpoint=parent_checkpoint,
                    state_dict=merged_state,
                    hf_token=hf_token,
                )
                merged_ids = [row["id"] for row in contributions]
                merged_shard_ids = [row["shard_id"] for row in contributions]
                merged_step_ids = [row["step_id"] for row in contributions]
                update_hash = state_dict_hash(merged_state)
                metrics = build_metrics(contributions)

                cur.execute(
                    """
                    insert into model_updates (
                      run_id, checkpoint_key, parent_checkpoint_key, status,
                      hf_repo_id, hf_revision, update_hash, merged_contribution_ids,
                      metrics, published_at
                    ) values (
                      %s, %s, %s, 'published',
                      %s, %s, %s, %s::uuid[], %s::jsonb, now()
                    )
                    returning id
                    """,
                    (
                        run.id,
                        checkpoint_key,
                        parent_checkpoint,
                        run.hf_repo_id,
                        revision,
                        update_hash,
                        merged_ids,
                        json.dumps(metrics),
                    ),
                )
                model_update_id = cur.fetchone()["id"]

                cur.execute(
                    """
                    insert into hf_update_artifacts (
                      run_id, contribution_id, worker_id, repo_id, artifact_path,
                      hf_revision, update_hash, bytes_size, consumed_by_model_update_id, consumed_at
                    )
                    select
                      c.run_id,
                      c.id,
                      c.worker_id,
                      c.artifacts->>'hf_update_repo_id',
                      c.artifacts->>'hf_update_path',
                      c.artifacts->>'hf_update_revision',
                      c.update_hash,
                      nullif(c.artifacts->>'bytes_size', '')::bigint,
                      %s,
                      now()
                    from contributions c
                    where c.id = any(%s::uuid[])
                      and coalesce(c.artifacts->>'hf_update_repo_id', '') <> ''
                    on conflict (contribution_id) do update set
                      consumed_by_model_update_id = excluded.consumed_by_model_update_id,
                      consumed_at = excluded.consumed_at
                    """,
                    (model_update_id, merged_ids),
                )

                cur.execute(
                    """
                    update contributions
                       set status = 'confirmed',
                           points_confirmed = points_pending,
                           points_pending = 0
                     where id = any(%s::uuid[])
                    """,
                    (merged_ids,),
                )
                cur.execute(
                    """
                    update step_ledger
                       set status = 'merged',
                           verified_at = coalesce(verified_at, now())
                     where id = any(%s::uuid[])
                    """,
                    (merged_step_ids,),
                )
                cur.execute(
                    """
                    update shards
                       set status = 'merged',
                           verification_count = verification_count + 1,
                           updated_at = now()
                     where id = any(%s::uuid[])
                    """,
                    (merged_shard_ids,),
                )
                cur.execute(
                    """
                    update training_runs
                       set current_checkpoint = %s,
                           current_step = current_step + 1,
                           total_tokens_processed = total_tokens_processed + %s,
                           updated_at = now()
                     where id = %s
                    """,
                    (checkpoint_key, metrics["tokens_processed"], run.id),
                )
                cur.execute("select refresh_leaderboard_cache()")
                conn.commit()
            finally:
                cur.execute("select pg_advisory_unlock(hashtext('parallect_aggregate_loop'))")

    return {
        "model_update_id": model_update_id,
        "checkpoint_key": checkpoint_key,
        "hf_revision": revision,
        "contribution_count": len(contributions),
    }


def load_active_run(cur) -> TrainingRun | None:
    cur.execute(
        """
        select id, run_key, current_step, current_checkpoint, hf_repo_id,
               hf_updates_repo_id,
               random_seed, model_config, tokenizer_config
          from training_runs
         where status = 'active'
         order by created_at desc
         limit 1
        """
    )
    row = cur.fetchone()
    if row is None:
        return None

    return TrainingRun(
        id=str(row["id"]),
        run_key=str(row["run_key"]),
        current_step=int(row["current_step"]),
        current_checkpoint=row["current_checkpoint"],
        hf_repo_id=str(row["hf_repo_id"]),
        hf_updates_repo_id=row["hf_updates_repo_id"],
        random_seed=int(row["random_seed"]),
        model_config=dict(row["model_config"] or {}),
        tokenizer_config=dict(row["tokenizer_config"] or {}),
    )


def load_mergeable_contributions(cur, run_id: str) -> list[dict[str, Any]]:
    cur.execute(
        """
        select c.id,
               c.shard_id,
               c.step_id,
               c.tokens_processed,
               c.loss_before,
               c.loss_after,
               c.update_hash,
               c.artifacts
          from contributions c
          join shards s on s.id = c.shard_id
         where c.run_id = %s
           and c.mode in ('train', 'train_lite')
           and c.status in ('pending', 'confirmed')
           and s.status in ('submitted', 'verified')
           and coalesce(c.artifacts->>'state_format', '') in ('torch_state_dict_gzip_base64', 'hf_update_artifact_json')
           and not exists (
             select 1
               from model_updates mu
              where c.id = any(mu.merged_contribution_ids)
           )
         order by c.created_at asc
         limit %s
        """,
        (run_id, MERGE_LIMIT),
    )
    return [dict(row) for row in cur.fetchall()]


def merge_state_dicts(contributions: list[dict[str, Any]]) -> dict[str, Any]:
    import torch

    weighted_states: list[tuple[float, dict[str, Any]]] = []
    total_weight = 0.0
    for contribution in contributions:
        weight = max(float(contribution["tokens_processed"]), 1.0)
        state = decode_state_dict(contribution["artifacts"])
        weighted_states.append((weight, state))
        total_weight += weight

    if total_weight <= 0:
        raise RuntimeError("No usable weights for aggregation")

    reference = weighted_states[0][1]
    merged: dict[str, Any] = {}
    for name, tensor in reference.items():
        if not torch.is_floating_point(tensor):
            merged[name] = tensor.clone()
            continue

        accumulator = torch.zeros_like(tensor, dtype=torch.float32)
        for weight, state in weighted_states:
            accumulator += state[name].to(dtype=torch.float32) * (weight / total_weight)
        merged[name] = accumulator.to(dtype=tensor.dtype)

    return merged


def decode_state_dict(artifacts: dict[str, Any]) -> dict[str, Any]:
    import torch

    if artifacts.get("state_format") == "hf_update_artifact_json":
        payload = fetch_hf_update_payload(
            repo_id=str(artifacts["hf_update_repo_id"]),
            artifact_path=str(artifacts["hf_update_path"]),
        )
        raw = gzip.decompress(base64.b64decode(payload["state_dict_gzip_base64"].encode("ascii")))
    else:
        payload = artifacts.get("state_dict_gzip_base64")
        if not isinstance(payload, str) or not payload:
            raise RuntimeError("Missing state_dict_gzip_base64 artifact")
        raw = gzip.decompress(base64.b64decode(payload.encode("ascii")))
    state = torch.load(BytesIO(raw), map_location="cpu")
    if not isinstance(state, dict):
        raise RuntimeError("Decoded state artifact is not a state_dict")
    return state


def fetch_hf_update_payload(*, repo_id: str, artifact_path: str) -> dict[str, Any]:
    token = os.environ.get("HF_TOKEN")
    headers = {"user-agent": f"parallect-client/{__version__}"}
    if token:
        headers["authorization"] = f"Bearer {token}"
    request = Request(
        f"https://huggingface.co/{repo_id}/resolve/main/{artifact_path}",
        headers=headers,
    )
    with urlopen(request, timeout=120) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not isinstance(payload, dict):
        raise RuntimeError("HF update artifact payload was malformed")
    return payload


def publish_checkpoint(
    *,
    run: TrainingRun,
    checkpoint_key: str,
    parent_checkpoint: str,
    state_dict: dict[str, Any],
    hf_token: str,
) -> str:
    import torch
    from huggingface_hub import HfApi

    api = HfApi(token=hf_token)
    api.create_repo(repo_id=run.hf_repo_id, repo_type="model", exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="parallect-aggregate-") as tmp:
        folder = Path(tmp)
        checkpoint_dir = folder / "checkpoints" / checkpoint_key
        checkpoint_dir.mkdir(parents=True, exist_ok=True)

        torch.save(state_dict, folder / "pytorch_model.bin")
        torch.save(state_dict, checkpoint_dir / "pytorch_model.bin")

        config_payload = build_config_payload(run)
        write_json(folder / "config.json", config_payload)
        write_json(checkpoint_dir / "config.json", config_payload)
        write_json(folder / "tokenizer_config.json", run.tokenizer_config)
        write_model_card(folder / "README.md", run, checkpoint_key, parent_checkpoint)

        commit = api.upload_folder(
            repo_id=run.hf_repo_id,
            repo_type="model",
            folder_path=str(folder),
            commit_message=f"Publish Parallect checkpoint {checkpoint_key}",
        )
        return str(getattr(commit, "oid", "") or getattr(commit, "commit_id", "") or "unknown")


def build_config_payload(run: TrainingRun) -> dict[str, Any]:
    payload = {
        "architecture": "parallect_tiny_transformer",
        "from_scratch": True,
        "random_seed": run.random_seed,
        "model_size": run.model_config.get("model_size", "unknown"),
    }
    payload.update(run.model_config)
    return payload


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def write_model_card(path: Path, run: TrainingRun, checkpoint_key: str, parent_checkpoint: str) -> None:
    model_size = run.model_config.get("model_size") or run.model_config.get("n_embd") or "unknown"
    path.write_text(
        f"""---
license: apache-2.0
tags:
- parallect
- from-scratch
- pytorch
- distributed-training
---

# Parallect {model_size}

This repository stores public model artifacts for Parallect.

## Checkpoint

- Run: `{run.run_key}`
- Current checkpoint: `{checkpoint_key}`
- Parent checkpoint: `{parent_checkpoint}`
- Base model: none
- Published by: `parallect-client/{__version__}`
""",
        encoding="utf-8",
    )


def state_dict_hash(state_dict: dict[str, Any]) -> str:
    import torch

    buffer = BytesIO()
    torch.save(state_dict, buffer)
    return "sha256:" + hashlib.sha256(buffer.getvalue()).hexdigest()


def build_metrics(contributions: list[dict[str, Any]]) -> dict[str, Any]:
    losses_before = [float(row["loss_before"]) for row in contributions if row["loss_before"] is not None]
    losses_after = [float(row["loss_after"]) for row in contributions if row["loss_after"] is not None]
    return {
        "aggregator": "fedavg",
        "contribution_count": len(contributions),
        "tokens_processed": int(sum(int(row["tokens_processed"]) for row in contributions)),
        "avg_loss_before": (sum(losses_before) / len(losses_before)) if losses_before else None,
        "avg_loss_after": (sum(losses_after) / len(losses_after)) if losses_after else None,
    }
