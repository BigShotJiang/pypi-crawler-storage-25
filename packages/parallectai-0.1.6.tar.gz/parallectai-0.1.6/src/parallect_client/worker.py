from __future__ import annotations

import hashlib
import json
import tempfile
import time
from http.client import IncompleteRead
from io import BytesIO
from pathlib import Path
from urllib.parse import parse_qs, quote, urlencode, urlparse
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
import os

from . import __version__
from .device import detect_device
from .http import ApiClient


HF_DATASETS_SERVER = "https://datasets-server.huggingface.co"
HF_ROWS_PAGE_SIZE = 100
HF_MAX_RETRIES = 10
HF_MAX_DELAY_SECONDS = 300.0
HF_REQUEST_SPACING_SECONDS = 0.8
_HF_SPLIT_CACHE: dict[str, tuple[str, str]] = {}
_LAST_HF_REQUEST_AT = 0.0


def run_worker(api: ApiClient, once: bool) -> None:
    device = detect_device()
    register_status, register = api.post(
        "/api/worker/register",
        {
            "client_version": __version__,
            "hostname": _hostname(),
            "device": device,
            "limits": {"pause_when_active": False},
        },
    )
    if register_status != 200:
        raise RuntimeError(f"Register failed with status {register_status}")

    worker_id = register["worker_id"]
    mode = register["mode"]
    run = register.get("run")
    if not run:
        raise RuntimeError("No active training run is available")

    print(f"worker={worker_id} mode={mode} run={run['run_key']}")

    while True:
        api.post(
            "/api/worker/heartbeat",
            {
                "worker_id": worker_id,
                "mode": mode,
                "status": "idle",
                "metrics": {},
            },
        )

        status, claim = api.post(
            "/api/step/claim",
            {
                "worker_id": worker_id,
                "run_id": run["run_id"],
                "mode": mode,
            },
        )
        if status == 204 or claim is None:
            print("no shard available")
            if once:
                return
            time.sleep(10)
            continue

        try:
            result = process_shard(claim["shard"], mode)
        except Exception as error:
            print(f"shard failed shard={claim['shard']['shard_key']} error={error}")
            if once:
                raise
            time.sleep(15)
            continue

        submit_payload = {
            "worker_id": worker_id,
            "step_id": claim["step_id"],
            "shard_id": claim["shard"]["shard_id"],
            "mode": mode,
            **result,
        }
        _, submitted = api.post("/api/step/submit", submit_payload)
        print(f"submitted contribution={submitted['contribution_id']} pending={submitted['points_pending']:.2f}")

        if once:
            return


def process_shard(shard: dict, mode: str) -> dict:
    started = time.perf_counter()
    data = read_shard_bytes(shard)

    if mode in {"train", "train_lite"}:
        from .train_runtime import train_bytes

        train_result = train_bytes(data)
        train_result["artifacts"] = maybe_publish_training_artifacts(
            shard=shard,
            train_result=train_result,
        )
        elapsed = max(time.perf_counter() - started, 0.001)
        return {
            "seconds": elapsed,
            "tokens_processed": train_result["tokens_processed"],
            "loss_before": train_result["loss_before"],
            "loss_after": train_result["loss_after"],
            "update_hash": train_result["update_hash"],
            "proof_hash": train_result["proof_hash"],
            "artifacts": train_result.get("artifacts", {}),
        }

    normalized = b"\n".join(line.strip() for line in data.splitlines() if line.strip())
    proof_hash = "sha256:" + hashlib.sha256(
        json.dumps(
            {
                "shard_id": shard["shard_id"],
                "shard_key": shard["shard_key"],
                "mode": mode,
                "input_hash": hashlib.sha256(data).hexdigest(),
                "output_hash": hashlib.sha256(normalized).hexdigest(),
            },
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()

    elapsed = max(time.perf_counter() - started, 0.001)
    tokens_processed = max(1, len(normalized.split()))

    return {
        "seconds": elapsed,
        "tokens_processed": tokens_processed,
        "loss_before": None,
        "loss_after": None,
        "update_hash": None,
        "proof_hash": proof_hash,
        "artifacts": {},
    }


def maybe_publish_training_artifacts(*, shard: dict, train_result: dict) -> dict:
    artifacts = dict(train_result.get("artifacts", {}))
    repo_id = os.environ.get("HF_UPDATE_REPO_ID")
    token = os.environ.get("HF_TOKEN")
    payload = artifacts.get("state_dict_gzip_base64")

    if not repo_id or not token or not isinstance(payload, str) or not payload:
        return artifacts

    try:
        from huggingface_hub import HfApi
    except ImportError:
        return artifacts

    api = HfApi(token=token)
    api.create_repo(repo_id=repo_id, repo_type="model", private=True, exist_ok=True)

    update_hash = train_result["update_hash"].replace("sha256:", "")
    artifact_path = f"updates/{shard['shard_key']}-{update_hash}.json"
    content = json.dumps(
        {
            "state_format": artifacts.get("state_format"),
            "state_dict_gzip_base64": payload,
            "seed": artifacts.get("seed"),
            "model_config": artifacts.get("model_config", {}),
            "proof_hash": train_result.get("proof_hash"),
            "update_hash": train_result.get("update_hash"),
        },
        sort_keys=True,
    )
    commit = api.upload_file(
        repo_id=repo_id,
        repo_type="model",
        path_in_repo=artifact_path,
        path_or_fileobj=content.encode("utf-8"),
        commit_message=f"Upload train update for {shard['shard_key']}",
    )
    return {
        "state_format": "hf_update_artifact_json",
        "hf_update_repo_id": repo_id,
        "hf_update_path": artifact_path,
        "hf_update_revision": str(getattr(commit, "oid", "") or getattr(commit, "commit_id", "") or "unknown"),
        "update_hash": train_result.get("update_hash"),
        "proof_hash": train_result.get("proof_hash"),
        "bytes_size": len(content),
    }


def read_shard_bytes(shard: dict) -> bytes:
    source_uri = shard["source_uri"]
    byte_start = shard.get("byte_start")
    byte_end = shard.get("byte_end")
    print(f"DEBUG uri: {shard['source_uri']}")

    if source_uri.startswith("file://"):
        print("DEBUG branch: file")
        data = Path(source_uri[7:]).read_bytes()
    elif source_uri.startswith("huggingface://datasets/"):
        print("DEBUG branch: huggingface-datasets")
        data = read_huggingface_dataset_bytes(source_uri)
    elif source_uri.startswith("http://") or source_uri.startswith("https://"):
        print("DEBUG branch: http")
        headers = {}
        if byte_start is not None and byte_end is not None:
            headers["range"] = f"bytes={byte_start}-{byte_end - 1}"
        request = Request(source_uri, headers=headers)
        with urlopen(request, timeout=60) as response:
            data = response.read()
    elif source_uri.startswith("inline:"):
        print("DEBUG branch: inline")
        data = source_uri[len("inline:") :].encode("utf-8")
    else:
        print("DEBUG branch: fallback")
        data = f"{shard['shard_key']}\n".encode("utf-8")

    if len(data) > 64 * 1024 * 1024:
        raise RuntimeError("Shard exceeds client safety limit")

    with tempfile.TemporaryDirectory(prefix="parallect-") as tmp:
        cache_path = Path(tmp) / "shard.bin"
        cache_path.write_bytes(data)
        return cache_path.read_bytes()


def read_huggingface_dataset_bytes(source_uri: str) -> bytes:
    dataset, config, split, offset, limit = parse_huggingface_dataset_uri(source_uri)
    limit = min(limit, HF_ROWS_PAGE_SIZE)
    rows = stream_huggingface_rows(
        dataset=dataset,
        config=config,
        split=split,
        offset=offset,
        limit=limit,
    )
    return encode_rows_as_jsonl(rows)


def parse_huggingface_dataset_uri(source_uri: str) -> tuple[str, str, str, int, int]:
    parsed = urlparse(source_uri)
    prefix = "huggingface://datasets/"
    if not source_uri.startswith(prefix):
        raise RuntimeError(f"Unsupported Hugging Face dataset URI: {source_uri}")

    dataset = source_uri[len(prefix) :].split("?", 1)[0].strip("/")
    if not dataset:
        raise RuntimeError("Missing dataset name in Hugging Face shard URI")

    query = parse_qs(parsed.query)
    offset = parse_positive_int(query, "offset", default=0)
    limit = parse_positive_int(query, "limit", default=HF_ROWS_PAGE_SIZE)
    config = first_query_value(query, "config")
    split = first_query_value(query, "split")

    if config and split:
        return dataset, config, split, offset, limit

    resolved = resolve_huggingface_config_and_split(dataset)
    return dataset, resolved[0], resolved[1], offset, limit


def parse_positive_int(query: dict[str, list[str]], key: str, default: int) -> int:
    raw = first_query_value(query, key)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError as error:
        raise RuntimeError(f"Invalid integer for {key}: {raw}") from error
    if value < 0:
        raise RuntimeError(f"{key} must be >= 0")
    return value


def first_query_value(query: dict[str, list[str]], key: str) -> str | None:
    values = query.get(key)
    if not values:
        return None
    value = values[0].strip()
    return value or None


def resolve_huggingface_config_and_split(dataset: str) -> tuple[str, str]:
    cached = _HF_SPLIT_CACHE.get(dataset)
    if cached is not None:
        return cached

    query = urlencode({"dataset": dataset})
    payload = fetch_json(f"{HF_DATASETS_SERVER}/splits?{query}")
    splits = payload.get("splits")
    if not isinstance(splits, list) or not splits:
        raise RuntimeError(f"No dataset splits available for {dataset}")

    preferred = choose_split_record(splits)
    config = preferred.get("config")
    split = preferred.get("split")
    if not isinstance(config, str) or not config:
        raise RuntimeError(f"Dataset {dataset} did not return a usable config")
    if not isinstance(split, str) or not split:
        raise RuntimeError(f"Dataset {dataset} did not return a usable split")

    resolved = (config, split)
    _HF_SPLIT_CACHE[dataset] = resolved
    return resolved


def choose_split_record(splits: list[dict]) -> dict:
    train = next(
        (
            item
            for item in splits
            if isinstance(item, dict) and item.get("split") == "train"
        ),
        None,
    )
    if train is not None:
        return train

    first = next((item for item in splits if isinstance(item, dict)), None)
    if first is None:
        raise RuntimeError("Dataset splits response did not include any split records")
    return first


def stream_huggingface_rows(
    *,
    dataset: str,
    config: str,
    split: str,
    offset: int,
    limit: int,
) -> list[dict]:
    rows: list[dict] = []
    remaining = limit
    current_offset = offset

    while remaining > 0:
        page_size = min(remaining, HF_ROWS_PAGE_SIZE)
        query = urlencode(
            {
                "dataset": dataset,
                "config": config,
                "split": split,
                "offset": current_offset,
                "length": page_size,
            },
            quote_via=quote,
        )
        payload = fetch_json(f"{HF_DATASETS_SERVER}/rows?{query}")
        page_rows = payload.get("rows")
        if not isinstance(page_rows, list):
            raise RuntimeError(f"Hugging Face rows response was malformed for {dataset}")
        if not page_rows:
            break

        rows.extend(page_rows)
        consumed = len(page_rows)
        current_offset += consumed
        remaining -= consumed
        if consumed < page_size:
            break

    if not rows:
        raise RuntimeError(
            f"Hugging Face dataset slice returned no rows for {dataset} offset={offset} limit={limit}"
        )

    return rows


def encode_rows_as_jsonl(rows: list[dict]) -> bytes:
    buffer = BytesIO()
    for item in rows:
        row = item.get("row", item)
        buffer.write(json.dumps(row, ensure_ascii=False, sort_keys=True).encode("utf-8"))
        buffer.write(b"\n")
    return buffer.getvalue()


def fetch_json(url: str) -> dict:
    global _LAST_HF_REQUEST_AT
    request = Request(
        url,
        headers={
            "accept": "application/json",
            "user-agent": f"parallect-client/{__version__}",
        },
    )
    payload = None
    delay = 2.0

    for attempt in range(1, HF_MAX_RETRIES + 1):
        try:
            now = time.monotonic()
            wait_for = HF_REQUEST_SPACING_SECONDS - (now - _LAST_HF_REQUEST_AT)
            if wait_for > 0:
                time.sleep(wait_for)
            with urlopen(request, timeout=60) as response:
                _LAST_HF_REQUEST_AT = time.monotonic()
                payload = json.loads(response.read().decode("utf-8"))
            break
        except HTTPError as error:
            if error.code == 429:
                retry_after = error.headers.get("Retry-After")
                sleep_for = max(delay, parse_retry_after(retry_after)) if retry_after else delay
                print(
                    f"HF datasets rate limited attempt={attempt}/{HF_MAX_RETRIES} "
                    f"sleep={sleep_for:.1f}s url={url}"
                )
                time.sleep(sleep_for)
                delay = min(delay * 2, HF_MAX_DELAY_SECONDS)
                continue
            raise RuntimeError(f"Hugging Face datasets request failed: {error.code} {url}") from error
        except (URLError, TimeoutError, IncompleteRead, json.JSONDecodeError, OSError) as error:
            if attempt < HF_MAX_RETRIES:
                print(
                    f"HF datasets transient error attempt={attempt}/{HF_MAX_RETRIES} "
                    f"sleep={delay:.1f}s url={url} reason={_transient_reason(error)}"
                )
                time.sleep(delay)
                delay = min(delay * 2, HF_MAX_DELAY_SECONDS)
                continue
            raise RuntimeError(f"Hugging Face datasets request failed: {url}") from error

    if isinstance(payload, dict) and payload.get("error"):
        raise RuntimeError(f"Hugging Face datasets API error: {payload['error']}")
    if not isinstance(payload, dict):
        raise RuntimeError("Expected JSON object from Hugging Face datasets API")
    return payload


def _hostname() -> str:
    return platform_node() or "worker"


def platform_node() -> str:
    import platform

    return platform.node()


def _transient_reason(error: Exception) -> str:
    if isinstance(error, URLError):
        return str(error.reason)
    if isinstance(error, IncompleteRead):
        return f"incomplete_read partial={len(error.partial)} expected_more={error.expected}"
    return str(error)


def parse_retry_after(value: str | None) -> float:
    if not value:
        return 0.0
    try:
        return max(0.0, float(value))
    except ValueError:
        return 0.0
