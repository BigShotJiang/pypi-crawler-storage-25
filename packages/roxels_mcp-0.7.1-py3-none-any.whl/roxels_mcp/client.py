"""Roxels API client — thin httpx wrapper for the REST API."""

import httpx


class RoxelsClient:
    """Async HTTP client for the Roxels API."""

    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {api_key}"}

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._headers,
            timeout=30.0,
        )

    async def _request(self, method: str, path: str, **kwargs) -> dict | list:
        async with self._client() as client:
            resp = await client.request(method, path, **kwargs)
            resp.raise_for_status()
            return resp.json()

    # ── Auth ──

    async def whoami(self) -> dict:
        """Get org info for the configured API key. Uses GET /v1/templates as a
        lightweight auth check (returns org context via the API key)."""
        # The /v1/auth/me endpoint requires an internal secret, so we use
        # listing templates as a connectivity/auth test instead.
        templates = await self._request("GET", "/v1/templates")
        return {"authenticated": True, "template_count": len(templates)}

    # ── Templates ──

    async def list_templates(self) -> list:
        return await self._request("GET", "/v1/templates")

    async def get_template(self, template_id: str) -> dict:
        return await self._request("GET", f"/v1/templates/{template_id}")

    async def create_template(self, data: dict) -> dict:
        return await self._request("POST", "/v1/templates", json=data)

    async def update_template(self, template_id: str, data: dict) -> dict:
        return await self._request("PATCH", f"/v1/templates/{template_id}", json=data)

    async def start_setup_assistant(self) -> dict:
        return await self._request("POST", "/v1/templates/setup-assistant")

    async def start_modify_assistant(self, template_id: str) -> dict:
        return await self._request(
            "POST", f"/v1/templates/{template_id}/modify-assistant"
        )

    # ── Interviews ──

    async def list_interviews(
        self,
        template_id: str | None = None,
        person_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list:
        params: dict = {"limit": limit, "offset": offset}
        if template_id:
            params["template_id"] = template_id
        if person_id:
            params["person_id"] = person_id
        if status:
            params["status"] = status
        return await self._request("GET", "/v1/interviews", params=params)

    async def get_interview(self, interview_id: str) -> dict:
        return await self._request("GET", f"/v1/interviews/{interview_id}")

    # ── Persons ──

    async def list_persons(self) -> list:
        return await self._request("GET", "/v1/persons")

    async def create_person(self, data: dict) -> dict:
        return await self._request("POST", "/v1/persons", json=data)

    # ── Embed ──

    async def create_embed_key(
        self, template_id: str, allowed_domains: list[str] | None = None
    ) -> dict:
        body = {"allowed_domains": allowed_domains or []}
        return await self._request(
            "POST", f"/v1/embed/keys/{template_id}", json=body
        )

    async def list_embed_keys(self, template_id: str) -> list:
        return await self._request("GET", f"/v1/embed/keys/{template_id}")

    async def revoke_embed_key(self, key_id: str) -> dict:
        return await self._request("DELETE", f"/v1/embed/keys/{key_id}")

    # ── Testing ──

    async def test_output(self, template_id: str, output_index: int = 0) -> dict:
        return await self._request(
            "POST",
            f"/v1/templates/{template_id}/test-output",
            json={"output_index": output_index},
        )

    async def record_learning(self, template_id: str, data: dict) -> dict:
        return await self._request(
            "POST",
            f"/v1/templates/{template_id}/learnings/record",
            json=data,
        )
