from __future__ import annotations

import csv
import io
import json
import re
from datetime import datetime, timezone
from typing import Any

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Response,
    UploadFile,
    status,
)
from sqlalchemy import text
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..broadcast import manager
from ..database import get_session
from ..db_store import (
    _coerce_for_write,
    _get_column_names,
    _normalize_row,
    _pg_table,
    _PG_TYPE_MAP,
    _qi,
    _read_col_types,
    _read_columns,
    _upsert_row,
    coerce_csv_value,
)
from ..deps import get_current_user
from ..models import DataTable, User
from .schemas import (
    DbTableCreate,
    DbTableRead,
    DbTableUpdate,
    DbAddColumnsRequest,
    DbRowsPage,
)


_VALID_COL_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,62}$")
_RESERVED_COL_NAMES = frozenset({"id", "history"})
_MAX_PAGE_SIZE = 1000


def _validate_column_id(col_id: str) -> None:
    """Raise 422 if col_id is empty, reserved, or not a valid PostgreSQL identifier."""
    if not col_id or not col_id.strip():
        raise HTTPException(status_code=422, detail="Column name cannot be empty.")
    if col_id in _RESERVED_COL_NAMES:
        raise HTTPException(
            status_code=422, detail=f"Column name '{col_id}' is reserved."
        )
    if not _VALID_COL_NAME.match(col_id):
        raise HTTPException(
            status_code=422,
            detail=(
                f"Column name '{col_id}' is invalid. Use only letters, digits, and underscores, "
                "starting with a letter or underscore (max 63 characters)."
            ),
        )


async def _tbl_read(
    t: DataTable, session: AsyncSession, include_rows: bool = True
) -> DbTableRead:
    columns = await _read_columns(session, t.id)
    rows: list[dict] = []
    if include_rows:
        tbl = _pg_table(t.id)
        col_types = {c["id"]: c["type"] for c in columns}
        result = await session.execute(text(f"SELECT * FROM {tbl} ORDER BY id"))
        rows = [_normalize_row(r._mapping, col_types) for r in result]
    return DbTableRead(
        id=t.id,
        name=t.name,
        description=t.description,
        actions=t.actions,
        columns=columns,
        rows=rows,
        created_at=t.created_at,
        updated_at=t.updated_at,
    )


def _build_mui_filter_sql(
    filter_items: list[dict],
    logic: str,
    col_types: dict[str, str],
) -> tuple[str, dict]:
    """Translate a MUI DataGrid filter model into a SQL WHERE clause fragment."""
    _SYSTEM_COLS = {
        "id": "integer",
        "created_at": "date",
        "updated_at": "date",
        "history": "json",
    }
    if not filter_items:
        return "", {}
    parts: list[str] = []
    params: dict[str, Any] = {}
    for i, item in enumerate(filter_items):
        field = item.get("field", "")
        operator = item.get("operator", "")
        value = item.get("value")
        if not field or not operator:
            continue
        col_type = col_types.get(field) or _SYSTEM_COLS.get(field)
        if col_type is None:
            continue  # unknown field — skip to prevent injection
        qi = _qi(field)
        p = f"fp{i}"
        clause = _mui_filter_clause(qi, operator, value, col_type, p, params)
        if clause:
            parts.append(f"({clause})")
    if not parts:
        return "", {}
    connector = " OR " if logic.lower() == "or" else " AND "
    return " WHERE " + connector.join(parts), params


def _mui_filter_clause(
    qi: str, operator: str, value: Any, col_type: str, p: str, params: dict
) -> str | None:
    if operator == "isEmpty":
        return f"{qi} IS NULL OR CAST({qi} AS TEXT) = ''"
    if operator == "isNotEmpty":
        return f"{qi} IS NOT NULL AND CAST({qi} AS TEXT) != ''"
    if col_type in ("integer", "float"):
        cast = "BIGINT" if col_type == "integer" else "DOUBLE PRECISION"
        if operator == "isAnyOf" and isinstance(value, list) and value:
            keys = [f"{p}_{j}" for j in range(len(value))]
            cast_fn = int if col_type == "integer" else float
            params.update({k: cast_fn(v) for k, v in zip(keys, value)})
            return f"CAST({qi} AS {cast}) IN ({', '.join(':' + k for k in keys)})"
        if value is None:
            return None
        try:
            num = int(value) if col_type == "integer" else float(value)
        except (ValueError, TypeError):
            return None
        params[p] = num
        op_map = {"=": "=", "!=": "!=", ">": ">", ">=": ">=", "<": "<", "<=": "<="}
        sql_op = op_map.get(operator)
        return f"CAST({qi} AS {cast}) {sql_op} :{p}" if sql_op else None
    if col_type == "boolean":
        if operator == "is":
            params[p] = value is True or value == "true"
            return f"{qi} = :{p}"
        return None
    if col_type == "date":
        if not value:
            return None
        params[p] = str(value)
        date_ops = {
            "is": "=",
            "not": "!=",
            "after": ">",
            "onOrAfter": ">=",
            "before": "<",
            "onOrBefore": "<=",
        }
        sql_op = date_ops.get(operator)
        return f"CAST({qi} AS DATE) {sql_op} CAST(:{p} AS DATE)" if sql_op else None
    # text / select / json — cast to text for string ops
    if operator == "isAnyOf" and isinstance(value, list) and value:
        keys = [f"{p}_{j}" for j in range(len(value))]
        params.update({k: str(v) for k, v in zip(keys, value)})
        return f"LOWER(CAST({qi} AS TEXT)) IN ({', '.join('LOWER(:' + k + ')' for k in keys)})"
    if not value:
        return None
    str_val = str(value)
    if operator == "contains":
        params[p] = f"%{str_val}%"
        return f"CAST({qi} AS TEXT) ILIKE :{p}"
    if operator == "equals":
        params[p] = str_val
        return f"LOWER(CAST({qi} AS TEXT)) = LOWER(:{p})"
    if operator == "startsWith":
        params[p] = f"{str_val}%"
        return f"CAST({qi} AS TEXT) ILIKE :{p}"
    if operator == "endsWith":
        params[p] = f"%{str_val}"
        return f"CAST({qi} AS TEXT) ILIKE :{p}"
    return None


def create_db_tables_router() -> APIRouter:
    router = APIRouter()

    @router.get(
        "/db-tables",
        response_model=list[DbTableRead],
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def list_db_tables(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        tables = (await session.exec(select(DataTable))).all()
        return [await _tbl_read(t, session, include_rows=False) for t in tables]

    @router.post(
        "/db-tables",
        response_model=DbTableRead,
        response_model_by_alias=True,
        status_code=status.HTTP_201_CREATED,
        tags=["db-tables"],
    )
    async def create_db_table(
        body: DbTableCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        seen_ids: set[str] = set()
        for col in body.columns or []:
            col_id = col.get("id", "")
            _validate_column_id(col_id)
            if col_id in seen_ids:
                raise HTTPException(
                    status_code=422, detail=f"Duplicate column name '{col_id}'."
                )
            seen_ids.add(col_id)

        existing_name = (
            await session.exec(select(DataTable).where(DataTable.name == body.name))
        ).first()
        if existing_name:
            raise HTTPException(
                status_code=409, detail=f"A table named '{body.name}' already exists."
            )

        t = DataTable(
            name=body.name, description=body.description, actions=body.actions
        )
        session.add(t)
        await session.flush()
        tbl = _pg_table(t.id)
        col_defs = [
            "id INTEGER NOT NULL",
            "history JSONB NOT NULL DEFAULT '[]'",
            "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
        ] + [
            f"{_qi(col['id'])} {_PG_TYPE_MAP.get(col.get('type', 'text'), 'TEXT')}"
            for col in (body.columns or [])
        ]
        await session.execute(
            text(f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))")
        )
        for col in body.columns or []:
            if col.get("type") == "select" and col.get("selectOptions"):
                await session.execute(
                    text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                        "VALUES (:tid, :cn, CAST(:opts AS json))"
                    ),
                    {
                        "tid": t.id,
                        "cn": col["id"],
                        "opts": json.dumps(col["selectOptions"]),
                    },
                )
        col_ids = [c["id"] for c in (body.columns or [])]
        max_id = 0
        for row in body.rows or []:
            row_id = row.get("id")
            if not isinstance(row_id, int) or row_id <= 0:
                max_id += 1
                row = {**{k: v for k, v in row.items() if k != "id"}, "id": max_id}
            else:
                max_id = max(max_id, row_id)
            await _upsert_row(session, tbl, row, col_ids)
        await session.commit()
        await session.refresh(t)
        await manager.broadcast("table_list", {"type": "table_created", "id": t.id})
        return await _tbl_read(t, session)

    @router.patch(
        "/db-tables/{id}",
        response_model=DbTableRead,
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def update_db_table(
        id: int,
        body: DbTableUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        patch = body.model_dump(exclude_unset=True, by_alias=False)
        if "name" in patch and patch["name"] != t.name:
            clash = (
                await session.exec(
                    select(DataTable).where(DataTable.name == patch["name"])
                )
            ).first()
            if clash:
                raise HTTPException(
                    status_code=409,
                    detail=f"A table named '{patch['name']}' already exists.",
                )
            t.name = patch["name"]
        if "description" in patch:
            t.description = patch["description"]
        if "actions" in patch:
            t.actions = patch["actions"]
        if "columns" in patch:
            new_columns: list[dict] = patch["columns"] or []
            seen_ids: set[str] = set()
            for col in new_columns:
                col_id = col.get("id", "")
                _validate_column_id(col_id)
                if col_id in seen_ids:
                    raise HTTPException(
                        status_code=422, detail=f"Duplicate column name '{col_id}'."
                    )
                seen_ids.add(col_id)
            old_cols = await _read_columns(session, id)
            old_col_map = {c["id"]: c for c in old_cols}
            new_col_map = {c["id"]: c for c in new_columns}
            for col_id in set(new_col_map) - set(old_col_map):
                pg_type = _PG_TYPE_MAP.get(
                    new_col_map[col_id].get("type", "text"), "TEXT"
                )
                try:
                    await session.execute(
                        text(f"ALTER TABLE {tbl} ADD COLUMN {_qi(col_id)} {pg_type}")
                    )
                except Exception as exc:
                    err_str = str(exc).lower()
                    if "already exists" in err_str:
                        await session.rollback()
                        raise HTTPException(
                            status_code=409, detail=f"Column '{col_id}' already exists."
                        )
                    raise
            for col_id in set(old_col_map) - set(new_col_map):
                await session.execute(
                    text(f"ALTER TABLE {tbl} DROP COLUMN {_qi(col_id)}")
                )
                await session.execute(
                    text(
                        "DELETE FROM data_table_column_meta WHERE table_id = :tid AND column_name = :cn"
                    ),
                    {"tid": id, "cn": col_id},
                )
            for col_id in set(old_col_map) & set(new_col_map):
                old_pg = _PG_TYPE_MAP.get(
                    old_col_map[col_id].get("type", "text"), "TEXT"
                )
                new_pg = _PG_TYPE_MAP.get(
                    new_col_map[col_id].get("type", "text"), "TEXT"
                )
                if old_pg != new_pg:
                    await session.execute(
                        text(
                            f"ALTER TABLE {tbl} ALTER COLUMN {_qi(col_id)} TYPE {new_pg} "
                            f"USING CAST({_qi(col_id)} AS {new_pg})"
                        )
                    )
            for col_id, col in new_col_map.items():
                if col.get("type") == "select" and col.get("selectOptions"):
                    await session.execute(
                        text(
                            "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                            "VALUES (:tid, :cn, CAST(:opts AS json)) "
                            "ON CONFLICT (table_id, column_name) DO UPDATE SET select_options = EXCLUDED.select_options"
                        ),
                        {
                            "tid": id,
                            "cn": col_id,
                            "opts": json.dumps(col["selectOptions"]),
                        },
                    )
                else:
                    await session.execute(
                        text(
                            "DELETE FROM data_table_column_meta WHERE table_id = :tid AND column_name = :cn"
                        ),
                        {"tid": id, "cn": col_id},
                    )
        if "rows" in patch:
            col_ids = await _get_column_names(session, tbl)
            max_id: int = (
                await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
            ) or 0
            normalized: list[dict] = []
            for row in patch["rows"] or []:
                row_id = row.get("id")
                if not isinstance(row_id, int) or row_id <= 0:
                    max_id += 1
                    normalized.append(
                        {**{k: v for k, v in row.items() if k != "id"}, "id": max_id}
                    )
                else:
                    max_id = max(max_id, row_id)
                    normalized.append(row)
            new_ids = [r["id"] for r in normalized]
            if new_ids:
                id_list = ", ".join(str(i) for i in new_ids)
                await session.execute(
                    text(f"DELETE FROM {tbl} WHERE id NOT IN ({id_list})")
                )
            else:
                await session.execute(text(f"DELETE FROM {tbl}"))
            for row in normalized:
                await _upsert_row(session, tbl, row, col_ids)
        t.updated_at = datetime.now(timezone.utc)
        session.add(t)
        await session.commit()
        await session.refresh(t)
        await manager.broadcast(f"table:{id}", {"type": "schema_changed"})
        return await _tbl_read(t, session)

    @router.post(
        "/db-tables/{id}/add-columns",
        response_model=DbTableRead,
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def add_table_columns(
        id: int,
        body: DbAddColumnsRequest,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        existing_cols = await _read_columns(session, id)
        existing_col_ids = {c["id"] for c in existing_cols}

        for col in body.columns:
            col_id = col.get("id", "")
            _validate_column_id(col_id)
            if col_id in existing_col_ids:
                continue
            pg_type = _PG_TYPE_MAP.get(col.get("type", "text"), "TEXT")
            await session.execute(
                text(f"ALTER TABLE {tbl} ADD COLUMN {_qi(col_id)} {pg_type}")
            )
            if col.get("type") == "select" and col.get("selectOptions"):
                await session.execute(
                    text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                        "VALUES (:tid, :cn, CAST(:opts AS json)) "
                        "ON CONFLICT (table_id, column_name) DO UPDATE SET select_options = EXCLUDED.select_options"
                    ),
                    {
                        "tid": id,
                        "cn": col_id,
                        "opts": json.dumps(col["selectOptions"]),
                    },
                )

        t.updated_at = datetime.now(timezone.utc)
        session.add(t)
        await session.commit()
        await session.refresh(t)
        await manager.broadcast(f"table:{id}", {"type": "schema_changed"})
        return await _tbl_read(t, session)

    @router.get(
        "/db-tables/{id}/rows",
        response_model=DbRowsPage,
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def get_db_table_rows(
        id: int,
        page: int = 0,
        page_size: int = 100,
        filter: str | None = None,
        filter_logic: str = "and",
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        page = max(0, page)
        page_size = max(1, min(page_size, _MAX_PAGE_SIZE))
        tbl = _pg_table(id)
        columns = await _read_columns(session, id)
        col_types = {c["id"]: c["type"] for c in columns}
        filter_items: list[dict] = []
        if filter:
            try:
                filter_items = json.loads(filter)
            except (ValueError, TypeError):
                raise HTTPException(status_code=422, detail="Invalid filter JSON")
        where_sql, params = _build_mui_filter_sql(filter_items, filter_logic, col_types)
        total: int = (
            await session.scalar(text(f"SELECT COUNT(*) FROM {tbl}{where_sql}"), params)
        ) or 0
        # Exclude JSON columns from the list query — they can be very large.
        # A NULL placeholder is returned instead; the full value is only fetched
        # when a single row is opened for editing.
        json_col_ids = {c["id"] for c in columns if c["type"] == "json"}
        system_col_ids = ["id", "created_at", "updated_at", "history"]
        col_select = ", ".join(
            "NULL" if col_id in json_col_ids else _qi(col_id)
            for col_id in [
                *system_col_ids,
                *[c["id"] for c in columns],
            ]
        )
        result = await session.execute(
            text(
                f"SELECT {col_select} FROM {tbl}{where_sql} ORDER BY id LIMIT :lim OFFSET :off"
            ),
            {**params, "lim": page_size, "off": page * page_size},
        )
        col_names = [*system_col_ids, *[c["id"] for c in columns]]
        rows = [_normalize_row(dict(zip(col_names, r)), col_types) for r in result]
        return DbRowsPage(rows=rows, total=total)

    @router.post(
        "/db-tables/{id}/rows", status_code=status.HTTP_201_CREATED, tags=["db-tables"]
    )
    async def add_db_table_row(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_ids = await _get_column_names(session, tbl)
        col_types = await _read_col_types(session, tbl)
        max_id: int = (
            await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
        ) or 0
        new_id = max_id + 1
        await _upsert_row(session, tbl, {"id": new_id}, col_ids)
        await session.commit()
        await manager.broadcast(f"table:{id}", {"type": "rows_changed"})
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": new_id}
        )
        row = result.first()
        return _normalize_row(row._mapping, col_types)

    @router.get("/db-tables/{id}/rows/{row_id}", tags=["db-tables"])
    async def get_db_table_row(
        id: int,
        row_id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_types = await _read_col_types(session, tbl)
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        row = result.first()
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Row not found"
            )
        return _normalize_row(row._mapping, col_types)

    @router.patch("/db-tables/{id}/rows/{row_id}", tags=["db-tables"])
    async def update_db_table_row(
        id: int,
        row_id: int,
        body: dict[str, Any],
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_ids = await _get_column_names(session, tbl)
        col_types = await _read_col_types(session, tbl)
        existing = await session.execute(
            text(f"SELECT id FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        if not existing.first():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Row not found"
            )
        coerced = {
            k: _coerce_for_write(v, col_types.get(k, "text")) for k, v in body.items()
        }
        await _upsert_row(session, tbl, {**coerced, "id": row_id}, col_ids)
        await session.commit()
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        row = result.first()
        normalized = _normalize_row(row._mapping, col_types)
        json_col_ids = {k for k, v in col_types.items() if v == "json"}
        broadcast_row = {k: v for k, v in normalized.items() if k not in json_col_ids}
        await manager.broadcast(
            f"table:{id}", {"type": "row_updated", "row": broadcast_row}
        )
        return normalized

    @router.post(
        "/db-tables/{id}/rows/{row_id}/restore/{history_index}", tags=["db-tables"]
    )
    async def restore_db_table_row(
        id: int,
        row_id: int,
        history_index: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Restore a row to the state recorded at *history_index* and clear all history."""
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_types = await _read_col_types(session, tbl)
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        row = result.first()
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Row not found"
            )
        row_dict = _normalize_row(row._mapping, col_types)
        history: list[dict] = row_dict.get("history") or []
        if history_index < 0 or history_index >= len(history):
            raise HTTPException(status_code=422, detail="history_index out of range")
        # Find the state from the first row_update action in this history item.
        history_item = history[history_index]
        state: dict | None = None
        for action in history_item.get("actions") or []:
            if action.get("type") == "row_update":
                state = action.get("state") or {}
                break
        if state is None:
            raise HTTPException(
                status_code=422,
                detail="No restorable row state found in this history item.",
            )
        update_data = {
            k: _coerce_for_write(v, col_types.get(k, "text"))
            for k, v in state.items()
            if k in col_types
        }
        params: dict[str, Any] = {"row_id": row_id}
        set_clauses = ["history = '[]'::jsonb", "updated_at = NOW()"]
        for i, (k, v) in enumerate(update_data.items()):
            set_clauses.append(f"{_qi(k)} = :v{i}")
            params[f"v{i}"] = v
        await session.execute(
            text(f"UPDATE {tbl} SET {', '.join(set_clauses)} WHERE id = :row_id"),
            params,
        )
        await session.commit()
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        updated = result.first()
        normalized = _normalize_row(updated._mapping, col_types)
        json_col_ids = {k for k, v in col_types.items() if v == "json"}
        broadcast_row = {k: v for k, v in normalized.items() if k not in json_col_ids}
        await manager.broadcast(
            f"table:{id}", {"type": "row_updated", "row": broadcast_row}
        )
        return normalized

    @router.delete(
        "/db-tables/{id}/rows",
        status_code=status.HTTP_204_NO_CONTENT,
        tags=["db-tables"],
    )
    async def delete_db_table_rows(
        id: int,
        ids: str,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        try:
            row_ids = [int(i.strip()) for i in ids.split(",") if i.strip()]
        except ValueError:
            raise HTTPException(
                status_code=422, detail="ids must be a comma-separated list of integers"
            )
        if row_ids:
            id_list = ", ".join(str(i) for i in row_ids)
            await session.execute(
                text(f"DELETE FROM {_pg_table(id)} WHERE id IN ({id_list})")
            )
            await session.commit()
            await manager.broadcast(f"table:{id}", {"type": "rows_changed"})

    @router.delete(
        "/db-tables/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["db-tables"]
    )
    async def delete_db_table(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        await session.execute(text(f"DROP TABLE IF EXISTS {_pg_table(id)}"))
        await session.delete(t)
        await session.commit()
        await manager.broadcast("table_list", {"type": "table_deleted", "id": id})

    @router.get("/db-tables/{id}/export", tags=["db-tables"])
    async def export_db_table_csv(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        columns = await _read_columns(session, id)
        col_ids = [c["id"] for c in columns]
        col_types = {c["id"]: c["type"] for c in columns}
        result = await session.execute(text(f"SELECT * FROM {tbl} ORDER BY id"))
        rows = [_normalize_row(r._mapping, col_types) for r in result]

        buf = io.StringIO()
        writer = csv.writer(buf)
        headers = ["id"] + col_ids + ["created_at", "updated_at"]
        writer.writerow(headers)
        for row in rows:
            writer.writerow(
                [
                    (
                        json.dumps(v)
                        if isinstance(v := row.get(h), (dict, list))
                        else (v if v is not None else "")
                    )
                    for h in headers
                ]
            )

        filename = re.sub(r"[^a-zA-Z0-9_-]", "_", t.name)
        return Response(
            content=buf.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{filename}.csv"'},
        )

    @router.post(
        "/db-tables/{id}/import", status_code=status.HTTP_200_OK, tags=["db-tables"]
    )
    async def import_db_table_csv(
        id: int,
        file: UploadFile = File(...),
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        columns = await _read_columns(session, id)
        col_type_map = {c["id"]: c["type"] for c in columns}
        col_ids = [c["id"] for c in columns]

        content = await file.read()
        try:
            text_content = content.decode("utf-8-sig")
        except UnicodeDecodeError:
            text_content = content.decode("latin-1")

        csv.field_size_limit(10 * 1024 * 1024)  # 10 MB — handles large JSON blobs
        reader = csv.DictReader(io.StringIO(text_content))
        if reader.fieldnames is None:
            raise HTTPException(
                status_code=422, detail="CSV file is empty or has no header row"
            )

        csv_headers = [h.strip() for h in reader.fieldnames]
        header_to_col_id = {h: h for h in col_ids}
        col_name_to_id = {c["name"]: c["id"] for c in columns}
        header_to_col_id.update(
            {
                name: col_id
                for name, col_id in col_name_to_id.items()
                if name in csv_headers
            }
        )

        max_id: int = (
            await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
        ) or 0
        imported = 0
        for csv_row in reader:
            row: dict[str, Any] = {}
            raw_id = csv_row.get("id", "").strip()
            if raw_id and raw_id.isdigit():
                row["id"] = int(raw_id)
            else:
                max_id += 1
                row["id"] = max_id
            max_id = max(max_id, row["id"])

            for header, value in csv_row.items():
                if header is None:
                    continue
                header = header.strip()
                if header in ("id", "created_at", "updated_at"):
                    continue
                col_id = header_to_col_id.get(header)
                if col_id is None:
                    continue
                row[col_id] = coerce_csv_value(
                    value or "", col_type_map.get(col_id, "text")
                )

            await _upsert_row(session, tbl, row, col_ids)
            imported += 1

        await session.commit()
        await manager.broadcast(f"table:{id}", {"type": "rows_changed"})
        return {"imported": imported}

    return router
