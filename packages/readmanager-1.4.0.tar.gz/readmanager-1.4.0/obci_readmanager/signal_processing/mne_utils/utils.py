# -*- coding: utf-8 -*-
# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# Copyright (c) 2025-2026 Faculty of Physics, University of Warsaw
# Licensed under GPL-3.0-or-later

"""Misc utils needed for obci-MNE conversion."""
import re

try:
    import mne
except ImportError:
    mne = None


#: Cached set of MNE ``standard_1005`` positions in lowercase. Populated
#: lazily on the first call to :func:`chtype_heuristic` so importing this
#: module doesn't pay the cost of building a 343-position montage for
#: callers that never use the heuristic.
_NORM_1005_NAMES = None


def _get_1005_positions():
    """Return the (lazily cached) set of ``standard_1005`` position names,
    lowercased, for substring-token matching in :func:`chtype_heuristic`.
    """
    global _NORM_1005_NAMES
    if _NORM_1005_NAMES is None:
        montage = mne.channels.make_standard_montage('standard_1005')
        _NORM_1005_NAMES = {n.lower() for n in montage.ch_names}
    return _NORM_1005_NAMES


def requires_mne(func):
    """Make sure that mne is loaded, point user to installing."""
    def wrapper(*args, **kwargs):
        if mne is None:
            raise Exception("You have no MNE installed, to install visit http://martinos.org/mne/stable/\n"
                            "Alternatively you can try running:\n"
                            "pip3 install --user mne")
        return func(*args, **kwargs)
    return wrapper


@requires_mne
def chtype_heuristic(chname):
    """Guess a sensible MNE channel type from the channel name.

    Returns one of seven valid MNE channel-type strings:

    ===== =======================================================
    Type  Detection rule
    ===== =======================================================
    eog   ``chname`` contains ``'eog'`` (case-insensitive substring)
    emg   contains ``'emg'``
    ecg   contains ``'ecg'`` or ``'ekg'``
    bio   contains ``'resp'``, ``'sao2'`` or ``'spo2'``
          (respiration / oximetry — MNE's generic biosignal type)
    stim  contains ``'stim'``, ``'trig'``, ``'marker'``, ``'status'``,
          ``'sync'``, or starts with ``'sti '``
          (the last catches MNE's FIF convention ``'STI 014'``)
    eeg   Any whitespace/punctuation-separated token of ``chname``
          matches an MNE ``standard_1005`` montage position
          (e.g. ``'EEG F3-CLE'`` → tokens ``['eeg', 'f3', 'cle']``,
          ``'f3'`` is in the 10-05 set → ``'eeg'``).  Tokenized
          matching avoids false positives on short 10-05 names
          like ``'A1'``/``'C3'``/``'O1'`` embedded in unrelated
          words such as ``'Data1'``/``'misc3'``/``'audio1'``.
    misc  Fallback — name matches none of the above rules.
    ===== =======================================================

    Detection order matters: non-EEG substring rules fire **before**
    the positive EEG position lookup, so a name like
    ``'EOG Fp1-M2'`` (an EOG reference channel using Fp1/M2 as the
    reference montage) is correctly typed as ``'eog'`` rather than
    ``'eeg'``.

    All seven returned strings are valid MNE channel-type values
    and can be passed directly to :func:`mne.create_info` via its
    ``ch_types`` parameter, or to :meth:`mne.io.Raw.set_channel_types`.

    Parameters
    ----------
    chname : str
        The channel name to classify.

    Returns
    -------
    str
        One of: ``'eog'``, ``'emg'``, ``'ecg'``, ``'bio'``, ``'stim'``,
        ``'eeg'``, ``'misc'``.

    Examples
    --------
    >>> chtype_heuristic('Fp1')
    'eeg'
    >>> chtype_heuristic('EEG F3-CLE')  # EDF polysomnography convention
    'eeg'
    >>> chtype_heuristic('EOG Left Horiz')
    'eog'
    >>> chtype_heuristic('EOG Fp1-M2')  # non-EEG label wins over position
    'eog'
    >>> chtype_heuristic('EMG Chin1')
    'emg'
    >>> chtype_heuristic('ECG ECGI')
    'ecg'
    >>> chtype_heuristic('Resp Thermistor')
    'bio'
    >>> chtype_heuristic('SaO2 SaO2')
    'bio'
    >>> chtype_heuristic('STI 014')  # MNE FIF convention
    'stim'
    >>> chtype_heuristic('Trigger')
    'stim'
    >>> chtype_heuristic('Channel_42')  # unknown, no rule matches
    'misc'
    >>> chtype_heuristic('audio1')  # 'o1' as substring is NOT enough
    'misc'
    """
    lname = chname.lower()

    # 1. Explicit non-EEG labels take priority over any EEG position
    #    that might happen to appear in the name as a substring. This
    #    is why e.g. 'EOG Fp1-M2' is typed eog: the 'eog' substring
    #    rule fires before the tokenized 10-05 check.
    if 'eog' in lname:
        return 'eog'
    if 'emg' in lname:
        return 'emg'
    if 'ecg' in lname or 'ekg' in lname:
        return 'ecg'
    if 'resp' in lname:
        return 'bio'
    if 'sao2' in lname or 'spo2' in lname:
        return 'bio'
    if ('stim' in lname
            or 'trig' in lname
            or 'marker' in lname
            or 'status' in lname
            or 'sync' in lname
            or lname.startswith('sti ')):
        return 'stim'

    # 2. Positive EEG detection via tokenized 10-05 lookup.
    #    Tokenize on any non-alphanumeric boundary and look for an
    #    exact match against the lowercased standard_1005 position
    #    set. This catches prefixed/suffixed variants common in EDF
    #    polysomnography files ('EEG F3-CLE', 'EEG Fp1-M2') while
    #    staying safe against false positives from short position
    #    names like 'A1'/'C3'/'O1' embedded in unrelated words.
    norm_names = _get_1005_positions()
    tokens = re.split(r'[^a-z0-9]+', lname)
    if any(t in norm_names for t in tokens if t):
        return 'eeg'

    # 3. Fall-through for anything else. Downstream callers that need
    #    a more specific type for names readmanager doesn't know can
    #    always override by passing an explicit ``channel_types`` list
    #    to get_mne_info/get_mne_raw.
    return 'misc'
