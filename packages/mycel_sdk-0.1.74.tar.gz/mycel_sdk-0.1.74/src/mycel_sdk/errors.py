"""Stable SDK errors exposed above generated transport details."""

from __future__ import annotations

import json
from typing import Any


class ApiError(RuntimeError):
    """HTTP API failure surfaced through the stable SDK boundary."""

    def __init__(self, status_code: int, detail: str, *, content: bytes | None = None):
        self.status_code = status_code
        self.detail = detail
        self.content = content
        super().__init__(f"HTTP {status_code}: {detail}")

    @classmethod
    def transport_error(cls, detail: str) -> ApiError:
        return cls(0, f"transport error: {detail}")

    @property
    def is_transport_error(self) -> bool:
        return self.status_code == 0

    @classmethod
    def from_response_content(cls, status_code: int, content: bytes) -> ApiError:
        detail = _extract_error_detail(content)
        return cls(status_code, detail, content=content)


class ConnectionClosed(RuntimeError):
    """Runtime inbox stream closed before another frame arrived."""


class ReplayOverflow(RuntimeError):
    """Runtime inbox stream cannot replay from the requested sequence."""

    def __init__(self, frame: dict[str, Any]):
        self.frame = frame
        super().__init__("runtime inbox replay overflow")


def _extract_error_detail(content: bytes) -> str:
    text = content.decode(errors="replace").strip()
    if not text:
        return "empty response body"

    try:
        payload: Any = json.loads(text)
    except json.JSONDecodeError:
        return text

    if isinstance(payload, dict):
        detail = payload.get("detail") or payload.get("message")
        if isinstance(detail, str) and detail:
            return detail
        if detail is not None:
            return json.dumps(detail, ensure_ascii=False)

    return text
