from __future__ import annotations

from distutils.errors import CCompilerError, DistutilsExecError, DistutilsPlatformError

from setuptools import Extension, setup
from setuptools.command.build_ext import build_ext


class OptionalBuildExt(build_ext):
    """Allow installation to continue when the optional C build is unavailable."""

    def run(self) -> None:
        try:
            super().run()
        except (DistutilsPlatformError, DistutilsExecError, CCompilerError, OSError, ValueError) as exc:
            self._announce_skip(exc)

    def build_extension(self, ext: Extension) -> None:
        try:
            super().build_extension(ext)
        except (DistutilsPlatformError, DistutilsExecError, CCompilerError, OSError, ValueError) as exc:
            self._announce_skip(exc)

    def _announce_skip(self, exc: BaseException) -> None:
        self.warn(
            f"Skipping optional C extension for smartarr. "
            f"The pure Python backend will be used instead. Reason: {exc}"
        )


setup(
    ext_modules=[
        Extension(
            "smartarr._smartarr",
            sources=["src/smartarr/_smartarr.c"],
            optional=True,
        )
    ],
    cmdclass={"build_ext": OptionalBuildExt},
)
