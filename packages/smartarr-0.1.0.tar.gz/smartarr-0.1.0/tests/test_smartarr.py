from __future__ import annotations

import unittest

from smartarr import smart

try:
    import numpy as np
except ImportError:  # pragma: no cover - optional dependency
    np = None


class SmartArrayTests(unittest.TestCase):
    def test_basic_accessors(self) -> None:
        arr = smart([1, 2, 3, 4])
        self.assertEqual(arr.first(), 1)
        self.assertEqual(arr.last(), 4)
        self.assertEqual(arr.middle(), 3)
        self.assertEqual(arr.middle(mode="left"), 2)
        self.assertEqual(arr.middle(mode="avg"), 2.5)

    def test_rotate_and_reverse_are_chainable(self) -> None:
        value = smart([1, 2, 3, 4, 5]).rotate(2).reverse().middle()
        self.assertEqual(value, 1)

    def test_len_and_empty(self) -> None:
        self.assertEqual(smart([1, 2]).len(), 2)
        self.assertFalse(smart([1]).is_empty())
        self.assertTrue(smart([]).is_empty())

    def test_chunk_and_window(self) -> None:
        arr = smart([1, 2, 3, 4, 5])
        self.assertEqual(arr.chunk(2).to_list(), [[1, 2], [3, 4], [5]])
        self.assertEqual(arr.chunk(2, drop_last=True).to_list(), [[1, 2], [3, 4]])
        self.assertEqual(arr.window(3).to_list(), [[1, 2, 3], [2, 3, 4], [3, 4, 5]])
        self.assertEqual(arr.window(3, step=2).to_list(), [[1, 2, 3], [3, 4, 5]])

    def test_search_helpers(self) -> None:
        arr = smart([1, 4, 4, 9])
        self.assertEqual(arr.find(4), 1)
        self.assertEqual(arr.find(8), -1)
        self.assertEqual(arr.count(4), 2)
        self.assertTrue(arr.contains(9))
        self.assertFalse(arr.contains(10))

    def test_sort_helpers(self) -> None:
        arr = smart([3, 1, 2])
        self.assertFalse(arr.is_sorted())
        self.assertEqual(arr.sorted().to_list(), [1, 2, 3])
        self.assertTrue(smart([3, 2, 2]).is_sorted(reverse=True))

    def test_random_helpers(self) -> None:
        arr = smart([10, 20, 30, 40])
        self.assertIn(arr.random(seed=7), arr.to_list())
        self.assertEqual(arr.random(n=2, seed=7).len(), 2)
        self.assertEqual(arr.random(n=3, seed=7, replace=True).len(), 3)

    def test_transformations_and_stats(self) -> None:
        arr = smart([1, 2, 3, 4])
        self.assertEqual(arr.map(lambda x: x * 2).to_list(), [2, 4, 6, 8])
        self.assertEqual(arr.filter(lambda x: x % 2 == 0).to_list(), [2, 4])
        self.assertEqual(arr.reduce(lambda a, b: a + b), 10)
        self.assertEqual(arr.sum(), 10)
        self.assertEqual(arr.mean(), 2.5)
        self.assertEqual(arr.median(), 2.5)
        self.assertEqual(arr.min(), 1)
        self.assertEqual(arr.max(), 4)

    def test_advanced_algorithms(self) -> None:
        arr = smart([1, 3, 2, 5, 4, 5, 1])
        self.assertEqual(arr.peaks().to_list(), [1, 3, 5])
        self.assertEqual(arr.unique().to_list(), [1, 3, 2, 5, 4])
        self.assertEqual(arr.duplicates().to_list(), [5, 1])
        self.assertEqual(arr.frequency(), {1: 2, 3: 1, 2: 1, 5: 2, 4: 1})

    def test_flatten_and_reshape(self) -> None:
        arr = smart([[1, 2], [3, [4, 5]]])
        self.assertEqual(arr.flatten().to_list(), [1, 2, 3, 4, 5])
        self.assertEqual(smart([1, 2, 3, 4]).reshape(2, 2).to_list(), [[1, 2], [3, 4]])

    def test_tuple_adapter_restores_tuple(self) -> None:
        arr = smart((1, 2, 3)).reverse()
        self.assertEqual(arr.to_native(), (3, 2, 1))

    @unittest.skipIf(np is None, "NumPy is not installed")
    def test_numpy_adapter_restores_ndarray(self) -> None:
        arr = smart(np.array([1, 2, 3])).rotate(1).to_native()
        self.assertTrue((arr == np.array([3, 1, 2])).all())


if __name__ == "__main__":
    unittest.main()
