# smartarr

`smartarr` is an expressive array utility layer for Python with a clean `smart(arr)` API and an optional C backend for fast core operations.

## Why it exists

The goal is simple:

- one readable interface for lists, tuples, and NumPy arrays
- fast common operations when the C extension is available
- chainable transformations that still feel like Python

```python
from smartarr import smart

value = smart([1, 2, 3, 4, 5]).rotate(2).reverse().middle()
print(value)  # 1
```

## Install

Local install from this project:

```bash
python -m pip install .
```

Editable install for development:

```bash
python -m pip install -e .
```

Optional NumPy support:

```bash
python -m pip install ".[numpy]"
```

If a compiler is available, `smartarr` builds its C extension automatically. If not, installation still succeeds and falls back to the pure Python backend.

## Quick start

```python
from smartarr import smart

arr = smart([1, 2, 3, 4])

print(arr.first())                 # 1
print(arr.last())                  # 4
print(arr.middle())                # 3
print(arr.middle(mode="left"))     # 2
print(arr.middle(mode="avg"))      # 2.5
print(arr.rotate(1).to_list())     # [4, 1, 2, 3]
print(arr.reverse().to_list())     # [4, 3, 2, 1]
print(arr.chunk(2).to_list())      # [[1, 2], [3, 4]]
print(arr.window(2).to_list())     # [[1, 2], [2, 3], [3, 4]]
```

## Design notes

- `middle()` defaults to the right-middle element for even-length arrays, matching `arr[len(arr) // 2]`.
- Structural methods return a new `SmartArray`, so chaining works naturally.
- Terminal methods return a final value, such as an element, a number, or a dictionary.
- Flat transformations preserve the original adapter where practical. Shape-changing operations return list-shaped data by default.

## Supported input types

- `list`
- `tuple`
- NumPy `ndarray` when NumPy is installed
- general iterables such as `range`

## Current feature coverage

### V1

- `first`
- `last`
- `middle`
- `rotate`
- `reverse`
- `len`
- `is_empty`

### V2

- `chunk`
- `window`
- `random`
- `find`
- `count`
- `contains`
- `is_sorted`
- `sorted`

### V3

- `map`
- `filter`
- `reduce`
- `sum`
- `mean`
- `median`
- `min`
- `max`
- `peaks`
- `unique`
- `duplicates`
- `frequency`
- `flatten`
- `reshape`

## Development

Run tests:

```bash
python -m unittest discover -s tests -v
```

## License

MIT
