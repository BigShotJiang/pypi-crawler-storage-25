from __future__ import annotations

from . import _pybackend

try:  # pragma: no cover - depends on build environment
    from . import _smartarr as _cbackend
except ImportError:  # pragma: no cover - exercised when C build is unavailable
    _cbackend = None


BACKEND_NAME = "c" if _cbackend is not None else "python"

length = _cbackend.length if _cbackend is not None else _pybackend.length
is_empty = _cbackend.is_empty if _cbackend is not None else _pybackend.is_empty
first = _cbackend.first if _cbackend is not None else _pybackend.first
last = _cbackend.last if _cbackend is not None else _pybackend.last
middle = _cbackend.middle if _cbackend is not None else _pybackend.middle
rotate = _cbackend.rotate if _cbackend is not None else _pybackend.rotate
reverse = _cbackend.reverse if _cbackend is not None else _pybackend.reverse
find = _cbackend.find if _cbackend is not None else _pybackend.find
count = _cbackend.count if _cbackend is not None else _pybackend.count
contains = _cbackend.contains if _cbackend is not None else _pybackend.contains
chunk = _cbackend.chunk if _cbackend is not None else _pybackend.chunk
window = _cbackend.window if _cbackend is not None else _pybackend.window
is_sorted = _cbackend.is_sorted if _cbackend is not None else _pybackend.is_sorted
