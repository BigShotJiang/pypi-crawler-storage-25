from __future__ import annotations

from typing import Any


def length(values: list[Any]) -> int:
    return len(values)


def is_empty(values: list[Any]) -> bool:
    return len(values) == 0


def first(values: list[Any]) -> Any:
    if not values:
        raise ValueError("smartarr.first() cannot operate on an empty sequence")
    return values[0]


def last(values: list[Any]) -> Any:
    if not values:
        raise ValueError("smartarr.last() cannot operate on an empty sequence")
    return values[-1]


def middle(values: list[Any], mode: str = "right") -> Any:
    if not values:
        raise ValueError("smartarr.middle() cannot operate on an empty sequence")
    if mode not in {"left", "right", "avg"}:
        raise ValueError("middle mode must be one of: right, left, avg")

    size = len(values)
    if size % 2 == 1:
        return values[size // 2]

    if mode == "left":
        return values[(size // 2) - 1]
    if mode == "right":
        return values[size // 2]

    return (values[(size // 2) - 1] + values[size // 2]) / 2


def rotate(values: list[Any], steps: int) -> list[Any]:
    if not values:
        return []
    steps = steps % len(values)
    if steps == 0:
        return list(values)
    return list(values[-steps:] + values[:-steps])


def reverse(values: list[Any]) -> list[Any]:
    return list(reversed(values))


def find(values: list[Any], needle: Any) -> int:
    for index, item in enumerate(values):
        if item == needle:
            return index
    return -1


def count(values: list[Any], needle: Any) -> int:
    total = 0
    for item in values:
        if item == needle:
            total += 1
    return total


def contains(values: list[Any], needle: Any) -> bool:
    return find(values, needle) != -1


def chunk(values: list[Any], size: int, drop_last: bool = False) -> list[list[Any]]:
    if size <= 0:
        raise ValueError("chunk size must be greater than 0")

    chunks = [values[index : index + size] for index in range(0, len(values), size)]
    if drop_last and chunks and len(chunks[-1]) < size:
        chunks.pop()
    return chunks


def window(values: list[Any], size: int, step: int = 1) -> list[list[Any]]:
    if size <= 0:
        raise ValueError("window size must be greater than 0")
    if step <= 0:
        raise ValueError("window step must be greater than 0")
    if size > len(values):
        return []

    return [
        values[index : index + size]
        for index in range(0, len(values) - size + 1, step)
    ]


def is_sorted(values: list[Any], reverse: bool = False) -> bool:
    if len(values) < 2:
        return True

    if reverse:
        return all(values[index - 1] >= values[index] for index in range(1, len(values)))
    return all(values[index - 1] <= values[index] for index in range(1, len(values)))
