from __future__ import annotations

import builtins
import functools
import math
import random as _random
import statistics
from typing import Any, Callable

from . import _backend
from .adapters import BaseAdapter, ListAdapter, is_numpy_array, resolve_adapter

_MISSING = object()


class SmartArray:
    """Chainable wrapper around array-like data."""

    def __init__(
        self,
        source: Any,
        *,
        _adapter: BaseAdapter | None = None,
        _normalized: bool = False,
    ) -> None:
        if isinstance(source, SmartArray):
            self._items = source.to_list()
            self._adapter = source._adapter
            return

        adapter = _adapter or resolve_adapter(source)
        self._adapter = adapter
        self._items = list(source) if _normalized else adapter.normalize(source)

    def __repr__(self) -> str:
        return (
            f"SmartArray({self._items!r}, adapter={self._adapter.name!r}, "
            f"backend={_backend.BACKEND_NAME!r})"
        )

    def __iter__(self):
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index: int) -> Any:
        return self._items[index]

    @property
    def backend(self) -> str:
        return _backend.BACKEND_NAME

    def to_list(self) -> list[Any]:
        return list(self._items)

    def to_native(self) -> Any:
        return self._adapter.restore(self.to_list())

    def copy(self) -> "SmartArray":
        return self._spawn(self._items)

    def first(self) -> Any:
        return _backend.first(self._items)

    def last(self) -> Any:
        return _backend.last(self._items)

    def middle(self, mode: str = "right") -> Any:
        return _backend.middle(self._items, mode)

    def rotate(self, steps: int) -> "SmartArray":
        return self._spawn(_backend.rotate(self._items, steps))

    def reverse(self) -> "SmartArray":
        return self._spawn(_backend.reverse(self._items))

    def len(self) -> int:
        return _backend.length(self._items)

    def is_empty(self) -> bool:
        return _backend.is_empty(self._items)

    def chunk(self, size: int, drop_last: bool = False) -> "SmartArray":
        return self._spawn(_backend.chunk(self._items, size, drop_last), preserve_adapter=False)

    def window(self, size: int, step: int = 1) -> "SmartArray":
        return self._spawn(_backend.window(self._items, size, step), preserve_adapter=False)

    def random(
        self,
        n: int | None = None,
        *,
        seed: int | None = None,
        replace: bool = False,
    ) -> Any:
        if self.is_empty():
            raise ValueError("smartarr.random() cannot operate on an empty sequence")

        rng = _random.Random(seed)
        if n is None:
            return rng.choice(self._items)
        if n < 0:
            raise ValueError("n must be non-negative")
        if replace:
            return self._spawn(rng.choices(self._items, k=n))
        if n > len(self._items):
            raise ValueError("n cannot be larger than the array length when replace=False")
        return self._spawn(rng.sample(self._items, n))

    def find(self, value: Any) -> int:
        return _backend.find(self._items, value)

    def count(self, value: Any) -> int:
        return _backend.count(self._items, value)

    def contains(self, value: Any) -> bool:
        return _backend.contains(self._items, value)

    def is_sorted(self, reverse: bool = False) -> bool:
        return _backend.is_sorted(self._items, reverse)

    def sorted(self, *, reverse: bool = False, key: Callable[[Any], Any] | None = None) -> "SmartArray":
        return self._spawn(builtins.sorted(self._items, key=key, reverse=reverse))

    def map(self, func: Callable[[Any], Any]) -> "SmartArray":
        return self._spawn([func(item) for item in self._items])

    def filter(self, func: Callable[[Any], bool]) -> "SmartArray":
        return self._spawn([item for item in self._items if func(item)])

    def reduce(self, func: Callable[[Any, Any], Any], initial: Any = _MISSING) -> Any:
        if initial is _MISSING:
            return functools.reduce(func, self._items)
        return functools.reduce(func, self._items, initial)

    def sum(self) -> Any:
        return builtins.sum(self._items)

    def mean(self) -> float:
        if self.is_empty():
            raise ValueError("smartarr.mean() cannot operate on an empty sequence")
        return statistics.mean(self._items)

    def median(self) -> Any:
        if self.is_empty():
            raise ValueError("smartarr.median() cannot operate on an empty sequence")
        return statistics.median(self._items)

    def min(self) -> Any:
        if self.is_empty():
            raise ValueError("smartarr.min() cannot operate on an empty sequence")
        return builtins.min(self._items)

    def max(self) -> Any:
        if self.is_empty():
            raise ValueError("smartarr.max() cannot operate on an empty sequence")
        return builtins.max(self._items)

    def peaks(self) -> "SmartArray":
        if len(self._items) < 3:
            return self._spawn([], preserve_adapter=False)

        peak_indexes = [
            index
            for index in range(1, len(self._items) - 1)
            if self._items[index] > self._items[index - 1] and self._items[index] > self._items[index + 1]
        ]
        return self._spawn(peak_indexes, preserve_adapter=False)

    def unique(self) -> "SmartArray":
        uniques: list[Any] = []
        for item in self._items:
            if not any(existing == item for existing in uniques):
                uniques.append(item)
        return self._spawn(uniques)

    def duplicates(self) -> "SmartArray":
        seen: list[Any] = []
        duplicates: list[Any] = []
        for item in self._items:
            if any(existing == item for existing in seen):
                if not any(existing == item for existing in duplicates):
                    duplicates.append(item)
            else:
                seen.append(item)
        return self._spawn(duplicates)

    def frequency(self) -> dict[Any, int]:
        counts: dict[Any, int] = {}
        for item in self._items:
            counts[item] = counts.get(item, 0) + 1
        return counts

    def flatten(self) -> "SmartArray":
        flattened = list(self._flatten_items(self._items))
        return self._spawn(flattened, preserve_adapter=False)

    def reshape(self, *shape: int | tuple[int, ...]) -> "SmartArray":
        if len(shape) == 1 and isinstance(shape[0], tuple):
            dims = shape[0]
        else:
            dims = shape

        if not dims:
            raise ValueError("reshape() requires at least one dimension")
        if any(not isinstance(dim, int) or dim <= 0 for dim in dims):
            raise ValueError("reshape() dimensions must be positive integers")

        flat = self.flatten().to_list()
        if math.prod(dims) != len(flat):
            raise ValueError("reshape() dimensions must match the flattened array length")

        iterator = iter(flat)

        def build(level: int) -> list[Any]:
            size = dims[level]
            if level == len(dims) - 1:
                return [next(iterator) for _ in range(size)]
            return [build(level + 1) for _ in range(size)]

        return self._spawn(build(0), preserve_adapter=False)

    def _spawn(self, values: list[Any], preserve_adapter: bool = True) -> "SmartArray":
        adapter = self._adapter if preserve_adapter else ListAdapter()
        return SmartArray(values, _adapter=adapter, _normalized=True)

    def _flatten_items(self, values: list[Any]):
        for item in values:
            if isinstance(item, SmartArray):
                yield from self._flatten_items(item.to_list())
            elif is_numpy_array(item):
                yield from self._flatten_items(item.tolist())
            elif isinstance(item, (list, tuple)):
                yield from self._flatten_items(list(item))
            else:
                yield item


def smart(source: Any) -> SmartArray:
    if isinstance(source, SmartArray):
        return source
    return SmartArray(source)
