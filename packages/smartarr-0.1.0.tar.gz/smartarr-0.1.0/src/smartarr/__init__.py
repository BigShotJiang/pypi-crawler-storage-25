from .api import SmartArray, smart

__all__ = ["SmartArray", "smart"]
__version__ = "0.1.0"
