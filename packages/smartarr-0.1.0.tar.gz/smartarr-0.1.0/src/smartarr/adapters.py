from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

try:
    import numpy as _np
except ImportError:  # pragma: no cover - optional dependency
    _np = None


@dataclass(frozen=True)
class BaseAdapter:
    name: str = "list"

    def normalize(self, value: Any) -> list[Any]:
        if isinstance(value, list):
            return list(value)
        if isinstance(value, Iterable):
            return list(value)
        raise TypeError("smartarr expects an iterable array-like input")

    def restore(self, values: list[Any]) -> Any:
        return list(values)


@dataclass(frozen=True)
class ListAdapter(BaseAdapter):
    name: str = "list"

    def restore(self, values: list[Any]) -> list[Any]:
        return list(values)


@dataclass(frozen=True)
class TupleAdapter(BaseAdapter):
    name: str = "tuple"

    def restore(self, values: list[Any]) -> tuple[Any, ...]:
        return tuple(values)


@dataclass(frozen=True)
class NumpyAdapter(BaseAdapter):
    dtype: Any = None
    name: str = "numpy"

    def normalize(self, value: Any) -> list[Any]:
        return value.tolist()

    def restore(self, values: list[Any]) -> Any:
        if _np is None:  # pragma: no cover - defensive fallback
            return list(values)
        return _np.array(values, dtype=self.dtype)


def is_numpy_array(value: Any) -> bool:
    return _np is not None and isinstance(value, _np.ndarray)


def resolve_adapter(value: Any) -> BaseAdapter:
    if isinstance(value, (str, bytes, bytearray)):
        raise TypeError("smartarr does not accept string-like inputs")

    if is_numpy_array(value):
        return NumpyAdapter(dtype=value.dtype)

    if isinstance(value, tuple):
        return TupleAdapter()

    if isinstance(value, list):
        return ListAdapter()

    if isinstance(value, Iterable):
        return ListAdapter()

    raise TypeError("smartarr expects an iterable array-like input")
