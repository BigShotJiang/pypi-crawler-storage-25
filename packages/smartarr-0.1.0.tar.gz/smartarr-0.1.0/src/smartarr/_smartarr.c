#define PY_SSIZE_T_CLEAN
#include <Python.h>


static PyObject *
smartarr_sequence_fast(PyObject *sequence, const char *message)
{
    return PySequence_Fast(sequence, message);
}


static int
smartarr_validate_mode(const char *mode)
{
    return strcmp(mode, "left") == 0 || strcmp(mode, "right") == 0 || strcmp(mode, "avg") == 0;
}


static PyObject *
smartarr_length(PyObject *self, PyObject *arg)
{
    PyObject *fast = smartarr_sequence_fast(arg, "smartarr.length() expects a sequence");
    Py_ssize_t size;

    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    Py_DECREF(fast);
    return PyLong_FromSsize_t(size);
}


static PyObject *
smartarr_is_empty(PyObject *self, PyObject *arg)
{
    PyObject *fast = smartarr_sequence_fast(arg, "smartarr.is_empty() expects a sequence");
    Py_ssize_t size;

    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    Py_DECREF(fast);

    if (size == 0) {
        Py_RETURN_TRUE;
    }

    Py_RETURN_FALSE;
}


static PyObject *
smartarr_first(PyObject *self, PyObject *arg)
{
    PyObject *fast = smartarr_sequence_fast(arg, "smartarr.first() expects a sequence");
    PyObject **items;
    Py_ssize_t size;

    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    if (size == 0) {
        Py_DECREF(fast);
        PyErr_SetString(PyExc_ValueError, "smartarr.first() cannot operate on an empty sequence");
        return NULL;
    }

    items = PySequence_Fast_ITEMS(fast);
    Py_INCREF(items[0]);
    Py_DECREF(fast);
    return items[0];
}


static PyObject *
smartarr_last(PyObject *self, PyObject *arg)
{
    PyObject *fast = smartarr_sequence_fast(arg, "smartarr.last() expects a sequence");
    PyObject **items;
    Py_ssize_t size;

    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    if (size == 0) {
        Py_DECREF(fast);
        PyErr_SetString(PyExc_ValueError, "smartarr.last() cannot operate on an empty sequence");
        return NULL;
    }

    items = PySequence_Fast_ITEMS(fast);
    Py_INCREF(items[size - 1]);
    Py_DECREF(fast);
    return items[size - 1];
}


static PyObject *
smartarr_middle(PyObject *self, PyObject *args, PyObject *kwargs)
{
    static char *kwlist[] = {"sequence", "mode", NULL};
    PyObject *sequence;
    PyObject *fast;
    PyObject **items;
    Py_ssize_t size;
    const char *mode = "right";

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O|s:middle", kwlist, &sequence, &mode)) {
        return NULL;
    }

    if (!smartarr_validate_mode(mode)) {
        PyErr_SetString(PyExc_ValueError, "middle mode must be one of: right, left, avg");
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.middle() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    if (size == 0) {
        Py_DECREF(fast);
        PyErr_SetString(PyExc_ValueError, "smartarr.middle() cannot operate on an empty sequence");
        return NULL;
    }

    items = PySequence_Fast_ITEMS(fast);
    if (size % 2 == 1) {
        PyObject *result = items[size / 2];
        Py_INCREF(result);
        Py_DECREF(fast);
        return result;
    }

    if (strcmp(mode, "left") == 0) {
        PyObject *result = items[(size / 2) - 1];
        Py_INCREF(result);
        Py_DECREF(fast);
        return result;
    }

    if (strcmp(mode, "right") == 0) {
        PyObject *result = items[size / 2];
        Py_INCREF(result);
        Py_DECREF(fast);
        return result;
    }

    {
        PyObject *sum = PyNumber_Add(items[(size / 2) - 1], items[size / 2]);
        PyObject *two;
        PyObject *result;

        if (sum == NULL) {
            Py_DECREF(fast);
            return NULL;
        }

        two = PyLong_FromLong(2);
        if (two == NULL) {
            Py_DECREF(sum);
            Py_DECREF(fast);
            return NULL;
        }

        result = PyNumber_TrueDivide(sum, two);
        Py_DECREF(two);
        Py_DECREF(sum);
        Py_DECREF(fast);
        return result;
    }
}


static PyObject *
smartarr_rotate(PyObject *self, PyObject *args)
{
    PyObject *sequence;
    PyObject *fast;
    PyObject *result;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t steps;
    Py_ssize_t index;
    Py_ssize_t source_index;

    if (!PyArg_ParseTuple(args, "On:rotate", &sequence, &steps)) {
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.rotate() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    if (size == 0) {
        Py_DECREF(fast);
        return PyList_New(0);
    }

    steps %= size;
    if (steps < 0) {
        steps += size;
    }

    items = PySequence_Fast_ITEMS(fast);
    result = PyList_New(size);
    if (result == NULL) {
        Py_DECREF(fast);
        return NULL;
    }

    for (index = 0; index < size; index++) {
        source_index = (index - steps + size) % size;
        Py_INCREF(items[source_index]);
        PyList_SET_ITEM(result, index, items[source_index]);
    }

    Py_DECREF(fast);
    return result;
}


static PyObject *
smartarr_reverse(PyObject *self, PyObject *arg)
{
    PyObject *fast = smartarr_sequence_fast(arg, "smartarr.reverse() expects a sequence");
    PyObject *result;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t index;

    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    items = PySequence_Fast_ITEMS(fast);
    result = PyList_New(size);
    if (result == NULL) {
        Py_DECREF(fast);
        return NULL;
    }

    for (index = 0; index < size; index++) {
        Py_INCREF(items[size - index - 1]);
        PyList_SET_ITEM(result, index, items[size - index - 1]);
    }

    Py_DECREF(fast);
    return result;
}


static PyObject *
smartarr_find(PyObject *self, PyObject *args)
{
    PyObject *sequence;
    PyObject *needle;
    PyObject *fast;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t index;
    int equal;

    if (!PyArg_ParseTuple(args, "OO:find", &sequence, &needle)) {
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.find() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    items = PySequence_Fast_ITEMS(fast);

    for (index = 0; index < size; index++) {
        equal = PyObject_RichCompareBool(items[index], needle, Py_EQ);
        if (equal < 0) {
            Py_DECREF(fast);
            return NULL;
        }
        if (equal == 1) {
            Py_DECREF(fast);
            return PyLong_FromSsize_t(index);
        }
    }

    Py_DECREF(fast);
    return PyLong_FromLong(-1);
}


static PyObject *
smartarr_count(PyObject *self, PyObject *args)
{
    PyObject *sequence;
    PyObject *needle;
    PyObject *fast;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t index;
    Py_ssize_t total = 0;
    int equal;

    if (!PyArg_ParseTuple(args, "OO:count", &sequence, &needle)) {
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.count() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    items = PySequence_Fast_ITEMS(fast);

    for (index = 0; index < size; index++) {
        equal = PyObject_RichCompareBool(items[index], needle, Py_EQ);
        if (equal < 0) {
            Py_DECREF(fast);
            return NULL;
        }
        if (equal == 1) {
            total++;
        }
    }

    Py_DECREF(fast);
    return PyLong_FromSsize_t(total);
}


static PyObject *
smartarr_contains(PyObject *self, PyObject *args)
{
    PyObject *sequence;
    PyObject *needle;
    PyObject *fast;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t index;
    int equal;

    if (!PyArg_ParseTuple(args, "OO:contains", &sequence, &needle)) {
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.contains() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    items = PySequence_Fast_ITEMS(fast);

    for (index = 0; index < size; index++) {
        equal = PyObject_RichCompareBool(items[index], needle, Py_EQ);
        if (equal < 0) {
            Py_DECREF(fast);
            return NULL;
        }
        if (equal == 1) {
            Py_DECREF(fast);
            Py_RETURN_TRUE;
        }
    }

    Py_DECREF(fast);
    Py_RETURN_FALSE;
}


static PyObject *
smartarr_chunk(PyObject *self, PyObject *args, PyObject *kwargs)
{
    static char *kwlist[] = {"sequence", "size", "drop_last", NULL};
    PyObject *sequence;
    PyObject *fast;
    PyObject *outer;
    PyObject *inner;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t chunk_size;
    Py_ssize_t position = 0;
    Py_ssize_t outer_index = 0;
    int drop_last = 0;

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "On|p:chunk", kwlist, &sequence, &chunk_size, &drop_last)) {
        return NULL;
    }

    if (chunk_size <= 0) {
        PyErr_SetString(PyExc_ValueError, "chunk size must be greater than 0");
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.chunk() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    items = PySequence_Fast_ITEMS(fast);

    if (size == 0) {
        Py_DECREF(fast);
        return PyList_New(0);
    }

    {
        Py_ssize_t full_chunks = size / chunk_size;
        Py_ssize_t remainder = size % chunk_size;
        Py_ssize_t total_chunks = full_chunks + ((remainder != 0 && !drop_last) ? 1 : 0);

        outer = PyList_New(total_chunks);
        if (outer == NULL) {
            Py_DECREF(fast);
            return NULL;
        }
    }

    while (position < size) {
        Py_ssize_t remaining = size - position;
        Py_ssize_t current_size = remaining < chunk_size ? remaining : chunk_size;
        Py_ssize_t inner_index;

        if (remaining < chunk_size && drop_last) {
            break;
        }

        inner = PyList_New(current_size);
        if (inner == NULL) {
            Py_DECREF(outer);
            Py_DECREF(fast);
            return NULL;
        }

        for (inner_index = 0; inner_index < current_size; inner_index++) {
            Py_INCREF(items[position + inner_index]);
            PyList_SET_ITEM(inner, inner_index, items[position + inner_index]);
        }

        PyList_SET_ITEM(outer, outer_index, inner);
        outer_index++;
        position += chunk_size;
    }

    Py_DECREF(fast);
    return outer;
}


static PyObject *
smartarr_window(PyObject *self, PyObject *args, PyObject *kwargs)
{
    static char *kwlist[] = {"sequence", "size", "step", NULL};
    PyObject *sequence;
    PyObject *fast;
    PyObject *outer;
    PyObject *inner;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t window_size;
    Py_ssize_t step = 1;
    Py_ssize_t start;
    Py_ssize_t outer_index = 0;

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "On|n:window", kwlist, &sequence, &window_size, &step)) {
        return NULL;
    }

    if (window_size <= 0) {
        PyErr_SetString(PyExc_ValueError, "window size must be greater than 0");
        return NULL;
    }
    if (step <= 0) {
        PyErr_SetString(PyExc_ValueError, "window step must be greater than 0");
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.window() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    items = PySequence_Fast_ITEMS(fast);

    if (window_size > size) {
        Py_DECREF(fast);
        return PyList_New(0);
    }

    {
        Py_ssize_t total_windows = 1 + ((size - window_size) / step);
        outer = PyList_New(total_windows);
        if (outer == NULL) {
            Py_DECREF(fast);
            return NULL;
        }
    }

    for (start = 0; start + window_size <= size; start += step) {
        Py_ssize_t inner_index;

        inner = PyList_New(window_size);
        if (inner == NULL) {
            Py_DECREF(outer);
            Py_DECREF(fast);
            return NULL;
        }

        for (inner_index = 0; inner_index < window_size; inner_index++) {
            Py_INCREF(items[start + inner_index]);
            PyList_SET_ITEM(inner, inner_index, items[start + inner_index]);
        }

        PyList_SET_ITEM(outer, outer_index, inner);
        outer_index++;
    }

    Py_DECREF(fast);
    return outer;
}


static PyObject *
smartarr_is_sorted(PyObject *self, PyObject *args, PyObject *kwargs)
{
    static char *kwlist[] = {"sequence", "reverse", NULL};
    PyObject *sequence;
    PyObject *fast;
    PyObject **items;
    Py_ssize_t size;
    Py_ssize_t index;
    int reverse = 0;
    int comparison;
    int operator_id = Py_LE;

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O|p:is_sorted", kwlist, &sequence, &reverse)) {
        return NULL;
    }

    fast = smartarr_sequence_fast(sequence, "smartarr.is_sorted() expects a sequence");
    if (fast == NULL) {
        return NULL;
    }

    size = PySequence_Fast_GET_SIZE(fast);
    if (size < 2) {
        Py_DECREF(fast);
        Py_RETURN_TRUE;
    }

    items = PySequence_Fast_ITEMS(fast);
    if (reverse) {
        operator_id = Py_GE;
    }

    for (index = 1; index < size; index++) {
        comparison = PyObject_RichCompareBool(items[index - 1], items[index], operator_id);
        if (comparison < 0) {
            Py_DECREF(fast);
            return NULL;
        }
        if (comparison == 0) {
            Py_DECREF(fast);
            Py_RETURN_FALSE;
        }
    }

    Py_DECREF(fast);
    Py_RETURN_TRUE;
}


static PyMethodDef smartarr_methods[] = {
    {"length", (PyCFunction) smartarr_length, METH_O, "Return the sequence length."},
    {"is_empty", (PyCFunction) smartarr_is_empty, METH_O, "Return True when the sequence is empty."},
    {"first", (PyCFunction) smartarr_first, METH_O, "Return the first item."},
    {"last", (PyCFunction) smartarr_last, METH_O, "Return the last item."},
    {"middle", (PyCFunction) smartarr_middle, METH_VARARGS | METH_KEYWORDS, "Return the middle item."},
    {"rotate", (PyCFunction) smartarr_rotate, METH_VARARGS, "Rotate the sequence to the right."},
    {"reverse", (PyCFunction) smartarr_reverse, METH_O, "Return a reversed copy."},
    {"find", (PyCFunction) smartarr_find, METH_VARARGS, "Find the first matching index."},
    {"count", (PyCFunction) smartarr_count, METH_VARARGS, "Count matching items."},
    {"contains", (PyCFunction) smartarr_contains, METH_VARARGS, "Check whether an item exists."},
    {"chunk", (PyCFunction) smartarr_chunk, METH_VARARGS | METH_KEYWORDS, "Split into chunks."},
    {"window", (PyCFunction) smartarr_window, METH_VARARGS | METH_KEYWORDS, "Return sliding windows."},
    {"is_sorted", (PyCFunction) smartarr_is_sorted, METH_VARARGS | METH_KEYWORDS, "Check sort order."},
    {NULL, NULL, 0, NULL}
};


static struct PyModuleDef smartarrmodule = {
    PyModuleDef_HEAD_INIT,
    "_smartarr",
    "Optional C backend for smartarr.",
    -1,
    smartarr_methods
};


PyMODINIT_FUNC
PyInit__smartarr(void)
{
    return PyModule_Create(&smartarrmodule);
}
