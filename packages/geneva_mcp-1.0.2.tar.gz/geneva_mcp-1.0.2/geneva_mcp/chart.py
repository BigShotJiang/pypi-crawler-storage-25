"""
Geneva MCP — Headless chart builder.

Generates a forecast visualization as a base64-encoded PNG that can be
returned to AI agents via MCP ImageContent.  Optimized for Claude Desktop's
inline rendering (<750KB raw, max 1024px dimension).
"""

from __future__ import annotations

import base64
import io
from typing import Optional

import matplotlib
matplotlib.use("Agg")  # headless — no display window

import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker as ticker  # noqa: E402

from geneva_forecast.models import ForecastResult  # noqa: E402


# ── Color palette ────────────────────────────────────────────────────

_C_TRAIN = "#2c3e50"
_C_FITTED = "#e67e22"
_C_FORECAST = "#e74c3c"
_C_BAND = "#3498db"


def build_forecast_chart(
    historical_data: list[float],
    result: ForecastResult,
    *,
    confidence_level: Optional[float] = None,
) -> tuple[str, str]:
    """Build a forecast chart and return as base64-encoded PNG.

    Returns a compact PNG image (<750KB) suitable for Claude Desktop
    inline rendering via MCP ImageContent.

    Returns
    -------
    tuple[str, str]
        (base64_data, mime_type) — always PNG.
    """
    n_hist = len(historical_data)
    hist_x = list(range(1, n_hist + 1))

    # Forecast points
    forecast_vals = [pt.value for pt in result.forecast] if result.forecast else []
    n_forecast = len(forecast_vals)
    forecast_x = list(range(n_hist + 1, n_hist + n_forecast + 1))

    # Fitted values
    fitted_vals = [pt.value for pt in result.fitted] if result.fitted else []
    fitted_x = [pt.period for pt in result.fitted] if result.fitted else []

    # Prediction intervals
    has_intervals = result.prediction_intervals is not None and len(result.prediction_intervals) > 0
    if has_intervals:
        lower_band = [pt.lower for pt in result.prediction_intervals]
        upper_band = [pt.upper for pt in result.prediction_intervals]
    else:
        lower_band, upper_band = [], []

    # ── Build the figure ────────────────────────────────────────────
    # 10x5 inches @ 100dpi = 1000x500px (within 1024px limit)
    plt.style.use("seaborn-v0_8-darkgrid")
    fig, ax = plt.subplots(figsize=(10, 5))

    # Historical data
    ax.plot(
        hist_x, historical_data,
        color=_C_TRAIN, linewidth=1.6, label="Historical Data",
        marker=".", markersize=3, zorder=3,
    )

    # Fitted values
    if fitted_vals:
        ax.plot(
            fitted_x, fitted_vals,
            color=_C_FITTED, linewidth=1.2, linestyle="--",
            label="Fitted (In-sample)", alpha=0.7, zorder=2,
        )

    # Forecast line
    if forecast_vals:
        ax.plot(
            forecast_x, forecast_vals,
            color=_C_FORECAST, linewidth=2.2, label="Forecast",
            marker="o", markersize=5, zorder=4,
        )

    # Prediction interval bands
    if lower_band and upper_band:
        conf_pct = f"{confidence_level * 100:.0f}%" if confidence_level else "95%"
        ax.fill_between(
            forecast_x, lower_band, upper_band,
            color=_C_BAND, alpha=0.20,
            label=f"{conf_pct} Prediction Interval",
            zorder=1,
        )
        ax.plot(forecast_x, lower_band, color=_C_BAND, linewidth=0.8, linestyle=":", alpha=0.6)
        ax.plot(forecast_x, upper_band, color=_C_BAND, linewidth=0.8, linestyle=":", alpha=0.6)

    # Vertical divider
    ax.axvline(
        x=n_hist + 0.5, color="#7f8c8d", linestyle="-.",
        linewidth=1.0, alpha=0.6,
    )

    # ── Info box annotation ─────────────────────────────────────────
    info_lines = []
    if result.model_info:
        info_lines.append(f"Model: {result.model_info.method_name}")
        if result.model_info.transform_name and result.model_info.transform_name != "None":
            info_lines.append(f"Transform: {result.model_info.transform_name}")
    if result.metrics:
        info_lines.append(
            f"MAD: {result.metrics.mad:.2f}  |  "
            f"MAPE: {result.metrics.mape:.2f}%  |  "
            f"RMSE: {result.metrics.rmse:.2f}"
        )
    if result.prediction_interval_info:
        pi = result.prediction_interval_info
        info_lines.append(
            f"Band Width: ±{pi.interval_width / 2:.2f}  "
            f"({pi.calibration_residuals} residuals)"
        )

    if info_lines:
        ax.text(
            0.02, 0.97, "\n".join(info_lines),
            transform=ax.transAxes, fontsize=8,
            verticalalignment="top", fontfamily="monospace",
            bbox=dict(
                boxstyle="round,pad=0.5",
                facecolor="white", alpha=0.85,
                edgecolor="#bdc3c7",
            ),
        )

    # Labels
    ax.set_title(
        "Geneva Forecast — Time Series Analysis",
        fontsize=13, fontweight="bold", pad=12,
    )
    ax.set_xlabel("Period", fontsize=10)
    ax.set_ylabel("Value", fontsize=10)
    ax.legend(loc="lower left", fontsize=8, framealpha=0.9)

    # Format large numbers with commas
    ax.yaxis.set_major_formatter(ticker.FuncFormatter(
        lambda x, _: f"{x:,.0f}" if abs(x) >= 1000 else f"{x:.1f}"
    ))

    plt.tight_layout()

    # ── Encode as PNG ────────────────────────────────────────────────
    # Claude Desktop needs <750KB raw image for inline rendering.
    # PNG at 100dpi for these line charts is typically 40-120KB.
    buf = io.BytesIO()
    fig.savefig(
        buf, format="png", dpi=100, bbox_inches="tight", facecolor="white",
    )
    plt.close(fig)
    buf.seek(0)

    b64_str = base64.b64encode(buf.read()).decode("utf-8")
    return b64_str, "image/png"
