"""Geneva MCP Server — AI agent tools for the Geneva Forecasting Engine."""

__version__ = "1.0.1"


def main():
    """Entry point for the `geneva-mcp` console script."""
    from .server import mcp
    mcp.run()
