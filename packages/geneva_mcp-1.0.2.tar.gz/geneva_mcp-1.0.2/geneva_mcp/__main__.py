"""Entry point for `python -m geneva_mcp` and `geneva-mcp` CLI."""

from .server import mcp


def main():
    """Run the Geneva MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
