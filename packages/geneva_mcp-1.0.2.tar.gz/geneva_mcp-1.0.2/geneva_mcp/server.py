"""
Geneva MCP Server — Forecast tool for AI agents.

Exposes the Geneva Forecasting Engine as an MCP tool that returns
structured forecast data so agents can provide analysis with inline
visualizations.
"""

from __future__ import annotations

import base64
import os
from typing import Optional

from mcp.server.fastmcp import FastMCP
from mcp.types import CallToolResult, TextContent, ImageContent

from geneva_forecast import GenevaClient
from geneva_forecast.exceptions import GenevaAPIError, GenevaConnectionError

from .chart import build_forecast_chart

# ── MCP server instance ─────────────────────────────────────────────

mcp = FastMCP(
    "Geneva Forecasting Engine",
    instructions=(
        "You are connected to the Geneva Forecasting Engine, a high-performance "
        "statistical forecasting system. Use the forecast tool when a user provides "
        "time series data and wants predictions for future periods.\n\n"
        "When presenting forecast results:\n"
        "1. Create a simple inline line chart showing historical values and forecast "
        "values as two connected lines. Keep it minimal — just the data lines, no "
        "confidence bands, no dashboard, no React artifacts, no code blocks. "
        "Use your native inline visualization capability only.\n"
        "2. Below the chart, provide a concise written analysis covering: model "
        "selected, MAPE accuracy, key trends, seasonality, and confidence intervals.\n"
        "3. A detailed chart with confidence bands is also attached as an image in "
        "the tool result (users can expand the tool call to see it)."
    ),
)

# ── Lazy client singleton ────────────────────────────────────────────

_client: Optional[GenevaClient] = None


def _get_client() -> GenevaClient:
    """Get or create the GenevaClient from environment variables."""
    global _client
    if _client is None:
        api_url = os.environ.get("GENEVA_API_URL", "http://localhost:8000")
        api_key = os.environ.get("GENEVA_API_KEY", "")
        if not api_key:
            raise RuntimeError(
                "GENEVA_API_KEY environment variable is not set. "
                "Configure it in your MCP server settings."
            )
        _client = GenevaClient(api_url=api_url, api_key=api_key)
    return _client



# ── Forecast tool ────────────────────────────────────────────────────

@mcp.tool()
def forecast(
    data: list[float],
    horizon: int | None = None,
    wave_periods: list[int] | None = None,
    confidence_level: float = 0.95,
    method: int | None = None,
    seasonal_transform: int = 0,
    smoothing: bool = False,
    max_periods_factor: float | None = None,
    holdout_ratio: float | None = None,
) -> CallToolResult:
    """Run the Geneva Forecasting Engine on a time series and return forecast results.

    Use this tool when the user has numerical time series data (e.g., monthly
    sales, daily temperatures, quarterly revenue) and wants to predict future
    values. The Geneva Expert System automatically selects the best forecasting
    model from 10 methods including exponential smoothing, Holt-Winters, and
    regression models.

    Parameters
    ----------
    data : list[float]
        Time series observations. Minimum 3 data points, maximum 10,000.
        These should be sequential, evenly-spaced numerical values.
    horizon : int, optional
        Number of future periods to forecast. Default: one full seasonal
        cycle (e.g., 12 for monthly data). For monthly data, 18 is a
        good choice. For quarterly, 8. For weekly, 13.
    wave_periods : list[int], optional
        Seasonal cycle lengths. IMPORTANT — set this correctly for your data:
        - [12] for monthly data (default)
        - [4] for quarterly data
        - [52] for weekly data
        - [7] for daily data
        - [24] for hourly data
        - [1] for yearly/non-seasonal data
    confidence_level : float
        Prediction interval confidence (0.0 to 1.0). Default 0.95 gives
        95% prediction intervals. Higher = wider bands, more confidence.
    method : int, optional
        Force a specific forecasting method (0–9). Omit to let the Expert
        System auto-select the best model. Methods: 0=LinearReg,
        1-5=NonLinearReg, 6=SES, 7=DES (Double Exponential Smoothing),
        8=HoltWinters, 9=Croston. Expert System (default) tries all and
        picks the best fit.
    seasonal_transform : int
        Seasonal transform to apply: 0=None (default), 1=Seasonal,
        2=MPT (Moving Periodic Total). Use 1 or 2 for strongly seasonal
        data to improve forecast accuracy.
    smoothing : bool
        Enable median data smoothing (3-period window). Useful for noisy
        data. Default: False.
    max_periods_factor : float, optional
        Controls the fit window cap (nPPC × MPF). Higher values give the
        model more holdout data for evaluation, which can improve accuracy
        on long series. Default: engine default (1.5). Use 10+ for long
        series. Max: 100.
    holdout_ratio : float, optional
        Fraction of data reserved for model evaluation (e.g., 0.333).
        Default: engine default (1/3).

    Returns
    -------
    CallToolResult
        Contains a text summary with forecast values, accuracy metrics,
        model info, and prediction intervals.
    """

    if wave_periods is None:
        wave_periods = [12]

    # ── Call the Geneva API ──────────────────────────────────────────
    try:
        client = _get_client()

        # Build base kwargs (shared between Expert and fallback calls)
        base_kwargs = dict(
            data=data,
            wave_periods=wave_periods,
            confidence_level=confidence_level,
            include=["forecast", "fitted", "metrics", "model_info", "prediction_intervals"],
        )
        if horizon is not None:
            base_kwargs["horizon"] = horizon
        if seasonal_transform != 0:
            base_kwargs["seasonal_transform"] = seasonal_transform
        if smoothing:
            base_kwargs["smoothing"] = smoothing
        if max_periods_factor is not None:
            base_kwargs["max_periods_factor"] = max_periods_factor
        if holdout_ratio is not None:
            base_kwargs["holdout_ratio"] = holdout_ratio

        # ── Step 1: Run Expert System (method=None → -E flag) ────────
        if method is not None:
            # User explicitly chose a method — respect that, no fallback
            result = client.forecast(**base_kwargs, method=method)
        else:
            # Run Expert System first
            result = client.forecast(**base_kwargs)

            # ── Step 2: Quality gate — check if Expert picked well ───
            # If Expert chose a non-seasonal model on clearly seasonal
            # data, try Holt-Winters (method=8) and compare.
            # Non-seasonal methods: 0=LinearReg, 1-5=NonLinearReg,
            #                       6=SES, 9=Croston
            # Seasonal methods:     7=DES, 8=HoltWinters
            _NON_SEASONAL = {0, 1, 2, 3, 4, 5, 6, 9}
            min_seasonal_points = 2 * max(wave_periods)  # need ≥2 cycles

            expert_is_non_seasonal = (
                result.model_info is not None
                and result.model_info.method_id in _NON_SEASONAL
            )
            data_has_enough_for_seasonal = len(data) >= min_seasonal_points

            if expert_is_non_seasonal and data_has_enough_for_seasonal:
                # Try Holt-Winters as fallback
                try:
                    hw_result = client.forecast(**base_kwargs, method=8)

                    # Compare MAPE — pick whichever is more accurate
                    expert_mape = result.metrics.mape if result.metrics else 999
                    hw_mape = hw_result.metrics.mape if hw_result.metrics else 999

                    if hw_mape <= expert_mape:
                        result = hw_result
                except Exception:
                    pass  # Expert result is fine, keep it

    except GenevaConnectionError as exc:
        return CallToolResult(content=[TextContent(
            type="text",
            text=f"❌ Could not connect to the Geneva API: {exc}\n\n"
                 f"Make sure the engine is running and GENEVA_API_URL is correct.",
        )])
    except GenevaAPIError as exc:
        msg = f"❌ Geneva API error (HTTP {exc.status_code}): {exc.message}"
        if exc.status_code == 429:
            msg += "\n\nRate limit reached — try again in a moment."
        elif exc.status_code == 403:
            msg += "\n\nAccess denied — check your API key and plan tier."
        return CallToolResult(content=[TextContent(type="text", text=msg)])
    except Exception as exc:
        return CallToolResult(content=[TextContent(
            type="text",
            text=f"❌ Unexpected error: {type(exc).__name__}: {exc}",
        )])

    # ── Build text summary ──────────────────────────────────────────
    lines = ["## Geneva Forecast Results\n"]

    if result.model_info:
        mi = result.model_info
        lines.append(f"**Model:** {mi.method_name}")
        lines.append(f"**Transform:** {mi.transform_name}")
        lines.append(f"**Smoothing:** {'Yes' if mi.smoothing else 'No'}")
        lines.append("")

    if result.metrics:
        m = result.metrics
        lines.append(f"**Accuracy Metrics:**")
        lines.append(f"- MAD: {m.mad:.4f}")
        lines.append(f"- MAPE: {m.mape:.2f}%")
        lines.append(f"- RMSE: {m.rmse:.4f}")
        lines.append("")

    if result.forecast:
        lines.append(f"**Forecast ({len(result.forecast)} periods):**")
        lines.append("")
        lines.append("| Period | Value |")
        lines.append("|--------|-------|")
        for pt in result.forecast:
            lines.append(f"| {pt.period} | {pt.value:.4f} |")
        lines.append("")

    if result.prediction_intervals:
        conf_pct = confidence_level * 100
        lines.append(f"**Prediction Intervals ({conf_pct:.0f}% confidence):**")
        lines.append("")
        lines.append("| Period | Forecast | Lower | Upper |")
        lines.append("|--------|----------|-------|-------|")
        for pt in result.prediction_intervals:
            lines.append(f"| {pt.period} | {pt.forecast:.4f} | {pt.lower:.4f} | {pt.upper:.4f} |")
        lines.append("")

    if result.prediction_interval_info:
        pi = result.prediction_interval_info
        lines.append(f"**Interval Info:** width ±{pi.interval_width/2:.4f}, "
                      f"{pi.calibration_residuals} calibration residuals")
        if pi.low_residual_warning:
            lines.append(f"⚠️ {pi.low_residual_warning}")

    # ── Build chart image ──────────────────────────────────────────
    chart_b64 = None
    chart_mime = "image/png"
    try:
        chart_b64, chart_mime = build_forecast_chart(
            historical_data=data,
            result=result,
            confidence_level=confidence_level,
        )
    except Exception:
        pass

    # ── Assemble response ─────────────────────────────────────────────
    # IMPORTANT: ImageContent MUST come first in the content array.
    # Claude Desktop only renders images inline when they appear before
    # text in the multi-part response.
    text_summary = "\n".join(lines)
    content: list = []
    if chart_b64:
        content.append(ImageContent(type="image", data=chart_b64, mimeType=chart_mime))
    content.append(TextContent(type="text", text=text_summary))

    return CallToolResult(content=content)

