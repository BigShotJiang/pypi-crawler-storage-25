from MohitJan.utils.formatter import console, create_panel, print_header
from rich.table import Table

def display_certifications():
    print_header("Licenses & Certifications")
    
    table = Table(show_header=True, header_style="bold magenta", expand=True)
    table.add_column("Category", style="cyan", width=20)
    table.add_column("Certificate / License Name", style="white")
    
    table.add_row("Licenses", "2024 Certified Data Scientist Certification by IABAC\n2024 Certified Data Scientist Certification by NASSCOM")
    table.add_row("Certifications", "[2023] Certified Data Science (IABAC) Course at Data Mites Bangalore\n[2022] Python, AI, ML, DL Certification - CourseIBuy ISO Education\n[2021] Data Science with Python - Remark Skill Education\n[2021] Internship - Data Science in Python (Remark Skill Edu, Delhi)\n[2020] Java Programming - KICIT Nagpur\n[2019] C Programming - KICIT Nagpur")
    
    panel = create_panel(table, title="Credentials & Honors", expand=True)
    console.print(panel)
