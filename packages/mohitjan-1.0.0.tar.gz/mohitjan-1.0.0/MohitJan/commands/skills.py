from MohitJan.utils.formatter import console, create_panel, print_header
from rich.table import Table

def display_skills():
    print_header("Skills Repository")
    
    table = Table(show_header=True, header_style="bold magenta", expand=True)
    table.add_column("Category", style="cyan", width=35)
    table.add_column("Skills", style="white")
    
    table.add_row("Programming Languages", "Python, R, C, Java")
    table.add_row("Machine Learning", "Supervised (Regression: Linear, SVR, DT | Classification: Logistic, SVM, RF, XGBoost, AdaBoost, KNN, Naive Bayes)\nUnsupervised (K-Means Clustering, PCA)")
    table.add_row("IDE / Platforms", "Jupyter, Colab, Visual Studio, NetBeans, VS Code")
    table.add_row("Deep Learning & NLP", "ANN (Feedforward, MLP), CNN (Image Classification, Object Detection), Time Series (RNN, LSTM)\nNLP: Sentiment Analysis, Tokenization, Classification, Transformers")
    table.add_row("Visualization", "Matplotlib, Seaborn, PowerBI")
    table.add_row("Libraries & Frameworks", "Pandas, NumPy, Scikit-Learn, TensorFlow, Keras, Hugging Face")
    table.add_row("Statistical Analysis", "Hypothesis Testing, A/B Testing")
    table.add_row("Database & Big Data", "MySQL, SQLite, MongoDB, Hadoop, Spark, Kafka")
    table.add_row("Git Version Control", "Git, Git Bash")
    table.add_row("Cloud Platforms", "AWS, Azure")
    table.add_row("Business Strategy & Product", "Strategic Planning, Technology Strategy, AI Product Strategy, Business Model Analysis, Customer Success, Product Roadmapping, Project Management")
    table.add_row("Business Analytics", "Business Intelligence, Data-Driven Decision Making, KPI & Market Analysis, Performance Metrics, Forecasting & Trend Analysis, Insights Generation")
    table.add_row("Business Communication", "Stakeholder Communication, Business Requirement Analysis, Cross-Functional Collaboration, Data Storytelling, Presentation of Insights")
    
    panel = create_panel(table, title="Technical & Business Skills", expand=True)
    console.print(panel)
