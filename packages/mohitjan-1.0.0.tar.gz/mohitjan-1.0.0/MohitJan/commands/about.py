from MohitJan.utils.formatter import console, create_panel, print_header
from rich.text import Text

def display_about():
    print_header("Profile Summary")
    content = Text()
    
    content.append("I am a skilled Certified Data Scientist with 3-4 years of hands-on experience applying machine learning, deep learning and advanced analytics to solve real-world business problems.\n\n", style="white")
    content.append("I hold a Bachelor of Engineering in Information Technology and am currently pursuing an MBA in Business Analytics, which further strengthens my analytical and business acumen.\n\n", style="white")
    content.append("I am proficient in Python, SQL, TensorFlow and a wide range of AI technologies. I have a strong foundation in designing and developing machine learning systems, implementing algorithms and conducting experiments.\n\n", style="white")
    content.append("My expertise includes working with large-scale data to extract actionable insights that drive business decisions. I am adept at techniques such as Linear Regression, Logistic Regression, Classification, Cluster Analysis, Forecasting and Text Mining. Additionally, I am familiar with pre-trained models, embeddings and their use cases for advanced AI applications.\n\n", style="white")
    content.append("Furthermore, I have experience working with cloud-based machine learning services, especially on Azure, and approach projects with a consultative mindset to effectively engage client stakeholders. Passionate about solving complex problems, I strive to deliver innovative data-driven solutions across diverse industries.\n\n", style="white")
    content.append("I am eager to take on challenging roles where I can build intelligent solutions that create meaningful impact, in environments that value innovation and professional growth. I look forward to further developing my expertise and contributing to impactful data science initiatives.\n", style="white")
    
    panel = create_panel(content, title="About Me", expand=False)
    console.print(panel)
