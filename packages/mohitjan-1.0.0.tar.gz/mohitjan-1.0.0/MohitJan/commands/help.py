from MohitJan.utils.formatter import console, create_panel, print_header
from rich.table import Table

def display_help():
    print_header("Available Commands")
    
    table = Table(show_header=True, header_style="bold magenta", expand=True)
    table.add_column("Command", style="bold blue", width=25)
    table.add_column("Description", style="white")
    
    table.add_row("help", "List all available output commands")
    table.add_row("about", "Profile summary, experience, and education")
    table.add_row("skills", "Technical abilities categorized")
    table.add_row("internships_projects", "Internships and significant projects")
    table.add_row("certifications", "Licenses and certifications")
    table.add_row("recent_participation", "Recent competitions and extracurriculars")
    table.add_row("contact", "Social media handles and email")
    table.add_row("clear", "Clear the terminal screen")
    table.add_row("exit / quit", "Exit the portfolio CLI")
    
    panel = create_panel(table, title="Navigation", expand=False)
    console.print(panel)
