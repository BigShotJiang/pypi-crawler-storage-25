from MohitJan.utils.formatter import console, create_panel, print_header
from rich.text import Text

def display_participation():
    print_header("Recent Participation")
    
    content = Text()
    content.append("Event: ", style="bold magenta")
    content.append("World Audio Visual & Entertainment Summit (WAVES 2025)\n\n", style="bold cyan")
    content.append("Contribution:\n", style="bold green")
    content.append("Participated in the WAVES Anti-Piracy Challenge 2025, part of the prestigious World Audio Visual & Entertainment Summit.\n\n", style="white")
    content.append("Submitted a concept focused on enhancing digital content security and protecting intellectual property in the streaming and content creation ecosystem.\n\n", style="white")
    content.append("WAVES aims to establish India as a global leader in media & entertainment, promoting innovation, digital rights protection, and cultural diversity across platforms.", style="white")
    
    panel = create_panel(content, title="Extracurricular & Competitions", expand=False)
    console.print(panel)
