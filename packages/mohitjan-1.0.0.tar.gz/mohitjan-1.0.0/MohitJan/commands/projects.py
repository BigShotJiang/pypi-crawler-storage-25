from MohitJan.utils.formatter import console, create_panel, print_header
from rich.console import Group
from rich.panel import Panel
from rich.text import Text

def get_project_text(desc, tech=None):
    text = Text()
    text.append(f"{desc}\n", style="white")
    if tech:
        text.append("Details / Tech: ", style="bold yellow")
        text.append(f"{tech}", style="cyan")
    return text

def display_projects():
    print_header("Internships & Projects")

    panels = [
        Panel(get_project_text("Developed machine learning models for predictive analytics to help the bank marketing team know which customer will buy the product via phone call marketing campaigns.", "ED, Python & SQL"), title="[bold magenta]Portuges Bank Analysis | Data Science Consultant Intern at Rubixe AI[/]", border_style="cyan"),
        
        Panel(get_project_text("CNN model using TensorFlow/Keras to classify rice leaf diseases. Included augmentation, preprocessing and real-time deployment.", "Data Augmentation, Classification (Leaf blast, bacterial blight, brown spot)"), title="[bold magenta]Rice Leaf Disease Detection Classification | Rubixe AI[/]", border_style="cyan"),
        
        Panel(get_project_text("Analyzed causes of performance issues and built predictive models for performance forecasting to find the top 3 Important Factors effecting employee performance.", "Performance Analytics & Recommendations"), title="[bold magenta]INX Future Inc Employee Performance Analysis | IABAC Project[/]", border_style="cyan"),
        
        Panel(get_project_text("Offline handwriting to text converter. Recognition is performed after the writing is completed by converting the handwritten document into digital form.", "Android Studio, Google Vision, Java Backend"), title="[bold magenta]Handwriting Recognition App | Academic Project[/]", border_style="cyan"),
        
        Panel(get_project_text("Android-based chatting application developed during academic term.", "Android"), title="[bold magenta]Android Chatting App | Academic Project[/]", border_style="cyan"),
        
        Panel(get_project_text("ANN, reinforcement learning, and time series for real-time stock predictions.", "AI, Time Series, RL"), title="[bold green]CipherDeepSense - Stock Prediction AI | Upcoming Project[/]", border_style="green"),
        
        Panel(get_project_text("Stay tuned for more advanced AI-based solutions.", ""), title="[bold green]Soonnnn... | Upcoming Project[/]", border_style="green"),
    ]

    group = Group(*panels)
    main_panel = create_panel(group, title="Portfolio Overview", expand=True)
    console.print(main_panel)
