from MohitJan.utils.formatter import console, create_panel, print_header
from rich.table import Table

def display_contact():
    print_header("Let's Connect!")
    
    table = Table(show_header=False, expand=True)
    table.add_column("Platform", style="bold cyan", width=15)
    table.add_column("Detail", style="white")
    
    table.add_row("- Email", "mojanbandhu@gmail.com")
    table.add_row("- LinkedIn", "linkedin.com/in/mohitjanbandhu")
    table.add_row("- GitHub", "github.com/MJanbandhu")
    
    panel = create_panel(table, title="Contact Details", expand=False)
    console.print(panel)
