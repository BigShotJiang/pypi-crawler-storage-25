import os
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from .colors import PANEL_BORDER, PRIMARY

# Initialize a central Rich console for all styling outputs
console = Console()

def clear_screen():
    """Clears the terminal screen securely on cross-platform."""
    os.system('cls' if os.name == 'nt' else 'clear')

def create_panel(renderable, title=None, subtitle=None, border_style=PANEL_BORDER, expand=False):
    """Helper to return beautifully formatted Rich panels."""
    return Panel(
        renderable,
        title=f"[{PRIMARY}]{title}[/]" if title else None,
        subtitle=subtitle,
        border_style=border_style,
        expand=expand,
        padding=(1, 2)
    )

def print_header(title):
    console.print(f"\n[bold magenta]=== {title.upper()} ===[/]\n")
