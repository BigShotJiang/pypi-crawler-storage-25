"""Utilities for styling and formatting the CLI interface."""
