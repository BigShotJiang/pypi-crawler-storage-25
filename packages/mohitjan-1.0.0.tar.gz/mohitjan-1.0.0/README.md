# Mohit Janbandhu CLI Portfolio

Welcome to the interactive command-line interface (CLI) portfolio for Mohit Janbandhu!

## What This CLI Does
This tool is an interactive, terminal-based developer portfolio. Instead of just printing a wall of text and dropping you back into your standard OS shell, the CLI creates a persistent **REPL (Read-Eval-Print Loop)** environment. 

Once launched, you are greeted with an animated ASCII banner and dropped into a custom `mohitjan >` prompt. From here, you can seamlessly navigate through my professional experience, comprehensive technical skills, extensive projects, and credentials all without leaving the environment. 

**Features include:**
- **Rich Interactive Formatting:** Styled text, colored boxes, and beautifully organized tables utilizing the `rich` Python library.
- **Auto-Correction:** Internal typo-matching logic (via Python's `difflib`) to suggest the correct command if misspelled.
- **Cross-Platform:** Tested to work securely without formatting or Unicode bugs on Windows Legacy Terminals, modern PowerShell, Linux bash, and macOS terminals.

## How to Install

You can easily install this CLI system locally directly via `pip`. 

Navigate into the root directory containing `setup.py` and run:

```bash
pip install .
```

> **Note for Windows Users:** 
> If you received a yellow warning during installation stating that `mohitjan.exe` is installed in `C:\Users\...\Scripts` which is not on your `PATH`, your terminal won't recognize the `mohitjan` command. 
> To run it immediately, you can simply type: `python -m MohitJan.main`
> Alternatively, you can permanently fix this by adding that explicit `Scripts` directory path to your Windows Environment Variables.

## Commands
Once inside the running shell (`mohitjan >`), type any of the following commands to navigate the portfolio:

- `about` — Detailed profile summary highlighting my experience and educational background.
- `skills` — Categorized table outlining expertise across Machine Learning, Programming, Cloud Platforms, and Business Strategy.
- `internships_projects` — Real-world insights into my Rubixe Internship, Bank Predictive models, IABAC Projects, and upcoming applications like CipherDeepSense.
- `certifications` — Official credentials and Data Scientist licensing from IABAC & NASSCOM.
- `recent_participation` — Background on my competition in the WAVES 2025 Anti-Piracy Challenge.
- `contact` — Quick links to my professional Email, GitHub, and LinkedIn profiles.
- `help` — Prints a styled helper table listing all available commands.
- `clear` — Wipes the terminal screen clean for better organization.
- `exit` or `quit` — Gracefully exits the interactive portfolio back to your native OS shell.
