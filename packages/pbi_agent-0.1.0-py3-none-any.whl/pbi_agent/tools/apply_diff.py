"""Utility for applying V4A diffs against text inputs."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Callable, Literal

ApplyDiffMode = Literal["default", "create"]
DiffLineNumber = dict[str, int | None]

TRAILING_WHITESPACE_MATCH_WARNING = (
    "used fuzzy context match ignoring trailing whitespace"
)
TRIMMED_WHITESPACE_MATCH_WARNING = (
    "used fuzzy context match ignoring leading/trailing whitespace"
)
UNICODE_NORMALIZED_MATCH_WARNING = (
    "used fuzzy context match after normalizing Unicode punctuation/spaces"
)
EOF_FALLBACK_MATCH_WARNING = (
    "used fallback context search for an end-of-file anchored hunk"
)


@dataclass(frozen=True, slots=True)
class ApplyDiffResult:
    content: str
    warnings: tuple[str, ...] = ()


@dataclass
class Chunk:
    orig_index: int
    del_lines: list[str]
    ins_lines: list[str]


@dataclass
class ParserState:
    lines: list[str]
    index: int = 0
    warnings: list[str] = field(default_factory=list)


@dataclass
class ParsedUpdateDiff:
    chunks: list[Chunk]
    warnings: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MatchStrategy:
    normalize: Callable[[str], str]
    warning: str | None = None


class InvalidContextError(ValueError):
    """Raised when a V4A context block cannot be matched."""

    def __init__(self, cursor: int, context: list[str], eof: bool = False) -> None:
        label = "Invalid EOF Context" if eof else "Invalid Context"
        super().__init__(_format_invalid_context_message(label, cursor, context))


@dataclass
class ReadSectionResult:
    next_context: list[str]
    section_chunks: list[Chunk]
    end_index: int
    eof: bool


END_PATCH = "*** End Patch"
END_FILE = "*** End of File"
SECTION_TERMINATORS = [
    END_PATCH,
    "*** Update File:",
    "*** Delete File:",
    "*** Add File:",
]
END_SECTION_MARKERS = [*SECTION_TERMINATORS, END_FILE]


def apply_diff(
    input: str,
    diff: str,
    mode: ApplyDiffMode = "default",
) -> ApplyDiffResult:
    """Apply a V4A diff and return content plus matching diagnostics.

    This parser understands both the create-file syntax (only "+" prefixed
    lines) and the default update syntax that includes context hunks.
    """
    newline = _detect_newline(input, diff, mode)
    diff_lines = _normalize_diff_lines(diff)
    if mode == "create":
        return ApplyDiffResult(content=_parse_create_diff(diff_lines, newline=newline))

    normalized_input = _normalize_text_newlines(input)
    parsed = _parse_update_diff(diff_lines, normalized_input)
    return ApplyDiffResult(
        content=_apply_chunks(normalized_input, parsed.chunks, newline=newline),
        warnings=parsed.warnings,
    )


def diff_line_numbers(
    input: str,
    diff: str,
    mode: ApplyDiffMode = "default",
) -> list[DiffLineNumber]:
    """Return old/new line numbers for each normalized V4A diff line.

    The web diff viewer receives compact V4A patches rather than full unified
    diffs. V4A hunks do not encode line numbers, so this mirrors the patch
    parser's context matching against the original file and produces display
    gutters from the actual location the patch matched.
    """
    lines = _normalize_diff_lines(diff)
    if mode == "create":
        return _create_diff_line_numbers(lines)
    return _update_diff_line_numbers(_normalize_text_newlines(input), lines)


def _create_diff_line_numbers(lines: list[str]) -> list[DiffLineNumber]:
    line_numbers: list[DiffLineNumber] = []
    new_number = 1
    for raw_line in lines:
        if raw_line.startswith("+"):
            line_numbers.append({"old": None, "new": new_number})
            new_number += 1
            continue
        line_numbers.append(_empty_line_number())
    return line_numbers


def _update_diff_line_numbers(input: str, lines: list[str]) -> list[DiffLineNumber]:
    parser = ParserState(lines=[*lines, END_PATCH])
    input_lines = input.split("\n")
    line_numbers: list[DiffLineNumber] = []
    cursor = 0
    new_delta = 0

    while not _is_done(parser, END_SECTION_MARKERS):
        anchor = _read_str(parser, "@@ ")
        if anchor != "":
            line_numbers.append(_empty_line_number())
        has_bare_anchor = (
            anchor == ""
            and parser.index < len(parser.lines)
            and parser.lines[parser.index] == "@@"
        )
        if has_bare_anchor:
            parser.index += 1
            line_numbers.append(_empty_line_number())

        if not (anchor or has_bare_anchor or cursor == 0):
            current_line = (
                parser.lines[parser.index] if parser.index < len(parser.lines) else ""
            )
            raise ValueError(f"Invalid Line:\n{current_line}")

        if anchor.strip():
            cursor = _advance_cursor_to_anchor(anchor, input_lines, cursor, parser)

        section_start = parser.index
        section = _read_section(parser.lines, parser.index)
        find_result = _find_context(
            input_lines, section.next_context, cursor, section.eof
        )
        if find_result.new_index == -1:
            ctx_text = "\n".join(section.next_context)
            if section.eof:
                raise ValueError(f"Invalid EOF Context {cursor}:\n{ctx_text}")
            raise ValueError(f"Invalid Context {cursor}:\n{ctx_text}")

        old_cursor = find_result.new_index
        new_cursor = find_result.new_index + new_delta
        section_line_end = section.end_index - 1 if section.eof else section.end_index
        for raw_line in lines[section_start:section_line_end]:
            line = raw_line if raw_line else " "
            prefix = line[0]
            if prefix == "+":
                line_numbers.append({"old": None, "new": new_cursor + 1})
                new_cursor += 1
            elif prefix == "-":
                line_numbers.append({"old": old_cursor + 1, "new": None})
                old_cursor += 1
            elif prefix == " ":
                line_numbers.append({"old": old_cursor + 1, "new": new_cursor + 1})
                old_cursor += 1
                new_cursor += 1
            else:
                line_numbers.append(_empty_line_number())

        if section.eof:
            line_numbers.append(_empty_line_number())

        cursor = find_result.new_index + len(section.next_context)
        new_delta = new_cursor - old_cursor
        parser.index = section.end_index

    return line_numbers


def _empty_line_number() -> DiffLineNumber:
    return {"old": None, "new": None}


def _normalize_diff_lines(diff: str) -> list[str]:
    lines = [line.rstrip("\r") for line in re.split(r"\r?\n", diff)]
    if lines and lines[-1] == "":
        lines.pop()
    return lines


def _detect_newline_from_text(text: str) -> str:
    return "\r\n" if "\r\n" in text else "\n"


def _detect_newline(input: str, diff: str, mode: ApplyDiffMode) -> str:
    # Create-file diffs don't have an input to infer newline style from.
    # Use the diff's newline style if present, otherwise default to LF.
    if mode != "create" and "\n" in input:
        return _detect_newline_from_text(input)
    return _detect_newline_from_text(diff)


def _normalize_text_newlines(text: str) -> str:
    # Normalize CRLF to LF for parsing/matching. Newline style is restored when emitting.
    return text.replace("\r\n", "\n")


def _is_done(state: ParserState, prefixes: Sequence[str]) -> bool:
    if state.index >= len(state.lines):
        return True
    if any(state.lines[state.index].startswith(prefix) for prefix in prefixes):
        return True
    return False


def _read_str(state: ParserState, prefix: str) -> str:
    if state.index >= len(state.lines):
        return ""
    current = state.lines[state.index]
    if current.startswith(prefix):
        state.index += 1
        return current[len(prefix) :]
    return ""


def _parse_create_diff(lines: list[str], newline: str) -> str:
    parser = ParserState(lines=[*lines, END_PATCH])
    output: list[str] = []

    while not _is_done(parser, SECTION_TERMINATORS):
        if parser.index >= len(parser.lines):
            break
        line = parser.lines[parser.index]
        parser.index += 1
        if not line.startswith("+"):
            raise ValueError(f"Invalid Add File Line: {line}")
        output.append(line[1:])

    return newline.join(output)


def _parse_update_diff(lines: list[str], input: str) -> ParsedUpdateDiff:
    parser = ParserState(lines=[*lines, END_PATCH])
    input_lines = input.split("\n")
    chunks: list[Chunk] = []
    cursor = 0

    while not _is_done(parser, END_SECTION_MARKERS):
        anchor = _read_str(parser, "@@ ")
        has_bare_anchor = (
            anchor == ""
            and parser.index < len(parser.lines)
            and parser.lines[parser.index] == "@@"
        )
        if has_bare_anchor:
            parser.index += 1

        if not (anchor or has_bare_anchor or cursor == 0):
            current_line = (
                parser.lines[parser.index] if parser.index < len(parser.lines) else ""
            )
            raise ValueError(f"Invalid Line:\n{current_line}")

        if anchor.strip():
            cursor = _advance_cursor_to_anchor(anchor, input_lines, cursor, parser)

        section = _read_section(parser.lines, parser.index)
        find_result = _find_context(
            input_lines, section.next_context, cursor, section.eof
        )
        if find_result.new_index == -1:
            raise InvalidContextError(cursor, section.next_context, eof=section.eof)

        cursor = find_result.new_index + len(section.next_context)
        if find_result.warning is not None:
            _append_warning(parser.warnings, find_result.warning)
        parser.index = section.end_index

        for ch in section.section_chunks:
            chunks.append(
                Chunk(
                    orig_index=ch.orig_index + find_result.new_index,
                    del_lines=list(ch.del_lines),
                    ins_lines=list(ch.ins_lines),
                )
            )

    return ParsedUpdateDiff(chunks=chunks, warnings=tuple(parser.warnings))


def _advance_cursor_to_anchor(
    anchor: str,
    input_lines: list[str],
    cursor: int,
    parser: ParserState,
) -> int:
    match = _find_anchor(input_lines, anchor, cursor)
    if match.new_index == -1:
        return cursor
    if match.warning is not None:
        _append_warning(parser.warnings, match.warning)
    return match.new_index + 1


def _find_anchor(input_lines: list[str], anchor: str, cursor: int) -> ContextMatch:
    if any(line == anchor for line in input_lines[:cursor]):
        return ContextMatch(new_index=-1)
    match = _find_context_core(input_lines, [anchor], cursor)
    if match.new_index == -1:
        return match
    if _has_prior_anchor_match(input_lines, anchor, cursor, match.warning):
        return ContextMatch(new_index=-1)
    return match


def _has_prior_anchor_match(
    input_lines: list[str],
    anchor: str,
    cursor: int,
    warning: str | None,
) -> bool:
    if warning is None:
        return False
    normalizer = _warning_normalizer(warning)
    return any(normalizer(line) == normalizer(anchor) for line in input_lines[:cursor])


def _warning_normalizer(warning: str) -> Callable[[str], str]:
    if warning == TRAILING_WHITESPACE_MATCH_WARNING:
        return str.rstrip
    if warning == TRIMMED_WHITESPACE_MATCH_WARNING:
        return str.strip
    if warning == UNICODE_NORMALIZED_MATCH_WARNING:
        return _normalize_common_unicode
    return lambda value: value


def _read_section(lines: list[str], start_index: int) -> ReadSectionResult:
    context: list[str] = []
    del_lines: list[str] = []
    ins_lines: list[str] = []
    section_chunks: list[Chunk] = []
    mode: Literal["keep", "add", "delete"] = "keep"
    index = start_index
    orig_index = index

    while index < len(lines):
        raw = lines[index]
        if (
            raw.startswith("@@")
            or raw.startswith(END_PATCH)
            or raw.startswith("*** Update File:")
            or raw.startswith("*** Delete File:")
            or raw.startswith("*** Add File:")
            or raw.startswith(END_FILE)
        ):
            break
        if raw == "***":
            break
        if raw.startswith("***"):
            raise ValueError(f"Invalid Line: {raw}")

        index += 1
        last_mode = mode
        line = raw if raw else " "
        prefix = line[0]
        if prefix == "+":
            mode = "add"
        elif prefix == "-":
            mode = "delete"
        elif prefix == " ":
            mode = "keep"
        else:
            raise ValueError(f"Invalid Line: {line}")

        line_content = line[1:]
        switching_to_context = mode == "keep" and last_mode != mode
        if switching_to_context and (del_lines or ins_lines):
            section_chunks.append(
                Chunk(
                    orig_index=len(context) - len(del_lines),
                    del_lines=list(del_lines),
                    ins_lines=list(ins_lines),
                )
            )
            del_lines = []
            ins_lines = []

        if mode == "delete":
            del_lines.append(line_content)
            context.append(line_content)
        elif mode == "add":
            ins_lines.append(line_content)
        else:
            context.append(line_content)

    if del_lines or ins_lines:
        section_chunks.append(
            Chunk(
                orig_index=len(context) - len(del_lines),
                del_lines=list(del_lines),
                ins_lines=list(ins_lines),
            )
        )

    if index < len(lines) and lines[index] == END_FILE:
        return ReadSectionResult(context, section_chunks, index + 1, True)

    if index == orig_index:
        next_line = lines[index] if index < len(lines) else ""
        raise ValueError(f"Nothing in this section - index={index} {next_line}")

    return ReadSectionResult(context, section_chunks, index, False)


@dataclass
class ContextMatch:
    new_index: int
    warning: str | None = None


def _find_context(
    lines: list[str], context: list[str], start: int, eof: bool
) -> ContextMatch:
    if eof:
        end_start = max(0, len(lines) - len(context))
        end_match = _find_context_core(lines, context, end_start)
        if end_match.new_index != -1:
            return end_match
        fallback = _find_context_core(lines, context, start)
        if fallback.new_index == -1:
            return fallback
        warnings = [EOF_FALLBACK_MATCH_WARNING]
        if fallback.warning is not None:
            warnings.append(fallback.warning)
        return ContextMatch(
            new_index=fallback.new_index,
            warning="; ".join(warnings),
        )
    return _find_context_core(lines, context, start)


def _find_context_core(
    lines: list[str], context: list[str], start: int
) -> ContextMatch:
    if not context:
        return ContextMatch(new_index=start)

    strategies = [
        MatchStrategy(lambda value: value),
        MatchStrategy(str.rstrip, TRAILING_WHITESPACE_MATCH_WARNING),
        MatchStrategy(str.strip, TRIMMED_WHITESPACE_MATCH_WARNING),
        MatchStrategy(_normalize_common_unicode, UNICODE_NORMALIZED_MATCH_WARNING),
    ]
    for strategy in strategies:
        for i in range(start, len(lines)):
            if _equals_slice(lines, context, i, strategy.normalize):
                return ContextMatch(new_index=i, warning=strategy.warning)

    return ContextMatch(new_index=-1)


def _equals_slice(
    source: list[str], target: list[str], start: int, map_fn: Callable[[str], str]
) -> bool:
    if start + len(target) > len(source):
        return False
    for offset, target_value in enumerate(target):
        if map_fn(source[start + offset]) != map_fn(target_value):
            return False
    return True


_UNICODE_TRANSLATION = str.maketrans(
    {
        "\u2010": "-",
        "\u2011": "-",
        "\u2012": "-",
        "\u2013": "-",
        "\u2014": "-",
        "\u2015": "-",
        "\u2212": "-",
        "\u2018": "'",
        "\u2019": "'",
        "\u201a": "'",
        "\u201b": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u201e": '"',
        "\u201f": '"',
        "\u2026": "...",
        "\u00a0": " ",
        "\u2002": " ",
        "\u2003": " ",
        "\u2004": " ",
        "\u2005": " ",
        "\u2006": " ",
        "\u2007": " ",
        "\u2008": " ",
        "\u2009": " ",
        "\u200a": " ",
        "\u202f": " ",
        "\u205f": " ",
        "\u3000": " ",
    }
)


def _normalize_common_unicode(value: str) -> str:
    return value.strip().translate(_UNICODE_TRANSLATION)


def _append_warning(warnings: list[str], warning: str) -> None:
    for part in warning.split("; "):
        if part not in warnings:
            warnings.append(part)


def _apply_chunks(input: str, chunks: list[Chunk], newline: str) -> str:
    orig_lines = input.split("\n")
    dest_lines: list[str] = []
    cursor = 0

    for chunk in chunks:
        if chunk.orig_index > len(orig_lines):
            raise ValueError(
                f"applyDiff: chunk.origIndex {chunk.orig_index} > input length {len(orig_lines)}"
            )
        if cursor > chunk.orig_index:
            raise ValueError(
                f"applyDiff: overlapping chunk at {chunk.orig_index} (cursor {cursor})"
            )

        dest_lines.extend(orig_lines[cursor : chunk.orig_index])
        cursor = chunk.orig_index

        if chunk.ins_lines:
            dest_lines.extend(chunk.ins_lines)

        cursor += len(chunk.del_lines)

    dest_lines.extend(orig_lines[cursor:])
    return newline.join(dest_lines)


def _format_invalid_context_message(label: str, cursor: int, context: list[str]) -> str:
    ctx_text = "\n".join(context)
    hint = _v4a_prefix_escape_hint(context)
    if hint:
        return f"{label} {cursor}:\n{ctx_text}\n\nHint: {hint}"
    return f"{label} {cursor}:\n{ctx_text}"


def _v4a_prefix_escape_hint(context: list[str]) -> str | None:
    if not any(line.startswith((" ", "+", "-")) for line in context):
        return None
    return (
        "V4A uses the first character of each diff line as the patch marker. "
        "If the target file line literally starts with '-', '+', or a leading "
        "space, include both the patch marker and the literal character. "
        "Examples: delete '- item' as '-- item', insert it as '+- item', "
        "and use it as context as ' - item'."
    )


__all__ = ["ApplyDiffResult", "apply_diff", "diff_line_numbers"]
