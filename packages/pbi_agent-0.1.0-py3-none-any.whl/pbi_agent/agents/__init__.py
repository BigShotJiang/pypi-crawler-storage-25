"""Project sub-agent catalog and installation helpers."""
