"""Sage CLI — local-first AI coding assistant.

Usage:
  sage run                              Interactive coding agent (Claude Code-like)
  sage chat                             Interactive chat session
  sage ask "explain quicksort"          One-shot prompt
  sage ask -f script.py "explain"       Ask about a file
  cat file.py | sage ask "explain"      Pipe input
  sage models                           List available models
  sage config show                      Show current config
  sage config set <key> <value>         Set a config value
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

import typer
from typing_extensions import Annotated

from sage import __version__
from sage.config import (
    SageConfig,
    load_config,
    save_config,
    set_config_value,
    get_config_value,
)
from sage.core import renderer
from sage.core.engine import ConversationEngine
from sage.core.router import ProviderRouter
from sage.providers.base import ProviderBase
from sage.providers.gemini import GeminiProvider
from sage.providers.llama_cpp import LlamaCppProvider
from sage.providers.openai_compat import (
    build_openai_compat_providers,
    OllamaProvider,
)

app = typer.Typer(
    name="sage",
    help="Sage — local-first AI coding assistant",
    no_args_is_help=True,
    add_completion=False,
)

config_app = typer.Typer(help="Manage configuration")
app.add_typer(config_app, name="config")


# ── Shared setup ────────────────────────────────────────────


def _build_router(cfg: SageConfig) -> ProviderRouter:
    """Instantiate all providers and return a configured router."""
    providers: list[ProviderBase] = [
        GeminiProvider(cfg),
        LlamaCppProvider(cfg),
        OllamaProvider(cfg),
        *build_openai_compat_providers(cfg),
    ]
    return ProviderRouter(providers, default_model=cfg.default_model)


def _read_stdin() -> str | None:
    """Read piped input if stdin is not a terminal."""
    if sys.stdin.isatty():
        return None
    return sys.stdin.read()


def _scan_project_context(
    cwd: Path,
    max_tree: int = 40,
    max_config_chars: int = 400,
    max_source_files: int = 10,
    max_source_lines: int = 60,
) -> str:
    """Scan the project directory and return a compact context string.

    Reads the file tree, detects languages, git status, config files,
    and the first N lines of key source files for deep codebase context.
    """
    skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv",
                 "dist", "build", ".next", ".cache", "target", ".tox",
                 "egg-info", ".eggs", ".mypy_cache", ".pytest_cache"}
    source_exts = {".py", ".js", ".ts", ".tsx", ".jsx", ".rs", ".go",
                   ".java", ".c", ".cpp", ".rb", ".sh"}
    ext_map = {
        ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
        ".tsx": "TypeScript/React", ".jsx": "React", ".rs": "Rust",
        ".go": "Go", ".java": "Java", ".c": "C", ".cpp": "C++",
        ".rb": "Ruby", ".sh": "Shell", ".html": "HTML", ".css": "CSS",
        ".json": "JSON", ".yaml": "YAML", ".yml": "YAML",
        ".toml": "TOML", ".md": "Markdown",
    }

    all_files: list[str] = []
    source_files: list[Path] = []
    lang_counts: dict[str, int] = {}
    for p in sorted(cwd.rglob("*")):
        rel = p.relative_to(cwd)
        if any(part.startswith(".") or any(s in part for s in skip_dirs) for part in rel.parts):
            continue
        if p.is_file():
            all_files.append(str(rel))
            ext = p.suffix.lower()
            if ext in ext_map:
                lang = ext_map[ext]
                lang_counts[lang] = lang_counts.get(lang, 0) + 1
            if ext in source_exts:
                source_files.append(p)

    sorted_langs = sorted(lang_counts.items(), key=lambda x: -x[1])
    primary_lang = sorted_langs[0][0] if sorted_langs else "Unknown"

    # Git context
    git_info = ""
    try:
        branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True, cwd=str(cwd), timeout=5,
        ).strip()
        status = subprocess.check_output(
            ["git", "status", "--short"],
            text=True, cwd=str(cwd), timeout=5,
        ).strip()
        git_info = f"Branch: {branch}"
        if status:
            git_info += f"\nChanged:\n{status}"
    except Exception:
        git_info = "(not a git repo)"

    # Config files
    config_names = [
        "pyproject.toml", "package.json", "Cargo.toml", "go.mod",
        "requirements.txt", "Makefile", "Dockerfile",
    ]
    configs = []
    for cf in config_names:
        cf_path = cwd / cf
        if cf_path.exists():
            try:
                configs.append(f"--- {cf} ---\n{cf_path.read_text('utf-8')[:max_config_chars]}")
            except Exception:
                pass

    # Read key source files for deep codebase understanding
    source_previews: list[str] = []
    # Prioritize entry points, main files, and smaller files
    priority_names = {"main", "app", "index", "cli", "__init__", "server", "config"}
    def _sort_key(p: Path) -> tuple:
        stem = p.stem.lower()
        is_priority = 0 if stem in priority_names else 1
        return (is_priority, p.stat().st_size)

    try:
        source_files.sort(key=_sort_key)
    except OSError:
        pass

    for sf in source_files[:max_source_files]:
        try:
            rel = sf.relative_to(cwd)
            lines = sf.read_text("utf-8", errors="replace").splitlines()[:max_source_lines]
            if lines:
                numbered = "\n".join(f"{i+1:>4}| {l}" for i, l in enumerate(lines))
                source_previews.append(f"--- {rel} (first {len(lines)} lines) ---\n{numbered}")
        except Exception:
            pass

    parts = [
        f"CWD: {cwd}",
        f"Lang: {primary_lang} | {', '.join(f'{l}({n})' for l, n in sorted_langs[:5])}",
        f"Git: {git_info}",
        f"Files ({len(all_files)}):",
    ]
    for f in all_files[:max_tree]:
        parts.append(f"  {f}")
    if len(all_files) > max_tree:
        parts.append(f"  ... +{len(all_files) - max_tree} more")
    if configs:
        parts.append("Config:")
        parts.extend(configs)
    if source_previews:
        parts.append("\nKey source files:")
        parts.extend(source_previews)
    return "\n".join(parts)


def _run_shell(cmd: str, cwd: Path, timeout: int = 30) -> str:
    """Run a shell command and return combined stdout+stderr."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True,
            cwd=str(cwd), timeout=timeout,
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += result.stderr
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"[command timed out after {timeout}s]"
    except Exception as exc:
        return f"[error: {exc}]"


def _read_file_context(filepath: str, cwd: Path, max_lines: int = 200) -> str | None:
    """Read a file and return its content with line numbers, or None if not found."""
    target = (cwd / filepath).resolve()
    if not str(target).startswith(str(cwd.resolve())):
        return None
    if not target.exists() or not target.is_file():
        return None
    try:
        lines = target.read_text("utf-8", errors="replace").splitlines()[:max_lines]
        numbered = "\n".join(f"{i+1:>4}| {l}" for i, l in enumerate(lines))
        truncated = f"\n... ({len(lines)}/{len(target.read_text('utf-8', errors='replace').splitlines())} lines shown)" if len(lines) == max_lines else ""
        return f"File: {filepath}\n{numbered}{truncated}"
    except Exception:
        return None


def _extract_bash_blocks(text: str) -> list[str]:
    """Extract ```bash or ```shell code blocks from model output."""
    blocks = []
    for m in re.finditer(r"```(?:bash|shell|sh)\s*\n(.*?)```", text, re.DOTALL):
        cmd = m.group(1).strip()
        if cmd:
            blocks.append(cmd)
    return blocks


def _write_file(filepath_str: str, content: str, cwd: Path) -> str | None:
    """Safely write a file under *cwd*. Returns the relative path or None."""
    cwd_str = str(cwd)
    if filepath_str.startswith(cwd_str):
        filepath_str = filepath_str[len(cwd_str):].lstrip("/")
    filepath_str = filepath_str.lstrip("/")
    try:
        target = (cwd / filepath_str).resolve()
        if not str(target).startswith(str(cwd.resolve())):
            renderer.warning(f"Path traversal blocked: {filepath_str}")
            return None
    except (ValueError, OSError):
        return None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return filepath_str
    except OSError as exc:
        renderer.warning(f"Could not write {filepath_str}: {exc}")
        return None


def _extract_and_write_files(output: str, cwd: Path) -> list[str]:
    """Parse model output for file blocks and write them to disk.

    Recognizes:
      1. FILE: path/to/file.ext\\n```\\ncontent\\n```
      2. ```path/to/file.ext\\ncontent\\n```
    """
    written: list[str] = []
    seen: set[str] = set()

    # Pattern 1: FILE: path\n```\ncontent\n```
    for m in re.finditer(r"FILE:\s*(\S+)\s*\n```[^\n]*\n(.*?)```", output, re.DOTALL):
        fp = m.group(1).strip()
        if fp in seen:
            continue
        seen.add(fp)
        result = _write_file(fp, m.group(2), cwd)
        if result:
            written.append(result)

    if written:
        return written

    # Pattern 2 (fallback): ```filename.ext\ncontent\n```
    lang_tags = {"python", "javascript", "typescript", "bash", "sh",
                 "json", "yaml", "yml", "toml", "html", "css", "sql",
                 "go", "rust", "java", "c", "cpp", "ruby", "php", "jsx", "tsx"}
    for m in re.finditer(r"```(\S+)\s*\n(.*?)```", output, re.DOTALL):
        tag = m.group(1).strip()
        if tag.lower() in lang_tags:
            continue
        if "." not in tag and "/" not in tag:
            continue
        if tag in seen:
            continue
        seen.add(tag)
        result = _write_file(tag, m.group(2), cwd)
        if result:
            written.append(result)

    return written


_AGENT_SYSTEM_PROMPT = """\
You are Sage, an autonomous AI coding agent running directly on the user's machine.
You are a senior software engineer — you plan, build, test, and fix code end-to-end.

## How you work

1. PLAN — Before writing any code, state what you will do in 2-4 bullet points.
2. IMPLEMENT — Write complete, production-ready code using FILE: blocks.
3. VERIFY — Always include a ```bash block with the command to test/run your code.
4. If tests fail, you will receive the error output. Diagnose the root cause and fix it.

## File output format

When creating or modifying files, use EXACTLY this format:

FILE: path/to/file.ext
```
<complete file contents>
```

- One FILE: block per file. Full path on the FILE: line, NOT on the ``` line.
- Output the COMPLETE file — no placeholders, no "...", no truncation.

## Verification commands

After writing code, ALWAYS include a ```bash block to verify it works:
- Python files: ```bash pytest <test_file> -v``` or ```bash python <file>```
- Other languages: appropriate build/run/test command

## Rules

- Match the project's existing code style and patterns.
- When asked to build something, write BOTH the implementation AND tests.
- Test files must be named test_*.py and use pytest.
- Reference specific files and line numbers when analyzing code.
- Keep explanations concise — lead with code, explain after.
- If you receive error output from a failed command, fix the code and output corrected FILE: blocks.
"""


def _detect_test_files(written: list[str]) -> list[str]:
    """Return test file paths from a list of written files."""
    return [f for f in written if Path(f).name.startswith("test_") and f.endswith(".py")]


def _detect_runnable_files(written: list[str]) -> list[str]:
    """Return Python files that can be syntax-checked."""
    return [f for f in written if f.endswith(".py")]


def _auto_validate(written: list[str], cwd: Path) -> str | None:
    """Run automatic validation on written files. Returns output or None."""
    test_files = _detect_test_files(written)
    if test_files:
        cmd = f"python -m pytest {' '.join(test_files)} -v --tb=short"
        return cmd, _run_shell(cmd, cwd, timeout=60)

    runnable = _detect_runnable_files(written)
    if runnable:
        # At minimum, syntax-check all written Python files
        checks = []
        for f in runnable:
            result = _run_shell(f"python -c \"import ast; ast.parse(open('{f}').read())\"", cwd, timeout=10)
            if "exit code" in result or "Error" in result:
                checks.append(f"{f}: {result}")
        if checks:
            return "python syntax check", "\n".join(checks)

    return None


def _has_errors(output: str) -> bool:
    """Check if command output indicates failure."""
    error_signals = ["FAILED", "Error", "error:", "Traceback", "exit code:", "SyntaxError",
                     "NameError", "TypeError", "ImportError", "ModuleNotFoundError",
                     "AttributeError", "ValueError", "IndentationError"]
    return any(sig in output for sig in error_signals)


# ── Commands ────────────────────────────────────────────────


@app.command()
def run(
    model: Annotated[Optional[str], typer.Option("--model", "-m", help="Model ID")] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    auto_run: Annotated[bool, typer.Option("--auto-run/--no-auto-run", help="Auto-execute bash blocks without prompting")] = False,
    max_retries: Annotated[int, typer.Option("--max-retries", help="Max auto-fix retries on test failure")] = 3,
) -> None:
    """Interactive coding agent — project-aware, auto-writes files (like Claude Code)."""
    cfg = load_config()
    router = _build_router(cfg)

    model_id = model or cfg.default_model
    temp = temperature if temperature is not None else 0.1
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens
    cwd = Path.cwd()

    with renderer.status_spinner("Scanning project...", "reading"):
        context = _scan_project_context(cwd)
    renderer.step_done("Project scanned")

    # Build initial conversation with project context
    engine = ConversationEngine(
        system_prompt=_AGENT_SYSTEM_PROMPT,
        max_history=50,
    )

    messages_init = [
        {"role": "user", "content": f"[Project context — do not repeat this back]\n{context}"},
        {"role": "assistant", "content": "Understood. I can see your project. What would you like to do?"},
    ]
    for m in messages_init:
        if m["role"] == "user":
            engine.add_user(m["content"])
        else:
            engine.add_assistant(m["content"])

    renderer.print_agent_welcome(model_id, str(cwd))

    last_written: list[str] = []
    all_written: list[str] = []
    multiline_buffer: list[str] | None = None

    def _send_to_model(user_msg: str, show_thinking: bool = True) -> str | None:
        """Send a message to the model and stream the response. Returns response text."""
        engine.add_user(user_msg)
        messages = engine.build_messages()
        try:
            if show_thinking:
                response = renderer.stream_tokens_with_phase(
                    router.stream(messages, model_id, temp, tokens),
                    model_id=model_id,
                )
            else:
                renderer.console.print("[bold green]sage>[/bold green] ", end="")
                response = renderer.stream_tokens(
                    router.stream(messages, model_id, temp, tokens)
                )
            engine.add_assistant(response)
            return response
        except Exception as exc:
            engine._messages.pop()  # Remove the failed user message
            renderer.error(str(exc))
            return None

    def _process_response(response: str) -> list[str]:
        """Process model response: write files, execute commands. Returns written files."""
        nonlocal last_written, all_written

        # Auto-write files from response
        written = _extract_and_write_files(response, cwd)
        if written:
            last_written = written
            all_written.extend(written)
            renderer.print_files_written(written)

        # Detect bash blocks and execute
        bash_blocks = _extract_bash_blocks(response)
        for cmd in bash_blocks:
            should_run = auto_run
            if not should_run:
                try:
                    answer = renderer.console.input(
                        f"  [yellow]▷ Run:[/yellow] [dim]{cmd[:80]}{'...' if len(cmd) > 80 else ''}[/dim] [yellow](y/n)?[/yellow] "
                    )
                    should_run = answer.strip().lower() in {"y", "yes", ""}
                except (EOFError, KeyboardInterrupt):
                    break
            if should_run:
                renderer.print_shell_start(cmd)
                with renderer.status_spinner(f"Running: {cmd[:60]}...", "executing"):
                    output = _run_shell(cmd, cwd, timeout=60)
                renderer.print_shell_output(output)
                engine.add_user(f"[Ran: {cmd}]")
                engine.add_assistant(f"Command output:\n```\n{output}\n```")

        return written

    def _auto_validate_and_retry(written: list[str], retries_left: int, attempt: int = 1) -> None:
        """Auto-validate written files and retry on failure."""
        if not written or retries_left <= 0:
            return

        validation = _auto_validate(written, cwd)
        if validation is None:
            return

        cmd_name, output = validation
        renderer.print_validation_start(cmd_name)

        with renderer.status_spinner("Running validation...", "testing"):
            pass  # validation already ran in _auto_validate

        has_errors = _has_errors(output)
        renderer.print_test_results(output, passed=not has_errors)

        if has_errors:
            renderer.print_retry(attempt, max_retries)

            # Feed error back to model
            fix_prompt = (
                f"The validation command failed. Here is the error output:\n"
                f"```\n{output}\n```\n"
                f"Fix the code. Output corrected FILE: blocks for the files that need changes."
            )
            fix_response = _send_to_model(fix_prompt)
            if fix_response:
                new_written = _process_response(fix_response)
                if new_written:
                    _auto_validate_and_retry(new_written, retries_left - 1, attempt + 1)

    while True:
        try:
            prompt_text = "[bold cyan]you>[/bold cyan] " if multiline_buffer is None else "[dim]...[/dim]  "
            raw = renderer.console.input(prompt_text)
        except (EOFError, KeyboardInterrupt):
            renderer.info("\nGoodbye.")
            break

        # Multi-line mode
        if multiline_buffer is not None:
            if raw.rstrip() == '"""':
                user_input = "\n".join(multiline_buffer)
                multiline_buffer = None
            else:
                multiline_buffer.append(raw)
                continue
        elif raw.lstrip().startswith('"""'):
            rest = raw.lstrip()[3:]
            multiline_buffer = [rest] if rest else []
            continue
        else:
            user_input = raw.strip()

        if not user_input:
            continue

        # ── Shell escape: !command ─────────────────────────
        if user_input.startswith("!"):
            shell_cmd = user_input[1:].strip()
            if shell_cmd:
                renderer.print_shell_start(shell_cmd)
                with renderer.status_spinner(f"Running: {shell_cmd[:60]}...", "executing"):
                    output = _run_shell(shell_cmd, cwd)
                renderer.print_shell_output(output)
                engine.add_user(f"[Shell command: {shell_cmd}]")
                engine.add_assistant(f"Command output:\n```\n{output}\n```")
            continue

        # ── Agent commands ──────────────────────────────────
        if user_input.startswith("/"):
            cmd_parts = user_input.split(None, 1)
            command = cmd_parts[0].lower()
            arg = cmd_parts[1] if len(cmd_parts) > 1 else ""

            if command in {"/exit", "/quit", "/q"}:
                renderer.info("Goodbye.")
                break
            elif command == "/help":
                renderer.print_agent_help()
                continue
            elif command == "/clear":
                engine.clear()
                last_written.clear()
                all_written.clear()
                renderer.success("Conversation and file history cleared.")
                continue
            elif command == "/files":
                if all_written:
                    unique = list(dict.fromkeys(all_written))
                    renderer.info(f"All written files ({len(unique)}):")
                    for f in unique:
                        exists = "  " if (cwd / f).exists() else "  [deleted]"
                        renderer.console.print(f"  {exists} {f}")
                else:
                    renderer.info("No files written yet.")
                continue
            elif command == "/undo":
                if last_written:
                    for fp in last_written:
                        target = cwd / fp
                        if target.exists():
                            target.unlink()
                            renderer.info(f"  Deleted: {fp}")
                    last_written.clear()
                else:
                    renderer.info("Nothing to undo.")
                continue
            elif command == "/model":
                if arg:
                    model_id = arg
                    renderer.success(f"Switched to: {model_id}")
                else:
                    renderer.info(f"Model: {model_id}")
                continue
            elif command == "/read":
                if not arg:
                    renderer.warning("Usage: /read <filepath>")
                    continue
                content = _read_file_context(arg, cwd)
                if content:
                    line_count = content.count("\n")
                    renderer.print_file_read(arg, line_count)
                    engine.add_user(f"[Reading file: {arg}]\n{content}")
                    engine.add_assistant("I've read the file. What would you like me to do with it?")
                else:
                    renderer.step_fail(f"Could not read: {arg}")
                continue
            elif command == "/test":
                # Run project tests
                test_cmd = arg or "python -m pytest -v --tb=short"
                renderer.phase("testing", test_cmd)
                with renderer.status_spinner("Running tests...", "testing"):
                    output = _run_shell(test_cmd, cwd, timeout=120)
                has_errors = _has_errors(output)
                renderer.print_test_results(output, passed=not has_errors)
                if has_errors:
                    renderer.print_shell_output(output)
                engine.add_user(f"[Test run: {test_cmd}]")
                engine.add_assistant(f"Test output:\n```\n{output}\n```")
                continue
            elif command == "/history":
                renderer.info(f"Turns: {engine.turn_count}")
                continue
            else:
                renderer.warning(f"Unknown command: {command}")
                continue

        # ── Send to model ───────────────────────────────────
        response = _send_to_model(user_input)
        if response:
            written = _process_response(response)
            # Auto-validate: run tests on written files, retry on failure
            if written:
                _auto_validate_and_retry(written, max_retries)


@app.command()
def chat(
    model: Annotated[Optional[str], typer.Option("--model", "-m", help="Model ID (provider:model)")] = None,
    system: Annotated[Optional[str], typer.Option("--system", "-s", help="System prompt")] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    no_stream: Annotated[bool, typer.Option("--no-stream", help="Disable streaming")] = False,
) -> None:
    """Interactive chat session (REPL)."""
    cfg = load_config()
    router = _build_router(cfg)

    model_id = model or cfg.default_model
    temp = temperature if temperature is not None else cfg.temperature
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens

    engine = ConversationEngine(
        system_prompt=system or cfg.system_prompt,
        max_history=50,
    )

    renderer.print_welcome(model_id)

    multiline_buffer: list[str] | None = None

    while True:
        try:
            prompt_text = "[bold cyan]you>[/bold cyan] " if multiline_buffer is None else "[dim]...[/dim]  "
            raw = renderer.console.input(prompt_text)
        except (EOFError, KeyboardInterrupt):
            renderer.info("\nGoodbye.")
            break

        # Multi-line mode
        if multiline_buffer is not None:
            if raw.rstrip() == '"""':
                user_input = "\n".join(multiline_buffer)
                multiline_buffer = None
            else:
                multiline_buffer.append(raw)
                continue
        elif raw.lstrip().startswith('"""'):
            # Start multi-line
            rest = raw.lstrip()[3:]
            multiline_buffer = [rest] if rest else []
            continue
        else:
            user_input = raw.strip()

        if not user_input:
            continue

        # ── REPL commands ───────────────────────────────────
        if user_input.startswith("/"):
            cmd = user_input.split(None, 1)
            command = cmd[0].lower()
            arg = cmd[1] if len(cmd) > 1 else ""

            if command in {"/exit", "/quit", "/q"}:
                renderer.info("Goodbye.")
                break
            elif command == "/help":
                renderer.print_help()
                continue
            elif command == "/clear":
                engine.clear()
                renderer.success("Conversation cleared.")
                continue
            elif command == "/model":
                if arg:
                    model_id = arg
                    renderer.success(f"Switched to model: {model_id}")
                else:
                    renderer.info(f"Current model: {model_id}")
                continue
            elif command == "/system":
                if arg:
                    engine.system_prompt = arg
                    renderer.success("System prompt updated.")
                else:
                    sp = engine.system_prompt or "(none)"
                    renderer.info(f"System prompt: {sp}")
                continue
            elif command == "/history":
                renderer.info(f"Turns: {engine.turn_count}")
                continue
            else:
                renderer.warning(f"Unknown command: {command}")
                continue

        # ── Send to model ───────────────────────────────────
        engine.add_user(user_input)
        messages = engine.build_messages()

        try:
            renderer.console.print("[bold green]sage>[/bold green] ", end="")
            if no_stream:
                response = router.generate(messages, model_id, temp, tokens)
                renderer.console.print()
                renderer.render_markdown(response)
            else:
                response = renderer.stream_tokens(
                    router.stream(messages, model_id, temp, tokens)
                )
            engine.add_assistant(response)
        except Exception as exc:
            engine._messages.pop()  # Remove the failed user message
            renderer.error(str(exc))


@app.command()
def ask(
    prompt: Annotated[Optional[str], typer.Argument(help="Prompt text")] = None,
    file: Annotated[Optional[Path], typer.Option("--file", "-f", help="Read file content as context")] = None,
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    system: Annotated[Optional[str], typer.Option("--system", "-s")] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    raw: Annotated[bool, typer.Option("--raw", help="Output raw text (no markdown rendering)")] = False,
) -> None:
    """One-shot prompt — ask a question and get an answer."""
    cfg = load_config()
    router = _build_router(cfg)

    model_id = model or cfg.default_model
    temp = temperature if temperature is not None else cfg.temperature
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens

    # Build the prompt from arguments, file, and/or stdin
    parts: list[str] = []

    # Check for piped input
    piped = _read_stdin()
    if piped:
        parts.append(piped.strip())

    # Read file if provided
    if file:
        if not file.exists():
            renderer.error(f"File not found: {file}")
            raise typer.Exit(1)
        content = file.read_text("utf-8")
        parts.append(f"File: {file.name}\n```\n{content}\n```")

    if prompt:
        parts.append(prompt)

    if not parts:
        renderer.error("No prompt provided. Usage: sage ask 'your question'")
        raise typer.Exit(1)

    full_prompt = "\n\n".join(parts)

    engine = ConversationEngine(system_prompt=system or cfg.system_prompt)
    engine.add_user(full_prompt)
    messages = engine.build_messages()

    try:
        if raw or not sys.stdout.isatty():
            # Non-interactive: stream raw text
            response = renderer.stream_tokens(
                router.stream(messages, model_id, temp, tokens)
            )
        else:
            # Interactive terminal: render markdown
            response = router.generate(messages, model_id, temp, tokens)
            renderer.render_markdown(response)
    except Exception as exc:
        renderer.error(str(exc))
        raise typer.Exit(2)


@app.command()
def models() -> None:
    """List available models from all configured providers."""
    cfg = load_config()
    router = _build_router(cfg)
    all_models = router.list_all_models()

    if not all_models:
        renderer.warning(
            "No models available.\n"
            "  Configure Gemini: sage config set api_keys.gemini YOUR_KEY\n"
            "  Add local model:  sage config set models.mymodel.path /path/to/model.gguf"
        )
        raise typer.Exit(1)

    renderer.print_model_table([
        {"id": m.id, "provider": m.provider, "name": m.name, "local": m.local}
        for m in all_models
    ])
    renderer.info(f"\nDefault: {cfg.default_model}")


# ── Config subcommands ──────────────────────────────────────


@config_app.command("show")
def config_show() -> None:
    """Show current configuration."""
    cfg = load_config()
    # Mask API keys for display
    display = cfg.to_dict()
    for key in display.get("api_keys", {}):
        val = display["api_keys"][key]
        if val and len(val) > 8:
            display["api_keys"][key] = val[:4] + "..." + val[-4:]
    renderer.print_config(display)


@config_app.command("set")
def config_set(
    key: Annotated[str, typer.Argument(help="Config key (e.g. api_keys.gemini, default_model)")],
    value: Annotated[str, typer.Argument(help="Value to set")],
) -> None:
    """Set a configuration value."""
    try:
        set_config_value(key, value)
        renderer.success(f"Set {key}")
    except KeyError as exc:
        renderer.error(str(exc))
        raise typer.Exit(1)


@config_app.command("get")
def config_get(
    key: Annotated[str, typer.Argument(help="Config key to read")],
) -> None:
    """Get a configuration value."""
    try:
        val = get_config_value(key)
        renderer.console.print(val)
    except KeyError as exc:
        renderer.error(str(exc))
        raise typer.Exit(1)


@config_app.command("init")
def config_init() -> None:
    """Create default config file at ~/.sage/config.json."""
    cfg = SageConfig()
    save_config(cfg)
    renderer.success(f"Config created at ~/.sage/config.json")
    renderer.info("Set up free providers (pick any):")
    renderer.info("  sage config set api_keys.gemini    YOUR_KEY  # Google AI Studio")
    renderer.info("  sage config set api_keys.groq      YOUR_KEY  # console.groq.com")
    renderer.info("  sage config set api_keys.openrouter YOUR_KEY  # openrouter.ai")
    renderer.info("  sage config set api_keys.cerebras  YOUR_KEY  # cloud.cerebras.ai")
    renderer.info("  sage config set api_keys.sambanova YOUR_KEY  # cloud.sambanova.ai")
    renderer.info("  sage config set api_keys.together  YOUR_KEY  # together.ai")
    renderer.info("  sage config set api_keys.mistral   YOUR_KEY  # console.mistral.ai")
    renderer.info("  sage config set api_keys.cohere    YOUR_KEY  # dashboard.cohere.com")
    renderer.info("  sage config set api_keys.deepseek  YOUR_KEY  # platform.deepseek.com")
    renderer.info("  sage config set api_keys.github    YOUR_TOKEN # github.com/settings/tokens")
    renderer.info("Or use Ollama (no key needed): ollama pull llama3.2")


# ── Version callback ────────────────────────────────────────


def _version_callback(value: bool) -> None:
    if value:
        renderer.console.print(f"sage {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-v", callback=_version_callback, is_eager=True),
    ] = None,
) -> None:
    """Sage — local-first AI coding assistant."""


def run() -> None:
    """Entry point for pyproject.toml console_scripts."""
    app()
