import json
import logging
import os
import uuid
from dataclasses import asdict
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles

from .auto_updater import AutoUpdater
from .config import runtime_defaults, settings
from .conversations import ConversationStore
from .github_client import discover_model_assets, parse_repo_url
from .hardware import detect_hardware_summary
from .model_catalog import filter_by_ram, get_recommended_models, list_catalog_models
from .model_registry import ModelRegistry
from .prompt_engine import build_messages
from .runtime_manager import RuntimeManager
from .schemas import (
    AddSourceReq,
    ChatMessage,
    ChatReq,
    CreateConversationReq,
    DownloadModelReq,
    ImportModelReq,
    LoadModelReq,
    SetActiveVersionReq,
)

settings.ensure_dirs()
logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger("ai-platform")

app = FastAPI(title="Local AI Platform", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

registry = ModelRegistry()
runtime_manager = RuntimeManager()
conversation_store = ConversationStore()
auto_updater = AutoUpdater(registry)


# ── Health & Hardware ──────────────────────────────────────────


@app.get("/health")
def health():
    return {
        "ok": True,
        "version": "3.0.0",
        "loaded_model_id": runtime_manager.loaded_model_id,
        "loaded_runtime": runtime_manager.loaded_runtime,
    }


@app.get("/hardware")
def hardware():
    return detect_hardware_summary()


# ── Model Catalog (free models from GitHub) ────────────────────


@app.get("/catalog")
def catalog():
    """Browse the curated catalog of free, open-weight models."""
    return {"ok": True, "models": list_catalog_models()}


@app.get("/catalog/recommended")
def catalog_recommended():
    """Get recommended starter models."""
    return {"ok": True, "models": get_recommended_models()}


@app.get("/catalog/fits-ram")
def catalog_fits_ram(max_gb: float = 8.0):
    """Get models that fit within a RAM budget."""
    return {"ok": True, "models": filter_by_ram(max_gb)}


# ── Models ─────────────────────────────────────────────────────


@app.get("/models")
def list_models():
    return {"ok": True, "models": [m.model_dump() for m in registry.list_models()]}


@app.get("/models/names")
def model_names():
    """Return all known model IDs (from registry + tracked sources) for autocomplete."""
    ids = {m.model_id for m in registry.list_models()}
    ids |= {s.model_id for s in auto_updater.list_sources()}
    return {"ok": True, "names": sorted(ids)}


@app.get("/models/{model_id}")
def get_model(model_id: str):
    try:
        record = registry.get_model(model_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"ok": True, "model": record.model_dump()}


@app.get("/models/{model_id}/versions")
def list_versions(model_id: str):
    try:
        versions = registry.list_versions(model_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"ok": True, "versions": [v.model_dump() for v in versions]}


@app.post("/models/download")
def download_model(req: DownloadModelReq):
    try:
        record = registry.download_and_register(req)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/import")
def import_model(req: ImportModelReq):
    try:
        record = registry.import_local(req)
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/set-version")
def set_version(req: SetActiveVersionReq):
    try:
        record = registry.set_active_version(req.model_id, req.version)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/load")
def load_model(req: LoadModelReq):
    try:
        record = registry.get_model(req.model_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    if req.version:
        version = next((v for v in record.versions if v.version == req.version), None)
        if not version:
            raise HTTPException(status_code=404, detail=f"Version {req.version} not found")
    else:
        version = record.active()

    threads = req.threads or runtime_defaults.default_threads or None
    runtime_manager.load(
        record.runtime, req.model_id, version.file_path, threads=threads
    )
    return {
        "ok": True,
        "loaded_model_id": runtime_manager.loaded_model_id,
        "loaded_runtime": runtime_manager.loaded_runtime,
        "loaded_version": version.version,
        "threads": threads,
    }


# ── Source Tracking ────────────────────────────────────────────


@app.get("/sources")
def list_sources():
    sources = auto_updater.list_sources()
    return {"ok": True, "sources": [asdict(s) for s in sources]}


@app.post("/sources/add")
def add_source(req: AddSourceReq):
    try:
        source = auto_updater.add_source(
            repo_url=req.repo_url,
            model_id=req.model_id,
            runtime=req.runtime,
            asset_pattern=req.asset_pattern,
            license=req.license,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "source": asdict(source)}


@app.delete("/sources/{model_id}")
def remove_source(model_id: str):
    auto_updater.remove_source(model_id)
    return {"ok": True}


# ── Auto-Update ────────────────────────────────────────────────


@app.post("/models/update")
def check_all_updates():
    """Check all tracked sources for new model releases."""
    results = auto_updater.check_updates()
    return {
        "ok": True,
        "results": [asdict(r) for r in results],
    }


@app.post("/models/update/{model_id}")
def check_model_updates(model_id: str):
    """Check a specific tracked source for new releases."""
    try:
        results = auto_updater.check_updates(model_id=model_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {
        "ok": True,
        "results": [asdict(r) for r in results],
    }


# ── GitHub Discovery ──────────────────────────────────────────


@app.get("/github/discover")
def github_discover(repo_url: str):
    """Discover model assets in a GitHub repository's releases."""
    try:
        owner, repo = parse_repo_url(repo_url)
        assets = discover_model_assets(owner, repo)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "owner": owner, "repo": repo, "assets": assets}


# ── Chat ───────────────────────────────────────────────────────


@app.post("/chat")
def chat(req: ChatReq):
    runtime_manager.ensure_loaded()
    if runtime_manager.loaded_model_id != req.model_id:
        raise HTTPException(status_code=400, detail="Requested model is not loaded")

    conv_id = req.conversation_id or str(uuid.uuid4())
    for msg in req.messages:
        conversation_store.append_message(conv_id, msg.role, msg.content)

    # Inject system prompt — this is what makes it "your own" coding AI
    has_system = any(m.role == "system" for m in req.messages)
    full_messages = build_messages(
        req.messages,
        include_system=not has_system,
        include_fewshot=False,
    )

    def stream():
        chunks = []
        for token in runtime_manager.runtime.stream_chat(
            full_messages,
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        ):
            chunks.append(token)
            yield f"data: {json.dumps({'token': token})}\n\n"
        final = "".join(chunks).strip()
        conversation_store.append_message(conv_id, "assistant", final)
        yield f"data: {json.dumps({'done': True, 'conversation_id': conv_id})}\n\n"

    if req.stream:
        return StreamingResponse(stream(), media_type="text/event-stream")

    text = runtime_manager.runtime.chat(
        full_messages,
        temperature=req.temperature,
        max_tokens=req.max_tokens,
    )
    conversation_store.append_message(conv_id, "assistant", text)
    return {"ok": True, "output": text, "conversation_id": conv_id}


# ── Conversations ──────────────────────────────────────────────


@app.post("/conversations")
def create_conversation(req: CreateConversationReq):
    conv = conversation_store.create(req.title)
    return {"ok": True, "conversation": conv}


@app.get("/conversations")
def list_conversations():
    return {"ok": True, "conversations": conversation_store.list_all()}


@app.get("/conversations/{conversation_id}")
def get_conversation(conversation_id: str):
    try:
        conv = conversation_store.get(conversation_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return {"ok": True, "conversation": conv}


@app.delete("/conversations/{conversation_id}")
def delete_conversation(conversation_id: str):
    conversation_store.delete(conversation_id)
    return {"ok": True}


# ── Static Frontend (production) ──────────────────────────────

_FRONTEND_DIST = Path(__file__).resolve().parent.parent / "frontend" / "dist"
if _FRONTEND_DIST.is_dir():
    # Serve index.html for SPA routes (must come after API routes)
    from fastapi.responses import FileResponse

    @app.get("/app/{full_path:path}")
    def spa_fallback(full_path: str):
        return FileResponse(_FRONTEND_DIST / "index.html")

    @app.get("/")
    def root():
        return FileResponse(_FRONTEND_DIST / "index.html")

    app.mount("/", StaticFiles(directory=str(_FRONTEND_DIST), html=True), name="static")


def main():
    """Entry point for `ai-server` console script and direct execution."""
    import uvicorn
    port = int(os.environ.get("PORT", settings.port))
    uvicorn.run(app, host=settings.host, port=port)
