from __future__ import annotations

import logging
import re
import typing as t
from concurrent.futures import ThreadPoolExecutor
from contextlib import suppress
from pathlib import Path

from rich import box
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
)
from rich.table import Table

from crackerjack.cli.formatting import separator as make_separator
from crackerjack.code_cleaner import CodeCleaner
from crackerjack.config import get_console_width
from crackerjack.core.autofix_coordinator import AutofixCoordinator
from crackerjack.core.console import CrackerjackConsole
from crackerjack.core.session_coordinator import SessionCoordinator
from crackerjack.decorators import handle_errors
from crackerjack.models.protocols import ConsoleInterface
from crackerjack.services.memory_optimizer import create_lazy_service

try:
    from crackerjack.services.monitoring.performance_cache import (
        FileSystemCache,
        GitOperationCache,
    )
except Exception:  # pragma: no cover - optional legacy module
    FileSystemCache = t.Any  # type: ignore[assignment]
    GitOperationCache = t.Any  # type: ignore[assignment]

if t.TYPE_CHECKING:
    from crackerjack.agents.base import AgentContext
    from crackerjack.agents.coordinator import AgentCoordinator
    from crackerjack.models.protocols import (
        ConfigMergeServiceProtocol,
        FileSystemInterface,
        GitInterface,
        HookManager,
        MemoryOptimizerProtocol,
        OptionsProtocol,
        PublishManager,
        TestManagerProtocol,
    )
    from crackerjack.models.task import HookResult
    from crackerjack.services.cache import CrackerjackCache
    from crackerjack.services.parallel_executor import (
        AsyncCommandExecutor,
        ParallelHookExecutor,
    )


class PhaseCoordinator:
    def __init__(
        self,
        *,
        console: ConsoleInterface | None = None,
        pkg_path: Path | None = None,
        session: SessionCoordinator | None = None,
        filesystem: FileSystemInterface | None = None,
        git_service: GitInterface | None = None,
        hook_manager: HookManager | None = None,
        test_manager: TestManagerProtocol | None = None,
        publish_manager: PublishManager | None = None,
        config_merge_service: ConfigMergeServiceProtocol | None = None,
        logger: logging.Logger | None = None,
        memory_optimizer: MemoryOptimizerProtocol | None = None,
        parallel_executor: ParallelHookExecutor | None = None,
        async_executor: AsyncCommandExecutor | None = None,
        git_cache: GitOperationCache | None = None,
        filesystem_cache: FileSystemCache | None = None,
        settings: t.Any | None = None,
        enable_hooks: list[str] | None = None,
    ) -> None:
        from crackerjack.config import load_settings
        from crackerjack.config.settings import CrackerjackSettings
        from crackerjack.managers.hook_manager import HookManagerImpl
        from crackerjack.managers.publish_manager import PublishManagerImpl
        from crackerjack.managers.test_manager import TestManagementImpl
        from crackerjack.services.filesystem import FileSystemService
        from crackerjack.services.git import GitService

        self.console = console or CrackerjackConsole()
        self.pkg_path = pkg_path or Path.cwd()
        self.session = session or SessionCoordinator(
            console=self.console,
            pkg_path=self.pkg_path,
        )

        self._settings = settings or load_settings(CrackerjackSettings)

        # Adapter learning integration
        from crackerjack.integration.dhara_integration import (
            DharaLearningIntegration,
            create_adapter_learner,
        )

        learning = self._settings.learning
        adapter_learner = create_adapter_learner(
            enabled=getattr(learning, "adapter_learning_enabled", False),
            db_path=Path(
                getattr(
                    learning, "adapter_learning_db", ".crackerjack/adapter_learning.db"
                )
            ),
            min_attempts=getattr(learning, "adapter_min_attempts", 5),
            backend=getattr(learning, "adapter_learning_backend", "auto"),
        )
        self._adapter_learning = DharaLearningIntegration(
            adapter_learner=adapter_learner
        )

        self.filesystem = filesystem or FileSystemService()
        self.git_service = git_service or GitService(
            console=self.console,
            pkg_path=self.pkg_path,
        )
        self.hook_manager = hook_manager or HookManagerImpl(
            pkg_path=self.pkg_path,
            verbose=getattr(self._settings.execution, "verbose", False),
            quiet=False,
            console=self.console,
            settings=self._settings,
            enable_hooks=enable_hooks,
            adapter_learner_integration=self._adapter_learning,
        )
        self.test_manager = test_manager or TestManagementImpl(
            console=self.console,
            pkg_path=self.pkg_path,
        )
        self.publish_manager = publish_manager or PublishManagerImpl(
            console=self.console,
            pkg_path=self.pkg_path,
        )
        self.config_merge_service = config_merge_service

        self.code_cleaner = CodeCleaner(
            console=self.console,
            base_directory=self.pkg_path,
            file_processor=None,
            error_handler=None,
            pipeline=None,
            logger=None,
            security_logger=None,
            backup_service=None,
            strip_comments_only=getattr(settings, "strip_comments_only", False)
            if settings
            else False,
            strip_docstrings_only=getattr(settings, "strip_docstrings_only", False)
            if settings
            else False,
        )

        self._logger = logger or logging.getLogger(__name__)

        self._memory_optimizer = memory_optimizer
        self._parallel_executor = parallel_executor
        self._async_executor = async_executor
        self._git_cache = git_cache
        self._filesystem_cache = filesystem_cache

        self._last_hook_summary: dict[str, t.Any] | None = None
        self._last_hook_results: list[HookResult] = []

        self._lazy_autofix = create_lazy_service(
            lambda: AutofixCoordinator(
                pkg_path=pkg_path,
                adapter_learner_integration=self._adapter_learning,
            ),
            "autofix_coordinator",
        )
        self.console.print()

        self._fast_hooks_started: bool = False

    @property
    def logger(self) -> logging.Logger:
        return self._logger

    @logger.setter
    def logger(self, value: logging.Logger) -> None:
        self._logger = value

    def _create_enhanced_coordinator_factory(
        self,
    ) -> t.Callable[[AgentContext, CrackerjackCache], AgentCoordinator]:

        def factory(context: AgentContext, cache: CrackerjackCache) -> AgentCoordinator:
            from crackerjack.agents.enhanced_coordinator import (
                EnhancedAgentCoordinator,
            )
            from crackerjack.agents.tracker import AgentTracker
            from crackerjack.services.debug import get_ai_agent_debugger

            return EnhancedAgentCoordinator(
                context=context,
                tracker=AgentTracker(),
                debugger=get_ai_agent_debugger(),
                cache=cache,
                enable_external_agents=True,
            )

        return factory

    @staticmethod
    def _strip_ansi(text: str) -> str:
        ansi_re = re.compile(r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
        return ansi_re.sub("", text)

    def _is_plain_output(self) -> bool:
        try:
            if bool(getattr(self.console, "_plain_mode", False)):
                return True

            is_tty = bool(getattr(self.console, "is_terminal", True))
            color_system = getattr(self.console, "color_system", None)
            return (not is_tty) or (color_system in (None, "null"))
        except Exception:
            return True

    @handle_errors
    def run_config_cleanup_phase(self, options: OptionsProtocol) -> bool:
        self.session.track_task("config_cleanup", "Config cleanup")
        self._display_cleanup_header()

        from crackerjack.services.config_cleanup import ConfigCleanupService

        cleanup_service = ConfigCleanupService(
            console=self.console,
            pkg_path=self.pkg_path,
            git_service=self.git_service,
            settings=self._settings,
        )

        dry_run = getattr(options, "configs_dry_run", False)
        result = cleanup_service.cleanup_configs(dry_run=dry_run)

        if result.success:
            self.session.complete_task(
                "config_cleanup",
                details=result.summary,
            )
            return True

        self.session.fail_task(
            "config_cleanup",
            result.error_message or "Config cleanup failed",
        )
        return False

    @handle_errors
    def run_cleaning_phase(self, options: OptionsProtocol) -> bool:
        if not getattr(options, "clean", False):
            return True

        self.session.track_task("cleaning", "Code cleaning")
        self._display_cleaning_header()
        return self._execute_cleaning_process()

    @handle_errors
    def run_configuration_phase(self, options: OptionsProtocol) -> bool:
        if options.no_config_updates:
            return True
        self.session.track_task("configuration", "Configuration updates")
        self.console.print(
            "[dim]⚙️ Configuration phase skipped (no automated updates defined).[/dim]",
        )
        self.session.complete_task(
            "configuration",
            "No configuration updates were required.",
        )
        return True

    @handle_errors
    async def run_hooks_phase(self, options: OptionsProtocol) -> bool:
        if options.skip_hooks:
            return True

        if not await self.run_fast_hooks_only(options):
            return False

        return await self.run_comprehensive_hooks_only(options)

    async def run_fast_hooks_only(self, options: OptionsProtocol) -> bool:
        if options.skip_hooks:
            self.console.print("[yellow]⚠️[/yellow] Skipping fast hooks (--skip-hooks)")
            return True

        if getattr(self, "_fast_hooks_started", False):
            self.logger.debug("Duplicate fast hooks invocation detected; skipping")
            return True

        self._fast_hooks_started = True
        self.session.track_task("hooks_fast", "Fast quality checks")

        success = self._run_fast_hooks_with_retry(options)

        if not success and getattr(options, "ai_fix", False):
            success = await self._apply_ai_fix_for_fast_hooks(options, success)

        self._complete_fast_hooks_task(success)

        return success

    def _run_fast_hooks_with_retry(self, options: OptionsProtocol) -> bool:
        max_attempts = 2
        attempt = 0
        success = False

        while attempt < max_attempts:
            attempt += 1

            if attempt > 1:
                self.console.print(
                    f"\n[yellow]♻️[/yellow] Verification Retry {attempt}/{max_attempts}\n",
                )

            self._display_hook_phase_header(
                "FAST HOOKS",
                "Formatters, import sorting, and quick static analysis",
            )

            success = self._execute_hooks_once(
                "fast",
                self.hook_manager.run_fast_hooks,
                options,
                attempt,
            )

            if success:
                break

            if getattr(options, "fast_iteration", False):
                break

            if attempt < max_attempts:
                self._display_hook_failures("fast", self._last_hook_results, options)

        return success

    def _complete_fast_hooks_task(self, success: bool) -> None:
        summary = self._last_hook_summary or {}
        details = self._format_hook_summary(summary)

        if success:
            self.session.complete_task("hooks_fast", details=details)
        else:
            self.session.fail_task("hooks_fast", "Fast hook failures detected")

        self.console.print()

    def _should_show_ai_fix_banner(self, options: OptionsProtocol) -> bool:
        return bool(options.verbose or getattr(options, "ai_debug", False))

    async def _apply_ai_fix_for_fast_hooks(
        self, options: OptionsProtocol, current_success: bool
    ) -> bool:
        max_ai_iterations = 3
        attempt = 2

        from crackerjack.core.autofix_coordinator import AutofixCoordinator

        for ai_iteration in range(max_ai_iterations):
            ai_iteration_num = ai_iteration + 1
            attempt += 1

            if self._should_show_ai_fix_banner(options):
                self.console.print("\n")
                if ai_iteration_num == 1:
                    self.console.print(
                        "[bold bright_magenta]🤖 AI AGENT FIXING[/bold bright_magenta] "
                        "[bold bright_white]Attempting automated fixes for fast hook failures[/bold bright_white]"
                    )
                else:
                    self.console.print(
                        f"[bold bright_magenta]🤖 AI AGENT FIXING[/bold bright_magenta] "
                        f"[bold bright_white]Iteration {ai_iteration_num}/{max_ai_iterations} - Fixing remaining issues[/bold bright_white]"
                    )
                self.console.print(make_separator("-"))

            autofix_coordinator = AutofixCoordinator(
                console=self.console,  # type: ignore[arg-type]
                pkg_path=self.pkg_path,
                max_iterations=getattr(options, "ai_fix_max_iterations", None),
                coordinator_factory=self._create_enhanced_coordinator_factory(),
                adapter_learner_integration=self._adapter_learning,
            )

            ai_fix_success = await autofix_coordinator.apply_fast_stage_fixes(
                hook_results=self._last_hook_results
            )

            if not ai_fix_success:
                if ai_iteration_num == 1:
                    self.console.print(
                        "[yellow]⚠️[/yellow] AI agents unable to fix fast hook issues"
                    )
                else:
                    self.console.print(
                        f"[yellow]⚠️[/yellow] AI agents unable to fix remaining issues (iteration {ai_iteration_num})"
                    )
                self.console.print()
                return current_success

            self.console.print(
                "[green]✅[/green] AI agents applied fixes, retrying fast hooks..."
            )
            self.console.print()

            self._display_hook_phase_header(
                "FAST HOOKS",
                "Formatters, import sorting, and quick static analysis",
            )

            success = self._execute_hooks_once(
                "fast",
                self.hook_manager.run_fast_hooks,
                options,
                attempt=attempt,
            )

            if success:
                self.console.print(
                    f"[green]✅[/green] Fast hooks passed after AI fixes (iteration {ai_iteration_num})!"
                )
                self.console.print()
                return True

            if ai_iteration_num < max_ai_iterations:
                self.console.print(
                    f"[yellow]⚠️[/yellow] Fast hooks still failing after AI fixes (iteration {ai_iteration_num}), trying again..."
                )
                self.console.print()
            else:
                self.console.print(
                    f"[yellow]⚠️[/yellow] Fast hooks still failing after {max_ai_iterations} AI-fix iterations"
                )
                self.console.print()

        return False

    def _apply_ai_fix_for_tests(self, options: OptionsProtocol) -> bool:
        from rich.console import Console as RichConsole
        from rich.prompt import Confirm

        test_failures = self.test_manager.get_test_failures()
        if not test_failures:
            self.console.print("[yellow]⚠️[/yellow] No test failures detected")
            return False

        safe_failures = self._classify_safe_test_failures(test_failures)
        if not safe_failures:
            self.console.print(
                "[yellow]⚠️[/yellow] Test failures require manual review (not safe for auto-fix)"
            )
            self.console.print(
                "[yellow]   Hint:[/yellow] Complex logic errors, assertion failures, or infrastructure issues"
            )
            return False

        total_failures = len(test_failures)
        fixable_count = len(safe_failures)

        self.console.print("\n")
        self.console.print(
            f"[cyan]📊 AI Analysis:[/cyan] {fixable_count}/{total_failures} test failures may be auto-fixable"
        )
        self.console.print()

        for failure in safe_failures[:3]:
            self.console.print(f"  • {failure[:100]}")

        if len(safe_failures) > 3:
            self.console.print(f"  ... and {len(safe_failures) - 3} more")

        self.console.print()
        self.console.print(
            "[bold yellow]⚠️  AI will attempt to fix these test failures[/bold yellow]"
        )
        self.console.print(
            "[bold yellow]    Review all changes carefully before accepting[/bold yellow]"
        )
        self.console.print()

        try:
            rich_console = RichConsole()
            user_confirms = Confirm.ask(
                "[yellow]Attempt AI auto-fix for these test failures?[/yellow]",
                console=rich_console,
                default=False,
            )

            if not user_confirms:
                self.console.print("[yellow]Skipped AI-fix for tests[/yellow]")
                return False

        except Exception:
            self.console.print(
                "[yellow]⚠️[/yellow] Test AI-fix requires interactive mode"
            )
            return False

        return self._run_ai_test_fix(safe_failures, options)

    def _run_ai_test_fix(
        self, safe_failures: list[str], options: OptionsProtocol
    ) -> bool:
        from crackerjack.agents.base import AgentContext, Issue, IssueType, Priority
        from crackerjack.agents.coordinator import AgentCoordinator
        from crackerjack.services.cache import CrackerjackCache

        if self._should_show_ai_fix_banner(options):
            self.console.print(
                "[bold bright_magenta]🤖 AI AGENT FIXING[/bold bright_magenta] "
                "[bold bright_white]Attempting automated test fixes[/bold bright_white]"
            )
            self.console.print(make_separator("-") + "\n")

        context = AgentContext(
            project_path=self.pkg_path,
            subprocess_timeout=300,
        )
        cache = CrackerjackCache()

        from crackerjack.agents.tracker import AgentTracker
        from crackerjack.services.debug import get_ai_agent_debugger

        coordinator = AgentCoordinator(
            context=context,
            tracker=AgentTracker(),
            debugger=get_ai_agent_debugger(),
            cache=cache,
        )

        issues = [
            Issue(
                type=IssueType.IMPORT_ERROR,
                severity=Priority.HIGH,
                message=failure,
                file_path="test_failures",
                line_number=0,
                stage="tests",
            )
            for failure in safe_failures
        ]

        try:
            import asyncio

            try:
                asyncio.get_running_loop()
                with ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        coordinator.handle_issues(issues),  # type: ignore[unused-coroutine]
                    )
                    fix_result = future.result(timeout=300)
            except RuntimeError:
                fix_result = asyncio.run(coordinator.handle_issues(issues))

            if fix_result and fix_result.success:
                fixed_count = len(fix_result.fixes_applied)
                remaining_count = len(fix_result.remaining_issues)
                self.console.print(
                    f"[green]✅[/green] AI agents fixed {fixed_count} test failure(s)"
                )
                if remaining_count > 0:
                    self.console.print(
                        f"[yellow]⚠️[/yellow] {remaining_count} test failures remain"
                    )
                return fixed_count == 0

            self.console.print(
                "[yellow]⚠️[/yellow] AI agents unable to fix test failures"
            )
            return False

        except Exception as e:
            self.console.print(f"[yellow]⚠️[/yellow] AI fix failed: {e}")
            return False

    def _classify_safe_test_failures(self, failures: list[str]) -> list[str]:
        safe_failures = []
        risky_patterns = [
            "AssertionError",
            "assert ",
            "Failed: ",
            "AssertionError: ",
            "Integration",
            "infrastructure",
        ]

        for failure in failures:
            failure_lower = failure.lower()

            if any(risky.lower() in failure_lower for risky in risky_patterns):
                continue

            safe_patterns = (
                "modulenotfounderror",
                "importerror",
                "attributeerror",
                "import ",
                "no module named",
                "cannot import",
            )
            if any(safe in failure_lower for safe in safe_patterns):
                safe_failures.append(failure)
                continue

        return safe_failures

    async def _apply_ai_fix_for_comprehensive_hooks(
        self, options: OptionsProtocol, current_success: bool
    ) -> bool:
        max_ai_iterations = 3
        attempt = 1

        from crackerjack.core.autofix_coordinator import AutofixCoordinator

        for ai_iteration in range(max_ai_iterations):
            ai_iteration_num = ai_iteration + 1
            attempt += 1

            if self._should_show_ai_fix_banner(options):
                self.console.print("\n")
                if ai_iteration_num == 1:
                    self.console.print(
                        "[bold bright_magenta]🤖 AI AGENT FIXING[/bold bright_magenta] "
                        "[bold bright_white]Attempting automated fixes for comprehensive hook failures[/bold bright_white]"
                    )
                else:
                    self.console.print(
                        f"[bold bright_magenta]🤖 AI AGENT FIXING[/bold bright_magenta] "
                        f"[bold bright_white]Iteration {ai_iteration_num}/{max_ai_iterations} - Fixing remaining issues[/bold bright_white]"
                    )
                self.console.print(make_separator("-"))

            autofix_coordinator = AutofixCoordinator(
                console=self.console,  # type: ignore[arg-type]
                pkg_path=self.pkg_path,
                max_iterations=getattr(options, "ai_fix_max_iterations", None),
                coordinator_factory=self._create_enhanced_coordinator_factory(),
                adapter_learner_integration=self._adapter_learning,
            )

            ai_fix_success = await autofix_coordinator.apply_comprehensive_stage_fixes(
                hook_results=self._last_hook_results
            )

            if not ai_fix_success:
                if ai_iteration_num == 1:
                    self.console.print(
                        "[yellow]⚠️[/yellow] AI agents unable to fix comprehensive hook issues"
                    )
                else:
                    self.console.print(
                        f"[yellow]⚠️[/yellow] AI agents unable to fix remaining issues (iteration {ai_iteration_num})"
                    )
                self.console.print()
                return current_success

            self.console.print(
                "[green]✅[/green] AI agents applied fixes, retrying comprehensive hooks..."
            )
            self.console.print()

            self._display_hook_phase_header(
                "COMPREHENSIVE HOOKS",
                "Type, security, and complexity checking",
            )

            success = self._execute_hooks_once(
                "comprehensive",
                self.hook_manager.run_comprehensive_hooks,
                options,
                attempt=attempt,
            )

            if success:
                self.console.print(
                    f"[green]✅[/green] Comprehensive hooks passed after AI fixes (iteration {ai_iteration_num})!"
                )
                self.console.print()
                return True

            if ai_iteration_num < max_ai_iterations:
                self.console.print(
                    f"[yellow]⚠️[/yellow] Comprehensive hooks still failing after AI fixes (iteration {ai_iteration_num}), trying again..."
                )
                self.console.print()
            else:
                self.console.print(
                    f"[yellow]⚠️[/yellow] Comprehensive hooks still failing after {max_ai_iterations} AI-fix iterations"
                )
                self.console.print()

        return False

    async def run_comprehensive_hooks_only(self, options: OptionsProtocol) -> bool:
        if options.skip_hooks:
            self.console.print(
                "[yellow]⚠️[/yellow] Skipping comprehensive hooks (--skip-hooks)",
            )
            return True

        self.session.track_task("hooks_comprehensive", "Comprehensive quality checks")
        self._display_hook_phase_header(
            "COMPREHENSIVE HOOKS",
            "Type, security, and complexity checking",
        )

        success = self._execute_hooks_once(
            "comprehensive",
            self.hook_manager.run_comprehensive_hooks,
            options,
            attempt=1,
        )

        if not success and getattr(options, "ai_fix", False):
            success = await self._apply_ai_fix_for_comprehensive_hooks(options, success)

        if not success:
            self._display_hook_failures(
                "comprehensive",
                self._last_hook_results,
                options,
            )

        summary = self._last_hook_summary or {}
        details = self._format_hook_summary(summary)

        if success:
            self.session.complete_task("hooks_comprehensive", details=details)
        else:
            self.session.fail_task(
                "hooks_comprehensive",
                "Comprehensive hook failures detected",
            )

        return success

    @handle_errors
    def run_testing_phase(self, options: OptionsProtocol) -> bool:
        if not getattr(options, "test", False) and not getattr(
            options,
            "run_tests",
            False,
        ):
            return True
        self.session.track_task("testing", "Test execution")
        self.console.print("\n" + make_separator("-"))
        self.console.print(
            "[bold bright_blue]🧪 TESTS[/bold bright_blue] [bold bright_white]Running test suite[/bold bright_white]",
        )
        self.console.print(make_separator("-") + "\n")
        if not self.test_manager.validate_test_environment():
            self.session.fail_task("testing", "Test environment validation failed")
            return False
        test_success = self.test_manager.run_tests(options)

        if test_success:
            coverage_info = self.test_manager.get_coverage()
            self.session.complete_task(
                "testing",
                f"Tests passed, coverage: {coverage_info.get('total_coverage', 0):.1f}%",
            )
        else:
            if getattr(options, "ai_fix", False):
                ai_fix_success = self._apply_ai_fix_for_tests(options)
                if ai_fix_success:
                    self.console.print(
                        "[green]✅[/green] AI agents applied fixes, re-running tests..."
                    )
                    self.console.print()
                    test_success = self.test_manager.run_tests(options)
                    if test_success:
                        coverage_info = self.test_manager.get_coverage()
                        self.session.complete_task(
                            "testing",
                            f"Tests passed after AI fixes, coverage: {coverage_info.get('total_coverage', 0):.1f}%",
                        )
                        return test_success

            self.session.fail_task("testing", "Tests failed")

        return test_success

    @handle_errors
    def run_documentation_cleanup_phase(self, options: OptionsProtocol) -> bool:
        if not getattr(options, "cleanup_docs", False):
            return True

        self.session.track_task("documentation_cleanup", "Documentation cleanup")
        self._display_cleanup_header()

        from crackerjack.services.documentation_cleanup import DocumentationCleanup

        cleanup_service = DocumentationCleanup(
            console=self.console,
            pkg_path=self.pkg_path,
            git_service=self.git_service,
            settings=self._settings,
        )

        dry_run = getattr(options, "docs_dry_run", False)
        result = cleanup_service.cleanup_documentation(dry_run=dry_run)

        if result.success:
            self.session.complete_task(
                "documentation_cleanup",
                details=result.summary,
            )
            return True

        self.session.fail_task(
            "documentation_cleanup",
            result.error_message or "Documentation cleanup failed",
        )
        return False

    @handle_errors
    def run_git_cleanup_phase(self, options: OptionsProtocol) -> bool:
        if not getattr(options, "cleanup_git", False):
            return True

        self.session.track_task("git_cleanup", "Git cleanup")
        self._display_cleanup_header()

        from crackerjack.services.git_cleanup_service import GitCleanupService

        git_service = GitCleanupService(
            console=self.console,
            pkg_path=self.pkg_path,
            git_service=self.git_service,
            settings=self._settings,
        )

        result = git_service.cleanup_git_deleted_files(dry_run=False)

        if result.success:
            self.session.complete_task(
                "git_cleanup",
                details=result.summary,
            )
            return True

        self.session.fail_task(
            "git_cleanup",
            result.error_message or "Git cleanup failed",
        )
        return False

    @handle_errors
    def run_doc_update_phase(self, options: OptionsProtocol) -> bool:
        if not getattr(options, "update_docs", False):
            return True

        self.session.track_task("doc_updates", "Documentation updates")
        self._display_cleanup_header()

        from crackerjack.services.doc_update_service import DocUpdateService

        doc_service = DocUpdateService(
            console=self.console,
            pkg_path=self.pkg_path,
            git_service=self.git_service,
            settings=self._settings,
        )

        result = doc_service.update_documentation(dry_run=False)

        if result.success:
            self.session.complete_task(
                "doc_updates",
                details=result.summary,
            )
            return True

        self.session.fail_task(
            "doc_updates",
            result.error_message or "Documentation updates failed",
        )
        return False

    @handle_errors
    def run_publishing_phase(self, options: OptionsProtocol) -> bool:
        version_type = self._determine_version_type(options)
        if not version_type:
            return True

        self.session.track_task("publishing", f"Publishing ({version_type})")
        return self._execute_publishing_workflow(options, version_type)

    @handle_errors
    def run_commit_phase(self, options: OptionsProtocol) -> bool:
        if not options.commit:
            return True

        version_type = self._determine_version_type(options)
        if version_type:
            self.console.print(
                "[dim]ℹ️ Commit phase skipped (handled by publish workflow)[/dim]",
            )
            return True

        self._display_commit_push_header()
        self.session.track_task("commit", "Git commit and push")
        changed_files = self.git_service.get_changed_files()
        if not changed_files:
            return self._handle_no_changes_to_commit()
        commit_message = self._get_commit_message(changed_files, options)
        return self._execute_commit_and_push(changed_files, commit_message)

    def _execute_hooks_once(
        self,
        suite_name: str,
        hook_runner: t.Callable[[], list[HookResult]],
        options: OptionsProtocol,
        attempt: int,
    ) -> bool:
        self._last_hook_summary = None
        self._last_hook_results = []

        hook_count = self.hook_manager.get_hook_count(suite_name)
        progress = self._create_progress_bar()

        callbacks = self._setup_progress_callbacks(progress)
        elapsed_time = self._run_hooks_with_progress(
            suite_name,
            hook_runner,
            progress,
            hook_count,
            attempt,
            callbacks,
        )

        if elapsed_time is None:
            return False

        return self._process_hook_results(suite_name, elapsed_time, attempt)

    def _create_progress_bar(self) -> Progress:
        from rich.console import Console as RichConsole

        console = (
            RichConsole() if not isinstance(self.console, RichConsole) else self.console
        )

        return Progress(
            SpinnerColumn(spinner_name="dots"),
            TextColumn("[cyan]{task.description}[/cyan]"),
            BarColumn(bar_width=20),
            MofNCompleteColumn(),
            console=console,
            transient=True,
        )

    def _setup_progress_callbacks(
        self,
        progress: Progress,
    ) -> dict[str, t.Callable[[int, int], None] | None | dict[str, t.Any]]:
        task_id_holder = {"task_id": None}

        def update_progress(completed: int, total: int) -> None:
            if task_id_holder["task_id"] is not None:
                progress.update(task_id_holder["task_id"], completed=completed)

        def update_progress_started(started: int, total: int) -> None:
            if task_id_holder["task_id"] is not None:
                progress.update(task_id_holder["task_id"], completed=started)

        original_callback = getattr(self.hook_manager, "_progress_callback", None)
        original_start_callback = getattr(
            self.hook_manager,
            "_progress_start_callback",
            None,
        )

        self.hook_manager._progress_callback = update_progress
        self.hook_manager._progress_start_callback = update_progress_started

        return {
            "update": update_progress,
            "update_started": update_progress_started,
            "original": original_callback,
            "original_started": original_start_callback,
            "task_id_holder": task_id_holder,
        }

    def _run_hooks_with_progress(
        self,
        suite_name: str,
        hook_runner: t.Callable[[], list[HookResult]],
        progress: Progress,
        hook_count: int,
        attempt: int,
        callbacks: dict[str, t.Any],
    ) -> float | None:
        try:
            with progress:
                task_id = progress.add_task(
                    f"Running {suite_name} hooks:",
                    total=hook_count,
                )
                callbacks["task_id_holder"]["task_id"] = task_id

                import time

                start_time = time.time()
                hook_results = hook_runner()
                self._last_hook_results = hook_results
                return time.time() - start_time

        except Exception as exc:
            self._handle_hook_execution_error(suite_name, exc, attempt)
            return None
        finally:
            self._restore_progress_callbacks(callbacks)

    def _handle_hook_execution_error(
        self,
        suite_name: str,
        exc: Exception,
        attempt: int,
    ) -> None:
        self.console.print(
            f"[red]❌[/red] {suite_name.title()} hooks encountered an unexpected error: {exc}",
        )
        self.logger.error(
            "Hook execution raised exception: %s",
            exc,
            extra={"suite": suite_name, "attempt": attempt},
        )

    def _restore_progress_callbacks(self, callbacks: dict[str, t.Any]) -> None:
        self.hook_manager._progress_callback = callbacks["original"]
        self.hook_manager._progress_start_callback = callbacks["original_started"]

    def _process_hook_results(
        self,
        suite_name: str,
        elapsed_time: float,
        attempt: int,
    ) -> bool:
        summary = self.hook_manager.get_hook_summary(
            self._last_hook_results,
            elapsed_time=elapsed_time,
        )
        self._last_hook_summary = summary

        self._update_json_hook_issue_counts()

        self._report_hook_results(suite_name, self._last_hook_results, summary, attempt)

        if summary.get("failed", 0) == 0 == summary.get("errors", 0):
            return True

        self.logger.warning(
            "Hook suite reported failures",
            extra={
                "suite": suite_name,
                "attempt": attempt,
                "failed": summary.get("failed", 0),
                "errors": summary.get("errors", 0),
            },
        )
        return False

    def _display_hook_phase_header(self, title: str, description: str) -> None:
        sep = make_separator("-")
        self.console.print("\n" + sep)

        pretty_title = title.title()
        message = (
            f"[bold bright_cyan]🔍 {pretty_title}[/bold bright_cyan][bold bright_white]"
            f" - {description}[/bold bright_white]"
        )
        self.console.print(message)
        self.console.print(sep + "\n")

    def _report_hook_results(
        self,
        suite_name: str,
        results: list[HookResult],
        summary: dict[str, t.Any],
        attempt: int,
    ) -> None:
        total = summary.get("total", 0)
        passed = summary.get("passed", 0)
        failed = summary.get("failed", 0)
        errors = summary.get("errors", 0)
        duration = summary.get("total_duration", 0.0)

        if total == 0:
            self.console.print(
                f"[yellow]⚠️[/yellow] No {suite_name} hooks are configured for this project.",
            )
            return

        base_message = (
            f"{suite_name.title()} hooks attempt {attempt}: "
            f"{passed}/{total} passed in {duration:.2f}s"
        )

        if failed or errors:
            self.console.print(f"\n[red]❌[/red] {base_message}\n")

            self._render_hook_results_table(suite_name, results)
        else:
            self.console.print(f"\n[green]✅[/green] {base_message}\n")
            self._render_hook_results_table(suite_name, results)

    def _render_hook_results_table(
        self,
        suite_name: str,
        results: list[HookResult],
    ) -> None:
        if not results:
            return

        if self._is_plain_output():
            self._render_plain_hook_results(suite_name, results)
        else:
            self._render_rich_hook_results(suite_name, results)

    def _render_plain_hook_results(
        self,
        suite_name: str,
        results: list[HookResult],
    ) -> None:
        self.console.print(f"{suite_name.title()} Hook Results:", highlight=False)

        stats = self._calculate_hook_statistics(results)
        hooks_to_show = stats["failed_hooks"] or results

        for result in hooks_to_show:
            self._print_plain_hook_result(result)

        if not stats["failed_hooks"] and results:
            self._print_plain_summary(stats)

        self.console.print()

    def _calculate_hook_statistics(self, results: list[HookResult]) -> dict[str, t.Any]:
        passed_hooks = [r for r in results if r.status.lower() in {"passed", "success"}]
        failed_hooks = [
            r for r in results if r.status.lower() in {"failed", "error", "timeout"}
        ]
        other_hooks = [
            r
            for r in results
            if r.status.lower()
            not in {"passed", "success", "failed", "error", "timeout"}
        ]

        total_issues = 0
        config_errors = 0
        for r in results:
            if r.status == "passed":
                continue

            if hasattr(r, "is_config_error") and r.is_config_error:
                config_errors += 1
                continue

            if hasattr(r, "issues_count"):
                total_issues += r.issues_count
            elif r.issues_found:
                total_issues += len(r.issues_found)

        return {
            "total_hooks": len(results),
            "passed_hooks": passed_hooks,
            "failed_hooks": failed_hooks,
            "other_hooks": other_hooks,
            "total_passed": len(passed_hooks),
            "total_failed": len(failed_hooks),
            "total_other": len(other_hooks),
            "total_issues_found": total_issues,
            "config_errors": config_errors,
        }

    def _update_json_hook_issue_counts(self) -> None:
        if not self._last_hook_results:
            return

        from crackerjack.parsers.factory import ParserFactory

        ParserFactory()

        for result in self._last_hook_results:
            if not self._should_update_hook_count(result):
                continue

            self._try_update_count_from_json(result)

    def _should_update_hook_count(self, result: HookResult) -> bool:
        if result.issues_count != 0 or result.status != "failed":
            return False

        if not result.output or not result.output.strip().startswith(("{", "[")):
            return False

        return True

    def _try_update_count_from_json(self, result: HookResult) -> None:
        import json

        with suppress(json.JSONDecodeError, KeyError, TypeError):
            data = json.loads(result.output)
            count = self._extract_count_from_json_data(data)
            if count is not None:
                result.issues_count = count

    def _extract_count_from_json_data(self, data: object) -> int | None:
        if isinstance(data, list):
            return len(data)
        if isinstance(data, dict):
            return self._extract_count_from_json_dict(data)
        return None

    def _extract_count_from_json_dict(self, data: dict) -> int | None:
        if "results" in data and isinstance(data["results"], list):
            return len(data["results"])
        if "issues" in data and isinstance(data["issues"], list):
            return len(data["issues"])
        return None

    def _print_plain_hook_result(self, result: HookResult) -> None:
        name = self._strip_ansi(result.name)
        status = result.status.upper()
        duration = f"{result.duration:.2f}s"

        if result.status == "passed":
            issues = "0"
        elif hasattr(result, "is_config_error") and result.is_config_error:
            issues = "[yellow]![/yellow]"
        else:
            issues = str(result.issues_count if hasattr(result, "issues_count") else 0)

        self.console.print(
            f" - {name} :: {status} | {duration} | issues={issues}",
        )

    def _print_plain_summary(self, stats: dict[str, t.Any]) -> None:
        issues_text = f"{stats['total_issues_found']} issues found"
        if stats.get("config_errors", 0) > 0:
            issues_text += f" ({stats['config_errors']} config)"

        self.console.print(
            f" Summary: {stats['total_passed']}/{stats['total_hooks']} hooks passed, {issues_text}",
            highlight=False,
        )

    def _render_rich_hook_results(
        self,
        suite_name: str,
        results: list[HookResult],
    ) -> None:
        stats = self._calculate_hook_statistics(results)
        summary_text = self._build_summary_text(stats)
        table = self._build_results_table(results)
        panel = self._build_results_panel(suite_name, table, summary_text)

        self.console.print(panel)

        has_config_errors = any(
            hasattr(r, "is_config_error") and r.is_config_error for r in results
        )
        if has_config_errors:
            self.console.print(
                " [dim][yellow]![/yellow] = Configuration or tool error (not code "
                "issues)[/dim]",
            )

        self.console.print()

    @staticmethod
    def _build_summary_text(stats: dict[str, t.Any]) -> str:
        summary_text = (
            f"Total: [white]{stats['total_hooks']}[/white] | Passed:"
            f" [green]{stats['total_passed']}[/green] | Failed: [red]{stats['total_failed']}[/red]"
        )
        if stats["total_other"] > 0:
            summary_text += f" | Other: [yellow]{stats['total_other']}[/yellow]"

        issues_text = f"[white]{stats['total_issues_found']}[/white]"
        if stats.get("config_errors", 0) > 0:
            issues_text += f" [dim]({stats['config_errors']} config)[/dim]"
        summary_text += f" | Issues found: {issues_text}"
        return summary_text

    def _build_results_table(self, results: list[HookResult]) -> Table:
        table = Table(
            box=box.SIMPLE,
            header_style="bold bright_white",
            expand=True,
        )
        table.add_column("Hook", style="cyan", overflow="fold", min_width=20)
        table.add_column("Status", style="bright_white", min_width=8)
        table.add_column("Duration", justify="right", style="magenta", min_width=10)
        table.add_column("Issues", justify="right", style="bright_white", min_width=8)

        for result in results:
            status_style = self._status_style(result.status)

            if result.status == "passed":
                issues_display = "0"
            elif hasattr(result, "is_config_error") and result.is_config_error:
                issues_display = "[yellow]![/yellow]"
            else:
                issues_display = str(
                    result.issues_count if hasattr(result, "issues_count") else 0,
                )
            table.add_row(
                self._strip_ansi(result.name),
                f"[{status_style}]{result.status.upper()}[/{status_style}]",
                f"{result.duration:.2f}s",
                issues_display,
            )

        return table

    def _format_issues(self, issues: list[str]) -> list[dict[str, str | int | None]]:
        def _format_single_issue(issue) -> None:
            if hasattr(issue, "file_path") and hasattr(issue, "line_number"):
                return {
                    "file": str(getattr(issue, "file_path", "unknown")),
                    "line": getattr(issue, "line_number", 0),
                    "message": getattr(issue, "message", str(issue)),
                    "code": getattr(issue, "code", None),
                    "severity": getattr(issue, "severity", "warning"),
                    "suggestion": getattr(issue, "suggestion", None),
                }

            return {
                "file": "unknown",
                "line": 0,
                "message": str(issue),
                "code": None,
                "severity": "warning",
                "suggestion": None,
            }

        return [_format_single_issue(issue) for issue in issues]

    def to_json(self, results: list[HookResult], suite_name: str = "") -> dict:
        return {
            "suite": suite_name,
            "summary": self._calculate_hook_statistics(results),
            "hooks": [
                {
                    "name": result.name,
                    "status": result.status,
                    "duration": round(result.duration, 2),
                    "issues_count": len(result.issues_found)
                    if result.issues_found
                    else 0,
                    "issues": self._format_issues(result.issues_found)
                    if result.issues_found
                    else [],
                }
                for result in results
            ],
        }

    def _build_results_panel(
        self,
        suite_name: str,
        table: Table,
        summary_text: str,
    ) -> Panel:
        return Panel(
            table,
            title=f"[bold]{suite_name.title()} Hook Results[/bold]",
            subtitle=summary_text,
            border_style="cyan" if suite_name == "fast" else "magenta",
            padding=(0, 1),
            width=get_console_width(),
            expand=True,
        )

    def _format_failing_hooks(
        self,
        suite_name: str,
        results: list[HookResult],
    ) -> list[HookResult]:
        failing = [
            result
            for result in results
            if result.status.lower() in {"failed", "error", "timeout"}
        ]

        if failing:
            self.console.print(
                f"[red]Details for failing {suite_name} hooks:[/red]",
                highlight=False,
            )

        return failing

    def _display_issue_details(self, result: HookResult) -> None:
        if not result.issues_found:
            return

        for issue in result.issues_found:
            self.console.print(f" - {self._strip_ansi(issue)}", highlight=False)

    def _display_timeout_info(self, result: HookResult) -> None:
        if result.is_timeout:
            self.console.print(" - Hook timed out during execution", highlight=False)

    def _display_exit_code_info(self, result: HookResult) -> None:
        if result.exit_code is not None and result.exit_code != 0:
            exit_msg = f"Exit code: {result.exit_code}"

            if result.exit_code == 137:
                exit_msg += " (killed - possibly timeout or out of memory)"
            elif result.exit_code == 139:
                exit_msg += " (segmentation fault)"
            elif result.exit_code in {126, 127}:
                exit_msg += " (command not found or not executable)"
            self.console.print(f" - {exit_msg}", highlight=False)

    def _display_error_message(self, result: HookResult) -> None:
        if result.error_message:
            error_preview = result.error_message.split("\n")[0][:200]
            self.console.print(f" - Error: {error_preview}", highlight=False)

    def _display_generic_failure(self, result: HookResult) -> None:
        if not result.is_timeout and not result.exit_code and not result.error_message:
            self.console.print(
                " - Hook failed with no detailed error information",
                highlight=False,
            )

    def _display_hook_failures(
        self,
        suite_name: str,
        results: list[HookResult],
        options: OptionsProtocol,
    ) -> None:
        if not (options.verbose or getattr(options, "ai_debug", False)):
            return

        failing = self._format_failing_hooks(suite_name, results)
        if not failing:
            return

        for result in failing:
            self._print_single_hook_failure(result)

        self.console.print()

    def _print_single_hook_failure(self, result: HookResult) -> None:
        self.console.print(
            f" - [red]{self._strip_ansi(result.name)}[/red] ({result.status})",
            highlight=False,
        )

        if result.issues_found:
            self._print_hook_issues(result)
        else:
            self._display_failure_reasons(result)

    def _print_hook_issues(self, result: HookResult) -> None:
        assert result.issues_found is not None
        for issue in result.issues_found:
            self.console.print(f" - {self._strip_ansi(issue)}", highlight=False)

    def _display_failure_reasons(self, result: HookResult) -> None:
        self._display_timeout_info(result)
        self._display_exit_code_info(result)
        self._display_error_message(result)
        self._display_generic_failure(result)

    def _display_cleaning_header(self) -> None:
        sep = make_separator("-")
        self.console.print("\n" + sep)
        self.console.print("[bold bright_green]🧹 CLEANING[/bold bright_green]")
        self.console.print(sep + "\n")

    def _execute_cleaning_process(self) -> bool:
        py_files = list(self.pkg_path.rglob("*.py"))
        if not py_files:
            return self._handle_no_files_to_clean()

        cleaned_files = self._clean_python_files(py_files)
        self._report_cleaning_results(cleaned_files)
        return True

    def _handle_no_files_to_clean(self) -> bool:
        self.console.print("No Python files found to clean")
        self.session.complete_task("cleaning", "No files to clean")
        return True

    def _clean_python_files(self, files: list[Path]) -> list[str]:
        cleaned_files = []
        for file in files:
            if self.code_cleaner.should_process_file(file):
                result = self.code_cleaner.clean_file(file)
                if result.success:
                    cleaned_files.append(str(file))
        return cleaned_files

    def _report_cleaning_results(self, cleaned_files: list[str]) -> None:
        if cleaned_files:
            self.console.print(f"Cleaned {len(cleaned_files)} files")
            self.session.complete_task(
                "cleaning",
                f"Cleaned {len(cleaned_files)} files",
            )
        else:
            self.console.print("No cleaning needed for any files")
            self.session.complete_task("cleaning", "No cleaning needed")

    @staticmethod
    def _determine_version_type(options: OptionsProtocol) -> str | None:
        return options.publish or options.all or options.bump

    def _execute_publishing_workflow(
        self,
        options: OptionsProtocol,
        version_type: str,
    ) -> bool:
        original_head = (
            self.git_service.get_current_commit_hash()
            if hasattr(self.git_service, "get_current_commit_hash")
            else None
        )

        if not self._handle_pre_publish_commit(options):
            return False

        new_version = self._perform_version_bump(version_type)
        if not new_version:
            return False

        current_commit_hash = self._commit_version_changes(new_version)
        if not current_commit_hash:
            return False

        if not self._publish_to_pypi(
            options,
            new_version,
            original_head,
            current_commit_hash,
        ):
            return False

        self._finalize_publishing(options, new_version)

        self.session.complete_task("publishing", f"Published version {new_version}")
        return True

    def _handle_pre_publish_commit(self, options: OptionsProtocol) -> bool:
        if not options.commit:
            return True

        existing_changes = self.git_service.get_changed_files()
        if not existing_changes:
            return True

        self._display_commit_push_header()
        self.console.print(
            "[cyan]ℹ️[/cyan] Committing existing changes before version bump...",
        )
        commit_message = self._get_commit_message(existing_changes, options)
        if not self._execute_commit_and_push(existing_changes, commit_message):
            self.session.fail_task("publishing", "Failed to commit pre-publish changes")
            return False
        self.console.print(
            "[green]✅[/green] Pre-publish changes committed and pushed\n",
        )
        return True

    def _perform_version_bump(self, version_type: str) -> str | None:
        self._display_version_bump_header()

        new_version = self.publish_manager.bump_version(version_type)
        if not new_version:
            self.session.fail_task("publishing", "Version bumping failed")
            return None

        self.console.print(f"[green]✅[/green] Version bumped to {new_version}")
        self.console.print(
            f"[green]✅[/green] Changelog updated for version {new_version}",
        )
        return new_version

    def _commit_version_changes(self, new_version: str) -> str | None:
        self._display_commit_push_header()

        changed_files = self.git_service.get_changed_files()
        if not changed_files:
            self.console.print("[yellow]⚠️[/yellow] No changes to stage")
            self.session.fail_task("publishing", "No changes to commit")
            return None

        if not self.git_service.add_files(changed_files):
            self.session.fail_task("publishing", "Failed to stage files")
            return None
        self.console.print(f"[green]✅[/green] Staged {len(changed_files)} files")

        commit_message = f"chore: bump version to {new_version}"
        if not self.git_service.commit(commit_message):
            self.session.fail_task("publishing", "Failed to commit changes")
            return None
        return (
            self.git_service.get_current_commit_hash()
            if hasattr(self.git_service, "get_current_commit_hash")
            else None
        )

    def _publish_to_pypi(
        self,
        options: OptionsProtocol,
        new_version: str,
        original_head: str | None,
        current_commit_hash: str | None,
    ) -> bool:
        self._display_publish_header()

        if not self.publish_manager.publish_package():
            self.session.fail_task("publishing", "Package publishing failed")

            if current_commit_hash and original_head:
                self._attempt_rollback_version_bump(original_head, current_commit_hash)
            return False
        return True

    def _finalize_publishing(self, options: OptionsProtocol, new_version: str) -> None:
        if not options.no_git_tags:
            if not self.publish_manager.create_git_tag_local(new_version):
                self.console.print(
                    f"[yellow]⚠️[/yellow] Failed to create git tag v{new_version}",
                )

        if not self.git_service.push_with_tags():
            self.console.print("[yellow]⚠️[/yellow] Push failed. Please push manually")

    def _attempt_rollback_version_bump(
        self,
        original_head: str,
        current_commit_hash: str,
    ) -> bool:
        try:
            self.console.print(
                "[yellow]🔄 Attempting to rollback version bump commit...[/yellow]",
            )

            result = self.git_service.reset_hard(original_head)

            if result:
                self.console.print(
                    f"[green]✅ Version bump commit ({current_commit_hash[:8]}...) reverted[/green]",
                )
                return True
            self.console.print("[red]❌ Failed to revert version bump commit[/red]")
            return False
        except Exception as e:
            self.console.print(f"[red]❌ Error during version rollback: {e}[/red]")
            return False

    def _display_version_bump_header(self) -> None:
        sep = make_separator("-")
        self.console.print("\n" + sep)
        self.console.print("[bold bright_cyan]📝 VERSION BUMP[/bold bright_cyan]")
        self.console.print(sep + "\n")

    def _display_commit_push_header(self) -> None:
        sep = make_separator("-")
        self.console.print("\n" + sep)
        self.console.print("[bold bright_blue]📦 COMMIT & PUSH[/bold bright_blue]")
        self.console.print(sep + "\n")

    def _display_publish_header(self) -> None:
        sep = make_separator("-")
        self.console.print("\n" + sep)
        self.console.print("[bold bright_green]🚀 PUBLISH TO PYPI[/bold bright_green]")
        self.console.print(sep + "\n")

    def _display_cleanup_header(self) -> None:
        sep = make_separator("-")
        self.console.print("\n" + sep)
        self.console.print(
            "[bold bright_cyan]🧹 DOCUMENTATION CLEANUP[/bold bright_cyan]"
        )
        self.console.print(sep + "\n")

    def _handle_no_changes_to_commit(self) -> bool:
        self.console.print("No changes to commit")
        self.session.complete_task("commit", "No changes to commit")
        return True

    def _get_commit_message(
        self,
        changed_files: list[str],
        options: OptionsProtocol,
    ) -> str:
        suggestions = self.git_service.get_commit_message_suggestions(changed_files)
        if not suggestions:
            return "Update project files"

        if not options.interactive:
            return suggestions[0]

        return self._interactive_commit_message_selection(suggestions)

    def _interactive_commit_message_selection(self, suggestions: list[str]) -> str:
        self._display_commit_suggestions(suggestions)
        choice = self.console.input(
            "\nEnter number, custom message, or press Enter for default: ",
        ).strip()
        return self._process_commit_choice(choice, suggestions)

    def _display_commit_suggestions(self, suggestions: list[str]) -> None:
        self.console.print("\n[bold]Commit message suggestions:[/bold]")
        for i, suggestion in enumerate(suggestions, 1):
            self.console.print(f" [cyan]{i}[/cyan]: {suggestion}")

    @staticmethod
    def _process_commit_choice(choice: str, suggestions: list[str]) -> str:
        if not choice:
            return suggestions[0]
        if choice.isdigit() and 1 <= int(choice) <= len(suggestions):
            return suggestions[int(choice) - 1]
        return choice

    def _execute_commit_and_push(
        self,
        changed_files: list[str],
        commit_message: str,
    ) -> bool:
        if not self.git_service.add_files(changed_files):
            self.session.fail_task("commit", "Failed to add files to git")
            return False
        if not self.git_service.commit(commit_message):
            self.session.fail_task("commit", "Failed to commit files")
            return False
        if not self.git_service.push():
            self.console.print("[yellow]⚠️[/yellow] Push failed. Please push manually")

        self.session.complete_task("commit", "Committed and pushed changes")
        return True

    @staticmethod
    def _format_hook_summary(summary: dict[str, t.Any]) -> str:
        if not summary:
            return "No hooks executed"

        total = summary.get("total", 0)
        passed = summary.get("passed", 0)
        failed = summary.get("failed", 0)
        errors = summary.get("errors", 0)
        duration = summary.get("total_duration", 0.0)

        parts = [f"{passed}/{total} passed"]
        if failed:
            parts.append(f"{failed} failed")
        if errors:
            parts.append(f"{errors} errors")

        summary_str = ", ".join(parts)
        return f"{summary_str} in {duration:.2f}s"

    @staticmethod
    def _status_style(status: str) -> str:
        normalized = status.lower()
        if normalized == "passed":
            return "green"
        if normalized in {"failed", "error"}:
            return "red"
        if normalized == "timeout":
            return "yellow"
        return "bright_white"
