from __future__ import annotations

import ast
import asyncio
import json
import logging
import os
import shutil
import subprocess
import time
import typing as t
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from crackerjack.config import CrackerjackSettings
from crackerjack.integration.skills_tracking import create_skills_tracker
from crackerjack.services.prompt_evolution import get_prompt_evolution

if TYPE_CHECKING:
    from crackerjack.agents.analysis_coordinator import AnalysisCoordinator
    from crackerjack.agents.coordinator import AgentCoordinator
    from crackerjack.agents.fixer_coordinator import FixerCoordinator
    from crackerjack.agents.validation_coordinator import ValidationCoordinator
    from crackerjack.models.protocols import (
        AgentCoordinatorProtocol,
        LoggerProtocol,
    )

from crackerjack.adapters.factory import DefaultAdapterFactory
from crackerjack.agents.base import AgentContext, FixResult, Issue, IssueType, Priority
from crackerjack.models.fix_plan import FixPlan
from crackerjack.models.qa_config import QACheckConfig
from crackerjack.models.qa_results import QAResult
from crackerjack.parsers.factory import ParserFactory, ParsingError
from crackerjack.services.ai_fix_progress import AIFixProgressManager
from crackerjack.services.cache import CrackerjackCache

logger = logging.getLogger(__name__)


FIX_ORDER: list[list[str]] = [
    ["name-defined", "var-annotated"],
    ["call-arg", "arg-type"],
    # Pass 3: Medium-risk fixes (may need type: ignore)
    ["attr-defined", "union-attr", "assignment"],
    ["operator", "index", "return-value", "misc"],
]


class AutofixCoordinator:
    def __init__(
        self,
        console: Console | None = None,
        pkg_path: Path | None = None,
        logger: LoggerProtocol | None = None,
        max_iterations: int | None = None,
        coordinator_factory: Callable[
            [AgentContext, CrackerjackCache], AgentCoordinatorProtocol
        ]
        | None = None,
        enable_fancy_progress: bool = True,
        enable_agent_bars: bool = True,
        adapter_learner_integration: t.Any | None = None,
    ) -> None:
        self.console = console or Console()
        self.pkg_path = pkg_path or Path.cwd()
        self._adapter_learner_integration = adapter_learner_integration

        self.logger = logger or logging.getLogger("crackerjack.autofix")  # type: ignore[assignment]
        self._max_iterations = max_iterations
        self._coordinator_factory = coordinator_factory
        self._parser_factory = ParserFactory()

        self.progress_manager = AIFixProgressManager(
            console=self.console,
            enabled=enable_fancy_progress,
            enable_agent_bars=enable_agent_bars,
        )

        self._collected_errors: list[dict[str, str]] = []
        self._success_count = 0
        self._total_count = 0
        self._prompt_evolution = get_prompt_evolution()
        self._failed_issue_keys: set[str] = set()

    def _sort_issues_by_fix_order(self, issues: list[Issue]) -> list[Issue]:
        error_code_to_pass: dict[str, int] = {}
        for pass_num, codes in enumerate(FIX_ORDER):
            for code in codes:
                error_code_to_pass[code] = pass_num

        def get_sort_key(issue: Issue) -> int:

            message = issue.message.lower()
            for code in error_code_to_pass:
                if code in message:
                    return error_code_to_pass[code]
            return len(FIX_ORDER)

        return sorted(issues, key=get_sort_key)

    def _collect_error(
        self, error_type: str, message: str, file_path: str = ""
    ) -> None:
        self._collected_errors.append(
            {
                "type": error_type,
                "message": message,
                "file": file_path,
            }
        )

    def record_fix_attempt(
        self,
        issue: Issue,
        attempted_fix: str,
        success: bool,
        context: dict[str, str] | None = None,
    ) -> None:
        if success:
            pass
        else:
            self._prompt_evolution.record_failed_fix(
                issue=issue,
                attempted_fix=attempted_fix,
                failure_reason="Fix validation failed",
                context=context,
            )

    def get_evolved_prompt(self, issue: Issue, base_prompt: str) -> str:
        return self._prompt_evolution.get_evolved_prompt(issue, base_prompt)

    def _display_error_summary(self) -> None:
        if not self._collected_errors:
            return

        from rich.panel import Panel
        from rich.table import Table

        error_groups: dict[str, list[dict[str, str]]] = {}
        for error in self._collected_errors:
            error_type = error["type"]
            if error_type not in error_groups:
                error_groups[error_type] = []
            error_groups[error_type].append(error)

        table = Table(show_header=True, header_style="bold red")
        table.add_column("Error Type", style="red")
        table.add_column("Count", justify="right")
        table.add_column("Files Affected", style="dim")

        for error_type, errors in error_groups.items():
            files = {e["file"] for e in errors if e["file"]}
            files_str = ", ".join(sorted(files)[:3])
            if len(files) > 3:
                files_str += f" (+{len(files) - 3} more)"
            table.add_row(error_type, str(len(errors)), files_str or "N/A")

        self.console.print("\n")
        self.console.print(
            Panel(
                table,
                title=f"[bold red]AI Fix Errors Summary[/bold red] ({len(self._collected_errors)} total)",
                border_style="red",
            )
        )

        if self._total_count > 0:
            rate = (self._success_count / self._total_count) * 100
            self.console.print(
                f"[dim]Success rate: {self._success_count}/{self._total_count} ({rate:.1f}%)[/dim]"
            )

        self._display_detailed_errors(error_groups)

        self._log_errors_to_file(error_groups)

    def _display_detailed_errors(
        self, error_groups: dict[str, list[dict[str, str]]]
    ) -> None:
        from rich.panel import Panel
        from rich.text import Text

        for error_type, errors in error_groups.items():
            if not errors:
                continue

            detailed_text = Text()
            for i, error in enumerate(errors[:3]):
                file_info = f"[{error['file']}] " if error.get("file") else ""
                message = error.get("message", "No details")

                if len(message) > 200:
                    message = message[:197] + "..."
                detailed_text.append(f"\n{i + 1}. {file_info}{message}\n", style="dim")

            if errors:
                remaining = len(errors) - 3
                if remaining > 0:
                    detailed_text.append(
                        f"\n  ... and {remaining} more {error_type.lower()}s\n",
                        style="dim italic",
                    )

                self.console.print(
                    Panel(
                        detailed_text,
                        title=f"[bold yellow]{error_type} Details[/bold yellow] (showing {min(3, len(errors))} of {len(errors)})",
                        border_style="yellow",
                    )
                )

    def _log_errors_to_file(
        self, error_groups: dict[str, list[dict[str, str]]]
    ) -> None:
        import json
        import tempfile
        from datetime import datetime

        log_dirs = [
            self.pkg_path / ".crackerjack" / "logs",
            Path(tempfile.gettempdir()) / "crackerjack" / "logs",
        ]
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        log_data = {
            "timestamp": timestamp,
            "total_errors": len(self._collected_errors),
            "success_count": self._success_count,
            "total_count": self._total_count,
            "success_rate": (
                round((self._success_count / self._total_count) * 100, 1)
                if self._total_count > 0
                else 0
            ),
            "error_groups": error_groups,
        }

        for log_dir in log_dirs:
            try:
                log_dir.mkdir(parents=True, exist_ok=True)
                log_file = log_dir / f"ai-fix-errors-{timestamp}.json"

                with log_file.open("w", encoding="utf-8") as f:
                    json.dump(log_data, f, indent=2)

                display_path = (
                    log_file.relative_to(self.pkg_path)
                    if log_file.is_relative_to(self.pkg_path)
                    else log_file
                )
                self.console.print(f"[dim]📝 Detailed error log: {display_path}[/dim]")
                return
            except Exception as e:
                self.logger.warning(f"Failed to write error log at {log_dir}: {e}")

    async def apply_autofix_for_hooks(
        self, mode: str, hook_results: list[object]
    ) -> bool:

        self._collected_errors = []
        self._success_count = 0
        self._total_count = 0

        try:
            if self._should_skip_autofix(hook_results):
                return False

            if mode == "fast":
                result = await self._apply_fast_stage_fixes()
            elif mode == "comprehensive":
                result = await self._apply_comprehensive_stage_fixes(hook_results)
            else:
                self.logger.warning(f"Unknown autofix mode: {mode}")
                result = False
        except Exception:
            self.logger.exception("Error applying autofix")
            result = False
        finally:
            self._display_error_summary()

        return result

    async def apply_fast_stage_fixes(
        self, hook_results: Sequence[object] | None = None
    ) -> bool:
        return await self._apply_fast_stage_fixes(hook_results)

    async def apply_comprehensive_stage_fixes(
        self, hook_results: Sequence[object]
    ) -> bool:
        return await self._apply_comprehensive_stage_fixes(hook_results)

    def run_fix_command(self, cmd: list[str], description: str) -> bool:
        return self._run_fix_command(cmd, description)

    def check_tool_success_patterns(self, cmd: list[str], result: object) -> bool:
        return self._check_tool_success_patterns(cmd, result)

    def validate_fix_command(self, cmd: list[str]) -> bool:
        return self._validate_fix_command(cmd)

    def validate_hook_result(self, result: object) -> bool:
        return self._validate_hook_result(result)

    def should_skip_autofix(self, hook_results: Sequence[object]) -> bool:
        return self._should_skip_autofix(hook_results)

    async def _apply_fast_stage_fixes(
        self, hook_results: Sequence[object] | None = None
    ) -> bool:
        ai_agent_enabled = os.environ.get("AI_AGENT") == "1"

        if ai_agent_enabled and hook_results is not None:
            self.logger.info(
                "AI agent mode enabled for fast stage, attempting AI-based fixing"
            )
            return await self._apply_ai_agent_fixes(hook_results, stage="fast")

        return self._execute_fast_fixes()

    async def _apply_comprehensive_stage_fixes(
        self, hook_results: Sequence[object]
    ) -> bool:
        self._failed_issue_keys = set()
        ai_agent_enabled = os.environ.get("AI_AGENT") == "1"

        if ai_agent_enabled:
            self.logger.info("AI agent mode enabled, attempting AI-based fixing")
            return await self._apply_ai_agent_fixes(hook_results, stage="comprehensive")

        failed_hooks = self._extract_failed_hooks(hook_results)
        if not failed_hooks:
            return True

        hook_specific_fixes = self._get_hook_specific_fixes(failed_hooks)

        if not self._execute_fast_fixes():
            return False

        all_successful = True
        for cmd, description in hook_specific_fixes:
            if not self._run_fix_command(cmd, description):
                all_successful = False

        return all_successful

    def _extract_failed_hooks(self, hook_results: Sequence[object]) -> set[str]:
        failed_hooks: set[str] = set()
        for result in hook_results:
            if (
                self._validate_hook_result(result)
                and getattr(result, "status", "").lower() == "failed"
            ):
                name = getattr(result, "name", "")
                if isinstance(name, str):
                    failed_hooks.add(name)
        return failed_hooks

    def _get_hook_specific_fixes(
        self,
        failed_hooks: set[str],
    ) -> list[tuple[list[str], str]]:
        fixes: list[tuple[list[str], str]] = []

        if "bandit" in failed_hooks:
            fixes.append((["uv", "run", "bandit", "-r", "."], "bandit analysis"))

        return fixes

    def _execute_fast_fixes(self) -> bool:
        fixes = [
            (["uv", "run", "ruff", "format", "."], "format code"),
            (["uv", "run", "ruff", "check", "--fix", "."], "fix code style"),
        ]

        all_successful = True
        for cmd, description in fixes:
            if not self._run_fix_command(cmd, description):
                all_successful = False

        return all_successful

    def _run_fix_command(self, cmd: list[str], description: str) -> bool:
        if not self._validate_fix_command(cmd):
            self.logger.warning(f"Invalid fix command: {cmd}")
            return False

        try:
            self.logger.info(f"Running fix command: {description}")
            result = subprocess.run(
                cmd,
                check=False,
                cwd=self.pkg_path,
                env=self._get_fix_environment(),
                capture_output=True,
                text=True,
                timeout=300,
            )
            return self._handle_command_result(result, description)
        except Exception:
            self.logger.exception("Error running fix command: %s", description)
            return False

    def _handle_command_result(
        self,
        result: subprocess.CompletedProcess[str],
        description: str,
    ) -> bool:
        if result.returncode == 0:
            self.logger.info(f"Fix command succeeded: {description}")
            return True

        if self._is_successful_fix(result):
            self.logger.info(f"Fix command applied changes: {description}")
            return True

        stderr_excerpt = result.stderr[:200] if result.stderr else "No stderr"
        self.logger.warning(
            "Fix command failed: %s (returncode=%s, stderr=%s)",
            description,
            result.returncode,
            stderr_excerpt,
        )
        return False

    def _get_fix_environment(self) -> dict[str, str]:
        env = os.environ.copy()
        env.update(self._get_uv_environment_paths())
        return env

    def _get_uv_environment_paths(self) -> dict[str, str]:
        import tempfile

        root_dir = self.pkg_path / ".crackerjack" / "uv"
        try:
            if root_dir.exists():
                shutil.rmtree(root_dir)
            cache_dir = root_dir / "cache"
            data_dir = root_dir / "data"
            tool_dir = root_dir / "tools"
            cache_dir.mkdir(parents=True, exist_ok=True)
            data_dir.mkdir(parents=True, exist_ok=True)
            tool_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            root_dir = Path(tempfile.gettempdir()) / "crackerjack" / "uv"
            cache_dir = root_dir / "cache"
            data_dir = root_dir / "data"
            tool_dir = root_dir / "tools"
            cache_dir.mkdir(parents=True, exist_ok=True)
            data_dir.mkdir(parents=True, exist_ok=True)
            tool_dir.mkdir(parents=True, exist_ok=True)

        ruff_cache_dir = cache_dir / "ruff"
        pip_cache_dir = cache_dir / "pip"
        ruff_cache_dir.mkdir(parents=True, exist_ok=True)
        pip_cache_dir.mkdir(parents=True, exist_ok=True)

        return {
            "UV_CACHE_DIR": str(cache_dir),
            "UV_TOOL_DIR": str(tool_dir),
            "XDG_CACHE_HOME": str(cache_dir),
            "XDG_DATA_HOME": str(data_dir),
            "RUFF_CACHE_DIR": str(ruff_cache_dir),
            "PIP_CACHE_DIR": str(pip_cache_dir),
        }

    def _is_successful_fix(self, result: subprocess.CompletedProcess[str]) -> bool:
        success_indicators = [
            "fixed",
            "formatted",
            "reformatted",
            "updated",
            "changed",
            "removed",
        ]

        if hasattr(result, "stdout") and hasattr(result, "stderr"):
            stdout = getattr(result, "stdout", "") or ""
            stderr = getattr(result, "stderr", "") or ""

            if not isinstance(stdout, str):
                stdout = str(stdout)
            if not isinstance(stderr, str):
                stderr = str(stderr)
            output = stdout + stderr
        else:
            output = str(result)

        output_lower = output.lower()

        return any(indicator in output_lower for indicator in success_indicators)

    def _check_tool_success_patterns(self, cmd: list[str], result: object) -> bool:
        if not cmd:
            return False

        if hasattr(result, "returncode"):
            return self._check_process_result_success(result)

        if isinstance(result, str):
            return self._check_string_result_success(result)

        return False

    def _check_process_result_success(self, result: object) -> bool:
        if getattr(result, "returncode", 1) == 0:
            return True

        output = self._extract_process_output(result)
        return self._has_success_patterns(output)

    def _extract_process_output(self, result: object) -> str:
        stdout = getattr(result, "stdout", "") or ""
        stderr = getattr(result, "stderr", "") or ""

        if not isinstance(stdout, str):
            stdout = str(stdout)
        if not isinstance(stderr, str):
            stderr = str(stderr)

        return stdout + stderr

    def _check_string_result_success(self, result: str) -> bool:
        return self._has_success_patterns(result)

    def _has_success_patterns(self, output: str) -> bool:
        if not output:
            return False

        success_patterns = [
            "fixed",
            "formatted",
            "reformatted",
            "would reformat",
            "fixing",
        ]

        output_lower = output.lower()
        return any(pattern in output_lower for pattern in success_patterns)

    def _validate_fix_command(self, cmd: list[str]) -> bool:
        if not cmd or len(cmd) < 2:
            return False

        if cmd[0] != "uv":
            return False

        if cmd[1] != "run":
            return False

        allowed_tools = [
            "bandit",
            "trailing-whitespace",
        ]

        return bool(len(cmd) > 2 and cmd[2] in allowed_tools)

    def _validate_hook_result(self, result: object) -> bool:
        name = getattr(result, "name", None)
        status = getattr(result, "status", None)

        if not name or not isinstance(name, str):
            return False

        if not status or not isinstance(status, str):
            return False

        valid_statuses = {"passed", "failed", "skipped", "error", "timeout"}
        return status.lower() in valid_statuses

    def _should_skip_autofix(self, hook_results: Sequence[object]) -> bool:
        for result in hook_results:
            raw_output = self._extract_raw_output(result)
            if self._has_import_errors(raw_output):
                self.logger.info("Skipping autofix for import errors")
                return True
        return False

    def _extract_raw_output(self, result: object) -> str:
        output = getattr(result, "output", None)
        error = getattr(result, "error", None)
        error_message = getattr(result, "error_message", None)

        output = str(output) if output else ""
        error = str(error) if error else ""
        error_message = str(error_message) if error_message else ""

        return output + error + error_message

    def _has_import_errors(self, raw_output: str) -> bool:
        if not raw_output:
            return False
        output_lower = raw_output.lower()
        return "importerror" in output_lower or "modulenotfounderror" in output_lower

    def _handle_zero_issues_case(
        self, iteration: int, stage: str = "fast"
    ) -> bool | None:
        if iteration > 0:
            self.logger.debug("Verifying issue resolution...")
            verification_issues = self._collect_current_issues(stage=stage)
            if verification_issues:
                count = len(verification_issues)
                issue_word = "issue" if count == 1 else "issues"
                self.logger.warning(
                    f"False positive detected: {count} {issue_word} remain"
                )

                return None
            else:
                self._report_iteration_success(iteration)
                return True
        else:
            self.logger.debug("Iteration 0: No issues detected from hook results")
            return None

    def _get_iteration_issues(
        self,
        iteration: int,
        hook_results: Sequence[object],
        stage: str = "fast",
    ) -> list[Issue]:
        self.logger.debug(
            f"Iteration {iteration}: Parsing {len(hook_results)} hook results"
        )
        issues = self._parse_hook_results_to_issues(hook_results)
        self.logger.info(
            f"Iteration {iteration}: Extracted {len(issues)} issues from hook results"
        )
        return issues

    def _check_coverage_regression(self, hook_results: Sequence[object]) -> list[Issue]:
        coverage_issues: list[Issue] = []

        ratchet_path = self.pkg_path / ".coverage-ratchet.json"
        if not ratchet_path.exists():
            self.logger.debug("No coverage ratchet file found, skipping coverage check")
            return coverage_issues

        try:
            with open(ratchet_path) as f:
                ratchet_data = json.load(f)

            current_coverage = ratchet_data.get("current_coverage", 0)
            baseline = ratchet_data.get("baseline_coverage", 0)
            tolerance = ratchet_data.get("tolerance_margin", 2.0)

            if current_coverage < (baseline - tolerance):
                gap = baseline - current_coverage
                self.logger.warning(
                    f"📉 Coverage regression detected: {current_coverage:.1f}% "
                    f"(baseline: {baseline:.1f}%, gap: {gap:.1f}%)"
                )

                coverage_issues.append(
                    Issue(
                        type=IssueType.COVERAGE_IMPROVEMENT,
                        severity=Priority.HIGH,
                        message=f"Coverage regression: {current_coverage:.1f}% (baseline: {baseline:.1f}%, gap: {gap:.1f}%)",
                        file_path=ratchet_path,  # type: ignore
                        line_number=None,
                        stage="coverage-ratchet",
                        details=[
                            f"baseline_coverage: {baseline:.1f}%",
                            f"current_coverage: {current_coverage:.1f}%",
                            f"regression_amount: {gap:.1f}%",
                            f"tolerance_margin: {tolerance:.1f}%",
                            f"action: Add tests to increase coverage by {gap:.1f}%",
                        ],
                    )
                )
        except Exception as e:
            self._collect_error("Coverage Error", str(e))

        return coverage_issues

    def _should_skip_console_print(self) -> bool:
        return self.progress_manager.is_in_progress()

    def _report_iteration_success(self, iteration: int) -> None:

        if not self._should_skip_console_print():
            self.console.print(
                f"[green]✓ All issues resolved in {iteration} iteration(s)![/green]"
            )
            self.console.print()
        self.logger.info(f"All issues resolved in {iteration} iteration(s)")

    def _should_stop_on_convergence(
        self,
        current_count: int,
        previous_count: float,
        no_progress_count: int,
        fixes_applied: int = 0,
    ) -> bool:
        convergence_threshold = self._get_convergence_threshold()

        if fixes_applied == 0 and current_count >= previous_count:
            if no_progress_count + 1 >= convergence_threshold:
                issue_word = "issue" if current_count == 1 else "issues"

                if not self._should_skip_console_print():
                    self.console.print(
                        f"[yellow]⚠ No progress for {convergence_threshold} iterations "
                        f"({current_count} {issue_word} remain)[/yellow]"
                    )
                self.logger.warning(
                    f"No progress for {convergence_threshold} iterations, "
                    f"{current_count} {issue_word} remain"
                )
                return True
        return False

    def _update_progress_count(
        self,
        current_count: int,
        previous_count: float,
        no_progress_count: int,
        fixes_applied: int = 0,
    ) -> int:

        if fixes_applied > 0:
            self.logger.info(
                f"✓ Progress made: {fixes_applied} fix(es) applied, resetting convergence counter"
            )
            return 0

        if current_count >= previous_count:
            return no_progress_count + 1

        return 0

    def _report_iteration_progress(
        self,
        iteration: int,
        issue_count: int,
    ) -> None:
        issue_word = "issue" if issue_count == 1 else "issues"

        if not self._should_skip_console_print():
            self.console.print(
                f"[cyan]→ Iteration {iteration + 1}: "
                f"{issue_count} {issue_word} to fix[/cyan]"
            )
            self.console.print()
        self.logger.info(
            f"Iteration {iteration + 1}: {issue_count} {issue_word} to fix"
        )

    def _run_ai_fix_iteration(
        self,
        coordinator: AgentCoordinatorProtocol | AgentCoordinator,
        issues: list[Issue],
        iteration: int = 0,
    ) -> tuple[bool, int]:

        issues = self._sort_issues_by_fix_order(issues)
        self.logger.info(
            f"🤖 Starting AI agent fixing iteration {iteration} with {len(issues)} issues (sorted by fix order)"
        )

        self.logger.info("📋 Sending issues to agents:")
        for i, issue in enumerate(issues[:5]):
            issue_type = issue.type.value

            safe_msg = issue.message.replace(" ", "_").replace("=", ":")
            self.logger.info(
                f"  [{i}] type={issue_type:>15s} | "
                f"file={issue.file_path}:{issue.line_number} | "
                f"msg={safe_msg}"
            )
        if len(issues) > 5:
            self.logger.info(
                f"  ... and {len(issues) - 5} more issues (total: {len(issues)})"
            )

        self.logger.info(
            f"🔧 Invoking coordinator.handle_issues(iteration={iteration})..."
        )
        fix_result = self._execute_ai_fix(coordinator, issues, iteration)

        if fix_result is None:
            self._collect_error(
                "AI Fix Error", "AI agent fixing iteration failed - returned None"
            )
            return False, 0

        fixes_applied = len(fix_result.fixes_applied)

        self.logger.info(
            f"✅ AI agent fixing iteration completed:\n"
            f"   - Success: {fix_result.success}\n"
            f"   - Confidence: {fix_result.confidence:.2f}\n"
            f"   - Fixes applied: {fixes_applied}\n"
            f"   - Files modified: {len(fix_result.files_modified)}\n"
            f"   - Remaining issues: {len(fix_result.remaining_issues)}"
        )

        if fix_result.fixes_applied:
            self.logger.info("🔨 Fixes applied:")
            for i, fix in enumerate(fix_result.fixes_applied[:5]):
                self.logger.info(f"  [{i}] {fix[:100]}")
            if len(fix_result.fixes_applied) > 5:
                self.logger.info(
                    f"  ... and {len(fix_result.fixes_applied) - 5} more fixes"
                )

        if fix_result.files_modified:
            self.logger.info(
                f"📝 Files modified: {', '.join(fix_result.files_modified)}"
            )

        if fix_result.files_modified:
            self.logger.info(
                "🔍 Validating modified files for syntax and semantic errors"
            )
            if not self._validate_modified_files(fix_result.files_modified):
                self._collect_error(
                    "Validation Error",
                    "AI agents introduced invalid code - rejecting fixes and rolling back",
                )
                self._revert_ai_fix_changes(fix_result.files_modified)
                return False, 0
            self.logger.info("✅ All modified files validated successfully")

        success = self._process_fix_result(fix_result)
        return success, fixes_applied

    def _execute_ai_fix(
        self,
        coordinator: AgentCoordinatorProtocol | AgentCoordinator,
        issues: list[Issue],
        iteration: int = 0,
    ) -> FixResult | None:
        try:
            self.logger.info(
                f"🚀 Initiating AI agent coordination for issue resolution "
                f"(iteration {iteration})"
            )

            self._validate_issue_file_paths(issues)

            try:
                asyncio.get_running_loop()
                self.logger.debug("Running AI agent fixing in existing event loop")
                result = self._run_in_threaded_loop(coordinator, issues, iteration)
            except RuntimeError:
                self.logger.debug("Creating new event loop for AI agent fixing")
                result = asyncio.run(
                    coordinator.handle_issues(issues, iteration=iteration)  # type: ignore[call-arg]
                )

            self.logger.info("✅ AI agent coordination completed")
            return result
        except Exception:
            self.logger.exception("❌ AI agent handling failed")
            return None

    def _validate_issue_file_paths(self, issues: list[Issue]) -> None:
        self.logger.debug("🔍 Validating file paths for issues...")

        missing_files = []
        for issue in issues:
            if issue.file_path:
                file_path = Path(issue.file_path)
                if not file_path.exists():
                    missing_files.append(str(issue.file_path))
                    self.logger.warning(
                        f"⚠️ File not found: {issue.file_path} (issue: {issue.id})"
                    )

        if missing_files:
            self._collect_error(
                "Missing File Error",
                f"{len(missing_files)} issues reference non-existent files",
                ", ".join(missing_files[:3]),
            )

    def _validate_modified_files(self, modified_files: list[str]) -> bool:

        from ..agents.validation_coordinator import ValidationCoordinator

        validation_coordinator = ValidationCoordinator(project_path=self.pkg_path)

        for file_path_str in modified_files:
            if not self._should_validate_file(file_path_str):
                continue

            file_path = Path(file_path_str)
            if not file_path.exists():
                self.logger.warning(f"⚠️ File not found for validation: {file_path}")
                continue

            content = file_path.read_text()

            if not self._validate_file_syntax(file_path, content):
                return False

            if not self._validate_file_duplicates(file_path, content):
                return False

            try:
                import asyncio

                is_valid, feedback = asyncio.run(
                    validation_coordinator.validate_fix(
                        code=content,
                        file_path=file_path,  # type: ignore
                    )
                )
                if not is_valid:
                    self._collect_error(
                        "ValidationCoordinator",
                        f"Comprehensive validation failed: {feedback}",
                        file_path,  # type: ignore  # type: ignore
                    )
                    return False

            except RuntimeError:
                self.logger.debug(
                    f"Skipping async ValidationCoordinator for {file_path} "
                    "(already in async context)"
                )

        return True

    def _should_validate_file(self, file_path_str: str) -> bool:
        if not file_path_str.endswith(".py"):
            self.logger.debug(f"⏭️ Skipping non-Python file: {file_path_str}")
            return False
        return True

    def _validate_file_syntax(self, file_path: Path, content: str) -> bool:
        try:
            compile(content, file_path, "exec")
            self.logger.debug(f"✅ Syntax validation passed: {file_path}")
            return True
        except SyntaxError as e:
            self._collect_error(
                "Syntax Error",
                f"{e.msg} at line {e.lineno}",
                file_path,  # type: ignore
            )
            return False

    def _validate_file_duplicates(self, file_path: Path, content: str) -> bool:
        import ast

        try:
            tree = ast.parse(content)
            definitions = self._find_definitions(tree)

            duplicates = self._find_duplicate_definitions(definitions, file_path)
            if duplicates:
                return False

            self.logger.debug(f"✅ No duplicate definitions: {file_path}")
            return True

        except Exception as e:
            self.logger.warning(f"⚠️ Could not check for duplicates in {file_path}: {e}")
            return True

    def _find_definitions(self, tree: ast.AST) -> dict[str, int]:
        import ast

        definitions = {}
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = node.name
                if name not in definitions:
                    definitions[name] = node.lineno

        return definitions

    def _find_duplicate_definitions(
        self, definitions: dict[str, int], file_path: Path
    ) -> bool:
        for name, lineno in definitions.items():
            count = sum(
                1 for node_lineno in definitions.values() if node_lineno == lineno
            )
            if count > 1:
                self._collect_error(
                    "Duplicate Definition",
                    f"'{name}' at line {lineno}",
                    file_path,  # type: ignore  # type: ignore
                )
                return True

        return False

    def _revert_ai_fix_changes(self, modified_files: list[str]) -> None:
        import subprocess

        self.logger.warning(f"🔄 Reverting AI changes to {len(modified_files)} files")

        for file_path_str in modified_files:
            try:
                result = subprocess.run(
                    ["git", "checkout", "--", file_path_str],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 0:
                    self.logger.info(f"✅ Reverted changes: {file_path_str}")
                else:
                    self.logger.warning(
                        f"⚠️ Could not revert {file_path_str}: {result.stderr}"
                    )
            except Exception as e:
                self._collect_error("Revert Error", str(e), file_path_str)

    def _run_in_threaded_loop(
        self,
        coordinator: AgentCoordinatorProtocol | AgentCoordinator,
        issues: list[Issue],
        iteration: int = 0,
    ) -> FixResult | None:
        import threading

        result_container: list[FixResult | None] = [None]
        exception_container: list[Exception | None] = [None]

        def run_in_new_loop() -> None:
            try:
                new_loop = asyncio.new_event_loop()
                asyncio.set_event_loop(new_loop)
                try:
                    self.logger.info(
                        "Starting AI agent coordination in threaded event loop"
                    )
                    result_container[0] = new_loop.run_until_complete(
                        asyncio.wait_for(
                            coordinator.handle_issues(issues, iteration=iteration),  # type: ignore[call-arg]
                            timeout=300,
                        )
                    )
                    self.logger.info("AI agent coordination in threaded loop completed")
                finally:
                    new_loop.close()
            except Exception as e:
                self.logger.exception("Error in threaded AI agent coordination")
                exception_container[0] = e

        thread = threading.Thread(target=run_in_new_loop)
        thread.start()
        thread.join(timeout=300)

        if exception_container[0] is not None:
            raise exception_container[0]

        if result_container[0] is None:
            raise RuntimeError("AI agent fixing timed out")

        return result_container[0]

    def _process_fix_result(self, fix_result: FixResult) -> bool:
        fixes_count = len(fix_result.fixes_applied)
        remaining_count = len(fix_result.remaining_issues)

        self.logger.info(
            f"Processing fix result: {fixes_count} fixes applied, {remaining_count} issues remaining"
        )

        if fixes_count > 0:
            for i, fix in enumerate(fix_result.fixes_applied[:3]):
                self.logger.info(f"  Applied fix {i + 1}: {fix[:100]}...")
            if len(fix_result.fixes_applied) > 3:
                self.logger.info(
                    f"  ... and {len(fix_result.fixes_applied) - 3} more fixes"
                )

            return self._handle_partial_progress(
                fix_result, fixes_count, remaining_count
            )

        if not fix_result.success and remaining_count > 0:
            if not self._should_skip_console_print():
                self.console.print(
                    "[yellow]⚠ Agents cannot fix remaining issues[/yellow]"
                )
            self.logger.warning("AI agents cannot fix remaining issues")

            for i, issue in enumerate(fix_result.remaining_issues[:3]):
                self.logger.info(f"  Remaining issue {i + 1}: {issue[:100]}...")
            if len(fix_result.remaining_issues) > 3:
                self.logger.info(
                    f"  ... and {len(fix_result.remaining_issues) - 3} more issues"
                )

            return False

        if remaining_count == 0:
            self.logger.info(
                f"All {fixes_count} issues fixed with confidence {fix_result.confidence:.2f}"
            )
            return True

        issue_word = "issue" if remaining_count == 1 else "issues"
        self.logger.warning(
            f"No fixes applied but {remaining_count} {issue_word} remain - agents unable to fix"
        )

        return False

    def _handle_partial_progress(
        self, fix_result: FixResult, fixes_count: int, remaining_count: int
    ) -> bool:
        self.logger.info(
            f"Fixed {fixes_count} issues with confidence {fix_result.confidence:.2f}"
        )

        if remaining_count == 0:
            self.logger.info("All issues fixed")
            return True

        issue_word = "issue" if remaining_count == 1 else "issues"

        if not self._should_skip_console_print():
            self.console.print(
                f"[yellow]⚠ Partial progress: {fixes_count} fixes applied, "
                f"{remaining_count} {issue_word} remain[/yellow]"
            )
        self.logger.info(
            f"Partial progress: {fixes_count} fixes applied, "
            f"{remaining_count} {issue_word} remain"
        )

        return False

    def _report_max_iterations_reached(
        self, max_iterations: int, stage: str = "fast"
    ) -> bool:
        final_issue_count = len(self._collect_current_issues(stage=stage))
        issue_word = "issue" if final_issue_count == 1 else "issues"

        if not self._should_skip_console_print():
            self.console.print(
                f"[yellow]⚠ Reached {max_iterations} iterations with "
                f"{final_issue_count} {issue_word} remaining[/yellow]"
            )
            self.console.print()
        self.logger.warning(
            f"Reached {max_iterations} iterations with {final_issue_count} {issue_word} remaining"
        )
        return False

    def _parse_hook_results_to_issues(
        self, hook_results: Sequence[object]
    ) -> list[Issue]:
        self.logger.debug(f"Parsing {len(hook_results)} hook results for issues")

        issues, parsed_counts_by_hook = self._parse_all_hook_results(hook_results)
        self._update_hook_issue_counts(hook_results, parsed_counts_by_hook)
        unique_issues = self._deduplicate_issues(issues)

        self._log_parsing_summary(len(issues), len(unique_issues))
        return unique_issues

    def _parse_all_hook_results(
        self, hook_results: Sequence[object]
    ) -> tuple[list[Issue], dict[str, int]]:
        issues: list[Issue] = []
        parsed_counts_by_hook: dict[str, int] = {}

        for result in hook_results:
            hook_issues = self._parse_single_hook_result(result)
            self._track_hook_issue_count(result, hook_issues, parsed_counts_by_hook)
            issues.extend(hook_issues)

        return issues, parsed_counts_by_hook

    def _run_qa_adapters_for_hooks(
        self, hook_results: Sequence[object]
    ) -> dict[str, QAResult]:
        qa_results: dict[str, QAResult] = {}
        adapter_factory = DefaultAdapterFactory()

        for result in hook_results:
            if not self._should_run_qa_adapter(result):
                continue

            hook_name = getattr(result, "name", "")
            if not hook_name:
                continue

            qa_result = self._run_single_qa_adapter(hook_name, adapter_factory)
            if qa_result is not None:
                qa_results[hook_name] = qa_result

        return qa_results

    def _should_run_qa_adapter(self, result: object) -> bool:
        if not self._validate_hook_result(result):
            return False

        status = getattr(result, "status", "")

        return status.lower() in ("failed", "timeout")

    def _run_single_qa_adapter(
        self, hook_name: str, adapter_factory: DefaultAdapterFactory
    ) -> QAResult | None:
        try:
            adapter = self._get_qa_adapter(hook_name, adapter_factory)
            if adapter is None:
                return None

            if self._is_in_async_context():
                self.logger.debug(
                    f"QA adapter for '{hook_name}' called from async context, "
                    "falling back to raw output parsing"
                )
                return None

            asyncio.run(adapter.init())  # type: ignore
            config = self._create_qa_config(adapter, hook_name)
            check_start = time.monotonic()
            qa_result: QAResult = asyncio.run(adapter.check(config=config))  # type: ignore
            execution_time_ms = int((time.monotonic() - check_start) * 1000)

            if self._adapter_learner_integration is not None:
                try:
                    self._adapter_learner_integration.track_adapter_execution(
                        adapter_name=hook_name,
                        file_path=str(self.pkg_path),
                        file_size=0,
                        project_context={},
                        success=qa_result.is_success if qa_result else True,
                        execution_time_ms=execution_time_ms,
                        error_type=qa_result.details
                        if qa_result and not qa_result.is_success
                        else None,
                    )
                except Exception:
                    pass

            self._log_qa_adapter_result(hook_name, qa_result)
            return qa_result

        except Exception as e:
            self.logger.warning(
                f"Failed to run QA adapter for '{hook_name}': {e}. "
                f"Will fall back to raw output parsing."
            )
            return None

    def _get_qa_adapter(
        self, hook_name: str, adapter_factory: DefaultAdapterFactory
    ) -> object | None:
        adapter_name = adapter_factory.get_adapter_name(hook_name)
        if not adapter_name:
            self.logger.debug(f"No adapter name mapping for '{hook_name}'")
            return None

        adapter = adapter_factory.create_adapter(adapter_name)
        if adapter is None:
            self.logger.debug(f"No QA adapter available for '{hook_name}'")
            return None

        return adapter

    def _is_in_async_context(self) -> bool:
        try:
            asyncio.get_running_loop()
            return True
        except RuntimeError:
            return False

    def _create_qa_config(self, adapter: object, hook_name: str) -> QACheckConfig:
        return QACheckConfig(
            check_id=adapter.module_id,  # type: ignore
            check_name=hook_name,
            check_type=adapter._get_check_type(),  # type: ignore
            enabled=True,
            file_patterns=["**/*.py"],
            timeout_seconds=60,
        )

    def _log_qa_adapter_result(self, hook_name: str, qa_result: QAResult) -> None:
        if qa_result.parsed_issues:
            self.logger.info(
                f"✅ QA adapter for '{hook_name}' found "
                f"{len(qa_result.parsed_issues)} issues"
            )
        else:
            self.logger.debug(f"QA adapter for '{hook_name}' found no issues")

    def _parse_hook_results_to_issues_with_qa(
        self, hook_results: Sequence[object]
    ) -> list[Issue]:
        self.logger.info(f"🔄 Processing {len(hook_results)} hook results...")

        qa_results = self._extract_cached_qa_results(hook_results)

        if len(qa_results) < len(hook_results):
            missing_hooks = [
                r.name  # type: ignore
                for r in hook_results
                if getattr(r, "name", "") not in qa_results  # type: ignore[untyped]
            ]
            if missing_hooks:
                self.logger.debug(
                    f"Running QA adapters for {len(missing_hooks)} hooks without cache: {missing_hooks}"
                )
                additional_results = self._run_qa_adapters_for_hooks(hook_results)
                qa_results.update(additional_results)

        self.logger.info(
            f"📦 Got QAResult for {len(qa_results)} hooks: {list(qa_results.keys())}"
        )

        issues, parsed_counts_by_hook = self._parse_all_hook_results_with_qa(
            hook_results, qa_results
        )

        self._update_hook_issue_counts(hook_results, parsed_counts_by_hook)
        unique_issues = self._deduplicate_issues(issues)

        self._log_parsing_summary(len(issues), len(unique_issues))
        return unique_issues

    def _extract_cached_qa_results(
        self, hook_results: Sequence[object]
    ) -> dict[str, t.Any]:
        cached_results: dict[str, t.Any] = {}
        cache_hits = 0

        for result in hook_results:
            hook_name = getattr(result, "name", "")
            if not hook_name:
                continue

            qa_result = getattr(result, "qa_result", None)

            if qa_result and qa_result.parsed_issues:
                cached_results[hook_name] = qa_result
                cache_hits += 1
                self.logger.info(
                    f"✅ Cache hit for '{hook_name}': {len(qa_result.parsed_issues)} issues "
                    f"(saved re-running QA adapter)"
                )

        if cache_hits > 0:
            self.logger.info(
                f"🎯 QAResult cache: {cache_hits}/{len(hook_results)} hooks "
                f"({cache_hits / len(hook_results) * 100:.0f}% hit rate)"
            )

        return cached_results

    def _parse_all_hook_results_with_qa(
        self, hook_results: Sequence[object], qa_results: dict[str, QAResult]
    ) -> tuple[list[Issue], dict[str, int]]:
        issues: list[Issue] = []
        parsed_counts_by_hook: dict[str, int] = {}

        for result in hook_results:
            hook_name = getattr(result, "name", "")
            if not hook_name:
                continue

            status = getattr(result, "status", "")
            if status and status.lower() not in ("failed", "timeout"):
                self.logger.debug(
                    f"Skipping hook '{hook_name}' with status '{status}' (not failed/timeout)"
                )
                continue

            qa_result = qa_results.get(hook_name)
            raw_output = self._extract_raw_output(result)

            if qa_result and qa_result.parsed_issues:
                hook_issues = self._convert_parsed_issues_to_issues(
                    hook_name, qa_result.parsed_issues
                )
                self.logger.info(
                    f"✅ Used QAResult for '{hook_name}': {len(hook_issues)} issues"
                )
            else:
                hook_issues = self._parse_hook_to_issues(
                    hook_name, raw_output, qa_result
                )
                self.logger.info(
                    f"🔄 Fallback to raw output parsing for '{hook_name}': "
                    f"{len(hook_issues)} issues"
                )

            self._track_hook_issue_count(result, hook_issues, parsed_counts_by_hook)
            issues.extend(hook_issues)

        return issues, parsed_counts_by_hook

    def _track_hook_issue_count(
        self,
        result: object,
        hook_issues: list[Issue],
        parsed_counts_by_hook: dict[str, int],
    ) -> None:
        if hasattr(result, "name"):
            hook_name = result.name
            if hook_name not in parsed_counts_by_hook:
                parsed_counts_by_hook[hook_name] = 0
            parsed_counts_by_hook[hook_name] += len(hook_issues)

    def _update_hook_issue_counts(
        self, hook_results: Sequence[object], parsed_counts_by_hook: dict[str, int]
    ) -> None:
        for result in hook_results:
            if not (hasattr(result, "name") and hasattr(result, "issues_count")):
                continue

            hook_name = getattr(result, "name")
            if hook_name not in parsed_counts_by_hook:
                continue

            old_count = getattr(result, "issues_count", 0)
            new_count = parsed_counts_by_hook[hook_name]

            if self._should_update_issue_count(result, new_count):
                self._update_single_hook_count(result, hook_name, old_count, new_count)

    def _should_update_issue_count(self, result: object, new_count: int) -> bool:
        if new_count > 0:
            return True

        return hasattr(result, "status") and getattr(result, "status", "") == "failed"

    def _update_single_hook_count(
        self, result: object, hook_name: str, old_count: int, new_count: int
    ) -> None:
        if old_count == new_count:
            return

        self.logger.debug(
            f"Updated issues_count for '{hook_name}': "
            f"{old_count} → {new_count} (matched to parsed issues)"
        )
        setattr(result, "issues_count", new_count)

    def _deduplicate_issues(self, issues: list[Issue]) -> list[Issue]:
        seen: set[tuple[str | None, int | None, str, str]] = set()
        unique_issues: list[Issue] = []

        for issue in issues:
            key = (
                issue.file_path,
                issue.line_number,
                issue.stage,
                issue.message,
            )
            if key not in seen:
                seen.add(key)
                unique_issues.append(issue)

        return unique_issues

    def _log_parsing_summary(self, raw_count: int, unique_count: int) -> None:
        if raw_count != unique_count:
            self.logger.info(
                f"Deduplicated issues: {raw_count} raw -> {unique_count} unique"
            )
        else:
            self.logger.info(f"Total issues extracted from all hooks: {unique_count}")

    def _parse_single_hook_result(self, result: object) -> list[Issue]:
        if not self._validate_hook_result(result):
            return []

        status = getattr(result, "status", "")

        if status.lower() not in ("failed", "timeout"):
            self.logger.debug(
                f"Skipping hook with status '{status}' (not failed/timeout)"
            )
            return []

        hook_name = getattr(result, "name", "")
        if not hook_name:
            self.logger.warning("Hook result has no name attribute")
            return []

        self.logger.debug(f"Parsing hook result: name='{hook_name}', status='{status}'")

        raw_output = self._extract_raw_output(result)
        self._log_hook_parsing_start(hook_name, result, raw_output)

        hook_issues = self._parse_hook_to_issues(hook_name, raw_output)
        self._log_hook_parsing_result(hook_name, hook_issues, raw_output)

        return hook_issues

    def _log_hook_parsing_start(
        self, hook_name: str, result: object, raw_output: str
    ) -> None:
        output = getattr(result, "output", None) or ""
        error = getattr(result, "error", None) or ""
        error_message = getattr(result, "error_message", None) or ""
        self.logger.debug(
            f"Parsing hook '{hook_name}': "
            f"output_len={len(str(output))}, error_len={len(str(error))}, "
            f"error_msg_len={len(str(error_message))}, total_raw_len={len(raw_output)}"
        )

    def _log_hook_parsing_result(
        self, hook_name: str, hook_issues: list[Issue], raw_output: str
    ) -> None:
        self.logger.debug(
            f"Hook '{hook_name}' produced {len(hook_issues)} issues. "
            f"Sample (first 200 chars of raw_output): {raw_output[:200]!r}"
        )

    def _get_max_iterations(self) -> int:
        if self._max_iterations is not None:
            return self._max_iterations

        return int(os.environ.get("CRACKERJACK_AI_FIX_MAX_ITERATIONS", "5"))

    def _get_convergence_threshold(self) -> int:
        return int(os.environ.get("CRACKERJACK_AI_FIX_CONVERGENCE_THRESHOLD", "5"))

    def _collect_current_issues(self, stage: str = "fast") -> list[Issue]:
        pkg_dir = self._detect_package_directory()
        check_commands = self._build_check_commands(pkg_dir, stage=stage)
        self.logger.debug(
            f"Built {len(check_commands)} check commands for stage '{stage}'"
        )
        for cmd, hook_name, timeout in check_commands:
            self.logger.debug(
                f"  Check command: {cmd[:3]}... (hook={hook_name}, timeout={timeout}s)"
            )

        all_issues, successful_checks = self._execute_check_commands(check_commands)

        if successful_checks == 0 and self.pkg_path.exists():
            self.logger.warning(
                "No issues collected from any checks - commands may have failed. "
                "This could indicate a problem with the issue collection process."
            )

        self.logger.debug(
            f"Collected {len(all_issues)} current issues (from {successful_checks} successful checks)"
        )
        return all_issues

    def _detect_package_directory(self) -> Path:
        pkg_name = self.pkg_path.name

        pkg_dirs = [
            self.pkg_path / pkg_name,
            self.pkg_path / "src" / pkg_name,
            self.pkg_path / "src",
            self.pkg_path,
        ]

        for d in pkg_dirs:
            if d.exists() and d.is_dir():
                return d

        self.logger.warning(f"Cannot find package directory, using {self.pkg_path}")
        return self.pkg_path

    def _build_check_commands(
        self, pkg_dir: Path, stage: str = "fast"
    ) -> list[tuple[list[str], str, int]]:
        pkg_name = self.pkg_path.name

        all_commands = [
            (["uv", "run", "ruff", "check", "."], "ruff", 60),
            (["uv", "run", "ruff", "format", "--check", "."], "ruff-format", 60),
            (
                [
                    "uv",
                    "run",
                    "zuban",
                    "mypy",
                    "--config-file",
                    "mypy.ini",
                    "--no-error-summary",
                    str(pkg_dir),
                ],
                "zuban",
                120,
            ),
            (
                [
                    "uv",
                    "run",
                    "refurb",
                    str(pkg_dir),
                ],
                "refurb",
                120,
            ),
            (
                [
                    "uv",
                    "run",
                    "complexipy",
                    "--max-complexity-allowed",
                    "15",
                    pkg_name,
                ],
                "complexity",
                60,
            ),
        ]

        if stage == "fast":
            return [cmd for cmd in all_commands if cmd[1] in ("ruff", "ruff-format")]

        return [
            cmd for cmd in all_commands if cmd[1] in ("zuban", "refurb", "complexity")
        ]

    def _execute_check_commands(
        self, check_commands: list[tuple[list[str], str, int]]
    ) -> tuple[list[Issue], int]:
        all_issues: list[Issue] = []
        successful_checks = 0

        for cmd, hook_name, timeout in check_commands:
            result = self._run_check_command(cmd, timeout, hook_name)
            if result:
                process, stdout, stderr = result
                issues = self._process_check_result(process, stdout, stderr, hook_name)
                all_issues.extend(issues)
                successful_checks += 1

        return all_issues, successful_checks

    def _run_check_command(
        self, cmd: list[str], timeout: int, hook_name: str
    ) -> tuple[subprocess.Popen[str], str, str] | None:
        process: subprocess.Popen[str] | None = None
        try:
            process = subprocess.Popen(
                cmd,
                cwd=self.pkg_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            stdout, stderr = process.communicate(timeout=timeout)
            return (process, stdout, stderr)
        except subprocess.TimeoutExpired:
            self._kill_process_gracefully(process)
            self.logger.warning(f"Timeout running {hook_name} check")
            return None
        except Exception as e:
            self._kill_process_gracefully(process)
            self._collect_error("Hook Error", f"{hook_name}: {e}")
            return None

    def _kill_process_gracefully(self, process: subprocess.Popen[str] | None) -> None:
        if process:
            process.kill()
            try:
                process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()

    def _process_check_result(
        self, process: subprocess.Popen[str], stdout: str, stderr: str, hook_name: str
    ) -> list[Issue]:
        combined_output = stdout + stderr

        self.logger.debug(
            f"{hook_name}: returncode={process.returncode}, "
            f"stdout_len={len(stdout)}, stderr_len={len(stderr)}, "
            f"combined_len={len(combined_output)}"
        )

        if process.returncode != 0 or combined_output:
            hook_issues = self._parse_hook_to_issues(hook_name, combined_output)
            if hook_issues:
                self.logger.debug(
                    f"{hook_name}: Parsed {len(hook_issues)} issues from output"
                )
            else:
                self.logger.debug(
                    f"{hook_name}: Output present but no issues parsed (filtered out?)"
                )
            return hook_issues

        return []

    def _convert_parsed_issues_to_issues(
        self, tool_name: str, parsed_issues: list[dict[str, t.Any]]
    ) -> list[Issue]:
        issues = []

        for tool_issue_dict in parsed_issues:
            try:
                file_path = tool_issue_dict.get("file_path")
                if not file_path:
                    self.logger.debug(
                        f"Skipping issue from '{tool_name}': missing file_path. "
                        f"Issue data: {tool_issue_dict}"
                    )
                    continue

                severity_raw = tool_issue_dict.get("severity", "error")
                severity_str = severity_raw.lower() if severity_raw else "error"
                severity = self._map_severity_to_priority(severity_str)

                issue_type = self._determine_issue_type(tool_name, tool_issue_dict)

                details = self._build_issue_details(tool_issue_dict)

                issue = Issue(
                    type=issue_type,
                    severity=severity,
                    message=tool_issue_dict.get("message", ""),
                    file_path=file_path,
                    line_number=tool_issue_dict.get("line_number"),
                    details=details,
                    stage=tool_name,
                )

                issues.append(issue)

            except (KeyError, TypeError, ValueError) as e:
                self.logger.warning(
                    f"Failed to convert parsed issue from '{tool_name}': {e}. "
                    f"Issue data: {tool_issue_dict}",
                    exc_info=True,
                )
                continue
            except Exception as e:
                self._collect_error(
                    "Parse Error",
                    f"{tool_name}: {e}",
                )
                continue

        self.logger.info(
            f"✅ Converted {len(issues)} issues from '{tool_name}' "
            f"(from QAResult.parsed_issues)"
        )

        return issues

    def _map_severity_to_priority(self, severity_str: str) -> Priority:
        severity_map = {
            "error": Priority.HIGH,
            "warning": Priority.MEDIUM,
            "info": Priority.LOW,
            "note": Priority.LOW,
        }

        return severity_map.get(severity_str, Priority.MEDIUM)

    def _determine_issue_type(
        self, tool_name: str, tool_issue_dict: dict[str, t.Any]
    ) -> IssueType:

        code = (
            tool_issue_dict.get("code", "").upper()
            if tool_issue_dict.get("code")
            else ""
        )
        message = (
            tool_issue_dict.get("message", "").lower()
            if tool_issue_dict.get("message")
            else ""
        )

        if tool_name == "ruff":
            if code.startswith("C90") or code == "C901":
                return IssueType.COMPLEXITY
            if code in {"F401", "F822", "F841"}:
                return IssueType.DEAD_CODE
            if code in {"F821", "I001"}:
                return IssueType.IMPORT_ERROR
            if code == "E741":
                return IssueType.FORMATTING

        if tool_name in (
            "check-local-links",
            "check-links",
            "lychee",
            "linkcheckmd",
            "markdown-link-check",
        ):
            return IssueType.DOCUMENTATION

        tool_type_map = {
            "ruff": IssueType.FORMATTING,
            "ruff-format": IssueType.FORMATTING,
            "mdformat": IssueType.FORMATTING,
            "codespell": IssueType.FORMATTING,
            "mypy": IssueType.TYPE_ERROR,
            "zuban": IssueType.TYPE_ERROR,
            "pyright": IssueType.TYPE_ERROR,
            "pylint": IssueType.TYPE_ERROR,
            "bandit": IssueType.SECURITY,
            "gitleaks": IssueType.SECURITY,
            "semgrep": IssueType.SECURITY,
            "safety": IssueType.SECURITY,
            "pytest": IssueType.TEST_FAILURE,
            "complexipy": IssueType.COMPLEXITY,
            "refurb": IssueType.REFURB,
            "skylos": IssueType.DEAD_CODE,
            "creosote": IssueType.DEPENDENCY,
            "pyscn": IssueType.DEPENDENCY,
        }

        if tool_name in tool_type_map:
            return tool_type_map[tool_name]

        if any(
            word in message
            for word in (
                "broken link",
                "file not found",
                "local link",
                "documentation",
                "markdown link",
            )
        ):
            return IssueType.DOCUMENTATION
        if any(word in message for word in ("test", "pytest", "unittest")):
            return IssueType.TEST_FAILURE
        if any(word in message for word in ("complex", "cyclomatic")):
            return IssueType.COMPLEXITY
        if any(word in message for word in ("dead", "unused", "redundant")):
            return IssueType.DEAD_CODE
        if any(word in message for word in ("security", "vulnerability")):
            return IssueType.SECURITY
        if any(word in message for word in ("import", "module")):
            return IssueType.IMPORT_ERROR
        if "type" in message or "type:" in code:
            return IssueType.TYPE_ERROR

        return IssueType.FORMATTING

    def _build_issue_details(self, tool_issue_dict: dict[str, t.Any]) -> list[str]:
        details = []

        if code := tool_issue_dict.get("code"):
            details.append(f"code: {code}")

        if suggestion := tool_issue_dict.get("suggestion"):
            details.append(f"suggestion: {suggestion}")

        if column := tool_issue_dict.get("column_number"):
            details.append(f"column: {column}")

        details.append(f"severity: {tool_issue_dict.get('severity', 'unknown')}")

        return details

    def _parse_hook_to_issues(
        self,
        hook_name: str,
        raw_output: str,
        qa_result: QAResult | None = None,
    ) -> list[Issue]:
        self.logger.debug(
            f"Parsing hook '{hook_name}': "
            f"raw_output_lines={len(raw_output.split(chr(10)))}"
        )

        output_preview = raw_output[:500] if raw_output else "(empty)"
        self.logger.debug(f"Raw output preview from '{hook_name}':\n{output_preview!r}")

        if qa_result and qa_result.parsed_issues:
            self.logger.info(
                f"📦 Using QAResult.parsed_issues for '{hook_name}' "
                f"({len(qa_result.parsed_issues)} issues)"
            )
            return self._convert_parsed_issues_to_issues(
                hook_name, qa_result.parsed_issues
            )

        self.logger.info(
            f"🔄 QAResult not available for '{hook_name}', parsing raw output"
        )
        expected_count = self._extract_issue_count(raw_output, hook_name)
        self.logger.info(f"Parsing '{hook_name}': expected_count={expected_count}")

        try:
            issues = self._parser_factory.parse_with_validation(
                tool_name=hook_name,
                output=raw_output,
                expected_count=expected_count,
            )

            self.logger.info(
                f"Successfully parsed {len(issues)} issues from '{hook_name}'"
            )

            if issues:
                self._log_parsed_issues(hook_name, issues)
                self._validate_parsed_issues(issues)
            else:
                self.logger.info(f"✅ No issues found from '{hook_name}' (clean run)")

            return issues

        except (ParsingError, ValueError) as e:
            self._collect_error("Parsing Error", f"{hook_name}: {e}")
            try:
                issues = self._parser_factory.parse_with_validation(
                    tool_name=hook_name,
                    output=raw_output,
                    expected_count=None,
                )
                if issues:
                    self.logger.info(
                        f"Recovered {len(issues)} issues from '{hook_name}' "
                        "after validation failure"
                    )
                    return issues
            except Exception as recovery_error:
                self.logger.debug(
                    f"Best-effort parsing failed for '{hook_name}': {recovery_error}"
                )
            return []

    def _extract_issue_count(self, output: str, tool_name: str) -> int | None:

        if tool_name in (
            "complexipy",
            "refurb",
            "creosote",
            "pyscn",
            "semgrep",
            "pytest",
            "check-yaml",
            "check-toml",
            "check-json",
            "pip-audit",
            "check-ast",
            "check-local-links",
            "check-added-large-files",
            "format-json",
            "gitleaks",
            "lychee",
        ):
            return None

        json_count = _extract_issue_count_from_json(output, tool_name)
        if json_count is not None:
            return json_count

        return _extract_issue_count_from_text_lines(output)

    def _log_parsed_issues(self, hook_name: str, issues: list[Issue]) -> None:
        self.logger.info(f"📋 Issue structure from '{hook_name}':")
        for i, issue in enumerate(issues[:5]):
            self.logger.info(
                f"  [{i}] type={issue.type.value}, "
                f"severity={issue.severity.value}, "
                f"file={issue.file_path}:{issue.line_number}, "
                f"msg={issue.message!r}"
            )

        if len(issues) > 5:
            self.logger.info(f"  ... and {len(issues) - 5} more issues")

    def _validate_parsed_issues(self, issues: list[Issue]) -> None:
        for i, issue in enumerate(issues):
            if not issue.file_path:
                self.logger.warning(
                    f"Issue {i} ({issue.id}) missing file_path: {issue.message}"
                )

            if not issue.message:
                self.logger.warning(
                    f"Issue {i} ({issue.id}) missing message, file={issue.file_path}"
                )

            if issue.severity not in Priority:
                self.logger.warning(
                    f"Issue {i} has invalid severity: {issue.severity.value}"
                )

            if issue.type not in IssueType:
                self.logger.warning(f"Issue {i} has invalid type: {issue.type.value}")

    def _setup_ai_fix_coordinator(self) -> AgentCoordinatorProtocol:

        settings = CrackerjackSettings()

        skills_tracker = None
        if settings.skills.enabled:
            try:
                skills_tracker = create_skills_tracker(
                    session_id=f"autofix-{os.getpid()}",
                    enabled=settings.skills.enabled,
                    backend=settings.skills.backend,
                    db_path=Path(settings.skills.db_path)
                    if settings.skills.db_path
                    else None,
                    mcp_server_url=settings.skills.mcp_server_url,
                )
                self.logger.debug(
                    f"Skills tracking enabled: backend={skills_tracker.get_backend()}, "
                    f"enabled={skills_tracker.is_enabled()}"
                )
            except Exception as e:
                self.logger.warning(f"Failed to initialize skills tracking: {e}")

        fix_strategy_memory = None
        if settings.fix_strategy_memory.enabled:
            try:
                from crackerjack.memory.fix_strategy_storage import FixStrategyStorage

                fix_strategy_memory = FixStrategyStorage(
                    db_path=Path(settings.fix_strategy_memory.db_path)
                )
                self.logger.info(
                    f"✅ Fix strategy memory enabled: {settings.fix_strategy_memory.db_path}"
                )
            except Exception as e:
                self.logger.warning(f"Failed to initialize fix strategy memory: {e}")

        context = AgentContext(
            project_path=self.pkg_path,
            subprocess_timeout=300,
            skills_tracker=skills_tracker,
            fix_strategy_memory=fix_strategy_memory,
        )
        cache = CrackerjackCache()

        if self._coordinator_factory is not None:
            coordinator = self._coordinator_factory(context, cache)
        else:
            from crackerjack.agents.coordinator import AgentCoordinator
            from crackerjack.agents.tracker import get_agent_tracker
            from crackerjack.services.debug import get_ai_agent_debugger

            coordinator = AgentCoordinator(
                context=context,
                tracker=get_agent_tracker(),
                debugger=get_ai_agent_debugger(),
                cache=cache,
            )

        return coordinator

    def _collect_fixable_issues(self, hook_results: Sequence[object]) -> list[Issue]:
        initial_issues = self._parse_hook_results_to_issues_with_qa(hook_results)

        coverage_issues = self._check_coverage_regression(hook_results)
        if coverage_issues:
            self.logger.info(
                f"🧪 Test AI Stage: Detected {len(coverage_issues)} coverage failures, "
                f"adding to AI-fix queue for test creation"
            )
            initial_issues.extend(coverage_issues)

        return initial_issues

    def _get_iteration_issues_with_log(
        self,
        iteration: int,
        hook_results: Sequence[object],
        stage: str,
        initial_issues: list[Issue],
    ) -> list[Issue]:
        if iteration == 0:
            issues = initial_issues
            self.logger.info(
                f"Iteration {iteration}: Using initial hook results ({len(issues)} issues)"
            )
        else:
            issues = self._collect_current_issues(stage=stage)
            self.logger.info(
                f"Iteration {iteration}: Re-ran hooks, collected {len(issues)} current issues"
            )

        return issues

    def _check_iteration_completion(
        self,
        iteration: int,
        current_issue_count: int,
        previous_issue_count: float,
        no_progress_count: int,
        max_iterations: int,
        stage: str,
        fixes_applied: int = 0,
    ) -> bool | None:
        if current_issue_count == 0:
            return self._handle_zero_issues_case(iteration, stage)

        if iteration >= max_iterations:
            self.logger.warning(
                f"Reached max iterations ({max_iterations}) with {current_issue_count} issues remaining"
            )
            return False

        if self._should_stop_on_convergence(
            current_issue_count,
            previous_issue_count,
            no_progress_count,
            fixes_applied,
        ):
            return False

        return None

    def _update_iteration_progress_with_tracking(
        self,
        iteration: int,
        current_issue_count: int,
        previous_issue_count: float,
        no_progress_count: int,
        fixes_applied: int = 0,
    ) -> int:
        no_progress_count = self._update_progress_count(
            current_issue_count,
            previous_issue_count,
            no_progress_count,
            fixes_applied,
        )

        self.progress_manager.update_iteration_progress(
            iteration,
            current_issue_count,
            no_progress_count,
        )

        return no_progress_count

    def _run_ai_fix_iteration_loop(
        self,
        coordinator: AgentCoordinatorProtocol,
        initial_issues: list[Issue],
        hook_results: Sequence[object],
        stage: str,
    ) -> bool:
        max_iterations = self._get_max_iterations()
        previous_issue_count = float("inf")
        no_progress_count = 0
        iteration = 0

        try:
            while True:
                issues = self._get_iteration_issues_with_log(
                    iteration, hook_results, stage, initial_issues
                )
                current_issue_count = len(issues)

                self.progress_manager.start_iteration(iteration, current_issue_count)

                completion_result = self._check_iteration_completion(
                    iteration,
                    current_issue_count,
                    previous_issue_count,
                    no_progress_count,
                    max_iterations,
                    stage,
                    fixes_applied=0,
                )

                if completion_result is not None:
                    self.progress_manager.end_iteration()
                    self.progress_manager.finish_session(success=completion_result)
                    return completion_result

                success, fixes_applied = self._run_ai_fix_iteration(
                    coordinator, issues, iteration
                )

                no_progress_count = self._update_iteration_progress_with_tracking(
                    iteration,
                    current_issue_count,
                    previous_issue_count,
                    no_progress_count,
                    fixes_applied,
                )

                if not success:
                    self.progress_manager.end_iteration()
                    self.progress_manager.finish_session(success=False)
                    return False

                self.progress_manager.end_iteration()

                previous_issue_count = current_issue_count
                iteration += 1

        except Exception as e:
            self.logger.exception(f"Error during AI fixing at iteration {iteration}")
            self.progress_manager.end_iteration()
            self.progress_manager.finish_session(
                success=False, message=f"Error during AI fixing: {e}"
            )
            raise

    def _validate_final_issues(self, issues: list[Issue]) -> None:
        for i, issue in enumerate(issues):
            errors = self._collect_validation_errors(issue)

            if errors:
                self._log_validation_error(i, issue, errors)
                raise ValueError(f"Invalid issue object: {errors}")

    def _collect_validation_errors(self, issue: Issue) -> list[str]:
        errors = []

        type_errors = self._validate_issue_type(issue)
        errors.extend(type_errors)

        severity_errors = self._validate_issue_severity(issue)
        errors.extend(severity_errors)

        message_errors = self._validate_issue_message(issue)
        errors.extend(message_errors)

        file_path_errors = self._validate_issue_file_path(issue)
        errors.extend(file_path_errors)

        return errors

    def _validate_issue_type(self, issue: Issue) -> list[str]:
        if not hasattr(issue, "type") or issue.type is None:
            return ["missing type"]
        if not isinstance(issue.type, IssueType):
            return [f"invalid type: {type(issue.type)}"]
        return []

    def _validate_issue_severity(self, issue: Issue) -> list[str]:
        if not hasattr(issue, "severity") or issue.severity is None:
            return ["missing severity"]
        if not isinstance(issue.severity, Priority):
            return [f"invalid severity: {type(issue.severity)}"]
        return []

    def _validate_issue_message(self, issue: Issue) -> list[str]:
        if not hasattr(issue, "message") or not issue.message:
            return ["missing or empty message"]
        return []

    def _validate_issue_file_path(self, issue: Issue) -> list[str]:

        if issue.file_path or self._is_aggregate_issue(issue):
            return []
        return []

    def _is_aggregate_issue(self, issue: Issue) -> bool:
        msg_lower = issue.message.lower()
        aggregate_keywords = [
            "files",
            "file(",
            "would be reformatted",
            "require formatting",
            "formatting error",
        ]

        return "file" in msg_lower and any(
            keyword in msg_lower for keyword in aggregate_keywords
        )

    def _log_validation_error(
        self, index: int, issue: Issue, errors: list[str]
    ) -> None:
        self._collect_error(
            "Validation Error",
            f"Issue {index} ({issue.id}): {', '.join(errors)}",
            getattr(issue, "file_path", "") or "",
        )

    async def _apply_ai_agent_fixes(
        self, hook_results: Sequence[object], stage: str = "fast"
    ) -> bool:

        use_v1_pipeline = os.environ.get("AI_FIX_V1", "0") == "1"

        if use_v1_pipeline:
            self.logger.info("⚠️ Using V1 Legacy Pipeline (AI_FIX_V1=1)")
            return self._apply_ai_agent_fixes_v1(hook_results, stage)

        self.logger.info("🚀 Using V2 Two-Stage Pipeline with validation")
        return await self._apply_ai_agent_fixes_v2(hook_results, stage)

    def _apply_ai_agent_fixes_v1(
        self, hook_results: Sequence[object], stage: str = "fast"
    ) -> bool:
        coordinator = self._setup_ai_fix_coordinator()
        issues = self._collect_fixable_issues(hook_results)

        fixable_issues = [i for i in issues if i.file_path]
        skipped_issues = [i for i in issues if not i.file_path]
        if skipped_issues:
            self.logger.warning(
                f"⚠️ V1: Skipping {len(skipped_issues)} issues without file_path"
            )

        _infra_files = {"autofix_coordinator.py"}
        infra_issues = [
            i
            for i in fixable_issues
            if i.file_path and any(f in i.file_path for f in _infra_files)
        ]
        if infra_issues:
            fixable_issues = [i for i in fixable_issues if i not in infra_issues]
            self.logger.info(
                f"🛡️ Excluding {len(infra_issues)} infrastructure issues from V1 AI-fix"
            )

        issues = fixable_issues

        self.progress_manager.start_fix_session(
            stage=stage,
            initial_issue_count=len(issues),
        )

        if not issues:
            return True

        result = self._run_ai_fix_iteration_loop(
            coordinator, issues, hook_results, stage
        )

        if result:
            self._validate_final_issues(issues)

        return result

    async def _execute_plan_with_validation(
        self,
        plan: FixPlan,
        fixer_coordinator: FixerCoordinator,
        validation_coordinator: ValidationCoordinator,
        bar: Any,  # type: ignore
    ) -> tuple[bool, list[FixResult], str]:

        if bar:
            self.progress_manager.update_bar_text(plan.file_path)

        self.logger.info(
            f"Plan {plan.file_path}: {len(plan.changes)} changes, risk={plan.risk_level}"
        )
        self.progress_manager.log_event(
            agent="FixerCoordinator",
            action="Executing plan",
            file=plan.file_path,
            severity="info",
        )

        backup_path = self._create_backup(plan.file_path)
        original_content = Path(plan.file_path).read_text()

        try:
            plan_results = await fixer_coordinator.execute_plans([plan])
            if not plan_results:
                return False, [], "No fixer available for this issue type"
            if not plan_results[0].success:
                failure_reasons = plan_results[0].remaining_issues or [
                    "Unknown failure"
                ]
                return False, [], f"Fix failed: {'; '.join(failure_reasons)}"

            modified_content = Path(plan.file_path).read_text()
            is_valid, feedback = await validation_coordinator.validate_fix(
                code=modified_content,
                file_path=plan.file_path,
                original_code=original_content,
            )

            if is_valid:
                self.logger.info(f"✅ Plan validated: {plan.file_path}")
                self.progress_manager.log_event(
                    agent="ValidationCoordinator",
                    action="Validated successfully",
                    file=plan.file_path,
                    severity="success",
                )
                if bar:
                    bar()
                return True, plan_results, ""

            self.logger.warning(f"⚠️ Validation failed, rolling back {plan.file_path}")
            self._restore_backup(backup_path)
            return False, [], feedback

        except Exception as e:
            self._restore_backup(backup_path)
            return False, [], str(e)

    async def _apply_ai_agent_fixes_v2(
        self, hook_results: Sequence[object], stage: str = "fast"
    ) -> bool:
        from pathlib import Path

        from ..agents.analysis_coordinator import AnalysisCoordinator
        from ..agents.fixer_coordinator import FixerCoordinator
        from ..agents.validation_coordinator import ValidationCoordinator
        from ..services.debug import get_ai_agent_debugger

        self.logger.info("🎯 Initializing V2 Two-Stage Pipeline")

        issues = self._collect_fixable_issues(hook_results)
        if not issues:
            self.logger.info("✅ No issues to fix")
            return True

        issues = self._filter_fixable_issues(issues)
        if not issues:
            return True

        project_path = str(self.pkg_path)
        analysis_coordinator = AnalysisCoordinator(
            project_path=project_path,
            debugger=get_ai_agent_debugger(),
        )
        fixer_coordinator = FixerCoordinator(project_path=project_path)
        validation_coordinator = ValidationCoordinator(project_path=Path(project_path))

        plans = await self._create_fix_plans(analysis_coordinator, issues)
        if not plans:
            return False

        results = await self._execute_plans_with_validation(
            plans,
            fixer_coordinator,
            validation_coordinator,
            analysis_coordinator,
            issues,
        )

        return self._check_execution_results(results)

    def _filter_fixable_issues(self, issues: list[Issue]) -> list[Issue]:
        fixable_issues = [i for i in issues if i.file_path]
        skipped_issues = [i for i in issues if not i.file_path]

        # Exclude infrastructure files from AI-fix to prevent self-modification
        _infra_files = {"autofix_coordinator.py"}
        infra_issues = [
            i
            for i in fixable_issues
            if i.file_path and any(f in i.file_path for f in _infra_files)
        ]
        if infra_issues:
            fixable_issues = [i for i in fixable_issues if i not in infra_issues]
            self.logger.info(
                f"🛡️ Excluding {len(infra_issues)} infrastructure issues from AI-fix "
                f"(pipeline files must not be self-modified)"
            )

        if skipped_issues:
            self.logger.warning(
                f"⚠️ Skipping {len(skipped_issues)} issues without file_path: "
                f"{', '.join(i.message[:50] + '...' for i in skipped_issues[:3])}"
            )

        if not fixable_issues:
            self.logger.info("✅ No fixable issues (all require manual intervention)")

        return fixable_issues

    async def _create_fix_plans(
        self, analysis_coordinator: AnalysisCoordinator, issues: list[Issue]
    ) -> list[FixPlan] | None:
        import asyncio

        self.logger.info("🔍 Stage 2: Analysis Phase - creating FixPlans")
        try:
            try:
                asyncio.get_running_loop()
                self.logger.debug("Running in existing event loop")
                plans = await analysis_coordinator.analyze_issues(issues)
            except RuntimeError:
                self.logger.debug("Creating new event loop for analysis")
                plans = asyncio.run(analysis_coordinator.analyze_issues(issues))

            self.logger.info(f"✅ Created {len(plans)} FixPlans")
            return plans.copy()
        except Exception as e:
            self._collect_error("Analysis Error", str(e))
            return None

    @staticmethod
    def _issue_key(file_path: str, line_number: int | None, issue_type: str) -> str:
        """Composite key for deduplicating issues across iterations."""
        return f"{file_path}:{line_number or ''}:{issue_type}"

    async def _execute_plans_with_validation(
        self,
        plans: list[FixPlan],
        fixer_coordinator: FixerCoordinator,
        validation_coordinator: ValidationCoordinator,
        analysis_coordinator: AnalysisCoordinator,
        issues: list[Issue],
    ) -> list[FixResult]:
        results: list[FixResult] = []
        plan_to_issue = {
            self._issue_key(i.file_path, i.line_number, i.type.value): i
            for i in issues
            if i.file_path
        }

        # Short-circuit plans with no changes — retrying them is guaranteed waste
        viable_plans = [p for p in plans if p.changes]
        skipped = len(plans) - len(viable_plans)
        if skipped:
            self.logger.info(
                f"⏭️ Skipping {skipped} plans with no viable changes (would fail all 3 retries)"
            )
            for p in plans:
                if not p.changes:
                    results.append(
                        FixResult(
                            success=False,
                            confidence=0.0,
                            remaining_issues=[
                                f"No viable changes for {p.issue_type} at {p.file_path}"
                            ],
                        )
                    )

        # Deduplicate plans targeting the same file + issue_type
        seen: set[tuple[str, str]] = set()
        deduped_plans: list[FixPlan] = []
        for p in viable_plans:
            key = (p.file_path, p.issue_type or "")
            if key not in seen:
                seen.add(key)
                deduped_plans.append(p)
        if len(deduped_plans) < len(viable_plans):
            self.logger.info(
                f"🔀 Deduplicated {len(viable_plans)} → {len(deduped_plans)} plans"
            )
        viable_plans = deduped_plans

        # Skip plans for issues that already failed in a previous outer iteration
        retry_plans: list[FixPlan] = []
        for p in viable_plans:
            pk = self._issue_key(
                p.file_path,
                p.changes[0].line_range[0] if p.changes else None,
                p.issue_type or "",
            )
            if pk in self._failed_issue_keys:
                self.logger.info(
                    f"\033[2m⏭️ Skipping previously failed: {p.file_path} ({p.issue_type})\033[0m"
                )
                results.append(
                    FixResult(
                        success=False,
                        confidence=0.0,
                        remaining_issues=[
                            f"Previously failed: {p.issue_type} at {p.file_path}"
                        ],
                    )
                )
            else:
                retry_plans.append(p)
        viable_plans = retry_plans

        with self.progress_manager.progress_context(
            len(viable_plans), "AI-FIX EXECUTION"
        ) as bar:
            for plan in viable_plans:
                plan_key = self._issue_key(
                    plan.file_path,
                    plan.changes[0].line_range[0] if plan.changes else None,
                    plan.issue_type or "",
                )
                result = await self._execute_single_plan_with_retry(
                    plan,
                    fixer_coordinator,
                    validation_coordinator,
                    analysis_coordinator,
                    plan_to_issue,
                    plan_key,
                    bar,
                )
                if not result.success:
                    self._failed_issue_keys.add(plan_key)
                results.append(result)

        return results

    async def _execute_single_plan_with_retry(
        self,
        plan: FixPlan,
        fixer_coordinator: FixerCoordinator,
        validation_coordinator: ValidationCoordinator,
        analysis_coordinator: AnalysisCoordinator,
        plan_to_issue: dict[str, Issue],
        plan_key: str,
        bar: Any,  # type: ignore
    ) -> FixResult:
        accumulated_feedback: list[str] = []
        per_issue_timeout = 90  # seconds per single attempt
        plan_loc = (
            f"{plan.file_path}:{plan.changes[0].line_range[0]}"
            if plan.changes
            else plan.file_path
        )

        if not self._is_writable_target(plan.file_path):
            feedback = f"Workspace is not writable: {plan.file_path}"
            self.logger.warning(
                f"\033[91m✗ [FixerCoordinator] Non-retryable workspace write failure ({plan_loc})\033[0m"
            )
            self._collect_error("Workspace Write Error", feedback, plan.file_path)
            if bar:
                bar()
            return FixResult(
                success=False,
                confidence=0.0,
                remaining_issues=[feedback],
            )

        for attempt in range(3):
            try:
                success, plan_results, feedback = await asyncio.wait_for(
                    self._execute_plan_with_validation(
                        plan, fixer_coordinator, validation_coordinator, bar
                    ),
                    timeout=per_issue_timeout,
                )
            except TimeoutError:
                feedback = f"Timed out after {per_issue_timeout}s"
                self.logger.warning(
                    f"\033[91m⏱️ [FixerCoordinator] Plan timed out "
                    f"({plan_loc}), "
                    f"attempt {attempt + 1}/3\033[0m"
                )
                accumulated_feedback.append(feedback)
                if attempt < 2:
                    plan = await self._regenerate_plan_with_feedback(
                        plan,
                        plan_key,
                        analysis_coordinator,
                        plan_to_issue,
                        accumulated_feedback,
                    )
                continue

            if success and plan_results:
                return plan_results[0]

            accumulated_feedback.append(f"Attempt {attempt + 1}: {feedback}")

            if self._is_non_retryable_write_failure(feedback, plan_results):
                self.logger.warning(
                    f"\033[91m✗ [FixerCoordinator] Non-retryable write failure ({plan_loc})\033[0m"
                )
                self._collect_error(
                    "Workspace Write Error",
                    feedback,
                    plan.file_path,
                )
                if bar:
                    bar()
                return FixResult(
                    success=False,
                    confidence=0.0,
                    remaining_issues=accumulated_feedback,
                )

            if attempt < 2:
                plan = await self._regenerate_plan_with_feedback(
                    plan,
                    plan_key,
                    analysis_coordinator,
                    plan_to_issue,
                    accumulated_feedback,
                )

        self.logger.warning(
            f"\033[91m✗ [FixerCoordinator] Max retries exceeded ({plan_loc})\033[0m"
        )
        self._collect_error(
            "Max Retries Error",
            f"Failed after 3 attempts: {'; '.join(accumulated_feedback)}",
            plan.file_path,
        )
        if bar:
            bar()
        return FixResult(
            success=False,
            confidence=0.0,
            remaining_issues=accumulated_feedback,
        )

    async def _regenerate_plan_with_feedback(
        self,
        plan: FixPlan,
        plan_key: str,
        analysis_coordinator: AnalysisCoordinator,
        plan_to_issue: dict[str, Issue],
        feedback: list[str],
    ) -> FixPlan:
        plan_loc = (
            f"{plan.file_path}:{plan.changes[0].line_range[0]}"
            if plan.changes
            else plan.file_path
        )
        self.logger.info(
            f"\033[93m🔄 [AnalysisCoordinator] Regenerating plan with feedback "
            f"({plan_loc})\033[0m"
        )

        source_issue = plan_to_issue.get(plan_key)
        if not source_issue:
            # Fallback: try the old file_path-only key for backward compat
            source_issue = plan_to_issue.get(plan.file_path)
        if not source_issue:
            return plan

        enhanced_issue = self._enhance_issue_with_feedback(source_issue, feedback)
        try:
            new_plans = await asyncio.wait_for(
                analysis_coordinator.analyze_issues([enhanced_issue]),
                timeout=30,
            )
            if new_plans:
                self.logger.info(
                    f"📋 Re-generated plan with {len(new_plans[0].changes)} changes"
                )
                return new_plans[0]
        except TimeoutError:
            self.logger.warning(
                f"\033[91m⏱️ [AnalysisCoordinator] Plan regeneration timed out "
                f"({plan_loc})\033[0m"
            )
        except Exception as e:
            self.logger.warning(f"Could not regenerate plan: {e}")

        return plan

    def _check_execution_results(self, results: list[FixResult]) -> bool:
        success_count = sum(1 for r in results if r.success)
        total_count = len(results)
        self._success_count = success_count
        self._total_count = total_count

        self._display_error_summary()

        if success_count > 0:
            self.logger.info(
                f"📊 V2 Pipeline Results: {success_count}/{total_count} plans succeeded"
            )

        return success_count > 0

    def _create_backup(self, file_path: str) -> str:
        import shutil
        import tempfile

        source_path = Path(file_path)
        backup_dirs = [
            source_path.parent,
            self.pkg_path / ".crackerjack" / "backups",
            Path(tempfile.gettempdir()) / "crackerjack" / "backups",
        ]

        for backup_dir in backup_dirs:
            try:
                backup_dir.mkdir(parents=True, exist_ok=True)
                backup_path = backup_dir / f"{source_path.name}.backup"
                shutil.copy2(source_path, backup_path)
                metadata_path = backup_path.with_suffix(backup_path.suffix + ".json")
                metadata_path.write_text(
                    json.dumps({"original_path": str(source_path)}),
                    encoding="utf-8",
                )
                self.logger.debug(f"Created backup: {backup_path}")
                return str(backup_path)
            except OSError as exc:
                self.logger.debug(
                    "Backup path unavailable, trying next candidate: %s",
                    exc,
                )
                continue

        raise OSError(f"Unable to create backup for {file_path}")

    def _restore_backup(self, backup_path: str) -> None:
        import shutil

        backup_file = Path(backup_path)
        metadata_path = backup_file.with_suffix(backup_file.suffix + ".json")
        if metadata_path.exists():
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            file_path = Path(metadata["original_path"])
        else:
            file_path = Path(backup_path.replace(".backup", ""))

        shutil.move(str(backup_file), file_path)
        if metadata_path.exists():
            metadata_path.unlink(missing_ok=True)
        self.logger.debug(f"Restored backup: {file_path}")

    def _is_non_retryable_write_failure(
        self,
        feedback: str,
        plan_results: list[FixResult] | None = None,
    ) -> bool:
        text_parts = [feedback.lower()]
        if plan_results:
            for result in plan_results:
                text_parts.extend(issue.lower() for issue in result.remaining_issues)

        text = " ".join(text_parts)
        failure_markers = (
            "operation not permitted",
            "permission denied",
            "read-only database",
            "read only",
            "failed to write",
            "failed to create backup",
            "failed to open",
        )
        return any(marker in text for marker in failure_markers)

    def _is_writable_target(self, file_path: str) -> bool:
        path = Path(file_path)
        if path.exists():
            return os.access(path, os.W_OK)
        return os.access(path.parent, os.W_OK)

    def _enhance_issue_with_feedback(
        self, issue: Issue, feedback_history: list[str]
    ) -> Issue:

        enhanced_details = issue.details.copy() if issue.details else []
        enhanced_details.append("--- Previous Attempt Feedback ---")
        for i, feedback in enumerate(feedback_history[-3:], 1):
            truncated = feedback[:200] + "..." if len(feedback) > 200 else feedback
            enhanced_details.append(f"[{i}] {truncated}")

        return Issue(
            type=issue.type,
            severity=issue.severity,
            message=f"{issue.message} (retry with feedback)",
            file_path=issue.file_path,
            line_number=issue.line_number,
            details=enhanced_details,
            stage=issue.stage,
        )

    _swarm_manager: t.Any = None  # type: ignore[misc]

    @property
    def swarm_enabled(self) -> bool:
        return os.environ.get("CRACKERJACK_SWARM", "1") == "1"

    async def _get_swarm_manager(self) -> t.Any:
        if self._swarm_manager is None:
            from crackerjack.services.swarm_client import SwarmManager

            worker_count = int(os.environ.get("CRACKERJACK_SWARM_WORKERS", "4"))
            mcp_port = int(os.environ.get("CRACKERJACK_SWARM_MCP_PORT", "8680"))

            self._swarm_manager = SwarmManager(
                project_path=self.pkg_path,
                prefer_parallel=True,
                worker_count=worker_count,
                mcp_port=mcp_port,
                agent_executor=self._create_swarm_agent_executor(),
            )

            await self._swarm_manager.initialize()

            if self._swarm_manager.is_parallel:
                self.logger.info(
                    f"🐝 Swarm mode active: {worker_count} parallel workers"
                )
            else:
                self.logger.info("🔄 Swarm mode: sequential fallback")

        return self._swarm_manager

    def _create_swarm_agent_executor(
        self,
    ) -> t.Callable[[t.Any], t.Awaitable[t.Any]]:

        async def executor(task: t.Any) -> t.Any:
            from crackerjack.services.swarm_client import SwarmResult

            try:
                result = await self._execute_single_agent_fix(
                    issue_type=task.issue_type,
                    file_paths=task.file_paths,
                    prompt=task.prompt,
                    context=task.context,
                )

                return SwarmResult(
                    task_id=task.task_id,
                    worker_id="",
                    success=result.get("success", False),
                    files_modified=result.get("files_modified", []),
                    fixes_applied=result.get("fixes_applied", 0),
                    errors=result.get("errors", []),
                )
            except Exception as e:
                from crackerjack.services.swarm_client import SwarmResult

                return SwarmResult(
                    task_id=task.task_id,
                    worker_id="",
                    success=False,
                    errors=[str(e)],
                )

        return executor

    async def _execute_single_agent_fix(
        self,
        issue_type: str,
        file_paths: list[str],
        prompt: str,
        context: dict[str, t.Any],
    ) -> dict[str, t.Any]:
        from pathlib import Path

        from crackerjack.agents.base import AgentContext, Issue, IssueType, Priority

        issue_type_map = {
            "typing": IssueType.TYPE_ERROR,
            "refurb": IssueType.REFURB,
            "complexity": IssueType.COMPLEXITY,
            "security": IssueType.SECURITY,
            "formatting": IssueType.FORMATTING,
            "import": IssueType.IMPORT_ERROR,
            "test": IssueType.TEST_FAILURE,
            "documentation": IssueType.DOCUMENTATION,
        }

        mapped_type = issue_type_map.get(issue_type.lower(), IssueType.TYPE_ERROR)

        issues = []
        for file_path in file_paths:
            issue = Issue(
                type=mapped_type,
                severity=Priority.MEDIUM,
                message=prompt,
                file_path=Path(file_path),  # type: ignore
                line_number=context.get("line"),
                details=[context.get("original_message", "")],
            )
            issues.append(issue)

        if not issues:
            return {"success": False, "errors": ["No issues to fix"]}

        try:
            coordinator = self._setup_ai_fix_coordinator()
            context_obj = AgentContext(  # type: ignore[call-arg]
                project_path=self.pkg_path,
                issue=issues[0],
            )

            results = []
            for issue in issues:
                context_obj.issue = issue  # type: ignore
                result = coordinator.analyze_and_fix(context_obj)  # type: ignore
                results.append(result)

            success = any(r.success for r in results if hasattr(r, "success"))
            files_modified = list(
                set(
                    str(r.file_path)
                    for r in results
                    if hasattr(r, "file_path") and r.file_path
                )
            )
            fixes_applied = sum(
                r.fixes_applied for r in results if hasattr(r, "fixes_applied")
            )
            errors = [
                e
                for r in results
                if hasattr(r, "errors") and r.errors
                for e in r.errors
            ]

            return {
                "success": success,
                "files_modified": files_modified,
                "fixes_applied": fixes_applied,
                "errors": errors,
            }

        except Exception as e:
            self.logger.error(f"Swarm agent execution failed: {e}")
            return {"success": False, "errors": [str(e)]}

    async def _apply_swarm_fixes(
        self,
        issues: list[Issue],
        stage: str = "comprehensive",
    ) -> bool:
        if not issues:
            return True

        if not self.swarm_enabled:
            self.logger.debug("Swarm mode disabled, using standard pipeline")
            return False

        try:
            manager = await self._get_swarm_manager()

            issue_dicts = []
            for issue in issues:
                issue_dicts.append(
                    {
                        "type": issue.type.value
                        if hasattr(issue.type, "value")
                        else str(issue.type),
                        "file": str(issue.file_path) if issue.file_path else "",
                        "message": issue.message,
                        "priority": issue.severity.value
                        if hasattr(issue.severity, "value")
                        else 0,
                        "line": issue.line_number,
                        "context": {
                            "details": issue.details.copy() if issue.details else [],
                        },
                    }
                )

            results = await manager.execute_fixes(issue_dicts)

            success_count = sum(1 for r in results if r.success)
            total_count = len(results)

            self._success_count = success_count
            self._total_count = total_count

            for result in results:
                if result.success:
                    self.logger.info(
                        f"✅ Swarm fix: {result.task_id} - "
                        f"{result.fixes_applied} fixes in {len(result.files_modified)} files"
                    )
                else:
                    self.logger.warning(
                        f"❌ Swarm fix failed: {result.task_id} - "
                        f"{', '.join(result.errors[:2])}"
                    )
                    self._collect_error(
                        "Swarm Fix Error",
                        "; ".join(result.errors[:2]),
                        result.files_modified[0] if result.files_modified else "",
                    )

            await manager.shutdown()

            self.logger.info(
                f"🐝 Swarm results: {success_count}/{total_count} tasks succeeded "
                f"(mode: {manager.mode.value})"
            )

            return success_count > 0

        except Exception as e:
            self.logger.error(f"Swarm fixing failed: {e}")
            self._collect_error("Swarm Error", str(e))
            return False


def _extract_issue_count_from_json(output: str, tool_name: str) -> int | None:
    try:
        data = json.loads(output)
        return _count_issues_for_tool(data, tool_name)
    except (json.JSONDecodeError, TypeError):
        return None


def _count_issues_for_tool(data: object, tool_name: str) -> int | None:
    if tool_name in ("ruff", "ruff-check", "mypy", "zuban", "pyrefly", "ty", "pyright"):
        return _count_list_data(data)
    if tool_name == "bandit":
        return _count_bandit_results(data)
    if tool_name == "semgrep":
        return _count_semgrep_results(data)
    if tool_name == "pytest":
        return _count_pytest_results(data)
    return None


def _count_list_data(data: object) -> int | None:
    return len(data) if isinstance(data, list) else None


def _count_bandit_results(data: object) -> int | None:
    if isinstance(data, dict) and "results" in data:
        results = data["results"]
        return len(results) if isinstance(results, list) else None
    return None


def _count_semgrep_results(data: object) -> int | None:
    if isinstance(data, dict) and "results" in data:
        results = data["results"]
        return len(results) if isinstance(results, list) else None
    return None


def _count_pytest_results(data: object) -> int | None:
    if isinstance(data, dict) and "tests" in data:
        tests = data["tests"]
        if isinstance(tests, list):
            failed = [
                t for t in tests if isinstance(t, dict) and t.get("outcome") == "failed"
            ]
            return len(failed)
    return None


def _extract_issue_count_from_text_lines(output: str) -> int | None:
    lines = output.split("\n")
    issue_lines = [
        line
        for line in lines
        if line.strip()
        and ":" in line
        and not line.strip().startswith(("#", "─", "Found"))
    ]
    return len(issue_lines) if issue_lines else None
