"""Notification storage and retrieval for the admin panel.

Stores notifications in ~/.sygen/notifications.json with FIFO rotation
(max 500 entries). Thread-safe via asyncio file locks.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, Literal

logger = logging.getLogger(__name__)

_SYGEN_HOME = Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))
_MAX_NOTIFICATIONS = 500

Severity = Literal["critical", "warning", "info", "silent"]
VALID_SEVERITIES: tuple[str, ...] = ("critical", "warning", "info", "silent")
# Severities counted toward the unread badge.
UNREAD_SEVERITIES: frozenset[str] = frozenset({"critical", "warning", "info"})


def _normalize_severity(value: Any) -> str:
    """Coerce an arbitrary value to a valid severity, defaulting to 'info'."""
    if isinstance(value, str) and value in VALID_SEVERITIES:
        return value
    return "info"


def _migrate_record(record: dict[str, Any]) -> dict[str, Any]:
    """Backfill severity on a record read from disk (no overwrite to file)."""
    if "severity" not in record or record.get("severity") not in VALID_SEVERITIES:
        record["severity"] = "info"
    return record


_EMPTY_BODY_TOKENS: frozenset[str] = frozenset({"", "done", "ok", "success", "completed"})


def is_empty_body(body: str | None) -> bool:
    """Return True for trivial success bodies that carry no real information."""
    if body is None:
        return True
    if not isinstance(body, str):
        return False
    return body.strip().lower() in _EMPTY_BODY_TOKENS


def classify_event(source: str, status: str, body: str | None) -> str | None:
    """Map an observer event to a severity, or None to skip persistence.

    Returns None when the event is pure noise (e.g. a cron success with an
    empty body). Otherwise returns one of the valid severities.
    """
    is_success = status == "success"
    empty = is_empty_body(body)

    if source == "cron":
        if is_success:
            return None if empty else "silent"
        return "critical"

    if source == "task":
        if is_success:
            return None if empty else "silent"
        return "critical"

    if source == "webhook":
        if is_success and empty:
            return None
        if is_success:
            return "silent"
        return "warning"

    return "info"

_file_locks: dict[str, asyncio.Lock] = {}


def _notifications_path() -> Path:
    return _SYGEN_HOME / "notifications.json"


async def _with_file_lock(path: Path) -> asyncio.Lock:
    key = str(path)
    if key not in _file_locks:
        _file_locks[key] = asyncio.Lock()
    return _file_locks[key]


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def _write_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), "utf-8")
    tmp.replace(path)


BroadcastFn = Callable[[dict[str, Any]], Awaitable[None]]


async def create_notification(
    type: str,
    agent: str,
    title: str,
    body: str,
    status: str,
    source_id: str,
    severity: str = "info",
    broadcast_fn: BroadcastFn | None = None,
) -> dict[str, Any]:
    """Create and persist a notification. Optionally broadcast via WebSocket."""
    notification: dict[str, Any] = {
        "id": f"notif-{uuid.uuid4()}",
        "type": type,
        "agent": agent,
        "title": title,
        "body": body,
        "status": status,
        "source_id": source_id,
        "severity": _normalize_severity(severity),
        "created_at": time.time(),
        "read": False,
    }

    path = _notifications_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"notifications": []}
        notifications = data.get("notifications", [])
        notifications.append(notification)
        if len(notifications) > _MAX_NOTIFICATIONS:
            notifications = notifications[-_MAX_NOTIFICATIONS:]
        data["notifications"] = notifications
        _write_json(path, data)

    if broadcast_fn:
        try:
            await broadcast_fn(notification)
        except Exception:
            logger.debug("Failed to broadcast notification", exc_info=True)

    return notification


async def get_notifications(
    limit: int = 50,
    unread_only: bool = False,
    severities: tuple[str, ...] | None = None,
) -> list[dict[str, Any]]:
    """Return notifications, newest first.

    `severities`: when provided, only records whose severity is in this set
    are returned. Records without a severity field are migrated to 'info' on
    read (no disk overwrite).
    """
    path = _notifications_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"notifications": []}
    notifications = [_migrate_record(n) for n in data.get("notifications", [])]
    if severities is not None:
        allowed = set(severities)
        notifications = [n for n in notifications if n.get("severity") in allowed]
    if unread_only:
        notifications = [n for n in notifications if not n.get("read")]
    notifications.reverse()
    return notifications[:limit]


async def mark_read(notification_id: str) -> bool:
    """Mark a single notification as read. Returns True if found."""
    path = _notifications_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return False
        notifications = data.get("notifications", [])
        for n in notifications:
            if n.get("id") == notification_id:
                n["read"] = True
                _write_json(path, data)
                return True
    return False


async def mark_all_read() -> int:
    """Mark all notifications as read. Returns count of newly marked."""
    path = _notifications_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return 0
        notifications = data.get("notifications", [])
        count = 0
        for n in notifications:
            if not n.get("read"):
                n["read"] = True
                count += 1
        if count:
            _write_json(path, data)
    return count


async def get_unread_count() -> int:
    """Return unread count, excluding 'silent' severity records."""
    path = _notifications_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"notifications": []}
    count = 0
    for raw in data.get("notifications", []):
        n = _migrate_record(raw)
        if n.get("read"):
            continue
        if n.get("severity") not in UNREAD_SEVERITIES:
            continue
        count += 1
    return count
