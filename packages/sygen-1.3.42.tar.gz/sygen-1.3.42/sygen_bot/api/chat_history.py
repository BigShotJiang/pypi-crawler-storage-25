"""Helpers for persisting ``chat_message`` events into admin chat history.

Used by :class:`~sygen_bot.api.server.ApiServer` to append task / interagent
events into the admin panel's chat session file so they survive a reload.
Messages with no matching chat session are broadcast-only: we write the
event to disk when possible, but the WS fan-out is the source of truth.
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any

from sygen_bot.api._file_locks import FILE_LOCKS as _file_locks, lock_for as _lock_for

logger = logging.getLogger(__name__)


_SESSION_ID_RE = __import__("re").compile(r"^[a-zA-Z0-9_-]+$")


def _home() -> Path:
    return Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))


def _chat_sessions_path() -> Path:
    return _home() / "chat_sessions.json"


def _chat_history_dir() -> Path:
    return _home() / "chat_history"


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def _write_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), "utf-8")
    tmp.replace(path)


def _latest_session_id_for_agent(agent: str) -> str | None:
    """Return the most recently updated chat session for *agent*, if any."""
    data = _read_json(_chat_sessions_path())
    sessions = (data or {}).get("sessions", []) if isinstance(data, dict) else []
    candidates = [s for s in sessions if isinstance(s, dict) and s.get("agent") == agent]
    if not candidates:
        return None
    candidates.sort(key=lambda s: s.get("updated_at", 0), reverse=True)
    sid = candidates[0].get("id")
    return sid if isinstance(sid, str) and _SESSION_ID_RE.match(sid) else None


def _payload_to_message(payload: dict[str, Any]) -> dict[str, Any]:
    """Shape a ``chat_message`` WS payload into a persisted history record.

    Keeps the same field names that ``ChatSessionMessage`` in the admin
    client expects (sender/agentName/content/timestamp) and adds
    kind/meta so non-text events can re-render as cards after reload.
    """
    ts_raw = payload.get("timestamp", time.time())
    try:
        ts_float = float(ts_raw)
    except (TypeError, ValueError):
        ts_float = time.time()
    iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts_float))

    agent = payload.get("agent") or "main"
    role = payload.get("role", "agent")
    if role == "user":
        sender = "user"
    elif role == "system":
        sender = "system"
    else:
        sender = "agent"
    record: dict[str, Any] = {
        "id": f"msg-{uuid.uuid4()}",
        "sender": sender,
        "agentName": str(agent),
        "content": str(payload.get("content", "")),
        "timestamp": iso,
        "kind": str(payload.get("kind", "text")),
    }
    meta = payload.get("meta")
    if isinstance(meta, dict) and meta:
        record["meta"] = meta
    files = payload.get("files")
    if isinstance(files, list) and files:
        record["files"] = files
    return record


def resolve_chat_session_id(payload: dict[str, Any]) -> str | None:
    """Return the REST session id this payload should land in (read-only).

    Cheap pure-read helper so callers can update the broadcast envelope
    with the resolved id without waiting for the disk write that
    :func:`persist_chat_message` performs. Returns ``None`` when no
    matching chat session exists.
    """
    agent = str(payload.get("agent") or "")
    if not agent:
        return None

    session_id = str(payload.get("session_id") or "")
    sessions = _read_json(_chat_sessions_path()) or {}
    known_ids = {
        s.get("id")
        for s in (sessions.get("sessions", []) if isinstance(sessions, dict) else [])
        if isinstance(s, dict)
    }
    if session_id in known_ids and _SESSION_ID_RE.match(session_id or ""):
        return session_id
    return _latest_session_id_for_agent(agent)


async def persist_chat_message(payload: dict[str, Any]) -> str | None:
    """Append a ``chat_message`` payload to the agent's latest chat history.

    Returns the resolved session id on success, ``None`` if no matching
    chat session exists (broadcast-only) or persistence failed. Best-effort:
    never raises — admin WS fan-out continues regardless.
    """
    session_id = resolve_chat_session_id(payload)
    if session_id is None:
        return None

    history_dir = _chat_history_dir()
    history_dir.mkdir(parents=True, exist_ok=True)
    history_file = history_dir / f"{session_id}.json"

    record = _payload_to_message(payload)
    lock = _lock_for(history_file)
    try:
        async with lock:
            existing = _read_json(history_file)
            if isinstance(existing, dict):
                messages = list(existing.get("messages") or [])
            elif isinstance(existing, list):
                messages = list(existing)
            else:
                messages = []
            messages.append(record)
            _write_json(history_file, {"messages": messages})

        # Bump the session's updated_at so it sorts to the top of the list.
        sessions_path = _chat_sessions_path()
        sessions_lock = _lock_for(sessions_path)
        async with sessions_lock:
            data = _read_json(sessions_path) or {"sessions": []}
            for s in data.get("sessions", []):
                if isinstance(s, dict) and s.get("id") == session_id:
                    s["updated_at"] = time.time()
                    break
            _write_json(sessions_path, data)
    except Exception:
        logger.debug("persist_chat_message failed for session=%s", session_id, exc_info=True)
        return None

    return session_id


# ---------------------------------------------------------------------------
# Direct persistence for admin WS (server-side source of truth)
# ---------------------------------------------------------------------------
#
# ``persist_chat_message`` above only writes *broadcast* chat_message envelopes
# (task / interagent events) whose ``agent`` field resolves to an existing
# session. The admin WS chat path needs a stricter contract: the server must
# persist both sides of the conversation as soon as they exist, so a WS
# disconnect mid-stream never loses the user turn or the assistant response.
# The helpers below are the direct-write primitives used by
# ``ApiServer._admin_dispatch_message``.


async def _write_history_message(
    session_id: str,
    message: dict[str, Any],
    *,
    upsert_by_id: bool,
) -> bool:
    """Append or upsert ``message`` in ``chat_history/<session_id>.json``.

    Returns True on success, False if the session_id failed validation or
    the write raised. Callers should treat failures as non-fatal.
    """
    if not isinstance(session_id, str) or not _SESSION_ID_RE.match(session_id):
        return False

    history_dir = _chat_history_dir()
    try:
        history_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        logger.debug("chat history dir create failed", exc_info=True)
        return False
    history_file = history_dir / f"{session_id}.json"

    lock = _lock_for(history_file)
    try:
        async with lock:
            existing = _read_json(history_file)
            if isinstance(existing, dict):
                messages = list(existing.get("messages") or [])
            elif isinstance(existing, list):
                messages = list(existing)
            else:
                messages = []

            if upsert_by_id:
                mid = message.get("id")
                replaced = False
                if mid:
                    for i, m in enumerate(messages):
                        if isinstance(m, dict) and m.get("id") == mid:
                            messages[i] = message
                            replaced = True
                            break
                if not replaced:
                    messages.append(message)
            else:
                messages.append(message)

            _write_json(history_file, {"messages": messages})

        sessions_path = _chat_sessions_path()
        sessions_lock = _lock_for(sessions_path)
        async with sessions_lock:
            data = _read_json(sessions_path) or {"sessions": []}
            for s in data.get("sessions", []):
                if isinstance(s, dict) and s.get("id") == session_id:
                    s["updated_at"] = time.time()
                    break
            _write_json(sessions_path, data)
    except Exception:
        logger.debug(
            "write_history_message failed sid=%s upsert=%s",
            session_id,
            upsert_by_id,
            exc_info=True,
        )
        return False

    return True


def _iso_timestamp(ts: float | None) -> str:
    ts_float = ts if ts is not None else time.time()
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts_float))


async def persist_admin_user_message(
    session_id: str,
    content: str,
    *,
    msg_id: str | None = None,
    timestamp: float | None = None,
    files: list[dict[str, Any]] | None = None,
) -> str:
    """Append a user message to ``session_id``'s chat history.

    If ``msg_id`` is provided (e.g. by the admin client via the WS payload),
    the server upserts under that id so client-side autosave and server-side
    persistence share a single record. Otherwise generates a ``msg-<uuid>``.
    Best-effort: swallows errors so a failing disk write never blocks the
    admin WS dispatch.
    """
    resolved_id = msg_id or f"msg-{uuid.uuid4()}"
    message: dict[str, Any] = {
        "id": resolved_id,
        "sender": "user",
        "content": content,
        "timestamp": _iso_timestamp(timestamp),
    }
    if files:
        message["files"] = files
    # Upsert-by-id when the client supplied the id, so a late autosave that
    # lands after the server persist doesn't create a second record.
    await _write_history_message(session_id, message, upsert_by_id=msg_id is not None)
    return resolved_id


async def upsert_admin_assistant_message(
    session_id: str,
    msg_id: str,
    content: str,
    *,
    agent_name: str = "main",
    timestamp: float | None = None,
) -> bool:
    """Upsert an assistant message by id in ``session_id``'s chat history.

    Used by the admin WS streaming flush: called periodically with the
    growing content so a mid-stream disconnect still leaves a partial
    assistant turn on disk. Returns True on success.
    """
    message: dict[str, Any] = {
        "id": msg_id,
        "sender": "agent",
        "agentName": agent_name,
        "content": content,
        "timestamp": _iso_timestamp(timestamp),
    }
    return await _write_history_message(session_id, message, upsert_by_id=True)
