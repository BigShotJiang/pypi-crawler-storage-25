from __future__ import annotations

import json
import warnings
from collections.abc import Mapping
from datetime import datetime
from typing import Any, Literal, TypedDict

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import requests

from dbnl import config
from dbnl.api.util import (
    ResourceName,
    create,
    delete,
    get,
    get_by_name,
    list_,
    parse_error_from_xml,
    parse_query_response,
    parse_response,
    request,
    update,
)
from dbnl.api.version import check_version_compatibility
from dbnl.errors import (
    DBNLConfigurationError,
    DBNLRunNotUploadableError,
    DBNLUploadResultsError,
)
from dbnl.warnings import DBNLAPIIncompatibilityWarning

_MAX_ROW_GROUP_SIZE = 10_000
_MAX_ROW_FILE_SIZE = 10_000


def get_spec() -> dict[str, Any]:
    response = request("GET", "spec.json")
    return parse_response(response)


def maybe_warn_invalid_version() -> None:
    response = request("GET", "spec.json")
    if response.status_code != 200:
        warnings.warn(
            f"Failed to fetch OpenAPI spec: {response.status_code}. Cannot validate API version compatability with SDK.",
            DBNLAPIIncompatibilityWarning,
            stacklevel=2,
        )
        return
    try:
        spec = json.loads(response.text)
        api_version = spec.get("info", {}).get("version")
        check_version_compatibility(api_version)
    except json.JSONDecodeError:
        warnings.warn(
            "Failed to parse OpenAPI spec. Cannot validate API version compatability with SDK.",
            DBNLAPIIncompatibilityWarning,
            stacklevel=2,
        )


def ensure_valid_token() -> None:
    data = parse_response(request("GET", "users/me"))
    # A bad DBNL_API_URL may still return a 200. Sanity check the response.
    if "id" not in data:
        raise DBNLConfigurationError(
            "Failed to validate user token against the dbnl API. Likely your DBNL_API_URL is incorrect. "
            f"Current value is {config.api_url()}"
        )


def get_me() -> dict[str, Any]:
    response = request("GET", "users/me")
    return parse_response(response)


def get_default_namespace() -> dict[str, Any]:
    response = request("GET", "namespaces", query_params={"is_default": True})
    return parse_query_response(response)


#
# Projects endpoints.
#


def create_project(
    name: str,
    description: str | None = None,
    schedule: Literal["daily", "hourly"] | None = "daily",
    default_llm_model_id: str | None = None,
    template: Literal["default"] | None = "default",
) -> dict[str, Any]:
    json_payload = {"name": name}
    if description is not None:
        json_payload.update({"description": description})
    if schedule is not None:
        json_payload.update({"schedule": schedule})
    if default_llm_model_id is not None:
        json_payload.update({"default_llm_model_id": default_llm_model_id})
    if template is not None:
        json_payload.update({"template": template})
    return create(ResourceName.PROJECTS, json=json_payload)


def get_project(project_id: str) -> dict[Any, Any]:
    return get(ResourceName.PROJECTS, project_id)


def get_project_by_name(name: str, archived: bool | None = None) -> dict[Any, Any]:
    params: dict[str, Any] = {}
    if archived is not None:
        params["archived"] = archived
    return get_by_name(ResourceName.PROJECTS, name, params)


#
# Runs endpoints.
#


def create_run(
    project_id: str,
    data_start_time: datetime | None = None,
    data_end_time: datetime | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {
        "project_id": project_id,
    }
    if data_start_time is not None:
        json_payload.update({"data_start_time": data_start_time.isoformat()})
    if data_end_time is not None:
        json_payload.update({"data_end_time": data_end_time.isoformat()})
    return create(ResourceName.RUNS, json=json_payload)


def get_run(run_id: str) -> dict[Any, Any]:
    return get(ResourceName.RUNS, run_id)


def generate_run_upload_url(
    *,
    run_id: str,
    location: Literal[
        "dataset",
        "staging_spans",
        "staging_spans_extra",
        "staging_traces_extra",
        "staging_sessions_extra",
    ]
    | None = None,
    part: int | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {}
    if location is not None:
        json_payload["location"] = location
    if part is not None:
        json_payload["part"] = part
    response = request(
        "POST",
        f"runs/{run_id}/generate_upload_url",
        json_payload=json_payload if json_payload else None,
    )
    if response.status_code == 400 and json.loads(response.text).get("code") == "run_not_uploadable":
        raise DBNLRunNotUploadableError(run_id)
    return parse_response(response)


def close_run(run_id: str) -> dict[Any, Any]:
    response = request("POST", f"runs/{run_id}/close")
    return parse_response(response)


def _upload_parquet_table(run_id: str, table: pa.Table, upload_details: dict[str, Any]) -> None:
    data_buffer = pa.BufferOutputStream()
    pq.write_table(table, data_buffer, row_group_size=_MAX_ROW_GROUP_SIZE)

    # GCS requires PUT method and uploads raw data rather than POST + files
    files: Mapping[str, pa.Buffer] | None
    data: Any
    if upload_details["method"] == "PUT" and not upload_details["data"]:
        data = data_buffer.getvalue()
        files = None
    else:
        data = upload_details["data"]
        files = {"file": data_buffer.getvalue()}

    response = requests.request(
        method=upload_details["method"],
        url=upload_details["url"],
        data=data,
        files=files,  # type: ignore[arg-type]
        headers=upload_details["headers"],
        timeout=300,
    )
    if response.status_code >= 400:
        error_detail = parse_error_from_xml(response) or response.text
        raise DBNLUploadResultsError(
            run_id,
            error_detail,
            upload_details["url"],
        )


def post_results(run_id: str, data: pd.DataFrame) -> None:
    upload_details = generate_run_upload_url(run_id=run_id)
    pa_table = pa.Table.from_pandas(data, preserve_index=False)
    _upload_parquet_table(run_id, pa_table, upload_details)


def post_spans(run_id: str, data: pd.DataFrame) -> None:
    table = pa.Table.from_pandas(data, preserve_index=False)
    for i, batch in enumerate(table.to_batches(max_chunksize=_MAX_ROW_GROUP_SIZE)):
        upload_details = generate_run_upload_url(run_id=run_id, location="staging_spans", part=i)
        _upload_parquet_table(run_id, pa.Table.from_batches([batch], schema=table.schema), upload_details)


def _post_extra_data(
    *,
    run_id: str,
    data: pa.Table,
    location: Literal["staging_spans_extra", "staging_traces_extra", "staging_sessions_extra"],
) -> None:
    upload_details = generate_run_upload_url(run_id=run_id, location=location, part=0)
    _upload_parquet_table(run_id, data, upload_details)


def post_spans_extra(run_id: str, data: pa.Table) -> None:
    _post_extra_data(run_id=run_id, data=data, location="staging_spans_extra")


def post_traces_extra(run_id: str, data: pa.Table) -> None:
    _post_extra_data(run_id=run_id, data=data, location="staging_traces_extra")


def post_sessions_extra(run_id: str, data: pa.Table) -> None:
    _post_extra_data(run_id=run_id, data=data, location="staging_sessions_extra")


def create_metric(
    project_id: str,
    name: str,
    table: Literal["spans", "traces", "sessions"],
    expression: str,
    description: str | None = None,
    greater_is_better: bool | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {
        "project_id": project_id,
        "name": name,
        "table": table,
        "expression": expression,
    }
    if description is not None:
        json_payload.update({"description": description})
    if greater_is_better is not None:
        json_payload.update({"greater_is_better": greater_is_better})
    return create(ResourceName.METRICS, json=json_payload)


def get_metric(metric_id: str) -> dict[str, Any]:
    return get(ResourceName.METRICS, metric_id)


def get_metric_by_name(name: str) -> dict[str, Any]:
    return get_by_name(ResourceName.METRICS, name)


def update_metric(
    metric_id: str,
    name: str | None = None,
    expression: str | None = None,
    description: str | None = None,
    greater_is_better: bool | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {}
    if name is not None:
        json_payload["name"] = name
    if expression is not None:
        json_payload["expression"] = expression
    if description is not None:
        json_payload["description"] = description
    if greater_is_better is not None:
        json_payload["greater_is_better"] = greater_is_better
    return update(ResourceName.METRICS, metric_id, json=json_payload)


def delete_metric(metric_id: str) -> None:
    delete(ResourceName.METRICS, metric_id)


#
# LLM models endpoints.
#


def create_llm_model(
    name: str,
    provider: str,
    model: str,
    description: str | None = None,
    type: Literal["completion", "embedding"] | None = "completion",
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {
        "name": name,
        "model": model,
        "provider": provider,
        "params": params or {},
        "type": type,
    }
    if description is not None:
        json_payload.update({"description": description})
    return create(ResourceName.LLM_MODELS, json=json_payload)


def get_llm_model(llm_model_id: str) -> dict[str, Any]:
    return get(ResourceName.LLM_MODELS, llm_model_id)


def get_llm_model_by_name(name: str) -> dict[str, Any]:
    return get_by_name(ResourceName.LLM_MODELS, name)


def update_llm_model(
    llm_model_id: str,
    name: str | None = None,
    description: str | None = None,
    model: str | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {}
    if name is not None:
        json_payload["name"] = name
    if model is not None:
        json_payload["model"] = model
    if params is not None:
        json_payload["params"] = params
    if description is not None:
        json_payload["description"] = description
    return update(ResourceName.LLM_MODELS, llm_model_id, json=json_payload)


def delete_llm_model(llm_model_id: str) -> None:
    return delete(ResourceName.LLM_MODELS, llm_model_id)


def list_llm_models(
    name: str | None = None,
    type: Literal["completion", "embedding"] | None = None,
    provider: str | None = None,
    model: str | None = None,
) -> list[dict[str, Any]]:
    params: dict[str, Any] = {}
    if name is not None:
        params["name"] = name
    if model is not None:
        params["model"] = model
    if provider is not None:
        params["provider"] = provider
    if type is not None:
        params["type"] = type
    return list_(ResourceName.LLM_MODELS, params=params)


#
# Notification integrations endpoints.
#


def create_notification_integration(
    name: str,
    integration_type: str,
    integration_params: dict[str, Any],
    description: str | None = None,
) -> dict[str, Any]:
    json_payload = {
        "name": name,
        "integration_type": integration_type,
        "integration_params": integration_params,
    }
    if description is not None:
        json_payload.update({"description": description})
    return create(ResourceName.NOTIFICATION_INTEGRATIONS, json=json_payload)


def get_notification_integration(notification_integration_id: str) -> dict[str, Any]:
    return get(ResourceName.NOTIFICATION_INTEGRATIONS, notification_integration_id)


def update_notification_integration(
    notification_integration_id: str,
    name: str | None = None,
    integration_type: str | None = None,
    integration_params: dict[str, Any] | None = None,
    description: str | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {}
    if name is not None:
        json_payload["name"] = name
    if integration_type is not None:
        json_payload["integration_type"] = integration_type
    if integration_params is not None:
        json_payload["integration_params"] = integration_params
    if description is not None:
        json_payload["description"] = description
    return update(ResourceName.NOTIFICATION_INTEGRATIONS, notification_integration_id, json=json_payload)


def delete_notification_integration(notification_integration_id: str) -> None:
    delete(ResourceName.NOTIFICATION_INTEGRATIONS, notification_integration_id)


def list_notification_integrations() -> list[dict[str, Any]]:
    return list_(ResourceName.NOTIFICATION_INTEGRATIONS)


#
# Notification rules endpoints.
#


def create_notification_rule(
    project_id: str,
    name: str,
    status: str,
    trigger: str,
    notification_integration_ids: list[str],
    conditions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {
        "project_id": project_id,
        "name": name,
        "status": status,
        "trigger": trigger,
        "notification_integration_ids": notification_integration_ids,
    }
    if conditions is not None:
        json_payload.update({"conditions": conditions})
    return create(ResourceName.NOTIFICATION_RULES, json=json_payload)


def get_notification_rule(notification_rule_id: str) -> dict[str, Any]:
    return get(ResourceName.NOTIFICATION_RULES, notification_rule_id)


def update_notification_rule(
    notification_rule_id: str,
    name: str | None = None,
    status: str | None = None,
    notification_integration_ids: list[str] | None = None,
    conditions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {}
    if name is not None:
        json_payload["name"] = name
    if status is not None:
        json_payload["status"] = status
    if notification_integration_ids is not None:
        json_payload["notification_integration_ids"] = notification_integration_ids
    if conditions is not None:
        json_payload["conditions"] = conditions
    return update(ResourceName.NOTIFICATION_RULES, notification_rule_id, json=json_payload)


def delete_notification_rule(notification_rule_id: str) -> None:
    delete(ResourceName.NOTIFICATION_RULES, notification_rule_id)


def list_notification_rules(
    project_id: str | None = None,
    notification_integration_id: str | None = None,
) -> list[dict[str, Any]]:
    params: dict[str, Any] = {}
    if project_id is not None:
        params["project_id"] = project_id
    if notification_integration_id is not None:
        params["notification_integration_id"] = notification_integration_id
    return list_(ResourceName.NOTIFICATION_RULES, params=params)


#
# Filters endpoints.
#


class FilterCondition(TypedDict):
    column_name: str
    operator: str
    value_expression: str


def create_filter(
    project_id: str,
    name: str,
    table: Literal["spans", "traces", "sessions"],
    conditions: list[FilterCondition],
    description: str | None = None,
    expression: str | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {
        "project_id": project_id,
        "name": name,
        "table": table,
        "conditions": conditions,
    }
    if description is not None:
        json_payload["description"] = description
    if expression is not None:
        json_payload["expression"] = expression
    return create(ResourceName.FILTERS, json=json_payload)


def get_filter(filter_id: str) -> dict[str, Any]:
    return get(ResourceName.FILTERS, filter_id)


def get_filter_by_name(name: str) -> dict[str, Any]:
    return get_by_name(ResourceName.FILTERS, name)


def update_filter(
    filter_id: str,
    name: str | None = None,
    description: str | None = None,
    conditions: list[FilterCondition] | None = None,
    expression: str | None = None,
) -> dict[str, Any]:
    json_payload: dict[str, Any] = {}
    if name is not None:
        json_payload["name"] = name
    if description is not None:
        json_payload["description"] = description
    if conditions is not None:
        json_payload["conditions"] = conditions
    if expression is not None:
        json_payload["expression"] = expression
    return update(ResourceName.FILTERS, filter_id, json=json_payload)


def delete_filter(filter_id: str) -> None:
    delete(ResourceName.FILTERS, filter_id)


def list_filters(project_id: str | None = None) -> list[dict[str, Any]]:
    params: dict[str, Any] = {}
    if project_id is not None:
        params["project_id"] = project_id
    return list_(ResourceName.FILTERS, params=params)
