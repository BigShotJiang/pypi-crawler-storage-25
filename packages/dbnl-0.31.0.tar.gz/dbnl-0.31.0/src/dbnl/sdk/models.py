from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Literal

from dataclasses_json import DataClassJsonMixin

REPR_INDENT = 4

"""
When adding a new class that should be exposed in the documentation, make sure to update
/docs/classes.rst
"""


@dataclass(repr=False)
class DBNLObject(DataClassJsonMixin):
    def __repr__(self) -> str:
        return self._pretty_print()

    def _pretty_print(self, nested_indent: int = 0) -> str:
        field_reprs = []
        for f in fields(self):
            value = getattr(self, f.name)
            if isinstance(value, list):
                value_repr = " " * (
                    2 * REPR_INDENT + nested_indent
                ) + f",\n{' ' * (2 * REPR_INDENT + nested_indent)}".join([f"{d}" for d in value])
                field_reprs.append(f"{f.name}=[\n{value_repr}\n{' ' * (REPR_INDENT + nested_indent)}]")
            elif isinstance(value, dict):
                value_repr = " " * (
                    2 * REPR_INDENT + nested_indent
                ) + f",\n{' ' * (2 * REPR_INDENT + nested_indent)}".join([f"'{k}': {v!r}" for k, v in value.items()])
                field_reprs.append(f"{f.name}=" + "{" + f"\n{value_repr}\n{' ' * (REPR_INDENT + nested_indent)}" + "}")
            elif isinstance(value, DBNLObject):
                field_reprs.append(f"{f.name}={value._pretty_print(nested_indent=REPR_INDENT)}")
            else:
                field_reprs.append(f"{f.name}={value!r}")
        return (
            f"{self.__class__.__name__}(\n{' ' * (REPR_INDENT + nested_indent)}"
            + f",\n{' ' * (REPR_INDENT + nested_indent)}".join(field_reprs)
            + f"\n{' ' * nested_indent})"
        )


@dataclass(repr=False)
class Project(DBNLObject):
    id: str
    org_id: str
    namespace_id: str
    created_at: str
    updated_at: str
    name: str
    description: str | None = None
    schedule: Literal["daily", "hourly"] | None = None
    default_llm_model_id: str | None = None


@dataclass(repr=False)
class Metric(DBNLObject):
    id: str
    org_id: str
    namespace_id: str
    created_at: str
    updated_at: str
    project_id: str
    name: str
    expression: str
    description: str | None = None
    greater_is_better: bool | None = None


@dataclass(repr=False)
class RunMetric(DBNLObject):
    name: str
    table: str
    expression: str
    description: str | None = None
    greater_is_better: bool | None = None


@dataclass(repr=False)
class Run(DBNLObject):
    id: str
    org_id: str
    namespace_id: str
    created_at: str
    updated_at: str
    project_id: str
    data_start_time: str | None = None
    data_end_time: str | None = None
    status: Literal["pending", "closing", "closed", "canceled", "errored"] | None = None
    completed_at: str | None = None
    failure: str | None = None
    metrics: list[RunMetric] = field(default_factory=list)


@dataclass(repr=False)
class LLMModel(DBNLObject):
    id: str
    org_id: str
    namespace_id: str
    created_at: str
    updated_at: str
    name: str
    model: str
    type: str
    provider: str
    author_id: str
    params: dict[str, str]
    description: str | None = None


@dataclass(repr=False)
class FilterCondition(DBNLObject):
    column_name: str
    operator: str
    value_expression: str


@dataclass(repr=False)
class Filter(DBNLObject):
    id: str
    org_id: str
    namespace_id: str
    created_at: str
    updated_at: str
    project_id: str
    name: str
    table: Literal["spans", "traces", "sessions"]
    description: str | None = None
    conditions: list[FilterCondition] = field(default_factory=list)
    expression: str | None = None
