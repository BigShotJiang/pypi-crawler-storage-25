import enum
import json
from collections.abc import Callable
from functools import wraps
from typing import Any, ParamSpec, TypeVar

import click
import yaml
from click import ClickException
from click.types import Choice

from dbnl import __version__, config
from dbnl.api import get_spec
from dbnl.errors import DBNLError
from dbnl.sandbox import (
    SandboxError,
    default_base_url,
    default_registry,
    default_version,
    sandbox_delete,
    sandbox_exec,
    sandbox_logs,
    sandbox_start,
    sandbox_status,
    sandbox_stop,
)
from dbnl.sdk.core import login as core_login

P = ParamSpec("P")
T = TypeVar("T")


def login_required(fn: Callable[P, T]) -> Callable[P, T]:
    """
    Require login before executing command. Tries to login using the config file. On login fail, exits with error code.
    """

    @wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        # Try to login.
        try:
            core_login(verify=True)
        except DBNLError as exc:
            raise ClickException(str(exc)) from exc
        # Call command.
        return fn(*args, **kwargs)

    return wrapped


@click.group()
@click.version_option()
def cli() -> None:
    """The dbnl CLI."""
    pass


class ConfigKey(str, enum.Enum):
    api_token = "api_token"
    api_url = "api_url"
    app_url = "app_url"

    @property
    def description(self) -> str:
        return {
            "api_token": "API token for authentication",
            "api_url": "Base URL of the dbnl API",
            "app_url": "Base URL of the dbnl app",
        }[self.value]


_KEYS_LIST = ", ".join(k.value for k in ConfigKey)
_KEYS_HELP_BLOCK = "\n\n\b\nAccepted keys:\n" + "\n".join(f"  {k.value:<12}{k.description}" for k in ConfigKey)


class ConfigKeyType(click.ParamType):
    name = f"KEY ({_KEYS_LIST})"

    def convert(self, value: str, param: click.Parameter | None, ctx: click.Context | None) -> str:
        try:
            return ConfigKey(value)
        except ValueError:
            self.fail(f"Invalid key {value!r}. Valid keys: {_KEYS_LIST}", param, ctx)


class ConfigPairType(click.ParamType):
    name = f"KEY=VALUE ({_KEYS_LIST})"

    def convert(self, value: str, param: click.Parameter | None, ctx: click.Context | None) -> tuple[str, str]:
        if "=" not in value:
            self.fail(f"Expected KEY=VALUE, got {value!r}.", param, ctx)
        key, val = value.split("=", 1)
        try:
            ConfigKey(key)
        except ValueError:
            self.fail(f"Invalid key {key!r}. Valid keys: {_KEYS_LIST}", param, ctx)
        return key, val


@cli.group("config")
def config_group() -> None:
    """Manage dbnl SDK configuration."""
    pass


@config_group.command()
def show() -> None:
    """Display the current configuration."""
    data = config.read_file()
    if not data:
        raise ClickException("No configuration file found.")
    masked = {}
    for k, v in data.items():
        if k == ConfigKey.api_token and isinstance(v, str) and len(v) > 4:
            masked[k] = "***" + v[-4:]
        else:
            masked[k] = v
    click.echo(json.dumps(masked, indent=2))


@config_group.command(help=f"Set configuration values (KEY=VALUE ...).\n{_KEYS_HELP_BLOCK}")
@click.argument("pairs", nargs=-1, required=True, type=ConfigPairType())
def set(pairs: tuple[tuple[str, str], ...]) -> None:
    data = config.read_file()
    data.update(pairs)
    config.write_file(data)
    click.echo("Configuration updated.")


@config_group.command(help=f"Remove configuration keys (KEY ...).\n{_KEYS_HELP_BLOCK}")
@click.argument("keys", nargs=-1, required=True, type=ConfigKeyType())
def unset(keys: tuple[str, ...]) -> None:
    data = config.read_file()
    for key in keys:
        data.pop(key, None)
    config.write_file(data)
    click.echo("Configuration updated.")


@config_group.command()
def clear() -> None:
    """Delete the configuration file."""
    config.delete_file()
    config.reset()
    click.echo("Configuration cleared.")


@config_group.command()
def validate() -> None:
    """Validate configuration against the API."""
    try:
        core_login(verify=True)
    except DBNLError as exc:
        raise ClickException(str(exc)) from exc
    click.echo("Configuration is valid.")


@cli.command()
@login_required
def info() -> None:
    """Info about SDK and API."""
    spec = get_spec()
    info = {
        "sdk": {
            "version": __version__,
        },
        "api": {
            "version": spec["info"]["version"],
            "url": config.api_url(),
        },
    }
    click.echo(yaml.dump(info, sort_keys=False))


@cli.group()
def sandbox() -> None:
    """Subcommand to interact with the sandbox."""
    pass


class NotEmpty(click.ParamType):
    """A parameter type that is not empty."""

    name = "not_empty"

    def convert(self, value: str, param: click.Parameter | None, ctx: click.Context | None) -> str:
        if not value:
            if param is None:
                self.fail("Parameter must not be empty")
            self.fail(f"{param.name} must not be empty", param=param)
        return value


def _format_size(n: int, suffix: str = "") -> str:
    size = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if abs(size) < 1024:
            return f"{size:.0f}{suffix} {unit}" if unit == "B" else f"{size:.1f}{suffix} {unit}"
        size /= 1024
    return f"{size:.1f}{suffix} TB"


@sandbox.command()
@click.option("-u", "--registry-username", help="Registry username")
@click.option("-p", "--registry-password", hide_input=True, help="Registry password", type=NotEmpty())
@click.option("--registry", help="Registry")
@click.option("--version", default=default_version(), help="Sandbox version", show_default=True)
@click.option("--base-url", default=default_base_url(), help="Sandbox base url", show_default=True)
@click.option("-q", "--quiet", is_flag=True, help="Suppress pull progress output")
def start(
    registry_username: str | None,
    registry_password: str | None,
    registry: str | None,
    version: str,
    base_url: str,
    quiet: bool,
) -> None:
    """Start the sandbox."""
    if registry is None:
        registry = default_registry(version)

    def on_progress(
        completed_layers: int, total_layers: int, downloaded_bytes: int, total_bytes: int, all_sizes_known: bool
    ) -> None:
        if total_bytes > 0:
            total_str = _format_size(total_bytes, suffix="+" if not all_sizes_known else "")
            size_str = f", {_format_size(downloaded_bytes)} / {total_str}"
        else:
            size_str = ""
        msg = f"Pulling image: {completed_layers}/{total_layers} layers{size_str}"
        click.echo(f"\r{msg:<60}", nl=False)

    def on_wait_progress(message: str) -> None:
        click.echo(f"\r{message:<60}", nl=False)

    try:
        metadata = sandbox_start(
            registry_username,
            registry_password,
            registry,
            version,
            base_url,
            on_progress=None if quiet else on_progress,
            on_wait_progress=None if quiet else on_wait_progress,
        )
    except SandboxError as exc:
        if not quiet:
            click.echo()
        raise ClickException(exc.message) from exc
    if not quiet:
        click.echo()
    click.echo("Sandbox is ready. To see logs run: dbnl sandbox logs")
    if metadata.get("url"):
        click.echo(f"  {'URL:':<11}{metadata['url']}")
    if metadata.get("username"):
        click.echo(f"  {'Username:':<11}{metadata['username']}")
    if metadata.get("password"):
        click.echo(f"  {'Password:':<11}{metadata['password']}")


@sandbox.command()
@click.option(
    "--service",
    help="Tail service logs.",
    type=Choice(["sandbox", "api", "scheduler", "ui", "worker"]),
    default="sandbox",
)
def logs(service: str) -> None:
    """Tail the logs for the sandbox or a specific service."""
    try:
        if service == "sandbox":
            sandbox_logs()
        else:
            component = f"{service}-srv" if service != "worker" else "worker-default-srv"
            sandbox_exec(["kubectl", "logs", "-f", "-l", f"app.kubernetes.io/component={component}"])
    except SandboxError as exc:
        raise ClickException(exc.message) from exc


@sandbox.command()
@click.argument("command", nargs=-1)
def exec(command: tuple[str, ...]) -> None:
    """Exec a command on the sandbox."""
    try:
        sandbox_exec(list(command))
    except SandboxError as exc:
        raise ClickException(exc.message) from exc


@sandbox.command()
def stop() -> None:
    """Stop the sandbox."""
    try:
        sandbox_stop()
    except SandboxError as exc:
        raise ClickException(exc.message) from exc
    click.echo("Sandbox stopped.")


@sandbox.command()
def status() -> None:
    """Get sandbox status."""
    try:
        click.echo(sandbox_status())
    except SandboxError as exc:
        raise ClickException(exc.message) from exc


@sandbox.command()
@click.option("--force", "-f", is_flag=True, help="Force delete")
def delete(force: bool) -> None:
    """Delete sandbox data."""
    if not force:
        click.confirm("Are you sure you want to delete the sandbox data?", abort=True)
    try:
        sandbox_delete()
    except SandboxError as exc:
        raise ClickException(exc.message) from exc
    click.echo("Sandbox data deleted.")


if __name__ == "__main__":
    cli()
