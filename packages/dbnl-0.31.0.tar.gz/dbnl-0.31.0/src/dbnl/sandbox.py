import json
import re
import signal
import sys
import time
from collections.abc import Callable
from types import FrameType
from typing import Any, Literal, Optional, TypeAlias

# Can't use types-docker since it requires urllib2 which is incompatible with boto3 for Python 3.9.
import docker  # type: ignore[import-untyped]
from docker import DockerClient
from docker.errors import APIError, DockerException, NotFound  # type: ignore[import-untyped]

Container = Any
Volume = Any

from dbnl import __version__
from dbnl.errors import DBNLError

CONTAINER_NAME = "dbnl-sandbox"
VOLUME_NAME = "dbnl-sandbox"
IMAGE_NAME = "sandbox-srv"
LEGACY_REGISTRY = "us-docker.pkg.dev/dbnlai/images"
DEFAULT_REGISTRY = "ghcr.io/dbnlai/images"
DEFAULT_BASE_URL = "http://localhost:8080"
DEFAULT_REGISTRY_USERNAME = "_json_key_base64"
DEFAULT_START_TIMEOUT_SECONDS = 600
STARTUP_POLL_INTERVAL_SECONDS = 2


class SandboxError(DBNLError):
    def __init__(self, message: str) -> None:
        self.message = message


class SandboxDockerConnectionError(SandboxError):
    def __init__(self) -> None:
        super().__init__("Failed to connect to Docker. Is Docker running?")


class SandboxAlreadyRunning(SandboxError):
    def __init__(self) -> None:
        super().__init__("Sandbox is already running.")


class SandboxHaltedUnexpectedly(SandboxError):
    def __init__(self) -> None:
        super().__init__("Sandbox has halted unexpectedly.")


class SandboxNotFound(SandboxError):
    def __init__(self) -> None:
        super().__init__("Sandbox was not found.")


class SandboxVolumeNotFound(SandboxError):
    def __init__(self) -> None:
        super().__init__("Sandbox volume was not found.")


def _client() -> DockerClient:
    try:
        return docker.from_env()
    except DockerException as exc:
        raise SandboxDockerConnectionError() from exc


def default_registry(version: str | None) -> str:
    """Returns the default sandbox registry."""
    if version is not None:
        match = re.match(r"^(\d+)\.(\d+)", version)
        assert match is not None, "Version string does not match expected format"
        major, minor = match.groups()
        if int(major) == 0 and int(minor) <= 24:
            return LEGACY_REGISTRY
    return DEFAULT_REGISTRY


def default_version() -> str:
    """Returns the default sandbox version."""
    match = re.match(r"^(\d+)\.(\d+)", __version__)
    assert match is not None, "Version string does not match expected format"
    major, minor = match.groups()
    return f"{major}.{minor}"


def default_base_url() -> str:
    """Returns the default base url."""
    return DEFAULT_BASE_URL


def _container(client: DockerClient) -> Optional["Container"]:
    """Gets the sandbox container if it exists."""
    try:
        return client.containers.get(CONTAINER_NAME)
    except NotFound:
        return None


def _volume(client: DockerClient) -> Optional["Volume"]:
    """Gets the sandbox volume if it exists."""
    try:
        return client.volumes.get(VOLUME_NAME)
    except NotFound:
        return None


def _pull_image(
    client: DockerClient,
    repository: str,
    tag: str,
    on_progress: Callable[[int, int, int, int, bool], None] | None = None,
) -> Any:
    """Pull an image with optional progress reporting.

    on_progress receives (completed_layers, total_layers, downloaded_bytes, known_total_bytes, all_sizes_known).
    """
    total_layers = 0
    completed_layers = 0
    cached_layers = 0
    layer_bytes: dict[str, tuple[int, int]] = {}
    for event in client.api.pull(repository, tag=tag, stream=True, decode=True):
        layer_id = event.get("id")
        status = event.get("status", "")
        detail = event.get("progressDetail", {})
        if not layer_id:
            continue
        if status == "Pulling fs layer":
            total_layers += 1
        elif status == "Already exists":
            total_layers += 1
            completed_layers += 1
            cached_layers += 1
        elif status == "Downloading" and "current" in detail and "total" in detail:
            layer_bytes[layer_id] = (detail["current"], detail["total"])
        elif status == "Download complete" and layer_id in layer_bytes:
            layer_bytes[layer_id] = (layer_bytes[layer_id][1], layer_bytes[layer_id][1])
        elif status == "Pull complete":
            completed_layers += 1
        if on_progress and total_layers > 0:
            downloaded = sum(c for c, _ in layer_bytes.values())
            known_total = sum(t for _, t in layer_bytes.values())
            downloadable = total_layers - cached_layers
            all_sizes_known = len(layer_bytes) >= downloadable
            on_progress(completed_layers, total_layers, downloaded, known_total, all_sizes_known)
    return client.images.get(f"{repository}:{tag}")


def _container_logs(container: "Container", tail: int = 300) -> str:
    logs = container.logs(tail=tail)
    if isinstance(logs, bytes):
        return logs.decode("utf-8", errors="replace")
    return str(logs)


def _wait_for_healthy(
    container: "Container",
    timeout_seconds: int = DEFAULT_START_TIMEOUT_SECONDS,
    on_progress: Callable[[str], None] | None = None,
) -> None:
    start = time.monotonic()
    deadline = start + timeout_seconds
    health = "unknown"

    while time.monotonic() < deadline:
        container.reload()
        status = container.status
        health = container.attrs.get("State", {}).get("Health", {}).get("Status", "unknown")

        if status != "running":
            logs = _container_logs(container)
            raise SandboxError(f"Sandbox container exited with status '{status}'.\n\n{logs}")

        if on_progress is not None:
            elapsed = int(time.monotonic() - start)
            on_progress(f"Waiting for sandbox to be healthy ({elapsed}s, status: {health})")

        if health == "healthy":
            return

        if health == "unhealthy":
            logs = _container_logs(container)
            try:
                container.stop()
                container.remove()
            except Exception as cleanup_exc:
                logs += f"\n\nCleanup failed: {cleanup_exc}"
            raise SandboxError(f"Sandbox container is unhealthy.\n\n{logs}")

        time.sleep(STARTUP_POLL_INTERVAL_SECONDS)

    raise SandboxError(
        f"Timed out waiting for sandbox to become healthy after {timeout_seconds}s (last status: {health})."
    )


METADATA_PATH = "/var/run/dbnl/metadata.json"
MetadataKey: TypeAlias = Literal["url", "username", "password"]
METADATA_KEYS: set[MetadataKey] = {"url", "username", "password"}


def _read_metadata(container: "Container") -> dict[MetadataKey, str]:
    exit_code, output = container.exec_run(["cat", METADATA_PATH])
    if exit_code != 0:
        return {}
    try:
        data = json.loads(output)
    except (json.JSONDecodeError, ValueError):
        return {}
    return {k: v for k, v in data.items() if k in METADATA_KEYS and isinstance(v, str)}


def sandbox_start(
    username: str | None,
    password: str | None,
    registry: str,
    version: str,
    base_url: str,
    on_progress: Callable[[int, int, int, int, bool], None] | None = None,
    on_wait_progress: Callable[[str], None] | None = None,
) -> dict[MetadataKey, str]:
    """Start the sandbox."""
    repository = f"{registry}/{IMAGE_NAME}"

    client = _client()

    existing = _container(client)
    if existing is not None and existing.status == "running":
        raise SandboxAlreadyRunning()

    # If credentials were provided, login.
    if username is not None and password is not None:
        client.login(username=username, password=password, registry=registry)

    image = _pull_image(client, repository, version, on_progress)

    # Check if volume exists.
    volume = _volume(client)
    if volume is None:
        volume = client.volumes.create(VOLUME_NAME)

    # Check if container exists.
    container = _container(client)
    if container is not None:
        if container.status == "running":
            # If container is running, raise an error.
            raise SandboxAlreadyRunning()
        else:
            # Otherwise, remove it.
            container.remove()

    # Start container.
    try:
        container = client.containers.run(
            image=image,
            detach=True,
            ports={"80": 8080},
            name=CONTAINER_NAME,
            privileged=True,
            cgroupns="host",
            tmpfs={"/run": "", "/var/run": ""},
            volumes={volume.name: {"bind": "/var/lib/dbnl", "mode": "rw"}},
        )
    except APIError as exc:
        if exc.status_code == 409:
            raise SandboxAlreadyRunning() from exc
        raise exc

    _wait_for_healthy(container, on_progress=on_wait_progress)
    return _read_metadata(container)


def sandbox_status() -> str:
    """Check sandbox status."""
    client = _client()
    container = _container(client)
    if container is None:
        return "not found"
    return str(container.status)


def sandbox_logs() -> None:
    """Tail the sandbox logs."""
    client = _client()
    container = _container(client)
    if container is None:
        raise SandboxNotFound()

    # Add graceful exit handler to stop container.
    def exit_gracefully(signal: int, frame: FrameType | None) -> None:
        sys.exit(0)

    signal.signal(signal.SIGINT, exit_gracefully)
    signal.signal(signal.SIGTERM, exit_gracefully)

    # Tail logs.
    logs = container.logs(stream=True)
    for line in logs:
        sys.stdout.buffer.write(line)
        sys.stdout.buffer.flush()


def sandbox_exec(command: list[str]) -> None:
    """Exec a command on the sandbox."""
    client = _client()
    container = _container(client)
    if container is None:
        raise SandboxNotFound()

    # Add graceful exit handler to stop container.
    def exit_gracefully(signal: int, frame: FrameType | None) -> None:
        sys.exit(0)

    signal.signal(signal.SIGINT, exit_gracefully)
    signal.signal(signal.SIGTERM, exit_gracefully)

    # Run command.
    (_, output) = container.exec_run(command, stream=True)

    # Tail output.
    for line in output:
        sys.stdout.buffer.write(line)
        sys.stdout.buffer.flush()


def sandbox_stop() -> None:
    """Stop the sandbox."""
    client = _client()
    container = _container(client)
    if container is None:
        # Nothing to do if container is missing.
        return
    container.stop()
    container.remove()


def sandbox_delete() -> None:
    """Delete the sandbox data."""
    client = _client()
    volume = _volume(client)
    if volume is None:
        raise SandboxVolumeNotFound()
    volume.remove()
