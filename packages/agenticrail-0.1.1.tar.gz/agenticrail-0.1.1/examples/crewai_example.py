"""
CrewAI + AgenticRail — full working example.

Demonstrates a 3-task CrewAI crew where every task is gated by AgenticRail
before execution. Uses guard.kickoff() instead of crew.kickoff().

    pip install agenticrail[crewai]
    python crewai_example.py
"""

from crewai import Agent, Task, Crew, Process
from agenticrail import RailClient
from agenticrail.integrations.crewai import CrewRailGuard


# --- AgenticRail setup -------------------------------------------------------

client = RailClient(
    api_key="DEMO-AGENTICRAIL-PUBLIC-2026",
    model_id="crewai-example",
)

STEP_ORDER = ["research_task", "analysis_task", "write_task"]

guard = CrewRailGuard(client, step_order=STEP_ORDER)


# --- Agents ------------------------------------------------------------------

researcher = Agent(
    role="Research Specialist",
    goal="Find accurate information about the given topic",
    backstory="Expert researcher with access to academic databases",
    verbose=True,
)

analyst = Agent(
    role="Data Analyst",
    goal="Extract key insights from research findings",
    backstory="Expert at identifying patterns and drawing conclusions",
    verbose=True,
)

writer = Agent(
    role="Technical Writer",
    goal="Produce clear, accurate reports",
    backstory="Experienced at translating complex analysis into plain language",
    verbose=True,
)


# --- Tasks -------------------------------------------------------------------

research_task = Task(
    description="Research the current state of {topic}. Summarize 3 key findings.",
    expected_output="Three bullet points summarizing key research findings",
    agent=researcher,
)

analysis_task = Task(
    description="Analyze the research findings and identify the most important trend.",
    expected_output="One paragraph identifying the most significant trend and why it matters",
    agent=analyst,
)

write_task = Task(
    description="Write a concise executive summary based on the analysis.",
    expected_output="A 2-paragraph executive summary suitable for a non-technical audience",
    agent=writer,
)


# --- Crew & gated kickoff ----------------------------------------------------

crew = Crew(
    agents=[researcher, analyst, writer],
    tasks=[research_task, analysis_task, write_task],
    process=Process.sequential,
    verbose=True,
)

if __name__ == "__main__":
    print("Running gated CrewAI workflow...")
    print("guard.kickoff() gates each task via AgenticRail before execution.\n")

    result = guard.kickoff(crew, inputs={"topic": "AI agent governance frameworks"})

    print(f"\nCrew output:\n{result}")
    print("\nAll tasks executed with ALLOW — sequence sealed.")


# --- Alternative: explicit gating in a custom loop ---------------------------
#
# If you control task execution directly (e.g. a custom orchestration loop),
# use guard.gate() for hard blocking:
#
#   guard.reset()
#   for step, task_fn in zip(STEP_ORDER, [run_research, run_analysis, run_write]):
#       guard.gate(step)      # raises RailDenied if gate returns DENY/HALT
#       task_fn()
