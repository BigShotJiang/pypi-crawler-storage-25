"""
LangGraph + AgenticRail — full working example.

Demonstrates a 4-node LangGraph graph where every node is gated by AgenticRail
before execution. Run with the demo key — no account needed.

    pip install agenticrail[langgraph]
    python langgraph_example.py
"""

from typing import TypedDict
from langgraph.graph import StateGraph, END
from agenticrail import RailClient
from agenticrail.integrations.langgraph import LangGraphRail


# --- State -------------------------------------------------------------------

class AgentState(TypedDict):
    topic: str
    research: str
    analysis: str
    report: str


# --- Node functions (your actual logic lives here) ---------------------------

def _research(state: AgentState) -> AgentState:
    print(f"  [research] Researching: {state['topic']}")
    return {"research": f"Found 3 sources on {state['topic']}"}


def _analyze(state: AgentState) -> AgentState:
    print(f"  [analyze] Analyzing research...")
    return {"analysis": f"Key finding: {state['research']} shows clear pattern"}


def _write_report(state: AgentState) -> AgentState:
    print("  [write] Drafting report...")
    return {"report": f"Report on {state['topic']}: {state['analysis']}"}


def _review(state: AgentState) -> AgentState:
    print("  [review] Reviewing final report...")
    return {}  # no state change — just a gate checkpoint


# --- AgenticRail setup -------------------------------------------------------

client = RailClient(
    api_key="DEMO-AGENTICRAIL-PUBLIC-2026",
    model_id="langgraph-example",
)

STEP_ORDER = ["research", "analyze", "write_report", "review"]

rail = LangGraphRail(client, step_order=STEP_ORDER)


# --- Build graph -------------------------------------------------------------

builder = StateGraph(AgentState)

builder.add_node("research",    rail.wrap("research",    _research))
builder.add_node("analyze",     rail.wrap("analyze",     _analyze))
builder.add_node("write_report",rail.wrap("write_report",_write_report))
builder.add_node("review",      rail.wrap("review",      _review))

builder.set_entry_point("research")
builder.add_edge("research",    "analyze")
builder.add_edge("analyze",     "write_report")
builder.add_edge("write_report","review")
builder.add_edge("review",      END)

graph = builder.compile()


# --- Run it ------------------------------------------------------------------

if __name__ == "__main__":
    print("Running gated LangGraph workflow...")
    print("Each node calls AgenticRail before executing.\n")

    result = graph.invoke(
        {"topic": "EU AI Act enforcement deadlines"},
        config={"configurable": {"thread_id": "example-run-001"}},
    )

    print(f"\nFinal report:\n{result['report']}")
    print("\nAll nodes executed with ALLOW decisions — sequence sealed at 'review'.")
