"""CrewAI integration for AgenticRail."""

from __future__ import annotations

import uuid
from typing import Any, List, Optional

from agenticrail.client import RailClient, RailDenied


class CrewRailGuard:
    """
    Guards a CrewAI Crew by calling the AgenticRail gate before each task executes.

    Usage:
        from agenticrail import RailClient
        from agenticrail.integrations.crewai import CrewRailGuard

        client = RailClient(api_key="YOUR_KEY")
        guard = CrewRailGuard(
            client,
            step_order=["research_task", "analysis_task", "write_task"],
        )

        crew = Crew(
            agents=[researcher, analyst, writer],
            tasks=[research_task, analysis_task, write_task],
        )

        # Call guard.kickoff() instead of crew.kickoff()
        result = guard.kickoff(crew, inputs={"topic": "EU AI Act enforcement"})

    How it works:
        1. guard.kickoff() gates step[0] before crew starts. Raises RailDenied on DENY.
        2. A task_callback is injected into the crew. After each task completes, the
           callback gates the NEXT step before CrewAI moves to it. If the gate denies,
           a flag is set and a RailDenied is raised after kickoff returns.
        3. The sequence is sealed when all tasks complete (the step_order's last step
           is evaluated at the start of the last task).

    Note on timing:
        CrewAI's task_callback fires synchronously between tasks. However, if CrewAI
        swallows the exception from task_callback, the denied task may still execute.
        In that case, guard.kickoff() raises RailDenied after crew.kickoff() returns,
        preserving the gate decision in the audit trail even if execution wasn't blocked.

        For hard blocking, wrap task execution directly via guard.gate() before each
        task in a custom orchestration loop (see examples/crewai_example.py).

    New sequence per run:
        Each call to guard.kickoff() generates a fresh sequence_id unless you pass
        sequence_id= explicitly. This ensures each crew run is independently tracked.
    """

    def __init__(
        self,
        client: RailClient,
        step_order: List[str],
        *,
        sequence_id: Optional[str] = None,
        action_type: str = "CHECK_STATE",
    ):
        self._client = client
        self.step_order = step_order
        self._action_type = action_type
        self._fixed_sequence_id = sequence_id
        # Runtime state (reset on each kickoff)
        self._sequence_id: str = ""
        self._step_idx: int = 0
        self._denied: Optional[RailDenied] = None

    def _gate(self, step_name: str) -> None:
        # step_order sent on every call — gate reads it from each payload
        self._client.evaluate(
            self._sequence_id,
            step_name,
            action_type=self._action_type,
            action=f"execute {step_name}",
            step_order=self.step_order,
            raise_on_deny=True,
        )

    def gate(self, step_name: str) -> None:
        """
        Explicitly gate a single step. Use this for custom orchestration loops
        where you control task execution directly.
        """
        if not self._sequence_id:
            self._sequence_id = self._fixed_sequence_id or str(uuid.uuid4())
        self._gate(step_name)
        self._step_idx += 1

    def reset(self, sequence_id: Optional[str] = None) -> None:
        """Reset guard state for a new crew run."""
        self._sequence_id = sequence_id or self._fixed_sequence_id or str(uuid.uuid4())
        self._step_idx = 0
        self._denied = None

    def kickoff(self, crew: Any, **kwargs: Any) -> Any:
        """
        Gate-enabled replacement for crew.kickoff().

        Gates step[0] before the crew starts. Injects a task_callback that gates
        each subsequent step between tasks. Raises RailDenied if any step is denied.
        """
        self.reset()

        # Gate the first step — raises immediately on DENY/HALT
        first_step = self.step_order[self._step_idx]
        self._gate(first_step)
        self._step_idx += 1

        # Capture any existing callback so we can chain it
        existing_callback = getattr(crew, "task_callback", None)

        def _task_callback(task_output: Any) -> None:
            if self._denied:
                return

            # Gate the next step (if any remain)
            if self._step_idx < len(self.step_order):
                next_step = self.step_order[self._step_idx]
                self._step_idx += 1
                try:
                    self._gate(next_step)
                except RailDenied as e:
                    self._denied = e
                    # Cannot reliably stop CrewAI from inside a callback,
                    # but we record the denial and raise after kickoff.

            if existing_callback is not None:
                existing_callback(task_output)

        crew.task_callback = _task_callback

        result = crew.kickoff(**kwargs)

        if self._denied:
            raise self._denied

        return result
