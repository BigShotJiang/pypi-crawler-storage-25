"""LangGraph integration for AgenticRail."""

from __future__ import annotations

import inspect
import uuid
from functools import wraps
from typing import Any, Callable, Dict, List, Optional

from agenticrail.client import RailClient


class LangGraphRail:
    """
    Guards a LangGraph StateGraph by calling the AgenticRail gate before each
    node executes. Each graph invocation gets its own sequence_id derived from
    LangGraph's thread_id, so concurrent runs are isolated.

    Usage:
        from agenticrail import RailClient
        from agenticrail.integrations.langgraph import LangGraphRail

        client = RailClient(api_key="YOUR_KEY")
        rail = LangGraphRail(client, step_order=["research", "analyze", "write"])

        # Wrap your nodes at add_node time
        builder.add_node("research", rail.wrap("research", research_fn))
        builder.add_node("analyze",  rail.wrap("analyze",  analyze_fn))
        builder.add_node("write",    rail.wrap("write",    write_fn))

        graph = builder.compile()

        # thread_id becomes the sequence_id — each run is isolated
        result = graph.invoke(
            {"messages": [...]},
            config={"configurable": {"thread_id": "run-abc-001"}},
        )

    Gate enforcement:
        - ALLOW  → node function executes normally.
        - DENY   → RailDenied raised; LangGraph halts the graph.
        - HALT   → RailDenied raised; LangGraph halts the graph.

    Sequence isolation:
        Each unique thread_id gets its own AgenticRail sequence. If you invoke
        the same graph twice with different thread_ids, both are tracked
        independently. If thread_id is not provided in config, a random UUID is
        used (not recommended — you lose the audit trail correlation).
    """

    def __init__(
        self,
        client: RailClient,
        step_order: List[str],
        *,
        fallback_sequence_id: Optional[str] = None,
    ):
        self._client = client
        self.step_order = step_order
        self._fallback_sequence_id = fallback_sequence_id or str(uuid.uuid4())

    def _resolve_sequence_id(self, config: Any) -> str:
        if config and isinstance(config, dict):
            configurable = config.get("configurable") or {}
            thread_id = (
                configurable.get("thread_id")
                or configurable.get("sequence_id")
            )
            if thread_id:
                return str(thread_id)
        return self._fallback_sequence_id

    def wrap(
        self,
        step_name: str,
        fn: Callable,
        *,
        action_type: str = "CHECK_STATE",
    ) -> Callable:
        """
        Wrap a LangGraph node function with AgenticRail pre-execution gate enforcement.

        Args:
            step_name: Must match the corresponding entry in step_order.
            fn: The original node function (state -> dict, or state, config -> dict).
            action_type: Gate action type (default CHECK_STATE).

        Returns:
            Wrapped node function with identical signature.
        """
        # Check if the original function accepts a config argument
        try:
            sig = inspect.signature(fn)
            _fn_takes_config = len(sig.parameters) > 1
        except (ValueError, TypeError):
            _fn_takes_config = False

        @wraps(fn)
        def guarded(state: Any, config: Any = None) -> Any:
            seq_id = self._resolve_sequence_id(config)
            # step_order sent on every call — gate reads it from each payload
            self._client.evaluate(
                seq_id,
                step_name,
                action_type=action_type,
                action=f"execute {step_name}",
                step_order=self.step_order,
                raise_on_deny=True,
            )

            if _fn_takes_config and config is not None:
                return fn(state, config)
            return fn(state)

        return guarded
