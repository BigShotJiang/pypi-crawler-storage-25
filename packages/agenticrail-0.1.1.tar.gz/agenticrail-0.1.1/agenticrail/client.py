"""AgenticRail gate client — core HTTP implementation."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import List, Optional

import requests


class RailDenied(Exception):
    """Raised when the gate returns DENY or HALT."""

    def __init__(self, decision: str, reasons: List[str], pack_id: str, step: str):
        self.decision = decision
        self.reasons = reasons
        self.pack_id = pack_id
        self.step = step
        super().__init__(f"{decision} at '{step}': {reasons}")


@dataclass
class RailDecision:
    decision: str           # ALLOW | DENY | HALT
    pack_id: str
    reasons: List[str]
    executed: bool
    sequence_id: str
    step: str
    receipt: dict = field(default_factory=dict)

    @property
    def allowed(self) -> bool:
        return self.decision == "ALLOW"


class RailSequence:
    """
    Stateful sequence helper. Tracks step_order and sends it on every call —
    removes boilerplate from multi-step workflows.

    Usage:
        seq = client.sequence("my-seq-001", step_order=["step_a", "step_b", "step_c"])
        seq.next("step_a")
        seq.next("step_b")
        seq.next("step_c")  # seals sequence
    """

    def __init__(self, client: "RailClient", sequence_id: str, step_order: List[str]):
        self._client = client
        self.sequence_id = sequence_id
        self.step_order = step_order

    def next(
        self,
        step: str,
        *,
        action_type: str = "CHECK_STATE",
        action: Optional[str] = None,
        inputs: Optional[dict] = None,
        raise_on_deny: bool = True,
    ) -> RailDecision:
        # step_order must be sent on every call — the gate reads it from each
        # payload to resolve the step index; it does not persist it server-side.
        return self._client.evaluate(
            self.sequence_id,
            step,
            action_type=action_type,
            action=action,
            inputs=inputs,
            step_order=self.step_order,
            raise_on_deny=raise_on_deny,
        )


class RailClient:
    """
    Thin client for the AgenticRail gate API.

    Usage:
        client = RailClient(api_key="DEMO-AGENTICRAIL-PUBLIC-2026")

        # Direct calls — manage step_order yourself
        client.evaluate("seq-001", "verify_identity", step_order=[...])
        client.evaluate("seq-001", "assess_risk")

        # Or use RailSequence helper
        seq = client.sequence("seq-001", step_order=["verify_identity", "assess_risk"])
        seq.next("verify_identity")
        seq.next("assess_risk")
    """

    DEFAULT_BASE_URL = "https://api.agenticrail.nz/v1/evaluate"

    def __init__(
        self,
        api_key: str,
        *,
        model_id: str = "agent",
        base_url: Optional[str] = None,
        timeout: int = 10,
    ):
        self.api_key = api_key
        self.model_id = model_id
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

    def evaluate(
        self,
        sequence_id: str,
        step: str,
        *,
        action_type: str = "CHECK_STATE",
        action: Optional[str] = None,
        inputs: Optional[dict] = None,
        step_order: Optional[List[str]] = None,
        raise_on_deny: bool = True,
    ) -> RailDecision:
        """
        Evaluate one step of a sequence against the AgenticRail gate.

        Args:
            sequence_id: Unique identifier for this agent run.
            step: Step name (must equal function; must match step_order).
            action_type: One of CHECK_STATE, VALIDATE_INPUT, RECORD_RESULT, etc.
            action: Human-readable action label (defaults to step name).
            inputs: Arbitrary metadata attached to this step.
            step_order: Full ordered list of step names — required on every call.
            raise_on_deny: If True (default), raise RailDenied on DENY or HALT.

        Returns:
            RailDecision with decision, pack_id, receipt, and reasons.

        Raises:
            RailDenied: If decision is DENY or HALT and raise_on_deny is True.
            requests.HTTPError: On non-2xx HTTP responses.
        """
        payload: dict = {
            "schema_version": "1.0",
            "model_id": self.model_id,
            "sequence_id": sequence_id,
            "step": step,
            "function": step,
            "action_type": action_type,
            "action": action if action is not None else step,
            "inputs": inputs or {},
            "nonce": str(uuid.uuid4()),
            "ts_ms": int(time.time() * 1000),
        }
        if step_order is not None:
            payload["step_order"] = step_order

        resp = requests.post(
            self.base_url,
            json=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        data = resp.json()

        decision = RailDecision(
            decision=data["decision"],
            pack_id=data.get("pack_id", ""),
            reasons=data.get("reasons", []),
            executed=data.get("executed", False),
            sequence_id=data.get("sequence_id", sequence_id),
            step=data.get("step", step),
            receipt=data.get("receipt", {}),
        )

        if raise_on_deny and not decision.allowed:
            raise RailDenied(decision.decision, decision.reasons, decision.pack_id, step)

        return decision

    def sequence(self, sequence_id: str, step_order: List[str]) -> RailSequence:
        """Create a stateful sequence helper that manages step_order automatically."""
        return RailSequence(self, sequence_id, step_order)
