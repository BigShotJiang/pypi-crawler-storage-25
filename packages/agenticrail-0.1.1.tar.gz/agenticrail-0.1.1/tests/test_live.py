"""
Live integration tests — hits the real demo API.
No mocking. Proves the SDK actually works end-to-end.

    cd sdks/python
    python -m tests.test_live
"""

import sys
import uuid
sys.path.insert(0, ".")

from agenticrail import RailClient, RailDenied

client = RailClient(api_key="DEMO-AGENTICRAIL-PUBLIC-2026", model_id="sdk-test")
STEPS = ["verify_identity", "assess_risk", "execute_action", "audit_ledger"]

passed = 0
failed = 0


def check(label, cond, detail=""):
    global passed, failed
    if cond:
        print(f"  PASS {label}")
        passed += 1
    else:
        print(f"  FAIL {label}" + (f": {detail}" if detail else ""))
        failed += 1


def run(label, fn):
    print(f"\n{label}")
    try:
        fn()
    except Exception as e:
        global failed
        print(f"  FAIL CRASHED: {e}")
        failed += 1


# ---------------------------------------------------------------------------

def test_happy_path():
    seq = client.sequence(f"sdk-test-{uuid.uuid4()}", STEPS)
    decisions = []
    for step in STEPS:
        d = seq.next(step)
        decisions.append(d)

    check("all steps ALLOW", all(d.allowed for d in decisions))
    check("all pack_ids present", all(d.pack_id for d in decisions))
    check("sequence_id consistent", len({d.sequence_id for d in decisions}) == 1)
    check("steps returned match sent", [d.step for d in decisions] == STEPS)


def test_step_order_every_call():
    seq_id = f"sdk-test-{uuid.uuid4()}"
    seq = client.sequence(seq_id, STEPS)

    d0 = seq.next("verify_identity")
    check("first call: ALLOW", d0.allowed)

    # step_order is sent on every call (gate reads it from each payload)
    d1 = seq.next("assess_risk")
    check("second call: ALLOW", d1.allowed)


def test_sequence_violation():
    seq_id = f"sdk-test-{uuid.uuid4()}"
    seq = client.sequence(seq_id, STEPS)
    seq.next("verify_identity")

    try:
        seq.next("execute_action")  # skips assess_risk
        check("SEQUENCE_VIOLATION raised", False, "no exception raised")
    except RailDenied as e:
        check("SEQUENCE_VIOLATION raised", True)
        check("decision is DENY", e.decision == "DENY", e.decision)
        check("reason is SEQUENCE_VIOLATION", "SEQUENCE_VIOLATION" in e.reasons, str(e.reasons))
        check("pack_id present", bool(e.pack_id))
        check("step name correct", e.step == "execute_action", e.step)


def test_sealed_sequence():
    seq_id = f"sdk-test-{uuid.uuid4()}"
    seq = client.sequence(seq_id, STEPS)
    for step in STEPS:
        seq.next(step)

    try:
        seq.next("verify_identity")  # re-entry after seal
        check("SEALED_SEQUENCE raised", False, "no exception raised")
    except RailDenied as e:
        check("SEALED_SEQUENCE raised", True)
        check("reason is SEALED_SEQUENCE", "SEALED_SEQUENCE" in e.reasons, str(e.reasons))


def test_raise_on_deny_false():
    seq_id = f"sdk-test-{uuid.uuid4()}"
    client.evaluate(seq_id, "verify_identity", step_order=STEPS)

    # Wrong order, but don't raise — still need step_order on every call
    d = client.evaluate(seq_id, "execute_action", step_order=STEPS, raise_on_deny=False)
    check("DENY returned (not raised)", not d.allowed)
    check("reason present", len(d.reasons) > 0, str(d.reasons))


def test_direct_evaluate():
    seq_id = f"sdk-test-{uuid.uuid4()}"
    d = client.evaluate(
        seq_id,
        "verify_identity",
        action_type="VALIDATE_INPUT",
        action="check user credentials",
        inputs={"user_id": "u123", "region": "EU"},
        step_order=STEPS,
    )
    check("direct evaluate ALLOW", d.allowed)
    check("action_type accepted", d.allowed)  # server would DENY if invalid


# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("AgenticRail Python SDK — live integration tests")
    print(f"API: {client.base_url}\n")

    run("1. Happy path — full sequence", test_happy_path)
    run("2. step_order sent on every call", test_step_order_every_call)
    run("3. Sequence violation (skip step)", test_sequence_violation)
    run("4. Sealed sequence (re-entry blocked)", test_sealed_sequence)
    run("5. raise_on_deny=False returns decision", test_raise_on_deny_false)
    run("6. Direct evaluate with all options", test_direct_evaluate)

    print(f"\n{'-'*40}")
    print(f"  {passed} passed  |  {failed} failed")
    print(f"{'-'*40}")
    sys.exit(0 if failed == 0 else 1)
