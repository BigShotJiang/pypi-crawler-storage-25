"""Singleton WalletStore lifecycle management.

Extracted from core.py so that all wallet sub-managers can import
``_get_store`` and ``_save_store`` without importing the Wallet class.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from fluxwallet.config import DEFAULT_WALLET_FILE, TPM_AUTH_FILE
from fluxwallet.wallet_file import store_key_in_keyring, try_auto_unlock, unwrap_master_key
from fluxwallet.wallet_store import WalletStore

if TYPE_CHECKING:
    from collections.abc import Callable

_logger = logging.getLogger(__name__)


class _StoreManager:
    """Manages the singleton WalletStore lifecycle."""

    def __init__(self) -> None:
        self.store: WalletStore | None = None
        self.password: str | None = None
        self.master_key: bytes | None = None
        self.path: Path | None = None
        self.key_file: str | None = None
        self.tpm_auth_file: str | None = TPM_AUTH_FILE or None
        self.password_prompt: Callable[[], str] | None = None
        self.new_password_prompt: Callable[[], str] | None = None

    async def get(self) -> WalletStore:
        if self.store is not None:
            return self.store

        self.store = WalletStore()
        path = self.path or DEFAULT_WALLET_FILE
        if not Path(path).exists():
            self.path = Path(path)
            return self.store

        # Try auto-unlock once; prompt for password if it fails
        auto_mk = try_auto_unlock(str(path), key_file=self.key_file)
        if auto_mk is None and not self.password and self.password_prompt:
            self.password = self.password_prompt()

        def _load() -> None:
            if self.store is None:
                raise RuntimeError("Store not initialized")
            mk = auto_mk
            if mk:
                self.master_key = mk
                self.store.load(str(path), master_key=mk)
                self.path = Path(path)
                return

            # Slow path: unwrap master key from password (~200ms Argon2id, releases GIL)
            if self.password:
                mk = unwrap_master_key(str(path), self.password)
                self.master_key = mk
                self.store.load(str(path), master_key=mk)
                store_key_in_keyring(mk.hex())
                self.path = Path(path)

        await asyncio.to_thread(_load)
        return self.store

    async def save(self) -> None:
        if not self.store or not self.store.dirty:
            return

        path = self.store._file_path or (str(self.path) if self.path else None)
        if not path:
            return

        if not self.master_key and not self.password:
            prompt = self.new_password_prompt or self.password_prompt
            if prompt:
                self.password = prompt()

        def _save() -> None:
            if self.store is None:
                raise RuntimeError("Store not initialized")
            if self.master_key:
                self.store.save_with_key(self.master_key, path=path)
            elif self.password:
                mk = self.store.save(self.password, path=path)
                self.master_key = mk
                store_key_in_keyring(mk.hex())

        await asyncio.to_thread(_save)

    def configure(self, path: Path | str, password: str) -> None:
        self.path = Path(path)
        self.password = password
        self.store = None

    def reset(self) -> None:
        if self.store:
            self.store.wipe()
        self.store = None
        self.password = None
        self.master_key = None
        self.path = None


_mgr = _StoreManager()


async def _get_store() -> WalletStore:
    """Return the singleton WalletStore, loading from disk if needed."""
    return await _mgr.get()


async def _save_store() -> None:
    """Persist the WalletStore to disk if dirty."""
    await _mgr.save()
