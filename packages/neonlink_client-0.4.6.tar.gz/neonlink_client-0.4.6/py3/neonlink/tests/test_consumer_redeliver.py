"""Tests for the BUG-PLD-008 fix: handler exception must rewind the consume
cursor so the next poll() re-serves the failed record on the same
topic/partition. confluent-kafka-python advances its internal fetch position on
every poll regardless of broker-side commit state, so without an explicit
Consumer.seek(TopicPartition(topic, partition, offset)) rewind the failed
record is orphaned in-process until restart or rebalance — the exact symptom
the bug-log §15 captured (one "will redeliver" log followed by 9+h of silence).

Mirrors mcfo-neonlink/pkg/neonlink/consumer_redeliver_test.go (Go SDK).

All tests build a Consumer via object.__new__ + manual field init (mirroring
test_commit_fenced_for_revoked_partition in test_consumer_post_remediation.py)
so the tests exercise _handle_processing_error / _rewind_for_redelivery
without spinning a real broker. Test hooks (_rewind_seek_fn,
_transient_backoff_fn, _sleep_fn) are overridden to capture the rewind
decision.
"""

from __future__ import annotations

import threading
from typing import Optional

import pytest
from confluent_kafka import KafkaException

from neonlink.consumer import Consumer, _FailureTracker
from neonlink.metrics import NoopMetrics
from neonlink.record import Record


class _FakeMessage:
    """Minimal Message stub matching the surface used by _commit / poll."""

    def __init__(self, topic: str = "topic-a", partition: int = 0, offset: int = 7) -> None:
        self._topic = topic
        self._partition = partition
        self._offset = offset

    def topic(self) -> str:
        return self._topic

    def partition(self) -> int:
        return self._partition

    def offset(self) -> int:
        return self._offset

    def error(self):
        return None


class _RewindRecorder:
    """Captures every _rewind_seek_fn call so tests can assert on the exact
    (topic, partition, offset) tuple passed to confluent-kafka seek."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, int, int]] = []
        self._lock = threading.Lock()

    def __call__(self, topic: str, partition: int, offset: int) -> None:
        with self._lock:
            self.calls.append((topic, partition, offset))


class _CountingMetrics(NoopMetrics):
    """Counts ConsumerRedeliver / DLQRouted / PoisonPillDetected /
    PoisonPillBlocked calls; everything else inherited as no-op."""

    def __init__(self) -> None:
        self.redeliver = 0
        self.dlq_routed_count = 0
        self.poison_detected_count = 0
        self.poison_blocked_count = 0

    def consumer_redeliver(self, topic: str, partition: int) -> None:
        self.redeliver += 1

    def dlq_routed(self, original_topic: str, err: Exception) -> None:
        self.dlq_routed_count += 1

    def poison_pill_detected(self, topic: str, partition: int, offset: int) -> None:
        self.poison_detected_count += 1

    def poison_pill_blocked(self, topic: str, partition: int, offset: int) -> None:
        self.poison_blocked_count += 1


class _DLQCapture:
    """Mirrors the Publisher protocol; counts publish calls; can be set to fail."""

    def __init__(self) -> None:
        self.records: list[dict] = []
        self.fail_with: Optional[Exception] = None

    def publish(self, topic: str, key=None, value=None, headers=None) -> None:
        if self.fail_with is not None:
            raise self.fail_with
        self.records.append({"topic": topic, "headers": dict(headers or {})})


class _StubCfg:
    """Minimal Config stub for fields _handle_processing_error reads."""

    def __init__(self, threshold: int = 5) -> None:
        self.poison_pill_threshold = threshold
        self.dlq_topic = "errors-dlq"
        self.consumer_group = "test-group"
        self.retry_initial_wait_ms = 1
        self.retry_max_wait_ms = 5


def _new_test_consumer(threshold: int = 5) -> Consumer:
    """Build a Consumer suitable for direct _handle_processing_error tests:
    no real ConfluentConsumer, default hooks pre-installed (tests override)."""
    c = object.__new__(Consumer)
    c._cfg = _StubCfg(threshold=threshold)
    c._tracker = _FailureTracker()
    c._metrics = NoopMetrics()
    c._dlq_producer = None
    c._revoked_partitions = set()
    c._revoked_lock = threading.Lock()
    c._stop_event = threading.Event()
    c._cancel_event = None
    # Default hooks: tests override these.
    c._rewind_seek_fn = lambda topic, partition, offset: None
    c._transient_backoff_fn = lambda attempt: 0.0
    c._sleep_fn = lambda d: True
    return c


def _make_record(topic: str = "topic-a", partition: int = 3, offset: int = 7) -> Record:
    return Record(topic=topic, partition=partition, offset=offset, headers={})


# ---------------------------------------------------------------------------
# Transient handler exception → rewind cursor
# ---------------------------------------------------------------------------

def test_redeliver_seeks_to_failed_offset_on_transient_exception():
    """BUG-PLD-008 contract: a transient handler exception below the poison
    threshold MUST call seek(TopicPartition(...)) to rewind the consume cursor
    to the failed offset. Pre-fix, _handle_processing_error only logged
    "will redeliver" and returned, so the next poll() fetched the next offset
    and the failed record was orphaned in-process."""
    c = _new_test_consumer(threshold=5)
    rec = _RewindRecorder()
    c._rewind_seek_fn = rec
    metrics = _CountingMetrics()
    c._metrics = metrics

    record = _make_record(topic="topic-a", partition=3, offset=7)
    msg = _FakeMessage(topic="topic-a", partition=3, offset=7)

    c._handle_processing_error(record, msg, RuntimeError("transient"))

    assert rec.calls == [("topic-a", 3, 7)], (
        f"expected exactly one seek to (topic-a, 3, 7); got {rec.calls}"
    )
    assert metrics.redeliver == 1, f"expected ConsumerRedeliver=1; got {metrics.redeliver}"


def test_redeliver_honors_revoke_fence():
    """Revoked partition MUST NOT be seeked — confluent-kafka raises on seek
    of a non-assigned partition, and after revoke the partition belongs to
    another consumer."""
    c = _new_test_consumer(threshold=5)
    rec = _RewindRecorder()
    c._rewind_seek_fn = rec
    c._revoked_partitions.add("topic-a:3")

    record = _make_record(topic="topic-a", partition=3, offset=7)
    msg = _FakeMessage(topic="topic-a", partition=3, offset=7)

    c._handle_processing_error(record, msg, RuntimeError("transient"))

    assert rec.calls == [], "revoked partition must not be seeked"


def test_redeliver_aborts_on_stop_during_backoff():
    """Backoff MUST respect stop signals. If the consumer is asked to stop
    during backoff, no seek must follow — preventing a stale seek call after
    consumer shutdown."""
    c = _new_test_consumer(threshold=5)
    rec = _RewindRecorder()
    c._rewind_seek_fn = rec
    c._transient_backoff_fn = lambda attempt: 0.5
    c._sleep_fn = lambda d: False  # signals "stop requested during sleep"

    record = _make_record(offset=7)
    msg = _FakeMessage(offset=7)

    c._handle_processing_error(record, msg, RuntimeError("transient"))

    assert rec.calls == [], "no seek when sleep returns False (stop)"


def test_redeliver_applies_bounded_backoff_with_attempt_count():
    """The configured exponential backoff must be applied with the effective
    retry count (max of header retry_count vs in-memory tracker)."""
    c = _new_test_consumer(threshold=10)
    c._rewind_seek_fn = lambda *args: None

    observed_attempts: list[int] = []
    observed_sleeps: list[float] = []

    c._transient_backoff_fn = lambda attempt: (observed_attempts.append(attempt), 0.07)[1]
    c._sleep_fn = lambda d: (observed_sleeps.append(d), True)[1]

    record = _make_record(offset=1)
    record.set_header("retry_count", "2")
    msg = _FakeMessage(offset=1)

    c._handle_processing_error(record, msg, RuntimeError("transient"))

    # effective_retry_count = max(header=2, tracker=1) = 2
    assert observed_attempts == [2], f"expected backoff attempt=2, got {observed_attempts}"
    assert observed_sleeps == [0.07], f"expected sleep=0.07s, got {observed_sleeps}"


def test_redeliver_failure_tracker_increments_per_retry():
    """Repeated failures on the same offset increment the in-memory tracker."""
    c = _new_test_consumer(threshold=10)
    c._rewind_seek_fn = lambda *args: None
    attempts: list[int] = []
    c._transient_backoff_fn = lambda attempt: (attempts.append(attempt), 0)[1]

    record = _make_record(offset=5)
    msg = _FakeMessage(offset=5)

    for _ in range(3):
        c._handle_processing_error(record, msg, RuntimeError("transient"))

    assert attempts == [1, 2, 3], f"expected attempts [1,2,3], got {attempts}"


# ---------------------------------------------------------------------------
# Poison threshold + DLQ semantics
# ---------------------------------------------------------------------------

def test_poison_routes_to_dlq_and_attempts_commit():
    """Poison threshold reached → DLQ publish → commit attempt. Without a real
    confluent consumer, _commit raises AttributeError on .commit() — which
    we rely on to assert the safety-net rewind engages on commit failure."""
    c = _new_test_consumer(threshold=3)
    dlq = _DLQCapture()
    c._dlq_producer = dlq
    metrics = _CountingMetrics()
    c._metrics = metrics
    rec = _RewindRecorder()
    c._rewind_seek_fn = rec

    # Stub commit() to fail so the safety-net rewind engages (no live broker).
    # _commit only retries on KafkaException — use that so the bounded retry
    # exhausts and returns False, triggering the post-DLQ rewind safety net.
    class _StubFailingConsumer:
        def commit(self, message=None, asynchronous=False):
            raise KafkaException("no broker in test")

    c._consumer = _StubFailingConsumer()

    record = _make_record(offset=5)
    record.set_header("retry_count", "3")  # at threshold
    msg = _FakeMessage(offset=5)

    c._handle_processing_error(record, msg, RuntimeError("terminal"))

    assert len(dlq.records) == 1, f"expected DLQ count=1, got {len(dlq.records)}"
    assert metrics.dlq_routed_count == 1
    assert metrics.poison_detected_count == 1
    # Commit failed (no real broker) → safety-net rewind engaged.
    assert rec.calls == [("topic-a", 3, 5)], (
        f"expected commit-failure safety-net seek to (topic-a, 3, 5); got {rec.calls}"
    )


def test_dlq_publish_failure_rewinds_no_commit():
    """DLQ publish error MUST NOT commit. The fix replaces the silent return
    with an explicit cursor rewind so the next poll re-serves and retries DLQ."""
    c = _new_test_consumer(threshold=3)
    dlq = _DLQCapture()
    dlq.fail_with = RuntimeError("dlq publish broken")
    c._dlq_producer = dlq
    metrics = _CountingMetrics()
    c._metrics = metrics
    rec = _RewindRecorder()
    c._rewind_seek_fn = rec

    record = _make_record(offset=9)
    record.set_header("retry_count", "3")
    msg = _FakeMessage(offset=9)

    c._handle_processing_error(record, msg, RuntimeError("terminal"))

    assert len(dlq.records) == 0, "DLQ must not have recorded the failed publish"
    assert metrics.dlq_routed_count == 0
    assert rec.calls == [("topic-a", 3, 9)], (
        f"expected rewind to (topic-a, 3, 9) after DLQ failure; got {rec.calls}"
    )


def test_poison_without_dlq_rewinds():
    """Poison + no DLQ configured MUST rewind instead of silently orphaning.
    Operator sees CRITICAL log on every poll until DLQ is configured."""
    c = _new_test_consumer(threshold=3)
    c._dlq_producer = None
    metrics = _CountingMetrics()
    c._metrics = metrics
    rec = _RewindRecorder()
    c._rewind_seek_fn = rec

    record = _make_record(offset=4)
    record.set_header("retry_count", "3")
    msg = _FakeMessage(offset=4)

    c._handle_processing_error(record, msg, RuntimeError("terminal"))

    assert metrics.poison_blocked_count == 1
    assert rec.calls == [("topic-a", 3, 4)], (
        f"expected rewind to (topic-a, 3, 4) on no-DLQ poison; got {rec.calls}"
    )


# ---------------------------------------------------------------------------
# Default hook installation
# ---------------------------------------------------------------------------

def test_consumer_init_installs_default_rewind_hooks(monkeypatch):
    """Constructor MUST install default _rewind_seek_fn / _transient_backoff_fn
    / _sleep_fn. A None default would silently revert the BUG-PLD-008 fix."""
    from neonlink.config import Config

    # Avoid touching a real broker by stubbing ConfluentConsumer.
    class _StubConfluentConsumer:
        def __init__(self, *args, **kwargs):
            pass

    monkeypatch.setattr("neonlink.consumer.ConfluentConsumer", _StubConfluentConsumer)

    cfg = Config(brokers=["localhost:9092"], consumer_group="test-group")
    c = Consumer(cfg, ["topic-a"])
    assert c._rewind_seek_fn is not None, "rewind hook missing — BUG-PLD-008 fix gone"
    assert c._transient_backoff_fn is not None
    assert c._sleep_fn is not None


def test_seek_failure_does_not_silently_succeed():
    """If seek raises (e.g. KafkaException), the error must be logged and
    no ConsumerRedeliver counter increment must happen — regression sensor
    for 'silent seek failure' which would orphan the record again."""
    c = _new_test_consumer(threshold=5)
    metrics = _CountingMetrics()
    c._metrics = metrics

    def _raising_seek(topic: str, partition: int, offset: int) -> None:
        raise RuntimeError("seek failed: partition not assigned")

    c._rewind_seek_fn = _raising_seek

    record = _make_record(offset=7)
    msg = _FakeMessage(offset=7)

    c._handle_processing_error(record, msg, RuntimeError("transient"))

    assert metrics.redeliver == 0, "must not bump redeliver counter when seek failed"


# Pytest will fail the suite if any of these returns the wrong type.
@pytest.mark.parametrize("offset", [0, 1, 999_999_999])
def test_seek_passes_exact_offset(offset: int):
    c = _new_test_consumer(threshold=5)
    rec = _RewindRecorder()
    c._rewind_seek_fn = rec

    record = _make_record(offset=offset)
    msg = _FakeMessage(offset=offset)
    c._handle_processing_error(record, msg, RuntimeError("transient"))
    assert rec.calls == [("topic-a", 3, offset)]
