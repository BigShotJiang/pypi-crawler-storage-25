from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum


class Severity(IntEnum):
    INFO = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

    @classmethod
    def from_str(cls, value: str) -> "Severity":
        try:
            return cls[value.upper()]
        except KeyError:
            valid = ", ".join(m.name for m in cls)
            raise ValueError(f"Invalid severity '{value}'. Valid values: {valid}")

    def label(self) -> str:
        return self.name


@dataclass
class Finding:
    file: str
    line: int | None
    rule: str
    severity: Severity
    message: str
    remediation: str
    scanner: str
    owasp: str | None = field(default=None)

    def dedup_key(self) -> tuple:
        return (self.file, self.line, self.rule, self.scanner)
