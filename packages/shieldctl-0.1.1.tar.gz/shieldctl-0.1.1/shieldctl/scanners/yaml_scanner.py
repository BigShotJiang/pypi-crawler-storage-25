from __future__ import annotations

import re
import shutil
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity

# yamllint parsable format: "path:line:col: [level] message (rule)"
_PARSABLE = re.compile(r"^(?P<file>.+):(?P<line>\d+):\d+: \[(?P<level>\w+)\] (?P<msg>.+?) \((?P<rule>[^)]+)\)$")

_LEVEL_MAP = {
    "error": Severity.MEDIUM,
    "warning": Severity.LOW,
}

# Path component sets that warrant checkov YAML scanning (path-based)
_CHECKOV_YAML_COMPONENT_SETS = [
    {".github", "workflows"},
    {"k8s"},
    {"kubernetes"},
    {"helm"},
]

# Content-based fingerprints
_K8S_RE = re.compile(r"^apiVersion\s*:", re.MULTILINE)
_KIND_RE = re.compile(r"^kind\s*:", re.MULTILINE)
_GHA_ON_RE = re.compile(r"^(?:on|'on'|\"on\")\s*:", re.MULTILINE)
_GHA_JOBS_RE = re.compile(r"^jobs\s*:", re.MULTILINE)


def _is_checkov_target(path: Path) -> bool:
    """Path-based: path contains k8s/, kubernetes/, .github/workflows/, or helm/."""
    parts = set(path.parts)
    if any(required <= parts for required in _CHECKOV_YAML_COMPONENT_SETS):
        return True
    # Content-based fallback
    try:
        text = path.read_text(errors="replace")
        if _K8S_RE.search(text) and _KIND_RE.search(text):
            return True
        if _GHA_ON_RE.search(text) and _GHA_JOBS_RE.search(text):
            return True
    except OSError:
        pass
    return False


class YamlScanner(BaseScanner):
    extensions = [".yml", ".yaml"]

    def _primary_tool(self) -> str:
        return "yamllint"

    def _is_checkov_target(self, path: Path) -> bool:
        return _is_checkov_target(path)

    def run(self, paths: list[Path]) -> list[Finding]:
        out: list[Finding] = []
        for path in paths:
            out.extend(self._yamllint(path))
            if _is_checkov_target(path) and shutil.which("checkov"):
                out.extend(self._checkov_yaml(path))
        return out

    def _yamllint(self, path: Path) -> list[Finding]:
        result = self._exec(["yamllint", "-f", "parsable", str(path)])
        findings: list[Finding] = []
        for line in (result.stdout + result.stderr).splitlines():
            m = _PARSABLE.match(line)
            if not m:
                continue
            level = m.group("level").lower()
            sev = _LEVEL_MAP.get(level, Severity.LOW)
            findings.append(Finding(
                file=m.group("file"),
                line=int(m.group("line")),
                rule=f"yamllint:{m.group('rule')}",
                severity=sev,
                message=m.group("msg"),
                remediation=f"https://yamllint.readthedocs.io/en/stable/rules.html#{m.group('rule').replace('-', '_')}",
                scanner="yamllint",
            ))
        return findings

    def _checkov_yaml(self, path: Path) -> list[Finding]:
        import json
        result = self._exec([
            "checkov", "-f", str(path), "-o", "json", "--compact", "--quiet",
        ])
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        if isinstance(data, list):
            checks: list = []
            for block in data:
                checks.extend(block.get("results", {}).get("failed_checks", []))
        else:
            checks = data.get("results", {}).get("failed_checks", [])

        out: list[Finding] = []
        for c in checks:
            line: int | None = None
            flr = c.get("file_line_range")
            if flr:
                line = flr[0]
            check_id = c.get("check_id", "UNKNOWN")
            description = (
                c.get("description")
                or c.get("short_description")
                or f"Policy check: {check_id}"
            )
            out.append(Finding(
                file=c.get("file_path", str(path)),
                line=line,
                rule=check_id,
                severity=Severity.MEDIUM,
                message=description,
                remediation=c.get("guideline", ""),
                scanner="checkov-yaml",
                owasp="A05:2021 – Security Misconfiguration",
            ))
        return out
