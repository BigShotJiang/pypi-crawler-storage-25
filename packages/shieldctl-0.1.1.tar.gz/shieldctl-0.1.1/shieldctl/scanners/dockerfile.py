from __future__ import annotations

import json
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity

_LEVEL_MAP = {
    "error": Severity.HIGH,
    "warning": Severity.MEDIUM,
    "info": Severity.LOW,
    "style": Severity.INFO,
}


class DockerfileScanner(BaseScanner):
    # Match "Dockerfile", "Dockerfile.prod", etc.
    extensions = [".dockerfile", "Dockerfile"]

    def _primary_tool(self) -> str:
        return "hadolint"

    def available(self) -> bool:
        import shutil
        return shutil.which("hadolint") is not None

    def run(self, paths: list[Path]) -> list[Finding]:
        # extensions list contains "Dockerfile" as a bare name — dispatcher may not catch all variants
        # so also match any file named Dockerfile* from passed paths
        targets = [
            p for p in paths
            if p.name.startswith("Dockerfile") or p.suffix == ".dockerfile"
        ]
        out: list[Finding] = []
        for path in targets:
            out.extend(self._hadolint(path))
        return out

    def _hadolint(self, path: Path) -> list[Finding]:
        result = self._exec(["hadolint", "--format", "json", str(path)])
        try:
            issues = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        findings: list[Finding] = []
        for issue in issues:
            level = issue.get("level", "warning").lower()
            sev = _LEVEL_MAP.get(level, Severity.MEDIUM)
            code = issue.get("code", "DL0000")
            findings.append(Finding(
                file=issue.get("file", str(path)),
                line=issue.get("line"),
                rule=code,
                severity=sev,
                message=issue.get("message", ""),
                remediation=f"https://github.com/hadolint/hadolint/wiki/{code}",
                scanner="hadolint",
            ))
        return findings
