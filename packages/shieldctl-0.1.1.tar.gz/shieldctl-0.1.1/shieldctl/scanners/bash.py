from __future__ import annotations

import json
import re
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity

_LEVEL_MAP = {
    "error": Severity.HIGH,
    "warning": Severity.MEDIUM,
    "info": Severity.LOW,
    "style": Severity.INFO,
}

# ── Custom shell security rules ───────────────────────────────────────────────

# SH-001: curl/wget piped directly to a shell interpreter (supply chain risk)
_SH001_RE = re.compile(
    r"\b(curl|wget)\b[^|]*\|\s*(sudo\s+)?(bash|sh|zsh|ash|python[23]?|perl|ruby)\b"
)

# SH-002: Hardcoded credential assignment (PASSWORD=, TOKEN=, SECRET=, API_KEY=, etc.)
_SH002_RE = re.compile(
    r"(?i)\b(password|passwd|token|secret|api_key|apikey|access_key|private_key)\s*=\s*['\"][^'\"]{4,}['\"]"
)

# SH-003: eval with a variable operand (eval "$cmd", eval `...`, eval $(...))
_SH003_RE = re.compile(r'\beval\s+["\']?\$')

# SH-004: Script does not contain 'set -e' (or -eu, -euo, set -euo pipefail, etc.)
_SET_E_RE = re.compile(r"\bset\s+[^#\n]*-[a-zA-Z]*e")

# SH-005: Dangerous rm -rf with a variable path
_SH005_RE = re.compile(r"\brm\s+(-[rfRF]{1,4}\s+){0,3}\$[({]?\w")

# SH-006: chmod 777 (world-writable permission)
_SH006_RE = re.compile(r"\bchmod\s+.*\b777\b")

_CUSTOM_RULES: list[tuple[str, re.Pattern, str, Severity, str]] = [
    (
        "SH-001",
        _SH001_RE,
        "Script downloads and pipes directly to a shell — supply chain risk",
        Severity.HIGH,
        "Download to a file, verify checksum, then execute.",
    ),
    (
        "SH-002",
        _SH002_RE,
        "Hardcoded credential found in shell script",
        Severity.HIGH,
        "Load secrets from environment variables or a secret manager, never hardcode them.",
    ),
    (
        "SH-003",
        _SH003_RE,
        "eval with dynamic input is a command-injection risk",
        Severity.MEDIUM,
        "Avoid eval; use arrays, functions, or case statements instead.",
    ),
    (
        "SH-004",
        None,  # checked differently — absence of set -e
        "Script missing 'set -euo pipefail' — errors may silently propagate",
        Severity.LOW,
        "Add 'set -euo pipefail' near the top of the script.",
    ),
    (
        "SH-005",
        _SH005_RE,
        "rm -rf with a variable path — accidental deletion risk",
        Severity.MEDIUM,
        "Validate the path is non-empty and within expected bounds before deletion.",
    ),
    (
        "SH-006",
        _SH006_RE,
        "chmod 777 grants world-writable permissions — least privilege violation",
        Severity.MEDIUM,
        "Use the minimum required permissions (e.g. 755 for executables, 644 for files).",
    ),
]


class BashScanner(BaseScanner):
    extensions = [".sh"]

    def _primary_tool(self) -> str:
        return "shellcheck"

    def run(self, paths: list[Path]) -> list[Finding]:
        out: list[Finding] = []
        for path in paths:
            out.extend(self._scan_file(path))
            out.extend(self._custom_check(path))
        return out

    def _scan_file(self, path: Path) -> list[Finding]:
        result = self._exec(["shellcheck", "-f", "json", str(path)])
        try:
            issues = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        findings: list[Finding] = []
        for issue in issues:
            level = issue.get("level", "warning").lower()
            sev = _LEVEL_MAP.get(level, Severity.MEDIUM)
            code_val = issue.get("code")
            code = f"SC{code_val}" if code_val is not None else "SC-UNKNOWN"
            findings.append(Finding(
                file=str(path),
                line=issue.get("line"),
                rule=code,
                severity=sev,
                message=issue.get("message", ""),
                remediation=f"https://www.shellcheck.net/wiki/{code}",
                scanner="shellcheck",
            ))
        return findings

    def _custom_check(self, path: Path) -> list[Finding]:
        try:
            text = path.read_text(errors="replace")
        except OSError:
            return []

        findings: list[Finding] = []

        for rule_id, pattern, message, severity, remediation in _CUSTOM_RULES:
            if rule_id == "SH-004":
                # Fire if 'set -e' variant is absent AND the file has at least one command
                if text.strip() and not _SET_E_RE.search(text):
                    findings.append(Finding(
                        file=str(path),
                        line=1,
                        rule=rule_id,
                        severity=severity,
                        message=message,
                        remediation=remediation,
                        scanner="shieldctl-bash",
                    ))
                continue

            for m in pattern.finditer(text):
                line_no = text[: m.start()].count("\n") + 1
                findings.append(Finding(
                    file=str(path),
                    line=line_no,
                    rule=rule_id,
                    severity=severity,
                    message=message,
                    remediation=remediation,
                    scanner="shieldctl-bash",
                ))

        return findings
