from __future__ import annotations

import shutil
import subprocess
from abc import ABC, abstractmethod
from pathlib import Path

from ..models import Finding


class ScannerError(Exception):
    pass


class BaseScanner(ABC):
    # File extensions this scanner handles. Empty list = repo-wide (run once).
    extensions: list[str] = []

    @abstractmethod
    def run(self, paths: list[Path]) -> list[Finding]:
        ...

    def _exec(self, cmd: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
        tool = cmd[0]
        if not shutil.which(tool):
            raise ScannerError(
                f"Tool '{tool}' not found in PATH. "
                f"Install it or use --use-docker (not yet implemented)."
            )
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=cwd,
        )

    def available(self) -> bool:
        tool = self._primary_tool()
        return tool is not None and shutil.which(tool) is not None

    def _primary_tool(self) -> str | None:
        return None
