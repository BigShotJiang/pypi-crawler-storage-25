from __future__ import annotations

import json
import re
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity

# Minimal K8s content fingerprint: needs both apiVersion and kind keys
_K8S_RE = re.compile(r"^apiVersion\s*:", re.MULTILINE)
_KIND_RE = re.compile(r"^kind\s*:", re.MULTILINE)


def _is_k8s_manifest(path: Path) -> bool:
    try:
        text = path.read_text(errors="replace")
        return bool(_K8S_RE.search(text) and _KIND_RE.search(text))
    except OSError:
        return False


class KubernetesScanner(BaseScanner):
    extensions = [".yml", ".yaml"]

    def _primary_tool(self) -> str:
        return "checkov"

    def run(self, paths: list[Path]) -> list[Finding]:
        targets = [p for p in paths if _is_k8s_manifest(p)]
        out: list[Finding] = []
        for path in targets:
            out.extend(self._checkov(path))
        return out

    def _checkov(self, path: Path) -> list[Finding]:
        result = self._exec([
            "checkov", "-f", str(path),
            "--framework", "kubernetes",
            "-o", "json", "--compact", "--quiet",
        ])
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        if isinstance(data, list):
            checks: list = []
            for block in data:
                checks.extend(block.get("results", {}).get("failed_checks", []))
        else:
            checks = data.get("results", {}).get("failed_checks", [])

        findings: list[Finding] = []
        for c in checks:
            line: int | None = None
            flr = c.get("file_line_range")
            if flr:
                line = flr[0]
            check_id = c.get("check_id", "UNKNOWN")
            description = (
                c.get("description")
                or c.get("short_description")
                or f"Policy check: {check_id}"
            )
            findings.append(Finding(
                file=c.get("file_path", str(path)),
                line=line,
                rule=check_id,
                severity=Severity.MEDIUM,
                message=description,
                remediation=c.get("guideline", ""),
                scanner="checkov-k8s",
                owasp="A05:2021 – Security Misconfiguration",
            ))
        return findings
