from __future__ import annotations

import json
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity


class PipAuditScanner(BaseScanner):
    # Repo-wide scanner — runs once against the environment / requirements files.
    extensions: list[str] = []

    def _primary_tool(self) -> str:
        return "pip-audit"

    def run(self, paths: list[Path]) -> list[Finding]:
        # paths will be [root] from the dispatcher (repo-wide mode).
        root = paths[0] if paths else Path(".")
        return self._pip_audit(root)

    def _pip_audit(self, root: Path) -> list[Finding]:
        result = self._exec(["pip-audit", "--format", "json"], cwd=root)
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            # pip-audit may write findings to stderr on error
            try:
                data = json.loads(result.stderr)
            except json.JSONDecodeError:
                return []

        # pip-audit JSON: list of {name, version, vulns: [{id, aliases, description, fix_versions}]}
        findings: list[Finding] = []
        for pkg_entry in data if isinstance(data, list) else data.get("dependencies", []):
            name = pkg_entry.get("name", "unknown")
            version = pkg_entry.get("version", "?")
            for vuln in pkg_entry.get("vulns", []):
                vid = vuln.get("id", "UNKNOWN")
                aliases = vuln.get("aliases", [])
                description = vuln.get("description", "")
                fix_versions = vuln.get("fix_versions", [])
                rule = vid
                # Prefer CVE alias if present
                for alias in aliases:
                    if alias.startswith("CVE-"):
                        rule = alias
                        break

                fix_note = (
                    f"Upgrade to {', '.join(fix_versions)}."
                    if fix_versions
                    else "No fixed version available — consider an alternative package."
                )
                findings.append(Finding(
                    file="requirements",
                    line=None,
                    rule=f"pip-audit:{vid}",
                    severity=Severity.HIGH,
                    message=f"{name}=={version}: {description[:120]}",
                    remediation=fix_note,
                    scanner="pip-audit",
                    owasp="A06:2021 – Vulnerable and Outdated Components",
                ))
        return findings
