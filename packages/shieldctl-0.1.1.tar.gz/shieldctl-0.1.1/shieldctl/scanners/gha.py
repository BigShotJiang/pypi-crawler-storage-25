from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity

# GHA workflow fingerprint: needs 'on:' (or 'on' key) and 'jobs:' at root
_ON_RE = re.compile(r"^(?:on|'on'|\"on\")\s*:", re.MULTILINE)
_JOBS_RE = re.compile(r"^jobs\s*:", re.MULTILINE)

# actionlint severity mapping
_ACTIONLINT_SEV: dict[str, Severity] = {
    "error": Severity.HIGH,
    "warning": Severity.MEDIUM,
}


def _is_gha_workflow(path: Path) -> bool:
    try:
        text = path.read_text(errors="replace")
        return bool(_ON_RE.search(text) and _JOBS_RE.search(text))
    except OSError:
        return False


class GhaScanner(BaseScanner):
    extensions = [".yml", ".yaml"]

    def _primary_tool(self) -> str:
        return "actionlint"

    def run(self, paths: list[Path]) -> list[Finding]:
        targets = [p for p in paths if _is_gha_workflow(p)]
        out: list[Finding] = []
        for path in targets:
            if shutil.which("actionlint"):
                out.extend(self._actionlint(path))
            if shutil.which("checkov"):
                out.extend(self._checkov(path))
        return out

    def _actionlint(self, path: Path) -> list[Finding]:
        result = self._exec(["actionlint", "-format", "{{json .}}", str(path)])
        try:
            issues = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        findings: list[Finding] = []
        for issue in issues or []:
            kind = (issue.get("kind") or "error").lower()
            sev = _ACTIONLINT_SEV.get(kind, Severity.MEDIUM)
            pos = issue.get("line") or (issue.get("filepath") and None)
            rule_id = issue.get("kind", "actionlint")
            findings.append(Finding(
                file=str(path),
                line=pos,
                rule=f"actionlint:{rule_id}",
                severity=sev,
                message=issue.get("message", ""),
                remediation="https://rhysd.github.io/actionlint/",
                scanner="actionlint",
                owasp="A05:2021 – Security Misconfiguration",
            ))
        return findings

    def _checkov(self, path: Path) -> list[Finding]:
        result = self._exec([
            "checkov", "-f", str(path),
            "--framework", "github_actions",
            "-o", "json", "--compact", "--quiet",
        ])
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        if isinstance(data, list):
            checks: list = []
            for block in data:
                checks.extend(block.get("results", {}).get("failed_checks", []))
        else:
            checks = data.get("results", {}).get("failed_checks", [])

        findings: list[Finding] = []
        for c in checks:
            line: int | None = None
            flr = c.get("file_line_range")
            if flr:
                line = flr[0]
            check_id = c.get("check_id", "UNKNOWN")
            description = (
                c.get("description")
                or c.get("short_description")
                or f"Policy check: {check_id}"
            )
            findings.append(Finding(
                file=c.get("file_path", str(path)),
                line=line,
                rule=check_id,
                severity=Severity.MEDIUM,
                message=description,
                remediation=c.get("guideline", ""),
                scanner="checkov-gha",
                owasp="A05:2021 – Security Misconfiguration",
            ))
        return findings
