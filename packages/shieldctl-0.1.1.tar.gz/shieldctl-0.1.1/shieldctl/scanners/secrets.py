from __future__ import annotations

import json
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity


class SecretsScanner(BaseScanner):
    # Empty = repo-wide; dispatcher passes root
    extensions = []

    def _primary_tool(self) -> str:
        return "gitleaks"

    def run(self, paths: list[Path]) -> list[Finding]:
        # paths[0] is always the repo root when extensions=[]
        root = paths[0]
        result = self._exec([
            "gitleaks", "detect",
            "--source", str(root),
            "--report-format", "json",
            "--report-path", "-",
            "--no-banner",
            "--exit-code", "0",  # don't let gitleaks control our exit
        ])

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        if not data:
            return []

        out: list[Finding] = []
        for leak in data:
            out.append(Finding(
                file=leak.get("File", ""),
                line=leak.get("StartLine"),
                rule=leak.get("RuleID", "secret-detected"),
                severity=Severity.CRITICAL,
                message=f"{leak.get('Description', 'Secret detected')} — [REDACTED — see file:line]",
                remediation="Remove the secret, rotate the credential, and use a secrets manager (GCP Secret Manager).",
                scanner="gitleaks",
                owasp="A02:2021 – Cryptographic Failures",
            ))
        return out
