from __future__ import annotations

import json
import shutil
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity

_BANDIT_SEV = {
    "HIGH": Severity.HIGH,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
}


class PythonScanner(BaseScanner):
    extensions = [".py"]

    def _primary_tool(self) -> str:
        return "bandit"

    def run(self, paths: list[Path]) -> list[Finding]:
        out: list[Finding] = []
        # Bandit works best on directories; group files by parent and run once per unique dir
        dirs = {p.parent for p in paths}
        for d in dirs:
            out.extend(self._bandit(d))
        if shutil.which("safety"):
            out.extend(self._safety())
        return out

    def _bandit(self, directory: Path) -> list[Finding]:
        exclude = ",".join([
            ".venv", "venv", "env", ".env",
            "node_modules", "__pycache__", "*.egg-info",
            ".terraform", ".terragrunt-cache", "dist", "build",
        ])
        result = self._exec([
            "bandit", "-r", str(directory), "-f", "json", "-q",
            "--exclude", exclude,
        ], cwd=directory)
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        findings: list[Finding] = []
        for issue in data.get("results", []):
            sev_str = issue.get("issue_severity", "MEDIUM").upper()
            sev = _BANDIT_SEV.get(sev_str, Severity.MEDIUM)
            findings.append(Finding(
                file=issue.get("filename", ""),
                line=issue.get("line_number"),
                rule=issue.get("test_id", "B000"),
                severity=sev,
                message=issue.get("issue_text", ""),
                remediation=issue.get("more_info", ""),
                scanner="bandit",
                owasp="A03:2021 – Injection",
            ))
        return findings

    def _safety(self) -> list[Finding]:
        result = self._exec(["safety", "check", "--json"])
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        # safety JSON format varies by version; handle both
        vulnerabilities = []
        if isinstance(data, list):
            vulnerabilities = data
        elif isinstance(data, dict):
            vulnerabilities = data.get("vulnerabilities", [])

        findings: list[Finding] = []
        for vuln in vulnerabilities:
            if isinstance(vuln, list):
                # legacy format: [package, spec, installed_ver, description, vuln_id]
                pkg = vuln[0] if len(vuln) > 0 else "unknown"
                desc = vuln[3] if len(vuln) > 3 else ""
                vid = vuln[4] if len(vuln) > 4 else "UNKNOWN"
            else:
                pkg = vuln.get("package_name", "unknown")
                desc = vuln.get("advisory", "")
                vid = vuln.get("vulnerability_id", "UNKNOWN")

            findings.append(Finding(
                file="requirements.txt",
                line=None,
                rule=f"safety:{vid}",
                severity=Severity.HIGH,
                message=f"{pkg}: {desc[:120]}",
                remediation="Update the package to a version without this vulnerability.",
                scanner="safety",
                owasp="A06:2021 – Vulnerable and Outdated Components",
            ))
        return findings
