from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

from .base import BaseScanner
from ..models import Finding, Severity

_CHECKOV_SEV = {
    "CRITICAL": Severity.CRITICAL,
    "HIGH": Severity.HIGH,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
    "INFO": Severity.INFO,
}

_TFSEC_SEV = {
    "CRITICAL": Severity.CRITICAL,
    "HIGH": Severity.HIGH,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
}

_OWASP = "A05:2021 – Security Misconfiguration"

# checkov returns null for description/short_description on many checks
_CHECK_DESCRIPTIONS: dict[str, str] = {
    # Terraform module hygiene
    "CKV_TF_1": "Ensure Terraform module sources use a commit hash (not a branch/tag)",
    "CKV_TF_2": "Ensure Terraform module sources use a commit hash in the registry",
    # Compute instances
    "CKV_GCP_32": "Ensure 'Block Project-wide SSH keys' is enabled for VM instances",
    "CKV_GCP_33": "Ensure OS login is enabled for a project",
    "CKV_GCP_34": "Ensure that no instance overrides the project setting for OS Login",
    "CKV_GCP_35": "Ensure 'Enable connecting to serial ports' is not enabled for VM instances",
    "CKV_GCP_36": "Ensure that IP forwarding is not enabled on instances",
    "CKV_GCP_37": "Ensure VM disks are encrypted with customer-supplied keys (CSEK)",
    "CKV_GCP_38": "Ensure VM disks are encrypted with customer-managed keys (CMEK)",
    "CKV_GCP_39": "Ensure Compute instances are launched with Shielded VM enabled",
    "CKV_GCP_40": "Ensure that Compute instances do not have public IP addresses",
    # Networking
    "CKV_GCP_3": "Ensure project is not using the default network",
    "CKV_GCP_25": "Ensure VPC flow logs are enabled for every subnet",
    "CKV_GCP_26": "Ensure that private Google access is enabled for subnets",
    "CKV_GCP_29": "Ensure no 'open' (0.0.0.0/0) egress/ingress firewall rules exist",
    "CKV_GCP_30": "Ensure firewall rule does not allow all traffic on all ports",
    "CKV_GCP_74": "Ensure that private_ip_google_access is enabled for Subnet",
    "CKV_GCP_76": "Ensure that Private Google access is enabled for IPv6",
    "CKV_GCP_77": "Ensure that no HTTPS or SSL proxy load balancers permit SSL policies with weak cipher suites",
    # DNS
    "CKV_GCP_16": "Ensure that DNSSEC is enabled for Cloud DNS",
    "CKV_GCP_17": "Ensure that RSASHA1 is not used for the key-signing key in Cloud DNS DNSSEC",
    "CKV_GCP_18": "Ensure that RSASHA1 is not used for the zone-signing key in Cloud DNS DNSSEC",
    # IAM
    "CKV_GCP_41": "Ensure that Service Account has no Admin privileges",
    "CKV_GCP_42": "Ensure that Service Account does not have Public/Primitive IAM roles",
    "CKV_GCP_43": "Ensure that Service Account Tokens are not created for non-default service accounts",
    "CKV_GCP_44": "Ensure no roles that grant all resources to any principal",
    "CKV_GCP_45": "Ensure no 'primitive' roles are used in IAM bindings",
    "CKV_GCP_46": "Ensure that Separation of duties is enforced while assigning service account related roles to users",
    "CKV_GCP_47": "Ensure default service account is not used at project level",
    "CKV_GCP_48": "Ensure Audit Logging is enabled for all services",
    "CKV_GCP_49": "Ensure roles do not impersonate service accounts",
    # Cloud Storage
    "CKV_GCP_28": "Ensure that Cloud Storage bucket is not anonymously or publicly accessible",
    "CKV_GCP_62": "Ensure bucket is not publicly accessible via allUsers or allAuthenticatedUsers",
    "CKV_GCP_78": "Ensure Cloud storage bucket is not anonymously or publicly accessible",
    # Logging / Monitoring
    "CKV_GCP_1": "Ensure Stackdriver Logging is enabled",
    "CKV_GCP_2": "Ensure Stackdriver Monitoring is enabled",
    # Cloud SQL
    "CKV_GCP_50": "Ensure MySQL database instances have the 'local_infile' flag set to 'off'",
    "CKV_GCP_51": "Ensure that SQL database instances are not open to the world",
    "CKV_GCP_52": "Ensure that Cloud SQL database instances require all incoming connections to use SSL",
    "CKV_GCP_53": "Ensure that MySQL Database Instances do not allow the root login from any host",
    "CKV_GCP_54": "Ensure that Cloud SQL instances are not publicly exposed",
    "CKV_GCP_55": "Ensure that PostgreSQL database flag 'log_checkpoints' is set to 'on'",
    "CKV_GCP_56": "Ensure that PostgreSQL database flag 'log_connections' is set to 'on'",
    "CKV_GCP_57": "Ensure that PostgreSQL database flag 'log_disconnections' is set to 'on'",
    "CKV_GCP_58": "Ensure that PostgreSQL database flag 'log_lock_waits' is set to 'on'",
    "CKV_GCP_59": "Ensure that PostgreSQL database flag 'log_min_error_statement' is set to 'error' or lower",
    "CKV_GCP_60": "Ensure that Cloud SQL database instances are not open to the world",
    "CKV_GCP_79": "Ensure SQL database is using a current-generation major version",
    # GKE
    "CKV_GCP_61": "Ensure GKE cluster is not using the Compute Engine default service account",
    "CKV_GCP_63": "Ensure GKE cluster is not using a release channel below Regular",
    "CKV_GCP_64": "Ensure private cluster is enabled when creating Kubernetes Clusters",
    "CKV_GCP_65": "Ensure Kubernetes Cluster is created with Alias IP ranges enabled",
    "CKV_GCP_66": "Ensure GKE Node pool is set to auto-upgrade",
    "CKV_GCP_67": "Ensure legacy Authorization is set to Disabled on Kubernetes clusters",
    "CKV_GCP_68": "Ensure Kubernetes Cluster is created with master authorized networks",
    "CKV_GCP_69": "Ensure GKE cluster has network policy enabled",
    "CKV_GCP_70": "Ensure master authorized networks is enabled on GKE clusters",
    "CKV_GCP_71": "Ensure GKE cluster has client certificate authentication enabled to the API server",
    "CKV_GCP_72": "Ensure GKE cluster is not running a vulnerable version of Kubernetes",
    "CKV_GCP_73": "Ensure GKE control plane is not public",
    # Encryption / Privacy
    "CKV_GCP_83": "Ensure GCE disks are encrypted with CMEK",
    "CKV_GCP_84": "Ensure Pub/Sub topic is encrypted with CMEK",
    "CKV_GCP_85": "Ensure Spanner Database is encrypted with CMEK",
    "CKV_GCP_86": "Ensure Cloud Bigtable cluster is encrypted with CMEK",
    "CKV_GCP_87": "Ensure Artifact Registry repository is encrypted with CMEK",
    "CKV_GCP_88": "Ensure Vertex AI dataset is encrypted with CMEK",
    "CKV_GCP_89": "Ensure Cloud Composer environment is encrypted with CMEK",
    "CKV_GCP_90": "Ensure Cloud Run service is encrypted with CMEK",
    "CKV_GCP_91": "Ensure Secret Manager secrets are encrypted with CMEK",
    "CKV_GCP_92": "Ensure Cloud Memorystore Redis is encrypted with CMEK",
    "CKV_GCP_93": "Ensure Filestore instance is encrypted with CMEK",
    "CKV_GCP_94": "Ensure GKE node pool uses a customer-managed encryption key",
    "CKV_GCP_95": "Ensure GKE cluster is encrypted with CMEK",
    # Project-level
    "CKV2_GCP_1": "Ensure GCP project does not have OS login disabled",
}


def _common_ancestor(paths: list[Path]) -> Path:
    """Return the deepest directory that is an ancestor of all paths."""
    dirs = [p.parent if p.is_file() else p for p in paths]
    if not dirs:
        return Path(".")
    resolved = [str(d.resolve()) for d in dirs]
    return Path(os.path.commonpath(resolved))


class TerraformScanner(BaseScanner):
    extensions = [".tf", ".tfvars", "terragrunt.hcl"]

    def _primary_tool(self) -> str:
        return "checkov"

    def run(self, paths: list[Path]) -> list[Finding]:
        root = _common_ancestor(paths)
        findings: list[Finding] = []
        findings.extend(self._run_checkov(root))
        findings.extend(self._run_tfsec(root))
        return findings

    def _run_checkov(self, directory: Path) -> list[Finding]:
        if not shutil.which("checkov"):
            return []

        result = self._exec(
            [
                "checkov", "-d", str(directory),
                "-o", "json", "--compact", "--quiet",
                "--skip-path", ".terragrunt-cache",
                "--skip-path", ".terraform",
            ],
            cwd=directory,
        )

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        # checkov can return a list (one entry per framework) or a single dict
        if isinstance(data, list):
            checks = []
            for block in data:
                checks.extend(block.get("results", {}).get("failed_checks", []))
        else:
            checks = data.get("results", {}).get("failed_checks", [])

        out: list[Finding] = []
        for c in checks:
            file_path = c.get("repo_file_path") or c.get("file_path", "")
            line = None
            file_line_range = c.get("file_line_range")
            if file_line_range:
                line = file_line_range[0]

            sev_str = c.get("severity") or "MEDIUM"
            sev = _CHECKOV_SEV.get(sev_str.upper(), Severity.MEDIUM)

            # Resolve checkov's repo-relative path (e.g. "/main.tf") to absolute
            raw_path = str(file_path)
            if raw_path.startswith("/") and not raw_path.startswith(str(directory)):
                # checkov emits paths relative to the scan root with a leading /
                abs_path = str(directory / Path(raw_path).relative_to("/"))
            else:
                abs_path = raw_path

            check_id = c.get("check_id", "UNKNOWN")
            description = (
                c.get("description")
                or c.get("short_description")
                or _CHECK_DESCRIPTIONS.get(check_id)
                or f"Resource: {c.get('resource', '')}"
            )
            guide = c.get("guideline") or ""
            out.append(Finding(
                file=abs_path,
                line=line,
                rule=check_id,
                severity=sev,
                message=description,
                remediation=guide or f"https://docs.bridgecrew.io/docs/{check_id.lower()}",
                scanner="checkov",
                owasp=_OWASP,
            ))
        return out

    def _run_tfsec(self, directory: Path) -> list[Finding]:
        if not shutil.which("tfsec"):
            return []

        result = self._exec(
            [
                "tfsec", str(directory),
                "--format", "json", "--no-color",
                "--exclude-path", ".terragrunt-cache",
                "--exclude-path", ".terraform",
            ],
        )

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

        results = data.get("results") or []
        out: list[Finding] = []
        for r in results:
            loc = r.get("location", {})
            sev_str = r.get("severity", "MEDIUM")
            sev = _TFSEC_SEV.get(sev_str.upper(), Severity.MEDIUM)
            out.append(Finding(
                file=loc.get("filename", ""),
                line=loc.get("start_line"),
                rule=r.get("rule_id", "UNKNOWN"),
                severity=sev,
                message=r.get("description", ""),
                remediation=r.get("resolution", r.get("links", [""])[0] if r.get("links") else ""),
                scanner="tfsec",
                owasp=_OWASP,
            ))
        return out
