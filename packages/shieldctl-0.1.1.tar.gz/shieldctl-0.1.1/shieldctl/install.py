from __future__ import annotations

import os
import platform
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from rich.console import Console

console = Console()

# Python tools installed via the same pip that installed shieldctl
_PIP_TOOLS: dict[str, str] = {
    "checkov": "checkov",
    "yamllint": "yamllint",
    "bandit": "bandit",
    "safety": "safety",
}

# Brew package name for each binary tool (macOS)
_BREW_PACKAGES: dict[str, str] = {
    "tfsec": "tfsec",
    "shellcheck": "shellcheck",
    "hadolint": "hadolint",
    "gitleaks": "gitleaks",
}

# GitHub release asset patterns per tool and arch (Linux)
# {ver} is replaced with the tag version (without leading 'v' where noted)
_GITHUB_ASSETS: dict[str, dict] = {
    "tfsec": {
        "repo": "aquasecurity/tfsec",
        "amd64": "tfsec-linux-amd64",
        "arm64": "tfsec-linux-arm64",
        "extract": False,
    },
    "shellcheck": {
        "repo": "koalaman/shellcheck",
        "amd64": "shellcheck-{vtag}.linux.x86_64.tar.xz",
        "arm64": "shellcheck-{vtag}.linux.aarch64.tar.xz",
        "extract": True,
        "binary_in_archive": "shellcheck-{vtag}/shellcheck",
    },
    "hadolint": {
        "repo": "hadolint/hadolint",
        "amd64": "hadolint-Linux-x86_64",
        "arm64": "hadolint-Linux-arm64",
        "extract": False,
    },
    "gitleaks": {
        "repo": "gitleaks/gitleaks",
        "amd64": "gitleaks_{ver}_linux_x64.tar.gz",
        "arm64": "gitleaks_{ver}_linux_arm64.tar.gz",
        "extract": True,
        "binary_in_archive": "gitleaks",
    },
}


@dataclass
class InstallResult:
    tool: str
    status: str   # "ok", "skipped", "failed"
    note: str = ""


def _arch() -> str:
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return "amd64"
    if machine in ("aarch64", "arm64"):
        return "arm64"
    return machine


def _pip_executable() -> str:
    # Use the pip that belongs to the current Python (same venv as shieldctl)
    return str(Path(sys.executable).parent / "pip")


def _install_bin_dir() -> Path:
    """Return a writable directory on PATH for binary installs."""
    for candidate in ("/usr/local/bin", str(Path.home() / ".local" / "bin")):
        p = Path(candidate)
        try:
            p.mkdir(parents=True, exist_ok=True)
            # Check writability
            test = p / ".shieldctl_write_test"
            test.touch()
            test.unlink()
            return p
        except (PermissionError, OSError):
            continue
    raise RuntimeError(
        "No writable bin directory found. "
        "Try running with sudo or add ~/.local/bin to your PATH."
    )


def _latest_github_release(repo: str) -> str:
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    req = urllib.request.Request(url, headers={"User-Agent": "shieldctl"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        import json
        data = json.load(resp)
    return data["tag_name"]  # e.g. "v1.2.3"


def _download(url: str, dest: Path) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "shieldctl"})
    with urllib.request.urlopen(req, timeout=60) as resp, dest.open("wb") as f:
        while chunk := resp.read(65536):
            f.write(chunk)


def _install_github_binary(tool: str, dry_run: bool) -> InstallResult:
    spec = _GITHUB_ASSETS[tool]
    arch = _arch()
    if arch not in ("amd64", "arm64"):
        return InstallResult(tool, "failed", f"Unsupported architecture: {arch}")

    try:
        vtag = _latest_github_release(spec["repo"])
    except Exception as e:
        return InstallResult(tool, "failed", f"Could not fetch latest release: {e}")

    ver = vtag.lstrip("v")
    asset_name = spec[arch].format(vtag=vtag, ver=ver)
    download_url = f"https://github.com/{spec['repo']}/releases/download/{vtag}/{asset_name}"

    if dry_run:
        return InstallResult(tool, "ok", f"would download {download_url}")

    try:
        bin_dir = _install_bin_dir()
    except RuntimeError as e:
        return InstallResult(tool, "failed", str(e))

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        download_path = tmp / asset_name
        try:
            _download(download_url, download_path)
        except Exception as e:
            return InstallResult(tool, "failed", f"Download failed: {e}")

        dest = bin_dir / tool

        if spec.get("extract"):
            archive_member = spec.get("binary_in_archive", tool).format(vtag=vtag, ver=ver)
            try:
                if asset_name.endswith(".tar.xz") or asset_name.endswith(".tar.gz"):
                    with tarfile.open(download_path) as tf:
                        member = tf.getmember(archive_member)
                        extracted = tf.extractfile(member)
                        if extracted:
                            dest.write_bytes(extracted.read())
                else:
                    return InstallResult(tool, "failed", f"Unknown archive format: {asset_name}")
            except Exception as e:
                return InstallResult(tool, "failed", f"Extraction failed: {e}")
        else:
            shutil.copy2(download_path, dest)

        dest.chmod(dest.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    return InstallResult(tool, "ok", f"installed to {bin_dir / tool}")


def _install_via_brew(tool: str, pkg: str, dry_run: bool) -> InstallResult:
    if not shutil.which("brew"):
        return InstallResult(tool, "failed", "brew not found")
    if dry_run:
        return InstallResult(tool, "ok", f"would run: brew install {pkg}")
    result = subprocess.run(["brew", "install", pkg], capture_output=True, text=True)
    if result.returncode != 0:
        lines = result.stderr.strip().splitlines()
        return InstallResult(tool, "failed", lines[-1] if lines else "brew error")
    return InstallResult(tool, "ok", f"brew install {pkg}")


def _install_via_pip(tool: str, pkg: str, dry_run: bool) -> InstallResult:
    pip = _pip_executable()
    if dry_run:
        return InstallResult(tool, "ok", f"would run: pip install {pkg}")
    result = subprocess.run([pip, "install", "--quiet", pkg], capture_output=True, text=True)
    if result.returncode != 0:
        lines = result.stderr.strip().splitlines()
        return InstallResult(tool, "failed", lines[-1] if lines else "pip error")
    return InstallResult(tool, "ok", f"pip install {pkg}")


def install_all(dry_run: bool = False) -> list[InstallResult]:
    is_macos = platform.system() == "Darwin"
    results: list[InstallResult] = []

    # Python tools — always via pip
    for tool, pkg in _PIP_TOOLS.items():
        if shutil.which(tool):
            results.append(InstallResult(tool, "skipped", "already installed"))
            continue
        console.print(f"  Installing [bold]{tool}[/bold] via pip...")
        results.append(_install_via_pip(tool, pkg, dry_run))

    # Binary tools
    for tool in _GITHUB_ASSETS:
        if shutil.which(tool):
            results.append(InstallResult(tool, "skipped", "already installed"))
            continue
        console.print(f"  Installing [bold]{tool}[/bold]...")
        if is_macos:
            results.append(_install_via_brew(tool, _BREW_PACKAGES[tool], dry_run))
        else:
            results.append(_install_github_binary(tool, dry_run))

    return results
