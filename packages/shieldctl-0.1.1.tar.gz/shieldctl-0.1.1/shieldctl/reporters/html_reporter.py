from __future__ import annotations

from collections import Counter

from ..models import Finding, Severity

_SEV_COLOR = {
    "CRITICAL": "#ef4444",
    "HIGH": "#f97316",
    "MEDIUM": "#eab308",
    "LOW": "#3b82f6",
    "INFO": "#6b7280",
}

_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>shieldctl report</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Segoe UI',system-ui,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh;padding:2rem}}
  h1{{font-size:1.6rem;font-weight:700;margin-bottom:1.5rem;color:#f8fafc}}
  .cards{{display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:2rem}}
  .card{{background:#1e293b;border-radius:.75rem;padding:1.25rem 1.75rem;min-width:120px;border-top:3px solid var(--c)}}
  .card .num{{font-size:2rem;font-weight:800;color:var(--c)}}
  .card .lbl{{font-size:.8rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em}}
  .controls{{margin-bottom:1rem;display:flex;gap:.75rem;flex-wrap:wrap}}
  input,select{{background:#1e293b;border:1px solid #334155;color:#e2e8f0;padding:.45rem .75rem;border-radius:.5rem;font-size:.875rem}}
  input{{width:280px}}
  table{{width:100%;border-collapse:collapse;font-size:.85rem}}
  thead th{{background:#1e293b;color:#94a3b8;font-weight:600;text-align:left;padding:.6rem .75rem;position:sticky;top:0;cursor:pointer;user-select:none}}
  thead th:hover{{background:#263148}}
  tbody tr{{border-bottom:1px solid #1e293b}}
  tbody tr:hover{{background:#1e293b88}}
  td{{padding:.55rem .75rem;vertical-align:top;word-break:break-word}}
  .badge{{display:inline-block;padding:.15rem .55rem;border-radius:9999px;font-size:.75rem;font-weight:700;color:#fff;background:var(--c)}}
  .empty{{text-align:center;padding:3rem;color:#64748b}}
  .remediation{{font-size:.78rem;color:#64748b;margin-top:.2rem}}
</style>
</head>
<body>
<h1>shieldctl — security scan report</h1>
<div class="cards">
{cards}
</div>
<div class="controls">
  <input type="text" id="search" placeholder="Filter by file, rule, or message…" oninput="filter()">
  <select id="sev-filter" onchange="filter()">
    <option value="">All severities</option>
    <option>CRITICAL</option><option>HIGH</option><option>MEDIUM</option><option>LOW</option><option>INFO</option>
  </select>
  <select id="scanner-filter" onchange="filter()">
    <option value="">All scanners</option>
    {scanner_options}
  </select>
</div>
{table_or_empty}
<script>
const rows = Array.from(document.querySelectorAll('tbody tr'));
function filter(){{
  const q = document.getElementById('search').value.toLowerCase();
  const sev = document.getElementById('sev-filter').value;
  const scn = document.getElementById('scanner-filter').value;
  rows.forEach(r=>{{
    const txt = r.textContent.toLowerCase();
    const ok = (!q||txt.includes(q)) && (!sev||r.dataset.sev===sev) && (!scn||r.dataset.scanner===scn);
    r.style.display = ok ? '' : 'none';
  }});
}}
// basic column sort
document.querySelectorAll('thead th[data-col]').forEach(th=>{{
  th.addEventListener('click',()=>{{
    const col = +th.dataset.col;
    const tbody = document.querySelector('tbody');
    const sorted = [...rows].sort((a,b)=>{{
      const av = a.children[col].textContent.trim();
      const bv = b.children[col].textContent.trim();
      return av.localeCompare(bv);
    }});
    sorted.forEach(r=>tbody.appendChild(r));
  }});
}});
</script>
</body>
</html>
"""

_CARD = '<div class="card" style="--c:{color}"><div class="num">{count}</div><div class="lbl">{label}</div></div>'
_ROW = (
    '<tr data-sev="{sev}" data-scanner="{scanner}">'
    '<td><span class="badge" style="--c:{color}">{sev}</span></td>'
    '<td>{file_line}</td>'
    '<td>{rule}</td>'
    '<td>{scanner}</td>'
    '<td>{message}<div class="remediation">{remediation}</div></td>'
    '</tr>'
)

_TABLE = """\
<div style="overflow-x:auto">
<table id="findings">
<thead><tr>
  <th data-col="0">Severity</th>
  <th data-col="1">File:Line</th>
  <th data-col="2">Rule</th>
  <th data-col="3">Scanner</th>
  <th data-col="4">Message / Remediation</th>
</tr></thead>
<tbody>
{rows}
</tbody>
</table>
</div>"""


class HtmlReporter:
    def render(self, findings: list[Finding]) -> str:
        counts = Counter(f.severity for f in findings)

        cards = "\n".join(
            _CARD.format(color=_SEV_COLOR[sev.label()], count=counts[sev], label=sev.label())
            for sev in reversed(Severity)
        )

        if not findings:
            table_or_empty = '<div class="empty">No findings — clean scan.</div>'
            scanner_options = ""
        else:
            sorted_findings = sorted(findings, key=lambda f: (-f.severity, f.file, f.line or 0))
            scanners = sorted({f.scanner for f in findings})
            scanner_options = "\n".join(f"<option>{s}</option>" for s in scanners)

            rows_html = "\n".join(
                _ROW.format(
                    sev=f.severity.label(),
                    color=_SEV_COLOR[f.severity.label()],
                    file_line=_esc(f"{f.file}:{f.line}" if f.line else f.file),
                    rule=_esc(f.rule),
                    scanner=_esc(f.scanner),
                    message=_esc(f.message),
                    remediation=_esc(f.remediation),
                )
                for f in sorted_findings
            )
            table_or_empty = _TABLE.format(rows=rows_html)

        return _TEMPLATE.format(
            cards=cards,
            scanner_options=scanner_options,
            table_or_empty=table_or_empty,
        )


def _esc(s: str) -> str:
    return (
        str(s)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
