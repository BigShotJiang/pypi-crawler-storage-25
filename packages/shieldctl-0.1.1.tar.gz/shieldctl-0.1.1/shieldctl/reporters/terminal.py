from __future__ import annotations

from collections import Counter

from rich import box
from rich.console import Console
from rich.padding import Padding
from rich.table import Table
from rich.text import Text

from ..models import Finding, Severity

_BADGE: dict[Severity, tuple[str, str]] = {
    Severity.CRITICAL: ("bold white on red",         "CRITICAL"),
    Severity.HIGH:     ("bold white on dark_orange",  "HIGH"),
    Severity.MEDIUM:   ("bold black on yellow",       "MEDIUM"),
    Severity.LOW:      ("bold white on blue",         "LOW"),
    Severity.INFO:     ("bold white on grey50",       "INFO"),
}

_LOC_COLOUR: dict[Severity, str] = {
    Severity.CRITICAL: "red",
    Severity.HIGH:     "dark_orange",
    Severity.MEDIUM:   "yellow",
    Severity.LOW:      "cyan",
    Severity.INFO:     "dim",
}

console = Console(highlight=False)


def _location(f: Finding) -> str:
    return f"{f.file}:{f.line}" if f.line else f.file


class TerminalReporter:
    def render(self, findings: list[Finding]) -> str:
        if not findings:
            console.print(Padding("[bold green]✓  No findings.[/bold green]", (1, 2)))
            return ""

        console.print()

        by_severity: dict[Severity, list[Finding]] = {}
        for f in sorted(findings, key=lambda x: (-x.severity, x.file, x.line or 0)):
            by_severity.setdefault(f.severity, []).append(f)

        for sev in reversed(Severity):
            group = by_severity.get(sev)
            if not group:
                continue

            badge_style, badge_label = _BADGE[sev]
            loc_colour = _LOC_COLOUR[sev]
            count = len(group)

            # Section header — badge + count
            header = Text("  ")
            header.append(f"  {badge_label}  ", style=badge_style)
            header.append(f"   {count} finding{'s' if count != 1 else ''}",
                          style="bold")
            console.print(header)
            console.print()

            # Two-column table: Rule | Found at
            # Mirrors the screenshot's "Type | Found at" structure
            table = Table(
                box=box.SIMPLE_HEAD,
                show_header=True,
                show_edge=False,
                header_style="dim",
                padding=(0, 1),
            )
            table.add_column("Rule", no_wrap=True, min_width=22, max_width=26)
            table.add_column("Found at", overflow="fold", ratio=1)

            for f in group:
                # Left: rule name bold, scanner dim underneath
                rule_cell = Text()
                rule_cell.append(f.rule, style="bold")
                rule_cell.append(f"\n{f.scanner}", style="dim")

                # Right: coloured location, message underneath
                found_cell = Text()
                found_cell.append(_location(f), style=loc_colour)
                found_cell.append(f"\n  {f.message}", style="default")

                table.add_row(rule_cell, found_cell)

            console.print(Padding(table, (0, 2)))
            console.print()

        # Summary
        counts = Counter(f.severity for f in findings)
        total = len(findings)

        bar = Text(f"  {total} finding{'s' if total != 1 else ''}    ")
        for sev in reversed(Severity):
            if not counts[sev]:
                continue
            badge_style, badge_label = _BADGE[sev]
            bar.append(f"  {badge_label}  ", style=badge_style)
            bar.append(f"  {counts[sev]}   ", style="bold")

        console.print(bar)
        console.print()

        return ""
