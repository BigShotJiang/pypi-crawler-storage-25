from __future__ import annotations

import json
from collections import Counter
from dataclasses import asdict

from ..models import Finding, Severity


class JsonReporter:
    def render(self, findings: list[Finding]) -> str:
        counts = Counter(f.severity for f in findings)
        summary = {sev.label(): counts[sev] for sev in Severity}
        summary["total"] = len(findings)

        serialisable = []
        for f in findings:
            d = asdict(f)
            d["severity"] = f.severity.label()
            serialisable.append(d)

        return json.dumps({"summary": summary, "findings": serialisable}, indent=2)
