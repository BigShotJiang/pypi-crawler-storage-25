from __future__ import annotations

import dataclasses
import fnmatch
import subprocess
from pathlib import Path

from .config import ShieldConfig
from .models import Finding
from .scanners.base import BaseScanner, ScannerError
from .scanners.terraform import TerraformScanner
from .scanners.secrets import SecretsScanner
from .scanners.bash import BashScanner
from .scanners.yaml_scanner import YamlScanner
from .scanners.dockerfile import DockerfileScanner
from .scanners.python_scanner import PythonScanner
from .scanners.kubernetes import KubernetesScanner
from .scanners.gha import GhaScanner
from .scanners.pip_audit import PipAuditScanner

import rich.console

console = rich.console.Console(stderr=True)

_ALL_SCANNERS: list[BaseScanner] = [
    TerraformScanner(),
    SecretsScanner(),
    BashScanner(),
    YamlScanner(),
    DockerfileScanner(),
    PythonScanner(),
    KubernetesScanner(),
    GhaScanner(),
    PipAuditScanner(),
]


def _is_excluded(path: Path, root: Path, patterns: list[str]) -> bool:
    try:
        rel = path.relative_to(root)
    except ValueError:
        return False
    rel_str = str(rel)
    parts = rel.parts
    for pat in patterns:
        if fnmatch.fnmatch(rel_str, pat):
            return True
        # Handle ** glob patterns: extract non-wildcard segments and check
        # that each one matches at least one actual path component.
        # e.g. "**/.terraform/**" → segment ".terraform" must appear in parts.
        if "**" in pat:
            segments = [s for s in pat.replace("\\", "/").split("/")
                        if s and s != "**"]
            if segments and all(
                any(fnmatch.fnmatch(part, seg) for part in parts)
                for seg in segments
            ):
                return True
    return False


def _changed_files(root: Path) -> list[Path]:
    result = subprocess.run(
        ["git", "diff", "--name-only", "HEAD"],
        capture_output=True,
        text=True,
        cwd=root,
    )
    if result.returncode != 0:
        # Fall back to diff against main/master
        for base in ("main", "master", "origin/main", "origin/master"):
            result = subprocess.run(
                ["git", "diff", "--name-only", base],
                capture_output=True,
                text=True,
                cwd=root,
            )
            if result.returncode == 0:
                break
    files = [root / f.strip() for f in result.stdout.splitlines() if f.strip()]
    return [f for f in files if f.exists()]


def run_scan(
    root: Path,
    config: ShieldConfig,
    changed_only: bool = False,
    scanner_filter: str | None = None,
    strict: bool = False,
) -> list[Finding]:
    if changed_only:
        all_files = _changed_files(root)
        console.print(f"[dim]--changed-only: {len(all_files)} file(s) in scope[/dim]")
    else:
        all_files = [
            p for p in root.rglob("*")
            if p.is_file() and not _is_excluded(p, root, config.exclude_paths)
        ]

    scanners = _ALL_SCANNERS
    if scanner_filter:
        name = scanner_filter.lower()
        # Match by class name prefix (e.g. "terraform" matches TerraformScanner)
        scanners = [s for s in scanners if type(s).__name__.lower().startswith(name)]
        if not scanners:
            console.print(f"[yellow]No scanner matches '{scanner_filter}'[/yellow]")
            return []

    findings: list[Finding] = []
    seen: set[tuple] = set()

    for scanner in scanners:
        if not scanner.available():
            tool = scanner._primary_tool() or type(scanner).__name__
            if strict:
                console.print(
                    f"[bold red]--strict: tool '{tool}' not found. "
                    f"Run 'shieldctl install-tools' to install all dependencies.[/bold red]"
                )
                raise ScannerError(f"Required tool '{tool}' not found (--strict mode).")
            console.print(
                f"[dim]Skipping {type(scanner).__name__} ({tool} not found)[/dim]"
            )
            continue

        if scanner.extensions:
            targets = [
                f for f in all_files
                if f.suffix in scanner.extensions
                or f.name in scanner.extensions
                or any(f.name.startswith(e.lstrip("*")) for e in scanner.extensions if "*" in e)
            ]
            if not targets:
                continue
        else:
            # Repo-wide scanner — pass root
            targets = [root]

        label = scanner._primary_tool() or type(scanner).__name__
        if len(targets) == 1:
            t = targets[0]
            target_summary = t.name if t.is_file() else f"{t.name}/"
        else:
            target_summary = f"{len(targets)} files"
        console.print(f"[dim]→ {label}  {target_summary}[/dim]")

        try:
            raw = scanner.run(targets)
        except ScannerError as e:
            console.print(f"[red]Scanner error:[/red] {e}")
            continue

        for f in raw:
            # Drop findings in remote/downloaded modules — not actionable
            if f.file.startswith("git::"):
                continue
            if config.is_suppressed(f.rule):
                continue
            # Normalize to path relative to scan root
            try:
                rel = str(Path(f.file).relative_to(root))
                f = dataclasses.replace(f, file=rel)
            except ValueError:
                pass  # file not under root — leave as-is
            key = f.dedup_key()
            if key not in seen:
                seen.add(key)
                findings.append(f)

    return findings
