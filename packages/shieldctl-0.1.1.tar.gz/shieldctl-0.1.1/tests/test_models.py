from __future__ import annotations

import pytest

from shieldctl.models import Finding, Severity


def test_severity_ordering():
    assert Severity.INFO < Severity.LOW < Severity.MEDIUM < Severity.HIGH < Severity.CRITICAL


def test_severity_from_str():
    assert Severity.from_str("HIGH") == Severity.HIGH
    assert Severity.from_str("critical") == Severity.CRITICAL
    assert Severity.from_str("medium") == Severity.MEDIUM


def test_severity_from_str_invalid():
    with pytest.raises(ValueError, match="Invalid severity"):
        Severity.from_str("UNKNOWN")


def test_severity_label():
    assert Severity.CRITICAL.label() == "CRITICAL"
    assert Severity.INFO.label() == "INFO"


def _finding(**kwargs) -> Finding:
    defaults = dict(
        file="main.tf",
        line=10,
        rule="CKV_GCP_1",
        severity=Severity.HIGH,
        message="Some issue",
        remediation="https://example.com",
        scanner="checkov",
    )
    defaults.update(kwargs)
    return Finding(**defaults)


def test_dedup_key_includes_file_line_rule_scanner():
    f = _finding(file="a.tf", line=5, rule="CKV1", scanner="checkov")
    assert f.dedup_key() == ("a.tf", 5, "CKV1", "checkov")


def test_dedup_key_none_line():
    f = _finding(line=None)
    assert f.dedup_key()[1] is None


def test_dedup_key_uniqueness():
    f1 = _finding(file="a.tf", line=1, rule="R1", scanner="checkov")
    f2 = _finding(file="a.tf", line=1, rule="R1", scanner="tfsec")
    assert f1.dedup_key() != f2.dedup_key()


def test_finding_owasp_defaults_none():
    f = _finding()
    assert f.owasp is None


def test_finding_with_owasp():
    f = _finding(owasp="A05:2021 – Security Misconfiguration")
    assert "A05" in f.owasp
