"""Tests for HtmlReporter."""
from __future__ import annotations

from shieldctl.models import Finding, Severity
from shieldctl.reporters.html_reporter import HtmlReporter

_reporter = HtmlReporter()


def _finding(**kwargs) -> Finding:
    defaults = dict(
        file="infra/main.tf",
        line=10,
        rule="CKV_GCP_29",
        severity=Severity.HIGH,
        message="Unrestricted egress",
        remediation="Restrict egress to required CIDRs only.",
        scanner="checkov",
    )
    defaults.update(kwargs)
    return Finding(**defaults)


def test_html_is_valid_document():
    html = _reporter.render([_finding()])
    assert html.startswith("<!DOCTYPE html>")
    assert "</html>" in html


def test_html_empty_shows_clean_message():
    html = _reporter.render([])
    assert "No findings" in html
    assert "<tbody>" not in html


def test_html_contains_severity_badge():
    html = _reporter.render([_finding(severity=Severity.CRITICAL)])
    assert "CRITICAL" in html


def test_html_contains_file_and_line():
    html = _reporter.render([_finding(file="main.tf", line=42)])
    assert "main.tf" in html
    assert "42" in html


def test_html_contains_rule_id():
    html = _reporter.render([_finding(rule="CKV_GCP_12")])
    assert "CKV_GCP_12" in html


def test_html_contains_scanner_name():
    html = _reporter.render([_finding(scanner="tfsec")])
    assert "tfsec" in html


def test_html_contains_message():
    html = _reporter.render([_finding(message="Bucket is public")])
    assert "Bucket is public" in html


def test_html_contains_remediation():
    html = _reporter.render([_finding(remediation="Make the bucket private.")])
    assert "Make the bucket private" in html


def test_html_severity_cards_present():
    findings = [
        _finding(severity=Severity.HIGH),
        _finding(severity=Severity.MEDIUM, line=2, rule="R2"),
    ]
    html = _reporter.render(findings)
    assert "HIGH" in html
    assert "MEDIUM" in html


def test_html_all_severities_represented():
    findings = [
        _finding(severity=Severity.CRITICAL, line=1, rule="C1"),
        _finding(severity=Severity.HIGH, line=2, rule="C2"),
        _finding(severity=Severity.MEDIUM, line=3, rule="C3"),
        _finding(severity=Severity.LOW, line=4, rule="C4"),
        _finding(severity=Severity.INFO, line=5, rule="C5"),
    ]
    html = _reporter.render(findings)
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        assert sev in html


def test_html_escapes_xss_in_message():
    html = _reporter.render([_finding(message="<script>alert('xss')</script>")])
    # The payload should appear as HTML entities, not raw tags
    assert "&lt;script&gt;" in html
    # Raw payload must not appear as executable content (check the escaped form exists)
    assert "alert(&#x27;xss&#x27;)" in html or "alert(" in html.replace("&lt;script&gt;", "")


def test_html_escapes_xss_in_file():
    html = _reporter.render([_finding(file="<img src=x onerror=alert(1)>")])
    assert "<img" not in html


def test_html_scanner_filter_dropdown_populated():
    findings = [
        _finding(scanner="checkov"),
        _finding(scanner="tfsec", line=2, rule="R2"),
    ]
    html = _reporter.render(findings)
    assert "checkov" in html
    assert "tfsec" in html


def test_html_no_line_shows_just_filename():
    html = _reporter.render([_finding(file="global.tf", line=None)])
    assert "global.tf" in html


def test_html_multiple_findings_all_appear():
    findings = [_finding(rule=f"R{i}", line=i) for i in range(5)]
    html = _reporter.render(findings)
    for i in range(5):
        assert f"R{i}" in html


def test_html_is_self_contained():
    """No external stylesheet or script src attributes."""
    html = _reporter.render([_finding()])
    assert 'src="http' not in html
    assert 'href="http' not in html


def test_html_contains_filter_script():
    html = _reporter.render([_finding()])
    assert "filter()" in html
    assert "<script>" in html
