from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from shieldctl.models import Severity
from shieldctl.scanners.secrets import SecretsScanner


def _mock_exec(stdout: str):
    proc = MagicMock()
    proc.stdout = stdout
    proc.returncode = 0
    return proc


def _leak(rule_id="aws-access-token", file="infra/main.tf", line=22):
    return {
        "RuleID": rule_id,
        "File": file,
        "StartLine": line,
        "Description": "AWS Access Token",
        "Match": "AKIAIOSFODNN7EXAMPLE",
    }


def test_secrets_scanner_parses_leak(tmp_path):
    scanner = SecretsScanner()
    payload = json.dumps([_leak()])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([tmp_path])
    assert len(findings) == 1
    f = findings[0]
    assert f.severity == Severity.CRITICAL
    assert f.rule == "aws-access-token"
    assert f.file == "infra/main.tf"
    assert f.line == 22
    assert f.scanner == "gitleaks"
    assert "AWS Access Token" in f.message
    # Secret value is redacted in the report to prevent accidental exposure
    assert "REDACTED" in f.message
    assert "AKIAIOSFODNN7EXAMPLE" not in f.message


def test_secrets_scanner_redacts_match(tmp_path):
    scanner = SecretsScanner()
    long_match = "A" * 200
    leak = _leak()
    leak["Match"] = long_match
    payload = json.dumps([leak])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([tmp_path])
    # Match value must not appear in the message regardless of length
    assert long_match not in findings[0].message
    assert "REDACTED" in findings[0].message


def test_secrets_scanner_empty_list(tmp_path):
    scanner = SecretsScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("[]")):
        findings = scanner.run([tmp_path])
    assert findings == []


def test_secrets_scanner_null_response(tmp_path):
    scanner = SecretsScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("null")):
        findings = scanner.run([tmp_path])
    assert findings == []


def test_secrets_scanner_invalid_json(tmp_path):
    scanner = SecretsScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("not-json")):
        findings = scanner.run([tmp_path])
    assert findings == []


def test_secrets_scanner_owasp_tag(tmp_path):
    scanner = SecretsScanner()
    payload = json.dumps([_leak()])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([tmp_path])
    assert "A02" in findings[0].owasp


def test_secrets_scanner_multiple_leaks(tmp_path):
    scanner = SecretsScanner()
    leaks = [_leak("rule-a", "a.tf", 1), _leak("rule-b", "b.tf", 5)]
    payload = json.dumps(leaks)
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([tmp_path])
    assert len(findings) == 2
    assert {f.rule for f in findings} == {"rule-a", "rule-b"}


def test_secrets_scanner_primary_tool():
    assert SecretsScanner()._primary_tool() == "gitleaks"


def test_secrets_scanner_no_extensions():
    assert SecretsScanner().extensions == []
