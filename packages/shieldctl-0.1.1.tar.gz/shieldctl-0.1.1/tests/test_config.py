from __future__ import annotations

from pathlib import Path

import pytest

from shieldctl.config import ShieldConfig, Suppression, load_config
from shieldctl.models import Severity


def test_load_config_defaults(tmp_path):
    cfg = load_config(tmp_path)
    assert cfg.fail_on == Severity.HIGH
    assert "**/.terraform/**" in cfg.exclude_paths
    assert cfg.suppress == []


def test_load_config_override_fail_on(tmp_path):
    (tmp_path / ".shieldctl.yaml").write_text("fail_on: CRITICAL\n")
    cfg = load_config(tmp_path)
    assert cfg.fail_on == Severity.CRITICAL


def test_load_config_exclude_paths(tmp_path):
    yaml = "exclude_paths:\n  - '**/vendor/**'\n  - '**/dist/**'\n"
    (tmp_path / ".shieldctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    assert "**/vendor/**" in cfg.exclude_paths


def test_load_config_suppressions(tmp_path):
    yaml = (
        "suppress:\n"
        "  - rule: CKV_GCP_29\n"
        "    reason: allow-all-egress tracked manually\n"
    )
    (tmp_path / ".shieldctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    assert len(cfg.suppress) == 1
    assert cfg.suppress[0].rule == "CKV_GCP_29"
    assert "manually" in cfg.suppress[0].reason


def test_is_suppressed_match(tmp_path):
    cfg = ShieldConfig(
        fail_on=Severity.HIGH,
        exclude_paths=[],
        suppress=[Suppression(rule="CKV_GCP_29")],
    )
    assert cfg.is_suppressed("CKV_GCP_29") is True


def test_is_suppressed_no_match(tmp_path):
    cfg = ShieldConfig(
        fail_on=Severity.HIGH,
        exclude_paths=[],
        suppress=[Suppression(rule="CKV_GCP_29")],
    )
    assert cfg.is_suppressed("CKV_GCP_30") is False


def test_is_suppressed_empty():
    cfg = ShieldConfig(fail_on=Severity.HIGH, exclude_paths=[], suppress=[])
    assert cfg.is_suppressed("ANYTHING") is False


def test_load_config_missing_yaml_is_ok(tmp_path):
    # No .shieldctl.yaml — should succeed with defaults
    cfg = load_config(tmp_path)
    assert cfg.fail_on == Severity.HIGH


def test_load_config_invalid_yaml_raises(tmp_path):
    (tmp_path / ".shieldctl.yaml").write_text("fail_on: [unclosed bracket\n")
    with pytest.raises(ValueError, match="Invalid .shieldctl.yaml"):
        load_config(tmp_path)


def test_load_config_invalid_severity_raises(tmp_path):
    (tmp_path / ".shieldctl.yaml").write_text("fail_on: OOPS\n")
    with pytest.raises(ValueError, match="Invalid severity"):
        load_config(tmp_path)


def test_load_config_suppress_missing_rule_key_skipped(tmp_path):
    """Suppress entries without a 'rule' key must be silently skipped."""
    yaml = (
        "suppress:\n"
        "  - reason: tracked elsewhere\n"          # no 'rule' key
        "  - rule: CKV_GCP_29\n"
        "    reason: intentional\n"
    )
    (tmp_path / ".shieldctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    assert len(cfg.suppress) == 1
    assert cfg.suppress[0].rule == "CKV_GCP_29"


def test_load_config_suppress_all_missing_rule_keys(tmp_path):
    yaml = "suppress:\n  - reason: no rule here\n"
    (tmp_path / ".shieldctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    assert cfg.suppress == []
