"""Tests for PythonScanner (bandit + safety output parsing)."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from shieldctl.scanners.python_scanner import PythonScanner
from shieldctl.models import Severity

_scanner = PythonScanner()


def _fake_result(stdout: str, returncode: int = 0) -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr="")


# ── bandit parsing ────────────────────────────────────────────────────────────

def test_bandit_parses_single_issue(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    payload = json.dumps({"results": [{
        "filename": str(py),
        "line_number": 5,
        "test_id": "B201",
        "issue_severity": "HIGH",
        "issue_text": "Use of exec detected.",
        "more_info": "https://bandit.readthedocs.io/en/latest/plugins/b201_flask_debug_true.html",
    }]})
    with patch.object(_scanner, "_exec", return_value=_fake_result(payload)):
        with patch("shutil.which", return_value=None):  # skip safety
            findings = _scanner.run([py])
    assert len(findings) == 1
    f = findings[0]
    assert f.rule == "B201"
    assert f.severity == Severity.HIGH
    assert f.line == 5
    assert f.scanner == "bandit"


def test_bandit_severity_mapping(tmp_path):
    py = tmp_path / "app.py"
    py.touch()

    for sev_str, expected in [("HIGH", Severity.HIGH), ("MEDIUM", Severity.MEDIUM), ("LOW", Severity.LOW)]:
        payload = json.dumps({"results": [{
            "filename": str(py),
            "line_number": 1,
            "test_id": "B000",
            "issue_severity": sev_str,
            "issue_text": "Test.",
            "more_info": "",
        }]})
        with patch.object(_scanner, "_exec", return_value=_fake_result(payload)):
            with patch("shutil.which", return_value=None):
                findings = _scanner.run([py])
        assert findings[0].severity == expected


def test_bandit_unknown_severity_defaults_to_medium(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    payload = json.dumps({"results": [{
        "filename": str(py),
        "line_number": 1,
        "test_id": "B000",
        "issue_severity": "UNDEFINED",
        "issue_text": "Test.",
        "more_info": "",
    }]})
    with patch.object(_scanner, "_exec", return_value=_fake_result(payload)):
        with patch("shutil.which", return_value=None):
            findings = _scanner.run([py])
    assert findings[0].severity == Severity.MEDIUM


def test_bandit_empty_results(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    payload = json.dumps({"results": []})
    with patch.object(_scanner, "_exec", return_value=_fake_result(payload)):
        with patch("shutil.which", return_value=None):
            findings = _scanner.run([py])
    assert findings == []


def test_bandit_invalid_json_returns_empty(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    with patch.object(_scanner, "_exec", return_value=_fake_result("not json")):
        with patch("shutil.which", return_value=None):
            findings = _scanner.run([py])
    assert findings == []


def test_bandit_runs_per_unique_directory(tmp_path):
    """Bandit is invoked per directory, not per file."""
    d1 = tmp_path / "pkg1"
    d2 = tmp_path / "pkg2"
    d1.mkdir()
    d2.mkdir()
    py1 = d1 / "a.py"
    py2 = d2 / "b.py"
    py1.touch()
    py2.touch()

    payload = json.dumps({"results": []})
    calls = []

    def fake_exec(cmd, **kwargs):
        calls.append(cmd)
        return _fake_result(payload)

    with patch.object(_scanner, "_exec", side_effect=fake_exec):
        with patch("shutil.which", return_value=None):
            _scanner.run([py1, py2])

    # One call per unique parent directory
    bandit_calls = [c for c in calls if c[0] == "bandit"]
    assert len(bandit_calls) == 2


def test_bandit_owasp_tag_present(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    payload = json.dumps({"results": [{
        "filename": str(py),
        "line_number": 1,
        "test_id": "B101",
        "issue_severity": "LOW",
        "issue_text": "assert used.",
        "more_info": "",
    }]})
    with patch.object(_scanner, "_exec", return_value=_fake_result(payload)):
        with patch("shutil.which", return_value=None):
            findings = _scanner.run([py])
    assert findings[0].owasp is not None


# ── safety parsing ────────────────────────────────────────────────────────────

def test_safety_parses_new_format(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    bandit_payload = json.dumps({"results": []})
    safety_payload = json.dumps({"vulnerabilities": [{
        "package_name": "requests",
        "advisory": "Requests has a known vulnerability in versions < 2.31",
        "vulnerability_id": "CVE-2023-1234",
    }]})

    exec_calls = [_fake_result(bandit_payload), _fake_result(safety_payload)]
    with patch.object(_scanner, "_exec", side_effect=exec_calls):
        with patch("shutil.which", return_value="/usr/bin/safety"):
            findings = _scanner.run([py])

    safety_findings = [f for f in findings if f.scanner == "safety"]
    assert len(safety_findings) == 1
    f = safety_findings[0]
    assert f.severity == Severity.HIGH
    assert "requests" in f.message
    assert "CVE-2023-1234" in f.rule


def test_safety_parses_legacy_list_format(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    bandit_payload = json.dumps({"results": []})
    # Legacy: [[package, spec, version, description, vuln_id], ...]
    safety_payload = json.dumps([
        ["django", ">=2.0,<3.2", "2.0.0", "Django SQL injection vulnerability.", "45327"],
    ])
    exec_calls = [_fake_result(bandit_payload), _fake_result(safety_payload)]
    with patch.object(_scanner, "_exec", side_effect=exec_calls):
        with patch("shutil.which", return_value="/usr/bin/safety"):
            findings = _scanner.run([py])

    safety_findings = [f for f in findings if f.scanner == "safety"]
    assert len(safety_findings) == 1
    assert "django" in safety_findings[0].message.lower()


def test_safety_skipped_when_not_installed(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    payload = json.dumps({"results": []})
    with patch.object(_scanner, "_exec", return_value=_fake_result(payload)):
        with patch("shutil.which", return_value=None):
            findings = _scanner.run([py])
    assert not any(f.scanner == "safety" for f in findings)


def test_safety_invalid_json_returns_empty(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    bandit_payload = json.dumps({"results": []})
    exec_calls = [_fake_result(bandit_payload), _fake_result("not json")]
    with patch.object(_scanner, "_exec", side_effect=exec_calls):
        with patch("shutil.which", return_value="/usr/bin/safety"):
            findings = _scanner.run([py])
    assert not any(f.scanner == "safety" for f in findings)


def test_safety_owasp_tag_present(tmp_path):
    py = tmp_path / "app.py"
    py.touch()
    bandit_payload = json.dumps({"results": []})
    safety_payload = json.dumps({"vulnerabilities": [{
        "package_name": "pillow",
        "advisory": "Buffer overflow.",
        "vulnerability_id": "CVE-2022-9999",
    }]})
    exec_calls = [_fake_result(bandit_payload), _fake_result(safety_payload)]
    with patch.object(_scanner, "_exec", side_effect=exec_calls):
        with patch("shutil.which", return_value="/usr/bin/safety"):
            findings = _scanner.run([py])
    safety_findings = [f for f in findings if f.scanner == "safety"]
    assert safety_findings[0].owasp is not None


# ── scanner meta ──────────────────────────────────────────────────────────────

def test_python_scanner_primary_tool():
    assert _scanner._primary_tool() == "bandit"


def test_python_scanner_extensions():
    assert ".py" in _scanner.extensions
