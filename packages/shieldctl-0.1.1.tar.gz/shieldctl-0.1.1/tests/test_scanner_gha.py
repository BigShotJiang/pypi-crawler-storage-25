from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from shieldctl.models import Severity
from shieldctl.scanners.gha import GhaScanner, _is_gha_workflow


# ── content detection ─────────────────────────────────────────────────────────

def test_is_gha_workflow_true(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text("on: push\njobs:\n  build:\n    runs-on: ubuntu-latest\n")
    assert _is_gha_workflow(f) is True


def test_is_gha_workflow_on_quoted(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text("'on': push\njobs:\n  build:\n    runs-on: ubuntu-latest\n")
    assert _is_gha_workflow(f) is True


def test_is_gha_workflow_missing_jobs(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text("on: push\nsteps:\n  - run: echo hi\n")
    assert _is_gha_workflow(f) is False


def test_is_gha_workflow_k8s_manifest(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\n")
    assert _is_gha_workflow(f) is False


def test_is_gha_workflow_nonexistent():
    assert _is_gha_workflow(Path("/nonexistent/path.yaml")) is False


# ── scanner run() helpers ─────────────────────────────────────────────────────

def _mock_exec(stdout: str):
    proc = MagicMock()
    proc.stdout = stdout
    proc.returncode = 0
    return proc


_GHA_CONTENT = "on: push\njobs:\n  build:\n    runs-on: ubuntu-latest\n"

_ACTIONLINT_RESULT = json.dumps([
    {
        "message": "shellcheck reported issue in this script: ...",
        "kind": "error",
        "line": 10,
        "filepath": "ci.yaml",
    }
])

_CHECKOV_RESULT = json.dumps({
    "results": {
        "failed_checks": [
            {
                "check_id": "CKV2_GHA_1",
                "description": "Ensure top-level permissions are not set to write-all",
                "file_path": "/path/ci.yaml",
                "file_line_range": [1, 5],
            }
        ]
    }
})


def test_gha_scanner_actionlint_findings(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text(_GHA_CONTENT)
    scanner = GhaScanner()
    with (
        patch("shieldctl.scanners.gha.shutil.which", return_value="/usr/bin/actionlint"),
        patch.object(scanner, "_exec", return_value=_mock_exec(_ACTIONLINT_RESULT)),
    ):
        findings = scanner.run([f])
    assert any(f.scanner == "actionlint" for f in findings)
    assert any("actionlint" in f.rule for f in findings)


def test_gha_scanner_checkov_findings(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text(_GHA_CONTENT)
    scanner = GhaScanner()

    def mock_which(tool: str):
        return None if tool == "actionlint" else "/usr/bin/checkov"

    with (
        patch("shieldctl.scanners.gha.shutil.which", side_effect=mock_which),
        patch.object(scanner, "_exec", return_value=_mock_exec(_CHECKOV_RESULT)),
    ):
        findings = scanner.run([f])
    assert any(f.scanner == "checkov-gha" for f in findings)
    assert any(f.rule == "CKV2_GHA_1" for f in findings)


def test_gha_scanner_skips_non_gha_file(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\n")
    scanner = GhaScanner()
    with patch("shieldctl.scanners.gha.shutil.which", return_value="/usr/bin/actionlint"):
        with patch.object(scanner, "_exec", return_value=_mock_exec(_ACTIONLINT_RESULT)) as mock_exec:
            findings = scanner.run([f])
    assert findings == []
    mock_exec.assert_not_called()


def test_gha_scanner_actionlint_invalid_json(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text(_GHA_CONTENT)
    scanner = GhaScanner()
    with (
        patch("shieldctl.scanners.gha.shutil.which", return_value="/usr/bin/actionlint"),
        patch.object(scanner, "_exec", return_value=_mock_exec("not-json")),
    ):
        findings = scanner.run([f])
    assert findings == []


def test_gha_scanner_checkov_invalid_json(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text(_GHA_CONTENT)
    scanner = GhaScanner()

    def mock_which(tool: str):
        return None if tool == "actionlint" else "/usr/bin/checkov"

    with (
        patch("shieldctl.scanners.gha.shutil.which", side_effect=mock_which),
        patch.object(scanner, "_exec", return_value=_mock_exec("bad")),
    ):
        findings = scanner.run([f])
    assert findings == []


def test_gha_scanner_no_tools_available(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text(_GHA_CONTENT)
    scanner = GhaScanner()
    with patch("shieldctl.scanners.gha.shutil.which", return_value=None):
        findings = scanner.run([f])
    assert findings == []


def test_gha_scanner_checkov_list_response(tmp_path):
    f = tmp_path / "ci.yaml"
    f.write_text(_GHA_CONTENT)
    scanner = GhaScanner()
    result = json.dumps([
        {"results": {"failed_checks": [
            {"check_id": "CKV2_GHA_1", "description": "Test", "file_path": str(f)}
        ]}}
    ])

    def mock_which(tool: str):
        return None if tool == "actionlint" else "/usr/bin/checkov"

    with (
        patch("shieldctl.scanners.gha.shutil.which", side_effect=mock_which),
        patch.object(scanner, "_exec", return_value=_mock_exec(result)),
    ):
        findings = scanner.run([f])
    assert any(f.rule == "CKV2_GHA_1" for f in findings)


def test_gha_scanner_primary_tool():
    assert GhaScanner()._primary_tool() == "actionlint"


def test_gha_scanner_extensions():
    exts = GhaScanner().extensions
    assert ".yaml" in exts
    assert ".yml" in exts
