from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from shieldctl.models import Severity
from shieldctl.scanners.terraform import TerraformScanner, _common_ancestor


# ── _common_ancestor ──────────────────────────────────────────────────────────

def test_common_ancestor_single_file(tmp_path):
    f = tmp_path / "a" / "main.tf"
    f.parent.mkdir()
    f.touch()
    assert _common_ancestor([f]) == f.parent.resolve()


def test_common_ancestor_siblings(tmp_path):
    (tmp_path / "a").mkdir()
    (tmp_path / "b").mkdir()
    f1 = tmp_path / "a" / "main.tf"
    f2 = tmp_path / "b" / "main.tf"
    f1.touch()
    f2.touch()
    assert _common_ancestor([f1, f2]) == tmp_path.resolve()


def test_common_ancestor_nested(tmp_path):
    deep = tmp_path / "a" / "b" / "c"
    deep.mkdir(parents=True)
    f1 = deep / "main.tf"
    f2 = tmp_path / "a" / "other.tf"
    f1.touch()
    f2.touch()
    assert _common_ancestor([f1, f2]) == (tmp_path / "a").resolve()


def test_common_ancestor_empty():
    result = _common_ancestor([])
    assert result == Path(".")


# ── checkov JSON parsing ───────────────────────────────────────────────────────

def _make_checkov_result(check_id="CKV_GCP_1", sev="HIGH", file_path="/main.tf", line=5, resource="google_project"):
    return {
        "check_id": check_id,
        "severity": sev,
        "repo_file_path": file_path,
        "file_line_range": [line, line + 2],
        "resource": resource,
        "description": None,
        "short_description": None,
        "guideline": "",
    }


def _mock_exec(stdout: str):
    proc = MagicMock()
    proc.stdout = stdout
    proc.returncode = 0
    return proc


def test_checkov_parses_single_dict(tmp_path):
    scanner = TerraformScanner()
    payload = {"results": {"failed_checks": [_make_checkov_result()]}}
    with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
        with patch("shutil.which", return_value="/usr/bin/checkov"):
            findings = scanner._run_checkov(tmp_path)
    assert len(findings) == 1
    assert findings[0].rule == "CKV_GCP_1"
    assert findings[0].severity == Severity.HIGH
    assert findings[0].scanner == "checkov"


def test_checkov_parses_list_format(tmp_path):
    scanner = TerraformScanner()
    payload = [
        {"results": {"failed_checks": [_make_checkov_result("CKV_GCP_1")]}},
        {"results": {"failed_checks": [_make_checkov_result("CKV_GCP_2")]}},
    ]
    with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
        with patch("shutil.which", return_value="/usr/bin/checkov"):
            findings = scanner._run_checkov(tmp_path)
    assert len(findings) == 2
    rules = {f.rule for f in findings}
    assert rules == {"CKV_GCP_1", "CKV_GCP_2"}


def test_checkov_severity_mapping(tmp_path):
    scanner = TerraformScanner()
    cases = [
        ("CRITICAL", Severity.CRITICAL),
        ("HIGH", Severity.HIGH),
        ("MEDIUM", Severity.MEDIUM),
        ("LOW", Severity.LOW),
        ("INFO", Severity.INFO),
    ]
    for sev_str, expected in cases:
        payload = {"results": {"failed_checks": [_make_checkov_result(sev=sev_str)]}}
        with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
            with patch("shutil.which", return_value="/usr/bin/checkov"):
                findings = scanner._run_checkov(tmp_path)
        assert findings[0].severity == expected, f"Failed for {sev_str}"


def test_checkov_resolves_repo_relative_path(tmp_path):
    scanner = TerraformScanner()
    # checkov emits "/main.tf" (leading slash, relative to scanned dir)
    check = _make_checkov_result(file_path="/main.tf")
    payload = {"results": {"failed_checks": [check]}}
    with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
        with patch("shutil.which", return_value="/usr/bin/checkov"):
            findings = scanner._run_checkov(tmp_path)
    # Should resolve to tmp_path / "main.tf", not "/main.tf"
    assert findings[0].file == str(tmp_path / "main.tf")


def test_checkov_known_description_lookup(tmp_path):
    scanner = TerraformScanner()
    check = _make_checkov_result(check_id="CKV_GCP_16")
    check["description"] = None
    check["short_description"] = None
    payload = {"results": {"failed_checks": [check]}}
    with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
        with patch("shutil.which", return_value="/usr/bin/checkov"):
            findings = scanner._run_checkov(tmp_path)
    assert "DNSSEC" in findings[0].message


def test_checkov_fallback_to_resource_description(tmp_path):
    scanner = TerraformScanner()
    check = _make_checkov_result(check_id="CKV_UNKNOWN_9999", resource="google_some_resource")
    check["description"] = None
    check["short_description"] = None
    payload = {"results": {"failed_checks": [check]}}
    with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
        with patch("shutil.which", return_value="/usr/bin/checkov"):
            findings = scanner._run_checkov(tmp_path)
    assert "google_some_resource" in findings[0].message


def test_checkov_invalid_json_returns_empty(tmp_path):
    scanner = TerraformScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("not-json")):
        with patch("shutil.which", return_value="/usr/bin/checkov"):
            findings = scanner._run_checkov(tmp_path)
    assert findings == []


# ── tfsec JSON parsing ────────────────────────────────────────────────────────

def _make_tfsec_result(rule_id="aws-s3-no-public-buckets", sev="HIGH"):
    return {
        "rule_id": rule_id,
        "severity": sev,
        "description": "S3 bucket is publicly accessible",
        "resolution": "Restrict bucket access",
        "links": ["https://example.com"],
        "location": {"filename": "/infra/main.tf", "start_line": 12},
    }


def test_tfsec_parses_results(tmp_path):
    scanner = TerraformScanner()
    payload = {"results": [_make_tfsec_result()]}
    with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
        with patch("shutil.which", return_value="/usr/bin/tfsec"):
            findings = scanner._run_tfsec(tmp_path)
    assert len(findings) == 1
    assert findings[0].rule == "aws-s3-no-public-buckets"
    assert findings[0].severity == Severity.HIGH
    assert findings[0].scanner == "tfsec"
    assert findings[0].line == 12


def test_tfsec_null_results(tmp_path):
    scanner = TerraformScanner()
    payload = {"results": None}
    with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
        with patch("shutil.which", return_value="/usr/bin/tfsec"):
            findings = scanner._run_tfsec(tmp_path)
    assert findings == []


def test_tfsec_invalid_json_returns_empty(tmp_path):
    scanner = TerraformScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("garbage")):
        with patch("shutil.which", return_value="/usr/bin/tfsec"):
            findings = scanner._run_tfsec(tmp_path)
    assert findings == []


def test_tfsec_severity_mapping(tmp_path):
    scanner = TerraformScanner()
    for sev_str, expected in [("CRITICAL", Severity.CRITICAL), ("LOW", Severity.LOW)]:
        payload = {"results": [_make_tfsec_result(sev=sev_str)]}
        with patch.object(scanner, "_exec", return_value=_mock_exec(json.dumps(payload))):
            with patch("shutil.which", return_value="/usr/bin/tfsec"):
                findings = scanner._run_tfsec(tmp_path)
        assert findings[0].severity == expected
