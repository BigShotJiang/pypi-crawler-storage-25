from __future__ import annotations

import json

from shieldctl.models import Finding, Severity
from shieldctl.reporters.json_reporter import JsonReporter


def _finding(sev: Severity, rule: str = "CKV1", file: str = "main.tf") -> Finding:
    return Finding(
        file=file,
        line=1,
        rule=rule,
        severity=sev,
        message="Some issue",
        remediation="https://example.com",
        scanner="checkov",
    )


def test_json_reporter_structure():
    findings = [_finding(Severity.HIGH), _finding(Severity.MEDIUM)]
    reporter = JsonReporter()
    raw = reporter.render(findings)
    data = json.loads(raw)
    assert "summary" in data
    assert "findings" in data
    assert len(data["findings"]) == 2


def test_json_reporter_summary_counts():
    findings = [
        _finding(Severity.CRITICAL),
        _finding(Severity.HIGH),
        _finding(Severity.HIGH),
        _finding(Severity.MEDIUM),
    ]
    reporter = JsonReporter()
    data = json.loads(reporter.render(findings))
    assert data["summary"]["CRITICAL"] == 1
    assert data["summary"]["HIGH"] == 2
    assert data["summary"]["MEDIUM"] == 1
    assert data["summary"]["LOW"] == 0
    assert data["summary"]["total"] == 4


def test_json_reporter_severity_as_string():
    findings = [_finding(Severity.CRITICAL)]
    reporter = JsonReporter()
    data = json.loads(reporter.render(findings))
    assert data["findings"][0]["severity"] == "CRITICAL"


def test_json_reporter_all_fields_present():
    f = Finding(
        file="infra/main.tf",
        line=10,
        rule="CKV_GCP_1",
        severity=Severity.HIGH,
        message="Logging disabled",
        remediation="https://docs.example.com",
        scanner="checkov",
        owasp="A05:2021",
    )
    reporter = JsonReporter()
    data = json.loads(reporter.render([f]))
    entry = data["findings"][0]
    assert entry["file"] == "infra/main.tf"
    assert entry["line"] == 10
    assert entry["rule"] == "CKV_GCP_1"
    assert entry["severity"] == "HIGH"
    assert entry["message"] == "Logging disabled"
    assert entry["remediation"] == "https://docs.example.com"
    assert entry["scanner"] == "checkov"
    assert entry["owasp"] == "A05:2021"


def test_json_reporter_empty_findings():
    reporter = JsonReporter()
    data = json.loads(reporter.render([]))
    assert data["findings"] == []
    assert data["summary"]["total"] == 0


def test_json_reporter_none_line():
    f = Finding(
        file="script.sh",
        line=None,
        rule="SC2006",
        severity=Severity.MEDIUM,
        message="Some issue",
        remediation="",
        scanner="shellcheck",
    )
    reporter = JsonReporter()
    data = json.loads(reporter.render([f]))
    assert data["findings"][0]["line"] is None


def test_json_reporter_valid_json():
    findings = [_finding(Severity.LOW, rule=f"R{i}") for i in range(20)]
    reporter = JsonReporter()
    raw = reporter.render(findings)
    # Should not raise
    data = json.loads(raw)
    assert len(data["findings"]) == 20
