from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from shieldctl.models import Severity
from shieldctl.scanners.yaml_scanner import YamlScanner


def _mock_exec(stdout: str = "", stderr: str = ""):
    proc = MagicMock()
    proc.stdout = stdout
    proc.stderr = stderr
    proc.returncode = 0
    return proc


def _parsable_line(path: str, line: int, col: int, level: str, msg: str, rule: str) -> str:
    return f"{path}:{line}:{col}: [{level}] {msg} ({rule})"


def test_yamllint_error_maps_to_medium(tmp_path):
    f = tmp_path / "config.yaml"
    f.touch()
    scanner = YamlScanner()
    output = _parsable_line(str(f), 1, 1, "error", "wrong indentation: expected 2 but found 4", "indentation")
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=output)):
        findings = scanner._yamllint(f)
    assert len(findings) == 1
    assert findings[0].severity == Severity.MEDIUM
    assert findings[0].rule == "yamllint:indentation"
    assert findings[0].scanner == "yamllint"


def test_yamllint_warning_maps_to_low(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.touch()
    scanner = YamlScanner()
    output = _parsable_line(str(f), 5, 1, "warning", "missing document start", "document-start")
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=output)):
        findings = scanner._yamllint(f)
    assert findings[0].severity == Severity.LOW


def test_yamllint_line_number_parsed(tmp_path):
    f = tmp_path / "svc.yaml"
    f.touch()
    scanner = YamlScanner()
    output = _parsable_line(str(f), 42, 3, "error", "too many spaces", "indentation")
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=output)):
        findings = scanner._yamllint(f)
    assert findings[0].line == 42


def test_yamllint_empty_output(tmp_path):
    f = tmp_path / "clean.yaml"
    f.touch()
    scanner = YamlScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout="")):
        findings = scanner._yamllint(f)
    assert findings == []


def test_yamllint_stderr_also_parsed(tmp_path):
    f = tmp_path / "err.yaml"
    f.touch()
    scanner = YamlScanner()
    output = _parsable_line(str(f), 2, 1, "error", "syntax error", "syntax")
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout="", stderr=output)):
        findings = scanner._yamllint(f)
    assert len(findings) == 1


def test_yamllint_remediation_url(tmp_path):
    f = tmp_path / "x.yaml"
    f.touch()
    scanner = YamlScanner()
    output = _parsable_line(str(f), 1, 1, "error", "some issue", "document-start")
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=output)):
        findings = scanner._yamllint(f)
    assert "yamllint.readthedocs.io" in findings[0].remediation
    assert "document_start" in findings[0].remediation


def test_is_checkov_target_github_actions(tmp_path):
    scanner = YamlScanner()
    path = tmp_path / ".github" / "workflows" / "ci.yml"
    assert scanner._is_checkov_target(path) is True


def test_is_checkov_target_k8s(tmp_path):
    scanner = YamlScanner()
    path = tmp_path / "k8s" / "deployment.yaml"
    assert scanner._is_checkov_target(path) is True


def test_is_checkov_target_regular_yaml(tmp_path):
    scanner = YamlScanner()
    path = tmp_path / "config" / "app.yaml"
    assert scanner._is_checkov_target(path) is False


def test_yaml_scanner_primary_tool():
    assert YamlScanner()._primary_tool() == "yamllint"


def test_yaml_scanner_extensions():
    exts = YamlScanner().extensions
    assert ".yml" in exts
    assert ".yaml" in exts


# ── Content-based checkov target detection ────────────────────────────────────

def test_is_checkov_target_k8s_content(tmp_path):
    """File with apiVersion + kind detected as K8s even outside k8s/ directory."""
    f = tmp_path / "app.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: app\n")
    scanner = YamlScanner()
    assert scanner._is_checkov_target(f) is True


def test_is_checkov_target_gha_content(tmp_path):
    """File with on: + jobs: detected as GHA workflow even outside .github/workflows/."""
    f = tmp_path / "app.yaml"
    f.write_text("on: push\njobs:\n  build:\n    runs-on: ubuntu-latest\n")
    scanner = YamlScanner()
    assert scanner._is_checkov_target(f) is True


def test_is_checkov_target_plain_yaml_not_flagged(tmp_path):
    """Regular YAML config with no K8s/GHA markers is not a checkov target."""
    f = tmp_path / "config.yaml"
    f.write_text("database:\n  host: localhost\n  port: 5432\n")
    scanner = YamlScanner()
    assert scanner._is_checkov_target(f) is False
