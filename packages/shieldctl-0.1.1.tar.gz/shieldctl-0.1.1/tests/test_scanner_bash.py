from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from shieldctl.models import Severity
from shieldctl.scanners.bash import BashScanner


def _mock_exec(stdout: str):
    proc = MagicMock()
    proc.stdout = stdout
    proc.returncode = 0
    return proc


def _issue(code=2006, level="warning", message="Use double quotes to avoid globbing"):
    return {"code": code, "level": level, "line": 4, "message": message}


def test_bash_scanner_parses_warning(tmp_path):
    f = tmp_path / "deploy.sh"
    f.touch()
    scanner = BashScanner()
    payload = json.dumps([_issue(level="warning")])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([f])
    assert len(findings) == 1
    assert findings[0].severity == Severity.MEDIUM
    assert findings[0].rule == "SC2006"
    assert findings[0].scanner == "shellcheck"


def test_bash_scanner_level_mapping(tmp_path):
    f = tmp_path / "script.sh"
    f.touch()
    scanner = BashScanner()
    cases = [
        ("error", Severity.HIGH),
        ("warning", Severity.MEDIUM),
        ("info", Severity.LOW),
        ("style", Severity.INFO),
    ]
    for level, expected_sev in cases:
        payload = json.dumps([_issue(level=level)])
        with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
            findings = scanner.run([f])
        assert findings[0].severity == expected_sev, f"Failed for level={level}"


def test_bash_scanner_remediation_url(tmp_path):
    f = tmp_path / "run.sh"
    f.touch()
    scanner = BashScanner()
    payload = json.dumps([_issue(code=1234)])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([f])
    assert "SC1234" in findings[0].remediation
    assert "shellcheck.net" in findings[0].remediation


def test_bash_scanner_empty_output(tmp_path):
    f = tmp_path / "clean.sh"
    f.touch()
    scanner = BashScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("[]")):
        findings = scanner.run([f])
    assert findings == []


def test_bash_scanner_invalid_json(tmp_path):
    f = tmp_path / "bad.sh"
    f.touch()
    scanner = BashScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("not-json")):
        findings = scanner.run([f])
    assert findings == []


def test_bash_scanner_multiple_files(tmp_path):
    files = [tmp_path / f"script{i}.sh" for i in range(3)]
    for f in files:
        f.touch()
    scanner = BashScanner()
    payload = json.dumps([_issue()])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run(files)
    assert len(findings) == 3  # one finding per file


def test_bash_scanner_primary_tool():
    assert BashScanner()._primary_tool() == "shellcheck"


def test_bash_scanner_extensions():
    assert ".sh" in BashScanner().extensions


def test_bash_unknown_level_defaults_to_medium(tmp_path):
    f = tmp_path / "script.sh"
    f.touch()
    scanner = BashScanner()
    payload = json.dumps([_issue(level="unknown_future_level")])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([f])
    assert findings[0].severity == Severity.MEDIUM


def test_bash_missing_code_gives_sc_unknown(tmp_path):
    f = tmp_path / "script.sh"
    f.touch()
    scanner = BashScanner()
    issue_no_code = {"level": "warning", "line": 1, "message": "test"}  # no 'code' key
    payload = json.dumps([issue_no_code])
    with patch.object(scanner, "_exec", return_value=_mock_exec(payload)):
        findings = scanner.run([f])
    assert findings[0].rule == "SC-UNKNOWN"
