from __future__ import annotations

import dataclasses
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from shieldctl.config import ShieldConfig, Suppression
from shieldctl.dispatcher import _is_excluded, run_scan
from shieldctl.models import Finding, Severity
from shieldctl.scanners.base import ScannerError


def _cfg(**kwargs) -> ShieldConfig:
    defaults = dict(fail_on=Severity.HIGH, exclude_paths=[], suppress=[])
    defaults.update(kwargs)
    return ShieldConfig(**defaults)


def _finding(**kwargs) -> Finding:
    defaults = dict(
        file="/some/main.tf",
        line=1,
        rule="CKV1",
        severity=Severity.HIGH,
        message="Issue",
        remediation="",
        scanner="checkov",
    )
    defaults.update(kwargs)
    return Finding(**defaults)


# ── _is_excluded ──────────────────────────────────────────────────────────────

def test_is_excluded_matches_pattern(tmp_path):
    f = tmp_path / ".terraform" / "modules" / "main.tf"
    assert _is_excluded(f, tmp_path, ["**/.terraform/**"]) is True


def test_is_excluded_no_match(tmp_path):
    f = tmp_path / "infrastructure" / "main.tf"
    assert _is_excluded(f, tmp_path, ["**/.terraform/**"]) is False


def test_is_excluded_empty_patterns(tmp_path):
    f = tmp_path / "anything.tf"
    assert _is_excluded(f, tmp_path, []) is False


# ── git:: filtering ───────────────────────────────────────────────────────────

def test_git_remote_findings_dropped(tmp_path):
    remote_finding = _finding(file="git::https://github.com/tameed/modules.git//gcp/main.tf")
    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = True
    mock_scanner.run.return_value = [remote_finding]
    mock_scanner._primary_tool.return_value = "checkov"

    tf_file = tmp_path / "main.tf"
    tf_file.touch()

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, _cfg())
    assert findings == []


# ── path normalization ────────────────────────────────────────────────────────

def test_paths_normalized_to_relative(tmp_path):
    abs_finding = _finding(file=str(tmp_path / "infra" / "main.tf"))
    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = True
    mock_scanner.run.return_value = [abs_finding]
    mock_scanner._primary_tool.return_value = "checkov"

    tf_file = tmp_path / "infra" / "main.tf"
    tf_file.parent.mkdir()
    tf_file.touch()

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, _cfg())

    assert len(findings) == 1
    assert findings[0].file == "infra/main.tf"


def test_path_outside_root_left_as_is(tmp_path):
    other = Path("/tmp/unrelated/file.tf")
    raw_finding = _finding(file=str(other))
    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = True
    mock_scanner.run.return_value = [raw_finding]
    mock_scanner._primary_tool.return_value = "checkov"

    tf_file = tmp_path / "main.tf"
    tf_file.touch()

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, _cfg())

    assert findings[0].file == str(other)


# ── deduplication ─────────────────────────────────────────────────────────────

def test_duplicate_findings_deduplicated(tmp_path):
    f = _finding(file=str(tmp_path / "main.tf"), line=5, rule="CKV1", scanner="checkov")
    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = True
    mock_scanner.run.return_value = [f, f]  # same finding twice
    mock_scanner._primary_tool.return_value = "checkov"

    tf_file = tmp_path / "main.tf"
    tf_file.touch()

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, _cfg())
    assert len(findings) == 1


def test_different_scanners_not_deduplicated(tmp_path):
    tf_file = tmp_path / "main.tf"
    tf_file.touch()
    f1 = _finding(file=str(tf_file), rule="RULE", scanner="checkov")
    f2 = _finding(file=str(tf_file), rule="RULE", scanner="tfsec")

    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = True
    mock_scanner.run.return_value = [f1, f2]
    mock_scanner._primary_tool.return_value = "checkov"

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, _cfg())
    assert len(findings) == 2


# ── suppression ───────────────────────────────────────────────────────────────

def test_suppressed_rules_dropped(tmp_path):
    tf_file = tmp_path / "main.tf"
    tf_file.touch()
    f = _finding(file=str(tf_file), rule="CKV_GCP_29")

    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = True
    mock_scanner.run.return_value = [f]
    mock_scanner._primary_tool.return_value = "checkov"

    cfg = _cfg(suppress=[Suppression(rule="CKV_GCP_29")])
    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, cfg)
    assert findings == []


def test_non_suppressed_rules_kept(tmp_path):
    tf_file = tmp_path / "main.tf"
    tf_file.touch()
    f = _finding(file=str(tf_file), rule="CKV_GCP_30")

    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = True
    mock_scanner.run.return_value = [f]
    mock_scanner._primary_tool.return_value = "checkov"

    cfg = _cfg(suppress=[Suppression(rule="CKV_GCP_29")])
    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, cfg)
    assert len(findings) == 1


# ── scanner availability / strict mode ───────────────────────────────────────

def test_unavailable_scanner_skipped(tmp_path):
    tf_file = tmp_path / "main.tf"
    tf_file.touch()

    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = False
    mock_scanner._primary_tool.return_value = "checkov"

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        findings = run_scan(tmp_path, _cfg())
    assert findings == []
    mock_scanner.run.assert_not_called()


def test_strict_mode_raises_on_unavailable_scanner(tmp_path):
    tf_file = tmp_path / "main.tf"
    tf_file.touch()

    mock_scanner = MagicMock()
    mock_scanner.extensions = [".tf"]
    mock_scanner.available.return_value = False
    mock_scanner._primary_tool.return_value = "checkov"

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [mock_scanner]):
        with pytest.raises(ScannerError):
            run_scan(tmp_path, _cfg(), strict=True)


# ── scanner_filter ────────────────────────────────────────────────────────────

def test_scanner_filter_selects_by_name(tmp_path):
    tf_file = tmp_path / "main.tf"
    tf_file.touch()

    class FakeTerraformScanner:
        extensions = [".tf"]
        def available(self): return True
        def run(self, _): return []
        def _primary_tool(self): return "checkov"

    class FakeBashScanner:
        extensions = [".sh"]
        def available(self): return True
        def run(self, _): return [_finding(file=str(tf_file))]
        def _primary_tool(self): return "shellcheck"

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [FakeTerraformScanner(), FakeBashScanner()]):
        findings = run_scan(tmp_path, _cfg(), scanner_filter="terraform")
    # bash scanner shouldn't run — no .sh files scanned either but TF scanner returns []
    assert findings == []


def test_scanner_filter_no_match_returns_empty(tmp_path):
    with patch("shieldctl.dispatcher._ALL_SCANNERS", []):
        findings = run_scan(tmp_path, _cfg(), scanner_filter="nonexistent")
    assert findings == []


# ── ScannerError handling ─────────────────────────────────────────────────────

def test_scanner_error_caught_and_scan_continues(tmp_path):
    """A ScannerError from one scanner shouldn't stop others from running."""
    tf_file = tmp_path / "main.tf"
    tf_file.touch()

    good_finding = _finding(file=str(tf_file), rule="GOOD_RULE", scanner="good")

    class FailingScanner:
        extensions = [".tf"]
        def available(self): return True
        def run(self, _): raise ScannerError("tool crashed")
        def _primary_tool(self): return "broken"

    class GoodScanner:
        extensions = [".tf"]
        def available(self): return True
        def run(self, _): return [good_finding]
        def _primary_tool(self): return "good"

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [FailingScanner(), GoodScanner()]):
        findings = run_scan(tmp_path, _cfg())

    assert len(findings) == 1
    assert findings[0].rule == "GOOD_RULE"


# ── file matching / empty targets ─────────────────────────────────────────────

def test_scanner_with_no_matching_files_not_run(tmp_path):
    """Scanner whose extensions don't match any file must never have run() called."""
    yaml_file = tmp_path / "config.yaml"
    yaml_file.touch()

    class TfScanner:
        extensions = [".tf"]
        def available(self): return True
        def run(self, paths):
            raise AssertionError("run() should not be called")
        def _primary_tool(self): return "checkov"

    with patch("shieldctl.dispatcher._ALL_SCANNERS", [TfScanner()]):
        findings = run_scan(tmp_path, _cfg())
    assert findings == []


# ── _is_excluded regression (G-04) ───────────────────────────────────────────

def test_is_excluded_doesnt_match_similar_dirname(tmp_path):
    """other_terraform/ must not be excluded by **/.terraform/**."""
    f = tmp_path / "other_terraform" / "main.tf"
    f.parent.mkdir()
    assert _is_excluded(f, tmp_path, ["**/.terraform/**"]) is False


def test_is_excluded_nested_terraform_dir(tmp_path):
    """Files deep inside .terraform/ must be excluded regardless of depth."""
    f = tmp_path / "infra" / ".terraform" / "modules" / "vpc" / "main.tf"
    f.parent.mkdir(parents=True)
    assert _is_excluded(f, tmp_path, ["**/.terraform/**"]) is True
