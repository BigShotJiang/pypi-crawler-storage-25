from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from shieldctl.models import Severity
from shieldctl.scanners.pip_audit import PipAuditScanner


def _mock_exec(stdout: str = "", stderr: str = ""):
    proc = MagicMock()
    proc.stdout = stdout
    proc.stderr = stderr
    proc.returncode = 0
    return proc


_SAMPLE_OUTPUT = json.dumps([
    {
        "name": "requests",
        "version": "2.25.0",
        "vulns": [
            {
                "id": "PYSEC-2023-74",
                "aliases": ["CVE-2023-32681"],
                "description": "Requests forwards proxy-authorization header to destination servers.",
                "fix_versions": ["2.31.0"],
            }
        ],
    },
    {
        "name": "flask",
        "version": "2.0.0",
        "vulns": [],  # no vulnerabilities
    },
])

_EMPTY_OUTPUT = json.dumps([])


def test_pip_audit_parses_vulnerability(tmp_path):
    scanner = PipAuditScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=_SAMPLE_OUTPUT)):
        findings = scanner.run([tmp_path])
    assert len(findings) == 1
    f = findings[0]
    assert f.rule == "pip-audit:PYSEC-2023-74"
    assert f.severity == Severity.HIGH
    assert "requests" in f.message
    assert "2.25.0" in f.message
    assert "CVE-2023-32681" in f.message or "2.31.0" in f.remediation
    assert f.scanner == "pip-audit"
    assert f.owasp is not None


def test_pip_audit_skips_package_with_no_vulns(tmp_path):
    scanner = PipAuditScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=_SAMPLE_OUTPUT)):
        findings = scanner.run([tmp_path])
    # flask has no vulns — only 1 finding (requests)
    assert len(findings) == 1
    assert all("flask" not in f.message for f in findings)


def test_pip_audit_empty_output(tmp_path):
    scanner = PipAuditScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=_EMPTY_OUTPUT)):
        findings = scanner.run([tmp_path])
    assert findings == []


def test_pip_audit_invalid_json_stdout_falls_back_to_stderr(tmp_path):
    scanner = PipAuditScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout="not-json", stderr="also-not-json")):
        findings = scanner.run([tmp_path])
    assert findings == []


def test_pip_audit_multiple_vulns_same_package(tmp_path):
    data = json.dumps([
        {
            "name": "pillow",
            "version": "9.0.0",
            "vulns": [
                {"id": "PYSEC-2023-1", "aliases": [], "description": "Vuln 1", "fix_versions": []},
                {"id": "PYSEC-2023-2", "aliases": [], "description": "Vuln 2", "fix_versions": ["9.5.0"]},
            ],
        }
    ])
    scanner = PipAuditScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=data)):
        findings = scanner.run([tmp_path])
    assert len(findings) == 2
    rules = {f.rule for f in findings}
    assert "pip-audit:PYSEC-2023-1" in rules
    assert "pip-audit:PYSEC-2023-2" in rules


def test_pip_audit_cve_alias_used(tmp_path):
    data = json.dumps([
        {
            "name": "somelib",
            "version": "1.0.0",
            "vulns": [
                {
                    "id": "PYSEC-2024-99",
                    "aliases": ["GHSA-xxxx-yyyy-zzzz", "CVE-2024-12345"],
                    "description": "Remote code execution",
                    "fix_versions": [],
                }
            ],
        }
    ])
    scanner = PipAuditScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=data)):
        findings = scanner.run([tmp_path])
    assert len(findings) == 1
    assert "CVE-2024-12345" in findings[0].message or findings[0].rule == "pip-audit:PYSEC-2024-99"


def test_pip_audit_no_fix_version_remediation(tmp_path):
    data = json.dumps([
        {
            "name": "oldlib",
            "version": "0.1.0",
            "vulns": [
                {"id": "PYSEC-2020-1", "aliases": [], "description": "Old vuln", "fix_versions": []},
            ],
        }
    ])
    scanner = PipAuditScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(stdout=data)):
        findings = scanner.run([tmp_path])
    assert "No fixed version" in findings[0].remediation


def test_pip_audit_primary_tool():
    assert PipAuditScanner()._primary_tool() == "pip-audit"


def test_pip_audit_repo_wide():
    assert PipAuditScanner().extensions == []


def test_pip_audit_uses_first_path_as_cwd(tmp_path):
    scanner = PipAuditScanner()
    called_cwd = []

    def fake_exec(cmd, cwd=None):
        called_cwd.append(cwd)
        return _mock_exec(stdout=_EMPTY_OUTPUT)

    with patch.object(scanner, "_exec", side_effect=fake_exec):
        scanner.run([tmp_path])
    assert called_cwd[0] == tmp_path
