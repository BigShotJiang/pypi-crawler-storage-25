"""Tests for DockerfileScanner (hadolint output parsing)."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from shieldctl.scanners.dockerfile import DockerfileScanner
from shieldctl.models import Severity

_scanner = DockerfileScanner()


def _fake_result(stdout: str, returncode: int = 0) -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr="")


def _patch(stdout: str, returncode: int = 0):
    return patch.object(_scanner, "_exec", return_value=_fake_result(stdout, returncode))


# ── output parsing ────────────────────────────────────────────────────────────

def test_hadolint_parses_single_issue(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    payload = json.dumps([{
        "file": str(dockerfile),
        "line": 3,
        "column": 1,
        "level": "warning",
        "code": "DL3008",
        "message": "Pin versions in apt get install.",
    }])
    with _patch(payload):
        findings = _scanner.run([dockerfile])
    assert len(findings) == 1
    assert findings[0].rule == "DL3008"
    assert findings[0].severity == Severity.MEDIUM
    assert findings[0].line == 3


def test_hadolint_error_level_maps_to_high(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    payload = json.dumps([{
        "file": str(dockerfile),
        "line": 1,
        "column": 1,
        "level": "error",
        "code": "DL1000",
        "message": "Invalid instruction.",
    }])
    with _patch(payload):
        findings = _scanner.run([dockerfile])
    assert findings[0].severity == Severity.HIGH


def test_hadolint_info_level_maps_to_low(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    payload = json.dumps([{
        "file": str(dockerfile),
        "line": 5,
        "column": 1,
        "level": "info",
        "code": "DL3059",
        "message": "Multiple consecutive RUN instructions.",
    }])
    with _patch(payload):
        findings = _scanner.run([dockerfile])
    assert findings[0].severity == Severity.LOW


def test_hadolint_style_level_maps_to_info(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    payload = json.dumps([{
        "file": str(dockerfile),
        "line": 7,
        "column": 1,
        "level": "style",
        "code": "DL4006",
        "message": "Set the SHELL option -o pipefail.",
    }])
    with _patch(payload):
        findings = _scanner.run([dockerfile])
    assert findings[0].severity == Severity.INFO


def test_hadolint_remediation_url_contains_code(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    payload = json.dumps([{
        "file": str(dockerfile),
        "line": 2,
        "column": 1,
        "level": "warning",
        "code": "DL3007",
        "message": "Using latest is best avoided.",
    }])
    with _patch(payload):
        findings = _scanner.run([dockerfile])
    assert "DL3007" in findings[0].remediation
    assert "hadolint" in findings[0].remediation


def test_hadolint_multiple_issues(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    payload = json.dumps([
        {"file": str(dockerfile), "line": 2, "column": 1, "level": "warning",
         "code": "DL3007", "message": "Using latest."},
        {"file": str(dockerfile), "line": 5, "column": 1, "level": "error",
         "code": "DL1000", "message": "Invalid."},
    ])
    with _patch(payload):
        findings = _scanner.run([dockerfile])
    assert len(findings) == 2


def test_hadolint_empty_output(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    with _patch("[]"):
        findings = _scanner.run([dockerfile])
    assert findings == []


def test_hadolint_invalid_json_returns_empty(tmp_path):
    dockerfile = tmp_path / "Dockerfile"
    dockerfile.touch()
    with _patch("not json at all"):
        findings = _scanner.run([dockerfile])
    assert findings == []


def test_hadolint_scanner_label():
    assert _scanner._primary_tool() == "hadolint"


def test_dockerfile_extensions():
    assert ".dockerfile" in _scanner.extensions or "Dockerfile" in _scanner.extensions


def test_non_dockerfile_files_skipped(tmp_path):
    regular = tmp_path / "main.tf"
    regular.touch()
    with patch.object(_scanner, "_exec") as mock_exec:
        _scanner.run([regular])
        mock_exec.assert_not_called()


def test_dockerfile_variant_names_accepted(tmp_path):
    """Dockerfile.prod, Dockerfile.dev etc. should all be scanned."""
    df_prod = tmp_path / "Dockerfile.prod"
    df_prod.touch()
    payload = json.dumps([])
    with _patch(payload) as mock_exec:
        _scanner.run([df_prod])
        mock_exec.assert_called_once()
