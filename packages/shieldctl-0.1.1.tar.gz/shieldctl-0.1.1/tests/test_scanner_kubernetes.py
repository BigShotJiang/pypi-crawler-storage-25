from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from shieldctl.models import Severity
from shieldctl.scanners.kubernetes import KubernetesScanner, _is_k8s_manifest


# ── content detection helpers ─────────────────────────────────────────────────

def test_is_k8s_manifest_true(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: app\n")
    assert _is_k8s_manifest(f) is True


def test_is_k8s_manifest_missing_kind(tmp_path):
    f = tmp_path / "notk8s.yaml"
    f.write_text("apiVersion: apps/v1\nmetadata:\n  name: app\n")
    assert _is_k8s_manifest(f) is False


def test_is_k8s_manifest_missing_apiversion(tmp_path):
    f = tmp_path / "notk8s.yaml"
    f.write_text("kind: Deployment\nmetadata:\n  name: app\n")
    assert _is_k8s_manifest(f) is False


def test_is_k8s_manifest_gha_content(tmp_path):
    f = tmp_path / "workflow.yaml"
    f.write_text("on: push\njobs:\n  build:\n    runs-on: ubuntu-latest\n")
    assert _is_k8s_manifest(f) is False


def test_is_k8s_manifest_nonexistent():
    assert _is_k8s_manifest(Path("/nonexistent/path.yaml")) is False


# ── scanner run() ─────────────────────────────────────────────────────────────

def _mock_exec(stdout: str):
    proc = MagicMock()
    proc.stdout = stdout
    proc.returncode = 0
    return proc


_CHECKOV_RESULT = json.dumps({
    "results": {
        "failed_checks": [
            {
                "check_id": "CKV_K8S_28",
                "description": "Do not admit containers with the NET_RAW capability",
                "file_path": "/k8s/deploy.yaml",
                "file_line_range": [5, 20],
                "guideline": "https://docs.bridgecrew.io/docs/bc_k8s_28",
            }
        ]
    }
})


def test_kubernetes_scanner_parses_failed_check(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\n")
    scanner = KubernetesScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(_CHECKOV_RESULT)):
        findings = scanner.run([f])
    assert len(findings) == 1
    assert findings[0].rule == "CKV_K8S_28"
    assert findings[0].scanner == "checkov-k8s"
    assert findings[0].severity == Severity.MEDIUM
    assert findings[0].owasp is not None


def test_kubernetes_scanner_skips_non_k8s_file(tmp_path):
    f = tmp_path / "docker-compose.yaml"
    f.write_text("version: '3'\nservices:\n  app:\n    image: nginx\n")
    scanner = KubernetesScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec(_CHECKOV_RESULT)) as mock_exec:
        findings = scanner.run([f])
    assert findings == []
    mock_exec.assert_not_called()


def test_kubernetes_scanner_empty_failed_checks(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\n")
    scanner = KubernetesScanner()
    result = json.dumps({"results": {"failed_checks": []}})
    with patch.object(scanner, "_exec", return_value=_mock_exec(result)):
        findings = scanner.run([f])
    assert findings == []


def test_kubernetes_scanner_invalid_json(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\n")
    scanner = KubernetesScanner()
    with patch.object(scanner, "_exec", return_value=_mock_exec("not-json")):
        findings = scanner.run([f])
    assert findings == []


def test_kubernetes_scanner_list_response(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\n")
    scanner = KubernetesScanner()
    result = json.dumps([
        {"results": {"failed_checks": [
            {"check_id": "CKV_K8S_1", "description": "Test", "file_path": str(f)}
        ]}}
    ])
    with patch.object(scanner, "_exec", return_value=_mock_exec(result)):
        findings = scanner.run([f])
    assert len(findings) == 1
    assert findings[0].rule == "CKV_K8S_1"


def test_kubernetes_scanner_multiple_files(tmp_path):
    files = []
    for i in range(3):
        f = tmp_path / f"deploy{i}.yaml"
        f.write_text(f"apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: app{i}\n")
        files.append(f)
    scanner = KubernetesScanner()
    result = json.dumps({"results": {"failed_checks": [
        {"check_id": "CKV_K8S_1", "description": "Test", "file_path": "x.yaml"}
    ]}})
    with patch.object(scanner, "_exec", return_value=_mock_exec(result)):
        findings = scanner.run(files)
    assert len(findings) == 3  # one finding per file


def test_kubernetes_scanner_primary_tool():
    assert KubernetesScanner()._primary_tool() == "checkov"


def test_kubernetes_scanner_extensions():
    exts = KubernetesScanner().extensions
    assert ".yaml" in exts
    assert ".yml" in exts


def test_kubernetes_scanner_no_line_range(tmp_path):
    f = tmp_path / "deploy.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\n")
    scanner = KubernetesScanner()
    result = json.dumps({"results": {"failed_checks": [
        {"check_id": "CKV_K8S_1", "description": "Test", "file_path": str(f)}
        # no file_line_range key
    ]}})
    with patch.object(scanner, "_exec", return_value=_mock_exec(result)):
        findings = scanner.run([f])
    assert findings[0].line is None
