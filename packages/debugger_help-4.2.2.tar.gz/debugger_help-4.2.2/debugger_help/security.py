"""
Security Engine — Process classification, threat scoring, persistence scanning.
Part of the debugger.help incident response system.
"""

import os
import re
import json
import time
import shutil
import signal
import subprocess
from datetime import datetime, timezone

try:
    import psutil
except ImportError:
    psutil = None


# =============================================================================
# Process Classification
# =============================================================================

ALLOWED_PROCESSES = {
    # System
    "systemd", "init", "sshd", "cron", "crond", "bash", "sh", "zsh", "login",
    "su", "sudo", "rsyslogd", "journald", "udevd", "dbus-daemon", "polkitd",
    "networkd", "resolved", "timesyncd", "agetty", "getty",
    # Docker
    "dockerd", "containerd", "containerd-shim", "runc", "docker-proxy",
    # Node / PM2
    "node", "npm", "npx", "pm2", "PM2", "yarn", "pnpm", "bun",
    # Python
    "python", "python3", "python3.10", "python3.11", "python3.12", "pip", "pip3",
    # GPU / CUDA
    "nvidia-smi", "nvidia-persistenced", "nvidia-cuda-mps",
    # Our services
    "yourstudio", "comfyui", "ComfyUI", "llama", "llama-server",
    "chatterbox", "debugger-agent", "debugger_agent",
    # Common system tools
    "top", "htop", "ps", "grep", "find", "cat", "less", "tail", "head",
    "curl", "wget", "git", "make", "gcc", "g++", "cc", "ld",
    "tar", "gzip", "zip", "unzip", "rsync", "scp", "sftp",
    "screen", "tmux", "vim", "nano", "vi",
    # Monitoring
    "prometheus", "grafana", "telegraf", "collectd",
    # Web servers
    "nginx", "apache2", "httpd", "caddy",
    # Databases
    "postgres", "postgresql", "mysql", "mysqld", "redis-server", "mongod",
}

BLOCKED_SIGNATURES = [
    # Mining software
    re.compile(r"xmrig", re.IGNORECASE),
    re.compile(r"rigel", re.IGNORECASE),
    re.compile(r"monero", re.IGNORECASE),
    re.compile(r"kryptex", re.IGNORECASE),
    re.compile(r"stratum\+", re.IGNORECASE),
    re.compile(r"ethminer", re.IGNORECASE),
    re.compile(r"phoenixminer", re.IGNORECASE),
    re.compile(r"t-rex", re.IGNORECASE),
    re.compile(r"nbminer", re.IGNORECASE),
    re.compile(r"gminer", re.IGNORECASE),
    re.compile(r"lolminer", re.IGNORECASE),
    re.compile(r"claymore", re.IGNORECASE),
    re.compile(r"bfgminer", re.IGNORECASE),
    re.compile(r"cgminer", re.IGNORECASE),
    re.compile(r"cpuminer", re.IGNORECASE),
    re.compile(r"minerd", re.IGNORECASE),
    re.compile(r"minergate", re.IGNORECASE),
    # Mining arguments
    re.compile(r"--coin\s+monero", re.IGNORECASE),
    re.compile(r"--algo\s+random", re.IGNORECASE),
    re.compile(r"--donate-level", re.IGNORECASE),
    re.compile(r"pool\.(minergate|hashvault|nanopool|supportxmr|herominers)", re.IGNORECASE),
    # Hidden path patterns (executables in dotdirs)
    re.compile(r"/\.[a-z]+/(bin|lib|tmp)/", re.IGNORECASE),
    re.compile(r"\.cache/[a-z]+miner", re.IGNORECASE),
    re.compile(r"\.dbus/sessions?/[a-z0-9]+", re.IGNORECASE),
    re.compile(r"\.local/share/[a-z]+min", re.IGNORECASE),
]

# Mining pool ports
SUSPICIOUS_PORTS = {3333, 4444, 5555, 14433, 14444, 13333, 45700, 10128}


def _is_allowed_process(name, cmdline):
    """Check if a process name or its base binary is in the allowed list."""
    if not name:
        return False
    name_lower = name.lower()
    for allowed in ALLOWED_PROCESSES:
        if name_lower == allowed.lower():
            return True
    # Check if the binary in cmdline is allowed
    if cmdline:
        binary = os.path.basename(cmdline[0]) if cmdline else ""
        for allowed in ALLOWED_PROCESSES:
            if binary.lower() == allowed.lower():
                return True
    return False


def _check_blocked(cmdline_str):
    """Check cmdline against blocked signatures. Returns list of matched patterns."""
    matches = []
    for pattern in BLOCKED_SIGNATURES:
        if pattern.search(cmdline_str):
            matches.append(pattern.pattern)
    return matches


def classify_processes():
    """Classify all running processes into allowed, suspicious, and malicious."""
    if not psutil:
        return {"error": "psutil not available", "allowed": [], "suspicious": [], "malicious": []}

    allowed = []
    suspicious = []
    malicious = []

    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent",
                                      "status", "create_time", "cmdline", "username"]):
        try:
            info = proc.info
            pid = info["pid"]
            name = info["name"] or ""
            cmdline = info.get("cmdline") or []
            cmdline_str = " ".join(cmdline)
            cpu_pct = info.get("cpu_percent") or 0
            mem_pct = round(info.get("memory_percent") or 0, 1)
            username = info.get("username") or ""
            create_time = info.get("create_time") or 0

            entry = {
                "pid": pid,
                "name": name,
                "cmdline": cmdline_str[:300],
                "cpu_pct": cpu_pct,
                "mem_pct": mem_pct,
                "username": username,
                "started": datetime.fromtimestamp(create_time, tz=timezone.utc).isoformat() if create_time else None,
            }

            # Check blocked signatures first
            blocked_matches = _check_blocked(cmdline_str)
            if blocked_matches:
                entry["confidence"] = 95
                entry["reasoning"] = "Matches blocked signature: {}".format(", ".join(blocked_matches[:3]))
                entry["matched_patterns"] = blocked_matches
                malicious.append(entry)
                continue

            # Check if running from hidden path
            if cmdline and len(cmdline) > 0:
                exe_path = cmdline[0]
                if re.search(r"/\.[a-z_]+/", exe_path) and not any(
                    ok in exe_path for ok in [".npm", ".nvm", ".pm2", ".local/bin", ".pyenv", ".cache/pip"]
                ):
                    entry["confidence"] = 60
                    entry["reasoning"] = "Running from hidden directory: {}".format(exe_path[:100])
                    suspicious.append(entry)
                    continue

            # Check if allowed
            if _is_allowed_process(name, cmdline):
                entry["confidence"] = 100
                allowed.append(entry)
            else:
                # Unknown process — suspicious
                entry["confidence"] = 30
                entry["reasoning"] = "Unknown process not in allowed list"
                suspicious.append(entry)

        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    return {
        "allowed": allowed,
        "suspicious": suspicious,
        "malicious": malicious,
        "summary": {
            "total": len(allowed) + len(suspicious) + len(malicious),
            "allowed_count": len(allowed),
            "suspicious_count": len(suspicious),
            "malicious_count": len(malicious),
        },
    }


# =============================================================================
# Threat Scoring
# =============================================================================

def compute_threat_score(classification, gpu_metrics=None):
    """Compute a weighted 0-100 threat score."""
    score = 0
    reasons = []

    # Mining signatures detected (weight: 80)
    malicious_count = len(classification.get("malicious", []))
    if malicious_count > 0:
        score += min(80, malicious_count * 40)
        reasons.append("{} malicious process(es) detected".format(malicious_count))

    # Suspicious processes in hidden paths (weight: 20)
    hidden_path_count = sum(
        1 for s in classification.get("suspicious", [])
        if "hidden directory" in (s.get("reasoning") or "")
    )
    if hidden_path_count > 0:
        score += min(20, hidden_path_count * 10)
        reasons.append("{} process(es) running from hidden paths".format(hidden_path_count))

    # GPU saturation with unknown/malicious process (weight: 40)
    if gpu_metrics:
        gpus = gpu_metrics.get("gpus", [])
        for gpu in gpus:
            util = gpu.get("gpu_util_pct", 0)
            if util > 90:
                # Check if GPU processes are all known
                gpu_procs = gpu.get("processes", [])
                unknown_gpu_procs = []
                for gp in gpu_procs:
                    gp_name = gp.get("name", "")
                    if not _is_allowed_process(gp_name, []):
                        unknown_gpu_procs.append(gp_name)
                if unknown_gpu_procs:
                    score += 40
                    reasons.append("GPU at {}% with unknown process(es): {}".format(
                        util, ", ".join(unknown_gpu_procs[:3])
                    ))

    # Suspicious outbound connections (weight: 30)
    try:
        suspicious_conns = _check_suspicious_connections()
        if suspicious_conns:
            score += min(30, len(suspicious_conns) * 15)
            reasons.append("{} suspicious outbound connection(s)".format(len(suspicious_conns)))
    except Exception:
        pass

    return {
        "score": min(100, score),
        "level": "critical" if score >= 70 else "high" if score >= 50 else "medium" if score >= 30 else "low",
        "reasons": reasons,
    }


def _check_suspicious_connections():
    """Check for outbound connections to suspicious ports."""
    suspicious = []
    if not psutil:
        return suspicious
    try:
        for conn in psutil.net_connections(kind="tcp"):
            if conn.status == "ESTABLISHED" and conn.raddr:
                if conn.raddr.port in SUSPICIOUS_PORTS:
                    proc_name = ""
                    try:
                        if conn.pid:
                            proc_name = psutil.Process(conn.pid).name()
                    except Exception:
                        pass
                    suspicious.append({
                        "pid": conn.pid,
                        "process": proc_name,
                        "remote_addr": "{}:{}".format(conn.raddr.ip, conn.raddr.port),
                        "local_port": conn.laddr.port if conn.laddr else None,
                    })
    except Exception:
        pass
    return suspicious


# =============================================================================
# Persistence Scanner
# =============================================================================

def persistence_scan():
    """Scan for persistence mechanisms and return findings with confidence scores."""
    findings = []

    # 1. Crontab entries
    try:
        cron_output = subprocess.run(
            "crontab -l 2>/dev/null", shell=True, capture_output=True, text=True, timeout=5
        ).stdout.strip()
        if cron_output and "no crontab" not in cron_output.lower():
            for i, line in enumerate(cron_output.split("\n")):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                confidence = 20
                reasoning = "Standard cron entry"
                blocked = _check_blocked(line)
                if blocked:
                    confidence = 90
                    reasoning = "Cron entry matches blocked signature: {}".format(", ".join(blocked[:2]))
                elif re.search(r"/\.[a-z_]+/", line):
                    confidence = 70
                    reasoning = "Cron entry references hidden directory"
                elif re.search(r"(curl|wget)\s.*\|\s*(sh|bash)", line):
                    confidence = 80
                    reasoning = "Cron entry downloads and executes script"
                elif re.search(r"@reboot", line):
                    confidence = 40
                    reasoning = "Runs at system boot"
                findings.append({
                    "type": "crontab",
                    "line_number": i + 1,
                    "content": line[:300],
                    "confidence": confidence,
                    "reasoning": reasoning,
                    "suspicious": confidence >= 50,
                })
    except Exception as e:
        findings.append({"type": "crontab", "error": str(e)})

    # 2. Systemd services
    try:
        user_services = subprocess.run(
            "ls /etc/systemd/system/*.service 2>/dev/null", shell=True,
            capture_output=True, text=True, timeout=5
        ).stdout.strip()
        if user_services:
            known_services = {
                "docker.service", "nginx.service", "sshd.service", "cron.service",
                "getty@.service", "NetworkManager.service", "systemd-resolved.service",
                "ufw.service", "rsyslog.service", "snapd.service",
            }
            for svc_path in user_services.split("\n"):
                svc_name = os.path.basename(svc_path.strip())
                if not svc_name:
                    continue
                confidence = 10
                reasoning = "Known system service"
                if svc_name not in known_services:
                    # Read ExecStart to check
                    try:
                        content = subprocess.run(
                            "cat {} 2>/dev/null".format(svc_path.strip()),
                            shell=True, capture_output=True, text=True, timeout=3
                        ).stdout
                        blocked = _check_blocked(content)
                        if blocked:
                            confidence = 90
                            reasoning = "Service matches blocked signature: {}".format(", ".join(blocked[:2]))
                        elif re.search(r"/\.[a-z_]+/", content):
                            confidence = 65
                            reasoning = "Service references hidden directory"
                        elif re.search(r"[a-z0-9]{20,}", svc_name):
                            confidence = 50
                            reasoning = "Service has random/obfuscated name"
                        else:
                            confidence = 25
                            reasoning = "Non-standard service"
                    except Exception:
                        confidence = 30
                        reasoning = "Could not read service file"

                findings.append({
                    "type": "systemd_service",
                    "name": svc_name,
                    "path": svc_path.strip(),
                    "confidence": confidence,
                    "reasoning": reasoning,
                    "suspicious": confidence >= 50,
                })
    except Exception as e:
        findings.append({"type": "systemd_service", "error": str(e)})

    # 3. PM2 processes
    try:
        pm2_raw = subprocess.run(
            "pm2 jlist 2>/dev/null", shell=True, capture_output=True, text=True, timeout=10
        ).stdout.strip()
        if pm2_raw and pm2_raw.startswith("["):
            pm2_procs = json.loads(pm2_raw)
            known_pm2 = {"yourstudio-gpu", "debugger-agent", "comfyui", "llama-server", "chatterbox"}
            for proc in pm2_procs:
                name = proc.get("name", "")
                script = proc.get("pm2_env", {}).get("pm_exec_path", "")
                confidence = 10
                reasoning = "Known PM2 process"
                if name.lower() not in known_pm2:
                    blocked = _check_blocked(name + " " + script)
                    if blocked:
                        confidence = 90
                        reasoning = "PM2 process matches blocked signature"
                    elif re.search(r"/\.[a-z_]+/", script):
                        confidence = 65
                        reasoning = "PM2 process runs from hidden directory"
                    else:
                        confidence = 30
                        reasoning = "Unknown PM2 process"
                findings.append({
                    "type": "pm2_process",
                    "name": name,
                    "script": script[:200],
                    "status": proc.get("pm2_env", {}).get("status", "unknown"),
                    "confidence": confidence,
                    "reasoning": reasoning,
                    "suspicious": confidence >= 50,
                })
    except (json.JSONDecodeError, Exception) as e:
        findings.append({"type": "pm2_process", "error": str(e)})

    # 4. SSH authorized_keys
    try:
        auth_keys_paths = [
            os.path.expanduser("~/.ssh/authorized_keys"),
            "/root/.ssh/authorized_keys",
        ]
        for ak_path in auth_keys_paths:
            if os.path.exists(ak_path):
                with open(ak_path, "r") as f:
                    keys = f.readlines()
                for i, key in enumerate(keys):
                    key = key.strip()
                    if not key or key.startswith("#"):
                        continue
                    parts = key.split()
                    comment = parts[-1] if len(parts) >= 3 else "no comment"
                    confidence = 20
                    reasoning = "SSH key with comment: {}".format(comment[:50])
                    # Check for suspicious patterns
                    if re.search(r"command=", key):
                        confidence = 60
                        reasoning = "SSH key with forced command — may be used for persistence"
                    elif comment in ("", "no comment") or re.search(r"[a-z0-9]{20,}@", comment):
                        confidence = 45
                        reasoning = "SSH key with generic/suspicious comment"
                    findings.append({
                        "type": "ssh_authorized_key",
                        "file": ak_path,
                        "line": i + 1,
                        "key_type": parts[0] if parts else "unknown",
                        "comment": comment[:100],
                        "confidence": confidence,
                        "reasoning": reasoning,
                        "suspicious": confidence >= 50,
                    })
    except Exception as e:
        findings.append({"type": "ssh_authorized_key", "error": str(e)})

    suspicious_findings = [f for f in findings if f.get("suspicious")]
    return {
        "findings": findings,
        "suspicious_count": len(suspicious_findings),
        "total_checked": len(findings),
        "summary": "Found {} suspicious persistence mechanism(s)".format(len(suspicious_findings))
        if suspicious_findings else "No suspicious persistence mechanisms found",
    }


# =============================================================================
# Security Action Handlers (with built-in verification)
# =============================================================================

QUARANTINE_DIR = "/root/quarantine"

# Safe parent directories for quarantine_path
ALLOWED_QUARANTINE_PARENTS = {"/tmp", "/home", "/root", "/var/tmp", "/opt", "/workspace"}


def _run_cmd(cmd, timeout=10):
    """Run a shell command, return stdout+stderr."""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return (result.stdout + result.stderr).strip()
    except subprocess.TimeoutExpired:
        return "[timeout after {}s]".format(timeout)
    except Exception as e:
        return "[error: {}]".format(e)


def action_kill_process(payload):
    """Kill a process by PID with verification."""
    pid = payload.get("pid") if payload else None
    if not pid:
        return {"success": False, "output": "Missing 'pid' in payload", "verification": {"check": "pid_exists", "passed": False, "details": "No PID provided"}}

    pid = int(pid)

    # Safety: don't kill ourselves or init
    if pid in (os.getpid(), 1):
        return {"success": False, "output": "Cannot kill this process (protected PID)", "verification": {"check": "protected", "passed": False, "details": "PID {} is protected".format(pid)}}

    try:
        proc = psutil.Process(pid)
        proc_name = proc.name()
        proc_cmdline = " ".join(proc.cmdline()[:5])
    except psutil.NoSuchProcess:
        return {"success": False, "output": "PID {} does not exist".format(pid), "verification": {"check": "pid_exists", "passed": True, "details": "Process already gone"}}

    try:
        os.kill(pid, signal.SIGKILL)
        time.sleep(0.5)
    except ProcessLookupError:
        pass
    except PermissionError:
        return {"success": False, "output": "Permission denied killing PID {}".format(pid), "verification": {"check": "kill", "passed": False, "details": "Insufficient permissions"}}

    # Verify
    still_alive = psutil.pid_exists(pid)
    return {
        "success": not still_alive,
        "output": "Killed process {} (PID {}, cmd: {})".format(proc_name, pid, proc_cmdline[:100]) if not still_alive else "Failed to kill PID {}".format(pid),
        "verification": {
            "check": "pid_gone",
            "passed": not still_alive,
            "details": "PID {} is {}".format(pid, "gone" if not still_alive else "STILL RUNNING"),
        },
    }


def action_quarantine_path(payload):
    """Move a file/directory to quarantine instead of deleting."""
    path = payload.get("path") if payload else None
    if not path:
        return {"success": False, "output": "Missing 'path' in payload", "verification": {"check": "path", "passed": False, "details": "No path provided"}}

    path = os.path.abspath(path)

    # Safety: only allow quarantining from specific parent directories
    allowed = False
    for parent in ALLOWED_QUARANTINE_PARENTS:
        if path.startswith(parent + "/"):
            allowed = True
            break
    if not allowed:
        return {"success": False, "output": "Path {} is not in an allowed directory for quarantine".format(path), "verification": {"check": "allowed_path", "passed": False, "details": "Only paths under {} can be quarantined".format(", ".join(sorted(ALLOWED_QUARANTINE_PARENTS)))}}

    if not os.path.exists(path):
        return {"success": False, "output": "Path does not exist: {}".format(path), "verification": {"check": "exists", "passed": False, "details": "Path not found"}}

    os.makedirs(QUARANTINE_DIR, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    dest_name = "{}_{}".format(timestamp, os.path.basename(path))
    dest = os.path.join(QUARANTINE_DIR, dest_name)

    try:
        shutil.move(path, dest)
    except Exception as e:
        return {"success": False, "output": "Failed to quarantine: {}".format(e), "verification": {"check": "move", "passed": False, "details": str(e)}}

    source_gone = not os.path.exists(path)
    dest_exists = os.path.exists(dest)
    return {
        "success": source_gone and dest_exists,
        "output": "Quarantined {} -> {}".format(path, dest),
        "verification": {
            "check": "quarantine",
            "passed": source_gone and dest_exists,
            "details": "Source removed: {}, Quarantined at: {}".format(source_gone, dest),
        },
    }


def action_disable_service(payload):
    """Stop and disable a systemd service with verification."""
    service = payload.get("service") if payload else None
    if not service:
        return {"success": False, "output": "Missing 'service' in payload", "verification": {"check": "service", "passed": False, "details": "No service name provided"}}

    # Sanitize
    service = re.sub(r"[^a-zA-Z0-9_\-@.]", "", service)
    if not service.endswith(".service"):
        service += ".service"

    output = _run_cmd("sudo systemctl stop {} && sudo systemctl disable {}".format(service, service), timeout=15)
    time.sleep(1)

    # Verify
    status = _run_cmd("systemctl is-active {} 2>/dev/null".format(service), timeout=5)
    is_inactive = status.strip() in ("inactive", "dead", "failed")
    enabled = _run_cmd("systemctl is-enabled {} 2>/dev/null".format(service), timeout=5)
    is_disabled = enabled.strip() in ("disabled", "masked")

    return {
        "success": is_inactive and is_disabled,
        "output": "Service {}: status={}, enabled={}.\n{}".format(service, status.strip(), enabled.strip(), output),
        "verification": {
            "check": "service_state",
            "passed": is_inactive and is_disabled,
            "details": "Active: {}, Enabled: {}".format(status.strip(), enabled.strip()),
        },
    }


def action_remove_cron(payload):
    """Remove a crontab entry by line number with verification."""
    line_num = payload.get("line") if payload else None
    if not line_num:
        return {"success": False, "output": "Missing 'line' in payload", "verification": {"check": "line", "passed": False, "details": "No line number provided"}}

    line_num = int(line_num)

    cron = subprocess.run("crontab -l 2>/dev/null", shell=True, capture_output=True, text=True, timeout=5).stdout
    lines = cron.split("\n")
    if line_num < 1 or line_num > len(lines):
        return {"success": False, "output": "Line {} out of range (crontab has {} lines)".format(line_num, len(lines)), "verification": {"check": "range", "passed": False, "details": "Invalid line number"}}

    removed_line = lines[line_num - 1]
    new_lines = [l for i, l in enumerate(lines) if i != line_num - 1]
    new_cron = "\n".join(new_lines)

    result = subprocess.run("echo '{}' | crontab -".format(new_cron.replace("'", "\\'")), shell=True, capture_output=True, text=True, timeout=5)

    # Verify
    updated = subprocess.run("crontab -l 2>/dev/null", shell=True, capture_output=True, text=True, timeout=5).stdout
    line_gone = removed_line.strip() not in updated

    return {
        "success": line_gone,
        "output": "Removed cron line {}: {}\nUpdated crontab:\n{}".format(line_num, removed_line.strip(), updated),
        "verification": {
            "check": "line_removed",
            "passed": line_gone,
            "details": "Line '{}' {}".format(removed_line.strip()[:80], "removed" if line_gone else "STILL PRESENT"),
        },
    }


def action_restart_service(payload):
    """Restart a systemd service with verification."""
    service = payload.get("service") if payload else None
    if not service:
        return {"success": False, "output": "Missing 'service' in payload", "verification": {"check": "service", "passed": False, "details": "No service name provided"}}

    service = re.sub(r"[^a-zA-Z0-9_\-@.]", "", service)
    if not service.endswith(".service"):
        service += ".service"

    output = _run_cmd("sudo systemctl restart {}".format(service), timeout=15)
    time.sleep(3)

    status = _run_cmd("systemctl is-active {} 2>/dev/null".format(service), timeout=5)
    is_active = status.strip() == "active"

    return {
        "success": is_active,
        "output": "Restart {}: {}\n{}".format(service, status.strip(), output),
        "verification": {
            "check": "service_active",
            "passed": is_active,
            "details": "Service status: {}".format(status.strip()),
        },
    }


def action_block_outbound(payload):
    """Block outbound connections to an IP or port via UFW."""
    ip = payload.get("ip") if payload else None
    port = payload.get("port") if payload else None

    if not ip and not port:
        return {"success": False, "output": "Missing 'ip' or 'port' in payload", "verification": {"check": "params", "passed": False, "details": "Need ip or port"}}

    if ip:
        cmd = "sudo ufw deny out to {}".format(ip)
    else:
        cmd = "sudo ufw deny out {}".format(port)

    output = _run_cmd(cmd, timeout=10)

    # Verify
    rules = _run_cmd("sudo ufw status verbose 2>/dev/null", timeout=5)
    target = ip or str(port)
    rule_exists = target in rules

    return {
        "success": rule_exists,
        "output": "UFW rule: {}\n{}".format(cmd, output),
        "verification": {
            "check": "ufw_rule",
            "passed": rule_exists,
            "details": "Rule for {} {}".format(target, "found in UFW" if rule_exists else "NOT FOUND"),
        },
    }


def action_list_connections():
    """List active network connections with process info."""
    output = _run_cmd("ss -tunp", timeout=10)
    # Also get structured data
    connections = []
    if psutil:
        try:
            for conn in psutil.net_connections(kind="tcp"):
                if conn.status == "ESTABLISHED" and conn.raddr:
                    proc_name = ""
                    try:
                        if conn.pid:
                            proc_name = psutil.Process(conn.pid).name()
                    except Exception:
                        pass
                    entry = {
                        "pid": conn.pid,
                        "process": proc_name,
                        "local": "{}:{}".format(conn.laddr.ip, conn.laddr.port) if conn.laddr else "",
                        "remote": "{}:{}".format(conn.raddr.ip, conn.raddr.port),
                        "status": conn.status,
                    }
                    if conn.raddr.port in SUSPICIOUS_PORTS:
                        entry["suspicious"] = True
                        entry["reason"] = "Port {} is a known mining pool port".format(conn.raddr.port)
                    connections.append(entry)
        except Exception:
            pass

    structured = json.dumps({
        "connections": connections[:100],
        "total": len(connections),
        "suspicious": [c for c in connections if c.get("suspicious")],
    }, indent=2)

    return {
        "success": True,
        "output": "{}\n\n--- Structured ---\n{}".format(output[:10000], structured),
    }


def action_security_scan(gpu_metrics=None):
    """Full security scan: classify processes + persistence scan + threat score."""
    classification = classify_processes()
    persistence = persistence_scan()
    threat = compute_threat_score(classification, gpu_metrics)

    return {
        "success": True,
        "output": json.dumps({
            "threat_score": threat,
            "process_classification": {
                "summary": classification.get("summary"),
                "malicious": classification.get("malicious", []),
                "suspicious": classification.get("suspicious", [])[:20],
            },
            "persistence": persistence,
        }, indent=2),
    }


# =============================================================================
# Cost Estimation
# =============================================================================

# Rough estimates — configurable via env
HOURLY_GPU_RATE = float(os.environ.get("DEBUGGER_GPU_HOURLY_RATE", "1.50"))  # $/hr


def estimate_cost_impact(gpu_metrics=None, classification=None):
    """Estimate resource waste from malicious processes."""
    if not gpu_metrics or not classification:
        return None

    malicious = classification.get("malicious", [])
    if not malicious:
        return None

    total_gpu_util = 0
    total_cpu = 0
    for proc in malicious:
        total_cpu += proc.get("cpu_pct", 0)
        # Rough GPU estimation — if process is in GPU process list
    
    gpus = gpu_metrics.get("gpus", [])
    for gpu in gpus:
        gpu_procs = gpu.get("processes", [])
        for gp in gpu_procs:
            for mp in malicious:
                if gp.get("pid") == mp.get("pid"):
                    total_gpu_util += gpu.get("gpu_util_pct", 0)

    waste_per_hour = (total_gpu_util / 100.0) * HOURLY_GPU_RATE

    return {
        "gpu_util_stolen_pct": total_gpu_util,
        "cpu_stolen_pct": round(total_cpu, 1),
        "estimated_waste_per_hour_usd": round(waste_per_hour, 2),
        "estimated_waste_per_day_usd": round(waste_per_hour * 24, 2),
    }
