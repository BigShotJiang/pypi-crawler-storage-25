# Copyright 2026 OpenC3, Inc.
# All Rights Reserved.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE.md for more details.
#
# This file may also be used under the terms of a commercial license
# if purchased from OpenC3, Inc.

import json
import time

from openc3.top_level import CriticalCmdError, HazardousError
from openc3.topics.topic import Topic
from openc3.utilities.json import JsonEncoder
from openc3.utilities.store import Store
from openc3.utilities.store_queued import EphemeralStoreQueued
from openc3.utilities.time import to_nsec_from_epoch


class CommandTopic(Topic):
    COMMAND_ACK_TIMEOUT_S = 30

    @classmethod
    def write_packet(cls, packet, scope):
        topic = f"{scope}__COMMAND__{{{packet.target_name}}}__{packet.packet_name}"
        msg_hash = {
            "time": to_nsec_from_epoch(packet.packet_time),
            "received_time": to_nsec_from_epoch(packet.received_time),
            "target_name": packet.target_name,
            "packet_name": packet.packet_name,
            "received_count": packet.received_count,
            "stored": str(packet.stored),
            "buffer": bytes(packet.buffer_no_copy()),
        }
        if packet.extra:
            msg_hash["extra"] = json.dumps(packet.extra)
        db_shard = Store.db_shard_for_target(packet.target_name, scope=scope)
        EphemeralStoreQueued.instance(db_shard=db_shard).write_topic(topic, msg_hash)

    @classmethod
    def send_command(cls, command, timeout, scope, obfuscated_items=None):
        """Send a command to a target.

        Args:
            command: Command hash structure to be written to a topic
            timeout: Timeout in seconds. Set to 0 or negative for fire-and-forget mode (no ACK waiting).
            scope: COSMOS scope
            obfuscated_items: List of obfuscated items
        """
        if obfuscated_items is None:
            obfuscated_items = []
        if timeout is None:
            timeout = cls.COMMAND_ACK_TIMEOUT_S
        # Save the existing cmd_params Hash and JSON generate before writing to the topic
        cmd_params = command["cmd_params"]
        command["cmd_params"] = json.dumps(command["cmd_params"], cls=JsonEncoder)

        db_shard = Store.db_shard_for_target(command["target_name"], scope=scope)

        # Fire-and-forget mode: skip ACK waiting when timeout <= 0
        if timeout <= 0:
            Topic.write_topic(
                f"{{{scope}__CMD}}TARGET__{command['target_name']}",
                command,
                "*",
                100,
                db_shard=db_shard,
            )
            command["cmd_params"] = cmd_params  # Restore the original cmd_params dict
            return command

        ack_topic = f"{{{scope}__ACKCMD}}TARGET__{command['target_name']}"
        Topic.update_topic_offsets([ack_topic], db_shard=db_shard)
        cmd_id = Topic.write_topic(
            f"{{{scope}__CMD}}TARGET__{command['target_name']}",
            command,
            "*",
            100,
            db_shard=db_shard,
        )
        command["cmd_params"] = cmd_params  # Restore the original cmd_params dict
        start_time = time.time()
        while (time.time() - start_time) < timeout:
            for _, _, msg_hash, _ in Topic.read_topics([ack_topic], db_shard=db_shard):
                if msg_hash[b"id"] == cmd_id:
                    result = msg_hash[b"result"].decode()
                    if result == "SUCCESS":
                        return command
                    # Check for HazardousError which is a special case
                    elif "HazardousError" in result:
                        cls.raise_hazardous_error(msg_hash, command)
                    elif "CriticalCmdError" in result:
                        cls.raise_critical_cmd_error(msg_hash, command)
                    else:
                        raise RuntimeError(result)
        raise RuntimeError(f"Timeout of {timeout}s waiting for cmd ack")

    ###########################################################################
    # PRIVATE implementation details
    ###########################################################################

    @classmethod
    def raise_hazardous_error(cls, msg_hash, command):
        _, description, formatted = msg_hash[b"result"].decode().split("\n")
        # Create and populate a new HazardousError and raise it up
        # The _cmd method in script/commands.rb rescues this and calls prompt_for_hazardous
        error = HazardousError()
        error.target_name = command["target_name"]
        error.cmd_name = command["cmd_name"]
        error.cmd_params = command["cmd_params"]
        error.hazardous_description = description
        error.formatted = formatted

        # No Logger.info because the error is already logged by the Logger.info "Ack Received ...
        raise error

    @classmethod
    def raise_critical_cmd_error(cls, msg_hash, command):
        _, uuid = msg_hash[b"result"].decode().split("\n")
        # Create and populate a new CriticalCmdError and raise it up
        # The _cmd method in script/commands.rb rescues this and calls prompt_for_critical_cmd
        error = CriticalCmdError()
        error.uuid = uuid
        error.command = command
        # No Logger.info because the error is already logged by the Logger.info "Ack Received ...
        raise error
