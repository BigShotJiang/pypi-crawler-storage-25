module github.com/mmgehlot/bitpolar/services/bitpolar/bitpolar-go

go 1.21
