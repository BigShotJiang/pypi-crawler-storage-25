class FunctionalRequirementTooComplex(Exception):
    def __init__(self, message, proposed_breakdown=None):
        self.message = message
        self.proposed_breakdown = proposed_breakdown
        super().__init__(self.message)


class ConflictingRequirements(Exception):
    pass


class RenderingCreditBalanceTooLow(Exception):
    pass


class LLMInternalError(Exception):
    pass


class MissingResource(Exception):
    pass


class PlainSyntaxError(Exception):
    pass


class InternalClientError(Exception):
    pass


class MissingAPIKey(Exception):
    pass


class InvalidAPIKey(Exception):
    pass


class OutdatedClientVersion(Exception):
    pass


class InvalidFridArgument(Exception):
    pass


class InvalidGitRepositoryError(Exception):
    """Raised when the git repository is in an invalid state."""

    pass


class InvalidLiquidVariableName(Exception):
    pass


class ModuleDoesNotExistError(Exception):
    pass


class InternalServerError(Exception):
    pass


class MissingPreviousFunctionalitiesError(Exception):
    """Raised when trying to render from a FRID but previous FRID commits are missing."""

    pass


class NetworkConnectionError(Exception):
    """Raised when there is a network connectivity issue with the API server."""

    pass


class AmbiguousConfigFileError(Exception):
    """Raised when a config file is found in both the plain file directory and the current working directory."""

    pass


class RenderCancelledError(Exception):
    """Raised when the render is cancelled by the user closing the TUI."""

    pass
