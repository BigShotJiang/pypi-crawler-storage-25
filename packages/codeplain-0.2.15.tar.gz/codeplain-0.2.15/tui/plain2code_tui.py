import threading
from typing import Callable, Optional

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.widgets import ContentSwitcher, Static

from event_bus import EventBus
from plain2code_events import (
    LogMessageEmitted,
    RenderCompleted,
    RenderContextSnapshot,
    RenderFailed,
    RenderModuleCompleted,
    RenderModuleStarted,
    RenderPaused,
    RenderStateUpdated,
)
from render_machine.states import States
from tui.widget_helpers import log_to_widget, transition_frid_progress

from .components import (
    CustomFooter,
    FRIDProgress,
    LogFilterChanged,
    LogLevelFilter,
    ProgressItem,
    RenderingInfoBox,
    ScriptOutputType,
    StructuredLogView,
    TestScriptsContainer,
    TUIComponents,
)
from .state_handlers import (
    ConformanceTestsHandler,
    FridFullyImplementedHandler,
    FridReadyHandler,
    RefactoringHandler,
    RenderErrorHandler,
    RenderSuccessHandler,
    ScriptOutputsHandler,
    StateCompletionHandler,
    StateHandler,
    UnitTestsHandler,
)


class Plain2CodeTUI(App):
    """A Textual TUI for plain2code."""

    ENABLE_COMMAND_PALETTE = False

    BINDINGS = [
        Binding("ctrl+c", "copy_selection", "Copy", show=False),
        Binding("ctrl+d", "quit", "Quit", show=False),
        Binding("enter", "enter_exit", "Exit", show=False),
        Binding("ctrl+p", "pause", "Pause", show=False, priority=True),
        ("ctrl+l", "toggle_logs", "Toggle Logs"),
    ]

    def __init__(
        self,
        event_bus: EventBus,
        on_ready: Callable[[], None],
        render_id: str,
        unittests_script: str,
        conformance_tests_script: str,
        prepare_environment_script: str,
        state_machine_version: str,
        enter_pause_event: threading.Event | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.dark = True  # Set dark mode as default
        self.event_bus = event_bus
        self._on_ready = on_ready
        self.render_id = render_id
        self.unittests_script: Optional[str] = unittests_script
        self.conformance_tests_script: Optional[str] = conformance_tests_script
        self.prepare_environment_script: Optional[str] = prepare_environment_script
        self.state_machine_version = state_machine_version
        self.enter_pause_event = enter_pause_event
        self._render_finished = False

        # Initialize state handlers
        self._state_handlers: dict[str, StateHandler] = {
            States.READY_FOR_FRID_IMPLEMENTATION.value: FridReadyHandler(
                self, self.unittests_script, self.conformance_tests_script
            ),
            States.PROCESSING_UNIT_TESTS.value: UnitTestsHandler(
                self, self.unittests_script, self.conformance_tests_script
            ),
            States.REFACTORING_CODE.value: RefactoringHandler(
                self, self.unittests_script, self.conformance_tests_script
            ),
            States.PROCESSING_CONFORMANCE_TESTS.value: ConformanceTestsHandler(
                self, self.unittests_script, self.conformance_tests_script
            ),
            States.FRID_FULLY_IMPLEMENTED.value: FridFullyImplementedHandler(
                self, self.unittests_script, self.conformance_tests_script
            ),
        }
        self._script_outputs_handler = ScriptOutputsHandler(self)
        self._render_error_handler = RenderErrorHandler(self)
        self._render_success_handler = RenderSuccessHandler(self)
        self._state_completion_handler = StateCompletionHandler(
            self, self.unittests_script, self.conformance_tests_script
        )

    def get_active_script_types(self) -> list[ScriptOutputType]:
        """Get the list of active script output types based on which scripts exist.

        Returns:
            List of ScriptOutputType enum members for scripts that are configured
        """
        active_types = []
        if self.unittests_script is not None:
            active_types.append(ScriptOutputType.UNIT_TEST_OUTPUT_TEXT)
        if self.conformance_tests_script is not None:
            active_types.append(ScriptOutputType.CONFORMANCE_TEST_OUTPUT_TEXT)
        if self.prepare_environment_script is not None:
            active_types.append(ScriptOutputType.TESTING_ENVIRONMENT_OUTPUT_TEXT)
        return active_types

    def on_mount(self) -> None:
        """Called when the app is mounted."""
        self.event_bus.subscribe(RenderStateUpdated, self.on_render_state_updated)
        self.event_bus.subscribe(RenderCompleted, self.on_render_completed)
        self.event_bus.subscribe(RenderFailed, self.on_render_failed)
        self.event_bus.subscribe(RenderModuleStarted, self.on_render_module_started)
        self.event_bus.subscribe(RenderModuleCompleted, self.on_render_module_completed)
        self.event_bus.subscribe(LogMessageEmitted, self.on_log_message_emitted)
        self.event_bus.subscribe(RenderPaused, self.on_render_paused)

        self._on_ready()

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        with ContentSwitcher(id=TUIComponents.CONTENT_SWITCHER.value, initial=TUIComponents.DASHBOARD_VIEW.value):
            with Vertical(id=TUIComponents.DASHBOARD_VIEW.value):
                with VerticalScroll():
                    yield Static(
                        f"[#FFFFFF]*codeplain[/#FFFFFF] [#888888](v{self.state_machine_version})[/#888888]",
                        id="codeplain-header",
                        classes="codeplain-header",
                    )
                    yield FRIDProgress(
                        id=TUIComponents.FRID_PROGRESS.value,
                        unittests_script=self.unittests_script,
                        conformance_tests_script=self.conformance_tests_script,
                    )

                    # Test scripts container with border
                    yield TestScriptsContainer(
                        id=TUIComponents.TEST_SCRIPTS_CONTAINER.value,
                        show_unit_test=self.unittests_script is not None,
                        show_conformance_test=self.conformance_tests_script is not None,
                        show_testing_env=self.prepare_environment_script is not None,
                    )
                    yield Static(
                        "[#FFFFFF]Rendering in progress...[/#FFFFFF]",
                        id=TUIComponents.RENDER_STATUS_WIDGET.value,
                    )
            with Vertical(id=TUIComponents.LOG_VIEW.value):
                yield LogLevelFilter(id=TUIComponents.LOG_FILTER.value)
                yield Static("", classes="filter-spacer")
                yield StructuredLogView(id=TUIComponents.LOG_WIDGET.value)
        yield CustomFooter(render_id=self.render_id)

    def action_toggle_logs(self) -> None:
        """Toggle between dashboard and log view."""
        switcher = self.query_one(f"#{TUIComponents.CONTENT_SWITCHER.value}", ContentSwitcher)
        if switcher.current == TUIComponents.DASHBOARD_VIEW.value:
            switcher.current = TUIComponents.LOG_VIEW.value
        else:
            switcher.current = TUIComponents.DASHBOARD_VIEW.value

    def on_render_module_started(self, event: RenderModuleStarted):
        """Update TUI based on the current state machine state."""
        try:
            frid_progress = self.query_one(f"#{TUIComponents.FRID_PROGRESS.value}", FRIDProgress)
            info_box = frid_progress.query_one(RenderingInfoBox)
            info_box.update_module(f"{FRIDProgress.RENDERING_MODULE_TEXT}{event.module_name}")
        except Exception as e:
            log_to_widget(self, "WARNING", f"Error updating render module name: {type(e).__name__}: {e}")

    def on_render_module_completed(self, _event: RenderModuleCompleted):
        """Update TUI based on the current state machine state."""
        try:
            frid_progress = self.query_one(f"#{TUIComponents.FRID_PROGRESS.value}", FRIDProgress)
            info_box = frid_progress.query_one(RenderingInfoBox)
            info_box.update_module(FRIDProgress.RENDERING_MODULE_TEXT)
        except Exception as e:
            log_to_widget(self, "WARNING", f"Error resetting render module name: {type(e).__name__}: {e}")

    def on_log_message_emitted(self, event: LogMessageEmitted):
        try:
            log_widget = self.query_one(f"#{TUIComponents.LOG_WIDGET.value}", StructuredLogView)
            self.call_later(
                log_widget.add_log,
                event.logger_name,
                event.level,
                event.message,
                event.timestamp,
            )
        except Exception as e:
            log_to_widget(
                self, "WARNING", f"Error adding log message from {event.logger_name}: {type(e).__name__}: {e}"
            )

    def on_log_filter_changed(self, event: LogFilterChanged):
        """Handle log filter changes from LogLevelFilter widget."""
        try:
            log_widget = self.query_one(f"#{TUIComponents.LOG_WIDGET.value}", StructuredLogView)
            log_widget.filter_logs(event.min_level)
        except Exception as e:
            log_to_widget(self, "WARNING", f"Error filtering logs to level {event.min_level}: {type(e).__name__}: {e}")

    def on_render_state_updated(self, event: RenderStateUpdated):
        """Update TUI based on the current state machine state."""
        # 1. Parse current and previous state
        segments = event.state.split("_")
        if len(segments) < 2:
            return
        previous_state_segments = [] if event.previous_state is None else event.previous_state.split("_")

        # 3. Route to appropriate handler based on top-level state
        if segments[0] == States.IMPLEMENTING_FRID.value:
            self._handle_frid_state(segments, event.snapshot, previous_state_segments)

    def _handle_frid_state(
        self, segments: list[str], snapshot: RenderContextSnapshot, previous_state_segments: list[str]
    ) -> None:
        """Handle all states under IMPLEMENTING_FRID."""
        phase = segments[1]

        # Dispatch to appropriate handler
        handler = self._state_handlers.get(phase, None)
        if handler:
            handler.handle(segments, snapshot, previous_state_segments)
        if snapshot.script_execution_history.should_update_script_outputs:
            self._script_outputs_handler.handle(segments, snapshot, previous_state_segments)

        self._state_completion_handler.handle(segments, snapshot, previous_state_segments)

    def on_render_paused(self, event: RenderPaused):
        footer = self.screen.query_one(CustomFooter)
        footer.update_footer_state("paused")
        transition_frid_progress(self, ProgressItem.PAUSING, ProgressItem.PAUSED)
        pass

    def on_render_completed(self, event: RenderCompleted):
        """Handle successful render completion."""
        self._render_success_handler.handle(event.rendered_code_path)
        self._render_finished = True
        try:
            footer = self.screen.query_one(CustomFooter)
            footer.update_footer_state("finished")
        except NoMatches:
            pass

    def on_render_failed(self, event: RenderFailed):
        """Handle render failure."""
        self._render_error_handler.handle(event.error_message)
        self._render_finished = True
        try:
            footer = self.screen.query_one(CustomFooter)
            footer.update_footer_state("finished")
        except NoMatches:
            pass

    async def action_copy_selection(self) -> None:
        """Handle ctrl+c: copy selected text if any.

        - If text is selected -> copy it to clipboard
        - If no text is selected -> do nothing
        """
        selected_text = self.screen.get_selected_text()
        if selected_text:
            self.copy_to_clipboard(selected_text)
            self.screen.clear_selection()
            self.notify("Copied to clipboard", timeout=2)

    def action_pause(self) -> None:
        """Handle ctrl+p: request the render machine to pause."""
        if not self._render_finished and self.enter_pause_event is not None:
            if self.enter_pause_event.is_set():
                transition_frid_progress(self, ProgressItem.PAUSED, ProgressItem.PROCESSING)
                transition_frid_progress(self, ProgressItem.PAUSING, ProgressItem.PROCESSING)
                footer = self.screen.query_one(CustomFooter)
                footer.update_footer_state("rendering")
                self.enter_pause_event.clear()
            else:
                transition_frid_progress(self, ProgressItem.PROCESSING, ProgressItem.PAUSING)
                footer = self.screen.query_one(CustomFooter)
                footer.update_footer_state("pausing")
                self.enter_pause_event.set()

    def action_enter_exit(self) -> None:
        """Handle enter: exit the TUI only after rendering has finished."""
        if self._render_finished:
            self.action_quit()

    def action_quit(self) -> None:
        """Quit the application immediately.

        Note: Force exit may leave files partially written if interrupted during file I/O operations.
        This is acceptable since the folders in which we are writing are git versioned and are reset in the next render.
        """
        self.exit()
