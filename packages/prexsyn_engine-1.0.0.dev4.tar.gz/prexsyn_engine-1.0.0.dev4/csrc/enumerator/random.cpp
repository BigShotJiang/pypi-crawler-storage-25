#include "random.hpp"

#include <cstddef>
#include <cstdlib>
#include <memory>
#include <optional>
#include <random>
#include <stdexcept>
#include <utility>
#include <vector>

#include "../chemistry/chemistry.hpp"
#include "../chemspace/chemspace.hpp"
#include "../utility/random.hpp"

namespace prexsyn::enumerator {

RandomEnumerator::RandomEnumerator(std::shared_ptr<chemspace::ChemicalSpace> cs,
                                   const Config &config, std::optional<size_t> random_seed)
    : cs_(std::move(cs)), config_(config), synthesis_(nullptr),
      rng_(random_seed.value_or(std::random_device{}())) {
    if (cs_ == nullptr) {
        throw std::invalid_argument("null pointer for chemical space");
    }
    if (cs_->bb_lib().size() == 0) {
        throw std::invalid_argument("empty building block library");
    }
    if (cs_->rxn_lib().size() == 0) {
        throw std::invalid_argument("empty reaction library");
    }
}

bool RandomEnumerator::not_growable() const {
    if (synthesis_ == nullptr) {
        return false;
    }
    auto products = synthesis_->products();
    if (products.empty()) {
        return false;
    }
    const auto &product = products.front();
    return product->num_heavy_atoms() >= config_.heavy_atom_limit ||
           synthesis_->count_building_blocks() >= config_.max_building_blocks;
}

void RandomEnumerator::clear_synthesis() { synthesis_.reset(); }

void RandomEnumerator::init_synthesis() {
    synthesis_ = cs_->new_synthesis();

    auto num_bb = cs_->bb_lib().size();
    std::uniform_int_distribution<size_t> dist(0, num_bb - 1);
    size_t index = dist(rng_);
    synthesis_->add_building_block(index);
}

void RandomEnumerator::grow_synthesis() {
    auto products = synthesis_->products();
    if (products.empty()) {
        clear_synthesis();
        return;
    }
    auto product = random_choice(products, rng_);

    auto matches = cs_->rxn_lib().match_reactants(*product);

    // Remove when there are too many same functional groups for the reaction (poor selectivity)
    std::erase_if(matches,
                  [&](const auto &match) { return match.count > config_.selectivity_cutoff; });

    if (matches.empty()) {
        clear_synthesis();
        return;
    }
    auto match = random_choice(matches, rng_);

    auto rxn = cs_->rxn_lib().get(match.reaction_index);
    chemspace::Synthesis::Result result;
    for (size_t i = 0; i < rxn.reaction->num_reactants(); ++i) {
        if (i == match.reactant_index) {
            continue;
        }
        const auto &rlist_bb = cs_->building_block_reactant_lists().get(match.reaction_index, i);
        const auto &rlist_int = cs_->intermediate_reactant_lists().get(match.reaction_index, i);
        if (rlist_bb.empty() && rlist_int.empty()) {
            // No possible reactants for this slot, so this reaction can't be applied
            clear_synthesis();
            return;
        }

        const auto &[choice, index] = random_choice(rlist_bb, rlist_int, rng_);
        if (choice == which_vector::first) {
            result = synthesis_->add_building_block(index);
        } else {
            result = synthesis_->add_intermediate(index, config_.max_outcomes_per_reaction);
        }
        if (!result) {
            clear_synthesis();
            return;
        }
    }

    // add_reaction returns failure if there's no products produced
    result = synthesis_->add_reaction(match.reaction_index, config_.max_outcomes_per_reaction);
    if (!result) {
        clear_synthesis();
        return;
    }
}

std::optional<std::shared_ptr<chemspace::Synthesis>> RandomEnumerator::try_next() {
    if (synthesis_ == nullptr || not_growable()) {
        init_synthesis();
    } else {
        grow_synthesis();
    }

    if (synthesis_ == nullptr) {
        return std::nullopt;
    } else {
        return std::make_shared<chemspace::Synthesis>(*synthesis_);
    }
}

std::shared_ptr<chemspace::Synthesis> RandomEnumerator::next() {
    constexpr const int max_attempts = 100;
    for (int attempt = 0; attempt < max_attempts; ++attempt) {
        auto result = try_next();
        if (result.has_value()) {
            return result.value();
        }
    }
    throw std::runtime_error("too many failed attempts to find next synthesis");
}

std::pair<std::shared_ptr<chemspace::Synthesis>, std::shared_ptr<Molecule>>
RandomEnumerator::next_with_product() {
    auto syn = next();
    auto product = random_choice(syn->products(), rng_);
    return {syn, product};
}

} // namespace prexsyn::enumerator
