#include <pybind11/pybind11.h>

#include "chemistry/bind.hpp"
#include "chemspace/bind.hpp"
#include "datapipe/bind.hpp"
#include "descriptor/bind.hpp"
#include "detokenizer/bind.hpp"
#include "enumerator/bind.hpp"

namespace py = pybind11;

PYBIND11_MODULE(prexsyn_engine, m) {
    m.doc() = "PrexSyn Engine";

    auto m_chemistry = m.def_submodule("chemistry");
    def_module_chemistry(m_chemistry);

    auto m_chemspace = m.def_submodule("chemspace");
    def_module_chemspace(m_chemspace);

    auto m_descriptor = m.def_submodule("descriptor");
    def_module_descriptor(m_descriptor);

    auto m_enumerator = m.def_submodule("enumerator");
    def_module_enumerator(m_enumerator);

    auto m_datapipe = m.def_submodule("datapipe");
    def_module_datapipe(m_datapipe);

    auto m_detokenizer = m.def_submodule("detokenizer");
    def_module_detokenizer(m_detokenizer);
}
