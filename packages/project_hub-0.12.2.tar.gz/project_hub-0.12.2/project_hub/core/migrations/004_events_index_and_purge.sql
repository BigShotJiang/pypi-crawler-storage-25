-- Index on seen for fast unseen lookups (events panel polls every 5s)
CREATE INDEX IF NOT EXISTS idx_events_seen ON events(seen);

-- Purge old seen events (keep 7 days)
DELETE FROM events WHERE seen = 1 AND created_at < datetime('now', '-7 days');
