ALTER TABLE vulnerabilities ADD COLUMN report_stale INTEGER DEFAULT 0;
ALTER TABLE vulnerabilities ADD COLUMN report_stale_since TEXT;
