CREATE TABLE IF NOT EXISTS issues (
    id INTEGER,
    iid INTEGER,
    title TEXT,
    author TEXT,
    state TEXT,
    web_url TEXT,
    user_notes_count INTEGER DEFAULT 0,
    created_at TEXT,
    updated_at TEXT,
    repo_name TEXT,
    labels TEXT DEFAULT '[]',
    assignees TEXT DEFAULT '[]',
    participants TEXT DEFAULT '[]',
    confidential INTEGER DEFAULT 0
);
