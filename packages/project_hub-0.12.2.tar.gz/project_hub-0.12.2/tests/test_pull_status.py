from unittest.mock import patch
from project_hub.git.ops import check_pull_status_sync

def test_pull_status_up_to_date(tmp_path):
    """behind=0 → up-to-date"""
    with patch("project_hub.git.ops.git_status") as mock_status:
        mock_status.return_value = type("GS", (), {"behind": 0, "ahead": 0, "dirty": False, "branch": "main"})()
        result = check_pull_status_sync(tmp_path)
    assert result == "up-to-date"

def test_pull_status_clean(tmp_path):
    """behind>0, no conflict → clean"""
    with patch("project_hub.git.ops.git_status") as mock_status, \
         patch("project_hub.git.ops._has_conflict") as mock_conflict:
        mock_status.return_value = type("GS", (), {"behind": 2, "ahead": 0, "dirty": False, "branch": "main"})()
        mock_conflict.return_value = False
        result = check_pull_status_sync(tmp_path)
    assert result == "clean"

def test_pull_status_conflict(tmp_path):
    """behind>0, conflict → conflict"""
    with patch("project_hub.git.ops.git_status") as mock_status, \
         patch("project_hub.git.ops._has_conflict") as mock_conflict:
        mock_status.return_value = type("GS", (), {"behind": 1, "ahead": 1, "dirty": False, "branch": "main"})()
        mock_conflict.return_value = True
        result = check_pull_status_sync(tmp_path)
    assert result == "conflict"

def test_pull_status_no_upstream(tmp_path):
    """git_status raises (no upstream) → None"""
    with patch("project_hub.git.ops.git_status") as mock_status:
        mock_status.side_effect = Exception("no upstream")
        result = check_pull_status_sync(tmp_path)
    assert result is None
