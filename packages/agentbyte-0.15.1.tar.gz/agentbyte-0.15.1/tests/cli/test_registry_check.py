"""Tests for the `agentbyte registry check` CLI sub-command (spec 0012, Phase 3)."""

from __future__ import annotations

import argparse

import pytest

from agentbyte.catalog import InMemoryInstructionCatalog
from agentbyte.cli.main import _load_catalog, cmd_registry_check


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_args(catalog_path: str) -> argparse.Namespace:
    return argparse.Namespace(catalog=catalog_path)


# ---------------------------------------------------------------------------
# _load_catalog
# ---------------------------------------------------------------------------

class TestLoadCatalog:
    def test_loads_preset_catalog(self) -> None:
        from agentbyte.catalog import BaseInstructionCatalog
        catalog = _load_catalog("agentbyte.presets.instruction_registry:_PRESET_CATALOG")
        assert isinstance(catalog, BaseInstructionCatalog)

    def test_raises_on_bad_format(self) -> None:
        with pytest.raises(SystemExit) as exc_info:
            _load_catalog("agentbyte.presets.instruction_registry")
        assert exc_info.value.code == 1

    def test_raises_on_missing_module(self) -> None:
        with pytest.raises(SystemExit) as exc_info:
            _load_catalog("nonexistent.module:obj")
        assert exc_info.value.code == 1

    def test_raises_on_missing_object(self) -> None:
        with pytest.raises(SystemExit) as exc_info:
            _load_catalog("agentbyte.presets.instruction_registry:nonexistent")
        assert exc_info.value.code == 1

    def test_raises_when_object_is_not_a_catalog(self) -> None:
        with pytest.raises(SystemExit) as exc_info:
            _load_catalog("agentbyte.__about__:VERSION")
        assert exc_info.value.code == 1


# ---------------------------------------------------------------------------
# cmd_registry_check
# ---------------------------------------------------------------------------

class TestCmdRegistryCheck:
    def test_preset_catalog_passes(self) -> None:
        args = _make_args("agentbyte.presets.instruction_registry:_PRESET_CATALOG")
        exit_code = cmd_registry_check(args)
        assert exit_code == 0

    def test_catalog_missing_default_fails(self, tmp_path, monkeypatch) -> None:
        catalog = InMemoryInstructionCatalog(
            {
                "analyst": {
                    "claude": "Claude analyst.",
                    "openai": "OpenAI analyst.",
                    # intentionally missing 'default'
                },
            }
        )
        import types
        fake_module = types.ModuleType("fake_test_module")
        fake_module.bad_catalog = catalog  # type: ignore[attr-defined]

        import sys
        monkeypatch.setitem(sys.modules, "fake_test_module", fake_module)

        args = _make_args("fake_test_module:bad_catalog")
        exit_code = cmd_registry_check(args)
        assert exit_code == 1

    def test_custom_catalog_with_default_passes(self, monkeypatch) -> None:
        catalog = InMemoryInstructionCatalog(
            {
                "analyst": {
                    "claude": "Claude analyst.",
                    "default": "Default analyst.",
                },
            }
        )
        import sys
        import types
        fake_module = types.ModuleType("fake_good_module")
        fake_module.good_catalog = catalog  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "fake_good_module", fake_module)

        args = _make_args("fake_good_module:good_catalog")
        exit_code = cmd_registry_check(args)
        assert exit_code == 0
