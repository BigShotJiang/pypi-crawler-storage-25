"""Tests for instruction_registry (spec 0012, Phase 0 + Phase 1)."""

from __future__ import annotations

import pytest

from agentbyte.catalog import InMemoryInstructionCatalog, resolve_model_family
from agentbyte.presets.instruction_registry import get_instruction, _PRESET_CATALOG


class TestResolveModelFamily:
    def test_claude_sonnet(self) -> None:
        assert resolve_model_family("claude-sonnet-4-6") == "claude"

    def test_claude_opus(self) -> None:
        assert resolve_model_family("claude-opus-4-7") == "claude"

    def test_claude_haiku(self) -> None:
        assert resolve_model_family("claude-haiku-4-5") == "claude-haiku"

    def test_claude_haiku_takes_priority_over_claude(self) -> None:
        assert resolve_model_family("claude-haiku-3") == "claude-haiku"

    def test_gpt_4_1(self) -> None:
        assert resolve_model_family("gpt-4.1") == "openai"

    def test_gpt_4o(self) -> None:
        assert resolve_model_family("gpt-4o") == "openai"

    def test_gpt_4_1_mini(self) -> None:
        assert resolve_model_family("gpt-4.1-mini") == "openai-mini"

    def test_gpt_4o_mini(self) -> None:
        assert resolve_model_family("gpt-4o-mini") == "openai-mini"

    def test_azure_model(self) -> None:
        assert resolve_model_family("azure-gpt-4") == "azure-openai"

    def test_unknown_model_returns_default(self) -> None:
        assert resolve_model_family("unknown-model-xyz") == "default"

    def test_empty_string_returns_default(self) -> None:
        assert resolve_model_family("") == "default"

    def test_case_insensitive(self) -> None:
        assert resolve_model_family("Claude-Sonnet-4-6") == "claude"
        assert resolve_model_family("GPT-4.1-mini") == "openai-mini"


class TestInstructionCatalog:
    def setup_method(self) -> None:
        self.catalog = InMemoryInstructionCatalog(
            {
                "analyst": {
                    "claude": "Claude analyst instruction.",
                    "openai": "OpenAI analyst instruction.",
                    "default": "Default analyst instruction.",
                },
                "summariser": {
                    "default": "Default summariser instruction.",
                },
            }
        )

    def test_lookup_returns_family_specific_string(self) -> None:
        assert self.catalog.lookup("analyst", "claude-sonnet-4-6") == "Claude analyst instruction."

    def test_lookup_falls_back_to_default(self) -> None:
        assert self.catalog.lookup("summariser", "claude-sonnet-4-6") == "Default summariser instruction."

    def test_lookup_raises_for_unknown_role(self) -> None:
        with pytest.raises(ValueError, match="Unknown role"):
            self.catalog.lookup("nonexistent", "gpt-4.1")

    @pytest.mark.asyncio
    async def test_get_instruction_async(self) -> None:
        result = await self.catalog.get_instruction("analyst", "gpt-4.1")
        assert result == "OpenAI analyst instruction."

    @pytest.mark.asyncio
    async def test_list_roles_returns_sorted(self) -> None:
        roles = await self.catalog.list_roles()
        assert roles == ["analyst", "summariser"]

    def test_custom_catalog_is_independent_of_preset_catalog(self) -> None:
        with pytest.raises(ValueError, match="Unknown role"):
            self.catalog.lookup("researcher", "gpt-4.1")


class TestPresetCatalog:
    def test_get_instruction_returns_claude_specific(self) -> None:
        result = get_instruction("researcher", "claude-sonnet-4-6")
        assert "<instructions>" in result

    def test_get_instruction_returns_openai_specific(self) -> None:
        result = get_instruction("researcher", "gpt-4.1")
        assert "<instructions>" not in result

    def test_claude_and_openai_instructions_differ(self) -> None:
        claude = get_instruction("researcher", "claude-sonnet-4-6")
        openai = get_instruction("researcher", "gpt-4.1")
        assert claude != openai

    def test_falls_back_to_default_for_unknown_model(self) -> None:
        unknown = get_instruction("researcher", "unknown-model-xyz")
        default = get_instruction("researcher", "")
        assert unknown == default

    def test_raises_for_unknown_role(self) -> None:
        with pytest.raises(ValueError, match="Unknown role"):
            get_instruction("nonexistent_role", "gpt-4.1")

    @pytest.mark.parametrize("role", ["researcher", "writer", "query_rewriter", "reviewer", "orchestrator"])
    def test_every_role_has_default_entry(self, role: str) -> None:
        result = get_instruction(role, "unknown-model-xyz")
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.parametrize("role", ["researcher", "writer", "query_rewriter", "reviewer", "orchestrator"])
    def test_every_role_returns_string_for_claude(self, role: str) -> None:
        result = get_instruction(role, "claude-sonnet-4-6")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_haiku_instruction_differs_from_openai(self) -> None:
        haiku = get_instruction("researcher", "claude-haiku-4-5")
        openai = get_instruction("researcher", "gpt-4.1")
        assert haiku != openai

    def test_preset_catalog_is_base_catalog_instance(self) -> None:
        from agentbyte.catalog import BaseInstructionCatalog
        assert isinstance(_PRESET_CATALOG, BaseInstructionCatalog)

    def test_top_level_exports(self) -> None:
        from agentbyte import BaseInstructionCatalog, InMemoryInstructionCatalog as IC, resolve_model_family as rmf
        assert callable(rmf)
        assert issubclass(IC, BaseInstructionCatalog)


class TestYamlInstructionCatalog:
    def test_loads_from_preset_instructions_dir(self) -> None:
        from pathlib import Path
        from agentbyte.catalog import YamlInstructionCatalog
        yaml_dir = Path(__file__).parents[2] / "src" / "agentbyte" / "presets" / "instructions"
        catalog = YamlInstructionCatalog(yaml_dir)
        roles = catalog._roles
        assert "researcher" in roles
        assert "writer" in roles
        assert "query_rewriter" in roles
        assert "reviewer" in roles
        assert "orchestrator" in roles

    def test_yaml_lookup_returns_claude_specific(self) -> None:
        from pathlib import Path
        from agentbyte.catalog import YamlInstructionCatalog
        yaml_dir = Path(__file__).parents[2] / "src" / "agentbyte" / "presets" / "instructions"
        catalog = YamlInstructionCatalog(yaml_dir)
        result = catalog.lookup("researcher", "claude-sonnet-4-6")
        assert "<instructions>" in result

    def test_yaml_and_memory_catalogs_produce_same_output(self) -> None:
        from pathlib import Path
        from agentbyte.catalog import YamlInstructionCatalog
        yaml_dir = Path(__file__).parents[2] / "src" / "agentbyte" / "presets" / "instructions"
        yaml_catalog = YamlInstructionCatalog(yaml_dir)
        for role in ["researcher", "writer", "query_rewriter", "reviewer", "orchestrator"]:
            for model in ["claude-sonnet-4-6", "gpt-4.1", "gpt-4.1-mini", "claude-haiku-4-5"]:
                yaml_result = yaml_catalog.lookup(role, model)
                mem_result = get_instruction(role, model)
                assert yaml_result == mem_result, (
                    f"Mismatch for role={role!r} model={model!r}:\n"
                    f"YAML: {yaml_result!r}\nMem:  {mem_result!r}"
                )

    def test_preset_catalog_is_yaml_backed_when_files_present(self) -> None:
        from agentbyte.catalog import YamlInstructionCatalog
        assert isinstance(_PRESET_CATALOG, YamlInstructionCatalog)

    @pytest.mark.asyncio
    async def test_yaml_catalog_async_interface(self) -> None:
        from pathlib import Path
        from agentbyte.catalog import YamlInstructionCatalog
        yaml_dir = Path(__file__).parents[2] / "src" / "agentbyte" / "presets" / "instructions"
        catalog = YamlInstructionCatalog(yaml_dir)
        roles = await catalog.list_roles()
        assert sorted(roles) == roles
        families = await catalog.families_for_role("researcher")
        assert "default" in families
