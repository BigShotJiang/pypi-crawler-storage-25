"""Generic model-aware instruction catalog (spec 0012)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

# Ordered prefix rules: most-specific first.
# Each entry is (prefix_to_match, family_key).
_FAMILY_RULES: list[tuple[str, str]] = [
    ("claude-haiku", "claude-haiku"),
    ("claude", "claude"),
    ("gpt-4.1-mini", "openai-mini"),
    ("gpt-4o-mini", "openai-mini"),
    ("gpt", "openai"),
    ("azure", "azure-openai"),
]


def resolve_model_family(model: str) -> str:
    """Map a raw model string to a canonical family key.

    Examples:
        'claude-sonnet-4-6' → 'claude'
        'claude-haiku-4-5'  → 'claude-haiku'
        'gpt-4.1'           → 'openai'
        'gpt-4.1-mini'      → 'openai-mini'
        'unknown-xyz'       → 'default'
    """
    normalised = model.strip().lower()
    for prefix, family in _FAMILY_RULES:
        if normalised.startswith(prefix):
            return family
    return "default"


class BaseInstructionCatalog(ABC):
    """Abstract base for model-aware instruction catalogs.

    Implement this to provide instructions from any backing store
    (in-memory dict, YAML files, remote API, etc.).
    """

    @abstractmethod
    async def get_instruction(self, role: str, model: str) -> str:
        """Return the instruction string for (role, model).

        Implementations should fall back to a 'default' family entry
        when no model-specific entry exists, and raise ValueError for
        unknown roles.
        """

    @abstractmethod
    async def list_roles(self) -> list[str]:
        """Return a sorted list of all registered role names."""

    @abstractmethod
    async def families_for_role(self, role: str) -> list[str]:
        """Return a sorted list of model family keys registered for a role.

        Raises ValueError for unknown roles.
        Used by tooling (e.g. ``agentbyte registry check``) to inspect coverage.
        """


class InMemoryInstructionCatalog(BaseInstructionCatalog):
    """In-memory instruction catalog backed by a nested dict.

    Data shape: ``{role: {model_family: instruction_string}}``.
    Every role must have a ``'default'`` key as the fallback entry.

    Usage::

        catalog = InMemoryInstructionCatalog({
            "analyst": {
                "claude": "You are an analyst. <instructions>...</instructions>",
                "openai": "You are an analyst. Think step-by-step...",
                "default": "You are an analyst.",
            },
        })
        instruction = catalog.lookup("analyst", "claude-sonnet-4-6")
        instruction = await catalog.get_instruction("analyst", "claude-sonnet-4-6")
    """

    def __init__(self, data: dict[str, dict[str, str]]) -> None:
        self._data = data
        self._roles: frozenset[str] = frozenset(data.keys())

    def lookup(self, role: str, model: str) -> str:
        """Synchronous instruction lookup for in-memory callers.

        Use this from sync contexts (e.g. preset builders) where the backing
        store is guaranteed to be in-memory. Async callers should use
        ``await get_instruction(...)`` instead.
        """
        if role not in self._roles:
            raise ValueError(
                f"Unknown role {role!r}. Known roles: {sorted(self._roles)}"
            )
        family = resolve_model_family(model)
        role_entries = self._data[role]
        return role_entries.get(family) or role_entries["default"]

    async def get_instruction(self, role: str, model: str) -> str:
        """Async instruction lookup — delegates to ``lookup``."""
        return self.lookup(role, model)

    async def list_roles(self) -> list[str]:
        return sorted(self._roles)

    async def families_for_role(self, role: str) -> list[str]:
        if role not in self._roles:
            raise ValueError(
                f"Unknown role {role!r}. Known roles: {sorted(self._roles)}"
            )
        return sorted(self._data[role].keys())


class YamlInstructionCatalog(BaseInstructionCatalog):
    """YAML-file-backed instruction catalog.

    Loads one YAML file per role from a directory at construction time.
    File name (without extension) is the role name — e.g. ``researcher.yaml``
    becomes the ``"researcher"`` role. Each YAML key is a model family;
    values are instruction strings.

    Every role must have a ``'default'`` key as the fallback entry.

    Usage::

        catalog = YamlInstructionCatalog("/path/to/instructions/")
        instruction = catalog.lookup("analyst", "claude-sonnet-4-6")
        instruction = await catalog.get_instruction("analyst", "claude-sonnet-4-6")
    """

    def __init__(self, directory: str | Path) -> None:
        import yaml

        directory = Path(directory)
        data: dict[str, dict[str, str]] = {}

        for yaml_file in sorted(directory.glob("*.yaml")):
            role = yaml_file.stem
            raw = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError(
                    f"Expected a mapping in {yaml_file}, got {type(raw).__name__!r}"
                )
            data[role] = {k: str(v).rstrip() for k, v in raw.items()}

        self._data = data
        self._roles: frozenset[str] = frozenset(data.keys())

    def lookup(self, role: str, model: str) -> str:
        """Synchronous instruction lookup for in-memory callers."""
        if role not in self._roles:
            raise ValueError(
                f"Unknown role {role!r}. Known roles: {sorted(self._roles)}"
            )
        family = resolve_model_family(model)
        role_entries = self._data[role]
        return role_entries.get(family) or role_entries["default"]

    async def get_instruction(self, role: str, model: str) -> str:
        """Async instruction lookup — delegates to ``lookup``."""
        return self.lookup(role, model)

    async def list_roles(self) -> list[str]:
        return sorted(self._roles)

    async def families_for_role(self, role: str) -> list[str]:
        if role not in self._roles:
            raise ValueError(
                f"Unknown role {role!r}. Known roles: {sorted(self._roles)}"
            )
        return sorted(self._data[role].keys())


__all__ = [
    "BaseInstructionCatalog",
    "InMemoryInstructionCatalog",
    "YamlInstructionCatalog",
    "resolve_model_family",
]
