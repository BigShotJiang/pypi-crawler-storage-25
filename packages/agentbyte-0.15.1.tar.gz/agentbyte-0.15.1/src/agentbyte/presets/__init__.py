"""Convenience preset builders for agents, orchestrators, and workflows."""

from .agents import get_query_rewriter, get_researcher, get_reviewer, get_writer
from .clients import build_chat_client
from .instruction_registry import _PRESET_CATALOG, get_instruction, resolve_model_family
from .orchestration import (
    get_ai_orchestrator,
    get_orchestrator,
    get_plan_based_orchestrator,
    get_round_robin_orchestrator,
)
from .workflow import get_workflow

__all__ = [
    "build_chat_client",
    "get_ai_orchestrator",
    "get_instruction",
    "get_orchestrator",
    "get_plan_based_orchestrator",
    "get_query_rewriter",
    "get_researcher",
    "get_reviewer",
    "get_round_robin_orchestrator",
    "get_workflow",
    "get_writer",
    "resolve_model_family",
]
