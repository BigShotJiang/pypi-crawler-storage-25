"""Default LLM-only agent builders."""

from __future__ import annotations

from typing import Any

from agentbyte.agents import Agent
from agentbyte.llm import BaseChatCompletionClient

from .clients import DEFAULT_OPENAI_MODEL, build_chat_client
from .instruction_registry import get_instruction


def _resolve_model_client(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
) -> BaseChatCompletionClient:
    if model_client is not None:
        return model_client
    return build_chat_client(provider=provider, model=model, config=config)


def get_query_rewriter(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "query_rewriter",
    description: str = "Query rewriter that clarifies and enriches search prompts.",
    example_tasks: list[str] | None = None,
    **kwargs: Any,
) -> Agent:
    """Build the default query rewriter agent."""
    client = _resolve_model_client(model_client, provider=provider, model=model, config=config)
    return Agent(
        name=name,
        description=description,
        instructions=get_instruction("query_rewriter", model or DEFAULT_OPENAI_MODEL),
        model_client=client,
        example_tasks=example_tasks
        or [
            "Rewrite: best laptops for coding and gaming",
            "Rewrite: solar energy benefits article topic",
        ],
        **kwargs,
    )


def get_researcher(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "researcher",
    description: str = "Research specialist for concise factual context and key insights.",
    example_tasks: list[str] | None = None,
    **kwargs: Any,
) -> Agent:
    """Build the default researcher agent."""
    client = _resolve_model_client(model_client, provider=provider, model=model, config=config)
    return Agent(
        name=name,
        description=description,
        instructions=get_instruction("researcher", model or DEFAULT_OPENAI_MODEL),
        model_client=client,
        example_tasks=example_tasks
        or [
            "Gather key points about the benefits of solar energy.",
            "Summarize the main advantages of remote work.",
        ],
        **kwargs,
    )


def get_writer(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "writer",
    description: str = "Writer who turns available material into clear user-facing prose.",
    example_tasks: list[str] | None = None,
    completion_signal: str | None = None,
    **kwargs: Any,
) -> Agent:
    """Build the default writer agent."""
    client = _resolve_model_client(model_client, provider=provider, model=model, config=config)
    base = get_instruction("writer", model or DEFAULT_OPENAI_MODEL)
    if completion_signal:
        instructions = (
            base
            + f"\nWhen the draft is complete, end your response with {completion_signal} on its own line after a blank line."
        )
    else:
        instructions = base + "\nProduce a complete final draft and stop."
    return Agent(
        name=name,
        description=description,
        instructions=instructions,
        model_client=client,
        example_tasks=example_tasks
        or [
            "Write a brief article about solar energy benefits.",
            "Draft a short note on why renewable energy matters.",
        ],
        **kwargs,
    )


def get_reviewer(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "reviewer",
    description: str = "Reviewer who checks clarity, completeness, and unsupported claims.",
    example_tasks: list[str] | None = None,
    approval_signal: str | None = "APPROVED",
    **kwargs: Any,
) -> Agent:
    """Build the default reviewer agent."""
    client = _resolve_model_client(model_client, provider=provider, model=model, config=config)
    base = get_instruction("reviewer", model or DEFAULT_OPENAI_MODEL)
    if approval_signal:
        outcome = (
            f"\nIf the draft text is acceptable, output only the single word {approval_signal} and nothing else.\n"
            "If the draft needs revision, output one specific sentence describing what text content to fix."
        )
    else:
        outcome = (
            "\nIf the draft is ready, clearly state it is ready. "
            "If it needs revision, output one specific sentence describing what text content to fix."
        )
    return Agent(
        name=name,
        description=description,
        instructions=base + outcome,
        model_client=client,
        example_tasks=example_tasks
        or [
            "Review a short article about solar energy benefits.",
            "Review a note about remote work productivity.",
        ],
        **kwargs,
    )


__all__ = [
    "get_query_rewriter",
    "get_researcher",
    "get_reviewer",
    "get_writer",
]
