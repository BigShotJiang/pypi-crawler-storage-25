"""Execution-level event logger for agent, orchestrator, and workflow streams.

:class:`StreamEventLogger` operates one layer above the middleware chain — it
consumes the events yielded by ``run_stream()`` and routes each to the
appropriate standard log level so callers never have to write their own
``isinstance`` dispatch.

Log format matches :class:`~agentbyte.middleware.LoggingMiddleware`:
    ``[source] HH:MM:SS | event_type  key=value ...``

Logger name: ``agentbyte.stream`` (distinct from the middleware logger
``agentbyte.middleware`` so the two can be filtered independently).
"""

from __future__ import annotations

import logging
from typing import Any, Optional


class StreamEventLogger:
    """Logs events from ``run_stream()`` using standard Python log levels.

    Each method — ``info()``, ``debug()``, ``warning()``, ``error()`` — handles
    only the event types that belong to that level.  Every other item (including
    ``Message``, ``AgentResponse``, raw token chunks, and non-event objects) is
    silently ignored, so callers can pass every item from the stream without
    pre-filtering.

    This logger sits at the agent/orchestrator/workflow execution layer, above
    the :class:`~agentbyte.middleware.LoggingMiddleware` which operates at the
    LLM/tool operation layer.  The two loggers are complementary and can be
    active at the same time without conflict.

    Args:
        logger: Logger to write to.  Defaults to ``agentbyte.stream``.

    Example — single agent::

        from agentbyte.logger import StreamEventLogger

        stream_logger = StreamEventLogger()

        async for item in agent.run_stream("hello", verbose=True):
            stream_logger.info(item)
            stream_logger.debug(item)
            stream_logger.warning(item)
            stream_logger.error(item)

    Example — orchestrator with multiple agents::

        async for item in orchestrator.run_stream("research this", verbose=True):
            stream_logger.info(item)
            stream_logger.debug(item)
            stream_logger.warning(item)
            stream_logger.error(item)
    """

    _DEFAULT_LOGGER = "agentbyte.stream"

    def __init__(self, logger: Optional[logging.Logger] = None) -> None:
        self._logger = logger or logging.getLogger(self._DEFAULT_LOGGER)

    @staticmethod
    def _fmt(item: Any) -> tuple[str, str, str]:
        return (
            item.source,
            item.timestamp.strftime("%H:%M:%S"),
            item.event_type,
        )

    def info(self, item: Any) -> None:
        """Emit INFO for ``TaskStartEvent``, ``TaskCompleteEvent``, and ``ToolCallEvent``.

        All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            TaskCompleteEvent,
            TaskStartEvent,
            ToolCallEvent,
        )

        if not isinstance(item, BaseEvent):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, TaskStartEvent):
            self._logger.info("[%s] %s | %s", source, time_str, event_type)

        elif isinstance(item, TaskCompleteEvent):
            self._logger.info(
                "[%s] %s | %s  finish_reason=%s",
                source,
                time_str,
                event_type,
                item.finish_reason,
            )

        elif isinstance(item, ToolCallEvent):
            self._logger.info(
                "[%s] %s | %s  tool=%s  call_id=%s",
                source,
                time_str,
                event_type,
                item.tool_name,
                item.call_id,
            )

    def debug(self, item: Any) -> None:
        """Emit DEBUG for model/tool/memory detail events.

        Handles ``ModelCallEvent``, ``ModelResponseEvent``,
        ``ModelStreamChunkEvent``, ``ToolCallResponseEvent``,
        ``ToolValidationEvent`` (when valid), ``MemoryUpdateEvent``,
        and ``MemoryRetrievalEvent``.  All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            MemoryRetrievalEvent,
            MemoryUpdateEvent,
            ModelCallEvent,
            ModelResponseEvent,
            ModelStreamChunkEvent,
            ToolCallResponseEvent,
            ToolValidationEvent,
        )

        if not isinstance(item, BaseEvent):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, ModelStreamChunkEvent):
            self._logger.debug(
                "[%s] %s | %s  is_final=%s",
                source,
                time_str,
                event_type,
                item.is_final,
            )

        elif isinstance(item, ToolValidationEvent) and item.is_valid:
            self._logger.debug(
                "[%s] %s | %s  tool=%s  valid=True",
                source,
                time_str,
                event_type,
                item.tool_name,
            )

        elif isinstance(
            item,
            (
                ModelCallEvent,
                ModelResponseEvent,
                ToolCallResponseEvent,
                MemoryUpdateEvent,
                MemoryRetrievalEvent,
            ),
        ):
            self._logger.debug("[%s] %s | %s", source, time_str, event_type)

    def warning(self, item: Any) -> None:
        """Emit WARNING for ``ToolApprovalEvent`` and invalid ``ToolValidationEvent``.

        All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            ToolApprovalEvent,
            ToolValidationEvent,
        )

        if not isinstance(item, BaseEvent):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, ToolApprovalEvent):
            self._logger.warning(
                "[%s] %s | %s  tool=%s  request_id=%s",
                source,
                time_str,
                event_type,
                item.approval_request.tool_name,
                item.approval_request.request_id,
            )

        elif isinstance(item, ToolValidationEvent) and not item.is_valid:
            errors = ", ".join(item.errors or [])
            self._logger.warning(
                "[%s] %s | %s  tool=%s  valid=False  errors=%s",
                source,
                time_str,
                event_type,
                item.tool_name,
                errors,
            )

    def error(self, item: Any) -> None:
        """Emit ERROR for ``ErrorEvent`` and ``FatalErrorEvent``.

        All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            ErrorEvent,
            FatalErrorEvent,
        )

        if not isinstance(item, BaseEvent):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, (ErrorEvent, FatalErrorEvent)):
            self._logger.error(
                "[%s] %s | %s  error=%s",
                source,
                time_str,
                event_type,
                item.error_message,
            )


__all__ = ["StreamEventLogger"]
