# Dataset CLI Tool

A powerful command-line tool for dataset operations — filter, transform, validate, and migrate data across CSV, JSON, Excel, and databases with simple commands.

## Features

- **Filter** — Filter dataset rows based on conditions (equals, contains, greater than, etc.)
- **Transform** — Apply transformations to columns (rename, map values, type conversion)
- **Validate** — Validate data against rules and schemas
- **Migrate** — Migrate data between formats (CSV ↔ JSON ↔ Excel ↔ Database)
- **Container** — Merge, split, and combine datasets

## Installation

```bash
pip install dataset-cli-tool
```

## Usage

```bash
cli-tool --help
```

### Filter Command

Filter rows based on conditions:

```bash
cli-tool filter input.csv --column age --gt 18 --output filtered.csv
```

### Transform Command

Transform columns:

```bash
cli-tool transform input.csv --rename "name:full_name" --output transformed.csv
```

### Validate Command

Validate data:

```bash
cli-tool validate input.csv --rules rules.json
```

### Migrate Command

Convert between formats:

```bash
cli-tool migrate input.csv --to json --output data.json
```

### Container Command

Merge multiple datasets:

```bash
cli-tool container merge file1.csv file2.csv --output merged.csv
```

## Supported Formats

- CSV
- JSON
- Excel (.xlsx, .xls)
- Database (SQLite, PostgreSQL, MySQL)

## Requirements

- Python 3.10+
- pandas
- openpyxl
- typer

## License

MIT