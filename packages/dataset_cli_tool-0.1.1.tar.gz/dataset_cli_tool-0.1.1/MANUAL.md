# CLI Tool for Dataset Operations — User Manual

## Table of Contents
1. [Overview](#overview)
2. [Installation](#installation)
3. [Quick Start](#quick-start)
4. [Supported Formats](#supported-formats)
5. [Commands](#commands)
   - [filter](#filter)
   - [transform](#transform)
   - [validate](#validate)
   - [migrate](#migrate)
   - [container](#container)
6. [Architecture](#architecture)
7. [Error Handling](#error-handling)
8. [Extending the Tool](#extending-the-tool)
9. [Troubleshooting](#troubleshooting)

---

## Overview

**cli-tool** is a reusable command-line utility that handles all common data operations with simple commands. Instead of writing a new custom script for every dataset task, type one command and it works — every time, in any environment.

### What it does
- **Filter** — Pull only the records you need by any field
- **Transform** — Reshape, rename, and convert data between formats
- **Validate** — Check data quality against rules before processing
- **Migrate** — Move data between files and databases safely
- **Container** — Run any operation in an isolated Podman container

### Key benefits
- **Saves development time** — Repetitive data tasks that used to take hours of scripting now take one command
- **Reduces human errors** — Built-in validation catches bad data before it reaches production
- **Works in any workflow** — Run manually, inside shell scripts, or as part of a CI/CD pipeline
- **Consistent across machines** — Podman containers guarantee identical behaviour everywhere

---

## Installation

### Prerequisites
- Python 3.10 or higher
- pip or pipx (Python package manager)
- Podman (optional, for container command)

### Quick Install (Recommended)
```bash
pipx install git+https://github.com/hemil-korat-25/CLI-Tool.git
```

### Install from Local Clone
```bash
git clone https://github.com/hemil-korat-25/CLI-Tool.git
cd CLI-Tool
pipx install .
```

### Install in Development Mode
```bash
git clone https://github.com/hemil-korat-25/CLI-Tool.git
cd CLI-Tool
pip install --break-system-packages -e .
```

### Verify installation
```bash
cli-tool --help
```

---

## Quick Start

Given a CSV file `data.csv`:
```csv
id,name,email,status,age
1,Alice,alice@example.com,active,28
2,Bob,bob@example.com,inactive,35
3,Charlie,charlie@example.com,active,42
4,Diana,bad-email,active,19
5,Eve,eve@example.com,inactive,31
```

**Filter active users:**
```bash
cli-tool filter --input data.csv --field status --value active
```

**Validate emails:**
```bash
cli-tool validate --input data.csv --rules email
```

**Convert to JSON with selected fields:**
```bash
cli-tool transform --input data.csv --output data.json --fields id --fields name --fields email
```

---

## Supported Formats

| Format | Read | Write | Notes |
|--------|------|-------|-------|
| CSV    | Yes  | Yes   | Standard comma-separated |
| JSON   | Yes  | Yes   | Array of objects |
| Excel  | Yes  | Yes   | `.xlsx` and `.xls` via openpyxl |

The tool auto-detects the format from the file extension.

---

## Commands

### filter

Pull only the records you need — by status, date, or any field.

#### Usage
```bash
cli-tool filter --input <file> --field <name> [OPTIONS]
```

#### Required flags
| Flag | Short | Description |
|------|-------|-------------|
| `--input` | `-i` | Input file path (csv, json, xlsx) |
| `--field` | `-f` | Field/column name to filter on |

#### Optional flags
| Flag | Short | Default | Description |
|------|-------|---------|-------------|
| `--output` | `-o` | stdout | Output file path |
| `--value` | `-v` | — | Value to match |
| `--operator` | `-r` | `eq` | Comparison operator |
| `--sheet` | `-s` | — | Sheet name (for Excel files) |

#### Operators
| Operator | Description | Example |
|----------|-------------|---------|
| `eq` | Equal to (default) | `--value active` |
| `neq` | Not equal to | `--value inactive` |
| `contains` | Case-insensitive substring | `--value "john"` |
| `gt` | Greater than (numeric) | `--value 30` |
| `gte` | Greater than or equal | `--value 18` |
| `lt` | Less than (numeric) | `--value 65` |
| `lte` | Less than or equal | `--value 100` |

#### Examples

**Filter by exact match:**
```bash
cli-tool filter --input data.csv --field status --value active
```

**Filter by numeric range:**
```bash
cli-tool filter --input data.csv --field age --operator gte --value 30
```

**Filter and save to file:**
```bash
cli-tool filter --input data.csv --field status --value active --output active_users.csv
```

**Filter Excel file by sheet:**
```bash
cli-tool filter --input data.xlsx --sheet "Users" --field role --value admin
```

**Case-insensitive substring match:**
```bash
cli-tool filter --input data.csv --field name --operator contains --value "ali"
```

---

### transform

Reshape and reformat data fields to match a target system.

#### Usage
```bash
cli-tool transform --input <file> --output <file> [OPTIONS]
```

#### Required flags
| Flag | Short | Description |
|------|-------|-------------|
| `--input` | `-i` | Input file path |
| `--output` | `-o` | Output file path |

#### Optional flags
| Flag | Short | Description |
|------|-------|-------------|
| `--format` | `-f` | Output format: csv, json, xlsx (auto-detected from extension) |
| `--fields` | — | Select specific fields/columns to keep (repeatable) |
| `--rename` | `-r` | Rename fields as `old_name:new_name` (repeatable) |

#### Examples

**Convert CSV to JSON:**
```bash
cli-tool transform --input data.csv --output data.json
```

**Select specific columns:**
```bash
cli-tool transform --input data.csv --output clean.csv --fields id --fields name --fields email
```

**Rename columns:**
```bash
cli-tool transform --input data.csv --output clean.csv --rename "name:full_name" --rename "email:email_address"
```

**Convert Excel to CSV:**
```bash
cli-tool transform --input data.xlsx --output data.csv
```

**Combine — select, rename, and convert:**
```bash
cli-tool transform --input data.csv --output clean.json \
  --fields id --fields name --fields email \
  --rename "name:full_name"
```

---

### validate

Check every record against rules before processing — no silent failures.

#### Usage
```bash
cli-tool validate --input <file> --rules <rule> [OPTIONS]
```

#### Required flags
| Flag | Short | Description |
|------|-------|-------------|
| `--input` | `-i` | Input file path |
| `--rules` | `-r` | Validation rule (repeatable) |

#### Optional flags
| Flag | Default | Description |
|------|---------|-------------|
| `--sheet` | — | Sheet name (for Excel files) |
| `--strict` | false | Exit with error code if any validation fails |

#### Validation rules
| Rule | Description | Example |
|------|-------------|---------|
| `email` | Checks email format (auto-detects email column) | `--rules email` |
| `email:field_name` | Checks email format on specific column | `--rules "email:user_email"` |
| `not_null:field` | Ensures a field is not empty | `--rules "not_null:name"` |
| `unique:field` | Ensures all values in a field are unique | `--rules "unique:id"` |
| `range:field:min:max` | Ensures a numeric value is within bounds | `--rules "range:age:18:100"` |

#### Examples

**Check email format:**
```bash
cli-tool validate --input data.csv --rules email
```

**Multiple rules:**
```bash
cli-tool validate --input data.csv \
  --rules email \
  --rules "not_null:name" \
  --rules "not_null:email"
```

**Check numeric range:**
```bash
cli-tool validate --input data.csv --rules "range:age:18:100"
```

**Strict mode (fails CI/CD on errors):**
```bash
cli-tool validate --input data.csv --rules email --rules "not_null:name" --strict
```

#### Sample output
```
Validation Report
=================
Total records:  5
Passed:         4
Failed:         1

Errors:
  Row 5: invalid email in email: 'bad-email'
```

---

### migrate

Move data between databases or environments safely, with rollback support.

#### Usage
```bash
cli-tool migrate --source <connection> --target <connection> --table <name> [OPTIONS]
```

#### Required flags
| Flag | Short | Description |
|------|-------|-------------|
| `--source` | `-s` | Source connection string |
| `--target` | `-t` | Target connection string |
| `--table` | — | Target table name |

#### Optional flags
| Flag | Short | Default | Description |
|------|-------|---------|-------------|
| `--batch` | `-b` | 100 | Batch size for inserts |
| `--dry-run` | `-d` | false | Preview migration without making changes |

#### Connection string formats
| Type | Format | Example |
|------|--------|---------|
| CSV | `csv:<path>` | `csv:data.csv` |
| JSON | `json:<path>` | `json:dump.json` |
| SQLite | `sqlite:<path>` | `sqlite:mydb.db` |
| PostgreSQL | `postgres://<url>` | `postgres://user:pass@localhost/mydb` |

#### Examples

**CSV to SQLite:**
```bash
cli-tool migrate --source csv:data.csv --target sqlite:mydb.db --table users
```

**JSON to PostgreSQL:**
```bash
cli-tool migrate --source json:dump.json --target postgres://user:pass@localhost/mydb --table records
```

**Dry run (preview):**
```bash
cli-tool migrate --source csv:data.csv --target sqlite:mydb.db --table users --dry-run
```

**Custom batch size:**
```bash
cli-tool migrate --source csv:large_file.csv --target sqlite:mydb.db --table records --batch 500
```

#### Notes
- PostgreSQL support requires `psycopg2-binary` and `sqlalchemy`: `pip install psycopg2-binary sqlalchemy`
- The `--dry-run` flag shows how many records would be migrated without making any changes

---

### container

Run any cli-tool command inside an isolated Podman container so behaviour is identical on every machine.

#### Usage
```bash
cli-tool container [OPTIONS] -- <command> [args...]
```

#### Required
- A command to run after `--`

#### Optional flags
| Flag | Short | Default | Description |
|------|-------|---------|-------------|
| `--image` | — | `cli-tool:latest` | Podman image to use |
| `--volume` | `-v` | — | Mount host directory (host_path:container_path) |
| `--input` | `-i` | — | Input file to auto-mount into container |

#### Examples

**Run filter inside a container:**
```bash
cli-tool container --volume /my/data:/data -- filter --input /data/data.csv --field status --value active
```

**Auto-mount input file:**
```bash
cli-tool container --input data.csv -- filter --input /data/data.csv --field status --value active
```

**Run validation in container:**
```bash
cli-tool container --volume /my/data:/data -- validate --input /data/data.csv --rules email
```

#### Notes
- Podman must be installed and accessible in your PATH
- The container image must have `cli-tool` installed inside it
- Build the image with a Dockerfile that installs Python, dependencies, and the tool

---

## Architecture

```
cli-tool/
├── pyproject.toml              # Project config, dependencies, entry point
└── cli_tool/
    ├── main.py                 # Root Typer app, registers all subcommands
    ├── __main__.py             # Allows running with: python -m cli_tool
    ├── core/
    │   └── data.py             # Shared data layer: read_data() / write_data()
    └── commands/
        ├── filter.py           # Filter command logic
        ├── transform.py        # Transform command logic
        ├── validate.py         # Validate command logic
        ├── migrate.py          # Migrate command logic
        └── container.py        # Container command logic
```

### Design principles
- **Modular** — Each command is a separate, independent module
- **Reusable data layer** — `core/data.py` handles all file I/O for CSV, JSON, and Excel
- **Clean argument parsing** — Typer handles validation, help text, and type coercion automatically
- **Extensible** — Add new commands by creating a file in `commands/` and registering it in `main.py`

---

## Error Handling

The tool handles errors at multiple levels:

| Error type | Behaviour |
|------------|-----------|
| Missing required flags | Shows error message and exits with code 1 |
| Unknown field/column | Lists available columns and exits with code 1 |
| Invalid operator | Shows supported operators and exits with code 1 |
| Unsupported file format | Shows supported formats and exits with code 1 |
| File not found | Standard Python file error with path |
| Validation failures (strict) | Prints report and exits with code 1 |
| Container failure | Propagates the container's exit code |

### Exit codes
| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error (missing args, invalid input, validation failure in strict mode) |
| N | Container exit code (when running via `container` command) |

---

## Extending the Tool

### Adding a new command

1. Create a new file in `cli_tool/commands/`:

```python
# cli_tool/commands/export.py
import typer
from cli_tool.core.data import read_data

app = typer.Typer(
    name="export",
    help="Export data to a custom format.",
    add_completion=False,
)

@app.callback(invoke_without_command=True)
def export_cmd(
    input: str = typer.Option(..., "--input", "-i", help="Input file"),
    format: str = typer.Option(..., "--format", "-f", help="Export format"),
):
    df = read_data(input)
    # Your export logic here
    typer.echo(f"Exported {len(df)} rows to {format}")
```

2. Register it in `cli_tool/main.py`:

```python
from cli_tool.commands.export import app as export_app

app.add_typer(export_app, name="export")
```

3. Test it:
```bash
cli-tool export --help
```

### Adding a new validation rule

Edit `cli_tool/commands/validate.py` and add a new case in the `match rule_type:` block:

```python
case "regex":
    regex_parts = rule_arg.split(":", 1)
    if len(regex_parts) != 2:
        errors.append({"row": idx + 2, "message": f"invalid regex rule format"})
    else:
        field, pattern = regex_parts
        if field in df.columns and not re.match(pattern, str(row[field])):
            errors.append({"row": idx + 2, "message": f"field {field!r} does not match pattern {pattern!r}"})
```

---

## Troubleshooting

### `cli-tool: command not found`
The package was not installed in editable mode. Run:
```bash
cd cli-tool && pip install -e .
```

### `ModuleNotFoundError: No module named 'pandas'`
Dependencies were not installed. Run:
```bash
pip install -e .
```

### Excel files not working
Make sure `openpyxl` is installed. It's included in the dependencies but you can verify:
```bash
pip show openpyxl
```

### `podman is not installed or not in PATH`
Install Podman:
```bash
# Arch/Garuda Linux
sudo pacman -S podman

# Ubuntu/Debian
sudo apt install podman
```

### PostgreSQL migration fails
Install the required drivers:
```bash
pip install psycopg2-binary sqlalchemy
```

### Large files are slow
For files over 100MB, consider:
- Using the `--fields` flag in `transform` to select only needed columns
- Filtering data before migration with the `filter` command
- Increasing the `--batch` size in `migrate` for database operations
