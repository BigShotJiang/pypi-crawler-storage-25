import pandas as pd
from pathlib import Path


def read_data(path: str, sheet: str | None = None) -> pd.DataFrame:
    p = Path(path)
    ext = p.suffix.lower()

    match ext:
        case ".csv":
            return pd.read_csv(path)
        case ".json":
            return pd.read_json(path)
        case ".xlsx" | ".xls":
            return pd.read_excel(path, sheet_name=sheet or 0)
        case _:
            raise ValueError(f"Unsupported file format: {ext} (supported: csv, json, xlsx)")


def write_data(df: pd.DataFrame, path: str, sheet: str | None = None) -> None:
    p = Path(path)
    ext = p.suffix.lower()

    match ext:
        case ".csv":
            df.to_csv(path, index=False)
        case ".json":
            df.to_json(path, orient="records", indent=2)
        case ".xlsx" | ".xls":
            df.to_excel(path, index=False, sheet_name=sheet or "Sheet1")
        case _:
            raise ValueError(f"Unsupported output format: {ext} (supported: csv, json, xlsx)")
