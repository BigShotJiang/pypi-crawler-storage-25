import subprocess
import typer

app = typer.Typer(
    name="container",
    help="Run any cli-tool command inside an isolated Podman container so behaviour is identical on every machine.",
    add_completion=False,
)


@app.callback(invoke_without_command=True)
def container_cmd(
    image: str = typer.Option("cli-tool:latest", "--image", help="Podman image to use"),
    volume: str = typer.Option(None, "--volume", "-v", help="Mount host directory into container (host_path:container_path)"),
    input_file: str = typer.Option(None, "--input", "-i", help="Input file to auto-mount into container"),
    command: list[str] = typer.Argument(None, help="Command to run inside the container (after --)"),
):
    if not command:
        typer.echo("Error: a command to run inside the container is required after --", err=True)
        raise typer.Exit(1)

    try:
        subprocess.run(["podman", "--version"], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        typer.echo("Error: podman is not installed or not in PATH", err=True)
        raise typer.Exit(1)

    args = ["podman", "run", "--rm"]

    if volume:
        args.extend(["-v", volume])

    if input_file:
        import os
        from pathlib import Path
        abs_path = str(Path(input_file).resolve())
        container_path = f"/data/{Path(abs_path).name}"
        args.extend(["-v", f"{abs_path}:{container_path}"])

    args.append(image)
    args.extend(command)

    typer.echo(f"Running in Podman container: {' '.join(args[2:])}")

    result = subprocess.run(args)
    if result.returncode != 0:
        raise typer.Exit(result.returncode)
