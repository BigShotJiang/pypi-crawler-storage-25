import typer
from cli_tool.core.data import read_data, write_data

app = typer.Typer(
    name="transform",
    help="Reshape and reformat data fields to match a target system.",
    add_completion=False,
)


@app.callback(invoke_without_command=True)
def transform_cmd(
    input: str = typer.Option(..., "--input", "-i", help="Input file path"),
    output: str = typer.Option(..., "--output", "-o", help="Output file path"),
    format: str = typer.Option(None, "--format", "-f", help="Output format: csv, json, xlsx (auto-detected from extension if not set)"),
    fields: list[str] = typer.Option(None, "--fields", help="Select specific fields/columns to keep"),
    rename: list[str] = typer.Option(None, "--rename", "-r", help="Rename fields as old_name:new_name (can repeat)"),
):
    df = read_data(input)

    if fields:
        missing = [f for f in fields if f not in df.columns]
        if missing:
            typer.echo(f"Error: fields not found: {', '.join(missing)}", err=True)
            raise typer.Exit(1)
        df = df[fields]

    if rename:
        rename_map = {}
        for r in rename:
            if ":" not in r:
                typer.echo(f"Error: invalid rename format '{r}', expected old:new", err=True)
                raise typer.Exit(1)
            old, new = r.split(":", 1)
            rename_map[old] = new
        df = df.rename(columns=rename_map)

    write_data(df, output)
    typer.echo(f"Transformed {len(df)} rows successfully")
    typer.echo(f"Output written to: {output}")
