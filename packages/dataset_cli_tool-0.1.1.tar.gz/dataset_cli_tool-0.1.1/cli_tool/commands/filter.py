import typer
import pandas as pd
from cli_tool.core.data import read_data, write_data

app = typer.Typer(
    name="filter",
    help="Pull only the records you need — by status, date, or any field.",
    add_completion=False,
)


@app.callback(invoke_without_command=True)
def filter_cmd(
    input: str = typer.Option(..., "--input", "-i", help="Input file path (csv, json, xlsx)"),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: stdout)"),
    field: str = typer.Option(..., "--field", "-f", help="Field/column name to filter on"),
    value: str = typer.Option(None, "--value", "-v", help="Value to match"),
    operator: str = typer.Option("eq", "--operator", "-r", help="Comparison operator: eq, neq, gt, gte, lt, lte, contains"),
    sheet: str = typer.Option(None, "--sheet", "-s", help="Sheet name (for Excel files)"),
):
    df = read_data(input, sheet)

    if field not in df.columns:
        typer.echo(f"Error: field '{field}' not found in input (available: {', '.join(df.columns)})", err=True)
        raise typer.Exit(1)

    col = df[field]

    match operator:
        case "eq":
            mask = col.astype(str) == value
        case "neq":
            mask = col.astype(str) != value
        case "contains":
            mask = col.astype(str).str.contains(value, case=False, na=False)
        case "gt":
            mask = pd.to_numeric(col, errors="coerce") > float(value)
        case "gte":
            mask = pd.to_numeric(col, errors="coerce") >= float(value)
        case "lt":
            mask = pd.to_numeric(col, errors="coerce") < float(value)
        case "lte":
            mask = pd.to_numeric(col, errors="coerce") <= float(value)
        case _:
            typer.echo(f"Error: unknown operator '{operator}'", err=True)
            raise typer.Exit(1)

    filtered = df[mask]
    count = len(filtered)

    if output:
        write_data(filtered, output)
        typer.echo(f"Filtered {count} matching records")
        typer.echo(f"Output written to: {output}")
    else:
        typer.echo(filtered.to_string(index=False))
        typer.echo(f"\nFiltered {count} matching records")
