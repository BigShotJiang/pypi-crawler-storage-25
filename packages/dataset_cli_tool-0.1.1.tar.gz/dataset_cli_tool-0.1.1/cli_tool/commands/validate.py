import re
import pandas as pd
import typer
from cli_tool.core.data import read_data

app = typer.Typer(
    name="validate",
    help="Check every record against rules before processing — no silent failures.",
    add_completion=False,
)


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@app.callback(invoke_without_command=True)
def validate_cmd(
    input: str = typer.Option(..., "--input", "-i", help="Input file path"),
    rules: list[str] = typer.Option(..., "--rules", "-r", help="Validation rules: email, not_null:field, unique:field, range:field:min:max"),
    sheet: str = typer.Option(None, "--sheet", "-s", help="Sheet name (for Excel files)"),
    strict: bool = typer.Option(False, "--strict", help="Exit with error code if any validation fails"),
):
    df = read_data(input, sheet)
    errors: list[dict] = []

    for idx, row in df.iterrows():
        for rule in rules:
            parts = rule.split(":", 1)
            rule_type = parts[0]
            rule_arg = parts[1] if len(parts) > 1 else ""

            match rule_type:
                case "email":
                    field = rule_arg or _find_email_col(df.columns)
                    if field and field in df.columns and pd.notna(row.get(field)) and row[field] != "":
                        if not EMAIL_RE.match(str(row[field])):
                            errors.append({"row": idx + 2, "message": f"invalid email in {field}: {row[field]!r}"})

                case "not_null":
                    if rule_arg not in df.columns:
                        errors.append({"row": idx + 2, "message": f"field {rule_arg!r} not found"})
                    elif pd.isna(row[rule_arg]) or str(row[rule_arg]).strip() == "":
                        errors.append({"row": idx + 2, "message": f"field {rule_arg!r} is empty"})

                case "unique":
                    pass  # checked after loop

                case "range":
                    range_parts = rule_arg.split(":")
                    if len(range_parts) != 3:
                        errors.append({"row": idx + 2, "message": f"invalid range rule format, expected field:min:max, got: {rule_arg}"})
                    else:
                        field, min_val, max_val = range_parts
                        if field not in df.columns:
                            errors.append({"row": idx + 2, "message": f"field {field!r} not found"})
                        else:
                            try:
                                val = float(row[field])
                                if val < float(min_val) or val > float(max_val):
                                    errors.append({"row": idx + 2, "message": f"field {field!r} value {val} out of range [{min_val}, {max_val}]"})
                            except (ValueError, TypeError):
                                errors.append({"row": idx + 2, "message": f"field {field!r} is not a number: {row[field]!r}"})

    # Check uniqueness across entire dataframe
    for rule in rules:
        if rule.startswith("unique:"):
            field = rule.split(":", 1)[1]
            if field not in df.columns:
                errors.append({"row": 0, "message": f"field {field!r} not found"})
            else:
                dupes = df[df.duplicated(subset=[field], keep=False)]
                for idx in dupes.index:
                    errors.append({"row": idx + 2, "message": f"duplicate value in {field}: {df.loc[idx, field]!r}"})

    total = len(df)
    failed_rows = set(e["row"] for e in errors)
    failed = len(failed_rows)
    passed = total - failed

    typer.echo("Validation Report")
    typer.echo("=================")
    typer.echo(f"Total records:  {total}")
    typer.echo(f"Passed:         {passed}")
    typer.echo(f"Failed:         {failed}")

    if errors:
        typer.echo("\nErrors:")
        for e in errors:
            typer.echo(f"  Row {e['row']}: {e['message']}")

    if failed > 0 and strict:
        typer.echo(f"\nValidation failed with {failed} errors (strict mode)", err=True)
        raise typer.Exit(1)


def _find_email_col(columns) -> str | None:
    for c in columns:
        if "email" in c.lower():
            return c
    return None
