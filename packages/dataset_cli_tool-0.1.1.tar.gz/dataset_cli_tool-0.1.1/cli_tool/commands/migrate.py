import typer
import pandas as pd
from cli_tool.core.data import read_data

app = typer.Typer(
    name="migrate",
    help="Move data between databases or environments safely, with rollback support.",
    add_completion=False,
)


def parse_connection(spec: str) -> tuple[str, str]:
    if ":" not in spec:
        typer.echo(f"Error: invalid format '{spec}', expected type:path (e.g. csv:data.csv, sqlite:dev.db, postgres://...)", err=True)
        raise typer.Exit(1)
    parts = spec.split(":", 1)
    return parts[0], parts[1]


@app.callback(invoke_without_command=True)
def migrate_cmd(
    source: str = typer.Option(..., "--source", "-s", help="Source connection (csv:file, json:file, sqlite:file, postgres://url)"),
    target: str = typer.Option(..., "--target", "-t", help="Target connection (sqlite:file, postgres://url)"),
    table: str = typer.Option(..., help="Target table name"),
    batch: int = typer.Option(100, "--batch", "-b", help="Batch size for inserts"),
    dry_run: bool = typer.Option(False, "--dry-run", "-d", help="Preview migration without making changes"),
):
    src_type, src_path = parse_connection(source)

    match src_type:
        case "csv" | "json":
            df = read_data(src_path)
        case "sqlite":
            try:
                import sqlite3
                conn = sqlite3.connect(src_path)
                df = pd.read_sql(f"SELECT * FROM {table}", conn)
                conn.close()
            except Exception as e:
                typer.echo(f"Error reading SQLite: {e}", err=True)
                raise typer.Exit(1)
        case "postgres":
            typer.echo("Error: PostgreSQL requires 'psycopg2' — install with: pip install psycopg2-binary", err=True)
            raise typer.Exit(1)
        case _:
            typer.echo(f"Error: unsupported source type '{src_type}'", err=True)
            raise typer.Exit(1)

    count = len(df)

    if dry_run:
        typer.echo(f"[DRY RUN] Would migrate {count} records from {source} to {target}")
        return

    tgt_type, tgt_path = parse_connection(target)

    match tgt_type:
        case "sqlite":
            try:
                import sqlite3
                conn = sqlite3.connect(tgt_path)
                df.to_sql(table, conn, if_exists="append", index=False, chunksize=batch)
                conn.close()
                typer.echo(f"Migrated {count} records to table '{table}' in SQLite: {tgt_path}")
            except Exception as e:
                typer.echo(f"Error writing to SQLite: {e}", err=True)
                raise typer.Exit(1)
        case "postgres":
            typer.echo("Error: PostgreSQL requires 'psycopg2' and 'sqlalchemy' — install with: pip install psycopg2-binary sqlalchemy", err=True)
            raise typer.Exit(1)
        case _:
            typer.echo(f"Error: unsupported target type '{tgt_type}'", err=True)
            raise typer.Exit(1)
