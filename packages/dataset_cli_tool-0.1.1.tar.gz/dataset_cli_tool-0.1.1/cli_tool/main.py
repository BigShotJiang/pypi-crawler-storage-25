import typer
from cli_tool.commands.filter import app as filter_app
from cli_tool.commands.transform import app as transform_app
from cli_tool.commands.migrate import app as migrate_app
from cli_tool.commands.validate import app as validate_app
from cli_tool.commands.container import app as container_app

app = typer.Typer(
    name="cli-tool",
    help="A reusable command-line tool that handles all common data operations with simple commands. Filter, transform, migrate, and validate datasets without writing custom scripts every time.",
    add_completion=False,
)

app.add_typer(filter_app, name="filter")
app.add_typer(transform_app, name="transform")
app.add_typer(migrate_app, name="migrate")
app.add_typer(validate_app, name="validate")
app.add_typer(container_app, name="container")

if __name__ == "__main__":
    app()
