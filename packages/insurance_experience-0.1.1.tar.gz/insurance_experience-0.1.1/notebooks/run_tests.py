# Databricks notebook source
# MAGIC %md
# MAGIC # Run insurance-experience tests on Databricks

# COMMAND ----------

# MAGIC %pip install pytest polars scipy numpy

# COMMAND ----------

import subprocess, sys

result = subprocess.run(
    [sys.executable, "-m", "pip", "install", "-e", "/Workspace/insurance-experience"],
    capture_output=True, text=True
)
print(result.stdout[-3000:] if len(result.stdout) > 3000 else result.stdout)
print(result.stderr[-2000:] if len(result.stderr) > 2000 else result.stderr)

# COMMAND ----------

result = subprocess.run(
    [sys.executable, "-m", "pytest",
     "/Workspace/insurance-experience/tests/",
     "--ignore=/Workspace/insurance-experience/tests/test_attention.py",
     "-v", "--tb=short", "-q"],
    capture_output=True, text=True,
    cwd="/Workspace/insurance-experience"
)
print(result.stdout)
print(result.stderr[-3000:] if len(result.stderr) > 3000 else result.stderr)
print("Return code:", result.returncode)
