from __future__ import annotations

import json
import mimetypes
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests

from .config import AppConfig


class WechatApiError(RuntimeError):
    pass


@dataclass
class UploadedImage:
    media_id: str
    url: str


@dataclass
class ImageReplacementResult:
    html: str
    first_uploaded_media_id: str


class WechatClient:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.session = requests.Session()

    def _request_json(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        last_error: Exception | None = None
        for attempt in range(1, self.config.retry_times + 1):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    params=params,
                    data=(
                        json.dumps(json_body, ensure_ascii=False).encode("utf-8")
                        if json_body is not None
                        else None
                    ),
                    headers=(
                        {"Content-Type": "application/json; charset=utf-8"}
                        if json_body is not None
                        else None
                    ),
                    files=files,
                    timeout=self.config.request_timeout,
                )
                response.raise_for_status()
                return response.json()
            except (requests.RequestException, ValueError) as exc:
                last_error = exc
                if attempt >= self.config.retry_times:
                    break
                sleep_seconds = self.config.retry_backoff_seconds * attempt
                time.sleep(sleep_seconds)
        raise WechatApiError(f"请求微信接口失败: {last_error}")

    def _load_token_cache(self) -> str | None:
        cache_file = self.config.token_cache_file
        if not cache_file.exists():
            return None
        try:
            payload = json.loads(cache_file.read_text(encoding="utf-8"))
            access_token = payload.get("access_token", "")
            expires_at = int(payload.get("expires_at", 0))
            if not access_token:
                return None
            if expires_at <= int(time.time()) + 60:
                return None
            return access_token
        except (OSError, ValueError, TypeError):
            return None

    def _save_token_cache(self, token: str, expires_in: int) -> None:
        cache_file = self.config.token_cache_file
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        expires_at = int(time.time()) + int(expires_in)
        payload = {"access_token": token, "expires_at": expires_at}
        cache_file.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def get_access_token(self, force_refresh: bool = False) -> str:
        if not force_refresh:
            cached = self._load_token_cache()
            if cached:
                return cached

        token_url = "https://api.weixin.qq.com/cgi-bin/stable_token"
        body = {
            "grant_type": "client_credential",
            "appid": self.config.app_id,
            "secret": self.config.app_secret,
            "force_refresh": force_refresh,
        }
        data = self._request_json("POST", token_url, json_body=body)
        errcode = int(data.get("errcode", 0))
        if errcode != 0:
            errmsg = data.get("errmsg", "unknown error")
            raise WechatApiError(f"获取 access_token 失败: errcode={errcode}, errmsg={errmsg}")

        token = data.get("access_token", "")
        expires_in = int(data.get("expires_in", 0))
        if not token or expires_in <= 0:
            raise WechatApiError("微信返回的 access_token 无效")
        self._save_token_cache(token, expires_in)
        return token

    def upload_material_image(self, image_path: Path) -> UploadedImage:
        if not image_path.exists() or not image_path.is_file():
            raise WechatApiError(f"图片文件不存在: {image_path}")
        token = self.get_access_token()
        url = "https://api.weixin.qq.com/cgi-bin/material/add_material"
        mime_type = mimetypes.guess_type(str(image_path))[0] or "application/octet-stream"
        with image_path.open("rb") as file_pointer:
            files = {"media": (image_path.name, file_pointer, mime_type)}
            data = self._request_json(
                "POST",
                url,
                params={"access_token": token, "type": "image"},
                files=files,
            )
        media_id = str(data.get("media_id", "")).strip()
        image_url = str(data.get("url", "")).strip()
        if not media_id or not image_url:
            errcode = int(data.get("errcode", -1))
            errmsg = data.get("errmsg", "unknown error")
            raise WechatApiError(f"上传素材库图片失败: errcode={errcode}, errmsg={errmsg}")
        return UploadedImage(media_id=media_id, url=image_url)

    def replace_local_images(self, html: str, base_dir: Path) -> ImageReplacementResult:
        pattern = re.compile(r'<img[^>]*src=["\']([^"\']+)["\'][^>]*>', re.IGNORECASE)
        replaced_html = html
        matched_sources = pattern.findall(html)
        uploaded_cache: dict[str, UploadedImage] = {}
        first_uploaded_media_id = ""
        for src in matched_sources:
            normalized = src.strip()
            if normalized.startswith(("http://", "https://", "data:")):
                continue
            if normalized in uploaded_cache:
                replaced_html = replaced_html.replace(src, uploaded_cache[normalized].url)
                continue
            local_path = (base_dir / normalized).resolve()
            uploaded_image = self.upload_material_image(local_path)
            uploaded_cache[normalized] = uploaded_image
            if not first_uploaded_media_id:
                first_uploaded_media_id = uploaded_image.media_id
            replaced_html = replaced_html.replace(src, uploaded_image.url)
        return ImageReplacementResult(
            html=replaced_html,
            first_uploaded_media_id=first_uploaded_media_id,
        )

    def create_draft(self, article_payload: dict[str, Any]) -> str:
        return self._create_draft_inner(article_payload, token_refresh_allowed=True)

    def _create_draft_inner(self, article_payload: dict[str, Any], token_refresh_allowed: bool) -> str:
        token = self.get_access_token(force_refresh=False)
        url = "https://api.weixin.qq.com/cgi-bin/draft/add"
        body = {"articles": [article_payload]}
        data = self._request_json("POST", url, params={"access_token": token}, json_body=body)

        errcode = int(data.get("errcode", 0))
        if errcode == 0:
            media_id = data.get("media_id", "")
            if not media_id:
                raise WechatApiError("草稿创建成功但未返回 media_id")
            return media_id

        token_invalid_codes = {40001, 40014, 42001}
        if errcode in token_invalid_codes and token_refresh_allowed:
            self.get_access_token(force_refresh=True)
            return self._create_draft_inner(article_payload, token_refresh_allowed=False)

        errmsg = data.get("errmsg", "unknown error")
        raise WechatApiError(f"创建草稿失败: errcode={errcode}, errmsg={errmsg}")
