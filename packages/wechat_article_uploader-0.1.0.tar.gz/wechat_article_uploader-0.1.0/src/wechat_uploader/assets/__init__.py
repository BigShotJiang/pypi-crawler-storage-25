# Package data container for bundled CSS assets.
