from __future__ import annotations

import html
import re
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path
from typing import Optional

import markdown as md_lib
from bs4 import BeautifulSoup


@dataclass
class ParsedArticle:
    title: str
    content_html: str
    digest: str


def load_style_css(style_file: Optional[Path] = None) -> str:
    if style_file is None:
        css_text = files("wechat_uploader.assets").joinpath("wechat_style.css").read_text(
            encoding="utf-8"
        )
    else:
        if not style_file.exists() or not style_file.is_file():
            raise FileNotFoundError(f"样式文件不存在: {style_file}")
        css_text = style_file.read_text(encoding="utf-8")
    css_text = css_text.strip()
    if not css_text:
        raise ValueError("样式文件为空")
    return css_text


def render_with_nice_style(content_html: str, style_css: str) -> str:
    decorated_html = _decorate_html_for_nice_theme(content_html)
    html_fragment = f"<section id=\"nice\">\n{decorated_html}\n</section>"
    return _inline_css_styles(html_fragment=html_fragment, style_css=style_css)


def parse_article_file(path: Path, digest_max_bytes: int = 120) -> ParsedArticle:
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"文章文件不存在: {path}")
    suffix = path.suffix.lower()
    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        raise ValueError(f"文章内容为空: {path}")

    if suffix == ".md":
        title, body = _extract_markdown_title_and_body(raw, fallback_title=path.stem)
        content_html = _markdown_to_html(body)
    elif suffix == ".txt":
        title, body = _extract_text_title_and_body(raw, fallback_title=path.stem)
        content_html = _text_to_html(body)
    else:
        raise ValueError(f"不支持的文章后缀: {suffix}")

    digest = _build_digest(body, max_bytes=digest_max_bytes)
    return ParsedArticle(title=title, content_html=content_html, digest=digest)


def _extract_markdown_title_and_body(raw: str, fallback_title: str) -> tuple[str, str]:
    lines = raw.splitlines()
    title = fallback_title
    title_line_index = -1

    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("# "):
            title = stripped[2:].strip() or fallback_title
            title_line_index = index
        elif stripped.startswith("## "):
            title = stripped[3:].strip() or fallback_title
            title_line_index = index
        break

    if title_line_index >= 0:
        body_lines = lines[:title_line_index] + lines[title_line_index + 1 :]
    else:
        body_lines = lines
    body = "\n".join(body_lines).strip()
    if not body:
        body = title
    return title, body


def _extract_text_title_and_body(raw: str, fallback_title: str) -> tuple[str, str]:
    lines = [line.rstrip() for line in raw.splitlines()]
    non_empty_lines = [line for line in lines if line.strip()]
    if not non_empty_lines:
        return fallback_title, fallback_title
    title = non_empty_lines[0].strip() or fallback_title

    has_same_first_line = lines and lines[0].strip() == title
    if has_same_first_line:
        body = "\n".join(lines[1:]).strip()
    else:
        body = "\n".join(lines).strip()
    if not body:
        body = title
    return title, body


def _markdown_to_html(content: str) -> str:
    return md_lib.markdown(
        content,
        extensions=["extra", "sane_lists", "nl2br"],
        output_format="html5",
    )


def _text_to_html(content: str) -> str:
    paragraphs = [line.strip() for line in content.splitlines() if line.strip()]
    return "".join(f"<p>{html.escape(item)}</p>" for item in paragraphs)


def _build_digest(content: str, max_bytes: int) -> str:
    plain = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", content)
    plain = re.sub(r"\[[^\]]+\]\([^)]+\)", "", plain)
    plain = re.sub(r"[#>*`~\-]+", " ", plain)
    plain = re.sub(r"\s+", " ", plain).strip()
    if not plain:
        return ""
    plain_bytes = plain.encode("utf-8")
    if len(plain_bytes) <= max_bytes:
        return plain

    ellipsis = "..."
    ellipsis_bytes = ellipsis.encode("utf-8")
    allowed_bytes = max(0, max_bytes - len(ellipsis_bytes))
    clipped = plain_bytes[:allowed_bytes].decode("utf-8", errors="ignore").rstrip()
    return f"{clipped}{ellipsis}"


def _decorate_html_for_nice_theme(content_html: str) -> str:
    heading_pattern = re.compile(r"<h([1-4])>(.*?)</h\1>", re.DOTALL)

    def replace_heading(match: re.Match[str]) -> str:
        level = match.group(1)
        inner = match.group(2).strip()
        return f"<h{level}><span class=\"content\">{inner}</span></h{level}>"

    styled_html = heading_pattern.sub(replace_heading, content_html)
    list_item_pattern = re.compile(r"<li>(.*?)</li>", re.DOTALL)

    def replace_list_item(match: re.Match[str]) -> str:
        inner = match.group(1).strip()
        if re.search(r"<section\b", inner, re.IGNORECASE):
            return match.group(0)
        return f"<li><section>{inner}</section></li>"

    styled_html = list_item_pattern.sub(replace_list_item, styled_html)
    return styled_html


def _inline_css_styles(html_fragment: str, style_css: str) -> str:
    soup = BeautifulSoup(html_fragment, "html.parser")
    for selector, declarations in _parse_css_rules(style_css):
        if not declarations.strip():
            continue
        if ":" in selector:
            continue
        try:
            nodes = soup.select(selector)
        except Exception:
            continue
        for node in nodes:
            existing_style = node.get("style", "").strip()
            if existing_style and not existing_style.endswith(";"):
                existing_style += ";"
            merged_style = f"{existing_style}{declarations}".strip()
            node["style"] = merged_style
    return str(soup)


def _parse_css_rules(style_css: str) -> list[tuple[str, str]]:
    css_no_comment = re.sub(r"/\*.*?\*/", "", style_css, flags=re.DOTALL)
    pattern = re.compile(r"([^{}]+)\{([^{}]*)\}", re.DOTALL)
    rules: list[tuple[str, str]] = []
    for match in pattern.finditer(css_no_comment):
        selectors_text = match.group(1).strip()
        declarations = _normalize_css_declarations(match.group(2))
        if not selectors_text or not declarations:
            continue
        selectors = [item.strip() for item in selectors_text.split(",") if item.strip()]
        for selector in selectors:
            rules.append((selector, declarations))
    return rules


def _normalize_css_declarations(block: str) -> str:
    declarations = [line.strip() for line in block.split(";") if line.strip()]
    if not declarations:
        return ""
    return "; ".join(declarations) + ";"
