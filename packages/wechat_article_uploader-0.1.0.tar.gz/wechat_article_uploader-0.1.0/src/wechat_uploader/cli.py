from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from .config import AppConfig, ConfigError, get_user_config_path, load_config
from .parser import (
    ParsedArticle,
    load_style_css,
    parse_article_file,
    render_with_nice_style,
)
from .wechat_client import ImageReplacementResult, WechatApiError, WechatClient


SUPPORTED_EXTENSIONS = {".md", ".txt"}


@dataclass
class UploadResult:
    file: str
    title: str
    status: str
    draft_media_id: str = ""
    error: str = ""


def _truncate_utf8_bytes(text: str, max_bytes: int) -> str:
    if max_bytes <= 0:
        return ""
    raw = text.encode("utf-8")
    if len(raw) <= max_bytes:
        return text
    return raw[:max_bytes].decode("utf-8", errors="ignore").rstrip()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="读取文章文件并上传到微信公众号草稿箱。"
    )
    parser.add_argument(
        "--config",
        type=Path,
        help="配置文件路径；默认优先读取当前目录 config.toml，其次读取系统配置目录",
    )
    parser.add_argument(
        "--print-config-path",
        action="store_true",
        help="打印默认配置文件路径并退出",
    )
    target_group = parser.add_mutually_exclusive_group(required=False)
    target_group.add_argument("--file", type=Path, help="单篇文章文件路径（md/txt）")
    target_group.add_argument("--dir", type=Path, help="文章目录，自动批量上传")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="仅解析并预览，不调用微信公众号接口",
    )
    parser.add_argument("--author", default="", help="覆盖默认作者")
    parser.add_argument("--thumb-media-id", default="", help="覆盖默认封面媒体ID")
    parser.add_argument("--digest", default="", help="覆盖自动摘要")
    parser.add_argument("--content-source-url", default="", help="覆盖原文链接")
    parser.add_argument(
        "--copyright-type",
        type=int,
        choices=[0, 1, 2],
        default=-1,
        help="兼容参数（当前草稿接口不生效）：0=不传，1=原创，2=转载",
    )
    parser.add_argument(
        "--need-open-comment",
        type=int,
        choices=[0, 1],
        default=-1,
        help="覆盖默认评论开关：0=关闭，1=开启",
    )
    parser.add_argument(
        "--only-fans-can-comment",
        type=int,
        choices=[0, 1],
        default=-1,
        help="覆盖默认仅粉丝可评论：0=否，1=是",
    )
    parser.add_argument(
        "--log-dir",
        type=Path,
        default=Path("logs"),
        help="结果日志目录",
    )
    return parser


def resolve_files(single_file: Optional[Path], directory: Optional[Path]) -> list[Path]:
    if single_file:
        if not single_file.exists():
            raise FileNotFoundError(f"文件不存在: {single_file}")
        if single_file.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise ValueError(f"不支持的文件类型: {single_file.suffix}")
        return [single_file]

    if directory is None:
        return []

    if not directory.exists():
        raise FileNotFoundError(f"目录不存在: {directory}")
    if not directory.is_dir():
        raise NotADirectoryError(f"不是目录: {directory}")

    files = [
        path
        for path in sorted(directory.rglob("*"))
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS
    ]
    if not files:
        raise FileNotFoundError(f"目录中没有可上传文件: {directory}")
    return files


def resolve_thumb_media_id(
    args: argparse.Namespace,
    config: AppConfig,
    first_uploaded_media_id: str,
) -> str:
    if args.thumb_media_id:
        return args.thumb_media_id
    if config.default_thumb_media_id:
        return config.default_thumb_media_id
    if first_uploaded_media_id:
        print(f"未配置封面ID，已自动使用正文中第一张上传图片的 media_id: {first_uploaded_media_id}")
        return first_uploaded_media_id
    raise ConfigError(
        "未提供封面 thumb_media_id，且正文中也没有可作为封面的本地图片。"
        "请在配置文件中填写 default_thumb_media_id、通过 --thumb-media-id 传入，"
        "或在文章中至少包含一张可上传的本地图片。"
    )


def upload_articles(
    files: list[Path],
    config: AppConfig,
    args: argparse.Namespace,
) -> list[UploadResult]:
    results: list[UploadResult] = []
    try:
        style_css = load_style_css(config.style_file)
    except (OSError, ValueError) as exc:
        raise ConfigError(f"加载样式文件失败: {exc}") from exc

    client: Optional[WechatClient] = None
    if not args.dry_run:
        client = WechatClient(config=config)

    for file_path in files:
        try:
            parsed: ParsedArticle = parse_article_file(file_path)
            author = args.author or config.default_author
            digest = args.digest or parsed.digest
            source_url = args.content_source_url or config.default_content_source_url
            need_open_comment = (
                args.need_open_comment
                if args.need_open_comment in (0, 1)
                else config.default_need_open_comment
            )
            only_fans_can_comment = (
                args.only_fans_can_comment
                if args.only_fans_can_comment in (0, 1)
                else config.default_only_fans_can_comment
            )
            content_html = render_with_nice_style(parsed.content_html, style_css)
            image_result = ImageReplacementResult(
                html=content_html,
                first_uploaded_media_id="",
            )

            if client is not None:
                image_result = client.replace_local_images(
                    html=content_html,
                    base_dir=file_path.parent,
                )
                content_html = image_result.html

            thumb_media_id = ""
            if not args.dry_run:
                thumb_media_id = resolve_thumb_media_id(
                    args=args,
                    config=config,
                    first_uploaded_media_id=image_result.first_uploaded_media_id,
                )

            article_payload = {
                "title": parsed.title,
                "author": author,
                "digest": digest,
                "content": content_html,
                "content_source_url": source_url,
                "thumb_media_id": thumb_media_id,
                "need_open_comment": need_open_comment,
                "only_fans_can_comment": only_fans_can_comment,
            }

            if args.dry_run:
                results.append(
                    UploadResult(
                        file=str(file_path),
                        title=parsed.title,
                        status="dry_run",
                    )
                )
                continue

            if client is None:
                raise ConfigError("运行时客户端未初始化")

            try:
                draft_media_id = client.create_draft(article_payload)
            except WechatApiError as exc:
                err_text = str(exc)
                if "description size out of limit" not in err_text:
                    raise
                retry_payload = dict(article_payload)
                retry_payload["digest"] = _truncate_utf8_bytes(retry_payload.get("digest", ""), 48)
                try:
                    draft_media_id = client.create_draft(retry_payload)
                except WechatApiError as retry_exc:
                    if "description size out of limit" not in str(retry_exc):
                        raise
                    retry_payload["digest"] = ""
                    draft_media_id = client.create_draft(retry_payload)
            results.append(
                UploadResult(
                    file=str(file_path),
                    title=parsed.title,
                    status="success",
                    draft_media_id=draft_media_id,
                )
            )
        except (WechatApiError, ValueError, OSError) as exc:
            results.append(
                UploadResult(
                    file=str(file_path),
                    title=file_path.stem,
                    status="failed",
                    error=str(exc),
                )
            )

    return results


def write_reports(results: list[UploadResult], log_dir: Path) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    result_path = log_dir / f"upload_results_{timestamp}.json"
    failed_path = log_dir / "failed.json"

    serializable_results = [asdict(item) for item in results]
    failed_results = [item for item in serializable_results if item["status"] == "failed"]

    result_path.write_text(
        json.dumps(serializable_results, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    failed_path.write_text(
        json.dumps(failed_results, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def print_summary(results: list[UploadResult]) -> None:
    success_count = sum(1 for item in results if item.status == "success")
    dry_run_count = sum(1 for item in results if item.status == "dry_run")
    failed_count = sum(1 for item in results if item.status == "failed")
    print(f"处理完成: success={success_count}, dry_run={dry_run_count}, failed={failed_count}")
    for item in results:
        if item.status == "success":
            print(f"[SUCCESS] {item.file} -> draft_media_id={item.draft_media_id}")
        elif item.status == "dry_run":
            print(f"[DRY-RUN] {item.file} -> title={item.title}")
        else:
            print(f"[FAILED] {item.file} -> error={item.error}")


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.print_config_path:
        print(get_user_config_path())
        return 0

    if not args.file and not args.dir:
        parser.error("请通过 --file 或 --dir 指定要处理的文章")

    try:
        config = load_config(
            config_file=args.config,
            require_auth=not args.dry_run,
        )
        if args.copyright_type in (1, 2):
            print(
                "提示: 当前微信 draft/add 接口不支持通过 API 设置原创声明/创作来源。"
                "该参数会被忽略，请在公众号后台草稿编辑页手动设置。"
            )
        files = resolve_files(args.file, args.dir)
        results = upload_articles(files=files, config=config, args=args)
        write_reports(results=results, log_dir=args.log_dir)
        print_summary(results=results)
        return 0 if all(item.status != "failed" for item in results) else 1
    except (ConfigError, OSError, ValueError) as exc:
        print(f"运行失败: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
