from __future__ import annotations

import os
import sys
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib


class ConfigError(RuntimeError):
    pass


CONFIG_FILENAME = "config.toml"
CONFIG_ENV_VARS = ("WECHAT_ARTICLE_UPLOADER_CONFIG", "WECHAT_UPLOADER_CONFIG")
CONFIG_SECTION_NAMES = ("wechat_article_uploader", "wechat_uploader")
APP_DIR_NAME = "wechat-article-uploader"


@dataclass
class AppConfig:
    app_id: str
    app_secret: str
    default_author: str
    default_thumb_media_id: str
    default_content_source_url: str
    default_need_open_comment: int
    default_only_fans_can_comment: int
    request_timeout: int
    retry_times: int
    retry_backoff_seconds: float
    token_cache_file: Path
    style_file: Optional[Path]
    config_file: Optional[Path]


def get_user_config_path() -> Path:
    if sys.platform == "win32":
        base_dir = Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base_dir = Path.home() / "Library" / "Application Support"
    else:
        base_dir = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base_dir / APP_DIR_NAME / CONFIG_FILENAME


def get_default_cache_path() -> Path:
    if sys.platform == "win32":
        base_dir = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base_dir = Path.home() / "Library" / "Caches"
    else:
        base_dir = Path(os.getenv("XDG_CACHE_HOME", Path.home() / ".cache"))
    return base_dir / APP_DIR_NAME / "token.json"


def iter_candidate_config_paths(explicit_path: Optional[Path] = None) -> list[Path]:
    candidates: list[Path] = []
    if explicit_path is not None:
        candidates.append(explicit_path.expanduser())
    else:
        for env_var in CONFIG_ENV_VARS:
            env_path = os.getenv(env_var, "").strip()
            if env_path:
                candidates.append(Path(env_path).expanduser())
        candidates.append(Path.cwd() / CONFIG_FILENAME)
        candidates.append(get_user_config_path())

    deduplicated: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        deduplicated.append(path)
    return deduplicated


def load_config(
    config_file: Optional[Path] = None,
    *,
    require_auth: bool = True,
) -> AppConfig:
    selected_path: Optional[Path] = None
    for candidate in iter_candidate_config_paths(config_file):
        if candidate.exists():
            selected_path = candidate.resolve()
            break

    payload: dict[str, Any] = {}
    config_dir = Path.cwd()
    if selected_path is None:
        if config_file is not None:
            raise ConfigError(f"配置文件不存在: {config_file.expanduser()}")
        if require_auth:
            raise ConfigError(
                "未找到配置文件。请先创建 config.toml，或通过 --config 指定。"
                f"默认配置路径: {get_user_config_path()}"
            )
    else:
        payload = _read_toml_file(selected_path)
        config_dir = selected_path.parent

    section_raw: Mapping[str, Any] | Any = payload
    for section_name in CONFIG_SECTION_NAMES:
        if section_name in payload:
            section_raw = payload[section_name]
            break
    if not isinstance(section_raw, Mapping):
        valid_sections = " 或 ".join(f"[{name}]" for name in CONFIG_SECTION_NAMES)
        raise ConfigError(f"配置文件格式错误: {valid_sections} 必须是对象")

    app_id = _get_required_str(section_raw, "app_id", require=require_auth)
    app_secret = _get_required_str(section_raw, "app_secret", require=require_auth)
    default_author = _get_str(section_raw, "default_author", "")
    default_thumb_media_id = _get_str(section_raw, "default_thumb_media_id", "")
    default_content_source_url = _get_str(section_raw, "default_content_source_url", "")
    default_need_open_comment = _get_choice_int(
        section_raw,
        "default_need_open_comment",
        0,
        {0, 1},
    )
    default_only_fans_can_comment = _get_choice_int(
        section_raw,
        "default_only_fans_can_comment",
        0,
        {0, 1},
    )
    request_timeout = _get_int(section_raw, "request_timeout", 20)
    retry_times = _get_int(section_raw, "retry_times", 3)
    retry_backoff_seconds = _get_float(section_raw, "retry_backoff_seconds", 1.5)
    token_cache_file = _resolve_optional_path(
        section_raw.get("token_cache_file"),
        base_dir=config_dir,
        default=get_default_cache_path(),
    )
    style_file = _resolve_optional_path(
        section_raw.get("style_file"),
        base_dir=config_dir,
        default=None,
    )

    if request_timeout <= 0:
        raise ConfigError("request_timeout 必须大于 0")
    if retry_times < 1:
        raise ConfigError("retry_times 必须大于等于 1")
    if retry_backoff_seconds <= 0:
        raise ConfigError("retry_backoff_seconds 必须大于 0")

    return AppConfig(
        app_id=app_id,
        app_secret=app_secret,
        default_author=default_author,
        default_thumb_media_id=default_thumb_media_id,
        default_content_source_url=default_content_source_url,
        default_need_open_comment=default_need_open_comment,
        default_only_fans_can_comment=default_only_fans_can_comment,
        request_timeout=request_timeout,
        retry_times=retry_times,
        retry_backoff_seconds=retry_backoff_seconds,
        token_cache_file=token_cache_file,
        style_file=style_file,
        config_file=selected_path,
    )


def _read_toml_file(path: Path) -> dict[str, Any]:
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ConfigError(f"读取配置文件失败: {path}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"配置文件 TOML 格式错误: {path}") from exc


def _get_required_str(data: Mapping[str, Any], key: str, *, require: bool) -> str:
    value = data.get(key, "")
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ConfigError(f"配置项 {key} 必须是字符串")
    value = value.strip()
    if require and not value:
        raise ConfigError(f"缺少配置项: {key}")
    return value


def _get_str(data: Mapping[str, Any], key: str, default: str) -> str:
    value = data.get(key, default)
    if value is None:
        return default
    if not isinstance(value, str):
        raise ConfigError(f"配置项 {key} 必须是字符串")
    return value.strip()


def _get_int(data: Mapping[str, Any], key: str, default_value: int) -> int:
    raw = data.get(key, default_value)
    try:
        return int(raw)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"配置项 {key} 不是合法整数: {raw}") from exc


def _get_float(data: Mapping[str, Any], key: str, default_value: float) -> float:
    raw = data.get(key, default_value)
    try:
        return float(raw)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"配置项 {key} 不是合法浮点数: {raw}") from exc


def _get_choice_int(
    data: Mapping[str, Any],
    key: str,
    default_value: int,
    allowed: set[int],
) -> int:
    value = _get_int(data, key, default_value)
    if value not in allowed:
        allowed_text = ",".join(str(item) for item in sorted(allowed))
        raise ConfigError(f"配置项 {key} 仅支持: {allowed_text}")
    return value


def _resolve_optional_path(
    raw_value: Any,
    *,
    base_dir: Path,
    default: Optional[Path],
) -> Optional[Path]:
    if raw_value in (None, ""):
        return default
    if not isinstance(raw_value, str):
        raise ConfigError("路径类配置项必须是字符串")
    path = Path(raw_value).expanduser()
    if not path.is_absolute():
        path = (base_dir / path).resolve()
    else:
        path = path.resolve()
    return path
