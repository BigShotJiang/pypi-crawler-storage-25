from wechat_uploader.parser import load_style_css, parse_article_file, render_with_nice_style


def test_parse_markdown_uses_heading_as_title(tmp_path):
    article = tmp_path / "article.md"
    article.write_text("# 标题\n\n第一段内容\n\n第二段内容", encoding="utf-8")

    parsed = parse_article_file(article)

    assert parsed.title == "标题"
    assert "<p>第一段内容</p>" in parsed.content_html
    assert parsed.digest.startswith("第一段内容")


def test_parse_text_uses_first_line_as_title(tmp_path):
    article = tmp_path / "note.txt"
    article.write_text("这是标题\n正文第一段\n正文第二段", encoding="utf-8")

    parsed = parse_article_file(article)

    assert parsed.title == "这是标题"
    assert "正文第一段" in parsed.content_html


def test_builtin_style_is_available():
    css_text = load_style_css()

    assert "#nice p" in css_text


def test_render_with_nice_style_wraps_content():
    rendered = render_with_nice_style("<h2>小标题</h2><p>正文</p>", load_style_css())

    assert "id=\"nice\"" in rendered
    assert "小标题" in rendered
    assert "正文" in rendered
