from wechat_uploader.wechat_client import UploadedImage, WechatClient


def test_replace_local_images_uses_first_uploaded_media_id(tmp_path):
    article_dir = tmp_path / "article"
    article_dir.mkdir()
    (article_dir / "cover.png").write_bytes(b"cover")
    (article_dir / "body.png").write_bytes(b"body")

    class DummyConfig:
        request_timeout = 20
        retry_times = 1
        retry_backoff_seconds = 1.0
        token_cache_file = tmp_path / "token.json"
        app_id = "demo"
        app_secret = "demo"

    client = WechatClient(DummyConfig())
    uploaded = [
        UploadedImage(media_id="media-cover", url="https://img.example/cover.png"),
        UploadedImage(media_id="media-body", url="https://img.example/body.png"),
    ]

    def fake_upload_material_image(_image_path):
        return uploaded.pop(0)

    client.upload_material_image = fake_upload_material_image  # type: ignore[method-assign]

    result = client.replace_local_images(
        '<p><img src="cover.png" /></p><p><img src="body.png" /></p>',
        article_dir,
    )

    assert result.first_uploaded_media_id == "media-cover"
    assert "https://img.example/cover.png" in result.html
    assert "https://img.example/body.png" in result.html


def test_replace_local_images_reuses_cached_upload(tmp_path):
    article_dir = tmp_path / "article"
    article_dir.mkdir()
    (article_dir / "cover.png").write_bytes(b"cover")

    class DummyConfig:
        request_timeout = 20
        retry_times = 1
        retry_backoff_seconds = 1.0
        token_cache_file = tmp_path / "token.json"
        app_id = "demo"
        app_secret = "demo"

    client = WechatClient(DummyConfig())
    upload_calls = []

    def fake_upload_material_image(image_path):
        upload_calls.append(image_path.name)
        return UploadedImage(media_id="media-cover", url="https://img.example/cover.png")

    client.upload_material_image = fake_upload_material_image  # type: ignore[method-assign]

    result = client.replace_local_images(
        '<p><img src="cover.png" /></p><p><img src="cover.png" /></p>',
        article_dir,
    )

    assert upload_calls == ["cover.png"]
    assert result.first_uploaded_media_id == "media-cover"
