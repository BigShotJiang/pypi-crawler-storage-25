from wechat_uploader.cli import main


def test_print_config_path(capsys):
    exit_code = main(["--print-config-path"])

    captured = capsys.readouterr()

    assert exit_code == 0
    assert "config.toml" in captured.out


def test_dry_run_works_without_config_file(tmp_path, monkeypatch):
    article = tmp_path / "article.md"
    article.write_text("# 标题\n\n这是正文。", encoding="utf-8")
    log_dir = tmp_path / "logs"

    monkeypatch.chdir(tmp_path)

    exit_code = main(
        [
            "--file",
            str(article),
            "--dry-run",
            "--log-dir",
            str(log_dir),
        ]
    )

    assert exit_code == 0
    assert (log_dir / "failed.json").exists()
