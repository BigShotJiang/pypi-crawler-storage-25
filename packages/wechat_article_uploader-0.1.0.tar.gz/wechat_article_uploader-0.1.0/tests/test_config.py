from pathlib import Path

from wechat_uploader.config import get_user_config_path, load_config


def test_load_config_from_explicit_file(tmp_path):
    style_file = tmp_path / "style.css"
    style_file.write_text("#nice {}", encoding="utf-8")

    config_file = tmp_path / "config.toml"
    config_file.write_text(
        """
[wechat_article_uploader]
app_id = "demo_app_id"
app_secret = "demo_secret"
default_author = "tester"
default_need_open_comment = 1
token_cache_file = "cache/token.json"
style_file = "style.css"
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_file=config_file)

    assert config.app_id == "demo_app_id"
    assert config.default_author == "tester"
    assert config.default_need_open_comment == 1
    assert config.token_cache_file == (tmp_path / "cache" / "token.json").resolve()
    assert config.style_file == style_file.resolve()


def test_legacy_section_name_still_works(tmp_path):
    config_file = tmp_path / "config.toml"
    config_file.write_text(
        """
[wechat_uploader]
app_id = "legacy_app_id"
app_secret = "legacy_secret"
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_file=config_file)

    assert config.app_id == "legacy_app_id"
    assert config.app_secret == "legacy_secret"


def test_dry_run_can_start_without_config(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    config = load_config(require_auth=False)

    assert config.app_id == ""
    assert config.app_secret == ""


def test_get_user_config_path_points_to_toml():
    path = get_user_config_path()

    assert isinstance(path, Path)
    assert path.name == "config.toml"
