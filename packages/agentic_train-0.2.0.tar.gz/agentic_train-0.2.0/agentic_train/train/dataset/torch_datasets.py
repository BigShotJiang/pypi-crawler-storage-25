from typing import Any, Dict, List

import polars as pl
from agentic_train.settings import QueryMultiPositiveDatasetSettings
from agentic_train.train.dataset import TorchDataset


class QueryMultiPositiveDataset(TorchDataset[QueryMultiPositiveDatasetSettings[Any], Dict[str, Any]]):
    """
    Each item:
      {
        "query": str,
        "positives": List[str]
      }
    """

    def __init__(self, config: QueryMultiPositiveDatasetSettings[Any]) -> None:
        super().__init__(config)
        grouped = self.dataset.polars.group_by(pl.col("metadata").struct.field("query")).agg(
            pl.col("page_content").alias("positives"),
        )

        self.queries: List[str] = grouped.select(pl.col("query")).to_series().to_list()
        self.positives: List[List[str]] = grouped["positives"].to_list()

        assert len(self.queries) == len(self.positives)

    def __len__(self) -> int:
        return len(self.queries)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        positives = self.positives[idx]
        return {
            "query": self.queries[idx],
            "positives": positives,
        }


class QueryPositiveDataset(TorchDataset[QueryMultiPositiveDatasetSettings[Any], Dict[str, str]]):
    """
    Flattened dataset:
      {
        "query": str,
        "positive": str
      }
    """

    def __init__(self, config: QueryMultiPositiveDatasetSettings[Any]) -> None:
        super().__init__(config)

        base_ds = QueryMultiPositiveDataset(config)

        rows: list[tuple[str, str]] = []
        for q, positives in zip(base_ds.queries, base_ds.positives):
            for pos in positives:
                rows.append((q, pos))

        self._queries = [q for q, _ in rows]
        self._positives = [p for _, p in rows]

        assert len(self._queries) == len(self._positives)

    def __len__(self) -> int:
        return len(self._queries)

    def __getitem__(self, idx: int) -> Dict[str, str]:
        return {
            "query": self._queries[idx],
            "positive": self._positives[idx],
        }
