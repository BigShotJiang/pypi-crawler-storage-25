import random
from typing import Any, Dict, List, Optional, Tuple

from agentic_train.settings import (
    InBatchPositiveCollateFnSettings,
    MultiPositiveInBatchCollateFnSettings,
)
from agentic_train.train.dataset import CollateFn


class InBatchPositiveCollateFn(CollateFn[InBatchPositiveCollateFnSettings, Dict[str, str]]):

    def __init__(self, config: InBatchPositiveCollateFnSettings, context: Optional[Dict[str, Any]]) -> None:
        super().__init__(config, context)

    def _process_batch(
        self,
        batch: List[Dict[str, str]],
    ) -> Tuple[List[str], List[str]]:
        queries: List[str] = []
        positives: List[str] = []

        for item in batch:
            queries.append(item["query"])
            positives.append(random.choice(item["positives"]))
        return queries, positives


class MultiPositiveInBatchCollateFn(CollateFn[MultiPositiveInBatchCollateFnSettings, Dict[str, str]]):

    def __init__(
        self,
        config: MultiPositiveInBatchCollateFnSettings,
        context: Optional[Dict[str, Any]],
    ) -> None:
        super().__init__(config, context)

    def _process_batch(
        self,
        batch: List[Dict[str, str]],
    ) -> Tuple[List[str], List[str]]:
        queries: List[str] = []
        passages: List[str] = []
        for item in batch:
            query = item["query"]
            positives = item["positives"]
            sampled_positives = [random.choice(positives) for _ in range(self.config.n_pos)]
            queries.append(query)
            passages.extend(sampled_positives)
        return queries, passages
