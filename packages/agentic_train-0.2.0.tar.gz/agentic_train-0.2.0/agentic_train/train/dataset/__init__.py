import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, List, Optional, Tuple, cast

import torch
from agentic_base.dataset import TextDataset
from agentic_base.enums import EmbeddingPurposeEnum
from agentic_base.evaluation import Processor
from agentic_base.mixins import FromConfigMixin
from agentic_train.types import T, TCCollateFn, TCTorchDataset
from agentic_train.utils import load_class
from datasets import Dataset as HFDataset  # type: ignore[import-untyped]
from torch.utils.data import Dataset as TorchDatasetBase
from transformers import AutoTokenizer, PreTrainedTokenizer

_logger = logging.getLogger(__name__)


class CollateFn(ABC, Generic[TCCollateFn, T]):

    def __init__(self, config: TCCollateFn, context: Optional[Dict[str, Any]]) -> None:
        self.config = config
        self.context = context
        self.tokenizer: PreTrainedTokenizer = self._load_tokenizer()
        self.processor: Processor[Any] = self._load_processor()

    @abstractmethod
    def _process_batch(self, batch: List[T]) -> Tuple[List[str], List[str]]:
        raise NotImplementedError()

    def _load_tokenizer(self) -> PreTrainedTokenizer:
        tokenizer = AutoTokenizer.from_pretrained(
            self.config.tokenizer.name, trust_remote_code=self.config.tokenizer.trust_remote_code
        )
        return cast(PreTrainedTokenizer, tokenizer)

    def _load_processor(self) -> Processor[Any]:
        processor: Processor[Any] = load_class(self.config.processor.module_path).from_config(self.config.processor)
        return processor

    def __call__(self, batch: List[T]) -> Tuple[torch.Tensor, torch.Tensor]:
        queries, candidates = self._process_batch(batch)
        return self._post_process(queries, candidates)

    def _post_process(self, queries: List[str], candidates: List[str]) -> Tuple[torch.Tensor, torch.Tensor]:
        queries = [self.processor(text=query, purpose=EmbeddingPurposeEnum.QUERY) for query in queries]  # type: ignore[arg-type]
        candidates = [self.processor(text=candidate, purpose=EmbeddingPurposeEnum.DOCUMENT) for candidate in candidates]  # type: ignore[arg-type]
        return self._tokenizer_qc(queries, candidates)

    def _tokenizer_qc(self, queries: List[str], candidates: List[str]) -> Tuple[torch.Tensor, torch.Tensor]:
        q_tok = self.tokenizer(
            queries,
            padding=self.config.tokenizer.padding,
            truncation=self.config.tokenizer.truncation,
            max_length=self.config.tokenizer.max_length,
            return_tensors="pt",
        )
        c_tok = self.tokenizer(
            candidates,
            padding=self.config.tokenizer.padding,
            truncation=self.config.tokenizer.truncation,
            max_length=self.config.tokenizer.max_length,
            return_tensors="pt",
        )
        return q_tok, c_tok


class TorchDataset(FromConfigMixin[TCTorchDataset], TorchDatasetBase[T], ABC, Generic[TCTorchDataset, T]):

    def __init__(self, config: TCTorchDataset) -> None:
        self.config = config
        self.dataset = self._load_dataset()

    @abstractmethod
    def __len__(self) -> int:
        raise NotImplementedError()

    def _load_dataset(self) -> TextDataset[Any]:
        dataset: TextDataset[Any] = (
            load_class(self.config.dataset_connector.module_path).from_config(self.config.dataset_connector).load_text()
        )
        _logger.info(f"Instantiating dataset | class={dataset.__class__.__name__} |")
        _logger.info(f"Dataset loaded | type={type(dataset).__name__} | " f"size={len(dataset)}")
        return dataset

    def to_hf_dataset(self) -> HFDataset:
        """
        Convert *this* TorchDataset (via __getitem__) to a HuggingFace Dataset.
        """
        rows: List[Dict[str, Any]] = [self[i] for i in range(len(self))]
        return HFDataset.from_list(rows)
