import logging
from abc import ABC, abstractmethod
from contextlib import nullcontext
from datetime import datetime
from typing import Any, Dict, Generic, Tuple, cast

import torch
import torch.nn.functional as F
from agentic_train.constants import RANDOM_SEED
from agentic_train.models import Model
from agentic_train.train.dataset import CollateFn
from agentic_train.train.dataset.torch_datasets import TorchDataset
from agentic_train.train.trainers import Trainer
from agentic_train.train.trainers.torch.loss import Loss
from agentic_train.types import TCPyTorchTrainer
from agentic_train.utils import load_class
from torch.optim import Optimizer
from torch.utils.data import DataLoader, random_split
from torch.utils.tensorboard import SummaryWriter

_logger = logging.getLogger(__name__)


class PyTorchTrainer(Trainer[TCPyTorchTrainer], ABC, Generic[TCPyTorchTrainer]):
    LOGS_PER_EPOCH = 51  # logs per epoch

    def __init__(self, config: TCPyTorchTrainer):
        super().__init__(config)
        self.run_name = self._run_name()
        self.device = self.config.device
        self.model = self._load_model().to_hf_model()
        self.optimizer = self._load_optimizer()
        self.writer = self._load_writer()
        self.num_epochs = self.config.num_epochs
        self.checkpoint_dir = self.config.data_dir / "checkpoints"
        self.save_every = self.config.save_every
        self.loss = self._load_loss()
        self.resume_from = self.config.resume_from
        self.torch_dataset: TorchDataset[Any, Any] = load_class(self.config.torch_dataset.module_path).from_config(
            self.config.torch_dataset
        )
        _logger.info(
            f"Initialized {self.__class__.__name__} | device={self.device} | \
            num_epochs={self.num_epochs} | save_every={self.save_every} | \
            resume_from={self.resume_from}"
        )

    @classmethod
    def get_nstep(cls, num_batches: int) -> int:
        return max(1, num_batches // cls.LOGS_PER_EPOCH)

    @abstractmethod
    def _encode_query(self, tokens: Dict[str, torch.Tensor]) -> torch.Tensor:
        raise NotImplementedError()

    @abstractmethod
    def _encode_documents(self, tokens: Dict[str, torch.Tensor]) -> torch.Tensor:
        raise NotImplementedError()

    @torch.no_grad()
    def _compute_val_score(self, batch: Any) -> float:
        q_tok, c_tok = batch
        q_emb = self._encode_query(q_tok)
        c_emb = self._encode_documents(c_tok)
        q_emb = F.normalize(q_emb, dim=-1)
        c_emb = F.normalize(c_emb, dim=-1)
        scores = q_emb @ c_emb.T  # (B, B)
        top1 = scores.argmax(dim=1)
        targets = torch.arange(scores.size(0), device=scores.device)
        recall_at_1 = (top1 == targets).float().mean()
        return cast(float, recall_at_1.item())

    def _step(
        self,
        batch: Tuple[Dict[str, torch.Tensor], Dict[str, torch.Tensor]],
    ) -> torch.Tensor:
        q_tok, c_tok = batch
        q_emb = self._encode_query(q_tok)
        c_emb = self._encode_documents(c_tok)
        return self.loss(q_emb, c_emb)

    def _run_name(self) -> str:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        class_name = self.config.module_path.split(".")[-1].lower()
        return f"{class_name}" f"_bs{self.config.batch_size}" f"_lr{self.config.lr}" f"_{ts}"

    def _load_model(self) -> Model[Any]:
        return cast(
            Model[Any], load_class(self.config.model.module_path).from_config(self.config.model).to(self.device)
        )

    def _load_optimizer(self) -> Optimizer:
        return torch.optim.AdamW(
            self.model.parameters(),
            lr=self.config.lr,
        )

    def _load_loss(self) -> Loss[Any]:
        return cast(Loss[Any], load_class(self.config.loss.module_path).from_config(self.config.loss))

    def _load_writer(self) -> SummaryWriter:
        log_dir = self.config.data_dir / f"tensorboard/runs/{self.run_name}"
        _logger.info(f"TensorBoard log dir | path={log_dir}")
        return SummaryWriter(log_dir=str(log_dir))

    def save_checkpoint(self, epoch: int) -> None:
        ckpt = {
            "epoch": epoch,
            "model_state": self.model.state_dict(),
            "optimizer_state": self.optimizer.state_dict(),
        }
        path = self.checkpoint_dir / f"{self.run_name}/epoch_{epoch:04d}.pt"
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(ckpt, path)

    def load_checkpoint(self) -> int:
        if self.resume_from:
            checkpoint_path = self.resume_from
            _logger.info(f"Loading checkpoint from {checkpoint_path}")
            ckpt = torch.load(checkpoint_path, map_location=self.device)
            self.model.load_state_dict(ckpt["model_state"])
            self.optimizer.load_state_dict(ckpt["optimizer_state"])
            _logger.info(f"Resuming training from epoch {ckpt["epoch"]}")
            return ckpt["epoch"]  # type:ignore[no-any-return]
        return 0

    def run_epoch(
        self,
        epoch: int,
        data_loader: DataLoader,
        training: bool,
    ) -> float:
        self.model.train() if training else self.model.eval()
        tag = "Train" if training else "Val"

        ctx = nullcontext() if training else torch.no_grad()
        loss_sum = 0.0
        num_batches = len(data_loader)

        for step, batch in enumerate(data_loader):
            with ctx:
                loss = self._step(batch)
            if training:
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
            loss_sum += loss.detach().item()
            if step % self.get_nstep(num_batches) == 0:
                if training:
                    _logger.info("%s epoch %d | step %d / %d", tag, epoch, step, num_batches)
                else:
                    val_score = self._compute_val_score(batch)
                    _logger.info("%s epoch %d | step %d / %d | score=%.4f", tag, epoch, step, num_batches, val_score)

        return loss_sum / num_batches

    def _fit(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
    ) -> None:
        start_epoch = self.load_checkpoint()
        for epoch in range(start_epoch + 1, self.num_epochs + 1):
            train_loss = self.run_epoch(epoch, train_loader, training=True)
            val_loss = self.run_epoch(epoch, val_loader, training=False)
            _logger.info(f"[Epoch {epoch:02d}] train loss: {train_loss:4f} | val loss: {val_loss:4f}")
            self.writer.add_scalar("loss/train_epoch", train_loss, epoch)
            self.writer.add_scalar("loss/val_epoch", val_loss, epoch)
            if epoch % self.save_every == 0:
                self.save_checkpoint(epoch)

    def _build_collate_fn(self) -> CollateFn[Any, Any]:
        collate_cls = load_class(self.config.collate_fn.module_path)
        _logger.info(
            f"Building collate function | class={collate_cls.__name__} | "
            f"module_path={self.config.collate_fn.module_path}"
        )
        context = {"torch_dataset": self.torch_dataset}
        collate_fn: CollateFn[Any, Any] = collate_cls(self.config.collate_fn, context)
        _logger.info("Collate function ready")
        return collate_fn

    def _load_dataloaders(self) -> Tuple[DataLoader, DataLoader]:
        collate_fn = self._build_collate_fn()
        n_total = len(self.torch_dataset)
        n_val = int((1 - self.config.train_frac) * n_total)
        n_train = n_total - n_val
        train_ds, val_ds = random_split(
            self.torch_dataset,
            [n_train, n_val],
            generator=torch.Generator().manual_seed(RANDOM_SEED),
        )
        train_loader = DataLoader(
            train_ds,
            batch_size=self.config.batch_size,
            shuffle=True,
            collate_fn=collate_fn,
            drop_last=self.config.drop_last,
        )
        val_loader = DataLoader(
            val_ds,
            batch_size=self.config.batch_size,
            shuffle=False,
            collate_fn=collate_fn,
            drop_last=self.config.drop_last,
        )
        return train_loader, val_loader

    def train(self) -> None:
        train_loader, val_loader = self._load_dataloaders()
        self._fit(train_loader, val_loader)
