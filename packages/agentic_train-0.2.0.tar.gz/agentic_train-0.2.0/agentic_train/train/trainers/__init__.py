from abc import ABC, abstractmethod
from datetime import datetime
from typing import Generic

from agentic_base.mixins import FromConfigMixin
from agentic_train.types import TCTrainer


class Trainer(FromConfigMixin[TCTrainer], ABC, Generic[TCTrainer]):

    def __init__(self, config: TCTrainer):
        super().__init__(config)

    def _run_name(self) -> str:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        class_name = self.config.module_path.split(".")[-1].lower()
        return f"{class_name}_{ts}"

    @abstractmethod
    def train(self) -> None:
        raise NotImplementedError()
