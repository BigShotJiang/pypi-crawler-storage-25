from pathlib import Path
from typing import Any, Dict, Generic, List, Literal, Optional, Self, Union

from agentic_base.dataset.settings import HuggingFaceDatasetAdaptaterSettings
from agentic_base.settings import FromConfigMixinSettings
from agentic_base.types import TCDatasetConnector, TCProcessor
from agentic_train.constants import TRUST_REMOTE_CODE
from agentic_train.exceptions import AgenticTrainValueError
from agentic_train.types import (
    TCCollateFn,
    TCDistance,
    TCLoss,
    TCModel,
    TCTorchDataset,
    TCTrainer,
)
from pydantic import Field
from pydantic_settings import BaseSettings


class TorchDatasetSettings(FromConfigMixinSettings, Generic[TCDatasetConnector]):
    dataset_connector: TCDatasetConnector


class TokenizerSettings(BaseSettings):
    name: str
    padding: Union[str, bool]
    truncation: bool
    max_length: int
    trust_remote_code: bool = TRUST_REMOTE_CODE


class SamplerSettings(BaseSettings):
    module_path: str
    seed: Optional[int]


class DistanceSettings(FromConfigMixinSettings):
    pass


class StepRangeDistanceSettings(DistanceSettings):
    pass


class PositiveSamplerSettings(SamplerSettings, Generic[TCDistance]):
    max_step_distance: int
    distance: TCDistance
    k: int


class CollateFnSettings(BaseSettings, Generic[TCProcessor]):
    module_path: str
    tokenizer: TokenizerSettings
    processor: TCProcessor


class InBatchPositiveCollateFnSettings(CollateFnSettings[TCProcessor], Generic[TCProcessor]):
    pass


class MultiPositiveInBatchCollateFnSettings(CollateFnSettings[TCProcessor], Generic[TCProcessor]):
    n_pos: int


class ModelSettings(FromConfigMixinSettings):
    pass


class LossSettings(FromConfigMixinSettings):
    pass


class TrainerSettings(FromConfigMixinSettings):
    data_dir: Path


class PyTorchTrainerSettings(TrainerSettings, Generic[TCModel, TCLoss, TCTorchDataset, TCCollateFn]):
    model: TCModel
    torch_dataset: TCTorchDataset
    collate_fn: TCCollateFn
    train_frac: float
    num_epochs: int
    batch_size: int
    shuffle: bool
    lr: float
    device: str
    save_every: int
    drop_last: bool
    loss: TCLoss
    resume_from: Optional[str] = None


class ContrastiveLossSettings(LossSettings):
    temperature: float


class QueryMultiPositiveDatasetSettings(TorchDatasetSettings[TCDatasetConnector]):
    pass


class InBatchNegativeContrastiveLossSettings(ContrastiveLossSettings):
    pass


class MultiPositiveContrastiveLossSettings(ContrastiveLossSettings):
    n_pos: int


class RunnerSettings(FromConfigMixinSettings):
    pass


class HFSettings(BaseSettings):
    repo: str
    revision: Optional[str]
    private: bool
    commit_message: Optional[str]


class PushToHFRunnerSettings(RunnerSettings, Generic[TCModel]):
    checkpoint_path: str = Field(init=False)
    device: str = Field(init=False)
    push: bool = Field(init=False)
    create_repo: bool = Field(init=False)
    hf: HFSettings = Field(init=False)
    model: TCModel = Field(init=False)


class TrainRunnerSettings(RunnerSettings, Generic[TCTrainer]):
    trainer: TCTrainer


class HardNegativesSettings(BaseSettings):
    range_min: int
    range_max: int
    max_score: float
    relative_margin: float
    num_negatives: int
    sampling_strategy: Literal["random", "top"]
    batch_size: int
    use_faiss: bool


class EvalutationSettings(BaseSettings):
    query_column: str
    document_column: str
    precision_recall_at_k: List[int]
    mrr_at_k: List[int]
    ndcg_at_k: List[int]
    batch_size: int


class SentenceTransformerLoss(LossSettings):
    kwargs: Dict[str, Any]


from pydantic import model_validator


class SentenceTransformersTrainerSettings(TrainerSettings, Generic[TCDatasetConnector, TCModel]):
    hf_dataset: HuggingFaceDatasetAdaptaterSettings[TCDatasetConnector]
    model: TCModel
    tokenizer: TokenizerSettings
    loss: SentenceTransformerLoss
    pooling: Literal["cls", "mean_tokens", "max_tokens"]
    batch_size: int
    num_epochs: int
    lr: float
    warmup_ratio: float
    eval_steps: int
    save_steps: int
    logging_steps: int
    fp16: bool
    train_frac: float
    resume_from: Optional[str]
    evaluation: EvalutationSettings
    trust_remote_code: bool = TRUST_REMOTE_CODE

    # -------------------------
    # CROSS-FIELD VALIDATION
    # -------------------------
    @model_validator(mode="after")
    def _validate_steps_consistency(self) -> Self:
        # 1️⃣ ordering
        if not (self.logging_steps <= self.eval_steps <= self.save_steps):
            raise AgenticTrainValueError(
                "Expected logging_steps ≤ eval_steps ≤ save_steps, got "
                f"{self.logging_steps} ≤ {self.eval_steps} ≤ {self.save_steps}"
            )

        # 2️⃣ alignment (CRITICAL)
        if self.save_steps % self.eval_steps != 0:
            raise AgenticTrainValueError(
                "save_steps must be a multiple of eval_steps "
                f"(got save_steps={self.save_steps}, eval_steps={self.eval_steps})"
            )

        return self
