from typing import TYPE_CHECKING, Any, Dict, TypeVar

if TYPE_CHECKING:
    from agentic_base.settings import FromConfigMixinSettings
    from agentic_train.settings import (
        CollateFnSettings,
        DistanceSettings,
        LossSettings,
        ModelSettings,
        PushToHFRunnerSettings,
        PyTorchTrainerSettings,
        RunnerSettings,
        SamplerSettings,
        SentenceTransformersTrainerSettings,
        TorchDatasetSettings,
        TrainerSettings,
        TrainRunnerSettings,
    )

T = TypeVar("T", bound=Dict[str, Any])
TModel = TypeVar("TModel")
TCTorchDataset = TypeVar("TCTorchDataset", bound="TorchDatasetSettings")
TCCollateFn = TypeVar("TCCollateFn", bound="CollateFnSettings")
TCModel = TypeVar("TCModel", bound="ModelSettings")
TCTrainer = TypeVar("TCTrainer", bound="TrainerSettings")
TCPyTorchTrainer = TypeVar("TCPyTorchTrainer", bound="PyTorchTrainerSettings[Any, Any, Any, Any]")
TCLoss = TypeVar("TCLoss", bound="LossSettings")
TCRunner = TypeVar("TCRunner", bound="RunnerSettings")
TCTrainRunner = TypeVar("TCTrainRunner", bound="TrainRunnerSettings[Any]")
TCHFTrainRunner = TypeVar("TCHFTrainRunner", bound="SentenceTransformersTrainerSettings[Any, Any]")
TCPushToHFRunner = TypeVar("TCPushToHFRunner", bound="PushToHFRunnerSettings[Any]")
TCFromConfigMixin = TypeVar("TCFromConfigMixin", bound="FromConfigMixinSettings")
TCSampler = TypeVar("TCSampler", bound="SamplerSettings")
TCDistance = TypeVar("TCDistance", bound="DistanceSettings")
