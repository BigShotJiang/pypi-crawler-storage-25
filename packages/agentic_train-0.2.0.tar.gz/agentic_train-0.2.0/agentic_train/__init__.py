from abc import ABC, abstractmethod
from typing import Any, Generic, Type

import yaml
from agentic_base.mixins import FromConfigMixin
from agentic_train.exceptions import InvalidRunnerClassError
from agentic_train.types import TCRunner
from agentic_train.utils import load_class


class Runner(FromConfigMixin[TCRunner], ABC, Generic[TCRunner]):
    def __init__(self, config: TCRunner):
        self.config = config

    @abstractmethod
    def run(self) -> None:
        raise NotImplementedError()

    @classmethod
    def _validate_klass(self, symbol: Any) -> Type["Runner[TCRunner]"]:
        if not isinstance(symbol, type):
            raise InvalidRunnerClassError(f"Loaded object is not a class: {symbol!r}")
        # 2️⃣ Ensure it is a Runner subclass
        if not issubclass(symbol, Runner):
            raise InvalidRunnerClassError(
                f"Class {symbol.__module__}.{symbol.__name__} " f"is not a subclass of Runner"
            )
        return symbol

    @classmethod
    def get_runner(cls, config_path: str) -> "Runner[TCRunner]":
        with open(config_path) as f:
            yaml_config = yaml.safe_load(f)
            symbol = load_class(yaml_config["module_path"])
            klass: Type["Runner[TCRunner]"] = cls._validate_klass(symbol)
            return klass.from_settings()
