# finetune_embedder/src/runners/push_to_hf.py
import inspect
import logging
from pathlib import Path
from typing import Any, Generic, List

from agentic_train import Runner
from agentic_train.models import Model
from agentic_train.types import TCPushToHFRunner
from agentic_train.utils import load_class
from huggingface_hub import HfApi

_logger = logging.getLogger(__name__)


class PushToHFRunner(Runner[TCPushToHFRunner], Generic[TCPushToHFRunner]):
    def __init__(self, config: TCPushToHFRunner) -> None:
        super().__init__(config)

    def _infer_model_name(self) -> str:
        name: str = self.wrapper_cls.__name__
        if not name.endswith("ModelWrapper"):
            raise ValueError(f"Model wrapper class must end with 'ModelWrapper', got {name}")
        return name.removesuffix("ModelWrapper").lower()

    def _find_model_source_dir(self) -> Path:
        module_file = Path(inspect.getfile(self.wrapper_cls)).resolve()
        models_dir = module_file.parent
        return models_dir

    def _collect_model_files(self) -> list[Path]:
        model_name = self._infer_model_name()
        models_dir = self._find_model_source_dir()

        model_dir = models_dir / model_name
        if not model_dir.exists():
            raise FileNotFoundError(f"Model directory not found: {model_dir}")

        files: List[Path] = []

        for pattern in (
            "modeling_*.py",
            "configuration_*.py",
            "vllm_modeling_*.py",
            "vllm_configuration_*.py",
        ):
            files.extend(model_dir.glob(pattern))

        if not files:
            raise RuntimeError(f"No model source files found in {model_dir}")

        return sorted(set(files))

    def _save_model_source_files(self) -> None:
        files = self._collect_model_files()
        for src in files:
            dst = Path(self.config.hf.repo) / src.name
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")

    def _load_model(self) -> Model[Any]:
        _logger.info(f"Loading model class from {self.config.model.module_path}")
        model_cls: Model[Any] = load_class(self.config.model.module_path)
        return model_cls.from_checkpoint(
            config=self.config.model,
            checkpoint=self.config.checkpoint_path,
            device=self.config.device,
        )

    def _load_wrapper(self) -> None:
        _logger.info(f"Loading model wrapper → {self.config.model.module_path}")
        self.wrapper_cls = load_class(self.config.model.module_path)

    def _load_model_from_checkpoint(self) -> None:
        _logger.info(f"Loading model from checkpoint → {self.config.checkpoint_path}")
        self.model: Model[Any] = self.wrapper_cls.from_checkpoint(
            config=self.config.model,
            checkpoint=self.config.checkpoint_path,
            device=self.config.device,
        )

    def _save_model_locally(self) -> None:
        _logger.info("Saving model locally → %s", self.config.hf.repo)
        self.model.save(
            repo_dir=self.config.hf.repo,
            push=False,  # we control pushing
            create_repo=self.config.create_repo,
            revision=self.config.hf.revision,
            private=self.config.hf.private,
            commit_message=self.config.hf.commit_message,
        )

    def _ensure_hf_repo_exists(self) -> None:
        if not self.config.create_repo:
            return
        _logger.info(
            f"Ensuring Hugging Face repo exists | repo={self.config.hf.repo} | private={self.config.hf.private}"
        )
        api = HfApi()
        api.create_repo(
            repo_id=self.config.hf.repo,
            repo_type="model",
            private=self.config.hf.private,
            exist_ok=True,  # safe for retries / CI
        )

    def _push_repo_to_hf(self) -> None:
        _logger.info(
            f"Pushing full repository folder to Hugging Face | repo={self.config.hf.repo} | revision={self.config.hf.revision}"
        )
        api = HfApi()
        api.upload_folder(
            folder_path=self.config.hf.repo,
            repo_id=self.config.hf.repo,
            repo_type="model",
            revision=self.config.hf.revision,
            commit_message=self.config.hf.commit_message,
        )
        _logger.info("Repository successfully pushed to Hugging Face")

    def run(self) -> None:
        self._load_wrapper()
        self._load_model_from_checkpoint()
        self._save_model_locally()
        self._save_model_source_files()
        if self.config.push:
            self._ensure_hf_repo_exists()
            self._push_repo_to_hf()
        _logger.info("PushToHFRunner completed successfully")
