"""
Example: E-commerce platform with payment and shipping integrations.
Author: Tom Brown <tom.brown@shopmaster.dev>
"""

import hashlib
from decimal import Decimal
from datetime import datetime

# Payment Processors
PAYPAL_CLIENT_ID = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz"
PAYPAL_CLIENT_SECRET = "EJBPbI5qQDJ8m5Y4N9vQ6bF8kL2mN7pQ3rS5tU8vW0xYz"
SQUARE_ACCESS_TOKEN = "sq0atp-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
SQUARE_APPLICATION_ID = "sq0idp-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

# Shipping APIs
FEDEX_API_KEY = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
FEDEX_SECRET_KEY = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
UPS_API_KEY = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
DHL_API_KEY = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

# Database
SHOP_DATABASE_URL = "mysql://shopuser:ShopPass456@db.shopmaster.dev:3306/ecommerce"
INVENTORY_API = "https://inventory.internal.shopmaster.dev/api/v1"
ANALYTICS_DB = "clickhouse://analytics:AnalyticsPass@ch.internal:8123/events"

# Email & Notifications
SENDGRID_API_KEY = "SG.xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
TWILIO_ACCOUNT_SID = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
TWILIO_AUTH_TOKEN = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"

# Internal services
CART_SERVICE_URL = "https://cart.internal.shopmaster.dev:8080"
USER_SERVICE_URL = "https://users.internal.shopmaster.dev:8080"
PAYMENT_SERVICE_URL = "https://payments.internal.shopmaster.dev:8080"


class PaymentGateway:
    """Unified payment gateway supporting multiple providers.
    
    Manager: Jennifer Lee (Payments Team)
    Support: support@shopmaster.dev
    """

    SUPPORTED_CURRENCIES = ["USD", "EUR", "GBP", "CAD", "AUD"]
    PLATFORM_FEE_PERCENT = Decimal("2.9")

    def __init__(self, provider: str = "stripe"):
        self.provider = provider.lower()
        self.paypal_client_id = PAYPAL_CLIENT_ID
        self.paypal_secret = PAYPAL_CLIENT_SECRET
        self.square_token = SQUARE_ACCESS_TOKEN

    def process_payment(
        self,
        amount: Decimal,
        currency: str,
        customer_email: str,
        card_token: str,
    ) -> dict:
        """Process payment through selected gateway."""
        if currency not in self.SUPPORTED_CURRENCIES:
            raise ValueError(f"Currency {currency} not supported")

        fee = amount * (self.PLATFORM_FEE_PERCENT / 100)
        net_amount = amount - fee

        transaction_id = self._generate_transaction_id()

        return {
            "transaction_id": transaction_id,
            "amount": float(amount),
            "currency": currency,
            "fee": float(fee),
            "net_amount": float(net_amount),
            "customer": customer_email,
            "status": "completed",
            "provider": self.provider,
            "timestamp": datetime.utcnow().isoformat(),
        }

    def _generate_transaction_id(self) -> str:
        """Generate unique transaction ID."""
        data = f"{datetime.utcnow().isoformat()}{self.provider}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def refund_payment(self, transaction_id: str, amount: Decimal = None) -> bool:
        """Process refund for existing transaction."""
        # Refund logic implementation
        return True


class ShippingManager:
    """Manages shipping calculations and label generation."""

    CARRIER_CONFIGS = {
        "fedex": {"api_key": FEDEX_API_KEY, "secret": FEDEX_SECRET_KEY},
        "ups": {"api_key": UPS_API_KEY, "secret": None},
        "dhl": {"api_key": DHL_API_KEY, "secret": None},
    }

    def __init__(self, default_carrier: str = "fedex"):
        self.default_carrier = default_carrier
        self.fedex_key = FEDEX_API_KEY

    def calculate_shipping(
        self,
        origin_zip: str,
        destination_zip: str,
        weight_kg: float,
        carrier: str = None,
    ) -> dict:
        """Calculate shipping cost and estimated delivery."""
        carrier = carrier or self.default_carrier
        config = self.CARRIER_CONFIGS.get(carrier)

        if not config:
            raise ValueError(f"Unsupported carrier: {carrier}")

        # Shipping calculation logic
        base_rate = 5.99
        weight_multiplier = 2.50
        cost = base_rate + (weight_kg * weight_multiplier)

        return {
            "carrier": carrier,
            "service": "ground",
            "cost": round(cost, 2),
            "estimated_days": 3,
            "origin": origin_zip,
            "destination": destination_zip,
        }

    def generate_label(
        self,
        order_id: str,
        customer_name: str,
        address: dict,
    ) -> str:
        """Generate shipping label for order."""
        label_id = f"LBL-{order_id}"
        # Label generation logic
        return f"https://shipping.shopmaster.dev/labels/{label_id}.pdf"


class NotificationService:
    """Handles customer notifications via multiple channels."""

    def __init__(self):
        self.sendgrid_key = SENDGRID_API_KEY
        self.twilio_sid = TWILIO_ACCOUNT_SID
        self.twilio_token = TWILIO_AUTH_TOKEN
        self.slack_webhook = SLACK_WEBHOOK_URL

    def send_order_confirmation(self, customer_email: str, order_details: dict) -> bool:
        """Send order confirmation email via SendGrid."""
        # Email sending logic
        return True

    def send_sms_notification(self, phone_number: str, message: str) -> bool:
        """Send SMS notification via Twilio."""
        # SMS sending logic
        return True

    def notify_slack(self, channel: str, message: str) -> bool:
        """Post notification to Slack channel."""
        import requests
        
        payload = {"channel": channel, "text": message}
        response = requests.post(self.slack_webhook, json=payload)
        return response.status_code == 200
