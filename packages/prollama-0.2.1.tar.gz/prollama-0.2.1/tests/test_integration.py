"""Integration tests for the full anonymization pipeline.

Tests that regex, NLP, and AST layers work together correctly,
including rehydration roundtrips and edge cases.
"""

from pathlib import Path

from prollama.anonymizer import AnonymizationPipeline, RegexAnonymizer
from prollama.models import PrivacyLevel

FIXTURES_DIR = Path(__file__).parent / "fixtures"


class TestRegexEdgeCases:
    """Edge cases for regex anonymization."""

    def test_multiple_secrets_same_type(self):
        code = (
            'KEY1 = "sk_live_aaaaaaaaaaaaaaaaaaaaaaaaa"\n'
            'KEY2 = "sk_live_bbbbbbbbbbbbbbbbbbbbbbbbb"\n'
        )
        anon = RegexAnonymizer()
        result, mappings = anon.anonymize(code)
        assert result.count("[SECRET_") == 2
        assert "sk_live_aaa" not in result
        assert "sk_live_bbb" not in result

    def test_jwt_detection(self):
        code = 'token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"'
        anon = RegexAnonymizer()
        result, mappings = anon.anonymize(code)
        assert "eyJ" not in result

    def test_database_url_variants(self):
        urls = [
            "postgresql://user:pass@host:5432/db",
            "mysql://root:pass@localhost/mydb",
            "mongodb+srv://admin:pass@cluster.net/db",
            "redis://cache:6379/0",
        ]
        anon = RegexAnonymizer()
        for url in urls:
            result, mappings = anon.anonymize(f'URL = "{url}"')
            assert url not in result, f"Failed to catch: {url}"

    def test_internal_ip_ranges(self):
        anon = RegexAnonymizer()
        ips = [
            "http://192.168.1.100:8080/api",
            "http://10.0.0.1/internal",
            "http://172.16.0.1:3000/dashboard",
        ]
        for ip_url in ips:
            result, _ = anon.anonymize(f'URL = "{ip_url}"')
            assert ip_url not in result

    def test_preserves_code_structure(self):
        code = "def add(a: int, b: int) -> int:\n    return a + b\n"
        anon = RegexAnonymizer()
        result, mappings = anon.anonymize(code)
        assert result == code
        assert len(mappings) == 0

    def test_preserves_normal_urls(self):
        """Public URLs should not be anonymized."""
        anon = RegexAnonymizer()
        code = 'url = "https://api.stripe.com/v1/charges"'
        result, mappings = anon.anonymize(code)
        assert "https://api.stripe.com" in result

    def test_mixed_secrets_and_code(self):
        code = (
            "import os\n"
            'API_KEY = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\n'
            "def process():\n"
            "    x = 1 + 2\n"
            '    email = "user@example.com"\n'
            "    return x\n"
        )
        anon = RegexAnonymizer()
        result, mappings = anon.anonymize(code)
        assert "import os" in result
        assert "def process():" in result
        assert "x = 1 + 2" in result
        assert "sk_live" not in result
        assert "user@example.com" not in result


class TestRehydrationRoundtrip:
    """Verify that anonymize → rehydrate produces the original code."""

    def test_basic_roundtrip(self):
        code = 'key = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\nemail = "test@corp.com"\n'
        pipeline = AnonymizationPipeline(PrivacyLevel.BASIC)
        result = pipeline.run(code)
        restored = pipeline.rehydrate(result.anonymized_code, result.mappings)
        assert restored == code

    def test_full_roundtrip(self):
        code = (
            '# Author: Jan Kowalski\n'
            'API_KEY = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\n\n'
            'class UserManager:\n'
            '    def find_user(self, user_id):\n'
            '        return self.db.get(user_id)\n'
        )
        pipeline = AnonymizationPipeline(PrivacyLevel.FULL)
        result = pipeline.run(code, language="python")
        restored = pipeline.rehydrate(result.anonymized_code, result.mappings)
        assert restored == code

    def test_roundtrip_clean_code(self, clean_code):
        """Clean code should survive roundtrip unchanged."""
        pipeline = AnonymizationPipeline(PrivacyLevel.FULL)
        result = pipeline.run(clean_code, language="python")
        restored = pipeline.rehydrate(result.anonymized_code, result.mappings)
        assert restored == clean_code

    def test_roundtrip_fintech(self, fintech_code):
        """Complex fintech code should survive roundtrip."""
        pipeline = AnonymizationPipeline(PrivacyLevel.FULL)
        result = pipeline.run(fintech_code, language="python")
        restored = pipeline.rehydrate(result.anonymized_code, result.mappings)
        assert restored == fintech_code


class TestSecretsCoverage:
    """Test with the secrets-heavy fixture to verify detection coverage."""

    def test_catches_all_secrets(self, secrets_heavy_code):
        pipeline = AnonymizationPipeline(PrivacyLevel.BASIC)
        result = pipeline.run(secrets_heavy_code)
        anon = result.anonymized_code

        # Should NOT be present after anonymization
        must_catch = [
            "AKIAIOSFODNN7EXAMPLE",
            "sk_live_4eC39HqLyjWDarjtT1zdp7dc",
            "pk_live_",
            "sk_test_",
            "ghp_ABCDEF",
            "glpat-",
            "postgresql://admin",
            "redis://cache",
            "mongodb+srv://",
            "amqp://guest",
            "admin@acme-fintech.com",
            "support@acme-fintech.com",
            "192.168.1.100",
        ]

        for secret in must_catch:
            assert secret not in anon, f"Failed to catch: {secret}"

    def test_full_mode_catches_more(self, secrets_heavy_code):
        basic = AnonymizationPipeline(PrivacyLevel.BASIC)
        full = AnonymizationPipeline(PrivacyLevel.FULL)

        basic_result = basic.run(secrets_heavy_code)
        full_result = full.run(secrets_heavy_code, language="python")

        # Full should find more items than basic
        basic_total = sum(basic_result.stats.values())
        full_total = sum(full_result.stats.values())
        assert full_total > basic_total

    def test_clean_code_zero_findings(self, clean_code):
        pipeline = AnonymizationPipeline(PrivacyLevel.BASIC)
        result = pipeline.run(clean_code)
        assert sum(result.stats.values()) == 0


class TestPrivacyLevels:
    """Test behavior at each privacy level."""

    def test_none_does_nothing(self):
        code = 'key = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"'
        pipeline = AnonymizationPipeline(PrivacyLevel.NONE)
        result = pipeline.run(code)
        assert result.anonymized_code == code
        assert len(result.mappings) == 0

    def test_basic_catches_secrets_only(self):
        code = (
            '# Author: Jan Kowalski\n'
            'key = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\n'
            'class AcmeService:\n    pass\n'
        )
        pipeline = AnonymizationPipeline(PrivacyLevel.BASIC)
        result = pipeline.run(code)
        assert "sk_live" not in result.anonymized_code
        # Basic does NOT catch person names or class names
        assert "Jan Kowalski" in result.anonymized_code
        assert "AcmeService" in result.anonymized_code

    def test_full_catches_everything(self):
        code = (
            '# Author: Jan Kowalski\n'
            'key = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\n'
            'class AcmeService:\n    pass\n'
        )
        pipeline = AnonymizationPipeline(PrivacyLevel.FULL)
        result = pipeline.run(code, language="python")
        assert "sk_live" not in result.anonymized_code
        assert "Jan Kowalski" not in result.anonymized_code
        assert "AcmeService" not in result.anonymized_code
