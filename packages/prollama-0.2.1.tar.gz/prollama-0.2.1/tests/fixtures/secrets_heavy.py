# Author: Jan Kowalski
# Contact: admin@acme-fintech.com
# Copyright 2025 Acme Fintech Ltd
# Office: 42 Innovation Street


# Cloud provider keys
AWS_KEY = "AKIAIOSFODNN7EXAMPLE"
GCP_KEY = "AIzaSyD-EX4mPL3K3y1s-t0ken-example35"
STRIPE_SECRET = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"
STRIPE_PUB = "pk_live_EX4mPL3K3y1st0ken1234abcd"
STRIPE_TEST = "sk_test_4eC39HqLyjWDarjtT1zdp7dc"

# VCS tokens
GITHUB_TOKEN = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"
GITLAB_TOKEN = "glpat-ABCDEFGHIJKLMNOPQRST"

# Connection strings
DATABASE_URL = "postgresql://admin:s3cret@db.internal.acme.com:5432/production"
REDIS_URL = "redis://cache.internal:6379/0"
MONGO_URL = "mongodb+srv://user:pass@cluster.mongodb.net/mydb"
AMQP_URL = "amqp://guest:guest@rabbitmq.internal:5672/vhost"

# Tokens
JWT_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
BEARER = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.test"
API_KEY = "api_key=abcdef1234567890abcdef1234567890"
AUTH_TOKEN = "auth_token=MySecretToken12345678"

# PII
ADMIN_EMAIL = "admin@acme-fintech.com"
SUPPORT_EMAIL = "support@acme-fintech.com"
INTERNAL_URL = "https://api.internal.acme.com/v2/payments"
LOCALHOST_URL = "http://localhost:8080/debug"
PRIVATE_IP = "192.168.1.100"
PHONE = "+48 123 456 789"

# SSN in comment: 123-45-6789
# Credit card: 4111 1111 1111 1111
