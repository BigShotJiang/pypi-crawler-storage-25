"""Tests for prollama core functionality."""


from prollama.anonymizer.pipeline import AnonymizationPipeline
from prollama.anonymizer.regex_layer import RegexAnonymizer
from prollama.config import Config, ProviderConfig
from prollama.executor.task_executor import classify_complexity, classify_type
from prollama.models import (
    ModelTier,
    PrivacyLevel,
    Task,
    TaskComplexity,
    TaskType,
)
from prollama.router.model_router import ModelRouter

# -- Config -----------------------------------------------------------------

class TestConfig:
    def test_default_config(self):
        config = Config()
        assert config.proxy.port == 8741
        assert config.privacy.level == "full"
        assert config.routing.strategy == "cost-optimized"

    def test_provider_names(self):
        config = Config(providers=[
            ProviderConfig(name="ollama", base_url="http://localhost:11434/v1"),
            ProviderConfig(name="openai", api_key="sk-test"),
        ])
        assert config.provider_names() == ["ollama", "openai"]

    def test_get_provider(self):
        config = Config(providers=[
            ProviderConfig(name="ollama"),
        ])
        assert config.get_provider("ollama") is not None
        assert config.get_provider("openai") is None


# -- Anonymizer -------------------------------------------------------------

class TestRegexAnonymizer:
    def test_detects_aws_key(self):
        anon = RegexAnonymizer()
        code = 'AWS_KEY = "AKIAIOSFODNN7EXAMPLE"'
        result, mappings = anon.anonymize(code)
        assert "AKIA" not in result
        assert len(mappings) == 1
        assert mappings[0].category == "SECRET"

    def test_detects_stripe_key(self):
        anon = RegexAnonymizer()
        code = 'stripe_key = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"'
        result, mappings = anon.anonymize(code)
        assert "sk_live" not in result

    def test_detects_email(self):
        anon = RegexAnonymizer()
        code = '# Contact: jan@example.com for details'
        result, mappings = anon.anonymize(code)
        assert "jan@example.com" not in result
        assert any(m.category == "EMAIL" for m in mappings)

    def test_detects_github_token(self):
        anon = RegexAnonymizer()
        code = 'GITHUB_TOKEN = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"'
        result, mappings = anon.anonymize(code)
        assert "ghp_" not in result

    def test_detects_database_url(self):
        anon = RegexAnonymizer()
        code = 'DB_URL = "postgresql://user:pass@db.internal:5432/myapp"'
        result, mappings = anon.anonymize(code)
        assert "postgresql://" not in result

    def test_rehydration(self):
        anon = RegexAnonymizer()
        original = 'key = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"'
        anonymized, mappings = anon.anonymize(original)
        restored = anon.rehydrate(anonymized, mappings)
        assert restored == original

    def test_no_false_positives_on_clean_code(self):
        anon = RegexAnonymizer()
        code = "def add(a: int, b: int) -> int:\n    return a + b\n"
        result, mappings = anon.anonymize(code)
        assert result == code
        assert len(mappings) == 0


class TestAnonymizationPipeline:
    def test_basic_level(self):
        pipeline = AnonymizationPipeline(PrivacyLevel.BASIC)
        code = 'token = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"'
        result = pipeline.run(code)
        assert "sk_live" not in result.anonymized_code
        assert result.privacy_level == PrivacyLevel.BASIC

    def test_none_level(self):
        pipeline = AnonymizationPipeline(PrivacyLevel.NONE)
        code = 'token = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"'
        result = pipeline.run(code)
        assert result.anonymized_code == code

    def test_rehydrate(self):
        pipeline = AnonymizationPipeline(PrivacyLevel.BASIC)
        original = 'email = "test@corp.com"'
        result = pipeline.run(original)
        restored = pipeline.rehydrate(result.anonymized_code, result.mappings)
        assert restored == original


# -- Router -----------------------------------------------------------------

class TestModelRouter:
    def _config_with_ollama(self) -> Config:
        return Config(providers=[
            ProviderConfig(name="ollama", base_url="http://localhost:11434/v1"),
        ])

    def test_select_cheap_for_simple(self):
        router = ModelRouter(config=self._config_with_ollama())
        model = router.select(complexity=TaskComplexity.SIMPLE)
        assert model is not None
        assert model.tier == ModelTier.CHEAP

    def test_escalate(self):
        router = ModelRouter(config=self._config_with_ollama())
        cheap = router.select(preferred_tier=ModelTier.CHEAP)
        assert cheap is not None
        mid = router.escalate(cheap)
        assert mid is not None
        assert mid.tier == ModelTier.MID

    def test_no_models_returns_none(self):
        router = ModelRouter(config=Config())  # no providers
        assert router.select() is None


# -- Classifier -------------------------------------------------------------

class TestClassifier:
    def test_simple_task(self):
        task = Task(description="Fix typo in README")
        assert classify_complexity(task) == TaskComplexity.SIMPLE

    def test_medium_task(self):
        task = Task(description="Fix the TypeError bug in auth module")
        assert classify_complexity(task) == TaskComplexity.MEDIUM

    def test_hard_task(self):
        task = Task(description="Refactor PaymentService to use strategy pattern")
        assert classify_complexity(task) == TaskComplexity.HARD

    def test_very_hard_task(self):
        task = Task(description="Architect multi-file migration for database layer")
        assert classify_complexity(task) == TaskComplexity.VERY_HARD

    def test_type_fix(self):
        task = Task(description="Fix crash on login page")
        assert classify_type(task) == TaskType.FIX

    def test_type_refactor(self):
        task = Task(description="Refactor the user module")
        assert classify_type(task) == TaskType.REFACTOR

    def test_type_feature(self):
        task = Task(description="Add new REST endpoint for users")
        assert classify_type(task) == TaskType.FEATURE
