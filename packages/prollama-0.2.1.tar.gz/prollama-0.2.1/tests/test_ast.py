"""Tests for AST-based anonymization layer."""

from prollama.anonymizer.ast_layer import ASTAnonymizer
from prollama.anonymizer.pipeline import AnonymizationPipeline
from prollama.models import PrivacyLevel


class TestASTAnonymizer:
    """Tests for tree-sitter AST anonymization."""

    def test_class_names_anonymized(self):
        code = "class StripePaymentProcessor:\n    pass\n"
        anon = ASTAnonymizer(language="python")
        result, mappings = anon.anonymize(code)
        assert "StripePaymentProcessor" not in result
        assert "Class_001" in result
        assert any(m.original == "StripePaymentProcessor" for m in mappings)

    def test_function_names_anonymized(self):
        code = "def charge_customer(amount):\n    return amount * 100\n"
        anon = ASTAnonymizer(language="python")
        result, mappings = anon.anonymize(code)
        assert "charge_customer" not in result
        assert any(m.original == "charge_customer" for m in mappings)

    def test_builtins_preserved(self):
        code = "x = len(range(10))\nprint(isinstance(x, int))\n"
        anon = ASTAnonymizer(language="python")
        result, _ = anon.anonymize(code)
        assert "len" in result
        assert "range" in result
        assert "print" in result
        assert "isinstance" in result
        assert "int" in result

    def test_self_preserved(self):
        code = "class Foo:\n    def bar(self):\n        return self.x\n"
        anon = ASTAnonymizer(language="python")
        result, _ = anon.anonymize(code)
        assert "self" in result

    def test_dunder_methods_preserved(self):
        code = "class MyClass:\n    def __init__(self):\n        self.__name__ = 'test'\n"
        anon = ASTAnonymizer(language="python")
        result, _ = anon.anonymize(code)
        assert "__init__" in result
        assert "__name__" in result

    def test_imports_preserved(self):
        code = "import stripe\nfrom payment.gateway import PaymentGateway\n"
        anon = ASTAnonymizer(language="python")
        result, _ = anon.anonymize(code)
        assert "import stripe" in result
        assert "from payment.gateway import PaymentGateway" in result

    def test_consistent_mapping(self):
        """Same identifier always gets same replacement."""
        code = (
            "def process_payment(amount):\n"
            "    return process_payment(amount + 1)\n"
        )
        anon = ASTAnonymizer(language="python")
        result, mappings = anon.anonymize(code)
        # The function name should appear exactly twice with same replacement
        replacement = None
        for m in mappings:
            if m.original == "process_payment":
                replacement = m.replacement
                break
        assert replacement is not None
        assert result.count(replacement) == 2

    def test_rehydration_roundtrip(self):
        code = (
            "class AcmePaymentService:\n"
            "    def charge_premium_user(self, user_id: str):\n"
            "        return self.gateway.charge(user_id)\n"
        )
        anon = ASTAnonymizer(language="python")
        anonymized, mappings = anon.anonymize(code)
        restored = anon.rehydrate(anonymized, mappings)
        assert restored == code

    def test_naming_convention_classification(self):
        """PascalCase → Class_NNN, snake_case → var_NNN, UPPER → CONST_NNN."""
        code = (
            "class MyService:\n"
            "    MAX_RETRIES_COUNT = 3\n"
            "    def process_data(self):\n"
            "        pass\n"
        )
        anon = ASTAnonymizer(language="python")
        result, mappings = anon.anonymize(code)
        mapping_dict = {m.original: m.replacement for m in mappings}
        assert mapping_dict["MyService"].startswith("Class_")
        assert mapping_dict["process_data"].startswith("var_")
        assert mapping_dict["MAX_RETRIES_COUNT"].startswith("CONST_")

    def test_clean_code_no_business_logic_leaks(self):
        """After anonymization, no business-specific names should remain."""
        code = (
            "class StripePaymentProcessor:\n"
            "    def charge_customer(self, customer_id: str, amount: int):\n"
            "        response = self.stripe_client.charges.create(\n"
            "            customer=customer_id,\n"
            "            amount=int(amount * 100),\n"
            "        )\n"
            "        return PaymentResult(transaction_id=response.id)\n"
        )
        anon = ASTAnonymizer(language="python")
        result, _ = anon.anonymize(code)
        # None of these business terms should remain
        for term in ["Stripe", "Payment", "customer", "charges", "transaction"]:
            assert term not in result, f"Business term '{term}' leaked through"

    def test_multiple_classes(self):
        code = (
            "class UserService:\n    pass\n\n"
            "class OrderService:\n    pass\n\n"
            "class PaymentService:\n    pass\n"
        )
        anon = ASTAnonymizer(language="python")
        result, mappings = anon.anonymize(code)
        class_mappings = [m for m in mappings if m.replacement.startswith("Class_")]
        # Should have 3 distinct class replacements
        assert len(set(m.replacement for m in class_mappings)) == 3


class TestFullPipelineAST:
    """Test regex + AST pipeline together."""

    def test_full_pipeline_catches_both(self):
        code = (
            "# Contact: admin@acme.com\n"
            "STRIPE_KEY = 'sk_live_4eC39HqLyjWDarjtT1zdp7dc'\n\n"
            "class AcmePaymentService:\n"
            "    def charge(self, amount):\n"
            "        pass\n"
        )
        pipeline = AnonymizationPipeline(PrivacyLevel.FULL)
        result = pipeline.run(code, language="python")

        # Regex should catch the email and stripe key
        assert "admin@acme.com" not in result.anonymized_code
        assert "sk_live" not in result.anonymized_code

        # AST should catch the class name
        assert "AcmePaymentService" not in result.anonymized_code

        # Stats should reflect both layers
        assert result.stats.get("EMAIL", 0) >= 1
        assert result.stats.get("SECRET", 0) >= 1
        assert result.stats.get("AST_IDENT", 0) >= 1

    def test_full_pipeline_rehydration(self):
        code = (
            "API_KEY = 'sk_live_4eC39HqLyjWDarjtT1zdp7dc'\n\n"
            "class UserManager:\n"
            "    def find_user(self, user_id):\n"
            "        return self.db.get(user_id)\n"
        )
        pipeline = AnonymizationPipeline(PrivacyLevel.FULL)
        result = pipeline.run(code, language="python")
        restored = pipeline.rehydrate(result.anonymized_code, result.mappings)
        assert restored == code
