#!/usr/bin/env python3
"""Swampo Installer - Installs slash commands and CLAUDE.md files."""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


def get_claude_dir() -> Path:
    """Get Claude Code config directory."""
    return Path.home() / ".claude"


def get_resources_dir() -> Path:
    """Get bundled resources directory."""
    pkg_dir = Path(__file__).parent
    return pkg_dir / "resources"


def install_slash_command(name: str) -> bool:
    """Install a slash command to ~/.claude/commands/"""
    resources = get_resources_dir()
    cmd_dir = resources / "slash-commands" / name

    if not cmd_dir.exists():
        print(f"❌ Command '{name}' not found")
        return False

    md_files = list(cmd_dir.glob("*.md"))
    if not md_files:
        print(f"❌ No .md file found in {cmd_dir}")
        return False

    src = md_files[0]
    claude_dir = get_claude_dir()
    commands_dir = claude_dir / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)

    dst = commands_dir / f"{name}.md"
    shutil.copy2(src, dst)

    print(f"✅ Installed /{name} command")
    return True


def install_claude_md(name: str, project_dir: Path | None = None) -> bool:
    """Install CLAUDE.md file to project."""
    resources = get_resources_dir()
    md_dir = resources / "claude.md-files" / name

    if not md_dir.exists():
        print(f"❌ CLAUDE.md '{name}' not found")
        return False

    src = md_dir / "CLAUDE.md"
    if not src.exists():
        print(f"❌ CLAUDE.md not found in {md_dir}")
        return False

    if project_dir:
        dst = project_dir / "CLAUDE.md"
    else:
        print("❌ CLAUDE.md should be installed per-project")
        return False

    shutil.copy2(src, dst)
    print(f"✅ Installed CLAUDE.md ({name}) to {dst}")
    return True


def list_available() -> None:
    resources = get_resources_dir()

    print("\n📋 Slash Commands:")
    slash_dir = resources / "slash-commands"
    if slash_dir.exists():
        for cmd in sorted(slash_dir.iterdir()):
            if cmd.is_dir():
                print(f"  /{cmd.name}")

    print("\n📋 Skills:")
    skills_dir = resources / "skills"
    if skills_dir.exists():
        for skill in sorted(skills_dir.iterdir()):
            if skill.is_dir():
                print(f"  @{skill.name}")

    print("\n📋 CLAUDE.md Templates:")
    md_dir = resources / "claude.md-files"
    if md_dir.exists():
        for tmpl in sorted(md_dir.iterdir()):
            if tmpl.is_dir():
                print(f"  {tmpl.name}")


def install_skill(name: str) -> bool:
    resources = get_resources_dir()
    skill_dir = resources / "skills" / name

    if not skill_dir.exists():
        print(f"  ❌ Skill '{name}' not found")
        return False

    src = skill_dir / "SKILL.md"
    if not src.exists():
        print(f"  ❌ No SKILL.md in {skill_dir}")
        return False

    claude_dir = get_claude_dir()
    dst_dir = claude_dir / "skills" / name
    dst_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(src, dst_dir / "SKILL.md")
    return True


def install_all() -> None:
    resources = get_resources_dir()

    slash_dir = resources / "slash-commands"
    cmd_count = 0
    if slash_dir.exists():
        for cmd_dir in slash_dir.iterdir():
            if cmd_dir.is_dir():
                if install_slash_command(cmd_dir.name):
                    cmd_count += 1

    skills_dir = resources / "skills"
    skill_count = 0
    if skills_dir.exists():
        for skill_dir in skills_dir.iterdir():
            if skill_dir.is_dir():
                if install_skill(skill_dir.name):
                    skill_count += 1

    print(f"\n✅ Installed {cmd_count} commands + {skill_count} skills")
    print(f"📁 Commands: {get_claude_dir() / 'commands'}")
    print(f"📁 Skills: {get_claude_dir() / 'skills'}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Install Swampo skills, commands, and CLAUDE.md files"
    )
    parser.add_argument("command", choices=["list", "install", "install-all"])
    parser.add_argument("--name", "-n", help="Name of command or CLAUDE.md to install")
    parser.add_argument("--project", "-p", type=Path, help="Project directory for CLAUDE.md")

    args = parser.parse_args()

    if args.command == "list":
        list_available()
    elif args.command == "install":
        if not args.name:
            print("❌ --name required for install")
            return 1
        if not install_slash_command(args.name):
            install_claude_md(args.name, args.project)
    elif args.command == "install-all":
        install_all()

    return 0


if __name__ == "__main__":
    sys.exit(main())
