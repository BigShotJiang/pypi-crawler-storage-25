# Swampo

The most complete skill pack for [Claude Code](https://docs.anthropic.com/en/docs/claude-code). 23 slash commands, 55 curated skills, 22 CLAUDE.md templates. One install.

## Install

```bash
npm install -g swampo
```

Done. Everything installs automatically — commands, skills, templates.

## What's Inside

### 55 Skills

Curated from top open-source collections. Each skill is a lightweight SKILL.md that Claude Code loads on demand.

**Security & Pentest (30)**

| Skill | Source | What it does |
|-------|--------|-------------|
| `@sast-orchestration` | ai-security-arsenal | Static analysis with Semgrep, CodeQL, Bandit |
| `@api-security` | ai-security-arsenal | REST/GraphQL security, OWASP API Top 10 |
| `@cloud-security` | ai-security-arsenal | Multi-cloud assessment (AWS/GCP/Azure) |
| `@container-security` | ai-security-arsenal | Docker/Kubernetes security |
| `@network-pentest` | ai-security-arsenal | Internal network, Active Directory |
| `@llm-security` | ai-security-arsenal | Prompt injection, OWASP LLM Top 10 |
| `@threat-modeling` | ai-security-arsenal | STRIDE, PASTA, attack trees |
| `@dast-automation` | ai-security-arsenal | Dynamic testing with ZAP, Nuclei, Playwright |
| `@sca-security` | ai-security-arsenal | Software composition analysis, SBOM |
| `@iac-security` | ai-security-arsenal | Infrastructure-as-code scanning |
| `@android-pentest` | ai-security-arsenal | Frida, objection, ADB |
| `@ios-pentest` | ai-security-arsenal | Frida, Cycript, objection |
| `@sql-injection-anti-pattern` | grimbard | Detect SQLi vulnerabilities |
| `@command-injection-anti-pattern` | grimbard | Shell command injection |
| `@xss-anti-pattern` | grimbard | Cross-site scripting patterns |
| `@dom-clobbering-anti-pattern` | grimbard | DOM clobbering attacks |
| `@log-injection-anti-pattern` | grimbard | Log injection detection |
| `@second-order-injection-anti-pattern` | grimbard | Second-order injection |
| `@unrestricted-file-upload-anti-pattern` | grimbard | File upload vulnerabilities |
| `@missing-input-validation-anti-pattern` | grimbard | Input validation gaps |
| `@excessive-data-exposure-anti-pattern` | grimbard | Data exposure risks |
| `@integer-overflow-anti-pattern` | grimbard | Integer overflow bugs |
| `@insufficient-randomness-anti-pattern` | grimbard | Weak random generation |
| `@debug-mode-production-anti-pattern` | grimbard | Debug mode in production |
| `@hallucinated-packages-anti-pattern` | grimbard | AI-hallucinated dependency attacks |
| `@authorisation-pattern` | grimbard | Authorization design patterns |
| `@password-based-authentication-pattern` | grimbard | Secure auth implementation |
| `@cryptographic-key-management-pattern` | grimbard | Key management best practices |
| `@codebase-discovery` | grimbard | Attack surface mapping |
| `@codeql` | grimbard | CodeQL query writing |

**Productivity & Dev (12)**

| Skill | Source | What it does |
|-------|--------|-------------|
| `@test-driven-development` | superpowers | Multi-agent TDD orchestration |
| `@systematic-debugging` | superpowers | Root cause analysis workflow |
| `@brainstorming` | superpowers | Structured ideation |
| `@using-git-worktrees` | superpowers | Parallel branch workflows |
| `@executing-plans` | superpowers | Plan execution with validation |
| `@dispatching-parallel-agents` | superpowers | Multi-agent task dispatch |
| `@subagent-driven-development` | superpowers | Subagent coordination |
| `@finishing-a-development-branch` | superpowers | Branch completion checklist |
| `@receiving-code-review` | superpowers | Handle incoming reviews |
| `@requesting-code-review` | superpowers | Structure review requests |
| `@verification-before-completion` | superpowers | Pre-completion validation |
| `@writing-plans` | superpowers | Technical plan writing |

**Files, Docs & Design (7)**

| Skill | Source | What it does |
|-------|--------|-------------|
| `@docx` | anthropic | Create/edit Word documents |
| `@xlsx` | anthropic | Create/edit Excel spreadsheets |
| `@pdf` | anthropic | PDF text extraction, form filling |
| `@pptx` | anthropic | Create PowerPoint presentations |
| `@frontend-design` | anthropic | UI/UX component design |
| `@webapp-testing` | anthropic | Playwright-based UI testing |
| `@mcp-builder` | anthropic | Build MCP servers |

**Research & Tools (6)**

| Skill | Source | What it does |
|-------|--------|-------------|
| `@deep-research` | glebis/claude-skills | Multi-source research with citations |
| `@pdf-generation` | glebis/claude-skills | Generate PDF reports |
| `@github-gist` | glebis/claude-skills | Publish gists from Claude |
| `@context-builder` | glebis/claude-skills | Build project context |
| `@decision-toolkit` | glebis/claude-skills | Structured decision frameworks |
| `@youtube-transcript` | glebis/claude-skills | YouTube transcript analysis |

### 23 Slash Commands

`/commit` `/pr-review` `/create-pr` `/create-pull-request` `/fix-github-issue` `/clean` `/todo` `/optimize` `/release` `/context-prime` `/create-hook` `/create-prd` `/create-prp` `/create-jtbd` `/create-worktrees` `/husky` `/initref` `/load-llms-txt` `/update-docs` `/update-branch-name` `/add-to-changelog` `/testing_plan_integration` `/act`

### 22 CLAUDE.md Templates

`Basic-Memory` `AWS-MCP-Server` `Course-Builder` `LangGraphJS` `Cursor-Tools` `DroidconKotlin` `Guitar` `Lamoom-Python` `Network-Chronicles` `Note-Companion` `Pareto-Mac` `Perplexity-MCP` and more.

## Usage

```bash
# List everything
swampo-install list

# Install single skill
swampo-install install -n api-security

# Install CLAUDE.md to project
swampo-install install -n Basic-Memory --project .

# Install all commands + skills
swampo-install install-all
```

Skills load automatically when relevant. Ask Claude to "review this API for security issues" and `@api-security` activates.

## Sources

Skills are curated from:

| Repository | Stars | Skills used |
|------------|-------|-------------|
| [hardw00t/ai-security-arsenal](https://github.com/hardw00t/ai-security-arsenal) | 34 | 12 |
| [igbuend/grimbard](https://github.com/igbuend/grimbard) | 87 | 18 |
| [obra/superpowers](https://github.com/obra/superpowers) | — | 12 |
| [anthropics/skills](https://github.com/anthropics/skills) | — | 7 |
| [glebis/claude-skills](https://github.com/glebis/claude-skills) | 110 | 6 |

All skills are MIT or Apache 2.0 licensed.

## Uninstall

```bash
npm uninstall -g swampo
pip uninstall swampo
```

## License

MIT
