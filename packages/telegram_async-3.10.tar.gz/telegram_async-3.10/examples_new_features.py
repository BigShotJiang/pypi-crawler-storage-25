"""
Examples of all new features in telegram_async
"""
import asyncio
import time
from telegram_async import (
    Bot, Dispatcher, Router, Context,
    I18n, CallbackData, DeepLink,
    BackgroundTasksManager, BotMetrics,
    BroadcastManager, AutoDeleteManager,
    MockBot, MockContext
)
from telegram_types import (
    BotCommandScope, ReactionType, MenuButton,
    LabeledPrice
)


# ==================== Setup ====================

bot = Bot("YOUR_BOT_TOKEN")
dp = Dispatcher(bot)
router = Router("examples")
dp.include_router(router)


# ==================== 1. Webhook Secret Token ====================

async def setup_webhook_with_secret():
    from telegram_async import WebhookServer
    
    server = WebhookServer(dp, bot)
    server.enable_secret_token("my-secret-token-123")
    
    await server.set_webhook(
        url="https://your-domain.com",
        secret_token="my-secret-token-123"
    )


# ==================== 2. Bot Commands API ====================

async def setup_bot_commands():
    # Set commands
    await bot.set_my_commands([
        {"command": "start", "description": "Start the bot"},
        {"command": "help", "description": "Get help"},
        {"command": "settings", "description": "Open settings"}
    ])
    
    # Commands for admins only
    await bot.set_my_commands([
        {"command": "ban", "description": "Ban user"},
        {"command": "unban", "description": "Unban user"}
    ], scope=BotCommandScope.chat_administrators(chat_id=123))
    
    # Get commands
    commands = await bot.get_my_commands()
    print(f"Bot has {len(commands)} commands")
    
    # Set bot info
    await bot.set_my_name("My Awesome Bot")
    await bot.set_my_description("An awesome bot for Telegram")


# ==================== 3. Background Tasks ====================

bg_manager = BackgroundTasksManager()

async def database_monitor():
    """Background task to monitor database"""
    while True:
        print("Checking database connection...")
        await asyncio.sleep(60)

async def cache_cleaner():
    """Background task to clean cache"""
    while True:
        print("Cleaning cache...")
        await asyncio.sleep(3600)

async def setup_background_tasks():
    bg_manager.add_task("db_monitor", database_monitor, restart_on_failure=True)
    bg_manager.add_task("cache_cleaner", cache_cleaner, restart_on_failure=True)
    await bg_manager.start_all()


# ==================== 4. i18n/L10n ====================

i18n = I18n(default_locale="en")

# Manually add translations (or load from files)
i18n._translations['en'] = {
    'greeting': 'Hello, $name! 👋',
    'goodbye': 'Goodbye, $name! 👋',
    'help_text': 'Available commands: /start, /help, /settings'
}
i18n._translations['pl'] = {
    'greeting': 'Cześć, $name! 👋',
    'goodbye': 'Do widzenia, $name! 👋',
    'help_text': 'Dostępne komendy: /start, /help, /settings'
}

@router.command("start")
async def cmd_start_i18n(ctx: Context):
    """Example: Internationalized /start command"""
    name = ctx.update.message.from_user.first_name
    text = await i18n.t(ctx.user_id, "greeting", name=name)
    await ctx.reply(text)


# ==================== 5. Callback Data Factory ====================

class VoteCallback(CallbackData):
    prefix = "vote"
    post_id: int
    action: str  # upvote, downvote

class PageCallback(CallbackData):
    prefix = "page"
    page: int
    sort: str

@router.message()
async def send_vote_buttons(ctx: Context):
    """Example: Send message with callback buttons"""
    from telegram_async.keyboards import InlineKeyboardMarkup, InlineKeyboardButton
    
    keyboard = InlineKeyboardMarkup()
    keyboard.row(
        InlineKeyboardButton("👍 Upvote", callback_data=VoteCallback.new(post_id=123, action="upvote")),
        InlineKeyboardButton("👎 Downvote", callback_data=VoteCallback.new(post_id=123, action="downvote"))
    )
    
    await ctx.reply("Vote on this post:", reply_markup=keyboard.to_dict())

@router.callback_query()
async def handle_votes(ctx: Context):
    """Example: Handle callback with structured data"""
    if VoteCallback.validate(ctx.callback_data):
        data = VoteCallback.parse(ctx.callback_data)
        post_id = data['post_id']
        action = data['action']
        
        await ctx.answer_callback(f"You {action}d post #{post_id}")


# ==================== 6. Payments API ====================

async def send_invoice_example(ctx: Context):
    """Example: Send an invoice"""
    await bot.send_invoice(
        chat_id=ctx.chat_id,
        title="Premium Subscription",
        description="1 month of premium features",
        payload="premium_1month",
        provider_token="PAYMENT_TOKEN",  # Optional for Telegram Stars
        currency="USD",
        prices=[
            LabeledPrice(label="Subscription", amount=999).to_dict()
        ]
    )


# ==================== 7. Games API ====================

async def send_game_example(ctx: Context):
    """Example: Send a game"""
    await bot.send_game(
        chat_id=ctx.chat_id,
        game_short_name="gamebot"  # Set via @BotFather
    )


# ==================== 8. Forum/Topics ====================

async def create_forum_example():
    """Example: Create and manage forum topics"""
    chat_id = -1001234567890
    
    # Create topic
    topic = await bot.create_forum_topic(
        chat_id=chat_id,
        name="General Discussion",
        icon_color=0x6FB9F0
    )
    
    print(f"Created topic: {topic['message_thread_id']}")
    
    # Edit topic
    await bot.edit_forum_topic(
        chat_id=chat_id,
        message_thread_id=topic['message_thread_id'],
        name="Updated Name"
    )


# ==================== 9. Bot Menu ====================

async def setup_menu_example():
    """Example: Set custom menu button"""
    # Default commands menu
    await bot.set_chat_menu_button(menu_button=MenuButton.commands().to_dict())
    
    # WebApp button
    await bot.set_chat_menu_button(
        chat_id=123,
        menu_button=MenuButton.web_app("Open App", "https://example.com").to_dict()
    )


# ==================== 10. Sticker Sets ====================

async def sticker_example():
    """Example: Send and manage stickers"""
    # Send sticker
    await bot.send_sticker(
        chat_id=123,
        sticker="CAACAgIAAxkBAAIB"
    )
    
    # Get sticker set
    sticker_set = await bot.get_sticker_set(name="MyStickerPack")
    print(f"Sticker set has {len(sticker_set['stickers'])} stickers")


# ==================== 11. Custom Context Injection ====================

class AdminContext(Context):
    """Custom context with admin checking"""
    
    ADMIN_IDS = {123456789}
    
    @property
    def is_admin(self) -> bool:
        return self.user_id in self.ADMIN_IDS
    
    async def reply_admin_only(self, text: str):
        """Reply only if user is admin"""
        if self.is_admin:
            await self.reply(text)
        else:
            await self.reply("❌ Access denied")

admin_router = Router("admin")
admin_router.set_context_class(AdminContext)

@admin_router.command("admin")
async def cmd_admin(ctx: AdminContext):
    """Example: Custom context with admin checking"""
    await ctx.reply_admin_only("🔧 Admin Panel")


# ==================== 12. Handler Priority System ====================

@admin_router.message(priority=10)
async def high_priority_handler(ctx: Context):
    """High priority - executes first"""
    if ctx.text and ctx.text.startswith("!"):
        await ctx.reply("Admin command detected")
        return True

@router.message(priority=0)
async def low_priority_handler(ctx: Context):
    """Low priority - executes last"""
    if ctx.text:
        await ctx.reply(f"You said: {ctx.text}")


# ==================== 13. Deep Linking ====================

@router.command("start")
async def cmd_start_deeplink(ctx: Context):
    """Example: Handle /start with referral link"""
    parts = ctx.text.split()
    
    if len(parts) > 1:
        ref_code = parts[1]
        # Decode if it was base64 encoded
        original = DeepLink.parse_start_param(ref_code, decode=False)
        print(f"User came from referral: {original}")
    
    # Create invite link
    link = DeepLink.create_start_link(
        bot_username="MyBot",
        param=f"ref_{ctx.user_id}",
        encode=False
    )
    
    await ctx.reply(f"Share this link to invite friends:\n{link}")


# ==================== 14. Bot Stats Dashboard ====================

metrics = BotMetrics()

@router.message()
async def track_metrics(ctx: Context):
    """Example: Track metrics"""
    metrics.inc_messages()
    metrics.inc_user(ctx.user_id)
    
    # Expose via /metrics endpoint in your aiohttp app
    # metrics.format_all() returns Prometheus-format metrics


# ==================== 15. Testing Utilities ====================

async def test_handler():
    """Example: Test a handler"""
    mock_bot = MockBot()
    mock_ctx = MockContext(
        user_id=123,
        chat_id=456,
        text="/start"
    )
    
    # Call your handler
    # await my_handler(mock_bot, mock_ctx)
    
    # Assert behavior
    # mock_bot.assert_sent_message_count(1)
    # mock_bot.assert_sent_text("Hello!")
    # mock_ctx.assert_replied(count=1)


# ==================== 16. CLI Tool ====================
# Run: python -m telegram_async.cli init my_new_bot


# ==================== 17. Admin Broadcast ====================

broadcast = BroadcastManager(bot)

async def broadcast_example():
    """Example: Send broadcast to multiple chats"""
    # Add chats
    broadcast.add_chat(123)
    broadcast.add_chat(456)
    broadcast.add_chat(789)
    
    # Send broadcast
    result = await broadcast.send_to_chats(
        text="📢 Important announcement!",
        rate_limit=0.05,  # 50ms between messages
        on_progress=lambda current, total, chat_id, success: 
            print(f"{current}/{total}: {chat_id} - {'OK' if success else 'FAIL'}"),
        on_error=lambda chat_id, error: print(f"Error: {chat_id} - {error}")
    )
    
    print(f"\nResults:")
    print(f"  Success: {result.success_count}")
    print(f"  Blocked: {result.blocked_count}")
    print(f"  Failed: {result.failure_count}")
    print(f"  Rate: {result.success_rate:.1f}%")


# ==================== 18. Message Auto-Delete ====================

auto_delete = AutoDeleteManager()
auto_delete.set_bot(bot)

@router.message()
async def auto_delete_example(ctx: Context):
    """Example: Auto-delete message after delay"""
    msg = await ctx.reply("This message will self-destruct in 30 seconds ⏱️")
    
    await auto_delete.schedule(
        chat_id=ctx.chat_id,
        message_id=msg['message_id'],
        delay=30.0
    )


# ==================== 19. Reaction Support ====================

@router.message()
async def react_to_message(ctx: Context):
    """Example: React to message"""
    await bot.set_message_reaction(
        chat_id=ctx.chat_id,
        message_id=ctx.update.message.message_id,
        reaction=[ReactionType.emoji("👍").to_dict()],
        is_big=True
    )


# ==================== 20. Business Accounts ====================

async def business_example():
    """Example: Business features"""
    # Get business connection
    # connection = await bot.get_business_connection("connection_id")
    
    # Send gift
    # await bot.send_gift(
    #     user_id=123,
    #     gift_id="gift_id",
    #     text="Happy birthday! 🎉"
    # )
    
    # Verify user
    # await bot.verify_user(123, "Verified developer")
    
    # Set emoji status
    # await bot.set_user_emoji_status(
    #     user_id=123,
    #     custom_emoji_id="emoji_id"
    # )
    pass


# ==================== Main ====================

async def main():
    """Start the bot"""
    print("Starting bot with all new features...")
    
    # Setup background tasks
    await setup_background_tasks()
    
    # Setup bot commands
    await setup_bot_commands()
    
    # Start polling
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
