"""
telegram_async - Nowoczesna asynchroniczna biblioteka do Telegram Bot API
"""

from .version import __version__
from .client.bot import Bot
from .client.base import TelegramClient
from .client.webhook import WebhookServer
from .dispatcher.dispatcher import Dispatcher
from .dispatcher.context import Context
from .dispatcher.router import Router
from . import telegram_types
from . import filters
from . import keyboards
from . import fsm
from . import utils
from . import exceptions
from .utils.i18n import I18n
from .utils.callback_factory import CallbackData, CompactCallbackData
from .utils.deep_linking import DeepLink
from .utils.background_tasks import BackgroundTasksManager
from .utils.metrics import BotMetrics
from .utils.broadcast import BroadcastManager
from .utils.auto_delete import AutoDeleteManager
from .utils.testing import MockBot, MockContext

__all__ = [
    "Bot",
    "Dispatcher",
    "Router",
    "Context",
    "TelegramClient",
    "WebhookServer",
    "telegram_types",
    "filters",
    "keyboards",
    "fsm",
    "utils",
    "exceptions",
    "I18n",
    "CallbackData",
    "CompactCallbackData",
    "DeepLink",
    "BackgroundTasksManager",
    "BotMetrics",
    "BroadcastManager",
    "AutoDeleteManager",
    "MockBot",
    "MockContext",
]