"""
Additional Telegram Bot API types for API 9.5+
"""
from dataclasses import dataclass
from typing import Optional, List, Dict, Any, Union


# ==================== Bot Commands ====================

@dataclass
class BotCommand:
    """Represents a bot command."""
    command: str  # 1-32 chars, lowercase, no @ for default
    description: str  # 1-256 chars
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BotCommand':
        return cls(
            command=data['command'],
            description=data['description']
        )


@dataclass
class BotCommandScope:
    """Scope for bot commands."""
    type: str  # default, all_chat_administrators, all_group_administrators, chat, chat_administrators, chat_member
    chat_id: Optional[Union[int, str]] = None
    user_id: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        data = {'type': self.type}
        if self.chat_id:
            data['chat_id'] = self.chat_id
        if self.user_id:
            data['user_id'] = self.user_id
        return data
    
    @classmethod
    def default(cls) -> 'BotCommandScope':
        return cls(type='default')
    
    @classmethod
    def all_private_chats(cls) -> 'BotCommandScope':
        return cls(type='all_private_chats')
    
    @classmethod
    def all_group_chats(cls) -> 'BotCommandScope':
        return cls(type='all_group_chats')
    
    @classmethod
    def all_chat_administrators(cls) -> 'BotCommandScope':
        return cls(type='all_chat_administrators')
    
    @classmethod
    def all_private_chat_administrators(cls) -> 'BotCommandScope':
        return cls(type='all_private_chat_administrators')
    
    @classmethod
    def all_group_chat_administrators(cls) -> 'BotCommandScope':
        return cls(type='all_group_chat_administrators')
    
    @classmethod
    def chat(cls, chat_id: Union[int, str]) -> 'BotCommandScope':
        return cls(type='chat', chat_id=chat_id)
    
    @classmethod
    def chat_administrators(cls, chat_id: Union[int, str]) -> 'BotCommandScope':
        return cls(type='chat_administrators', chat_id=chat_id)
    
    @classmethod
    def chat_member(cls, chat_id: Union[int, str], user_id: int) -> 'BotCommandScope':
        return cls(type='chat_member', chat_id=chat_id, user_id=user_id)


# ==================== Payments ====================

@dataclass
class LabeledPrice:
    """Price portion of an invoice."""
    label: str
    amount: int  # Smallest currency unit (e.g., cents)
    
    def to_dict(self) -> Dict[str, Any]:
        return {'label': self.label, 'amount': self.amount}
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LabeledPrice':
        return cls(
            label=data['label'],
            amount=data['amount']
        )


@dataclass
class ShippingOption:
    """One shipping option."""
    id: str
    title: str
    prices: List[LabeledPrice]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'title': self.title,
            'prices': [p.to_dict() for p in self.prices]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ShippingOption':
        return cls(
            id=data['id'],
            title=data['title'],
            prices=[LabeledPrice.from_dict(p) for p in data['prices']]
        )


@dataclass
class StarTransaction:
    """Telegram Star transaction."""
    id: str
    amount: int
    date: int
    source: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StarTransaction':
        return cls(
            id=data['id'],
            amount=data['amount'],
            date=data['date'],
            source=data.get('source')
        )


@dataclass
class StarTransactions:
    """List of Star transactions."""
    transactions: List[StarTransaction]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StarTransactions':
        return cls(
            transactions=[StarTransaction.from_dict(t) for t in data.get('transactions', [])]
        )


# ==================== Games ====================

@dataclass
class Game:
    """A game."""
    title: str
    description: str
    photo: List[Any]  # List of PhotoSize
    text: Optional[str] = None
    text_entities: Optional[List[Any]] = None
    animation: Optional[Any] = None
    photo_list: Optional[List[Any]] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Game':
        return cls(
            title=data['title'],
            description=data['description'],
            photo=data.get('photo', []),
            text=data.get('text'),
            text_entities=data.get('text_entities'),
            animation=data.get('animation'),
            photo_list=data.get('photo_list')
        )


@dataclass
class GameHighScore:
    """One row of game high scores."""
    position: int
    user: Any  # User object
    score: int
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GameHighScore':
        return cls(
            position=data['position'],
            user=data['user'],
            score=data['score']
        )


# ==================== Forum/Topics ====================

@dataclass
class ForumTopic:
    """A forum topic."""
    message_thread_id: int
    name: str
    icon_color: Optional[int] = None
    icon_custom_emoji_id: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ForumTopic':
        return cls(
            message_thread_id=data['message_thread_id'],
            name=data['name'],
            icon_color=data.get('icon_color'),
            icon_custom_emoji_id=data.get('icon_custom_emoji_id')
        )


@dataclass
class ForumTopicCreated:
    """Service message about forum topic creation."""
    name: str
    icon_color: int
    icon_custom_emoji_id: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ForumTopicCreated':
        return cls(
            name=data['name'],
            icon_color=data['icon_color'],
            icon_custom_emoji_id=data.get('icon_custom_emoji_id')
        )


@dataclass
class ForumTopicClosed:
    """Service message about forum topic closure."""
    pass


@dataclass
class ForumTopicEdited:
    """Service message about forum topic edit."""
    name: Optional[str] = None
    icon_custom_emoji_id: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ForumTopicEdited':
        return cls(
            name=data.get('name'),
            icon_custom_emoji_id=data.get('icon_custom_emoji_id')
        )


@dataclass
class ForumTopicReopened:
    """Service message about forum topic reopen."""
    pass


@dataclass
class GeneralForumTopicHidden:
    """Service message about General forum topic hidden."""
    pass


@dataclass
class GeneralForumTopicUnhidden:
    """Service message about General forum topic unhidden."""
    pass


# ==================== Menu Button ====================

@dataclass
class MenuButton:
    """Describes the bot's menu button."""
    type: str  # commands, web_app, default
    text: Optional[str] = None
    web_app: Optional[Dict[str, str]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        data = {'type': self.type}
        if self.text:
            data['text'] = self.text
        if self.web_app:
            data['web_app'] = self.web_app
        return data
    
    @classmethod
    def commands(cls) -> 'MenuButton':
        return cls(type='commands')
    
    @classmethod
    def web_app(cls, text: str, url: str) -> 'MenuButton':
        return cls(type='web_app', text=text, web_app={'url': url})
    
    @classmethod
    def default(cls) -> 'MenuButton':
        return cls(type='default')


# ==================== Stickers ====================

@dataclass
class Sticker:
    """A sticker."""
    file_id: str
    file_unique_id: str
    width: int
    height: int
    is_animated: bool
    is_video: bool
    type: str  # regular, mask, custom_emoji
    emoji: Optional[str] = None
    set_name: Optional[str] = None
    premium_animation: Optional[Any] = None
    mask_position: Optional[Any] = None
    custom_emoji_id: Optional[str] = None
    thumb: Optional[Any] = None
    file_size: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Sticker':
        return cls(
            file_id=data['file_id'],
            file_unique_id=data['file_unique_id'],
            width=data['width'],
            height=data['height'],
            is_animated=data['is_animated'],
            is_video=data['is_video'],
            type=data.get('type', 'regular'),
            emoji=data.get('emoji'),
            set_name=data.get('set_name'),
            premium_animation=data.get('premium_animation'),
            mask_position=data.get('mask_position'),
            custom_emoji_id=data.get('custom_emoji_id'),
            thumb=data.get('thumb'),
            file_size=data.get('file_size')
        )


@dataclass
class StickerSet:
    """A sticker set."""
    name: str
    title: str
    sticker_type: str
    stickers: List[Sticker]
    is_animated: bool
    is_video: bool
    thumb: Optional[Any] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StickerSet':
        return cls(
            name=data['name'],
            title=data['title'],
            sticker_type=data.get('sticker_type', 'regular'),
            stickers=[Sticker.from_dict(s) for s in data.get('stickers', [])],
            is_animated=data.get('is_animated', False),
            is_video=data.get('is_video', False),
            thumb=data.get('thumb')
        )


@dataclass
class MaskPosition:
    """Position where a mask should be placed."""
    point: str  # forehead, eyes, chin
    x_shift: float
    y_shift: float
    scale: float
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MaskPosition':
        return cls(
            point=data['point'],
            x_shift=data['x_shift'],
            y_shift=data['y_shift'],
            scale=data['scale']
        )


# ==================== Reactions ====================

@dataclass
class ReactionType:
    """Type of reaction."""
    type: str  # emoji, custom_emoji
    emoji: Optional[str] = None
    custom_emoji_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        data = {'type': self.type}
        if self.emoji:
            data['emoji'] = self.emoji
        if self.custom_emoji_id:
            data['custom_emoji_id'] = self.custom_emoji_id
        return data
    
    @classmethod
    def emoji(cls, emoji: str) -> 'ReactionType':
        return cls(type='emoji', emoji=emoji)
    
    @classmethod
    def custom_emoji(cls, custom_emoji_id: str) -> 'ReactionType':
        return cls(type='custom_emoji', custom_emoji_id=custom_emoji_id)


@dataclass
class ReactionCount:
    """Reaction count of a specific type."""
    type: ReactionType
    total_count: int
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ReactionCount':
        return cls(
            type=ReactionType(**data['type']),
            total_count=data['total_count']
        )


@dataclass
class MessageReactionUpdated:
    """Reaction changed on a message."""
    chat_id: int
    message_id: int
    user: Optional[Any] = None
    old_reaction: Optional[List[ReactionType]] = None
    new_reaction: Optional[List[ReactionType]] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MessageReactionUpdated':
        return cls(
            chat_id=data['chat']['id'],
            message_id=data['message_id'],
            user=data.get('user'),
            old_reaction=[ReactionType(**r) for r in data.get('old_reaction', [])] if data.get('old_reaction') else None,
            new_reaction=[ReactionType(**r) for r in data.get('new_reaction', [])] if data.get('new_reaction') else None
        )


@dataclass
class MessageReactionCountUpdated:
    """Reactions changed on a message (channel posts)."""
    chat_id: int
    message_id: int
    reactions: List[ReactionCount]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MessageReactionCountUpdated':
        return cls(
            chat_id=data['chat']['id'],
            message_id=data['message_id'],
            reactions=[ReactionCount.from_dict(r) for r in data.get('reactions', [])]
        )


# ==================== Business ====================

@dataclass
class BusinessConnection:
    """Information about connection to a business account."""
    id: str
    user: Any  # User
    user_chat_id: int
    date: int
    can_reply: bool
    is_enabled: bool
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BusinessConnection':
        return cls(
            id=data['id'],
            user=data['user'],
            user_chat_id=data['user_chat_id'],
            date=data['date'],
            can_reply=data['can_reply'],
            is_enabled=data['is_enabled']
        )


@dataclass
class BusinessMessagesDeleted:
    """Messages deleted in a business chat."""
    business_connection_id: str
    chat_id: int
    message_ids: List[int]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BusinessMessagesDeleted':
        return cls(
            business_connection_id=data['business_connection_id'],
            chat_id=data['chat']['id'],
            message_ids=data['message_ids']
        )


@dataclass
class BusinessIntro:
    """Business intro info."""
    title: Optional[str] = None
    message: Optional[str] = None
    sticker: Optional[Sticker] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BusinessIntro':
        return cls(
            title=data.get('title'),
            message=data.get('message'),
            sticker=Sticker.from_dict(data['sticker']) if data.get('sticker') else None
        )


# ==================== Gifts ====================

@dataclass
class Gift:
    """A gift."""
    id: str
    sticker: Sticker
    star_count: int
    total_count: Optional[int] = None
    remaining_count: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Gift':
        return cls(
            id=data['id'],
            sticker=Sticker.from_dict(data['sticker']),
            star_count=data['star_count'],
            total_count=data.get('total_count'),
            remaining_count=data.get('remaining_count')
        )


@dataclass
class Gifts:
    """List of gifts."""
    gifts: List[Gift]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Gifts':
        return cls(
            gifts=[Gift.from_dict(g) for g in data.get('gifts', [])]
        )


# ==================== Verified Sections ====================

@dataclass
class ChatAvailableReactions:
    """Available reactions in a chat."""
    type: str  # all, some
    reactions: Optional[List[ReactionType]] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ChatAvailableReactions':
        return cls(
            type=data['type'],
            reactions=[ReactionType(**r) for r in data.get('reactions', [])] if data.get('reactions') else None
        )
