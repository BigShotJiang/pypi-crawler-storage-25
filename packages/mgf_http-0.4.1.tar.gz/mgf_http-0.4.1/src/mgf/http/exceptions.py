"""``mgf.http.exceptions`` — sibling-domain concrete exception leaves.

Per the federation rule (decision **D3** in
``mgf-common/docs/release/federation_roadmap.md``): **siblings own
their domain concretes; mgf-common owns hierarchy roots + status
leaves.**

The HTTP-01 hierarchy roots (``AppError``, ``OperationError``,
``HttpError``, ``HttpClientError`` *the 4xx-hierarchy parent*,
``HttpServerError``) and the generic status-code leaves
(``HttpUnauthorized``, ``HttpForbidden``, ``HttpNotFound``, etc.)
stay in :mod:`mgf.common.exceptions`. Sibling-domain concretes that
inherit from them live here.

Today the only such concrete is :class:`HttpTransportError`. Future
HTTP-client-domain leaves (e.g. for httpx-specific corruption modes)
will land here as they're added.

Note on the rename: prior to v0.29, this concrete lived in
mgf-common as ``mgf.common.http.HttpClientError``. The name
collided with ``mgf.common.exceptions.HttpClientError`` (the
HTTP-01 hierarchy parent for 4xx-class responses). Moving the
concrete to a sibling at v0.29 was the natural moment to fix the
collision; the new name is :class:`HttpTransportError` since
"transport-layer failure" is exactly what it represents.
"""

from __future__ import annotations

from mgf.http._errors import HttpTransportError

__all__ = ["HttpTransportError"]
