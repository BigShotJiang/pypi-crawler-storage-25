"""``mgf.http`` — typed async HTTP client for ``mgf-common`` consumers.

Sibling of :mod:`mgf.common` under the ``mgf.*`` namespace. Houses
the typed httpx wrapper that previously lived under
``mgf.common.http.*`` — extracted at mgf-common v0.29 / mgf-http v0.1
per the federation split plan.

A consumer that needs HTTP shouldn't reinvent these things every
time:

  - User-Agent identity headers
    (``<app>/<ver> mgf-http/<libver>``)
  - Redaction of secret-shaped headers (Authorization, Cookie, etc.)
    in logs and OTel spans
  - Retry on transient failures with exponential backoff + jitter
  - Per-request and global timeouts
  - TLS-verify default-on with a runtime warning if disabled
  - Typed error translation (``httpx.TimeoutException`` →
    :class:`HttpTransportError`, etc.)

This package ships :class:`AsyncHttpClient` — a thin layer over
:class:`httpx.AsyncClient` that bakes the above in.

Install: ``pip install mgf-http`` (or ``pip install 'mgf-http[test]'``
for ``respx`` mocking).

The submodule:

  - :mod:`mgf.http.exceptions` — sibling-domain concrete exception
    leaves (``HttpTransportError``).

Closed-box invariant: ``mgf-http`` depends on ``mgf-common`` +
``httpx`` only. Consumers MUST import :class:`AsyncHttpClient` /
:class:`RetryPolicy` from ``mgf.http``, never reach into
``mgf.http._client`` / ``mgf.http._retry``.

**Renamed from ``HttpClientError``:** prior to v0.29, the
transport-failure leaf was named ``HttpClientError`` — collided
with :class:`mgf.common.exceptions.HttpClientError` (the HTTP-01
4xx-class hierarchy parent). The new name is :class:`HttpTransportError`
since "transport-layer failure" is exactly its role.
"""

from __future__ import annotations

from mgf.http._client import AsyncHttpClient
from mgf.http._download import DownloadResult, IntegrityError
from mgf.http._retry import RetryPolicy
from mgf.http.exceptions import HttpTransportError

__all__ = [
    "AsyncHttpClient",
    "DownloadResult",
    "HttpTransportError",
    "IntegrityError",
    "RetryPolicy",
]
