# `docs/inprogress/` — the maintainer's workspace

**Per `DOC-02` + `DOC-11`** in `mgf-common`'s [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md):
this directory is the **workspace** where the maintainer's
internal-posture docs live while they're active. It is **not a
graveyard** — closed trackers SHOULD move to `docs/archive/<year>/`
within one release cycle.

## What goes here

- **Living priority trackers** (per `DOC-06`): one per concern
  area. Each follows the §1..§6 canonical shape; each work unit
  carries verified `file:line` evidence and a falsifiable concrete
  output.
- **One-shot audit passes**. Finite scope; move to archive when
  complete.

## What does NOT go here

- **Consumer-reported papercuts** — `mgf-http` has no
  consumer-facing `FEEDBACK.md` of its own; consumer signal lands
  in [`mgf-common/FEEDBACK.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md)
  under a `[mgf-http]` prefix.
- **Per-release breaking-change guides** — those go to
  `docs/cutover/`.
- **Permanent rules / standards** — those live in
  `mgf-common/docs/standards/` (this sibling inherits them; see
  [`docs/standards/README.md`](../standards/README.md)).

## Index

| File | Status | What |
|---|---|---|
| [`RELIABILITY_AND_ACCURACY.md`](RELIABILITY_AND_ACCURACY.md) | v0.1 — active | RA-* items: TLS-disable warning race, 429 Retry-After handling, cookie value sanitization, redirect-policy carve-out, cause-summary content scrubbing, aclose() idempotency pin. |
| [`SECURITY_HARDENING.md`](SECURITY_HARDENING.md) | v0.1 — active | SH-* items: cookie sanitization (twin RA-03), cross-domain redirect auth-leak, TLS-disable structured audit, cause_summary secret-leak (twin RA-04), cert-pinning recipe, sibling SBOM + vuln-scan. |
| [`PERFORMANCE_AND_CAPACITY.md`](PERFORMANCE_AND_CAPACITY.md) | v0.1 — active | PC-* items: per-call wrapper overhead pin, connection-pool capacity profile, User-Agent computation cache, header redaction lookup, retry-policy iteration cost, sustained-throughput 100 req/s. |
