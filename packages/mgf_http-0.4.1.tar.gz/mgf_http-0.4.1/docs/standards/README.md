# Engineering Standards

This folder is **NOT a duplicate** of `mgf-common/docs/standards/`.
The cross-project engineering standards (logging, configuration,
exceptions, design principles, security, testing, API design,
documentation, operability, deployment) live in `mgf-common`.
This project depends on those — pinned via
`mgf-common>=0.33,<0.34`. Read them on demand via
`mgf-common standards <topic>` or directly at
[`mgf-common/docs/standards/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/).

**Project shape:** **Federation sibling** of `mgf-common`
(per [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0).

**Conformance target:** L2 — Observability-Native (Tier C) per
[`mgf-common/docs/standards/README.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/README.md#conformance-levels-for-projects).
Inherited via the `mgf-common>=0.33,<0.34` dependency; the HTTP
client in this sibling preserves the parent's logging /
correlation / redaction guarantees on every outbound request.

---

## What lives in mgf-common (do not duplicate here)

The full standards set:

- [`DESIGN_PRINCIPLES.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DESIGN_PRINCIPLES.md) — DP-01..DP-13
- [`ERROR_HANDLING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/ERROR_HANDLING.md) — EH-01..EH-13 (especially **EH-11** retry-with-jitter, **EH-12** idempotency, **EH-13** circuit breaker — all directly applicable to this client)
- [`LOGGING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/LOGGING.md) — LG-01..LG-17 (especially **LG-04** redaction, applied to outbound headers by `_redact_headers`)
- [`CONFIGURATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/CONFIGURATION.md) — CF-01..CF-12
- [`SECURITY_STANDARD.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/SECURITY_STANDARD.md) — SC-01..SC-18
- [`TESTING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/TESTING.md) — TS-01..TS-21
- [`API_DESIGN.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/API_DESIGN.md) — AP-01..AP-15
- [`RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md) — REL-01..REL-09
- [`WORKFLOWS.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/WORKFLOWS.md) — WF-01..WF-12
- [`SCOPE.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/SCOPE.md)
- [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) — DOC-01..DOC-12
- [`OPERABILITY.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/OPERABILITY.md) — OP-01..OP-12
- [`DEPLOYMENT.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DEPLOYMENT.md) — DEP-01..DEP-11

---

## Project-specific standards

None at present. `mgf-http` is a thin async-HTTP-client sibling;
its public surface (see [`PUBLIC_API.md`](../../PUBLIC_API.md)) is
three names (`AsyncHttpClient`, `RetryPolicy`,
`HttpTransportError`) plus the `mgf.http.exceptions` submodule.
The whole library's job is to bridge `httpx` into the federation's
error/logging/correlation contract.

Domain-specific extensions worth codifying (e.g., a circuit-
breaker policy beyond the EH-13 default, or a multi-target
load-balanced client) MAY land here following the §2.0.4 Shape B
pattern in DOCUMENTATION.md. None warranted today.
