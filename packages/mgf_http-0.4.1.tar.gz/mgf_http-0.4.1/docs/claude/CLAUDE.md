# mgf-http — Claude Reference

Dense lookup document. No prose. Facts only.

> **See also:** [`mgf-common/docs/claude/CLAUDE.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/claude/CLAUDE.md)
> — cornerstone reference shared across the federation. THIS
> file is the mgf-http-specific addenda.

---

## Project shape

- **Federation sibling** of `mgf-common` (per
  [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0).
- **Conformance target:** L2 — inherited via
  `mgf-common>=0.33,<0.34`.
- **PyPI:** `mgf-http`; first published at v0.1.0 (2026-05-09);
  current v0.2.0 (this release adds the v2.6/v2.7 compliance
  shape).
- **Codeberg:** `magogi-admin/mgf-http`; default branch `main`.

## File map (where things live)

| Path | Purpose |
|---|---|
| `src/mgf/http/__init__.py` | Re-exports `AsyncHttpClient`, `RetryPolicy`, `HttpTransportError`. PEP 420 namespace package. |
| `src/mgf/http/_client.py` | `AsyncHttpClient` — async-context-manager wrapper over `httpx.AsyncClient`. Builds User-Agent, attaches OTel span, redacts secret-shaped request/response headers in logs, translates `httpx` transport exceptions. |
| `src/mgf/http/_retry.py` | `RetryPolicy` frozen dataclass + `backoff_for_attempt()` with full jitter. Default policy is `max_attempts=0` (no retry) — opt-in. Retryable methods exclude POST by default per EH-12 idempotency rule. |
| `src/mgf/http/_errors.py` | Translation seam: `httpx.TimeoutException`, `httpx.ConnectError`, `httpx.NetworkError` → `HttpTransportError` (with `__cause__` preserved). Per **EH-02** + **EH-03**. |
| `src/mgf/http/exceptions.py` | `HttpTransportError` public class. |
| `PUBLIC_API.md` | Contract list — three public names. |
| `CHANGELOG.md` | Per-release record. |
| `SECURITY.md` | Vuln-reporting policy. |
| `docs/standards/README.md` | Pointer-only stub. |
| `docs/cutover/v*.md` | Per-release migration guides. |
| `docs/recipes/*.md` | Task-shaped how-tos. |

## Cross-cutting patterns

1. **Header redaction.** Outbound `Authorization`, `Cookie`,
   `X-Api-Key`, `Proxy-Authorization`, `Set-Cookie` headers are
   replaced with `[REDACTED]` in log records + OTel span
   attributes. The redaction list is configurable via
   `redact_headers=` on `AsyncHttpClient`.

2. **Transport vs. application errors.** 4xx and 5xx responses
   are NOT raised by default — `response.raise_for_status()` is
   the explicit opt-in. Transport-level failures (timeout,
   connect refused, network error) DO raise
   `HttpTransportError` after retries exhaust. The split
   matches REST convention: the server replied vs. we never
   got a reply.

3. **Idempotency boundary.** `RetryPolicy.retryable_methods`
   defaults to `{GET, HEAD, OPTIONS, PUT, DELETE}` — POST is
   excluded because a retried POST can create duplicate state.
   Consumers that need POST retries MUST ensure
   idempotency-key support upstream + add `POST` to the policy
   themselves. Per **EH-12**.

4. **TLS-default-on warning.** `verify_tls=False` emits
   `UserWarning` exactly once per process. The warning is the
   audit trail — disabling TLS verification is operator choice,
   but it MUST be a logged choice.

5. **User-Agent identity.** Every request carries
   `User-Agent: <app>/<ver> mgf-http/<libver>` so upstream
   logs can attribute traffic to the right consumer.
   `<app>` and `<ver>` come from the active `AppContext`.

6. **Full-jitter backoff.** `RetryPolicy.backoff_for_attempt(n)`
   returns `random.uniform(0, min(base * 2**n, max_backoff))`.
   Full jitter (not equal jitter, not decorrelated jitter)
   per the AWS Architecture blog's empirical finding +
   **EH-11**.

## Build and release

The canonical sequence per
[`mgf-common/docs/standards/RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md):

1. Bump `version` in `pyproject.toml`.
2. Add the `[X.Y.Z] — YYYY-MM-DD` entry in `CHANGELOG.md`.
3. Update `PUBLIC_API.md` if the public surface changed.
4. Run the full test suite (`pytest`).
5. Run `mypy --strict src/mgf/http/`.
6. Build: `uv build`.
7. `twine check dist/*` — both wheel and sdist MUST pass.
8. Commit + annotated tag.
9. Push commit + tag.
10. `twine upload dist/*`.
11. Post-publish smoke: `pip install --upgrade mgf-http==X.Y.Z`.

## Common pitfalls

- **Forgetting to call `await client.__aexit__()`.** The
  client owns the underlying `httpx.AsyncClient`'s connection
  pool. Forgotten close → ResourceWarning + connection leaks.
  Use `async with AsyncHttpClient(...) as client: ...`.
- **Setting `max_attempts=10` against a non-idempotent endpoint.**
  Retried POST = duplicate row. Either ensure idempotency
  upstream (key + ON CONFLICT) or keep POST off `retryable_methods`.
- **Adding `Authorization` to a per-call `headers=` dict and
  expecting it to be redacted.** It IS redacted (the
  case-insensitive default match catches it), but consumers
  who add a custom header like `X-Internal-Auth-Token` MUST
  extend `redact_headers=` themselves.
- **Mixing `verify_tls=False` with a logged secret.** If
  TLS is disabled and the call is intercepted, the redactor
  protects the log but not the wire. Don't ship secrets
  over plaintext.

## Recently-touched areas

- **v0.2.0 prep (2026-05-15)** — added v2.6/v2.7 compliance
  files (this CLAUDE.md + SECURITY.md + docs/standards/README.md
  pointer); no code changes.
- **v0.1.1 (2026-05-11)** — walked mgf-common pin to >=0.33,<0.34.
- **v0.1.0 (2026-05-09)** — maiden release extracted from
  mgf-common[http]. Three public names; retry-with-jitter,
  header redaction, TLS-default-on warning all shipped.

---

*Last updated: 2026-05-15.*
