# USERS — who depends on mgf-http

> **Purpose:** mgf-http's user roll. Lists every consumer project and
> federation sibling that imports `mgf.http.*`.
> **Maintained by:** the mgf-common owner (Bassam — mgf-common owns the
> federation per the one-big-library mindset).
> **Per standard DOC-16** (v2.9): every `mgf-*` library MUST maintain a
> `USERS.md` at repo root.

Last verified: 2026-05-18 (post-mgf-http v0.4.0 release with resumable
download).

---

## §1 Consumer projects (external users)

| Project        | Location                                  | Import sites | Status                                  | Surfaces used                                        |
|----------------|-------------------------------------------|-------------:|-----------------------------------------|------------------------------------------------------|
| **inthewords** | `/home/bassam/PycharmProjects/inthewords` | 1            | Single use                              | `mgf.http` client                                    |

**Single-direct-consumer reality.** Only inthewords imports `mgf.http`
directly today. **VManager, PlasmaMapper, and iosRecovery are expected
adopters** — the v0.4.0 `download(...)` API was shipped specifically to
close their resumable-download pain (see Wave 2 H-NEW-1 evidence in
`/home/bassam/PycharmProjects/mgf_common/docs/inprogress/pre_release_additions.md`
§12). They haven't migrated yet; the surface is ready when they do.

---

## §2 Federation siblings (`mgf-*` libraries)

No siblings depend on mgf-http today. Each handles its own HTTP needs
(mgf-fastapi via Starlette, mgf-apiprobe via its own transport adapter).

---

## §3 What a "user" change MUST trigger

See [`../mgf_common/USERS.md`](../mgf_common/USERS.md) §3.

For mgf-http specifically: when VManager / PlasmaMapper / iosRecovery
finish their migration to `mgf.http.download(...)`, update this table
in the same PR that bumps their pyproject pins. Their migration will
also feed back into `MGF_ADOPTION.md` deltas.

---

## §4 How this list is maintained

```sh
for proj in VManager inthewords PlasmaMapper iosRecovery; do
  grep -rE "(from|import) +mgf\.http" "/home/bassam/PycharmProjects/$proj" \
    --include='*.py' | wc -l
done
```

Re-run before each MINOR release. The three planned migrations (VManager
+ PlasmaMapper + iosRecovery) will roughly quadruple the import count.
