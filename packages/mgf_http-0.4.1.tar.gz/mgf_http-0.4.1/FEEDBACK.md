# FEEDBACK — mgf-http

> Paper-tracking file for issues, friction, and requests against
> this sibling. Consumer projects (PlasmaMapper, inthewords,
> VManager, iosRecovery, and any future adopter) file PAPER-NN
> entries here.
>
> **Where to file what:**
>
> - **mgf-http-specific** (transport behaviour, retry policy,
>   redaction, streaming) → file HERE.
> - **Federation-wide** (cross-sibling patterns, standards
>   proposals) → file in
>   [mgf-common/FEEDBACK.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md).
>
> **Numbering convention:** paper numbers (`PAPER-NN`) are
> local to this repo. When a paper closes elsewhere or
> cross-references a federation-wide paper, the federation
> number appears in the metadata table as a cross-reference row.
>
> **Discipline:** see
> [mgf-common/docs/standards/DOCUMENTATION.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md)
> §FEEDBACK (rules FB-01..FB-04, DOC-13).

---

## §1 Process

1. **File freely.** Any consumer hitting friction MUST file
   a PAPER-NN under §2. Don't wait for permission; the
   maintainer triages.
2. **Status flips** through `OPEN` → `SHIPPED` / `DEFERRED` /
   `WONTFIX` / `MOVED` as the paper resolves. A `SHIPPED` row
   carries a commit-SHA reference + release-version reference.
3. **Renumbering** never happens within this repo — papers
   keep their PAPER-NN forever (per FB-01).

---

## §2 Open feedback (active)

#### `PAPER-01` — Streaming + body cap absent from `AsyncHttpClient.request()`

| Field | Value |
|---|---|
| Federation paper | [PAPER-36 in mgf-common](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md#paper-36) (original filing — sibling-scoped per DOC-13) |
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (commit [`36cd832`](https://codeberg.org/magogi-admin/inthewords/commit/36cd832)) |
| Submitted | 2026-05-18 |
| Decision | accept (both Approach A and Approach B, sharing one internal implementation) |
| Decided on | 2026-05-18 |
| Scheduled for | mgf-http v0.3.1 (next minor) |
| Shipped in | mgf-http commit [`4722bb3`](https://codeberg.org/magogi-admin/mgf-http/commit/4722bb3) |

**Concern.** `AsyncHttpClient.request()` returns a fully-buffered
`httpx.Response`. There is no `stream=True` flag, no
`max_response_size` constructor parameter, and no
`AsyncHttpClient.stream()` convenience method. A malicious or
misconfigured upstream that responds with N MB of body forces
httpx to buffer the full N MB into memory before the wrapper
hands the response back. The 5s `timeout` bounds wall-clock, not
bytes — on a fast link the practical cap is bandwidth × timeout
(gigabits/sec × seconds = potentially hundreds of MB).

**Why it matters.** Any consumer fetching user-submitted URLs
(link previews, OG-metadata scrapers, webhook URL verifiers,
citation enrichers) needs a body-size cap as a SSRF/DoS guard.
The library forces a binary choice today: use `.request()` for
retry + redaction + typed `HttpTransportError` translation OR
drop to the `.client` escape hatch for streaming and lose all
three. The `_client.py:246-247` docstring explicitly calls this
out as a downside.

**Concrete evidence.** inthewords' citation-metadata fetcher
caps body size at 1 MB (`CITATION_FETCH_MAX_BYTES = 1_000_000`).
Pre-adoption (urllib): `resp.read(N)` was a single line. Post-
adoption (`apps/messaging/tasks.py:_fetch_url_async`, commit
[`36cd832`](https://codeberg.org/magogi-admin/inthewords/commit/36cd832)):
the body fetch had to be split — `client.request()` for the
redirect-walk (kept for the retry / typed-error benefits), then
`client.client.stream(...)` (the escape hatch) for the actual
body read. The hop through the escape hatch silently bypasses
`RetryPolicy` and the `HttpTransportError` wrap, forcing a
separate `except httpx.HTTPError` catch downstream.

**Suggested shape.** Two non-exclusive proposals.

**Approach A — constructor-level cap.** Add
`AsyncHttpClient(max_response_size: int | None = None)`. When
set, the wrapper streams the response under the hood and raises
`HttpTransportError` with a new
`cause_summary="response-too-large"` if the cap is exceeded.
Default `None` preserves current behaviour. Lowest-effort
adoption: consumers add one kwarg and the wrapper does the
right thing.

**Approach B — streaming variant on the public surface.** Add
`AsyncHttpClient.stream(method, url, ...)` that yields the
response under an async context manager AND keeps the wrapper's
retry policy + typed-error translation. Body-cap becomes an
idiom the consumer drives (`break` out of the
`aiter_bytes` loop), but the wrapper still owns the protocol-
level posture.

**Recommendation.** Both. Approach A is the right default for
"I don't care, just cap it"; Approach B is the right shape for
consumers needing streaming-as-a-feature (large downloads,
chunked metadata extraction). They share an internal
implementation — both wrap `httpx.AsyncClient.stream()` with the
mgf-http envelope.

**Decision rationale.** Both approaches shipped as recommended.
The submitter's framing (Approach A is the simpler "just cap it"
shape; Approach B is the lower-level "I want streaming control"
shape) matched the implementation: `request()` with
`max_response_size` set routes through `stream()` internally —
single implementation of the streaming + retry loop, two public
surfaces. The existing `_send_with_retries` (the buffered path)
stays unchanged, preserving 71 existing tests; the new code path
is covered by 16 new tests across two classes
(`TestMaxResponseSizeConstruction` + `TestMaxResponseSize` +
`TestStream`).

**Retrospective.** Shipped exactly as suggested. The one
notable in-flight refinement: `_log_response` reads
`response.elapsed`, which httpx only sets after the response is
closed — moved the log call to AFTER the inner `async with
self._client.stream(...)` exits in the streaming path. The
shared cookie header-injection guard (SH-01 / RA-03) was
extracted into a new private helper `_assemble_request_headers`
to keep cookie validation in one place across both surfaces.
Total surface: +16 tests, +1 ctor kwarg, +1 public method, +1
private helper, no breaking changes.

---
#### `PAPER-02` — SSRF-safe redirect-walk recipe missing from `docs/recipes/http.md`

| Field | Value |
|---|---|
| Federation paper | [PAPER-37 in mgf-common](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md#paper-37) (original filing — sibling-scoped per DOC-13) |
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | inthewords (commit [`36cd832`](https://codeberg.org/magogi-admin/inthewords/commit/36cd832)) |
| Submitted | 2026-05-18 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-18 |
| Scheduled for | bundled with PAPER-36 in mgf-http v0.3.1 |
| Shipped in | mgf-http commit [`4722bb3`](https://codeberg.org/magogi-admin/mgf-http/commit/4722bb3) — `docs/recipes/http.md` |

**Concern.** mgf-http correctly leaves SSRF posture to the
consumer — TLS-on-by-default and a one-shot `verify_tls=False`
warning are the only SSRF-adjacent primitives. But the
consumer-side recipe for "https-only-on-every-hop redirect
walking" is non-trivial: set `follow_redirects=False`, walk
the `Location` header manually, re-check the scheme on each
hop, resolve relative URLs via `urljoin`, cap the redirect
depth, translate redirect loops to a typed error. The recipe
docs cover the happy path but not this shape.

**Why it matters.** Any web-shaped consumer fetching user-
submitted URLs reinvents this loop. inthewords just did; future
consumers will too unless the shape is documented in one place.

**Concrete evidence.** ~50 lines of `_fetch_url_async` in
`apps/messaging/tasks.py` (inthewords commit
[`36cd832`](https://codeberg.org/magogi-admin/inthewords/commit/36cd832))
implement the canonical pattern. The pattern is straightforward
once written but takes 30-60 minutes to derive from first
principles + httpx docs.

**Suggested shape.** Add a section to
`docs/recipes/http.md` titled "SSRF-safe redirect walking",
showing the canonical pattern:

```python
async with AsyncHttpClient(follow_redirects=False, ...) as client:
    current_url = url
    for _ in range(MAX_REDIRECTS + 1):
        if not current_url.startswith("https://"):
            return None  # consumer-chosen failure mode
        response = await client.request("GET", current_url)
        if response.status_code in (301, 302, 303, 307, 308):
            location = response.headers.get("location") or ""
            current_url = urljoin(current_url, location)
            continue
        # ... handle non-redirect response ...
        break
    else:
        return None  # too many redirects
```

A reference consumer (inthewords) is now available to cite from
the recipe; the citation fetcher is the worked example.

**Decision rationale.** Bundled with PAPER-36 since both touch
the same recipe doc and surface the same body-cap + redirect-walk
pattern. The recipe lands as a new "SSRF-safe redirect walking"
section in `docs/recipes/http.md` (mgf-http) alongside the new
"Bounded response sizes — `max_response_size`" and "Streaming
responses — `.stream()`" sections from PAPER-36.

**Retrospective.** Shipped verbatim per the suggested shape. The
recipe cites inthewords' `apps/messaging/tasks.py:_fetch_url_async`
as the worked production example, closing the "future consumers
will reinvent this loop" loop the filing called out.

---


## §3 Reviewer's meta-feedback

(none yet — placeholder for cross-cutting observations about the
FEEDBACK process itself.)

---

## §4 How consumers submit feedback

1. **Open a Codeberg issue** at
   <https://codeberg.org/magogi-admin/mgf-http/issues> if you
   have a quick question. Maintainer triages.
2. **For a structured pain point**: file a PAPER-NN here as a PR
   that adds the entry to §2. Use the existing entries as the
   shape template (status table → concern → why-it-matters →
   concrete evidence → suggested shape → decision rationale on
   close).
3. **For AI-agent-driven consumer sessions**: see your project's
   `docs/CLAUDE.md` auto-block (managed by `mgf-common catch-up`)
   — the `feedback-discipline` section spells out where to file
   what.

---

## §5 Cross-references

- [mgf-common/FEEDBACK.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md)
  — federation-wide PAPERs (cross-sibling concerns, standards
  proposals).
- [mgf-common/docs/standards/DOCUMENTATION.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md)
  — FEEDBACK discipline rules (FB-01..FB-04, DOC-13).
- [mgf-common/docs/recipes/feedback-md-template.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/recipes/feedback-md-template.md)
  — the canonical shape this file was built from.
