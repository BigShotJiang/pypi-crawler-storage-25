import asyncio
import json
import logging
import signal
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional

try:
    import redis.asyncio as aioredis
    _REDIS_AVAILABLE = True
except ImportError:
    aioredis = None  # type: ignore[assignment]
    _REDIS_AVAILABLE = False

logger = logging.getLogger(__name__)


@dataclass
class StreamMessage:
    """
    A single inbound message entry read from a Redis Stream.

    Fields map directly to the fields published by the powerlink-video-lk-backend
    webhook controller via XADD.
    """
    stream_id: str            # Redis auto-generated entry ID (used for cursor tracking)
    stream_key: str           # The stream key this message was read from
    direction: str            # "inbound" (reserved — future outbound messages will use "outbound")
    sender_id: str            # Provider-specific sender identifier
    provider_type: str        # "whatsapp" | "messenger" | "instagram" | "telegram"
    channel_uuid: str         # UUID of the channel config in the platform
    received_at: str          # ISO-8601 timestamp set by the publisher
    payload: Dict[str, Any]   # Full parsed JSON of the provider webhook body


class RedisStreamConsumer:
    """
    Async Redis Stream consumer designed for use inside LiveKit AI agent workers.

    Reads from a single Redis Stream using XREAD BLOCK (no consumer groups —
    one agent exclusively owns one stream for the lifetime of a conversation).

    Usage::

        async def on_message(msg: StreamMessage, consumer: RedisStreamConsumer) -> None:
            print(f"[{msg.provider_type}] {msg.sender_id}: {msg.payload}")

        consumer = RedisStreamConsumer(
            stream_key="conv:stream:whatsapp_16315551181_tmiLCEBiStO-",
            redis_url="redis://localhost:6379",
            on_message=on_message,
        )
        await consumer.start()
    """

    def __init__(
        self,
        stream_key: str,
        redis_url: str,
        on_message: Callable[["StreamMessage", "RedisStreamConsumer"], "asyncio.Future"],
        start_from: str = "$",
        block_ms: int = 5000,
        read_count: int = 10,
    ):
        """
        :param stream_key:   Redis Stream key to consume (e.g. ``conv:stream:{roomName}``).
        :param redis_url:    Redis connection URL (e.g. ``redis://localhost:6379``).
        :param on_message:   Async callback invoked for each new message. Signature:
                             ``async (msg: StreamMessage, consumer: RedisStreamConsumer) -> None``
        :param start_from:   Stream cursor position to start from.
                             ``"$"`` = new messages only (default — agent starts fresh with its session).
                             ``"0"`` = replay all messages from the beginning of the stream.
                             Any specific Redis stream ID to resume from a known position.
        :param block_ms:     How long (ms) XREAD waits for new entries before looping. Default 5000ms.
        :param read_count:   Max entries per XREAD call. Default 10.
        """
        if not _REDIS_AVAILABLE:
            raise ImportError(
                "Redis extra is required to use RedisStreamConsumer. "
                "Install it with: pip install agentix-core[redis]"
            )
        if not stream_key:
            raise ValueError("stream_key must be provided")
        if not redis_url:
            raise ValueError("redis_url must be provided")
        if not on_message:
            raise ValueError("on_message callback must be provided")

        self.stream_key = stream_key
        self.redis_url = redis_url
        self.on_message = on_message
        self.start_from = start_from
        self.block_ms = block_ms
        self.read_count = read_count

        self._redis: Optional["aioredis.Redis"] = None  # type: ignore[name-defined]
        self._cursor: str = start_from
        self._shutdown_event = asyncio.Event()

    # ──────────────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────────────

    async def start(self):
        """
        Start consuming the stream. Blocks until ``stop()`` is called or a
        SIGINT/SIGTERM signal is received.

        Automatically reconnects on connection errors with a 10-second back-off,
        mirroring the ``AgentTaskQueueWorker`` behaviour.
        """
        logger.debug(f"🚀 RedisStreamConsumer starting — stream: {self.stream_key} (cursor: {self._cursor})")
        self._setup_signal_handlers()

        while not self._shutdown_event.is_set():
            try:
                logger.debug(f"🟢 Connecting to Redis: {self.redis_url}")
                self._redis = aioredis.from_url(self.redis_url, decode_responses=True)

                # Verify connection is alive before entering read loop
                await self._redis.ping()
                logger.debug(f"✅ Connected. Consuming stream: {self.stream_key}")

                await self._read_loop()

            except asyncio.CancelledError:
                break
            except Exception as e:
                if self._shutdown_event.is_set():
                    break
                logger.warning(f"🔴 Redis connection error: {e}")
                logger.debug("⏳ Retrying in 10 seconds...")
                await self._close_redis()
                await asyncio.sleep(10)

        await self._close_redis()
        logger.debug("👋 RedisStreamConsumer exited cleanly.")

    def stop(self):
        """
        Signal the consumer to shut down gracefully.
        Safe to call from sync or async context.
        """
        logger.debug(f"🛑 RedisStreamConsumer stopping — stream: {self.stream_key}")
        self._shutdown_event.set()

    async def delete_message(self, stream_id: str) -> None:
        """
        Explicitly delete a message from the stream by its entry ID.

        Rarely needed — the stream is self-managing via MAXLEN ~1000 trimming and
        full deletion on room_finished. Use this only if the agent needs to explicitly
        remove a specific entry (e.g. sensitive data that must not persist).

        Call from inside on_message::

            async def on_message(msg: StreamMessage, consumer: RedisStreamConsumer) -> None:
                # ... process msg ...
                await consumer.delete_message(msg.stream_id)

        :param stream_id: The Redis stream entry ID (``msg.stream_id``).
        """
        if not self._redis:
            raise RuntimeError("Consumer is not connected to Redis.")
        await self._redis.xdel(self.stream_key, stream_id)
        logger.debug(f"RedisStreamConsumer: deleted entry {stream_id} from {self.stream_key}")

    async def delete_conversation(self, conv_key: str) -> None:
        """
        Explicitly delete the conversation from Redis — both the stream and the
        conversation meta hash.

        Call this from the agent on disconnect as an alternative to waiting for
        the room_finished webhook, or alongside it for belt-and-suspenders cleanup.

        The conv_key is available in the LiveKit job metadata::

            conv_key = job.metadata.get("convKey")  # e.g. "conv:whatsapp:<channelUuid>:<senderId>"

        Usage::

            await ctx.wait_for_disconnect()
            consumer.stop()
            await consumer_task
            await consumer.delete_conversation(conv_key)

        :param conv_key: The conversation key (e.g. ``conv:whatsapp:<channelUuid>:<senderId>``).
                         The meta hash key is derived as ``conv:meta:{conv_key}``.
        """
        if not self._redis:
            raise RuntimeError("Consumer is not connected to Redis.")
        meta_key = f"conv:meta:{conv_key}"
        deleted = await self._redis.delete(self.stream_key, meta_key)
        logger.debug(
            f"RedisStreamConsumer: deleted conversation — stream [{self.stream_key}] "
            f"+ meta [{meta_key}] ({deleted} key(s) removed)"
        )

    # ──────────────────────────────────────────────────────────────────────────
    # Internal
    # ──────────────────────────────────────────────────────────────────────────

    async def _read_loop(self):
        """Core XREAD BLOCK loop — runs until shutdown is signalled or an exception is raised."""
        while not self._shutdown_event.is_set():
            results = await self._redis.xread(
                {self.stream_key: self._cursor},
                count=self.read_count,
                block=self.block_ms,
            )

            if not results:
                # Timeout — no new messages, loop again
                continue

            # results: list of (stream_key, list of (entry_id, fields_dict))
            for _key, entries in results:
                for entry_id, fields in entries:
                    msg = self._parse_entry(entry_id, fields)
                    try:
                        await self.on_message(msg, self)
                    except Exception as e:
                        logger.error(
                            f"❌ on_message raised an exception for entry {entry_id}: {e}",
                            exc_info=True,
                        )
                    # Advance cursor regardless — a failed callback must not
                    # replay the same message and cause an infinite error loop
                    self._cursor = entry_id

    def _parse_entry(self, entry_id: str, fields: Dict[str, str]) -> StreamMessage:
        """Parse raw Redis Stream entry fields into a typed StreamMessage."""
        payload_raw = fields.get("payload", "{}")
        try:
            payload = json.loads(payload_raw)
        except (json.JSONDecodeError, TypeError):
            logger.warning(f"RedisStreamConsumer: could not parse payload for entry {entry_id}")
            payload = {}

        return StreamMessage(
            stream_id=entry_id,
            stream_key=self.stream_key,
            direction=fields.get("direction", "inbound"),
            sender_id=fields.get("senderId", ""),
            provider_type=fields.get("providerType", ""),
            channel_uuid=fields.get("channelUuid", ""),
            received_at=fields.get("receivedAt", ""),
            payload=payload,
        )

    async def _close_redis(self):
        if self._redis:
            try:
                await self._redis.aclose()
            except Exception:
                pass
            self._redis = None

    def _setup_signal_handlers(self):
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, lambda s=sig: asyncio.create_task(self._on_signal(s)))

    async def _on_signal(self, sig):
        logger.debug(f"🛑 Received signal: {sig.name}")
        self.stop()
