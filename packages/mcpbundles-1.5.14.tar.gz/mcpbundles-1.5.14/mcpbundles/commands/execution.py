"""Execution commands: call, read, prompt, exec.

All execution is live against the server — no caching.

Supports two modes:
  - Hub mode (default): connects to /hub/ for platform-level tools
  - Server mode (--server <slug>): connects to /bundle/<slug>/ for direct
    MCP server tool calls via standard MCP protocol (no code_execution wrapper)

Argument parsing:
  key=value args get conservative client-side coercion (bool, null, int, JSON
  structures).  The server applies precise type coercion via Pydantic lax
  validation against the tool's actual parameter types — no extra round-trip
  for schema lookup needed.
"""

import asyncio
import logging
import re
import sys
from pathlib import Path

import click

from mcpbundles.args import parse_tool_args, ArgParseError
from mcpbundles.auth_resolve import resolve_auth
from mcpbundles.config import AuthError, CLISettings
from mcpbundles.exit_codes import USER_ERROR, TOOL_ERROR, CONNECTION_ERROR
from mcpbundles.mcp_client import (
    hub_session, call_tool, extract_text,
    ConnectionError, ToolCallError,
)
from mcpbundles.output import render_call_result, render_error, render_hint, print_json, render_success
from mcpbundles.completion import tool_name_completer, resource_uri_completer, prompt_name_completer
from mcpbundles.endpoints import resolve_endpoint
from mcpbundles.commands.options import PreferredAliasOption

logger = logging.getLogger(__name__)

_HASH_SUFFIX_RE = re.compile(r"-[a-f0-9]{3}$")


def _emit_tool_error_hints(error_msg: str, tool_name: str | None = None, bundle_slug: str | None = None) -> None:
    """Emit contextual hints after a tool error to help AI and human users recover.

    Only emits hints for discovery/usage errors (unknown tool, missing server,
    wrong endpoint). Auth and server errors don't get hints — they have
    their own recovery paths.
    """
    lower = error_msg.lower()
    is_discovery_error = "unknown tool" in lower or "not found" in lower
    is_server_context_error = ("server" in lower or "bundle" in lower) and "require" in lower
    emitted = False

    if tool_name and _HASH_SUFFIX_RE.search(tool_name) and not bundle_slug and is_discovery_error:
        render_hint(
            f"'{tool_name}' looks like an MCP server tool (has hash suffix). "
            f"Try: mcpbundles call {tool_name} --server <slug>"
        )
        render_hint("Run: mcpbundles call list_connected_mcp_servers  to list available MCP servers and their slugs")
        emitted = True

    if is_discovery_error and not emitted:
        if bundle_slug:
            render_hint(f"Run: mcpbundles tools --server {bundle_slug}  to list available tools in this MCP server")
        else:
            render_hint("Run: mcpbundles tools  for hub tools, or  mcpbundles tools --server <slug>  for MCP server tools")
        emitted = True

    if is_server_context_error:
        render_hint("MCP server tools need server= in exec. Example: await tool_name(server='attio', ...)")
        emitted = True

    if emitted:
        skill_path = Path(".skills/mcpbundles-cli/SKILL.md")
        if skill_path.exists():
            render_hint(f"Full guide: {skill_path}")
        else:
            render_hint("Run: mcpbundles init  to generate a local skill file with discovery workflow")



@click.command("call")
@click.argument("tool_name", shell_complete=tool_name_completer)
@click.argument("args", nargs=-1)
@click.option("-f", "--file", "file_path", help="Read arguments from a JSON file")
@click.option("--stdin", "from_stdin", is_flag=True, help="Read JSON arguments from stdin")
@click.option(
    "--code-file",
    "code_file",
    help=(
        "Read raw text/source from a file and inject it as the 'code' argument "
        "(for code_execution and any tool that takes a 'code' string param). "
        "Mutually exclusive with -f/--file (which expects a JSON args file)."
    ),
)
@click.option("--raw", is_flag=True, help="Output full MCP response envelope")
@click.option("--pretty", is_flag=True, help="Rich-formatted output with syntax highlighting")
@click.option("--as", "connection", help="Use a named connection")
@click.option(
    "--server",
    "--bundle",
    "bundle_slug",
    cls=PreferredAliasOption,
    preferred_opts=("--server",),
    help="Connect directly to an MCP server endpoint",
)
@click.option("--output-dir", "output_dir", help="Save binary content (images, files) to this directory instead of ~/.mcpbundles/cache/")
@click.pass_context
def call_cmd(
    ctx: click.Context,
    tool_name: str,
    args: tuple[str, ...],
    file_path: str | None,
    from_stdin: bool,
    code_file: str | None,
    raw: bool,
    pretty: bool,
    connection: str | None,
    bundle_slug: str | None,
    output_dir: str | None,
) -> None:
    """Call an MCP tool by name.

    By default, calls hub-level tools. Use --server to call a tool
    directly on an MCP server endpoint (no code_execution wrapper needed).

    Arguments can be passed as key=value pairs, key:=json, JSON string, or file.
    Key=value arguments get conservative client-side coercion; the server
    handles precise type coercion via Pydantic.

    Use --code-file to load source code from a file into a tool's 'code'
    parameter (the Python sandbox is the canonical use case). This is the
    correct flag for `mcpbundles call code_execution --code-file script.py`;
    the existing -f/--file flag expects a JSON args file and will reject a
    raw .py source file with "Invalid JSON".

    Examples:
        mcpbundles call list_connected_mcp_servers                   # hub tool
        mcpbundles call attio-list-lists-5b7 --server attio          # MCP server tool
        mcpbundles call search query="test" include_archived:=true
        mcpbundles call create-note '{"title": "Hello"}' --server my-server
        mcpbundles call process-data -f payload.json
        mcpbundles call code_execution --code-file analysis.py --server resend
    """
    if code_file and file_path:
        render_error("--code-file and -f/--file are mutually exclusive (one passes raw source as 'code=', the other passes a JSON args blob).")
        raise SystemExit(USER_ERROR)
    if code_file and from_stdin:
        render_error("--code-file and --stdin are mutually exclusive.")
        raise SystemExit(USER_ERROR)
    if code_file:
        p = Path(code_file)
        if not p.exists():
            render_error(f"File not found: {code_file}")
            raise SystemExit(USER_ERROR)
        if any(a.startswith("code=") or a.startswith("code:=") for a in args):
            render_error("--code-file conflicts with an explicit 'code=' argument.")
            raise SystemExit(USER_ERROR)
        try:
            source = p.read_text()
        except OSError as exc:
            render_error(f"Could not read --code-file {code_file}: {exc}")
            raise SystemExit(USER_ERROR)
        # Append as a key=value arg; parse_tool_args treats this as a literal
        # string (no JSON coercion of multi-line source).
        args = (*args, f"code={source}")

    mode = "raw" if raw else ("pretty" if pretty else "json")
    if output_dir:
        from mcpbundles.output import set_output_dir
        set_output_dir(output_dir)
    asyncio.run(_call_impl(ctx, tool_name, args, file_path, from_stdin, mode, connection, bundle_slug))


async def _call_impl(
    ctx: click.Context,
    tool_name: str,
    raw_args: tuple[str, ...],
    file_path: str | None,
    from_stdin: bool,
    mode: str,
    connection: str | None,
    bundle_slug: str | None = None,
) -> None:
    settings: CLISettings = ctx.obj["settings"]
    try:
        auth = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    endpoint = resolve_endpoint(bundle_slug) if bundle_slug else auth.endpoint

    try:
        async with hub_session(auth.token, auth.url, endpoint) as session:
            schema = None
            has_kv_args = raw_args and not from_stdin and not file_path
            if has_kv_args:
                try:
                    tools_result = await session.list_tools()
                    match = next((t for t in tools_result.tools if t.name == tool_name), None)
                    if match and match.inputSchema:
                        schema = match.inputSchema
                except Exception:
                    pass

            try:
                arguments = parse_tool_args(
                    raw_args, file_path=file_path, from_stdin=from_stdin,
                    schema=schema,
                )
            except ArgParseError as exc:
                render_error(str(exc))
                raise SystemExit(USER_ERROR)

            result = await call_tool(session, tool_name, arguments)
            render_call_result(result, mode=mode)
    except ToolCallError as exc:
        render_error(str(exc))
        _emit_tool_error_hints(str(exc), tool_name=tool_name, bundle_slug=bundle_slug)
        raise SystemExit(TOOL_ERROR)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)
    except ConnectionError as exc:
        render_error(str(exc))
        _emit_tool_error_hints(str(exc), tool_name=tool_name, bundle_slug=bundle_slug)
        raise SystemExit(CONNECTION_ERROR)


@click.command("read")
@click.argument("uri", shell_complete=resource_uri_completer)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--as", "connection", help="Use a named connection")
@click.pass_context
def read_cmd(ctx: click.Context, uri: str, as_json: bool, connection: str | None) -> None:
    """Read an MCP resource by URI.

    Examples:
        mcpbundles read config://workspace/settings
        mcpbundles read --json config://workspace/settings
    """
    asyncio.run(_read_impl(ctx, uri, as_json, connection))


async def _read_impl(ctx: click.Context, uri: str, as_json: bool, connection: str | None) -> None:
    settings: CLISettings = ctx.obj["settings"]
    try:
        auth = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    try:
        async with hub_session(auth.token, auth.url, auth.endpoint) as session:
            result = await session.read_resource(uri)
            for content in result.contents:
                if as_json:
                    print_json({"uri": str(content.uri), "mimeType": content.mimeType, "text": content.text if hasattr(content, "text") else None})
                else:
                    if hasattr(content, "text") and content.text:
                        print(content.text)
                    else:
                        print(f"[Binary content: {content.mimeType}]")
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)
    except ConnectionError as exc:
        render_error(str(exc))
        raise SystemExit(CONNECTION_ERROR)


@click.command("prompt")
@click.argument("prompt_name", shell_complete=prompt_name_completer)
@click.argument("args", nargs=-1)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--as", "connection", help="Use a named connection")
@click.pass_context
def prompt_cmd(ctx: click.Context, prompt_name: str, args: tuple[str, ...], as_json: bool, connection: str | None) -> None:
    """Get an MCP prompt by name.

    Examples:
        mcpbundles prompt summarize-data dataset=sales_q4
    """
    try:
        arguments = parse_tool_args(args)
    except ArgParseError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    asyncio.run(_prompt_impl(ctx, prompt_name, arguments, as_json, connection))


async def _prompt_impl(ctx: click.Context, prompt_name: str, arguments: dict, as_json: bool, connection: str | None) -> None:
    settings: CLISettings = ctx.obj["settings"]
    try:
        auth = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    try:
        async with hub_session(auth.token, auth.url, auth.endpoint) as session:
            result = await session.get_prompt(prompt_name, arguments)
            if as_json:
                print_json({"description": result.description, "messages": [{"role": m.role, "content": m.content.text if hasattr(m.content, "text") else str(m.content)} for m in result.messages]})
            else:
                if result.description:
                    print(f"# {result.description}\n")
                for msg in result.messages:
                    print(f"[{msg.role}]")
                    if hasattr(msg.content, "text"):
                        print(msg.content.text)
                    else:
                        print(str(msg.content))
                    print()
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)
    except ConnectionError as exc:
        render_error(str(exc))
        raise SystemExit(CONNECTION_ERROR)


@click.command("exec")
@click.argument("code", required=False)
@click.option("-f", "--file", "file_path", help="Execute code from a file")
@click.option("--raw", is_flag=True, help="Output full MCP response envelope")
@click.option("--pretty", is_flag=True, help="Rich-formatted output")
@click.option("--stream", is_flag=True, help="Stream output line-by-line as it arrives")
@click.option("--as", "connection", help="Use a named connection")
@click.option("--output-dir", "output_dir", help="Save binary content (images, files) to this directory instead of ~/.mcpbundles/cache/")
@click.pass_context
def exec_cmd(ctx: click.Context, code: str | None, file_path: str | None, raw: bool, pretty: bool, stream: bool, connection: str | None, output_dir: str | None) -> None:
    """Execute code via code_execution tool (sugar for 'call code_execution').

    Examples:
        mcpbundles exec "result = 2 + 2; print(result)"
        mcpbundles exec -f script.py
        mcpbundles exec -f sync_contacts.py --stream
        echo "print('hello')" | mcpbundles exec --stdin
    """
    if file_path:
        p = Path(file_path)
        if not p.exists():
            render_error(f"File not found: {file_path}")
            raise SystemExit(USER_ERROR)
        code = p.read_text()
    elif not code and not sys.stdin.isatty():
        code = sys.stdin.read()

    if not code:
        render_error("Provide code as argument, -f file, or pipe via stdin.")
        raise SystemExit(USER_ERROR)

    if output_dir:
        from mcpbundles.output import set_output_dir
        set_output_dir(output_dir)

    arguments = {"code": code}
    if raw:
        mode = "raw"
    elif stream:
        mode = "stream"
    elif pretty:
        mode = "pretty"
    else:
        mode = "json"
    asyncio.run(_exec_impl(ctx, arguments, mode, connection))


async def _exec_impl(ctx: click.Context, arguments: dict, mode: str, connection: str | None) -> None:
    settings: CLISettings = ctx.obj["settings"]
    try:
        auth = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    try:
        async with hub_session(auth.token, auth.url, auth.endpoint) as session:
            result = await call_tool(session, "code_execution", arguments)
            render_call_result(result, mode=mode)
    except ToolCallError as exc:
        render_error(str(exc))
        _emit_tool_error_hints(str(exc))
        raise SystemExit(TOOL_ERROR)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)
    except ConnectionError as exc:
        render_error(str(exc))
        _emit_tool_error_hints(str(exc))
        raise SystemExit(CONNECTION_ERROR)
