"""Click option helpers for compatibility aliases."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import click


class PreferredAliasOption(click.Option):
    """Keep legacy aliases parseable while rendering only preferred flags in help."""

    def __init__(
        self,
        *param_decls: str,
        preferred_opts: Sequence[str] | None = None,
        **attrs: Any,
    ) -> None:
        self._preferred_opts = tuple(preferred_opts or ())
        super().__init__(*param_decls, **attrs)

    def get_help_record(self, ctx: click.Context) -> tuple[str, str] | None:
        if not self._preferred_opts:
            return super().get_help_record(ctx)

        original_opts = self.opts
        original_secondary_opts = self.secondary_opts
        try:
            preferred = set(self._preferred_opts)
            self.opts = [opt for opt in self.opts if opt in preferred] or self.opts
            self.secondary_opts = [
                opt for opt in self.secondary_opts if opt in preferred
            ]
            return super().get_help_record(ctx)
        finally:
            self.opts = original_opts
            self.secondary_opts = original_secondary_opts
