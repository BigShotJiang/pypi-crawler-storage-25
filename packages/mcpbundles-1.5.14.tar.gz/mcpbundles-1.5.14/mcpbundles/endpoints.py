"""MCP endpoint path resolution."""


def resolve_endpoint(server_slug: str | None) -> str:
    """Return the MCP endpoint path for a server slug, or the hub default."""
    if server_slug:
        return f"/bundle/{server_slug}/"
    return "/hub/"
