---
name: extraction-faits
version: 1.1
date: 2026-04-27
description: Extraire les faits pertinents d'un dossier en défense ou en demande et produire un fichier `livrables/faits-pertinents.md` chargé en contexte pour toute la session. Déclencher dès l'ouverture d'un dossier ou quand les pièces sont disponibles.
---

# Extraction des faits pertinents

---

## §1 — Rôle et périmètre

Lire les pièces du dossier et produire un fichier de référence `livrables/faits-pertinents.md`.  
Ce fichier reste chargé en contexte pour toutes les tâches ultérieures de la session.

**Ce skill fait :**
- Lire les pièces principales (arrêt attaqué, MA adverse si dossier en défense, conclusions d'appel)
- Sélectionner les faits utiles à l'argumentation
- Les organiser par axe de réponse (branches du moyen, ou thèmes si non encore identifiés)

**Ce skill ne fait pas :**
- Analyser le droit → skill de recherche adapté à la juridiction : `recherche-Ccass_droit privé`, `recherche-CE_droit-public`, etc.
- Construire et rédiger le mémoire → `redaction-MA-cassation` ou `redaction-MD-cassation` selon le sens du pourvoi
- Identifier les moyens de cassation → `redaction-MA-cassation` §2

---

## §2 — Méthode

### Étape 1 — Lecture des pièces

Lire dans cet ordre de priorité :
1. L'arrêt attaqué (CA)
2. Le mémoire ampliatif adverse (MA) si dossier en défense, ou les conclusions d'appel de la partie adverse si dossier en demande
3. En défense : nos propres conclusions d'appel / En demande : les conclusions d'appel de la partie adverse

Ne lire que les pièces disponibles en `.md` dans le dossier.  
Ne pas charger l'ensemble du workspace sans demande explicite.

### Étape 2 — Sélection des faits

Un fait est pertinent en défense s'il :
- Est constaté par la CA dans l'arrêt attaqué 
- Et :
  - Contredit une affirmation du MA adverse
  - Établit un contexte que le MA minimise ou ignore
  - Supporte un argument de défense 
  - Distingue notre espèce d'une jurisprudence adverse citée

Un fait est pertinent en demande s'il :
- Est constaté par la CA dans l'arrêt attaqué 
- Et :
  - La CA a constaté ce fait mais l'a ignoré ou contredit dans son raisonnement juridique — ce décalage entre les propres constatations de la CA et leur traitement juridique peut fonder un moyen de cassation
  - Établit un contexte que la CA minimise ou ignore ensuite dans l'arrêt attaqué dans l'application du droit
  - Supporte un argument de demande
  - Distingue notre espèce d'une jurisprudence que la cour d'appel cite 

Écarter les faits purement narratifs sans portée argumentative.

### Étape 3 — Organisation

Une partie contextuelle : regrouper tous les faits pertinents de façon chronologique pour reconstituer la trame factuelle de l'espèce.

Une partie visant à préparer l'argumentation : organiser les faits par axe de réponse. En défense : Organiser par branche du moyen du MA adverse. En demande : Organiser par thème ou axe de réponse. Si aucun thème clair n'émerge, ne pas organiser. 

Pour chaque fait : source exacte (pièce + paragraphe ou page).

---

## §3 — Format de sortie

Fichier `livrables/faits-pertinents.md` dans le dossier courant.  
Créer le dossier `Livrables/` s'il n'existe pas.  
Appender si le fichier existe déjà — ne jamais écraser.

```
# Faits pertinents — [Nom du dossier]

## Extraction du [JJ/MM/AAAA]

## Faits contextuels

## Branche X / Thème X
- **Fait** : [description]  
  *Source : [pièce, p. X / §X]*
```

---

## §4 — Chargement en contexte

Une fois le fichier produit, indiquer à l'utilisateur :  
*"Le fichier `livrables/faits-pertinents.md` est créé. Pour le charger automatiquement à chaque session, ajoute cette ligne dans le `CLAUDE.md` du dossier :*

```
- Faits pertinents : @livrables/faits-pertinents.md
```
*"*
