---
name: redaction-moyen
description: Rédiger le chapeau d'un moyen de cassation (niveau 1 : grief / niveau 2 : "Alors que" de chaque branche) et l'insérer dans le draft du mémoire ampliatif. Déclencher une fois que les développements des branches sont rédigés. Ne déclencher ni avant (extraction-faits, identification-moyens, rédaction des développements viennent d'abord), ni en défense.
---

# Rédaction du chapeau de moyen

Étape finale du mémoire ampliatif. Requiert que les développements des branches soient déjà rédigés dans le draft.

**Principe directeur : le moyen de cassation est l'arrêt de cassation à l'envers.**
Le "Alors que" de chaque branche est le chapeau de l'arrêt de cassation souhaité : il énonce la règle que la Cour de cassation poserait pour censurer l'arrêt attaqué. Construire ce chapeau revient à projeter d'abord l'arrêt de cassation idéal, puis à écrire le moyen à rebours.

---

## §1 -- Rôle et périmètre

**Ce skill fait :**
- Rédiger le niveau 1 (grief : "fait grief à l'arrêt attaqué de l'avoir...")
- Rédiger le niveau 2 (chapeau de chaque branche : "Alors que [règle] ;")
- Présenter les propositions à l'utilisateur pour validation
- Insérer dans le draft du mémoire ampliatif après validation

**Ce skill ne fait pas :**
- Extraire les faits -> skill `extraction-faits`
- Identifier les moyens de cassation -> skill `redaction-MA-cassation` §2
- Rédiger les développements des branches -> skill `redaction-MA-cassation` §4

---

## §2 -- Méthode

### Phase 1 -- Lecture

Lire dans cet ordre :
1. Draft du mémoire ampliatif (développements des branches déjà rédigés) -- lire en entier
2. Fichier contexte `livrables/[nom-dossier].md`, section **Notes stratégiques** -- qualification retenue, textes visés, cas d'ouverture de chaque moyen/branche
3. Arrêt d'appel : dispositif (pour le niveau 1) et passages du raisonnement visés par chaque branche (pour le niveau 2)
4. **Arrêts cités dans les développements** -- lire les attendus/chapeaux des arrêts de la Cour de cassation invoqués dans la majeure de chaque branche, pour en reprendre la formulation exacte de la règle

> **Règle : la formulation de la règle dans le "Alors que" doit s'appuyer sur la façon dont la Cour de cassation l'énonce dans les arrêts cités.** Ne pas reformuler la règle ex nihilo quand un arrêt de principe la formule déjà.

### Phase 2 -- Construction collaborative (moyen par moyen)

#### Étape 1 -- Projeter l'arrêt de cassation souhaité

Pour chaque branche, avant de rédiger le "Alors que", répondre mentalement à la question :

> "Si la Cour de cassation accueille ce moyen, quel chapeau poserait-elle dans son arrêt ?"

Ce chapeau projeté devient le "Alors que" de la branche. La règle doit être :
- Énoncée dans sa généralité (pas taillée pour les faits de l'espèce)
- Formulée en reprenant les termes des arrêts de principe cités dans le développement
- Suffisamment précise pour fonder la censure
- Cohérente avec la qualification retenue dans les Notes stratégiques du fichier contexte

#### Étape 2 -- Rédiger le niveau 2 (branches)

La structure interne du "Alors que" varie selon le cas d'ouverture. Voir §3 pour les modèles complets.

Pour chaque branche, proposer :
- Le "Alors que" complet (règle + articulation avec les faits + formule de clôture)
- Le connecteur de subordination entre branches si le moyen comporte plusieurs branches (cf. §4)

#### Étape 3 -- Rédiger le niveau 1 (grief)

Une fois les branches finalisées, rédiger le grief :

> "[Partie] fait grief à l'arrêt attaqué de l'avoir [verbe + description précise du dispositif attaqué]"

Le grief doit :
- Correspondre exactement au dispositif de l'arrêt attaqué (verbe + chef de décision)
- Lister toutes les demandes subséquentes rejetées par voie de conséquence (indemnité de licenciement, préavis, congés payés, dommages et intérêts, etc.)
- Ne viser que ce qui est effectivement argumenté dans les branches

#### Étape 4 -- Présentation à l'utilisateur

Présenter pour chaque moyen :

```
MOYEN X

Niveau 1 -- Grief proposé :
[Partie] fait grief à l'arrêt attaqué de l'avoir...

Branche 1 -- [Cas d'ouverture] :
Alors que [texte complet] ;

Branche 2 -- [Cas d'ouverture] :
Alors, [connecteur], que [texte complet] ;
```

**Attendre la validation avant toute insertion dans le draft.**

### Phase 3 -- Insertion

Après validation, insérer dans le draft du mémoire ampliatif :
- Le grief (niveau 1) en tête du moyen, avant les branches
- Le "Alors que" (niveau 2) en tête de chaque branche numérotée

Lire le fichier entier avant toute modification.

---

## §3 -- Structure du "Alors que" par cas d'ouverture

### A. Violation de la loi

**Structure :** règle générale + constatations propres de la CA + reproche de n'avoir pas tiré les conséquences légales.

**Modèle :**

> Alors que [règle de droit, formulée dans les termes de la Cour de cassation] ; qu'en l'espèce, la cour d'appel a constaté [rappel des constatations de fait que la CA a elle-même retenues] ; qu'en [statuant comme elle l'a fait / jugeant néanmoins que...], sans tirer les conséquences légales de ses propres constatations, la cour d'appel a violé [textes visés] ;

**Ce qui caractérise cette branche :** la CA disposait de toutes les constatations nécessaires pour appliquer la règle, mais elle a refusé d'en tirer la conséquence juridique qui s'imposait. C'est un syllogisme fermé : la prémisse majeure (règle) et la prémisse mineure (faits constatés par la CA) commandaient une conclusion différente.

### B. Défaut de base légale

**Structure :** rappel des faits ou arguments invoqués par le demandeur + reproche à la CA de n'avoir pas recherché si...

**Modèle :**

> Alors que [règle de droit] ; qu'en se bornant à [motif insuffisant retenu par la CA], sans rechercher si [élément déterminant invoqué dans les conclusions du demandeur], la cour d'appel a privé sa décision de base légale au regard de [textes visés] ;

ou :

> Alors que [le demandeur] faisait valoir dans ses conclusions d'appel que [rappel des faits/arguments invoqués] ; qu'en [se bornant à / retenant que...], sans rechercher si [ces éléments ne constituaient pas / n'étaient pas de nature à...], la cour d'appel a privé sa décision de base légale au regard de [textes visés] ;

**Ce qui caractérise cette branche :** la CA a peut-être correctement identifié la règle, mais ses motifs de fait sont insuffisants pour vérifier qu'elle l'a correctement appliquée. Il manque une recherche, une vérification, un examen.

### C. Défaut de réponse à conclusions

**Structure :** visa des conclusions précises du demandeur + constat du silence de la CA.

**Modèle :**

> Alors que [le demandeur] faisait valoir dans ses conclusions d'appel que [moyen précis : fait + déduction juridique + portée sur la solution] ; qu'en [statuant comme elle l'a fait] sans répondre à ce moyen, la cour d'appel a violé l'article 455 du code de procédure civile ;

### D. Dénaturation

**Structure :** rappel des termes clairs de l'acte + interprétation incompatible retenue par la CA.

**Modèle :**

> Alors que [l'acte / la clause / le document] stipulait clairement que [termes exacts] ; qu'en retenant que [interprétation retenue par la CA], la cour d'appel a dénaturé [les termes clairs et précis de l'acte], en violation de l'obligation faite au juge de ne pas dénaturer les documents de la cause ;

### E. Contradiction de motifs

**Structure :** rappel des deux motifs contradictoires.

**Modèle :**

> Alors qu'en retenant, d'une part, que [motif A] et, d'autre part, que [motif B], la cour d'appel s'est contredite et a violé l'article 455 du code de procédure civile ;

---

## §4 -- Articulation entre branches (connecteurs de subordination)

Quand un moyen comporte plusieurs branches, leur ordre et leurs connecteurs reflètent leur rapport logique.

| Position | Connecteur | Usage |
|---|---|---|
| Première branche | "Alors que..." | Branche principale |
| Branche subsidiaire | "Alors, en tout état de cause, que..." | La branche tient même si la première est rejetée |
| Branche alternative | "Alors, subsidiairement, que..." | La branche n'est examinée que si la précédente est rejetée |
| Branche complémentaire | "Alors, de surcroit, que..." | Renforce la branche précédente par un argument additionnel |

**Ordre recommandé :**
1. Violation de la loi avant défaut de base légale (la violation est le reproche le plus fort ; le défaut de base légale est subsidiaire)
2. Défaut de base légale avant défaut de réponse à conclusions
3. Les branches portant sur le même raisonnement de la CA sont groupées

---

## §5 -- Formules de clôture (récapitulatif)

| Cas d'ouverture | Formule de clôture complète |
|---|---|
| Violation de loi | "sans tirer les conséquences légales de ses propres constatations, la cour d'appel a violé [textes]" |
| Violation de loi (variante : mauvaise application) | "la cour d'appel a violé [textes]" |
| Défaut de base légale | "la cour d'appel a privé sa décision de base légale au regard de [textes]" |
| Défaut de réponse à conclusions | "la cour d'appel a violé l'article 455 du code de procédure civile" |
| Contradiction de motifs | "la cour d'appel s'est contredite et a violé l'article 455 du code de procédure civile" |
| Dénaturation | "la cour d'appel a dénaturé [les termes clairs et précis de l'acte], en violation de l'obligation faite au juge de ne pas dénaturer les documents de la cause" |
| Excès de pouvoir | "la cour d'appel a excédé ses pouvoirs, en violation de [textes]" |

Pour les formules complexes (plusieurs textes visés, rédactions antérieures applicables), vérifier les références exactes dans le fichier contexte et via le skill `recherche-Ccass_droit privé`.
