---
name: recherche-CEDH
version: 2.0
date: 2026-05-14
description: "Recherche et analyse de jurisprudence de la Cour européenne des droits de l'homme (CEDH/ECHR). Utilise Legal Data Hunter MCP (97 000+ décisions 1960-2026), l'API HUDOC (hudoc.echr.coe.int) pour les filtres spécifiques (article, importance, État défendeur, formation, thésaurus) et les guides ECHR-KS. Déclencher pour toute question impliquant la Convention européenne des droits de l'homme, un arrêt de la CEDH, un numéro de requête CEDH, un article de la Convention (art. 2 à 18, Protocoles), une condamnation d'un État par la Cour de Strasbourg, les droits fondamentaux au sens de la Convention, la marge d'appréciation, l'épuisement des voies de recours internes, ou toute recherche par nom d'affaire ou numéro de requête CEDH."
---

# Recherche et analyse — CEDH

## §1 — Sources

==- **Legal Data Hunter MCP** : `search`, `namespace: "case_law"`, `country: ["CoE"]` — jurisprudence CEDH 1960-2026 (~97 000 décisions). Retourne extrait, métadonnées et identifiant source. **Langue : formuler les requêtes en anglais** pour maximiser la pertinence (le fonds est majoritairement indexé en anglais). `get_document` pour le texte intégral. `resolve_reference` pour résoudre un numéro de requête ou un ECLI en identifiant exact.==
==- **API HUDOC** (WebFetch) : complément obligatoire pour les filtres que Legal Data Hunter ne fournit pas : article de la Convention, niveau d'importance, État défendeur, formation (GC/chambre/comité), codes thésaurus (`kpthesaurus`). Utiliser en ciblage après la recherche sémantique, ou directement pour une recherche par numéro de requête, par article ou par État.==
- **Guides ECHR-KS** : guides de jurisprudence rédigés par le greffe, article par article. Mis à jour semestriellement. Accessibles via `WebFetch`.
- **Thésaurus HUDOC** : `references/hudoc-keywords.md`, mots-clés classés article par article.

---

==### 1.1 — Legal Data Hunter : paramètres==

==| Paramètre | Valeur |==
==|---|---|==
==| `country` | `["CoE"]` |==
==| `namespace` | `"case_law"` |==
==| `court_tier` | `1` (seule valeur) |==
==| `language` | `"fre"` ou `"eng"` (filtrage optionnel) |==
==| `top_k` | 5 (SIMPLE) / 10 (COMPLEXE) |==
==| `alpha` | 0.7 (défaut) — baisser à 0.4 pour des recherches plus littérales (numéro de requête, nom de partie) |==
==| `date_start` / `date_end` | Format `YYYY-MM-DD` |==

==**Fichiers volumineux.** `get_document` retourne parfois des fichiers trop grands pour être lus directement. Dans ce cas, utiliser l'outil **Grep** (recherche par mot-clé à l'intérieur du fichier sauvegardé) pour localiser les passages pertinents sans charger le document entier. Chercher le nom des parties, un numéro de paragraphe, un mot du dispositif.==

---

### 1.2 — API HUDOC : paramètres

**URL recherche** : `https://hudoc.echr.coe.int/app/query/results`

**Paramètres obligatoires** :

| Paramètre | Rôle | Valeur |
|---|---|---|
| `query` | Requête de filtrage | Expression booléenne (voir syntaxe ci-dessous) |
| `select` | Champs retournés | Liste de champs séparés par des virgules |
| `sort` | Tri | `kpdate Descending` (défaut recommandé) |
| `start` | Offset de pagination | `0` pour la première page |
| `length` | Nombre de résultats | `20` (recommandé), max `500` |
| `rankingModelId` | Modèle de classement | `22222222-ffff-0000-0000-000000000000` (obligatoire) |

**Champs `select` standard** (copier tel quel) :

```
itemid,docname,doctype,appno,conclusion,importance,originatingbody,typedescription,kpdate,kpdateAsText,documentcollectionid2,languageisocode,extractedappno,doctypebranch,respondent,article,kpthesaurus
```

**Syntaxe du paramètre `query`** :

Toujours commencer par `contentsitename:ECHR`. Combiner avec `AND` :

| Filtre | Syntaxe | Exemples |
|---|---|---|
| Type de document | `doctype=XXX` | `HFJUD` (arrêt FR), `HEJUD` (arrêt EN), `HFDEC` (décision FR), `HEDEC` (décision EN) |
| État défendeur | `respondent="XXX"` | `"FRA"`, `"ITA"`, `"TUR"`, `"RUS"`, `"DEU"` |
| Article de la Convention | `article="N"` | `"6"`, `"8"`, `"3"`, `"P1-1"` (Protocole 1, art. 1) |
| Niveau d'importance | `importance="N"` | `"1"` (Key cases), `"2"` (Important), `"3"` (Standard) |
| Date (intervalle) | `kpdate>=` / `kpdate<=` | `"2020-01-01T00:00:00.0Z"` |
| Texte libre | Termes simples | `marge appréciation`, `margin appreciation` |
| Formation | `doctypebranch=XXX` | `GRANDCHAMBER`, `CHAMBER`, `COMMITTEE` |
| Collection | `documentcollectionid2="XXX"` | `"ADVISORYOPINIONS"` (avis consultatifs), `"CLIN"` (fiches) |
| Exclusion | `NOT (doctype=PR OR doctype=HEJUD)` | Exclure communiqués de presse, doublons EN |
| Numéro de requête | `appno:"NNNNN/NN"` | `appno:"36815/03"` |

**Opérateurs** : `AND`, `OR`, `NOT`, parenthèses. Valeurs URL-encodées.

**Exemple — GC c. France, art. 8, depuis 2015** :
```
https://hudoc.echr.coe.int/app/query/results?query=contentsitename%3AECHR%20AND%20(doctype%3DHFJUD%20OR%20doctype%3DHEJUD)%20AND%20(respondent%3D%22FRA%22)%20AND%20(article%3D%228%22)%20AND%20(doctypebranch%3DGRANDCHAMBER)%20AND%20(kpdate%3E%3D%222015-01-01T00%3A00%3A00.0Z%22)&select=itemid,docname,doctype,appno,conclusion,importance,kpdate,doctypebranch,respondent,article,languageisocode&sort=kpdate%20Descending&start=0&length=20&rankingModelId=22222222-ffff-0000-0000-000000000000
```

**Exemple — par numéro de requête** :
```
https://hudoc.echr.coe.int/app/query/results?query=contentsitename%3AECHR%20AND%20(appno%3A%2236815/03%22)&select=itemid,docname,doctype,appno,conclusion,importance,kpdate,doctypebranch,respondent,article,languageisocode&sort=kpdate%20Descending&start=0&length=10&rankingModelId=22222222-ffff-0000-0000-000000000000
```

### 1.3 — Texte intégral (HUDOC)

**URL** : `https://hudoc.echr.coe.int/app/conversion/docx/html/body?library=ECHR&id=[itemid]`

Remplacer `[itemid]` par l'`itemid` du résultat (ex. : `001-242789`). Retourne le HTML intégral. Fichiers potentiellement volumineux : cibler via le `prompt` de `WebFetch` (ex. : « Extraire la section EN DROIT, §§ 80-120 »).

### 1.4 — Fiches thématiques (CLIN)

Résumés analytiques du greffe. Utiles pour le cadrage thématique avant de chercher les arrêts.

**Recherche** : `doctype=CLIN` dans `query`.

### 1.5 — Avis consultatifs (Protocole n° 16)

Doctypes : `ADVPRO16OPFRE` (avis FR), `ADVPRO16OPENG` (avis EN), `ADVPRO16REFFRE` / `ADVPRO16REFENG` (refus du panel).

**Recherche** : `documentcollectionid2="ADVISORYOPINIONS"`.

### 1.6 — Champs de réponse HUDOC

| Champ | Contenu |
|---|---|
| `itemid` | Identifiant unique (ex. : `001-242789`), sert pour l'URL de lecture |
| `docname` | Intitulé de l'affaire |
| `appno` | Numéro(s) de requête, séparés par `;` |
| `kpdate` | Date (ISO 8601) |
| `respondent` | Code ISO de l'État défendeur (`FRA`, `ITA`, `TUR`...) |
| `article` | Articles invoqués, séparés par `;` (ex. : `6;6-1;8;8-1`) |
| `conclusion` | `Violation of Article X`, `No violation`, `Inadmissible`, `Struck out`... |
| `importance` | `1` = Key case, `2` = Important, `3` = Standard |
| `doctypebranch` | `GRANDCHAMBER`, `CHAMBER`, `COMMITTEE`, `ADMISSIBILITYCOM`, `OPINIONS` |
| `doctype` | `HFJUD`/`HEJUD` (arrêts), `HFDEC`/`HEDEC` (décisions), `CLIN` (fiches) |
| `languageisocode` | `FRE` ou `ENG` |
| `kpthesaurus` | Codes numériques internes, séparés par `;` (ex. : `283;577;216`). Pas de table publique, exploitables pour croisement thématique (§1.8) |
| `documentcollectionid2` | Collections : `CASELAW;JUDGMENTS;GRANDCHAMBER;FRA;FRE` etc. |
| `extractedappno` | Numéro de requête normalisé |

### 1.7 — Limites HUDOC

- Pas de recherche par ECLI : passer par numéro de requête ou texte libre.
- Résultats FR et EN mélangés : filtrer par `languageisocode` ou `doctype` (HFJUD = FR, HEJUD = EN).
- `conclusion` en français ou anglais selon la version du document.
- CLIN majoritairement en anglais.
- Texte intégral potentiellement très long (> 100 pages en GC) : cibler les sections.
- Pas de tri par importance dans `sort` : filtrer via `query`.

### 1.8 — Croisement thématique par `kpthesaurus`

Le champ `kpthesaurus` contient des codes numériques identifiant les questions juridiques traitées. Si un arrêt pertinent est identifié, ses codes servent à trouver d'autres affaires sur les mêmes questions.

**Méthode** :

1. Relever les codes `kpthesaurus` d'un arrêt de référence.
2. Retenir les codes discriminants (pas ceux communs à tous les arrêts d'un article).
3. Requête : `kpthesaurus="CODE"` dans `query`.

**Exemple** : *S. et Marper c. Royaume-Uni* (GC), codes `451;429;268;329;216;577;283`. Pour la conservation de données biométriques :

```
query=contentsitename%3AECHR%20AND%20(doctype%3DHFJUD%20OR%20doctype%3DHEJUD)%20AND%20kpthesaurus%3D%22268%22%20AND%20kpthesaurus%3D%22329%22
```

Complète la recherche en texte libre, surtout quand les termes sont trop larges ou ambigus.

### 1.9 — Guides ECHR-KS

Guides de jurisprudence rédigés par le greffe, article par article. Mis à jour semestriellement. Accessibles via `WebFetch`.

**URLs stables** :

| Guide | URL (EN) | URL (FR) |
|---|---|---|
| Article N | `https://ks.echr.coe.int/documents/d/echr-ks/guide_art_[N]_eng` | `https://ks.echr.coe.int/documents/d/echr-ks/guide_art_[N]_fre` |
| Article 6 (civil) | `guide_art_6_civil_eng` | `guide_art_6_civil_fre` |
| Article 6 (pénal) | `guide_art_6_criminal_eng` | `guide_art_6_criminal_fre` |
| Recevabilité (art. 34-35) | `https://www.echr.coe.int/documents/d/echr/Admissibility_guide_ENG` | `Admissibility_guide_FRA` |

**Thèmes transversaux** : protection des données, environnement, immigration, manifestations de masse, droits des minorités, droits des détenus, droits de l'enfant, droits LGBTI, droits des personnes handicapées, droits sociaux, terrorisme, droit UE dans la jurisprudence CEDH.

Consulter le guide de l'article en cause en Phase 1 pour les arrêts de principe, critères des tests et évolutions. Cibler la section via le `prompt` de `WebFetch`.

### 1.10 — Thésaurus HUDOC

`references/hudoc-keywords.md` : liste complète des mots-clés du thésaurus, classés article par article.

Les utiliser dans les requêtes en texte libre pour maximiser la pertinence. Consulter le fichier avant de construire une requête : naviguer à l'article en cause, reprendre les termes exacts.

**Exemples** :

| Article | Termes clés |
|---|---|
| Art. 3 | `Torture`, `Inhuman treatment`, `Degrading treatment`, `Effective investigation`, `Positive obligations`, `Expulsion` |
| Art. 6 §1 | `Access to court`, `Fair hearing`, `Equality of arms`, `Reasonable time`, `Independent tribunal`, `Impartial tribunal` |
| Art. 8 §2 | `Interference`, `Prescribed by law`, `Necessary in a democratic society`, `Foreseeability`, `Safeguards against abuse` |
| Art. 14 | `Discrimination`, `Comparable situation`, `Objective and reasonable justification` |
| Art. 1 P1 | `Possessions`, `Peaceful enjoyment of possessions`, `Deprivation of property`, `Public interest` |

---

## §2 — Méthode

### Transparence (toutes phases)

| Moment | Affichage |
|---|---|
| Avant requête | ==`Requête : [outil] — terme : "[X]" — filtres : [Y]`== |
| Après requête | `[N] résultat(s) : [liste avec nom d'affaire, date et formation]` |
| Sélection / rejet | `Retenu : [réf.] — [raison]` / `Écarté : [réf.] — [raison]` |
| Lecture | `Lecture [affaire] — section : [EN DROIT §§ X-Y]` |
| Résultat nul | `Aucun résultat — reformulation : [nouveau filtre ou terme]` |

---

### Règle anti-hallucination — CHERCHER → TROUVER → CITER

- Jamais citer un arrêt sans l'avoir trouvé par ==Legal Data Hunter ou== requête HUDOC.
- Jamais inventer un numéro de requête, une date, une formation ou un nom d'affaire.
- Jamais attribuer une portée (violation, non-violation) sans le champ `conclusion` ou les paragraphes pertinents.
- Arrêt non localisé : « non trouvé ==dans les sources== », jamais « faux ».
- Vérifier l'applicabilité temporelle au dossier.

---

### Phase 0 — Triage

Classer la question sur la forme de la demande, pas sur des connaissances de fond.

| Critère | SIMPLE | COMPLEXE |
|---|---|---|
| Questions | Une seule, bien délimitée | Plusieurs imbriquées ou à décomposer |
| Texte de référence | Article de la Convention identifié | Non identifié ou plusieurs articles en jeu |
| Dimension temporelle | Aucune (jurisprudence constante) | Évolution récente, revirement possible |
| Conflit de normes | Aucun | Articulation Convention / droit UE / droit interne |

SIMPLE si tous les critères pointent SIMPLE. Un seul COMPLEXE suffit à basculer.

**En cas de doute** — afficher et attendre confirmation :

```
Triage : je classe [SIMPLE / COMPLEXE] — [critère déterminant].
Confirmer ou corriger ?
```

---

### Phase 1 — Cadrage conventionnel

**Bypass** — sauter cette phase si :
- l'article de la Convention est évident et la question porte sur un point de jurisprudence bien identifié ;
- l'utilisateur fournit déjà les dispositions conventionnelles applicables.
Dans ces cas, passer directement à la Phase 2 en notant : `Phase 1 sautée — [raison]`.

| Triage | Phase 1 |
|---|---|
| SIMPLE | Étapes 1-2, cadrage en 2 lignes |
| COMPLEXE | Étapes 1-2-3, bloc CADRAGE formaté |

Identifier les dispositions conventionnelles avant de chercher des arrêts.

**Étape 1 — Questions**

Déterminer la ou les dispositions conventionnelles en cause :

| Droits substantiels | Article |
|---|---|
| Droit à la vie | Art. 2 |
| Interdiction de la torture | Art. 3 |
| Interdiction de l'esclavage | Art. 4 |
| Droit à la liberté et à la sûreté | Art. 5 |
| Droit à un procès équitable | Art. 6 |
| Pas de peine sans loi | Art. 7 |
| Vie privée et familiale | Art. 8 |
| Pensée, conscience, religion | Art. 9 |
| Liberté d'expression | Art. 10 |
| Réunion et association | Art. 11 |
| Droit au mariage | Art. 12 |
| Recours effectif | Art. 13 |
| Interdiction de discrimination | Art. 14 |
| Protection de la propriété | Art. 1 P1 |
| Droit à l'instruction | Art. 2 P1 |
| Élections libres | Art. 3 P1 |
| Interdiction de l'expulsion collective | Art. 4 P4 |
| Liberté de circulation | Art. 2 P4 |
| Abolition de la peine de mort | Prot. 6, Prot. 13 |

Exception : question de recevabilité (art. 35) :
- Épuisement des voies de recours internes 
- Délai de quatre mois (six mois avant février 2022, Protocole n° 15) 
- Requête non anonyme, non abusive, non essentiellement identique
- Préjudice significatif (art. 35 §3 b)

**Étape 2 — Cadrage doctrinal**

Consulter le guide ECHR-KS de l'article en cause (§1.9). Cibler la section pertinente via `WebFetch`.

Consulter `references/hudoc-keywords.md` (§1.10) pour les termes exacts du thésaurus à utiliser en Phase 2.

**Étape 3 — Affichage**

```
CADRAGE — [Objet]
QUESTION : [Formulation]
  Convention : [Article + paragraphe + volet (matériel/procédural)]
  Obligation : [Négative / Positive]
  À préciser : [Marge d'appréciation, critères du test, obligations positives]
```

Ne pas passer en Phase 2 sans au moins un article identifié.

---

### Phase 2 — Recherche

==**Chercher d'abord, lire ensuite.** Ne pas ouvrir une décision sans avoir établi sa pertinence. Legal Data Hunter retourne des extraits et métadonnées pour évaluer la pertinence par recherche sémantique. L'API HUDOC permet un ciblage par filtres structurés (article, État, importance, formation). Multiplier les requêtes et reformulations sur ces deux axes. Ne lire que les arrêts retenus, et seulement leurs sections utiles.==

**Contra reo** : chercher systématiquement les arrêts contraires. Présenter dans l'ordre hiérarchique, jamais les favorables en premier.

**Hiérarchie des formations**

1. Grande Chambre (17 juges) — arrêts de principe, font autorité
2. Chambre (7 juges) — jurisprudence courante
3. Comité (3 juges) — jurisprudence établie, sans apport nouveau
4. Juge unique — irrecevabilité manifeste, sans valeur jurisprudentielle

Un arrêt GC prime toujours un arrêt de chambre, même postérieur. Signaler tout revirement.

**Niveaux d'importance**

| Code | Signification | Usage |
|---|---|---|
| `1` | Key case | Priorité absolue |
| `2` | Important | Application ou précision d'un principe |
| `3` | Standard | Citer si 1 et 2 insuffisants |

Épuiser 1 et 2 avant de citer des arrêts d'importance 3.

**Avis consultatif** (Prot. 16) : pas de force contraignante, mais interprétation authentique.

==**Axe principal : Legal Data Hunter (recherche sémantique)**==

==Interroger avec `country: ["CoE"]`, `namespace: "case_law"`. Formuler les requêtes **en anglais**. Ancrer sur la notion juridique exacte de la Convention + article (ex. : « right to respect for private life » + « Article 8 »), puis décliner en formulations concurrentes.==

==Si numéro de requête ou ECLI connu : `resolve_reference` en premier.==

==**Complément obligatoire : API HUDOC (filtres structurés)**==

==Après Legal Data Hunter, toujours interroger l'API HUDOC avec les filtres spécifiques à la CEDH que Legal Data Hunter ne fournit pas :==

==| Filtre HUDOC | Quand l'utiliser |==
==|---|---|==
==| `article="N"` | Cibler un article précis de la Convention |==
==| `importance="1"` | Key cases seulement |==
==| `respondent="FRA"` | Restreindre à un État défendeur |==
==| `doctypebranch=GRANDCHAMBER` | Arrêts de principe uniquement |==
==| `kpthesaurus="CODE"` | Croisement thématique (§1.8) |==

==Ce contrôle par filtres structurés n'est pas optionnel : Legal Data Hunter ne filtre ni par article de la Convention, ni par importance, ni par formation.==

==**Contrôle de recency obligatoire**==

==Après les deux axes, toujours interroger Legal Data Hunter avec `date_start: "2023-01-01"` — quelle que soit la richesse des résultats précédents. La jurisprudence CEDH évolue rapidement et les arrêts récents peuvent modifier l'état du droit.==

**Bilingue** : chercher en FR et EN. Privilégier FR (HFJUD, HFDEC), basculer sur EN (HEJUD, HEDEC) si absent. Les arrêts GC existent presque toujours dans les deux langues.

**Budget de requêtes**

| Triage | Règle |
|---|---|
| SIMPLE | **3-4 requêtes** (Legal Data Hunter + HUDOC) |
| COMPLEXE | Plancher **8 requêtes minimum** (Legal Data Hunter + HUDOC) |
| Plafond | **15** — au-delà, redécomposer |

Saturation : arrêter après deux requêtes consécutives stériles (au-dessus du plancher).

==**Calibrage `top_k` (Legal Data Hunter) et `length` (HUDOC)**==

| Triage | `top_k` (LDH) | `length` (HUDOC) |
|---|---|---|
| SIMPLE | **5** | **10** |
| COMPLEXE | **10** | **20** |

**Reformulation**

| Angle | Action |
|---|---|
| Ancrage conventionnel | Article exact + paragraphe (ex. : `article="8"` + `vie privée`) |
| ==Sémantique== | ==Reformuler en anglais dans Legal Data Hunter (ex. : `margin of appreciation`, `positive obligations`, `effective remedy`)== |
| État défendeur | Resserrer (`respondent="FRA"`) puis élargir |
| Formation | `doctypebranch=GRANDCHAMBER` pour les principes |
| Temporalité | `kpdate>=` ==ou `date_start`== pour la jurisprudence récente |
| Bilingue | EN si résultats FR insuffisants |
| Importance | `"1"` → `"2"` → `"3"` |

Deux reformulations minimum (dont une en anglais) avant de signaler l'échec. ==En cas d'échec confirmé : le dire, puis produire depuis la connaissance propre en le signalant clairement.==

**CLIN** : `doctype=CLIN` + termes de recherche. Utiles pour le panorama d'une question avant les arrêts.

**Avis consultatifs** : `documentcollectionid2="ADVISORYOPINIONS"`. Premiers avis à partir de 2019. Pas de force contraignante, interprétation authentique.

---

### Phase 3 — Lecture ciblée

Lire uniquement un arrêt retenu sur ses métadonnées. Jamais de lecture intégrale sans pertinence confirmée.

==**Accès au texte** : utiliser `get_document` (Legal Data Hunter, `source: "CoE/HUDOC"`) ou l'URL HUDOC (§1.3) via `WebFetch`. Pour les fichiers volumineux, utiliser **Grep** sur le fichier sauvegardé pour localiser les passages pertinents.==

**Structure d'un arrêt CEDH**

```
1. PROCÉDURE          → ne pas citer comme solution
2. EN FAIT            → faits selon les parties et le gouvernement
3. DROIT PERTINENT    → droit interne et comparé
4. EN DROIT           → *** solution ***
   a. Recevabilité
   b. Fond
      i.  Thèses des parties
      ii. Appréciation de la Cour    → lire en priorité
5. PAR CES MOTIFS     → dispositif
   ↑ s'arrêter ici
```

Lire « Appréciation de la Cour » / « The Court's assessment » puis le dispositif.

**Marqueurs de raisonnement**

| Signal | Signification |
|---|---|
| « La Cour rappelle que... » / « The Court reiterates... » | Jurisprudence constante |
| « Il convient de rechercher si... » / « It remains to be determined... » | Début du test |
| « un juste équilibre » / « a fair balance » | Proportionnalité |
| « marge d'appréciation » / « margin of appreciation » | Latitude de l'État |
| « obligations positives » / « positive obligations » | Obligation d'agir |
| « Par ces motifs... » / « For these reasons... » | Dispositif |

**Tests par article**

| Article | Test |
|---|---|
| Art. 3 | Seuil de gravité minimale + circonstances de l'espèce |
| Art. 5 | Légalité + proportionnalité + voies de recours |
| Art. 6 §1 | Applicabilité + équité globale |
| Art. 8-11 | Ingérence → prévue par la loi → but légitime → nécessaire dans une société démocratique |
| Art. 14 + autre art. | Situation comparable → différence de traitement → justification objective et raisonnable |
| Art. 1 P1 | Ingérence → légalité → utilité publique → proportionnalité |

Ne jamais qualifier le test sans vérifier la formule dans l'arrêt.

---

## §3 — Format de sortie

Résumé court dans le chat + numéro de requête + lien HUDOC. Pas de fichier Markdown.

**Lien** : `https://hudoc.echr.coe.int/fre?i=[itemid]` (FR) ou `.../eng?i=[itemid]` (EN).

**Citation**

```
CEDH, [formation], [date], [nom usuel], req. n° [numéro], [§ N si point précis].
Ex. : CEDH, gde ch., 4 déc. 2008, S. et Marper c. Royaume-Uni, req. nos 30562/04 et 30566/04, § 101.
Ex. : CEDH, ch., 25 juin 2020, Moustahi c. France, req. n° 9347/14, § 128.
Ex. (avis) : CEDH, gde ch., avis consultatif, 10 avr. 2019, req. n° P16-2018-001.
```

**Statut épistémique (obligatoire)**

- **Constante** : jurisprudence établie de la Grande Chambre
- **Divisée** : divergences entre chambres, ou opinion dissidente significative
- **Incertaine** : question non tranchée par la GC, évolution possible
