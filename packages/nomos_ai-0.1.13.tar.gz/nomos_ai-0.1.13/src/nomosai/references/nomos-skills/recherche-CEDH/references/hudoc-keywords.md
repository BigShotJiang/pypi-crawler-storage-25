# Thésaurus HUDOC — Mots-clés par article

Termes exacts du thésaurus ECHR. Les utiliser tels quels dans les requêtes HUDOC en texte libre.

---

## Table des matières

1. [Convention — Droits substantiels (art. 1-18)](#convention--droits-substantiels)
2. [Convention — Dispositions procédurales (art. 33-59)](#convention--dispositions-procédurales)
3. [Protocole n° 1](#protocole-n-1)
4. [Protocole n° 4](#protocole-n-4)
5. [Protocole n° 6](#protocole-n-6)
6. [Protocole n° 7](#protocole-n-7)
7. [Protocoles n° 12 et 13](#protocoles-n-12-et-13)
8. [Mots-clés transversaux](#mots-clés-transversaux)

---

## Convention — Droits substantiels

### Art. 1 — Obligation to respect human rights

`High Contracting Party` · `Responsibility of States` · `Jurisdiction of States`

### Art. 2 — Right to life

**Général** : `Expulsion` · `Extradition` · `Positive obligations`

**§1** : `Life` · `Death penalty` · `Prescribed by law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Competent court` · `Effective investigation`

**§2** : `Use of force` · `Absolutely necessary` · `Defence from unlawful violence` · `Effect lawful arrest` · `Prevent escape` · `Quell riot or insurrection`

### Art. 3 — Prohibition of torture

`Torture` · `Inhuman treatment` · `Inhuman punishment` · `Degrading treatment` · `Degrading punishment` · `Effective investigation` · `Expulsion` · `Extradition` · `Positive obligations`

### Art. 4 — Prohibition of slavery and forced labour

**Général** : `Effective investigation` · `Positive obligations`

**§1** : `Slavery` · `Servitude` · `Trafficking in human beings`

**§2** : `Forced labour` · `Compulsory labour`

**§3** : `Work required of detainees` · `Work required to be done during conditional release` · `Service of military character` · `Alternative civil service` · `Service exacted in case of emergency` · `Service exacted in case of calamity` · `Normal civic obligations`

### Art. 5 — Right to liberty and security

**§1** : `Liberty of person` · `Security of person` · `Deprivation of liberty` · `Procedure prescribed by law` · `Lawful arrest or detention`
- *(a)* `Conviction` · `After conviction` · `Competent court`
- *(b)* `Lawful order of a court` · `Non-compliance with court order` · `Secure fulfilment of obligation prescribed by law`
- *(c)* `Bringing before competent legal authority` · `Criminal offence` · `Reasonable suspicion` · `Reasonably necessary to prevent offence` · `Reasonably necessary to prevent fleeing`
- *(d)* `Minors` · `Educational supervision` · `Bringing before competent authority`
- *(e)* `Prevention of spreading of infectious diseases` · `Persons of unsound mind` · `Alcoholics` · `Drug addicts` · `Vagrants`
- *(f)* `Prevent unauthorised entry into country` · `Expulsion` · `Extradition`

**§2** : `Prompt information` · `Information in language understood` · `Information on reasons for arrest` · `Information on charge`

**§3** : `Judge or other officer exercising judicial power` · `Brought promptly before judge or other officer` · `Trial within a reasonable time` · `Release pending trial` · `Length of pre-trial detention` · `Reasonableness of pre-trial detention` · `Conditional release` · `Guarantees to appear for trial`

**§4** : `Review of lawfulness of detention` · `Take proceedings` · `Review by a court` · `Speediness of review` · `Procedural guarantees of review` · `Order release`

**§5** : `Compensation`

### Art. 6 — Right to a fair trial

**Général** : `Civil proceedings` · `Criminal proceedings` · `Administrative proceedings` · `Constitutional proceedings` · `Disciplinary proceedings` · `Enforcement proceedings` · `Expulsion` · `Extradition`

**§1** : `Civil rights and obligations` · `Determination` · `Dispute` · `Criminal charge` · `Access to court` · `Fair hearing` · `Adversarial trial` · `Equality of arms` · `Legal aid` · `Public hearing` · `Oral hearing` · `Exclusion of press` · `Exclusion of public` · `Necessary in a democratic society` · `Protection of morals` · `Protection of public order` · `National security` · `Protection of juveniles` · `Protection of private life of the parties` · `Extent strictly necessary` · `Prejudice interests of justice` · `Reasonable time` · `Independent tribunal` · `Impartial tribunal` · `Tribunal established by law` · `Public judgment`

**§2** : `Charged with a criminal offence` · `Presumption of innocence` · `Proved guilty according to law`

**§3** : `Charged with a criminal offence` · `Rights of defence`
- *(a)* `Information on nature and cause of accusation` · `Prompt information` · `Information in language understood` · `Information in detail`
- *(b)* `Preparation of defence` · `Adequate time` · `Adequate facilities` · `Access to relevant files`
- *(c)* `Defence in person` · `Defence through legal assistance` · `Legal assistance of own choosing` · `Insufficient means` · `Free legal assistance` · `Required by interests of justice`
- *(d)* `Witnesses` · `Examination of witnesses` · `Obtain attendance of witnesses` · `Same conditions`
- *(e)* `Free assistance of interpreter`

### Art. 7 — No punishment without law

**§1** : `Nullum crimen sine lege` · `Nulla poena sine lege` · `Conviction` · `Heavier penalty` · `Criminal offence` · `Time when the act or omission committed` · `Retroactivity`

**§2** : `Criminal offence` · `General principles of law recognised by civilised nations`

### Art. 8 — Right to respect for private and family life

**Général** : `Expulsion` · `Extradition` · `Positive obligations`

**§1** : `Respect for private life` · `Respect for family life` · `Respect for home` · `Respect for correspondence`

**§2** : `Public authority` · `Interference` · `Prescribed by law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Necessary in a democratic society` · `National security` · `Public safety` · `Economic well-being of the country` · `Prevention of disorder` · `Prevention of crime` · `Protection of health` · `Protection of morals` · `Protection of the rights and freedoms of others`

### Art. 9 — Freedom of thought, conscience and religion

**Général** : `Positive obligations`

**§1** : `Freedom of thought` · `Freedom of conscience` · `Freedom of religion` · `Change religion or belief` · `Manifest religion or belief` · `Worship` · `Teaching` · `Practice` · `Observance`

**§2** : `Interference` · `Prescribed by law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Necessary in a democratic society` · `Public safety` · `Protection of public order` · `Protection of health` · `Protection of morals` · `Protection of the rights and freedoms of others`

### Art. 10 — Freedom of expression

**Général** : `Positive obligations`

**§1** : `Freedom of expression` · `Freedom to hold opinions` · `Freedom to receive information` · `Freedom to impart information` · `Freedom to receive ideas` · `Freedom to impart ideas` · `Interference of public authority` · `Regardless of frontiers` · `Licensing of broadcasting enterprises`

**§2** : `Duties and responsibilities` · `Interference` · `Prescribed by law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Necessary in a democratic society` · `National security` · `Territorial integrity` · `Public safety` · `Prevention of disorder` · `Prevention of crime` · `Protection of health` · `Protection of morals` · `Protection of the rights of others` · `Protection of the reputation of others` · `Preventing the disclosure of information received in confidence` · `Maintaining the authority and impartiality of the judiciary`

### Art. 11 — Freedom of assembly and association

**§1** : `Freedom of peaceful assembly` · `Freedom of association` · `Form and join trade unions` · `Not join trade unions` · `Interests of members`

**§2** : `Interference` · `Prescribed by law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Necessary in a democratic society` · `National security` · `Public safety` · `Prevention of disorder` · `Prevention of crime` · `Protection of health` · `Protection of morals` · `Protection of the rights and freedoms of others` · `Members of armed forces` · `Members of police` · `Members of administration`

### Art. 12 — Right to marry

`Men and women` · `Marriageable age` · `Marry` · `Found a family` · `National law`

### Art. 13 — Right to an effective remedy

`Effective remedy` · `National authority` · `Arguable claim`

### Art. 14 — Prohibition of discrimination

`Discrimination` · `Sex` · `Race` · `Colour` · `Language` · `Religion` · `Political or other opinion` · `National origin` · `Social origin` · `National minority` · `Property` · `Birth` · `Other status` · `Comparable situation` · `Objective and reasonable justification`

### Art. 15 — Derogation in time of emergency

**§1** : `War` · `Public emergency` · `Threat to the life of the nation` · `Derogation` · `Extent strictly required by situation` · `International obligations`

**§3** : `Notification of a derogation`

### Art. 16 — Restrictions on political activity of aliens

`Restrictions on political activity of aliens`

### Art. 17 — Prohibition of abuse of rights

`Destruction of rights and freedoms` · `Excessive limitations on rights and freedoms`

### Art. 18 — Limitation on use of restrictions on rights

`Restrictions for unauthorised purposes`

---

## Convention — Dispositions procédurales

### Art. 19 — Establishment of the Court

`High Contracting Party` · `Engagements undertaken by Parties` · `Ensure observance of engagements`

### Art. 33 — Inter-State cases

`Inter-State application` · `Applicant State Party` · `Defendant State Party` · `Jurisdiction of the Court`

### Art. 34 — Individual applications

`Petition` · `Defendant State Party` · `Individual` · `Non-governmental organisation` · `Group of individuals` · `Victim` · `Actio popularis` · `Locus standi` · `Hinder the exercise of the right of application`

### Art. 35 — Admissibility criteria

**§1** : `Exhaustion of domestic remedies` · `Exemption from exhaustion of domestic remedies` · `Effective domestic remedy` · `Four-month period (former six-month)` · `Final domestic decision` · `Continuing situation`

**§2** :
- *(a)* `Anonymous application`
- *(b)* `Matter already examined by the Court` · `Matter already submitted to another international procedure` · `Relevant new information`

**§3** :
- *(a)* `Ratione temporis` · `Continuing situation` · `Ratione loci` · `Ratione materiae` · `Ratione personae` · `Manifestly ill-founded` · `Abuse of the right of application`
- *(b)* `No significant disadvantage` · `Continued examination not justified` · `Case duly considered by a domestic tribunal`

**§4** : `Rejection of application at any stage of the proceedings`

### Art. 37 — Striking out applications

**§1** : `Striking out applications` · `Respect for human rights`
- *(a)* `Absence of intention to pursue application`
- *(b)* `Matter resolved`
- *(c)* `Continued examination not justified`

**§2** : `Restore to list`

### Art. 38 — Examination of the case

`Examination of the case` · `Obligation to furnish all necessary facilities`

### Art. 39 — Friendly settlements

`Friendly settlement`

### Art. 41 — Just satisfaction

`Just satisfaction` · `Pecuniary damage` · `Non-pecuniary damage` · `Costs and expenses` · `Insufficient reparation under national law` · `Injured party` · `Jurisdiction to give orders or grant injunctions` · `Experts' costs` · `Default interest` · `Causal link` · `Overall assessment` · `Freedom from attachment`

### Art. 46 — Binding force and execution of judgments

**Général** : `Pilot judgment` · `Systemic problem` · `General measures (pilot judgment)` · `Individual measures (pilot judgment)`

**§1** : `Abide by judgment` · `Parties to case`

**§2** : `Execution of judgment` · `Just satisfaction` · `Default interest` · `Freedom from attachment` · `Individual measures` · `Reopening of proceedings` · `Pardon` · `Striking out of criminal records` · `General measures` · `Legislative amendments` · `Changes of regulations` · `Changes in case-law`

**§4** : `Infringement proceedings`

### Art. 47-48 — Advisory opinions

`Request by the Committee of Ministers` · `Advisory opinions` · `Advisory jurisdiction of the Court`

### Art. 52 — Inquiries by the Secretary General

`Request by the Secretary General` · `Report to the Secretary General`

### Art. 53 — Rights otherwise guaranteed

`Rights otherwise guaranteed`

### Art. 55 — Renunciation of other means

`Renunciation of other means of settlement`

### Art. 56 — Territorial application

`Territorial application` · `Local requirements`

### Art. 57 — Reservations

`Reservations` · `Particular provision of the Convention` · `Law then in force` · `Prohibition of reservations of a general character` · `Brief statement of the law` · `Interpretative declaration`

### Art. 58 — Denunciation

`Six months' notice` · `Notification of denunciation` · `Cessation of membership of the Council of Europe`

---

## Protocole n° 1

### Art. 1 P1 — Protection of property

**Général** : `Positive obligations`

**§1** : `Possessions` · `Peaceful enjoyment of possessions` · `Interference` · `Deprivation of property` · `Public interest` · `Prescribed by law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `General principles of international law`

**§2** : `Control of the use of property` · `General interest` · `Secure the payment of taxes` · `Secure the payment of contributions or penalties`

### Art. 2 P1 — Right to education

`Right to education` · `Respect for parents' religious convictions` · `Respect for parents' philosophical convictions`

### Art. 3 P1 — Right to free elections

`Right to free elections` · `Periodic elections` · `Elections by secret ballot` · `Free expression of the opinion of the people` · `Choice of the legislature` · `Vote` · `Stand for election`

---

## Protocole n° 4

### Art. 1 P4 — Prohibition of imprisonment for debt

`Prohibition of imprisonment for debt` · `Deprivation of liberty`

### Art. 2 P4 — Freedom of movement

**§1** : `Freedom of movement` · `Freedom to choose residence` · `Lawfully within the territory`

**§2** : `Freedom to leave a country`

**§3** : `Interference` · `In accordance with law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Necessary in a democratic society` · `National security` · `Public safety` · `Protection of health` · `Protection of morals` · `Protection of rights and freedoms of others` · `Protection of public order` · `Prevention of crime` · `Restrictions in particular areas` · `Public interest`

### Art. 3 P4 — Prohibition of expulsion of nationals

**§1** : `Prohibition of expulsion of a national` · `Prohibition of collective expulsion of nationals`

**§2** : `Enter own country`

### Art. 4 P4 — Prohibition of collective expulsion of aliens

`Prohibition of collective expulsion of aliens`

---

## Protocole n° 6

### Art. 1 P6 — Abolition of the death penalty

`Abolition of the death penalty`

### Art. 2 P6 — Death penalty in time of war

`Death penalty in time of war` · `War` · `Imminent threat of war` · `Prescribed by law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Communication of the law to the Secretary General`

---

## Protocole n° 7

### Art. 1 P7 — Procedural safeguards relating to expulsion of aliens

**§1** : `Expulsion of an alien` · `Lawfully resident` · `In accordance with law` · `Accessibility` · `Foreseeability` · `Safeguards against abuse` · `Contest expulsion` · `Review of expulsion decision` · `Competent authority` · `Represented`

**§2** : `Expulsion before exercising procedural rights` · `Necessary in a democratic society` · `Protection of public order` · `National security`

### Art. 2 P7 — Right of appeal in criminal matters

`Conviction` · `Criminal offence` · `Competent court` · `Review of conviction` · `Review of sentence` · `Higher tribunal` · `National law` · `Minor offences` · `Trial at first instance by the highest tribunal` · `Conviction following appeal against acquittal`

### Art. 3 P7 — Compensation for wrongful conviction

`Compensation` · `Miscarriage of justice` · `Conviction` · `Criminal offence` · `New or newly discovered facts` · `National law` · `Non-disclosure of fact by convicted person`

### Art. 4 P7 — Right not to be tried or punished twice (ne bis in idem)

`Right not to be tried or punished twice` · `Criminal offence` · `Conviction` · `Acquittal` · `Jurisdiction of the same State` · `Reopening of case` · `New or newly discovered facts` · `Fundamental defect in proceedings`

### Art. 5 P7 — Equality between spouses

`Equality between spouses` · `Spouses` · `Relations with children` · `As to marriage` · `During marriage` · `In the event of dissolution of marriage` · `Measures necessary in the interests of children`

---

## Protocoles n° 12 et 13

### Art. 1 P12 — General prohibition of discrimination

`General prohibition of discrimination`

### Art. 1 P13 — Abolition of death penalty in all circumstances

`Abolition of the death penalty in all circumstances`

---

## Mots-clés transversaux

Termes utilisables avec n'importe quel article :

`Accessibility` · `Foreseeability` · `Jurisdiction of the Court` · `Margin of appreciation` · `Non-derogable rights and freedoms` · `Positive obligations` · `Proportionality` · `Safeguards against abuse`
