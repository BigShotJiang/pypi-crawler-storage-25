---
name: redaction-MD-cassation
description: Rédaction d'un mémoire en défense devant la Cour de cassation (toutes chambres). Déclencher dès que l'utilisateur évoque : répondre à un pourvoi, rédiger un mémoire en défense, répondre à un moyen de cassation, contrer une branche du moyen, défendre un arrêt devant la Cour de cassation. 
---

# Mémoire en défense — Cour de cassation

Skill autonome pour la défense d'un arrêt devant la Cour de cassation, toutes chambres.  
**Mode par défaut : collaboratif.** Présenter l'analyse avant de rédiger. Ne jamais rédiger sans validation.

---

## §0 — Environnement

| Mode | Détection | Sortie |
|---|---|---|
| **CLAUDE_CODE** (VS Code) | Outil Bash disponible | Édition directe du fichier `.md` |
| **COWORK** | Dossier projet Cowork | Fichier `.md` ou `.docx` dans le dossier de travail |
| **CLAUDE_AI** | Ni Bash ni Cowork | Réponse conversationnelle structurée, branche par branche |

En mode **CLAUDE_CODE** : lire le fichier avant toute modification.

---

## §1 — Contexte du dossier (workflow)

Le workflow du cabinet organise les fichiers en trois niveaux. Lire dans cet ordre pour obtenir le contexte le plus rapidement possible — ne pas scanner l'ensemble du dossier sans raison.

### Étape 1 — Fichiers de contexte (lire en priorité)

| Fichier | Contenu | Où le trouver |
|---|---|---|
| Instructions permanentes du dossier | Stratégie, notes, points de vigilance | Fichier `.md` à la racine du dossier (`CLAUDE.md` propre au dossier) |
| Contexte juridique du dossier | Parties, juridiction, pièces disponibles, axes déjà validés | Fichier `[nom-dossier].md`|
| Faits pertinents extraits | Chronologie et faits-clés déjà sélectionnés | `livrables/faits-pertinents.md` si disponible (produit par le skill `extraction-faits`) |

Ces trois fichiers suffisent pour lancer le playbook. L'utilisateur guide si un approfondissement factuel est nécessaire.

### Étape 2 — Fichiers procéduraux (lecture chirurgicale)

Ne pas lire les documents entiers. Cibler les passages pertinents pour la branche traitée.

| Fichier | Ce qu'il faut lire |
|---|---|
| Mémoire ampliatif adverse (MA) | Le passage relatif à la branche traitée uniquement |
| Arrêt attaqué | Le passage correspondant à la question soulevée par la branche |
| Conclusions d'appel | **Conditionnel** : lire uniquement si la question était déjà traitée devant les juges du fond — ne pas supposer que c'est le cas |
| Draft existant du mémoire en défense | Lire l'intégralité du draft avant toute intervention |

**Règle : si un draft existe, partir de ce qui est déjà rédigé.** Ne jamais rédiger de zéro une branche déjà traitée. Identifier ce qui est solide, ce qui manque, ce qui doit être restructuré, et intervenir chirurgicalement. La tâche par défaut est d'améliorer, pas de remplacer.

L'utilisateur guide si un approfondissement factuel ou une lecture plus large est nécessaire.

---

## §2 — Playbook cassation

Exécuter avant toute rédaction. Présenter le résultat à l'utilisateur et **attendre sa validation** avant de passer à la rédaction.

### 2.1 — Lire le moyen adverse branche par branche

Pour chaque branche, qualifier le grief :

| Grief | Signal dans le MA |
réponse attendu
| Violation de loi | « a violé l'article X » | Démontrer que la règle de droit a été comprise et respectée par le juge
| Manque de base légale | « n'a pas donné de base légale », « n'a pas légalement justifié » | Démontrer que les éléments de fait forment une base légale suffisante pour le contrôle de cassation
| Défaut de réponse à conclusions | Moyen non examiné par la cour d'appel | Démontrer que la cour d'appel a répondu aux conclusions, même implicitement

### 2.2 — Identifier un contre-argumentaire

Ne pas se limiter au mal-fondé du moyen ni se laisser enfermer sur une défense point par point. 

D'autres défenses possibles :

- **Appréciation souveraine** : la notion juridique sur laquelle se fonde le moyen n'est pas contrôlée par la Cour de cassation
- **Moyen de faits** : Un moyen de fait fondé sur un élément non prouvé en appel n'est pas recevable.
- **Moyen inopérant** : si la branche attaque un motif de l'arrêt surabondant, le moyen est inopérant.
- **Irrecevabilité du moyen nouveau**: Le MA ne peut pas plus modifier l'objet de la demande que son fondement juridique. Si la branche se fonde sur un grief qui ne correspond pas à ce qui a été traité devant le juge du fond, le moyen est irrecevable. Comparer le MA avec les conclusions d'appel adverses pour vérifier si le moyen est nouveau.
- **Moyen fait dire à l'arrêt ce qu'il ne dit pas** : si la branche se fonde sur une interprétation erronée de l'arrêt, il faut démontrer que l'arrêt ne dit pas ce que le MA prétend qu'il dit.
- **Distinguishing** : lorsque le MA cite une jurisprudence qui semble adverse, vérifier la décision sur openLegi. Démontrer que les faits de l'espèce diffèrent suffisamment de ceux de la décision citée pour que la solution ne soit pas transposable. Identifier le fait ou la circonstance décisive qui distingue les deux cas. Les comparer aux faits du dossier en cours. Ne pas contester la règle posée par l'arrêt adverse : concéder la règle, contester son applicabilité aux faits.Relever explicitement les différences permettant de distinguer les espèces

### 2.4 — Format de présentation à l'utilisateur (mode collaboratif)

Pour chaque branche, présenter :
- Nature du grief (qualification)
- Constats souverains utilisables comme bouclier
- Axe(s) de réponse envisagés
- Risques tactiques identifiés

Formuler clairement les choix à faire et les risques. Attendre la validation avant toute rédaction.

### 2.5 — Mise à jour des notes stratégiques

Après validation, mettre à jour la section **Notes stratégiques** du fichier `[nom-dossier].md` :
- Axes de défense retenus par branche (qualification du grief, angle choisi)
- Défenses écartées : raison (risque tactique, inopérance, absence de fondement)
- Constats souverains identifiés comme boucliers
- Points à approfondir (jurisprudence à rechercher, faits à confirmer)


---

## §3 — Sources et anti-hallucination

**Règle absolue : ne citer aucune décision sans l'avoir trouvée par recherche préalable.**

Ordre impératif : **Chercher → Trouver → Citer**. Jamais l'inverse.

**Pour toute recherche jurisprudentielle**, invoquer le skill **`recherche-Ccass_droit privé`**. Ce skill gère la recherche sur OpenLegi, la lecture des arrêts, la distinction publication B/D, et le contrôle anti-hallucination.

Sources admises dans le mémoire :
- Textes normatifs lus et vérifiés via OpenLegi (articles des codes en vigueur à la date des faits)
- Décisions trouvées et lues via le skill `recherche-Ccass_droit privé`
- Citations textuelles de l'arrêt attaqué et du MA adverse (fichiers du dossier)
- Doctrine identifiée par recherche effective (jamais de mémoire)

Si une recherche ne retourne rien : le dire. Zéro référence vaut mieux qu'une référence inventée.

---

## §4 — Rédaction

### Structure du raisonnement — majeure / mineure

**Règle absolue : toujours commencer par la règle de droit (majeure), puis vérifier qu'elle a été respectée en l'espèce (mineure).**

- La majeure n'a pas besoin d'être longue : une phrase ou deux suffisent si la règle est bien établie.
- On peut alterner majeure et mineure au sein d'un même développement, mais le premier mouvement est toujours la règle.
- Ne jamais partir des faits pour remonter vers la règle — c'est l'inverse du syllogisme juridique et ça affaiblit le raisonnement.

### Style

- **Densité** : pas de rappel factuel inutile, pas de digression. Le mémoire en défense est court et percutant.
- **Citations** : guillemets français « … », référence précise (arrêt, p. X ou § Y). Citer les constats souverains textuellement.
- **Clôture de chaque branche** : « La branche doit être rejetée. »
- **Clôture globale** : « Le moyen sera rejeté, comme le sera le pourvoi. »

---

## §5 — Format de sortie

**CLAUDE_CODE** : édition directe du fichier `.md` du mémoire en cours. Lire le fichier entier avant toute modification. Ne pas créer de nouveau fichier si un draft existe.

**COWORK** : créer ou compléter un fichier dans le dossier du dossier. Convention : `[AAAA-MM-JJ]-memoire-defense-[nom].md`.

**CLAUDE_AI** : réponse structurée dans le chat, une branche à la fois. Préciser que l'export vers Word est conseillé avant dépôt.
