﻿---
name: recherche-Ccass_droit privé
version: 1.8
date: 2026-05-06
---

# Recherche et analyse — Cour de cassation

Recherche et lecture de décisions de la Cour de cassation à l'appui d'un dossier en cours.

---

## Principes transversaux

**Transparence** — narrer chaque étape en direct :

| Moment | Format |
|---|---|
| Avant requête | `Requête : [outil] — terme : "[X]" — filtres : [Y]` |
| Après requête | `[N] résultat(s) : [références avec date et formation]` |
| Sélection | `Retenu / Écarté : [référence] — [raison]` |
| Lecture | `Lecture section "[Réponse de la Cour]" — [date]` |
| Résultat nul | `Aucun résultat — reformulation : [nouveau terme]` |

**Anti-hallucination — CHERCHER → TROUVER → CITER**

- Ne jamais citer, dater, numéroter ou qualifier une décision de mémoire.
- Une décision non localisée est « non trouvée », jamais « fausse ».
- Vérifier l'applicabilité temporelle au dossier.

---

## Phase 0 — Triage

Classer la question sur la forme de la demande, pas sur des connaissances de fond.

| Critère | SIMPLE | COMPLEXE |
|---|---|---|
| Questions | Une seule, bien délimitée | Plusieurs imbriquées ou à décomposer |
| Texte de référence | Nommé ou identifiable à la lecture | Non identifié, multiple ou incertain |
| Dimension temporelle | Aucune (droit positif) | Réforme, évolution, transition |
| Conflit de normes | Aucun | Textes concurrents, articulation à trancher |

SIMPLE si tous les critères pointent SIMPLE. Un seul COMPLEXE suffit à basculer.

**En cas de doute** — afficher et attendre confirmation :

```
Triage : je classe [SIMPLE / COMPLEXE] — [critère déterminant].
Confirmer ou corriger ?
```

---

## Phase 1 — Cadrage juridique

Comprendre la matière avant de chercher des décisions.

==**Bypass** — sauter cette phase si :==
==- la question porte sur une question purement jurisprudentielle (ex. contrôle de la cour de cassation) dont le régime ne découle pas d'un texte précis ;==
==- l'utilisateur fournit déjà les textes applicables dans sa demande.==
==Dans ces cas, passer directement à la Phase 2 en notant : `Phase 1 sautée — [raison]`.==

| Triage | Phase 1 | Budget panoramas |
|---|---|---|
| SIMPLE | Étapes 1-2, cadrage en 2 lignes | 2-3 panoramas |
| COMPLEXE | Étapes 1-2-3, bloc CADRAGE formaté | 10 panoramas min. |

**Étape 1** — Identifier 1 à 3 questions juridiques précises. Décomposer si la demande est trop large.

**Étape 2** — Pour chaque question : rechercher les articles applicables via `OpenLegi:rechercher_code` (texte exact, numéro, vigueur), vérifier le statut temporel, identifier les conditions légales que la jurisprudence devra préciser. Au moins un texte normatif identifié avant de passer à la Phase 2.

**Étape 3 (COMPLEXE uniquement)**

```
CADRAGE — [Objet]
QUESTION : [Formulation précise]
  Textes : [Articles + code + vigueur]
  Conditions légales : [Éléments constitutifs]
  À préciser par la jurisprudence : [Zone d'incertitude]
```

---

## Phase 2 — Recherche

Répondre uniquement à la question posée. Réponse courte si la question est courte.

**Contra reo** — Chercher objectivement sans aller dans les favorables. Présenter dans l'ordre hiérarchique, jamais les favorables en premier.

**Hiérarchie des formations** : Ass. plén. > Ch. mixte > plénière de chambre > ordinaire. Un arrêt Ass. plén. prime toujours sauf revirement explicite.

**Publiés d'abord** — épuiser les arrêts publiés (P/B) avant les non publiés (F-D, FS-D). Basculer sur les non publiés uniquement si les publiés ne répondent pas.

**Séquence de recherche**

1. Construire les termes depuis les questions et conditions identifiées en Phase 1.
2. ==Première requête : `panorama: true` par défaut. Sauter le panorama si la question est ciblée (ex. « quel contrôle sur X ? ») et passer directement à une requête filtrée.==
3. Puis `publication_bulletin: true` + terme unique discriminant. Élargir sans filtre si volume insuffisant.
4. Outil : `OpenLegi:rechercher_jurisprudence_judiciaire`, `juridiction_judiciaire: ["Cour de cassation"]`, `sort: DATE_DESC`.
5. Par numéro de pourvoi : `champ: "NUM_AFFAIRE"`, `type_recherche: "EXACTE"`. Si introuvable : web_search Judilibre.

**Budget panoramas**

| Triage | Règle |
|---|---|
| SIMPLE | **2-3 panoramas** |
| COMPLEXE | Plancher **10 panoramas min.** |
| Plafond | **20** — au-delà, redécomposer |

==**Calibrage `page_size`**==

==| Triage | `page_size` |==
==|---|---|==
==| SIMPLE | **3 à 5** |==
==| COMPLEXE | **10** (défaut OpenLegi) |==

**Sortie anticipée** : arrêt publié de formation élevée (Ass. plén., Ch. mixte, plénière) qui répond à la question → passer à la lecture, ne pas épuiser le budget.

**Saturation** : sinon, continuer tant qu'une requête remonte un arrêt non vu. Arrêter après deux requêtes consécutives stériles.

**Matrice de recherche** — toujours décliner plusieurs formules en parallèle :

| Angle | Description |
|---|---|
| **Ancrage impératif** | Notion exacte du texte + numéro d'article. Toujours en premier. |
| **Calibration lexicale** | Formules concurrentes pour la même notion. Adapter selon les résultats. |
| **Évolution terminologique** | Chercher les deux terminologies quand un concept a changé de nom (ex. : « bon père de famille » / « personne raisonnable ») |

==**Rebond PJCJ** — Plan de classement de la jurisprudence judiciaire comme levier de recherche :==

==1. **Repérer la cote** : après le premier panorama, relever le champ « Plan de classement » des arrêts pertinents (ex. : `RESPONSABILITE CONTRACTUELLE - Applications diverses - Expert`).==
==2. **Requête ciblée** : rechercher la rubrique PJCJ (ou une sous-rubrique) dans `champ: "ABSTRATS"` avec `type_recherche: "EXACTE"`.==
==3. **Affiner** : si la rubrique de niveau 1 donne trop de résultats (>50), descendre à la sous-rubrique. Si elle en donne trop peu, remonter d'un niveau.==
==4. **Quand l'utiliser** : dès qu'un panorama retourne des arrêts pertinents avec un plan de classement, et que la question appelle un état de la jurisprudence exhaustif (recherche COMPLEXE).==

**Après panorama — mode collaboratif**

- Résumé répond directement → citer, fin.
- Aucun résumé ne répond → présenter les décisions et pistes, **attendre validation** avant lecture intégrale.

**Reformulation** : si >500 résultats, reformuler avant de paginer. Ne jamais dépasser la page 2 sans reformulation.

**Résultats nuls** : deux reformulations minimum avant de signaler l'échec. En cas d'échec confirmé, répondre depuis la connaissance propre, clairement signalée comme telle.

---

## ==Phase 3== — Lecture

**Plan de lecture obligatoire**

```
1. Faits et procédure       → contexte, ne pas citer comme solution
2. Énoncé du moyen           → argument de la PARTIE, pas la solution
3. Réponse de la Cour        → position de la COUR, c'est la solution
4. Dispositif                → CASSE ET ANNULE / REJETTE
   ↑ S'ARRÊTER ICI ↑
5. MOYENS ANNEXÉS            → NE PAS LIRE
```

**Ciblage** : lire uniquement « Réponse de la Cour » (ou « Mais attendu que ») + dispositif. S'arrêter au dispositif. Si pertinent, lire les moyens auxquels la Cour répond et la position de la cour d'appel, pas les moyens annexés.

**Marqueurs**

| Section | Marqueurs |
|---|---|
| Énoncé du moyen | « il est fait grief… », « reproche à l'arrêt… », « soutient que… » |
| Réponse (enrichi) | Heading « Réponse de la Cour » ou §§ numérotés |
| Réponse (ancien) | « Mais attendu que… » (rejet) / « Vu l'art. X… ; Attendu que… » (cassation) |
| Dispositif | « Par ces motifs… CASSE ET ANNULE » / « REJETTE le pourvoi » |

**Niveaux de contrôle** — ne qualifier qu'après vérification de la formule dans l'arrêt :

| Signal | Niveau |
|---|---|
| « souverainement retenu / apprécié » | Appréciation souveraine |
| « a pu retenir / déduire » | Contrôle léger |
| « exactement retenu », « à bon droit » | Contrôle lourd |
| « n'a pas donné de base légale » | Manque de base légale |
| « n'a pas satisfait aux exigences de l'art. 455 CPC » | Contrôle disciplinaire |

**Portée** : arrêt de principe (publié B, chapeau général, formation élevée) vs décision d'espèce (solution liée aux faits). Publication : **P** = Bulletin, **B** = après le 15 juin 2021.

==**Plan de classement (PJCJ)** : relever systématiquement la rubrique « Plan de classement » quand elle figure dans les métadonnées. Réutilisable pour un rebond PJCJ (cf. Phase 2).==

---

## Format de sortie

Résumé court dans le chat + numéro de pourvoi + lien Légifrance. Pas de fichier. Pas d'argumentation ni de cours.

**Statut épistémique obligatoire** : **Constante** (solution uniforme) · **Divisée** (courants contradictoires, les exposer) · **Incertaine** (décisions insuffisantes ou disparates).