---
name: recherche-CE_droit-public
version: 1.2
date: 2026-05-14
description: "Recherche et analyse de jurisprudence du Conseil d'État. Utilise Open Legi MCP (Légifrance) et ArianeWeb API (conseil-etat.fr). Déclencher pour toute question de droit public impliquant le Conseil d'État : recours pour excès de pouvoir, pourvoi en cassation administratif, référé suspension ou liberté, avis contentieux, responsabilité de la puissance publique, contrats administratifs, fonction publique, urbanisme, ou toute recherche par numéro de requête CE."
---

# Recherche et analyse — Conseil d'État

---

## §1 — Sources

### 1.1 — Open Legi MCP (source primaire)

`rechercher_jurisprudence_administrative`, `sort: DATE_DESC`. Retourne CETATEXT, numéro de requête, formation, date, solution, résumé, plan de classement, lien Légifrance. Utiliser `panorama: true` pour toute première requête. **Attention** : l'outil retourne des résultats CE, CAA et TA mélangés, vérifier systématiquement le champ `Juridiction` et écarter tout résultat qui n'est pas `Conseil d'État`.

### 1.2 — ArianeWeb (source complémentaire)

Accès via les outils MCP `nomos-ai` : `search_arianeweb` (recherche) et `get_conclusion` (texte intégral des conclusions).

**`search_arianeweb`** — paramètres :

| Paramètre | Rôle | Valeurs / défaut |
|---|---|---|
| `query` | Recherche plein texte | Termes libres |
| `numero` | N° de requête exact | Ex. : `489441` |
| `fund` | Fond de jurisprudence | `AW_DCE` (CE, défaut) · `AW_DCA` (CAA) · `AW_DTC` (Conflits) · `AW_CRP` (conclusions) |
| `page_size` | Résultats par page | `10` (défaut) |
| `offset` | Décalage pagination | `0` (défaut) |
| `pcja` | Code PCJA (match exact) | Ex. : `60-01-02-01` |

**Champs retournés par `search_arianeweb`** :

| Champ JSON | Contenu |
|---|---|
| `SourceStr3` | Juridiction (ex. : « Conseil d'État », « CAA LYON ») |
| `SourceStr5` | Numéro de requête |
| `SourceStr7` | Formation de jugement (ex. : « 4-1 CHR », « Assemblée ») |
| `SourceStr8` | Publication Recueil : `A` = Recueil, `B` = Tables, `C` = non publié |
| `SourceStr9` | Type de procédure (ex. : « Premier ressort », « Cassation ») |
| `SourceStr12` | Solution (ex. : « Annulation », « Rejet », « Satisfaction partielle ») |
| `SourceStr21` | Résumé et plan de classement PCJA |
| `SourceStr30` | Identifiant ECLI |
| `SourceCsv1` | Numéro(s) d'affaire |
| `SourceCsv3` | Codes PCJA (plan de classement), séparés par `;`. Filtrable via `sourcecsv3=[code]` : match exact par valeur (pas préfixe hiérarchique). Combinable avec `text.add`. |
| `SourceDateTime1` | Date de la décision |
| `SourceDateTime2` | Date de lecture / audience |
| `SourceInt1` | Année de la décision |
| `Extracts` | Extraits avec termes recherchés surlignés |
| `TotalCount` (global) | Nombre total de résultats |

**Limites de chaque source — ne pas attendre d'un outil ce qu'il ne fait pas**

Open Legi :
- Ne filtre pas par juridiction : les résultats mêlent CE, CAA et TA sans distinction
- Ne retourne pas l'ECLI dans les résultats de recherche
- Ne permet pas de filtrer par formation de jugement, type de procédure ou solution
- Ne recherche pas de façon fiable par numéro de requête (`NUMERO_DECISION` non fonctionnel)
- Ne donne pas accès aux conclusions du rapporteur public

ArianeWeb :
- Ne donne pas accès au texte intégral des décisions (extraits seulement) — mais le texte intégral des **conclusions** est accessible via `get_conclusion`
- Ne fournit pas de résumé PCJA structuré comparable à celui d'Open Legi
- Ne garantit pas l'absence de faux positifs (les synonymes décomposent les expressions composées)
- N'est pas une API documentée officiellement : elle pourrait changer sans préavis
- Ne permet pas de lister l'arborescence PCJA ni d'obtenir le libellé d'un code : les codes PCJA ne sont exploitables que par rebond à partir d'une décision déjà trouvée

**Workflow** : `search_arianeweb` pour découvrir (volume, filtrage CE pur, métadonnées, rebond PCJA), Open Legi pour lire le texte intégral des décisions, `get_conclusion` pour lire les conclusions du rapporteur public.

**Conclusions du rapporteur public** (`fund="AW_CRP"`, ~9 000 documents) :

`search_arianeweb(fund="AW_CRP", numero="[n°]")` retourne les métadonnées. `get_conclusion(numero="[n°]")` télécharge et extrait le texte intégral du PDF officiel.

Champs retournés par `get_conclusion` :

| Champ | Contenu |
|---|---|
| `numero` / `numeros` | N° de requête principal / tous les numéros joints |
| `date` | Date des conclusions (`YYYY-MM-DD`) |
| `ecli` | Identifiant ECLI |
| `formation` | Formation de jugement |
| `publication` | Code Recueil (`A` / `B` / `C`) |
| `linked_decision` | Lien vers la décision (`DCE:[id]`) |
| `resume` | Résumé et plan de classement PCJA |
| `pdf_url` | URL directe du PDF |
| `text` | Texte intégral extrait du PDF |
| `copyright` | Mention légale (conclusions non libres de droits) |

**Copyright** : les conclusions ne sont pas libres de droits. Leur citation doit respecter le code de la propriété intellectuelle. Toute rediffusion commerciale est subordonnée à l'accord du rapporteur public.

### 1.3 — Recueil Lebon

Le filtre `publication_recueil` est ignoré par Open Legi et ne fonctionne pas. Lire le champ `Recueil` (Open Legi) ou `SourceStr8` (ArianeWeb) : `A` = publié au Recueil Lebon (priorité absolue), `B` = Tables du Recueil, `C` = non publié. Épuiser les décisions A et B avant de citer des décisions C.

### 1.4 — Open Legi — textes normatifs

`rechercher_code` pour identifier les articles applicables (CJA, CGCT, etc.). `lister_codes_juridiques` si le nom exact du code est incertain.

### 1.5 — WebSearch (dernier recours)

`site:conseil-etat.fr [termes]` : pour les recherches ciblées par nom d'affaire quand Open Legi et ArianeWeb ne remontent rien.

---

## §2 — Méthode

### Principe de transparence (toutes phases)

Narrer le travail en direct à chaque étape.

| Moment | Ce qu'on affiche |
|---|---|
| Avant une requête | `Requête : [outil] — terme : "[X]" — filtres : [Y]` |
| Après la requête | `[N] résultat(s) : [liste des références avec date et formation]` |
| Sélection / rejet | `Retenu : [réf.] — [raison]` / `Écarté : [réf.] — [raison]` |
| Lecture | `Lecture §§ [X-Y] — [affaire] — [date]` |
| Résultat nul | `Aucun résultat — reformulation : [nouveau terme]` |

---

### Règle anti-hallucination — CHERCHER → TROUVER → CITER

- Ne jamais citer une décision sans l'avoir trouvée par recherche préalable.
- Ne jamais produire un numéro de requête, une date, une formation ou un nom d'affaire.
- Ne jamais attribuer une portée sans avoir lu les considérants contenant la solution.
- Décision non localisée : « non trouvée » — jamais « fausse ».
- Vérifier que la décision est applicable à la date des faits du dossier.

---

==### Phase 0 — Triage==

==Classer la question sur la forme de la demande, pas sur des connaissances de fond.==

==| Critère | SIMPLE | COMPLEXE |==
==|---|---|---|==
==| Questions | Une seule, bien délimitée | Plusieurs imbriquées ou à décomposer |==
==| Texte de référence | Nommé ou identifiable à la lecture | Non identifié, multiple ou incertain |==
==| Dimension temporelle | Aucune (droit positif) | Réforme, évolution, transition |==
==| Conflit de normes | Aucun | Textes concurrents, articulation à trancher |==

==SIMPLE si tous les critères pointent SIMPLE. Un seul COMPLEXE suffit à basculer.==

==**En cas de doute** — afficher et attendre confirmation :==

```
Triage : je classe [SIMPLE / COMPLEXE] — [critère déterminant].
Confirmer ou corriger ?
```

---

### Phase 1 — Cadrage juridique

==**Bypass** — sauter cette phase si :==
==- la question porte sur une question purement jurisprudentielle (ex. contrôle du juge de cassation administratif, office du juge des référés) dont le régime ne découle pas d'un texte précis ;==
==- l'utilisateur fournit déjà les textes applicables dans sa demande.==
==Dans ces cas, passer directement à la Phase 2 en notant : `Phase 1 sautée — [raison]`.==

==| Triage | Phase 1 |==
==|---|---|==
==| SIMPLE | Étapes 1-2, cadrage en 2 lignes |==
==| COMPLEXE | Étapes 1-2-3, bloc CADRAGE formaté |==

La jurisprudence administrative ne s'interprète que dans son cadre normatif. Identifier les textes applicables avant de chercher des décisions.

**Étape 1 — Formulation des questions juridiques**

Identifier 1 à 3 questions précises à partir de la demande. Si la demande est trop large, la décomposer.

Préciser la **procédure** en cause, car elle détermine la nature de la solution attendue :

| Procédure | Objet |
|---|---|
| Recours pour excès de pouvoir (REP) | Légalité d'un acte administratif |
| Pourvoi en cassation | Contrôle de l'arrêt de la CAA |
| Référé suspension (L. 521-1 CJA) | Urgence + doute sérieux sur la légalité |
| Référé liberté (L. 521-2 CJA) | Atteinte grave et manifestement illégale à une liberté fondamentale |
| Avis contentieux (L. 113-1 CJA) | Question de droit nouvelle, sérieuse, se posant dans de nombreux litiges |
| Recours de plein contentieux | Droits subjectifs, responsabilité, contrats |

**Étape 2 — Identification des textes normatifs applicables**

Pour chaque question :
1. Identifier les textes applicables : CJA, CGCT, code de l'urbanisme, loi, décret, PGD, CEDH, bloc de constitutionnalité.
2. Rechercher les articles via `OpenLegi:rechercher_code` — texte exact, numéro d'article, état de vigueur.
3. Vérifier le statut temporel de chaque texte.

**Règle d'application de la loi dans le temps — impérative**

En droit administratif, la légalité d'un acte s'apprécie **à la date à laquelle il a été pris**, et non à la date du jugement. Vérifier systématiquement :
- Quelle version du texte était en vigueur à la date de l'acte contesté ?
- Si le texte a évolué depuis, le signaler et identifier la version applicable.
- Pour les contrats : c'est la loi en vigueur à la date de la signature qui régit le fond.

Ne pas passer à la Phase 2 sans au moins un texte normatif identifié et applicable.

**Étape 3 — Production du cadre (dans le chat, pas dans un fichier)**

```
CADRAGE — [Objet de la demande]

QUESTION : [Formulation précise]
  Procédure : [REP / cassation / référé / plein contentieux / avis]
  Textes applicables : [Articles + code + état de vigueur à la date de l'acte]
  Conditions légales : [Éléments constitutifs posés par le texte]
  Ce que la jurisprudence doit préciser : [Zone d'incertitude, condition débattue, niveau de contrôle]
```

---

### Phase 2 — Recherche

**Contra reo — absolue**

Chercher systématiquement les décisions contraires. Présenter dans l'ordre hiérarchique — jamais les décisions favorables en premier.

**Hiérarchie des formations**

1. Assemblée du contentieux (Ass.)
2. Section du contentieux (Sect.)
3. Formation plénière (Plén.)
4. Chambres réunies
5. Chambre seule
6. Ordonnance (juge unique)

Un arrêt d'Assemblée prime toujours un arrêt de Section, même postérieur. Signaler explicitement un revirement.

**Codes de publication**

| Code | Signification | Portée |
|---|---|---|
| A | Publié au Recueil Lebon | Apport jurisprudentiel majeur — priorité absolue |
| B | Publié aux Tables du Recueil Lebon | Apport notable |
| C | Non publié | Sans apport particulier — utiliser si A et B insuffisants |

Épuiser les décisions A et B (champ `Recueil` dans les métadonnées) avant de citer des décisions C. Signaler explicitement quand une décision citée est non publiée (Recueil C).

**Séquence de recherche**

1. Exploiter les questions juridiques et conditions légales identifiées en Phase 1 pour construire les termes.
2. Première requête : Open Legi `panorama: true` + terme unique discriminant (ancré sur la notion exacte du texte légal + numéro d'article). Écarter immédiatement les résultats dont le champ `Juridiction` n'est pas `Conseil d'État`.
3. Lire le **résumé** et le **plan de classement** de chaque décision CE retournée : ces champs donnent le vocabulaire exact utilisé par le Conseil d'État et orientent les reformulations suivantes. Lire aussi le champ `Recueil` (A/B/C) pour hiérarchiser.
4. Si le résumé répond directement à la question → citer sans lire le texte intégral.
5. Si aucun résumé ne répond → **mode collaboratif** : présenter les candidats et les pistes, attendre validation avant lecture intégrale.
6. **Complément ArianeWeb** : après les requêtes Open Legi, interroger ArianeWeb via `search_arianeweb` pour élargir ou vérifier :
   - Recherche textuelle complémentaire : `search_arianeweb(query="[termes]")`
   - Vérification croisée des métadonnées (formation, publication, ECLI) via les champs retournés
7. **Rebond PCJA** (systématique dès qu'une décision pertinente est trouvée) :
   a. Lire le champ `pcja_codes` de la décision pour obtenir ses codes PCJA (ex. : `60-01-02-01;54-08-01-03-02`)
   b. Relancer : `search_arianeweb(pcja="[code le plus spécifique]")` pour trouver les arrêts classés sous la même rubrique
   c. Si le volume est trop large, combiner : `search_arianeweb(pcja="[code]", query="[termes]")`
   d. `pcja` fait un match exact par valeur : `60-01-02` ne matche pas les décisions classées sous `60-01-02-01`
   e. Pour élargir, remonter d'un niveau : si `60-01-02-01` donne trop peu de résultats, essayer `60-01-02`
8. Recherche par numéro de requête (séquence de fallback) :
   a. Open Legi : `search` avec `champ: "ALL"` (le champ `NUMERO_DECISION` est non fonctionnel pour CETAT)
   b. ArianeWeb : `search_arianeweb(numero="[numéro]")`
   c. WebSearch `site:conseil-etat.fr [numéro]` (dernier recours)

==**Budget de requêtes panorama**==

==| Triage | Règle |==
==|---|---|==
==| SIMPLE | **3-4 panoramas** |==
==| COMPLEXE | Plancher **8 panoramas minimum** |==
==| Plafond | **15** — au-delà, redécomposer |==

==Saturation : s'arrêter après deux requêtes consécutives stériles (au-dessus du plancher).==

==**Calibrage `page_size`**==

==| Triage | `page_size` |==
==|---|---|==
==| SIMPLE | **3 à 5** |==
==| COMPLEXE | **10** (défaut Open Legi) |==

**Matrice de recherche**

| Angle | Description |
|---|---|
| Ancrage impératif | Notion juridique exacte du texte + numéro d'article (ex. : « urgence » + « L. 521-1 ») |
| Calibration lexicale | Plusieurs formules concurrentes pour la même notion (ex. : « doute sérieux », « illégalité manifeste », « atteinte grave ») |
| Reformulation temporelle | Ajouter `sort: DATE_DESC` pour capturer la jurisprudence récente post-réforme |
| Évolution terminologique | Chercher les deux terminologies quand un concept a changé de nom (ex. : « directive » pré-2014 / « lignes directrices » post-2014, « commissaire du gouvernement » pré-2009 / « rapporteur public » post-2009) |
| Rebond PCJA | À partir d'une décision pertinente, lire son champ `pcja_codes` et relancer `search_arianeweb(pcja="[code]")` pour trouver les arrêts classés sur la même rubrique. Combinable avec `query` pour affiner. |

Résultats nuls : deux reformulations distinctes minimum avant de signaler l'échec. En cas d'échec confirmé : le dire, puis produire depuis la connaissance propre, clairement signalé comme tel.

**Conclusions du rapporteur public** : Si l'arrêt est pertinent, vérifier systématiquement l'existence de conclusions : `search_arianeweb(fund="AW_CRP", numero="[n°]")`. Si des conclusions existent, proposer à l'utilisateur de les lire via `get_conclusion(numero="[n°]")` — retourne le texte intégral extrait du PDF officiel. Mentionner le copyright : les conclusions ne sont pas libres de droits.

---

### Phase 2 — Lecture (ciblée)

Lire uniquement après avoir retenu une décision sur la base de son résumé ou de ses métadonnées.

**Structure d'une décision CE — plan de lecture**

Le Conseil d'État a abandonné la forme « Considérant que » en 2019 au profit de paragraphes numérotés. Les deux styles coexistent dans la base.

```
1. Visas            → textes visés — ne pas citer comme solution
2. Faits / procédure → contexte factuel
3. Motifs (§§ numérotés ou « Considérant que »)
   → C'est ici que se trouve la solution
   → Repérer : rappel de la règle → application aux faits → conclusion
4. Dispositif       → « Article 1er : ... est annulé » / « Le pourvoi est rejeté »
   ↑ ARRÊT DE LECTURE — s'arrêter ici
```

**Marqueurs selon le style**

| Style | Section à lire | Marqueur |
|---|---|---|
| Nouveau (post-2019) | §§ numérotés, rubriques explicites | Titre de section + numéro de §§ |
| Ancien | « Considérant que » | « Il résulte de ce qui précède que... » précède le dispositif |

Lire uniquement les motifs répondant à la question identifiée en Phase 1, puis le dispositif. S'arrêter au dispositif.

**Niveaux de contrôle — signaux dans l'arrêt**

| Signal dans l'arrêt | Niveau |
|---|---|
| « erreur de droit » | Contrôle entier sur la qualification juridique |
| « erreur manifeste d'appréciation » | Contrôle restreint |
| « pouvoir discrétionnaire » | Contrôle minimal |
| « n'a pas commis d'erreur de droit en jugeant que » | Validation sans contrôle propre |
| « a exactement qualifié les faits » | Contrôle normal de la qualification |

Ne jamais qualifier le niveau de contrôle sans avoir vérifié la formule utilisée dans l'arrêt.

**Portée**

- **Arrêt de principe** : Assemblée ou Section, publié Recueil (A), formule générale → fonde une règle.
- **Décision d'espèce** : solution liée aux faits, portée limitée.
- **Avis contentieux** : lie la juridiction de renvoi et oriente les juridictions inférieures saisies de la même question.

---

## §3 — Format de sortie

Résumé court dans le chat + numéro de requête + lien Légifrance. Pas de fichier Markdown. Ne pas construire d'argumentation ni faire de cours.

**Format de citation**

```
CE, [formation], [date], [nom usuel], n° [requête][, Rec. si publié au Recueil].
Ex. : CE, Ass., 8 févr. 2007, Gardedieu, n° 279522, Rec. 78.
Ex. : CE, Sect., 28 déc. 2009, Commune de Béziers, n° 304802, Rec. 509.
Ex. (non publié) : CE, 10e-9e ch. réunies, 3 mars 2025, Société X, n° 472133.
```

**Statut épistémique — obligatoire à l'issue**

- **Constante** : solution uniforme et concordante
- **Divisée** : courants contradictoires, les exposer
- **Incertaine** : décisions insuffisantes, question non tranchée ou renvoyée aux juges du fond
