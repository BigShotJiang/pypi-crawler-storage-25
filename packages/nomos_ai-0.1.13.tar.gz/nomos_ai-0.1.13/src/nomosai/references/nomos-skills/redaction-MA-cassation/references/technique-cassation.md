﻿# technique-cassation

---

## §1 — Distinction fait / droit

Socle de toute qualification. La Cour de cassation contrôle le droit, pas les faits.

**Non contrôlé (souveraineté des juges du fond) :**
- Appréciation des preuves et constatation des faits
- Interprétation des actes ambigus (→ mais dénaturation si l'acte est clair)
- Pouvoir discrétionnaire du juge (ex. dommages-intérêts dans certaines matières)

**Contrôlé :**
- Qualification juridique des faits et des actes
- Déduction des conséquences légales imposées par la loi
- Suffisance des motifs de fait au regard de la règle appliquée

---

## §2 — Les 8 cas d'ouverture

### 1. Violation de la règle de droit

**Signal :** La CA a mal interprété ou mal appliqué une règle de droit (loi, règlement, jurisprudence), indépendamment de la motivation.

**Formule type :** "En statuant ainsi, la cour d'appel a violé l'article X."

**Vigilance :** Ne vise que l'erreur de droit pure, pas l'insuffisance de motivation (→ défaut de base légale).

---

### 2. Incompétence et excès de pouvoir

**Signal :** La CA a statué au-delà de sa compétence ou des limites du litige.

Deux formes :
- Incompétence : empiétement sur la compétence d'une autre juridiction
- Excès de pouvoir : statuer ultra petita, infra petita, ou sur une chose non demandée (transgression des limites du litige)

---

### 3. Violation des formes de procédure

**Signal :** Vice de forme affectant la procédure (avant l'audience, lors des débats, au prononcé, à la rédaction).

**Condition :** Le vice doit faire grief. Présomption de régularité à renverser.

Vices fréquents : défaut de contradictoire, composition irrégulière, non-respect du principe du contradictoire.

---

### 4. Contrariété de jugements

**Signal :** Deux décisions de l'ordre judiciaire contenant des dispositions inconciliables, insusceptibles de recours ordinaire.

**Conditions cumulatives :**
- Mêmes parties (ou leurs ayants droit)
- Deux juridictions de l'ordre judiciaire
- Décisions passées en force de chose jugée
- Dispositions inconciliables (pas simplement contradictoires)
- Recours dirigé contre les deux décisions

**Rare en pratique.**

---

### 5. Perte de fondement juridique

**Signal :** La décision est privée de base par la cassation d'une décision dont elle dépend juridiquement (cassation par voie de conséquence).

Exemple : cassation du chef principal entraînant la cassation du chef accessoire.

---

### 6. Défaut de motifs

Trois formes distinctes :

**a. Absence de motifs**
La décision ne comporte aucune motivation sur un chef. Le silence du juge sur un point qu'il devait trancher.

**b. Contradiction de motifs**
Les motifs se contredisent entre eux, ou les motifs contredisent le dispositif. La contradiction doit être réelle et irréductible.

**c. Défaut de réponse à conclusions**
La CA n'a pas répondu à un véritable moyen des dernières conclusions récapitulatives. Un moyen = un fait offert en preuve + une déduction juridique + une portée sur la solution du litige.

**Ne constitue pas un défaut de réponse à conclusions :**
- Le silence sur un argument ou une allégation dépourvue de déduction juridique : le juge n'est pas tenu de suivre les parties dans le détail de leur argumentation
- L'omission de faits invoqués à l'appui d'un moyen auquel le juge a répondu : si ces faits étaient déterminants, le grief est le défaut de base légale, non le défaut de réponse
- Le silence sur un moyen inopérant, qui, même fondé, ne pouvait influer sur la solution du litige
- Le silence sur des conclusions non motivées, imprécises ou contradictoires

**Avantage procédural :** Le défaut de motifs échappe à l'exception de nouveauté, recevable même si le vice n'avait pas été soulevé devant les juges du fond.

---

### 7. Défaut de base légale

**Signal :** La CA a appliqué une règle de droit correctement identifiée, mais ses motifs de fait sont insuffisants pour permettre à la Cour de cassation de vérifier que les conditions légales sont remplies. Les constatations ne permettent pas de contrôler l'application de la règle.

**Formule type :** "En se déterminant ainsi, sans rechercher si [condition légale], la cour d'appel n'a pas donné de base légale à sa décision au regard de l'article X."

**Distinction clé :**
- Violation de loi : la CA a mal compris ou mal appliqué la règle
- Défaut de base légale : la CA a peut-être bien appliqué la règle, mais on ne peut pas le vérifier faute de motifs suffisants

**Vigilance :** Le défaut de base légale peut être irrecevable comme moyen nouveau si le grief n'a pas été soulevé devant les juges du fond, sauf s'il entre dans les exceptions à la nouveauté.

---

### 8. Dénaturation de l'écrit

**Signal :** La CA a interprété un acte clair d'une façon incompatible avec son sens évident.

**Conditions cumulatives :**
- Un écrit valable (acte, contrat, pièce)
- L'acte est clair : son sens n'est pas ambigu
- L'interprétation retenue est incompatible avec le texte de l'acte
- La CA a rattaché son interprétation à l'acte (elle ne peut pas ignorer ce qu'elle a lu)

**Vigilance :**
- Si l'acte est ambigu, l'interprétation relève de l'appréciation souveraine : pas de dénaturation possible
- Ne pas confondre dénaturation (rare en pratique) et désaccord sur l'interprétation d'un acte ambigu

---

## §3 — Recevabilité et opérance

### A. Moyen précis

Art. 978 CPC : le moyen doit viser un texte de loi défini et formuler le grief de façon précise.

Un moyen vague, sans référence à une règle de droit identifiable, est irrecevable.

---

### B. Moyen non nouveau

**Principe :** Le moyen doit avoir été soumis aux juges du fond. Un moyen nouveau est irrecevable.

**Vérification pratique :** Comparer le grief envisagé avec les conclusions d'appel. Si le grief n'y figure pas, il est a priori nouveau.

**Exceptions (moyen nouveau recevable) :**
1. **Révélé par la décision attaquée** : vice de forme, vice de motivation ou vice de fond qui ne pouvait être soulevé qu'après lecture de l'arrêt
2. **Moyen de pur droit** : ne requiert aucune constatation de fait nouvelle, la règle de droit peut être appliquée aux faits tels que constatés par la CA
3. **Moyen d'ordre public** : doit avoir été de pur droit et apparent en cause d'appel
4. **Moyen d'irrecevabilité ou de défense révélé par le pourvoi**

---

### C. Moyen opérant

**Principe :** L'erreur doit être causale, supprimer le motif attaqué doit entraîner l'impossibilité de maintenir la solution.

**Moyen inopérant si :**
- Le motif attaqué est surabondant : la solution repose sur d'autres motifs indépendants qui ne sont pas attaqués
- Le moyen est étranger à la décision attaquée ou aux parties

**Test pratique :** "Si la CA avait statué correctement sur ce point, aurait-elle nécessairement tranché différemment ?" Si oui, le moyen est opérant.

**Stratégie :** Si plusieurs motifs soutiennent la solution, tous doivent être attaqués. Un seul moyen qui en laisse un intact est inopérant.