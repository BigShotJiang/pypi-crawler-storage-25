---
name: redaction-MA-cassation
description: Rédaction d'un mémoire ampliatif devant la Cour de cassation (toutes chambres). Déclencher dès que l'utilisateur évoque : attaquer un arrêt d'appel, former un pourvoi, rédiger un mémoire ampliatif, trouver des moyens de cassation, construire un grief, identifier ce qu'on peut reprocher à la cour d'appel, préparer un pourvoi. Ne pas déclencher en défense — pour répondre à un pourvoi adverse, utiliser `redaction-MD-cassation`.
---

# Mémoire ampliatif — Cour de cassation

Skill autonome pour l'attaque d'un arrêt devant la Cour de cassation, toutes chambres.  
**Mode par défaut : collaboratif.** Présenter l'analyse avant de rédiger. Ne jamais rédiger sans validation.

---

## §0 — Environnement

| Mode | Détection | Sortie |
|---|---|---|
| **CLAUDE_CODE** (VS Code) | Outil Bash disponible | Édition directe du fichier `.md` |
| **COWORK** | Dossier projet Cowork | Fichier `.md` ou `.docx` dans le dossier de travail |
| **CLAUDE_AI** | Ni Bash ni Cowork | Réponse conversationnelle structurée, moyen par moyen |

En mode **CLAUDE_CODE** : lire le fichier avant toute modification.

---

## §1 — Contexte du dossier (workflow)

Le workflow du cabinet organise les fichiers en deux niveaux. Lire dans cet ordre.

### Étape 1 — Fichiers de contexte (lire en priorité)

| Fichier | Contenu | Où le trouver |
|---|---|---|
| Instructions permanentes du dossier | Stratégie, notes, points de vigilance | Fichier `CLAUDE.md` propre au dossier |
| Contexte juridique du dossier | Parties, juridiction, pièces disponibles, moyens identifiés, notes stratégiques | Fichier `[nom-dossier].md` |

Ces deux fichiers suffisent pour lancer le playbook. L'utilisateur guide si un approfondissement factuel est nécessaire.

### Étape 2 — Pièces procédurales (lecture chirurgicale)

Ne pas lire les documents entiers. Cibler les passages pertinents.

| Fichier | Ce qu'il faut lire |
|---|---|
| Arrêt attaqué | Le raisonnement juridique uniquement — pas les faits s'ils figurent déjà dans le fichier contextuel |
| Nos conclusions d'appel | Les moyens soumis aux juges du fond, pour vérifier la recevabilité des griefs |
| Draft existant du mémoire ampliatif | Lire l'intégralité du draft avant toute intervention |

**Règle : si un draft existe, partir de ce qui est déjà rédigé.** Identifier ce qui est solide, ce qui manque, ce qui doit être restructuré, et intervenir chirurgicalement.

---

## §2 — Playbook : identification des moyens

Exécuter avant toute rédaction. Présenter le résultat à l'utilisateur et **attendre sa validation** avant de passer à la rédaction.

### 2.1 — Analyse de l'arrêt attaqué

Pour chaque point de droit tranché par la cour d'appel, se demander :
- Quelle règle a-t-elle appliquée ou refusé d'appliquer ?
- L'a-t-elle correctement qualifiée, appliquée, motivée ?
- Y a-t-il un décalage entre ses propres constatations de fait et son raisonnement juridique ?

Confronter chaque piste à la grille des cas d'ouverture → `references/technique-cassation.md`

### 2.2 — Qualification des griefs

Pour chaque piste, qualifier le cas d'ouverture :

| Cas d'ouverture | Signal dans l'arrêt | Démonstration à construire |
|---|---|---|
| Violation de loi | La CA a appliqué une règle inexacte ou l'a mal interprétée | Poser la règle exacte et montrer que la CA s'en est écartée |
| Défaut de base légale | La CA n'a pas recherché un élément déterminant, ou ses motifs sont insuffisants pour contrôler la légalité | Démontrer le défaut de motivation ou l'absence de recherche |
| Défaut de réponse à conclusions | Un véritable moyen (fait + déduction juridique + portée sur la solution) reste sans réponse, même implicite. Ne pas confondre avec l'omission d'un argument ou de faits à l'appui d'un moyen traité (→ défaut de base légale) | Identifier le moyen délaissé dans les dernières conclusions récapitulatives, montrer qu'il n'est ni un simple argument ni un moyen inopérant, et constater le silence de l'arrêt |

### 2.3 — Filtre de recevabilité

Pour chaque piste, vérifier :
- **Précision** : peut-on viser un texte de loi défini (art. X) ?
- **Nouveauté** : le grief a-t-il été soumis aux juges du fond ? Si non, irrecevable sauf exceptions → `references/technique-cassation.md` §3
- **Opérance** : l'erreur est-elle causale ? Si le motif attaqué est surabondant, le moyen est inopérant.

Une piste qui échoue à l'un de ces filtres n'est pas écartée d'office : la signaler comme risquée et en informer l'utilisateur.

### 2.4 — Présentation à l'utilisateur

Pour chaque piste, présenter :

| # | Qualification | Grief en une phrase | Texte visé | Recevabilité | Risque |
|---|---|---|---|---|---|
| 1 | Défaut de base légale | La CA n'a pas recherché si… | Art. X | ✅ | Faible |
| 2 | Violation de loi | La CA a appliqué l'art. X alors que… | Art. X | ⚠️ moyen nouveau | Élevé |

Formuler pour chaque piste : le grief en une phrase, le texte visé, les faits-support tirés de l'arrêt et des conclusions d'appel.

**Attendre la validation de l'utilisateur avant toute rédaction.**

### 2.5 — Mise à jour des notes stratégiques

Après validation, mettre à jour la section **Notes stratégiques** du fichier `[nom-dossier].md` :
- Moyens retenus : qualification, texte visé, grief en une phrase
- Moyens écartés : raison (irrecevabilité, inopérance, risque élevé)
- Points à approfondir (jurisprudence à rechercher, faits à confirmer)


---

## §3 — Sources et anti-hallucination

**Règle absolue : ne citer aucune décision sans l'avoir trouvée par recherche préalable.**

Ordre impératif : **Chercher → Trouver → Citer**. Jamais l'inverse.

**Pour toute recherche jurisprudentielle**, invoquer le skill **`recherche-Ccass_droit privé`**. Ce skill gère la recherche sur OpenLegi, la lecture des arrêts et le contrôle anti-hallucination.

Sources admises dans le mémoire :
- Textes normatifs lus et vérifiés via OpenLegi (articles des codes en vigueur à la date des faits)
- Décisions trouvées et lues via le skill `recherche-Ccass_droit privé`
- Citations textuelles de l'arrêt attaqué et de nos conclusions d'appel (fichiers du dossier)
- Doctrine identifiée par recherche effective (jamais de mémoire)

Si une recherche ne retourne rien : le dire. Zéro référence vaut mieux qu'une référence inventée.

---

## §4 — Rédaction

### Structure du raisonnement — majeure / mineure

**Règle absolue : toujours commencer par la règle de droit (majeure), puis démontrer qu'elle a été méconnue en l'espèce (mineure).**

- La majeure pose la règle exacte : texte visé, interprétation exacte, jurisprudence de principe si disponible.
- La mineure confronte le raisonnement de la cour d'appel à cette règle : citer textuellement les motifs attaqués, identifier précisément l'erreur ou le manquement.
- On peut alterner majeure et mineure au sein d'un même développement, mais le premier mouvement est toujours la règle.
- Ne jamais partir des faits pour remonter vers la règle.

### Style

- **Densité** : pas de rappel factuel inutile, pas de digression. Le mémoire ampliatif est offensif et précis.
- **Citations** : guillemets français « … », référence précise (arrêt, p. X ou § Y). Citer textuellement les motifs attaqués.
- **Clôture de chaque branche** : « La cassation s'impose. »
- **Clôture de chaque moyen** : « Le moyen sera accueilli. »
- **Clôture globale** : « L'arrêt sera cassé. »

### Périmètre de ce skill

Ce skill rédige le **corps argumentatif** de chaque branche.  
La rédaction du **chapeau formel** de chaque moyen relève du skill `redaction-moyen`.

---

## §5 — Format de sortie

**CLAUDE_CODE** : édition directe du fichier `.md` du mémoire en cours. Lire le fichier entier avant toute modification. Ne pas créer de nouveau fichier si un draft existe.

**COWORK** : créer ou compléter un fichier dans le dossier du dossier. Convention : `[AAAA-MM-JJ]-memoire-ampliatif-[nom].md`.

**CLAUDE_AI** : réponse structurée dans le chat, un moyen à la fois.