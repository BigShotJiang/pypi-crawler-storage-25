﻿---
name: recherche-CJUE_UE
version: 1.2
date: 2026-05-14
description: "Recherche et analyse de jurisprudence de la Cour de justice de l'Union européenne (CJUE) et du Tribunal. Utilise Legal Data Hunter MCP (12 000 décisions 2015-2026), EurLex MCP (textes normatifs), InfoCuria (curia.europa.eu) et le Répertoire CJUE. Déclencher pour toute question sur la jurisprudence européenne, un arrêt CJUE, un renvoi préjudiciel, un recours en annulation, un manquement d'État, une interprétation du droit de l'Union, ou toute recherche impliquant un ECLI EU, un numéro d'affaire C-xxx/xx ou T-xxx/xx."
---

# Recherche et analyse — CJUE

## §1 — Sources

- **Legal Data Hunter MCP** : `search`, `namespace: "case_law"`, `country: ["EU"]`, `court_tier: 1` — jurisprudence CJUE et Tribunal 2015-2026 (~12 000 décisions). Retourne ECLI, CELEX, URL EUR-Lex et extrait. **Langue : formuler les requêtes en anglais** — les requêtes en français remontent systématiquement des résultats hors CJUE (OEB, juridictions nationales).
- **EurLex MCP** : textes normatifs uniquement (traités, directives, règlements). Ne jamais utiliser pour la jurisprudence.
==- **GoodLegal MCP** : `eu_caselaw_search` — recherche sémantique dans la jurisprudence UE. Retourne CELEX, résumé, score de pertinence et articles fréquemment cités. Point d'entrée rapide pour un premier balayage.==
- **InfoCuria** (WebSearch sur curia.europa.eu) : jurisprudence avant 2015 et recherches ciblées par numéro d'affaire ou ECLI. Le portail infocuria.curia.europa.eu est une SPA JavaScript inaccessible via WebFetch : passer par WebSearch (`site:curia.europa.eu C-xxx/xx`) pour localiser les décisions.

---

## §2 — Méthode

### Transparence (toutes phases)

| Moment | Affichage |
|---|---|
| Avant requête | `Requête : [outil] — terme : "[X]" — filtres : [Y]` |
| Après requête | `[N] résultat(s) : [liste avec date et formation]` |
| Sélection / rejet | `Retenu : [réf.] — [raison]` / `Écarté : [réf.] — [raison]` |
| Lecture | `Lecture §§ [X-Y] — [affaire] — [date]` |
| Résultat nul | `Aucun résultat — reformulation : [nouveau terme]` |

---

### Règle anti-hallucination — CHERCHER → TROUVER → CITER

- Jamais citer sans avoir trouvé par recherche préalable.
- Jamais produire ECLI, numéro d'affaire, date, formation ou partie de mémoire.
- Jamais attribuer une portée sans avoir lu les points contenant la solution.
- Décision non localisée : « non trouvée » — jamais « fausse ».
- Vérifier l'applicabilité temporelle à la date des faits.

---

==### Phase 0 — Triage==

==Classer la question sur la forme de la demande, pas sur des connaissances de fond.==

==| Critère | SIMPLE | COMPLEXE |==
==|---|---|---|==
==| Questions | Une seule, bien délimitée | Plusieurs imbriquées ou à décomposer |==
==| Texte de référence | Nommé ou identifiable à la lecture | Non identifié, multiple ou incertain |==
==| Dimension temporelle | Aucune (droit positif) | Réforme, évolution, transition pré/post-Lisbonne |==
==| Conflit de normes | Aucun | Articulation droit primaire / dérivé, ou droit UE / national |==

==SIMPLE si tous les critères pointent SIMPLE. Un seul COMPLEXE suffit à basculer.==

==**En cas de doute** — afficher et attendre confirmation :==

```
Triage : je classe [SIMPLE / COMPLEXE] — [critère déterminant].
Confirmer ou corriger ?
```

---

### Phase 1 — Cadrage normatif

==**Bypass** — sauter cette phase si :==
==- la question porte sur un point de jurisprudence autonome (ex. effet direct, primauté, responsabilité Francovich) dont le régime est purement prétorien ;==
==- l'utilisateur fournit déjà les textes applicables dans sa demande.==
==Dans ces cas, passer directement à la Phase 2 en notant : `Phase 1 sautée — [raison]`.==

==| Triage | Phase 1 |==
==|---|---|==
==| SIMPLE | Questions 1-2, cadrage en 2 lignes |==
==| COMPLEXE | Questions 1-2-3, bloc CADRAGE formaté |==

La jurisprudence CJUE ne s'interprète que dans son cadre normatif. Identifier les textes avant toute recherche.

1. Formuler 1 à 3 questions juridiques précises.
2. Pour chaque question : identifier l'article TFUE/CDFUE/acte dérivé applicable. Si acte dérivé : récupérer le CELEX via `eurlex_search_by_number` ou `eurlex_search_by_title`, puis vérifier le statut et la date applicable.
3. Afficher dans le chat :

```
CADRAGE — [Objet]
QUESTION : [Formulation]
  Textes : [Article + instrument + CELEX si acte dérivé]
  Procédure : [renvoi préjudiciel / annulation / manquement / pourvoi]
  Zone d'incertitude : [ce que la jurisprudence doit préciser]
```

Ne pas passer en Phase 2 sans au moins un texte identifié.

---

### Phase 2 — Recherche

==**Chercher d'abord, lire ensuite.** Ne pas ouvrir une décision sans avoir établi sa pertinence. Trois outils d'identification (sans lecture intégrale) : GoodLegal `eu_caselaw_search` (balayage sémantique rapide), Legal Data Hunter `search` (extraits + métadonnées + filtres fins), InfoCuria via WebSearch (pré-2015). Multiplier les requêtes et reformulations. Ne lire que les arrêts retenus, et seulement leurs sections utiles.==

**Fichiers volumineux.** `get_document` retourne parfois des fichiers trop grands pour être lus directement. Dans ce cas, utiliser l'outil **Grep** (recherche par mot-clé à l'intérieur du fichier sauvegardé) — il localise instantanément les passages pertinents sans charger le document entier. Chercher le nom des parties, un numéro de point, un mot du dispositif.

**Contra reo** : chercher systématiquement les décisions contraires. Présenter dans l'ordre hiérarchique — jamais les favorables en premier.

**Hiérarchie des formations**

1. Cour — Assemblée plénière
2. Cour — Grande Chambre (15 juges)
3. Cour — Chambre à 5 juges
4. Cour — Chambre à 3 juges
5. Cour — Ordonnance
6. Tribunal — Chambre élargie puis ordinaire

Grande Chambre prime toujours un arrêt de chambre, même postérieur. Signaler explicitement un revirement.

EurLex MCP ne remonte pas de jurisprudence fiable — ne pas l'utiliser pour les arrêts.

==**Axe 1 — GoodLegal `eu_caselaw_search`** (balayage initial)==

==Premier réflexe. Requête sémantique large pour identifier les arrêts de principe et les articles fréquemment cités. Permet de calibrer les recherches suivantes.==

==**Axe 2 — Legal Data Hunter `search`** (approfondissement)==

==`namespace: "case_law"`, `country: ["EU"]`. Formulations **en anglais uniquement**. Filtres utiles : `court_tier: 1`, `date_start`, `date_end`. Toujours inclure une requête avec `date_start: "2023-01-01"` pour couvrir les décisions récentes non encore indexées ailleurs.==

==**Accès direct par référence** : quand un numéro d'affaire (C-xxx/xx) ou un ECLI est connu, utiliser `resolve_reference` (Legal Data Hunter) au lieu de WebSearch. Plus fiable, retourne directement source + source_id pour `get_document`.==

==**Axe 3 — InfoCuria** (pré-2015 et complément)==

==WebSearch `site:curia.europa.eu [termes]` pour la jurisprudence avant 2015 ou les décisions non couvertes par les deux premiers axes.==

**Critères InfoCuria**

| Critère | Format |
|---|---|
| Numéro d'affaire | C-xxx/xx (Cour) / T-xxx/xx (Tribunal) |
| ECLI | ECLI:EU:C:AAAA:N |
| CELEX jurisprudence | 6[AAAA][C ou T][NNNNN] |
| Mots du texte | booléens : espace=ET, virgule=OU, !=SAUF |
| Nom des parties | jokers : * (0→∞ car.), _ (1 car.), " " (exact) |

Suffixes à exclure du numéro d'affaire : P, R, PPU, REV, RX, OP, DEP, AJ.


==**Budget de requêtes**==

==| Triage | Règle |==
==|---|---|==
==| SIMPLE | **3-4 requêtes** |==
==| COMPLEXE | Plancher **8 requêtes minimum** (GoodLegal + Legal Data Hunter + InfoCuria) |==
==| Plafond | **15** — au-delà, redécomposer |==

==Saturation : arrêter après deux requêtes consécutives stériles.==

==**Calibrage `top_k` (Legal Data Hunter)**==

==| Triage | `top_k` |==
==|---|---|==
==| SIMPLE | **5** |==
==| COMPLEXE | **10** (défaut) |==

**Matrice de reformulation** : ancrer sur la notion juridique exacte du texte de l'Union + article (ex. : « intérêt supérieur de l'enfant » + « art. 24 CDFUE »), puis décliner en plusieurs formules concurrentes en français et anglais.

**Évolution terminologique** : chercher les deux terminologies quand un concept ou un texte a changé de nom (ex. : « Communauté européenne » pré-Lisbonne / « Union européenne » post-2009, « art. 81 TCE » / « art. 101 TFUE » en droit de la concurrence, « Tribunal de première instance » pré-2009 / « Tribunal » post-2009, « renvoi préjudiciel art. 234 TCE » / « art. 267 TFUE »).

Résultats nuls : deux reformulations minimum avant de signaler l'échec. En cas d'échec confirmé : le dire, puis produire depuis la connaissance propre en le signalant clairement.

**Conclusions d'avocat général** : pas de valeur normative. Ne pas lire sauf demande explicite.

---

### Phase 3 — Lecture (ciblée)

Lire uniquement après avoir retenu une décision sur la base de ses métadonnées ou de l'extrait. Ne jamais lire intégralement un arrêt non encore confirmé pertinent.

**Plan commun — repérer dans cet ordre**

```
1. Cadre juridique       → textes — ne pas citer comme interprétation
2. Litige                → faits selon la procédure
3. Forms of order sought → absent du renvoi préjudiciel
4. *** SECTION D'INTERPRÉTATION *** → nom varie (voir ci-dessous)
5. Dispositif            → conclusion formelle
```

Lire la section 4 puis le dispositif (5). Pas les observations des parties, pas les développements procéduraux.

**Section d'interprétation selon la procédure**

| Procédure | Marqueur | Section à lire |
|---|---|---|
| Renvoi préjudiciel | Questions reproduites textuellement — pas de "Forms of order sought" | « Sur les questions préjudicielles » / "Consideration of the questions referred" |
| Recours en annulation | "Forms of order sought" présent | « En droit » / "Law" → subdivisé par moyen |
| Manquement d'État | Section "Pre-litigation procedure" | « Sur le recours » / "The action" |
| Pourvoi | "Background... and the **judgment under appeal**" | « Sur le pourvoi » / "The appeal" |

**Dispositifs — formules de conclusion**

| Procédure | Formule |
|---|---|
| Renvoi préjudiciel | « dit pour droit : » / "hereby rules:" |
| Recours en annulation | « Annule [l'acte] » / « Rejette le recours » |
| Manquement d'État | « Déclare que [État] a manqué » |
| Pourvoi | « Annule l'arrêt du Tribunal » / « Rejette le pourvoi » |

**Renvoi préjudiciel** : la Cour reformule souvent les questions — « Par sa question X, la juridiction de renvoi demande en substance... ». Repérer cette reformulation : elle délimite l'interprétation. Commencer la lecture là, pas aux questions textuelles.

**Recours en annulation** : chaque sous-section de « En droit » suit le schéma : rappel de la règle → application aux faits → conclusion (« il y a lieu de constater que... »). Le dispositif numéroté confirme l'issue sans raisonnement supplémentaire.

**Portée** : arrêt de principe (Grande Chambre ou Plénière, publié, formule générale) fonde une règle d'interprétation. Décision d'espèce (chambre ordinaire, liée aux faits) a une portée limitée. Renvoi préjudiciel : la réponse lie la juridiction de renvoi et toutes les juridictions des États membres saisies d'une question identique.

---

## §3 — Format de sortie

Résumé court dans le chat + numéro d'affaire + ECLI + lien EUR-Lex (fourni par Legal Data Hunter, ou via `eurlex_get_url` si seul le CELEX est connu) ou lien InfoCuria. Pas de fichier Markdown.

**Format de citation**

```
CJUE, [formation], [date], [nom usuel], aff. [C-xxx/xx], ECLI:[ECLI], point [N].
Ex. : CJUE, grande ch., 25 juill. 2018, Confédération paysanne, aff. C-528/16, ECLI:EU:C:2018:583, pt. 44.
```

**Statut épistémique — obligatoire à l'issue**

- **Constante** : interprétation uniforme posée par la Cour
- **Divisée** : lignes contradictoires entre Cour et Tribunal, ou entre chambres
- **Incertaine** : question non tranchée, décisions insuffisantes, ou renvoyée aux juridictions nationales
