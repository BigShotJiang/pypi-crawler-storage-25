---
name: recherche-BOFIP_fiscal
version: 1.1
date: 2026-05-05
description: "Recherche et identification de la doctrine administrative fiscale dans le BOFiP (Bulletin Officiel des Finances Publiques – Impôts). Utilise le MCP BOFiP (bofip_rechercher, bofip_consulter_document, bofip_lister_enfants, bofip_consulter_document_contexte) et Open Legi pour le cadrage normatif (CGI, LPF). Déclencher pour toute question sur la position de l'administration fiscale, la doctrine DGFiP, un commentaire BOFiP, un BOI, un rescrit, l'opposabilité d'une position fiscale (art. L. 80 A LPF), ou toute question du type « comment l'administration traite X en matière fiscale », même si l'utilisateur ne mentionne pas explicitement le BOFiP."
---

# Recherche — Doctrine fiscale BOFiP

---

## §1 — Sources

- **BOFiP MCP** — quatre outils utiles :
  - `bofip_rechercher(query, serie, limit)` : recherche plein texte. Filtre `serie` recommandé dès que la série est identifiable.
  - `bofip_lister_enfants(identifiant_juridique)` : navigation descendante dans l'arborescence — utile pour explorer une division avant de cibler un BOI.
  - `bofip_consulter_document(identifiant_juridique)` : texte complet d'un BOI, avec pagination si long (`content_offset`). **Outil de lecture par défaut.**
  - `bofip_consulter_document_contexte(identifiant_juridique)` : idem + fil d'Ariane + documents frères + renvois croisés. Réserver aux cas où la portée ou le positionnement du BOI est incertain.
- **Open Legi MCP** — `rechercher_code(search, code_name, champ)` : recours si la recherche part d'un article CGI ou LPF précis, ou pour vérifier la rédaction exacte d'un texte en litige. Ne pas appeler par défaut.
- **Périmètre du BOFiP** : doctrine administrative uniquement. Ne contient ni jurisprudence ni rescrits non publiés ni positions locales des services.

---

## §2 — Méthode

### Transparence (toutes phases)

| Moment | Affichage |
|---|---|
| Avant requête | `Requête : [outil] — terme : "[X]" — série : [Y ou "toutes"]` |
| Après requête | `[N] résultat(s) : [liste des BOI avec date de validité]` |
| Sélection / rejet | `Retenu : [BOI-XXX] — [raison]` / `Écarté : [BOI-XXX] — [raison]` |
| Résultat nul | `Aucun résultat — reformulation : [nouveau terme]` |

---

### Règle anti-hallucination — CHERCHER → TROUVER → CITER

- Ne jamais citer un BOI sans l'avoir trouvé via le MCP.
- Ne jamais inventer un identifiant juridique : la structure `BOI-SÉRIE-DIVISION-...` est spécifique — un identifiant plausible mais faux est indétectable.
- Reproduire les permaliens tels quels depuis le résultat MCP, sans modification.
- BOI non localisé : « non trouvé » — jamais supposé ou reconstitué.

---

### Phase 1 — Cadrage (interne)

Avant de chercher, identifier mentalement : la série BOFiP pertinente et un ou deux mots-clés discriminants ancrés sur la question. Ce raisonnement reste interne — ne pas l'afficher sauf si la question est ambiguë ou multi-volets.

**Table des séries**

| Série | Domaine |
|---|---|
| BIC | Bénéfices industriels et commerciaux |
| BNC | Bénéfices non commerciaux |
| BA | Bénéfices agricoles |
| IS | Impôt sur les sociétés |
| IR | Impôt sur le revenu (hors revenus catégoriels) |
| RSA | Traitements, salaires, pensions |
| RPPM | Revenus et profits du patrimoine mobilier |
| RFPI | Revenus fonciers et plus-values immobilières des particuliers |
| TVA | Taxe sur la valeur ajoutée |
| ENR | Droits d'enregistrement, IFI |
| IF | Impôts fonciers locaux |
| INT | Fiscalité internationale |
| CF | Contrôle fiscal |
| CTX | Contentieux de l'impôt |
| REC | Recouvrement |
| SJ | Sécurité juridique (rescrits, L. 80 A LPF) |
| RES | Rescrits à portée générale publiés |

Si la question part d'un article CGI ou LPF précis dont la rédaction est nécessaire : appeler `Open Legi : rechercher_code`. Sinon, aller directement en Phase 2 — les BOI citent eux-mêmes les articles dans leur corps.

---

### Phase 2 — Recherche

**Ordre de priorité**

1. Identifiant juridique connu → `bofip_consulter_document` directement.
2. Série identifiée → `bofip_rechercher(query, serie=XXX)`.
3. Série incertaine → `bofip_rechercher(query)` sans filtre, puis affiner.
4. Navigation → `bofip_lister_enfants(BOI-SÉRIE)` pour explorer une division.

**Budget**

| Question | Règle |
|---|---|
| Précise (série et terme connus) | 1-2 requêtes, puis lecture |
| Thématique | 4-6 requêtes |
| Plafond | 10 — au-delà, redécomposer |

Saturation : s'arrêter après deux requêtes consécutives sans nouveau BOI pertinent. En cas de résultat nul : reformuler avec synonymes fiscaux ou numéro d'article CGI. Deux reformulations avant de signaler l'échec.

**Évolution terminologique** : chercher les deux terminologies quand un concept fiscal a changé de nom.

**Vérification de la version**

Chaque BOI porte une date de validité. `bofip_rechercher` retourne la dernière version en vigueur : vérifier qu'elle est applicable à la date des faits. Date de publication ≠ date d'effet : signaler tout décalage notable. Pour une situation ancienne, avertir que la version applicable au moment des faits peut différer.

Un BOI abrogé n'est pas supprimé mais « fermé » (épitaphe). Le signaler s'il remonte dans les résultats.

---

### Phase 3 — Lecture (ciblée)

Lire un BOI seulement après l'avoir retenu sur la base du titre et des métadonnées.

Les BOI sont structurés en paragraphes numérotés par dizaines (§10, §20…). Aller directement au § ou à la section répondant à la question — ne pas lire le document en entier. Si le contenu est tronqué, paginer via `content_offset`.

---

## §3 — Format de sortie

Résumé de la position doctrinale dans le chat + identifiant BOI + date de validité + permalink tel quel. Pas de fichier Markdown. Ne pas faire de cours sur la matière fiscale.

**Format de citation**

```
BOI-[SÉRIE]-[DIVISION]-[...], [date de validité], §[N].
Ex. : BOI-TVA-LIQ-30-20-90, 15 janv. 2024, §30.
Ex. (rescrit) : BOI-RES-TVA-000230, 28 janv. 2026.
```

**Statut épistémique — obligatoire à l'issue**

- **Doctrine constante** : position claire et uniforme
- **Doctrine favorable invocable** : plus favorable que la loi, opposable à l'administration (art. L. 80 A LPF) tant que publiée
- **Doctrine silencieuse** : aucun BOI ne traite la question — le dire, ne pas suppléer sans le signaler
- **Doctrine abrogée** : BOI fermé — signaler la date de clôture

**Si contentieux fiscal nécessaire** : signaler que la jurisprudence administrative (CE) relève du skill `recherche-CE_droit-public`.
