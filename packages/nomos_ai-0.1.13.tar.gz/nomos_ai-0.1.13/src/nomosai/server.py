#!/usr/bin/env python3
"""
NomosAI MCP Server
==================
Expose les capacités d'anonymisation de NomosAI comme outils MCP pour agents LLM.

Transport : stdio (par défaut, compatible Claude Desktop / Claude Code)

Outils disponibles :
    anonymize_file   — traite un fichier (.docx, .pdf, .txt, .md, .rst), écrit le .md anonymisé
    list_entities    — liste les types de PII disponibles avec leurs descriptions

Usage :
    uvx nomos-ai

Configuration Claude Desktop (%APPDATA%\\Claude\\claude_desktop_config.json) :
    {
      "mcpServers": {
        "nomos-ai": {
          "command": "uvx",
          "args": ["nomos-ai"]
        }
      }
    }
"""

import datetime
import io
import json
import re
import shutil
import threading
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP, Context
from pdfminer.high_level import extract_text as _pdf_extract_text
from pydantic import create_model, Field

from nomosai.engine import (
    build_analyzer,
    DocumentAnonymizer,
    DEFAULT_ENTITIES,
    ENTITY_LABELS,
)
from nomosai.readers import read_document, SUPPORTED_EXTENSIONS
from nomosai.formatter import to_markdown


# ---------------------------------------------------------------------------
# Serveur MCP
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name="nomos-ai",
    instructions=(
        "Serveur d'anonymisation NomosAI.\n\n"
        "CONFIDENTIALITÉ : utilisez toujours anonymize_file avec le chemin du fichier — "
        "le contenu brut ne circule jamais dans le contexte LLM.\n\n"
        "SÉLECTION DES ENTITÉS avant chaque appel à anonymize_file :\n"
        "  • Demande générique → anonymize_file(elicit_entities=True)\n"
        "    Présente 3 profils : base / avancee / personnalise\n"
        "    L'utilisateur tape son choix et confirme.\n"
        "  • Entités nommées explicitement → anonymize_file(entities=[<codes>])\n"
        "  • 'Par défaut' → anonymize_file() sans paramètre\n\n"
        "PROFILS DISPONIBLES (elicit_entities=True) :\n"
        "  base         PERSON · ORGANIZATION · EMAIL_ADDRESS · PHONE_NUMBER\n"
        "  avancee      base + FR_NIR · FR_CNI · FR_PASSPORT · FR_DRIVING_LICENSE\n"
        "               · LOCATION · FR_POSTAL_CODE · IBAN_CODE · CREDIT_CARD · URL · IP_ADDRESS\n"
        "  personnalise l'utilisateur liste ses catégories (texte libre)\n\n"
        "CODES pour entities=[...] :\n"
        "  PERSON  ORGANIZATION  EMAIL_ADDRESS  PHONE_NUMBER  LOCATION\n"
        "  IBAN_CODE  CREDIT_CARD  URL  IP_ADDRESS  MEDICAL_LICENSE\n"
        "  FR_NIR  FR_CNI  FR_PASSPORT  FR_DRIVING_LICENSE  FR_SIRET  FR_SIREN  FR_TVA  FR_POSTAL_CODE\n"
        "  DATE_TIME  FILE_PATH  (opt-in — désactivés par défaut)\n\n"
        "Formats supportés : .docx .pdf .txt .md .rst"
    ),
)


# ---------------------------------------------------------------------------
# Cache des analyseurs (build_analyzer est coûteux : ~5-10s par langue)
# ---------------------------------------------------------------------------

_analyzer_cache: dict[str, object] = {}
_cache_lock = threading.Lock()

SUPPORTED_LANGUAGES = {"fr", "en", "de", "es", "it", "nl", "pt"}

_SPACY_MODELS = {
    "fr": "fr_core_news_lg",
    "en": "en_core_web_lg",
    "de": "de_core_news_lg",
    "es": "es_core_news_lg",
    "it": "it_core_news_lg",
    "nl": "nl_core_news_lg",
    "pt": "pt_core_news_lg",
}

_OPT_IN_ENTITIES = {"DATE_TIME", "FILE_PATH"}

_FRENCH_ONLY = {
    "FR_NIR", "FR_SIRET", "FR_SIREN", "FR_TVA",
    "FR_PASSPORT", "FR_CNI", "FR_DRIVING_LICENSE", "FR_POSTAL_CODE",
    "FILE_PATH",
}

_ENTITY_DESCRIPTIONS = {
    "PERSON":             "Noms de personnes physiques",
    "ORGANIZATION":       "Noms d'organisations ou entreprises",
    "LOCATION":           "Lieux géographiques, adresses",
    "EMAIL_ADDRESS":      "Adresses e-mail",
    "PHONE_NUMBER":       "Numéros de téléphone",
    "IBAN_CODE":          "Codes IBAN bancaires",
    "CREDIT_CARD":        "Numéros de carte de crédit",
    "MEDICAL_LICENSE":    "Licences médicales",
    "URL":                "URLs et liens web",
    "IP_ADDRESS":         "Adresses IP",
    "FR_NIR":             "Numéro INSEE / Sécurité Sociale (15 chiffres)",
    "FR_SIRET":           "SIRET — identifiant établissement (14 chiffres)",
    "FR_SIREN":           "SIREN — identifiant entreprise (9 chiffres)",
    "FR_TVA":             "Numéro TVA intracommunautaire",
    "FR_PASSPORT":        "Numéro de passeport français",
    "FR_CNI":             "Carte Nationale d'Identité (12 chiffres)",
    "FR_DRIVING_LICENSE": "Permis de conduire format post-2013 (AA-NNN-AA)",
    "FR_POSTAL_CODE":     "Code postal français (avec contexte)",
    "DATE_TIME":          "Dates et heures — opt-in, génèrent du bruit par défaut",
    "FILE_PATH":          "Chemins de fichiers Windows/Unix — opt-in",
}

# (field_name, label, entities_covered, default_on)
_ENTITY_GROUPS: list[tuple[str, str, list[str], bool]] = [
    (
        "personnes",
        "Personnes — noms et prénoms",
        ["PERSON"],
        True,
    ),
    (
        "identite",
        "Documents d'identité — NIR/sécu, CNI, passeport, permis, licences",
        ["FR_NIR", "FR_CNI", "FR_PASSPORT", "FR_DRIVING_LICENSE", "MEDICAL_LICENSE"],
        True,
    ),
    (
        "organisations",
        "Organisations — noms, SIRET, SIREN, TVA",
        ["ORGANIZATION", "FR_SIRET", "FR_SIREN", "FR_TVA"],
        True,
    ),
    (
        "contacts",
        "Coordonnées — e-mails et téléphones",
        ["EMAIL_ADDRESS", "PHONE_NUMBER"],
        True,
    ),
    (
        "localisation",
        "Localisation — lieux, adresses, codes postaux",
        ["LOCATION", "FR_POSTAL_CODE"],
        True,
    ),
    (
        "financier",
        "Données financières — IBAN et cartes bancaires",
        ["IBAN_CODE", "CREDIT_CARD"],
        True,
    ),
    (
        "web",
        "Identifiants numériques — URLs et adresses IP",
        ["URL", "IP_ADDRESS"],
        True,
    ),
    (
        "dates_et_fichiers",
        "Dates / chemins de fichiers (opt-in — peuvent générer du bruit)",
        ["DATE_TIME", "FILE_PATH"],
        False,
    ),
]


# Groupes couverts par chaque profil (noms des clés de _ENTITY_GROUPS)
_PRESET_GROUPS = {
    "base":    ["personnes", "organisations", "contacts"],
    "avancee": ["personnes", "identite", "organisations", "contacts",
                "localisation", "financier", "web"],
}

_PRESET_SCHEMA = create_model(
    "ProfilAnonymisation",
    profil=(
        str,
        Field(
            default="avancee",
            description=(
                "Tapez le profil voulu :\n"
                "  base        — Personnes · Organisations · Contacts\n"
                "  avancee     — Identité · Localisation · Financier · Web + base\n"
                "  personnalise — précisez les catégories ci-dessous"
            ),
        ),
    ),
    categories=(
        str,
        Field(
            default="",
            description=(
                "Profil personnalise uniquement — listez les catégories séparées par des virgules :\n"
                "personnes, identite, organisations, contacts, localisation, financier, web, dates_et_fichiers"
            ),
        ),
    ),
)

_DOSSIER_TYPE_SCHEMA = create_model(
    "TypeDossier",
    type_dossier=(
        str,
        Field(
            default="autre",
            description=(
                "Type de dossier juridique — choisissez parmi :\n"
                "  defense — Mémoire en défense (réponse à un pourvoi adverse)\n"
                "  demande — Mémoire ampliatif / pourvoi en cassation\n"
                "  autre   — Autre type de dossier (espace de travail générique)"
            ),
        ),
    ),
)


def _resolve_preset(profil: str, categories_text: str, language: str) -> list[str]:
    """Traduit un profil (base/avancee/personnalise) en liste de types d'entités."""
    key = profil.strip().lower()
    valid_groups = {g[0] for g in _ENTITY_GROUPS}

    if key in _PRESET_GROUPS:
        selected = _PRESET_GROUPS[key]
    else:
        # Profil personnalisé : parse le texte libre
        tokens = [t.strip().lower() for t in categories_text.replace(",", " ").split()]
        selected = [t for t in tokens if t in valid_groups]
        if not selected:
            selected = _PRESET_GROUPS["avancee"]  # fallback

    result: list[str] = []
    for field_name, _, entities, _ in _ENTITY_GROUPS:
        if field_name not in selected:
            continue
        for entity in entities:
            if entity in _FRENCH_ONLY and language != "fr":
                continue
            if entity not in result:
                result.append(entity)
    return result


def _get_analyzer(language: str):
    """Retourne l'analyseur Presidio pour la langue, en le construisant une seule fois."""
    if language not in _analyzer_cache:
        with _cache_lock:
            if language not in _analyzer_cache:
                _analyzer_cache[language] = build_analyzer(language)
    return _analyzer_cache[language]


def _validate_entities(entities: Optional[list[str]]) -> tuple[list[str], list[str]]:
    """Retourne (entités_valides, entités_inconnues)."""
    if entities is None:
        return DEFAULT_ENTITIES, []
    all_known = set(ENTITY_LABELS.keys())
    valid = [e for e in entities if e in all_known]
    unknown = [e for e in entities if e not in all_known]
    return (valid if valid else DEFAULT_ENTITIES), unknown


_GLOBAL_INDEX_NAME = "_nomos_index.md"
_GLOBAL_ROW_RE = re.compile(r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`([^`]+)`\s*\|$")


def _find_confidential_dir(input_path: Path, output_path: Path) -> Optional[Path]:
    """Localise le répertoire documents-confidentiels/ du projet NomosAI.

    Cherche d'abord dans les ancêtres du fichier d'entrée (cas typique : le fichier
    est dans documents-confidentiels/ ou ses sources sont dans un projet NomosAI initié).
    Cherche ensuite dans les ancêtres du fichier de sortie.
    """
    for path in (input_path, output_path):
        for ancestor in path.parents:
            if ancestor.name == "documents-confidentiels" and ancestor.is_dir():
                return ancestor
        for ancestor in path.parents:
            candidate = ancestor / "documents-confidentiels"
            if candidate.is_dir():
                return candidate
    return None


def _read_global_index(conf_dir: Path) -> list[dict]:
    """Lit _nomos_index.md depuis documents-confidentiels/ et retourne les entrées existantes."""
    index_path = conf_dir / _GLOBAL_INDEX_NAME
    if not index_path.exists():
        return []
    entries = []
    try:
        for line in index_path.read_text(encoding="utf-8").splitlines():
            m = _GLOBAL_ROW_RE.match(line.strip())
            if not m:
                continue
            placeholder = m.group(1)
            original = m.group(2).strip().replace(r"\|", "|").replace(r"\n", "\n")
            entity_type = m.group(3).strip()
            if placeholder and original and entity_type:
                from nomosai.engine import ENTITY_LABELS as _EL
                entries.append({
                    "placeholder": placeholder,
                    "original": original,
                    "entity_type": entity_type,
                    "label": _EL.get(entity_type, entity_type),
                })
    except Exception:
        pass
    return entries


def _merge_index_entries(existing: list[dict], new: list[dict]) -> list[dict]:
    """Fusionne deux listes d'entrées d'index (clé unique = placeholder)."""
    merged = {e["placeholder"]: e for e in existing}
    for entry in new:
        merged[entry["placeholder"]] = entry
    return list(merged.values())


def _write_global_index(conf_dir: Path, entries: list[dict]) -> Path:
    """Écrit (ou met à jour) _nomos_index.md dans documents-confidentiels/."""
    index_path = conf_dir / _GLOBAL_INDEX_NAME
    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "---",
        f"generated: {date_str}",
        f"total_entities: {len(entries)}",
        "---",
        "",
        "# Index global d'anonymisation NomosAI",
        "",
        "> Ce fichier est **confidentiel** — il contient les données personnelles originales.",
        "> Ne pas inclure dans les exports anonymisés.",
        "",
        "| Placeholder | Valeur originale | Entité |",
        "| --- | --- | --- |",
    ]
    for entry in sorted(entries, key=lambda e: (e.get("label", ""), e["placeholder"])):
        original = (
            entry["original"]
            .replace("|", "\\|")
            .replace("\r\n", "\\n")
            .replace("\n", "\\n")
            .replace("\r", "\\n")
        )
        lines.append(f"| `{entry['placeholder']}` | {original} | `{entry['entity_type']}` |")
    lines += ["", "---", ""]
    index_path.write_text("\n".join(lines), encoding="utf-8")
    return index_path


# ---------------------------------------------------------------------------
# Gabarits pour initiate_project
# ---------------------------------------------------------------------------

_HOOK_SCRIPT = '''\
#!/usr/bin/env python3
"""Hook NomosAI — bloque la lecture directe dans documents-confidentiels/"""
import json
import pathlib
import sys


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    path_str = data.get("file_path", data.get("path", ""))
    if not path_str:
        sys.exit(0)

    try:
        parts = pathlib.PurePath(path_str).parts
    except Exception:
        sys.exit(0)

    if "documents-confidentiels" in parts:
        print("BLOQUE : Lecture directe interdite dans documents-confidentiels/", file=sys.stderr)
        print("Ce dossier contient des donnees a caractere personnel (DCP).", file=sys.stderr)
        print("Utilisez anonymize_file via le serveur MCP nomos-ai.", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
'''

# Données embarquées dans le package (templates et skills).
# Path(__file__).parent = src/nomosai/ → toujours résolu correctement,
# que ce soit en développement ou après installation via pip/uvx.
_DATA_DIR = Path(__file__).parent / "references"
_TEMPLATES_DIR = _DATA_DIR / "Claude_templates"
_NOMOS_SKILLS_SRC_DIR = _DATA_DIR / "nomos-skills"

_TEMPLATE_FILES: dict[str, str] = {
    "defense": "dossier-defense.md",
    "demande": "dossier-demande.md",
}


def _build_claude_md(project_name: str, dossier_type: Optional[str] = None) -> str:
    base = f"""\
# {project_name}

Espace de travail juridique assisté par IA. Tâches : recherche sémantique, rédaction et édition de textes juridiques.

## Répertoires

Respecter la structure de répertoires et le role de chacun des dossiers par defaults.

| Répertoire                    | Rôle                                                        |
|-------------------------------|-------------------------------------------------------------|
| `documents-confidentiels/`    | DCP — lecture directe **interdite**, anonymiser via MCP     |
| `sources/`                    | Documents lisibles directement (publics ou anonymisés)      |
| `documents-anonymisés/`       | Sorties de `anonymize_file` fichier anonymisés accessibles  |
| `livrables/`                  | Livrables finaux ecrire les fichiers ici                    |
| `artefacts/`                  | Fichiers temporaires — supprimer dès que possible           |

## Règles

1. **Confidentialité** : ne jamais lire `documents-confidentiels/` directement. Utiliser uniquement l'outil `anonymize_file` du MCP `nomos-ai`.
2. **Pas de code** sauf si explicitement demandé ou strictement nécessaire.
3. **Nettoyage** : supprimer les artefacts dès qu'ils ne sont plus utiles.
"""
    if dossier_type and dossier_type in _TEMPLATE_FILES:
        template_path = _TEMPLATES_DIR / _TEMPLATE_FILES[dossier_type]
        if template_path.exists():
            base += "\n---\n\n" + template_path.read_text(encoding="utf-8")
    return base


def _build_settings() -> str:
    settings = {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Read|Edit",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "python .claude/hooks/block_confidentiel.py",
                        }
                    ],
                }
            ]
        }
    }
    return json.dumps(settings, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# ArianeWeb — constantes et helpers
# ---------------------------------------------------------------------------

_AW_SEARCH_URL = "https://www.conseil-etat.fr/xsearch"
_AW_CONCLUSION_BASE = "https://www.conseil-etat.fr/fr/arianeweb/CRP/conclusion"
_AW_UA = "Mozilla/5.0 (compatible; NomosAI/1.0)"
_AW_VALID_FUNDS = {"AW_DCE", "AW_DCA", "AW_DTC", "AW_CRP", "AW_AJCE", "AW_AJTC"}


def _aw_fetch(params: dict) -> dict:
    url = _AW_SEARCH_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": _AW_UA})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _aw_doc_to_dict(doc: dict) -> dict:
    date_raw = doc.get("SourceDateTime1", "")
    return {
        "id": doc.get("Id", ""),
        "collection": doc.get("Collection", ""),
        "numero": doc.get("SourceStr5", ""),
        "numeros": doc.get("SourceCsv1", ""),
        "juridiction": doc.get("SourceStr3", ""),
        "formation": doc.get("SourceStr7", ""),
        "date": date_raw[:10] if date_raw else "",
        "solution": doc.get("SourceStr12", ""),
        "publication": doc.get("SourceStr8", ""),
        "procedure": doc.get("SourceStr9", ""),
        "ecli": doc.get("SourceStr30", ""),
        "pcja_codes": doc.get("SourceCsv3", ""),
        "resume": doc.get("SourceStr21", ""),
        "linked_decision": doc.get("SourceCsv2", ""),
    }


# ---------------------------------------------------------------------------
# Outils MCP
# ---------------------------------------------------------------------------

@mcp.tool()
async def anonymize_file(
    ctx: Context,
    file_path: str,
    output_path: Optional[str] = None,
    language: str = "fr",
    entities: Optional[list[str]] = None,
    elicit_entities: bool = False,
    score_threshold: float = 0.55,
    write_index: bool = True,
) -> dict:
    """
    Anonymise un fichier document (.docx, .pdf, .txt, .md, .rst).

    Lit le document, détecte et remplace les PII, puis écrit un fichier Markdown
    anonymisé avec frontmatter YAML. Génère optionnellement
    un fichier d'index confidentiel (placeholder → valeur originale).

    Args:
        ctx: Contexte MCP (injecté automatiquement par FastMCP).
        file_path: Chemin absolu ou relatif vers le document source.
        output_path: Chemin du fichier .md de sortie. Par défaut : <nom>_anonymise.md.
        language: Code langue — 'fr' (défaut), 'en', 'de', 'es', 'it', 'nl', 'pt'.
        entities: Types d'entités à détecter. None = tous les types par défaut.
        elicit_entities: Si True et entities est None, présente un formulaire interactif
            pour que l'utilisateur choisisse les types d'entités. Ignoré si entities
            est fourni. Défaut False.
        score_threshold: Seuil de confiance 0.0–1.0 (défaut 0.55).
        write_index: Écrire le fichier d'index confidentiel (défaut True).

    Returns:
        dict avec : success, input_path, output_path, index_path, stats, total_entities
    """
    input_p = Path(file_path).resolve()

    if not input_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {input_p}",
        }

    suffix = input_p.suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        return {
            "success": False,
            "error_type": "UnsupportedFormat",
            "error": (
                f"Format '{suffix}' non supporté. "
                f"Supportés : {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
            ),
        }

    if language not in SUPPORTED_LANGUAGES:
        return {
            "success": False,
            "error_type": "UnsupportedLanguage",
            "error": f"Langue '{language}' non supportée. Supportées : {sorted(SUPPORTED_LANGUAGES)}",
        }

    elicitation_fallback = False
    if elicit_entities and entities is None:
        try:
            elicit_result = await ctx.elicit(
                message=(
                    "Choisissez un profil d'anonymisation :\n"
                    "  base         — Personnes · Organisations · Contacts\n"
                    "  avancee      — + Identité · Localisation · Financier · Web\n"
                    "  personnalise — listez vos catégories dans le champ ci-dessous\n\n"
                    "Refuser = réglages par défaut."
                ),
                schema=_PRESET_SCHEMA,
            )
            if elicit_result.action == "accept" and elicit_result.data is not None:
                data = elicit_result.data.model_dump()
                entities = _resolve_preset(
                    data.get("profil", "avancee"),
                    data.get("categories", ""),
                    language,
                )
            else:
                elicitation_fallback = True
        except Exception:
            elicitation_fallback = True

    out_p = (
        Path(output_path).resolve()
        if output_path
        else input_p.with_name(input_p.stem + "_anonymise.md")
    )

    valid_entities, unknown = _validate_entities(entities)

    try:
        analyzer = _get_analyzer(language)
    except OSError as e:
        model = _SPACY_MODELS.get(language, f"{language}_core_news_lg")
        return {
            "success": False,
            "error_type": "SpacyModelMissing",
            "error": f"Exécutez : python -m spacy download {model}",
            "detail": str(e),
        }

    try:
        blocks = read_document(input_p)
    except Exception as e:
        return {"success": False, "error_type": "ReadError", "error": str(e)}

    if not blocks:
        return {
            "success": False,
            "error_type": "EmptyDocument",
            "error": f"Aucun texte extrait de {input_p.name}",
        }

    conf_dir = _find_confidential_dir(input_p, out_p)

    anonymizer = DocumentAnonymizer(
        analyzer,
        language=language,
        score_threshold=score_threshold,
    )

    # Pré-charge l'index global pour garantir la cohérence des placeholders
    # entre tous les documents du projet.
    existing_entries: list[dict] = []
    if conf_dir:
        existing_entries = _read_global_index(conf_dir)
        if existing_entries:
            anonymizer.load_index(existing_entries)

    try:
        anon_blocks = anonymizer.anonymize_blocks(blocks, valid_entities)
        md = to_markdown(
            anon_blocks,
            source_path=input_p,
            language=language,
            stats=dict(anonymizer.stats),
            score_threshold=score_threshold,
        )
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(md, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "AnonymizationError", "error": str(e)}

    index_path_str = None
    if write_index:
        try:
            target_dir = conf_dir if conf_dir else out_p.parent
            all_entries = _merge_index_entries(existing_entries, anonymizer.get_index())
            idx_p = _write_global_index(target_dir, all_entries)
            index_path_str = str(idx_p)
        except Exception:
            pass  # non bloquant : l'anonymisation a réussi

    result = {
        "success": True,
        "input_path": str(input_p),
        "output_path": str(out_p),
        "index_path": index_path_str,
        "format_detected": suffix,
        "stats": dict(anonymizer.stats),
        "total_entities": sum(anonymizer.stats.values()),
        "language": language,
        "score_threshold": score_threshold,
    }
    if unknown:
        result["warnings"] = [f"Types d'entités inconnus ignorés : {unknown}"]
    if elicitation_fallback:
        result["elicitation_fallback"] = True
    return result


@mcp.tool()
def deanonymize_file(
    anonymized_file_path: str,
    index_path: Optional[str] = None,
    output_path: Optional[str] = None,
) -> dict:
    """
    Restaure un document anonymisé NomosAI en remplaçant les placeholders
    ([PERSONNE_1], [EMAIL_2]…) par les valeurs originales stockées dans l'index.

    L'index est le fichier confidentiel <nom>-index.md généré lors de l'anonymisation.
    Si index_path est absent, il est cherché automatiquement à côté du fichier anonymisé
    sous le nom <stem>-index.md.

    Args:
        anonymized_file_path: Chemin vers le fichier .md anonymisé.
        index_path: Chemin vers le fichier index (-index.md). Auto-détecté si absent.
        output_path: Chemin de sortie. Par défaut : <stem>_restaure.md.

    Returns:
        dict avec : success, input_path, index_path, output_path, replacements_count
    """
    _ROW_RE = re.compile(
        r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`[^`]+`\s*\|$"
    )

    doc_p = Path(anonymized_file_path).resolve()

    if not doc_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {doc_p}",
        }

    if doc_p.suffix.lower() != ".md":
        return {
            "success": False,
            "error_type": "InvalidFormat",
            "error": f"Le fichier doit être un .md anonymisé (reçu : {doc_p.suffix!r})",
        }

    # Résolution de l'index
    if index_path:
        idx_p = Path(index_path).resolve()
        if not idx_p.exists():
            return {
                "success": False,
                "error_type": "FileNotFound",
                "error": f"Index introuvable : {idx_p}",
            }
    else:
        # 1. Index global NomosAI dans documents-confidentiels/ (nouveau comportement)
        conf_dir = _find_confidential_dir(doc_p, doc_p)
        global_idx = (conf_dir / _GLOBAL_INDEX_NAME) if conf_dir else None
        # 2. Ancien index par document à côté du fichier (rétrocompatibilité)
        legacy_idx = doc_p.with_name(doc_p.stem + "-index.md")

        if global_idx and global_idx.exists():
            idx_p = global_idx
        elif legacy_idx.exists():
            idx_p = legacy_idx
        else:
            return {
                "success": False,
                "error_type": "IndexNotFound",
                "error": (
                    f"Aucun index trouvé (cherché : {global_idx}, {legacy_idx}).\n"
                    "Utilisez index_path pour en spécifier un explicitement."
                ),
            }

    # Parsing de l'index
    try:
        content = idx_p.read_text(encoding="utf-8")
        mapping: dict[str, str] = {}
        for line in content.splitlines():
            m = _ROW_RE.match(line.strip())
            if not m:
                continue
            placeholder = m.group(1)
            original = m.group(2).strip().replace(r"\|", "|").replace(r"\n", "\n")
            mapping[placeholder] = original
    except Exception as e:
        return {"success": False, "error_type": "IndexParseError", "error": str(e)}

    if not mapping:
        return {
            "success": False,
            "error_type": "EmptyIndex",
            "error": f"Aucun placeholder trouvé dans l'index : {idx_p}",
        }

    # Restauration du texte
    try:
        text = doc_p.read_text(encoding="utf-8")
        replacements = sum(text.count(ph) for ph in mapping)
        # Remplacer les plus longs en premier (évite [PERSONNE_1] avant [PERSONNE_10])
        for placeholder in sorted(mapping, key=len, reverse=True):
            text = text.replace(placeholder, mapping[placeholder])

        stem = doc_p.stem.removesuffix("_anonymise")
        out_p = Path(output_path).resolve() if output_path else doc_p.with_name(stem + "_restaure.md")
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(text, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "RestoreError", "error": str(e)}

    return {
        "success": True,
        "input_path": str(doc_p),
        "index_path": str(idx_p),
        "output_path": str(out_p),
        "entries_in_index": len(mapping),
        "replacements_count": replacements,
    }


@mcp.tool()
def list_entities(language: str = "fr") -> dict:
    """
    Liste tous les types de PII que NomosAI peut détecter.

    Ne nécessite pas de chargement d'analyseur — répond instantanément.
    Les entités FR_* sont uniquement disponibles avec language='fr'.
    Les entités opt-in (DATE_TIME, FILE_PATH) doivent être explicitement
    listées dans le paramètre 'entities' de anonymize_file.

    Args:
        language: Code langue pour filtrer les entités pertinentes.

    Returns:
        dict avec : default_entities, opt_in_entities, total_default, total_opt_in
    """
    default_list = []
    opt_in_list = []

    for entity_type, label in ENTITY_LABELS.items():
        is_opt_in = entity_type in _OPT_IN_ENTITIES
        is_french_only = entity_type in _FRENCH_ONLY

        if is_french_only and language != "fr":
            continue

        entry = {
            "entity_type": entity_type,
            "label": label,
            "description": _ENTITY_DESCRIPTIONS.get(entity_type, ""),
            "opt_in": is_opt_in,
        }
        if is_french_only:
            entry["french_only"] = True

        if is_opt_in:
            opt_in_list.append(entry)
        else:
            default_list.append(entry)

    return {
        "language": language,
        "default_entities": default_list,
        "opt_in_entities": opt_in_list,
        "total_default": len(default_list),
        "total_opt_in": len(opt_in_list),
        "note": (
            "Les entités opt_in doivent être explicitement listées dans le paramètre "
            "'entities' pour être activées."
        ),
    }


@mcp.tool()
def search_arianeweb(
    query: Optional[str] = None,
    numero: Optional[str] = None,
    fund: str = "AW_DCE",
    page_size: int = 10,
    offset: int = 0,
    pcja: Optional[str] = None,
) -> dict:
    """
    Recherche dans la base ArianeWeb du Conseil d'État.

    Interroge l'API xsearch et retourne les métadonnées structurées des décisions
    ou conclusions. Remplace les appels WebFetch manuels à l'API xsearch.

    Args:
        query: Termes de recherche plein texte (ex. : "responsabilité puissance publique").
        numero: Numéro de requête (ex. : "489441"). Prioritaire sur query.
        fund: Fond de jurisprudence :
              "AW_DCE"  — Décisions CE (défaut)
              "AW_DCA"  — Décisions CAA
              "AW_DTC"  — Tribunal des conflits
              "AW_CRP"  — Conclusions des rapporteurs publics
        page_size: Résultats par page (défaut 10, max 50).
        offset: Décalage pour la pagination (défaut 0).
        pcja: Code PCJA pour filtrer par rubrique (ex. : "60-01-02-01").
              Match exact sur la valeur — ne remonte pas les sous-rubriques.

    Returns:
        dict avec : success, total, fund, documents (liste de métadonnées).
        Chaque document expose : numero, numeros, juridiction, formation, date,
        solution, publication, procedure, ecli, pcja_codes, resume, linked_decision.
    """
    if not query and not numero and not pcja:
        return {"success": False, "error": "Au moins un paramètre parmi query, numero, pcja est requis."}

    if fund not in _AW_VALID_FUNDS:
        return {"success": False, "error": f"Fund inconnu : '{fund}'. Valeurs : {sorted(_AW_VALID_FUNDS)}"}

    params: dict = {
        "advanced": "1",
        "type": "json",
        "SourceStr4": fund,
        "SkipCount": str(min(page_size, 50)),
        "SkipFrom": str(offset),
        "sort": "SourceDateTime1.desc",
        "synonyms": "true",
        "scmode": "smart",
    }
    if query:
        params["text.add"] = query
    if numero:
        params["sourcecsv1"] = numero
    if pcja:
        params["sourcecsv3"] = pcja

    try:
        data = _aw_fetch(params)
    except Exception as e:
        return {"success": False, "error": f"Erreur réseau ArianeWeb : {e}"}

    return {
        "success": True,
        "total": data.get("TotalCount", 0),
        "page_size": page_size,
        "offset": offset,
        "fund": fund,
        "documents": [_aw_doc_to_dict(d) for d in data.get("Documents", [])],
    }


@mcp.tool()
def get_conclusion(numero: str) -> dict:
    """
    Télécharge et extrait le texte intégral des conclusions du rapporteur public
    pour un numéro de requête CE.

    Interroge ArianeWeb CRP pour obtenir la date et les métadonnées, télécharge
    le PDF officiel, puis en extrait le texte complet via pdfminer.

    Args:
        numero: Numéro de requête principal (ex. : "368082"). Si la conclusion
                couvre plusieurs requêtes jointes, n'importe lequel suffit.

    Returns:
        dict avec : success, numero, numeros, date, ecli, formation, publication,
        linked_decision, resume, pdf_url, text, copyright.
        Le champ text contient le texte intégral des conclusions.
    """
    # --- Métadonnées CRP ---
    try:
        data = _aw_fetch({
            "advanced": "1",
            "type": "json",
            "SourceStr4": "AW_CRP",
            "sourcecsv1": numero,
            "SkipCount": "1",
            "SkipFrom": "0",
        })
    except Exception as e:
        return {"success": False, "error": f"Erreur API ArianeWeb : {e}"}

    docs = data.get("Documents", [])
    if not docs:
        return {"success": False, "error": f"Aucune conclusion trouvée pour le n° {numero} dans AW_CRP."}

    doc = docs[0]
    date_raw = doc.get("SourceDateTime1", "")
    date_str = date_raw[:10] if date_raw else ""

    if not date_str:
        return {"success": False, "error": "Date des conclusions introuvable dans les métadonnées."}

    # SourceStr5 est le numéro canonique (peut différer si l'entrée était un numéro joint)
    primary = doc.get("SourceStr5", numero)

    # --- Téléchargement du PDF ---
    pdf_url = f"{_AW_CONCLUSION_BASE}/{date_str}/{primary}?download_pdf="
    try:
        req = urllib.request.Request(pdf_url, headers={"User-Agent": _AW_UA})
        with urllib.request.urlopen(req, timeout=30) as resp:
            pdf_bytes = resp.read()
    except Exception as e:
        return {"success": False, "error": f"Erreur téléchargement PDF ({pdf_url}) : {e}"}

    # --- Extraction du texte ---
    try:
        text = _pdf_extract_text(io.BytesIO(pdf_bytes))
    except Exception as e:
        return {"success": False, "error": f"Erreur extraction texte PDF : {e}"}

    return {
        "success": True,
        "numero": primary,
        "numeros": doc.get("SourceCsv1", primary),
        "date": date_str,
        "ecli": doc.get("SourceStr30", ""),
        "formation": doc.get("SourceStr7", ""),
        "publication": doc.get("SourceStr8", ""),
        "linked_decision": doc.get("SourceCsv2", ""),
        "resume": doc.get("SourceStr21", ""),
        "pdf_url": pdf_url,
        "text": text.strip(),
        "copyright": (
            "Ces conclusions ne sont pas libres de droits. Leur citation doit respecter "
            "le code de la propriété intellectuelle. Toute rediffusion, commerciale ou non, "
            "est subordonnée à l'accord du rapporteur public."
        ),
    }


@mcp.tool()
async def initiate_project(
    ctx: Context,
    directory: str,
    project_name: Optional[str] = None,
    dossier_type: Optional[str] = None,
) -> dict:
    """
    Initialise un espace de travail juridique NomosAI dans le répertoire spécifié.

    Crée la structure de répertoires standard, un fichier CLAUDE.md adapté au
    type de dossier, et un hook de sécurité qui bloque la lecture directe des
    fichiers dans le dossier documents-confidentiels/.

    Si dossier_type est absent, demande interactivement à l'utilisateur de choisir
    parmi les types disponibles : defense, demande, autre.

    Structure créée :
        documents-confidentiels/   — Documents confidentiels (DCP) : traitement via nomos-ai MCP uniquement
        sources/                   — Documents sources lisibles directement par l'agent
        documents-anonymisés/      — Sorties anonymisées produites par NomosAI
        livrables/                 — Livrables finaux en cours de production
        artefacts/                 — Fichiers temporaires produits par l'agent (à nettoyer)
        .claude/settings.json      — Hook bloquant la lecture directe de documents-confidentiels/
        CLAUDE.md                  — Instructions de l'agent adaptées au type de dossier

    Args:
        ctx: Contexte MCP (injecté automatiquement par FastMCP).
        directory: Chemin absolu ou relatif vers le répertoire du projet.
                   Le répertoire est créé s'il n'existe pas.
        project_name: Nom du projet (titre du CLAUDE.md). Défaut : nom du répertoire.
        dossier_type: Type de dossier juridique. Valeurs acceptées : "defense", "demande", "autre".
                      Si None, une question interactive est posée à l'utilisateur.

    Returns:
        dict avec : success, project_path, dossier_type, template_loaded, created_dirs,
                    claude_md_path, hook_path, settings_path
    """
    if dossier_type is None:
        try:
            elicit_result = await ctx.elicit(
                message=(
                    "Quel type de dossier souhaitez-vous initialiser ?\n\n"
                    "  defense — Mémoire en défense (réponse à un pourvoi adverse)\n"
                    "  demande — Mémoire ampliatif / pourvoi en cassation\n"
                    "  autre   — Autre type de dossier (espace de travail générique)\n\n"
                    "Refuser = espace générique par défaut."
                ),
                schema=_DOSSIER_TYPE_SCHEMA,
            )
            if elicit_result.action == "accept" and elicit_result.data is not None:
                chosen = elicit_result.data.model_dump().get("type_dossier", "autre").strip().lower()
                dossier_type = chosen if chosen in _TEMPLATE_FILES else None
        except Exception:
            dossier_type = None

    project_path = Path(directory).resolve()

    try:
        project_path.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer le répertoire : {e}",
        }

    name = project_name or project_path.name

    subdirs = ["documents-confidentiels", "sources", "documents-anonymisés", "livrables", "artefacts"]
    created_dirs: list[str] = []
    for subdir in subdirs:
        subdir_path = project_path / subdir
        try:
            subdir_path.mkdir(exist_ok=True)
            created_dirs.append(str(subdir_path))
        except Exception as e:
            return {
                "success": False,
                "error_type": "DirectoryCreateError",
                "error": f"Impossible de créer {subdir}/ : {e}",
                "created_dirs": created_dirs,
            }

    hooks_dir = project_path / ".claude" / "hooks"
    try:
        hooks_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer .claude/hooks/ : {e}",
        }

    hook_script_path = hooks_dir / "block_confidentiel.py"
    try:
        hook_script_path.write_text(_HOOK_SCRIPT, encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire le script de hook : {e}",
        }

    settings_path = project_path / ".claude" / "settings.json"
    try:
        settings_path.write_text(_build_settings(), encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire settings.json : {e}",
        }

    template_loaded = (
        dossier_type is not None
        and dossier_type in _TEMPLATE_FILES
        and (_TEMPLATES_DIR / _TEMPLATE_FILES[dossier_type]).exists()
    )

    claude_md_path = project_path / "CLAUDE.md"
    try:
        claude_md_path.write_text(_build_claude_md(name, dossier_type=dossier_type), encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire CLAUDE.md : {e}",
        }

    return {
        "success": True,
        "project_path": str(project_path),
        "project_name": name,
        "dossier_type": dossier_type or "generic",
        "template_loaded": template_loaded,
        "created_dirs": created_dirs,
        "claude_md_path": str(claude_md_path),
        "hook_path": str(hook_script_path),
        "settings_path": str(settings_path),
        "message": (
            f"Projet '{name}' initialisé"
            + (f" (type : {dossier_type})" if dossier_type else "")
            + ". "
            "Le hook bloque la lecture directe de documents-confidentiels/ (outils Read et Edit). "
            "Placez les documents confidentiels dans documents-confidentiels/ et utilisez "
            "anonymize_file via nomos-ai MCP pour les traiter."
        ),
    }


@mcp.tool()
def initialise_nomos_skills(
    skills_dir: Optional[str] = None,
) -> dict:
    """
    Installe les skills Claude NomosAI pour l'assistance juridique par IA.

    Copie dans le dossier de configuration Claude (par défaut ~/.claude/skills/)
    les skills juridiques NomosAI présents dans references/nomos-skills/.
    Les skills déjà présents ne sont pas écrasés.

    Skills disponibles : extraction de faits, recherche jurisprudentielle
    (Cour de cassation, Conseil d'État, CJUE, BOFIP), rédaction de mémoires
    (mémoire ampliatif / en défense cassation, moyens de cassation).

    Args:
        skills_dir: Chemin vers le dossier skills Claude.
                    Par défaut : ~/.claude/skills/
                    NOTE pour Claude : si l'utilisateur ne précise pas ce chemin,
                    déterminer le dossier de configuration Claude de la machine
                    (souvent ~/.claude/) avant d'appeler cet outil, puis passer
                    le sous-dossier skills/ correspondant.

    Returns:
        dict avec : success, skills_dir, installed, already_present,
                    total_available, total_installed
    """
    target = Path(skills_dir).expanduser().resolve() if skills_dir else Path.home() / ".claude" / "skills"

    src = _NOMOS_SKILLS_SRC_DIR
    if not src.exists():
        return {
            "success": False,
            "error_type": "SkillsSourceNotFound",
            "error": f"Dossier de skills source introuvable : {src}",
        }

    try:
        target.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer le dossier skills : {e}",
        }

    skill_dirs = [
        item for item in sorted(src.iterdir())
        if item.is_dir() and not item.name.startswith(".") and (item / "SKILL.md").exists()
    ]

    installed: list[str] = []
    already_present: list[str] = []
    errors: list[dict] = []

    for skill_dir in skill_dirs:
        dest = target / skill_dir.name
        if dest.exists():
            already_present.append(skill_dir.name)
            continue
        try:
            shutil.copytree(
                skill_dir,
                dest,
                ignore=shutil.ignore_patterns(".git", ".gitignore"),
            )
            installed.append(skill_dir.name)
        except Exception as e:
            errors.append({"skill": skill_dir.name, "error": str(e)})

    result: dict = {
        "success": True,
        "skills_dir": str(target),
        "installed": installed,
        "already_present": already_present,
        "total_available": len(skill_dirs),
        "total_installed": len(installed),
    }
    if errors:
        result["errors"] = errors
        result["success"] = len(installed) > 0 or len(already_present) > 0
    return result


@mcp.tool()
async def update_nomos_skills(
    ctx: Context,
    skills_dir: Optional[str] = None,
) -> dict:
    """
    Met à jour des skills Claude NomosAI déjà installés (écrase la version installée).

    Découvre les skills disponibles dans le package NomosAI, présente la liste
    à l'utilisateur via un formulaire interactif, puis écrase les skills sélectionnés
    dans le dossier ~/.claude/skills/ (ou le chemin fourni).

    Contrairement à initialise_nomos_skills, cet outil écrase les skills existants.

    Args:
        ctx: Contexte MCP (injecté automatiquement par FastMCP).
        skills_dir: Chemin vers le dossier skills Claude.
                    Par défaut : ~/.claude/skills/
                    NOTE pour Claude : si l'utilisateur ne précise pas ce chemin,
                    déterminer le dossier de configuration Claude de la machine
                    (souvent ~/.claude/) avant d'appeler cet outil, puis passer
                    le sous-dossier skills/ correspondant.

    Returns:
        dict avec : success, skills_dir, updated, skipped, total_available, total_updated
    """
    target = Path(skills_dir).expanduser().resolve() if skills_dir else Path.home() / ".claude" / "skills"

    src = _NOMOS_SKILLS_SRC_DIR
    if not src.exists():
        return {
            "success": False,
            "error_type": "SkillsSourceNotFound",
            "error": f"Dossier de skills source introuvable : {src}",
        }

    skill_dirs = [
        item for item in sorted(src.iterdir())
        if item.is_dir() and not item.name.startswith(".") and (item / "SKILL.md").exists()
    ]

    if not skill_dirs:
        return {
            "success": False,
            "error_type": "NoSkillsFound",
            "error": "Aucun skill trouvé dans le dossier source.",
        }

    def _field_name(name: str) -> str:
        return re.sub(r"[^a-zA-Z0-9]", "_", name).strip("_")

    field_to_skill: dict[str, Path] = {_field_name(sd.name): sd for sd in skill_dirs}

    skill_fields = {
        fname: (
            bool,
            Field(default=False, description=f"Mettre à jour le skill « {sd.name} »"),
        )
        for fname, sd in field_to_skill.items()
    }
    SelectionSchema = create_model("SelectionSkills", **skill_fields)

    skills_list = "\n".join(f"  • {sd.name}" for sd in skill_dirs)
    try:
        elicit_result = await ctx.elicit(
            message=(
                f"Sélectionnez les skills à mettre à jour :\n\n{skills_list}\n\n"
                "Cochez les skills que vous souhaitez écraser avec la version la plus récente."
            ),
            schema=SelectionSchema,
        )
    except Exception as e:
        return {"success": False, "error_type": "ElicitError", "error": str(e)}

    if elicit_result.action != "accept" or elicit_result.data is None:
        return {
            "success": True,
            "message": "Mise à jour annulée par l'utilisateur.",
            "updated": [],
            "skipped": [sd.name for sd in skill_dirs],
            "errors": [],
            "total_available": len(skill_dirs),
            "total_updated": 0,
        }

    selected_data = elicit_result.data.model_dump()
    selected = [
        field_to_skill[fname]
        for fname, chosen in selected_data.items()
        if chosen and fname in field_to_skill
    ]

    if not selected:
        return {
            "success": True,
            "message": "Aucun skill sélectionné.",
            "updated": [],
            "skipped": [sd.name for sd in skill_dirs],
            "errors": [],
            "total_available": len(skill_dirs),
            "total_updated": 0,
        }

    try:
        target.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible d'accéder au dossier skills : {e}",
        }

    updated: list[str] = []
    errors: list[dict] = []

    for skill_dir in selected:
        dest = target / skill_dir.name
        try:
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(
                skill_dir,
                dest,
                ignore=shutil.ignore_patterns(".git", ".gitignore"),
            )
            updated.append(skill_dir.name)
        except Exception as e:
            errors.append({"skill": skill_dir.name, "error": str(e)})

    skipped = [sd.name for sd in skill_dirs if sd not in selected]

    result: dict = {
        "success": len(errors) == 0 or len(updated) > 0,
        "skills_dir": str(target),
        "updated": updated,
        "skipped": skipped,
        "total_available": len(skill_dirs),
        "total_updated": len(updated),
    }
    if errors:
        result["errors"] = errors
    return result


# ---------------------------------------------------------------------------
# Warm-up : charge le modèle français en arrière-plan au démarrage
# ---------------------------------------------------------------------------

def _warmup() -> None:
    # subprocess output must be suppressed: stdout is the MCP stdio channel and
    # any stray bytes corrupt the JSON-RPC stream.
    import subprocess, sys
    try:
        _get_analyzer("fr")
    except OSError:
        # spaCy model absent — download silently so no output leaks to stdout.
        subprocess.run(
            [sys.executable, "-m", "spacy", "download", "fr_core_news_lg"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            _get_analyzer("fr")
        except Exception:
            pass
    except Exception:
        pass


threading.Thread(target=_warmup, daemon=True, name="nomos-warmup").start()


# ---------------------------------------------------------------------------
# Point d'entrée
# ---------------------------------------------------------------------------

def main():
    mcp.run()


if __name__ == "__main__":
    main()
