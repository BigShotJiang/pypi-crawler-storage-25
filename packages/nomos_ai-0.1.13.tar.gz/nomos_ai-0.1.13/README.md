# NomosAI — Anonymiseur de documents juridiques

Détecte et masque les données personnelles dans des documents `.docx`, `.pdf`, `.txt`, `.md` et `.rst`, et produit un Markdown structuré avec métadonnées de conformité.  
Moteur : [Microsoft Presidio](https://github.com/microsoft/presidio) + [spaCy](https://spacy.io/) · **Langue par défaut : français**.

Distribué comme **serveur MCP** — utilisable directement depuis Claude Desktop ou Claude Code, sans interface graphique.

Le serveur expose cinq outils : **`anonymize_file`** (anonymise un document), **`deanonymize_file`** (restaure les valeurs originales depuis l'index), **`list_entities`** (liste les types de PII disponibles), **`initiate_project`** (initialise un espace de travail juridique avec structure de dossiers, hook de sécurité et `CLAUDE.md`) et **`initialise_nomos_skills`** (installe dans `~/.claude/skills/` les skills Claude pour l'assistance juridique : extraction de faits, recherche jurisprudentielle, rédaction de mémoires).

---

## Installation rapide

**Étape 1 — Installer `uv` (une seule fois par machine) :**

- **Windows :** ouvre PowerShell et colle :
  ```
  powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
  ```
- **Mac :** ouvre Terminal et colle :
  ```bash
  curl -LsSf https://astral.sh/uv/install.sh | sh
  ```

**Étape 2 — Installer NomosAI :**

```bash
uv tool install nomos-ai
```

Cela installe NomosAI et toutes ses dépendances (modèle spaCy `fr_core_news_lg` inclus, ~600 Mo) en une seule commande — environ 1 à 3 minutes la première fois.

**Étape 3 — Ajouter NomosAI à Claude :**

Directement dans Claude Code via une commande bash:
```bash
# claude mcp add nomos-ai -- uv tool run nomos-ai
claude mcp add --scope user nomos-ai -- uv tool run nomos-ai

```

Ou manuellement selon ton client :

| Client | Fichier de config |
|--------|-------------------|
| **Claude Code** (CLI / VS Code) | `~/.claude/settings.json` |
| **Claude Desktop** — Windows | `%APPDATA%\Claude\claude_desktop_config.json` |
| **Claude Desktop** — Mac | `~/Library/Application Support/Claude/claude_desktop_config.json` |

Ajoute le bloc suivant dans la section `mcpServers` :

```json
{
  "mcpServers": {
    "nomos-ai": {
      "command": "uv",
      "args": ["tool", "run", "nomos-ai"]
    }
  }
}
```

Redémarrer Claude.

---

## Mettre à jour NomosAI

Pour mettre à jour vers la dernière version publiée sur PyPI :

```bash
uv tool upgrade nomos-ai
```

Puis redémarrez Claude Desktop pour que le nouveau serveur soit pris en compte.

---

## Formats supportés

| Entrée | Librairie |
|--------|-----------|
| `.docx` | `python-docx` |
| `.pdf` | `pdfminer.six` (fallback : `pypdf`) |
| `.txt` / `.md` / `.rst` | natif |

---

## Entités détectées

### Par défaut

| Entité | Label | Description |
|--------|-------|-------------|
| `PERSON` | `[PERSONNE_N]` | Noms de personnes (NLP + titres Pr/Dr/M./Mme) |
| `ORGANIZATION` | `[ORGANISATION_N]` | Noms d'organisations |
| `LOCATION` | `[ADRESSE_N]` | Lieux, adresses |
| `EMAIL_ADDRESS` | `[EMAIL_N]` | Adresses e-mail |
| `PHONE_NUMBER` | `[TELEPHONE_N]` | Numéros français (+33, 0033, local) |
| `URL` | `[URL_N]` | URLs |
| `IP_ADDRESS` | `[IP_N]` | Adresses IP |
| `CREDIT_CARD` | `[CARTE_BANCAIRE_N]` | Numéros de carte bancaire |
| `IBAN_CODE` | `[IBAN_N]` | IBAN |
| `NRP` | `[ID_NATIONAL_N]` | Identifiants nationaux |
| `MEDICAL_LICENSE` | `[LICENCE_MEDICALE_N]` | Licences médicales |
| `CRYPTO` | `[CRYPTO_N]` | Adresses crypto |

### Reconnaisseurs français supplémentaires

| Entité | Label | Exemples |
|--------|-------|---------|
| `FR_NIR` | `[NIR_N]` | Numéro de sécurité sociale (15 chiffres) |
| `FR_SIRET` | `[SIRET_N]` | SIRET (14 chiffres) |
| `FR_SIREN` | `[SIREN_N]` | SIREN (9 chiffres) |
| `FR_TVA` | `[TVA_N]` | TVA intracommunautaire |
| `FR_PASSPORT` | `[PASSEPORT_N]` | Passeport français |
| `FR_CNI` | `[CNI_N]` | Carte nationale d'identité |
| `FR_DRIVING_LICENSE` | `[PERMIS_N]` | Permis de conduire |
| `FR_POSTAL_CODE` | `[CODE_POSTAL_N]` | Code postal (avec contexte) |

### Entités opt-in (à activer via `--entities`)

| Entité | Label | Remarque |
|--------|-------|---------|
| `DATE_TIME` | `[DATE_N]` | Dates — exclus par défaut (bruit dans les rapports) |
| `FILE_PATH` | `[CHEMIN_FICHIER_N]` | Chemins Windows/Unix — français uniquement, exclus par défaut |

---

## Architecture

```
anonymize.py              CLI principal (lecture, anonymisation, écriture)
deanonymize.py            CLI de restauration à partir de l'index
src/
  nomosai/
    readers.py            Lecture DOCX/PDF/TXT/MD/RST → liste de Block
    engine.py             Moteur Presidio + filtres faux positifs + dédup spans
    recognizers_fr.py     Reconnaisseurs regex français (NIR, SIRET, téléphone…)
    formatter.py          Rendu Markdown + frontmatter
    server.py             Serveur MCP (FastMCP, transport stdio)
pyproject.toml            Métadonnées du package et dépendances
```

**Pipeline :** `Reader → Engine → Formatter → fichier .md + fichier -index.md`

---

## Qualité de détection

### Seuils de confiance

Le seuil global par défaut est `0.55`. Certains types ont un plancher plus élevé pour réduire les faux positifs :

| Type | Seuil minimum |
|------|---------------|
| `LOCATION` | 0.80 (sur-détection dans les tableaux PDF) |
| `FR_SIREN` | 0.70 |
| `FR_CNI` | 0.70 |
| `FR_POSTAL_CODE` | 0.70 |

### Filtres anti-faux-positifs

L'engine rejette automatiquement les détections dont le texte :
- est une lettre ou sigle de 1–3 caractères (`F`, `NR`, `ET`…)
- est une valeur statistique (`N=1 035`, `75,6`…)
- est un numéro de section (`II.4`, `I.1`…)
- est un fragment tout-en-majuscules multi-mots (en-tête de tableau)
- contient des artefacts OCR (espaces intrus dans un mot)

---

## Ajouter un reconnaisseur personnalisé

```python
from presidio_analyzer import PatternRecognizer, Pattern

MY_RECOGNIZER = PatternRecognizer(
    supported_entity="MY_ENTITY",
    supported_language="fr",
    patterns=[Pattern("MY_PATTERN", r"\bREGEX\b", score=0.85)],
    context=["mot", "clé", "contextuel"],
)
```

Ajouter l'instance dans `get_french_recognizers()` de `src/nomosai/recognizers_fr.py` et son label dans `FRENCH_ENTITY_LABELS`.

Voir la [doc Presidio](https://microsoft.github.io/presidio/analyzer/adding_recognizers/).

---