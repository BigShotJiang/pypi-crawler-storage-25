# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

Do not commit without being explicitely asked for.

## Project Overview

NomosAI is a CLI document anonymization tool for legal/compliance use cases. It detects and replaces PII in documents (DOCX, PDF, TXT, MD, RST) and outputs anonymized Markdown files with GDPR-compliant metadata. The project is Python 3, French-first, with no build system or test suite.

## Setup

```bash
pip install -r requirements.txt
python -m spacy download fr_core_news_lg   # required for French (default)
python -m spacy download en_core_web_lg    # optional for English
```

## Running the Tool

A conda env is installed on this machine to run the python scripts in this project.
Conda env name nomosai

```bash
# Single file
python anonymize.py report.pdf

# Specify output
python anonymize.py contract.docx --output contract_redacted.md

# Batch (recursive directory)
python anonymize.py dossier/ --recursive --language fr --output dossier_anonymise/

# Limit entity types
python anonymize.py notes.txt --entities PERSON EMAIL_ADDRESS PHONE_NUMBER

# Adjust confidence threshold (default 0.55)
python anonymize.py file.pdf --score-threshold 0.6
```

## Architecture

The pipeline is: **Reader → Engine → Formatter → Output file**

1. **`src/readers.py`** — Converts DOCX/PDF/TXT/MD/RST into a list of `Block` dataclasses (`type`, `text`, `cells`). Block types: `heading1/2/3`, `paragraph`, `table_row`, `list_item`, `hr`.

2. **`src/engine.py`** — Core anonymization logic.
   - `DocumentAnonymizer` wraps the Microsoft Presidio analyzer (backed by spaCy NLP).
   - Replaces PII with numbered placeholders (`[PERSON_1]`, `[EMAIL_2]`) — the same PII value always maps to the same placeholder within a document.
   - French-specific recognizers are injected into the registry when `language=="fr"`.
   - `_HIGH_CONFIDENCE_ONLY` set (`FR_SIREN`, `FR_CNI`, `FR_POSTAL_CODE`) requires score ≥ 0.70 regardless of the `--score-threshold` flag.

3. **`src/recognizers_fr.py`** — Custom regex recognizers for French PII: NIR (sécu), SIRET, SIREN, TVA, CNI, passport, driving license, postal codes, French phone numbers. Each is a `PatternRecognizer` registered for `language="fr"`.

4. **`src/formatter.py`** — Renders anonymized blocks as Markdown.

5. **`anonymize.py`** — CLI entry point; parses args, wires up engine + reader + formatter, handles single-file and batch modes.

## Key Implementation Notes

- **Presidio is the detection backbone**: adding a new entity type means writing a `PatternRecognizer` or `EntityRecognizer` subclass in `recognizers_fr.py` and registering it.
- **Replacement order matters**: `engine.py` processes Presidio results in reverse position order to avoid index drift during in-place string substitution.
- **Batch mode** generates a GDPR summary report alongside the anonymized files.
- **No config file**: all defaults live in `anonymize.py` (default language `fr`, default threshold `0.55`).

## Development process 

Once a new task of development has been completed add unit tests.
Run all unit tests to ensure that no regressions are present.
Keep README updated when necessary.