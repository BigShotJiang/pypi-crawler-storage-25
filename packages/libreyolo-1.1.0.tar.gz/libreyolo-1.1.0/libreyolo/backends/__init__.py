"""Inference backends for LibreYOLO."""
