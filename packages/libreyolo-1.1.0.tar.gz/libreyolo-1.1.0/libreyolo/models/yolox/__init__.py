"""
YOLOX implementation for LibreYOLO.
"""
