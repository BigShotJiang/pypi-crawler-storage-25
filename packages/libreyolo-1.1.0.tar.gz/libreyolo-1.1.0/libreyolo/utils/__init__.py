"""Shared utilities for LibreYOLO."""
