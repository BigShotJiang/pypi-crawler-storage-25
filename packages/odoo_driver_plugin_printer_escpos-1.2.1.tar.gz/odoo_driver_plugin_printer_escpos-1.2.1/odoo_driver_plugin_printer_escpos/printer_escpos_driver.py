import base64
from io import BytesIO

from escpos.printer import Usb
from flask_babel import gettext as _
from odoo_driver.drivers.driver_abstract_with_queue import DriverAbstractWithQueue
from PIL import Image


class DriverPrinterEscPos(DriverAbstractWithQueue):
    _driver_function = "printer"
    _plugin_name = "printer_escpos"
    _default_max_queue_size = 3
    _default_delay = 1

    @property
    def name(self):
        return _("Printer")

    def _process_task(self, task):
        printer = Usb(self._usb_device.idVendor, self._usb_device.idProduct, 0)
        (action, value) = task.data

        if action == "print":
            im = Image.open(BytesIO(base64.b64decode(value)))
            printer.image(im)
            printer.cut()

        elif action == "open_cashbox":
            printer.cashdraw(2)

        printer.close()
