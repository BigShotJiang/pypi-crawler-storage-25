USB_DEVICES = {
    (0x04B8, 0x0E15): {"name": "Epson - TM-T20II", "image": "epson__tm_t20.png"},
    (0x04B8, 0x0E28): {"name": "Epson - TM-T20III", "image": "epson__tm_t20.png"},
    (0x04B8, 0x0202): {"name": "Epson - TM-T88V", "image": "epson__tm_t88.png"},
}
