from flask import Blueprint, jsonify, request
from loguru import logger
from odoo_driver.tools.tools_interface import interface

driver_routes_odoo = Blueprint(
    "route_printer_escpos_odoo", __name__, template_folder="templates"
)


@driver_routes_odoo.route("/hw_proxy/default_printer_action", methods=["POST", "PUT"])
@logger.catch
def default_printer_action():
    driver = interface.drivers.get("printer")
    data = request.json.get("params", {}).get("data", {})

    data_copy = data.copy()
    if data_copy.get("action") == "print_receipt":
        data_copy.pop("receipt")
    interface.log_data(data_copy, "printer", "DEBUG")

    if data.get("action") == "print_receipt":
        receipt = data["receipt"]
        interface.log_image(receipt, "DEBUG")
        driver.add_task(("print", receipt))

    elif data.get("action") == "cashbox":
        driver.add_task(("open_cashbox", False))

    else:
        raise Exception(f"Incorrect action value: '{data.get('action')}'")

    return jsonify(jsonrpc="2.0", result=True)
