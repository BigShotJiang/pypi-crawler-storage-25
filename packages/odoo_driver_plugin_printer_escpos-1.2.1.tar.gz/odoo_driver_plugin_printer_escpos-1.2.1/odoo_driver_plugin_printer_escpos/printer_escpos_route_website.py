import os

from flask import Blueprint, render_template, send_from_directory
from loguru import logger
from odoo_driver.tools.tools_interface import interface

driver_routes_website = Blueprint(
    "route_printer_escpos_website", __name__, template_folder="templates"
)


@driver_routes_website.route("/driver/printer_escpos.html")
@logger.catch
def driver_printer_escpos():
    driver = interface.drivers.get("printer")
    return render_template("driver_printer_escpos.html.jinja", driver=driver)


@driver_routes_website.route("/printer_escpos/photo_booth.html")
@logger.catch
def photo_booth():
    return render_template("photo_booth.html.jinja")


@driver_routes_website.route("/printer_escpos/photo_taken.wav")
@logger.catch
def printer_escpos_photo_taken():
    return send_from_directory(
        os.path.join(driver_routes_website.root_path, "static", "audio"),
        "photo-taken.wav",
        mimetype="audio/wav",
    )


@driver_routes_website.route("/printer_escpos/webcam-easy.js")
@logger.catch
def printer_escpos_webcam_easy():
    return send_from_directory(
        os.path.join(driver_routes_website.root_path, "static", "js"),
        "webcam-easy.js",
        mimetype="application/javascript",
    )
