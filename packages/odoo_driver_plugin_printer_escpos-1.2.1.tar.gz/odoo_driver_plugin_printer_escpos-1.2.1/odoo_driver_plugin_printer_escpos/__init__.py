from pathlib import Path

from single_source import get_version

from . import usb_devices
from .printer_escpos_driver import DriverPrinterEscPos
from .printer_escpos_route_odoo import driver_routes_odoo
from .printer_escpos_route_website import driver_routes_website

__version__ = get_version(__name__, Path(__file__).parent.parent)
__package_name__ = __name__

DRIVER_FUNCTION = "printer"
PLUGIN_NAME = "printer_escpos"
DRIVER_CLASS = DriverPrinterEscPos

DRIVER_ROUTES_GROUPS = [driver_routes_odoo, driver_routes_website]
