# Odoo Driver Plugin - Printer ESC/POS

![License: AGPL v3](https://img.shields.io/badge/License-AGPL_v3-blue.svg)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/odoo-driver-plugin-printer-escpos)
![PyPI - Downloads](https://img.shields.io/pypi/dm/odoo-driver-plugin-printer-escpos)
![GitLab last commit](https://img.shields.io/gitlab/last-commit/81118598)
![GitLab stars](https://img.shields.io/gitlab/stars/81118598?style=social)

This project provide a plugin for ``odoo-driver``
to communicate with Printers with ECS/POS protocol.

This plugin requires the following odoo module : `point_of_sale` (Odoo CE / EE).

To install this plugin, refer to the main project page : https://gitlab.com/grap-rhone-alpes/odoo-driver/.

For developpers, refer to this page : https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-printer-escpos/-/blob/main/DEVELOP.md.

## Table of contents

1. [Compatible Devices](#compatible-devices)
2. [Credits](#credits)


<a name="compatible-devices"></a>

## Compatible Devices

<table style="width: 100%;">
    <tbody>
        <tr>
            <th colspan="2">Printers</th>
        </tr>
        <tr>
            <td>
              <li>
                <ul>Epson - TM-T20II</ul>
                <ul>Epson - TM-T20III</ul>
              </li>
            </td>
            <td>
              <img src="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-printer-escpos/-/raw/main/odoo_driver_plugin_printer_escpos/static/img/epson__tm_t20.png" width="200" height="200" />
            </td>
        </tr>
        <tr>
            <td>
              <li>
                <ul>Epson - TM-T88V</ul>
              </li>
            </td>
            <td>
              <img src="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-printer-escpos/-/raw/main/odoo_driver_plugin_printer_escpos/static/img/epson__tm_t88.png" width="200" height="200" />
            </td>
        </tr>
    </tbody>
</table>

<a name="credits"></a>

## Credits

### Authors

* GRAP <https://www.grap.coop>

### Contributors

* Sylvain LE GAL <https://www.grap.coop/>

### Extra authorship

Part of the code in this project comes from the following projects, including:

* [Pywebdriver](https://github.com/pywebdriver/pywebdriver) (AGPL-3.0), by GRAP.

### Images

* [Thermal Receipt Printer Icon](https://www.flaticon.com/fr/icone-gratuite/facture_1649343), created by Icongeek26 (Flaticon).
