from __future__ import annotations

import json
from pathlib import Path

import typer


def load_schema(value: str) -> object:
    # Check if value looks like a file path (not JSON) before treating it as a path
    stripped = value.strip()
    if stripped.startswith("{") or stripped.startswith("["):
        # Value looks like JSON, use it directly
        raw = value
    else:
        candidate = Path(value).expanduser()
        if candidate.exists():
            try:
                raw = candidate.read_text(encoding="utf-8")
            except OSError as exc:
                raise typer.BadParameter(f"Unable to read schema file: {exc}") from exc
        else:
            raw = value

    raw = raw.strip()
    if not raw:
        raise typer.BadParameter("Schema cannot be empty")

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return raw
