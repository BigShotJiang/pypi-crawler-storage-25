import torch
import torch.nn as nn


class TensorMessagePassingLayer(nn.Module):
    r"""Base class for tensor-based message passing layers.

    Given a graph (node features, edge index, and optionally edge features),
    the layer performs:

        Message:   m_ij = f( node_i, node_j, edge_ij )
        Aggregation: m_i = aggr( { m_ij }_{j in N(i)} )
        Update:    x_i' = g( x_i, m_i )

    Subclasses should override the ``message()`` and ``update()`` methods.
    The default aggregation is implemented using index_add.

    Naming note:
        The public ``forward()`` signature accepts ``edge_features`` (matching
        the ``Graph`` data class).  The abstract ``message()`` method receives
        the same tensor as ``edge_attr``.  Both names refer to identical data;
        ``edge_attr`` is the per-edge name used in the internal message step.
    """

    def __init__(self, in_shape, out_shape, aggr='sum', dropout_prob=0.0, residual=False, use_batchnorm=False):
        super().__init__()
        self.in_shape = in_shape
        self.out_shape = out_shape
        self.aggr = aggr
        self.dropout_prob = dropout_prob
        self.residual = residual
        self.use_batchnorm = use_batchnorm
        if use_batchnorm:
            ndim = len(out_shape)
            if ndim == 1:
                self.bn = nn.BatchNorm1d(out_shape[0])
            elif ndim == 3:
                self.bn = nn.BatchNorm2d(out_shape[0])
            elif ndim == 4:
                self.bn = nn.BatchNorm3d(out_shape[0])
            else:
                raise ValueError(
                    f"use_batchnorm requires out_shape of 1 (vector), 3 (2-D spatial), "
                    f"or 4 (3-D volumetric) dimensions; got {ndim}."
                )
        self.dropout = nn.Dropout(p=dropout_prob) if dropout_prob > 0 else None


    def message(self, src, dest, edge_attr):
        r"""Compute message for each edge.

        Args:
            src (Tensor): Source node features for each edge.
            dest (Tensor): Destination node features for each edge.
            edge_attr (Tensor or None): Edge features for each edge.

        Returns:
            Tensor: Message for each edge.
        """
        raise NotImplementedError("Subclasses must implement message()")

    def aggregate(self, messages, edge_index, num_nodes):
        r"""Aggregate messages from incoming edges for each node.

        Supports ``aggr`` values:

        * ``"sum"``  — element-wise sum of incoming messages.
        * ``"mean"`` — element-wise mean over incoming edges (isolated nodes
          stay at zero; the count divisor is clamped to 1).
        * ``"max"``  — element-wise max over incoming edges (isolated nodes
          return zero; ``-inf`` placeholders are masked out).  Implemented
          via ``torch.scatter_reduce_(reduce='amax')``.

        Args:
            messages (Tensor): Messages for each edge, shape ``[E, ...]``.
            edge_index (LongTensor): Edge indices with shape ``[2, E]``.
            num_nodes (int): Number of nodes.

        Returns:
            Tensor: Aggregated messages for each node, shape
            ``[num_nodes, ...]``.
        """
        target = edge_index[1]
        if self.aggr == 'max':
            # Local import to avoid an import cycle at module load.
            from ._scatter import scatter_max
            return scatter_max(messages, target, num_nodes)

        aggregated = torch.zeros(
            num_nodes, *messages.shape[1:],
            device=messages.device, dtype=messages.dtype,
        )
        aggregated = aggregated.index_add(0, target, messages)
        if self.aggr == 'mean':
            counts = torch.zeros(num_nodes, device=messages.device, dtype=messages.dtype)
            ones = torch.ones(messages.shape[0], device=messages.device, dtype=messages.dtype)
            counts = counts.index_add(0, target, ones)
            view_shape = (num_nodes,) + (1,) * (aggregated.dim() - 1)
            counts = counts.view(view_shape).clamp(min=1)
            aggregated = aggregated / counts
        return aggregated

    def update(self, node_feature, aggregated_message):
        out = aggregated_message
        if self.use_batchnorm:
            out = self.bn(out)
        if self.dropout:
            out = self.dropout(out)
        if self.residual:
            # Only add skip connection if dimensions match
            if node_feature.shape == out.shape:
                out = node_feature + out
        return out

    def forward(self, node_features, edge_index, edge_features=None, edge_weight=None):
        r"""Standard message-passing forward.

        ``edge_weight`` is an optional ``[E]`` per-edge scalar.  If provided,
        each per-edge message is multiplied by the corresponding weight
        before aggregation.  The weight is broadcast over every trailing
        dimension of the message tensor, so it works for both vector and
        spatial messages.
        """
        src_idx = edge_index[0]
        dest_idx = edge_index[1]
        src_features = node_features[src_idx]
        dest_features = node_features[dest_idx]
        messages = self.message(src_features, dest_features, edge_features)
        if edge_weight is not None:
            from ._scatter import broadcast_edge_weight
            weight_b = broadcast_edge_weight(
                edge_weight, messages, num_edges=edge_index.size(1)
            )
            messages = messages * weight_b
        num_nodes = node_features.size(0)
        aggregated = self.aggregate(messages, edge_index, num_nodes)
        updated_nodes = self.update(node_features, aggregated)
        return updated_nodes


class LinearMessagePassing(TensorMessagePassingLayer):
    r"""Message passing layer based on linear transformations for vector node features.

    This layer concatenates the source and destination node features (and optionally
    edge features) then passes the result through a learnable linear module.

    Only 1-D per-node feature shapes ``(D,)`` are supported.  For 2-D spatial
    ``(C, H, W)`` or 3-D volumetric ``(C, D, H, W)`` features use
    :class:`ConvMessagePassing`, :class:`TensorGATLayer`,
    :class:`TensorGraphSAGELayer`, or :class:`TensorGINLayer` instead.
    """

    def __init__(self, in_shape, out_shape, aggr='sum', use_edge_features=False,
                 dropout_prob=0.0, residual=False, use_batchnorm=False):
        in_shape = tuple(in_shape)
        out_shape = tuple(out_shape)
        if len(in_shape) != 1:
            raise ValueError(
                f"LinearMessagePassing supports vector node features [N, D] only "
                f"(in_shape must be a 1-element tuple such as (32,)); "
                f"got in_shape={in_shape}. "
                f"For 2-D/3-D tensor features use ConvMessagePassing, "
                f"TensorGATLayer, TensorGraphSAGELayer, or TensorGINLayer."
            )
        if len(out_shape) != 1:
            raise ValueError(
                f"LinearMessagePassing supports vector node features [N, D] only "
                f"(out_shape must be a 1-element tuple such as (64,)); "
                f"got out_shape={out_shape}."
            )
        super().__init__(in_shape, out_shape, aggr, dropout_prob=dropout_prob,
                         residual=residual, use_batchnorm=use_batchnorm)
        self.use_edge_features = use_edge_features
        in_dim = in_shape[0]
        linear_in_dim = in_dim * 3 if use_edge_features else in_dim * 2
        self.message_linear = nn.Linear(linear_in_dim, out_shape[0])

    def message(self, src, dest, edge_attr):
        if self.use_edge_features and edge_attr is not None:
            msg_input = torch.cat([src, dest, edge_attr], dim=-1)
        else:
            msg_input = torch.cat([src, dest], dim=-1)
        return self.message_linear(msg_input)

    # update() is intentionally NOT overridden here so that the base-class
    # implementation runs and applies batchnorm → dropout → residual in the
    # correct order whenever those flags were set at construction time.
