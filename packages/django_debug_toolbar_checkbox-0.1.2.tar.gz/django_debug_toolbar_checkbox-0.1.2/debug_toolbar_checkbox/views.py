from django.conf import settings
from django.contrib import admin
from django.contrib.auth.mixins import UserPassesTestMixin
from django.urls import path
from django.views.generic import TemplateView


class SuperuserAdminView(UserPassesTestMixin, TemplateView):
    """An admin view that can only be seen by superusers."""
    title = "(no title)"

    def test_func(self):
        return self.request.user.is_superuser

    def get_context_data(self, **kwargs):
        return {
            **super().get_context_data(**kwargs),
            **admin.site.each_context(self.request),
            "title": self.title,
        }


class DebugToolbarView(SuperuserAdminView):
    template_name = "debug_toolbar/admin/debug_toolbar.html"
    title = "Debug toolbar"

    def get_context_data(self, **kwargs):
        return super().get_context_data(**kwargs) | {"debug_toolbar_secret": settings.DEBUG_TOOLBAR_SECRET}
