from django.urls import path

from debug_toolbar_checkbox.views import DebugToolbarView

urlpatterns = [
    path("debug-toolbar", DebugToolbarView.as_view()),
]
