from django.apps import AppConfig


class DebugToolbarCheckboxConfig(AppConfig):
    name = "debug_toolbar_checkbox"
