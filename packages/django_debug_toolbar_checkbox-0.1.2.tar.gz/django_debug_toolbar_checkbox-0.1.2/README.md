# Debug Toolbar Checkbox

## Demo

![](https://git.afpy.org/mdk/debug-toolbar-checkbox/media/branch/main/debug-toolbar.gif)


## Install


First [install the Django Debug
Toolbar](https://django-debug-toolbar.readthedocs.io/en/latest/installation.html),
if not already done.


```shell
$ pip install debug_toolbar_checkbox
```

In `settings.py`, add `debug_toolbar_checkbox` **before** django admin:

```python
INSTALLED_APPS = [
    "debug_toolbar",
    "debug_toolbar_checkbox",
    "django.contrib.admin",
    ...,
]
```

In `settings.py` set a `DEBUG_TOOLBAR_SETTINGS`, or derive it from `SECRET_KEY`:

```python
from hashlib import sha256
DEBUG_TOOLBAR_SECRET = sha256(b"djdt" + SECRET_KEY.encode("UTF-8")).hexdigest()
```

In `settings.py` configure the Debug Toolbar to check the secret in the cookie:

```python
DEBUG_TOOLBAR_CONFIG = {
    "SHOW_TOOLBAR_CALLBACK": lambda request: DEBUG_TOOLBAR_SECRET in request.headers.get("cookie", "")
}
```

In `urls.py` add this **before** the `path("admin/")`:

```python
path("admin/pages/", include("debug_toolbar_checkbox.urls")),
```

You may need to add `include` to the `from django.urls import path` line.

It may look like this:

```python
from debug_toolbar.toolbar import debug_toolbar_urls
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/pages/", include("debug_toolbar_checkbox.urls")),
    path("admin/", admin.site.urls),
] + debug_toolbar_urls()
```

## Security

The activation is governed by the presence of a secret in a
cookie. The cookie is set by some JavaScript (static file, publicly
available). But the secret is only written in the admin page as a
[data
attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/How_to/Use_data_attributes).
The admin page is only accessible to superusers, so only superusers
can query the page containing the secret.

If you're not OK with my sha256/concat to derive a new secret, feel
free to replace it with a truly random secret.
