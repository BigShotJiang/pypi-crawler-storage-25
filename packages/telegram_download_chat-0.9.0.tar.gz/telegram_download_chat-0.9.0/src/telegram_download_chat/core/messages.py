import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..paths import get_relative_to_downloads_dir


class MessagesMixin:
    def convert_archive_to_messages(
        self, archive: Dict[str, Any], user_filter: str | None = None
    ) -> List[Dict[str, Any]]:
        self.logger.debug("Converting archive to messages...")
        if user_filter:
            self.logger.info(f"Filtering messages by user: {user_filter}")
            user_filter = (
                user_filter.replace("user", "")
                if user_filter.startswith("user")
                else user_filter
            )

        messages = []
        chats = archive.get("chats", {}).get("list", [])
        left_chats = archive.get("left_chats", {}).get("list", [])
        chats.extend(left_chats)

        self.logger.info(
            f"Found {len(chats)} chats, including {len(left_chats)} left chats"
        )
        for chat in chats:
            chat_id = chat.get("id")
            if not chat_id:
                continue

            for message in chat.get("messages", []):
                if message.get("type") != "message":
                    continue

                text = message.get("text", "")
                if isinstance(text, list):
                    text_parts = []
                    for part in text:
                        if isinstance(part, str):
                            text_parts.append(part)
                        elif isinstance(part, dict):
                            text_parts.append(part.get("text", ""))
                    text = "".join(text_parts)
                elif not isinstance(text, str):
                    text = str(text)

                from_id = message.get("from_id", "")
                if isinstance(from_id, str) and from_id.startswith("user"):
                    try:
                        user_id = int(from_id[4:])
                    except (ValueError, TypeError):
                        user_id = from_id
                else:
                    user_id = from_id

                if user_filter and str(user_id) != user_filter:
                    continue

                formatted = {
                    "id": message.get("id"),
                    "peer_id": {
                        "_": (
                            "PeerChat" if chat.get("type") == "group" else "PeerChannel"
                        ),
                        (
                            "channel_id"
                            if chat.get("type") in ["channel", "public_supergroup"]
                            else "user_id"
                        ): chat_id,
                    },
                    "date": message.get("date"),
                    "message": text,
                    "from_id": {"_": "PeerUser", "user_id": user_id},
                    "user_display_name": message.get("from")
                    or message.get("from_id")
                    or "",
                }

                media = self._convert_archive_media(message)
                if media:
                    formatted["media"] = media

                if "reply_to_message_id" in message:
                    formatted["reply_to_msg_id"] = message["reply_to_message_id"]

                messages.append(formatted)

        return messages

    @staticmethod
    def _convert_archive_media(message: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert Telegram Desktop export media fields to Telethon-style media dict."""
        if "photo" in message:
            return {"_": "MessageMediaPhoto"}

        media_type = message.get("media_type", "")
        file_name = message.get("file", "")
        if file_name:
            # Telegram Desktop exports use this sentinel when media wasn't downloaded
            if file_name.startswith("(File not included"):
                file_name = ""
            else:
                file_name = (
                    file_name.rsplit("/", 1)[-1] if "/" in file_name else file_name
                )

        if media_type == "sticker":
            return {
                "_": "MessageMediaDocument",
                "document": {
                    "attributes": [{"_": "DocumentAttributeSticker"}],
                },
            }

        if media_type in ("video_message", "video_file", "animation"):
            attrs = [{"_": "DocumentAttributeVideo"}]
            if file_name:
                attrs.append({"_": "DocumentAttributeFilename", "file_name": file_name})
            return {"_": "MessageMediaDocument", "document": {"attributes": attrs}}

        if media_type in ("voice_message", "audio_file"):
            attrs = [{"_": "DocumentAttributeAudio"}]
            if file_name:
                attrs.append({"_": "DocumentAttributeFilename", "file_name": file_name})
            return {"_": "MessageMediaDocument", "document": {"attributes": attrs}}

        if "contact_information" in message or "contact_vcard" in message:
            return {"_": "MessageMediaContact"}

        if "location_information" in message:
            return {"_": "MessageMediaGeo"}

        if "poll" in message:
            return {"_": "MessageMediaPoll"}

        # Generic file with no specific media_type
        if file_name:
            attrs = [{"_": "DocumentAttributeFilename", "file_name": file_name}]
            return {"_": "MessageMediaDocument", "document": {"attributes": attrs}}

        if media_type:
            return {"_": "MessageMediaDocument", "document": {"attributes": []}}

        return None

    def prepare_messages_for_txt(
        self, messages: List[Dict[str, Any]], sort_order: str = "asc"
    ) -> List[Dict[str, Any]]:
        epoch = datetime.min.replace(tzinfo=timezone.utc)

        def parse_dt(msg: Dict[str, Any]) -> datetime:
            date_str = msg.get("date")
            if not date_str:
                return epoch
            try:
                dt = datetime.fromisoformat(str(date_str).replace("Z", "+00:00"))
            except Exception:
                return epoch
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt

        id_map: Dict[Any, Dict[str, Any]] = {
            m.get("id"): m for m in messages if m.get("id") is not None
        }
        children: Dict[Any, List[Dict[str, Any]]] = {}
        roots: List[Dict[str, Any]] = []

        for msg in messages:
            reply = msg.get("reply_to") or {}
            reply_id = reply.get("reply_to_msg_id") or msg.get("reply_to_msg_id")
            if reply_id and reply_id in id_map:
                children.setdefault(reply_id, []).append(msg)
            else:
                roots.append(msg)

        def sort_msgs(msgs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            return sorted(msgs, key=parse_dt, reverse=(sort_order == "desc"))

        def traverse(msg: Dict[str, Any]) -> List[Dict[str, Any]]:
            child_msgs = []
            for child in sort_msgs(children.get(msg.get("id"), [])):
                child_msgs.extend(traverse(child))

            if sort_order == "desc":
                return child_msgs + [msg]
            return [msg] + child_msgs

        ordered_messages: List[Dict[str, Any]] = []
        for root in sort_msgs(roots):
            ordered_messages.extend(traverse(root))

        return ordered_messages

    @staticmethod
    def _get_media_placeholder(
        media_dict: Optional[Dict[str, Any]],
    ) -> Optional[str]:
        if not media_dict or not isinstance(media_dict, dict):
            return None

        media_type = media_dict.get("_", "")

        if media_type == "MessageMediaPhoto":
            return "[photo]"

        if media_type == "MessageMediaDocument":
            doc = media_dict.get("document")
            if isinstance(doc, dict):
                attributes = doc.get("attributes", [])
                filename = None
                has_video = False
                has_audio = False
                has_sticker = False
                for attr in attributes:
                    if not isinstance(attr, dict):
                        continue
                    attr_type = attr.get("_", "")
                    if attr_type == "DocumentAttributeFilename":
                        filename = attr.get("file_name")
                    elif attr_type == "DocumentAttributeVideo":
                        has_video = True
                    elif attr_type == "DocumentAttributeAudio":
                        has_audio = True
                    elif attr_type == "DocumentAttributeSticker":
                        has_sticker = True

                if has_sticker:
                    return "[sticker]"
                if has_video:
                    return "[video]"
                if has_audio:
                    return "[audio]"
                if filename:
                    safe_name = filename.replace("[", "(").replace("]", ")").replace("\n", " ")
                    return f"[file={safe_name}]"
            return "[file]"

        if media_type == "MessageMediaContact":
            return "[contact]"

        if media_type in (
            "MessageMediaGeo",
            "MessageMediaGeoLive",
            "MessageMediaVenue",
        ):
            return "[location]"

        if media_type == "MessageMediaPoll":
            return "[poll]"

        if media_type == "MessageMediaDice":
            return "[dice]"

        if media_type == "MessageMediaGame":
            return "[game]"

        if media_type == "MessageMediaWebPage":
            return None

        return "[media]"

    async def save_messages_as_txt(
        self,
        messages: List[Dict[str, Any]],
        txt_path: Path,
        sort_order: str = "asc",
        media_placeholders: bool = False,
    ) -> int:
        saved = 0
        txt_path.parent.mkdir(parents=True, exist_ok=True)
        txt_path.write_text("", encoding="utf-8")  # Truncate for fresh overwrite

        ordered_messages = self.prepare_messages_for_txt(messages, sort_order)

        for msg in ordered_messages:
            try:
                date_str = msg.get("date", "")
                if date_str:
                    try:
                        dt = datetime.fromisoformat(str(date_str).replace("Z", "+00:00"))
                        date_fmt = dt.strftime("%Y-%m-%d %H:%M:%S")
                    except (ValueError, TypeError):
                        date_fmt = ""
                else:
                    date_fmt = ""

                sender_name = ""
                sender_id = self._get_sender_id(msg)
                if sender_id:
                    sender_name = await self._get_user_display_name(sender_id)

                text = msg.get("text", "")
                if not text and "message" in msg:
                    text = msg["message"]

                if media_placeholders:
                    placeholder = self._get_media_placeholder(msg.get("media"))
                    if placeholder:
                        if text:
                            text = f"{text}\n{placeholder}"
                        else:
                            text = placeholder

                recipient_name = ""
                recipient_id = self._get_recipient_id(msg)
                if recipient_id:
                    recipient_name = await self._get_peer_display_name(recipient_id)

                if date_fmt or sender_name:
                    if recipient_name:
                        line = (
                            f"{date_fmt} {sender_name} -> {recipient_name}:\n{text}\n\n"
                        )
                    else:
                        line = f"{date_fmt} {sender_name}:\n{text}\n\n"
                else:
                    line = f"{text}\n\n"

                with open(txt_path, "a", encoding="utf-8") as f:
                    f.write(line)
                saved += 1
            except Exception as e:
                logging.warning(f"Error saving message to TXT: {e}")

        if self._fetched_usernames_count > 0 or self._fetched_chatnames_count > 0:
            self._save_config()

        return saved

    def make_serializable(self, obj):
        if isinstance(obj, dict):
            return {k: self.make_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [self.make_serializable(x) for x in obj]
        elif isinstance(obj, (str, int, float, bool, type(None))):
            return obj
        else:
            try:
                return str(obj)
            except Exception:
                return None

    def get_attachments_dir(self, output_file: Path) -> Path:
        """Get the attachments directory path for a given output file.

        Returns <output_file_parent>/attachments — a sibling of the message
        files inside the chat's own directory.
        """
        return output_file.parent / "attachments"

    async def save_messages(
        self,
        messages,
        output_file: str,
        save_txt: bool = True,
        sort_order: str = "asc",
        download_media: bool = False,
        export_html: bool = False,
        export_pdf: bool = False,
        chat_title: Optional[str] = None,
        media_placeholders: bool = False,
        html_media_links: bool = False,
    ) -> None:
        output_path = Path(output_file)

        attachments_dir = self.get_attachments_dir(output_path)
        serializable_messages = []
        preserved_ids: set = set()  # IDs whose attachment_path was kept from prior run
        for msg in messages:
            try:
                msg_dict = msg.to_dict() if hasattr(msg, "to_dict") else msg
                sender_id = self._get_sender_id(msg_dict)
                msg_dict["user_display_name"] = (
                    await self._get_user_display_name(sender_id)
                    if sender_id
                    else "Unknown"
                )
                if download_media:
                    # For dict messages (e.g. from resume), preserve existing
                    # attachment_path rather than recalculating from media
                    # (dicts have no Telethon media attribute).
                    if isinstance(msg, dict) and msg.get("attachment_path"):
                        existing = attachments_dir / msg["attachment_path"]
                        if existing.exists():
                            msg_dict["attachment_path"] = msg["attachment_path"]
                            mid = str(msg.get("id", ""))
                            if mid:
                                preserved_ids.add(mid)
                        else:
                            msg_dict["attachment_path"] = None
                    else:
                        raw_media = getattr(msg, "media", None)
                        raw_id = str(getattr(msg, "id", None) or "")
                        if raw_media and raw_id:
                            msg_dict["attachment_path"] = (
                                self.get_predicted_attachment_path(
                                    raw_media, raw_id, attachments_dir
                                )
                            )
                        else:
                            msg_dict["attachment_path"] = None
                serializable_messages.append(self.make_serializable(msg_dict))
            except Exception as e:
                self.logger.warning(f"Failed to serialize message: {e}")

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(serializable_messages, f, ensure_ascii=False, indent=2)

        if save_txt:
            txt_path = output_path.with_suffix(".txt")
            saved = await self.save_messages_as_txt(
                serializable_messages,
                txt_path,
                sort_order,
                media_placeholders=media_placeholders,
            )
            txt_path_relative = get_relative_to_downloads_dir(txt_path)
            self.logger.info(f"Saved {saved} messages to {txt_path_relative}")

        # Download media attachments if requested
        if download_media:
            self.logger.info("Downloading media attachments...")
            download_results = await self.download_all_media(messages, attachments_dir)
            # Reconcile predicted paths with actual download results:
            # - null out attachment_path for messages whose downloads failed
            # - update attachment_path when Telethon used a different filename
            ids_with_predicted_path = {
                str(m.get("id", ""))
                for m in serializable_messages
                if m.get("attachment_path") is not None and m.get("id")
            }
            if ids_with_predicted_path:
                changed = False
                for m in serializable_messages:
                    mid = str(m.get("id", ""))
                    if mid in preserved_ids:
                        continue
                    if m.get("attachment_path") is not None:
                        if mid not in download_results:
                            m["attachment_path"] = None
                            changed = True
                        elif m["attachment_path"] != download_results[mid]:
                            m["attachment_path"] = download_results[mid]
                            changed = True
                if changed:
                    with open(output_path, "w", encoding="utf-8") as f:
                        json.dump(
                            serializable_messages, f, ensure_ascii=False, indent=2
                        )

        # HTML / PDF export (after media download so attachment paths are final)
        if not chat_title:
            chat_title = output_path.parent.name
        if export_html:
            html_path = output_path.with_suffix(".html")
            try:
                self.render_html(
                    serializable_messages,
                    html_path,
                    attachments_dir,
                    chat_title,
                    media_links=html_media_links,
                )
                self.logger.info(
                    f"Saved HTML to {get_relative_to_downloads_dir(html_path)}"
                )
            except Exception as exc:
                self.logger.error(f"HTML export failed: {exc}")
        if export_pdf:
            pdf_path = output_path.with_suffix(".pdf")
            try:
                self.render_pdf(
                    serializable_messages, pdf_path, attachments_dir, chat_title
                )
                self.logger.info(
                    f"Saved PDF to {get_relative_to_downloads_dir(pdf_path)}"
                )
            except Exception as exc:
                self.logger.error(f"PDF export failed: {exc}")

        partial = self.get_temp_file_path(output_path)
        if partial.exists() and not self._stop_requested:
            self.logger.debug(f"Removing partial file: {partial}")
            partial.unlink()

        output_file_relative = get_relative_to_downloads_dir(output_path)
        self.logger.info(f"Saved {len(messages)} messages to {output_file_relative}")
