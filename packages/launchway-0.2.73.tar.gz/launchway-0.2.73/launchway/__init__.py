"""
Launchway - AI-powered job application automation CLI.
"""

__version__ = "0.2.73"
__author__ = "Launchway"
__description__ = "Automate your job search: tailor resumes, find jobs, and apply autonomously."
