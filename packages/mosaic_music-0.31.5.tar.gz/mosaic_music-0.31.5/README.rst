.. image:: https://raw.githubusercontent.com/mandeep/Mosaic/master/mosaic.png

|actions| |pypi| |status| |pyversions| |wheel| |license|

.. image:: https://raw.githubusercontent.com/mandeep/Mosaic/master/screenshots/screen.png

.. image:: https://raw.githubusercontent.com/mandeep/Mosaic/master/screenshots/screen2.png

.. image:: https://raw.githubusercontent.com/mandeep/Mosaic/master/screenshots/screen3.png

********
Features
********

* Displays correctly scaled cover art meta data in the main window
* Provides media information including bitrate, bits per sample, and sample rate
* Media library and playlist browser for easy access listening
* Supports FLAC and MP3 file formats
* Cross platform UI utilizes the user's system theme

************
Installation
************

With your environment set, simply run the following command to install Mosaic::

    $ pip install --user mosaic-music

If you would rather install from source, run the following commands::

    $ git clone https://github.com/mandeep/Mosaic.git
    $ cd Mosaic
    $ python setup.py install


*****
Usage
*****

Mosaic can be run with the following command::

    $ mosaic

**********
Change Log
**********


To see the Mosaic change log, click here_.

.. |actions| image:: https://img.shields.io/github/actions/workflow/status/mandeep/Mosaic/python-tests.yml
    :target: https://github.com/mandeep/Mosaic/actions
.. |pypi| image:: https://img.shields.io/pypi/v/mosaic-music
    :target: https://pypi.python.org/pypi/mosaic-music
.. |status| image:: https://img.shields.io/pypi/status/mosaic-music
    :target: https://pypi.python.org/pypi/mosaic-music
.. |pyversions| image:: https://img.shields.io/pypi/pyversions/mosaic-music
    :target: https://pypi.python.org/pypi/mosaic-music
.. |wheel| image:: https://img.shields.io/pypi/format/mosaic-music
    :target: https://pypi.python.org/pypi/mosaic-music
.. |license| image:: https://img.shields.io/pypi/l/mosaic-music
    :target: https://pypi.python.org/pypi/mosaic-music

.. _here: https://github.com/mandeep/Mosaic/blob/master/CHANGELOG.rst
