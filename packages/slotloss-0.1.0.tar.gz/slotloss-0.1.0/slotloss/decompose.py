"""Per-grammar-role loss decomposition.

Computes teacher-forced per-token loss and aggregates by grammar role.
"""

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from .roles import GrammarRole, assign_grammar_roles, map_roles_to_tokens


@dataclass
class RoleStats:
    """Loss statistics for a single grammar role."""
    total_loss: float = 0.0
    token_count: int = 0

    @property
    def mean_loss(self) -> float:
        return self.total_loss / self.token_count if self.token_count > 0 else 0.0


@dataclass
class DecomposeResult:
    """Per-grammar-role loss decomposition result."""
    per_role: Dict[str, RoleStats] = field(default_factory=dict)
    total_tokens: int = 0
    total_loss: float = 0.0
    label: str = ""

    @property
    def mean_loss(self) -> float:
        return self.total_loss / self.total_tokens if self.total_tokens > 0 else 0.0

    def role_names(self) -> List[str]:
        order = [
            "STRUCTURAL", "QUOTE", "KEY", "ENUM_VALUE", "BOOLEAN",
            "NUMBER", "FREE_TEXT", "WHITESPACE", "UNKNOWN"
        ]
        return [r for r in order if r in self.per_role]


def decompose_loss(
    model,
    tokenizer,
    prompt: str,
    target_json: str,
    json_schema: dict,
    device: str = "cpu",
) -> DecomposeResult:
    """Compute per-grammar-role loss for a single example.

    Args:
        model: HuggingFace causal LM (or PEFT-wrapped).
        tokenizer: The model's tokenizer.
        prompt: Input prompt.
        target_json: Target JSON string.
        json_schema: JSON Schema dict.
        device: torch device.

    Returns:
        DecomposeResult with per-role statistics.
    """
    import torch
    import torch.nn.functional as F

    prompt_ids = tokenizer.encode(prompt, add_special_tokens=True)
    target_ids = tokenizer.encode(target_json, add_special_tokens=False)

    input_ids = prompt_ids + target_ids
    input_tensor = torch.tensor([input_ids], device=device)

    with torch.no_grad():
        outputs = model(input_ids=input_tensor)
        logits = outputs.logits

    prompt_len = len(prompt_ids)
    target_len = len(target_ids)
    pred_logits = logits[0, prompt_len-1 : prompt_len-1+target_len, :]
    target_tensor = torch.tensor(target_ids, device=device)
    per_token_loss = F.cross_entropy(pred_logits, target_tensor, reduction='none')
    losses = per_token_loss.cpu().tolist()

    char_roles = assign_grammar_roles(target_json, json_schema)
    token_roles = map_roles_to_tokens(target_json, target_ids, char_roles, tokenizer)

    result = DecomposeResult()
    for tid, loss, role in zip(target_ids, losses, token_roles):
        name = role.name
        if name not in result.per_role:
            result.per_role[name] = RoleStats()
        result.per_role[name].total_loss += loss
        result.per_role[name].token_count += 1
        result.total_loss += loss
        result.total_tokens += 1

    return result


def decompose_loss_batch(
    model,
    tokenizer,
    examples: List[Tuple[str, str]],
    json_schema: dict,
    device: str = "cpu",
    verbose: bool = False,
) -> DecomposeResult:
    """Compute per-grammar-role loss over multiple examples.

    Args:
        model: HuggingFace causal LM (or PEFT-wrapped).
        tokenizer: The model's tokenizer.
        examples: List of (prompt, target_json) tuples.
        json_schema: JSON Schema dict.
        device: torch device.
        verbose: Print progress.

    Returns:
        Aggregated DecomposeResult.
    """
    combined = DecomposeResult()

    for i, (prompt, target_json) in enumerate(examples):
        result = decompose_loss(model, tokenizer, prompt, target_json,
                                json_schema, device)

        for role_name, stats in result.per_role.items():
            if role_name not in combined.per_role:
                combined.per_role[role_name] = RoleStats()
            combined.per_role[role_name].total_loss += stats.total_loss
            combined.per_role[role_name].token_count += stats.token_count

        combined.total_loss += result.total_loss
        combined.total_tokens += result.total_tokens

        if verbose and ((i + 1) % 10 == 0 or i == 0):
            print(f"  Processed {i+1}/{len(examples)}")

    return combined
