"""slotloss: Per-grammar-role loss decomposition for structured JSON output.

Reveals hidden per-role regressions in fine-tuned language models that
aggregate metrics miss.

Usage:
    from slotloss import analyze

    report = analyze(
        model_name="Qwen/Qwen2.5-7B-Instruct",
        checkpoint="my_lora/",
        schema="schema.json",
        data="test.jsonl",
    )
    print(report)

CLI:
    slotloss --model Qwen/Qwen2.5-7B-Instruct --checkpoint my_lora/ \\
        --schema schema.json --data test.jsonl
"""

__version__ = "0.1.0"

from .roles import GrammarRole, assign_grammar_roles
from .decompose import decompose_loss, decompose_loss_batch
from .report import SlotReport, analyze
