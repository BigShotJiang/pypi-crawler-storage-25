"""Grammar role assignment for structured JSON output.

Walks a JSON string character by character, assigns each character a
grammar role based on the schema, then maps roles to BPE token positions.
"""

from enum import Enum, auto
from typing import List, Optional


class GrammarRole(Enum):
    """Grammar roles for tokens in structured JSON output."""
    STRUCTURAL = auto()   # { } [ ] : ,
    QUOTE = auto()        # "
    KEY = auto()          # object key characters
    ENUM_VALUE = auto()   # categorical value characters
    BOOLEAN = auto()      # True / False string characters
    NUMBER = auto()       # numeric characters
    FREE_TEXT = auto()    # non-categorical string value characters
    WHITESPACE = auto()   # spaces, tabs, newlines
    UNKNOWN = auto()      # fallback


def assign_grammar_roles(json_str: str, json_schema: dict) -> List[GrammarRole]:
    """Assign a grammar role to each character in a JSON string.

    Args:
        json_str: A valid JSON string.
        json_schema: A JSON Schema dict with "properties" mapping field
            names to type definitions. Fields with "enum" containing
            ["True", "False"] are classified as boolean; other "enum"
            fields as enum values; everything else as free text.

    Returns:
        List of GrammarRole, one per character in json_str.
    """
    roles = [GrammarRole.UNKNOWN] * len(json_str)

    properties = json_schema.get("properties", {})
    enum_fields = set()
    boolean_fields = set()
    for key, prop in properties.items():
        if "enum" in prop:
            vals = set(prop["enum"])
            if vals == {"True", "False"}:
                boolean_fields.add(key)
            else:
                enum_fields.add(key)

    pos = 0

    def skip_ws():
        nonlocal pos
        while pos < len(json_str) and json_str[pos] in ' \t\n\r':
            roles[pos] = GrammarRole.WHITESPACE
            pos += 1

    def parse_string() -> str:
        nonlocal pos
        assert json_str[pos] == '"'
        roles[pos] = GrammarRole.QUOTE
        pos += 1
        start = pos
        while pos < len(json_str):
            if json_str[pos] == '\\':
                pos += 2
                continue
            if json_str[pos] == '"':
                content = json_str[start:pos]
                roles[pos] = GrammarRole.QUOTE
                pos += 1
                return content
            pos += 1
        return json_str[start:]

    def assign_content_roles(start: int, end: int, role: GrammarRole):
        for i in range(start, end):
            if roles[i] == GrammarRole.UNKNOWN:
                roles[i] = role

    def parse_value(current_key: Optional[str] = None):
        nonlocal pos
        skip_ws()
        if pos >= len(json_str):
            return
        ch = json_str[pos]
        if ch == '"':
            content_start = pos + 1
            content = parse_string()
            content_end = pos - 1
            if current_key in boolean_fields:
                role = GrammarRole.BOOLEAN
            elif current_key in enum_fields:
                role = GrammarRole.ENUM_VALUE
            else:
                role = GrammarRole.FREE_TEXT
            assign_content_roles(content_start, content_end, role)
        elif ch == '{':
            parse_object()
        elif ch == '[':
            parse_array()
        elif ch in '-0123456789':
            parse_number()
        elif json_str[pos:pos+4] == 'true':
            for _ in range(4):
                roles[pos] = GrammarRole.BOOLEAN
                pos += 1
        elif json_str[pos:pos+5] == 'false':
            for _ in range(5):
                roles[pos] = GrammarRole.BOOLEAN
                pos += 1
        elif json_str[pos:pos+4] == 'null':
            for _ in range(4):
                roles[pos] = GrammarRole.STRUCTURAL
                pos += 1

    def parse_number():
        nonlocal pos
        while pos < len(json_str) and json_str[pos] in '-0123456789.eE+':
            roles[pos] = GrammarRole.NUMBER
            pos += 1

    def parse_object():
        nonlocal pos
        assert json_str[pos] == '{'
        roles[pos] = GrammarRole.STRUCTURAL
        pos += 1
        skip_ws()
        if pos < len(json_str) and json_str[pos] == '}':
            roles[pos] = GrammarRole.STRUCTURAL
            pos += 1
            return
        while pos < len(json_str):
            skip_ws()
            key_start = pos + 1
            key = parse_string()
            key_end = pos - 1
            assign_content_roles(key_start, key_end, GrammarRole.KEY)
            skip_ws()
            if pos < len(json_str) and json_str[pos] == ':':
                roles[pos] = GrammarRole.STRUCTURAL
                pos += 1
            skip_ws()
            parse_value(current_key=key)
            skip_ws()
            if pos < len(json_str) and json_str[pos] == ',':
                roles[pos] = GrammarRole.STRUCTURAL
                pos += 1
            elif pos < len(json_str) and json_str[pos] == '}':
                roles[pos] = GrammarRole.STRUCTURAL
                pos += 1
                return
            else:
                break

    def parse_array():
        nonlocal pos
        assert json_str[pos] == '['
        roles[pos] = GrammarRole.STRUCTURAL
        pos += 1
        skip_ws()
        if pos < len(json_str) and json_str[pos] == ']':
            roles[pos] = GrammarRole.STRUCTURAL
            pos += 1
            return
        while pos < len(json_str):
            skip_ws()
            parse_value()
            skip_ws()
            if pos < len(json_str) and json_str[pos] == ',':
                roles[pos] = GrammarRole.STRUCTURAL
                pos += 1
            elif pos < len(json_str) and json_str[pos] == ']':
                roles[pos] = GrammarRole.STRUCTURAL
                pos += 1
                return
            else:
                break

    skip_ws()
    if pos < len(json_str):
        if json_str[pos] == '{':
            parse_object()
        elif json_str[pos] == '[':
            parse_array()
        else:
            parse_value()

    return roles


def map_roles_to_tokens(
    json_str: str,
    token_ids: List[int],
    char_roles: List[GrammarRole],
    tokenizer,
) -> List[GrammarRole]:
    """Map character-level grammar roles to token-level roles.

    For tokens spanning multiple roles (cross-terminal BPE tokens),
    assigns the role of the token's first character.

    Args:
        json_str: The JSON string.
        token_ids: BPE token IDs for the JSON string.
        char_roles: Per-character roles from assign_grammar_roles().
        tokenizer: HuggingFace tokenizer.

    Returns:
        List of GrammarRole, one per token.
    """
    token_roles = []
    decoded_so_far = ""
    for tid in token_ids:
        token_text = tokenizer.decode([tid])
        start = len(decoded_so_far)
        decoded_so_far += token_text
        if start < len(char_roles):
            token_roles.append(char_roles[start])
        else:
            token_roles.append(GrammarRole.UNKNOWN)
    return token_roles
