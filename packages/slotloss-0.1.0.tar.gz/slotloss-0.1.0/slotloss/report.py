"""Report generation: compares baseline vs fine-tuned, flags regressions."""

import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .decompose import DecomposeResult, RoleStats, decompose_loss_batch


@dataclass
class RoleComparison:
    """Comparison of a single grammar role between baseline and fine-tuned."""
    role: str
    baseline_loss: float
    finetuned_loss: float
    baseline_tokens: int
    finetuned_tokens: int

    @property
    def change_pct(self) -> float:
        if self.baseline_loss == 0:
            return 0.0
        return (self.finetuned_loss - self.baseline_loss) / self.baseline_loss * 100

    @property
    def regressed(self) -> bool:
        return self.finetuned_loss > self.baseline_loss

    @property
    def status(self) -> str:
        pct = self.change_pct
        if pct > 10:
            return f"!! REGRESSION (+{pct:.0f}%)"
        elif pct > 0:
            return f"~  marginal (+{pct:.0f}%)"
        elif pct > -10:
            return f"   marginal ({pct:.0f}%)"
        else:
            return f"OK ({pct:.0f}%)"


@dataclass
class SlotReport:
    """Full comparison report between baseline and fine-tuned model."""
    baseline: DecomposeResult
    finetuned: DecomposeResult
    comparisons: List[RoleComparison] = field(default_factory=list)
    regressions: List[RoleComparison] = field(default_factory=list)

    def __post_init__(self):
        role_order = [
            "STRUCTURAL", "QUOTE", "KEY", "ENUM_VALUE", "BOOLEAN",
            "NUMBER", "FREE_TEXT", "WHITESPACE"
        ]
        all_roles = set(self.baseline.per_role.keys()) | set(self.finetuned.per_role.keys())
        ordered = [r for r in role_order if r in all_roles]
        ordered.extend(r for r in sorted(all_roles) if r not in ordered)

        for role in ordered:
            b = self.baseline.per_role.get(role, RoleStats())
            f = self.finetuned.per_role.get(role, RoleStats())
            comp = RoleComparison(
                role=role,
                baseline_loss=b.mean_loss,
                finetuned_loss=f.mean_loss,
                baseline_tokens=b.token_count,
                finetuned_tokens=f.token_count,
            )
            self.comparisons.append(comp)
            if comp.regressed and comp.change_pct > 10:
                self.regressions.append(comp)

    def __str__(self) -> str:
        lines = []
        lines.append("")
        lines.append("=" * 70)
        lines.append("  slotloss: Per-Grammar-Role Loss Report")
        lines.append("=" * 70)
        lines.append("")
        lines.append(f"{'Role':<15} {'Baseline':>10} {'Fine-tuned':>10} {'Change':>10}  Status")
        lines.append("-" * 70)

        for c in self.comparisons:
            lines.append(
                f"{c.role:<15} {c.baseline_loss:>10.4f} {c.finetuned_loss:>10.4f} "
                f"{c.change_pct:>+9.1f}%  {c.status}"
            )

        lines.append("-" * 70)
        lines.append(
            f"{'TOTAL':<15} {self.baseline.mean_loss:>10.4f} "
            f"{self.finetuned.mean_loss:>10.4f} "
            f"{(self.finetuned.mean_loss - self.baseline.mean_loss) / max(self.baseline.mean_loss, 1e-10) * 100:>+9.1f}%"
        )

        if self.regressions:
            lines.append("")
            lines.append(f"WARNING: {len(self.regressions)} grammar role(s) REGRESSED after fine-tuning:")
            for r in self.regressions:
                lines.append(
                    f"  {r.role}: {r.baseline_loss:.4f} -> {r.finetuned_loss:.4f} "
                    f"(+{r.change_pct:.0f}%)"
                )
            lines.append("")
            lines.append("Your model may be memorizing majority values for constrained fields.")
            lines.append("Per-role regressions are invisible to aggregate loss metrics.")
            lines.append("")
            lines.append("Learn more: https://github.com/breckbaldwin/slotloss")
        else:
            lines.append("")
            lines.append("No regressions detected. All grammar roles improved or held steady.")

        lines.append("")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "baseline": {
                "per_role": {r: {"mean_loss": s.mean_loss, "tokens": s.token_count}
                             for r, s in self.baseline.per_role.items()},
                "total_mean_loss": self.baseline.mean_loss,
                "total_tokens": self.baseline.total_tokens,
            },
            "finetuned": {
                "per_role": {r: {"mean_loss": s.mean_loss, "tokens": s.token_count}
                             for r, s in self.finetuned.per_role.items()},
                "total_mean_loss": self.finetuned.mean_loss,
                "total_tokens": self.finetuned.total_tokens,
            },
            "regressions": [
                {"role": r.role, "baseline": r.baseline_loss,
                 "finetuned": r.finetuned_loss, "change_pct": r.change_pct}
                for r in self.regressions
            ],
        }


def load_model(model_name: str, checkpoint: Optional[str], device: str):
    """Load base model, optionally with a LoRA checkpoint."""
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)

    dtype = torch.bfloat16 if device == "cuda" else torch.float32
    model = AutoModelForCausalLM.from_pretrained(
        model_name, dtype=dtype, trust_remote_code=True
    ).to(device)

    if checkpoint:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, checkpoint)

    model.eval()
    return model, tokenizer


def analyze(
    model_name: str,
    schema: str,
    data: str,
    checkpoint: Optional[str] = None,
    device: str = "cpu",
    max_examples: Optional[int] = None,
    verbose: bool = True,
) -> SlotReport:
    """Run full analysis: baseline vs fine-tuned, with regression detection.

    Args:
        model_name: HuggingFace model name.
        schema: Path to JSON Schema file.
        data: Path to JSONL data file (with "prompt" and "target_json" fields).
        checkpoint: Path to LoRA checkpoint (None for baseline-only).
        device: torch device.
        max_examples: Limit number of examples.
        verbose: Print progress.

    Returns:
        SlotReport with baseline, fine-tuned, and comparison.
    """
    with open(schema) as f:
        json_schema = json.load(f)

    examples = []
    with open(data) as f:
        for line in f:
            rec = json.loads(line)
            examples.append((rec["prompt"], rec["target_json"]))
    if max_examples:
        examples = examples[:max_examples]

    if verbose:
        print(f"Model: {model_name}")
        print(f"Schema: {schema}")
        print(f"Examples: {len(examples)}")

    # Baseline
    if verbose:
        print(f"\nRunning baseline (no fine-tuning)...")
    base_model, tokenizer = load_model(model_name, None, device)
    baseline = decompose_loss_batch(
        base_model, tokenizer, examples, json_schema, device, verbose
    )
    baseline.label = "baseline"

    # Free baseline model memory
    del base_model
    import torch
    if device == "cuda":
        torch.cuda.empty_cache()

    # Fine-tuned
    if checkpoint:
        if verbose:
            print(f"\nRunning fine-tuned ({checkpoint})...")
        ft_model, tokenizer = load_model(model_name, checkpoint, device)
        finetuned = decompose_loss_batch(
            ft_model, tokenizer, examples, json_schema, device, verbose
        )
        finetuned.label = checkpoint
        del ft_model
        if device == "cuda":
            torch.cuda.empty_cache()
    else:
        if verbose:
            print("\nNo checkpoint provided. Baseline-only report.")
        finetuned = baseline

    report = SlotReport(baseline=baseline, finetuned=finetuned)

    if verbose:
        print(report)

    return report
