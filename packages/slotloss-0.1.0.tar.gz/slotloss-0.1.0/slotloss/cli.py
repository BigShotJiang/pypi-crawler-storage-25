"""Command-line interface for slotloss.

Usage:
    slotloss --model Qwen/Qwen2.5-7B-Instruct \\
        --checkpoint my_lora/ \\
        --schema schema.json \\
        --data test.jsonl

    slotloss --model Qwen/Qwen2.5-7B-Instruct \\
        --schema schema.json \\
        --data test.jsonl  # baseline only
"""

import argparse
import json
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="slotloss",
        description=(
            "Per-grammar-role loss decomposition for fine-tuned JSON output. "
            "Compares baseline vs fine-tuned model and flags per-role regressions "
            "hidden by aggregate metrics."
        ),
    )
    parser.add_argument("--model", required=True,
                        help="HuggingFace model name (e.g., Qwen/Qwen2.5-7B-Instruct)")
    parser.add_argument("--checkpoint", default=None,
                        help="Path to LoRA checkpoint directory (omit for baseline only)")
    parser.add_argument("--schema", required=True,
                        help="Path to JSON Schema file")
    parser.add_argument("--data", required=True,
                        help="Path to JSONL test data (fields: prompt, target_json)")
    parser.add_argument("--device", default="cpu",
                        choices=["cpu", "cuda", "mps"],
                        help="torch device (default: cpu)")
    parser.add_argument("--max-examples", type=int, default=None,
                        help="Limit number of test examples")
    parser.add_argument("--output", default=None,
                        help="Write JSON report to file")
    parser.add_argument("--quiet", action="store_true",
                        help="Suppress progress output")

    args = parser.parse_args()

    from .report import analyze

    report = analyze(
        model_name=args.model,
        schema=args.schema,
        data=args.data,
        checkpoint=args.checkpoint,
        device=args.device,
        max_examples=args.max_examples,
        verbose=not args.quiet,
    )

    if args.output:
        with open(args.output, "w") as f:
            json.dump(report.to_dict(), f, indent=2)
        print(f"Report written to {args.output}")

    sys.exit(1 if report.regressions else 0)


if __name__ == "__main__":
    main()
