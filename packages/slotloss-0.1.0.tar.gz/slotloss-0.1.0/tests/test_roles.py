"""Tests for grammar role assignment."""

import json
from collections import Counter
from slotloss.roles import GrammarRole, assign_grammar_roles


SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "city": {"type": "string"},
        "cuisine": {"type": "string", "enum": ["Mexican", "Italian", "Chinese"]},
        "price": {"type": "string", "enum": ["cheap", "moderate", "expensive"]},
        "has_wifi": {"type": "string", "enum": ["True", "False"]},
        "rating": {"type": "number"},
    },
}


def test_structural():
    roles = assign_grammar_roles('{}', SCHEMA)
    assert roles[0] == GrammarRole.STRUCTURAL
    assert roles[1] == GrammarRole.STRUCTURAL


def test_key():
    roles = assign_grammar_roles('{"city": "NYC"}', SCHEMA)
    assert roles[2] == GrammarRole.KEY  # c
    assert roles[3] == GrammarRole.KEY  # i
    assert roles[4] == GrammarRole.KEY  # t
    assert roles[5] == GrammarRole.KEY  # y


def test_free_text():
    roles = assign_grammar_roles('{"city": "NYC"}', SCHEMA)
    assert roles[9] == GrammarRole.QUOTE   # "
    assert roles[10] == GrammarRole.FREE_TEXT  # N
    assert roles[11] == GrammarRole.FREE_TEXT  # Y
    assert roles[12] == GrammarRole.FREE_TEXT  # C


def test_enum():
    roles = assign_grammar_roles('{"cuisine": "Italian"}', SCHEMA)
    idx = '{"cuisine": "'.find('"', 12)
    i = '{"cuisine": "Italian"}'.index("Italian")
    assert roles[i] == GrammarRole.ENUM_VALUE


def test_boolean():
    roles = assign_grammar_roles('{"has_wifi": "True"}', SCHEMA)
    idx = '{"has_wifi": "True"}'.index("True")
    assert roles[idx] == GrammarRole.BOOLEAN


def test_number():
    roles = assign_grammar_roles('{"rating": 4.5}', SCHEMA)
    idx = '{"rating": 4.5}'.index("4")
    assert roles[idx] == GrammarRole.NUMBER
    assert roles[idx + 1] == GrammarRole.NUMBER  # .
    assert roles[idx + 2] == GrammarRole.NUMBER  # 5


def test_whitespace():
    roles = assign_grammar_roles('{\n  "city": "X"\n}', SCHEMA)
    assert roles[1] == GrammarRole.WHITESPACE  # \n
    assert roles[2] == GrammarRole.WHITESPACE  # space


def test_quote():
    roles = assign_grammar_roles('{"city": "X"}', SCHEMA)
    assert roles[1] == GrammarRole.QUOTE   # opening " of key
    assert roles[6] == GrammarRole.QUOTE   # closing " of key


def test_no_unknowns():
    obj = {"name": "Bob", "cuisine": "Italian", "has_wifi": "True", "rating": 5}
    roles = assign_grammar_roles(json.dumps(obj, indent=2), SCHEMA)
    assert GrammarRole.UNKNOWN not in roles


def test_all_roles_present():
    obj = {"name": "Bob", "cuisine": "Italian", "has_wifi": "True", "rating": 5}
    roles = assign_grammar_roles(json.dumps(obj, indent=2), SCHEMA)
    names = Counter(r.name for r in roles)
    assert names["STRUCTURAL"] > 0
    assert names["QUOTE"] > 0
    assert names["KEY"] > 0
    assert names["ENUM_VALUE"] > 0
    assert names["BOOLEAN"] > 0
    assert names["NUMBER"] > 0
    assert names["FREE_TEXT"] > 0
    assert names["WHITESPACE"] > 0
