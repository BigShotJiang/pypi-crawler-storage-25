
def display_code():
    code = """
import cv2
import numpy as np

image = cv2.imread("car.jpg")
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

edges = cv2.Canny(gray, 50, 150)

_, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

kernel = np.ones((3, 3), np.uint8)
clean = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)

contours, _ = cv2.findContours(clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

detected = image.copy()

for cnt in contours:
 if cv2.contourArea(cnt) > 500:
  x, y, w, h = cv2.boundingRect(cnt)
  cv2.rectangle(detected, (x, y), (x + w, y + h), (0, 0, 255), 2)

cv2.imshow("Canny Edge Detection", edges)
cv2.imshow("Thresholded Image", clean)
cv2.imshow("Detected Objects", detected)

cv2.waitKey(0)
cv2.destroyAllWindows()
    """

    return code