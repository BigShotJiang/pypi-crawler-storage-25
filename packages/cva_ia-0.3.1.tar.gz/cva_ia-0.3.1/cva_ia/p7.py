import textwrap
def display_code():
    code = """
import cv2

img1 = cv2.imread("car.jpg")
img2 = cv2.imread("car3.png")

orb = cv2.ORB_create()

kp1, des1 = orb.detectAndCompute(img1, None)
kp2, des2 = orb.detectAndCompute(img2, None)

bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

matches = bf.match(des1, des2)

matches = sorted(matches, key=lambda x: x.distance)

matched_img = cv2.drawMatches(
 img1,
 kp1,
 img2,
 kp2,
 matches[:20],
 None,
 flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

cv2.imshow("ORB Feature Matching", matched_img)

cv2.waitKey(0)
cv2.destroyAllWindows()
    """

    return code