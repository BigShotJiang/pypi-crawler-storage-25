
def display_code():
    code = """
import cv2
import numpy as np

image = cv2.imread("car.jpg")

image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

pixels = image_rgb.reshape((-1, 3)).astype(np.float32)

K = 7

criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)

_, labels, centers = cv2.kmeans(
 pixels,
 K,
 None,
 criteria,
 10,
 cv2.KMEANS_RANDOM_CENTERS
)

centers = np.uint8(centers)

segmented = centers[labels.flatten()]
segmented = segmented.reshape(image_rgb.shape)

cv2.imshow("Original Image", image)
cv2.imshow("Semantic Segmentation (K-Means)", segmented)

cv2.waitKey(0)
cv2.destroyAllWindows()
    """

    return code