import textwrap
def display_code():
    code = """
import cv2
import numpy as np

img = cv2.imread("car.jpg")

cv2.imshow("Original Image", img)

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
gray = np.float32(gray)

corners = cv2.cornerHarris(gray, 2, 3, 0.04)

cv2.imshow("Corner Detection", corners)

corners = cv2.dilate(corners, None)

cv2.imshow("Dilated Image", corners)

img[corners > 0.01 * corners.max()] = [0, 0, 255]

cv2.imshow("Harris Corner Detection", img)

cv2.waitKey(0)
cv2.destroyAllWindows()
    """

    return code