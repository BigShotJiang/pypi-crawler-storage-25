import textwrap
def display_code():
    code = """
import cv2
import numpy as np
import tensorflow as tf

from tensorflow.keras.applications.mobilenet import (
 MobileNet,
 preprocess_input,
 decode_predictions
)

model = MobileNet(weights='imagenet')

image_path = "car.jpg"

img = cv2.imread(image_path)

img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

img_resized = cv2.resize(img_rgb, (224, 224))

img_array = np.array(img_resized)
img_array = np.expand_dims(img_array, axis=0)

img_array = preprocess_input(img_array)

predictions = model.predict(img_array)

decoded = decode_predictions(predictions, top=1)[0][0]

class_label = decoded[1]
probability = decoded[2] * 100

print(f"Predicted Class: {class_label}")
print(f"Probability: {probability:.2f}%")

output_image = cv2.putText(
 img,
 f"{class_label} ({probability:.2f}%)",
 (10, 30),
 cv2.FONT_HERSHEY_SIMPLEX,
 1,
 (0, 255, 0),
 2
)

cv2.imshow("Prediction", output_image)

cv2.waitKey(0)
cv2.destroyAllWindows()
    """

    return code