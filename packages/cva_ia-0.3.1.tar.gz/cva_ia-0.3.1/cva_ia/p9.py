
def display_code():
    code = """
import cv2
import numpy as np

img1 = cv2.imread("car_st1.png")
img2 = cv2.imread("car_st2.png")

if img1 is None or img2 is None:
 print("Error loading images")
 exit()

gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

orb = cv2.ORB_create(5000)

kp1, des1 = orb.detectAndCompute(gray1, None)
kp2, des2 = orb.detectAndCompute(gray2, None)

bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

matches = bf.match(des1, des2)

matches = sorted(matches, key=lambda x: x.distance)

pts1 = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
pts2 = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)

H, mask = cv2.findHomography(pts2, pts1, cv2.RANSAC, 5.0)

height1, width1 = img1.shape[:2]
height2, width2 = img2.shape[:2]

panorama = cv2.warpPerspective(img2, H, (width1 + width2, height1))

panorama[0:height1, 0:width1] = img1

gray_panorama = cv2.cvtColor(panorama, cv2.COLOR_BGR2GRAY)

_, thresh = cv2.threshold(gray_panorama, 1, 255, cv2.THRESH_BINARY)

contours, _ = cv2.findContours(
 thresh,
 cv2.RETR_EXTERNAL,
 cv2.CHAIN_APPROX_SIMPLE
)

if contours:
 x, y, w, h = cv2.boundingRect(contours[0])
 panorama = panorama[y:y+h, x:x+w]

cv2.imshow("Image 1", img1)
cv2.imshow("Image 2", img2)
cv2.imshow("Stitched Panorama", panorama)

cv2.waitKey(0)
cv2.destroyAllWindows()
    """

    return code