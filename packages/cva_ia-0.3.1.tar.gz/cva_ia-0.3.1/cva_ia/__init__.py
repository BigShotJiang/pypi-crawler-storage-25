import pyperclip

def display_code(choice):
    module = __import__(f"cva_ia.p{choice}", fromlist=["display_code"])
    return module.display_code()



def displaycode(choice):
    module = __import__(f"cva_ia.p{choice}", fromlist=["display_code"])

    code = module.display_code()

    pyperclip.copy(code)