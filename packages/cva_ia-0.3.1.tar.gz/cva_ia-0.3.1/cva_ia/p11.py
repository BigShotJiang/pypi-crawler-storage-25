def display_code():
    code = """
    
    """
    return code