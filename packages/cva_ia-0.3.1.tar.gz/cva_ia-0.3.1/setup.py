from setuptools import setup, find_packages

setup(
    name="cva-ia",
    version="0.3.1",
    packages=find_packages(),
    install_requires=[
        "pyperclip",
    ],
)